#include "../GSM_include/GSM_include_def.h"

// TYPE is double or complex
// -------------------------

// CM means center of mass
// -----------------------

// Class xL2_CM_plus_alpha_str is used only in closures and then is not commented.





// Class applying the L[CM]^2 operator
// -----------------------------------
// \vec{L[CM]} = \vec{R} x \vec{P} is the center of mass angular momenum operator, with \vec{R} and \vec{P} the center of mass radius and linear momentum.
// It is useful to check if a HO-SM vector is separated in |CM>.|intrinsic> parts, where |CM> has a fixed L[CM] quantum number.
// This arises when building cluster states from |Psi> = |CM-0s>.|intrinsic>, as then cluster states are equal to |N[CM] L[CM]>.|intrinsic>.
//
// One has here constructors, destructors, L[CM]^2 operator apply call and operators overloading of operations of the type a.L[CM]^2 + b.
//
// Routines are rather straightforward so that they are not detailed. Only general explanations are given.
//
// One uses the standard decomposition L[CM]^2 = L-.L+ + Lz.(Lz + 1), to which an alpha.Id constant operator is added.
// L+, L- and Lz are called using CM_operator_class.
// If M = M[max], the maximal M that one can have in the GSM space, L+ |Psi> is always equal to zero.
// Work GSM vectos and L+, L- , Lz operators are external to the class.
//
// xL2_CM_plus_alpha_str
// ---------------------
// L2_CM_pa must be understood here as L[CM]^2 + alpha.Id (see above).
// Operators overloading of operations are of the type a.L2_CM_pa + b.Id, to which operators of the form c.L2_CM_pa + d.Id as well can be added. 
// One cannot add another operator to a.L2_CM_pa + b.Id besides c.L2_CM_pa + d.Id,
// however, as one would have to call different many-body routines for it, which would be too complicated to handle.
// Indeed, the latter is seen as (a + c).L2_CM_pa + (b + d).Id .
// One can use instead (a*H + b)*PSI_0 + L2_CM_pa*PSI_1 for example, up to 10 terms.
// Products of operators are not accepted with operator overloading.




L2_CM_class::L2_CM_class () :
  Lplus_ptr (NULL) , 
  Lminus_ptr (NULL) , 
  Lz_ptr (NULL) , 
  PSI_M_ptr (NULL) ,
  PSI_Mp1_ptr (NULL)
{}



L2_CM_class::L2_CM_class (
			  const class CM_operator_class &Lplus , 
			  const class CM_operator_class &Lminus , 
			  const class CM_operator_class &Lz , 
			  class GSM_vector &PSI_M ,
			  class GSM_vector &PSI_Mp1) :
  Lplus_ptr (NULL) , 
  Lminus_ptr (NULL) , 
  Lz_ptr (NULL) , 
  PSI_M_ptr (NULL) ,
  PSI_Mp1_ptr (NULL)
{
  allocate (Lplus , Lminus , Lz , PSI_M , PSI_Mp1);  
}




L2_CM_class::L2_CM_class (const class L2_CM_class &X) :
  Lplus_ptr (NULL) , 
  Lminus_ptr (NULL) , 
  Lz_ptr (NULL) , 
  PSI_M_ptr (NULL) ,
  PSI_Mp1_ptr (NULL)
{
  allocate_fill (X);
}


L2_CM_class::~L2_CM_class () {}



void L2_CM_class::allocate (
			    const class CM_operator_class &Lplus , 
			    const class CM_operator_class &Lminus ,  
			    const class CM_operator_class &Lz ,    
			    class GSM_vector &PSI_M ,
			    class GSM_vector &PSI_Mp1)
{
  Lplus_ptr  = &Lplus; 
  Lminus_ptr = &Lminus;
  Lz_ptr = &Lz; 

  PSI_M_ptr   = &PSI_M;
  PSI_Mp1_ptr = &PSI_Mp1;
}





void L2_CM_class::allocate_fill (const class L2_CM_class &X)
{
  if (!X.is_it_filled ()) return;
  
  Lplus_ptr  = X.Lplus_ptr; 
  Lminus_ptr = X.Lminus_ptr; 
  Lz_ptr     = X.Lz_ptr; 

  PSI_Mp1_ptr = X.PSI_Mp1_ptr;
  PSI_M_ptr   = X.PSI_M_ptr;
}




void L2_CM_class::deallocate ()
{ 
  Lplus_ptr  = NULL;
  Lminus_ptr = NULL;
  Lz_ptr     = NULL;

  PSI_M_ptr   = NULL;
  PSI_Mp1_ptr = NULL;
}





void L2_CM_class::apply_add (
			     const class GSM_vector &PSI_in , 
			     const TYPE &alpha , 
			     class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper_in  = PSI_in.get_GSM_vector_helper ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = PSI_out.get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local_in  = GSM_vector_helper_in.get_is_it_MPI_parallelized_local ();
  const bool is_it_MPI_parallelized_local_out = GSM_vector_helper_out.get_is_it_MPI_parallelized_local ();
  
  const bool is_it_hybrid_1D_2D_in  = GSM_vector_helper_in.get_is_it_hybrid_1D_2D ();
  const bool is_it_hybrid_1D_2D_out = GSM_vector_helper_out.get_is_it_hybrid_1D_2D ();

  if (is_it_MPI_parallelized_local_in  && !is_it_hybrid_1D_2D_in)  error_message_print_abort ("The GSM vector in must be sequential or hybrid 1D/2D in L2_CM_class::apply_add");
  if (is_it_MPI_parallelized_local_out && !is_it_hybrid_1D_2D_out) error_message_print_abort ("The GSM vector out must be sequential or hybrid 1D/2D in L2_CM_class::apply_add");
  
  const class CM_operator_class &Lz = get_Lz ();

  class GSM_vector &PSI_M = get_PSI_M ();

  PSI_M = (Lz + 1.0)*PSI_in;
    
  const double M = GSM_vector_helper_in.get_M ();
  
  const double Jmax = GSM_vector_helper_in.get_Jmax ();
  
  if (rint (M - Jmax) != 0.0)
    {
      const class CM_operator_class &Lplus  = get_Lplus ();      
      const class CM_operator_class &Lminus = get_Lminus ();

      class GSM_vector &PSI_Mp1 = get_PSI_Mp1 ();
      
      PSI_Mp1 = Lplus*PSI_in;
       
      PSI_out += Lminus*PSI_Mp1 + Lz*PSI_M + alpha*PSI_in;      
    }
  else
    PSI_out += Lz*PSI_M + alpha*PSI_in;
}






xL2_CM_plus_alpha_str::xL2_CM_plus_alpha_str (
					      const TYPE &x_c ,
					      const TYPE &alpha_c ,
					      const class L2_CM_class &L2_CM_c) :
  x (x_c) ,
  alpha (alpha_c) ,
  L2_CM (L2_CM_c)
{}

class xL2_CM_plus_alpha_str operator + (const class L2_CM_class &L2_CM)
{
  return xL2_CM_plus_alpha_str (1.0 , 0.0 , L2_CM);
}

class xL2_CM_plus_alpha_str operator - (const class L2_CM_class &L2_CM)
{
  return xL2_CM_plus_alpha_str (-1.0 , 0.0 , L2_CM);
}

class xL2_CM_plus_alpha_str operator + (const class L2_CM_class &L2_CM , const double alpha)
{
  return xL2_CM_plus_alpha_str (1.0 , alpha , L2_CM);
}

class xL2_CM_plus_alpha_str operator - (const class L2_CM_class &L2_CM , const double alpha)
{
  return xL2_CM_plus_alpha_str (1.0 , -alpha , L2_CM);
}

class xL2_CM_plus_alpha_str operator + (const double alpha , const class L2_CM_class &L2_CM)
{
  return xL2_CM_plus_alpha_str (1.0 , alpha , L2_CM);
}

class xL2_CM_plus_alpha_str operator - (const double alpha , const class L2_CM_class &L2_CM)
{
  return xL2_CM_plus_alpha_str (-1.0 , alpha , L2_CM);
}

class xL2_CM_plus_alpha_str operator * (const class L2_CM_class &L2_CM , const double x)
{
  return xL2_CM_plus_alpha_str (x , 0.0 , L2_CM);
}

class xL2_CM_plus_alpha_str operator * (const double x , const class L2_CM_class &L2_CM)
{
  return xL2_CM_plus_alpha_str (x , 0.0 , L2_CM);
}

class xL2_CM_plus_alpha_str operator / (const class L2_CM_class &L2_CM , const double x)
{
  const double one_over_x = 1.0/x;

  return xL2_CM_plus_alpha_str (one_over_x , 0.0 , L2_CM);
}

class xL2_CM_plus_alpha_str operator + (const class xL2_CM_plus_alpha_str &Op)
{
  return xL2_CM_plus_alpha_str (Op.x , Op.alpha , Op.L2_CM);
}

class xL2_CM_plus_alpha_str operator - (const class xL2_CM_plus_alpha_str &Op)
{
  return xL2_CM_plus_alpha_str (-Op.x , -Op.alpha , Op.L2_CM);
}

class xL2_CM_plus_alpha_str operator + (const class xL2_CM_plus_alpha_str &Op , const double term)
{
  return xL2_CM_plus_alpha_str (Op.x , Op.alpha + term , Op.L2_CM);
}

class xL2_CM_plus_alpha_str operator - (const class xL2_CM_plus_alpha_str &Op , const double term)
{
  return xL2_CM_plus_alpha_str (Op.x , Op.alpha - term , Op.L2_CM);
}

class xL2_CM_plus_alpha_str operator + (const double term , const class xL2_CM_plus_alpha_str &Op)
{
  return xL2_CM_plus_alpha_str (Op.x , term + Op.alpha , Op.L2_CM);
}

class xL2_CM_plus_alpha_str operator - (const double term , const class xL2_CM_plus_alpha_str &Op)
{
  return xL2_CM_plus_alpha_str (-Op.x , term - Op.alpha , Op.L2_CM);
}

class xL2_CM_plus_alpha_str operator * (const class xL2_CM_plus_alpha_str &Op , const double factor)
{
  return xL2_CM_plus_alpha_str (Op.x*factor , Op.alpha*factor , Op.L2_CM);
}

class xL2_CM_plus_alpha_str operator / (const class xL2_CM_plus_alpha_str &Op , const double factor)
{
  return xL2_CM_plus_alpha_str (Op.x/factor , Op.alpha/factor , Op.L2_CM);
}

class xL2_CM_plus_alpha_str operator * (const double factor , const class xL2_CM_plus_alpha_str &Op)
{
  return xL2_CM_plus_alpha_str (factor*Op.x , factor*Op.alpha , Op.L2_CM);
}

#ifdef TYPEisDOUBLECOMPLEX

class xL2_CM_plus_alpha_str operator + (const class L2_CM_class &L2_CM , const complex<double> &alpha)
{
  return xL2_CM_plus_alpha_str (1.0 , alpha , L2_CM);
}

class xL2_CM_plus_alpha_str operator - (const class L2_CM_class &L2_CM , const complex<double> &alpha)
{
  return xL2_CM_plus_alpha_str (1.0 , -alpha , L2_CM);
}

class xL2_CM_plus_alpha_str operator + (const complex<double> &alpha , const class L2_CM_class &L2_CM)
{
  return xL2_CM_plus_alpha_str (1.0 , alpha , L2_CM);
}

class xL2_CM_plus_alpha_str operator - (const complex<double> &alpha , const class L2_CM_class &L2_CM)
{
  return xL2_CM_plus_alpha_str (-1.0 , alpha , L2_CM);
}

class xL2_CM_plus_alpha_str operator * (const class L2_CM_class &L2_CM , const complex<double> &x)
{
  return xL2_CM_plus_alpha_str (x , 0.0 , L2_CM);
}

class xL2_CM_plus_alpha_str operator * (const complex<double> &x , const class L2_CM_class &L2_CM)
{
  return xL2_CM_plus_alpha_str (x , 0.0 , L2_CM);
}

class xL2_CM_plus_alpha_str operator / (const class L2_CM_class &L2_CM , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return xL2_CM_plus_alpha_str (one_over_x , 0.0 , L2_CM);
}

class xL2_CM_plus_alpha_str operator + (const class xL2_CM_plus_alpha_str &Op , const complex<double> &term)
{
  return xL2_CM_plus_alpha_str (Op.x , Op.alpha + term , Op.L2_CM);
}

class xL2_CM_plus_alpha_str operator - (const class xL2_CM_plus_alpha_str &Op , const complex<double> &term)
{
  return xL2_CM_plus_alpha_str (Op.x , Op.alpha - term , Op.L2_CM);
}

class xL2_CM_plus_alpha_str operator + (const complex<double> &term , const class xL2_CM_plus_alpha_str &Op)
{
  return xL2_CM_plus_alpha_str (Op.x , term + Op.alpha , Op.L2_CM);
}

class xL2_CM_plus_alpha_str operator - (const complex<double> &term , const class xL2_CM_plus_alpha_str &Op)
{
  return xL2_CM_plus_alpha_str (-Op.x , term - Op.alpha , Op.L2_CM);
}

class xL2_CM_plus_alpha_str operator * (const class xL2_CM_plus_alpha_str &Op , const complex<double> &factor)
{
  return xL2_CM_plus_alpha_str (Op.x*factor , Op.alpha*factor , Op.L2_CM);
}

class xL2_CM_plus_alpha_str operator / (const class xL2_CM_plus_alpha_str &Op , const complex<double> &factor)
{
  return xL2_CM_plus_alpha_str (Op.x/factor , Op.alpha/factor , Op.L2_CM);
}

class xL2_CM_plus_alpha_str operator * (const complex<double> &factor , const class xL2_CM_plus_alpha_str &Op)
{
  return xL2_CM_plus_alpha_str (factor*Op.x , factor*Op.alpha , Op.L2_CM);
}

#endif

class xL2_CM_plus_alpha_str operator + (const class xL2_CM_plus_alpha_str &Op_a , const class xL2_CM_plus_alpha_str &Op_b)
{
  if (&(Op_a.L2_CM) != &(Op_b.L2_CM))
    error_message_print_abort ("L2_CM must be the same in both Op_a and Op_b in class xL2_CM_plus_alpha_str operator +");

  return xL2_CM_plus_alpha_str (Op_a.x + Op_b.x , Op_a.alpha + Op_b.alpha , Op_a.L2_CM);
}

class xL2_CM_plus_alpha_str operator - (const class xL2_CM_plus_alpha_str &Op_a , const class xL2_CM_plus_alpha_str &Op_b)
{	
  if (&(Op_a.L2_CM) != &(Op_b.L2_CM))
    error_message_print_abort ("L2_CM must be the same in both Op_a and Op_b in class xL2_CM_plus_alpha_str operator -");

  return xL2_CM_plus_alpha_str (Op_a.x - Op_b.x , Op_a.alpha - Op_b.alpha , Op_a.L2_CM);
}




double used_memory_calc (const class L2_CM_class &T)
{
  return sizeof (T)/1000000.0;
}

