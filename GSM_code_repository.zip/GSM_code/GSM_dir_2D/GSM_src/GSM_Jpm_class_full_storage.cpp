#include "../GSM_include/GSM_include_def.h"

// TYPE is double or complex
// -------------------------



using namespace inputs_misc;
using namespace GSM_vector_NBMEs_handling;
using namespace GSM_vector_NBMEs_handling::in_to_out;
using namespace GSM_vector_dimensions;
using namespace MPI_2D_partitioning;



// Storage of non-zero NBMEs of Jpm when full storage options are used and application of Jpm times vector
// -------------------------------------------------------------------------------------------------------
// Jpm means J+ or J-, as pm = +/1. One uses Jpm for J+ or J- in all Jpm classes files.
//
// One uses Jpm in J^2 = J-.J+ + Jz.(Jz + 1), and to generate |J M> Hamiltonian eigenstates for all M values starting from an eigenstate with a fixed M value.
//
// Non-zero NBMEs of Jpm are calculated and stored therein. Array dimensions have been calculated in GSM_Jpm_class_non_zero_NBMEs_numbers.cpp .
//
// One calculates non-zero NBMEs occurring in one node only as they are not used in other nodes due to Hamiltonian hybrid 1D/2D partitioning (see GSM_vector.cpp).
//
// One loops over proton and neutron Slater determinants, the first loop being proton or neutron according to the case.
//
//
//
// hybrid 1D/2D partitioning
// -------------------------
// One uses hybrid 1D/2D partitioning for J+/-, so that each node takes care of only one part of the input and output GSM vectors (2D partitioning), but where operators are stored as columns on each node (1D partitioning):
//
//        J+/-         x  Psi[in]  =  Psi[out]
// * n * n * n * n *        *           *   
// *   *   *   *   *      node 0       node 0
// * o * o * o * o *        *           *
// *   *   *   *   *      node 1       node 1
// * d * d * d * d *        *           *
// *   *   *   *   *      node 2       node 2
// * e * e * e * e *        *           *
// *   *   *   *   *      node 3       node 3
// * 0 * 1 * 2 * 3 *        *           *
//                                                  
// Hence, each node calculates only part of Psi[out] and stores only part of J+/-. 
// What is called a square is a part of J+/- connecting the node i storing a part of |Psi[in]> to the node j storing a part of |Psi[out]>.
// An MPI communication of all newly calculated components on each row to the node taking care of the considered part of |Psi[out]> has to be done.
// However, as J+/- does not induce configuration mixing, it is localized on one node except for side effects.
// Hence, one just has to transfer the newly calculated non-zero components of J+/-|Psi[in]> from one node to another, which are in a very small number. 
// If OpenMP is used, MPI communications are overlapped with computation. For this, one uses two J+/-|Psi[in]> vector parts, one for even rows and one for odd rows.
// When one loops over rows, a J+/-|Psi[in]> part is transfered by one core, while the other cores calculate the other part. 
//
//
// J+/J- with hybrid 1D/2D partitioning
// ------------------------------------------
// Each node calculates only part of Psi[out] and stores only part of J+/J-. 
// What is called a square is a part of J+/- connecting the node i storing a part of |Psi[in]> to the node j storing a part of |Psi[out]>.
// An MPI communication of all newly calculated components on each row to the node taking care of the considered part of |Psi[out]> has to be done.
//
//
// Let us take 5 nodes. One then has 25 squares:
//
// 0 5 10 15 20
// 1 6 11 16 21
// 2 7 12 17 22
// 3 8 13 18 23
// 4 9 14 19 24
// 
// Nodes 0,1,2,3,4 store squares (0,1,2,3,4), (5,6,7,8,9), (10,11,12,13,14), (15,16,17,18,19), (20,21,22,23,24), respectively.
//
// For the construction of the J+/- matrix, loops are on in tables but output is on out tables to obtain the scheme above, so that OpenMP race conditions have to be avoided.
// OpenMP loops are then done on configurations indices as there is no configuration mixing induced by J+/-:
// iCp in one_jump_p_part_pn_calc_store as iCp_in = iCp_out = iCp so that the same outSD index cannot occur in different Cp's
// iCn in one_jump_n_part_pn_calc_store as iCn_in = iCn_out = iCn so that the same outSD index cannot occur in different Cn's
// iC in non_zero_NBMEs_numbers_pp_nn_calc as iC_in = iC_out = iC so that the same outSD index cannot occur in different C's
//
// Jpm_part_one_jump_store
// -----------------------------
// This provides with non-zero off-diagonal NBMEs for 1p-1h jumps from a proton/neutron out Slater determinant to an in proton/neutron Slater determinant.
// Jumps have already been calculated at this level, so that one just has to loop over jumps.
// The index of the in Slater determinant and the associated NBME are then stored and added to Jpm arrays.
// 
// one_jump_p_part_pn_calc_store, one_jump_n_part_pn_calc_store
// ------------------------------------------------------------
// This provides with non-zero off-diagonal NBMEs of 1p-1h type from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// These routines are used when one has both valence protons and neutrons.
// In these routines, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the indices of the in Slater determinant and the associated NBMEs from them.
//
// jumps_pp_nn_calc_store
// ----------------------
// This provides with the non-zero off-diagonal NBMEs for 1p-1h jumps from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// This routine is used when one has valence protons only or valence neutrons only.
// In this routine, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the number of non-zero NBMEs from them.
//
// matrix_store
// ------------
// This routine calls the previous routine and calculates and stores non-zero NBMEs for each row of Jpm for each node.
// 
// apply_add_full_storage_fixed_square, apply_add_full_storage
// -----------------------------------------------------------
// One applies here |Psi[out]> -> |Psi[out]> + Jpm.|Psi[in]> using arrays previously stored on a fixed square, and and loops over all squares.
//
//
// total means that one considers the index of the SD of the full GSM vector, not of part of it in a node (see GSM_vector_helper.cpp).


void Jpm_class::Jpm_part_one_jump_store (
					 const unsigned int PSI_in_index , 
					 const unsigned int dimension_one_jump ,
					 const class array<bool> &is_PSI_out_index_accepted_tab , 
					 const class array<unsigned int> &square_row_indices ,  
					 const class array<unsigned int> &PSI_out_indices ,
					 const class array<double> &NBMEs_one_jump)
{
  for (unsigned int i = 0 ; i < dimension_one_jump ; i++)
    {
      const bool is_PSI_out_index_accepted = is_PSI_out_index_accepted_tab(i);

      if (is_PSI_out_index_accepted)
	{
	  const unsigned int square_row_index = square_row_indices(i);

	  const unsigned int PSI_out_index = PSI_out_indices(i);

	  const double NBME_one_jump = NBMEs_one_jump(i);
	  
	  const unsigned int *const PSI_row_non_zero_indices = PSI_row_non_zero_indices_tables(square_row_index);
	  
	  const unsigned int PSI_out_non_zero_index = PSI_row_non_zero_indices[PSI_out_index];
	  
	  const unsigned int non_zero_NBMEs_index = squares_non_zero_NBMEs_numbers(square_row_index , PSI_out_index)++;
	  
	  class array<unsigned int *> &squares_non_zero_NBMEs_PSI_column_indices_table = squares_non_zero_NBMEs_PSI_column_indices_tables(square_row_index);

	  class array<double *> &squares_non_zero_NBMEs_table = squares_non_zero_NBMEs_tables(square_row_index);
	  
	  unsigned int *const squares_non_zero_NBMEs_PSI_column_indices = squares_non_zero_NBMEs_PSI_column_indices_table(PSI_out_non_zero_index);
	  
	  double *const squares_non_zero_NBMEs = squares_non_zero_NBMEs_table(PSI_out_non_zero_index);
	  
	  squares_non_zero_NBMEs_PSI_column_indices[non_zero_NBMEs_index] = PSI_in_index;
	  
	  squares_non_zero_NBMEs[non_zero_NBMEs_index] += NBME_one_jump;
	}
    }
}









void Jpm_class::one_jump_p_part_pn_calc_store ()
{
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
 
  const bool truncation_hw = GSM_vector_helper_in.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_in.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_in.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_in.get_neut_Y_data ();

  const int n_holes_max_p = GSM_vector_helper_in.get_n_holes_max_p ();
  
  const int n_scat_max_p = GSM_vector_helper_in.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_in.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper_in.get_Ep_max_hw ();

  const int iMp_max = prot_Y_data.get_iM_max ();

  const unsigned int BP = GSM_vector_helper_in.get_BP ();
  
  const int S = GSM_vector_helper_in.get_S ();

  const int n_spec_max = GSM_vector_helper_in.get_n_spec_max ();
  
  const int iMp_in_min_M = GSM_vector_helper_in.get_iMp_min_M ();
  const int iMp_in_max_M = GSM_vector_helper_in.get_iMp_max_M ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();

  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper_in.get_all_dimensions_SDn_zero_tab ();
  
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper_in.get_first_total_PSI_index_column ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper_in.get_last_total_PSI_index_column ();
  
  const unsigned int dimension_configuration_total_n = neut_Y_data.get_dimension_configuration_total ();

  const class array<unsigned int> &sum_dimensions_configuration_set_n = neut_Y_data.get_sum_dimensions_configuration_set ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();

  const class array<unsigned int> &iCp_min_tab = GSM_vector_helper_in.get_iCp_min_tab_column ();
  const class array<unsigned int> &iCp_max_tab = GSM_vector_helper_in.get_iCp_max_tab_column ();
  
  const class array<unsigned int> &iCn_min_tab = GSM_vector_helper_in.get_iCn_min_tab_column ();
  const class array<unsigned int> &iCn_max_tab = GSM_vector_helper_in.get_iCn_max_tab_column ();
  
  class array<class jumps_data_in_to_out_str> one_jump_p_tab(NUMBER_OF_THREADS);

  class array<class array_BP_S_Nspec_Nscat_iC<bool> > is_configuration_accepted_tabs(NUMBER_OF_THREADS);

  class array<class array_BP_S_Nspec_Nscat_iC<unsigned int> > dimensions_SDn_Mn_fixed_tab(NUMBER_OF_THREADS);

  class array<class array_BP_S_Nspec_Nscat_iC<unsigned int> > sum_dimensions_configuration_Mp_Mn_fixed_in_tabs(NUMBER_OF_THREADS);

  class array<class array<double> > NBMEs_one_jump_p_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_PSI_out_index_accepted_one_jump_p_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > square_row_indices_one_jump_p_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > PSI_out_indices_one_jump_p_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_p_tab(i).allocate (ONE_JUMP , truncation_hw , truncation_ph , ZYval);

      is_configuration_accepted_tabs(i).allocate (dimension_configuration_total_n , sum_dimensions_configuration_set_n);	      

      dimensions_SDn_Mn_fixed_tab(i).allocate (dimension_configuration_total_n , sum_dimensions_configuration_set_n);

      sum_dimensions_configuration_Mp_Mn_fixed_in_tabs(i).allocate (dimension_configuration_total_n , sum_dimensions_configuration_set_n);
      
      NBMEs_one_jump_p_tab(i).allocate (ZYval);

      is_PSI_out_index_accepted_one_jump_p_tabs(i).allocate (ZYval);	      

      square_row_indices_one_jump_p_tab(i).allocate (ZYval);      

      PSI_out_indices_one_jump_p_tab(i).allocate (ZYval);
    }
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP);

      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;
	  
	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p;
	      
	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int iCp_min = iCp_min_tab(BPp , Sp , n_spec_p , n_scat_p);
		  const unsigned int iCp_max = iCp_max_tab(BPp , Sp , n_spec_p , n_scat_p);

		  if (iCp_max < iCp_min) continue;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif    
		  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
		    {
		      const unsigned int i_thread = OpenMP_thread_number_determine ();
	      
		      class jumps_data_in_to_out_str &one_jump_p = one_jump_p_tab(i_thread);
	      
		      class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_accepted_tab = is_configuration_accepted_tabs(i_thread);
	      
		      class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_Mn_fixed = dimensions_SDn_Mn_fixed_tab(i_thread);

		      class array_BP_S_Nspec_Nscat_iC<unsigned int> &sum_dimensions_configuration_Mp_Mn_fixed_in_tab = sum_dimensions_configuration_Mp_Mn_fixed_in_tabs(i_thread);
	      
		      class array<double> &NBMEs_one_jump_p = NBMEs_one_jump_p_tab(i_thread);

		      class array<bool> &is_PSI_out_index_accepted_one_jump_p_tab = is_PSI_out_index_accepted_one_jump_p_tabs(i_thread);	      

		      class array<unsigned int> &square_row_indices_one_jump_p = square_row_indices_one_jump_p_tab(i_thread);

		      class array<unsigned int> &PSI_out_indices_one_jump_p = PSI_out_indices_one_jump_p_tab(i_thread);

		      bool is_configuration_accepted_tab_filled = false;
	      
		      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
			{
			  const int iMp_out = iMp_in + pm;

			  if ((iMp_out < 0) || (iMp_out > iMp_max)) continue;

			  const unsigned int dimension_inSDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp_in);

			  if (dimension_inSDp == 0) continue;

			  const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp_in);

			  if (all_dimensions_SDn_zero) continue;

			  const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
			  const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

			  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

			  if (!is_configuration_accepted_tab_filled)
			    {
			      is_configuration_accepted_n_fill (n_holes_p , n_scat_p , Ep_hw , BPn , Sn , n_spec_n , GSM_vector_helper_in , is_configuration_accepted_tab);
		      
			      is_configuration_accepted_tab_filled = true;
			    }

			  dimensions_SDn_sum_dimensions_configuration_Mp_Mn_fixed_n_fill (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp_in , GSM_vector_helper_in , is_configuration_accepted_tab ,
											       dimensions_SDn_Mn_fixed , sum_dimensions_configuration_Mp_Mn_fixed_in_tab);

			  for (unsigned int inSDp_index = 0 ; inSDp_index < dimension_inSDp ; inSDp_index++)
			    {
			      bool jump_p_calculated = false;

			      bool is_there_jump_calc_all = true;

			      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && is_there_jump_calc_all ; n_scat_n++)
				{
				  const unsigned int is_configuration_accepted_tab_BP_S_n_scat_n_zero_index = is_configuration_accepted_tab.index_determine (BPn , Sn , n_spec_n , n_scat_n , 0);
			  
				  const unsigned int dimensions_SDn_Mn_fixed_BP_S_n_scat_n_zero_index = dimensions_SDn_Mn_fixed.index_determine(BPn , Sn , n_spec_n , n_scat_n , 0);
			  
				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in_BP_S_n_scat_n_tab_zero_index = sum_dimensions_configuration_Mp_Mn_fixed_in_tab.index_determine(BPn , Sn , n_spec_n , n_scat_n , 0);

				  const unsigned int iCn_min = iCn_min_tab(BPn , Sn , n_spec_n , n_scat_n);
				  const unsigned int iCn_max = iCn_max_tab(BPn , Sn , n_spec_n , n_scat_n);
		  
				  for (unsigned int iCn = iCn_min ; (iCn <= iCn_max) && is_there_jump_calc_all ; iCn++)
				    { 
				      const unsigned int is_configuration_accepted_tab_index = is_configuration_accepted_tab_BP_S_n_scat_n_zero_index + iCn;

				      const bool is_configuration_accepted = is_configuration_accepted_tab[is_configuration_accepted_tab_index];

				      if (is_configuration_accepted)
					{
					  const unsigned int dimensions_SDn_Mn_fixed_index = dimensions_SDn_Mn_fixed_BP_S_n_scat_n_zero_index + iCn;

					  const unsigned int dimension_SDn = dimensions_SDn_Mn_fixed[dimensions_SDn_Mn_fixed_index];

					  if (dimension_SDn == 0) continue;

					  const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

					  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in_index = sum_dimensions_configuration_Mp_Mn_fixed_in_BP_S_n_scat_n_tab_zero_index + iCn;

					  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_configuration_Mp_Mn_fixed_in_tab[sum_dimensions_configuration_Mp_Mn_fixed_in_index];

					  const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_SDn*inSDp_index;
				  
					  const unsigned long int total_PSI_in_index_dimension_minus_one = total_PSI_in_index_zero + dimension_SDn_minus_one;
				  
					  if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
					    {
					      for (unsigned int SDn_index = 0 ; (SDn_index < dimension_SDn) && is_there_jump_calc_all ; SDn_index++)
						{
						  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero + SDn_index;

						  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						    {
						      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;

						      if (!jump_p_calculated)
							{
							  one_jump_p.one_jump_mu_Jpm_store (pm , BPp , Sp , n_spec_p , n_scat_p , iCp , iMp_in , inSDp_index , prot_Y_data);

							  NBMEs_one_jump_mu_calc_one_body_operator_Jpm (Jpm_OBMEs_p_tab , one_jump_p , NBMEs_one_jump_p);
						  
							  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();

							  is_there_jump_calc_all = (dimension_one_jump_p > 0);

							  jump_p_calculated = true;
							}
					      
						      if (is_there_jump_calc_all)
							{
							  bool is_there_jump_calc = false;
						  
							  are_PSI_out_indices_accepted_PSI_out_indices_p_fill_Jpm (n_scat_n , iCn , SDn_index , BPp , Sp , n_spec_p , n_scat_p , iCp , iMp_out , one_jump_p ,
														   GSM_vector_helper_out , dimension_SDn , is_PSI_out_index_accepted_one_jump_p_tab ,
														   square_row_indices_one_jump_p , PSI_out_indices_one_jump_p , is_there_jump_calc);

							  if (is_there_jump_calc)
							    {
							      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
							
							      Jpm_part_one_jump_store (PSI_in_index , dimension_one_jump_p , is_PSI_out_index_accepted_one_jump_p_tab ,
										       square_row_indices_one_jump_p , PSI_out_indices_one_jump_p , NBMEs_one_jump_p);
							    }}}}}}}}}}}}}}}
}








void Jpm_class::one_jump_n_part_pn_calc_store ()
{   
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  const bool truncation_hw = GSM_vector_helper_in.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_in.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_in.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_in.get_neut_Y_data ();

  const int n_holes_max_n = GSM_vector_helper_in.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_in.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_in.get_n_scat_max_n ();

  const int En_max_hw = GSM_vector_helper_in.get_En_max_hw ();

  const int iMn_max = neut_Y_data.get_iM_max ();

  const unsigned int BP = GSM_vector_helper_in.get_BP ();
  
  const int S = GSM_vector_helper_in.get_S ();

  const int n_spec_max = GSM_vector_helper_in.get_n_spec_max ();

  const int iM_in = GSM_vector_helper_in.get_iM ();

  const int iMn_in_min_M = GSM_vector_helper_in.get_iMn_min_M ();
  const int iMn_in_max_M = GSM_vector_helper_in.get_iMn_max_M ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper_in.get_all_dimensions_SDp_zero_tab ();

  const unsigned int dimension_configuration_total_p = prot_Y_data.get_dimension_configuration_total ();

  const class array<unsigned int> &sum_dimensions_configuration_set_p = prot_Y_data.get_sum_dimensions_configuration_set ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();  
  
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper_in.get_first_total_PSI_index_column ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper_in.get_last_total_PSI_index_column ();

  const class array<unsigned int> &iCp_min_tab = GSM_vector_helper_in.get_iCp_min_tab_column ();
  const class array<unsigned int> &iCp_max_tab = GSM_vector_helper_in.get_iCp_max_tab_column ();
  
  const class array<unsigned int> &iCn_min_tab = GSM_vector_helper_in.get_iCn_min_tab_column ();
  const class array<unsigned int> &iCn_max_tab = GSM_vector_helper_in.get_iCn_max_tab_column ();

  class array<class jumps_data_in_to_out_str> one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array_BP_S_Nspec_Nscat_iC<bool> > is_configuration_accepted_tabs(NUMBER_OF_THREADS);

  class array<class array_BP_S_Nspec_Nscat_iC<unsigned int> > dimensions_SDp_Mp_fixed_tab(NUMBER_OF_THREADS);

  class array<class array_BP_S_Nspec_Nscat_iC<unsigned int> > sum_dimensions_configuration_Mp_Mn_fixed_in_tabs(NUMBER_OF_THREADS);

  class array<class array<double> > NBMEs_one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_PSI_out_index_accepted_one_jump_n_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > square_row_indices_one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > PSI_out_indices_one_jump_n_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_n_tab(i).allocate (ONE_JUMP , truncation_hw , truncation_ph , NYval);

      is_configuration_accepted_tabs(i).allocate (dimension_configuration_total_p , sum_dimensions_configuration_set_p);	      

      dimensions_SDp_Mp_fixed_tab(i).allocate (dimension_configuration_total_p , sum_dimensions_configuration_set_p);

      sum_dimensions_configuration_Mp_Mn_fixed_in_tabs(i).allocate (dimension_configuration_total_p , sum_dimensions_configuration_set_p);
      
      NBMEs_one_jump_n_tab(i).allocate (NYval);

      is_PSI_out_index_accepted_one_jump_n_tabs(i).allocate (NYval);	      

      square_row_indices_one_jump_n_tab(i).allocate (NYval);      

      PSI_out_indices_one_jump_n_tab(i).allocate (NYval);
    }
  
  for (unsigned int BPn = 0 ; BPn <= 1 ; BPn++)
    {
      const unsigned int BPp = binary_parity_product (BPn , BP);

      for (int Sn = 0 ; Sn <= S ; Sn++)
	{
	  const int Sp = S - Sn;
	  
	  for (int n_spec_n = 0 ; n_spec_n <= n_spec_max ; n_spec_n++)
	    {
	      const int n_spec_p = n_spec_max - n_spec_n;
	      
	      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
		{
		  const unsigned int iCn_min = iCn_min_tab(BPn , Sn , n_spec_n , n_scat_n);
		  const unsigned int iCn_max = iCn_max_tab(BPn , Sn , n_spec_n , n_scat_n);

		  if (iCn_max < iCn_min) continue;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
		  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
		    {
		      const unsigned int i_thread = OpenMP_thread_number_determine ();
	      
		      class jumps_data_in_to_out_str &one_jump_n = one_jump_n_tab(i_thread);
	      
		      class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_accepted_tab = is_configuration_accepted_tabs(i_thread);
	      
		      class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_Mp_fixed = dimensions_SDp_Mp_fixed_tab(i_thread);

		      class array_BP_S_Nspec_Nscat_iC<unsigned int> &sum_dimensions_configuration_Mp_Mn_fixed_in_tab = sum_dimensions_configuration_Mp_Mn_fixed_in_tabs(i_thread);
	      
		      class array<double> &NBMEs_one_jump_n = NBMEs_one_jump_n_tab(i_thread);

		      class array<bool> &is_PSI_out_index_accepted_one_jump_n_tab = is_PSI_out_index_accepted_one_jump_n_tabs(i_thread);	      

		      class array<unsigned int> &square_row_indices_one_jump_n = square_row_indices_one_jump_n_tab(i_thread);

		      class array<unsigned int> &PSI_out_indices_one_jump_n = PSI_out_indices_one_jump_n_tab(i_thread);
	      
		      bool is_configuration_accepted_tab_filled = false; 

		      for (int iMn_in = iMn_in_min_M ; iMn_in <= iMn_in_max_M ; iMn_in++)
			{
			  const int iMn_out = iMn_in + pm;

			  const int iMp = iM_in - iMn_in;

			  if ((iMn_out < 0) || (iMn_out > iMn_max)) continue;

			  const unsigned int dimension_inSDn  = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn_in);
			  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn_out);

			  if ((dimension_inSDn == 0) || (dimension_outSDn == 0)) continue;

			  const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn_in);

			  if (all_dimensions_SDp_zero) continue;

			  const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
			  const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

			  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

			  if (!is_configuration_accepted_tab_filled)
			    {
			      is_configuration_accepted_p_fill (n_holes_n , n_scat_n , En_hw , BPp , Sp , n_spec_p , GSM_vector_helper_in , is_configuration_accepted_tab);
		      
			      is_configuration_accepted_tab_filled = true;
			    }

			  dimensions_SDp_sum_dimensions_configuration_Mp_Mn_fixed_p_fill (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn_in , GSM_vector_helper_in , is_configuration_accepted_tab ,
											       dimensions_SDp_Mp_fixed , sum_dimensions_configuration_Mp_Mn_fixed_in_tab);

			  for (unsigned int inSDn_index = 0 ; inSDn_index < dimension_inSDn ; inSDn_index++)
			    {
			      bool jump_n_calculated = false;

			      bool is_there_jump_calc_all = true;

			      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && is_there_jump_calc_all ; n_scat_p++)
				{
				  const unsigned int is_configuration_accepted_tab_BP_S_n_scat_p_zero_index = is_configuration_accepted_tab.index_determine (BPp , Sp , n_spec_p , n_scat_p , 0);

				  const unsigned int dimensions_SDp_Mp_fixed_BP_S_n_scat_p_zero_index = dimensions_SDp_Mp_fixed.index_determine(BPp , Sp , n_spec_p , n_scat_p , 0);

				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in_BP_S_n_scat_p_tab_zero_index = sum_dimensions_configuration_Mp_Mn_fixed_in_tab.index_determine(BPp , Sp , n_spec_p , n_scat_p , 0);

				  const unsigned int iCp_min = iCp_min_tab(BPp , Sp , n_spec_p , n_scat_p);
				  const unsigned int iCp_max = iCp_max_tab(BPp , Sp , n_spec_p , n_scat_p);
	  
				  for (unsigned int iCp = iCp_min ; (iCp <= iCp_max) && is_there_jump_calc_all ; iCp++)
				    {
				      const unsigned int is_configuration_accepted_tab_index = is_configuration_accepted_tab_BP_S_n_scat_p_zero_index + iCp;

				      const bool is_configuration_accepted = is_configuration_accepted_tab[is_configuration_accepted_tab_index];

				      if (is_configuration_accepted)
					{
					  const unsigned int dimensions_SDp_Mp_fixed_index = dimensions_SDp_Mp_fixed_BP_S_n_scat_p_zero_index + iCp;

					  const unsigned int dimension_SDp = dimensions_SDp_Mp_fixed[dimensions_SDp_Mp_fixed_index];

					  if (dimension_SDp == 0) continue;

					  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in_index = sum_dimensions_configuration_Mp_Mn_fixed_in_BP_S_n_scat_p_tab_zero_index + iCp;

					  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_configuration_Mp_Mn_fixed_in_tab[sum_dimensions_configuration_Mp_Mn_fixed_in_index];

					  const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

					  const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;

					  const unsigned long int total_PSI_in_index_dimension_minus_one = total_PSI_in_index_zero + dimension_inSDn*dimension_SDp_minus_one;

					  if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
					    {
					      for (unsigned int SDp_index = 0 ; (SDp_index < dimension_SDp) && is_there_jump_calc_all ; SDp_index++)
						{
						  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero + dimension_inSDn*SDp_index;

						  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						    {
						      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;

						      if (!jump_n_calculated)
							{
							  one_jump_n.one_jump_mu_Jpm_store (pm , BPn , Sn , n_spec_n , n_scat_n , iCn , iMn_in , inSDn_index , neut_Y_data);

							  NBMEs_one_jump_mu_calc_one_body_operator_Jpm (Jpm_OBMEs_n_tab , one_jump_n , NBMEs_one_jump_n);
						  
							  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

							  is_there_jump_calc_all = (dimension_one_jump_n > 0);

							  jump_n_calculated = true;
							}
					      
						      if (is_there_jump_calc_all)
							{
							  bool is_there_jump_calc = false;
						  
							  are_PSI_out_indices_accepted_PSI_out_indices_n_fill_Jpm (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index , n_scat_n , iCn , one_jump_n ,
														   GSM_vector_helper_out , dimension_outSDn , is_PSI_out_index_accepted_one_jump_n_tab ,
														   square_row_indices_one_jump_n , PSI_out_indices_one_jump_n , is_there_jump_calc);

							  if (is_there_jump_calc)
							    {
							      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
						      
							      Jpm_part_one_jump_store (PSI_in_index , dimension_one_jump_n , is_PSI_out_index_accepted_one_jump_n_tab ,
										       square_row_indices_one_jump_n , PSI_out_indices_one_jump_n , NBMEs_one_jump_n);
							    }}}}}}}}}}}}}}}
}










void Jpm_class::jumps_part_pp_nn_calc_store ()
{
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  const enum space_type space = GSM_vector_helper_in.get_space ();

  const bool truncation_hw = GSM_vector_helper_in.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_in.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_in.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_in.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper_in.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_in.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_in.get_E_max_hw ();

  const unsigned int BP = GSM_vector_helper_in.get_BP (); 
  
  const int S = GSM_vector_helper_in.get_S ();

  const int iM_in = GSM_vector_helper_in.get_iM ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_in = GSM_vector_helper_in.get_sum_dimensions_GSM_vector ();

  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();
  
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper_in.get_first_total_PSI_index_column ();

  const unsigned long int last_total_PSI_in_index = GSM_vector_helper_in.get_last_total_PSI_index_column ();
  
  const class array<unsigned int> &iC_min_tab = GSM_vector_helper_in.get_iC_min_tab_column ();
  const class array<unsigned int> &iC_max_tab = GSM_vector_helper_in.get_iC_max_tab_column ();

  const class array<double> &Jpm_mu_tab = (space == PROT_Y_ONLY) ? (Jpm_OBMEs_p_tab) : (Jpm_OBMEs_n_tab);
  
  class array<class jumps_data_in_to_out_str> one_jump_mu_tab(NUMBER_OF_THREADS);

  class array<class array<double> > NBMEs_one_jump_mu_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_PSI_out_index_accepted_one_jump_mu_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > square_row_indices_one_jump_mu_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > PSI_out_indices_one_jump_mu_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_mu_tab(i).allocate (ONE_JUMP , truncation_hw , truncation_ph , N_valence_baryons);
      
      NBMEs_one_jump_mu_tab(i).allocate (N_valence_baryons);

      is_PSI_out_index_accepted_one_jump_mu_tabs(i).allocate (N_valence_baryons);

      square_row_indices_one_jump_mu_tab(i).allocate (N_valence_baryons);

      PSI_out_indices_one_jump_mu_tab(i).allocate (N_valence_baryons);
    }
  
  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int iC_min = iC_min_tab(n_scat);
      const unsigned int iC_max = iC_max_tab(n_scat);

      if (iC_max < iC_min) continue;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
      for (unsigned int iC = iC_min ; iC <= iC_max ; iC++)
	{
	  const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);

	  const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned long int sum_dimensions_configuration_fixed_in = sum_dimensions_in(n_scat , iC);

	  const unsigned int dimension_inSD_set = dimensions_SD_set(BP , S , 0 , n_scat , iC , iM_in);

	  if (dimension_inSD_set == 0) continue;

	  const unsigned int dimension_inSD_set_minus_one = dimension_inSD_set - 1;

	  const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_fixed_in;

	  const unsigned long int total_PSI_in_index_dimension_minus_one = total_PSI_in_index_zero + dimension_inSD_set_minus_one;
	  
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	      
	  class jumps_data_in_to_out_str &one_jump_mu = one_jump_mu_tab(i_thread);
	      	      
	  class array<double> &NBMEs_one_jump_mu = NBMEs_one_jump_mu_tab(i_thread);

	  class array<bool> &is_PSI_out_index_accepted_one_jump_mu_tab = is_PSI_out_index_accepted_one_jump_mu_tabs(i_thread);	      

	  class array<unsigned int> &square_row_indices_one_jump_mu = square_row_indices_one_jump_mu_tab(i_thread);

	  class array<unsigned int> &PSI_out_indices_one_jump_mu = PSI_out_indices_one_jump_mu_tab(i_thread);
	      
	  if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
	    {
	      for (unsigned int inSD_index = 0 ; inSD_index < dimension_inSD_set ; inSD_index++)
		{
		  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero + inSD_index;

		  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
		    {
		      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;

		      one_jump_mu.one_jump_mu_Jpm_store (pm , BP , S , 0 , n_scat , iC , iM_in , inSD_index , data);

		      NBMEs_one_jump_mu_calc_one_body_operator_Jpm (Jpm_mu_tab , one_jump_mu , NBMEs_one_jump_mu);
						  
		      const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();
		      
		      bool is_there_jump_calc = (dimension_one_jump_mu > 0);

		      if (is_there_jump_calc)
			{
			  are_PSI_out_indices_accepted_PSI_out_indices_pp_nn_fill_Jpm (n_scat , iC , one_jump_mu , GSM_vector_helper_out ,
										       is_PSI_out_index_accepted_one_jump_mu_tab , square_row_indices_one_jump_mu , PSI_out_indices_one_jump_mu , is_there_jump_calc);
			  
			  if (is_there_jump_calc)
			    Jpm_part_one_jump_store (PSI_in_index , dimension_one_jump_mu , is_PSI_out_index_accepted_one_jump_mu_tab , square_row_indices_one_jump_mu , PSI_out_indices_one_jump_mu , NBMEs_one_jump_mu);
			}}}}}}
}









void Jpm_class::matrix_store ()
{
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_out.get_is_it_MPI_parallelized_local ();

  const unsigned int N = (is_it_MPI_parallelized_local) ? (NUMBER_OF_PROCESSES) : (1);
       
  const enum space_type space = GSM_vector_helper_out.get_space ();

  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
    {
      const unsigned int space_dimension_non_zero = space_dimensions_non_zero(square_row_index);

      const unsigned int *const PSI_row_indices_non_zero = PSI_row_indices_non_zero_tables(square_row_index);
      
      for (unsigned int PSI_out_non_zero_index = 0 ; PSI_out_non_zero_index < space_dimension_non_zero ; PSI_out_non_zero_index++)
	{
	  const unsigned int PSI_out_index = PSI_row_indices_non_zero[PSI_out_non_zero_index];
		  
	  const unsigned int squares_non_zero_NBMEs_number = squares_non_zero_NBMEs_numbers(square_row_index , PSI_out_index);
		
	  class array<unsigned int *> &squares_non_zero_NBMEs_PSI_column_indices_table = squares_non_zero_NBMEs_PSI_column_indices_tables(square_row_index);

	  class array<double *> &squares_non_zero_NBMEs_table = squares_non_zero_NBMEs_tables(square_row_index);
	  
	  unsigned int *const squares_non_zero_NBMEs_PSI_column_indices = squares_non_zero_NBMEs_PSI_column_indices_table(PSI_out_non_zero_index);

	  double *const squares_non_zero_NBMEs = squares_non_zero_NBMEs_table(PSI_out_non_zero_index);

	  for (unsigned int i = 0 ; i < squares_non_zero_NBMEs_number ; i++)
	    {
	      squares_non_zero_NBMEs_PSI_column_indices[i] = space_dimension_non_zero;
	      
	      squares_non_zero_NBMEs[i] = 0.0;
	    }
	}
    }
  
  squares_non_zero_NBMEs_numbers = 0;
   
  if (space == PROT_NEUT_Y)
    {
      one_jump_p_part_pn_calc_store ();
      one_jump_n_part_pn_calc_store ();
    }
  else
    jumps_part_pp_nn_calc_store ();
}



#ifdef UseMPI

void Jpm_class::Jpm_PSI_in_part_non_zero_components_transfer_add (
								  const unsigned int i_Recv ,
								  class GSM_vector &Jpm_PSI_in_part) const
{
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  const unsigned int space_dimensions_all_processes_max = GSM_vector_helper_out.get_space_dimensions_all_processes_max ();

  const bool is_it_process_Recv = (i_Recv == THIS_PROCESS);
	      
  for (unsigned int i_Send = 0 ; i_Send < NUMBER_OF_PROCESSES ; i_Send++)
    {
      if (i_Send != i_Recv)
	{
	  const bool is_it_process_Send = (i_Send == THIS_PROCESS);
	    
	  if (is_it_process_Send || is_it_process_Recv)
	    {
	      const unsigned int tag = i_Recv + NUMBER_OF_PROCESSES*i_Send;

	      const unsigned int non_zeros_number_tag = 2*tag;

	      const unsigned int non_zeros_tag = 2*tag + 1;

	      unsigned int Jpm_PSI_in_part_non_zeros_number = 0;

	      if (is_it_process_Send)
		{
		  for (unsigned int Jpm_PSI_in_index = 0 ; Jpm_PSI_in_index < space_dimensions_all_processes_max ; Jpm_PSI_in_index++)
		    {
		      if (inf_norm (Jpm_PSI_in_part[Jpm_PSI_in_index]) > 1E-15) Jpm_PSI_in_part_non_zeros_number++;
		    }
		  
		  MPI_helper::Send (Jpm_PSI_in_part_non_zeros_number , i_Recv , non_zeros_number_tag , MPI_COMM_WORLD);		 
		}
			
	      if (is_it_process_Recv) MPI_helper::Recv (Jpm_PSI_in_part_non_zeros_number , i_Send , non_zeros_number_tag , MPI_COMM_WORLD);
			
	      if (Jpm_PSI_in_part_non_zeros_number > 0)
		{
		  class array<unsigned int> Jpm_PSI_in_part_non_zeros_indices(Jpm_PSI_in_part_non_zeros_number);
		  
		  class array<TYPE> Jpm_PSI_in_part_non_zeros(Jpm_PSI_in_part_non_zeros_number);
		  
		  if (is_it_process_Send)
		    {
		      unsigned int Jpm_PSI_in_part_non_zeros_index = 0;
		      
		      for (unsigned int Jpm_PSI_in_index = 0 ; Jpm_PSI_in_index < space_dimensions_all_processes_max ; Jpm_PSI_in_index++)
			{
			  const TYPE Jpm_PSI_in_part_component = Jpm_PSI_in_part[Jpm_PSI_in_index];

			  if (inf_norm (Jpm_PSI_in_part_component) > 1E-15)
			    {
			      Jpm_PSI_in_part_non_zeros_indices(Jpm_PSI_in_part_non_zeros_index) = Jpm_PSI_in_index;
			      
			      Jpm_PSI_in_part_non_zeros(Jpm_PSI_in_part_non_zeros_index) = Jpm_PSI_in_part_component;
			      
			      Jpm_PSI_in_part_non_zeros_index++;
			    }
			}
				 
		      Jpm_PSI_in_part_non_zeros_indices.MPI_Send (i_Recv , non_zeros_tag , MPI_COMM_WORLD);
		      
		      Jpm_PSI_in_part_non_zeros.MPI_Send (i_Recv , non_zeros_tag , MPI_COMM_WORLD);
		    }
		  		  
		  if (is_it_process_Recv)
		    {
		      Jpm_PSI_in_part_non_zeros_indices.MPI_Recv (i_Send , non_zeros_tag , MPI_COMM_WORLD);
		      
		      Jpm_PSI_in_part_non_zeros.MPI_Recv (i_Send , non_zeros_tag , MPI_COMM_WORLD);
		      
		      for (unsigned int i = 0 ; i < Jpm_PSI_in_part_non_zeros_number ; i++)
			{
			  const unsigned int Jpm_PSI_in_part_non_zero_index = Jpm_PSI_in_part_non_zeros_indices(i);
			  
			  const TYPE Jpm_PSI_in_part_non_zero = Jpm_PSI_in_part_non_zeros(i);
			  
			  Jpm_PSI_in_part[Jpm_PSI_in_part_non_zero_index] += Jpm_PSI_in_part_non_zero;
			}
		    }
		}
	    }
	}
    }
}

#endif









void Jpm_class::apply_add_full_storage_fixed_square (
						     const unsigned int square_row_index ,
						     const class GSM_vector &PSI_in) const
{   
  const unsigned int space_dimension_non_zero = space_dimensions_non_zero(square_row_index);
  
  const bool is_it_even = (square_row_index%2 == 0);
  	 
  const class array<unsigned int *> &squares_non_zero_NBMEs_PSI_column_indices_table = squares_non_zero_NBMEs_PSI_column_indices_tables(square_row_index);
  
  const class array<double *> &squares_non_zero_NBMEs_table = squares_non_zero_NBMEs_tables(square_row_index);
	  
  const unsigned int *const PSI_row_indices_non_zero = PSI_row_indices_non_zero_tables(square_row_index);
	  
  class GSM_vector &Jpm_PSI_in_even = get_Jpm_PSI_in_0 ();
  class GSM_vector &Jpm_PSI_in_odd  = get_Jpm_PSI_in_1 ();

  class GSM_vector &Jpm_PSI_in = (is_it_even) ? (Jpm_PSI_in_even) : (Jpm_PSI_in_odd);
  
  Jpm_PSI_in.zero ();
  
  double Jpm_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel default(shared) reduction(+:Jpm_multiplications_number_local) if (is_it_OpenMP_parallelized)
#endif
  {
    
#ifdef UseMPI
     
    const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();

    const bool is_it_MPI_parallelized_local = GSM_vector_helper_out.get_is_it_MPI_parallelized_local ();

    if (is_it_MPI_parallelized_local && (square_row_index > 0))
      {
	const unsigned int i_thread = OpenMP_thread_number_determine ();
	    	  
	if (i_thread == MASTER_THREAD)
	  {	    
	    const unsigned int previous_square_row_index = square_row_index - 1;
	    
	    class GSM_vector &Jpm_PSI_in_previous = (is_it_even) ? (Jpm_PSI_in_odd)  : (Jpm_PSI_in_even);

	    const double reference_time = absolute_time_determine ();
	    
	    Jpm_PSI_in_part_non_zero_components_transfer_add (previous_square_row_index , Jpm_PSI_in_previous);
	    
	    const double MPI_communication_absolute_time = absolute_time_determine ();
	    
	    Jpm_MPI_communication_time += MPI_communication_absolute_time - reference_time;
	  }
      }
    
#endif
    
  
#ifdef UseOpenMP
#pragma omp for schedule (dynamic)
#endif
    for (unsigned int PSI_out_non_zero_index = 0 ; PSI_out_non_zero_index < space_dimension_non_zero ; PSI_out_non_zero_index++)
      {
	const unsigned int PSI_out_index = PSI_row_indices_non_zero[PSI_out_non_zero_index];

	const unsigned int square_non_zero_NBMEs_number = squares_non_zero_NBMEs_numbers(square_row_index , PSI_out_index);
	
	const unsigned int *const squares_non_zero_NBMEs_PSI_column_indices = squares_non_zero_NBMEs_PSI_column_indices_table(PSI_out_non_zero_index);
	
	const double *const squares_non_zero_NBMEs = squares_non_zero_NBMEs_table(PSI_out_non_zero_index);

	TYPE component_part = 0.0;
      
	for (unsigned int i = 0 ; i < square_non_zero_NBMEs_number ; i++) 
	  {
	    const unsigned int PSI_in_index = squares_non_zero_NBMEs_PSI_column_indices[i];

	    const TYPE &PSI_in_component = PSI_in[PSI_in_index];
	    
	    const double &NBME = squares_non_zero_NBMEs[i];
	      
	    component_part += NBME*PSI_in_component;
	  }
	  
	Jpm_PSI_in[PSI_out_index] += component_part;
	
	Jpm_multiplications_number_local += square_non_zero_NBMEs_number;
      }
  }
  
  Jpm_multiplications_number += Jpm_multiplications_number_local;
}











void Jpm_class::apply_add_full_storage (
					const class GSM_vector &PSI_in ,
					class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_out.get_is_it_MPI_parallelized_local ();

  const unsigned int N = (is_it_MPI_parallelized_local) ? (NUMBER_OF_PROCESSES) : (1);

  const unsigned int last_square_row_index = N - 1;
    
  class GSM_vector &Jpm_PSI_in_even = get_Jpm_PSI_in_0 ();
  class GSM_vector &Jpm_PSI_in_odd  = get_Jpm_PSI_in_1 ();
    
  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
    {
      const bool is_it_even = (square_row_index%2 == 0);
  
      const unsigned int previous_square_row_index = (square_row_index > 0) ? (square_row_index - 1) : (NADA);

      class GSM_vector &Jpm_PSI_in_previous = (is_it_even) ? (Jpm_PSI_in_odd)  : (Jpm_PSI_in_even);
      class GSM_vector &Jpm_PSI_in          = (is_it_even) ? (Jpm_PSI_in_even) : (Jpm_PSI_in_odd);
  
      apply_add_full_storage_fixed_square (square_row_index , PSI_in);

      if ((square_row_index > 0) && (THIS_PROCESS == previous_square_row_index)) PSI_out += Jpm_PSI_in_previous;
      
      if (square_row_index == last_square_row_index)
	{
	  
#ifdef UseMPI
	  
	  if (is_it_MPI_parallelized_local) Jpm_PSI_in_part_non_zero_components_transfer_add (last_square_row_index , Jpm_PSI_in);

#endif
	  
	  if (!is_it_MPI_parallelized_local || (THIS_PROCESS == last_square_row_index)) PSI_out += Jpm_PSI_in;
	}
    }
}



