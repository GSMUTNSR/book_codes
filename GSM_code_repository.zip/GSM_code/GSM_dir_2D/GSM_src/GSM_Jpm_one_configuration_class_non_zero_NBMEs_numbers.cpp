#include "../GSM_include/GSM_include_def.h"

using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;


// TYPE is double or complex
// -------------------------

// Calculation of the number of non-zero NBMEs of Jpm when only one configuration is occupied in basis space for MSDHF calculations
// --------------------------------------------------------------------------------------------------------------------------------
// In order to calculate the MSDHF potential, one has to diagonalize H on the MSDHF configuration, as its ground state is used in the HF-like formulas defining the MSDHF potential.
// The J^2 operator when only one configuration is occupied is also used, to check if GSM vectors are coupled to J and to project them on good J.
// As only one configuration occurs, it is much more efficient to recode J^2 in this particular case, than to use the full J^2 class of the general case.
//
// Jpm means J+ or J-, as pm = +/1. One uses Jpm for J+ or J- in all Jpm classes files.
// One uses Jpm in J^2 = J-.J+ + Jz.(Jz + 1).
//
// One calculates the number of non-zero NBMEs per Jpm row.
//
// One loops over proton and neutron Slater determinants, the first loop being proton or neutron according to the case.
//
// non_zero_NBMEs_numbers_one_jump_p_part_pn_calc, non_zero_NBMEs_numbers_one_jump_n_part_pn_calc
// ----------------------------------------------------------------------------------------------
// This provides with the number of non-zero off-diagonal NBMEs for 1p-1h jumps from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// These routines are used when one has both valence protons and neutrons.
// In these routines, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the number of non-zero NBMEs from them.
//
// non_zero_NBMEs_numbers_pp_nn_calc
// ---------------------------------
// This provides with the number of non-zero off-diagonal NBMEs for 1p-1h jumps from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// This routine is used when one has valence protons only or valence neutrons only.
// In this routine, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the number of non-zero NBMEs from them.
//
// rows_non_zero_NBMEs_numbers_calc
// --------------------------------
// This routine calls the previous routine and calculates the number of non-zero NBMEs for each row of Jpm for each node (MPI only).

void Jpm_one_configuration_class::non_zero_NBMEs_numbers_one_jump_p_part_pn_calc ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper_out.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();
  
  const unsigned int iM = GSM_vector_helper_out.get_iM ();
  
  const int iMp_max = prot_Y_data.get_iM_max (); 
  const int iMp_min_M = GSM_vector_helper_out.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper_out.get_iMp_max_M ();
  
  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const unsigned int BPp = prot_Y_data.get_BP_one_configuration ();
  const unsigned int BPn = neut_Y_data.get_BP_one_configuration ();
  
  const unsigned int iCp = prot_Y_data.get_iC_one_configuration ();
  const unsigned int iCn = neut_Y_data.get_iC_one_configuration ();
     
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  class jumps_data_out_to_in_str one_jump_p(ONE_JUMP_ONE_CONFIGURATION , PROT_NEUT_Y , true , true , ZYval);
      
  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
    {
      const int iMp_mp_one = iMp - pm , iMn = iM - iMp;
      
      if ((iMp_mp_one < 0) || (iMp_mp_one > iMp_max)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , 0 , 0 , 0 , iCp , iMp);
      
      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , 0 , 0 , 0 , iCn , iMn);

      if ((dimension_outSDp == 0) || (dimension_SDn == 0)) continue;

      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_out(iMp);

      for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
	{
	  one_jump_p.one_jump_mu_Jpm_store (pm , BPp , 0 , 0 , 0 , iCp , iMp , outSDp_index , prot_Y_data);

	  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();

	  if (dimension_one_jump_p == 0) continue;

	  const unsigned int PSI_zero_index_outSDp = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_SDn*outSDp_index;
	      
	  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
	    {
	      const unsigned int PSI_index = PSI_zero_index_outSDp + SDn_index;

	      rows_non_zero_NBMEs_numbers(PSI_index) += dimension_one_jump_p;
	    }
	}
    }
}




void Jpm_one_configuration_class::non_zero_NBMEs_numbers_one_jump_n_part_pn_calc ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_out.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();
  
  const unsigned int iM = GSM_vector_helper_out.get_iM ();
  
  const int iMn_max = neut_Y_data.get_iM_max (); 

  const int iMn_min_M = GSM_vector_helper_out.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper_out.get_iMn_max_M ();
  
  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const unsigned int BPp = prot_Y_data.get_BP_one_configuration (); 
  const unsigned int BPn = neut_Y_data.get_BP_one_configuration ();
  
  const unsigned int iCp = prot_Y_data.get_iC_one_configuration (); 
  const unsigned int iCn = neut_Y_data.get_iC_one_configuration ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  class jumps_data_out_to_in_str one_jump_n(ONE_JUMP_ONE_CONFIGURATION , PROT_NEUT_Y , true , true , NYval);
      
  for (int iMn = iMn_min_M ; iMn <= iMn_max_M ; iMn++)
    {
      const int iMn_mp_one = iMn - pm;

      const int iMp = iM - iMn;

      if ((iMn_mp_one < 0) || (iMn_mp_one > iMn_max)) continue;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , 0 , 0 , 0 , iCp , iMp);

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , 0 , 0 , 0 , iCn , iMn);

      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn , 0 , 0 , 0 , iCn , iMn_mp_one);
      
      if ((dimension_SDp == 0) || (dimension_outSDn == 0) || (dimension_inSDn == 0)) continue;

      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_out(iMp);

      for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
	{
	  one_jump_n.one_jump_mu_Jpm_store (pm , BPn , 0 , 0 , 0 , iCn , iMn , outSDn_index , neut_Y_data);

	  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

	  if (dimension_one_jump_n == 0) continue;

	  const unsigned int PSI_zero_index_outSDn = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
	      
	  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
	    {
	      const unsigned int PSI_index = PSI_zero_index_outSDn + dimension_outSDn*SDp_index;

	      rows_non_zero_NBMEs_numbers(PSI_index) += dimension_one_jump_n;
	    }
	}
    }
}




void Jpm_one_configuration_class::non_zero_NBMEs_numbers_pp_nn_calc ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();

  const enum space_type space = GSM_vector_helper_out.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_out.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();
  
  const int iM = GSM_vector_helper_out.get_iM ();
  
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);
  
  const int N_valence_baryons = data.get_N_valence_baryons ();

  const unsigned int BP = data.get_BP_one_configuration ();
  const unsigned int iC = data.get_iC_one_configuration ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const unsigned int dimension_SD_set = dimensions_SD_set(BP , 0 , 0 , 0 , iC , iM);

  for (unsigned int outSD_index = 0 ; outSD_index < dimension_SD_set ; outSD_index++)
    {
      class jumps_data_out_to_in_str one_jump_mu(ONE_JUMP_ONE_CONFIGURATION , space , true , true , N_valence_baryons);

      one_jump_mu.one_jump_mu_Jpm_store (pm , BP , 0 , 0 , 0 , iC , iM , outSD_index , data);

      const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();

      rows_non_zero_NBMEs_numbers(outSD_index) += dimension_one_jump_mu;
    }
}




void Jpm_one_configuration_class::rows_non_zero_NBMEs_numbers_calc ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();

  const enum space_type space = GSM_vector_helper_out.get_space ();
  
  rows_non_zero_NBMEs_numbers = 0;
    
  if (space == PROT_NEUT_Y)
    {
      non_zero_NBMEs_numbers_one_jump_p_part_pn_calc ();
      non_zero_NBMEs_numbers_one_jump_n_part_pn_calc ();
    }
  else
    non_zero_NBMEs_numbers_pp_nn_calc ();
}





