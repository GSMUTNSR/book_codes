#include "../GSM_include/GSM_include_def.h"

using namespace string_routines;



// TYPE is double or complex
// -------------------------

// Implementation of the Lanczos method when only one configuration is occupied in basis space for MSDHF calculations
// ------------------------------------------------------------------------------------------------------------------
// In order to calculate the MSDHF potential, one has to diagonalize H on the MSDHF configuration, as its ground state is used in the HF-like formulas defining the MSDHF potential.
// As only one configuration occurs, it is much more efficient to recode H in this particular case, than to use the full H class of the general case.
// One uses the Lanczos method to diagonalize H, as one only considers extremal eigenvales on one configuration, which has to be pole approximation.
// One always uses full diagonalization as dimensions are very small on a configuration.
// One only considers one Hamiltonian eigenvector, i.e. its ground state, as it is this eigenstate which enters MSDHF calculations.
//
// One starts from a random pivot |Phi[0]> (+ J projection), of energy E[0] = <Phi[0] | H | Phi[0]>.
// If the GSM dimension is 1, the Lanczos method stops here.
//
// 1) One calculate the next Lanczos vector:
//    It is |Phi[1]>   = H|Phi[0]> - <Phi[0] | H | Phi[0]> |Phi[0]> + orthonormalization (see after) for i = 0 and
//          |Phi[i+1]> = H|Phi[i]> - <Phi[i] | H | Phi[i]> |Phi[i]> - <Phi[i] | H | Phi[i-1]> |Phi[i-1]> + orthonormalization (see after) for i >= 1.
// 
// 2) Orthogonalize |Phi[i+1]> to all previous Lanczos vectors |Phi[j]>, 0 <= j <= i.
//    Orthogonalization is necessary from numerical reasons. Indeed, as is well known, Lanczos vectors are orthogonal theoretically,
//    but lose orthogonality once convergence to an eigenvector starts.
//    Hence, they are orthogonalized with the modified Gram-Schmidt method as if they were non orthogonal.
//
// 3) Project |Phi[i+1]> on J. Indeed, even though H commutes with \vec{J} theoretically,
//    it is not true numerically and one has to project on J because good quantum number character is lost due to numerical inaccuracy.
//    No test is made whether J is conserved or not, as dimensions is very small, on the one hand, and one wants to have maximal precision, on the other hand.
//
// 4) Project H onto the extended basis set |Phi[j]>, 0 <= j <= i+1.
//
// 5) Repeat the above steps until GSM dimension is reached.


// tridiagonalization
// ------------------
// The H matrix is tridiagonalized using the Lanczos method.
// It is represented using calculated Lanczos vectors (see previous points).
// H is diagonalized when GSM dimension is reached (full diagonalization).
//
// lowest_eigenvector_calc_store
// -----------------------------
// The |Psi> ground state eigenvector is calculated in Lanczos basis with shift-and-invert.
// It is calculated from the Lanczos basis to the Slater determinant basis and copied to a GSM vector.
// 
// H_J2_check
// ----------
// In order to check any instability, one puts is_there_cout to true (see below) and one calculates the residues norms ||H|Psi> - E|Psi> + J^2|Psi> - J(J+1)|Psi>||oo.
// It is close to 10^(-15) when there is no instability, and one considers that the calculation is wrong if it is larger than 10^(-5).
// If it is the case, one calculates ||H|Psi> - E|Psi>||oo and ||J^2|Psi> - J(J+1)|Psi>||oo to see which operator creates problems.


void Lanczos_one_configuration::tridiagonalization (
						    const double J , 
						    const class J2_one_configuration_class &J2 , 
						    const class H_one_configuration_class &H , 
						    class array<class GSM_vector_one_configuration> &V_Lanczos_tab , 
						    class array<TYPE> &diagonal , 
						    class array<TYPE> &off_diagonal , 
						    class array<TYPE> &E_tab)
{
  const unsigned int dimension_BP_J = V_Lanczos_tab.dimension (0);

  const class GSM_vector_one_configuration dummy_V;
  
  class GSM_vector_one_configuration &V0 = V_Lanczos_tab(0);

  class GSM_vector_one_configuration HV = H*V0;

  if (dimension_BP_J == 1)
    {
      diagonal(0) = V0*HV;

      const TYPE E0 = diagonal(0);

      E_tab(0) = E0;

      return;
    }

  diagonal(0) = V0*HV;

  const TYPE E0 = diagonal(0);

  class GSM_vector_one_configuration Res_V0 = HV;

  Res_V0 -= E0*V0;

  const double Res_V0_norm = Res_V0.infinite_norm ();

  if (Res_V0_norm < precision)
    {
      E_tab(0) = E0;

      return;
    }

  for (unsigned int i = 1 ; i < dimension_BP_J ; i++)
    {
      const unsigned int im1 = i - 1;

      const unsigned int im2 = (i > 1) ? (i-2) : (NADA);
      
      const class GSM_vector_one_configuration &Vim1 = V_Lanczos_tab(im1);

      const class GSM_vector_one_configuration &Vim2 = (i > 1) ? (V_Lanczos_tab(im2)) : (dummy_V);

      class GSM_vector_one_configuration &Vi = V_Lanczos_tab(i);

      Vi = HV;
      
      Vi -= diagonal(im1)*Vim1;

      if (i > 1) Vi -= off_diagonal(im2)*Vim2;

      Vi.orthogonalization (i , V_Lanczos_tab);

      Vi.good_J (J2 , J);

      Vi.normalization ();

      off_diagonal(im1) = (Vi*HV);

      HV = H*Vi;

      diagonal(i) = (Vi*HV);
      
      off_diagonal(i) = 0.0; 
    }
}




void Lanczos_one_configuration::lowest_eigenvector_calc_store (
							       const bool is_there_cout , 
							       const double J , 
							       const class J2_one_configuration_class &J2 , 
							       const class H_one_configuration_class &H , 
							       const class array<TYPE> &diagonal , 
							       const class array<TYPE> &off_diagonal , 
							       const class array<TYPE> &E_tab , 
							       const class array<class GSM_vector_one_configuration> &V_Lanczos_tab , 
							       class GSM_vector_one_configuration &PSI)
{
  const unsigned int dimension_BP_J = V_Lanczos_tab.dimension (0);

  class array<TYPE> diagonal_tab(dimension_BP_J);

  class array<TYPE> off_diagonal_tab(dimension_BP_J);

  diagonal_tab.assign (diagonal);
  
  off_diagonal_tab.assign (off_diagonal);
	
  const TYPE E = E_tab(0);

  const class vector_class<TYPE> eigenvector_Lanczos = total_diagonalization::symmetric::eigenvector_tridiagonal_calc (E , precision , diagonal_tab , off_diagonal_tab);

  PSI = 0.0;

  for (unsigned int i = 0 ; i < dimension_BP_J ; i++) 
    {
      const class GSM_vector_one_configuration &Vi = V_Lanczos_tab(i);

      PSI += eigenvector_Lanczos(i)*Vi;
    }

  PSI.good_phase ();

  const unsigned int dimension = PSI.get_space_dimension ();

  for (unsigned int i = 0 ; i < dimension ; i++) 
    {
      if (inf_norm (PSI[i]) < precision) PSI[i] = 0.0;
    }

  if (is_there_cout) H_J2_check (PSI , J , J2 , H , E);
}  




void Lanczos_one_configuration::iterative_diagonalization_lowest_states (
									 const bool is_there_cout , 
									 const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_M , 
									 const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_Mp1 , 
									 const class TBMEs_class &TBMEs_pn , 
									 const unsigned int dimension_BP_J , 
									 const double J , 
									 class GSM_vector_one_configuration &PSI)
{
  const class H_one_configuration_class H(GSM_vector_helper_M , TBMEs_pn , J);
  
  const class J2_one_configuration_class J2(GSM_vector_helper_M , GSM_vector_helper_Mp1);
  
  class array<class GSM_vector_one_configuration> V_Lanczos_tab(dimension_BP_J);

  for (unsigned int i = 0 ; i < dimension_BP_J ; i++) V_Lanczos_tab(i).allocate_fill (PSI);

  class GSM_vector_one_configuration &Pivot = V_Lanczos_tab(0);
  
  Pivot.pivot_init (J , J2);

  class array<TYPE> E_tab(dimension_BP_J);

  class array<TYPE> diagonal_tab(dimension_BP_J);

  class array<TYPE> off_diagonal_tab(dimension_BP_J);

  tridiagonalization (J , J2 , H , V_Lanczos_tab , diagonal_tab , off_diagonal_tab , E_tab);
	
  total_diagonalization::symmetric::all_eigenvalues (off_diagonal_tab , diagonal_tab , E_tab);

  lowest_eigenvector_calc_store (is_there_cout , J , J2 , H , diagonal_tab , off_diagonal_tab , E_tab , V_Lanczos_tab , PSI);
}




void Lanczos_one_configuration::H_J2_check (
					    const class GSM_vector_one_configuration &PSI , 
					    const double J , 
					    const class J2_one_configuration_class &J2 , 
					    const class H_one_configuration_class &H , 
					    const TYPE E)
{
  const class GSM_vector_one_configuration Res = (J2 - J*(J+1))*PSI + (H - E)*PSI;

  if (Res.infinite_norm () > sqrt_precision)
    {
      const class GSM_vector_one_configuration Res_J2 = (J2 - J*(J+1))*PSI;

      if (Res_J2.infinite_norm () > sqrt_precision)
	error_message_print_abort ("Residue for J2 too large : |J^2.PSI - J(J+1).PSI|oo = " + make_string<double> (Res.infinite_norm ()));
      
      const class GSM_vector_one_configuration Res_H = (H - E)*PSI;
  
      if (Res_H.infinite_norm () > sqrt_precision)
	error_message_print_abort ("Residue for H too large : |H.PSI - E.PSI|oo = " + make_string<double> (Res.infinite_norm ()));
    }
}


