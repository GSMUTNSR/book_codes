#include "../GSM_include/GSM_include_def.h"


using namespace inputs_misc;
using namespace GSM_vector_NBMEs_handling;
using namespace GSM_vector_NBMEs_handling::out_to_in;
using namespace GSM_vector_dimensions;
using namespace MPI_2D_partitioning;
using namespace configuration_SD_in_space_1ph_2ph_one_jump_Jpm;





// TYPE is double or complex
// -------------------------

unsigned int H_class::non_zero_NBMEs_numbers_pp_nn_calc (
							 const class jumps_data_out_to_in_str &jumps , 
							 const class array<bool> &are_PSI_in_indices_accepted) const
{
  const unsigned int dimension_jumps = jumps.get_dimension ();

  unsigned int non_zero_NBMEs_number = 0;
  
  for (unsigned int i = 0 ; i < dimension_jumps ; i++)
    {
      const bool is_PSI_in_index_accepted = are_PSI_in_indices_accepted(i);

      if (is_PSI_in_index_accepted) non_zero_NBMEs_number++;
    }

  return non_zero_NBMEs_number;
}






void H_class::non_zero_NBMEs_numbers_jumps_p_part_pn_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper_2D (0);
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
        
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 
  
  const int iM = GSM_vector_helper.get_iM (); 

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max  = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max (); 
  const unsigned int dimension_pp_2p2h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_2p2h_space_BP_S_iM_fixed_max ();      
    
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index_row ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index_row ();
  
  const class array<unsigned int> &iCn_min_tab = GSM_vector_helper.get_iCn_min_tab_row ();
  const class array<unsigned int> &iCn_max_tab = GSM_vector_helper.get_iCn_max_tab_row ();

  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min_row ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max_row ();

  if (total_outSDp_index_min > total_outSDp_index_max) return;
    
  class array<class jumps_data_out_to_in_str> one_jump_p_tab(NUMBER_OF_THREADS);
  class array<class jumps_data_out_to_in_str> two_jumps_p_tab(NUMBER_OF_THREADS);
  
  class array<class array<bool> > are_PSI_in_indices_accepted_one_jump_p_tabs(NUMBER_OF_THREADS);  
  class array<class array<bool> > are_PSI_in_indices_accepted_two_jumps_p_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_p_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
      
      are_PSI_in_indices_accepted_one_jump_p_tabs(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);
      
      if (ZYval >= 2)
	{
	  two_jumps_p_tab(i).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_pp_2p2h_space_BP_S_iM_fixed_max);
	  
	  are_PSI_in_indices_accepted_two_jumps_p_tabs(i).allocate (dimension_pp_2p2h_space_BP_S_iM_fixed_max);
	}
    }
       
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule(dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp = outSDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = outSDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sp = outSDp_qn.get_S ();

      const int Sn = S - Sp;
      
      const int n_spec_p = outSDp_qn.get_n_spec ();

      const int n_spec_n = n_spec_max - n_spec_p;

      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

      if (all_dimensions_SDn_zero) continue;

      const int iMn = iM - iMp;
      
      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class jumps_data_out_to_in_str &one_jump_p  = one_jump_p_tab(i_thread);
      class jumps_data_out_to_in_str &two_jumps_p = two_jumps_p_tab(i_thread);
      
      class array<bool> &are_PSI_in_indices_accepted_one_jump_p_tab  = are_PSI_in_indices_accepted_one_jump_p_tabs(i_thread);
      class array<bool> &are_PSI_in_indices_accepted_two_jumps_p_tab = are_PSI_in_indices_accepted_two_jumps_p_tabs(i_thread);
		
      bool are_jumps_p_calculated = false;

      bool is_there_one_jump_calc_all = true;

      bool are_there_two_jumps_calc_all = true;

      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && (is_there_one_jump_calc_all || are_there_two_jumps_calc_all) ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_tab(BPn , Sn , n_spec_n , n_scat_n);
	  const unsigned int iCn_max = iCn_max_tab(BPn , Sn , n_spec_n , n_scat_n);
		  			  
	  for (unsigned int iCn = iCn_min ; (iCn <= iCn_max) && (is_there_one_jump_calc_all || are_there_two_jumps_calc_all) ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
	      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

	      if (dimension_SDn == 0) continue;
				  
	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1; 

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , iMp);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_SDn*outSDp_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_SDn_minus_one;
				  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{	     
		  if (!are_jumps_p_calculated)
		    {						  
		      are_there_two_jumps_calc_all = false;
			      
		      one_jump_p.one_jump_mu_store (0 , BPp , Sp , n_spec_p , iMp , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index , prot_Y_data);
			      
		      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();

		      is_there_one_jump_calc_all = (dimension_one_jump_p > 0);
				    
		      if (is_pp_non_zero && (ZYval >= 2))
			{
			  two_jumps_p.two_jumps_mu_store (0 , BPp , Sp , n_spec_p , iMp , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index , false , false , prot_Y_data);
				  
			  const unsigned int dimension_two_jumps_p = two_jumps_p.get_dimension ();
				  
			  if ((dimension_two_jumps_p > 0) && is_pp_non_zero) are_there_two_jumps_calc_all = true;
			}
			      
		      are_jumps_p_calculated = true;			      
		    }
		  
		  if (!is_there_one_jump_calc_all && !are_there_two_jumps_calc_all) continue;			      
      
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + SDn_index;

		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
					  
			  if (is_there_one_jump_calc_all)
			    {
			      bool is_there_one_jump_calc = false;
			  
			      are_PSI_in_indices_accepted_p_fill_symmetric_case (BPn , Sn , n_spec_n , n_holes_n , n_scat_n , iCn , iMn , SDn_index , En_hw , one_jump_p , GSM_vector_helper , dimension_SDn , PSI_out_index ,
										 are_PSI_in_indices_accepted_one_jump_p_tab , is_there_one_jump_calc);
			      
			      if (is_there_one_jump_calc) non_zero_NBMEs_one_jump_numbers(PSI_out_index) += non_zero_NBMEs_numbers_pp_nn_calc (one_jump_p , are_PSI_in_indices_accepted_one_jump_p_tab);
			    }
			  
			  if (are_there_two_jumps_calc_all)
			    {
			      bool are_there_two_jumps_calc = false;
			  
			      are_PSI_in_indices_accepted_p_fill_symmetric_case (BPn , Sn , n_spec_n , n_holes_n , n_scat_n , iCn , iMn , SDn_index , En_hw , two_jumps_p , GSM_vector_helper , dimension_SDn , PSI_out_index ,
										 are_PSI_in_indices_accepted_two_jumps_p_tab , are_there_two_jumps_calc);
			      
			      if (are_there_two_jumps_calc) non_zero_NBMEs_two_jumps_numbers(PSI_out_index) += non_zero_NBMEs_numbers_pp_nn_calc (two_jumps_p , are_PSI_in_indices_accepted_two_jumps_p_tab);
			    }}}}}}}
}








void H_class::non_zero_NBMEs_numbers_jumps_n_part_pn_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper_2D (0);
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM (); 

  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
        
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max  = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max (); 
  const unsigned int dimension_nn_2p2h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_2p2h_space_BP_S_iM_fixed_max (); 

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
      
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index_row ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index_row ();
  
  const class array<unsigned int> &iCp_min_tab = GSM_vector_helper.get_iCp_min_tab_row ();
  const class array<unsigned int> &iCp_max_tab = GSM_vector_helper.get_iCp_max_tab_row ();
      
  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min_row  ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max_row  ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
    
  class array<class jumps_data_out_to_in_str> one_jump_n_tab(NUMBER_OF_THREADS);
  class array<class jumps_data_out_to_in_str> two_jumps_n_tab(NUMBER_OF_THREADS);
  
  class array<class array<bool> > are_PSI_in_indices_accepted_one_jump_n_tabs(NUMBER_OF_THREADS);  
  class array<class array<bool> > are_PSI_in_indices_accepted_two_jumps_n_tabs(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_n_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      are_PSI_in_indices_accepted_one_jump_n_tabs(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      if (NYval >= 2)
	{
	  two_jumps_n_tab(i).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_nn_2p2h_space_BP_S_iM_fixed_max);
	  
	  are_PSI_in_indices_accepted_two_jumps_n_tabs(i).allocate (dimension_nn_2p2h_space_BP_S_iM_fixed_max);
	}
    }

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule(dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn = outSDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = outSDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sn = outSDn_qn.get_S ();

      const int Sp = S - Sn;
      
      const int n_spec_n = outSDn_qn.get_n_spec ();

      const int n_spec_p = n_spec_max - n_spec_n;

      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

      if (dimension_outSDn == 0) continue;

      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

      if (all_dimensions_SDp_zero) continue;

      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
      
      const int iMp = iM - iMn;
            
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	      
      class jumps_data_out_to_in_str &one_jump_n  = one_jump_n_tab(i_thread);
      class jumps_data_out_to_in_str &two_jumps_n = two_jumps_n_tab(i_thread);
      
      class array<bool> &are_PSI_in_indices_accepted_one_jump_n_tab  = are_PSI_in_indices_accepted_one_jump_n_tabs(i_thread);
      class array<bool> &are_PSI_in_indices_accepted_two_jumps_n_tab = are_PSI_in_indices_accepted_two_jumps_n_tabs(i_thread);
      
      bool are_jumps_n_calculated = false;

      bool is_there_one_jump_calc_all = true;

      bool are_there_two_jumps_calc_all = true;

      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && (is_there_one_jump_calc_all || are_there_two_jumps_calc_all) ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_tab(BPp , Sp , n_spec_p , n_scat_p);
	  const unsigned int iCp_max = iCp_max_tab(BPp , Sp , n_spec_p , n_scat_p);
	  
	  for (unsigned int iCp = iCp_min ; (iCp <= iCp_max) && (is_there_one_jump_calc_all || are_there_two_jumps_calc_all) ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
	      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;
	      
	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

	      if (dimension_SDp == 0) continue;

	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , iMp);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn*dimension_SDp_minus_one;

	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  if (!are_jumps_n_calculated)
		    {
		      are_there_two_jumps_calc_all = false;
						
		      one_jump_n.one_jump_mu_store (0 , BPn , Sn , n_spec_n , iMn , n_holes_max_n , n_scat_max_n , En_max_hw , BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index , neut_Y_data);

		      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
						  								  
		      is_there_one_jump_calc_all = (dimension_one_jump_n > 0);
			      
		      if (is_nn_non_zero && (NYval >= 2))
			{
			  two_jumps_n.two_jumps_mu_store (0 , BPn , Sn , n_spec_n , iMn , n_holes_max_n , n_scat_max_n , En_max_hw , BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index , false , false , neut_Y_data);
				  
			  const unsigned int dimension_two_jumps_n = two_jumps_n.get_dimension ();
				  
			  if ((dimension_two_jumps_n > 0) && is_nn_non_zero) are_there_two_jumps_calc_all = true;
			}
			      
		      are_jumps_n_calculated = true;
		    }		

		  if (!is_there_one_jump_calc_all && !are_there_two_jumps_calc_all) continue;
		  
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + dimension_outSDn*SDp_index;
					
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
			  
			  if (is_there_one_jump_calc_all)
			    {
			      bool is_there_one_jump_calc = false;
			  
			      are_PSI_in_indices_accepted_n_fill_symmetric_case (BPp , Sp , n_spec_p , n_holes_p ,n_scat_p ,  iCp , iMp , SDp_index , Ep_hw , one_jump_n , GSM_vector_helper , PSI_out_index ,
										 are_PSI_in_indices_accepted_one_jump_n_tab , is_there_one_jump_calc);
			      
			      if (is_there_one_jump_calc) non_zero_NBMEs_one_jump_numbers(PSI_out_index) += non_zero_NBMEs_numbers_pp_nn_calc (one_jump_n , are_PSI_in_indices_accepted_one_jump_n_tab);
			    }
			  
			  if (are_there_two_jumps_calc_all)
			    {
			      bool are_there_two_jumps_calc = false;
			  
			      are_PSI_in_indices_accepted_n_fill_symmetric_case (BPp , Sp , n_spec_p , n_holes_p , n_scat_p , iCp , iMp , SDp_index , Ep_hw , two_jumps_n , GSM_vector_helper , PSI_out_index , 
										 are_PSI_in_indices_accepted_two_jumps_n_tab , are_there_two_jumps_calc);
			      
			      if (are_there_two_jumps_calc) non_zero_NBMEs_two_jumps_numbers(PSI_out_index) += non_zero_NBMEs_numbers_pp_nn_calc (two_jumps_n , are_PSI_in_indices_accepted_two_jumps_n_tab);
			    }}}}}}}
}








void H_class::non_zero_NBMEs_numbers_two_jumps_pn_part_pn_one_jumps_stored_Nval_larger_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper_2D (0);
      
  const bool is_it_diagonal_square = GSM_vector_helper.get_is_it_diagonal_square ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();  
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
    
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index_column ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index_column ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index_row ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index_row ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_tab = GSM_vector_helper.get_iCp_min_tab_row ();
  const class array<unsigned int> &iCp_out_max_tab = GSM_vector_helper.get_iCp_max_tab_row ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min_row ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min_row ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max_row ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();

      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();
      
      const unsigned int BPp_out = binary_parity_product (BPn_out , BP);

      const int Sn_out = outSDn_qn.get_S ();

      const int Sp_out = S - Sn_out;
      
      const int n_spec_n_out = outSDn_qn.get_n_spec ();

      const int n_spec_p_out = n_spec_max - n_spec_n_out;
      
      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;
		  
      const int n_spec_p_in = n_spec_p_out;
      const int n_spec_n_in = n_spec_n_out;
		  
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const int iMp_out = iM - iMn_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);
      
      const unsigned long int total_outSDn_index_shifted = total_outSDn_index - total_outSDn_index_min;
      
      const class array<class jumps_data_out_to_in_str> &one_jump_n_tab = one_jump_n_tabs(0 , total_outSDn_index_shifted);
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;
	      
	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
	      
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int total_outSDp_index_zero = SDp_set.index_determine (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , 0);
      
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDp_index*dimension_outSDn;
      
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned long int total_outSDp_index = total_outSDp_index_zero + outSDp_index;

			  const unsigned long int total_outSDp_index_shifted = total_outSDp_index - total_outSDp_index_min;

			  const class array<class jumps_data_out_to_in_str> &one_jump_p_tab = one_jump_p_tabs(0 , total_outSDp_index_shifted);
			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  unsigned int &non_zero_NBMEs_index_two_jumps = non_zero_NBMEs_two_jumps_numbers(PSI_out_index);
				
			  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
			    {
			      const unsigned int BPn_in = binary_parity_product (BPp_in , BP);

			      for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				{
				  const int Sn_in = S - Sp_in;
		  	  
				  for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
				    {
				      const int iMn_in = iM - iMp_in;

				      const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
				      const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
				      if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
				      if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				  
				      const class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in);
				
				      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
				      
				      if (dimension_one_jump_n == 0) continue;
				      
				      const class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in);
				      
				      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				  
				      if (dimension_one_jump_p == 0) continue;
				      
				      unsigned long int total_PSI_in_index_zero_inSDn = 0;
				  
				      unsigned long int total_PSI_in_index_dimension_minus_one_inSDn = 0;
				  
				      bool are_PSI_in_indices_considered = true;
  
				      for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
					{
					  const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);

					  const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();

					  const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

					  const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
				      
					  const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();

					  const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();
												  
					  for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)
					    {
					      const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);

					      const bool is_configuration_changing = one_jump_n_inSDn.get_is_configuration_changing ();

					      if (is_configuration_changing) 
						{
						  const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
					      
						  const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();

						  const int En_hw_in = one_jump_n_inSDn.get_E_hw ();
								  
						  are_PSI_in_indices_considered = true;
							  
						  if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) are_PSI_in_indices_considered = false;
					      
						  if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) are_PSI_in_indices_considered = false;
							  
						  if (are_PSI_in_indices_considered) 
						    {
						      const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();

						      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);

						      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
							      
						      total_PSI_in_index_zero_inSDn = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*inSDp_index;
						  
						      total_PSI_in_index_dimension_minus_one_inSDn = total_PSI_in_index_zero_inSDn + (dimension_inSDn - 1);
							      
						      if ((total_PSI_in_index_zero_inSDn > last_total_PSI_in_index) || (total_PSI_in_index_dimension_minus_one_inSDn < first_total_PSI_in_index))
							are_PSI_in_indices_considered = false;
						    }
						}
						      
					      if (are_PSI_in_indices_considered)
						{
						  const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

						  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDn + inSDn_index;
							  
						  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						    {
						      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
							      
						      if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index)) non_zero_NBMEs_index_two_jumps++;
						    }}}}}}}}}}}}}
} 










void H_class::non_zero_NBMEs_numbers_two_jumps_pn_part_pn_one_jumps_stored_Zval_larger_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper_2D (0);
      
  const bool is_it_diagonal_square = GSM_vector_helper.get_is_it_diagonal_square ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
    
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();

  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
    
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
    
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
	  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index_column ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index_column ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index_row ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index_row ();

  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_tab = GSM_vector_helper.get_iCn_min_tab_row ();
  const class array<unsigned int> &iCn_out_max_tab = GSM_vector_helper.get_iCn_max_tab_row ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min_row ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max_row ();

  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min_row ();
  
  if (total_outSDp_index_min > total_outSDp_index_max) return;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();
      
      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);

      const int Sp_out = outSDp_qn.get_S ();

      const int Sn_out = S - Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();

      const int n_spec_n_out = n_spec_max - n_spec_p_out;
      
      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;
		  
      const int n_spec_p_in = n_spec_p_out;
      const int n_spec_n_in = n_spec_n_out;

      const int iMn_out = iM - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);

      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();

      const unsigned long int total_outSDp_index_shifted = total_outSDp_index - total_outSDp_index_min;

      const class array<class jumps_data_out_to_in_str> &one_jump_p_tab = one_jump_p_tabs(0 , total_outSDp_index_shifted);
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	      
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int total_outSDn_index_zero = SDn_set.index_determine (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , 0);
		  
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDn_index;
		     			  
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned long int total_outSDn_index = total_outSDn_index_zero + outSDn_index;

			  const unsigned long int total_outSDn_index_shifted = total_outSDn_index - total_outSDn_index_min;

			  const class array<class jumps_data_out_to_in_str> &one_jump_n_tab = one_jump_n_tabs(0 , total_outSDn_index_shifted);
			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  unsigned int &non_zero_NBMEs_index_two_jumps = non_zero_NBMEs_two_jumps_numbers(PSI_out_index);
			  
			  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
			    {
			      const unsigned int BPn_in = binary_parity_product (BPp_in , BP);

			      for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				{
				  const int Sn_in = S - Sp_in;
		  	  
				  for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
				    {
				      const int iMn_in = iM - iMp_in;
				  
				      const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
				      const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
				      if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
				      if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				  
				      const class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in);   
				
				      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				      
				      if (dimension_one_jump_p == 0) continue;

				      const class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in);
				      				      
				      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
					      
				      if (dimension_one_jump_n == 0) continue;
				      
				      bool are_PSI_in_indices_considered = true;
				      
				      unsigned long int total_PSI_in_index_zero_inSDp = 0;
				  
				      unsigned long int total_PSI_in_index_dimension_minus_one_inSDp = 0;

				      for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)  
					{
					  const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);
						  
					  const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();

					  const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

					  const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
				      
					  const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();

					  const int En_hw_in = one_jump_n_inSDn.get_E_hw ();

					  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
						  
					  for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)
					    {
					      const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);

					      const bool is_configuration_changing = one_jump_p_inSDp.get_is_configuration_changing ();
						      
					      if (is_configuration_changing) 
						{
						  const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
					      
						  const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();

						  const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();
								      
						  are_PSI_in_indices_considered = true;
									  
						  if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) are_PSI_in_indices_considered = false;

						  if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) are_PSI_in_indices_considered = false;

						  if (are_PSI_in_indices_considered) 
						    {
						      const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();

						      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);

						      const unsigned int dimension_inSDp = dimensions_SDp_set(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in , iMp_in);
							      
						      total_PSI_in_index_zero_inSDp = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;

						      total_PSI_in_index_dimension_minus_one_inSDp = total_PSI_in_index_zero_inSDp + dimension_inSDn*(dimension_inSDp - 1);
							      
						      if ((total_PSI_in_index_zero_inSDp > last_total_PSI_in_index) || (total_PSI_in_index_dimension_minus_one_inSDp < first_total_PSI_in_index))
							are_PSI_in_indices_considered = false;
						    }
						}
						      
					      if (are_PSI_in_indices_considered)
						{
						  const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

						  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDp + dimension_inSDn*inSDp_index;
							  
						  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						    {
						      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
										  
						      if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index)) non_zero_NBMEs_index_two_jumps++;
						    }}}}}}}}}}}}}
}














void H_class::non_zero_NBMEs_numbers_two_jumps_pn_part_pn_one_jumps_partially_stored_Nval_larger_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper_2D (0);
      
  const bool is_it_diagonal_square = GSM_vector_helper.get_is_it_diagonal_square ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 

  const int S_plus_one = S + 1;

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();  
  const int four_mn_max = neut_Y_data.get_four_m_max ();

  const int four_mn_max_plus_one = four_mn_max + 1;
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
    
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max (); 

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index_column ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index_column ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index_row ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index_row ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_tab = GSM_vector_helper.get_iCp_min_tab_row ();
  const class array<unsigned int> &iCp_out_max_tab = GSM_vector_helper.get_iCp_max_tab_row ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min_row ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min_row ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max_row ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
    
  class array<class array<class jumps_data_out_to_in_str> > one_jump_n_tabs_local(NUMBER_OF_THREADS);
  
  class array<class array<bool> > is_one_jump_n_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      class array<class jumps_data_out_to_in_str> &one_jump_n_tab = one_jump_n_tabs_local(i);
      
      one_jump_n_tab.allocate (2 , S_plus_one , four_mn_max_plus_one);
      
      for (unsigned int BPn_in = 0 ; BPn_in <= 1 ; BPn_in++)
	for (int Sn_in = 0 ; Sn_in <= S ; Sn_in++)
	  for (int Delta_iMn_in = 0 ; Delta_iMn_in <= four_mn_max ; Delta_iMn_in++)
	    one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      is_one_jump_n_calculated_tabs(i).allocate (2 , S_plus_one , four_mn_max_plus_one);
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();

      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();
      
      const unsigned int BPp_out = binary_parity_product (BPn_out , BP);

      const int Sn_out = outSDn_qn.get_S ();

      const int Sp_out = S - Sn_out;
      
      const int n_spec_n_out = outSDn_qn.get_n_spec ();

      const int n_spec_p_out = n_spec_max - n_spec_n_out;
      
      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;
		  
      const int n_spec_p_in = n_spec_p_out;
      const int n_spec_n_in = n_spec_n_out;
		  
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const int iMp_out = iM - iMn_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class array<class jumps_data_out_to_in_str> &one_jump_n_tab = one_jump_n_tabs_local(i_thread);
      
      class array<bool> &is_one_jump_n_calculated_tab = is_one_jump_n_calculated_tabs(i_thread);
  
      is_one_jump_n_calculated_tab = false;
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;
	      
	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
	      
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int total_outSDp_index_zero = SDp_set.index_determine (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , 0);
      
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDp_index*dimension_outSDn;
      
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned long int total_outSDp_index = total_outSDp_index_zero + outSDp_index;

			  const unsigned long int total_outSDp_index_shifted = total_outSDp_index - total_outSDp_index_min;

			  const class array<class jumps_data_out_to_in_str> &one_jump_p_tab = one_jump_p_tabs(0 , total_outSDp_index_shifted);
			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  unsigned int &non_zero_NBMEs_index_two_jumps = non_zero_NBMEs_two_jumps_numbers(PSI_out_index);
						  
			  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
			    {
			      const unsigned int BPn_in = binary_parity_product (BPp_in , BP);

			      for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				{
				  const int Sn_in = S - Sp_in;
		  	  
				  for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
				    {
				      const int iMn_in = iM - iMp_in;

				      const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
				      const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
				      if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
				      if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				  
				      class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in); 

				      bool &is_one_jump_n_calculated = is_one_jump_n_calculated_tab(BPn_in , Sn_in , Delta_iMn_in);

				      if (!is_one_jump_n_calculated)
					{
					  one_jump_n.one_jump_mu_store (0 , BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw ,
									BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , neut_Y_data);
				      
					  is_one_jump_n_calculated = true;
					}
				
				      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
				      
				      if (dimension_one_jump_n == 0) continue;
				      
				      const class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in);
				      
				      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				  
				      if (dimension_one_jump_p == 0) continue;
				      
				      unsigned long int total_PSI_in_index_zero_inSDn = 0;
				  
				      unsigned long int total_PSI_in_index_dimension_minus_one_inSDn = 0;
				  
				      bool are_PSI_in_indices_considered = true;
  
				      for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
					{
					  const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);

					  const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();

					  const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

					  const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
				      
					  const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();

					  const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();
												  
					  for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)
					    {
					      const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);

					      const bool is_configuration_changing = one_jump_n_inSDn.get_is_configuration_changing ();

					      if (is_configuration_changing) 
						{
						  const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
					      
						  const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();

						  const int En_hw_in = one_jump_n_inSDn.get_E_hw ();
								  
						  are_PSI_in_indices_considered = true;
							  
						  if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) are_PSI_in_indices_considered = false;
					      
						  if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) are_PSI_in_indices_considered = false;
							  
						  if (are_PSI_in_indices_considered) 
						    {
						      const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();

						      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);

						      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
							      
						      total_PSI_in_index_zero_inSDn = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*inSDp_index;
						  
						      total_PSI_in_index_dimension_minus_one_inSDn = total_PSI_in_index_zero_inSDn + (dimension_inSDn - 1);
							      
						      if ((total_PSI_in_index_zero_inSDn > last_total_PSI_in_index) || (total_PSI_in_index_dimension_minus_one_inSDn < first_total_PSI_in_index))
							are_PSI_in_indices_considered = false;
						    }
						}
						      
					      if (are_PSI_in_indices_considered)
						{
						  const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

						  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDn + inSDn_index;
							  
						  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						    {
						      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
							      
						      if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index)) non_zero_NBMEs_index_two_jumps++;
						    }}}}}}}}}}}}}
} 










void H_class::non_zero_NBMEs_numbers_two_jumps_pn_part_pn_one_jumps_partially_stored_Zval_larger_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper_2D (0);
      
  const bool is_it_diagonal_square = GSM_vector_helper.get_is_it_diagonal_square ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
    
  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int S_plus_one = S + 1;
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();

  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();

  const int four_mp_max_plus_one = four_mp_max + 1;
    
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
  
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
	  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index_column ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index_column ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index_row ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index_row ();

  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_tab = GSM_vector_helper.get_iCn_min_tab_row ();
  const class array<unsigned int> &iCn_out_max_tab = GSM_vector_helper.get_iCn_max_tab_row ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min_row ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max_row ();

  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min_row ();
  
  if (total_outSDp_index_min > total_outSDp_index_max) return;
  
  class array<class array<class jumps_data_out_to_in_str> > one_jump_p_tabs_local(NUMBER_OF_THREADS);
  
  class array<class array<bool> > is_one_jump_p_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      class array<class jumps_data_out_to_in_str> &one_jump_p_tab = one_jump_p_tabs_local(i);
      
      one_jump_p_tab.allocate (2 , S_plus_one , four_mp_max_plus_one);
      
      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
	for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
	  for (int Delta_iMp_in = 0 ; Delta_iMp_in <= four_mp_max ; Delta_iMp_in++)
	    one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
      
      is_one_jump_p_calculated_tabs(i).allocate (2 , S_plus_one , four_mp_max_plus_one);
    }  

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();
      
      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);

      const int Sp_out = outSDp_qn.get_S ();

      const int Sn_out = S - Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();

      const int n_spec_n_out = n_spec_max - n_spec_p_out;
      
      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;
		  
      const int n_spec_p_in = n_spec_p_out;
      const int n_spec_n_in = n_spec_n_out;

      const int iMn_out = iM - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);

      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();

      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class array<class jumps_data_out_to_in_str> &one_jump_p_tab = one_jump_p_tabs_local(i_thread);
      
      class array<bool> &is_one_jump_p_calculated_tab = is_one_jump_p_calculated_tabs(i_thread);
            
      is_one_jump_p_calculated_tab = false;
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	      
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int total_outSDn_index_zero = SDn_set.index_determine (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , 0);
		  
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDn_index;
		     			  
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned long int total_outSDn_index = total_outSDn_index_zero + outSDn_index;

			  const unsigned long int total_outSDn_index_shifted = total_outSDn_index - total_outSDn_index_min;

			  const class array<class jumps_data_out_to_in_str> &one_jump_n_tab = one_jump_n_tabs(0 , total_outSDn_index_shifted);
			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  unsigned int &non_zero_NBMEs_index_two_jumps = non_zero_NBMEs_two_jumps_numbers(PSI_out_index);
			  
			  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
			    {
			      const unsigned int BPn_in = binary_parity_product (BPp_in , BP);

			      for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				{
				  const int Sn_in = S - Sp_in;
		  		  	  
				  for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
				    {
				      const int iMn_in = iM - iMp_in;
				  
				      const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
				      const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
				      if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
				      if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				  
				      class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in);

				      bool &is_one_jump_p_calculated = is_one_jump_p_calculated_tab(BPp_in , Sp_in , Delta_iMp_in);

				      if (!is_one_jump_p_calculated)
					{
					  one_jump_p.one_jump_mu_store (0 , BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw ,
									BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , prot_Y_data);
				      
					  is_one_jump_p_calculated = true;
					}
				
				      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				      
				      if (dimension_one_jump_p == 0) continue;

				      const class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in);
				      				      
				      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
					      
				      if (dimension_one_jump_n == 0) continue;
				      
				      bool are_PSI_in_indices_considered = true;
				      
				      unsigned long int total_PSI_in_index_zero_inSDp = 0;
				  
				      unsigned long int total_PSI_in_index_dimension_minus_one_inSDp = 0;

				      for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)  
					{
					  const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);
						  
					  const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();

					  const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

					  const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
				      
					  const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();

					  const int En_hw_in = one_jump_n_inSDn.get_E_hw ();

					  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
						  
					  for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)
					    {
					      const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);

					      const bool is_configuration_changing = one_jump_p_inSDp.get_is_configuration_changing ();
						      
					      if (is_configuration_changing) 
						{
						  const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
					      
						  const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();

						  const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();
								      
						  are_PSI_in_indices_considered = true;
									  
						  if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) are_PSI_in_indices_considered = false;

						  if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) are_PSI_in_indices_considered = false;

						  if (are_PSI_in_indices_considered) 
						    {
						      const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();

						      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);

						      const unsigned int dimension_inSDp = dimensions_SDp_set(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in , iMp_in);
							      
						      total_PSI_in_index_zero_inSDp = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;

						      total_PSI_in_index_dimension_minus_one_inSDp = total_PSI_in_index_zero_inSDp + dimension_inSDn*(dimension_inSDp - 1);
							      
						      if ((total_PSI_in_index_zero_inSDp > last_total_PSI_in_index) || (total_PSI_in_index_dimension_minus_one_inSDp < first_total_PSI_in_index))
							are_PSI_in_indices_considered = false;
						    }
						}
						      
					      if (are_PSI_in_indices_considered)
						{
						  const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

						  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDp + dimension_inSDn*inSDp_index;
							  
						  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						    {
						      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
										  
						      if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index)) non_zero_NBMEs_index_two_jumps++;
						    }}}}}}}}}}}}}
}














void H_class::non_zero_NBMEs_numbers_two_jumps_pn_part_pn_one_jumps_recalculated_Nval_larger_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper_2D (0);
      
  const bool is_it_diagonal_square = GSM_vector_helper.get_is_it_diagonal_square ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 
  
  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 

  const int S_plus_one = S + 1;

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();  
  const int four_mn_max = neut_Y_data.get_four_m_max ();

  const int four_mn_max_plus_one = four_mn_max + 1;
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
    
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max (); 
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index_column ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index_column ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index_row ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index_row ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_tab = GSM_vector_helper.get_iCp_min_tab_row ();
  const class array<unsigned int> &iCp_out_max_tab = GSM_vector_helper.get_iCp_max_tab_row ();
    
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min_row ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max_row ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
    
  class array<class jumps_data_out_to_in_str> one_jump_p_tab(NUMBER_OF_THREADS);
  
  class array<class array<class jumps_data_out_to_in_str> > one_jump_n_tabs_local(NUMBER_OF_THREADS);
  
  class array<class array<bool> > is_one_jump_n_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_p_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
	  
      class array<class jumps_data_out_to_in_str> &one_jump_n_tab = one_jump_n_tabs_local(i);
      
      one_jump_n_tab.allocate (2 , S_plus_one , four_mn_max_plus_one);
      
      for (unsigned int BPn_in = 0 ; BPn_in <= 1 ; BPn_in++)
	for (int Sn_in = 0 ; Sn_in <= S ; Sn_in++)
	  for (int Delta_iMn_in = 0 ; Delta_iMn_in <= four_mn_max ; Delta_iMn_in++)
	    one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      is_one_jump_n_calculated_tabs(i).allocate (2 , S_plus_one , four_mn_max_plus_one);
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();

      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();
      
      const unsigned int BPp_out = binary_parity_product (BPn_out , BP);

      const int Sn_out = outSDn_qn.get_S ();

      const int Sp_out = S - Sn_out;
      
      const int n_spec_n_out = outSDn_qn.get_n_spec ();

      const int n_spec_p_out = n_spec_max - n_spec_n_out;
      
      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;
		  
      const int n_spec_p_in = n_spec_p_out;
      const int n_spec_n_in = n_spec_n_out;
		  
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const int iMp_out = iM - iMn_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(i_thread);
  
      class array<class jumps_data_out_to_in_str> &one_jump_n_tab = one_jump_n_tabs_local(i_thread);
      
      class array<bool> &is_one_jump_n_calculated_tab = is_one_jump_n_calculated_tabs(i_thread);
  
      is_one_jump_n_calculated_tab = false;
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
	      
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{      
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDp_index*dimension_outSDn;
      
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  unsigned int &non_zero_NBMEs_index_two_jumps = non_zero_NBMEs_two_jumps_numbers(PSI_out_index);
					
			  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
			    {
			      const unsigned int BPn_in = binary_parity_product (BPp_in , BP);

			      for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				{
				  const int Sn_in = S - Sp_in;
		  	  
				  for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
				    {
				      const int iMn_in = iM - iMp_in;

				      const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
				      const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
				      if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
				      if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				  
				      class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in); 

				      bool &is_one_jump_n_calculated = is_one_jump_n_calculated_tab(BPn_in , Sn_in , Delta_iMn_in);

				      if (!is_one_jump_n_calculated)
					{
					  one_jump_n.one_jump_mu_store (0 , BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw ,
									BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , neut_Y_data);
				      
					  is_one_jump_n_calculated = true;
					}
				
				      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
				      
				      if (dimension_one_jump_n == 0) continue;
				      
				      one_jump_p.one_jump_mu_store (0 , BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw ,
								    BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , prot_Y_data);
				      
				      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				  
				      if (dimension_one_jump_p == 0) continue;
				      
				      unsigned long int total_PSI_in_index_zero_inSDn = 0;
				  
				      unsigned long int total_PSI_in_index_dimension_minus_one_inSDn = 0;
				  
				      bool are_PSI_in_indices_considered = true;
  
				      for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
					{
					  const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);

					  const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();

					  const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

					  const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
				      
					  const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();

					  const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();
												  
					  for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)
					    {
					      const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);

					      const bool is_configuration_changing = one_jump_n_inSDn.get_is_configuration_changing ();

					      if (is_configuration_changing) 
						{
						  const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
					      
						  const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();

						  const int En_hw_in = one_jump_n_inSDn.get_E_hw ();
								  
						  are_PSI_in_indices_considered = true;
							  
						  if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) are_PSI_in_indices_considered = false;
					      
						  if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) are_PSI_in_indices_considered = false;
							  
						  if (are_PSI_in_indices_considered) 
						    {
						      const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();

						      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);

						      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
							      
						      total_PSI_in_index_zero_inSDn = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*inSDp_index;
						  
						      total_PSI_in_index_dimension_minus_one_inSDn = total_PSI_in_index_zero_inSDn + (dimension_inSDn - 1);
							      
						      if ((total_PSI_in_index_zero_inSDn > last_total_PSI_in_index) || (total_PSI_in_index_dimension_minus_one_inSDn < first_total_PSI_in_index))
							are_PSI_in_indices_considered = false;
						    }
						}
						      
					      if (are_PSI_in_indices_considered)
						{
						  const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

						  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDn + inSDn_index;
							  
						  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						    {
						      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
							      
						      if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index)) non_zero_NBMEs_index_two_jumps++;
						    }}}}}}}}}}}}}
} 










void H_class::non_zero_NBMEs_numbers_two_jumps_pn_part_pn_one_jumps_recalculated_Zval_larger_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper_2D (0);
      
  const bool is_it_diagonal_square = GSM_vector_helper.get_is_it_diagonal_square ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int S_plus_one = S + 1;
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();

  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();

  const int four_mp_max_plus_one = four_mp_max + 1;
    
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
  
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  	  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index_column ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index_column ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index_row ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index_row ();

  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_tab = GSM_vector_helper.get_iCn_min_tab_row ();
  const class array<unsigned int> &iCn_out_max_tab = GSM_vector_helper.get_iCn_max_tab_row ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min_row ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max_row ();
  
  if (total_outSDp_index_min > total_outSDp_index_max) return;
  
  class array<class jumps_data_out_to_in_str> one_jump_n_tab(NUMBER_OF_THREADS);
  
  class array<class array<class jumps_data_out_to_in_str> > one_jump_p_tabs_local(NUMBER_OF_THREADS);
  
  class array<class array<bool> > is_one_jump_p_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_n_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      class array<class jumps_data_out_to_in_str> &one_jump_p_tab = one_jump_p_tabs_local(i);
      
      one_jump_p_tab.allocate (2 , S_plus_one , four_mp_max_plus_one);
      
      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
	for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
	  for (int Delta_iMp_in = 0 ; Delta_iMp_in <= four_mp_max ; Delta_iMp_in++)
	    one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
      
      is_one_jump_p_calculated_tabs(i).allocate (2 , S_plus_one , four_mp_max_plus_one);
    }  

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();
      
      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);
      
      const int Sp_out = outSDp_qn.get_S ();

      const int Sn_out = S - Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();

      const int n_spec_n_out = n_spec_max - n_spec_p_out;
      
      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;
		  
      const int n_spec_p_in = n_spec_p_out;
      const int n_spec_n_in = n_spec_n_out;

      const int iMn_out = iM - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);

      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();

      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(i_thread);
      
      class array<class jumps_data_out_to_in_str> &one_jump_p_tab = one_jump_p_tabs_local(i_thread);
      
      class array<bool> &is_one_jump_p_calculated_tab = is_one_jump_p_calculated_tabs(i_thread);
            
      is_one_jump_p_calculated_tab = false;
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	      
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{		  
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDn_index;
		     			  
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  unsigned int &non_zero_NBMEs_index_two_jumps = non_zero_NBMEs_two_jumps_numbers(PSI_out_index);
			  
			  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
			    {
			      const unsigned int BPn_in = binary_parity_product (BPp_in , BP);

			      for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				{
				  const int Sn_in = S - Sp_in;
		  	  
				  for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
				    {
				      const int iMn_in = iM - iMp_in;
				  
				      const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
				      const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
				      if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
				      if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				  
				      class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in);

				      bool &is_one_jump_p_calculated = is_one_jump_p_calculated_tab(BPp_in , Sp_in , Delta_iMp_in);

				      if (!is_one_jump_p_calculated)
					{
					  one_jump_p.one_jump_mu_store (0 , BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw ,
									BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , prot_Y_data);
				      
					  is_one_jump_p_calculated = true;
					}
				
				      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				      
				      if (dimension_one_jump_p == 0) continue;

				      one_jump_n.one_jump_mu_store (0 , BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw ,
								    BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , neut_Y_data);
				      				      
				      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
					      
				      if (dimension_one_jump_n == 0) continue;
				      
				      bool are_PSI_in_indices_considered = true;
				      
				      unsigned long int total_PSI_in_index_zero_inSDp = 0;
				  
				      unsigned long int total_PSI_in_index_dimension_minus_one_inSDp = 0;

				      for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)  
					{
					  const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);
						  
					  const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();

					  const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

					  const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
				      
					  const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();

					  const int En_hw_in = one_jump_n_inSDn.get_E_hw ();

					  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
						  
					  for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)
					    {
					      const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);

					      const bool is_configuration_changing = one_jump_p_inSDp.get_is_configuration_changing ();
						      
					      if (is_configuration_changing) 
						{
						  const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
					      
						  const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();

						  const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();
								      
						  are_PSI_in_indices_considered = true;
									  
						  if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) are_PSI_in_indices_considered = false;

						  if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) are_PSI_in_indices_considered = false;

						  if (are_PSI_in_indices_considered) 
						    {
						      const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();

						      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);

						      const unsigned int dimension_inSDp = dimensions_SDp_set(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in , iMp_in);
							      
						      total_PSI_in_index_zero_inSDp = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;

						      total_PSI_in_index_dimension_minus_one_inSDp = total_PSI_in_index_zero_inSDp + dimension_inSDn*(dimension_inSDp - 1);
							      
						      if ((total_PSI_in_index_zero_inSDp > last_total_PSI_in_index) || (total_PSI_in_index_dimension_minus_one_inSDp < first_total_PSI_in_index))
							are_PSI_in_indices_considered = false;
						    }
						}
						      
					      if (are_PSI_in_indices_considered)
						{
						  const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

						  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDp + dimension_inSDn*inSDp_index;
							  
						  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						    {
						      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
										  
						      if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index)) non_zero_NBMEs_index_two_jumps++;
						    }}}}}}}}}}}}}
}



































void H_class::non_zero_NBMEs_numbers_two_jumps_cv_part_pn_two_jumps_stored_Nval_larger_calc (const bool is_it_cv_pp_to_nn)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper_2D (0);
      
  const bool is_it_diagonal_square = GSM_vector_helper.get_is_it_diagonal_square ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();  
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
    
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index_column ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index_column ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index_row ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index_row ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_tab = GSM_vector_helper.get_iCp_min_tab_row ();
  const class array<unsigned int> &iCp_out_max_tab = GSM_vector_helper.get_iCp_max_tab_row ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min_row ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min_row ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max_row ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();

      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();
      
      const unsigned int BPp_out = binary_parity_product (BPn_out , BP);

      const int Sn_out = outSDn_qn.get_S ();

      const int Sp_out = S - Sn_out;
      
      const int n_spec_n_out = outSDn_qn.get_n_spec ();

      const int n_spec_p_out = n_spec_max - n_spec_n_out;
      
      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;
		  
      const int n_spec_p_in = (is_it_cv_pp_to_nn) ? (n_spec_p_out - 2) : (n_spec_p_out + 2);
      const int n_spec_n_in = (is_it_cv_pp_to_nn) ? (n_spec_n_out + 2) : (n_spec_n_out - 2);
		  
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const int iMp_out = iM - iMn_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);
      
      const unsigned long int total_outSDn_index_shifted = total_outSDn_index - total_outSDn_index_min;
      
      const class array<class jumps_data_out_to_in_str> &two_jumps_cv_n_tab = (is_it_cv_pp_to_nn) ? (two_jumps_cv_n_pp_to_nn_tabs(total_outSDn_index_shifted)) : (two_jumps_cv_n_nn_to_pp_tabs(total_outSDn_index_shifted));
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;
	      
	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
	      
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int total_outSDp_index_zero = SDp_set.index_determine (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , 0);
      
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDp_index*dimension_outSDn;
      
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned long int total_outSDp_index = total_outSDp_index_zero + outSDp_index;

			  const unsigned long int total_outSDp_index_shifted = total_outSDp_index - total_outSDp_index_min;

			  const class array<class jumps_data_out_to_in_str> &two_jumps_cv_p_tab = (is_it_cv_pp_to_nn) ? (two_jumps_cv_p_pp_to_nn_tabs(total_outSDp_index_shifted)) : (two_jumps_cv_p_nn_to_pp_tabs(total_outSDp_index_shifted));
			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  unsigned int &non_zero_NBMEs_index_two_jumps = non_zero_NBMEs_two_jumps_numbers(PSI_out_index);
						
			  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
			    {
			      const unsigned int BPn_in = binary_parity_product (BPp_in , BP);

			      for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				{
				  const int Sn_in = S - Sp_in;
		  	  
				  for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
				    {
				      const int iMn_in = iM - iMp_in;

				      const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
				      const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
				      if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
				      if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				  
				      const class jumps_data_out_to_in_str &two_jumps_cv_n = two_jumps_cv_n_tab(BPn_in , Sn_in , Delta_iMn_in);
				
				      const unsigned int dimension_two_jumps_cv_n = two_jumps_cv_n.get_dimension ();
				      
				      if (dimension_two_jumps_cv_n == 0) continue;
				      
				      const class jumps_data_out_to_in_str &two_jumps_cv_p = two_jumps_cv_p_tab(BPp_in , Sp_in , Delta_iMp_in);
				      
				      const unsigned int dimension_two_jumps_cv_p = two_jumps_cv_p.get_dimension ();
				  
				      if (dimension_two_jumps_cv_p == 0) continue;
				      
				      unsigned long int total_PSI_in_index_zero_inSDn = 0;
				  
				      unsigned long int total_PSI_in_index_dimension_minus_one_inSDn = 0;
				  
				      bool are_PSI_in_indices_considered = true;
  
				      for (unsigned int ip = 0 ; ip < dimension_two_jumps_cv_p ; ip++)  
					{
					  const class jumps_data_inSD_str &two_jumps_cv_p_inSDp = two_jumps_cv_p(ip);

					  const unsigned int iCp_in = two_jumps_cv_p_inSDp.get_iC ();

					  const unsigned int inSDp_index = two_jumps_cv_p_inSDp.get_inSD_index ();

					  const int n_holes_p_in = two_jumps_cv_p_inSDp.get_n_holes ();
				      
					  const int n_scat_p_in = two_jumps_cv_p_inSDp.get_n_scat ();

					  const int Ep_hw_in = two_jumps_cv_p_inSDp.get_E_hw ();
												  
					  for (unsigned int in = 0 ; in < dimension_two_jumps_cv_n ; in++)
					    {
					      const class jumps_data_inSD_str &two_jumps_cv_n_inSDn = two_jumps_cv_n(in);

					      const bool is_configuration_changing = two_jumps_cv_n_inSDn.get_is_configuration_changing ();

					      if (is_configuration_changing) 
						{
						  const int n_holes_n_in = two_jumps_cv_n_inSDn.get_n_holes ();
					      
						  const int n_scat_n_in = two_jumps_cv_n_inSDn.get_n_scat ();

						  const int En_hw_in = two_jumps_cv_n_inSDn.get_E_hw ();
								  
						  are_PSI_in_indices_considered = true;
							  
						  if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) are_PSI_in_indices_considered = false;
					      
						  if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) are_PSI_in_indices_considered = false;
							  
						  if (are_PSI_in_indices_considered) 
						    {
						      const unsigned int iCn_in = two_jumps_cv_n_inSDn.get_iC ();

						      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);

						      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
							      
						      total_PSI_in_index_zero_inSDn = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*inSDp_index;
						  
						      total_PSI_in_index_dimension_minus_one_inSDn = total_PSI_in_index_zero_inSDn + (dimension_inSDn - 1);
							      
						      if ((total_PSI_in_index_zero_inSDn > last_total_PSI_in_index) || (total_PSI_in_index_dimension_minus_one_inSDn < first_total_PSI_in_index))
							are_PSI_in_indices_considered = false;
						    }
						}
						      
					      if (are_PSI_in_indices_considered)
						{
						  const unsigned int inSDn_index = two_jumps_cv_n_inSDn.get_inSD_index ();

						  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDn + inSDn_index;
							  
						  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						    {
						      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
							      
						      if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index)) non_zero_NBMEs_index_two_jumps++;
						    }}}}}}}}}}}}}
} 










void H_class::non_zero_NBMEs_numbers_two_jumps_cv_part_pn_two_jumps_stored_Zval_larger_calc (const bool is_it_cv_pp_to_nn)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper_2D (0);
      
  const bool is_it_diagonal_square = GSM_vector_helper.get_is_it_diagonal_square ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
    
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();

  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
    
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
    
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
	  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index_column ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index_column ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index_row ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index_row ();

  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_tab = GSM_vector_helper.get_iCn_min_tab_row ();
  const class array<unsigned int> &iCn_out_max_tab = GSM_vector_helper.get_iCn_max_tab_row ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min_row ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max_row ();

  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min_row ();
  
  if (total_outSDp_index_min > total_outSDp_index_max) return;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();
      
      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);

      const int Sp_out = outSDp_qn.get_S ();

      const int Sn_out = S - Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();

      const int n_spec_n_out = n_spec_max - n_spec_p_out;
      
      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;
		  
      const int n_spec_p_in = (is_it_cv_pp_to_nn) ? (n_spec_p_out - 2) : (n_spec_p_out + 2);
      const int n_spec_n_in = (is_it_cv_pp_to_nn) ? (n_spec_n_out + 2) : (n_spec_n_out - 2);

      const int iMn_out = iM - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);

      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();

      const unsigned long int total_outSDp_index_shifted = total_outSDp_index - total_outSDp_index_min;

      const class array<class jumps_data_out_to_in_str> &two_jumps_cv_p_tab = (is_it_cv_pp_to_nn) ? (two_jumps_cv_p_pp_to_nn_tabs(total_outSDp_index_shifted)) : (two_jumps_cv_p_nn_to_pp_tabs(total_outSDp_index_shifted));
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	      
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int total_outSDn_index_zero = SDn_set.index_determine (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , 0);
		  
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDn_index;
		     			  
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned long int total_outSDn_index = total_outSDn_index_zero + outSDn_index;

			  const unsigned long int total_outSDn_index_shifted = total_outSDn_index - total_outSDn_index_min;

			  const class array<class jumps_data_out_to_in_str> &two_jumps_cv_n_tab = (is_it_cv_pp_to_nn) ? (two_jumps_cv_n_pp_to_nn_tabs(total_outSDn_index_shifted)) : (two_jumps_cv_n_nn_to_pp_tabs(total_outSDn_index_shifted));
			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  unsigned int &non_zero_NBMEs_index_two_jumps = non_zero_NBMEs_two_jumps_numbers(PSI_out_index);
			  
			  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
			    {
			      const unsigned int BPn_in = binary_parity_product (BPp_in , BP);

			      for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				{
				  const int Sn_in = S - Sp_in;
		  	  
				  for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
				    {
				      const int iMn_in = iM - iMp_in;
				  
				      const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
				      const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
				      if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
				      if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				  
				      const class jumps_data_out_to_in_str &two_jumps_cv_p = two_jumps_cv_p_tab(BPp_in , Sp_in , Delta_iMp_in);   
				
				      const unsigned int dimension_two_jumps_cv_p = two_jumps_cv_p.get_dimension ();
				      
				      if (dimension_two_jumps_cv_p == 0) continue;

				      const class jumps_data_out_to_in_str &two_jumps_cv_n = two_jumps_cv_n_tab(BPn_in , Sn_in , Delta_iMn_in);
				      				      
				      const unsigned int dimension_two_jumps_cv_n = two_jumps_cv_n.get_dimension ();
					      
				      if (dimension_two_jumps_cv_n == 0) continue;
				      
				      bool are_PSI_in_indices_considered = true;
				      
				      unsigned long int total_PSI_in_index_zero_inSDp = 0;
				  
				      unsigned long int total_PSI_in_index_dimension_minus_one_inSDp = 0;

				      for (unsigned int in = 0 ; in < dimension_two_jumps_cv_n ; in++)  
					{
					  const class jumps_data_inSD_str &two_jumps_cv_n_inSDn = two_jumps_cv_n(in);
						  
					  const unsigned int iCn_in = two_jumps_cv_n_inSDn.get_iC ();

					  const unsigned int inSDn_index = two_jumps_cv_n_inSDn.get_inSD_index ();

					  const int n_holes_n_in = two_jumps_cv_n_inSDn.get_n_holes ();
				      
					  const int n_scat_n_in = two_jumps_cv_n_inSDn.get_n_scat ();

					  const int En_hw_in = two_jumps_cv_n_inSDn.get_E_hw ();

					  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
						  
					  for (unsigned int ip = 0 ; ip < dimension_two_jumps_cv_p ; ip++)
					    {
					      const class jumps_data_inSD_str &two_jumps_cv_p_inSDp = two_jumps_cv_p(ip);

					      const bool is_configuration_changing = two_jumps_cv_p_inSDp.get_is_configuration_changing ();
						      
					      if (is_configuration_changing) 
						{
						  const int n_holes_p_in = two_jumps_cv_p_inSDp.get_n_holes ();
					      
						  const int n_scat_p_in = two_jumps_cv_p_inSDp.get_n_scat ();

						  const int Ep_hw_in = two_jumps_cv_p_inSDp.get_E_hw ();
								      
						  are_PSI_in_indices_considered = true;
									  
						  if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) are_PSI_in_indices_considered = false;

						  if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) are_PSI_in_indices_considered = false;

						  if (are_PSI_in_indices_considered) 
						    {
						      const unsigned int iCp_in = two_jumps_cv_p_inSDp.get_iC ();

						      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);

						      const unsigned int dimension_inSDp = dimensions_SDp_set(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in , iMp_in);
							      
						      total_PSI_in_index_zero_inSDp = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;

						      total_PSI_in_index_dimension_minus_one_inSDp = total_PSI_in_index_zero_inSDp + dimension_inSDn*(dimension_inSDp - 1);
							      
						      if ((total_PSI_in_index_zero_inSDp > last_total_PSI_in_index) || (total_PSI_in_index_dimension_minus_one_inSDp < first_total_PSI_in_index))
							are_PSI_in_indices_considered = false;
						    }
						}
						      
					      if (are_PSI_in_indices_considered)
						{
						  const unsigned int inSDp_index = two_jumps_cv_p_inSDp.get_inSD_index ();

						  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDp + dimension_inSDn*inSDp_index;
							  
						  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						    {
						      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
										  
						      if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index)) non_zero_NBMEs_index_two_jumps++;
						    }}}}}}}}}}}}}
}














void H_class::non_zero_NBMEs_numbers_two_jumps_cv_part_pn_two_jumps_partially_stored_Nval_larger_calc (const bool is_it_cv_pp_to_nn)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper_2D (0);
      
  const bool is_it_diagonal_square = GSM_vector_helper.get_is_it_diagonal_square ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 

  const int S_plus_one = S + 1;

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();  
  const int four_mn_max = neut_Y_data.get_four_m_max ();

  const int four_mn_max_plus_one = four_mn_max + 1;
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
    
  const unsigned int NYval = neut_Y_data.get_N_valence_baryons ();
      
  const unsigned int NY_valence_pairs_number = (NYval*(NYval - 1))/2;
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index_column ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index_column ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index_row ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index_row ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_tab = GSM_vector_helper.get_iCp_min_tab_row ();
  const class array<unsigned int> &iCp_out_max_tab = GSM_vector_helper.get_iCp_max_tab_row ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min_row ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min_row ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max_row ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
    
  class array<class array<class jumps_data_out_to_in_str> > two_jumps_cv_n_tabs_local(NUMBER_OF_THREADS);
  
  class array<class array<bool> > is_two_jumps_cv_n_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      class array<class jumps_data_out_to_in_str> &two_jumps_cv_n_tab = two_jumps_cv_n_tabs_local(i);
      
      two_jumps_cv_n_tab.allocate (2 , S_plus_one , four_mn_max_plus_one);
      
      for (unsigned int BPn_in = 0 ; BPn_in <= 1 ; BPn_in++)
	for (int Sn_in = 0 ; Sn_in <= S ; Sn_in++)
	  for (int Delta_iMn_in = 0 ; Delta_iMn_in <= four_mn_max ; Delta_iMn_in++)
	    two_jumps_cv_n_tab(BPn_in , Sn_in , Delta_iMn_in).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , NY_valence_pairs_number);
      
      is_two_jumps_cv_n_calculated_tabs(i).allocate (2 , S_plus_one , four_mn_max_plus_one);
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();

      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();
      
      const unsigned int BPp_out = binary_parity_product (BPn_out , BP);

      const int Sn_out = outSDn_qn.get_S ();

      const int Sp_out = S - Sn_out;
      
      const int n_spec_n_out = outSDn_qn.get_n_spec ();

      const int n_spec_p_out = n_spec_max - n_spec_n_out;
      
      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;
		  
      const int n_spec_p_in = (is_it_cv_pp_to_nn) ? (n_spec_p_out - 2) : (n_spec_p_out + 2);
      const int n_spec_n_in = (is_it_cv_pp_to_nn) ? (n_spec_n_out + 2) : (n_spec_n_out - 2);
		  
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const int iMp_out = iM - iMn_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class array<class jumps_data_out_to_in_str> &two_jumps_cv_n_tab = two_jumps_cv_n_tabs_local(i_thread);
      
      class array<bool> &is_two_jumps_cv_n_calculated_tab = is_two_jumps_cv_n_calculated_tabs(i_thread);
  
      is_two_jumps_cv_n_calculated_tab = false;
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;
	      
	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
	      
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int total_outSDp_index_zero = SDp_set.index_determine (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , 0);
      
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDp_index*dimension_outSDn;
      
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned long int total_outSDp_index = total_outSDp_index_zero + outSDp_index;

			  const unsigned long int total_outSDp_index_shifted = total_outSDp_index - total_outSDp_index_min;

			  const class array<class jumps_data_out_to_in_str> &two_jumps_cv_p_tab = (is_it_cv_pp_to_nn) ? (two_jumps_cv_p_pp_to_nn_tabs(total_outSDp_index_shifted)) : (two_jumps_cv_p_nn_to_pp_tabs(total_outSDp_index_shifted));
			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  unsigned int &non_zero_NBMEs_index_two_jumps = non_zero_NBMEs_two_jumps_numbers(PSI_out_index);
					
			  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
			    {
			      const unsigned int BPn_in = binary_parity_product (BPp_in , BP);

			      for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				{
				  const int Sn_in = S - Sp_in;
		  	  
				  for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
				    {
				      const int iMn_in = iM - iMp_in;

				      const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
				      const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
				      if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
				      if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				  
				      class jumps_data_out_to_in_str &two_jumps_cv_n = two_jumps_cv_n_tab(BPn_in , Sn_in , Delta_iMn_in); 

				      bool &is_two_jumps_cv_n_calculated = is_two_jumps_cv_n_calculated_tab(BPn_in , Sn_in , Delta_iMn_in);

				      if (!is_two_jumps_cv_n_calculated)
					{
					  two_jumps_cv_n.two_jumps_mu_store (0 , BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw ,
									     BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , !is_it_cv_pp_to_nn , is_it_cv_pp_to_nn , neut_Y_data);
				      
					  is_two_jumps_cv_n_calculated = true;
					}
				
				      const unsigned int dimension_two_jumps_cv_n = two_jumps_cv_n.get_dimension ();
				      
				      if (dimension_two_jumps_cv_n == 0) continue;
				      
				      const class jumps_data_out_to_in_str &two_jumps_cv_p = two_jumps_cv_p_tab(BPp_in , Sp_in , Delta_iMp_in);
				      
				      const unsigned int dimension_two_jumps_cv_p = two_jumps_cv_p.get_dimension ();
				  
				      if (dimension_two_jumps_cv_p == 0) continue;
				      
				      unsigned long int total_PSI_in_index_zero_inSDn = 0;
				  
				      unsigned long int total_PSI_in_index_dimension_minus_one_inSDn = 0;
				  
				      bool are_PSI_in_indices_considered = true;
  
				      for (unsigned int ip = 0 ; ip < dimension_two_jumps_cv_p ; ip++)  
					{
					  const class jumps_data_inSD_str &two_jumps_cv_p_inSDp = two_jumps_cv_p(ip);

					  const unsigned int iCp_in = two_jumps_cv_p_inSDp.get_iC ();

					  const unsigned int inSDp_index = two_jumps_cv_p_inSDp.get_inSD_index ();

					  const int n_holes_p_in = two_jumps_cv_p_inSDp.get_n_holes ();
				      
					  const int n_scat_p_in = two_jumps_cv_p_inSDp.get_n_scat ();

					  const int Ep_hw_in = two_jumps_cv_p_inSDp.get_E_hw ();
												  
					  for (unsigned int in = 0 ; in < dimension_two_jumps_cv_n ; in++)
					    {
					      const class jumps_data_inSD_str &two_jumps_cv_n_inSDn = two_jumps_cv_n(in);

					      const bool is_configuration_changing = two_jumps_cv_n_inSDn.get_is_configuration_changing ();

					      if (is_configuration_changing) 
						{
						  const int n_holes_n_in = two_jumps_cv_n_inSDn.get_n_holes ();
					      
						  const int n_scat_n_in = two_jumps_cv_n_inSDn.get_n_scat ();

						  const int En_hw_in = two_jumps_cv_n_inSDn.get_E_hw ();
								  
						  are_PSI_in_indices_considered = true;
							  
						  if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) are_PSI_in_indices_considered = false;
					      
						  if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) are_PSI_in_indices_considered = false;
							  
						  if (are_PSI_in_indices_considered) 
						    {
						      const unsigned int iCn_in = two_jumps_cv_n_inSDn.get_iC ();

						      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);

						      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
							      
						      total_PSI_in_index_zero_inSDn = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*inSDp_index;
						  
						      total_PSI_in_index_dimension_minus_one_inSDn = total_PSI_in_index_zero_inSDn + (dimension_inSDn - 1);
							      
						      if ((total_PSI_in_index_zero_inSDn > last_total_PSI_in_index) || (total_PSI_in_index_dimension_minus_one_inSDn < first_total_PSI_in_index))
							are_PSI_in_indices_considered = false;
						    }
						}
						      
					      if (are_PSI_in_indices_considered)
						{
						  const unsigned int inSDn_index = two_jumps_cv_n_inSDn.get_inSD_index ();

						  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDn + inSDn_index;
							  
						  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						    {
						      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
							      
						      if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index)) non_zero_NBMEs_index_two_jumps++;
						    }}}}}}}}}}}}}
} 










void H_class::non_zero_NBMEs_numbers_two_jumps_cv_part_pn_two_jumps_partially_stored_Zval_larger_calc (const bool is_it_cv_pp_to_nn)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper_2D (0);
      
  const bool is_it_diagonal_square = GSM_vector_helper.get_is_it_diagonal_square ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
    
  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int S_plus_one = S + 1;
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();

  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();

  const int four_mp_max_plus_one = four_mp_max + 1;
    
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
  
  const unsigned int ZYval = prot_Y_data.get_N_valence_baryons ();
      
  const unsigned int ZY_valence_pairs_number = (ZYval*(ZYval - 1))/2;
    
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
	  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index_column ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index_column ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index_row ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index_row ();

  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_tab = GSM_vector_helper.get_iCn_min_tab_row ();
  const class array<unsigned int> &iCn_out_max_tab = GSM_vector_helper.get_iCn_max_tab_row ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min_row ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max_row ();

  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min_row ();
  
  if (total_outSDp_index_min > total_outSDp_index_max) return;
  
  class array<class array<class jumps_data_out_to_in_str> > two_jumps_cv_p_tabs_local(NUMBER_OF_THREADS);
  
  class array<class array<bool> > is_two_jumps_cv_p_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      class array<class jumps_data_out_to_in_str> &two_jumps_cv_p_tab = two_jumps_cv_p_tabs_local(i);
      
      two_jumps_cv_p_tab.allocate (2 , S_plus_one , four_mp_max_plus_one);
      
      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
	for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
	  for (int Delta_iMp_in = 0 ; Delta_iMp_in <= four_mp_max ; Delta_iMp_in++)
	    two_jumps_cv_p_tab(BPp_in , Sp_in , Delta_iMp_in).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , ZY_valence_pairs_number);
      
      is_two_jumps_cv_p_calculated_tabs(i).allocate (2 , S_plus_one , four_mp_max_plus_one);
    }  

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();
      
      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);

      const int Sp_out = outSDp_qn.get_S ();

      const int Sn_out = S - Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();

      const int n_spec_n_out = n_spec_max - n_spec_p_out;
      
      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;
		  
      const int n_spec_p_in = (is_it_cv_pp_to_nn) ? (n_spec_p_out - 2) : (n_spec_p_out + 2);
      const int n_spec_n_in = (is_it_cv_pp_to_nn) ? (n_spec_n_out + 2) : (n_spec_n_out - 2);

      const int iMn_out = iM - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);

      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();

      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class array<class jumps_data_out_to_in_str> &two_jumps_cv_p_tab = two_jumps_cv_p_tabs_local(i_thread);
      
      class array<bool> &is_two_jumps_cv_p_calculated_tab = is_two_jumps_cv_p_calculated_tabs(i_thread);
            
      is_two_jumps_cv_p_calculated_tab = false;
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	      
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int total_outSDn_index_zero = SDn_set.index_determine (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , 0);
		  
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDn_index;
		     			  
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned long int total_outSDn_index = total_outSDn_index_zero + outSDn_index;

			  const unsigned long int total_outSDn_index_shifted = total_outSDn_index - total_outSDn_index_min;

			  const class array<class jumps_data_out_to_in_str> &two_jumps_cv_n_tab = (is_it_cv_pp_to_nn) ? (two_jumps_cv_n_pp_to_nn_tabs(total_outSDn_index_shifted)) : (two_jumps_cv_n_nn_to_pp_tabs(total_outSDn_index_shifted));
			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  unsigned int &non_zero_NBMEs_index_two_jumps = non_zero_NBMEs_two_jumps_numbers(PSI_out_index);
			  
			  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
			    {
			      const unsigned int BPn_in = binary_parity_product (BPp_in , BP);

			      for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				{
				  const int Sn_in = S - Sp_in;
		  	      
				  for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
				    {
				      const int iMn_in = iM - iMp_in;
				  
				      const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
				      const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
				      if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
				      if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				  
				      class jumps_data_out_to_in_str &two_jumps_cv_p = two_jumps_cv_p_tab(BPp_in , Sp_in , Delta_iMp_in);

				      bool &is_two_jumps_cv_p_calculated = is_two_jumps_cv_p_calculated_tab(BPp_in , Sp_in , Delta_iMp_in);

				      if (!is_two_jumps_cv_p_calculated)
					{
					  two_jumps_cv_p.two_jumps_mu_store (0 , BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw ,
									     BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , is_it_cv_pp_to_nn , !is_it_cv_pp_to_nn , prot_Y_data);
				      
					  is_two_jumps_cv_p_calculated = true;
					}
				
				      const unsigned int dimension_two_jumps_cv_p = two_jumps_cv_p.get_dimension ();
				      
				      if (dimension_two_jumps_cv_p == 0) continue;

				      const class jumps_data_out_to_in_str &two_jumps_cv_n = two_jumps_cv_n_tab(BPn_in , Sn_in , Delta_iMn_in);
				      				      
				      const unsigned int dimension_two_jumps_cv_n = two_jumps_cv_n.get_dimension ();
					      
				      if (dimension_two_jumps_cv_n == 0) continue;
				      
				      bool are_PSI_in_indices_considered = true;
				      
				      unsigned long int total_PSI_in_index_zero_inSDp = 0;
				  
				      unsigned long int total_PSI_in_index_dimension_minus_one_inSDp = 0;

				      for (unsigned int in = 0 ; in < dimension_two_jumps_cv_n ; in++)  
					{
					  const class jumps_data_inSD_str &two_jumps_cv_n_inSDn = two_jumps_cv_n(in);
						  
					  const unsigned int iCn_in = two_jumps_cv_n_inSDn.get_iC ();

					  const unsigned int inSDn_index = two_jumps_cv_n_inSDn.get_inSD_index ();

					  const int n_holes_n_in = two_jumps_cv_n_inSDn.get_n_holes ();
				      
					  const int n_scat_n_in = two_jumps_cv_n_inSDn.get_n_scat ();

					  const int En_hw_in = two_jumps_cv_n_inSDn.get_E_hw ();

					  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
						  
					  for (unsigned int ip = 0 ; ip < dimension_two_jumps_cv_p ; ip++)
					    {
					      const class jumps_data_inSD_str &two_jumps_cv_p_inSDp = two_jumps_cv_p(ip);

					      const bool is_configuration_changing = two_jumps_cv_p_inSDp.get_is_configuration_changing ();
						      
					      if (is_configuration_changing) 
						{
						  const int n_holes_p_in = two_jumps_cv_p_inSDp.get_n_holes ();
					      
						  const int n_scat_p_in = two_jumps_cv_p_inSDp.get_n_scat ();

						  const int Ep_hw_in = two_jumps_cv_p_inSDp.get_E_hw ();
								      
						  are_PSI_in_indices_considered = true;
									  
						  if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) are_PSI_in_indices_considered = false;

						  if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) are_PSI_in_indices_considered = false;

						  if (are_PSI_in_indices_considered) 
						    {
						      const unsigned int iCp_in = two_jumps_cv_p_inSDp.get_iC ();

						      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);

						      const unsigned int dimension_inSDp = dimensions_SDp_set(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in , iMp_in);
							      
						      total_PSI_in_index_zero_inSDp = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;

						      total_PSI_in_index_dimension_minus_one_inSDp = total_PSI_in_index_zero_inSDp + dimension_inSDn*(dimension_inSDp - 1);
							      
						      if ((total_PSI_in_index_zero_inSDp > last_total_PSI_in_index) || (total_PSI_in_index_dimension_minus_one_inSDp < first_total_PSI_in_index))
							are_PSI_in_indices_considered = false;
						    }
						}
						      
					      if (are_PSI_in_indices_considered)
						{
						  const unsigned int inSDp_index = two_jumps_cv_p_inSDp.get_inSD_index ();

						  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDp + dimension_inSDn*inSDp_index;
							  
						  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						    {
						      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
										  
						      if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index)) non_zero_NBMEs_index_two_jumps++;
						    }}}}}}}}}}}}}
}














void H_class::non_zero_NBMEs_numbers_two_jumps_cv_part_pn_two_jumps_recalculated_Nval_larger_calc (const bool is_it_cv_pp_to_nn)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper_2D (0);
      
  const bool is_it_diagonal_square = GSM_vector_helper.get_is_it_diagonal_square ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 
  
  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 

  const int S_plus_one = S + 1;

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();  
  const int four_mn_max = neut_Y_data.get_four_m_max ();

  const int four_mn_max_plus_one = four_mn_max + 1;
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
    
  const unsigned int ZYval = prot_Y_data.get_N_valence_baryons ();
  const unsigned int NYval = neut_Y_data.get_N_valence_baryons ();
      
  const unsigned int ZY_valence_pairs_number = (ZYval*(ZYval - 1))/2;
  const unsigned int NY_valence_pairs_number = (NYval*(NYval - 1))/2;
    
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index_column ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index_column ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index_row ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index_row ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_tab = GSM_vector_helper.get_iCp_min_tab_row ();
  const class array<unsigned int> &iCp_out_max_tab = GSM_vector_helper.get_iCp_max_tab_row ();
    
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min_row ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max_row ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
    
  class array<class jumps_data_out_to_in_str> two_jumps_cv_p_tab(NUMBER_OF_THREADS);
  
  class array<class array<class jumps_data_out_to_in_str> > two_jumps_cv_n_tabs_local(NUMBER_OF_THREADS);
  
  class array<class array<bool> > is_two_jumps_cv_n_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      two_jumps_cv_p_tab(i).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , ZY_valence_pairs_number);
	  
      class array<class jumps_data_out_to_in_str> &two_jumps_cv_n_tab = two_jumps_cv_n_tabs_local(i);
      
      two_jumps_cv_n_tab.allocate (2 , S_plus_one , four_mn_max_plus_one);
      
      for (unsigned int BPn_in = 0 ; BPn_in <= 1 ; BPn_in++)
	for (int Sn_in = 0 ; Sn_in <= S ; Sn_in++)
	  for (int Delta_iMn_in = 0 ; Delta_iMn_in <= four_mn_max ; Delta_iMn_in++)
	    two_jumps_cv_n_tab(BPn_in , Sn_in , Delta_iMn_in).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , NY_valence_pairs_number);
      
      is_two_jumps_cv_n_calculated_tabs(i).allocate (2 , S_plus_one , four_mn_max_plus_one);
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();

      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();
      
      const unsigned int BPp_out = binary_parity_product (BPn_out , BP);

      const int Sn_out = outSDn_qn.get_S ();

      const int Sp_out = S - Sn_out;
      
      const int n_spec_n_out = outSDn_qn.get_n_spec ();

      const int n_spec_p_out = n_spec_max - n_spec_n_out;
      
      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;
		  
      const int n_spec_p_in = (is_it_cv_pp_to_nn) ? (n_spec_p_out - 2) : (n_spec_p_out + 2);
      const int n_spec_n_in = (is_it_cv_pp_to_nn) ? (n_spec_n_out + 2) : (n_spec_n_out - 2);
		  
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const int iMp_out = iM - iMn_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class jumps_data_out_to_in_str &two_jumps_cv_p = two_jumps_cv_p_tab(i_thread);
  
      class array<class jumps_data_out_to_in_str> &two_jumps_cv_n_tab = two_jumps_cv_n_tabs_local(i_thread);
      
      class array<bool> &is_two_jumps_cv_n_calculated_tab = is_two_jumps_cv_n_calculated_tabs(i_thread);
  
      is_two_jumps_cv_n_calculated_tab = false;
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
	      
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{      
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDp_index*dimension_outSDn;
      
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  unsigned int &non_zero_NBMEs_index_two_jumps = non_zero_NBMEs_two_jumps_numbers(PSI_out_index);
					
			  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
			    {
			      const unsigned int BPn_in = binary_parity_product (BPp_in , BP);

			      for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				{
				  const int Sn_in = S - Sp_in;
		  	  
				  for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
				    {
				      const int iMn_in = iM - iMp_in;

				      const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
				      const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
				      if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
				      if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				  
				      class jumps_data_out_to_in_str &two_jumps_cv_n = two_jumps_cv_n_tab(BPn_in , Sn_in , Delta_iMn_in); 

				      bool &is_two_jumps_cv_n_calculated = is_two_jumps_cv_n_calculated_tab(BPn_in , Sn_in , Delta_iMn_in);

				      if (!is_two_jumps_cv_n_calculated)
					{
					  two_jumps_cv_n.two_jumps_mu_store (0 , BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw ,
									     BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , !is_it_cv_pp_to_nn , is_it_cv_pp_to_nn , neut_Y_data);
				      
					  is_two_jumps_cv_n_calculated = true;
					}
				
				      const unsigned int dimension_two_jumps_cv_n = two_jumps_cv_n.get_dimension ();
				      
				      if (dimension_two_jumps_cv_n == 0) continue;
				      
				      two_jumps_cv_p.two_jumps_mu_store (0 , BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw ,
									 BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , is_it_cv_pp_to_nn , !is_it_cv_pp_to_nn , prot_Y_data);
				      
				      const unsigned int dimension_two_jumps_cv_p = two_jumps_cv_p.get_dimension ();
				  
				      if (dimension_two_jumps_cv_p == 0) continue;
				      
				      unsigned long int total_PSI_in_index_zero_inSDn = 0;
				  
				      unsigned long int total_PSI_in_index_dimension_minus_one_inSDn = 0;
				  
				      bool are_PSI_in_indices_considered = true;
  
				      for (unsigned int ip = 0 ; ip < dimension_two_jumps_cv_p ; ip++)  
					{
					  const class jumps_data_inSD_str &two_jumps_cv_p_inSDp = two_jumps_cv_p(ip);

					  const unsigned int iCp_in = two_jumps_cv_p_inSDp.get_iC ();

					  const unsigned int inSDp_index = two_jumps_cv_p_inSDp.get_inSD_index ();

					  const int n_holes_p_in = two_jumps_cv_p_inSDp.get_n_holes ();
				      
					  const int n_scat_p_in = two_jumps_cv_p_inSDp.get_n_scat ();

					  const int Ep_hw_in = two_jumps_cv_p_inSDp.get_E_hw ();
												  
					  for (unsigned int in = 0 ; in < dimension_two_jumps_cv_n ; in++)
					    {
					      const class jumps_data_inSD_str &two_jumps_cv_n_inSDn = two_jumps_cv_n(in);

					      const bool is_configuration_changing = two_jumps_cv_n_inSDn.get_is_configuration_changing ();

					      if (is_configuration_changing) 
						{
						  const int n_holes_n_in = two_jumps_cv_n_inSDn.get_n_holes ();
					      
						  const int n_scat_n_in = two_jumps_cv_n_inSDn.get_n_scat ();

						  const int En_hw_in = two_jumps_cv_n_inSDn.get_E_hw ();
								  
						  are_PSI_in_indices_considered = true;
							  
						  if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) are_PSI_in_indices_considered = false;
					      
						  if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) are_PSI_in_indices_considered = false;
							  
						  if (are_PSI_in_indices_considered) 
						    {
						      const unsigned int iCn_in = two_jumps_cv_n_inSDn.get_iC ();

						      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);

						      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
							      
						      total_PSI_in_index_zero_inSDn = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*inSDp_index;
						  
						      total_PSI_in_index_dimension_minus_one_inSDn = total_PSI_in_index_zero_inSDn + (dimension_inSDn - 1);
							      
						      if ((total_PSI_in_index_zero_inSDn > last_total_PSI_in_index) || (total_PSI_in_index_dimension_minus_one_inSDn < first_total_PSI_in_index))
							are_PSI_in_indices_considered = false;
						    }
						}
						      
					      if (are_PSI_in_indices_considered)
						{
						  const unsigned int inSDn_index = two_jumps_cv_n_inSDn.get_inSD_index ();

						  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDn + inSDn_index;
							  
						  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						    {
						      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
							      
						      if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index)) non_zero_NBMEs_index_two_jumps++;
						    }}}}}}}}}}}}}
} 










void H_class::non_zero_NBMEs_numbers_two_jumps_cv_part_pn_two_jumps_recalculated_Zval_larger_calc (const bool is_it_cv_pp_to_nn)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper_2D (0);
      
  const bool is_it_diagonal_square = GSM_vector_helper.get_is_it_diagonal_square ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int S_plus_one = S + 1;
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();

  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();

  const int four_mp_max_plus_one = four_mp_max + 1;
    
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
  
  const unsigned int ZYval = prot_Y_data.get_N_valence_baryons ();
  const unsigned int NYval = neut_Y_data.get_N_valence_baryons ();
      
  const unsigned int ZY_valence_pairs_number = (ZYval*(ZYval - 1))/2;
  const unsigned int NY_valence_pairs_number = (NYval*(NYval - 1))/2;
    	  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index_column ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index_column ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index_row ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index_row ();

  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_tab = GSM_vector_helper.get_iCn_min_tab_row ();
  const class array<unsigned int> &iCn_out_max_tab = GSM_vector_helper.get_iCn_max_tab_row ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min_row ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max_row ();
  
  if (total_outSDp_index_min > total_outSDp_index_max) return;
  
  class array<class jumps_data_out_to_in_str> two_jumps_cv_n_tab(NUMBER_OF_THREADS);
  
  class array<class array<class jumps_data_out_to_in_str> > two_jumps_cv_p_tabs_local(NUMBER_OF_THREADS);
  
  class array<class array<bool> > is_two_jumps_cv_p_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      two_jumps_cv_n_tab(i).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , NY_valence_pairs_number);
      
      class array<class jumps_data_out_to_in_str> &two_jumps_cv_p_tab = two_jumps_cv_p_tabs_local(i);
      
      two_jumps_cv_p_tab.allocate (2 , S_plus_one , four_mp_max_plus_one);
      
      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
	for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
	  for (int Delta_iMp_in = 0 ; Delta_iMp_in <= four_mp_max ; Delta_iMp_in++)
	    two_jumps_cv_p_tab(BPp_in , Sp_in , Delta_iMp_in).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , ZY_valence_pairs_number);
      
      is_two_jumps_cv_p_calculated_tabs(i).allocate (2 , S_plus_one , four_mp_max_plus_one);
    }  

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();
      
      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);
      
      const int Sp_out = outSDp_qn.get_S ();

      const int Sn_out = S - Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();

      const int n_spec_n_out = n_spec_max - n_spec_p_out;
      
      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;
		  
      const int n_spec_p_in = (is_it_cv_pp_to_nn) ? (n_spec_p_out - 2) : (n_spec_p_out + 2);
      const int n_spec_n_in = (is_it_cv_pp_to_nn) ? (n_spec_n_out + 2) : (n_spec_n_out - 2);

      const int iMn_out = iM - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);

      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();

      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class jumps_data_out_to_in_str &two_jumps_cv_n = two_jumps_cv_n_tab(i_thread);
      
      class array<class jumps_data_out_to_in_str> &two_jumps_cv_p_tab = two_jumps_cv_p_tabs_local(i_thread);
      
      class array<bool> &is_two_jumps_cv_p_calculated_tab = is_two_jumps_cv_p_calculated_tabs(i_thread);
            
      is_two_jumps_cv_p_calculated_tab = false;
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	      
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{		  
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDn_index;
		     			  
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  unsigned int &non_zero_NBMEs_index_two_jumps = non_zero_NBMEs_two_jumps_numbers(PSI_out_index);
			  
			  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
			    {
			      const unsigned int BPn_in = binary_parity_product (BPp_in , BP);

			      for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				{
				  const int Sn_in = S - Sp_in;
		  	  
				  for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
				    {
				      const int iMn_in = iM - iMp_in;
				  
				      const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
				      const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
				      if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
				      if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				  
				      class jumps_data_out_to_in_str &two_jumps_cv_p = two_jumps_cv_p_tab(BPp_in , Sp_in , Delta_iMp_in);

				      bool &is_two_jumps_cv_p_calculated = is_two_jumps_cv_p_calculated_tab(BPp_in , Sp_in , Delta_iMp_in);

				      if (!is_two_jumps_cv_p_calculated)
					{
					  two_jumps_cv_p.two_jumps_mu_store (0 , BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw ,
									     BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , is_it_cv_pp_to_nn , !is_it_cv_pp_to_nn , prot_Y_data);
				      
					  is_two_jumps_cv_p_calculated = true;
					}
				
				      const unsigned int dimension_two_jumps_cv_p = two_jumps_cv_p.get_dimension ();
				      
				      if (dimension_two_jumps_cv_p == 0) continue;

				      two_jumps_cv_n.two_jumps_mu_store (0 , BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw ,
									 BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , !is_it_cv_pp_to_nn , is_it_cv_pp_to_nn , neut_Y_data);
				      				      
				      const unsigned int dimension_two_jumps_cv_n = two_jumps_cv_n.get_dimension ();
					      
				      if (dimension_two_jumps_cv_n == 0) continue;
				      
				      bool are_PSI_in_indices_considered = true;
				      
				      unsigned long int total_PSI_in_index_zero_inSDp = 0;
				  
				      unsigned long int total_PSI_in_index_dimension_minus_one_inSDp = 0;

				      for (unsigned int in = 0 ; in < dimension_two_jumps_cv_n ; in++)  
					{
					  const class jumps_data_inSD_str &two_jumps_cv_n_inSDn = two_jumps_cv_n(in);
						  
					  const unsigned int iCn_in = two_jumps_cv_n_inSDn.get_iC ();

					  const unsigned int inSDn_index = two_jumps_cv_n_inSDn.get_inSD_index ();

					  const int n_holes_n_in = two_jumps_cv_n_inSDn.get_n_holes ();
				      
					  const int n_scat_n_in = two_jumps_cv_n_inSDn.get_n_scat ();

					  const int En_hw_in = two_jumps_cv_n_inSDn.get_E_hw ();

					  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
						  
					  for (unsigned int ip = 0 ; ip < dimension_two_jumps_cv_p ; ip++)
					    {
					      const class jumps_data_inSD_str &two_jumps_cv_p_inSDp = two_jumps_cv_p(ip);

					      const bool is_configuration_changing = two_jumps_cv_p_inSDp.get_is_configuration_changing ();
						      
					      if (is_configuration_changing) 
						{
						  const int n_holes_p_in = two_jumps_cv_p_inSDp.get_n_holes ();
					      
						  const int n_scat_p_in = two_jumps_cv_p_inSDp.get_n_scat ();

						  const int Ep_hw_in = two_jumps_cv_p_inSDp.get_E_hw ();
								      
						  are_PSI_in_indices_considered = true;
									  
						  if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) are_PSI_in_indices_considered = false;

						  if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) are_PSI_in_indices_considered = false;

						  if (are_PSI_in_indices_considered) 
						    {
						      const unsigned int iCp_in = two_jumps_cv_p_inSDp.get_iC ();

						      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);

						      const unsigned int dimension_inSDp = dimensions_SDp_set(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in , iMp_in);
							      
						      total_PSI_in_index_zero_inSDp = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;

						      total_PSI_in_index_dimension_minus_one_inSDp = total_PSI_in_index_zero_inSDp + dimension_inSDn*(dimension_inSDp - 1);
							      
						      if ((total_PSI_in_index_zero_inSDp > last_total_PSI_in_index) || (total_PSI_in_index_dimension_minus_one_inSDp < first_total_PSI_in_index))
							are_PSI_in_indices_considered = false;
						    }
						}
						      
					      if (are_PSI_in_indices_considered)
						{
						  const unsigned int inSDp_index = two_jumps_cv_p_inSDp.get_inSD_index ();

						  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDp + dimension_inSDn*inSDp_index;
							  
						  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						    {
						      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
										  
						      if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index)) non_zero_NBMEs_index_two_jumps++;
						    }}}}}}}}}}}}}
}































void H_class::non_zero_NBMEs_numbers_off_diagonal_pp_nn_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper_2D (0);
  
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 
  
  const int S = GSM_vector_helper.get_S ();
  
  const int iM = GSM_vector_helper.get_iM (); 
        
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector (); 
  
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  const unsigned int dimension_1p1h_space_BP_S_iM_fixed_max = data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  const unsigned int dimension_2p2h_space_BP_S_iM_fixed_max = data.get_dimension_2p2h_space_BP_S_iM_fixed_max ();
    
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
    
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index_row ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index_row ();

  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_outSD_index_min = GSM_vector_helper.get_total_SD_index_min_row ();
  const unsigned long int total_outSD_index_max = GSM_vector_helper.get_total_SD_index_max_row ();

  if (total_outSD_index_min > total_outSD_index_max) return;
      
  class array<class jumps_data_out_to_in_str> one_jump_mu_tab(NUMBER_OF_THREADS);
  class array<class jumps_data_out_to_in_str> two_jumps_mu_tab(NUMBER_OF_THREADS);
  
  class array<class array<bool> > are_PSI_in_indices_accepted_one_jump_mu_tab(NUMBER_OF_THREADS);
  class array<class array<bool> > are_PSI_in_indices_accepted_two_jumps_mu_tab(NUMBER_OF_THREADS);
      
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_mu_tab(i).allocate (ONE_JUMP , space , truncation_hw , truncation_ph , dimension_1p1h_space_BP_S_iM_fixed_max);
      
      are_PSI_in_indices_accepted_one_jump_mu_tab(i).allocate (dimension_1p1h_space_BP_S_iM_fixed_max);
      
      if (N_valence_baryons >= 2)
	{
	  two_jumps_mu_tab(i).allocate (TWO_JUMPS , space , truncation_hw , truncation_ph , dimension_2p2h_space_BP_S_iM_fixed_max);
		
	  are_PSI_in_indices_accepted_two_jumps_mu_tab(i).allocate (dimension_2p2h_space_BP_S_iM_fixed_max);
	}      
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSD_index = total_outSD_index_min ; total_outSD_index <= total_outSD_index_max ; total_outSD_index++)
    {
      const class SD_quantum_numbers &outSD_qn = SD_quantum_numbers_tab(total_outSD_index);
      
      const unsigned int BP_out = outSD_qn.get_BP ();

      if (BP_out != BP) continue;
      
      const int S_out = outSD_qn.get_S ();

      if (S_out != S) continue;

      const int iM_out = outSD_qn.get_iM ();

      if (iM_out != iM) continue;
      
      const unsigned int n_scat_out = outSD_qn.get_n_scat ();

      const unsigned int iC_out = outSD_qn.get_iC ();

      const int n_holes_out = n_holes_table(BP , S , 0 , n_scat_out , iC_out);
      
      const int E_out_hw = E_hw_table(BP , S , 0 , n_scat_out , iC_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
      
      const unsigned int outSD_index = outSD_qn.get_SD_index ();

      const unsigned long int sum_dimensions_configuration_fixed_out = sum_dimensions_GSM_vector(n_scat_out , iC_out);

      const unsigned long int total_PSI_out_index = sum_dimensions_configuration_fixed_out + outSD_index;
      
      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
	{
	  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
	  
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	
	  class jumps_data_out_to_in_str &one_jump_mu  = one_jump_mu_tab(i_thread);  
	  class jumps_data_out_to_in_str &two_jumps_mu = two_jumps_mu_tab(i_thread);

	  class array<bool> &are_PSI_in_indices_accepted_one_jump_mu  = are_PSI_in_indices_accepted_one_jump_mu_tab(i_thread);
	  class array<bool> &are_PSI_in_indices_accepted_two_jumps_mu = are_PSI_in_indices_accepted_two_jumps_mu_tab(i_thread);

	  one_jump_mu.one_jump_mu_store (0 , BP , S , 0 , iM , n_holes_max , n_scat_max , E_max_hw , BP , S , 0 , n_scat_out , iC_out , iM , outSD_index , data);

	  const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();

	  bool is_there_one_jump_calc = (dimension_one_jump_mu > 0);
      
	  if (is_there_one_jump_calc)
	    {
	      are_PSI_in_indices_accepted_pp_nn_fill_symmetric_case (one_jump_mu , GSM_vector_helper , PSI_out_index , are_PSI_in_indices_accepted_one_jump_mu , is_there_one_jump_calc);
	  
	      if (is_there_one_jump_calc) non_zero_NBMEs_one_jump_numbers(PSI_out_index) += non_zero_NBMEs_numbers_pp_nn_calc (one_jump_mu , are_PSI_in_indices_accepted_one_jump_mu);
	    }
             
	  if (N_valence_baryons >= 2)
	    {
	      two_jumps_mu.two_jumps_mu_store (0 , BP , S , 0 , iM , n_holes_max , n_scat_max , E_max_hw , BP , S , 0 , n_scat_out , iC_out , iM , outSD_index , false , false , data);

	      const unsigned int dimension_two_jumps_mu = two_jumps_mu.get_dimension ();
      
	      bool are_there_two_jumps_calc = (dimension_two_jumps_mu > 0);
		      
	      if (are_there_two_jumps_calc)
		{
		  are_PSI_in_indices_accepted_pp_nn_fill_symmetric_case (two_jumps_mu , GSM_vector_helper , PSI_out_index , are_PSI_in_indices_accepted_two_jumps_mu , are_there_two_jumps_calc);		    

		  if (are_there_two_jumps_calc) non_zero_NBMEs_two_jumps_numbers(PSI_out_index) += non_zero_NBMEs_numbers_pp_nn_calc (two_jumps_mu , are_PSI_in_indices_accepted_two_jumps_mu);	    
		}
	    }
	}
    }
}









  
void H_class::non_zero_NBMEs_off_diagonal_numbers_calc ()
{
  const class GSM_vector_helper_class dummy_helper;
  
  class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper_2D (0);
  
  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);
    
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const bool is_it_one_body = (!is_pp_non_zero && !is_nn_non_zero && !is_pn_non_zero);
  
  class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  non_zero_NBMEs_one_jump_numbers  = 0;
  non_zero_NBMEs_two_jumps_numbers = 0;

  if (configuration_SD_1ph_2ph_tables_to_recalculate)
    configuration_SD_in_out_in_space_1ph_2ph_tables_alloc_calc (is_there_cout , false , is_it_one_body , 0 , GSM_vector_helper , GSM_vector_helper , dummy_helper , prot_Y_data , neut_Y_data);
  
  if (space == PROT_NEUT_Y)
    {   
      class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
      class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
      
      const int ZYval = prot_Y_data.get_N_valence_baryons ();
      const int NYval = neut_Y_data.get_N_valence_baryons ();
	  
      if (is_one_body_p_non_zero || is_pp_non_zero || is_pn_non_zero) non_zero_NBMEs_numbers_jumps_p_part_pn_calc ();
      if (is_one_body_n_non_zero || is_nn_non_zero || is_pn_non_zero) non_zero_NBMEs_numbers_jumps_n_part_pn_calc ();  
       
      if (is_pn_non_zero)
	{	  
	  switch (one_jumps_pn_two_jumps_cv_storage)
	    {
	    case FULL_STORAGE:
	      {
		if (NYval >= ZYval)
		  non_zero_NBMEs_numbers_two_jumps_pn_part_pn_one_jumps_stored_Nval_larger_calc ();
		else
		  non_zero_NBMEs_numbers_two_jumps_pn_part_pn_one_jumps_stored_Zval_larger_calc ();
	      } break;

	    case PARTIAL_STORAGE:
	      {
		if (NYval >= ZYval)
		  non_zero_NBMEs_numbers_two_jumps_pn_part_pn_one_jumps_partially_stored_Nval_larger_calc ();
		else
		  non_zero_NBMEs_numbers_two_jumps_pn_part_pn_one_jumps_partially_stored_Zval_larger_calc ();
	      } break;

	    case ON_THE_FLY:
	      {
		if (NYval >= ZYval)
		  non_zero_NBMEs_numbers_two_jumps_pn_part_pn_one_jumps_recalculated_Nval_larger_calc ();
		else
		  non_zero_NBMEs_numbers_two_jumps_pn_part_pn_one_jumps_recalculated_Zval_larger_calc ();
	      } break;

	    default: abort_all ();
	    }
	}
      
      if (is_cv_non_zero)
	{	  
	  switch (one_jumps_pn_two_jumps_cv_storage)
	    {
	    case FULL_STORAGE:
	      {
		if (NYval >= ZYval)
		  {
		    non_zero_NBMEs_numbers_two_jumps_cv_part_pn_two_jumps_stored_Nval_larger_calc (true);
		    non_zero_NBMEs_numbers_two_jumps_cv_part_pn_two_jumps_stored_Nval_larger_calc (false);
		  }
		else
		  {
		    non_zero_NBMEs_numbers_two_jumps_cv_part_pn_two_jumps_stored_Zval_larger_calc (true);
		    non_zero_NBMEs_numbers_two_jumps_cv_part_pn_two_jumps_stored_Zval_larger_calc (false);
		  }
	      } break;

	    case PARTIAL_STORAGE:
	      {
		if (NYval >= ZYval)
		  {
		    non_zero_NBMEs_numbers_two_jumps_cv_part_pn_two_jumps_partially_stored_Nval_larger_calc (true);
		    non_zero_NBMEs_numbers_two_jumps_cv_part_pn_two_jumps_partially_stored_Nval_larger_calc (false);
		  }
		else
		  {
		    non_zero_NBMEs_numbers_two_jumps_cv_part_pn_two_jumps_partially_stored_Zval_larger_calc (true);
		    non_zero_NBMEs_numbers_two_jumps_cv_part_pn_two_jumps_partially_stored_Zval_larger_calc (false);
		  }
	      } break;

	    case ON_THE_FLY:
	      {
		if (NYval >= ZYval)
		  {
		    non_zero_NBMEs_numbers_two_jumps_cv_part_pn_two_jumps_recalculated_Nval_larger_calc (true);
		    non_zero_NBMEs_numbers_two_jumps_cv_part_pn_two_jumps_recalculated_Nval_larger_calc (false);
		  }
		else
		  {
		    non_zero_NBMEs_numbers_two_jumps_cv_part_pn_two_jumps_recalculated_Zval_larger_calc (true);
		    non_zero_NBMEs_numbers_two_jumps_cv_part_pn_two_jumps_recalculated_Zval_larger_calc (false);
		  }
	      } break;

	    default: abort_all ();
	    }
	}
    }
  else
    non_zero_NBMEs_numbers_off_diagonal_pp_nn_calc ();
  
  if (configuration_SD_1ph_2ph_tables_to_recalculate)
    {
      prot_Y_data.tables_1ph_deallocate ();
      neut_Y_data.tables_1ph_deallocate ();
      
      prot_Y_data.tables_2ph_deallocate ();
      neut_Y_data.tables_2ph_deallocate ();
    }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time; 
      
      cout << endl << "Number of non zeros H NBMEs calculated and stored. time:" << relative_time << " s" << endl << endl;
    }
}







double H_class::non_zero_NBMEs_proportion_calc () const
{
  const class GSM_vector_helper_class &GSM_vector_helper_hybrid_1D_2D = get_GSM_vector_helper_hybrid_1D_2D ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_hybrid_1D_2D.get_is_it_MPI_parallelized_local ();
  
  const unsigned int space_dimension_process_hybrid_1D_2D = GSM_vector_helper_hybrid_1D_2D.get_space_dimension_process_row ();
  
  const unsigned long int total_space_dimension = GSM_vector_helper_hybrid_1D_2D.get_total_space_dimension ();

  const double total_space_dimension_double = total_space_dimension;
  
  const double half_off_diagonal_non_zero_NBMEs_number_process = non_zero_NBMEs_one_jump_numbers.sum () + non_zero_NBMEs_two_jumps_numbers.sum ();
  
  if (is_there_cout)
    {
      const class GSM_vector_helper_class &GSM_vector_helper_2D_occupied = get_GSM_vector_helper_2D (0);
  
      const bool is_process_active = GSM_vector_helper_2D_occupied.get_is_process_active ();
      
      const double off_diagonal_non_zero_NBMEs_number_process = 2.0*half_off_diagonal_non_zero_NBMEs_number_process;
  
      const double off_diagonal_non_zero_NBMEs_number_process_for_min = (is_process_active) ? (off_diagonal_non_zero_NBMEs_number_process) : (INFINITE);
      
      const double off_diagonal_non_zero_NBMEs_number_process_square = off_diagonal_non_zero_NBMEs_number_process*off_diagonal_non_zero_NBMEs_number_process;

      const double off_diagonal_non_zero_NBMEs_number_min = min_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , off_diagonal_non_zero_NBMEs_number_process_for_min);
      const double off_diagonal_non_zero_NBMEs_number_max = max_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , off_diagonal_non_zero_NBMEs_number_process);
      
      const double off_diagonal_non_zero_NBMEs_number_sum         = sum_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , off_diagonal_non_zero_NBMEs_number_process);
      const double off_diagonal_non_zero_NBMEs_number_squares_sum = sum_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , off_diagonal_non_zero_NBMEs_number_process_square);
      
      if (THIS_PROCESS == MASTER_PROCESS)
	{	  
	  const unsigned int MPI_active_squares_number = active_squares_number_calculate (NUMBER_OF_PROCESSES);
      
	  const double off_diagonal_non_zero_NBMEs_number_average = off_diagonal_non_zero_NBMEs_number_sum/MPI_active_squares_number;

	  const double off_diagonal_non_zero_NBMEs_number_sigma = statistical_sigma_calc (MPI_active_squares_number , off_diagonal_non_zero_NBMEs_number_sum , off_diagonal_non_zero_NBMEs_number_squares_sum);
	  
	  const double TYPE_memory = sizeof (TYPE)/1000000.0;
	  
	  const double off_diagonal_non_zero_NBMEs_equivalent_memory_min     = off_diagonal_non_zero_NBMEs_number_min*TYPE_memory;
	  const double off_diagonal_non_zero_NBMEs_equivalent_memory_max     = off_diagonal_non_zero_NBMEs_number_max*TYPE_memory;
	  const double off_diagonal_non_zero_NBMEs_equivalent_memory_average = off_diagonal_non_zero_NBMEs_number_average*TYPE_memory;
	  const double off_diagonal_non_zero_NBMEs_equivalent_memory_sigma   = off_diagonal_non_zero_NBMEs_number_sigma*TYPE_memory;

	  cout << endl;
	  cout << "Off diagonal non zero NBMEs equivalent memory min used by a process        : " << off_diagonal_non_zero_NBMEs_equivalent_memory_min     << " Mb" << endl;
	  cout << "Off diagonal non zero NBMEs equivalent memory max used by a process        : " << off_diagonal_non_zero_NBMEs_equivalent_memory_max     << " Mb" << endl;
	  cout << "Off diagonal non zero NBMEs equivalent memory average for all processes    : " << off_diagonal_non_zero_NBMEs_equivalent_memory_average << " Mb" << endl;
	  cout << "Off diagonal non zero NBMEs equivalent memory dispersion for all processes : " << off_diagonal_non_zero_NBMEs_equivalent_memory_sigma   << " Mb" << endl;
	  cout << endl;
	}
    }
    
  const double non_zero_NBMEs_number_process = space_dimension_process_hybrid_1D_2D + half_off_diagonal_non_zero_NBMEs_number_process;
          
  const double non_zero_NBMEs_proportion_process = 100.0*non_zero_NBMEs_number_process/(total_space_dimension_double*total_space_dimension_double);
  
  const double non_zero_NBMEs_proportion = sum_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , non_zero_NBMEs_proportion_process);
  
  return non_zero_NBMEs_proportion;
}


