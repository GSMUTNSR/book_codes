#include "../GSM_include/GSM_include_def.h"

// MPI transfer is sometimes done here even if is_it_MPI_parallelized is false as disk access cannot be done by many processes at the same time

using namespace string_routines;
using namespace inputs_misc;
using namespace correlated_state_routines;
using namespace total_diagonalization::symmetric;



// TYPE is double or complex
// -------------------------

// Implementation of the Jacobi-Davidson method
// --------------------------------------------
// One starts from an approximation to the desired the GSM eigenpair, E[i] and |Psi[i]>.
// The first eigenpair E[0] and |Psi[0]> is obtained from pole approximation or another calculation, 
// where either the Lanczos method, full orthogonalization or a pivot from file can be used.
//
//
// 1) Calculate the residue |R[i]> = H |Psi[i]> - E[i] |Psi[i]>
//
// 2) Update the approximate eigenvector by solving the linear system (H_app - E[i]) |Phi[i+1]> = |R[i]>, where H_app is a preconditioner for H (see after).
//
// 3) Orthogonalize |Phi[i+1]> to all previous Jacobi-Davidson vectors |Phi[j]>, 0 <= j <= i, with the modified Gram-Schmidt method (see GSM_vector.cpp).
//
// 4) Project |Phi[i+1]> on J if necessary and normalize.
//    Indeed, even though H and H_app commute with \vec{J} if there is Coulomb interaction) theoretically,
//    it is not true numerically and one sometimes has to project on J because good quantum number character is lost due to numerical inaccuracy.
//
// 5) Project H onto the extended basis set |Phi[j]>, 0 <= j <= i+1, so that one obtains a very small complex symmetric matrix which is diagonalized exactly using standard methods. 
//    This provides with a new approximation to the eigenpair E[i+1] and |Psi[i+1]>.
//
// 6) |Psi[i+1]> is identified from the spectrum of the diagonalized small complex symmetric matrix using the overlap method. 
//     For this, one looks for the eigenstate whose overlap with pole approximation is maximal. 
//
// 7) Repeat the above steps until convergence, as indicated by the |<Phi[i] | Psi[i]>|oo value.
//
//
// Even though the use of an approximated shift-and-invert scheme ensures convergence of the Jacobi-Davidson method to the desired interior eigenvalues, this convergence can be very slow. 
// Hence, a crucial need in GSM is to find a good preconditioner H_app, which transforms the eigenvalue problem into a form that is more favorable for a numerical solver, essentially accelerating convergence. 
// The simple diagonal approximation for H_app is not sufficient therein, as off-diagonal matrix elements are large in the pole space. However, H is diagonally dominant in the scattering space. 
// Consequently, to build an effective preconditioner, one can take H_app equal to H itself in the pole space, and equal to the diagonal of H in the scattering space 
// (the diagonal matrix elements <SD | H | SD> involving the Slater determinants of a fixed configuration are in fact replaced by their average therein in order to ensure that [H_app,\vec{J}] = 0). 
// Using H_app as a preconditioner in Jacobi-Davidson requires computing its inverse matrix. Since the dimension of the pole space is very small (a few hundreds at most), 
// and the rest of H_app is only a diagonal matrix, computing the inverse of H_app is inexpensive. 
//
//
//
//
// new_Davidson_vector_alloc_calc
// ------------------------------
// |R[i]> is orthogonalized with respect to previous Jacobi-Davidson vectors, normalized for stability,
// projected on J, and normalized again to form the new Jacobi-Davidson vector |Phi[i]>.
// |Phi[i]> is then globally reduced in all nodes so that each node has a copy of it, and copied to disk.
//
// Davidson_matrix_calc
// --------------------
// H|Phi[i]> is calculated and stored on disk afterwards, which allows to calculate the Jacobi-Davidson matrix at i-th iteration.
// The Jacobi-Davidson matrix is always globally reduced in all nodes so that each node does calculations independently afterwards.
// The generalized Lawson method has been coded with the L^2[CM] operator, but it is kept only for testing purposes and has never been used otherwise.
//
// Davidson_Res_test
// -----------------
// After diagonalization and overlap method, |Psi[i]> is tested with |<Phi[i] | Psi[i]>|oo, which must be smaller than the demanded precision to have convergence.
// H|Psi[i]> and its residue are calculated from H|Psi[i]> = \sum_j <Phi[j] | Psi[i]> H|Phi[j]> and |R[i]> = \sum_j (<Phi[j] | Psi[i]> H|Phi[j]> - <Phi[j] | Psi[i]> E[i] |Phi[j]>). 
// Read on disk is parallelized with MPI and OpenMP, and |R[i]> is added its components sequentially as calculation is quick compared to disk read.
// Res is globally reduced in all nodes afterwards so that each node has a copy of it.
//
//
//
// largest_overlap_eigenvector_calc_store_write_expectation_values
// ---------------------------------------------------------------
// |Psi[i]> is calculated from the Jacobi-Davidson basis to the Slater determinant basis and stored on disk when convergence is reached.
// Expectation values of operators and configuration mixing can be printed at the end of the calculation.
//
//
//
// iterative_diagonalization_largest_overlap
// -----------------------------------------
// The pivot vector is read from disk here, is obtained from pole approximation, or from file.
// Davidson_matrix_calc and largest_overlap_eigenvector_calc_store_write_expectation_values are called here.
// The Jacobi-Davidson process can be restarted, by taking the last |Psi[i]> as pivot. This allows not to have many lengthy orthogonalizations if one has many iterations.



void Davidson_GSM_disk::new_Davidson_vector_alloc_calc (
							const bool is_there_cout_detailed , 
							const bool is_it_Lowdin ,
							const unsigned int J_number , 
							const class J2_class &J2 , 
							const double J , 
							const class H_class &H , 
							const unsigned int i , 
							const TYPE E , 
							const unsigned int subspace_dimension , 
							const class array<TYPE> &E_subspace_tab , 
							const class array<class GSM_vector> &eigenvector_subspace_tab ,  
							const class GSM_vector &Res , 
							class GSM_vector &Res_subspace , 
							class array<class GSM_vector> &V_hybrid_1D_2D_work_vectors , 
							class GSM_vector &H_app_minus_E_inverse_Res_subspace , 
							class GSM_vector &Vstore , 
							class GSM_vector &V)
{						   
  const string node_string = node_string_determine (false , THIS_PROCESS);
    
  Davidson_GSM_not_disk::H_app_minus_E_inverse_apply (J , H , E , subspace_dimension , E_subspace_tab , eigenvector_subspace_tab ,
						      Res , Res_subspace , H_app_minus_E_inverse_Res_subspace , V);  
  
  V.orthogonalization_disk (is_there_cout_detailed , false , i , V_hybrid_1D_2D_work_vectors);
    
  V.normalization ();
  
  V.project_good_J (is_there_cout_detailed , J2 , J , J_number , is_it_Lowdin , true , V_hybrid_1D_2D_work_vectors , Vstore);
    
  V.copy_disk_indexed_name (false , false , STORAGE_DIR + node_string + "V" , i);
}





void Davidson_GSM_disk::Davidson_matrix_calc (
					      const bool is_there_cout , 
					      const unsigned int dimension_good_J , 
					      const class input_data_str &input_data , 
					      const double J , 
					      const unsigned int vector_index , 
					      const unsigned int J_number , 
					      const class J2_class &J2 ,
					      const class H_class &H , 
					      const unsigned int subspace_dimension , 
					      const class array<TYPE> &E_subspace_tab , 
					      const class array<class GSM_vector> &eigenvector_subspace_tab , 
					      class GSM_vector &Res_subspace , 
					      class GSM_vector &H_app_minus_E_inverse_Res_subspace , 
					      class GSM_vector &V ,
					      class GSM_vector &Vstore , 
					      class array<class GSM_vector> &V_hybrid_1D_2D_work_vectors , 
					      class matrix<TYPE> &Davidson , 
					      unsigned int &Davidson_dimension , 
					      double &test)
{
  const class GSM_vector_helper_class &GSM_vector_helper = V.get_GSM_vector_helper ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
      
  const int Z = prot_Y_data.get_N_nucleons ();
  const int N = neut_Y_data.get_N_nucleons ();
    
  const unsigned int BP = GSM_vector_helper.get_BP ();
    
  const unsigned int Davidson_max_dimension = Davidson.get_dimension ();
  
  const bool print_detailed_information = input_data.get_print_detailed_information ();

  const bool is_there_cout_detailed = (is_there_cout && print_detailed_information);

  const bool is_there_cout_not_detailed = (is_there_cout && !print_detailed_information);
  
  const bool is_it_Lowdin = input_data.get_is_it_Lowdin ();
  
  const double test_vector_solution = input_data.get_test_vector_solution ();

  const string node_string = node_string_determine (false , THIS_PROCESS);
  
  class GSM_vector &HV = Vstore;
  
  HV = H*V;
 
  HV.copy_disk_indexed_name (false , false , STORAGE_DIR + node_string + "HV" , 0);
  
  Davidson(0 , 0) = (V*HV);

  TYPE E = Davidson(0 , 0);
  
  class GSM_vector &Res = HV;
  
  Res -= E*V;
  
  const double Res_norm = Res.infinite_norm ();
  
  if (Res_norm < precision)
    {
      Davidson_dimension = 1;

      test = 0.0;

      return;
    }
  
  E += sqrt_precision;

  cout.precision (10);
    
  for (unsigned int i = 1 ; ((i < Davidson_max_dimension) && (test > test_vector_solution)) ; i++)
    {
      const bool is_time_considered = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_not_detailed);

      const double reference_time = (is_time_considered) ? (absolute_time_determine ()) : (NADA);
        
      new_Davidson_vector_alloc_calc (is_there_cout_detailed , is_it_Lowdin , J_number , J2 , J , H , i , E , subspace_dimension , E_subspace_tab , eigenvector_subspace_tab , Res , Res_subspace ,
				      V_hybrid_1D_2D_work_vectors , H_app_minus_E_inverse_Res_subspace , Vstore , V);
		    
      HV = H*V;
      
      HV.copy_disk_indexed_name (false , false , STORAGE_DIR + node_string + "HV" , i);

      if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_detailed)
	{	        
	  cout << endl << "Iteration:" << i << endl;
	  cout << "---------------" << endl << endl;

	  cout << J_Pi_vector_index_string (BP , J , vector_index) << " Z:" << Z << " , N:" << N << endl;
	}
      
      if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_not_detailed) cout << "Iteration " << i << "  ";
      
      Davidson_dimension = i + 1;
      
      const unsigned int vectors_subset_number = Davidson_dimension/NUMBER_OF_THREADS;

      for (unsigned int vectors_subset_index = 0 ; vectors_subset_index <= vectors_subset_number ; vectors_subset_index++)
	{
	  const unsigned int ii_debut = vectors_subset_index*NUMBER_OF_THREADS;

#ifdef UseOpenMP
#pragma omp parallel default(shared) if (is_it_OpenMP_parallelized)
#endif
	  {
	    const unsigned int this_thread = OpenMP_thread_number_determine ();

	    const unsigned int ii = ii_debut + this_thread;

	    if (ii < Davidson_dimension)
	      {
		class GSM_vector &Vii = V_hybrid_1D_2D_work_vectors(this_thread);

		Vii.read_disk_indexed_name (false , false , STORAGE_DIR + node_string + "V" , ii);
	      }
	  }

	  for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++)
	    {
	      const unsigned int ii = ii_debut + i_thread;

	      if (ii < Davidson_dimension)
		{
		  const class GSM_vector &Vii = V_hybrid_1D_2D_work_vectors(i_thread);
  
		  Davidson(i , ii) = Davidson(ii , i) = (Vii*HV);
		}
	    }
	}
  
      Davidson_Res_test (is_there_cout , print_detailed_information , dimension_good_J , Davidson_dimension , Davidson , V_hybrid_1D_2D_work_vectors , Res , E , test);
  
      if ((THIS_PROCESS == MASTER_PROCESS) && is_time_considered)
	{
	  const double now = absolute_time_determine () , relative_time = now - reference_time;
	  
	  cout << "time:" << relative_time << " s" << endl;
	}
    }

  if (Davidson_dimension == 0) Davidson_dimension = 1;
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << endl;

  cout.precision (15);
}











void Davidson_GSM_disk::Davidson_Res_test (
					   const bool is_there_cout , 
					   const bool print_detailed_information ,
					   const unsigned int dimension_good_J , 
					   const unsigned int Davidson_dimension , 
					   const class matrix<TYPE> &Davidson , 
					   class array<class GSM_vector> &V_hybrid_1D_2D_work_vectors , 
					   class GSM_vector &Res , 
					   TYPE &E_tilde , 
					   double &test)
{
  const unsigned int Davidson_dimension_minus_one = Davidson_dimension - 1;
  
  const string node_string = node_string_determine (false , THIS_PROCESS);

  class matrix<TYPE> Davidson_small(Davidson_dimension);
  
  Davidson_small.assign (Davidson);
  
  class array<TYPE> E_tab_small(Davidson_dimension);

  all_eigenpairs (Davidson_small , E_tab_small);

  const unsigned int i_max = maximal_overlap_eigenvector_index_determine (Davidson_small , 0);

  E_tilde = E_tab_small(i_max);  

  const class vector_class<TYPE> &eigenvector_Davidson = Davidson_small.eigenvector(i_max);

  const TYPE eigenvector_Davidson_last_Davidson_vector_overlap = eigenvector_Davidson(Davidson_dimension_minus_one);

  test = (Davidson_dimension < dimension_good_J) ? (inf_norm (eigenvector_Davidson_last_Davidson_vector_overlap)) : (0.0);

  Res = 0.0;

  const unsigned int vectors_subset_number = Davidson_dimension/NUMBER_OF_THREADS;

  for (unsigned int vectors_subset_index = 0 ; vectors_subset_index <= vectors_subset_number ; vectors_subset_index++)
    {
      const unsigned int i_debut = vectors_subset_index*NUMBER_OF_THREADS;

#ifdef UseOpenMP
#pragma omp parallel default(shared) if (is_it_OpenMP_parallelized)
#endif
      {
	const unsigned int this_thread = OpenMP_thread_number_determine ();

	const unsigned int i = i_debut + this_thread;

	if (i < Davidson_dimension)
	  {
	    class GSM_vector &HVi = V_hybrid_1D_2D_work_vectors(this_thread);

	    HVi.read_disk_indexed_name (false , false , STORAGE_DIR + node_string + "HV" , i);
	  }
      }

      for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++)
	{
	  const unsigned int i = i_debut + i_thread;

	  if (i < Davidson_dimension)
	    {
	      const TYPE component_i = eigenvector_Davidson(i);
	  
	      const class GSM_vector &HVi = V_hybrid_1D_2D_work_vectors(i_thread);

	      Res += component_i*HVi;
	    }
	}
    }


  for (unsigned int vectors_subset_index = 0 ; vectors_subset_index <= vectors_subset_number ; vectors_subset_index++)
    {
      const unsigned int i_debut = vectors_subset_index*NUMBER_OF_THREADS;

#ifdef UseOpenMP
#pragma omp parallel default(shared) if (is_it_OpenMP_parallelized)
#endif
      {
	const unsigned int this_thread = OpenMP_thread_number_determine ();

	const unsigned int i = i_debut + this_thread;

	if (i < Davidson_dimension)
	  {
	    class GSM_vector &Vi = V_hybrid_1D_2D_work_vectors(this_thread);

	    Vi.read_disk_indexed_name (false , false , STORAGE_DIR + node_string + "V" , i);
	  }
      }

      for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++)
	{
	  const unsigned int i = i_debut + i_thread;

	  if (i < Davidson_dimension)
	    {
	      const TYPE component_i = eigenvector_Davidson(i);

	      const TYPE E_tilde_component_i = E_tilde*component_i;
	  
	      const class GSM_vector &Vi = V_hybrid_1D_2D_work_vectors(i_thread);

	      Res -= E_tilde_component_i*Vi;
	    }
	}
    }

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      
#ifdef TYPEisDOUBLE

      if (print_detailed_information)
	cout << "E:" << E_tilde << " MeV" << endl << "test:" << test << endl << endl;
      else
	cout << "E:" << E_tilde << " MeV   test:" << test << "  ";

#endif

#ifdef TYPEisDOUBLECOMPLEX
      
      const double E = real_dc (E_tilde);

      const double Gamma = -2000.0*imag_dc (E_tilde);
	  
      if (print_detailed_information)
	cout << "E:" << E << " MeV G:" << Gamma << " keV" << endl << "test:" << test << endl << endl;
      else
	cout << "E:" << E << " MeV G:" << Gamma << " keV test:" << test << "  ";

#endif
      
    }
}










void Davidson_GSM_disk::largest_overlap_eigenvector_calc_store_write_expectation_values (
											 const bool is_there_cout , 
											 const class input_data_str &input_data , 
											 const class J2_class &J2 , 
											 const class T2_class &T2 , 
											 const class H_class &H , 
											 const class L2_CM_class &L2_CM , 
											 const unsigned int Davidson_dimension , 
											 const bool are_PSI_expectation_values_written ,
											 const class matrix<TYPE> &Davidson ,
											 class GSM_vector_helper_class &GSM_vector_helper_hybrid_1D_2D_M ,
											 class GSM_vector_helper_class &GSM_vector_helper_2D_occupied_M ,
											 class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied_M , 
											 class array<class GSM_vector> &V_hybrid_1D_2D_work_vectors , 
											 class GSM_vector &Vstore , 
											 class GSM_vector &PSI ,
											 class array<class GSM_vector> &PSI_M_tab , 
											 class correlated_state_str &PSI_qn)
{
  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
    
  const string node_string = node_string_determine (false , THIS_PROCESS);

  class matrix<TYPE> Davidson_small(Davidson_dimension);

  Davidson_small.assign (Davidson);

  class array<TYPE> E_tab_small(Davidson_dimension);
  
  all_eigenpairs (Davidson_small , E_tab_small);

  const unsigned int i_max = maximal_overlap_eigenvector_index_determine (Davidson_small , 0);

  const TYPE E = E_tab_small(i_max);

  const class vector_class<TYPE> &eigenvector_Davidson = Davidson_small.eigenvector(i_max);
  
  PSI_qn.initialize (PSI_qn.get_Z () ,
		     PSI_qn.get_N () ,
		     PSI_qn.get_BP () ,
		     PSI_qn.get_S () ,
		     PSI_qn.get_J () ,
		     PSI_qn.get_vector_index () ,
		     E ,
		     PSI_qn.get_weight () ,
		     PSI_qn.get_experimental_energy () ,
		     PSI_qn.get_energy_error () ,
		     PSI_qn.get_is_it_optimization_reference_state ());

  PSI = 0.0;

  const unsigned int vectors_subset_number = Davidson_dimension/NUMBER_OF_THREADS;

  for (unsigned int vectors_subset_index = 0 ; vectors_subset_index <= vectors_subset_number ; vectors_subset_index++)
    {
      const unsigned int i_debut = vectors_subset_index*NUMBER_OF_THREADS;

#ifdef UseOpenMP
#pragma omp parallel default(shared) if (is_it_OpenMP_parallelized)
#endif
      {
	const unsigned int this_thread = OpenMP_thread_number_determine ();

	const unsigned int i = i_debut + this_thread;

	if (i < Davidson_dimension)
	  {
	    class GSM_vector &Vi = V_hybrid_1D_2D_work_vectors(this_thread);

	    Vi.read_disk_indexed_name (false , false , STORAGE_DIR + node_string + "V" , i);

	    Vi *= eigenvector_Davidson(i);
	  }
      }

      for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++)
	{
	  const unsigned int i = i_debut + i_thread;

	  if (i < Davidson_dimension)
	    {
	      const class GSM_vector &Vi = V_hybrid_1D_2D_work_vectors(i_thread);

	      PSI += Vi;
	    }
	}
    }
  
  PSI.good_phase ();

  PSI.space_dimension_SDs_components_eigenvector_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);

  const TYPE average_n_scat = PSI.average_n_scat_calc ();

  if (THIS_PROCESS == MASTER_PROCESS) GSM_vector_eigenenergy_average_n_scat_copy_disk ("eigenvector_E_averaged_n_scat" , PSI_qn , average_n_scat);
  
  if (are_PSI_expectation_values_written && is_there_cout) 
    eigenvector_functions::write_expectation_values (input_data , PSI , J2 , T2 , H , L2_CM , GSM_vector_helper_hybrid_1D_2D_M , GSM_vector_helper_2D_occupied_M , GSM_vector_helper_2D_unoccupied_M , Vstore , PSI_M_tab , PSI_qn);
}










void Davidson_GSM_disk::iterative_diagonalization_largest_overlap (
								   const bool is_there_cout , 
								   const unsigned int J_number , 
								   const unsigned int dimension_good_J , 
								   const class input_data_str &input_data , 
								   const unsigned int Davidson_max_dimension , 
								   const class H_class &H , 
								   const class J2_class &J2 , 
								   const unsigned int subspace_dimension , 
								   const class array<TYPE> &E_subspace_tab , 
								   const class array<class GSM_vector> &eigenvector_subspace_tab ,  
								   class GSM_vector &Res_subspace , 
								   class GSM_vector &H_app_minus_E_inverse_Res_subspace ,
								   class GSM_vector_helper_class &GSM_vector_helper_hybrid_1D_2D_M ,
								   class GSM_vector_helper_class &GSM_vector_helper_hybrid_1D_2D_Mp1 ,
								   class GSM_vector_helper_class &GSM_vector_helper_2D_occupied_M ,
								   class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied_M , 
								   class GSM_vector_helper_class &GSM_vector_helper_2D_occupied_Mp1 ,
								   class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied_Mp1 , 
								   class GSM_vector &V ,
								   class GSM_vector &Vstore , 
								   class array<class GSM_vector> &PSI_M_tab ,
								   class array<class GSM_vector> &PSI_Mp1_tab ,
								   class GSM_vector &PSI_hybrid_1D_2D_M ,
								   class GSM_vector &PSI_hybrid_1D_2D_Mp1 ,
								   class array<class GSM_vector> &V_hybrid_1D_2D_work_vectors , 
								   class correlated_state_str &PSI_qn)
{
  const bool initial_pivot_from_file = input_data.get_initial_pivot_from_file ();

  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();

  const bool print_detailed_information = input_data.get_print_detailed_information ();

  const bool is_there_cout_detailed = (is_there_cout && print_detailed_information);
  
  const bool is_there_cout_not_detailed = (is_there_cout && !print_detailed_information);
  
  const bool is_it_Lowdin = input_data.get_is_it_Lowdin ();
  
  const string node_string = node_string_determine (false , THIS_PROCESS);

  const unsigned int N_restarts = input_data.get_N_restarts ();

  const unsigned int N_restarts_plus_one = N_restarts + 1;
  
  const unsigned int BP = PSI_qn.get_BP ();
  
  const double J = PSI_qn.get_J ();
  
  const unsigned int vector_index = PSI_qn.get_vector_index ();
  
  const bool is_cv_possible = input_data.get_is_cv_possible ();
  
  const double test_vector_solution = input_data.get_test_vector_solution ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const bool is_it_COSM = is_it_COSM_determine (inter);
  
  const bool T2_CM_operators_calculated = input_data.get_T2_CM_operators_calculated ();
  
  const bool is_L2_CM_applied = (!is_it_COSM && T2_CM_operators_calculated); 

  class GSM_vector &PSI0_M = PSI_M_tab(0);
  class GSM_vector &PSI1_M = PSI_M_tab(1);
  class GSM_vector &PSI2_M = PSI_M_tab(2);
  class GSM_vector &PSI3_M = PSI_M_tab(3);
		  
  class GSM_vector &PSI0_Mp1 = PSI_Mp1_tab(0);
  class GSM_vector &PSI1_Mp1 = PSI_Mp1_tab(1);
  
  const class T2_class T2(false , J , is_cv_possible , GSM_vector_helper_hybrid_1D_2D_M , GSM_vector_helper_2D_occupied_M , GSM_vector_helper_2D_unoccupied_M , PSI0_M , PSI1_M , PSI2_M , PSI3_M);

  class CM_operator_class Lplus;
  class CM_operator_class Lminus;
  class CM_operator_class Lz;

  class L2_CM_class L2_CM;
  
  if (is_L2_CM_applied)
    {
      Lplus.allocate  (LPLUS , false , J , true , GSM_vector_helper_hybrid_1D_2D_M , GSM_vector_helper_hybrid_1D_2D_Mp1 ,
		       GSM_vector_helper_2D_occupied_M , GSM_vector_helper_2D_unoccupied_M , GSM_vector_helper_2D_occupied_Mp1 ,
		       GSM_vector_helper_2D_unoccupied_Mp1 , PSI0_M , PSI1_M , PSI0_Mp1 , PSI1_Mp1);
      
      Lminus.allocate (LMINUS , false , J , true , GSM_vector_helper_hybrid_1D_2D_Mp1 , GSM_vector_helper_hybrid_1D_2D_M ,
		       GSM_vector_helper_2D_occupied_Mp1 , GSM_vector_helper_2D_unoccupied_Mp1 , GSM_vector_helper_2D_occupied_M ,
		       GSM_vector_helper_2D_unoccupied_M , PSI0_Mp1 , PSI1_Mp1 , PSI0_M , PSI1_M);
      
      Lz.allocate     (LZ , false , J , true , GSM_vector_helper_hybrid_1D_2D_M , GSM_vector_helper_hybrid_1D_2D_M ,
		       GSM_vector_helper_2D_occupied_M , GSM_vector_helper_2D_unoccupied_M , GSM_vector_helper_2D_occupied_M ,
		       GSM_vector_helper_2D_unoccupied_M , PSI0_M , PSI1_M , PSI2_M , PSI3_M);
      
      L2_CM.allocate (Lplus , Lminus , Lz , PSI_hybrid_1D_2D_M , PSI_hybrid_1D_2D_Mp1);
    }

  double test = INFINITE;

  class matrix<TYPE> Davidson(Davidson_max_dimension);

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_not_detailed)
    {
      const class baryons_data &prot_Y_data = GSM_vector_helper_hybrid_1D_2D_M.get_prot_Y_data (); 
      const class baryons_data &neut_Y_data = GSM_vector_helper_hybrid_1D_2D_M.get_neut_Y_data ();
  
      const int Z = prot_Y_data.get_N_nucleons ();
      const int N = neut_Y_data.get_N_nucleons ();
      
      cout << endl << J_Pi_vector_index_string (BP , J , vector_index) << " Z:" << Z << " , N:" << N << endl;
      cout << "--------------------" << endl << endl;
    }
  
  for (unsigned int r = 0 ; ((r < N_restarts_plus_one) && (test > test_vector_solution)) ; r++)
    {
      const bool is_there_pivot_from_file_here = (initial_pivot_from_file || (r > 0));

      if (is_there_pivot_from_file_here)
	V.pivot_init_Davidson (is_there_cout_detailed , full_common_vectors_used_in_file , true , true , PSI_qn , J2 , J , J_number , is_it_Lowdin , true , V_hybrid_1D_2D_work_vectors , Vstore);
      else
	V.pivot_init_Davidson (is_there_cout_detailed , true , true , true , PSI_qn , J2 , J , J_number , is_it_Lowdin , true , V_hybrid_1D_2D_work_vectors , Vstore);
      
      V.copy_disk_indexed_name (false , false , STORAGE_DIR + node_string + "V" , 0);
 
      unsigned int Davidson_dimension = 0;

      Davidson = 0.0;

      Davidson_matrix_calc (is_there_cout , dimension_good_J , input_data , J , vector_index , J_number , J2 , H ,
			    subspace_dimension , E_subspace_tab , eigenvector_subspace_tab , Res_subspace , H_app_minus_E_inverse_Res_subspace ,
			    V , Vstore , V_hybrid_1D_2D_work_vectors , Davidson , Davidson_dimension , test);

      const bool are_PSI_expectation_values_written = ((test < test_vector_solution) || (r == N_restarts));

      largest_overlap_eigenvector_calc_store_write_expectation_values (is_there_cout , input_data , J2 , T2 , H , L2_CM ,
								       Davidson_dimension , are_PSI_expectation_values_written , Davidson ,
								       GSM_vector_helper_hybrid_1D_2D_M , GSM_vector_helper_2D_occupied_M , GSM_vector_helper_2D_unoccupied_M ,
								       V_hybrid_1D_2D_work_vectors , Vstore , V , PSI_M_tab , PSI_qn);
    }

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << endl << endl; 
}



