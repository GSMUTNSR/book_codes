#include "../GSM_include/GSM_include_def.h"

// TYPE is double or complex
// -------------------------

// Class xJ2_plus_alpha_str is used only in closures and then is not commented.




// Class applying the J^2 operator and checking the precision of J-coupling of GSM vector
// --------------------------------------------------------------------------------------
// One has here constructors, destructors, J^2 operator apply call and operators overloading of operations of the type a.J^2 + b.
//
// Routines are rather straightforward so that they are not detailed. Only general explanations are given.
//
// One uses the standard decomposition J^2 = J-.J+ + Jz.(Jz + 1), to which an alpha.Id constant operator is added.
// If M = M[max], the maximal M that one can have in the GSM space, J+ |Psi> is always equal to zero.
// The J+/J- operators are allocated in the class if M < M[max], and Jz.(Jz+1) only provides with the factor M.(M + 1).Id .
//
//
// time_multiplications_data_print
//--------------------------------
// print the time spent applying J+ and J-
//
//
// J_coupling_precision_calc
//--------------------------
// The precision of J-coupling is considered in two different ways, according to having M=J or M=0.
// If M=J, one just has to calculate the infinite norm of J+|Psi>, as a J-coupled GSM vector has to verify J+|Psi> = 0, as the |J M+1> vector is theoretically equal to 0.
// if M=0, one calculates the infinite norm of [J^2 - J.(J + 1).Id].|Psi>, as this vector vanishes if |Psi> is coupled to J.
//
// The latter test allows to gain time, as one does not to have to project on J a GSM vector whose previous test norm is smaller than 10^(-!0).
// Indeed, when applying Hamiltonian to a J-coupled state, it is coupled to J theoretically, so that the previous test norm is smaller than 10^(-!0) most of the time.
// Consequently, in practice, J-projection only rarely has to be effected.
// As J-projection demands typically tens of J^2 application using the Lowdin method, the latter test is negligible compared to J-projection.
// Moreover, the latter test is typically 10-100 times faster than Hamiltonian times vector, so that it does not slow calculations.
// One the contrary, J-projection slows calculation, as it is similar, and sometimes longer, than Hamiltonian times vector.
//
//
// apply_add
// ---------
// Apply J^2 on |Psi[in]> and adds it to the initial |Psi[iout]>.
//
//
// xJ2_plus_alpha_str
// ------------------
// J2_pa must be understood here as J^2 + alpha.Id (see above).
// Operators overloading of operations are of the type a.J2_pa + b.Id, to which operators of the form c.J2_pa + d.Id as well can be added. 
// One cannot add another operator to a.J2_pa + b.Id besides c.J2_pa + d.Id, however, as one would have to call different many-body routines for it, which would be too complicated to handle.
// Indeed, the latter is seen as (a + c).J2_pa + (b + d).Id .
// One can use instead (a*H + b)*PSI_0 + J^2*PSI_1 for example, up to 10 terms.
// Products of operators are not accepted with operator overloading.
//
//
// used_memory_calc
// ----------------
// Memory used by the class


J2_class::J2_class () :
  Jplus_ptr (NULL) ,
  Jminus_ptr (NULL) ,
  PSI_Mp1_ptr (NULL)
{}
  
J2_class::J2_class (
		    const class Jpm_class &Jplus , 
		    const class Jpm_class &Jminus , 
		    class GSM_vector &PSI_Mp1) :
  Jplus_ptr (NULL) ,
  Jminus_ptr (NULL) ,
  PSI_Mp1_ptr (NULL)
{
  allocate (Jplus , Jminus , PSI_Mp1);  
}

J2_class::J2_class (const class J2_class &X) :
  Jplus_ptr (NULL) ,
  Jminus_ptr (NULL) ,
  PSI_Mp1_ptr (NULL)
{
  allocate_fill (X);
}
  
J2_class::~J2_class () {}






void J2_class::allocate (
			 const class Jpm_class &Jplus , 
			 const class Jpm_class &Jminus , 
			 class GSM_vector &PSI_Mp1)
{
  Jplus_ptr  = &Jplus;
  Jminus_ptr = &Jminus;
  
  PSI_Mp1_ptr = &PSI_Mp1;
}





void J2_class::allocate_fill (const class J2_class &X)
{
  Jplus_ptr  = X.Jplus_ptr;
  Jminus_ptr = X.Jminus_ptr;
  
  PSI_Mp1_ptr = X.PSI_Mp1_ptr; 
}


void J2_class::deallocate ()
{
  Jplus_ptr  = NULL;
  Jminus_ptr = NULL;
  
  PSI_Mp1_ptr = NULL;
}



bool J2_class::is_it_filled () const
{
  return ((Jplus_ptr != NULL) && (Jminus_ptr != NULL) && (PSI_Mp1_ptr != NULL));
}






void J2_class::apply_add (
			  const class GSM_vector &PSI_in , 
			  const TYPE &alpha , 
			  class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper_in  = PSI_in.get_GSM_vector_helper ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = PSI_out.get_GSM_vector_helper ();
  
  const bool is_it_MPI_parallelized_local_in  = GSM_vector_helper_in.get_is_it_MPI_parallelized_local ();
  const bool is_it_MPI_parallelized_local_out = GSM_vector_helper_out.get_is_it_MPI_parallelized_local ();
  
  const bool is_it_hybrid_1D_2D_in  = GSM_vector_helper_in.get_is_it_hybrid_1D_2D ();
  const bool is_it_hybrid_1D_2D_out = GSM_vector_helper_out.get_is_it_hybrid_1D_2D ();

  if (is_it_MPI_parallelized_local_in  && !is_it_hybrid_1D_2D_in)  error_message_print_abort ("The GSM vector in must be sequential or hybrid 1D/2D in J2_class::apply_add");
  if (is_it_MPI_parallelized_local_out && !is_it_hybrid_1D_2D_out) error_message_print_abort ("The GSM vector out must be sequential or hybrid 1D/2D in J2_class::apply_add");
      
  const double M = GSM_vector_helper_in.get_M ();
  
  const double Jmax = GSM_vector_helper_in.get_Jmax ();

  const TYPE M_M_plus_one_plus_alpha = M*(M + 1.0) + alpha;
  
  if (rint (M - Jmax) == 0.0)
    PSI_out += M_M_plus_one_plus_alpha*PSI_in;
  else
    {
      const class Jpm_class &Jplus  = get_Jplus ();      
      const class Jpm_class &Jminus = get_Jminus ();
      
      class GSM_vector &PSI_Mp1 = get_PSI_Mp1 ();
      
      PSI_Mp1 = Jplus*PSI_in;

      PSI_out += Jminus*PSI_Mp1 + M_M_plus_one_plus_alpha*PSI_in;
    }
}


// PSI_test can be a work vector of Jplus, but not of Jminus.

double J2_class::J_coupling_precision_calc (
					    const class GSM_vector &PSI , 
					    const double J , 
					    class GSM_vector &PSI_test) const
{
  const class GSM_vector_helper_class &GSM_vector_helper_M = PSI.get_GSM_vector_helper ();
  
  const double M = GSM_vector_helper_M.get_M ();

  const double Jmax = GSM_vector_helper_M.get_Jmax ();
  
  if (rint (M - Jmax) == 0.0)
    return 0.0;
  else
    { 
      class GSM_vector &PSI_Mp1 = get_PSI_Mp1 ();
      
      if (rint (M - J) == 0.0)
	{
	  const class Jpm_class &Jplus = get_Jplus ();

	  PSI_Mp1 = Jplus*PSI;
	    
	  const double J_coupling_precision = PSI_Mp1.infinite_norm ();

	  return J_coupling_precision;
	}
      else
	{
	  const class Jpm_class &Jplus  = get_Jplus ();
	  const class Jpm_class &Jminus = get_Jminus ();
	  
	  const double J_J_plus_one_minus_M_M_plus_one = J*(J + 1.0) - M*(M + 1.0);

	  PSI_Mp1 = Jplus*PSI;
	  
	  PSI_test = Jminus*PSI_Mp1 - J_J_plus_one_minus_M_M_plus_one*PSI;
  
	  const double J_coupling_precision = PSI_test.infinite_norm ();
	  
	  return J_coupling_precision;
	}
    }
}



void J2_class::time_multiplications_data_print () const
{
  const class Jpm_class &Jplus  = get_Jplus ();
  const class Jpm_class &Jminus = get_Jminus ();
      
  Jplus.time_multiplications_data_print ();
  Jminus.time_multiplications_data_print ();
}





xJ2_plus_alpha_str::xJ2_plus_alpha_str (const TYPE &x_c , const TYPE &alpha_c , const class J2_class &J2_c) : x (x_c) , alpha (alpha_c) , J2 (J2_c) {}

class xJ2_plus_alpha_str operator + (const class J2_class &J2)
{
  return xJ2_plus_alpha_str (1.0 , 0.0 , J2);
}

class xJ2_plus_alpha_str operator - (const class J2_class &J2)
{
  return xJ2_plus_alpha_str (-1.0 , 0.0 , J2);
}

class xJ2_plus_alpha_str operator + (const class J2_class &J2 , const double alpha)
{
  return xJ2_plus_alpha_str (1.0 , alpha , J2);
}

class xJ2_plus_alpha_str operator - (const class J2_class &J2 , const double alpha)
{
  return xJ2_plus_alpha_str (1.0 , -alpha , J2);
}

class xJ2_plus_alpha_str operator + (const double alpha , const class J2_class &J2)
{
  return xJ2_plus_alpha_str (1.0 , alpha , J2);
}

class xJ2_plus_alpha_str operator - (const double alpha , const class J2_class &J2)
{
  return xJ2_plus_alpha_str (-1.0 , alpha , J2);
}

class xJ2_plus_alpha_str operator * (const class J2_class &J2 , const double x)
{
  return xJ2_plus_alpha_str (x , 0.0 , J2);
}

class xJ2_plus_alpha_str operator * (const double x , const class J2_class &J2)
{
  return xJ2_plus_alpha_str (x , 0.0 , J2);
}

class xJ2_plus_alpha_str operator / (const class J2_class &J2 , const double x)
{
  const double one_over_x = 1.0/x;

  return xJ2_plus_alpha_str (one_over_x , 0.0 , J2);
}

class xJ2_plus_alpha_str operator + (const class xJ2_plus_alpha_str &Op)
{
  return xJ2_plus_alpha_str (Op.x , Op.alpha , Op.J2);
}

class xJ2_plus_alpha_str operator - (const class xJ2_plus_alpha_str &Op)
{
  return xJ2_plus_alpha_str (-Op.x , -Op.alpha , Op.J2);
}

class xJ2_plus_alpha_str operator + (const class xJ2_plus_alpha_str &Op , const double term)
{
  return xJ2_plus_alpha_str (Op.x , Op.alpha + term , Op.J2);
}

class xJ2_plus_alpha_str operator - (const class xJ2_plus_alpha_str &Op , const double term)
{
  return xJ2_plus_alpha_str (Op.x , Op.alpha - term , Op.J2);
}

class xJ2_plus_alpha_str operator + (const double term , const class xJ2_plus_alpha_str &Op)
{
  return xJ2_plus_alpha_str (Op.x , term + Op.alpha , Op.J2);
}

class xJ2_plus_alpha_str operator - (const double term , const class xJ2_plus_alpha_str &Op)
{
  return xJ2_plus_alpha_str (-Op.x , term - Op.alpha , Op.J2);
}

class xJ2_plus_alpha_str operator * (const class xJ2_plus_alpha_str &Op , const double factor)
{
  return xJ2_plus_alpha_str (Op.x*factor , Op.alpha*factor , Op.J2);
}

class xJ2_plus_alpha_str operator / (const class xJ2_plus_alpha_str &Op , const double factor)
{
  return xJ2_plus_alpha_str (Op.x/factor , Op.alpha/factor , Op.J2);
}

class xJ2_plus_alpha_str operator * (const double factor , const class xJ2_plus_alpha_str &Op)
{
  return xJ2_plus_alpha_str (factor*Op.x , factor*Op.alpha , Op.J2);
}

#ifdef TYPEisDOUBLECOMPLEX

class xJ2_plus_alpha_str operator + (const class J2_class &J2 , const complex<double> &alpha)
{
  return xJ2_plus_alpha_str (1.0 , alpha , J2);
}

class xJ2_plus_alpha_str operator - (const class J2_class &J2 , const complex<double> &alpha)
{
  return xJ2_plus_alpha_str (1.0 , -alpha , J2);
}

class xJ2_plus_alpha_str operator + (const complex<double> &alpha , const class J2_class &J2)
{
  return xJ2_plus_alpha_str (1.0 , alpha , J2);
}

class xJ2_plus_alpha_str operator - (const complex<double> &alpha , const class J2_class &J2)
{
  return xJ2_plus_alpha_str (-1.0 , alpha , J2);
}

class xJ2_plus_alpha_str operator * (const class J2_class &J2 , const complex<double> &x)
{
  return xJ2_plus_alpha_str (x , 0.0 , J2);
}

class xJ2_plus_alpha_str operator * (const complex<double> &x , const class J2_class &J2)
{
  return xJ2_plus_alpha_str (x , 0.0 , J2);
}

class xJ2_plus_alpha_str operator / (const class J2_class &J2 , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return xJ2_plus_alpha_str (one_over_x , 0.0 , J2);
}

class xJ2_plus_alpha_str operator + (const class xJ2_plus_alpha_str &Op , const complex<double> &term)
{
  return xJ2_plus_alpha_str (Op.x , Op.alpha + term , Op.J2);
}

class xJ2_plus_alpha_str operator - (const class xJ2_plus_alpha_str &Op , const complex<double> &term)
{
  return xJ2_plus_alpha_str (Op.x , Op.alpha - term , Op.J2);
}

class xJ2_plus_alpha_str operator + (const complex<double> &term , const class xJ2_plus_alpha_str &Op)
{
  return xJ2_plus_alpha_str (Op.x , term + Op.alpha , Op.J2);
}

class xJ2_plus_alpha_str operator - (const complex<double> &term , const class xJ2_plus_alpha_str &Op)
{
  return xJ2_plus_alpha_str (-Op.x , term - Op.alpha , Op.J2);
}

class xJ2_plus_alpha_str operator * (const class xJ2_plus_alpha_str &Op , const complex<double> &factor)
{
  return xJ2_plus_alpha_str (Op.x*factor , Op.alpha*factor , Op.J2);
}

class xJ2_plus_alpha_str operator / (const class xJ2_plus_alpha_str &Op , const complex<double> &factor)
{
  return xJ2_plus_alpha_str (Op.x/factor , Op.alpha/factor , Op.J2);
}

class xJ2_plus_alpha_str operator * (const complex<double> &factor , const class xJ2_plus_alpha_str &Op)
{
  return xJ2_plus_alpha_str (factor*Op.x , factor*Op.alpha , Op.J2);
}

#endif

class xJ2_plus_alpha_str operator + (const class xJ2_plus_alpha_str &Op_a , const class xJ2_plus_alpha_str &Op_b)
{
  if (&(Op_a.J2) != &(Op_b.J2))
    error_message_print_abort ("J2 must be the same in both Op_a and Op_b in class xJ2_plus_alpha_str operator +");

  return xJ2_plus_alpha_str (Op_a.x + Op_b.x , Op_a.alpha + Op_b.alpha , Op_a.J2);
}

class xJ2_plus_alpha_str operator - (const class xJ2_plus_alpha_str &Op_a , const class xJ2_plus_alpha_str &Op_b)
{	
  if (&(Op_a.J2) != &(Op_b.J2))
    error_message_print_abort ("J2 must be the same in both Op_a and Op_b in class xJ2_plus_alpha_str operator -");

  return xJ2_plus_alpha_str (Op_a.x - Op_b.x , Op_a.alpha - Op_b.alpha , Op_a.J2);
}




double used_memory_calc (const class J2_class &T)
{
  return sizeof (T)/1000000.0;
}



