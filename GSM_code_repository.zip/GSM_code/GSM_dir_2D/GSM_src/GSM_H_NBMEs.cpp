#include "../GSM_include/GSM_include_def.h"

// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons (plus a few hyperons if any)
// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------




// Calculation of diagonal and off-diagonal NBMEs of Hamiltonian for the 0p-0h and 1p-1h cases, not considering the reordering phase
// ---------------------------------------------------------------------------------------------------------------------------------
// H = h + V, with h the one-body part and V the two-body part.
//
// Formulas are:
// <SD | H | SD> = \sum_i <i | h | i> + \sum_{i < j} <i j | V | i j>
// <SD' | H | SD> = +/- (<i' | h | i> + \sum_{j} <i' j | V | i j>). The +/- phase is not considered here (cf no_phase in routine names).
// In this notation, |SD> and |SD'> can contain protons and neutrons.
//
// pp, nn and pn parts are separated in NBMEs.
// The pp/nn parts are considered in diagonal_pp_nn_calc and no_pn_one_jump_mu_no_phase_calc (mu is proton or neutron)
// The pn parts are considered in diagonal_pn_calc, pn_no_phase_one_jump_p_calc (p -> p') and pn_no_phase_one_jump_n_calc (n -> n').
//
// Uncoupled OBMEs are always recalculated from coupled OBMEs.
// However, as H is a scalar, this amounts to checking if the OBME is equal to zero or to the coupled OBME from m conservation (see GSM_small_classes.cpp).
//
// The same routines are repeated twice, as TBMEs cam be calculated in two different ways.
// Either one uses class TBMEs_class for TBMEs,
// in which case stored TBMEs are J-coupled and uncoupled TBMEs must be recalculated each time with Clebsch-Gordan coefficients (see GSM_TBMEs_class.cpp).
// Or one uses class uncoupled_TBMEs_class, where uncoupled TBMEs are stored, so that uncoupled TBMEs are simply read from the class.
//
// Variables
// ---------
// is_one_body_part_non_zero, is_two_body_part_non_zero: true if the one-body or two-body parts are equal to zero, false if not.
//                                                       This occurs if one calculates gradients of the Hamiltonian with respect to WS parameters, for example,
//                                                       in which case only the one-body part is non-zero.
//
// OBMEs_inter_set: array of arrays of one-body matrix elements for Hamiltonian, nuclear, kinetic and Coulomb operators
//
// SDp, SDn, SD: proton or neutron Slater determinants in proton-neutron space. SD is used with protons only or neutrons only.
//               For 1p-1h NBMEs in proton-neutron space, SDp/SDn is the common part of |SD> and |SD'> (above notation).
//
// TBMEs, TBMEs_pn: class storing J-coupled pp/nn and pn two-body matrix elements. Uncoupled TBMEs are recalculated from coupled TBMEs with Clebsch-Gordan coefficients.  
// M_TBMEs: class storing uncoupled pp, nn and pn two-body matrix elements
// ZYval, NYval, N_valence_baryons: number of valence protons and neutrons of the nucleus (plus a few hyperons if any). N_valence_baryons is ZYval or NYval.
// NBME, NBME_no_phase_res, NBME_H_pn_no_phase: N-body matrix element to calculate and return, where reordering phase is not considered, for pp/nn and pn parts.
// state_i, state_ii: |i> and |j> states in <i j | V | i j> for pp/nn case only
// state_p, state_n: |i> and |j> states in <i j | V | i j> for pn case only
// in_jump, out_jump, idem:  changing states |i> -> |i'>, and common state |j>, in the pp/nn part of \sum_{j} <i' j | V | i j>.
// is_in_ordered, is_out_ordered: true if i < j or i' < j, false if not, for the pp/nn case. One has to multiply by a -1 phase if states are not ordered.
// p_in, p_out, n_in, n_out: changing states |i> -> |i'> in the pn part of \sum_{j} <i' j | V | i j>. This part is \sum_n <p_out n | V | p_in n> or \sum_p <p n_out | V | p n_in>.
// TBME_space: PROT_Y_ONLY or NEUT_Y_ONLY if one has only protons or neutrons (plus a few hyperons if any)
// inter: type of the interaction used (FHT, realistic, ...) 
// data: class where all data related to protons or neutrons (plus a few hyperons if any) are stored


TYPE H_NBMEs::diagonal_pp_nn_calc (
				   const bool is_one_body_part_non_zero , 
				   const bool is_two_body_part_non_zero , 
				   const class OBMEs_inter_set_str &OBMEs_inter_set ,
				   const enum interaction_type inter , 
				   const class TBMEs_class &TBMEs , 
				   const class Slater_determinant &SD)
{
  const unsigned int N_valence_baryons = SD.get_N_valence_baryons ();

  TYPE NBME = 0.0;

  if (is_one_body_part_non_zero)
    {
      for (unsigned int i = 0 ; i < N_valence_baryons ; i++) 
	{
	  const unsigned int state_i = SD[i];

	  NBME += OBMEs_inter_set.uncoupled_OBME (inter , state_i , state_i);
	}
    }

  if (is_two_body_part_non_zero)
    {
      for (unsigned int i = 0 ; i < N_valence_baryons ; i++)
	{
	  const unsigned int state_i = SD[i];

	  for (unsigned int ii = 0 ; ii < N_valence_baryons ; ii++)
	    {
	      const unsigned int state_ii = SD[ii];

	      if (state_i < state_ii) NBME += TBMEs.M_TBME (false , state_i , state_ii , state_i , state_ii);
	    }
	} 
    }
  
  return NBME;
}



TYPE H_NBMEs::diagonal_pn_calc (
				const class TBMEs_class &TBMEs_pn , 
				const class Slater_determinant &SDp , 
				const class Slater_determinant &SDn)
{
  const unsigned int ZYval = SDp.get_N_valence_baryons ();
  const unsigned int NYval = SDn.get_N_valence_baryons ();

  TYPE NBME = 0.0;

  for (unsigned int p = 0 ; p < ZYval ; p++)
    {
      const unsigned int state_p = SDp[p];

      for (unsigned int n = 0 ; n < NYval ; n++)
	{
	  const unsigned int state_n = SDn[n];

	  NBME += TBMEs_pn.M_TBME (false , state_p , state_n , state_p , state_n);
	}
    }
    
  return NBME;
}



TYPE H_NBMEs::no_pn_one_jump_mu_no_phase_calc (
					       const enum interaction_type inter , 
					       const bool is_one_body_part_non_zero , 
					       const bool is_two_body_part_non_zero , 
					       const unsigned int in_jump ,
					       const unsigned int out_jump , 
					       const class Slater_determinant &outSD , 
					       const class baryons_data &data)
{	
  const class OBMEs_inter_set_str &OBMEs_inter_set = data.get_OBMEs_inter_set ();

  const class TBMEs_class &TBMEs = data.get_TBMEs ();

  const unsigned int N_valence_baryons = data.get_N_valence_baryons ();

  TYPE NBME_no_phase_res = (is_one_body_part_non_zero) ? (OBMEs_inter_set.uncoupled_OBME (inter , in_jump , out_jump)) : (0.0);

  if (is_two_body_part_non_zero)
    {
      for (unsigned int i = 0 ; i < N_valence_baryons ; i++)
	{
	  const unsigned int idem = outSD[i];

	  if ((idem != in_jump) && (idem != out_jump))
	    {
	      const bool is_in_ordered  = (in_jump  < idem);
	      const bool is_out_ordered = (out_jump < idem);

	      if (is_in_ordered && is_out_ordered) NBME_no_phase_res += TBMEs.M_TBME (false , in_jump , idem , out_jump , idem);

	      else if (!is_in_ordered && is_out_ordered) NBME_no_phase_res -= TBMEs.M_TBME (false , idem , in_jump , out_jump , idem);
	      else if (is_in_ordered && !is_out_ordered) NBME_no_phase_res -= TBMEs.M_TBME (false , in_jump , idem , idem , out_jump);

	      else if (!is_in_ordered && !is_out_ordered) NBME_no_phase_res += TBMEs.M_TBME (false , idem , in_jump , idem , out_jump);
	    }
	}
    }

  return NBME_no_phase_res;
}



TYPE H_NBMEs::pn_no_phase_one_jump_p_calc (
					   const unsigned int p_in ,
					   const unsigned int p_out , 
					   const class Slater_determinant &SDn , 
					   const class TBMEs_class &TBMEs_pn)
{
  const unsigned int NYval = SDn.get_N_valence_baryons ();

  TYPE NBME_H_pn_no_phase = 0.0;

  for (unsigned int n = 0 ; n < NYval ; n++)
    {
      const unsigned int state_n = SDn[n];

      NBME_H_pn_no_phase += TBMEs_pn.M_TBME (false , p_in , state_n , p_out , state_n);
    }

  return NBME_H_pn_no_phase;
}



TYPE H_NBMEs::pn_no_phase_one_jump_n_calc (
					   const unsigned int n_in ,
					   const unsigned int n_out , 
					   const class Slater_determinant &SDp , 
					   const class TBMEs_class &TBMEs_pn)
{
  const unsigned int ZYval = SDp.get_N_valence_baryons ();

  TYPE NBME_H_pn_no_phase = 0.0;

  for (unsigned int p = 0 ; p < ZYval ; p++)
    {
      const unsigned int state_p = SDp[p];

      NBME_H_pn_no_phase += TBMEs_pn.M_TBME (false , state_p , n_in , state_p , n_out); 
    }

  return NBME_H_pn_no_phase;
}




TYPE H_NBMEs::diagonal_pp_nn_calc (
				   const bool is_one_body_part_non_zero , 
				   const bool is_two_body_part_non_zero , 
				   const enum space_type TBME_space , 
				   const class OBMEs_inter_set_str &OBMEs_inter_set ,
				   const enum interaction_type inter , 
				   const class uncoupled_TBMEs_class &M_TBMEs , 
				   const class Slater_determinant &SD)
{
  const unsigned int N_valence_baryons = SD.get_N_valence_baryons ();

  TYPE NBME = 0.0;

  if (is_one_body_part_non_zero)
    {
      for (unsigned int i = 0 ; i < N_valence_baryons ; i++) 
	{
	  const unsigned int state_i = SD[i];

	  NBME += OBMEs_inter_set.uncoupled_OBME (inter , state_i , state_i);
	}
    }

  if (is_two_body_part_non_zero)
    {
      for (unsigned int i = 0 ; i < N_valence_baryons ; i++)
	{
	  const unsigned int state_i = SD[i];

	  for (unsigned int ii = 0 ; ii < N_valence_baryons ; ii++)
	    {
	      const unsigned int state_ii = SD[ii];

	      if (state_i < state_ii) NBME += M_TBMEs (TBME_space , false , state_i , state_ii , state_i , state_ii);
	    }
	} 
    }

  return NBME;
}



TYPE H_NBMEs::diagonal_pn_calc (
				const class uncoupled_TBMEs_class &M_TBMEs , 
				const class Slater_determinant &SDp , 
				const class Slater_determinant &SDn)
{
  const unsigned int ZYval = SDp.get_N_valence_baryons ();
  const unsigned int NYval = SDn.get_N_valence_baryons ();

  TYPE NBME = 0.0;

  for (unsigned int p = 0 ; p < ZYval ; p++)
    {
      const unsigned int state_p = SDp[p];

      for (unsigned int n = 0 ; n < NYval ; n++)
	{
	  const unsigned int state_n = SDn[n];

	  NBME += M_TBMEs (PROT_NEUT_Y , false , state_p , state_n , state_p , state_n);
	}
    }

  return NBME;
}



TYPE H_NBMEs::no_pn_one_jump_mu_no_phase_calc (
					       const enum interaction_type inter , 
					       const bool is_one_body_part_non_zero , 
					       const bool is_two_body_part_non_zero , 
					       const class uncoupled_TBMEs_class &M_TBMEs , 
					       const unsigned int in_jump , 								
					       const unsigned int out_jump , 
					       const class Slater_determinant &outSD , 
					       const class baryons_data &data)
{
  const enum particle_type nucleonic_particle_mu = data.get_nucleonic_particle ();

  const enum space_type TBME_space = (nucleonic_particle_mu == PROTON) ? (PROT_Y_ONLY) : (NEUT_Y_ONLY);

  const class OBMEs_inter_set_str &OBMEs_inter_set = data.get_OBMEs_inter_set ();

  const unsigned int N_valence_baryons = data.get_N_valence_baryons ();

  TYPE NBME_no_phase_res = (is_one_body_part_non_zero) ? (OBMEs_inter_set.uncoupled_OBME (inter , in_jump , out_jump)) : (0.0);

  if (is_two_body_part_non_zero)
    {
      for (unsigned int i = 0 ; i < N_valence_baryons ; i++)
	{
	  const unsigned int idem = outSD[i];

	  if ((idem != in_jump) && (idem != out_jump))
	    {
	      const bool is_in_ordered  = (in_jump  < idem);
	      const bool is_out_ordered = (out_jump < idem);

	      if (is_in_ordered && is_out_ordered) NBME_no_phase_res += M_TBMEs (TBME_space , false , in_jump , idem , out_jump , idem);

	      else if (!is_in_ordered && is_out_ordered) NBME_no_phase_res -= M_TBMEs (TBME_space , false , idem , in_jump , out_jump , idem);
	      else if (is_in_ordered && !is_out_ordered) NBME_no_phase_res -= M_TBMEs (TBME_space , false , in_jump , idem , idem , out_jump);

	      else if (!is_in_ordered && !is_out_ordered) NBME_no_phase_res += M_TBMEs (TBME_space , false , idem , in_jump , idem , out_jump);
	    }
	}
    }
  
  return NBME_no_phase_res;
}



TYPE H_NBMEs::pn_no_phase_one_jump_p_calc (
					   const unsigned int p_in ,
					   const unsigned int p_out , 
					   const class Slater_determinant &SDn , 
					   const class uncoupled_TBMEs_class &M_TBMEs)
{
  const unsigned int NYval = SDn.get_N_valence_baryons ();

  TYPE NBME_H_pn_no_phase = 0.0;

  for (unsigned int n = 0 ; n < NYval ; n++)
    {
      const unsigned int state_n = SDn[n];

      NBME_H_pn_no_phase += M_TBMEs (PROT_NEUT_Y , false , p_in , state_n , p_out , state_n);
    }

  return NBME_H_pn_no_phase;
}




TYPE H_NBMEs::pn_no_phase_one_jump_n_calc (
					   const unsigned int n_in ,
					   const unsigned int n_out , 
					   const class Slater_determinant &SDp , 
					   const class uncoupled_TBMEs_class &M_TBMEs)
{
  const unsigned int ZYval = SDp.get_N_valence_baryons ();

  TYPE NBME_H_pn_no_phase = 0.0;

  for (unsigned int p = 0 ; p < ZYval ; p++)
    {
      const unsigned int state_p = SDp[p];

      NBME_H_pn_no_phase += M_TBMEs (PROT_NEUT_Y , false , state_p , n_in , state_p , n_out); 
    }

  return NBME_H_pn_no_phase;
}


