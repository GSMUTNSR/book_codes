#include "../GSM_optimization_include/GSM_optimization_include_def.h"

using namespace string_routines;
using namespace inputs_misc;
using namespace configuration_SD_in_space_1ph_2ph_one_jump_Jpm;
using namespace GSM_vector_dimensions;
using namespace fixed_nucleus_common;







// TYPE is double or complex
// ----------------------------


// All routines here deal with a nucleus with fixed number of protons and neutrons.
// One can deal with several eigenstates per nucleus in these routines.




// Calculation of the gradients of many-body energies with respect to Hamiltonian parameters
// -----------------------------------------------------------------------------------------

void fixed_nucleus::E_grad_components_calc (
					    const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
					    const class array<bool> &is_there_l_dependence_from_fit_index , 
					    const class array<int> &l_from_fit_index , 
					    const class input_data_str &input_data , 
					    const class array<class interaction_class> &inter_data_units , 
					    const class array<class correlated_state_str> &PSI_qn_tab , 
					    const double J , 
					    const unsigned int eigenset_index , 
					    const unsigned int eigenset_vectors_number , 
					    class interaction_class &inter_data , 
					    class TBMEs_class &TBMEs_pn , 
					    class TBMEs_class &TBMEs_cv , 
					    class baryons_data &prot_Y_data , 
					    class baryons_data &neut_Y_data , 
					    class GSM_vector_helper_class &GSM_vector_helper_hybrid_1D_2D_M ,
					    class GSM_vector_helper_class &GSM_vector_helper_2D_occupied_M ,
					    class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied_M , 
					    class array<class GSM_vector> &PSI_M_tab , 
					    class array<class GSM_vector> &H_PSI_unoccupied_2D_tab , 
					    class array<class vector_class<TYPE> > &E_grad_all_states)
{  
  const unsigned int N_parameters_to_fit = FHT_EFT_parameters_from_fit_index.dimension (0);

  const bool print_detailed_information = input_data.get_print_detailed_information ();
    
  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const bool is_cv_possible = input_data.get_is_cv_possible ();
  
  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();
  
  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage ();
  
  const enum storage_type one_jumps_pn_two_jumps_cv_storage = input_data.get_one_jumps_pn_two_jumps_cv_storage ();
  
  const int ZYval = input_data.get_ZYval ();
  const int NYval = input_data.get_NYval ();
      
  class GSM_vector &PSI0_M = PSI_M_tab(0);
  class GSM_vector &PSI1_M = PSI_M_tab(1);
  class GSM_vector &PSI2_M = PSI_M_tab(2);
  class GSM_vector &PSI3_M = PSI_M_tab(3);
    
  class GSM_vector PSI(GSM_vector_helper_hybrid_1D_2D_M);

  class GSM_vector H_grad_PSI(GSM_vector_helper_hybrid_1D_2D_M);
  
  class OBMEs_inter_set_str dummy_inter_set;
  
  class OBMEs_inter_set_str &OBMEs_p_inter_set = (space != NEUT_Y_ONLY) ? (prot_Y_data.get_OBMEs_inter_set ()) : (dummy_inter_set);
  class OBMEs_inter_set_str &OBMEs_n_inter_set = (space != PROT_Y_ONLY) ? (neut_Y_data.get_OBMEs_inter_set ()) : (dummy_inter_set);

  const class array<TYPE> dummy_array;
  
  const class array<TYPE> OBMEs_p_inter = (space != NEUT_Y_ONLY) ? (OBMEs_p_inter_set(inter)) : (dummy_array);
  const class array<TYPE> OBMEs_n_inter = (space != PROT_Y_ONLY) ? (OBMEs_n_inter_set(inter)) : (dummy_array);

  const class array<TYPE> OBMEs_p_hole_double_counting = (space != NEUT_Y_ONLY) ? (OBMEs_p_inter_set(HOLE_DOUBLE_COUNTING)) : (dummy_array);
  const class array<TYPE> OBMEs_n_hole_double_counting = (space != PROT_Y_ONLY) ? (OBMEs_n_inter_set(HOLE_DOUBLE_COUNTING)) : (dummy_array);
  
  const class GSM_vector_helper_class dummy_helper;
  
  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
    { 
      const enum FHT_EFT_parameter_type FHT_EFT_parameter = FHT_EFT_parameters_from_fit_index(fit_index);

      const bool is_it_p_grad = is_it_FHT_EFT_one_body_charged_baryon_determine   (FHT_EFT_parameter);
      const bool is_it_n_grad = is_it_FHT_EFT_one_body_uncharged_baryon_determine (FHT_EFT_parameter);

      const bool is_it_two_body_grad = (!is_it_p_grad && !is_it_n_grad);

      const bool is_one_body_p_non_zero = (is_it_p_grad && (space != NEUT_Y_ONLY));
      const bool is_one_body_n_non_zero = (is_it_n_grad && (space != PROT_Y_ONLY));

      const bool is_it_FHT_EFT_parameter_pp_nn = is_it_FHT_EFT_parameter_pp_nn_determine (FHT_EFT_parameter);
  
      const bool is_pp_non_zero = ((ZYval >= 2) && is_it_FHT_EFT_parameter_pp_nn);
      const bool is_nn_non_zero = ((NYval >= 2) && is_it_FHT_EFT_parameter_pp_nn);
  
      const bool is_pn_non_zero = ((space == PROT_NEUT_Y) && is_it_two_body_grad);

      const bool is_cv_non_zero = (is_cv_possible && is_it_two_body_grad);

      if (is_one_body_p_non_zero || is_one_body_n_non_zero || is_pp_non_zero || is_nn_non_zero || is_pn_non_zero)
	{
	  OBMEs_TBMEs_grad_calc (FHT_EFT_parameters_from_fit_index , is_there_l_dependence_from_fit_index , l_from_fit_index , 
				 input_data , inter_data_units , fit_index , inter_data , TBMEs_pn , TBMEs_cv , prot_Y_data , neut_Y_data);
	  
	  const class H_class H_grad(print_detailed_information , print_detailed_information , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_two_jumps_cv_storage , false , false , false ,
				     TBMEs_pn , TBMEs_cv , is_one_body_p_non_zero , is_one_body_n_non_zero , is_pp_non_zero , is_nn_non_zero , is_pn_non_zero , is_cv_non_zero , J , 
				     GSM_vector_helper_hybrid_1D_2D_M , GSM_vector_helper_2D_occupied_M , GSM_vector_helper_2D_unoccupied_M ,
				     PSI0_M , PSI1_M , PSI2_M , PSI3_M , H_PSI_unoccupied_2D_tab);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {	  
	      const class correlated_state_str &PSI_qn = PSI_qn_tab(eigenset_index , i);

	      const double weight = PSI_qn.get_weight ();

	      const bool is_it_optimization_reference_state = PSI_qn.get_is_it_optimization_reference_state ();
      
	      if (!is_it_optimization_reference_state && (weight == 0.0)) continue;
	      
	      PSI.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);

	      H_grad_PSI = H_grad*PSI;

	      class vector_class<TYPE> &E_grad = E_grad_all_states(eigenset_index , i);

	      E_grad(fit_index) = PSI*H_grad_PSI;
	    }

	  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl << FHT_EFT_parameter << " gradient component calculated" << endl << endl;
	}
    }

  if (space != NEUT_Y_ONLY) OBMEs_p_inter_set(inter) = OBMEs_p_inter , OBMEs_p_inter_set(HOLE_DOUBLE_COUNTING) = OBMEs_p_hole_double_counting;
  if (space != PROT_Y_ONLY) OBMEs_n_inter_set(inter) = OBMEs_n_inter , OBMEs_n_inter_set(HOLE_DOUBLE_COUNTING) = OBMEs_n_hole_double_counting;
}



















// Calculation of the one-body basis states
// ----------------------------------------

void fixed_nucleus::space_one_body_basis_data_alloc_calc (
							  const class input_data_str &input_data , 
							  const class interaction_class &inter_data_basis , 
							  class baryons_data &prot_Y_data , 				 
							  class baryons_data &neut_Y_data)
{
  //  COMMENT: the parameters to be fitted are: V0_ctr_ot , V0_ctr_et , V0_ctr_es , V0_ctr_os , V0_so_ot , V0_so_et , V0_t_ot , V0_t_et for FHT
  //                                            VS_const_LO_T0 , VS_const_LO_T1 , VT_sigma_product_LO_T0 , VT_sigma_product_LO_T1 ,
  //                                            V1_q2_NLO , V2_k2_NLO , V3_q2_sigma_product_NLO , V4_k2_sigma_product_NLO ,
  //                                            V5_k2_sigma_q_vector_k_NLO , V6_sigma_q_product_NLO , V7_sigma_k_product_NLO for EFT

  baryons_data_initialization (true , input_data , prot_Y_data , neut_Y_data);

  class HF_nucleons_data prot_Y_HF_data(input_data , prot_Y_data);
  class HF_nucleons_data neut_Y_HF_data(input_data , neut_Y_data);
    
  const bool print_detailed_information = input_data.get_print_detailed_information ();
  
  const enum potential_type basis_potential = input_data.get_basis_potential ();
  
  if (basis_potential == MSDHF)
    MSDHF_potentials::potentials_shells_OBMEs_realloc_calc (print_detailed_information , input_data , inter_data_basis , prot_Y_HF_data , neut_Y_HF_data , prot_Y_data , neut_Y_data);
  else
    HF_potentials::potentials_shells_OBMEs_realloc_calc (print_detailed_information , input_data , inter_data_basis , prot_Y_HF_data , neut_Y_HF_data , prot_Y_data , neut_Y_data);
}








// Calculation of the many-body eigenstates by diagonalizing H and using J^2 projection
// ------------------------------------------------------------------------------------

void fixed_nucleus::H_J2_find_eigenvector (
					   const class input_data_str &input_data , 
					   const class TBMEs_class &TBMEs_pn ,
					   const class TBMEs_class &TBMEs_cv ,
					   const unsigned int J_number , 
					   const class array<unsigned long int> &total_space_dimensions_good_J_pole_approximation , 
					   const class array<unsigned long int> &total_space_dimensions_good_J , 
					   const unsigned int eigenset_index , 
					   const class array<TYPE> &E_subspace_tab , 
					   const class array<class GSM_vector> &eigenvector_subspace_tab ,
					   class GSM_vector_helper_class &GSM_vector_helper_hybrid_1D_2D_M ,
					   class GSM_vector_helper_class &GSM_vector_helper_hybrid_1D_2D_Mp1 ,
					   class GSM_vector_helper_class &GSM_vector_helper_2D_occupied_M ,
					   class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied_M , 
					   class GSM_vector_helper_class &GSM_vector_helper_2D_occupied_Mp1 ,
					   class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied_Mp1 , 
					   class GSM_vector &V ,
					   class GSM_vector &Vstore , 
					   class array<class GSM_vector> &PSI_M_tab , 
					   class array<class GSM_vector> &PSI_Mp1_tab , 
					   class array<class GSM_vector> &V_hybrid_1D_2D_M_tab ,
					   class array<class GSM_vector> &V_hybrid_1D_2D_Mp1_tab ,
					   class array<class GSM_vector> &V_hybrid_1D_2D_tab , 
					   class array<class GSM_vector> &HV_hybrid_1D_2D_tab , 
					   class array<class GSM_vector> &Vp_hybrid_1D_2D_tab , 
					   class array<class GSM_vector> &V_hybrid_1D_2D_work_vectors ,
					   class array<class GSM_vector> &H_PSI_unoccupied_2D_tab , 
					   class array<class correlated_state_str> &PSI_qn_tab)
{
  const bool print_detailed_information = input_data.get_print_detailed_information ();
  
  const bool all_states_calculated = input_data.get_all_states_calculated ();

  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage ();
  
  const enum storage_type one_jumps_pn_two_jumps_cv_storage = input_data.get_one_jumps_pn_two_jumps_cv_storage ();
  
  const bool is_cv_possible = input_data.get_is_cv_possible ();
  
  const int n_scat_max = input_data.get_n_scat_max ();

  const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

  const class array<unsigned int> &BP_eigenset_tab = input_data.get_BP_eigenset_tab ();
  
  const class array<double> &J_eigenset_tab = input_data.get_J_eigenset_tab ();

  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

  const unsigned int BP = BP_eigenset_tab(eigenset_index);
  
  const double J = J_eigenset_tab(eigenset_index);
  
  const int two_J = make_int (2.0*J);

  const int J_index = (two_J%2 == 0) ? (make_int (J)) : (make_int (J - 0.5));

  const unsigned long int total_space_dimension_good_J = total_space_dimensions_good_J(BP , n_scat_max , J_index);

  const unsigned int vectors_to_find_number = (all_states_calculated) ? (total_space_dimension_good_J) : (eigenset_vectors_number);
  
  class GSM_vector &PSI0_hybrid_1D_2D_M   = V_hybrid_1D_2D_M_tab(0);
  class GSM_vector &PSI1_hybrid_1D_2D_M   = V_hybrid_1D_2D_M_tab(1);
  
  class GSM_vector &PSI0_hybrid_1D_2D_Mp1 = V_hybrid_1D_2D_Mp1_tab(0);
  class GSM_vector &PSI1_hybrid_1D_2D_Mp1 = V_hybrid_1D_2D_Mp1_tab(1);
  class GSM_vector &PSI2_hybrid_1D_2D_Mp1 = V_hybrid_1D_2D_Mp1_tab(2);

  class GSM_vector &PSI0_M = PSI_M_tab(0);
  class GSM_vector &PSI1_M = PSI_M_tab(1);
  class GSM_vector &PSI2_M = PSI_M_tab(2);
  class GSM_vector &PSI3_M = PSI_M_tab(3);

  const class H_class H(print_detailed_information , print_detailed_information , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_two_jumps_cv_storage , false , true , false ,
			TBMEs_pn , TBMEs_cv , true , true , true , true , true , is_cv_possible , J , GSM_vector_helper_hybrid_1D_2D_M , GSM_vector_helper_2D_occupied_M , GSM_vector_helper_2D_unoccupied_M ,
			PSI0_M , PSI1_M , PSI2_M , PSI3_M , H_PSI_unoccupied_2D_tab);
  
  const class Jpm_class Jplus( print_detailed_information , print_detailed_information ,  1 , true , GSM_vector_helper_hybrid_1D_2D_M   , GSM_vector_helper_hybrid_1D_2D_Mp1 , PSI0_hybrid_1D_2D_Mp1 , PSI1_hybrid_1D_2D_Mp1);
  const class Jpm_class Jminus(print_detailed_information , print_detailed_information , -1 , true , GSM_vector_helper_hybrid_1D_2D_Mp1 , GSM_vector_helper_hybrid_1D_2D_M   , PSI0_hybrid_1D_2D_M   , PSI1_hybrid_1D_2D_M);
  
  const class J2_class J2(Jplus , Jminus , PSI2_hybrid_1D_2D_Mp1);
  
  eigenvector_functions::find_eigenvector (print_detailed_information , input_data , GSM_vector_helper_2D_occupied_M , J_number , 
					   total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J ,
					   J , H , J2 , eigenset_index , vectors_to_find_number , E_subspace_tab , eigenvector_subspace_tab ,
					   GSM_vector_helper_hybrid_1D_2D_M , GSM_vector_helper_hybrid_1D_2D_Mp1 , 
					   GSM_vector_helper_2D_occupied_M , GSM_vector_helper_2D_unoccupied_M ,
					   GSM_vector_helper_2D_occupied_Mp1 , GSM_vector_helper_2D_unoccupied_Mp1 , V , Vstore , PSI_M_tab , PSI_Mp1_tab ,
					   PSI0_hybrid_1D_2D_M , PSI0_hybrid_1D_2D_Mp1 , V_hybrid_1D_2D_tab , HV_hybrid_1D_2D_tab , Vp_hybrid_1D_2D_tab , V_hybrid_1D_2D_work_vectors , PSI_qn_tab);

  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << "Eigenvectors calculated" << endl;
}





// Calculations of the energies and energy gradients with respect to Hamiltonian parameters of all many-body states
// ----------------------------------------------------------------------------------------------------------------

void fixed_nucleus::E_grad_E_all_states_alloc_calc (
						    const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
						    const class array<bool> &is_there_l_dependence_from_fit_index , 
						    const class array<int> &l_from_fit_index , 
						    const class array<class interaction_class> &inter_data_units ,
						    const class vector_class<double> &FHT_EFT_parameters , 
						    class interaction_class &inter_data_Coulomb ,  
						    class input_data_str &input_data , 
						    class interaction_class &inter_data_basis , 
						    class interaction_class &inter_data , 
						    class array<class correlated_state_str> &PSI_qn_tab , 
						    class array<class vector_class<TYPE> > &E_grad_all_states)
{
  const bool print_detailed_information = input_data.get_print_detailed_information ();
  
  const class array<class array<class JT_coupled_TBME> > dummy_array_JT_coupled_TBME;
      
  inter_data_Coulomb.V_Coulomb_HO_basis_tab_calc (input_data);

  inter_data_basis.V_Coulomb_HO_basis_tab_calc (input_data);

  inter_data.V_Coulomb_HO_basis_tab_calc (input_data);
  
  class baryons_data prot_Y_data;
  class baryons_data neut_Y_data;
  
  space_one_body_basis_data_alloc_calc (input_data , inter_data_basis , prot_Y_data , neut_Y_data);
  
  Berggren_basis::single_particle_indices_radial_wfs_pn_alloc_calc (print_detailed_information , input_data , prot_Y_data , neut_Y_data);
 
  space_truncation_data_best_hbar_omega_calc (print_detailed_information , input_data , prot_Y_data , neut_Y_data);
  
  all_HO_GHF_overlaps_pn_alloc_calc (input_data , prot_Y_data , neut_Y_data);
    
  class TBMEs_class TBMEs_pn;
  class TBMEs_class TBMEs_cv;
  
  OBMEs_TBMEs::all_OBMEs_TBMEs_alloc_calc (print_detailed_information , false , dummy_array_JT_coupled_TBME , inter_data_basis , inter_data , input_data , prot_Y_data , neut_Y_data , TBMEs_pn , TBMEs_cv);
  
  hole_double_counting::prot_neut_OBMEs_no_natural_orbitals_calc_store_remove (false , input_data , prot_Y_data , neut_Y_data , TBMEs_pn);
    
  hole_double_counting::prot_neut_OBMEs_calc_store (false , input_data , prot_Y_data , neut_Y_data , TBMEs_pn);
  
  configuration_SD_sets::configuration_SD_tables_pp_nn_alloc_calc (print_detailed_information , false , true , input_data , prot_Y_data , neut_Y_data);

  const bool are_natural_orbitals_calculated_every_iteration = input_data.get_are_natural_orbitals_calculated_every_iteration ();

  const bool are_GSM_vectors_stored_on_disk = input_data.get_are_GSM_vectors_stored_on_disk ();
  
  const bool is_it_Lowdin = input_data.get_is_it_Lowdin ();
  
  const unsigned int N_parameters_to_fit = FHT_EFT_parameters_from_fit_index.dimension (0);
  
  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();

  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();

  const unsigned int eigensets_number = input_data.get_eigensets_number ();
  
  const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();
  const class array<unsigned int> &BP_eigenset_tab = input_data.get_BP_eigenset_tab ();

  const class array<double> &J_eigenset_tab = input_data.get_J_eigenset_tab ();
  
  const bool are_there_basis_p_natural_orbitals = prot_Y_data.get_are_there_basis_natural_orbitals ();
  const bool are_there_basis_n_natural_orbitals = neut_Y_data.get_are_there_basis_natural_orbitals ();

  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();
  
  const bool is_it_on_the_fly = (Hamiltonian_storage == ON_THE_FLY);
    
  const bool T2_CM_operators_calculated = input_data.get_T2_CM_operators_calculated ();
  
  const bool is_it_MPI_parallelized_T2_CM_operators_calculated_or_on_the_fly = (is_it_MPI_parallelized && (T2_CM_operators_calculated || is_it_on_the_fly));
  
  const unsigned int J_index_max = J_index_max_calc (space , prot_Y_data , neut_Y_data);

  const unsigned int n_scat_max_plus_one = n_scat_max + 1;

  const unsigned int J_index_max_plus_one = J_index_max + 1;
 
  const string debut_file_name_p = prot_Y_data.get_debut_file_name ();
  const string debut_file_name_n = neut_Y_data.get_debut_file_name ();
  
  class array<unsigned long int> total_space_dimensions_good_J_pole_approximation(2 , 1 , J_index_max_plus_one);

  class array<unsigned long int> total_space_dimensions_good_J(2 , n_scat_max_plus_one , J_index_max_plus_one);
  
  class array<double> M_table(eigensets_number);

  if (are_there_basis_p_natural_orbitals) OBMEs_inter_calc (inter_data , neut_Y_data , prot_Y_data);
  if (are_there_basis_n_natural_orbitals) OBMEs_inter_calc (inter_data , neut_Y_data , neut_Y_data);
    
  if (are_there_basis_p_natural_orbitals || are_there_basis_n_natural_orbitals) OBMEs_hole_double_counting_calc_remove (input_data , TBMEs_pn , inter_data , prot_Y_data , neut_Y_data);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_basis_p_natural_orbitals)
    {
      const class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
      
      OBMEs_p_inter_set.copy_disk (inter , debut_file_name_p);
    }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_basis_n_natural_orbitals)
    {
      const class OBMEs_inter_set_str &OBMEs_n_inter_set = neut_Y_data.get_OBMEs_inter_set ();
      
      OBMEs_n_inter_set.copy_disk (inter , debut_file_name_n);
    }
      
  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information)
    {
      const int Z = input_data.get_Z ();
      const int N = input_data.get_N ();
  
      cout << "Z:" << Z << " N:" << N << endl << endl;
    }
  
  all_J_total_space_dimensions_calc_print (print_detailed_information , input_data , prot_Y_data , neut_Y_data , total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J);
  
  M_table_calc (input_data , prot_Y_data , neut_Y_data , BP_eigenset_tab , J_eigenset_tab , M_table);

  const unsigned int eigenset_vectors_number_max = eigenset_vectors_number_tab.max ();

  input_data.PSI_quantum_numbers_tab_partial_fill (total_space_dimensions_good_J_pole_approximation , PSI_qn_tab);

  const unsigned int total_space_dimensions_good_J_pole_approximation_max = total_space_dimensions_good_J_pole_approximation.max ();

  const unsigned int vectors_to_find_number_max = max (eigenset_vectors_number_max , total_space_dimensions_good_J_pole_approximation_max);

  const unsigned long int dimension_good_J_max = total_space_dimensions_good_J.max ();
  
  const unsigned int workspace_max_dimension = input_data.get_workspace_max_dimension ();
  
  const unsigned int workspace_dimension_max = (dimension_good_J_max <= workspace_max_dimension) ? (dimension_good_J_max) : (workspace_max_dimension);

  const int J_number_max = J_number_max_calc (space , prot_Y_data , neut_Y_data , n_scat_max , total_space_dimensions_good_J);
      
  const int J_number_max_plus_one = J_number_max + 1;

  class array<unsigned int> eigenset_vectors_indices(eigensets_number , vectors_to_find_number_max);

  class array<bool> is_it_new_J_Pi_tab(eigensets_number);

  class array<bool> is_it_new_BP_M_tab(eigensets_number);

  eigensets_vectors_indices_calc (true , prot_Y_data , neut_Y_data , total_space_dimensions_good_J_pole_approximation , input_data , eigenset_vectors_indices);

  eigenvector_functions::changing_eigensets_bool_tables_calc (input_data , M_table , is_it_new_J_Pi_tab , is_it_new_BP_M_tab);

  const unsigned int subspace_max_dimension = total_space_dimensions_good_J_pole_approximation.max ();

  class array<TYPE> E_subspace_tab(2 , J_index_max_plus_one , subspace_max_dimension);  

  class array<class GSM_vector_helper_class> GSM_vector_helper_subspace_tab(2 , J_index_max_plus_one);

  class array<class GSM_vector> eigenvector_subspace_tab(2 , J_index_max_plus_one , subspace_max_dimension);
  
  E_subspace_tab = 0.0;
  eigenvector_functions::pole_approximation_eigenvectors_calc (print_detailed_information , total_space_dimensions_good_J_pole_approximation , M_table , TBMEs_pn , TBMEs_cv , input_data ,
							       PSI_qn_tab , prot_Y_data , neut_Y_data , E_subspace_tab , GSM_vector_helper_subspace_tab , eigenvector_subspace_tab);

  bool OBMEs_TBMEs_to_recalculate = false;

  class GSM_vector_helper_class GSM_vector_helper_2D_occupied_M;
  class GSM_vector_helper_class GSM_vector_helper_2D_occupied_Mp1;
  
  class GSM_vector_helper_class GSM_vector_helper_2D_unoccupied_M;
  class GSM_vector_helper_class GSM_vector_helper_2D_unoccupied_Mp1;
  
  class GSM_vector_helper_class GSM_vector_helper_hybrid_1D_2D_M;
  class GSM_vector_helper_class GSM_vector_helper_hybrid_1D_2D_Mp1;
  
  class GSM_vector V;
  
  class GSM_vector Vstore;
      
  class array<class GSM_vector> V_hybrid_1D_2D_M_tab(2);

  class array<class GSM_vector> V_hybrid_1D_2D_Mp1_tab(3);

  class array<class GSM_vector>  V_hybrid_1D_2D_tab(workspace_dimension_max);
  class array<class GSM_vector> HV_hybrid_1D_2D_tab(workspace_dimension_max);

  class array<class GSM_vector> Vp_hybrid_1D_2D_tab(J_number_max_plus_one);
  
  class array<class GSM_vector> V_hybrid_1D_2D_work_vectors(NUMBER_OF_THREADS);
  
  class array<class GSM_vector> PSI_M_tab(4);
  
  class array<class GSM_vector> PSI_Mp1_tab(2);

  class array<class GSM_vector> H_PSI_unoccupied_2D_tab(NUMBER_OF_THREADS);
  
  for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)	
    {
      const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

      const unsigned int BP = BP_eigenset_tab(eigenset_index);

      const double J = J_eigenset_tab(eigenset_index);

      const double M = M_table(eigenset_index);

      const double Mp1 = M + 1.0;

      const unsigned int J_number = J_number_calc (space , prot_Y_data , neut_Y_data , BP , n_scat_max , M , total_space_dimensions_good_J);
      
      if (OBMEs_TBMEs_to_recalculate)
	OBMEs_TBMEs_calc (input_data , inter_data_units , inter_data_Coulomb , FHT_EFT_parameters , inter_data , TBMEs_pn , TBMEs_cv , prot_Y_data , neut_Y_data);

      if (is_it_new_J_Pi_tab(eigenset_index) && is_it_new_BP_M_tab(eigenset_index))
	{  
	  V.deallocate ();
	  
	  Vstore.deallocate ();
		  
	  V_hybrid_1D_2D_M_tab.deallocate_object_elements ();

	  V_hybrid_1D_2D_Mp1_tab.deallocate_object_elements ();

	  V_hybrid_1D_2D_tab.deallocate_object_elements ();
	  
	  HV_hybrid_1D_2D_tab.deallocate_object_elements ();
	  
	  Vp_hybrid_1D_2D_tab.deallocate_object_elements ();
	  
	  V_hybrid_1D_2D_work_vectors.deallocate_object_elements ();
	      
	  PSI_M_tab.deallocate_object_elements ();

	  PSI_Mp1_tab.deallocate_object_elements ();

	  H_PSI_unoccupied_2D_tab.deallocate_object_elements ();
	      	      
	  GSM_vector_helper_hybrid_1D_2D_M.deallocate ();
	  GSM_vector_helper_hybrid_1D_2D_Mp1.deallocate ();
	  
	  GSM_vector_helper_2D_occupied_M.deallocate ();
	  GSM_vector_helper_2D_occupied_Mp1.deallocate ();
	      
	  GSM_vector_helper_2D_unoccupied_M.deallocate ();
	  GSM_vector_helper_2D_unoccupied_Mp1.deallocate ();
	  
	  GSM_vector_helper_hybrid_1D_2D_M.allocate (is_it_MPI_parallelized , true , true , space , inter , false , truncation_hw , truncation_ph ,
						     n_holes_max   , n_scat_max   , E_max_hw  ,
						     n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						     n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , true , prot_Y_data , neut_Y_data);
	  
	  GSM_vector_helper_hybrid_1D_2D_Mp1.allocate (is_it_MPI_parallelized , true , true , space , inter , false , truncation_hw , truncation_ph ,
						       n_holes_max   , n_scat_max   , E_max_hw  ,
						       n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						       n_holes_max_n , n_scat_max_n , En_max_hw , BP , Mp1 , true , prot_Y_data , neut_Y_data);
	  
	  GSM_vector_helper_2D_occupied_M.allocate_fill_2D_occupied (GSM_vector_helper_hybrid_1D_2D_M);
	      
	  GSM_vector_helper_2D_occupied_Mp1.allocate_fill_2D_occupied (GSM_vector_helper_hybrid_1D_2D_Mp1);
		
	  GSM_vector_helper_2D_unoccupied_M.allocate_fill_2D_unoccupied (GSM_vector_helper_2D_occupied_M);
	  
	  GSM_vector_helper_2D_unoccupied_Mp1.allocate_fill_2D_unoccupied (GSM_vector_helper_2D_occupied_Mp1);

	  V.allocate (GSM_vector_helper_hybrid_1D_2D_M);
		  
	  Vstore.allocate (GSM_vector_helper_hybrid_1D_2D_M);
		  		      	
	  for (unsigned int i = 0 ; i < 4 ; i++) PSI_M_tab(i).allocate (GSM_vector_helper_2D_occupied_M);

	  for (unsigned int i = 0 ; i < 2 ; i++) PSI_Mp1_tab(i).allocate (GSM_vector_helper_2D_occupied_Mp1);
	      
	  if (!is_it_on_the_fly)
	    {
	      for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) H_PSI_unoccupied_2D_tab(i).allocate (GSM_vector_helper_2D_unoccupied_M);
	    }
	  
	  for (unsigned int i = 0 ; i < 2 ; i++) V_hybrid_1D_2D_M_tab(i).allocate (GSM_vector_helper_hybrid_1D_2D_M);		  

	  for (unsigned int i = 0 ; i < 3 ; i++) V_hybrid_1D_2D_Mp1_tab(i).allocate (GSM_vector_helper_hybrid_1D_2D_Mp1); 
		  
	  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) V_hybrid_1D_2D_work_vectors(i).allocate (GSM_vector_helper_hybrid_1D_2D_M);
		  
	  if (!is_it_Lowdin && !are_GSM_vectors_stored_on_disk)
	    {
	      for (unsigned int i = 0 ; i < J_number ; i++) Vp_hybrid_1D_2D_tab(i).allocate (GSM_vector_helper_hybrid_1D_2D_M);
	    }
	  
	  configuration_SD_in_out_in_space_1ph_2ph_tables_alloc_calc (print_detailed_information , false , false , 0 , 
								      GSM_vector_helper_2D_occupied_M , GSM_vector_helper_2D_occupied_M ,
								      GSM_vector_helper_2D_occupied_Mp1 , prot_Y_data , neut_Y_data);
	      	     
	  if (is_it_MPI_parallelized_T2_CM_operators_calculated_or_on_the_fly)
	    configuration_SD_in_out_in_space_1ph_2ph_tables_alloc_calc (print_detailed_information , false , false , 1 ,
									GSM_vector_helper_2D_unoccupied_M , GSM_vector_helper_2D_unoccupied_M ,
									GSM_vector_helper_2D_unoccupied_Mp1 , prot_Y_data , neut_Y_data);
	}
      
      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	{
	  const unsigned int eigenvector_index = eigenset_vectors_indices(eigenset_index , i);

	  class correlated_state_str &PSI_qn = PSI_qn_tab(eigenset_index , i);

	  PSI_qn.initialize (
			     PSI_qn.get_Z () ,
			     PSI_qn.get_N () ,
			     PSI_qn.get_BP () ,
			     PSI_qn.get_S () ,
			     PSI_qn.get_J () ,
			     eigenvector_index ,
			     PSI_qn.get_E () ,
			     PSI_qn.get_weight () ,
			     PSI_qn.get_experimental_energy () ,
			     PSI_qn.get_energy_error () ,
	  		     PSI_qn.get_is_it_optimization_reference_state ());
	}

      H_J2_find_eigenvector (input_data , TBMEs_pn , TBMEs_cv , J_number , total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J ,
			     eigenset_index , E_subspace_tab , eigenvector_subspace_tab ,
			     GSM_vector_helper_hybrid_1D_2D_M , GSM_vector_helper_hybrid_1D_2D_Mp1 ,
			     GSM_vector_helper_2D_occupied_M , GSM_vector_helper_2D_unoccupied_M ,
			     GSM_vector_helper_2D_occupied_Mp1 , GSM_vector_helper_2D_unoccupied_Mp1 , V , Vstore , PSI_M_tab , PSI_Mp1_tab ,
			     V_hybrid_1D_2D_M_tab , V_hybrid_1D_2D_Mp1_tab , V_hybrid_1D_2D_tab , HV_hybrid_1D_2D_tab , Vp_hybrid_1D_2D_tab , V_hybrid_1D_2D_work_vectors , H_PSI_unoccupied_2D_tab , PSI_qn_tab);

      const bool is_there_reference_state_fixed_eigenset = optimization_data_handling::is_there_reference_state_fixed_eigenset_determine (input_data , eigenset_index);
      
      const bool are_all_weights_zero_fixed_eigenset = optimization_data_handling::are_all_weights_zero_fixed_eigenset_determine (input_data , eigenset_index);

      if (!are_all_weights_zero_fixed_eigenset || is_there_reference_state_fixed_eigenset)
	{
	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {
	      class vector_class<TYPE> &E_grad = E_grad_all_states(eigenset_index , i);
	      
	      if (!E_grad.is_it_filled ()) E_grad.allocate (N_parameters_to_fit);
	      
	      E_grad = 0.0;
	    }
	  
	  E_grad_components_calc (FHT_EFT_parameters_from_fit_index , is_there_l_dependence_from_fit_index , l_from_fit_index , input_data , inter_data_units ,
				  PSI_qn_tab , J , eigenset_index , eigenset_vectors_number , inter_data , TBMEs_pn , TBMEs_cv , prot_Y_data , neut_Y_data ,
				  GSM_vector_helper_hybrid_1D_2D_M , GSM_vector_helper_2D_occupied_M , GSM_vector_helper_2D_unoccupied_M ,
				  PSI_M_tab , H_PSI_unoccupied_2D_tab , E_grad_all_states);
	}
      
      OBMEs_TBMEs_to_recalculate = true;	
    }
  
  V.deallocate ();
  
  Vstore.deallocate ();
		  
  V_hybrid_1D_2D_M_tab.deallocate ();

  V_hybrid_1D_2D_Mp1_tab.deallocate ();

  V_hybrid_1D_2D_tab.deallocate ();

  HV_hybrid_1D_2D_tab.deallocate ();
	  
  Vp_hybrid_1D_2D_tab.deallocate ();
  
  V_hybrid_1D_2D_work_vectors.deallocate ();
	      
  PSI_M_tab.deallocate ();

  PSI_Mp1_tab.deallocate ();

  H_PSI_unoccupied_2D_tab.deallocate ();
	      	      
  GSM_vector_helper_hybrid_1D_2D_M.deallocate ();
  GSM_vector_helper_hybrid_1D_2D_Mp1.deallocate ();
	  
  GSM_vector_helper_2D_occupied_M.deallocate ();
  GSM_vector_helper_2D_occupied_Mp1.deallocate ();
	      
  GSM_vector_helper_2D_unoccupied_M.deallocate ();
  GSM_vector_helper_2D_unoccupied_Mp1.deallocate ();
	  
  prot_Y_data.one_jump_tables_Jpm_in_to_out_deallocate ();
  neut_Y_data.one_jump_tables_Jpm_in_to_out_deallocate ();
       
  prot_Y_data.tables_1ph_deallocate ();
  neut_Y_data.tables_1ph_deallocate ();
      
  prot_Y_data.tables_2ph_deallocate ();
  neut_Y_data.tables_2ph_deallocate ();
  
  // Necessary for natural orbitals
  for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)	
    {
      const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);
      
      const unsigned int BP = BP_eigenset_tab(eigenset_index);
      
      const double M = M_table(eigenset_index);
      
      class GSM_vector_helper_class GSM_vector_helper_hybrid_1D_2D_M(is_it_MPI_parallelized , true , true , space , inter , false , truncation_hw , truncation_ph ,
								     n_holes_max   , n_scat_max   , E_max_hw  ,
								     n_holes_max_p , n_scat_max_p , Ep_max_hw ,
								     n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , true , prot_Y_data , neut_Y_data);
      
      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	{
	  const class correlated_state_str &PSI_qn = PSI_qn_tab(eigenset_index , i);
	  
	  eigenvector_functions::eigenvector_stored_with_all_M_projections (false , print_detailed_information , input_data , total_space_dimensions_good_J , PSI_qn , GSM_vector_helper_hybrid_1D_2D_M);
	}
    }
  
#ifdef UseMPI
  
  for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)	
    {
      const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

      const bool is_there_reference_state_fixed_eigenset = optimization_data_handling::is_there_reference_state_fixed_eigenset_determine (input_data , eigenset_index);
      
      const bool are_all_weights_zero_fixed_eigenset = optimization_data_handling::are_all_weights_zero_fixed_eigenset_determine (input_data , eigenset_index);
      
      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	{	  
	  class correlated_state_str &PSI_qn = PSI_qn_tab(eigenset_index , i);
	  
	  const complex<double> E_init = PSI_qn.get_E ();

	  TYPE E = generate_scalar<TYPE> (real (E_init) , imag (E_init));
	  
	  MPI_helper::Bcast<TYPE> (E , MASTER_PROCESS , MPI_COMM_WORLD);

	  PSI_qn.initialize (
			     PSI_qn.get_Z () ,
			     PSI_qn.get_N () ,
			     PSI_qn.get_BP () ,
			     PSI_qn.get_S () ,
			     PSI_qn.get_J () ,
			     PSI_qn.get_vector_index () ,
			     E ,
			     PSI_qn.get_weight () ,
			     PSI_qn.get_experimental_energy () ,
			     PSI_qn.get_energy_error () ,
			     PSI_qn.get_is_it_optimization_reference_state ());
      
	  if (!are_all_weights_zero_fixed_eigenset || is_there_reference_state_fixed_eigenset)
	    {
	      class vector_class<TYPE> &E_grad = E_grad_all_states(eigenset_index , i);
	      
	      E_grad.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
	    }
	}
    }
  
#endif

  if (are_natural_orbitals_calculated_every_iteration)
    {
      const bool are_there_new_natural_orbitals_p = input_data.get_are_there_new_natural_orbitals_p ();
      const bool are_there_new_natural_orbitals_n = input_data.get_are_there_new_natural_orbitals_n ();

      if (are_there_new_natural_orbitals_p || are_there_new_natural_orbitals_n)
	{
	  natural_orbitals_ESPEs::calc_print (print_detailed_information , false , input_data , TBMEs_pn , prot_Y_data , neut_Y_data);

	  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_new_natural_orbitals_p) prot_Y_data.natural_orbitals_OBMEs_basis_store (inter_data);
	  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_new_natural_orbitals_n) neut_Y_data.natural_orbitals_OBMEs_basis_store (inter_data);
	}
    }
}











// Calculations of the energies of all many-body states
// ----------------------------------------------------

void fixed_nucleus::E_all_states_calc (
				       class input_data_str &input_data , 
				       class interaction_class &inter_data_basis , 
				       class interaction_class &inter_data , 
				       class array<class correlated_state_str> &PSI_qn_tab)
{	
  const bool print_detailed_information = input_data.get_print_detailed_information ();
  
  const class array<class array<class JT_coupled_TBME> > dummy_array_JT_coupled_TBME;
  
  inter_data_basis.V_Coulomb_HO_basis_tab_calc (input_data);

  inter_data.V_Coulomb_HO_basis_tab_calc (input_data);
  
  class baryons_data prot_Y_data;
  class baryons_data neut_Y_data;
    
  space_one_body_basis_data_alloc_calc (input_data , inter_data_basis , prot_Y_data , neut_Y_data);

  Berggren_basis::single_particle_indices_radial_wfs_pn_alloc_calc (print_detailed_information , input_data , prot_Y_data , neut_Y_data);
  
  space_truncation_data_best_hbar_omega_calc (print_detailed_information , input_data , prot_Y_data , neut_Y_data);

  all_HO_GHF_overlaps_pn_alloc_calc (input_data , prot_Y_data , neut_Y_data);
    
  class TBMEs_class TBMEs_pn;
  class TBMEs_class TBMEs_cv;
  
  OBMEs_TBMEs::all_OBMEs_TBMEs_alloc_calc (print_detailed_information , false , dummy_array_JT_coupled_TBME , inter_data_basis , inter_data , input_data , prot_Y_data , neut_Y_data , TBMEs_pn , TBMEs_cv);

  hole_double_counting::prot_neut_OBMEs_no_natural_orbitals_calc_store_remove (false , input_data , prot_Y_data , neut_Y_data , TBMEs_pn);
  
  hole_double_counting::prot_neut_OBMEs_calc_store (false , input_data , prot_Y_data , neut_Y_data , TBMEs_pn);
  
  configuration_SD_sets::configuration_SD_tables_pp_nn_alloc_calc (print_detailed_information , false , true , input_data , prot_Y_data , neut_Y_data);

  const bool are_natural_orbitals_calculated_every_iteration = input_data.get_are_natural_orbitals_calculated_every_iteration ();

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const int n_scat_max = input_data.get_n_scat_max ();
  
  const unsigned int eigensets_number = input_data.get_eigensets_number ();
   
  const bool are_there_basis_p_natural_orbitals = prot_Y_data.get_are_there_basis_natural_orbitals ();
  const bool are_there_basis_n_natural_orbitals = neut_Y_data.get_are_there_basis_natural_orbitals ();

  const unsigned int J_index_max = J_index_max_calc (space , prot_Y_data , neut_Y_data);

  const string debut_file_name_p = prot_Y_data.get_debut_file_name ();
  const string debut_file_name_n = neut_Y_data.get_debut_file_name ();
  
  const unsigned int n_scat_max_plus_one = n_scat_max + 1;
  
  const unsigned int J_index_max_plus_one = J_index_max + 1;
 
  class array<unsigned long int> total_space_dimensions_good_J_pole_approximation(2 , 1 , J_index_max_plus_one);
  
  class array<unsigned long int> total_space_dimensions_good_J(2 , n_scat_max_plus_one , J_index_max_plus_one);
  
  class array<double> M_table(eigensets_number);

  if (are_there_basis_p_natural_orbitals) OBMEs_inter_calc (inter_data , neut_Y_data , prot_Y_data);
  if (are_there_basis_n_natural_orbitals) OBMEs_inter_calc (inter_data , neut_Y_data , neut_Y_data);

  if (are_there_basis_p_natural_orbitals || are_there_basis_n_natural_orbitals) OBMEs_hole_double_counting_calc_remove (input_data , TBMEs_pn , inter_data , prot_Y_data , neut_Y_data);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_basis_p_natural_orbitals)
    {
      const class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
      
      OBMEs_p_inter_set.copy_disk (inter , debut_file_name_p);
    }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_basis_n_natural_orbitals)
    {
      const class OBMEs_inter_set_str &OBMEs_n_inter_set = neut_Y_data.get_OBMEs_inter_set ();
      
      OBMEs_n_inter_set.copy_disk (inter , debut_file_name_n);
    }
        
  const int Z = input_data.get_Z ();
  const int N = input_data.get_N ();
      
  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information)
    {  
      cout << endl << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;
      cout << "Z:" << Z << " N:" << N << endl;
      cout << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl << endl;
    }
  
  all_J_total_space_dimensions_calc_print (print_detailed_information , input_data , prot_Y_data , neut_Y_data , total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J);
  
  input_data.PSI_quantum_numbers_tab_partial_fill (total_space_dimensions_good_J , PSI_qn_tab);
  
  eigenvector_functions::eigenvectors_pole_approximation_full_space_calc (print_detailed_information , false , input_data , total_space_dimensions_good_J_pole_approximation , 
									  total_space_dimensions_good_J , TBMEs_pn , TBMEs_cv , prot_Y_data , neut_Y_data , PSI_qn_tab);

  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information)
    {
      cout << endl << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;
      cout << "Data for " << "Z:" << Z << " N:" << N << " calculated" << endl;
      cout << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl << endl;
    }
 
#ifdef UseMPI
  
  const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();
	
  for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)	
    {
      const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	{
	  class correlated_state_str &PSI_qn = PSI_qn_tab(eigenset_index , i);

	  const complex<double> E_init = PSI_qn.get_E ();

	  TYPE E = generate_scalar<TYPE> (real (E_init) , imag (E_init));

	  MPI_helper::Bcast<TYPE> (E , MASTER_PROCESS , MPI_COMM_WORLD);

	  PSI_qn.initialize (
			     PSI_qn.get_Z () ,
			     PSI_qn.get_N () ,
			     PSI_qn.get_BP () ,
			     PSI_qn.get_S () ,
			     PSI_qn.get_J () ,
			     PSI_qn.get_vector_index () ,
			     E ,
			     PSI_qn.get_weight () ,
			     PSI_qn.get_experimental_energy () ,
			     PSI_qn.get_energy_error () ,
			     PSI_qn.get_is_it_optimization_reference_state ());
	}
    }
  
#endif

  if (are_natural_orbitals_calculated_every_iteration)
    {
      const bool are_there_new_natural_orbitals_p = input_data.get_are_there_new_natural_orbitals_p ();
      const bool are_there_new_natural_orbitals_n = input_data.get_are_there_new_natural_orbitals_n ();

      if (are_there_new_natural_orbitals_p || are_there_new_natural_orbitals_n)
	{
	  natural_orbitals_ESPEs::calc_print (print_detailed_information , false , input_data , TBMEs_pn , prot_Y_data , neut_Y_data);

	  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_new_natural_orbitals_p) prot_Y_data.natural_orbitals_OBMEs_basis_store (inter_data);
	  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_new_natural_orbitals_n) neut_Y_data.natural_orbitals_OBMEs_basis_store (inter_data);
	}
    }
}








// Calculations of the natural orbitals associated to many-body states and of the OBMEs between natural orbitals
// -------------------------------------------------------------------------------------------------------------

void fixed_nucleus::natural_orbitals_OBMEs_basis_store (
							class input_data_str &input_data , 
							const class interaction_class &inter_data_basis ,
							const class interaction_class &inter_data)
{	
  const bool print_detailed_information = input_data.get_print_detailed_information ();
    
  const class array<class array<class JT_coupled_TBME> > dummy_array_JT_coupled_TBME;

  const bool are_there_new_natural_orbitals_p = input_data.get_are_there_new_natural_orbitals_p ();
  const bool are_there_new_natural_orbitals_n = input_data.get_are_there_new_natural_orbitals_n ();

  const class array<unsigned int> eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

  class baryons_data prot_Y_data;
  class baryons_data neut_Y_data;
  
  class TBMEs_class TBMEs_pn;
  class TBMEs_class TBMEs_cv;
  
  space_one_body_basis_data_alloc_calc (input_data , inter_data_basis , prot_Y_data , neut_Y_data);

  Berggren_basis::single_particle_indices_radial_wfs_pn_alloc_calc (print_detailed_information , input_data , prot_Y_data , neut_Y_data);
  
  space_truncation_data_best_hbar_omega_calc (print_detailed_information , input_data , prot_Y_data , neut_Y_data);

  all_HO_GHF_overlaps_pn_alloc_calc (input_data , prot_Y_data , neut_Y_data);

  OBMEs_TBMEs::all_OBMEs_TBMEs_alloc_calc (print_detailed_information , false , dummy_array_JT_coupled_TBME , inter_data_basis , inter_data , input_data , prot_Y_data , neut_Y_data , TBMEs_pn , TBMEs_cv);
      
  hole_double_counting::prot_neut_OBMEs_no_natural_orbitals_calc_store_remove (false , input_data , prot_Y_data , neut_Y_data , TBMEs_pn);
    
  hole_double_counting::prot_neut_OBMEs_calc_store (false , input_data , prot_Y_data , neut_Y_data , TBMEs_pn);
    
  configuration_SD_sets::configuration_SD_tables_pp_nn_alloc_calc (print_detailed_information , false , true , input_data , prot_Y_data , neut_Y_data);

  natural_orbitals_ESPEs::calc_print (print_detailed_information , false , input_data , TBMEs_pn , prot_Y_data , neut_Y_data);

  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_new_natural_orbitals_p) prot_Y_data.natural_orbitals_OBMEs_basis_store (inter_data);
  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_new_natural_orbitals_n) neut_Y_data.natural_orbitals_OBMEs_basis_store (inter_data);
}


