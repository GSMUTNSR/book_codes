#ifndef CCHMESONEBARYONH
#define CCHMESONEBARYONH

namespace CC_H_MEs_one_baryon 
{
  double HO_channel_decomposition_Ho_two_HO_calc (
						  const double CC_average_n_scat_target_projectile_max , 
						  const class array<class CC_channel_class> &channels_tab , 
						  const class array<bool> &is_it_forbidden_channel_tab , 
						  const class CG_str &CGs , 
						  const class interaction_class &inter_data_basis , 
						  const class array<double> &Gaussian_table_GL , 
						  const class multipolar_expansion_str &multipolar_expansion , 
						  const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
						  const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
						  const class baryons_data &prot_Y_data_one_configuration_GSM , 
						  const class baryons_data &neut_Y_data_one_configuration_GSM , 
						  const unsigned int ic ,  
						  const int nHOc ,  
						  const int nHOcp , 
						  const class baryons_data &prot_Y_data ,  
						  const class baryons_data &neut_Y_data , 
						  const class baryons_data &prot_Y_data_CC_Berggren ,  
						  const class baryons_data &neut_Y_data_CC_Berggren);

  double Berggren_channel_decomposition_Ho_two_HO_calc (
							const double CC_average_n_scat_target_projectile_max , 
							const class array<class CC_channel_class> &channels_tab , 
							const class array<bool> &is_it_forbidden_channel_CC_Berggren_tab , 
							const unsigned int ic ,  
							const int nHOc ,  
							const int nHOcp , 
							const class baryons_data &prot_Y_data_CC_Berggren ,  
							const class baryons_data &neut_Y_data_CC_Berggren);

  double Ho_two_HO_calc (
			 const double CC_average_n_scat_target_projectile_max , 
			 const class array<class CC_channel_class> &channels_tab , 
			 const class array<bool> &is_it_forbidden_channel_tab , 
			 const class array<bool> &is_it_forbidden_channel_Berggren_tab , 
			 const class CG_str &CGs , 
			 const class interaction_class &inter_data_basis , 
			 const class array<double> &Gaussian_table_GL , 
			 const class multipolar_expansion_str &multipolar_expansion , 
			 const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
			 const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
			 const class baryons_data &prot_Y_data_one_configuration_GSM , 
			 const class baryons_data &neut_Y_data_one_configuration_GSM , 
			 const unsigned int ic ,  
			 const int nHOc ,  
			 const int nHOcp , 
			 const class baryons_data &prot_Y_data ,  
			 const class baryons_data &neut_Y_data , 
			 const class baryons_data &prot_Y_data_CC_Berggren ,  
			 const class baryons_data &neut_Y_data_CC_Berggren);

  double Berggren_to_HO_two_channels_two_HO_calc (
						  const double CC_average_n_scat_target_projectile_max , 
						  const class array<class CC_channel_class> &channels_tab , 
						  const class array<bool> &is_it_forbidden_channel_tab , 
						  const unsigned int ic ,  
						  const unsigned int icp ,  
						  const int nHOc ,  
						  const int nHOcp , 
						  const class baryons_data &prot_Y_data ,  
						  const class baryons_data &neut_Y_data ,  
						  const class array<unsigned int> &matrices_indices , 
						  const class matrix<complex<double> > &Berggren_matrix);

  double potential_two_channels_two_HO_calc (
					     const double CC_average_n_scat_target_projectile_max , 
					     const class array<class CC_channel_class> &channels_tab ,    
					     const class array<bool> &is_it_forbidden_channel_tab , 
					     const class array<bool> &is_it_forbidden_channel_Berggren_tab , 
					     const class CG_str &CGs , 
					     const class interaction_class &inter_data_basis , 
					     const class array<double> &Gaussian_table_GL , 
					     const class multipolar_expansion_str &multipolar_expansion , 
					     const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
					     const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
					     const class baryons_data &prot_Y_data_one_configuration_GSM , 
					     const class baryons_data &neut_Y_data_one_configuration_GSM , 
					     const unsigned int ic ,  
					     const unsigned int icp ,  
					     const int nHOc ,  
					     const int nHOcp , 
					     const class baryons_data &prot_Y_data ,  
					     const class baryons_data &neut_Y_data , 
					     const class baryons_data &prot_Y_data_CC_Berggren ,  
					     const class baryons_data &neut_Y_data_CC_Berggren , 
					     const class array<unsigned int> &matrices_indices , 
					     const class matrix<complex<double> > &H_matrix);

  double finite_range_overlap_matrix_two_channels_two_HO_calc (
							       const double CC_average_n_scat_target_projectile_max , 
							       const class array<class CC_channel_class> &channels_tab ,    
							       const class array<bool> &is_it_forbidden_channel_tab , 
							       const unsigned int ic ,  
							       const unsigned int icp ,  
							       const int nHOc ,  
							       const int nHOcp , 
							       const class baryons_data &prot_Y_data ,  
							       const class baryons_data &neut_Y_data ,  
							       const class array<unsigned int> &matrices_indices , 
							       const class matrix<complex<double> > &overlaps_matrix) ;

  complex<double> finite_range_orthogonalized_potential_two_channels_two_CC_Berggren_calc (
											   const class array<class CC_channel_class> &channels_tab , 
											   const unsigned int ic ,  
											   const unsigned int icp ,  
											   const unsigned int nc ,  
											   const unsigned int ncp , 
											   const class baryons_data &prot_Y_data_CC_Berggren ,  
											   const class baryons_data &neut_Y_data_CC_Berggren, 
											   const class array<class matrix<complex<double> > > &finite_range_orthogonalized_potential_HO_submatrices);
}
#endif


