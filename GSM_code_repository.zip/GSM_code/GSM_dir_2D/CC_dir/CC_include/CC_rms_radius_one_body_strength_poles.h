#ifndef CC_RMSRADIUSONEBODYSTRENGTHPOLES_H
#define CC_RMSRADIUSONEBODYSTRENGTHPOLES_H

namespace CC_rms_radius_one_body_strength_poles
{
  void rms_radius_intrinsic_MEs_calc (
				      const class input_data_str &input_data , 
				      const enum operator_type rms_radius_op ,
				      const enum particle_type particle , 
				      const bool is_it_Gauss_Legendre , 
				      const class input_data_str &input_data_CC_Berggren ,  
				      const class array<double> &r_bef_R_tab ,
				      class array<class cluster_data> &cluster_projectile_data_tab , 
				      class CC_target_projectile_composite_data &Tpc_data);

  void calc (
	     const enum operator_type rms_radius_op , 
	     const enum particle_type particle , 
	     const int N_particle ,
	     const bool is_it_Gauss_Legendre , 
	     const bool is_it_nas_only , 
	     const class CC_target_projectile_composite_data &Tpc_data , 
	     const class input_data_str &input_data_CC_Berggren , 
	     const class interaction_class &inter_data_basis ,  
	     const class array<class cluster_data> &cluster_projectile_data_tab ,
	     const class CC_Hamiltonian_data &CC_H_data ,  
	     const class CC_state_class &CC_state , 
	     class baryons_data &prot_Y_data , 
	     class baryons_data &neut_Y_data,
	     class array<TYPE> &strength_tab);
  
  void calc_store (
		   const class input_data_str &input_data , 
		   const class input_data_str &input_data_CC_Berggren ,  
		   const class interaction_class &inter_data_basis , 
		   const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
		   const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
		   class baryons_data &prot_Y_data_CC_Berggren , 
		   class baryons_data &neut_Y_data_CC_Berggren , 
		   class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
		   class baryons_data &prot_Y_data , 
		   class baryons_data &neut_Y_data , 
		   class array<class cluster_data> &cluster_projectile_data_tab , 
		   class CC_target_projectile_composite_data &Tpc_data , 
		   class TBMEs_class &TBMEs_pn , 
		   class TBMEs_class &TBMEs_cv);
}

#endif


