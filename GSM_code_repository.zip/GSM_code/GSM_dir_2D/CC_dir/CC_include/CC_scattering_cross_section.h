#ifndef CC_SCATTERING_CROSS_SECTION_H
#define CC_SCATTERING_CROSS_SECTION_H

namespace CC_scattering_cross_section
{
  void iterative_calc (
		       const class input_data_str &input_data_CC_Berggren ,
		       const class interaction_class &inter_data_basis ,
		       const class HF_nucleons_data &prot_HF_data_CC_Berggren ,
		       const class HF_nucleons_data &neut_HF_data_CC_Berggren ,
		       const class CC_target_projectile_composite_data &Tpc_data ,
		       const class array<class cluster_data> &cluster_projectile_data_tab, 
		       class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab, 
		       class baryons_data &prot_Y_data_CC_Berggren ,
		       class baryons_data &neut_Y_data_CC_Berggren ,
		       class baryons_data &prot_Y_data ,
		       class baryons_data &neut_Y_data ,
		       class TBMEs_class &TBMEs_pn , 
		       class TBMEs_class &TBMEs_cv ,
		       class array<double> &phase_shifts , 
		       class array<complex<double> > &T_matrix_values);

  void CC_state_T_matrix_calc (
			       const unsigned int iE, 
			       const unsigned int i_entrance ,
			       const unsigned int iJPi_A ,
			       const bool compute_matrices ,
			       const class input_data_str &input_data_CC_Berggren ,
			       const class interaction_class &inter_data_basis ,
			       const class HF_nucleons_data &prot_HF_data_CC_Berggren ,
			       const class HF_nucleons_data &neut_HF_data_CC_Berggren ,
			       const class baryons_data &prot_Y_data_one_configuration_GSM ,
			       const class baryons_data &neut_Y_data_one_configuration_GSM ,
			       const class CC_target_projectile_composite_data &Tpc_data ,
			       const class array<class cluster_data> &cluster_projectile_data_tab, 
			       class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab, 
			       const class array<class CC_channel_class> &channels_JPi_A_tab,
			       class baryons_data &prot_Y_data_CC_Berggren ,
			       class baryons_data &neut_Y_data_CC_Berggren ,
			       const bool ME_storage ,
			       class baryons_data &prot_Y_data ,
			       class baryons_data &neut_Y_data,
			       class TBMEs_class &TBMEs_pn , 
			       class TBMEs_class &TBMEs_cv ,
			       class HF_nucleons_data &CC_prot_HF_data ,
			       class HF_nucleons_data &CC_neut_HF_data ,
			       class CC_Hamiltonian_data &CC_H_data ,
			       class array<double> &phase_shifts , 
			       class array<complex<double> > &T_matrix_values);

  void tau_tab_calc (
		     const bool print_detailed_information ,
		     const double K_CM , 
		     const class CC_target_projectile_composite_data &Tpc_data , 
		     class array<double> &tau_tab);

  void theta_lab_tab_calc (
			   const class array<bool> &is_it_pole_target_tab ,
			   const class array<double> &tau_tab , 
			   const class array<double> &theta_CM_tab , 
			   class array<double> &theta_lab_tab);

  void F_Coulomb_entrance_target_tab_calc (
					   const complex<double> &k_entrance_channel ,
					   const complex<double> &eta_entrance_channel ,
					   const class array<bool> &is_it_pole_target_tab , 
					   const class array<double> &theta_lab_tab , 
					   class array<complex<double> > &F_Coulomb_entrance_target_tab);

  void F_tab_Coulomb_part_calc (
				const class CC_target_projectile_composite_data &Tpc_data , 
				const class array<complex<double> > &F_Coulomb_entrance_target_tab , 
				class array<complex<double> > &F_tab);

  void F_tab_nuclear_part_calc (
				const class CC_target_projectile_composite_data &Tpc_data , 
				const class array<double> &theta_lab_tab , 
				const class array<complex<double> > &T_matrix_values ,
				const unsigned int iE,
				const double K_CM ,
				class array<complex<double> > &F_tab , 
				class array<complex<double> > &F_tab_left , 
				class array<complex<double> > &F_tab_right);


  double k_spin_factor_ratios_calc (
				    const class input_data_str &input_data_CC_Berggren , 
				    const class CC_target_projectile_composite_data &Tpc_data ,
				    const complex<double> &k_entrance_channel ,
				    const enum particle_type projectile ,
				    const complex<double> &k_channel);

  void differential_cross_section_lab_tab_calc (
						const class input_data_str &input_data_CC_Berggren , 
						const class CC_target_projectile_composite_data &Tpc_data , 
						const class array<complex<double> > &F_tab , 
						const unsigned int iE ,
						class array<double> &differential_cross_section_lab_tab);
  
  void analyzing_power_tab_calc (
				 const class CC_target_projectile_composite_data &Tpc_data , 
				 const class array<complex<double> > &F_tab_left , 
				 const class array<complex<double> > &F_tab_right , 
				 class array<double> &analyzing_power_lab_tab);
 
  void differential_cross_section_lab_to_CM_tab_calc (
						      const class CC_target_projectile_composite_data &Tpc_data , 
						      const double K_CM , 
						      const class array<double> &tau_tab , 
						      const class array<double> &theta_CM_tab , 
						      const class array <double> &differential_cross_section_lab_tab , 
						      class array <double> &differential_cross_section_CM_tab);

  void cross_section_analyzing_power_calc (
					   const class input_data_str &input_data_CC_Berggren , 
					   const class CC_target_projectile_composite_data &Tpc_data , 
					   const class array<complex<double> > &T_matrix_values , 
					   class array<double> &differential_cross_section_Coulomb_CM_vs_energy_tab , 
					   class array<double> &differential_cross_section_CM_vs_energy_tab , 
					   class array<double> &differential_cross_section_Coulomb_lab_vs_energy_tab , 
					   class array<double> &differential_cross_section_lab_vs_energy_tab , 
					   class array<double> &analyzing_power_vs_energy_tab);
	
  void cross_section_analyzing_power_print (
					    const bool print_detailed_information ,
					    const class CC_target_projectile_composite_data &Tpc_data , 
					    const class array<double> &differential_cross_section_Coulomb_CM_vs_energy_tab ,
					    const class array<double> &differential_cross_section_CM_vs_energy_tab ,
					    const class array<double> &differential_cross_section_Coulomb_lab_vs_energy_tab , 
					    const class array<double> &differential_cross_section_lab_vs_energy_tab , 
					    const class array<double> &analyzing_power_CM_vs_energy_tab);
	

  void phase_shifts_print (
			   const class CC_target_projectile_composite_data &Tpc_data , 
			   const class array<double> &phase_shifts);
  
  void calc_print (	
		   const class input_data_str &input_data_CC_Berggren ,  
		   const class interaction_class &inter_data_basis , 
		   const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
		   const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
		   class baryons_data &prot_Y_data_CC_Berggren , 
		   class baryons_data &neut_Y_data_CC_Berggren , 
		   class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab ,
		   class baryons_data &prot_Y_data , 
		   class baryons_data &neut_Y_data ,
		   class array<class cluster_data> &cluster_projectile_data_tab ,
		   class CC_target_projectile_composite_data &Tpc_data ,
		   class TBMEs_class &TBMEs_pn , 
		   class TBMEs_class &TBMEs_cv);
}

#endif


