#ifndef CC_EMTRANSITIONSSTRENGTHPOLES_H
#define CC_EMTRANSITIONSSTRENGTHPOLES_H

namespace CC_EM_transitions_strength_poles
{
  void EM_suboperators_intrinsic_MEs_calc (
					   const class input_data_str &input_data ,
					   const TYPE &q ,
					   const int L , 
					   const bool is_it_longwavelength_approximation ,
					   const bool is_it_Gauss_Legendre , 
					   const class interaction_class &inter_data_basis ,  
					   class array<class cluster_data> &cluster_projectile_data_tab , 
					   class CC_target_projectile_composite_data &Tpc_data);
  void B_amplitude_tab_calc (
			     const enum EM_type EM , 
			     const int L , 
			     const bool is_it_longwavelength_approximation ,
			     const bool is_it_Gauss_Legendre , 
			     const bool is_it_nas_only ,
			     const class CC_target_projectile_composite_data &Tpc_data , 
			     const class input_data_str &input_data_CC_Berggren , 
			     const class interaction_class &inter_data_basis ,  
			     const class array<class cluster_data> &cluster_projectile_data_tab ,
			     const class CC_Hamiltonian_data &CC_H_data_in ,  
			     const class CC_state_class &CC_state_in , 
			     const class CC_Hamiltonian_data &CC_H_data_out , 
			     const class CC_state_class &CC_state_out ,  
			     class baryons_data &prot_Y_data , 
			     class baryons_data &neut_Y_data ,
			     class array<TYPE> &strength_tab);

  void calc_store (
		   const class input_data_str &input_data ,
		   const class input_data_str &input_data_CC_Berggren ,  
		   const class interaction_class &inter_data_basis ,
		   const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
		   const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
		   class baryons_data &prot_Y_data_CC_Berggren , 
		   class baryons_data &neut_Y_data_CC_Berggren , 
		   class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab ,
		   class baryons_data &prot_Y_data , 
		   class baryons_data &neut_Y_data ,
		   class array<class cluster_data> &cluster_projectile_data_tab ,
		   class CC_target_projectile_composite_data &Tpc_data ,
		   class TBMEs_class &TBMEs_pn , 
		   class TBMEs_class &TBMEs_cv);
}

#endif


