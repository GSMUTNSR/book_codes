#include "CC_include/CC_include_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

enum called_code_type called_code = CC_CODE;

using namespace inputs_misc;
using namespace string_routines;
using namespace GSM_vector_dimensions;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    print_array_vector_test_status<int> ();

    //--// dummy variables

    class array<double> dummy_array_double;

    class array<string> dummy_array_string;

    class array<class input_data_str> dummy_input_data_tab;

    const class array<class array<class JT_coupled_TBME> > dummy_array_JT_coupled_TBME;

    //================================== input data and nucleons data  ==================================//
    
    //--// Initialization of classes which contain all input values and some pointers on tables from the input (not all initialized here)

    class input_data_str input_data;
    
    class input_data_str input_data_CC_Berggren;

    call_common_routines::input_data_read_MPI_transfer (dummy_array_double , dummy_array_double , dummy_array_string , input_data , input_data_CC_Berggren , dummy_input_data_tab);

    const int N_channels_max = make_int (input_data.N_channels_max_calc ());

    input_data.add_N_channels_max_to_nmax (N_channels_max);

    input_data_CC_Berggren.add_N_channels_max_to_nmax (N_channels_max);
    
    if (THIS_PROCESS == MASTER_PROCESS) MPI_2D_partitioning::print_active_processes_numbers ();
    
    //--// initialization of the classes which contain information on p and n

    class baryons_data prot_Y_data;
    class baryons_data neut_Y_data;

    class baryons_data prot_Y_data_CC_Berggren;
    class baryons_data neut_Y_data_CC_Berggren;

    baryons_data_initialization (true , input_data , prot_Y_data , neut_Y_data);

    baryons_data_initialization (true , input_data_CC_Berggren , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren);
    
    const enum space_type basis_space = input_data.get_basis_space ();
    
    const enum space_type space = input_data.get_space ();

    //--// setting the maximal numbers of scattering states of CC_Berggren classes to those of input_data
    set_all_n_holes_max_n_scat_max_CC_Berggren_classes (input_data , input_data_CC_Berggren , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren);
    
    //================================== basis interaction and HF potentials  ==================================//
    
    //--// class which contains information on the interaction for the basis

    class interaction_class inter_data_basis (true , true , false , input_data_CC_Berggren);

    inter_data_basis.inter_data_calc (input_data_CC_Berggren);

    //--// classes which contain information on p and n in the HF potential
    
    class HF_nucleons_data prot_HF_data(input_data , prot_Y_data);
    class HF_nucleons_data neut_HF_data(input_data , neut_Y_data);

    const enum potential_type basis_potential = input_data.get_basis_potential ();
        
    if (THIS_PROCESS == MASTER_PROCESS)
      {
	cout << endl << "Potentials for GSM basis" << endl;
	cout <<         "------------------------" << endl << endl;
    }
 
    if (basis_potential == MSDHF)
      MSDHF_potentials::potentials_shells_OBMEs_realloc_calc (true , input_data , inter_data_basis , prot_HF_data , neut_HF_data , prot_Y_data , neut_Y_data);
    else
      HF_potentials::potentials_shells_OBMEs_realloc_calc (true , input_data , inter_data_basis , prot_HF_data , neut_HF_data , prot_Y_data , neut_Y_data);
 
    prot_HF_data.deallocate ();
    neut_HF_data.deallocate ();
    
    if (THIS_PROCESS == MASTER_PROCESS)
      {
	cout << endl << "Potentials for GSM-CC basis" << endl;
	cout <<         "---------------------------" << endl << endl;
      }
    
    //--// classes which contain information on p and n in the HF potential for CC Berggren classes
    class HF_nucleons_data prot_HF_data_CC_Berggren(input_data_CC_Berggren , prot_Y_data_CC_Berggren);
    class HF_nucleons_data neut_HF_data_CC_Berggren(input_data_CC_Berggren , neut_Y_data_CC_Berggren);

    if (basis_potential == MSDHF)
      MSDHF_potentials::potentials_shells_OBMEs_realloc_calc (true , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren);
    else
      HF_potentials::potentials_shells_OBMEs_realloc_calc (true , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren);
 
    
    //================================== Berggren one-body basis and space truncation  ==================================//
    
    //--// initialization of the tables containing the one-body basis, OBMEs, TBMEs, configurations, SDs
    
    if (THIS_PROCESS == MASTER_PROCESS)
      {
	cout << endl << "Berggren basis for GSM basis" << endl;
	cout <<         "----------------------------" << endl << endl;
      }
    
    Berggren_basis::single_particle_indices_radial_wfs_pn_alloc_calc (true , input_data , prot_Y_data , neut_Y_data);
     
    inputs_misc::space_truncation_data_best_hbar_omega_calc (true , input_data , prot_Y_data , neut_Y_data);

    inputs_misc::space_truncation_data_best_hbar_omega_calc (true , input_data_CC_Berggren , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren);

    //--// calculation of the one-body Berggren basis of CC_Berggren classes
    
    if (THIS_PROCESS == MASTER_PROCESS)
      {
	cout << endl << "Berggren basis for GSM-CC basis" << endl;
	cout <<         "-------------------------------" << endl << endl;
      }
    
    Berggren_basis::single_particle_indices_radial_wfs_pn_alloc_calc (true , input_data , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren);
    
    //================================== GSM interaction  ==================================//
    
    //--// class which contains information on the interaction

    class interaction_class inter_data(true , false , false , input_data);

    inter_data.inter_data_calc (input_data);
    
    //================================== OBMEs, TBMEs  ==================================//
    
    all_HO_GHF_overlaps_pn_alloc_calc (input_data , prot_Y_data , neut_Y_data);
    
    all_HO_GHF_overlaps_pn_alloc_calc (input_data_CC_Berggren , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren);
    
    //--// initialization of the class which contains proton-neutron TBMEs and pp <-> nn conversion TBMEs

    class TBMEs_class TBMEs_pn;
    class TBMEs_class TBMEs_cv;
    
    OBMEs_TBMEs::all_OBMEs_TBMEs_alloc_calc (true , false , dummy_array_JT_coupled_TBME , inter_data_basis , inter_data , input_data , prot_Y_data , neut_Y_data , TBMEs_pn , TBMEs_cv);

    hole_double_counting::prot_neut_OBMEs_no_natural_orbitals_calc_store_remove (false , input_data , prot_Y_data , neut_Y_data , TBMEs_pn);
    
    OBMEs_TBMEs::Berggren::h_basis_prot_neut_alloc_calc (basis_space , inter_data , true , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren);
    
    //================================== configurations, SDs  ==================================//
    
    configuration_SD_sets::configuration_SD_tables_pp_nn_alloc_calc (true , false , true , input_data , prot_Y_data , neut_Y_data);

    //================================== GSM space dimensions ==================================//
        
    const int n_scat_max = input_data.get_n_scat_max ();

    const int n_scat_max_plus_one = n_scat_max + 1;

    const unsigned int J_index_max = J_index_max_calc (space , prot_Y_data , neut_Y_data);

    const unsigned int J_index_max_plus_one = J_index_max + 1;
  
    //--// initialization of the tables containing the GSM space dimensions at pole approximation and in full space

    class array<unsigned long int> total_space_dimensions_good_J_pole_approximation(2 , 1 , J_index_max_plus_one);

    class array<unsigned long int> total_space_dimensions_good_J(2 , n_scat_max_plus_one , J_index_max_plus_one);

    all_J_total_space_dimensions_calc_print (true , input_data , prot_Y_data , neut_Y_data , total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J);
    
    //================================== CC calculations: CC reaction data, clusters, cross sections, observables ==================================//
    
    const enum CC_reaction_type CC_reaction = input_data.get_CC_reaction ();

    //--// allowed J-Pi quantum numbers of different channels printed on screen
    if (THIS_PROCESS == MASTER_PROCESS) observable_allowed_JPi_channels_calc_print (CC_reaction , input_data_CC_Berggren);

    //--// initialization of the structure containing the data related to CC calculations
    class CC_target_projectile_composite_data Tpc_data(input_data , prot_Y_data , neut_Y_data);
    
    const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();

    const unsigned int CC_cluster_projectile_number = input_data.get_CC_cluster_projectile_number ();

    class array<class cluster_data> cluster_projectile_data_tab(CC_cluster_projectile_number);
    
    class array<class cluster_data> cluster_projectile_data_CC_Berggren_tab(CC_cluster_projectile_number);
    
    //--// initialization of clusters data for for CC calculations involving cluster projectiles
    if (!is_it_one_baryon_COSM_case) cluster_projectile_data_tab_PCM_matrices_alloc_calc (inter_data_basis , input_data , prot_Y_data , neut_Y_data , cluster_projectile_data_tab ,
											    input_data_CC_Berggren , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , cluster_projectile_data_CC_Berggren_tab);

    //--// calculation of cross sections and observables in GSM-CC
    CC_observables_common::cross_sections_observables_calc_print_store (input_data , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
								        prot_Y_data , neut_Y_data , cluster_projectile_data_tab , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , cluster_projectile_data_CC_Berggren_tab , Tpc_data , TBMEs_pn , TBMEs_cv);
    
    //Parallel instruction
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
    
    return 0;
  }


