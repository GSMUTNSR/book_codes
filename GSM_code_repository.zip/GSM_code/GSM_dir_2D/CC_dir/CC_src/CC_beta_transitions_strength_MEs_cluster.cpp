#include "../CC_include/CC_include_def.h"


using namespace angular_matrix_elements;
using namespace beta_transitions_common;
using namespace beta_transitions_strength_OBMEs;
using namespace beta_transitions_strength;
using namespace inputs_misc;

using namespace CC_beta_transitions_strength_MEs::radial;



void CC_beta_transitions_strength_MEs::cluster::beta_suboperator_intrinsic_NBMEs_calc (
										       const enum beta_pm_type beta_pm ,
										       const enum radial_operator_type radial_operator ,
										       const enum beta_suboperator_type beta_suboperator ,
										       const bool is_it_Gauss_Legendre , 
										       const class correlated_state_str &PSI_cluster_qn_c ,  
										       const class correlated_state_str &PSI_cluster_qn_cp ,
										       const class GSM_vector &PSI_cluster_cp ,
										       class array<TYPE> &beta_suboperator_intrinsic_NBMEs_strength)
{
  const class GSM_vector_helper_class &PSI_helper_cp =  PSI_cluster_cp.get_GSM_vector_helper ();
  
  const class baryons_data &prot_Y_data = PSI_helper_cp.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = PSI_helper_cp.get_neut_Y_data ();

  const class baryons_data &data_c  = data_in_determine  (beta_pm , prot_Y_data , neut_Y_data);
  const class baryons_data &data_cp = data_out_determine (beta_pm , prot_Y_data , neut_Y_data);

  const unsigned int N_nlj_c  = data_c.get_N_nlj_baryon ();
  const unsigned int N_nlj_cp = data_cp.get_N_nlj_baryon ();

  const unsigned int N_nljm_c  = data_c.get_N_nljm_baryon ();
  const unsigned int N_nljm_cp = data_cp.get_N_nljm_baryon ();

  const unsigned int N_bef_R_GL = data_c.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = data_c.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const double Jc  = PSI_cluster_qn_c.get_J ();
  const double Jcp = PSI_cluster_qn_cp.get_J ();

  const double Mc  = Jc;
  const double Mcp = Jcp;

  const unsigned int BP_Op = BP_beta_suboperator_determine (beta_suboperator);

  const unsigned int BP_in  = PSI_cluster_qn_c.get_BP ();
  const unsigned int BP_out = PSI_cluster_qn_cp.get_BP ();

  if (binary_parity_product (BP_in , BP_Op) != BP_out) return;

  const int rank_Op = rank_beta_suboperator_determine (beta_suboperator);

  const int rank_Op_projection = make_int (Mcp - Mc);

  const int Z_projectile_in = PSI_cluster_qn_c.get_Z ();
  const int N_projectile_in = PSI_cluster_qn_c.get_N ();

  const int Z_projectile_out = PSI_cluster_qn_cp.get_Z ();
  const int N_projectile_out = PSI_cluster_qn_cp.get_N ();

  if (Z_projectile_in != Z_IN_beta_determine (beta_pm , Z_projectile_out)) return;
  if (N_projectile_in != N_IN_beta_determine (beta_pm , N_projectile_out)) return;

  const double J_projectile_in  = PSI_cluster_qn_c.get_J ();
  const double J_projectile_out = PSI_cluster_qn_cp.get_J ();

  if ((abs (make_int (J_projectile_out - J_projectile_in)) > rank_Op) || (make_int (J_projectile_out + J_projectile_in) < rank_Op)) return;

  const unsigned int beta_suboperator_index = beta_suboperator_type_index_determine (beta_suboperator);

  class array<TYPE> OBMEs_reduced(N_nlj_c , N_nlj_cp , Nr);

  class array<TYPE> OBMEs(N_nljm_c , N_nljm_cp , Nr);

  class array<TYPE> OBMEs_part(N_nljm_c , N_nljm_cp);

  beta_suboperator_OBMEs_reduced_calc (radial_operator , beta_suboperator , is_it_Gauss_Legendre , data_c , data_cp , OBMEs_reduced);

  OBMEs_dereduced_strength_calc<TYPE> (rank_Op , rank_Op_projection , data_c , data_cp , OBMEs_reduced , OBMEs);

  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      for (unsigned int s_c = 0 ; s_c < N_nljm_c ; s_c++)
	for (unsigned int s_cp = 0 ; s_cp < N_nljm_cp ; s_cp++)
	  OBMEs_part(s_c , s_cp) = OBMEs(s_c , s_cp , i);

      beta_suboperator_intrinsic_NBMEs_strength(beta_suboperator_index , i) = beta_transitions_NBMEs::calc (beta_pm ,  beta_suboperator , true , OBMEs_part , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp);
    }
}







//--// return <uc_f lf jf || beta || uc_i li ji>
void CC_beta_transitions_strength_MEs::cluster::beta_suboperators_intrinsic_NBMEs_calc (
											const enum beta_type beta , 
											const enum beta_pm_type beta_pm ,
											const bool is_it_Gauss_Legendre , 
											const class correlated_state_str &PSI_cluster_qn_c ,  
											const class correlated_state_str &PSI_cluster_qn_cp ,
											const class GSM_vector &PSI_cluster_cp ,
											class array<TYPE> &beta_suboperator_intrinsic_NBMEs_strength)
{
  switch (beta)
    {
    case ALLOWED:
      {
	beta_suboperator_intrinsic_NBMEs_calc (beta_pm , OVERLAP , FERMI_ALLOWED        , is_it_Gauss_Legendre , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp , beta_suboperator_intrinsic_NBMEs_strength);
	beta_suboperator_intrinsic_NBMEs_calc (beta_pm , OVERLAP , GAMOW_TELLER_ALLOWED , is_it_Gauss_Legendre ,  PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp , beta_suboperator_intrinsic_NBMEs_strength);
      } break;

    case FIRST_FORBIDDEN:
      {
	beta_suboperator_intrinsic_NBMEs_calc (beta_pm , FFBD , W_FFBD , is_it_Gauss_Legendre , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp ,  beta_suboperator_intrinsic_NBMEs_strength);
	beta_suboperator_intrinsic_NBMEs_calc (beta_pm , FFBD , U_FFBD , is_it_Gauss_Legendre , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp ,  beta_suboperator_intrinsic_NBMEs_strength);
	beta_suboperator_intrinsic_NBMEs_calc (beta_pm , FFBD , Z_FFBD , is_it_Gauss_Legendre , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp ,  beta_suboperator_intrinsic_NBMEs_strength);
	beta_suboperator_intrinsic_NBMEs_calc (beta_pm , FFBD , X_FFBD , is_it_Gauss_Legendre , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp ,  beta_suboperator_intrinsic_NBMEs_strength);

	beta_suboperator_intrinsic_NBMEs_calc (beta_pm , FFBD_COULOMB , W_FFBD_COULOMB , is_it_Gauss_Legendre , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp ,  beta_suboperator_intrinsic_NBMEs_strength);
	beta_suboperator_intrinsic_NBMEs_calc (beta_pm , FFBD_COULOMB , U_FFBD_COULOMB , is_it_Gauss_Legendre , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp ,  beta_suboperator_intrinsic_NBMEs_strength);
	beta_suboperator_intrinsic_NBMEs_calc (beta_pm , FFBD_COULOMB , X_FFBD_COULOMB , is_it_Gauss_Legendre , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp ,  beta_suboperator_intrinsic_NBMEs_strength);

	beta_suboperator_intrinsic_NBMEs_calc (beta_pm , REDUCED_GRADIENT , XI_PRIME_V_FFBD , is_it_Gauss_Legendre , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp ,  beta_suboperator_intrinsic_NBMEs_strength);
	beta_suboperator_intrinsic_NBMEs_calc (beta_pm , REDUCED_GRADIENT , XI_PRIME_Y_FFBD , is_it_Gauss_Legendre , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp ,  beta_suboperator_intrinsic_NBMEs_strength);
      } break;

    default: abort_all ();
    }
}









//--// return <uc_f lf jf || beta || uc_i li ji>
void CC_beta_transitions_strength_MEs::cluster::beta_suboperator_NBMEs_calc (
									     const enum beta_type beta ,
									     const enum radial_operator_type radial_operator ,
									     const enum beta_suboperator_type beta_suboperator , 
									     const bool is_it_Gauss_Legendre , 
									     const class CC_target_projectile_composite_data &Tpc_data,
									     const unsigned int ic ,
									     const unsigned int icp ,
									     const class correlated_state_str &PSI_cluster_qn_c ,  
									     const class correlated_state_str &PSI_cluster_qn_cp ,
									     const class CC_state_class &CC_state_in , 
									     const class CC_state_class &CC_state_out , 
									     const unsigned int ic_in , 
									     const unsigned int ic_out,
									     class array<TYPE> &beta_suboperator_tab)
{
  const unsigned int BP_Op = BP_beta_determine (beta);

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out) == BP_Op)
    {
      const class array<TYPE> &beta_suboperator_intrinsic_NBMEs_strength = Tpc_data.get_beta_suboperator_intrinsic_NBMEs_strength ();

      const int A = CC_state_in.get_A ();
      
      const double R_charge = R_charge_beta_calc (A);

      const unsigned int beta_suboperator_index = beta_suboperator_type_index_determine (beta_suboperator);

      const unsigned int Nr = beta_suboperator_tab.dimension (1);

      class array<TYPE> radial_OBMEs(Nr);

      switch (beta)
	{
	case ALLOWED:
	  {
	    const TYPE allowed_intrinsic_ME = beta_suboperator_intrinsic_NBMEs_strength(ic , icp , beta_suboperator_index);

	    radial_OBMEs_calc (radial_operator , R_charge , is_it_Gauss_Legendre , CC_state_in , CC_state_out ,ic_in , ic_out , radial_OBMEs);

	    for (unsigned int i = 0 ; i < Nr ; i++)
	      {
		const TYPE allowed_CM_ME = radial_OBMEs(i);

		const TYPE allowed_ME = allowed_CM_ME*allowed_intrinsic_ME;

		beta_suboperator_tab(beta_suboperator_index , i) = allowed_ME;
	      }
	  } break;

	case FIRST_FORBIDDEN:
	  {
	    const enum beta_suboperator_type beta_intrinsic_suboperator = beta_intrinsic_suboperator_determine (beta_suboperator);

	    const int rank_Op = rank_beta_suboperator_determine (beta_suboperator);

	    const int rank_intrinsic_Op = rank_beta_suboperator_determine (beta_intrinsic_suboperator);

	    const int rank_CM = 1;		

	    const TYPE FFBD_intrinsic_ME = beta_suboperator_intrinsic_NBMEs_strength(ic , icp , beta_suboperator_index);

	    const double angular_part_FFBD_CM_ME = OBME_YL_reduced_in_l (rank_CM , LCM_projectile_in , LCM_projectile_out);

	    const double J_intrinsic_in  = PSI_cluster_qn_c.get_J ();
	    const double J_intrinsic_out = PSI_cluster_qn_cp.get_J ();

	    const double J_in  = CC_state_in.get_J ();
	    const double J_out = CC_state_out.get_J ();

	    radial_OBMEs_calc (radial_operator , R_charge , is_it_Gauss_Legendre , CC_state_in , CC_state_out ,ic_in , ic_out , radial_OBMEs);

	    for (unsigned int i = 0 ; i < Nr ; i++)
	      {
		const TYPE radial_FFBD_CM_ME = radial_OBMEs(i);

		const TYPE FFBD_CM_ME = radial_FFBD_CM_ME*angular_part_FFBD_CM_ME;

		const TYPE FFBD_ME = Oa_tensor_Ob_reduced_ME_calc (rank_CM , rank_intrinsic_Op , rank_Op , LCM_projectile_in , J_intrinsic_in , J_in , LCM_projectile_out , J_intrinsic_out , J_out , FFBD_CM_ME , FFBD_intrinsic_ME);

		beta_suboperator_tab(beta_suboperator_index , i) = FFBD_ME;
	      }
	  } break;

	default: abort_all ();
	}
    }
}






//--// return <uc_f lf jf || beta || uc_i li ji>
void CC_beta_transitions_strength_MEs::cluster::beta_suboperators_NBMEs_calc (
									      const enum beta_type beta , 
									      const bool is_it_Gauss_Legendre , 
									      const class CC_target_projectile_composite_data &Tpc_data,
									      const unsigned int ic ,
									      const unsigned int icp , 
									      const class correlated_state_str &PSI_cluster_qn_c ,  
									      const class correlated_state_str &PSI_cluster_qn_cp ,
									      const class CC_state_class &CC_state_in , 
									      const class CC_state_class &CC_state_out , 
									      const unsigned int ic_in , 
									      const unsigned int ic_out , 
									      class array<TYPE> &beta_suboperator_tab)
{
  const unsigned int BP_Op = BP_beta_determine (beta);

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out) != BP_Op) return;
    
  switch (beta)
    {
    case ALLOWED:
      {
	beta_suboperator_NBMEs_calc (beta , OVERLAP , FERMI_ALLOWED        , is_it_Gauss_Legendre , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
	beta_suboperator_NBMEs_calc (beta , OVERLAP , GAMOW_TELLER_ALLOWED , is_it_Gauss_Legendre , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
      } break;

    case FIRST_FORBIDDEN:
      {
	beta_suboperator_NBMEs_calc (beta , FFBD , W_FFBD , is_it_Gauss_Legendre , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
	beta_suboperator_NBMEs_calc (beta , FFBD , U_FFBD , is_it_Gauss_Legendre , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
	beta_suboperator_NBMEs_calc (beta , FFBD , Z_FFBD , is_it_Gauss_Legendre , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
	beta_suboperator_NBMEs_calc (beta , FFBD , X_FFBD , is_it_Gauss_Legendre , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);

	beta_suboperator_NBMEs_calc (beta , FFBD_COULOMB , W_FFBD_COULOMB , is_it_Gauss_Legendre , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
	beta_suboperator_NBMEs_calc (beta , FFBD_COULOMB , U_FFBD_COULOMB , is_it_Gauss_Legendre , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
	beta_suboperator_NBMEs_calc (beta , FFBD_COULOMB , X_FFBD_COULOMB , is_it_Gauss_Legendre , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);

	beta_suboperator_NBMEs_calc (beta , REDUCED_GRADIENT , XI_PRIME_V_FFBD , is_it_Gauss_Legendre , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);

	beta_suboperator_NBMEs_calc (beta , REDUCED_GRADIENT , XI_PRIME_Y_FFBD , is_it_Gauss_Legendre , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
      } break;

    default: abort_all ();
    }
}


