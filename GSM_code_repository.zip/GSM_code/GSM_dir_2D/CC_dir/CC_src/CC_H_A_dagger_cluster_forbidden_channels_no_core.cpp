#include "../CC_include/CC_include_def.h"

using namespace string_routines;
using namespace correlated_state_routines;
using namespace inputs_misc;
using namespace A_dagger_cluster_helper;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;


void CC_H_A_dagger_cluster_forbidden_channels_no_core::A_dagger_calculations_and_copy_disk (
											    const bool print_detailed_information , 
											    const class array<class CC_channel_class> &channels_tab , 
											    const class array<class cluster_data> &cluster_projectile_data_tab , 
											    const double J , 
											    const class J2_class &J2 , 
											    const class CM_operator_class &Hcm ,
											    class GSM_vector &Vstore , 
											    class GSM_vector &A_dagger_PSI_c_coupled) 
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Relative A+(projectile) |target> cluster calculation (no core)" << endl;
      cout         << "--------------------------------------------------------------" << endl << endl;
    }
  
  const class GSM_vector_helper_class &GSM_vector_helper = A_dagger_PSI_c_coupled.get_GSM_vector_helper ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const unsigned int N_channels = channels_tab.dimension (0);

  const double M = GSM_vector_helper.get_M ();
     for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const complex<double> E_intrinsic_Tc = channel_c.get_E_Tc ();

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const enum particle_type Tc = channel_c.get_Tc_no_core ();

      const int Z_Tc = channel_c.get_Z_Tc ();
      const int N_Tc = channel_c.get_N_Tc ();
      
      const int S_Tc = channel_c.get_S_Tc ();
      
      const unsigned int BP_intrinsic_Tc = channel_c.get_BP_Tc ();

      const unsigned int vector_index_intrinsic_Tc = channel_c.get_vector_index_Tc ();

      const double J_relative_projectile_c = channel_c.get_J_projectile ();

      const double J_intrinsic_Tc = channel_c.get_J_Tc ();

      const int Z_projectile_c = channel_c.get_Z_projectile ();
      const int N_projectile_c = channel_c.get_N_projectile ();
      const int A_projectile_c = channel_c.get_A_projectile ();

      const int S_projectile_c = channel_c.get_S_projectile ();
      
      const double mass_Tc = channel_c.get_mass_Tc ();
      
      const double mass_projectile_c = channel_c.get_mass_projectile ();

      const double mass_ratio = mass_projectile_c/mass_Tc;
      
      const int LCM_relative_projectile_c = channel_c.get_LCM_projectile ();

      const unsigned int BP_intrinsic_projectile_c = channel_c.get_BP_intrinsic_projectile ();
      
      const double J_intrinsic_projectile_c = channel_c.get_J_intrinsic_projectile ();
      
      const unsigned int BP_relative_projectile_c = channel_c.get_BP_projectile ();

      const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);

      const class lj_table<int> &NCM_HO_max_relative_cluster_projectile_CM_tab_c = data_c.get_Nmax_cluster_projectile_CM_tab ();	

      const int NCM_HO_max_relative_cluster_LCM_J_projectile_c = NCM_HO_max_relative_cluster_projectile_CM_tab_c(LCM_relative_projectile_c , J_relative_projectile_c);

      const string Tc_str = "Target[c] : Z:" + make_string<int> (Z_Tc) + " N:" + make_string<int> (N_Tc) + " " + J_Pi_vector_index_string (BP_intrinsic_Tc , J_intrinsic_Tc , vector_index_intrinsic_Tc);

      if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl << "ic : " << ic << " channel[rel] : " << channel_c << " NCM-HO[max] : " << NCM_HO_max_relative_cluster_LCM_J_projectile_c << endl << endl;

      const class correlated_state_str PSI_relative_projectile_qn_c(Z_projectile_c , N_projectile_c , BP_relative_projectile_c , S_projectile_c , J_relative_projectile_c , NADA , NADA , NADA , NADA , NADA , false);
	      
      const class correlated_state_str PSI_intrinsic_qn_Tc(Z_Tc , N_Tc , BP_intrinsic_Tc , S_Tc , J_intrinsic_Tc , vector_index_intrinsic_Tc , E_intrinsic_Tc , NADA , NADA , NADA , false);

      const int NCM_HO_max_relative_cluster_LCM_J_projectile_c_plus_one = NCM_HO_max_relative_cluster_LCM_J_projectile_c + 1;

      const int E_HO_relative_max = 2*NCM_HO_max_relative_cluster_LCM_J_projectile_c + LCM_relative_projectile_c;
  
      const int E_HO_relative_max_plus_one = E_HO_relative_max + 1;

      const int two_J_intrinsic_Tc = make_int (2.0*J_intrinsic_Tc);
  
      const int two_J_intrinsic_projectile_c = make_int (2.0*J_intrinsic_projectile_c);
    
      const double J_Tc_min = (two_J_intrinsic_Tc%2 == 0) ? (0) : (0.5);
  
      const double J_Tc_max = J_intrinsic_Tc + E_HO_relative_max;

      const double J_projectile_c_min = (two_J_intrinsic_projectile_c%2 == 0) ? (0) : (0.5);
  
      const double J_projectile_c_max = J_intrinsic_projectile_c + E_HO_relative_max;

      const int J_Tc_number_max = make_int (J_Tc_max - J_Tc_min) + 1;
  
      const int J_projectile_c_number_max = make_int (J_projectile_c_max - J_projectile_c_min) + 1;
  
      const double J_intrinsic_min_Tc_projectile_c = abs (J_intrinsic_Tc - J_intrinsic_projectile_c);  
      const double J_intrinsic_max_Tc_projectile_c =      J_intrinsic_Tc + J_intrinsic_projectile_c;

      const double J_intrinsic_min_LCM_relative_J = abs (LCM_relative_projectile_c - J);  
      const double J_intrinsic_max_LCM_relative_J =      LCM_relative_projectile_c + J;

      const double J_intrinsic_min = max (J_intrinsic_min_Tc_projectile_c , J_intrinsic_min_LCM_relative_J);  
      const double J_intrinsic_max = min (J_intrinsic_max_Tc_projectile_c , J_intrinsic_max_LCM_relative_J);
  
      const double Jmin_J_intrinsic_Tc_J_relative_projectile_c = abs (J_intrinsic_Tc - J_relative_projectile_c);		  
      const double Jmax_J_intrinsic_Tc_J_relative_projectile_c =      J_intrinsic_Tc + J_relative_projectile_c;
  
      const int J_intrinsic_number = make_int (J_intrinsic_max - J_intrinsic_min) + 1;
      
      class array<class Moshinsky_table> Moshinsky_tables(NCM_HO_max_relative_cluster_LCM_J_projectile_c_plus_one);
 
      class array<double> three_js_recoupling_table(J_intrinsic_number);

      class array<double> four_js_recoupling_table(J_intrinsic_number , E_HO_relative_max_plus_one , E_HO_relative_max_plus_one , J_Tc_number_max , J_projectile_c_number_max);

      Moshinsky_coefficients_recoupling_tables_non_spurious_reaction_channels_calc (LCM_relative_projectile_c , J_intrinsic_Tc , J_intrinsic_projectile_c , J_relative_projectile_c , J , mass_ratio ,
										    Moshinsky_tables , three_js_recoupling_table , four_js_recoupling_table);
      
      for (int NCM_HO_relative_c = 0 ; NCM_HO_relative_c <= NCM_HO_max_relative_cluster_LCM_J_projectile_c ; NCM_HO_relative_c++) 
	{
	  const double reference_time = absolute_time_determine ();	
			  
	  const int E_HO_relative = 2*NCM_HO_relative_c + LCM_relative_projectile_c;

	  const int NCM_HO_Tc_projectile_c_max = E_HO_relative/2;

	  const class Moshinsky_table &Moshinsky_table_NCM_HO_relative = Moshinsky_tables(NCM_HO_relative_c);
	  
	  A_dagger_PSI_c_coupled = 0.0;
	  
	  for (int NCM_HO_Tc = 0 ; NCM_HO_Tc <= NCM_HO_Tc_projectile_c_max ; NCM_HO_Tc++)
	    for (int LCM_Tc = 0 ; LCM_Tc <= E_HO_relative ; LCM_Tc++)
	      {
		const int E_Tc_HO = 2*NCM_HO_Tc + LCM_Tc;

		const unsigned int BP_Tc = binary_parity_product (BP_intrinsic_Tc , binary_parity_from_orbital_angular_momentum (LCM_Tc));
	  
		const double J_Tc_min_local = abs (LCM_Tc - J_intrinsic_Tc);
		const double J_Tc_max_local =      LCM_Tc + J_intrinsic_Tc;

		const int J_Tc_number = make_int (J_Tc_max_local - J_Tc_min_local) + 1;
				  
		for (int NCM_HO_projectile_c = 0 ; NCM_HO_projectile_c <= NCM_HO_Tc_projectile_c_max ; NCM_HO_projectile_c++)
		  for (int LCM_projectile_c = 0 ; LCM_projectile_c <= E_HO_relative ; LCM_projectile_c++)
		    {
		      const int E_projectile_c_HO = 2*NCM_HO_projectile_c + LCM_projectile_c;
		      
		      const unsigned int BP_projectile_c = binary_parity_product (BP_intrinsic_projectile_c , binary_parity_from_orbital_angular_momentum (LCM_projectile_c));
		
		      if (E_Tc_HO + E_projectile_c_HO == E_HO_relative)
			{  
			  const double Moshinsky_coefficient = Moshinsky_table_NCM_HO_relative(NCM_HO_Tc , LCM_Tc , NCM_HO_projectile_c , LCM_projectile_c);

			  const double J_projectile_c_min_local = abs (LCM_projectile_c - J_intrinsic_projectile_c);
			  const double J_projectile_c_max_local =      LCM_projectile_c + J_intrinsic_projectile_c;
		
			  const int J_projectile_c_number = make_int (J_projectile_c_max_local - J_projectile_c_min_local) + 1;
		
			  const double LCM_J_intrinsic_projectile_c_Tc_sum = LCM_projectile_c + J_intrinsic_projectile_c + LCM_Tc + J_intrinsic_Tc;
			  
			  for (int iJ_intrinsic = 0 ; iJ_intrinsic < J_intrinsic_number ; iJ_intrinsic++)
			    {
			      const double J_intrinsic = iJ_intrinsic + J_intrinsic_min;
						
			      const double Jmin_LCM_relative_J_intrinsic = abs (LCM_relative_projectile_c - J_intrinsic);
			      const double Jmax_LCM_relative_J_intrinsic =      LCM_relative_projectile_c + J_intrinsic;
										    
			      const double Jmin_intrinsic_relative = max (Jmin_LCM_relative_J_intrinsic , Jmin_J_intrinsic_Tc_J_relative_projectile_c);
			      const double Jmax_intrinsic_relative = min (Jmax_LCM_relative_J_intrinsic , Jmax_J_intrinsic_Tc_J_relative_projectile_c);
					
			      const double three_js_recoupling_coefficient = three_js_recoupling_table(iJ_intrinsic);

			      const double Moshinsky_three_js_recoupling_coefficients_product = Moshinsky_coefficient*three_js_recoupling_coefficient;
				  
			      for (int iJ_Tc = 0 ; iJ_Tc < J_Tc_number ; iJ_Tc++)
				for (int iJ_projectile_c = 0 ; iJ_projectile_c < J_projectile_c_number ; iJ_projectile_c++)
				  {
				    const double J_Tc = iJ_Tc + J_Tc_min_local;

				    const double J_projectile_c = iJ_projectile_c + J_projectile_c_min_local;

				    const double Jmin_J_Tc_J_projectile_c = abs (J_Tc - J_projectile_c);		    
				    const double Jmax_J_Tc_J_projectile_c =      J_Tc + J_projectile_c;
					    
				    const double Jmin = max (Jmin_intrinsic_relative , Jmin_J_Tc_J_projectile_c);
				    const double Jmax = min (Jmax_intrinsic_relative , Jmax_J_Tc_J_projectile_c);

				    if ((rint (J - Jmin) >= 0.0) && (rint (J - Jmax) <= 0.0))
				      {	
					const unsigned int iJ_Tc_four_js = make_uns_int (J_Tc - J_Tc_min);
					    
					const unsigned int iJ_projectile_c_four_js = make_uns_int (J_projectile_c - J_projectile_c_min);
					    
					const class correlated_state_str PSI_projectile_qn_c(Z_projectile_c , N_projectile_c , BP_projectile_c , S_projectile_c , J_projectile_c , NADA , NADA , NADA , NADA , NADA , false);
	      
					const class correlated_state_str PSI_qn_Tc(Z_Tc , N_Tc , BP_Tc , S_Tc , J_Tc , NADA , NADA , NADA , NADA , NADA , false);
      
					const double four_js_recoupling_coefficient = four_js_recoupling_table(iJ_intrinsic , LCM_Tc , LCM_projectile_c , iJ_Tc_four_js , iJ_projectile_c_four_js);

					const int reordering_phase_intrinsic_CM_coupling = minus_one_pow (LCM_J_intrinsic_projectile_c_Tc_sum - J_projectile_c - J_Tc);
					
					const double Moshinsky_recoupling_coefficients_phase_product = Moshinsky_three_js_recoupling_coefficients_product*four_js_recoupling_coefficient*reordering_phase_intrinsic_CM_coupling;
					    
					Vstore = A_dagger_cluster_coupled_to_J (true , true , projectile_c , NCM_HO_projectile_c , LCM_projectile_c , PSI_projectile_qn_c , true , Tc , NCM_HO_Tc , LCM_Tc , PSI_qn_Tc , J , M);
			      
					A_dagger_PSI_c_coupled += Moshinsky_recoupling_coefficients_phase_product*Vstore;					    
				      }}}}}}
	  
	  const double J_coupling_precision = J2.J_coupling_precision_calc (A_dagger_PSI_c_coupled , J , Vstore);

	  Vstore = Hcm*A_dagger_PSI_c_coupled;
	    
	  const double Hcm_precision = Vstore.infinite_norm ();
	      
	  const double now = absolute_time_determine () , relative_time = now - reference_time; 

	  if (THIS_PROCESS == MASTER_PROCESS)
	    {
	      if (print_detailed_information || (J_coupling_precision > sqrt_precision) || (Hcm_precision > sqrt_precision))
		{
		  const string space_for_two_body_cluster = (A_projectile_c == 2) ? (" ") : ("");
		      
		  cout << "Relative [A+(" << projectile_c << " " << NCM_HO_relative_c << space_for_two_body_cluster << angular_state_cluster (projectile_c , LCM_relative_projectile_c , J_relative_projectile_c) << ") ";
		      
		  cout << Tc_str << "]^(" << J_Pi_string (BP , J) << ") calculated , J^2 precision : " << J_coupling_precision <<" , HCM precision : " << Hcm_precision << " time:" << relative_time << " s" << endl;

		  if (J_coupling_precision > sqrt_precision) error_message_print_abort ("The composite state is not coupled to J in CC_H_A_dagger_cluster_forbidden_channels_no_core::A_dagger_calculations_and_copy_disk");
		  
		  if (Hcm_precision > sqrt_precision) error_message_print_abort ("The center of mass part of the composite state is not a 0s HO state in CC_H_A_dagger_cluster_forbidden_channels_no_core::A_dagger_calculations_and_copy_disk");
		}
		      
	      const string A_dagger_PSI_c_coupled_file_name = PSI_OUT_coupled_to_J_file_name_A_dagger_cluster_CM_relative_determine (true , "A_dagger_cluster" , projectile_c , NCM_HO_relative_c , LCM_relative_projectile_c ,
																     PSI_relative_projectile_qn_c , PSI_intrinsic_qn_Tc , J , M);
	      A_dagger_PSI_c_coupled.copy_disk (false , false , A_dagger_PSI_c_coupled_file_name);
	    }
	}
    }
      
  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl;
}







void CC_H_A_dagger_cluster_forbidden_channels_no_core::is_it_forbidden_channel_tab_calc (
											 const bool print_detailed_information , 
											 const double CC_forbidden_channel_precision , 	
											 const class array<class CC_channel_class> &channels_tab , 
											 const class array<class cluster_data> &cluster_projectile_data_tab , 
											 const double J , 
											 class GSM_vector &V_in , 
											 class array<bool> &is_it_forbidden_channel_tab)
{	
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Forbidden channels cluster determination (no core)" << endl;
      cout <<         "--------------------------------------------------" << endl << endl;
    }
  
  const class GSM_vector_helper_class &V_helper = V_in.get_GSM_vector_helper ();

  const unsigned int BP = V_helper.get_BP ();

  const unsigned int N_channels = channels_tab.dimension (0);

  const double M =  V_helper.get_M ();

  const unsigned int first_index_out = is_it_forbidden_channel_tab.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_index_out = is_it_forbidden_channel_tab.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const double reference_time = absolute_time_determine ();

  class array<class GSM_vector> V_out_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++) V_out_tab(i_thread).allocate_fill (V_in);

  is_it_forbidden_channel_tab = false;
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const complex<double> E_intrinsic_Tc = channel_c.get_E_Tc ();

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const int Z_Tc = channel_c.get_Z_Tc ();
      const int N_Tc = channel_c.get_N_Tc ();
      
      const int S_Tc = channel_c.get_S_Tc ();
      
      const unsigned int BP_intrinsic_Tc = channel_c.get_BP_Tc ();

      const unsigned int vector_index_intrinsic_Tc = channel_c.get_vector_index_Tc ();

      const double J_relative_projectile_c = channel_c.get_J_projectile ();

      const double J_intrinsic_Tc = channel_c.get_J_Tc ();

      const int Z_projectile_c = channel_c.get_Z_projectile ();
      const int N_projectile_c = channel_c.get_N_projectile ();
      const int A_projectile_c = channel_c.get_A_projectile ();
      
      const int S_projectile_c = channel_c.get_S_projectile ();
      
      const int LCM_relative_projectile_c = channel_c.get_LCM_projectile ();
            
      const unsigned int BP_relative_projectile_c = channel_c.get_BP_projectile ();

      const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);

      const class lj_table<int> &NCM_HO_max_relative_cluster_projectile_CM_tab_c = data_c.get_Nmax_cluster_projectile_CM_tab ();	

      const int NCM_HO_max_relative_cluster_LCM_J_projectile_c = NCM_HO_max_relative_cluster_projectile_CM_tab_c(LCM_relative_projectile_c , J_relative_projectile_c);

      const string Tc_str = "Target[c] : Z:" + make_string<int> (Z_Tc) + " N:" + make_string<int> (N_Tc) + " " + J_Pi_vector_index_string (BP_intrinsic_Tc , J_intrinsic_Tc , vector_index_intrinsic_Tc);

      if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl << "ic : " << ic << " channel[rel] : " << channel_c << " NCM-HO[max] : " << NCM_HO_max_relative_cluster_LCM_J_projectile_c << endl << endl;

      const class correlated_state_str PSI_relative_projectile_qn_c(Z_projectile_c , N_projectile_c , BP_relative_projectile_c , S_projectile_c , J_relative_projectile_c , NADA , NADA , NADA , NADA , NADA , false);
	      
      const class correlated_state_str PSI_intrinsic_qn_Tc(Z_Tc , N_Tc , BP_intrinsic_Tc , S_Tc , J_intrinsic_Tc , vector_index_intrinsic_Tc , E_intrinsic_Tc , NADA , NADA , NADA , false);

      for (int NCM_HO_relative_c = 0 ; NCM_HO_relative_c <= NCM_HO_max_relative_cluster_LCM_J_projectile_c ; NCM_HO_relative_c++) 
	{	
	  if (!is_it_forbidden_channel_tab(ic , NCM_HO_relative_c))
	    {
	      const string A_dagger_PSI_c_coupled_file_name = PSI_OUT_coupled_to_J_file_name_A_dagger_cluster_CM_relative_determine (true , "A_dagger_cluster" , projectile_c , NCM_HO_relative_c , LCM_relative_projectile_c ,
																     PSI_relative_projectile_qn_c , PSI_intrinsic_qn_Tc , J , M);

	      V_in.read_disk (false , false , A_dagger_PSI_c_coupled_file_name);

	      bool is_it_forbidden_channel_partial = false;

	      const complex<double> V_in_norm = sqrt (V_in*V_in);

	      if (inf_norm (V_in_norm) < CC_forbidden_channel_precision) is_it_forbidden_channel_partial = true;
	      for (unsigned int icp = 0 ; (!is_it_forbidden_channel_partial) && (icp <= ic) ; icp++)
		{
		  const class CC_channel_class &channel_cp = channels_tab(icp);

		  const complex<double> E_intrinsic_Tcp = channel_cp.get_E_Tc ();

		  const enum particle_type projectile_cp = channel_cp.get_projectile ();
      
		  const int Z_Tcp = channel_cp.get_Z_Tc ();
		  const int N_Tcp = channel_cp.get_N_Tc ();
      
		  const int S_Tcp = channel_cp.get_S_Tc ();
		  
		  const unsigned int BP_intrinsic_Tcp = channel_cp.get_BP_Tc ();

		  const unsigned int vector_index_intrinsic_Tcp = channel_cp.get_vector_index_Tc ();

		  const double J_relative_projectile_cp = channel_cp.get_J_projectile ();

		  const double J_intrinsic_Tcp = channel_cp.get_J_Tc ();

		  const int Z_projectile_cp = channel_cp.get_Z_projectile ();
		  const int N_projectile_cp = channel_cp.get_N_projectile ();
		      
		  const int S_projectile_cp = channel_cp.get_S_projectile ();
		  
		  const int LCM_relative_projectile_cp = channel_cp.get_LCM_projectile ();
            
		  const unsigned int BP_relative_projectile_cp = channel_cp.get_BP_projectile ();

		  const class cluster_data &data_cp = get_cluster_projectile_data (projectile_cp , cluster_projectile_data_tab);

		  const class lj_table<int> &NCM_HO_max_relative_cluster_projectile_CM_tab_cp = data_cp.get_Nmax_cluster_projectile_CM_tab ();	

		  const int NCM_HO_max_relative_cluster_LCM_J_projectile_cp = NCM_HO_max_relative_cluster_projectile_CM_tab_cp(LCM_relative_projectile_cp , J_relative_projectile_cp);

		  const int NCM_HO_max_relative_cluster_LCM_J_projectile_cp_NCM_HO_relative_c = (icp < ic) ? (NCM_HO_max_relative_cluster_LCM_J_projectile_cp) : (NCM_HO_relative_c - 1);
		  
		  const class correlated_state_str PSI_relative_projectile_qn_cp(Z_projectile_cp , N_projectile_cp , BP_relative_projectile_cp , S_projectile_cp , J_relative_projectile_cp , NADA , NADA , NADA , NADA , NADA , false);
	      
		  const class correlated_state_str PSI_intrinsic_qn_Tcp(Z_Tcp , N_Tcp , BP_intrinsic_Tcp , S_Tcp , J_intrinsic_Tcp , vector_index_intrinsic_Tcp , E_intrinsic_Tcp , NADA , NADA , NADA , false);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) reduction(||:is_it_forbidden_channel_partial)
#endif
		  for (int NCM_HO_relative_cp = 0 ; NCM_HO_relative_cp <= NCM_HO_max_relative_cluster_LCM_J_projectile_cp_NCM_HO_relative_c ; NCM_HO_relative_cp++) 
		    {
		      if (!is_it_forbidden_channel_partial && !is_it_forbidden_channel_tab(icp , NCM_HO_relative_cp))
			{	
			  const unsigned int index_out = is_it_forbidden_channel_tab.index_determine (icp , NCM_HO_relative_cp);

			  if ((index_out >= first_index_out) && (index_out <= last_index_out))
			    {
			      const unsigned int this_thread = OpenMP_thread_number_determine ();

			      const string A_dagger_PSI_cp_coupled_file_name = PSI_OUT_coupled_to_J_file_name_A_dagger_cluster_CM_relative_determine (true , "A_dagger_cluster" , projectile_cp , NCM_HO_relative_cp , LCM_relative_projectile_cp ,
																		      PSI_relative_projectile_qn_cp , PSI_intrinsic_qn_Tcp , J , M);

			      class GSM_vector &V_out = V_out_tab(this_thread);
			      
			      V_out.read_disk (false , false , A_dagger_PSI_cp_coupled_file_name);

			      const complex<double> overlap = V_in*V_out;

			      if (inf_norm (overlap - 1.0) < CC_forbidden_channel_precision) is_it_forbidden_channel_partial = true;
			    }
			}
		    }
		}

	      const bool is_it_forbidden_channel = or_Allreduce (is_it_MPI_parallelized , is_it_forbidden_channel_partial);

	      is_it_forbidden_channel_tab(ic , NCM_HO_relative_c) = is_it_forbidden_channel;
	    }

	  if ((THIS_PROCESS == MASTER_PROCESS) && is_it_forbidden_channel_tab(ic , NCM_HO_relative_c))
	    {	
	      const string space_for_two_body_cluster = (A_projectile_c == 2) ? (" ") : ("");

	      cout << endl << "[(" << projectile_c << " " << NCM_HO_relative_c << space_for_two_body_cluster << angular_state_cluster (projectile_c , LCM_relative_projectile_c , J_relative_projectile_c) << ") ";

	      cout << Tc_str << "]^(" << J_Pi_string (BP , J) << ") forbidden" << endl << endl;
	    }
	}
    }

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      const string is_it_forbidden_channel_tab_file_name = file_name_J_Pi_string ("CC_is_it_forbidden_channel_tab" , BP , J);
      
      is_it_forbidden_channel_tab.copy_disk (is_it_forbidden_channel_tab_file_name);

      if (print_detailed_information)
	{
	  const double now = absolute_time_determine () , relative_time = now - reference_time; 

	  cout << endl << "forbidden_channel channels cluster (no core) time:" << relative_time << " s" << endl << endl;
	}
    }
}












void CC_H_A_dagger_cluster_forbidden_channels_no_core::H_A_dagger_calculations_and_copy_disk (
											      const bool print_detailed_information , 
											      const class array<class CC_channel_class> &channels_tab , 
											      const class array<class cluster_data> &cluster_projectile_data_tab , 
											      const class array<bool> &is_it_forbidden_channel_tab , 
											      const double J , 
											      const class J2_class &J2 , 
											      const class CM_operator_class &Hcm ,
											      const class H_class &H , 
											      class GSM_vector &A_dagger_PSI_c_coupled , 
											      class GSM_vector &H_A_dagger_PSI_c_coupled) 
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Relative H[A+(projectile) |target>] cluster calculation (no core)" << endl;
      cout         << "-----------------------------------------------------------------" << endl << endl;
    }
  
  const class GSM_vector_helper_class &GSM_vector_helper = A_dagger_PSI_c_coupled.get_GSM_vector_helper ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const unsigned int N_channels = channels_tab.dimension (0);

  const double M = GSM_vector_helper.get_M ();
    for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const complex<double> E_intrinsic_Tc = channel_c.get_E_Tc ();

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const int Z_Tc = channel_c.get_Z_Tc ();
      const int N_Tc = channel_c.get_N_Tc ();
      
      const int S_Tc = channel_c.get_S_Tc ();
      
      const unsigned int BP_intrinsic_Tc = channel_c.get_BP_Tc ();

      const unsigned int vector_index_intrinsic_Tc = channel_c.get_vector_index_Tc ();

      const double J_relative_projectile_c = channel_c.get_J_projectile ();

      const double J_intrinsic_Tc = channel_c.get_J_Tc ();

      const int Z_projectile_c = channel_c.get_Z_projectile ();
      const int N_projectile_c = channel_c.get_N_projectile ();
      const int A_projectile_c = channel_c.get_A_projectile ();
      
      const int S_projectile_c = channel_c.get_S_projectile ();
      
      const int LCM_relative_projectile_c = channel_c.get_LCM_projectile ();
      
      const unsigned int BP_relative_projectile_c = channel_c.get_BP_projectile ();

      const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);

      const class lj_table<int> &NCM_HO_max_relative_cluster_projectile_CM_tab_c = data_c.get_Nmax_cluster_projectile_CM_tab ();	

      const int NCM_HO_max_relative_cluster_LCM_J_projectile_c = NCM_HO_max_relative_cluster_projectile_CM_tab_c(LCM_relative_projectile_c , J_relative_projectile_c);

      const string Tc_str = "Target[c] : Z:" + make_string<int> (Z_Tc) + " N:" + make_string<int> (N_Tc) + " " + J_Pi_vector_index_string (BP_intrinsic_Tc , J_intrinsic_Tc , vector_index_intrinsic_Tc);

      if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl << "ic : " << ic << " channel[rel] : " << channel_c << " NCM-HO[max] : " << NCM_HO_max_relative_cluster_LCM_J_projectile_c << endl << endl;

      const class correlated_state_str PSI_relative_projectile_qn_c(Z_projectile_c , N_projectile_c , BP_relative_projectile_c , S_projectile_c , J_relative_projectile_c , NADA , NADA , NADA , NADA , NADA , false);
	      
      const class correlated_state_str PSI_intrinsic_qn_Tc(Z_Tc , N_Tc , BP_intrinsic_Tc , S_Tc , J_intrinsic_Tc , vector_index_intrinsic_Tc , E_intrinsic_Tc , NADA , NADA , NADA , false);
      
      for (int NCM_HO_relative_c = 0 ; NCM_HO_relative_c <= NCM_HO_max_relative_cluster_LCM_J_projectile_c ; NCM_HO_relative_c++) 
	{	
	  if (!is_it_forbidden_channel_tab(ic , NCM_HO_relative_c))
	    {	
	      const double reference_time = absolute_time_determine ();

	      const string A_dagger_PSI_c_coupled_file_name = PSI_OUT_coupled_to_J_file_name_A_dagger_cluster_CM_relative_determine (true , "A_dagger_cluster" , projectile_c , NCM_HO_relative_c , LCM_relative_projectile_c ,
																     PSI_relative_projectile_qn_c , PSI_intrinsic_qn_Tc , J , M);
	      
	      A_dagger_PSI_c_coupled.read_disk (false , false , A_dagger_PSI_c_coupled_file_name);

	      H_A_dagger_PSI_c_coupled = H*A_dagger_PSI_c_coupled;

	      class GSM_vector &Vstore = A_dagger_PSI_c_coupled;

	      const double J_coupling_precision = J2.J_coupling_precision_calc (H_A_dagger_PSI_c_coupled , J , Vstore);

	      Vstore = Hcm*H_A_dagger_PSI_c_coupled;
	    
	      const double Hcm_precision = Vstore.infinite_norm ();
	  
	      const double now = absolute_time_determine () , relative_time = now - reference_time; 

	      if (THIS_PROCESS == MASTER_PROCESS) 
		{
		  if (print_detailed_information || (J_coupling_precision > sqrt_precision) || (Hcm_precision > sqrt_precision))
		    {
		      const string space_for_two_body_cluster = (A_projectile_c == 2) ? (" ") : ("");

		      cout << "Relative H[A+(" << projectile_c << " " << NCM_HO_relative_c << space_for_two_body_cluster << angular_state_cluster (projectile_c , LCM_relative_projectile_c , J_relative_projectile_c) << ") ";

		      cout << Tc_str << "]^(" << J_Pi_string (BP , J) << ") calculated , J^2 precision : " << J_coupling_precision << " , time:" << relative_time << " s" << endl;
		      
		      if (J_coupling_precision > sqrt_precision) error_message_print_abort ("The composite state is not coupled to J in CC_H_A_dagger_cluster_forbidden_channels_no_core::H_A_dagger_calculations_and_copy_disk");
		  
		      if (Hcm_precision > sqrt_precision) error_message_print_abort ("The center of mass part of the composite state is not a 0s HO state in CC_H_A_dagger_cluster_forbidden_channels_no_core::H_A_dagger_calculations_and_copy_disk");
		    }
		    
		  const string H_A_dagger_PSI_c_coupled_file_name = PSI_OUT_coupled_to_J_file_name_A_dagger_cluster_CM_relative_determine (true , "H_A_dagger_cluster" , projectile_c , NCM_HO_relative_c , LCM_relative_projectile_c ,
																	   PSI_relative_projectile_qn_c , PSI_intrinsic_qn_Tc , J , M);

		  H_A_dagger_PSI_c_coupled.copy_disk (false , false , H_A_dagger_PSI_c_coupled_file_name);
		}
	    }
	}	  
    }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl;
}






