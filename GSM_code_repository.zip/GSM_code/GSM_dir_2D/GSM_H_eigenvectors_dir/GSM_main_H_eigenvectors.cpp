#include "../GSM_include/GSM_include_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

enum called_code_type called_code = H_EIGENVECTORS_CODE;

using namespace inputs_misc;
using namespace GSM_vector_dimensions;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    print_array_vector_test_status<int> ();

    //--// dummy variables

    class array<double> dummy_array_double;

    class array<string> dummy_array_string;

    class array<class input_data_str> dummy_input_data_tab;

    class input_data_str dummy_input_data;
    
    const class array <class array<class JT_coupled_TBME> > dummy_array_JT_coupled_TBME;

    //================================== input data and nucleons data ==================================//
    
    //--// initialization of the class which contains all input values and some pointers on tables (not all initialized here)

    class input_data_str input_data;

    call_common_routines::input_data_read_MPI_transfer (dummy_array_double , dummy_array_double , dummy_array_string , input_data , dummy_input_data , dummy_input_data_tab);

    if (THIS_PROCESS == MASTER_PROCESS) MPI_2D_partitioning::print_active_processes_numbers ();
    
    //--// initialization of the classes which contain information on protons and neutrons

    class baryons_data prot_Y_data;
    class baryons_data neut_Y_data;

    baryons_data_initialization (true , input_data , prot_Y_data , neut_Y_data);
    
    const enum space_type space = input_data.get_space ();
    
    //================================== Berggren one-body basis and space truncation  ==================================//

    radial_wfs_HF_data_HO_overlaps_basis_pn_alloc_read_disk (input_data , prot_Y_data , neut_Y_data);
    
    space_truncation_data_best_hbar_omega_calc (true , input_data , prot_Y_data , neut_Y_data);
	
    //================================== OBMEs, TBMEs ==================================//

    all_OBMEs_inter_HO_GHF_overlaps_alloc_read_disk (input_data , prot_Y_data , neut_Y_data);
    
    all_OBMEs_CM_reduced_r_grad_sets_alloc_read_disk (space , prot_Y_data , neut_Y_data);

    //--// initialization of the class which contains pn TBMEs and pp <-> nn conversion TBMEs (hypernuclei only)
 
    class TBMEs_class TBMEs_pn;
    class TBMEs_class TBMEs_cv;

    TBMEs_pp_nn_pn_alloc_read_disk (true , false , input_data , prot_Y_data , neut_Y_data , TBMEs_pn , TBMEs_cv);

    //================================== configurations, SDs  ==================================//
    
    configuration_SD_sets::configuration_SD_tables_pp_nn_alloc_calc (true , false , true , input_data , prot_Y_data , neut_Y_data);
    
    //================================== GSM space dimensions ==================================//
    
    const int n_scat_max = input_data.get_n_scat_max ();

    const int n_scat_max_plus_one = n_scat_max + 1;

    const unsigned int J_index_max = J_index_max_calc (space , prot_Y_data , neut_Y_data);

    const unsigned int J_index_max_plus_one = J_index_max + 1;
    
    //--// initialization of the tables containing the GSM space dimensions at pole approximation and in full space

    class array<unsigned long int> total_space_dimensions_good_J_pole_approximation(2 , 1 , J_index_max_plus_one);

    class array<unsigned long int> total_space_dimensions_good_J(2 , n_scat_max_plus_one , J_index_max_plus_one);

    all_J_total_space_dimensions_calc_print (true , input_data , prot_Y_data , neut_Y_data , total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J);
 
    const bool only_dimensions = input_data.get_only_dimensions ();
    
    if (only_dimensions)
      {
#ifdef UseMPI
	MPI_helper::Finalize ();
#endif
	return 0;
      }
    
    //================================== Calculation of eigenvectors and energies: pole approximation with Lanczos, full space with Lanczos or Davidson. ==================================//
    
    //--// initialization of the table of classes containing GSM eigenstates quantum numbers (qn)

    const unsigned int eigensets_number = input_data.get_eigensets_number ();

    const unsigned int vectors_to_find_number_max = vectors_to_find_number_max_determine (input_data , total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J);    
    
    //--// initialization of the table of classes containing GSM eigenstates quantum numbers (qn)

    class array<class correlated_state_str> PSI_qn_tab(eigensets_number , vectors_to_find_number_max);

    input_data.PSI_quantum_numbers_tab_partial_fill (total_space_dimensions_good_J , PSI_qn_tab);

    //--// Calculations of GSM eigenvalues and eigenvectors at pole approximation and full space level

    eigenvector_functions::eigenvectors_pole_approximation_full_space_calc (true , false , input_data , total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J , TBMEs_pn , TBMEs_cv , prot_Y_data , neut_Y_data , PSI_qn_tab);

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
    
    return 0;
  }


