#ifndef SD2PHCONSTRUCTIONSET_H
#define SD2PHCONSTRUCTIONSET_H


// TYPE is double or complex
// -------------------------

namespace SD_2ph_construction_set
{
  namespace out_to_inter
  {
    void SD_2h_data_fill (
			  const enum operation_type operation , 
			  const unsigned int occupied_squares_index , 
			  const unsigned long int dimensions_SD_2h_table_index , 
			  const unsigned long int SD_2h_table_zero_index , 
			  const unsigned int dimension_SD_inter_2h ,
			  const unsigned long int SD_set_2h_zero_SD_inter_index ,
			  const int im_left_2h , 
			  const int im_right_2h , 
			  const unsigned int bin_phase ,
			  const unsigned int C_2h_table_index , 
			  const class Slater_determinant &SD_inter , 
			  class Slater_determinant &SD_try , 
			  class baryons_data &particles_data);

    void SD_2h_table_all_SDs_inter (
				    const enum operation_type operation , 
				    const unsigned int occupied_squares_index , 
				    const class Slater_determinant &outSD ,
				    const unsigned long int dimensions_SD_2h_table_index , 
				    const unsigned long int SD_2h_table_zero_index , 
				    const unsigned int C_2h_table_index ,
				    const unsigned int dimension_SD_inter_2h ,
				    const unsigned long int SD_set_2h_zero_SD_inter_index ,
				    const int iM_pair_2h ,
				    const unsigned int shell_left_index_2h ,
				    const unsigned int shell_right_index_2h , 
				    class Slater_determinant &SD_inter ,
				    class Slater_determinant &SD_try ,   
				    class baryons_data &particles_data);

    void all_SDs_2h_all_SDs (
			     const enum operation_type operation , 
			     const unsigned int occupied_squares_index , 
			     const bool is_it_pole_approximation , 
			     class baryons_data &particles_data);
  }
  
  namespace inter_to_in
  {
    void SD_2p_data_fill (
			  const enum operation_type operation ,
			  const unsigned int occupied_squares_index , 
			  const unsigned int inSD_index ,
			  const int im_left_2p , 
			  const int im_right_2p , 
			  const unsigned int bin_phase ,
			  const unsigned int C_2p_table_index ,
			  const unsigned long int SD_2p_table_zero_index ,
			  const unsigned long int dimensions_SD_2p_table_index ,
			  class baryons_data &particles_data);

    void SD_2p_table_all_SDs_inter (
				    const enum operation_type operation ,
				    const unsigned int occupied_squares_index , 
				    const unsigned int C_2p_table_index ,
				    const unsigned int dimension_inSD , 
				    const unsigned long int SD_set_zero_SD_index ,
				    const unsigned long int SD_2p_table_zero_index ,
				    const unsigned long int is_inSD_in_space_zero_index , 
				    const unsigned long int dimensions_SD_2p_table_index ,
				    const int iM_pair_2p , 
				    const unsigned int shell_left_index_2p ,
				    const unsigned int shell_right_index_2p ,
				    const class Slater_determinant &SD_inter ,
				    class Slater_determinant &inSD ,
				    class Slater_determinant &SD_try ,   
				    class baryons_data &particles_data);

    void all_SDs_2p_all_SDs (
			     const enum operation_type operation , 
			     const unsigned int occupied_squares_index , 
			     const bool is_it_pole_approximation , 
			     class baryons_data &particles_data);
  }
  
  void all_SDs_2ph_all_SDs_alloc_calc (
				       const bool is_there_cout , 
				       const bool is_it_pole_approximation , 
				       const unsigned int occupied_squares_index , 
				       class baryons_data &particles_data);
}

#endif


