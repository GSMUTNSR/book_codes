#ifndef GSMHAMILTONIANPARTS_H
#define GSMHAMILTONIANPARTS_H

// TYPE is double or complex
// -------------------------

namespace Hamiltonian_parts
{
  void kinetic_one_body_calc_print (
				    const class input_data_str &input_data , 
				    const class interaction_class &inter_data ,
				    const double J ,
				    const class GSM_vector &PSI ,
				    class GSM_vector_helper_class &GSM_vector_helper_2D_occupied ,
				    class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied , 
				    class GSM_vector &PSI0_2D ,
				    class GSM_vector &PSI1_2D ,
				    class GSM_vector &PSI2_2D ,
				    class GSM_vector &PSI3_2D ,
				    class array<class GSM_vector> &H_PSI_table);

  void kinetic_recoil_calc_print (
				  const class input_data_str &input_data , 
				  const class interaction_class &inter_data ,
				  const double J , 
				  const class GSM_vector &PSI ,
				  class GSM_vector_helper_class &GSM_vector_helper_2D_occupied ,
				  class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied , 
				  class GSM_vector &PSI0_2D ,
				  class GSM_vector &PSI1_2D ,
				  class GSM_vector &PSI2_2D ,
				  class GSM_vector &PSI3_2D ,
				  class array<class GSM_vector> &H_PSI_table ,
				  class TBMEs_class &TBMEs_pn);

  void nuclear_one_body_calc_print (
				    const class input_data_str &input_data , 
				    const class interaction_class &inter_data ,
				    const double J ,
				    const class GSM_vector &PSI ,
				    class GSM_vector_helper_class &GSM_vector_helper_2D_occupied ,
				    class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied , 
				    class GSM_vector &PSI0_2D ,
				    class GSM_vector &PSI1_2D ,
				    class GSM_vector &PSI2_2D ,
				    class GSM_vector &PSI3_2D ,
				    class array<class GSM_vector> &H_PSI_table);

  void nuclear_two_body_calc_print (
				    const class input_data_str &input_data , 
				    const int Jn_rel_max , 
				    const double J ,
				    const class GSM_vector &PSI ,
				    class interaction_class &inter_data , 
				    class GSM_vector_helper_class &GSM_vector_helper_2D_occupied ,
				    class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied , 
				    class GSM_vector &PSI0_2D ,
				    class GSM_vector &PSI1_2D ,
				    class GSM_vector &PSI2_2D ,
				    class GSM_vector &PSI3_2D ,
				    class array<class GSM_vector> &H_PSI_table ,
				    class TBMEs_class &TBMEs_pn ,
				    class TBMEs_class &TBMEs_cv);

  void nuclear_three_body_calc_print (
				      const class input_data_str &input_data ,
				      const double J , 
				      const class GSM_vector &PSI ,
				      class GSM_vector_helper_class &GSM_vector_helper_2D_occupied ,
				      class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied , 
				      class GSM_vector &PSI0_2D ,
				      class GSM_vector &PSI1_2D ,
				      class GSM_vector &PSI2_2D ,
				      class GSM_vector &PSI3_2D ,
				      class array<class GSM_vector> &H_PSI_table ,
				      class interaction_class &inter_data , 
				      class TBMEs_class &TBMEs_pn);

  void Coulomb_one_body_calc_print (
				    const class input_data_str &input_data , 
				    const class interaction_class &inter_data ,
				    const double J ,
				    const class GSM_vector &PSI ,
				    class GSM_vector_helper_class &GSM_vector_helper_2D_occupied ,
				    class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied , 
				    class GSM_vector &PSI0_2D ,
				    class GSM_vector &PSI1_2D ,
				    class GSM_vector &PSI2_2D ,
				    class GSM_vector &PSI3_2D ,
				    class array<class GSM_vector> &H_PSI_table);

  void Coulomb_two_body_calc_print (
				    const class input_data_str &input_data , 
				    const int Jc_rel_max , 
				    const double J , 
				    const class GSM_vector &PSI ,
				    class interaction_class &inter_data ,
				    class GSM_vector_helper_class &GSM_vector_helper_2D_occupied ,
				    class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied ,  
				    class GSM_vector &PSI0_2D ,
				    class GSM_vector &PSI1_2D ,
				    class GSM_vector &PSI2_2D ,
				    class GSM_vector &PSI3_2D ,
				    class array<class GSM_vector> &H_PSI_table);

  void GSM_SMEC_energies_print (
				const class input_data_str &input_data , 
				const double J , 
				class TBMEs_class &TBMEs_pn , 
				class TBMEs_class &TBMEs_cv , 
				const class GSM_vector &PSI ,
				class GSM_vector_helper_class &GSM_vector_helper_hybrid_1D_2D ,
				class GSM_vector_helper_class &GSM_vector_helper_2D_occupied ,
				class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied , 
				class GSM_vector &PSI0_2D ,
				class GSM_vector &PSI1_2D ,
				class GSM_vector &PSI2_2D ,
				class GSM_vector &PSI3_2D ,
				class array<class GSM_vector> &H_PSI_table);
 
  void calc_print (
		   const class input_data_str &input_data , 
		   const class array<class correlated_state_str> &PSI_qn_tab , 
		   class interaction_class &inter_data , 
		   class baryons_data &prot_Y_data , 
		   class baryons_data &neut_Y_data , 
		   class TBMEs_class &TBMEs_pn ,
		   class TBMEs_class &TBMEs_cv);
}

#endif
