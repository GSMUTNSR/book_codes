#ifndef GSMCONFIGURATION1PHCONSTRUCTIONSET_H
#define GSMCONFIGURATION1PHCONSTRUCTIONSET_H

// TYPE is double or complex
// -------------------------

namespace configuration_1ph_construction_set
{
  namespace out_to_inter
  {
    void configuration_1h_data_fill (
				     const enum operation_type operation , 
				     const unsigned int occupied_squares_index , 
				     const int n_scat_inter ,
				     const unsigned int iC_inter ,  
				     const unsigned int shell_1h_index , 
				     const unsigned int configuration_1h_table_zero_index , 
				     const unsigned int dimensions_configuration_1h_table_index ,
				     class baryons_data &particles_data);

    void configuration_1h_all_C_inter (
				       const enum operation_type operation , 
				       const unsigned int occupied_squares_index ,  
				       const int n_scat_out , 
				       const class configuration &C_out , 
				       const unsigned int configuration_1h_table_zero_index , 
				       const unsigned int dimensions_configuration_1h_table_index ,
				       const unsigned int BP_inter , 
				       const int S_inter , 
				       const int n_spec_inter , 
				       const unsigned int BP_1h , 
				       const int S_1h , 
				       const int n_spec_1h , 
				       class configuration &C_inter , 	
				       class configuration &C_try , 	
				       class baryons_data &particles_data);

    void all_configurations_1h_all_configurations (
						   const enum operation_type operation ,
						   const bool is_it_pole_approximation ,
						   const unsigned int occupied_squares_index ,  
						   class baryons_data &particles_data);   
  }

  namespace inter_to_in
  {
    void configuration_1p_data_fill (
				     const enum operation_type operation , 
				     const unsigned int occupied_squares_index , 
				     const unsigned int BP_in , 
				     const int S_in , 
				     const int n_spec_in , 
				     const int n_scat_in , 
				     const unsigned int iC_in ,
				     const unsigned int BP_inter , 
				     const int S_inter , 
				     const int n_spec_inter , 
				     const int n_scat_inter ,
				     const unsigned int iC_inter ,  
				     const unsigned int shell_1p_index , 
				     class baryons_data &particles_data);

    void configuration_1p_all_C_inter (
				       const enum operation_type operation ,
				       const unsigned int occupied_squares_index ,  
				       const unsigned int BP_in ,  
				       const int S_in , 
				       const int n_spec_in , 
				       const int n_scat_in , 
				       const unsigned int iC_in ,
				       const class configuration &C_in ,  
				       const unsigned int BP_inter , 
				       const int S_inter , 
				       const int n_spec_inter , 
				       const unsigned int BP_1p , 
				       const int S_1p , 
				       const int n_spec_1p , 
				       class configuration &C_inter , 	
				       class configuration &C_try , 	
				       class baryons_data &particles_data);

    void all_configurations_1p_all_configurations (
						   const enum operation_type operation ,
						   const bool is_it_pole_approximation ,
						   const unsigned int occupied_squares_index ,  
						   class baryons_data &particles_data);
  }

  void is_configuration_inter_occupied_in_in_out_spaces_1ph_determine (
								       const bool truncation_hw ,
								       const bool truncation_ph ,
								       const bool is_it_pole_approximation , 
								       const unsigned int occupied_squares_index ,
								       const unsigned int BP_inter ,
								       const int S_inter , 
								       const int n_spec_inter , 
								       const unsigned int n_holes_inter ,
								       const unsigned int n_scat_inter ,
								       const unsigned int iC_inter ,
								       const int E_hw_inter , 
								       const class configuration &C_inter , 
								       class configuration &C ,
								       class configuration &C_try ,
								       class baryons_data &particles_data);
  
  void are_configurations_inter_occupied_in_space_1ph_table_calc  ( 
								   const bool truncation_hw ,
								   const bool truncation_ph ,
								   const bool is_it_pole_approximation , 
								   const unsigned int occupied_squares_index ,
								   class baryons_data &particles_data);
 
  void all_configurations_1ph_all_configurations_alloc_calc (
							     const bool is_there_cout , 
							     const bool is_it_pole_approximation ,
							     const unsigned int occupied_squares_index ,
							     const bool truncation_hw ,
							     const bool truncation_ph , 
							     class baryons_data &particles_data);
}

#endif



