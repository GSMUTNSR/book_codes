#ifndef GSMOVERLAPFUNCTION_H
#define GSMOVERLAPFUNCTION_H

// TYPE is double or complex
// -------------------------

namespace overlap_function
{

  namespace one_baryon
  {
    void stripping_calc (
			 const bool full_common_vectors_used_in_file ,
			 const class ljm_struct &ljm , 
			 const bool is_it_GL ,
			 const class correlated_state_str &PSI_IN_qn , 
			 const class correlated_state_str &PSI_OUT_qn , 
			 const class GSM_vector &PSI_OUT , 
			 class array<TYPE> &overlap_function_tab);

    void pick_up_calc (
		       const bool full_common_vectors_used_in_file ,
		       const class ljm_struct &ljm ,
		       const bool is_it_GL , 
		       const class correlated_state_str &PSI_IN_qn , 
		       const class correlated_state_str &PSI_OUT_qn , 
		       const class GSM_vector &PSI_OUT , 
		       class array<TYPE> &overlap_function_tab);
  }
  
  namespace cluster
  {
    void stripping_calc (
			 const bool full_common_vectors_used_in_file ,
			 const double b_HO , 
			 const int NCM_HO_max_proj , 
			 const class ljm_struct &LJM_cluster ,
			 const bool is_it_GL , 
			 const class correlated_state_str &PSI_IN_qn , 
			 const class correlated_state_str &PSI_OUT_qn , 
			 const class correlated_state_str &PSI_projectile_qn , 
			 const class GSM_vector &PSI_OUT , 
			 const class array<double> &r_tab , 
			 class array<TYPE> &overlap_function_tab);
	
    void pick_up_calc (
		       const bool full_common_vectors_used_in_file ,
		       const double b_HO , 
		       const int NCM_HO_max_proj , 
		       const class ljm_struct &LJM_cluster , 
		       const bool is_it_GL ,
		       const class correlated_state_str &PSI_IN_qn , 
		       const class correlated_state_str &PSI_OUT_qn , 
		       const class correlated_state_str &PSI_projectile_qn , 
		       const class GSM_vector &PSI_OUT , 
		       const class array<double> &r_tab , 
		       class array<TYPE> &overlap_function_tab);
  }
  
  void calc (
	     const bool full_common_vectors_used_in_file ,
	     const enum spectroscopic_factor_type SF , 
	     const enum nucleus_type nucleus , 
	     const double b_HO , 
	     const int NCM_HO_max_projectile , 
	     const class ljm_struct &LJM_projectile , 
	     const bool is_it_GL ,
	     const class correlated_state_str &PSI_IN_qn , 
	     const class correlated_state_str &PSI_OUT_qn , 
	     const class correlated_state_str &PSI_projectile_qn , 
	     const class GSM_vector &PSI_OUT , 
	     const class array<double> &r_tab , 
	     class array<TYPE> &overlap_function_tab);

  void calc_store (
		   const class input_data_str &input_data , 
		   const class array<class correlated_state_str> &PSI_qn_tab ,
		   class baryons_data &prot_Y_data , 
		   class baryons_data &neut_Y_data); 
}

#endif


