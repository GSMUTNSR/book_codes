#ifndef GSMOBSERVABLES_H
#define GSMOBSERVABLES_H

// TYPE is double or complex
// -------------------------

namespace GSM_observables
{ 
  void HO_calculation (
		       const class input_data_str &input_data ,
		       const class array<class correlated_state_str> &PSI_qn_tab ,
		       class interaction_class &inter_data ,
		       class baryons_data &prot_Y_data ,
		       class baryons_data &neut_Y_data);

  void calculation (
		    const class input_data_str &input_data ,
		    const class array<class correlated_state_str> &PSI_qn_tab ,
		    class interaction_class &inter_data ,
		    class TBMEs_class &TBMEs_pn ,  
		    class TBMEs_class &TBMEs_cv ,  
		    class baryons_data &prot_Y_data ,
		    class baryons_data &neut_Y_data);
}
#endif

