#ifndef GSMSCALARDENSITYMATRIX_H
#define GSMSCALARDENSITYMATRIX_H

// TYPE is double or complex
// -------------------------

namespace scalar_density_matrix
{
  void diagonal_parts_pp_nn_fixed_configuration_calc (
						      const class baryons_data &data , 
						      const class configuration &C ,
						      class array<class nlj_table<int> > &diagonal_parts_fixed_iC_tab);

  void components_parts_one_jump_mu_calc (
					  const class baryons_data &data , 
					  const class jumps_data_out_to_in_str &one_jump_mu , 
					  const class array<bool> &are_PSI_IN_indices_accepted_tab , 
					  const class array<unsigned int> &PSI_IN_indices_one_jump_mu ,
					  const class GSM_vector &PSI_IN_2D ,
					  class array<class lj_table<TYPE> > &components_parts_one_jump_mu_tab);

  void diagonal_parts_calc (
			    const class array<class nlj_table<int> > &diagonal_parts_fixed_iC_tab ,
			    const TYPE &PSI_out_component ,
			    const TYPE &PSI_out_component_TRS_factor ,
			    class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_fixed_iC_tab);
  
  void one_jump_mu_part_calc (
			      const class array<class lj_table<TYPE> > &components_parts_one_jump_mu_tab ,
			      const TYPE &PSI_out_component_TRS_factor ,
			      class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_fixed_iC_tab);
  
  void pp_nn_diagonal_parts_calc (
				  const class GSM_vector &PSI ,
				  class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_tab);

  void pp_nn_one_jump_parts_calc (
				  const unsigned int occupied_squares_index , 
				  const class GSM_vector &PSI_IN_2D ,
				  const class GSM_vector &PSI_OUT_2D ,
				  class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_tab);
 
  void diagonal_parts_pn_p_part_calc (
				      const class GSM_vector &PSI ,
				      class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_p_tab);

  void diagonal_parts_pn_n_part_calc (
				      const class GSM_vector &PSI ,
				      class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_n_tab);

  void one_jump_p_parts_pn_calc (
				 const unsigned int occupied_squares_index , 
				 const class GSM_vector &PSI_IN_2D ,
				 const class GSM_vector &PSI_OUT_2D ,
				 class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_p_tab);

  void one_jump_n_parts_pn_calc (
				 const unsigned int occupied_squares_index , 
				 const class GSM_vector &PSI_IN_2D ,
				 const class GSM_vector &PSI_OUT_2D , 
				 class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_n_tab);

  void calc (
	     const class GSM_vector &PSI , 
	     class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_p_tab ,
	     class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_n_tab);
}

#endif


