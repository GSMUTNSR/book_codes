#ifndef GSMPAIRDENSITY_H
#define GSMPAIRDENSITY_H

// TYPE is double or complex
// -------------------------

namespace pair_density
{
  void NBMEs_diagonal_pp_nn_part_calc (				       
				       const class baryons_data &data , 
				       const class array<TYPE> &rk_OBMEs ,
				       const class Slater_determinant &SD , 
				       class array<TYPE> &density_TBMEs ,
				       class array<TYPE> &density_NBMEs);
  
  void NBMEs_diagonal_pn_part_calc (				    
				    const class baryons_data &prot_Y_data , 
				    const class baryons_data &neut_Y_data , 
				    const class array<TYPE> &rk_OBMEs_p , 
				    const class array<TYPE> &rk_OBMEs_n , 
				    const class Slater_determinant &SDp , 
				    const class Slater_determinant &SDn , 
				    class array<TYPE> &density_TBMEs_pn , 
				    class array<TYPE> &density_NBMEs);

  void diagonal_part_pn_p_part_pn_calc (										
					const class array<TYPE> &rk_OBMEs_p , 
					const class GSM_vector &PSI_IN ,
					const class GSM_vector &PSI_OUT , 
					class array<TYPE> &density_tab);

  void diagonal_part_pn_n_part_pn_calc (										
					const class array<TYPE> &rk_OBMEs_n , 
					const class GSM_vector &PSI_IN , 
					const class GSM_vector &PSI_OUT , 
					class array<TYPE> &density_tab);
  
  void diagonal_part_pn_part_pn_Nval_larger_calc (						  
						  const class array<TYPE> &rk_OBMEs_p , 
						  const class array<TYPE> &rk_OBMEs_n , 
						  const class GSM_vector &PSI_IN ,
						  const class GSM_vector &PSI_OUT ,
						  class array<TYPE> &density_tab);
  
  void diagonal_part_pn_part_pn_Zval_larger_calc (						  
						  const class array<TYPE> &rk_OBMEs_p , 
						  const class array<TYPE> &rk_OBMEs_n , 
						  const class GSM_vector &PSI_IN ,
						  const class GSM_vector &PSI_OUT ,
						  class array<TYPE> &density_tab);
  
  void NBMEs_one_jump_mu_no_phase_calc (					
					const unsigned int out_jump , 
					const unsigned int in_jump , 
					const class Slater_determinant &outSD , 
					const class baryons_data &data , 
					const class array<TYPE> &rk_OBMEs , 
					class array<TYPE> &density_TBMEs , 
					class array<TYPE> &density_NBMEs_no_phase_fixed_inSD);
  
  void NBMEs_pn_no_phase_one_jump_p_calc (					  
					  const unsigned int p_in , 
					  const unsigned int p_out , 
					  const class Slater_determinant &SDn , 
					  const class baryons_data &prot_Y_data , 
					  const class baryons_data &neut_Y_data , 
					  const class array<TYPE> &rk_OBMEs_p , 
					  const class array<TYPE> &rk_OBMEs_n , 
					  class array<TYPE> &density_NBMEs_pn_no_phase_fixed_pair);
  
  void NBMEs_pn_no_phase_one_jump_n_calc (					  
					  const unsigned int n_in , 
					  const unsigned int n_out , 
					  const class Slater_determinant &SDp , 
					  const class baryons_data &prot_Y_data , 
					  const class baryons_data &neut_Y_data , 
					  const class array<TYPE> &rk_OBMEs_p , 
					  const class array<TYPE> &rk_OBMEs_n , 
					  class array<TYPE> &density_NBMEs_no_phase_fixed_pair);
  
  void NBMEs_jumps_pp_nn_calc_store (				     
				     const unsigned int occupied_squares_index , 
				     const int n_holes_max_mu , 
				     const int n_scat_max_mu , 
				     const int Emu_max_hw , 
				     const unsigned int BPmu , 
				     const int Smu , 
				     const int n_spec_mu , 
				     const int iMmu , 
				     const int n_scat_mu_out , 
				     const unsigned int iCmu_out , 
				     const unsigned int outSDmu_index , 
				     const class Slater_determinant &outSDmu , 
				     const class baryons_data &data , 
				     const class array<TYPE> &rk_OBMEs , 
				     bool &is_there_one_jump_calc , 
				     bool &is_there_two_jumps_calc , 
				     class jumps_data_out_to_in_str &one_jump_mu , 
				     class jumps_data_out_to_in_str &two_jumps_mu , 
				     class array<TYPE> &density_NBMEs_one_jump_mu_no_phase_fixed_inSD , 
				     class array<TYPE> &density_NBMEs_one_jump_mu , 
				     class array<TYPE> &density_TBMEs_mu , 
				     class array<TYPE> &density_NBMEs_two_jumps_mu);
  
  void densities_part_calc (
			    const class jumps_data_out_to_in_str &jump , 
			    const class array<bool> &are_PSI_IN_indices_accepted_tab , 
			    const class array<unsigned int> &PSI_IN_indices , 
			    const class array<TYPE> &density_NBMEs_jump , 
			    const TYPE &PSI_OUT_component_TRS_factor , 
			    const class GSM_vector &PSI_IN_2D , 
			    class array<TYPE> &density_part_tab);
  
  void jumps_p_p_part_pn_calc (			       
			       const unsigned int occupied_squares_index , 
			       const class array<TYPE> &rk_OBMEs_p , 
			       const class GSM_vector &PSI_IN_2D ,  
			       const class GSM_vector &PSI_OUT_2D , 
			       class array<TYPE> &density_tab);
  
  void jumps_n_n_part_pn_calc (			       
			       const unsigned int occupied_squares_index , 
			       const class array<TYPE> &rk_OBMEs_n , 
			       const class GSM_vector &PSI_IN_2D , 
			       const class GSM_vector &PSI_OUT_2D , 
			       class array<TYPE> &density_tab);
  
  void one_jump_p_pn_part_pn_calc (				   
				   const unsigned int occupied_squares_index , 
				   const class array<TYPE> &rk_OBMEs_p , 
				   const class array<TYPE> &rk_OBMEs_n , 
				   const class GSM_vector &PSI_IN_2D , 
				   const class GSM_vector &PSI_OUT_2D , 
				   class array<TYPE> &density_tab);
  
  void one_jump_n_pn_part_pn_calc (				   
				   const unsigned int occupied_squares_index , 
				   const class array<TYPE> &rk_OBMEs_p , 
				   const class array<TYPE> &rk_OBMEs_n , 
				   const class GSM_vector &PSI_IN_2D ,  
				   const class GSM_vector &PSI_OUT_2D , 
				   class array<TYPE> &density_tab);

  void two_jumps_pn_part_pn_Nval_larger_calc (					      
					      const unsigned int occupied_squares_index ,
					      const class array<TYPE> &rk_OBMEs_p , 
					      const class array<TYPE> &rk_OBMEs_n , 
					      const class GSM_vector &PSI_IN_2D ,  
					      const class GSM_vector &PSI_OUT_2D , 
					      class array<TYPE> &density_tab);
  
  void two_jumps_pn_part_pn_Zval_larger_calc (					      
					      const unsigned int occupied_squares_index , 
					      const class array<TYPE> &rk_OBMEs_p , 
					      const class array<TYPE> &rk_OBMEs_n , 
					      const class GSM_vector &PSI_IN_2D ,  
					      const class GSM_vector &PSI_OUT_2D , 
					      class array<TYPE> &density_tab);
  
  void diagonal_part_pp_nn_calc (				 
				 const class array<TYPE> &rk_OBMEs , 
				 const class GSM_vector &PSI_IN ,
				 const class GSM_vector &PSI_OUT ,  
				 class array<TYPE> &density_tab);
  
  void jumps_part_pp_nn_calc (			      
			      const unsigned int occupied_squares_index , 
			      const class array<TYPE> &rk_OBMEs , 
			      const class GSM_vector &PSI_IN_2D ,
			      const class GSM_vector &PSI_OUT_2D ,  
			      class array<TYPE> &density_tab);

  void pn_calc_diagonal_parts_one_pair (					
					const class array<TYPE> &rk_OBMEs_p , 
					const class array<TYPE> &rk_OBMEs_n , 
					const class GSM_vector &PSI_IN ,
					const class GSM_vector &PSI_OUT , 
					class array<TYPE> &density_pp_tab , 
					class array<TYPE> &density_nn_tab , 
					class array<TYPE> &density_pn_tab);
  
  void pn_calc_jumps_parts_one_pair (				     
				     const unsigned int occupied_squares_index , 
				     const class array<TYPE> &rk_OBMEs_p , 
				     const class array<TYPE> &rk_OBMEs_n , 
				     const class GSM_vector &PSI_IN_2D ,
				     const class GSM_vector &PSI_OUT_2D , 
				     class array<TYPE> &density_pp_tab , 
				     class array<TYPE> &density_nn_tab , 
				     class array<TYPE> &density_pn_tab);
  
  void calc_one_pair (		      
		      const bool is_it_radial ,
		      const bool is_it_Gauss_Legendre , 
		      const class GSM_vector &PSI_IN ,
		      const class GSM_vector &PSI_OUT , 
		      class array<TYPE> &density_pp_tab , 
		      class array<TYPE> &density_nn_tab , 
		      class array<TYPE> &density_pn_tab);
  
  void calc_store_one_pair (			    
			    const bool is_it_radial ,
			    const bool is_it_Gauss_Legendre , 
			    const class array<double> &rk_tab ,
			    const class correlated_state_str &PSI_qn , 
			    const class GSM_vector &PSI);
  
  void calc_store_pair_densities (
				  const class input_data_str &input_data , 
				  const class array<class correlated_state_str> &PSI_qn_tab ,
				  class baryons_data &prot_Y_data , 
				  class baryons_data &neut_Y_data); 
}

#endif


