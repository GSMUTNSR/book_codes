#ifndef GSMLANCZOSDISK_H
#define GSMLANCZOSDISK_H

// TYPE is double or complex
// -------------------------

namespace Lanczos_GSM_disk
{ 
  namespace Hamiltonian
  {
    void new_Lanczos_vector_calc (
				  const bool is_there_cout_detailed , 
				  const bool J_projected ,
				  const bool is_it_Lowdin , 
				  const unsigned int J_number ,
				  const class J2_class &J2 , 
				  const double J , 
				  const class array<TYPE> &diagonal_tab , 
				  const class array<TYPE> &off_diagonal_tab , 
				  const unsigned int i , 
				  class array<class GSM_vector> &V_hybrid_1D_2D_work_vectors  , 
				  class GSM_vector &Vstore ,
				  class GSM_vector &V);

    void tridiagonalization (
			     const bool is_there_cout ,
			     const class input_data_str &input_data , 
			     const bool full_diagonalization , 
			     const unsigned int J_number ,
			     const unsigned int dimension_good_J_or_M , 
			     const unsigned int Lanczos_max_dimension , 
			     const unsigned int vectors_to_find_number , 
			     const double J , 
			     const class J2_class &J2 ,
			     const class H_class &H , 
			     class GSM_vector &V , 
			     class GSM_vector &Vstore ,
			     class array<class GSM_vector> &V_hybrid_1D_2D_work_vectors , 
			     class array<TYPE> &diagonal_tab , 
			     class array<TYPE> &off_diagonal_tab , 
			     class array<TYPE> &E_tab , 
			     unsigned int &Lanczos_dimension , 
			     double &test);

    void Lanczos_matrix_diagonalization_test (
					      const bool is_there_cout , 
					      const bool print_detailed_information ,
					      const unsigned int dimension_good_J_or_M , 
					      const unsigned int Lanczos_dimension , 
					      const unsigned int vectors_to_find_number , 
					      const class array<TYPE> &diagonal_tab , 
					      const class array<TYPE> &off_diagonal_tab , 
					      class array<TYPE> &E_tab , 
					      double &test);

    void all_eigenvectors_energies_alloc_calc (
					       const bool is_it_pole_approximation , 
					       const class GSM_vector_helper_class &GSM_vector_helper_M , 
					       const double J , 
					       const class array<TYPE> &diagonal_tab , 
					       const class array<TYPE> &off_diagonal_tab , 
					       class matrix<TYPE> &Lanczos ,
					       class array<class GSM_vector> &V_hybrid_1D_2D_work_vectors , 
					       class array<TYPE> &E_tab , 
					       class array<TYPE> &E_subspace_tab , 
					       class array<class GSM_vector_helper_class> &GSM_vector_helper_subspace_tab , 
					       class array<class GSM_vector> &eigenvector_subspace_tab);

    void lowest_eigenvectors_calc_store_write_expectation_values (
								  const bool is_there_cout , 
								  const bool vectors_write ,
								  const bool full_common_vectors_used_in_file , 
								  const bool full_diagonalization , 
								  const class input_data_str &input_data , 
								  const class J2_class &J2 , 
								  const class T2_class &T2 , 
								  const class H_class &H , 
								  const class L2_CM_class &L2_CM , 
								  const unsigned int Lanczos_dimension , 
								  const unsigned int eigenset_index , 
								  const unsigned int vectors_to_find_number , 
								  const class array<TYPE> &diagonal_tab , 
								  const class array<TYPE> &off_diagonal_tab , 
								  const class array<TYPE> &E_tab , 
								  const class matrix<TYPE> &Lanczos , 
								  const bool are_PSI_expectation_values_written , 
								  class GSM_vector_helper_class &GSM_vector_helper_hybrid_1D_2D_M ,
								  class GSM_vector_helper_class &GSM_vector_helper_2D_occupied_M ,
								  class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied_M ,  
								  class GSM_vector &Vstore ,
								  class GSM_vector &PSI , 
								  class array<class GSM_vector> &PSI_M_tab , 
								  class array<class GSM_vector> &V_hybrid_1D_2D_work_vectors , 
								  class array<class correlated_state_str> &PSI_qn_tab);

    void iterative_diagonalization_lowest_states (
						  const bool is_there_cout , 
						  const bool is_it_pole_approximation , 
						  const bool vectors_write ,  
						  const class input_data_str &input_data , 
						  const bool full_diagonalization , 
						  const unsigned int J_number ,
						  const unsigned int dimension_good_J_or_M , 
						  const unsigned int Lanczos_max_dimension , 
						  const double J , 
						  const class H_class &H , 
						  const class J2_class &J2 , 
						  const unsigned int eigenset_index , 
						  const unsigned int eigenset_vectors_number ,
						  class array<TYPE> &E_subspace_tab , 
						  class array<class GSM_vector_helper_class> &GSM_vector_helper_subspace_tab , 
						  class array<class GSM_vector> &eigenvector_subspace_tab ,
						  class GSM_vector_helper_class &GSM_vector_helper_hybrid_1D_2D_M ,
						  class GSM_vector_helper_class &GSM_vector_helper_hybrid_1D_2D_Mp1 ,
						  class GSM_vector_helper_class &GSM_vector_helper_2D_occupied_M ,
						  class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied_M , 
						  class GSM_vector_helper_class &GSM_vector_helper_2D_occupied_Mp1 ,
						  class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied_Mp1 , 
						  class GSM_vector &V , 
						  class GSM_vector &Vstore ,
						  class array<class GSM_vector> &PSI_M_tab ,
						  class array<class GSM_vector> &PSI_Mp1_tab ,
						  class GSM_vector &V_hybrid_1D_2D_M ,
						  class GSM_vector &V_hybrid_1D_2D_Mp1 ,
						  class array<class GSM_vector> &V_hybrid_1D_2D_work_vectors , 
						  class array<class correlated_state_str> &PSI_qn_tab);
  }

  namespace J2_projection
  {
    void new_Lanczos_vector_calc (
				  const class array<TYPE> &diagonal_tab , 
				  const class array<TYPE> &off_diagonal_tab , 
				  const unsigned int i , 
				  class array<class GSM_vector> &V_hybrid_1D_2D_work_vectors , 
				  class GSM_vector &Vstore , 
				  class GSM_vector &Vp);

    void tridiagonalization (
			     const unsigned int J_number ,
			     const class J2_class &J2 ,
			     class GSM_vector &Vp ,   
			     class GSM_vector &Vstore ,
			     class array<class GSM_vector> &V_hybrid_1D_2D_work_vectors , 
			     class array<TYPE> &diagonal_tab , 
			     class array<TYPE> &off_diagonal_tab);
    
    void J_projected_GSM_vector_calc (
				      const bool is_there_cout_detailed , 
				      const double J ,
				      const unsigned int J_number ,
				      const class J2_class &J2 ,
				      class array<class GSM_vector> &V_hybrid_1D_2D_work_vectors ,
				      class GSM_vector &Vstore , 
				      class GSM_vector &PSI);
  }
}

#endif


