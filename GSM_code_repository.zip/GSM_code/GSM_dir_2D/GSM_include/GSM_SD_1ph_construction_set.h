#ifndef SD1PHCONSTRUCTIONSET_H
#define SD1PHCONSTRUCTIONSET_H

// TYPE is double or complex
// -------------------------


namespace SD_1ph_construction_set
{
  namespace out_to_inter
  {
    void SD_1h_data_fill (
			  const enum operation_type operation , 
			  const unsigned int occupied_square_index , 
			  const unsigned long int dimensions_SD_1h_table_index , 
			  const unsigned long int SD_1h_table_zero_index , 
			  const unsigned int dimension_SD_inter_1h ,
			  const unsigned long int SD_set_1h_zero_SD_inter_index ,
			  const unsigned int C_1h_table_index , 
			  const int im_1h , 
			  const unsigned int bin_phase ,
			  const class Slater_determinant &SD_inter , 
			  class Slater_determinant &SD_try , 
			  class baryons_data &particles_data);
    
    void SD_1h_table_all_SDs_inter (
				    const enum operation_type operation , 
				    const unsigned int occupied_square_index , 
				    const class Slater_determinant &outSD ,
				    const unsigned long int dimensions_SD_1h_table_index , 
				    const unsigned long int SD_1h_table_zero_index ,
				    const unsigned int dimension_SD_inter_1h ,
				    const unsigned long int SD_set_1h_zero_SD_inter_index ,
				    const unsigned int C_1h_table_index , 
				    const int im_1h , 
				    const unsigned int shell_1h , 
				    class Slater_determinant &SD_inter ,
				    class Slater_determinant &SD_try ,   
				    class baryons_data &particles_data);
    
    void all_SDs_1h_all_SDs (
			     const enum operation_type operation , 
			     const unsigned int occupied_square_index , 
			     const bool is_it_pole_approximation , 
			     class baryons_data &particles_data);
  }
  
  namespace inter_to_in
  {
    void SD_1p_data_fill (
			  const enum operation_type operation ,
			  const unsigned int occupied_squares_index , 
			  const unsigned int inSD_index ,
			  const int im_1p , 
			  const unsigned int bin_phase ,
			  const unsigned int C_1p_table_index ,
			  const unsigned long int SD_1p_table_zero_index ,
			  const unsigned long int dimensions_SD_1p_table_index ,
			  class baryons_data &particles_data);

    void SD_1p_table_all_SDs_inter (
				    const enum operation_type operation ,
				    const unsigned int occupied_squares_index , 
				    const unsigned int C_1p_table_index ,
				    const unsigned int dimension_inSD , 
				    const unsigned long int SD_set_zero_SD_index ,
				    const unsigned long int SD_1p_table_zero_index ,
				    const unsigned long int is_inSD_in_space_zero_index , 
				    const unsigned long int dimensions_SD_1p_table_index ,
				    const int im_1p , 
				    const unsigned int shell_1p_index ,
				    const class Slater_determinant &SD_inter ,
				    class Slater_determinant &inSD ,
				    class Slater_determinant &SD_try ,   
				    class baryons_data &particles_data);

    void all_SDs_1p_all_SDs (
			     const enum operation_type operation , 
			     const unsigned int occupied_square_index , 
			     const bool is_it_pole_approximation , 
			     class baryons_data &particles_data);
  }

  void all_SDs_1ph_all_SDs_alloc_calc (
				       const bool is_there_cout , 
				       const bool is_it_pole_approximation , 
				       const unsigned int occupied_square_index , 
				       class baryons_data &particles_data);
}

#endif


