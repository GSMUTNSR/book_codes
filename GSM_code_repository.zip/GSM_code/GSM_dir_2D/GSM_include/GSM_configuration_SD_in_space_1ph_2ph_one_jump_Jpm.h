#ifndef GSMCONFIGURATIONSDINSPACE1PH2PHONEJUMPJPM_H
#define GSMCONFIGURATIONSDINSPACE1PH2PHONEJUMPJPM_H

// TYPE is double or complex
// -------------------------

namespace configuration_SD_in_space_1ph_2ph_one_jump_Jpm
{
  void tables_1ph_alloc_calc_pp_nn (
				    const bool is_there_cout , 
				    const bool is_it_pole_approximation , 
				    const unsigned int occupied_squares_index , 
				    const bool truncation_hw ,
				    const bool truncation_ph ,
				    class baryons_data &particles_data);

  void tables_2ph_alloc_calc_pp_nn (
				    const bool is_there_cout , 
				    const bool is_it_pole_approximation , 
				    const unsigned int occupied_squares_index ,
				    const bool truncation_hw ,
				    const bool truncation_ph , 
				    class baryons_data &particles_data);

  void is_inSD_in_space_tab_Jpm_pp_nn_determine (
						 const class GSM_vector_helper_class &GSM_vector_helper_in , 
						 class baryons_data &particles_data);
  
  void is_inSD_in_space_tab_Jpm_pn_determine (
					      const class GSM_vector_helper_class &GSM_vector_helper_in , 
					      class baryons_data &prot_Y_data , 
					      class baryons_data &neut_Y_data);
  
  void is_configuration_in_inSD_in_space_tabs_pp_nn_determine (
							       const unsigned int occupied_squares_index , 
							       const class GSM_vector_helper_class &GSM_vector_helper_in , 
							       class baryons_data &particles_data);

  void is_configuration_out_outSD_in_space_tabs_pp_nn_determine (
								 const class GSM_vector_helper_class &GSM_vector_helper_out , 
								 class baryons_data &particles_data);

  void is_configuration_in_inSD_in_space_tabs_pn_determine (
							    const unsigned int occupied_squares_index , 
							    const class GSM_vector_helper_class &GSM_vector_helper_in , 
							    class baryons_data &prot_Y_data , 
							    class baryons_data &neut_Y_data);

  void is_configuration_out_outSD_in_space_tabs_pn_determine (
							      const class GSM_vector_helper_class &GSM_vector_helper_out , 
							      class baryons_data &prot_Y_data , 
							      class baryons_data &neut_Y_data);

  void are_inSD_in_space_tabs_Jpm_determine (
					     const class GSM_vector_helper_class &GSM_vector_helper_in , 
					     class baryons_data &prot_Y_data , 
					     class baryons_data &neut_Y_data);
 
  void are_configuration_SD_in_in_space_tabs_determine (
							const bool is_L2_CM_applied ,  
							const unsigned int occupied_squares_index , 
							const class GSM_vector_helper_class &GSM_vector_helper_in , 
							const class GSM_vector_helper_class &GSM_vector_helper_Mp1 , 
							class baryons_data &prot_Y_data , 
							class baryons_data &neut_Y_data);

  void are_configuration_SD_out_in_space_tabs_determine (
							 const bool is_L2_CM_applied , 
							 const class GSM_vector_helper_class &GSM_vector_helper_out , 
							 const class GSM_vector_helper_class &GSM_vector_helper_Mp1 , 
							 class baryons_data &prot_Y_data , 
							 class baryons_data &neut_Y_data);

  void inSD_in_space_one_jump_tables_alloc_calc_Jpm (
						     const bool is_there_cout , 
						     const int pm ,
						     const class GSM_vector_helper_class &GSM_vector_helper_in , 
						     const class GSM_vector_helper_class &GSM_vector_helper_out , 
						     class baryons_data &prot_Y_data , 
						     class baryons_data &neut_Y_data);
 
  void configuration_SD_in_out_in_space_1ph_2ph_tables_alloc_calc (
								   const bool is_there_cout , 
								   const bool is_it_1ph , 
								   const bool is_L2_CM_applied ,
								   const unsigned int occupied_squares_index , 
								   const class GSM_vector_helper_class &GSM_vector_helper_in , 
								   const class GSM_vector_helper_class &GSM_vector_helper_out , 
								   const class GSM_vector_helper_class &GSM_vector_helper_Mp1 , 
								   class baryons_data &prot_Y_data ,
								   class baryons_data &neut_Y_data);
}

#endif


