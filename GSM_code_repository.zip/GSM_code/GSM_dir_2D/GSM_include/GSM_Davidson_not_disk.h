#ifndef GSMDAVIDSONNOTDISK_H
#define GSMDAVIDSONNOTDISK_H

// TYPE is double or complex
// -------------------------

namespace Davidson_GSM_not_disk
{
  void H_app_minus_E_inverse_apply (
				    const double J , 
				    const class H_class &H , 
				    const TYPE E , 
				    const unsigned int subspace_dimension , 
				    const class array<TYPE> &E_subspace_tab , 
				    const class array<class GSM_vector> &eigenvector_subspace_tab , 
				    const class GSM_vector &Res , 
				    class GSM_vector &Res_subspace , 
				    class GSM_vector &H_app_minus_E_inverse_Res_subspace , 
				    class GSM_vector &H_app_minus_E_inverse_Res);

  void new_Davidson_vector_alloc_calc (
				       const bool is_there_cout_detailed , 
				       const bool is_it_Lowdin , 
				       const unsigned int J_number , 
				       const class J2_class &J2 , 
				       const double J , 
				       const class H_class &H , 
				       const unsigned int i , 
				       const TYPE E , 
				       const unsigned int subspace_dimension , 
				       const class array<TYPE> &E_subspace_tab , 
				       const class array<class GSM_vector> &eigenvector_subspace_tab , 
				       const class GSM_vector &Res , 
				       class GSM_vector &Res_subspace ,
				       class array<class GSM_vector> &V_tab_hybrid_1D_2D , 
				       class array<class GSM_vector> &Vp_tab_hybrid_1D_2D , 
				       class GSM_vector &H_app_minus_E_inverse_Res_subspace , 
				       class GSM_vector &Vstore);

  void Davidson_matrix_calc (
			     const bool is_there_cout , 
			     const unsigned int dimension_good_J , 
			     const class input_data_str &input_data , 
			     const double J , 
			     const unsigned int vector_index , 
			     const unsigned int J_number , 
			     const class J2_class &J2 , 
			     const class H_class &H , 
			     const unsigned int subspace_dimension , 
			     const class array<TYPE> &E_subspace_tab , 
			     const class array<class GSM_vector> &eigenvector_subspace_tab , 
			     class GSM_vector &Res_subspace , 
			     class GSM_vector &H_app_minus_E_inverse_Res_subspace , 
			     class GSM_vector &Res , 
			     class GSM_vector &Vstore , 
			     class array<class GSM_vector> &V_tab_hybrid_1D_2D , 
			     class array<class GSM_vector> &HV_tab_hybrid_1D_2D , 
			     class array<class GSM_vector> &Vp_tab_hybrid_1D_2D , 
			     class matrix<TYPE> &Davidson , 
			     unsigned int &Davidson_dimension , 
			     double &test);

  void Davidson_Res_test (
			  const bool is_there_cout , 
			  const bool print_detailed_information ,
			  const unsigned int dimension_good_J , 
			  const unsigned int Davidson_dimension , 
			  const class matrix<TYPE> &Davidson , 
			  const class array<class GSM_vector> &V_tab_hybrid_1D_2D , 
			  const class array<class GSM_vector> &HV_tab_hybrid_1D_2D , 
			  class GSM_vector &Res , 
			  TYPE &E_tilde , 
			  double &test);

  void largest_overlap_eigenvector_calc_store_write_expectation_values (
									const bool is_there_cout , 
									const class input_data_str &input_data , 
									const class J2_class &J2 , 
									const class T2_class &T2 , 
									const class H_class &H , 
									const class L2_CM_class &L2_CM , 
									const unsigned int Davidson_dimension , 
									const bool are_PSI_expectation_values_written ,
									const class matrix<TYPE> &Davidson ,
									const class array<class GSM_vector> &V_tab_hybrid_1D_2D , 
									class GSM_vector_helper_class &GSM_vector_helper_hybrid_1D_2D_M ,
									class GSM_vector_helper_class &GSM_vector_helper_2D_occupied_M ,
									class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied_M , 
									class GSM_vector &Vstore , 
									class GSM_vector &PSI , 
									class array<class GSM_vector> &PSI_M_tab ,
									class correlated_state_str &PSI_qn);

  void iterative_diagonalization_largest_overlap (
						  const bool is_there_cout , 
						  const unsigned int J_number , 
						  const unsigned int dimension_good_J , 
						  const class input_data_str &input_data , 
						  const unsigned int Davidson_max_dimension , 
						  const class H_class &H , 
						  const class J2_class &J2 , 
						  const unsigned int subspace_dimension , 
						  const class array<TYPE> &E_subspace_tab , 
						  const class array<class GSM_vector> &eigenvector_subspace_tab , 
						  class GSM_vector &Res_subspace , 
						  class GSM_vector &H_app_minus_E_inverse_Res_subspace ,
						  class GSM_vector_helper_class &GSM_vector_helper_hybrid_1D_2D_M ,
						  class GSM_vector_helper_class &GSM_vector_helper_hybrid_1D_2D_Mp1 ,
						  class GSM_vector_helper_class &GSM_vector_helper_2D_occupied_M ,
						  class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied_M , 
						  class GSM_vector_helper_class &GSM_vector_helper_2D_occupied_Mp1 ,
						  class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied_Mp1 , 
						  class GSM_vector &V , 
						  class GSM_vector &Vstore , 
						  class array<class GSM_vector> &PSI_M_tab ,
						  class array<class GSM_vector> &PSI_Mp1_tab ,
						  class GSM_vector &PSI_hybrid_1D_2D_M ,
						  class GSM_vector &PSI_hybrid_1D_2D_Mp1 ,
						  class array<class GSM_vector> &V_tab_hybrid_1D_2D , 
						  class array<class GSM_vector> &HV_tab_hybrid_1D_2D , 
						  class array<class GSM_vector> &Vp_tab_hybrid_1D_2D , 
						  class correlated_state_str &PSI_qn);
}

#endif


