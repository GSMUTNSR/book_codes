#ifndef GSMCLUSTERDATA_H
#define GSMCLUSTERDATA_H

// TYPE is double or complex
// -------------------------

class cluster_data
{
public:
  
  cluster_data ();

  cluster_data (
		const bool is_it_CM_HO_basis , 
		const class input_data_str &input_data , 
		const class baryons_data &prot_Y_data , 
		const class baryons_data &neut_Y_data , 
		const class interaction_class &inter_data_basis , 
		const class cluster_data &cluster_data_helper ,
		const unsigned int ic);

  cluster_data (
		const bool is_there_cout , 
		const bool is_it_GSM_basis , 
		const bool is_it_CM_HO_basis , 
		const class input_data_str &input_data , 
		const class baryons_data &prot_Y_data , 
		const class baryons_data &neut_Y_data , 
		const class interaction_class &inter_data_basis , 
		const unsigned int ic);
  
  cluster_data (
		const bool is_there_cout , 
		const class input_data_str &input_data , 
		const class baryons_data &prot_Y_data , 
		const class baryons_data &neut_Y_data , 
		const class interaction_class &inter_data_basis ,
		const unsigned int eigenset_index , 
		const unsigned int eigenset_vector_number);

  cluster_data (const class cluster_data &X);

  void allocate (
		 const bool is_there_cout , 
		 const bool is_it_GSM_basis , 
		 const bool is_it_CM_HO_basis , 
		 const class input_data_str &input_data , 
		 const class baryons_data &prot_Y_data , 
		 const class baryons_data &neut_Y_data , 
		 const class interaction_class &inter_data_basis , 
		 const unsigned int ic);

  void allocate (
		 const bool is_there_cout , 
		 const class input_data_str &input_data , 
		 const class baryons_data &prot_Y_data , 
		 const class baryons_data &neut_Y_data , 
		 const class interaction_class &inter_data_basis , 
		 const class cluster_data &cluster_data_helper ,
		 const unsigned int ic);
  
  void allocate (
		 const bool is_there_cout , 
		 const class input_data_str &input_data , 
		 const class baryons_data &prot_Y_data , 
		 const class baryons_data &neut_Y_data , 
		 const class interaction_class &inter_data_basis , 
		 const unsigned int eigenset_index , 
		 const unsigned int eigenset_vector_number);

  void allocate_fill (const class cluster_data &X);

  void deallocate ();

  bool is_it_filled () const
  {
    return (cluster != NO_PARTICLE);
  }

  enum potential_type get_H_potential () const
  {
    return H_potential;
  }
  
  enum potential_type get_basis_potential () const
  {
    return basis_potential;
  }

  bool get_is_it_Lowdin () const
  {
    return is_it_Lowdin;
  }

  enum particle_type get_cluster () const
  {
    return cluster;
  }

  bool get_S_matrix_pole () const
  {
    return S_matrix_pole;
  }

  int get_Z_cluster () const
  {
    return Z_cluster;
  }

  int get_N_cluster () const
  {
    return N_cluster;
  }

  int get_A_cluster () const
  {
    return A_cluster;
  }

  int get_A_composite () const
  {
    return A_composite;
  }

  unsigned int get_BP_intrinsic () const
  {
    return BP_intrinsic;
  }

  double get_J_intrinsic () const
  {
    return J_intrinsic;
  }
  
  int get_S_intrinsic () const
  {
    return S_intrinsic;
  }

  unsigned int get_vector_index_intrinsic () const
  {
    return vector_index_intrinsic;
  }

  int get_Lmax () const
  {
    return Lmax;
  }

  int get_Nmax () const
  {
    return Nmax;
  }

  double get_cluster_mass_for_calc () const
  {
    return cluster_mass_for_calc;
  }

  unsigned int get_N_bef_R_GL () const
  {
    return N_bef_R_GL;
  }

  unsigned int get_N_aft_R_GL () const
  {
    return N_aft_R_GL;
  }

  unsigned int get_N_bef_R_uniform () const
  {
    return N_bef_R_uniform;
  }

  unsigned int get_N_aft_R_uniform () const
  {
    return N_aft_R_uniform;
  }

  unsigned int get_Nk_momentum_GL () const
  {
    return Nk_momentum_GL;
  }
  
  unsigned int get_Nk_momentum_uniform () const
  {
    return Nk_momentum_uniform;
  }
  
  double get_R () const
  {
    return R;
  }

  double get_step_bef_R_uniform () const
  {
    return step_bef_R_uniform;
  }

  double get_R_real_max () const
  {
    return R_real_max;
  }

  double get_kmax_momentum () const
  {
    return kmax_momentum;
  }

  double get_R_Fermi_momentum () const
  {
    return R_Fermi_momentum;
  }

  double get_R_charge () const
  {
    return R_charge;
  }

  double get_nucleus_mass () const
  {
    return nucleus_mass;
  }

  double get_R_cut_function () const
  {
    return R_cut_function;
  }

  double get_d_cut_function () const
  {
    return d_cut_function;
  }

  double get_b_lab_cluster () const
  {
    return b_lab_cluster;
  }

  double get_hbar_omega_cluster () const
  {
    return hbar_omega_cluster;
  }

  int get_Z_cluster_charge_potential () const
  {
    return Z_cluster_charge_potential;
  }

  complex<double> get_E_intrinsic_cluster () const
  {
    return E_intrinsic_cluster;
  }

  int get_E_CM_HO_max () const
  {
    return E_CM_HO_max;
  }
  
  double get_potential_cluster_CM_derivative_R () const
  {
    return potential_cluster_CM_derivative_R;
  }
  
  const class array<double> & get_V0_KKNN_tab () const
  {
    return V0_KKNN_tab;
  }
  
  const class array<double> & get_rho_KKNN_tab () const
  {
    return rho_KKNN_tab;
  }

  const class array<double> & get_Vls_KKNN_tab () const
  {
    return Vls_KKNN_tab;
  }
  
  const class array<double> & get_rho_ls_KKNN_tab () const
  {
    return rho_ls_KKNN_tab;
  }
  
  void set_N_poles_cluster_projectile_CM_tab (const class lj_table<unsigned int> &X)
  {
    N_poles_cluster_projectile_CM_tab = X;
  }
  
  class lj_table<unsigned int> & get_N_poles_cluster_projectile_CM_tab ()
  {
    return N_poles_cluster_projectile_CM_tab;
  }
  
  const class lj_table<unsigned int> & get_N_poles_cluster_projectile_CM_tab () const
  {
    return N_poles_cluster_projectile_CM_tab;
  }
  
  void set_Nmin_PCM_cluster_projectile_tab (const class lj_table<int> &X)
  {
    Nmin_PCM_cluster_projectile_tab = X;
  }

  class lj_table<int> & get_Nmin_PCM_cluster_projectile_tab ()
  {
    return Nmin_PCM_cluster_projectile_tab;
  }

  const class lj_table<int> & get_Nmin_PCM_cluster_projectile_tab () const
  {
    return Nmin_PCM_cluster_projectile_tab;
  }

  void set_Nmax_cluster_projectile_CM_tab (const class lj_table<int> &X)
  {
    Nmax_cluster_projectile_CM_tab = X;
  }

  class lj_table<int> & get_Nmax_cluster_projectile_CM_tab ()
  {
    return Nmax_cluster_projectile_CM_tab;
  }

  const class lj_table<int> & get_Nmax_cluster_projectile_CM_tab () const
  {
    return Nmax_cluster_projectile_CM_tab;
  }

  void set_cluster_CM_S_matrix_poles (const class nlj_table<bool> &X)
  {
    cluster_CM_S_matrix_poles = X;
  }

  class nlj_table<bool> & get_cluster_CM_S_matrix_poles ()
  {
    return cluster_CM_S_matrix_poles;
  }

  const class nlj_table<bool> & get_cluster_CM_S_matrix_poles () const
  {
    return cluster_CM_S_matrix_poles;
  }

  void set_cluster_CM_R0_tab (const class array<double> &X)
  {
    cluster_CM_R0_tab = X;
  }

  class array<double> & get_cluster_CM_R0_tab ()
  {
    return cluster_CM_R0_tab;
  }

  const class array<double> & get_cluster_CM_R0_tab () const
  {
    return cluster_CM_R0_tab;
  }

  void set_cluster_CM_K_tab (const class nlj_table<complex<double> > &X)
  {
    cluster_CM_K_tab = X;
  }

  class nlj_table<complex<double> > & get_cluster_CM_K_tab ()
  {
    return cluster_CM_K_tab;
  }

  const class nlj_table<complex<double> > & get_cluster_CM_K_tab () const
  {
    return cluster_CM_K_tab;
  }

  void set_cluster_CM_W_tab (const class nlj_table<complex<double> > &X)
  {
    cluster_CM_W_tab = X;
  }

  class nlj_table<complex<double> > & get_cluster_CM_W_tab ()
  {
    return cluster_CM_W_tab;
  }

  const class nlj_table<complex<double> > & get_cluster_CM_W_tab () const
  {
    return cluster_CM_W_tab;
  }

  void set_cluster_CM_E_tab (const class nlj_table<complex<double> > &X)
  {
    cluster_CM_E_tab = X;
  }

  class nlj_table<complex<double> > & get_cluster_CM_E_tab ()
  {
    return cluster_CM_E_tab;
  }

  const class nlj_table<complex<double> > & get_cluster_CM_E_tab () const
  {
    return cluster_CM_E_tab;
  }

  void set_cluster_CM_C0_tab (const class nlj_table<complex<double> > &X)
  {
    cluster_CM_C0_tab = X;
  }

  class nlj_table<complex<double> > & get_cluster_CM_C0_tab ()
  {
    return cluster_CM_C0_tab;
  }

  const class nlj_table<complex<double> > & get_cluster_CM_C0_tab () const
  {
    return cluster_CM_C0_tab;
  }

  void set_cluster_CM_Cplus_tab (const class nlj_table<complex<double> > &X)
  {
    cluster_CM_Cplus_tab = X;
  }

  class nlj_table<complex<double> > & get_cluster_CM_Cplus_tab ()
  {
    return cluster_CM_Cplus_tab;
  }

  const class nlj_table<complex<double> > & get_cluster_CM_Cplus_tab () const
  {
    return cluster_CM_Cplus_tab;
  }

  void set_potential_cluster_CM_bef_R_tab_uniform (const class lj_table<double> &X)
  {
    potential_cluster_CM_bef_R_tab_uniform = X;
  }

  class lj_table<double> & get_potential_cluster_CM_bef_R_tab_uniform ()
  {
    return potential_cluster_CM_bef_R_tab_uniform;
  }

  const class lj_table<double> & get_potential_cluster_CM_bef_R_tab_uniform () const
  {
    return potential_cluster_CM_bef_R_tab_uniform;
  }

  void set_potential_cluster_CM_bef_R_tab_GL (const class lj_table<double> &X)
  {
    potential_cluster_CM_bef_R_tab_GL = X;
  }

  class lj_table<double> & get_potential_cluster_CM_bef_R_tab_GL ()
  {
    return potential_cluster_CM_bef_R_tab_GL;
  }

  const class lj_table<double> & get_potential_cluster_CM_bef_R_tab_GL () const
  {
    return potential_cluster_CM_bef_R_tab_GL;
  }

  void set_potential_cluster_CM_aft_R_tab_GL (const class lj_table<double> &X)
  {
    potential_cluster_CM_aft_R_tab_GL = X;
  }

  class lj_table<double> & get_potential_cluster_CM_aft_R_tab_GL ()
  {
    return potential_cluster_CM_aft_R_tab_GL;
  }

  const class lj_table<double> & get_potential_cluster_CM_aft_R_tab_GL () const
  {
    return potential_cluster_CM_aft_R_tab_GL;
  }

  class lj_table<double> & get_potential_cluster_CM_derivative_r0_tab ()
  {
    return potential_cluster_CM_derivative_r0_tab;
  }

  const class lj_table<double> & get_potential_cluster_CM_derivative_r0_tab () const
  {
    return potential_cluster_CM_derivative_r0_tab;
  }

  class nlj_table<class spherical_state > & get_cluster_CM_shells ()
  {
    return cluster_CM_shells;
  }

  const class nlj_table<class spherical_state > & get_cluster_CM_shells () const
  {
    return cluster_CM_shells;
  }

  void set_Nmax_HO_tab (const class array<int> &X)
  {
    Nmax_HO_tab = X;
  }

  class array<int> & get_Nmax_HO_tab ()
  {
    return Nmax_HO_tab;
  }

  const class array<int> & get_Nmax_HO_tab () const
  {
    return Nmax_HO_tab;
  }

  void set_r_bef_R_tab_uniform (const class array<double> &X)
  {
    r_bef_R_tab_uniform = X;
  }

  class array<double> & get_r_bef_R_tab_uniform ()
  {
    return r_bef_R_tab_uniform;
  }

  const class array<double> & get_r_bef_R_tab_uniform () const
  {
    return r_bef_R_tab_uniform;
  }
  
  void set_r_bef_R_tab_GL (const class array<double> &X)
  {
    r_bef_R_tab_GL = X;
  }

  class array<double> & get_r_bef_R_tab_GL ()
  {
    return r_bef_R_tab_GL;
  }

  const class array<double> & get_r_bef_R_tab_GL () const
  {
    return r_bef_R_tab_GL;
  }

  void set_w_bef_R_tab_GL (const class array<double> &X)
  {
    w_bef_R_tab_GL = X;
  }

  class array<double> & get_w_bef_R_tab_GL ()
  {
    return w_bef_R_tab_GL;
  }

  const class array<double> & get_w_bef_R_tab_GL () const
  {
    return w_bef_R_tab_GL;
  }

  void set_HO_wfs_bef_R_tab_GL (const class array<double> &X)
  {
    HO_wfs_bef_R_tab_GL = X;
  }

  class array<double> & get_HO_wfs_bef_R_tab_GL ()
  {
    return HO_wfs_bef_R_tab_GL;
  }

  const class array<double> & get_HO_wfs_bef_R_tab_GL () const
  {
    return HO_wfs_bef_R_tab_GL;
  }

  void set_HO_dwfs_bef_R_tab_GL (const class array<double> &X)
  {
    HO_dwfs_bef_R_tab_GL = X;
  }

  class array<double> & get_HO_dwfs_bef_R_tab_GL ()
  {
    return HO_dwfs_bef_R_tab_GL;
  }

  const class array<double> & get_HO_dwfs_bef_R_tab_GL () const
  {
    return HO_dwfs_bef_R_tab_GL;
  }

  void set_r_aft_R_tab_GL (const class array<double> &X)
  {
    r_aft_R_tab_GL = X;
  }

  class array<double> & get_r_aft_R_tab_GL ()
  {
    return r_aft_R_tab_GL;
  }

  const class array<double> & get_r_aft_R_tab_GL () const
  {
    return r_aft_R_tab_GL;
  }

  void set_w_aft_R_tab_GL (const class array<double> &X)
  {
    w_aft_R_tab_GL = X;
  }

  class array<double> & get_w_aft_R_tab_GL ()
  {
    return w_aft_R_tab_GL;
  }

  const class array<double> & get_w_aft_R_tab_GL () const
  {
    return w_aft_R_tab_GL;
  }

  void set_HO_wfs_aft_R_tab_GL (const class array<double> &X)
  {
    HO_wfs_aft_R_tab_GL = X;
  }

  class array<double> & get_HO_wfs_aft_R_tab_GL ()
  {
    return HO_wfs_aft_R_tab_GL;
  }

  const class array<double> & get_HO_wfs_aft_R_tab_GL () const
  {
    return HO_wfs_aft_R_tab_GL;
  }

  void set_HO_dwfs_aft_R_tab_GL (const class array<double> &X)
  {
    HO_dwfs_aft_R_tab_GL = X;
  }

  class array<double> & get_HO_dwfs_aft_R_tab_GL ()
  {
    return HO_dwfs_aft_R_tab_GL;
  }

  const class array<double> & get_HO_dwfs_aft_R_tab_GL () const
  {
    return HO_dwfs_aft_R_tab_GL;
  }

  void set_HO_overlaps_cluster_CM (const class nlj_table<class vector_class<complex<double> > > &X)
  {
    HO_overlaps_cluster_CM = X;
  }

  class nlj_table<class vector_class<complex<double> > > & get_HO_overlaps_cluster_CM ()
  {
    return HO_overlaps_cluster_CM;
  }

  const class nlj_table<class vector_class<complex<double> > > & get_HO_overlaps_cluster_CM () const
  {
    return HO_overlaps_cluster_CM;
  }

  void set_HO_overlaps_Fermi_cluster_CM (const class nlj_table<class vector_class<complex<double> > > &X)
  {
    HO_overlaps_Fermi_cluster_CM = X;
  }

  class nlj_table<class vector_class<complex<double> > > & get_HO_overlaps_Fermi_cluster_CM ()
  {
    return HO_overlaps_Fermi_cluster_CM;
  }

  const class nlj_table<class vector_class<complex<double> > > & get_HO_overlaps_Fermi_cluster_CM () const
  {
    return HO_overlaps_Fermi_cluster_CM;
  }

  void set_PCM_matrices_cluster (const class lj_table<class matrix<double> > &X)
  {
    PCM_matrices_cluster = X;
  }

  class lj_table<class matrix<double> > & get_PCM_matrices_cluster ()
  {
    return PCM_matrices_cluster;
  }

  const class lj_table<class matrix<double> > & get_PCM_matrices_cluster () const
  {
    return PCM_matrices_cluster;
  }

  class baryons_data & get_cluster_prot_Y_data_HO ()
  {
    return cluster_prot_Y_data_HO;
  }

  const class baryons_data & get_cluster_prot_Y_data_HO () const
  {
    return cluster_prot_Y_data_HO;
  }

  class baryons_data & get_cluster_neut_Y_data_HO ()
  {
    return cluster_neut_Y_data_HO;
  }

  const class baryons_data & get_cluster_neut_Y_data_HO () const
  {
    return cluster_neut_Y_data_HO;
  }

  class baryons_data & get_cluster_prot_Y_data ()
  {
    return cluster_prot_Y_data;
  }

  const class baryons_data & get_cluster_prot_Y_data () const
  {
    return cluster_prot_Y_data;
  }
  
  class baryons_data & get_cluster_neut_Y_data ()
  {
    return cluster_neut_Y_data;
  }

  const class baryons_data & get_cluster_neut_Y_data () const
  {
    return cluster_neut_Y_data;
  }

  void HO_overlaps_CM_calc ();

  void PCM_matrices_cluster_calc ();
  
  void get_PCM_matrices_cluster (const class cluster_data &data_CC_Berggren);

  friend double used_memory_calc (const class cluster_data &T);
  
private:
  
  void potential_part_r_tab_fixed_calc (
					const enum particle_type particle , 
					const int L , 
					const double J , 
					const class array<double> &r_tab , 
					class array<double> &nucleon_part_potential_tab) const;

  void potential_part_calc (
			    const int L , 
			    const double J);

  void cluster_CM_potential_tables_calc (
					 const int L , 
					 const double J);

  enum potential_type H_potential;       // potential used in the Hamiltonian: it is the potential of the core, which can be typically WS or KKNN
  enum potential_type basis_potential;   // basis_potential: potential used for basis generation (WS, HF, ...)

  bool is_it_Lowdin; // true if one uses the Lowdin method for J-projection, false if one uses the Lanczos method for that matter (this is independent of Hamiltonian diagonalization). 
  
  enum particle_type cluster; // type of cluster (proton, neutron, diproton, deuteron, 3He, alpha, ...)

  bool S_matrix_pole; // true if one has a resonant cluster state, false if it is scattering

  int Z_cluster; // number of protons  of the cluster 
  int N_cluster; // number of neutrons of the cluster 
  int A_cluster; // number of nucleons of the cluster 

  int A_composite; // number of nucleons of the composite target + cluster

  unsigned int BP_intrinsic; // binary parity (see observables_basic_functions.cpp for definition) of the cluster intrinsic wave function

  int S_intrinsic; // strangeness of the cluster intrinsic wave function
  
  double J_intrinsic; // total angular momentum of the cluster intrinsic wave function

  unsigned int vector_index_intrinsic; // eigenvector index of the cluster intrinsic wave function (0 in 1+(0) for example)

  int Lmax; // maximal orbital angular momentum of the cluster partial wave expansion
  int Nmax; // maximal principal quantum number of the cluster partial wave expansion

  double cluster_mass_for_calc; // mass of the cluster, used in the calculation of CM cluster wave functions. It does not have to be its physical mass.

  unsigned int N_bef_R_GL; // number of Gauss-Legendre points on [0:R] (before R) (see spherical_state.cpp)
  unsigned int N_aft_R_GL; // number of Gauss-Legendre points on [R:R_real_max], [0:1/R^4] (after R) (see spherical_state.cpp)
  
  unsigned int N_bef_R_uniform;      // number of points on the uniform grid  [0:R] (before R) (see spherical_state.cpp)
  unsigned int N_aft_R_uniform;      // number of points on the uniform grids [R:R_real_max], [0:1/R^4] (after R) (see spherical_state.cpp)
  
  unsigned int Nk_momentum_GL;       // number of Gauss-Legendre points on [0:kmax_momentum] for wave functions in momentum space
  unsigned int Nk_momentum_uniform;  // number of points on the uniform grid [0:kmax_momentum] for wave functions in momentum space
  
  double R;                                         // rotation point of complex scaling
  double step_bef_R_uniform;                        // radial step on the uniform grid on [0:R], with R the rotation point. The number of points on the uniform grid is typically 10 times that of Gauss-Legendre
  double R_real_max;                                // maximal radius considered on the real-axis. All HO states must be negligible therein.
  
  double kmax_momentum;                             // maximal momentum for the calculation of densities and correlation densities in momentum space

  double R_Fermi_momentum;                          // Radius of the Fermi function applied to one-body basis states for the calculation of their approximate Fourier-Bessel transform. The diffuseness can be fixed at a large value.

  double R_charge;                                  // charge radius used in the Coulomb potential

  double nucleus_mass;                              // mass of the core nucleus if COSM is used, mass of the considered nucleus if not, used for Hamiltonian diagonalization

  double R_cut_function;                            // diffuseness of the Fermi cut function F(r) (see basic_maths.cpp) used in HF/MSDHF/OCM potentials for stability
  double d_cut_function;                            // radius      of the Fermi cut function F(r) (see basic_maths.cpp) used in HF/MSDHF/OCM potentials for stability

  double b_lab_cluster;                             // HO length of HO cluster wave functions

  double hbar_omega_cluster;                        // HO hbar omega value of HO cluster wave functions

  int Z_cluster_charge_potential;                   // charge of the Coulomb potential of the cluster wave function. It is Z_core + Z_cluster - 1 if Z_cluster >= 1 and Z_core otherwise

  complex<double> E_intrinsic_cluster;              // Intrinsic energy of the cluster wavre function

  int E_CM_HO_max;                                  // Maximal CM energy of HO CM states in the expansion of projectiles in intrinsic/CM coordinates,
                                                    // hence equal to 2.NCM_max + LCM_max

  double potential_cluster_CM_derivative_R;         // V[cluster]'(R), used in splines of V[cluster](r)

  class array<double> V0_KKNN_tab;     // Central strength array of the set of KKNN parameters for each particle type
  class array<double> rho_KKNN_tab;    // Central length array of the set of KKNN parameters for each particle type
  class array<double> Vls_KKNN_tab;    // Spin-orbit strength array of the set of KKNN parameter for each particle type
  class array<double> rho_ls_KKNN_tab; // Spin-orbit length array of the set of KKNN parameters for each particle type
  
  class lj_table<unsigned int> N_poles_cluster_projectile_CM_tab;   // (l,j) array of the number of cluster poles per partial wave

  class lj_table<int> Nmin_PCM_cluster_projectile_tab;              // (l,j) array of the N[min] occurring in the projection P[CM] on states not occupying too much the core per partial wave

  class lj_table<int> Nmax_cluster_projectile_CM_tab;               // (l,j) array of the N[max] per partial wave

  class nlj_table<bool> cluster_CM_S_matrix_poles;       // (n,l,j) array of S-matrix poles (true if it one, false if not)

  class array<double> cluster_CM_R0_tab;                 // Arrays of radii R0 per partial wave for core potentials for each orbital angular momentum

  class nlj_table<complex<double> > cluster_CM_K_tab;    // (n,l,j) array of linear momenta for each cluster shell
  class nlj_table<complex<double> > cluster_CM_W_tab;    // (n,l,j) array of Gauss-Legendre weights of discretized scattering states for each cluster shell
  class nlj_table<complex<double> > cluster_CM_E_tab;    // (n,l,j) array of energies for each cluster shell

  class nlj_table<complex<double> > cluster_CM_C0_tab;     // (n,l,j) array of C0 integration constant (U[cluster](r) ~ C0 r^(l+1), r ~ 0) for each cluster shell
  class nlj_table<complex<double> > cluster_CM_Cplus_tab;  // (n,l,j) array of C0 integration constant (U[cluster](r) ~ C+ H+(kr) + C- H-(kr), r > R) for each cluster shell

  class lj_table<double> potential_cluster_CM_bef_R_tab_uniform; // (l,j) array of potentials Vlj[cluster](r) on a uniform grid on [0:R]

  class lj_table<double> potential_cluster_CM_bef_R_tab_GL; // (l,j) array of potentials Vlj[cluster](r) on a Gauss-Legendre grid on [0:R]
  class lj_table<double> potential_cluster_CM_aft_R_tab_GL; // (l,j) array of potentials Vlj[cluster](r) on a Gauss-Legendre grid on [R:R[max]]

  class lj_table<double> potential_cluster_CM_derivative_r0_tab; // (l,j) array of Vlj[cluster]'(r0), used in splines of Vlj[cluster](r)

  class nlj_table<class spherical_state > cluster_CM_shells;     // Array of CM parts of cluster wave functions (see spherical_state.cpp)

  class array<int> Nmax_HO_tab;                                  // Array of the N[max] per HO orbital angular momentum

  class array<double> r_bef_R_tab_uniform; // Uniformly distributed abscissas before R : r = i.step_bef_R_uniform ,  i in [0:N_bef_R_uniform-1]
  
  class array<double> r_bef_R_tab_GL , w_bef_R_tab_GL , HO_wfs_bef_R_tab_GL , HO_dwfs_bef_R_tab_GL; // Gaussian abscissas and weights before R : r in ]0:R[ and cluster HO wave functions there for each n,l
  class array<double> r_aft_R_tab_GL , w_aft_R_tab_GL , HO_wfs_aft_R_tab_GL , HO_dwfs_aft_R_tab_GL; // Gaussian abscissas and weights after R : r in ]R:R_real_max[ if R_real_max > 0 and cluster HO wave functions there for each n,l

  class nlj_table<class vector_class<complex<double> > > HO_overlaps_cluster_CM;             // Array of overlaps between cluster shells and HO states
  class nlj_table<class vector_class<complex<double> > > HO_overlaps_Fermi_cluster_CM;       // Array of overlaps between cluster shells and HO states multiplied by a Fermi function

  class lj_table<class matrix<double> > PCM_matrices_cluster; // (l,j) array of matrices of P[CM] projectors on states not occupying too much the core per partial wave

  // Proton and neutron data in HO or Berggren space
  
  class baryons_data cluster_prot_Y_data_HO , cluster_prot_Y_data;
  class baryons_data cluster_neut_Y_data_HO , cluster_neut_Y_data;

  void contours_data_fill (
			   const class input_data_str &input_data , 
			   const unsigned int ic);

  void HO_CM_basis_data_fill (
			      const class input_data_str &input_data , 
			      const unsigned int ic);
};

#endif


