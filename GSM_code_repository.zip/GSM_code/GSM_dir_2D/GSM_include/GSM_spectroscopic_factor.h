#ifndef GSMSPECTROSCOPICFACTOR_H
#define GSMSPECTROSCOPICFACTOR_H

// TYPE is double or complex
// -------------------------

namespace spectroscopic_factor
{
  namespace one_baryon
  {
    TYPE stripping_calc (
			 const bool full_common_vectors_used_in_file ,
			 const class ljm_struct &ljm , 
			 const class correlated_state_str &PSI_IN_qn , 
			 const class correlated_state_str &PSI_OUT_qn , 
			 const class GSM_vector &PSI_OUT);
    
    TYPE pick_up_calc (
		       const bool full_common_vectors_used_in_file ,
		       const class ljm_struct &ljm , 
		       const class correlated_state_str &PSI_IN_qn , 
		       const class correlated_state_str &PSI_OUT_qn , 
		       const class GSM_vector &PSI_OUT);
  }

  namespace cluster
  {
    TYPE stripping_calc (
			 const bool full_common_vectors_used_in_file ,
			 const int NCM_HO_max_proj , 
			 const class ljm_struct &LJM_cluster , 
			 const class correlated_state_str &PSI_IN_qn , 
			 const class correlated_state_str &PSI_OUT_qn , 
			 const class correlated_state_str &PSI_cluster_qn , 
			 const class GSM_vector &PSI_OUT);
    
    TYPE pick_up_calc (
		       const bool full_common_vectors_used_in_file ,
		       const int NCM_HO_max_proj , 
		       const class ljm_struct &LJM_cluster , 
		       const class correlated_state_str &PSI_IN_qn , 
		       const class correlated_state_str &PSI_OUT_qn , 
		       const class correlated_state_str &PSI_cluster_qn , 
		       const class GSM_vector &PSI_OUT);
  }

  namespace nucleus
  {
    TYPE stripping_calc (
			 const bool full_common_vectors_used_in_file ,
			 const class correlated_state_str &PSI_IN_qn , 
			 const class correlated_state_str &PSI_OUT_qn , 
			 const class correlated_state_str &PSI_cluster_qn ,			 
			 const double M_cluster , 
			 const class GSM_vector &PSI_OUT);

    TYPE pick_up_calc (
		       const bool full_common_vectors_used_in_file ,
		       const class correlated_state_str &PSI_IN_qn , 
		       const class correlated_state_str &PSI_OUT_qn , 
		       const class correlated_state_str &PSI_cluster_qn , 		 
		       const double M_cluster , 
		       const class GSM_vector &PSI_OUT); 
  }
  
  TYPE calc (
	     const bool full_common_vectors_used_in_file ,
	     const enum spectroscopic_factor_type SF , 
	     const enum nucleus_type nucleus , 
	     const int NCM_HO_max_cluster , 
	     const class ljm_struct &LJM_cluster , 
	     const class correlated_state_str &PSI_IN_qn , 
	     const class correlated_state_str &PSI_OUT_qn , 
	     const class correlated_state_str &PSI_cluster_qn ,		 
	     const class GSM_vector &PSI_OUT);

  void calc_print (
		   const class input_data_str &input_data , 
		   const class array<class correlated_state_str> &PSI_qn_tab ,
		   class baryons_data &prot_Y_data , 				 
		   class baryons_data &neut_Y_data); 
}

#endif


