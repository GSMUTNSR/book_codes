#ifndef GSMVECTORNBMESHANDLING_H
#define GSMVECTORNBMESHANDLING_H

// TYPE is double or complex
// -------------------------

namespace GSM_vector_NBMEs_handling
{
  TYPE component_part_jumps_calc (
				  const unsigned int dimension_jumps ,
				  const class array<bool> &are_PSI_in_indices_accepted_tab , 
				  const class array<unsigned int> &PSI_in_indices , 
				  const class array<TYPE> &NBMEs_jumps ,
				  const class GSM_vector &PSI_in);
  
  TYPE component_part_jumps_calc (
				  const unsigned int dimension_jumps ,
				  const class array<bool> &are_PSI_in_indices_accepted_tab , 
				  const class array<unsigned long int> &total_PSI_in_indices , 
				  const class array<TYPE> &NBMEs_jumps ,
				  const class GSM_vector &PSI_in_full);
  
  unsigned int component_part_jumps_number_calc (
						 const unsigned int dimension_jumps ,
						 const class array<bool> &are_PSI_in_indices_accepted_tab);

  namespace in_to_out
  {  
    void is_configuration_accepted_p_fill (
					   const int n_holes_n , 
					   const int n_scat_n , 
					   const int En_hw , 
					   const unsigned int BPp , 
					   const int Sp , 
					   const int n_spec_p , 
					   const class GSM_vector_helper_class &GSM_vector_helper ,
					   class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_accepted_p_tab);
  
    void is_configuration_accepted_n_fill (
					   const int n_holes_p ,
					   const int n_scat_p , 
					   const int Ep_hw , 
					   const unsigned int BPn , 
					   const int Sn , 
					   const int n_spec_n , 
					   const class GSM_vector_helper_class &GSM_vector_helper , 
					   class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_accepted_n_tab);
 
    void dimensions_SDp_sum_dimensions_configuration_Mp_Mn_fixed_p_fill (
									 const unsigned int BPn , 
									 const int Sn ,
									 const int n_spec_n ,  
									 const int n_scat_n , 
									 const unsigned int iCn , 
									 const int iMn , 
									 const class GSM_vector_helper_class &GSM_vector_helper , 
									 const class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_accepted_tab , 
									 class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_Mp_fixed , 
									 class array_BP_S_Nspec_Nscat_iC<unsigned int> &sum_dimensions_configuration_Mp_Mn_fixed_tab);
 
    void dimensions_SDn_sum_dimensions_configuration_Mp_Mn_fixed_n_fill (
									 const unsigned int BPp , 
									 const int Sp ,
									 const int n_spec_p ,    
									 const int n_scat_p , 
									 const unsigned int iCp , 
									 const int iMp , 
									 const class GSM_vector_helper_class &GSM_vector_helper , 
									 const class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_accepted_tab , 
									 class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_Mn_fixed , 
									 class array_BP_S_Nspec_Nscat_iC<unsigned int> &sum_dimensions_configuration_Mp_Mn_fixed_tab);
  
    void NBMEs_one_jump_mu_calc_one_body_operator_Jpm (
						       const class array<double> &OBMEs_mu,
						       const class jumps_data_in_to_out_str &one_jump_one_mu,
						       class array<double> &NBMEs_one_jump_mu);
    
    
    void are_PSI_out_indices_accepted_PSI_out_indices_p_fill_Jpm (
								  const int n_scat_n , 
								  const unsigned int iCn , 
								  const unsigned int SDn_index ,
								  const unsigned int BPp , 
								  const int Sp , 
								  const int n_spec_p , 
								  const int n_scat_p ,
								  const unsigned int iCp , 
								  const int iMp_pm_one ,
								  const class jumps_data_in_to_out_str &one_jump_p , 
								  const class GSM_vector_helper_class &GSM_vector_helper_out , 
								  const unsigned int dimension_SDn ,
								  class array<bool> &is_PSI_out_index_accepted_p_tab ,	
								  class array<unsigned int> &square_row_indices ,  
								  class array<unsigned int> &PSI_out_indices ,
								  bool &is_there_calc);
 
    void are_PSI_out_indices_accepted_PSI_out_indices_n_fill_Jpm (
								  const unsigned int BPp ,
								  const int Sp ,
								  const int n_spec_p ,     
								  const int n_scat_p , 
								  const unsigned int iCp , 
								  const int iMp , 
								  const unsigned int SDp_index , 
								  const int n_scat_n , 
								  const unsigned int iCn ,
								  const class jumps_data_in_to_out_str &one_jump_n , 
								  const class GSM_vector_helper_class &GSM_vector_helper_out ,
								  const unsigned int dimension_outSDn , 
								  class array<bool> &is_PSI_out_index_accepted_n_tab ,
								  class array<unsigned int> &square_row_indices ,  
								  class array<unsigned int> &PSI_out_indices ,
								  bool &is_there_calc);
 
    void are_PSI_out_indices_accepted_PSI_out_indices_pp_nn_fill_Jpm (
								      const int n_scat ,
								      const unsigned int iC ,
								      const class jumps_data_in_to_out_str &one_jump_mu , 
								      const class GSM_vector_helper_class &GSM_vector_helper_out ,
								      class array<bool> &is_PSI_out_index_accepted_mu_tab ,
								      class array<unsigned int> &square_row_indices ,  
								      class array<unsigned int> &PSI_out_indices ,
								      bool &is_there_calc);
  }
 
  namespace out_to_in
  {  
    void is_configuration_accepted_p_fill (
					   const int n_holes_n ,
					   const int n_scat_n , 
					   const int En_hw , 
					   const unsigned int BPp , 
					   const int Sp , 
					   const int n_spec_p , 
					   const class GSM_vector_helper_class &GSM_vector_helper ,
					   class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_accepted_p_tab);
  
    void is_configuration_accepted_n_fill (
					   const int n_holes_p ,
					   const int n_scat_p , 
					   const int Ep_hw , 
					   const unsigned int BPn ,
					   const int Sn , 
					   const int n_spec_n , 
					   const class GSM_vector_helper_class &GSM_vector_helper , 
					   class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_accepted_n_tab);
 
    void dimensions_SDp_sum_dimensions_configuration_Mp_Mn_fixed_p_fill (
									 const unsigned int BPn ,
									 const int Sn ,
									 const int n_spec_n ,     
									 const int n_scat_n , 
									 const unsigned int iCn , 
									 const int iMn , 
									 const class GSM_vector_helper_class &GSM_vector_helper , 
									 const class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_accepted_tab , 
									 class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_Mp_fixed , 
									 class array_BP_S_Nspec_Nscat_iC<unsigned int> &sum_dimensions_configuration_Mp_Mn_fixed_tab);
 
    void dimensions_SDn_sum_dimensions_configuration_Mp_Mn_fixed_n_fill (
									 const unsigned int BPp , 
									 const int Sp ,
									 const int n_spec_p ,    
									 const int n_scat_p , 
									 const unsigned int iCp , 
									 const int iMp , 
									 const class GSM_vector_helper_class &GSM_vector_helper , 
									 const class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_accepted_tab , 
									 class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_Mn_fixed , 
									 class array_BP_S_Nspec_Nscat_iC<unsigned int> &sum_dimensions_configuration_Mp_Mn_fixed_tab);
  
    void NBMEs_one_jump_mu_calc_one_body_operator (
						   const class array<TYPE> &OBMEs_mu,
						   const class jumps_data_out_to_in_str &one_jump_one_mu,
						   class array<TYPE> &NBMEs_one_jump_mu);
    
    void NBMEs_one_jump_mu_calc_one_body_operator_Jpm (
						       const class array<double> &OBMEs_mu,
						       const class jumps_data_out_to_in_str &one_jump_one_mu,
						       class array<double> &NBMEs_one_jump_mu);
    
    void is_configuration_accepted_total_PSI_in_indices_p_fill (
								const unsigned int BPn ,  
								const int Sn ,
								const int n_spec_n ,    
								const int n_holes_n , 
								const int n_scat_n , 
								const unsigned int iCn , 
								const int iMn , 
								const unsigned int SDn_index , 
								const int En_hw , 
								const class jumps_data_out_to_in_str &jumps_p , 
								const class GSM_vector_helper_class &GSM_vector_helper_in , 
								const unsigned int dimension_SDn ,
								class array<bool> &is_configuration_accepted_p_tab ,
								class array<unsigned long int> &total_PSI_in_indices_p ,
								bool &is_there_calc);

    void is_configuration_accepted_total_PSI_in_indices_n_fill (
								const unsigned int BPp ,
								const int Sp ,
								const int n_spec_p ,     
								const int n_holes_p ,  
								const int n_scat_p , 
								const unsigned int iCp , 
								const int iMp , 
								const unsigned int SDp_index , 
								const int Ep_hw , 
								const class jumps_data_out_to_in_str &jumps_n , 
								const class GSM_vector_helper_class &GSM_vector_helper_in ,
								class array<bool> &is_configuration_accepted_n_tab , 
								class array<unsigned long int> &total_PSI_in_indices_n ,
								bool &is_there_calc);

    void total_PSI_in_indices_pp_nn_fill (
					  const class jumps_data_out_to_in_str &jumps_mu , 
					  const class GSM_vector_helper_class &GSM_vector_helper_in ,
					  class array<unsigned long int> &total_PSI_in_indices ,
					  bool &is_there_calc);
    
    void are_PSI_in_indices_accepted_p_fill_symmetric_case (
							    const unsigned int BPn , 
							    const int Sn ,
							    const int n_spec_n ,    
							    const int n_holes_n , 
							    const int n_scat_n , 
							    const unsigned int iCn , 
							    const int iMn , 
							    const unsigned int SDn_index , 
							    const int En_hw , 
							    const class jumps_data_out_to_in_str &jumps_p , 
							    const class GSM_vector_helper_class &GSM_vector_helper_in , 
							    const unsigned int dimension_SDn ,
							    const unsigned int PSI_out_index , 
							    class array<bool> &are_PSI_in_indices_accepted_p_tab ,
							    bool &is_there_calc);
 
    void are_PSI_in_indices_accepted_n_fill_symmetric_case (
							    const unsigned int BPp ,
							    const int Sp ,
							    const int n_spec_p ,     
							    const int n_holes_p , 
							    const int n_scat_p , 
							    const unsigned int iCp , 
							    const int iMp , 
							    const unsigned int SDp_index , 
							    const int Ep_hw , 
							    const class jumps_data_out_to_in_str &jumps_n , 
							    const class GSM_vector_helper_class &GSM_vector_helper_in ,
							    const unsigned int PSI_out_index , 
							    class array<bool> &are_PSI_in_indices_accepted_n_tab , 
							    bool &is_there_calc);
 
    void are_PSI_in_indices_accepted_pp_nn_fill_symmetric_case (
								const class jumps_data_out_to_in_str &jumps_mu , 
								const class GSM_vector_helper_class &GSM_vector_helper_in ,
								const unsigned int PSI_out_index ,  
								class array<bool> &are_PSI_in_indices_accepted_tab ,
								bool &is_there_calc);
    
    void are_PSI_in_indices_accepted_PSI_in_indices_p_fill_symmetric_case (
									   const unsigned int BPn , 
									   const int Sn ,
									   const int n_spec_n ,     
									   const int n_holes_n ,  
									   const int n_scat_n , 
									   const unsigned int iCn , 
									   const int iMn , 
									   const unsigned int SDn_index , 
									   const int En_hw , 
									   const class jumps_data_out_to_in_str &jumps_p , 
									   const class GSM_vector_helper_class &GSM_vector_helper_in , 
									   const unsigned int dimension_SDn ,
									   const unsigned int PSI_out_index , 
									   class array<bool> &are_PSI_in_indices_accepted_p_tab ,
									   class array<unsigned int> &PSI_in_indices_p ,
									   bool &is_there_calc);
    
    void are_PSI_in_indices_accepted_PSI_in_indices_n_fill_symmetric_case (
									   const unsigned int BPp , 
									   const int Sp ,
									   const int n_spec_p ,
									   const int n_holes_p , 
									   const int n_scat_p , 
									   const unsigned int iCp , 
									   const int iMp , 
									   const unsigned int SDp_index , 
									   const int Ep_hw , 
									   const class jumps_data_out_to_in_str &jumps_n , 
									   const class GSM_vector_helper_class &GSM_vector_helper_in ,
									   const unsigned int PSI_out_index , 
									   class array<bool> &are_PSI_in_indices_accepted_n_tab , 
									   class array<unsigned int> &PSI_in_indices_n ,
									   bool &is_there_calc);
 
    void are_PSI_in_indices_accepted_PSI_in_indices_pp_nn_fill_symmetric_case (
									       const class jumps_data_out_to_in_str &jumps_mu , 
									       const class GSM_vector_helper_class &GSM_vector_helper_in ,
									       const unsigned int PSI_out_index , 
									       class array<bool> &are_PSI_in_indices_accepted_tab , 
									       class array<unsigned int> &PSI_in_indices ,
									       bool &is_there_calc);
    
    void are_PSI_in_indices_accepted_PSI_in_indices_p_fill (
							    const unsigned int BPn , 
							    const int Sn ,
							    const int n_spec_n ,     
							    const int n_holes_n , 
							    const int n_scat_n , 
							    const unsigned int iCn , 
							    const int iMn , 
							    const unsigned int SDn_index , 
							    const int En_hw , 
							    const class jumps_data_out_to_in_str &jumps_p , 
							    const class GSM_vector_helper_class &GSM_vector_helper_in , 
							    const unsigned int dimension_SDn ,
							    class array<bool> &are_PSI_in_indices_accepted_p_tab ,
							    class array<unsigned int> &PSI_in_indices_p ,
							    bool &is_there_calc);
 
    void are_PSI_in_indices_accepted_PSI_in_indices_n_fill (
							    const unsigned int BPp ,  
							    const int Sp ,
							    const int n_spec_p ,    
							    const int n_holes_p ,  
							    const int n_scat_p , 
							    const unsigned int iCp , 
							    const int iMp , 
							    const unsigned int SDp_index , 
							    const int Ep_hw , 
							    const class jumps_data_out_to_in_str &jumps_n , 
							    const class GSM_vector_helper_class &GSM_vector_helper_in ,
							    class array<bool> &are_PSI_in_indices_accepted_n_tab , 
							    class array<unsigned int> &PSI_in_indices_n ,
							    bool &is_there_calc);
 
    void are_PSI_in_indices_accepted_PSI_in_indices_pp_nn_fill (
								const class jumps_data_out_to_in_str &jumps_mu , 
								const class GSM_vector_helper_class &GSM_vector_helper_in ,
								class array<bool> &are_PSI_in_indices_accepted_tab , 
								class array<unsigned int> &PSI_in_indices ,
								bool &is_there_calc);
 
    void total_PSI_in_indices_p_fill_Jpm (
					  const unsigned int SDn_index ,
					  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in ,
					  const class jumps_data_out_to_in_str &one_jump_p , 
					  const class GSM_vector_helper_class &GSM_vector_helper_in ,
					  const unsigned int dimension_SDn ,
					  class array<unsigned long int> &total_PSI_in_indices_p ,
					  bool &is_there_calc);

    void total_PSI_in_indices_n_fill_Jpm (
					  const unsigned int SDp_index , 
					  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in ,
					  const unsigned int dimension_inSDn ,
					  const class jumps_data_out_to_in_str &one_jump_n , 
					  const class GSM_vector_helper_class &GSM_vector_helper_in ,
					  class array<unsigned long int> &total_PSI_in_indices_n ,
					  bool &is_there_calc);

    void total_PSI_in_indices_pp_nn_fill_Jpm (			      
					      const unsigned long int sum_dimensions_configuration_fixed_in ,
					      const class jumps_data_out_to_in_str &one_jump_mu , 
					      const class GSM_vector_helper_class &GSM_vector_helper_in ,
					      class array<unsigned long int> &total_PSI_in_indices ,
					      bool &is_there_calc);
 
    void PSI_in_indices_p_fill_Jpm (
				    const unsigned int SDn_index , 							      
				    const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in ,
				    const class jumps_data_out_to_in_str &one_jump_p , 
				    const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in ,
				    const unsigned int dimension_SDn ,
				    class array<unsigned int> &PSI_in_indices_p ,
				    bool &is_there_calc);

    void PSI_in_indices_n_fill_Jpm (
				    const unsigned int SDp_index , 							      
				    const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in ,
				    const unsigned int dimension_inSDn ,
				    const class jumps_data_out_to_in_str &one_jump_n , 
				    const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in ,
				    class array<unsigned int> &PSI_in_indices_n ,
				    bool &is_there_calc);

    void PSI_in_indices_pp_nn_fill_Jpm (			      
					const unsigned int sum_dimensions_configuration_fixed_in ,
					const class jumps_data_out_to_in_str &one_jump_mu , 
					const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in ,
					class array<unsigned int> &PSI_in_indices ,
					bool &is_there_calc);    
  }
}

#endif


