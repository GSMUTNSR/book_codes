#ifndef GSMT2CLASS_H
#define GSMT2CLASS_H

// TYPE is double or complex
// -------------------------

class T2_class
{
public:

  T2_class ();
  
  T2_class (
	    const bool configuration_SD_1ph_tables_to_recalculate_c , 
	    const double J_c , 
	    const bool is_cv_possible_c ,
	    class GSM_vector_helper_class &GSM_vector_helper_hybrid_1D_2D , 
	    class GSM_vector_helper_class &GSM_vector_helper_2D_occupied , 
	    class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied ,  
	    class GSM_vector &PSI_in_2D_occupied ,
	    class GSM_vector &PSI_in_2D_unoccupied ,
	    class GSM_vector &T2_PSI_in_2D_off_diagonal ,
	    class GSM_vector &T2_PSI_in_2D_off_diagonal_unoccupied);

  T2_class (const class T2_class &X);
  
  ~T2_class ();
  
  void allocate (
		 const bool configuration_SD_1ph_tables_to_recalculate_c , 
		 const double J_c , 
		 const bool is_cv_possible_c ,
		 class GSM_vector_helper_class &GSM_vector_helper_hybrid_1D_2D , 
		 class GSM_vector_helper_class &GSM_vector_helper_2D_occupied , 
		 class GSM_vector_helper_class &GSM_vector_helper_2D_unoccupied , 
		 class GSM_vector &PSI_in_2D_occupied ,
		 class GSM_vector &PSI_in_2D_unoccupied ,
		 class GSM_vector &T2_PSI_in_2D_off_diagonal ,
		 class GSM_vector &T2_PSI_in_2D_off_diagonal_unoccupied);

  void allocate_fill (const class T2_class &X);

  void deallocate ();

  void apply_add (
		  const class GSM_vector &PSI_in , 
		  const TYPE &alpha , 
		  class GSM_vector &PSI_out) const;

  double T_coupling_precision_calc (
				    const class GSM_vector &PSI , 
				    const double T , 
				    class GSM_vector &PSI_test) const;

  class GSM_vector_helper_class & get_GSM_vector_helper_hybrid_1D_2D () const
  {
    return *GSM_vector_helper_hybrid_1D_2D_ptr;
  }
  
  class GSM_vector_helper_class & get_GSM_vector_helper_hybrid_1D_2D ()
  {
    return *GSM_vector_helper_hybrid_1D_2D_ptr;
  }

  class GSM_vector_helper_class & get_GSM_vector_helper_2D_occupied () const
  {
    return *GSM_vector_helper_2D_occupied_ptr;
  }
  
  class GSM_vector_helper_class & get_GSM_vector_helper_2D_occupied ()
  {
    return *GSM_vector_helper_2D_occupied_ptr;
  }
  
  class GSM_vector_helper_class & get_GSM_vector_helper_2D_unoccupied () const
  {
    return *GSM_vector_helper_2D_unoccupied_ptr;
  }
    
  class GSM_vector_helper_class & get_GSM_vector_helper_2D_unoccupied ()
  {
    return *GSM_vector_helper_2D_unoccupied_ptr;
  }
  
  class GSM_vector & get_PSI_in_2D_occupied () const
  {
    return *PSI_in_2D_occupied_ptr;
  }
    
  class GSM_vector & get_PSI_in_2D_occupied ()
  {
    return *PSI_in_2D_occupied_ptr;
  }
  
  class GSM_vector & get_PSI_in_2D_unoccupied () const
  {
    return *PSI_in_2D_unoccupied_ptr;
  }
  
  class GSM_vector & get_PSI_in_2D_unoccupied ()
  {
    return *PSI_in_2D_unoccupied_ptr;
  }
    
  class GSM_vector & get_T2_PSI_in_2D_off_diagonal () const
  {
    return *T2_PSI_in_2D_off_diagonal_ptr;
  }
  
  class GSM_vector & get_T2_PSI_in_2D_off_diagonal_unoccupied () const
  {
    return *T2_PSI_in_2D_off_diagonal_unoccupied_ptr;
  }
  
  class GSM_vector & get_T2_PSI_in_2D_off_diagonal_unoccupied ()
  {
    return *T2_PSI_in_2D_off_diagonal_unoccupied_ptr;
  }
  
  bool is_it_filled () const
  {
    return (GSM_vector_helper_2D_occupied_ptr != NULL);
  }

  friend double used_memory_calc (const class T2_class &T);
  
private:

  void diagonal_part_pp_nn_calc_store ();
  
  void diagonal_part_pn_Nval_larger_calc_store ();
  
  void diagonal_part_pn_Zval_larger_calc_store ();
  
  void two_jumps_pn_part_pn_Nval_larger_calc (const unsigned int occupied_squares_index) const;
  void two_jumps_pn_part_pn_Zval_larger_calc (const unsigned int occupied_squares_index) const;
  
  void two_jumps_cv_part_pn_Nval_larger_calc (const bool is_it_cv_pp_to_nn , const unsigned int occupied_squares_index) const;
  void two_jumps_cv_part_pn_Zval_larger_calc (const bool is_it_cv_pp_to_nn , const unsigned int occupied_squares_index) const;
 
  bool configuration_SD_1ph_tables_to_recalculate; // true if one has to recalculate the a+ or a matrix elements between SDs to apply the T^2 operator, false if not
  
  double J; // total angular momentum of the considered many body wave function
  
  bool is_cv_possible; // true if pp <-> nn conversions exist in the considered hypernucleus, false if not
  
  class GSM_vector_helper_class *GSM_vector_helper_hybrid_1D_2D_ptr;  // pointer to data necessary to handle |Psi> stored in a hybrid 1D/2D format, i.e. with distribution over all nodes. It does not contain its vector components.
  
  class GSM_vector_helper_class *GSM_vector_helper_2D_occupied_ptr;   // pointer to data necessary to handle |Psi> stored in 2D format, i.e. with distribution over row master nodes only in   occupied squares. It does not contain its vector components.
  class GSM_vector_helper_class *GSM_vector_helper_2D_unoccupied_ptr; // pointer to data necessary to handle |Psi> stored in 2D format, i.e. with distribution over row master nodes only in unoccupied squares. It does not contain its vector components.
  
  class GSM_vector *PSI_in_2D_occupied_ptr;   // pointer to |Psi-in> stored in 2D format, i.e. with distribution over row master nodes only in   occupied squares.
  class GSM_vector *PSI_in_2D_unoccupied_ptr; // pointer to |Psi-in> stored in 2D format, i.e. with distribution over row master nodes only in unoccupied squares.
  
  class GSM_vector *T2_PSI_in_2D_off_diagonal_ptr;            // pointer to H|Psi-in> stored in 2D format, i.e. with distribution over row master nodes only in off-diagonal squares.
  class GSM_vector *T2_PSI_in_2D_off_diagonal_unoccupied_ptr; // pointer to H|Psi-in> stored in 2D format, i.e. with distribution over row master nodes only in off-diagonal unoccupied squares.
  
  // One-body matrix elements of t- t+, and t+, t- from charged baryon to uncharged baryon
  
  class array<int> Tminus_Tplus_OBMEs_p_tab;
  class array<int> Tminus_Tplus_OBMEs_n_tab;
  
  class array<double> Tminus_OBMEs_pn_tab;
    
  class array<double> Tplus_OBMEs_pn_tab;
  
  class array<bool> are_Tminus_OBMEs_pn_non_zero_tab;

  class array<bool> are_Tplus_OBMEs_pn_non_zero_tab;
  
  class array<TYPE> T2_diagonal_tab; // diagonal NBMEs of T^2
};







class xT2_plus_alpha_str
{
public:

  const TYPE x , alpha;
  const class T2_class &T2;

  xT2_plus_alpha_str (const TYPE &x_c , const TYPE &alpha_c , const class T2_class &T2_c);
};

class xT2_plus_alpha_str operator + (const class T2_class &T2);
class xT2_plus_alpha_str operator - (const class T2_class &T2);

class xT2_plus_alpha_str operator + (const class T2_class &T2 , const double term);
class xT2_plus_alpha_str operator - (const class T2_class &T2 , const double term);

class xT2_plus_alpha_str operator + (const double term , const class T2_class &T2);
class xT2_plus_alpha_str operator - (const double term , const class T2_class &T2);

class xT2_plus_alpha_str operator * (const class T2_class &T2 , const double x);
class xT2_plus_alpha_str operator * (const double x , const class T2_class &T2);
class xT2_plus_alpha_str operator / (const class T2_class &T2 , const double x);

class xT2_plus_alpha_str operator + (const class xT2_plus_alpha_str &Op);
class xT2_plus_alpha_str operator - (const class xT2_plus_alpha_str &Op);

class xT2_plus_alpha_str operator + (const class xT2_plus_alpha_str &Op , const double term);
class xT2_plus_alpha_str operator - (const class xT2_plus_alpha_str &Op , const double term);

class xT2_plus_alpha_str operator + (const double alpha , const class xT2_plus_alpha_str &Op);
class xT2_plus_alpha_str operator - (const double alpha , const class xT2_plus_alpha_str &Op);

class xT2_plus_alpha_str operator * (const class xT2_plus_alpha_str &Op , const double factor);
class xT2_plus_alpha_str operator / (const class xT2_plus_alpha_str &Op , const double factor);
class xT2_plus_alpha_str operator * (const double factor , const class xT2_plus_alpha_str &Op);

class xT2_plus_alpha_str operator + (const class T2_class &T2 , const complex<double> &term);
class xT2_plus_alpha_str operator - (const class T2_class &T2 , const complex<double> &term);

class xT2_plus_alpha_str operator + (const complex<double> &term , const class T2_class &T2);
class xT2_plus_alpha_str operator - (const complex<double> &term , const class T2_class &T2);

class xT2_plus_alpha_str operator * (const class T2_class &T2 , const complex<double> &x);
class xT2_plus_alpha_str operator * (const complex<double> &x , const class T2_class &T2);
class xT2_plus_alpha_str operator / (const class T2_class &T2 , const complex<double> &x);

class xT2_plus_alpha_str operator + (const class xT2_plus_alpha_str &Op , const complex<double> &term);
class xT2_plus_alpha_str operator - (const class xT2_plus_alpha_str &Op , const complex<double> &term);

class xT2_plus_alpha_str operator + (const complex<double> &alpha , const class xT2_plus_alpha_str &Op);
class xT2_plus_alpha_str operator - (const complex<double> &alpha , const class xT2_plus_alpha_str &Op);

class xT2_plus_alpha_str operator * (const class xT2_plus_alpha_str &Op , const complex<double> &factor);
class xT2_plus_alpha_str operator / (const class xT2_plus_alpha_str &Op , const complex<double> &factor);
class xT2_plus_alpha_str operator * (const complex<double> &factor , const class xT2_plus_alpha_str &Op);

class xT2_plus_alpha_str operator + (const class xT2_plus_alpha_str &Op_a , const class xT2_plus_alpha_str &Op_b);
class xT2_plus_alpha_str operator - (const class xT2_plus_alpha_str &Op_a , const class xT2_plus_alpha_str &Op_b);

#endif

