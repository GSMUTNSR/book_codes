#include "../GSM_include/GSM_include_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


enum called_code_type called_code = TWO_PARTICLE_CODE;


using namespace inputs_misc;



#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    print_array_vector_test_status<int> ();

    //--// dummy variables
    class array<double> dummy_array_double;
    class array<string> dummy_array_string;
    class array<class input_data_str> dummy_input_data_tab;
    class input_data_str dummy_input_data;
    
    const class array <class array<class JT_coupled_TBME> > dummy_array_JT_coupled_TBME;

    //================================== input data and nucleons data ==================================//
    
    //--// initialization of the class which contains all input values and some pointers on tables (not all initialized here)
    class input_data_str input_data;
    call_common_routines::input_data_read_MPI_transfer (dummy_array_double , dummy_array_double , dummy_array_string , input_data , dummy_input_data , dummy_input_data_tab);

    //--// initialization of the classes which contain information on protons and neutrons
    class nucleons_data prot_data , neut_data;
    nucleons_data_initialization (false , input_data , prot_data , neut_data);
    
    //================================== basis interaction and HF potentials ==================================//
    
    //--// class which contains information on the interaction for the basis

    class interaction_class inter_data_basis (true , true , false , input_data);
    inter_data_basis.inter_data_calc (input_data);

    const enum potential_type basis_potential = input_data.get_basis_potential ();
    
    if (basis_potential == MSDHF) error_message_print_abort ("No MSDHF potential in GSM_main_OCM_basis_only.cpp");
    
    class HF_nucleons_data prot_HF_data(input_data , prot_data);
    class HF_nucleons_data neut_HF_data(input_data , neut_data);
  
    HF_potentials::potentials_shells_OBMEs_realloc_calc (true , input_data , inter_data_basis , prot_HF_data , neut_HF_data , prot_data , neut_data);
        
    Berggren_basis::single_particle_indices_radial_wfs_prot_neut_alloc_calc (true , input_data , prot_data , neut_data);

    HO_GHF_overlaps_prot_neut_alloc_calc (true , input_data , prot_data , neut_data);
    
    if (THIS_PROCESS == MASTER_PROCESS) radial_wfs_HF_data_HO_overlaps_basis_prot_neut_copy_disk (input_data , prot_data , neut_data);

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
    
    return 0;
  }


