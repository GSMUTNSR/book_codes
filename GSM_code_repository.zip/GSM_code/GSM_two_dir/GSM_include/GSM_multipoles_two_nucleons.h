#ifndef GSMMULTIPOLES_H
#define GSMMULTIPOLES_H


// TYPE is double or complex
// -------------------------

namespace GSM_multipoles
{
  TYPE OBME_pp_nn_part_calc (
			     const int J ,
			     const int L ,
			     const bool is_it_HO_expansion ,
			     const class nucleons_data &data ,
			     const class pair_str &pair_in , 
			     const class pair_str &pair_out);

  TYPE OBME_pn_part_calc (
			  const int L ,
			  const bool is_it_HO_expansion ,
			  const class nucleons_data &prot_data ,
			  const class nucleons_data &neut_data ,
			  const class pair_str &pair_in , 
			  const class pair_str &pair_out);

  TYPE OBME_part_calc (
		       const enum space_type space ,
		       const int J ,
		       const int L ,
		       const bool is_it_HO_expansion ,
		       const class nucleons_data &prot_data ,
		       const class nucleons_data &neut_data ,
		       const class pair_str &pair_in , 
		       const class pair_str &pair_out);
 
  TYPE TBME_part_calc (
		       const enum space_type space ,
		       const int L ,
		       const bool is_it_HO_expansion ,
		       const class nucleons_data &prot_data ,
		       const class nucleons_data &neut_data ,
		       const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
		       const class pair_str &pair_in , 
		       const class pair_str &pair_out);

  TYPE multipole_ME_calc_one_pair (
				   const int L ,
				   const bool is_it_HO_expansion ,
				   const class GSM_vector_two_nucleons &PSI_in , 
				   const class GSM_vector_two_nucleons &PSI_out);

  void calc_print (
		   const class input_data_str &input_data , 
		   const class nucleons_data &prot_data , 
		   const class nucleons_data &neut_data , 
		   const class array<class correlated_state_str> &PSI_qn_tab);
}

#endif







