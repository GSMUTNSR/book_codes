#ifndef GSMRMSRADIUSONEBODYSTRENGTH_H
#define GSMRMSRADIUSONEBODYSTRENGTH_H

// TYPE is double or complex
// -------------------------

namespace rms_radius_one_body_strength
{
  void calc_one_strength (
			  const enum operator_type rms_radius_op , 
			  const bool is_it_Gauss_Legendre ,
			  const class GSM_vector_two_nucleons &PSI_IN , 
			  const class GSM_vector_two_nucleons &PSI_OUT , 
			  class array<TYPE> &rms_radius_one_body_strength_tab);

  void calc_store_one_strength (
				const enum operator_type rms_radius_op ,
				const bool is_it_Gauss_Legendre ,
				const class array<double> &r_bef_R_tab ,
				const class correlated_state_str &PSI_qn , 
				const class GSM_vector_two_nucleons &PSI);

  void calc_store (
		   const class input_data_str &input_data , 
		   const class nucleons_data &prot_data , 
		   const class nucleons_data &neut_data , 
		   const class array<class correlated_state_str> &PSI_qn_tab);
}

#endif
