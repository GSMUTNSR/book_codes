#ifndef GSMEIGENVECTORFUNCTIONS_H
#define GSMEIGENVECTORFUNCTIONS_H

// TYPE is double or complex
// -------------------------

namespace eigenvector_functions
{
  void changing_eigensets_bool_tables_calc (
					    const class input_data_str &input_data , 
					    class array<bool> &is_it_new_J_Pi_tab);

  void write_expectation_values (
				 const class input_data_str &input_data , 
				 const class GSM_vector_two_nucleons &PSI , 
				 const class T2_class &T2 , 
				 const class H_class &H , 
				 const class GSM_vector_helper_class_two_nucleons &PSI_helper , 
				 const class correlated_state_str &PSI_qn);

  void find_eigenvector_starting_point (
					const bool vectors_write , 
					const class input_data_str &input_data , 
					const class array<unsigned long int> &GSM_dimensions , 
					const class GSM_vector_helper_class_two_nucleons &GSM_vector_two_nucleons_helper , 
					const unsigned int eigenset_index , 
					const unsigned int eigenset_vectors_number , 
					const class TBMEs_class &TBMEs_pn , 
					class array<TYPE> &E_subspace_tab , 
					class array<class GSM_vector_two_nucleons> &eigenvector_subspace_tab , 
					class array<class correlated_state_str> &PSI_qn_tab);

  void find_eigenvector (
			 const class input_data_str &input_data , 
			 const class array<unsigned long int> &GSM_dimensions_pole_app , 
			 const class array<unsigned long int> &GSM_dimensions , 
			 const class GSM_vector_helper_class_two_nucleons &GSM_vector_two_nucleons_helper , 
			 const unsigned int eigenset_index , 
			 const unsigned int eigenset_vectors_number , 
			 const class TBMEs_class &TBMEs_pn , 
			 const class array<TYPE> &E_subspace_tab , 
			 const class array<class GSM_vector_two_nucleons> &eigenvector_subspace_tab , 
			 class array<class correlated_state_str> &PSI_qn_tab);
	
  void pole_approximation_eigenvectors_calc (
					     const class array<unsigned long int> &GSM_dimensions_pole_approximation , 
					     const class TBMEs_class &TBMEs_pn , 
					     const class input_data_str &input_data , 
					     class array<class correlated_state_str> &PSI_qn_tab ,
					     class nucleons_data &prot_data , 
					     class nucleons_data &neut_data , 
					     class array<unsigned int> &eigenset_vectors_indices ,  
					     class array<TYPE> &E_subspace_tab , 
					     class array<class GSM_vector_two_nucleons> &eigenvector_subspace_tab);
  void full_space_eigenvectors_calc (
				     const class array<unsigned long int> &GSM_dimensions_pole_approximation , 
				     const class array<unsigned long int> &GSM_dimensions , 
				     const class TBMEs_class &TBMEs_pn , 
				     const class input_data_str &input_data ,
				     const class array<TYPE> &E_subspace_tab ,  
				     const class array<class GSM_vector_two_nucleons> &eigenvector_subspace_tab ,
				     class nucleons_data &prot_data , 
				     class nucleons_data &neut_data , 
				     class array<unsigned int> &eigenset_vectors_indices ,  
				     class array<class correlated_state_str> &PSI_qn_tab);

  void eigenvectors_pole_approximation_full_space_calc (
							const class input_data_str &input_data ,
							const class array<unsigned long int> &GSM_dimensions_pole_approximation , 
							const class array<unsigned long int> &GSM_dimensions , 
							class TBMEs_class &TBMEs_pn , 
							class nucleons_data &prot_data , 
							class nucleons_data &neut_data ,
							class array<class correlated_state_str> &PSI_qn_tab);
}

#endif
