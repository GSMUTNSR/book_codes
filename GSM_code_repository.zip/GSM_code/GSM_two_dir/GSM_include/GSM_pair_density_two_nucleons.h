#ifndef GSMPAIRINGDENSITY_H
#define GSMPAIRINGDENSITY_H

// TYPE is double or complex
// -------------------------

namespace pair_density
{
  void densities_calc_one_state (
				 const bool is_it_radial ,
				 const bool is_it_Gauss_Legendre , 
				 const class GSM_vector_two_nucleons &PSI_IN ,
				 const class GSM_vector_two_nucleons &PSI_OUT , 
				 class array<TYPE> &density_tab);
 
  void calc_store_one_state (
			     const bool is_it_radial ,
			     const bool is_it_Gauss_Legendre , 
			     const class array<double> &rk_tab , 
			     const class correlated_state_str &PSI_qn ,
			     const class GSM_vector_two_nucleons &PSI);

  void calc_store (
		   const class input_data_str &input_data , 
		   const class nucleons_data &prot_data , 
		   const class nucleons_data &neut_data , 
		   const class array<class correlated_state_str> &PSI_qn_tab);
}

#endif
