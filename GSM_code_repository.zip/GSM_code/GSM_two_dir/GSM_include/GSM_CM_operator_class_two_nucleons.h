#ifndef GSMCMOPCLASS_H
#define GSMCMOPCLASS_H


// TYPE is double or complex
// -------------------------

class CM_operator_class
{ 
public:

  CM_operator_class ();
  
  CM_operator_class (
		     const enum operator_type CM_operator_inter_c , 
		     const bool is_it_HO_expansion_c , 
		     const class GSM_vector_helper_class_two_nucleons &GSM_vector_two_nucleons_helper_c);

  CM_operator_class (const class CM_operator_class &X);

  ~CM_operator_class ();

  void allocate (
		 const enum operator_type CM_operator_inter_c , 
		 const bool is_it_HO_expansion_c , 
		 const class GSM_vector_helper_class_two_nucleons &GSM_vector_two_nucleons_helper_c);

  void allocate_fill (const class CM_operator_class &X);

  void deallocate ();

  void apply_add (
		  const class GSM_vector_two_nucleons &PSI , 
		  const TYPE &alpha , 
		  class GSM_vector_two_nucleons &CM_operator_PSI) const;

  const class GSM_vector_helper_class_two_nucleons & get_GSM_vector_two_nucleons_helper () const
  {
    return *GSM_vector_two_nucleons_helper_ptr;
  }

  enum operator_type get_CM_operator_inter () const
  {
    return CM_operator_inter;
  }

  friend double used_memory_calc (const class CM_operator_class &T);
  
private:

  TYPE OBME_pp_nn_part_calc (
			     const enum space_type TBME_sspace ,
			     const class pair_str &pair_in , 
			     const class pair_str &pair_out) const;
  
  TYPE OBME_pn_part_calc (
			  const class pair_str &pair_in , 
			  const class pair_str &pair_out) const;
  
  TYPE OBME_part_calc (
		       const class pair_str &pair_in , 
		       const class pair_str &pair_out) const;

  TYPE TBME_part_calc (
		       const class pair_str &pair_in , 
		       const class pair_str &pair_out) const;

  const class GSM_vector_helper_class_two_nucleons *GSM_vector_two_nucleons_helper_ptr;
  
  enum operator_type CM_operator_inter; // type of considered CM operator (Hcm, P^2/2M ...)
  
  bool is_it_HO_expansion; // true if one uses HO expansion if the CM operator, false if one uses R cut, i.e. integration on [0:R] only

  class CM_TBMEs_angular_table_str TBMEs_angular_table; // class allowing to calculates the angular part of TBMEs 
};








class xCM_operator_plus_alpha_str
{
public:

  const TYPE x , alpha;
  const class CM_operator_class &CM_operator;

  xCM_operator_plus_alpha_str (const TYPE &x_c , const TYPE &alpha_c , const class CM_operator_class &CM_operator_c);
};


class xCM_operator_plus_alpha_str operator + (const class CM_operator_class &CM_operator);
class xCM_operator_plus_alpha_str operator - (const class CM_operator_class &CM_operator);

class xCM_operator_plus_alpha_str operator + (const class CM_operator_class &CM_operator , const double term);
class xCM_operator_plus_alpha_str operator - (const class CM_operator_class &CM_operator , const double term);

class xCM_operator_plus_alpha_str operator + (const double term , const class CM_operator_class &CM_operator);
class xCM_operator_plus_alpha_str operator - (const double term , const class CM_operator_class &CM_operator);

class xCM_operator_plus_alpha_str operator * (const class CM_operator_class &CM_operator , const double x);
class xCM_operator_plus_alpha_str operator * (const double x , const class CM_operator_class &CM_operator);
class xCM_operator_plus_alpha_str operator / (const class CM_operator_class &CM_operator , const double one_over_x);

class xCM_operator_plus_alpha_str operator + (const class xCM_operator_plus_alpha_str &Op);
class xCM_operator_plus_alpha_str operator - (const class xCM_operator_plus_alpha_str &Op);

class xCM_operator_plus_alpha_str operator + (const class xCM_operator_plus_alpha_str &Op , const double term);
class xCM_operator_plus_alpha_str operator - (const class xCM_operator_plus_alpha_str &Op , const double term);

class xCM_operator_plus_alpha_str operator + (const double alpha , const class xCM_operator_plus_alpha_str &Op);
class xCM_operator_plus_alpha_str operator - (const double alpha , const class xCM_operator_plus_alpha_str &Op);

class xCM_operator_plus_alpha_str operator * (const class xCM_operator_plus_alpha_str &Op , const double factor);
class xCM_operator_plus_alpha_str operator / (const class xCM_operator_plus_alpha_str &Op , const double factor);
class xCM_operator_plus_alpha_str operator * (const double factor , const class xCM_operator_plus_alpha_str &Op);

class xCM_operator_plus_alpha_str operator + (const class CM_operator_class &CM_operator , const complex<double> &term);
class xCM_operator_plus_alpha_str operator - (const class CM_operator_class &CM_operator , const complex<double> &term);

class xCM_operator_plus_alpha_str operator + (const complex<double> &term , const class CM_operator_class &CM_operator);
class xCM_operator_plus_alpha_str operator - (const complex<double> &term , const class CM_operator_class &CM_operator);

class xCM_operator_plus_alpha_str operator * (const class CM_operator_class &CM_operator , const complex<double> &x);
class xCM_operator_plus_alpha_str operator * (const complex<double> &x , const class CM_operator_class &CM_operator);
class xCM_operator_plus_alpha_str operator / (const class CM_operator_class &CM_operator , const complex<double> &one_over_x);

class xCM_operator_plus_alpha_str operator + (const class xCM_operator_plus_alpha_str &Op , const complex<double> &term);
class xCM_operator_plus_alpha_str operator - (const class xCM_operator_plus_alpha_str &Op , const complex<double> &term);

class xCM_operator_plus_alpha_str operator + (const complex<double> &alpha , const class xCM_operator_plus_alpha_str &Op);
class xCM_operator_plus_alpha_str operator - (const complex<double> &alpha , const class xCM_operator_plus_alpha_str &Op);

class xCM_operator_plus_alpha_str operator * (const class xCM_operator_plus_alpha_str &Op , const complex<double> &factor);
class xCM_operator_plus_alpha_str operator / (const class xCM_operator_plus_alpha_str &Op , const complex<double> &factor);
class xCM_operator_plus_alpha_str operator * (const complex<double> &factor , const class xCM_operator_plus_alpha_str &Op);


#endif
