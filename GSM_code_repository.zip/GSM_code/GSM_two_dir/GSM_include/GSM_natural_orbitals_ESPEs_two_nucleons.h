#ifndef GSMNATURALORBITALSESPES_H
#define GSMNATURALORBITALSESPES_H

// TYPE is double or complex
// -------------------------

namespace natural_orbitals_ESPEs
{
  void calc_print (
		   const bool are_there_ESPEs ,
		   const class input_data_str &input_data , 
		   const class TBMEs_class &TBMEs_pn ,  
		   class nucleons_data &prot_data ,
		   class nucleons_data &neut_data);
}

#endif
