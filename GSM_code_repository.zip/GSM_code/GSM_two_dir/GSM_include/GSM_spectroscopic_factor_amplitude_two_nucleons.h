#ifndef GSMSPECTROSCOPICAMPLITUDE_H
#define GSMSPECTROSCOPICAMPLITUDE_H

// TYPE is double or complex
// -------------------------

namespace spectroscopic_factor_amplitude
{
  class nlj_struct target_qn_determine (
					const class baryons_data &prot_Y_data , 
					const class baryons_data &neut_Y_data , 
					const unsigned int BP , 
					const double J , 
					const unsigned int vector_index , 
					const enum particle_type particle_target);

  int nmax_SF_calc (
		    const enum particle_type particle_SF ,
		    const int l_SF ,
		    const double j_SF ,
		    const class array<class nlj_struct> &shells_qn_SF);

  unsigned int shell_index_SF_calc (
				    const class nlj_struct &shell_qn_SF ,
				    const class array<class nlj_struct> &shells_qn_SF);

  unsigned int target_state_basis_dimension_calc (
						  const enum particle_type particle_target ,
						  const int lt ,
						  const double jt ,
						  const class array<class nlj_struct> &shells_qn_target);
  
  void target_state_n_indices_calc (
				    const enum particle_type particle_target ,
				    const int lt ,
				    const double jt ,
				    const class array<class nlj_struct> &shells_qn_target , 
				    class array<unsigned int> &n_indices);
 
  void target_state_basis_components_calc (
					   const enum interaction_type inter , 
					   const enum particle_type particle_target ,
					   const class baryons_data &data_target , 
					   const class nlj_struct &target_qn , 
					   class vector_class<TYPE> &target_vector);

  void calc (
	     const enum space_type space , 
	     const enum interaction_type inter , 
	     const enum particle_type particle_target , 
	     const class nlj_struct &target_qn , 
	     const enum particle_type particle_SF ,
	     const int l_SF ,
	     const double j_SF , 
	     const class GSM_vector_two_nucleons &PSI , 
	     class array<TYPE> &spectroscopic_factor_amplitude_tab);
}


#endif
