#ifndef GSMBETATRANSITIONS_H
#define GSMBETATRANSITIONS_H

// TYPE is double or complex
// -------------------------

namespace beta_transitions
{
  TYPE beta_minus_NBME_nn_pn_calc (
				   const int rank_Op , 
				   const class array<TYPE> &OBMEs , 
				   const class correlated_state_str &PSI_IN_qn , 
				   const class correlated_state_str &PSI_OUT_qn , 
				   const class GSM_vector_two_nucleons &PSI_OUT);

  TYPE beta_plus_NBME_pp_pn_calc (
				  const int rank_Op , 
				  const class array<TYPE> &OBMEs , 
				  const class correlated_state_str &PSI_IN_qn , 
				  const class correlated_state_str &PSI_OUT_qn , 
				  const class GSM_vector_two_nucleons &PSI_OUT);

  void beta_suboperator_NBME_calc (
				   const enum beta_pm_type beta_pm , 
				   const bool is_it_HO_expansion , 
				   const enum radial_operator_type radial_operator , 
				   const enum beta_suboperator_type beta_suboperator , 
				   const class interaction_class &inter_data , 
				   const class correlated_state_str &PSI_IN_qn , 
				   const class correlated_state_str &PSI_OUT_qn , 
				   const class GSM_vector_two_nucleons &PSI_OUT , 
				   class array<TYPE> &beta_suboperators_NBMEs);
	
  void beta_suboperators_NBMEs_calc (
				     const enum beta_type beta , 
				     const enum beta_pm_type beta_pm , 
				     const bool is_it_HO_expansion , 
				     const class interaction_class &inter_data , 
				     const class correlated_state_str &PSI_IN_qn ,  
				     const class correlated_state_str &PSI_OUT_qn ,  
				     const class GSM_vector_two_nucleons &PSI_OUT , 
				     class array<TYPE> &beta_suboperators_NBMEs);
	
  void calc_print (
		   const input_data_str &input_data , 
		   const class interaction_class &inter_data , 
		   const class nucleons_data &prot_data , 
		   const class nucleons_data &neut_data , 
		   const class array<class correlated_state_str> &PSI_qn_tab);
}

#endif
