#ifndef GSMOVERLAPFUNCTION_H
#define GSMOVERLAPFUNCTION_H

// TYPE is double or complex
// -------------------------

namespace overlap_function
{
  void calc (
	     const enum space_type space , 
	     const enum interaction_type inter , 
	     const enum particle_type target_type , 
	     const class nlj_struct &target_qn , 
	     const int l_SF , 
	     const double j_SF ,
	     const bool is_it_Gauss_Legendre ,
	     const class GSM_vector_two_nucleons &PSI , 
	     class array<TYPE> &overlap_function_tab);

  void calc_store (const class input_data_str &input_data , 
		   const class nucleons_data &prot_data , 
		   const class nucleons_data &neut_data , 
		   const class array<class correlated_state_str> &PSI_qn_tab);
}


#endif
