#ifndef GSMSCALARSTRENGTH_H
#define GSMSCALARSTRENGTH_H

// TYPE is double or complex
// -------------------------

namespace scalar_strength
{
  void OBME_pp_nn_part_tab_calc (
				 const class baryons_data &data , 
				 const class array<TYPE> &OBMEs , 
				 const int J , 
				 const class pair_str &pair_in , 
				 const class pair_str &pair_out , 
				 class array<TYPE> &OBME_part_tab);

  void OBME_pn_part_tabs_calc (
			       const class array<TYPE> &OBMEs_prot , 
			       const class array<TYPE> &OBMEs_neut , 
			       const class pair_str &pair_in , 
			       const class pair_str &pair_out , 
			       class array<TYPE> &OBME_part_p_tab ,
			       class array<TYPE> &OBME_part_n_tab);

  void OBME_part_tabs_calc (
			    const enum space_type space , 
			    const int J , 
			    const class baryons_data &prot_Y_data , 
			    const class baryons_data &neut_Y_data , 
			    const class array<TYPE> &OBMEs_p , 
			    const class array<TYPE> &OBMEs_n , 
			    const class pair_str &pair_in , 
			    const class pair_str &pair_out , 
			    class array<TYPE> &OBME_part_p_tab ,
			    class array<TYPE> &OBME_part_n_tab);

  void calc (
	     const class array<TYPE> &OBMEs_p , 
	     const class array<TYPE> &OBMEs_n , 
	     const class GSM_vector_two_nucleons &PSI_IN , 
	     const class GSM_vector_two_nucleons &PSI_OUT , 
	     class array<TYPE> &scalar_strength_p_tab , 
	     class array<TYPE> &scalar_strength_n_tab);
}

#endif
