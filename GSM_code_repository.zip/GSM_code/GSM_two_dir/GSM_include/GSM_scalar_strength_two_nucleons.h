#ifndef GSMSCALARSTRENGTH_H
#define GSMSCALARSTRENGTH_H

// TYPE is double or complex
// -------------------------

namespace scalar_strength
{
  void OBME_pp_nn_part_table_calc (
				   const class nucleons_data &data , 
				   const class array<TYPE> &OBMEs , 
				   const int J , 
				   const class pair_str &pair_in , 
				   const class pair_str &pair_out , 
				   class array<TYPE> &OBME_part_table);

  void OBME_pn_part_table_calc (
				const class array<TYPE> &OBMEs_prot , 
				const class array<TYPE> &OBMEs_neut , 
				const class pair_str &pair_in , 
				const class pair_str &pair_out , 
				class array<TYPE> &OBME_part_table);

  void OBME_part_table_calc (
			     const enum space_type space , 
			     const int J , 
			     const class nucleons_data &prot_data , 
			     const class nucleons_data &neut_data , 
			     const class array<TYPE> &OBMEs_prot , 
			     const class array<TYPE> &OBMEs_neut , 
			     const class pair_str &pair_in , 
			     const class pair_str &pair_out , 
			     class array<TYPE> &OBME_part_table);

  void calc (
	     const class array<TYPE> &OBMEs_prot , 
	     const class array<TYPE> &OBMEs_neut , 
	     const class GSM_vector_two_nucleons &PSI_IN , 
	     const class GSM_vector_two_nucleons &PSI_OUT , 
	     class array<TYPE> &scalar_strength_tab);
}

#endif
