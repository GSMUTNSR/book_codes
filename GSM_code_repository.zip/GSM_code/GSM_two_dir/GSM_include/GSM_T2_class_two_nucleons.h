#ifndef GSMT2CLASS_H
#define GSMT2CLASS_H

// TYPE is double or complex
// -------------------------

class T2_class
{
public:

  T2_class ();
  
  T2_class (const class GSM_vector_helper_class_two_nucleons &GSM_vector_two_nucleons_helper);

  explicit T2_class (const class T2_class &X);

  ~T2_class ();

  void initialize (const class GSM_vector_helper_class_two_nucleons &GSM_vector_two_nucleons_helper);

  void initialize (const class T2_class &X);
  
  void apply_add (
		  const class GSM_vector_two_nucleons &PSI_in , 
		  const TYPE &alpha , 
		  class GSM_vector_two_nucleons &PSI_out) const;

  const class GSM_vector_helper_class_two_nucleons & get_GSM_vector_two_nucleons_helper () const
  {
    return *GSM_vector_two_nucleons_helper_ptr;
  }

  friend double used_memory_calc (const class T2_class &T);
  
private: 

  const class GSM_vector_helper_class_two_nucleons *GSM_vector_two_nucleons_helper_ptr; // pointer to data necessary to handle |Psi[in]> and |Psi[out]>. It does not contain their vector components.
};



class xT2_plus_alpha_str
{
public:

  const TYPE x , alpha;
  const class T2_class &T2;

  xT2_plus_alpha_str (const TYPE &x_c , const TYPE &alpha_c , const class T2_class &T2_c);
};

class xT2_plus_alpha_str operator + (const class T2_class &T2);
class xT2_plus_alpha_str operator - (const class T2_class &T2);

class xT2_plus_alpha_str operator + (const class T2_class &T2 , const double term);
class xT2_plus_alpha_str operator - (const class T2_class &T2 , const double term);

class xT2_plus_alpha_str operator + (const double term , const class T2_class &T2);
class xT2_plus_alpha_str operator - (const double term , const class T2_class &T2);

class xT2_plus_alpha_str operator * (const class T2_class &T2 , const double x);
class xT2_plus_alpha_str operator * (const double x , const class T2_class &T2);
class xT2_plus_alpha_str operator / (const class T2_class &T2 , const double one_over_x);

class xT2_plus_alpha_str operator + (const class xT2_plus_alpha_str &Op);
class xT2_plus_alpha_str operator - (const class xT2_plus_alpha_str &Op);

class xT2_plus_alpha_str operator + (const class xT2_plus_alpha_str &Op , const double term);
class xT2_plus_alpha_str operator - (const class xT2_plus_alpha_str &Op , const double term);

class xT2_plus_alpha_str operator + (const double alpha , const class xT2_plus_alpha_str &Op);
class xT2_plus_alpha_str operator - (const double alpha , const class xT2_plus_alpha_str &Op);

class xT2_plus_alpha_str operator * (const class xT2_plus_alpha_str &Op , const double factor);
class xT2_plus_alpha_str operator / (const class xT2_plus_alpha_str &Op , const double factor);
class xT2_plus_alpha_str operator * (const double factor , const class xT2_plus_alpha_str &Op);

class xT2_plus_alpha_str operator + (const class T2_class &T2 , const complex<double> &term);
class xT2_plus_alpha_str operator - (const class T2_class &T2 , const complex<double> &term);

class xT2_plus_alpha_str operator + (const complex<double> &term , const class T2_class &T2);
class xT2_plus_alpha_str operator - (const complex<double> &term , const class T2_class &T2);

class xT2_plus_alpha_str operator * (const class T2_class &T2 , const complex<double> &x);
class xT2_plus_alpha_str operator * (const complex<double> &x , const class T2_class &T2);
class xT2_plus_alpha_str operator / (const class T2_class &T2 , const complex<double> &one_over_x);

class xT2_plus_alpha_str operator + (const class xT2_plus_alpha_str &Op , const complex<double> &term);
class xT2_plus_alpha_str operator - (const class xT2_plus_alpha_str &Op , const complex<double> &term);

class xT2_plus_alpha_str operator + (const complex<double> &alpha , const class xT2_plus_alpha_str &Op);
class xT2_plus_alpha_str operator - (const complex<double> &alpha , const class xT2_plus_alpha_str &Op);

class xT2_plus_alpha_str operator * (const class xT2_plus_alpha_str &Op , const complex<double> &factor);
class xT2_plus_alpha_str operator / (const class xT2_plus_alpha_str &Op , const complex<double> &factor);
class xT2_plus_alpha_str operator * (const complex<double> &factor , const class xT2_plus_alpha_str &Op);


#endif
