#ifndef GSMDAVIDSON_H
#define GSMDAVIDSON_H

// TYPE is double or complex
// -------------------------

namespace Davidson_GSM
{
  void H_app_minus_E_inverse_apply (
				    const class H_class &H , 
				    const TYPE &E , 
				    const unsigned int subspace_dimension, 
				    const class array<TYPE> &E_subspace_tab , 
				    const class array<class GSM_vector_two_nucleons> &eigenvector_subspace_tab , 
				    const class GSM_vector_two_nucleons &PSI , 
				    class GSM_vector_two_nucleons &Res_subspace , 
				    class GSM_vector_two_nucleons &H_app_minus_E_inverse_Res_subspace , 
				    class GSM_vector_two_nucleons &H_app_minus_E_inverse_PSI);

  void new_Davidson_vector_alloc_calc (
				       const bool is_there_cout_detailed , 
				       const class H_class &H , 
				       const unsigned int i , 
				       const TYPE &E , 
				       const unsigned int subspace_dimension, 
				       const class array<TYPE> &E_subspace_tab , 
				       const class array<class GSM_vector_two_nucleons> &eigenvector_subspace_tab , 
				       const class GSM_vector_two_nucleons &Res ,  
				       class GSM_vector_two_nucleons &Res_subspace , 
				       class array<class GSM_vector_two_nucleons> &V_tab , 
				       class GSM_vector_two_nucleons &H_app_minus_E_inverse_Res_subspace , 
				       class GSM_vector_two_nucleons &Vstore);

  void Davidson_matrix_calc (
			     const class input_data_str &input_data , 
			     const class H_class &H , 
			     const class correlated_state_str &PSI_qn , 
			     const unsigned int subspace_dimension, 
			     const class array<TYPE> &E_subspace_tab , 
			     const class array<class GSM_vector_two_nucleons> &eigenvector_subspace_tab , 
			     class GSM_vector_two_nucleons &Res_subspace , 
			     class GSM_vector_two_nucleons &H_app_minus_E_inverse_Res_subspace , 
			     class GSM_vector_two_nucleons &Res , 
			     class GSM_vector_two_nucleons &Vstore , 
			     class array<class GSM_vector_two_nucleons> &V_tab , 
			     class array<class GSM_vector_two_nucleons> &HV_tab ,
			     class matrix<TYPE> &Davidson , 
			     unsigned int &Davidson_dimension, 
			     double &test);

  void Davidson_Res_test (
			  const bool print_detailed_information ,
			  const unsigned int Davidson_dimension, 
			  const class matrix<TYPE> &Davidson ,  
			  const class array<class GSM_vector_two_nucleons> &V_tab ,
			  const class array<class GSM_vector_two_nucleons> &HV_tab , 
			  class GSM_vector_two_nucleons &Res , 
			  TYPE &E_tilde ,
			  double &test);

  void largest_overlap_eigenvector_calc_store_write_expectation_values (
									const class input_data_str &input_data , 
									const class T2_class &T2 , 
									const class H_class &H , 
									const unsigned int Davidson_dimension , 
									const class matrix<TYPE> &Davidson ,
									const class array<class GSM_vector_two_nucleons> &V_tab , 
									const bool are_PSI_expectation_values_written ,  
									const class GSM_vector_helper_class_two_nucleons &GSM_vector_two_nucleons_helper , 
									class correlated_state_str &PSI_qn , 
									class GSM_vector_two_nucleons &PSI);

  void iterative_diagonalization_largest_overlap (
						  const class input_data_str &input_data , 
						  const class GSM_vector_helper_class_two_nucleons &GSM_vector_two_nucleons_helper , 
						  const unsigned int Davidson_max_dimension, 
						  const class H_class &H , 
						  const unsigned int subspace_dimension, 
						  const class array<TYPE> &E_subspace_tab , 
						  const class array<class GSM_vector_two_nucleons> &eigenvector_subspace_tab , 
						  class GSM_vector_two_nucleons &Res_subspace , 
						  class GSM_vector_two_nucleons &H_app_minus_E_inverse_Res_subspace , 
						  class correlated_state_str &PSI_qn);
}

#endif


