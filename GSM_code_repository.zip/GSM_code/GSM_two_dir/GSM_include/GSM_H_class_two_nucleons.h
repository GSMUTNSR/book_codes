#ifndef GSMHCLASS_H
#define GSMHCLASS_H

// TYPE is double or complex
// -------------------------

class H_class
{
public:
  
  H_class ();
  
  H_class (
	   const bool print_detailed_information_c , 
	   const class GSM_vector_helper_class_two_nucleons &GSM_vector_two_nucleons_helper ,
	   const class TBMEs_class &TBMEs_pn ,
	   const class TBMEs_class &TBMEs_cv);

  H_class (const class H_class &X);

  void initialize (
		   const bool print_detailed_information_c , 
		   const class GSM_vector_helper_class_two_nucleons &GSM_vector_two_nucleons_helper ,
		   const class TBMEs_class &TBMEs_pn ,
		   const class TBMEs_class &TBMEs_cv);

  void initialize (const class H_class &X);
  
  void allocate_fill (const class H_class &X);
  
  void deallocate ();

  void print () const;
		
  TYPE operator () (const class pair_str &pair_in , const class pair_str &pair_out) const;

  double non_zero_NBMEs_proportion_calc() const;

  void apply_add (
		  const class GSM_vector_two_nucleons &PSI_in , 
		  const TYPE &alpha , 
		  class GSM_vector_two_nucleons &PSI_out) const;

  const class GSM_vector_helper_class_two_nucleons & get_GSM_vector_two_nucleons_helper () const
  {
    return *GSM_vector_two_nucleons_helper_ptr;
  }
  
  const class TBMEs_class & get_TBMEs () const;

  friend double used_memory_calc (const class H_class &T);
  
private:

  TYPE OBME_pp_nn_part_calc (
			     const enum space_type TBME_space ,
			     const class pair_str &pair_in ,
			     const class pair_str &pair_out) const;

  TYPE OBME_pn_part_calc (
			  const class pair_str &pair_in ,
			  const class pair_str &pair_out) const;

  TYPE OBME_part_calc (
		       const class pair_str &pair_in ,
		       const class pair_str &pair_out) const;

  const class TBMEs_class & get_TBMEs_pn () const
  {
    return *TBMEs_pn_ptr;
  }

  const class TBMEs_class & get_TBMEs_cv () const
  {
    return *TBMEs_cv_ptr;
  }

  bool print_detailed_information; // true if one prints all information about memory and time on screen, false if the most impostant information and one prints only results
  
  const class GSM_vector_helper_class_two_nucleons *GSM_vector_two_nucleons_helper_ptr; // pointer to data necessary to handle |Psi[in]> and |Psi[out]>. It does not contain their vector components.
  
  const class TBMEs_class *TBMEs_pn_ptr; // pointer to class containing coupled pn TBMEs
  const class TBMEs_class *TBMEs_cv_ptr; // pointer to class containing coupled pp <-> nn conversion TBMEs
};






class xH_plus_alpha_str
{
public:

  const TYPE x;

  const TYPE alpha;

  const class H_class &H;

  xH_plus_alpha_str (const TYPE &x_c , const TYPE &alpha_c , const class H_class &H_c);
};


class xH_plus_alpha_str operator + (const class H_class &H);
class xH_plus_alpha_str operator - (const class H_class &H);

class xH_plus_alpha_str operator + (const class H_class &H , const double term);
class xH_plus_alpha_str operator - (const class H_class &H , const double term);

class xH_plus_alpha_str operator + (const double term , const class H_class &H);
class xH_plus_alpha_str operator - (const double term , const class H_class &H);

class xH_plus_alpha_str operator * (const class H_class &H , const double x);
class xH_plus_alpha_str operator * (const double x , const class H_class &H);
class xH_plus_alpha_str operator / (const class H_class &H , const double one_over_x);

class xH_plus_alpha_str operator + (const class xH_plus_alpha_str &Op);
class xH_plus_alpha_str operator - (const class xH_plus_alpha_str &Op);

class xH_plus_alpha_str operator + (const class xH_plus_alpha_str &Op , const double term);
class xH_plus_alpha_str operator - (const class xH_plus_alpha_str &Op , const double term);

class xH_plus_alpha_str operator + (const double alpha , const class xH_plus_alpha_str &Op);
class xH_plus_alpha_str operator - (const double alpha , const class xH_plus_alpha_str &Op);

class xH_plus_alpha_str operator * (const class xH_plus_alpha_str &Op , const double factor);
class xH_plus_alpha_str operator / (const class xH_plus_alpha_str &Op , const double factor);
class xH_plus_alpha_str operator * (const double factor , const class xH_plus_alpha_str &Op);

class xH_plus_alpha_str operator + (const class H_class &H , const complex<double> &term);
class xH_plus_alpha_str operator - (const class H_class &H , const complex<double> &term);

class xH_plus_alpha_str operator + (const complex<double> &term , const class H_class &H);
class xH_plus_alpha_str operator - (const complex<double> &term , const class H_class &H);

class xH_plus_alpha_str operator * (const class H_class &H , const complex<double> &x);
class xH_plus_alpha_str operator * (const complex<double> &x , const class H_class &H);
class xH_plus_alpha_str operator / (const class H_class &H , const complex<double> &one_over_x);

class xH_plus_alpha_str operator + (const class xH_plus_alpha_str &Op , const complex<double> &term);
class xH_plus_alpha_str operator - (const class xH_plus_alpha_str &Op , const complex<double> &term);

class xH_plus_alpha_str operator + (const complex<double> &alpha , const class xH_plus_alpha_str &Op);
class xH_plus_alpha_str operator - (const complex<double> &alpha , const class xH_plus_alpha_str &Op);

class xH_plus_alpha_str operator * (const class xH_plus_alpha_str &Op , const complex<double> &factor);
class xH_plus_alpha_str operator / (const class xH_plus_alpha_str &Op , const complex<double> &factor);
class xH_plus_alpha_str operator * (const complex<double> &factor , const class xH_plus_alpha_str &Op);


#endif
