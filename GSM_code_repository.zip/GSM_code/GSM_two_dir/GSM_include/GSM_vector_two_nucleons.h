#ifndef GSMVECTORTWONUCLEONS_H
#define GSMVECTORTWONUCLEONS_H

// TYPE is double or complex
// -------------------------

class GSM_vector_two_nucleons
{
public:

  GSM_vector_two_nucleons ();
  
  explicit GSM_vector_two_nucleons (const class GSM_vector_helper_class_two_nucleons &GSM_vector_two_nucleons_helper);

  GSM_vector_two_nucleons (const class GSM_vector_two_nucleons &V);
  GSM_vector_two_nucleons (const class Op_PSI_closure_two_nucleons_str &);

  ~GSM_vector_two_nucleons ();

  void allocate (const class GSM_vector_helper_class_two_nucleons &GSM_vector_two_nucleons_helper);

  void allocate_fill (const class GSM_vector_two_nucleons &V);
  void allocate_calc (const class Op_PSI_closure_two_nucleons_str &closure);

  void deallocate ();

  bool is_it_filled () const
  {
    return (table != NULL);
  }

  unsigned int get_space_dimension () const
  {
    return space_dimension;
  }
  
  const class GSM_vector_two_nucleons & operator = (const class GSM_vector_two_nucleons &);
  const class GSM_vector_two_nucleons & operator = (const complex<double> &x);
  const class GSM_vector_two_nucleons & operator = (const double x);
  const class GSM_vector_two_nucleons & operator = (const class Op_PSI_closure_two_nucleons_str &);

  class GSM_vector_two_nucleons & operator += (const class GSM_vector_two_nucleons &);
  class GSM_vector_two_nucleons & operator += (const TYPE &x);
  class GSM_vector_two_nucleons & operator += (const class Op_PSI_closure_two_nucleons_str &);

  class GSM_vector_two_nucleons & operator -= (const class GSM_vector_two_nucleons &);
  class GSM_vector_two_nucleons & operator -= (const TYPE &x);
  class GSM_vector_two_nucleons & operator -= (const class Op_PSI_closure_two_nucleons_str &);

  class GSM_vector_two_nucleons & operator *= (const TYPE &x);
  class GSM_vector_two_nucleons & operator /= (const TYPE &x);

  TYPE & operator () (const class pair_str &pair) const;

  inline TYPE & operator [] (const unsigned int i) const
  {
    return table[i];
  }

  double infinite_norm () const;
  bool equality_numerical (const class GSM_vector_two_nucleons &PSI , const double precision_local) const;
  void normalization ();
  void random_vector ();
  void pseudo_random_vector ();

  void print () const;

  void opposite ();

  void good_phase ();

  void configuration_occupation_print (const bool are_scattering_configuration_probabilities_printed , const double configuration_precision) const;
		
  void assign (const class GSM_vector_two_nucleons &PSI);

  TYPE average_n_scat_calc () const;

  void eigenvector_copy_disk (const class correlated_state_str &PSI_qn) const;
  void space_dimension_eigenvector_copy_disk (const class correlated_state_str &PSI_qn) const;
  void space_dimension_pairs_components_eigenvector_copy_disk (const class correlated_state_str &PSI_qn) const;
  void pairs_components_eigenvector_copy_disk (const class correlated_state_str &PSI_qn) const;
  
  void eigenvector_good_T_copy_disk (const class correlated_state_str &PSI_qn) const;
  void space_dimension_eigenvector_good_T_copy_disk (const class correlated_state_str &PSI_qn) const;
  void space_dimension_pairs_components_eigenvector_good_T_copy_disk (const class correlated_state_str &PSI_qn) const;
  void pairs_components_eigenvector_good_T_copy_disk (const class correlated_state_str &PSI_qn) const;
  
  void copy_disk (const string &file_name) const;
  void copy_disk_indexed_name (const string &file_name_debut , const unsigned int index) const;
  void space_dimension_copy_disk (const string &space_dimension_file_name) const;
  void pairs_components_copy_disk (const string &space_dimension_file_name) const;
  void space_dimension_pairs_components_copy_disk (const string &space_dimension_file_name , const string &file_name) const;

  void eigenvector_read_disk (const class correlated_state_str &PSI_qn);
  void pairs_components_eigenvector_read_disk (const class correlated_state_str &PSI_qn);
  
  void eigenvector_good_T_read_disk (const class correlated_state_str &PSI_qn);
  void pairs_components_eigenvector_good_T_read_disk (const class correlated_state_str &PSI_qn);
  
  void read_disk (const string &file_name);
  void read_disk_indexed_name (const string &file_name_debut , const unsigned int index);
  void pairs_components_read_disk (const string &space_dimension_file_name , const string &file_name);

  void pivot_init (
		   const bool initial_pivot_from_file , 
		   const class correlated_state_str &Pivot_qn);
  
  void pivot_init (
		   const bool initial_pivot_from_file , 
		   const unsigned int eigenset_index ,
		   const unsigned int eigenset_vectors_number ,
		   const class array<class correlated_state_str> &PSI_qn_tab ,
		   class GSM_vector_two_nucleons &Vstore);
 
  class pair_str basis_pair_from_index (const unsigned int i) const;

  friend double used_memory_calc (const class GSM_vector_two_nucleons &T);

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const;
  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const;
  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const;

#ifdef UseMPI
  void MPI_simple_Send_Receive (
				const unsigned int Send_process ,
				const unsigned int Recv_process ,
				const unsigned int process ,
				const int tag ,
				const MPI_Comm MPI_C);
		
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void MPI_Reduce (const MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  void MPI_Allreduce (const MPI_Op op , const MPI_Comm MPI_C);
#endif

  const class GSM_vector_helper_class_two_nucleons & get_GSM_vector_two_nucleons_helper () const
  {
    return *GSM_vector_two_nucleons_helper_ptr;
  }
  
  TYPE sum () const;
  
private:

  unsigned int space_dimension;
  
  const class GSM_vector_helper_class_two_nucleons *GSM_vector_two_nucleons_helper_ptr;
  
  TYPE *table;
};



TYPE operator* (const class GSM_vector_two_nucleons &X , const class GSM_vector_two_nucleons &Y);

istream & operator >> (istream &is , class GSM_vector_two_nucleons &PSI);
ostream & operator << (ostream &os , const class GSM_vector_two_nucleons &PSI);

void orthogonalization (
			const bool is_there_cout , 
			const unsigned int i , 
			class array<class GSM_vector_two_nucleons> &V_tab);




void pairs_left_right_indices_PSI_components_read_from_file (
							     const string &file_name , 
							     class array<unsigned int> &pairs_left_right_indices , 
							     class array<TYPE > &PSI_component_tab);




class Op_PSI_closure_two_nucleons_str
{
public:

  Op_PSI_closure_two_nucleons_str (const unsigned int closure_terms_number_c);
  Op_PSI_closure_two_nucleons_str (const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure_old);
  Op_PSI_closure_two_nucleons_str (const class GSM_vector_two_nucleons &);

  bool is_it_filled () const
  {
    return (PSI_in_ptrs[0] != NULL);
  }
  
  const class Op_PSI_closure_two_nucleons_str & operator = (const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure);

  unsigned int get_closure_terms_number () const;
  enum operator_type get_Op (const unsigned int index) const;
  TYPE get_x (const unsigned int index) const;
  TYPE get_alpha (const unsigned int index) const;

  const class H_class & get_H (const unsigned int index) const;
  const class T2_class & get_T2 (const unsigned int index) const;
  const class CM_operator_class & get_CM_operator (const unsigned int index) const;
  const class GSM_vector_two_nucleons & get_PSI_in (const unsigned int index) const;

  void default_values_init ();

  void fill_data (
		  const enum operator_type Op , 
		  const TYPE x , 
		  const TYPE alpha , 
		  const void *const Op_ptr , 
		  const class GSM_vector_two_nucleons *const PSI_in_ptr , 
		  const unsigned int index);

  void fill_data (
		  const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure , 
		  const unsigned int i , 
		  const unsigned int index);

  bool is_it_only_scalar_identity () const;

  void sign_change (const unsigned int index);

  void global_sign_change ();

  void factor_multiplication (const unsigned int index , const TYPE &factor);
	
  void global_factor_multiplication (const TYPE &factor);

  const class GSM_vector_helper_class_two_nucleons & GSM_vector_two_nucleons_helper_determine () const;

  bool is_PSI_out_used (const class GSM_vector_two_nucleons &PSI_out) const;

  void all_Op_PSI_in_calc_add (class GSM_vector_two_nucleons &PSI_out) const;

  class Op_PSI_closure_two_nucleons_str operator_times_scalar_identity (
									const enum operator_type Op , 
									const TYPE x_Op , 
									const TYPE alpha_Op ,  
									const void *const Op_ptr) const;


private:

  unsigned int closure_terms_number;

  enum operator_type Op_tab[CLOSURE_TERMS_MAX];

  TYPE x_tab[CLOSURE_TERMS_MAX] , alpha_tab[CLOSURE_TERMS_MAX];

  const void * Op_ptrs[CLOSURE_TERMS_MAX];
  const class GSM_vector_two_nucleons * PSI_in_ptrs[CLOSURE_TERMS_MAX];
};

class Op_PSI_closure_two_nucleons_str operator * (const class H_class &H , const class GSM_vector_two_nucleons &PSI_in);
class Op_PSI_closure_two_nucleons_str operator * (const class T2_class &T2 , const class GSM_vector_two_nucleons &PSI_in);
class Op_PSI_closure_two_nucleons_str operator * (const class CM_operator_class &CM_operator , const class GSM_vector_two_nucleons &PSI_in);

class Op_PSI_closure_two_nucleons_str operator * (const class xH_plus_alpha_str &xH_plus_alpha , const class GSM_vector_two_nucleons &PSI_in);
class Op_PSI_closure_two_nucleons_str operator * (const class xT2_plus_alpha_str &xT2_plus_alpha , const class GSM_vector_two_nucleons &PSI_in);
class Op_PSI_closure_two_nucleons_str operator * (const class xCM_operator_plus_alpha_str &xCM_operator_plus_alpha , const class GSM_vector_two_nucleons &PSI_in);

class Op_PSI_closure_two_nucleons_str operator * (const class H_class &H , const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure);
class Op_PSI_closure_two_nucleons_str operator * (const class T2_class &T2 , const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure);
class Op_PSI_closure_two_nucleons_str operator * (const class CM_operator_class &CM_operator , const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure);

class Op_PSI_closure_two_nucleons_str operator * (const class xH_plus_alpha_str &xH_plus_alpha , const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure);
class Op_PSI_closure_two_nucleons_str operator * (const class xT2_plus_alpha_str &xT2_plus_alpha , const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure);
class Op_PSI_closure_two_nucleons_str operator * (const class xCM_operator_plus_alpha_str &xCM_operator_plus_alpha , const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure);

class Op_PSI_closure_two_nucleons_str operator + (const class GSM_vector_two_nucleons &PSI_in);
class Op_PSI_closure_two_nucleons_str operator - (const class GSM_vector_two_nucleons &PSI_in);
class Op_PSI_closure_two_nucleons_str operator * (const TYPE &alpha , const class GSM_vector_two_nucleons &PSI_in);
class Op_PSI_closure_two_nucleons_str operator * (const class GSM_vector_two_nucleons &PSI_in , const TYPE &alpha);
class Op_PSI_closure_two_nucleons_str operator / (const class GSM_vector_two_nucleons &PSI_in , const TYPE &alpha);

class Op_PSI_closure_two_nucleons_str operator + (const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure);
class Op_PSI_closure_two_nucleons_str operator - (const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure);
class Op_PSI_closure_two_nucleons_str operator * (const TYPE &factor , const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure);
class Op_PSI_closure_two_nucleons_str operator * (const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure , const TYPE &factor);
class Op_PSI_closure_two_nucleons_str operator / (const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure , const TYPE &factor);

class Op_PSI_closure_two_nucleons_str Op_PSI_closure_add (
							  const int sign , 
							  const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure_a , 
							  const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure_b);

class Op_PSI_closure_two_nucleons_str operator + (const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure_a , const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure_b);
class Op_PSI_closure_two_nucleons_str operator - (const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure_a , const class Op_PSI_closure_two_nucleons_str &Op_PSI_closure_b);

#endif


