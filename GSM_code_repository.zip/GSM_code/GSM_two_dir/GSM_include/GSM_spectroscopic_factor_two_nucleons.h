#ifndef GSMSPECTROSCOPICFACTOR_H
#define GSMSPECTROSCOPICFACTOR_H

// TYPE is double or complex
// -------------------------

namespace spectroscopic_factor
{
  TYPE calc (
	     const enum space_type space , 
	     const enum interaction_type inter , 
	     const enum particle_type target_type , 
	     const class nlj_struct &target_qn , 
	     const int l_SF ,
	     const double j_SF , 
	     const class GSM_vector_two_nucleons &PSI);

  void calc_print (
		   const class input_data_str &input_data , 
		   const class nucleons_data &prot_data , 
		   const class nucleons_data &neut_data , 
		   const class array<class correlated_state_str> &PSI_qn_tab);
}

#endif
