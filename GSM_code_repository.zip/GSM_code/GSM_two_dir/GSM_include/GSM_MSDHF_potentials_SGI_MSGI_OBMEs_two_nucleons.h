#ifndef GSMMSDHFPOTENTIALSGIMSGIOBMES_H
#define GSMMSDHFPOTENTIALSGIMSGIOBMES_H

// TYPE is double or complex
// -------------------------

namespace MSDHF_potentials_SGI_MSGI_OBMEs
{
  complex<double> prot_OBME_HF_pp_subpart_calc (
						const int J , 
						const double pair_weight , 
						const class spherical_state &shell_prot_in , 
						const class spherical_state &shell_prot_out , 
						const class spherical_state &shell_prot_occ , 
						const class interaction_class &inter_data , 
						const class array<double> &Gaussian_table_GL , 
						const class multipolar_expansion_str &multipolar_expansion);

  complex<double> prot_OBME_HF_pn_subpart_calc (
						const int J , 
						const class spherical_state &shell_prot_in , 
						const class spherical_state &shell_prot_out , 
						const class spherical_state &shell_neut_occ , 
						const class interaction_class &inter_data , 
						const class array<double> &Gaussian_table_GL , 
						const class multipolar_expansion_str &multipolar_expansion);

  complex<double> prot_OBME_HF_pp_part_calc (
					     const class spherical_state &shell_prot_HF_in , 
					     const class spherical_state &shell_prot_HF_out , 
					     const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
					     const class interaction_class &inter_data , 
					     const class array<double> &Gaussian_table_GL , 
					     const class multipolar_expansion_str &multipolar_expansion , 
					     const class HF_nucleons_data &prot_HF_data);

  complex<double> prot_OBME_HF_pn_part_calc (
					     const class spherical_state &shell_prot_HF_in , 
					     const class spherical_state &shell_prot_HF_out , 
					     const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
					     const class interaction_class &inter_data , 
					     const class array<double> &Gaussian_table_GL , 
					     const class multipolar_expansion_str &multipolar_expansion , 
					     const class HF_nucleons_data &prot_HF_data , 
					     const class HF_nucleons_data &neut_HF_data);

  complex<double> prot_OBME_HF_calc (
				     const class spherical_state &shell_prot_in , 
				     const class spherical_state &shell_prot_out , 
				     const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
				     const class interaction_class &inter_data , 
				     const class array<double> &Gaussian_table_GL , 
				     const class multipolar_expansion_str &multipolar_expansion , 
				     const class HF_nucleons_data &prot_HF_data , 
				     const class HF_nucleons_data &neut_HF_data);

  complex<double> neut_OBME_HF_nn_subpart_calc (
						const int J , 
						const double pair_weight , 
						const class spherical_state &shell_neut_in , 
						const class spherical_state &shell_neut_out , 
						const class spherical_state &shell_neut_occ , 
						const class interaction_class &inter_data , 
						const class array<double> &Gaussian_table_GL , 
						const class multipolar_expansion_str &multipolar_expansion);

  complex<double> neut_OBME_HF_pn_subpart_calc (const int J , 
						const class spherical_state &shell_neut_in , 
						const class spherical_state &shell_neut_out , 
						const class spherical_state &shell_prot_occ , 
						const class interaction_class &inter_data , 
						const class array<double> &Gaussian_table_GL , 
						const class multipolar_expansion_str &multipolar_expansion);

  complex<double> neut_OBME_HF_nn_part_calc (
					     const class spherical_state &shell_neut_HF_in , 
					     const class spherical_state &shell_neut_HF_out , 
					     const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
					     const class interaction_class &inter_data , 
					     const class array<double> &Gaussian_table_GL , 
					     const class multipolar_expansion_str &multipolar_expansion , 
					     const class HF_nucleons_data &neut_HF_data);

  complex<double> neut_OBME_HF_pn_part_calc (
					     const class spherical_state &shell_neut_HF_in , 
					     const class spherical_state &shell_neut_HF_out , 
					     const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
					     const class interaction_class &inter_data , 
					     const class array<double> &Gaussian_table_GL , 
					     const class multipolar_expansion_str &multipolar_expansion , 
					     const class HF_nucleons_data &prot_HF_data , 
					     const class HF_nucleons_data &neut_HF_data);

  complex<double> neut_OBME_HF_calc (
				     const class spherical_state &shell_neut_in , 
				     const class spherical_state &shell_neut_out , 
				     const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
				     const class interaction_class &inter_data , 
				     const class array<double> &Gaussian_table_GL , 
				     const class multipolar_expansion_str &multipolar_expansion , 
				     const class HF_nucleons_data &prot_HF_data , 
				     const class HF_nucleons_data &neut_HF_data);

  void prot_OBMEs_HF_calc (
			   const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
			   const class interaction_class &inter_data , 
			   const class array<double> &Gaussian_table_GL , 
			   const class multipolar_expansion_str &multipolar_expansion , 
			   const class HF_nucleons_data &neut_HF_data , 
			   class HF_nucleons_data &prot_HF_data);

  void neut_OBMEs_HF_calc (
			   const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
			   const class interaction_class &inter_data , 
			   const class array<double> &Gaussian_table_GL , 
			   const class multipolar_expansion_str &multipolar_expansion , 
			   const class HF_nucleons_data &prot_HF_data , 
			   class HF_nucleons_data &neut_HF_data);
}

#endif
