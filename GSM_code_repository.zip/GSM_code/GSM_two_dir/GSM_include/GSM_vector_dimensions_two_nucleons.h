#ifndef GSMVECTORDIMENSIONSTWONUCLEONS_H
#define GSMVECTORDIMENSIONSTWONUCLEONS_H

// TYPE is double or complex
// -------------------------

namespace GSM_vector_dimensions_two_nucleons
{
  bool is_basis_state_in_space (
				const bool truncation_hw , 
				const bool truncation_ph , 
				const int n_scat , 
				const int E_hw , 
				const int n_scat_max , 
				const int E_max_hw);

  unsigned int space_dimension_calc (
				     const enum space_type space , 
				     const bool truncation_hw , 
				     const bool truncation_ph , 
				     const int n_scat_max , 
				     const int E_max_hw , 
				     const unsigned int BP ,
				     const int J , 
				     const class baryons_data &prot_Y_data , 
				     const class baryons_data &neut_Y_data);

  void GSM_dimensions_calc_print (
				  const bool is_it_pole_approximation , 
				  const class input_data_str &input_data , 
				  const class baryons_data &prot_Y_data , 
				  const class baryons_data &neut_Y_data , 
				  class array<unsigned long int> &GSM_dimensions);
  
  void all_GSM_dimensions_calc_print (
				      const class input_data_str &input_data , 
				      const class baryons_data &prot_Y_data , 
				      const class baryons_data &neut_Y_data , 
				      class array<unsigned long int> &GSM_dimensions_pole_approximation , 
				      class array<unsigned long int> &GSM_dimensions);
}

#endif







