#ifndef GSMSCALARDENSITYMATRIX_H
#define GSMSCALARDENSITYMATRIX_H

// TYPE is double or complex
// -------------------------

namespace scalar_density_matrix
{
  double ME_pp_nn_calc (
			const class baryons_data &data , 
			const int J , 
			const class pair_str &pair_ab , 
			const class pair_str &pair_in , 
			const class pair_str &pair_out);

  double ME_pn_p_calc (
		       const class pair_str &pair_p_ab , 
		       const class pair_str &pair_in , 
		       const class pair_str &pair_out);
 
  double ME_pn_n_calc (
		       const class pair_str &pair_n_ab , 
		       const class pair_str &pair_in , 
		       const class pair_str &pair_out);
 
  double ME_calc (
		  const enum space_type space ,
		  const class baryons_data &data , 
		  const int J , 
		  const class pair_str &pair_ab , 
		  const class pair_str &pair_in , 
		  const class pair_str &pair_out);

  bool non_zero_ME_condition (
			      const enum space_type space ,
			      const class baryons_data &data , 
			      const enum particle_type particle ,
			      const unsigned int s ,
			      const class pair_str &basis_pair);
 
  void fixed_in_out_basis_states_part_calc (
					    const enum space_type space ,
					    const int J ,
					    const class pair_str &pair_in , 
					    const class pair_str &pair_out ,
					    const TYPE &PSI_in_out_components_product ,
					    const class baryons_data &data ,
					    class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_tab_fixed_basis_state_out);

  void pp_nn_calc (
		   const class GSM_vector_two_nucleons &PSI ,
		   const class baryons_data &data ,
		   class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_tab);

  void pn_calc (
		const class GSM_vector_two_nucleons &PSI ,
		const class baryons_data &prot_Y_data ,
		const class baryons_data &neut_Y_data ,
		class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_p_tab ,
		class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_n_tab);
  
  void cv_calc (
		const class GSM_vector_two_nucleons &PSI ,
		const class baryons_data &prot_Y_data ,
		const class baryons_data &neut_Y_data ,
		class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_p_tab ,
		class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_n_tab);
  
  void calc (
	     const enum space_type space , 
	     const class GSM_vector_two_nucleons &PSI ,
	     const class baryons_data &prot_Y_data ,
	     const class baryons_data &neut_Y_data ,
	     class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_p_tab ,
	     class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_n_tab);
}

#endif





