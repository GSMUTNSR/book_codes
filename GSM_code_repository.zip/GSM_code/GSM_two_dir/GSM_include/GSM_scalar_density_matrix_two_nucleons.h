#ifndef GSMSCALARDENSITYMATRIX_H
#define GSMSCALARDENSITYMATRIX_H

// TYPE is double or complex
// -------------------------

namespace scalar_density_matrix
{
  double ME_pp_nn_calc (
			const class nucleons_data &data , 
			const int J , 
			const class pair_str &pair_ab , 
			const class pair_str &pair_in , 
			const class pair_str &pair_out);

  double ME_pn_prot_calc (
			  const class pair_str &pair_prot_ab , 
			  const class pair_str &pair_in , 
			  const class pair_str &pair_out);
 
  double ME_pn_neut_calc (
			  const class pair_str &pair_neut_ab , 
			  const class pair_str &pair_in , 
			  const class pair_str &pair_out);
 
  double ME_calc (
		  const enum space_type space ,
		  const class nucleons_data &data , 
		  const int J , 
		  const class pair_str &pair_ab , 
		  const class pair_str &pair_in , 
		  const class pair_str &pair_out);

  bool non_zero_ME_condition (
			      const enum space_type space ,
			      const class nucleons_data &data , 
			      const unsigned int s ,
			      const class pair_str &basis_pair);
 
  void fixed_in_out_basis_states_part_calc (
					    const enum space_type space ,
					    const int J ,
					    const class pair_str &pair_in , 
					    const class pair_str &pair_out ,
					    const TYPE &PSI_in_out_components_product ,
					    const class nucleons_data &data ,
					    class lj_table<class matrix<TYPE> > &scalar_density_matrices_fixed_basis_state_out);

  void pp_nn_calc (
		   const class GSM_vector_two_nucleons &PSI ,
		   const class nucleons_data &data ,
		   class lj_table<class matrix<TYPE> > &scalar_density_matrices);

  void pn_calc (
		const class GSM_vector_two_nucleons &PSI ,
		const class nucleons_data &prot_data ,
		const class nucleons_data &neut_data ,
		class lj_table<class matrix<TYPE> > &prot_scalar_density_matrices ,
		class lj_table<class matrix<TYPE> > &neut_scalar_density_matrices);
  
  void calc (
	     const enum space_type space , 
	     const class GSM_vector_two_nucleons &PSI ,
	     const class nucleons_data &prot_data ,
	     const class nucleons_data &neut_data ,
	     class lj_table<class matrix<TYPE> > &prot_scalar_density_matrices ,
	     class lj_table<class matrix<TYPE> > &neut_scalar_density_matrices);
}

#endif





