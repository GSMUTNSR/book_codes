#ifndef GSMVECTORHELPERCLASSTWONUCLEONS_H
#define GSMVECTORHELPERCLASSTWONUCLEONS_H

// TYPE is double or complex
// -------------------------

class GSM_vector_helper_class_two_nucleons
{
public:
  
  GSM_vector_helper_class_two_nucleons ();
  
  GSM_vector_helper_class_two_nucleons (
					const enum space_type space_c , 
					const enum interaction_type inter_c ,
					const bool truncation_hw_c , 
					const bool truncation_ph_c , 
					const int n_scat_max_c , 
					const int E_max_hw_c , 
					const int n_scat_max_p_c ,
					const int Ep_max_hw_c , 
					const int n_scat_max_n_c , 
					const int En_max_hw_c , 
					const class nucleons_data &prot_data_c , 
					const class nucleons_data &neut_data_c , 
					const unsigned int BP_c , 
					const int J_c);

  GSM_vector_helper_class_two_nucleons (const class GSM_vector_helper_class_two_nucleons &X);
  
  ~GSM_vector_helper_class_two_nucleons ();

  void allocate (
		 const enum space_type space_c , 
		 const enum interaction_type inter_c ,
		 const bool truncation_hw_c , 
		 const bool truncation_ph_c , 
		 const int n_scat_max_c , 
		 const int E_max_hw_c , 
		 const int n_scat_max_p_c ,
		 const int Ep_max_hw_c , 
		 const int n_scat_max_n_c , 
		 const int En_max_hw_c , 
		 const class nucleons_data &prot_data , 
		 const class nucleons_data &neut_data , 
		 const unsigned int BP_c , 
		 const int J_c);

  void allocate_fill (const class GSM_vector_helper_class_two_nucleons &X);
  
  void deallocate ();

  enum space_type get_space () const
  {
    return space;
  }
  
  enum interaction_type get_inter () const
  {
    return inter;
  }
  
  bool get_truncation_hw () const
  {
    return truncation_hw;
  }
  
  bool get_truncation_ph () const
  {
    return truncation_ph;
  }
  
  int get_n_scat_max () const
  {
    return n_scat_max;
  }
  
  int get_n_scat_max_p () const
  {
    return n_scat_max_p;
  }
  
  int get_n_scat_max_n () const
  {
    return n_scat_max_n;
  }
  
  int get_E_max_hw () const
  {
    return E_max_hw;
  }
  
  int get_Ep_max_hw () const
  {
    return Ep_max_hw;
  }
  
  int get_En_max_hw () const
  {
    return En_max_hw;
  }

  unsigned int get_BP () const
  {
    return BP;
  }

  int get_J () const
  {
    return J;
  }

  unsigned int get_space_dimension () const
  {
    return space_dimension;
  }

  const class nucleons_data & get_prot_data () const
  {
    return *prot_data_ptr;
  }
  
  const class nucleons_data & get_neut_data () const
  {
    return *neut_data_ptr;
  }
  
  const class array<unsigned int> & get_pairs_indices () const
  {
    return pairs_indices;
  }
  
  const class array<class pair_str> & get_pairs_tab () const
  {
    return pairs_tab;
  }
  
  bool is_it_filled () const
  {
    return (space != NO_SPACE);
  }
   
  friend double used_memory_calc (const class GSM_vector_helper_class_two_nucleons &T);
  
private:

  enum space_type space;  // type of space used: protons only, neutrons only or protons-neutrons

  enum interaction_type inter; // type of the interaction used (FHT, realistic, ...)
  
  bool truncation_hw; // true if one truncates in energy, given there in units of hbar omega (which can be used as arbitrary units as well), false if not
  bool truncation_ph; // true if one truncates with respect to particle number in the continuum, false if not
  
  int n_holes_max;    // maximal number of nucleon holes in core states
  int n_holes_max_p;  // maximal number of proton  holes in core states
  int n_holes_max_n;  // maximal number of neutron holes in core states
  
  int n_scat_max;    // maximal number of nucleons in the continuum
  int n_scat_max_p;  // maximal number of protons  in the continuum
  int n_scat_max_n;  // maximal number of neutrons in the continuum
  
  int E_max_hw;   // maximal truncation energy of configurations
  int Ep_max_hw;  // maximal truncation energy of proton configurations
  int En_max_hw;  // maximal truncation energy of neutron configurations
  
  unsigned int BP; // binary parity (see observables_basic_functions.cpp for definition) of the GSM vector

  int J; // total angular momentum of the GSM vector
  
  unsigned int space_dimension;   // Number of basis J-coupled pairs in the GSM vector expansion
  
  const class nucleons_data *prot_data_ptr; // pointer to constants and arrays related to protons  only
  const class nucleons_data *neut_data_ptr; // pointer to constants and arrays related to neutrons only
  
  class array<unsigned int> pairs_indices;   // Indices of basis J-coupled pairs in the GSM vector expansion
  
  class array<class pair_str> pairs_tab;   // Basis J-coupled pairs in the GSM vector expansion
};

#endif
