#ifndef GSMHFPOTENTIALS_H
#define GSMHFPOTENTIALS_H

// TYPE is double or complex
// -------------------------

namespace HF_potentials
{
  void iterative_HF_potentials_calc (
				     const class input_data_str &input_data , 
				     const class interaction_class &inter_data , 
				     class nucleons_data &prot_data , 
				     class nucleons_data &neut_data);

  void HF_potentials_realloc_calc (
				   const class input_data_str &input_data , 
				   const class interaction_class &inter_data_basis , 
				   class nucleons_data &prot_data , 
				   class nucleons_data &neut_data);
}

#endif
