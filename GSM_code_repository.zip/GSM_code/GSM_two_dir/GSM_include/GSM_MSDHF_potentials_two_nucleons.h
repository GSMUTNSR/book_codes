#ifndef GSMMSDHFPOTENTIALS_H
#define GSMMSDHFPOTENTIALS_H

// TYPE is double or complex
// -------------------------

namespace MSDHF_potentials
{
  namespace HO_expansion_part
  {
    void Up_HF_pp_part_HO_basis_calc (
				      const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
				      const class interaction_class &inter_data , 
				      class HF_nucleons_data &prot_Y_HF_data);

    void Up_HF_pn_part_HO_basis_calc (
				      const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
				      const class interaction_class &inter_data , 
				      const class HF_nucleons_data &neut_Y_HF_data , 
				      class HF_nucleons_data &prot_Y_HF_data);

    void Un_HF_nn_part_HO_basis_calc (
				      const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
				      const class interaction_class &inter_data , 
				      class HF_nucleons_data &neut_Y_HF_data);

    void Un_HF_pn_part_HO_basis_calc (
				      const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
				      const class interaction_class &inter_data , 
				      const class HF_nucleons_data &prot_Y_HF_data , 
				      class HF_nucleons_data &neut_Y_HF_data);

    void prot_potentials_HO_basis_calc (
					const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
					const class interaction_class &inter_data , 
					const class HF_nucleons_data &neut_Y_HF_data , 
					class HF_nucleons_data &prot_Y_HF_data);

    void neut_potentials_HO_basis_calc (
					const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
					const class interaction_class &inter_data , 
					const class HF_nucleons_data &prot_Y_HF_data , 
					class HF_nucleons_data &neut_Y_HF_data);
  }

  namespace SGI_MSGI_part
  {
    namespace SGI_part
    {
      void Up_pp_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm ,  
			    const int J , 
			    const double pair_weight , 
			    const unsigned int sp_occ , 
			    const class spherical_state &shell_prot , 
			    const class spherical_state &shell_prot_occ , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data , 
			    const class SGI_radial_tabs_str &prot_radial_tabs , 
			    class HF_nucleons_data &prot_Y_HF_data);

      void Up_pn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm ,  
			    const int J , 
			    const unsigned int sn_occ , 
			    const class spherical_state &shell_prot , 
			    const class spherical_state &shell_neut_occ , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data , 
			    const class SGI_radial_tabs_str &neut_radial_tabs , 
			    class HF_nucleons_data &prot_Y_HF_data);

      void Un_nn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm ,  
			    const int J , 
			    const double pair_weight , 
			    const unsigned int sn_occ , 
			    const class spherical_state &shell_neut , 
			    const class spherical_state &shell_neut_occ , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data , 
			    const class SGI_radial_tabs_str &neut_radial_tabs , 
			    class HF_nucleons_data &neut_Y_HF_data);

      void Un_pn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm ,  
			    const int J , 
			    const unsigned int sp_occ , 
			    const class spherical_state &shell_neut , 
			    const class spherical_state &shell_prot_occ , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data , 
			    const class SGI_radial_tabs_str &prot_radial_tabs , 
			    class HF_nucleons_data &neut_Y_HF_data);
    }

    namespace MSGI_part
    {
      void Up_pp_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm ,  
			    const int J , 
			    const double pair_weight , 
			    const class spherical_state &shell_prot , 
			    const class spherical_state &shell_prot_occ , 
			    const class array<double> &Gaussian_table_GL , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data , 
			    class HF_nucleons_data &prot_Y_HF_data);

      void Up_pn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm ,  
			    const int J , 
			    const class spherical_state &shell_prot , 
			    const class spherical_state &shell_neut_occ , 
			    const class array<double> &Gaussian_table_GL , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data , 
			    class HF_nucleons_data &prot_Y_HF_data);

      void Un_nn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm ,  
			    const int J , 
			    const double pair_weight , 
			    const class spherical_state &shell_neut , 
			    const class spherical_state &shell_neut_occ , 
			    const class array<double> &Gaussian_table_GL , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data , 
			    class HF_nucleons_data &neut_Y_HF_data);

      void Un_pn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm ,  
			    const int J , 
			    const class spherical_state &shell_neut , 
			    const class spherical_state &shell_prot_occ , 
			    const class array<double> &Gaussian_table_GL , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data , 
			    class HF_nucleons_data &neut_Y_HF_data);
    }

    void prot_trivially_equivalent_potentials_pp_part_calc (
							    const bool HO_diag , 
							    const class array<double> &Gaussian_table_GL , 
							    const class multipolar_expansion_str &multipolar_expansion , 
							    const class interaction_class &inter_data , 
							    const class SGI_radial_tabs_str &prot_radial_tabs , 
							    const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
							    class HF_nucleons_data &prot_Y_HF_data);

    void prot_trivially_equivalent_potentials_pn_part_calc (
							    const bool HO_diag , 
							    const class array<double> &Gaussian_table_GL , 
							    const class multipolar_expansion_str &multipolar_expansion , 
							    const class interaction_class &inter_data , 
							    const class SGI_radial_tabs_str &neut_radial_tabs , 
							    const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
							    const class HF_nucleons_data &neut_Y_HF_data , 
							    class HF_nucleons_data &prot_Y_HF_data);

    void neut_trivially_equivalent_potentials_nn_part_calc (
							    const bool HO_diag , 
							    const class array<double> &Gaussian_table_GL , 
							    const class multipolar_expansion_str &multipolar_expansion , 
							    const class interaction_class &inter_data , 
							    const class SGI_radial_tabs_str &neut_radial_tabs , 
							    const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
							    class HF_nucleons_data &neut_Y_HF_data);

    void neut_trivially_equivalent_potentials_pn_part_calc (
							    const bool HO_diag , 
							    const class array<double> &Gaussian_table_GL , 
							    const class multipolar_expansion_str &multipolar_expansion , 
							    const class interaction_class &inter_data , 
							    const class SGI_radial_tabs_str &prot_radial_tabs , 
							    const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
							    const class HF_nucleons_data &prot_Y_HF_data , 
							    class HF_nucleons_data &neut_Y_HF_data);

    void prot_trivially_equivalent_potentials_pp_part_shells_pm_calc (
								      const int pm , 
								      const class array<double> &Gaussian_table_GL , 
								      const class multipolar_expansion_str &multipolar_expansion , 
								      const class interaction_class &inter_data , 
								      const class SGI_radial_tabs_str &prot_radial_tabs , 
								      const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
								      class HF_nucleons_data &prot_Y_HF_data);

    void prot_trivially_equivalent_potentials_pn_part_shells_pm_calc (
								      const int pm , 
								      const class array<double> &Gaussian_table_GL , 
								      const class multipolar_expansion_str &multipolar_expansion , 
								      const class interaction_class &inter_data , 
								      const class SGI_radial_tabs_str &neut_radial_tabs , 
								      const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
								      const class HF_nucleons_data &neut_Y_HF_data , 
								      class HF_nucleons_data &prot_Y_HF_data);

    void neut_trivially_equivalent_potentials_nn_part_shells_pm_calc (
								      const int pm , 
								      const class array<double> &Gaussian_table_GL , 
								      const class multipolar_expansion_str &multipolar_expansion , 
								      const class interaction_class &inter_data , 
								      const class SGI_radial_tabs_str &neut_radial_tabs , 
								      const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
								      class HF_nucleons_data &neut_Y_HF_data);

    void neut_trivially_equivalent_potentials_pn_part_shells_pm_calc (
								      const int pm , 
								      const class array<double> &Gaussian_table_GL , 
								      const class multipolar_expansion_str &multipolar_expansion , 
								      const class interaction_class &inter_data , 
								      const class SGI_radial_tabs_str &prot_radial_tabs , 
								      const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
								      const class HF_nucleons_data &prot_Y_HF_data , 
								      class HF_nucleons_data &neut_Y_HF_data);

    void prot_trivially_equivalent_potentials_calc (
						    const bool HO_diag , 
						    const class array<double> &Gaussian_table_GL , 
						    const class multipolar_expansion_str &multipolar_expansion , 
						    const class interaction_class &inter_data , 
						    const class SGI_radial_tabs_str &prot_radial_tabs , 
						    const class SGI_radial_tabs_str &neut_radial_tabs , 
						    const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
						    const class HF_nucleons_data &neut_Y_HF_data , 
						    class HF_nucleons_data &prot_Y_HF_data);

    void neut_trivially_equivalent_potentials_calc (
						    const bool HO_diag , 
						    const class array<double> &Gaussian_table_GL , 
						    const class multipolar_expansion_str &multipolar_expansion , 
						    const class interaction_class &inter_data , 
						    const class SGI_radial_tabs_str &prot_radial_tabs , 
						    const class SGI_radial_tabs_str &neut_radial_tabs , 
						    const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
						    const class HF_nucleons_data &prot_Y_HF_data , 
						    class HF_nucleons_data &neut_Y_HF_data);

    void prot_trivially_equivalent_potentials_shells_pm_calc (
							      const int pm , 
							      const class array<double> &Gaussian_table_GL , 
							      const class multipolar_expansion_str &multipolar_expansion , 
							      const class interaction_class &inter_data , 
							      const class SGI_radial_tabs_str &prot_radial_tabs , 
							      const class SGI_radial_tabs_str &neut_radial_tabs , 
							      const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
							      const class HF_nucleons_data &neut_Y_HF_data , 
							      class HF_nucleons_data &prot_Y_HF_data);

    void neut_trivially_equivalent_potentials_shells_pm_calc (
							      const int pm , 
							      const class array<double> &Gaussian_table_GL , 
							      const class multipolar_expansion_str &multipolar_expansion , 
							      const class interaction_class &inter_data , 
							      const class SGI_radial_tabs_str &prot_radial_tabs , 
							      const class SGI_radial_tabs_str &neut_radial_tabs , 
							      const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
							      const class HF_nucleons_data &prot_Y_HF_data , 
							      class HF_nucleons_data &neut_Y_HF_data);
  }

  void potentials_calc (
			const class lj_table<class correlated_state_str> &prot_basis_PSI_qn_tab , 
			const class lj_table<class correlated_state_str> &neut_basis_PSI_qn_tab , 
			const bool HO_diag , 
			const bool neutron_basis_potential , 
			const class interaction_class &inter_data , 
			const class array<double> &Gaussian_table_GL , 
			const class multipolar_expansion_str &multipolar_expansion ,
			class HF_nucleons_data &prot_Y_HF_data , 
			class HF_nucleons_data &neut_Y_HF_data);
  
  void iterative_potentials_shells_OBMEs_calc (
					       const class input_data_str &input_data , 
					       const class interaction_class &inter_data , 
					       class HF_nucleons_data &prot_Y_HF_data ,
					       class HF_nucleons_data &neut_Y_HF_data , 
					       class baryons_data &prot_Y_data , 
					       class baryons_data &neut_Y_data);
  
  void potentials_shells_OBMEs_realloc_calc (
					     const class input_data_str &input_data , 
					     const class interaction_class &inter_data_basis , 
					     class HF_nucleons_data &prot_Y_HF_data , 
					     class HF_nucleons_data &neut_Y_HF_data ,
					     class baryons_data &prot_Y_data , 
					     class baryons_data &neut_Y_data);
}

#endif
