#ifndef GSMJ2ONECONFIGURATIONCLASS_H
#define GSMJ2ONECONFIGURATIONCLASS_H

// TYPE is double or complex
// -------------------------

class J2_one_configuration_class
{
public:
  J2_one_configuration_class ();
  
  ~J2_one_configuration_class ();
  
  J2_one_configuration_class (
			      const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_M , 
			      const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_Mp1);

  J2_one_configuration_class (const class J2_one_configuration_class &X);
  
  void allocate (
		 const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_M , 
		 const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_Mp1);
  
  void allocate_fill (const class J2_one_configuration_class &X);

  void deallocate ();

  void apply_add (
		  const class GSM_vector_one_configuration &PSI , 
		  const TYPE &alpha , 
		  class GSM_vector_one_configuration &J2_PSI) const;

  const class GSM_vector_helper_one_configuration_class & get_GSM_vector_helper_M () const
  {
    return *GSM_vector_helper_M_ptr;
  }
  
  class GSM_vector_one_configuration & get_PSI_Mp1 () const
  {
    return *PSI_Mp1_ptr;
  }
  
  bool is_it_filled () const;

  friend double used_memory_calc (const class J2_one_configuration_class &T);
  
private:
  
  const class GSM_vector_helper_one_configuration_class *GSM_vector_helper_M_ptr; // pointer to data necessary to handle |Psi[in]> and |Psi[out]>. It does not contain their vector components.

  class Jpm_one_configuration_class Jplus;  // Class containing data related to J+
  class Jpm_one_configuration_class Jminus; // Class containing data related to J-
  
  class GSM_vector_one_configuration *PSI_Mp1_ptr; // pointer to GSM vector whose M-projection is equal to M+1. It is necessary to store J+|Psi[in]>.
};





class xJ2_one_configuration_plus_alpha_str
{
public:

  const TYPE x;
  const TYPE alpha;

  const class J2_one_configuration_class &J2;

  xJ2_one_configuration_plus_alpha_str (const TYPE &x_c , const TYPE &alpha_c , const class J2_one_configuration_class &J2_c);
};

class xJ2_one_configuration_plus_alpha_str operator + (const class J2_one_configuration_class &J2);
class xJ2_one_configuration_plus_alpha_str operator - (const class J2_one_configuration_class &J2);

class xJ2_one_configuration_plus_alpha_str operator + (const class J2_one_configuration_class &J2 , const double term);
class xJ2_one_configuration_plus_alpha_str operator - (const class J2_one_configuration_class &J2 , const double term);

class xJ2_one_configuration_plus_alpha_str operator + (const double term , const class J2_one_configuration_class &J2);
class xJ2_one_configuration_plus_alpha_str operator - (const double term , const class J2_one_configuration_class &J2);

class xJ2_one_configuration_plus_alpha_str operator * (const class J2_one_configuration_class &J2 , const double x);
class xJ2_one_configuration_plus_alpha_str operator * (const double x , const class J2_one_configuration_class &J2);
class xJ2_one_configuration_plus_alpha_str operator / (const class J2_one_configuration_class &J2 , const double x);

class xJ2_one_configuration_plus_alpha_str operator + (const class xJ2_one_configuration_plus_alpha_str &Op);
class xJ2_one_configuration_plus_alpha_str operator - (const class xJ2_one_configuration_plus_alpha_str &Op);

class xJ2_one_configuration_plus_alpha_str operator + (const class xJ2_one_configuration_plus_alpha_str &Op , const double term);
class xJ2_one_configuration_plus_alpha_str operator - (const class xJ2_one_configuration_plus_alpha_str &Op , const double term);

class xJ2_one_configuration_plus_alpha_str operator + (const double alpha , const class xJ2_one_configuration_plus_alpha_str &Op);
class xJ2_one_configuration_plus_alpha_str operator - (const double alpha , const class xJ2_one_configuration_plus_alpha_str &Op);

class xJ2_one_configuration_plus_alpha_str operator * (const class xJ2_one_configuration_plus_alpha_str &Op , const double factor);
class xJ2_one_configuration_plus_alpha_str operator / (const class xJ2_one_configuration_plus_alpha_str &Op , const double factor);

class xJ2_one_configuration_plus_alpha_str operator + (const class J2_one_configuration_class &J2 , const complex<double> &term);
class xJ2_one_configuration_plus_alpha_str operator - (const class J2_one_configuration_class &J2 , const complex<double> &term);

class xJ2_one_configuration_plus_alpha_str operator + (const complex<double> &term , const class J2_one_configuration_class &J2);
class xJ2_one_configuration_plus_alpha_str operator - (const complex<double> &term , const class J2_one_configuration_class &J2);

class xJ2_one_configuration_plus_alpha_str operator * (const class J2_one_configuration_class &J2 , const complex<double> &x);
class xJ2_one_configuration_plus_alpha_str operator * (const complex<double> &x , const class J2_one_configuration_class &J2);
class xJ2_one_configuration_plus_alpha_str operator / (const class J2_one_configuration_class &J2 , const complex<double> &x);

class xJ2_one_configuration_plus_alpha_str operator + (const class xJ2_one_configuration_plus_alpha_str &Op , const complex<double> &term);
class xJ2_one_configuration_plus_alpha_str operator - (const class xJ2_one_configuration_plus_alpha_str &Op , const complex<double> &term);

class xJ2_one_configuration_plus_alpha_str operator + (const complex<double> &alpha , const class xJ2_one_configuration_plus_alpha_str &Op);
class xJ2_one_configuration_plus_alpha_str operator - (const complex<double> &alpha , const class xJ2_one_configuration_plus_alpha_str &Op);

class xJ2_one_configuration_plus_alpha_str operator * (const class xJ2_one_configuration_plus_alpha_str &Op , const complex<double> &factor);
class xJ2_one_configuration_plus_alpha_str operator / (const class xJ2_one_configuration_plus_alpha_str &Op , const complex<double> &factor);

#endif






