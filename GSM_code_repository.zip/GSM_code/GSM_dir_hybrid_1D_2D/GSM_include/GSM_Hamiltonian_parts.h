#ifndef GSMHAMILTONIANPARTS_H
#define GSMHAMILTONIANPARTS_H

// TYPE is double or complex
// -------------------------

namespace Hamiltonian_parts
{
  void kinetic_one_body_calc_print (
				    const class input_data_str &input_data , 
				    const class interaction_class &inter_data ,
				    class GSM_vector &PSI_full , 
				    const double J ,
				    const class GSM_vector &PSI ,
				    class GSM_vector &PSI_0 ,
				    class GSM_vector &PSI_1 ,
				    class array<class GSM_vector> &H_PSI_table ,
				    class TBMEs_class &TBMEs_pn);

  void kinetic_recoil_calc_print (
				  const class input_data_str &input_data , 
				  const class interaction_class &inter_data ,
				  class GSM_vector &PSI_full ,  
				  const double J , 
				  const class GSM_vector &PSI ,
				  class GSM_vector &PSI_0 ,
				  class GSM_vector &PSI_1 ,
				  class array<class GSM_vector> &H_PSI_table ,
				  class TBMEs_class &TBMEs_pn);

  void nuclear_one_body_calc_print (
				    const class input_data_str &input_data , 
				    const class interaction_class &inter_data ,
				    class GSM_vector &PSI_full , 
				    const double J ,
				    const class GSM_vector &PSI ,
				    class GSM_vector &PSI_0 ,
				    class GSM_vector &PSI_1 ,
				    class array<class GSM_vector> &H_PSI_table ,
				    class TBMEs_class &TBMEs_pn);

  void nuclear_two_body_calc_print (
				    const class input_data_str &input_data , 
				    const int Jn_rel_max , 
				    class GSM_vector &PSI_full , 
				    const double J ,
				    const class GSM_vector &PSI ,
				    class interaction_class &inter_data , 
				    class GSM_vector &PSI_0 ,
				    class GSM_vector &PSI_1 ,
				    class array<class GSM_vector> &H_PSI_table ,
				    class TBMEs_class &TBMEs_pn);

  void nuclear_three_body_calc_print (
				      const class input_data_str &input_data ,
				      class GSM_vector &PSI_full ,  
				      const double J , 
				      const class GSM_vector &PSI ,
				      class GSM_vector &PSI_0 ,
				      class GSM_vector &PSI_1 ,
				      class array<class GSM_vector> &H_PSI_table ,
				      class interaction_class &inter_data , 
				      class TBMEs_class &TBMEs_pn);

  void Coulomb_one_body_calc_print (
				    const class input_data_str &input_data , 
				    const class interaction_class &inter_data ,
				    class GSM_vector &PSI_full , 
				    const double J ,
				    const class GSM_vector &PSI ,
				    class GSM_vector &PSI_0 ,
				    class GSM_vector &PSI_1 ,
				    class array<class GSM_vector> &H_PSI_table ,
				    class TBMEs_class &TBMEs_pn);

  void Coulomb_two_body_calc_print (
				    const class input_data_str &input_data , 
				    const int Jc_rel_max , 
				    class GSM_vector &PSI_full ,
				    const double J , 
				    const class GSM_vector &PSI ,
				    class interaction_class &inter_data , 
				    class GSM_vector &PSI_0 ,
				    class GSM_vector &PSI_1 ,
				    class array<class GSM_vector> &H_PSI_table ,
				    class TBMEs_class &TBMEs_pn);

  void calc_print (
		   const class input_data_str &input_data , 
		   const class array<class correlated_state_str> &PSI_qn_tab , 
		   class interaction_class &inter_data , 
		   class nucleons_data &prot_data , 
		   class nucleons_data &neut_data , 
		   class TBMEs_class &TBMEs_pn ,
		   class GSM_vector &PSI_full);
}

#endif
