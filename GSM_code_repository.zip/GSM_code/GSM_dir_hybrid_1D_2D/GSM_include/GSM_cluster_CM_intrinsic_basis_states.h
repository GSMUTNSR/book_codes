#ifndef GSMCLUSTERCMINTRINSICBASISSTATES_H
#define GSMCLUSTERCMINTRINSICBASISSTATES_H

// TYPE is double or complex
// -------------------------

namespace cluster_CM_intrinsic_basis_states
{
  void PSI_HO_A_dagger_CM_HO_LCM_M_LCM_tabs_alloc (
						   const class input_data_str &input_data , 
						   const double M_intrinsic , 
						   class cluster_data &data , 
						   class array<class GSM_vector_helper_class> &GSM_vector_helper_M_E_CM_HO_tab , 
						   class array<class GSM_vector_helper_class> &GSM_vector_helper_M_E_CM_HO_m1_tab , 
						   class array<class GSM_vector> &GSM_vector_M_E_CM_HO_m1_tab , 
						   class array<class CM_operator_class> &A_dagger_CM_HO_minus_tab , 
						   class array<class CM_operator_class> &A_dagger_CM_HO_zero_tab , 
						   class array<class CM_operator_class> &A_dagger_CM_HO_plus_tab , 
						   class array<class GSM_vector> &PSI_HO_LCM_M_LCM_tab);
 
  void PSI_HO_CM_0s_M_intrinsic_store (
				       const class input_data_str &input_data , 
				       const int iM_intrinsic , 
				       class cluster_data &data ,
				       class array<class GSM_vector> &PSI_HO_LCM_M_LCM_tab);
  
  void PSI_HO_LCM_M_LCM_tab_all_LCM_E_CM_HO_fixed_calc (
							const int E_CM_HO , 
							const class array<class CM_operator_class> &A_dagger_CM_HO_minus_tab , 
							const class array<class CM_operator_class> &A_dagger_CM_HO_zero_tab , 
							const class array<class CM_operator_class> &A_dagger_CM_HO_plus_tab , 
							class array<class GSM_vector> &PSI_HO_LCM_M_LCM_tab);
 
  unsigned int LCM_M_LCM_number_determine (
					   const int LCM_min ,
					   const int LCM_max);
 
  void LCM_M_LCM_indices_determine (
				    const int LCM_min ,
				    const int LCM_max ,
				    class array<unsigned int> &LCM_M_LCM_indices);
 
  void PSI_HO_LCM_M_LCM_tab_all_LCM_E_CM_HO_fixed_store (
							 const class input_data_str &input_data , 
							 const double M_intrinsic , 
							 const int E_CM_HO , 
							 class cluster_data &data , 		
							 const class array<class GSM_vector> &PSI_HO_LCM_M_LCM_tab);
 
  unsigned int NCM_HO_LCM_number_determine (
					    const int E_CM_HO_max ,
					    const int LCM_max_all);
 
  void NCM_HO_LCM_indices_determine (
				     const int E_CM_HO_max ,
				     const int LCM_max_all ,
				     class array<unsigned int> &NCM_HO_LCM_indices);
 
  void all_PSI_HO_fixed_NCM_HO_LCM_alloc_init (
					       const class input_data_str &input_data , 
					       const unsigned int BP_cluster , 
					       const int LCM , 
					       class cluster_data &data , 
					       class array<class GSM_vector_helper_class> &PSI_HO_BP_M_cluster_helper_tab , 
					       class array<class GSM_vector_helper_class> &PSI_HO_coupled_to_J_cluster_helper_tab , 
					       class array<class GSM_vector> &PSI_HO_BP_M_cluster_0_tab , 
					       class array<class GSM_vector> &PSI_HO_BP_M_cluster_1_tab ,
					       class array<class GSM_vector> &PSI_HO_BP_M_cluster_store_tab , 
					       class array<class GSM_vector> &PSI_HO_coupled_to_J_cluster_tab);
 
  void all_PSI_HO_coupled_to_J_cluster_tabs_fixed_NCM_HO_LCM_calc (
								   const class cluster_data &data , 
								   const int NCM_HO , 
								   const int LCM , 
								   class array<class GSM_vector> &PSI_HO_BP_M_cluster_tab , 
								   class array<class GSM_vector> &PSI_HO_coupled_to_J_cluster_tab);
 
  void all_PSI_HO_coupled_to_J_cluster_tabs_fixed_NCM_HO_LCM_project_store (
									    const class input_data_str &input_data , 
									    class cluster_data &data , 
									    const int NCM_HO , 
									    const int LCM , 
									    const class array<class GSM_vector_helper_class> &PSI_HO_BP_M_cluster_helper_tab ,
									    class array<class GSM_vector> &PSI_HO_BP_M_cluster_0_tab , 
									    class array<class GSM_vector> &PSI_HO_BP_M_cluster_1_tab ,
									    class array<class GSM_vector> &PSI_HO_BP_M_cluster_store_tab , 
									    class array<class GSM_vector> &PSI_HO_coupled_to_J_cluster_tab);
 
  void PSI_HO_coupled_to_J_cluster_E_CM_HO_max_precision_print (
								const class input_data_str &input_data ,
								class cluster_data &data);
 
  void all_PSI_HO_coupled_to_J_cluster_calc_store (
						   const class input_data_str &input_data , 
						   class cluster_data &data);
 
  void GSM_vector_NCM_HO_LCM_HO_basis_tab_calc_store (
						      const bool is_there_cout , 
						      const class input_data_str &input_data , 
						      class cluster_data &data);
 
  void GSM_vector_NCM_HO_LCM_HO_basis_tab_read_from_M_scheme ( 
							      const class cluster_data &data , 
							      const int LCM , 
							      const double J_cluster , 
							      const double M_cluster , 
							      class array<class GSM_vector> &GSM_vector_NCM_HO_LCM_HO_basis_tab);

  void GSM_vector_NCM_HO_LCM_HO_basis_tab_read_from_J_scheme ( 
							      const class cluster_data &data , 
							      const int LCM , 
							      const double J_cluster , 
							      class array<class GSM_vector> &GSM_vector_NCM_HO_LCM_HO_basis_tab);

  void GSM_vector_NCM_HO_LCM_HO_basis_tab_read (
						const bool are_two_body_clusters_stored_in_J_scheme ,
						const class cluster_data &data , 
						const int LCM , 
						const double J_proj , 
						const double M_proj , 
						class array<class GSM_vector> &GSM_vector_NCM_LCM_HO_basis_tab);
  
  void GSM_vector_NCM_HO_LCM_Berggren_basis_tab_calc (
						      const class cluster_data &data , 
						      const int LCM , 
						      const double J_cluster , 	
						      const class J2_class &J2 , 
						      const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren , 
						      const class array<class GSM_vector> &GSM_vector_NCM_HO_LCM_HO_basis_tab , 
						      class GSM_vector &Vstore , 
						      class array<class GSM_vector> &GSM_vector_NCM_HO_LCM_Berggren_basis_tab);
 
  void GSM_vector_NCM_HO_LCM_Berggren_basis_tab_store (
						       const class cluster_data &data , 
						       const int LCM , 
						       const double J_cluster , 
						       const double M_cluster , 
						       class array<class GSM_vector> &GSM_vector_NCM_HO_LCM_Berggren_basis_TRS_tab , 
						       class array<class GSM_vector> &GSM_vector_NCM_HO_LCM_Berggren_basis_tab);
 
  void Berggren_basis_states_calc_store (
					 const bool is_there_cout , 
					 const class input_data_str &input_data , 
					 const class array<int> &nmax_HO_lab_tab , 
					 class cluster_data &data);
}

#endif
