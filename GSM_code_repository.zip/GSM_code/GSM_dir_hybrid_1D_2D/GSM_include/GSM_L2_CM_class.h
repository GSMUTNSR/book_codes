#ifndef GSML2CMCLASS_H
#define GSML2CMCLASS_H

// TYPE is double or complex
// -------------------------

class L2_CM_class
{
public:

  L2_CM_class ();
  
  L2_CM_class (
	       const class CM_operator_class &Lplus , 
	       const class CM_operator_class &Lminus ,  
	       const class CM_operator_class &Lz , 
	       class GSM_vector &PSI_M , 
	       class GSM_vector &PSI_Mp1);

  L2_CM_class (const class L2_CM_class &X);

  ~L2_CM_class ();
  
  void allocate (
		 const class CM_operator_class &Lplus , 
		 const class CM_operator_class &Lminus ,  
		 const class CM_operator_class &Lz , 
		 class GSM_vector &PSI_M , 
		 class GSM_vector &PSI_Mp1);

  void allocate_fill (const class L2_CM_class &X);

  void deallocate ();

  void apply_add (
		  const class GSM_vector &PSI , 
		  const TYPE &alpha , 
		  class GSM_vector &PSI_out) const;

  const class CM_operator_class & get_Lplus () const
  {
    return *Lplus_ptr;
  }

  const class CM_operator_class & get_Lminus () const
  {
    return *Lminus_ptr;
  }

  const class CM_operator_class & get_Lz () const
  {
    return *Lz_ptr;
  }

  class GSM_vector & get_PSI_M () const
  {
    return *PSI_M_ptr;
  }
  
  class GSM_vector & get_PSI_Mp1 () const
  {
    return *PSI_Mp1_ptr;
  }
  
  bool is_it_filled () const
  {
    return (PSI_M_ptr != NULL);
  }

private:

  const class CM_operator_class *Lplus_ptr;  // Pointer to class containing data related to L+
  const class CM_operator_class *Lminus_ptr; // Pointer to class containing data related to L-
  const class CM_operator_class *Lz_ptr;     // Pointer to class containing data related to Lz
  
  class GSM_vector *PSI_M_ptr;   // pointer to GSM vector whose M-projection is equal to 1.   It is necessary to store Lz|Psi[in]> + |Psi[in]>.
  class GSM_vector *PSI_Mp1_ptr; // pointer to GSM vector whose M-projection is equal to M+1. It is necessary to store L+|Psi[in]>.
};

double used_memory_calc (const class L2_CM_class &T);






class xL2_CM_plus_alpha_str
{
public:

  const TYPE x , alpha;
  const class L2_CM_class &L2_CM;

  xL2_CM_plus_alpha_str (const TYPE &x_c , const TYPE &alpha_c , const class L2_CM_class &L2_CM_c);
};

class xL2_CM_plus_alpha_str operator + (const class L2_CM_class &L2_CM);
class xL2_CM_plus_alpha_str operator - (const class L2_CM_class &L2_CM);

class xL2_CM_plus_alpha_str operator + (const class L2_CM_class &L2_CM , const double term);
class xL2_CM_plus_alpha_str operator - (const class L2_CM_class &L2_CM , const double term);

class xL2_CM_plus_alpha_str operator + (const double term , const class L2_CM_class &L2_CM);
class xL2_CM_plus_alpha_str operator - (const double term , const class L2_CM_class &L2_CM);

class xL2_CM_plus_alpha_str operator * (const class L2_CM_class &L2_CM , const double x);
class xL2_CM_plus_alpha_str operator * (const double x , const class L2_CM_class &L2_CM);
class xL2_CM_plus_alpha_str operator / (const class L2_CM_class &L2_CM , const double x);

class xL2_CM_plus_alpha_str operator + (const class xL2_CM_plus_alpha_str &Op);
class xL2_CM_plus_alpha_str operator - (const class xL2_CM_plus_alpha_str &Op);

class xL2_CM_plus_alpha_str operator + (const class xL2_CM_plus_alpha_str &Op , const double term);
class xL2_CM_plus_alpha_str operator - (const class xL2_CM_plus_alpha_str &Op , const double term);

class xL2_CM_plus_alpha_str operator + (const double alpha , const class xL2_CM_plus_alpha_str &Op);
class xL2_CM_plus_alpha_str operator - (const double alpha , const class xL2_CM_plus_alpha_str &Op);

class xL2_CM_plus_alpha_str operator * (const class xL2_CM_plus_alpha_str &Op , const double factor);
class xL2_CM_plus_alpha_str operator / (const class xL2_CM_plus_alpha_str &Op , const double factor);
class xL2_CM_plus_alpha_str operator * (const double factor , const class xL2_CM_plus_alpha_str &Op);

class xL2_CM_plus_alpha_str operator + (const class L2_CM_class &L2_CM , const complex<double> &term);
class xL2_CM_plus_alpha_str operator - (const class L2_CM_class &L2_CM , const complex<double> &term);

class xL2_CM_plus_alpha_str operator + (const complex<double> &term , const class L2_CM_class &L2_CM);
class xL2_CM_plus_alpha_str operator - (const complex<double> &term , const class L2_CM_class &L2_CM);

class xL2_CM_plus_alpha_str operator * (const class L2_CM_class &L2_CM , const complex<double> &x);
class xL2_CM_plus_alpha_str operator * (const complex<double> &x , const class L2_CM_class &L2_CM);
class xL2_CM_plus_alpha_str operator / (const class L2_CM_class &L2_CM , const complex<double> &x);

class xL2_CM_plus_alpha_str operator + (const class xL2_CM_plus_alpha_str &Op , const complex<double> &term);
class xL2_CM_plus_alpha_str operator - (const class xL2_CM_plus_alpha_str &Op , const complex<double> &term);

class xL2_CM_plus_alpha_str operator + (const complex<double> &alpha , const class xL2_CM_plus_alpha_str &Op);
class xL2_CM_plus_alpha_str operator - (const complex<double> &alpha , const class xL2_CM_plus_alpha_str &Op);

class xL2_CM_plus_alpha_str operator * (const class xL2_CM_plus_alpha_str &Op , const complex<double> &factor);
class xL2_CM_plus_alpha_str operator / (const class xL2_CM_plus_alpha_str &Op , const complex<double> &factor);
class xL2_CM_plus_alpha_str operator * (const complex<double> &factor , const class xL2_CM_plus_alpha_str &Op);

#endif

class xL2_CM_plus_alpha_str operator + (const class xL2_CM_plus_alpha_str &Op_a , const class xL2_CM_plus_alpha_str &Op_b);
class xL2_CM_plus_alpha_str operator - (const class xL2_CM_plus_alpha_str &Op_a , const class xL2_CM_plus_alpha_str &Op_b);

