#ifndef GSMCLUSTERHOTOBERGGRENCLASS_H
#define GSMCLUSTERHOTOBERGGRENCLASS_H

// TYPE is double or complex
// -------------------------

class cluster_HO_to_Berggren_class
{
public:
  
  cluster_HO_to_Berggren_class ();
  
  cluster_HO_to_Berggren_class (
			        const bool is_there_cout ,
				const enum storage_type storage_c ,
				const double J_c , 
				const class cluster_data &data , 
				class GSM_vector_helper_class &GSM_vector_helper_HO ,
				class GSM_vector_helper_class &GSM_vector_helper);
  
  cluster_HO_to_Berggren_class (
			        const bool is_there_cout ,
				const enum storage_type storage_c ,
				const double J_c , 
				const class cluster_data &data , 
				class GSM_vector_helper_class &GSM_vector_helper_HO ,
				class GSM_vector_helper_class &GSM_vector_helper , 
				class array<class GSM_vector> &PSI_HO_part_table);

  cluster_HO_to_Berggren_class (const class cluster_HO_to_Berggren_class &X);
  
  ~cluster_HO_to_Berggren_class ();
  
  void allocate (
		 const bool is_there_cout ,
		 const enum storage_type storage_c ,
		 const double J_c , 
		 const class cluster_data &data , 
		 class GSM_vector_helper_class &GSM_vector_helper_HO ,
		 class GSM_vector_helper_class &GSM_vector_helper);

  void allocate (
		 const bool is_there_cout ,
		 const enum storage_type storage_c ,
		 const double J_c , 
		 const class cluster_data &data , 
		 class GSM_vector_helper_class &GSM_vector_helper_HO ,
		 class GSM_vector_helper_class &GSM_vector_helper , 
		 class array<class GSM_vector> &PSI_HO_part_table);
  
  void allocate_fill (const class cluster_HO_to_Berggren_class &X);

  void deallocate ();

  bool is_it_filled () const
  {
    return (storage != NO_STORAGE); 
  }
  
  enum storage_type get_storage ()
  {
    return storage;
  }
  
  void set_J (const double J_c)
  {
    J = J_c;
  }

  double get_J () const
  {
    return J;
  }

  class GSM_vector_helper_class & get_GSM_vector_helper () const
  {
    return *GSM_vector_helper_ptr;
  }
  
  class GSM_vector_helper_class & get_GSM_vector_helper_HO () const
  {
    return *GSM_vector_helper_HO_ptr;
  }
      
  const class cluster_data & get_cluster_data () const
  {
    return *cluster_data_ptr;
  }
  
  class array<class GSM_vector> & get_PSI_HO_part_table ()
  {
    return *PSI_HO_part_table_ptr;
  }
  
  class array<class GSM_vector> & get_PSI_HO_part_table () const
  {
    return *PSI_HO_part_table_ptr;
  }
  
  unsigned long int total_space_dimension_HO_determine () const;

  unsigned long int total_space_dimension_determine () const;

  void print () const;

  double non_zero_overlaps_proportion_calc () const;

  void apply_add (const class GSM_vector &PSI_HO_in , class GSM_vector &PSI_out) const;
  
  void apply_add_inverse (const class GSM_vector &PSI_in , class GSM_vector &PSI_HO) const;

  friend double used_memory_calc (const class cluster_HO_to_Berggren_class &T);
  
private:

  void non_zero_overlaps_numbers_pn_Nval_larger_calc_store ();  
  void non_zero_overlaps_numbers_pn_Zval_larger_calc_store ();

  void non_zero_overlaps_numbers_pp_nn_calc_store ();

  void non_zero_overlaps_numbers_calc_store ();

  void non_zero_overlaps_pn_Nval_larger_calc_store ();  
  void non_zero_overlaps_pn_Zval_larger_calc_store ();
  
  void non_zero_overlaps_pp_nn_calc_store ();
  
  void matrix_store ();

  void apply_add_full_storage (const class GSM_vector &PSI_in , class GSM_vector &PSI_out) const;
  
  void apply_add_inverse_full_storage (const class GSM_vector &PSI_in , class GSM_vector &PSI_out) const;
  
  void apply_add_pn_on_the_fly_Nval_larger (const class GSM_vector &PSI_HO_in , class GSM_vector &PSI_out) const;
  void apply_add_pn_on_the_fly_Zval_larger (const class GSM_vector &PSI_HO_in , class GSM_vector &PSI_out) const;

  void apply_add_pp_nn_on_the_fly (const class GSM_vector &PSI_HO_in , class GSM_vector &PSI_out) const;
  
  void apply_add_on_the_fly (const class GSM_vector &PSI_HO_in , class GSM_vector &PSI_out) const;
    
  void apply_add_inverse_pn_on_the_fly_Nval_larger (const class GSM_vector &PSI_in , class GSM_vector &PSI_HO_out) const;
  void apply_add_inverse_pn_on_the_fly_Zval_larger (const class GSM_vector &PSI_in , class GSM_vector &PSI_HO_out) const;

  void apply_add_inverse_pp_nn_on_the_fly (const class GSM_vector &PSI_in , class GSM_vector &PSI_HO_out) const;
  
  void apply_add_inverse_on_the_fly (const class GSM_vector &PSI_in , class GSM_vector &PSI_HO_out) const;
    
  enum storage_type storage; // storage type of the Hamiltonian (full storage, partial storage or on the fly)
  
  double J; // total angular momentum of the considered many body wave function

  unsigned long int total_space_dimension_non_zeros; // dimension of the considered GSM vector
  
  const class cluster_data *cluster_data_ptr; // pointer to data of the used cluster
  
  class GSM_vector_helper_class *GSM_vector_helper_HO_ptr; // pointer to data necessary to handle |Psi-HO>. It does not contain its vector components.
  class GSM_vector_helper_class *GSM_vector_helper_ptr;    // pointer to data necessary to handle |Psi> = U[HO to Berggren] |Psi-HO>. It does not contain vector components.
   
  class array<unsigned int> non_zero_overlaps_numbers; // number of non-zeros overlaps

  class array<unsigned long int> total_PSI_indices_non_zeros; // indices of the SDs of |Psi> whose components must be calculated

  class array<class array<unsigned int> > non_zero_overlaps_PSI_HO_indices_tab; // indices of the SDs of |Psi-HO> leading to non-zeros overlaps

  class array<class array<TYPE> > non_zero_overlaps_tab; // non-zeros overlaps
  
  class array<class GSM_vector> *PSI_HO_part_table_ptr; // array of work vectors to avoid a race condition for the inverse operator
};




class x_cluster_HO_to_Berggren_str
{
public:

  const TYPE x;
  const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren;

  x_cluster_HO_to_Berggren_str (const TYPE &x_c , const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren_c);
};

class x_cluster_HO_to_Berggren_str operator + (const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren);
class x_cluster_HO_to_Berggren_str operator - (const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren);

class x_cluster_HO_to_Berggren_str operator * (const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren , const double x);
class x_cluster_HO_to_Berggren_str operator * (const double x , const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren);
class x_cluster_HO_to_Berggren_str operator / (const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren , const double x);

class x_cluster_HO_to_Berggren_str operator + (const class x_cluster_HO_to_Berggren_str &x_cluster_HO_to_Berggren_str);
class x_cluster_HO_to_Berggren_str operator - (const class x_cluster_HO_to_Berggren_str &x_cluster_HO_to_Berggren_str);

class x_cluster_HO_to_Berggren_str operator * (const class cluster_HO_to_Berggren_str &cluster_HO_to_Berggren_class , const complex<double> &x);
class x_cluster_HO_to_Berggren_str operator * (const complex<double> &x , const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren);
class x_cluster_HO_to_Berggren_str operator / (const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren , const complex<double> &x);

#endif
