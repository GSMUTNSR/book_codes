#ifndef GSMADAGGERCLUSTERHELPER_H
#define GSMADAGGERCLUSTERHELPER_H


// TYPE is double or complex
// -------------------------




class A_dagger_cluster_PSI_str 
{
public:

  const bool full_common_vectors_used_in_file; // true if vectors are copied fully to disk, false if they are copied in parallel in several files, following MPI distribution of vectors

  const bool is_it_CM_relative_cluster_projectile; //  true if one considers a cluster projectile of the form |Psi(cluster)> = |N[CM] L[CM] rel> in HO basis for reactions, false if it is not the case
  
  const enum particle_type cluster_projectile; // type of cluster projectile (proton, neutron, diproton, deuteron, 3He, alpha, ...)

  const int NCM_HO_cluster_projectile; // N[CM] in |Psi(cluster)> = |N[CM] L[CM] rel> in HO basis (is_it_CM_relative_cluster true)

  const int LCM_cluster_projectile; // L[CM] in |Psi(cluster)> = |N[CM] L[CM] rel> in HO basis (is_it_CM_relative_cluster true)

  const double M_cluster_projectile; // M-projection of |Psi(cluster)>
  
  const class correlated_state_str &PSI_cluster_projectile_qn; // data containing the quantum numbers of |Psi(cluster)>

  const bool is_it_CM_relative_IN; //  true if one considers a cluster target of the form |Psi[in]> = |N[CM] L[CM] rel> in HO basis for reactions, false if it is not the case

  const enum particle_type cluster_IN; // type of cluster target (proton, neutron, diproton, deuteron, 3He, alpha, Z3_N3 for 6Li, ...)
  
  const int NCM_HO_IN; // N[CM] in |Psi[in]> = |int N[CM] L[CM] rel> in HO basis (is_it_CM_relative_cluster true).

  const int LCM_IN; // L[CM] in |Psi[in]> = |int N[CM] L[CM] rel> in HO basis (is_it_CM_relative_cluster true)
  
  const double M_IN; // M-projection of |Psi[in]>
  
  const class correlated_state_str &PSI_IN_qn; // data containing the quantum numbers of |Psi[in]>

  A_dagger_cluster_PSI_str (
			    const bool full_common_vectors_used_in_file_c ,
			    const bool is_it_CM_relative_cluster_projectile_c , 
			    const enum particle_type cluster_projectile_c , 
			    const int NCM_HO_cluster_projectile_c , 
			    const int LCM_cluster_projectile_c , 
			    const double M_cluster_projectile_c ,
			    const class correlated_state_str &PSI_cluster_projectile_qn_c ,  
			    const bool is_it_CM_relative_IN_c , 
			    const enum particle_type cluster_IN_c ,   
			    const int NCM_HO_IN_c , 
			    const int LCM_IN_c , 
			    const double M_IN_c ,  
			    const class correlated_state_str &PSI_IN_qn_c);
};




class A_dagger_cluster_coupled_to_J_PSI_str 
{
public:

  const bool full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile;

  const enum particle_type cluster_projectile;

  const int NCM_HO_cluster_projectile;
  const int LCM_cluster_projectile;

  const class correlated_state_str &PSI_cluster_projectile_qn;
  
  const bool is_it_CM_relative_IN;

  const enum particle_type cluster_IN;
  
  const int NCM_HO_IN;
  const int LCM_IN;
  
  const class correlated_state_str &PSI_IN_qn;

  const double J_OUT;
  const double M_OUT;

  A_dagger_cluster_coupled_to_J_PSI_str (
					 const bool full_common_vectors_used_in_file_c ,
					 const bool is_it_CM_relative_cluster_projectile_c , 
					 const enum particle_type cluster_projectile_c , 
					 const int NCM_HO_cluster_projectile_c , 
					 const int LCM_cluster_projectile_c , 
					 const class correlated_state_str &PSI_cluster_projectile_qn_c , 
					 const bool is_it_CM_relative_IN_c ,  
					 const enum particle_type cluster_IN_c ,  
					 const int NCM_HO_IN_c , 
					 const int LCM_IN_c , 
					 const class correlated_state_str &PSI_IN_qn_c ,
					 const double J_OUT_c , 
					 const double M_OUT_c);
};



class A_cluster_PSI_str 
{
public:
  
  const bool full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile; 

  const enum particle_type cluster_projectile;

  const int NCM_HO_cluster_projectile;
  const int LCM_cluster_projectile;
  
  const double M_cluster_projectile;
  
  const class correlated_state_str &PSI_cluster_projectile_qn;
  
  const bool is_it_CM_relative_IN; 

  const enum particle_type cluster_IN;
  
  const int NCM_HO_IN;
  const int LCM_IN;  

  const double M_IN;  

  const class correlated_state_str &PSI_IN_qn;

  A_cluster_PSI_str (
		     const bool full_common_vectors_used_in_file_c ,
		     const bool is_it_CM_relative_cluster_projectile_c , 
		     const enum particle_type cluster_projectile_c , 
		     const int NCM_HO_cluster_projectile_c , 
		     const int LCM_cluster_projectile_c , 
		     const double M_cluster_projectile_c ,
		     const class correlated_state_str &PSI_cluster_projectile_qn_c , 
		     const bool is_it_CM_relative_IN_c , 
		     const enum particle_type cluster_IN_c ,  
		     const int NCM_HO_IN_c , 
		     const int LCM_IN_c , 
		     const double M_IN_c ,  
		     const class correlated_state_str &PSI_IN_qn_c);
};




class A_cluster_coupled_to_J_PSI_str 
{
public:
  
  const bool full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile;

  const enum particle_type cluster_projectile;

  const int NCM_HO_cluster_projectile;
  const int LCM_cluster_projectile;

  const class correlated_state_str &PSI_cluster_projectile_qn;
  
  const bool is_it_CM_relative_IN;

  const enum particle_type cluster_IN;
  
  const int NCM_HO_IN;
  const int LCM_IN;
  
  const class correlated_state_str &PSI_IN_qn;

  const double J_OUT;
  const double M_OUT;

  A_cluster_coupled_to_J_PSI_str (
				  const bool full_common_vectors_used_in_file_c ,
				  const bool is_it_CM_relative_cluster_projectile_c , 
				  const enum particle_type cluster_projectile_c , 
				  const int NCM_HO_cluster_projectile_c , 
				  const int LCM_cluster_projectile_c , 
				  const class correlated_state_str &PSI_cluster_projectile_qn_c , 
				  const bool is_it_CM_relative_IN_c , 
				  const enum particle_type cluster_IN_c , 
				  const int NCM_HO_IN_c , 
				  const int LCM_IN_c , 
				  const class correlated_state_str &PSI_IN_qn_c ,
				  const double J_OUT_c , 
				  const double M_OUT_c);
};






namespace A_dagger_cluster_helper
{  
  void A_dagger_PSI_IN_total_PSI_indices_components_calc_pn (
							     const class correlated_state_str &PSI_cluster_qn ,
							     const class correlated_state_str &PSI_IN_qn ,
							     const class GSM_vector_helper_class &GSM_vector_helper_OUT ,
							     const class array<unsigned int> &inSDp_tab ,
							     const class array<unsigned int> &inSDn_tab ,
							     const class array<unsigned int> &SDp_cluster_tab ,
							     const class array<unsigned int> &SDn_cluster_tab ,
							     const class array<TYPE> &PSI_IN_component_tab ,
							     const class array<TYPE> &PSI_cluster_component_tab ,
							     const class array<bool> &is_inSDp_in_new_space_tab ,
							     const class array<bool> &is_inSDn_in_new_space_tab ,
							     const class array<bool> &is_SDp_cluster_in_new_space_tab ,
							     const class array<bool> &is_SDn_cluster_in_new_space_tab ,
							     const class array<unsigned char> &reordering_bin_phases_p_IN ,
							     const class array<unsigned char> &reordering_bin_phases_n_IN ,
							     const class array<unsigned char> &reordering_bin_phases_p_cluster ,
							     const class array<unsigned char> &reordering_bin_phases_n_cluster ,
							     class array<unsigned int> &A_dagger_SD_cluster_PSI_IN_total_PSI_indices ,
							     class array<TYPE> &A_dagger_SD_cluster_PSI_IN_components);

  void A_dagger_PSI_IN_total_PSI_indices_components_calc_pp_nn (
								const class correlated_state_str &PSI_cluster_qn ,
								const class correlated_state_str &PSI_IN_qn ,
								const class GSM_vector_helper_class &GSM_vector_helper_OUT ,
								const class array<unsigned int> &inSD_tab ,
								const class array<unsigned int> &SD_cluster_tab ,
								const class array<TYPE> &PSI_IN_component_tab ,
								const class array<TYPE> &PSI_cluster_component_tab ,
								const class array<bool> &is_inSD_in_new_space_tab ,
								const class array<bool> &is_SD_cluster_in_new_space_tab ,
								const class array<unsigned char> &reordering_bin_phases_IN ,
								const class array<unsigned char> &reordering_bin_phases_cluster ,
								class array<unsigned int> &A_dagger_SD_cluster_PSI_IN_total_PSI_indices ,
								class array<TYPE> &A_dagger_SD_cluster_PSI_IN_components);
  
  void A_dagger_cluster_apply_add_pn (
				      const bool full_common_vectors_used_in_file , 
				      const bool is_it_CM_relative_cluster_projectile , 
				      const enum particle_type cluster_projectile ,
				      const int NCM_HO_cluster_projectile , 
				      const int LCM_cluster_projectile , 
				      const double M_cluster_projectile , 
				      const class correlated_state_str &PSI_cluster_projectile_qn ,
				      const bool is_it_CM_relative_IN ,  
				      const enum particle_type cluster_IN ,  
				      const int NCM_HO_IN , 
				      const int LCM_IN , 
				      const double M_IN , 
				      const class correlated_state_str &PSI_IN_qn ,
				      class GSM_vector &PSI_OUT);

  void A_dagger_cluster_apply_add_pp_nn (
					 const bool full_common_vectors_used_in_file , 
					 const bool is_it_CM_relative_cluster_projectile ,
					 const enum particle_type cluster_projectile , 
					 const int NCM_HO_cluster_projectile , 
					 const int LCM_cluster_projectile , 
					 const double M_cluster_projectile ,
					 const class correlated_state_str &PSI_cluster_projectile_qn ,  
					 const bool is_it_CM_relative_IN ,  
					 const enum particle_type cluster_IN ,  
					 const int NCM_HO_IN , 
					 const int LCM_IN , 
					 const double M_IN , 
					 const class correlated_state_str &PSI_IN_qn ,
					 class GSM_vector &PSI_OUT);
  
  void A_dagger_cluster_apply_add (
				   const bool full_common_vectors_used_in_file ,
				   const bool is_it_CM_relative_cluster_projectile , 
				   const enum particle_type cluster_projectile , 
				   const int NCM_HO_cluster_projectile , 
				   const int LCM_cluster_projectile , 
				   const double M_cluster_projectile , 
				   const class correlated_state_str &PSI_cluster_projectile_qn ,
				   const bool is_it_CM_relative_IN ,  
				   const enum particle_type cluster_IN ,   
				   const int NCM_HO_IN , 
				   const int LCM_IN , 
				   const double M_IN , 
				   const class correlated_state_str &PSI_IN_qn ,
				   class GSM_vector &PSI_OUT);
  
  void A_dagger_cluster_coupled_to_J_apply_add (
						const bool full_common_vectors_used_in_file ,
						const bool is_it_CM_relative_cluster_projectile , 
						const enum particle_type cluster_projectile , 
						const int NCM_HO_cluster_projectile , 
						const int LCM_cluster_projectile , 
						const class correlated_state_str &PSI_cluster_projectile_qn , 
						const bool is_it_CM_relative_IN ,  
						const enum particle_type cluster_IN ,   
						const int NCM_HO_IN , 
						const int LCM_IN , 
						const class correlated_state_str &PSI_IN_qn , 
						const double J_OUT , 
						class GSM_vector &PSI_OUT);

  void A_PSI_IN_total_PSI_indices_components_calc_pn (
						      const class correlated_state_str &PSI_cluster_qn ,
						      const class correlated_state_str &PSI_IN_qn ,
						      const class GSM_vector_helper_class &GSM_vector_helper_OUT ,
						      const class array<unsigned int> &inSDp_tab ,
						      const class array<unsigned int> &inSDn_tab ,
						      const class array<unsigned int> &SDp_cluster_tab ,
						      const class array<unsigned int> &SDn_cluster_tab ,
						      const class array<TYPE> &PSI_IN_component_tab ,
						      const class array<TYPE> &PSI_cluster_component_tab ,
						      const class array<bool> &is_inSDp_in_new_space_tab ,
						      const class array<bool> &is_inSDn_in_new_space_tab ,
						      const class array<bool> &is_SDp_cluster_in_new_space_tab ,
						      const class array<bool> &is_SDn_cluster_in_new_space_tab ,
						      const class array<unsigned char> &reordering_bin_phases_p_IN ,
						      const class array<unsigned char> &reordering_bin_phases_n_IN ,
						      const class array<unsigned char> &reordering_bin_phases_p_cluster ,
						      const class array<unsigned char> &reordering_bin_phases_n_cluster ,
						      class array<unsigned int> &A_SD_cluster_PSI_IN_total_PSI_indices ,
						      class array<TYPE> &A_SD_cluster_PSI_IN_components);

  void A_PSI_IN_total_PSI_indices_components_calc_pp_nn (
							 const class correlated_state_str &PSI_cluster_qn ,
							 const class correlated_state_str &PSI_IN_qn ,
							 const class GSM_vector_helper_class &GSM_vector_helper_OUT ,
							 const class array<unsigned int> &inSD_tab ,
							 const class array<unsigned int> &SD_cluster_tab ,
							 const class array<TYPE> &PSI_IN_component_tab ,
							 const class array<TYPE> &PSI_cluster_component_tab ,
							 const class array<bool> &is_inSD_in_new_space_tab ,
							 const class array<bool> &is_SD_cluster_in_new_space_tab ,
							 const class array<unsigned char> &reordering_bin_phases_IN ,
							 const class array<unsigned char> &reordering_bin_phases_cluster ,
							 class array<unsigned int> &A_SD_cluster_PSI_IN_total_PSI_indices ,
							 class array<TYPE> &A_SD_cluster_PSI_IN_components);
  
  void A_cluster_apply_add_pn (
			       const bool full_common_vectors_used_in_file , 
			       const bool is_it_CM_relative_cluster_projectile , 
			       const enum particle_type cluster_projectile , 
			       const int NCM_HO_cluster_projectile , 
			       const int LCM_cluster_projectile , 
			       const double M_cluster_projectile ,  
			       const class correlated_state_str &PSI_cluster_projectile_qn ,
			       const bool is_it_CM_relative_IN , 
			       const enum particle_type cluster_IN , 
			       const int NCM_HO_IN , 
			       const int LCM_IN , 
			       const double M_IN ,  
			       const class correlated_state_str &PSI_IN_qn ,
			       class GSM_vector &PSI_OUT);

  void A_cluster_apply_add_pp_nn (
				  const bool full_common_vectors_used_in_file ,
				  const bool is_it_CM_relative_cluster_projectile ,  
				  const enum particle_type cluster_projectile , 
				  const int NCM_HO_cluster_projectile , 
				  const int LCM_cluster_projectile , 
				  const double M_cluster_projectile ,  
				  const class correlated_state_str &PSI_cluster_projectile_qn ,
				  const bool is_it_CM_relative_IN , 
				  const enum particle_type cluster_IN , 
				  const int NCM_HO_IN , 
				  const int LCM_IN , 
				  const double M_IN ,  
				  const class correlated_state_str &PSI_IN_qn ,
				  class GSM_vector &PSI_OUT);
  
  void A_cluster_apply_add (
			    const bool full_common_vectors_used_in_file ,
			    const bool is_it_CM_relative_cluster_projectile , 
			    const enum particle_type cluster_projectile , 
			    const int NCM_HO_cluster_projectile , 
			    const int LCM_cluster_projectile , 
			    const double M_cluster_projectile , 
			    const class correlated_state_str &PSI_cluster_projectile_qn ,
			    const bool is_it_CM_relative_IN , 
			    const enum particle_type cluster_IN ,  
			    const int NCM_HO_IN , 
			    const int LCM_IN , 
			    const double M_IN ,  
			    const class correlated_state_str &PSI_IN_qn ,
			    class GSM_vector &PSI_OUT);
  
  void A_cluster_coupled_to_J_apply_add (
					 const bool full_common_vectors_used_in_file ,
					 const bool is_it_CM_relative_cluster_projectile , 
					 const enum particle_type cluster_projectile , 
					 const int NCM_HO_cluster_projectile , 
					 const int LCM_cluster_projectile , 
					 const class correlated_state_str &PSI_cluster_projectile_qn , 
					 const bool is_it_CM_relative_IN , 
					 const enum particle_type cluster_IN ,  
					 const int NCM_HO_IN , 
					 const int LCM_IN , 
					 const class correlated_state_str &PSI_IN_qn , 
					 const double J_OUT , 
					 class GSM_vector &PSI_OUT);
  
  class A_dagger_cluster_PSI_str A_dagger_cluster (
						   const bool full_common_vectors_used_in_file ,
						   const bool is_it_CM_relative_cluster_projectile_c , 
						   const enum particle_type cluster_projectile_c , 
						   const int NCM_HO_cluster_projectile_c , 
						   const int LCM_cluster_projectile_c , 
						   const double M_cluster_projectile_c , 
						   const class correlated_state_str &PSI_cluster_projectile_qn_c , 
						   const bool is_it_CM_relative_IN_c , 
						   const enum particle_type cluster_IN_c ,   
						   const int NCM_HO_IN_c , 
						   const int LCM_IN_c , 
						   const double M_IN_c ,  
						   const class correlated_state_str &PSI_IN_qn_c);
  
  
  class A_dagger_cluster_coupled_to_J_PSI_str A_dagger_cluster_coupled_to_J (
									     const bool full_common_vectors_used_in_file_c ,
									     const bool is_it_CM_relative_cluster_projectile_c , 
									     const enum particle_type cluster_projectile_c , 
									     const int NCM_HO_cluster_projectile_c , 
									     const int LCM_cluster_projectile_c ,
									     const class correlated_state_str &PSI_cluster_projectile_qn_c ,  
									     const bool is_it_CM_relative_IN_c , 
									     const enum particle_type cluster_IN_c ,   
									     const int NCM_HO_IN_c , 
									     const int LCM_IN_c , 
									     const class correlated_state_str &PSI_IN_qn_c ,
									     const double J_OUT_c , 
									     const double M_OUT_c);
  
  class A_cluster_coupled_to_J_PSI_str A_cluster_coupled_to_J (
							       const bool full_common_vectors_used_in_file_c ,
							       const bool is_it_CM_relative_cluster_projectile_c , 
							       const enum particle_type cluster_projectile_c , 
							       const int NCM_HO_cluster_projectile_c , 
							       const int LCM_cluster_projectile_c ,
							       const class correlated_state_str &PSI_cluster_projectile_qn_c , 
							       const bool is_it_CM_relative_IN_c , 
							       const enum particle_type cluster_IN_c ,  
							       const int NCM_HO_IN_c , 
							       const int LCM_IN_c , 
							       const class correlated_state_str &PSI_IN_qn_c ,
							       const double J_OUT_c , 
							       const double M_OUT_c);
  
  class A_cluster_PSI_str A_cluster (
				     const bool full_common_vectors_used_in_file_c ,
				     const bool is_it_CM_relative_cluster_projectile_c , 
				     const enum particle_type cluster_projectile_c , 
				     const int NCM_HO_cluster_projectile_c , 
				     const int LCM_cluster_projectile_c , 
				     const double M_cluster_projectile_c ,
				     const class correlated_state_str &PSI_cluster_projectile_qn_c , 
				     const bool is_it_CM_relative_IN_c , 
				     const enum particle_type cluster_IN_c ,  
				     const int NCM_HO_IN_c , 
				     const int LCM_IN_c , 
				     const double M_IN_c ,  
				     const class correlated_state_str &PSI_IN_qn_c);
}








class x_A_dagger_cluster_PSI_str
{
public:

  const TYPE x;
  const class A_dagger_cluster_PSI_str &A_dagger_cluster_PSI;

  x_A_dagger_cluster_PSI_str (const TYPE &x_c , const class A_dagger_cluster_PSI_str &A_dagger_cluster_c);
};

class x_A_dagger_cluster_PSI_str operator + (const class A_dagger_cluster_PSI_str &A_dagger_PSI);
class x_A_dagger_cluster_PSI_str operator - (const class A_dagger_cluster_PSI_str &A_dagger_PSI);

class x_A_dagger_cluster_PSI_str operator * (const class A_dagger_cluster_PSI_str &A_dagger_PSI , const double x);
class x_A_dagger_cluster_PSI_str operator * (const double x , const class A_dagger_cluster_PSI_str &A_dagger_PSI);
class x_A_dagger_cluster_PSI_str operator / (const class A_dagger_cluster_PSI_str &A_dagger_PSI , const double x);

class x_A_dagger_cluster_PSI_str operator + (const class x_A_dagger_cluster_PSI_str &x_A_dagger_PSI);
class x_A_dagger_cluster_PSI_str operator - (const class x_A_dagger_cluster_PSI_str &x_A_dagger_PSI);

class x_A_dagger_cluster_PSI_str operator * (const class A_dagger_cluster_PSI_str &A_dagger_PSI , const complex<double> &x);
class x_A_dagger_cluster_PSI_str operator * (const complex<double> &x , const class A_dagger_cluster_PSI_str &A_dagger_PSI);
class x_A_dagger_cluster_PSI_str operator / (const class A_dagger_cluster_PSI_str &A_dagger_PSI , const complex<double> &x);





class x_A_dagger_cluster_coupled_to_J_PSI_str
{
public:

  const TYPE x;
  const class A_dagger_cluster_coupled_to_J_PSI_str &A_dagger_cluster_coupled_to_J_PSI;

  x_A_dagger_cluster_coupled_to_J_PSI_str (const TYPE &x_c , const class A_dagger_cluster_coupled_to_J_PSI_str &A_dagger_cluster_coupled_to_J_c);
};

class x_A_dagger_cluster_coupled_to_J_PSI_str operator + (const class A_dagger_cluster_coupled_to_J_PSI_str &a_plus_coupled_to_J_PSI);
class x_A_dagger_cluster_coupled_to_J_PSI_str operator - (const class A_dagger_cluster_coupled_to_J_PSI_str &a_plus_coupled_to_J_PSI);

class x_A_dagger_cluster_coupled_to_J_PSI_str operator * (const class A_dagger_cluster_coupled_to_J_PSI_str &a_plus_coupled_to_J_PSI , const double x);
class x_A_dagger_cluster_coupled_to_J_PSI_str operator * (const double x , const class A_dagger_cluster_coupled_to_J_PSI_str &a_plus_coupled_to_J_PSI);
class x_A_dagger_cluster_coupled_to_J_PSI_str operator / (const class A_dagger_cluster_coupled_to_J_PSI_str &a_plus_coupled_to_J_PSI , const double x);

class x_A_dagger_cluster_coupled_to_J_PSI_str operator + (const class x_A_dagger_cluster_coupled_to_J_PSI_str &x_a_plus_coupled_to_J_PSI);
class x_A_dagger_cluster_coupled_to_J_PSI_str operator - (const class x_A_dagger_cluster_coupled_to_J_PSI_str &x_a_plus_coupled_to_J_PSI);

class x_A_dagger_cluster_coupled_to_J_PSI_str operator * (const class A_dagger_cluster_coupled_to_J_PSI_str &a_plus_coupled_to_J_PSI , const complex<double> &x);
class x_A_dagger_cluster_coupled_to_J_PSI_str operator * (const complex<double> &x , const class A_dagger_cluster_coupled_to_J_PSI_str &a_plus_coupled_to_J_PSI);
class x_A_dagger_cluster_coupled_to_J_PSI_str operator / (const class A_dagger_cluster_coupled_to_J_PSI_str &a_plus_coupled_to_J_PSI , const complex<double> &x);









class x_A_cluster_PSI_str
{
public:

  const TYPE x;
  const class A_cluster_PSI_str &A_cluster_PSI;

  x_A_cluster_PSI_str (const TYPE &x_c , const class A_cluster_PSI_str &A_cluster_c);
};

class x_A_cluster_PSI_str operator + (const class A_cluster_PSI_str &A_dagger_PSI);
class x_A_cluster_PSI_str operator - (const class A_cluster_PSI_str &A_dagger_PSI);

class x_A_cluster_PSI_str operator * (const class A_cluster_PSI_str &A_dagger_PSI , const double x);
class x_A_cluster_PSI_str operator * (const double x , const class A_cluster_PSI_str &A_dagger_PSI);
class x_A_cluster_PSI_str operator / (const class A_cluster_PSI_str &A_dagger_PSI , const double x);

class x_A_cluster_PSI_str operator + (const class x_A_cluster_PSI_str &x_A_dagger_PSI);
class x_A_cluster_PSI_str operator - (const class x_A_cluster_PSI_str &x_A_dagger_PSI);

class x_A_cluster_PSI_str operator * (const class A_cluster_PSI_str &A_dagger_PSI , const complex<double> &x);
class x_A_cluster_PSI_str operator * (const complex<double> &x , const class A_cluster_PSI_str &A_dagger_PSI);
class x_A_cluster_PSI_str operator / (const class A_cluster_PSI_str &A_dagger_PSI , const complex<double> &x);






class x_A_cluster_coupled_to_J_PSI_str
{
public:

  const TYPE x;
  const class A_cluster_coupled_to_J_PSI_str &A_cluster_coupled_to_J_PSI;

  x_A_cluster_coupled_to_J_PSI_str (const TYPE &x_c , const class A_cluster_coupled_to_J_PSI_str &A_cluster_coupled_to_J_c);
};

class x_A_cluster_coupled_to_J_PSI_str operator + (const class A_cluster_coupled_to_J_PSI_str &a_plus_coupled_to_J_PSI);
class x_A_cluster_coupled_to_J_PSI_str operator - (const class A_cluster_coupled_to_J_PSI_str &a_plus_coupled_to_J_PSI);

class x_A_cluster_coupled_to_J_PSI_str operator * (const class A_cluster_coupled_to_J_PSI_str &a_plus_coupled_to_J_PSI , const double x);
class x_A_cluster_coupled_to_J_PSI_str operator * (const double x , const class A_cluster_coupled_to_J_PSI_str &a_plus_coupled_to_J_PSI);
class x_A_cluster_coupled_to_J_PSI_str operator / (const class A_cluster_coupled_to_J_PSI_str &a_plus_coupled_to_J_PSI , const double x);

class x_A_cluster_coupled_to_J_PSI_str operator + (const class x_A_cluster_coupled_to_J_PSI_str &x_a_plus_coupled_to_J_PSI);
class x_A_cluster_coupled_to_J_PSI_str operator - (const class x_A_cluster_coupled_to_J_PSI_str &x_a_plus_coupled_to_J_PSI);

class x_A_cluster_coupled_to_J_PSI_str operator * (const class A_cluster_coupled_to_J_PSI_str &a_plus_coupled_to_J_PSI , const complex<double> &x);
class x_A_cluster_coupled_to_J_PSI_str operator * (const complex<double> &x , const class A_cluster_coupled_to_J_PSI_str &a_plus_coupled_to_J_PSI);
class x_A_cluster_coupled_to_J_PSI_str operator / (const class A_cluster_coupled_to_J_PSI_str &a_plus_coupled_to_J_PSI , const complex<double> &x);



#endif


