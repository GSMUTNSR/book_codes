#ifndef GSMCONFIGURATIONSDINSPACEONEJUMPOUTTOIN_H
#define GSMCONFIGURATIONSDINSPACEONEJUMPOUTTOIN_H

// TYPE is double or complex
// -------------------------

namespace configuration_SD_in_space_one_jump_out_to_in
{
  void is_configuration_in_inSD_BPin_iMin_in_space_pp_nn_determine (
								    const class GSM_vector_helper_class &GSM_vector_helper_in , 
								    class nucleons_data &particles_data);
    
  void is_configuration_out_outSD_in_space_pp_nn_determine (
							    const class GSM_vector_helper_class &GSM_vector_helper_out , 
							    class nucleons_data &particles_data);

  void is_configuration_in_inSD_BPin_iMin_in_space_pn_determine (
								 const class GSM_vector_helper_class &GSM_vector_helper_in , 
								 class nucleons_data &prot_data , 
								 class nucleons_data &neut_data);
    
  void is_configuration_out_outSD_in_space_pn_determine (
							 const class GSM_vector_helper_class &GSM_vector_helper_out , 
							 class nucleons_data &prot_data , 
							 class nucleons_data &neut_data);

  void is_configuration_out_outSD_in_space_pn_SD_set_determine (
								const class GSM_vector_helper_class &GSM_vector_helper_out , 
								class nucleons_data &particles_data);
	
  void is_configuration_out_outSD_in_space_pn_PSI_determine (
							     const class GSM_vector_helper_class &GSM_vector_helper_out , 
							     class nucleons_data &prot_data , 
							     class nucleons_data &neut_data);
	
  void is_it_configuration_inter_to_include_determine_all_configurations (
									  const bool is_it_pole_approximation , 
									  class nucleons_data &particles_data);

  bool is_it_SD_inter_to_include_fixed_configuration_in_determine (
								   const class configuration &C_out , 
								   const class Slater_determinant &outSD ,
								   const int M_jump , 
								   const unsigned int C_in_jump_shell , 
								   const unsigned int C_out_jump_shell , 
								   class nucleons_data &particles_data);

  void is_it_SD_inter_to_include_determine_all_SDs (
						    const bool is_it_pole_approximation , 
						    class nucleons_data &particles_data);

  void configuration_SD_in_space_one_jump_tables_init (
						       class nucleons_data &prot_data , 
						       class nucleons_data &neut_data);

  void SD_in_out_int_spaces_indices_alloc_calc (const bool is_it_pole_approximation ,
						const enum operation_type operation ,
						class nucleons_data &particles_data);
 
  void one_jump_tables_alloc_calc_pp_nn (
					 const bool is_there_cout , 
					 const bool is_it_one_body ,
					 const bool is_it_two_body_pn_only , 
					 const bool is_it_pole_approximation ,  
					 const bool is_J2_applied , 
					 const bool truncation_hw , 
					 const bool truncation_ph , 
					 class nucleons_data &particles_data);

  void configuration_SD_in_in_space_determine (
					       const bool is_L2_CM_J2_applied , 
					       const class GSM_vector_helper_class &GSM_vector_helper_in , 
					       const class GSM_vector_helper_class &GSM_vector_helper_Mp1 , 
					       class nucleons_data &prot_data , 
					       class nucleons_data &neut_data);

  void configuration_SD_out_in_space_determine (
						const bool is_L2_CM_J2_applied , 
						const class GSM_vector_helper_class &GSM_vector_helper_out , 
						const class GSM_vector_helper_class &GSM_vector_helper_Mp1 , 
						class nucleons_data &prot_data , 
						class nucleons_data &neut_data);
    
  void configuration_SD_in_out_in_space_one_jump_tables_alloc_calc_Jpm (
									const bool is_there_cout ,
									const int pm , 
									const class GSM_vector_helper_class &GSM_vector_helper_in , 
									const class GSM_vector_helper_class &GSM_vector_helper_out , 
									class nucleons_data &prot_data , 
									class nucleons_data &neut_data);
     
  void configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (
								    const bool is_there_cout , 
								    const bool is_it_one_body ,
								    const bool is_it_two_body_pn_only , 
								    const bool is_J2_applied ,
								    const bool is_L2_CM_applied ,
								    const class GSM_vector_helper_class &GSM_vector_helper_in , 
								    const class GSM_vector_helper_class &GSM_vector_helper_out , 
								    const class GSM_vector_helper_class &GSM_vector_helper_Mp1 , 
								    class nucleons_data &prot_data , 
								    class nucleons_data &neut_data);
}

#endif


