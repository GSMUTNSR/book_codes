#ifndef GSMHONECONFIGURATIONCLASS_H
#define GSMHONECONFIGURATIONCLASS_H

// TYPE is double or complex
// -------------------------

class H_one_configuration_class
{
public:
  
  H_one_configuration_class ();
  
  H_one_configuration_class (
			     const class GSM_vector_helper_one_configuration_class &GSM_vector_helper ,
			     const class TBMEs_class &TBMEs_pn , 
			     const double J_c);

  H_one_configuration_class (const class H_one_configuration_class &X);

  ~H_one_configuration_class ();

  void allocate (
		 const class GSM_vector_helper_one_configuration_class &GSM_vector_helper ,
		 const class TBMEs_class &TBMEs_pn , 
		 const double J_c);

  void allocate_fill (const class H_one_configuration_class &X);

  void deallocate ();
  
  bool is_it_filled () const;

  double non_zero_NBMEs_proportion_calc () const;

  void apply_add (
		  const class GSM_vector_one_configuration &PSI_in , 
		  const TYPE &alpha , 
		  class GSM_vector_one_configuration &PSI_out) const;

  void print () const;
		
  const class GSM_vector_helper_one_configuration_class & get_GSM_vector_helper () const
  {
    return *GSM_vector_helper_ptr;
  }

  const class TBMEs_class & get_TBMEs_pn () const
  {
    return *TBMEs_pn_ptr;
  }

  friend double used_memory_calc (const class H_one_configuration_class &T);
  
private:
  
  unsigned int non_zero_NBMEs_number_diagonal_part_calc () const;

  unsigned int non_zero_NBMEs_number_component_part_jump_p_calc (
								 const int n_scat_n , 
								 const int En , 
								 const class jumps_data_out_to_in_str &jump_p) const;

  unsigned int non_zero_NBMEs_number_component_part_jump_n_calc (
								 const int n_scat_p , 
								 const int Ep , 
								 const class jumps_data_out_to_in_str &jump_n) const;

  void non_zero_NBMEs_numbers_jumps_p_part_pn_calc ();
  void non_zero_NBMEs_numbers_jumps_n_part_pn_calc ();
  void non_zero_NBMEs_numbers_two_jumps_pn_part_pn_calc ();
  void non_zero_NBMEs_numbers_off_diagonal_pp_nn_calc ();
  void rows_non_zero_NBMEs_off_diagonal_numbers_calc ();

  void diagonal_part_pn_prot_part_calc ();
  void diagonal_part_pn_neut_part_calc ();
  void diagonal_part_pn_pn_part_calc ();

  void NBMEs_jumps_pp_nn_calc_store (
				     const unsigned int BPmu , 
				     const unsigned int iCmu , 
				     const int iMmu , 
				     const unsigned int outSDmu_index , 
				     const class Slater_determinant &outSDmu , 
				     const class nucleons_data &data , 
				     bool &is_there_one_jump_calc , 
				     bool &is_there_two_jumps_calc , 
				     class jumps_data_out_to_in_str &one_jump_mu , 
				     class jumps_data_out_to_in_str &two_jumps_mu , 
				     class array<TYPE> &NBMEs_one_jump_mu_no_phase , 
				     class array<TYPE> &NBMEs_two_jumps_mu) const;

  void Hamiltonian_part_jumps_store (
				     const class jumps_data_out_to_in_str &jump , 
				     const class array<unsigned int> &PSI_in_indices , 
				     const class array<TYPE> &NBMEs_jump , 
				     const unsigned int PSI_out_index);

  void jumps_p_prot_part_pn_calc_store (class array<unsigned int> &one_jump_start_non_zero_NBMEs_indices);
  void jumps_n_neut_part_pn_calc_store (class array<unsigned int> &one_jump_start_non_zero_NBMEs_indices);

  void one_jump_p_pn_part_pn_calc_store (const class array<unsigned int> &one_jump_start_non_zero_NBMEs_indices);
  void one_jump_n_pn_part_pn_calc_store (const class array<unsigned int> &one_jump_start_non_zero_NBMEs_indices);

  void two_jumps_pn_part_pn_calc_store ();

  void diagonal_part_pp_nn_calc ();
  void jumps_part_pp_nn_calc_store ();

  void matrix_off_diagonal_store ();

  void apply_add_off_diagonal_full_storage (
					    const class GSM_vector_one_configuration &PSI_in , 
					    class GSM_vector_one_configuration &PSI_out) const;
  
  double J; // total angular momentum of the considered many body wave function
  
  const class GSM_vector_helper_one_configuration_class *GSM_vector_helper_ptr; // pointer to data necessary to handle |Psi[in]> and |Psi[out]>. It does not contain their vector components.

  const class TBMEs_class *TBMEs_pn_ptr; // pointer to class containing coupled pn TBMEs
  
  class array<TYPE> H_diagonal_tab; // diagonal NBMEs of H
  
  class array<unsigned int> rows_non_zero_NBMEs_numbers;   // number of non-zeros NBMEs per row

  class array<unsigned int> rows_non_zero_NBMEs_PSI_in_indices; // indices of the SDs of |Psi[in]> leading to non-zeros NBMEs per row
  
  class array<TYPE> rows_non_zero_NBMEs; // non-zeros NBMEs per row
};






class xH_one_configuration_plus_alpha_str
{
public:

  const TYPE x;
  const TYPE alpha;

  const class H_one_configuration_class &H;

  xH_one_configuration_plus_alpha_str (const TYPE &x_c , const TYPE &alpha_c , const class H_one_configuration_class &H_c);
};

class xH_one_configuration_plus_alpha_str operator + (const class H_one_configuration_class &H);
class xH_one_configuration_plus_alpha_str operator - (const class H_one_configuration_class &H);

class xH_one_configuration_plus_alpha_str operator + (const class H_one_configuration_class &H , const double term);
class xH_one_configuration_plus_alpha_str operator - (const class H_one_configuration_class &H , const double term);

class xH_one_configuration_plus_alpha_str operator + (const double term , const class H_one_configuration_class &H);
class xH_one_configuration_plus_alpha_str operator - (const double term , const class H_one_configuration_class &H);

class xH_one_configuration_plus_alpha_str operator * (const class H_one_configuration_class &H , const double x);
class xH_one_configuration_plus_alpha_str operator * (const double x , const class H_one_configuration_class &H);
class xH_one_configuration_plus_alpha_str operator / (const class H_one_configuration_class &H , const double x);

class xH_one_configuration_plus_alpha_str operator + (const class xH_one_configuration_plus_alpha_str &Op);
class xH_one_configuration_plus_alpha_str operator - (const class xH_one_configuration_plus_alpha_str &Op);

class xH_one_configuration_plus_alpha_str operator + (const class xH_one_configuration_plus_alpha_str &Op , const double term);
class xH_one_configuration_plus_alpha_str operator - (const class xH_one_configuration_plus_alpha_str &Op , const double term);

class xH_one_configuration_plus_alpha_str operator + (const double alpha , const class xH_one_configuration_plus_alpha_str &Op);
class xH_one_configuration_plus_alpha_str operator - (const double alpha , const class xH_one_configuration_plus_alpha_str &Op);

class xH_one_configuration_plus_alpha_str operator * (const class xH_one_configuration_plus_alpha_str &Op , const double factor);
class xH_one_configuration_plus_alpha_str operator / (const class xH_one_configuration_plus_alpha_str &Op , const double factor);

class xH_one_configuration_plus_alpha_str operator + (const class H_one_configuration_class &H , const complex<double> &term);
class xH_one_configuration_plus_alpha_str operator - (const class H_one_configuration_class &H , const complex<double> &term);

class xH_one_configuration_plus_alpha_str operator + (const complex<double> &term , const class H_one_configuration_class &H);
class xH_one_configuration_plus_alpha_str operator - (const complex<double> &term , const class H_one_configuration_class &H);

class xH_one_configuration_plus_alpha_str operator * (const class H_one_configuration_class &H , const complex<double> &x);
class xH_one_configuration_plus_alpha_str operator * (const complex<double> &x , const class H_one_configuration_class &H);
class xH_one_configuration_plus_alpha_str operator / (const class H_one_configuration_class &H , const complex<double> &x);

class xH_one_configuration_plus_alpha_str operator + (const class xH_one_configuration_plus_alpha_str &Op , const complex<double> &term);
class xH_one_configuration_plus_alpha_str operator - (const class xH_one_configuration_plus_alpha_str &Op , const complex<double> &term);

class xH_one_configuration_plus_alpha_str operator + (const complex<double> &alpha , const class xH_one_configuration_plus_alpha_str &Op);
class xH_one_configuration_plus_alpha_str operator - (const complex<double> &alpha , const class xH_one_configuration_plus_alpha_str &Op);

class xH_one_configuration_plus_alpha_str operator * (const class xH_one_configuration_plus_alpha_str &Op , const complex<double> &factor);
class xH_one_configuration_plus_alpha_str operator / (const class xH_one_configuration_plus_alpha_str &Op , const complex<double> &factor);

#endif


