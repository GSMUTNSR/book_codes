#ifndef GSMCONFIGURATIONSDINSPACEONEJUMPONLYBASIS_H
#define GSMCONFIGURATIONSDINSPACEONEJUMPONLYBASIS_H

// TYPE is double or complex
// -------------------------

namespace configuration_SD_in_space_one_jump_only_basis
{
  void is_configuration_in_out_BPin_iMin_inSD_outSD_in_space_pp_nn_determine (
									      const class GSM_vector_helper_one_configuration_class &GSM_vector_helper , 
									      class baryons_data &particles_data);

  void is_configuration_in_out_BPin_iMin_inSD_outSD_in_space_pn_determine (
									   const class GSM_vector_helper_one_configuration_class &GSM_vector_helper , 
									   class baryons_data &prot_Y_data , 
									   class baryons_data &neut_Y_data);

  void one_jump_tables_alloc_calc_pp_nn (class baryons_data &particles_data);

  void configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (
								    const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_M , 
								    const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_Mp1 , 
								    class baryons_data &prot_Y_data ,
								    class baryons_data &neut_Y_data);
}

#endif


