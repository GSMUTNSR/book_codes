#ifndef GSMCONFIGURATIONONEJUMPCONSTRUCTIONSETINTOOUT_H
#define GSMCONFIGURATIONONEJUMPCONSTRUCTIONSETINTOOUT_H

// TYPE is double or complex
// -------------------------

namespace configuration_one_jump_construction_set_in_to_out
{
  void configuration_one_jump_data_fill (
					 const bool is_it_one_body_two_body_pn , 
					 const enum operation_type operation , 
					 const bool is_configuration_in_in_space , 
					 const unsigned int BP_out , 
					 const int n_holes_out , 
					 const int n_scat_out , 
					 const unsigned int C_in_jump_shell , 
					 const unsigned int C_out_jump_shell , 
					 const unsigned int SD_eq_configuration_one_jump_index , 
					 const unsigned int configuration_one_jump_table_zero_index , 
					 const unsigned int dimensions_configuration_one_jump_table_index ,
					 const class configuration &C_out , 	
					 class configuration &C_try , 	
					 class nucleons_data &particles_data);
    
  void configuration_one_jump_all_C_out (
					 const bool is_it_only_basis , 
					 const bool is_it_one_body_two_body_pn , 
					 const enum operation_type operation , 
					 const bool truncation_hw , 
					 const bool truncation_ph , 
					 const bool is_it_pole_approximation , 
					 const int n_holes_in ,  
					 const int n_scat_in , 
					 const int E_hw_in , 
					 const class configuration &C_in , 
					 const unsigned int configuration_one_jump_table_zero_index , 
					 const unsigned int dimensions_configuration_one_jump_table_index , 
					 const bool is_configuration_in_in_space , 
					 const unsigned int BP_out , 
					 const unsigned int BP_jump , 
					 class configuration &C_out , 	
					 class configuration &C_try , 	
					 unsigned int &SD_eq_configuration_one_jump_index , 
					 bool &first_configuration_one_jump_for_C_in ,
					 class nucleons_data &particles_data);
    
  void all_configurations_one_jump_all_configurations (
						       const bool is_it_only_basis , 
						       const bool is_it_one_body_two_body_pn , 
						       const enum operation_type operation , 
						       const bool truncation_hw , 
						       const bool truncation_ph , 
						       const bool is_it_pole_approximation , 
						       class nucleons_data &particles_data);
    
  void all_configurations_one_jump_all_configurations_alloc_calc (
								  const bool is_there_cout , 
								  const bool is_it_only_basis , 
								  const bool is_it_one_body_two_body_pn ,
								  const bool truncation_hw , 
								  const bool truncation_ph , 
								  const bool is_it_pole_approximation , 
								  class nucleons_data &particles_data);  
}
#endif



