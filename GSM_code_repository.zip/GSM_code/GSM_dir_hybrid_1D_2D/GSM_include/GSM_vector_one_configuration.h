#ifndef GSMVECTORONECONFIGURATION_H
#define GSMVECTORONECONFIGURATION_H

// TYPE is double or complex
// -------------------------

class GSM_vector_one_configuration
{
public:

  GSM_vector_one_configuration ();
  
  explicit GSM_vector_one_configuration (const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_c);

  GSM_vector_one_configuration (const class GSM_vector_one_configuration &V);
  GSM_vector_one_configuration (const class Op_PSI_one_configuration_closure_str &);
  
  ~GSM_vector_one_configuration ();

  void allocate (const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_c);

  void allocate_fill (const class GSM_vector_one_configuration &V);
  void allocate_calc (const class Op_PSI_one_configuration_closure_str &);

  void deallocate ();

  bool is_it_filled () const
  {
    return (table != NULL);
  }
  
  unsigned int get_space_dimension () const
  {
    return space_dimension;
  }
  
  const class GSM_vector_helper_one_configuration_class & get_GSM_vector_helper () const
  {
    return *GSM_vector_helper_ptr;
  }
  
  const class GSM_vector_one_configuration & operator = (const class GSM_vector_one_configuration &);
  const class GSM_vector_one_configuration & operator = (const complex<double> &x);
  const class GSM_vector_one_configuration & operator = (const double x);
  const class GSM_vector_one_configuration & operator = (const class Op_PSI_one_configuration_closure_str &);

  class GSM_vector_one_configuration & operator += (const class GSM_vector_one_configuration &);
  class GSM_vector_one_configuration & operator += (const TYPE &x);
  class GSM_vector_one_configuration & operator += (const class Op_PSI_one_configuration_closure_str &);

  class GSM_vector_one_configuration & operator -= (const class GSM_vector_one_configuration &);
  class GSM_vector_one_configuration & operator -= (const TYPE &x);
  class GSM_vector_one_configuration & operator -= (const class Op_PSI_one_configuration_closure_str &);

  class GSM_vector_one_configuration & operator *= (const TYPE &x);
  class GSM_vector_one_configuration & operator /= (const TYPE &x);

  TYPE & operator [] (const unsigned int i) const;

  double infinite_norm () const;
  void normalization ();
  void random_vector ();

  void good_J (
	       const class J2_one_configuration_class &J2 ,
	       const double J);
		
  void good_phase ();
		
  void copy_disk (const string &file_name) const;

  void read_disk (const string &file_name);

  class Slater_determinant basis_SD_from_index (
						const enum space_type basis_space ,
						const unsigned int total_index) const;

  void print () const;

  void orthogonalization (
			  const unsigned int i ,
			  const class array<class GSM_vector_one_configuration> &V_tab);

  void pivot_init (
		   const double J ,
		   const class J2_one_configuration_class &J2);

  void TRS_rest_part_fill (const double J);

  void opposite ();

  void diagonal_part_PSI_add (
			      const class GSM_vector_one_configuration &PSI , 
			      const class array<TYPE> &diagonal_tab , 
			      const TYPE &alpha);

  bool same_parity_M_projection (const class GSM_vector_one_configuration &PSI) const;
  bool same_parity_M_projection (const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_PSI) const;
  
  friend double used_memory_calc (const class GSM_vector_one_configuration &T);
  
private:

  class Slater_determinant basis_SD_from_index_pn    (const enum space_type basis_space , const unsigned int total_index) const;
  class Slater_determinant basis_SD_from_index_pp_nn (const enum space_type basis_space , const unsigned int total_index) const;

  void print_pn () const;
  void print_pp_nn () const;

  unsigned int space_dimension; // dimension of the GSM vector
  
  const class GSM_vector_helper_one_configuration_class *GSM_vector_helper_ptr; // pointer to data necessary to handle the GSM vector. It does not contain their vector components.
  
  TYPE *table; // array of vector components
};

TYPE operator* (const class GSM_vector_one_configuration &X , const class GSM_vector_one_configuration &Y);

istream & operator >> (istream &is , class GSM_vector_one_configuration &PSI);
ostream & operator << (ostream &os , const class GSM_vector_one_configuration &PSI);











class Op_PSI_one_configuration_closure_str
{
public:

  Op_PSI_one_configuration_closure_str (const unsigned int closure_terms_number_c);
  Op_PSI_one_configuration_closure_str (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure_old);
  Op_PSI_one_configuration_closure_str (const class GSM_vector_one_configuration &);

  bool is_it_filled () const
  {
    return (PSI_in_ptrs[0] != NULL);
  }
  
  const class Op_PSI_one_configuration_closure_str & operator = (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure);

  unsigned int get_closure_terms_number () const;
  enum operator_type get_Op (const unsigned int index) const;
  TYPE get_x (const unsigned int index) const;
  TYPE get_alpha (const unsigned int index) const;

  const class H_one_configuration_class & get_H (const unsigned int index) const;
  const class Jpm_one_configuration_class & get_Jpm (const unsigned int index) const;
  const class J2_one_configuration_class & get_J2 (const unsigned int index) const;
  const class GSM_vector_one_configuration & get_PSI_in (const unsigned int index) const;

  void default_values_init ();

  void fill_data (
		  const enum operator_type Op , 
		  const TYPE x , 
		  const TYPE alpha , 
		  const void *const Op_ptr , 
		  const class GSM_vector_one_configuration *const PSI_in_ptr , 
		  const unsigned int index);

  void fill_data (
		  const class Op_PSI_one_configuration_closure_str &Op_PSI_closure , 
		  const unsigned int i , 
		  const unsigned int index);

  bool is_it_only_scalar_identity () const;

  void sign_change (const unsigned int index);

  void global_sign_change ();

  void factor_multiplication (const unsigned int index , const TYPE &factor);
	
  void global_factor_multiplication (const TYPE &factor);

  const class GSM_vector_helper_one_configuration_class & GSM_vector_helper_determine () const;

  bool is_PSI_out_used (const class GSM_vector_one_configuration &PSI_out) const;

  void all_Op_PSI_in_calc_add (class GSM_vector_one_configuration &PSI_out) const;

  class Op_PSI_one_configuration_closure_str operator_times_scalar_identity (
									     const enum operator_type Op , 
									     const TYPE x_Op , 
									     const TYPE alpha_Op ,  
									     const void *const Op_ptr) const;

private:

  unsigned int closure_terms_number;

  enum operator_type Op_tab[CLOSURE_TERMS_MAX];

  TYPE x_tab[CLOSURE_TERMS_MAX];
  
  TYPE alpha_tab[CLOSURE_TERMS_MAX];

  const void * Op_ptrs[CLOSURE_TERMS_MAX];
  
  const GSM_vector_one_configuration * PSI_in_ptrs[CLOSURE_TERMS_MAX];
};

class Op_PSI_one_configuration_closure_str operator * (const class H_one_configuration_class &H , const class GSM_vector_one_configuration &PSI_in);
class Op_PSI_one_configuration_closure_str operator * (const class Jpm_one_configuration_class &Jpm , const class GSM_vector_one_configuration &PSI_in);
class Op_PSI_one_configuration_closure_str operator * (const class J2_one_configuration_class &J2 , const class GSM_vector_one_configuration &PSI_in);

class Op_PSI_one_configuration_closure_str operator * (const class xH_one_configuration_plus_alpha_str &xH_plus_alpha , const class GSM_vector_one_configuration &PSI_in);
class Op_PSI_one_configuration_closure_str operator * (const class xJpm_one_configuration_str &xJpm , const class GSM_vector_one_configuration &PSI_in);
class Op_PSI_one_configuration_closure_str operator * (const class xJ2_one_configuration_plus_alpha_str &xJ2_plus_alpha , const class GSM_vector_one_configuration &PSI_in);

class Op_PSI_one_configuration_closure_str operator * (const class H_one_configuration_class &H , const class Op_PSI_one_configuration_closure_str &Op_PSI_closure);
class Op_PSI_one_configuration_closure_str operator * (const class Jpm_one_configuration_class &Jpm , const class Op_PSI_one_configuration_closure_str &Op_PSI_closure);
class Op_PSI_one_configuration_closure_str operator * (const class J2_one_configuration_class &J2 , const class Op_PSI_one_configuration_closure_str &Op_PSI_closure);

class Op_PSI_one_configuration_closure_str operator * (const class xH_one_configuration_plus_alpha_str &xH_plus_alpha , const class Op_PSI_one_configuration_closure_str &Op_PSI_closure);
class Op_PSI_one_configuration_closure_str operator * (const class xJpm_one_configuration_str &xJpm , const class Op_PSI_one_configuration_closure_str &Op_PSI_closure);
class Op_PSI_one_configuration_closure_str operator * (const class xJ2_one_configuration_plus_alpha_str &xJ2_plus_alpha , const class Op_PSI_one_configuration_closure_str &Op_PSI_closure);

class Op_PSI_one_configuration_closure_str operator + (const class GSM_vector_one_configuration &PSI_in);
class Op_PSI_one_configuration_closure_str operator - (const class GSM_vector_one_configuration &PSI_in);
class Op_PSI_one_configuration_closure_str operator * (const TYPE &alpha , const class GSM_vector_one_configuration &PSI_in);
class Op_PSI_one_configuration_closure_str operator * (const class GSM_vector_one_configuration &PSI_in , const TYPE &alpha);
class Op_PSI_one_configuration_closure_str operator / (const class GSM_vector_one_configuration &PSI_in , const TYPE &one_over_alpha);

class Op_PSI_one_configuration_closure_str operator + (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure);
class Op_PSI_one_configuration_closure_str operator - (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure);
class Op_PSI_one_configuration_closure_str operator * (const TYPE &factor , const class Op_PSI_one_configuration_closure_str &Op_PSI_closure);
class Op_PSI_one_configuration_closure_str operator * (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure , const TYPE &factor);
class Op_PSI_one_configuration_closure_str operator / (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure , const TYPE &one_over_factor);

class Op_PSI_one_configuration_closure_str Op_PSI_closure_add (
							       const int sign , 
							       const class Op_PSI_one_configuration_closure_str &Op_PSI_closure_a , 
							       const class Op_PSI_one_configuration_closure_str &Op_PSI_closure_b);

class Op_PSI_one_configuration_closure_str operator + (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure_a , const class Op_PSI_one_configuration_closure_str &Op_PSI_closure_b);
class Op_PSI_one_configuration_closure_str operator - (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure_a , const class Op_PSI_one_configuration_closure_str &Op_PSI_closure_b);


#endif


