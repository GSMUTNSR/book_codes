#ifndef GSMADAGGERBARYONHELPER_H
#define GSMADAGGERBARYONHELPER_H


// TYPE is double or complex
// -------------------------


class a_dagger_baryon_PSI_str 
{
public:

  const bool full_common_vectors_used_in_file; // true if vectors are copied fully to disk, false if they are copied in parallel in several files, following MPI distribution of vectors

  const class nljm_struct &phi_projectile; // structure containing the particle,n,l,j,m quantum numbers of the projectile 

  const class correlated_state_str &PSI_IN_qn; // data containing the quantum numbers of |Psi[in]>

  const double M_IN; // M-projection of |Psi[in]>

  a_dagger_baryon_PSI_str (
			   const bool full_common_vectors_used_in_file_c , 
			   const class nljm_struct &phi_projectile_c , 
			   const class correlated_state_str &PSI_IN_qn_c ,
			   const double M_IN_c);
};


class a_dagger_baryon_coupled_to_J_PSI_str 
{
public:

  const bool full_common_vectors_used_in_file;

  const class nlj_struct &shell_projectile;

  const class correlated_state_str &PSI_IN_qn;

  const double J_OUT;
  const double M_OUT;

  a_dagger_baryon_coupled_to_J_PSI_str (
					const bool full_common_vectors_used_in_file_c , 
					const class nlj_struct &shell_projectile_c , 
					const class correlated_state_str &PSI_IN_qn_c ,
					const double J_OUT_c , 
					const double M_OUT_c);
};





class a_baryon_PSI_str 
{
public:
  const bool full_common_vectors_used_in_file;

  const class nljm_struct &phi_ejectile;

  const class correlated_state_str &PSI_IN_qn;

  const double M_IN;

  a_baryon_PSI_str (
		    const bool full_common_vectors_used_in_file_c , 
		    const class nljm_struct &phi_ejectile_c , 
		    const class correlated_state_str &PSI_IN_qn_c ,
		    const double M_IN_c);
};


class a_baryon_coupled_to_J_PSI_str 
{
public:
  const bool full_common_vectors_used_in_file;
  
  const class nlj_struct &shell_ejectile;

  const class correlated_state_str &PSI_IN_qn;

  const double J_OUT;
  const double M_OUT;

  a_baryon_coupled_to_J_PSI_str (
				 const bool full_common_vectors_used_in_file_c , 
				 const class nlj_struct &shell_ejectile_c , 
				 const class correlated_state_str &PSI_IN_qn_c ,
				 const double J_OUT_c , 
				 const double M_OUT_c);
};






namespace a_dagger_baryon_helper
{
  void a_dagger_p_PSI_IN_total_PSI_indices_components_calc_pn (
							       const class nljm_struct &phi_p_projectile ,
							       const class correlated_state_str &PSI_IN_qn ,
							       const class GSM_vector_helper_class &GSM_vector_helper_OUT ,
							       const class array<unsigned int> &inSDp_tab ,
							       const class array<unsigned int> &SDn_tab ,
							       const class array<TYPE> &PSI_IN_component_tab ,
							       const class array<bool> &is_inSDp_in_new_space_tab ,
							       const class array<bool> &is_SDn_in_new_space_tab ,
							       const class array<unsigned char> &reordering_bin_phases_p ,
							       const class array<unsigned char> &reordering_bin_phases_n ,
							       class array<unsigned int> &a_dagger_PSI_IN_total_PSI_indices ,
							       class array<TYPE> &a_dagger_PSI_IN_components);

  void a_dagger_n_PSI_IN_total_PSI_indices_components_calc_pn (
							       const class nljm_struct &phi_n_projectile ,
							       const class correlated_state_str &PSI_IN_qn ,
							       const class GSM_vector_helper_class &GSM_vector_helper_OUT ,
							       const class array<unsigned int> &SDp_tab ,
							       const class array<unsigned int> &inSDn_tab ,
							       const class array<TYPE> &PSI_IN_component_tab ,
							       const class array<bool> &is_SDp_in_new_space_tab ,
							       const class array<bool> &is_inSDn_in_new_space_tab ,
							       const class array<unsigned char> &reordering_bin_phases_p ,
							       const class array<unsigned char> &reordering_bin_phases_n ,
							       class array<unsigned int> &a_dagger_PSI_IN_total_PSI_indices ,
							       class array<TYPE> &a_dagger_PSI_IN_components);

  void a_dagger_mu_PSI_IN_total_PSI_indices_components_calc_pp_nn (
								   const class nljm_struct &phi_mu_projectile ,
								   const class correlated_state_str &PSI_IN_qn ,
								   const class GSM_vector_helper_class &GSM_vector_helper_OUT ,
								   const class array<unsigned int> &inSD_tab ,
								   const class array<TYPE> &PSI_IN_component_tab ,
								   const class array<bool> &is_inSD_in_new_space_tab ,
								   const class array<unsigned char> &reordering_bin_phases ,
								   class array<unsigned int> &a_dagger_PSI_IN_total_PSI_indices ,
								   class array<TYPE> &a_dagger_PSI_IN_components);
  

  void a_dagger_p_apply_add_pn (
				const bool full_common_vectors_used_in_file ,
				const class nljm_struct &phi_p_projectile ,
				const class correlated_state_str &PSI_IN_qn ,
				const double M_IN , 
				class GSM_vector &PSI_OUT);

  void a_dagger_n_apply_add_pn (
				const bool full_common_vectors_used_in_file ,
				const class nljm_struct &phi_n_projectile ,
				const class correlated_state_str &PSI_IN_qn ,
				const double M_IN , 
				class GSM_vector &PSI_OUT);

  void a_dagger_mu_apply_add_pp_nn ( 
				    const bool full_common_vectors_used_in_file ,
				    const class nljm_struct &phi_projectile ,
				    const class correlated_state_str &PSI_IN_qn ,
				    const double M_IN , 
				    class GSM_vector &PSI_OUT);

  void a_dagger_baryon_apply_add (
				  const bool full_common_vectors_used_in_file ,
				  const class nljm_struct &phi_projectile ,
				  const class correlated_state_str &PSI_IN_qn ,
				  const double M_IN , 
				  class GSM_vector &PSI_OUT);
    
  void a_dagger_baryon_coupled_to_J_apply_add (
					       const bool full_common_vectors_used_in_file ,
					       const class nlj_struct &shell_projectile , 
					       const class correlated_state_str &PSI_IN_qn , 
					       const double J_OUT , 
					       class GSM_vector &PSI_OUT);
  
  void a_p_PSI_IN_total_PSI_indices_components_calc_pn (
							const class nljm_struct &phi_p_projectile ,
							const class correlated_state_str &PSI_IN_qn ,
							const class GSM_vector_helper_class &GSM_vector_helper_OUT ,
							const class array<unsigned int> &inSDp_tab ,
							const class array<unsigned int> &SDn_tab ,
							const class array<TYPE> &PSI_IN_component_tab ,
							const class array<bool> &is_inSDp_in_new_space_tab ,
							const class array<bool> &is_SDn_in_new_space_tab ,
							const class array<unsigned char> &reordering_bin_phases_p ,
							const class array<unsigned char> &reordering_bin_phases_n ,
							class array<unsigned int> &a_PSI_IN_total_PSI_indices ,
							class array<TYPE> &a_PSI_IN_components);

  void a_n_PSI_IN_total_PSI_indices_components_calc_pn (
							const class nljm_struct &phi_n_projectile ,
							const class correlated_state_str &PSI_IN_qn ,
							const class GSM_vector_helper_class &GSM_vector_helper_OUT , 
							const class array<unsigned int> &SDp_tab ,
							const class array<unsigned int> &inSDn_tab ,
							const class array<TYPE> &PSI_IN_component_tab ,
							const class array<bool> &is_SDp_in_new_space_tab ,
							const class array<bool> &is_inSDn_in_new_space_tab ,
							const class array<unsigned char> &reordering_bin_phases_p ,
							const class array<unsigned char> &reordering_bin_phases_n ,
							class array<unsigned int> &a_PSI_IN_total_PSI_indices ,
							class array<TYPE> &a_PSI_IN_components);

  void a_mu_PSI_IN_total_PSI_indices_components_calc_pp_nn (
							    const class nljm_struct &phi_mu_projectile ,
							    const class correlated_state_str &PSI_IN_qn ,
							    const class GSM_vector_helper_class &GSM_vector_helper_OUT , 
							    const class array<unsigned int> &inSD_tab ,
							    const class array<TYPE> &PSI_IN_component_tab ,
							    const class array<bool> &is_inSD_in_new_space_tab ,
							    const class array<unsigned char> &reordering_bin_phases ,
							    class array<unsigned int> &a_PSI_IN_total_PSI_indices , 
							    class array<TYPE> &a_PSI_IN_components);

  void a_proton_apply_add_pn (
			      const bool full_common_vectors_used_in_file ,
			      const class nljm_struct &phi_p_projectile ,
			      const class correlated_state_str &PSI_IN_qn ,
			      const double M_IN , 
			      class GSM_vector &PSI_OUT);

  void a_neutron_apply_add_pn (
			       const bool full_common_vectors_used_in_file ,
			       const class nljm_struct &phi_n_projectile ,
			       const class correlated_state_str &PSI_IN_qn ,
			       const double M_IN , 
			       class GSM_vector &PSI_OUT);

  void a_mu_apply_add_pp_nn ( 
			     const bool full_common_vectors_used_in_file ,
			     const class nljm_struct &phi_projectile ,
			     const class correlated_state_str &PSI_IN_qn ,
			     const double M_IN , 
			     class GSM_vector &PSI_OUT);
  
  void a_baryon_apply_add (
			   const bool full_common_vectors_used_in_file ,
			   const class nljm_struct &phi_projectile ,
			   const class correlated_state_str &PSI_IN_qn ,
			   const double M_IN , 
			   class GSM_vector &PSI_OUT);
  
  void a_baryon_coupled_to_J_apply_add (
					const bool full_common_vectors_used_in_file ,
					const class nlj_struct &shell_projectile , 
					const class correlated_state_str &PSI_IN_qn , 
					const double J_OUT , 
					class GSM_vector &PSI_OUT);
  
  class a_dagger_baryon_PSI_str a_dagger_baryon (
						 const bool full_common_vectors_used_in_file ,
						 const class nljm_struct &phi_projectile_c , 
						 const class correlated_state_str &PSI_IN_qn_c ,
						 const double M_IN_c);
  
  class a_dagger_baryon_coupled_to_J_PSI_str a_dagger_baryon_coupled_to_J (
									   const bool full_common_vectors_used_in_file ,
									   const class nlj_struct &shell_projectile_c ,  
									   const class correlated_state_str &PSI_IN_qn_c ,
									   const double J_OUT_c , 
									   const double M_OUT_c);
  
  class a_baryon_PSI_str a_baryon (
				   const bool full_common_vectors_used_in_file ,
				   const class nljm_struct &phi_ejectile_c , 
				   const class correlated_state_str &PSI_IN_qn_c ,
				   const double M_IN_c);
  
  class a_baryon_coupled_to_J_PSI_str a_baryon_coupled_to_J (
							     const bool full_common_vectors_used_in_file ,
							     const class nlj_struct &shell_ejectile_c ,  
							     const class correlated_state_str &PSI_IN_qn_c ,
							     const double J_OUT_c , 
							     const double M_OUT_c);

}









class x_a_dagger_baryon_PSI_str
{
public:

  const TYPE x;
  const class a_dagger_baryon_PSI_str &a_dagger_baryon_PSI;

  x_a_dagger_baryon_PSI_str (const TYPE &x_c , const class a_dagger_baryon_PSI_str &a_dagger_baryon_PSI_c);
};




class x_a_dagger_baryon_PSI_str operator + (const class a_dagger_baryon_PSI_str &a_dagger_baryon_PSI);
class x_a_dagger_baryon_PSI_str operator - (const class a_dagger_baryon_PSI_str &a_dagger_baryon_PSI);

class x_a_dagger_baryon_PSI_str operator * (const class a_dagger_baryon_PSI_str &a_dagger_baryon_PSI , const double x);
class x_a_dagger_baryon_PSI_str operator * (const double x , const class a_dagger_baryon_PSI_str &a_dagger_baryon_PSI);
class x_a_dagger_baryon_PSI_str operator / (const class a_dagger_baryon_PSI_str &a_dagger_baryon_PSI , const double x);

class x_a_dagger_baryon_PSI_str operator + (const class x_a_dagger_baryon_PSI_str &x_a_dagger_baryon_PSI);
class x_a_dagger_baryon_PSI_str operator - (const class x_a_dagger_baryon_PSI_str &x_a_dagger_baryon_PSI);

class x_a_dagger_baryon_PSI_str operator * (const class a_dagger_baryon_PSI_str &a_dagger_baryon_PSI , const complex<double> &x);
class x_a_dagger_baryon_PSI_str operator * (const complex<double> &x , const class a_dagger_baryon_PSI_str &a_dagger_baryon_PSI);
class x_a_dagger_baryon_PSI_str operator / (const class a_dagger_baryon_PSI_str &a_dagger_baryon_PSI , const complex<double> &x);





class x_a_dagger_baryon_coupled_to_J_PSI_str
{
public:

  const TYPE x;
  const class a_dagger_baryon_coupled_to_J_PSI_str &a_dagger_baryon_coupled_to_J_PSI;

  x_a_dagger_baryon_coupled_to_J_PSI_str (const TYPE &x_c , const class a_dagger_baryon_coupled_to_J_PSI_str &a_dagger_baryon_coupled_to_J_PSI_c);
};

class x_a_dagger_baryon_coupled_to_J_PSI_str operator + (const class a_dagger_baryon_coupled_to_J_PSI_str &a_dagger_baryon_coupled_to_J_PSI);
class x_a_dagger_baryon_coupled_to_J_PSI_str operator - (const class a_dagger_baryon_coupled_to_J_PSI_str &a_dagger_baryon_coupled_to_J_PSI);

class x_a_dagger_baryon_coupled_to_J_PSI_str operator * (const class a_dagger_baryon_coupled_to_J_PSI_str &a_dagger_baryon_coupled_to_J_PSI , const double x);
class x_a_dagger_baryon_coupled_to_J_PSI_str operator * (const double x , const class a_dagger_baryon_coupled_to_J_PSI_str &a_dagger_baryon_coupled_to_J_PSI);
class x_a_dagger_baryon_coupled_to_J_PSI_str operator / (const class a_dagger_baryon_coupled_to_J_PSI_str &a_dagger_baryon_coupled_to_J_PSI , const double x);

class x_a_dagger_baryon_coupled_to_J_PSI_str operator + (const class x_a_dagger_baryon_coupled_to_J_PSI_str &x_a_dagger_baryon_coupled_to_J_PSI);
class x_a_dagger_baryon_coupled_to_J_PSI_str operator - (const class x_a_dagger_baryon_coupled_to_J_PSI_str &x_a_dagger_baryon_coupled_to_J_PSI);

class x_a_dagger_baryon_coupled_to_J_PSI_str operator * (const class a_dagger_baryon_coupled_to_J_PSI_str &a_dagger_baryon_coupled_to_J_PSI , const complex<double> &x);
class x_a_dagger_baryon_coupled_to_J_PSI_str operator * (const complex<double> &x , const class a_dagger_baryon_coupled_to_J_PSI_str &a_dagger_baryon_coupled_to_J_PSI);
class x_a_dagger_baryon_coupled_to_J_PSI_str operator / (const class a_dagger_baryon_coupled_to_J_PSI_str &a_dagger_baryon_coupled_to_J_PSI , const complex<double> &x);





class x_a_baryon_PSI_str
{
public:

  const TYPE x;
  const class a_baryon_PSI_str &a_baryon_PSI;

  x_a_baryon_PSI_str (const TYPE &x_c , const class a_baryon_PSI_str &a_baryon_PSI_c);
};




class x_a_baryon_PSI_str operator + (const class a_baryon_PSI_str &a_baryon_PSI);
class x_a_baryon_PSI_str operator - (const class a_baryon_PSI_str &a_baryon_PSI);

class x_a_baryon_PSI_str operator * (const class a_baryon_PSI_str &a_baryon_PSI , const double x);
class x_a_baryon_PSI_str operator * (const double x , const class a_baryon_PSI_str &a_baryon_PSI);
class x_a_baryon_PSI_str operator / (const class a_baryon_PSI_str &a_baryon_PSI , const double x);

class x_a_baryon_PSI_str operator + (const class x_a_baryon_PSI_str &x_a_baryon_PSI);
class x_a_baryon_PSI_str operator - (const class x_a_baryon_PSI_str &x_a_baryon_PSI);

class x_a_baryon_PSI_str operator * (const class a_baryon_PSI_str &a_baryon_PSI , const complex<double> &x);
class x_a_baryon_PSI_str operator * (const complex<double> &x , const class a_baryon_PSI_str &a_baryon_PSI);
class x_a_baryon_PSI_str operator / (const class a_baryon_PSI_str &a_baryon_PSI , const complex<double> &x);





class x_a_baryon_coupled_to_J_PSI_str
{
public:

  const TYPE x;
  const class a_baryon_coupled_to_J_PSI_str &a_baryon_coupled_to_J_PSI;

  x_a_baryon_coupled_to_J_PSI_str (const TYPE &x_c , const class a_baryon_coupled_to_J_PSI_str &a_baryon_coupled_to_J_PSI_c);
};

class x_a_baryon_coupled_to_J_PSI_str operator + (const class a_baryon_coupled_to_J_PSI_str &a_baryon_coupled_to_J_PSI);
class x_a_baryon_coupled_to_J_PSI_str operator - (const class a_baryon_coupled_to_J_PSI_str &a_baryon_coupled_to_J_PSI);

class x_a_baryon_coupled_to_J_PSI_str operator * (const class a_baryon_coupled_to_J_PSI_str &a_baryon_coupled_to_J_PSI , const double x);
class x_a_baryon_coupled_to_J_PSI_str operator * (const double x , const class a_baryon_coupled_to_J_PSI_str &a_baryon_coupled_to_J_PSI);
class x_a_baryon_coupled_to_J_PSI_str operator / (const class a_baryon_coupled_to_J_PSI_str &a_baryon_coupled_to_J_PSI , const double x);

class x_a_baryon_coupled_to_J_PSI_str operator + (const class x_a_baryon_coupled_to_J_PSI_str &x_a_baryon_coupled_to_J_PSI);
class x_a_baryon_coupled_to_J_PSI_str operator - (const class x_a_baryon_coupled_to_J_PSI_str &x_a_baryon_coupled_to_J_PSI);

class x_a_baryon_coupled_to_J_PSI_str operator * (const class a_baryon_coupled_to_J_PSI_str &a_baryon_coupled_to_J_PSI , const complex<double> &x);
class x_a_baryon_coupled_to_J_PSI_str operator * (const complex<double> &x , const class a_baryon_coupled_to_J_PSI_str &a_baryon_coupled_to_J_PSI);
class x_a_baryon_coupled_to_J_PSI_str operator / (const class a_baryon_coupled_to_J_PSI_str &a_baryon_coupled_to_J_PSI , const complex<double> &x);

#endif



