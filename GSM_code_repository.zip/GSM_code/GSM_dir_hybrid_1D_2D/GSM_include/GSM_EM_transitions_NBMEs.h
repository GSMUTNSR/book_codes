#ifndef EMTRANSITIONSNBMES_H
#define EMTRANSITIONSNBMES_H

// TYPE is double or complex
// -------------------------

namespace EM_transitions_NBMEs
{
  TYPE diagonal_part_pp_nn_calc (
				 const class array<TYPE> &OBMEs , 
				 const class Slater_determinant &SD);

  TYPE B_EM_amplitude_diagonal_part_pp_nn_calc (
						const class array<TYPE> &OBMEs , 
						const class GSM_vector &PSI_IN_full , 
						const class GSM_vector &PSI_OUT);

  TYPE B_EM_amplitude_one_jump_part_pp_nn_calc (
						const class array<TYPE> &OBMEs , 
						const class GSM_vector &PSI_IN_full , 
						const class GSM_vector &PSI_OUT);
	
  TYPE B_EM_amplitude_diagonal_part_pn_prot_part_calc (
						       const class array<TYPE> &OBMEs_p , 
						       const class GSM_vector &PSI_IN_full , 
						       const class GSM_vector &PSI_OUT);
	
  TYPE B_EM_amplitude_diagonal_part_pn_neut_part_calc (
						       const class array<TYPE> &OBMEs_n , 
						       const class GSM_vector &PSI_IN_full , 
						       const class GSM_vector &PSI_OUT);
	
  TYPE B_EM_amplitude_one_jump_p_pn_calc (
					  const unsigned int BP_Op , 
					  const class array<TYPE> &OBMEs_p , 
					  const class GSM_vector &PSI_IN_full , 
					  const class GSM_vector &PSI_OUT);

  TYPE B_EM_amplitude_one_jump_n_pn_calc (
					  const unsigned int BP_Op , 
					  const class array<TYPE> &OBMEs_n , 
					  const class GSM_vector &PSI_IN_full , 
					  const class GSM_vector &PSI_OUT);

  TYPE B_EM_amplitude_from_OBMEs_calc (
				       class GSM_vector &PSI_IN_full ,
				       const int L ,
				       const unsigned int BP_Op , 
				       const class array<TYPE> &OBMEs_p , 
				       const class array<TYPE> &OBMEs_n , 
				       const double J_IN , 
				       const class GSM_vector &PSI_IN ,
				       const double J_OUT , 
				       const class GSM_vector &PSI_OUT);
}

#endif


