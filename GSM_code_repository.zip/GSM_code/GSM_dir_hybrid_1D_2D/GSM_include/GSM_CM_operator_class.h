#ifndef GSMCMOPCLASS_H
#define GSMCMOPCLASS_H

// TYPE is double or complex
// -------------------------

class CM_operator_class
{ 
public:
  
  CM_operator_class ();
  
  CM_operator_class (
		     const enum operator_type CM_operator_inter_c , 
		     const bool configuration_SD_one_jump_tables_to_recalculate_c ,  
		     const double J_c , 
		     const bool is_it_HO_expansion_c , 
		     class GSM_vector_helper_class &GSM_vector_helper_in ,
		     class GSM_vector_helper_class &GSM_vector_helper_out ,
		     class GSM_vector &PSI_in_full);
 
  CM_operator_class (const class CM_operator_class &X);
  
  ~CM_operator_class ();
    
  void allocate (
		 const enum operator_type CM_operator_inter_c , 
		 const bool configuration_SD_one_jump_tables_to_recalculate_c , 
		 const double J_c ,  
		 const bool is_it_HO_expansion_c , 
		 class GSM_vector_helper_class &GSM_vector_helper_in ,
		 class GSM_vector_helper_class &GSM_vector_helper_out ,
		 class GSM_vector &PSI_in_full);
 
  void allocate_fill (const class CM_operator_class &X);

  void deallocate ();

  bool is_it_filled () const
  {
    return (CM_operator_inter != NO_OPERATOR);
  }

  enum operator_type get_CM_operator_inter () const
  {
    return CM_operator_inter;
  }
  
  class GSM_vector_helper_class & get_GSM_vector_helper_in () const
  {
    return *GSM_vector_helper_in_ptr;
  }
  
  class GSM_vector_helper_class & get_GSM_vector_helper_out () const
  {
    return *GSM_vector_helper_out_ptr;
  }
    
  class GSM_vector & get_PSI_in_full ()
  {
    return *PSI_in_full_ptr;
  }
  
  class GSM_vector & get_PSI_in_full () const
  {
    return *PSI_in_full_ptr;
  }
  
  void apply_add (
		  const class GSM_vector &PSI_in , 
		  const TYPE &alpha , 
		  class GSM_vector &PSI_out) const;
  
  friend double used_memory_calc (const class CM_operator_class &T);
  
private:
  
  void NBMEs_p_diagonal_all_SDs_calc_pn (const class baryons_data &data);
  void NBMEs_n_diagonal_all_SDs_calc_pn (const class baryons_data &data);
  
  void NBMEs_diagonal_all_SDs_calc_pp_nn (const class baryons_data &data);
 
  void diagonal_part_pn_N_valence_larger_calc (
					       const TYPE &alpha ,
					       class GSM_vector &PSI_out) const;
  
  void diagonal_part_pn_Z_valence_larger_calc (
					       const TYPE &alpha ,
					       class GSM_vector &PSI_out) const;
  
  void diagonal_part_pp_nn_calc (
				 const TYPE &alpha ,
				 class GSM_vector &PSI_out) const;
 
  TYPE NBME_one_jump_mu_no_phase_calc (
				       const unsigned int in_jumps , 
				       const unsigned int out_jumps , 
				       const class Slater_determinant &outSD , 
				       const class baryons_data &data) const;

  void NBMEs_one_jump_pp_nn_calc_store (
					const unsigned int BPmu_out ,
					const int Smu_out , 
					const int n_spec_mu_out ,  
					const int iMmu_out , 
					const unsigned int BPmu_in , 
					const int Smu_in ,  
					const int n_spec_mu_in , 
					const int iMmu_in , 
					const int n_scat_mu_out , 
					const unsigned int iCmu_out , 
					const unsigned int outSDmu_index , 
					const class Slater_determinant &outSDmu , 
					const class baryons_data &data , 
					bool &is_there_one_jump_calc , 
					class jumps_data_out_to_in_str &one_jump_mu , 
					class array<TYPE> &NBMEs_one_jump_mu) const;
 
  void NBMEs_two_jumps_pp_nn_calc_store (
					 const unsigned int BPmu_out , 
					 const int Smu_out , 
					 const int n_spec_mu_out , 
					 const int iMmu_out , 
					 const unsigned int BPmu_in ,
					 const int Smu_in ,  
					 const int n_spec_mu_in ,  
					 const int iMmu_in , 
					 const int n_scat_mu_out , 
					 const unsigned int iCmu_out , 
					 const unsigned int outSDmu_index , 
					 const class baryons_data &data , 
					 bool &are_there_two_jumps_calc , 
					 class jumps_data_out_to_in_str &two_jumps_mu , 
					 class array<TYPE> &NBMEs_two_jumps_mu) const;
 
  void jumps_p_one_body_part_pn_calc (class GSM_vector &PSI_out) const;
  void jumps_p_two_body_part_pn_calc (class GSM_vector &PSI_out) const;
  
  void jumps_n_one_body_part_pn_calc (class GSM_vector &PSI_out) const;
  void jumps_n_two_body_part_pn_calc (class GSM_vector &PSI_out) const;
  
  void two_jumps_pn_part_pn_N_valence_larger_calc (class GSM_vector &PSI_out) const;
  
  void two_jumps_pn_part_pn_Z_valence_larger_calc (class GSM_vector &PSI_out) const;
  
  void jumps_part_pp_nn_calc (class GSM_vector &PSI_out) const;

  class CM_TBMEs_angular_table_str & get_TBMEs_angular_table () const;

  class array_BP_S_Nspec_Nscat_iC_iM_SD<TYPE> & get_diagonal_NBMEs_p () const;
  class array_BP_S_Nspec_Nscat_iC_iM_SD<TYPE> & get_diagonal_NBMEs_n () const;

  enum operator_type CM_operator_inter; // type of considered CM operator (Hcm, P^2/2M, L^2[CM], A+[CM-HO], ...)

  bool configuration_SD_one_jump_tables_to_recalculate; // true if one has to recalculate the a+ a matrix elements between SDs to apply the CM operator, false if not
  
  bool is_it_HO_expansion; // true if one uses HO expansion if the CM operator, false if one uses R cut, i.e. integration on [0:R] only

  double J; // total angular momentum of |Psi[in]> and |Psi[out]> (used with TRS only)
  
  class GSM_vector_helper_class *GSM_vector_helper_in_ptr;  // pointer to data necessary to handle |Psi-in>. It does not contain its vector components.
  class GSM_vector_helper_class *GSM_vector_helper_out_ptr; // pointer to data necessary to handle |Psi-out>. It does not contain its vector components.
  
  mutable class GSM_vector_helper_class GSM_vector_helper_in_full; // data necessary to handle |Psi-in> which is stored as a full vector on each node. It does not contain its vector components.
    
  class GSM_vector *PSI_in_full_ptr; // pointer to GSM vector |Psi-in> which is stored as a full vector on each MPI node. It contains its vector components.
  
  class CM_TBMEs_angular_table_str TBMEs_angular_table; // class allowing to calculates the angular part of TBMEs 
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<TYPE> diagonal_NBMEs_p; // class containing the diagonal proton  (+ a few charged hyperons if any)   NBMEs of the CM operator
  class array_BP_S_Nspec_Nscat_iC_iM_SD<TYPE> diagonal_NBMEs_n; // class containing the diagonal neutron (+ a few uncharged hyperons if any) NBMEs of the CM operator
};





const class CM_operator_class & A_dagger_CM_HO_component_determine (
								    const int mu ,
								    const class CM_operator_class &A_dagger_CM_HO_minus ,
								    const class CM_operator_class &A_dagger_CM_HO_zero ,
								    const class CM_operator_class &A_dagger_CM_HO_plus);



class xCM_operator_plus_alpha_str
{
public:

  const TYPE x;
  const TYPE alpha;
  
  const class CM_operator_class &CM_operator;

  xCM_operator_plus_alpha_str (const TYPE &x_c , const TYPE &alpha_c , const class CM_operator_class &CM_operator_c);
};

class xCM_operator_plus_alpha_str operator + (const class CM_operator_class &CM_operator);
class xCM_operator_plus_alpha_str operator - (const class CM_operator_class &CM_operator);

class xCM_operator_plus_alpha_str operator + (const class CM_operator_class &CM_operator , const double term);
class xCM_operator_plus_alpha_str operator - (const class CM_operator_class &CM_operator , const double term);

class xCM_operator_plus_alpha_str operator + (const double term , const class CM_operator_class &CM_operator);
class xCM_operator_plus_alpha_str operator - (const double term , const class CM_operator_class &CM_operator);

class xCM_operator_plus_alpha_str operator * (const class CM_operator_class &CM_operator , const double x);
class xCM_operator_plus_alpha_str operator * (const double x , const class CM_operator_class &CM_operator);
class xCM_operator_plus_alpha_str operator / (const class CM_operator_class &CM_operator , const double x);

class xCM_operator_plus_alpha_str operator + (const class xCM_operator_plus_alpha_str &Op);
class xCM_operator_plus_alpha_str operator - (const class xCM_operator_plus_alpha_str &Op);

class xCM_operator_plus_alpha_str operator + (const class xCM_operator_plus_alpha_str &Op , const double term);
class xCM_operator_plus_alpha_str operator - (const class xCM_operator_plus_alpha_str &Op , const double term);

class xCM_operator_plus_alpha_str operator + (const double alpha , const class xCM_operator_plus_alpha_str &Op);
class xCM_operator_plus_alpha_str operator - (const double alpha , const class xCM_operator_plus_alpha_str &Op);

class xCM_operator_plus_alpha_str operator * (const class xCM_operator_plus_alpha_str &Op , const double factor);
class xCM_operator_plus_alpha_str operator / (const class xCM_operator_plus_alpha_str &Op , const double factor);
class xCM_operator_plus_alpha_str operator * (const double factor , const class xCM_operator_plus_alpha_str &Op);

class xCM_operator_plus_alpha_str operator + (const class CM_operator_class &CM_operator , const complex<double> &term);
class xCM_operator_plus_alpha_str operator - (const class CM_operator_class &CM_operator , const complex<double> &term);

class xCM_operator_plus_alpha_str operator + (const complex<double> &term , const class CM_operator_class &CM_operator);
class xCM_operator_plus_alpha_str operator - (const complex<double> &term , const class CM_operator_class &CM_operator);

class xCM_operator_plus_alpha_str operator * (const class CM_operator_class &CM_operator , const complex<double> &x);
class xCM_operator_plus_alpha_str operator * (const complex<double> &x , const class CM_operator_class &CM_operator);
class xCM_operator_plus_alpha_str operator / (const class CM_operator_class &CM_operator , const complex<double> &x);

class xCM_operator_plus_alpha_str operator + (const class xCM_operator_plus_alpha_str &Op , const complex<double> &term);
class xCM_operator_plus_alpha_str operator - (const class xCM_operator_plus_alpha_str &Op , const complex<double> &term);

class xCM_operator_plus_alpha_str operator + (const complex<double> &alpha , const class xCM_operator_plus_alpha_str &Op);
class xCM_operator_plus_alpha_str operator - (const complex<double> &alpha , const class xCM_operator_plus_alpha_str &Op);

class xCM_operator_plus_alpha_str operator * (const class xCM_operator_plus_alpha_str &Op , const complex<double> &factor);
class xCM_operator_plus_alpha_str operator / (const class xCM_operator_plus_alpha_str &Op , const complex<double> &factor);
class xCM_operator_plus_alpha_str operator * (const complex<double> &factor , const class xCM_operator_plus_alpha_str &Op);

class xCM_operator_plus_alpha_str operator + (const class xCM_operator_plus_alpha_str &Op_a , const class xCM_operator_plus_alpha_str &Op_b);
class xCM_operator_plus_alpha_str operator - (const class xCM_operator_plus_alpha_str &Op_a , const class xCM_operator_plus_alpha_str &Op_b);

#endif

