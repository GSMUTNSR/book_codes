#ifndef GSMHCLASS_H
#define GSMHCLASS_H

// TYPE is double or complex
// -------------------------

class H_class
{
public:

  H_class ();

  H_class (
	   const bool is_there_cout_c , 
	   const bool print_detailed_information , 
	   const enum storage_type Hamiltonian_storage_c , 
	   const enum storage_type M_TBMEs_storage_c ,
	   const enum storage_type one_jumps_pn_storage_c ,
	   const bool configuration_SD_one_jump_tables_to_recalculate_for_matrices_c , 
	   const bool is_it_Davidson_c , 
	   const bool non_zero_NBMEs_proportion_only , 
	   const class TBMEs_class &TBMEs_pn_c , 
	   const bool is_prot_one_body_non_zero_if_here_c , 
	   const bool is_neut_one_body_non_zero_if_here_c , 
	   const bool is_pp_non_zero_if_here_c , 
	   const bool is_nn_non_zero_if_here_c , 
	   const bool is_pn_non_zero_if_here_c , 
	   const double J_c , 
	   class GSM_vector_helper_class &GSM_vector_helper ,
	   class GSM_vector &PSI_in_full ,
	   class GSM_vector &PSI_in_unoccupied_squares ,
	   class GSM_vector &H_PSI_occupied_squares ,
	   class array<class GSM_vector> &H_PSI_table);
  
  H_class (const class H_class &X);

  ~H_class ();


  void allocate (
		 const bool is_there_cout_c , 
		 const bool print_detailed_information , 
		 const enum storage_type Hamiltonian_storage_c ,
		 const enum storage_type M_TBMEs_storage_c ,
		 const enum storage_type one_jumps_pn_storage_c ,
		 const bool configuration_SD_one_jump_tables_to_recalculate_for_matrices_c ,  
		 const bool is_it_Davidson_c , 
		 const bool non_zero_NBMEs_proportion_only , 
		 const class TBMEs_class &TBMEs_pn_c , 
		 const bool is_prot_one_body_non_zero_if_here_c , 
		 const bool is_neut_one_body_non_zero_if_here_c , 
		 const bool is_pp_non_zero_if_here_c , 
		 const bool is_nn_non_zero_if_here_c , 
		 const bool is_pn_non_zero_if_here_c , 
		 const double J_c , 
		 class GSM_vector_helper_class &GSM_vector_helper ,
		 class GSM_vector &PSI_in_full ,
		 class GSM_vector &PSI_in_unoccupied_squares ,
		 class GSM_vector &H_PSI_occupied_squares ,
		 class array<class GSM_vector> &H_PSI_table);

  void allocate_fill (const class H_class &X);

  double get_J () const
  {
    return J;
  }

  void set_J (const double J_c)
  {
    J = J_c;
  }

  class GSM_vector_helper_class & get_GSM_vector_helper () const
  {
    return *GSM_vector_helper_ptr;
  }
  
  class GSM_vector & get_PSI_in_full ()
  {
    return *PSI_in_full_ptr;
  }
  
  class GSM_vector & get_PSI_in_full () const
  {
    return *PSI_in_full_ptr;
  }
  
  class GSM_vector & get_PSI_in_unoccupied_squares ()
  {
    return *PSI_in_unoccupied_squares_ptr;
  }
  
  class GSM_vector & get_PSI_in_unoccupied_squares () const
  {
    return *PSI_in_unoccupied_squares_ptr;
  }

  class GSM_vector & get_H_PSI_occupied_squares ()
  {
    return *H_PSI_occupied_squares_ptr;
  }

  class GSM_vector & get_H_PSI_occupied_squares () const
  {
    return *H_PSI_occupied_squares_ptr;
  }

  class array<class GSM_vector> & get_H_PSI_table ()
  {
    return *H_PSI_table_ptr;
  }

  class array<class GSM_vector> & get_H_PSI_table () const
  {
    return *H_PSI_table_ptr;
  }

  const class TBMEs_class & get_TBMEs_pn () const
  {
    return *TBMEs_pn_ptr;
  }

  class array<TYPE> & get_H_diagonal_tab ()
  {
    return H_diagonal_tab;
  }

  const class array<TYPE> & get_H_diagonal_tab () const
  {
    return H_diagonal_tab;
  }

  class array<TYPE> & get_H_diagonal_averaged_tab ()
  {
    return H_diagonal_averaged_tab;
  }

  const class array<TYPE> & get_H_diagonal_averaged_tab () const
  {
    return H_diagonal_averaged_tab;
  }

  bool is_it_filled () const
  {
    return (Hamiltonian_storage != NO_STORAGE);
  }

  void deallocate ();

  void print () const;

  double non_zero_NBMEs_proportion_calc () const;

  void apply_add (
		  const class GSM_vector &PSI_in , 
		  const TYPE &E , 
		  class GSM_vector &PSI_out) const;

  friend double used_memory_calc (const class H_class &T);
  
private:
    
  void one_jump_p_tab_out_to_in_all_SDp_calc ();
  
  void one_jump_n_tab_out_to_in_all_SDn_calc ();
  
  void diagonal_part_prot_part_pn_calc_store ();
  void diagonal_part_neut_part_pn_calc_store ();  

  void diagonal_part_pn_part_pn_N_valence_larger_calc_store ();
  void diagonal_part_pn_part_pn_Z_valence_larger_calc_store ();
  
  TYPE NBME_averaged_pn_calc (
			      const unsigned int BPp ,
			      const int n_scat_p ,
			      const unsigned int iCp , 
			      const unsigned int BPn ,
			      const int n_scat_n ,
			      const unsigned int iCn) const;

  void diagonal_part_averaged_pn_N_valence_larger_calc_store ();
  void diagonal_part_averaged_pn_Z_valence_larger_calc_store ();

  void diagonal_part_pp_nn_calc_store ();

  TYPE NBME_averaged_pp_nn_calc (const int n_scat , const unsigned int iC) const;

  void diagonal_part_averaged_pp_nn_calc_store ();

  void non_zero_NBMEs_numbers_pp_nn_calc (
					  const class jumps_data_in_to_out_str &jumps , 
					  const class array<bool> &is_PSI_out_index_accepted_tab , 
					  const class array<unsigned int> &square_row_indices ,  
					  const class array<unsigned int> &PSI_out_indices ,
					  class array<unsigned int> &squares_non_zero_NBMEs_numbers);
 
  void non_zero_NBMEs_numbers_jumps_p_part_pn_calc ();
  void non_zero_NBMEs_numbers_jumps_n_part_pn_calc ();
  
  void non_zero_NBMEs_numbers_two_jumps_pn_part_pn_N_valence_larger_calc ();
  void non_zero_NBMEs_numbers_two_jumps_pn_part_pn_Z_valence_larger_calc ();
  
  void non_zero_NBMEs_numbers_off_diagonal_pp_nn_calc ();
  
  void squares_non_zero_NBMEs_off_diagonal_numbers_calc ();

  unsigned int pp_pairs_in_number_pn_calc_partial_storage () const;
  unsigned int nn_pairs_in_number_pn_calc_partial_storage () const;
  unsigned int pn_pairs_in_number_pn_calc_partial_storage () const;
  
  unsigned int pairs_in_number_pp_nn_calc_partial_storage () const;
  
  unsigned int pp_pairs_out_number_pn_calc_partial_storage () const;
  unsigned int nn_pairs_out_number_pn_calc_partial_storage () const;
  unsigned int pn_pairs_out_number_pn_calc_partial_storage () const;

  unsigned int pairs_out_number_pp_nn_calc_partial_storage () const;

  void pp_pairs_in_tab_pn_calc_partial_storage (class array<class pair_str> &pp_pairs_in_tab) const;
  void nn_pairs_in_tab_pn_calc_partial_storage (class array<class pair_str> &nn_pairs_in_tab) const;
  void pn_pairs_in_tab_pn_calc_partial_storage (class array<class pair_str> &pn_pairs_in_tab) const;
  
  void pairs_in_tab_pp_nn_calc_partial_storage (class array<class pair_str> &pairs_in_tab) const;
  
  void pp_pairs_out_tab_pn_calc_partial_storage (class array<class pair_str> &pp_pairs_out_tab) const;
  void nn_pairs_out_tab_pn_calc_partial_storage (class array<class pair_str> &nn_pairs_out_tab) const;
  void pn_pairs_out_tab_pn_calc_partial_storage (class array<class pair_str> &pn_pairs_out_tab) const;

  void pairs_out_tab_pp_nn_calc_partial_storage (class array<class pair_str> &pairs_out_tab) const;

  void M_TBMEs_pp_nn_alloc_calc_partial_storage ();
  
  void M_TBMEs_pn_alloc_calc_partial_storage ();
  
  unsigned int pp_pairs_in_number_pn_calc_on_the_fly () const;
  unsigned int nn_pairs_in_number_pn_calc_on_the_fly () const;
  unsigned int pn_pairs_in_number_pn_calc_on_the_fly () const;

  unsigned int pairs_in_number_pp_nn_calc_on_the_fly () const;
  
  unsigned int pp_pairs_out_number_pn_calc_on_the_fly () const;
  unsigned int nn_pairs_out_number_pn_calc_on_the_fly () const;
  unsigned int pn_pairs_out_number_pn_calc_on_the_fly () const;

  unsigned int pairs_out_number_pp_nn_calc_on_the_fly () const;
  
  void pp_pairs_in_tab_pn_calc_on_the_fly (class array<class pair_str> &pp_pairs_in_tab) const;
  void nn_pairs_in_tab_pn_calc_on_the_fly (class array<class pair_str> &nn_pairs_in_tab) const;
  void pn_pairs_in_tab_pn_calc_on_the_fly (class array<class pair_str> &pn_pairs_in_tab) const;

  void pairs_in_tab_pp_nn_calc_on_the_fly (class array<class pair_str> &pairs_in_tab) const;
						   
  void pp_pairs_out_tab_pn_calc_on_the_fly (class array<class pair_str> &pp_pairs_out_tab) const;
  void nn_pairs_out_tab_pn_calc_on_the_fly (class array<class pair_str> &nn_pairs_out_tab) const;
  void pn_pairs_out_tab_pn_calc_on_the_fly (class array<class pair_str> &pn_pairs_out_tab) const;

  void pairs_out_tab_pp_nn_calc_on_the_fly (class array<class pair_str> &pairs_out_tab) const;
  
  void M_TBMEs_pp_nn_alloc_calc_on_the_fly ();
  
  void M_TBMEs_pn_alloc_calc_on_the_fly ();
  
  void NBMEs_one_jump_pp_nn_calc_store (
					const unsigned int BPmu , 
					const int iMmu , 
					const int n_scat_mu_in , 
					const unsigned int iCmu_in , 
					const unsigned int inSDmu_index , 
					const class Slater_determinant &inSDmu ,
					const class nucleons_data &data , 
					bool &is_there_one_jump_calc , 
					class jumps_data_in_to_out_str &one_jump_mu ,
					class array<TYPE> &NBMEs_one_jump_mu) const;
  
  void NBMEs_two_jumps_indices_pp_nn_calc_store (
						 const unsigned int BPmu , 
						 const int iMmu , 
						 const int n_scat_mu_in , 
						 const unsigned int iCmu_in , 
						 const unsigned int inSDmu_index ,  
						 const class nucleons_data &data , 
						 bool &are_there_two_jumps_calc , 
						 class jumps_data_in_to_out_str &two_jumps_mu ,  
						 class array<unsigned int> &NBMEs_two_jumps_mu_indices) const;
  
  void NBMEs_two_jumps_pp_nn_calc_store (
					 const unsigned int BPmu , 
					 const int iMmu , 
					 const int n_scat_mu_in , 
					 const unsigned int iCmu_in , 
					 const unsigned int inSDmu_index ,  
					 const class nucleons_data &data , 
					 bool &are_there_two_jumps_calc , 
					 class jumps_data_in_to_out_str &two_jumps_mu ,  
					 class array<TYPE> &NBMEs_two_jumps_mu) const;
  
  void Hamiltonian_part_one_jump_pp_nn_store (
					      const unsigned int PSI_in_index , 
					      const unsigned int dimension_one_jump ,
					      const class array<bool> &is_PSI_out_index_accepted_tab , 
					      const class array<unsigned int> &occupied_squares_row_indices ,  
					      const class array<unsigned int> &PSI_out_indices ,
					      const class array<TYPE> &NBMEs_one_jump);

  void Hamiltonian_part_two_jumps_indices_pp_nn_store (
						       const unsigned int PSI_in_index , 
						       const unsigned int dimension_two_jumps ,
						       const class array<bool> &is_PSI_out_index_accepted_tab , 
						       const class array<unsigned int> &occupied_squares_row_indices ,  
						       const class array<unsigned int> &PSI_out_indices ,
						       const class array<unsigned int> &NBMEs_two_jumps_indices);

  void Hamiltonian_part_two_jumps_pp_nn_store (
					       const unsigned int PSI_in_index , 
					       const unsigned int dimension_two_jumps ,
					       const class array<bool> &are_PSI_out_indices_accepted , 
					       const class array<unsigned int> &occupied_squares_row_indices ,  
					       const class array<unsigned int> &PSI_out_indices ,
					       const class array<TYPE> &NBMEs_two_jumps);
  
  void jumps_p_prot_one_body_part_pn_calc_store ();
  void jumps_p_prot_two_body_part_pn_calc_store ();
  
  void jumps_n_neut_one_body_part_pn_calc_store ();
  void jumps_n_neut_two_body_part_pn_calc_store ();

  void one_jump_p_pn_part_pn_calc_store ();
  void one_jump_n_pn_part_pn_calc_store ();
    
  void two_jumps_pn_part_pn_N_valence_larger_calc_store ();
  void two_jumps_pn_part_pn_Z_valence_larger_calc_store ();  

  void jumps_part_pp_nn_calc_store ();

  void matrix_off_diagonal_store ();

  void NBMEs_one_jump_pp_nn_calc_partial_storage_on_the_fly (
							     const unsigned int BPmu , 
							     const int iMmu , 
							     const int n_scat_mu_out , 
							     const unsigned int iCmu_out , 
							     const unsigned int outSDmu_index , 
							     const class Slater_determinant &outSDmu , 
							     const class nucleons_data &data , 
							     bool &is_there_one_jump_calc , 
							     class jumps_data_out_to_in_str &one_jump_mu , 
							     class array<TYPE> &NBMEs_one_jump_mu) const;
  
  void NBMEs_two_jumps_pp_nn_calc_partial_storage_on_the_fly (
							      const unsigned int BPmu , 
							      const int iMmu , 
							      const int n_scat_mu_in , 
							      const unsigned int iCmu_in , 
							      const unsigned int inSDmu_index , 
							      const class nucleons_data &data , 
							      bool &are_there_two_jumps_calc , 
							      class jumps_data_out_to_in_str &two_jumps_mu ,  
							      class array<TYPE> &NBMEs_two_jumps_mu) const;
  
  void jumps_p_prot_one_body_part_pn_calc_on_the_fly (class GSM_vector &PSI_out) const;
  
  void jumps_p_prot_two_body_part_pn_calc_on_the_fly (class GSM_vector &PSI_out) const;
  
  void jumps_n_neut_one_body_part_pn_calc_on_the_fly (class GSM_vector &PSI_out) const;
  
  void jumps_n_neut_two_body_part_pn_calc_on_the_fly (class GSM_vector &PSI_out) const;
  
  void one_jump_p_pn_part_pn_calc_on_the_fly (class GSM_vector &PSI_out) const;  
  void one_jump_n_pn_part_pn_calc_on_the_fly (class GSM_vector &PSI_out) const;
  
  void M_TBMEs_pn_indices_alloc_calc (const bool is_it_N_valence_larger);
  
  void two_jumps_pn_part_pn_on_the_fly_one_jumps_stored_N_valence_larger_calc (class GSM_vector &PSI_out) const;
  void two_jumps_pn_part_pn_on_the_fly_one_jumps_stored_Z_valence_larger_calc (class GSM_vector &PSI_out) const;
  
  void two_jumps_pn_part_pn_on_the_fly_one_jumps_partially_stored_N_valence_larger_calc (class GSM_vector &PSI_out) const;
  void two_jumps_pn_part_pn_on_the_fly_one_jumps_partially_stored_Z_valence_larger_calc (class GSM_vector &PSI_out) const;
  
  void two_jumps_pn_part_pn_on_the_fly_one_jumps_recalculated_N_valence_larger_calc (class GSM_vector &PSI_out) const;
  void two_jumps_pn_part_pn_on_the_fly_one_jumps_recalculated_Z_valence_larger_calc (class GSM_vector &PSI_out) const;
  
  void jumps_part_pp_nn_calc_on_the_fly (class GSM_vector &PSI_out) const;
 
  void apply_add_off_diagonal_on_the_fly (
					  const class GSM_vector &PSI_in ,
					  class GSM_vector &PSI_out) const;
  
  void apply_add_off_diagonal_full_or_partial_storage_occupied_squares_part (
									     const unsigned int square_row_index ,
									     const class GSM_vector &PSI_in) const;

  void apply_add_off_diagonal_full_or_partial_storage_unoccupied_squares_part (const unsigned int square_row_index) const;
  
  void apply_add_off_diagonal_full_or_partial_storage (const class GSM_vector &PSI_in , class GSM_vector &PSI_out) const;
  
  void H_MPI_communication_times_multiplications_number_print () const;
  
  bool is_there_cout; // true if one prints information on screen, false if not
  
  bool is_there_cout_detailed;  // true if prints all information on screen, false if one wants only the most important information on screen

  enum storage_type Hamiltonian_storage;            // FULL_STORAGE if Hamiltonian is fully stored , 
                                                    // PARTIAL_STORAGE if Hamiltonian TBMEs indices are stored, not TBMEs themselves (leads to a factor 2.5 in memory gain, but is slightly slower) 
                                                    // ON_THE_FLY for on the fly calculation with or without recalculation of uncoupled TBMEs from coupled TBMEs or and with or without storage of 1p-1h jumps occurring in the pn part of the Hamiltonian

  enum storage_type M_TBMEs_storage;                // Storage option of uncoupled TBMEs with partial storage or "on the fly" for Hamiltonian.
                                                    // FULL_STORAGE if all uncoupled TBMEs are stored. It is always the case with Hamiltonian partial storage.
                                                    // PARTIAL_STORAGE if only pp/pn or nn/pn uncoupled TBMEs are stored. They are indeed in small number compared to nn or pp TBMEs in very asymmetric spaces.
                                                    // ON_THE_FLY if all uncoupled TBMEs are recalculated when applying Hamiltonian.
  
  enum storage_type one_jumps_pn_storage;           // Storage option of the <outSDp | a+ a | inSDp> and <outSDn | a+ a | inSDn> matrix elements, i.e. the pn one jumps occurring in the pn part of the Hamiltonian with "on the fly" for pn Hamiltonian.
                                                    // FULL_STORAGE if all pn one jumps are stored. It is faster with Hamiltonian "on the fly" calculations, but is possible only if one does have not many valence shells. 
                                                    // PARTIAL_STORAGE if only proton or neutron jumps are stored. Neutron one jumps are indeed in small number compared to proton one jumps in neutron-rich nuclei (same with proton <-> neutron).
                                                    // ON_THE_FLY if all pn one jumps are recalculated when applying Hamiltonian.  enum storage_type one_jumps_pn_storage;
  
  bool configuration_SD_one_jump_tables_to_recalculate_for_matrices; // true if one has to recalculate the a+ a matrix elements between SDs to apply the Hamiltonian operator, false if not
  
  bool is_it_Davidson;                              // true if one uses the Davidson method for Hamiltonian diagonalization, false if one uses the Lanczos method

  bool is_prot_one_body_non_zero;                   // true if the one-body proton  part of the Hamiltonian matrix is not equal to zero, false if not
  bool is_neut_one_body_non_zero;                   // true if the one-body neutron part of the Hamiltonian matrix is not equal to zero, false if not
  
  bool is_pp_non_zero;                   // true if the two-body pp part of the Hamiltonian matrix is not equal to zero, false if not
  bool is_nn_non_zero;                   // true if the two-body nn part of the Hamiltonian matrix is not equal to zero, false if not
  bool is_pn_non_zero;                   // true if the two-body pn part of the Hamiltonian matrix is not equal to zero, false if not
  
  double J; // total angular momentum of the considered many body wave function

  mutable double H_MPI_communication_time; // time taken to make MPI communications in the calculation of H|Psi[in]>
  
  mutable double H_multiplications_number; // number of multiplications done in H|Psi[in]>
  
  class GSM_vector_helper_class *GSM_vector_helper_ptr; // pointer to data necessary to handle |Psi[in]> and |Psi[out]>. It does not contain their vector components.
  
  mutable class GSM_vector_helper_class GSM_vector_helper_full; // pointer to data necessary to handle the fully stored |Psi[in]> on each MPI node. It does not contain their vector components.

  class GSM_vector *PSI_in_full_ptr; // pointer to GSM vector |Psi-in> which is stored as a full vector on each MPI node. It contains its vector components.

  class GSM_vector *PSI_in_unoccupied_squares_ptr; // part of GSM vector  |Psi-in> in unoccupied squares
  
  class GSM_vector *H_PSI_occupied_squares_ptr; // part of GSM vector H.|Psi-in> in occupied squares

  class array<class GSM_vector> *H_PSI_table_ptr; // arrays of work vectors to calculate H|Psi[in]>

  const class TBMEs_class *TBMEs_pn_ptr; // pointer to class containing coupled pn TBMEs

  class array<TYPE> H_diagonal_tab; // diagonal NBMEs of H
  
  class array<TYPE> H_diagonal_averaged_tab; // diagonal NBMEs of H averaged on each configuration so that this diagonal commutes with J^2 (used with the Jacobi-Davidson method only)

  class uncoupled_TBMEs_class M_TBMEs; // class containing the uncoupled TBMEs used in the considered MPI node

  class array<unsigned int> space_dimensions_non_zero_one_jump_no_TRS;  // Numbers of non-zero 1p-1h NBMEs for the considered MPI node without time-reversal symmetry (TRS) for all occupied squares
  class array<unsigned int> space_dimensions_non_zero_two_jumps_no_TRS; // Numbers of non-zero 2p-2h NBMEs for the considered MPI node without time-reversal symmetry (TRS) for all occupied squares
  
  class array<unsigned int> space_dimensions_non_zero_one_jump_TRS;  // Numbers of non-zero 1p-1h NBMEs for the considered MPI node with time-reversal symmetry (TRS) for all occupied squares
  class array<unsigned int> space_dimensions_non_zero_two_jumps_TRS; // Numbers of non-zero 2p-2h NBMEs for the considered MPI node with time-reversal symmetry (TRS) for all occupied squares
  
  mutable class array<unsigned int> squares_non_zero_NBMEs_one_jump_numbers;  // Number of non-zero 1p-1h NBMEs for the considered MPI node stored on a square of hybrid 1D/2D partitioning
  mutable class array<unsigned int> squares_non_zero_NBMEs_two_jumps_numbers; // Number of non-zero 2p-2h NBMEs for the considered MPI node stored on a square of hybrid 1D/2D partitioning
  
  class array<unsigned int *> PSI_row_indices_non_zero_one_jump_no_TRS_tables;  // indices of the SDs of the rows of Hamiltonian leading to non-zeros 1p-1h NBMEs per row without time-reversal symmetry (TRS) (Hamiltonian full or partial storage only)
  class array<unsigned int *> PSI_row_indices_non_zero_two_jumps_no_TRS_tables; // indices of the SDs of the rows of Hamiltonian leading to non-zeros 2p-2h NBMEs per row without time-reversal symmetry (TRS) (Hamiltonian full or partial storage only)
  
  class array<unsigned int *> PSI_row_indices_non_zero_one_jump_TRS_tables;  // indices of the SDs of Hamiltonian rows leading to non-zeros 1p-1h NBMEs per row with time-reversal symmetry (TRS) (Hamiltonian full or partial storage only)
  class array<unsigned int *> PSI_row_indices_non_zero_two_jumps_TRS_tables; // indices of the SDs of Hamiltonian rows leading to non-zeros 2p-2h NBMEs per row with time-reversal symmetry (TRS) (Hamiltonian full or partial storage only)
    
  class array<unsigned int *> squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables; // indices of the SDs of Hamiltonian columns  (Hamiltonian full or partial storage only)
  
  class array<TYPE *> squares_non_zero_NBMEs_one_jump_tables;   // non-zeros 1p-1h NBMEs per square (Hamiltonian full or partial storage only)
  
  class array<unsigned int *> squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables; // indices of the SDs of |Psi[out]> associated to non-zeros 2p-2h NBMEs per square (Hamiltonian full or partial storage only)
  
  class array<unsigned int *> squares_non_zero_NBMEs_two_jumps_indices_tables; // indices allowing to calculate the non-zeros 2p-2h NBMEs per square (Hamiltonian partial storage only) 
  
  class array<TYPE *> squares_non_zero_NBMEs_two_jumps_tables;  // non-zeros 2p-2h NBMEs per square (Hamiltonian full storage only) 

  mutable class array<class array<class jumps_data_out_to_in_str> > one_jump_p_tabs; // Array of data of proton  one-jumps of the form <SDp' | a+[alpha] a[beta] | SDp>
  mutable class array<class array<class jumps_data_out_to_in_str> > one_jump_n_tabs; // Array of data of neutron one-jumps of the form <SDn' | a+[alpha] a[beta] | SDn>
  
  mutable class array<unsigned int> M_TBMEs_pn_indices; // Indices allowing to find uncoupled pn TBMEs quickly in M_TBMEs
};








class xH_plus_alpha_str
{
public:

  const TYPE x , alpha;
  const class H_class &H;

  xH_plus_alpha_str (const TYPE &x_c , const TYPE &alpha_c , const class H_class &H_c);
};

class xH_plus_alpha_str operator + (const class H_class &H);
class xH_plus_alpha_str operator - (const class H_class &H);

class xH_plus_alpha_str operator + (const class H_class &H , const double term);
class xH_plus_alpha_str operator - (const class H_class &H , const double term);

class xH_plus_alpha_str operator + (const double term , const class H_class &H);
class xH_plus_alpha_str operator - (const double term , const class H_class &H);

class xH_plus_alpha_str operator * (const class H_class &H , const double x);
class xH_plus_alpha_str operator * (const double x , const class H_class &H);
class xH_plus_alpha_str operator / (const class H_class &H , const double x);

class xH_plus_alpha_str operator + (const class xH_plus_alpha_str &Op);
class xH_plus_alpha_str operator - (const class xH_plus_alpha_str &Op);

class xH_plus_alpha_str operator + (const class xH_plus_alpha_str &Op , const double term);
class xH_plus_alpha_str operator - (const class xH_plus_alpha_str &Op , const double term);

class xH_plus_alpha_str operator + (const double alpha , const class xH_plus_alpha_str &Op);
class xH_plus_alpha_str operator - (const double alpha , const class xH_plus_alpha_str &Op);

class xH_plus_alpha_str operator * (const class xH_plus_alpha_str &Op , const double factor);
class xH_plus_alpha_str operator / (const class xH_plus_alpha_str &Op , const double factor);
class xH_plus_alpha_str operator * (const double factor , const class xH_plus_alpha_str &Op);

class xH_plus_alpha_str operator + (const class H_class &H , const complex<double> &term);
class xH_plus_alpha_str operator - (const class H_class &H , const complex<double> &term);

class xH_plus_alpha_str operator + (const complex<double> &term , const class H_class &H);
class xH_plus_alpha_str operator - (const complex<double> &term , const class H_class &H);

class xH_plus_alpha_str operator * (const class H_class &H , const complex<double> &x);
class xH_plus_alpha_str operator * (const complex<double> &x , const class H_class &H);
class xH_plus_alpha_str operator / (const class H_class &H , const complex<double> &x);

class xH_plus_alpha_str operator + (const class xH_plus_alpha_str &Op , const complex<double> &term);
class xH_plus_alpha_str operator - (const class xH_plus_alpha_str &Op , const complex<double> &term);

class xH_plus_alpha_str operator + (const complex<double> &alpha , const class xH_plus_alpha_str &Op);
class xH_plus_alpha_str operator - (const complex<double> &alpha , const class xH_plus_alpha_str &Op);

class xH_plus_alpha_str operator * (const class xH_plus_alpha_str &Op , const complex<double> &factor);
class xH_plus_alpha_str operator / (const class xH_plus_alpha_str &Op , const complex<double> &factor);
class xH_plus_alpha_str operator * (const complex<double> &factor , const class xH_plus_alpha_str &Op);

class xH_plus_alpha_str operator + (const class xH_plus_alpha_str &Op_a , const class xH_plus_alpha_str &Op_b);
class xH_plus_alpha_str operator - (const class xH_plus_alpha_str &Op_a , const class xH_plus_alpha_str &Op_b);

#endif
