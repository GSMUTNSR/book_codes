#ifndef GSMCLUSTERSDHOBERGGRENOVERLAPS_H
#define GSMCLUSTERSDHOBERGGRENOVERLAPS_H

// TYPE is double or complex
// -------------------------

namespace cluster_SD_HO_Berggren_overlaps
{
  void fill_SD_HO_Berggren_overlaps_table (
					   const enum operation_type operation , 
					   const unsigned int n_scat_HO_in , 
					   const unsigned int iC_HO_in , 
					   const unsigned int inSD_HO_index , 
					   const unsigned int dimensions_SD_HO_Berggren_overlaps_table_index , 
					   const unsigned int SD_HO_Berggren_overlaps_table_zero_index , 
					   const TYPE SD_HO_Berggren_overlap , 
					   class nucleons_data &cluster_particles_data);

  void all_SDs_HO_Berggren_overlaps_of_SD (
					   const enum operation_type operation , 
					   const bool truncation_hw , 
					   const bool truncation_ph , 
					   const unsigned int BP , 
					   const int iM , 
					   const unsigned int dimensions_SD_HO_Berggren_overlaps_table_index , 
					   const unsigned int SD_HO_Berggren_overlaps_table_zero_index , 
					   const unsigned int outSD_nljm_reordering_bin_phase , 
					   const class Slater_determinant &outSD_nljm_reordered , 
					   const class array<class ljm_struct> &ljm_states , 
					   const class array<unsigned int> &N_valence_nucleons_per_ljm , 
					   const class array<unsigned int> &N_sub_SDs_HO_per_ljm , 
					   const class array<class array<class Slater_determinant> > &sub_SDs_HO_tab , 
					   const class nucleons_data &cluster_particles_data_HO , 
					   class nucleons_data &cluster_particles_data);

  void all_sub_SDs_HO_per_ljm (
			       const class ljm_struct &ljm , 
			       const unsigned int N_valence_nucleons_fixed_ljm , 
			       const class array<int> &nmax_HO_lab_tab , 
			       const class one_body_indices_str &one_body_indices_HO , 
			       class array<class Slater_determinant> &sub_SDs_HO_tab_ljm);

  void N_valence_nucleons_per_ljm_fill (
					const class array<class nljm_struct> &phi_table , 
					const class Slater_determinant &SD_nljm_reordered , 
					const class array<class ljm_struct> &ljm_states , 
					class array<unsigned int> &N_valence_nucleons_per_ljm);

  void N_sub_SDs_HO_per_ljm_fill (
				  const class array<class ljm_struct> &ljm_states , 
				  const class array<unsigned int> &N_valence_nucleons_per_ljm , 
				  const class array<int> &nmax_HO_lab_tab , 
				  class array<unsigned int> &N_sub_SDs_HO_per_ljm);

  void tables_fill_dimensions_calc (
				    const enum operation_type operation , 
				    const bool truncation_hw , 
				    const bool truncation_ph , 
				    const class array<int> &nmax_HO_lab_tab , 
				    const class nucleons_data &cluster_particles_data_HO , 
				    class nucleons_data &cluster_particles_data);

  void tables_allocated_built (
			       const bool is_there_cout , 
			       const bool truncation_hw , 
			       const bool truncation_ph , 
			       const class array<int> &nmax_HO_lab_tab , 
			       const enum particle_type cluster , 
			       const class nucleons_data &cluster_particles_data_HO , 
			       class nucleons_data &cluster_particles_data);
}

#endif


