#ifndef GSMHNBMES_H
#define GSMHNBMES_H

// TYPE is double or complex
// -------------------------

namespace H_NBMEs
{
  TYPE diagonal_pp_nn_calc (
			    const bool is_one_body_part_non_zero , 
			    const bool is_two_body_part_non_zero , 
			    const class OBMEs_inter_set_str &OBMEs_inter_set ,
			    const enum interaction_type inter , 
			    const class TBMEs_class &TBMEs , 
			    const class Slater_determinant &SD);

  TYPE diagonal_pn_calc (
			 const class TBMEs_class &TBMEs_pn , 
			 const class Slater_determinant &SDp , 
			 const class Slater_determinant &SDn);

  TYPE no_pn_one_jump_mu_no_phase_calc (
					const enum interaction_type inter , 
					const bool is_one_body_part_non_zero , 
					const bool is_two_body_part_non_zero ,
					const unsigned int in_jump ,
					const unsigned int out_jump , 
					const class Slater_determinant &outSD , 
					const class baryons_data &data);

  TYPE pn_no_phase_one_jump_p_calc (
				    const unsigned int p_in ,
				    const unsigned int p_out , 
				    const class Slater_determinant &SDn , 
				    const class TBMEs_class &TBMEs_pn);

  TYPE pn_no_phase_one_jump_n_calc (
				    const unsigned int n_in ,
				    const unsigned int n_out , 
				    const class Slater_determinant &SDp , 
				    const class TBMEs_class &TBMEs_pn);

  TYPE diagonal_pp_nn_calc (
			    const bool is_one_body_part_non_zero , 
			    const bool is_two_body_part_non_zero , 
			    const enum space_type TBME_space , 
			    const class OBMEs_inter_set_str &OBMEs_inter_set ,
			    const enum interaction_type inter , 
			    const class uncoupled_TBMEs_class &TBMEs , 
			    const class Slater_determinant &SD);

  TYPE diagonal_pn_calc (
			 const class uncoupled_TBMEs_class &M_TBMEs , 
			 const class Slater_determinant &SDp , 
			 const class Slater_determinant &SDn);

  TYPE no_pn_one_jump_mu_no_phase_calc (
					const enum interaction_type inter , 
					const bool is_one_body_part_non_zero , 
					const bool is_two_body_part_non_zero , 
					const class uncoupled_TBMEs_class &M_TBMEs , 
					const unsigned int in_jump , 
					const unsigned int out_jump , 
					const class Slater_determinant &outSD , 
					const class baryons_data &data);

  TYPE pn_no_phase_one_jump_p_calc (
				    const unsigned int p_in , const unsigned int p_out , 
				    const class Slater_determinant &SDn , 
				    const class uncoupled_TBMEs_class &M_TBMEs);

  TYPE pn_no_phase_one_jump_n_calc (
				    const unsigned int n_in , const unsigned int n_out , 
				    const class Slater_determinant &SDp , 
				    const class uncoupled_TBMEs_class &M_TBMEs);
}

#endif


