#ifndef GSMRMSRADIUSONEBODYSTRENGTH_H
#define GSMRMSRADIUSONEBODYSTRENGTH_H

// TYPE is double or complex
// -------------------------

namespace rms_radius_one_body_strength
{
  void calc_one_strength (
			  const enum particle_type particle ,
			  const bool is_it_Gauss_Legendre ,
			  class GSM_vector &PSI_full , 
			  const class GSM_vector &PSI_IN , 
			  const class GSM_vector &PSI_OUT , 
			  class array<TYPE> &rms_radius_one_body_strength);
 
  void calc_store_one_strength (
				const enum particle_type particle ,
				const bool is_it_Gauss_Legendre ,
				const class array<double> &r_bef_R_tab ,
				class GSM_vector &PSI_full , 
				const class correlated_state_str &PSI_qn , 
				const class GSM_vector &PSI);

  void calc_store (
		   const class input_data_str &input_data , 
		   const class array<class correlated_state_str> &PSI_qn_tab ,
		   class baryons_data &prot_Y_data , 
		   class baryons_data &neut_Y_data ,
		   class GSM_vector &PSI_full); 
}

#endif


