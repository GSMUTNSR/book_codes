#ifndef GSMBETATRANSITIONSNBMES_H
#define GSMBETATRANSITIONSNBMES_H

// TYPE is double or complex
// -------------------------

namespace beta_transitions_NBMEs
{
  void Op_PSI_IN_beta_plus_total_PSI_indices_components_calc (
							      const int rank_beta_operator , 
							      const int rank_beta_operator_projection , 
							      const class array<TYPE> &OBMEs , 
							      const unsigned int i_in , 
							      const class configuration &Cp_in , 
							      const class configuration &Cn_in , 
							      const class Slater_determinant &inSDp , 
							      const class Slater_determinant &inSDn ,
							      const unsigned int reordering_bin_phase_p ,
							      const unsigned int reordering_bin_phase_n ,
							      const TYPE &PSI_IN_component ,
							      const unsigned int p_in , 
							      const class GSM_vector &PSI_OUT ,
							      class Slater_determinant &outSDp ,
							      class Slater_determinant &outSDn ,
							      class Slater_determinant &SDp_try ,
							      class Slater_determinant &SDn_try ,
							      class configuration &Cp_out ,
							      class configuration &Cn_out ,
							      class configuration &Cp_try ,
							      class configuration &Cn_try ,
							      class array<unsigned int> &Op_PSI_IN_total_PSI_indices , 
							      class array<TYPE> &Op_PSI_IN_all_partial_components);

  void Op_PSI_IN_beta_minus_total_PSI_indices_components_calc (
							       const int rank_beta_operator , 
							       const int rank_beta_operator_projection ,
							       const class array<TYPE> &OBMEs , 
							       const unsigned int i_in , 
							       const class configuration &Cp_in , 
							       const class configuration &Cn_in , 
							       const class Slater_determinant &inSDp , 
							       const class Slater_determinant &inSDn ,
							       const unsigned int reordering_bin_phase_p ,
							       const unsigned int reordering_bin_phase_n , 
							       const TYPE &PSI_IN_component ,
							       const unsigned int n_in , 
							       const class GSM_vector &PSI_OUT ,
							       class Slater_determinant &outSDp ,
							       class Slater_determinant &outSDn ,
							       class Slater_determinant &SDp_try ,
							       class Slater_determinant &SDn_try ,
							       class configuration &Cp_out ,
							       class configuration &Cn_out ,
							       class configuration &Cp_try ,
							       class configuration &Cn_try ,
							       class array<unsigned int> &Op_PSI_IN_total_PSI_indices , 
							       class array<TYPE> &Op_PSI_IN_all_partial_components);
	
  TYPE calc (
	     const enum beta_pm_type beta_pm , 
	     const enum beta_suboperator_type beta_suboperator , 
	     const bool full_common_vectors_used_in_file ,
	     const class array<TYPE> &OBMEs , 
	     const class correlated_state_str &PSI_IN_qn , 
	     const class correlated_state_str &PSI_OUT_qn , 
	     const class GSM_vector &PSI_OUT);
}

#endif


