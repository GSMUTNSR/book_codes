#ifndef GSMRMSRADIUS_H
#define GSMRMSRADIUS_H

// TYPE is double or complex
// -------------------------

namespace rms_radius
{
  void calc_print (
		   const class input_data_str &input_data , 
		   const class array<class correlated_state_str> &PSI_qn_tab , 
		   class nucleons_data &prot_data , 
		   class nucleons_data &neut_data ,
		   class GSM_vector &PSI_full); 
}

#endif


