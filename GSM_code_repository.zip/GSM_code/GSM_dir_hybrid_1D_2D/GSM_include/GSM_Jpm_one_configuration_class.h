#ifndef GSMJPMONECONFIGURATIONCLASS_H
#define GSMJPMONECONFIGURATIONCLASS_H

// TYPE is double or complex
// -------------------------

class Jpm_one_configuration_class
{
public:

  Jpm_one_configuration_class ();
  
  Jpm_one_configuration_class (
			       const int pm_c , 
			       const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in , 
			       const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_out);

  Jpm_one_configuration_class (const class Jpm_one_configuration_class &X);

  ~Jpm_one_configuration_class ();
  
  void allocate (
		 const int pm_c , 
		 const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in , 
		 const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_out);

  void allocate_fill (const class Jpm_one_configuration_class &X);

  void deallocate ();
  
  bool is_it_filled () const;
  
  void apply_add (
		  const class GSM_vector_one_configuration &PSI_in , 
		  class GSM_vector_one_configuration &PSI_out) const;
  
  void print () const;
  
  int get_pm () const
  {
    return pm;
  }
  
  const class GSM_vector_helper_one_configuration_class & get_GSM_vector_helper_in () const
  {
    return *GSM_vector_helper_in_ptr;
  }
  
  const class GSM_vector_helper_one_configuration_class & get_GSM_vector_helper_out () const
  {
    return *GSM_vector_helper_out_ptr;
  }
  
  friend double used_memory_calc (const class Jpm_one_configuration_class &T);
  
private:	
  
  void non_zero_NBMEs_numbers_one_jump_p_part_pn_calc ();

  void non_zero_NBMEs_numbers_one_jump_n_part_pn_calc ();

  void non_zero_NBMEs_numbers_pp_nn_calc ();

  void rows_non_zero_NBMEs_numbers_calc ();

  void Jpm_part_one_jump_pp_nn_store (
				      const unsigned int PSI_out_index ,
				      const unsigned int dimension_one_jump , 
				      const class array<unsigned int> &PSI_in_indices ,
				      const class array<double> &NBMEs_one_jump);
  
  void one_jump_p_part_pn_calc_store ();

  void one_jump_n_part_pn_calc_store ();

  void pp_nn_calc_store ();

  void matrix_store ();

  int pm; // It is 1 for J+ and -1 for J-.
   
  const class GSM_vector_helper_one_configuration_class *GSM_vector_helper_in_ptr;  // pointer to data necessary to handle |Psi[in]>. It does not contain their vector components.
  const class GSM_vector_helper_one_configuration_class *GSM_vector_helper_out_ptr; // pointer to data necessary to handle |Psi[out]>. It does not contain their vector components.
  
  class array<double> Jpm_prot_OBMEs_tab; // proton  OBMEs of the j+ operator
  class array<double> Jpm_neut_OBMEs_tab; // neutron OBMEs of the j+ operator

  class array<unsigned int> rows_non_zero_NBMEs_numbers;    // number of non-zeros NBMEs per row
  
  class array<unsigned int> rows_non_zero_NBMEs_PSI_in_indices;  // indices of the SDs of |Psi[in]> leading to non-zeros NBMEs per row
  
  class array<double> rows_non_zero_NBMEs;    // non-zeros NBMEs per row
};




class xJpm_one_configuration_str
{
public:

  const TYPE x;
  const class Jpm_one_configuration_class &Jpm;

  xJpm_one_configuration_str (const TYPE &x_c , const class Jpm_one_configuration_class &Jpm_c);
};

class xJpm_one_configuration_str operator + (const class Jpm_one_configuration_class &Jpm);
class xJpm_one_configuration_str operator - (const class Jpm_one_configuration_class &Jpm);

class xJpm_one_configuration_str operator * (const class Jpm_one_configuration_class &Jpm , const double x);
class xJpm_one_configuration_str operator * (const double x , const class Jpm_one_configuration_class &Jpm);
class xJpm_one_configuration_str operator / (const class Jpm_one_configuration_class &Jpm , const double x);

class xJpm_one_configuration_str operator + (const class xJpm_one_configuration_str &xJpm);
class xJpm_one_configuration_str operator - (const class xJpm_one_configuration_str &xJpm);

class xJpm_one_configuration_str operator * (const class xJpm_one_configuration_str &Op , const double factor);
class xJpm_one_configuration_str operator / (const class xJpm_one_configuration_str &Op , const double factor);

class xJpm_one_configuration_str operator * (const double factor , const class xJpm_one_configuration_str &Op);

class xJpm_one_configuration_str operator * (const class Jpm_one_configuration_class &Jpm , const complex<double> &x);
class xJpm_one_configuration_str operator * (const complex<double> &x , const class Jpm_one_configuration_class &Jpm);
class xJpm_one_configuration_str operator / (const class Jpm_one_configuration_class &Jpm , const complex<double> &x);

class xJpm_one_configuration_str operator * (const class xJpm_one_configuration_str &Op , const complex<double> &factor);
class xJpm_one_configuration_str operator / (const class xJpm_one_configuration_str &Op , const complex<double> &factor);

class xJpm_one_configuration_str operator * (const complex<double> &factor , const class xJpm_one_configuration_str &Op);

class xJpm_one_configuration_str operator + (const class xJpm_one_configuration_str &Op_a , const class xJpm_one_configuration_str &Op_b);
class xJpm_one_configuration_str operator - (const class xJpm_one_configuration_str &Op_a , const class xJpm_one_configuration_str &Op_b);

#endif


