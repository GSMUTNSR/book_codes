#ifndef SDONEJUMPCONSTRUCTIONSETINTOOUT_H
#define SDONEJUMPCONSTRUCTIONSETINTOOUT_H


// TYPE is double or complex
// -------------------------

namespace SD_one_jump_construction_set_in_to_out
{
  void SD_one_jump_data_Jpm_fill (
				  const enum operation_type operation , 
				  const unsigned int shell_index ,
				  const int im_out , 
				  const unsigned int Delta_iM_out , 
				  const unsigned int bin_phase , 
				  const unsigned int outSD_index , 
				  const unsigned long int SD_one_jump_table_Jpm_zero_index , 
				  const unsigned long int dimensions_SD_one_jump_table_Jpm_index ,  
				  class baryons_data &particles_data);

  void SD_one_jump_table_all_outSD_Jpm (
					const enum operation_type operation , 
					const unsigned long int dimensions_SD_one_jump_table_Jpm_zero_index , 
					const unsigned int BP , 
					const int S , 
					const int n_spec ,
					const int n_scat ,
					const unsigned int iC , 
					const int iM_in ,
					const unsigned int inSD_index ,
					const class Slater_determinant &inSD ,
					class Slater_determinant &outSD ,
					class Slater_determinant &SD_try ,  
					class baryons_data &particles_data);
  
  void SD_one_jump_table_all_outSD_Jpm (
					const enum operation_type operation ,
					const int pm ,
					const unsigned long int dimensions_SD_one_jump_table_Jpm_zero_index , 
					const unsigned int BP , 
					const int S , 
					const int n_spec ,
					const int n_scat ,
					const unsigned int iC , 
					const int iM_in ,
					const unsigned int inSD_index ,
					const class Slater_determinant &inSD ,
					class Slater_determinant &outSD ,
					class Slater_determinant &SD_try ,  
					class baryons_data &particles_data);

  void all_SDs_one_jump_all_SDs_Jpm (
				     const enum operation_type operation , 
				     const bool is_it_pole_approximation , 
				     const bool is_it_both_Jplus_Jminus ,
				     const int pm ,
				     class baryons_data &particles_data);

  void all_SDs_one_jump_all_SDs_alloc_calc_Jpm (
						const bool is_there_cout , 
						const bool is_it_pole_approximation ,
						const bool is_it_both_Jplus_Jminus ,
						const int pm ,  
						class baryons_data &particles_data);

  void SD_one_jump_data_fill (
			      const enum operation_type operation , 
			      const unsigned long int dimensions_SD_one_jump_table_index , 
			      const unsigned long int SD_one_jump_table_zero_index , 
			      const unsigned int dimension_outSD_set ,
			      const unsigned long int SD_set_zero_outSD_index ,
			      const int Delta_iM_out , 
			      const unsigned int bin_phase ,
			      const int im_out , 
			      const unsigned int C_eq_one_jump_index , 
			      const class Slater_determinant &outSD , 
			      class Slater_determinant &SD_try , 
			      class baryons_data &particles_data);

  void SD_one_jump_table_all_outSD (
				    const enum operation_type operation , 
				    const class configuration &C_in , 
				    const class Slater_determinant &inSD ,
				    const unsigned long int dimensions_SD_one_jump_table_index , 
				    const unsigned long int SD_one_jump_table_zero_index , 
				    const unsigned int C_eq_one_jump_index ,
				    const unsigned int dimension_outSD_set ,
				    const unsigned long int SD_set_zero_outSD_index ,
				    const int Delta_iM_out , 
				    const unsigned int C_in_jump_shell ,
				    const unsigned int C_out_jump_shell , 
				    class Slater_determinant &outSD ,
				    class Slater_determinant &SD_try ,   
				    class baryons_data &particles_data);

  void all_SDs_one_jump_all_SDs (
				 const bool is_it_one_body ,
				 const bool is_it_two_body_pn_only , 
				 const enum operation_type operation , 
				 const bool is_it_pole_approximation , 
				 class baryons_data &particles_data);

  void all_SDs_one_jump_all_SDs_alloc_calc (
					    const bool is_there_cout , 	
					    const bool is_it_one_body ,
					    const bool is_it_two_body_pn_only , 
					    const bool is_it_pole_approximation , 
					    class baryons_data &particles_data);
}

#endif


