#ifndef GSMDAGGERTILDEOPERATORS_H
#define GSMDAGGERTILDEOPERATORS_H

// TYPE is double or complex
// -------------------------

namespace dagger_tilde_operators
{
  void a_dagger_a_tilde_MK_table_pn_calc (
					  const enum dagger_tilde_operator_type dagger_tilde_operator , 
					  const class nlj_struct &shell_dagger_a_qn , 
					  const class nlj_struct &shell_tilde_b_qn , 
					  const class correlated_state_str &PSI_IN_qn , 
					  const class correlated_state_str &PSI_OUT_qn , 
					  const class GSM_vector &PSI_OUT_full ,
					  const class array<unsigned int> &inSDp_tab ,
					  const class array<unsigned int> &inSDn_tab ,
					  const class array<TYPE> &PSI_IN_component_tab ,
					  const class array<bool> &is_inSDp_in_new_space_tab ,
					  const class array<bool> &is_inSDn_in_new_space_tab ,
					  const class array<unsigned char> &reordering_bin_phases_p ,
					  const class array<unsigned char> &reordering_bin_phases_n ,
					  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_MK_table);

  void a_dagger_a_tilde_MK_RDM_pn_calc (
					const enum dagger_tilde_operator_type dagger_tilde_operator ,
					const class nljm_struct &phi_dagger_d , 
					const class nljm_struct &phi_tilde_c , 
					const class array<unsigned int> &inSDp_tab ,
					const class array<unsigned int> &inSDn_tab ,
					const class GSM_vector &PSI_IN ,
					class GSM_vector &PSI_OUT_full);
 
  void a_dagger_a_dagger_MK_table_pn_calc (
					   const enum dagger_tilde_operator_type dagger_tilde_operator , 
					   const class nlj_struct &shell_dagger_a_qn , 
					   const class nlj_struct &shell_dagger_b_qn , 
					   const class correlated_state_str &PSI_IN_qn , 
					   const class correlated_state_str &PSI_OUT_qn , 
					   const class GSM_vector &PSI_OUT_full ,
					   const class array<unsigned int> &inSDp_tab ,
					   const class array<unsigned int> &inSDn_tab ,
					   const class array<TYPE> &PSI_IN_component_tab ,
					   const class array<bool> &is_inSDp_in_new_space_tab ,
					   const class array<bool> &is_inSDn_in_new_space_tab ,
					   const class array<unsigned char> &reordering_bin_phases_p ,
					   const class array<unsigned char> &reordering_bin_phases_n ,
					   class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_MK_table);
 
  void a_dagger_a_dagger_MK_RDM_pn_calc (
					 const enum dagger_tilde_operator_type dagger_tilde_operator , 
					 const class nljm_struct &phi_dagger_d , 
					 const class nljm_struct &phi_dagger_c , 
					 const class array<unsigned int> &inSDp_tab ,
					 const class array<unsigned int> &inSDn_tab ,
					 const class GSM_vector &PSI_IN ,
					 class GSM_vector &PSI_OUT_full);
 
  void a_tilde_a_tilde_MK_table_pn_calc (
					 const enum dagger_tilde_operator_type dagger_tilde_operator , 
					 const class nlj_struct &shell_tilde_a_qn , 
					 const class nlj_struct &shell_tilde_b_qn , 
					 const class correlated_state_str &PSI_IN_qn , 
					 const class correlated_state_str &PSI_OUT_qn , 
					 const class GSM_vector &PSI_OUT_full ,
					 const class array<unsigned int> &inSDp_tab ,
					 const class array<unsigned int> &inSDn_tab ,
					 const class array<TYPE> &PSI_IN_component_tab ,
					 const class array<bool> &is_inSDp_in_new_space_tab ,
					 const class array<bool> &is_inSDn_in_new_space_tab ,
					 const class array<unsigned char> &reordering_bin_phases_p ,
					 const class array<unsigned char> &reordering_bin_phases_n ,
					 class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_MK_table);
 
  void a_tilde_a_tilde_MK_RDM_pn_calc (
				       const enum dagger_tilde_operator_type dagger_tilde_operator , 
				       const class nljm_struct &phi_tilde_d , 
				       const class nljm_struct &phi_tilde_c , 
				       const class array<unsigned int> &inSDp_tab ,
				       const class array<unsigned int> &inSDn_tab ,
				       const class GSM_vector &PSI_IN ,
				       class GSM_vector &PSI_OUT_full);
 
  void a_dagger_a_dagger_a_tilde_MK_table_pn_calc (
						   const enum dagger_tilde_operator_type dagger_tilde_operator , 
						   const class nlj_struct &shell_dagger_a_qn , 
						   const class nlj_struct &shell_dagger_b_qn , 
						   const class nlj_struct &shell_tilde_c_qn , 
						   const class correlated_state_str &PSI_IN_qn , 
						   const class correlated_state_str &PSI_OUT_qn , 
						   const class GSM_vector &PSI_OUT_full ,
						   const class array<unsigned int> &inSDp_tab ,
						   const class array<unsigned int> &inSDn_tab ,
						   const class array<TYPE> &PSI_IN_component_tab ,
						   const class array<bool> &is_inSDp_in_new_space_tab ,
						   const class array<bool> &is_inSDn_in_new_space_tab ,
						   const class array<unsigned char> &reordering_bin_phases_p ,
						   const class array<unsigned char> &reordering_bin_phases_n ,
						   class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_tilde_MK_table);
 
  void a_dagger_a_dagger_a_tilde_MK_RDM_pn_calc (
						 const enum dagger_tilde_operator_type dagger_tilde_operator ,  
						 const class nljm_struct &phi_dagger_f , 
						 const class nljm_struct &phi_dagger_e , 
						 const class nljm_struct &phi_tilde_d , 
						 const class array<unsigned int> &inSDp_tab ,
						 const class array<unsigned int> &inSDn_tab ,
						 const class GSM_vector &PSI_IN ,
						 class GSM_vector &PSI_OUT_full);
 
  void a_dagger_a_tilde_a_tilde_MK_table_pn_calc (
						  const enum dagger_tilde_operator_type dagger_tilde_operator , 
						  const class nlj_struct &shell_dagger_a_qn , 
						  const class nlj_struct &shell_tilde_b_qn , 
						  const class nlj_struct &shell_tilde_c_qn , 
						  const class correlated_state_str &PSI_IN_qn , 
						  const class correlated_state_str &PSI_OUT_qn , 
						  const class GSM_vector &PSI_OUT_full ,
						  const class array<unsigned int> &inSDp_tab ,
						  const class array<unsigned int> &inSDn_tab ,
						  const class array<TYPE> &PSI_IN_component_tab ,
						  const class array<bool> &is_inSDp_in_new_space_tab ,
						  const class array<bool> &is_inSDn_in_new_space_tab ,
						  const class array<unsigned char> &reordering_bin_phases_p ,
						  const class array<unsigned char> &reordering_bin_phases_n ,
						  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_a_tilde_MK_table);
 
  void a_dagger_a_tilde_a_tilde_MK_RDM_pn_calc (
						const enum dagger_tilde_operator_type dagger_tilde_operator ,
						const class nljm_struct &phi_dagger_f , 
						const class nljm_struct &phi_tilde_e , 
						const class nljm_struct &phi_tilde_d ,
						const class array<unsigned int> &inSDp_tab ,
						const class array<unsigned int> &inSDn_tab ,
						const class GSM_vector &PSI_IN ,
						class GSM_vector &PSI_OUT_full);
 
  void a_dagger_a_dagger_a_dagger_MK_table_pn_calc (
						    const enum dagger_tilde_operator_type dagger_tilde_operator , 
						    const class nlj_struct &shell_dagger_a_qn , 
						    const class nlj_struct &shell_dagger_b_qn ,
						    const class nlj_struct &shell_dagger_c_qn ,  
						    const class correlated_state_str &PSI_IN_qn , 
						    const class correlated_state_str &PSI_OUT_qn , 
						    const class GSM_vector &PSI_OUT_full ,
						    const class array<unsigned int> &inSDp_tab ,
						    const class array<unsigned int> &inSDn_tab ,
						    const class array<TYPE> &PSI_IN_component_tab ,
						    const class array<bool> &is_inSDp_in_new_space_tab ,
						    const class array<bool> &is_inSDn_in_new_space_tab ,
						    const class array<unsigned char> &reordering_bin_phases_p ,
						    const class array<unsigned char> &reordering_bin_phases_n ,
						    class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_dagger_MK_table);
 
  void a_dagger_a_dagger_a_dagger_MK_RDM_pn_calc (
						  const enum dagger_tilde_operator_type dagger_tilde_operator ,
						  const class nljm_struct &phi_dagger_f , 
						  const class nljm_struct &phi_dagger_e ,
						  const class nljm_struct &phi_dagger_d ,  
						  const class array<unsigned int> &inSDp_tab ,
						  const class array<unsigned int> &inSDn_tab ,
						  const class GSM_vector &PSI_IN ,
						  class GSM_vector &PSI_OUT_full);
 
  void a_tilde_a_tilde_a_tilde_MK_table_pn_calc (
						 const enum dagger_tilde_operator_type dagger_tilde_operator , 
						 const class nlj_struct &shell_tilde_a_qn , 
						 const class nlj_struct &shell_tilde_b_qn , 
						 const class nlj_struct &shell_tilde_c_qn , 
						 const class correlated_state_str &PSI_IN_qn , 
						 const class correlated_state_str &PSI_OUT_qn , 
						 const class GSM_vector &PSI_OUT_full ,
						 const class array<unsigned int> &inSDp_tab ,
						 const class array<unsigned int> &inSDn_tab ,
						 const class array<TYPE> &PSI_IN_component_tab ,
						 const class array<bool> &is_inSDp_in_new_space_tab ,
						 const class array<bool> &is_inSDn_in_new_space_tab ,
						 const class array<unsigned char> &reordering_bin_phases_p ,
						 const class array<unsigned char> &reordering_bin_phases_n ,
						 class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_a_tilde_MK_table);
 
  void a_tilde_a_tilde_a_tilde_MK_RDM_pn_calc (
					       const enum dagger_tilde_operator_type dagger_tilde_operator , 
					       const class nljm_struct &phi_tilde_f, 
					       const class nljm_struct &phi_tilde_e , 
					       const class nljm_struct &phi_tilde_d , 
					       const class array<unsigned int> &inSDp_tab ,
					       const class array<unsigned int> &inSDn_tab ,
					       const class GSM_vector &PSI_IN ,
					       class GSM_vector &PSI_OUT_full);
 
  void a_dagger_a_tilde_MK_table_pp_nn_calc (
					     const enum dagger_tilde_operator_type dagger_tilde_operator ,
					     const class nlj_struct &shell_dagger_a_qn , 
					     const class nlj_struct &shell_tilde_b_qn , 
					     const class correlated_state_str &PSI_IN_qn , 
					     const class correlated_state_str &PSI_OUT_qn , 
					     const class GSM_vector &PSI_OUT_full ,
					     const class array<unsigned int> &inSD_tab ,
					     const class array<TYPE> &PSI_IN_component_tab ,
					     const class array<bool> &is_inSD_in_new_space_tab ,
					     const class array<unsigned char> &reordering_bin_phases ,
					     class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_MK_table);
 
  void a_dagger_a_tilde_MK_RDM_pp_nn_calc (
					   const enum dagger_tilde_operator_type dagger_tilde_operator , 
					   const class nljm_struct &phi_dagger_d , 
					   const class nljm_struct &phi_tilde_c , 
					   const class array<unsigned int> &inSD_tab ,
					   const class GSM_vector &PSI_IN ,
					   class GSM_vector &PSI_OUT_full);
 
  void a_dagger_a_dagger_MK_table_pp_nn_calc (
					      const enum dagger_tilde_operator_type dagger_tilde_operator ,
					      const class nlj_struct &shell_dagger_a_qn , 
					      const class nlj_struct &shell_dagger_b_qn , 
					      const class correlated_state_str &PSI_IN_qn , 
					      const class correlated_state_str &PSI_OUT_qn , 
					      const class GSM_vector &PSI_OUT_full ,
					      const class array<unsigned int> &inSD_tab ,
					      const class array<TYPE> &PSI_IN_component_tab ,
					      const class array<bool> &is_inSD_in_new_space_tab ,
					      const class array<unsigned char> &reordering_bin_phases ,
					      class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_MK_table);
 
  void a_dagger_a_dagger_MK_RDM_pp_nn_calc (
					    const enum dagger_tilde_operator_type dagger_tilde_operator , 
					    const class nljm_struct &phi_dagger_d , 
					    const class nljm_struct &phi_dagger_c , 
					    const class array<unsigned int> &inSD_tab ,
					    const class GSM_vector &PSI_IN ,
					    class GSM_vector &PSI_OUT_full);
 
  void a_tilde_a_tilde_MK_table_pp_nn_calc (
					    const enum dagger_tilde_operator_type dagger_tilde_operator , 
					    const class nlj_struct &shell_tilde_a_qn , 
					    const class nlj_struct &shell_tilde_b_qn , 
					    const class correlated_state_str &PSI_IN_qn , 
					    const class correlated_state_str &PSI_OUT_qn , 
					    const class GSM_vector &PSI_OUT_full ,
					    const class array<unsigned int> &inSD_tab ,
					    const class array<TYPE> &PSI_IN_component_tab ,
					    const class array<bool> &is_inSD_in_new_space_tab ,
					    const class array<unsigned char> &reordering_bin_phases ,
					    class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_MK_table);
 
  void a_tilde_a_tilde_MK_RDM_pp_nn_calc (
					  const enum dagger_tilde_operator_type dagger_tilde_operator , 
					  const class nljm_struct &phi_tilde_d , 
					  const class nljm_struct &phi_tilde_c , 
					  const class array<unsigned int> &inSD_tab ,
					  const class GSM_vector &PSI_IN ,
					  class GSM_vector &PSI_OUT_full);
 
  void a_dagger_a_dagger_a_tilde_MK_table_pp_nn_calc (
						      const enum dagger_tilde_operator_type dagger_tilde_operator , 
						      const class nlj_struct &shell_dagger_a_qn , 
						      const class nlj_struct &shell_dagger_b_qn , 
						      const class nlj_struct &shell_tilde_c_qn , 
						      const class correlated_state_str &PSI_IN_qn , 
						      const class correlated_state_str &PSI_OUT_qn , 
						      const class GSM_vector &PSI_OUT_full ,
						      const class array<unsigned int> &inSD_tab ,
						      const class array<TYPE> &PSI_IN_component_tab ,
						      const class array<bool> &is_inSD_in_new_space_tab ,
						      const class array<unsigned char> &reordering_bin_phases ,
						      class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_tilde_MK_table);
 
  void a_dagger_a_dagger_a_tilde_MK_RDM_pp_nn_calc (
						    const enum dagger_tilde_operator_type dagger_tilde_operator , 
						    const class nljm_struct &phi_dagger_f , 
						    const class nljm_struct &phi_dagger_e , 
						    const class nljm_struct &phi_tilde_d , 
						    const class array<unsigned int> &inSD_tab ,
						    const class GSM_vector &PSI_IN ,
						    class GSM_vector &PSI_OUT_full);
 
  void a_dagger_a_tilde_a_tilde_MK_table_pp_nn_calc (
						     const enum dagger_tilde_operator_type dagger_tilde_operator , 
						     const class nlj_struct &shell_dagger_a_qn , 
						     const class nlj_struct &shell_tilde_b_qn , 
						     const class nlj_struct &shell_tilde_c_qn , 
						     const class correlated_state_str &PSI_IN_qn , 
						     const class correlated_state_str &PSI_OUT_qn , 
						     const class GSM_vector &PSI_OUT_full ,
						     const class array<unsigned int> &inSD_tab ,
						     const class array<TYPE> &PSI_IN_component_tab ,
						     const class array<bool> &is_inSD_in_new_space_tab ,
						     const class array<unsigned char> &reordering_bin_phases ,
						     class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_a_tilde_MK_table);
 
  void a_dagger_a_tilde_a_tilde_MK_RDM_pp_nn_calc (
						   const enum dagger_tilde_operator_type dagger_tilde_operator , 
						   const class nljm_struct &phi_dagger_f , 
						   const class nljm_struct &phi_tilde_e , 
						   const class nljm_struct &phi_tilde_d , 
						   const class array<unsigned int> &inSD_tab ,
						   const class GSM_vector &PSI_IN ,
						   class GSM_vector &PSI_OUT_full);
 
  void a_dagger_a_dagger_a_dagger_MK_table_pp_nn_calc (
						       const enum dagger_tilde_operator_type dagger_tilde_operator , 
						       const class nlj_struct &shell_dagger_a_qn , 
						       const class nlj_struct &shell_dagger_b_qn , 
						       const class nlj_struct &shell_dagger_c_qn , 
						       const class correlated_state_str &PSI_IN_qn , 
						       const class correlated_state_str &PSI_OUT_qn , 
						       const class GSM_vector &PSI_OUT_full ,
						       const class array<unsigned int> &inSD_tab ,
						       const class array<TYPE> &PSI_IN_component_tab ,
						       const class array<bool> &is_inSD_in_new_space_tab ,
						       const class array<unsigned char> &reordering_bin_phases ,
						       class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_dagger_MK_table);
 
  void a_dagger_a_dagger_a_dagger_MK_RDM_pp_nn_calc (
						     const enum dagger_tilde_operator_type dagger_tilde_operator , 
						     const class nljm_struct &phi_dagger_f , 
						     const class nljm_struct &phi_dagger_e , 
						     const class nljm_struct &phi_dagger_d , 
						     const class array<unsigned int> &inSD_tab ,
						     const class GSM_vector &PSI_IN ,
						     class GSM_vector &PSI_OUT_full);
 
  void a_tilde_a_tilde_a_tilde_MK_table_pp_nn_calc (
						    const enum dagger_tilde_operator_type dagger_tilde_operator , 
						    const class nlj_struct &shell_tilde_a_qn , 
						    const class nlj_struct &shell_tilde_b_qn , 
						    const class nlj_struct &shell_tilde_c_qn , 
						    const class correlated_state_str &PSI_IN_qn , 
						    const class correlated_state_str &PSI_OUT_qn , 
						    const class GSM_vector &PSI_OUT_full ,
						    const class array<unsigned int> &inSD_tab ,
						    const class array<TYPE> &PSI_IN_component_tab ,
						    const class array<bool> &is_inSD_in_new_space_tab ,
						    const class array<unsigned char> &reordering_bin_phases ,
						    class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_a_tilde_MK_table);
 
  void a_tilde_a_tilde_a_tilde_MK_RDM_pp_nn_calc (
						  const enum dagger_tilde_operator_type dagger_tilde_operator , 
						  const class nljm_struct &phi_tilde_f , 
						  const class nljm_struct &phi_tilde_e , 
						  const class nljm_struct &phi_tilde_d , 
						  const class array<unsigned int> &inSD_tab ,
						  const class GSM_vector &PSI_IN ,
						  class GSM_vector &PSI_OUT_full);
 
  void two_body_K_tables_calc_store (
				     const bool full_common_vectors_used_in_file , 
				     const enum dagger_tilde_operator_type dagger_tilde_operator , 
				     const class correlated_state_str &PSI_IN_qn , 
				     const class correlated_state_str &PSI_OUT_qn , 
				     const class GSM_vector &PSI_OUT_full);
 
  void three_body_L_K_tables_calc_store (
					 const bool full_common_vectors_used_in_file , 
					 const enum dagger_tilde_operator_type dagger_tilde_operator , 
					 const class correlated_state_str &PSI_IN_qn , 
					 const class correlated_state_str &PSI_OUT_qn , 
					 const class GSM_vector &PSI_OUT_full);
 
  void PQG_uncoupled_MEs_table_calc (
				     const bool full_common_vectors_used_in_file , 
				     const enum dagger_tilde_operator_type dagger_tilde_operator ,
				     const class correlated_state_str &PSI_IN_qn , 
				     class GSM_vector_helper_class &GSM_vector_helper_IN ,
				     class array<TYPE> &PQG_uncoupled_MEs_table);
 
  void T1_T2_part_uncoupled_MEs_table_calc (
					    const bool full_common_vectors_used_in_file , 
					    const enum dagger_tilde_operator_type dagger_tilde_operator ,
					    const class correlated_state_str &PSI_IN_qn ,
					    class GSM_vector_helper_class &GSM_vector_helper_IN ,
					    class array<TYPE> &T1_T2_part_uncoupled_MEs_table);

  void calc_store_PSI_IN_OUT (
			      const input_data_str &input_data , 
			      const class array<class correlated_state_str> &PSI_qn_tab ,
			      const unsigned int dagger_tilde_operators_index ,
			      class nucleons_data &prot_data , 
			      class nucleons_data &neut_data);
 
  void calc_store_RDM (
		       const input_data_str &input_data , 
		       const class array<class correlated_state_str> &PSI_qn_tab ,
		       const unsigned int dagger_tilde_operators_index , 
		       class nucleons_data &prot_data , 
		       class nucleons_data &neut_data);
 
  void calc_store (
		   const input_data_str &input_data , 
		   const class array<class correlated_state_str> &PSI_qn_tab ,
		   class nucleons_data &prot_data , 
		   class nucleons_data &neut_data);
}

#endif


