#ifndef GSMJ2CLASS_H
#define GSMJ2CLASS_H

// TYPE is double or complex
// -------------------------

class J2_class
{
public:

  J2_class ();
	    
  J2_class (
	    const class Jpm_class &Jplus , 
	    const class Jpm_class &Jminus , 
	    class GSM_vector &PSI_Mp1);

  J2_class (const class J2_class &X);

  ~J2_class ();
	    
  void allocate (
		 const class Jpm_class &Jplus , 
		 const class Jpm_class &Jminus , 
		 class GSM_vector &PSI_Mp1);

  void allocate_fill (const class J2_class &X);

  void deallocate ();

  bool is_it_filled () const;
  
  void apply_add (
		  const class GSM_vector &PSI_in , 
		  const TYPE &alpha , 
		  class GSM_vector &PSI_out) const;

  double J_coupling_precision_calc (
				    const class GSM_vector &PSI , 
				    const double J , 
				    class GSM_vector &PSI_test) const;
    
  void time_multiplications_data_print () const;
  
  const class Jpm_class & get_Jplus () const
  {
    return *Jplus_ptr;
  }
  
  const class Jpm_class & get_Jminus () const
  {
    return *Jminus_ptr;
  }
  
  class GSM_vector & get_PSI_Mp1 () const
  {
    return *PSI_Mp1_ptr;
  }
  
private:
  
  const class Jpm_class *Jplus_ptr;  // Pointer to class containing data related to J+
  const class Jpm_class *Jminus_ptr; // Pointer to class containing data related to J-
  
  class GSM_vector *PSI_Mp1_ptr; // pointer to GSM vector whose M-projection is equal to M+1. It is necessary to store J+|Psi[in]>.
};

double used_memory_calc (const class J2_class &T);



class xJ2_plus_alpha_str
{
public:

  const TYPE x;
  const TYPE alpha;
  
  const class J2_class &J2;

  xJ2_plus_alpha_str (const TYPE &x_c , const TYPE &alpha_c , const class J2_class &J2_c);
};

class xJ2_plus_alpha_str operator + (const class J2_class &J2);
class xJ2_plus_alpha_str operator - (const class J2_class &J2);

class xJ2_plus_alpha_str operator + (const class J2_class &J2 , const double term);
class xJ2_plus_alpha_str operator - (const class J2_class &J2 , const double term);

class xJ2_plus_alpha_str operator + (const double term , const class J2_class &J2);
class xJ2_plus_alpha_str operator - (const double term , const class J2_class &J2);

class xJ2_plus_alpha_str operator * (const class J2_class &J2 , const double x);
class xJ2_plus_alpha_str operator * (const double x , const class J2_class &J2);
class xJ2_plus_alpha_str operator / (const class J2_class &J2 , const double x);

class xJ2_plus_alpha_str operator + (const class xJ2_plus_alpha_str &Op);
class xJ2_plus_alpha_str operator - (const class xJ2_plus_alpha_str &Op);

class xJ2_plus_alpha_str operator + (const class xJ2_plus_alpha_str &Op , const double term);
class xJ2_plus_alpha_str operator - (const class xJ2_plus_alpha_str &Op , const double term);

class xJ2_plus_alpha_str operator + (const double alpha , const class xJ2_plus_alpha_str &Op);
class xJ2_plus_alpha_str operator - (const double alpha , const class xJ2_plus_alpha_str &Op);

class xJ2_plus_alpha_str operator * (const class xJ2_plus_alpha_str &Op , const double factor);
class xJ2_plus_alpha_str operator / (const class xJ2_plus_alpha_str &Op , const double factor);
class xJ2_plus_alpha_str operator * (const double factor , const class xJ2_plus_alpha_str &Op);

class xJ2_plus_alpha_str operator + (const class J2_class &J2 , const complex<double> &term);
class xJ2_plus_alpha_str operator - (const class J2_class &J2 , const complex<double> &term);

class xJ2_plus_alpha_str operator + (const complex<double> &term , const class J2_class &J2);
class xJ2_plus_alpha_str operator - (const complex<double> &term , const class J2_class &J2);

class xJ2_plus_alpha_str operator * (const class J2_class &J2 , const complex<double> &x);
class xJ2_plus_alpha_str operator * (const complex<double> &x , const class J2_class &J2);
class xJ2_plus_alpha_str operator / (const class J2_class &J2 , const complex<double> &x);

class xJ2_plus_alpha_str operator + (const class xJ2_plus_alpha_str &Op , const complex<double> &term);
class xJ2_plus_alpha_str operator - (const class xJ2_plus_alpha_str &Op , const complex<double> &term);

class xJ2_plus_alpha_str operator + (const complex<double> &alpha , const class xJ2_plus_alpha_str &Op);
class xJ2_plus_alpha_str operator - (const complex<double> &alpha , const class xJ2_plus_alpha_str &Op);

class xJ2_plus_alpha_str operator * (const class xJ2_plus_alpha_str &Op , const complex<double> &factor);
class xJ2_plus_alpha_str operator / (const class xJ2_plus_alpha_str &Op , const complex<double> &factor);
class xJ2_plus_alpha_str operator * (const complex<double> &factor , const class xJ2_plus_alpha_str &Op);

class xJ2_plus_alpha_str operator + (const class xJ2_plus_alpha_str &Op_a , const class xJ2_plus_alpha_str &Op_b);
class xJ2_plus_alpha_str operator - (const class xJ2_plus_alpha_str &Op_a , const class xJ2_plus_alpha_str &Op_b);

#endif

