#ifndef GSMVECTOR_H
#define GSMVECTOR_H

// TYPE is double or complex
// -------------------------

class GSM_vector
{
public:

  GSM_vector ();
  
  explicit GSM_vector (class GSM_vector_helper_class &GSM_vector_helper);

  GSM_vector (const class GSM_vector &V);
  GSM_vector (const class Op_PSI_closure_str &closure);

  ~GSM_vector ();
  
  void allocate (class GSM_vector_helper_class &GSM_vector_helper);

  void virtual_allocate (class GSM_vector_helper_class &GSM_vector_helper , const class GSM_vector &V);
  
  void allocate_fill (const class GSM_vector &V);
  void allocate_calc (const class Op_PSI_closure_str &closure);

  void deallocate ();

  bool is_it_filled () const
  {
    return (table != NULL);
  }

  bool get_is_it_virtual_allocation () const
  {
    return is_it_virtual_allocation;
  }
  
  unsigned int get_space_dimensions_all_processes_max () const
  {
    return space_dimensions_all_processes_max;	
  }

  class GSM_vector_helper_class & get_GSM_vector_helper () const
  {
    return *GSM_vector_helper_ptr;
  }

  class GSM_vector_helper_class & get_GSM_vector_helper ()
  {
    return *GSM_vector_helper_ptr;
  }
  
  const class GSM_vector & operator = (const class GSM_vector &);
  const class GSM_vector & operator = (const complex<double> &);
  const class GSM_vector & operator = (const double);
  const class GSM_vector & operator = (const class Op_PSI_closure_str &);
  const class GSM_vector & operator = (const class a_dagger_nucleon_PSI_str &);
  const class GSM_vector & operator = (const class x_a_dagger_nucleon_PSI_str &);
  const class GSM_vector & operator = (const class A_dagger_cluster_PSI_str &);
  const class GSM_vector & operator = (const class x_A_dagger_cluster_PSI_str &);
  const class GSM_vector & operator = (const class a_dagger_nucleon_coupled_to_J_PSI_str &);
  const class GSM_vector & operator = (const class x_a_dagger_nucleon_coupled_to_J_PSI_str &);
  const class GSM_vector & operator = (const class A_dagger_cluster_coupled_to_J_PSI_str &);
  const class GSM_vector & operator = (const class x_A_dagger_cluster_coupled_to_J_PSI_str &);
  const class GSM_vector & operator = (const class a_nucleon_PSI_str &);
  const class GSM_vector & operator = (const class x_a_nucleon_PSI_str &);
  const class GSM_vector & operator = (const class A_cluster_PSI_str &);
  const class GSM_vector & operator = (const class x_A_cluster_PSI_str &);
  const class GSM_vector & operator = (const class a_nucleon_coupled_to_J_PSI_str &);
  const class GSM_vector & operator = (const class x_a_nucleon_coupled_to_J_PSI_str &);
  const class GSM_vector & operator = (const class A_cluster_coupled_to_J_PSI_str &);
  const class GSM_vector & operator = (const class x_A_cluster_coupled_to_J_PSI_str &);

  class GSM_vector & operator += (const class GSM_vector &);
  class GSM_vector & operator += (const TYPE &);
  class GSM_vector & operator += (const class Op_PSI_closure_str &);
  class GSM_vector & operator += (const class a_dagger_nucleon_PSI_str &);
  class GSM_vector & operator += (const class x_a_dagger_nucleon_PSI_str &);
  class GSM_vector & operator += (const class A_dagger_cluster_PSI_str &);
  class GSM_vector & operator += (const class x_A_dagger_cluster_PSI_str &);
  class GSM_vector & operator += (const class a_dagger_nucleon_coupled_to_J_PSI_str &);
  class GSM_vector & operator += (const class x_a_dagger_nucleon_coupled_to_J_PSI_str &);
  class GSM_vector & operator += (const class A_dagger_cluster_coupled_to_J_PSI_str &);
  class GSM_vector & operator += (const class x_A_dagger_cluster_coupled_to_J_PSI_str &);
  class GSM_vector & operator += (const class a_nucleon_PSI_str &);
  class GSM_vector & operator += (const class x_a_nucleon_PSI_str &);
  class GSM_vector & operator += (const class A_cluster_PSI_str &);
  class GSM_vector & operator += (const class x_A_cluster_PSI_str &);
  class GSM_vector & operator += (const class a_nucleon_coupled_to_J_PSI_str &);
  class GSM_vector & operator += (const class x_a_nucleon_coupled_to_J_PSI_str &);
  class GSM_vector & operator += (const class A_cluster_coupled_to_J_PSI_str &);
  class GSM_vector & operator += (const class x_A_cluster_coupled_to_J_PSI_str &);

  class GSM_vector & operator -= (const class GSM_vector &);
  class GSM_vector & operator -= (const TYPE &);
  class GSM_vector & operator -= (const class Op_PSI_closure_str &);
  class GSM_vector & operator -= (const class a_dagger_nucleon_PSI_str &);
  class GSM_vector & operator -= (const class x_a_dagger_nucleon_PSI_str &);
  class GSM_vector & operator -= (const class A_dagger_cluster_PSI_str &);
  class GSM_vector & operator -= (const class x_A_dagger_cluster_PSI_str &);
  class GSM_vector & operator -= (const class a_dagger_nucleon_coupled_to_J_PSI_str &);
  class GSM_vector & operator -= (const class x_a_dagger_nucleon_coupled_to_J_PSI_str &);
  class GSM_vector & operator -= (const class A_dagger_cluster_coupled_to_J_PSI_str &);
  class GSM_vector & operator -= (const class x_A_dagger_cluster_coupled_to_J_PSI_str &);
  class GSM_vector & operator -= (const class a_nucleon_PSI_str &);
  class GSM_vector & operator -= (const class x_a_nucleon_PSI_str &);
  class GSM_vector & operator -= (const class A_cluster_PSI_str &);
  class GSM_vector & operator -= (const class x_A_cluster_PSI_str &);
  class GSM_vector & operator -= (const class a_nucleon_coupled_to_J_PSI_str &);
  class GSM_vector & operator -= (const class x_a_nucleon_coupled_to_J_PSI_str &);
  class GSM_vector & operator -= (const class A_cluster_coupled_to_J_PSI_str &);
  class GSM_vector & operator -= (const class x_A_cluster_coupled_to_J_PSI_str &);

  class GSM_vector & operator *= (const TYPE &);
  class GSM_vector & operator /= (const TYPE &);

  inline TYPE & operator [] (const unsigned int index) const
  {
    return table[index];
  }

  void change_GSM_vector_helper_reallocate (class GSM_vector_helper_class &new_GSM_vector_helper);
  
  void remove_GSM_vector_helper ();
  
  void zero ();
  
  double infinite_norm () const;
  
  void normalization ();
  void random_vector ();
  void pseudo_random_vector ();

  void opposite ();

  TYPE sum () const;

  void good_J_Lowdin (
		      const bool is_there_cout_detailed , 
		      const class J2_class &J2 , 
		      const double J , 
		      class GSM_vector &PSI_temp);

  void good_phase ();

  void configuration_occupation_print (const bool are_all_configuration_probabilties_printed , const double configuration_precision) const;

  void assign (const class GSM_vector &PSI_other_space);

  class Slater_determinant basis_SD_from_index (
						const enum space_type basis_space , 
						const unsigned long int total_PSI_index) const;

  void print () const;

  TYPE average_n_scat_calc () const;

  void eigenvector_copy_disk (
			      const bool full_common_vectors_used_in_file ,
			      const bool full_common_vectors_used_in_file_with_MPI_calls ,
			      const class correlated_state_str &PSI_qn) const;
  
  void space_dimension_eigenvector_copy_disk (
					      const bool full_common_vectors_used_in_file ,
					      const class correlated_state_str &PSI_qn) const;

  void space_dimension_SDs_components_eigenvector_copy_disk (
							     const bool full_common_vectors_used_in_file ,
							     const bool full_common_vectors_used_in_file_with_MPI_calls ,
							     const class correlated_state_str &PSI_qn) const;
  
  void SDs_components_eigenvector_copy_disk (
					     const bool full_common_vectors_used_in_file ,
					     const bool full_common_vectors_used_in_file_with_MPI_calls ,
					     const class correlated_state_str &PSI_qn) const;
  
  void eigenvector_good_T_copy_disk (
				     const bool full_common_vectors_used_in_file ,
				     const bool full_common_vectors_used_in_file_with_MPI_calls ,
				     const class correlated_state_str &PSI_qn) const;
  
  void space_dimension_eigenvector_good_T_copy_disk (
						     const bool full_common_vectors_used_in_file ,
						     const class correlated_state_str &PSI_qn) const;

  void space_dimension_SDs_components_eigenvector_good_T_copy_disk (
								    const bool full_common_vectors_used_in_file ,
								    const bool full_common_vectors_used_in_file_with_MPI_calls ,
								    const class correlated_state_str &PSI_qn) const;
  
  void SDs_components_eigenvector_good_T_copy_disk (
						    const bool full_common_vectors_used_in_file ,
						    const bool full_common_vectors_used_in_file_with_MPI_calls ,
						    const class correlated_state_str &PSI_qn) const;
  
  void eigenvector_Jmin_copy_disk (
				   const bool full_common_vectors_used_in_file ,
				   const bool full_common_vectors_used_in_file_with_MPI_calls ,
				   const class correlated_state_str &PSI_qn) const;
  
  void space_dimension_eigenvector_Jmin_copy_disk (
						   const bool full_common_vectors_used_in_file ,
						   const class correlated_state_str &PSI_qn) const;

  void space_dimension_SDs_components_eigenvector_Jmin_copy_disk (
								  const bool full_common_vectors_used_in_file ,
								  const bool full_common_vectors_used_in_file_with_MPI_calls ,
								  const class correlated_state_str &PSI_qn) const;
  
  void SDs_components_eigenvector_Jmin_copy_disk (
						  const bool full_common_vectors_used_in_file ,
						  const bool full_common_vectors_used_in_file_with_MPI_calls ,
						  const class correlated_state_str &PSI_qn) const;
  
  void copy_disk (
		  const bool full_common_vectors_used_in_file ,
		  const bool full_common_vectors_used_in_file_with_MPI_calls ,
		  const string &file_name) const;
  
  void copy_disk_indexed_name (
			       const bool full_common_vectors_used_in_file ,
			       const bool full_common_vectors_used_in_file_with_MPI_calls ,
			       const string &file_name ,
			       const unsigned int index) const;

  void space_dimension_copy_disk (
				  const bool full_common_vectors_used_in_file ,
				  const string &space_dimension_file_name) const;
  
  void SDs_components_copy_disk (
				 const bool full_common_vectors_used_in_file ,
				 const bool full_common_vectors_used_in_file_with_MPI_calls ,
				 const string &file_name) const;
  
  void SDs_components_copy_disk (const string &file_name) const;
  
  void SDs_components_pn_copy_disk (const string &file_name) const;
  
  void SDs_components_pp_nn_copy_disk (const string &file_name) const;
  
  void space_dimension_SDs_components_copy_disk (
						 const bool full_common_vectors_used_in_file ,
						 const bool full_common_vectors_used_in_file_with_MPI_calls ,
						 const string &space_dimension_file_name ,
						 const string &file_name) const;
  
  void eigenvector_read_disk (
			      const bool full_common_vectors_used_in_file ,
			      const bool full_common_vectors_used_in_file_with_MPI_calls ,
			      const class correlated_state_str &PSI_qn);
  
  void SDs_components_eigenvector_read_disk (
					     const bool full_common_vectors_used_in_file ,
					     const bool full_common_vectors_used_in_file_with_MPI_calls ,
					     const class correlated_state_str &PSI_qn);

  void J_scheme_components_eigenvector_read_disk_M_scheme_conversion (
								      const bool full_common_vectors_used_in_file ,
								      const bool full_common_vectors_used_in_file_with_MPI_calls ,
								      const class correlated_state_str &PSI_qn);
  
  void eigenvector_good_T_read_disk (
				     const bool full_common_vectors_used_in_file ,
				     const bool full_common_vectors_used_in_file_with_MPI_calls ,
				     const class correlated_state_str &PSI_qn);
  
  void SDs_components_eigenvector_good_T_read_disk (
						    const bool full_common_vectors_used_in_file ,
						    const bool full_common_vectors_used_in_file_with_MPI_calls ,
						    const class correlated_state_str &PSI_qn);
  
  void eigenvector_Jmin_read_disk (
				   const bool full_common_vectors_used_in_file ,
				   const bool full_common_vectors_used_in_file_with_MPI_calls ,
				   const class correlated_state_str &PSI_qn);
  
  void SDs_components_eigenvector_Jmin_read_disk (
						  const bool full_common_vectors_used_in_file ,
						  const bool full_common_vectors_used_in_file_with_MPI_calls ,
						  const class correlated_state_str &PSI_qn);
  
  void read_disk (
		  const bool full_common_vectors_used_in_file ,
		  const bool full_common_vectors_used_in_file_with_MPI_calls ,
		  const string &file_name);
  
  void read_disk_indexed_name (
			       const bool full_common_vectors_used_in_file ,
			       const bool full_common_vectors_used_in_file_with_MPI_calls ,
			       const string &file_name ,
			       const unsigned int index);
  
  void SDs_components_read_disk (
				 const bool full_common_vectors_used_in_file ,
				 const bool full_common_vectors_used_in_file_with_MPI_calls ,
				 const string &space_dimension_file_name ,
				 const string &file_name);
  
  void SDs_components_read_disk (
				 const string &space_dimension_file_name ,
				 const string &file_name);
  
  void SDs_components_pn_read_disk (
				    const string &space_dimension_file_name ,
				    const string &file_name);
  
  void SDs_components_pp_nn_read_disk (
				       const string &space_dimension_file_name ,
				       const string &file_name);

  void J_scheme_components_read_disk_M_scheme_conversion (
							  const bool full_common_vectors_used_in_file ,
							  const bool full_common_vectors_used_in_file_with_MPI_calls ,
							  const int J , 
							  const string &space_dimension_file_name ,
							  const string &file_name);
  
  void J_scheme_components_read_disk_M_scheme_conversion (
							  const int J , 
							  const string &space_dimension_file_name ,
							  const string &file_name);
  
  void J_scheme_components_pn_read_disk_M_scheme_conversion (
							     const int J , 
							     const string &space_dimension_file_name ,
							     const string &file_name);
  
  void J_scheme_components_pp_nn_read_disk_M_scheme_conversion (
								const int J , 
								const string &space_dimension_file_name ,
								const string &file_name);
  
  void orthogonalization_disk (
			       const bool is_there_cout_detailed ,
			       const bool is_it_J2_projection ,
			       const unsigned int i , 
			       class array<class GSM_vector> &V_tab);

  void project_good_J (
		       const bool is_there_cout_detailed , 
		       const class J2_class &J2 ,
		       const double J ,  
		       const unsigned int J_number ,
		       const bool is_it_Lowdin ,
		       const bool are_GSM_vectors_stored_on_disk ,
		       class array<class GSM_vector> &Vp_tab ,
		       class GSM_vector &Vstore);

  void pivot_init_Davidson (
			    const bool is_there_cout_detailed , 
			    const bool full_common_vectors_used_in_file ,
			    const bool pivot_from_file , 
			    const bool J_projected , 
			    const class correlated_state_str &Pivot_qn ,
			    const class J2_class &J2 , 
			    const double J ,
			    const unsigned int J_number ,				      
			    const bool is_it_Lowdin ,
			    const bool are_GSM_vectors_stored_on_disk , 
			    class array<class GSM_vector> &V_tab , 
			    class GSM_vector &Vstore);
 
  void pivot_init_Lanczos (
			   const bool is_there_cout_detailed , 
			   const bool full_common_vectors_used_in_file ,
			   const bool pivot_from_file ,  
			   const bool J_projected , 
			   const unsigned int eigenset_index ,
			   const unsigned int eigenset_vectors_number ,
			   const class array<class correlated_state_str> &PSI_qn_tab ,
			   const class J2_class &J2 , 
			   const double J , 
			   const unsigned int J_number ,
			   const bool are_GSM_vectors_stored_on_disk , 
			   const bool is_it_Lowdin ,
			   class array<class GSM_vector> &Vp_tab , 
			   class GSM_vector &Vstore);

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const;
  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const;
  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const;

  friend double used_memory_calc (const class GSM_vector &T);

  void TRS_rest_part_fill (
			   const bool is_there_cout_detailed,
			   const double J);
  
  void get_SDs_pn (
		   class array<unsigned int> &SDp_tab ,
		   class array<unsigned int> &SDn_tab) const;
  
  void get_SDs_pp_nn (class array<unsigned int> &SD_tab) const;
  
  void diagonal_part_PSI_add (
			      const class GSM_vector &PSI_in , 
			      const class array<TYPE> &diagonal_tab , 
			      const TYPE &alpha);

  void Op_PSI_IN_indices_components_transfer_add_one_nucleon (
							      const unsigned int i_Send ,
							      const unsigned int i_Recv ,
							      const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
							      const class array<TYPE> &Op_PSI_IN_all_components);
 
  void Op_PSI_IN_components_add_one_nucleon_all_processes (
							   const bool full_common_vectors_used_in_file ,
							   const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
							   const class array<TYPE> &Op_PSI_IN_components);
  
  TYPE Op_PSI_IN_indices_components_transfer_scalar_product_add_one_nucleon (
									     const unsigned int i_Send ,
									     const unsigned int i_Recv ,
									     const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
									     const class array<TYPE> &Op_PSI_IN_all_components) const;
  
  TYPE Op_PSI_IN_scalar_product_add_one_nucleon_all_processes (
							       const bool full_common_vectors_used_in_file ,
							       const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
							       const class array<TYPE> &Op_PSI_IN_components) const;

  void Op_PSI_IN_indices_components_transfer_add_cluster (
							  const unsigned int i_Send ,
							  const unsigned int i_Recv ,
							  const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
							  const class array<TYPE> &Op_PSI_IN_all_components);
 
  void Op_PSI_IN_components_add_cluster_all_processes (
						       const bool full_common_vectors_used_in_file ,
						       const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
						       const class array<TYPE> &Op_PSI_IN_components);

  TYPE Op_PSI_IN_indices_components_transfer_scalar_product_add_cluster (
									 const unsigned int i_Send ,
									 const unsigned int i_Recv ,
									 const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
									 const class array<TYPE> &Op_PSI_IN_all_components) const;
  
  TYPE Op_PSI_IN_scalar_product_add_cluster_all_processes (
							   const bool full_common_vectors_used_in_file ,
							   const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
							   const class array<TYPE> &Op_PSI_IN_components) const;

  TYPE Op_PSI_IN_indices_partial_components_transfer_scalar_product_beta_add (
									      const unsigned int i_Send ,
									      const unsigned int i_Recv ,
									      const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
									      const class array<TYPE> &Op_PSI_IN_all_partial_components) const;
 
  TYPE Op_PSI_IN_beta_add_all_processes (
					 const bool full_common_vectors_used_in_file ,
					 const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
					 const class array<TYPE> &Op_PSI_IN_partial_components) const;
  
  void full_vector_fill (const class GSM_vector &PSI);

  void partitioned_vector_fill (const class GSM_vector &PSI_full);

  bool same_parity_M_projection (const class GSM_vector &PSI) const;
  bool same_parity_M_projection (const class GSM_vector_helper_class &GSM_vector_helper_PSI) const;
  
#ifdef UseMPI  
  void MPI_Send (const unsigned int Recv_process , const unsigned int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int Send_process , const unsigned int tag , const MPI_Comm MPI_C);
  void MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif


private:
  
  unsigned int configuration_mixing_tab_dimension_pp_nn_calc () const;

  void configuration_mixing_tab_fill_pp_nn (class array<class configuration_mixing_data> &configuration_mixing_tab) const;

  void configuration_occupation_print_pp_nn (
					     const bool are_all_configuration_probabilties_printed , 
					     const class array<class configuration_mixing_data> &configuration_mixing_tab , 
					     const double configuration_precision) const;

  unsigned int configuration_mixing_tab_dimension_pn_calc () const;

  void configuration_mixing_tab_fill_pn (class array<class configuration_mixing_data> &configuration_mixing_tab) const;

  void configuration_mixing_tab_sort (
				      const int low , 
				      const int high , 
				      class array<class configuration_mixing_data> &configuration_mixing_tab) const;

  void configuration_occupation_print_pn (
					  const bool are_all_configuration_probabilties_printed , 
					  const class array<class configuration_mixing_data> &configuration_mixing_tab , 
					  const double configuration_precision) const;

  void maximal_probability_configuration_print (const class array<class configuration_mixing_data> &configuration_mixing_tab) const;

  class Slater_determinant basis_SD_from_index_pn (
						   const enum space_type basis_space , 
						   const unsigned long int total_PSI_index) const;

  class Slater_determinant basis_SD_from_index_pp_nn (
						      const enum space_type basis_space , 
						      const unsigned long int total_PSI_index) const;

  void print_pn () const;
  void print_pp_nn () const;

  TYPE average_n_scat_calc_pp_nn () const;
  TYPE average_n_scat_calc_pn () const;

  void TRS_rest_part_fill_one_transfer (
					const unsigned int i_Send ,
					const unsigned int i_Recv ,
					const double J);

  bool is_it_virtual_allocation; // true if one uses the memory of another GSM vector to store vector components, false if memory is allocated to store vector components
  
  unsigned int space_dimensions_all_processes_max; // maximal number of SDs considered in all MPI nodes in the SD expansion of the GSM vector
 
  class GSM_vector_helper_class *GSM_vector_helper_ptr; // pointer to data necessary to handle the GSM vector. It does not contain their vector components.
  
  TYPE *table; // array of vector components
};

TYPE GSM_vector_node_overlap (const class GSM_vector &X , const class GSM_vector &Y);

TYPE operator * (const class GSM_vector &X , const class GSM_vector &Y);

bool operator == (const class GSM_vector &X , const class GSM_vector &Y);
bool operator != (const class GSM_vector &X , const class GSM_vector &Y);

istream & operator >> (istream &is , class GSM_vector &PSI);
ostream & operator << (ostream &os , const class GSM_vector &PSI);

void orthogonalization_not_disk (
				 const bool is_there_cout_detailed ,
				 const unsigned int i , 
				 class array<class GSM_vector> &V_tab);






class Op_PSI_closure_str
{
public:

  Op_PSI_closure_str (const unsigned int closure_terms_number_c);
  Op_PSI_closure_str (const class Op_PSI_closure_str &Op_PSI_closure_old);
  Op_PSI_closure_str (const class GSM_vector &);

  Op_PSI_closure_str (const class TRS_class &TRS , const class GSM_vector &PSI);

  bool is_it_filled () const
  {
    return (PSI_in_ptrs[0] != NULL);
  }
  
  const class Op_PSI_closure_str & operator = (const class Op_PSI_closure_str &Op_PSI_closure);

  unsigned int get_closure_terms_number () const;
  enum operator_type get_Op (const unsigned int index) const;
  TYPE get_x (const unsigned int index) const;
  TYPE get_alpha (const unsigned int index) const;

  const class H_class & get_H (const unsigned int index) const;
  const class Jpm_class & get_Jpm (const unsigned int index) const;
  const class J2_class & get_J2 (const unsigned int index) const;
  const class T2_class & get_T2 (const unsigned int index) const;
  const class CM_operator_class & get_CM_operator (const unsigned int index) const;
  const class L2_CM_class & get_L2_CM (const unsigned int index) const;
  const class TRS_class & get_TRS (const unsigned int index) const;
  const class cluster_HO_to_Berggren_class & get_cluster_HO_to_Berggren (const unsigned int index) const;
  const class GSM_vector & get_PSI_in (const unsigned int index) const;

  void default_values_init ();

  void fill_data (
		  const enum operator_type Op , 
		  const TYPE x , 
		  const TYPE alpha , 
		  const void *const Op_ptr , 
		  const class GSM_vector *const PSI_in_ptr , 
		  const unsigned int index);

  void fill_data (
		  const class Op_PSI_closure_str &Op_PSI_closure , 
		  const unsigned int i , 
		  const unsigned int index);

  bool is_it_only_scalar_identity () const;

  void sign_change (const unsigned int index);

  void global_sign_change ();

  void factor_multiplication (const unsigned int index , const TYPE &factor);
	
  void global_factor_multiplication (const TYPE &factor);

  class GSM_vector_helper_class & GSM_vector_helper_determine () const;

  bool is_PSI_out_used (const class GSM_vector &PSI_out) const;

  void all_Op_PSI_in_calc_add (class GSM_vector &PSI_out) const;

  class Op_PSI_closure_str operator_times_scalar_identity (
							   const enum operator_type Op , 
							   const TYPE x_Op , 
							   const TYPE alpha_Op ,  
							   const void *const Op_ptr) const;

private:

  unsigned int closure_terms_number;

  enum operator_type Op_tab[CLOSURE_TERMS_MAX];

  TYPE x_tab[CLOSURE_TERMS_MAX] , alpha_tab[CLOSURE_TERMS_MAX];

  const void * Op_ptrs[CLOSURE_TERMS_MAX];
  
  const GSM_vector * PSI_in_ptrs[CLOSURE_TERMS_MAX];
};

class Op_PSI_closure_str operator * (const class H_class &H , const class GSM_vector &PSI_in);
class Op_PSI_closure_str operator * (const class Jpm_class &Jpm , const class GSM_vector &PSI_in);
class Op_PSI_closure_str operator * (const class J2_class &J2 , const class GSM_vector &PSI_in);
class Op_PSI_closure_str operator * (const class T2_class &T2 , const class GSM_vector &PSI_in);
class Op_PSI_closure_str operator * (const class CM_operator_class &CM_operator , const class GSM_vector &PSI_in);
class Op_PSI_closure_str operator * (const class L2_CM_class &L2_CM , const class GSM_vector &PSI_in);
class Op_PSI_closure_str operator * (const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren , const class GSM_vector &PSI_HO_in);

class Op_PSI_closure_str operator * (const class xH_plus_alpha_str &xH_plus_alpha , const class GSM_vector &PSI_in);
class Op_PSI_closure_str operator * (const class xJpm_str &xJpm , const class GSM_vector &PSI_in);
class Op_PSI_closure_str operator * (const class xJ2_plus_alpha_str &xJ2_plus_alpha , const class GSM_vector &PSI_in);
class Op_PSI_closure_str operator * (const class xT2_plus_alpha_str &xT2_plus_alpha , const class GSM_vector &PSI_in);
class Op_PSI_closure_str operator * (const class xCM_operator_plus_alpha_str &xCM_operator_plus_alpha , const class GSM_vector &PSI_in);
class Op_PSI_closure_str operator * (const class xL2_CM_plus_alpha_str &xL2_CM_plus_alpha , const class GSM_vector &PSI_in);
class Op_PSI_closure_str operator * (const class x_cluster_HO_to_Berggren_str &x_cluster_HO_to_Berggren , const class GSM_vector &PSI_HO_in);

class Op_PSI_closure_str operator * (const class H_class &H , const class Op_PSI_closure_str &Op_PSI_closure);
class Op_PSI_closure_str operator * (const class Jpm_class &Jpm , const class Op_PSI_closure_str &Op_PSI_closure);
class Op_PSI_closure_str operator * (const class J2_class &J2 , const class Op_PSI_closure_str &Op_PSI_closure);
class Op_PSI_closure_str operator * (const class T2_class &T2 , const class Op_PSI_closure_str &Op_PSI_closure);
class Op_PSI_closure_str operator * (const class CM_operator_class &CM_operator , const class Op_PSI_closure_str &Op_PSI_closure);
class Op_PSI_closure_str operator * (const class L2_CM_class &L2_CM , const class Op_PSI_closure_str &Op_PSI_closure);
class Op_PSI_closure_str operator * (const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren , const class Op_PSI_closure_str &Op_PSI_closure);

class Op_PSI_closure_str operator * (const class xH_plus_alpha_str &xH_plus_alpha , const class Op_PSI_closure_str &Op_PSI_closure);
class Op_PSI_closure_str operator * (const class xJpm_str &xJpm , const class Op_PSI_closure_str &Op_PSI_closure);
class Op_PSI_closure_str operator * (const class xJ2_plus_alpha_str &xJ2_plus_alpha , const class Op_PSI_closure_str &Op_PSI_closure);
class Op_PSI_closure_str operator * (const class xT2_plus_alpha_str &xT2_plus_alpha , const class Op_PSI_closure_str &Op_PSI_closure);
class Op_PSI_closure_str operator * (const class xCM_operator_plus_alpha_str &xCM_operator_plus_alpha , const class Op_PSI_closure_str &Op_PSI_closure);
class Op_PSI_closure_str operator * (const class xL2_CM_plus_alpha_str &xL2_CM_plus_alpha , const class Op_PSI_closure_str &Op_PSI_closure);
class Op_PSI_closure_str operator * (const class x_cluster_HO_to_Berggren_str &x_cluster_HO_to_Berggren , const class Op_PSI_closure_str &Op_PSI_closure);

class Op_PSI_closure_str operator + (const class GSM_vector &PSI_in);
class Op_PSI_closure_str operator - (const class GSM_vector &PSI_in);
class Op_PSI_closure_str operator * (const TYPE &alpha , const class GSM_vector &PSI_in);
class Op_PSI_closure_str operator * (const class GSM_vector &PSI_in , const TYPE &alpha);
class Op_PSI_closure_str operator / (const class GSM_vector &PSI_in , const TYPE &one_over_alpha);

class Op_PSI_closure_str operator + (const class Op_PSI_closure_str &Op_PSI_closure);
class Op_PSI_closure_str operator - (const class Op_PSI_closure_str &Op_PSI_closure);
class Op_PSI_closure_str operator * (const TYPE &factor , const class Op_PSI_closure_str &Op_PSI_closure);
class Op_PSI_closure_str operator * (const class Op_PSI_closure_str &Op_PSI_closure , const TYPE &factor);
class Op_PSI_closure_str operator / (const class Op_PSI_closure_str &Op_PSI_closure , const TYPE &factor);

class Op_PSI_closure_str Op_PSI_closure_add (
					     const int sign , 
					     const class Op_PSI_closure_str &Op_PSI_closure_a , 
					     const class Op_PSI_closure_str &Op_PSI_closure_b);

class Op_PSI_closure_str operator + (const class Op_PSI_closure_str &Op_PSI_closure_a , const class Op_PSI_closure_str &Op_PSI_closure_b);
class Op_PSI_closure_str operator - (const class Op_PSI_closure_str &Op_PSI_closure_a , const class Op_PSI_closure_str &Op_PSI_closure_b);

#endif


