#ifndef GSMCONFIGURATIONSDINSPACEONEJUMPINTOOUT_H
#define GSMCONFIGURATIONSDINSPACEONEJUMPINTOOUT_H

// TYPE is double or complex
// -------------------------

namespace configuration_SD_in_space_one_jump_in_to_out
{
  void is_configuration_in_inSD_in_space_pp_nn_determine (
							  const class GSM_vector_helper_class &GSM_vector_helper_in , 
							  class baryons_data &particles_data);

  void is_configuration_out_outSD_BPout_Sout_Nspec_out_iMout_in_space_pp_nn_determine (
										       const class GSM_vector_helper_class &GSM_vector_helper_out , 
										       class baryons_data &particles_data);

  void is_configuration_in_inSD_in_space_pn_determine (
						       const class GSM_vector_helper_class &GSM_vector_helper_in , 
						       class baryons_data &prot_Y_data , 
						       class baryons_data &neut_Y_data);

  void is_configuration_out_outSD_BPout_Sout_Nspec_out_iMout_in_space_pn_determine (
										    const class GSM_vector_helper_class &GSM_vector_helper_out , 
										    class baryons_data &prot_Y_data , 
								     class baryons_data &neut_Y_data);

  void is_it_configuration_inter_to_include_determine_all_configuration (
									 const bool is_it_pole_approximation , 
									 class baryons_data &particles_data);

  bool is_it_SD_inter_to_include_fixed_configuration_in_determine (
								   const class configuration &C_in , 
								   const class Slater_determinant &inSD ,
								   const int M_jump , 
								   const unsigned int C_in_jump_shell , 
								   const unsigned int C_out_jump_shell , 
								   class baryons_data &particles_data);
  
  void is_it_SD_inter_to_include_determine_all_SDs (
						    const bool is_it_pole_approximation , 
						    class baryons_data &particles_data);
 
  void one_jump_tables_alloc_calc_pp_nn (
					 const bool is_there_cout , 
					 const bool is_it_one_body ,
					 const bool is_it_two_body_pn_only , 
					 const bool is_it_pole_approximation , 
					 const bool is_J2_applied ,
					 const bool truncation_hw , 
					 const bool truncation_ph ,  
					 class baryons_data &particles_data);

  void configuration_SD_in_space_determine (
					    const bool is_L2_CM_J2_applied , 
					    const class GSM_vector_helper_class &GSM_vector_helper_in , 
					    const class GSM_vector_helper_class &GSM_vector_helper_Mp1 , 
					    class baryons_data &prot_Y_data , 
					    class baryons_data &neut_Y_data);

  void configuration_SD_out_space_determine (
					     const bool is_L2_CM_J2_applied ,  
					     const class GSM_vector_helper_class &GSM_vector_helper_out , 
					     const class GSM_vector_helper_class &GSM_vector_helper_Mp1 , 
					     class baryons_data &prot_Y_data , 
					     class baryons_data &neut_Y_data);
 
  void configuration_SD_in_out_in_space_one_jump_tables_alloc_calc_Jpm (
									const bool is_there_cout ,
									const int pm , 
									const class GSM_vector_helper_class &GSM_vector_helper_in , 
									const class GSM_vector_helper_class &GSM_vector_helper_out , 
									class baryons_data &prot_Y_data , 
									class baryons_data &neut_Y_data);

  // M is the current angular momentum projection.
  // If is_L2_CM_J2_applied is true , GSM_vector_helper_in and GSM_vector_helper_out must be equal. Test is made for M and parity only.
  // GSM_vector_helper_in.M = GSM_vector_helper_out.M = M and GSM_vector_helper_Mp1.M = M+1.
  // Indeed , L2_CM = L-_CM.L+_CM + Lz_CM.(Lz_CM + 1) , and L+_CM : M -> M+1 , L-_CM : M+1 -> M , Lz_CM : M -> M.
  // It is compatible with all two-body operators having GSM_vector_helper_in(out).M equal to M , such as H.
  // If not, GSM_vector_helper_Mp1 is not used and can be arbitrary.

  void configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (
								    const bool is_there_cout , 
								    const bool is_it_one_body ,
								    const bool is_it_two_body_pn_only , 
								    const bool is_J2_applied ,
								    const bool is_L2_CM_applied ,
								    const class GSM_vector_helper_class &GSM_vector_helper_in , 
								    const class GSM_vector_helper_class &GSM_vector_helper_out , 
								    const class GSM_vector_helper_class &GSM_vector_helper_Mp1 , 
								    class baryons_data &prot_Y_data , 
								    class baryons_data &neut_Y_data);
}

#endif


