#ifndef GSMNATURALORBITALSESPES_H
#define GSMNATURALORBITALSESPES_H


// TYPE is double or complex
// -------------------------

namespace natural_orbitals_ESPEs
{
  void calc_print (
		   const bool is_there_cout , 
		   const bool are_there_ESPEs , 
		   const class input_data_str &input_data , 
		   const class TBMEs_class &TBMEs_pn ,  
		   class baryons_data &prot_Y_data , 
		   class baryons_data &neut_Y_data ,
		   class GSM_vector &PSI_full);
}

#endif
