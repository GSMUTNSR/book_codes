#ifndef GSMBETATRANSITIONS_H
#define GSMBETATRANSITIONS_H

// TYPE is double or complex
// -------------------------

namespace beta_transitions
{ 
  void beta_suboperator_OBMEs_calc (
				    const bool is_it_HO_expansion , 
				    const enum radial_operator_type radial_operator , 
				    const enum beta_suboperator_type beta_suboperator , 
				    const class interaction_class &inter_data , 
				    const int rank_Op_projection , 
				    const class nucleons_data &data_in , 
				    const class nucleons_data &data_out , 
				    class array<TYPE> &OBMEs);
  
  void beta_suboperator_NBME_calc (
				   const enum beta_pm_type beta_pm , 
				   const bool is_it_HO_expansion , 
				   const bool full_common_vectors_used_in_file ,
				   const enum radial_operator_type radial_operator , 
				   const enum beta_suboperator_type beta_suboperator , 
				   const class interaction_class &inter_data , 
				   const class correlated_state_str &PSI_IN_qn , 
				   const class correlated_state_str &PSI_OUT_qn , 
				   const class GSM_vector &PSI_OUT , 
				   class array<TYPE> &beta_suboperators_NBMEs);
 
  void beta_suboperators_NBMEs_calc (
				     const enum beta_type beta , 
				     const enum beta_pm_type beta_pm , 
				     const bool is_it_HO_expansion , 
				     const bool full_common_vectors_used_in_file ,
				     const class interaction_class &inter_data , 
				     const class correlated_state_str &PSI_IN_qn ,  
				     const class correlated_state_str &PSI_OUT_qn ,  
				     const class GSM_vector &PSI_OUT , 
				     class array<TYPE> &beta_suboperators_NBMEs);
  
  void calc_print (
		   const input_data_str &input_data , 
		   const class interaction_class &inter_data , 
		   const class array<class correlated_state_str> &PSI_qn_tab ,
		   class nucleons_data &prot_data , 
		   class nucleons_data &neut_data); 
}

#endif


