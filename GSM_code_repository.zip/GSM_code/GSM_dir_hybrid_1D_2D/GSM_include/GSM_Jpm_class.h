#ifndef GSMJPMCLASS_H
#define GSMJPMCLASS_H

// TYPE is double or complex
// -------------------------

class Jpm_class
{
public:
  
  Jpm_class ();
  
  Jpm_class (
	     const bool is_there_cout_c , 
	     const bool print_detailed_information_c , 
	     const int pm_c ,
	     const enum storage_type storage_c , 
	     const bool configuration_SD_one_jump_tables_to_recalculate_c ,   
	     class GSM_vector_helper_class &GSM_vector_helper_in ,
	     class GSM_vector_helper_class &GSM_vector_helper_out ,
	     class GSM_vector &PSI_in_full , 
	     class GSM_vector &Jpm_PSI_in_0 , 
	     class GSM_vector &Jpm_PSI_in_1);
  
  Jpm_class (const class Jpm_class &X);

  ~Jpm_class ();
  
  void allocate (
		 const bool is_there_cout_c , 
		 const bool print_detailed_information_c , 
		 const int pm_c ,
		 const enum storage_type storage_c , 
		 const bool configuration_SD_one_jump_tables_to_recalculate_c ,   
		 class GSM_vector_helper_class &GSM_vector_helper_in ,
		 class GSM_vector_helper_class &GSM_vector_helper_out ,
		 class GSM_vector &PSI_in_full , 
		 class GSM_vector &Jpm_PSI_in_0 , 
		 class GSM_vector &Jpm_PSI_in_1);
  
  void allocate_fill (const class Jpm_class &X);

  void deallocate ();

  void apply_add (
		  const class GSM_vector &PSI_in , 
		  class GSM_vector &PSI_out) const;

  void print () const;
  
  friend double used_memory_calc (const class Jpm_class &T);

  void time_multiplications_data_print () const;
  
  class GSM_vector_helper_class & get_GSM_vector_helper_in () const
  {
    return *GSM_vector_helper_in_ptr;
  }
  
  class GSM_vector_helper_class & get_GSM_vector_helper_out () const
  {
    return *GSM_vector_helper_out_ptr;
  }
    
  class GSM_vector & get_PSI_in_full () const
  {
    return *PSI_in_full_ptr;
  }
    
  class GSM_vector & get_Jpm_PSI_in_0 () const
  {
    return *Jpm_PSI_in_0_ptr;
  }
  
  class GSM_vector & get_Jpm_PSI_in_1 () const
  {
    return *Jpm_PSI_in_1_ptr;
  }
    
  bool is_it_filled () const
  {
    return (storage != NO_STORAGE); 
  }
  
private:
 
  void non_zero_NBMEs_numbers_pp_nn_calc (
					  const class jumps_data_in_to_out_str &one_jump , 
					  const class array<bool> &is_PSI_out_index_accepted_tab , 
					  const class array<unsigned int> &square_row_indices ,  
					  const class array<unsigned int> &PSI_out_indices);
  
  void non_zero_NBMEs_numbers_one_jump_p_part_pn_calc ();

  void non_zero_NBMEs_numbers_one_jump_n_part_pn_calc ();

  void non_zero_NBMEs_numbers_pp_nn_calc ();

  void squares_non_zero_NBMEs_numbers_calc ();
  
  void Jpm_part_one_jump_pp_nn_store (
				      const unsigned int PSI_in_index ,
				      const unsigned int dimension_one_jump , 
				      const class array<bool> &is_PSI_out_index_accepted_tab , 
				      const class array<unsigned int> &square_row_indices ,  
				      const class array<unsigned int> &PSI_out_indices ,
				      const class array<double> &NBMEs_one_jump);
 
  void one_jump_p_part_pn_calc_full_storage ();
  

  void one_jump_n_part_pn_calc_full_storage ();

  void jumps_part_pp_nn_calc_full_storage ();

  void matrix_store ();

  void Jpm_PSI_in_part_non_zero_components_transfer_add (
							 const unsigned int i_Recv ,
							 class GSM_vector &Jpm_PSI_in_part) const;
  
  void apply_add_full_storage_fixed_square (
					    const unsigned int square_row_index ,
					    const class GSM_vector &PSI_in) const;

  void apply_add_full_storage (
			       const class GSM_vector &PSI_in , 
			       class GSM_vector &PSI_out) const;
  
  void one_jump_p_part_pn_calc_on_the_fly (class GSM_vector &PSI_out) const;
  
  void one_jump_n_part_pn_calc_on_the_fly (class GSM_vector &PSI_out) const;
  
  void pp_nn_calc_on_the_fly (class GSM_vector &PSI_out) const;

  void apply_add_on_the_fly (
			     const class GSM_vector &PSI_in ,
			     class GSM_vector &PSI_out) const;

  bool is_there_cout; // true if one prints information on screen, false if not
  
  bool is_there_cout_detailed;  // true if prints all information on screen, false if one wants only the most important information on screen
  
  int pm; // It is 1 for J+ and -1 for J-.
  
  enum storage_type storage;  // FULL_STORAGE if J+/- matrix is fully stored , 
                              // PARTIAL_STORAGE is the same as FULL_STORAGE when considering J+/- 
                              // ON_THE_FLY for on the fly calculation

  mutable double Jpm_MPI_communication_time; // time taken to make MPI communications in the calculation of J+/-|Psi[in]>
  
  mutable double Jpm_multiplications_number; // number of multiplications done in J+/-|Psi[in]>
  
  bool configuration_SD_one_jump_tables_to_recalculate; // true if one has to recalculate the a+ a matrix elements between SDs to apply the J+/- operator, false if not
 
  class GSM_vector_helper_class *GSM_vector_helper_in_ptr;  // pointer to data necessary to handle |Psi[in]>. It does not contain their vector components.
  class GSM_vector_helper_class *GSM_vector_helper_out_ptr; // pointer to data necessary to handle |Psi[out]>. It does not contain their vector components.
  
  mutable class GSM_vector_helper_class GSM_vector_helper_in_full; // pointer to data necessary to handle the fully stored |Psi[in]> on each MPI node. It does not contain their vector components.
  
  class GSM_vector *PSI_in_full_ptr; // pointer to GSM vector |Psi-in> which is stored as a full vector on each MPI node. It contains its vector components.

  class GSM_vector *Jpm_PSI_in_0_ptr; // pointer to work vector to calculate J+/-|Psi[in]>
  class GSM_vector *Jpm_PSI_in_1_ptr; // pointer to work vector to calculate J+/-|Psi[in]>
  
  class array<double> Jpm_prot_OBMEs_tab; // proton  OBMEs of the j+ operator
  class array<double> Jpm_neut_OBMEs_tab; // neutron OBMEs of the j+ operator

  class array<unsigned int> squares_non_zero_NBMEs_numbers; // Number of non-zero NBMEs for the considered MPI node stored on a square of hybrid 1D/2D partitioning
  
  class array<unsigned int> space_dimensions_non_zero; // Numbers of SDs leading to non-zero NBMEs for the considered MPI square
  
  class array<unsigned int *> PSI_row_non_zero_indices_tables; // modified indices of the SDs of the rows of J+/- leading to non-zeros NBMEs per row as a function of initial SD indices

  class array<unsigned int *> PSI_row_indices_non_zero_tables; // indices of the SDs of the rows of J+/- leading to non-zeros NBMEs per row
  
  class array<class array<unsigned int *> > squares_non_zero_NBMEs_PSI_column_indices_tables; // indices of the SDs of the columns of J+/- leading to non-zeros NBMEs per square
  
  class array<class array<double *> > squares_non_zero_NBMEs_tables; // non-zero NBMEs for the considered MPI square
};






class xJpm_str
{
public:

  const TYPE x;
  const class Jpm_class &Jpm;

  xJpm_str (const TYPE &x_c , const class Jpm_class &Jpm_c);
};


class xJpm_str operator + (const class Jpm_class &Jpm);
class xJpm_str operator - (const class Jpm_class &Jpm);

class xJpm_str operator * (const class Jpm_class &Jpm , const double x);
class xJpm_str operator * (const double x , const class Jpm_class &Jpm);
class xJpm_str operator / (const class Jpm_class &Jpm , const double x);

class xJpm_str operator + (const class xJpm_str &xJpm);
class xJpm_str operator - (const class xJpm_str &xJpm);

class xJpm_str operator * (const class xJpm_str &Op , const double factor);
class xJpm_str operator / (const class xJpm_str &Op , const double factor);

class xJpm_str operator * (const double factor , const class xJpm_str &Op);

class xJpm_str operator * (const class Jpm_class &Jpm , const complex<double> &x);
class xJpm_str operator * (const complex<double> &x , const class Jpm_class &Jpm);
class xJpm_str operator / (const class Jpm_class &Jpm , const complex<double> &x);

class xJpm_str operator * (const class xJpm_str &Op , const complex<double> &factor);
class xJpm_str operator / (const class xJpm_str &Op , const complex<double> &factor);

class xJpm_str operator * (const complex<double> &factor , const class xJpm_str &Op);

class xJpm_str operator + (const class xJpm_str &Op_a , const class xJpm_str &Op_b);
class xJpm_str operator - (const class xJpm_str &Op_a , const class xJpm_str &Op_b);

#endif


