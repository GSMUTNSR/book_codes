#ifndef GSMEIGENVECTORFUNCTIONS_H
#define GSMEIGENVECTORFUNCTIONS_H

// TYPE is double or complex
// -------------------------

namespace eigenvector_functions
{
  void changing_eigensets_bool_tables_calc (
					    const class input_data_str &input_data , 
					    const class array<double> &M_table , 
					    class array<bool> &is_it_new_J_Pi_tab , 
					    class array<bool> &is_it_new_BP_M_tab);

  void write_expectation_values (
				 const class input_data_str &input_data , 
				 const class GSM_vector &PSI , 
				 const class J2_class &J2 , 
				 const class T2_class &T2 , 
				 const class H_class &H , 
				 const class L2_CM_class &L2_CM , 
				 class GSM_vector &PSI_full , 
				 class GSM_vector &Vstore , 
				 const class correlated_state_str &PSI_qn);

  void M_plus_one_eigenvector_calc_stored (
					   const bool is_there_cout , 
					   const bool is_there_cout_detailed , 
					   const class input_data_str &input_data , 
					   const class array<unsigned long int> &dimensions_good_J ,
					   const class correlated_state_str &PSI_qn , 
					   class GSM_vector_helper_class &GSM_vector_helper_M ,
					   class GSM_vector &PSI_full);

  void M_minus_one_eigenvector_calc_stored (
					    const bool is_there_cout , 
					    const bool is_there_cout_detailed , 
					    const class input_data_str &input_data , 
					    const class array<unsigned long int> &dimensions_good_J ,
					    const class correlated_state_str &PSI_qn , 
					    class GSM_vector_helper_class &GSM_vector_helper_M ,
					    class GSM_vector &PSI_full); 

  void eigenvector_stored_with_all_M_projections (
						  const bool is_there_cout , 
						  const bool is_there_cout_detailed , 
						  const class input_data_str &input_data ,
						  const class array<unsigned long int> &dimensions_good_J ,
						  const class correlated_state_str &PSI_qn , 
						  class GSM_vector_helper_class &GSM_vector_helper_M_deb ,
						  class GSM_vector &PSI_full); 

  void find_eigenvector_starting_point (
					const bool vectors_write , 
					const class input_data_str &input_data , 
					const unsigned int J_number , 
					const class array<unsigned long int> &dimensions_good_J_pole_approximation , 
					const double J , 
					const class H_class &H , 
					const class J2_class &J2 , 
					const unsigned int eigenset_index , 
					const unsigned int eigenset_vectors_number , 
					class array<TYPE> &E_subspace_tab , 
					class array<class GSM_vector_helper_class> &GSM_vector_helper_subspace_tab , 
					class array<class GSM_vector> &eigenvector_subspace_tab , 
					class GSM_vector &V ,  
					class GSM_vector &V_store ,
					class array<class GSM_vector> &PSI_M_tab , 
					class array<class GSM_vector> &PSI_Mp1_tab , 
					class array<class GSM_vector> &V_tab , 
					class array<class GSM_vector> &Vp_tab ,
					class array<class correlated_state_str> &PSI_qn_tab);

  void find_eigenvector (
			 const bool is_there_cout , 
			 const class input_data_str &input_data , 
			 const class GSM_vector_helper_class &GSM_vector_helper_M , 
			 const unsigned int J_number , 
			 const class array<unsigned long int> &dimensions_good_J_pole_approximation , 
			 const class array<unsigned long int> &dimensions_good_J , 
			 const double J , 
			 const class H_class &H , 
			 const class J2_class &J2 , 
			 const unsigned int eigenset_index , 
			 const unsigned int eigenset_vectors_number , 
			 const class array<TYPE> &E_subspace_tab , 
			 const class array<class GSM_vector> &eigenvector_subspace_tab ,  
			 class GSM_vector &PSI_full ,
			 class GSM_vector &V ,
			 class GSM_vector &Vstore ,
			 class array<class GSM_vector> &PSI_M_tab , 
			 class array<class GSM_vector> &PSI_Mp1_tab , 
			 class array<class GSM_vector> &V_tab , 
			 class array<class GSM_vector> &HV_tab , 
			 class array<class GSM_vector> &Vp_tab ,
			 class array<class GSM_vector> &GSM_work_vectors , 
			 class array<class correlated_state_str> &PSI_qn_tab);
  
  void pole_approximation_eigenvectors_calc (
					     const bool is_there_cout , 
					     const class array<unsigned long int> &total_space_dimensions_good_J_pole_approximation , 
					     const class array<double> &M_table , 
					     const class TBMEs_class &TBMEs_pn , 
					     const class input_data_str &input_data ,  
					     const class array<class correlated_state_str> &PSI_qn_tab , 
					     class nucleons_data &prot_data , 
					     class nucleons_data &neut_data ,  
					     class array<TYPE> &E_subspace_tab , 
					     class array<class GSM_vector_helper_class> &GSM_vector_helper_subspace_tab , 
					     class array<class GSM_vector> &eigenvector_subspace_tab);

  void full_space_eigenvectors_calc (
				     const bool is_there_cout , 
				     const class array<unsigned long int> &total_space_dimensions_good_J_pole_approximation , 
				     const class array<unsigned long int> &total_space_dimensions_good_J , 
				     const class array<double> &M_table , 
				     const class TBMEs_class &TBMEs_pn , 
				     const class input_data_str &input_data , 
				     const class array<TYPE> &E_subspace_tab , 
				     const class array<class GSM_vector> &eigenvector_subspace_tab ,		   
				     class nucleons_data &prot_data , 
				     class nucleons_data &neut_data ,  
				     class array<class correlated_state_str> &PSI_qn_tab , 
				     class GSM_vector &PSI_full);
  
  void eigenvectors_pole_approximation_full_space_calc (
							const bool is_there_cout , 
							const bool is_it_pole_approximation_only , 
							const class input_data_str &input_data , 
							const class array<unsigned long int> &total_space_dimensions_good_J_pole_approximation , 
							const class array<unsigned long int> &total_space_dimensions_good_J , 
							class TBMEs_class &TBMEs_pn , 
							class nucleons_data &prot_data , 
							class nucleons_data &neut_data ,
							class array<class correlated_state_str> &PSI_qn_tab ,
							class GSM_vector &PSI_full);
  void diagonalization_memory_used_print (
					  const bool non_zero_NBMEs_proportion_only ,
					  const bool is_it_Lanczos ,
					  const bool are_GSM_vectors_stored_on_disk , 
					  const class GSM_vector_helper_class &GSM_vector_helper , 
					  const class H_class &H , 
					  const class GSM_vector &V ,  
					  const class GSM_vector &V_store ,
					  const class array<class GSM_vector> &PSI_M_tab , 
					  const class array<class GSM_vector> &GSM_work_vectors ,
					  const class array<class GSM_vector> &Vp_tab ,  
					  const unsigned int workspace_dimension);
}

#endif


