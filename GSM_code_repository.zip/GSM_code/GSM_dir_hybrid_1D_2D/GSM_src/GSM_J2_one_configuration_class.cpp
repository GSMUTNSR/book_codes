#include "../GSM_include/GSM_include_def.h"

// TYPE is double or complex
// -------------------------

// Class applying the J^2 operator and checking the precision of J-coupling of GSM vector when only one configuration is occupied in basis space for MSDHF calculations
// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
// In order to calculate the MSDHF potential, one has to diagonalize H on the MSDHF configuration, as its ground state is used in the HF-like formulas defining the MSDHF potential.
// The J^2 operator when only one configuration is occupied is also used, to check if GSM vectors are coupled to J and to project them on good J.
// As only one configuration occurs, it is much more efficient to recode J^2 in this particular case, than to use the full J^2 class of the general case.
//
// One has here constructors, destructors, J^2 operator apply call and operators overloading of operations of the type a.J^2 + b.
//
// Routines are rather straightforward so that they are not detailed. Only general explanations are given.
//
// One uses the standard decomposition J^2 = J-.J+ + Jz.(Jz + 1).
// If M = M[max], the maximal M that one can have in the GSM space, J+ |Psi> is always equal to zero.
// The J+/J- operators are allocated in the class if M < M[max], and Jz.(Jz+1) only provides with the factor M.(M + 1).Id .
//
// One always projects GSM vectors on J after Hamiltonian times vector, as the operation is very fast.
//
//
// xJ2_one_configuration_plus_alpha_str
// ------------------------------------
// Operators overloading of operations are of the type a.J2 + b.Id, to which operators of the form c.J2 + d.Id as well can be added. 
// One cannot add another operator to a.J2 + b.Id besides c.J2 + d.Id, however, as one would have to call different many-body routines for it, which would be too complicated to handle.
// Indeed, the latter is seen as (a + c).J2 + (b + d).Id .
// One can use instead (a*H + b)*PSI_0 + J^2*PSI_1 for example, up to 10 terms.
// Products of operators are not accepted with operator overloading.
// Only operators when only one configuration is occupied in basis space for MSDHF calculations are considered.

J2_one_configuration_class::J2_one_configuration_class () :
  GSM_vector_helper_M_ptr (NULL) ,
  PSI_Mp1_ptr (NULL)
{}
  
J2_one_configuration_class::J2_one_configuration_class (
						        const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_M , 
							const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_Mp1) :
  GSM_vector_helper_M_ptr (NULL) ,
  PSI_Mp1_ptr (NULL)
{
  allocate (GSM_vector_helper_M , GSM_vector_helper_Mp1);  
}

J2_one_configuration_class::J2_one_configuration_class (const class J2_one_configuration_class &X) :
  GSM_vector_helper_M_ptr (NULL) ,
  PSI_Mp1_ptr (NULL)
{
  allocate_fill (X);
}
  
J2_one_configuration_class::~J2_one_configuration_class ()
{
  delete PSI_Mp1_ptr;
}

void J2_one_configuration_class::allocate (
					   const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_M , 
					   const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_Mp1)
{
  GSM_vector_helper_M_ptr = &GSM_vector_helper_M; 

  const double M = GSM_vector_helper_M.get_M ();

  const double Jmax = GSM_vector_helper_M.get_Jmax ();
  
  if (rint (M - Jmax) != 0.0)
    {	
      Jplus.allocate  ( 1 , GSM_vector_helper_M   , GSM_vector_helper_Mp1);
      Jminus.allocate (-1 , GSM_vector_helper_Mp1 , GSM_vector_helper_M);
      
      PSI_Mp1_ptr = new class GSM_vector_one_configuration (GSM_vector_helper_Mp1);
    }
}

void J2_one_configuration_class::allocate_fill (const class J2_one_configuration_class &X)
{
  GSM_vector_helper_M_ptr = X.GSM_vector_helper_M_ptr; 
  
  if (!is_it_filled ()) return;
  
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_M = get_GSM_vector_helper_M ();
  
  const double M = GSM_vector_helper_M.get_M () , Jmax = GSM_vector_helper_M.get_Jmax ();
  
  if (rint (M - Jmax) != 0.0)
    {	
      Jplus.allocate_fill  (X.Jplus);
      Jminus.allocate_fill (X.Jminus);
      
      PSI_Mp1_ptr = new class GSM_vector_one_configuration (X.get_PSI_Mp1 ());
    }
}


void J2_one_configuration_class::deallocate ()
{
  Jplus.deallocate ();
  Jminus.deallocate ();

  delete PSI_Mp1_ptr;

  GSM_vector_helper_M_ptr = NULL;

  PSI_Mp1_ptr = NULL;
}




bool J2_one_configuration_class::is_it_filled () const
{
  return (GSM_vector_helper_M_ptr != NULL);
}



void J2_one_configuration_class::apply_add (
					    const class GSM_vector_one_configuration &PSI_in , 
					    const TYPE &alpha , 
					    class GSM_vector_one_configuration &PSI_out) const
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_M = get_GSM_vector_helper_M ();
  
  const double M = GSM_vector_helper_M.get_M ();

  const double Jmax = GSM_vector_helper_M.get_Jmax ();

  const TYPE M_M_plus_one_plus_alpha = M*(M + 1.0) + alpha;
  
  if (rint (M - Jmax) == 0.0)
    PSI_out += M_M_plus_one_plus_alpha*PSI_in;
  else
    {
      class GSM_vector_one_configuration &PSI_Mp1 = get_PSI_Mp1 ();
            
      PSI_Mp1 = Jplus*PSI_in;

      PSI_out += Jminus*PSI_Mp1 + M_M_plus_one_plus_alpha*PSI_in;			
    }
}






xJ2_one_configuration_plus_alpha_str::xJ2_one_configuration_plus_alpha_str (const TYPE &x_c , const TYPE &alpha_c , const class J2_one_configuration_class &J2_c) : x (x_c) , alpha (alpha_c) , J2 (J2_c) {}

class xJ2_one_configuration_plus_alpha_str operator + (const class J2_one_configuration_class &J2)
{
  return xJ2_one_configuration_plus_alpha_str (1.0 , 0.0 , J2);
}

class xJ2_one_configuration_plus_alpha_str operator - (const class J2_one_configuration_class &J2)
{
  return xJ2_one_configuration_plus_alpha_str (-1.0 , 0.0 , J2);
}

class xJ2_one_configuration_plus_alpha_str operator + (const class J2_one_configuration_class &J2 , const double alpha)
{
  return xJ2_one_configuration_plus_alpha_str (1.0 , alpha , J2);
}

class xJ2_one_configuration_plus_alpha_str operator - (const class J2_one_configuration_class &J2 , const double alpha)
{
  return xJ2_one_configuration_plus_alpha_str (1.0 , -alpha , J2);
}

class xJ2_one_configuration_plus_alpha_str operator + (const double alpha , const class J2_one_configuration_class &J2)
{
  return xJ2_one_configuration_plus_alpha_str (1.0 , alpha , J2);
}

class xJ2_one_configuration_plus_alpha_str operator - (const double alpha , const class J2_one_configuration_class &J2)
{
  return xJ2_one_configuration_plus_alpha_str (-1.0 , alpha , J2);
}

class xJ2_one_configuration_plus_alpha_str operator * (const class J2_one_configuration_class &J2 , const double x)
{
  return xJ2_one_configuration_plus_alpha_str (x , 0.0 , J2);
}

class xJ2_one_configuration_plus_alpha_str operator * (const double x , const class J2_one_configuration_class &J2)
{
  return xJ2_one_configuration_plus_alpha_str (x , 0.0 , J2);
}

class xJ2_one_configuration_plus_alpha_str operator / (const class J2_one_configuration_class &J2 , const double x)
{
  const double one_over_x = 1.0/x;

  return xJ2_one_configuration_plus_alpha_str (one_over_x , 0.0 , J2);
}

class xJ2_one_configuration_plus_alpha_str operator + (const class xJ2_one_configuration_plus_alpha_str &Op)
{
  return xJ2_one_configuration_plus_alpha_str (Op.x , Op.alpha , Op.J2);
}

class xJ2_one_configuration_plus_alpha_str operator - (const class xJ2_one_configuration_plus_alpha_str &Op)
{
  return xJ2_one_configuration_plus_alpha_str (-Op.x , -Op.alpha , Op.J2);
}

class xJ2_one_configuration_plus_alpha_str operator + (const class xJ2_one_configuration_plus_alpha_str &Op , const double term)
{
  return xJ2_one_configuration_plus_alpha_str (Op.x , Op.alpha + term , Op.J2);
}

class xJ2_one_configuration_plus_alpha_str operator - (const class xJ2_one_configuration_plus_alpha_str &Op , const double term)
{
  return xJ2_one_configuration_plus_alpha_str (Op.x , Op.alpha - term , Op.J2);
}

class xJ2_one_configuration_plus_alpha_str operator + (const double term , const class xJ2_one_configuration_plus_alpha_str &Op)
{
  return xJ2_one_configuration_plus_alpha_str (Op.x , term + Op.alpha , Op.J2);
}

class xJ2_one_configuration_plus_alpha_str operator - (const double term , const class xJ2_one_configuration_plus_alpha_str &Op)
{
  return xJ2_one_configuration_plus_alpha_str (-Op.x , term - Op.alpha , Op.J2);
}

class xJ2_one_configuration_plus_alpha_str operator * (const class xJ2_one_configuration_plus_alpha_str &Op , const double factor)
{
  return xJ2_one_configuration_plus_alpha_str (Op.x*factor , Op.alpha*factor , Op.J2);
}

class xJ2_one_configuration_plus_alpha_str operator / (const class xJ2_one_configuration_plus_alpha_str &Op , const double factor)
{
  return xJ2_one_configuration_plus_alpha_str (Op.x/factor , Op.alpha/factor , Op.J2);
}

class xJ2_one_configuration_plus_alpha_str operator * (const double factor , const class xJ2_one_configuration_plus_alpha_str &Op)
{
  return xJ2_one_configuration_plus_alpha_str (factor*Op.x , factor*Op.alpha , Op.J2);
}

#ifdef TYPEisDOUBLECOMPLEX

class xJ2_one_configuration_plus_alpha_str operator + (const class J2_one_configuration_class &J2 , const complex<double> &alpha)
{
  return xJ2_one_configuration_plus_alpha_str (1.0 , alpha , J2);
}

class xJ2_one_configuration_plus_alpha_str operator - (const class J2_one_configuration_class &J2 , const complex<double> &alpha)
{
  return xJ2_one_configuration_plus_alpha_str (1.0 , -alpha , J2);
}

class xJ2_one_configuration_plus_alpha_str operator + (const complex<double> &alpha , const class J2_one_configuration_class &J2)
{
  return xJ2_one_configuration_plus_alpha_str (1.0 , alpha , J2);
}

class xJ2_one_configuration_plus_alpha_str operator - (const complex<double> &alpha , const class J2_one_configuration_class &J2)
{
  return xJ2_one_configuration_plus_alpha_str (-1.0 , alpha , J2);
}

class xJ2_one_configuration_plus_alpha_str operator * (const class J2_one_configuration_class &J2 , const complex<double> &x)
{
  return xJ2_one_configuration_plus_alpha_str (x , 0.0 , J2);
}

class xJ2_one_configuration_plus_alpha_str operator * (const complex<double> &x , const class J2_one_configuration_class &J2)
{
  return xJ2_one_configuration_plus_alpha_str (x , 0.0 , J2);
}

class xJ2_one_configuration_plus_alpha_str operator / (const class J2_one_configuration_class &J2 , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return xJ2_one_configuration_plus_alpha_str (one_over_x , 0.0 , J2);
}

class xJ2_one_configuration_plus_alpha_str operator + (const class xJ2_one_configuration_plus_alpha_str &Op , const complex<double> &term)
{
  return xJ2_one_configuration_plus_alpha_str (Op.x , Op.alpha + term , Op.J2);
}

class xJ2_one_configuration_plus_alpha_str operator - (const class xJ2_one_configuration_plus_alpha_str &Op , const complex<double> &term)
{
  return xJ2_one_configuration_plus_alpha_str (Op.x , Op.alpha - term , Op.J2);
}

class xJ2_one_configuration_plus_alpha_str operator + (const complex<double> &term , const class xJ2_one_configuration_plus_alpha_str &Op)
{
  return xJ2_one_configuration_plus_alpha_str (Op.x , term + Op.alpha , Op.J2);
}

class xJ2_one_configuration_plus_alpha_str operator - (const complex<double> &term , const class xJ2_one_configuration_plus_alpha_str &Op)
{
  return xJ2_one_configuration_plus_alpha_str (-Op.x , term - Op.alpha , Op.J2);
}

class xJ2_one_configuration_plus_alpha_str operator * (const class xJ2_one_configuration_plus_alpha_str &Op , const complex<double> &factor)
{
  return xJ2_one_configuration_plus_alpha_str (Op.x*factor , Op.alpha*factor , Op.J2);
}

class xJ2_one_configuration_plus_alpha_str operator / (const class xJ2_one_configuration_plus_alpha_str &Op , const complex<double> &factor)
{
  return xJ2_one_configuration_plus_alpha_str (Op.x/factor , Op.alpha/factor , Op.J2);
}

class xJ2_one_configuration_plus_alpha_str operator * (const complex<double> &factor , const class xJ2_one_configuration_plus_alpha_str &Op)
{
  return xJ2_one_configuration_plus_alpha_str (factor*Op.x , factor*Op.alpha , Op.J2);
}

#endif

double used_memory_calc (const class J2_one_configuration_class &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.Jplus) + used_memory_calc (T.Jminus) - (sizeof (T.Jplus) + sizeof (T.Jminus))/1000000.0);
}

