#include "../GSM_include/GSM_include_def.h"

using namespace string_routines;
using namespace correlated_state_routines;


// MPI transfer is done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// CM means center of mass
// -----------------------

// Calculation of the proton or neutron rms radius
// -----------------------------------------------
// Proton and neutron rms radius are:
//
// Rp = sqrt ((1/Z) \sum_{p} (\vec{r_p,lab - R_CM})^2)
// Rn = sqrt ((1/N) \sum_{n} (\vec{r_n,lab - R_CM})^2)
//
// so that, using COSM coordinates, one obtains:
//
// Rp = ( (Z_frozen_core/Z) (R_frozen_core-p)^2 + \sum_{p val} ((1/Z) - (2/Z) (mp/M) + (mp/M)^2 ) r_p^2 + \sum_{n val} (mn/M)^2 r_n^2 
//    + \sum_{(p < p') val} ( 2 (mp/M)^2 - (4/Z) (mp/M) ) \vec{r_p} . \vec{r_{p'}} + \sum_{(n < n') val} 2 (mn/M)^2 \vec{r_n} . \vec{r_{n'}}
//    + \sum_{(p,n) val} ( 2 (mp mn)/M^2 - (2/Z) (mn/M) ) \vec{r_p} . \vec{r_n} )^{1/2} + v.t.
//
// Rn = ( (N_frozen_core/N) (R_frozen_core-n)^2 + \sum_{n val} ((1/N) - (2/N) (mn/M) + (mn/M)^2 ) r_n^2 + \sum_{p val} (mp/M)^2 r_p^2
//     + \sum_{(n < n') val} ( 2 (mn/M)^2 - (4/N) (mn/M) ) \vec{r_n} . \vec{r_{n'}} + \sum_{(p < p') val} 2 (mp/M)^2 \vec{r_p} . \vec{r_{p'}}
//     + \sum_{(p,n) val} ( 2 (mp mn)/M^2 - (2/N) (mp/M) ) \vec{r_p} . \vec{r_n} )^{1/2} + v.t. 
//
// where mp, mn, M are the masses of proton, neutron, and nucleus, and v.t. are vanishing terms.
// All constants are included in pre-calculated terms and Rp,Rn and calculated from the CM operator class.
//
// If one has holes, the used core is the frozen core, as COSM coordinates are defined with respect to the frozen core.

void rms_radius::calc_print (
			     const class input_data_str &input_data , 
			     const class array<class correlated_state_str> &PSI_qn_tab , 
			     class nucleons_data &prot_data , 
			     class nucleons_data &neut_data ,
			     class GSM_vector &PSI_full) 
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "rms radii" << endl;
      cout <<         "---------" << endl << endl;
    }

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const int n_holes_max_p = prot_data.get_n_holes_max ();
  const int n_holes_max_n = neut_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_data.get_n_scat_max ();
  const int n_scat_max_n = neut_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_data.get_E_max_hw ();
  const int En_max_hw = neut_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();

  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
  
  const int Z = prot_data.get_N_nucleons ();
  const int N = neut_data.get_N_nucleons ();
    
  const int prot_hole_states_number = prot_data.get_hole_states_number ();
  const int neut_hole_states_number = neut_data.get_hole_states_number ();
  
  const int Z_core = prot_data.get_Z_core ();
  const int N_core = prot_data.get_N_core ();
  
  const int Z_frozen_core = Z_core - prot_hole_states_number;
  const int N_frozen_core = N_core - neut_hole_states_number;

  const unsigned int rms_radius_number = input_data.get_rms_radius_number ();

  const class array<bool> &rms_radius_is_it_HO_expansion_tab = input_data.get_rms_radius_is_it_HO_expansion_tab (); 

  const class array<unsigned int> &rms_radius_BP_tab = input_data.get_rms_radius_BP_tab ();

  const class array<double> &rms_radius_J_tab = input_data.get_rms_radius_J_tab ();

  const class array<unsigned int> &rms_radius_vector_index_tab = input_data.get_rms_radius_vector_index_tab ();

  const class array<enum particle_type> &rms_radius_particle_tab = input_data.get_rms_radius_particle_tab ();

  const class array<double> &rms_radius_frozen_core_tab = input_data.get_rms_radius_frozen_core_tab ();
  
  for (unsigned int rms_radius_index = 0 ; rms_radius_index < rms_radius_number ; rms_radius_index++)
    {
      const bool is_it_HO_expansion = rms_radius_is_it_HO_expansion_tab(rms_radius_index);

      const string HO_expansion_string = (is_it_HO_expansion) ? ("HO expansion") : ("R cut"); 
      
      const unsigned int BP = rms_radius_BP_tab(rms_radius_index);

      const unsigned int vector_index = rms_radius_vector_index_tab(rms_radius_index);

      const double J = rms_radius_J_tab(rms_radius_index) , M = J;

      const class correlated_state_str PSI_qn = PSI_quantum_numbers_find (Z , N , BP , J , vector_index , PSI_qn_tab);

      class GSM_vector_helper_class PSI_helper(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
					       n_holes_max   , n_scat_max    , E_max_hw ,
					       n_holes_max_p , n_scat_max_p  , Ep_max_hw ,
					       n_holes_max_n , n_scat_max_n  , En_max_hw , BP , M , true , prot_data , neut_data);

      class GSM_vector PSI(PSI_helper);

      PSI.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);
      
      const enum particle_type particle = rms_radius_particle_tab(rms_radius_index);
      
      const double rms_radius_frozen_core = rms_radius_frozen_core_tab(rms_radius_index);

      const enum operator_type rms_radius_op = rms_radius_operator_determine (particle);
      
      const class CM_operator_class rms_op(rms_radius_op , true , J , is_it_HO_expansion , PSI_helper , PSI_helper , PSI_full);

      const class GSM_vector rms_op_PSI = rms_op*PSI;
      
      const TYPE rms_radius_square_valence = PSI*rms_op_PSI;

      const TYPE rms_radius = static_cast<TYPE> (rms_radius_calc (rms_radius_op , Z_frozen_core , N_frozen_core , Z , N , rms_radius_frozen_core , rms_radius_square_valence));

      if (THIS_PROCESS == MASTER_PROCESS) cout << J_Pi_vector_index_string (BP , J , vector_index) << " : " << particle << " rms radius with " << HO_expansion_string << " : " << rms_radius << " fm" << endl;
    }
}


