#include "../GSM_include/GSM_include_def.h"

using namespace string_routines;
using namespace correlated_state_routines;
using namespace OBMEs_TBMEs;


// MPI transfer is done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// CM means center of mass
// -----------------------

// Calculation of the proton or neutron rms radius
// -----------------------------------------------
// Proton and neutron rms radius are:
//
// Rp = sqrt ((1/Z) \sum_{p} (\vec{r_p,lab - R_CM})^2)
// Rn = sqrt ((1/N) \sum_{n} (\vec{r_n,lab - R_CM})^2)
//
// so that, using COSM coordinates, one obtains:
//
// Rp = ( (Z_frozen_core/Z) (R_frozen_core-p)^2 + \sum_{p val} ((1/Z) - (2/Z) (mp/M) + (mp/M)^2 ) r_p^2 + \sum_{n val} (mn/M)^2 r_n^2 
//    + \sum_{(p < p') val} ( 2 (mp/M)^2 - (4/Z) (mp/M) ) \vec{r_p} . \vec{r_{p'}} + \sum_{(n < n') val} 2 (mn/M)^2 \vec{r_n} . \vec{r_{n'}}
//    + \sum_{(p,n) val} ( 2 (mp mn)/M^2 - (2/Z) (mn/M) ) \vec{r_p} . \vec{r_n} )^{1/2} + v.t.
//
// Rn = ( (N_frozen_core/N) (R_frozen_core-n)^2 + \sum_{n val} ((1/N) - (2/N) (mn/M) + (mn/M)^2 ) r_n^2 + \sum_{p val} (mp/M)^2 r_p^2
//     + \sum_{(n < n') val} ( 2 (mn/M)^2 - (4/N) (mn/M) ) \vec{r_n} . \vec{r_{n'}} + \sum_{(p < p') val} 2 (mp/M)^2 \vec{r_p} . \vec{r_{p'}}
//     + \sum_{(p,n) val} ( 2 (mp mn)/M^2 - (2/N) (mp/M) ) \vec{r_p} . \vec{r_n} )^{1/2} + v.t. 
//
// where mp, mn, M are the masses of proton, neutron, and nucleus, and v.t. are vanishing terms.
// All constants are included in pre-calculated terms and Rp,Rn and calculated from the CM operator class.
//
// If one has holes, the used core is the frozen core, as COSM coordinates are defined with respect to the frozen core.

void rms_radius::calc_print (
			     const class input_data_str &input_data , 
			     const class array<class correlated_state_str> &PSI_qn_tab , 
			     class baryons_data &prot_Y_data , 
			     class baryons_data &neut_Y_data ,
			     class GSM_vector &PSI_full) 
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "rms radii" << endl;
      cout <<         "---------" << endl << endl;
    }

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();

  const bool is_it_COSM = is_it_COSM_determine (inter);

  const int S = input_data.get_hypernucleus_strangeness ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();

  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
  
  const int Z = prot_Y_data.get_N_nucleons () , Zmin = max (Z - S , 0) , Zmax = Z + S;
  const int N = neut_Y_data.get_N_nucleons () , Nmin = max (N - S , 0) , Nmax = N + S;
  
  const int prot_hole_states_number = prot_Y_data.get_hole_states_number ();
  const int neut_hole_states_number = neut_Y_data.get_hole_states_number ();
  
  const int Z_core = prot_Y_data.get_Z_core ();
  const int N_core = prot_Y_data.get_N_core ();
  
  const int Z_frozen_core = Z_core - prot_hole_states_number;
  const int N_frozen_core = N_core - neut_hole_states_number;

  const unsigned int rms_radius_number = input_data.get_rms_radius_number ();

  const class array<bool> &rms_radius_is_it_HO_expansion_tab = input_data.get_rms_radius_is_it_HO_expansion_tab (); 

  const class array<unsigned int> &rms_radius_BP_tab = input_data.get_rms_radius_BP_tab ();

  const class array<double> &rms_radius_J_tab = input_data.get_rms_radius_J_tab ();

  const class array<unsigned int> &rms_radius_vector_index_tab = input_data.get_rms_radius_vector_index_tab ();

  const class array<enum particle_type> &rms_radius_particle_tab = input_data.get_rms_radius_particle_tab ();

  const class array<double> &rms_radius_frozen_core_tab = input_data.get_rms_radius_frozen_core_tab ();
  
  for (unsigned int rms_radius_index = 0 ; rms_radius_index < rms_radius_number ; rms_radius_index++)
    {
      const bool is_it_HO_expansion = rms_radius_is_it_HO_expansion_tab(rms_radius_index);

      const string HO_expansion_string = (is_it_HO_expansion) ? ("HO expansion") : ("R cut"); 
      
      const unsigned int BP = rms_radius_BP_tab(rms_radius_index);

      const unsigned int vector_index = rms_radius_vector_index_tab(rms_radius_index);

      const double J = rms_radius_J_tab(rms_radius_index);

      const double M = J;

      const class correlated_state_str PSI_qn = PSI_quantum_numbers_find (Z , N , BP , S , J , vector_index , PSI_qn_tab);

      class GSM_vector_helper_class PSI_helper(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
					       n_holes_max   , n_scat_max    , E_max_hw ,
					       n_holes_max_p , n_scat_max_p  , Ep_max_hw ,
					       n_holes_max_n , n_scat_max_n  , En_max_hw , BP , M , true , prot_Y_data , neut_Y_data);

      class GSM_vector PSI(PSI_helper);
      
      PSI.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);
      
      class array<TYPE> OBMEs_CM_radius_init_p , reduced_r_rms_radius_same_table_init_p , reduced_r_rms_radius_diff_table_init_p;
      class array<TYPE> OBMEs_CM_radius_init_n , reduced_r_rms_radius_same_table_init_n , reduced_r_rms_radius_diff_table_init_n;
  
      if (space != NEUT_Y_ONLY)
	{
	  class OBMEs_CM_set_str &OBMEs_CM_set_p = (is_it_HO_expansion) ? (prot_Y_data.get_OBMEs_CM_set_HO_expansion ()) : (prot_Y_data.get_OBMEs_CM_set_R_cut ());
	  
	  const class OBMEs_CM_set_str &reduced_r_set_p                 = (is_it_HO_expansion) ? (prot_Y_data.get_reduced_r_HO_expansion_set                                ()) : (prot_Y_data.get_reduced_r_R_cut_set ());
	  const class OBMEs_CM_set_str &reduced_r_rms_radius_diff_set_p = (is_it_HO_expansion) ? (prot_Y_data.get_reduced_r_HO_expansion_rms_radius_different_particles_set ()) : (prot_Y_data.get_reduced_r_R_cut_rms_radius_different_particles_set ());

	  OBMEs_CM_radius_init_p.allocate_fill (OBMEs_CM_set_p(RMS_RADIUS));
	  
	  reduced_r_rms_radius_same_table_init_p.allocate_fill (reduced_r_set_p                (RMS_RADIUS));
	  reduced_r_rms_radius_diff_table_init_p.allocate_fill (reduced_r_rms_radius_diff_set_p(RMS_RADIUS));
	}
      
      if (space != PROT_Y_ONLY)
	{  
	  class OBMEs_CM_set_str &OBMEs_CM_set_n = (is_it_HO_expansion) ? (neut_Y_data.get_OBMEs_CM_set_HO_expansion ()) : (neut_Y_data.get_OBMEs_CM_set_R_cut ());
	  
	  const class OBMEs_CM_set_str &reduced_r_set_n                 = (is_it_HO_expansion) ? (neut_Y_data.get_reduced_r_HO_expansion_set                                ()) : (neut_Y_data.get_reduced_r_R_cut_set ());
	  const class OBMEs_CM_set_str &reduced_r_rms_radius_diff_set_n = (is_it_HO_expansion) ? (neut_Y_data.get_reduced_r_HO_expansion_rms_radius_different_particles_set ()) : (neut_Y_data.get_reduced_r_R_cut_rms_radius_different_particles_set ());

	  OBMEs_CM_radius_init_n.allocate_fill (OBMEs_CM_set_n(RMS_RADIUS));
	  
	  reduced_r_rms_radius_same_table_init_n.allocate_fill (reduced_r_set_n                (RMS_RADIUS));
	  reduced_r_rms_radius_diff_table_init_n.allocate_fill (reduced_r_rms_radius_diff_set_n(RMS_RADIUS));
	}
      
      const enum particle_type particle = rms_radius_particle_tab(rms_radius_index);

      const enum operator_type rms_radius_operator = rms_radius_operator_determine (particle);
  
      const double rms_radius_frozen_core = rms_radius_frozen_core_tab(rms_radius_index);
      
      const int s = particle_strangeness_determine (particle);

      const int N_nucleons_min = (particle == PROTON) ? (Zmin) : (Nmin) , N_particle_min = (s == 0) ? (N_nucleons_min) : (0);
      const int N_nucleons_max = (particle == PROTON) ? (Zmax) : (Nmax) , N_particle_max = (s == 0) ? (N_nucleons_max) : (S/s);
            
      class GSM_vector PSI_N_particle_fixed;
      
      class GSM_vector rms_operator_PSI_N_particle_fixed(PSI_helper);
      
      if (S != 0) PSI_N_particle_fixed.allocate (PSI_helper);
	
      TYPE rms_radius_square_valence = 0.0;
	  
      for (int N_particle = N_particle_min ; N_particle <= N_particle_max ; N_particle++)
	{
	  if (space != NEUT_Y_ONLY) coupled_OBMEs_CM_rms_radius_calc (rms_radius_operator , is_it_HO_expansion , input_data , N_particle , prot_Y_data);
	  if (space != PROT_Y_ONLY) coupled_OBMEs_CM_rms_radius_calc (rms_radius_operator , is_it_HO_expansion , input_data , N_particle , neut_Y_data);

	  if (space != NEUT_Y_ONLY) reduced_r_rms_radius_tables_CM_set_calc (rms_radius_operator , is_it_HO_expansion , input_data , N_particle , prot_Y_data);
	  if (space != PROT_Y_ONLY) reduced_r_rms_radius_tables_CM_set_calc (rms_radius_operator , is_it_HO_expansion , input_data , N_particle , neut_Y_data);

	  const class CM_operator_class rms_operator(rms_radius_operator , true , J , is_it_HO_expansion , is_it_COSM , PSI_helper , PSI_helper , PSI_full);
      
	  if (S == 0)
	    {      
	      rms_operator_PSI_N_particle_fixed = rms_operator*PSI;
 
	      rms_radius_square_valence = PSI*rms_operator_PSI_N_particle_fixed;
	    }
	  else
	    {	
	      PSI_N_particle_fixed = PSI;

	      PSI_N_particle_fixed.fixed_particle_type_number_impose_normalize (particle , N_particle);

	      const double PSI_N_particle_fixed_infinite_norm = PSI_N_particle_fixed.infinite_norm ();

	      if (PSI_N_particle_fixed_infinite_norm > 0)
		{
		  rms_operator_PSI_N_particle_fixed = rms_operator*PSI_N_particle_fixed;
 
		  rms_radius_square_valence += PSI_N_particle_fixed*rms_operator_PSI_N_particle_fixed;
		}
	    }
      
	  if (space != NEUT_Y_ONLY)
	    {
	      class OBMEs_CM_set_str &OBMEs_CM_set_p = (is_it_HO_expansion) ? (prot_Y_data.get_OBMEs_CM_set_HO_expansion ()) : (prot_Y_data.get_OBMEs_CM_set_R_cut ());
	  
	      class OBMEs_CM_set_str &reduced_r_set_p                 = (is_it_HO_expansion) ? (prot_Y_data.get_reduced_r_HO_expansion_set                                ()) : (prot_Y_data.get_reduced_r_R_cut_set ());
	      class OBMEs_CM_set_str &reduced_r_rms_radius_diff_set_p = (is_it_HO_expansion) ? (prot_Y_data.get_reduced_r_HO_expansion_rms_radius_different_particles_set ()) : (prot_Y_data.get_reduced_r_R_cut_rms_radius_different_particles_set ());

	      OBMEs_CM_set_p(RMS_RADIUS) = OBMEs_CM_radius_init_p;
	    
	      reduced_r_set_p                (RMS_RADIUS) = reduced_r_rms_radius_same_table_init_p;
	      reduced_r_rms_radius_diff_set_p(RMS_RADIUS) = reduced_r_rms_radius_diff_table_init_p;
	    }
	  
	  if (space != PROT_Y_ONLY)
	    {
	      class OBMEs_CM_set_str &OBMEs_CM_set_n = (is_it_HO_expansion) ? (neut_Y_data.get_OBMEs_CM_set_HO_expansion ()) : (neut_Y_data.get_OBMEs_CM_set_R_cut ());
	  
	      class OBMEs_CM_set_str &reduced_r_set_n                 = (is_it_HO_expansion) ? (neut_Y_data.get_reduced_r_HO_expansion_set                                ()) : (neut_Y_data.get_reduced_r_R_cut_set ());
	      class OBMEs_CM_set_str &reduced_r_rms_radius_diff_set_n = (is_it_HO_expansion) ? (neut_Y_data.get_reduced_r_HO_expansion_rms_radius_different_particles_set ()) : (neut_Y_data.get_reduced_r_R_cut_rms_radius_different_particles_set ());

	      OBMEs_CM_set_n(RMS_RADIUS) = OBMEs_CM_radius_init_n;
	      
	      reduced_r_set_n                (RMS_RADIUS) = reduced_r_rms_radius_same_table_init_n;
	      reduced_r_rms_radius_diff_set_n(RMS_RADIUS) = reduced_r_rms_radius_diff_table_init_n;
	    }
	}
      
      const TYPE rms_radius = rms_radius_calc (rms_radius_operator , Z_frozen_core , N_frozen_core , Z , N , rms_radius_frozen_core , rms_radius_square_valence);
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << J_Pi_vector_index_string (BP , J , vector_index) << " : " << particle << " rms radius with " << HO_expansion_string << " : " << rms_radius << " fm" << endl;
    }
}


