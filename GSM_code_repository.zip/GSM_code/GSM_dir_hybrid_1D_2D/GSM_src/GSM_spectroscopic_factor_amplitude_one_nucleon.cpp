#include "../GSM_include/GSM_include_def.h"

using namespace inputs_misc;
using namespace correlated_state_routines;
using namespace a_dagger_nucleon_helper;


// TYPE is double or complex
// -------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons
// ------------------------------------------------------------------------------------------------------------------------------------------------------




// Calculation of spectroscopic factor amplitude involving one nucleon
// -------------------------------------------------------------------
// Spectroscopic factors and overlap functions are related to transfer reactions:
// A stripping reaction removes a nucleon from the projectile and then adds it to the target.
// A pick-up reaction adds a nucleon to the projectile after removing it from the target.
//
// One considers spectroscopic factor amplitudes of one proton or one neutron of a fixed (l,j) partial wave.
// The latter nucleon is called the projectile/ejectile for stripping/pick-up and the initial nucleus the target.
// 
// Spectroscopic factors are of the form S = \sum_{n <= nmax} (<Psi[out] || a+_{nlj} || Psi[in]>^J[out]/hat(J[out]))^2 for stripping
//                                   and S = \sum_{n <= nmax} (<Psi[out] || a~_{nlj} || Psi[in]>^J[out]/hat(J[in]))^2  for pick-up
//
// Overlap functions read: I(r) = \sum_{n <= nmax} <Psi[out] || a+_{nlj} || Psi[in]>^J[out]/hat(J[out]) u_{nlj}(r) for stripping
//                     and I(r) = \sum_{n <= nmax} <Psi[out] || a~_{nlj} || Psi[in]>^J[out]/hat(J[in])  u_{nlj}(r) for pick-up
//
// using the Berggren basis of |nlj> shells, with u_{nlj}(r)/r = <nlj | rlj>.
//
// S = \int_{0}^{+oo} I(r)^2 dr, as u_{nlj}(r) one-body radial basis wave functions are orthogonal.
//
// The spectroscopic amplitude is defined to be equal to <Psi[out] | a+_{nljm} | Psi[in]> for stripping, with m = M[out] - M[in]
//                                                   and <Psi[out] |  a_{nljm} | Psi[in]> for pick-up,   with m = M[in]  - M[out]
//
// One uses M[in] = J[in] and M[out] = J[out] for convenience.
//
// Thus, one calculates and stores an array of nmax + 1 spectroscopic factor amplitudes.
// Reduced matrix elements function of a+_{nlj} and a~_{nlj} are calculated from the latter using Wigner-Eckart theorem, and one sums over 0 <= n <= nmax afterwards.
// Spectroscopic factors and overlap functions directly follow from reduced matrix elements function of a+_{nlj} and a~_{nlj}.
//
// |Psi[out]> is given as input and |Psi[in]> will be read from disk from its provided quantum numbers.
//
// Different routines are used for stripping and pick-up, for proton or neutron projectiles, and if one has both valence protons and neutrons, or only valence protons or neutrons.
//
// mu is for proton or neutron in routines where one hase only valence protons or neutrons.
//
// The GSM vectors resulting from the action of a+ or a~ on |Psi[in]> are meaningful only in the master process, even if it is not written.
//
// 
// stripping_prot_pn_calc, stripping_neut_pn_calc, stripping_pp_nn_calc
// --------------------------------------------------------------------
// Routines calculating spectroscopic factor amplitudes for proton and/or neutron projectile
// and if one has both valence protons and neutrons, or only valence protons or neutrons for stripping reactions.
// 
// pick_up_prot_pn_calc, pick_up_neut_pn_calc, pick_up_pp_nn_calc
// --------------------------------------------------------------
// Routines calculating spectroscopic factor amplitudes for proton and/or neutron ejectile
// and if one has both valence protons and neutrons, or only valence protons or neutrons for pick-up reactions.
//
// stripping_calc, pick_up_calc
// ----------------------------
// Routines calling previous routines for stripping or pick-up.

void spectroscopic_factor_amplitude::one_nucleon::stripping_prot_pn_calc (
									  const bool full_common_vectors_used_in_file ,
									  const class ljm_struct &ljm , 
									  const class correlated_state_str &PSI_IN_qn , 
									  const class GSM_vector &PSI_OUT , 
									  class array<TYPE> &spectroscopic_factor_amplitude_tab)
{  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class one_body_indices_str &one_body_indices_p = prot_data.get_one_body_indices ();

  const class nlj_table<bool> &is_it_valence_shell_prot_tab = prot_data.get_is_it_valence_shell_tab ();
    
  const int Z_core = prot_data.get_Z_core ();
  const int N_core = prot_data.get_N_core ();
  
  const int Z_IN = PSI_IN_qn.get_Z ();
  const int N_IN = PSI_IN_qn.get_N ();
  
  const int prot_hole_states_number = prot_data.get_hole_states_number (); 
  const int neut_hole_states_number = neut_data.get_hole_states_number ();
  
  const int Zval_IN = Z_IN - Z_core + prot_hole_states_number;
  const int Nval_IN = N_IN - N_core + neut_hole_states_number;
  
  const int np_max = prot_data.get_nmax ();
  
  const int l = ljm.get_l ();

  const double j = ljm.get_j ();
  const double m = ljm.get_m ();

  const double M_OUT = GSM_vector_helper_OUT.get_M (); 

  const double M_IN = M_OUT - m; 

  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);
  
  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Zval_IN , Nval_IN , file_name_IN_dimension);
  
  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));

  class array<unsigned int>   SDn_tab(space_dimension_IN , Nval_IN);
  class array<unsigned int> inSDp_tab(space_dimension_IN , Zval_IN);

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);
  
  class array<bool> is_inSDp_in_new_space_tab(space_dimension_IN);

  class array<bool> is_SDn_in_new_space_tab(space_dimension_IN);

  class array<unsigned char> reordering_bin_phases_p(space_dimension_IN);
  class array<unsigned char> reordering_bin_phases_n(space_dimension_IN);
      
  files_IN_tables_read_pn_one_nucleon (full_common_vectors_used_in_file , Zval_IN , Nval_IN , PSI_IN_qn , M_IN , prot_data , neut_data , inSDp_tab , SDn_tab , PSI_IN_component_tab ,
				       is_inSDp_in_new_space_tab , is_SDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n);
	     
  class array<unsigned int> a_dagger_PSI_IN_total_PSI_indices(space_dimension_IN_max);
  
  class array<TYPE> a_dagger_PSI_IN_components(space_dimension_IN_max);
   
  for (int np = 0 ; np <= np_max ; np++)
    {
      if (is_it_valence_shell_prot_tab(np , l , j))
	{
	  const unsigned int phi_p_stripping_index = one_body_indices_p(np , l , j , m);
      
	  if (phi_p_stripping_index != OUT_OF_RANGE)
	    {
	      const class nljm_struct phi_p_projectile (np , l , j , m , false , false , false , NADA , NADA , m);
	  
	      a_dagger_proton_PSI_IN_total_PSI_indices_components_calc_pn (phi_p_projectile , PSI_IN_qn , GSM_vector_helper_OUT , 
									   inSDp_tab , SDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_SDn_in_new_space_tab ,
									   reordering_bin_phases_p , reordering_bin_phases_n ,
									   a_dagger_PSI_IN_total_PSI_indices , a_dagger_PSI_IN_components);
	  
	      spectroscopic_factor_amplitude_tab(np) = PSI_OUT.Op_PSI_IN_scalar_product_add_one_nucleon_all_processes (full_common_vectors_used_in_file ,
														       a_dagger_PSI_IN_total_PSI_indices , a_dagger_PSI_IN_components);
	    }
	}
    }
}






void spectroscopic_factor_amplitude::one_nucleon::stripping_neut_pn_calc (
									  const bool full_common_vectors_used_in_file ,
									  const class ljm_struct &ljm , 
									  const class correlated_state_str &PSI_IN_qn , 
									  const class GSM_vector &PSI_OUT , 
									  class array<TYPE> &spectroscopic_factor_amplitude_tab)
{  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class one_body_indices_str &one_body_indices_n = neut_data.get_one_body_indices ();
  
  const class nlj_table<bool> &is_it_valence_shell_neut_tab = neut_data.get_is_it_valence_shell_tab ();
  
  const int Z_core = prot_data.get_Z_core ();
  const int N_core = prot_data.get_N_core ();
  
  const int Z_IN = PSI_IN_qn.get_Z ();
  const int N_IN = PSI_IN_qn.get_N ();
  
  const int prot_hole_states_number = prot_data.get_hole_states_number (); 
  const int neut_hole_states_number = neut_data.get_hole_states_number ();
  
  const int Zval_IN = Z_IN - Z_core + prot_hole_states_number;
  const int Nval_IN = N_IN - N_core + neut_hole_states_number;
      
  const int nn_max = neut_data.get_nmax ();
  
  const int l = ljm.get_l ();

  const double j = ljm.get_j ();
  const double m = ljm.get_m ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M (); 

  const double M_IN = M_OUT - m; 

  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);
  
  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Zval_IN , Nval_IN , file_name_IN_dimension);
    
  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));

  class array<unsigned int>   SDp_tab(space_dimension_IN , Zval_IN);
  class array<unsigned int> inSDn_tab(space_dimension_IN , Nval_IN);

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);
  
  class array<bool> is_SDp_in_new_space_tab(space_dimension_IN);

  class array<bool> is_inSDn_in_new_space_tab(space_dimension_IN);

  class array<unsigned char> reordering_bin_phases_p(space_dimension_IN);
  class array<unsigned char> reordering_bin_phases_n(space_dimension_IN);
    
  files_IN_tables_read_pn_one_nucleon (full_common_vectors_used_in_file , Zval_IN , Nval_IN , PSI_IN_qn , M_IN , prot_data , neut_data , SDp_tab , inSDn_tab , PSI_IN_component_tab ,
				       is_SDp_in_new_space_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n);
	     
  class array<unsigned int> a_dagger_PSI_IN_total_PSI_indices(space_dimension_IN_max);

  class array<TYPE> a_dagger_PSI_IN_components(space_dimension_IN_max);
   
  for (int nn = 0 ; nn <= nn_max ; nn++)
    {
      if (is_it_valence_shell_neut_tab(nn , l , j))
	{
	  const unsigned int phi_n_stripping_index = one_body_indices_n(nn , l , j , m);

	  if (phi_n_stripping_index != OUT_OF_RANGE)
	    {
	      const class nljm_struct phi_n_projectile (nn , l , j , m , false , false , false , NADA , NADA , m);
	  
	      a_dagger_neutron_PSI_IN_total_PSI_indices_components_calc_pn (phi_n_projectile , PSI_IN_qn , GSM_vector_helper_OUT , SDp_tab , inSDn_tab , PSI_IN_component_tab ,
									    is_SDp_in_new_space_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n ,
									    a_dagger_PSI_IN_total_PSI_indices , a_dagger_PSI_IN_components);
	  
	      spectroscopic_factor_amplitude_tab(nn) = PSI_OUT.Op_PSI_IN_scalar_product_add_one_nucleon_all_processes (full_common_vectors_used_in_file ,
														       a_dagger_PSI_IN_total_PSI_indices , a_dagger_PSI_IN_components);
	    }
	}
    }
}



void spectroscopic_factor_amplitude::one_nucleon::stripping_pp_nn_calc (
									const bool full_common_vectors_used_in_file ,
									const class ljm_struct &ljm , 
									const class correlated_state_str &PSI_IN_qn , 
									const class GSM_vector &PSI_OUT , 
									class array<TYPE> &spectroscopic_factor_amplitude_tab)
{  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);

  const class one_body_indices_str &one_body_indices = data.get_one_body_indices ();

  const class nlj_table<bool> &is_it_valence_shell_tab = data.get_is_it_valence_shell_tab ();
  
  const int N_core_mu = (space == PROTONS_ONLY) ? (data.get_Z_core ()) : (data.get_N_core ());
  
  const int N_IN_mu = (space == PROTONS_ONLY) ? (PSI_IN_qn.get_Z ()) : (PSI_IN_qn.get_N ());

  const int hole_states_number_mu = data.get_hole_states_number ();
  
  const int Nval_IN_mu = N_IN_mu - N_core_mu + hole_states_number_mu;
  
  const int n_max = data.get_nmax ();
  
  const int l = ljm.get_l ();

  const double j = ljm.get_j ();
  const double m = ljm.get_m ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M (); 

  const double M_IN = M_OUT - m;

  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);
  
  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Nval_IN_mu , file_name_IN_dimension);
  
  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));
  
  class array<unsigned int> inSD_tab(space_dimension_IN , Nval_IN_mu);

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);
  
  class array<bool> is_inSD_in_new_space_tab(space_dimension_IN);

  class array<unsigned char> reordering_bin_phases(space_dimension_IN);
    
  files_IN_tables_read_pp_nn_one_nucleon (full_common_vectors_used_in_file , PSI_IN_qn , M_IN , data , inSD_tab , PSI_IN_component_tab , is_inSD_in_new_space_tab , reordering_bin_phases);
	     
  class array<unsigned int> a_dagger_PSI_IN_total_PSI_indices(space_dimension_IN_max);

  class array<TYPE> a_dagger_PSI_IN_components(space_dimension_IN_max);
   
  for (int n = 0 ; n <= n_max ; n++)
    {
      if (is_it_valence_shell_tab(n , l , j))
	{
	  const unsigned int phi_mu_stripping_index = one_body_indices(n , l , j , m);

	  if (phi_mu_stripping_index != OUT_OF_RANGE)
	    {
	      const class nljm_struct phi_mu_projectile (n , l , j , m , false , false , false , NADA , NADA , m);
	  
	      a_dagger_mu_PSI_IN_total_PSI_indices_components_calc_pp_nn (phi_mu_projectile , PSI_IN_qn , GSM_vector_helper_OUT , 
									  inSD_tab , PSI_IN_component_tab , is_inSD_in_new_space_tab , reordering_bin_phases ,
									  a_dagger_PSI_IN_total_PSI_indices , a_dagger_PSI_IN_components);
	  
	      spectroscopic_factor_amplitude_tab(n) = PSI_OUT.Op_PSI_IN_scalar_product_add_one_nucleon_all_processes (full_common_vectors_used_in_file ,
														      a_dagger_PSI_IN_total_PSI_indices , a_dagger_PSI_IN_components);
	    }
	}
    }
}











void spectroscopic_factor_amplitude::one_nucleon::stripping_calc (
								  const bool full_common_vectors_used_in_file ,
								  const enum particle_type particle ,  
								  const class ljm_struct &ljm , 
								  const class correlated_state_str &PSI_IN_qn , 
								  const class GSM_vector &PSI_OUT , 
								  class array<TYPE> &spectroscopic_factor_amplitude_tab)
{
  spectroscopic_factor_amplitude_tab = 0.0;

  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const int Z_IN = PSI_IN_qn.get_Z ();
  const int N_IN = PSI_IN_qn.get_N ();
  
  const int Z_OUT = prot_data.get_N_nucleons ();
  const int N_OUT = neut_data.get_N_nucleons ();
  
  const int Z_particle = Z_cluster_determine (particle);
  const int N_particle = N_cluster_determine (particle);

  if (Z_OUT != Z_IN + Z_particle) return;
  if (N_OUT != N_IN + N_particle) return;

  const int l = ljm.get_l ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (l);

  const unsigned int BP_IN = PSI_IN_qn.get_BP ();

  if (BP_OUT != binary_parity_product (BP_IN , bp)) return;
  
  const double j = ljm.get_j ();
  const double m = ljm.get_m ();

  if (rint (abs (m) - j) > 0.0) return;
  
  const double J_IN = PSI_IN_qn.get_J ();

  const double M_IN = M_OUT - m;

  if (rint (abs (M_IN) - J_IN) > 0.0) return;
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  if (space == PROTONS_NEUTRONS)
    {
      switch (particle)
	{
	case PROTON:  one_nucleon::stripping_prot_pn_calc (full_common_vectors_used_in_file , ljm , PSI_IN_qn , PSI_OUT , spectroscopic_factor_amplitude_tab); break;
	case NEUTRON: one_nucleon::stripping_neut_pn_calc (full_common_vectors_used_in_file , ljm , PSI_IN_qn , PSI_OUT , spectroscopic_factor_amplitude_tab); break;

	default: abort_all ();
	}
    }
  else
    one_nucleon::stripping_pp_nn_calc (full_common_vectors_used_in_file , ljm , PSI_IN_qn , PSI_OUT , spectroscopic_factor_amplitude_tab);
}












void spectroscopic_factor_amplitude::one_nucleon::pick_up_prot_pn_calc (
									const bool full_common_vectors_used_in_file ,
									const class ljm_struct &ljm , 
									const class correlated_state_str &PSI_IN_qn , 
									const class GSM_vector &PSI_OUT , 
									class array<TYPE> &spectroscopic_factor_amplitude_tab)
{  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const class one_body_indices_str &one_body_indices_p = prot_data.get_one_body_indices ();
  
  const class nlj_table<bool> &is_it_valence_shell_prot_tab = prot_data.get_is_it_valence_shell_tab ();
  
  const int Z_core = prot_data.get_Z_core ();
  const int N_core = prot_data.get_N_core ();
  
  const int Z_IN = PSI_IN_qn.get_Z ();
  const int N_IN = PSI_IN_qn.get_N ();
  
  const int prot_hole_states_number = prot_data.get_hole_states_number (); 
  const int neut_hole_states_number = neut_data.get_hole_states_number ();
  
  const int Zval_IN = Z_IN - Z_core + prot_hole_states_number;
  const int Nval_IN = N_IN - N_core + neut_hole_states_number;
  
  const int np_max = prot_data.get_nmax ();
  
  const int l = ljm.get_l ();

  const double j = ljm.get_j ();
  const double m = ljm.get_m ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M (); 

  const double M_IN = M_OUT + m;

  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);
  
  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Zval_IN , Nval_IN , file_name_IN_dimension);
   
  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));

  class array<unsigned int> inSDp_tab(space_dimension_IN , Zval_IN);
  class array<unsigned int>   SDn_tab(space_dimension_IN , Nval_IN);

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);
  
  class array<bool> is_inSDp_in_new_space_tab(space_dimension_IN);
  
  class array<bool> is_SDn_in_new_space_tab(space_dimension_IN);

  class array<unsigned char> reordering_bin_phases_p(space_dimension_IN);
  class array<unsigned char> reordering_bin_phases_n(space_dimension_IN);
    
  files_IN_tables_read_pn_one_nucleon (full_common_vectors_used_in_file , Zval_IN , Nval_IN , PSI_IN_qn , M_IN , prot_data , neut_data , inSDp_tab , SDn_tab , PSI_IN_component_tab ,
				       is_inSDp_in_new_space_tab , is_SDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n);
	     
  class array<unsigned int> a_dagger_PSI_IN_total_PSI_indices(space_dimension_IN_max);

  class array<TYPE> a_dagger_PSI_IN_components(space_dimension_IN_max);
   
  for (int np = 0 ; np <= np_max ; np++)
    {
      if (is_it_valence_shell_prot_tab(np , l , j))
	{
	  const unsigned int phi_p_pick_up_index = one_body_indices_p(np , l , j , m);

	  if (phi_p_pick_up_index != OUT_OF_RANGE)
	    {
	      const class nljm_struct phi_p_ejectile (np , l , j , m , false , false , false , NADA , NADA , m);
	  
	      a_proton_PSI_IN_total_PSI_indices_components_calc_pn (phi_p_ejectile , PSI_IN_qn , GSM_vector_helper_OUT , 
								    inSDp_tab , SDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_SDn_in_new_space_tab ,
								    reordering_bin_phases_p , reordering_bin_phases_n ,
								    a_dagger_PSI_IN_total_PSI_indices , a_dagger_PSI_IN_components);
	  
	      spectroscopic_factor_amplitude_tab(np) = PSI_OUT.Op_PSI_IN_scalar_product_add_one_nucleon_all_processes (full_common_vectors_used_in_file ,
														       a_dagger_PSI_IN_total_PSI_indices , a_dagger_PSI_IN_components);
	    }
	}
    }
}






void spectroscopic_factor_amplitude::one_nucleon::pick_up_neut_pn_calc (
									const bool full_common_vectors_used_in_file ,
									const class ljm_struct &ljm , 
									const class correlated_state_str &PSI_IN_qn , 
									const class GSM_vector &PSI_OUT , 
									class array<TYPE> &spectroscopic_factor_amplitude_tab)
{  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
 
  const class one_body_indices_str &one_body_indices_n = neut_data.get_one_body_indices ();
  
  const class nlj_table<bool> &is_it_valence_shell_neut_tab = neut_data.get_is_it_valence_shell_tab ();
  
  const int Z_core = prot_data.get_Z_core ();
  const int N_core = prot_data.get_N_core ();
  
  const int Z_IN = PSI_IN_qn.get_Z ();
  const int N_IN = PSI_IN_qn.get_N ();
  
  const int prot_hole_states_number = prot_data.get_hole_states_number (); 
  const int neut_hole_states_number = neut_data.get_hole_states_number ();
  
  const int Zval_IN = Z_IN - Z_core + prot_hole_states_number;
  const int Nval_IN = N_IN - N_core + neut_hole_states_number;

  const int nn_max = neut_data.get_nmax ();
  
  const int l = ljm.get_l ();
  const double j = ljm.get_j ();
  const double m = ljm.get_m ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M (); 

  const double M_IN = M_OUT + m;

  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);
  
  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Zval_IN , Nval_IN , file_name_IN_dimension);
   
  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));

  class array<unsigned int>   SDp_tab(space_dimension_IN , Zval_IN);
  class array<unsigned int> inSDn_tab(space_dimension_IN , Nval_IN);

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);
  
  class array<bool> is_SDp_in_new_space_tab(space_dimension_IN);

  class array<bool> is_inSDn_in_new_space_tab(space_dimension_IN);

  class array<unsigned char> reordering_bin_phases_p(space_dimension_IN);
  class array<unsigned char> reordering_bin_phases_n(space_dimension_IN);
    
  files_IN_tables_read_pn_one_nucleon (full_common_vectors_used_in_file , Zval_IN , Nval_IN , PSI_IN_qn , M_IN , prot_data , neut_data , SDp_tab , inSDn_tab ,
				       PSI_IN_component_tab , is_SDp_in_new_space_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n);
	     
  class array<unsigned int> a_dagger_PSI_IN_total_PSI_indices(space_dimension_IN_max);

  class array<TYPE> a_dagger_PSI_IN_components(space_dimension_IN_max);
   
  for (int nn = 0 ; nn <= nn_max ; nn++)
    {
      if (is_it_valence_shell_neut_tab(nn , l , j))
	{
	  const unsigned int phi_n_pick_up_index = one_body_indices_n(nn , l , j , m);

	  if (phi_n_pick_up_index != OUT_OF_RANGE)
	    {
	      const class nljm_struct phi_n_ejectile (nn , l , j , m , false , false , false , NADA , NADA , m);
	  
	      a_neutron_PSI_IN_total_PSI_indices_components_calc_pn (phi_n_ejectile , PSI_IN_qn , GSM_vector_helper_OUT , 
								     SDp_tab , inSDn_tab , PSI_IN_component_tab , is_SDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
								     reordering_bin_phases_p , reordering_bin_phases_n ,
								     a_dagger_PSI_IN_total_PSI_indices , a_dagger_PSI_IN_components);
	  
	      spectroscopic_factor_amplitude_tab(nn) = PSI_OUT.Op_PSI_IN_scalar_product_add_one_nucleon_all_processes (full_common_vectors_used_in_file ,
														       a_dagger_PSI_IN_total_PSI_indices , a_dagger_PSI_IN_components);
	    }
	}
    }
}



void spectroscopic_factor_amplitude::one_nucleon::pick_up_pp_nn_calc (
								      const bool full_common_vectors_used_in_file ,
								      const class ljm_struct &ljm , 
								      const class correlated_state_str &PSI_IN_qn , 
								      const class GSM_vector &PSI_OUT , 
								      class array<TYPE> &spectroscopic_factor_amplitude_tab)
{  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);
 
  const class one_body_indices_str &one_body_indices = data.get_one_body_indices ();
  
  const class nlj_table<bool> &is_it_valence_shell_tab = data.get_is_it_valence_shell_tab ();
  
  const int N_core_mu = (space == PROTONS_ONLY) ? (data.get_Z_core ()) : (data.get_N_core ());
  
  const int N_IN_mu = (space == PROTONS_ONLY) ? (PSI_IN_qn.get_Z ()) : (PSI_IN_qn.get_N ());

  const int hole_states_number_mu = data.get_hole_states_number ();
  
  const int Nval_IN_mu = N_IN_mu - N_core_mu + hole_states_number_mu;
    
  const int n_max = data.get_nmax ();
  
  const int l = ljm.get_l ();

  const double j = ljm.get_j ();
  const double m = ljm.get_m ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M (); 

  const double M_IN = M_OUT + m;

  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);
  
  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Nval_IN_mu , file_name_IN_dimension);
   
  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));

  class array<unsigned int> inSD_tab(space_dimension_IN , Nval_IN_mu);

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);
  
  class array<bool> is_inSD_in_new_space_tab(space_dimension_IN);

  class array<unsigned char> reordering_bin_phases(space_dimension_IN);
    
  files_IN_tables_read_pp_nn_one_nucleon (full_common_vectors_used_in_file , PSI_IN_qn , M_IN , data , inSD_tab , PSI_IN_component_tab , is_inSD_in_new_space_tab , reordering_bin_phases);
	     
  class array<unsigned int> a_dagger_PSI_IN_total_PSI_indices(space_dimension_IN_max);

  class array<TYPE> a_dagger_PSI_IN_components(space_dimension_IN_max);
   
  for (int n = 0 ; n <= n_max ; n++)
    {
      if (is_it_valence_shell_tab(n , l , j))
	{
	  const unsigned int phi_mu_pick_up_index = one_body_indices(n , l , j , m);

	  if (phi_mu_pick_up_index != OUT_OF_RANGE)
	    {
	      const class nljm_struct phi_mu_ejectile (n , l , j , m , false , false , false , NADA , NADA , m);
	  
	      a_mu_PSI_IN_total_PSI_indices_components_calc_pp_nn (phi_mu_ejectile , PSI_IN_qn , GSM_vector_helper_OUT ,
								   inSD_tab , PSI_IN_component_tab , is_inSD_in_new_space_tab , reordering_bin_phases ,
								   a_dagger_PSI_IN_total_PSI_indices , a_dagger_PSI_IN_components);
	  
	      spectroscopic_factor_amplitude_tab(n) = PSI_OUT.Op_PSI_IN_scalar_product_add_one_nucleon_all_processes (full_common_vectors_used_in_file ,
														      a_dagger_PSI_IN_total_PSI_indices , a_dagger_PSI_IN_components);
	    }
	}
    }
}



void spectroscopic_factor_amplitude::one_nucleon::pick_up_calc (
								const bool full_common_vectors_used_in_file ,
								const enum particle_type particle ,  
								const class ljm_struct &ljm , 
								const class correlated_state_str &PSI_IN_qn , 
								const class GSM_vector &PSI_OUT , 
								class array<TYPE> &spectroscopic_factor_amplitude_tab)
{
  spectroscopic_factor_amplitude_tab = 0.0;

  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const int Z_IN = PSI_IN_qn.get_Z ();
  const int N_IN = PSI_IN_qn.get_N ();
  
  const int Z_OUT = prot_data.get_N_nucleons ();
  const int N_OUT = neut_data.get_N_nucleons ();
  
  const int Z_particle = Z_cluster_determine (particle);
  const int N_particle = N_cluster_determine (particle);

  if (Z_OUT != Z_IN - Z_particle) return;
  if (N_OUT != N_IN - N_particle) return;

  const int l = ljm.get_l ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (l);

  const unsigned int BP_IN = PSI_IN_qn.get_BP ();

  if (BP_OUT != binary_parity_product (BP_IN , bp)) return;
  
  const double j = ljm.get_j ();

  const double m = ljm.get_m ();

  if (rint (abs (m) - j) > 0.0) return;
  
  const double J_IN = PSI_IN_qn.get_J ();

  const double M_IN = M_OUT + m;

  if (rint (abs (M_IN) - J_IN) > 0.0) return;
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();

  if (space == PROTONS_NEUTRONS)
    {
      switch (particle)
	{
	case PROTON:  one_nucleon::pick_up_prot_pn_calc (full_common_vectors_used_in_file , ljm , PSI_IN_qn , PSI_OUT , spectroscopic_factor_amplitude_tab); break;
	case NEUTRON: one_nucleon::pick_up_neut_pn_calc (full_common_vectors_used_in_file , ljm , PSI_IN_qn , PSI_OUT , spectroscopic_factor_amplitude_tab); break;

	default: abort_all ();
	}
    }
  else
    one_nucleon::pick_up_pp_nn_calc (full_common_vectors_used_in_file , ljm , PSI_IN_qn , PSI_OUT , spectroscopic_factor_amplitude_tab);
}
