#include "../GSM_include/GSM_include_def.h"

using namespace GSM_vector_NBMEs_handling;
using namespace GSM_vector_NBMEs_handling::out_to_in;
using namespace configuration_SD_in_space_one_jump_out_to_in;

// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons
// ------------------------------------------------------------------------------------------------------------------------------------------------------


// Application of Jpm times vector with the on the fly method
// ----------------------------------------------------------
// One uses 1D partitioning here. For this, one copies the initial |Psi[in]>, parallelized in 2D format, to |Psi[in]-full>, not parallelized, and copied to every node.
// Otherwise, MPI communications would be too lengthy. Then, J+ or j- is applied with the on the fly method to |Psi[in]-full>, to get |Psi[out], parallelized in 2D format.
//
// Jpm means J+ or J-, as pm = +/1. One uses Jpm for J+ or J- in all Jpm classes files.
//
// One uses Jpm in J^2 = J-.J+ + Jz.(Jz + 1), and to generate |J M> Hamiltonian eigenstates for all M values starting from an eigenstate with a fixed M value.
//
// Jpm is applied therein as |Psi[out]> -> |Psi[out]> + Jpm.|Psi[in]>
//
// One calculates non-zero NBMEs occurring in one node only as they are not used in other nodes due to Hamiltonian 1D partitioning (see GSM_vector.cpp).
//
// One loops over proton and neutron Slater determinants, the first loop being proton or neutron according to the case.
//
//
// one_jump_p_part_pn_calc_on_the_fly, one_jump_n_part_pn_calc_on_the_fly
// ----------------------------------------------------------------------
// This provides with non-zero off-diagonal NBMEs of 1p-1h type from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// These routines are used when one has both valence protons and neutrons.
// In these routines, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the indices of the in Slater determinant and the associated NBMEs from them.
//
// pp_nn_calc_on_the_fly
// ---------------------
// This provides with the non-zero off-diagonal NBMEs for 1p-1h jumps from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// This routine is used when one has valence protons only or valence neutrons only.
// In this routine, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the number of non-zero NBMEs from them.
// 
// apply_add_on_the_fly
// --------------------
// One applies here |Psi[out]> -> |Psi[out]> + Jpm.|Psi[in]> using previous routines.

void Jpm_class::one_jump_p_part_pn_calc_on_the_fly (class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
 
  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_out.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max ();

  const int n_holes_max_p = GSM_vector_helper_out.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_out.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_out.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_out.get_n_scat_max_n ();

  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper_out.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_out.get_En_max_hw ();

  const int iMp_max = prot_Y_data.get_iM_max ();

  const unsigned int BP = GSM_vector_helper_out.get_BP ();

  const int S = GSM_vector_helper_out.get_S ();
  
  const int n_spec_max = GSM_vector_helper_out.get_n_spec_max ();

  const int iM_out = GSM_vector_helper_out.get_iM ();

  const int iMp_out_min_M = GSM_vector_helper_out.get_iMp_min_M ();
  const int iMp_out_max_M = GSM_vector_helper_out.get_iMp_max_M ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_in  = GSM_vector_helper_in.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper_out.get_all_dimensions_SDn_zero_tab ();

  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();

  const unsigned long int first_total_PSI_out_index = GSM_vector_helper_out.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper_out.get_last_total_PSI_index ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper_out.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper_out.get_iCn_max_process_tab ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper_out.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper_out.get_total_SDp_index_max ();

  if (total_outSDp_index_min > total_outSDp_index_max) return;
    
  const class GSM_vector &PSI_in_full = get_PSI_in_full ();
  
  class array<class jumps_data_out_to_in_str> one_jump_p_tab(NUMBER_OF_THREADS);

  class array<class array<double> > NBMEs_jump_p_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_in_indices_p_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_p_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , ZYval);

      NBMEs_jump_p_tab(i).allocate (ZYval);

      total_PSI_in_indices_p_tab(i).allocate (ZYval);
    }  
  
  double Jpm_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:Jpm_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_out_min_M) || (iMp_out > iMp_out_max_M)) continue;
      
      const int iMp_in = iMp_out - pm;

      const int iMn = iM_out - iMp_out;

      if ((iMp_in < 0) || (iMp_in > iMp_max)) continue;
		  
      const unsigned int BPp = outSDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sp = outSDp_qn.get_S ();

      const int Sn = S - Sp;
      
      const int n_spec_p = outSDp_qn.get_n_spec ();

      const int n_spec_n = n_spec_max - n_spec_p;

      const int n_scat_p = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp = outSDp_qn.get_iC ();

      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp_out);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp_out);

      if (all_dimensions_SDn_zero) continue;

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(i_thread);

      class array<double> &NBMEs_jump_p = NBMEs_jump_p_tab(i_thread);

      class array<unsigned long int> &total_PSI_in_indices_p = total_PSI_in_indices_p_tab(i_thread);

      bool jump_p_calculated = false;

      bool is_there_jump_calc_all = false;

      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
	  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  
	  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
	    { 
	      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
	      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

	      if (dimension_SDn == 0) continue;

	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector_in(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp_in);

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector_out(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp_out);

	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_SDn*outSDp_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_SDn_minus_one;

	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  if (!jump_p_calculated)
		    {
		      one_jump_p.one_jump_mu_Jpm_store (pm , BPp , Sp , n_spec_p , n_scat_p , iCp , iMp_out , outSDp_index , prot_Y_data);

		      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
		      
		      is_there_jump_calc_all = (dimension_one_jump_p > 0);

		      NBMEs_one_jump_mu_calc_one_body_operator_Jpm (Jpm_OBMEs_p_tab , one_jump_p , NBMEs_jump_p);

		      jump_p_calculated = true;
		    }
		  
		  if (is_there_jump_calc_all)
		    {
		      for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
			{
			  const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + SDn_index;

			  if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			    {
			      const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			      bool is_there_jump_calc = false;
						  
			      total_PSI_in_indices_p_fill_Jpm (SDn_index , sum_dimensions_configuration_Mp_Mn_fixed_in , one_jump_p , GSM_vector_helper_in , dimension_SDn , total_PSI_in_indices_p , is_there_jump_calc);

			      if (is_there_jump_calc)
				{
				  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
		      
				  PSI_out[PSI_out_index] += component_part_one_jump_calc_Jpm (dimension_one_jump_p , total_PSI_in_indices_p , NBMEs_jump_p , PSI_in_full);
  
				  Jpm_multiplications_number_local += dimension_one_jump_p;
				  
				}}}}}}}}
  
  Jpm_multiplications_number += Jpm_multiplications_number_local;
}





void Jpm_class::one_jump_n_part_pn_calc_on_the_fly (class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_out.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max ();

  const int n_holes_max_p = GSM_vector_helper_out.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_out.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_out.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_out.get_n_scat_max_n ();

  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper_out.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_out.get_En_max_hw ();

  const int iMn_max = neut_Y_data.get_iM_max ();

  const unsigned int BP = GSM_vector_helper_out.get_BP ();

  const int S = GSM_vector_helper_out.get_S ();

  const int n_spec_max = GSM_vector_helper_out.get_n_spec_max ();
  
  const int iM_out = GSM_vector_helper_out.get_iM ();

  const int iMn_out_min_M = GSM_vector_helper_out.get_iMn_min_M ();
  const int iMn_out_max_M = GSM_vector_helper_out.get_iMn_max_M ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_in = GSM_vector_helper_in.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper_out.get_all_dimensions_SDp_zero_tab ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();  

  const unsigned long int first_total_PSI_out_index = GSM_vector_helper_out.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper_out.get_last_total_PSI_index ();
    
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper_out.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper_out.get_iCp_max_process_tab ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper_out.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper_out.get_total_SDn_index_max ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
  
  const class GSM_vector &PSI_in_full = get_PSI_in_full ();
  
  class array<class jumps_data_out_to_in_str> one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<double> > NBMEs_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_in_indices_n_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_n_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , NYval);

      NBMEs_jump_n_tab(i).allocate (NYval);

      total_PSI_in_indices_n_tab(i).allocate (NYval);
    }
  
  double Jpm_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:Jpm_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();

      if ((iMn_out < iMn_out_min_M) || (iMn_out > iMn_out_max_M)) continue;
      
      const int iMn_in = iMn_out - pm;

      const int iMp = iM_out - iMn_out;

      if ((iMn_in < 0) || (iMn_in > iMn_max)) continue;
		  
      const unsigned int BPn = outSDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sn = outSDn_qn.get_S ();

      const int Sp = S - Sn;
      
      const int n_spec_n = outSDn_qn.get_n_spec ();

      const int n_spec_p = n_spec_max - n_spec_n;

      const int n_scat_n = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn = outSDn_qn.get_iC ();

      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn_out);

      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn_in);
		  
      if ((dimension_outSDn == 0) || (dimension_inSDn == 0)) continue;

      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn_out);

      if (all_dimensions_SDp_zero) continue;

      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(i_thread);

      class array<double> &NBMEs_jump_n = NBMEs_jump_n_tab(i_thread);

      class array<unsigned long int> &total_PSI_in_indices_n = total_PSI_in_indices_n_tab(i_thread);
  
      bool jump_n_calculated = false;

      bool is_there_jump_calc_all = false;

      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  
	  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

	      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
	      
	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

	      if (dimension_SDp == 0) continue;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector_in(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector_out(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn*dimension_SDp_minus_one;

	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  if (!jump_n_calculated)
		    {
		      one_jump_n.one_jump_mu_Jpm_store (pm , BPn , Sn , n_spec_n , n_scat_n , iCn , iMn_out , outSDn_index , neut_Y_data);

		      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

		      is_there_jump_calc_all = (dimension_one_jump_n > 0);

		      NBMEs_one_jump_mu_calc_one_body_operator_Jpm (Jpm_OBMEs_n_tab , one_jump_n , NBMEs_jump_n);

		      jump_n_calculated = true;
		    }
			
		  if (is_there_jump_calc_all)
		    {	  
		      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
			{
			  const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + dimension_outSDn*SDp_index;

			  if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			    {
			      const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			      bool is_there_jump_calc = false;
						  
			      total_PSI_in_indices_n_fill_Jpm (SDp_index , sum_dimensions_configuration_Mp_Mn_fixed_in , dimension_inSDn , one_jump_n , GSM_vector_helper_in , total_PSI_in_indices_n , is_there_jump_calc);

			      if (is_there_jump_calc)
				{
				  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
		  
				  PSI_out[PSI_out_index] += component_part_one_jump_calc_Jpm (dimension_one_jump_n , total_PSI_in_indices_n , NBMEs_jump_n , PSI_in_full);
									  
				  Jpm_multiplications_number += dimension_one_jump_n;
				  
				}}}}}}}}
  
  Jpm_multiplications_number += Jpm_multiplications_number_local;
}









void Jpm_class::pp_nn_calc_on_the_fly (class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
    
  const enum space_type space = GSM_vector_helper_out.get_space ();

  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_out.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();

  const unsigned int BP = GSM_vector_helper_out.get_BP ();

  const int S = GSM_vector_helper_out.get_S ();

  const int iM_out = GSM_vector_helper_out.get_iM ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_in  = GSM_vector_helper_in.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();

  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();

  const class array<double> &Jpm_mu_tab = (space == PROT_Y_ONLY) ? (Jpm_OBMEs_p_tab) : (Jpm_OBMEs_n_tab);
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper_out.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper_out.get_last_total_PSI_index ();

  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_outSD_index_min = GSM_vector_helper_out.get_total_SD_index_min ();
  const unsigned long int total_outSD_index_max = GSM_vector_helper_out.get_total_SD_index_max ();

  if (total_outSD_index_min > total_outSD_index_max) return;
    
  const class GSM_vector &PSI_in_full = get_PSI_in_full ();
  
  class array<class jumps_data_out_to_in_str> one_jump_mu_tab(NUMBER_OF_THREADS);

  class array<class array<double> > NBMEs_jump_mu_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_in_indices_mu_tab(NUMBER_OF_THREADS);
  
  class array<double> NBMEs_jump_mu(N_valence_baryons);

  class array<unsigned long int> total_PSI_in_indices_mu(N_valence_baryons);
	      
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_mu_tab(i).allocate (ONE_JUMP , space , truncation_hw , truncation_ph , N_valence_baryons);

      NBMEs_jump_mu_tab(i).allocate (N_valence_baryons);

      total_PSI_in_indices_mu_tab(i).allocate (N_valence_baryons);
    }
  
  double Jpm_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:Jpm_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSD_index = total_outSD_index_min ; total_outSD_index <= total_outSD_index_max ; total_outSD_index++)
    {
      const class SD_quantum_numbers &outSD_qn = SD_quantum_numbers_tab(total_outSD_index);

      const int iM_outSD = outSD_qn.get_iM ();

      if (iM_outSD != iM_out) continue;

      const unsigned int BP_outSD = outSD_qn.get_BP ();

      if (BP_outSD != BP) continue;
      
      const int S_outSD = outSD_qn.get_S ();

      if (S_outSD != S) continue;
      
      const unsigned int n_scat = outSD_qn.get_n_scat ();

      const unsigned int iC = outSD_qn.get_iC ();

      const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
      const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
      
      const unsigned int outSD_index = outSD_qn.get_SD_index ();

      const unsigned long int sum_dimensions_configuration_fixed_in  = sum_dimensions_GSM_vector_in(n_scat , iC);
      const unsigned long int sum_dimensions_configuration_fixed_out = sum_dimensions_GSM_vector_out(n_scat , iC);
      
      const unsigned long int total_PSI_out_index = sum_dimensions_configuration_fixed_out + outSD_index;
      
      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
	{
	  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	      
	  class jumps_data_out_to_in_str &one_jump_mu = one_jump_mu_tab(i_thread);

	  class array<double> &NBMEs_jump_mu = NBMEs_jump_mu_tab(i_thread);

	  class array<unsigned long int> &total_PSI_in_indices_mu = total_PSI_in_indices_mu_tab(i_thread);

	  one_jump_mu.one_jump_mu_Jpm_store (pm , BP , S , 0 , n_scat , iC , iM_out , outSD_index , data);

	  const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();

	  if (dimension_one_jump_mu == 0) continue;

	  bool is_there_jump_calc_all = false;
      
	  total_PSI_in_indices_pp_nn_fill_Jpm (sum_dimensions_configuration_fixed_in , one_jump_mu , GSM_vector_helper_in , total_PSI_in_indices_mu , is_there_jump_calc_all);

	  if (is_there_jump_calc_all)
	    {
	      NBMEs_one_jump_mu_calc_one_body_operator_Jpm (Jpm_mu_tab , one_jump_mu , NBMEs_jump_mu);
	  
	      PSI_out[PSI_out_index] += component_part_one_jump_calc_Jpm (dimension_one_jump_mu , total_PSI_in_indices_mu , NBMEs_jump_mu , PSI_in_full);
	  				  
	      Jpm_multiplications_number += dimension_one_jump_mu;
	    }
	}
    }
  
  Jpm_multiplications_number += Jpm_multiplications_number_local;
}











void Jpm_class::apply_add_on_the_fly (
				      const class GSM_vector &PSI_in ,
				      class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  const enum space_type space = GSM_vector_helper_out.get_space ();
     
  class baryons_data &prot_Y_data = GSM_vector_helper_out.get_prot_Y_data ();
  class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();
  
  class GSM_vector &PSI_in_full = get_PSI_in_full ();

  PSI_in_full.change_GSM_vector_helper_reallocate (GSM_vector_helper_in_full);
  
  PSI_in_full.full_vector_fill (PSI_in);
  
  if (configuration_SD_one_jump_tables_to_recalculate)
    {
      configuration_SD_in_out_in_space_one_jump_tables_alloc_calc_Jpm (is_there_cout_detailed , pm , GSM_vector_helper_in , GSM_vector_helper_out , prot_Y_data , neut_Y_data);

      if (is_there_cout_detailed && (THIS_PROCESS == MASTER_PROCESS))
	{
	  const string pm_string = (pm == 1) ? ("+") : ("-");
      
	  cout << "---------------------------------------------------------------------------------------------------" << endl;
	  cout << "1p-1h jumps tables for J" << pm_string << " calculated" << endl;  
	  cout << "---------------------------------------------------------------------------------------------------" << endl;
	  cout << endl;
	}
    }
  
  if (space == PROT_NEUT_Y)
    { 
      one_jump_p_part_pn_calc_on_the_fly (PSI_out);
      one_jump_n_part_pn_calc_on_the_fly (PSI_out);
    }
  else
    pp_nn_calc_on_the_fly (PSI_out);
      
  if (configuration_SD_one_jump_tables_to_recalculate)
    {
      prot_Y_data.one_jump_tables_Jpm_out_to_in_deallocate ();
      neut_Y_data.one_jump_tables_Jpm_out_to_in_deallocate ();
    }
  
  PSI_in_full.remove_GSM_vector_helper ();
}




