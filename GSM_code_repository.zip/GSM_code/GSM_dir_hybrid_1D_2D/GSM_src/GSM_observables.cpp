#include "../GSM_include/GSM_include_def.h"

using namespace string_routines;
using namespace inputs_misc;
using namespace correlated_state_routines;



// TYPE is double or complex
// -------------------------

// Calculation of observables from GSM eigenstates
// -----------------------------------------------
// Observables are calculated GSM eigenstates.
//
// As the following routines are straightforward, calling only observable routines, they are not commented. See files where observables are coded for details.






void GSM_observables::calculation (
				   const class input_data_str &input_data ,
				   const class array<class correlated_state_str> &PSI_qn_tab ,
				   class interaction_class &inter_data ,
				   class TBMEs_class &TBMEs_pn ,  
				   class TBMEs_class &TBMEs_cv ,  
				   class baryons_data &prot_Y_data ,
				   class baryons_data &neut_Y_data ,
				   class GSM_vector &PSI_full)
{
  
  const bool are_there_GSM_multipoles                = input_data.get_are_there_GSM_multipoles ();
  const bool are_there_EM_transitions                = input_data.get_are_there_EM_transitions ();
  const bool are_there_EM_transitions_strength       = input_data.get_are_there_EM_transitions_strength ();
  const bool are_there_beta_transitions              = input_data.get_are_there_beta_transitions ();
  const bool are_there_beta_transitions_strength     = input_data.get_are_there_beta_transitions_strength ();
  const bool are_there_densities                     = input_data.get_are_there_densities ();
  const bool are_there_correlation_densities         = input_data.get_are_there_correlation_densities ();
  const bool are_there_pair_densities                = input_data.get_are_there_pair_densities ();
  const bool are_there_spectroscopic_factors         = input_data.get_are_there_spectroscopic_factors ();
  const bool are_there_overlap_functions             = input_data.get_are_there_overlap_functions ();
  const bool are_there_rms_radii                     = input_data.get_are_there_rms_radii ();
  const bool are_there_rms_radius_one_body_strengths = input_data.get_are_there_rms_radius_one_body_strengths ();
  const bool are_there_Hamiltonian_parts             = input_data.get_are_there_Hamiltonian_parts ();
  const bool are_there_Coulomb_isospin_mixtures      = input_data.get_are_there_Coulomb_isospin_mixtures ();
  const bool are_there_dagger_tilde_operators        = input_data.get_are_there_dagger_tilde_operators ();
  const bool are_there_new_natural_orbitals_p        = input_data.get_are_there_new_natural_orbitals_p ();
  const bool are_there_new_natural_orbitals_n        = input_data.get_are_there_new_natural_orbitals_n ();

  const bool are_there_new_natural_orbitals = (are_there_new_natural_orbitals_p || are_there_new_natural_orbitals_n);
  
  const bool are_there_new_natural_orbitals_dagger_tilde_operators = (are_there_new_natural_orbitals || are_there_dagger_tilde_operators);
 
  const bool are_there_multipoles_EM_beta_calculations = (are_there_GSM_multipoles || are_there_EM_transitions || are_there_EM_transitions_strength || are_there_beta_transitions || are_there_beta_transitions_strength);
  
  const bool are_there_densities_spectroscopic_factors_overlap_functions_calculations = (are_there_densities || are_there_correlation_densities || are_there_pair_densities || are_there_spectroscopic_factors || are_there_overlap_functions);

  const bool are_there_multipoles_EM_beta_densities_spectroscopic_factors_overlap_functions_calculations = (are_there_multipoles_EM_beta_calculations || are_there_densities_spectroscopic_factors_overlap_functions_calculations);

  const bool are_there_rms_radii_Hamiltonian_parts_Coulomb_isospin_mixture_calculations = (are_there_rms_radii || are_there_rms_radius_one_body_strengths || are_there_Hamiltonian_parts || are_there_Coulomb_isospin_mixtures);

  const bool are_there_calculations = (are_there_multipoles_EM_beta_densities_spectroscopic_factors_overlap_functions_calculations ||
				       are_there_rms_radii_Hamiltonian_parts_Coulomb_isospin_mixture_calculations ||
				       are_there_new_natural_orbitals_dagger_tilde_operators);
    
  if (are_there_calculations)
    {
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  cout << endl << "Observables" << endl;
	  cout <<         "-----------" << endl << endl;
	}
      
      const double reference_time = (THIS_PROCESS == MASTER_PROCESS) ? (absolute_time_determine ()) : (NADA);
      
      if (are_there_new_natural_orbitals) natural_orbitals_ESPEs::calc_print (true , true , input_data , TBMEs_pn , prot_Y_data , neut_Y_data , PSI_full);
  
      if ((THIS_PROCESS == MASTER_PROCESS) && are_there_new_natural_orbitals_p) prot_Y_data.natural_orbitals_OBMEs_basis_store (inter_data);
      if ((THIS_PROCESS == MASTER_PROCESS) && are_there_new_natural_orbitals_n) neut_Y_data.natural_orbitals_OBMEs_basis_store (inter_data);
      
      if (are_there_GSM_multipoles) GSM_multipoles::calc_print (input_data , prot_Y_data , neut_Y_data , PSI_qn_tab , PSI_full);
      
      if (are_there_EM_transitions) EM_transitions::calc_print (input_data , inter_data , prot_Y_data , neut_Y_data , PSI_qn_tab , PSI_full);

      if (are_there_EM_transitions_strength) EM_transitions_strength::calc_store (input_data , prot_Y_data , neut_Y_data , PSI_qn_tab , PSI_full);

      if (are_there_beta_transitions) beta_transitions::calc_print (input_data , inter_data , PSI_qn_tab , prot_Y_data , neut_Y_data);

      if (are_there_beta_transitions_strength) beta_transitions_strength::calc_store (input_data , PSI_qn_tab , prot_Y_data , neut_Y_data);

      if (are_there_densities) density::calc_store (input_data , PSI_qn_tab , prot_Y_data , neut_Y_data , PSI_full);

      if (are_there_correlation_densities) correlation_density::calc_store (input_data , inter_data , PSI_qn_tab , prot_Y_data , neut_Y_data , PSI_full);
      
      if (are_there_pair_densities) pair_density::calc_store_pair_densities (input_data , PSI_qn_tab , prot_Y_data , neut_Y_data , PSI_full);
      
      if (are_there_spectroscopic_factors) spectroscopic_factor::calc_print (input_data , PSI_qn_tab , prot_Y_data , neut_Y_data);

      if (are_there_overlap_functions) overlap_function::calc_store (input_data , PSI_qn_tab , prot_Y_data , neut_Y_data);

      if (are_there_rms_radii) rms_radius::calc_print (input_data , PSI_qn_tab , prot_Y_data , neut_Y_data , PSI_full);

      if (are_there_rms_radius_one_body_strengths) rms_radius_one_body_strength::calc_store (input_data , PSI_qn_tab , prot_Y_data , neut_Y_data , PSI_full);

      if (are_there_Hamiltonian_parts) Hamiltonian_parts::calc_print (input_data , PSI_qn_tab , inter_data , prot_Y_data , neut_Y_data , TBMEs_pn , TBMEs_cv , PSI_full);

      if (are_there_dagger_tilde_operators) dagger_tilde_operators::calc_store (input_data , PSI_qn_tab , prot_Y_data , neut_Y_data);
    
      if (are_there_Coulomb_isospin_mixtures) Coulomb_isospin_mixture::calc_print (input_data , prot_Y_data , neut_Y_data , PSI_qn_tab);
      
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  const double now = absolute_time_determine () , relative_time = now - reference_time;
	  
	  cout << endl << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;
	  cout << "Observables calculated. time:" << relative_time << " s" << endl;
	  cout << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl << endl;
	}
    }
}
