#include "../GSM_include/GSM_include_def.h"


// TYPE is double or complex
// -------------------------

// out_to_in means that one starts from |outSD> and one creates |inSD> from a+ a operations
// ----------------------------------------------------------------------------------------






// Calculation and storage of jumps for the application of many-body operators
// ---------------------------------------------------------------------------
// A many-body operator is written in second quantization: Op = \sum_ab <a | Op | b> a+(a) a(b) +  \sum_abcd <ab | Op | cd> a+(a) a+(b) a(d) a(c).
// Hence, in order to apply Op to a GSM vector vector, one has to calculate jumps of the form <outSD | a+(a) a(b) | inSD> and <outSD | a+(a) a+(b) a(d) a(c) | inSD>.

// The pp, nn two-body jumps are written as <outSD | a+(a) a+(b) a(d) a(c) | inSD> = <outSD | a+(a) a(c) | SDinter> <SDinter | a+(b) a(d) | inSD>, with |SDinter> an intermediate Slater determinant.
// The pn two-body jumps <outSD | a+(a) a+(b) a(d) a(c) | inSD> are equal to  <outSDp | a+(a) a(c) | inSDp>  <outSDn | a+(b) a(d) | inSDn>, so that no intermediate Slater determinant is needed here.
// Hence, all jumps can be calculated from those of the form <outSD | a+(a) a(b) | inSD>. 
// 
// In order not to consider intermediate Slater determinants with many particles in the continuum, one demands all Slater determinants to have a number particles in the continuum smaller or equal
// to that of the model space. This is possible as can always reshuffle the a+/a operators above for |SDinter> to be in that situation.
//
// One has |Psi[out]> = Op|Psi[in]>. To calculate the components of |Psi[out]> = \sum_{outSD} c_{outSD} |outSD>, one has to calculate c_{outSD} = \sum_{inSD} c_{inSD} <outSD | CM-op | inSD>.
// Hence, for a fixed c_{outSD}, one has |outSD> fixed and |inSD> varied, so that |inSD> differs by one or two states in off-diagonal matrix elements.
// As |outSD> is fixed and |inSD> is varied and is function of |outSD>, one calls this scheme "out to in".
// Consequently, in the jump routines, one starts from |outSD>, or its configuration C[out], and 1p-1h excitations generate |inSD>, or its configuration C_in.
// Hence, one goes from outSD to inSD.
// 
// One can separate in the calculation of <outSD | a+(a) a(b) | inSD> in two parts: 
//
// _One considers only configurations and shells, so that a, b become (n,l,j) shells and inSD, outSD are replaced by their configurations C_in, C[out].
//  C[in] is generated from C[out] with 1p-1h excitations from the occupied shells of C[out] to its unoccupied shells.
//  No matrix element is calculated here, but one one stores the indices the shells a, b and the quantum numbers of configurations.
//
// _One fixes C[in], C[out], a(shell), b(shell), and one obtains <outSD | a+(a) a(b) | inSD> by adding only m quantum numbers.
//  One stores the phase <outSD | a+(a) a(b) | inSD>, and also m quantum numbers.
//
// One considers Slater determinants in this namespace.
// Jumps done at the level of configurations and shells have been calculated and stored in GSM_configuration_one_jump_construction_set.cpp .
// Previously introduced notations are used throughout this namespace.
//
// OpenMP parallelization is used on the loop of proton or neutron Slater determinants total indices, i.e. indices taking into account all quantum numbers (see GSM_vector_dimension.cpp).
// MPI parallelization here is only implicit, as on considers only the Slater determinants which are used in operators by the current node.
// 
//
// Equivalent configurations in scattering many-body spaces
// --------------------------------------------------------
// When one has scattering states in the one-body basis, it is possible to reduce the number of stored <outSD | a+(a) a(b) | inSD> jumps by using the fact that one has many more scattering states than valence nucleons.
// For example, let us consider that the one-body states consist of 51 p3/2 shells, issued from the discretization of the p3/2 contour, and that one has a configuration of three valence nucleons.
// These are typical values in GSM. As one has in average 17 shells between two nucleons, with only one nucleon per shell for most configurations, 
// a 1p-1h excitation from an occupied shell to another leaves the <outSD | a+(a) a(b) | inSD> matrix element unchanged, as only the principal quantum number of |a> changes.
// Moreover, Slater determinants are formally identical from one configuration to the other in this case, as the number and indices of one-body states on one shell depend only on j and m.
//
// Hence, this <outSD | a+(a) a(b) | inSD> matrix element is stored only once, and one starts storing other matrix elements once 1p-1h excitations make the nucleon arrive on an occupied shell, 
// or if one arrives on a new partial wave. One-body states are evidently ordered so that all one-body states of a given partial wave are contiguous.
//
// The configuration for which <outSD | a+(a) a(b) | inSD> matrix element is stored is a called an equivalent configuration, 
// as it represents all the configurations equivalent to the latter for the calculation of <outSD | a+(a) a(b) | inSD> matrix elements.







// Storage of dimensions and Slater determinant jumps in arrays for J+ and J-
// --------------------------------------------------------------------------
// An outSD Slater determinant jump has been generated and belongs to the proton or neutron model space.
// If arrays dimensions are calculated only, the dimension of fixed outSD Slater determinant is increased. 
// If Slater determinant jumps arrays are constructed, the index of the shell containing the changing states, the M index im[in] = m[in] + m[max] of the in one-body state,
// Delta[iM[in]], i.e. the coded difference of M quantum numbers, equal to 0 for J+ and 1 for J-,
// the index of inSD function of inSD quantum numbers (see GSM_array_BP_S_Nscat_iC_iM_SD.hpp),
// and reordering binary phase (see observables_basic_functions.cpp for definition) are also stored in the array containing Slater determinant jumps.
// As M[out] is fixed (outSD is fixed), M[in] (of inSD) and m[out] (of the out one-body state) can be recovered from m[in] and Delta[iM[in]].
//
// Jpm is J+ or J- (pm is plus or minus one).

void SD_one_jump_construction_set_out_to_in::SD_one_jump_data_Jpm_fill (
									const enum operation_type operation , 
									const unsigned int shell_index ,
									const int im_in , 
									const unsigned int Delta_iM_in , 
									const unsigned int bin_phase , 
									const unsigned int inSD_index , 
									const unsigned long int SD_one_jump_table_Jpm_zero_index , 
									const unsigned long int dimensions_SD_one_jump_table_Jpm_index ,  
									class baryons_data &particles_data)
{ 
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_one_jump_table_Jpm = particles_data.get_dimensions_SD_one_jump_table_Jpm_out_to_in ();

  switch (operation)
    {
    case DIMENSIONS_TABLES_CALC:
      dimensions_SD_one_jump_table_Jpm[dimensions_SD_one_jump_table_Jpm_index]++;
      break;

    case TABLES_FILL:
      {  
	const unsigned int SD_one_jump_index = dimensions_SD_one_jump_table_Jpm[dimensions_SD_one_jump_table_Jpm_index]++;

	const unsigned long int SD_one_jump_table_Jpm_index = SD_one_jump_table_Jpm_zero_index + SD_one_jump_index;

	class array_of_SD_one_jump_data_Jpm_out_to_in &SD_one_jump_table_Jpm = particles_data.get_SD_one_jump_table_Jpm_out_to_in ();

	SD_one_jump_table_Jpm[SD_one_jump_table_Jpm_index] = SD_one_jump_data_Jpm_out_to_in_str(shell_index , im_in , Delta_iM_in , inSD_index , bin_phase);
      } break; 

    default: abort_all ();
    }
}





// Generation of all 1p-1h Slater determinants inSD out of a Slater determinant outSD for J+ and J-
// ------------------------------------------------------------------------------------------------
// One generates all the inSD Slater determinants with 1p-1h excitations on outSD fixed for J+ and J-.
// As M[in] = M[out] -/+ 1, one just has to loop on Delta[iM[in]], the coded difference of M quantum numbers M[in] - M[out], equal to 0 for J+ and 1 for J-,
// as it fixes M[in], and m[in] and m[out] of the in and out one-body states, and on the valence states occupied in outSD, to generate all possible 1p-1h excitations for J+ and J-.
// As configuration does not vary in 1p-1h excitations of J+ and J-, it is equal to that of outSD.
// The out shell, where the out one-body state is, is also equal to the in shell, where the in one-body state is.
// One generates a 1p-1h excitation on outSD, which generates inSD (see GSM_Slater_determinant.cpp).
// The index of inSD is then found with binary search from its occupied states (see GSM_Slater_determinant.cpp).
//
// Jpm is J+ or J- (pm is plus or minus one).

void SD_one_jump_construction_set_out_to_in::SD_one_jump_table_all_inSD_Jpm (
									     const enum operation_type operation , 
									     const unsigned long int dimensions_SD_one_jump_table_Jpm_zero_index , 
									     const unsigned int BP , 
									     const int S ,
									     const int n_spec ,
									     const int n_scat ,
									     const unsigned int iC , 
									     const int iM_out ,
									     const unsigned int outSD_index ,
									     const class Slater_determinant &outSD ,
									     class Slater_determinant &inSD ,
									     class Slater_determinant &SD_try ,  
									     class baryons_data &particles_data)
{ 
  const int iM_max = particles_data.get_iM_max ();
  
  const int Delta_iM_in_min = (iM_out > 0) ? (0) : (1);

  const int Delta_iM_in_max = (iM_out == iM_max) ? (0) : (1);

  if (Delta_iM_in_min > Delta_iM_in_max) return;

  const int N_valence_baryons = particles_data.get_N_valence_baryons ();

  const int m_max_minus_half = particles_data.get_m_max_minus_half ();
 
  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();

  const class one_body_indices_str &one_body_indices = particles_data.get_one_body_indices ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = particles_data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = particles_data.get_SD_set ();
  
  const class array_of_SD_one_jump_data_Jpm_out_to_in &SD_one_jump_table_Jpm = particles_data.get_SD_one_jump_table_Jpm_out_to_in ();

  const unsigned long int dimensions_SD_one_jump_table_Jpm_index = dimensions_SD_one_jump_table_Jpm_zero_index + outSD_index;

  const unsigned long int SD_one_jump_table_Jpm_zero_index = (operation == TABLES_FILL) ? (SD_one_jump_table_Jpm.index_determine (BP , S , n_spec , n_scat , iC , iM_out , outSD_index , 0)) : (NADA);

  for (int Delta_iM_in = Delta_iM_in_min ; Delta_iM_in <= Delta_iM_in_max ; Delta_iM_in++)
    {
      const int iM_in = (Delta_iM_in == 0) ? (iM_out - 1) : (iM_out + 1);

      const unsigned int dimension_inSD_set = dimensions_SD_set(BP , S , n_spec , n_scat , iC , iM_in);

      const unsigned long int SD_set_zero_inSD_index = SD_set.index_determine (BP , S , n_spec , n_scat , iC , iM_in , 0);
      
      for (int i = 0 ; i < N_valence_baryons ; i++)
	{
	  const unsigned int out_jump = outSD[i];

	  const class nljm_struct &phi_out_jump = phi_table(out_jump);

	  const unsigned int shell_index = phi_out_jump.get_shell_index ();

	  const int ij = phi_out_jump.get_ij ();

	  const int im_in_min = -ij + m_max_minus_half;
	  const int im_in_max =  ij + m_max_minus_half + 1;

	  const int im_out = phi_out_jump.get_im ();

	  const int im_in = (Delta_iM_in == 0) ? (im_out - 1) : (im_out + 1);

	  if ((im_in >= im_in_min) && (im_in <= im_in_max))
	    {
	      const unsigned int in_jump = one_body_indices(shell_index , im_in);
	    
	      const bool is_in_jump_occupied_in_outSD = outSD.is_valence_state_occupied (in_jump);

	      if (!is_in_jump_occupied_in_outSD)
		{
		  unsigned int bin_phase = 0;

		  outSD.excitation_1p_1h_and_bin_phase (in_jump , out_jump , inSD , bin_phase);
		  
		  const unsigned int inSD_index = inSD.index_search (dimension_inSD_set , SD_set_zero_inSD_index , SD_set , SD_try);
		  
		  SD_one_jump_data_Jpm_fill (operation , shell_index , im_in , Delta_iM_in , bin_phase , inSD_index , 
					     SD_one_jump_table_Jpm_zero_index , dimensions_SD_one_jump_table_Jpm_index , particles_data);
		}
	    }
	}
    }
}




// Calculation of all the inSD 1p-1h Slater determinants jumps for all outSD Slater determinants for J+ and J-
// -----------------------------------------------------------------------------------------------------------
// One loops over all outSD Slater determinants and one calls the previous routine.
//
// OpenMP is used on the index of the total outSD Slater determinant (i.e. including all its quantum numbers, see GSM_vector_dimensions.cpp), which is usually more than the number of threads.
//
// Jpm is J+ or J- (pm is plus or minus one).


void SD_one_jump_construction_set_out_to_in::SD_one_jump_table_all_inSD_Jpm (
									     const enum operation_type operation , 
									     const int pm ,  
									     const unsigned long int dimensions_SD_one_jump_table_Jpm_zero_index , 
									     const unsigned int BP , 
									     const int S ,
									     const int n_spec ,
									     const int n_scat ,
									     const unsigned int iC , 
									     const int iM_out ,
									     const unsigned int outSD_index ,
									     const class Slater_determinant &outSD ,
									     class Slater_determinant &inSD ,
									     class Slater_determinant &SD_try ,  
									     class baryons_data &particles_data)
{ 
  const int iM_max = particles_data.get_iM_max ();

  const unsigned int Delta_iM_in = (pm == 1) ? (0) : (1);
  
  const int iM_in = (Delta_iM_in == 0) ? (iM_out - 1) : (iM_out + 1);

  if ((iM_in < 0) || (iM_in > iM_max)) return;
  
  const int N_valence_baryons = particles_data.get_N_valence_baryons ();

  const int m_max_minus_half = particles_data.get_m_max_minus_half ();
 
  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();

  const class one_body_indices_str &one_body_indices = particles_data.get_one_body_indices ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = particles_data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = particles_data.get_SD_set ();
  
  const class array_of_SD_one_jump_data_Jpm_out_to_in &SD_one_jump_table_Jpm = particles_data.get_SD_one_jump_table_Jpm_out_to_in ();

  const unsigned long int dimensions_SD_one_jump_table_Jpm_index = dimensions_SD_one_jump_table_Jpm_zero_index + outSD_index;

  const unsigned long int SD_one_jump_table_Jpm_zero_index = (operation == TABLES_FILL) ? (SD_one_jump_table_Jpm.index_determine (BP , S , n_spec , n_scat , iC , iM_out , outSD_index , 0)) : (NADA);
  
  const unsigned int dimension_inSD_set = dimensions_SD_set(BP , S , n_spec , n_scat , iC , iM_in);

  const unsigned long int SD_set_zero_inSD_index = SD_set.index_determine (BP , S , n_spec , n_scat , iC , iM_in , 0);
      
  for (int i = 0 ; i < N_valence_baryons ; i++)
    {
      const unsigned int out_jump = outSD[i];

      const class nljm_struct &phi_out_jump = phi_table(out_jump);

      const unsigned int shell_index = phi_out_jump.get_shell_index ();

      const int ij = phi_out_jump.get_ij ();

      const int im_in_min = -ij + m_max_minus_half;
      const int im_in_max =  ij + m_max_minus_half + 1;

      const int im_out = phi_out_jump.get_im ();

      const int im_in = (Delta_iM_in == 0) ? (im_out - 1) : (im_out + 1);

      if ((im_in >= im_in_min) && (im_in <= im_in_max))
	{
	  const unsigned int in_jump = one_body_indices(shell_index , im_in);
	    
	  const bool is_in_jump_occupied_in_outSD = outSD.is_valence_state_occupied (in_jump);

	  if (!is_in_jump_occupied_in_outSD)
	    {
	      unsigned int bin_phase = 0;

	      outSD.excitation_1p_1h_and_bin_phase (in_jump , out_jump , inSD , bin_phase);
		  
	      const unsigned int inSD_index = inSD.index_search (dimension_inSD_set , SD_set_zero_inSD_index , SD_set , SD_try);
		  
	      SD_one_jump_data_Jpm_fill (operation , shell_index , im_in , Delta_iM_in , bin_phase , inSD_index , 
					 SD_one_jump_table_Jpm_zero_index , dimensions_SD_one_jump_table_Jpm_index , particles_data);
	    }
	}
    }
}







// Calculation of all the inSD 1p-1h Slater determinants jumps for all outSD Slater determinants for J+ and J-
// -----------------------------------------------------------------------------------------------------------
// One loops over all outSD Slater determinants and one calls the previous routine.
//
// OpenMP is used on the index of the total outSD Slater determinant (i.e. including all its quantum numbers, see GSM_vector_dimensions.cpp), which is usually more than the number of threads.
//
// Jpm is J+ or J- (pm is plus or minus one).

void SD_one_jump_construction_set_out_to_in::all_SDs_one_jump_all_SDs_Jpm (
									   const enum operation_type operation ,
									   const bool is_it_pole_approximation , 
									   const bool is_it_both_Jplus_Jminus ,
									   const int pm , 
									   class baryons_data &particles_data)
{
  const int n_scat_max = (!is_it_pole_approximation) ? (particles_data.get_n_scat_max ()) : (0);
  
  const int N_valence_baryons = particles_data.get_N_valence_baryons ();
  
  const unsigned long int dimension_SD_total = particles_data.get_dimension_SD_total ();
  
  const class array_of_SD &SD_set = particles_data.get_SD_set ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_outSD_in_space_tab = particles_data.get_is_outSD_in_space_tab ();

  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = particles_data.get_SD_quantum_numbers_tab ();
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_one_jump_table_Jpm = particles_data.get_dimensions_SD_one_jump_table_Jpm_out_to_in ();
  dimensions_SD_one_jump_table_Jpm = 0;
  
  class array<class Slater_determinant>   inSD_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant>  outSD_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_tab  (i).allocate (N_valence_baryons);
      outSD_tab (i).allocate (N_valence_baryons);
      SD_try_tab(i).allocate (N_valence_baryons);
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSD_index = 0 ; total_outSD_index < dimension_SD_total ; total_outSD_index++)
    {
      const class SD_quantum_numbers &outSD_qn = SD_quantum_numbers_tab(total_outSD_index);
            
      const int n_scat = outSD_qn.get_n_scat ();
      
      if (n_scat > n_scat_max) continue;

      const unsigned int BP = outSD_qn.get_BP ();
      
      const int S = outSD_qn.get_S ();      

      const int n_spec = outSD_qn.get_n_spec ();
      
      const unsigned int iC = outSD_qn.get_iC ();

      const int iM_out = outSD_qn.get_iM ();

      const unsigned int outSD_index = outSD_qn.get_SD_index ();

      const bool is_outSD_in_space = is_outSD_in_space_tab(BP , S , n_spec , n_scat , iC , iM_out , outSD_index);

      if (is_outSD_in_space)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();

	  class Slater_determinant &inSD   =   inSD_tab(i_thread);
	  class Slater_determinant &outSD  =  outSD_tab(i_thread);
	  class Slater_determinant &SD_try = SD_try_tab(i_thread);
	  
	  const unsigned long int dimensions_SD_one_jump_table_Jpm_zero_index = dimensions_SD_one_jump_table_Jpm.index_determine (BP , S , n_spec , n_scat , iC , iM_out , 0);

	  outSD = SD_set(BP , S , n_spec , n_scat , iC , iM_out , outSD_index);
	  
	  if (is_it_both_Jplus_Jminus)
	    SD_one_jump_table_all_inSD_Jpm (operation , dimensions_SD_one_jump_table_Jpm_zero_index , BP , S , n_spec , n_scat , iC , iM_out , outSD_index , outSD , inSD , SD_try , particles_data);
	  else
	    SD_one_jump_table_all_inSD_Jpm (operation , pm , dimensions_SD_one_jump_table_Jpm_zero_index , BP , S , n_spec , n_scat , iC , iM_out , outSD_index , outSD , inSD , SD_try , particles_data);
	}
    }
}








// Allocation and calculation of all the inSD 1p-1h configurations jumps for all outSD configurations for J+ and J-
// ----------------------------------------------------------------------------------------------------------------
// One allocates arrays and one calls the previous routine.
// Dimensions of arrays of Slater determinant jumps are calculated first, they are allocated, and then calculated.
// Time taken to do calculations can be also written, as they can be lengthy.
//
// Jpm is J+ or J- (pm is plus or minus one).

void SD_one_jump_construction_set_out_to_in::all_SDs_one_jump_all_SDs_alloc_calc_Jpm (
										      const bool is_there_cout , 
										      const bool is_it_pole_approximation ,
										      const bool is_it_both_Jplus_Jminus ,
										      const int pm ,
										      class baryons_data &particles_data)
{
  const double time_1 = absolute_time_determine ();

  const unsigned long int dimension_SD_total = particles_data.get_dimension_SD_total (); 

  const enum particle_type nucleonic_particle = particles_data.get_nucleonic_particle ();
  
  const int strangeness_max = particles_data.get_hypernucleus_strangeness ();
  
  const int n_spec_max = particles_data.get_n_spec_max ();
  
  const int n_scat_max = (!is_it_pole_approximation) ? (particles_data.get_n_scat_max ()) : (0);

  const int iM_max = particles_data.get_iM_max ();
  
  const class array<unsigned int> &dimensions_configuration_set = particles_data.get_dimensions_configuration_set ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = particles_data.get_dimensions_SD_set ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned long int> &sum_dimensions_SD_set = particles_data.get_sum_dimensions_SD_set ();

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_one_jump_table_Jpm = particles_data.get_dimensions_SD_one_jump_table_Jpm_out_to_in ();

  class array_of_SD_one_jump_data_Jpm_out_to_in &SD_one_jump_table_Jpm = particles_data.get_SD_one_jump_table_Jpm_out_to_in ();
  
  dimensions_SD_one_jump_table_Jpm.deallocate ();

  SD_one_jump_table_Jpm.deallocate ();
  
  dimensions_SD_one_jump_table_Jpm.allocate (dimension_SD_total , sum_dimensions_SD_set);

  const double time_2 = absolute_time_determine () , relative_time_dimension = time_2 - time_1;

  const string Jpm_str = Jpm_str_determine (is_it_both_Jplus_Jminus , pm);
  
  all_SDs_one_jump_all_SDs_Jpm (DIMENSIONS_TABLES_CALC , is_it_pole_approximation , is_it_both_Jplus_Jminus , pm , particles_data);

  SD_one_jump_table_Jpm.allocate (dimension_SD_total , sum_dimensions_SD_set , strangeness_max , n_spec_max , n_scat_max , dimensions_configuration_set , iM_max , dimensions_SD_set , dimensions_SD_one_jump_table_Jpm);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const double dimensions_SD_one_jump_table_Jpm_used_memory = used_memory_calc (dimensions_SD_one_jump_table_Jpm);
      
      const double SD_one_jump_table_Jpm_used_memory = used_memory_calc (SD_one_jump_table_Jpm);

      cout << endl << "SD jumps table " << nucleonic_particle << " space for " << Jpm_str << " (on the fly)" << endl;
      cout << "dimensions: " << dimensions_SD_one_jump_table_Jpm_used_memory << " Mb" << endl;
      cout << "array     : " << SD_one_jump_table_Jpm_used_memory << " Mb" << endl;
      cout << "time      : " << relative_time_dimension << " s" << endl << endl;
    }

  all_SDs_one_jump_all_SDs_Jpm (TABLES_FILL , is_it_pole_approximation , is_it_both_Jplus_Jminus , pm , particles_data);

  const double time_3 = absolute_time_determine () , relative_time = time_3 - time_2;

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    cout << "SD jumps table " << nucleonic_particle << " space for " << Jpm_str << " (on the fly) calculated. time:" << relative_time << " s" << endl << endl;
}








// Storage of dimensions and Slater determinant jumps in arrays for the general operator
// -------------------------------------------------------------------------------------
// An outSD Slater determinant jump has been generated and belongs to the proton or neutron model space.
// If arrays dimensions are calculated only, the dimension of fixed outSD Slater determinant is increased. 
// If Slater determinant jumps arrays are constructed, the index of the equivalent configuration (see above),
// Delta[iM[in]], i.e. the difference of M quantum numbers in and out indices, equal to M[in] - M[out] + 2.m[max],
// the index of inSD function of inSD quantum numbers (see GSM_array_BP_S_Nspec_Nscat_iC_iM_SD.hpp),
// the M index im[in] = m[in] + m[max] of the in one-body state,
// and reordering binary phase (see observables_basic_functions.cpp for definition) are also stored in the array containing Slater determinant jumps.
// As M[out] is fixed (outSD is fixed), M[in] (of inSD) and m[out] (of the out one-body state) can be recovered from m[in] and Delta[iM[in]].


void SD_one_jump_construction_set_out_to_in::SD_one_jump_data_fill (
								    const enum operation_type operation , 
								    const unsigned long int dimensions_SD_one_jump_table_index , 
								    const unsigned long int SD_one_jump_table_zero_index , 
								    const unsigned int dimension_inSD_set ,
								    const unsigned long int SD_set_zero_inSD_index ,
								    const int Delta_iM_in , 
								    const unsigned int bin_phase ,
								    const int im_in , 
								    const unsigned int C_eq_one_jump_index , 
								    const class Slater_determinant &inSD , 
								    class Slater_determinant &SD_try , 
								    class baryons_data &particles_data)
{ 
  const class array_of_SD &SD_set = particles_data.get_SD_set ();

  const unsigned int inSD_index = inSD.index_search (dimension_inSD_set , SD_set_zero_inSD_index , SD_set , SD_try);

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_one_jump_table = particles_data.get_dimensions_SD_one_jump_table_out_to_in ();

  switch (operation)
    {
    case DIMENSIONS_TABLES_CALC:
      dimensions_SD_one_jump_table[dimensions_SD_one_jump_table_index]++;
      break;

    case TABLES_FILL:
      { 
	const unsigned int SD_one_jump_index = dimensions_SD_one_jump_table[dimensions_SD_one_jump_table_index]++;

	const unsigned long int SD_one_jump_table_index = SD_one_jump_table_zero_index + SD_one_jump_index;

	class array_of_SD_one_jump_data_out_to_in &SD_one_jump_table = particles_data.get_SD_one_jump_table_out_to_in ();

	SD_one_jump_table[SD_one_jump_table_index] = SD_one_jump_data_out_to_in_str(C_eq_one_jump_index , Delta_iM_in , inSD_index , im_in , bin_phase);
      } break; 

    default: abort_all ();
    }
}









// Generation of all 1p-1h Slater determinants inSD out of a Slater determinant outSD for the general operator
// -----------------------------------------------------------------------------------------------------------
// One generates all the inSD Slater determinants with 1p-1h excitations on outSD fixed.
// As C[in], C[out], the changing shells s[in] and s[out], M[in] and M[out] are fixed,
// one just has to loop on the valence states occupied in outSD to generate all possible 1p-1h excitations,
// where one checks that s[out] is the shell occupied by the current valence nucleon and m[out] fixes m[in].

void SD_one_jump_construction_set_out_to_in::SD_one_jump_table_all_inSD (
									 const enum operation_type operation , 
									 const class configuration &C_out , 
									 const class Slater_determinant &outSD ,
									 const unsigned long int dimensions_SD_one_jump_table_index , 
									 const unsigned long int SD_one_jump_table_zero_index , 
									 const unsigned int C_eq_one_jump_index ,
									 const unsigned int dimension_inSD_set ,
									 const unsigned long int SD_set_zero_inSD_index ,
									 const int Delta_iM_in , 
									 const unsigned int C_in_jump_shell ,
									 const unsigned int C_out_jump_shell , 
									 class Slater_determinant &inSD ,
									 class Slater_determinant &SD_try ,   
									 class baryons_data &particles_data)
{ 
  const int two_m_max = particles_data.get_two_m_max () , M_jump = Delta_iM_in - two_m_max;

  const int N_valence_baryons = particles_data.get_N_valence_baryons ();

  const int m_max_minus_half = particles_data.get_m_max_minus_half ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();

  const class one_body_indices_str &one_body_indices = particles_data.get_one_body_indices ();
  
  const class nlj_struct &shell_qn_in = shells_qn(C_in_jump_shell);

  const int ij_in = shell_qn_in.get_ij ();

  const int im_in_min = -ij_in + m_max_minus_half;
  const int im_in_max =  ij_in + m_max_minus_half + 1;

  const bool shell_in_in_C_out = C_out.is_shell_occupied (C_in_jump_shell);

  for (int i = 0 ; i < N_valence_baryons ; i++)
    {
      const unsigned int shell_out_index = C_out[i];
      
      if (shell_out_index == C_out_jump_shell)
	{
	  const unsigned int out_jump = outSD[i];

	  const class nljm_struct &phi_out_jump = phi_table(out_jump);

	  const int im_out = phi_out_jump.get_im ();

	  const int im_in = im_out + M_jump;

	  if ((im_in >= im_in_min) && (im_in <= im_in_max))
	    {   
	      const unsigned int in_jump = one_body_indices(C_in_jump_shell , im_in);
	      
	      const bool is_in_jump_occupied_in_outSD = (shell_in_in_C_out && outSD.is_valence_state_occupied (in_jump));

	      if (!is_in_jump_occupied_in_outSD)
		{
		  unsigned int bin_phase = 0;

		  outSD.excitation_1p_1h_and_bin_phase (in_jump , out_jump , inSD , bin_phase);
			
		  SD_one_jump_data_fill (operation , dimensions_SD_one_jump_table_index , SD_one_jump_table_zero_index , 
					 dimension_inSD_set , SD_set_zero_inSD_index , Delta_iM_in , bin_phase , im_in , C_eq_one_jump_index , inSD , SD_try , particles_data);
		}
	    }
	}
    }
}







// Calculation of all the inSD 1p-1h Slater determinants jumps for all outSD Slater determinants
// ---------------------------------------------------------------------------------------------
// One loops over all outSD Slater determinants and one calls the previous routine.
//
// One checks if one has to do a calculation or not according to the used operator and model space truncations.
// _If one has a one-body operator or a proton-neutron two body operator, hence one-body like as there is no intermediate Slater determinant (see GSM_configuration_one_jump_construction_set.cpp),
//  the calculation must be done only if outSD belongs to the model space and the current (Pi[in], M[in]) can be attained with this operator (calculated elsewhere).
// _If one has a two-body operator with pp and nn two-body matrix elements, hence involving intermediate Slater determinants (see GSM_configuration_one_jump_construction_set.cpp),
//  the calculation must be done only if outSD belongs to the model space or if the current (Pi[in], M[in]) can be attained with this operator (calculated elsewhere).
//  Indeed, if outSD does not belong to the model space and hence |outSD> is |SDinter> here, |inSD> has to belong to the model space and hence the current (Pi[in], M[in]) must be attained with this operator (calculated elsewhere).
//
// One also uses time-reversal symmetry (TRS) to save memory (see GSM_TRS_class.cpp).
// Indeed, 1p-1h phases of the form <outSD | a+(a) a(b) | inSD> is equal to +/- <outSD | TRS a+(TRS(a)) a(TRS(b)) TRS | inSD>,
// where the phase is the reordering phase of TRS|outSD> times that of TRS|inSD> times (-1)^(ja-ma) times (-1)^(jb-mb), and SD TRS phases have been calculated and stored.
// Thus, <outSD | a+(a) a(b) | inSD> can be found easily if M[in] < 0, so that one stores only <outSD | a+(a) a(b) | inSD> if M[in] > 0.
//
// One will use binary search to localize 1p-1h jumps data of given M[in] values, outSD being given in array input.
// Indeed, it would take too much memory to give M[in] as array input, as too many zeros would have to be stored.
// Hence, one loops first on the index of Delta[M[in]], even though some values must be recalculated,
// as then 1p-1h jumps data of same M[in] values are contiguous in the array of 1p-1h jumps data.
// The first and indices of 1p-1h jumps data with fixed M[in] can then be found with binary search (see GSM_array_of_SD_one_jump_data_out_to_in.cpp).
//
// As one stores only data for the 1p-1h jump configuration equal to the 1p-1h jump equivalent configuration (see above)
// when one loops over 1p-1h jump configuration data, one does calculations only if the current equivalent configuration is different from the previous one.
//
// OpenMP is used on the index of the total outSD Slater determinant (i.e. including all its quantum numbers, see GSM_vector_dimensions.cpp), which is usually more than the number of threads.

void SD_one_jump_construction_set_out_to_in::all_SDs_one_jump_all_SDs (
								       const bool is_it_one_body ,
								       const bool is_it_two_body_pn_only , 
								       const enum operation_type operation , 
								       const bool is_it_pole_approximation , 
								       class baryons_data &particles_data)
{
  const bool is_it_one_body_two_body_pn_only = (is_it_one_body || is_it_two_body_pn_only);
  
  const int strangeness_max = particles_data.get_hypernucleus_strangeness ();
  
  const int n_spec_max = particles_data.get_n_spec_max ();
  
  const int n_scat_max = (!is_it_pole_approximation) ? (particles_data.get_n_scat_max ()) : (0);

  const int iM_max = particles_data.get_iM_max ();
  
  const int N_valence_baryons = particles_data.get_N_valence_baryons ();
  
  const unsigned long int dimension_SD_total = particles_data.get_dimension_SD_total ();
  
  const int two_m_max = particles_data.get_two_m_max ();

  const int four_m_max = particles_data.get_four_m_max ();

  const class array_of_configuration &configuration_set = particles_data.get_configuration_set ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = particles_data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = particles_data.get_SD_set ();

  const class array<bool> &BPin_Sin_Nspec_in_iMin_for_one_jump_tab = particles_data.get_BPin_Sin_Nspec_in_iMin_for_one_jump_tab ();

  const class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_out_in_space_tab = particles_data.get_is_configuration_out_in_space_tab ();

  const class array_BP_S_Nspec_Nscat_iC<bool> &is_it_configuration_inter_to_include_tab = particles_data.get_is_it_configuration_inter_to_include_tab ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_outSD_in_space_tab = particles_data.get_is_outSD_in_space_tab ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_it_SD_inter_to_include_tab = particles_data.get_is_it_SD_inter_to_include_tab ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_configuration_one_jump_table = particles_data.get_dimensions_configuration_one_jump_table_out_to_in ();

  const class array_of_configuration_one_jump_data_out_to_in &configuration_one_jump_table = particles_data.get_configuration_one_jump_table_out_to_in ();

  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = particles_data.get_SD_quantum_numbers_tab ();

  const class array_of_SD_one_jump_data_out_to_in &SD_one_jump_table = particles_data.get_SD_one_jump_table_out_to_in ();

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_one_jump_table = particles_data.get_dimensions_SD_one_jump_table_out_to_in ();

  dimensions_SD_one_jump_table = 0;
	
  class array<class configuration> C_out_tab(NUMBER_OF_THREADS);
  
  class array<class Slater_determinant> inSD_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSD_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      C_out_tab(i).allocate (N_valence_baryons);
      
      inSD_tab(i).allocate (N_valence_baryons);

      outSD_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSD_index = 0 ; total_outSD_index < dimension_SD_total ; total_outSD_index++)
    {
      const class SD_quantum_numbers &outSD_qn = SD_quantum_numbers_tab(total_outSD_index);
      
      const unsigned int BP_out = outSD_qn.get_BP ();
      
      const int S_out = outSD_qn.get_S ();          

      const int n_spec_out = outSD_qn.get_n_spec ();
      
      const int n_scat_out = outSD_qn.get_n_scat ();

      if (n_scat_out > n_scat_max) continue;
      
      const unsigned int iC_out = outSD_qn.get_iC ();

      const int iM_out = outSD_qn.get_iM ();

      const unsigned int outSD_index = outSD_qn.get_SD_index ();

      const bool is_configuration_out_in_space = is_configuration_out_in_space_tab(BP_out , S_out , n_spec_out , n_scat_out , iC_out);

      const bool is_outSD_in_space = is_outSD_in_space_tab(BP_out , S_out , n_spec_out , n_scat_out , iC_out , iM_out , outSD_index);
      
      const bool is_it_SD_inter_to_include = (!is_it_one_body_two_body_pn_only) ? (is_it_SD_inter_to_include_tab(BP_out , S_out , n_spec_out , n_scat_out , iC_out , iM_out , outSD_index)) : (false);

      const bool is_there_calc_one_body_two_body_pn_only_from_SD = (is_it_one_body_two_body_pn_only && is_outSD_in_space);

      const bool is_there_calc_two_body_from_SD = (!is_it_one_body_two_body_pn_only && (is_outSD_in_space || is_it_SD_inter_to_include));

      const bool is_there_calc_from_SD = (is_there_calc_one_body_two_body_pn_only_from_SD || is_there_calc_two_body_from_SD);
		    
      if (is_there_calc_from_SD)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();

	  class configuration &C_out = C_out_tab(i_thread);
	  
	  class Slater_determinant &inSD = inSD_tab(i_thread);

	  class Slater_determinant &outSD = outSD_tab(i_thread);

	  class Slater_determinant &SD_try = SD_try_tab(i_thread);

	  const bool is_it_configuration_inter_to_include = (!is_it_one_body_two_body_pn_only) ? (is_it_configuration_inter_to_include_tab(BP_out , S_out , n_spec_out , n_scat_out , iC_out)) : (false);
	  
	  const unsigned long int dimensions_SD_one_jump_table_index = dimensions_SD_one_jump_table.index_determine (BP_out , S_out , n_spec_out , n_scat_out , iC_out , iM_out , outSD_index);

	  const unsigned long int SD_one_jump_table_zero_index = (operation == TABLES_FILL) ? (SD_one_jump_table.index_determine (BP_out , S_out , n_spec_out , n_scat_out , iC_out , iM_out , outSD_index , 0)) : (NADA);

	  C_out = configuration_set(BP_out , S_out , n_spec_out , n_scat_out , iC_out);

  	  outSD = SD_set(BP_out , S_out , n_spec_out , n_scat_out , iC_out , iM_out , outSD_index);
	  
	  // Delta_iM_in comes first as binary search will be used on Delta_iM_in.
	  for (int Delta_iM_in = 0 ; Delta_iM_in <= four_m_max ; Delta_iM_in++)
	    {
	      const int M_jump = Delta_iM_in - two_m_max , iM_in = iM_out + M_jump , two_iM_in = 2*iM_in;
		      
	      if ((two_iM_in >= iM_max) && (iM_in <= iM_max))
		{
		  for (unsigned int BP_in = 0 ; BP_in <= 1 ; BP_in++)
		    for (int S_in = 0 ; S_in <= strangeness_max ; S_in++)
		      for (int n_spec_in = 0 ; n_spec_in <= n_spec_max ; n_spec_in++)
		    {
		      const unsigned int dimensions_configuration_one_jump_table_C_out_BP_S_Nspec_in = dimensions_configuration_one_jump_table(BP_out , S_out , n_spec_out , n_scat_out , iC_out , BP_in , S_in , n_spec_in);

		      if (dimensions_configuration_one_jump_table_C_out_BP_S_Nspec_in > 0)
			{		  				
			  const bool BPin_Sin_Nspec_in_iMin_for_one_jump = BPin_Sin_Nspec_in_iMin_for_one_jump_tab(BP_in , S_in , n_spec_in , iM_in);				      
						
			  const bool is_there_calc_two_body_pn_only_BPin_Sin_Nspec_in_iMin = (is_it_two_body_pn_only && (is_configuration_out_in_space && BPin_Sin_Nspec_in_iMin_for_one_jump));

			  const bool is_there_calc_one_body_from_C_BPin_Sin_Nspec_in_iMin = (is_it_one_body && (is_configuration_out_in_space && BPin_Sin_Nspec_in_iMin_for_one_jump));
			  
			  const bool is_there_calc_two_body_from_C_BPin_Sin_Nspec_in_iMin = (!is_it_one_body_two_body_pn_only && (is_configuration_out_in_space || (is_it_configuration_inter_to_include && BPin_Sin_Nspec_in_iMin_for_one_jump)));

			  const bool is_there_calc_from_C_BPin_Sin_Nspec_in_iMin = (is_there_calc_two_body_pn_only_BPin_Sin_Nspec_in_iMin || is_there_calc_one_body_from_C_BPin_Sin_Nspec_in_iMin || is_there_calc_two_body_from_C_BPin_Sin_Nspec_in_iMin);

			  if (is_there_calc_from_C_BPin_Sin_Nspec_in_iMin)
			    {	 
			      const unsigned int C_one_jump_table_debut_index = configuration_one_jump_table.index_determine (BP_out , S_out , n_spec_out , n_scat_out , iC_out , BP_in , S_in , n_spec_in , 0);
			      
			      const unsigned int C_one_jump_table_end_index = C_one_jump_table_debut_index + (dimensions_configuration_one_jump_table_C_out_BP_S_Nspec_in - 1);

			      unsigned int C_eq_one_jump_index_bef = 0;

			      for (unsigned int C_one_jump_table_index = C_one_jump_table_debut_index ; C_one_jump_table_index <= C_one_jump_table_end_index ; C_one_jump_table_index++)
				{	
				  const class configuration_one_jump_data_out_to_in_str &C_one_jump_data_out = configuration_one_jump_table[C_one_jump_table_index];

				  const unsigned int C_eq_one_jump_index = C_one_jump_data_out.get_C_eq_one_jump_index ();
						
				  if ((C_one_jump_table_index == C_one_jump_table_debut_index) || (C_eq_one_jump_index != C_eq_one_jump_index_bef))
				    {
				      const unsigned int iC_in = C_one_jump_data_out.get_iC_in ();

				      const unsigned int C_in_jump_shell  = C_one_jump_data_out.get_C_in_shell ();
				      const unsigned int C_out_jump_shell = C_one_jump_data_out.get_C_out_shell ();

				      const int n_scat_in = C_one_jump_data_out.get_n_scat_in ();
		   
				      const unsigned int dimension_inSD_set = dimensions_SD_set(BP_in , S_in , n_spec_in , n_scat_in , iC_in , iM_in);

				      const unsigned long int SD_set_zero_inSD_index = SD_set.index_determine (BP_in , S_in , n_spec_in , n_scat_in , iC_in , iM_in , 0);

				      SD_one_jump_table_all_inSD (operation , C_out , outSD , dimensions_SD_one_jump_table_index , SD_one_jump_table_zero_index , 
								  C_eq_one_jump_index , dimension_inSD_set , SD_set_zero_inSD_index , 
								  Delta_iM_in , C_in_jump_shell , C_out_jump_shell , inSD , SD_try , particles_data);
				    }

				  C_eq_one_jump_index_bef = C_eq_one_jump_index;
				}}}}}}}}
}







// Allocation and calculation of all the inSD 1p-1h Slater determinants jumps for all outSD Slater determinants
// ------------------------------------------------------------------------------------------------------------
// One allocates arrays and one calls the previous routine.
// Dimensions of arrays of Slater determinant jumps are calculated first, they are allocated, and then calculated.
// Time taken to do calculations can be also written, as they can be lengthy.

void SD_one_jump_construction_set_out_to_in::all_SDs_one_jump_all_SDs_alloc_calc (
										  const bool is_there_cout , 	
										  const bool is_it_one_body ,
										  const bool is_it_two_body_pn_only , 
										  const bool is_it_pole_approximation , 
										  class baryons_data &particles_data)
{
  const double time_1 = absolute_time_determine ();

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_one_jump_table = particles_data.get_dimensions_SD_one_jump_table_out_to_in ();

  class array_of_SD_one_jump_data_out_to_in &SD_one_jump_table = particles_data.get_SD_one_jump_table_out_to_in ();

  const enum particle_type nucleonic_particle = particles_data.get_nucleonic_particle ();
  
  const int strangeness_max = particles_data.get_hypernucleus_strangeness ();
  
  const int n_spec_max = particles_data.get_n_spec_max ();

  const int n_scat_max = (!is_it_pole_approximation) ? (particles_data.get_n_scat_max ()) : (0);

  const int iM_max = particles_data.get_iM_max ();

  const class array<unsigned int> &dimensions_configuration_set = particles_data.get_dimensions_configuration_set ();

  const unsigned long int dimension_SD_total = particles_data.get_dimension_SD_total ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = particles_data.get_dimensions_SD_set ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned long int> &sum_dimensions_SD_set = particles_data.get_sum_dimensions_SD_set ();

  dimensions_SD_one_jump_table.deallocate ();

  SD_one_jump_table.deallocate ();
  
  dimensions_SD_one_jump_table.allocate (dimension_SD_total , sum_dimensions_SD_set);

  all_SDs_one_jump_all_SDs (is_it_one_body , is_it_two_body_pn_only , DIMENSIONS_TABLES_CALC , is_it_pole_approximation , particles_data);

  const double time_2 = absolute_time_determine () , relative_time_dimension = time_2 - time_1;

  SD_one_jump_table.allocate (strangeness_max , n_spec_max , n_scat_max , dimensions_configuration_set , iM_max , dimension_SD_total , dimensions_SD_set , sum_dimensions_SD_set , dimensions_SD_one_jump_table);

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const double dimensions_SD_one_jump_table_used_memory = used_memory_calc (dimensions_SD_one_jump_table);
      
      const double SD_one_jump_table_used_memory = used_memory_calc (SD_one_jump_table);

      cout << endl << "SD jumps table " << nucleonic_particle << " space (on the fly)" << endl;
      cout << "dimensions: " << dimensions_SD_one_jump_table_used_memory << " Mb" << endl;
      cout << "array     : " << SD_one_jump_table_used_memory << " Mb" <<endl;
      cout << "time      : " << relative_time_dimension << " s" << endl << endl;      
    }

  all_SDs_one_jump_all_SDs (is_it_one_body , is_it_two_body_pn_only , TABLES_FILL , is_it_pole_approximation , particles_data);

  const double time_3 = absolute_time_determine () , relative_time = time_3 - time_2;

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << "SD jumps table " << nucleonic_particle << " space (on the fly) calculated. time:" << relative_time << " s" << endl << endl;
}


