#include "../GSM_include/GSM_include_def.h"


using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;
using namespace MPI_2D_partitioning;


// TYPE is double or complex
// -------------------------

// OpenMP is not used in all routines as one can have race conditions

// in_to_out means that one starts from |inSD> and one creates |outSD> from a+ a operations
// ----------------------------------------------------------------------------------------






// Checks if configurations or Slater determinants belong to the in or out space for the protons only, neutrons only or proton-neutron case 
// ----------------------------------------------------------------------------------------------------------------------------------------
// One loops over the configurations and Slater determinants and one considers only those respecting truncations, and parity, M quantum number conservation.
// One does not consider MPI here as one uses hybrid 1D/2D partitioning (see GSM_vector.cpp), where the Hamiltonian is divided in vertical stripes. 
// MPI indeed only distributes the in space of the Hamiltonian.
// One then checks if configurations or Slater determinants belong to the model space (pp/nn or pn case) after one jump a+(a) a(b).
// Associated booleans are stored in arrays.
// These arrays are especially important with MPI, as one uses only parts of the full GSM space on each node.
// One use time-reversal symmetry when dealing with jumps a+(a) a(b). 
// However, proton or neutron Slater determinants are considered to belong to the model space even if Mp, Mn < 0 (pn case only, as otherwise M[SD] is fixed) due to MPI.
// Indeed, |SD> and TRS|SD> do not have to belong to the same MPI node, and data would be missing if suppressing |SDp>, |SDn> because Mp, Mn < 0.
// Hence, one includes all |SD> and TRS|SD> in a node to avoid it.

void configuration_SD_in_space_one_jump_in_to_out::is_configuration_in_inSD_in_space_pp_nn_determine (
												      const class GSM_vector_helper_class &GSM_vector_helper_in , 
												      class nucleons_data &particles_data)
{
  const unsigned long int total_space_dimension_in = GSM_vector_helper_in.get_total_space_dimension ();

  if (total_space_dimension_in == 0) return;

  const bool truncation_hw = GSM_vector_helper_in.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_in.get_truncation_ph ();
  
  const class array<unsigned int> &dimensions_configuration_set = particles_data.get_dimensions_configuration_set ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = particles_data.get_dimensions_SD_set ();

  const class array_BP_Nscat_iC<int> &n_holes_table = particles_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &E_hw_table = particles_data.get_E_hw_table ();

  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = particles_data.get_SD_TRS_indices ();
  
  const unsigned int BP = GSM_vector_helper_in.get_BP ();

  const int iM = GSM_vector_helper_in.get_iM ();

  const int TRS_iM = GSM_vector_helper_in.get_TRS_iM ();
  
  const int n_holes_max = GSM_vector_helper_in.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_in.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_in.get_E_max_hw ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_in.get_sum_dimensions_GSM_vector ();
    
  const unsigned int first_total_PSI_in_index = GSM_vector_helper_in.get_first_total_PSI_index ();
  const unsigned int last_total_PSI_in_index = GSM_vector_helper_in.get_last_total_PSI_index ();
      
  class array_BP_Nscat_iC<bool> &is_configuration_in_in_space_tab = particles_data.get_is_configuration_in_in_space_tab (0);

  class array_BP_Nscat_iC_iM_SD<bool> &is_inSD_in_space_tab = particles_data.get_is_inSD_in_space_tab (0);
  
  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int dimension_C = dimensions_configuration_set(BP , n_scat);

      for (unsigned int iC = 0 ; iC < dimension_C ; iC++)
	{
	  const int n_holes = n_holes_table(BP , n_scat , iC);
	  
	  const int E = E_hw_table(BP , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD = dimensions_SD_set(BP , n_scat , iC , iM);

	  if (dimension_SD == 0) continue;

	  const unsigned int dimension_SD_minus_one = dimension_SD - 1;

	  const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions_GSM_vector(n_scat , iC);

	  const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_fixed;

	  const unsigned long int total_PSI_in_index_dimension_minus_one = sum_dimensions_configuration_fixed + dimension_SD_minus_one;

	  if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
	    { 
	      const unsigned long int SD_TRS_indices_zero_index = SD_TRS_indices.index_determine (BP , n_scat , iC , iM , 0);
	      
	      const unsigned long int is_inSD_in_space_tab_zero_index = is_inSD_in_space_tab.index_determine (BP , n_scat , iC , iM , 0);

	      const unsigned long int is_inSD_in_space_tab_TRS_zero_index = is_inSD_in_space_tab.index_determine (BP , n_scat , iC , TRS_iM , 0);
	      
	      is_configuration_in_in_space_tab(BP , n_scat , iC) = true;
	      	  
	      for (unsigned int SD_index = 0 ; SD_index < dimension_SD ; SD_index++)
		{
		  const unsigned long int total_PSI_in_index = sum_dimensions_configuration_fixed + SD_index;
		  
		  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
		    {
		      const unsigned long int is_inSD_in_space_tab_index = is_inSD_in_space_tab_zero_index + SD_index;
		      
		      is_inSD_in_space_tab[is_inSD_in_space_tab_index] = true;
			  
		      const unsigned long int SD_TRS_indices_index = SD_TRS_indices_zero_index + SD_index;

		      const unsigned int SD_TRS_index = SD_TRS_indices[SD_TRS_indices_index];

		      const unsigned long int is_inSD_in_space_tab_TRS_index = is_inSD_in_space_tab_TRS_zero_index + SD_TRS_index;
			  
		      is_inSD_in_space_tab[is_inSD_in_space_tab_TRS_index] = true;	
		    }}}}}
}

void configuration_SD_in_space_one_jump_in_to_out::is_configuration_out_outSD_BPout_iMout_in_space_pp_nn_determine (
														    const class GSM_vector_helper_class &GSM_vector_helper_out , 
														    class nucleons_data &particles_data)
{
  const unsigned long int total_space_dimension_out = GSM_vector_helper_out.get_total_space_dimension ();

  if (total_space_dimension_out == 0) return;

  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const class array<unsigned int> &dimensions_configuration_set = particles_data.get_dimensions_configuration_set ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = particles_data.get_dimensions_SD_set ();

  const class array_BP_Nscat_iC<int> &n_holes_table = particles_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &E_hw_table = particles_data.get_E_hw_table ();

  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = particles_data.get_SD_TRS_indices ();
  
  class array<bool> &BPout_for_one_jump_tab = particles_data.get_BPout_for_one_jump_tab ();

  class array<bool> &BPout_iMout_for_one_jump_tab = particles_data.get_BPout_iMout_for_one_jump_tab ();
  
  const unsigned int BP = GSM_vector_helper_out.get_BP ();

  const int iM = GSM_vector_helper_out.get_iM ();

  const int TRS_iM = GSM_vector_helper_out.get_TRS_iM ();
  
  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw ();
  
  class array_BP_Nscat_iC<bool> &is_configuration_out_in_space_tab = particles_data.get_is_configuration_out_in_space_tab ();

  class array_BP_Nscat_iC_iM_SD<bool> &is_outSD_in_space_tab = particles_data.get_is_outSD_in_space_tab ();
    
  BPout_for_one_jump_tab(BP) = true;

  BPout_iMout_for_one_jump_tab(BP , iM) = true;  
  
  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int dimension_C = dimensions_configuration_set(BP , n_scat);

      for (unsigned int iC = 0 ; iC < dimension_C ; iC++)
	{
	  const int n_holes = n_holes_table(BP , n_scat , iC);
	  
	  const int E = E_hw_table(BP , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD = dimensions_SD_set(BP , n_scat , iC , iM);

	  if (dimension_SD == 0) continue;

	  const unsigned long int SD_TRS_indices_zero_index = SD_TRS_indices.index_determine (BP , n_scat , iC , iM , 0);
	      
	  const unsigned long int is_outSD_in_space_tab_zero_index = is_outSD_in_space_tab.index_determine (BP , n_scat , iC , iM , 0);

	  const unsigned long int is_outSD_in_space_tab_TRS_zero_index = is_outSD_in_space_tab.index_determine (BP , n_scat , iC , TRS_iM , 0);
	      
	  is_configuration_out_in_space_tab(BP , n_scat , iC) = true;
	      	      
	  for (unsigned int SD_index = 0 ; SD_index < dimension_SD ; SD_index++)
	    {
	      const unsigned long int is_outSD_in_space_tab_index = is_outSD_in_space_tab_zero_index + SD_index;
		      
	      is_outSD_in_space_tab[is_outSD_in_space_tab_index] = true;
			  
	      const unsigned long int SD_TRS_indices_index = SD_TRS_indices_zero_index + SD_index;

	      const unsigned int SD_TRS_index = SD_TRS_indices[SD_TRS_indices_index];

	      const unsigned long int is_outSD_in_space_tab_TRS_index = is_outSD_in_space_tab_TRS_zero_index + SD_TRS_index;
			  
	      is_outSD_in_space_tab[is_outSD_in_space_tab_TRS_index] = true;
	    }
	}
    }
}

void configuration_SD_in_space_one_jump_in_to_out::is_configuration_in_inSD_in_space_pn_determine (
												   const class GSM_vector_helper_class &GSM_vector_helper_in , 
												   class nucleons_data &prot_data , 
												   class nucleons_data &neut_data)
{
  const unsigned long int total_space_dimension_in = GSM_vector_helper_in.get_total_space_dimension ();

  if (total_space_dimension_in == 0) return;
  
  const class array<unsigned int> &dimensions_configuration_set_p = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_set_n = neut_data.get_dimensions_configuration_set ();
  
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_data.get_SD_TRS_indices ();
  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_data.get_SD_TRS_indices ();
  
  const unsigned int BP = GSM_vector_helper_in.get_BP ();

  const int iM = GSM_vector_helper_in.get_iM ();
  
  const int iMp_max = prot_data.get_iM_max ();
  const int iMn_max = neut_data.get_iM_max ();
    
  const int iMp_min_M = GSM_vector_helper_in.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper_in.get_iMp_max_M ();
  
  const int n_holes_max_p = GSM_vector_helper_in.get_n_holes_max_p ();
  
  const int n_scat_max_p = GSM_vector_helper_in.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_in.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_in.get_Ep_max_hw ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_in.get_sum_dimensions_GSM_vector ();
  
  const bool truncation_hw = GSM_vector_helper_in.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_in.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_in.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_in.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_in.get_E_max_hw ();
  
  const unsigned int first_total_PSI_in_index = GSM_vector_helper_in.get_first_total_PSI_index ();
  const unsigned int last_total_PSI_in_index = GSM_vector_helper_in.get_last_total_PSI_index ();
  
  class array_BP_Nscat_iC<bool> &is_prot_configuration_in_in_space_tab = prot_data.get_is_configuration_in_in_space_tab (0);
  class array_BP_Nscat_iC<bool> &is_neut_configuration_in_in_space_tab = neut_data.get_is_configuration_in_in_space_tab (0);
  
  class array_BP_Nscat_iC_iM_SD<bool> &is_inSDp_in_space_tab = prot_data.get_is_inSD_in_space_tab (0);
  class array_BP_Nscat_iC_iM_SD<bool> &is_inSDn_in_space_tab = neut_data.get_is_inSD_in_space_tab (0);
    
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP); 

      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int dimension_Cp = dimensions_configuration_set_p(BPp , n_scat_p);

	  for (unsigned int iCp = 0 ; iCp < dimension_Cp ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

	      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

	      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
		{
		  const unsigned int dimension_Cn = dimensions_configuration_set_n(BPn , n_scat_n);

		  for (unsigned int iCn = 0 ; iCn < dimension_Cn ; iCn++)
		    {
		      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
		      const int En = En_hw_table(BPn , n_scat_n , iCn);
		      
		      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw))
			{	      
			  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
			    {			
			      const int iMn = iM - iMp;

			      const int TRS_iMp = iMp_max - iMp;
			      const int TRS_iMn = iMn_max - iMn;
	      
			      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);
			      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);
			      
			      if ((dimension_SDn == 0) || (dimension_SDp == 0)) continue;

			      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , n_scat_p , n_scat_n , iCp , iCn , iMp);

			      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1 , dimension_SDn_minus_one = dimension_SDn - 1;
			      
			      const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed;
			      
			      const unsigned long int total_PSI_in_index_dimension_minus_one = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*dimension_SDp_minus_one + dimension_SDn_minus_one;

			      if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
				{
				  const unsigned long int SDp_TRS_indices_zero_index = SDp_TRS_indices.index_determine (BPp , n_scat_p , iCp , iMp , 0);
				  const unsigned long int SDn_TRS_indices_zero_index = SDn_TRS_indices.index_determine (BPn , n_scat_n , iCn , iMn , 0);
	      
				  const unsigned long int is_inSDp_in_space_tab_zero_index = is_inSDp_in_space_tab.index_determine (BPp , n_scat_p , iCp , iMp , 0);
				  const unsigned long int is_inSDn_in_space_tab_zero_index = is_inSDn_in_space_tab.index_determine (BPn , n_scat_n , iCn , iMn , 0);
				  
				  const unsigned long int is_inSDp_in_space_tab_TRS_zero_index = is_inSDp_in_space_tab.index_determine (BPp , n_scat_p , iCp , TRS_iMp , 0);
				  const unsigned long int is_inSDn_in_space_tab_TRS_zero_index = is_inSDn_in_space_tab.index_determine (BPn , n_scat_n , iCn , TRS_iMn , 0);
				  
				  is_prot_configuration_in_in_space_tab(BPp , n_scat_p , iCp) = true;
				  is_neut_configuration_in_in_space_tab(BPn , n_scat_n , iCn) = true;
				  			      
				  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
				    {
				      const unsigned long int total_PSI_in_index_zero_SDp_fixed = total_PSI_in_index_zero + SDp_index*dimension_SDn;

				      const unsigned long int total_PSI_in_index_dimension_minus_one_SDp_fixed = total_PSI_in_index_zero_SDp_fixed + dimension_SDn_minus_one;

				      if ((total_PSI_in_index_zero_SDp_fixed <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one_SDp_fixed >= first_total_PSI_in_index))
					{
					  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
					    {
					      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_SDp_fixed + SDn_index;
						    
					      if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						{
						  const unsigned long int is_inSDp_in_space_tab_index = is_inSDp_in_space_tab_zero_index + SDp_index;
						  const unsigned long int is_inSDn_in_space_tab_index = is_inSDn_in_space_tab_zero_index + SDn_index;
						  
						  is_inSDp_in_space_tab[is_inSDp_in_space_tab_index] = true;
						  is_inSDn_in_space_tab[is_inSDn_in_space_tab_index] = true;
						  
						  const unsigned long int SDp_TRS_indices_index = SDp_TRS_indices_zero_index + SDp_index;
						  const unsigned long int SDn_TRS_indices_index = SDn_TRS_indices_zero_index + SDn_index;
						  
						  const unsigned int SDp_TRS_index = SDp_TRS_indices[SDp_TRS_indices_index];
						  const unsigned int SDn_TRS_index = SDn_TRS_indices[SDn_TRS_indices_index];
						  
						  const unsigned long int is_inSDp_in_space_tab_TRS_index = is_inSDp_in_space_tab_TRS_zero_index + SDp_TRS_index;
						  const unsigned long int is_inSDn_in_space_tab_TRS_index = is_inSDn_in_space_tab_TRS_zero_index + SDn_TRS_index;
		      
						  is_inSDp_in_space_tab[is_inSDp_in_space_tab_TRS_index] = true;
						  is_inSDn_in_space_tab[is_inSDn_in_space_tab_TRS_index] = true;
						}}}}}}}}}}}}
}

void configuration_SD_in_space_one_jump_in_to_out::is_configuration_out_outSD_BPout_iMout_in_space_pn_determine (
														 const class GSM_vector_helper_class &GSM_vector_helper_out , 
														 class nucleons_data &prot_data , 
														 class nucleons_data &neut_data)
{
  const unsigned long int total_space_dimension_out = GSM_vector_helper_out.get_total_space_dimension ();

  if (total_space_dimension_out == 0) return;

  const class array<unsigned int> &dimensions_configuration_set_p = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_set_n = neut_data.get_dimensions_configuration_set ();
  
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_data.get_SD_TRS_indices ();
  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_data.get_SD_TRS_indices ();
      
  const unsigned int BP = GSM_vector_helper_out.get_BP ();

  const int iM = GSM_vector_helper_out.get_iM ();
  
  const int iMp_max = prot_data.get_iM_max ();
  const int iMn_max = neut_data.get_iM_max ();
    
  const int iMp_min_M = GSM_vector_helper_out.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper_out.get_iMp_max_M ();
  
  const int n_holes_max_p = GSM_vector_helper_out.get_n_holes_max_p ();
  
  const int n_scat_max_p = GSM_vector_helper_out.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_out.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_out.get_Ep_max_hw ();
  
  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw ();
  
  class array<bool> &prot_BPout_for_one_jump_tab = prot_data.get_BPout_for_one_jump_tab ();
  class array<bool> &neut_BPout_for_one_jump_tab = neut_data.get_BPout_for_one_jump_tab ();

  class array<bool> &prot_BPout_iMout_for_one_jump_tab = prot_data.get_BPout_iMout_for_one_jump_tab ();
  class array<bool> &neut_BPout_iMout_for_one_jump_tab = neut_data.get_BPout_iMout_for_one_jump_tab ();
  
  class array_BP_Nscat_iC<bool> &is_prot_configuration_out_in_space_tab = prot_data.get_is_configuration_out_in_space_tab ();
  class array_BP_Nscat_iC<bool> &is_neut_configuration_out_in_space_tab = neut_data.get_is_configuration_out_in_space_tab ();
  
  class array_BP_Nscat_iC_iM_SD<bool> &is_outSDp_in_space_tab = prot_data.get_is_outSD_in_space_tab ();
  class array_BP_Nscat_iC_iM_SD<bool> &is_outSDn_in_space_tab = neut_data.get_is_outSD_in_space_tab ();
    
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP); 

      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int dimension_Cp = dimensions_configuration_set_p(BPp , n_scat_p);

	  for (unsigned int iCp = 0 ; iCp < dimension_Cp ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

	      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

	      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
		{
		  const unsigned int dimension_Cn = dimensions_configuration_set_n(BPn , n_scat_n);

		  for (unsigned int iCn = 0 ; iCn < dimension_Cn ; iCn++)
		    {
		      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
		      const int En = En_hw_table(BPn , n_scat_n , iCn);
		      
		      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw))
			{	      
			  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
			    {			
			      const int iMn = iM - iMp;

			      const int TRS_iMp = iMp_max - iMp;
			      const int TRS_iMn = iMn_max - iMn;

			      const int two_iMp = 2*iMp;
			      const int two_iMn = 2*iMn;
	      
			      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);
			      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);
			      
			      if ((dimension_SDn == 0) || (dimension_SDp == 0)) continue;

			      const unsigned long int SDp_TRS_indices_zero_index = SDp_TRS_indices.index_determine (BPp , n_scat_p , iCp , iMp , 0);
			      const unsigned long int SDn_TRS_indices_zero_index = SDn_TRS_indices.index_determine (BPn , n_scat_n , iCn , iMn , 0);
	      
			      const unsigned long int is_outSDp_in_space_tab_zero_index = is_outSDp_in_space_tab.index_determine (BPp , n_scat_p , iCp , iMp , 0);
			      const unsigned long int is_outSDn_in_space_tab_zero_index = is_outSDn_in_space_tab.index_determine (BPn , n_scat_n , iCn , iMn , 0);
				  
			      const unsigned long int is_outSDp_in_space_tab_TRS_zero_index = is_outSDp_in_space_tab.index_determine (BPp , n_scat_p , iCp , TRS_iMp , 0);
			      const unsigned long int is_outSDn_in_space_tab_TRS_zero_index = is_outSDn_in_space_tab.index_determine (BPn , n_scat_n , iCn , TRS_iMn , 0);
				  
			      is_prot_configuration_out_in_space_tab(BPp , n_scat_p , iCp) = true;
			      is_neut_configuration_out_in_space_tab(BPn , n_scat_n , iCn) = true;

			      prot_BPout_for_one_jump_tab(BPp) = true;
			      neut_BPout_for_one_jump_tab(BPn) = true;
			      
			      (two_iMp >= iMp_max) ? (prot_BPout_iMout_for_one_jump_tab(BPp , iMp) = true) : (prot_BPout_iMout_for_one_jump_tab(BPp , TRS_iMp) = true);				    
			      (two_iMn >= iMn_max) ? (neut_BPout_iMout_for_one_jump_tab(BPn , iMn) = true) : (neut_BPout_iMout_for_one_jump_tab(BPn , TRS_iMn) = true);
				  
			      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
				{
				  const unsigned long int is_outSDp_in_space_tab_index = is_outSDp_in_space_tab_zero_index + SDp_index;
						  
				  is_outSDp_in_space_tab[is_outSDp_in_space_tab_index] = true;
				    
				  const unsigned long int SDp_TRS_indices_index = SDp_TRS_indices_zero_index + SDp_index;
				  
				  const unsigned int SDp_TRS_index = SDp_TRS_indices[SDp_TRS_indices_index];
				  
				  const unsigned long int is_outSDp_in_space_tab_TRS_index = is_outSDp_in_space_tab_TRS_zero_index + SDp_TRS_index;
		      
				  is_outSDp_in_space_tab[is_outSDp_in_space_tab_TRS_index] = true;
				}
			      
			      for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
				{
				  const unsigned long int is_outSDn_in_space_tab_index = is_outSDn_in_space_tab_zero_index + SDn_index;
						  
				  is_outSDn_in_space_tab[is_outSDn_in_space_tab_index] = true;
						  
				  const unsigned long int SDn_TRS_indices_index = SDn_TRS_indices_zero_index + SDn_index;
				  
				  const unsigned int SDn_TRS_index = SDn_TRS_indices[SDn_TRS_indices_index];

				  const unsigned long int is_outSDn_in_space_tab_TRS_index = is_outSDn_in_space_tab_TRS_zero_index + SDn_TRS_index;
		      
				  is_outSDn_in_space_tab[is_outSDn_in_space_tab_TRS_index] = true;
				  
				}}}}}}}}
}



















// Checks if configurations or Slater determinants belong to the intermediate space for the protons only, neutrons only or proton-neutron case 
// -------------------------------------------------------------------------------------------------------------------------------------------
//
// H or J+/J- is written in second quantization: H = \sum_ab <a | H | b> a+(a) a(b) + \sum_abcd <ab | H | cd> a+(a) a+(b) a(d) a(c), and J+/J- = \sum_ab <a | J+/J- | b> a+(a) a(b).
// Hence, in order to apply Op to a GSM vector vector, one has to calculate jumps of the form <outSD | a+(a) a(b) | inSD> and <outSD | a+(a) a+(b) a(d) a(c) | inSD>.

// The pp, nn two-body jumps are written as <outSD | a+(a) a+(b) a(d) a(c) | inSD> = <outSD | a+(a) a(c) | SDinter> <SDinter | a+(b) a(d) | inSD>, with |SDinter> an intermediate Slater determinant.
// The pn two-body jumps <outSD | a+(a) a+(b) a(d) a(c) | inSD> are equal to  <outSDp | a+(a) a(c) | inSDp>  <outSDn | a+(b) a(d) | inSDn>, so that no intermediate Slater determinant is needed here.
// Hence, all jumps can be calculated from those of the form <outSD | a+(a) a(b) | inSD>. 
// 
// In order not to consider intermediate Slater determinants with many particles in the continuum, one demands all Slater determinants to have a number particles in the continuum smaller or equal
// to that of the model space. This is possible as can always reshuffle the a+/a operators above for |SDinter> to be in that situation.
//
// The many-operators associated to this namespace are H and J+/J- used iwth full storage.
// One uses hybrid 1D/2D partitioning for GSM vectors and operators, so that input and output GSM vectors are scattered over all nodes, but H or J+/J- are stored ina 1D fashion:
//
//     H or J+/J-           x  Psi[in]  =  Psi[out]
// 
// *     *     *    *    *       *           *
// *     *     *    *    *     node 0      node 0 (from reduction over all nodes)
// *  n  *  n  *  n *  n *       *           *
// *  o  *  o  *  o *  o *     node 1      node 1 (from reduction over all nodes)
// *  d  *  d  *  d *  d *       *           *
// *  e  *  e  *  e *  e *     node 2      node 2 (from reduction over all nodes)
// *     *     *    *    *       *           *
// *  0  *  1  *  2 *  3 *     node 3      node 3 (from reduction over all nodes)
// *     *     *    *    *       *           *
//
// One then checks if configurations belong to the intermediate space after one jump a+(a) a(b) on a configuration which does not belong to the in space only because of truncations.
// If one arrives in the out space with one of these jumps, it means that the initial configuration belongs to the intermediate space and one can check for the next configuration. 
// Otherwise, it does not belong to the intermediate space.
//
// To check if Slater determinants belong to the intermediate space, one also applies one jump a+(a) a(b) on a Slater determinant which does not belong to the out space only because of truncations.
// One loops over intermediate and in configurations, which have been found in the previous step. 
// One also loops over M_jump = m_out - m_in, which fixes m_in, m_out and M_intermediate as M_in is already fixed. 
// As configurations are fixed, the obtained Slater determinant belongs to the intermediate space if the out state, defined by a+(a) and m_out, is not occupied in the in Slater determinant.
// Otherwise, it does not belong to the intermediate space.
//
// Associated booleans are stored in arrays.

void configuration_SD_in_space_one_jump_in_to_out::is_it_configuration_inter_to_include_determine_all_configuration (
														     const bool is_it_pole_approximation , 
														     class nucleons_data &particles_data)
{ 
  const int n_scat_max = (is_it_pole_approximation) ? (0) : (particles_data.get_n_scat_max ());

  const class array<unsigned int> &dimensions_configuration_set = particles_data.get_dimensions_configuration_set ();

  const class array_BP_Nscat_iC<bool> &is_configuration_in_in_space_tab = particles_data.get_is_configuration_in_in_space_tab (0);

  const class array_BP_Nscat_iC<unsigned int> &dimensions_configuration_one_jump_table = particles_data.get_dimensions_configuration_one_jump_table_in_to_out ();

  const class array_of_configuration_one_jump_data_in_to_out &configuration_one_jump_table = particles_data.get_configuration_one_jump_table_in_to_out ();

  class array_BP_Nscat_iC<bool> &is_it_configuration_inter_to_include_tab = particles_data.get_is_it_configuration_inter_to_include_tab ();
  
  for (unsigned int BP_in = 0 ; BP_in <= 1 ; BP_in++)
    for (int n_scat_in = 0 ; n_scat_in <= n_scat_max ; n_scat_in++)
      {
	const unsigned int dimension_C_in = dimensions_configuration_set(BP_in , n_scat_in);
	
	const unsigned int is_configuration_in_in_space_zero_index = is_configuration_in_in_space_tab.index_determine (BP_in , n_scat_in , 0);

	const unsigned int is_it_configuration_inter_to_include_tab_zero_index = is_it_configuration_inter_to_include_tab.index_determine (BP_in , n_scat_in , 0);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
	for (unsigned int iC_in = 0 ; iC_in < dimension_C_in ; iC_in++)
	  {	
	    const unsigned int is_configuration_in_in_space_iC_in_index = is_configuration_in_in_space_zero_index + iC_in;

	    const unsigned int is_it_configuration_inter_to_include_iC_in_index = is_it_configuration_inter_to_include_tab_zero_index + iC_in;

	    const bool is_configuration_in_in_space = is_configuration_in_in_space_tab[is_configuration_in_in_space_iC_in_index];
	    
	    if (!is_configuration_in_in_space)
	      {
		bool &is_it_configuration_inter_to_include = is_it_configuration_inter_to_include_tab[is_it_configuration_inter_to_include_iC_in_index];

		const unsigned int dimensions_configuration_one_jump_zero_index = dimensions_configuration_one_jump_table.index_determine (BP_in , n_scat_in , iC_in , 0);

		for (unsigned int BP_out = 0 ; (BP_out <= 1) && (!is_it_configuration_inter_to_include) ; BP_out++)
		  {
		    const unsigned int dimensions_configuration_one_jump_index = dimensions_configuration_one_jump_zero_index + BP_out;

		    const unsigned int dimensions_configuration_one_jump_table_C_in = dimensions_configuration_one_jump_table[dimensions_configuration_one_jump_index];

		    const unsigned int configuration_one_jump_table_zero_index = configuration_one_jump_table.index_determine (BP_in , n_scat_in , iC_in , BP_out , 0);

		    for (unsigned int C_one_jump_index = 0 ; C_one_jump_index < (dimensions_configuration_one_jump_table_C_in) && (!is_it_configuration_inter_to_include) ; C_one_jump_index++)
		      {	
			const unsigned int C_one_jump_table_index = configuration_one_jump_table_zero_index + C_one_jump_index;

			const class configuration_one_jump_data_in_to_out_str &C_one_jump_data_in = configuration_one_jump_table[C_one_jump_table_index];

			const unsigned int iC_out = C_one_jump_data_in.get_iC_out ();

			const int n_scat_out = C_one_jump_data_in.get_n_scat_out ();

			const bool is_configuration_out_in_space = is_configuration_in_in_space_tab(BP_out , n_scat_out , iC_out);
			
			if (is_configuration_out_in_space) is_it_configuration_inter_to_include = true;      
		      }}}}}
}

bool configuration_SD_in_space_one_jump_in_to_out::is_it_SD_inter_to_include_fixed_configuration_in_determine (
													       const class configuration &C_in , 
													       const class Slater_determinant &inSD ,
													       const int M_jump , 
													       const unsigned int C_in_jump_shell , 
													       const unsigned int C_out_jump_shell , 
													       class nucleons_data &particles_data)
{ 
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();

  const int m_max_minus_half = particles_data.get_m_max_minus_half ();

  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();

  const class one_body_indices_str &one_body_indices = particles_data.get_one_body_indices ();

  const class nlj_struct &shell_qn_out = shells_qn(C_out_jump_shell);

  const int ij_out = shell_qn_out.get_ij ();

  const int im_out_min = -ij_out + m_max_minus_half;
  const int im_out_max =  ij_out + m_max_minus_half + 1;

  const bool shell_in_in_C_in = C_in.is_shell_occupied (C_in_jump_shell);			

  for (int i = 0 ; i < N_valence_nucleons ; i++)
    {
      const unsigned int shell_in_index = C_in[i];
      
      if (shell_in_index == C_in_jump_shell)
	{
	  const unsigned int in_jump = inSD[i];

	  const class nljm_struct &phi_in_jump = phi_table(in_jump);
	  
	  const int im_in = phi_in_jump.get_im ();

	  const int im_out = im_in + M_jump;
	  
	  if ((im_out >= im_out_min) && (im_out <= im_out_max))
	    {   
	      const unsigned int out_jump = one_body_indices(C_out_jump_shell , im_out);

	      const bool is_out_jump_occupied_in_inSD = (shell_in_in_C_in && inSD.is_valence_state_occupied (out_jump));

	      if (!is_out_jump_occupied_in_inSD) return true;
	    }
	}
    }

  return false;
}

void configuration_SD_in_space_one_jump_in_to_out::is_it_SD_inter_to_include_determine_all_SDs (
												const bool is_it_pole_approximation , 
												class nucleons_data &particles_data)
{ 
  const int n_scat_max = (is_it_pole_approximation) ? (0) : (particles_data.get_n_scat_max ());

  const int iM_max = particles_data.get_iM_max ();
  
  const int two_m_max = particles_data.get_two_m_max ();

  const int four_m_max = particles_data.get_four_m_max ();

  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();
  
  const unsigned long int dimension_SD_total = particles_data.get_dimension_SD_total ();

  const class array_of_configuration &configuration_set = particles_data.get_configuration_set ();
    
  const class array_of_SD &SD_set = particles_data.get_SD_set ();
  
  const class array_BP_Nscat_iC_iM_SD<bool> &is_inSD_in_space_tab = particles_data.get_is_inSD_in_space_tab (0);

  const class array_BP_Nscat_iC<unsigned int> &dimensions_configuration_one_jump_table = particles_data.get_dimensions_configuration_one_jump_table_in_to_out ();
  
  const class array_of_configuration_one_jump_data_in_to_out &configuration_one_jump_table = particles_data.get_configuration_one_jump_table_in_to_out ();
 
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = particles_data.get_SD_quantum_numbers_tab ();

  class array_BP_Nscat_iC_iM_SD<bool> &is_it_SD_inter_to_include_tab = particles_data.get_is_it_SD_inter_to_include_tab ();

  class array<class configuration> C_in_tab(NUMBER_OF_THREADS);
  
  class array<class Slater_determinant> inSD_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      C_in_tab(i).allocate (N_valence_nucleons);     

      inSD_tab(i).allocate (N_valence_nucleons);
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_inSD_index = 0 ; total_inSD_index < dimension_SD_total ; total_inSD_index++)
    {
      const class SD_quantum_numbers &inSD_qn = SD_quantum_numbers_tab(total_inSD_index);
      
      const unsigned int BP_in = inSD_qn.get_BP ();      

      const int n_scat_in = inSD_qn.get_n_scat ();

      if (n_scat_in > n_scat_max ) continue;
      
      const unsigned int iC_in = inSD_qn.get_iC ();

      const int iM_in = inSD_qn.get_iM ();

      const unsigned int inSD_index = inSD_qn.get_SD_index ();

      const bool is_inSD_in_space = is_inSD_in_space_tab(BP_in , n_scat_in , iC_in , iM_in , inSD_index);

      if (!is_inSD_in_space)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();

	  class configuration &C_in = C_in_tab(i_thread);

	  class Slater_determinant &inSD = inSD_tab(i_thread);
	  
	  bool &is_it_SD_inter_to_include = is_it_SD_inter_to_include_tab(BP_in , n_scat_in , iC_in , iM_in , inSD_index);
	  
	  C_in = configuration_set(BP_in , n_scat_in , iC_in);
	  
	  inSD = SD_set(BP_in , n_scat_in , iC_in , iM_in , inSD_index);
	  
	  for (int Delta_iM_out = 0 ; (Delta_iM_out <= four_m_max) && (!is_it_SD_inter_to_include) ; Delta_iM_out++)
	    {	      
	      const int M_jump = Delta_iM_out - two_m_max , iM_out = iM_in + M_jump , two_iM_out = 2*iM_out;
	      
	      if ((two_iM_out >= iM_max) && (iM_out <= iM_max))
		{			  
		  for (unsigned int BP_out = 0 ; (BP_out <= 1) && (!is_it_SD_inter_to_include) ; BP_out++)
		    {
		      const unsigned int dimensions_configuration_one_jump_table_C_in = dimensions_configuration_one_jump_table(BP_in , n_scat_in , iC_in , BP_out);

		      const unsigned int configuration_one_jump_table_zero_index = configuration_one_jump_table.index_determine (BP_in , n_scat_in , iC_in , BP_out , 0);
		      
		      unsigned int C_eq_one_jump_index_bef = dimensions_configuration_one_jump_table_C_in;
		      
		      for (unsigned int C_one_jump_index = 0 ; (C_one_jump_index < dimensions_configuration_one_jump_table_C_in) && (!is_it_SD_inter_to_include) ; C_one_jump_index++)
			{	
			  const unsigned int C_one_jump_table_index = configuration_one_jump_table_zero_index + C_one_jump_index;

			  const class configuration_one_jump_data_in_to_out_str &C_one_jump_data_out = configuration_one_jump_table[C_one_jump_table_index];
			  
			  const unsigned int C_eq_one_jump_index = C_one_jump_data_out.get_C_eq_one_jump_index ();
			  
			  if ((C_one_jump_index == 0) || (C_eq_one_jump_index != C_eq_one_jump_index_bef))
			    {
			      const unsigned int C_in_jump_shell  = C_one_jump_data_out.get_C_in_shell ();
			      const unsigned int C_out_jump_shell = C_one_jump_data_out.get_C_out_shell ();
			      
			      const bool is_it_SD_inter_to_include_fixed_configuration_in = is_it_SD_inter_to_include_fixed_configuration_in_determine (C_in , inSD , M_jump , C_in_jump_shell , C_out_jump_shell , particles_data);
			      
			      if (is_it_SD_inter_to_include_fixed_configuration_in) is_it_SD_inter_to_include = true;
			    }
			  
			  C_eq_one_jump_index_bef = C_eq_one_jump_index;
			}}}}}}
}

















// Calculations of all booleans checking if configurations or Slater determinants belong to the in or out space for the protons only, neutrons only or proton-neutron case 
// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Routines above are called according to the case.
//
// Intermediate space routines are not called for one-body and T^2 operators, as they are of 1p-1h nature inside proton or neutron space, so that there is no intermediate therein.
//
// If L^2[CM] or J^2 operators are considered, one has M -> M+1 or M -> M-1 as L^2[CM] = L^-[CM].L^+[CM] + Lz[CM].(Lz[CM] + 1) or J^2 = J-.J+ + Jz.(Jz + 1).
// The M -> M-1 is not considered as it symmetric to M-1 -> M, included in M -> M+1 as one sum over all M values.
//
// M is the current angular momentum projection.
// If is_L2_CM_J2_applied is true , GSM_vector_helper_in and GSM_vector_helper_out must be equal. Test is made for M and parity only.
// One must have GSM_vector_helper_in.M = GSM_vector_helper_out.M = M and GSM_vector_helper_Mp1.M = M+1.
// It is compatible with all two-body operators having GSM_vector_helper_in(out).M equal to M , such as H.
// If not, GSM_vector_helper_Mp1 is not used and can be arbitrary.

void configuration_SD_in_space_one_jump_in_to_out::one_jump_tables_alloc_calc_pp_nn (
										     const bool is_there_cout , 
										     const bool is_it_one_body ,
										     const bool is_it_two_body_pn_only , 
										     const bool is_it_pole_approximation , 
										     const bool is_J2_applied ,
										     const bool truncation_hw , 
										     const bool truncation_ph ,  
										     class nucleons_data &particles_data)
{
  if (is_J2_applied) SD_one_jump_construction_set_in_to_out::all_SDs_one_jump_all_SDs_alloc_calc_Jpm (is_there_cout , is_it_pole_approximation , true , NADA , particles_data);
  
  const bool is_it_one_body_T2_only = (is_it_one_body || is_it_two_body_pn_only);

  configuration_one_jump_construction_set_in_to_out::all_configurations_one_jump_all_configurations_alloc_calc (is_there_cout , false , is_it_one_body_T2_only , truncation_hw , truncation_ph , is_it_pole_approximation , particles_data);
  
  if (!is_it_one_body_T2_only) 
    {
      is_it_configuration_inter_to_include_determine_all_configuration (is_it_pole_approximation , particles_data);

      is_it_SD_inter_to_include_determine_all_SDs (is_it_pole_approximation , particles_data);
    }

  SD_one_jump_construction_set_in_to_out::all_SDs_one_jump_all_SDs_alloc_calc (is_there_cout , is_it_one_body , is_it_two_body_pn_only , is_it_pole_approximation , particles_data);
}

void configuration_SD_in_space_one_jump_in_to_out::configuration_SD_in_space_determine (
											const bool is_L2_CM_J2_applied , 
											const class GSM_vector_helper_class &GSM_vector_helper_in , 
											const class GSM_vector_helper_class &GSM_vector_helper_Mp1 , 
											class nucleons_data &prot_data , 
											class nucleons_data &neut_data)
{
  const enum space_type space = GSM_vector_helper_in.get_space ();
  
  if (space != NEUTRONS_ONLY) prot_data.configuration_SD_in_in_space_BPin_iMin_tables_init (false);
  if (space != PROTONS_ONLY)  neut_data.configuration_SD_in_in_space_BPin_iMin_tables_init (false);

  if (is_L2_CM_J2_applied)
    {
      const class GSM_vector_helper_class &GSM_vector_helper_M = GSM_vector_helper_in;

      switch (space)
	{
	case PROTONS_ONLY:
	  {
	    is_configuration_in_inSD_in_space_pp_nn_determine (GSM_vector_helper_M   , prot_data);
	    is_configuration_in_inSD_in_space_pp_nn_determine (GSM_vector_helper_Mp1 , prot_data);
	  } break;

	case NEUTRONS_ONLY:	
	  {
	    is_configuration_in_inSD_in_space_pp_nn_determine (GSM_vector_helper_M   , neut_data);
	    is_configuration_in_inSD_in_space_pp_nn_determine (GSM_vector_helper_Mp1 , neut_data);
	  } break;

	case PROTONS_NEUTRONS:
	  {
	    is_configuration_in_inSD_in_space_pn_determine (GSM_vector_helper_M   , prot_data , neut_data);
	    is_configuration_in_inSD_in_space_pn_determine (GSM_vector_helper_Mp1 , prot_data , neut_data);
	  } break;

	default: abort_all ();
	}
    }
  else
    {
      switch (space)
	{
	case PROTONS_ONLY:
	  {
	    is_configuration_in_inSD_in_space_pp_nn_determine (GSM_vector_helper_in , prot_data);
	  } break;

	case NEUTRONS_ONLY:	
	  {
	    is_configuration_in_inSD_in_space_pp_nn_determine (GSM_vector_helper_in , neut_data);
	  } break;

	case PROTONS_NEUTRONS:
	  {
	    is_configuration_in_inSD_in_space_pn_determine (GSM_vector_helper_in , prot_data , neut_data);
	  } break;

	default: abort_all ();
	}
    }
}

void configuration_SD_in_space_one_jump_in_to_out::configuration_SD_out_space_determine (
											 const bool is_L2_CM_J2_applied ,  
											 const class GSM_vector_helper_class &GSM_vector_helper_out , 
											 const class GSM_vector_helper_class &GSM_vector_helper_Mp1 , 
											 class nucleons_data &prot_data , 
											 class nucleons_data &neut_data)
{
  const enum space_type space = GSM_vector_helper_out.get_space ();
    
  if (space != NEUTRONS_ONLY)
    {
      prot_data.configuration_SD_out_in_space_BPout_iMout_tables_init (false);

      prot_data.configuration_SD_inter_to_include_tables_init (false);
    }

  if (space != PROTONS_ONLY)
    {
      neut_data.configuration_SD_out_in_space_BPout_iMout_tables_init (false);

      neut_data.configuration_SD_inter_to_include_tables_init (false);
    }
  
  if (is_L2_CM_J2_applied)
    {
      const class GSM_vector_helper_class &GSM_vector_helper_M = GSM_vector_helper_out;

      switch (space)
	{
	case PROTONS_ONLY:
	  {
	    is_configuration_out_outSD_BPout_iMout_in_space_pp_nn_determine (GSM_vector_helper_M   , prot_data);
	    is_configuration_out_outSD_BPout_iMout_in_space_pp_nn_determine (GSM_vector_helper_Mp1 , prot_data);
	  } break;

	case NEUTRONS_ONLY:	
	  {
	    is_configuration_out_outSD_BPout_iMout_in_space_pp_nn_determine (GSM_vector_helper_M   , neut_data);
	    is_configuration_out_outSD_BPout_iMout_in_space_pp_nn_determine (GSM_vector_helper_Mp1 , neut_data);
	  } break;

	case PROTONS_NEUTRONS:
	  {
	    is_configuration_out_outSD_BPout_iMout_in_space_pn_determine (GSM_vector_helper_M   , prot_data , neut_data);
	    is_configuration_out_outSD_BPout_iMout_in_space_pn_determine (GSM_vector_helper_Mp1 , prot_data , neut_data);
	  } break;

	default: abort_all ();
	}
    }
  else
    {
      switch (space)
	{
	case PROTONS_ONLY:
	  {
	    is_configuration_out_outSD_BPout_iMout_in_space_pp_nn_determine (GSM_vector_helper_out , prot_data);
	  } break;

	case NEUTRONS_ONLY:	
	  {
	    is_configuration_out_outSD_BPout_iMout_in_space_pp_nn_determine (GSM_vector_helper_out , neut_data);
	  } break;

	case PROTONS_NEUTRONS:
	  {
	    is_configuration_out_outSD_BPout_iMout_in_space_pn_determine (GSM_vector_helper_out , prot_data , neut_data);
	  } break;

	default: abort_all ();
	}
    }
}

void configuration_SD_in_space_one_jump_in_to_out::configuration_SD_in_out_in_space_one_jump_tables_alloc_calc_Jpm (
														    const bool is_there_cout ,
														    const int pm , 
														    const class GSM_vector_helper_class &GSM_vector_helper_in , 
														    const class GSM_vector_helper_class &GSM_vector_helper_out , 
														    class nucleons_data &prot_data , 
														    class nucleons_data &neut_data)
{
  const class GSM_vector_helper_class dummy_helper;
  
  const enum space_type space = GSM_vector_helper_out.get_space ();

  const bool is_it_pole_approximation_in  = GSM_vector_helper_in.get_is_it_pole_approximation ();
  const bool is_it_pole_approximation_out = GSM_vector_helper_out.get_is_it_pole_approximation ();

  const bool is_it_pole_approximation = (is_it_pole_approximation_in && is_it_pole_approximation_out);
  
  configuration_SD_in_space_determine  (false , GSM_vector_helper_in  , dummy_helper , prot_data , neut_data);
  configuration_SD_out_space_determine (false , GSM_vector_helper_out , dummy_helper , prot_data , neut_data);

  if (space != NEUTRONS_ONLY) SD_one_jump_construction_set_in_to_out::all_SDs_one_jump_all_SDs_alloc_calc_Jpm (is_there_cout , is_it_pole_approximation , false , pm , prot_data);
  if (space != PROTONS_ONLY)  SD_one_jump_construction_set_in_to_out::all_SDs_one_jump_all_SDs_alloc_calc_Jpm (is_there_cout , is_it_pole_approximation , false , pm , neut_data);
}

void configuration_SD_in_space_one_jump_in_to_out::configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (
														const bool is_there_cout , 
														const bool is_it_one_body ,
														const bool is_it_two_body_pn_only , 
														const bool is_J2_applied ,
														const bool is_L2_CM_applied ,
														const class GSM_vector_helper_class &GSM_vector_helper_in , 
														const class GSM_vector_helper_class &GSM_vector_helper_out , 
														const class GSM_vector_helper_class &GSM_vector_helper_Mp1 , 
														class nucleons_data &prot_data , 
														class nucleons_data &neut_data)
{
  const bool is_it_one_body_T2_only = (is_it_one_body || is_it_two_body_pn_only);

  if (is_it_one_body_T2_only && is_L2_CM_applied)
    error_message_print_abort ("is_L2_CM_applied and is_it_one_body_T2_only are incompatible in configuration_SD_in_space_one_jump_in_to_out::configuration_SD_in_out_in_space_one_jump_tables_alloc_calc");

  const bool is_L2_CM_J2_applied = (is_J2_applied || is_L2_CM_applied);
  
  if (is_L2_CM_J2_applied && ((GSM_vector_helper_in.get_BP () != GSM_vector_helper_out.get_BP ()) || (GSM_vector_helper_in.get_iM () != GSM_vector_helper_out.get_iM ())))
    error_message_print_abort ("With L2_CM or Jpm applied, GSM_vector_helper_[in/out] must have same parity and M in configuration_SD_in_space_one_jump_in_to_out::configuration_SD_in_out_in_space_one_jump_tables_alloc_calc");

  const enum space_type space = GSM_vector_helper_out.get_space ();
  
  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const bool is_it_pole_approximation_in  = GSM_vector_helper_in.get_is_it_pole_approximation ();
  const bool is_it_pole_approximation_out = GSM_vector_helper_out.get_is_it_pole_approximation ();

  const bool is_it_pole_approximation_Mp1 = GSM_vector_helper_Mp1.get_is_it_pole_approximation ();
  
  const bool is_it_pole_approximation_in_out = (is_it_pole_approximation_in && is_it_pole_approximation_out);
  
  const bool is_it_pole_approximation = (is_L2_CM_J2_applied) ? (is_it_pole_approximation_in_out && is_it_pole_approximation_Mp1) : (is_it_pole_approximation_in_out);
  
  configuration_SD_in_space_determine  (is_L2_CM_J2_applied , GSM_vector_helper_in  , GSM_vector_helper_Mp1 , prot_data , neut_data);
  configuration_SD_out_space_determine (is_L2_CM_J2_applied , GSM_vector_helper_out , GSM_vector_helper_Mp1 , prot_data , neut_data);
  
  if (space != NEUTRONS_ONLY) one_jump_tables_alloc_calc_pp_nn (is_there_cout , is_it_one_body , is_it_two_body_pn_only , is_it_pole_approximation , is_J2_applied , truncation_hw , truncation_ph , prot_data);
  if (space != PROTONS_ONLY)  one_jump_tables_alloc_calc_pp_nn (is_there_cout , is_it_one_body , is_it_two_body_pn_only , is_it_pole_approximation , is_J2_applied , truncation_hw , truncation_ph , neut_data);
}


