#include "../GSM_include/GSM_include_def.h"

// MPI transfer is sometimes done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

using namespace string_routines;
using namespace correlated_state_routines;
using namespace density_OBMEs;
using namespace inputs_misc;

// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------



// See GSM_density_OBMEs.cpp for the calculation of OBMEs
// ------------------------------------------------------


// Calculation of the density for one pair of many-body states <Psi[out] | rho(r/k) | Psi[in]> or the density of a fixed state |Psi> <Psi | rho(r/k) | Psi>
// -------------------------------------------------------------------------------------------------------------------------------------------------------
//
// calc_one_pair
// -------------
// One calculates the density <Psi[out] | rho(r/k) | Psi[in]> for fixed states |Psi[in]> and |Psi[out]> for all r radii or k momenta.
//
// calc_store_one_state
// --------------------
// One calculates the density of a fixed state |Psi> <Psi | rho(r/k) | Psi> for all r radii.
// It is stored in disk in a file whose name looks like density_0+_0.dat .
//
// calc_store
// ----------
// Eigenvectors are read from disk and calc_store_one_state is called for the density associated to these eigenvectors.

void density::calc_one_pair (
			     const bool is_it_radial ,
			     const bool is_it_Gauss_Legendre ,
			     class GSM_vector &PSI_full , 		
			     const class GSM_vector &PSI_IN ,
			     const class GSM_vector &PSI_OUT , 
			     class array<class array<TYPE> > &density_p_tabs , 
			     class array<class array<TYPE> > &density_n_tabs)
{
  const class GSM_vector_helper_class &PSI_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
 
  const enum space_type space = PSI_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = PSI_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = PSI_helper_OUT.get_neut_Y_data ();
			       
  const unsigned int Np_nljm = prot_Y_data.get_N_nljm_baryon ();
  const unsigned int Nn_nljm = neut_Y_data.get_N_nljm_baryon ();
  
  const unsigned int N_bef_R_GL = prot_Y_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = prot_Y_data.get_N_bef_R_uniform ();
  
  const unsigned int Nk_momentum_GL = prot_Y_data.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = prot_Y_data.get_Nk_momentum_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const unsigned int Nk = (is_it_Gauss_Legendre) ? (Nk_momentum_GL) : (Nk_momentum_uniform);

  const unsigned int Nrk = (is_it_radial) ? (Nr) : (Nk);

  const int S = prot_Y_data.get_hypernucleus_strangeness ();
  
  const unsigned int N_density_particle_pairs = (S == 0) ? (1) : (S + 2);

  const enum particle_type density_particles_p[] = {PROTON  , SIGMA_MINUS , SIGMA_PLUS , XI_MINUS};
  const enum particle_type density_particles_n[] = {NEUTRON , SIGMA_ZERO  , LAMBDA     , XI_ZERO};
  
  class array<TYPE> OBMEs_p(Np_nljm , Np_nljm , Nrk);
  class array<TYPE> OBMEs_n(Nn_nljm , Nn_nljm , Nrk);
 
  for (unsigned int i = 0 ; i < N_density_particle_pairs ; i++)
    {
      const enum particle_type density_particle_p = density_particles_p[i];
      const enum particle_type density_particle_n = density_particles_n[i];
      
      const unsigned int density_particle_p_index = charge_baryon_index_determine (density_particle_p);
      const unsigned int density_particle_n_index = charge_baryon_index_determine (density_particle_n);
    
      class array<TYPE> &density_p_tab = density_p_tabs(density_particle_p_index);
      class array<TYPE> &density_n_tab = density_n_tabs(density_particle_n_index);
      
      if (space != NEUT_Y_ONLY) OBMEs_calc (density_particle_p , is_it_radial , is_it_Gauss_Legendre , prot_Y_data , OBMEs_p);
      if (space != PROT_Y_ONLY) OBMEs_calc (density_particle_n , is_it_radial , is_it_Gauss_Legendre , neut_Y_data , OBMEs_n);
    
      scalar_strength::calc (PSI_full , OBMEs_p , OBMEs_n , PSI_IN , PSI_OUT , density_p_tab , density_n_tab);
    }
}


void density::calc_one_pair (
			     const bool is_it_radial ,
			     const bool is_it_Gauss_Legendre ,
			     class GSM_vector &PSI_full , 		
			     const class GSM_vector &PSI_IN ,
			     const class GSM_vector &PSI_OUT , 
			     class array<TYPE> &density_tab)
{
  const class GSM_vector_helper_class &PSI_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
   
  const enum space_type space = PSI_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = PSI_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = PSI_helper_OUT.get_neut_Y_data ();
			       
  const unsigned int Np_nljm = prot_Y_data.get_N_nljm_baryon ();
  const unsigned int Nn_nljm = neut_Y_data.get_N_nljm_baryon ();
  
  const unsigned int N_bef_R_GL = prot_Y_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = prot_Y_data.get_N_bef_R_uniform ();
  
  const unsigned int Nk_momentum_GL = prot_Y_data.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = prot_Y_data.get_Nk_momentum_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const unsigned int Nk = (is_it_Gauss_Legendre) ? (Nk_momentum_GL) : (Nk_momentum_uniform);

  const unsigned int Nrk = (is_it_radial) ? (Nr) : (Nk);

  const int S = prot_Y_data.get_hypernucleus_strangeness ();
  
  const unsigned int N_density_particle_pairs = (S == 0) ? (1) : (S + 2);

  const enum particle_type density_particles_p[] = {PROTON  , SIGMA_MINUS , SIGMA_PLUS , XI_MINUS};
  const enum particle_type density_particles_n[] = {NEUTRON , SIGMA_ZERO  , LAMBDA     , XI_ZERO};
  
  class array<TYPE> OBMEs_p(Np_nljm , Np_nljm , Nrk);
  class array<TYPE> OBMEs_n(Nn_nljm , Nn_nljm , Nrk);

  class array<TYPE> density_p_tab(Nrk);
  class array<TYPE> density_n_tab(Nrk);

  density_tab = 0.0;
  
  for (unsigned int i = 0 ; i < N_density_particle_pairs ; i++)
    {
      const enum particle_type density_particle_p = density_particles_p[i];
      const enum particle_type density_particle_n = density_particles_n[i];
      
      if (space != NEUT_Y_ONLY) OBMEs_calc (density_particle_p , is_it_radial , is_it_Gauss_Legendre , prot_Y_data , OBMEs_p);
      if (space != PROT_Y_ONLY) OBMEs_calc (density_particle_n , is_it_radial , is_it_Gauss_Legendre , neut_Y_data , OBMEs_n);
        
      scalar_strength::calc (PSI_full , OBMEs_p , OBMEs_n , PSI_IN , PSI_OUT , density_p_tab , density_n_tab);
      
      density_tab += density_p_tab + density_n_tab;
    }
}



void density::calc_store_one_state (
				    const bool is_it_radial ,
				    const bool is_it_Gauss_Legendre ,
				    const class array<double> &rk_tab ,
				    const class correlated_state_str &PSI_qn , 
				    const class GSM_vector &PSI , 
				    class GSM_vector &PSI_full)
{
  const class GSM_vector_helper_class &PSI_helper = PSI.get_GSM_vector_helper ();
     
  const class baryons_data &prot_Y_data = PSI_helper.get_prot_Y_data ();
    
  const enum space_type space = PSI_helper.get_space ();
  
  const unsigned int N_bef_R_GL = prot_Y_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = prot_Y_data.get_N_bef_R_uniform ();
  
  const unsigned int Nk_momentum_GL = prot_Y_data.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = prot_Y_data.get_Nk_momentum_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const unsigned int Nk = (is_it_Gauss_Legendre) ? (Nk_momentum_GL) : (Nk_momentum_uniform);
    
  const unsigned int Nrk = (is_it_radial) ? (Nr) : (Nk);
  
  const string PSI_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_qn);
      
  const int S = prot_Y_data.get_hypernucleus_strangeness ();
  
  const unsigned int N_density_particle_pairs = (S == 0) ? (1) : (S + 2);
  
  class array<class array<TYPE> > density_p_tabs(N_density_particle_pairs);
  class array<class array<TYPE> > density_n_tabs(N_density_particle_pairs);
			 
  for (unsigned int i = 0 ; i < N_density_particle_pairs ; i++)
    {    
      density_p_tabs(i).allocate (Nrk);
      density_n_tabs(i).allocate (Nrk);
    }
  
  calc_one_pair (is_it_radial , is_it_Gauss_Legendre , PSI_full , PSI , PSI , density_p_tabs , density_n_tabs);
  
  if (THIS_PROCESS == MASTER_PROCESS) density_files_store (space , S , is_it_radial , PSI_qn_string , rk_tab , density_p_tabs , density_n_tabs);
}








void density::calc_store (
			  const class input_data_str &input_data , 
			  const class array<class correlated_state_str> &PSI_qn_tab , 
			  class baryons_data &prot_Y_data , 
			  class baryons_data &neut_Y_data ,  
			  class GSM_vector &PSI_full)
{ 
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Densities" << endl;
      cout <<         "---------" << endl << endl;
    }

  const enum space_type space = input_data.get_space ();
  
  const enum interaction_type inter = input_data.get_inter ();

  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();

  const int Z = prot_Y_data.get_N_nucleons ();
  const int N = neut_Y_data.get_N_nucleons ();

  const int S = prot_Y_data.get_hypernucleus_strangeness ();
  
  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
  
  const unsigned int density_number = input_data.get_density_number ();
  
  const class array<unsigned int> &density_BP_tab = input_data.get_density_BP_tab ();

  const class array<double> &density_J_tab = input_data.get_density_J_tab ();

  const class array<unsigned int> &density_vector_index_tab = input_data.get_density_vector_index_tab ();

  const class array<bool> &density_is_it_radial_tab = input_data.get_density_is_it_radial_tab ();
  
  const class array<bool> &density_is_it_Gauss_Legendre_tab = input_data.get_density_is_it_Gauss_Legendre_tab ();

  const unsigned int N_bef_R_GL = input_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = input_data.get_N_bef_R_uniform ();

  const unsigned int Nk_momentum_GL = input_data.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = input_data.get_Nk_momentum_uniform ();
  
  const double R = input_data.get_R ();
  
  const double kmax_momentum = input_data.get_kmax_momentum ();

  const double step_bef_R_uniform = input_data.get_step_bef_R_uniform ();
  
  const double step_momentum_uniform = input_data.get_step_momentum_uniform ();
  
  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);

  class array<double> r_bef_R_tab_uniform(N_bef_R_uniform);
  
  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;
  
  class array<double> k_tab_GL(Nk_momentum_GL);
  class array<double> wk_tab_GL(Nk_momentum_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , kmax_momentum , k_tab_GL , wk_tab_GL);

  class array<double> k_tab_uniform(Nk_momentum_uniform);
  
  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++) k_tab_uniform(i) = i*step_momentum_uniform;  

  for (unsigned int density_index = 0 ; density_index < density_number ; density_index++)
    {
      const unsigned int BP = density_BP_tab(density_index);

      const unsigned int vector_index = density_vector_index_tab(density_index);

      const double J = density_J_tab(density_index);

      const double M = J;
      
      const bool is_it_radial = density_is_it_radial_tab(density_index);
      
      const bool is_it_Gauss_Legendre = density_is_it_Gauss_Legendre_tab(density_index);

      const class correlated_state_str PSI_qn = PSI_quantum_numbers_find (Z , N , BP , S , J , vector_index , PSI_qn_tab);

      class GSM_vector_helper_class PSI_helper(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
					       n_holes_max   , n_scat_max   , E_max_hw  ,
					       n_holes_max_p , n_scat_max_p , Ep_max_hw ,
					       n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , true , prot_Y_data , neut_Y_data);
	
      class GSM_vector PSI(PSI_helper);

      PSI.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);
      
      const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (r_bef_R_tab_GL) : (r_bef_R_tab_uniform);

      const class array<double> &k_tab = (is_it_Gauss_Legendre) ? (k_tab_GL) : (k_tab_uniform);
      
      const class array<double> &rk_tab = (is_it_radial) ? (r_bef_R_tab) : (k_tab);
      
      calc_store_one_state (is_it_radial , is_it_Gauss_Legendre , rk_tab , PSI_qn , PSI , PSI_full);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  const string radial_momentum_str = (is_it_radial) ? ("Radial") : ("Momentum");
	  
	  cout << radial_momentum_str << " densities of " << J_Pi_vector_index_string (BP , J , vector_index) << " calculated." << endl << endl;
	}
    }

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
}


