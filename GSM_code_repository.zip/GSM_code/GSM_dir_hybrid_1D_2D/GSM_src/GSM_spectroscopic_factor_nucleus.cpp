#include "../GSM_include/GSM_include_def.h"




// TYPE is double or complex
// -------------------------

// Calculation of spectroscopic factor involving one nucleus
// ---------------------------------------------------------
// Spectroscopic factors and overlap functions are related to transfer reactions:
// A stripping reaction removes a cluster from the projectile and then adds it to the target.
// A pick-up reaction adds a cluster to the projectile after removing it from the target.
//
// One considers spectroscopic factor amplitudes of one cluster, or nucleus, as its wave function is that of a GSM vector issued from a structure calculation.
// The latter cluster is called the projectile/ejectile for stripping/pick-up and the initial nucleus the target.
//
// Spectroscopic factors are of the form S = (<Psi[out] || A+_{cluster} || Psi[in]>^J[out]/hat(J[out]))^2 for stripping
//                                   and S = (<Psi[out] || A~_{cluster} || Psi[in]>^J[out]/hat(J[in]))^2  for pick-up
//
// The spectroscopic amplitude is defined to be equal to <Psi[out] | A+_{cluster M[cluster]} | Psi[in]> for stripping, with M[cluster] = M[out] - M[in]
//                                                   and <Psi[out] | A~_{cluster M[cluster]} | Psi[in]> for pick-up,   with M[cluster] = M[in]  - M[out]
//
// One uses M[in] = J[in] and M[out] = J[out] for convenience.

// Spectroscopic factor directly follows from reduced matrix elements function of A+_{NCM[HO] LCM J[cluster]} and A~_{NCM[HO] LCM J[cluster]}.
//
// |Psi[out]> is given as input and |Psi[in]> will be read from disk from its provided quantum numbers.
//
// Different routines are used for stripping and pick-up, for proton or neutron projectiles, and if one has both valence protons and neutrons, or only valence protons or neutrons (plus a few hyperons if any).
//
// As the GSM vectors resulting from the action of A+ or A~ on |Psi[in]> are meaningful only in the master process, spectroscopic factor are only calculated in the master process.
//
// 
// stripping_calc, pick_up_calc
// ----------------------------
// Routines calculating spectroscopic factor for stripping or pick-up.


TYPE spectroscopic_factor::nucleus::stripping_calc (
						    const bool full_common_vectors_used_in_file ,
						    const class correlated_state_str &PSI_IN_qn , 
						    const class correlated_state_str &PSI_OUT_qn , 
						    const class correlated_state_str &PSI_cluster_qn ,
						    const double M_cluster , 
						    const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const double J_cluster = PSI_cluster_qn.get_J ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M ();

  const double M_IN = M_OUT - M_cluster;  
  
  const TYPE spectroscopic_factor_amplitude = spectroscopic_factor_amplitude::nucleus::stripping_calc (full_common_vectors_used_in_file , PSI_IN_qn , PSI_cluster_qn , M_cluster , PSI_OUT);
  
  const TYPE spectroscopic_factor_amplitude_reduced = ME_reduced (spectroscopic_factor_amplitude , J_cluster , M_cluster , J_IN , M_IN , J_OUT , M_OUT)/hat (J_OUT);

  const TYPE spectroscopic_factor_value = spectroscopic_factor_amplitude_reduced*spectroscopic_factor_amplitude_reduced;
  
  return spectroscopic_factor_value;
}
    





TYPE spectroscopic_factor::nucleus::pick_up_calc (
						  const bool full_common_vectors_used_in_file ,
						  const class correlated_state_str &PSI_IN_qn , 
						  const class correlated_state_str &PSI_OUT_qn , 
						  const class correlated_state_str &PSI_cluster_qn , 
						  const double M_cluster , 
						  const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const double J_cluster = PSI_cluster_qn.get_J ();

  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M ();

  const double M_IN = M_OUT + M_cluster;  
   
  const TYPE spectroscopic_factor_amplitude = spectroscopic_factor_amplitude::nucleus::pick_up_calc (full_common_vectors_used_in_file , PSI_IN_qn , PSI_cluster_qn , M_cluster , PSI_OUT);

  const TYPE spectroscopic_factor_amplitude_reduced = ME_reduced (spectroscopic_factor_amplitude , J_cluster , -M_cluster , J_IN , M_IN , J_OUT , M_OUT)/hat (J_IN);

  const TYPE spectroscopic_factor_value = spectroscopic_factor_amplitude_reduced*spectroscopic_factor_amplitude_reduced;
  
  return spectroscopic_factor_value;
}


