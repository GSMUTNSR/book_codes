#include "../GSM_include/GSM_include_def.h"

// TYPE is double or complex
// -------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------


// out_to_in means that one starts from |outSD> and one creates |inSD> from a+ a operations
// ----------------------------------------------------------------------------------------






// Class calculating and storing the 1p-1h or 2p-2h proton or neutron jumps from a fixed Slater determinant
// --------------------------------------------------------------------------------------------------------
// One has here constructors, destructors, calculation of memory used, and member routines calculating 1p-1h or 2p-2h proton or neutron jumps data from a fixed Slater determinant.
//
// 1p-1h and 2p-2h excitations are always of proton of neutron type.
// Indeed, 2p-2h pn excitations can always be reduced to two 1p-1h excitations of proton type and neutron type.
//
// One considers |Psi[out]> = O |Psi[in]> for a given operator O.
// One has <outSD | Psi[out]> = <outSD | O | Psi[in]> = \sum_{inSD} <outSD | O | inSD> . <inSD | Psi[in]> for a fixed |outSD>.
// Consequently, one has to generate all |inSD> Slater determinants from a fixed |outSD> Slater determinants.
// Even though |inSD> and |outSD> can have proton and neutron parts in the latter equations,
// one will consider for the rest of comments that they are of proton or neutron character only, as 1p-1h or 2p-2h jumps are of proton or neutron character only.
// One always starts from |outSD>, which provides all |inSD> Slater determinants of fixed parity Pi[in] and total angular momentum projection M[in].
// As parity and M are good quantum numbers for eigenvectors, it is indeed convenient to fix the parity and M quantum numbers of the proton or neutron part  Pi[in] and M[in] therein.
//
//
// 1p-1h jumps from configurations and Slater determinants have already been calculated here in other arrays,
// so that 1p-1h and 2p-2h excitation data are calculated form them are stored therein for a fixed |outSD>, Pi[in] and M[in]. 
// In order to save memory, one has only stored data for |inSD> Slater determinants bearing M[in] >= 0, as the M[in] < 0 can be recovered with time-reversal symmetry (TRS).
//
// In order to save time, one does deallocates and reallocates the array of the class which contains the data coming from 1p-1h and 2p-2h excitations.
// One calculates instead its maximal dimension for 1p-1h and 2p-2h excitations (see dimensions_1p1h_2p2h_space_BP_iM_fixed_max_calc_print in GSM_nucleons_data),
// and one allocates the present array only once, which is reused for all |outSD>, Pi[in] and M[in].
// As Pi[in], M[in] are fixed, the maximal number of 1p-1h excitations is the number of valence protons or neutrons times Ns+-,
// with Ns+- = max (Ns+,Ns-), where Ns+/Ns- is the number of protons or neutrons shells or positive/negative parity.
// Similarly, the maximal number of 2p-2h excitations is the number of valence proton or neutron pairs times the number of proton or neutron states times Ns+- over two.
// Consequently, these numbers are rather small, so that it is not expensive to allocate the array of data of 1p-1h and 2p-2h excitations to its maximal value.
// The current number of 1p-1h and 2p-2h excitation data is stored in "dimension".
//
// If one calculates jumps in the MSDHF framework, one has one only one configuration.
// Hence, one does not loop on all configurations in this case.
//
// mu is for proton or neutron.
//
//
//
// remove_zero_NBMEs
// -----------------
// One removes 1p-1h or 2p-2h excitation data associated to NBMEs equal to zero, calculated elsewhere.
// For this, one calculates the number of non zero NBMEs. If all NBMEs are non zeros, one leaves the routine.
// Then, one loops over the NBMEs, and everytime one has a non zero NBME, it is put in the NBMEs array at the position given by the incremented index.
// The member array table of 1p-1h or 2p-2h excitation data is modified accordingly.
// Then, all zero NBMEs are ignored, and all non zero NBMEs and their associated 1p-1h or 2p-2h data are put at the beginning of arrays.
// "dimension" is replaced by the number of non zero NBMEs.
// As configurations are no longer the same in elements, the element where configuration changes is no longer the same either (see GSM_jumps_data_inSD_str.cpp).
// Hence, booleans associated to this change are reset.
// 
// 
//
//
// reorder_minimal_configuration_changes
// -------------------------------------
// If the configuration changes in an array of jumps, one has to recalculate configuration-dependent indices.
// These recalculations are minimized by reordering the array in increasing order of configuration indices.
// The lexciographic order is used for that.
// It is not done for J+/J-, as configuration is fixed therein.
//
//
//
// 
//
// one_jump_mu_store
// -----------------
// This routine stores the data for 1p-1h excitations for all operators except J+ and J-.
// One considers the part of the array of 1p-1h jumps for configurations only (no consideration of m quantum numbers) generated by the configuration C[out] of |outSD>.
// Its first and last indices in the array are fully determined by the C[out] quantum numbers abnd the parity of |inSD> Slater determinants.
//
// Then, one does the same for the part of the array of 1p-1h jumps of Slater determinants |inSD> generated by |outSD>, which uses information of the latter array.
// However, to find its first and last indices, one has to do a binary search (see ..._good_iM_in_determine in GSM_array_of_SD_one_jump_data...cpp).
// Indeed, its elements are function of |outSD> and of the index of the jump a+_{alpha} a_{beta}, where the value of M[in] is implicit.
// It would have demanded too much memory to include it, as an array of the form T(outSD , M[in] , jump.index) instead of T(outSD , jump.index) would have generated too many zeros.
// Hence, one looks for the first and last indices of T(outSD , jump.index) so that the M[in] of the jump index is the one demanded for |inSD> with binary search, which is fast enough.
// 
// Then, one loops over the 1p-1h jump indices of configurations.
// This fixes C[in], and the shells shell[in] and shell[out], whose associated states mu[in] and mu[out] are different.
// One checks if GSM model space truncations are verified therein.
// This also fixes the equivalent configuration index of C[in] (see GSM_configuration_one_jump_construction_set.cpp).
// Then, one looks for the first 1p-1h jump index of Slater determinants whose equivalent configuration index is that of C[in].
// It is either looked for sequentially, as it typically arrives quickly in the array,
// or one takes that of the previous calculation if the equivalent configuration indices of C[in] and of the previous C[in] are identical,
// as then the 1p-1h jump indices of Slater determinants to use are identical as well (see GSM_configuration_one_jump_construction_set.cpp).
// Then, one loops over all the 1p-1h jump indices of Slater determinants whose equivalent configuration index is that of C[in].
// There, one can recover |inSD> and its index, as well as the mu[in] and mu[out] states and reordering phase from already stored arrays, using TRS if M[in] < 0.
// All these values are stored in the class.
//
//
//
// one_jump_mu_store_Jpm
// ---------------------
// This routine stores the data for 1p-1h excitations for J+ and J-.
// As there is no configuration mixing here, C[in] = C[out] = C, and the techniques of equivalent configurations are not used here.
// One does not loop over 1p-1h jump indices of configurations.
//
// One considers the part of the array of 1p-1h jumps for Slater determinants generated by |outSD>.
// Its first and last indices in the array are fully determined by the |outSD> quantum numbers, as Pi[in] = Pi[out] and M[in] = M[out] -/+ 1 for J+/J-,
// and they are also determined with binary search as in the previous case.
// 
// Then, one loops over the 1p-1h jump indices of Slater determinants.
// There, one can recover |inSD> and its index, as well as the mu[in] and mu[out] states and reordering phase from already stored arrays. TRS is not used.
// All these values are stored in the class.
//
//
// 
// two_jumps_mu_store
// ------------------
// This routine stores the data for 2p-2h excitations for all operators.
// The 2p-2h excitations are generated by two consecutive 1p-1h excitations of proton or neutron type, taking into account antisymmetry.
// Hence, one generates an intermediate Slater determinant |SDinter>, as |outSD> = a+(c) a+(d) a(b) a(a) |inSD> becomes |outSD> = a+(c) a(a) |SDinter> and |SDinter> = a+(d) a(b) |inSD>.
// The states a,b,c,d and denoted as 0,1,2,3 in the routine.
// As |SDinter> has the same number of nucleons as |inSD> and |outSD>, one can use the same stored arrays of 1p-1h excitations for |outSD> -> |SDinter> and |SDinter> -> |inSD>.
//
// One first loops over the parity Pi[inter] and total angular momentum projection M[inter] of |SDinter>, as they are not conserved.
// However, as |SDinter> is generated by a 1p-1h exciation, M[inter] is restricted to [M[out] - (m[max] - m[min]) : M[out] + (m[max] - m[min])] (added to that, |M[inter]| <= M[max]).
// 
// Then, the process described in the one_jump_mu_store section is repeated twice, one for |outSD-> -> |SDinter> and one for |SDinter> -> |inSD>.
// One has then the |SDinter> -> |inSD> loop inside the |outSD> -> |SDinter> loop.
//
// There, one can recover |inSD> and its index, as well as the a,b,c,d states and reordering phase from already stored arrays, using TRS if M[inter] < 0 and/or M[in] < 0
// Without energy truncation, one only selects a,b,c,d states verifying a < b and c < d, as demanded by antisymmetry.
// One can already suppress many cases at |inSD> configuration level if one does not have s(a) <= s(b) and s(c) <= s(d), with s(a,b,c,d) the shell associated to the a,b,c,d state.
// With energy truncation, however, added to the latter normal case, one sometimes has to consider a,b,c,d states verifying b < a and d < c.
// Indeed, considering a < b and c < d, energy truncation forbids |SDinter> -> |inSD> to occur if E[SDinter] = E[outSD] + energy(a) - energy(c) > E.max .
// Conversely, as E[inSD] <= E.max and E[outSD] <= E.max, one necessarily has E[SDinter'] = E[outSD] + energy(b) - energy(d) <= E.max, as energy(b) - energy(d) < 0.
// Hence, it is sufficient to allow for a,b,c,d states verifying b < a and d < c if E[outSD] + energy(b) - energy(d) > E.max, as then the previous (a,b) and (c,d) pairs are reversed,
// E[SDinter] = E[outSD] + energy(a) - energy(c) <= E.max, and then |SDinter> can be generated. No double counting occurs with this technique.

jumps_data_out_to_in_str::jumps_data_out_to_in_str () : 
  jump_type (NO_JUMP_DATA) ,
  space (NO_SPACE) ,
  truncation_hw (false) , 
  truncation_ph (false) , 
  dimension (0)
{}

jumps_data_out_to_in_str::jumps_data_out_to_in_str (
						    const enum jump_data_type jump_type_c , 
						    const enum space_type space_c , 
						    const bool truncation_hw_c , 
						    const bool truncation_ph_c , 
						    const unsigned int dimension_max) :
  jump_type (NO_JUMP_DATA) ,
  space (NO_SPACE) ,
  truncation_hw (false) , 
  truncation_ph (false) , 
  dimension (0)
{
  allocate (jump_type_c , space_c , truncation_hw_c ,  truncation_ph_c , dimension_max);
}

jumps_data_out_to_in_str::jumps_data_out_to_in_str (const class jumps_data_out_to_in_str &X) :
  jump_type (NO_JUMP_DATA) ,
  space (NO_SPACE) ,
  truncation_hw (false) , 
  truncation_ph (false) , 
  dimension (0)
{
  allocate_fill (X);
}

void jumps_data_out_to_in_str::allocate (
					 const enum jump_data_type jump_type_c , 
					 const enum space_type space_c , 
					 const bool truncation_hw_c , 
					 const bool truncation_ph_c , 
					 const unsigned int dimension_max)
{
  if (is_it_filled ()) error_message_print_abort ("jumps_data_out_to_in_str cannot be allocated twice in jumps_data_out_to_in_str::allocate");

  jump_type = jump_type_c;
  
  space = space_c;

  truncation_hw = truncation_hw_c;
  truncation_ph = truncation_ph_c;

  dimension = 0; 

  table.allocate (dimension_max);
}

void jumps_data_out_to_in_str::allocate_fill (const class jumps_data_out_to_in_str &X)
{
  if (is_it_filled ()) error_message_print_abort ("jumps_data_out_to_in_str cannot be allocated twice in jumps_data_out_to_in_str::allocate_fill");

  jump_type = X.jump_type;
  
  space = X.space;

  truncation_hw = X.truncation_hw;
  truncation_ph = X.truncation_ph;

  dimension = X.dimension; 

  table.allocate_fill (X.table);
}

void jumps_data_out_to_in_str::deallocate ()
{
  table.deallocate ();

  jump_type = NO_JUMP_DATA;
  
  space = NO_SPACE;

  truncation_hw = false;
  truncation_ph = false; 

  dimension = 0;
}

double used_memory_calc (const class jumps_data_out_to_in_str &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.table) - sizeof (T.table)/1000000.0);
}




void jumps_data_out_to_in_str::remove_zero_NBMEs (class array<TYPE> &NBMEs)
{
  unsigned int dimension_non_zero_NBMEs = 0;
  
  for (unsigned int i = 0 ; i < dimension ; i++)
    {
      const TYPE NBME = NBMEs(i);

      if (NBME != 0.0) dimension_non_zero_NBMEs++;
    }
  
  if (dimension_non_zero_NBMEs != dimension)
    {
      if (dimension_non_zero_NBMEs == 0)
	dimension = 0;
      else
	{	  
	  dimension_non_zero_NBMEs = 0;
	  
	  for (unsigned int i = 0 ; i < dimension ; i++)
	    {
	      const TYPE NBME = NBMEs(i);
	      
	      if (NBME != 0.0)
		{
		  const unsigned int index_non_zero_NBMEs = dimension_non_zero_NBMEs++;

		  if (index_non_zero_NBMEs != i)
		    {
		      table(index_non_zero_NBMEs) = table(i);
		      
		      NBMEs(index_non_zero_NBMEs) = NBMEs(i);
		    }
		}
	    }
	    
	  dimension = dimension_non_zero_NBMEs;

	  class jumps_data_inSD_str &jumps_zero = table(0);
	      
	  int n_holes_bef = jumps_zero.get_n_holes ();
	  
	  int n_scat_bef = jumps_zero.get_n_scat ();
	  
	  int iC_bef = jumps_zero.get_iC ();
	      
	  jumps_zero.set_configuration_change ();
	  
	  for (unsigned int i = 1 ; i < dimension ; i++)
	    {
	      class jumps_data_inSD_str &jumps = table(i);
	      
	      const int n_holes = jumps.get_n_holes ();
	      
	      const int n_scat = jumps.get_n_scat ();

	      const int iC = jumps.get_iC ();

	      if ((n_holes != n_holes_bef) || (n_scat != n_scat_bef) || (iC != iC_bef)) jumps.set_configuration_change ();

	      n_holes_bef = n_holes;
	      
	      n_scat_bef = n_scat;

	      iC_bef = iC;
	    }
	}  
    }
}






void jumps_data_out_to_in_str::reorder_minimal_configuration_changes ()
{
  if (dimension == 0) return;
  
  table.quick_sort (0 , dimension - 1);

  class jumps_data_inSD_str &jumps_zero = table(0);
	      
  int n_holes_bef = jumps_zero.get_n_holes ();
	  
  int n_scat_bef = jumps_zero.get_n_scat ();
	  
  int iC_bef = jumps_zero.get_iC ();
	      
  jumps_zero.set_configuration_change ();
	  
  for (unsigned int i = 1 ; i < dimension ; i++)
    {
      class jumps_data_inSD_str &jumps = table(i);
	      
      const int n_holes = jumps.get_n_holes ();
	      
      const int n_scat = jumps.get_n_scat ();

      const int iC = jumps.get_iC ();

      if ((n_holes != n_holes_bef) || (n_scat != n_scat_bef) || (iC != iC_bef))
	jumps.set_configuration_change ();
      else
	jumps.unset_configuration_change ();
      
      n_holes_bef = n_holes;
	      
      n_scat_bef = n_scat;

      iC_bef = iC;
    }
}






void jumps_data_out_to_in_str::one_jump_mu_store (
						  const unsigned int BPmu_in , 
						  const int iMmu_in , 
						  const int n_holes_max_mu , 
						  const int n_scat_max_mu , 
						  const int Emu_max_hw , 
						  const unsigned int BPmu_out , 
						  const int n_scat_mu_out , 
						  const unsigned int iCmu_out , 
						  const int iMmu_out , 
						  const unsigned int outSDmu_index , 
						  const class nucleons_data &data)
{
  if ((jump_type != ONE_JUMP) && (jump_type != ONE_JUMP_ONE_CONFIGURATION))
    error_message_print_abort ("jumps_data_str with ONE_JUMP or ONE_JUMP_ONE_CONFIGURATION jump type only in jumps_data_out_to_in_str::one_jump_mu_store");
  
  dimension = 0;

  const int two_m_max_mu = data.get_two_m_max ();

  const int four_m_max_mu = data.get_four_m_max ();

  const int iMmu_max = data.get_iM_max ();
  
  const int Delta_iMmu_in = iMmu_in - iMmu_out + two_m_max_mu;
	      
  if ((Delta_iMmu_in < 0) || (Delta_iMmu_in > four_m_max_mu)) return;
   
  const class array_BP_Nscat_iC<unsigned int> &dimensions_configuration_one_jump_table_mu = data.get_dimensions_configuration_one_jump_table_out_to_in ();
	
  const unsigned int dimension_configuration_one_jump_subtable_mu = dimensions_configuration_one_jump_table_mu(BPmu_out , n_scat_mu_out , iCmu_out , BPmu_in);

  if (dimension_configuration_one_jump_subtable_mu == 0) return;

  const class array_of_configuration_one_jump_data_out_to_in &configuration_one_jump_table_mu = data.get_configuration_one_jump_table_out_to_in ();

  const unsigned int C_one_jump_mu_debut_index = configuration_one_jump_table_mu.index_determine (BPmu_out , n_scat_mu_out , iCmu_out , BPmu_in , 0);

  const unsigned int C_one_jump_mu_end_index = C_one_jump_mu_debut_index + (dimension_configuration_one_jump_subtable_mu - 1);

  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDmu_TRS_indices = data.get_SD_TRS_indices ();

  const int TRS_iMmu_in  = iMmu_max - iMmu_in;
  const int TRS_iMmu_out = iMmu_max - iMmu_out;
  
  const int TRS_Delta_iMmu_in = TRS_iMmu_in - TRS_iMmu_out + two_m_max_mu;

  const bool is_Mmu_in_negative = (iMmu_in < TRS_iMmu_in);
    
  const int iMmu_in_abs_Mmu = (is_Mmu_in_negative) ? (TRS_iMmu_in) : (iMmu_in);

  const int Delta_iMmu_in_abs_Mmu = (is_Mmu_in_negative) ? (TRS_Delta_iMmu_in) : (Delta_iMmu_in);
  
  const int iMmu_out_abs_Mmu = (is_Mmu_in_negative) ? (TRS_iMmu_out) : (iMmu_out);

  const unsigned int outSDmu_TRS_index = SDmu_TRS_indices(BPmu_out , n_scat_mu_out , iCmu_out , iMmu_out , outSDmu_index);

  const unsigned int outSDmu_index_one_jump = (is_Mmu_in_negative) ? (outSDmu_TRS_index) : (outSDmu_index);

  const class array_BP_Nscat_iC_iM_SD<unsigned int> &dimensions_SDmu_one_jump_table = data.get_dimensions_SD_one_jump_table_out_to_in ();

  const unsigned int dimension_SDmu_one_jump_subtable = dimensions_SDmu_one_jump_table(BPmu_out , n_scat_mu_out , iCmu_out , iMmu_out_abs_Mmu , outSDmu_index_one_jump);  

  if (dimension_SDmu_one_jump_subtable == 0) return;
  
  const class array_of_SD_one_jump_data_out_to_in &SDmu_one_jump_table = data.get_SD_one_jump_table_out_to_in ();

  const unsigned long int SDmu_one_jump_zero_index = SDmu_one_jump_table.index_determine (BPmu_out , n_scat_mu_out , iCmu_out , iMmu_out_abs_Mmu , outSDmu_index_one_jump , 0);

  const class SD_one_jump_data_out_to_in_str &SDmu_one_jump_zero = SDmu_one_jump_table[SDmu_one_jump_zero_index];

  const int Delta_iMmu_in_zero = SDmu_one_jump_zero.get_Delta_iM_in ();

  if (Delta_iMmu_in_abs_Mmu < Delta_iMmu_in_zero) return;

  const unsigned long int SDmu_one_jump_last_index = SDmu_one_jump_zero_index + (dimension_SDmu_one_jump_subtable - 1);

  const class SD_one_jump_data_out_to_in_str &SDmu_one_jump_last = SDmu_one_jump_table[SDmu_one_jump_last_index];

  const int Delta_iMmu_in_last = SDmu_one_jump_last.get_Delta_iM_in ();  

  if (Delta_iMmu_in_abs_Mmu > Delta_iMmu_in_last) return;
  
  const unsigned long int SDmu_one_jump_debut_index = SDmu_one_jump_table.debut_index_good_iM_in_determine (Delta_iMmu_in_abs_Mmu , dimension_SDmu_one_jump_subtable , SDmu_one_jump_zero_index);

  const unsigned long int SDmu_one_jump_end_index = SDmu_one_jump_table.end_index_good_iM_in_determine (Delta_iMmu_in_abs_Mmu , dimension_SDmu_one_jump_subtable , SDmu_one_jump_zero_index);
  
  const class array_BP_Nscat_iC<int> &E_hw_table_mu = data.get_E_hw_table ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_Nscat_iC_iM_SD<unsigned char> &SDmu_TRS_reordering_bin_phases = data.get_SD_TRS_reordering_bin_phases ();

  const class array_BP_Nscat_iC<bool> &is_configuration_in_in_space_tab_mu = data.get_is_configuration_in_in_space_tab (0);

  const class array_BP_Nscat_iC_iM_SD<bool> &is_inSDmu_in_space_tab = data.get_is_inSD_in_space_tab (0);
      
  const unsigned int TRS_reordering_bin_phase_outSDmu = SDmu_TRS_reordering_bin_phases(BPmu_out , n_scat_mu_out , iCmu_out , iMmu_out , outSDmu_index);

  const bool is_it_one_configuration_case = (jump_type == ONE_JUMP_ONE_CONFIGURATION);
  
  unsigned long int SDmu_one_jump_index = SDmu_one_jump_debut_index;

  unsigned long int SDmu_one_jump_C_eq_deb_index = SDmu_one_jump_debut_index;

  unsigned int C_eq_one_jump_mu_index_bef = 0;
		 		      
  for (unsigned int C_one_jump_mu_index = C_one_jump_mu_debut_index ; C_one_jump_mu_index <= C_one_jump_mu_end_index ; C_one_jump_mu_index++)
    {
      const class configuration_one_jump_data_out_to_in_str &C_one_jump_mu = configuration_one_jump_table_mu[C_one_jump_mu_index];

      const int n_holes_mu_in = C_one_jump_mu.get_n_holes_in ();
      
      const int n_scat_mu_in = C_one_jump_mu.get_n_scat_in ();
      
      if (!truncation_ph || ((n_holes_mu_in <= n_holes_max_mu) && (n_scat_mu_in <= n_scat_max_mu)))
	{
	  const unsigned int iCmu_in = C_one_jump_mu.get_iC_in ();
	  
	  if (!is_configuration_in_in_space_tab_mu(BPmu_in , n_scat_mu_in , iCmu_in)) continue;
	  
	  if (is_it_one_configuration_case && (iCmu_in != iCmu_out)) continue;

	  const int Emu_hw_in = E_hw_table_mu(BPmu_in , n_scat_mu_in , iCmu_in);
	  
	  const unsigned int C_eq_one_jump_mu_index = C_one_jump_mu.get_C_eq_one_jump_index ();
	      
	  if (!truncation_hw || (Emu_hw_in <= Emu_max_hw))
	    {
	      const unsigned int mu_shell_out_index = C_one_jump_mu.get_C_out_shell ();
	      const unsigned int mu_shell_in_index  = C_one_jump_mu.get_C_in_shell ();
	      
	      const unsigned long int is_inSDmu_in_space_C_Mmu_in_zero_index = is_inSDmu_in_space_tab.index_determine (BPmu_in , n_scat_mu_in , iCmu_in , iMmu_in , 0);
	      
	      const unsigned long int SDmu_TRS_indices_C_abs_Mmu_in_zero_index = SDmu_TRS_indices.index_determine (BPmu_in , n_scat_mu_in , iCmu_in , iMmu_in_abs_Mmu , 0);
	      
	      const unsigned long int SDmu_TRS_reordering_bin_phases_C_abs_Mmu_in_zero_index = SDmu_TRS_reordering_bin_phases.index_determine (BPmu_in , n_scat_mu_in , iCmu_in , iMmu_in_abs_Mmu , 0);

	      bool is_configuration_changing = true;

	      if ((C_one_jump_mu_index > C_one_jump_mu_debut_index) && (C_eq_one_jump_mu_index == C_eq_one_jump_mu_index_bef))
		SDmu_one_jump_index = SDmu_one_jump_C_eq_deb_index;
	      else
		{
		  while ((SDmu_one_jump_index <= SDmu_one_jump_end_index) && (SDmu_one_jump_table[SDmu_one_jump_index].get_C_eq_one_jump_index () < C_eq_one_jump_mu_index)) SDmu_one_jump_index++;

		  SDmu_one_jump_C_eq_deb_index = SDmu_one_jump_index;
		}
	      
	      while ((SDmu_one_jump_index <= SDmu_one_jump_end_index) && (SDmu_one_jump_table[SDmu_one_jump_index].get_C_eq_one_jump_index () == C_eq_one_jump_mu_index))
		{
		  const class SD_one_jump_data_out_to_in_str &SDmu_one_jump = SDmu_one_jump_table[SDmu_one_jump_index];

		  const unsigned int inSDmu_index_abs_Mmu_in = SDmu_one_jump.get_inSD_index ();

		  const unsigned long int SDmu_TRS_indices_C_abs_Mmu_in_index = SDmu_TRS_indices_C_abs_Mmu_in_zero_index + inSDmu_index_abs_Mmu_in;

		  const unsigned int inSDmu_index = (is_Mmu_in_negative) ? (SDmu_TRS_indices[SDmu_TRS_indices_C_abs_Mmu_in_index]) : (inSDmu_index_abs_Mmu_in);  

		  const unsigned long int is_inSDmu_in_space_C_Mmu_in_index = is_inSDmu_in_space_C_Mmu_in_zero_index + inSDmu_index;
								   
		  if (is_inSDmu_in_space_tab[is_inSDmu_in_space_C_Mmu_in_index])
		    {
		      const int im_mu_abs_Mmu_in = SDmu_one_jump.get_im_in ();
		      
		      const int im_mu_in = (is_Mmu_in_negative) ? (two_m_max_mu - im_mu_abs_Mmu_in) : (im_mu_abs_Mmu_in);
		      
		      const int im_mu_out = im_mu_in - Delta_iMmu_in + two_m_max_mu;

		      const unsigned int mu_in  = one_body_indices_mu(mu_shell_in_index  , im_mu_in);		      
		      const unsigned int mu_out = one_body_indices_mu(mu_shell_out_index , im_mu_out);
		      
		      const unsigned int bin_phase_mu = SDmu_one_jump.get_bin_phase ();

		      const unsigned long int SDmu_TRS_reordering_bin_phases_C_abs_Mmu_in_index = SDmu_TRS_reordering_bin_phases_C_abs_Mmu_in_zero_index + inSDmu_index_abs_Mmu_in;

		      const unsigned int TRS_reordering_bin_phase_inSDmu = SDmu_TRS_reordering_bin_phases[SDmu_TRS_reordering_bin_phases_C_abs_Mmu_in_index];

		      const unsigned int TRS_reordering_bin_phase_mu = (is_Mmu_in_negative) ? (binary_parity_product (TRS_reordering_bin_phase_outSDmu , TRS_reordering_bin_phase_inSDmu)) : (0);

		      const unsigned int total_bin_phase_mu = binary_parity_product (bin_phase_mu , TRS_reordering_bin_phase_mu);
		      
		      table(dimension++).initialize (n_holes_mu_in , n_scat_mu_in , iCmu_in , inSDmu_index , total_bin_phase_mu , is_configuration_changing , mu_in , mu_out , Emu_hw_in);
		      
		      is_configuration_changing = false;
		    }
		  
		  SDmu_one_jump_index++;
		}
	    }
	  C_eq_one_jump_mu_index_bef = C_eq_one_jump_mu_index;
	}
    }
  
  if (space == PROTONS_NEUTRONS) reorder_minimal_configuration_changes ();
}







void jumps_data_out_to_in_str::one_jump_mu_Jpm_store (
						      const int pm , 
						      const unsigned int BPmu , 
						      const int n_scat_mu , 
						      const unsigned int iCmu , 
						      const int iMmu , 
						      const unsigned int outSDmu_index , 
						      const class nucleons_data &data)
{
  if ((jump_type != ONE_JUMP) && (jump_type != ONE_JUMP_ONE_CONFIGURATION)) error_message_print_abort ("jumps_data_str with ONE_JUMP or ONE_JUMP_ONE_CONFIGURATION jump type only in jumps_data_out_to_in_str::one_jump_mu_Jpm_store");
    
  dimension = 0;
  
  const unsigned int Delta_iMmu_in = (pm == 1) ? (0) : (1);  

  const class array_BP_Nscat_iC_iM_SD<unsigned int> &dimensions_SDmu_one_jump_table = data.get_dimensions_SD_one_jump_table_Jpm_out_to_in ();

  const unsigned int dimension_SDmu_one_jump_subtable = dimensions_SDmu_one_jump_table(BPmu , n_scat_mu , iCmu , iMmu , outSDmu_index);

  if (dimension_SDmu_one_jump_subtable == 0) return;

  const class array_of_SD_one_jump_data_Jpm_out_to_in &SDmu_one_jump_table = data.get_SD_one_jump_table_Jpm_out_to_in ();
  
  const unsigned long int SDmu_one_jump_zero_index = SDmu_one_jump_table.index_determine (BPmu , n_scat_mu , iCmu , iMmu , outSDmu_index , 0);

  const class SD_one_jump_data_Jpm_out_to_in_str &SDmu_one_jump_zero = SDmu_one_jump_table[SDmu_one_jump_zero_index];

  const unsigned int Delta_iMmu_in_zero = SDmu_one_jump_zero.get_Delta_iM_in ();

  if (Delta_iMmu_in < Delta_iMmu_in_zero) return;

  const unsigned long int SDmu_one_jump_last_index = SDmu_one_jump_zero_index + (dimension_SDmu_one_jump_subtable - 1);

  const class SD_one_jump_data_Jpm_out_to_in_str &SDmu_one_jump_last = SDmu_one_jump_table[SDmu_one_jump_last_index];

  const unsigned int Delta_iMmu_in_last = SDmu_one_jump_last.get_Delta_iM_in ();

  if (Delta_iMmu_in > Delta_iMmu_in_last) return;

  const unsigned long int SDmu_one_jump_debut_index = SDmu_one_jump_table.debut_index_good_iM_in_determine (Delta_iMmu_in , dimension_SDmu_one_jump_subtable , SDmu_one_jump_zero_index);

  const unsigned long int SDmu_one_jump_end_index = SDmu_one_jump_table.end_index_good_iM_in_determine (Delta_iMmu_in , dimension_SDmu_one_jump_subtable , SDmu_one_jump_zero_index);

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_Nscat_iC_iM_SD<bool> &is_inSDmu_in_space_tab = data.get_is_inSD_in_space_tab (0);

  const int iMmu_in = iMmu - pm;
  
  const unsigned long int is_inSDmu_in_space_C_Mmu_in_zero_index = is_inSDmu_in_space_tab.index_determine (BPmu , n_scat_mu , iCmu , iMmu_in , 0);
  
  for (unsigned long int SDmu_one_jump_index = SDmu_one_jump_debut_index ; SDmu_one_jump_index <= SDmu_one_jump_end_index ; SDmu_one_jump_index++)
    { 
      const class SD_one_jump_data_Jpm_out_to_in_str &SDmu_one_jump = SDmu_one_jump_table[SDmu_one_jump_index];

      const unsigned int inSDmu_index = SDmu_one_jump.get_inSD_index ();

      const unsigned long int is_inSDmu_in_space_C_Mmu_in_index = is_inSDmu_in_space_C_Mmu_in_zero_index + inSDmu_index;
								   
      if (is_inSDmu_in_space_tab[is_inSDmu_in_space_C_Mmu_in_index])
	{
	  const unsigned int mu_shell_index = SDmu_one_jump.get_shell_index ();
	  
	  const unsigned int total_bin_phase_mu = SDmu_one_jump.get_bin_phase ();
	  
	  const int im_mu_in = SDmu_one_jump.get_im_in ();

	  const int im_mu_out = im_mu_in + pm;
	  
	  const unsigned int mu_in   = one_body_indices_mu(mu_shell_index , im_mu_in);
	  const unsigned int mu_out = one_body_indices_mu(mu_shell_index , im_mu_out);
	  
	  table(dimension++).initialize (inSDmu_index , total_bin_phase_mu , false , mu_in , mu_out);
	} 
    }
}




void jumps_data_out_to_in_str::two_jumps_mu_store (
						   const unsigned int BPmu_in , 
						   const int iMmu_in , 
						   const int n_holes_max_mu , 
						   const int n_scat_max_mu , 
						   const int Emu_max_hw , 
						   const unsigned int BPmu_out , 
						   const int n_scat_mu_out , 
						   const unsigned int iCmu_out , 
						   const int iMmu_out , 
						   const unsigned int outSDmu_index , 
						   const class nucleons_data &data)
{
  if ((jump_type != TWO_JUMPS) && (jump_type != TWO_JUMPS_ONE_CONFIGURATION)) error_message_print_abort ("jumps_data_str with TWO_JUMPS or TWO_JUMPS_ONE_CONFIGURATION jump type only in jumps_data_out_to_in_str::two_jumps_mu_store");
  
  dimension = 0;

  const int two_m_max_mu = data.get_two_m_max ();

  const int four_m_max_mu = data.get_four_m_max ();

  const int m_max_minus_m_min_mu = data.get_m_max_minus_m_min ();

  const int iMmu_max = data.get_iM_max ();

  const int iMmu_inter_min_M = max (0 , iMmu_out - m_max_minus_m_min_mu);

  const int iMmu_inter_max_M = min (iMmu_max , iMmu_out + m_max_minus_m_min_mu);
  
  const int TRS_iMmu_in  = iMmu_max - iMmu_in;
  const int TRS_iMmu_out = iMmu_max - iMmu_out;
  
  const bool is_Mmu_in_negative = (iMmu_in < TRS_iMmu_in);
  
  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_Nscat_iC<int> &Emu_hw_table = data.get_E_hw_table ();

  const class array_BP_Nscat_iC_iM_SD<unsigned char> &SDmu_TRS_reordering_bin_phases = data.get_SD_TRS_reordering_bin_phases ();
  
  const class array_BP_Nscat_iC_iM_SD<unsigned int> &dimensions_SDmu_one_jump_table = data.get_dimensions_SD_one_jump_table_out_to_in ();

  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDmu_TRS_indices = data.get_SD_TRS_indices ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_configuration_one_jump_table_mu = data.get_dimensions_configuration_one_jump_table_out_to_in ();
  
  const class array_BP_Nscat_iC<bool> &is_configuration_in_in_space_mu_tab = data.get_is_configuration_in_in_space_tab (0);

  const class array_BP_Nscat_iC<bool> &is_it_configuration_inter_to_include_mu_tab = data.get_is_it_configuration_inter_to_include_tab ();

  const class array_BP_Nscat_iC<bool> &is_configuration_out_in_space_mu_tab = data.get_is_configuration_out_in_space_tab ();
      
  const class array_BP_Nscat_iC_iM_SD<bool> &is_inSDmu_in_space_tab = data.get_is_inSD_in_space_tab (0);
  
  const class array_of_configuration_one_jump_data_out_to_in &configuration_one_jump_table_mu = data.get_configuration_one_jump_table_out_to_in ();
  
  const class array_of_SD_one_jump_data_out_to_in &SDmu_one_jump_table = data.get_SD_one_jump_table_out_to_in ();
  
  const bool is_it_one_configuration_case = (jump_type == TWO_JUMPS_ONE_CONFIGURATION);
      
  for (unsigned int BPmu_inter = 0 ; BPmu_inter <= 1 ; BPmu_inter++)
    {
      if (is_it_one_configuration_case && (BPmu_inter != BPmu_out)) continue;
		    
      for (int iMmu_inter = iMmu_inter_min_M ; iMmu_inter <= iMmu_inter_max_M ; iMmu_inter++)
	{
	  const int TRS_iMmu_inter = iMmu_max - iMmu_inter;
	  
	  const int Delta_iMmu_inter = iMmu_inter - iMmu_out + two_m_max_mu;

	  const int Delta_iMmu_in = iMmu_in - iMmu_inter + two_m_max_mu;
	  
	  const int TRS_Delta_iMmu_inter = TRS_iMmu_inter - TRS_iMmu_out + two_m_max_mu;

	  const int TRS_Delta_iMmu_in = TRS_iMmu_in - TRS_iMmu_inter + two_m_max_mu;
	  
	  const bool is_Mmu_inter_negative = (iMmu_inter < TRS_iMmu_inter);

	  if ((Delta_iMmu_in >= 0) && (Delta_iMmu_in <= four_m_max_mu) && (Delta_iMmu_inter >= 0) && (Delta_iMmu_inter <= four_m_max_mu))
	    {	
	      const unsigned int dimension_configuration_one_jump_subtable_mu_02 = dimensions_configuration_one_jump_table_mu(BPmu_out , n_scat_mu_out , iCmu_out , BPmu_inter);
	      
	      if (dimension_configuration_one_jump_subtable_mu_02 == 0) continue;

	      const int iMmu_inter_abs_Mmu = (is_Mmu_inter_negative) ? (TRS_iMmu_inter) : (iMmu_inter);

	      const int Delta_iMmu_inter_abs_Mmu = (is_Mmu_inter_negative) ? (TRS_Delta_iMmu_inter) : (Delta_iMmu_inter);
	      
	      const int iMmu_in_abs_Mmu = (is_Mmu_in_negative) ? (TRS_iMmu_in) : (iMmu_in);

	      const int Delta_iMmu_in_abs_Mmu = (is_Mmu_in_negative) ? (TRS_Delta_iMmu_in) : (Delta_iMmu_in);
	      
	      const int iMmu_out_abs_Mmu_02 = (is_Mmu_inter_negative) ? (TRS_iMmu_out) : (iMmu_out);

	      const int iMmu_inter_abs_Mmu_13 = (is_Mmu_in_negative) ? (TRS_iMmu_inter) : (iMmu_inter);

	      const unsigned int outSDmu_TRS_index = SDmu_TRS_indices(BPmu_out , n_scat_mu_out , iCmu_out , iMmu_out , outSDmu_index);

	      const unsigned int outSDmu_index_one_jump_02 = (is_Mmu_inter_negative) ? (outSDmu_TRS_index) : (outSDmu_index);

	      const unsigned int dimension_SDmu_one_jump_subtable_02 = dimensions_SDmu_one_jump_table(BPmu_out , n_scat_mu_out , iCmu_out , iMmu_out_abs_Mmu_02 , outSDmu_index_one_jump_02);

	      if (dimension_SDmu_one_jump_subtable_02 == 0) continue;

	      const unsigned long int SDmu_one_jump_02_zero_index = SDmu_one_jump_table.index_determine (BPmu_out , n_scat_mu_out , iCmu_out , iMmu_out_abs_Mmu_02 , outSDmu_index_one_jump_02 , 0);

	      const class SD_one_jump_data_out_to_in_str &SDmu_one_jump_02_zero = SDmu_one_jump_table[SDmu_one_jump_02_zero_index];

	      const int Delta_iMmu_inter_02_zero = SDmu_one_jump_02_zero.get_Delta_iM_in ();

	      if (Delta_iMmu_inter_abs_Mmu < Delta_iMmu_inter_02_zero) continue;

	      const unsigned long int SDmu_one_jump_02_last_index = SDmu_one_jump_02_zero_index + (dimension_SDmu_one_jump_subtable_02 - 1);

	      const class SD_one_jump_data_out_to_in_str &SDmu_one_jump_02_last = SDmu_one_jump_table[SDmu_one_jump_02_last_index];

	      const int Delta_iMmu_inter_02_last = SDmu_one_jump_02_last.get_Delta_iM_in ();

	      if (Delta_iMmu_inter_abs_Mmu > Delta_iMmu_inter_02_last) continue;

	      const unsigned long int SDmu_one_jump_02_debut_index = SDmu_one_jump_table.debut_index_good_iM_in_determine (Delta_iMmu_inter_abs_Mmu , dimension_SDmu_one_jump_subtable_02 , SDmu_one_jump_02_zero_index);

	      const unsigned long int SDmu_one_jump_02_end_index = SDmu_one_jump_table.end_index_good_iM_in_determine (Delta_iMmu_inter_abs_Mmu , dimension_SDmu_one_jump_subtable_02 , SDmu_one_jump_02_zero_index);

	      const int Emu_hw_out = Emu_hw_table(BPmu_out , n_scat_mu_out , iCmu_out);

	      const unsigned int C_one_jump_02_mu_debut_index = configuration_one_jump_table_mu.index_determine (BPmu_out , n_scat_mu_out , iCmu_out , BPmu_inter , 0);

	      const unsigned int C_one_jump_02_mu_end_index = C_one_jump_02_mu_debut_index + (dimension_configuration_one_jump_subtable_mu_02 - 1);

	      const unsigned int TRS_reordering_bin_phase_outSDmu = SDmu_TRS_reordering_bin_phases(BPmu_out , n_scat_mu_out , iCmu_out , iMmu_out , outSDmu_index);

	      unsigned int SDmu_one_jump_02_index = SDmu_one_jump_02_debut_index;

	      unsigned int SDmu_one_jump_C_eq_deb_02_index = SDmu_one_jump_02_debut_index;

	      unsigned int C_eq_one_jump_mu_index_02_bef = 0;

	      for (unsigned int C_one_jump_02_mu_index = C_one_jump_02_mu_debut_index ; C_one_jump_02_mu_index <= C_one_jump_02_mu_end_index ; C_one_jump_02_mu_index++)
		{
		  const class configuration_one_jump_data_out_to_in_str &C_one_jump_02_mu = configuration_one_jump_table_mu[C_one_jump_02_mu_index];

		  const int n_holes_mu_inter = C_one_jump_02_mu.get_n_holes_in ();
		  
		  const int n_scat_mu_inter = C_one_jump_02_mu.get_n_scat_in ();
  
		  if (!truncation_ph || ((n_holes_mu_inter <= n_holes_max_mu) && (n_scat_mu_inter <= n_scat_max_mu)))
		    {
		      const unsigned int iCmu_inter = C_one_jump_02_mu.get_iC_in ();
      
		      if (!is_configuration_out_in_space_mu_tab(BPmu_inter , n_scat_mu_inter , iCmu_inter) && !is_it_configuration_inter_to_include_mu_tab(BPmu_inter , n_scat_mu_inter , iCmu_inter)) continue;
      
		      if (is_it_one_configuration_case && (iCmu_inter != iCmu_out)) continue;
      
		      const unsigned int dimension_configuration_one_jump_subtable_mu_13 = dimensions_configuration_one_jump_table_mu(BPmu_inter , n_scat_mu_inter , iCmu_inter , BPmu_in);

		      if (dimension_configuration_one_jump_subtable_mu_13 > 0)
			{
			  const unsigned int C_eq_one_jump_mu_index_02 = C_one_jump_02_mu.get_C_eq_one_jump_index ();
			  
			  const unsigned int s0_shell_index = C_one_jump_02_mu.get_C_in_shell ();
			  const unsigned int s2_shell_index = C_one_jump_02_mu.get_C_out_shell ();

			  const unsigned long int SDmu_TRS_indices_C_abs_Mmu_inter_zero_index = SDmu_TRS_indices.index_determine (BPmu_inter , n_scat_mu_inter , iCmu_inter , iMmu_inter_abs_Mmu , 0);

			  const unsigned long int SDmu_TRS_reordering_bin_phases_C_abs_Mmu_inter_zero_index = SDmu_TRS_reordering_bin_phases.index_determine (BPmu_inter , n_scat_mu_inter , iCmu_inter , iMmu_inter_abs_Mmu , 0);
	      
			  if ((C_one_jump_02_mu_index > C_one_jump_02_mu_debut_index) && (C_eq_one_jump_mu_index_02 == C_eq_one_jump_mu_index_02_bef))
			    SDmu_one_jump_02_index = SDmu_one_jump_C_eq_deb_02_index;
			  else
			    {
			      while ((SDmu_one_jump_02_index <= SDmu_one_jump_02_end_index) && (SDmu_one_jump_table[SDmu_one_jump_02_index].get_C_eq_one_jump_index () < C_eq_one_jump_mu_index_02))
				SDmu_one_jump_02_index++;
		  
			      SDmu_one_jump_C_eq_deb_02_index = SDmu_one_jump_02_index;
			    }
	      
			  while ((SDmu_one_jump_02_index <= SDmu_one_jump_02_end_index) && (SDmu_one_jump_table[SDmu_one_jump_02_index].get_C_eq_one_jump_index () == C_eq_one_jump_mu_index_02))
			    {
			      const class SD_one_jump_data_out_to_in_str &SDmu_one_jump_02 = SDmu_one_jump_table[SDmu_one_jump_02_index];

			      const unsigned int SDmu_inter_index_abs_Mmu_inter = SDmu_one_jump_02.get_inSD_index ();
   
			      const unsigned long int SDmu_TRS_indices_C_abs_Mmu_inter_index = SDmu_TRS_indices_C_abs_Mmu_inter_zero_index + SDmu_inter_index_abs_Mmu_inter;
			      
			      const unsigned int SDmu_inter_TRS_index_abs_Mmu_inter = SDmu_TRS_indices[SDmu_TRS_indices_C_abs_Mmu_inter_index];

			      const unsigned int SDmu_inter_index = (is_Mmu_inter_negative) ? (SDmu_inter_TRS_index_abs_Mmu_inter) : (SDmu_inter_index_abs_Mmu_inter);

			      const unsigned int SDmu_inter_TRS_index = (is_Mmu_inter_negative) ? (SDmu_inter_index_abs_Mmu_inter) : (SDmu_inter_TRS_index_abs_Mmu_inter);

			      const unsigned int SDmu_inter_index_one_jump_13 = (is_Mmu_in_negative) ? (SDmu_inter_TRS_index) : (SDmu_inter_index);
		  
			      const unsigned int dimension_SDmu_one_jump_subtable_13 = dimensions_SDmu_one_jump_table(BPmu_inter , n_scat_mu_inter , iCmu_inter , iMmu_inter_abs_Mmu_13 , SDmu_inter_index_one_jump_13);
	  
			      if (dimension_SDmu_one_jump_subtable_13 > 0)
				{	
				  const unsigned long int SDmu_one_jump_13_zero_index = SDmu_one_jump_table.index_determine (BPmu_inter , n_scat_mu_inter , iCmu_inter , iMmu_inter_abs_Mmu_13 , SDmu_inter_index_one_jump_13 , 0);

				  const class SD_one_jump_data_out_to_in_str &SDmu_one_jump_13_zero = SDmu_one_jump_table[SDmu_one_jump_13_zero_index];
				  
				  const int Delta_iMmu_in_13_zero = SDmu_one_jump_13_zero.get_Delta_iM_in ();

				  if (Delta_iMmu_in_abs_Mmu >= Delta_iMmu_in_13_zero)
				    {
				      const unsigned long int SDmu_one_jump_13_last_index = SDmu_one_jump_13_zero_index + (dimension_SDmu_one_jump_subtable_13 - 1);

				      const class SD_one_jump_data_out_to_in_str &SDmu_one_jump_13_last = SDmu_one_jump_table[SDmu_one_jump_13_last_index];

				      const int Delta_iMmu_in_13_last = SDmu_one_jump_13_last.get_Delta_iM_in ();

				      if (Delta_iMmu_in_abs_Mmu <= Delta_iMmu_in_13_last)
					{
					  const unsigned int C_one_jump_13_mu_debut_index = configuration_one_jump_table_mu.index_determine (BPmu_inter , n_scat_mu_inter , iCmu_inter , BPmu_in , 0);

					  const unsigned int C_one_jump_13_mu_end_index = C_one_jump_13_mu_debut_index + (dimension_configuration_one_jump_subtable_mu_13 - 1);

					  const int im_s0_abs_Mmu_inter = SDmu_one_jump_02.get_im_in ();

					  const int im_s0 = (is_Mmu_inter_negative) ? (two_m_max_mu - im_s0_abs_Mmu_inter) : (im_s0_abs_Mmu_inter);

					  const int im_s2 = im_s0 + two_m_max_mu - Delta_iMmu_inter;
					  
					  const unsigned int s0 = one_body_indices_mu(s0_shell_index , im_s0);
					  const unsigned int s2 = one_body_indices_mu(s2_shell_index , im_s2);

					  const unsigned int bin_phase_out_to_inter = SDmu_one_jump_02.get_bin_phase ();
			   
					  const unsigned long int SDmu_TRS_reordering_bin_phases_C_abs_Mmu_inter_index = SDmu_TRS_reordering_bin_phases_C_abs_Mmu_inter_zero_index + SDmu_inter_index_abs_Mmu_inter;

					  const unsigned int TRS_reordering_bin_phase_SDmu_inter = SDmu_TRS_reordering_bin_phases[SDmu_TRS_reordering_bin_phases_C_abs_Mmu_inter_index];

					  const unsigned int TRS_reordering_bin_phase_out_to_inter = (is_Mmu_inter_negative) ? (binary_parity_product (TRS_reordering_bin_phase_outSDmu , TRS_reordering_bin_phase_SDmu_inter)) : (0);

					  const unsigned int total_bin_phase_out_to_inter = binary_parity_product (bin_phase_out_to_inter , TRS_reordering_bin_phase_out_to_inter);

					  const unsigned long int SDmu_one_jump_13_debut_index = SDmu_one_jump_table.debut_index_good_iM_in_determine (Delta_iMmu_in_abs_Mmu , dimension_SDmu_one_jump_subtable_13 , SDmu_one_jump_13_zero_index);
					  
					  const unsigned long int SDmu_one_jump_13_end_index = SDmu_one_jump_table.end_index_good_iM_in_determine (Delta_iMmu_in_abs_Mmu , dimension_SDmu_one_jump_subtable_13 , SDmu_one_jump_13_zero_index);
				      
					  unsigned int SDmu_one_jump_13_index = SDmu_one_jump_13_debut_index;

					  unsigned int SDmu_one_jump_C_eq_deb_13_index = SDmu_one_jump_13_debut_index;

					  unsigned int C_eq_one_jump_mu_index_13_bef = 0;
			      
					  for (unsigned int C_one_jump_13_mu_index = C_one_jump_13_mu_debut_index ; C_one_jump_13_mu_index <= C_one_jump_13_mu_end_index ; C_one_jump_13_mu_index++)
					    {
					      const class configuration_one_jump_data_out_to_in_str &C_one_jump_13 = configuration_one_jump_table_mu[C_one_jump_13_mu_index];
				  
					      const int n_holes_mu_in = C_one_jump_13.get_n_holes_in ();
					      
					      const int n_scat_mu_in = C_one_jump_13.get_n_scat_in ();
							      
					      if (!truncation_ph || ((n_holes_mu_in <= n_holes_max_mu) && (n_scat_mu_in <= n_scat_max_mu)))
						{
						  const unsigned int iCmu_in = C_one_jump_13.get_iC_in ();

						  if (!is_configuration_in_in_space_mu_tab(BPmu_in , n_scat_mu_in , iCmu_in)) continue;
						  
						  if (is_it_one_configuration_case && (iCmu_in != iCmu_out)) continue;
				      
						  const unsigned int s1_shell_index = C_one_jump_13.get_C_in_shell ();
						  const unsigned int s3_shell_index = C_one_jump_13.get_C_out_shell ();
						  
						  const class nlj_struct &shell_s1 = shells_qn(s1_shell_index);
						  const class nlj_struct &shell_s3 = shells_qn(s3_shell_index);
						  
						  const int e1 = shell_s1.get_e_trunc ();
						  const int e3 = shell_s3.get_e_trunc ();

						  const bool is_it_energy_truncation_case = (truncation_hw && (Emu_hw_out + e1 - e3 > Emu_max_hw));
						  
						  const bool is_it_shell_normal_case = ((s2_shell_index <= s3_shell_index) && (s0_shell_index <= s1_shell_index));

						  const bool is_it_shell_energy_truncation_case = (is_it_energy_truncation_case && (s3_shell_index <= s2_shell_index) && (s1_shell_index <= s0_shell_index));

						  const unsigned int C_eq_one_jump_mu_index_13 = C_one_jump_13.get_C_eq_one_jump_index ();
	  
						  if (is_it_shell_normal_case || is_it_shell_energy_truncation_case)
						    {
						      const int Emu_hw_in = Emu_hw_table(BPmu_in , n_scat_mu_in , iCmu_in);

						      if (!truncation_hw || (Emu_hw_in <= Emu_max_hw))
							{
							  const unsigned long int is_inSDmu_in_space_C_Mmu_in_zero_index = is_inSDmu_in_space_tab.index_determine (BPmu_in , n_scat_mu_in , iCmu_in , iMmu_in , 0);

							  const unsigned long int SDmu_TRS_indices_C_abs_Mmu_in_zero_index = SDmu_TRS_indices.index_determine (BPmu_in , n_scat_mu_in , iCmu_in , iMmu_in_abs_Mmu , 0);

							  const unsigned long int SDmu_TRS_reordering_bin_phases_C_abs_Mmu_in_zero_index = SDmu_TRS_reordering_bin_phases.index_determine (BPmu_in , n_scat_mu_in , iCmu_in , iMmu_in_abs_Mmu , 0);

							  bool is_configuration_changing = true;

							  if ((C_one_jump_13_mu_index > C_one_jump_13_mu_debut_index) && (C_eq_one_jump_mu_index_13 == C_eq_one_jump_mu_index_13_bef))
							    SDmu_one_jump_13_index = SDmu_one_jump_C_eq_deb_13_index;
							  else
							    {
							      while ((SDmu_one_jump_13_index <= SDmu_one_jump_13_end_index) && (SDmu_one_jump_table[SDmu_one_jump_13_index].get_C_eq_one_jump_index () < C_eq_one_jump_mu_index_13))
								SDmu_one_jump_13_index++;
						  
							      SDmu_one_jump_C_eq_deb_13_index = SDmu_one_jump_13_index;
							    }
					            
							  while ((SDmu_one_jump_13_index <= SDmu_one_jump_13_end_index) && (SDmu_one_jump_table[SDmu_one_jump_13_index].get_C_eq_one_jump_index () == C_eq_one_jump_mu_index_13))
							    {
							      const class SD_one_jump_data_out_to_in_str &SDmu_one_jump_13 = SDmu_one_jump_table[SDmu_one_jump_13_index];
						  
							      const unsigned int inSDmu_index_abs_Mmu_in = SDmu_one_jump_13.get_inSD_index ();

							      const unsigned long int SDmu_TRS_indices_C_abs_Mmu_in_index = (is_Mmu_in_negative) ? (SDmu_TRS_indices_C_abs_Mmu_in_zero_index + inSDmu_index_abs_Mmu_in)	: (NADA);

							      const unsigned int inSDmu_index = (is_Mmu_in_negative) ? (SDmu_TRS_indices[SDmu_TRS_indices_C_abs_Mmu_in_index]) : (inSDmu_index_abs_Mmu_in);

							      const unsigned long int is_inSDmu_in_space_C_Mmu_in_index = is_inSDmu_in_space_C_Mmu_in_zero_index + inSDmu_index;
								   
							      if (is_inSDmu_in_space_tab[is_inSDmu_in_space_C_Mmu_in_index])
								{
								  const int im_s1_abs_Mmu_in = SDmu_one_jump_13.get_im_in ();

								  const int im_s1 = (is_Mmu_in_negative) ? (two_m_max_mu - im_s1_abs_Mmu_in) : (im_s1_abs_Mmu_in);
								  
								  const unsigned int s1 = one_body_indices_mu(s1_shell_index , im_s1);
						  
								  if ((s1 != s2) && (is_it_energy_truncation_case || (s0 < s1)))
								    {
								      const int im_s3 = im_s1 + two_m_max_mu - Delta_iMmu_in;

								      const unsigned int s3 = one_body_indices_mu(s3_shell_index , im_s3);
						  	
								      if ((s3 != s0) && (is_it_energy_truncation_case || (s2 < s3)))
									{
									  const bool all_ordered_normal_case = ((s2 < s3) && (s0 < s1));

									  const bool all_ordered_energy_truncation_case = (is_it_energy_truncation_case && (s3 < s2) && (s1 < s0));
			      						      
									  if (all_ordered_normal_case || all_ordered_energy_truncation_case)
									    {							      
									      const unsigned int bin_phase_inter_to_in = SDmu_one_jump_13.get_bin_phase ();
							      
									      const unsigned int left_in  = (all_ordered_normal_case) ? (s0) : (s1);
									      const unsigned int right_in = (all_ordered_normal_case) ? (s1) : (s0);
									      
									      const unsigned int left_out  = (all_ordered_normal_case) ? (s2) : (s3);
									      const unsigned int right_out = (all_ordered_normal_case) ? (s3) : (s2);

									      const unsigned long int SDmu_TRS_reordering_bin_phases_C_abs_Mmu_in_index = SDmu_TRS_reordering_bin_phases_C_abs_Mmu_in_zero_index + inSDmu_index_abs_Mmu_in;

									      const unsigned int TRS_reordering_bin_phase_inSDmu = SDmu_TRS_reordering_bin_phases[SDmu_TRS_reordering_bin_phases_C_abs_Mmu_in_index];

									      const unsigned int TRS_reordering_bin_phase_inter_to_in = (is_Mmu_in_negative) ? (binary_parity_product (TRS_reordering_bin_phase_SDmu_inter , TRS_reordering_bin_phase_inSDmu))	: (0);

									      const unsigned int total_bin_phase_inter_to_in = binary_parity_product (bin_phase_inter_to_in , TRS_reordering_bin_phase_inter_to_in);

									      const unsigned int total_bin_phase_mu = binary_parity_product (total_bin_phase_out_to_inter , total_bin_phase_inter_to_in);
									      
									      table(dimension++).initialize (n_holes_mu_in , n_scat_mu_in , iCmu_in , inSDmu_index , total_bin_phase_mu , is_configuration_changing , left_in , right_in , left_out , right_out , Emu_hw_in);

									      is_configuration_changing = false;

									    }}}}

							      SDmu_one_jump_13_index++;

							    }}
						      
						      C_eq_one_jump_mu_index_13_bef = C_eq_one_jump_mu_index_13;

						    }}}}}}
			      
			      SDmu_one_jump_02_index++;

			    }

			  C_eq_one_jump_mu_index_02_bef = C_eq_one_jump_mu_index_02;

			}}}}}}
  
  
  if (space == PROTONS_NEUTRONS) reorder_minimal_configuration_changes ();
}





