#include "../GSM_include/GSM_include_def.h"


using namespace inputs_misc;
using namespace GSM_vector_NBMEs_handling;
using namespace GSM_vector_NBMEs_handling::in_to_out;
using namespace GSM_vector_dimensions;
using namespace MPI_2D_partitioning;
using namespace configuration_SD_in_space_one_jump_in_to_out;


// TYPE is double or complex
// -------------------------


// OBMEs means one-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons
// ------------------------------------------------------------------------------------------------------------------------------------------------------

// Jpm means J+ or J-, as pm = +/1. One uses Jpm for J+ or J- in all Jpm classes files.
//
// One uses Jpm in J^2 = J-.J+ + Jz.(Jz + 1), and to generate |J M> Hamiltonian eigenstates for all M values starting from an eigenstate with a fixed M value.
//
// Non-zero NBMEs of Jpm are calculated and stored therein. Array dimensions have been calculated in GSM_Jpm_class_non_zero_NBMEs_numbers.cpp .
//
// One calculates non-zero NBMEs occurring in one node only as they are not used in other nodes due to Hamiltonian hybrid 1D/2D partitioning (see GSM_vector.cpp).
//
// One loops over proton and neutron Slater determinants, the first loop being proton or neutron according to the case.
//
//
//
// hybrid 1D/2D partitioning
// -------------------------------------
// One uses hybrid 1D/2D partitioning for GSM vectors and operators, so that each node takes care of only one part of the input and output GSM vectors (2D partitioning), but where operators are stored as columns on each node(1D partitioning):
//
//        J+/-         x  Psi[in]  =  Psi[out]
// * n * n * n * n *        *           *   
// *   *   *   *   *      node 0       node 0
// * o * o * o * o *        *           *
// *   *   *   *   *      node 1       node 1
// * d * d * d * d *        *           *
// *   *   *   *   *      node 2       node 2
// * e * e * e * e *        *           *
// *   *   *   *   *      node 3       node 3
// * 0 * 1 * 2 * 3 *        *           *
//                                                  
// Hence, each node calculates only part of Psi[out] and stores only part of J+/-.
// What is called a square is a part of J+/- connecting the node i storing a part of |Psi[in]> to the node j storing a part of |Psi[out]>.
// An MPI communication of all newly calculated components on each row to the node taking care of the considered part of |Psi[out]> has to be done.
// However, as J+/- does not induce configuration mixing, it is localized on one node except for side effects.
// Hence, one just has to transfer the newly calculated non-zero components of J+/-|Psi[in]> from one node to another, which are in a very small number. 
// If OpenMP is used, MPI communications are overlapped with computation. For this, one uses two J+/-|Psi[in]> vector parts, one for even rows and one for odd rows.
// When one loops over rows, a J+/-|Psi[in]> part is transfered by one core, while the other cores calculate the other part. 
//
//
// For the construction of the J+/- matrix, loops are on in tables but output is on out tables to obtain the scheme above, so that OpenMP race conditions have to be avoided.
// OpenMP loops are then done on configurations indices as there is no configuration mixing induced by J+/-:
// iCp in one_jump_p_part_pn_calc_store as iCp_in = iCp_out = iCp so that the same outSD index cannot occur in different Cp's
// iCn in one_jump_n_part_pn_calc_store as iCn_in = iCn_out = iCn so that the same outSD index cannot occur in different Cn's
// iC in non_zero_NBMEs_numbers_pp_nn_calc as iC_in = iC_out = iC so that the same outSD index cannot occur in different C's
// See below for notations.
//
//
// non_zero_NBMEs_numbers_pp_nn_calc
// ---------------------------------
// This provides with the number of non-zero off-diagonal NBMEs for 1p-1h jumps from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// This routine is used when one has valence protons only or valence neutrons only.
// In this routine, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the number of non-zero NBMEs from them.
//
//
// non_zero_NBMEs_numbers_one_jump_p_part_pn_calc, non_zero_NBMEs_numbers_one_jump_n_part_pn_calc
// ----------------------------------------------------------------------------------------------
// This provides with the number of non-zero off-diagonal NBMEs for 1p-1h jumps from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// These routines are used when one has both valence protons and neutrons.
// In these routines, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the number of non-zero NBMEs from them.
//
// non_zero_NBMEs_numbers_pp_nn_calc
// ---------------------------------
// This provides with the number of non-zero off-diagonal NBMEs for 1p-1h jumps from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// This routine is used when one has valence protons only or valence neutrons only.
// In this routine, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the number of non-zero NBMEs from them.
//
// squares_non_zero_NBMEs_numbers_calc
// -----------------------------------
// This routine calls the previous routine and calculates the number of non-zero NBMEs for all the squares of Jpm for each node.
//
//
//
// total means that one considers the index of the SD of the full GSM vector, not of part of it in a node (see GSM_vector_helper.cpp).

void Jpm_class::non_zero_NBMEs_numbers_pp_nn_calc (
						   const class jumps_data_in_to_out_str &one_jump , 
						   const class array<bool> &is_PSI_out_index_accepted_tab , 
						   const class array<unsigned int> &square_row_indices ,  
						   const class array<unsigned int> &PSI_out_indices)
{
  const unsigned int dimension_one_jump = one_jump.get_dimension ();
  
  for (unsigned int i = 0 ; i < dimension_one_jump ; i++)
    {
      const bool is_PSI_out_index_accepted = is_PSI_out_index_accepted_tab(i);

      if (is_PSI_out_index_accepted)
	{
	  const unsigned int square_row_index = square_row_indices(i);
	  
	  const unsigned int PSI_out_index = PSI_out_indices(i);
	
	  squares_non_zero_NBMEs_numbers(square_row_index , PSI_out_index)++;
	}
    }
}






void Jpm_class::non_zero_NBMEs_numbers_one_jump_p_part_pn_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
 
  const bool truncation_hw = GSM_vector_helper_in.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_in.get_truncation_ph ();

  const class nucleons_data &prot_data = GSM_vector_helper_in.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_in.get_neut_data ();

  const int n_holes_max_p = GSM_vector_helper_in.get_n_holes_max_p ();
  
  const int n_scat_max_p = GSM_vector_helper_in.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_in.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper_in.get_Ep_max_hw ();

  const int iMp_max = prot_data.get_iM_max ();

  const unsigned int BP = GSM_vector_helper_in.get_BP ();

  const int iMp_in_min_M = GSM_vector_helper_in.get_iMp_min_M ();
  const int iMp_in_max_M = GSM_vector_helper_in.get_iMp_max_M ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();

  const class array_BP_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper_in.get_all_dimensions_SDn_zero_tab ();
  
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper_in.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper_in.get_last_total_PSI_index ();

  const unsigned int dimension_configuration_total_n = neut_data.get_dimension_configuration_total ();

  const class array<unsigned int> &sum_dimensions_configuration_set_n = neut_data.get_sum_dimensions_configuration_set ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();

  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();

  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper_in.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper_in.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper_in.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper_in.get_iCn_max_process_tab ();
  
  class array<class jumps_data_in_to_out_str> one_jump_p_tab(NUMBER_OF_THREADS);

  class array<class array_BP_Nscat_iC<bool> > is_configuration_accepted_tabs(NUMBER_OF_THREADS);

  class array<class array_BP_Nscat_iC<unsigned int> > dimensions_SDn_Mn_fixed_tab(NUMBER_OF_THREADS);

  class array<class array_BP_Nscat_iC<unsigned int> > sum_dimensions_configuration_Mp_Mn_fixed_in_tabs(NUMBER_OF_THREADS);

  class array<class array<bool> > is_PSI_out_index_accepted_one_jump_p_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > square_row_indices_one_jump_p_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > PSI_out_indices_one_jump_p_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_p_tab(i).allocate (ONE_JUMP , PROTONS_NEUTRONS , truncation_hw , truncation_ph , Zval);

      is_configuration_accepted_tabs(i).allocate (dimension_configuration_total_n , sum_dimensions_configuration_set_n);	      

      dimensions_SDn_Mn_fixed_tab(i).allocate (dimension_configuration_total_n , sum_dimensions_configuration_set_n);

      sum_dimensions_configuration_Mp_Mn_fixed_in_tabs(i).allocate (dimension_configuration_total_n , sum_dimensions_configuration_set_n);
      
      is_PSI_out_index_accepted_one_jump_p_tabs(i).allocate (Zval);	      

      square_row_indices_one_jump_p_tab(i).allocate (Zval);      

      PSI_out_indices_one_jump_p_tab(i).allocate (Zval);
    }
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP);

      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , n_scat_p);

	  if (iCp_max < iCp_min) continue;
	  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif    
	  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
	    {
	      const unsigned int i_thread = OpenMP_thread_number_determine ();
	      
	      class jumps_data_in_to_out_str &one_jump_p = one_jump_p_tab(i_thread);
	      
	      class array_BP_Nscat_iC<bool> &is_configuration_accepted_tab = is_configuration_accepted_tabs(i_thread);
	      
	      class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_Mn_fixed = dimensions_SDn_Mn_fixed_tab(i_thread);

	      class array_BP_Nscat_iC<unsigned int> &sum_dimensions_configuration_Mp_Mn_fixed_in_tab = sum_dimensions_configuration_Mp_Mn_fixed_in_tabs(i_thread);
	      
	      class array<bool> &is_PSI_out_index_accepted_one_jump_p_tab = is_PSI_out_index_accepted_one_jump_p_tabs(i_thread);	      

	      class array<unsigned int> &square_row_indices_one_jump_p = square_row_indices_one_jump_p_tab(i_thread);

	      class array<unsigned int> &PSI_out_indices_one_jump_p = PSI_out_indices_one_jump_p_tab(i_thread);

	      bool is_configuration_accepted_tab_filled = false;
	      	  
	      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
		{
		  const int iMp_out = iMp_in + pm;

		  if ((iMp_out < 0) || (iMp_out > iMp_max)) continue;

		  const unsigned int dimension_inSDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp_in);	      

		  if (dimension_inSDp == 0) continue;


		  const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , n_scat_p , iCp , iMp_in);
		  if (all_dimensions_SDn_zero) continue;

		  const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

		  const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);

		  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

		  if (!is_configuration_accepted_tab_filled)
		    {
		      is_configuration_accepted_neut_fill (n_holes_p , n_scat_p , Ep , BPn , GSM_vector_helper_in , is_configuration_accepted_tab);

		      is_configuration_accepted_tab_filled = true;
		    }

		  dimensions_SDn_sum_dimensions_configuration_Mp_Mn_fixed_neut_fill (BPp , n_scat_p , iCp , iMp_in , GSM_vector_helper_in , is_configuration_accepted_tab ,
										     dimensions_SDn_Mn_fixed , sum_dimensions_configuration_Mp_Mn_fixed_in_tab);

		  for (unsigned int inSDp_index = 0 ; inSDp_index < dimension_inSDp ; inSDp_index++)
		    {
		      bool jump_p_calculated = false;

		      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
			{
			  const unsigned int is_configuration_accepted_tab_BP_n_scat_n_zero_index = is_configuration_accepted_tab.index_determine (BPn , n_scat_n , 0);

			  const unsigned int dimensions_SDn_Mn_fixed_BP_n_scat_n_zero_index = dimensions_SDn_Mn_fixed.index_determine(BPn , n_scat_n , 0);
			  
			  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in_BP_n_scat_n_tab_zero_index = sum_dimensions_configuration_Mp_Mn_fixed_in_tab.index_determine(BPn , n_scat_n , 0);

			  const unsigned int iCn_min = iCn_min_process_tab(BPn , n_scat_n);
			  const unsigned int iCn_max = iCn_max_process_tab(BPn , n_scat_n);
		  
			  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
			    { 
			      const unsigned int is_configuration_accepted_tab_index = is_configuration_accepted_tab_BP_n_scat_n_zero_index + iCn;

			      const bool is_configuration_accepted = is_configuration_accepted_tab[is_configuration_accepted_tab_index];

			      if (is_configuration_accepted)
				{
				  const unsigned int dimensions_SDn_Mn_fixed_index = dimensions_SDn_Mn_fixed_BP_n_scat_n_zero_index + iCn;

				  const unsigned int dimension_SDn = dimensions_SDn_Mn_fixed[dimensions_SDn_Mn_fixed_index];

				  if (dimension_SDn == 0) continue;

				  const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in_index = sum_dimensions_configuration_Mp_Mn_fixed_in_BP_n_scat_n_tab_zero_index + iCn;

				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_configuration_Mp_Mn_fixed_in_tab[sum_dimensions_configuration_Mp_Mn_fixed_in_index];

				  const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_SDn*inSDp_index;

				  const unsigned long int total_PSI_in_index_dimension_minus_one = total_PSI_in_index_zero + dimension_SDn_minus_one;
				  
				  if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
				    {
				      if (!jump_p_calculated)
					{
					  one_jump_p.one_jump_mu_Jpm_store (pm , BPp , n_scat_p , iCp , iMp_in , inSDp_index , prot_data);

					  jump_p_calculated = true;
					}
				      
				      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				      
				      if (dimension_one_jump_p > 0)
					{
					  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
					    {
					      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero + SDn_index;

					      if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						{
						  bool is_there_jump_calc = false;
						  
						  are_PSI_out_indices_accepted_PSI_out_indices_prot_fill_Jpm (n_scat_n , iCn , SDn_index , BPp , iCp , n_scat_p , iMp_out , one_jump_p ,
													      GSM_vector_helper_out , dimension_SDn , is_PSI_out_index_accepted_one_jump_p_tab ,
													      square_row_indices_one_jump_p , PSI_out_indices_one_jump_p , is_there_jump_calc);
						  
						  if (is_there_jump_calc) non_zero_NBMEs_numbers_pp_nn_calc (one_jump_p , is_PSI_out_index_accepted_one_jump_p_tab , square_row_indices_one_jump_p , PSI_out_indices_one_jump_p);
						}}}}}}}}}}}}
}




void Jpm_class::non_zero_NBMEs_numbers_one_jump_n_part_pn_calc ()
{   
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  const bool truncation_hw = GSM_vector_helper_in.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_in.get_truncation_ph ();

  const class nucleons_data &prot_data = GSM_vector_helper_in.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_in.get_neut_data ();

  const int n_holes_max_n = GSM_vector_helper_in.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_in.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_in.get_n_scat_max_n ();

  const int En_max_hw = GSM_vector_helper_in.get_En_max_hw ();

  const int iMn_max = neut_data.get_iM_max ();

  const unsigned int BP = GSM_vector_helper_in.get_BP ();

  const int iM_in = GSM_vector_helper_in.get_iM ();
  
  const int iMn_in_min_M = GSM_vector_helper_in.get_iMn_min_M ();
  const int iMn_in_max_M = GSM_vector_helper_in.get_iMn_max_M ();
  
  const int Nval = neut_data.get_N_valence_nucleons ();

  const class array_BP_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper_in.get_all_dimensions_SDp_zero_tab ();

  const unsigned int dimension_configuration_total_p = prot_data.get_dimension_configuration_total ();

  const class array<unsigned int> &sum_dimensions_configuration_set_p = prot_data.get_sum_dimensions_configuration_set ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();  
  
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper_in.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper_in.get_last_total_PSI_index ();

  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper_in.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper_in.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper_in.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper_in.get_iCn_max_process_tab ();
  
  class array<class jumps_data_in_to_out_str> one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array_BP_Nscat_iC<bool> > is_configuration_accepted_tabs(NUMBER_OF_THREADS);

  class array<class array_BP_Nscat_iC<unsigned int> > dimensions_SDp_Mp_fixed_tab(NUMBER_OF_THREADS);

  class array<class array_BP_Nscat_iC<unsigned int> > sum_dimensions_configuration_Mp_Mn_fixed_in_tabs(NUMBER_OF_THREADS);

  class array<class array<bool> > is_PSI_out_index_accepted_one_jump_n_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > square_row_indices_one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > PSI_out_indices_one_jump_n_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_n_tab(i).allocate (ONE_JUMP , PROTONS_NEUTRONS , truncation_hw , truncation_ph , Nval);

      is_configuration_accepted_tabs(i).allocate (dimension_configuration_total_p , sum_dimensions_configuration_set_p);	      

      dimensions_SDp_Mp_fixed_tab(i).allocate (dimension_configuration_total_p , sum_dimensions_configuration_set_p);

      sum_dimensions_configuration_Mp_Mn_fixed_in_tabs(i).allocate (dimension_configuration_total_p , sum_dimensions_configuration_set_p);
      
      is_PSI_out_index_accepted_one_jump_n_tabs(i).allocate (Nval);	      

      square_row_indices_one_jump_n_tab(i).allocate (Nval);      

      PSI_out_indices_one_jump_n_tab(i).allocate (Nval);
    }
  
  for (unsigned int BPn = 0 ; BPn <= 1 ; BPn++)
    {
      const unsigned int BPp = binary_parity_product (BPn , BP);

      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_process_tab(BPn , n_scat_n);
	  const unsigned int iCn_max = iCn_max_process_tab(BPn , n_scat_n);

	  if (iCn_max < iCn_min) continue;
	  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
	  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
	    {
	      const unsigned int i_thread = OpenMP_thread_number_determine ();
	      
	      class jumps_data_in_to_out_str &one_jump_n = one_jump_n_tab(i_thread);
	      
	      class array_BP_Nscat_iC<bool> &is_configuration_accepted_tab = is_configuration_accepted_tabs(i_thread);
	      
	      class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_Mp_fixed = dimensions_SDp_Mp_fixed_tab(i_thread);

	      class array_BP_Nscat_iC<unsigned int> &sum_dimensions_configuration_Mp_Mn_fixed_in_tab = sum_dimensions_configuration_Mp_Mn_fixed_in_tabs(i_thread);
	      
	      class array<bool> &is_PSI_out_index_accepted_one_jump_n_tab = is_PSI_out_index_accepted_one_jump_n_tabs(i_thread);	      

	      class array<unsigned int> &square_row_indices_one_jump_n = square_row_indices_one_jump_n_tab(i_thread);

	      class array<unsigned int> &PSI_out_indices_one_jump_n = PSI_out_indices_one_jump_n_tab(i_thread);
	      
	      bool is_configuration_accepted_tab_filled = false; 

	      for (int iMn_in = iMn_in_min_M ; iMn_in <= iMn_in_max_M ; iMn_in++)
		{
		  const int iMn_out = iMn_in + pm;

		  const int iMp = iM_in - iMn_in;

		  if ((iMn_out < 0) || (iMn_out > iMn_max)) continue;

		  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn_in);
		  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn_out);

		  if ((dimension_inSDn == 0) || (dimension_outSDn == 0)) continue;

		  const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , n_scat_n , iCn , iMn_in);

		  if (all_dimensions_SDp_zero) continue;

		  const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
		  const int En = En_hw_table(BPn , n_scat_n , iCn);

		  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

		  if (!is_configuration_accepted_tab_filled)
		    {
		      is_configuration_accepted_prot_fill (n_holes_n , n_scat_n , En , BPp , GSM_vector_helper_in , is_configuration_accepted_tab);

		      is_configuration_accepted_tab_filled = true;
		    }

		  dimensions_SDp_sum_dimensions_configuration_Mp_Mn_fixed_prot_fill (BPn , n_scat_n , iCn , iMn_in , GSM_vector_helper_in , is_configuration_accepted_tab ,
										     dimensions_SDp_Mp_fixed , sum_dimensions_configuration_Mp_Mn_fixed_in_tab);

		  for (unsigned int inSDn_index = 0 ; inSDn_index < dimension_inSDn ; inSDn_index++)
		    {
		      bool jump_n_calculated = false;

		      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
			{
			  const unsigned int is_configuration_accepted_tab_BP_n_scat_p_zero_index = is_configuration_accepted_tab.index_determine (BPp , n_scat_p , 0);

			  const unsigned int dimensions_SDp_Mp_fixed_BP_n_scat_p_zero_index = dimensions_SDp_Mp_fixed.index_determine(BPp , n_scat_p , 0);

			  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in_BP_n_scat_p_tab_zero_index = sum_dimensions_configuration_Mp_Mn_fixed_in_tab.index_determine(BPp , n_scat_p , 0);

			  const unsigned int iCp_min = iCp_min_process_tab(BPp , n_scat_p);
			  const unsigned int iCp_max = iCp_max_process_tab(BPp , n_scat_p);
	  
			  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
			    {
			      const unsigned int is_configuration_accepted_tab_index = is_configuration_accepted_tab_BP_n_scat_p_zero_index + iCp;

			      const bool is_configuration_accepted = is_configuration_accepted_tab[is_configuration_accepted_tab_index];

			      if (is_configuration_accepted)
				{
				  const unsigned int dimensions_SDp_Mp_fixed_index = dimensions_SDp_Mp_fixed_BP_n_scat_p_zero_index + iCp;

				  const unsigned int dimension_SDp = dimensions_SDp_Mp_fixed[dimensions_SDp_Mp_fixed_index];

				  if (dimension_SDp == 0) continue;

				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in_index = sum_dimensions_configuration_Mp_Mn_fixed_in_BP_n_scat_p_tab_zero_index + iCp;

				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_configuration_Mp_Mn_fixed_in_tab[sum_dimensions_configuration_Mp_Mn_fixed_in_index];

				  const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

				  const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;

				  const unsigned long int total_PSI_in_index_dimension_minus_one = total_PSI_in_index_zero + dimension_inSDn*dimension_SDp_minus_one;

				  if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
				    {
				      if (!jump_n_calculated)
					{
					  one_jump_n.one_jump_mu_Jpm_store (pm , BPn , n_scat_n , iCn , iMn_in , inSDn_index , neut_data);

					  jump_n_calculated = true;
					}
					      
				      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

				      if (dimension_one_jump_n > 0)
					{
					  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
					    {
					      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero + dimension_inSDn*SDp_index;

					      if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						{					      
						  bool is_there_jump_calc = false;
					      
						  are_PSI_out_indices_accepted_PSI_out_indices_neut_fill_Jpm (BPp , n_scat_p , iCp , iMp , SDp_index , n_scat_n , iCn , one_jump_n ,
													      GSM_vector_helper_out , dimension_outSDn , is_PSI_out_index_accepted_one_jump_n_tab ,
													      square_row_indices_one_jump_n , PSI_out_indices_one_jump_n , is_there_jump_calc);
					      
						  if (is_there_jump_calc) non_zero_NBMEs_numbers_pp_nn_calc (one_jump_n , is_PSI_out_index_accepted_one_jump_n_tab , square_row_indices_one_jump_n , PSI_out_indices_one_jump_n);
						}}}}}}}}}}}}
}







void Jpm_class::non_zero_NBMEs_numbers_pp_nn_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  const enum space_type space = GSM_vector_helper_in.get_space ();

  const bool truncation_hw = GSM_vector_helper_in.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_in.get_truncation_ph ();

  const class nucleons_data &prot_data = GSM_vector_helper_in.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_in.get_neut_data ();

  const int n_holes_max = GSM_vector_helper_in.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_in.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_in.get_E_max_hw ();

  const unsigned int BP = GSM_vector_helper_in.get_BP ();
  
  const int iM_in = GSM_vector_helper_in.get_iM ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_in = GSM_vector_helper_in.get_sum_dimensions_GSM_vector ();

  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);

  const int N_valence_nucleons = data.get_N_valence_nucleons ();
  
  const class array_BP_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();
  
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper_in.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper_in.get_last_total_PSI_index ();

  const class array<unsigned int> &iC_min_process_tab = GSM_vector_helper_in.get_iC_min_process_tab ();
  const class array<unsigned int> &iC_max_process_tab = GSM_vector_helper_in.get_iC_max_process_tab ();
  
  class array<class jumps_data_in_to_out_str> one_jump_mu_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_PSI_out_index_accepted_one_jump_mu_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > square_row_indices_one_jump_mu_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > PSI_out_indices_one_jump_mu_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_mu_tab(i).allocate (ONE_JUMP , space , truncation_hw , truncation_ph , N_valence_nucleons);
      
      is_PSI_out_index_accepted_one_jump_mu_tabs(i).allocate (N_valence_nucleons);	      

      square_row_indices_one_jump_mu_tab(i).allocate (N_valence_nucleons);      

      PSI_out_indices_one_jump_mu_tab(i).allocate (N_valence_nucleons);
    }
  
  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int iC_min = iC_min_process_tab(n_scat);
      const unsigned int iC_max = iC_max_process_tab(n_scat);

      if (iC_max < iC_min) continue;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
      for (unsigned int iC = iC_min ; iC <= iC_max ; iC++)
	{
	  const int n_holes = n_holes_table(BP , n_scat , iC);
	  
	  const int E = E_hw_table(BP , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned long int sum_dimensions_configuration_fixed_in = sum_dimensions_GSM_vector_in(n_scat , iC);

	  const unsigned int dimension_inSD_set = dimensions_SD_set(BP , n_scat , iC , iM_in);

	  if (dimension_inSD_set == 0) continue;

	  const unsigned int dimension_inSD_set_minus_one = dimension_inSD_set - 1;

	  const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_fixed_in;

	  const unsigned long int total_PSI_in_index_dimension_minus_one = total_PSI_in_index_zero + dimension_inSD_set_minus_one;
	  
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	      
	  class jumps_data_in_to_out_str &one_jump_mu = one_jump_mu_tab(i_thread);
	      	      
	  class array<bool> &is_PSI_out_index_accepted_one_jump_mu_tab = is_PSI_out_index_accepted_one_jump_mu_tabs(i_thread);	      

	  class array<unsigned int> &square_row_indices_one_jump_mu = square_row_indices_one_jump_mu_tab(i_thread);

	  class array<unsigned int> &PSI_out_indices_one_jump_mu = PSI_out_indices_one_jump_mu_tab(i_thread);
	      
	  if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
	    {
	      for (unsigned int inSD_index = 0 ; inSD_index < dimension_inSD_set ; inSD_index++)
		{
		  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero + inSD_index;

		  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
		    {
		      one_jump_mu.one_jump_mu_Jpm_store (pm , BP , n_scat , iC , iM_in , inSD_index , data);

		      const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();
  
		      bool is_there_jump_calc = (dimension_one_jump_mu > 0);
		      
		      if (is_there_jump_calc)
			{
			  are_PSI_out_indices_accepted_PSI_out_indices_pp_nn_fill_Jpm (n_scat , iC , one_jump_mu , GSM_vector_helper_out ,
										       is_PSI_out_index_accepted_one_jump_mu_tab , square_row_indices_one_jump_mu , PSI_out_indices_one_jump_mu , is_there_jump_calc);
			  
			  if (is_there_jump_calc) non_zero_NBMEs_numbers_pp_nn_calc (one_jump_mu , is_PSI_out_index_accepted_one_jump_mu_tab , square_row_indices_one_jump_mu , PSI_out_indices_one_jump_mu);			    
			}}}}}}
}






void Jpm_class::squares_non_zero_NBMEs_numbers_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();

  const enum space_type space = GSM_vector_helper_out.get_space ();

  class nucleons_data &prot_data = GSM_vector_helper_in.get_prot_data ();
  class nucleons_data &neut_data = GSM_vector_helper_in.get_neut_data ();

  squares_non_zero_NBMEs_numbers = 0;

  if (configuration_SD_one_jump_tables_to_recalculate)
    {
      configuration_SD_in_out_in_space_one_jump_tables_alloc_calc_Jpm (is_there_cout_detailed , pm , GSM_vector_helper_in , GSM_vector_helper_out , prot_data , neut_data);
      
      if (is_there_cout_detailed && (THIS_PROCESS == MASTER_PROCESS))
	{
	  const string pm_string = (pm == 1) ? ("+") : ("-");
      
	  cout << "---------------------------------------------------------------------------------------------------" << endl;
	  cout << "1p-1h jumps tables for J" << pm_string << " non zero numbers calculated" << endl;  
	  cout << "---------------------------------------------------------------------------------------------------" << endl;
	  cout << endl;
	}	  
    }
  
  if (space == PROTONS_NEUTRONS)
    {
      non_zero_NBMEs_numbers_one_jump_p_part_pn_calc ();
      non_zero_NBMEs_numbers_one_jump_n_part_pn_calc ();
    }
  else
    non_zero_NBMEs_numbers_pp_nn_calc ();
}
