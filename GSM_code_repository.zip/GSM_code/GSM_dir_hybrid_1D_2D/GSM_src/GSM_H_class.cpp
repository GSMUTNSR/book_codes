#include "../GSM_include/GSM_include_def.h"

using namespace inputs_misc;
using namespace MPI_2D_partitioning;
using namespace GSM_vector_NBMEs_handling;
using namespace configuration_SD_in_space_one_jump_out_to_in;

// TYPE is double or complex
// -------------------------

// Class xH_plus_alpha_str is used only in closures and then is not commented.

H_class::H_class () :
  is_there_cout (false) , 
  is_there_cout_detailed (false) , 
  Hamiltonian_storage (NO_STORAGE) ,
  M_TBMEs_storage (NO_STORAGE) , 
  one_jumps_pn_two_jumps_cv_storage (NO_STORAGE) , 
  configuration_SD_one_jump_tables_to_recalculate_for_matrices (false) ,
  is_it_Davidson (false) , 
  is_one_body_p_non_zero (false) , 
  is_one_body_n_non_zero (false) , 
  is_pp_non_zero (false) , 
  is_nn_non_zero (false) , 
  is_pn_non_zero (false) ,
  is_cv_non_zero (false) ,
  J (0.0) , 
  GSM_vector_helper_ptr (NULL) ,  
  PSI_in_full_ptr (NULL) ,
  PSI_in_unoccupied_squares_ptr (NULL) ,
  H_PSI_occupied_squares_ptr (NULL) ,
  H_PSI_table_ptr (NULL) , 
  TBMEs_pn_ptr (NULL) ,
  TBMEs_cv_ptr (NULL)
{}



// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------



// Class applying Hamiltonian plus number times identity to |Psi[in]> to obtain |Psi[out]>
// ----------------------------------------------------------------------------------------
// One has here constructors, destructors, Hamiltonian operator apply call and operators overloading of operations of the type a.H + b.
//
// Routines here besides one_jump_p_tab_all_SDp_calc, one_jump_n_tab_all_SDn_calc, NBMEs_two_jumps_pp_nn_calc_store
// are rather straightforward so that they are not detailed. Only general explanations are given.
//
// The average and maximal memories occupied in MPI ranks and its dispersion are written on screen after memory allocation.
// Indeed, this a measure a load imbalance, which is usually less or about a factor 2 but can be significant nevertheless.
// Average and maximal memories are equal for a sequential calculation and dispersion is equal to zero.
//
// Full storage and on the fly methods can be used.
// One can store either NBMEs or NBMEs indices for the 2p-2h part, with Hamiltonian_storage put to FULL_STORAGE or PARTIAL_STORAGE.
// A NBME index is of the form reordering binary phase + 2.TBME index, where reordering binary phase is 0,1 (see observables_basic_functions.cpp for definition)
// and TBME index is the index the TBME in the array of uncoupled TBMEs M_TBMEs, as NBME = reordering phase . TBME.
// Thus, one can reconstruct the NBME from the NBME index, as TBME index = NBME index/2 and reordering binary phase = NBME index%2.
// As NBMEs are complex numbers and indices are integers, and as one always has to store the associated in Slater determinant index, which is an unsigned integer,
// PARTIAL_STORAGE stores two unsigned integers (4 + 4 = 8 bytes) where FULL_STORAGE stores one complex number and one unsigned integer (16 + 4 = 20 bytes).
// Hence, PARTIAL_STORAGE provides with a memory gain of 2.5 compared to FULL_STORAGE.
// However, PARTIAL_STORAGE is typically slower by a factor of 2-3,
// as one has to look for non-contiguous uncoupled TBMEs in M_TBMEs when looping on in Slater determinants, which takes more time as looping on arrays element after element.
//
// One has different arrays of space dimensions and indices per MPI rank according to the use of time-reversal symmetry (TRS) or not.
// This is because about half of outSD indices are not considered with TRS, as they are recovered by this symmetry at the end of the calculation.
// Hence, half of cores would be idle if they were not suppressed of OpenMP parallelized loops.
// By using different arrays, one does not loop on outSD indices not considered during H.|Psi[in]> when TRS is used.
// This also means that the ..._no_TRS arrays loop on all SDs.
// Associated arrays are allocated and calculated in the constructor
//
//
// used_memory_calc
// ----------------
// This routine calculates the memory used by the class in Mb by looping over its data and adding their used memory.
//
//
// print
// -----
// This routine prints non-zero Hamiltonian NBMEs on screen, This can be used only in a sequential calculation and using the FULL_STORAGE option. It is typically used for tests.
//
//
// apply_add
// ---------
// One calculates |Psi[out]> -> |Psi[out]> + (H + alpha.Id).|Psi[in]>, where alpha is a constant.
// If MPI parallelization is used and |Psi[out]> != 0, |Psi[out]> is firstly transfered to all nodes, as only the master process has a copy of it, and divided by the number of nodes.
// Consequently, the |Psi[out]> parts in all nodes can be summed up in the end to obtain |Psi[out]> -> |Psi[out]> + (H + alpha.Id).|Psi[in]>
//
// TRS is time-reversal symmetry and can be used therein.
// It allows to to calculate about one half of |Psi[out]> if M=0, while the rest is given from the first half up to a phase in |Psi[in]> and |Psi[out]>.
// 
// When recovering the symmetric part of the Hamiltonian matrix, one has to pay attention that inSD and outSD indices are exchanged,
// so that this would create a race condition with OpenMP as OpenMP distribution is done on outSD indices.
// To avoid it, one uses an array of GSM vectors, one for each core.
// This creates no additional memory as such an array is already used to orthogonalize Lanczos or Jacobi/Davidson vectors.
// 
// The time taken for a Hamiltonian times vector operation can be printed on screen.
//
//
// See N. Michel, H. Aktulga, Y. Jaganathen, Computer Physics Communications 247, 106978 (2020) or the book for the 2D partitioning method
//
//
// xH_plus_alpha_str
// -----------------
// Hpa must be understood here as H + alpha.Id (see above).
// Operators overloading of operations are of the type a.Hpa + b.Id, to which operators of the form c.Hpa + d.Id as well can be added. 
// One cannot add another operator to a.Hpa + b.Id besides c.Hpa + d.Id, however, as one would have to call different many-body routines for it, which would be too complicated to handle.
// Indeed, the latter is seen as (a + c).Hpa + (b + d).Id .
// One can use instead (a*Hpa + b)*PSI_0 + J^2*PSI_1 for example, up to 10 terms.
// Products of operators are not accepted with operator overloading.



H_class::H_class (
		  const bool is_there_cout_c ,
		  const bool print_detailed_information , 
		  const enum storage_type Hamiltonian_storage_c , 
		  const enum storage_type M_TBMEs_storage_c ,
		  const enum storage_type one_jumps_pn_two_jumps_cv_storage_c ,
		  const bool configuration_SD_one_jump_tables_to_recalculate_for_matrices_c , 
		  const bool is_it_Davidson_c , 
		  const bool non_zero_NBMEs_proportion_only , 
		  const class TBMEs_class &TBMEs_pn , 
		  const class TBMEs_class &TBMEs_cv , 
		  const bool is_one_body_p_non_zero_if_here_c , 
		  const bool is_one_body_n_non_zero_if_here_c , 
		  const bool is_pp_non_zero_if_here_c , 
		  const bool is_nn_non_zero_if_here_c , 
		  const bool is_pn_non_zero_if_here_c ,
		  const bool is_cv_non_zero_if_here_c ,
		  const double J_c , 
		  class GSM_vector_helper_class &GSM_vector_helper ,
		  class GSM_vector &PSI_in_full ,
		  class GSM_vector &PSI_in_unoccupied_squares ,
		  class GSM_vector &H_PSI_occupied_squares ,
		  class array<class GSM_vector> &H_PSI_table) :
  is_there_cout (false) , 
  is_there_cout_detailed (false) , 
  Hamiltonian_storage (NO_STORAGE) ,
  M_TBMEs_storage (NO_STORAGE) , 
  one_jumps_pn_two_jumps_cv_storage (NO_STORAGE) , 
  configuration_SD_one_jump_tables_to_recalculate_for_matrices (false) ,
  is_it_Davidson (false) ,  
  is_one_body_p_non_zero (false) , 
  is_one_body_n_non_zero (false) , 
  is_pp_non_zero (false) , 
  is_nn_non_zero (false) , 
  is_pn_non_zero (false) ,
  is_cv_non_zero (false) ,
  J (0.0) , 
  GSM_vector_helper_ptr (NULL) , 
  PSI_in_full_ptr (NULL) ,
  PSI_in_unoccupied_squares_ptr (NULL) ,
  H_PSI_occupied_squares_ptr (NULL) ,
  H_PSI_table_ptr (NULL) , 
  TBMEs_pn_ptr (NULL) ,
  TBMEs_cv_ptr (NULL)
{
  allocate (is_there_cout_c , print_detailed_information , Hamiltonian_storage_c , M_TBMEs_storage_c , one_jumps_pn_two_jumps_cv_storage_c , configuration_SD_one_jump_tables_to_recalculate_for_matrices_c , is_it_Davidson_c ,
	    non_zero_NBMEs_proportion_only , TBMEs_pn , TBMEs_cv , is_one_body_p_non_zero_if_here_c , is_one_body_n_non_zero_if_here_c ,
	    is_pp_non_zero_if_here_c , is_nn_non_zero_if_here_c , is_pn_non_zero_if_here_c , is_cv_non_zero_if_here_c , J_c , GSM_vector_helper , PSI_in_full , PSI_in_unoccupied_squares , H_PSI_occupied_squares , H_PSI_table);
}






H_class::H_class (const class H_class &X) :
  is_there_cout (false) , 
  is_there_cout_detailed (false) , 
  Hamiltonian_storage (NO_STORAGE) ,
  M_TBMEs_storage (NO_STORAGE) , 
  one_jumps_pn_two_jumps_cv_storage (NO_STORAGE) , 
  configuration_SD_one_jump_tables_to_recalculate_for_matrices (false) ,
  is_it_Davidson (false) ,
  is_one_body_p_non_zero (false) , 
  is_one_body_n_non_zero (false) , 
  is_pp_non_zero (false) , 
  is_nn_non_zero (false) , 
  is_pn_non_zero (false) ,
  is_cv_non_zero (false) ,
  J (0.0) , 
  GSM_vector_helper_ptr (NULL) ,
  PSI_in_full_ptr (NULL) , 
  PSI_in_unoccupied_squares_ptr (NULL) ,
  H_PSI_occupied_squares_ptr (NULL) ,
  H_PSI_table_ptr (NULL) ,
  TBMEs_pn_ptr (NULL) ,
  TBMEs_cv_ptr (NULL)
{
  allocate_fill (X);
}







H_class::~H_class ()
{
  if (PSI_row_indices_non_zero_one_jump_no_TRS_tables.is_it_filled ())
    {
      const unsigned int MPI_occupied_squares_row_number = PSI_row_indices_non_zero_one_jump_no_TRS_tables.dimension (0);
	  
      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	delete [] PSI_row_indices_non_zero_one_jump_no_TRS_tables(occupied_squares_row_index);
    }
      
  if (PSI_row_indices_non_zero_two_jumps_no_TRS_tables.is_it_filled ())
    {	  
      const unsigned int MPI_occupied_squares_row_number = PSI_row_indices_non_zero_two_jumps_no_TRS_tables.dimension (0);
	  
      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	delete [] PSI_row_indices_non_zero_two_jumps_no_TRS_tables(occupied_squares_row_index);
    }

  if (PSI_row_indices_non_zero_one_jump_TRS_tables.is_it_filled ())
    {	  
      const unsigned int MPI_occupied_squares_row_number = PSI_row_indices_non_zero_one_jump_TRS_tables.dimension (0);
	  
      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	delete [] PSI_row_indices_non_zero_one_jump_TRS_tables(occupied_squares_row_index);
    }
      
  if (PSI_row_indices_non_zero_two_jumps_TRS_tables.is_it_filled ())
    {	  
      const unsigned int MPI_occupied_squares_row_number = PSI_row_indices_non_zero_two_jumps_TRS_tables.dimension (0);
	  
      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	delete [] PSI_row_indices_non_zero_two_jumps_TRS_tables(occupied_squares_row_index);
    }

  if (squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables.is_it_filled ())
    {
      const unsigned int MPI_occupied_squares_row_number = squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables.dimension (0);

      const unsigned int space_dimensions_all_processes_max = squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables.dimension (1);
	  
      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)	  
	for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimensions_all_processes_max ; PSI_row_index++) 
	  delete [] squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables(occupied_squares_row_index , PSI_row_index);
    }
	  
  if (squares_non_zero_NBMEs_one_jump_tables.is_it_filled ())
    {
      const unsigned int MPI_occupied_squares_row_number = squares_non_zero_NBMEs_one_jump_tables.dimension (0);

      const unsigned int space_dimensions_all_processes_max = squares_non_zero_NBMEs_one_jump_tables.dimension (1);

      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimensions_all_processes_max ; PSI_row_index++) 
	  delete [] squares_non_zero_NBMEs_one_jump_tables(occupied_squares_row_index , PSI_row_index);
    }
	 
  if (squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables.is_it_filled ())
    {
      const unsigned int MPI_occupied_squares_row_number = squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables.dimension (0);

      const unsigned int space_dimensions_all_processes_max = squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables.dimension (1);

      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimensions_all_processes_max ; PSI_row_index++) 
	  delete [] squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables(occupied_squares_row_index , PSI_row_index);	      
    }
	
  if (squares_non_zero_NBMEs_two_jumps_indices_tables.is_it_filled ())
    {
      const unsigned int MPI_occupied_squares_row_number = squares_non_zero_NBMEs_two_jumps_indices_tables.dimension (0);

      const unsigned int space_dimensions_all_processes_max = squares_non_zero_NBMEs_two_jumps_indices_tables.dimension (1);

      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	   
	for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimensions_all_processes_max ; PSI_row_index++) 
	  delete [] squares_non_zero_NBMEs_two_jumps_indices_tables(occupied_squares_row_index , PSI_row_index);
    }
      
  if (squares_non_zero_NBMEs_two_jumps_tables.is_it_filled ())
    {
      const unsigned int MPI_occupied_squares_row_number = squares_non_zero_NBMEs_two_jumps_tables.dimension (0);

      const unsigned int space_dimensions_all_processes_max = squares_non_zero_NBMEs_two_jumps_tables.dimension (1);

      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	  
	for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimensions_all_processes_max ; PSI_row_index++) 
	  delete [] squares_non_zero_NBMEs_two_jumps_tables(occupied_squares_row_index , PSI_row_index);
    }     
}








void H_class::allocate (
			const bool is_there_cout_c , 
			const bool print_detailed_information , 
			const enum storage_type Hamiltonian_storage_c , 
			const enum storage_type M_TBMEs_storage_c ,
			const enum storage_type one_jumps_pn_two_jumps_cv_storage_c ,
			const bool configuration_SD_one_jump_tables_to_recalculate_for_matrices_c , 
			const bool is_it_Davidson_c ,
			const bool non_zero_NBMEs_proportion_only , 
			const class TBMEs_class &TBMEs_pn , 
			const class TBMEs_class &TBMEs_cv , 
			const bool is_one_body_p_non_zero_if_here_c , 
			const bool is_one_body_n_non_zero_if_here_c , 
			const bool is_pp_non_zero_if_here_c , 
			const bool is_nn_non_zero_if_here_c , 
			const bool is_pn_non_zero_if_here_c ,
			const bool is_cv_non_zero_if_here_c ,
			const double J_c ,
			class GSM_vector_helper_class &GSM_vector_helper ,  
			class GSM_vector &PSI_in_full ,
			class GSM_vector &PSI_in_unoccupied_squares ,
			class GSM_vector &H_PSI_occupied_squares ,
			class array<class GSM_vector> &H_PSI_table)
{    
  if (is_it_filled ()) error_message_print_abort ("H_class cannot be allocated twice in H_class::allocate");

  const int S = GSM_vector_helper.get_S ();
  
  const int S_plus_one = S + 1;
  
  H_MPI_communication_time = 0.0;
  
  H_multiplications_number = 0.0;
 
  const unsigned int space_dimensions_all_processes_max = GSM_vector_helper.get_space_dimensions_all_processes_max ();
 
  GSM_vector_helper_ptr = &GSM_vector_helper;

  is_there_cout = is_there_cout_c;
  
  is_there_cout_detailed = (is_there_cout && print_detailed_information);
  
  Hamiltonian_storage = Hamiltonian_storage_c;

  M_TBMEs_storage = M_TBMEs_storage_c;
  
  one_jumps_pn_two_jumps_cv_storage = one_jumps_pn_two_jumps_cv_storage_c;
  
  if ((Hamiltonian_storage == FULL_STORAGE) && (M_TBMEs_storage != ON_THE_FLY) && (one_jumps_pn_two_jumps_cv_storage != ON_THE_FLY) && (S == 0))
    error_message_print_abort ("If one has Hamiltonian full storage, storage of uncoupled TBMEs and one jumps proton-neutron must be on the fly");
  
  if ((Hamiltonian_storage == FULL_STORAGE) && (M_TBMEs_storage != ON_THE_FLY) && (one_jumps_pn_two_jumps_cv_storage != ON_THE_FLY) && (S != 0))
    error_message_print_abort ("If one has Hamiltonian full storage, storage of uncoupled TBMEs and one jumps proton-neutron / two jumps for pp <-> m conversions must be on the fly");
  
  if ((Hamiltonian_storage == PARTIAL_STORAGE) && (M_TBMEs_storage != FULL_STORAGE) && (one_jumps_pn_two_jumps_cv_storage != ON_THE_FLY) && (S == 0))
    error_message_print_abort ("If one has Hamiltonian partial storage, storage of uncoupled TBMEs must be full storage and that of one jumps proton-neutron must be on the fly");

  if ((Hamiltonian_storage == PARTIAL_STORAGE) && (M_TBMEs_storage != FULL_STORAGE) && (one_jumps_pn_two_jumps_cv_storage != ON_THE_FLY) && (S != 0))
    error_message_print_abort ("If one has Hamiltonian partial storage, storage of uncoupled TBMEs must be full storage and that of one jumps proton-neutron / two jumps for pp <-> m conversions must be on the fly");
  
  configuration_SD_one_jump_tables_to_recalculate_for_matrices = configuration_SD_one_jump_tables_to_recalculate_for_matrices_c;
	
  is_it_Davidson = is_it_Davidson_c;
    
  J = J_c;
  
  const enum space_type space = GSM_vector_helper.get_space ();
  
  is_one_body_p_non_zero = (space != NEUT_Y_ONLY) ? (is_one_body_p_non_zero_if_here_c) : (false);
  is_one_body_n_non_zero = (space != PROT_Y_ONLY) ? (is_one_body_n_non_zero_if_here_c) : (false);
 
  is_pp_non_zero = (space != NEUT_Y_ONLY) ? (is_pp_non_zero_if_here_c) : (false);
  is_nn_non_zero = (space != PROT_Y_ONLY) ? (is_nn_non_zero_if_here_c) : (false);
  is_pn_non_zero = (space == PROT_NEUT_Y) ? (is_pn_non_zero_if_here_c) : (false);
  is_cv_non_zero = (space == PROT_NEUT_Y) ? (is_cv_non_zero_if_here_c) : (false);
  
  PSI_in_full_ptr = &PSI_in_full;
  
  PSI_in_unoccupied_squares_ptr = &PSI_in_unoccupied_squares;

  H_PSI_occupied_squares_ptr = &H_PSI_occupied_squares;
  
  H_PSI_table_ptr = &H_PSI_table;

  TBMEs_pn_ptr = &TBMEs_pn;
  TBMEs_cv_ptr = &TBMEs_cv; 
  
  if (space_dimensions_all_processes_max == 0) return;

  GSM_vector_helper_full.allocate_fill_without_MPI_parallelization (GSM_vector_helper);

  const class array<unsigned int> &space_dimensions_all_processes = GSM_vector_helper.get_space_dimensions_all_processes ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();

  const unsigned int MPI_occupied_squares_row_number = GSM_vector_helper.get_MPI_occupied_squares_row_number ();

  const unsigned int N = (is_it_MPI_parallelized_local) ? (NUMBER_OF_PROCESSES) : (1);
  
  const class array<bool> &MPI_are_squares_occupied = GSM_vector_helper.get_MPI_are_squares_occupied ();

  const class array<unsigned int> &MPI_occupied_squares_row_indices = GSM_vector_helper.get_MPI_occupied_squares_row_indices ();

  const class GSM_vector_helper_class dummy_helper;
  
  class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
   
  const unsigned int ZYval = prot_Y_data.get_N_valence_baryons ();
  const unsigned int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const bool is_it_N_valence_larger = (NYval >= ZYval);
  
  const bool is_it_full_or_partial_storage = is_it_full_or_partial_storage_determine (Hamiltonian_storage);
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  squares_non_zero_NBMEs_one_jump_numbers.allocate  (MPI_occupied_squares_row_number , space_dimensions_all_processes_max);
  squares_non_zero_NBMEs_two_jumps_numbers.allocate (MPI_occupied_squares_row_number , space_dimensions_all_processes_max);
  
  squares_non_zero_NBMEs_off_diagonal_numbers_calc ();
  
  if (non_zero_NBMEs_proportion_only) return;

  if (is_it_full_or_partial_storage)
    {
      if (PSI_in_unoccupied_squares.get_space_dimensions_all_processes_max () == 0) return;
      
      if (H_PSI_occupied_squares.get_space_dimensions_all_processes_max () == 0) return;
    }
  
  H_diagonal_tab.allocate (space_dimensions_all_processes_max);

  H_diagonal_tab = 0.0;
  
  if (space == PROT_NEUT_Y)
    {
      if (is_one_body_p_non_zero || is_pp_non_zero) diagonal_part_p_part_pn_calc_store ();
      if (is_one_body_n_non_zero || is_nn_non_zero) diagonal_part_n_part_pn_calc_store ();
      
      if (is_pn_non_zero)
	{
	  if (is_it_N_valence_larger)
	    diagonal_part_pn_part_pn_N_valence_larger_calc_store ();
	  else
	    diagonal_part_pn_part_pn_Z_valence_larger_calc_store ();
	}
    }
  else
    diagonal_part_pp_nn_calc_store ();
  
  if (is_it_Davidson) 
    {
      H_diagonal_averaged_tab.allocate (space_dimensions_all_processes_max);

      H_diagonal_averaged_tab = 0.0;

      if (space == PROT_NEUT_Y)
	{
	  if (is_it_N_valence_larger)
	    diagonal_part_averaged_pn_N_valence_larger_calc_store ();
	  else
	    diagonal_part_averaged_pn_Z_valence_larger_calc_store ();
	}
      else
	diagonal_part_averaged_pp_nn_calc_store ();
    }
  
  if (is_it_full_or_partial_storage)
    {
      if (Hamiltonian_storage == PARTIAL_STORAGE)
	{	      	   
	  if (space == PROT_NEUT_Y)
	    {
	      M_TBMEs_pn_alloc_calc_partial_storage ();

	      M_TBMEs_pn_cv_indices_alloc_calc (is_it_N_valence_larger);
	    }      
	  else      
	    M_TBMEs_pp_nn_alloc_calc_partial_storage ();      
	}
      
      space_dimensions_non_zero_one_jump_no_TRS.allocate  (MPI_occupied_squares_row_number);
      space_dimensions_non_zero_two_jumps_no_TRS.allocate (MPI_occupied_squares_row_number);

      space_dimensions_non_zero_one_jump_no_TRS  = 0;
      space_dimensions_non_zero_two_jumps_no_TRS = 0;
      
      squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables.allocate (MPI_occupied_squares_row_number , space_dimensions_all_processes_max);
      squares_non_zero_NBMEs_one_jump_tables.allocate                    (MPI_occupied_squares_row_number , space_dimensions_all_processes_max);

      squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables.allocate (MPI_occupied_squares_row_number , space_dimensions_all_processes_max);
      
      if (Hamiltonian_storage == PARTIAL_STORAGE) squares_non_zero_NBMEs_two_jumps_indices_tables.allocate (MPI_occupied_squares_row_number , space_dimensions_all_processes_max);
      if (Hamiltonian_storage == FULL_STORAGE)    squares_non_zero_NBMEs_two_jumps_tables.allocate         (MPI_occupied_squares_row_number , space_dimensions_all_processes_max);

      squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables  = NULL;
      squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables = NULL;
      
      squares_non_zero_NBMEs_one_jump_tables  = NULL;
      squares_non_zero_NBMEs_two_jumps_tables = NULL;      

      squares_non_zero_NBMEs_two_jumps_indices_tables = NULL;

      for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	{
	  const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
	  
	  if (is_square_occupied)
	    {
	      const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
	  
	      const unsigned int space_dimension_process = space_dimensions_all_processes(square_row_index);
	  
	      for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimension_process ; PSI_row_index++) 
		{
		  const unsigned int squares_non_zero_NBMEs_one_jump_number  = squares_non_zero_NBMEs_one_jump_numbers(occupied_squares_row_index , PSI_row_index);
		  const unsigned int squares_non_zero_NBMEs_two_jumps_number = squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_row_index);
	      
		  if (squares_non_zero_NBMEs_one_jump_number > 0)
		    {
		      squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables(occupied_squares_row_index , PSI_row_index) = new unsigned int [squares_non_zero_NBMEs_one_jump_number];		      
		      squares_non_zero_NBMEs_one_jump_tables                   (occupied_squares_row_index , PSI_row_index) = new TYPE         [squares_non_zero_NBMEs_one_jump_number];
		      
		      space_dimensions_non_zero_one_jump_no_TRS(occupied_squares_row_index)++;
		    }
	      
		  if (squares_non_zero_NBMEs_two_jumps_number > 0)
		    {
		      squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables(occupied_squares_row_index , PSI_row_index) = new unsigned int [squares_non_zero_NBMEs_two_jumps_number];

		      if (Hamiltonian_storage == PARTIAL_STORAGE)
			squares_non_zero_NBMEs_two_jumps_indices_tables(occupied_squares_row_index , PSI_row_index) = new unsigned int [squares_non_zero_NBMEs_two_jumps_number];

		      if (Hamiltonian_storage == FULL_STORAGE)
			squares_non_zero_NBMEs_two_jumps_tables (occupied_squares_row_index , PSI_row_index) = new TYPE [squares_non_zero_NBMEs_two_jumps_number];
		      
		      space_dimensions_non_zero_two_jumps_no_TRS(occupied_squares_row_index)++;
		    }
		}
	    }
	}

      PSI_row_indices_non_zero_one_jump_no_TRS_tables.allocate  (MPI_occupied_squares_row_number);
      PSI_row_indices_non_zero_two_jumps_no_TRS_tables.allocate (MPI_occupied_squares_row_number);
      
      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	{
	  const unsigned int space_dimension_non_zero_one_jump_no_TRS  = space_dimensions_non_zero_one_jump_no_TRS(occupied_squares_row_index);
	  const unsigned int space_dimension_non_zero_two_jumps_no_TRS = space_dimensions_non_zero_two_jumps_no_TRS(occupied_squares_row_index);

	  PSI_row_indices_non_zero_one_jump_no_TRS_tables(occupied_squares_row_index) = (space_dimension_non_zero_one_jump_no_TRS > 0) ? (new unsigned int [space_dimension_non_zero_one_jump_no_TRS]) : (NULL);
	  PSI_row_indices_non_zero_two_jumps_no_TRS_tables(occupied_squares_row_index) = (space_dimension_non_zero_two_jumps_no_TRS > 0) ? (new unsigned int [space_dimension_non_zero_two_jumps_no_TRS]) : (NULL);
	}

      space_dimensions_non_zero_one_jump_no_TRS = 0;
      space_dimensions_non_zero_two_jumps_no_TRS = 0;

      for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	{
	  const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
	  
	  if (is_square_occupied)
	    {
	      const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
	  
	      const unsigned int space_dimension_process = space_dimensions_all_processes(square_row_index);

	      for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimension_process ; PSI_row_index++)
		{
		  const unsigned int squares_non_zero_NBMEs_one_jump_number  = squares_non_zero_NBMEs_one_jump_numbers (occupied_squares_row_index , PSI_row_index);
		  const unsigned int squares_non_zero_NBMEs_two_jumps_number = squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_row_index);

		  unsigned int *const PSI_row_indices_non_zero_one_jump_no_TRS  = PSI_row_indices_non_zero_one_jump_no_TRS_tables (occupied_squares_row_index);
		  unsigned int *const PSI_row_indices_non_zero_two_jumps_no_TRS = PSI_row_indices_non_zero_two_jumps_no_TRS_tables(occupied_squares_row_index);
	      
		  if (squares_non_zero_NBMEs_one_jump_number > 0)
		    {
		      const unsigned int PSI_column_non_zero_index_one_jump = space_dimensions_non_zero_one_jump_no_TRS(occupied_squares_row_index)++;
		  
		      PSI_row_indices_non_zero_one_jump_no_TRS[PSI_column_non_zero_index_one_jump] = PSI_row_index;
		    }
	      
		  if (squares_non_zero_NBMEs_two_jumps_number > 0)
		    {
		      const unsigned int PSI_column_non_zero_index_two_jumps = space_dimensions_non_zero_two_jumps_no_TRS(occupied_squares_row_index)++;
		  
		      PSI_row_indices_non_zero_two_jumps_no_TRS[PSI_column_non_zero_index_two_jumps] = PSI_row_index;
		    }
		}
	    }
	}
      
      if (is_it_TRS)
	{
	  const class array<unsigned long int> &first_total_PSI_indices = GSM_vector_helper.get_first_total_PSI_indices ();  
  
	  space_dimensions_non_zero_one_jump_TRS.allocate (MPI_occupied_squares_row_number);
	  space_dimensions_non_zero_one_jump_TRS = 0;
	  
	  space_dimensions_non_zero_two_jumps_TRS.allocate (MPI_occupied_squares_row_number);
	  space_dimensions_non_zero_two_jumps_TRS = 0;

	  const class array<unsigned long int> &TRS_total_PSI_indices = GSM_vector_helper.get_TRS_total_PSI_indices ();

#ifdef UseMPI
	  
	  const class array<MPI_Comm> &MPI_row_communicators = GSM_vector_helper.get_MPI_row_communicators ();
  
	  const class array<unsigned int> &MPI_row_processes = GSM_vector_helper.get_MPI_row_processes ();
	  const class array<unsigned int> &MPI_row_group_master_processes = GSM_vector_helper.get_MPI_row_group_master_processes ();
  
	  class array<unsigned long int> TRS_total_PSI_indices_square_row_for_transfer(space_dimensions_all_processes_max);

#endif	
	
	  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	    {
	      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
	  
	      if (is_square_occupied)
		{
		  const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
		  
#ifdef UseMPI

		  const MPI_Comm MPI_row_communicator = MPI_row_communicators(square_row_index);
		  
		  const unsigned int MPI_row_master_process = MPI_row_group_master_processes (square_row_index);

		  const unsigned int MPI_row_process = MPI_row_processes (square_row_index);
  
		  TRS_total_PSI_indices_square_row_for_transfer = TRS_total_PSI_indices;
		  
		  if (is_it_MPI_parallelized_local)
		    {		  
		      if (MPI_row_process == MPI_row_master_process) TRS_total_PSI_indices_square_row_for_transfer = TRS_total_PSI_indices;
		  
		      TRS_total_PSI_indices_square_row_for_transfer.MPI_Bcast (MPI_row_master_process , MPI_row_communicator);
		    }
	      
		  const class array<unsigned long int> &TRS_total_PSI_indices_square_row = (is_it_MPI_parallelized_local) ? (TRS_total_PSI_indices_square_row_for_transfer) : (TRS_total_PSI_indices);
#else
		  const class array<unsigned long int> &TRS_total_PSI_indices_square_row = TRS_total_PSI_indices;
#endif	 

	      
		  const unsigned int space_dimension_process = space_dimensions_all_processes(square_row_index);
	  
		  const unsigned long int first_total_PSI_row_index = first_total_PSI_indices(square_row_index);
  
		  for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimension_process ; PSI_row_index++) 
		    {		  
		      const unsigned long int total_PSI_row_index = first_total_PSI_row_index + PSI_row_index;
		  
		      if (TRS_total_PSI_indices_square_row(PSI_row_index) >= total_PSI_row_index)
			{
			  if (squares_non_zero_NBMEs_one_jump_numbers (occupied_squares_row_index , PSI_row_index) > 0) space_dimensions_non_zero_one_jump_TRS (occupied_squares_row_index)++;
			  if (squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_row_index) > 0) space_dimensions_non_zero_two_jumps_TRS(occupied_squares_row_index)++;
			}
		    }
		}
	    }
	  
	  PSI_row_indices_non_zero_one_jump_TRS_tables.allocate  (MPI_occupied_squares_row_number);
	  PSI_row_indices_non_zero_two_jumps_TRS_tables.allocate (MPI_occupied_squares_row_number);
            
	  for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	    {
	      const unsigned int space_dimension_non_zero_one_jump_TRS  = space_dimensions_non_zero_one_jump_TRS(occupied_squares_row_index);
	      const unsigned int space_dimension_non_zero_two_jumps_TRS = space_dimensions_non_zero_two_jumps_TRS(occupied_squares_row_index);
	      
	      PSI_row_indices_non_zero_one_jump_TRS_tables(occupied_squares_row_index)  = (space_dimension_non_zero_one_jump_TRS  > 0) ? (new unsigned int [space_dimension_non_zero_one_jump_TRS])  : (NULL);
	      PSI_row_indices_non_zero_two_jumps_TRS_tables(occupied_squares_row_index) = (space_dimension_non_zero_two_jumps_TRS > 0) ? (new unsigned int [space_dimension_non_zero_two_jumps_TRS]) : (NULL);
	    }
      
	  space_dimensions_non_zero_one_jump_TRS  = 0;
	  space_dimensions_non_zero_two_jumps_TRS = 0;
	  
	  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	    {
	      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
	  
	      if (is_square_occupied)
		{
		  const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
		  
#ifdef UseMPI

		  const MPI_Comm MPI_row_communicator = MPI_row_communicators(square_row_index);
		  
		  const unsigned int MPI_row_master_process = MPI_row_group_master_processes (square_row_index);

		  const unsigned int MPI_row_process = MPI_row_processes (square_row_index);
  
		  TRS_total_PSI_indices_square_row_for_transfer = TRS_total_PSI_indices;
		  
		  if (is_it_MPI_parallelized_local)
		    {		  
		      if (MPI_row_process == MPI_row_master_process) TRS_total_PSI_indices_square_row_for_transfer = TRS_total_PSI_indices;
		  
		      TRS_total_PSI_indices_square_row_for_transfer.MPI_Bcast (MPI_row_master_process , MPI_row_communicator);
		    }
	      
		  const class array<unsigned long int> &TRS_total_PSI_indices_square_row = (is_it_MPI_parallelized_local) ? (TRS_total_PSI_indices_square_row_for_transfer) : (TRS_total_PSI_indices);
#else
		  const class array<unsigned long int> &TRS_total_PSI_indices_square_row = TRS_total_PSI_indices;
#endif	 

		  const unsigned int space_dimension_process = space_dimensions_all_processes(square_row_index);
	  
		  const unsigned long int first_total_PSI_row_index = first_total_PSI_indices(square_row_index);
  
		  unsigned int *const PSI_row_indices_non_zero_one_jump_TRS  = PSI_row_indices_non_zero_one_jump_TRS_tables (occupied_squares_row_index);
		  unsigned int *const PSI_row_indices_non_zero_two_jumps_TRS = PSI_row_indices_non_zero_two_jumps_TRS_tables(occupied_squares_row_index);
	      
		  for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimension_process ; PSI_row_index++) 
		    {
		      const unsigned long int total_PSI_row_index = first_total_PSI_row_index + PSI_row_index;
		  
		      if (TRS_total_PSI_indices_square_row (PSI_row_index) >= total_PSI_row_index)
			{
			  if (squares_non_zero_NBMEs_one_jump_numbers(occupied_squares_row_index , PSI_row_index) > 0)
			    {
			      const unsigned int PSI_column_non_zero_index_one_jump = space_dimensions_non_zero_one_jump_TRS(occupied_squares_row_index)++;
		  
			      PSI_row_indices_non_zero_one_jump_TRS[PSI_column_non_zero_index_one_jump] = PSI_row_index;
			    }
		      
			  if (squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_row_index) > 0)
			    {
			      const unsigned int PSI_column_non_zero_index_two_jumps = space_dimensions_non_zero_two_jumps_TRS(occupied_squares_row_index)++;
		  
			      PSI_row_indices_non_zero_two_jumps_TRS[PSI_column_non_zero_index_two_jumps] = PSI_row_index;
			    }
			}
		    }
		}
	    }
	}

      matrix_off_diagonal_store ();
      
      M_TBMEs_pn_indices.deallocate ();
      
      M_TBMEs_cv_pp_to_nn_indices.deallocate ();
      M_TBMEs_cv_nn_to_pp_indices.deallocate ();
    }
    
  if ((Hamiltonian_storage == ON_THE_FLY) && (space == PROT_NEUT_Y))
    {    
      const unsigned int ZY_valence_pairs_number = (ZYval*(ZYval - 1))/2;
      const unsigned int NY_valence_pairs_number = (NYval*(NYval - 1))/2;
  
      const bool configuration_SD_one_jump_tables_to_recalculate_for_pn = (configuration_SD_one_jump_tables_to_recalculate_for_matrices || is_there_cout);
  
      if (configuration_SD_one_jump_tables_to_recalculate_for_pn)
	{
	  if (is_there_cout_detailed && (THIS_PROCESS == MASTER_PROCESS))
	    {
	      cout << "---------------------------------------------------------------------------------------------------" << endl;
	      cout << "Proton and neutron 1p-1h jumps tables for Hamiltonian" << endl;  
	      cout << "---------------------------------------------------------------------------------------------------" << endl;
	    }
      
	  configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , false , true , false , false , GSM_vector_helper , GSM_vector_helper , dummy_helper , prot_Y_data , neut_Y_data);  
	}
      
      const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
      const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
      
      const bool is_it_jumps_full_storage = (one_jumps_pn_two_jumps_cv_storage == FULL_STORAGE);
      
      const bool is_it_one_jumps_pn_two_jumps_cv_partial_storage = (one_jumps_pn_two_jumps_cv_storage == PARTIAL_STORAGE);

      const bool is_it_jumps_p_partial_storage = (is_it_one_jumps_pn_two_jumps_cv_partial_storage &&  is_it_N_valence_larger);
      const bool is_it_jumps_n_partial_storage = (is_it_one_jumps_pn_two_jumps_cv_partial_storage && !is_it_N_valence_larger);
      
      if (is_pn_non_zero)
	{
	  class array<class jumps_data_out_to_in_str> dummy_two_jumps_cv_tab;
	      
	  if (is_it_jumps_full_storage || is_it_jumps_p_partial_storage)
	    {
	      const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
      
	      const int four_mp_max = prot_Y_data.get_four_m_max ();
	  
	      const int four_mp_max_plus_one = four_mp_max + 1;

	      const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
	      const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

	      const unsigned long int total_outSDp_number = (total_outSDp_index_max >= total_outSDp_index_min) ? ((total_outSDp_index_max - total_outSDp_index_min) + 1) : (0);   
      
	      one_jump_p_tabs.allocate (total_outSDp_number);  

	      if (is_cv_non_zero)
		{
		  two_jumps_cv_p_pp_to_nn_tabs.allocate (total_outSDp_number);
		  two_jumps_cv_p_nn_to_pp_tabs.allocate (total_outSDp_number);
		}
	  	
	      for (unsigned long int i = 0 ; i < total_outSDp_number ; i++)
		{
		  class array<class jumps_data_out_to_in_str> &one_jump_p_tab = one_jump_p_tabs(i);
	  
		  one_jump_p_tab.allocate (2 , S_plus_one , four_mp_max_plus_one);

		  class array<class jumps_data_out_to_in_str> &two_jumps_cv_p_pp_to_nn_tab = (is_cv_non_zero) ? (two_jumps_cv_p_pp_to_nn_tabs(i)) : (dummy_two_jumps_cv_tab);
		  class array<class jumps_data_out_to_in_str> &two_jumps_cv_p_nn_to_pp_tab = (is_cv_non_zero) ? (two_jumps_cv_p_nn_to_pp_tabs(i)) : (dummy_two_jumps_cv_tab);
		    
		  if (is_cv_non_zero)
		    {
		      two_jumps_cv_p_pp_to_nn_tab.allocate (2 , S_plus_one , four_mp_max_plus_one);
		      two_jumps_cv_p_nn_to_pp_tab.allocate (2 , S_plus_one , four_mp_max_plus_one);
		    }
	      
		  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
		    for (int Sp = 0 ; Sp <= S ; Sp++)
		      for (int Delta_iMp = 0 ; Delta_iMp <= four_mp_max ; Delta_iMp++)
			{
			  one_jump_p_tab(BPp , Sp , Delta_iMp).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);

			  if (is_cv_non_zero)
			    {
			      two_jumps_cv_p_pp_to_nn_tab(BPp , Sp , Delta_iMp).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , ZY_valence_pairs_number);
			      two_jumps_cv_p_nn_to_pp_tab(BPp , Sp , Delta_iMp).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , ZY_valence_pairs_number);
			    }
			}
		}
	      
	      one_jump_p_tab_out_to_in_all_SDp_calc ();
	      
	      if (is_cv_non_zero)
		{
		  two_jumps_cv_p_tab_out_to_in_all_SDp_calc (true);
		  two_jumps_cv_p_tab_out_to_in_all_SDp_calc (false);
		}
	    }
      
	  if (is_it_jumps_full_storage || is_it_jumps_n_partial_storage) 
	    {
	      const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
	  
	      const int four_mn_max = neut_Y_data.get_four_m_max ();

	      const int four_mn_max_plus_one = four_mn_max + 1;
	  
	      const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
	      const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();
      
	      const unsigned long int total_outSDn_number = (total_outSDn_index_max >= total_outSDn_index_min) ? ((total_outSDn_index_max - total_outSDn_index_min) + 1) : (0);
	        
	      one_jump_n_tabs.allocate (total_outSDn_number);
      
	      if (is_cv_non_zero)
		{
		  two_jumps_cv_n_pp_to_nn_tabs.allocate (total_outSDn_number);
		  two_jumps_cv_n_nn_to_pp_tabs.allocate (total_outSDn_number);
		}
	  
	      for (unsigned long int i = 0 ; i < total_outSDn_number ; i++)
		{
		  class array<class jumps_data_out_to_in_str> &one_jump_n_tab = one_jump_n_tabs(i);
	 
		  one_jump_n_tab.allocate (2 , S_plus_one , four_mn_max_plus_one);
	      
		  class array<class jumps_data_out_to_in_str> &two_jumps_cv_n_pp_to_nn_tab = (is_cv_non_zero) ? (two_jumps_cv_n_pp_to_nn_tabs(i)) : (dummy_two_jumps_cv_tab);
		  class array<class jumps_data_out_to_in_str> &two_jumps_cv_n_nn_to_pp_tab = (is_cv_non_zero) ? (two_jumps_cv_n_nn_to_pp_tabs(i)) : (dummy_two_jumps_cv_tab);
		  
		  if (is_cv_non_zero)
		    {
		      two_jumps_cv_n_pp_to_nn_tab.allocate (2 , S_plus_one , four_mn_max_plus_one);
		      two_jumps_cv_n_nn_to_pp_tab.allocate (2 , S_plus_one , four_mn_max_plus_one);
		    }
	      
		  for (unsigned int BPn = 0 ; BPn <= 1 ; BPn++)
		    for (int Sn = 0 ; Sn <= S ; Sn++)
		      for (int Delta_iMn = 0 ; Delta_iMn <= four_mn_max ; Delta_iMn++)
			{
			  one_jump_n_tab(BPn , Sn , Delta_iMn).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);

			  if (is_cv_non_zero)
			    {
			      two_jumps_cv_n_pp_to_nn_tab(BPn , Sn , Delta_iMn).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , NY_valence_pairs_number);
			      two_jumps_cv_n_nn_to_pp_tab(BPn , Sn , Delta_iMn).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , NY_valence_pairs_number);
			    }
			}
		}
  
	      one_jump_n_tab_out_to_in_all_SDn_calc ();
	  
	      if (is_cv_non_zero)
		{
		  two_jumps_cv_n_tab_out_to_in_all_SDn_calc (true);
		  two_jumps_cv_n_tab_out_to_in_all_SDn_calc (false);
		}
	    }
      
	  if (is_there_cout_detailed)
	    {
	      const double one_jump_tabs_used_memory_process_partial = used_memory_calc (one_jump_p_tabs) + used_memory_calc (one_jump_n_tabs);

	      const double one_jump_tabs_used_memory_process_partial_square = one_jump_tabs_used_memory_process_partial*one_jump_tabs_used_memory_process_partial;

	      const double one_jump_tabs_used_memory_process_min = min_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , one_jump_tabs_used_memory_process_partial);
	      const double one_jump_tabs_used_memory_process_max = max_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , one_jump_tabs_used_memory_process_partial);
      
	      const double one_jump_tabs_used_memory_process_sum         = sum_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , one_jump_tabs_used_memory_process_partial);
	      const double one_jump_tabs_used_memory_process_squares_sum = sum_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , one_jump_tabs_used_memory_process_partial_square);
	  
	      const double two_jumps_cv_tabs_used_memory_process_partial =
		used_memory_calc (two_jumps_cv_p_pp_to_nn_tabs) + used_memory_calc (two_jumps_cv_p_nn_to_pp_tabs) +
		used_memory_calc (two_jumps_cv_n_pp_to_nn_tabs) + used_memory_calc (two_jumps_cv_n_nn_to_pp_tabs);

	      const double two_jumps_cv_tabs_used_memory_process_partial_square = two_jumps_cv_tabs_used_memory_process_partial*two_jumps_cv_tabs_used_memory_process_partial;

	      const double two_jumps_cv_tabs_used_memory_process_min = min_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , two_jumps_cv_tabs_used_memory_process_partial);
	      const double two_jumps_cv_tabs_used_memory_process_max = max_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , two_jumps_cv_tabs_used_memory_process_partial);
      
	      const double two_jumps_cv_tabs_used_memory_process_sum         = sum_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , two_jumps_cv_tabs_used_memory_process_partial);
	      const double two_jumps_cv_tabs_used_memory_process_squares_sum = sum_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , two_jumps_cv_tabs_used_memory_process_partial_square);
	      
	      if (THIS_PROCESS == MASTER_PROCESS)
		{
		  const double one_jump_tabs_used_memory_process_average = one_jump_tabs_used_memory_process_sum/NUMBER_OF_PROCESSES;

		  const double one_jump_tabs_used_memory_process_sigma = statistical_sigma_calc (NUMBER_OF_PROCESSES , one_jump_tabs_used_memory_process_sum , one_jump_tabs_used_memory_process_squares_sum);
	  
		  cout << endl;
		  cout << "One jump pn tables memory min used by a process       : " << one_jump_tabs_used_memory_process_min     << " Mb" << endl;
		  cout << "One jump pn tables memory max used by a process       : " << one_jump_tabs_used_memory_process_max     << " Mb" << endl;
		  cout << "One jump pn tables memory average for all processes   : " << one_jump_tabs_used_memory_process_average << " Mb" << endl;
		  cout << "One jump pn tables memory dispersion for all processes: " << one_jump_tabs_used_memory_process_sigma   << " Mb" << endl;
		  cout << endl;

		  if (is_cv_non_zero)
		    {
		      const double two_jumps_cv_tabs_used_memory_process_average = two_jumps_cv_tabs_used_memory_process_sum/NUMBER_OF_PROCESSES;

		      const double two_jumps_cv_tabs_used_memory_process_sigma = statistical_sigma_calc (NUMBER_OF_PROCESSES , two_jumps_cv_tabs_used_memory_process_sum , two_jumps_cv_tabs_used_memory_process_squares_sum);
	  
		      cout << endl;
		      cout << "Two jumps cv tables memory min used by a process       : " << two_jumps_cv_tabs_used_memory_process_min     << " Mb" << endl;
		      cout << "Two jumps cv tables memory max used by a process       : " << two_jumps_cv_tabs_used_memory_process_max     << " Mb" << endl;
		      cout << "Two jumps cv tables memory average for all processes   : " << two_jumps_cv_tabs_used_memory_process_average << " Mb" << endl;
		      cout << "Two jumps cv tables memory dispersion for all processes: " << two_jumps_cv_tabs_used_memory_process_sigma   << " Mb" << endl;
		      cout << endl;
		    }
		}
	    }
	}
      
      if (configuration_SD_one_jump_tables_to_recalculate_for_pn && configuration_SD_one_jump_tables_to_recalculate_for_matrices)
	{
	  prot_Y_data.one_jump_tables_out_to_in_deallocate ();
	  neut_Y_data.one_jump_tables_out_to_in_deallocate ();
	}      	
    }

  if ((Hamiltonian_storage == ON_THE_FLY) && (M_TBMEs_storage != ON_THE_FLY))
    {
      if (space == PROT_NEUT_Y)
	{
	  M_TBMEs_pn_alloc_calc_on_the_fly ();

	  M_TBMEs_pn_cv_indices_alloc_calc (is_it_N_valence_larger);
	}      
      else      
	M_TBMEs_pp_nn_alloc_calc_on_the_fly ();      
    }
  
  if (is_there_cout)
    {
      const double H_used_memory_process_partial = used_memory_calc (*this);

      const double H_used_memory_process_partial_square = H_used_memory_process_partial*H_used_memory_process_partial;

      const double H_used_memory_process_min = min_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , H_used_memory_process_partial);
      const double H_used_memory_process_max = max_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , H_used_memory_process_partial);
      
      const double H_used_memory_process_sum         = sum_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , H_used_memory_process_partial);
      const double H_used_memory_process_squares_sum = sum_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , H_used_memory_process_partial_square);
      
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  const double H_used_memory_process_average = H_used_memory_process_sum/NUMBER_OF_PROCESSES;

	  const double H_used_memory_process_sigma = statistical_sigma_calc (NUMBER_OF_PROCESSES , H_used_memory_process_sum , H_used_memory_process_squares_sum);
	  
	  cout << endl;
	  cout << "H memory min used by a process        : " << H_used_memory_process_min     << " Mb" << endl;
	  cout << "H memory max used by a process        : " << H_used_memory_process_max     << " Mb" << endl;
	  cout << "H memory average for all processes    : " << H_used_memory_process_average << " Mb" << endl;
	  cout << "H memory dispersion for all processes : " << H_used_memory_process_sigma   << " Mb" << endl;
	  cout << endl;
	}
    }  
}
























void H_class::allocate_fill (const class H_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("H_class cannot be allocated twice in H_class::allocate_fill");
  
  is_there_cout = X.is_there_cout;

  is_there_cout_detailed = X.is_there_cout_detailed;

  Hamiltonian_storage = X.Hamiltonian_storage;

  M_TBMEs_storage = X.M_TBMEs_storage;
  
  one_jumps_pn_two_jumps_cv_storage = X.one_jumps_pn_two_jumps_cv_storage;
  
  configuration_SD_one_jump_tables_to_recalculate_for_matrices = X.configuration_SD_one_jump_tables_to_recalculate_for_matrices;

  is_it_Davidson = X.is_it_Davidson;

  J = X.J;
  
  is_one_body_p_non_zero = X.is_one_body_p_non_zero;
  is_one_body_n_non_zero = X.is_one_body_n_non_zero;
 
  is_pp_non_zero = X.is_pp_non_zero;
  is_nn_non_zero = X.is_nn_non_zero;
  is_pn_non_zero = X.is_pn_non_zero;
  is_cv_non_zero = X.is_cv_non_zero;
    
  GSM_vector_helper_ptr = X.GSM_vector_helper_ptr;
    
  PSI_in_full_ptr = X.PSI_in_full_ptr;

  PSI_in_unoccupied_squares_ptr = X.PSI_in_unoccupied_squares_ptr;

  H_PSI_occupied_squares_ptr = X.H_PSI_occupied_squares_ptr;
  
  H_PSI_table_ptr = X.H_PSI_table_ptr;
  
  TBMEs_pn_ptr = X.TBMEs_pn_ptr; 
  TBMEs_cv_ptr = X.TBMEs_cv_ptr; 

  GSM_vector_helper_full.allocate_fill (GSM_vector_helper_full);
 
  H_diagonal_tab.allocate_fill (X.H_diagonal_tab);  

  H_diagonal_averaged_tab.allocate_fill (X.H_diagonal_averaged_tab);

  M_TBMEs.allocate_fill (X.M_TBMEs);
  
  M_TBMEs_pn_indices.allocate_fill (X.M_TBMEs_pn_indices);
      
  M_TBMEs_cv_pp_to_nn_indices.allocate_fill (X.M_TBMEs_cv_pp_to_nn_indices);
  M_TBMEs_cv_nn_to_pp_indices.allocate_fill (X.M_TBMEs_cv_nn_to_pp_indices);
  
  space_dimensions_non_zero_one_jump_no_TRS.allocate_fill  (X.space_dimensions_non_zero_one_jump_no_TRS);
  space_dimensions_non_zero_two_jumps_no_TRS.allocate_fill (X.space_dimensions_non_zero_two_jumps_no_TRS);
  
  space_dimensions_non_zero_one_jump_TRS.allocate_fill  (X.space_dimensions_non_zero_one_jump_TRS);
  space_dimensions_non_zero_two_jumps_TRS.allocate_fill (X.space_dimensions_non_zero_two_jumps_TRS);
  
  squares_non_zero_NBMEs_one_jump_numbers.allocate_fill  (X.squares_non_zero_NBMEs_one_jump_numbers);
  squares_non_zero_NBMEs_two_jumps_numbers.allocate_fill (X.squares_non_zero_NBMEs_two_jumps_numbers);
    
  if (X.is_it_filled () && is_it_full_or_partial_storage_determine (Hamiltonian_storage))
    {
      const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

      const unsigned int MPI_occupied_squares_row_number = GSM_vector_helper.get_MPI_occupied_squares_row_number ();
      
      const unsigned int space_dimensions_all_processes_max = GSM_vector_helper.get_space_dimensions_all_processes_max ();

      const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
      const unsigned int N = (is_it_MPI_parallelized_local) ? (NUMBER_OF_PROCESSES) : (1);
      
      const class array<bool> &MPI_are_squares_occupied = GSM_vector_helper.get_MPI_are_squares_occupied ();

      const class array<unsigned int> &MPI_occupied_squares_row_indices = GSM_vector_helper.get_MPI_occupied_squares_row_indices ();
          
      const class array<unsigned int> &space_dimensions_all_processes = GSM_vector_helper.get_space_dimensions_all_processes ();

      if (X.PSI_row_indices_non_zero_one_jump_no_TRS_tables.is_it_filled ())
	{
	  PSI_row_indices_non_zero_one_jump_no_TRS_tables.allocate  (MPI_occupied_squares_row_number);

	  for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	    {
	      const unsigned int space_dimension_non_zero_one_jump_no_TRS = space_dimensions_non_zero_one_jump_no_TRS(occupied_squares_row_index);

	      PSI_row_indices_non_zero_one_jump_no_TRS_tables(occupied_squares_row_index) = (space_dimension_non_zero_one_jump_no_TRS > 0) ? (new unsigned int [space_dimension_non_zero_one_jump_no_TRS]) : (NULL);
	    }

	  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	    {
	      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
      
	      if (is_square_occupied)
		{
		  const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
	  
		  const unsigned int space_dimension_non_zero_one_jump_no_TRS = space_dimensions_non_zero_one_jump_no_TRS(occupied_squares_row_index);
	  
		  const unsigned int *const X_PSI_row_indices_non_zero_one_jump_no_TRS = X.PSI_row_indices_non_zero_one_jump_no_TRS_tables(occupied_squares_row_index);
	  
		  unsigned int *const PSI_row_indices_non_zero_one_jump_no_TRS = PSI_row_indices_non_zero_one_jump_no_TRS_tables(occupied_squares_row_index);

		  for (unsigned int PSI_column_non_zero_index_one_jump = 0 ; PSI_column_non_zero_index_one_jump < space_dimension_non_zero_one_jump_no_TRS ; PSI_column_non_zero_index_one_jump++) 
		    PSI_row_indices_non_zero_one_jump_no_TRS[PSI_column_non_zero_index_one_jump] = X_PSI_row_indices_non_zero_one_jump_no_TRS[PSI_column_non_zero_index_one_jump];
		}
	    }
	}
      
      if (X.PSI_row_indices_non_zero_two_jumps_no_TRS_tables.is_it_filled ())
	{
	  PSI_row_indices_non_zero_two_jumps_no_TRS_tables.allocate  (MPI_occupied_squares_row_number);

	  for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	    {
	      const unsigned int space_dimension_non_zero_two_jumps_no_TRS = space_dimensions_non_zero_two_jumps_no_TRS(occupied_squares_row_index);

	      PSI_row_indices_non_zero_two_jumps_no_TRS_tables(occupied_squares_row_index) = (space_dimension_non_zero_two_jumps_no_TRS > 0) ? (new unsigned int [space_dimension_non_zero_two_jumps_no_TRS]) : (NULL);
	    }
	  
	  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	    {
	      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
      
	      if (is_square_occupied)
		{
		  const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
	  
		  const unsigned int space_dimension_non_zero_two_jumps_no_TRS = space_dimensions_non_zero_two_jumps_no_TRS(occupied_squares_row_index);
	  
		  const unsigned int *const X_PSI_row_indices_non_zero_two_jumps_no_TRS = X.PSI_row_indices_non_zero_two_jumps_no_TRS_tables(occupied_squares_row_index);
	  
		  unsigned int *const PSI_row_indices_non_zero_two_jumps_no_TRS = PSI_row_indices_non_zero_two_jumps_no_TRS_tables(occupied_squares_row_index);

		  for (unsigned int PSI_column_non_zero_index_two_jumps = 0 ; PSI_column_non_zero_index_two_jumps < space_dimension_non_zero_two_jumps_no_TRS ; PSI_column_non_zero_index_two_jumps++) 
		    PSI_row_indices_non_zero_two_jumps_no_TRS[PSI_column_non_zero_index_two_jumps] = X_PSI_row_indices_non_zero_two_jumps_no_TRS[PSI_column_non_zero_index_two_jumps];
		}
	    }
	}
	
      if (X.PSI_row_indices_non_zero_one_jump_TRS_tables.is_it_filled ())
	{
	  PSI_row_indices_non_zero_one_jump_TRS_tables.allocate  (MPI_occupied_squares_row_number);

	  for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	    {
	      const unsigned int space_dimension_non_zero_one_jump_TRS = space_dimensions_non_zero_one_jump_TRS(occupied_squares_row_index);

	      PSI_row_indices_non_zero_one_jump_TRS_tables(occupied_squares_row_index) = (space_dimension_non_zero_one_jump_TRS > 0) ? (new unsigned int [space_dimension_non_zero_one_jump_TRS]) : (NULL);
	    }
	  
	  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	    {
	      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
      
	      if (is_square_occupied)
		{
		  const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
	  
		  const unsigned int space_dimension_non_zero_one_jump_TRS = space_dimensions_non_zero_one_jump_TRS(occupied_squares_row_index);
	  
		  const unsigned int *const X_PSI_row_indices_non_zero_one_jump_TRS = X.PSI_row_indices_non_zero_one_jump_TRS_tables(occupied_squares_row_index);
	  
		  unsigned int *const PSI_row_indices_non_zero_one_jump_TRS = PSI_row_indices_non_zero_one_jump_TRS_tables(occupied_squares_row_index);

		  for (unsigned int PSI_column_non_zero_index_one_jump = 0 ; PSI_column_non_zero_index_one_jump < space_dimension_non_zero_one_jump_TRS ; PSI_column_non_zero_index_one_jump++) 
		    PSI_row_indices_non_zero_one_jump_TRS[PSI_column_non_zero_index_one_jump] = X_PSI_row_indices_non_zero_one_jump_TRS[PSI_column_non_zero_index_one_jump];
		}
	    }
	}
	
      if (X.PSI_row_indices_non_zero_two_jumps_TRS_tables.is_it_filled ())
	{
	  PSI_row_indices_non_zero_two_jumps_TRS_tables.allocate (MPI_occupied_squares_row_number);

	  for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	    {
	      const unsigned int space_dimension_non_zero_two_jumps_TRS = space_dimensions_non_zero_two_jumps_TRS(occupied_squares_row_index);

	      PSI_row_indices_non_zero_two_jumps_TRS_tables(occupied_squares_row_index) = (space_dimension_non_zero_two_jumps_TRS > 0) ? (new unsigned int [space_dimension_non_zero_two_jumps_TRS]) : (NULL);
	    }
	  
	  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	    {
	      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
      
	      if (is_square_occupied)
		{
		  const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
	  
		  const unsigned int space_dimension_non_zero_two_jumps_TRS = space_dimensions_non_zero_two_jumps_TRS(occupied_squares_row_index);
	  
		  const unsigned int *const X_PSI_row_indices_non_zero_two_jumps_TRS = X.PSI_row_indices_non_zero_two_jumps_TRS_tables(occupied_squares_row_index);
	  
		  unsigned int *const PSI_row_indices_non_zero_two_jumps_TRS = PSI_row_indices_non_zero_two_jumps_TRS_tables(occupied_squares_row_index);

		  for (unsigned int PSI_column_non_zero_index_two_jumps = 0 ; PSI_column_non_zero_index_two_jumps < space_dimension_non_zero_two_jumps_TRS ; PSI_column_non_zero_index_two_jumps++) 
		    PSI_row_indices_non_zero_two_jumps_TRS[PSI_column_non_zero_index_two_jumps] = X_PSI_row_indices_non_zero_two_jumps_TRS[PSI_column_non_zero_index_two_jumps];
		}
	    }	  
	}

      if (X.squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables.is_it_filled ())
	{
	  squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables.allocate (MPI_occupied_squares_row_number , space_dimensions_all_processes_max);
	  
	  squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables = NULL;
	  
	  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	    {
	      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
      
	      if (is_square_occupied)
		{
		  const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);

		  const unsigned int space_dimension_process = space_dimensions_all_processes(square_row_index);
	  	  	  
		  for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimension_process ; PSI_row_index++) 
		    {
		      const unsigned int squares_non_zero_NBMEs_one_jump_number = squares_non_zero_NBMEs_one_jump_numbers(occupied_squares_row_index , PSI_row_index);
	      	      
		      if (squares_non_zero_NBMEs_one_jump_number > 0)
			{
			  squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables(occupied_squares_row_index , PSI_row_index) = new unsigned int [squares_non_zero_NBMEs_one_jump_number];
		      
			  const unsigned int *const X_squares_non_zero_NBMEs_one_jump_PSI_column_indices_table = X.squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables(occupied_squares_row_index , PSI_row_index);
			
			  unsigned int *const squares_non_zero_NBMEs_one_jump_PSI_column_indices_table = squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables(occupied_squares_row_index , PSI_row_index);
					  
			  for (unsigned int i = 0 ; i < squares_non_zero_NBMEs_one_jump_number ; i++)
			    squares_non_zero_NBMEs_one_jump_PSI_column_indices_table[i] = X_squares_non_zero_NBMEs_one_jump_PSI_column_indices_table[i];
			}
		    }
		}
	    }
	}
      
      if (X.squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables.is_it_filled ())
	{
	  squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables.allocate (MPI_occupied_squares_row_number , space_dimensions_all_processes_max);
	  
	  squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables = NULL;
	  
	  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	    {
	      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
      
	      if (is_square_occupied)
		{
		  const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);

		  const unsigned int space_dimension_process = space_dimensions_all_processes(square_row_index);
	  	  	  
		  for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimension_process ; PSI_row_index++) 
		    {
		      const unsigned int squares_non_zero_NBMEs_two_jumps_number = squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_row_index);
	      	      		  
		      if (squares_non_zero_NBMEs_two_jumps_number > 0)
			{
			  squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables(occupied_squares_row_index , PSI_row_index) = new unsigned int [squares_non_zero_NBMEs_two_jumps_number];
		      
			  const unsigned int *const X_squares_non_zero_NBMEs_two_jumps_PSI_column_indices_table = X.squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables(occupied_squares_row_index , PSI_row_index);
			
			  unsigned int *const squares_non_zero_NBMEs_two_jumps_PSI_column_indices_table = squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables(occupied_squares_row_index , PSI_row_index);
			
			  for (unsigned int i = 0 ; i < squares_non_zero_NBMEs_two_jumps_number ; i++)
			    squares_non_zero_NBMEs_two_jumps_PSI_column_indices_table[i] = X_squares_non_zero_NBMEs_two_jumps_PSI_column_indices_table[i];
			}
		    }
		}
	    }
	}

      if (X.squares_non_zero_NBMEs_one_jump_tables.is_it_filled ())
	{
	  squares_non_zero_NBMEs_one_jump_tables.allocate (MPI_occupied_squares_row_number , space_dimensions_all_processes_max);
	  
	  squares_non_zero_NBMEs_one_jump_tables = NULL;
	  
	  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	    {
	      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
      
	      if (is_square_occupied)
		{
		  const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);

		  const unsigned int space_dimension_process = space_dimensions_all_processes(square_row_index);
	  	  	  
		  for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimension_process ; PSI_row_index++) 
		    {
		      const unsigned int squares_non_zero_NBMEs_one_jump_number = squares_non_zero_NBMEs_one_jump_numbers(occupied_squares_row_index , PSI_row_index);
	      	      
		      if (squares_non_zero_NBMEs_one_jump_number > 0)
			{
			  squares_non_zero_NBMEs_one_jump_tables(occupied_squares_row_index , PSI_row_index) = new TYPE [squares_non_zero_NBMEs_one_jump_number];
		      
			  const TYPE *const X_squares_non_zero_NBMEs_one_jump_table = X.squares_non_zero_NBMEs_one_jump_tables(occupied_squares_row_index , PSI_row_index);
			
			  TYPE *const squares_non_zero_NBMEs_one_jump_table = squares_non_zero_NBMEs_one_jump_tables(occupied_squares_row_index , PSI_row_index);
					  
			  for (unsigned int i = 0 ; i < squares_non_zero_NBMEs_one_jump_number ; i++)
			    squares_non_zero_NBMEs_one_jump_table[i] = X_squares_non_zero_NBMEs_one_jump_table[i];
			}
		    }
		}
	    }
	}
      
      if (X.squares_non_zero_NBMEs_two_jumps_indices_tables.is_it_filled ())
	{
	  squares_non_zero_NBMEs_two_jumps_indices_tables.allocate (MPI_occupied_squares_row_number , space_dimensions_all_processes_max);
	  
	  squares_non_zero_NBMEs_two_jumps_indices_tables = NULL;
	  
	  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	    {
	      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
      
	      if (is_square_occupied)
		{
		  const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);

		  const unsigned int space_dimension_process = space_dimensions_all_processes(square_row_index);
	  	  	  
		  for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimension_process ; PSI_row_index++) 
		    {
		      const unsigned int squares_non_zero_NBMEs_two_jumps_number = squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_row_index);	      	      
		  
		      if (squares_non_zero_NBMEs_two_jumps_number > 0)
			{
			  squares_non_zero_NBMEs_two_jumps_indices_tables(occupied_squares_row_index , PSI_row_index) = new unsigned int [squares_non_zero_NBMEs_two_jumps_number];
			  
			  const unsigned int *const X_squares_non_zero_NBMEs_two_jumps_indices_table = X.squares_non_zero_NBMEs_two_jumps_indices_tables(occupied_squares_row_index , PSI_row_index);
			
			  unsigned int *const squares_non_zero_NBMEs_two_jumps_indices_table = squares_non_zero_NBMEs_two_jumps_indices_tables(occupied_squares_row_index , PSI_row_index);
			
			  for (unsigned int i = 0 ; i < squares_non_zero_NBMEs_two_jumps_number ; i++)
			    squares_non_zero_NBMEs_two_jumps_indices_table[i] = X_squares_non_zero_NBMEs_two_jumps_indices_table[i];
			}
		    }
		}
	    }
	}
      
      if (X.squares_non_zero_NBMEs_two_jumps_tables.is_it_filled ())
	{
	  squares_non_zero_NBMEs_two_jumps_tables.allocate (MPI_occupied_squares_row_number , space_dimensions_all_processes_max);
	  
	  squares_non_zero_NBMEs_two_jumps_tables = NULL;
	  
	  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	    {
	      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
      
	      if (is_square_occupied)
		{
		  const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);

		  const unsigned int space_dimension_process = space_dimensions_all_processes(square_row_index);
	  	  	  
		  for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimension_process ; PSI_row_index++) 
		    {
		      const unsigned int squares_non_zero_NBMEs_two_jumps_number = squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_row_index);	      	      
		  
		      if (squares_non_zero_NBMEs_two_jumps_number > 0)
			{
			  squares_non_zero_NBMEs_two_jumps_tables(occupied_squares_row_index , PSI_row_index) = new TYPE [squares_non_zero_NBMEs_two_jumps_number];
			  
			  const TYPE *const X_squares_non_zero_NBMEs_two_jumps_table = X.squares_non_zero_NBMEs_two_jumps_tables(occupied_squares_row_index , PSI_row_index);
			
			  TYPE *const squares_non_zero_NBMEs_two_jumps_table = squares_non_zero_NBMEs_two_jumps_tables(occupied_squares_row_index , PSI_row_index);
			
			  for (unsigned int i = 0 ; i < squares_non_zero_NBMEs_two_jumps_number ; i++)
			    squares_non_zero_NBMEs_two_jumps_table[i] = X_squares_non_zero_NBMEs_two_jumps_table[i];
			}
		    }
		}
	    }
	}
    }
  
  one_jump_p_tabs.allocate_fill (X.one_jump_p_tabs);
  one_jump_n_tabs.allocate_fill (X.one_jump_n_tabs);  
 
  two_jumps_cv_p_pp_to_nn_tabs.allocate_fill (X.two_jumps_cv_p_pp_to_nn_tabs);
  two_jumps_cv_p_nn_to_pp_tabs.allocate_fill (X.two_jumps_cv_p_nn_to_pp_tabs);
  two_jumps_cv_n_pp_to_nn_tabs.allocate_fill (X.two_jumps_cv_n_pp_to_nn_tabs);
  two_jumps_cv_n_nn_to_pp_tabs.allocate_fill (X.two_jumps_cv_n_nn_to_pp_tabs);
}







void H_class::deallocate ()
{
  if (PSI_row_indices_non_zero_one_jump_no_TRS_tables.is_it_filled ())
    {
      const unsigned int MPI_occupied_squares_row_number = PSI_row_indices_non_zero_one_jump_no_TRS_tables.dimension (0);
	  
      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	delete [] PSI_row_indices_non_zero_one_jump_no_TRS_tables(occupied_squares_row_index);
    }
      
  if (PSI_row_indices_non_zero_two_jumps_no_TRS_tables.is_it_filled ())
    {	  
      const unsigned int MPI_occupied_squares_row_number = PSI_row_indices_non_zero_two_jumps_no_TRS_tables.dimension (0);
	  
      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	delete [] PSI_row_indices_non_zero_two_jumps_no_TRS_tables(occupied_squares_row_index);
    }

  if (PSI_row_indices_non_zero_one_jump_TRS_tables.is_it_filled ())
    {	  
      const unsigned int MPI_occupied_squares_row_number = PSI_row_indices_non_zero_one_jump_TRS_tables.dimension (0);
	  
      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	delete [] PSI_row_indices_non_zero_one_jump_TRS_tables(occupied_squares_row_index);
    }
      
  if (PSI_row_indices_non_zero_two_jumps_TRS_tables.is_it_filled ())
    {	  
      const unsigned int MPI_occupied_squares_row_number = PSI_row_indices_non_zero_two_jumps_TRS_tables.dimension (0);
	  
      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	delete [] PSI_row_indices_non_zero_two_jumps_TRS_tables(occupied_squares_row_index);
    }

  if (squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables.is_it_filled ())
    {
      const unsigned int MPI_occupied_squares_row_number = squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables.dimension (0);

      const unsigned int space_dimensions_all_processes_max = squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables.dimension (1);
	  
      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)	  
	for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimensions_all_processes_max ; PSI_row_index++) 
	  delete [] squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables(occupied_squares_row_index , PSI_row_index);
    }
	  
  if (squares_non_zero_NBMEs_one_jump_tables.is_it_filled ())
    {
      const unsigned int MPI_occupied_squares_row_number = squares_non_zero_NBMEs_one_jump_tables.dimension (0);

      const unsigned int space_dimensions_all_processes_max = squares_non_zero_NBMEs_one_jump_tables.dimension (1);

      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimensions_all_processes_max ; PSI_row_index++) 
	  delete [] squares_non_zero_NBMEs_one_jump_tables(occupied_squares_row_index , PSI_row_index);
    }
	 
  if (squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables.is_it_filled ())
    {
      const unsigned int MPI_occupied_squares_row_number = squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables.dimension (0);

      const unsigned int space_dimensions_all_processes_max = squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables.dimension (1);

      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimensions_all_processes_max ; PSI_row_index++) 
	  delete [] squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables(occupied_squares_row_index , PSI_row_index);	      
    }
	
  if (squares_non_zero_NBMEs_two_jumps_indices_tables.is_it_filled ())
    {
      const unsigned int MPI_occupied_squares_row_number = squares_non_zero_NBMEs_two_jumps_indices_tables.dimension (0);

      const unsigned int space_dimensions_all_processes_max = squares_non_zero_NBMEs_two_jumps_indices_tables.dimension (1);

      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	   
	for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimensions_all_processes_max ; PSI_row_index++) 
	  delete [] squares_non_zero_NBMEs_two_jumps_indices_tables(occupied_squares_row_index , PSI_row_index);
    }
      
  if (squares_non_zero_NBMEs_two_jumps_tables.is_it_filled ())
    {
      const unsigned int MPI_occupied_squares_row_number = squares_non_zero_NBMEs_two_jumps_tables.dimension (0);
      const unsigned int space_dimensions_all_processes_max = squares_non_zero_NBMEs_two_jumps_tables.dimension (1);

      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	  
	for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimensions_all_processes_max ; PSI_row_index++) 
	  delete [] squares_non_zero_NBMEs_two_jumps_tables(occupied_squares_row_index , PSI_row_index);
    }
  
  H_diagonal_tab.deallocate ();

  H_diagonal_averaged_tab.deallocate ();

  M_TBMEs.deallocate ();
  
  M_TBMEs_pn_indices.deallocate ();
      
  M_TBMEs_cv_pp_to_nn_indices.deallocate ();
  M_TBMEs_cv_nn_to_pp_indices.deallocate ();
  
  space_dimensions_non_zero_one_jump_no_TRS.deallocate ();
  space_dimensions_non_zero_two_jumps_no_TRS.deallocate ();
  
  space_dimensions_non_zero_one_jump_TRS.deallocate ();
  space_dimensions_non_zero_two_jumps_TRS.deallocate ();
 
  squares_non_zero_NBMEs_one_jump_numbers.deallocate ();
  squares_non_zero_NBMEs_two_jumps_numbers.deallocate ();
  
  PSI_row_indices_non_zero_one_jump_no_TRS_tables.deallocate ();
  PSI_row_indices_non_zero_two_jumps_no_TRS_tables.deallocate ();
  
  PSI_row_indices_non_zero_one_jump_TRS_tables.deallocate ();
  PSI_row_indices_non_zero_two_jumps_TRS_tables.deallocate ();
  
  squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables.deallocate ();
  squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables.deallocate ();
  
  squares_non_zero_NBMEs_one_jump_tables.deallocate ();
  squares_non_zero_NBMEs_two_jumps_tables.deallocate ();
  
  squares_non_zero_NBMEs_two_jumps_indices_tables.deallocate ();
  
  one_jump_p_tabs.deallocate ();
  one_jump_n_tabs.deallocate ();
     
  two_jumps_cv_p_pp_to_nn_tabs.deallocate ();
  two_jumps_cv_p_nn_to_pp_tabs.deallocate ();
  two_jumps_cv_n_pp_to_nn_tabs.deallocate ();
  two_jumps_cv_n_nn_to_pp_tabs.deallocate ();
      
  GSM_vector_helper_full.deallocate ();
    
  is_there_cout = false; 

  is_there_cout_detailed = false; 

  Hamiltonian_storage = NO_STORAGE;
  
  M_TBMEs_storage = NO_STORAGE;
  
  one_jumps_pn_two_jumps_cv_storage = NO_STORAGE;

  configuration_SD_one_jump_tables_to_recalculate_for_matrices = false;

  is_it_Davidson = false;

  J = 0.0;
  
  is_one_body_p_non_zero = false; 
  is_one_body_n_non_zero = false;
  
  is_pp_non_zero = false; 
  is_nn_non_zero = false; 
  is_pn_non_zero = false;
  is_cv_non_zero = false;
    
  GSM_vector_helper_ptr = NULL;
    
  PSI_in_full_ptr = NULL;

  PSI_in_unoccupied_squares_ptr = NULL;

  H_PSI_occupied_squares_ptr = NULL;
  
  H_PSI_table_ptr = NULL;
  
  TBMEs_pn_ptr = NULL;
  TBMEs_cv_ptr = NULL;
}
  










// Calculation of arrays of arrays of 1p-1h jumps data for protons and neutrons for the 2p-2h pn part of H (pn only)
// -----------------------------------------------------------------------------------------------------------------
// They are functions of full proton and neutron outSDp/outSDn basis state indices,
// and of the binary parity BPp_in or BPn_in (see observables_basic_functions.cpp for definition)
// and M projection difference index iMp_in - iMp_out + 2.mp_max or iMn_in - iMn_out + 2.mn_max (see GSM_vector_dimensions.cpp for definition)
// of the inSDp/inSDn basis state. They contain data related to the application of a+(alpha) a(beta) to inSDp/inSDn to obtain outSDp/outSDn,
// for the pn H part of the form \sum a+(alpha_p) a+(alpha_n) a(beta_p) a(beta_n) <alpha_p alpha_n | V | beta_p beta_n>. 
// They are stored if one_jumps_pn_two_jumps_cv_storage is not on the fly, as then one gains time as otherwise they are recalculated on the fly.
// 
// For this, one loops over all outSDp/outSDn basis states, and one generates all possible 1p-1h excitations from them.
// Associated 1p-1h jumps data are then stored in arrays.
//
// OpenMP parallelization is used on the loop of proton or neutron Slater determinants.
// MPI parallelization here is implicit, as on considers only the Slater determinants of the current node.

void H_class::one_jump_p_tab_out_to_in_all_SDp_calc ()
{  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
          
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int S = GSM_vector_helper.get_S ();
  
  const int S_plus_one = S + 1;
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();

  const int four_mp_max = prot_Y_data.get_four_m_max ();
  
  const int four_mp_max_plus_one = four_mp_max + 1;
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();
 
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_out_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
    
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  if (total_outSDp_index_min > total_outSDp_index_max) return;
  			      
  class array<class array<bool> > is_one_jump_p_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) is_one_jump_p_calculated_tabs(i).allocate (2 , S_plus_one , four_mp_max_plus_one);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();

      const unsigned int BPn_out = binary_parity_product (BP , BPp_out);

      const int Sp_out = outSDp_qn.get_S ();
      
      const int Sn_out = S - Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();
      
      const int n_spec_n_out = n_spec_max - n_spec_p_out;
      
      const int n_scat_p_out = outSDp_qn.get_n_scat ();	

      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;

      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;
      
      const int n_spec_p_in = n_spec_p_out;
      
      const int iMn_out = iM - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();
      
      const unsigned long int total_outSDp_index_shifted = total_outSDp_index - total_outSDp_index_min;
      
      class array<class jumps_data_out_to_in_str> &one_jump_p_tab = one_jump_p_tabs(total_outSDp_index_shifted);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class array<bool> &is_one_jump_p_calculated_tab = is_one_jump_p_calculated_tabs(i_thread);
      
      is_one_jump_p_calculated_tab = false;
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;
	      
	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDn_index;
		     			  
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
			    for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
			      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
				{
				  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;	    
			
				  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
	
				  bool &is_one_jump_p_calculated = is_one_jump_p_calculated_tab(BPp_in , Sp_in , Delta_iMp_in);

				  if (!is_one_jump_p_calculated)
				    {
				      class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in);
      
				      one_jump_p.one_jump_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , prot_Y_data);

				      is_one_jump_p_calculated = true; 
				    }}}}}}}}
}

void H_class::one_jump_n_tab_out_to_in_all_SDn_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
          
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();
  
  const int S_plus_one = S + 1;
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
    
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
    
  const int two_mn_max = neut_Y_data.get_two_m_max ();

  const int four_mn_max = neut_Y_data.get_four_m_max ();
          		  	
  const int four_mn_max_plus_one = four_mn_max + 1;
  	  
  const int mn_max_minus_mn_min = neut_Y_data.get_m_max_minus_m_min ();
    
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
    
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();
    
  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_out_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
  
  class array<class array<bool> > is_one_jump_n_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) is_one_jump_n_calculated_tabs(i).allocate (2 , S_plus_one , four_mn_max_plus_one);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();

      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;

      const unsigned int BPn_out = outSDn_qn.get_BP ();
      
      const unsigned int BPp_out = binary_parity_product (BP , BPn_out);

      const int Sn_out = outSDn_qn.get_S ();
      
      const int Sp_out = S - Sn_out;
				 
      const int n_spec_n_out = outSDn_qn.get_n_spec ();
      
      const int n_spec_p_out = n_spec_max - n_spec_n_out;
      
      const int n_scat_n_out = outSDn_qn.get_n_scat ();	

      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;

      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;
      
      const int n_spec_n_in = n_spec_n_out;
      
      const int iMp_out = iM - iMn_out;

      const int iMn_in_min_M = max (iMn_min_M , iMn_out - mn_max_minus_mn_min);
      const int iMn_in_max_M = min (iMn_max_M , iMn_out + mn_max_minus_mn_min);

      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
      
      const unsigned long int total_outSDn_index_shifted = total_outSDn_index - total_outSDn_index_min;
      
      class array<class jumps_data_out_to_in_str> &one_jump_n_tab = one_jump_n_tabs(total_outSDn_index_shifted);
      			  
      const unsigned int i_thread = OpenMP_thread_number_determine ();
            
      class array<bool> &is_one_jump_n_calculated_tab = is_one_jump_n_calculated_tabs(i_thread);
      
      is_one_jump_n_calculated_tab = false;
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
	      
	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
				  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDp_index*dimension_outSDn;
      
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  for (unsigned int BPn_in = 0 ; BPn_in <= 1 ; BPn_in++)
			    for (int Sn_in = 0 ; Sn_in <= S ; Sn_in++)
			      for (int iMn_in = iMn_in_min_M ; iMn_in <= iMn_in_max_M ; iMn_in++)
				{
				  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;	    
			
				  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
	
				  bool &is_one_jump_n_calculated = is_one_jump_n_calculated_tab(BPn_in , Sn_in , Delta_iMn_in);

				  if (!is_one_jump_n_calculated)
				    {
				      class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in);
      
				      one_jump_n.one_jump_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw , BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , neut_Y_data);

				      is_one_jump_n_calculated = true;
				    }}}}}}}}
}



// Calculation of arrays of arrays of 2p-2h jumps data for protons and neutrons (plus a few hyperons if any) for the 2p-2h pp <-> nn conversion part of H
// ------------------------------------------------------------------------------------------------------------------------------------------------------
// They are functions of full outSDp/outSDn basis state indices,
// They are functions of full outSDp/outSDn basis state indices,
// and of the binary parity BPp_in or BPn_in, strangeness and number of spectators (see observables_basic_functions.cpp and enum_struct_definitions.h for definition), 
// and M projection difference index iMp_in - iMp_out + 2.mp_max or iMn_in - iMn_out + 2.mn_max (see GSM_vector_dimensions.cpp for definition)
// of the inSDp/inSDn basis state. They contain data related to the application of a+(alpha) a+(beta) a(alpha_spec) a(beta_spec) to inSDp/inSDn to obtain outSDp/outSDn,
// and to the application of a+(alpha_spec) a+(beta_spec) a(alpha) a(beta) to inSDp/inSDn to obtain outSDp/outSDn,
// for the cv H part of the form \sum a+(alpha_p) a+(beta_p) a(alpha_n) a(beta_n) <alpha_p beta_p | V | alpha_n beta_n> (nn to pp)
// and \sum a+(alpha_n) a+(beta_n) a(alpha_p) a(beta_p) <alpha_n beta_n | V | alpha_p beta_p> (pp to nn).
// They are stored if one_jumps_pn_two_jumps_cv_storage is not on the fly, as then one gains time as otherwise they are recalculated on the fly.
// 
// For this, one loops over all outSDp/outSDn basis states, and one generates all possible 2p-2h excitations from them.
// Associated 1p-1h jumps data are then stored in arrays.
//
// OpenMP parallelization is used on the loop of proton or neutron Slater determinants.
// MPI parallelization here is implicit, as on considers only the Slater determinants of the current node.

void H_class::two_jumps_cv_p_tab_out_to_in_all_SDp_calc (const bool is_it_cv_pp_to_nn)
{  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
          
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int S = GSM_vector_helper.get_S ();
  
  const int S_plus_one = S + 1;
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();

  const int four_mp_max = prot_Y_data.get_four_m_max ();
  
  const int four_mp_max_plus_one = four_mp_max + 1;
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();
 
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_out_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
    
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  if (total_outSDp_index_min > total_outSDp_index_max) return;
  			   
  class array<class array<bool> > are_two_jumps_cv_p_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) are_two_jumps_cv_p_calculated_tabs(i).allocate (2 , S_plus_one , four_mp_max_plus_one);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();

      const unsigned int BPn_out = binary_parity_product (BP , BPp_out);

      const int Sp_out = outSDp_qn.get_S ();
      
      const int Sn_out = S - Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();
      
      const int n_spec_n_out = n_spec_max - n_spec_p_out;
      
      const int n_scat_p_out = outSDp_qn.get_n_scat ();	

      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;

      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;
      
      const int n_spec_p_in = (is_it_cv_pp_to_nn) ? (n_spec_p_out - 2) : (n_spec_p_out + 2);
      
      const int iMn_out = iM - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();
      
      const unsigned long int total_outSDp_index_shifted = total_outSDp_index - total_outSDp_index_min;
      
      class array<class jumps_data_out_to_in_str> &two_jumps_cv_p_tab = (is_it_cv_pp_to_nn) ? (two_jumps_cv_p_pp_to_nn_tabs(total_outSDp_index_shifted)) : (two_jumps_cv_p_nn_to_pp_tabs(total_outSDp_index_shifted));
            
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class array<bool> &are_two_jumps_cv_p_calculated_tab = are_two_jumps_cv_p_calculated_tabs(i_thread);
      
      are_two_jumps_cv_p_calculated_tab = false;
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;
	      
	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDn_index;
		     			  
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
			    for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
			      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
				{
				  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
				
				  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
				    
				  bool &are_two_jumps_cv_p_calculated = are_two_jumps_cv_p_calculated_tab(BPp_in , Sp_in , Delta_iMp_in);
				    
				  if (!are_two_jumps_cv_p_calculated)
				    {
				      class jumps_data_out_to_in_str &two_jumps_cv_p = two_jumps_cv_p_tab(BPp_in , Sp_in , Delta_iMp_in);
				    
				      two_jumps_cv_p.two_jumps_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p ,  Ep_max_hw ,
									 BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , !is_it_cv_pp_to_nn , is_it_cv_pp_to_nn , prot_Y_data);
				    
				      are_two_jumps_cv_p_calculated = true;
				    }}}}}}}}
}

void H_class::two_jumps_cv_n_tab_out_to_in_all_SDn_calc (const bool is_it_cv_pp_to_nn)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
          
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();
  
  const int S_plus_one = S + 1;
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
    
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
    
  const int two_mn_max = neut_Y_data.get_two_m_max ();

  const int four_mn_max = neut_Y_data.get_four_m_max ();
          		  	
  const int four_mn_max_plus_one = four_mn_max + 1;
  	  
  const int mn_max_minus_mn_min = neut_Y_data.get_m_max_minus_m_min ();
    
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
    
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();
    
  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_out_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
  
  class array<class array<bool> > is_one_jump_n_calculated_tabs(NUMBER_OF_THREADS);
  
  class array<class array<bool> > are_two_jumps_cv_n_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) are_two_jumps_cv_n_calculated_tabs(i).allocate (2 , S_plus_one , four_mn_max_plus_one);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();

      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;

      const unsigned int BPn_out = outSDn_qn.get_BP ();
      
      const unsigned int BPp_out = binary_parity_product (BP , BPn_out);

      const int Sn_out = outSDn_qn.get_S ();
      
      const int Sp_out = S - Sn_out;
				 
      const int n_spec_n_out = outSDn_qn.get_n_spec ();
      
      const int n_spec_p_out = n_spec_max - n_spec_n_out;
      
      const int n_scat_n_out = outSDn_qn.get_n_scat ();	

      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;

      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;
      
      const int n_spec_n_in = (is_it_cv_pp_to_nn) ? (n_spec_n_out + 2) : (n_spec_n_out - 2);
      
      const int iMp_out = iM - iMn_out;

      const int iMn_in_min_M = max (iMn_min_M , iMn_out - mn_max_minus_mn_min);
      const int iMn_in_max_M = min (iMn_max_M , iMn_out + mn_max_minus_mn_min);

      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
      
      const unsigned long int total_outSDn_index_shifted = total_outSDn_index - total_outSDn_index_min;

      class array<class jumps_data_out_to_in_str> &two_jumps_cv_n_tab = (is_it_cv_pp_to_nn) ? (two_jumps_cv_n_pp_to_nn_tabs(total_outSDn_index_shifted)) : (two_jumps_cv_n_nn_to_pp_tabs(total_outSDn_index_shifted)); 
      			  
      const unsigned int i_thread = OpenMP_thread_number_determine ();
            
      class array<bool> &are_two_jumps_cv_n_calculated_tab = are_two_jumps_cv_n_calculated_tabs(i_thread);
      
      are_two_jumps_cv_n_calculated_tab = false;
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
	      
	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
				  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDp_index*dimension_outSDn;
      
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  for (unsigned int BPn_in = 0 ; BPn_in <= 1 ; BPn_in++)
			    for (int Sn_in = 0 ; Sn_in <= S ; Sn_in++)
			      for (int iMn_in = iMn_in_min_M ; iMn_in <= iMn_in_max_M ; iMn_in++)
				{
				  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
				
				  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				
				  bool &are_two_jumps_cv_n_calculated = are_two_jumps_cv_n_calculated_tab(BPn_in , Sn_in , Delta_iMn_in);

				  if (!are_two_jumps_cv_n_calculated)
				    {
				      class jumps_data_out_to_in_str &two_jumps_cv_n = two_jumps_cv_n_tab(BPn_in , Sn_in , Delta_iMn_in);
				      
				      two_jumps_cv_n.two_jumps_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw ,
									 BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , is_it_cv_pp_to_nn , !is_it_cv_pp_to_nn , neut_Y_data);
				      
				      are_two_jumps_cv_n_calculated = true;
				    }}}}}}}}
}




double used_memory_calc (const class H_class &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;
 
  double used_memory_allocated_arrays = used_memory_calc (T.GSM_vector_helper_full) +
    used_memory_calc (T.H_diagonal_tab) +
    used_memory_calc (T.H_diagonal_averaged_tab) +
    used_memory_calc (T.squares_non_zero_NBMEs_one_jump_numbers) +
    used_memory_calc (T.squares_non_zero_NBMEs_two_jumps_numbers) +
    used_memory_calc (T.space_dimensions_non_zero_one_jump_no_TRS) +
    used_memory_calc (T.space_dimensions_non_zero_two_jumps_no_TRS) +
    used_memory_calc (T.space_dimensions_non_zero_one_jump_TRS) +
    used_memory_calc (T.space_dimensions_non_zero_two_jumps_TRS) +
    used_memory_calc (T.PSI_row_indices_non_zero_one_jump_no_TRS_tables) +
    used_memory_calc (T.PSI_row_indices_non_zero_two_jumps_no_TRS_tables) +
    used_memory_calc (T.PSI_row_indices_non_zero_one_jump_TRS_tables) +
    used_memory_calc (T.PSI_row_indices_non_zero_two_jumps_TRS_tables) +
    used_memory_calc (T.squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables) +
    used_memory_calc (T.squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables) +
    used_memory_calc (T.squares_non_zero_NBMEs_one_jump_tables) +
    used_memory_calc (T.squares_non_zero_NBMEs_two_jumps_indices_tables) +
    used_memory_calc (T.squares_non_zero_NBMEs_two_jumps_tables) +
    used_memory_calc (T.one_jump_p_tabs) +
    used_memory_calc (T.one_jump_n_tabs) +
    used_memory_calc (T.M_TBMEs) +
    used_memory_calc (T.M_TBMEs_pn_indices) +
    used_memory_calc (T.M_TBMEs_cv_pp_to_nn_indices) +
    used_memory_calc (T.M_TBMEs_cv_nn_to_pp_indices)
    - (sizeof (T.GSM_vector_helper_full) +
       sizeof (T.H_diagonal_tab) +
       sizeof (T.H_diagonal_averaged_tab) +
       sizeof (T.squares_non_zero_NBMEs_one_jump_numbers) +
       sizeof (T.squares_non_zero_NBMEs_two_jumps_numbers) +
       sizeof (T.space_dimensions_non_zero_one_jump_no_TRS) +
       sizeof (T.space_dimensions_non_zero_two_jumps_no_TRS) +
       sizeof (T.space_dimensions_non_zero_one_jump_TRS) +
       sizeof (T.space_dimensions_non_zero_two_jumps_TRS) +
       sizeof (T.PSI_row_indices_non_zero_one_jump_no_TRS_tables) +
       sizeof (T.PSI_row_indices_non_zero_two_jumps_no_TRS_tables) +
       sizeof (T.PSI_row_indices_non_zero_one_jump_TRS_tables) +
       sizeof (T.PSI_row_indices_non_zero_two_jumps_TRS_tables) +
       sizeof (T.squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables) +
       sizeof (T.squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables) +
       sizeof (T.squares_non_zero_NBMEs_one_jump_tables) +
       sizeof (T.squares_non_zero_NBMEs_two_jumps_indices_tables) +
       sizeof (T.squares_non_zero_NBMEs_two_jumps_tables) +
       sizeof (T.one_jump_p_tabs) +
       sizeof (T.one_jump_n_tabs) +
       sizeof (T.M_TBMEs) +
       sizeof (T.M_TBMEs_pn_indices) +
       sizeof (T.M_TBMEs_cv_pp_to_nn_indices) +
       sizeof (T.M_TBMEs_cv_nn_to_pp_indices))/1000000.0;

  const class GSM_vector_helper_class &GSM_vector_helper = T.get_GSM_vector_helper ();
        
  const class array<unsigned int> &space_dimensions_all_processes = GSM_vector_helper.get_space_dimensions_all_processes ();
  
  const double unsigned_int_memory = sizeof (unsigned int)/1000000.0;

  const double TYPE_memory = sizeof (TYPE)/1000000.0;

  const double unsigned_int_TYPE_memory = unsigned_int_memory + TYPE_memory;
      
  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  const unsigned int N = (is_it_MPI_parallelized_local) ? (NUMBER_OF_PROCESSES) : (1);
  
  const class array<bool> &MPI_are_squares_occupied = GSM_vector_helper.get_MPI_are_squares_occupied ();
  
  const class array<unsigned int> &MPI_occupied_squares_row_indices = GSM_vector_helper.get_MPI_occupied_squares_row_indices ();

  if (T.space_dimensions_non_zero_one_jump_no_TRS.is_it_filled () && T.space_dimensions_non_zero_two_jumps_no_TRS.is_it_filled ())
    {
      if (T.squares_non_zero_NBMEs_one_jump_numbers.is_it_filled () && T.squares_non_zero_NBMEs_two_jumps_numbers.is_it_filled () && MPI_occupied_squares_row_indices.is_it_filled ())
	{
	  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	    {
	      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
	      
	      if (is_square_occupied)
		{
		  const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
		  
		  const unsigned int space_dimension_process = space_dimensions_all_processes(square_row_index);
		  
		  const unsigned int space_dimension_non_zero_one_jump_no_TRS  = T.space_dimensions_non_zero_one_jump_no_TRS(occupied_squares_row_index);
		  const unsigned int space_dimension_non_zero_two_jumps_no_TRS = T.space_dimensions_non_zero_two_jumps_no_TRS(occupied_squares_row_index);
		  
		  used_memory_allocated_arrays += (space_dimension_non_zero_one_jump_no_TRS + space_dimension_non_zero_two_jumps_no_TRS)*unsigned_int_memory;
		  		  
		  for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimension_process ; PSI_row_index++) 
		    {
		      const unsigned int squares_non_zero_NBMEs_one_jump_number  = T.squares_non_zero_NBMEs_one_jump_numbers(occupied_squares_row_index , PSI_row_index);			  
		      const unsigned int squares_non_zero_NBMEs_two_jumps_number = T.squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_row_index);
		      
		      used_memory_allocated_arrays += squares_non_zero_NBMEs_one_jump_number*unsigned_int_TYPE_memory;
		  
		      used_memory_allocated_arrays += squares_non_zero_NBMEs_two_jumps_number*unsigned_int_memory;
		      
		      if (T.Hamiltonian_storage == PARTIAL_STORAGE) used_memory_allocated_arrays += squares_non_zero_NBMEs_two_jumps_number*unsigned_int_memory;
		      if (T.Hamiltonian_storage == FULL_STORAGE)    used_memory_allocated_arrays += squares_non_zero_NBMEs_two_jumps_number*TYPE_memory;
		    }
		}
	    }
	}
    }
      
  if (T.space_dimensions_non_zero_one_jump_TRS.is_it_filled () && T.space_dimensions_non_zero_two_jumps_TRS.is_it_filled () && MPI_are_squares_occupied.is_it_filled ())
    {
      for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	{
	  const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
	  
	  if (is_square_occupied)
	    {
	      const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
	      
	      const unsigned int space_dimension_non_zero_one_jump_TRS  = T.space_dimensions_non_zero_one_jump_TRS(occupied_squares_row_index);
	      const unsigned int space_dimension_non_zero_two_jumps_TRS = T.space_dimensions_non_zero_two_jumps_TRS(occupied_squares_row_index);
		  
	      used_memory_allocated_arrays += (space_dimension_non_zero_one_jump_TRS + space_dimension_non_zero_two_jumps_TRS)*unsigned_int_memory;
	    }
	}      
    }
  
  const double used_memory = used_memory_constants + used_memory_allocated_arrays;
  
  return used_memory;
}











void H_class::print () const
{
  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Only serial processes allowed for the use of print of H_class.");
  
  if (Hamiltonian_storage != FULL_STORAGE) error_message_print_abort ("Full storage option must be used in print of H_class.");

  class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();
    
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
	  
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const int S = prot_Y_data.get_hypernucleus_strangeness ();
  
  const class Slater_determinant dummy_SD;

  const class GSM_vector V(GSM_vector_helper);

  class Slater_determinant inSDp(ZYval);
  class Slater_determinant inSDn(NYval);
  
  class Slater_determinant outSDp(ZYval);
  class Slater_determinant outSDn(NYval);
  
  for (unsigned int PSI_out_index = 0 ; PSI_out_index < space_dimension_process ; PSI_out_index++)
    {
      outSDp = (space != NEUT_Y_ONLY) ? (V.basis_SD_from_index (PROT_Y_ONLY , PSI_out_index)) : (dummy_SD);
      outSDn = (space != PROT_Y_ONLY) ? (V.basis_SD_from_index (NEUT_Y_ONLY , PSI_out_index)) : (dummy_SD);

      const unsigned int square_non_zero_NBMEs_one_jump_number  = squares_non_zero_NBMEs_one_jump_numbers (0 , PSI_out_index);
      const unsigned int square_non_zero_NBMEs_two_jumps_number = squares_non_zero_NBMEs_two_jumps_numbers(0 , PSI_out_index);

      const unsigned int *const square_non_zero_NBMEs_one_jump_PSI_column_indices  = squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables (0 , PSI_out_index);
      const unsigned int *const square_non_zero_NBMEs_two_jumps_PSI_column_indices = squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables(0 , PSI_out_index);
      
      const TYPE *const square_non_zero_NBMEs_one_jump  = squares_non_zero_NBMEs_one_jump_tables (0 , PSI_out_index);
      const TYPE *const square_non_zero_NBMEs_two_jumps = squares_non_zero_NBMEs_two_jumps_tables(0 , PSI_out_index);
      
      
      switch (space)
	{
	case PROT_Y_ONLY: 
	  {
	    cout << "inSD: "  , outSDp.print (phi_p_table);
	    cout << "outSD: " , outSDp.print (phi_p_table);
	  } break;

	case NEUT_Y_ONLY:
	  {
	    cout << "inSD: "  , outSDn.print (phi_n_table);
	    cout << "outSD: " , outSDn.print (phi_n_table);
	  } break;

	case PROT_NEUT_Y:
	  {
	    if (S == 0)
	      {
		cout << "inSDp: "  , outSDp.print (phi_p_table);
		cout << "inSDn: "  , outSDn.print (phi_n_table);
	    
		cout << "outSDp: " , outSDp.print (phi_p_table);
		cout << "outSDn: " , outSDn.print (phi_n_table);
	      }
	    else
	      {
		cout << "inSD[  charged baryons]: "  , outSDp.print (phi_p_table);
		cout << "inSD[uncharged baryons]: "  , outSDn.print (phi_n_table);
	    
		cout << "outSD[  charged baryons]: " , outSDp.print (phi_p_table);
		cout << "outSD[uncharged baryons]: " , outSDn.print (phi_n_table);
	      }
	  } break;

	default: abort_all ();
	}

      cout << "inSD index: " << PSI_out_index << " outSD index: " << PSI_out_index << " NBME: " << H_diagonal_tab(PSI_out_index) << endl << endl;

      for (unsigned int i = 0 ; i < square_non_zero_NBMEs_one_jump_number ; i++) 
	{
	  const unsigned int PSI_in_index = square_non_zero_NBMEs_one_jump_PSI_column_indices[i];

	  const TYPE &NBME = square_non_zero_NBMEs_one_jump[i];	

	  inSDp = (space != NEUT_Y_ONLY) ? (V.basis_SD_from_index (PROT_Y_ONLY , PSI_in_index)) : (dummy_SD);
	  inSDn = (space != PROT_Y_ONLY) ? (V.basis_SD_from_index (NEUT_Y_ONLY , PSI_in_index)) : (dummy_SD);

	  switch (space)
	    {
	    case PROT_Y_ONLY: 
	      {
		cout << "inSD: "  , inSDp.print (phi_p_table);
		cout << "outSD: " , outSDp.print (phi_p_table);
	      } break;

	    case NEUT_Y_ONLY:
	      {
		cout << "inSD: "  , inSDn.print (phi_n_table);
		cout << "outSD: " , outSDn.print (phi_n_table);
	      } break;

	    case PROT_NEUT_Y:
	      {
		if (S == 0)
		  {
		    cout << "inSDp: "  , outSDp.print (phi_p_table);
		    cout << "inSDn: "  , outSDn.print (phi_n_table);
	    
		    cout << "outSDp: " , outSDp.print (phi_p_table);
		    cout << "outSDn: " , outSDn.print (phi_n_table);
		  }
		else
		  {
		    cout << "inSD[  charged baryons]: "  , outSDp.print (phi_p_table);
		    cout << "inSD[uncharged baryons]: "  , outSDn.print (phi_n_table);
	    
		    cout << "outSD[  charged baryons]: " , outSDp.print (phi_p_table);
		    cout << "outSD[uncharged baryons]: " , outSDn.print (phi_n_table);
		  }
	      } break;

	    default: abort_all ();
	    }

	  cout << "inSD index: " << PSI_in_index << " outSD index: " << PSI_out_index << " NBME: " << NBME << endl << endl;
	}

      for (unsigned int i = 0 ; i < square_non_zero_NBMEs_two_jumps_number ; i++) 
	{
	  const unsigned int PSI_in_index = square_non_zero_NBMEs_two_jumps_PSI_column_indices[i];

	  const TYPE &NBME = square_non_zero_NBMEs_two_jumps[i];
	  
	  inSDp = (space != NEUT_Y_ONLY) ? (V.basis_SD_from_index (PROT_Y_ONLY , PSI_in_index)) : (dummy_SD);
	  inSDn = (space != PROT_Y_ONLY) ? (V.basis_SD_from_index (NEUT_Y_ONLY , PSI_in_index)) : (dummy_SD);	

	  switch (space)
	    {
	    case PROT_Y_ONLY: 
	      {
		cout << "inSD: "  , inSDp.print (phi_p_table);
		cout << "outSD: " , outSDp.print (phi_p_table);
	      } break;

	    case NEUT_Y_ONLY:
	      {
		cout << "inSD: "   , inSDn.print (phi_n_table);
		cout << "outSD: "  , outSDn.print (phi_n_table);
	      } break;

	    case PROT_NEUT_Y:
	      {
		if (S == 0)
		  {
		    cout << "inSDp: "  , outSDp.print (phi_p_table);
		    cout << "inSDn: "  , outSDn.print (phi_n_table);
	    
		    cout << "outSDp: " , outSDp.print (phi_p_table);
		    cout << "outSDn: " , outSDn.print (phi_n_table);
		  }
		else
		  {
		    cout << "inSD[  charged baryons]: "  , outSDp.print (phi_p_table);
		    cout << "inSD[uncharged baryons]: "  , outSDn.print (phi_n_table);
	    
		    cout << "outSD[  charged baryons]: " , outSDp.print (phi_p_table);
		    cout << "outSD[uncharged baryons]: " , outSDn.print (phi_n_table);
		  }
	      } break;

	    default: abort_all ();
	    }

	  cout << "inSD index: " << PSI_in_index << " outSD index: " << PSI_out_index << " NBME: " << NBME << endl << endl;
	}
    }
}










void H_class::apply_add (
			 const class GSM_vector &PSI_in , 
			 const TYPE &E , 
			 class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  H_MPI_communication_time = 0.0;

  H_multiplications_number = 0.0;
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array<unsigned long int> &TRS_total_PSI_indices = GSM_vector_helper.get_TRS_total_PSI_indices ();
   
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
 
  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();

  for (unsigned int PSI_index = 0 ; PSI_index < space_dimension_process ; PSI_index++) 
    {
      const unsigned long int total_PSI_index = PSI_index + first_total_PSI_index;

      if (!is_it_TRS || (TRS_total_PSI_indices(PSI_index) >= total_PSI_index)) H_multiplications_number += 1.0;
    }
  
  if (!PSI_in.same_parity_strangeness_M_projection  (GSM_vector_helper)) return;
  if (!PSI_out.same_parity_strangeness_M_projection (GSM_vector_helper)) return;
 
  const bool is_time_considered = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_detailed);

  const double reference_time = (is_time_considered) ? (absolute_time_determine ()) : (NADA);
  
  PSI_out.diagonal_part_PSI_add (PSI_in , H_diagonal_tab , E); 
  
  switch (Hamiltonian_storage)
    {
    case FULL_STORAGE:    apply_add_off_diagonal_full_or_partial_storage (PSI_in , PSI_out); break;      
    case PARTIAL_STORAGE: apply_add_off_diagonal_full_or_partial_storage (PSI_in , PSI_out); break;
      
    case ON_THE_FLY: apply_add_off_diagonal_on_the_fly (PSI_in , PSI_out); break;
      
    default: abort_all ();
    }
  
  if (is_it_TRS) PSI_out.TRS_rest_part_fill (is_there_cout_detailed , J);

  H_multiplications_number /= NUMBER_OF_THREADS;
  
#ifdef UseMPI
  MPI_helper::Barrier ();
#endif

  if (is_there_cout_detailed) H_MPI_communication_times_multiplications_number_print ();
  
  if (is_time_considered)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time;
  
      cout << "Time before H.PSI:" << reference_time << " s" << endl;
      cout << "Time after  H.PSI:" << now << " s" << endl;
      
      cout << "Hamiltonian applied. time:" << relative_time << " s" << endl << endl;
    }
}




void H_class::H_MPI_communication_times_multiplications_number_print () const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  const double H_MPI_communication_time_square = H_MPI_communication_time*H_MPI_communication_time;

  const double H_MPI_communication_time_min = min_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , H_MPI_communication_time);
  const double H_MPI_communication_time_max = max_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , H_MPI_communication_time);
      
  const double H_MPI_communication_time_sum         = sum_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , H_MPI_communication_time);
  const double H_MPI_communication_time_squares_sum = sum_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , H_MPI_communication_time_square);

  const double H_multiplications_number_square = H_multiplications_number*H_multiplications_number;

  const double H_multiplications_number_min = min_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , H_multiplications_number);
  const double H_multiplications_number_max = max_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , H_multiplications_number);
      
  const double H_multiplications_number_sum         = sum_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , H_multiplications_number);
  const double H_multiplications_number_squares_sum = sum_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , H_multiplications_number_square);

  if ((THIS_PROCESS == MASTER_PROCESS))
    {
      const double H_MPI_communication_time_average = H_MPI_communication_time_sum/NUMBER_OF_PROCESSES;

      const double H_MPI_communication_time_sigma = statistical_sigma_calc (NUMBER_OF_PROCESSES , H_MPI_communication_time_sum , H_MPI_communication_time_squares_sum);
	  
      const double H_multiplications_number_average = H_multiplications_number_sum/NUMBER_OF_PROCESSES;

      const double H_multiplications_number_sigma = statistical_sigma_calc (NUMBER_OF_PROCESSES , H_multiplications_number_sum , H_multiplications_number_squares_sum);
	  
      cout << endl;
      cout << "Hamiltonian MPI communication time min used by a process        : " << H_MPI_communication_time_min     << " s" << endl;
      cout << "Hamiltonian MPI communication time max used by a process        : " << H_MPI_communication_time_max     << " s" << endl;
      cout << "Hamiltonian MPI communication time average for all processes    : " << H_MPI_communication_time_average << " s" << endl;
      cout << "Hamiltonian MPI communication time dispersion for all processes : " << H_MPI_communication_time_sigma   << " s" << endl;

      cout << endl;
      cout << "Hamiltonian average multiplications number per thread min used by a process        : " << H_multiplications_number_min     << endl;
      cout << "Hamiltonian average multiplications number per thread max used by a process        : " << H_multiplications_number_max     << endl;
      cout << "Hamiltonian average multiplications number per thread average for all processes    : " << H_multiplications_number_average << endl;
      cout << "Hamiltonian average multiplications number per thread dispersion for all processes : " << H_multiplications_number_sigma   << endl;

      cout << endl;
    }
}







xH_plus_alpha_str::xH_plus_alpha_str (const TYPE &x_c , const TYPE &alpha_c , const class H_class &H_c) : x (x_c) , alpha (alpha_c) , H (H_c) {}

class xH_plus_alpha_str operator + (const class H_class &H)
{
  return xH_plus_alpha_str (1.0 , 0.0 , H);
}

class xH_plus_alpha_str operator - (const class H_class &H)
{
  return xH_plus_alpha_str (-1.0 , 0.0 , H);
}

class xH_plus_alpha_str operator + (const class H_class &H , const double alpha)
{
  return xH_plus_alpha_str (1.0 , alpha , H);
}

class xH_plus_alpha_str operator - (const class H_class &H , const double alpha)
{
  return xH_plus_alpha_str (1.0 , -alpha , H);
}

class xH_plus_alpha_str operator + (const double alpha , const class H_class &H)
{
  return xH_plus_alpha_str (1.0 , alpha , H);
}

class xH_plus_alpha_str operator - (const double alpha , const class H_class &H)
{
  return xH_plus_alpha_str (-1.0 , alpha , H);
}

class xH_plus_alpha_str operator * (const class H_class &H , const double x)
{
  return xH_plus_alpha_str (x , 0.0 , H);
}

class xH_plus_alpha_str operator * (const double x , const class H_class &H)
{
  return xH_plus_alpha_str (x , 0.0 , H);
}

class xH_plus_alpha_str operator / (const class H_class &H , const double x)
{
  const double one_over_x = 1.0/x;

  return xH_plus_alpha_str (one_over_x , 0.0 , H);
}

class xH_plus_alpha_str operator + (const class xH_plus_alpha_str &Op)
{
  return xH_plus_alpha_str (Op.x , Op.alpha , Op.H);
}

class xH_plus_alpha_str operator - (const class xH_plus_alpha_str &Op)
{
  return xH_plus_alpha_str (-Op.x , -Op.alpha , Op.H);
}

class xH_plus_alpha_str operator + (const class xH_plus_alpha_str &Op , const double term)
{
  return xH_plus_alpha_str (Op.x , Op.alpha + term , Op.H);
}

class xH_plus_alpha_str operator - (const class xH_plus_alpha_str &Op , const double term)
{
  return xH_plus_alpha_str (Op.x , Op.alpha - term , Op.H);
}

class xH_plus_alpha_str operator + (const double term , const class xH_plus_alpha_str &Op)
{
  return xH_plus_alpha_str (Op.x , term + Op.alpha , Op.H);
}

class xH_plus_alpha_str operator - (const double term , const class xH_plus_alpha_str &Op)
{
  return xH_plus_alpha_str (-Op.x , term - Op.alpha , Op.H);
}

class xH_plus_alpha_str operator * (const class xH_plus_alpha_str &Op , const double factor)
{
  return xH_plus_alpha_str (Op.x*factor , Op.alpha*factor , Op.H);
}

class xH_plus_alpha_str operator / (const class xH_plus_alpha_str &Op , const double factor)
{
  return xH_plus_alpha_str (Op.x/factor , Op.alpha/factor , Op.H);
}

class xH_plus_alpha_str operator * (const double factor , const class xH_plus_alpha_str &Op)
{
  return xH_plus_alpha_str (factor*Op.x , factor*Op.alpha , Op.H);
}

#ifdef TYPEisDOUBLECOMPLEX

class xH_plus_alpha_str operator + (const class H_class &H , const complex<double> &alpha)
{
  return xH_plus_alpha_str (1.0 , alpha , H);
}

class xH_plus_alpha_str operator - (const class H_class &H , const complex<double> &alpha)
{
  return xH_plus_alpha_str (1.0 , -alpha , H);
}

class xH_plus_alpha_str operator + (const complex<double> &alpha , const class H_class &H)
{
  return xH_plus_alpha_str (1.0 , alpha , H);
}

class xH_plus_alpha_str operator - (const complex<double> &alpha , const class H_class &H)
{
  return xH_plus_alpha_str (-1.0 , alpha , H);
}

class xH_plus_alpha_str operator * (const class H_class &H , const complex<double> &x)
{
  return xH_plus_alpha_str (x , 0.0 , H);
}

class xH_plus_alpha_str operator * (const complex<double> &x , const class H_class &H)
{
  return xH_plus_alpha_str (x , 0.0 , H);
}

class xH_plus_alpha_str operator / (const class H_class &H , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return xH_plus_alpha_str (one_over_x , 0.0 , H);
}

class xH_plus_alpha_str operator + (const class xH_plus_alpha_str &Op , const complex<double> &term)
{
  return xH_plus_alpha_str (Op.x , Op.alpha + term , Op.H);
}

class xH_plus_alpha_str operator - (const class xH_plus_alpha_str &Op , const complex<double> &term)
{
  return xH_plus_alpha_str (Op.x , Op.alpha - term , Op.H);
}

class xH_plus_alpha_str operator + (const complex<double> &term , const class xH_plus_alpha_str &Op)
{
  return xH_plus_alpha_str (Op.x , term + Op.alpha , Op.H);
}

class xH_plus_alpha_str operator - (const complex<double> &term , const class xH_plus_alpha_str &Op)
{
  return xH_plus_alpha_str (-Op.x , term - Op.alpha , Op.H);
}

class xH_plus_alpha_str operator * (const class xH_plus_alpha_str &Op , const complex<double> &factor)
{
  return xH_plus_alpha_str (Op.x*factor , Op.alpha*factor , Op.H);
}

class xH_plus_alpha_str operator / (const class xH_plus_alpha_str &Op , const complex<double> &factor)
{
  return xH_plus_alpha_str (Op.x/factor , Op.alpha/factor , Op.H);
}

class xH_plus_alpha_str operator * (const complex<double> &factor , const class xH_plus_alpha_str &Op)
{
  return xH_plus_alpha_str (factor*Op.x , factor*Op.alpha , Op.H);
}

#endif

class xH_plus_alpha_str operator + (const class xH_plus_alpha_str &Op_a , const class xH_plus_alpha_str &Op_b)
{
  if (&(Op_a.H) != &(Op_b.H))
    error_message_print_abort ("H must be the same in both Op_a and Op_b in class xH_plus_alpha_str operator +");

  return xH_plus_alpha_str (Op_a.x + Op_b.x , Op_a.alpha + Op_b.alpha , Op_a.H);
}

class xH_plus_alpha_str operator - (const class xH_plus_alpha_str &Op_a , const class xH_plus_alpha_str &Op_b)
{	
  if (&(Op_a.H) != &(Op_b.H))
    error_message_print_abort ("H must be the same in both Op_a and Op_b in class xH_plus_alpha_str operator -");

  return xH_plus_alpha_str (Op_a.x - Op_b.x , Op_a.alpha - Op_b.alpha , Op_a.H);
}


