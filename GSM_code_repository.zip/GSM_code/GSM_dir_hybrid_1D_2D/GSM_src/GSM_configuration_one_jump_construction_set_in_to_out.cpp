#include "../GSM_include/GSM_include_def.h"

using namespace GSM_vector_dimensions;


// TYPE is double or complex
// -------------------------

// in_to_out means that one starts from |inSD> and one creates |outSD> from a+ a operations
// ----------------------------------------------------------------------------------------



// Calculation and storage of jumps for the application of H or J+/J- stored with the hybrid 1D-2D parallelization
// ---------------------------------------------------------------------------------------------------------------
//
// H or J+/J- is written in second quantization: H = \sum_ab <a | H | b> a+(a) a(b) + \sum_abcd <ab | H | cd> a+(a) a+(b) a(d) a(c), and J+/J- = \sum_ab <a | J+/J- | b> a+(a) a(b).
// Hence, in order to apply Op to a GSM vector vector, one has to calculate jumps of the form <outSD | a+(a) a(b) | inSD> and <outSD | a+(a) a+(b) a(d) a(c) | inSD>.

// The pp, nn two-body jumps are written as <outSD | a+(a) a+(b) a(d) a(c) | inSD> = <outSD | a+(a) a(c) | SDinter> <SDinter | a+(b) a(d) | inSD>, with |SDinter> an intermediate Slater determinant.
// The pn two-body jumps <outSD | a+(a) a+(b) a(d) a(c) | inSD> are equal to  <outSDp | a+(a) a(c) | inSDp>  <outSDn | a+(b) a(d) | inSDn>, so that no intermediate Slater determinant is needed here.
// Hence, all jumps can be calculated from those of the form <outSD | a+(a) a(b) | inSD>. 
// 
// In order not to consider intermediate Slater determinants with many particles in the continuum, one demands all Slater determinants to have a number particles in the continuum smaller or equal
// to that of the model space. This is possible as can always reshuffle the a+/a operators above for |SDinter> to be in that situation.
//
// The many-operators associated to this namespace are H and J+/J- used with full storage.
// One uses hybrid 1D/2D partitioning for GSM vectors and operators, so that input and output GSM vectors are scattered over all nodes, but H or J+/J- are stored in a 1D fashion:
//
//     H or J+/J-           x  Psi[in]  =  Psi[out]
// 
// *     *     *    *    *       *           *
// *     *     *    *    *     node 0      node 0 (from reduction over all nodes)
// *  n  *  n  *  n *  n *       *           *
// *  o  *  o  *  o *  o *     node 1      node 1 (from reduction over all nodes)
// *  d  *  d  *  d *  d *       *           *
// *  e  *  e  *  e *  e *     node 2      node 2 (from reduction over all nodes)
// *     *     *    *    *       *           *
// *  0  *  1  *  2 *  3 *     node 3      node 3 (from reduction over all nodes)
// *     *     *    *    *       *           *
//
// To calcuiate the outSD component of |Psi[out]> = \sum_{outSD} c_{outSD} |outSD>, which is c_{outSD} = \sum_{inSD} c_{inSD} <outSD | H or J+/J- | inSD>,
// one loops over all nodes, and a fixed node takes care of a few inSD, so that c_{outSD} is issued from a reduction over all nodes at the end of the calculation.
// Hence, on a fixed node, to calculate and store the matrix elements of H or J+/J-, the inSD considered are those of this node, while the outSD cover all the configuration space, to create a column of H or J+/J- above.
// Thus, on a fixed node, one runs over all its inSD, to generate the 1p-1h outSD. This scheme is thus called "in to out".
//
// Consequently, in the jump routines, one starts from |inSD>, or its configuration C[in], and 1p-1h excitations generate |outSD>, or its configuration C[out].
// Hence, one goes from inSD to outSD.
// 
// One can separate in the calculation of <outSD | a+(a) a(b) | inSD> in two parts: 
//
// _One considers only configurations and shells, so that a, b become (n,l,j) shells and inSD, outSD are replaced by their configurations C[in], C[out].
//  C[out] is generated from C[in] with 1p-1h excitations from the occupied shells of C[in] to its unoccupied shells.
//  No matrix element is calculated here, but one one stores the indices the shells a, b and the quantum numbers of configurations.
//
// _One fixes C[in], C[out], a(shell), b(shell), and one obtains <outSD | a+(a) a(b) | inSD> by adding only m quantum numbers.
//  One stores the phase <outSD | a+(a) a(b) | inSD>, and also m quantum numbers.
//
// One considers only configurations and shells in this namespace.
// Previously introduced notations are used throughout this namespace.
//
// OpenMP parallelization is used on the loop of proton or neutron configurations.
// MPI parallelization here is only implicit, as on considers only the configurations which are used in operators by the current node.
// 
//
// Equivalent configurations in scattering many-body spaces
// --------------------------------------------------------
// When one has scattering states in the one-body basis, it is possible to reduce the number of stored <outSD | a+(a) a(b) | inSD> jumps by using the fact that one has many more scattering states than valence nucleons.
// For example, let us consider that the one-body states consist of 51 p3/2 shells, issued from the discretization of the p3/2 contour, and that one has a configuration of three valence nucleons.
// These are typical values in GSM. As one has in average 17 shells between two nucleons, with only one nucleon per shell for most configurations, 
// a 1p-1h excitation from an occupied shell to another leaves the <outSD | a+(a) a(b) | inSD> matrix element unchanged, as only the principal quantum number of |a> changes.
// Moreover, Slater determinants are formally identical from one configuration to the other in this case, as the number and indices of one-body states on one shell depend only on j and m.
//
// Hence, this <outSD | a+(a) a(b) | inSD> matrix element is stored only once, and one starts storing other matrix elements once 1p-1h excitations make the nucleon arrive on an occupied shell, 
// or if one arrives on a new partial wave. One-body states are evidently ordered so that all one-body states of a given partial wave are contiguous.
//
// The configuration for which <outSD | a+(a) a(b) | inSD> matrix element is stored is a called an equivalent configuration, 
// as it represents all the configurations equivalent to the latter for the calculation of <outSD | a+(a) a(b) | inSD> matrix elements.









// Storage of dimensions and configuration jumps in arrays
// -------------------------------------------------------
// A C[in] configuration jump has been generated and belongs to the proton or neutron model space.
// If arrays dimensions are calculated only, the dimension of fixed C[in] configuration and binary parity (see observables_basic_functions.cpp for definition) Pi[out] is increased. 
// If configuration jumps arrays are constructed, the number of particles in the continuum, index of configuration C[out], and indices of a,b shells are also stored in the array containing configuration jumps.
// The index of C[out] is calculated with a binary search (see GSM_configuration.cpp).
//
// Storage is done according to model space truncation.
// Indeed, as one can be using an intermediate Slater determinant |SDinter>, C[in] and/or C[out] might not belong to the model space.
// But, of course, one of them has to belong to the model space, as one cannot have two intermediate Slater determinants.
// This situation cannot occur if one builds jumps for a one-body or proton-neutron two-body operator, i.e. a many-body operator whose non-zero TBMEs are proton-neutron TBMEs.
// Indeed, jumps occurring in this case cannot involve intermediate Slater determinants, and C[out] has to belong to the model space.


void configuration_one_jump_construction_set_in_to_out::configuration_one_jump_data_fill (
											  const bool is_it_one_body_two_body_pn , 
											  const enum operation_type operation , 
											  const bool is_configuration_in_in_space , 
											  const unsigned int BP_out , 
											  const int n_holes_out , 
											  const int n_scat_out , 
											  const unsigned int C_in_jump_shell , 
											  const unsigned int C_out_jump_shell , 
											  const unsigned int C_eq_one_jump_index , 
											  const unsigned int configuration_one_jump_table_zero_index , 
											  const unsigned int dimensions_configuration_one_jump_table_index ,
											  const class configuration &C_out , 	
											  class configuration &C_try , 	
											  class nucleons_data &particles_data)
{
  const class array<unsigned int> &dimensions_configuration_set = particles_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = particles_data.get_configuration_set ();
  
  const unsigned int dimension_iC_out_set = dimensions_configuration_set(BP_out , n_scat_out);

  const unsigned int configuration_set_zero_iC_out = configuration_set.index_determine (BP_out , n_scat_out , 0);

  const unsigned int iC_out = C_out.index_search (dimension_iC_out_set , configuration_set_zero_iC_out , configuration_set , C_try);
  
  const class array_BP_Nscat_iC<bool> &is_configuration_out_in_space_tab = particles_data.get_is_configuration_out_in_space_tab ();

  const bool is_configuration_out_in_space = is_configuration_out_in_space_tab(BP_out , n_scat_out , iC_out);
  
  const bool is_there_storage = (is_it_one_body_two_body_pn) ? (is_configuration_out_in_space) : (is_configuration_in_in_space || is_configuration_out_in_space);

  if (is_there_storage)
    {
      class array_BP_Nscat_iC<unsigned int> &dimensions_configuration_one_jump_table = particles_data.get_dimensions_configuration_one_jump_table_in_to_out ();

      switch (operation)
	{
	case DIMENSIONS_TABLES_CALC:
	  dimensions_configuration_one_jump_table[dimensions_configuration_one_jump_table_index]++;
	  break;

	case TABLES_FILL:
	  { 
	    const unsigned int configuration_one_jump_index = dimensions_configuration_one_jump_table[dimensions_configuration_one_jump_table_index]++;
	    const unsigned int configuration_one_jump_table_index = configuration_one_jump_table_zero_index + configuration_one_jump_index;

	    class array_of_configuration_one_jump_data_in_to_out &configuration_one_jump_table = particles_data.get_configuration_one_jump_table_in_to_out ();

	    configuration_one_jump_table[configuration_one_jump_table_index].initialize (n_holes_out , n_scat_out , iC_out , C_eq_one_jump_index , C_in_jump_shell , C_out_jump_shell);
	  } break; 

	default: abort_all ();
	}
    }
}






// Generation of all 1p-1h configurations C[out] out of a configuration C[in] with fixed parity Pi[in]
// ---------------------------------------------------------------------------------------------------
// One generates all the C[out] configurations with 1p-1h excitations on C[in] fixed.
// Redundancy of <outSD | a+(a) a(b) | inSD> values is avoided by using equivalent configurations (see above).

void configuration_one_jump_construction_set_in_to_out::configuration_one_jump_all_C_out (
											  const bool is_it_only_basis , 
											  const bool is_it_one_body_two_body_pn , 
											  const enum operation_type operation , 
											  const bool truncation_hw , 
											  const bool truncation_ph , 
											  const bool is_it_pole_approximation ,
											  const int n_holes_in ,  
											  const int n_scat_in , 
											  const int E_in_hw , 
											  const class configuration &C_in , 
											  const unsigned int configuration_one_jump_table_zero_index , 
											  const unsigned int dimensions_configuration_one_jump_table_index , 
											  const bool is_configuration_in_in_space , 
											  const unsigned int BP_out , 
											  const unsigned int BP_jump , 
											  class configuration &C_out , 	
											  class configuration &C_try , 	
											  unsigned int &C_eq_one_jump_index , 
											  bool &first_configuration_one_jump_for_C_in ,
											  class nucleons_data &particles_data)
{  
  const int n_holes_max = (is_it_pole_approximation) ? (particles_data.get_n_holes_max_pole_approximation ()) : (particles_data.get_n_holes_max ());
  
  const int n_scat_max = (is_it_pole_approximation) ? (0) : (particles_data.get_n_scat_max ());

  const int E_max_hw = (is_it_pole_approximation) ? (particles_data.get_E_max_hw_pole_approximation ()) : (particles_data.get_E_max_hw ());

  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  for (int i_in = 0 ; i_in < N_valence_nucleons ; i_in++)
    {
      if ((i_in == 0) || (C_in[i_in] != C_in[i_in - 1]))
	{
	  const unsigned int C_in_jump_shell = C_in[i_in];

	  const class nlj_struct &shell_in = shells_qn(C_in_jump_shell);
	  
	  const bool S_matrix_pole_in = shell_in.get_S_matrix_pole ();

	  const bool is_n_scat_in_max = (n_scat_in == n_scat_max);
	  
	  const int l_in = shell_in.get_l ();
	  
	  const int e_shell_in = shell_in.get_e_trunc ();

	  const int E_in_hw_minus_e_shell_in = E_in_hw - e_shell_in;
	  
	  const bool frozen_state_in = shell_in.get_frozen_state ();
	      
	  const bool core_state_in = shell_in.get_core_state ();
			  
	  const bool core_active_state_in = (core_state_in && !frozen_state_in);
			  
	  const int scat_shell_in = (S_matrix_pole_in) ? (0) : (1);

	  const int n_scat_in_minus_scat_shell_in = n_scat_in - scat_shell_in;

	  bool crossing_occupied_shell_bef = true;

	  int l_out_bef = -1;

	  int ij_out_bef = -1;

	  for (unsigned int C_out_jump_shell = 0 ; C_out_jump_shell < N_nlj ; C_out_jump_shell++)
	    {
	      if (is_it_only_basis && (C_in_jump_shell != C_out_jump_shell)) continue;

	      const class nlj_struct &shell_out = shells_qn(C_out_jump_shell);

	      const bool frozen_state_out = shell_out.get_frozen_state ();

	      if (frozen_state_out) continue;
	      
	      const bool S_matrix_pole_out = shell_out.get_S_matrix_pole ();

	      const bool scat_side_effect = (is_n_scat_in_max && (!S_matrix_pole_out));

	      if (!scat_side_effect || !S_matrix_pole_in)
		{
		  const int shell_out_content = shell_out.m_number_determine ();

		  const int shell_out_occupancy = C_in.occupancy_determine (C_out_jump_shell);

		  if (shell_out_occupancy < shell_out_content)
		    {
		      const int l_out = shell_out.get_l ();

		      const int ij_out = shell_out.get_ij ();

		      const bool crossing_occupied_shell = (shell_out_occupancy > 0);
		      
		      const unsigned int bp_change = (l_in + l_out) % 2;
		      
		      if (bp_change == BP_jump)
			{
			  const int e_shell_out = shell_out.get_e_trunc ();

			  const int E_out_hw = E_in_hw_minus_e_shell_in + e_shell_out;
			  
			  const bool core_state_out = shell_out.get_core_state ();
	      
			  const bool core_active_state_out = (core_state_out && !frozen_state_out);

			  const bool n_holes_out_same = ((core_active_state_in && core_active_state_out) || (!core_active_state_in && !core_active_state_out));

			  const int n_holes_out_if_it_changes = (core_active_state_in && !core_active_state_out) ? (n_holes_in + 1) : (n_holes_in - 1);
			  
			  const int n_holes_out = (n_holes_out_same) ? (n_holes_in) : (n_holes_out_if_it_changes);
			  
			  const int scat_shell_out = (S_matrix_pole_out) ? (0) : (1);

			  const int n_scat_out = n_scat_in_minus_scat_shell_in + scat_shell_out;

			  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			  
			  C_in.excitation_1p_1h (C_out_jump_shell , C_in_jump_shell , C_out);

			  if (C_out.all_frozen_states_occupied (shells_qn))
			    {
			      if (!first_configuration_one_jump_for_C_in)
				{
				  const bool crossing_occupied_shells = (crossing_occupied_shell_bef || crossing_occupied_shell);

				  if (crossing_occupied_shells)
				    C_eq_one_jump_index++;
				  else
				    {
				      const bool changing_partial_wave = ((l_out != l_out_bef) || (ij_out != ij_out_bef));

				      if (changing_partial_wave) C_eq_one_jump_index++;
				    }
				}
			      			      
			      configuration_one_jump_data_fill (is_it_one_body_two_body_pn , operation , is_configuration_in_in_space ,
								BP_out , n_holes_out , n_scat_out , C_in_jump_shell , C_out_jump_shell ,
								C_eq_one_jump_index , configuration_one_jump_table_zero_index , dimensions_configuration_one_jump_table_index ,
								C_out , C_try , particles_data);

			      first_configuration_one_jump_for_C_in = false;
			    }
			}		
		      
		      l_out_bef = l_out;

		      ij_out_bef = ij_out;

		      crossing_occupied_shell_bef = crossing_occupied_shell;
		    }
		  else
		    crossing_occupied_shell_bef = true;
		}}}}
}





// Calculation of all the C[out] 1p-1h configurations jumps for all C[in] configurations
// -------------------------------------------------------------------------------------
// One loops over all C[in] configurations and one calls the previous routine.
//
// One checks if one has to do a calculation or not according to the used operator and model space truncations.
// _If one has a one-body operator or a proton-neutron two body operator, hence one-body like as there is no intermediate Slater determinant (see above),
//  the calculation must be done only if C[in] belongs to the model space and the current Pi[out] can be attained with this operator (calculated elsewhere).
// _If one has a two-body operator with pp and nn two-body matrix elements, hence involving intermediate Slater determinants (see above),
//  the calculation must be done only if C[in] belongs to the model space or if the current Pi[out] can be attained with this operator (calculated elsewhere).
//  Indeed, if C[in] does not belong to the model space and hence |inSD> is |SDinter> here, |outSD> has to belong to the model space and hence the current Pi[out] must be attained with this operator (calculated elsewhere).
//
// OpenMP is used on the index of the C[in] configuration for fixed parity and number of particles in the continuum, which is usually more than the number of threads.
// It is inside other loops, but whose number of elements is very small, as the maximal number of particles in the continuum is 2 to 4 typically.

void configuration_one_jump_construction_set_in_to_out::all_configurations_one_jump_all_configurations (
													const bool is_it_only_basis , 
													const bool is_it_one_body_two_body_pn , 
													const enum operation_type operation , 
													const bool truncation_hw , 
													const bool truncation_ph , 
													const bool is_it_pole_approximation , 
													class nucleons_data &particles_data)
{
  const int n_scat_max = (is_it_pole_approximation) ? (0) : (particles_data.get_n_scat_max ());

  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();
  
  const class array<unsigned int> &dimensions_configuration_set = particles_data.get_dimensions_configuration_set ();
  
  const class array_BP_Nscat_iC<int> &n_holes_table = particles_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &E_hw_table = particles_data.get_E_hw_table ();

  const class array_of_configuration &configuration_set = particles_data.get_configuration_set ();

  const class array_BP_Nscat_iC<bool> &is_configuration_in_in_space_tab = particles_data.get_is_configuration_in_in_space_tab (0); 

  const class array<bool> &BPout_for_one_jump_tab = particles_data.get_BPout_for_one_jump_tab ();

  const class array_of_configuration_one_jump_data_in_to_out &configuration_one_jump_table = particles_data.get_configuration_one_jump_table_in_to_out ();

  class array_BP_Nscat_iC<unsigned int> &dimensions_configuration_one_jump_table = particles_data.get_dimensions_configuration_one_jump_table_in_to_out ();
  
  dimensions_configuration_one_jump_table = 0;
  
  class array<class configuration> C_in_tab(NUMBER_OF_THREADS);
  class array<class configuration> C_out_tab(NUMBER_OF_THREADS);
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      C_in_tab(i).allocate (N_valence_nucleons);
      C_out_tab(i).allocate (N_valence_nucleons);
      C_try_tab(i).allocate (N_valence_nucleons);
    }
	    
  for (unsigned int BP_in = 0 ; BP_in <= 1 ; BP_in++)
    for (int n_scat_in = 0 ; n_scat_in <= n_scat_max ; n_scat_in++)
      {
	const unsigned int dimensions_configuration_in = dimensions_configuration_set(BP_in , n_scat_in);

	const unsigned int is_configuration_in_in_space_in_zero_index = is_configuration_in_in_space_tab.index_determine (BP_in , n_scat_in , 0);

	const unsigned int n_holes_in_zero_index = n_holes_table.index_determine (BP_in , n_scat_in , 0); 

	const unsigned int E_in_hw_zero_index = E_hw_table.index_determine (BP_in , n_scat_in , 0); 

	const unsigned int configuration_set_in_zero_index = configuration_set.index_determine (BP_in , n_scat_in , 0);
	
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
	for (unsigned int iC_in = 0 ; iC_in < dimensions_configuration_in ; iC_in++)
	  {
	    const unsigned int i_thread = OpenMP_thread_number_determine ();

	    class configuration &C_in = C_in_tab(i_thread);
	    class configuration &C_out = C_out_tab(i_thread);
	    class configuration &C_try = C_try_tab(i_thread);
  
	    const unsigned int is_configuration_in_in_space_in_index = is_configuration_in_in_space_in_zero_index + iC_in;

	    const unsigned int n_holes_in_index = n_holes_in_zero_index + iC_in;
	    
	    const unsigned int E_in_hw_index = E_in_hw_zero_index + iC_in;

	    const unsigned int configuration_set_in_index = configuration_set_in_zero_index + iC_in;

	    const bool is_configuration_in_in_space = is_configuration_in_in_space_tab[is_configuration_in_in_space_in_index];
	    
	    const int n_holes_in = n_holes_table[n_holes_in_index];
	    
	    const int E_in_hw = E_hw_table[E_in_hw_index];

	    const unsigned int dimensions_configuration_one_jump_table_zero_index = dimensions_configuration_one_jump_table.index_determine (BP_in , n_scat_in , iC_in , 0);

	    unsigned int C_eq_one_jump_index = 0;

	    bool first_configuration_one_jump_for_C_in = true;

	    C_in = configuration_set[configuration_set_in_index];
	    
	    for (unsigned int BP_out = 0 ; BP_out <= 1 ; BP_out++)
	      {
		const int BP_jump = binary_parity_product (BP_in , BP_out);

		const bool BPout_for_one_jump = BPout_for_one_jump_tab(BP_out);

		const bool is_there_calc_one_body = (is_it_one_body_two_body_pn  && (is_configuration_in_in_space && BPout_for_one_jump));
		const bool is_there_calc_two_body = (!is_it_one_body_two_body_pn && (is_configuration_in_in_space || BPout_for_one_jump));

		const bool is_there_calc = (is_there_calc_one_body || is_there_calc_two_body);
	    
		if (is_there_calc)
		  {
		    const unsigned int configuration_one_jump_table_zero_index = (operation == TABLES_FILL)
		      ? (configuration_one_jump_table.index_determine (BP_in , n_scat_in , iC_in , BP_out , 0))
		      : (NADA);
		    
		    const unsigned int dimensions_configuration_one_jump_table_index = dimensions_configuration_one_jump_table_zero_index + BP_out;

		    configuration_one_jump_all_C_out (is_it_only_basis , is_it_one_body_two_body_pn , operation , truncation_hw , truncation_ph , is_it_pole_approximation ,
						      n_holes_in , n_scat_in , E_in_hw , C_in , 
						      configuration_one_jump_table_zero_index , dimensions_configuration_one_jump_table_index , is_configuration_in_in_space ,
						      BP_out , BP_jump , C_out , C_try , C_eq_one_jump_index , first_configuration_one_jump_for_C_in , particles_data);
		  }
	      }
	  }
      }
}






// Allocation and calculation of all the C[out] 1p-1h configurations jumps for all C[in] configurations
// ----------------------------------------------------------------------------------------------------
// One allocates arrays and one calls the previous routine.
// Dimensions of arrays of configuration jumps are calculated first, they are allocated, and then calculated.
// Time taken to do calculations can be also written, as they can be lengthy.

void configuration_one_jump_construction_set_in_to_out::all_configurations_one_jump_all_configurations_alloc_calc (
														   const bool is_there_cout , 
														   const bool is_it_only_basis , 
														   const bool is_it_one_body_two_body_pn ,
														   const bool truncation_hw , 
														   const bool truncation_ph , 
														   const bool is_it_pole_approximation , 
														   class nucleons_data &particles_data)
{	
  const double time_1 = absolute_time_determine ();

  class array_BP_Nscat_iC<unsigned int> &dimensions_configuration_one_jump_table = particles_data.get_dimensions_configuration_one_jump_table_in_to_out ();

  class array_of_configuration_one_jump_data_in_to_out &configuration_one_jump_table = particles_data.get_configuration_one_jump_table_in_to_out ();

  const enum particle_type particle = particles_data.get_particle ();

  const unsigned int dimension_configuration_total = particles_data.get_dimension_configuration_total ();

  const int n_scat_max = (is_it_pole_approximation) ? (0) : (particles_data.get_n_scat_max ());

  const class array<unsigned int> &dimensions_configuration_set = particles_data.get_dimensions_configuration_set ();

  const class array<unsigned int> &sum_dimensions_configuration_set = particles_data.get_sum_dimensions_configuration_set ();

  dimensions_configuration_one_jump_table.deallocate ();

  configuration_one_jump_table.deallocate ();
  
  dimensions_configuration_one_jump_table.allocate (dimension_configuration_total , sum_dimensions_configuration_set , 2);

  all_configurations_one_jump_all_configurations (is_it_only_basis , is_it_one_body_two_body_pn , DIMENSIONS_TABLES_CALC ,
						  truncation_hw , truncation_ph , is_it_pole_approximation , particles_data);

  const double time_2 = absolute_time_determine () , relative_time_dimension = time_2 - time_1; 

  configuration_one_jump_table.allocate (n_scat_max , dimension_configuration_total , dimensions_configuration_set ,
					 sum_dimensions_configuration_set , dimensions_configuration_one_jump_table);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const double dimensions_configuration_one_jump_table_used_memory = used_memory_calc (dimensions_configuration_one_jump_table);
      
      const double configuration_one_jump_table_used_memory = used_memory_calc (configuration_one_jump_table);

      cout << endl << "configuration jumps " << particle << " full storage" << endl;
      cout << "dimensions: " << dimensions_configuration_one_jump_table_used_memory << " Mb" << endl;
      cout << "array     : " << configuration_one_jump_table_used_memory << " Mb" << endl;
      cout << "time      : " << relative_time_dimension << " s" << endl << endl;
    }

  all_configurations_one_jump_all_configurations (is_it_only_basis , is_it_one_body_two_body_pn , TABLES_FILL , truncation_hw , truncation_ph , is_it_pole_approximation , particles_data);

  const double time_3 = absolute_time_determine () , relative_time = time_3 - time_2; 

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    cout << "configuration jumps " << particle << " full storage calculated. time:" << relative_time << " s" << endl << endl;
}


