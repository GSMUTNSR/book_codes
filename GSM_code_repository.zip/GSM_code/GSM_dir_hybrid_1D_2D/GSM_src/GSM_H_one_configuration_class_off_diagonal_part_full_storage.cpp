#include "../GSM_include/GSM_include_def.h"

using namespace GSM_vector_NBMEs_handling;


// TYPE is double or complex
// -------------------------


// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons
// ------------------------------------------------------------------------------------------------------------------------------------------------------



// Storage of non-zero NBMEs of the Hamiltonian and application of H times vector for the off-diagonal part for a fixed configuration for the calculation of MSDHF potentials
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Non-zero NBMEs of the Hamiltonian are calculated and stored therein. Array dimensions have been calculated in GSM_H_one_configuration_class_non_zero_NBMEs_numbers.cpp .
//
// TRS is time-reversal symmetry and can be used therein.
// It allows to to calculate about one half of |Psi[out]> if M=0, while the rest is given from the first half up to a phase in |Psi[in]> and |Psi[out]>.
// Thus, Hamiltonian storage is divided by about two when TRS is used.
//
// Neither MPI nor OpenMP is used in this class, as parallelization is done an another level with MSDHF.
// It is done at level of the calculation of one-body scattering states, as they can be in large number, so that it is efficient for nodes to calculate them independently.
// Conversely, the space dimensions on one configuration are very small, so that a sequential calculation therein is efficient as well..
// Evidently, only full storage is used in this case, due to the very small dimensions involved.
// One calculates the number of non-zero NBMEs occurring in one node only as these values define array dimensions in the first place.
// MPI reduction is done afterwards when one calculates the proportion of non-zero NBMEs, which is defined in the full space.
//
// NBMEs_jumps_pp_nn_calc_store
// ----------------------------
// One considers only the proton or neutron 1p-1h or 2p-2h part (FULL_STORAGE_TBMES_INDICES only for 2p2-2h, see GSM_H_class.cpp), and one uses the notation mu for proton or neutron.
// This is for p -> p', n -> n', p1 p2 -> p1' p2' and n1 n2 -> n1' n2' only.
// The routine NBMEs_two_jumps_pp_nn_calc_store of GSM_H_class.cpp is used for FULL_STORAGE (see GSM_H_class.cpp).
// This provides with non-zero off-diagonal NBMEs for 1p-1h or 2p-2h jumps from a proton/neutron out Slater determinant to an in proton/neutron Slater determinant.
// Jumps have already been calculated at this level, so that one calculates the NBME without reordering phase, 
// which is multiplied afterwards by the reordering phase, calculated along with jumps data and stored in jumps data arrays.
//
// Hamiltonian_part_one_jump_pp_nn_store
// -------------------------------------
// This provides with non-zero off-diagonal NBMEs for 1p-1h jumps from a proton/neutron out Slater determinant to an in proton/neutron Slater determinant.
// This is for p -> p', n -> n' only.
// Jumps have already been calculated at this level, so that one just checks if the obtained configuration after the 1p-1h or 2p-2h jump is part of the model space,
// i.e. is accepted with used truncations. The index of the in Slater determinant and the associated NBME are then stored and added to Hamiltonian arrays.
//
// Hamiltonian_part_jumps_store
// ----------------------------
// This provides with non-zero off-diagonal NBMEs for 1p-1h and 2p-2h jumps from a proton/neutron out Slater determinant to an in proton/neutron Slater determinant.
// Jumps have already been calculated at this level, so that one just checks if the obtained configuration after the 1p-1h or 2p-2h jump is part of the model space,
// i.e. is accepted with used truncations. The index of the in Slater determinant and the associated NBME (or NBME index) are then stored and/or added to Hamiltonian arrays.
// 
// jumps_p_prot_part_pn_calc_store, jumps_n_neut_part_pn_calc_store
// ----------------------------------------------------------------
// This provides with non-zero off-diagonal NBMEs for 1p-1h or 2p-2h jumps from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// This is for p -> p', n -> n', p1 p2 -> p1' p2' and n1 n2 -> n1' n2' only, and these routines are used when one has both valence protons and neutrons.
// One considers pp and nn OBMEs and TBMEs only in these routines.
// In this routine, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the indices of the in Slater determinant and the associated NBME from them.
// If there is a TBMEs pn part, it will be added afterwards. In order to know where to add pm NBMEs in Hamiltonian arrays, 
// the one_jump_start_non_zero_NBMEs_indices array is stored, which provides with the NBME index related to the considered out Slater determinant.
//
// one_jump_p_pn_part_pn_calc_store, one_jump_n_pn_part_pn_calc_store
// ------------------------------------------------------------------
// This provides with non-zero off-diagonal NBMEs of 1p-1h type  from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// This is for p -> p', n -> n' only, and these routines are used when one has both valence protons and neutrons.
// One considers pn TBMEs only in these routines.
// In this routine, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the indices of the in Slater determinant and the associated NBME from them.
// This part of 1p-1h NBME has to added to the already calculated pp or nn NBME of the previous pp or nn routines.
// Hence, one has to know where to add NBMEs in Hamiltonian arrays.
// This is done with the one_jump_start_non_zero_NBMEs_indices array, which provides with the NBME index related to the considered out Slater determinant (see previous routines).
// In order to save time, one partially stored the pn NBME without phase, as it depends only on n and n' for a fixed proton SD (or p and p' for a fixed neutron SD).
// Hence, when one runs over neutrons SDs for a fixed proton SD (or over protons SDs for a fixed neutron SD), the same pn NBME can be reused several times.
// Only the reordering phase has to multiplied to it, and it has been calculated and stored in jumps arrays.
//
// two_jumps_pn_part_pn_calc_store
// -------------------------------
// This provides with non-zero off-diagonal NBMEs (or their indices, see GSM_H_class.cpp) for 2p-2h pn jumps from an out Slater determinant to an in Slater determinant.
// For this, one loop over parity and M quantum numbers of the in Slater determinant, and one calculates 1p-1h proton and neutron jumps using quantum number conservation,
// so that the pn 2p-2h jump can be generated from it. Once they are calculated, one loops over obtained proton and neutron in Slater determinants for a fixed out Slater determinant,
// and one calculates non-zero NBMEs if model space truncations are respected, i.e. if hw truncation energy and number of particles in the continuum are below their limit.
//
// jumps_part_pp_nn_calc_store
// ---------------------------
// This provides with the non-zero off-diagonal NBMEs for 1p-1h or 2p-2h jumps from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// This is for p -> p', n -> n', p1 p2 -> p1' p2' and n1 n2 -> n1' n2' only, and this routine is used when one has valence protons only or valence neutrons only.
// In this routine, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the number of non-zero NBMEs from them.
//
// matrix_off_diagonal_store
// -------------------------
// This routine calls the previous routine and calculates and stores non-zero NBMEs for each row of the Hamiltonian for each node.
// 
// apply_add_off_diagonal_full_storage
// -----------------------------------
// One applies here |Psi[out]> -> |Psi[out]> + (H + E.Id).|Psi[in]> using arrays previously stored.
// The diagonal part is not considered here, as it is taken into in apply_add (see GSM_H_class.cpp).

void H_one_configuration_class::NBMEs_jumps_pp_nn_calc_store (
							      const unsigned int BPmu , 
							      const unsigned int iCmu , 
							      const int iMmu , 
							      const unsigned int outSDmu_index , 
							      const class Slater_determinant &outSDmu , 
							      const class nucleons_data &data , 
							      bool &is_there_one_jump_calc , 
							      bool &is_there_two_jumps_calc , 
							      class jumps_data_out_to_in_str &one_jump_mu , 
							      class jumps_data_out_to_in_str &two_jumps_mu , 
							      class array<TYPE> &NBMEs_one_jump_mu , 
							      class array<TYPE> &NBMEs_two_jumps_mu) const
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const enum interaction_type inter = GSM_vector_helper.get_inter ();
   
  const int N_valence_nucleons = data.get_N_valence_nucleons ();
    
  const int E_max_hw = data.get_E_max_hw ();
  
  const int n_holes_max = data.get_n_holes_max ();

  const class TBMEs_class &TBMEs = data.get_TBMEs ();

  is_there_one_jump_calc  = false;
  is_there_two_jumps_calc = false;

  one_jump_mu.one_jump_mu_store (BPmu , iMmu , n_holes_max , 0 , E_max_hw ,  BPmu , 0 , iCmu , iMmu , outSDmu_index , data);

  const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();

  if (dimension_one_jump_mu > 0)
    { 
      for (unsigned int i = 0 ; i < dimension_one_jump_mu ; i++)
	{ 
	  const class jumps_data_inSD_str &one_jump_mu_inSD = one_jump_mu(i);

	  const unsigned int mu_in  = one_jump_mu_inSD.get_mu_in ();
	  const unsigned int mu_out = one_jump_mu_inSD.get_mu_out ();

	  const unsigned int total_bin_phase_mu = one_jump_mu_inSD.get_total_bin_phase ();

	  const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);
	      
	  const TYPE NBMEs_one_jump_mu_no_phase = H_NBMEs::no_pn_one_jump_mu_no_phase_calc (inter , true , true , mu_out , mu_in , outSDmu , data);

	  NBMEs_one_jump_mu(i) = (total_phase_mu == 1) ? (NBMEs_one_jump_mu_no_phase) : (-NBMEs_one_jump_mu_no_phase);
	}

      is_there_one_jump_calc = true;
    }

  if (N_valence_nucleons >= 2)
    {
      two_jumps_mu.two_jumps_mu_store (BPmu , iMmu , n_holes_max , 0 , E_max_hw , BPmu , 0 , iCmu , iMmu , outSDmu_index , data);

      const unsigned int dimension_two_jumps_mu = two_jumps_mu.get_dimension ();

      if (dimension_two_jumps_mu > 0)
	{  
	  for (unsigned int i = 0 ; i < dimension_two_jumps_mu ; i++)
	    { 
	      const class jumps_data_inSD_str &two_jumps_mu_inSD = two_jumps_mu(i);

	      const unsigned int mu_left_in  = two_jumps_mu_inSD.get_left_in ();
	      const unsigned int mu_left_out = two_jumps_mu_inSD.get_left_out ();
	      
	      const unsigned int mu_right_in  = two_jumps_mu_inSD.get_right_in ();
	      const unsigned int mu_right_out = two_jumps_mu_inSD.get_right_out ();

	      const unsigned int total_bin_phase_mu = two_jumps_mu_inSD.get_total_bin_phase ();

	      const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);
	      
	      const TYPE TBME_mu = TBMEs.M_TBME(mu_left_in , mu_right_in , mu_left_out , mu_right_out);

	      NBMEs_two_jumps_mu(i) = (total_phase_mu == 1) ? (TBME_mu) : (-TBME_mu);
	    }

	  is_there_two_jumps_calc = true;
	}
    }
}



void H_one_configuration_class::Hamiltonian_part_jumps_store (
							      const class jumps_data_out_to_in_str &jumps , 
							      const class array<unsigned int> &PSI_in_indices , 
							      const class array<TYPE> &NBMEs_jumps , 
							      const unsigned int PSI_out_index)
{  
  unsigned int &non_zero_NBMEs_index = rows_non_zero_NBMEs_numbers(PSI_out_index);
  
  const unsigned int dimension_jumps = jumps.get_dimension ();
      
  const unsigned int row_non_zero_NBMEs_PSI_in_indices_zero_index = rows_non_zero_NBMEs_PSI_in_indices.index_determine (PSI_out_index , 0);
	      
  const unsigned int row_non_zero_NBMEs_zero_index = rows_non_zero_NBMEs.index_determine (PSI_out_index , 0);
  
  for (unsigned int i = 0 ; i < dimension_jumps ; i++)
    {      
      const unsigned int row_non_zero_NBMEs_PSI_in_indices_index = row_non_zero_NBMEs_PSI_in_indices_zero_index + non_zero_NBMEs_index;

      const unsigned int row_non_zero_NBMEs_index = row_non_zero_NBMEs_zero_index + non_zero_NBMEs_index;
	  
      const unsigned int PSI_in_index = PSI_in_indices(i);

      const TYPE NBME = NBMEs_jumps(i);

      rows_non_zero_NBMEs_PSI_in_indices[row_non_zero_NBMEs_PSI_in_indices_index] = PSI_in_index;

      rows_non_zero_NBMEs[row_non_zero_NBMEs_index] += NBME;
      
      non_zero_NBMEs_index++;
    }
}




void H_one_configuration_class::jumps_p_prot_part_pn_calc_store (class array<unsigned int> &one_jump_start_non_zero_NBMEs_indices)
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  
  const int iM = GSM_vector_helper.get_iM ();

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const unsigned int BPp = prot_data.get_BP_one_configuration (); 
  const unsigned int BPn = neut_data.get_BP_one_configuration ();
  
  const unsigned int iCp = prot_data.get_iC_one_configuration (); 
  const unsigned int iCn = neut_data.get_iC_one_configuration ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array<unsigned int> &TRS_PSI_indices = GSM_vector_helper.get_TRS_PSI_indices (); 
  
  const unsigned int dimension_p_1p1h_space_BP_iM_fixed_max = prot_data.get_dimension_1p1h_space_BP_iM_fixed_max ();
  const unsigned int dimension_pp_2p2h_space_BP_iM_fixed_max = prot_data.get_dimension_2p2h_space_BP_iM_fixed_max ();
  
  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_data.get_SD_set (); 

  class jumps_data_out_to_in_str one_jump_p(ONE_JUMP_ONE_CONFIGURATION   , PROTONS_NEUTRONS , true , true , dimension_p_1p1h_space_BP_iM_fixed_max);
  class jumps_data_out_to_in_str two_jumps_p(TWO_JUMPS_ONE_CONFIGURATION , PROTONS_NEUTRONS , true , true , dimension_pp_2p2h_space_BP_iM_fixed_max);

  class array<TYPE> NBMEs_prot_one_jump_p(dimension_p_1p1h_space_BP_iM_fixed_max);

  class array<TYPE> NBMEs_two_jumps_p(dimension_pp_2p2h_space_BP_iM_fixed_max);

  class array<unsigned int> PSI_in_indices_one_jump_p(dimension_p_1p1h_space_BP_iM_fixed_max);
  class array<unsigned int> PSI_in_indices_two_jumps_p(dimension_pp_2p2h_space_BP_iM_fixed_max);

  class Slater_determinant outSDp(Zval);
      
  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
    {
      const int iMn = iM - iMp;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , 0 , iCp , iMp);
      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , 0 , iCn , iMn);

      if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

      for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_SDp ; outSDp_index++)
	{
	  outSDp = SDp_set(BPp , 0 , iCp , iMp , outSDp_index);

	  const unsigned int sum_dimensions_Mp_Mn_fixed = sum_dimensions(iMp);

	  bool is_there_one_jump_calc = false , is_there_two_jumps_calc = false;

	  NBMEs_jumps_pp_nn_calc_store (BPp , iCp , iMp , outSDp_index , outSDp , prot_data , is_there_one_jump_calc , is_there_two_jumps_calc ,
					one_jump_p , two_jumps_p , NBMEs_prot_one_jump_p , NBMEs_two_jumps_p);

	  if (!is_there_one_jump_calc && !is_there_two_jumps_calc) continue;

	  const unsigned int dimension_one_jump_p  = one_jump_p.get_dimension ();
	  const unsigned int dimension_two_jumps_p = two_jumps_p.get_dimension ();

	  const unsigned int PSI_out_zero_index_outSDp = sum_dimensions_Mp_Mn_fixed + dimension_SDn*outSDp_index;
		  
	  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
	    {
	      const unsigned int PSI_out_index = PSI_out_zero_index_outSDp + SDn_index;

	      if (!is_it_TRS || (TRS_PSI_indices(PSI_out_index) >= PSI_out_index))
		{
		  const unsigned int PSI_in_zero_index_SDn = sum_dimensions_Mp_Mn_fixed + SDn_index;
			  
		  if (is_there_one_jump_calc)
		    {
		      one_jump_start_non_zero_NBMEs_indices(PSI_out_index) = rows_non_zero_NBMEs_numbers(PSI_out_index);
			  
		      for (unsigned int i = 0 ; i < dimension_one_jump_p ; i++)
			{
			  const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(i);
			  
			  const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

			  PSI_in_indices_one_jump_p(i) = PSI_in_zero_index_SDn + dimension_SDn*inSDp_index;
			}

		      Hamiltonian_part_jumps_store (one_jump_p , PSI_in_indices_one_jump_p , NBMEs_prot_one_jump_p , PSI_out_index);
		    }

		  if (is_there_two_jumps_calc)
		    {
		      for (unsigned int i = 0 ; i < dimension_two_jumps_p ; i++)
			{
			  const class jumps_data_inSD_str &two_jumps_p_inSDp = two_jumps_p(i);
			  
			  const unsigned int inSDp_index = two_jumps_p_inSDp.get_inSD_index ();

			  PSI_in_indices_two_jumps_p(i) = PSI_in_zero_index_SDn + dimension_SDn*inSDp_index;
			}

		      Hamiltonian_part_jumps_store (two_jumps_p , PSI_in_indices_two_jumps_p , NBMEs_two_jumps_p , PSI_out_index);
		    }
		}
	    }
	}
    }
}




void H_one_configuration_class::jumps_n_neut_part_pn_calc_store (class array<unsigned int> &one_jump_start_non_zero_NBMEs_indices)
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M ();
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();
  
  const unsigned int BPp = prot_data.get_BP_one_configuration ();
  const unsigned int BPn = neut_data.get_BP_one_configuration ();
  
  const unsigned int iCp = prot_data.get_iC_one_configuration (); 
  const unsigned int iCn = neut_data.get_iC_one_configuration ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array<unsigned int> &TRS_PSI_indices = GSM_vector_helper.get_TRS_PSI_indices ();
    
  const unsigned int dimension_n_1p1h_space_BP_iM_fixed_max  = neut_data.get_dimension_1p1h_space_BP_iM_fixed_max ();
  const unsigned int dimension_nn_2p2h_space_BP_iM_fixed_max = neut_data.get_dimension_2p2h_space_BP_iM_fixed_max ();
  
  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDn_set = neut_data.get_SD_set (); 

  class jumps_data_out_to_in_str one_jump_n(ONE_JUMP_ONE_CONFIGURATION   , PROTONS_NEUTRONS , true , true , dimension_n_1p1h_space_BP_iM_fixed_max);
  class jumps_data_out_to_in_str two_jumps_n(TWO_JUMPS_ONE_CONFIGURATION , PROTONS_NEUTRONS , true , true , dimension_nn_2p2h_space_BP_iM_fixed_max);

  class array<TYPE> NBMEs_neut_one_jump_n(dimension_n_1p1h_space_BP_iM_fixed_max);

  class array<TYPE> NBMEs_two_jumps_n(dimension_nn_2p2h_space_BP_iM_fixed_max);
  
  class array<unsigned int> PSI_in_indices_one_jump_n(dimension_n_1p1h_space_BP_iM_fixed_max);
  class array<unsigned int> PSI_in_indices_two_jumps_n(dimension_nn_2p2h_space_BP_iM_fixed_max);
  
  class Slater_determinant outSDn(Nval);
  
  for (int iMn = iMn_min_M ; iMn <= iMn_max_M ; iMn++)
    {
      const int iMp = iM - iMn;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , 0 , iCp , iMp);
      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , 0 , iCn , iMn);
      
      if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

      for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_SDn ; outSDn_index++)
	{
	  outSDn = SDn_set(BPn , 0 , iCn , iMn , outSDn_index);

	  const unsigned int sum_dimensions_Mp_Mn_fixed = sum_dimensions(iMp);

	  bool is_there_one_jump_calc = false;
	  bool is_there_two_jumps_calc = false;

	  NBMEs_jumps_pp_nn_calc_store (BPn , iCn , iMn , outSDn_index , outSDn , neut_data , is_there_one_jump_calc , is_there_two_jumps_calc ,
					one_jump_n , two_jumps_n , NBMEs_neut_one_jump_n , NBMEs_two_jumps_n);

	  if (!is_there_one_jump_calc && !is_there_two_jumps_calc) continue;

	  const unsigned int dimension_one_jump_n  = one_jump_n.get_dimension ();
	  const unsigned int dimension_two_jumps_n = two_jumps_n.get_dimension ();

	  const unsigned int PSI_out_zero_index_outSDn = sum_dimensions_Mp_Mn_fixed + outSDn_index;
		  
	  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
	    {
	      const unsigned int PSI_out_index = PSI_out_zero_index_outSDn + dimension_SDn*SDp_index;

	      if (!is_it_TRS || (TRS_PSI_indices(PSI_out_index) >= PSI_out_index))
		{
		  const unsigned int PSI_in_zero_index_SDp = sum_dimensions_Mp_Mn_fixed + dimension_SDn*SDp_index;
	      
		  if (is_there_one_jump_calc)
		    {
		      one_jump_start_non_zero_NBMEs_indices(PSI_out_index) = rows_non_zero_NBMEs_numbers(PSI_out_index);

		      for (unsigned int i = 0 ; i < dimension_one_jump_n ; i++)
			{
			  const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(i);

			  const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

			  PSI_in_indices_one_jump_n(i) = PSI_in_zero_index_SDp + inSDn_index;
			}

		      Hamiltonian_part_jumps_store (one_jump_n , PSI_in_indices_one_jump_n , NBMEs_neut_one_jump_n , PSI_out_index);
		    }

		  if (is_there_two_jumps_calc)
		    {
		      for (unsigned int i = 0 ; i < dimension_two_jumps_n ; i++)
			{
			  const class jumps_data_inSD_str &two_jumps_n_inSDn = two_jumps_n(i);

			  const unsigned int inSDn_index = two_jumps_n_inSDn.get_inSD_index ();

			  PSI_in_indices_two_jumps_n(i) = PSI_in_zero_index_SDp + inSDn_index;
			}

		      Hamiltonian_part_jumps_store (two_jumps_n , PSI_in_indices_two_jumps_n , NBMEs_two_jumps_n , PSI_out_index);
		    }
		}
	    }
	}
    }
}




void H_one_configuration_class::one_jump_p_pn_part_pn_calc_store (const class array<unsigned int> &one_jump_start_non_zero_NBMEs_indices)
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn ();
  
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
    
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 

  const int iM = GSM_vector_helper.get_iM ();
  
  const unsigned int BPp = prot_data.get_BP_one_configuration (); 
  const unsigned int iCp = prot_data.get_iC_one_configuration ();
  
  const unsigned int BPn = neut_data.get_BP_one_configuration (); 
  const unsigned int iCn = neut_data.get_iC_one_configuration ();

  const int np_holes_max = prot_data.get_n_holes_max ();
  
  const int Ep_max_hw = prot_data.get_E_max_hw ();

  const unsigned int Np_nljm = prot_data.get_N_nljm ();
  
  const unsigned int dimension_p_1p1h_space_BP_iM_fixed_max = prot_data.get_dimension_1p1h_space_BP_iM_fixed_max ();   

  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();

  class jumps_data_out_to_in_str one_jump_p(ONE_JUMP_ONE_CONFIGURATION , PROTONS_NEUTRONS , true , true , dimension_p_1p1h_space_BP_iM_fixed_max);

  class array<TYPE> NBMEs_pn_one_jump_p_no_phase(Np_nljm , Np_nljm);

  class array<bool> NBMEs_pn_one_jump_p_no_phase_calculated(Np_nljm , Np_nljm);

  class Slater_determinant SDn(Nval);
  
  for (int iMn = iMn_min_M ; iMn <= iMn_max_M ; iMn++)
    {
      const int iMp = iM - iMn;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , 0 , iCp , iMp);
      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , 0 , iCn , iMn);

      if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

      const unsigned int sum_dimensions_Mp_Mn_fixed = sum_dimensions(iMp);

      for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
	{
	  SDn = SDn_set(BPn , 0 , iCn , iMn , SDn_index);

	  NBMEs_pn_one_jump_p_no_phase = 0.0;
	  
	  NBMEs_pn_one_jump_p_no_phase_calculated = false;

	  const unsigned int PSI_zero_index_SDn = sum_dimensions_Mp_Mn_fixed + SDn_index;
	      
	  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_SDp ; outSDp_index++)
	    {
	      const unsigned int PSI_out_index = PSI_zero_index_SDn + dimension_SDn*outSDp_index;
      
	      one_jump_p.one_jump_mu_store (BPp , iMp , np_holes_max , 0 , Ep_max_hw , BPp , 0 , iCp , iMp , outSDp_index , prot_data);

	      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();

	      const unsigned int row_non_zero_NBMEs_PSI_in_indices_zero_index = rows_non_zero_NBMEs_PSI_in_indices.index_determine (PSI_out_index , 0);
	      
	      const unsigned int row_non_zero_NBMEs_zero_index = rows_non_zero_NBMEs.index_determine (PSI_out_index , 0);
  
	      unsigned int non_zero_NBMEs_index = one_jump_start_non_zero_NBMEs_indices(PSI_out_index);
	  		  
	      for (unsigned int i = 0 ; i < dimension_one_jump_p ; i++)
		{
		  const unsigned int row_non_zero_NBMEs_PSI_in_indices_index = row_non_zero_NBMEs_PSI_in_indices_zero_index + non_zero_NBMEs_index;

		  const unsigned int row_non_zero_NBMEs_index = row_non_zero_NBMEs_zero_index + non_zero_NBMEs_index;
	  
		  const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(i);

		  const unsigned int p_in  = one_jump_p_inSDp.get_mu_in ();
		  const unsigned int p_out = one_jump_p_inSDp.get_mu_out ();
		  
		  const unsigned int total_bin_phase_p = one_jump_p_inSDp.get_total_bin_phase ();
		  
		  const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

		  const unsigned int PSI_in_index = PSI_zero_index_SDn + dimension_SDn*inSDp_index;

		  const int total_phase_p = parity_from_binary_parity (total_bin_phase_p);
		  
		  const bool NBME_pn_one_jump_p_no_phase_calculated = NBMEs_pn_one_jump_p_no_phase_calculated(p_in , p_out);

		  if (rows_non_zero_NBMEs_PSI_in_indices[row_non_zero_NBMEs_PSI_in_indices_index] != PSI_in_index)
		    error_message_print_abort ("Problem with PSI_in_index in H_one_configuration_class::one_jump_p_pn_part_calc_store");

		  if (!NBME_pn_one_jump_p_no_phase_calculated)
		    { 
		      const TYPE NBME_pn_one_jump_p_no_phase = H_NBMEs::pn_no_phase_one_jump_p_calc (p_in , p_out , SDn , TBMEs_pn);

		      NBMEs_pn_one_jump_p_no_phase(p_in , p_out) = NBMEs_pn_one_jump_p_no_phase(p_out , p_in) = NBME_pn_one_jump_p_no_phase;
		      NBMEs_pn_one_jump_p_no_phase_calculated(p_in , p_out) = NBMEs_pn_one_jump_p_no_phase_calculated(p_out , p_in) = true;

		      (total_phase_p == 1)
			? (rows_non_zero_NBMEs[row_non_zero_NBMEs_index] += NBME_pn_one_jump_p_no_phase)
			: (rows_non_zero_NBMEs[row_non_zero_NBMEs_index] -= NBME_pn_one_jump_p_no_phase);
		    }
		  else
		    {
		      const TYPE NBME_pn_one_jump_p_no_phase = NBMEs_pn_one_jump_p_no_phase(p_in , p_out);

		      (total_phase_p == 1)
			? (rows_non_zero_NBMEs[row_non_zero_NBMEs_index] += NBME_pn_one_jump_p_no_phase)
			: (rows_non_zero_NBMEs[row_non_zero_NBMEs_index] -= NBME_pn_one_jump_p_no_phase);
		    }
		  
		  non_zero_NBMEs_index++;
		}
	    }
	}
    }
}




void H_one_configuration_class::one_jump_n_pn_part_pn_calc_store (const class array<unsigned int> &one_jump_start_non_zero_NBMEs_indices)
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn (); 

  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const unsigned int BPp = prot_data.get_BP_one_configuration (); 
  const unsigned int BPn = neut_data.get_BP_one_configuration ();
  
  const unsigned int iCp = prot_data.get_iC_one_configuration (); 
  const unsigned int iCn = neut_data.get_iC_one_configuration ();
  
  const int nn_holes_max = neut_data.get_n_holes_max ();
  
  const int En_max_hw = neut_data.get_E_max_hw ();
    
  const unsigned int Nn_nljm = neut_data.get_N_nljm ();
  
  const unsigned int dimension_n_1p1h_space_BP_iM_fixed_max = neut_data.get_dimension_1p1h_space_BP_iM_fixed_max ();
  
  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_data.get_SD_set ();

  class jumps_data_out_to_in_str one_jump_n(ONE_JUMP_ONE_CONFIGURATION , PROTONS_NEUTRONS , true , true , dimension_n_1p1h_space_BP_iM_fixed_max);

  class array<TYPE> NBMEs_pn_one_jump_n_no_phase(Nn_nljm , Nn_nljm);
  
  class array<bool> NBMEs_pn_one_jump_n_no_phase_calculated(Nn_nljm , Nn_nljm);

  class Slater_determinant SDp(Zval);
	
  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
    {
      const int iMn = iM - iMp;
      
      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , 0 , iCp , iMp);
      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , 0 , iCn , iMn);
      
      if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

      const unsigned int sum_dimensions_Mp_Mn_fixed = sum_dimensions(iMp);

      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
	{
	  SDp = SDp_set(BPp , 0 , iCp , iMp , SDp_index);

	  NBMEs_pn_one_jump_n_no_phase = 0.0;
	  NBMEs_pn_one_jump_n_no_phase_calculated = false;

	  const unsigned int PSI_zero_index_SDp = sum_dimensions_Mp_Mn_fixed + dimension_SDn*SDp_index;
	      
	  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_SDn ; outSDn_index++)
	    {
	      const unsigned int PSI_out_index = PSI_zero_index_SDp + outSDn_index;
	      
	      one_jump_n.one_jump_mu_store (BPn , iMn , nn_holes_max , 0 , En_max_hw , BPn , 0 , iCn , iMn , outSDn_index , neut_data);

	      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

	      const unsigned int row_non_zero_NBMEs_PSI_in_indices_zero_index = rows_non_zero_NBMEs_PSI_in_indices.index_determine (PSI_out_index , 0);
	      
	      const unsigned int row_non_zero_NBMEs_zero_index = rows_non_zero_NBMEs.index_determine (PSI_out_index , 0);
	      
	      unsigned int non_zero_NBMEs_index = one_jump_start_non_zero_NBMEs_indices(PSI_out_index);
	      
	      for (unsigned int i = 0 ; i < dimension_one_jump_n ; i++)
		{
		  const unsigned int row_non_zero_NBMEs_PSI_in_indices_index = row_non_zero_NBMEs_PSI_in_indices_zero_index + non_zero_NBMEs_index;

		  const unsigned int row_non_zero_NBMEs_index = row_non_zero_NBMEs_zero_index + non_zero_NBMEs_index;
      
		  const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(i);

		  const unsigned int n_in  = one_jump_n_inSDn.get_mu_in ();
		  const unsigned int n_out = one_jump_n_inSDn.get_mu_out ();

		  const unsigned int total_bin_phase_n = one_jump_n_inSDn.get_total_bin_phase ();
		  
		  const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();
		  
		  const unsigned int PSI_in_index = PSI_zero_index_SDp + inSDn_index;

		  const int total_phase_n = parity_from_binary_parity (total_bin_phase_n);
		  
		  const bool NBME_pn_one_jump_n_no_phase_calculated = NBMEs_pn_one_jump_n_no_phase_calculated(n_in , n_out);

		  if (rows_non_zero_NBMEs_PSI_in_indices[row_non_zero_NBMEs_PSI_in_indices_index] != PSI_in_index)
		    error_message_print_abort ("Problem with PSI_in_index in H_one_configuration_class::one_jump_n_pn_part_calc_store");

		  if (!NBME_pn_one_jump_n_no_phase_calculated)
		    { 
		      const TYPE NBME_pn_one_jump_n_no_phase = H_NBMEs::pn_no_phase_one_jump_n_calc (n_in , n_out , SDp , TBMEs_pn);

		      NBMEs_pn_one_jump_n_no_phase(n_in , n_out) = NBMEs_pn_one_jump_n_no_phase(n_out , n_in) = NBME_pn_one_jump_n_no_phase;

		      NBMEs_pn_one_jump_n_no_phase_calculated(n_in , n_out) = NBMEs_pn_one_jump_n_no_phase_calculated(n_out , n_in) = true;

		      (total_phase_n == 1)
			? (rows_non_zero_NBMEs[row_non_zero_NBMEs_index] += NBME_pn_one_jump_n_no_phase)
			: (rows_non_zero_NBMEs[row_non_zero_NBMEs_index] -= NBME_pn_one_jump_n_no_phase);
		    }
		  else
		    {
		      const TYPE NBME_pn_one_jump_n_no_phase = NBMEs_pn_one_jump_n_no_phase(n_in , n_out);

		      (total_phase_n == 1)
			? (rows_non_zero_NBMEs[row_non_zero_NBMEs_index] += NBME_pn_one_jump_n_no_phase)
			: (rows_non_zero_NBMEs[row_non_zero_NBMEs_index] -= NBME_pn_one_jump_n_no_phase);
		    }
		  
		  non_zero_NBMEs_index++;
		}
	    }
	}
    }
}







void H_one_configuration_class::two_jumps_pn_part_pn_calc_store ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn (); 

  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
    
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 

  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();
  
  const int iMp_max_M_plus_one = iMp_max_M + 1;
  const int iMn_max_M_plus_one = iMn_max_M + 1;
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array<unsigned int> &TRS_PSI_indices = GSM_vector_helper.get_TRS_PSI_indices (); 
  
  const unsigned int BPp = prot_data.get_BP_one_configuration ();
  const unsigned int BPn = neut_data.get_BP_one_configuration ();
  
  const unsigned int iCp = prot_data.get_iC_one_configuration ();  
  const unsigned int iCn = neut_data.get_iC_one_configuration ();

  const int np_holes_max = prot_data.get_n_holes_max ();
  const int nn_holes_max = neut_data.get_n_holes_max ();
  
  const int Ep_max_hw = prot_data.get_E_max_hw ();
  const int En_max_hw = neut_data.get_E_max_hw ();
  
  const int two_mp_max = prot_data.get_two_m_max ();
  const int two_mn_max = neut_data.get_two_m_max ();
  
  const int four_mp_max = prot_data.get_four_m_max ();
  const int four_mn_max = neut_data.get_four_m_max ();
  
  const int mp_max_minus_mp_min = prot_data.get_m_max_minus_m_min ();

  const unsigned int dimension_p_1p1h_space_BP_iM_fixed_max = prot_data.get_dimension_1p1h_space_BP_iM_fixed_max (); 
  const unsigned int dimension_n_1p1h_space_BP_iM_fixed_max = neut_data.get_dimension_1p1h_space_BP_iM_fixed_max ();
  
  const unsigned int dimension_SDp_max = prot_data.get_dimension_SD_max ();
  const unsigned int dimension_SDn_max = neut_data.get_dimension_SD_max ();
  
  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  class array<class jumps_data_out_to_in_str> one_jump_p_tab(iMp_max_M_plus_one , dimension_SDp_max);
  class array<class jumps_data_out_to_in_str> one_jump_n_tab(iMn_max_M_plus_one , dimension_SDn_max);
      
  class array<bool> one_jump_p_calculated_tab(iMp_max_M_plus_one , dimension_SDp_max);
  class array<bool> one_jump_n_calculated_tab(iMn_max_M_plus_one , dimension_SDn_max);
      
  for (int iMp_out = iMp_min_M ; iMp_out <= iMp_max_M ; iMp_out++)
    {
      const int iMn_out = iM - iMp_out;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , 0 , iCp , iMp_out);
      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , 0 , iCn , iMn_out);

      if ((dimension_outSDp == 0) || (dimension_outSDn == 0)) continue;

      one_jump_p_calculated_tab = false;
      one_jump_n_calculated_tab = false;

      const int iMp_in_min_M = max(iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min(iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int sum_dimensions_Mp_Mn_fixed_out = sum_dimensions(iMp_out);

      for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
	{
	  const unsigned int PSI_out_index_zero_outSDp_fixed = sum_dimensions_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;

	  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
	    {
	      const unsigned int PSI_out_index = PSI_out_index_zero_outSDp_fixed + outSDn_index;

	      if (!is_it_TRS || (TRS_PSI_indices(PSI_out_index) >= PSI_out_index))
		{ 		  
		  const unsigned int row_non_zero_NBMEs_PSI_in_indices_zero_index = rows_non_zero_NBMEs_PSI_in_indices.index_determine (PSI_out_index , 0);
	      
		  const unsigned int row_non_zero_NBMEs_zero_index = rows_non_zero_NBMEs.index_determine (PSI_out_index , 0);
  
		  for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
		    {
		      const int iMn_in = iM - iMp_in;
		      
		      const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
		      const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
		      
		      if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
		      if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;

		      bool &one_jump_p_calculated = one_jump_p_calculated_tab(iMp_in , outSDp_index);
		      bool &one_jump_n_calculated = one_jump_n_calculated_tab(iMn_in , outSDn_index);

		      class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(iMp_in , outSDp_index);
		      class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(iMn_in , outSDn_index);

		      if (!one_jump_p_calculated)
			{
			  if (!one_jump_p.is_it_filled ()) one_jump_p.allocate (ONE_JUMP_ONE_CONFIGURATION , PROTONS_NEUTRONS , true , true , dimension_p_1p1h_space_BP_iM_fixed_max);

			  one_jump_p.one_jump_mu_store (BPp , iMp_in , np_holes_max , 0 , Ep_max_hw , BPp , 0 , iCp , iMp_out , outSDp_index , prot_data);

			  one_jump_p_calculated = true;
			}

		      if (!one_jump_n_calculated)
			{
			  if (!one_jump_n.is_it_filled ()) one_jump_n.allocate (ONE_JUMP_ONE_CONFIGURATION , PROTONS_NEUTRONS , true , true , dimension_n_1p1h_space_BP_iM_fixed_max);

			  one_jump_n.one_jump_mu_store (BPn , iMn_in , nn_holes_max , 0 , En_max_hw , BPn , 0 , iCn , iMn_out , outSDn_index , neut_data); 

			  one_jump_n_calculated = true;									 
			}

		      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
		      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
		      
		      if ((dimension_one_jump_p == 0) || (dimension_one_jump_n == 0)) continue;

		      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn , 0 , iCn , iMn_in);

		      const unsigned int sum_dimensions_Mp_Mn_fixed_in = sum_dimensions(iMp_in);

		      for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
			{
			  const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);

			  const unsigned int p_in  = one_jump_p_inSDp.get_mu_in ();
			  const unsigned int p_out = one_jump_p_inSDp.get_mu_out ();
			  
			  const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();
			  
			  const unsigned int total_bin_phase_p = one_jump_p_inSDp.get_total_bin_phase ();

			  const unsigned int PSI_in_zero_index_inSDp = sum_dimensions_Mp_Mn_fixed_in + dimension_inSDn*inSDp_index;
			      
			  for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)  
			    {
			      const unsigned int non_zero_NBMEs_index = rows_non_zero_NBMEs_numbers(PSI_out_index)++;
		  
			      const unsigned int row_non_zero_NBMEs_PSI_in_indices_index = row_non_zero_NBMEs_PSI_in_indices_zero_index + non_zero_NBMEs_index;
      
			      const unsigned int row_non_zero_NBMEs_index = row_non_zero_NBMEs_zero_index + non_zero_NBMEs_index;
      
			      const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);

			      const unsigned int n_in  = one_jump_n_inSDn.get_mu_in ();
			      const unsigned int n_out = one_jump_n_inSDn.get_mu_out ();

			      const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();
			      
			      const unsigned int total_bin_phase_n = one_jump_n_inSDn.get_total_bin_phase ();

			      const unsigned int PSI_in_index = PSI_in_zero_index_inSDp + inSDn_index;

			      const TYPE TBME = TBMEs_pn.M_TBME(p_in , n_in , p_out , n_out);

			      const TYPE NBME = (total_bin_phase_p == total_bin_phase_n) ? (TBME) : (-TBME);

			      rows_non_zero_NBMEs_PSI_in_indices[row_non_zero_NBMEs_PSI_in_indices_index] = PSI_in_index;

			      rows_non_zero_NBMEs[row_non_zero_NBMEs_index] += NBME;
			    }}}}}}}
}








void H_one_configuration_class::jumps_part_pp_nn_calc_store ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array<unsigned int> &TRS_PSI_indices = GSM_vector_helper.get_TRS_PSI_indices (); 
  
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);
  
  const int N_valence_nucleons = data.get_N_valence_nucleons ();
  
  const unsigned int BP = data.get_BP_one_configuration ();
  const unsigned int iC = data.get_iC_one_configuration ();
  
  const unsigned int dimension_1p1h_space_BP_iM_fixed_max = data.get_dimension_1p1h_space_BP_iM_fixed_max ();
  const unsigned int dimension_2p2h_space_BP_iM_fixed_max = data.get_dimension_2p2h_space_BP_iM_fixed_max ();
    
  const class array_BP_Nscat_iC<unsigned int> &dimensions_outSD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const unsigned int dimension_outSD_set = dimensions_outSD_set(BP , 0 , iC , iM);

  class jumps_data_out_to_in_str one_jump_mu(ONE_JUMP_ONE_CONFIGURATION   , space , true , true , dimension_1p1h_space_BP_iM_fixed_max);
  class jumps_data_out_to_in_str two_jumps_mu(TWO_JUMPS_ONE_CONFIGURATION , space , true , true , dimension_2p2h_space_BP_iM_fixed_max);
  
  class array<TYPE> NBMEs_one_jump_mu(dimension_1p1h_space_BP_iM_fixed_max);
  class array<TYPE> NBMEs_two_jumps_mu(dimension_2p2h_space_BP_iM_fixed_max);
  
  class array<unsigned int> PSI_in_indices_one_jump_mu(dimension_1p1h_space_BP_iM_fixed_max);
  class array<unsigned int> PSI_in_indices_two_jumps_mu(dimension_2p2h_space_BP_iM_fixed_max);

  class Slater_determinant outSD(N_valence_nucleons);
  
  for (unsigned int outSD_index = 0 ; outSD_index < dimension_outSD_set ; outSD_index++)
    {
      if (!is_it_TRS || (TRS_PSI_indices(outSD_index) >= outSD_index))
	{
	  outSD = SD_set(BP , 0 , iC , iM , outSD_index);

	  bool is_there_one_jump_calc = false;
	  bool is_there_two_jumps_calc = false;

	  NBMEs_jumps_pp_nn_calc_store (BP , iC , iM , outSD_index , outSD , data , is_there_one_jump_calc , is_there_two_jumps_calc ,
					one_jump_mu , two_jumps_mu , NBMEs_one_jump_mu , NBMEs_two_jumps_mu);

	  const unsigned int dimension_one_jump_mu  = one_jump_mu.get_dimension ();
	  const unsigned int dimension_two_jumps_mu = two_jumps_mu.get_dimension ();

	  if (is_there_one_jump_calc)
	    {
	      for (unsigned int i = 0 ; i < dimension_one_jump_mu ; i++)
		{
		  const class jumps_data_inSD_str &one_jump_mu_inSD = one_jump_mu(i);
		  
		  const unsigned int inSD_index = one_jump_mu_inSD.get_inSD_index ();

		  PSI_in_indices_one_jump_mu(i) = inSD_index;
		}

	      Hamiltonian_part_jumps_store (one_jump_mu , PSI_in_indices_one_jump_mu , NBMEs_one_jump_mu , outSD_index);
	    }

	  if (is_there_two_jumps_calc)
	    {
	      for (unsigned int i = 0 ; i < dimension_two_jumps_mu ; i++)
		{
		  const class jumps_data_inSD_str &two_jumps_mu_inSD = two_jumps_mu(i);

		  const unsigned int inSD_index = two_jumps_mu_inSD.get_inSD_index ();

		  PSI_in_indices_two_jumps_mu(i) = inSD_index;
		}

	      Hamiltonian_part_jumps_store (two_jumps_mu , PSI_in_indices_two_jumps_mu , NBMEs_two_jumps_mu , outSD_index);
	    }
	}
    }
}




void H_one_configuration_class::matrix_off_diagonal_store ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();
  
  const unsigned int space_dimension = GSM_vector_helper.get_space_dimension ();
  
  rows_non_zero_NBMEs_numbers = 0;
  
  for (unsigned int PSI_index = 0 ; PSI_index < space_dimension ; PSI_index++) 
    {
      const unsigned int rows_non_zero_NBMEs_number = rows_non_zero_NBMEs_numbers(PSI_index);
	  
      const unsigned int row_non_zero_NBMEs_PSI_in_indices_zero_index = rows_non_zero_NBMEs_PSI_in_indices.index_determine (PSI_index , 0);
	      
      const unsigned int row_non_zero_NBMEs_zero_index = rows_non_zero_NBMEs.index_determine (PSI_index , 0);
      
      for (unsigned int i = 0 ; i < rows_non_zero_NBMEs_number ; i++)
	{
	  const unsigned int row_non_zero_NBMEs_PSI_in_indices_index = row_non_zero_NBMEs_PSI_in_indices_zero_index + i;

	  const unsigned int row_non_zero_NBMEs_index = row_non_zero_NBMEs_zero_index + i;
      
	  rows_non_zero_NBMEs_PSI_in_indices[row_non_zero_NBMEs_PSI_in_indices_index] = space_dimension;

	  rows_non_zero_NBMEs[row_non_zero_NBMEs_index] = 0.0;
	}
    }

  if (space == PROTONS_NEUTRONS)
    {
      class array<unsigned int> one_jump_start_non_zero_NBMEs_indices(space_dimension);
      
      one_jump_start_non_zero_NBMEs_indices = space_dimension;

      jumps_p_prot_part_pn_calc_store (one_jump_start_non_zero_NBMEs_indices);

      one_jump_p_pn_part_pn_calc_store (one_jump_start_non_zero_NBMEs_indices);

      one_jump_start_non_zero_NBMEs_indices = space_dimension;

      jumps_n_neut_part_pn_calc_store (one_jump_start_non_zero_NBMEs_indices);

      one_jump_n_pn_part_pn_calc_store (one_jump_start_non_zero_NBMEs_indices);

      two_jumps_pn_part_pn_calc_store ();
    }
  else
    jumps_part_pp_nn_calc_store ();
}






void H_one_configuration_class::apply_add_off_diagonal_full_storage (
								     const class GSM_vector_one_configuration &PSI_in , 
								     class GSM_vector_one_configuration &PSI_out) const
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const unsigned int space_dimension = GSM_vector_helper.get_space_dimension ();
  
  for (unsigned int PSI_out_index = 0 ; PSI_out_index < space_dimension ; PSI_out_index++)
    {
      const unsigned int row_non_zero_NBMEs_number = rows_non_zero_NBMEs_numbers(PSI_out_index);

      const unsigned int row_non_zero_NBMEs_PSI_in_indices_zero_index = rows_non_zero_NBMEs_PSI_in_indices.index_determine (PSI_out_index , 0);
      
      const unsigned int row_non_zero_NBMEs_zero_index = rows_non_zero_NBMEs.index_determine (PSI_out_index , 0);
      
      TYPE PSI_out_component = 0.0;

      for (unsigned int i = 0 ; i < row_non_zero_NBMEs_number ; i++)
	{
	  const unsigned int row_non_zero_NBMEs_PSI_in_indices_index = row_non_zero_NBMEs_PSI_in_indices_zero_index + i;

	  const unsigned int row_non_zero_NBMEs_index = row_non_zero_NBMEs_zero_index + i;
	  
	  const unsigned int PSI_in_index = rows_non_zero_NBMEs_PSI_in_indices[row_non_zero_NBMEs_PSI_in_indices_index];

	  const TYPE &PSI_in_component = PSI_in[PSI_in_index];
	    
	  const TYPE &NBME = rows_non_zero_NBMEs[row_non_zero_NBMEs_index];

	  PSI_out_component += NBME*PSI_in_component;
	}

      PSI_out[PSI_out_index] += PSI_out_component;
    }
}

