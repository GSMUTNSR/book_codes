#include "../GSM_include/GSM_include_def.h"

using namespace GSM_vector_NBMEs_handling;
using namespace GSM_vector_dimensions;
using namespace CM_OBMEs_TBMEs;


// TYPE is double or complex
// -------------------------



// CM means center of mass
// -----------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons
// ------------------------------------------------------------------------------------------------------------------------------------------------------










// Calculation and storage of the diagonal matrix elements of the CM operator
// --------------------------------------------------------------------------
// One calculates here the diagonal matrix elements of the CM operator, of the form <SD | CM-Op | SD>. 
// They are calculated only for symmetric operators, as otherwise they do not exist.
// <SD | CM-Op | SD> = \sum_i <i | CM-op(1) |i> + \sum_(i<j) <ij | CM-op(2) |ij>, with CM-op(1) and CM-op(2) the one-body and two-body parts of the CM operator.
// One always checks if <ij | CM-op(2) |ij> is not a trivial zero before calculating it (see GSM_operator_class_OBMEs_TBMEs.cpp), which often happens as two-body operators are tensor products involving r and p.
// One separates the pp and nn parts of <SD | CM-Op | SD> in the proton-neutron case.
// There is no pn part in  <SD | CM-Op | SD>, as a tensor products of the form <ab | ri x rj | ab>, <ab | pi x pj | ab>, <ab | ri x pj | ab> are equal to zero, as r and p do not conserve parity. 
// One loops over proton or neutron Slater determinants, and one calculates and stores <SDp | CM-Op | SDp> and <SDn | CM-Op | SDn> NBMEs in member arrays.
//
// OpenMP parallelization is used on the loop of proton or neutron Slater determinants.
// MPI parallelization here is only implicit, as on considers only the Slater determinants of the current node.
//
//
// Application of the diagonal part of the CM operator to |Psi[in]> to obtain a part of |Psi[out>
// ----------------------------------------------------------------------------------------------
// One has |Psi[out]> -> |Psi[out]> + CM_operator.|Psi[in]>.
// One considers here the diagonal part of the CM operator, so that one calculates \sum <SD | CM-Op | SD> <SD|Psi[in]>, which is added to |Psi[out]>. 
// For the proton-neutron case, one routine is used if NYval >= ZYval, and another if not, as SD indices are calculated differently in each case to optimize their use (see GSM_vector_dimensions.cpp).
// Time-reversal symmetry (TRS) is used if both |Psi[in]> and CM-op |Psi[in]> states have M=0.
//
// When one writes total_PSI_index, total means that one considers the index of the SD of the full GSM vector, not of part of it in a node (see GSM_vector_helper.cpp).


void CM_operator_class::NBMEs_p_diagonal_all_SDs_calc_pn (const class baryons_data &prot_Y_data)
{
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();

  const int n_holes_max_p = GSM_vector_helper_out.get_n_holes_max_p ();
  
  const int n_scat_max_p = GSM_vector_helper_out.get_n_scat_max_p ();

  const int Ep_max_hw = GSM_vector_helper_out.get_Ep_max_hw ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();  

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper_out.get_all_dimensions_SDn_zero_tab ();
  
  const int iMp_min_M = GSM_vector_helper_out.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper_out.get_iMp_max_M ();

  const unsigned long int total_SDp_index_min = GSM_vector_helper_out.get_total_SDp_index_min ();
  const unsigned long int total_SDp_index_max = GSM_vector_helper_out.get_total_SDp_index_max ();

  if (total_SDp_index_min > total_SDp_index_max) return;
  
  class array<class Slater_determinant> SDp_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) SDp_tab(i).allocate (ZYval);
  
  diagonal_NBMEs_p = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned long int total_SDp_index = total_SDp_index_min ; total_SDp_index <= total_SDp_index_max ; total_SDp_index++)
    {
      const class SD_quantum_numbers &SDp_qn = SDp_quantum_numbers_tab(total_SDp_index);
 
      const int iMp = SDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = SDp_qn.get_BP ();
      
      const int Sp = SDp_qn.get_S ();
      
      const int n_spec_p = SDp_qn.get_n_spec ();
      
      const unsigned int n_scat_p = SDp_qn.get_n_scat ();

      const unsigned int iCp = SDp_qn.get_iC ();

      const unsigned int SDp_index = SDp_qn.get_SD_index ();

      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (dimension_SDp == 0) continue;
      
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (all_dimensions_SDn_zero) continue;
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &SDp = SDp_tab(i_thread);
      
      TYPE NBME_p = 0.0;

      SDp = SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index);
      
      for (int i = 0 ; i < ZYval ; i++)
	{
	  const unsigned int SDp_i = SDp[i];
			
	  NBME_p += uncoupled_OBME (CM_operator_inter , is_it_HO_expansion , prot_Y_data , SDp_i , SDp_i);

	  for (int ii = 0 ; ii < ZYval ; ii++)
	    {
	      const unsigned int SDp_ii = SDp[ii];
			
	      if ((SDp_i < SDp_ii) && !is_uncoupled_TBME_pp_nn_trivial_zero_determine (phi_p_table , SDp_i , SDp_ii , SDp_i , SDp_ii))
		NBME_p += uncoupled_TBME_pp_nn_calc (CM_operator_inter , is_it_HO_expansion , prot_Y_data , TBMEs_angular_table , SDp_i , SDp_ii , SDp_i , SDp_ii);
	    }
	}

      diagonal_NBMEs_p(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index) = NBME_p;
    }
}






void CM_operator_class::NBMEs_n_diagonal_all_SDs_calc_pn (const class baryons_data &neut_Y_data)
{
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const int n_holes_max_n = GSM_vector_helper_out.get_n_holes_max_n ();
  
  const int n_scat_max_n = GSM_vector_helper_out.get_n_scat_max_n ();

  const int En_max_hw = GSM_vector_helper_out.get_En_max_hw ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();  

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper_out.get_all_dimensions_SDp_zero_tab ();
  
  const int iMn_min_M = GSM_vector_helper_out.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper_out.get_iMn_max_M ();

  const unsigned long int total_SDn_index_min = GSM_vector_helper_out.get_total_SDn_index_min ();
  const unsigned long int total_SDn_index_max = GSM_vector_helper_out.get_total_SDn_index_max ();

  if (total_SDn_index_min > total_SDn_index_max) return;
  
  class array<class Slater_determinant> SDn_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) SDn_tab(i).allocate (NYval);
  
  diagonal_NBMEs_n = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned long int total_SDn_index = total_SDn_index_min ; total_SDn_index <= total_SDn_index_max ; total_SDn_index++)
    {
      const class SD_quantum_numbers &SDn_qn = SDn_quantum_numbers_tab(total_SDn_index);
 
      const int iMn = SDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = SDn_qn.get_BP ();
      
      const int Sn = SDn_qn.get_S ();
      
      const int n_spec_n = SDn_qn.get_n_spec ();
            
      const unsigned int n_scat_n = SDn_qn.get_n_scat ();

      const unsigned int iCn = SDn_qn.get_iC ();

      const unsigned int SDn_index = SDn_qn.get_SD_index ();
      
      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (dimension_SDn == 0) continue;
      
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (all_dimensions_SDp_zero) continue;
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &SDn = SDn_tab(i_thread);
      
      TYPE NBME_n = 0.0;

      SDn = SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index);

      for (int i = 0 ; i < NYval ; i++)
	{
	  const unsigned int SDn_i = SDn[i];
			  
	  NBME_n += uncoupled_OBME (CM_operator_inter , is_it_HO_expansion , neut_Y_data , SDn_i , SDn_i);

	  for (int ii = 0 ; ii < NYval ; ii++)
	    {
	      const unsigned int SDn_ii = SDn[ii];

	      if ((SDn_i < SDn_ii) && !is_uncoupled_TBME_pp_nn_trivial_zero_determine (phi_n_table , SDn_i , SDn_ii , SDn_i , SDn_ii))
		NBME_n += uncoupled_TBME_pp_nn_calc (CM_operator_inter , is_it_HO_expansion , neut_Y_data , TBMEs_angular_table , SDn_i , SDn_ii , SDn_i , SDn_ii);
	    }
	}

      diagonal_NBMEs_n(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index) = NBME_n;
    }
}



















void CM_operator_class::NBMEs_diagonal_all_SDs_calc_pp_nn (const class baryons_data &data)
{
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();

  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const enum particle_type nucleonic_particle = data.get_nucleonic_particle ();

  const bool is_it_charged = (nucleonic_particle == PROTON);
  
  const unsigned int BP = GSM_vector_helper_out.get_BP ();

  const int S = GSM_vector_helper_out.get_S ();
  
  const int iM = GSM_vector_helper_out.get_iM (); 

  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max (); 

  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw ();

  const class array<class nljm_struct> &phi_table = data.get_phi_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const int N_valence_baryons = data.get_N_valence_baryons ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  class array_BP_S_Nspec_Nscat_iC_iM_SD<TYPE> &diagonal_NBMEs = (is_it_charged) ? (diagonal_NBMEs_p) : (diagonal_NBMEs_n);
      
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_SD_index_min = GSM_vector_helper_out.get_total_SD_index_min ();
  const unsigned long int total_SD_index_max = GSM_vector_helper_out.get_total_SD_index_max ();

  if (total_SD_index_min > total_SD_index_max) return;
  
  class array<class Slater_determinant> SD_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) SD_tab(i).allocate (N_valence_baryons);
  
  diagonal_NBMEs = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned long int total_SD_index = total_SD_index_min ; total_SD_index <= total_SD_index_max ; total_SD_index++)
    {
      const class SD_quantum_numbers &SD_qn = SD_quantum_numbers_tab(total_SD_index);

      const unsigned int BP_SD = SD_qn.get_BP ();

      if (BP_SD != BP) continue;
      
      const int S_SD = SD_qn.get_S ();
  
      if (S_SD != S) continue;
 
      const int iM_SD = SD_qn.get_iM ();

      if (iM_SD != iM) continue;
      
      const unsigned int n_scat = SD_qn.get_n_scat ();

      const unsigned int iC = SD_qn.get_iC ();

      const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
      const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
      
      const unsigned int SD_index = SD_qn.get_SD_index ();
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &SD = SD_tab(i_thread);
	  
      TYPE NBME = 0.0;
      
      SD = SD_set(BP , S , 0 , n_scat , iC , iM , SD_index);

      for (int i = 0 ; i < N_valence_baryons ; i++)
	{
	  const unsigned int SDi = SD[i];
			  
	  NBME += uncoupled_OBME (CM_operator_inter , is_it_HO_expansion , data , SDi , SDi);
	  
	  for (int ii = 0 ; ii < N_valence_baryons ; ii++)
	    {
	      const unsigned int SDii = SD[ii];

	      if ((SDi < SDii) && !is_uncoupled_TBME_pp_nn_trivial_zero_determine (phi_table , SDi , SDii , SDi , SDii))
		NBME += uncoupled_TBME_pp_nn_calc (CM_operator_inter , is_it_HO_expansion , data , TBMEs_angular_table , SDi , SDii , SDi , SDii);
	    }
	}

      diagonal_NBMEs(BP , S , 0 , n_scat , iC , iM , SD_index) = NBME;
    }
}





void CM_operator_class::diagonal_part_pn_N_valence_larger_calc (
								const TYPE &alpha ,
								class GSM_vector &PSI_out) const
{  
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
    
  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_out.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max (); 

  const int n_holes_max_p = GSM_vector_helper_out.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_out.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_out.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper_out.get_n_scat_max_n ();
    
  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper_out.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_out.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper_out.get_BP ();

  const int S = GSM_vector_helper_out.get_S ();
  
  const int n_spec_max = GSM_vector_helper_out.get_n_spec_max ();
  
  const int iM = GSM_vector_helper_out.get_iM ();
    
  const int iMn_min_M = GSM_vector_helper_out.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper_out.get_iMn_max_M ();

  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const int CM_operator_rank = Op_rank_determine (CM_operator_inter);
  
  const bool is_it_TRS_in = GSM_vector_helper_in.get_is_it_TRS ();

  const bool is_it_TRS_out = GSM_vector_helper_out.get_is_it_TRS ();

  const bool is_it_TRS = ((CM_operator_rank == 0) && is_it_TRS_in && is_it_TRS_out);

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_out.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper_out.get_all_dimensions_SDp_zero_tab (); 

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
   
  const unsigned long int first_total_PSI_index = GSM_vector_helper_out.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper_out.get_last_total_PSI_index ();
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper_out.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper_out.get_iCp_max_process_tab ();
  
  const unsigned long int total_SDn_index_min = GSM_vector_helper_out.get_total_SDn_index_min ();
  const unsigned long int total_SDn_index_max = GSM_vector_helper_out.get_total_SDn_index_max ();

  if (total_SDn_index_min > total_SDn_index_max) return;
    
  class GSM_vector &PSI_in_full = get_PSI_in_full ();
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned long int total_SDn_index = total_SDn_index_min ; total_SDn_index <= total_SDn_index_max ; total_SDn_index++)
    {
      const class SD_quantum_numbers &SDn_qn = SDn_quantum_numbers_tab(total_SDn_index);

      const int iMn = SDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = SDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sn = SDn_qn.get_S ();

      const int Sp = S - Sn;

      const int n_spec_n = SDn_qn.get_n_spec ();

      const int n_spec_p = n_spec_max - n_spec_n;
      
      const int n_scat_n = SDn_qn.get_n_scat ();
	
      const unsigned int iCn = SDn_qn.get_iC ();

      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (dimension_SDn == 0) continue;
		  
      const int iMp = iM - iMn;

      const int TRS_iMp = iMp_max - iMp;
      
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (all_dimensions_SDp_zero) continue;
		  
      const unsigned int SDn_index = SDn_qn.get_SD_index ();
            
      const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index)) : (NADA);
      		      
      const TYPE &diagonal_NBME_n = diagonal_NBMEs_n(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index);
	  
      const TYPE diagonal_NBME_n_plus_alpha = diagonal_NBME_n + alpha;
      
      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
			  
	  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
	      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);	  

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
	      
	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

	      if (dimension_SDp == 0) continue;

	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

	      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + SDn_index;

	      const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDp_minus_one*dimension_SDn;
  
	      if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_SDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS + SDn_TRS_index) : (NADA);
				       
		  const unsigned long int total_SDp_index_zero = SDp_set.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0);
		  
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      const unsigned long int total_PSI_index = total_PSI_index_zero + SDp_index*dimension_SDn;

		      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
			{
			  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

			  const unsigned long int total_SDp_TRS_indices_index = (is_it_TRS) ? (total_SDp_TRS_indices_zero_index + SDp_index) : (NADA);

			  const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_SDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_index = (is_it_TRS) ? (TRS_total_PSI_index_zero + dimension_SDn*SDp_TRS_index) : (NADA);

			  if (!is_it_TRS || (TRS_total_PSI_index >= total_PSI_index))
			    {
			      const unsigned long int total_SDp_index = total_SDp_index_zero + SDp_index;

			      const TYPE &diagonal_NBME_p = diagonal_NBMEs_p[total_SDp_index];
			      
			      const TYPE NBME = diagonal_NBME_n_plus_alpha + diagonal_NBME_p;
			      
			      const TYPE &PSI_in_component = PSI_in_full[total_PSI_index];
			      
			      PSI_out[PSI_index] += PSI_in_component*NBME;
			    }}}}}}}
}














void CM_operator_class::diagonal_part_pn_Z_valence_larger_calc (
								const TYPE &alpha ,
								class GSM_vector &PSI_out) const
{  
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
      
  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_out.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max (); 

  const int n_holes_max_p = GSM_vector_helper_out.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_out.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_out.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper_out.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper_out.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper_out.get_En_max_hw ();

  const unsigned int BP = GSM_vector_helper_out.get_BP ();
  
  const int S = GSM_vector_helper_out.get_S ();
  
  const int n_spec_max = GSM_vector_helper_out.get_n_spec_max ();
  
  const int iM = GSM_vector_helper_out.get_iM (); 

  const int iMp_min_M = GSM_vector_helper_out.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper_out.get_iMp_max_M (); 

  const int iMp_max = prot_Y_data.get_iM_max ();

  const int CM_operator_rank = Op_rank_determine (CM_operator_inter);
  
  const bool is_it_TRS_in = GSM_vector_helper_in.get_is_it_TRS ();

  const bool is_it_TRS_out = GSM_vector_helper_out.get_is_it_TRS ();

  const bool is_it_TRS = ((CM_operator_rank == 0) && is_it_TRS_in && is_it_TRS_out);

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_out.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper_out.get_all_dimensions_SDn_zero_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
    
  const unsigned long int first_total_PSI_index = GSM_vector_helper_out.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper_out.get_last_total_PSI_index ();
  
  const unsigned long int total_SDp_index_min = GSM_vector_helper_out.get_total_SDp_index_min ();
  const unsigned long int total_SDp_index_max = GSM_vector_helper_out.get_total_SDp_index_max ();

  if (total_SDp_index_min > total_SDp_index_max) return;
  
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper_out.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper_out.get_iCn_max_process_tab ();
   
  class GSM_vector &PSI_in_full = get_PSI_in_full ();
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned long int total_SDp_index = total_SDp_index_min ; total_SDp_index <= total_SDp_index_max ; total_SDp_index++)
    {
      const class SD_quantum_numbers &SDp_qn = SDp_quantum_numbers_tab(total_SDp_index);

      const int iMp = SDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = SDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sp = SDp_qn.get_S ();
      
      const int Sn = S - Sp;
      
      const int n_spec_p = SDp_qn.get_n_spec ();
      
      const int n_spec_n = n_spec_max - n_spec_p;
      
      const int n_scat_p = SDp_qn.get_n_scat ();
	
      const unsigned int iCp = SDp_qn.get_iC ();

      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (dimension_SDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (all_dimensions_SDn_zero) continue;
	
      const int iMn = iM - iMp;

      const int TRS_iMp = iMp_max - iMp;

      const unsigned int SDp_index = SDp_qn.get_SD_index ();
  
      const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index)) : (NADA);
		      
      const TYPE &diagonal_NBME_p = diagonal_NBMEs_p(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index);
	  
      const TYPE diagonal_NBME_p_plus_alpha = diagonal_NBME_p + alpha;
      
      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
	  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
			  
	  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
	      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);	  

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

	      if (dimension_SDn == 0) continue;

	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);
				  
	      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;

	      const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDn_minus_one;
  
	      if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_SDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS + dimension_SDn*SDp_TRS_index) : (NADA);
			
		  const unsigned long int total_SDn_index_zero = SDn_set.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0);
		      
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      const unsigned long int total_PSI_index = total_PSI_index_zero + SDn_index;

		      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
			{
			  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

			  const unsigned long int total_SDn_TRS_indices_index = (is_it_TRS) ? (total_SDn_TRS_indices_zero_index + SDn_index) : (NADA);

			  const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_SDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_index = (is_it_TRS) ? (TRS_total_PSI_index_zero + SDn_TRS_index) : (NADA);

			  if (!is_it_TRS || (TRS_total_PSI_index >= total_PSI_index))
			    {
			      const unsigned long int total_SDn_index = total_SDn_index_zero + SDn_index;

			      const TYPE &diagonal_NBME_n = diagonal_NBMEs_n[total_SDn_index];
			      
			      const TYPE NBME = diagonal_NBME_p_plus_alpha + diagonal_NBME_n;
			      
			      const TYPE &PSI_in_component = PSI_in_full[total_PSI_index];
			      
			      PSI_out[PSI_index] += PSI_in_component*NBME;
			    }}}}}}}
}


























void CM_operator_class::diagonal_part_pp_nn_calc (
						  const TYPE &alpha ,
						  class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
            
  const enum space_type space = GSM_vector_helper_out.get_space ();

  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_out.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();
	
  const unsigned int BP = GSM_vector_helper_out.get_BP (); 

  const int S = GSM_vector_helper_out.get_S ();
  
  const int iM = GSM_vector_helper_out.get_iM ();
        
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_out.get_sum_dimensions_GSM_vector_TRS ();
    
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<TYPE> &diagonal_NBMEs = (space == PROT_Y_ONLY) ? (diagonal_NBMEs_p) : (diagonal_NBMEs_n);

  const unsigned long int first_total_PSI_index = GSM_vector_helper_out.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper_out.get_last_total_PSI_index ();
  
  const int CM_operator_rank = Op_rank_determine (CM_operator_inter);
  
  const bool is_it_TRS_in = GSM_vector_helper_in.get_is_it_TRS ();

  const bool is_it_TRS_out = GSM_vector_helper_out.get_is_it_TRS ();

  const bool is_it_TRS = ((CM_operator_rank == 0) && is_it_TRS_in && is_it_TRS_out);
    
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_SD_index_min = GSM_vector_helper_out.get_total_SD_index_min ();
  const unsigned long int total_SD_index_max = GSM_vector_helper_out.get_total_SD_index_max ();

  if (total_SD_index_min > total_SD_index_max) return;
    
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = data.get_SD_TRS_indices ();
  
  class GSM_vector &PSI_in_full = get_PSI_in_full ();

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned long int total_SD_index = total_SD_index_min ; total_SD_index <= total_SD_index_max ; total_SD_index++)
    {
      const class SD_quantum_numbers &SD_qn = SD_quantum_numbers_tab(total_SD_index);

      const unsigned int BP_SD = SD_qn.get_BP ();

      if (BP_SD != BP) continue;
 
      const int S_SD = SD_qn.get_S ();

      if (S_SD != S) continue;

      const int iM_SD = SD_qn.get_iM ();

      if (iM_SD != iM) continue;
      
      const unsigned int n_scat = SD_qn.get_n_scat ();

      const unsigned int iC = SD_qn.get_iC ();

      const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
      const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
      
      const unsigned int SD_index = SD_qn.get_SD_index ();

      const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions_GSM_vector(n_scat , iC);

      const unsigned long int total_PSI_index = sum_dimensions_configuration_fixed + SD_index;
      
      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
	{
	  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;
      
	  const unsigned int SD_TRS_index = (is_it_TRS) ? (SD_TRS_indices(BP , S , 0 , n_scat , iC , iM , SD_index)) : (NADA);

	  const unsigned long int sum_dimensions_configuration_fixed_TRS = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(n_scat , iC)) : (NADA);

	  const unsigned long int TRS_total_PSI_index = (is_it_TRS) ? (sum_dimensions_configuration_fixed_TRS + SD_TRS_index) : (NADA);
			      
	  if (!is_it_TRS || (TRS_total_PSI_index >= total_PSI_index))
	    {
	      const TYPE &diagonal_NBME = diagonal_NBMEs(BP , S , 0 , n_scat , iC , iM , SD_index);
	  
	      const TYPE NBME = diagonal_NBME + alpha;
	  
	      const TYPE &PSI_in_component = PSI_in_full[total_PSI_index];
			  
	      PSI_out[PSI_index] += PSI_in_component*NBME;
	    }
	}
    }
}
