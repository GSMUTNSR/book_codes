#include "../GSM_include/GSM_include_def.h"

// MPI transfer is sometimes done here even if is_it_MPI_parallelized is false as disk access cannot be done by many processes at the same time

using namespace string_routines;
using namespace Wigner_signs;
using namespace inputs_misc;
using namespace correlated_state_routines;
using namespace configuration_SD_in_space_one_jump_out_to_in;
using namespace GSM_vector_dimensions;

extern enum called_code_type called_code;

// TYPE is double or complex
// -------------------------

// Determination of the arrays of booleans stating if one calculates GSM states of new J-Pi or BP,M quantum numbers
// ----------------------------------------------------------------------------------------------------------------
// GSM vectors explicit quantum numbers are BP (binary parity, see observables_basic_functions.cpp for definition) 
// and angular momentum projection M. They are fixed when calculating the eigenvectors of a fixed eigenset, i.e. fot J,Pi fixed.
// If one goes from an eigenset to another with BP, M changing, for example from 0+ to 3-, the Hamiltonian matrix must be recalculated.
// If, however, one goes from 0+ to 1+ and BP, M do not change, as M=0 therein, the Hamiltonian matrix is not recalculated and stays the same.
// One just has to take into account the change of J from 0 to 1.

void eigenvector_functions::changing_eigensets_bool_tables_calc (
								 const class input_data_str &input_data , 
								 const class array<double> &M_table , 
								 class array<bool> &is_it_new_J_Pi_tab , 
								 class array<bool> &is_it_new_BP_M_tab)
{	
  const class array<unsigned int> &BP_eigenset_tab = input_data.get_BP_eigenset_tab ();

  const class array<double> &J_eigenset_tab = input_data.get_J_eigenset_tab ();

  const unsigned int eigensets_number = input_data.get_eigensets_number ();

  const int S = input_data.get_hypernucleus_strangeness ();
  
  unsigned int BP_bef = 2;

  double J_bef = -1;

  double M_bef = -2;

  for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
    {
      const unsigned int BP = BP_eigenset_tab(eigenset_index);
      
      const double J = J_eigenset_tab(eigenset_index);

      const double M = M_table(eigenset_index);

      is_it_new_BP_M_tab(eigenset_index) = ((eigenset_index == 0) || !same_BP_S_M (BP , S , M , BP_bef , S , M_bef));
      is_it_new_J_Pi_tab(eigenset_index) = ((eigenset_index == 0) || !same_BP_S_J (BP , S , J , BP_bef , S , J_bef));

      BP_bef = BP;
      
      J_bef = J;
      M_bef = M;
    }
}






// Calculation and print on screen of observables involving a newly calculated GSM eigenstate
// ------------------------------------------------------------------------------------------
// The GSM eigenstate |Psi> has just been calculated from the Jacobi-Davidson or Lanczos method.
// One first calculates the precision of J and quality of eigenstate with |J^2.|Psi> - J(J+1).|Psi>|oo and |H.|Psi> - E.|Psi>|oo.
// Isospin precision or mixture is similarly calculated from |T^2.|Psi> - T(T+1).|Psi>|oo for the proton-neutron case if demanded.
// If demanded as well, expectation values of center of mass operators <Psi|Hcm|Psi>, <Psi|L^2[CM]|Psi> and <Psi|P^2/2M|Psi> are calculated if one uses laboratory coordinates.
// If demanded, and if COSM coordinates are used, the recoil term <Psi|(pi.pj)/M[core]|Psi> is calculated, with HO expansion and calculation of radial integral on [0:R] only (R cut).
// Energy, J-Pi and T (if demanded, and for the proton-neutron case only) are printed at the end.


void eigenvector_functions::write_expectation_values (
						      const class input_data_str &input_data , 
						      const class GSM_vector &PSI , 
						      const class J2_class &J2 , 
						      const class T2_class &T2 , 
						      const class H_class &H , 
						      const class L2_CM_class &L2_CM ,
						      class GSM_vector &PSI_full , 
						      class GSM_vector &Vstore , 
						      const class correlated_state_str &PSI_qn)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Expectation values" << endl;
      cout <<         "------------------" << endl << endl;
    }
  
  class GSM_vector_helper_class &PSI_helper_M = Vstore.get_GSM_vector_helper ();

  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
  
  const bool good_isospin_basis_potential = input_data.get_good_isospin_basis_potential ();
  
  const bool is_Coulomb_Hamiltonian_here = input_data.get_is_Coulomb_Hamiltonian_here ();
  
  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();

  const bool T2_CM_operators_calculated = input_data.get_T2_CM_operators_calculated ();

  const bool are_configuration_probabilities_printed = input_data.get_are_configuration_probabilities_printed ();

  const bool are_scattering_configuration_probabilities_printed = input_data.get_are_scattering_configuration_probabilities_printed ();

  const double configuration_precision = input_data.get_configuration_precision ();

  const double J = PSI_qn.get_J ();

  const unsigned int BP = PSI_helper_M.get_BP ();
  
  const bool is_it_COSM = is_it_COSM_determine (inter);

  const complex<double> E_complex = PSI_qn.get_E (); 

  const TYPE E = generate_scalar<TYPE> (real (E_complex) , imag (E_complex));

  class GSM_vector &Res = Vstore;

  Res = (J2 - J*(J+1))*PSI;

  const double J2_test = Res.infinite_norm ();
      
  if (THIS_PROCESS == MASTER_PROCESS) cout << "|J^2.PSI - J(J+1).PSI|oo = " << J2_test << endl << endl;

  Res = (H - E)*PSI;

  const double H_test = Res.infinite_norm ();

  if (THIS_PROCESS == MASTER_PROCESS) cout << "|H.PSI - E.PSI|oo = " << H_test << endl << endl;
	  
  if (good_isospin_basis_potential && !is_Coulomb_Hamiltonian_here) PSI.space_dimension_SDs_components_eigenvector_good_T_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);
  
  if (T2_CM_operators_calculated)
    {
      if (space == PROT_NEUT_Y)
	{
	  const int Z_core = input_data.get_Z_core ();
	  const int N_core = input_data.get_N_core ();  
	  
	  if (Z_core == N_core)
	    {
	      class GSM_vector &T2_PSI = Vstore;

	      T2_PSI = T2*PSI;
	      
	      const TYPE average_T = (-1.0 + sqrt (1.0 + 4.0*(PSI*T2_PSI)))/2.0;

	      const TYPE two_average_T = 2.0*average_T;

	      const int two_average_T_int = make_int (real_dc (two_average_T));

	      if (inf_norm (two_average_T - two_average_T_int) < precision)
		{	
		  Res -= average_T*(average_T + 1)*PSI;

		  const double T2_test = Res.infinite_norm ();

		  const double average_T_half_int = 0.5*two_average_T_int;
	      
		  if (THIS_PROCESS == MASTER_PROCESS) cout << "T = " << J_string (average_T_half_int) << endl << "|T^2.PSI - T(T+1).PSI|oo = " << T2_test << endl << endl;
		}
	      else if (THIS_PROCESS == MASTER_PROCESS)
		{
		  if (good_isospin_basis_potential && !is_Coulomb_Hamiltonian_here) cout << "The eigenvector is not exactly coupled to T" << endl;
	      
		  cout << "<T> = " << average_T << endl << endl;	      
		}
	    }
	}
      
      if (!is_it_COSM) 
	{
	  const class CM_operator_class Hcm(HCM , false , J , true , PSI_helper_M , PSI_helper_M , PSI_full);

	  class GSM_vector &Hcm_PSI = Vstore;
	  	  
	  Hcm_PSI = Hcm*PSI;

	  const TYPE average_Hcm = PSI*Hcm_PSI;

	  if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hcm|PSI> = " << average_Hcm << " MeV" << endl << endl;

	  class GSM_vector &L2_CM_PSI = Vstore;

	  L2_CM_PSI = L2_CM*PSI;

	  const TYPE average_L2_CM = PSI*L2_CM_PSI;
	  
	  if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|L^2[CM]|PSI> = " << average_L2_CM << endl << endl;

	  const class CM_operator_class P2_over_2M(CM_KINETIC , false , J , true , PSI_helper_M , PSI_helper_M , PSI_full);

	  class GSM_vector &P2_over_2M_PSI = Vstore;

	  P2_over_2M_PSI = P2_over_2M*PSI;

	  const TYPE average_P2_over_2M = PSI*P2_over_2M_PSI;

	  if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|P^2/2M|PSI> = " << average_P2_over_2M << " MeV" << endl << endl;
	}
      else
	{
	  const class CM_operator_class pi_pj_over_2M_HO_expansion(CM_KINETIC , false , J , true , PSI_helper_M , PSI_helper_M , PSI_full);

	  class GSM_vector &pi_pj_over_2M_PSI = Vstore;

	  pi_pj_over_2M_PSI = pi_pj_over_2M_HO_expansion*PSI;

	  const TYPE average_pi_pj_over_2M_HO_expansion = PSI*pi_pj_over_2M_PSI;

	  if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|(pi.pj)/M[core]|PSI> = " << average_pi_pj_over_2M_HO_expansion << " MeV (HO expansion)" << endl;

	  const class CM_operator_class pi_pj_over_2M_R_cut(CM_KINETIC , false , J , false , PSI_helper_M , PSI_helper_M , PSI_full);
	  
	  pi_pj_over_2M_PSI = pi_pj_over_2M_R_cut*PSI;
	  
	  const TYPE average_pi_pj_over_2M_R_cut = PSI*pi_pj_over_2M_PSI;
	  
	  if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|(pi.pj)/M[core]|PSI> = " << average_pi_pj_over_2M_R_cut << " MeV (R cut)" << endl << endl;
	}
    }
  
  if (THIS_PROCESS == MASTER_PROCESS) cout << "E:" << E << "  J Pi:" << J_Pi_string (BP , J) << endl << endl;
  
  if (are_configuration_probabilities_printed)
    {
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  cout << endl << "Configuration probabilities" << endl;
	  cout <<         "---------------------------" << endl << endl;
	}
      
      PSI.configuration_occupation_print (are_scattering_configuration_probabilities_printed , configuration_precision);
    }
}















// Calculation of all eigenvectors |Psi>^J_M, with |M| <= J from an occurrence of |Psi> of fixed M value
// -----------------------------------------------------------------------------------------------------
// A GSM eigenstate |Psi> is calculated with a fixed value of M, with M=0 or M=J typically.
// However, one has to have M=J when calculating other observables as energy,
// and all |Psi>^J_M, |M| <= J, are needed for spectroscopic factors, overlap functions or reaction calculations.
// Consequently, they are all calculated here by iterative applications of J+/J-.
// Negative values of M are not handled with J+/J- as they can directly obtained from the time-reversal symmetry (TRS) of |J M> with M>0: |J -M> = (-1)^(J - M) . TRS|J M> (see GSM_TRS.cpp).
// The J quantum number can numerically lose its good quantum number character by applying iteratively J+/J-, even though it is not the case theoretically.
// Hence, J^2 precision is always calculated, and J projection is done in case J is no longer a good quantum number numerically.
//
// M_plus_one_eigenvector_calc_stored:  |J M+1> is calculated and stored on disk from |J M>, with M   >= 0 and M+1 <= J
// M_minus_one_eigenvector_calc_stored: |J M-1> is calculated and stored on disk from |J M>, with M-1 >= 0
// eigenvector_stored_with_all_M_projections: all |J M> are calculated using previous functions for M >= 0 and TRS for M<0


void eigenvector_functions::M_plus_one_eigenvector_calc_stored (
								const bool is_there_cout , 
								const bool is_there_cout_detailed , 
								const class input_data_str &input_data , 
								const class array<unsigned long int> &dimensions_good_J , 
								const class correlated_state_str &PSI_qn , 
								class GSM_vector_helper_class &PSI_helper_M ,
								class GSM_vector &PSI_full) 
{
  const bool is_it_MPI_parallelized_local = PSI_helper_M.get_is_it_MPI_parallelized_local ();
  
  const bool is_it_pole_approximation = PSI_helper_M.get_is_it_pole_approximation ();

  const bool full_common_vectors_used_in_file_full_space = input_data.get_full_common_vectors_used_in_file ();

  const bool full_common_vectors_used_in_file = (full_common_vectors_used_in_file_full_space || is_it_pole_approximation);

  const bool good_isospin_basis_potential = input_data.get_good_isospin_basis_potential ();
  
  const bool is_Coulomb_Hamiltonian_here = input_data.get_is_Coulomb_Hamiltonian_here ();
  
  const bool J_projected = input_data.get_J_projected ();
  
  const bool are_GSM_vectors_stored_on_disk = input_data.get_are_GSM_vectors_stored_on_disk ();

  const bool is_it_Lowdin = input_data.get_is_it_Lowdin ();
  
  const enum space_type space = PSI_helper_M.get_space ();

  const enum interaction_type inter = PSI_helper_M.get_inter ();
  
  const bool truncation_hw = PSI_helper_M.get_truncation_hw ();
  const bool truncation_ph = PSI_helper_M.get_truncation_ph ();

  const int n_scat_max_p = PSI_helper_M.get_n_scat_max_p ();
  const int n_scat_max_n = PSI_helper_M.get_n_scat_max_n ();

  const int n_scat_max = PSI_helper_M.get_n_scat_max ();

  const int n_holes_max_p = PSI_helper_M.get_n_holes_max_p ();
  const int n_holes_max_n = PSI_helper_M.get_n_holes_max_n ();

  const int n_holes_max = PSI_helper_M.get_n_holes_max ();
  
  const int Ep_max_hw = PSI_helper_M.get_Ep_max_hw ();
  const int En_max_hw = PSI_helper_M.get_En_max_hw ();

  const int E_max_hw = PSI_helper_M.get_E_max_hw ();

  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();
  
  const unsigned int BP = PSI_qn.get_BP ();

  const unsigned int vector_index = PSI_qn.get_vector_index ();

  const double J = PSI_qn.get_J ();

  const double M = PSI_helper_M.get_M ();

  const double Mp1 = M + 1.0;
  const double Mp2 = M + 2.0;

  class baryons_data &prot_Y_data = PSI_helper_M.get_prot_Y_data ();
  class baryons_data &neut_Y_data = PSI_helper_M.get_neut_Y_data ();
  
  class GSM_vector_helper_class PSI_helper_Mp1(is_it_MPI_parallelized_local , space , inter , is_it_pole_approximation , truncation_hw , truncation_ph ,
					       n_holes_max   , n_scat_max   , E_max_hw  ,
					       n_holes_max_p , n_scat_max_p , Ep_max_hw ,
					       n_holes_max_n , n_scat_max_n , En_max_hw , BP , Mp1 , false , prot_Y_data , neut_Y_data);
  
  class GSM_vector_helper_class PSI_helper_Mp2(is_it_MPI_parallelized_local , space , inter , is_it_pole_approximation , truncation_hw , truncation_ph ,
					       n_holes_max   , n_scat_max   , E_max_hw  ,
					       n_holes_max_p , n_scat_max_p , Ep_max_hw ,
					       n_holes_max_n , n_scat_max_n , En_max_hw , BP , Mp2 , false , prot_Y_data , neut_Y_data);

  class GSM_vector PSI0_Mp1(PSI_helper_Mp1);
  class GSM_vector PSI1_Mp1(PSI_helper_Mp1);

  class GSM_vector Vstore(PSI_helper_Mp1);

  class GSM_vector PSI0_Mp2(PSI_helper_Mp2);
  class GSM_vector PSI1_Mp2(PSI_helper_Mp2);
  class GSM_vector PSI2_Mp2(PSI_helper_Mp2);
  
  const class Jpm_class Jplus(false , false , 1 , Hamiltonian_storage , true , PSI_helper_M , PSI_helper_Mp1 , PSI_full , PSI0_Mp1 , PSI1_Mp1);
  
  class GSM_vector PSI_M(PSI_helper_M);

  PSI_M.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);
      
  class GSM_vector PSI_Mp1 = Jplus*PSI_M;

  PSI_Mp1.normalization ();
 
  const class Jpm_class Jplus_J2 (false , false ,  1 , Hamiltonian_storage , true , PSI_helper_Mp1 , PSI_helper_Mp2 , PSI_full , PSI0_Mp2 , PSI1_Mp2);
  const class Jpm_class Jminus_J2(false , false , -1 , Hamiltonian_storage , true , PSI_helper_Mp2 , PSI_helper_Mp1 , PSI_full , PSI0_Mp1 , PSI1_Mp1);

  class J2_class J2(Jplus_J2 , Jminus_J2 , PSI2_Mp2);

  const double J_coupling_precision = J2.J_coupling_precision_calc (PSI_Mp1 , J , Vstore);
      
  if (J_projected && (J_coupling_precision > precision))
    {
      if (is_it_Lowdin)
	PSI_Mp1.good_J_Lowdin (is_there_cout_detailed , J2 , J , Vstore);
      else
	{
	  const unsigned int J_number = J_number_calc (space , prot_Y_data , neut_Y_data , BP , n_scat_max , Mp1 , dimensions_good_J);
	  	  
	  if (are_GSM_vectors_stored_on_disk)
	    {
	      class array<class GSM_vector> GSM_work_vectors(NUMBER_OF_THREADS);
	      
	      GSM_work_vectors(0).virtual_allocate (PSI_helper_Mp1 , Vstore);
	      
	      for (unsigned int i = 1 ; i < NUMBER_OF_THREADS ; i++) GSM_work_vectors(i).allocate (PSI_helper_Mp1);
		  
	      Lanczos_GSM_disk::J2_projection::J_projected_GSM_vector_calc (is_there_cout_detailed , J , J_number , J2 , GSM_work_vectors , Vstore , PSI_Mp1);
	    }
	  else
	    {	  
	      class array<class GSM_vector> Vp_tab(J_number);
	      	      
	      Vp_tab(0).virtual_allocate (PSI_helper_Mp1 , Vstore);
	      
	      for (unsigned int i = 1 ; i < J_number ; i++) Vp_tab(i).allocate (PSI_helper_Mp1);
		      
	      Lanczos_GSM_not_disk::J2_projection::J_projected_GSM_vector_calc (is_there_cout_detailed , J , J_number , J2 , Vp_tab , PSI_Mp1);
	    }
	}
    }
  else
    PSI_Mp1.normalization ();

  PSI_Mp1.space_dimension_SDs_components_eigenvector_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);
      
  if (good_isospin_basis_potential && !is_Coulomb_Hamiltonian_here) PSI_Mp1.space_dimension_SDs_components_eigenvector_good_T_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    cout << "GSM eigenvector "<< JM_Pi_vector_index_string (BP , J , vector_index , Mp1) << " calculated and stored. Precision : " << J_coupling_precision << endl;
}










void eigenvector_functions::M_minus_one_eigenvector_calc_stored (
								 const bool is_there_cout , 
								 const bool is_there_cout_detailed , 
								 const class input_data_str &input_data , 
								 const class array<unsigned long int> &dimensions_good_J , 
								 const class correlated_state_str &PSI_qn , 
								 class GSM_vector_helper_class &PSI_helper_M ,
								 class GSM_vector &PSI_full) 
{
  const enum space_type space = PSI_helper_M.get_space ();

  const enum interaction_type inter = PSI_helper_M.get_inter ();

  const bool is_it_pole_approximation = PSI_helper_M.get_is_it_pole_approximation ();

  const bool full_common_vectors_used_in_file_full_space = input_data.get_full_common_vectors_used_in_file ();

  const bool full_common_vectors_used_in_file = (full_common_vectors_used_in_file_full_space || is_it_pole_approximation);

  const bool good_isospin_basis_potential = input_data.get_good_isospin_basis_potential ();
  
  const bool is_Coulomb_Hamiltonian_here = input_data.get_is_Coulomb_Hamiltonian_here ();
  
  const bool is_it_MPI_parallelized_local = PSI_helper_M.get_is_it_MPI_parallelized_local ();
  
  const bool J_projected = input_data.get_J_projected ();
  
  const bool are_GSM_vectors_stored_on_disk = input_data.get_are_GSM_vectors_stored_on_disk ();

  const bool is_it_Lowdin = input_data.get_is_it_Lowdin ();
  
  const bool truncation_hw = PSI_helper_M.get_truncation_hw ();
  const bool truncation_ph = PSI_helper_M.get_truncation_ph ();

  const int n_scat_max_p = PSI_helper_M.get_n_scat_max_p ();
  const int n_scat_max_n = PSI_helper_M.get_n_scat_max_n ();

  const int n_scat_max = PSI_helper_M.get_n_scat_max ();
  
  const int n_holes_max_p = PSI_helper_M.get_n_holes_max_p ();
  const int n_holes_max_n = PSI_helper_M.get_n_holes_max_n ();

  const int n_holes_max = PSI_helper_M.get_n_holes_max ();

  const int Ep_max_hw = PSI_helper_M.get_Ep_max_hw ();
  const int En_max_hw = PSI_helper_M.get_En_max_hw ();

  const int E_max_hw = PSI_helper_M.get_E_max_hw ();

  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const unsigned int BP = PSI_qn.get_BP ();

  const unsigned int vector_index = PSI_qn.get_vector_index ();
  
  const double J = PSI_qn.get_J ();

  const double M = PSI_helper_M.get_M ();

  const double Mm1 = M - 1.0;

  class baryons_data &prot_Y_data = PSI_helper_M.get_prot_Y_data ();
  class baryons_data &neut_Y_data = PSI_helper_M.get_neut_Y_data ();
      
  class GSM_vector_helper_class PSI_helper_Mm1(is_it_MPI_parallelized_local , space , inter , is_it_pole_approximation , truncation_hw , truncation_ph ,
					       n_holes_max   , n_scat_max   , E_max_hw ,
					       n_holes_max_p , n_scat_max_p , Ep_max_hw ,
					       n_holes_max_n , n_scat_max_n , En_max_hw , BP , Mm1 , false , prot_Y_data , neut_Y_data);
 
  class GSM_vector PSI0_M(PSI_helper_M);
  class GSM_vector PSI1_M(PSI_helper_M);
  class GSM_vector PSI2_M(PSI_helper_M);

  class GSM_vector PSI0_Mm1(PSI_helper_Mm1);
  class GSM_vector PSI1_Mm1(PSI_helper_Mm1);
  
  class GSM_vector Vstore(PSI_helper_Mm1);

  const class Jpm_class Jminus(false , false , -1 , Hamiltonian_storage , true , PSI_helper_M , PSI_helper_Mm1 , PSI_full , PSI0_Mm1 , PSI1_Mm1);
  
  class GSM_vector PSI_M(PSI_helper_M);

  PSI_M.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);
       
  class GSM_vector PSI_Mm1 = Jminus*PSI_M;

  PSI_Mm1.normalization ();

  const class Jpm_class Jplus_J2 (false , false,   1 , Hamiltonian_storage , true , PSI_helper_Mm1 , PSI_helper_M   , PSI_full , PSI0_M   , PSI1_M);
  const class Jpm_class Jminus_J2(false , false , -1 , Hamiltonian_storage , true , PSI_helper_M   , PSI_helper_Mm1 , PSI_full , PSI0_Mm1 , PSI1_Mm1);

  const class J2_class J2(Jplus_J2 , Jminus_J2 , PSI2_M);

  const double J_coupling_precision = J2.J_coupling_precision_calc (PSI_Mm1 , J , Vstore);
  
  if (J_projected && (J_coupling_precision > precision))
    {
      if (is_it_Lowdin)
	PSI_Mm1.good_J_Lowdin (is_there_cout_detailed , J2 , J , Vstore);
      else
	{
	  const unsigned int J_number = J_number_calc (space , prot_Y_data , neut_Y_data , BP , n_scat_max , Mm1 , dimensions_good_J);
	  
	  if (are_GSM_vectors_stored_on_disk)
	    {
	      class array<class GSM_vector> GSM_work_vectors(NUMBER_OF_THREADS);
	      
	      GSM_work_vectors(0).virtual_allocate (PSI_helper_Mm1 , Vstore);
	      
	      for (unsigned int i = 1 ; i < NUMBER_OF_THREADS ; i++) GSM_work_vectors(i).allocate (PSI_helper_Mm1);
		  
	      Lanczos_GSM_disk::J2_projection::J_projected_GSM_vector_calc (is_there_cout_detailed , J , J_number , J2 , GSM_work_vectors , Vstore , PSI_Mm1);
	    }
	  else
	    {	  
	      class array<class GSM_vector> Vp_tab(J_number);
	      
	      Vp_tab(0).virtual_allocate (PSI_helper_Mm1 , Vstore);
	      
	      for (unsigned int i = 1 ; i < J_number ; i++) Vp_tab(i).allocate (PSI_helper_Mm1);
		      
	      Lanczos_GSM_not_disk::J2_projection::J_projected_GSM_vector_calc (is_there_cout_detailed , J , J_number , J2 , Vp_tab , PSI_Mm1);
	    }
	}
    }
  else
    PSI_Mm1.normalization ();
   
  PSI_Mm1.space_dimension_SDs_components_eigenvector_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);
  
  if (good_isospin_basis_potential && !is_Coulomb_Hamiltonian_here) PSI_Mm1.space_dimension_SDs_components_eigenvector_good_T_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    cout << "GSM eigenvector "<< JM_Pi_vector_index_string (BP , J , vector_index , Mm1) << " calculated and stored. Precision : " << J_coupling_precision << endl;
}









void eigenvector_functions::eigenvector_stored_with_all_M_projections (
								       const bool is_there_cout , 
								       const bool is_there_cout_detailed , 
								       const class input_data_str &input_data , 
								       const class array<unsigned long int> &dimensions_good_J , 
								       const class correlated_state_str &PSI_qn , 
								       class GSM_vector_helper_class &PSI_helper_M_deb ,
								       class GSM_vector &PSI_full) 
{
  const unsigned int BP = PSI_qn.get_BP ();

  const unsigned int vector_index = PSI_qn.get_vector_index ();
  
  const double J = PSI_qn.get_J ();
  
  if (is_there_cout && (THIS_PROCESS == MASTER_PROCESS))
    {
      cout << endl << J_Pi_vector_index_string (BP , J , vector_index) << " GSM vectors calculated for all M values"   << endl;
      cout <<                                                             "----------------------------------------------------" << endl << endl;
    }
  
  const bool is_it_pole_approximation = PSI_helper_M_deb.get_is_it_pole_approximation ();
      
  const bool full_common_vectors_used_in_file_full_space = input_data.get_full_common_vectors_used_in_file ();
  const bool full_common_vectors_used_in_file = (full_common_vectors_used_in_file_full_space || is_it_pole_approximation);

  const bool is_it_MPI_parallelized_local = PSI_helper_M_deb.get_is_it_MPI_parallelized_local ();

  const enum space_type space = PSI_helper_M_deb.get_space ();

  const enum interaction_type inter = PSI_helper_M_deb.get_inter ();

  const bool truncation_hw = PSI_helper_M_deb.get_truncation_hw ();
  const bool truncation_ph = PSI_helper_M_deb.get_truncation_ph ();

  const int n_scat_max_p = PSI_helper_M_deb.get_n_scat_max_p ();
  const int n_scat_max_n = PSI_helper_M_deb.get_n_scat_max_n ();

  const int n_scat_max = PSI_helper_M_deb.get_n_scat_max ();

  const int n_holes_max_p = PSI_helper_M_deb.get_n_holes_max_p ();
  const int n_holes_max_n = PSI_helper_M_deb.get_n_holes_max_n ();

  const int n_holes_max = PSI_helper_M_deb.get_n_holes_max ();
  
  const int Ep_max_hw = PSI_helper_M_deb.get_Ep_max_hw (); 
  const int En_max_hw = PSI_helper_M_deb.get_En_max_hw ();

  const int E_max_hw = PSI_helper_M_deb.get_E_max_hw ();

  const double M_deb = PSI_helper_M_deb.get_M ();

  class baryons_data &prot_Y_data = PSI_helper_M_deb.get_prot_Y_data ();
  class baryons_data &neut_Y_data = PSI_helper_M_deb.get_neut_Y_data ();
  
  const double Mp_max = prot_Y_data.get_M_max ();
  const double Mn_max = neut_Y_data.get_M_max ();

  const double M_max = Mp_max + Mn_max;
  
  const int two_J = make_int (2.0*J);
  
  const double smallest_positive_M = (two_J%2 == 0) ? (0) : (0.5);

  const int iM_deb = make_int (M_deb + M_max);

  const int iM_J = make_int (J + M_max);

  const int iM_smallest_positive = make_int (smallest_positive_M + M_max);

  const int iM_smallest_positive_non_zero = (two_J%2 == 0) ? (iM_smallest_positive + 1) : (iM_smallest_positive);

  for (int iM = iM_deb ; iM < iM_J ; iM++)
    {
      const double M = iM - M_max;

      class GSM_vector_helper_class PSI_helper_M(is_it_MPI_parallelized_local , space , inter , is_it_pole_approximation , truncation_hw , truncation_ph ,
						 n_holes_max   , n_scat_max   , E_max_hw  ,
						 n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						 n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , false , prot_Y_data , neut_Y_data);

      M_plus_one_eigenvector_calc_stored (is_there_cout , is_there_cout_detailed , input_data , dimensions_good_J , PSI_qn , PSI_helper_M , PSI_full);
    }

  for (int iM = iM_deb ; iM > iM_smallest_positive ; iM--)
    {
      const double M = iM - M_max;

      class GSM_vector_helper_class PSI_helper_M(is_it_MPI_parallelized_local ,space , inter , is_it_pole_approximation , truncation_hw , truncation_ph ,
						 n_holes_max   , n_scat_max   , E_max_hw  ,
						 n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						 n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , false , prot_Y_data , neut_Y_data);
 
      M_minus_one_eigenvector_calc_stored (is_there_cout , is_there_cout_detailed , input_data , dimensions_good_J , PSI_qn , PSI_helper_M , PSI_full);
    }
      
  for (int iM = iM_smallest_positive_non_zero ; iM <= iM_J ; iM++)
    {  
      const double M = iM - M_max;

      class GSM_vector_helper_class PSI_helper_M(is_it_MPI_parallelized_local , space , inter , is_it_pole_approximation , truncation_hw , truncation_ph ,
						 n_holes_max   , n_scat_max   , E_max_hw  ,
						 n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						 n_holes_max_n , n_scat_max_n , En_max_hw , BP ,  M , false , prot_Y_data , neut_Y_data);
      
      class GSM_vector_helper_class PSI_helper_M_TRS(is_it_MPI_parallelized_local , space , inter , is_it_pole_approximation , truncation_hw , truncation_ph ,
						     n_holes_max   , n_scat_max   , E_max_hw  ,
						     n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						     n_holes_max_n , n_scat_max_n , En_max_hw , BP , -M , false , prot_Y_data , neut_Y_data);

      class GSM_vector PSI_M(PSI_helper_M);

      PSI_M.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);

      const class TRS_class TRS(PSI_helper_M , PSI_helper_M_TRS);
 
      const class GSM_vector PSI_M_TRS = minus_one_pow (J - M)*TRS (PSI_M);

      PSI_M_TRS.space_dimension_SDs_components_eigenvector_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);
    }
  
  if ((iM_smallest_positive_non_zero <= iM_J) && (THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << "GSM eigenvector " << J_Pi_vector_index_string (BP , J , vector_index) << " (M<0) calculated and stored" << endl << endl;
}






// Calculation of a GSM eigenvector of fixed quantum numbers: starting vector and full calculation
// -----------------------------------------------------------------------------------------------
// The starting GSM eigenvector is always calculated at pole approximation level with the Lanczos method.
// One does either a full diagonalization or a partial diagonalization as in HO shell model.
// The GSM eigenvector of the full space is calculated either with the Lanczos or the Jacobi-Davidson method.
//
// If one calculates only the proportion of non-zero NBMEs, no pole approximation calculation is done and one goes directly to full space.
//
// If a pivot from a file is used for the GSM eigenvector with the Lanczos method, no pole approximation is considered and one starts the full space calculation directly.
// If no pivot from a file is used for the GSM eigenvector, the pole approximation is necessary for the overlap method in all cases.
//
// If a pivot from a file is used for the GSM eigenvector with the Jacobi-Davidson method, the pole approximation is still considered.
// Indeed, the approximate Hamiltonian to invert in the Jacobi-Davidson method has to be defined from pole approximation (see GSM_Davidson.cpp).
//
// When one goes from an eigenset to another with BP, M changing, classes are reallocated as GSM matrices and vectors explicitly depend on BP, M in M-scheme.
// These classes are: Hamiltonian, J^2 operator, GSM eigenvector class, GSM vector class of M+1 total angular momentum projection for L^2[CM] application,
// array of GSM vector classes for orthogonalization, helper classes for GSM eigenvector class and GSM vector class with M+1,
// arrays of jumps betzeen Slater determinants (see GSM_configuration_SD_in_space_one_jump.cpp).
// If BP, M remain the same and only J changes, one uses the same classes as before for the same reason, with the J change taken into account in the Hamiltonian.
//
// If there are no eigenstates for a given J-Pi space, nothing is done.
//
// All eigenstates of a fixed J-Pi space are calculated at the same time with the Lanczos method, whereas there are calculated one by one with the Jacobi-Davidson method.
//
// All eigenvectors |Psi>^J_M, with |M| <= J, are calculated at the end of the calculation with previous routines.
//
// M+1 GSM vectors are never used at the same time as M GSM vectors. Hence, one uses virtual allocation (see GSM_vector.cpp) for M+1 GSM vectors to save memory.


void eigenvector_functions::find_eigenvector_starting_point (
							     const bool vectors_write , 
							     const class input_data_str &input_data , 
							     const unsigned int J_number , 
							     const class array<unsigned long int> &dimensions_good_J_pole_approximation , 
							     const double J , 
							     const class H_class &H , 
							     const class J2_class &J2 , 
							     const unsigned int eigenset_index , 
							     const unsigned int eigenset_vectors_number , 
							     class array<TYPE> &E_subspace_tab , 
							     class array<class GSM_vector_helper_class> &GSM_vector_helper_subspace_tab , 
							     class array<class GSM_vector> &eigenvector_subspace_tab , 
							     class GSM_vector &V ,  
							     class GSM_vector &Vstore ,
							     class array<class GSM_vector> &PSI_M_tab , 
							     class array<class GSM_vector> &PSI_Mp1_tab , 
							     class array<class GSM_vector> &V_tab , 
							     class array<class GSM_vector> &Vp_tab ,
							     class array<class correlated_state_str> &PSI_qn_tab)
{
  const bool print_detailed_information = input_data.get_print_detailed_information ();
  
  const bool J_projected = input_data.get_J_projected ();
  
  const class GSM_vector &PSI0_M = PSI_M_tab(0);

  const class GSM_vector_helper_class &PSI_helper_M = PSI0_M.get_GSM_vector_helper ();

  const int two_J = make_int (2.0*J);

  const int J_index = (two_J%2 == 0) ? (make_int (J)) : (make_int (J - 0.5));

  const unsigned int BP = PSI_helper_M.get_BP ();

  const unsigned int workspace_max_dimension = input_data.get_workspace_max_dimension ();

  const unsigned int dimension_good_J_or_M = (J_projected) ? (dimensions_good_J_pole_approximation(BP , 0 , J_index)) : (PSI_helper_M.get_total_space_dimension ());

  const unsigned int workspace_dimension = (dimension_good_J_or_M <= workspace_max_dimension) ? (dimension_good_J_or_M) : (workspace_max_dimension);

  const bool is_it_Lanczos = input_data.get_is_it_Lanczos ();
  
  class GSM_vector dummy_PSI_full;
  
  if (workspace_dimension == 0)
    {
      if (THIS_PROCESS == MASTER_PROCESS) cout << "dimension = 0 : nothing done" << endl << endl;
    }
  else
    Lanczos_GSM_not_disk::Hamiltonian::iterative_diagonalization_lowest_states (print_detailed_information , true , vectors_write , input_data , !is_it_Lanczos , J_number , dimension_good_J_or_M , workspace_dimension ,
										J , H , J2 , eigenset_index , eigenset_vectors_number ,
										E_subspace_tab , GSM_vector_helper_subspace_tab , eigenvector_subspace_tab ,
										dummy_PSI_full , V , Vstore , PSI_M_tab , PSI_Mp1_tab , V_tab , Vp_tab , PSI_qn_tab);
}













void eigenvector_functions::find_eigenvector (
					      const bool is_there_cout , 
					      const class input_data_str &input_data , 
					      const class GSM_vector_helper_class &PSI_helper_M , 
					      const unsigned int J_number , 
					      const class array<unsigned long int> &dimensions_good_J_pole_approximation , 
					      const class array<unsigned long int> &dimensions_good_J , 
					      const double J ,
					      const class H_class &H , 
					      const class J2_class &J2 , 
					      const unsigned int eigenset_index , 
					      const unsigned int eigenset_vectors_number , 
					      const class array<TYPE> &E_subspace_tab , 
					      const class array<class GSM_vector> &eigenvector_subspace_tab , 
					      class GSM_vector &PSI_full ,
					      class GSM_vector &V ,
					      class GSM_vector &Vstore ,
					      class array<class GSM_vector> &PSI_M_tab , 
					      class array<class GSM_vector> &PSI_Mp1_tab , 
					      class array<class GSM_vector> &V_tab , 
					      class array<class GSM_vector> &HV_tab , 
					      class array<class GSM_vector> &Vp_tab ,
					      class array<class GSM_vector> &GSM_work_vectors , 
					      class array<class correlated_state_str> &PSI_qn_tab)
{
  class baryons_data &prot_Y_data = PSI_helper_M.get_prot_Y_data ();
  class baryons_data &neut_Y_data = PSI_helper_M.get_neut_Y_data ();

  const bool is_it_Lanczos = input_data.get_is_it_Lanczos ();

  const bool J_projected = input_data.get_J_projected ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();

  const bool are_GSM_vectors_stored_on_disk = input_data.get_are_GSM_vectors_stored_on_disk ();
  
  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const int two_J = make_int (2.0*J);

  const int J_index = (two_J%2 == 0) ? (make_int (J)) : (make_int (J - 0.5));

  const int n_scat_max = input_data.get_n_scat_max ();

  const unsigned int BP = PSI_helper_M.get_BP ();

  const double M = PSI_helper_M.get_M ();

  const unsigned int workspace_max_dimension = input_data.get_workspace_max_dimension ();

  const unsigned int dimension_good_J_or_M = (J_projected) ? (dimensions_good_J(BP , n_scat_max , J_index)) : (PSI_helper_M.get_total_space_dimension ());

  const unsigned int workspace_dimension = (dimension_good_J_or_M <= workspace_max_dimension) ? (dimension_good_J_or_M) : (workspace_max_dimension);

  const unsigned int subspace_dimension = dimensions_good_J_pole_approximation(BP , 0 , J_index);

  const int Ep_max_hw_pole_approximation = prot_Y_data.get_E_max_hw_pole_approximation ();
  const int En_max_hw_pole_approximation = neut_Y_data.get_E_max_hw_pole_approximation ();

  const int E_max_hw_pole_approximation = input_data.get_E_max_hw_pole_approximation ();

  const int n_holes_max_p_pole_approximation = prot_Y_data.get_n_holes_max_pole_approximation ();
  const int n_holes_max_n_pole_approximation = neut_Y_data.get_n_holes_max_pole_approximation ();

  const int n_holes_max_pole_approximation = input_data.get_n_holes_max_pole_approximation ();
  
  if (workspace_dimension == 0)
    {
      if (THIS_PROCESS == MASTER_PROCESS) cout << "dimension = 0 : nothing done" << endl << endl;
    }	
  else
    {
      if (is_it_Lanczos)
	{
	  const bool full_space_diagonalization = input_data.get_all_states_calculated ();

	  class array<TYPE> dummy_array_TYPE;

	  class array<class GSM_vector> dummy_array_GSM_vector;

	  class array<class GSM_vector_helper_class> dummy_array_GSM_vector_helper;
	  
	  if (are_GSM_vectors_stored_on_disk)	      
	    Lanczos_GSM_disk::Hamiltonian::iterative_diagonalization_lowest_states (is_there_cout , false , true , input_data , full_space_diagonalization , J_number , dimension_good_J_or_M , workspace_dimension ,
										    J , H , J2 , eigenset_index , eigenset_vectors_number ,
										    dummy_array_TYPE , dummy_array_GSM_vector_helper , dummy_array_GSM_vector ,
										    PSI_full , V , Vstore , PSI_M_tab , PSI_Mp1_tab , GSM_work_vectors , PSI_qn_tab);
	  else	      
	    Lanczos_GSM_not_disk::Hamiltonian::iterative_diagonalization_lowest_states (is_there_cout , false , true , input_data , full_space_diagonalization , J_number , dimension_good_J_or_M , workspace_dimension ,
											J , H , J2 , eigenset_index , eigenset_vectors_number ,
											dummy_array_TYPE , dummy_array_GSM_vector_helper , dummy_array_GSM_vector ,
											PSI_full , V , Vstore , PSI_M_tab , PSI_Mp1_tab , V_tab , Vp_tab , PSI_qn_tab);
	}
      else
	{
	  class GSM_vector_helper_class PSI_subspace_helper(false , space , inter , true , truncation_hw , true ,
							    n_holes_max_pole_approximation   , 0 , E_max_hw_pole_approximation  ,
							    n_holes_max_p_pole_approximation , 0 , Ep_max_hw_pole_approximation ,
							    n_holes_max_n_pole_approximation , 0 , En_max_hw_pole_approximation , BP , M , true , prot_Y_data , neut_Y_data);
  
	  class GSM_vector PSI_subspace(PSI_subspace_helper);

	  class GSM_vector H_app_minus_E_inverse_PSI_subspace(PSI_subspace_helper);
	 
	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {
	      class correlated_state_str &PSI_qn = PSI_qn_tab(eigenset_index , i);
  
	      if (are_GSM_vectors_stored_on_disk)
		Davidson_GSM_disk::iterative_diagonalization_largest_overlap (is_there_cout , J_number , dimension_good_J_or_M , input_data , workspace_dimension , H , J2 , subspace_dimension , 
									      E_subspace_tab , eigenvector_subspace_tab , PSI_full , PSI_subspace , H_app_minus_E_inverse_PSI_subspace ,
									      V , Vstore , PSI_M_tab , PSI_Mp1_tab , GSM_work_vectors , PSI_qn);
	      else
		Davidson_GSM_not_disk::iterative_diagonalization_largest_overlap (is_there_cout , J_number , dimension_good_J_or_M , input_data , workspace_dimension , H , J2 , subspace_dimension , 
										  E_subspace_tab , eigenvector_subspace_tab , PSI_full , PSI_subspace , H_app_minus_E_inverse_PSI_subspace ,
										  V , Vstore , PSI_M_tab , PSI_Mp1_tab , V_tab , HV_tab , Vp_tab , PSI_qn);
	    }
	}
    }
}




void eigenvector_functions::pole_approximation_eigenvectors_calc (
								  const bool is_there_cout , 
								  const class array<unsigned long int> &total_space_dimensions_good_J_pole_approximation , 
								  const class array<double> &M_table , 
								  const class TBMEs_class &TBMEs_pn ,  
								  const class TBMEs_class &TBMEs_cv , 
								  const class input_data_str &input_data , 
								  const class array<class correlated_state_str> &PSI_qn_tab ,
								  class baryons_data &prot_Y_data , 
								  class baryons_data &neut_Y_data ,  
								  class array<TYPE> &E_subspace_tab , 
								  class array<class GSM_vector_helper_class> &GSM_vector_helper_subspace_tab , 
								  class array<class GSM_vector> &eigenvector_subspace_tab)
{
  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const bool J_projected = input_data.get_J_projected ();
  
  const bool print_detailed_information = input_data.get_print_detailed_information ();

  const bool is_there_cout_detailed = (is_there_cout && print_detailed_information);

  if (is_there_cout_detailed && (THIS_PROCESS == MASTER_PROCESS))
    {
      cout << endl << "Pole approximation" << endl;
      cout <<         "------------------" << endl << endl;
    }
  
  const bool non_zero_NBMEs_proportion_only = input_data.get_non_zero_NBMEs_proportion_only ();

  const bool is_cv_possible = input_data.get_is_cv_possible ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  
  const bool is_there_disk_storage_eigenvectors_all_M = input_data.get_is_there_disk_storage_eigenvectors_all_M ();
  
  const int Ep_max_hw_pole_approximation = prot_Y_data.get_E_max_hw_pole_approximation ();
  const int En_max_hw_pole_approximation = neut_Y_data.get_E_max_hw_pole_approximation ();

  const int E_max_hw_pole_approximation = input_data.get_E_max_hw_pole_approximation ();
    
  const int n_holes_max_p_pole_approximation = prot_Y_data.get_n_holes_max_pole_approximation ();
  const int n_holes_max_n_pole_approximation = neut_Y_data.get_n_holes_max_pole_approximation ();

  const int n_holes_max_pole_approximation = input_data.get_n_holes_max_pole_approximation ();
  
  const class array<unsigned int> &BP_eigenset_tab = input_data.get_BP_eigenset_tab ();

  const class array<double> &J_eigenset_tab = input_data.get_J_eigenset_tab ();

  const bool is_it_Lanczos = input_data.get_is_it_Lanczos ();
  
  const bool initial_pivot_from_file = input_data.get_initial_pivot_from_file ();

  const bool vectors_write = !initial_pivot_from_file;
    
  const bool is_it_Lowdin = input_data.get_is_it_Lowdin ();
  
  const unsigned int eigensets_number = input_data.get_eigensets_number ();
  
  const bool T2_CM_operators_calculated = input_data.get_T2_CM_operators_calculated ();
  
  if (!non_zero_NBMEs_proportion_only && (!initial_pivot_from_file || !is_it_Lanczos))
    {
      const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

      const unsigned int eigenset_vectors_number_max = eigenset_vectors_number_tab.max ();

      const unsigned long int total_space_dimension_Mmin_first_eigenset_pole_approximation = total_space_dimension_M_calc (space , truncation_hw , true ,
															   n_holes_max_p_pole_approximation , 0 , Ep_max_hw_pole_approximation ,
															   n_holes_max_n_pole_approximation , 0 , En_max_hw_pole_approximation ,
															   n_holes_max_pole_approximation   , 0 , E_max_hw_pole_approximation  , prot_Y_data , neut_Y_data , BP_eigenset_tab(0) , M_table(0));
  
      const unsigned long int total_space_dimension_Mmin_second_eigenset_pole_approximation = (eigensets_number >= 2) ? (total_space_dimension_M_calc (space , truncation_hw , true ,
																		       n_holes_max_p_pole_approximation , 0 , Ep_max_hw_pole_approximation ,
																		       n_holes_max_n_pole_approximation , 0 , En_max_hw_pole_approximation ,
																		       n_holes_max_pole_approximation   , 0 , E_max_hw_pole_approximation  ,
																		       prot_Y_data , neut_Y_data , BP_eigenset_tab(1) , M_table(1))) : (0);
  
      const unsigned long int total_space_dimension_Mmin_tab[] = {total_space_dimension_Mmin_first_eigenset_pole_approximation , total_space_dimension_Mmin_second_eigenset_pole_approximation};
    
      const unsigned int total_space_dimension_good_J_pole_approximation_max = (J_projected) ? (total_space_dimensions_good_J_pole_approximation.max ()) : (max (total_space_dimension_Mmin_tab[0] , total_space_dimension_Mmin_tab[1]));
  
      const unsigned int vectors_to_find_number_max = max (eigenset_vectors_number_max , total_space_dimension_good_J_pole_approximation_max);
      
      const int J_number_max = J_number_max_calc (space , prot_Y_data , neut_Y_data , 0 , total_space_dimensions_good_J_pole_approximation);
  
      const int J_number_max_plus_one = J_number_max + 1;
  
      class array<class correlated_state_str> PSI_qn_pole_approximation_tab(eigensets_number , vectors_to_find_number_max);

      class array<bool> is_it_new_J_Pi_tab(eigensets_number);

      class array<bool> is_it_new_BP_M_tab(eigensets_number);

      class array<unsigned int> eigenset_vectors_indices(eigensets_number , vectors_to_find_number_max);

      eigensets_vectors_indices_calc (true , prot_Y_data , neut_Y_data , total_space_dimensions_good_J_pole_approximation , input_data , eigenset_vectors_indices);

      changing_eigensets_bool_tables_calc (input_data , M_table , is_it_new_J_Pi_tab , is_it_new_BP_M_tab);
      
      class GSM_vector_helper_class PSI_helper_M;
      class GSM_vector_helper_class PSI_helper_Mp1;

      class H_class H;

      class Jpm_class Jplus;
      class Jpm_class Jminus;

      class J2_class J2;

      class array<class GSM_vector> PSI_M_tab(2);
      class array<class GSM_vector> PSI_Mp1_tab(3);

      class array<class GSM_vector> V_tab(total_space_dimension_good_J_pole_approximation_max);      

      class array<class GSM_vector> Vp_tab(J_number_max_plus_one);
  
      class array<class GSM_vector> GSM_work_vectors(NUMBER_OF_THREADS);
  
      class GSM_vector V;
      
      class GSM_vector Vstore;

      class GSM_vector dummy_PSI_full;
      
      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{	  
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  const unsigned int BP = BP_eigenset_tab(eigenset_index);
	  
	  const double J = J_eigenset_tab(eigenset_index);

	  const double M = M_table(eigenset_index);

	  const double Mp1 = M + 1.0;

	  const int two_J = make_int (2.0*J);

	  const unsigned int J_index = (two_J%2 == 0) ? (make_int (J)) : (make_int (J - 0.5));

	  const unsigned int space_dimension = (J_projected) ? (total_space_dimensions_good_J_pole_approximation(BP , 0 , J_index)) : (total_space_dimension_Mmin_tab[eigenset_index]);

	  const unsigned int J_number = J_number_calc (space , prot_Y_data , neut_Y_data , BP , 0 , M , total_space_dimensions_good_J_pole_approximation);
      
	  //Check if the number of vectors with J fixed is not larger than the dimension of the pole space with fixed J.

	  if (space_dimension < eigenset_vectors_number)
	    { 
	      const string too_many_vectors_str = "Too many vectors " + J_Pi_string (BP , J) + " in pole space.";

	      const string comparison_str = "Demanded vectors:" + make_string<unsigned int> (eigenset_vectors_number) + " , pole space J-dimension:" + make_string<unsigned int> (space_dimension);

	      const string error_str = too_many_vectors_str + comparison_str;

	      error_message_print_abort (error_str);
	    }

	  if (is_it_new_J_Pi_tab(eigenset_index))
	    {
	      if (is_it_new_BP_M_tab(eigenset_index))
		{
		  H.deallocate ();

		  J2.deallocate ();

		  Jplus.deallocate ();
		  
		  Jminus.deallocate ();

		  V.deallocate ();

		  Vstore.deallocate ();
		  
		  V_tab.deallocate_object_elements ();
		  
		  Vp_tab.deallocate_object_elements ();
		  
		  GSM_work_vectors.deallocate_object_elements ();

		  PSI_M_tab.deallocate_object_elements ();

		  PSI_Mp1_tab.deallocate_object_elements ();
		  
		  PSI_helper_M.deallocate ();
		  PSI_helper_Mp1.deallocate ();
		   
		  PSI_helper_M.allocate   (false , space , inter , true , truncation_hw , true ,
					   n_holes_max_pole_approximation   , 0 , E_max_hw_pole_approximation  ,
					   n_holes_max_p_pole_approximation , 0 , Ep_max_hw_pole_approximation ,
					   n_holes_max_n_pole_approximation , 0 , En_max_hw_pole_approximation , BP , M , J_projected , prot_Y_data , neut_Y_data);
		  
		  PSI_helper_Mp1.allocate (false , space , inter , true , truncation_hw , true ,
					   n_holes_max_pole_approximation   , 0 , E_max_hw_pole_approximation  ,
					   n_holes_max_p_pole_approximation , 0 , Ep_max_hw_pole_approximation ,
					   n_holes_max_n_pole_approximation , 0 , En_max_hw_pole_approximation , BP , Mp1 , J_projected , prot_Y_data , neut_Y_data);
		  
		  V.allocate (PSI_helper_M);

		  Vstore.allocate (PSI_helper_M);
		  
		  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) GSM_work_vectors(i).allocate (PSI_helper_M);
		  
		  for (unsigned int i = 0 ; i < 2 ; i++) PSI_M_tab(i).allocate (PSI_helper_M);

		  for (unsigned int i = 0 ; i < 2 ; i++) PSI_Mp1_tab(i).virtual_allocate (PSI_helper_Mp1 , PSI_M_tab(i));

		  PSI_Mp1_tab(2).virtual_allocate (PSI_helper_Mp1 , GSM_work_vectors(0));
		  
		  class GSM_vector &PSI0_M = PSI_M_tab(0);
		  class GSM_vector &PSI1_M = PSI_M_tab(1);

		  class GSM_vector &PSI0_Mp1 = PSI_Mp1_tab(0);
		  class GSM_vector &PSI1_Mp1 = PSI_Mp1_tab(1);
		  class GSM_vector &PSI2_Mp1 = PSI_Mp1_tab(2);

		  if (T2_CM_operators_calculated)
		    configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , false , false , true , true , PSI_helper_M , PSI_helper_M , PSI_helper_Mp1 , prot_Y_data , neut_Y_data);  

		  H.allocate  (false , false , FULL_STORAGE , ON_THE_FLY , ON_THE_FLY , true , false , false , TBMEs_pn , TBMEs_cv , true , true , true , true , true , is_cv_possible , 
			       J , PSI_helper_M , dummy_PSI_full , PSI0_M , PSI1_M , GSM_work_vectors);

		  Jplus.allocate  (false , false ,  1 , FULL_STORAGE , true , PSI_helper_M   , PSI_helper_Mp1 , dummy_PSI_full , PSI0_Mp1 , PSI1_Mp1);
		  Jminus.allocate (false , false , -1 , FULL_STORAGE , true , PSI_helper_Mp1 , PSI_helper_M   , dummy_PSI_full , PSI0_M   , PSI1_M);
		  
		  J2.allocate (Jplus , Jminus , PSI2_Mp1);
 
		  if (!is_it_Lowdin)
		    {		      
		      for (unsigned int i = 0 ; i < J_number ; i++) Vp_tab(i).allocate (PSI_helper_M);
		    }
		  
		  if (is_there_cout_detailed) diagonalization_memory_used_print (false , true , false , PSI_helper_M , H , V , Vstore , PSI_M_tab , GSM_work_vectors , Vp_tab , space_dimension);
		}
	      else
		H.set_J (J);
	    }
	  
	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {
	      const class correlated_state_str &PSI_qn = PSI_qn_tab(eigenset_index , i);

	      const unsigned int eigenvector_index = eigenset_vectors_indices(eigenset_index , i);

	      class correlated_state_str &PSI_qn_pole_approximation = PSI_qn_pole_approximation_tab(eigenset_index , i);

	      PSI_qn_pole_approximation.initialize (
						    PSI_qn.get_Z () ,
						    PSI_qn.get_N () ,
						    PSI_qn.get_BP () ,
						    PSI_qn.get_S () ,
						    PSI_qn.get_J () ,
						    eigenvector_index ,
						    PSI_qn.get_E () ,
						    PSI_qn.get_weight () ,
						    PSI_qn.get_experimental_energy () ,
						    PSI_qn.get_energy_error () ,
						    PSI_qn.get_is_it_optimization_reference_state ());
	    }

	  find_eigenvector_starting_point (vectors_write , input_data , J_number , total_space_dimensions_good_J_pole_approximation , 
					   J , H , J2 , eigenset_index , eigenset_vectors_number ,
					   E_subspace_tab , GSM_vector_helper_subspace_tab , eigenvector_subspace_tab ,
					   V , Vstore , PSI_M_tab , PSI_Mp1_tab , V_tab , Vp_tab , PSI_qn_pole_approximation_tab);
	}

      if (is_there_cout && (THIS_PROCESS == MASTER_PROCESS))
	{
	  cout << endl << "Pole approximation spectrum" << endl;
	  cout <<         "---------------------------" << endl << endl;
      	  
	  eigenvectors_sorted_printed (!J_projected , PSI_qn_pole_approximation_tab);
	}
      
      H.deallocate ();

      J2.deallocate ();

      Jplus.deallocate ();
      Jminus.deallocate ();

      V_tab.deallocate ();
      
      GSM_work_vectors.deallocate ();

      V.deallocate ();

      Vp_tab.deallocate ();
  
      Vstore.deallocate ();

      PSI_M_tab.deallocate ();

      PSI_Mp1_tab.deallocate ();

      PSI_helper_M.deallocate ();
      PSI_helper_Mp1.deallocate ();

      prot_Y_data.one_jump_tables_Jpm_in_to_out_deallocate ();
      neut_Y_data.one_jump_tables_Jpm_in_to_out_deallocate ();
       
      prot_Y_data.one_jump_tables_in_to_out_deallocate ();
      neut_Y_data.one_jump_tables_in_to_out_deallocate ();
  
      if (J_projected && is_there_disk_storage_eigenvectors_all_M)
	{
	  for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	    {
	      const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	      const unsigned int BP = BP_eigenset_tab(eigenset_index);

	      const double M = M_table(eigenset_index);
      
	      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
		{
		  class GSM_vector_helper_class PSI_helper_M_eigenset(false , space , inter , true , truncation_hw , true ,
								      n_holes_max_pole_approximation   , 0 , E_max_hw_pole_approximation  ,
								      n_holes_max_p_pole_approximation , 0 , Ep_max_hw_pole_approximation ,
								      n_holes_max_n_pole_approximation , 0 , En_max_hw_pole_approximation , BP , M , true , prot_Y_data , neut_Y_data);
	  
		  const class correlated_state_str &PSI_qn = PSI_qn_tab(eigenset_index , i);
	  
		  eigenvector_stored_with_all_M_projections (is_there_cout , is_there_cout_detailed , input_data , total_space_dimensions_good_J_pole_approximation , PSI_qn , PSI_helper_M_eigenset , dummy_PSI_full);
		}
	    }
	}
    }
}








void eigenvector_functions::full_space_eigenvectors_calc (
							  const bool is_there_cout , 
							  const class array<unsigned long int> &total_space_dimensions_good_J_pole_approximation , 
							  const class array<unsigned long int> &total_space_dimensions_good_J , 
							  const class array<double> &M_table , 
							  const class TBMEs_class &TBMEs_pn , 
							  const class TBMEs_class &TBMEs_cv , 
							  const class input_data_str &input_data , 
							  const class array<TYPE> &E_subspace_tab , 
							  const class array<class GSM_vector> &eigenvector_subspace_tab ,		   
							  class baryons_data &prot_Y_data , 
							  class baryons_data &neut_Y_data ,  
							  class array<class correlated_state_str> &PSI_qn_tab , 
							  class GSM_vector &PSI_full)	

{
  if (is_there_cout && (THIS_PROCESS == MASTER_PROCESS))
    {
      cout << endl << "Full space" << endl;
      cout <<         "----------" << endl << endl;
    }
  
  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const bool J_projected = input_data.get_J_projected ();
  
  const bool print_detailed_information = input_data.get_print_detailed_information ();

  const bool is_there_cout_detailed = (is_there_cout && print_detailed_information);
  
  const bool non_zero_NBMEs_proportion_only = input_data.get_non_zero_NBMEs_proportion_only ();

  const bool is_there_disk_storage_eigenvectors_all_M = input_data.get_is_there_disk_storage_eigenvectors_all_M ();

  const bool is_cv_possible = input_data.get_is_cv_possible ();
    
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

  const class array<unsigned int> &BP_eigenset_tab = input_data.get_BP_eigenset_tab ();

  const class array<double> &J_eigenset_tab = input_data.get_J_eigenset_tab ();

  const bool is_it_Lanczos = input_data.get_is_it_Lanczos ();

  const bool all_states_calculated = input_data.get_all_states_calculated ();
  
  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage (); 

  const enum storage_type one_jumps_pn_two_jumps_cv_storage = input_data.get_one_jumps_pn_two_jumps_cv_storage ();
  
  const unsigned int eigensets_number = input_data.get_eigensets_number ();
    
  const bool T2_CM_operators_calculated = input_data.get_T2_CM_operators_calculated ();

  const bool is_it_on_the_fly = (Hamiltonian_storage == ON_THE_FLY);
  
  const bool is_it_full_or_partial_storage = is_it_full_or_partial_storage_determine (Hamiltonian_storage);
    
  const bool configuration_SD_one_jump_tables_to_calculate_for_operators = (T2_CM_operators_calculated || is_it_on_the_fly);
  
  const bool configuration_SD_one_jump_tables_to_recalculate_for_matrices = is_it_full_or_partial_storage;
      
  const bool configuration_SD_one_jump_pn_tables_to_calculate = (!is_it_full_or_partial_storage && (space == PROT_NEUT_Y));
  
  const bool is_it_cluster_CM_HO_basis_calculation = input_data.get_is_it_cluster_CM_HO_basis_calculation ();
  
  const bool are_GSM_vectors_stored_on_disk = input_data.get_are_GSM_vectors_stored_on_disk ();
  
  const bool is_it_Lowdin = input_data.get_is_it_Lowdin ();
  
  const int n_scat_max_p = (!is_it_cluster_CM_HO_basis_calculation) ? (prot_Y_data.get_n_scat_max ()) : (0);
  const int n_scat_max_n = (!is_it_cluster_CM_HO_basis_calculation) ? (neut_Y_data.get_n_scat_max ()) : (0);

  const int n_scat_max = (!is_it_cluster_CM_HO_basis_calculation) ? (input_data.get_n_scat_max ()) : (0);
  
  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();
  
  const int n_holes_max_p = (!is_it_cluster_CM_HO_basis_calculation) ? (prot_Y_data.get_n_holes_max ()) : (0);
  const int n_holes_max_n = (!is_it_cluster_CM_HO_basis_calculation) ? (neut_Y_data.get_n_holes_max ()) : (0);
  
  const int n_holes_max = (!is_it_cluster_CM_HO_basis_calculation) ? (input_data.get_n_holes_max ()) : (0);
  		  
  const bool is_it_Davidson = !is_it_Lanczos;
  
  const unsigned int total_space_dimension_Mmin_first_eigenset = total_space_dimension_M_calc (space , truncation_hw , truncation_ph ,
											       n_holes_max_p , n_scat_max_p , Ep_max_hw ,
											       n_holes_max_n , n_scat_max_n , En_max_hw ,
											       n_holes_max   , n_scat_max   , E_max_hw  , prot_Y_data , neut_Y_data , BP_eigenset_tab(0) , M_table(0));
  
  const unsigned int total_space_dimension_Mmin_second_eigenset = (eigensets_number >= 2) ? (total_space_dimension_M_calc (space , truncation_hw , truncation_ph ,
															   n_holes_max_p , n_scat_max_p , Ep_max_hw ,
															   n_holes_max_n , n_scat_max_n , En_max_hw ,
															   n_holes_max   , n_scat_max   , E_max_hw  , prot_Y_data , neut_Y_data , BP_eigenset_tab(1) , M_table(1))) : (0);
  
  const unsigned long int dimension_good_J_or_M_max = (J_projected) ? (total_space_dimensions_good_J.max ()) : (max (total_space_dimension_Mmin_first_eigenset , total_space_dimension_Mmin_second_eigenset));
  
  const unsigned int workspace_max_dimension = input_data.get_workspace_max_dimension ();
  
  const unsigned int workspace_dimension_max = (dimension_good_J_or_M_max <= workspace_max_dimension) ? (dimension_good_J_or_M_max) : (workspace_max_dimension);
        
  const int J_number_max = J_number_max_calc (space , prot_Y_data , neut_Y_data , n_scat_max , total_space_dimensions_good_J);
  
  const int J_number_max_plus_one = J_number_max + 1;
  
  class GSM_vector_helper_class PSI_helper_M;
  class GSM_vector_helper_class PSI_helper_M_full;
  
  class GSM_vector_helper_class PSI_helper_Mp1;
  class GSM_vector_helper_class PSI_helper_Mp1_full;
  
  class H_class H;

  class Jpm_class Jplus;
  class Jpm_class Jminus;

  class J2_class J2;

  class array<class GSM_vector> PSI_M_tab(2);
  class array<class GSM_vector> PSI_Mp1_tab(3);

  class array<class GSM_vector>  V_tab(workspace_dimension_max);
  class array<class GSM_vector> HV_tab(workspace_dimension_max);

  class array<class GSM_vector> Vp_tab(J_number_max_plus_one);
  
  class array<class GSM_vector> GSM_work_vectors(NUMBER_OF_THREADS);
  
  class GSM_vector V;
  
  class GSM_vector Vstore;
      
  const unsigned int eigenset_vectors_number_max = eigenset_vectors_number_tab.max ();

  const unsigned int vectors_to_find_number_max = (all_states_calculated) ? (dimension_good_J_or_M_max) : (eigenset_vectors_number_max);

  class array<bool> is_it_new_J_Pi_tab(eigensets_number);

  class array<bool> is_it_new_BP_M_tab(eigensets_number);

  class array<unsigned int> eigenset_vectors_indices(eigensets_number , vectors_to_find_number_max);

  eigensets_vectors_indices_calc (false , prot_Y_data , neut_Y_data , total_space_dimensions_good_J , input_data , eigenset_vectors_indices);

  changing_eigensets_bool_tables_calc (input_data , M_table , is_it_new_J_Pi_tab , is_it_new_BP_M_tab);

  for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
    {
      const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);
      
      const unsigned int BP = BP_eigenset_tab(eigenset_index);
	  
      const double J = J_eigenset_tab(eigenset_index);

      const double M = M_table(eigenset_index);

      const double Mp1 = M + 1.0;

      const int two_J = make_int (2.0*J);

      const unsigned int J_index = (two_J%2 == 0) ? (make_int (J)) : (make_int (J - 0.5));

      const unsigned long int dimension_good_J_or_M = (J_projected) ? (total_space_dimensions_good_J(BP , n_scat_max , J_index)) : (total_space_dimension_M_calc (space , truncation_hw , truncation_ph ,
																				  n_holes_max_p , n_scat_max_p , Ep_max_hw ,
																				  n_holes_max_n , n_scat_max_n , En_max_hw ,
																				  n_holes_max   , n_scat_max   , E_max_hw  , prot_Y_data , neut_Y_data , BP , M));
      
      const unsigned int vectors_to_find_number = (all_states_calculated) ? (dimension_good_J_or_M) : (eigenset_vectors_number);

      const unsigned int workspace_dimension = (dimension_good_J_or_M <= workspace_max_dimension) ? (dimension_good_J_or_M) : (workspace_max_dimension);

      const unsigned int J_number = J_number_calc (space , prot_Y_data , neut_Y_data , BP , n_scat_max , M , total_space_dimensions_good_J);
      
      if (all_states_calculated && (workspace_dimension < dimension_good_J_or_M)) error_message_print_abort ("Not enough Lanczos vectors for J-Pi = " + J_Pi_string (BP , J) + " for full diagonalization");
      
      if ((THIS_PROCESS == MASTER_PROCESS) && non_zero_NBMEs_proportion_only)
	{
	  cout << endl << endl << "Non zeros NBMEs proportion for " << J_Pi_string (BP , J) << endl;
	  cout <<                 "---------------------------------------" << endl;
	  
	  if (!is_it_new_BP_M_tab(eigenset_index)) cout << "See previous eigenset (M = " + M_string (M) + ")" << endl;
	}
      
      if (is_it_new_J_Pi_tab(eigenset_index))
	{
	  if (is_it_new_BP_M_tab(eigenset_index))
	    {
	      H.deallocate ();

	      J2.deallocate ();

	      Jplus.deallocate ();
	      
	      Jminus.deallocate ();
	      
	      V.deallocate ();
	      	      
	      Vstore.deallocate ();
	      
	      V_tab.deallocate_object_elements ();

	      HV_tab.deallocate_object_elements ();
	      
	      Vp_tab.deallocate_object_elements ();
	      
	      GSM_work_vectors.deallocate_object_elements ();
	      
	      PSI_M_tab.deallocate_object_elements ();
	      PSI_Mp1_tab.deallocate_object_elements ();
	      	      
	      PSI_helper_M.deallocate ();
	      PSI_helper_M_full.deallocate ();

	      PSI_helper_Mp1.deallocate ();
	      PSI_helper_Mp1_full.deallocate ();
  
	      PSI_helper_M.allocate (is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
				     n_holes_max   , n_scat_max   , E_max_hw  ,
				     n_holes_max_p , n_scat_max_p , Ep_max_hw ,
				     n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , J_projected , prot_Y_data , neut_Y_data);
	      
	      PSI_helper_Mp1.allocate (is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
				       n_holes_max   , n_scat_max   , E_max_hw  ,
				       n_holes_max_p , n_scat_max_p , Ep_max_hw ,
				       n_holes_max_n , n_scat_max_n , En_max_hw , BP , Mp1 , J_projected , prot_Y_data , neut_Y_data);
	      		  
	      if (!non_zero_NBMEs_proportion_only)
		{
		  V.allocate (PSI_helper_M);

		  Vstore.allocate (PSI_helper_M);
	      
		  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) GSM_work_vectors(i).allocate (PSI_helper_M);
		      
		  if (!is_it_Lowdin && !are_GSM_vectors_stored_on_disk)
		    {		      
		      for (unsigned int i = 0 ; i < J_number ; i++) Vp_tab(i).allocate (PSI_helper_M);
		    }
	      
		  for (unsigned int i = 0 ; i < 2 ; i++) PSI_M_tab(i).allocate (PSI_helper_M);

		  for (unsigned int i = 0 ; i < 2 ; i++) PSI_Mp1_tab(i).virtual_allocate (PSI_helper_Mp1 , PSI_M_tab(i));

		  PSI_Mp1_tab(2).virtual_allocate (PSI_helper_Mp1 , GSM_work_vectors(0));
		}
	      
	      class GSM_vector &PSI0_M = PSI_M_tab(0);
	      class GSM_vector &PSI1_M = PSI_M_tab(1);

	      class GSM_vector &PSI0_Mp1 = PSI_Mp1_tab(0);
	      class GSM_vector &PSI1_Mp1 = PSI_Mp1_tab(1);
	      class GSM_vector &PSI2_Mp1 = PSI_Mp1_tab(2);
	      
	      if (configuration_SD_one_jump_pn_tables_to_calculate)
		{
		  const class GSM_vector_helper_class dummy_helper;
		  
		  configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (is_there_cout_detailed , false , true , false , false , PSI_helper_M , PSI_helper_M , dummy_helper , prot_Y_data , neut_Y_data);
		}
	      
	      H.allocate (is_there_cout , print_detailed_information , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_two_jumps_cv_storage , configuration_SD_one_jump_tables_to_recalculate_for_matrices , is_it_Davidson ,
			  non_zero_NBMEs_proportion_only , TBMEs_pn , TBMEs_cv , true , true , true , true , true , is_cv_possible , J , PSI_helper_M , PSI_full , PSI0_M , PSI1_M , GSM_work_vectors);
 
	      Jplus.allocate  (is_there_cout , print_detailed_information ,  1 , Hamiltonian_storage , configuration_SD_one_jump_tables_to_recalculate_for_matrices ,
			       PSI_helper_M   , PSI_helper_Mp1 , PSI_full , PSI0_Mp1 , PSI1_Mp1);
	      
	      Jminus.allocate (is_there_cout , print_detailed_information , -1 , Hamiltonian_storage , configuration_SD_one_jump_tables_to_recalculate_for_matrices ,
			       PSI_helper_Mp1 , PSI_helper_M , PSI_full , PSI0_M , PSI1_M);
		  
	      J2.allocate  (Jplus , Jminus , PSI2_Mp1);
	      
	      if (configuration_SD_one_jump_tables_to_calculate_for_operators)
		configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (is_there_cout_detailed , false , false , true , true , PSI_helper_M , PSI_helper_M , PSI_helper_Mp1 , prot_Y_data , neut_Y_data);
	     
#ifdef UseMPI
	      if (is_it_MPI_parallelized) MPI_helper::Barrier ();
#endif
	      
	      if (is_there_cout_detailed && (THIS_PROCESS == MASTER_PROCESS))
		{
		  cout << "---------------------------------------------------------------------------------------------------" << endl;
		  cout << "Configuration and SD jumps tables for Hamiltonian and/or T2/CM observables calculated" << endl;  
		  cout << "---------------------------------------------------------------------------------------------------" << endl;
		}

	      if (is_there_cout) diagonalization_memory_used_print (non_zero_NBMEs_proportion_only , is_it_Lanczos , are_GSM_vectors_stored_on_disk ,
								    PSI_helper_M , H , V , Vstore , PSI_M_tab , GSM_work_vectors , Vp_tab , workspace_dimension);
	    }
	  else
	    H.set_J (J);
	}

      if (!non_zero_NBMEs_proportion_only)
	{
	  for (unsigned int i = 0 ; i < vectors_to_find_number ; i++)
	    {
	      const unsigned int eigenvector_index = eigenset_vectors_indices(eigenset_index , i);

	      class correlated_state_str &PSI_qn = PSI_qn_tab(eigenset_index , i);

	      PSI_qn.initialize (
				 PSI_qn.get_Z () ,
				 PSI_qn.get_N () ,
				 PSI_qn.get_BP () ,
				 PSI_qn.get_S () ,
				 PSI_qn.get_J () ,
				 eigenvector_index ,
				 PSI_qn.get_E () ,
				 PSI_qn.get_weight () ,
				 PSI_qn.get_experimental_energy () ,
				 PSI_qn.get_energy_error () ,
				 PSI_qn.get_is_it_optimization_reference_state ());
	    }
 
	  find_eigenvector (is_there_cout , input_data , PSI_helper_M , J_number , total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J , J , H , J2 , 
			    eigenset_index , vectors_to_find_number , E_subspace_tab , eigenvector_subspace_tab , PSI_full ,
			    V , Vstore , PSI_M_tab , PSI_Mp1_tab , V_tab , HV_tab , Vp_tab , GSM_work_vectors , PSI_qn_tab);
	}
    }

  if (!non_zero_NBMEs_proportion_only && is_there_cout && (THIS_PROCESS == MASTER_PROCESS))
    {
      cout << endl << "Spectrum" << endl;
      cout <<         "--------" << endl << endl;
      
      eigenvectors_sorted_printed (false , PSI_qn_tab);
    } 

  H.deallocate ();

  J2.deallocate ();

  Jplus.deallocate ();
  Jminus.deallocate ();

  V.deallocate ();
  
  Vstore.deallocate ();

  V_tab.deallocate ();

  HV_tab.deallocate ();
  
  Vp_tab.deallocate ();

  GSM_work_vectors.deallocate ();
	      
  PSI_M_tab.deallocate ();
  PSI_Mp1_tab.deallocate ();

  PSI_helper_M.deallocate ();
  PSI_helper_Mp1.deallocate ();

  prot_Y_data.one_jump_tables_Jpm_in_to_out_deallocate ();
  neut_Y_data.one_jump_tables_Jpm_in_to_out_deallocate ();
       
  prot_Y_data.one_jump_tables_in_to_out_deallocate ();
  neut_Y_data.one_jump_tables_in_to_out_deallocate ();
      
  prot_Y_data.one_jump_tables_Jpm_out_to_in_deallocate ();
  neut_Y_data.one_jump_tables_Jpm_out_to_in_deallocate ();
       
  prot_Y_data.one_jump_tables_out_to_in_deallocate ();
  neut_Y_data.one_jump_tables_out_to_in_deallocate ();
  
  if (!non_zero_NBMEs_proportion_only && is_there_disk_storage_eigenvectors_all_M)
    {  
      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  const unsigned int BP = BP_eigenset_tab(eigenset_index);

	  const double J = J_eigenset_tab(eigenset_index);

	  const double M = M_table(eigenset_index);

	  const int two_J = make_int (2.0*J);

	  const int J_index = (two_J%2 == 0) ? (make_int (J)) : (make_int (J - 0.5));

	  const unsigned int vectors_to_find_number = (all_states_calculated) ? (total_space_dimensions_good_J(BP , n_scat_max , J_index)) : (eigenset_vectors_number);
      
	  for (unsigned int i = 0 ; i < vectors_to_find_number ; i++)
	    {
	      class GSM_vector_helper_class PSI_helper_M_eigenset (is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
								   n_holes_max   , n_scat_max   , E_max_hw  ,
								   n_holes_max_p , n_scat_max_p , Ep_max_hw ,
								   n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , J_projected , prot_Y_data , neut_Y_data);
	  
	      const class correlated_state_str &PSI_qn = PSI_qn_tab(eigenset_index , i);

	      eigenvector_stored_with_all_M_projections (is_there_cout , is_there_cout_detailed , input_data , total_space_dimensions_good_J , PSI_qn , PSI_helper_M_eigenset , PSI_full);
	    }
	}
    }
}




void eigenvector_functions::eigenvectors_pole_approximation_full_space_calc (
									     const bool is_there_cout , 
									     const bool is_it_pole_approximation_only , 
									     const class input_data_str &input_data , 
									     const class array<unsigned long int> &total_space_dimensions_good_J_pole_approximation , 
									     const class array<unsigned long int> &total_space_dimensions_good_J , 
									     class TBMEs_class &TBMEs_pn , 
									     class TBMEs_class &TBMEs_cv , 
									     class baryons_data &prot_Y_data , 
									     class baryons_data &neut_Y_data ,
									     class array<class correlated_state_str> &PSI_qn_tab ,
									     class GSM_vector &PSI_full)
{
  const bool non_zero_NBMEs_proportion_only = input_data.get_non_zero_NBMEs_proportion_only ();

  const bool is_time_considered = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout && !non_zero_NBMEs_proportion_only);
  
  const bool all_states_calculated = input_data.get_all_states_calculated ();

  const double reference_time_pole_approximation = (is_time_considered) ? (absolute_time_determine ()) : (NADA);
  
  const enum space_type space = input_data.get_space ();

  const unsigned int eigensets_number = input_data.get_eigensets_number ();
    
  //--// initialization of the table containing the M quantum numbers used in GSM matrices

  const class array<unsigned int> &BP_eigenset_tab = input_data.get_BP_eigenset_tab ();

  const class array<double> &J_eigenset_tab = input_data.get_J_eigenset_tab ();
    
  class array<double> M_table(eigensets_number);

  M_table_calc (input_data , prot_Y_data , neut_Y_data , BP_eigenset_tab , J_eigenset_tab , M_table);

  //--// Tables to contain the eigenvalues and eigenvectors at pole approximation level for the Davidson method

  const unsigned int subspace_max_dimension = total_space_dimensions_good_J_pole_approximation.max ();

  const unsigned int J_index_max = J_index_max_calc (space , prot_Y_data , neut_Y_data);

  const unsigned int J_index_max_plus_one = J_index_max + 1;

  class array<TYPE> E_subspace_tab(2 , J_index_max_plus_one , subspace_max_dimension);

  class array<class GSM_vector_helper_class> GSM_vector_helper_subspace_tab(2 , J_index_max_plus_one);

  class array<class GSM_vector> eigenvector_subspace_tab(2 , J_index_max_plus_one , subspace_max_dimension);
    
  E_subspace_tab = 0.0;
  
  if (!non_zero_NBMEs_proportion_only)
    {
      pole_approximation_eigenvectors_calc (is_there_cout , total_space_dimensions_good_J_pole_approximation , M_table , TBMEs_pn , TBMEs_cv , input_data , 
					    PSI_qn_tab , prot_Y_data , neut_Y_data , E_subspace_tab , GSM_vector_helper_subspace_tab , eigenvector_subspace_tab);
      
      if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
	{
	  const double now = absolute_time_determine () , relative_time_pole_approximation = now - reference_time_pole_approximation;
      
	  cout << endl << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;
	  cout << "Eigenvectors calculated (pole approximation). time:" << relative_time_pole_approximation << " s" << endl;
	  cout << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl << endl;
	}
    }

  if (is_it_pole_approximation_only) return;
    
  const double reference_time = (is_time_considered) ? (absolute_time_determine ()) : (NADA);
 
  full_space_eigenvectors_calc (is_there_cout , total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J , M_table , TBMEs_pn , TBMEs_cv , input_data , 
				E_subspace_tab , eigenvector_subspace_tab , prot_Y_data , neut_Y_data , PSI_qn_tab , PSI_full);

  if (all_states_calculated && (THIS_PROCESS == MASTER_PROCESS))
    {
      const int Z = input_data.get_Z ();
      const int N = input_data.get_N ();							    
      
      all_energies_copy_to_files (Z , N , BP_eigenset_tab , J_eigenset_tab , total_space_dimensions_good_J , PSI_qn_tab); 
    }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && !non_zero_NBMEs_proportion_only && is_there_cout)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time;
      
      cout << endl << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;
      cout << "Eigenvectors calculated. time:" << relative_time << " s" << endl;
      cout << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl << endl;
    } 
}










// Print of the memory used for a diagonalization of a Hamiltonian of fixed J-Pi
// -----------------------------------------------------------------------------
// The memory used by all GSM work vectors and the number and proportion of non zero NBMEs of the Hamiltonian are printed on screen.
// All used memories are in Mb.


void eigenvector_functions::diagonalization_memory_used_print (
							       const bool non_zero_NBMEs_proportion_only ,
							       const bool is_it_Lanczos , 
							       const bool are_GSM_vectors_stored_on_disk , 
							       const class GSM_vector_helper_class &GSM_vector_helper , 
							       const class H_class &H , 
							       const class GSM_vector &V ,  
							       const class GSM_vector &Vstore ,
							       const class array<class GSM_vector> &PSI_M_tab ,
							       const class array<class GSM_vector> &GSM_work_vectors , 
							       const class array<class GSM_vector> &Vp_tab , 
							       const unsigned int workspace_dimension)
{
  const unsigned int total_space_dimension = GSM_vector_helper.get_total_space_dimension ();
  
  if (total_space_dimension == 0) return;
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  const double V_used_memory = used_memory_calc (V);

  const double Vstore_used_memory = used_memory_calc (Vstore);
  
  const double PSI_M_tab_used_memory = used_memory_calc (PSI_M_tab);

  const double GSM_work_vectors_used_memory = used_memory_calc (GSM_work_vectors);
  
  const double Vp_tab_used_memory = used_memory_calc (Vp_tab);

  const double work_GSM_vectors_memory_now = V_used_memory + Vstore_used_memory + PSI_M_tab_used_memory + GSM_work_vectors_used_memory + Vp_tab_used_memory;
    
  const double work_GSM_vectors_memory_now_max = max_Allreduce (is_it_MPI_parallelized_local , work_GSM_vectors_memory_now);
      
  const double non_zero_NBMEs_proportion = H.non_zero_NBMEs_proportion_calc ();
      	  
  const double total_space_dimension_double = total_space_dimension;

  const double non_zero_NBMEs_number = ceil (non_zero_NBMEs_proportion*total_space_dimension_double*total_space_dimension_double*0.01);
  
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << "H non zero NBMEs number:" << non_zero_NBMEs_number << endl ;
      cout << "H non zero NBMEs proportion:" << non_zero_NBMEs_proportion << "%" << endl << endl;
      
      if (!non_zero_NBMEs_proportion_only && are_GSM_vectors_stored_on_disk) cout << "Maximal memory of all GSM vectors for a process:" << work_GSM_vectors_memory_now_max << " Mb" << endl;
    }
  
  if (!non_zero_NBMEs_proportion_only && !are_GSM_vectors_stored_on_disk)
    {
      const int GSM_vectors_additional_groups = (is_it_Lanczos) ? (1) : (2);
	  
      const double work_GSM_vectors_memory_possible = work_GSM_vectors_memory_now + GSM_vectors_additional_groups*workspace_dimension*V_used_memory;
    
      const double work_GSM_vectors_memory_possible_max = max_Allreduce (is_it_MPI_parallelized_local , work_GSM_vectors_memory_possible);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  cout << "Maximal initial memory of all GSM vectors for a process before the Lanczos/Davidson method:" << work_GSM_vectors_memory_now_max << " Mb" << endl;
	  cout << "Allowed maximal memory of all GSM vectors for a process during the Lanczos/Davidson method:" << work_GSM_vectors_memory_possible_max << " Mb" << endl;
	}
    }

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
}

