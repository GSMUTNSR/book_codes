#include "../GSM_include/GSM_include_def.h"

using namespace correlated_state_routines;

// MPI transfer is done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time


// TYPE is double or complex
// -------------------------

// Calculation of spectroscopic factor involving one nucleon
// ----------------------------------------------------------
// Spectroscopic factors and overlap functions are related to transfer reactions:
// A stripping reaction removes a nucleon from the projectile and then adds it to the target.
// A pick-up reaction adds a nucleon to the projectile after removing it from the target.
//
// One considers spectroscopic factor amplitudes of one proton or one neutron of a fixed (l,j) partial wave.
// The latter nucleon is called the projectile/ejectile for stripping/pick-up and the initial nucleus the target.
// 
// Spectroscopic factors are of the form S = \sum_{n <= nmax} (<Psi[out] || a+_{nlj} || Psi[in]>^J[out]/hat(J[out]))^2 for stripping
//                                   and S = \sum_{n <= nmax} (<Psi[out] || a~_{nlj} || Psi[in]>^J[out]/hat(J[in]))^2  for pick-up
//
// Overlap functions read: I(r) = \sum_{n <= nmax} <Psi[out] || a+_{nlj} || Psi[in]>^J[out]/hat(J[out]) u_{nlj}(r) for stripping
//                     and I(r) = \sum_{n <= nmax} <Psi[out] || a~_{nlj} || Psi[in]>^J[out]/hat(J[in])  u_{nlj}(r) for pick-up
//
// using the Berggren basis of |nlj> shells, with u_{nlj}(r)/r = <nlj | rlj>.
//
// S = \int_{0}^{+oo} I(r)^2 dr, as u_{nlj}(r) one-body radial basis wave functions are orthogonal.
//
// The spectroscopic amplitude is defined to be equal to <Psi[out] | a+_{nljm} | Psi[in]> for stripping, with m = M[out] - M[in]
//                                                   and <Psi[out] |  a_{nljm} | Psi[in]> for pick-up,   with m = M[in]  - M[out]
//
// One uses M[in] = J[in] and M[out] = J[out] for convenience.
//
// Thus, one first calculates and stores an array of nmax + 1 spectroscopic factor amplitudes.
// Reduced matrix elements function of a+_{nlj} and a~_{nlj} are calculated from the latter using Wigner-Eckart theorem, and one sums over 0 <= n <= nmax afterwards.
// The overlap function directly follows from reduced matrix elements function of a+_{nlj} and a~_{nlj}.
//
// |Psi[out]> is given as input and |Psi[in]> will be read from disk from its provided quantum numbers.
//
// Different routines are used for stripping and pick-up, for proton or neutron projectiles, and if one has both valence protons and neutrons, or only valence protons or neutrons.
//
// As the GSM vectors resulting from the action of a+ or a~ on |Psi[in]> are meaningful only in the master process, spectroscopic factor are only calculated in the master process.
//
// 
//
//
// stripping_calc, pick_up_calc
// ----------------------------
// Routines calculating the spectroscopic factor for stripping or pick-up.


TYPE spectroscopic_factor::one_nucleon::stripping_calc (
							const bool full_common_vectors_used_in_file ,
							const enum particle_type particle , 
							const class ljm_struct &ljm , 
							const class correlated_state_str &PSI_IN_qn , 
							const class correlated_state_str &PSI_OUT_qn , 
							const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (particle == PROTON) ? (prot_data) : (neut_data);

  if ((space == PROTONS_ONLY) && (particle != PROTON))   error_message_print_abort ("Protons have to be used in a proton space in spectroscopic_factor::one_nucleon::stripping_calc");
  if ((space == NEUTRONS_ONLY) && (particle != NEUTRON)) error_message_print_abort ("Neutrons have to be used in a neutron space in spectroscopic_factor::one_nucleon::stripping_calc");

  const int nmax = data.get_nmax ();
  
  const class one_body_indices_str &one_body_indices = data.get_one_body_indices ();
	
  const class nlj_table<bool> &is_it_valence_shell_tab = data.get_is_it_valence_shell_tab ();
  
  const int l = ljm.get_l ();

  const double j = ljm.get_j ();
  const double m = ljm.get_m ();

  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();

  const double M_OUT = GSM_vector_helper_OUT.get_M (); 
  const double M_IN = M_OUT - m;
  
  class array<TYPE> spectroscopic_factor_amplitude_tab(nmax+1);

  spectroscopic_factor_amplitude::one_nucleon::stripping_calc (full_common_vectors_used_in_file , particle , ljm , PSI_IN_qn , PSI_OUT , spectroscopic_factor_amplitude_tab);
  
  TYPE spectroscopic_factor_value = 0.0;

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      for (int n = 0 ; n <= nmax ; n++)
	{
	  if (is_it_valence_shell_tab(n , l , j))
	    {
	      const unsigned int phi_stripping_index = one_body_indices(n , l , j , m);

	      if (phi_stripping_index != OUT_OF_RANGE)
		{
		  const TYPE spectroscopic_factor_amplitude = spectroscopic_factor_amplitude_tab(n);

		  const TYPE spectroscopic_factor_amplitude_reduced = static_cast<TYPE> (ME_reduced (spectroscopic_factor_amplitude , j , m , J_IN , M_IN , J_OUT , M_OUT))/hat (J_OUT);
	      
		  spectroscopic_factor_value += spectroscopic_factor_amplitude_reduced*spectroscopic_factor_amplitude_reduced;
		}
	    }
	}
    }
  
  return spectroscopic_factor_value;
}






TYPE spectroscopic_factor::one_nucleon::pick_up_calc (
						      const bool full_common_vectors_used_in_file ,
						      const enum particle_type particle , 
						      const class ljm_struct &ljm , 
						      const class correlated_state_str &PSI_IN_qn , 
						      const class correlated_state_str &PSI_OUT_qn , 
						      const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (particle == PROTON) ? (prot_data) : (neut_data);

  if ((space == PROTONS_ONLY) && (particle != PROTON))   error_message_print_abort ("Protons have to be used in a proton space in spectroscopic_factor::one_nucleon::pick_up_calc");
  if ((space == NEUTRONS_ONLY) && (particle != NEUTRON)) error_message_print_abort ("Neutrons have to be used in a neutron space in spectroscopic_factor::one_nucleon::pick_up_calc");
  
  const int nmax = data.get_nmax ();

  const int nmax_plus_one = nmax + 1;
  
  const class one_body_indices_str &one_body_indices = data.get_one_body_indices ();
	
  const class nlj_table<bool> &is_it_valence_shell_tab = data.get_is_it_valence_shell_tab ();
  
  const int l = ljm.get_l ();

  const double j = ljm.get_j ();
  const double m = ljm.get_m ();

  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();

  const double M_OUT = GSM_vector_helper_OUT.get_M (); 

  const double M_IN = M_OUT + m;
  
  class array<TYPE> spectroscopic_factor_amplitude_tab(nmax_plus_one);

  spectroscopic_factor_amplitude::one_nucleon::pick_up_calc (full_common_vectors_used_in_file , particle , ljm , PSI_IN_qn , PSI_OUT , spectroscopic_factor_amplitude_tab);
  
  TYPE spectroscopic_factor_value = 0.0;

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      for (int n = 0 ; n <= nmax ; n++)
	{
	  if (is_it_valence_shell_tab(n , l , j))
	    {
	      const unsigned int phi_pick_up_index = one_body_indices(n , l , j , m);

	      if (phi_pick_up_index != OUT_OF_RANGE) 
		{
		  const TYPE spectroscopic_factor_amplitude = spectroscopic_factor_amplitude_tab(n);

		  const TYPE spectroscopic_factor_amplitude_reduced = static_cast<TYPE> (ME_reduced (spectroscopic_factor_amplitude , j , -m , J_IN , M_IN , J_OUT , M_OUT))/hat (J_IN);
	      
		  spectroscopic_factor_value += spectroscopic_factor_amplitude_reduced*spectroscopic_factor_amplitude_reduced;
		}
	    }
	}
    }
  
  return spectroscopic_factor_value;
}

