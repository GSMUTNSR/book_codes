#include "../GSM_include/GSM_include_def.h"


using namespace MPI_2D_partitioning;
using namespace GSM_vector_dimensions;



// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// in_to_out means that one starts from |inSD> and one creates |outSD> from a+ a operations
// ----------------------------------------------------------------------------------------

// out_to_in means that one starts from |outSD> and one creates |inSD> from a+ a operations
// ----------------------------------------------------------------------------------------



// Calculation of the part of the component of |Psi[out]> for a fixed |outSD> from the jumps on a given |inSD> in O |Psi[in]>
// --------------------------------------------------------------------------------------------------------------------------
//
// component_part_jumps_calc, component_part_one_jump_calc_Jpm
// -----------------------------------------------------------
// One considers |Psi[out]> = O |Psi[in]> for a given operator O.
// One has <outSD | Psi[out]> = <outSD | O | Psi[in]> = \sum_{inSD} <outSD | O | inSD> . <inSD | Psi[in]> for a fixed |outSD>.
// One considers here the |inSD> states obtained from 1p-1h or 2p-2h excitations from |outSD>, for example, so that a part of <outSD | Psi[out]> is calculated.
// Slater determinants here can possess only protons, only neutrons or protons and neutrons.
// Jumps are always of proton or neutron type.
//
// component_part_one_jump_calc_Jpm
// --------------------------------
// One uses this routine if one considers O = J+ or J-. As configuration does not change from |inSD> to |outSD>,
// one does not check if the configuration of |inSD> belongs to the GSM model space, at it automatically does.
//
// component_part_jumps_number_calc
// --------------------------------
// Number of jumps taking into account model space truncation for a given component part (see above)

TYPE GSM_vector_NBMEs_handling::component_part_jumps_calc (
							   const unsigned int dimension_jumps ,
							   const class array<bool> &is_configuration_accepted_tab , 
							   const class array<unsigned long int> &total_PSI_in_indices , 
							   const class array<TYPE> &NBMEs_jumps ,
							   const class GSM_vector &PSI_in_full)
{  
  
  TYPE component_part = 0.0;

  for (unsigned int i = 0 ; i < dimension_jumps ; i++)
    {
      const unsigned long int total_PSI_in_index = total_PSI_in_indices(i);

      const bool is_configuration_accepted = is_configuration_accepted_tab(i);
      
      if (is_configuration_accepted)
	{
	  const TYPE &NBME_jump = NBMEs_jumps(i);
	  
	  const TYPE &PSI_in_component = PSI_in_full[total_PSI_in_index];
	  
	  component_part += PSI_in_component*NBME_jump;
	} 
    }
  
  return component_part;
}

TYPE GSM_vector_NBMEs_handling::component_part_one_jump_calc_Jpm (
								  const unsigned int dimension_jumps ,
								  const class array<unsigned long int> &total_PSI_in_indices , 
								  const class array<double> &NBMEs_one_jump ,
								  const class GSM_vector &PSI_in_full)
{  
  TYPE component_part = 0.0;

  for (unsigned int i = 0 ; i < dimension_jumps ; i++)
    {
      const unsigned long int total_PSI_in_index = total_PSI_in_indices(i);

      const double NBME_one_jump = NBMEs_one_jump(i);

      const TYPE &PSI_in_component = PSI_in_full[total_PSI_in_index];
      
      component_part += PSI_in_component*NBME_one_jump;
    } 
  
  return component_part;
}

unsigned int GSM_vector_NBMEs_handling::component_part_jumps_number_calc (
									  const unsigned int dimension_jumps ,
									  const class array<bool> &is_configuration_accepted_tab)
{  
  unsigned int component_part_jumps_number = 0;

  for (unsigned int i = 0 ; i < dimension_jumps ; i++)
    {
      const bool is_configuration_accepted = is_configuration_accepted_tab(i);
      
      if (is_configuration_accepted) component_part_jumps_number++;
    }
  
  return component_part_jumps_number;
}





// Calculation and storage of booleans stating if the configuration or |outSD> belongs to the model space and of the indices of |outSD> in |Psi[out]>, issued from jumps on |inSD>
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One considers |Psi[out]> = O |Psi[in]> for a given operator O.
// One has <outSD | Psi[out]> = <outSD | O | Psi[in]> = \sum_{inSD} <outSD | O | inSD> . <inSD | Psi[in]> for a fixed |outSD>.
// One considers here the |outSD> states obtained from 1p-1h or 2p-2h excitations from |inSD>, for example.
//
// One calculates and stores booleans stating if the configuration of |outSD> belongs to the model space in ...is_configuration_accepted...fill routines.
// One calculates and stores the indices of |outSD> in |Psi[out]> as well in ...PSI_out_indices... routines.
//
// As the indices of |outSD> in |Psi[out]> are fonction of their configuration (see GSM_vector_dimensions.cpp),
// one precalculates part of the index everytime the configuration changes when looping on jumps values.
//
// Slater determinants here can possess only protons, only neutrons or protons and neutrons.
// Jumps are always of proton or neutron type.
//
// mu is proton or neutron.
//
//
// ..._Jpm routines
// ----------------
// One uses these routines if one considers O = J+ or J-. As configuration does not change from |inSD> to |outSD>,
// one does not check if the configuration of |outSD> belongs to the GSM model space, at it automatically does.


void GSM_vector_NBMEs_handling::is_configuration_accepted_p_fill (
								  const int n_holes_n , 
								  const int n_scat_n , 
								  const int En_hw , 
								  const unsigned int BPp , 
								  const int Sp ,
								  const int n_spec_p , 
								  const class GSM_vector_helper_class &GSM_vector_helper ,
								  class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_accepted_p_tab)
{
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
    {
      const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
      const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
      
      for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
	{
	  const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	  
	  const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

	  is_configuration_accepted_p_tab(BPp , Sp , n_spec_p , n_scat_p , iCp) =
	    is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw) &&
	    is_basis_state_in_space_pn    (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw);
	}
    }
}

void GSM_vector_NBMEs_handling::is_configuration_accepted_n_fill (
								  const int n_holes_p , 
								  const int n_scat_p , 
								  const int Ep_hw , 
								  const unsigned int BPn ,
								  const int Sn ,
								  const int n_spec_n , 
								  const class GSM_vector_helper_class &GSM_vector_helper , 
								  class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_accepted_n_tab)
{
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();

  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
    {
      const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
      const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
      
      for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
	{
	  const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	  
	  const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

	  is_configuration_accepted_n_tab(BPn , Sn , n_spec_n , n_scat_n , iCn) = 
	    is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw) &&
	    is_basis_state_in_space_pn    (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw);
	}
    }
}

void GSM_vector_NBMEs_handling::out_to_in::is_configuration_accepted_total_PSI_in_indices_p_fill (
												  const unsigned int BPn ,
												  const int Sn ,
												  const int n_spec_n ,  
												  const int n_holes_n , 
												  const int n_scat_n , 
												  const unsigned int iCn , 
												  const int iMn , 
												  const unsigned int SDn_index , 
												  const int En_hw , 
												  const class jumps_data_out_to_in_str &jumps_p , 
												  const class GSM_vector_helper_class &GSM_vector_helper_in , 
												  const unsigned int dimension_SDn ,
												  class array<bool> &is_configuration_accepted_p_tab ,
												  class array<unsigned long int> &total_PSI_in_indices_p ,
												  bool &is_there_calc)
{
  const bool truncation_hw = GSM_vector_helper_in.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_in.get_truncation_ph ();
  
  const unsigned int dimension_jumps_p = jumps_p.get_dimension ();

  const unsigned long int total_space_dimension_in = GSM_vector_helper_in.get_total_space_dimension ();
    
  const int n_holes_max = GSM_vector_helper_in.get_n_holes_max ();
  
  const int n_spec_max = GSM_vector_helper_in.get_n_spec_max ();
  
  const int n_scat_max = GSM_vector_helper_in.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_in.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper_in.get_BP ();

  const int S = GSM_vector_helper_in.get_S ();
  
  const int iM = GSM_vector_helper_in.get_iM ();
  
  const unsigned int BPp = binary_parity_product (BP , BPn);

  const int Sp = S - Sn;
  
  const int n_spec_p = n_spec_max - n_spec_n;
  
  const int iMp = iM - iMn;
	      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_in = GSM_vector_helper_in.get_sum_dimensions_GSM_vector ();

  bool is_configuration_accepted = true;

  unsigned long int total_PSI_in_index_zero_SDn_fixed = 0;

  total_PSI_in_indices_p = total_space_dimension_in;

  is_there_calc = false;

  for (unsigned int i = 0 ; i < dimension_jumps_p ; i++)
    {
      const class jumps_data_inSD_str &jumps_p_inSDp = jumps_p(i);

      const bool is_configuration_changing = jumps_p_inSDp.get_is_configuration_changing ();

      if (is_configuration_changing)
	{ 
	  const int n_holes_p_in = jumps_p_inSDp.get_n_holes ();
	  
	  const int n_scat_p_in = jumps_p_inSDp.get_n_scat ();

	  const int Ep_hw_in = jumps_p_inSDp.get_E_hw ();

	  is_configuration_accepted = true;
									  
	  if (truncation_hw && (Ep_hw_in + En_hw > E_max_hw))            is_configuration_accepted = false;
	  if (truncation_ph && (n_holes_p_in + n_holes_n > n_holes_max)) is_configuration_accepted = false;
	  if (truncation_ph && (n_scat_p_in + n_scat_n > n_scat_max))    is_configuration_accepted = false;
						  
	  if (is_configuration_accepted) 
	    {
	      const unsigned int iCp_in = jumps_p_inSDp.get_iC ();

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector_in(BPp , Sp , n_spec_p , n_scat_p_in , n_scat_n , iCp_in , iCn , iMp);
	      
	      total_PSI_in_index_zero_SDn_fixed = sum_dimensions_configuration_Mp_Mn_fixed_in + SDn_index;
	    }
	}

      if (is_configuration_accepted)
	{
	  const unsigned int inSDp_index = jumps_p_inSDp.get_inSD_index ();

	  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_SDn_fixed + dimension_SDn*inSDp_index;

	  total_PSI_in_indices_p(i) = total_PSI_in_index;
		
	  is_there_calc = true;
	}

      is_configuration_accepted_p_tab(i) = is_configuration_accepted;
    }
}

void GSM_vector_NBMEs_handling::out_to_in::is_configuration_accepted_total_PSI_in_indices_n_fill (
												  const unsigned int BPp ,
												  const int Sp ,
												  const int n_spec_p ,   
												  const int n_holes_p , 
												  const int n_scat_p , 
												  const unsigned int iCp , 
												  const int iMp , 
												  const unsigned int SDp_index , 
												  const int Ep_hw , 
												  const class jumps_data_out_to_in_str &jumps_n , 
												  const class GSM_vector_helper_class &GSM_vector_helper_in ,
												  class array<bool> &is_configuration_accepted_n_tab , 
												  class array<unsigned long int> &total_PSI_in_indices_n ,
												  bool &is_there_calc)
{
  const bool truncation_hw = GSM_vector_helper_in.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_in.get_truncation_ph ();
  
  const unsigned int dimension_jumps_n = jumps_n.get_dimension ();
    
  const unsigned long int total_space_dimension_in = GSM_vector_helper_in.get_total_space_dimension ();
     
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_in = GSM_vector_helper_in.get_sum_dimensions_GSM_vector ();
  
  const class baryons_data &neut_Y_data = GSM_vector_helper_in.get_neut_Y_data ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const int n_holes_max = GSM_vector_helper_in.get_n_holes_max ();
  
  const int n_spec_max = GSM_vector_helper_in.get_n_spec_max ();
  
  const int n_scat_max = GSM_vector_helper_in.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_in.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper_in.get_BP ();

  const int S = GSM_vector_helper_in.get_S ();
  
  const int iM = GSM_vector_helper_in.get_iM ();
  
  const unsigned int BPn = binary_parity_product (BP , BPp);

  const int Sn = S - Sp;
  
  const int n_spec_n = n_spec_max - n_spec_p;
  
  const int iMn = iM - iMp;
	      
  bool is_configuration_accepted = true;

  unsigned long int total_PSI_in_index_zero_SDp_fixed = 0;

  total_PSI_in_indices_n = total_space_dimension_in;

  is_there_calc = false;

  for (unsigned int i = 0 ; i < dimension_jumps_n ; i++)
    {
      const class jumps_data_inSD_str &jumps_n_inSDn = jumps_n(i);
      
      const bool is_configuration_changing = jumps_n_inSDn.get_is_configuration_changing ();
      
      if (is_configuration_changing)
	{ 
	  const int n_holes_n_in = jumps_n_inSDn.get_n_holes ();
	  
	  const int n_scat_n_in = jumps_n_inSDn.get_n_scat ();

	  const int En_hw_in = jumps_n_inSDn.get_E_hw ();
	  
	  is_configuration_accepted = true;
									  
	  if (truncation_hw && (Ep_hw + En_hw_in > E_max_hw))            is_configuration_accepted = false;
	  if (truncation_ph && (n_holes_p + n_holes_n_in > n_holes_max)) is_configuration_accepted = false;
	  if (truncation_ph && (n_scat_p + n_scat_n_in > n_scat_max))    is_configuration_accepted = false;
	      
	  if (is_configuration_accepted)
	    {
	      const unsigned int iCn_in = jumps_n_inSDn.get_iC ();

	      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_in , iCn_in , iMn);
	      
	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector_in(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_in , iCp , iCn_in , iMp);

	      total_PSI_in_index_zero_SDp_fixed = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*SDp_index;
	    }
	} 

      if (is_configuration_accepted)
	{
	  const unsigned int inSDn_index = jumps_n_inSDn.get_inSD_index ();

	  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_SDp_fixed + inSDn_index;

	  total_PSI_in_indices_n(i) = total_PSI_in_index;	      

	  is_there_calc = true;
	}

      is_configuration_accepted_n_tab(i) = is_configuration_accepted;
    }
}

void GSM_vector_NBMEs_handling::in_to_out::are_PSI_out_indices_accepted_PSI_out_indices_p_fill (
												const unsigned int BPn , 
												const int Sn ,
												const int n_spec_n ,    
												const int n_holes_n ,  
												const int n_scat_n , 
												const unsigned int iCn , 
												const int iMn , 
												const unsigned int SDn_index , 
												const int En_hw , 
												const class jumps_data_in_to_out_str &jumps_p , 
												const class GSM_vector_helper_class &GSM_vector_helper_out , 
												const unsigned int dimension_SDn ,
												const unsigned int PSI_in_index , 
												class array<bool> &is_PSI_out_index_accepted_p_tab ,			       
												class array<unsigned int> &occupied_squares_row_indices ,  
												class array<unsigned int> &PSI_out_indices ,
												bool &is_there_calc)
{
  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const class array<bool> &MPI_are_squares_occupied = GSM_vector_helper_out.get_MPI_are_squares_occupied ();
  
  const class array<unsigned int> &MPI_occupied_squares_row_indices = GSM_vector_helper_out.get_MPI_occupied_squares_row_indices ();
    
  const unsigned int dimension_jumps_p = jumps_p.get_dimension ();

  const unsigned int space_dimensions_all_processes_max_out = GSM_vector_helper_out.get_space_dimensions_all_processes_max ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_out.get_is_it_MPI_parallelized_local ();
 
  const class array<unsigned long int> &first_total_PSI_out_indices = GSM_vector_helper_out.get_first_total_PSI_indices ();
  const class array<unsigned long int> &last_total_PSI_out_indices = GSM_vector_helper_out.get_last_total_PSI_indices ();

  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();
  
  const int n_spec_max = GSM_vector_helper_out.get_n_spec_max ();
  
  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper_out.get_BP ();

  const int S = GSM_vector_helper_out.get_S ();
  
  const int iM = GSM_vector_helper_out.get_iM ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();
  
  const unsigned int BPp = binary_parity_product (BP , BPn);

  const int Sp = S - Sn;
  
  const int n_spec_p = n_spec_max - n_spec_n;
  
  const int iMp = iM - iMn;
		  
  bool is_configuration_accepted = true;

  unsigned long int total_PSI_out_index_zero_SDn_fixed = 0;

  PSI_out_indices = space_dimensions_all_processes_max_out;

  is_PSI_out_index_accepted_p_tab = false;
  
  is_there_calc = false;

  for (unsigned int i = 0 ; i < dimension_jumps_p ; i++)
    {
      const class jumps_data_outSD_str &jumps_p_outSDp = jumps_p(i);

      const bool is_configuration_changing = jumps_p_outSDp.get_is_configuration_changing ();

      if (is_configuration_changing)
	{ 
	  const int n_holes_p_out = jumps_p_outSDp.get_n_holes ();
	  
	  const int n_scat_p_out = jumps_p_outSDp.get_n_scat ();

	  const int Ep_hw_out = jumps_p_outSDp.get_E_hw ();

	  is_configuration_accepted = true;
	  
	  if (truncation_hw && (Ep_hw_out + En_hw > E_max_hw))            is_configuration_accepted = false;
	  if (truncation_ph && (n_holes_p_out + n_holes_n > n_holes_max)) is_configuration_accepted = false;
	  if (truncation_ph && (n_scat_p_out + n_scat_n > n_scat_max))    is_configuration_accepted = false;
	      
	  if (is_configuration_accepted) 
	    {
	      const unsigned int iCp_out = jumps_p_outSDp.get_iC ();

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector_out(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , iMp);
		  
	      total_PSI_out_index_zero_SDn_fixed = sum_dimensions_configuration_Mp_Mn_fixed_out + SDn_index;
	    }
	}

      if (is_configuration_accepted)
	{
	  const unsigned int outSDp_index = jumps_p_outSDp.get_outSD_index ();			      

	  const unsigned long int total_PSI_out_index = total_PSI_out_index_zero_SDn_fixed + dimension_SDn*outSDp_index;

	  const unsigned int square_row_index = square_row_index_determine_hybrid_1D_2D (total_PSI_out_index , first_total_PSI_out_indices , last_total_PSI_out_indices);

	  const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);

	  if (is_square_occupied)
	    {	      
	      const unsigned long int first_total_PSI_out_index = first_total_PSI_out_indices(square_row_index);

	      const bool is_it_diagonal_square = is_it_diagonal_square_determine_hybrid_1D_2D (is_it_MPI_parallelized_local , square_row_index);
	      
	      const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
										  
	      if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index))
		{
		  const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
		  
		  occupied_squares_row_indices(i) = occupied_squares_row_index;

		  PSI_out_indices(i) = PSI_out_index;
		  
		  is_PSI_out_index_accepted_p_tab(i) = is_there_calc = true;
		}
	    }
	}
    }
}
  
void GSM_vector_NBMEs_handling::in_to_out::are_PSI_out_indices_accepted_PSI_out_indices_n_fill (
												const unsigned int BPp , 
												const int Sp ,
												const int n_spec_p ,    
												const int n_holes_p , 
												const int n_scat_p , 
												const unsigned int iCp , 
												const int iMp , 
												const unsigned int SDp_index , 
												const int Ep_hw , 
												const class jumps_data_in_to_out_str &jumps_n , 
												const class GSM_vector_helper_class &GSM_vector_helper_out ,
												const unsigned int PSI_in_index , 
												class array<bool> &is_PSI_out_index_accepted_n_tab ,		       
												class array<unsigned int> &occupied_squares_row_indices ,  
												class array<unsigned int> &PSI_out_indices ,
												bool &is_there_calc)
{
  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();

  const class array<bool> &MPI_are_squares_occupied = GSM_vector_helper_out.get_MPI_are_squares_occupied ();

  const class array<unsigned int> &MPI_occupied_squares_row_indices = GSM_vector_helper_out.get_MPI_occupied_squares_row_indices ();
      
  const unsigned int dimension_jumps_n = jumps_n.get_dimension ();

  const unsigned int space_dimensions_all_processes_max_out = GSM_vector_helper_out.get_space_dimensions_all_processes_max ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_out.get_is_it_MPI_parallelized_local ();
 
  const class array<unsigned long int> &first_total_PSI_out_indices = GSM_vector_helper_out.get_first_total_PSI_indices ();
  const class array<unsigned long int> &last_total_PSI_out_indices = GSM_vector_helper_out.get_last_total_PSI_indices ();

  const class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();
  
  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();
  
  const int n_spec_max = GSM_vector_helper_out.get_n_spec_max ();
  
  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper_out.get_BP ();

  const int S = GSM_vector_helper_out.get_S ();
  
  const int iM = GSM_vector_helper_out.get_iM ();

  const unsigned int BPn = binary_parity_product (BP , BPp);

  const int Sn = S - Sp;
  
  const int n_spec_n = n_spec_max - n_spec_p;
  
  const int iMn = iM - iMp;
  
  bool is_configuration_accepted = true;

  unsigned long int total_PSI_out_index_zero_SDp_fixed = 0;

  PSI_out_indices = space_dimensions_all_processes_max_out;

  is_PSI_out_index_accepted_n_tab = false;
  
  is_there_calc = false;
  
  for (unsigned int i = 0 ; i < dimension_jumps_n ; i++)
    {
      const class jumps_data_outSD_str &jumps_n_outSDn = jumps_n(i);

      const bool is_configuration_changing = jumps_n_outSDn.get_is_configuration_changing ();

      if (is_configuration_changing)
	{ 
	  const int n_holes_n_out = jumps_n_outSDn.get_n_holes ();
	  
	  const int n_scat_n_out = jumps_n_outSDn.get_n_scat ();

	  const int En_hw_out = jumps_n_outSDn.get_E_hw ();

	  is_configuration_accepted = true;
	  
	  if (truncation_hw && (Ep_hw + En_hw_out > E_max_hw))            is_configuration_accepted = false;
	  if (truncation_ph && (n_holes_p + n_holes_n_out > n_holes_max)) is_configuration_accepted = false;
	  if (truncation_ph && (n_scat_p + n_scat_n_out > n_scat_max))    is_configuration_accepted = false;
	  
	  if (is_configuration_accepted) 
	    {
	      const unsigned int iCn_out = jumps_n_outSDn.get_iC ();

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector_out(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , iMp);
		  
	      total_PSI_out_index_zero_SDp_fixed = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*SDp_index;
	    }
	}

      if (is_configuration_accepted)
	{
	  const unsigned int outSDn_index = jumps_n_outSDn.get_outSD_index ();							      

	  const unsigned long int total_PSI_out_index = total_PSI_out_index_zero_SDp_fixed + outSDn_index;

	  const unsigned int square_row_index = square_row_index_determine_hybrid_1D_2D (total_PSI_out_index , first_total_PSI_out_indices , last_total_PSI_out_indices);

	  const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
	      
	  if (is_square_occupied)
	    {	      
	      const unsigned long int first_total_PSI_out_index = first_total_PSI_out_indices(square_row_index);

	      const bool is_it_diagonal_square = is_it_diagonal_square_determine_hybrid_1D_2D (is_it_MPI_parallelized_local , square_row_index);
	      
	      const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
										  
	      if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index))
		{
		  const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
		  
		  occupied_squares_row_indices(i) = occupied_squares_row_index;

		  PSI_out_indices(i) = PSI_out_index;
		  
		  is_PSI_out_index_accepted_n_tab(i) = is_there_calc = true;
		}
	    }
	}
    }
}

void GSM_vector_NBMEs_handling::in_to_out::are_PSI_out_indices_accepted_PSI_out_indices_pp_nn_fill (
												    const class jumps_data_in_to_out_str &jumps_mu , 
												    const class GSM_vector_helper_class &GSM_vector_helper_out ,
												    const unsigned int PSI_in_index , 
												    class array<bool> &is_PSI_out_index_accepted_mu_tab ,				       
												    class array<unsigned int> &occupied_squares_row_indices ,  
												    class array<unsigned int> &PSI_out_indices ,
												    bool &is_there_calc)
{
  const unsigned int dimension_jumps_mu = jumps_mu.get_dimension ();

  const class array<bool> &MPI_are_squares_occupied = GSM_vector_helper_out.get_MPI_are_squares_occupied ();

  const class array<unsigned int> &MPI_occupied_squares_row_indices = GSM_vector_helper_out.get_MPI_occupied_squares_row_indices ();
    
  const class array<unsigned long int> &first_total_PSI_out_indices = GSM_vector_helper_out.get_first_total_PSI_indices ();
  const class array<unsigned long int> &last_total_PSI_out_indices = GSM_vector_helper_out.get_last_total_PSI_indices ();
  
  const unsigned int space_dimensions_all_processes_max_out = GSM_vector_helper_out.get_space_dimensions_all_processes_max ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_out.get_is_it_MPI_parallelized_local ();
 
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();
      
  unsigned long int sum_dimensions_configuration_fixed_out = 0;

  PSI_out_indices = space_dimensions_all_processes_max_out;

  is_PSI_out_index_accepted_mu_tab = false;
  
  is_there_calc = false;

  for (unsigned int i = 0 ; i < dimension_jumps_mu ; i++)
    {
      const class jumps_data_outSD_str &jumps_mu_outSD = jumps_mu(i);

      const bool is_configuration_changing = jumps_mu_outSD.get_is_configuration_changing ();

      if (is_configuration_changing)
	{
	  const int n_scat_out = jumps_mu_outSD.get_n_scat ();
	  
	  const unsigned int iC_out = jumps_mu_outSD.get_iC ();
	  
	  sum_dimensions_configuration_fixed_out = sum_dimensions_GSM_vector_out(n_scat_out , iC_out);
	}

      const unsigned int outSD_index = jumps_mu_outSD.get_outSD_index ();

      const unsigned long int total_PSI_out_index = sum_dimensions_configuration_fixed_out + outSD_index;
	  
      const unsigned int square_row_index = square_row_index_determine_hybrid_1D_2D (total_PSI_out_index , first_total_PSI_out_indices , last_total_PSI_out_indices);

      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
	  
      if (is_square_occupied)
	{
	  const unsigned long int first_total_PSI_out_index = first_total_PSI_out_indices(square_row_index);

	  const bool is_it_diagonal_square = is_it_diagonal_square_determine_hybrid_1D_2D (is_it_MPI_parallelized_local , square_row_index);
	  
	  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
									
	  if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index))
	    {
	      const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
	      
	      occupied_squares_row_indices(i) = occupied_squares_row_index;

	      PSI_out_indices(i) = PSI_out_index;
		  
	      is_PSI_out_index_accepted_mu_tab(i) = is_there_calc = true;
	    }
	}
    }
}
void GSM_vector_NBMEs_handling::in_to_out::are_PSI_out_indices_accepted_PSI_out_indices_pp_nn_fill_Jpm (
													const int n_scat ,
													const unsigned int iC ,
													const class jumps_data_in_to_out_str &one_jump_mu , 
													const class GSM_vector_helper_class &GSM_vector_helper_out ,
													class array<bool> &is_PSI_out_index_accepted_mu_tab ,			       
													class array<unsigned int> &square_row_indices ,  
													class array<unsigned int> &PSI_out_indices ,
													bool &is_there_calc)
{
  const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();
  
  const class array<unsigned long int> &first_total_PSI_out_indices = GSM_vector_helper_out.get_first_total_PSI_indices ();
  const class array<unsigned long int> &last_total_PSI_out_indices = GSM_vector_helper_out.get_last_total_PSI_indices ();
  
  const unsigned int space_dimensions_all_processes_max_out = GSM_vector_helper_out.get_space_dimensions_all_processes_max ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_out.get_is_it_MPI_parallelized_local ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();
  
  const unsigned long int sum_dimensions_configuration_fixed_out = sum_dimensions_GSM_vector_out(n_scat , iC);

  const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_fixed_out;

  PSI_out_indices = space_dimensions_all_processes_max_out;

  is_PSI_out_index_accepted_mu_tab = false;
  
  is_there_calc = false;

  if (is_it_MPI_parallelized_local)
    {
      for (unsigned int i = 0 ; i < dimension_one_jump_mu ; i++)
	{
	  const class jumps_data_outSD_str &one_jump_mu_outSD = one_jump_mu(i);

	  const unsigned int outSD_index = one_jump_mu_outSD.get_outSD_index ();

	  const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSD_index;
	  
	  const unsigned int square_row_index = square_row_index_determine_hybrid_1D_2D (total_PSI_out_index , first_total_PSI_out_indices , last_total_PSI_out_indices);
      
	  const unsigned long int first_total_PSI_out_index = first_total_PSI_out_indices(square_row_index);	      

	  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
						
	  square_row_indices(i) = square_row_index;

	  PSI_out_indices(i) = PSI_out_index;
		  
	  is_PSI_out_index_accepted_mu_tab(i) = is_there_calc = true;
	}
    }
  else
    {
      square_row_indices = 0;
      
      for (unsigned int i = 0 ; i < dimension_one_jump_mu ; i++)
	{
	  const class jumps_data_outSD_str &one_jump_mu_outSD = one_jump_mu(i);

	  const unsigned int outSD_index = one_jump_mu_outSD.get_outSD_index ();

	  const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSD_index;
	  
	  PSI_out_indices(i) = total_PSI_out_index;
		  
	  is_PSI_out_index_accepted_mu_tab(i) = is_there_calc = true;
	}
    }
}

void GSM_vector_NBMEs_handling::in_to_out::are_PSI_out_indices_accepted_PSI_out_indices_p_fill_Jpm (
												    const int n_scat_n , 
												    const unsigned int iCn , 
												    const unsigned int SDn_index ,									   
												    const unsigned int BPp , 
												    const int Sp ,
												    const int n_spec_p ,    
												    const int n_scat_p ,
												    const unsigned int iCp , 
												    const int iMp_pm_one ,
												    const class jumps_data_in_to_out_str &one_jump_p , 
												    const class GSM_vector_helper_class &GSM_vector_helper_out , 
												    const unsigned int dimension_SDn ,
												    class array<bool> &is_PSI_out_index_accepted_p_tab ,								       
												    class array<unsigned int> &square_row_indices ,  
												    class array<unsigned int> &PSI_out_indices ,
												    bool &is_there_calc)
{
  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();

  const unsigned int space_dimensions_all_processes_max_out = GSM_vector_helper_out.get_space_dimensions_all_processes_max ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_out.get_is_it_MPI_parallelized_local ();
 
  const class array<unsigned long int> &first_total_PSI_out_indices = GSM_vector_helper_out.get_first_total_PSI_indices ();
  const class array<unsigned long int> &last_total_PSI_out_indices = GSM_vector_helper_out.get_last_total_PSI_indices ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();
  
  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector_out(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp_pm_one);
  const unsigned long int total_PSI_out_index_zero_SDn_fixed = sum_dimensions_configuration_Mp_Mn_fixed_out + SDn_index;

  PSI_out_indices = space_dimensions_all_processes_max_out;

  is_PSI_out_index_accepted_p_tab = false;
  
  is_there_calc = false;

  if (is_it_MPI_parallelized_local)
    {
      for (unsigned int i = 0 ; i < dimension_one_jump_p ; i++)
	{
	  const class jumps_data_outSD_str &one_jump_p_outSDp = one_jump_p(i);
      
	  const unsigned int outSDp_index = one_jump_p_outSDp.get_outSD_index ();							      

	  const unsigned long int total_PSI_out_index = total_PSI_out_index_zero_SDn_fixed + dimension_SDn*outSDp_index;

	  const unsigned int square_row_index = square_row_index_determine_hybrid_1D_2D (total_PSI_out_index , first_total_PSI_out_indices , last_total_PSI_out_indices);
      
	  const unsigned long int first_total_PSI_out_index = first_total_PSI_out_indices(square_row_index);

	  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
					
	  square_row_indices(i) = square_row_index;

	  PSI_out_indices(i) = PSI_out_index;
	      
	  is_PSI_out_index_accepted_p_tab(i) = is_there_calc = true;
	}
    }
  else
    {
      square_row_indices = 0;
      
      for (unsigned int i = 0 ; i < dimension_one_jump_p ; i++)
	{
	  const class jumps_data_outSD_str &one_jump_p_outSDp = one_jump_p(i);
      
	  const unsigned int outSDp_index = one_jump_p_outSDp.get_outSD_index ();							      

	  const unsigned long int total_PSI_out_index = total_PSI_out_index_zero_SDn_fixed + dimension_SDn*outSDp_index;
					
	  PSI_out_indices(i) = total_PSI_out_index;	      

	  is_PSI_out_index_accepted_p_tab(i) = is_there_calc = true;
	}
    }
}

void GSM_vector_NBMEs_handling::in_to_out::are_PSI_out_indices_accepted_PSI_out_indices_n_fill_Jpm (
												    const unsigned int BPp ,
												    const int Sp ,
												    const int n_spec_p ,      
												    const int n_scat_p , 
												    const unsigned int iCp , 
												    const int iMp , 
												    const unsigned int SDp_index , 
												    const int n_scat_n , 
												    const unsigned int iCn ,
												    const class jumps_data_in_to_out_str &one_jump_n , 
												    const class GSM_vector_helper_class &GSM_vector_helper_out ,
												    const unsigned int dimension_outSDn , 
												    class array<bool> &is_PSI_out_index_accepted_n_tab ,								       
												    class array<unsigned int> &square_row_indices ,  
												    class array<unsigned int> &PSI_out_indices ,
												    bool &is_there_calc)
{
  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

  const unsigned int space_dimensions_all_processes_max_out = GSM_vector_helper_out.get_space_dimensions_all_processes_max ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_out.get_is_it_MPI_parallelized_local ();
 
  const class array<unsigned long int> &first_total_PSI_out_indices = GSM_vector_helper_out.get_first_total_PSI_indices ();
  const class array<unsigned long int> &last_total_PSI_out_indices = GSM_vector_helper_out.get_last_total_PSI_indices ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();
  
  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector_out(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

  const unsigned long int total_PSI_out_index_zero_SDp_fixed = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*SDp_index;
  
  PSI_out_indices = space_dimensions_all_processes_max_out;

  is_PSI_out_index_accepted_n_tab = false;
  
  is_there_calc = false;

  if (is_it_MPI_parallelized_local)
    {
      for (unsigned int i = 0 ; i < dimension_one_jump_n ; i++)
	{
	  const class jumps_data_outSD_str &one_jump_n_outSDn = one_jump_n(i);
	
	  const unsigned int outSDn_index = one_jump_n_outSDn.get_outSD_index ();							      

	  const unsigned long int total_PSI_out_index = total_PSI_out_index_zero_SDp_fixed + outSDn_index;

	  const unsigned int square_row_index = square_row_index_determine_hybrid_1D_2D (total_PSI_out_index , first_total_PSI_out_indices , last_total_PSI_out_indices);
	  
	  const unsigned long int first_total_PSI_out_index = first_total_PSI_out_indices(square_row_index);	      

	  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
	
	  square_row_indices(i) = square_row_index;

	  PSI_out_indices(i) = PSI_out_index;
		  
	  is_PSI_out_index_accepted_n_tab(i) = is_there_calc = true;
	}
    }
  else
    {
      square_row_indices = 0;
      
      for (unsigned int i = 0 ; i < dimension_one_jump_n ; i++)
	{
	  const class jumps_data_outSD_str &one_jump_n_outSDn = one_jump_n(i);
	
	  const unsigned int outSDn_index = one_jump_n_outSDn.get_outSD_index ();

	  const unsigned long int total_PSI_out_index = total_PSI_out_index_zero_SDp_fixed + outSDn_index;
	  
	  PSI_out_indices(i) = total_PSI_out_index;
		  
	  is_PSI_out_index_accepted_n_tab(i) = is_there_calc = true;
	}
    }
}


void GSM_vector_NBMEs_handling::out_to_in::total_PSI_in_indices_pp_nn_fill (
									    const class jumps_data_out_to_in_str &jumps_mu , 
									    const class GSM_vector_helper_class &GSM_vector_helper_in ,
									    class array<unsigned long int> &total_PSI_in_indices ,
									    bool &is_there_calc)
{
  const unsigned int dimension_jumps_mu = jumps_mu.get_dimension ();
  
  const unsigned long int total_space_dimension_in = GSM_vector_helper_in.get_total_space_dimension ();
   
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_in = GSM_vector_helper_in.get_sum_dimensions_GSM_vector ();
    
  unsigned long int sum_dimensions_configuration_fixed_in = 0;

  total_PSI_in_indices = total_space_dimension_in;
  
  is_there_calc = false;
  
  for (unsigned int i = 0 ; i < dimension_jumps_mu ; i++)
    {
      const class jumps_data_inSD_str &jumps_mu_inSD = jumps_mu(i);

      const bool is_configuration_changing = jumps_mu_inSD.get_is_configuration_changing ();

      if (is_configuration_changing)
	{
	  const int n_scat_in = jumps_mu_inSD.get_n_scat ();

	  const unsigned int iC_in = jumps_mu_inSD.get_iC ();

	  sum_dimensions_configuration_fixed_in = sum_dimensions_GSM_vector_in(n_scat_in , iC_in);
	}

      const unsigned int inSD_index = jumps_mu_inSD.get_inSD_index ();

      const unsigned long int total_PSI_in_index = sum_dimensions_configuration_fixed_in + inSD_index;
	  
      total_PSI_in_indices(i) = total_PSI_in_index;
	  
      is_there_calc = true;
    }
}

void GSM_vector_NBMEs_handling::out_to_in::total_PSI_in_indices_p_fill_Jpm (
									    const unsigned int SDn_index ,
									    const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in ,
									    const class jumps_data_out_to_in_str &one_jump_p , 
									    const class GSM_vector_helper_class &GSM_vector_helper_in ,
									    const unsigned int dimension_SDn ,
									    class array<unsigned long int> &total_PSI_in_indices_p ,
									    bool &is_there_calc)
{
  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
   
  const unsigned long int total_space_dimension_in = GSM_vector_helper_in.get_total_space_dimension ();

  const unsigned long int total_PSI_in_index_zero_SDn_fixed = sum_dimensions_configuration_Mp_Mn_fixed_in + SDn_index;
 
  total_PSI_in_indices_p = total_space_dimension_in;

  is_there_calc = false;

  for (unsigned int i = 0 ; i < dimension_one_jump_p ; i++)
    {
      const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(i);

      const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_SDn_fixed + dimension_SDn*inSDp_index;
      
      total_PSI_in_indices_p(i) = total_PSI_in_index;
	  
      is_there_calc = true;
    }
}

void GSM_vector_NBMEs_handling::out_to_in::total_PSI_in_indices_n_fill_Jpm (
									    const unsigned int SDp_index ,	      
									    const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in ,
									    const unsigned int dimension_inSDn ,
									    const class jumps_data_out_to_in_str &one_jump_n , 
									    const class GSM_vector_helper_class &GSM_vector_helper_in ,
									    class array<unsigned long int> &total_PSI_in_indices_n ,
									    bool &is_there_calc)
{
  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
  
  const unsigned long int total_space_dimension_in = GSM_vector_helper_in.get_total_space_dimension ();
 
  const unsigned long int total_PSI_in_index_zero_SDp_fixed = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*SDp_index;
		  
  total_PSI_in_indices_n = total_space_dimension_in;

  is_there_calc = false;

  for (unsigned int i = 0 ; i < dimension_one_jump_n ; i++)
    {
      const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(i);

      const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_SDp_fixed + inSDn_index;

      total_PSI_in_indices_n(i) = total_PSI_in_index; 
	  
      is_there_calc = true;
    }
}

void GSM_vector_NBMEs_handling::out_to_in::total_PSI_in_indices_pp_nn_fill_Jpm (			      
										const unsigned long int sum_dimensions_configuration_fixed_in ,
										const class jumps_data_out_to_in_str &one_jump_mu , 
										const class GSM_vector_helper_class &GSM_vector_helper_in ,
										class array<unsigned long int> &total_PSI_in_indices ,
										bool &is_there_calc)
{
  const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();
  
  const unsigned long int total_space_dimension_in = GSM_vector_helper_in.get_total_space_dimension ();

  const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_fixed_in;
  
  total_PSI_in_indices = total_space_dimension_in;
  
  is_there_calc = false;
  
  for (unsigned int i = 0 ; i < dimension_one_jump_mu ; i++)
    {
      const class jumps_data_inSD_str &one_jump_mu_inSD = one_jump_mu(i);

      const unsigned int inSD_index = one_jump_mu_inSD.get_inSD_index ();

      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero + inSD_index;

      total_PSI_in_indices(i) = total_PSI_in_index;
	  
      is_there_calc = true;
    }
}

void GSM_vector_NBMEs_handling::out_to_in::PSI_in_indices_p_fill_Jpm (
								      const unsigned int SDn_index ,
								      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in ,
								      const class jumps_data_out_to_in_str &one_jump_p , 
								      const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in ,
								      const unsigned int dimension_SDn ,
								      class array<unsigned int> &PSI_in_indices_p ,
								      bool &is_there_calc)
{
  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
   
  const unsigned int space_dimension_in = GSM_vector_helper_in.get_space_dimension ();

  const unsigned int PSI_in_index_zero_SDn_fixed = sum_dimensions_configuration_Mp_Mn_fixed_in + SDn_index;
 
  PSI_in_indices_p = space_dimension_in;

  is_there_calc = false;

  for (unsigned int i = 0 ; i < dimension_one_jump_p ; i++)
    {
      const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(i);

      const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();
      
      const unsigned int PSI_in_index = PSI_in_index_zero_SDn_fixed + dimension_SDn*inSDp_index;
      
      PSI_in_indices_p(i) = PSI_in_index;
	  
      is_there_calc = true;
    }
}

void GSM_vector_NBMEs_handling::out_to_in::PSI_in_indices_n_fill_Jpm (
								      const unsigned int SDp_index , 							      
								      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in ,
								      const unsigned int dimension_inSDn ,
								      const class jumps_data_out_to_in_str &one_jump_n , 
								      const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in ,
								      class array<unsigned int> &PSI_in_indices_n ,
								      bool &is_there_calc)
{
  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
  
  const unsigned int space_dimension_in = GSM_vector_helper_in.get_space_dimension ();
 
  const unsigned int PSI_in_index_zero_SDp_fixed = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*SDp_index;
		  
  PSI_in_indices_n = space_dimension_in;

  is_there_calc = false;

  for (unsigned int i = 0 ; i < dimension_one_jump_n ; i++)
    {
      const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(i);

      const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

      const unsigned int PSI_in_index = PSI_in_index_zero_SDp_fixed + inSDn_index;

      PSI_in_indices_n(i) = PSI_in_index; 
	  
      is_there_calc = true;
    }
}

void GSM_vector_NBMEs_handling::out_to_in::PSI_in_indices_pp_nn_fill_Jpm (			      
									  const unsigned int sum_dimensions_configuration_fixed_in ,
									  const class jumps_data_out_to_in_str &one_jump_mu , 
									  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in ,
									  class array<unsigned int> &PSI_in_indices ,
									  bool &is_there_calc)
{
  const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();
  
  const unsigned int space_dimension_in = GSM_vector_helper_in.get_space_dimension ();

  const unsigned int PSI_in_index_zero = sum_dimensions_configuration_fixed_in;
  
  PSI_in_indices = space_dimension_in;
  
  is_there_calc = false;
  
  for (unsigned int i = 0 ; i < dimension_one_jump_mu ; i++)
    {
      const class jumps_data_inSD_str &one_jump_mu_inSD = one_jump_mu(i);

      const unsigned int inSD_index = one_jump_mu_inSD.get_inSD_index ();

      const unsigned int PSI_in_index = PSI_in_index_zero + inSD_index;

      PSI_in_indices(i) = PSI_in_index;
	  
      is_there_calc = true;
    }
}


























// Storage of the dimension of SD spaces and sum of dimensions (see GSM_vector_dimensions.cpp) for fast recovery of array elements
// -------------------------------------------------------------------------------------------------------------------------------

void GSM_vector_NBMEs_handling::dimensions_SDp_sum_dimensions_configuration_Mp_Mn_fixed_p_fill (
												const unsigned int BPn ,
												const int Sn ,
												const int n_spec_n ,   
												const int n_scat_n , 
												const unsigned int iCn , 
												const int iMn , 
												const class GSM_vector_helper_class &GSM_vector_helper , 
												const class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_accepted_tab , 
												class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_Mp_fixed , 
												class array_BP_S_Nspec_Nscat_iC<unsigned int> &sum_dimensions_configuration_Mp_Mn_fixed_tab)
{
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();

  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const unsigned int BPp = binary_parity_product (BPn , BP);

  const int Sp = S - Sn;
  
  const int n_spec_p = n_spec_max - n_spec_n;

  const int iMp = iM - iMn;
  
  for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
    {
      const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
      const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
      
      for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
	{
	  const bool is_configuration_accepted = is_configuration_accepted_tab(BPp , Sp , n_spec_p , n_scat_p , iCp);

	  if (is_configuration_accepted)
	    {
	      dimensions_SDp_Mp_fixed(BPp , Sp , n_spec_p , n_scat_p , iCp) = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
	      
	      sum_dimensions_configuration_Mp_Mn_fixed_tab(BPp , Sp , n_spec_p , n_scat_p , iCp) = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);
	    }
	}
    }									 
}

void GSM_vector_NBMEs_handling::dimensions_SDn_sum_dimensions_configuration_Mp_Mn_fixed_n_fill (
												const unsigned int BPp , 
												const int Sp ,
												const int n_spec_p ,    
												const int n_scat_p , 
												const unsigned int iCp , 
												const int iMp , 
												const class GSM_vector_helper_class &GSM_vector_helper , 
												const class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_accepted_tab , 
												class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_Mn_fixed , 
												class array_BP_S_Nspec_Nscat_iC<unsigned int> &sum_dimensions_configuration_Mp_Mn_fixed_tab)
{
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const unsigned int BPn = binary_parity_product (BPp , BP);

  const int Sn = S - Sp;
  
  const int n_spec_n = n_spec_max - n_spec_p;

  const int iMn = iM - iMp;

  for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
    {
      const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
      const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
      
      for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
	{
	  const bool is_configuration_accepted = is_configuration_accepted_tab(BPn , Sn , n_spec_n , n_scat_n , iCn);

	  if (is_configuration_accepted)
	    {
	      dimensions_SDn_Mn_fixed(BPn , Sn , n_spec_n , n_scat_n , iCn) = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);
	      
	      sum_dimensions_configuration_Mp_Mn_fixed_tab(BPn , Sn , n_spec_n , n_scat_n , iCn) = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);
	    }
	}
    }									 
}







// Calculation of the part of the component of |Psi[out]> for a fixed |outSD> from the jumps on a given |inSD> in O |Psi[in]> and OBMEs for a one-body operator
// ------------------------------------------------------------------------------------------------------------------------------------------------------------
// One considers |Psi[out]> = O |Psi[in]> for a given one-body operator O.
// One has <outSD | Psi[out]> = <outSD | O | Psi[in]> = \sum_{inSD} <outSD | O | inSD> . <inSD | Psi[in]> for a fixed |outSD>.
// One considers here the |inSD> states obtained from 1p-1h excitations from |outSD> and one calculates the NBMEs equal to <outSD | O | inSD>.
// Indeed, one has <outSD | O | inSD> = +/- <s[out] | O | s[in]>, with |s[in]> and |s[out]> the differing states in |inSD> and |outSD>, and +/- 1 is the reordering phase. 
// Slater determinants here can possess only protons, only neutrons or protons and neutrons.
//
// One uses NBMEs_one_jump_mu_calc_one_body_operator_Jpm if one considers O = J+ or J-.
// The only difference with the previous case is that the OBMEs and NBMEs of J+ and J- are real, instead of complex for the general operator.
//
// mu is proton or neutron.

void GSM_vector_NBMEs_handling::in_to_out::NBMEs_one_jump_mu_calc_one_body_operator (
										     const class array<TYPE> &OBMEs_mu,
										     const class jumps_data_in_to_out_str &jumps_one_mu,
										     class array<TYPE> &NBMEs_one_jump_mu)
{
  const unsigned int dimension_one_jump = jumps_one_mu.get_dimension ();

  for (unsigned int i = 0 ; i < dimension_one_jump ; i++)
    {
      const class jumps_data_outSD_str &jumps_one_mu_inSD = jumps_one_mu(i);

      const unsigned int mu_in  = jumps_one_mu_inSD.get_mu_in ();
      const unsigned int mu_out = jumps_one_mu_inSD.get_mu_out ();

      const unsigned int total_bin_phase_mu = jumps_one_mu_inSD.get_total_bin_phase ();

      const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);
      
      const TYPE &OBME_mu = OBMEs_mu(mu_in , mu_out);

      NBMEs_one_jump_mu(i) = (total_phase_mu == 1) ? (OBME_mu) : (-OBME_mu);
    }
}

void GSM_vector_NBMEs_handling::in_to_out::NBMEs_one_jump_mu_calc_one_body_operator_Jpm (
											 const class array<double> &OBMEs_mu,
											 const class jumps_data_in_to_out_str &jumps_one_mu,
											 class array<double> &NBMEs_one_jump_mu)
{
  const unsigned int dimension_one_jump = jumps_one_mu.get_dimension ();

  for (unsigned int i = 0 ; i < dimension_one_jump ; i++)
    {
      const class jumps_data_outSD_str &jumps_one_mu_outSD = jumps_one_mu(i);

      const unsigned int mu_in  = jumps_one_mu_outSD.get_mu_in ();
      const unsigned int mu_out = jumps_one_mu_outSD.get_mu_out ();

      const unsigned int total_bin_phase_mu = jumps_one_mu_outSD.get_total_bin_phase ();

      const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);
      
      const double OBME_mu = OBMEs_mu(mu_in , mu_out);

      NBMEs_one_jump_mu(i) = (total_phase_mu == 1) ? (OBME_mu) : (-OBME_mu);
    }
}

void GSM_vector_NBMEs_handling::out_to_in::NBMEs_one_jump_mu_calc_one_body_operator (
										     const class array<TYPE> &OBMEs_mu,
										     const class jumps_data_out_to_in_str &jumps_one_mu,
										     class array<TYPE> &NBMEs_one_jump_mu)
{
  const unsigned int dimension_one_jump = jumps_one_mu.get_dimension ();

  for (unsigned int i = 0 ; i < dimension_one_jump ; i++)
    {
      const class jumps_data_inSD_str &jumps_one_mu_inSD = jumps_one_mu(i);

      const unsigned int mu_in  = jumps_one_mu_inSD.get_mu_in ();
      const unsigned int mu_out = jumps_one_mu_inSD.get_mu_out ();

      const unsigned int total_bin_phase_mu = jumps_one_mu_inSD.get_total_bin_phase ();

      const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);
      
      const TYPE &OBME_mu = OBMEs_mu(mu_in , mu_out);

      NBMEs_one_jump_mu(i) = (total_phase_mu == 1) ? (OBME_mu) : (-OBME_mu);
    }
}

void GSM_vector_NBMEs_handling::out_to_in::NBMEs_one_jump_mu_calc_one_body_operator_Jpm (
											 const class array<double> &OBMEs_mu,
											 const class jumps_data_out_to_in_str &jumps_one_mu,
											 class array<double> &NBMEs_one_jump_mu)
{
  const unsigned int dimension_one_jump = jumps_one_mu.get_dimension ();

  for (unsigned int i = 0 ; i < dimension_one_jump ; i++)
    {
      const class jumps_data_inSD_str &jumps_one_mu_inSD = jumps_one_mu(i);

      const unsigned int mu_in  = jumps_one_mu_inSD.get_mu_in ();
      const unsigned int mu_out = jumps_one_mu_inSD.get_mu_out ();

      const unsigned int total_bin_phase_mu = jumps_one_mu_inSD.get_total_bin_phase ();

      const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);
      
      const double OBME_mu = OBMEs_mu(mu_in , mu_out);

      NBMEs_one_jump_mu(i) = (total_phase_mu == 1) ? (OBME_mu) : (-OBME_mu);
    }
}




















