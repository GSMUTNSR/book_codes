#include "../GSM_include/GSM_include_def.h"

// MPI transfer is done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

using namespace EM_transitions_common;
using namespace EM_transitions_NBMEs;
using namespace inputs_misc;
using namespace correlated_state_routines;
using namespace configuration_SD_in_space_one_jump_out_to_in;

// TYPE is double or complex
// -------------------------


// EM means electromagnetic
// ------------------------

// OBMEs means one-body matrix elements
// ------------------------------------




// Calculation of electric or magnetic transition matrix elements for all one-body basis states
// --------------------------------------------------------------------------------------------
// The routines for electric or magnetic transition reduced matrix elements are called and OBMEs are dereduced.


void EM_transitions::OBMEs_calc (
				 const enum EM_type EM , 
				 const TYPE &q , 
				 const int L ,
				 const int ML ,
				 const bool is_it_longwavelength_approximation , 
				 const bool is_it_HO_expansion , 
				 const class interaction_class &inter_data , 
				 const class baryons_data &data , 
				 class array<TYPE> &OBMEs)
{
  const unsigned int N_nlj = data.get_N_nlj_baryon ();

  class array<TYPE> OBMEs_reduced(N_nlj , N_nlj);

  OBMEs_reduced_calc (EM , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data , data , OBMEs_reduced);

  OBMEs_dereduced_calc<TYPE> (L , ML , data , data , OBMEs_reduced , OBMEs);
}

void EM_transitions::EM_suboperator_OBMEs_calc (
						const enum EM_suboperator_type EM_suboperator , 
						const TYPE &q , 
						const int L ,
						const int ML ,
						const bool is_it_longwavelength_approximation , 
						const bool is_it_HO_expansion , 
						const class interaction_class &inter_data ,  
						const class baryons_data &data , 
						class array<TYPE> &OBMEs)
{
  const unsigned int N_nlj = data.get_N_nlj_baryon ();

  class array<TYPE> OBMEs_reduced(N_nlj , N_nlj);

  EM_suboperator_OBMEs_reduced_calc (EM_suboperator , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data , data , OBMEs_reduced);

  OBMEs_dereduced_calc<TYPE> (L , ML , data , data , OBMEs_reduced , OBMEs);
}








// Calculation of the EM transition amplitudes are observable for protons only, neutrons only and proton/neutron cases
// -------------------------------------------------------------------------------------------------------------------
// <Psi[out] || Op || Psi[in]> or <Psi[out] || Op || Psi[in]>^2 are calculated for a given EM transition or suboperator.

TYPE EM_transitions::B_amplitude_pp_nn (
					const enum EM_type EM , 
					const TYPE &q , 
					const int L ,
					const bool is_it_longwavelength_approximation , 
					const bool is_it_HO_expansion , 
					const class interaction_class &inter_data ,
					class GSM_vector &PSI_full , 
					const double J_IN , 
					const class GSM_vector &PSI_IN , 
					const double J_OUT , 
					const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &PSI_IN_helper = PSI_IN.get_GSM_vector_helper ();

  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = PSI_IN_helper.get_space ();

  const class baryons_data &prot_Y_data = PSI_IN_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = PSI_IN_helper.get_neut_Y_data ();

  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const int iM_IN = PSI_IN_helper.get_iM ();

  const int iM_OUT = GSM_vector_helper_OUT.get_iM ();

  const int ML = iM_OUT - iM_IN;

  const class array<TYPE> dummy_OBMEs;
  
  const unsigned int BP_Op = BP_EM_determine (EM , L);

  const unsigned int N_nljm = data.get_N_nljm_baryon ();

  class array<TYPE> OBMEs(N_nljm , N_nljm);

  OBMEs_calc (EM , q , L , ML , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data , data , OBMEs);

  const TYPE reduced_B_EM_amplitude = (space == PROT_Y_ONLY)
    ? (B_EM_amplitude_from_OBMEs_calc (PSI_full , L , BP_Op , OBMEs , dummy_OBMEs , J_IN , PSI_IN , J_OUT , PSI_OUT))
    : (B_EM_amplitude_from_OBMEs_calc (PSI_full , L , BP_Op , dummy_OBMEs , OBMEs , J_IN , PSI_IN , J_OUT , PSI_OUT));

  return reduced_B_EM_amplitude;
}

TYPE EM_transitions::B_amplitude_pn ( 
				     const enum EM_type EM , 
				     const TYPE &q , 
				     const int L ,
				     const bool is_it_longwavelength_approximation , 
				     const bool is_it_HO_expansion , 
				     const class interaction_class &inter_data ,
				     class GSM_vector &PSI_full ,
				     const double J_IN , 
				     const class GSM_vector &PSI_IN , 
				     const double J_OUT , 
				     const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &PSI_IN_helper = PSI_IN.get_GSM_vector_helper ();

  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = PSI_IN_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = PSI_IN_helper.get_neut_Y_data ();

  const int iM_IN = PSI_IN_helper.get_iM ();

  const int iM_OUT = GSM_vector_helper_OUT.get_iM ();

  const int ML = iM_OUT - iM_IN;

  const unsigned int Np_nljm = prot_Y_data.get_N_nljm_baryon ();
  const unsigned int Nn_nljm = neut_Y_data.get_N_nljm_baryon ();

  const unsigned int BP_Op = BP_EM_determine (EM , L);

  class array<TYPE> OBMEs_p(Np_nljm , Np_nljm);
  class array<TYPE> OBMEs_n(Nn_nljm , Nn_nljm);

  OBMEs_calc (EM , q , L , ML , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data , prot_Y_data , OBMEs_p);
  OBMEs_calc (EM , q , L , ML , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data , neut_Y_data , OBMEs_n);

  const TYPE reduced_B_EM_amplitude = B_EM_amplitude_from_OBMEs_calc (PSI_full , L , BP_Op , OBMEs_p , OBMEs_n , J_IN , PSI_IN , J_OUT , PSI_OUT);

  return reduced_B_EM_amplitude;
}

TYPE EM_transitions::B_amplitude_calc ( 
				       const enum EM_type EM , 
				       const TYPE &q , 
				       const int L ,
				       const bool is_it_longwavelength_approximation , 
				       const bool is_it_HO_expansion , 
				       const class interaction_class &inter_data ,
				       class GSM_vector &PSI_full ,
				       const double J_IN , 
				       const class GSM_vector &PSI_IN , 
				       const double J_OUT , 
				       const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  switch (space)
    {
    case PROT_Y_ONLY: return B_amplitude_pp_nn (EM , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data , PSI_full , J_IN , PSI_IN , J_OUT , PSI_OUT);
    case NEUT_Y_ONLY: return B_amplitude_pp_nn (EM , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data , PSI_full , J_IN , PSI_IN , J_OUT , PSI_OUT);

    case PROT_NEUT_Y: return B_amplitude_pn (EM , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data , PSI_full , J_IN , PSI_IN , J_OUT , PSI_OUT);

    default: return NADA;
    }
}


TYPE EM_transitions::EM_suboperator_B_amplitude_pp_nn ( 
						       const enum EM_suboperator_type EM_suboperator ,
						       const TYPE &q , 
						       const int L ,
						       const bool is_it_longwavelength_approximation , 
						       const bool is_it_HO_expansion , 	
						       const class interaction_class &inter_data , 
						       class GSM_vector &PSI_full , 
						       const double J_IN , 
						       const class GSM_vector &PSI_IN , 
						       const double J_OUT , 
						       const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &PSI_IN_helper = PSI_IN.get_GSM_vector_helper ();

  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = PSI_IN_helper.get_space ();

  const class baryons_data &prot_Y_data = PSI_IN_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = PSI_IN_helper.get_neut_Y_data ();

  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const int iM_IN = PSI_IN_helper.get_iM ();

  const int iM_OUT = GSM_vector_helper_OUT.get_iM ();

  const int ML = iM_OUT - iM_IN;

  const class array<TYPE> dummy_OBMEs;
  
  const unsigned int BP_Op = BP_EM_suboperator_determine (EM_suboperator , L);

  const unsigned int N_nljm = data.get_N_nljm_baryon ();

  class array<TYPE> OBMEs(N_nljm , N_nljm);

  EM_suboperator_OBMEs_calc (EM_suboperator , q , L , ML , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data , data , OBMEs);

  const TYPE reduced_B_EM_amplitude = (space == PROT_Y_ONLY)
    ? (B_EM_amplitude_from_OBMEs_calc (PSI_full , L , BP_Op , OBMEs , dummy_OBMEs , J_IN , PSI_IN , J_OUT , PSI_OUT))
    : (B_EM_amplitude_from_OBMEs_calc (PSI_full , L , BP_Op , dummy_OBMEs , OBMEs , J_IN , PSI_IN , J_OUT , PSI_OUT));

  return reduced_B_EM_amplitude;
}

TYPE EM_transitions::EM_suboperator_B_amplitude_pn ( 
						    const enum EM_suboperator_type EM_suboperator , 
						    const TYPE &q , 
						    const int L ,
						    const bool is_it_longwavelength_approximation , 
						    const bool is_it_HO_expansion , 
						    const class interaction_class &inter_data , 
						    class GSM_vector &PSI_full , 
						    const double J_IN , 
						    const class GSM_vector &PSI_IN , 
						    const double J_OUT , 
						    const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &PSI_IN_helper = PSI_IN.get_GSM_vector_helper ();

  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = PSI_IN_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = PSI_IN_helper.get_neut_Y_data ();

  const int iM_IN = PSI_IN_helper.get_iM ();

  const int iM_OUT = GSM_vector_helper_OUT.get_iM ();

  const int ML = iM_OUT - iM_IN;

  const unsigned int Np_nljm = prot_Y_data.get_N_nljm_baryon ();
  const unsigned int Nn_nljm = neut_Y_data.get_N_nljm_baryon ();

  const unsigned int BP_Op = BP_EM_suboperator_determine (EM_suboperator , L);

  class array<TYPE> OBMEs_p(Np_nljm , Np_nljm);
  class array<TYPE> OBMEs_n(Nn_nljm , Nn_nljm);

  EM_suboperator_OBMEs_calc (EM_suboperator , q , L , ML , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data , prot_Y_data , OBMEs_p);
  EM_suboperator_OBMEs_calc (EM_suboperator , q , L , ML , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data , neut_Y_data , OBMEs_n);

  const TYPE reduced_B_EM_amplitude = B_EM_amplitude_from_OBMEs_calc (PSI_full , L , BP_Op , OBMEs_p , OBMEs_n , J_IN , PSI_IN , J_OUT , PSI_OUT);

  return reduced_B_EM_amplitude;
}

TYPE EM_transitions::EM_suboperator_B_amplitude_calc (
						      const enum EM_suboperator_type EM_suboperator , 
						      const TYPE &q , 
						      const int L ,
						      const bool is_it_longwavelength_approximation , 
						      const bool is_it_HO_expansion , 
						      const class interaction_class &inter_data ,
						      class GSM_vector &PSI_full , 
						      const double J_IN , 
						      const class GSM_vector &PSI_IN , 
						      const double J_OUT , 
						      const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  switch (space)
    {
    case PROT_Y_ONLY: return EM_suboperator_B_amplitude_pp_nn (EM_suboperator , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data , PSI_full , J_IN , PSI_IN , J_OUT , PSI_OUT);      
    case NEUT_Y_ONLY: return EM_suboperator_B_amplitude_pp_nn (EM_suboperator , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data , PSI_full , J_IN , PSI_IN , J_OUT , PSI_OUT);

    case PROT_NEUT_Y: return EM_suboperator_B_amplitude_pn (EM_suboperator , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data , PSI_full , J_IN , PSI_IN , J_OUT , PSI_OUT);

    default: return NADA;
    }
}









// Calculation of the EM transitions <Psi[out] || Op || Psi[in]>^2 for all demanded EM transitions in the input file
// -----------------------------------------------------------------------------------------------------------------
// Eigenvectors are read from disk and B_anmplitude_calc is called for the EM transitions, for Q and B to be printed on screen afterwards in nuclear and Weisskopf units.

void EM_transitions::calc_print (
				 const class input_data_str &input_data , 
				 const class interaction_class &inter_data , 
				 class baryons_data &prot_Y_data , 
				 class baryons_data &neut_Y_data , 
				 const class array<class correlated_state_str> &PSI_qn_tab ,
				 class GSM_vector &PSI_full)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "EM transitions" << endl;
      cout <<         "--------------" << endl << endl;
    }

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();

  const int S = input_data.get_hypernucleus_strangeness ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();

  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
  
  const int Z = prot_Y_data.get_N_nucleons ();
  const int N = neut_Y_data.get_N_nucleons ();
  
  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();
 
  const unsigned int EM_transitions_number = input_data.get_EM_transitions_number ();
  
  const class array<enum EM_type> &EM_tab = input_data.get_EM_tab ();

  const class array<int> &EM_L_tab = input_data.get_EM_L_tab ();

  const class array<unsigned int> &EM_BP_IN_tab  = input_data.get_EM_BP_IN_tab ();
  const class array<unsigned int> &EM_BP_OUT_tab = input_data.get_EM_BP_OUT_tab ();

  const class array<double> &EM_J_IN_tab  = input_data.get_EM_J_IN_tab ();
  const class array<double> &EM_J_OUT_tab = input_data.get_EM_J_OUT_tab ();

  const class array<unsigned int> &EM_vector_index_IN_tab  = input_data.get_EM_vector_index_IN_tab ();
  const class array<unsigned int> &EM_vector_index_OUT_tab = input_data.get_EM_vector_index_OUT_tab (); 

  const class array<bool> &EM_is_it_longwavelength_approximation_tab = input_data.get_EM_is_it_longwavelength_approximation_tab ();
  
  const class array<bool> &EM_is_it_HO_expansion_tab = input_data.get_EM_is_it_HO_expansion_tab (); 
  
  for (unsigned int EM_index = 0 ; EM_index < EM_transitions_number ; EM_index++)
    {
      const enum EM_type EM = EM_tab(EM_index);

      const int L = EM_L_tab(EM_index);

      const unsigned int BP_IN  = EM_BP_IN_tab(EM_index);
      const unsigned int BP_OUT = EM_BP_OUT_tab(EM_index);
      
      const unsigned int vector_index_IN  = EM_vector_index_IN_tab(EM_index);
      const unsigned int vector_index_OUT = EM_vector_index_OUT_tab(EM_index);
     
      const double J_IN  = EM_J_IN_tab(EM_index);
      const double J_OUT = EM_J_OUT_tab(EM_index);

      const double M_IN  = J_IN;
      const double M_OUT = J_OUT;
      
      const class correlated_state_str PSI_IN_qn = PSI_quantum_numbers_find (Z , N , BP_IN , S , J_IN , vector_index_IN , PSI_qn_tab);

      class GSM_vector_helper_class PSI_IN_helper(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph , 
						  n_holes_max   , n_scat_max   , E_max_hw  ,
						  n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						  n_holes_max_n , n_scat_max_n , En_max_hw , BP_IN , M_IN , false , prot_Y_data , neut_Y_data);
      
      class GSM_vector PSI_IN(PSI_IN_helper);

      PSI_IN.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_IN_qn);

      const class correlated_state_str PSI_OUT_qn = PSI_quantum_numbers_find (Z , N , BP_OUT , S , J_OUT , vector_index_OUT , PSI_qn_tab);

      class GSM_vector_helper_class PSI_OUT_helper(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
						   n_holes_max   , n_scat_max   , E_max_hw  ,
						   n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						   n_holes_max_n , n_scat_max_n , En_max_hw , BP_OUT , M_OUT , false , prot_Y_data , neut_Y_data);
      
      class GSM_vector PSI_OUT(PSI_OUT_helper);

      const class GSM_vector_helper_class dummy_helper;

      PSI_OUT.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_OUT_qn);

      class GSM_vector_helper_class PSI_IN_full_helper;
      
      PSI_IN_full_helper.allocate_fill_without_MPI_parallelization (PSI_IN_helper);

      configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , true , false , false , false , PSI_IN_full_helper , PSI_OUT_helper , dummy_helper , prot_Y_data , neut_Y_data);

      const bool is_it_longwavelength_approximation = EM_is_it_longwavelength_approximation_tab(EM_index);

      const bool is_it_HO_expansion = EM_is_it_HO_expansion_tab(EM_index);

      const int A = prot_Y_data.get_A ();

      const complex<double> E_IN_complex  = PSI_IN_qn.get_E ();
      const complex<double> E_OUT_complex = PSI_OUT_qn.get_E (); 

      const TYPE E_IN  = generate_scalar<TYPE> (real (E_IN_complex)  , imag (E_IN_complex));
      const TYPE E_OUT = generate_scalar<TYPE> (real (E_OUT_complex) , imag (E_OUT_complex));
      
      const TYPE q = (E_IN - E_OUT)/hbar_c;

      const TYPE B_amplitude = B_amplitude_calc (EM , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data , PSI_full , J_IN , PSI_IN , J_OUT , PSI_OUT);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  if (is_it_HO_expansion)
	    cout << "HO expansion , ";
	  else
	    cout << "R cut , ";

	  print_B_G (EM , q , L , is_it_longwavelength_approximation , A , PSI_IN_qn , PSI_OUT_qn , B_amplitude);
	}
    }
}



