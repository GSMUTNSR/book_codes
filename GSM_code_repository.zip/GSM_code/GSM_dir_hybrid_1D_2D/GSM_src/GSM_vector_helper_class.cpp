#include "../GSM_include/GSM_include_def.h"

using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;
using namespace MPI_2D_partitioning;



// TYPE is double or complex
// -------------------------

// Class providing with data necessary to calculate basis Slater determinant indices in a GSM vector
// -------------------------------------------------------------------------------------------------
// This class is a helper for GSM vector as it contains data common to all GSM vectors necessary to deal with basis Slater determinant states.
//
// One has here constructors, destructors and member routines.
// Arrays and constants are allocated and calculated in the constructor, and are not supposed to change afterwards.
// As GSM_vector_helper_class contains pointers to nucleon_data classes prot_data and neut_data, it is nevertheless not constant as the latter are modified very often.
//
// The MPI distribution of GSM vectors is also taken into account in this class.
//
// hybrid 1D/2D partitioning
// -------------------------
// One uses hybrid 1D/2D partitioning for GSM vectors and operators, so that each node takes care of only one part of the input and output GSM vectors (2D partitioning),
// but where operators are stored as columns on each node (1D partitioning):
//
//        Op           x  Psi[in]  =  Psi[out]
// * n * n * n * n *        *            *   
// *   *   *   *   *      node 0       node 0
// * o * o * o * o *        *            *
// *   *   *   *   *      node 1       node 1
// * d * d * d * d *        *            *
// *   *   *   *   *      node 2       node 2
// * e * e * e * e *        *            *
// *   *   *   *   *      node 3       node 3
// * 0 * 1 * 2 * 3 *        *            *
//
//
// Hamiltonian with hybrid 1D/2D partitioning
// ------------------------------------------
// Each node calculates only part of Psi[out] and stores only part of H. 
// What is called a square is a part of H connecting the node i storing a part of |Psi[in]> to the node j storing a part of |Psi[out]>.
// An MPI communication of all newly calculated components on each row to the node taking care of the considered part of |Psi[out]> has to be done.
//
// Hamiltonian symmetry is used so that about half of H is stored.
// For this, one stores H only in occupied squares, i.e. squares where 2D partitioning allows for storage (see MPI_2D_partitioning.cpp).
// Let us take 5 nodes. One then has 15 squares:
//
// 0 - - 11 13
// 1 3 - -  14
// 2 4 6 -  -
// - 5 7 9  -
// - - 8 10 12
//
// H is stored only in the 0,...,14 squares.
// Diagonal squares are separated in two triangles to take into account symmetry, so that occupied and unoccupied relate to triangles therein.
// Nodes 0,1,2,3,4 store squares (0,1,2), (3,4,5), (6,7,8), (9,10,11), (12,13,14), respectively, due to the column storage of hybrid 1D/2D partitioning (see above).
// To do MPI reduction of results, one uses row communicators. In this example, they consist of the nodes storing the squares (0,11,13), (1,3,14), (2,4,6), (5,7,9), (8,10,12), respectively.
//
//
//
// allocate_fill_with/without_MPI_parallelization
// ----------------------------------------------
// Copy constructor allowing for MPI parallelization or not, independently of the constructor used in the routine.
//
// configuration_total_SDp_SDn_indices_min_max_calc_store
// ------------------------------------------------------
// Calculates the minimal and maximal proton and neutron configuration and Slater determinant indices occurring in a node for a GSM vector.
//
// all_dimensions_SDp/SDn_zero_tabs_calc
// -------------------------------------
// Calculates booleans arrays stating if a full configuration has no proton or neutron Slater determinants of provided configuration quantum numbers and M.
// 
// same_parity_M_projection
// ------------------------
// check if two classes have same parity and M projection, which has to be the case with scalar operators for |Psi[in]> and |Psi[out]>.
// The routine is straightforward so that it is not commented.
//
// used_memory_calc
// ----------------
// Provides with the used memory of the class in Mb. Variables therein are not commented as they only state partial memories used by member variables.
//
// TRS_data_calc_store
// -------------------
// Time-reversal symmetry (TRS) arrays are calculated, which are used when TRS is applied to |Psi[M=0]> (see GSM_TRS_class.cpp for details).


GSM_vector_helper_class::GSM_vector_helper_class () :
  is_it_MPI_parallelized_local (false) ,
  space (NO_SPACE) ,
  inter (NO_INTERACTION) ,
  is_it_pole_approximation (false) , 
  truncation_hw (false) ,
  truncation_ph (false) , 
  n_holes_max (0) ,
  n_holes_max_p (0) ,
  n_holes_max_n (0) , 
  n_scat_max (0) ,
  n_scat_max_p (0) ,
  n_scat_max_n (0) ,
  E_max_hw (0) , 
  Ep_max_hw (0) , 
  En_max_hw (0) , 
  BP (0) , 
  M (0.0) ,  
  iM (0) ,  
  TRS_iM (0) , 
  iMp_min_M (0) , 
  iMp_max_M (0) , 
  iMn_min_M (0) , 
  iMn_max_M (0) , 
  is_it_TRS (false) ,
  Jmax (0.0) ,
  total_space_dimension (0) , 
  space_dimension_process (0) , 
  space_dimensions_all_processes_max (0) ,
  first_total_PSI_index (0) ,
  last_total_PSI_index (0) ,  
  MPI_occupied_squares_row_number (0) ,  
  total_SDp_index_min (0) ,
  total_SDp_index_max (0) ,
  total_SDn_index_min (0) ,
  total_SDn_index_max (0) , 
  total_SD_index_min (0) ,
  total_SD_index_max (0) ,
  prot_data_ptr (NULL) , 
  neut_data_ptr (NULL)
{}


GSM_vector_helper_class::GSM_vector_helper_class (
						  const bool is_it_MPI_parallelized_local_c ,
						  const enum space_type space_c , 
						  const enum interaction_type inter_c , 
						  const bool is_it_pole_approximation_c , 
						  const bool truncation_hw_c , 
						  const bool truncation_ph_c , 
						  const int n_holes_max_c , 
						  const int n_scat_max_c , 
						  const int E_max_hw_c , 
						  const int n_holes_max_p_c , 
						  const int n_scat_max_p_c , 
						  const int Ep_max_hw_c , 
						  const int n_holes_max_n_c , 
						  const int n_scat_max_n_c , 
						  const int En_max_hw_c ,
						  const unsigned int BP_c , 
						  const double M_c , 
						  const bool is_it_TRS_for_M_zero ,
						  class nucleons_data &prot_data , 
						  class nucleons_data &neut_data) :
  is_it_MPI_parallelized_local (false) ,
  space (NO_SPACE) ,
  inter (NO_INTERACTION) ,
  is_it_pole_approximation (false) , 
  truncation_hw (false) ,
  truncation_ph (false) , 
  n_holes_max (0) ,
  n_holes_max_p (0) ,
  n_holes_max_n (0) ,
  n_scat_max (0) ,
  n_scat_max_p (0) ,
  n_scat_max_n (0) ,
  E_max_hw (0) , 
  Ep_max_hw (0) , 
  En_max_hw (0) , 
  BP (0) , 
  M (0.0) ,  
  iM (0) ,  
  TRS_iM (0) , 
  iMp_min_M (0) , 
  iMp_max_M (0) , 
  iMn_min_M (0) , 
  iMn_max_M (0) ,
  is_it_TRS (false) ,
  Jmax (0.0) ,
  total_space_dimension (0) , 
  space_dimension_process (0) , 
  space_dimensions_all_processes_max (0) , 
  first_total_PSI_index (0) ,
  last_total_PSI_index (0) ,   
  MPI_occupied_squares_row_number (0) ,   
  total_SDp_index_min (0) ,
  total_SDp_index_max (0) ,
  total_SDn_index_min (0) ,
  total_SDn_index_max (0) ,
  total_SD_index_min (0) ,
  total_SD_index_max (0) ,
  prot_data_ptr (NULL) , 
  neut_data_ptr (NULL)
{
  allocate (is_it_MPI_parallelized_local_c , space_c , inter_c , is_it_pole_approximation_c , truncation_hw_c , truncation_ph_c ,
	    n_holes_max_c   , n_scat_max_c   , E_max_hw_c  ,
	    n_holes_max_p_c , n_scat_max_p_c , Ep_max_hw_c ,
	    n_holes_max_n_c , n_scat_max_n_c , En_max_hw_c , BP_c , M_c , is_it_TRS_for_M_zero , prot_data , neut_data);
}





GSM_vector_helper_class::GSM_vector_helper_class (const class GSM_vector_helper_class &X) :
  is_it_MPI_parallelized_local (false) ,
  space (NO_SPACE) ,
  inter (NO_INTERACTION) ,
  is_it_pole_approximation (false) , 
  truncation_hw (false) ,
  truncation_ph (false) ,
  n_holes_max (0) ,
  n_holes_max_p (0) ,
  n_holes_max_n (0) , 
  n_scat_max (0) ,
  n_scat_max_p (0) ,
  n_scat_max_n (0) ,
  E_max_hw (0) , 
  Ep_max_hw (0) , 
  En_max_hw (0) , 
  BP (0) , 
  M (0.0) ,  
  iM (0) ,  
  TRS_iM (0) , 
  iMp_min_M (0) , 
  iMp_max_M (0) , 
  iMn_min_M (0) , 
  iMn_max_M (0) ,
  is_it_TRS (false) ,
  Jmax (0.0) ,
  total_space_dimension (0) , 
  space_dimension_process (0) , 
  space_dimensions_all_processes_max (0) , 
  first_total_PSI_index (0) ,
  last_total_PSI_index (0) ,   
  MPI_occupied_squares_row_number (0) ,    
  total_SDp_index_min (0) ,
  total_SDp_index_max (0) ,
  total_SDn_index_min (0) ,
  total_SDn_index_max (0) ,
  total_SD_index_min (0) ,
  total_SD_index_max (0) ,  
  prot_data_ptr (NULL) , 
  neut_data_ptr (NULL)
{
  allocate_fill (X);
}






GSM_vector_helper_class::~GSM_vector_helper_class ()
{
#ifdef UseMPI
  
  const unsigned int N = MPI_row_communicators.dimension (0);
  
  for (unsigned int i = 0 ; i < N ; i++)
    {
      MPI_Comm &MPI_row_communicator = MPI_row_communicators(i);
	  
      if (MPI_row_communicator != MPI_COMM_SELF) MPI_helper::Comm_free (MPI_row_communicator);
    }

#endif  
}





void GSM_vector_helper_class::allocate_MPI_part ()
{
  const unsigned int N = (is_it_MPI_parallelized_local) ? (NUMBER_OF_PROCESSES) : (1);
  
  MPI_row_processes.allocate (N);

  MPI_row_processes = N;
  
  MPI_row_group_master_processes.allocate (N);

  MPI_row_group_master_processes = N;

  MPI_are_squares_occupied.allocate (N);

  MPI_are_squares_occupied = false;
  
  MPI_occupied_squares_row_indices.allocate (N);

  MPI_occupied_squares_row_indices = N;
  
#ifdef UseMPI
  
  MPI_row_communicators.allocate (N);

  MPI_row_communicators = MPI_COMM_SELF;
  
  if (is_it_MPI_parallelized_local)
    {
      class array<bool> fixed_row_are_squares_occupied(N);

      class array<unsigned int> fixed_row_square_indices(N);
 
      MPI_occupied_squares_row_number = 0;
      
      MPI_row_group_master_processes = N;
      
      for (unsigned int i = 0 ; i < N ; i++)
	{
	  fixed_row_square_indices_calc_fill_symmetric_case (i , fixed_row_are_squares_occupied , fixed_row_square_indices);
      
	  const bool is_square_occupied = fixed_row_are_squares_occupied(THIS_PROCESS);

	  const bool is_it_diagonal_square = is_it_diagonal_square_determine_hybrid_1D_2D (true , i);

	  const unsigned int square_color = (is_square_occupied) ? (i) : (i + N);
	  
	  const MPI_Comm MPI_row_communicator = MPI_helper::Comm_split (square_color , THIS_PROCESS , MPI_COMM_WORLD);
	  
	  MPI_row_communicators(i) = MPI_row_communicator;

	  if (is_square_occupied)
	    {
	      const unsigned int MPI_row_process = MPI_helper::Comm_rank (MPI_row_communicator);
	  
	      MPI_are_squares_occupied(i) = true;

	      MPI_row_processes(i) = MPI_row_process;
	  
	      if (is_it_diagonal_square) MPI_row_group_master_processes(i) = MPI_row_process;

	      MPI_occupied_squares_row_number++;
	    }
	}

      MPI_row_group_master_processes.MPI_Allreduce (MPI_MIN , MPI_COMM_WORLD);
	
      MPI_occupied_squares_row_number = 0;

      for (unsigned int i = 0 ; i < N ; i++)
	{
	  const bool is_square_occupied = MPI_are_squares_occupied(i);

	  if (is_square_occupied)
	    {
	      const unsigned int MPI_occupied_squares_index = MPI_occupied_squares_row_number++;
	      
	      MPI_occupied_squares_row_indices(i) = MPI_occupied_squares_index;
	    }
	}
    }
  
#endif
  
  if (!is_it_MPI_parallelized_local)
    {
      MPI_occupied_squares_row_number = 1;
            
      MPI_occupied_squares_row_indices(0) = 0;

      MPI_row_processes(0) = THIS_PROCESS;
  
      MPI_row_group_master_processes(0) = THIS_PROCESS;

      MPI_are_squares_occupied(0) = true;
    }
}





  

void GSM_vector_helper_class::allocate (
					const bool is_it_MPI_parallelized_local_c ,
					const enum space_type space_c , 
					const enum interaction_type inter_c , 
					const bool is_it_pole_approximation_c , 
					const bool truncation_hw_c , 
					const bool truncation_ph_c ,
					const int n_holes_max_c , 
					const int n_scat_max_c , 
					const int E_max_hw_c , 
					const int n_holes_max_p_c , 
					const int n_scat_max_p_c , 
					const int Ep_max_hw_c , 
					const int n_holes_max_n_c ,
					const int n_scat_max_n_c , 
					const int En_max_hw_c , 
					const unsigned int BP_c , 
					const double M_c , 
					const bool is_it_TRS_for_M_zero ,
					class nucleons_data &prot_data , 
					class nucleons_data &neut_data)

{
  if (is_it_filled ()) error_message_print_abort ("GSM_vector_helper_class cannot be allocated twice in GSM_vector_helper_class::allocate");

  is_it_MPI_parallelized_local = is_it_MPI_parallelized_local_c;

  space = space_c; 

  inter = inter_c; 

  is_it_pole_approximation = is_it_pole_approximation_c;

  truncation_hw = truncation_hw_c; 
  truncation_ph = truncation_ph_c; 

  n_holes_max = n_holes_max_c; 

  n_holes_max_p = n_holes_max_p_c; 
  n_holes_max_n = n_holes_max_n_c;
  
  n_scat_max = n_scat_max_c; 

  n_scat_max_p = n_scat_max_p_c; 
  n_scat_max_n = n_scat_max_n_c; 

  E_max_hw = E_max_hw_c; 

  Ep_max_hw = Ep_max_hw_c; 
  En_max_hw = En_max_hw_c; 

  BP = BP_c; 

  M = M_c; 

  const double M_max = M_max_calc (space , prot_data , neut_data);
  
  const int iMp_max = prot_data.get_iM_max ();
  const int iMn_max = neut_data.get_iM_max ();

  const int n_scat_max_plus_one   = n_scat_max   + 1;
  const int n_scat_max_p_plus_one = n_scat_max_p + 1;
  const int n_scat_max_n_plus_one = n_scat_max_n + 1;
  
  iM = make_int (M + M_max);

  TRS_iM = make_int (-M + M_max);

  iMp_min_M = max (0 , iM - iMn_max);
  iMn_min_M = max (0 , iM - iMp_max);
    
  iMp_max_M = min (iMp_max , iM); 
  iMn_max_M = min (iMn_max , iM);

  const int iMp_max_M_plus_one = iMp_max_M + 1;
  const int iMn_max_M_plus_one = iMn_max_M + 1;
  
  is_it_TRS = is_it_TRS_for_M_zero && (TRS_iM == iM);
    
  Jmax = M_max_dimension_non_zero_calc (BP , space , truncation_hw , truncation_ph , 
					n_holes_max_p , n_scat_max_p , Ep_max_hw ,
					n_holes_max_n , n_scat_max_n , En_max_hw ,
					n_holes_max   , n_scat_max   , E_max_hw  ,  prot_data , neut_data);

  total_space_dimension = total_space_dimension_M_calc (space , truncation_hw , truncation_ph , 
							n_holes_max_p , n_scat_max_p , Ep_max_hw ,
							n_holes_max_n , n_scat_max_n , En_max_hw ,
							n_holes_max   , n_scat_max   , E_max_hw  ,  prot_data , neut_data , BP , M);

  prot_data_ptr = &prot_data;
  neut_data_ptr = &neut_data;

  const unsigned int N = (is_it_MPI_parallelized_local) ? (NUMBER_OF_PROCESSES) : (1);
  
  space_dimensions_all_processes.allocate (N);

  space_dimensions_all_processes = space_dimension_process = space_dimensions_all_processes_max = total_space_dimension;
   
  first_total_PSI_indices.allocate (N);

  first_total_PSI_indices = total_space_dimension;
	
  last_total_PSI_indices.allocate (N);

  last_total_PSI_indices = total_space_dimension;
  
  if (is_it_MPI_parallelized_local)
    {
      for (unsigned int i = 0 ; i < N ; i++) space_dimensions_all_processes(i) = process_dimension_determine (total_space_dimension , N , i);

      space_dimension_process = space_dimensions_all_processes(THIS_PROCESS);
	
      space_dimensions_all_processes_max = space_dimensions_all_processes.max ();
   
      unsigned int vector_index_shift = 0;
  
      for (unsigned int i = 0 ; i < N ; i++)
	{
	  const unsigned int space_dimension_process = space_dimensions_all_processes(i);
      
	  if (space_dimension_process > 0)
	    {
	      const unsigned long int first_total_PSI_index = vector_index_shift;
	      const unsigned long int last_total_PSI_index = first_total_PSI_index + space_dimension_process - 1;

	      first_total_PSI_indices(i) = first_total_PSI_index;
	      last_total_PSI_indices(i) = last_total_PSI_index;
	  
	      vector_index_shift += space_dimension_process;
	    }
	}

      first_total_PSI_index = first_total_PSI_indices(THIS_PROCESS);
      last_total_PSI_index = last_total_PSI_indices(THIS_PROCESS);
    }
  else
    {      
      first_total_PSI_indices(0) = first_total_PSI_index = 0;
	
      last_total_PSI_indices(0) = last_total_PSI_index = total_space_dimension - 1;
    }
  
  if (space_dimensions_all_processes_max > 0)
    {
      const int TRS_iMp_min_M = max (0 , TRS_iM - iMn_max);
      const int TRS_iMn_min_M = max (0 , TRS_iM - iMp_max);

      const int TRS_iMp_max_M = min (iMp_max , TRS_iM);
      const int TRS_iMn_max_M = min (iMn_max , TRS_iM);
      
      sum_dimensions_GSM_vector.allocate (space , truncation_hw , truncation_ph , 
					  n_holes_max_p , n_scat_max_p , Ep_max_hw ,
					  n_holes_max_n , n_scat_max_n , En_max_hw ,
					  n_holes_max   , n_scat_max   , E_max_hw  , 
					  prot_data , neut_data , BP , iM , iMp_min_M , iMp_max_M , iMn_min_M , iMn_max_M);
      
      sum_dimensions_GSM_vector_TRS.allocate (space , truncation_hw , truncation_ph , 
					      n_holes_max_p , n_scat_max_p , Ep_max_hw ,
					      n_holes_max_n , n_scat_max_n , En_max_hw ,
					      n_holes_max   , n_scat_max   , E_max_hw  , 
					      prot_data , neut_data , BP , TRS_iM , TRS_iMp_min_M , TRS_iMp_max_M , TRS_iMn_min_M , TRS_iMn_max_M);
      
      const unsigned int prot_dimension_configuration_max = prot_data.get_dimension_configuration_max ();
      const unsigned int neut_dimension_configuration_max = neut_data.get_dimension_configuration_max ();
  
      const unsigned long int prot_dimension_SD_total = prot_data.get_dimension_SD_total ();
      const unsigned long int neut_dimension_SD_total = neut_data.get_dimension_SD_total ();
	  
      if (space == PROTONS_NEUTRONS)
	{
	  iCp_min_tab.allocate (2 , n_scat_max_p_plus_one , N);
	  iCp_max_tab.allocate (2 , n_scat_max_p_plus_one , N);
	  
	  iCn_min_tab.allocate (2 , n_scat_max_n_plus_one , N);	  
	  iCn_max_tab.allocate (2 , n_scat_max_n_plus_one , N);
	  
	  iCp_min_tab = prot_dimension_configuration_max;
	  iCp_max_tab = 0;
	  
	  iCn_min_tab = neut_dimension_configuration_max;
  	  iCn_max_tab = 0;

	  iCp_min_process_tab.allocate (2 , n_scat_max_p_plus_one);
	  iCp_max_process_tab.allocate (2 , n_scat_max_p_plus_one);
	  
	  iCn_min_process_tab.allocate (2 , n_scat_max_n_plus_one);	  
	  iCn_max_process_tab.allocate (2 , n_scat_max_n_plus_one);
	  
	  iCp_min_process_tab = prot_dimension_configuration_max;
	  iCp_max_process_tab = 0;
	  
	  iCn_min_process_tab = neut_dimension_configuration_max;  
	  iCn_max_process_tab = 0;

	  total_SDp_index_min_tab.allocate (N);
	  total_SDp_index_max_tab.allocate (N);
	  
	  total_SDn_index_min_tab.allocate (N);	  
	  total_SDn_index_max_tab.allocate (N);
	  
	  total_SDp_index_min_tab = prot_dimension_SD_total;
	  total_SDp_index_max_tab = 0;
	  
	  total_SDn_index_min_tab = neut_dimension_SD_total;  
	  total_SDn_index_max_tab = 0;

	  total_SDp_index_min = prot_dimension_SD_total;
	  total_SDp_index_max = 0;
	  
	  total_SDn_index_min = neut_dimension_SD_total;
	  total_SDn_index_max = 0;
	}
      else
	{
	  const unsigned int dimension_configuration_max = (space == PROTONS_ONLY) ? (prot_dimension_configuration_max) : (neut_dimension_configuration_max);
	  
	  const unsigned long int dimension_SD_total = (space == PROTONS_ONLY) ? (prot_dimension_SD_total) : (neut_dimension_SD_total);
      
	  iC_min_tab.allocate (n_scat_max_plus_one , N);
	  iC_max_tab.allocate (n_scat_max_plus_one , N);
	  
	  iC_min_process_tab.allocate (n_scat_max_plus_one);
	  iC_max_process_tab.allocate (n_scat_max_plus_one);
	  
	  iC_min_tab = dimension_configuration_max;
	  iC_max_tab = 0;

	  iC_min_process_tab = dimension_configuration_max;
	  iC_max_process_tab = 0;
	  
	  total_SD_index_min_tab.allocate (N);
	  total_SD_index_max_tab.allocate (N);

	  total_SD_index_min_tab = dimension_SD_total;
	  total_SD_index_max_tab = 0;
			  
	  total_SD_index_min = dimension_SD_total;
	  total_SD_index_max = 0;
	}
      
      configuration_total_SDp_SDn_indices_min_max_calc_store ();
      
      if (space == PROTONS_NEUTRONS)
	{
	  const unsigned int dimension_configuration_total_p = prot_data.get_dimension_configuration_total ();
	  const unsigned int dimension_configuration_total_n = neut_data.get_dimension_configuration_total ();

	  const class array<unsigned int> &sum_dimensions_configuration_set_p = prot_data.get_sum_dimensions_configuration_set ();
	  const class array<unsigned int> &sum_dimensions_configuration_set_n = neut_data.get_sum_dimensions_configuration_set ();

	  all_dimensions_SDp_zero_tab.allocate (dimension_configuration_total_n , sum_dimensions_configuration_set_n , iMn_max_M_plus_one);
	  all_dimensions_SDn_zero_tab.allocate (dimension_configuration_total_p , sum_dimensions_configuration_set_p , iMp_max_M_plus_one);
	  
	  all_dimensions_SDp_zero_tabs_calc ();
	  all_dimensions_SDn_zero_tabs_calc ();
	}
      
      TRS_total_PSI_indices.allocate (space_dimensions_all_processes_max);
      
      TRS_bin_phases.allocate (space_dimensions_all_processes_max);
      
      TRS_data_calc_store ();
    }
  
  allocate_MPI_part ();
}





void GSM_vector_helper_class::allocate_fill (const class GSM_vector_helper_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("GSM_vector_helper_class cannot be allocated twice in GSM_vector_helper_class::allocate_fill");
  
  is_it_MPI_parallelized_local = X.is_it_MPI_parallelized_local;

  space = X.space; 

  inter = X.inter; 

  is_it_pole_approximation = X.is_it_pole_approximation;

  truncation_hw = X.truncation_hw; 
  truncation_ph = X.truncation_ph; 

  n_holes_max = X.n_holes_max; 

  n_holes_max_p = X.n_holes_max_p; 
  n_holes_max_n = X.n_holes_max_n;
  
  n_scat_max = X.n_scat_max; 

  n_scat_max_p = X.n_scat_max_p; 
  n_scat_max_n = X.n_scat_max_n; 

  E_max_hw = X.E_max_hw; 

  Ep_max_hw = X.Ep_max_hw; 
  En_max_hw = X.En_max_hw; 

  BP = X.BP; 

  M = X.M; 
  
  iM = X.iM;
  TRS_iM = X.TRS_iM;

  iMp_min_M = X.iMp_min_M;
  iMp_max_M = X.iMp_max_M;

  iMn_min_M = X.iMn_min_M;
  iMn_max_M = X.iMn_max_M;

  is_it_TRS = X.is_it_TRS;
  
  Jmax = X.Jmax;

  total_space_dimension = X.total_space_dimension;

  space_dimension_process = X.space_dimension_process;

  space_dimensions_all_processes_max = X.space_dimensions_all_processes_max;

  prot_data_ptr = X.prot_data_ptr;
  neut_data_ptr = X.neut_data_ptr;
    
  space_dimensions_all_processes.allocate_fill (X.space_dimensions_all_processes);

  first_total_PSI_index = X.first_total_PSI_index;
  last_total_PSI_index = X.last_total_PSI_index;
    
  total_SDp_index_min = X.total_SDp_index_min;
  total_SDp_index_max = X.total_SDp_index_max;
  
  total_SDn_index_min = X.total_SDn_index_min;
  total_SDn_index_max = X.total_SDn_index_max;
    
  first_total_PSI_indices.allocate_fill (X.first_total_PSI_indices);
  last_total_PSI_indices.allocate_fill (X.last_total_PSI_indices);
  
  iCp_min_tab.allocate_fill (X.iCp_min_tab);
  iCp_max_tab.allocate_fill (X.iCp_max_tab);
  
  iCn_min_tab.allocate_fill (X.iCn_min_tab);
  iCn_max_tab.allocate_fill (X.iCn_max_tab);
  
  iCp_min_process_tab.allocate_fill (X.iCp_min_process_tab);
  iCp_max_process_tab.allocate_fill (X.iCp_max_process_tab);
  
  iCn_min_process_tab.allocate_fill (X.iCn_min_process_tab);
  iCn_max_process_tab.allocate_fill (X.iCn_max_process_tab);
  
  iC_min_tab.allocate_fill (X.iC_min_tab);
  iC_max_tab.allocate_fill (X.iC_max_tab);
  
  iC_min_process_tab.allocate_fill (X.iC_min_process_tab);
  iC_max_process_tab.allocate_fill (X.iC_max_process_tab);  
  
  total_SDp_index_min_tab.allocate_fill (X.total_SDp_index_min_tab);
  total_SDp_index_max_tab.allocate_fill (X.total_SDp_index_max_tab);
  
  total_SDn_index_min_tab.allocate_fill (X.total_SDn_index_min_tab);
  total_SDn_index_max_tab.allocate_fill (X.total_SDn_index_max_tab);
  
  sum_dimensions_GSM_vector.allocate_fill (X.sum_dimensions_GSM_vector);
  sum_dimensions_GSM_vector_TRS.allocate_fill (X.sum_dimensions_GSM_vector_TRS);

  if (space == PROTONS_NEUTRONS)
    {
      all_dimensions_SDp_zero_tab.allocate_fill (X.all_dimensions_SDp_zero_tab);
      all_dimensions_SDn_zero_tab.allocate_fill (X.all_dimensions_SDn_zero_tab);
    }

  TRS_total_PSI_indices.allocate_fill (X.TRS_total_PSI_indices);
      
  TRS_bin_phases.allocate_fill (X.TRS_bin_phases);
  
  allocate_MPI_part ();
}







void GSM_vector_helper_class::deallocate ()
{
  space_dimensions_all_processes.deallocate ();

  first_total_PSI_indices.deallocate ();
  last_total_PSI_indices.deallocate ();
  
  iCp_min_tab.deallocate ();
  iCp_max_tab.deallocate ();
  
  iCn_min_tab.deallocate ();
  iCn_max_tab.deallocate ();
  
  iCp_min_process_tab.deallocate ();
  iCp_max_process_tab.deallocate ();
  
  iCn_min_process_tab.deallocate ();
  iCn_max_process_tab.deallocate ();
  
  iC_min_tab.deallocate ();
  iC_max_tab.deallocate ();
  
  iC_min_process_tab.deallocate ();
  iC_max_process_tab.deallocate ();
  
  total_SDp_index_min_tab.deallocate ();
  total_SDp_index_max_tab.deallocate ();
  
  total_SDn_index_min_tab.deallocate ();
  total_SDn_index_max_tab.deallocate ();
  
  total_SD_index_min_tab.deallocate ();
  total_SD_index_max_tab.deallocate ();
  
  sum_dimensions_GSM_vector.deallocate ();
  sum_dimensions_GSM_vector_TRS.deallocate ();

  all_dimensions_SDp_zero_tab.deallocate ();
  all_dimensions_SDn_zero_tab.deallocate ();

  TRS_total_PSI_indices.deallocate ();
  
  TRS_bin_phases.deallocate ();

#ifdef UseMPI
  
  const unsigned int N = MPI_row_communicators.dimension (0);
  
  for (unsigned int i = 0 ; i < N ; i++)
    {
      MPI_Comm &MPI_row_communicator = MPI_row_communicators(i);
	  
      if (MPI_row_communicator != MPI_COMM_SELF) MPI_helper::Comm_free (MPI_row_communicator);
    }
  
  MPI_row_communicators.deallocate ();

#endif

  MPI_row_processes.deallocate ();

  MPI_row_group_master_processes.deallocate ();

  MPI_are_squares_occupied.deallocate ();

  MPI_occupied_squares_row_indices.deallocate ();
  
  is_it_MPI_parallelized_local = false;

  space = NO_SPACE;

  inter = NO_INTERACTION;

  is_it_pole_approximation = false;

  truncation_hw = false;
  truncation_ph = false; 

  n_scat_max = 0;

  n_scat_max_p = 0;
  n_scat_max_n = 0;

  n_holes_max = 0;

  n_holes_max_p = 0;
  n_holes_max_n = 0;
  
  E_max_hw = 0; 

  Ep_max_hw = 0; 
  En_max_hw = 0; 

  BP = 0; 

  M = 0.0;  

  iM = 0; 

  TRS_iM = 0; 

  iMp_min_M = 0; 
  iMp_max_M = 0; 

  iMn_min_M = 0; 
  iMn_max_M = 0;

  is_it_TRS = false;

  Jmax = 0.0; 

  total_space_dimension = 0;

  space_dimension_process = 0;

  space_dimensions_all_processes_max = 0;

  first_total_PSI_index = 0;

  last_total_PSI_index = 0;

  total_SDp_index_min = 0;
  total_SDp_index_max = 0;

  total_SDn_index_min = 0;
  total_SDn_index_max = 0;

  prot_data_ptr = NULL; 
  neut_data_ptr = NULL;
}





void GSM_vector_helper_class::allocate_fill_with_MPI_parallelization (const class GSM_vector_helper_class &X)
{
  if (X.is_it_MPI_parallelized_local)
    allocate_fill (X);
  else
    {
      const enum space_type space_c = X.space; 

      const enum interaction_type inter_c = X.inter; 

      const bool is_it_pole_approximation_c = X.is_it_pole_approximation;

      const bool truncation_hw_c = X.truncation_hw;
      const bool truncation_ph_c = X.truncation_ph;

      const int n_holes_max_c = X.n_holes_max;

      const int n_scat_max_c = X.n_scat_max;

      const int E_max_hw_c = X.E_max_hw;

      const int n_holes_max_p_c = X.n_holes_max_p;
      const int n_holes_max_n_c = X.n_holes_max_n;
      
      const int n_scat_max_p_c = X.n_scat_max_p;
      const int n_scat_max_n_c = X.n_scat_max_n;

      const int Ep_max_hw_c = X.Ep_max_hw; 
      const int En_max_hw_c = X.En_max_hw;
  
      const unsigned int BP_c = X.BP; 

      const double M_c = X.M; 

      const bool is_it_TRS_c = X.is_it_TRS;

      class nucleons_data &prot_data = X.get_prot_data ();
      class nucleons_data &neut_data = X.get_neut_data ();
  
      allocate (true , space_c , inter_c , is_it_pole_approximation_c , truncation_hw_c , truncation_ph_c ,
		n_holes_max_c   , n_scat_max_c   , E_max_hw_c ,
		n_holes_max_p_c , n_scat_max_p_c , Ep_max_hw_c ,
		n_holes_max_n_c , n_scat_max_n_c , En_max_hw_c , BP_c , M_c , is_it_TRS_c , prot_data , neut_data);
    }
}


void GSM_vector_helper_class::allocate_fill_without_MPI_parallelization (const class GSM_vector_helper_class &X)
{
  if (!X.is_it_MPI_parallelized_local) 
    allocate_fill (X);
  else
    {
      const enum space_type space_c = X.space; 

      const enum interaction_type inter_c = X.inter; 

      const bool is_it_pole_approximation_c = X.is_it_pole_approximation;

      const bool truncation_hw_c = X.truncation_hw;
      const bool truncation_ph_c = X.truncation_ph;

      const int n_holes_max_c = X.n_holes_max;

      const int n_scat_max_c = X.n_scat_max;

      const int E_max_hw_c = X.E_max_hw;

      const int n_holes_max_p_c = X.n_holes_max_p;
      const int n_holes_max_n_c = X.n_holes_max_n;
      
      const int n_scat_max_p_c = X.n_scat_max_p;
      const int n_scat_max_n_c = X.n_scat_max_n;

      const int Ep_max_hw_c = X.Ep_max_hw; 
      const int En_max_hw_c = X.En_max_hw;
  
      const unsigned int BP_c = X.BP; 

      const double M_c = X.M; 

      const bool is_it_TRS_c = X.is_it_TRS;

      class nucleons_data &prot_data = X.get_prot_data ();
      class nucleons_data &neut_data = X.get_neut_data ();
  
      allocate (false , space_c , inter_c , is_it_pole_approximation_c , truncation_hw_c , truncation_ph_c ,
		n_holes_max_c   , n_scat_max_c   , E_max_hw_c ,
		n_holes_max_p_c , n_scat_max_p_c , Ep_max_hw_c ,
		n_holes_max_n_c , n_scat_max_n_c , En_max_hw_c , BP_c , M_c , is_it_TRS_c , prot_data , neut_data);
    }
}



void GSM_vector_helper_class::configuration_total_SDp_SDn_indices_min_max_calc_store ()
{
  const unsigned int N = (is_it_MPI_parallelized_local) ? (NUMBER_OF_PROCESSES) : (1);
  
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  if (space == PROTONS_NEUTRONS)
    {
      const class array<unsigned int> &dimensions_configuration_set_p = prot_data.get_dimensions_configuration_set ();
      const class array<unsigned int> &dimensions_configuration_set_n = neut_data.get_dimensions_configuration_set ();

      const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
      const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
      
      const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
      const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();

      const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
      const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
      
      const class array_of_SD &SDp_set = prot_data.get_SD_set ();
      const class array_of_SD &SDn_set = neut_data.get_SD_set ();

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	{ 
	  const unsigned long int first_total_PSI_index_square_row = first_total_PSI_indices(square_row_index);
	  const unsigned long int last_total_PSI_index_square_row = last_total_PSI_indices(square_row_index);
					      
	  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
	    {
	      const unsigned int BPn = binary_parity_product (BPp , BP);

	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int dimension_configuration_p = dimensions_configuration_set_p(BPp , n_scat_p);

		  unsigned int &iCp_min_square_row = iCp_min_tab(BPp , n_scat_p , square_row_index);
		  unsigned int &iCp_max_square_row = iCp_max_tab(BPp , n_scat_p , square_row_index);
	  
		  for (unsigned int iCp = 0 ; iCp < dimension_configuration_p ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);
		  
		      const int Ep_hw = Ep_hw_table(BPp , n_scat_p , iCp);
		      
		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

		      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
			{
			  const unsigned int dimension_configuration_n = dimensions_configuration_set_n(BPn , n_scat_n);

			  unsigned int &iCn_min_square_row = iCn_min_tab(BPn , n_scat_n , square_row_index);
			  unsigned int &iCn_max_square_row = iCn_max_tab(BPn , n_scat_n , square_row_index);
				  
			  for (unsigned int iCn = 0 ; iCn < dimension_configuration_n ; iCn++)
			    {
			      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
			      const int En_hw = En_hw_table(BPn , n_scat_n , iCn);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
					  
			      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
				{
				  const int iMn = iM - iMp;
				  
				  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);
				  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

				  if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

				  const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , n_scat_p , n_scat_n , iCp , iCn , iMp);
				  
				  const unsigned long int total_SDp_zero_index = SDp_set.index_determine (BPp , n_scat_p , iCp , iMp , 0);
				  const unsigned long int total_SDn_zero_index = SDn_set.index_determine (BPn , n_scat_n , iCn , iMn , 0);
					  
				  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
				    {
				      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;
				      const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDn_minus_one;
				  
				      if ((total_PSI_index_zero <= last_total_PSI_index_square_row) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index_square_row))
					{
					  const unsigned long int total_SDp_index = total_SDp_zero_index + SDp_index;
					  
					  unsigned long int &total_SDp_index_min_square_row = total_SDp_index_min_tab(square_row_index);
					  unsigned long int &total_SDp_index_max_square_row = total_SDp_index_max_tab(square_row_index);
					  
					  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
					    {
					      const unsigned long int total_PSI_index = total_PSI_index_zero + SDn_index;
  
					      if ((total_PSI_index >= first_total_PSI_index_square_row) && (total_PSI_index <= last_total_PSI_index_square_row))
						{
						  const unsigned long int total_SDn_index = total_SDn_zero_index + SDn_index;
					  
						  unsigned long int &total_SDn_index_min_square_row = total_SDn_index_min_tab(square_row_index);
						  unsigned long int &total_SDn_index_max_square_row = total_SDn_index_max_tab(square_row_index);
			  
						  iCp_min_square_row = min (iCp_min_square_row , iCp);
						  iCp_max_square_row = max (iCp_max_square_row , iCp);
						  
						  iCn_min_square_row = min (iCn_min_square_row , iCn);
						  iCn_max_square_row = max (iCn_max_square_row , iCn);
						  
						  total_SDp_index_min_square_row = min (total_SDp_index_min_square_row , total_SDp_index);
						  total_SDp_index_max_square_row = max (total_SDp_index_max_square_row , total_SDp_index);
						  
						  total_SDn_index_min_square_row = min (total_SDn_index_min_square_row , total_SDn_index);
						  total_SDn_index_max_square_row = max (total_SDn_index_max_square_row , total_SDn_index);

						}}}}}}}}}}}

      if (is_it_MPI_parallelized_local)
	{
	  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
	    for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	      {
		iCp_min_process_tab(BPp , n_scat_p) = iCp_min_tab(BPp , n_scat_p , THIS_PROCESS);
		iCp_max_process_tab(BPp , n_scat_p) = iCp_max_tab(BPp , n_scat_p , THIS_PROCESS);
	      }

	  for (unsigned int BPn = 0 ; BPn <= 1 ; BPn++)
	    for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	      {
		iCn_min_process_tab(BPn , n_scat_n) = iCn_min_tab(BPn , n_scat_n , THIS_PROCESS);
		iCn_max_process_tab(BPn , n_scat_n) = iCn_max_tab(BPn , n_scat_n , THIS_PROCESS);
	      }
	  
	  total_SDp_index_min = total_SDp_index_min_tab(THIS_PROCESS);
	  total_SDp_index_max = total_SDp_index_max_tab(THIS_PROCESS);

	  total_SDn_index_min = total_SDn_index_min_tab(THIS_PROCESS);
	  total_SDn_index_max = total_SDn_index_max_tab(THIS_PROCESS);
	}
      else
	{
	  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
	    for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	      {
		iCp_min_process_tab(BPp , n_scat_p) = iCp_min_tab(BPp , n_scat_p , 0);
		iCp_max_process_tab(BPp , n_scat_p) = iCp_max_tab(BPp , n_scat_p , 0);
	      }

	  for (unsigned int BPn = 0 ; BPn <= 1 ; BPn++)
	    for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	      {
		iCn_min_process_tab(BPn , n_scat_n) = iCn_min_tab(BPn , n_scat_n , 0);
		iCn_max_process_tab(BPn , n_scat_n) = iCn_max_tab(BPn , n_scat_n , 0);
	      }
	  
	  total_SDp_index_min = total_SDp_index_min_tab(0);
	  total_SDp_index_max = total_SDp_index_max_tab(0);

	  total_SDn_index_min = total_SDn_index_min_tab(0);
	  total_SDn_index_max = total_SDn_index_max_tab(0);
	}
    }
  else
    {
      const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);
            
      const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();
      
      const class array_BP_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
        
      const class array_BP_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
      
      const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();	
       
      const class array_of_SD &SD_set = data.get_SD_set ();
      
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	{ 
	  const unsigned long int first_total_PSI_index_square_row = first_total_PSI_indices(square_row_index);
	  const unsigned long int last_total_PSI_index_square_row = last_total_PSI_indices(square_row_index);
	  
	  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
	    {
	      const unsigned int dimension_configuration = dimensions_configuration_set(BP , n_scat);

	      unsigned int &iC_min_square_row = iC_min_tab(n_scat , square_row_index);
	      unsigned int &iC_max_square_row = iC_max_tab(n_scat , square_row_index);
	 
	      for (unsigned int iC = 0 ; iC < dimension_configuration ; iC++)
		{
		  const int n_holes = n_holes_table(BP , n_scat , iC);
	      	  
		  const int E_hw = E_hw_table(BP , n_scat , iC);
	      
		  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
	      
		  const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions_GSM_vector(n_scat , iC);
		  const unsigned int dimension_SD_set = dimensions_SD_set(BP , n_scat , iC , iM);
		  const unsigned long int total_SD_zero_index = SD_set.index_determine (BP , n_scat , iC , iM , 0);
		  
		  for (unsigned int SD_index = 0 ; SD_index < dimension_SD_set ; SD_index++)
		    {
		      const unsigned long int total_PSI_index = sum_dimensions_configuration_fixed + SD_index;
		  
		      if ((total_PSI_index >= first_total_PSI_index_square_row) && (total_PSI_index <= last_total_PSI_index_square_row))
			{
			  const unsigned long int total_SD_index = total_SD_zero_index + SD_index;
						      
			  unsigned long int &total_SD_index_min_square_row = total_SD_index_min_tab(square_row_index);
			  unsigned long int &total_SD_index_max_square_row = total_SD_index_max_tab(square_row_index);
					      
			  iC_min_square_row = min (iC_min_square_row , iC);
			  iC_max_square_row = max (iC_max_square_row , iC);
			  
			  total_SD_index_min_square_row = min (total_SD_index_min_square_row , total_SD_index);
			  total_SD_index_max_square_row = max (total_SD_index_max_square_row , total_SD_index);
			}}}}
	}
      
      if (is_it_MPI_parallelized_local)
	{
	  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
	    {
	      iC_min_process_tab(n_scat) = iC_min_tab(n_scat , THIS_PROCESS);
	      iC_max_process_tab(n_scat) = iC_max_tab(n_scat , THIS_PROCESS);
	    }
	  
	  total_SD_index_min = total_SD_index_min_tab(THIS_PROCESS);
	  total_SD_index_max = total_SD_index_max_tab(THIS_PROCESS);
	}
      else
	{
	  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
	    {
	      iC_min_process_tab(n_scat) = iC_min_tab(n_scat , 0);
	      iC_max_process_tab(n_scat) = iC_max_tab(n_scat , 0);
	      
	      total_SD_index_min = total_SD_index_min_tab(0);
	      total_SD_index_max = total_SD_index_max_tab(0);
	    }
	}      
    }
}

































void GSM_vector_helper_class::all_dimensions_SDp_zero_tabs_calc ()
{
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();

  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
        
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();

  const class array<unsigned int> &dimensions_configuration_set_p = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_set_n = neut_data.get_dimensions_configuration_set ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  all_dimensions_SDp_zero_tab = true;
		  
  for (unsigned int BPn = 0 ; BPn <= 1 ; BPn++)
    {
      const unsigned int BPp = binary_parity_product (BPn , BP);

      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	{
	  const unsigned int dimension_iCn = dimensions_configuration_set_n(BPn , n_scat_n);

	  for (unsigned int iCn = 0 ; iCn < dimension_iCn ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
			      
	      const int En_hw = En_hw_table(BPn , n_scat_n , iCn);
			
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
			      
	      for (int iMn = iMn_min_M ; iMn <= iMn_max_M ; iMn++)   
		{
		  const int iMp = iM - iMn;
		  
		  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

		  bool positive_dimension_found = false;

		  if (dimension_SDn > 0)
		    {
		      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && !positive_dimension_found ; n_scat_p++)
			{
			  const unsigned int dimension_iCp = dimensions_configuration_set_p(BPp , n_scat_p);
	  
			  for (unsigned int iCp = 0 ; (iCp < dimension_iCp) && !positive_dimension_found ; iCp++)
			    {		  
			      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);
			      
			      const int Ep_hw = Ep_hw_table(BPp , n_scat_p , iCp);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
		  
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				
			      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);
				  
			      if (dimension_SDp > 0) positive_dimension_found = true;
			      
			    }}}
		  
		  if (positive_dimension_found) all_dimensions_SDp_zero_tab(BPn , n_scat_n , iCn , iMn) = false;
		  
		}}}}
}




void GSM_vector_helper_class::all_dimensions_SDn_zero_tabs_calc ()
{
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();

  const class array<unsigned int> &dimensions_configuration_set_p = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_set_n = neut_data.get_dimensions_configuration_set ();

  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
        
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  all_dimensions_SDn_zero_tab = true;
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP);

      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int dimension_iCp = dimensions_configuration_set_p(BPp , n_scat_p);

	  for (unsigned int iCp = 0 ; iCp < dimension_iCp ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);
	      
	      const int Ep_hw = Ep_hw_table(BPp , n_scat_p , iCp);
			   
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
			      
	      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
		{
		  const int iMn = iM - iMp;
		  
		  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);
		  
		  bool positive_dimension_found = false;

		  if (dimension_SDp > 0)
		    {
		      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && !positive_dimension_found ; n_scat_n++)
			{	
			  const unsigned int dimension_iCn = dimensions_configuration_set_n(BPn , n_scat_n);
	  
			  for (unsigned int iCn = 0 ; (iCn < dimension_iCn) && !positive_dimension_found ; iCn++)
			    {
			      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
			  
			      const int En_hw = En_hw_table(BPn , n_scat_n , iCn);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
							
			      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

			      if (dimension_SDn > 0) positive_dimension_found = true;
				
			    }}}
		  
		  if (positive_dimension_found) all_dimensions_SDn_zero_tab(BPp , n_scat_p , iCp , iMp) = false;
		  
		}}}}
}







void GSM_vector_helper_class::TRS_data_calc_store ()
{
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
    
  TRS_total_PSI_indices = total_space_dimension + 1;
  
  TRS_bin_phases = 0;
  
  if (space == PROTONS_NEUTRONS)
    { 
      const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
      const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
      
      const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
      const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();

      const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
      const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

      const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_data.get_SD_TRS_indices ();
      const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_data.get_SD_TRS_indices ();

      const class array_BP_Nscat_iC_iM_SD<unsigned char> &SDp_TRS_bin_phases = prot_data.get_SD_TRS_bin_phases ();
      const class array_BP_Nscat_iC_iM_SD<unsigned char> &SDn_TRS_bin_phases = neut_data.get_SD_TRS_bin_phases ();

      const int iMp_max = prot_data.get_iM_max ();
  
      for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
	{
	  const unsigned int BPn = binary_parity_product (BPp , BP);

	  for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	    {
	      const unsigned int iCp_min = iCp_min_process_tab(BPp , n_scat_p);
	      const unsigned int iCp_max = iCp_max_process_tab(BPp , n_scat_p);

	      if (iCp_max < iCp_min) continue;
	  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
	      for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
		{
		  const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);
		  
		  const int Ep_hw = Ep_hw_table(BPp , n_scat_p , iCp);

		  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
		  
		  for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
		    {
		      const unsigned int iCn_min = iCn_min_process_tab(BPn , n_scat_n);
		      const unsigned int iCn_max = iCn_max_process_tab(BPn , n_scat_n);
			  
		      for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
			{
			  const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
			  			  
			  const int En_hw = En_hw_table(BPn , n_scat_n , iCn);

			  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		  
			  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			    
			  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
			    {
			      const int iMn = iM - iMp , TRS_iMp = iMp_max - iMp;

			      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);
			      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

			      if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

			      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , n_scat_p , n_scat_n , iCp , iCn , iMp);

			      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS = sum_dimensions_GSM_vector_TRS(BPp , n_scat_p , n_scat_n , iCp , iCn , TRS_iMp);

			      const unsigned long int total_SDp_TRS_indices_zero_index = SDp_TRS_indices.index_determine (BPp , n_scat_p , iCp , iMp , 0);
				  
			      const unsigned long int total_SDn_TRS_indices_zero_index = SDn_TRS_indices.index_determine (BPn , n_scat_n , iCn , iMn , 0);
				  
			      const unsigned long int total_SDp_TRS_bin_phases_zero_index = SDp_TRS_bin_phases.index_determine (BPp , n_scat_p , iCp , iMp , 0);
				  
			      const unsigned long int total_SDn_TRS_bin_phases_zero_index = SDn_TRS_bin_phases.index_determine (BPn , n_scat_n , iCn , iMn , 0);
				  
			      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
				{
				  const unsigned long int total_SDp_TRS_indices_index = total_SDp_TRS_indices_zero_index + SDp_index;

				  const unsigned int SDp_TRS_index = SDp_TRS_indices[total_SDp_TRS_indices_index];
				      
				  const unsigned long int total_SDp_TRS_bin_phases_index = total_SDp_TRS_bin_phases_zero_index + SDp_index;

				  const unsigned int SDp_TRS_bin_phase = SDp_TRS_bin_phases[total_SDp_TRS_bin_phases_index];

				  const unsigned long int total_PSI_index_zero_SDp = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;
				      
				  const unsigned long int TRS_total_PSI_index_zero_SDp = sum_dimensions_configuration_Mp_Mn_fixed_TRS + dimension_SDn*SDp_TRS_index;

				  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
				    {
				      const unsigned long int total_PSI_index = total_PSI_index_zero_SDp + SDn_index;
  
				      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
					{
					  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;
					      
					  const unsigned long int total_SDn_TRS_indices_index = total_SDn_TRS_indices_zero_index + SDn_index;

					  const unsigned int SDn_TRS_index = SDn_TRS_indices[total_SDn_TRS_indices_index];
					      
					  const unsigned long int total_SDn_TRS_bin_phases_index = total_SDn_TRS_bin_phases_zero_index + SDn_index;

					  const unsigned int SDn_TRS_bin_phase = SDn_TRS_bin_phases[total_SDn_TRS_bin_phases_index];

					  const unsigned long int TRS_total_PSI_index = TRS_total_PSI_index_zero_SDp + SDn_TRS_index;

					  const unsigned int SD_TRS_bin_phase = binary_parity_product (SDp_TRS_bin_phase , SDn_TRS_bin_phase);

					  TRS_total_PSI_indices(PSI_index) = TRS_total_PSI_index;
					      
					  TRS_bin_phases(PSI_index) = SD_TRS_bin_phase;
					}}}}}}}}}
    }
  else
    {
      const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);

      const class array_BP_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
      const class array_BP_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
      
      const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();
      
      const class array_BP_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = data.get_SD_TRS_indices ();
      
      const class array_BP_Nscat_iC_iM_SD<unsigned char> &SD_TRS_bin_phases = data.get_SD_TRS_bin_phases ();

      for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
	{
	  const unsigned int iC_min = iC_min_process_tab(n_scat);
	  const unsigned int iC_max = iC_max_process_tab(n_scat);

	  if (iC_max < iC_min) continue;
			  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
	  for (unsigned int iC = iC_min ; iC <= iC_max ; iC++)
	    {
	      const int n_holes = n_holes_table(BP , n_scat , iC);
	  
	      const int E_hw = E_hw_table(BP , n_scat , iC);
	      
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions_GSM_vector(n_scat , iC);
	      
	      const unsigned long int sum_dimensions_configuration_fixed_TRS = sum_dimensions_GSM_vector_TRS(n_scat , iC);

	      const unsigned int dimension_SD_set = dimensions_SD_set(BP , n_scat , iC , iM);

	      const unsigned long int total_SD_TRS_indices_zero_index = SD_TRS_indices.index_determine (BP , n_scat , iC , iM , 0);
				  
	      const unsigned long int total_SD_TRS_bin_phases_zero_index = SD_TRS_bin_phases.index_determine (BP , n_scat , iC , iM , 0);
				  
	      for (unsigned int SD_index = 0 ; SD_index < dimension_SD_set ; SD_index++)
		{
		  const unsigned long int total_PSI_index = sum_dimensions_configuration_fixed + SD_index;
		  
		  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
		    {
		      const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;
		      
		      const unsigned long int total_SD_TRS_indices_index = total_SD_TRS_indices_zero_index + SD_index;

		      const unsigned int SD_TRS_index = SD_TRS_indices[total_SD_TRS_indices_index];
		      
		      const unsigned long int total_SD_TRS_bin_phases_index = total_SD_TRS_bin_phases_zero_index + SD_index;

		      const unsigned int SD_TRS_bin_phase = SD_TRS_bin_phases[total_SD_TRS_bin_phases_index];
		      
		      const unsigned long int TRS_total_PSI_index = sum_dimensions_configuration_fixed_TRS + SD_TRS_index;
		  
		      TRS_total_PSI_indices(PSI_index) = TRS_total_PSI_index;

		      TRS_bin_phases(PSI_index) = SD_TRS_bin_phase;
		    }}}}}
}





bool GSM_vector_helper_class::same_parity_M_projection (const class GSM_vector_helper_class &GSM_vector_helper_other) const
{
  const unsigned int BP_other = GSM_vector_helper_other.get_BP ();

  if (BP != BP_other) return false;

  const int iM_other = GSM_vector_helper_other.get_iM ();

  if (iM != iM_other) return false;

  return true;
}




double used_memory_calc (const class GSM_vector_helper_class &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;
  
  const double used_memory_allocated_arrays = used_memory_calc (T.sum_dimensions_GSM_vector) + used_memory_calc (T.sum_dimensions_GSM_vector_TRS) + used_memory_calc (T.TRS_total_PSI_indices) + used_memory_calc (T.TRS_bin_phases) + used_memory_calc (T.all_dimensions_SDp_zero_tab) + used_memory_calc (T.all_dimensions_SDn_zero_tab) + used_memory_calc (T.space_dimensions_all_processes) + used_memory_calc (T.first_total_PSI_indices) + used_memory_calc (T.last_total_PSI_indices) + used_memory_calc (T.MPI_row_processes) + used_memory_calc (T.MPI_row_group_master_processes) + used_memory_calc (T.MPI_are_squares_occupied) + used_memory_calc (T.MPI_occupied_squares_row_indices) + used_memory_calc (T.iCp_min_tab) + used_memory_calc (T.iCp_max_tab) + used_memory_calc (T.iCn_min_tab) + used_memory_calc (T.iCn_max_tab) + used_memory_calc (T.iC_min_tab) + used_memory_calc (T.iC_max_tab) + used_memory_calc (T.iCp_min_process_tab) + used_memory_calc (T.iCp_max_process_tab) + used_memory_calc (T.iCn_min_process_tab) + used_memory_calc (T.iCn_max_process_tab) + used_memory_calc (T.iC_min_process_tab) + used_memory_calc (T.iC_max_process_tab) + used_memory_calc (T.total_SDp_index_min_tab) + used_memory_calc (T.total_SDp_index_max_tab) + used_memory_calc (T.total_SDn_index_min_tab) + used_memory_calc (T.total_SDn_index_max_tab) + used_memory_calc (T.total_SD_index_min_tab) + used_memory_calc (T.total_SD_index_max_tab) - (sizeof (T.sum_dimensions_GSM_vector) + sizeof (T.sum_dimensions_GSM_vector_TRS) + sizeof (T.TRS_total_PSI_indices) + sizeof (T.TRS_bin_phases) + sizeof (T.all_dimensions_SDp_zero_tab) + sizeof (T.all_dimensions_SDn_zero_tab) + sizeof (T.space_dimensions_all_processes) + sizeof (T.first_total_PSI_indices) + sizeof (T.last_total_PSI_indices) + sizeof (T.MPI_row_processes) + sizeof (T.MPI_row_group_master_processes) + sizeof (T.MPI_are_squares_occupied) + sizeof (T.MPI_occupied_squares_row_indices) + sizeof (T.iCp_min_tab) + sizeof (T.iCp_max_tab) + sizeof (T.iCn_min_tab) + sizeof (T.iCn_max_tab) + sizeof (T.iC_min_tab) + sizeof (T.iC_max_tab) + sizeof (T.iCp_min_process_tab) + sizeof (T.iCp_max_process_tab) + sizeof (T.iCn_min_process_tab) + sizeof (T.iCn_max_process_tab) + sizeof (T.iC_min_process_tab) + sizeof (T.iC_max_process_tab) + sizeof (T.total_SDp_index_min_tab) + sizeof (T.total_SDp_index_max_tab) + sizeof (T.total_SDn_index_min_tab) + sizeof (T.total_SDn_index_max_tab) + sizeof (T.total_SD_index_min_tab) + sizeof (T.total_SD_index_max_tab))/1000000.0;
   
#ifdef UseMPI
  const double MPI_row_communicators_memory = used_memory_calc (T.MPI_row_communicators) - sizeof (T.MPI_row_communicators)/1000000.0;
  
  const double used_memory = used_memory_constants + used_memory_allocated_arrays + MPI_row_communicators_memory;
#else
  const double used_memory = used_memory_constants + used_memory_allocated_arrays;
#endif

  return used_memory;
}

