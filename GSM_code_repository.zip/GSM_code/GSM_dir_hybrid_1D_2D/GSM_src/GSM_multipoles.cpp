#include "../GSM_include/GSM_include_def.h"

using namespace MPI_2D_partitioning;
using namespace inputs_misc;
using namespace correlated_state_routines;
using namespace configuration_SD_in_space_one_jump_out_to_in;
using namespace GSM_multipole_OBMEs_TBMEs;
using namespace GSM_vector_NBMEs_handling;
using namespace GSM_vector_NBMEs_handling::out_to_in;
using namespace GSM_vector_dimensions;


// TYPE is double or complex
// -------------------------


// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons (plus a few hyperons if any)
// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------





// Calculation of diagonal NBMEs of multipole operator
// ---------------------------------------------------
//
// Formulas are:
// <SD | multipole-op | SD> = \sum_i <i | Oi^2 | i> + \sum_{i < j} <i j | Oi.Oj | i j>
// In this notation, |SD> and |SD'> can contain protons and neutrons.
//
// pp, nn and pn parts are separated in NBMEs.
// The pp/nn parts are considered in NBME_diagonal_pp_nn_calc.
// The pn parts are considered in NBME_diagonal_pn_calc.
//
// Uncoupled OBMEs are always recalculated from coupled OBMEs.
// However, as multipole-op is a scalar, this amounts to checking if the OBME is equal to zero or to the coupled OBME from m conservation (see GSM_small_classes.cpp).

TYPE GSM_multipoles::diagonal_NBME_pp_nn_calc (
					       const int L ,
					       const bool is_it_HO_expansion ,
					       const class baryons_data &data ,
					       const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
					       const class Slater_determinant &SD)
{
  const unsigned int N_valence_baryons = SD.get_N_valence_baryons ();
    
  TYPE NBME = 0.0;
  
  for (unsigned int i = 0 ; i < N_valence_baryons ; i++) 
    {
      const unsigned int state_i = SD[i];
      
      NBME += uncoupled_OBME (L , is_it_HO_expansion , data , state_i , state_i);
    }

  for (unsigned int i = 0 ; i < N_valence_baryons ; i++)
    {
      const unsigned int state_i = SD[i];
      
      for (unsigned int ii = 0 ; ii < N_valence_baryons ; ii++)
	{
	  const unsigned int state_ii = SD[ii];
	  
	  if (state_i < state_ii) NBME += uncoupled_TBME_pp_nn_calc (L , is_it_HO_expansion , data , TBMEs_angular_table , state_i , state_ii , state_i , state_ii);
	}
    } 
  
  return NBME;
}

TYPE GSM_multipoles::diagonal_NBME_pn_calc (
					    const int L ,
					    const bool is_it_HO_expansion ,
					    const class baryons_data &prot_Y_data ,
					    const class baryons_data &neut_Y_data ,
					    const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
					    const class Slater_determinant &SDp , 
					    const class Slater_determinant &SDn)
{
  const unsigned int ZYval = SDp.get_N_valence_baryons ();
  const unsigned int NYval = SDn.get_N_valence_baryons ();

  TYPE NBME = 0.0;

  for (unsigned int p = 0 ; p < ZYval ; p++)
    {
      const unsigned int state_p = SDp[p];

      for (unsigned int n = 0 ; n < NYval ; n++)
	{
	  const unsigned int state_n = SDn[n];

	  NBME += uncoupled_TBME_pn_calc (L , is_it_HO_expansion , prot_Y_data , neut_Y_data , TBMEs_angular_table , state_p , state_n , state_p , state_n);
	}
    }
    
  return NBME;
}








// Calculation and storage of the diagonal matrix elements of multipole-op
// -----------------------------------------------------------------------
// One calculates here the diagonal matrix elements of multipole-op, of the form <SD | multipole-op | SD>. 
// <SD | multipole-op | SD> = \sum_i <i | h |i> + \sum_(i<j) <ij | V |ij>, with h and V the one-body and two-body parts of multipole-op.
// One separates the pp, nn and pn parts of <SD | multipole-op | SD> in the proton-neutron case.
//
// One loops over proton and neutron Slater determinants, the first loop being proton or neutron according to the case.
// As the same proton  NBME occurs for fixed SDp and varying SDn, it is calculated only once and reused for all such cases.
// As the same neutron NBME occurs for fixed SDn and varying SDp, it is calculated only once and reused for all such cases.
// For the pn part of multipole-op, one routine is used if NYval >= ZYval, and another if not, as SD indices are calculated differently in each case to optimize their use (see GSM_vector_dimensions.cpp).
//
// Uncoupled TBMEs are not used here as they are distributed with MPI over all nodes,
// A direct calculation of uncoupled TBMEs from coupled TBMEs is hence done therein for simplicity.
//
// OpenMP parallelization is used on the loop of proton or neutron Slater determinants.
// MPI parallelization here is only implicit, as on considers only the Slater determinants of the current node.


TYPE GSM_multipoles::diagonal_part_p_part_pn_calc (
						   const int L ,
						   const bool is_it_HO_expansion ,
						   const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
						   const class GSM_vector &PSI_IN_full ,
						   const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper = PSI_OUT.get_GSM_vector_helper ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM (); 

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 

  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
   
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
          
  const unsigned int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
      
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int total_SDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_SDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  if (total_SDp_index_min > total_SDp_index_max) return 0.0;
  
  class array<class Slater_determinant> SDp_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) SDp_tab(i).allocate (ZYval);
      
  double Re_multipole_ME = 0.0;
  double Im_multipole_ME = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_multipole_ME , Im_multipole_ME)
#endif
  for (unsigned long int total_SDp_index = total_SDp_index_min ; total_SDp_index <= total_SDp_index_max ; total_SDp_index++)
    {
      const class SD_quantum_numbers &SDp_qn = SDp_quantum_numbers_tab(total_SDp_index);

      const int iMp = SDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = SDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sp = SDp_qn.get_S ();

      const int Sn = S - Sp;
      
      const int n_spec_p = SDp_qn.get_n_spec ();

      const int n_spec_n = n_spec_max - n_spec_p;

      const int n_scat_p = SDp_qn.get_n_scat ();
	
      const unsigned int iCp = SDp_qn.get_iC ();

      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (dimension_SDp == 0) continue;

      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (all_dimensions_SDn_zero) continue;
		  
      const unsigned int SDp_index = SDp_qn.get_SD_index ();
      
      const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &SDp = SDp_tab(i_thread);
      
      const int iMn = iM - iMp;
      
      const int TRS_iMp = iMp_max - iMp;
		  
      bool is_NBME_calculated = false;

      TYPE NBME = 0.0;					  		  
      
      SDp = SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index);
      
      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
	  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		        
	  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
	      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
		  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

	      if (dimension_SDn == 0) continue;
				  
	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);
		  
	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS = (is_it_TRS)
		? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , TRS_iMp))
		: (NADA);
		  
	      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;

	      const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDn_minus_one;
	      		
	      if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
		{
		  const unsigned long int TRS_total_PSI_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS + dimension_SDn*SDp_TRS_index) : (NADA);
		      
		  const unsigned long int total_SDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0)) : (NADA);
		      
		  if (!is_NBME_calculated)
		    {
		      NBME = diagonal_NBME_pp_nn_calc (L , is_it_HO_expansion , prot_Y_data , TBMEs_angular_table , SDp);

		      is_NBME_calculated = true;
		    }
					     		  
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      const unsigned long int total_PSI_index = total_PSI_index_zero + SDn_index;
			  
		      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
			{
			  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;
					      
			  const unsigned long int total_SDn_TRS_indices_index = (is_it_TRS) ? (total_SDn_TRS_indices_zero_index + SDn_index) : (NADA);

			  const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_SDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_index = (is_it_TRS) ? (TRS_total_PSI_index_zero + SDn_TRS_index) : (NADA);
			      		    
			  if (!is_it_TRS || (TRS_total_PSI_index >= total_PSI_index))
			    {
			      const TYPE &PSI_IN_component  = PSI_IN_full[total_PSI_index];
			      const TYPE &PSI_OUT_component = PSI_OUT[PSI_index];

			      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_index == total_PSI_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);

			      const TYPE PSI_components_TRS_factor_product = PSI_IN_component*PSI_OUT_component_TRS_factor;
				  
			      const TYPE multipole_ME_part = NBME*PSI_components_TRS_factor_product;
			      
			      Re_multipole_ME += real_dc (multipole_ME_part);
			      Im_multipole_ME += imag_dc (multipole_ME_part);
			    }}}}}}}
  
  const TYPE multipole_ME = generate_scalar<TYPE> (Re_multipole_ME , Im_multipole_ME);
	
  return multipole_ME;      
}









TYPE GSM_multipoles::diagonal_part_n_part_pn_calc (
						   const int L ,
						   const bool is_it_HO_expansion ,
						   const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
						   const class GSM_vector &PSI_IN_full ,
						   const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper = PSI_OUT.get_GSM_vector_helper ();
      
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM (); 

  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();

  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
    
  const unsigned int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();
    
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_SDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_SDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();

  if (total_SDn_index_min > total_SDn_index_max) return 0.0;
  
  class array<class Slater_determinant> SDn_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) SDn_tab(i).allocate (NYval);
      
  double Re_multipole_ME = 0.0;
  double Im_multipole_ME = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_multipole_ME , Im_multipole_ME)
#endif
  for (unsigned long int total_SDn_index = total_SDn_index_min ; total_SDn_index <= total_SDn_index_max ; total_SDn_index++)
    {
      const class SD_quantum_numbers &SDn_qn = SDn_quantum_numbers_tab(total_SDn_index);

      const int iMn = SDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = SDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sn = SDn_qn.get_S ();

      const int Sp = S - Sn;
      
      const int n_spec_n = SDn_qn.get_n_spec ();

      const int n_spec_p = n_spec_max - n_spec_n;

      const int n_scat_n = SDn_qn.get_n_scat ();
	
      const unsigned int iCn = SDn_qn.get_iC ();

      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (dimension_SDn == 0) continue;
        
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (all_dimensions_SDp_zero) continue;
      
      const unsigned int SDn_index = SDn_qn.get_SD_index ();
      
      const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &SDn = SDn_tab(i_thread);
      
      const int iMp = iM - iMn;
		  
      const int TRS_iMp = iMp_max - iMp;
      
      bool is_NBME_calculated = false;

      TYPE NBME = 0.0;					  

      SDn = SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index);
      
      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  
	  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
	      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
				      
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

	      if (dimension_SDp == 0) continue;
				  
	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS = (is_it_TRS)
		? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , TRS_iMp))
		: (NADA);
		  
	      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + SDn_index;

	      const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDn*dimension_SDp_minus_one;
		  
	      if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
		{
		  const unsigned long int TRS_total_PSI_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS + SDn_TRS_index) : (NADA);
		      
		  const unsigned long int total_SDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0)) : (NADA);
		      
		  if (!is_NBME_calculated)
		    {
		      NBME = diagonal_NBME_pp_nn_calc (L , is_it_HO_expansion , neut_Y_data , TBMEs_angular_table , SDn);
					  
		      is_NBME_calculated = true;
		    }
			
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      const unsigned long int total_PSI_index = total_PSI_index_zero + dimension_SDn*SDp_index;
					  
		      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
			{
			  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;
					      
			  const unsigned long int total_SDp_TRS_indices_index = (is_it_TRS) ? (total_SDp_TRS_indices_zero_index + SDp_index) : (NADA);
			      
			  const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_SDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_index = (is_it_TRS) ? (TRS_total_PSI_index_zero + SDp_TRS_index*dimension_SDn) : (NADA);
			      
			  if (!is_it_TRS || (TRS_total_PSI_index >= total_PSI_index))
			    {
			      const TYPE &PSI_IN_component  = PSI_IN_full[total_PSI_index];
			      const TYPE &PSI_OUT_component = PSI_OUT[PSI_index];

			      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_index == total_PSI_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
				  
			      const TYPE PSI_components_TRS_factor_product = PSI_IN_component*PSI_OUT_component_TRS_factor;
				  
			      const TYPE multipole_ME_part = NBME*PSI_components_TRS_factor_product;
	      
			      Re_multipole_ME += real_dc (multipole_ME_part);
			      Im_multipole_ME += imag_dc (multipole_ME_part);
			    }}}}}}}
  
  const TYPE multipole_ME = generate_scalar<TYPE> (Re_multipole_ME , Im_multipole_ME);
	
  return multipole_ME;      
}








TYPE GSM_multipoles::diagonal_part_pn_part_pn_N_valence_larger_calc (
								     const int L ,
								     const bool is_it_HO_expansion ,
								     const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
								     const class GSM_vector &PSI_IN_full ,
								     const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper = PSI_OUT.get_GSM_vector_helper ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
    
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();

  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
    
  const unsigned int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();
    
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_SDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_SDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();

  if (total_SDn_index_min > total_SDn_index_max) return 0.0;
  
  class array<class Slater_determinant> SDp_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SDp_tab(i).allocate (ZYval);
      SDn_tab(i).allocate (NYval);
    }
   
  double Re_multipole_ME = 0.0;
  double Im_multipole_ME = 0.0;
   
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_multipole_ME , Im_multipole_ME)
#endif
  for (unsigned long int total_SDn_index = total_SDn_index_min ; total_SDn_index <= total_SDn_index_max ; total_SDn_index++)
    {
      const class SD_quantum_numbers &SDn_qn = SDn_quantum_numbers_tab(total_SDn_index);

      const int iMn = SDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = SDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sn = SDn_qn.get_S ();

      const int Sp = S - Sn;
      
      const int n_spec_n = SDn_qn.get_n_spec ();

      const int n_spec_p = n_spec_max - n_spec_n;

      const int n_scat_n = SDn_qn.get_n_scat ();
	
      const unsigned int iCn = SDn_qn.get_iC ();

      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (dimension_SDn == 0) continue;
        
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (all_dimensions_SDp_zero) continue;
      
      const unsigned int SDn_index = SDn_qn.get_SD_index ();
      
      const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index)) : (NADA);
      
      const int iMp = iM - iMn;

      const int TRS_iMp = iMp_max - iMp;
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &SDp = SDp_tab(i_thread);
      class Slater_determinant &SDn = SDn_tab(i_thread);
      
      SDn = SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index);
      
      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  
	  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
	      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
				      
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

	      if (dimension_SDp == 0) continue;
				  
	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);
		  
	      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + SDn_index;

	      const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDn*dimension_SDp_minus_one;
  
	      if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS = (is_it_TRS)
		    ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , TRS_iMp))
		    : (NADA);
		      
		  const unsigned long int total_SDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0)) : (NADA);
		      
		  const unsigned long int TRS_total_PSI_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS + SDn_TRS_index) : (NADA);
		  
		  const unsigned long int total_SDp_index_zero = SDp_set.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0);
		      
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      const unsigned long int total_PSI_index = total_PSI_index_zero + dimension_SDn*SDp_index;
					  
		      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
			{
			  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

			  const unsigned long int total_SDp_TRS_indices_index = (is_it_TRS) ? (total_SDp_TRS_indices_zero_index + SDp_index) : (NADA);

			  const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_SDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_index = (is_it_TRS) ? (TRS_total_PSI_index_zero + dimension_SDn*SDp_TRS_index) : (NADA);
			      
			  if (!is_it_TRS || (TRS_total_PSI_index >= total_PSI_index))
			    {
			      const unsigned long int total_SDp_index = total_SDp_index_zero + SDp_index;

			      SDp = SDp_set[total_SDp_index];

			      const TYPE NBME = diagonal_NBME_pn_calc (L , is_it_HO_expansion , prot_Y_data , neut_Y_data , TBMEs_angular_table , SDp , SDn);
			      
			      const TYPE &PSI_IN_component  = PSI_IN_full[total_PSI_index];
			      const TYPE &PSI_OUT_component = PSI_OUT[PSI_index];
			      
			      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_index == total_PSI_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
				  
			      const TYPE PSI_components_TRS_factor_product = PSI_IN_component*PSI_OUT_component_TRS_factor;
				  
			      const TYPE multipole_ME_part = NBME*PSI_components_TRS_factor_product;
	      
			      Re_multipole_ME += real_dc (multipole_ME_part);
			      Im_multipole_ME += imag_dc (multipole_ME_part);			      
			    }}}}}}}
  
  const TYPE multipole_ME = generate_scalar<TYPE> (Re_multipole_ME , Im_multipole_ME);
	
  return multipole_ME;
}






TYPE GSM_multipoles::diagonal_part_pn_part_pn_Z_valence_larger_calc (
								     const int L ,
								     const bool is_it_HO_expansion ,
								     const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
								     const class GSM_vector &PSI_IN_full ,
								     const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper = PSI_OUT.get_GSM_vector_helper ();
      
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM (); 

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 

  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
   
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
            
  const unsigned int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
      
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int total_SDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_SDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  if (total_SDp_index_min > total_SDp_index_max) return 0.0;
    
  class array<class Slater_determinant> SDp_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SDp_tab(i).allocate (ZYval);
      SDn_tab(i).allocate (NYval);
    }
  
  double Re_multipole_ME = 0.0;
  double Im_multipole_ME = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_multipole_ME , Im_multipole_ME)
#endif
  for (unsigned long int total_SDp_index = total_SDp_index_min ; total_SDp_index <= total_SDp_index_max ; total_SDp_index++)
    {
      const class SD_quantum_numbers &SDp_qn = SDp_quantum_numbers_tab(total_SDp_index);

      const int iMp = SDp_qn.get_iM ();
      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = SDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sp = SDp_qn.get_S ();

      const int Sn = S - Sp;
      
      const int n_spec_p = SDp_qn.get_n_spec ();

      const int n_spec_n = n_spec_max - n_spec_p;

      const int n_scat_p = SDp_qn.get_n_scat ();
	
      const unsigned int iCp = SDp_qn.get_iC ();

      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (dimension_SDp == 0) continue;

      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (all_dimensions_SDn_zero) continue;
		  
      const unsigned int SDp_index = SDp_qn.get_SD_index ();
      
      const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index)) : (NADA);
      
      const int iMn = iM - iMp;
      
      const int TRS_iMp = iMp_max - iMp;
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &SDp = SDp_tab(i_thread);
      class Slater_determinant &SDn = SDn_tab(i_thread);
      
      SDp = SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index);
      
      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
	  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  
	  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
	      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
				      
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

	      if (dimension_SDn == 0) continue;
				  
	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);
	      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;

	      const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDn_minus_one;
  
	      if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS = (is_it_TRS)
		    ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , TRS_iMp))
		    : (NADA);
				  
		  const unsigned long int total_SDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS + dimension_SDn*SDp_TRS_index) : (NADA);
		  
		  const unsigned long int total_SDn_index_zero = SDn_set.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0);
		      
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      const unsigned long int total_PSI_index = total_PSI_index_zero + SDn_index;
					  
		      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
			{
			  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;
      
			  const unsigned long int total_SDn_TRS_indices_index = (is_it_TRS) ? (total_SDn_TRS_indices_zero_index + SDn_index) : (NADA);
			  
			  const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_SDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_index = (is_it_TRS) ? (TRS_total_PSI_index_zero + SDn_TRS_index) : (NADA);
			      
			  if (!is_it_TRS || (TRS_total_PSI_index >= total_PSI_index))
			    {
			      const unsigned long int total_SDn_index = total_SDn_index_zero + SDn_index;

			      SDn = SDn_set[total_SDn_index];
			      
			      const TYPE NBME = diagonal_NBME_pn_calc (L , is_it_HO_expansion , prot_Y_data , neut_Y_data , TBMEs_angular_table , SDp , SDn);
      
			      const TYPE &PSI_IN_component  = PSI_IN_full[total_PSI_index];
			      const TYPE &PSI_OUT_component = PSI_OUT[PSI_index];
			      
			      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_index == total_PSI_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
				  
			      const TYPE PSI_components_TRS_factor_product = PSI_IN_component*PSI_OUT_component_TRS_factor;
				  
			      const TYPE multipole_ME_part = NBME*PSI_components_TRS_factor_product;
	      
			      Re_multipole_ME += real_dc (multipole_ME_part);
			      Im_multipole_ME += imag_dc (multipole_ME_part);
			    }}}}}}}
  
  const TYPE multipole_ME = generate_scalar<TYPE> (Re_multipole_ME , Im_multipole_ME);
	
  return multipole_ME;
}

























TYPE GSM_multipoles::diagonal_part_pp_nn_calc (
					       const int L ,
					       const bool is_it_HO_expansion ,
					       const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
					       const class GSM_vector &PSI_IN_full ,
					       const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper = PSI_OUT.get_GSM_vector_helper ();
    
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int iM = GSM_vector_helper.get_iM (); 
  
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
 
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = data.get_SD_TRS_indices ();
  
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_SD_index_min = GSM_vector_helper.get_total_SD_index_min ();
  const unsigned long int total_SD_index_max = GSM_vector_helper.get_total_SD_index_max ();

  const unsigned int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  if (total_SD_index_min > total_SD_index_max) return 0.0;
  
  class array<class Slater_determinant> SD_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) SD_tab(i).allocate (N_valence_baryons);
      
  double Re_multipole_ME = 0.0;
  double Im_multipole_ME = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_multipole_ME , Im_multipole_ME)
#endif
  for (unsigned long int total_SD_index = total_SD_index_min ; total_SD_index <= total_SD_index_max ; total_SD_index++)
    {      
      const class SD_quantum_numbers &SD_qn = SD_quantum_numbers_tab(total_SD_index);

      const unsigned int BP_SD = SD_qn.get_BP ();

      if (BP_SD != BP) continue;
      
      const int S_SD = SD_qn.get_S ();

      if (S_SD != S) continue;
 
      const int iM_SD = SD_qn.get_iM ();

      if (iM_SD != iM) continue;
      
      const unsigned int n_scat = SD_qn.get_n_scat ();

      const unsigned int iC = SD_qn.get_iC ();

      const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);

      const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
      
      const unsigned int SD_index = SD_qn.get_SD_index ();

      const unsigned int sum_dimensions_configuration_fixed = sum_dimensions_GSM_vector(n_scat , iC);

      const unsigned long int total_PSI_index = sum_dimensions_configuration_fixed + SD_index;
      
      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
	{
	  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;
      
	  const unsigned int SD_TRS_index = (is_it_TRS) ? (SD_TRS_indices(BP , S , 0 , n_scat , iC , iM , SD_index)) : (NADA);
	  
	  const unsigned int sum_dimensions_configuration_fixed_TRS = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(n_scat , iC)) : (NADA);
	  
	  const unsigned long int TRS_total_PSI_index = (is_it_TRS) ? (sum_dimensions_configuration_fixed_TRS + SD_TRS_index) : (NADA);
	  
	  if (!is_it_TRS || (TRS_total_PSI_index >= total_PSI_index))
	    {
	      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	      class Slater_determinant &SD = SD_tab(i_thread);
	  
	      SD = SD_set(BP , S , 0 , n_scat , iC , iM , SD_index);

	      const TYPE NBME = diagonal_NBME_pp_nn_calc (L , is_it_HO_expansion , data , TBMEs_angular_table , SD);
      
	      const TYPE &PSI_IN_component  = PSI_IN_full[total_PSI_index];
	      
	      const TYPE &PSI_OUT_component = PSI_OUT[PSI_index];
			      
	      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_index == total_PSI_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
	      
	      const TYPE PSI_components_TRS_factor_product = PSI_IN_component*PSI_OUT_component_TRS_factor;
				  
	      const TYPE multipole_ME_part = NBME*PSI_components_TRS_factor_product;
	      
	      Re_multipole_ME += real_dc (multipole_ME_part);
	      Im_multipole_ME += imag_dc (multipole_ME_part);
	    }
	}
    }
  
  const TYPE multipole_ME = generate_scalar<TYPE> (Re_multipole_ME , Im_multipole_ME);
	
  return multipole_ME;
}










// Calculation of the 1p-1h <outSD | multipole-op | inSD> NBME without reordering phase
// -------------------------------------------------------------------------------------
// |inSD> and |outSD> differ by one state, mu_in and mu_out, here.
// Hence: <outSD | multipole-op | inSD> = +/- [<mu_out | multipole-op(1) | mu_in> + \sum_i <i mu_out | multipole-op(2) | i mu_in>], with multipole-op(1) and multipole-op(2) the one-body and two-body parts of multipole-op.
// Entering OBMEs and TBMEs are calculated from stored coupled or reduced one-body matrix elements (see GSM_multipole_operator_class_OBMEs_TBMEs.cpp).
// The +/- reordering phase is not considered here.
//
// pp, nn and pn parts are separated in NBMEs.
// The pp/nn parts are considered in NBME_no_pn_one_jump_mu_no_phase_calc (mu is proton or neutron)
// The pn parts are considered in NBME_pn_no_phase_one_jump_p_calc (p -> p') and NBME_pn_no_phase_one_jump_n_calc (n -> n').

TYPE GSM_multipoles::NBME_one_jump_mu_no_phase_calc (
						     const int L ,
						     const bool is_it_HO_expansion ,
						     const class baryons_data &data ,
						     const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
						     const unsigned int in_jump , 
						     const unsigned int out_jump , 
						     const class Slater_determinant &outSD)
{
  const int N_valence_baryons = data.get_N_valence_baryons ();
    
  TYPE NBME_no_phase = uncoupled_OBME (L , is_it_HO_expansion , data , in_jump , out_jump);

  for (int i = 0 ; i < N_valence_baryons ; i++)
    {
      const unsigned int idem = outSD[i];
      
      if ((idem != in_jump) && (idem != out_jump)) NBME_no_phase += uncoupled_TBME_pp_nn_calc (L , is_it_HO_expansion , data , TBMEs_angular_table , in_jump , idem , out_jump , idem);
    }

  return NBME_no_phase;
}

TYPE GSM_multipoles::NBME_pn_no_phase_one_jump_p_calc (
						       const int L ,
						       const bool is_it_HO_expansion ,
						       const class baryons_data &prot_Y_data ,
						       const class baryons_data &neut_Y_data ,
						       const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
						       const unsigned int p_in ,
						       const unsigned int p_out , 
						       const class Slater_determinant &SDn)
{
  const unsigned int NYval = SDn.get_N_valence_baryons ();

  TYPE NBME_multipole_no_phase = 0.0;

  for (unsigned int n = 0 ; n < NYval ; n++)
    {
      const unsigned int state_n = SDn[n];

      NBME_multipole_no_phase += uncoupled_TBME_pn_calc (L , is_it_HO_expansion , prot_Y_data , neut_Y_data , TBMEs_angular_table , p_in , state_n , p_out , state_n);
    }

  return NBME_multipole_no_phase;
}

TYPE GSM_multipoles::NBME_pn_no_phase_one_jump_n_calc (
						       const int L ,
						       const bool is_it_HO_expansion ,
						       const class baryons_data &prot_Y_data ,
						       const class baryons_data &neut_Y_data ,
						       const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
						       const unsigned int n_in ,
						       const unsigned int n_out , 
						       const class Slater_determinant &SDp)
{
  const unsigned int ZYval = SDp.get_N_valence_baryons ();

  TYPE NBME_multipole_no_phase = 0.0;

  for (unsigned int p = 0 ; p < ZYval ; p++)
    {
      const unsigned int state_p = SDp[p];

      NBME_multipole_no_phase += uncoupled_TBME_pn_calc (L , is_it_HO_expansion , prot_Y_data , neut_Y_data , TBMEs_angular_table , state_p , n_in , state_p , n_out); 
    }

  return NBME_multipole_no_phase;
}











// Calculation of NBMEs of 1p-1h and 2p-2h parts of the form <outSD | multipole-op | inSD>, with |outSD> fixed and inSD varying
// -------------------------------------------------------------------------------------------------------------------
// One has |Psi[out]> = multipole-op|Psi[in]>. One calculates the components of |Psi[out]> = \sum_{outSD} c_{outSD} |outSD>, where c_{outSD} = \sum_{inSD} c_{inSD} <outSD | multipole-op | inSD>.
// Hence, for a fixed c_{outSD}, one has |outSD> fixed and |inSD> varied, so that |inSD> differs by one or two states in off-diagonal matrix elements.
// |inSD> and <outSD | multipole-op | inSD> are calculated here for fixed |outSD>.
// The parity and M quantum number of |inSD> are fixed as well.
// 
// |inSD> is generated by one or two jumps from |outSD> (see GSM_jumps_data_str.cpp). 
// The results of the jump procedure is an array of structures containing data about |inSD>, associated data (one-body states indices, ...) and the reordering phase.
//
// <outSD | multipole-op | inSD> = +/- [<mu_out | multipole-op(1) | mu_in> + \sum_i <i mu_out | multipole-op(2) | i mu_in>] = +/- NBME(no phase) for the 1p-1h part, where |inSD> and |outSD> differ by one state, mu_in and mu_out.
// NBME(no phase) is calculated in NBME_one_jump_mu_no_phase_calc and the reordering phase is in the jump structure.
//
// <outSD | multipole-op | inSD> = +/- <mu_left_out mu_right_out | multipole-op(2) | mu_left_in mu_right_in>
// The TBMEs is calculated from stored coupled or reduced one-body matrix elements (see GSM_multipole_operator_class_OBMEs_TBMEs.cpp) and the reordering phase is in the jump structure.
//
// The <outSD | multipole-op | inSD> NBMEs are stored in an array and a jump structure contain all data related to the considered 1p-1h or 2p-2h excitation.
//
// mu means proton or neutron.

void GSM_multipoles::NBMEs_one_jump_pp_nn_calc_store (
						      const class GSM_vector_helper_class &GSM_vector_helper ,
						      const int L ,
						      const bool is_it_HO_expansion ,
						      const class baryons_data &data , 
						      const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
						      const unsigned int BPmu , 
						      const int Smu ,
						      const int n_spec_mu , 
						      const int iMmu , 
						      const int n_scat_mu_out , 
						      const unsigned int iCmu_out , 
						      const unsigned int outSDmu_index , 
						      const class Slater_determinant &outSDmu , 
						      bool &is_there_one_jump_calc , 
						      class jumps_data_out_to_in_str &one_jump_mu , 
						      class array<TYPE> &NBMEs_one_jump_mu)
{
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
      
  const enum particle_type nucleonic_particle_mu = data.get_nucleonic_particle ();

  const bool is_it_charged = (nucleonic_particle_mu == PROTON);
  
  const int n_holes_max_mu = (is_it_charged) ? (n_holes_max_p) : (n_holes_max_n);
  
  const int n_scat_max_mu = (is_it_charged) ? (n_scat_max_p) : (n_scat_max_n);
  
  const int Emu_max_hw = (is_it_charged) ? (Ep_max_hw) : (En_max_hw);
  
  is_there_one_jump_calc = false;

  one_jump_mu.one_jump_mu_store (BPmu , Smu , n_spec_mu , iMmu , n_holes_max_mu , n_scat_max_mu , Emu_max_hw , BPmu , Smu , n_spec_mu , n_scat_mu_out , iCmu_out , iMmu , outSDmu_index , data);

  const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();

  if (dimension_one_jump_mu > 0)
    {
      for (unsigned int i = 0 ; i < dimension_one_jump_mu ; i++)
	{ 
	  const class jumps_data_inSD_str &one_jump_mu_inSD = one_jump_mu(i);

	  const unsigned int mu_in  = one_jump_mu_inSD.get_mu_in ();
	  const unsigned int mu_out = one_jump_mu_inSD.get_mu_out ();
	  
	  const unsigned int total_bin_phase_mu = one_jump_mu_inSD.get_total_bin_phase ();

	  const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);

	  const TYPE NBME_one_jump_mu_no_phase = NBME_one_jump_mu_no_phase_calc (L , is_it_HO_expansion , data , TBMEs_angular_table , mu_in , mu_out , outSDmu);

	  NBMEs_one_jump_mu(i) = (total_phase_mu == 1) ? (NBME_one_jump_mu_no_phase) : (-NBME_one_jump_mu_no_phase);
	}

      one_jump_mu.remove_zero_NBMEs (NBMEs_one_jump_mu);

      const unsigned int dimension_one_jump_mu_non_zeros = one_jump_mu.get_dimension ();

      if (dimension_one_jump_mu_non_zeros > 0) is_there_one_jump_calc = true;
    }
}

void GSM_multipoles::NBMEs_two_jumps_pp_nn_calc_store (
						       const class GSM_vector_helper_class &GSM_vector_helper ,
						       const int L ,
						       const bool is_it_HO_expansion , 
						       const class baryons_data &data , 
						       const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
						       const unsigned int BPmu , 
						       const int Smu ,
						       const int n_spec_mu , 
						       const int iMmu , 
						       const int n_scat_mu_out , 
						       const unsigned int iCmu_out , 
						       const unsigned int outSDmu_index ,
						       bool &are_there_two_jumps_calc , 
						       class jumps_data_out_to_in_str &two_jumps_mu , 
						       class array<TYPE> &NBMEs_two_jumps_mu)
{
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
      
  const enum particle_type nucleonic_particle_mu = data.get_nucleonic_particle ();

  const bool is_it_charged = (nucleonic_particle_mu == PROTON);
  
  const class array<class nljm_struct> &phi_table_mu = data.get_phi_table ();
  
  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  const int n_holes_max_mu = (is_it_charged) ? (n_holes_max_p) : (n_holes_max_n);
  
  const int n_scat_max_mu = (is_it_charged) ? (n_scat_max_p) : (n_scat_max_n);

  const int Emu_max_hw = (is_it_charged) ? (Ep_max_hw) : (En_max_hw);
  
  are_there_two_jumps_calc = false;
  
  if (N_valence_baryons >= 2)
    {
      two_jumps_mu.two_jumps_mu_store (BPmu , Smu , n_spec_mu , iMmu , n_holes_max_mu , n_scat_max_mu , Emu_max_hw , BPmu , n_spec_mu , Smu , n_scat_mu_out , iCmu_out , iMmu , outSDmu_index , false , false , data);

      const unsigned int dimension_two_jumps_mu = two_jumps_mu.get_dimension ();
      
      if (dimension_two_jumps_mu > 0)
	{
	  for (unsigned int i = 0 ; i < dimension_two_jumps_mu ; i++)
	    { 
	      const class jumps_data_inSD_str &two_jumps_mu_inSD = two_jumps_mu(i);

	      const unsigned int mu_left_in  = two_jumps_mu_inSD.get_left_in ();
	      const unsigned int mu_right_in = two_jumps_mu_inSD.get_right_in ();
	      
	      const unsigned int mu_left_out  = two_jumps_mu_inSD.get_left_out ();
	      const unsigned int mu_right_out = two_jumps_mu_inSD.get_right_out ();
	      
	      if (!is_uncoupled_TBME_pp_nn_trivial_zero_determine (L , phi_table_mu , mu_left_in , mu_right_in , mu_left_out , mu_right_out))
		{
		  const unsigned int total_bin_phase_mu = two_jumps_mu_inSD.get_total_bin_phase ();

		  const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);
	      
		  const TYPE TBME_mu = uncoupled_TBME_pp_nn_calc (L , is_it_HO_expansion , data , TBMEs_angular_table , mu_left_in , mu_right_in , mu_left_out , mu_right_out);

		  NBMEs_two_jumps_mu(i) = (total_phase_mu == 1) ? (TBME_mu) : (-TBME_mu);
		}
	      else
		NBMEs_two_jumps_mu(i) = 0.0;
	    }

	  two_jumps_mu.remove_zero_NBMEs (NBMEs_two_jumps_mu);

	  const unsigned int dimension_two_jumps_mu_non_zeros = two_jumps_mu.get_dimension ();
	        
	  if (dimension_two_jumps_mu_non_zeros > 0) are_there_two_jumps_calc = true;
	}
    }
}






// Application of the off-diagonal part of multipole-op to |Psi[out]> in |Psi[out]> = multipole-op|Psi[in]>
// ------------------------------------------------------------------------------------------
// One has |Psi[out]> = multipole-op|Psi[in]>. One calculates the components of |Psi[out]> = \sum_{outSD} c_{outSD} |outSD>, where c_{outSD} = \sum_{inSD} c_{inSD} <outSD | multipole-op | inSD>.
// Hence, for a fixed c_{outSD}, one has |outSD> fixed and |inSD> varied, so that |inSD> differs by one or two states in off-diagonal matrix elements.
// multipole-op is separated in pp,nn and pn parts for its off-diagonal part.
// One loops over all the Slater determinants of |Psi[out]> to calculate its vector components.
// One takes into account parity and M conservation.
//
// For the proton-neutron case, one routine is used if NYval >= ZYval, and another if not, as SD indices are calculated differently in each case to optimize their use (see GSM_vector_dimensions.cpp).
//
// TRS is time-reversal symmetry. It allows to to calculate about one half of |Psi[out]>, while the rest is given from the first half up to a phase if M=0 in |Psi[in]> and |Psi[out]> and if multipole_Op is a scalar.
// Indeed, the components of |SD> and TRS|SD> differ only by a +/-1 phase, which is straightforward to calculate.
// Hence, only about half of |Psi[out]> components are calculated in this case.
//
//
// OpenMP parallelization is used on the loop of proton or neutron Slater determinants.
// MPI parallelization here is only implicit, as on considers only the Slater determinants of the current node.
// 
// One considers the proton part only. The neutron part reads symmetrically.
// One first loops over proton outSDs, and one loops over neutron outSDs inside this loop to generate all outSDs.
// One checks before if the 1p-1h or 2p-2h configuration of inSDs belongs ot the model space, as otherwise nothing is done.
// One generates the 1p-1h or 2p-2h excitations providing with proton inSDs. As the neutron part is spectator here, it is done only once for all neutron outSDs for a fixed proton outSD.
// One loops over all neutron outSDs, one calculates all indices of inSDs from their proton and neutron parts, and one adds its component to c_{outSD}.
// This part is the only one for spaces with only protons or neutrons (plus a few hyperons if any) in jumps_part_pp_nn_calc.
//
// The proton-neutron part is done similarly. One considers only the case NYval >= ZYval, as the other case reads symmetrically.
// One first loops over neutron outSDs, and one loops over proton outSDs inside this loop to generate all outSDs.
// One can reduce the possible Mp projections of inSDs, as they differ by 1 at most in multipole operators (rank 1). The parity of proton inSD is also opposite of that of proton outSD (same for neutron SDs).
// Contrary to the proton or neutron cases, Mp[in] and Mn[in] are not equal to Mp[out] and Mn[out]. Hence, one sums over the indices of Mp to have Mp[in] = Mp[out]-1, Mp[out], Mp[out]+1.
// Neutron 1p-1h jumps are calculated and stored. It is done only once for all proton outSDs for a fixed neutron outSD.
// One loops over all proton outSDs, one calculates all indices of inSDs from their proton and neutron parts.
// Proton  1p-1h jumps are there calculated and stored everytime as the last loop is on proton outSDs. 
// One firstly checks if the in configuration belongs to the model space, as otherwise it is refused.
// As inSD indices are quick to calculate when configuration does not change (see GSM_vector_dimensions.cpp), one checks if the configuration of inSD changes in the loop.
// If it does, dimensions and sum of dimensions depending on this new in configuration are recalculated, and not otherwise.
// One then adds the component associated to inSD to c_{outSD}. 
// 
// When one writes total_PSI_index, total means that one considers the index of the SD of the full GSM vector, not of part of it in a node (see GSM_vector_helper.cpp).

TYPE GSM_multipoles::jumps_p_one_body_part_pn_calc (
						    const int L ,
						    const bool is_it_HO_expansion ,
						    const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
						    const class GSM_vector &PSI_IN_full ,
						    const class GSM_vector &PSI_OUT)
{  
  const class GSM_vector_helper_class &GSM_vector_helper = PSI_OUT.get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM (); 

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 

  const int iMp_max = prot_Y_data.get_iM_max ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
    
  const unsigned long int first_total_PSI_OUT_index =  GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_OUT_index =  GSM_vector_helper.get_last_total_PSI_index ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  if (total_outSDp_index_min > total_outSDp_index_max) return 0.0;
  
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
	  
  class array<class Slater_determinant> outSDp_tab(NUMBER_OF_THREADS);
  
  class array<class jumps_data_out_to_in_str> one_jump_p_tab(NUMBER_OF_THREADS);
	      
  class array<class array<TYPE> > NBMEs_p_one_jump_p_tab(NUMBER_OF_THREADS);
  
  class array<class array<bool> > is_configuration_accepted_one_jump_p_in_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_IN_indices_one_jump_p_tab(NUMBER_OF_THREADS);
    
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      outSDp_tab(i).allocate (ZYval);
      
      one_jump_p_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
      	      
      NBMEs_p_one_jump_p_tab(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);
      
      is_configuration_accepted_one_jump_p_in_tabs(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);

      total_PSI_IN_indices_one_jump_p_tab(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);
    }

  double Re_multipole_ME = 0.0;
  double Im_multipole_ME = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_multipole_ME , Im_multipole_ME)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp = outSDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = outSDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sp = outSDp_qn.get_S ();

      const int Sn = S - Sp;
      
      const int n_spec_p = outSDp_qn.get_n_spec ();

      const int n_spec_n = n_spec_max - n_spec_p;

      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

      if (all_dimensions_SDn_zero) continue;
	
      const int iMn = iM - iMp;

      const int TRS_iMp = iMp_max - iMp;

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();
  
      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index)) : (NADA);
            				  
      const unsigned int i_thread = OpenMP_thread_number_determine ();	      
      
      class Slater_determinant &outSDp = outSDp_tab(i_thread);
      
      class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(i_thread);
      
      class array<TYPE> &NBMEs_p_one_jump_p = NBMEs_p_one_jump_p_tab(i_thread);
      
      class array<bool> &is_configuration_accepted_one_jump_p_in_tab = is_configuration_accepted_one_jump_p_in_tabs(i_thread);

      class array<unsigned long int> &total_PSI_IN_indices_one_jump_p = total_PSI_IN_indices_one_jump_p_tab(i_thread);
      
      bool are_jumps_p_calculated = false;

      bool is_there_one_jump_calc_all = true;
		      
      outSDp = SDp_set(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index);
      
      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && is_there_one_jump_calc_all ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
	  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
			  
	  for (unsigned int iCn = iCn_min ; (iCn <= iCn_max) && is_there_one_jump_calc_all ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
	      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

	      if (dimension_SDn == 0) continue;

	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , iMp);
				  
	      const unsigned long int total_PSI_OUT_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_SDn*outSDp_index;

	      const unsigned long int total_PSI_OUT_index_dimension_minus_one = total_PSI_OUT_index_zero + dimension_SDn_minus_one;
  
	      if ((total_PSI_OUT_index_zero <= last_total_PSI_OUT_index) && (total_PSI_OUT_index_dimension_minus_one >= first_total_PSI_OUT_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_SDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_OUT_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_SDn*outSDp_TRS_index) : (NADA);
				      
		  if (!are_jumps_p_calculated)
		    {
		      bool is_there_one_jump_calc = false;
 
		      NBMEs_one_jump_pp_nn_calc_store (GSM_vector_helper , L , is_it_HO_expansion , prot_Y_data , TBMEs_angular_table ,
						       BPp , Sp , n_spec_p , iMp , n_scat_p_out , iCp_out , outSDp_index , outSDp , is_there_one_jump_calc , one_jump_p , NBMEs_p_one_jump_p);
						
		      is_there_one_jump_calc_all = is_there_one_jump_calc;

		      are_jumps_p_calculated = true;
		    }

		  if (!is_there_one_jump_calc_all) continue;
		  
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      const unsigned long int total_PSI_OUT_index = total_PSI_OUT_index_zero + SDn_index;

		      TYPE component_part = 0.0;
		      
		      if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
			{
			  const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;

			  const unsigned long int total_SDn_TRS_indices_index = (is_it_TRS) ? (total_SDn_TRS_indices_zero_index + SDn_index) : (NADA);

			  const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_SDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_OUT_index = (is_it_TRS) ? (TRS_total_PSI_OUT_index_zero + SDn_TRS_index) : (NADA);
						      
			  if (!is_it_TRS || (TRS_total_PSI_OUT_index >= total_PSI_OUT_index))
			    {
			      bool is_there_one_jump_calc = false;
							
			      is_configuration_accepted_total_PSI_in_indices_p_fill (BPn , Sn , n_spec_n , n_holes_n , n_scat_n , iCn , iMn , SDn_index , En_hw , one_jump_p , GSM_vector_helper , dimension_SDn ,
										     is_configuration_accepted_one_jump_p_in_tab , total_PSI_IN_indices_one_jump_p , is_there_one_jump_calc);
						  
			      if (is_there_one_jump_calc)
				{
				  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
					
				  component_part += component_part_jumps_calc (dimension_one_jump_p , is_configuration_accepted_one_jump_p_in_tab , total_PSI_IN_indices_one_jump_p , NBMEs_p_one_jump_p , PSI_IN_full);
				}
			    }
		      
			  const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_OUT_index == total_PSI_OUT_index)) ? (PSI_OUT[PSI_OUT_index]) : (2.0*PSI_OUT[PSI_OUT_index]);
		      
			  const TYPE multipole_ME_part = component_part*PSI_OUT_component_TRS_factor;
	      
			  Re_multipole_ME += real_dc (multipole_ME_part);
			  Im_multipole_ME += imag_dc (multipole_ME_part);
			}}}}}}
  
  const TYPE multipole_ME = generate_scalar<TYPE> (Re_multipole_ME , Im_multipole_ME);
	
  return multipole_ME;
}

TYPE GSM_multipoles::jumps_p_two_body_part_pn_calc (
						    const int L ,
						    const bool is_it_HO_expansion ,
						    const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
						    const class GSM_vector &PSI_IN_full ,
						    const class GSM_vector &PSI_OUT)
{  
  const class GSM_vector_helper_class &GSM_vector_helper = PSI_OUT.get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  if (ZYval == 1) return 0.0;
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM (); 

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 

  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const unsigned int dimension_pp_2p2h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_2p2h_space_BP_S_iM_fixed_max ();
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
    
  const unsigned long int first_total_PSI_OUT_index =  GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_OUT_index =  GSM_vector_helper.get_last_total_PSI_index ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  if (total_outSDp_index_min > total_outSDp_index_max) return 0.0;
  
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
	  
  class array<class jumps_data_out_to_in_str> two_jumps_p_tab(NUMBER_OF_THREADS);
	      
  class array<class array<TYPE> > NBMEs_two_jumps_p_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_configuration_accepted_two_jumps_p_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_IN_indices_two_jumps_p_tab(NUMBER_OF_THREADS);
    
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {      
      two_jumps_p_tab(i).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_pp_2p2h_space_BP_S_iM_fixed_max);
		
      NBMEs_two_jumps_p_tab(i).allocate (dimension_pp_2p2h_space_BP_S_iM_fixed_max);

      is_configuration_accepted_two_jumps_p_tabs(i).allocate (dimension_pp_2p2h_space_BP_S_iM_fixed_max);

      total_PSI_IN_indices_two_jumps_p_tab(i).allocate (dimension_pp_2p2h_space_BP_S_iM_fixed_max);
    }
      
  double Re_multipole_ME = 0.0;
  double Im_multipole_ME = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_multipole_ME , Im_multipole_ME)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp = outSDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = outSDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sp = outSDp_qn.get_S ();

      const int Sn = S - Sp;
      
      const int n_spec_p = outSDp_qn.get_n_spec ();

      const int n_spec_n = n_spec_max - n_spec_p;

      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

      if (all_dimensions_SDn_zero) continue;
	
      const int iMn = iM - iMp;

      const int TRS_iMp = iMp_max - iMp;

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();
  
      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index)) : (NADA);

      const unsigned int i_thread = OpenMP_thread_number_determine ();	      
      
      class jumps_data_out_to_in_str &two_jumps_p = two_jumps_p_tab(i_thread);
	     
      class array<TYPE> &NBMEs_two_jumps_p = NBMEs_two_jumps_p_tab(i_thread);
	      
      class array<bool> &is_configuration_accepted_two_jumps_p_tab = is_configuration_accepted_two_jumps_p_tabs(i_thread);
	      
      class array<unsigned long int> &total_PSI_IN_indices_two_jumps_p = total_PSI_IN_indices_two_jumps_p_tab(i_thread);
      
      bool are_jumps_p_calculated = false;

      bool are_there_two_jumps_calc_all = true;
		      
      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && are_there_two_jumps_calc_all ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
	  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
			  
	  for (unsigned int iCn = iCn_min ; (iCn <= iCn_max) && are_there_two_jumps_calc_all ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
	      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

	      if (dimension_SDn == 0) continue;

	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , iMp);
				  
	      const unsigned long int total_PSI_OUT_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_SDn*outSDp_index;

	      const unsigned long int total_PSI_OUT_index_dimension_minus_one = total_PSI_OUT_index_zero + dimension_SDn_minus_one;
  
	      if ((total_PSI_OUT_index_zero <= last_total_PSI_OUT_index) && (total_PSI_OUT_index_dimension_minus_one >= first_total_PSI_OUT_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_SDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_OUT_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_SDn*outSDp_TRS_index) : (NADA);
				     
		  if (!are_jumps_p_calculated)
		    {
		      are_there_two_jumps_calc_all = false;

		      NBMEs_two_jumps_pp_nn_calc_store (GSM_vector_helper , L , is_it_HO_expansion , prot_Y_data , TBMEs_angular_table ,
							BPp , Sp , n_spec_p , iMp , n_scat_p_out , iCp_out , outSDp_index , are_there_two_jumps_calc_all , two_jumps_p , NBMEs_two_jumps_p);
		
		      are_jumps_p_calculated = true;
		    }

		  if (!are_there_two_jumps_calc_all) continue;
				       
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      const unsigned long int total_PSI_OUT_index = total_PSI_OUT_index_zero + SDn_index;

		      TYPE component_part = 0.0;
		      
		      if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
			{
			  const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;

			  const unsigned long int total_SDn_TRS_indices_index = (is_it_TRS) ? (total_SDn_TRS_indices_zero_index + SDn_index) : (NADA);

			  const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_SDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_OUT_index = (is_it_TRS) ? (TRS_total_PSI_OUT_index_zero + SDn_TRS_index) : (NADA);
				
			  if (!is_it_TRS || (TRS_total_PSI_OUT_index >= total_PSI_OUT_index))
			    {					
			      bool are_there_two_jumps_calc = false;

			      is_configuration_accepted_total_PSI_in_indices_p_fill (BPn , Sn , n_spec_n , n_holes_n , n_scat_n , iCn , iMn , SDn_index , En_hw , two_jumps_p , GSM_vector_helper , dimension_SDn ,
										     is_configuration_accepted_two_jumps_p_tab , total_PSI_IN_indices_two_jumps_p , are_there_two_jumps_calc);

			      if (are_there_two_jumps_calc)
				{
				  const unsigned int dimension_two_jumps_p = two_jumps_p.get_dimension ();
				  
				  component_part += component_part_jumps_calc (dimension_two_jumps_p , is_configuration_accepted_two_jumps_p_tab , total_PSI_IN_indices_two_jumps_p , NBMEs_two_jumps_p , PSI_IN_full);
				}
			    }
		      
			  const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_OUT_index == total_PSI_OUT_index)) ? (PSI_OUT[PSI_OUT_index]) : (2.0*PSI_OUT[PSI_OUT_index]);
		      
			  const TYPE multipole_ME_part = component_part*PSI_OUT_component_TRS_factor;
	      
			  Re_multipole_ME += real_dc (multipole_ME_part);
			  Im_multipole_ME += imag_dc (multipole_ME_part);
			}}}}}}
  
  const TYPE multipole_ME = generate_scalar<TYPE> (Re_multipole_ME , Im_multipole_ME);
	
  return multipole_ME;
}

TYPE GSM_multipoles::jumps_n_one_body_part_pn_calc (
						    const int L ,
						    const bool is_it_HO_expansion ,
						    const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
						    const class GSM_vector &PSI_IN_full ,
						    const class GSM_vector &PSI_OUT)
{  
  const class GSM_vector_helper_class &GSM_vector_helper = PSI_OUT.get_GSM_vector_helper ();
        
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM ();
    
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();

  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
    
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab (); 

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
   
  const unsigned long int first_total_PSI_OUT_index =  GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_OUT_index =  GSM_vector_helper.get_last_total_PSI_index ();
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();

  if (total_outSDn_index_min > total_outSDn_index_max) return 0.0;
    
  class array<class Slater_determinant> outSDn_tab(NUMBER_OF_THREADS);
  
  class array<class jumps_data_out_to_in_str> one_jump_n_tab(NUMBER_OF_THREADS);
	      
  class array<class array<TYPE> > NBMEs_n_one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_configuration_accepted_one_jump_n_in_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_IN_indices_one_jump_n_tab(NUMBER_OF_THREADS);
    
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      outSDn_tab(i).allocate (NYval);
      
      one_jump_n_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      	      
      NBMEs_n_one_jump_n_tab(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);

      is_configuration_accepted_one_jump_n_in_tabs(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);

      total_PSI_IN_indices_one_jump_n_tab(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);
    }
  
  double Re_multipole_ME = 0.0;
  double Im_multipole_ME = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_multipole_ME , Im_multipole_ME)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn = outSDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = outSDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sn = outSDn_qn.get_S ();

      const int Sp = S - Sn;
      
      const int n_spec_n = outSDn_qn.get_n_spec ();

      const int n_spec_p = n_spec_max - n_spec_n;

      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

      if (dimension_outSDn == 0) continue;
		  
      const int iMp = iM - iMn;

      const int TRS_iMp = iMp_max - iMp;
      
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

      if (all_dimensions_SDp_zero) continue;
		  
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index)) : (NADA);
            
      const unsigned int i_thread = OpenMP_thread_number_determine ();
  	      
      class Slater_determinant &outSDn = outSDn_tab(i_thread);
      
      class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(i_thread);
	      
      class array<TYPE> &NBMEs_n_one_jump_n = NBMEs_n_one_jump_n_tab(i_thread);

      class array<bool> &is_configuration_accepted_one_jump_n_in_tab = is_configuration_accepted_one_jump_n_in_tabs(i_thread);

      class array<unsigned long int> &total_PSI_IN_indices_one_jump_n = total_PSI_IN_indices_one_jump_n_tab(i_thread);
  	
      bool are_jumps_n_calculated = false;

      bool is_there_one_jump_calc_all = true;
		      
      outSDn = SDn_set(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index);
      
      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && is_there_one_jump_calc_all ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
			  
	  for (unsigned int iCp = iCp_min ; (iCp <= iCp_max) && is_there_one_jump_calc_all ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
	      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;
	      
	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
	      
	      if (dimension_SDp == 0) continue;

	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , iMp);

	      const unsigned long int total_PSI_OUT_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;

	      const unsigned long int total_PSI_OUT_index_dimension_minus_one = total_PSI_OUT_index_zero + dimension_SDp_minus_one*dimension_outSDn;
  
	      if ((total_PSI_OUT_index_zero <= last_total_PSI_OUT_index) && (total_PSI_OUT_index_dimension_minus_one >= first_total_PSI_OUT_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_SDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_OUT_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);
				      
		  if (!are_jumps_n_calculated)
		    {
		      bool is_there_one_jump_calc = false;
 
		      NBMEs_one_jump_pp_nn_calc_store (GSM_vector_helper , L , is_it_HO_expansion , neut_Y_data , TBMEs_angular_table ,
						       BPn , Sn , n_spec_n , iMn , n_scat_n_out , iCn_out , outSDn_index , outSDn , is_there_one_jump_calc , one_jump_n , NBMEs_n_one_jump_n);
						
		      is_there_one_jump_calc_all = is_there_one_jump_calc;

		      are_jumps_n_calculated = true;
		    }

		  if (!is_there_one_jump_calc_all) continue;
				       
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      const unsigned long int total_PSI_OUT_index = total_PSI_OUT_index_zero + SDp_index*dimension_outSDn;

		      TYPE component_part = 0.0;
		      
		      if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
			{
			  const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;

			  const unsigned long int total_SDp_TRS_indices_index = (is_it_TRS) ? (total_SDp_TRS_indices_zero_index + SDp_index) : (NADA);

			  const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_SDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_OUT_index = (is_it_TRS) ? (TRS_total_PSI_OUT_index_zero + dimension_outSDn*SDp_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_OUT_index >= total_PSI_OUT_index))
			    {
			      bool is_there_one_jump_calc = false;
						      
			      is_configuration_accepted_total_PSI_in_indices_n_fill (BPp , Sp , n_spec_p , n_holes_p , n_scat_p , iCp , iMp , SDp_index , Ep_hw , one_jump_n , GSM_vector_helper ,
										     is_configuration_accepted_one_jump_n_in_tab , total_PSI_IN_indices_one_jump_n , is_there_one_jump_calc);
						  
			      if (is_there_one_jump_calc)
				{
				  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
				      
				  component_part += component_part_jumps_calc (dimension_one_jump_n , is_configuration_accepted_one_jump_n_in_tab , total_PSI_IN_indices_one_jump_n , NBMEs_n_one_jump_n , PSI_IN_full);
				}
			    }
		      
			  const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_OUT_index == total_PSI_OUT_index)) ? (PSI_OUT[PSI_OUT_index]) : (2.0*PSI_OUT[PSI_OUT_index]);
		      
			  const TYPE multipole_ME_part = component_part*PSI_OUT_component_TRS_factor;
	      
			  Re_multipole_ME += real_dc (multipole_ME_part);
			  Im_multipole_ME += imag_dc (multipole_ME_part);
			}}}}}}
  
  const TYPE multipole_ME = generate_scalar<TYPE> (Re_multipole_ME , Im_multipole_ME);
	
  return multipole_ME;
}

TYPE GSM_multipoles::jumps_n_two_body_part_pn_calc (
						    const int L ,
						    const bool is_it_HO_expansion ,
						    const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
						    const class GSM_vector &PSI_IN_full ,
						    const class GSM_vector &PSI_OUT)
{  
  const class GSM_vector_helper_class &GSM_vector_helper = PSI_OUT.get_GSM_vector_helper ();
        
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int NYval = neut_Y_data.get_N_valence_baryons ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM ();
    
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();

  const int iMp_max = prot_Y_data.get_iM_max ();
    
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
    
  const unsigned int dimension_nn_2p2h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_2p2h_space_BP_S_iM_fixed_max ();
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab (); 

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
   
  const unsigned long int first_total_PSI_OUT_index =  GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_OUT_index =  GSM_vector_helper.get_last_total_PSI_index ();
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();

  if (total_outSDn_index_min > total_outSDn_index_max) return 0.0;
    
  class array<class jumps_data_out_to_in_str> two_jumps_n_tab(NUMBER_OF_THREADS);  	      
  
  class array<class array<TYPE> > NBMEs_two_jumps_n_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_configuration_accepted_two_jumps_n_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_IN_indices_two_jumps_n_tab(NUMBER_OF_THREADS);

  if (NYval >= 2)
    {
      for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
	{
	  two_jumps_n_tab(i).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_nn_2p2h_space_BP_S_iM_fixed_max);
		
	  NBMEs_two_jumps_n_tab(i).allocate (dimension_nn_2p2h_space_BP_S_iM_fixed_max);
      
	  is_configuration_accepted_two_jumps_n_tabs(i).allocate (dimension_nn_2p2h_space_BP_S_iM_fixed_max);

	  total_PSI_IN_indices_two_jumps_n_tab(i).allocate (dimension_nn_2p2h_space_BP_S_iM_fixed_max);
	}
    }
  
  double Re_multipole_ME = 0.0;
  double Im_multipole_ME = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_multipole_ME , Im_multipole_ME)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn = outSDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = outSDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sn = outSDn_qn.get_S ();

      const int Sp = S - Sn;
      
      const int n_spec_n = outSDn_qn.get_n_spec ();

      const int n_spec_p = n_spec_max - n_spec_n;

      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

      if (dimension_outSDn == 0) continue;
		  
      const int iMp = iM - iMn;

      const int TRS_iMp = iMp_max - iMp;
      
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

      if (all_dimensions_SDp_zero) continue;
		  
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class jumps_data_out_to_in_str &two_jumps_n = two_jumps_n_tab(i_thread);
      
      class array<TYPE> &NBMEs_two_jumps_n = NBMEs_two_jumps_n_tab(i_thread);
      
      class array<bool> &is_configuration_accepted_two_jumps_n_tab = is_configuration_accepted_two_jumps_n_tabs(i_thread);
	      
      class array<unsigned long int> &total_PSI_IN_indices_two_jumps_n = total_PSI_IN_indices_two_jumps_n_tab(i_thread);
  	
      bool are_jumps_n_calculated = false;

      bool are_there_two_jumps_calc_all = true;
		      
      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && are_there_two_jumps_calc_all ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
			  
	  for (unsigned int iCp = iCp_min ; (iCp <= iCp_max) && are_there_two_jumps_calc_all ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
	      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;
	      
	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

	      if (dimension_SDp == 0) continue;

	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , iMp);

	      const unsigned long int total_PSI_OUT_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;

	      const unsigned long int total_PSI_OUT_index_dimension_minus_one = total_PSI_OUT_index_zero + dimension_SDp_minus_one*dimension_outSDn;
  
	      if ((total_PSI_OUT_index_zero <= last_total_PSI_OUT_index) && (total_PSI_OUT_index_dimension_minus_one >= first_total_PSI_OUT_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_SDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_OUT_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);
				      	      
		  if (!are_jumps_n_calculated)
		    {
		      are_there_two_jumps_calc_all = false;

		      NBMEs_two_jumps_pp_nn_calc_store (GSM_vector_helper , L , is_it_HO_expansion , neut_Y_data , TBMEs_angular_table ,
							BPn , Sn , n_spec_n , iMn , n_scat_n_out , iCn_out , outSDn_index , are_there_two_jumps_calc_all , two_jumps_n , NBMEs_two_jumps_n);
			
		      are_jumps_n_calculated = true;
		    }

		  if (!are_there_two_jumps_calc_all) continue;
		  
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      const unsigned long int total_PSI_OUT_index = total_PSI_OUT_index_zero + SDp_index*dimension_outSDn;

		      TYPE component_part = 0.0;
		      
		      if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
			{
			  const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;

			  const unsigned long int total_SDp_TRS_indices_index = (is_it_TRS) ? (total_SDp_TRS_indices_zero_index + SDp_index) : (NADA);

			  const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_SDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_OUT_index = (is_it_TRS) ? (TRS_total_PSI_OUT_index_zero + dimension_outSDn*SDp_TRS_index) : (NADA);
				
			  if (!is_it_TRS || (TRS_total_PSI_OUT_index >= total_PSI_OUT_index))
			    {
			      bool are_there_two_jumps_calc = false;

			      is_configuration_accepted_total_PSI_in_indices_n_fill (BPp , Sp , n_spec_p , n_holes_p , n_scat_p , iCp , iMp , SDp_index , Ep_hw , two_jumps_n , GSM_vector_helper ,
										     is_configuration_accepted_two_jumps_n_tab , total_PSI_IN_indices_two_jumps_n , are_there_two_jumps_calc);
			      
			      if (are_there_two_jumps_calc)
				{
				  const unsigned int dimension_two_jumps_n = two_jumps_n.get_dimension ();
				  				  
				  component_part += component_part_jumps_calc (dimension_two_jumps_n , is_configuration_accepted_two_jumps_n_tab , total_PSI_IN_indices_two_jumps_n , NBMEs_two_jumps_n , PSI_IN_full);
				}
			    }
		      
			  const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_OUT_index == total_PSI_OUT_index)) ? (PSI_OUT[PSI_OUT_index]) : (2.0*PSI_OUT[PSI_OUT_index]);
		      
			  const TYPE multipole_ME_part = component_part*PSI_OUT_component_TRS_factor;
	      
			  Re_multipole_ME += real_dc (multipole_ME_part);
			  Im_multipole_ME += imag_dc (multipole_ME_part);
			}}}}}}
  
  const TYPE multipole_ME = generate_scalar<TYPE> (Re_multipole_ME , Im_multipole_ME);
	
  return multipole_ME;
}

TYPE GSM_multipoles::one_jump_p_pn_part_pn_calc (
						 const int L ,
						 const bool is_it_HO_expansion ,
						 const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
						 const class GSM_vector &PSI_IN_full ,
						 const class GSM_vector &PSI_OUT)
{
  if (L%2 == 1) return 0.0;
  
  const class GSM_vector_helper_class &GSM_vector_helper = PSI_OUT.get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 

  const int iM = GSM_vector_helper.get_iM (); 

  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
  
  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
      
  const unsigned int Np_nljm = prot_Y_data.get_N_nljm_baryon ();
        
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
 		  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
      
  const unsigned long int first_total_PSI_OUT_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_OUT_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_out_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const unsigned long int total_SDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_SDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();
    
  if (total_SDn_index_min > total_SDn_index_max) return 0.0;
    
  class array<class Slater_determinant> SDn_tab(NUMBER_OF_THREADS);
  
  class array<class jumps_data_out_to_in_str> one_jump_p_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > NBMEs_pn_one_jump_p_no_phase_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > NBMEs_pn_one_jump_p_no_phase_calculated_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SDn_tab(i).allocate (NYval);
      
      one_jump_p_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
      
      NBMEs_pn_one_jump_p_no_phase_tab(i).allocate (Np_nljm , Np_nljm);

      NBMEs_pn_one_jump_p_no_phase_calculated_tab(i).allocate (Np_nljm , Np_nljm);
    }
       
  double Re_multipole_ME = 0.0;
  double Im_multipole_ME = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_multipole_ME , Im_multipole_ME)
#endif
  for (unsigned long int total_SDn_index = total_SDn_index_min ; total_SDn_index <= total_SDn_index_max ; total_SDn_index++)
    {
      const class SD_quantum_numbers &SDn_qn = SDn_quantum_numbers_tab(total_SDn_index);

      const int iMn = SDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = SDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sn = SDn_qn.get_S ();

      const int Sp = S - Sn;
      
      const int n_spec_n = SDn_qn.get_n_spec ();

      const int n_spec_p = n_spec_max - n_spec_n;

      const int n_scat_n = SDn_qn.get_n_scat ();
	
      const unsigned int iCn = SDn_qn.get_iC ();

      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (dimension_SDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (all_dimensions_SDp_zero) continue;
		  
      const unsigned int SDn_index = SDn_qn.get_SD_index ();
            
      const int iMp = iM - iMn;

      const int TRS_iMp = iMp_max - iMp;
      
      const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class Slater_determinant &SDn = SDn_tab(i_thread);
      
      class array<TYPE> &NBMEs_pn_one_jump_p_no_phase = NBMEs_pn_one_jump_p_no_phase_tab(i_thread);

      class array<bool> &NBMEs_pn_one_jump_p_no_phase_calculated = NBMEs_pn_one_jump_p_no_phase_calculated_tab(i_thread);
        
      SDn = SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index);
      
      NBMEs_pn_one_jump_p_no_phase = 0.0;

      NBMEs_pn_one_jump_p_no_phase_calculated = false;

      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_process_tab(BPp , Sp , n_spec_p , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_process_tab(BPp , Sp , n_spec_p , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , iMp);
	          
	      const unsigned long int total_PSI_OUT_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + SDn_index;
	      
	      const unsigned long int total_PSI_OUT_index_dimension_minus_one = total_PSI_OUT_index_zero + dimension_SDn*dimension_outSDp_minus_one;
				  
	      if ((total_PSI_OUT_index_zero <= last_total_PSI_OUT_index) && (total_PSI_OUT_index_dimension_minus_one >= first_total_PSI_OUT_index))
		{		  
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_outSDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_OUT_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + SDn_TRS_index) : (NADA);
					  
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned long int total_PSI_OUT_index = total_PSI_OUT_index_zero + outSDp_index*dimension_SDn;
		      
		      if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
			{
			  const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;
						  
			  const unsigned long int total_outSDp_TRS_indices_index = (is_it_TRS) ? (total_outSDp_TRS_indices_zero_index + outSDp_index) : (NADA);

			  const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_outSDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_OUT_index = (is_it_TRS) ? (TRS_total_PSI_OUT_index_zero + dimension_SDn*outSDp_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_OUT_index >= total_PSI_OUT_index))
			    {
			      class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(i_thread);

			      one_jump_p.one_jump_mu_store (BPp , Sp , n_spec_p , iMp , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index , prot_Y_data);
			      
			      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();

			      unsigned long int total_PSI_IN_index_zero = 0;

			      bool is_configuration_accepted = true; 
			      
			      TYPE component_part = 0.0;

			      for (unsigned int i = 0 ; i < dimension_one_jump_p ; i++)
				{
				  const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(i);

				  const bool is_configuration_changing = one_jump_p_inSDp.get_is_configuration_changing ();

				  if (is_configuration_changing)
				    { 
				      const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
				      
				      const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();

				      const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();

				      is_configuration_accepted =
					is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_hw_in , n_holes_max_p , n_scat_max_p , Ep_max_hw) &&
					is_basis_state_in_space_pn    (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_hw_in , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw);

				      if (is_configuration_accepted) 
					{
					  const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();

					  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p_in , n_scat_n , iCp_in , iCn , iMp);

					  total_PSI_IN_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in + SDn_index;
					}
				    }

				  if (is_configuration_accepted)
				    {
				      const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

				      const unsigned long int total_PSI_IN_index = total_PSI_IN_index_zero + dimension_SDn*inSDp_index;

				      const unsigned int p_in  = one_jump_p_inSDp.get_mu_in ();
				      const unsigned int p_out = one_jump_p_inSDp.get_mu_out ();

				      const unsigned int total_bin_phase_p = one_jump_p_inSDp.get_total_bin_phase ();

				      const bool NBME_pn_one_jump_p_no_phase_calculated = NBMEs_pn_one_jump_p_no_phase_calculated(p_in , p_out);

				      const int total_phase_p = parity_from_binary_parity (total_bin_phase_p);
				      
				      const TYPE &PSI_IN_component = PSI_IN_full[total_PSI_IN_index];
					      
				      if (!NBME_pn_one_jump_p_no_phase_calculated)
					{ 
					  const TYPE NBME_pn_one_jump_p_no_phase = NBME_pn_no_phase_one_jump_p_calc (L , is_it_HO_expansion , prot_Y_data , neut_Y_data , TBMEs_angular_table , p_in , p_out , SDn);
 
					  NBMEs_pn_one_jump_p_no_phase(p_in , p_out) = NBMEs_pn_one_jump_p_no_phase(p_out , p_in) = NBME_pn_one_jump_p_no_phase;
					  
					  NBMEs_pn_one_jump_p_no_phase_calculated(p_in , p_out) = NBMEs_pn_one_jump_p_no_phase_calculated(p_out , p_in) = true;
						  
					  (total_phase_p == 1) ? (component_part += PSI_IN_component*NBME_pn_one_jump_p_no_phase) : (component_part -= PSI_IN_component*NBME_pn_one_jump_p_no_phase);
					}
				      else
					{
					  const TYPE NBME_pn_one_jump_p_no_phase = NBMEs_pn_one_jump_p_no_phase(p_in , p_out);
						  
					  (total_phase_p == 1) ? (component_part += PSI_IN_component*NBME_pn_one_jump_p_no_phase) : (component_part -= PSI_IN_component*NBME_pn_one_jump_p_no_phase);
					}
				    }
				}
				
			      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_OUT_index == total_PSI_OUT_index)) ? (PSI_OUT[PSI_OUT_index]) : (2.0*PSI_OUT[PSI_OUT_index]);
		      
			      const TYPE multipole_ME_part = component_part*PSI_OUT_component_TRS_factor;
	      
			      Re_multipole_ME += real_dc (multipole_ME_part);
			      Im_multipole_ME += imag_dc (multipole_ME_part);
			    }}}}}}}
  
  const TYPE multipole_ME = generate_scalar<TYPE> (Re_multipole_ME , Im_multipole_ME);
	
  return multipole_ME;
}

TYPE GSM_multipoles::one_jump_n_pn_part_pn_calc (
						 const int L ,
						 const bool is_it_HO_expansion ,
						 const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
						 const class GSM_vector &PSI_IN_full ,
						 const class GSM_vector &PSI_OUT)
{
  if (L%2 == 1) return 0.0;
  
  const class GSM_vector_helper_class &GSM_vector_helper = PSI_OUT.get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM (); 

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
      
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const unsigned int Nn_nljm = neut_Y_data.get_N_nljm_baryon ();
  
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
 
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const unsigned long int first_total_PSI_OUT_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_OUT_index = GSM_vector_helper.get_last_total_PSI_index ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
    
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
 
  const class array<unsigned int> &iCn_out_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_out_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int total_SDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_SDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();
    
  if (total_SDp_index_min > total_SDp_index_max) return 0.0;

  class array<class Slater_determinant> SDp_tab(NUMBER_OF_THREADS);
  
  class array<class jumps_data_out_to_in_str> one_jump_n_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > NBMEs_pn_one_jump_n_no_phase_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > NBMEs_pn_one_jump_n_no_phase_calculated_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SDp_tab(i).allocate (ZYval);
      
      one_jump_n_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      NBMEs_pn_one_jump_n_no_phase_tab(i).allocate (Nn_nljm , Nn_nljm);

      NBMEs_pn_one_jump_n_no_phase_calculated_tab(i).allocate (Nn_nljm , Nn_nljm);
    }
          
  double Re_multipole_ME = 0.0;
  double Im_multipole_ME = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_multipole_ME , Im_multipole_ME)
#endif
  for (unsigned long int total_SDp_index = total_SDp_index_min ; total_SDp_index <= total_SDp_index_max ; total_SDp_index++)
    {
      const class SD_quantum_numbers &SDp_qn = SDp_quantum_numbers_tab(total_SDp_index);

      const int iMp = SDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = SDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sp = SDp_qn.get_S ();

      const int Sn = S - Sp;
      
      const int n_spec_p = SDp_qn.get_n_spec ();

      const int n_spec_n = n_spec_max - n_spec_p;
      
      const int n_scat_p = SDp_qn.get_n_scat ();
	
      const unsigned int iCp = SDp_qn.get_iC ();

      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (dimension_SDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (all_dimensions_SDn_zero) continue;

      const int iMn = iM - iMp;

      const int TRS_iMp = iMp_max - iMp;

      const unsigned int SDp_index = SDp_qn.get_SD_index ();
      
      const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class Slater_determinant &SDp = SDp_tab(i_thread);

      class array<TYPE> &NBMEs_pn_one_jump_n_no_phase = NBMEs_pn_one_jump_n_no_phase_tab(i_thread);

      class array<bool> &NBMEs_pn_one_jump_n_no_phase_calculated = NBMEs_pn_one_jump_n_no_phase_calculated_tab(i_thread);

      SDp = SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index);
      
      NBMEs_pn_one_jump_n_no_phase = 0.0;

      NBMEs_pn_one_jump_n_no_phase_calculated = false;

      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_process_tab(BPn , Sn , n_spec_n , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_process_tab(BPn , Sn , n_spec_n , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);
      
	      const int En_hw_out = En_hw_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , iMp);
	      
	      const unsigned long int total_PSI_OUT_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*SDp_index;
	      
	      const unsigned long int total_PSI_OUT_index_dimension_minus_one = total_PSI_OUT_index_zero + dimension_outSDn_minus_one;
  
	      if ((total_PSI_OUT_index_zero <= last_total_PSI_OUT_index) && (total_PSI_OUT_index_dimension_minus_one >= first_total_PSI_OUT_index))
		{		  
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , TRS_iMp)) : (NADA);
		  
		  const unsigned long int total_outSDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_OUT_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_outSDn*SDp_TRS_index) : (NADA);
					  
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned long int total_PSI_OUT_index = total_PSI_OUT_index_zero + outSDn_index;
				      
		      if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
			{
			  const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;
					      
			  const unsigned long int total_outSDn_TRS_indices_index = (is_it_TRS) ? (total_outSDn_TRS_indices_zero_index + outSDn_index) : (NADA);

			  const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_outSDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_OUT_index = (is_it_TRS) ? (TRS_total_PSI_OUT_index_zero + outSDn_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_OUT_index >= total_PSI_OUT_index))
			    {
			      class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(i_thread);
				  
			      one_jump_n.one_jump_mu_store (BPn , Sn , n_spec_n , iMn , n_holes_max_n , n_scat_max_n , En_max_hw , BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index , neut_Y_data);
			  
			      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

			      unsigned long int total_PSI_IN_index_zero = 0;

			      bool is_configuration_accepted = true; 
			      
			      TYPE component_part = 0.0;

			      for (unsigned int i = 0 ; i < dimension_one_jump_n ; i++)
				{
				  const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(i);

				  const bool is_configuration_changing = one_jump_n_inSDn.get_is_configuration_changing ();

				  if (is_configuration_changing)
				    { 
				      const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
				      
				      const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();

				      const int En_hw_in = one_jump_n_inSDn.get_E_hw ();
				      
				      is_configuration_accepted =
					is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_in , n_scat_n_in , En_hw_in , n_holes_max_n , n_scat_max_n , En_max_hw) &&
					is_basis_state_in_space_pn    (truncation_hw , truncation_ph , n_holes_p    , n_scat_p    , Ep_hw    , n_holes_n_in , n_scat_n_in , En_hw_in , n_holes_max  , n_scat_max  , E_max_hw);

				      if (is_configuration_accepted)
					{
					  const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();

					  const int iMn = iM - iMp;

					  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_in , iCp , iCn_in , iMp);

					  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_in , iCn_in , iMn);

					  total_PSI_IN_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*SDp_index;
					}
				    } 

				  if (is_configuration_accepted)
				    {
				      const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

				      const unsigned long int total_PSI_IN_index = total_PSI_IN_index_zero + inSDn_index;

				      const unsigned int n_in  = one_jump_n_inSDn.get_mu_in ();
				      const unsigned int n_out = one_jump_n_inSDn.get_mu_out ();

				      const unsigned int total_bin_phase_n = one_jump_n_inSDn.get_total_bin_phase ();

				      const bool NBME_pn_one_jump_n_no_phase_calculated = NBMEs_pn_one_jump_n_no_phase_calculated(n_in , n_out);

				      const int total_phase_n = parity_from_binary_parity (total_bin_phase_n);
				      
				      const TYPE &PSI_IN_component = PSI_IN_full[total_PSI_IN_index];
					      
				      if (!NBME_pn_one_jump_n_no_phase_calculated)
					{
					  const TYPE NBME_pn_one_jump_n_no_phase = NBME_pn_no_phase_one_jump_n_calc (L , is_it_HO_expansion , prot_Y_data , neut_Y_data , TBMEs_angular_table ,n_in , n_out , SDp);

					  NBMEs_pn_one_jump_n_no_phase(n_in , n_out) = NBMEs_pn_one_jump_n_no_phase(n_out , n_in) = NBME_pn_one_jump_n_no_phase;
					  NBMEs_pn_one_jump_n_no_phase_calculated(n_in , n_out) = NBMEs_pn_one_jump_n_no_phase_calculated(n_out , n_in) = true;
						  
					  (total_phase_n == 1) ? (component_part += PSI_IN_component*NBME_pn_one_jump_n_no_phase) : (component_part -= PSI_IN_component*NBME_pn_one_jump_n_no_phase);
					}
				      else
					{
					  const TYPE NBME_pn_one_jump_n_no_phase = NBMEs_pn_one_jump_n_no_phase(n_in , n_out);
						  
					  (total_phase_n == 1) ? (component_part += PSI_IN_component*NBME_pn_one_jump_n_no_phase) : (component_part -= PSI_IN_component*NBME_pn_one_jump_n_no_phase);
					}
				    }
				}
					
			      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_OUT_index == total_PSI_OUT_index)) ? (PSI_OUT[PSI_OUT_index]) : (2.0*PSI_OUT[PSI_OUT_index]);
		      
			      const TYPE multipole_ME_part = component_part*PSI_OUT_component_TRS_factor;
	      
			      Re_multipole_ME += real_dc (multipole_ME_part);
			      Im_multipole_ME += imag_dc (multipole_ME_part);
			      			      
			    }}}}}}}
  
  const TYPE multipole_ME = generate_scalar<TYPE> (Re_multipole_ME , Im_multipole_ME);
	
  return multipole_ME;
}

TYPE GSM_multipoles::two_jumps_pn_part_pn_N_valence_larger_calc (
								 const int L ,
								 const bool is_it_HO_expansion ,
								 const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
								 const class GSM_vector &PSI_IN_full ,
								 const class GSM_vector &PSI_OUT)
{  
  const class GSM_vector_helper_class &GSM_vector_helper = PSI_OUT.get_GSM_vector_helper ();
          
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
    
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int S_plus_one = S + 1;
  
  const int n_spec_max_plus_one = n_spec_max + 1;
  
  const unsigned int BP_L = binary_parity_from_orbital_angular_momentum (L);
  
  const int iM = GSM_vector_helper.get_iM ();
    
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();
    
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int four_mn_max_plus_one = four_mn_max + 1;
     
  const int iMp_max = prot_Y_data.get_iM_max ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
    
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab (); 

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const unsigned long int first_total_PSI_OUT_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_OUT_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const class array<unsigned int> &iCp_out_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_out_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
    
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();

  if (total_outSDn_index_min > total_outSDn_index_max) return 0.0;
  	
  class array<class array<bool> > is_one_jump_n_calculated_tabs(NUMBER_OF_THREADS);
  
  class array<class array<class jumps_data_out_to_in_str> > one_jump_n_tabs(NUMBER_OF_THREADS);
  
  class array<class jumps_data_out_to_in_str> one_jump_p_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      is_one_jump_n_calculated_tabs(i).allocate (2 , S_plus_one , n_spec_max_plus_one , four_mn_max_plus_one);
      
      class array<class jumps_data_out_to_in_str> &one_jump_n_tab = one_jump_n_tabs(i);
			
      one_jump_n_tab.allocate (2 , S_plus_one , n_spec_max_plus_one , four_mn_max_plus_one);
      
      for (unsigned int BPn_in = 0 ; BPn_in <= 1 ; BPn_in++)
	for (int Sn_in = 0 ; Sn_in <= S ; Sn_in++)
	  for (int n_spec_n_in = 0 ; n_spec_n_in <= n_spec_max ; n_spec_n_in++)
	    for (int Delta_iMn_in = 0 ; Delta_iMn_in <= four_mn_max ; Delta_iMn_in++)
	      one_jump_n_tab(BPn_in , Sn_in , n_spec_n_in , Delta_iMn_in).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      one_jump_p_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
    }
  
  double Re_multipole_ME = 0.0;
  double Im_multipole_ME = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_multipole_ME , Im_multipole_ME)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();

      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();

      const unsigned int BPp_out = binary_parity_product (BPn_out , BP);

      const unsigned int BPp_in = binary_parity_product (BPp_out , BP_L);
      const unsigned int BPn_in = binary_parity_product (BPn_out , BP_L);

      const int Sn_out = outSDn_qn.get_S ();

      const int Sp_out = S - Sn_out;

      const int Sn_in = Sn_out;
      const int Sp_in = Sp_out;
      
      const int n_spec_n_out = outSDn_qn.get_n_spec ();

      const int n_spec_p_out = n_spec_max - n_spec_n_out;
      
      const int n_spec_n_in = n_spec_n_out;
      const int n_spec_p_in = n_spec_p_out;
      
      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;
		  
      const int iMp_out = iM - iMn_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M_local = max (iMp_min_M , iMp_out - L);
      const int iMp_in_max_M_local = min (iMp_max_M , iMp_out + L);
      
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;
		  
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
   
      class array<bool> &is_one_jump_n_calculated_tab = is_one_jump_n_calculated_tabs(i_thread);

      class array<class jumps_data_out_to_in_str> &one_jump_n_tab = one_jump_n_tabs(i_thread);
      
      class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(i_thread);
        
      is_one_jump_n_calculated_tab = false;
            
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{
	  const unsigned int iCp_out_min = iCp_out_min_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
			  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;
	      
	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;

	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

	      const unsigned long int total_PSI_OUT_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;

	      const unsigned long int total_PSI_OUT_index_dimension_minus_one = total_PSI_OUT_index_zero + dimension_outSDp_minus_one*dimension_outSDn;
  
	      if ((total_PSI_OUT_index_zero <= last_total_PSI_OUT_index) && (total_PSI_OUT_index_dimension_minus_one >= first_total_PSI_OUT_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out)) : (NADA);
				  
		  const unsigned long int total_outSDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_OUT_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);			
      
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned long int total_PSI_OUT_index = total_PSI_OUT_index_zero + dimension_outSDn*outSDp_index;

		      if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
			{
			  const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;
			  
			  const unsigned long int total_outSDp_TRS_indices_index = (is_it_TRS) ? (total_outSDp_TRS_indices_zero_index + outSDp_index) : (NADA);
			  const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_outSDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_OUT_index = (is_it_TRS) ? (TRS_total_PSI_OUT_index_zero + dimension_outSDn*outSDp_TRS_index) : (NADA);
			  
			  if (!is_it_TRS || (TRS_total_PSI_OUT_index >= total_PSI_OUT_index))
			    {
			      for (int iMp_in = iMp_in_min_M_local ; iMp_in <= iMp_in_max_M_local ; iMp_in++)	
				{
				  const int iMn_in = iM - iMp_in;
				  
				  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
				  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
				  
				  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
				  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				      
				  bool &is_one_jump_n_calculated = is_one_jump_n_calculated_tab(BPn_in , Sn_in , Delta_iMn_in);
				  
				  class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in);
				  	      
				  if (!is_one_jump_n_calculated)
				    {
				      one_jump_n.one_jump_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw , BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , neut_Y_data);

				      is_one_jump_n_calculated = true;				      
				    }

				  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
			  
				  if (dimension_one_jump_n == 0) continue;
			      
				  one_jump_p.one_jump_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , prot_Y_data);
			      
				  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				  
				  if (dimension_one_jump_p == 0) continue;

				  unsigned long int total_PSI_IN_index_zero_inSDn = 0;

				  bool is_configuration_accepted = true;
				  
				  TYPE component_part = 0.0;
				  
				  for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)
				    {
				      const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);

				      const unsigned int p_in  = one_jump_p_inSDp.get_mu_in ();
				      const unsigned int p_out = one_jump_p_inSDp.get_mu_out ();
					  
				      if (!is_uncoupled_TBME_pn_trivial_zero_determine_coupling_only (L , phi_p_table , p_in , p_out))
					{
					  const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();
					  
					  const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

					  const unsigned int total_bin_phase_p = one_jump_p_inSDp.get_total_bin_phase ();

					  const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
					  
					  const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();

					  const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();
				      
					  for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)
					    {
					      const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);

					      const unsigned int n_in  = one_jump_n_inSDn.get_mu_in ();
					      const unsigned int n_out = one_jump_n_inSDn.get_mu_out ();
					      
					      const bool is_configuration_changing = one_jump_n_inSDn.get_is_configuration_changing ();
									  
					      if (is_configuration_changing)
						{ 
						  const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
							  
						  const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();
							  
						  const int En_hw_in = one_jump_n_inSDn.get_E_hw ();
								      
						  is_configuration_accepted = true;
									  
						  if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw))            is_configuration_accepted = false;
						  if (truncation_ph && (n_holes_p_in + n_holes_n_in > n_holes_max)) is_configuration_accepted = false;
						  if (truncation_ph && (n_scat_p_in + n_scat_n_in > n_scat_max))    is_configuration_accepted = false;

						  if (is_configuration_accepted) 
						    {
						      const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();
						
						      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
				      
						      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
							  
						      total_PSI_IN_index_zero_inSDn = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*inSDp_index;
						    }
						}
						      
					      if (!is_uncoupled_TBME_pn_trivial_zero_determine_coupling_only (L , phi_n_table , n_in , n_out))
						{
						  const TYPE TBME = uncoupled_TBME_pn_calc (L , is_it_HO_expansion , prot_Y_data , neut_Y_data , TBMEs_angular_table , p_in , n_in , p_out , n_out);
										
						  if ((TBME != 0.0) && is_configuration_accepted)
						    {
						      const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();
							  
						      const unsigned long int total_PSI_IN_index = total_PSI_IN_index_zero_inSDn + inSDn_index;
							  
						      const unsigned int total_bin_phase_n = one_jump_n_inSDn.get_total_bin_phase ();
							  
						      const TYPE &PSI_IN_component = PSI_IN_full[total_PSI_IN_index];
							  
						      (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_IN_component*TBME) : (component_part -= PSI_IN_component*TBME);

						    }}}}}
							  
				  const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_OUT_index == total_PSI_OUT_index)) ? (PSI_OUT[PSI_OUT_index]) : (2.0*PSI_OUT[PSI_OUT_index]);
		      
				  const TYPE multipole_ME_part = component_part*PSI_OUT_component_TRS_factor;
	      
				  Re_multipole_ME += real_dc (multipole_ME_part);
				  Im_multipole_ME += imag_dc (multipole_ME_part);
			  
				}}}}}}}}
  
  const TYPE multipole_ME = generate_scalar<TYPE> (Re_multipole_ME , Im_multipole_ME);
	
  return multipole_ME;
}

TYPE GSM_multipoles::two_jumps_pn_part_pn_Z_valence_larger_calc (
								 const int L ,
								 const bool is_it_HO_expansion ,
								 const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
								 const class GSM_vector &PSI_IN_full ,
								 const class GSM_vector &PSI_OUT)
{  
  const class GSM_vector_helper_class &GSM_vector_helper = PSI_OUT.get_GSM_vector_helper ();
        
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
    
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int S_plus_one = S + 1;
  
  const int n_spec_max_plus_one = n_spec_max + 1;
  
  const unsigned int BP_L = binary_parity_from_orbital_angular_momentum (L);
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 
  
  const int four_mp_max_plus_one = four_mp_max + 1;
  
  const int iMp_max = prot_Y_data.get_iM_max ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
         
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
    
  const unsigned long int first_total_PSI_OUT_index =  GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_OUT_index =  GSM_vector_helper.get_last_total_PSI_index ();

  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCn_out_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_out_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  if (total_outSDp_index_min > total_outSDp_index_max) return 0.0;
      
  class array<class array<bool> > is_one_jump_p_calculated_tabs(NUMBER_OF_THREADS);
  
  class array<class array<class jumps_data_out_to_in_str> > one_jump_p_tabs(NUMBER_OF_THREADS);
  
  class array<class jumps_data_out_to_in_str> one_jump_n_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      is_one_jump_p_calculated_tabs(i).allocate (2 , S_plus_one , n_spec_max_plus_one , four_mp_max_plus_one);
      
      class array<class jumps_data_out_to_in_str> &one_jump_p_tab = one_jump_p_tabs(i);
      
      one_jump_p_tab.allocate (2 , S_plus_one , n_spec_max_plus_one , four_mp_max_plus_one);
      
      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
	for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
	  for (int n_spec_p_in = 0 ; n_spec_p_in <= n_spec_max ; n_spec_p_in++)
	    for (int Delta_iMp_in = 0 ; Delta_iMp_in <= four_mp_max ; Delta_iMp_in++)
	      one_jump_p_tab(BPp_in , Sp_in , n_spec_p_in , Delta_iMp_in).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
      
      one_jump_n_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
    }
     
  double Re_multipole_ME = 0.0;
  double Im_multipole_ME = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_multipole_ME , Im_multipole_ME)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();

      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);

      const unsigned int BPp_in = binary_parity_product (BPp_out , BP_L);
      const unsigned int BPn_in = binary_parity_product (BPn_out , BP_L);

      const int Sp_out = outSDp_qn.get_S ();

      const int Sn_out = S - Sp_out;

      const int Sp_in = Sp_out;
      const int Sn_in = Sn_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();

      const int n_spec_n_out = n_spec_max - n_spec_p_out;

      const int n_spec_p_in = n_spec_p_out;
      const int n_spec_n_in = n_spec_n_out;

      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;
	
      const int iMn_out = iM - iMp_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M_local = max (iMp_min_M , iMp_out - L);
      const int iMp_in_max_M_local = min (iMp_max_M , iMp_out + L);
      
      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();
  
      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index)) : (NADA);

      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class array<bool> &is_one_jump_p_calculated_tab = is_one_jump_p_calculated_tabs(i_thread);

      class array<class jumps_data_out_to_in_str> &one_jump_p_tab = one_jump_p_tabs(i_thread);
      
      class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(i_thread);
            
      is_one_jump_p_calculated_tab = false;
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
			  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
				  
	      const unsigned long int total_PSI_OUT_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;

	      const unsigned long int total_PSI_OUT_index_dimension_minus_one = total_PSI_OUT_index_zero + dimension_outSDn_minus_one;
  
	      if ((total_PSI_OUT_index_zero <= last_total_PSI_OUT_index) && (total_PSI_OUT_index_dimension_minus_one >= first_total_PSI_OUT_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out)) : (NADA);
				  
		  const unsigned long int total_outSDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_OUT_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_outSDn*outSDp_TRS_index) : (NADA);
      
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned long int total_PSI_OUT_index = total_PSI_OUT_index_zero + outSDn_index;

		      if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
			{
			  const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;
			
			  const unsigned long int total_outSDn_TRS_indices_index = (is_it_TRS) ? (total_outSDn_TRS_indices_zero_index + outSDn_index) : (NADA);
			  const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_outSDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_OUT_index = (is_it_TRS) ? (TRS_total_PSI_OUT_index_zero + outSDn_TRS_index) : (NADA);
						      
			  if (!is_it_TRS || (TRS_total_PSI_OUT_index >= total_PSI_OUT_index))
			    {
			      for (int iMp_in = iMp_in_min_M_local ; iMp_in <= iMp_in_max_M_local ; iMp_in++)	
				{
				  const int iMn_in = iM - iMp_in;
				  
				  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
				  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
				  
				  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
				  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				      
				  bool &is_one_jump_p_calculated = is_one_jump_p_calculated_tab(BPp_in , Sp_in , Delta_iMp_in);
				  
				  class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in);
	      
				  if (!is_one_jump_p_calculated)
				    {
				      one_jump_p.one_jump_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , prot_Y_data);
			      
				      is_one_jump_p_calculated = true;
				    }
			  
				  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				  
				  if (dimension_one_jump_p == 0) continue;

				  one_jump_n.one_jump_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw , BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , neut_Y_data);

				  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
				  
				  if (dimension_one_jump_n == 0) continue;

				  unsigned long int total_PSI_IN_index_zero_inSDp = 0;

				  bool is_configuration_accepted = true;
				  
				  TYPE component_part = 0.0;
			  
				  for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++) 
				    {
				      const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);
			      
				      const unsigned int n_in  = one_jump_n_inSDn.get_mu_in ();
				      const unsigned int n_out = one_jump_n_inSDn.get_mu_out ();
			      
				      if (!is_uncoupled_TBME_pn_trivial_zero_determine_coupling_only (L , phi_n_table , n_in , n_out))
					{
					  const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();

					  const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

					  const unsigned int total_bin_phase_n = one_jump_n_inSDn.get_total_bin_phase ();

					  const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
					  
					  const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();

					  const int En_hw_in = one_jump_n_inSDn.get_E_hw ();

					  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
				  				  
					  for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
					    {
					      const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);

					      const unsigned int p_in  = one_jump_p_inSDp.get_mu_in ();
					      const unsigned int p_out = one_jump_p_inSDp.get_mu_out ();
					      
					      const bool is_configuration_changing = one_jump_p_inSDp.get_is_configuration_changing ();
		      
					      if (is_configuration_changing) 
						{ 
						  const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
							  
						  const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();
							  
						  const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();

						  is_configuration_accepted = true;
									  
						  if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw))            is_configuration_accepted = false;
						  if (truncation_ph && (n_holes_p_in + n_holes_n_in > n_holes_max)) is_configuration_accepted = false;
						  if (truncation_ph && (n_scat_p_in + n_scat_n_in > n_scat_max))    is_configuration_accepted = false;
									  
						  if (is_configuration_accepted) 
						    {
						      const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();
			      
						      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
							  
						      total_PSI_IN_index_zero_inSDp = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;
						    }
						}
						      
					      if (!is_uncoupled_TBME_pn_trivial_zero_determine_coupling_only (L , phi_p_table , p_in , p_out))
						{
						  const TYPE TBME = uncoupled_TBME_pn_calc (L , is_it_HO_expansion , prot_Y_data , neut_Y_data , TBMEs_angular_table , p_in , n_in , p_out , n_out);
										
						  if ((TBME != 0.0) && is_configuration_accepted)
						    { 
						      const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

						      const unsigned long int total_PSI_IN_index = total_PSI_IN_index_zero_inSDp + dimension_inSDn*inSDp_index;
							    
						      const unsigned int total_bin_phase_p = one_jump_p_inSDp.get_total_bin_phase ();

						      const TYPE &PSI_IN_component = PSI_IN_full[total_PSI_IN_index];
							      
						      (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_IN_component*TBME) : (component_part -= PSI_IN_component*TBME);
							      
						    }}}}}

				  const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_OUT_index == total_PSI_OUT_index)) ? (PSI_OUT[PSI_OUT_index]) : (2.0*PSI_OUT[PSI_OUT_index]);
		      
				  const TYPE multipole_ME_part = component_part*PSI_OUT_component_TRS_factor;
	      
				  Re_multipole_ME += real_dc (multipole_ME_part);
				  Im_multipole_ME += imag_dc (multipole_ME_part);
			  
				}}}}}}}}
  
  const TYPE multipole_ME = generate_scalar<TYPE> (Re_multipole_ME , Im_multipole_ME);
	
  return multipole_ME;
}

TYPE GSM_multipoles::jumps_part_pp_nn_calc (
					    const int L ,
					    const bool is_it_HO_expansion ,
					    const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
					    const class GSM_vector &PSI_IN_full ,
					    const class GSM_vector &PSI_OUT)
{  
  const class GSM_vector_helper_class &GSM_vector_helper = PSI_OUT.get_GSM_vector_helper ();
      
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
    
  const int iM = GSM_vector_helper.get_iM ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
        
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();
 
  const unsigned int dimension_1p1h_space_BP_S_iM_fixed_max = data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();

  const unsigned int dimension_2p2h_space_BP_S_iM_fixed_max = data.get_dimension_2p2h_space_BP_S_iM_fixed_max ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
      
  const class array_of_SD &SD_set = data.get_SD_set ();
  
  const unsigned long int first_total_PSI_OUT_index =  GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_OUT_index =  GSM_vector_helper.get_last_total_PSI_index ();
  
  const unsigned int dimension_max = max (dimension_1p1h_space_BP_S_iM_fixed_max , dimension_2p2h_space_BP_S_iM_fixed_max);

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = data.get_SD_TRS_indices ();
  
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = data.get_SD_quantum_numbers_tab ();
    
  const unsigned long int total_outSD_index_min = GSM_vector_helper.get_total_SD_index_min ();
  const unsigned long int total_outSD_index_max = GSM_vector_helper.get_total_SD_index_max ();

  if (total_outSD_index_min > total_outSD_index_max) return 0.0;
    
  class array<class Slater_determinant> outSDmu_tab(NUMBER_OF_THREADS);
  
  class array<class jumps_data_out_to_in_str> one_jump_mu_tab(NUMBER_OF_THREADS);
  class array<class jumps_data_out_to_in_str> two_jumps_mu_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > NBMEs_one_jump_mu_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > NBMEs_two_jumps_mu_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_IN_indices_one_jump_mu_tab(NUMBER_OF_THREADS);
  class array<class array<unsigned long int> > total_PSI_IN_indices_two_jumps_mu_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      outSDmu_tab(i).allocate (N_valence_baryons);
      
      one_jump_mu_tab(i).allocate (ONE_JUMP , space , truncation_hw , truncation_ph , dimension_1p1h_space_BP_S_iM_fixed_max);

      NBMEs_one_jump_mu_tab(i).allocate (dimension_1p1h_space_BP_S_iM_fixed_max);

      total_PSI_IN_indices_one_jump_mu_tab(i).allocate (dimension_1p1h_space_BP_S_iM_fixed_max);
      
      if (N_valence_baryons >= 2)
	{
	  two_jumps_mu_tab(i).allocate (TWO_JUMPS , space , truncation_hw , truncation_ph , dimension_2p2h_space_BP_S_iM_fixed_max);
	  
	  NBMEs_two_jumps_mu_tab(i).allocate (dimension_2p2h_space_BP_S_iM_fixed_max);
	  
	  total_PSI_IN_indices_two_jumps_mu_tab(i).allocate (dimension_2p2h_space_BP_S_iM_fixed_max);
	}
    }
  
  class array<bool> is_configuration_accepted_tab(dimension_max);

  is_configuration_accepted_tab = true;
  
  double Re_multipole_ME = 0.0;
  double Im_multipole_ME = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_multipole_ME , Im_multipole_ME)
#endif
  for (unsigned long int total_outSD_index = total_outSD_index_min ; total_outSD_index <= total_outSD_index_max ; total_outSD_index++)
    {
      const class SD_quantum_numbers &outSD_qn = SD_quantum_numbers_tab(total_outSD_index);

      const unsigned int BP_outSD = outSD_qn.get_BP ();

      if (BP_outSD != BP) continue;
      
      const int S_outSD = outSD_qn.get_S ();

      if (S_outSD != S) continue;
 
      const int iM_outSD = outSD_qn.get_iM ();

      if (iM_outSD != iM) continue;
      
      const unsigned int n_scat_out = outSD_qn.get_n_scat ();

      const unsigned int iC_out = outSD_qn.get_iC ();

      const int n_holes_out = n_holes_table(BP , S , 0 , n_scat_out , iC_out);
      
      const int E_out_hw = E_hw_table(BP , S , 0 , n_scat_out , iC_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
      
      const unsigned int outSD_index = outSD_qn.get_SD_index ();

      const unsigned long int sum_dimensions_configuration_fixed_out = sum_dimensions_GSM_vector(n_scat_out , iC_out);

      const unsigned long int total_PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;
      
      if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
	{
	  const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;
      
	  const unsigned int outSD_TRS_index = (is_it_TRS) ? (SD_TRS_indices(BP , S , 0 , n_scat_out , iC_out , iM , outSD_index)) : (NADA);

	  const unsigned long int sum_dimensions_configuration_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(n_scat_out , iC_out)) : (NADA);

	  const unsigned long int TRS_total_PSI_OUT_index = (is_it_TRS) ? (sum_dimensions_configuration_fixed_TRS_out + outSD_TRS_index) : (NADA);
      
	  TYPE component_part = 0.0;
      
	  if (!is_it_TRS || (TRS_total_PSI_OUT_index >= total_PSI_OUT_index))
	    {
	      const unsigned int i_thread = OpenMP_thread_number_determine ();

	      class Slater_determinant &outSDmu = outSDmu_tab(i_thread);
	  
	      class jumps_data_out_to_in_str &one_jump_mu  = one_jump_mu_tab(i_thread);
	      class jumps_data_out_to_in_str &two_jumps_mu = two_jumps_mu_tab(i_thread);

	      class array<TYPE> &NBMEs_one_jump_mu  = NBMEs_one_jump_mu_tab(i_thread);
	      class array<TYPE> &NBMEs_two_jumps_mu = NBMEs_two_jumps_mu_tab(i_thread);

	      class array<unsigned long int> &total_PSI_IN_indices_one_jump_mu  = total_PSI_IN_indices_one_jump_mu_tab(i_thread);
	      class array<unsigned long int> &total_PSI_IN_indices_two_jumps_mu = total_PSI_IN_indices_two_jumps_mu_tab(i_thread);

	      outSDmu = SD_set(BP , S , 0 , n_scat_out , iC_out , iM , outSD_index);
	  
	      bool is_there_one_jump_calc = false , are_there_two_jumps_calc = false;
	  
	      NBMEs_one_jump_pp_nn_calc_store (GSM_vector_helper , L , is_it_HO_expansion , data , TBMEs_angular_table ,
					       BP , S , 0 , iM , n_scat_out , iC_out , outSD_index , outSDmu , is_there_one_jump_calc , one_jump_mu , NBMEs_one_jump_mu);
	  
	      if (is_there_one_jump_calc)
		{
		  total_PSI_in_indices_pp_nn_fill (one_jump_mu , GSM_vector_helper , total_PSI_IN_indices_one_jump_mu , is_there_one_jump_calc);
	      
		  if (is_there_one_jump_calc)
		    {
		      const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();
		  
		      component_part += component_part_jumps_calc (dimension_one_jump_mu , is_configuration_accepted_tab , total_PSI_IN_indices_one_jump_mu , NBMEs_one_jump_mu , PSI_IN_full);
		    }
		}

	      NBMEs_two_jumps_pp_nn_calc_store (GSM_vector_helper , L , is_it_HO_expansion , data , TBMEs_angular_table ,
						BP , S , 0 , iM , n_scat_out , iC_out , outSD_index , are_there_two_jumps_calc , two_jumps_mu , NBMEs_two_jumps_mu);
 
	      if (are_there_two_jumps_calc)
		{
		  total_PSI_in_indices_pp_nn_fill (two_jumps_mu , GSM_vector_helper , total_PSI_IN_indices_two_jumps_mu , are_there_two_jumps_calc);
				  
		  if (are_there_two_jumps_calc)
		    {
		      const unsigned int dimension_two_jumps_mu = two_jumps_mu.get_dimension ();
		      
		      component_part += component_part_jumps_calc (dimension_two_jumps_mu , is_configuration_accepted_tab , total_PSI_IN_indices_two_jumps_mu , NBMEs_two_jumps_mu , PSI_IN_full);			
		    }
		}
	    }
      
	  const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_OUT_index == total_PSI_OUT_index)) ? (PSI_OUT[PSI_OUT_index]) : (2.0*PSI_OUT[PSI_OUT_index]);
		      
	  const TYPE multipole_ME_part = component_part*PSI_OUT_component_TRS_factor;
	      
	  Re_multipole_ME += real_dc (multipole_ME_part);
	  Im_multipole_ME += imag_dc (multipole_ME_part);      
	}
    }
  
  const TYPE multipole_ME = generate_scalar<TYPE> (Re_multipole_ME , Im_multipole_ME);
	
  return multipole_ME;
}

  


TYPE GSM_multipoles::multipole_ME_calc_one_pair (
						 class GSM_vector &PSI_IN_full ,
						 const int L ,
						 const bool is_it_HO_expansion ,
						 const double J_IN ,  
						 const class GSM_vector &PSI_IN ,
						 const double J_OUT , 
						 const class GSM_vector &PSI_OUT)
{
  if (J_IN != J_OUT) return 0.0;
    
  const class GSM_vector_helper_class &GSM_vector_helper_IN  = PSI_IN.get_GSM_vector_helper ();
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  if (!PSI_IN.same_parity_strangeness_M_projection (GSM_vector_helper_OUT)) return 0.0;
  if (!PSI_OUT.same_parity_strangeness_M_projection (GSM_vector_helper_IN)) return 0.0;
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();
      
  const double mp_max = prot_Y_data.get_m_max ();
  const double mn_max = neut_Y_data.get_m_max ();
  
  const double m_max = max (mp_max , mn_max);

  const class multipole_TBMEs_angular_table_str TBMEs_angular_table(L , m_max);
	
  class GSM_vector_helper_class GSM_vector_helper_IN_full;
  
  GSM_vector_helper_IN_full.allocate_fill_without_MPI_parallelization (GSM_vector_helper_IN);
  
  PSI_IN_full.change_GSM_vector_helper_reallocate (GSM_vector_helper_IN_full);
  
  PSI_IN_full.full_vector_fill (PSI_IN);
    
  TYPE multipole_ME_partial = 0.0;
 
  if (space == PROT_NEUT_Y)
    {      
      const int ZYval = prot_Y_data.get_N_valence_baryons ();
      const int NYval = neut_Y_data.get_N_valence_baryons ();
      
      multipole_ME_partial += diagonal_part_p_part_pn_calc (L , is_it_HO_expansion , TBMEs_angular_table , PSI_IN_full , PSI_OUT);
      multipole_ME_partial += diagonal_part_n_part_pn_calc (L , is_it_HO_expansion , TBMEs_angular_table , PSI_IN_full , PSI_OUT);

      if (NYval >= ZYval)
	multipole_ME_partial += diagonal_part_pn_part_pn_N_valence_larger_calc (L , is_it_HO_expansion , TBMEs_angular_table , PSI_IN_full , PSI_OUT);
      else
	multipole_ME_partial += diagonal_part_pn_part_pn_Z_valence_larger_calc (L , is_it_HO_expansion , TBMEs_angular_table , PSI_IN_full , PSI_OUT);
       
      multipole_ME_partial += jumps_p_one_body_part_pn_calc (L , is_it_HO_expansion , TBMEs_angular_table , PSI_IN_full , PSI_OUT);
      multipole_ME_partial += jumps_n_one_body_part_pn_calc (L , is_it_HO_expansion , TBMEs_angular_table , PSI_IN_full , PSI_OUT);
      
      multipole_ME_partial += jumps_p_two_body_part_pn_calc (L , is_it_HO_expansion , TBMEs_angular_table , PSI_IN_full , PSI_OUT);
      multipole_ME_partial += jumps_n_two_body_part_pn_calc (L , is_it_HO_expansion , TBMEs_angular_table , PSI_IN_full , PSI_OUT);
            
      multipole_ME_partial += one_jump_p_pn_part_pn_calc (L , is_it_HO_expansion , TBMEs_angular_table , PSI_IN_full , PSI_OUT);
      multipole_ME_partial += one_jump_n_pn_part_pn_calc (L , is_it_HO_expansion , TBMEs_angular_table , PSI_IN_full , PSI_OUT);
	  
      if (NYval >= ZYval)
	multipole_ME_partial += two_jumps_pn_part_pn_N_valence_larger_calc (L , is_it_HO_expansion , TBMEs_angular_table , PSI_IN_full , PSI_OUT);
      else
	multipole_ME_partial += two_jumps_pn_part_pn_Z_valence_larger_calc (L , is_it_HO_expansion , TBMEs_angular_table , PSI_IN_full , PSI_OUT);
    }
  else
    {  
      multipole_ME_partial += diagonal_part_pp_nn_calc (L , is_it_HO_expansion , TBMEs_angular_table , PSI_IN_full , PSI_OUT);
      
      multipole_ME_partial += jumps_part_pp_nn_calc (L , is_it_HO_expansion , TBMEs_angular_table , PSI_IN_full , PSI_OUT);
    }
  PSI_IN_full.remove_GSM_vector_helper ();
  
  const TYPE multipole_ME = sum_Reduce<TYPE> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , multipole_ME_partial);
  
  return multipole_ME;
}






// Calculation of the GSM multipoles <Psi[out] | Op | Psi[in]>^2 for all demanded GSM multipoles in the input file
// ---------------------------------------------------------------------------------------------------------------
// Eigenvectors are read from disk and multipole_ME_calc_one_pair is called for the GSM multipoles, to be printed on screen afterwards.

void GSM_multipoles::calc_print (
				 const class input_data_str &input_data , 
				 class baryons_data &prot_Y_data , 
				 class baryons_data &neut_Y_data , 
				 const class array<class correlated_state_str> &PSI_qn_tab ,
				 class GSM_vector &PSI_full)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "GSM multipoles" << endl;
      cout <<         "--------------" << endl << endl;
    }

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();

  const int S = input_data.get_hypernucleus_strangeness ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();

  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
  
  const int Z = prot_Y_data.get_N_nucleons ();
  const int N = neut_Y_data.get_N_nucleons ();
  
  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();
 
  const unsigned int GSM_multipoles_number = input_data.get_GSM_multipoles_number ();
  
  const class array<int> &GSM_multipoles_L_tab = input_data.get_GSM_multipoles_L_tab ();
  
  const class array<unsigned int> &GSM_multipoles_BP_tab = input_data.get_GSM_multipoles_BP_tab ();

  const class array<double> &GSM_multipoles_J_tab = input_data.get_GSM_multipoles_J_tab ();

  const class array<unsigned int> &GSM_multipoles_vector_index_tab = input_data.get_GSM_multipoles_vector_index_tab (); 
  
  const class array<bool> &GSM_multipoles_is_it_HO_expansion_tab = input_data.get_GSM_multipoles_is_it_HO_expansion_tab (); 
  
  for (unsigned int GSM_multipole_index = 0 ; GSM_multipole_index < GSM_multipoles_number ; GSM_multipole_index++)
    {      
      const int L = GSM_multipoles_L_tab(GSM_multipole_index);
      
      const unsigned int BP = GSM_multipoles_BP_tab(GSM_multipole_index);

      const unsigned int vector_index = GSM_multipoles_vector_index_tab(GSM_multipole_index);

      const double J = GSM_multipoles_J_tab(GSM_multipole_index);

      const double M = J;
      
      const class correlated_state_str PSI_qn = PSI_quantum_numbers_find (Z , N , BP , S , J , vector_index , PSI_qn_tab);

      class GSM_vector_helper_class PSI_helper(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
					       n_holes_max   , n_scat_max   , E_max_hw  ,
					       n_holes_max_p , n_scat_max_p , Ep_max_hw ,
					       n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , true , prot_Y_data , neut_Y_data);

      const class GSM_vector_helper_class dummy_helper;
      
      configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , false , false , false , false , PSI_helper , PSI_helper , dummy_helper , prot_Y_data , neut_Y_data);
            
      class GSM_vector PSI(PSI_helper);
      
      PSI.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);

      const bool is_it_HO_expansion = GSM_multipoles_is_it_HO_expansion_tab(GSM_multipole_index);

      const TYPE GSM_multipole_ME = multipole_ME_calc_one_pair (PSI_full , L , is_it_HO_expansion , J , PSI , J , PSI);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  if (is_it_HO_expansion)
	    cout << "HO expansion , " << MULTIPOLE_RL_YL << "  L:" << L << "  ";
	  else
	    cout << "R cut , " << MULTIPOLE_RL_YL << "  L:" << L << "  ";

	  cout << J_Pi_vector_index_string (BP , J , vector_index) << "  expectation value : " << GSM_multipole_ME << endl;
	}      
    }
  
  if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
}



