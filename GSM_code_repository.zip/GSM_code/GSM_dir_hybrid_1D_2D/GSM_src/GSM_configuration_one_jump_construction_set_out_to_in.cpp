#include "../GSM_include/GSM_include_def.h"

using namespace GSM_vector_dimensions;

// TYPE is double or complex
// -------------------------


// out_to_in means that one starts from |outSD> and one creates |inSD> from a+ a operations
// ----------------------------------------------------------------------------------------



// Calculation and storage of jumps for the application of many-body operators
// ---------------------------------------------------------------------------
// A many-body operator is written in second quantization: Op = \sum_ab <a | Op | b> a+(a) a(b) +  \sum_abcd <ab | Op | cd> a+(a) a+(b) a(d) a(c).
// Hence, in order to apply Op to a GSM vector vector, one has to calculate jumps of the form <outSD | a+(a) a(b) | inSD> and <outSD | a+(a) a+(b) a(d) a(c) | inSD>.

// The pp, nn two-body jumps are written as <outSD | a+(a) a+(b) a(d) a(c) | inSD> = <outSD | a+(a) a(c) | SDinter> <SDinter | a+(b) a(d) | inSD>, with |SDinter> an intermediate Slater determinant.
// The pn two-body jumps <outSD | a+(a) a+(b) a(d) a(c) | inSD> are equal to  <outSDp | a+(a) a(c) | inSDp>  <outSDn | a+(b) a(d) | inSDn>, so that no intermediate Slater determinant is needed here.
// Hence, all jumps can be calculated from those of the form <outSD | a+(a) a(b) | inSD>. 
// 
// In order not to consider intermediate Slater determinants with many particles in the continuum, one demands all Slater determinants to have a number particles in the continuum smaller or equal
// to that of the model space. This is possible as can always reshuffle the a+/a operators above for |SDinter> to be in that situation.
//
// One has |Psi[out]> = Op|Psi[in]>. To calculate the components of |Psi[out]> = \sum_{outSD} c_{outSD} |outSD>, one has to calculate c_{outSD} = \sum_{inSD} c_{inSD} <outSD | Op | inSD>.
// Hence, for a fixed c_{outSD}, one has |outSD> fixed and |inSD> varied, so that |inSD> differs by one or two states in off-diagonal matrix elements.
// As |outSD> is fixed and |inSD> is varied and is function of |outSD>, one calls this scheme "out to in".
// Consequently, in the jump routines, one starts from |outSD>, or its configuration C[out], and 1p-1h excitations generate |inSD>, or its configuration C[in].
// Hence, one goes from outSD to inSD.
// 
// One can separate in the calculation of <outSD | a+(a) a(b) | inSD> in two parts: 
//
// _One considers only configurations and shells, so that a, b become (n,l,j) shells and inSD, outSD are replaced by their configurations C[in], C[out].
//  C[in] is generated from C[out] with 1p-1h excitations from the occupied shells of C[out] to its unoccupied shells.
//  No matrix element is calculated here, but one one stores the indices the shells a, b and the quantum numbers of configurations.
//
// _One fixes C[in], C[out], a(shell), b(shell), and one obtains <outSD | a+(a) a(b) | inSD> by adding only m quantum numbers.
//  One stores the phase <outSD | a+(a) a(b) | inSD>, and also m quantum numbers.
//
// One considers only configurations and shells in this namespace.
// Previously introduced notations are used throughout this namespace.
//
// OpenMP parallelization is used on the loop of proton or neutron configurations.
// MPI parallelization here is only implicit, as on considers only the configurations which are used in operators by the current node.
// 
//
// Equivalent configurations in scattering many-body spaces
// --------------------------------------------------------
// When one has scattering states in the one-body basis, it is possible to reduce the number of stored <outSD | a+(a) a(b) | inSD> jumps by using the fact that one has many more scattering states than valence nucleons.
// For example, let us consider that the one-body states consist of 51 p3/2 shells, issued from the discretization of the p3/2 contour, and that one has a configuration of three valence nucleons.
// These are typical values in GSM. As one has in average 17 shells between two nucleons, with only one nucleon per shell for most configurations, 
// a 1p-1h excitation from an occupied shell to another leaves the <outSD | a+(a) a(b) | inSD> matrix element unchanged, as only the principal quantum number of |a> changes.
// Moreover, Slater determinants are formally identical from one configuration to the other in this case, as the number and indices of one-body states on one shell depend only on j and m.
//
// Hence, this <outSD | a+(a) a(b) | inSD> matrix element is stored only once, and one starts storing other matrix elements once 1p-1h excitations make the nucleon arrive on an occupied shell, 
// or if one arrives on a new partial wave. One-body states are evidently ordered so that all one-body states of a given partial wave are contiguous.
//
// The configuration for which <outSD | a+(a) a(b) | inSD> matrix element is stored is a called an equivalent configuration, 
// as it represents all the configurations equivalent to the latter for the calculation of <outSD | a+(a) a(b) | inSD> matrix elements.









// Storage of dimensions and configuration jumps in arrays
// -------------------------------------------------------
// A C[out] configuration jump has been generated and belongs to the proton or neutron model space.
// If arrays dimensions are calculated only, the dimension of fixed C[out] configuration and binary parity (see observables_basic_functions.cpp for definition) BP_in is increased. 
// If configuration jumps arrays are constructed, the number of particles in the continuum, index of configuration C[in], and indices of a,b shells are also stored in the array containing configuration jumps.
// The index of C[in] is calculated with a binary search (see GSM_configuration.cpp).
//
// Storage is done according to model space truncation.
// Indeed, as one can be using an intermediate Slater determinant |SDinter>, C[in] and/or C[out] might not belong to the model space.
// But, of course, one of them has to belong to the model space, as one cannot have two intermediate Slater determinants.
// This situation cannot occur if one builds jumps for a one-body or proton-neutron two-body operator, i.e. a many-body operator whose non-zero TBMEs are proton-neutron TBMEs.
// Indeed, jumps occurring in this case cannot involve intermediate Slater determinants, and C[in] has to belong to the model space.


void configuration_one_jump_construction_set_out_to_in::configuration_one_jump_data_fill (
											  const bool is_it_one_body_two_body_pn , 
											  const enum operation_type operation , 
											  const bool is_configuration_out_in_space , 
											  const unsigned int BP_in , 
											  const int n_holes_in , 
											  const int n_scat_in , 
											  const unsigned int C_in_jump_shell , 
											  const unsigned int C_out_jump_shell , 
											  const unsigned int C_eq_one_jump_index , 
											  const unsigned int configuration_one_jump_table_zero_index , 
											  const unsigned int dimensions_configuration_one_jump_table_index ,
											  const class configuration &C_in , 	
											  class configuration &C_try , 	
											  class nucleons_data &particles_data)
{
  const class array<unsigned int> &dimensions_configuration_set = particles_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = particles_data.get_configuration_set ();
  
  const unsigned int dimension_iC_in_set = dimensions_configuration_set(BP_in , n_scat_in);

  const unsigned int configuration_set_zero_iC_in = configuration_set.index_determine (BP_in , n_scat_in , 0);

  const unsigned int iC_in = C_in.index_search (dimension_iC_in_set , configuration_set_zero_iC_in , configuration_set , C_try);
  
  const class array_BP_Nscat_iC<bool> &is_configuration_in_in_space_tab = particles_data.get_is_configuration_in_in_space_tab (0);

  const bool is_configuration_in_in_space = is_configuration_in_in_space_tab(BP_in , n_scat_in , iC_in);
  
  const bool is_there_storage = (is_it_one_body_two_body_pn) ? (is_configuration_in_in_space) : (is_configuration_out_in_space || is_configuration_in_in_space);

  if (is_there_storage)
    {
      class array_BP_Nscat_iC<unsigned int> &dimensions_configuration_one_jump_table = particles_data.get_dimensions_configuration_one_jump_table_out_to_in ();

      switch (operation)
	{
	case DIMENSIONS_TABLES_CALC:
	  dimensions_configuration_one_jump_table[dimensions_configuration_one_jump_table_index]++;
	  break;

	case TABLES_FILL:
	  { 
	    const unsigned int configuration_one_jump_index = dimensions_configuration_one_jump_table[dimensions_configuration_one_jump_table_index]++;
	    const unsigned int configuration_one_jump_table_index = configuration_one_jump_table_zero_index + configuration_one_jump_index;

	    class array_of_configuration_one_jump_data_out_to_in &configuration_one_jump_table = particles_data.get_configuration_one_jump_table_out_to_in ();

	    configuration_one_jump_table[configuration_one_jump_table_index].initialize (n_holes_in , n_scat_in , iC_in , C_eq_one_jump_index , C_in_jump_shell , C_out_jump_shell);
	  } break; 

	default: abort_all ();
	}
    }
}







// Generation of all 1p-1h configurations C[in] out of a configuration C[out] with fixed parity Pi[in]
// ---------------------------------------------------------------------------------------------------
// One generates all the C[in] configurations with 1p-1h excitations on C[out] fixed.
// Redundancy of <outSD | a+(a) a(b) | inSD> values is avoided by using equivalent configurations (see above).

void configuration_one_jump_construction_set_out_to_in::configuration_one_jump_all_C_in (
											 const bool is_it_only_basis , 
											 const bool is_it_one_body_two_body_pn , 
											 const enum operation_type operation , 
											 const bool truncation_hw , 
											 const bool truncation_ph , 
											 const bool is_it_pole_approximation , 
											 const int n_holes_out , 
											 const int n_scat_out , 
											 const int E_hw_out , 
											 const class configuration &C_out , 
											 const unsigned int configuration_one_jump_table_zero_index , 
											 const unsigned int dimensions_configuration_one_jump_table_index , 
											 const bool is_configuration_out_in_space , 
											 const unsigned int BP_in , 
											 const unsigned int BP_jump , 
											 class configuration &C_in , 	
											 class configuration &C_try , 	
											 unsigned int &C_eq_one_jump_index , 
											 bool &first_configuration_one_jump_for_C_out ,
											 class nucleons_data &particles_data)
{       
  const int n_holes_max = (is_it_pole_approximation) ? (particles_data.get_n_holes_max_pole_approximation ()) : (particles_data.get_n_holes_max ());
  
  const int n_scat_max = (is_it_pole_approximation) ? (0) : (particles_data.get_n_scat_max ());

  const int E_max_hw = (is_it_pole_approximation) ? (particles_data.get_E_max_hw_pole_approximation ()) : (particles_data.get_E_max_hw ());

  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  for (int i_out = 0 ; i_out < N_valence_nucleons ; i_out++)
    {
      if ((i_out == 0) || (C_out[i_out] != C_out[i_out - 1]))
	{
	  const unsigned int C_out_jump_shell = C_out[i_out];

	  const class nlj_struct &shell_out = shells_qn(C_out_jump_shell);
	  	  
	  const bool S_matrix_pole_out = shell_out.get_S_matrix_pole ();

	  const bool is_n_scat_out_max = (n_scat_out == n_scat_max);
	  
	  const int l_out = shell_out.get_l ();
	  
	  const int e_shell_out = shell_out.get_e_trunc ();

	  const int E_hw_out_minus_e_shell_out = E_hw_out - e_shell_out;
	  
	  const bool frozen_state_out = shell_out.get_frozen_state ();
	      
	  const bool core_state_out = shell_out.get_core_state ();
			  
	  const bool core_active_state_out = (core_state_out && !frozen_state_out);
	  
	  const int scat_shell_out = (S_matrix_pole_out) ? (0) : (1);

	  const int n_scat_out_minus_scat_shell_out = n_scat_out - scat_shell_out;

	  bool crossing_occupied_shell_bef = true;

	  int l_in_bef = -1;
	  
	  int ij_in_bef = -1;

	  for (unsigned int C_in_jump_shell = 0 ; C_in_jump_shell < N_nlj ; C_in_jump_shell++)
	    {
	      if (is_it_only_basis && (C_in_jump_shell != C_out_jump_shell)) continue;

	      const class nlj_struct &shell_in = shells_qn(C_in_jump_shell);

	      const bool frozen_state_in = shell_in.get_frozen_state ();

	      if (frozen_state_in) continue;
	      
	      const bool S_matrix_pole_in = shell_in.get_S_matrix_pole ();

	      const bool scat_side_effect = (is_n_scat_out_max && (!S_matrix_pole_in));
      		  
	      if (!scat_side_effect || !S_matrix_pole_out)
		{
		  const int shell_in_content = shell_in.m_number_determine ();

		  const int shell_in_occupancy = C_out.occupancy_determine (C_in_jump_shell);
			  
		  if (shell_in_occupancy < shell_in_content)
		    {
		      const int l_in = shell_in.get_l ();

		      const int ij_in = shell_in.get_ij ();

		      const bool crossing_occupied_shell = (shell_in_occupancy > 0);
		      
		      const unsigned int bp_change = (l_in + l_out) % 2;
		      
		      if (bp_change == BP_jump)
			{
			  const int e_shell_in = shell_in.get_e_trunc ();

			  const int E_hw_in = E_hw_out_minus_e_shell_out + e_shell_in;
			  
			  const bool core_state_in = shell_in.get_core_state ();
	      
			  const bool core_active_state_in = (core_state_in && !frozen_state_in);

			  const bool n_holes_in_same = ((core_active_state_in && core_active_state_out) || (!core_active_state_in && !core_active_state_out));

			  const int n_holes_in_if_it_changes = (!core_active_state_in && core_active_state_out) ? (n_holes_out + 1) : (n_holes_out - 1);
			  
			  const int n_holes_in = (n_holes_in_same) ? (n_holes_out) : (n_holes_in_if_it_changes);
			  
			  const int scat_shell_in = (S_matrix_pole_in) ? (0) : (1);

			  const int n_scat_in = n_scat_out_minus_scat_shell_out + scat_shell_in;

			  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_in , n_scat_in , E_hw_in , n_holes_max , n_scat_max , E_max_hw)) continue;
			  
			  C_out.excitation_1p_1h (C_in_jump_shell , C_out_jump_shell , C_in);	     
	      
			  if (C_in.all_frozen_states_occupied (shells_qn))
			    {
			      if (!first_configuration_one_jump_for_C_out)
				{
				  const bool crossing_occupied_shells = (crossing_occupied_shell_bef || crossing_occupied_shell);

				  if (crossing_occupied_shells)
				    C_eq_one_jump_index++;
				  else
				    {
				      const bool changing_partial_wave = ((l_in != l_in_bef) || (ij_in != ij_in_bef));

				      if (changing_partial_wave) C_eq_one_jump_index++;
				    }				  
				}
			      
			      configuration_one_jump_data_fill (is_it_one_body_two_body_pn , operation , is_configuration_out_in_space ,
								BP_in , n_holes_in , n_scat_in , C_in_jump_shell , C_out_jump_shell ,
								C_eq_one_jump_index , configuration_one_jump_table_zero_index , dimensions_configuration_one_jump_table_index ,
								C_in , C_try , particles_data);

			      first_configuration_one_jump_for_C_out = false;
			    }
			}		
		      
		      l_in_bef = l_in;
		      ij_in_bef = ij_in;
		      crossing_occupied_shell_bef = crossing_occupied_shell;
		    }
		  else
		    crossing_occupied_shell_bef = true;
		}}}}
}





// Calculation of all the C[in] 1p-1h configurations jumps for all C[out] configurations
// -------------------------------------------------------------------------------------
// One loops over all C[out] configurations and one calls the previous routine.
//
// One checks if one has to do a calculation or not according to the used operator and model space truncations.
// _If one has a one-body operator or a proton-neutron two body operator, hence one-body like as there is no intermediate Slater determinant (see above),
//  the calculation must be done only if C[out] belongs to the model space and the current Pi[in] can be attained with this operator (calculated elsewhere).
// _If one has a two-body operator with pp and nn two-body matrix elements, hence involving intermediate Slater determinants (see above),
//  the calculation must be done only if C[out] belongs to the model space or if the current Pi[in] can be attained with this operator (calculated elsewhere).
//  Indeed, if C[out] does not belong to the model space and hence |outSD> is |SDinter> here, |inSD> has to belong to the model space and hence the current Pi[in] must be attained with this operator (calculated elsewhere).
//
// OpenMP is used on the index of the C[out] configuration for fixed parity and number of particles in the continuum, which is usually more than the number of threads.
// It is inside other loops, but whose number of elements is very small, as the maximal number of particles in the continuum is 2 to 4 typically.

void configuration_one_jump_construction_set_out_to_in::all_configurations_one_jump_all_configurations (
													const bool is_it_only_basis , 
													const bool is_it_one_body_two_body_pn , 
													const enum operation_type operation , 
													const bool truncation_hw , 
													const bool truncation_ph , 
													const bool is_it_pole_approximation , 
													class nucleons_data &particles_data)
{
  const int n_scat_max = (is_it_pole_approximation) ? (0) : (particles_data.get_n_scat_max ());

  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();
  
  const class array<unsigned int> &dimensions_configuration_set = particles_data.get_dimensions_configuration_set ();
  
  const class array_BP_Nscat_iC<int> &n_holes_table = particles_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &E_hw_table = particles_data.get_E_hw_table ();

  const class array_of_configuration &configuration_set = particles_data.get_configuration_set ();

  const class array_BP_Nscat_iC<bool> &is_configuration_out_in_space_tab = particles_data.get_is_configuration_out_in_space_tab (); 

  const class array<bool> &BPin_for_one_jump_tab = particles_data.get_BPin_for_one_jump_tab ();

  const class array_of_configuration_one_jump_data_out_to_in &configuration_one_jump_table = particles_data.get_configuration_one_jump_table_out_to_in ();

  class array_BP_Nscat_iC<unsigned int> &dimensions_configuration_one_jump_table = particles_data.get_dimensions_configuration_one_jump_table_out_to_in ();
  dimensions_configuration_one_jump_table = 0;
  
  class array<class configuration> C_in_tab(NUMBER_OF_THREADS);
  class array<class configuration> C_out_tab(NUMBER_OF_THREADS);
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      C_in_tab(i).allocate (N_valence_nucleons);
      C_out_tab(i).allocate (N_valence_nucleons);
      C_try_tab(i).allocate (N_valence_nucleons);
    }
  
  for (unsigned int BP_out = 0 ; BP_out <= 1 ; BP_out++)
    for (int n_scat_out = 0 ; n_scat_out <= n_scat_max ; n_scat_out++)
      {
	const unsigned int dimensions_configuration_out = dimensions_configuration_set(BP_out , n_scat_out);

	const unsigned int is_configuration_out_in_space_out_zero_index = is_configuration_out_in_space_tab.index_determine (BP_out , n_scat_out , 0);
	
	const unsigned int n_holes_out_zero_index = n_holes_table.index_determine (BP_out , n_scat_out , 0);
	
	const unsigned int E_hw_out_zero_index = E_hw_table.index_determine (BP_out , n_scat_out , 0);

	const unsigned int configuration_set_out_zero_index = configuration_set.index_determine (BP_out , n_scat_out , 0);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
	for (unsigned int iC_out = 0 ; iC_out < dimensions_configuration_out ; iC_out++)
	  {
	    const unsigned int i_thread = OpenMP_thread_number_determine ();

	    class configuration &C_in = C_in_tab(i_thread);
	    class configuration &C_out = C_out_tab(i_thread);
	    class configuration &C_try = C_try_tab(i_thread);
  
	    const unsigned int is_configuration_out_in_space_out_index = is_configuration_out_in_space_out_zero_index + iC_out;

	    const unsigned int n_holes_out_index = n_holes_out_zero_index + iC_out;
	    
	    const unsigned int E_hw_out_index = E_hw_out_zero_index + iC_out;

	    const unsigned int configuration_set_out_index = configuration_set_out_zero_index + iC_out;

	    const bool is_configuration_out_in_space = is_configuration_out_in_space_tab[is_configuration_out_in_space_out_index];
	    
	    const int n_holes_out = n_holes_table[n_holes_out_index];
	    
	    const int E_hw_out = E_hw_table[E_hw_out_index];

	    const unsigned int dimensions_configuration_one_jump_table_zero_index = dimensions_configuration_one_jump_table.index_determine (BP_out , n_scat_out , iC_out , 0);
	    
	    unsigned int C_eq_one_jump_index = 0;

	    bool first_configuration_one_jump_for_C_out = true;

	    C_out = configuration_set[configuration_set_out_index];
	    
	    for (unsigned int BP_in = 0 ; BP_in <= 1 ; BP_in++)
	      {
		const int BP_jump = binary_parity_product (BP_out , BP_in);

		const bool BPin_for_one_jump = BPin_for_one_jump_tab(BP_in);

		const bool is_there_calc_one_body = (is_it_one_body_two_body_pn  && (is_configuration_out_in_space && BPin_for_one_jump));
		const bool is_there_calc_two_body = (!is_it_one_body_two_body_pn && (is_configuration_out_in_space || BPin_for_one_jump));

		const bool is_there_calc = (is_there_calc_one_body || is_there_calc_two_body);
		
		if (is_there_calc)
		  {
		    const unsigned int configuration_one_jump_table_zero_index = (operation == TABLES_FILL)
		      ? (configuration_one_jump_table.index_determine (BP_out , n_scat_out , iC_out , BP_in , 0))
		      : (NADA);
		    
		    const unsigned int dimensions_configuration_one_jump_table_index = dimensions_configuration_one_jump_table_zero_index + BP_in;

		    configuration_one_jump_all_C_in (is_it_only_basis , is_it_one_body_two_body_pn , operation , truncation_hw , truncation_ph , is_it_pole_approximation ,
						     n_holes_out , n_scat_out , E_hw_out , C_out , 
						     configuration_one_jump_table_zero_index , dimensions_configuration_one_jump_table_index , is_configuration_out_in_space ,
						     BP_in , BP_jump , C_in , C_try , C_eq_one_jump_index , first_configuration_one_jump_for_C_out , particles_data);
		  }
	      }
	  }
      }
}







// Allocation and calculation of all the C[in] 1p-1h configurations jumps for all C[out] configurations
// ----------------------------------------------------------------------------------------------------
// One allocates arrays and one calls the previous routine.
// Dimensions of arrays of configuration jumps are calculated first, they are allocated, and then calculated.
// Time taken to do calculations can be also written, as they can be lengthy.

void configuration_one_jump_construction_set_out_to_in::all_configurations_one_jump_all_configurations_alloc_calc (
														   const bool is_there_cout , 
														   const bool is_it_only_basis , 
														   const bool is_it_one_body_two_body_pn ,
														   const bool truncation_hw , 
														   const bool truncation_ph , 
														   const bool is_it_pole_approximation , 
														   class nucleons_data &particles_data)
{	
  const double time_1 = absolute_time_determine ();

  class array_BP_Nscat_iC<unsigned int> &dimensions_configuration_one_jump_table = particles_data.get_dimensions_configuration_one_jump_table_out_to_in ();

  class array_of_configuration_one_jump_data_out_to_in &configuration_one_jump_table = particles_data.get_configuration_one_jump_table_out_to_in ();

  const enum particle_type particle = particles_data.get_particle ();

  const unsigned int dimension_configuration_total = particles_data.get_dimension_configuration_total ();

  const int n_scat_max = (is_it_pole_approximation) ? (0) : (particles_data.get_n_scat_max ());

  const class array<unsigned int> &dimensions_configuration_set = particles_data.get_dimensions_configuration_set ();

  const class array<unsigned int> &sum_dimensions_configuration_set = particles_data.get_sum_dimensions_configuration_set ();

  dimensions_configuration_one_jump_table.deallocate ();

  configuration_one_jump_table.deallocate ();
  
  dimensions_configuration_one_jump_table.allocate (dimension_configuration_total , sum_dimensions_configuration_set , 2);

  all_configurations_one_jump_all_configurations (is_it_only_basis , is_it_one_body_two_body_pn , DIMENSIONS_TABLES_CALC ,
						  truncation_hw , truncation_ph , is_it_pole_approximation , particles_data);

  const double time_2 = absolute_time_determine () , relative_time_dimension = time_2 - time_1; 

  configuration_one_jump_table.allocate (n_scat_max , dimension_configuration_total , dimensions_configuration_set ,
					 sum_dimensions_configuration_set , dimensions_configuration_one_jump_table);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const double dimensions_configuration_one_jump_table_used_memory = used_memory_calc (dimensions_configuration_one_jump_table);
      
      const double configuration_one_jump_table_used_memory = used_memory_calc (configuration_one_jump_table);

      cout << endl << "configuration jumps " << particle << " on the fly" << endl;
      cout << "dimensions: " << dimensions_configuration_one_jump_table_used_memory << " Mb" << endl;
      cout << "array     : " << configuration_one_jump_table_used_memory << " Mb" << endl;
      cout << "time      : " << relative_time_dimension << " s" << endl << endl;
    }

  all_configurations_one_jump_all_configurations (is_it_only_basis , is_it_one_body_two_body_pn , TABLES_FILL , truncation_hw , truncation_ph , is_it_pole_approximation , particles_data);

  const double time_3 = absolute_time_determine () , relative_time = time_3 - time_2; 

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << "configuration jumps " << particle << " on the fly calculated. time:" << relative_time << " s" << endl << endl;
}



