#include "../GSM_include/GSM_include_def.h"

using namespace HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common;

// TYPE is double or complex
// -------------------------

// See GSM_MSDHF_potentials.cpp for definitions and general explanations related to the MSDHF potential
// ----------------------------------------------------------------------------------------------------


// Calculation of the direct and exchange parts of the MSDHF potential with one occupied state for the proton-proton, neutron-neutron and proton-neutron parts of the interaction
// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// The equivalent MSDHF potential U_MSDHF = U_MSDHF(direct) - U_MSDHF(exchange) writes, along with its source:
//
// U_MSDHF(dir)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ |\sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . F_Gaussian(r) . \int u_occ^2(r') F_Gaussian(r') dr'
// U_MSDHF(exc)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ |\sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ |\sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' . F(r)
//
// where weight is function of Clebsch-Gordan coefficients and of the SD components of the GSM ground state of the optimized configuration (see GSM_MSDHF_potentials_SGI_MSGI_part.cpp).
// coupling_constant(Pi,J) is the Pi-J-dependent coupling constant of the MSGI interaction, 
// F_Gaussian(r) is the Gaussian form factor entering the MSGI interaction (see Gaussian_table_GL_calc),
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
// Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
// The ratio |u(r)|^2/|u'(r)|^2) prevents F(r) to be non zero when r -> +oo.
// Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// The real part of the equivalent MSDHF potential is considered for the MSDHF potential when it is complex.

// These routines call previous routines if the considered state is general, or only bound or resonant (res),
// or if it a proton scattering state for which k +/- w/(4 Pi) for Coulomb complex scaling (see H_CM_OBMEs.cpp).
//
// If one uses holes, there is an additional double-counting potential term  <wf[out] | U[hole-double-counting] | wf[in]> term to remove (see GSM_hole_double_counting.cpp).
// The formula is: <wf[out] | U[hole-double-counting] | wf[in]> = \sum_{holes,J'} (2J' + 1)/(2j + 1) <wf[out] wf[hole] | V | wf[in] wf[hole]>_J,
// which is removed from the MSDHF potential. There is no 1p-1h term, as it is diagonal only, so that it cannot enter HF or MSDHF potentials.

void MSDHF_potentials::SGI_MSGI_part::MSGI_part::Up_pp_part_calc (
								  const bool is_it_res , 
								  const bool is_it_pm , 
								  const int pm , 
								  const class spherical_state &shell_prot , 
								  const class spherical_state &shell_prot_occ , 
								  const double mp_in , 
								  const double mp_out , 
								  const double mp_occ_in , 
								  const double mp_occ_out , 
								  const complex<double> &SDs_weight , 
								  const class CG_str &CGs , 
								  const class array<double> &Gaussian_table_GL , 
								  const class multipolar_expansion_str &multipolar_expansion , 
								  const class interaction_class &inter_data , 
								  class HF_nucleons_data &prot_HF_data)
{
  const double jp = shell_prot.get_j ();

  const double jp_occ = shell_prot_occ.get_j ();

  const double Ueq_regularizor = prot_HF_data.get_Ueq_regularizor ();

  const int Jmin = abs (make_int (jp - jp_occ));

  const int Jmax = make_int (jp + jp_occ);

  const int M = make_int (mp_in + mp_occ_in);

  const int abs_M = abs (M);

  if (is_it_pm)
    {
      class nlj_table<complex<double> > &Up_eq_MSGI_pm_tab_GL = (pm == 1) ? (prot_HF_data.get_Ueq_SGI_MSGI_plus_tab_GL ()) : (prot_HF_data.get_Ueq_SGI_MSGI_minus_tab_GL ());

      class nlj_table<complex<double> > &prot_source_MSGI_pm_tab_GL = (pm == 1) ? (prot_HF_data.get_source_SGI_MSGI_plus_tab_GL ()) : (prot_HF_data.get_source_SGI_MSGI_minus_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  if (abs_M <= J)
	    {
	      const double CG_in_direct = CGs(jp_occ , mp_occ_in , jp , mp_in , J , M);

	      const double CG_in_exchange = CG_in_direct*minus_one_pow (jp_occ + jp - J);

	      const double CG_out = CGs(jp_occ , mp_occ_out , jp , mp_out , J , M);

	      const complex<double> CG_out_SDs_weight = CG_out*SDs_weight;

	      const complex<double> CGs_in_out_SDs_weight_direct = CG_in_direct*CG_out_SDs_weight;

	      const complex<double> CGs_in_out_SDs_weight_exchange = CG_in_exchange*CG_out_SDs_weight;

	      Up_direct_pp_part_calc (J , shell_prot , shell_prot_occ , inter_data , CGs_in_out_SDs_weight_direct , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_pm_tab_GL);

	      Up_exchange_pp_part_calc (J , shell_prot , shell_prot_occ , Ueq_regularizor , inter_data , CGs_in_out_SDs_weight_exchange , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_pm_tab_GL , prot_source_MSGI_pm_tab_GL);
	    }
	}
    }
  else
    {
      class nlj_table<complex<double> > &Up_eq_MSGI_tab_GL = (is_it_res) ? (prot_HF_data.get_Ueq_SGI_MSGI_res_tab_GL ()) : (prot_HF_data.get_Ueq_SGI_MSGI_tab_GL ());

      class nlj_table<complex<double> > &prot_source_MSGI_tab_GL = (is_it_res) ? (prot_HF_data.get_source_SGI_MSGI_res_tab_GL ()) : (prot_HF_data.get_source_SGI_MSGI_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  if (abs_M <= J)
	    {
	      const double CG_in_direct = CGs(jp_occ , mp_occ_in , jp , mp_in , J , M);

	      const double CG_in_exchange = CG_in_direct*minus_one_pow (jp_occ + jp - J);

	      const double CG_out = CGs(jp_occ , mp_occ_out , jp , mp_out , J , M);

	      const complex<double> CG_out_SDs_weight = CG_out*SDs_weight;
	      
	      const complex<double> CGs_in_out_SDs_weight_direct = CG_in_direct*CG_out_SDs_weight;

	      const complex<double> CGs_in_out_SDs_weight_exchange = CG_in_exchange*CG_out_SDs_weight;

	      Up_direct_pp_part_calc (J , shell_prot , shell_prot_occ , inter_data , CGs_in_out_SDs_weight_direct , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_tab_GL);
	      
	      Up_exchange_pp_part_calc (J , shell_prot , shell_prot_occ , Ueq_regularizor , inter_data , CGs_in_out_SDs_weight_exchange , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_tab_GL , prot_source_MSGI_tab_GL);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::MSGI_part::Up_pn_part_calc (
								  const bool is_it_res , 
								  const bool is_it_pm , 
								  const int pm , 
								  const class spherical_state &shell_prot , 
								  const class spherical_state &shell_neut_occ , 
								  const double mp_in , 
								  const double mp_out , 
								  const double mn_occ_in , 
								  const double mn_occ_out , 
								  const complex<double> &SDs_weight , 
								  const class CG_str &CGs , 
								  const class array<double> &Gaussian_table_GL , 
								  const class multipolar_expansion_str &multipolar_expansion , 
								  const class interaction_class &inter_data , 
								  class HF_nucleons_data &prot_HF_data)
{
  const double jp = shell_prot.get_j ();
  
  const double jn_occ = shell_neut_occ.get_j ();
  
  const double Ueq_regularizor = prot_HF_data.get_Ueq_regularizor ();
  
  const int Jmin = abs (make_int (jp - jn_occ));
  
  const int Jmax = make_int (jp + jn_occ);
  
  const int M = make_int (mp_in + mn_occ_in);
  
  const int abs_M = abs (M);

  if (is_it_pm)
    {
      class nlj_table<complex<double> > &Up_eq_MSGI_pm_tab_GL = (pm == 1) ? (prot_HF_data.get_Ueq_SGI_MSGI_plus_tab_GL ()) : (prot_HF_data.get_Ueq_SGI_MSGI_minus_tab_GL ());

      class nlj_table<complex<double> > &prot_source_MSGI_pm_tab_GL = (pm == 1) ? (prot_HF_data.get_source_SGI_MSGI_plus_tab_GL ()) : (prot_HF_data.get_source_SGI_MSGI_minus_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  if (abs_M <= J)
	    {
	      const double CG_in_direct = CGs(jn_occ , mn_occ_in , jp , mp_in , J , M);

	      const double CG_in_exchange = CG_in_direct*minus_one_pow (jn_occ + jp - J);

	      const double CG_out = CGs(jn_occ , mn_occ_out , jp , mp_out , J , M);

	      const complex<double> CG_out_SDs_weight = CG_out*SDs_weight;

	      const complex<double> CGs_in_out_SDs_weight_direct = CG_in_direct*CG_out_SDs_weight;

	      const complex<double> CGs_in_out_SDs_weight_exchange = CG_in_exchange*CG_out_SDs_weight;

	      Up_direct_pn_part_calc (J , shell_prot , shell_neut_occ , inter_data , CGs_in_out_SDs_weight_direct , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_pm_tab_GL);
	      
	      Up_exchange_pn_part_calc (J , shell_prot , shell_neut_occ , Ueq_regularizor , inter_data , CGs_in_out_SDs_weight_exchange , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_pm_tab_GL , prot_source_MSGI_pm_tab_GL);
	    }
	}
    }
  else
    {
      class nlj_table<complex<double> > &Up_eq_MSGI_tab_GL = (is_it_res) ? (prot_HF_data.get_Ueq_SGI_MSGI_res_tab_GL ()) : (prot_HF_data.get_Ueq_SGI_MSGI_tab_GL ());
      
      class nlj_table<complex<double> > &prot_source_MSGI_tab_GL = (is_it_res) ? (prot_HF_data.get_source_SGI_MSGI_res_tab_GL ()) : (prot_HF_data.get_source_SGI_MSGI_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  if (abs_M <= J)
	    {
	      const double CG_in_direct = CGs(jn_occ , mn_occ_in , jp , mp_in , J , M);

	      const double CG_in_exchange = CG_in_direct*minus_one_pow (jn_occ + jp - J);

	      const double CG_out = CGs(jn_occ , mn_occ_out , jp , mp_out , J , M);

	      const complex<double> CG_out_SDs_weight = CG_out*SDs_weight;

	      const complex<double> CGs_in_out_SDs_weight_direct = CG_in_direct*CG_out_SDs_weight;

	      const complex<double> CGs_in_out_SDs_weight_exchange = CG_in_exchange*CG_out_SDs_weight;

	      Up_direct_pn_part_calc (J , shell_prot , shell_neut_occ , inter_data , CGs_in_out_SDs_weight_direct , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_tab_GL);
	      
	      Up_exchange_pn_part_calc (J , shell_prot , shell_neut_occ , Ueq_regularizor , inter_data , CGs_in_out_SDs_weight_exchange , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_tab_GL , prot_source_MSGI_tab_GL);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::MSGI_part::Un_nn_part_calc (
								  const bool is_it_res , 
								  const bool is_it_pm , 
								  const int pm , 
								  const class spherical_state &shell_neut , 
								  const class spherical_state &shell_neut_occ , 
								  const double mn_in , 
								  const double mn_out , 
								  const double mn_occ_in , 
								  const double mn_occ_out , 
								  const complex<double> &SDs_weight , 
								  const class CG_str &CGs , 
								  const class array<double> &Gaussian_table_GL , 
								  const class multipolar_expansion_str &multipolar_expansion , 
								  const class interaction_class &inter_data , 
								  class HF_nucleons_data &neut_HF_data)
{
  const double jn = shell_neut.get_j ();

  const double jn_occ = shell_neut_occ.get_j ();

  const double Ueq_regularizor = neut_HF_data.get_Ueq_regularizor ();

  const int Jmin = abs (make_int (jn - jn_occ));

  const int Jmax = make_int (jn + jn_occ);

  const int M = make_int (mn_in + mn_occ_in);

  const int abs_M = abs (M);

  if (is_it_pm)
    {
      class nlj_table<complex<double> > &Un_eq_MSGI_pm_tab_GL = (pm == 1) ? (neut_HF_data.get_Ueq_SGI_MSGI_plus_tab_GL ()) : (neut_HF_data.get_Ueq_SGI_MSGI_minus_tab_GL ());

      class nlj_table<complex<double> > &neut_source_MSGI_pm_tab_GL = (pm == 1) ? (neut_HF_data.get_source_SGI_MSGI_plus_tab_GL ()) : (neut_HF_data.get_source_SGI_MSGI_minus_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  if (abs_M <= J)
	    {
	      const double CG_in_direct = CGs(jn_occ , mn_occ_in , jn , mn_in , J , M);

	      const double CG_in_exchange = CG_in_direct*minus_one_pow (jn_occ + jn - J);

	      const double CG_out = CGs(jn_occ , mn_occ_out , jn , mn_out , J , M);

	      const complex<double> CG_out_SDs_weight = CG_out*SDs_weight;

	      const complex<double> CGs_in_out_SDs_weight_direct = CG_in_direct*CG_out_SDs_weight;

	      const complex<double> CGs_in_out_SDs_weight_exchange = CG_in_exchange*CG_out_SDs_weight;

	      Un_direct_nn_part_calc (J , shell_neut , shell_neut_occ , inter_data , CGs_in_out_SDs_weight_direct , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_pm_tab_GL);

	      Un_exchange_nn_part_calc (J , shell_neut , shell_neut_occ , Ueq_regularizor , inter_data , CGs_in_out_SDs_weight_exchange , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_pm_tab_GL , neut_source_MSGI_pm_tab_GL);
	    }
	}
    }
  else
    {
      class nlj_table<complex<double> > &Un_eq_MSGI_tab_GL = (is_it_res) ? (neut_HF_data.get_Ueq_SGI_MSGI_res_tab_GL ()) : (neut_HF_data.get_Ueq_SGI_MSGI_tab_GL ());
      
      class nlj_table<complex<double> > &neut_source_MSGI_tab_GL = (is_it_res) ? (neut_HF_data.get_source_SGI_MSGI_res_tab_GL ()) : (neut_HF_data.get_source_SGI_MSGI_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  if (abs_M <= J)
	    {
	      const double CG_in_direct = CGs(jn_occ , mn_occ_in , jn , mn_in , J , M);

	      const double CG_in_exchange = CG_in_direct*minus_one_pow (jn_occ + jn - J);

	      const double CG_out = CGs(jn_occ , mn_occ_out , jn , mn_out , J , M);

	      const complex<double> CG_out_SDs_weight = CG_out*SDs_weight;

	      const complex<double> CGs_in_out_SDs_weight_direct = CG_in_direct*CG_out_SDs_weight;

	      const complex<double> CGs_in_out_SDs_weight_exchange = CG_in_exchange*CG_out_SDs_weight;

	      Un_direct_nn_part_calc (J , shell_neut , shell_neut_occ , inter_data , CGs_in_out_SDs_weight_direct , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_tab_GL);

	      Un_exchange_nn_part_calc (J , shell_neut , shell_neut_occ , Ueq_regularizor , inter_data , CGs_in_out_SDs_weight_exchange , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_tab_GL , neut_source_MSGI_tab_GL);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::MSGI_part::Un_pn_part_calc (
								  const bool is_it_res , 
								  const bool is_it_pm , 
								  const int pm , 
								  const class spherical_state &shell_neut , 
								  const class spherical_state &shell_prot_occ , 
								  const double mn_in , 
								  const double mn_out , 
								  const double mp_occ_in , 
								  const double mp_occ_out , 
								  const complex<double> &SDs_weight , 
								  const class CG_str &CGs , 
								  const class array<double> &Gaussian_table_GL , 
								  const class multipolar_expansion_str &multipolar_expansion , 
								  const class interaction_class &inter_data , 
								  class HF_nucleons_data &neut_HF_data)
{
  const double jn = shell_neut.get_j ();

  const double jp_occ = shell_prot_occ.get_j ();

  const double Ueq_regularizor = neut_HF_data.get_Ueq_regularizor ();

  const int Jmin = abs (make_int (jn - jp_occ));

  const int Jmax = make_int (jn + jp_occ);

  const int M = make_int (mn_in + mp_occ_in);

  const int abs_M = abs (M);

  if (is_it_pm)
    {
      class nlj_table<complex<double> > &Un_eq_MSGI_pm_tab_GL = (pm == 1) ? (neut_HF_data.get_Ueq_SGI_MSGI_plus_tab_GL ()) : (neut_HF_data.get_Ueq_SGI_MSGI_minus_tab_GL ());
      
      class nlj_table<complex<double> > &neut_source_MSGI_pm_tab_GL = (pm == 1) ? (neut_HF_data.get_source_SGI_MSGI_plus_tab_GL ()) : (neut_HF_data.get_source_SGI_MSGI_minus_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  if (abs_M <= J)
	    {
	      const double CG_in_direct = CGs(jp_occ , mp_occ_in , jn , mn_in , J , M);

	      const double CG_in_exchange = CG_in_direct*minus_one_pow (jp_occ + jn - J);

	      const double CG_out = CGs(jp_occ , mp_occ_out , jn , mn_out , J , M);

	      const complex<double> CG_out_SDs_weight = CG_out*SDs_weight;

	      const complex<double> CGs_in_out_SDs_weight_direct = CG_in_direct*CG_out_SDs_weight;

	      const complex<double> CGs_in_out_SDs_weight_exchange = CG_in_exchange*CG_out_SDs_weight;

	      Un_direct_pn_part_calc (J , shell_neut , shell_prot_occ , inter_data , CGs_in_out_SDs_weight_direct , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_pm_tab_GL);

	      Un_exchange_pn_part_calc (J , shell_neut , shell_prot_occ , Ueq_regularizor , inter_data , CGs_in_out_SDs_weight_exchange , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_pm_tab_GL , neut_source_MSGI_pm_tab_GL);
	    }
	}
    }
  else
    {
      class nlj_table<complex<double> > &Un_eq_MSGI_tab_GL = (is_it_res) ? (neut_HF_data.get_Ueq_SGI_MSGI_res_tab_GL ()) : (neut_HF_data.get_Ueq_SGI_MSGI_tab_GL ());
      
      class nlj_table<complex<double> > &neut_source_MSGI_tab_GL = (is_it_res) ? (neut_HF_data.get_source_SGI_MSGI_res_tab_GL ()) : (neut_HF_data.get_source_SGI_MSGI_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  if (abs_M <= J)
	    {
	      const double CG_in_direct = CGs(jp_occ , mp_occ_in , jn , mn_in , J , M);

	      const double CG_in_exchange = CG_in_direct*minus_one_pow (jp_occ + jn - J);

	      const double CG_out = CGs(jp_occ , mp_occ_out , jn , mn_out , J , M);

	      const complex<double> CG_out_SDs_weight = CG_out*SDs_weight;

	      const complex<double> CGs_in_out_SDs_weight_direct = CG_in_direct*CG_out_SDs_weight;

	      const complex<double> CGs_in_out_SDs_weight_exchange = CG_in_exchange*CG_out_SDs_weight;

	      Un_direct_pn_part_calc (J , shell_neut , shell_prot_occ , inter_data , CGs_in_out_SDs_weight_direct , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_tab_GL);

	      Un_exchange_pn_part_calc (J , shell_neut , shell_prot_occ , Ueq_regularizor , inter_data , CGs_in_out_SDs_weight_exchange , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_tab_GL , neut_source_MSGI_tab_GL);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::MSGI_part::Up_hole_double_counting_pp_part_remove (
											 const bool is_it_res , 
											 const bool is_it_pm , 
											 const int pm , 
											 const class spherical_state &shell_prot , 
											 const class spherical_state &shell_prot_occ , 
											 const class array<double> &Gaussian_table_GL , 
											 const class multipolar_expansion_str &multipolar_expansion , 
											 const class interaction_class &inter_data , 
											 class HF_nucleons_data &prot_HF_data)
{
  const double jp = shell_prot.get_j ();

  const double jp_occ = shell_prot_occ.get_j ();

  const double Ueq_regularizor = prot_HF_data.get_Ueq_regularizor ();

  const int Jmin = abs (make_int (jp - jp_occ));

  const int Jmax = make_int (jp + jp_occ);

  if (is_it_pm)
    {	
      class nlj_table<complex<double> > &Up_eq_MSGI_tab_GL = (is_it_res) ? (prot_HF_data.get_Ueq_SGI_MSGI_res_tab_GL ()) : (prot_HF_data.get_Ueq_SGI_MSGI_tab_GL ());
      
      class nlj_table<complex<double> > &prot_source_MSGI_tab_GL = (is_it_res) ? (prot_HF_data.get_source_SGI_MSGI_res_tab_GL ()) : (prot_HF_data.get_source_SGI_MSGI_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = -(2.0*J + 1.0)/(2.0*jp + 1.0);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jp_occ + jp - J);

	  Up_direct_pp_part_calc (J , shell_prot , shell_prot_occ , inter_data , J_coefficient_direct , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_tab_GL);

	  Up_exchange_pp_part_calc (J , shell_prot , shell_prot_occ , Ueq_regularizor , inter_data , J_coefficient_exchange , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_tab_GL , prot_source_MSGI_tab_GL);
	}
    }
  else
    {
      class nlj_table<complex<double> > &Up_eq_MSGI_pm_tab_GL = (pm == 1) ? (prot_HF_data.get_Ueq_SGI_MSGI_plus_tab_GL ()) : (prot_HF_data.get_Ueq_SGI_MSGI_minus_tab_GL ());
      
      class nlj_table<complex<double> > &prot_source_MSGI_pm_tab_GL = (pm == 1) ? (prot_HF_data.get_source_SGI_MSGI_plus_tab_GL ()) : (prot_HF_data.get_source_SGI_MSGI_minus_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = -(2.0*J + 1.0)/(2.0*jp + 1.0);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jp_occ + jp - J);

	  Up_direct_pp_part_calc (J , shell_prot , shell_prot_occ , inter_data , J_coefficient_direct , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_pm_tab_GL);
	  
	  Up_exchange_pp_part_calc (J , shell_prot , shell_prot_occ , Ueq_regularizor , inter_data , J_coefficient_exchange , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_pm_tab_GL , prot_source_MSGI_pm_tab_GL);
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::MSGI_part::Up_hole_double_counting_pn_part_remove (
											 const bool is_it_res , 
											 const bool is_it_pm , 
											 const int pm , 
											 const class spherical_state &shell_prot , 
											 const class spherical_state &shell_neut_occ , 
											 const class array<double> &Gaussian_table_GL , 
											 const class multipolar_expansion_str &multipolar_expansion , 
											 const class interaction_class &inter_data , 
											 class HF_nucleons_data &prot_HF_data)
{
  const double jp = shell_prot.get_j ();

  const double jn_occ = shell_neut_occ.get_j ();

  const double Ueq_regularizor = prot_HF_data.get_Ueq_regularizor ();

  const int Jmin = abs (make_int (jp - jn_occ));
  
  const int Jmax = make_int (jp + jn_occ);

  if (is_it_pm)
    {	
      class nlj_table<complex<double> > &Up_eq_MSGI_pm_tab_GL = (pm == 1) ? (prot_HF_data.get_Ueq_SGI_MSGI_plus_tab_GL ()) : (prot_HF_data.get_Ueq_SGI_MSGI_minus_tab_GL ());

      class nlj_table<complex<double> > &prot_source_MSGI_pm_tab_GL = (pm == 1) ? (prot_HF_data.get_source_SGI_MSGI_plus_tab_GL ()) : (prot_HF_data.get_source_SGI_MSGI_minus_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = -(2.0*J + 1.0)/(2.0*jp + 1.0);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jn_occ + jp - J);

	  Up_direct_pn_part_calc (J , shell_prot , shell_neut_occ , inter_data , J_coefficient_direct , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_pm_tab_GL);

	  Up_exchange_pn_part_calc (J , shell_prot , shell_neut_occ , Ueq_regularizor , inter_data , J_coefficient_exchange , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_pm_tab_GL , prot_source_MSGI_pm_tab_GL);
	}
    }
  else
    {
      class nlj_table<complex<double> > &Up_eq_MSGI_tab_GL = (is_it_res) ? (prot_HF_data.get_Ueq_SGI_MSGI_res_tab_GL ()) : (prot_HF_data.get_Ueq_SGI_MSGI_tab_GL ());

      class nlj_table<complex<double> > &prot_source_MSGI_tab_GL = (is_it_res) ? (prot_HF_data.get_source_SGI_MSGI_res_tab_GL ()) : (prot_HF_data.get_source_SGI_MSGI_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = -(2.0*J + 1.0)/(2.0*jp + 1.0);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jn_occ + jp - J);

	  Up_direct_pn_part_calc (J , shell_prot , shell_neut_occ , inter_data , J_coefficient_direct , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_tab_GL);

	  Up_exchange_pn_part_calc (J , shell_prot , shell_neut_occ , Ueq_regularizor , inter_data , J_coefficient_exchange , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_tab_GL , prot_source_MSGI_tab_GL);
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::MSGI_part::Un_hole_double_counting_nn_part_remove (
											 const bool is_it_res , 
											 const bool is_it_pm , 
											 const int pm , 
											 const class spherical_state &shell_neut , 
											 const class spherical_state &shell_neut_occ , 
											 const class array<double> &Gaussian_table_GL , 
											 const class multipolar_expansion_str &multipolar_expansion , 
											 const class interaction_class &inter_data , 
											 class HF_nucleons_data &neut_HF_data)
{
  const double jn = shell_neut.get_j ();

  const double jn_occ = shell_neut_occ.get_j ();

  const double Ueq_regularizor = neut_HF_data.get_Ueq_regularizor ();

  const int Jmin = abs (make_int (jn - jn_occ));
  
  const int Jmax = make_int (jn + jn_occ);

  if (is_it_pm)
    {	
      class nlj_table<complex<double> > &Un_eq_MSGI_pm_tab_GL = (pm == 1) ? (neut_HF_data.get_Ueq_SGI_MSGI_plus_tab_GL ()) : (neut_HF_data.get_Ueq_SGI_MSGI_minus_tab_GL ());

      class nlj_table<complex<double> > &neut_source_MSGI_pm_tab_GL = (pm == 1) ? (neut_HF_data.get_source_SGI_MSGI_plus_tab_GL ()) : (neut_HF_data.get_source_SGI_MSGI_minus_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = -(2.0*J + 1.0)/(2.0*jn + 1.0);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jn_occ + jn - J);

	  Un_direct_nn_part_calc (J , shell_neut , shell_neut_occ , inter_data , J_coefficient_direct , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_pm_tab_GL);

	  Un_exchange_nn_part_calc (J , shell_neut , shell_neut_occ , Ueq_regularizor , inter_data , J_coefficient_exchange , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_pm_tab_GL , neut_source_MSGI_pm_tab_GL);
	}
    }
  else
    {
      class nlj_table<complex<double> > &Un_eq_MSGI_tab_GL = (is_it_res) ? (neut_HF_data.get_Ueq_SGI_MSGI_res_tab_GL ()) : (neut_HF_data.get_Ueq_SGI_MSGI_tab_GL ());

      class nlj_table<complex<double> > &neut_source_MSGI_tab_GL = (is_it_res) ? (neut_HF_data.get_source_SGI_MSGI_res_tab_GL ()) : (neut_HF_data.get_source_SGI_MSGI_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = -(2.0*J + 1.0)/(2.0*jn + 1.0);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jn_occ + jn - J);

	  Un_direct_nn_part_calc (J , shell_neut , shell_neut_occ , inter_data , J_coefficient_direct , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_tab_GL);

	  Un_exchange_nn_part_calc (J , shell_neut , shell_neut_occ , Ueq_regularizor , inter_data , J_coefficient_exchange , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_tab_GL , neut_source_MSGI_tab_GL);
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::MSGI_part::Un_hole_double_counting_pn_part_remove (
											 const bool is_it_res , 
											 const bool is_it_pm , 
											 const int pm , 
											 const class spherical_state &shell_neut , 
											 const class spherical_state &shell_prot_occ , 
											 const class array<double> &Gaussian_table_GL , 
											 const class multipolar_expansion_str &multipolar_expansion , 
											 const class interaction_class &inter_data , 
											 class HF_nucleons_data &neut_HF_data)
{
  const double jn = shell_neut.get_j ();

  const double jp_occ = shell_prot_occ.get_j ();

  const double Ueq_regularizor = neut_HF_data.get_Ueq_regularizor ();

  const int Jmin = abs (make_int (jn - jp_occ));

  const int Jmax = make_int (jn + jp_occ);

  if (is_it_pm)
    {
      class nlj_table<complex<double> > &Un_eq_MSGI_pm_tab_GL = (pm == 1) ? (neut_HF_data.get_Ueq_SGI_MSGI_plus_tab_GL ()) : (neut_HF_data.get_Ueq_SGI_MSGI_minus_tab_GL ());

      class nlj_table<complex<double> > &neut_source_MSGI_pm_tab_GL = (pm == 1) ? (neut_HF_data.get_source_SGI_MSGI_plus_tab_GL ()) : (neut_HF_data.get_source_SGI_MSGI_minus_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = -(2.0*J + 1.0)/(2.0*jn + 1.0);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jp_occ + jn - J);

	  Un_direct_pn_part_calc (J , shell_neut , shell_prot_occ , inter_data , J_coefficient_direct , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_pm_tab_GL);

	  Un_exchange_pn_part_calc (J , shell_neut , shell_prot_occ , Ueq_regularizor , inter_data , J_coefficient_exchange , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_pm_tab_GL , neut_source_MSGI_pm_tab_GL);
	}
    }
  else
    {
      class nlj_table<complex<double> > &Un_eq_MSGI_tab_GL = (is_it_res) ? (neut_HF_data.get_Ueq_SGI_MSGI_res_tab_GL ()) : (neut_HF_data.get_Ueq_SGI_MSGI_tab_GL ());

      class nlj_table<complex<double> > &neut_source_MSGI_tab_GL = (is_it_res) ? (neut_HF_data.get_source_SGI_MSGI_res_tab_GL ()) : (neut_HF_data.get_source_SGI_MSGI_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = -(2.0*J + 1.0)/(2.0*jn + 1.0);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jp_occ + jn - J);

	  Un_direct_pn_part_calc (J , shell_neut , shell_prot_occ , inter_data , J_coefficient_direct , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_tab_GL);

	  Un_exchange_pn_part_calc (J , shell_neut , shell_prot_occ , Ueq_regularizor , inter_data , J_coefficient_exchange , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_tab_GL , neut_source_MSGI_tab_GL);
	}
    }
}




