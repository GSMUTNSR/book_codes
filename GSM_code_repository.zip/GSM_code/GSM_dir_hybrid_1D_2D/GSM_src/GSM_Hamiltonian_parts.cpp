#include "../GSM_include/GSM_include_def.h"

using namespace string_routines;
using namespace correlated_state_routines;
using namespace GSM_vector_dimensions;
using namespace inputs_misc;
using namespace configuration_SD_in_space_one_jump_out_to_in;

// MPI transfer is done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------


// Routines calculating expectation values of the different parts of the Hamiltonian on an eigenvector |Psi>
// ---------------------------------------------------------------------------------------------------------
// The Hamiltonian is the sum of one-body kinetic part, two-body kinetic part (i.e. recoil), one-body and two-body nuclear and Coulomb parts and three-body like part (Minnesota only).
// They are all calculated one after the other and printed on screen.
//
// For this, OBMEs and TBMEs related to the considered Hamiltonian part are calculated and stored in OBMEs and TBMEs arrays and classes, then erasing previous OBMEs and TBMEs.
//
// The Hamiltonian part operator is applied to the eigenvector H[part]|Psi>,
// and the expectation value <Psi | H[part] | Psi> is then calculated and printed on screen.
//
// OBMEs and TBMEs of the initial Hamiltonian are erased at the end of the calculation.


void Hamiltonian_parts::kinetic_one_body_calc_print (
						     const class input_data_str &input_data , 
						     const class interaction_class &inter_data ,
						     class GSM_vector &PSI_full , 
						     const double J ,
						     const class GSM_vector &PSI ,
						     class GSM_vector &PSI_0 ,
						     class GSM_vector &PSI_1 ,
						     class array<class GSM_vector> &H_PSI_table)
{
  const class TBMEs_class dummy_TBMEs_pn;
  const class TBMEs_class dummy_TBMEs_cv;
  
  class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();

  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage (); 

  const enum storage_type jumps_pn_cv_storage = input_data.get_one_jumps_pn_two_jumps_cv_storage ();
  
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  const bool are_there_hyperons = input_data.get_are_there_hyperons ();

  class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  class TBMEs_class &TBMEs_p = prot_Y_data.get_TBMEs ();
  class TBMEs_class &TBMEs_n = neut_Y_data.get_TBMEs ();
  
  if (ZYval >= 2) TBMEs_p.zero ();
  if (NYval >= 2) TBMEs_n.zero ();
  
  switch (space)
    {
    case PROT_Y_ONLY:
      {
	class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> OBMEs_p_inter = OBMEs_p_inter_set(TBME_inter);

	const class array<TYPE> OBMEs_p_kinetic = OBMEs_p_inter_set(ONE_BODY_KINETIC);
	
	OBMEs_p_inter_set(TBME_inter) = OBMEs_p_kinetic;

	const class H_class Tp_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
					dummy_TBMEs_pn , dummy_TBMEs_cv , true , false , false , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Tp_one_body_PSI = Tp_one_body*PSI;

	const TYPE Tp_average_value = PSI*Tp_one_body_PSI;

	if (THIS_PROCESS == MASTER_PROCESS)
	  {
	    if (are_there_hyperons)
	      cout << "<PSI|T[one-body]|PSI> : " << Tp_average_value << " MeV" << endl << endl;
	    else
	      cout << "<PSI|Tp[one-body]|PSI> : " << Tp_average_value << " MeV" << endl << endl;
	  }

	OBMEs_p_inter_set(TBME_inter) = OBMEs_p_inter;
      } break;

    case NEUT_Y_ONLY: 
      {
	class OBMEs_inter_set_str &OBMEs_n_inter_set = neut_Y_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> OBMEs_n_inter = OBMEs_n_inter_set(TBME_inter);

	const class array<TYPE> OBMEs_n_kinetic = OBMEs_n_inter_set(ONE_BODY_KINETIC);
	
	OBMEs_n_inter_set(TBME_inter) = OBMEs_n_kinetic;

	const class H_class Tn_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
					dummy_TBMEs_pn , dummy_TBMEs_cv , false , true , false , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);

	const class GSM_vector Tn_one_body_PSI = Tn_one_body*PSI;

	const TYPE Tn_average_value = PSI*Tn_one_body_PSI;
	
	if (THIS_PROCESS == MASTER_PROCESS)
	  {
	    if (are_there_hyperons)
	      cout << "<PSI|T[one-body]|PSI> : " << Tn_average_value << " MeV" << endl << endl;
	    else
	      cout << "<PSI|Tn[one-body]|PSI> : " << Tn_average_value << " MeV" << endl << endl;
	  }

	OBMEs_n_inter_set(TBME_inter) = OBMEs_n_inter;
      } break;

    case PROT_NEUT_Y:
      { 
	class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &OBMEs_n_inter_set = neut_Y_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> OBMEs_p_inter = OBMEs_p_inter_set(TBME_inter) , OBMEs_p_kinetic = OBMEs_p_inter_set(ONE_BODY_KINETIC);
	const class array<TYPE> OBMEs_n_inter = OBMEs_n_inter_set(TBME_inter) , OBMEs_n_kinetic = OBMEs_n_inter_set(ONE_BODY_KINETIC);
	    
	if (are_there_hyperons)
	  {	    
	    OBMEs_p_inter_set(TBME_inter) = OBMEs_p_kinetic;
	    OBMEs_n_inter_set(TBME_inter) = OBMEs_n_kinetic;
	    
	    const class H_class T_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
					   dummy_TBMEs_pn , dummy_TBMEs_cv , true , true , false , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	      	  
	    class GSM_vector T_one_body_PSI = T_one_body*PSI;

	    const TYPE T_average_value = PSI*T_one_body_PSI;
	
	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|T[one-body]|PSI> : " << T_average_value << " MeV" << endl << endl;
	  }
	else
	  {
	    OBMEs_p_inter_set(TBME_inter) = OBMEs_p_kinetic;
	    
	    OBMEs_n_inter_set(TBME_inter) = 0.0;

	    {
	      const class H_class Tp_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
					      dummy_TBMEs_pn , dummy_TBMEs_cv , true , false , false , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	  
	      const class GSM_vector Tp_one_body_PSI = Tp_one_body*PSI;
	
	      const TYPE Tp_average_value = PSI*Tp_one_body_PSI;

	      if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tp[one-body]|PSI> : " << Tp_average_value << " MeV" << endl;
	    }

	    OBMEs_p_inter_set(TBME_inter) = 0.0;
	    
	    OBMEs_n_inter_set(TBME_inter) = OBMEs_n_kinetic;

	    {
	      const class H_class Tn_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
					      dummy_TBMEs_pn , dummy_TBMEs_cv , false , true , false , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	  
	      const class GSM_vector Tn_one_body_PSI = Tn_one_body*PSI;

	      const TYPE Tn_average_value = PSI*Tn_one_body_PSI;
	  
	      if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tn[one-body]|PSI> : " << Tn_average_value << " MeV" << endl << endl;
	    }
	  }

	OBMEs_p_inter_set(TBME_inter) = OBMEs_p_inter;
	OBMEs_n_inter_set(TBME_inter) = OBMEs_n_inter;
      
      } break;

    default: abort_all ();
    }
}

void Hamiltonian_parts::kinetic_recoil_calc_print (
						   const class input_data_str &input_data , 
						   const class interaction_class &inter_data , 
						   class GSM_vector &PSI_full , 
						   const double J , 
						   const class GSM_vector &PSI ,
						   class GSM_vector &PSI_0 ,
						   class GSM_vector &PSI_1 ,
						   class array<class GSM_vector> &H_PSI_table ,
						   class TBMEs_class &TBMEs_pn)
{  
  const class TBMEs_class dummy_TBMEs_cv;
  
  class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage (); 

  const enum storage_type jumps_pn_cv_storage = input_data.get_one_jumps_pn_two_jumps_cv_storage ();
  
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const bool are_there_hyperons = input_data.get_are_there_hyperons ();
  
  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);
  
  const int sign_inter = (!is_it_COSM) ? (-1) : (1);

  class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  class TBMEs_class &TBMEs_p = prot_Y_data.get_TBMEs ();
  class TBMEs_class &TBMEs_n = neut_Y_data.get_TBMEs ();
  
  if (ZYval >= 2) TBMEs_p.zero ();
  if (NYval >= 2) TBMEs_n.zero ();

  switch (space)
    {
    case PROT_Y_ONLY:
      {	
	class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> OBMEs_p_inter = OBMEs_p_inter_set(TBME_inter);
	
	OBMEs_p_inter_set(TBME_inter) = 0.0;

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , CM_KINETIC_INTERACTION , input_data , false , inter_data , prot_Y_data);

	const class H_class Tpp_recoil_no_sign(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
					       TBMEs_pn , dummy_TBMEs_cv , false , false , true , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Tpp_recoil_no_sign_PSI = Tpp_recoil_no_sign*PSI;

	const TYPE Tpp_recoil_average = sign_inter*(PSI*Tpp_recoil_no_sign_PSI);
	  
	if (THIS_PROCESS == MASTER_PROCESS)
	  {
	    if (are_there_hyperons)
	      cout << "<PSI|T[recoil]|PSI> : " << Tpp_recoil_average << " MeV" << endl << endl;
	    else
	      cout << "<PSI|Tpp[recoil]|PSI> : " << Tpp_recoil_average << " MeV" << endl << endl;
	  }

	OBMEs_p_inter_set(TBME_inter) = OBMEs_p_inter;
      } break;

    case NEUT_Y_ONLY: 
      {
	class OBMEs_inter_set_str &OBMEs_n_inter_set = neut_Y_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> OBMEs_n_inter = OBMEs_n_inter_set(TBME_inter);
	
	OBMEs_n_inter_set(TBME_inter) = 0.0;

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , CM_KINETIC_INTERACTION , input_data , false , inter_data , neut_Y_data); 

	const class H_class Tnn_recoil_no_sign(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
					       TBMEs_pn , dummy_TBMEs_cv , false , false , false , true , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
		
	const class GSM_vector Tnn_recoil_no_sign_PSI = Tnn_recoil_no_sign*PSI;
	
	const TYPE Tnn_recoil_average = sign_inter*(PSI*Tnn_recoil_no_sign_PSI);
	
	if (THIS_PROCESS == MASTER_PROCESS)
	  {
	    if (are_there_hyperons)
	      cout << "<PSI|T[recoil]|PSI> : " << Tnn_recoil_average << " MeV" << endl << endl;
	    else
	      cout << "<PSI|Tnn[recoil]|PSI> : " << Tnn_recoil_average << " MeV" << endl << endl;
	  }

	OBMEs_n_inter_set(TBME_inter) = OBMEs_n_inter;
      } break;

    case PROT_NEUT_Y:
      {
	class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &OBMEs_n_inter_set = neut_Y_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> OBMEs_p_inter = OBMEs_p_inter_set(TBME_inter);
	const class array<TYPE> OBMEs_n_inter = OBMEs_n_inter_set(TBME_inter);

	OBMEs_p_inter_set(TBME_inter) = 0.0;
	OBMEs_n_inter_set(TBME_inter) = 0.0;
	    
	TBMEs_pn.zero ();

	if (are_there_hyperons)
	  {	    
	    coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , CM_KINETIC_INTERACTION  , input_data , false , inter_data , prot_Y_data);
	    coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , CM_KINETIC_INTERACTION  , input_data , false , inter_data , neut_Y_data);
	
	    coupled_TBMEs::Berggren::TBMEs_pn_calc (false , false , CM_KINETIC_INTERACTION , input_data , prot_Y_data , neut_Y_data , false , inter_data , TBMEs_pn);
	    	    
	    const class H_class T_recoil_no_sign(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
						 TBMEs_pn , dummy_TBMEs_cv , false , false , true , true , true , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
		
	    class GSM_vector T_recoil_no_sign_PSI = T_recoil_no_sign*PSI;
	    
	    const TYPE T_recoil_average = sign_inter*(PSI*T_recoil_no_sign_PSI);
		
	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|T[recoil]|PSI> : " << T_recoil_average << " MeV" << endl << endl;
	  }
	else
	  {
	    if (ZYval >= 2)
	      {
		coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , CM_KINETIC_INTERACTION , input_data , false , inter_data , prot_Y_data);

		const class H_class Tpp_recoil_no_sign(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
						       TBMEs_pn , dummy_TBMEs_cv , false , false , true , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
		const class GSM_vector Tpp_recoil_no_sign_PSI = Tpp_recoil_no_sign*PSI;

		const TYPE Tpp_recoil_average = sign_inter*(PSI*Tpp_recoil_no_sign_PSI);
	    
		if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tpp[recoil]|PSI> : " << Tpp_recoil_average << " MeV" << endl;
	    
		TBMEs_p.zero ();
	      }

	    if (NYval >= 2)
	      {
		coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , CM_KINETIC_INTERACTION , input_data , false , inter_data , neut_Y_data); 

		const class H_class Tnn_recoil_no_sign(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
						       TBMEs_pn , dummy_TBMEs_cv , false , false , false , true , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
		const class GSM_vector Tnn_recoil_no_sign_PSI = Tnn_recoil_no_sign*PSI;
	    
		const TYPE Tnn_recoil_average = sign_inter*(PSI*Tnn_recoil_no_sign_PSI);
	
		if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tnn[recoil]|PSI> : " << Tnn_recoil_average << " MeV" << endl;
	    
		TBMEs_n.zero ();
	      }

	    coupled_TBMEs::Berggren::TBMEs_pn_calc (false , false , CM_KINETIC_INTERACTION , input_data , prot_Y_data , neut_Y_data , false , inter_data , TBMEs_pn);

	    const class H_class Tpn_recoil_no_sign(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
						   TBMEs_pn , dummy_TBMEs_cv , false , false , false , false , true , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	    const class GSM_vector Tpn_recoil_no_sign_PSI = Tpn_recoil_no_sign*PSI;

	    const TYPE Tpn_recoil_average = sign_inter*(PSI*Tpn_recoil_no_sign_PSI);
	
	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tpn[recoil]|PSI> : " << Tpn_recoil_average << " MeV" << endl << endl;
	  }
	
	OBMEs_p_inter_set(TBME_inter) = OBMEs_p_inter;
	OBMEs_n_inter_set(TBME_inter) = OBMEs_n_inter;
	
      } break;
      
    default: abort_all ();
    }
}

void Hamiltonian_parts::nuclear_one_body_calc_print (
						     const class input_data_str &input_data , 
						     const class interaction_class &inter_data ,
						     class GSM_vector &PSI_full , 
						     const double J ,
						     const class GSM_vector &PSI ,
						     class GSM_vector &PSI_0 ,
						     class GSM_vector &PSI_1 ,
						     class array<class GSM_vector> &H_PSI_table)
{
  const class TBMEs_class dummy_TBMEs_cv;
  const class TBMEs_class dummy_TBMEs_pn;
  
  class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage (); 

  const enum storage_type jumps_pn_cv_storage = input_data.get_one_jumps_pn_two_jumps_cv_storage ();
  
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  const bool are_there_hyperons = input_data.get_are_there_hyperons ();

  class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  class TBMEs_class &TBMEs_p = prot_Y_data.get_TBMEs ();
  class TBMEs_class &TBMEs_n = neut_Y_data.get_TBMEs ();
  
  if (ZYval >= 2) TBMEs_p.zero ();
  if (NYval >= 2) TBMEs_n.zero ();
  
  switch (space)
    {
    case PROT_Y_ONLY:
      {
	class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> OBMEs_p_inter = OBMEs_p_inter_set(TBME_inter);

	const class array<TYPE> OBMEs_p_nuclear = OBMEs_p_inter_set(ONE_BODY_NUCLEAR);
	
	OBMEs_p_inter_set(TBME_inter) = OBMEs_p_nuclear;

	const class H_class Hp_nuclear_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
						dummy_TBMEs_pn , dummy_TBMEs_cv , true , false , false , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Hp_nuclear_one_body_PSI = Hp_nuclear_one_body*PSI;

	const TYPE Hp_nuclear_average_value = PSI*Hp_nuclear_one_body_PSI;

	if (THIS_PROCESS == MASTER_PROCESS)
	  {
	    if (are_there_hyperons)
	      cout << "<PSI|H.baryonic[one-body]|PSI> : " << Hp_nuclear_average_value << " MeV" << endl << endl;
	    else
	      cout << "<PSI|Hp.nuclear[one-body]|PSI> : " << Hp_nuclear_average_value << " MeV" << endl << endl;
	  }

	OBMEs_p_inter_set(TBME_inter) = OBMEs_p_inter;
      } break;

    case NEUT_Y_ONLY: 
      {
	class OBMEs_inter_set_str &OBMEs_n_inter_set = neut_Y_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> OBMEs_n_inter = OBMEs_n_inter_set(TBME_inter);

	const class array<TYPE> OBMEs_n_nuclear = OBMEs_n_inter_set(ONE_BODY_NUCLEAR);
	
	OBMEs_n_inter_set(TBME_inter) = OBMEs_n_nuclear;

	const class H_class Hn_nuclear_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
						dummy_TBMEs_pn , dummy_TBMEs_cv , false , true , false , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	class GSM_vector Hn_nuclear_one_body_PSI = Hn_nuclear_one_body*PSI;

	const TYPE Hn_nuclear_average_value = PSI*Hn_nuclear_one_body_PSI;

	if (THIS_PROCESS == MASTER_PROCESS)
	  {
	    if (are_there_hyperons)
	      cout << "<PSI|H.baryonic[one-body]|PSI> : " << Hn_nuclear_average_value << " MeV" << endl << endl;
	    else
	      cout << "<PSI|Hn.nuclear[one-body]|PSI> : " << Hn_nuclear_average_value << " MeV" << endl << endl;
	  }
	
	OBMEs_n_inter_set(TBME_inter) = OBMEs_n_inter;
      } break;

    case PROT_NEUT_Y:
      {
	class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &OBMEs_n_inter_set = neut_Y_data.get_OBMEs_inter_set ();

	const class array<TYPE> OBMEs_p_inter = OBMEs_p_inter_set(TBME_inter) , OBMEs_p_nuclear = OBMEs_p_inter_set(ONE_BODY_NUCLEAR);
	const class array<TYPE> OBMEs_n_inter = OBMEs_n_inter_set(TBME_inter) , OBMEs_n_nuclear = OBMEs_n_inter_set(ONE_BODY_NUCLEAR);
	
	if (are_there_hyperons)
	  {	    
	    OBMEs_p_inter_set(TBME_inter) = OBMEs_p_nuclear;
	    OBMEs_n_inter_set(TBME_inter) = OBMEs_n_nuclear;
	    
	    const class H_class H_baryonic_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
						    dummy_TBMEs_pn , dummy_TBMEs_cv , true , true , false , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	    
	    class GSM_vector H_baryonic_one_body_PSI = H_baryonic_one_body*PSI;
	    
	    const TYPE H_baryonic_one_body_value = PSI*H_baryonic_one_body_PSI;
	
	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|H.baryonic[one-body]|PSI> : " << H_baryonic_one_body_value << " MeV" << endl << endl;
	  }
	else
	  {
	    OBMEs_p_inter_set(TBME_inter) = OBMEs_p_nuclear;
	    
	    OBMEs_n_inter_set(TBME_inter) = 0.0;

	    {
	      const class H_class Hp_nuclear_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
						      dummy_TBMEs_pn , dummy_TBMEs_cv , true , false , false , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	      const class GSM_vector Hp_nuclear_one_body_PSI = Hp_nuclear_one_body*PSI;
	  
	      const TYPE Hp_nuclear_average_value = PSI*Hp_nuclear_one_body_PSI;
	  
	      if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hp.nuclear[one-body]|PSI> : " << Hp_nuclear_average_value << " MeV" << endl;
	    }

	    OBMEs_p_inter_set(TBME_inter) = 0.0;
	    
	    OBMEs_n_inter_set(TBME_inter) = OBMEs_n_nuclear;

	    {
	      const class H_class Hn_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
					      dummy_TBMEs_pn , dummy_TBMEs_cv , false , true , false , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	      const class GSM_vector Hn_nuclear_one_body_PSI = Hn_one_body*PSI;

	      const TYPE Hn_nuclear_average_value = PSI*Hn_nuclear_one_body_PSI;

	      if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hn.nuclear[one-body]|PSI> : " << Hn_nuclear_average_value << " MeV" << endl << endl;
	    }
	  }

	OBMEs_p_inter_set(TBME_inter) = OBMEs_p_inter;
	OBMEs_n_inter_set(TBME_inter) = OBMEs_n_inter;
	
      } break;
      
    default: abort_all ();
    }
}

void Hamiltonian_parts::nuclear_two_body_calc_print (
						     const class input_data_str &input_data , 
						     const int Jn_relative_max , 
						     class GSM_vector &PSI_full , 
						     const double J ,
						     const class GSM_vector &PSI ,
						     class interaction_class &inter_data , 
						     class GSM_vector &PSI_0 ,
						     class GSM_vector &PSI_1 ,
						     class array<class GSM_vector> &H_PSI_table ,
						     class TBMEs_class &TBMEs_pn ,
						     class TBMEs_class &TBMEs_cv)
{
  class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage (); 

  const enum storage_type jumps_pn_cv_storage = input_data.get_one_jumps_pn_two_jumps_cv_storage ();

  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const enum interaction_type nuclear_inter = nuclear_inter_determine (TBME_inter);

  const bool are_there_hyperons = input_data.get_are_there_hyperons ();
  
  const bool is_cv_possible = input_data.get_is_cv_possible ();
  
  class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  class TBMEs_class &TBMEs_p = prot_Y_data.get_TBMEs ();
  class TBMEs_class &TBMEs_n = neut_Y_data.get_TBMEs ();
  
  if (ZYval >= 2) TBMEs_p.zero ();
  if (NYval >= 2) TBMEs_n.zero ();
  
  const double TBME_A_dependent_factor = TBME_A_dependent_factor_calc (input_data);
   
  inter_data.zero ();

  if (nuclear_inter == SGI)
    inter_data.SGI_radial_tables_calc ();
  else if ((nuclear_inter == FIT) || is_it_FHT_determine (nuclear_inter) || is_it_EFT_determine (nuclear_inter) || (is_it_Minnesota_determine (nuclear_inter)) || (nuclear_inter == REALISTIC_INTERACTION))
    inter_data.TBMEs_HO_lab_no_added_kinetic_part (false , Jn_relative_max , 0 , TBME_A_dependent_factor);

  switch (space)
    {
    case PROT_Y_ONLY:
      {
	class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> OBMEs_p_inter = OBMEs_p_inter_set(TBME_inter);
	
	OBMEs_p_inter_set(TBME_inter) = 0.0;

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , nuclear_inter , input_data , false , inter_data , prot_Y_data);

	const class H_class Vpp(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
				TBMEs_pn , TBMEs_cv , false , false , true , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Vpp_PSI = Vpp*PSI;

	const TYPE Vpp_average = PSI*Vpp_PSI;
	
	if (THIS_PROCESS == MASTER_PROCESS)
	  {
	    if (are_there_hyperons)
	      cout << "<PSI|H.baryonic[two-body]|PSI> : " << Vpp_average << " MeV" << endl << endl;
	    else
	      cout << "<PSI|Hpp.nuclear[two-body]|PSI> : " << Vpp_average << " MeV" << endl << endl;
	  }

	OBMEs_p_inter_set(TBME_inter) = OBMEs_p_inter;
      } break;

    case NEUT_Y_ONLY: 
      {
	class OBMEs_inter_set_str &OBMEs_n_inter_set = neut_Y_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> OBMEs_n_inter = OBMEs_n_inter_set(TBME_inter);
	
	OBMEs_n_inter_set(TBME_inter) = 0.0;

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , nuclear_inter , input_data , false , inter_data , neut_Y_data);

	const class H_class Vnn(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
				TBMEs_pn , TBMEs_cv , false , false , false , true , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Vnn_PSI = Vnn*PSI;

	const TYPE Vnn_average = PSI*Vnn_PSI;
	
	if (THIS_PROCESS == MASTER_PROCESS)
	  {
	    if (are_there_hyperons)
	      cout << "<PSI|H.baryonic[two-body]|PSI> : " << Vnn_average << " MeV" << endl << endl;
	    else
	      cout << "<PSI|Hnn.nuclear[two-body]|PSI> : " << Vnn_average << " MeV" << endl << endl;
	  }
	
	OBMEs_n_inter_set(TBME_inter) = OBMEs_n_inter;       
      } break;

    case PROT_NEUT_Y:
      {
	class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &OBMEs_n_inter_set = neut_Y_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> OBMEs_p_inter = OBMEs_p_inter_set(TBME_inter);
	const class array<TYPE> OBMEs_n_inter = OBMEs_n_inter_set(TBME_inter);
	
	OBMEs_p_inter_set(TBME_inter) = 0.0;
	OBMEs_n_inter_set(TBME_inter) = 0.0;

	TBMEs_pn.zero ();

	if (are_there_hyperons)
	  {	    
	    if (is_cv_possible) TBMEs_cv.zero ();
	
	    coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , nuclear_inter , input_data , false , inter_data , prot_Y_data);
	    coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , nuclear_inter , input_data , false , inter_data , neut_Y_data);
	
	    coupled_TBMEs::Berggren::TBMEs_pn_calc (false , false , nuclear_inter , input_data , prot_Y_data , neut_Y_data , false , inter_data , TBMEs_pn);
	    coupled_TBMEs::Berggren::TBMEs_cv_calc (false         , nuclear_inter , input_data , prot_Y_data , neut_Y_data         , inter_data , TBMEs_cv);
	    
	    const class H_class V(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
				  TBMEs_pn , TBMEs_cv , false , false , true , true , true , is_cv_possible , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	    
	    class GSM_vector V_PSI = V*PSI;
	    
	    const TYPE V_average = PSI*V_PSI;
		
	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|H.baryonic[two-body]|PSI> : " << V_average << " MeV" << endl << endl;	    
	  }
	else
	  {	
	    if (ZYval >= 2)
	      {
		coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , nuclear_inter , input_data , false , inter_data , prot_Y_data);

		const class H_class Vpp(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
					TBMEs_pn , TBMEs_cv , false , false , true , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
		const class GSM_vector Vpp_PSI = Vpp*PSI;

		const TYPE Vpp_average = PSI*Vpp_PSI;
	
		if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpp.nuclear[two-body]|PSI> : " << Vpp_average << " MeV" << endl; 

		TBMEs_p.zero ();
	      }

	    if (NYval >= 2)
	      {
		coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , nuclear_inter , input_data , false , inter_data , neut_Y_data);

		const class H_class Vnn(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
					TBMEs_pn , TBMEs_cv , false , false , false , true , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
		const class GSM_vector Vnn_PSI = Vnn*PSI;

		const TYPE Vnn_average = PSI*Vnn_PSI;
	
		if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hnn.nuclear[two-body]|PSI> : " << Vnn_average << " MeV" << endl;

		TBMEs_n.zero ();
	      }

	    coupled_TBMEs::Berggren::TBMEs_pn_calc (false , false , nuclear_inter , input_data , prot_Y_data , neut_Y_data , false , inter_data , TBMEs_pn);

	    const class H_class Vpn(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
				    TBMEs_pn , TBMEs_cv , false , false , false , false , true , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	    const class GSM_vector Vpn_PSI = Vpn*PSI;

	    const TYPE Vpn_average = PSI*Vpn_PSI;
	
	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpn.nuclear[two-body]|PSI> : " << Vpn_average << " MeV" << endl << endl;
	  }
	
	OBMEs_p_inter_set(TBME_inter) = OBMEs_p_inter;
	OBMEs_n_inter_set(TBME_inter) = OBMEs_n_inter;
      } break;
      
    default: abort_all ();
    }
}

void Hamiltonian_parts::nuclear_three_body_calc_print (
						       const class input_data_str &input_data , 
						       class GSM_vector &PSI_full , 
						       const double J , 
						       const class GSM_vector &PSI ,
						       class GSM_vector &PSI_0 ,
						       class GSM_vector &PSI_1 ,
						       class array<class GSM_vector> &H_PSI_table ,
						       class interaction_class &inter_data , 
						       class TBMEs_class &TBMEs_pn)
{
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  if (!is_it_Minnesota_determine (TBME_inter)) return;
  
  const class TBMEs_class dummy_TBMEs_cv;
  
  class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();

  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage (); 

  const enum storage_type jumps_pn_cv_storage = input_data.get_one_jumps_pn_two_jumps_cv_storage ();
  
  const bool are_there_hyperons = input_data.get_are_there_hyperons ();
  
  class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  class TBMEs_class &TBMEs_p = prot_Y_data.get_TBMEs ();
  class TBMEs_class &TBMEs_n = neut_Y_data.get_TBMEs ();
  
  if (ZYval >= 2) TBMEs_p.zero ();
  if (NYval >= 2) TBMEs_n.zero ();
  
  inter_data.zero ();

  switch (space)
    {
    case PROT_Y_ONLY:
      {
	class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> OBMEs_p_inter = OBMEs_p_inter_set(TBME_inter);
	
	OBMEs_p_inter_set(TBME_inter) = 0.0;

	inter_data.TBMEs_HO_three_body_like_NN_add ();

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , TBME_inter , input_data , false , inter_data , prot_Y_data);

	const class H_class Vpp(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
				TBMEs_pn , dummy_TBMEs_cv , false , false , true , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Vpp_PSI = Vpp*PSI;

	const TYPE Vpp_average = PSI*Vpp_PSI;
	
	if (THIS_PROCESS == MASTER_PROCESS)
	  {
	    if (are_there_hyperons)
	      cout << "<PSI|H.baryonic[three-body]|PSI> : " << Vpp_average << " MeV" << endl << endl;
	    else
	      cout << "<PSI|Hpp.nuclear[three-body]|PSI> : " << Vpp_average << " MeV" << endl << endl;
	  }

	OBMEs_p_inter_set(TBME_inter) = OBMEs_p_inter;
      } break;

    case NEUT_Y_ONLY: 
      {
	class OBMEs_inter_set_str &OBMEs_n_inter_set = neut_Y_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> OBMEs_n_inter = OBMEs_n_inter_set(TBME_inter);
	const class array<TYPE> OBMEs_n_kinetic = OBMEs_n_inter_set(ONE_BODY_KINETIC);
	
	OBMEs_n_inter_set(TBME_inter) = 0.0;

	inter_data.TBMEs_HO_three_body_like_NN_add ();

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , TBME_inter , input_data , false , inter_data , neut_Y_data);

	const class H_class Vnn(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
				TBMEs_pn , dummy_TBMEs_cv , false , false , false , true , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Vnn_PSI = Vnn*PSI;

	const TYPE Vnn_average = PSI*Vnn_PSI;
	
	if (THIS_PROCESS == MASTER_PROCESS)
	  {
	    if (are_there_hyperons)
	      cout << "<PSI|H.baryonic[three-body]|PSI> : " << Vnn_average << " MeV" << endl << endl;
	    else
	      cout << "<PSI|Hnn.nuclear[three-body]|PSI> : " << Vnn_average << " MeV" << endl << endl;
	  }

	OBMEs_n_inter_set(TBME_inter) = OBMEs_n_inter;
      } break;

    case PROT_NEUT_Y:
      {
	class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &OBMEs_n_inter_set = neut_Y_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> OBMEs_p_inter = OBMEs_p_inter_set(TBME_inter);
	const class array<TYPE> OBMEs_n_inter = OBMEs_n_inter_set(TBME_inter);
	
	OBMEs_p_inter_set(TBME_inter) = 0.0;
	OBMEs_n_inter_set(TBME_inter) = 0.0;

	inter_data.TBMEs_HO_three_body_like_NN_add ();

	TBMEs_pn.zero ();

	if (are_there_hyperons)
	  {	    
	    coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , TBME_inter , input_data , false , inter_data , prot_Y_data);
	    coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , TBME_inter , input_data , false , inter_data , neut_Y_data);
	
	    coupled_TBMEs::Berggren::TBMEs_pn_calc (false , false , TBME_inter , input_data , prot_Y_data , neut_Y_data , false , inter_data , TBMEs_pn);
	    
	    const class H_class V(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
				  TBMEs_pn , dummy_TBMEs_cv ,  false , false , true , true , true , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
			    
	    class GSM_vector V_PSI = V*PSI;
	    
	    const TYPE V_average = PSI*V_PSI;
		
	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|H.baryonic[three-body]|PSI> : " << V_average << " MeV" << endl << endl;	    
	  }
	else
	  {
	    if (ZYval >= 2)
	      {
		coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , TBME_inter , input_data , false , inter_data , prot_Y_data);

		const class H_class Vpp(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
					TBMEs_pn , dummy_TBMEs_cv , false , false , true , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
		const class GSM_vector Vpp_PSI = Vpp*PSI;

		const TYPE Vpp_average = PSI*Vpp_PSI;
	
		if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpp.nuclear[three-body]|PSI> : " << Vpp_average << " MeV" << endl; 

		TBMEs_p.zero ();
	      }

	    if (NYval >= 2)
	      {
		coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , TBME_inter , input_data , false , inter_data , neut_Y_data);

		const class H_class Vnn(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
					TBMEs_pn , dummy_TBMEs_cv , false , false , false , true , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
		const class GSM_vector Vnn_PSI = Vnn*PSI;

		const TYPE Vnn_average = PSI*Vnn_PSI;
	
		if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hnn.nuclear[three-body]|PSI> : " << Vnn_average << " MeV" << endl;

		TBMEs_n.zero ();
	      }

	    coupled_TBMEs::Berggren::TBMEs_pn_calc (false , false , TBME_inter , input_data , prot_Y_data , neut_Y_data , false , inter_data , TBMEs_pn);

	    const class H_class Vpn(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
				    TBMEs_pn , dummy_TBMEs_cv , false , false , false , false , true , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	    const class GSM_vector Vpn_PSI = Vpn*PSI;

	    const TYPE Vpn_average = PSI*Vpn_PSI;
	
	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpn.nuclear[three-body]|PSI> : " << Vpn_average << " MeV" << endl << endl;
	  }
	
	OBMEs_p_inter_set(TBME_inter) = OBMEs_p_inter;
	OBMEs_n_inter_set(TBME_inter) = OBMEs_n_inter;
      } break;
      
    default: abort_all ();
    }
}

void Hamiltonian_parts::Coulomb_one_body_calc_print (		
						     const class input_data_str &input_data , 
						     const class interaction_class &inter_data ,
						     class GSM_vector &PSI_full , 
						     const double J ,
						     const class GSM_vector &PSI ,
						     class GSM_vector &PSI_0 ,
						     class GSM_vector &PSI_1 ,
						     class array<class GSM_vector> &H_PSI_table)
{ 
  const class TBMEs_class dummy_TBMEs_pn;
  const class TBMEs_class dummy_TBMEs_cv;
  
  class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();

  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage (); 

  const enum storage_type jumps_pn_cv_storage = input_data.get_one_jumps_pn_two_jumps_cv_storage ();
  
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  const bool are_there_hyperons = input_data.get_are_there_hyperons ();
  
  class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  class TBMEs_class &TBMEs_p = prot_Y_data.get_TBMEs ();
  class TBMEs_class &TBMEs_n = neut_Y_data.get_TBMEs ();
  
  if (ZYval >= 2) TBMEs_p.zero ();
  if (NYval >= 2) TBMEs_n.zero ();

  switch (space)
    {
    case PROT_Y_ONLY:
      {
	class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> OBMEs_p_inter = OBMEs_p_inter_set(TBME_inter);

	const class array<TYPE> OBMEs_p_Coulomb = OBMEs_p_inter_set(ONE_BODY_COULOMB);
	
	OBMEs_p_inter_set(TBME_inter) = OBMEs_p_Coulomb;

	const class H_class Hp_Coulomb_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
						dummy_TBMEs_pn , dummy_TBMEs_cv , true , false , false , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Hp_Coulomb_one_body_PSI = Hp_Coulomb_one_body*PSI;

	const TYPE Hp_Coulomb_average_value = PSI*Hp_Coulomb_one_body_PSI;

	if (THIS_PROCESS == MASTER_PROCESS)
	  {
	    if (are_there_hyperons)
	      cout << "<PSI|H.Coulomb[one-body]|PSI> : " << Hp_Coulomb_average_value << " MeV" << endl << endl;
	    else
	      cout << "<<PSI|Hp.Coulomb[one-body]|PSI> : " << Hp_Coulomb_average_value << " MeV" << endl << endl;
	  }

	OBMEs_p_inter_set(TBME_inter) = OBMEs_p_inter;
      } break;

    case NEUT_Y_ONLY: break;

    case PROT_NEUT_Y: 
      {
	class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &OBMEs_n_inter_set = neut_Y_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> OBMEs_p_inter = OBMEs_p_inter_set(TBME_inter);
	const class array<TYPE> OBMEs_n_inter = OBMEs_n_inter_set(TBME_inter);
	
	const class array<TYPE> OBMEs_p_Coulomb = OBMEs_p_inter_set(ONE_BODY_COULOMB);

	OBMEs_p_inter_set(TBME_inter) = OBMEs_p_Coulomb;
	OBMEs_n_inter_set(TBME_inter) = 0.0;

	const class H_class Hp_Coulomb_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
						dummy_TBMEs_pn , dummy_TBMEs_cv , true , false , false , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Hp_Coulomb_one_body_PSI = Hp_Coulomb_one_body*PSI;

	const TYPE Hp_Coulomb_average_value = PSI*Hp_Coulomb_one_body_PSI;

	if (THIS_PROCESS == MASTER_PROCESS)
	  {
	    if (are_there_hyperons)
	      cout << "<PSI|H.Coulomb[one-body]|PSI> : " << Hp_Coulomb_average_value << " MeV" << endl << endl;
	    else
	      cout << "<PSI|Hp.Coulomb[one-body]|PSI> : " << Hp_Coulomb_average_value << " MeV" << endl << endl;
	  }

	OBMEs_p_inter_set(TBME_inter) = OBMEs_p_inter;
	OBMEs_n_inter_set(TBME_inter) = OBMEs_n_inter;
      } break;
      
    default: abort_all ();
    }
}

void Hamiltonian_parts::Coulomb_two_body_calc_print (
						     const class input_data_str &input_data , 
						     const int Jc_relative_max , 
						     class GSM_vector &PSI_full , 
						     const double J ,
						     const class GSM_vector &PSI ,
						     class interaction_class &inter_data , 
						     class GSM_vector &PSI_0 ,
						     class GSM_vector &PSI_1 ,
						     class array<class GSM_vector> &H_PSI_table)
{
  const bool are_there_hyperons = input_data.get_are_there_hyperons ();
  
  const class TBMEs_class dummy_TBMEs_pn;
  const class TBMEs_class dummy_TBMEs_cv;
  
  class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();

  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage (); 

  const enum storage_type jumps_pn_cv_storage = input_data.get_one_jumps_pn_two_jumps_cv_storage ();

  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  if (ZYval == 1) return;
  
  class TBMEs_class &TBMEs_p = prot_Y_data.get_TBMEs ();
  class TBMEs_class &TBMEs_n = neut_Y_data.get_TBMEs ();
  
  if (ZYval >= 2) TBMEs_p.zero ();
  if (NYval >= 2) TBMEs_n.zero ();
  
  inter_data.zero ();

  switch (space)
    {
    case PROT_Y_ONLY:
      {
	class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> OBMEs_p_inter = OBMEs_p_inter_set(TBME_inter);
	
	OBMEs_p_inter_set(TBME_inter) = 0.0;

	inter_data.TBMEs_HO_Coulomb_lab_add (Jc_relative_max);

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , REALISTIC_INTERACTION , input_data , false , inter_data , prot_Y_data);

	const class H_class Vpp_Coulomb(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
					dummy_TBMEs_pn , dummy_TBMEs_cv , false , false , true , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Vpp_Coulomb_PSI = Vpp_Coulomb*PSI;

	const TYPE Vpp_Coulomb_average = PSI*Vpp_Coulomb_PSI;
	
	if (THIS_PROCESS == MASTER_PROCESS)
	  {
	    if (are_there_hyperons)
	      cout << "<PSI|H.Coulomb[two-body]|PSI> : " << Vpp_Coulomb_average << " MeV" << endl << endl; 
	    else
	      cout << "<PSI|Hpp.Coulomb[two-body]|PSI> : " << Vpp_Coulomb_average << " MeV" << endl << endl; 
	  }

	OBMEs_p_inter_set(TBME_inter) = OBMEs_p_inter;
      } break;

    case NEUT_Y_ONLY: break;

    case PROT_NEUT_Y: 
      { 
	class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &OBMEs_n_inter_set = neut_Y_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> OBMEs_p_inter = OBMEs_p_inter_set(TBME_inter);
	const class array<TYPE> OBMEs_n_inter = OBMEs_n_inter_set(TBME_inter);
	
	OBMEs_p_inter_set(TBME_inter) = 0.0;
	OBMEs_n_inter_set(TBME_inter) = 0.0;

	inter_data.TBMEs_HO_Coulomb_lab_add (Jc_relative_max);

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , REALISTIC_INTERACTION , input_data , false , inter_data , prot_Y_data);

	const class H_class Vpp_Coulomb(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false ,
					dummy_TBMEs_pn , dummy_TBMEs_cv , false , false , true , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Vpp_Coulomb_PSI = Vpp_Coulomb*PSI;

	const TYPE Vpp_Coulomb_average = PSI*Vpp_Coulomb_PSI;
	
	if (THIS_PROCESS == MASTER_PROCESS)
	  {
	    if (are_there_hyperons)
	      cout << "<PSI|H.Coulomb[two-body]|PSI> : " << Vpp_Coulomb_average << " MeV" << endl << endl;
	    else
	      cout << "<PSI|Hpp.Coulomb[two-body]|PSI> : " << Vpp_Coulomb_average << " MeV" << endl << endl;
	  }

	OBMEs_p_inter_set(TBME_inter) = OBMEs_p_inter;
	OBMEs_n_inter_set(TBME_inter) = OBMEs_n_inter;  
      } break;
      
    default: abort_all ();
    }
}







void Hamiltonian_parts::GSM_SMEC_energies_print (
						 const class input_data_str &input_data , 
						 const double J , 
						 class GSM_vector &PSI_full , 
						 class TBMEs_class &TBMEs_pn , 
						 class TBMEs_class &TBMEs_cv , 
						 const class GSM_vector &PSI ,
						 class GSM_vector &PSI_0 ,
						 class GSM_vector &PSI_1 ,
						 class array<class GSM_vector> &H_PSI_table)
{
  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage ();
  
  const enum storage_type jumps_pn_cv_storage = input_data.get_one_jumps_pn_two_jumps_cv_storage ();
  
  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();
      
  class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
  
  const class H_class H(false , false , Hamiltonian_storage , M_TBMEs_storage , jumps_pn_cv_storage , true , false , false , 
			TBMEs_pn , TBMEs_cv , true , true , true , true , true , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
              
  class GSM_vector Q_PSI = PSI;
  class GSM_vector P_PSI = PSI;

  Q_PSI.pole_space_project ();   
  P_PSI.scat_space_project (); 
  
  const class GSM_vector HQ_PSI = H*Q_PSI;
  const class GSM_vector HP_PSI = H*P_PSI;
   
  const TYPE QHQ_energy = HQ_PSI*Q_PSI , PHQ_energy = HQ_PSI*P_PSI;
  const TYPE QHP_energy = HP_PSI*Q_PSI , PHP_energy = HP_PSI*P_PSI; 
  
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << "<PSI|QHQ|PSI>       : " << QHQ_energy              << " MeV" << endl;
      cout << "<PSI|PHP|PSI>       : " << PHP_energy              << " MeV" << endl;      
      cout << "<PSI|PHQ + QHP|PSI> : " << PHQ_energy + QHP_energy << " MeV" << endl << endl;
    }
}


void Hamiltonian_parts::calc_print (
				    const class input_data_str &input_data , 
				    const class array<class correlated_state_str> &PSI_qn_tab , 
				    class interaction_class &inter_data , 
				    class baryons_data &prot_Y_data ,
				    class baryons_data &neut_Y_data , 
				    class TBMEs_class &TBMEs_pn , 
				    class TBMEs_class &TBMEs_cv ,
				    class GSM_vector &PSI_full)
{  
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Hamiltonian parts" << endl;
      cout <<         "-----------------" << endl << endl;
    }
 
  const enum space_type space = input_data.get_space ();
  
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const int S = input_data.get_hypernucleus_strangeness ();
  
  if (S != 0) error_message_print_abort ("Hypernuclei cannot be considered in Hamiltonian_parts");
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
    
  const int Z = prot_Y_data.get_N_nucleons ();
  const int N = neut_Y_data.get_N_nucleons ();
  
  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();
  
  const int Jn_relative_max = input_data.get_Jn_relative_max ();
  const int Jc_relative_max = input_data.get_Jc_relative_max ();
  
  const unsigned int eigenstates_number = input_data.get_Hamiltonian_parts_eigenstates_number ();

  const class array<unsigned int > &Hamiltonian_parts_BP_tab = input_data.get_Hamiltonian_parts_BP_tab ();

  const class array<double > &Hamiltonian_parts_J_tab = input_data.get_Hamiltonian_parts_J_tab ();

  const class array<unsigned int > &Hamiltonian_parts_vector_index_tab = input_data.get_Hamiltonian_parts_vector_index_tab ();

  const enum potential_type H_potential = prot_Y_data.get_H_potential ();

  const int ZY_charge_basis_potential_pos = input_data.get_ZY_charge_basis_potential_pos ();
 
  for (unsigned int eigenstates_index = 0 ; eigenstates_index < eigenstates_number ; eigenstates_index++)
    {
      const unsigned int BP = Hamiltonian_parts_BP_tab(eigenstates_index);

      const unsigned int vector_index = Hamiltonian_parts_vector_index_tab(eigenstates_index);

      const double J = Hamiltonian_parts_J_tab(eigenstates_index);

      const class correlated_state_str PSI_qn = PSI_quantum_numbers_find (Z , N , BP , S , J , vector_index , PSI_qn_tab);

      const double M = optimal_M_calc (input_data , prot_Y_data , neut_Y_data , BP , J);

      class GSM_vector_helper_class GSM_vector_helper(is_it_MPI_parallelized , space , TBME_inter , false , truncation_hw , truncation_ph ,
						      n_holes_max   , n_scat_max    , E_max_hw ,
						      n_holes_max_p , n_scat_max_p  , Ep_max_hw ,
						      n_holes_max_n , n_scat_max_n  , En_max_hw , BP , M , true , prot_Y_data , neut_Y_data);
      
      class GSM_vector PSI(GSM_vector_helper);
      
      PSI.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);
      
      class GSM_vector PSI_copy = PSI;

      class GSM_vector PSI_0 = PSI;
      class GSM_vector PSI_1 = PSI;

      class array<class GSM_vector> H_PSI_table(NUMBER_OF_THREADS);
      
      for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) H_PSI_table(i).allocate_fill (PSI);

      if (THIS_PROCESS == MASTER_PROCESS) cout << J_Pi_vector_index_string (BP , J , vector_index) << endl << endl;

      GSM_SMEC_energies_print (input_data , J , PSI_full , TBMEs_pn , TBMEs_cv , PSI , PSI_0 , PSI_1 , H_PSI_table);
      
      if ((H_potential != WS) || (space == NEUT_Y_ONLY) || (ZY_charge_basis_potential_pos == 0)) kinetic_one_body_calc_print (input_data , inter_data , PSI_full , J , PSI , PSI_0 , PSI_1 , H_PSI_table);

      kinetic_recoil_calc_print (input_data , inter_data , PSI_full , J , PSI , PSI_0 , PSI_1 , H_PSI_table , TBMEs_pn);

      nuclear_one_body_calc_print (input_data , inter_data , PSI_full , J , PSI , PSI_0 , PSI_1 , H_PSI_table);

      nuclear_two_body_calc_print (input_data , Jn_relative_max , PSI_full , J , PSI , inter_data , PSI_0 , PSI_1 , H_PSI_table , TBMEs_pn , TBMEs_cv);

      if (is_it_Minnesota_determine (TBME_inter)) nuclear_three_body_calc_print (input_data , PSI_full , J , PSI , PSI_0 , PSI_1 , H_PSI_table , inter_data , TBMEs_pn);

      if (H_potential != WS) Coulomb_one_body_calc_print (input_data , inter_data , PSI_full , J , PSI , PSI_0 , PSI_1 , H_PSI_table);

      Coulomb_two_body_calc_print (input_data , Jc_relative_max , PSI_full , J , PSI , inter_data , PSI_0 , PSI_1 , H_PSI_table);
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << endl;
    }
}


