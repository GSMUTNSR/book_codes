#include "../GSM_include/GSM_include_def.h"

using namespace string_routines;
using namespace correlated_state_routines;
using namespace GSM_vector_dimensions;
using namespace inputs_misc;

// MPI transfer is done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------


// Routines calculating expectation values of the different parts of the Hamiltonian on an eigenvector |Psi>
// ---------------------------------------------------------------------------------------------------------
// The Hamiltonian is the sum of one-body kinetic part, two-body kinetic part (i.e. recoil), one-body and two-body nuclear and Coulomb parts and three-body like part (Minnesota only).
// They are all calculated one after the other and printed on screen.
//
// For this, OBMEs and TBMEs related to the considered Hamiltonian part are calculated and stored in OBMEs and TBMEs arrays and classes, then erasing previous OBMEs and TBMEs.
//
// The Hamiltonian part operator is applied to the eigenvector H[part]|Psi>,
// and the expectation value <Psi | H[part] | Psi> is then calculated and printed on screen.
//
// OBMEs and TBMEs of the initial Hamiltonian are erased at the end of the calculation.


void Hamiltonian_parts::kinetic_one_body_calc_print (
						     const class input_data_str &input_data , 
						     const class interaction_class &inter_data ,
						     class GSM_vector &PSI_full , 
						     const double J ,
						     const class GSM_vector &PSI ,
						     class GSM_vector &PSI_0 ,
						     class GSM_vector &PSI_1 ,
						     class array<class GSM_vector> &H_PSI_table ,
						     class TBMEs_class &TBMEs_pn)
{
  class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();

  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage (); 

  const enum storage_type one_jumps_pn_storage = input_data.get_one_jumps_pn_storage ();
  
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  class nucleons_data &prot_data = GSM_vector_helper.get_prot_data ();
  class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  class TBMEs_class &TBMEs_prot = prot_data.get_TBMEs ();
  class TBMEs_class &TBMEs_neut = neut_data.get_TBMEs ();
  
  if (Zval >= 2) TBMEs_prot.zero ();
  if (Nval >= 2) TBMEs_neut.zero ();
  
  switch (space)
    {
    case PROTONS_ONLY:
      {
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);

	const class array<TYPE> prot_OBMEs_kinetic = prot_OBMEs_inter_set(ONE_BODY_KINETIC);
	
	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_kinetic;

	const class H_class Tp_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , true , false , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Tp_one_body_PSI = Tp_one_body*PSI;

	const TYPE Tp_average_value = PSI*Tp_one_body_PSI;

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tp[one-body]|PSI> : " << Tp_average_value << " MeV" << endl << endl;

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
      } break;

    case NEUTRONS_ONLY: 
      {
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);

	const class array<TYPE> neut_OBMEs_kinetic = neut_OBMEs_inter_set(ONE_BODY_KINETIC);
	
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_kinetic;

	const class H_class Tn_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , true , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);

	const class GSM_vector Tn_one_body_PSI = Tn_one_body*PSI;

	const TYPE Tn_average_value = PSI*Tn_one_body_PSI;
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tn[one-body]|PSI> : " << Tn_average_value << " MeV" << endl << endl;

	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;

    case PROTONS_NEUTRONS:
      { 
	TBMEs_pn.zero ();

	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);
	
	const class array<TYPE> prot_OBMEs_kinetic = prot_OBMEs_inter_set(ONE_BODY_KINETIC);
	const class array<TYPE> neut_OBMEs_kinetic = neut_OBMEs_inter_set(ONE_BODY_KINETIC);

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_kinetic;
	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	{
	  const class H_class Tp_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , true , false , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	  
	  const class GSM_vector Tp_one_body_PSI = Tp_one_body*PSI;
	
	  const TYPE Tp_average_value = PSI*Tp_one_body_PSI;

	  if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tp[one-body]|PSI> : " << Tp_average_value << " MeV" << endl << endl;
	}

	prot_OBMEs_inter_set(TBME_inter) = 0.0;
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_kinetic;

	{
	  const class H_class Tn_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , true , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	  
	  const class GSM_vector Tn_one_body_PSI = Tn_one_body*PSI;

	  const TYPE Tn_average_value = PSI*Tn_one_body_PSI;
	  
	  if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tn[one-body]|PSI> : " << Tn_average_value << " MeV" << endl << endl;
	}

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;

    default: abort_all ();
    }
}

void Hamiltonian_parts::kinetic_recoil_calc_print (
						   const class input_data_str &input_data , 
						   const class interaction_class &inter_data , 
						   class GSM_vector &PSI_full , 
						   const double J , 
						   const class GSM_vector &PSI ,
						   class GSM_vector &PSI_0 ,
						   class GSM_vector &PSI_1 ,
						   class array<class GSM_vector> &H_PSI_table ,
						   class TBMEs_class &TBMEs_pn)
{  
  class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage (); 

  const enum storage_type one_jumps_pn_storage = input_data.get_one_jumps_pn_storage ();
  
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);
  
  const int sign_inter = (!is_it_COSM) ? (-1) : (1);

  class nucleons_data &prot_data = GSM_vector_helper.get_prot_data ();
  class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  class TBMEs_class &TBMEs_prot = prot_data.get_TBMEs ();
  class TBMEs_class &TBMEs_neut = neut_data.get_TBMEs ();
  
  if (Zval >= 2) TBMEs_prot.zero ();
  if (Nval >= 2) TBMEs_neut.zero ();

  switch (space)
    {
    case PROTONS_ONLY:
      {	
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	
	prot_OBMEs_inter_set(TBME_inter) = 0.0;

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , CM_KINETIC_INTERACTION , input_data , false , inter_data , prot_data);

	const class H_class Tpp_recoil_no_sign(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , false , true , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Tpp_recoil_no_sign_PSI = Tpp_recoil_no_sign*PSI;

	const TYPE Tpp_recoil_average = sign_inter*(PSI*Tpp_recoil_no_sign_PSI);
	  
	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tpp[recoil]|PSI> : " << Tpp_recoil_average << " MeV" << endl << endl;

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
      } break;

    case NEUTRONS_ONLY: 
      {
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);
	
	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , CM_KINETIC_INTERACTION , input_data , false , inter_data , neut_data); 

	const class H_class Tnn_recoil_no_sign(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , false , false , true , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
		
	const class GSM_vector Tnn_recoil_no_sign_PSI = Tnn_recoil_no_sign*PSI;
	
	const TYPE Tnn_recoil_average = sign_inter*(PSI*Tnn_recoil_no_sign_PSI);
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tnn[recoil]|PSI> : " << Tnn_recoil_average << " MeV" << endl << endl;

	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;

    case PROTONS_NEUTRONS:
      {
	TBMEs_pn.zero ();

	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);

	prot_OBMEs_inter_set(TBME_inter) = 0.0;
	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	if (Zval >= 2)
	  {
	    coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , CM_KINETIC_INTERACTION , input_data , false , inter_data , prot_data);

	    const class H_class Tpp_recoil_no_sign(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , false , true , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	    const class GSM_vector Tpp_recoil_no_sign_PSI = Tpp_recoil_no_sign*PSI;

	    const TYPE Tpp_recoil_average = sign_inter*(PSI*Tpp_recoil_no_sign_PSI);
	    
	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tpp[recoil]|PSI> : " << Tpp_recoil_average << " MeV" << endl << endl;
	    
	    TBMEs_prot.zero ();
	  }

	if (Nval >= 2)
	  {
	    coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , CM_KINETIC_INTERACTION , input_data , false , inter_data , neut_data); 

	    const class H_class Tnn_recoil_no_sign(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , false , false , true , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	    const class GSM_vector Tnn_recoil_no_sign_PSI = Tnn_recoil_no_sign*PSI;
	    
	    const TYPE Tnn_recoil_average = sign_inter*(PSI*Tnn_recoil_no_sign_PSI);
	
	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tnn[recoil]|PSI> : " << Tnn_recoil_average << " MeV" << endl << endl;
	    
	    TBMEs_neut.zero ();
	  }

	coupled_TBMEs::Berggren::TBMEs_pn_calc (false , false , CM_KINETIC_INTERACTION , input_data , prot_data , neut_data , false , inter_data , TBMEs_pn);

	const class H_class Tpn_recoil_no_sign(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , false , false , false , true , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Tpn_recoil_no_sign_PSI = Tpn_recoil_no_sign*PSI;

	const TYPE Tpn_recoil_average = sign_inter*(PSI*Tpn_recoil_no_sign_PSI);
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tpn[recoil]|PSI> : " << Tpn_recoil_average << " MeV" << endl << endl;
	    
	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;
      
    default: abort_all ();
    }
}

void Hamiltonian_parts::nuclear_one_body_calc_print (
						     const class input_data_str &input_data , 
						     const class interaction_class &inter_data ,
						     class GSM_vector &PSI_full , 
						     const double J ,
						     const class GSM_vector &PSI ,
						     class GSM_vector &PSI_0 ,
						     class GSM_vector &PSI_1 ,
						     class array<class GSM_vector> &H_PSI_table ,
						     class TBMEs_class &TBMEs_pn)
{
  class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage (); 

  const enum storage_type one_jumps_pn_storage = input_data.get_one_jumps_pn_storage ();
  
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  class nucleons_data &prot_data = GSM_vector_helper.get_prot_data ();
  class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  class TBMEs_class &TBMEs_prot = prot_data.get_TBMEs ();
  class TBMEs_class &TBMEs_neut = neut_data.get_TBMEs ();
  
  if (Zval >= 2) TBMEs_prot.zero ();
  if (Nval >= 2) TBMEs_neut.zero ();
  
  switch (space)
    {
    case PROTONS_ONLY:
      {
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);

	const class array<TYPE> prot_OBMEs_nuclear = prot_OBMEs_inter_set(ONE_BODY_NUCLEAR);
	
	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_nuclear;

	const class H_class Hp_nuclear_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , true , false , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Hp_nuclear_one_body_PSI = Hp_nuclear_one_body*PSI;

	const TYPE Hp_nuclear_average_value = PSI*Hp_nuclear_one_body_PSI;

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hp.nuclear[one-body]|PSI> : " << Hp_nuclear_average_value << " MeV" << endl << endl;

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
      } break;

    case NEUTRONS_ONLY: 
      {
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);

	const class array<TYPE> neut_OBMEs_nuclear = neut_OBMEs_inter_set(ONE_BODY_NUCLEAR);
	
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_nuclear;

	const class H_class Hn_nuclear_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , true , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	class GSM_vector Hn_nuclear_one_body_PSI = Hn_nuclear_one_body*PSI;

	const TYPE Hn_nuclear_average_value = PSI*Hn_nuclear_one_body_PSI;

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hn.nuclear[one-body]|PSI> : " << Hn_nuclear_average_value << " MeV" << endl << endl;
	
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;

    case PROTONS_NEUTRONS:
      { 
	TBMEs_pn.zero ();

	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);
	
	const class array<TYPE> prot_OBMEs_nuclear = prot_OBMEs_inter_set(ONE_BODY_NUCLEAR);
	const class array<TYPE> neut_OBMEs_nuclear = neut_OBMEs_inter_set(ONE_BODY_NUCLEAR);

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_nuclear;
	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	{
	  const class H_class Hp_nuclear_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , true , false , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	  const class GSM_vector Hp_nuclear_one_body_PSI = Hp_nuclear_one_body*PSI;
	  
	  const TYPE Hp_nuclear_average_value = PSI*Hp_nuclear_one_body_PSI;
	  
	  if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hp.nuclear[one-body]|PSI> : " << Hp_nuclear_average_value << " MeV" << endl << endl;
	}

	prot_OBMEs_inter_set(TBME_inter) = 0.0;
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_nuclear;

	{
	  const class H_class Hn_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , true , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	  const class GSM_vector Hn_nuclear_one_body_PSI = Hn_one_body*PSI;

	  const TYPE Hn_nuclear_average_value = PSI*Hn_nuclear_one_body_PSI;

	  if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hn.nuclear[one-body]|PSI> : " << Hn_nuclear_average_value << " MeV" << endl << endl;
	}

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;
      
    default: abort_all ();
    }
}

void Hamiltonian_parts::nuclear_two_body_calc_print (
						     const class input_data_str &input_data , 
						     const int Jn_relative_max , 
						     class GSM_vector &PSI_full , 
						     const double J ,
						     const class GSM_vector &PSI ,
						     class interaction_class &inter_data , 
						     class GSM_vector &PSI_0 ,
						     class GSM_vector &PSI_1 ,
						     class array<class GSM_vector> &H_PSI_table ,
						     class TBMEs_class &TBMEs_pn)
{
  class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage (); 

  const enum storage_type one_jumps_pn_storage = input_data.get_one_jumps_pn_storage ();

  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const enum interaction_type nuclear_inter = nuclear_inter_determine (TBME_inter);

  class nucleons_data &prot_data = GSM_vector_helper.get_prot_data ();
  class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  class TBMEs_class &TBMEs_prot = prot_data.get_TBMEs ();
  class TBMEs_class &TBMEs_neut = neut_data.get_TBMEs ();
  
  if (Zval >= 2) TBMEs_prot.zero ();
  if (Nval >= 2) TBMEs_neut.zero ();
  
  const double TBME_A_dependent_factor = TBME_A_dependent_factor_calc (input_data);
   
  inter_data.zero ();

  if (nuclear_inter == SGI)
    inter_data.SGI_radial_tables_calc ();
  else if ((nuclear_inter == FIT) || is_it_FHT_determine (nuclear_inter) || is_it_EFT_determine (nuclear_inter) ||
	   (is_it_Minnesota_determine (nuclear_inter)) || (nuclear_inter == REALISTIC_INTERACTION))
    inter_data.TBMEs_HO_lab_no_added_kinetic_part (false , Jn_relative_max , 0 , TBME_A_dependent_factor);

  switch (space)
    {
    case PROTONS_ONLY:
      {
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	
	prot_OBMEs_inter_set(TBME_inter) = 0.0;

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , nuclear_inter , input_data , false , inter_data , prot_data);

	const class H_class Vpp(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , false , true , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Vpp_PSI = Vpp*PSI;

	const TYPE Vpp_average = PSI*Vpp_PSI;
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpp.nuclear[two-body]|PSI> : " << Vpp_average << " MeV" << endl << endl; 

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
      } break;

    case NEUTRONS_ONLY: 
      {
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);
	
	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , nuclear_inter , input_data , false , inter_data , neut_data);

	const class H_class Vnn(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , false , false , true , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Vnn_PSI = Vnn*PSI;

	const TYPE Vnn_average = PSI*Vnn_PSI;
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hnn.nuclear[two-body]|PSI> : " << Vnn_average << " MeV" << endl << endl;
	
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;       
      } break;

    case PROTONS_NEUTRONS:
      {
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);
	
	prot_OBMEs_inter_set(TBME_inter) = 0.0;
	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	TBMEs_pn.zero ();

	if (Zval >= 2)
	  {
	    coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , nuclear_inter , input_data , false , inter_data , prot_data);

	    const class H_class Vpp(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , false , true , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	    const class GSM_vector Vpp_PSI = Vpp*PSI;

	    const TYPE Vpp_average = PSI*Vpp_PSI;
	
	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpp.nuclear[two-body]|PSI> : " << Vpp_average << " MeV" << endl << endl; 

	    TBMEs_prot.zero ();
	  }

	if (Nval >= 2)
	  {
	    coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , nuclear_inter , input_data , false , inter_data , neut_data);

	    const class H_class Vnn(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , false , false , true , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	    const class GSM_vector Vnn_PSI = Vnn*PSI;

	    const TYPE Vnn_average = PSI*Vnn_PSI;
	
	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hnn.nuclear[two-body]|PSI> : " << Vnn_average << " MeV" << endl << endl;

	    TBMEs_neut.zero ();
	  }

	coupled_TBMEs::Berggren::TBMEs_pn_calc (false , false , nuclear_inter , input_data , prot_data , neut_data , false , inter_data , TBMEs_pn);

	const class H_class Vpn(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , false , false , false , true , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Vpn_PSI = Vpn*PSI;

	const TYPE Vpn_average = PSI*Vpn_PSI;
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpn.nuclear[two-body]|PSI> : " << Vpn_average << " MeV" << endl << endl;

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;
      
    default: abort_all ();
    }
}

void Hamiltonian_parts::nuclear_three_body_calc_print (
						       const class input_data_str &input_data , 
						       class GSM_vector &PSI_full , 
						       const double J , 
						       const class GSM_vector &PSI ,
						       class GSM_vector &PSI_0 ,
						       class GSM_vector &PSI_1 ,
						       class array<class GSM_vector> &H_PSI_table ,
						       class interaction_class &inter_data , 
						       class TBMEs_class &TBMEs_pn)
{
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  if (!is_it_Minnesota_determine (TBME_inter)) return;
  
  class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();

  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage (); 

  const enum storage_type one_jumps_pn_storage = input_data.get_one_jumps_pn_storage ();
  
  class nucleons_data &prot_data = GSM_vector_helper.get_prot_data ();
  class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();

  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  class TBMEs_class &TBMEs_prot = prot_data.get_TBMEs ();
  class TBMEs_class &TBMEs_neut = neut_data.get_TBMEs ();
  
  if (Zval >= 2) TBMEs_prot.zero ();
  if (Nval >= 2) TBMEs_neut.zero ();
  
  inter_data.zero ();

  switch (space)
    {
    case PROTONS_ONLY:
      {
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	
	prot_OBMEs_inter_set(TBME_inter) = 0.0;

	inter_data.TBMEs_HO_three_body_like_add ();

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , TBME_inter , input_data , false , inter_data , prot_data);

	const class H_class Vpp(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , false , true , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Vpp_PSI = Vpp*PSI;

	const TYPE Vpp_average = PSI*Vpp_PSI;
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpp.nuclear[three-body]|PSI> : " << Vpp_average << " MeV" << endl << endl; 

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
      } break;

    case NEUTRONS_ONLY: 
      {
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);
	const class array<TYPE> neut_OBMEs_kinetic = neut_OBMEs_inter_set(ONE_BODY_KINETIC);
	
	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	inter_data.TBMEs_HO_three_body_like_add ();

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , TBME_inter , input_data , false , inter_data , neut_data);

	const class H_class Vnn(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , false , false , true , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Vnn_PSI = Vnn*PSI;

	const TYPE Vnn_average = PSI*Vnn_PSI;
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hnn.nuclear[three-body]|PSI> : " << Vnn_average << " MeV" << endl << endl;

	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;

    case PROTONS_NEUTRONS:
      {
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);
	
	prot_OBMEs_inter_set(TBME_inter) = 0.0;
	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	inter_data.TBMEs_HO_three_body_like_add ();

	TBMEs_pn.zero ();

	if (Zval >= 2)
	  {
	    coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , TBME_inter , input_data , false , inter_data , prot_data);

	    const class H_class Vpp(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , false , true , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	    const class GSM_vector Vpp_PSI = Vpp*PSI;

	    const TYPE Vpp_average = PSI*Vpp_PSI;
	
	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpp.nuclear[three-body]|PSI> : " << Vpp_average << " MeV" << endl << endl; 

	    TBMEs_prot.zero ();
	  }

	if (Nval >= 2)
	  {
	    coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , TBME_inter , input_data , false , inter_data , neut_data);

	    const class H_class Vnn(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , false , false , true , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	    const class GSM_vector Vnn_PSI = Vnn*PSI;

	    const TYPE Vnn_average = PSI*Vnn_PSI;
	
	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hnn.nuclear[three-body]|PSI> : " << Vnn_average << " MeV" << endl << endl;

	    TBMEs_neut.zero ();
	  }

	coupled_TBMEs::Berggren::TBMEs_pn_calc (false , false , TBME_inter , input_data , prot_data , neut_data , false , inter_data , TBMEs_pn);

	const class H_class Vpn(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , false , false , false , true , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Vpn_PSI = Vpn*PSI;

	const TYPE Vpn_average = PSI*Vpn_PSI;
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpn.nuclear[three-body]|PSI> : " << Vpn_average << " MeV" << endl << endl;

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;
      
    default: abort_all ();
    }
}

void Hamiltonian_parts::Coulomb_one_body_calc_print (		
						     const class input_data_str &input_data , 
						     const class interaction_class &inter_data ,
						     class GSM_vector &PSI_full , 
						     const double J ,
						     const class GSM_vector &PSI ,
						     class GSM_vector &PSI_0 ,
						     class GSM_vector &PSI_1 ,
						     class array<class GSM_vector> &H_PSI_table ,
						     class TBMEs_class &TBMEs_pn)
{ 
  class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();

  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage (); 

  const enum storage_type one_jumps_pn_storage = input_data.get_one_jumps_pn_storage ();
  
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  class nucleons_data &prot_data = GSM_vector_helper.get_prot_data ();
  class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  class TBMEs_class &TBMEs_prot = prot_data.get_TBMEs ();
  class TBMEs_class &TBMEs_neut = neut_data.get_TBMEs ();
  
  if (Zval >= 2) TBMEs_prot.zero ();
  if (Nval >= 2) TBMEs_neut.zero ();

  switch (space)
    {
    case PROTONS_ONLY:
      {
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);

	const class array<TYPE> prot_OBMEs_Coulomb = prot_OBMEs_inter_set(ONE_BODY_COULOMB);
	
	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_Coulomb;

	const class H_class Hp_Coulomb_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , true , false , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Hp_Coulomb_one_body_PSI = Hp_Coulomb_one_body*PSI;

	const TYPE Hp_Coulomb_average_value = PSI*Hp_Coulomb_one_body_PSI;

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hp.Coulomb[one-body]|PSI> : " << Hp_Coulomb_average_value << " MeV" << endl << endl;

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
      } break;

    case NEUTRONS_ONLY: 
      break;

    case PROTONS_NEUTRONS: 
      {
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);
	
	const class array<TYPE> prot_OBMEs_Coulomb = prot_OBMEs_inter_set(ONE_BODY_COULOMB);

	TBMEs_pn.zero ();

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_Coulomb;
	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	const class H_class Hp_Coulomb_one_body(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , true , false , false , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Hp_Coulomb_one_body_PSI = Hp_Coulomb_one_body*PSI;

	const TYPE Hp_Coulomb_average_value = PSI*Hp_Coulomb_one_body_PSI;

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hp.Coulomb[one-body]|PSI> : " << Hp_Coulomb_average_value << " MeV" << endl << endl;

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;
      
    default: abort_all ();
    }
}

void Hamiltonian_parts::Coulomb_two_body_calc_print (
						     const class input_data_str &input_data , 
						     const int Jc_relative_max , 
						     class GSM_vector &PSI_full , 
						     const double J ,
						     const class GSM_vector &PSI ,
						     class interaction_class &inter_data , 
						     class GSM_vector &PSI_0 ,
						     class GSM_vector &PSI_1 ,
						     class array<class GSM_vector> &H_PSI_table ,
						     class TBMEs_class &TBMEs_pn)
{
  class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();

  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage (); 

  const enum storage_type one_jumps_pn_storage = input_data.get_one_jumps_pn_storage ();

  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  class nucleons_data &prot_data = GSM_vector_helper.get_prot_data ();
  class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  if (Zval == 1) return;
  
  class TBMEs_class &TBMEs_prot = prot_data.get_TBMEs ();
  class TBMEs_class &TBMEs_neut = neut_data.get_TBMEs ();
  
  if (Zval >= 2) TBMEs_prot.zero ();
  if (Nval >= 2) TBMEs_neut.zero ();
  
  inter_data.zero ();

  switch (space)
    {
    case PROTONS_ONLY:
      {
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	
	prot_OBMEs_inter_set(TBME_inter) = 0.0;

	inter_data.TBMEs_HO_Coulomb_lab_add (Jc_relative_max);

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , REALISTIC_INTERACTION , input_data , false , inter_data , prot_data);

	const class H_class Vpp_Coulomb(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , false , true , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Vpp_Coulomb_PSI = Vpp_Coulomb*PSI;

	const TYPE Vpp_Coulomb_average = PSI*Vpp_Coulomb_PSI;
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpp.Coulomb[two-body]|PSI> : " << Vpp_Coulomb_average << " MeV" << endl << endl; 

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
      } break;

    case NEUTRONS_ONLY: 
      break;

    case PROTONS_NEUTRONS: 
      { 
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);
	
	prot_OBMEs_inter_set(TBME_inter) = 0.0;
	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	TBMEs_pn.zero ();

	inter_data.TBMEs_HO_Coulomb_lab_add (Jc_relative_max);

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , REALISTIC_INTERACTION , input_data , false , inter_data , prot_data);

	const class H_class Vpp_Coulomb(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage ,  true , false , false , TBMEs_pn , false , false , true , false , false , J , GSM_vector_helper , PSI_full , PSI_0 , PSI_1 , H_PSI_table);
	
	const class GSM_vector Vpp_Coulomb_PSI = Vpp_Coulomb*PSI;

	const TYPE Vpp_Coulomb_average = PSI*Vpp_Coulomb_PSI;
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpp.Coulomb[two-body]|PSI> : " << Vpp_Coulomb_average << " MeV" << endl << endl; 

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;  
      } break;
      
    default: abort_all ();
    }
}

void Hamiltonian_parts::calc_print (
				    const class input_data_str &input_data , 
				    const class array<class correlated_state_str> &PSI_qn_tab , 
				    class interaction_class &inter_data , 
				    class nucleons_data &prot_data ,
				    class nucleons_data &neut_data , 
				    class TBMEs_class &TBMEs_pn ,
				    class GSM_vector &PSI_full)
{  
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Hamiltonian parts" << endl;
      cout <<         "-----------------" << endl << endl;
    }
 
  const enum space_type space = input_data.get_space ();
  
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
    
  const int Z = prot_data.get_N_nucleons ();
  const int N = neut_data.get_N_nucleons ();
  
  const int n_holes_max_p = prot_data.get_n_holes_max ();
  const int n_holes_max_n = neut_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_data.get_n_scat_max ();
  const int n_scat_max_n = neut_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_data.get_E_max_hw ();
  const int En_max_hw = neut_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();
  
  const int Jn_relative_max = input_data.get_Jn_relative_max ();
  const int Jc_relative_max = input_data.get_Jc_relative_max ();
  
  const unsigned int eigenstates_number = input_data.get_Hamiltonian_parts_eigenstates_number ();

  const class array<unsigned int > &Hamiltonian_parts_BP_tab = input_data.get_Hamiltonian_parts_BP_tab ();

  const class array<double > &Hamiltonian_parts_J_tab = input_data.get_Hamiltonian_parts_J_tab ();

  const class array<unsigned int > &Hamiltonian_parts_vector_index_tab = input_data.get_Hamiltonian_parts_vector_index_tab ();

  const enum potential_type H_potential = prot_data.get_H_potential ();

  const int Z_charge_basis_potential = input_data.get_Z_charge_basis_potential ();
 
  for (unsigned int eigenstates_index = 0 ; eigenstates_index < eigenstates_number ; eigenstates_index++)
    {
      const unsigned int BP = Hamiltonian_parts_BP_tab(eigenstates_index);

      const unsigned int vector_index = Hamiltonian_parts_vector_index_tab(eigenstates_index);

      const double J = Hamiltonian_parts_J_tab(eigenstates_index);

      const class correlated_state_str PSI_qn = PSI_quantum_numbers_find (Z , N , BP , J , vector_index , PSI_qn_tab);

      const double M = optimal_M_calc (input_data , prot_data , neut_data , BP , J);

      class GSM_vector_helper_class GSM_vector_helper(is_it_MPI_parallelized , space , TBME_inter , false , truncation_hw , truncation_ph ,
						      n_holes_max   , n_scat_max    , E_max_hw ,
						      n_holes_max_p , n_scat_max_p  , Ep_max_hw ,
						      n_holes_max_n , n_scat_max_n  , En_max_hw , BP , M , true , prot_data , neut_data);
      
      class GSM_vector PSI(GSM_vector_helper);
      
      PSI.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);
      
      class GSM_vector PSI_copy = PSI;

      class GSM_vector PSI_0 = PSI;
      class GSM_vector PSI_1 = PSI;

      class array<class GSM_vector> H_PSI_table(NUMBER_OF_THREADS);
      
      for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) H_PSI_table(i).allocate_fill (PSI);

      if (THIS_PROCESS == MASTER_PROCESS) cout << J_Pi_vector_index_string (BP , J , vector_index) << endl << endl;

      if ((H_potential != WS) || (space == NEUTRONS_ONLY) || (Z_charge_basis_potential == 0)) kinetic_one_body_calc_print (input_data , inter_data , PSI_full , J , PSI , PSI_0 , PSI_1 , H_PSI_table , TBMEs_pn);

      kinetic_recoil_calc_print (input_data , inter_data , PSI_full , J , PSI , PSI_0 , PSI_1 , H_PSI_table , TBMEs_pn);

      nuclear_one_body_calc_print (input_data , inter_data , PSI_full , J , PSI , PSI_0 , PSI_1 , H_PSI_table , TBMEs_pn);

      nuclear_two_body_calc_print (input_data , Jn_relative_max , PSI_full , J , PSI , inter_data , PSI_0 , PSI_1 , H_PSI_table , TBMEs_pn);

      if (is_it_Minnesota_determine (TBME_inter)) nuclear_three_body_calc_print (input_data , PSI_full , J , PSI , PSI_0 , PSI_1 , H_PSI_table , inter_data , TBMEs_pn);

      if (H_potential != WS) Coulomb_one_body_calc_print (input_data , inter_data , PSI_full , J , PSI , PSI_0 , PSI_1 , H_PSI_table , TBMEs_pn);

      Coulomb_two_body_calc_print (input_data , Jc_relative_max , PSI_full , J , PSI , inter_data , PSI_0 , PSI_1 , H_PSI_table , TBMEs_pn);

      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << endl;
    }
}


