#include "../GSM_include/GSM_include_def.h"

using namespace string_routines;
using namespace correlated_state_routines;

// MPI transfer is done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

// TYPE is double or complex
// -------------------------


// Calculation of spectroscopic factor 
// -----------------------------------
// See called routines for details in GSM_spectroscopic_factor_...cpp files.

TYPE spectroscopic_factor::calc (
				 const bool full_common_vectors_used_in_file ,
				 const enum spectroscopic_factor_type SF , 
				 const enum nucleus_type nucleus , 
				 const int NCM_HO_max_projectile , 
				 const class ljm_struct &LJM_projectile , 
				 const class correlated_state_str &PSI_IN_qn , 
				 const class correlated_state_str &PSI_OUT_qn , 
				 const class correlated_state_str &PSI_projectile_qn ,  
				 const class GSM_vector &PSI_OUT)
{
  switch (nucleus)
    {
    case CLUSTER:
      {
	switch (SF)
	  {
	  case STRIPPING: return cluster::stripping_calc (full_common_vectors_used_in_file , NCM_HO_max_projectile , LJM_projectile , PSI_IN_qn , PSI_OUT_qn , PSI_projectile_qn , PSI_OUT);
	  case PICK_UP:   return cluster::pick_up_calc   (full_common_vectors_used_in_file , NCM_HO_max_projectile , LJM_projectile , PSI_IN_qn , PSI_OUT_qn , PSI_projectile_qn , PSI_OUT);

	  default: break;
	  }

	break;
      }

    case NUCLEUS:
      {
	const double M_projectile = LJM_projectile.get_m ();
	
	switch (SF)
	  {
	  case STRIPPING: return nucleus::stripping_calc (full_common_vectors_used_in_file , PSI_IN_qn , PSI_OUT_qn , PSI_projectile_qn , M_projectile , PSI_OUT);
	  case PICK_UP:   return nucleus::pick_up_calc   (full_common_vectors_used_in_file , PSI_IN_qn , PSI_OUT_qn , PSI_projectile_qn , M_projectile , PSI_OUT);

	  default: break;
	  }

	break;
      }

    case ONE_NUCLEON:
      {
	switch (SF)
	  {
	  case STRIPPING: return one_baryon::stripping_calc (full_common_vectors_used_in_file , LJM_projectile , PSI_IN_qn , PSI_OUT_qn , PSI_OUT);
	  case PICK_UP:   return one_baryon::pick_up_calc   (full_common_vectors_used_in_file , LJM_projectile , PSI_IN_qn , PSI_OUT_qn , PSI_OUT);

	  default: break;
	  }

	break;
      }

    case ONE_HYPERON:
      {
	switch (SF)
	  {
	  case STRIPPING: return one_baryon::stripping_calc (full_common_vectors_used_in_file , LJM_projectile , PSI_IN_qn , PSI_OUT_qn , PSI_OUT);
	  case PICK_UP:   return one_baryon::pick_up_calc   (full_common_vectors_used_in_file , LJM_projectile , PSI_IN_qn , PSI_OUT_qn , PSI_OUT);

	  default: break;
	  }

	break;
      }

    default: break;
    }

  abort_all ();

  return NADA;
}




// Calculation and print of all spectroscopic factors demanded in the input file
// -----------------------------------------------------------------------------
// Eigenvectors are read from disk and spectroscopic factors are calculated, to be printed on screen afterwards.
// See called routines for details in GSM_spectroscopic_factor_...cpp files.
// One calls the nucleon projectile here, even though it is called ejectile afterwards for pick-up reactions.
//
// Printed result looks like: Spectroscopic factor 0+(0) + p3/2 neutron --> 3/2-(0)  (0.85 , -0.01) for nucleon
//                            Spectroscopic factor 0+(0) + 3S1 deuteron.S1.T0 --> 1+(0)  (0.85 , -0.01) for cluster
//                            Spectroscopic factor 0+(0) + Z(projectile)=0 N(projectile)=3 3/2-(0) --> 3/2-(0)  (0.85 , -0.01) for nucleus
//

void spectroscopic_factor::calc_print (
				       const class input_data_str &input_data , 
				       const class array<class correlated_state_str> &PSI_qn_tab ,
				       class baryons_data &prot_Y_data , 				 
				       class baryons_data &neut_Y_data) 
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Spectroscopic factors" << endl;
      cout <<         "---------------------" << endl << endl;
    }

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int Z_OUT = prot_Y_data.get_N_nucleons ();
  const int N_OUT = neut_Y_data.get_N_nucleons ();
  
  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();

  const unsigned int S_OUT = input_data.get_hypernucleus_strangeness ();
  
  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
  
  const unsigned int spectroscopic_factor_number = input_data.get_spectroscopic_factor_number ();

  const class array<enum spectroscopic_factor_type> &spectroscopic_factor_type_tab = input_data.get_spectroscopic_factor_type_tab ();

  const class array<enum nucleus_type> &spectroscopic_factor_nucleus_projectile_tab = input_data.get_spectroscopic_factor_nucleus_projectile_tab ();

  const class array<enum particle_type> &spectroscopic_factor_cluster_projectile_tab = input_data.get_spectroscopic_factor_cluster_projectile_tab ();

  const class array<int> &spectroscopic_factor_Z_projectile_tab = input_data.get_spectroscopic_factor_Z_projectile_tab ();
  const class array<int> &spectroscopic_factor_N_projectile_tab = input_data.get_spectroscopic_factor_N_projectile_tab ();

  const class array<int> &spectroscopic_factor_LCM_projectile_tab = input_data.get_spectroscopic_factor_LCM_projectile_tab ();

  const class array<int> &spectroscopic_factor_NCM_HO_max_projectile_tab = input_data.get_spectroscopic_factor_NCM_HO_max_projectile_tab ();

  const class array<unsigned int> &spectroscopic_factor_BP_IN_tab  = input_data.get_spectroscopic_factor_BP_IN_tab ();
  const class array<unsigned int> &spectroscopic_factor_BP_OUT_tab = input_data.get_spectroscopic_factor_BP_OUT_tab ();

  const class array<unsigned int> &spectroscopic_factor_BP_projectile_tab = input_data.get_spectroscopic_factor_BP_projectile_tab ();

  const class array<double> &spectroscopic_factor_J_IN_tab  = input_data.get_spectroscopic_factor_J_IN_tab ();
  const class array<double> &spectroscopic_factor_J_OUT_tab = input_data.get_spectroscopic_factor_J_OUT_tab ();

  const class array<double> &spectroscopic_factor_J_projectile_tab = input_data.get_spectroscopic_factor_J_projectile_tab ();

  const class array<unsigned int> &spectroscopic_factor_vector_index_IN_tab  = input_data.get_spectroscopic_factor_vector_index_IN_tab ();
  const class array<unsigned int> &spectroscopic_factor_vector_index_OUT_tab = input_data.get_spectroscopic_factor_vector_index_OUT_tab (); 

  const class array<unsigned int> &spectroscopic_factor_vector_index_projectile_tab = input_data.get_spectroscopic_factor_vector_index_projectile_tab ();
  
  for (unsigned int SF_index = 0 ; SF_index < spectroscopic_factor_number ; SF_index++)
    {
      const enum spectroscopic_factor_type SF = spectroscopic_factor_type_tab(SF_index);

      const enum particle_type cluster = spectroscopic_factor_cluster_projectile_tab(SF_index);

      const enum nucleus_type nucleus = spectroscopic_factor_nucleus_projectile_tab(SF_index);

      const int Z_projectile = spectroscopic_factor_Z_projectile_tab(SF_index);
      const int N_projectile = spectroscopic_factor_N_projectile_tab(SF_index);
	    
      const int LCM_projectile = spectroscopic_factor_LCM_projectile_tab(SF_index);

      const int NCM_HO_max_projectile = spectroscopic_factor_NCM_HO_max_projectile_tab(SF_index);

      const unsigned int BP_IN  = spectroscopic_factor_BP_IN_tab(SF_index);
      const unsigned int BP_OUT = spectroscopic_factor_BP_OUT_tab(SF_index);

      const unsigned int BP_projectile = spectroscopic_factor_BP_projectile_tab(SF_index);
      
      const int S_projectile = particle_strangeness_determine (cluster);

      const double J_projectile = spectroscopic_factor_J_projectile_tab(SF_index);
      
      const unsigned int vector_index_projectile = spectroscopic_factor_vector_index_projectile_tab(SF_index);
      
      const unsigned int S_IN = (SF == STRIPPING) ? (S_OUT - S_projectile) : (S_OUT + S_projectile);
      
      const unsigned int vector_index_IN  = spectroscopic_factor_vector_index_IN_tab(SF_index);
      const unsigned int vector_index_OUT = spectroscopic_factor_vector_index_OUT_tab(SF_index);

      const double J_IN  = spectroscopic_factor_J_IN_tab(SF_index);
      const double J_OUT = spectroscopic_factor_J_OUT_tab(SF_index);

      const double M_IN  = J_IN;
      const double M_OUT = J_OUT;

      const double M_projectile = spectroscopic_factor_cluster_m_projection_calc (SF , M_IN , M_OUT);

      const class ljm_struct LJM_projectile(cluster , LCM_projectile , J_projectile , M_projectile , NADA);

      const int Z_IN = N_baryons_IN_spectroscopic_factor_determine (Z_OUT , Z_projectile , SF);
      const int N_IN = N_baryons_IN_spectroscopic_factor_determine (N_OUT , N_projectile , SF);

      const class correlated_state_str PSI_IN_qn(Z_IN , N_IN , BP_IN , S_IN , J_IN , vector_index_IN , NADA , NADA , NADA , NADA , false);

      const class correlated_state_str PSI_OUT_qn = PSI_quantum_numbers_find (Z_OUT , N_OUT , BP_OUT , S_OUT , J_OUT , vector_index_OUT , PSI_qn_tab);

      const class correlated_state_str PSI_projectile_qn(Z_projectile , N_projectile , BP_projectile , S_projectile , J_projectile , vector_index_projectile , NADA , NADA , NADA , NADA , false);

      class GSM_vector_helper_class PSI_OUT_helper(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
						   n_holes_max   , n_scat_max   , E_max_hw  ,
						   n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						   n_holes_max_n , n_scat_max_n , En_max_hw , BP_OUT , M_OUT , false , prot_Y_data , neut_Y_data);

      class GSM_vector PSI_OUT(PSI_OUT_helper);
      
      PSI_OUT.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_OUT_qn);
      
      const TYPE spectroscopic_factor_value = calc (full_common_vectors_used_in_file , SF , nucleus , NCM_HO_max_projectile , LJM_projectile ,
						    PSI_IN_qn , PSI_OUT_qn , PSI_projectile_qn , PSI_OUT);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  switch (SF)
	    {
	    case STRIPPING: cout << "Spectroscopic factor " << J_Pi_vector_index_string (BP_IN , J_IN , vector_index_IN) << " + "; break;
	    case PICK_UP:   cout << "Spectroscopic factor " << J_Pi_vector_index_string (BP_IN , J_IN , vector_index_IN) << " - "; break;

	    default: abort_all ();
	    }

	  if (nucleus == NUCLEUS)
	    cout << "Z(projectile)=" << Z_projectile <<" N(projectile)=" << N_projectile << " " << J_Pi_vector_index_string (BP_projectile , J_projectile , vector_index_projectile) << " --> ";
	  else
	    cout << angular_state_cluster (cluster , LCM_projectile , J_projectile) << " " << cluster << " --> ";

	  cout << J_Pi_vector_index_string (BP_OUT , J_OUT , vector_index_OUT) << " : " << spectroscopic_factor_value << endl << endl;
	}
    }
}


