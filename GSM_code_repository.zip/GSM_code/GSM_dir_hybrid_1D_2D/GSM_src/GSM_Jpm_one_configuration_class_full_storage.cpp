#include "../GSM_include/GSM_include_def.h"

using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling::out_to_in;

// TYPE is double or complex
// -------------------------


// OBMEs means one-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons
// ------------------------------------------------------------------------------------------------------------------------------------------------------



// Storage of non-zero NBMEs of Jpm wih full storage and application of Jpm times vector when only one configuration is occupied in basis space for MSDHF calculations
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------
// In order to calculate the MSDHF potential, one has to diagonalize H on the MSDHF configuration, as its ground state is used in the HF-like formulas defining the MSDHF potential.
// The J^2 operator when only one configuration is occupied is also used, to check if GSM vectors are coupled to J and to project them on good J.
// As only one configuration occurs, it is much more efficient to recode J^2 in this particular case, than to use the full J^2 class of the general case.
//
// Jpm means J+ or J-, as pm = +/1. One uses Jpm for J+ or J- in all Jpm classes files.
// One uses Jpm in J^2 = J-.J+ + Jz.(Jz + 1).
//
// Non-zero NBMEs of Jpm are calculated and stored therein. Array dimensions have been calculated in GSM_H_class_non_zero_NBMEs_numbers.cpp .
//
// One calculates non-zero NBMEs occurring in one node only as they are not used in other nodes due to Hamiltonian 1D partitioning (see GSM_vector.cpp).
//
// One loops over proton and neutron Slater determinants, the first loop being proton or neutron according to the case.
//
// Jpm_part_one_jump_pp_nn_store
// -----------------------------
// This provides with non-zero off-diagonal NBMEs for 1p-1h jumps from a proton/neutron out Slater determinant to an in proton/neutron Slater determinant.
// Jumps have already been calculated at this level, so that one just has to loop over jumps.
// The index of the in Slater determinant and the associated NBME are then stored and added to Jpm arrays.
// 
// one_jump_p_part_pn_calc_full_storage, one_jump_n_part_pn_calc_full_storage
// --------------------------------------------------------------------------
// This provides with non-zero off-diagonal NBMEs of 1p-1h type from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// These routines are used when one has both valence protons and neutrons.
// In these routines, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the indices of the in Slater determinant and the associated NBMEs from them.
//
// pp_nn_calc_store
// ----------------
// This provides with the non-zero off-diagonal NBMEs for 1p-1h jumps from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// This routine is used when one has valence protons only or valence neutrons only.
// In this routine, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the number of non-zero NBMEs from them.
//
// matrix_store
// ------------
// This routine calls the previous routine and calculates and stores non-zero NBMEs for each row of Jpm for each node.




void Jpm_one_configuration_class::Jpm_part_one_jump_pp_nn_store (
								 const unsigned int PSI_out_index ,
								 const unsigned int dimension_one_jump , 
								 const class array<unsigned int> &PSI_in_indices ,
								 const class array<double> &NBMEs_one_jump)
{
  unsigned int &non_zero_NBMEs_index = rows_non_zero_NBMEs_numbers(PSI_out_index);
  
  const unsigned int row_non_zero_NBMEs_PSI_in_indices_zero_index = rows_non_zero_NBMEs_PSI_in_indices.index_determine (PSI_out_index , 0);
	      
  const unsigned int row_non_zero_NBMEs_zero_index = rows_non_zero_NBMEs.index_determine (PSI_out_index , 0);

  for (unsigned int i = 0 ; i < dimension_one_jump ; i++)
    {
      const unsigned int row_non_zero_NBMEs_PSI_in_indices_index = row_non_zero_NBMEs_PSI_in_indices_zero_index + non_zero_NBMEs_index;

      const unsigned int row_non_zero_NBMEs_index = row_non_zero_NBMEs_zero_index + non_zero_NBMEs_index;
		  
      const double NBME = NBMEs_one_jump(i);

      const unsigned int PSI_in_index = PSI_in_indices(i);
	  		  
      rows_non_zero_NBMEs_PSI_in_indices[row_non_zero_NBMEs_PSI_in_indices_index] = PSI_in_index;

      rows_non_zero_NBMEs[row_non_zero_NBMEs_index] += NBME;

      non_zero_NBMEs_index++;
    }
}



void Jpm_one_configuration_class::one_jump_p_part_pn_calc_store ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_out.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();
  
  const unsigned int iM = GSM_vector_helper_out.get_iM ();
  
  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const int iMp_min_M = GSM_vector_helper_out.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper_out.get_iMp_max_M ();
  
  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions_in  = GSM_vector_helper_in.get_sum_dimensions_GSM_vector (); 
  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const unsigned int BPp = prot_Y_data.get_BP_one_configuration ();
  const unsigned int BPn = neut_Y_data.get_BP_one_configuration ();
  
  const unsigned int iCp = prot_Y_data.get_iC_one_configuration (); 
  const unsigned int iCn = neut_Y_data.get_iC_one_configuration ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  class jumps_data_out_to_in_str one_jump_p(ONE_JUMP_ONE_CONFIGURATION , PROT_NEUT_Y , true , true , ZYval);
  
  class array<double> NBMEs_one_jump_p(ZYval);
      
  class array<unsigned int> PSI_in_indices(ZYval);
  
  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
    {
      const int iMp_mp_one = iMp - pm;

      const int iMn = iM - iMp;

      if ((iMp_mp_one < 0) || (iMp_mp_one > iMp_max)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , 0 , 0 , 0 , iCp , iMp);
      
      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , 0 , 0 , 0 , iCn , iMn);

      if ((dimension_outSDp == 0) || (dimension_SDn == 0)) continue;

      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_in(iMp_mp_one);
      
      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_out(iMp);
      
      for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
	{
	  one_jump_p.one_jump_mu_Jpm_store (pm , BPp , 0 , 0 , 0 , iCp , iMp , outSDp_index , prot_Y_data);
	  
	  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();

	  if (dimension_one_jump_p == 0) continue;
	  
	  NBMEs_one_jump_mu_calc_one_body_operator_Jpm (Jpm_OBMEs_p_tab , one_jump_p , NBMEs_one_jump_p);

	  const unsigned int PSI_out_zero_index_outSDp = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_SDn*outSDp_index;
	      
	  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
	    {
	      const unsigned int PSI_out_index = PSI_out_zero_index_outSDp + SDn_index;

	      bool is_there_jump_calc = false;
  
	      PSI_in_indices_p_fill_Jpm (SDn_index , sum_dimensions_configuration_Mp_Mn_fixed_in , one_jump_p , GSM_vector_helper_in , dimension_SDn , PSI_in_indices , is_there_jump_calc);
	  
	      if (is_there_jump_calc) Jpm_part_one_jump_pp_nn_store (PSI_out_index , dimension_one_jump_p , PSI_in_indices , NBMEs_one_jump_p);
	    }
	}
    }
}





void Jpm_one_configuration_class::one_jump_n_part_pn_calc_store ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_out.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();
  
  const unsigned int iM = GSM_vector_helper_out.get_iM ();
  
  const int iMn_max = neut_Y_data.get_iM_max (); 

  const int iMn_min_M = GSM_vector_helper_out.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper_out.get_iMn_max_M ();
  
  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions_in  = GSM_vector_helper_in.get_sum_dimensions_GSM_vector (); 
  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const unsigned int BPp = prot_Y_data.get_BP_one_configuration (); 
  const unsigned int BPn = neut_Y_data.get_BP_one_configuration ();
  
  const unsigned int iCp = prot_Y_data.get_iC_one_configuration (); 
  const unsigned int iCn = neut_Y_data.get_iC_one_configuration ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  class jumps_data_out_to_in_str one_jump_n(ONE_JUMP_ONE_CONFIGURATION , PROT_NEUT_Y , true , true , NYval);
  
  class array<double> NBMEs_one_jump_n(NYval);
      
  class array<unsigned int> PSI_in_indices(NYval);
  
  for (int iMn = iMn_min_M ; iMn <= iMn_max_M ; iMn++)
    {
      const int iMn_mp_one = iMn - pm;

      const int iMp = iM - iMn;
      
      if ((iMn_mp_one < 0) || (iMn_mp_one > iMn_max)) continue;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , 0 , 0 , 0 , iCp , iMp);
      
      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , 0 , 0 , 0 , iCn , iMn);
      
      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn , 0 , 0 , 0 , iCn , iMn_mp_one);
      
      if ((dimension_SDp == 0) || (dimension_outSDn == 0) || (dimension_inSDn == 0)) continue;

      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_in(iMp);
      
      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_out(iMp);
      
      for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
	{
	  one_jump_n.one_jump_mu_Jpm_store (pm , BPn , 0 , 0 , 0 , iCn , iMn , outSDn_index , neut_Y_data);

	  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
	  
	  if (dimension_one_jump_n == 0) continue;
	  
	  NBMEs_one_jump_mu_calc_one_body_operator_Jpm (Jpm_OBMEs_n_tab , one_jump_n , NBMEs_one_jump_n);

	  const unsigned int PSI_out_zero_index_outSDn = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
	      
	  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
	    {  
	      const unsigned int PSI_out_index = PSI_out_zero_index_outSDn + dimension_outSDn*SDp_index;
	      	      
	      bool is_there_jump_calc = false;
	      
	      PSI_in_indices_n_fill_Jpm (SDp_index , sum_dimensions_configuration_Mp_Mn_fixed_in , dimension_inSDn , one_jump_n , GSM_vector_helper_in , PSI_in_indices , is_there_jump_calc);

	      if (is_there_jump_calc) Jpm_part_one_jump_pp_nn_store (PSI_out_index , dimension_one_jump_n , PSI_in_indices , NBMEs_one_jump_n);
	    }
	}
    }
}




void Jpm_one_configuration_class::pp_nn_calc_store ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  const enum space_type space = GSM_vector_helper_out.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_out.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();
  
  const unsigned int iM = GSM_vector_helper_out.get_iM ();
  
  const class array<double> &Jpm_mu_tab = (space == PROT_Y_ONLY) ? (Jpm_OBMEs_p_tab) : (Jpm_OBMEs_n_tab);
    
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  const unsigned int BP = data.get_BP_one_configuration ();
  const unsigned int iC = data.get_iC_one_configuration ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const unsigned int dimension_SD_set = dimensions_SD_set(BP , 0 , 0 , 0 , iC , iM);

  class jumps_data_out_to_in_str one_jump_mu(ONE_JUMP_ONE_CONFIGURATION , space , true , true , N_valence_baryons);

  class array<double> NBMEs_one_jump_mu(N_valence_baryons);
  
  class array<unsigned int> PSI_in_indices(N_valence_baryons);
  
  for (unsigned int outSD_index = 0 ; outSD_index < dimension_SD_set ; outSD_index++)
    {	
      one_jump_mu.one_jump_mu_Jpm_store (pm , BP , 0 , 0 , 0 , iC , iM , outSD_index , data);
      
      const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();

      if (dimension_one_jump_mu == 0) continue;
      
      NBMEs_one_jump_mu_calc_one_body_operator_Jpm (Jpm_mu_tab , one_jump_mu , NBMEs_one_jump_mu);
            
      bool is_there_jump_calc = false;
      
      PSI_in_indices_pp_nn_fill_Jpm (0 , one_jump_mu , GSM_vector_helper_in , PSI_in_indices , is_there_jump_calc);

      if (is_there_jump_calc) Jpm_part_one_jump_pp_nn_store (outSD_index , dimension_one_jump_mu , PSI_in_indices , NBMEs_one_jump_mu);
    }
}




void Jpm_one_configuration_class::matrix_store ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();

  const unsigned int space_dimension_out = GSM_vector_helper_out.get_space_dimension ();
  
  const enum space_type space = GSM_vector_helper_out.get_space ();

  rows_non_zero_NBMEs_numbers = 0;
  
  rows_non_zero_NBMEs_PSI_in_indices = space_dimension_out;
  
  rows_non_zero_NBMEs = 0.0;
    
  if (space == PROT_NEUT_Y)
    {
      one_jump_p_part_pn_calc_store ();
      one_jump_n_part_pn_calc_store ();
    }
  else
    pp_nn_calc_store ();
}






void Jpm_one_configuration_class::apply_add (
					     const class GSM_vector_one_configuration &PSI_in , 
					     class GSM_vector_one_configuration &PSI_out) const
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  if (!PSI_in.same_parity_M_projection (GSM_vector_helper_in)) return;
  if (!PSI_out.same_parity_M_projection (GSM_vector_helper_out)) return;
  
  const unsigned int BP_in  = GSM_vector_helper_in.get_BP ();
  const unsigned int BP_out = GSM_vector_helper_out.get_BP ();

  if (BP_out != BP_in) return;
  
  const int iM_in  = GSM_vector_helper_in.get_iM ();
  const int iM_out = GSM_vector_helper_out.get_iM ();
  
  if (iM_out != iM_in + pm) return;
  
  const unsigned int space_dimension_out = GSM_vector_helper_out.get_space_dimension ();
  
  for (unsigned int PSI_out_index = 0 ; PSI_out_index < space_dimension_out ; PSI_out_index++)
    {
      const unsigned int row_non_zero_NBMEs_number = rows_non_zero_NBMEs_numbers(PSI_out_index);

      const unsigned int row_non_zero_NBMEs_PSI_in_indices_zero_index = rows_non_zero_NBMEs_PSI_in_indices.index_determine (PSI_out_index , 0);
      
      const unsigned int row_non_zero_NBMEs_zero_index = rows_non_zero_NBMEs.index_determine (PSI_out_index , 0);

      TYPE PSI_out_component = 0.0;

      for (unsigned int i = 0 ; i < row_non_zero_NBMEs_number ; i++)
	{
	  const unsigned int row_non_zero_NBMEs_PSI_in_indices_index = row_non_zero_NBMEs_PSI_in_indices_zero_index + i;

	  const unsigned int row_non_zero_NBMEs_index = row_non_zero_NBMEs_zero_index + i;
	  
	  const unsigned int PSI_in_index = rows_non_zero_NBMEs_PSI_in_indices[row_non_zero_NBMEs_PSI_in_indices_index];

	  const TYPE &PSI_in_component = PSI_in[PSI_in_index];
	    
	  const double &NBME = rows_non_zero_NBMEs[row_non_zero_NBMEs_index];

	  PSI_out_component += NBME*PSI_in_component;
	}

      PSI_out[PSI_out_index] += PSI_out_component;
    }
}
