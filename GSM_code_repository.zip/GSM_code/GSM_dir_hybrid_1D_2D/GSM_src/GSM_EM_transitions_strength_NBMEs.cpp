#include "../GSM_include/GSM_include_def.h"

using namespace EM_transitions_common;
using namespace EM_transitions_NBMEs;

using namespace EM_transitions_strength_OBMEs;


// TYPE is double or complex
// -------------------------

// EM means electromagnetic
// ------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons
// ------------------------------------------------------------------------------------------------------------------------------------------------------


// Calculation of the radial array of the EM transition strength matrix elements <Psi[out] | Op | Psi[in]> for a given EM suboperator or for the full EM transition
// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
// EM transitions strengths (i.e. a as function of r, not integrated) are functions of several operators.
// One can consider a single operator here, such as charge, current for electric transition, or orbital, spin part for magnetic transition (routines EM_suboperator....)
//
// The full EM transition operator is considered in routines B_amplitude... .
//
// Reduced EM transition matrix elements are calculated first, and dereduced afterwards.
//
// The strength function is stored in B_amplitude_tab for full EM transition operator or EM_suboperator_B_amplitude_tab for  a given EM suboperator.

void EM_transitions_strength_NBMEs::B_amplitude_pp_nn_tab_calc (
								const enum EM_type EM , 
								const TYPE &q , 
								const int L , 
								const int Lc , 
								const bool is_it_longwavelength_approximation , 
								const bool is_it_Gauss_Legendre , 
								class GSM_vector &PSI_full ,
								const double J_IN , 
								const class GSM_vector &PSI_IN , 
								const double J_OUT , 
								const class GSM_vector &PSI_OUT , 
								class array<TYPE> &B_amplitude_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_IN = PSI_IN.get_GSM_vector_helper ();
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_IN.get_space ();

  const class nucleons_data &prot_data = GSM_vector_helper_IN.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_IN.get_neut_data ();

  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);
  
  const int iM_IN  = GSM_vector_helper_IN.get_iM ();
  const int iM_OUT = GSM_vector_helper_OUT.get_iM ();

  const int ML = iM_OUT - iM_IN;

  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL ();
  const unsigned int N_bef_R_uniform = data.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const class array<TYPE> dummy_OBMEs;
  
  const unsigned int BP_Op = BP_EM_determine (EM , L);

  const unsigned int N_nljm = data.get_N_nljm ();

  class array<TYPE> OBMEs(N_nljm , N_nljm , Nr);

  class array<TYPE> OBMEs_part(N_nljm , N_nljm);

  OBMEs_calc (EM , q , L , ML , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , data , OBMEs);

  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      for (unsigned int in = 0 ; in < N_nljm ; in++)
	for (unsigned int out = 0 ; out < N_nljm ; out++)
	  OBMEs_part(in , out) = OBMEs(in , out , i);

      B_amplitude_tab(i) = (space == PROTONS_ONLY)
	? (B_EM_amplitude_from_OBMEs_calc (PSI_full , L , BP_Op , OBMEs_part , dummy_OBMEs , J_IN , PSI_IN , J_OUT , PSI_OUT))
	: (B_EM_amplitude_from_OBMEs_calc (PSI_full , L , BP_Op , dummy_OBMEs , OBMEs_part , J_IN , PSI_IN , J_OUT , PSI_OUT));
    }
}

void EM_transitions_strength_NBMEs::B_amplitude_pn_tab_calc (
							     const enum EM_type EM , 
							     const TYPE &q , 
							     const int L , 
							     const int Lc , 
							     const bool is_it_longwavelength_approximation , 
							     const bool is_it_Gauss_Legendre , 
							     class GSM_vector &PSI_full ,
							     const double J_IN , 
							     const class GSM_vector &PSI_IN , 
							     const double J_OUT , 
							     const class GSM_vector &PSI_OUT , 
							     class array<TYPE> &B_amplitude_tab)
{
  const unsigned int BP_Op = BP_EM_determine (EM , L);

  const class GSM_vector_helper_class &GSM_vector_helper_IN = PSI_IN.get_GSM_vector_helper ();
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_IN.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_IN.get_neut_data ();

  const int iM_IN  = GSM_vector_helper_IN.get_iM ();
  const int iM_OUT = GSM_vector_helper_OUT.get_iM ();

  const int ML = iM_OUT - iM_IN;

  const unsigned int N_bef_R_GL = prot_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = prot_data.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const unsigned int Np_nljm = prot_data.get_N_nljm ();
  const unsigned int Nn_nljm = neut_data.get_N_nljm ();

  class array<TYPE> OBMEs_p(Np_nljm , Np_nljm , Nr);
  class array<TYPE> OBMEs_n(Nn_nljm , Nn_nljm , Nr);

  class array<TYPE> OBMEs_p_part(Np_nljm , Np_nljm);
  class array<TYPE> OBMEs_n_part(Nn_nljm , Nn_nljm);

  OBMEs_calc (EM , q , L , ML , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , prot_data , OBMEs_p);
  OBMEs_calc (EM , q , L , ML , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , neut_data , OBMEs_n);

  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      for (unsigned int p_in = 0 ; p_in < Np_nljm ; p_in++)
	for (unsigned int p_out = 0 ; p_out < Np_nljm ; p_out++)
	  OBMEs_p_part(p_in , p_out) = OBMEs_p(p_in , p_out , i);

      for (unsigned int n_in = 0 ; n_in < Nn_nljm ; n_in++)
	for (unsigned int n_out = 0 ; n_out < Nn_nljm ; n_out++)
	  OBMEs_n_part(n_in , n_out) = OBMEs_n(n_in , n_out , i);

      B_amplitude_tab(i) = B_EM_amplitude_from_OBMEs_calc (PSI_full , L , BP_Op , OBMEs_p_part , OBMEs_n_part , J_IN , PSI_IN , J_OUT , PSI_OUT);
    }
}

void EM_transitions_strength_NBMEs::B_amplitude_tab_calc ( 
							  const enum EM_type EM , 
							  const TYPE &q , 
							  const int L , 
							  const int Lc , 
							  const bool is_it_longwavelength_approximation , 
							  const bool is_it_Gauss_Legendre , 
							  const enum space_type space ,
							  class GSM_vector &PSI_full ,
							  const double J_IN , 
							  const class GSM_vector &PSI_IN , 
							  const double J_OUT , 
							  const class GSM_vector &PSI_OUT , 
							  class array<TYPE> &B_amplitude_tab)
{
  switch (space)
    {
    case PROTONS_ONLY:  B_amplitude_pp_nn_tab_calc (EM , q , L , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , PSI_full , J_IN , PSI_IN , J_OUT , PSI_OUT , B_amplitude_tab); break;
    case NEUTRONS_ONLY: B_amplitude_pp_nn_tab_calc (EM , q , L , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , PSI_full , J_IN , PSI_IN , J_OUT , PSI_OUT , B_amplitude_tab); break;

    case PROTONS_NEUTRONS: B_amplitude_pn_tab_calc (EM , q , L , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , PSI_full , J_IN , PSI_IN , J_OUT , PSI_OUT , B_amplitude_tab); break;

    default: abort_all ();
    }
}

void EM_transitions_strength_NBMEs::EM_suboperator_B_amplitude_pp_nn_tab_calc (
									       const enum EM_suboperator_type EM_suboperator , 
									       const enum radial_operator_type radial_operator , 
									       const TYPE &q , 
									       const int L , 
									       const int Lc , 
									       const bool is_it_longwavelength_approximation , 
									       const bool is_it_Gauss_Legendre , 
									       class GSM_vector &PSI_full ,
									       const double J_IN , 
									       const class GSM_vector &PSI_IN , 
									       const double J_OUT , 
									       const class GSM_vector &PSI_OUT , 
									       class array<TYPE> &EM_suboperator_B_amplitude_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_IN = PSI_IN.get_GSM_vector_helper ();
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_IN.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_IN.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_IN.get_neut_data ();

  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);

  const int iM_IN  = GSM_vector_helper_IN.get_iM ();
  const int iM_OUT = GSM_vector_helper_OUT.get_iM ();

  const int ML = iM_OUT - iM_IN;

  const unsigned int N_bef_R_GL = prot_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = prot_data.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const class array<TYPE> dummy_OBMEs;
  
  const unsigned int BP_Op = BP_EM_suboperator_determine (EM_suboperator , L);

  const unsigned int N_nljm = data.get_N_nljm ();

  class array<TYPE> OBMEs(N_nljm , N_nljm , Nr);

  class array<TYPE> OBMEs_part(N_nljm , N_nljm);

  EM_suboperator_OBMEs_calc (EM_suboperator , radial_operator , q , L , ML , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , data , OBMEs);

  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      for (unsigned int in = 0 ; in < N_nljm ; in++)
	for (unsigned int out = 0 ; out < N_nljm ; out++)
	  OBMEs_part(in , out) = OBMEs(in , out , i);

      EM_suboperator_B_amplitude_tab(i) = (space == PROTONS_ONLY)
	? (B_EM_amplitude_from_OBMEs_calc (PSI_full , L , BP_Op , OBMEs_part , dummy_OBMEs , J_IN , PSI_IN , J_OUT , PSI_OUT))
	: (B_EM_amplitude_from_OBMEs_calc (PSI_full , L , BP_Op , dummy_OBMEs , OBMEs_part , J_IN , PSI_IN , J_OUT , PSI_OUT));
    }
}

void EM_transitions_strength_NBMEs::EM_suboperator_B_amplitude_pn_tab_calc (
									    const enum EM_suboperator_type EM_suboperator ,
									    const enum radial_operator_type radial_operator , 
									    const TYPE &q , 
									    const int L , 
									    const int Lc , 
									    const bool is_it_longwavelength_approximation ,  
									    const bool is_it_Gauss_Legendre ,  
									    class GSM_vector &PSI_full ,
									    const double J_IN , 
									    const class GSM_vector &PSI_IN , 
									    const double J_OUT , 
									    const class GSM_vector &PSI_OUT , 
									    class array<TYPE> &EM_suboperator_B_amplitude_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_IN = PSI_IN.get_GSM_vector_helper ();
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_IN.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_IN.get_neut_data ();

  const int iM_IN  = GSM_vector_helper_IN.get_iM ();
  const int iM_OUT = GSM_vector_helper_OUT.get_iM ();

  const int ML = iM_OUT - iM_IN;

  const unsigned int N_bef_R_GL = prot_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = prot_data.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const unsigned int Np_nljm = prot_data.get_N_nljm ();
  const unsigned int Nn_nljm = neut_data.get_N_nljm ();

  const unsigned int BP_Op = BP_EM_suboperator_determine (EM_suboperator , L);

  class array<TYPE> OBMEs_p(Np_nljm , Np_nljm , Nr);
  class array<TYPE> OBMEs_n(Nn_nljm , Nn_nljm , Nr);

  class array<TYPE> OBMEs_p_part(Np_nljm , Np_nljm);
  class array<TYPE> OBMEs_n_part(Nn_nljm , Nn_nljm);

  EM_suboperator_OBMEs_calc (EM_suboperator , radial_operator , q , L , ML , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , prot_data , OBMEs_p);
  EM_suboperator_OBMEs_calc (EM_suboperator , radial_operator , q , L , ML , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , neut_data , OBMEs_n);

  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      for (unsigned int p_in = 0 ; p_in < Np_nljm ; p_in++)
	for (unsigned int p_out = 0 ; p_out < Np_nljm ; p_out++)
	  OBMEs_p_part(p_in , p_out) = OBMEs_p(p_in , p_out , i);

      for (unsigned int n_in = 0 ; n_in < Nn_nljm ; n_in++)
	for (unsigned int n_out = 0 ; n_out < Nn_nljm ; n_out++)
	  OBMEs_n_part(n_in , n_out) = OBMEs_n(n_in , n_out , i);

      EM_suboperator_B_amplitude_tab(i) = B_EM_amplitude_from_OBMEs_calc (PSI_full , L , BP_Op , OBMEs_p_part , OBMEs_n_part , J_IN , PSI_IN , J_OUT , PSI_OUT);
    }
}

void EM_transitions_strength_NBMEs::EM_suboperator_B_amplitude_tab_calc (	 
									 const enum EM_suboperator_type EM_suboperator ,
									 const enum radial_operator_type radial_operator , 
									 const TYPE &q , 
									 const int L , 
									 const int Lc , 
									 const bool is_it_longwavelength_approximation , 
									 const bool is_it_Gauss_Legendre ,  
									 class GSM_vector &PSI_full ,
									 const double J_IN , 
									 const class GSM_vector &PSI_IN , 
									 const double J_OUT , 
									 const class GSM_vector &PSI_OUT , 
									 class array<TYPE> &EM_suboperator_B_amplitude_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();

  switch (space)
    {
    case PROTONS_ONLY: EM_suboperator_B_amplitude_pp_nn_tab_calc (EM_suboperator , radial_operator , q , L , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , PSI_full ,
								  J_IN , PSI_IN , J_OUT , PSI_OUT , EM_suboperator_B_amplitude_tab); break;

    case NEUTRONS_ONLY: EM_suboperator_B_amplitude_pp_nn_tab_calc (EM_suboperator , radial_operator , q , L , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , PSI_full ,
								   J_IN , PSI_IN , J_OUT , PSI_OUT , EM_suboperator_B_amplitude_tab); break;

    case PROTONS_NEUTRONS: EM_suboperator_B_amplitude_pn_tab_calc (EM_suboperator , radial_operator , q , L , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , PSI_full ,
								   J_IN , PSI_IN , J_OUT , PSI_OUT , EM_suboperator_B_amplitude_tab); break;

    default: abort_all ();
    }
}









