#include "../GSM_include/GSM_include_def.h"

using namespace HF_potentials_common::SGI_MSGI_part_common;


// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------




// Calculation of the MSDHF potential OBMEs taking into account one occupied state for the pp, nn and pn parts 
// -----------------------------------------------------------------------------------------------------------
// The equivalent MSDHF potential U[MSDHF] = U[MSDHF](dir) - U[MSDHF](exc) OBMEs write for MSGI:
//
// <b | U[MSDHF](dir) |a> = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ |\sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . \int u_a(r)   u_b(r) F_Gaussian(r) dr \int u_occ(r')^2         F_Gaussian(r') dr'
// <b | U[MSDHF](exc) |a> = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ |\sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . \int u_occ(r) u_b(r) F_Gaussian(r) dr \int u_a(r') u_occ^2(r') F_Gaussian(r') dr'
//
// The equivalent MSDHF potential U[MSDHF] = U[MSDHF](dir) - U[MSDHF](exc) OBMEs write for SGI:
//
// <b | U[MSDHF](dir) |a> = \sum_{J, s_occ , l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . \int u_a(r) u_b(r) u_occ^2(2R0-r) Vl'_SGI(r) dr
// <b | U[MSDHF](exc) |a> = \sum_{J, s_occ , l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . \int u_a(r) u_b(2R0-r) u_occ(r) u_occ(2R0-r) Vl'_SGI(r) dr
//
// where weight is function of Clebsch-Gordan coefficients and of the SD components of the GSM ground state on the optimized configuration (see GSM_MSDHF_potentials_SGI_MSGI_part.cpp).
// coupling_constant(Pi,J) is the Pi-J-dependent coupling constant of the SGI/MSGI interaction and
// F_Gaussian(r) is the Gaussian form factor entering the MSGI interaction (see GSM_TBME_MSGI.cpp) and
// Vl'_SGI(r) is the multipolar expansion of the SGI interaction (see GSM_interaction_class.cpp) and R0 is the radius of the SGI/MSGI interaction.
//
// The real part of the equivalent MSDHF potential is considered for the MSDHF potential when it is complex.
//
// The occupied state is fixed in the subpart of the one-body matrix element of the MSDHF potential.
//
//
// If one uses holes, there is an additional double-counting potential term  <b | U[hole-double-counting] | a> term to remove (see GSM_hole_double_counting.cpp).
// The formula is: < b | U[hole-double-counting] | a > = \sum_{holes,J'} (2J' + 1)/(2j + 1) <b wf[hole] | V | a wf[hole]>_J,
// which is removed from the MSDHF potential. There is no 1p-1h term, as it is diagonal only, so that it cannot enter HF or MSDHF potentials.

complex<double> MSDHF_potentials::SGI_MSGI_OBMEs::prot_OBME_HF_pp_subpart_calc (
										  const class spherical_state &shell_p_in , 
										  const class spherical_state &shell_p_out , 
										  const class spherical_state &shell_p_occ , 
										  const double mp_in , 
										  const double mp_out , 
										  const double mp_occ_in , 
										  const double mp_occ_out , 
										  const complex<double> &SDs_weight , 
										  const class CG_str &CGs , 
										  const class interaction_class &inter_data , 
										  const class array<double> &Gaussian_table_GL , 
										  const class multipolar_expansion_str &multipolar_expansion)
{
  if (!same_lj_particle (shell_p_in , shell_p_out)) return 0.0;

  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);
  
  const int lp = shell_p_in.get_l ();

  const int lp_occ = shell_p_occ.get_l ();

  const int M = make_int (mp_in + mp_occ_in);

  const int abs_M = abs (M);

  const double jp = shell_p_in.get_j ();

  const double jp_occ = shell_p_occ.get_j ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (lp + lp_occ);
     
  const int Jmin = abs (make_int (jp - jp_occ));
  const int Jmax =      make_int (jp + jp_occ);

  complex<double> OBME_dir = 0.0;
  complex<double> OBME_exc = 0.0;

  for (int J = Jmin ; J <= Jmax ; J++)
    {
      if (abs_M <= J)
	{
	  const int lmax_multipole_expansion_dir = min (2*lp , 2*lp_occ);
	  
	  const int lmin_multipole_expansion_exc = abs (lp - lp_occ);
	  const int lmax_multipole_expansion_exc =      lp + lp_occ;

	  const double CG_in_dir = CGs(jp_occ , mp_occ_in , jp     , mp_in     , J , M);
	  const double CG_in_exc = CGs(jp     , mp_in     , jp_occ , mp_occ_in , J , M);

	  const double CG_out = CGs(jp_occ , mp_occ_out , jp , mp_out , J , M);

	  const complex<double> CG_out_SDs_weight = CG_out*SDs_weight;

	  const complex<double> CGs_SDs_weight_dir = CG_out_SDs_weight*CG_in_dir;
	  const complex<double> CGs_SDs_weight_exc = CG_out_SDs_weight*CG_in_exc;

	  complex<double> OBME_J_dir = 0.0;
	  complex<double> OBME_J_exc = 0.0;
	  
	  for (int ll = 0 ; ll <= lmax_multipole_expansion_dir ; ll++)
	    {
	      if (ll % 2 == 0)
		{
		  const double angular_part_dir = multipolar_expansion(lp , jp , lp_occ , jp_occ , lp , jp , lp_occ , jp_occ , ll , J);
		  
		  const complex<double> angular_part_CGs_SDs_weight_dir = angular_part_dir*CGs_SDs_weight_dir;

		  if (is_it_SGI) OBME_J_dir += SGI_part_common::OBME_nas_fixed_multipole_calc (inter_data , ll , true , angular_part_CGs_SDs_weight_dir , shell_p_occ , shell_p_in , shell_p_out);

		  if (is_it_MSGI) OBME_J_dir += angular_part_CGs_SDs_weight_dir;
		}
	    }
	  
	  for (int ll = lmin_multipole_expansion_exc ; ll <= lmax_multipole_expansion_exc ; ll++)
	    {
	      if ((lp + ll + lp_occ) % 2 == 0)
		{
		  const double angular_part_exc = multipolar_expansion(lp , jp , lp_occ , jp_occ , lp_occ , jp_occ , lp , jp , ll , J);
		  
		  const complex<double> angular_part_CGs_SDs_weight_exc = angular_part_exc*CGs_SDs_weight_exc;

		  if (is_it_SGI) OBME_J_exc += SGI_part_common::OBME_nas_fixed_multipole_calc (inter_data , ll , false , angular_part_CGs_SDs_weight_exc , shell_p_occ , shell_p_in , shell_p_out);

		  if (is_it_MSGI) OBME_J_exc += angular_part_CGs_SDs_weight_exc;
		}
	    }
	  
	  const double coupling_constant = inter_data.Gaussian_coupling_constant (bp , J , false , false);

	  OBME_J_dir *= coupling_constant , OBME_dir += OBME_J_dir;
	  OBME_J_exc *= coupling_constant , OBME_exc += OBME_J_exc;
	}
    }

  if (is_it_SGI) 
    {
      const complex<double> OBME = OBME_dir - OBME_exc;

      return OBME;
    }

  if (is_it_MSGI)
    {
      const complex<double> OBME = MSGI_part_common::total_OBME_calc (shell_p_in , shell_p_out , Gaussian_table_GL , OBME_dir , OBME_exc , shell_p_occ);

      return OBME;
    }

  return NADA;
}

complex<double> MSDHF_potentials::SGI_MSGI_OBMEs::prot_OBME_HF_pn_subpart_calc (
										  const class spherical_state &shell_p_in , 
										  const class spherical_state &shell_p_out , 
										  const class spherical_state &shell_n_occ , 
										  const double mp_in , 
										  const double mp_out , 
										  const double mn_occ_in , 
										  const double mn_occ_out , 
										  const complex<double> &SDs_weight , 
										  const class CG_str &CGs , 
										  const class interaction_class &inter_data , 
										  const class array<double> &Gaussian_table_GL , 
										  const class multipolar_expansion_str &multipolar_expansion)
{
  if (!same_lj_particle (shell_p_in , shell_p_out)) return 0.0;

  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const int lp = shell_p_in.get_l ();

  const int ln_occ = shell_n_occ.get_l ();

  const int M = make_int (mp_in + mn_occ_in);

  const int abs_M  = abs (M);

  const double jp = shell_p_in.get_j ();

  const double jn_occ = shell_n_occ.get_j ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (lp + ln_occ);
    
  const int Jmin = abs (make_int (jp - jn_occ));
  const int Jmax =      make_int (jp + jn_occ);

  complex<double> OBME_dir = 0.0;
  complex<double> OBME_exc = 0.0;

  for (int J = Jmin ; J <= Jmax ; J++)
    {
      if (abs_M <= J)
	{
	  const int lmax_multipole_expansion_dir = min (2*lp , 2*ln_occ);

	  const int lmin_multipole_expansion_exc = abs (lp - ln_occ);
	  const int lmax_multipole_expansion_exc =      lp + ln_occ;

	  const double CG_in_dir = CGs(jn_occ , mn_occ_in , jp     , mp_in     , J , M);
	  const double CG_in_exc = CGs(jp     , mp_in     , jn_occ , mn_occ_in , J , M);

	  const double CG_out = CGs(jn_occ , mn_occ_out , jp , mp_out , J , M);

	  const complex<double> CG_out_SDs_weight = CG_out*SDs_weight;
	  
	  const complex<double> CGs_SDs_weight_dir = CG_out_SDs_weight*CG_in_dir;
	  const complex<double> CGs_SDs_weight_exc = CG_out_SDs_weight*CG_in_exc;

	  complex<double> OBME_J_dir = 0.0;
	  complex<double> OBME_J_exc = 0.0;
	  
	  for (int ll = 0 ; ll <= lmax_multipole_expansion_dir ; ll++)
	    {
	      if (ll % 2 == 0)
		{
		  const double angular_part_dir = multipolar_expansion(lp , jp , ln_occ , jn_occ , lp , jp , ln_occ , jn_occ , ll , J);
		  
		  const complex<double> angular_part_CGs_SDs_weight_dir = angular_part_dir*CGs_SDs_weight_dir;

		  if (is_it_SGI) OBME_J_dir += SGI_part_common::OBME_nas_fixed_multipole_calc (inter_data , ll , true , angular_part_CGs_SDs_weight_dir , shell_n_occ , shell_p_in , shell_p_out);

		  if (is_it_MSGI) OBME_J_dir += angular_part_CGs_SDs_weight_dir;
		}
	    }
	  
	  for (int ll = lmin_multipole_expansion_exc ; ll <= lmax_multipole_expansion_exc ; ll++)
	    {
	      if ((lp + ll + ln_occ) % 2 == 0)
		{
		  const double angular_part_exc = multipolar_expansion(lp , jp , ln_occ , jn_occ , ln_occ , jn_occ , lp , jp , ll , J);
		  
		  const complex<double> angular_part_CGs_SDs_weight_exc = angular_part_exc*CGs_SDs_weight_exc;

		  if (is_it_SGI) OBME_J_exc += SGI_part_common::OBME_nas_fixed_multipole_calc (inter_data , ll , false , angular_part_CGs_SDs_weight_exc , shell_n_occ , shell_p_in , shell_p_out);

		  if (is_it_MSGI) OBME_J_exc += angular_part_CGs_SDs_weight_exc;
		}
	    }
	  
	  const double coupling_constant_dir = inter_data.Gaussian_coupling_constant (bp , J , true , false);
	  const double coupling_constant_exc = inter_data.Gaussian_coupling_constant (bp , J , false , true);

	  OBME_J_dir *= coupling_constant_dir , OBME_dir += OBME_J_dir;
	  OBME_J_exc *= coupling_constant_exc , OBME_exc += OBME_J_exc;
	}
    }

  if (is_it_SGI) 
    {
      const complex<double> OBME = OBME_dir - OBME_exc;

      return OBME;
    }

  if (is_it_MSGI)
    {
      const complex<double> OBME = MSGI_part_common::total_OBME_calc (shell_p_in , shell_p_out , Gaussian_table_GL , OBME_dir , OBME_exc , shell_n_occ);

      return OBME;
    }

  return NADA;
}

complex<double> MSDHF_potentials::SGI_MSGI_OBMEs::prot_OBME_HF_pp_part_calc (
									       const class spherical_state &shell_p_HF_in , 
									       const class spherical_state &shell_p_HF_out , 
									       const bool is_it_only_poles , 
									       const class CG_str &CGs , 
									       const class interaction_class &inter_data , 
									       const class array<double> &Gaussian_table_GL , 
									       const class multipolar_expansion_str &multipolar_expansion , 
									       const class baryons_data &prot_data_one_configuration_GSM , 
									       const class HF_nucleons_data &prot_HF_data)
{	
  const bool S_matrix_pole_in  = shell_p_HF_in.get_S_matrix_pole ();
  const bool S_matrix_pole_out = shell_p_HF_out.get_S_matrix_pole ();

  if (!same_lj_particle (shell_p_HF_in , shell_p_HF_out) || (is_it_only_poles && (!S_matrix_pole_in || !S_matrix_pole_out))) return 0.0;

  const int ZYval = prot_data_one_configuration_GSM.get_N_valence_nucleons_basis ();

  if (ZYval <= 1) return 0.0;

  const int ZYval_m1 = ZYval - 1;
  
  const class array<class nljm_struct> &phi_p_table = prot_data_one_configuration_GSM.get_phi_table ();

  const class array<class spherical_state> &shells_p = prot_data_one_configuration_GSM.get_shells ();
	
  const class lj_table<unsigned int> &dimensions_GS = prot_HF_data.get_dimensions_GS ();

  const class lj_table<complex<double> > &Up_HF_normalizing_sums = prot_HF_data.get_U_HF_normalizing_sums ();
  
  const class lj_table<class array<class Slater_determinant> > &SDp_tab_GS = prot_HF_data.get_SDp_tab_GS ();
  const class lj_table<class array<class Slater_determinant> > &SDn_tab_GS = prot_HF_data.get_SDn_tab_GS ();
  const class lj_table<class array<class Slater_determinant> > &SDp_tab_1h = prot_HF_data.get_SDs_1h ();

  const class lj_table<class array<complex<double> > > &SDs_GS_coefficients = prot_HF_data.get_SDs_GS_coefficients ();
  const class lj_table<class array<complex<double> > > &SDs_1h_coefficients = prot_HF_data.get_SDs_1h_coefficients ();

  const class lj_table<class array<bool> > &SDp_tab_1h_existence_tab = prot_HF_data.get_SDs_1h_existence_tab ();

  const double jp = shell_p_HF_in.get_j ();
  
  const int lp = shell_p_HF_in.get_l ();

  const int imp_number = make_int (2.0*jp + 1.0);

  const unsigned int dimension_GS = dimensions_GS(lp , jp);

  const complex<double> Up_HF_normalizing_sum = Up_HF_normalizing_sums(lp , jp);

  const class array<class Slater_determinant> &SDp_tab_GS_lj = SDp_tab_GS(lp , jp);
  const class array<class Slater_determinant> &SDn_tab_GS_lj = SDn_tab_GS(lp , jp);
  const class array<class Slater_determinant> &SDp_tab_1h_lj = SDp_tab_1h(lp , jp);

  const class array<complex<double> > &SDs_GS_coefficients_lj = SDs_GS_coefficients(lp , jp);
  const class array<complex<double> > &SDs_1h_coefficients_lj = SDs_1h_coefficients(lp , jp);

  const class array<bool> &SDp_tab_1h_existence_tab_lj = SDp_tab_1h_existence_tab(lp , jp);

  unsigned int p_jump_states_number_GS_in  = 0;
  unsigned int p_jump_states_number_1h_out = 0;

  class array<unsigned int> p_jump_states_GS_in(ZYval);
  class array<unsigned int> p_jump_states_1h_out(ZYval_m1);

  complex<double> prot_OBME_HF_pp_part = 0.0;
	
  for (unsigned int i_GS_in = 0 ; i_GS_in < dimension_GS ; i_GS_in++)
    {
      const complex<double> SD_GS_coefficient_in = SDs_GS_coefficients_lj(i_GS_in);

      if (SD_GS_coefficient_in == 0.0) continue;
			
      const class Slater_determinant &SDp_lj_GS_in = SDp_tab_GS_lj(i_GS_in);
      const class Slater_determinant &SDn_lj_GS_in = SDn_tab_GS_lj(i_GS_in);
			
      for (unsigned int i_GS_out = 0 ; i_GS_out < dimension_GS ; i_GS_out++)
	{
	  const class Slater_determinant &SDn_lj_GS_out = SDn_tab_GS_lj(i_GS_out);

	  if (SDn_lj_GS_in == SDn_lj_GS_out)
	    {
	      for (int imp_out = 0 ; imp_out < imp_number ; imp_out++)
		{
		  const bool SDp_lj_1h_out_exists = SDp_tab_1h_existence_tab_lj(i_GS_out , imp_out);

		  if (!SDp_lj_1h_out_exists) continue;

		  const complex<double> SD_1h_coefficient_out = SDs_1h_coefficients_lj(i_GS_out , imp_out);

		  if (SD_1h_coefficient_out == 0.0) continue;

		  const class Slater_determinant &SDp_lj_1h_out = SDp_tab_1h_lj(i_GS_out , imp_out);

		  SDp_lj_GS_in.different_states_determine (SDp_lj_1h_out , p_jump_states_number_GS_in , p_jump_states_GS_in);

		  if (p_jump_states_number_GS_in == 1)
		    {
		      const unsigned int p_jump_state = p_jump_states_GS_in(0);

		      const unsigned int p_jump_state_place = SDp_lj_GS_in.state_place_find (p_jump_state);

		      const int reordering_phase_p = minus_one_pow (p_jump_state_place + ZYval_m1);

		      const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase_p/Up_HF_normalizing_sum;

		      for (int p_occ = 0 ; p_occ < ZYval_m1 ; p_occ++)
			{
			  const unsigned int state_p_occ = SDp_lj_1h_out[p_occ];

			  const class nljm_struct &phi_p_occ = phi_p_table(state_p_occ);
			
			  const unsigned int sp_occ = phi_p_occ.get_shell_index ();

			  const class spherical_state &shell_p_occ = shells_p(sp_occ);

			  const double mp_occ = phi_p_occ.get_m ();

			  const double mp_out = imp_out - jp;
							
			  prot_OBME_HF_pp_part += prot_OBME_HF_pp_subpart_calc (shell_p_HF_in , shell_p_HF_out , shell_p_occ , mp_out , mp_out , mp_occ , mp_occ ,
										    SDs_weight , CGs , inter_data , Gaussian_table_GL , multipolar_expansion);
			}
		    }
		  else if (p_jump_states_number_GS_in == 2)
		    {
		      SDp_lj_1h_out.different_states_determine (SDp_lj_GS_in , p_jump_states_number_1h_out , p_jump_states_1h_out);
		    
		      const unsigned int sa_GS = p_jump_states_GS_in(1);
		      const unsigned int sc_GS = p_jump_states_GS_in(0);
		      const unsigned int sd_1h = p_jump_states_1h_out(0);

		      const unsigned int sa_GS_place = SDp_lj_GS_in.state_place_find (sa_GS);
		      const unsigned int sc_GS_place = SDp_lj_GS_in.state_place_find (sc_GS);
		      const unsigned int sd_1h_place = SDp_lj_1h_out.state_place_find (sd_1h);

		      const class nljm_struct &phi_a_GS = phi_p_table(sa_GS);
		      const class nljm_struct &phi_c_GS = phi_p_table(sc_GS);
		      const class nljm_struct &phi_d_1h = phi_p_table(sd_1h);
						
		      if (same_nlj_particle (phi_a_GS , phi_c_GS) && same_nlj_particle (phi_a_GS , phi_d_1h))
			{
			  const unsigned int shell_p_occ_index = phi_a_GS.get_shell_index ();

			  const class spherical_state &shell_p_occ = shells_p(shell_p_occ_index);

			  const int reordering_phase_p = minus_one_pow (sa_GS_place + sc_GS_place + sd_1h_place + ZYval_m1);

			  const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase_p/Up_HF_normalizing_sum;

			  const double ma_GS = phi_a_GS.get_m ();
			  const double mc_GS = phi_c_GS.get_m ();
			  const double md_1h = phi_d_1h.get_m ();
			  
			  const double mb_1h = imp_out - jp;

			  prot_OBME_HF_pp_part += prot_OBME_HF_pp_subpart_calc (shell_p_HF_in , shell_p_HF_out , shell_p_occ , ma_GS , mb_1h , mc_GS , md_1h ,
										    SDs_weight , CGs , inter_data , Gaussian_table_GL , multipolar_expansion);
			}
		    }
		}
	    }
	}
    }
  
  return prot_OBME_HF_pp_part;
}

complex<double> MSDHF_potentials::SGI_MSGI_OBMEs::prot_OBME_HF_pn_part_calc (
									       const class spherical_state &shell_p_HF_in , 
									       const class spherical_state &shell_p_HF_out , 
									       const bool is_it_only_poles , 
									       const class CG_str &CGs , 
									       const class interaction_class &inter_data , 
									       const class array<double> &Gaussian_table_GL , 
									       const class multipolar_expansion_str &multipolar_expansion , 
									       const class baryons_data &prot_data_one_configuration_GSM , 
									       const class baryons_data &neut_data_one_configuration_GSM , 
									       const class HF_nucleons_data &prot_HF_data)
{
  const bool S_matrix_pole_in  = shell_p_HF_in.get_S_matrix_pole ();
  const bool S_matrix_pole_out = shell_p_HF_out.get_S_matrix_pole ();

  if (!same_lj_particle (shell_p_HF_in , shell_p_HF_out) || (is_it_only_poles && (!S_matrix_pole_in || !S_matrix_pole_out))) return 0.0;

  const int ZYval = prot_data_one_configuration_GSM.get_N_valence_nucleons_basis ();
  const int NYval = neut_data_one_configuration_GSM.get_N_valence_nucleons_basis ();

  if ((ZYval == 0) || (NYval == 0)) return 0.0;

  const int ZYval_m1 = ZYval - 1;

  const class array<class nljm_struct> &phi_p_table = prot_data_one_configuration_GSM.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data_one_configuration_GSM.get_phi_table ();

  const class array<class spherical_state> &shells_n = neut_data_one_configuration_GSM.get_shells ();

  const class lj_table<unsigned int> &dimensions_GS = prot_HF_data.get_dimensions_GS ();
  
  const class lj_table<complex<double> > &Up_HF_normalizing_sums = prot_HF_data.get_U_HF_normalizing_sums ();
  
  const class lj_table<class array<class Slater_determinant> > &SDp_tab_GS = prot_HF_data.get_SDp_tab_GS ();
  const class lj_table<class array<class Slater_determinant> > &SDn_tab_GS = prot_HF_data.get_SDn_tab_GS ();
  const class lj_table<class array<class Slater_determinant> > &SDp_tab_1h = prot_HF_data.get_SDs_1h ();
  
  const class lj_table<class array<complex<double> > > &SDs_GS_coefficients = prot_HF_data.get_SDs_GS_coefficients ();
  const class lj_table<class array<complex<double> > > &SDs_1h_coefficients = prot_HF_data.get_SDs_1h_coefficients ();
  
  const class lj_table<class array<bool> > &SDp_tab_1h_existence_tab = prot_HF_data.get_SDs_1h_existence_tab ();

  const double jp = shell_p_HF_in.get_j ();

  const int lp = shell_p_HF_in.get_l ();
  
  const int imp_number = make_int (2.0*jp + 1.0);
  
  const unsigned int dimension_GS = dimensions_GS(lp , jp);

  const complex<double> Up_HF_normalizing_sum = Up_HF_normalizing_sums(lp , jp);
	
  const class array<class Slater_determinant> &SDp_tab_GS_lj = SDp_tab_GS(lp , jp);
  const class array<class Slater_determinant> &SDn_tab_GS_lj = SDn_tab_GS(lp , jp);
  const class array<class Slater_determinant> &SDp_tab_1h_lj = SDp_tab_1h(lp , jp);
  
  const class array<complex<double> > &SDs_GS_coefficients_lj = SDs_GS_coefficients(lp , jp);
  const class array<complex<double> > &SDs_1h_coefficients_lj = SDs_1h_coefficients(lp , jp);
  
  const class array<bool> &SDp_tab_1h_existence_tab_lj = SDp_tab_1h_existence_tab(lp , jp);
	
  unsigned int p_jump_states_number_GS_in  = 0;
  unsigned int n_jump_states_number_GS_in  = 0;
  unsigned int n_jump_states_number_GS_out = 0;
  
  class array<unsigned int> p_jump_states_GS_in(ZYval);
  class array<unsigned int> n_jump_states_GS_in(NYval);
  class array<unsigned int> n_jump_states_GS_out(NYval);

  complex<double> prot_OBME_HF_pn_part = 0.0;

  for (unsigned int i_GS_in = 0 ; i_GS_in < dimension_GS ; i_GS_in++)
    {
      const complex<double> SD_GS_coefficient_in = SDs_GS_coefficients_lj(i_GS_in);

      if (SD_GS_coefficient_in == 0.0) continue;

      const class Slater_determinant &SDp_lj_GS_in = SDp_tab_GS_lj(i_GS_in);
      const class Slater_determinant &SDn_lj_GS_in = SDn_tab_GS_lj(i_GS_in);

      for (unsigned int i_GS_out = 0 ; i_GS_out < dimension_GS ; i_GS_out++)
	{
	  const class Slater_determinant &SDn_lj_GS_out = SDn_tab_GS_lj(i_GS_out);

	  SDn_lj_GS_in.different_states_determine (SDn_lj_GS_out , n_jump_states_number_GS_in , n_jump_states_GS_in);

	  if (n_jump_states_number_GS_in <= 1)
	    {
	      for (int imp_out = 0 ; imp_out < imp_number ; imp_out++)
		{
		  const bool SDp_lj_1h_out_exists = SDp_tab_1h_existence_tab_lj(i_GS_out , imp_out);

		  if (!SDp_lj_1h_out_exists) continue;

		  const complex<double> SD_1h_coefficient_out = SDs_1h_coefficients_lj(i_GS_out , imp_out);

		  if (SD_1h_coefficient_out == 0.0) continue;

		  const class Slater_determinant &SDp_lj_1h_out = SDp_tab_1h_lj(i_GS_out , imp_out);

		  SDp_lj_GS_in.different_states_determine (SDp_lj_1h_out , p_jump_states_number_GS_in , p_jump_states_GS_in);

		  if ((p_jump_states_number_GS_in == 1) && (n_jump_states_number_GS_in == 0))
		    {
		      const unsigned int p_jump_state = p_jump_states_GS_in(0);

		      const unsigned int p_jump_state_place = SDp_lj_GS_in.state_place_find (p_jump_state);

		      const int reordering_phase_p = minus_one_pow (p_jump_state_place + ZYval_m1);

		      const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase_p/Up_HF_normalizing_sum;

		      for (int n_occ = 0 ; n_occ < NYval ; n_occ++)
			{
			  const unsigned int state_n_occ = SDn_lj_GS_out[n_occ];

			  const class nljm_struct &phi_n_occ = phi_n_table(state_n_occ);

			  const unsigned int sn_occ = phi_n_occ.get_shell_index ();

			  const class spherical_state &shell_n_occ = shells_n(sn_occ);

			  const double mn_occ = phi_n_occ.get_m ();

			  const double mp_out = imp_out - jp;
							
			  prot_OBME_HF_pn_part += prot_OBME_HF_pn_subpart_calc (shell_p_HF_in , shell_p_HF_out , shell_n_occ , mp_out , mp_out , mn_occ , mn_occ ,
										    SDs_weight , CGs , inter_data , Gaussian_table_GL , multipolar_expansion);
			}
		    }
		  else if ((p_jump_states_number_GS_in == 1) && (n_jump_states_number_GS_in == 1))
		    {
		      SDn_lj_GS_out.different_states_determine (SDn_lj_GS_in , n_jump_states_number_GS_out , n_jump_states_GS_out);
		    
		      const unsigned int p_in  = p_jump_states_GS_in(0);
		      const unsigned int n_in  = n_jump_states_GS_in(0);
		      const unsigned int n_out = n_jump_states_GS_out(0);
		    
		      const unsigned int p_in_place  = SDp_lj_GS_in.state_place_find (p_in);
		      const unsigned int n_in_place  = SDn_lj_GS_in.state_place_find (n_in);
		      const unsigned int n_out_place = SDn_lj_GS_out.state_place_find (n_out);
		    
		      const int reordering_phase = minus_one_pow (n_in_place + n_out_place + p_in_place + ZYval_m1);

		      const class nljm_struct &phi_p_in  = phi_p_table(p_in);
		      const class nljm_struct &phi_n_in  = phi_n_table(n_in);
		      const class nljm_struct &phi_n_out = phi_n_table(n_out);

		      if (same_nlj_particle (phi_n_in , phi_n_out))
			{
			  const unsigned int shell_n_in_index = phi_n_in.get_shell_index ();
			
			  const class spherical_state &shell_n_in = shells_n(shell_n_in_index);

			  const double mp_in  = phi_p_in.get_m ();
			  const double mn_in  = phi_n_in.get_m ();
			  const double mn_out = phi_n_out.get_m ();
			  
			  const double mp_out = imp_out - jp;

			  const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase/Up_HF_normalizing_sum;

			  prot_OBME_HF_pn_part += prot_OBME_HF_pn_subpart_calc (shell_p_HF_in , shell_p_HF_out , shell_n_in , mp_in , mp_out , mn_in , mn_out ,
										    SDs_weight , CGs , inter_data , Gaussian_table_GL , multipolar_expansion);
			}
		    }
		}
	    }
	}
    }
  
  return prot_OBME_HF_pn_part;
}

complex<double> MSDHF_potentials::SGI_MSGI_OBMEs::neut_OBME_HF_nn_subpart_calc (
										  const class spherical_state &shell_n_in , 
										  const class spherical_state &shell_n_out , 
										  const class spherical_state &shell_n_occ , 
										  const double mn_in , 
										  const double mn_out , 
										  const double mn_occ_in , 
										  const double mn_occ_out , 
										  const complex<double> &SDs_weight , 
										  const class CG_str &CGs , 
										  const class interaction_class &inter_data , 
										  const class array<double> &Gaussian_table_GL , 
										  const class multipolar_expansion_str &multipolar_expansion)
{
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);
  
  const int ln = shell_n_in.get_l ();

  const int ln_occ = shell_n_occ.get_l ();

  const int M = make_int (mn_in + mn_occ_in);

  const int abs_M  = abs (M);

  const double jn = shell_n_in.get_j ();

  const double jn_occ = shell_n_occ.get_j ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (ln + ln_occ);
    
  const int Jmin = abs (make_int (jn - jn_occ));
  const int Jmax =      make_int (jn + jn_occ);

  complex<double> OBME_dir = 0.0;
  complex<double> OBME_exc = 0.0;

  for (int J = Jmin ; J <= Jmax ; J++)
    {
      if (abs_M <= J)
	{
	  const int lmax_multipole_expansion_dir = min (2*ln , 2*ln_occ);

	  const int lmin_multipole_expansion_exc = abs (ln - ln_occ);
	  const int lmax_multipole_expansion_exc =      ln + ln_occ;

	  const double CG_in_dir = CGs(jn_occ , mn_occ_in , jn     , mn_in     , J , M);
	  const double CG_in_exc = CGs(jn     , mn_in     , jn_occ , mn_occ_in , J , M);

	  const double CG_out = CGs(jn_occ , mn_occ_out , jn , mn_out , J , M);
	  
	  const complex<double> CG_out_SDs_weight = CG_out*SDs_weight;

	  const complex<double> CGs_SDs_weight_dir = CG_out_SDs_weight*CG_in_dir;
	  const complex<double> CGs_SDs_weight_exc = CG_out_SDs_weight*CG_in_exc;

	  complex<double> OBME_J_dir = 0.0;
	  complex<double> OBME_J_exc = 0.0;
	  
	  for (int ll = 0 ; ll <= lmax_multipole_expansion_dir ; ll++)
	    {
	      if (ll % 2 == 0)
		{
		  const double angular_part_dir = multipolar_expansion(ln , jn , ln_occ , jn_occ , ln , jn , ln_occ , jn_occ , ll , J);
		  
		  const complex<double> angular_part_CGs_SDs_weight_dir = angular_part_dir*CGs_SDs_weight_dir;

		  if (is_it_SGI) OBME_J_dir += SGI_part_common::OBME_nas_fixed_multipole_calc (inter_data , ll , true , angular_part_CGs_SDs_weight_dir , shell_n_occ , shell_n_in , shell_n_out);

		  if (is_it_MSGI) OBME_J_dir += angular_part_CGs_SDs_weight_dir;
		}
	    }
	  
	  for (int ll = lmin_multipole_expansion_exc ; ll <= lmax_multipole_expansion_exc ; ll++)
	    {
	      if ((ln + ll + ln_occ) % 2 == 0)
		{
		  const double angular_part_exc = multipolar_expansion(ln , jn , ln_occ , jn_occ , ln_occ , jn_occ , ln , jn , ll , J);

		  const complex<double> angular_part_CGs_SDs_weight_exc = angular_part_exc*CGs_SDs_weight_exc;

		  if (is_it_SGI) OBME_J_exc += SGI_part_common::OBME_nas_fixed_multipole_calc (inter_data , ll , false , angular_part_CGs_SDs_weight_exc , shell_n_occ , shell_n_in , shell_n_out);

		  if (is_it_MSGI) OBME_J_exc += angular_part_CGs_SDs_weight_exc;
		}
	    }
	  
	  const double coupling_constant = inter_data.Gaussian_coupling_constant (bp , J , false , false);

	  OBME_J_dir *= coupling_constant , OBME_dir += OBME_J_dir;
	  OBME_J_exc *= coupling_constant , OBME_exc += OBME_J_exc;
	}
    }

  if (is_it_SGI) 
    {
      const complex<double> OBME = OBME_dir - OBME_exc;

      return OBME;
    }

  if (is_it_MSGI)
    {
      const complex<double> OBME = MSGI_part_common::total_OBME_calc (shell_n_in , shell_n_out , Gaussian_table_GL , OBME_dir , OBME_exc , shell_n_occ);

      return OBME;
    }	

  return NADA;
}




complex<double> MSDHF_potentials::SGI_MSGI_OBMEs::neut_OBME_HF_pn_subpart_calc (
										  const class spherical_state &shell_n_in , 
										  const class spherical_state &shell_n_out , 
										  const class spherical_state &shell_p_occ , 
										  const double mn_in , 
										  const double mn_out , 
										  const double mp_occ_in , 
										  const double mp_occ_out , 
										  const complex<double> &SDs_weight , 
										  const class CG_str &CGs , 
										  const class interaction_class &inter_data , 
										  const class array<double> &Gaussian_table_GL , 
										  const class multipolar_expansion_str &multipolar_expansion)
{
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const int ln = shell_n_in.get_l ();

  const int lp_occ = shell_p_occ.get_l ();

  const int M = make_int (mn_in + mp_occ_in);

  const int abs_M  = abs (M);

  const double jn = shell_n_in.get_j ();

  const double jp_occ = shell_p_occ.get_j ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (ln + lp_occ);
   
  const int Jmin = abs (make_int (jn - jp_occ));
  const int Jmax =      make_int (jn + jp_occ);

  complex<double> OBME_dir = 0.0;
  complex<double> OBME_exc = 0.0;

  for (int J = Jmin ; J <= Jmax ; J++)
    {
      if (abs_M <= J)
	{
	  const int lmax_multipole_expansion_dir = min (2*ln , 2*lp_occ);

	  const int lmin_multipole_expansion_exc = abs (ln - lp_occ);
	  const int lmax_multipole_expansion_exc =      ln + lp_occ;
	  
	  const double CG_in_dir = CGs(jp_occ , mp_occ_in , jn     , mn_in     , J , M);
	  const double CG_in_exc = CGs(jn     , mn_in     , jp_occ , mp_occ_in , J , M);

	  const double CG_out = CGs(jp_occ , mp_occ_out , jn , mn_out , J , M);

	  const complex<double> CG_out_SDs_weight = CG_out*SDs_weight;

	  const complex<double> CGs_SDs_weight_dir = CG_out_SDs_weight*CG_in_dir;
	  const complex<double> CGs_SDs_weight_exc = CG_out_SDs_weight*CG_in_exc;

	  complex<double> OBME_J_dir = 0.0;
	  complex<double> OBME_J_exc = 0.0;
	  
	  for (int ll = 0 ; ll <= lmax_multipole_expansion_dir ; ll++)
	    {
	      if (ll % 2 == 0)
		{
		  const double angular_part_dir = multipolar_expansion(ln , jn , lp_occ , jp_occ , ln , jn , lp_occ , jp_occ , ll , J);

		  const complex<double> angular_part_CGs_SDs_weight_dir = angular_part_dir*CGs_SDs_weight_dir;

		  if (is_it_SGI) OBME_J_dir += SGI_part_common::OBME_nas_fixed_multipole_calc (inter_data , ll , true , angular_part_CGs_SDs_weight_dir , shell_p_occ , shell_n_in , shell_n_out);

		  if (is_it_MSGI) OBME_J_dir += angular_part_CGs_SDs_weight_dir;
		}
	    }
	  
	  for (int ll = lmin_multipole_expansion_exc ; ll <= lmax_multipole_expansion_exc ; ll++)
	    {
	      if ((ln + ll + lp_occ) % 2 == 0)
		{
		  const double angular_part_exc = multipolar_expansion(ln , jn , lp_occ , jp_occ , lp_occ , jp_occ , ln , jn , ll , J);

		  const complex<double> angular_part_CGs_SDs_weight_exc = angular_part_exc*CGs_SDs_weight_exc;

		  if (is_it_SGI) OBME_J_exc += SGI_part_common::OBME_nas_fixed_multipole_calc (inter_data , ll , false , angular_part_CGs_SDs_weight_exc , shell_p_occ , shell_n_in , shell_n_out);

		  if (is_it_MSGI) OBME_J_exc += angular_part_CGs_SDs_weight_exc;
		}
	    }
	  
	  const double coupling_constant_dir = inter_data.Gaussian_coupling_constant (bp , J , true , false);
	  const double coupling_constant_exc = inter_data.Gaussian_coupling_constant (bp , J , false , true);

	  OBME_J_dir *= coupling_constant_dir , OBME_dir += OBME_J_dir;
	  OBME_J_exc *= coupling_constant_exc , OBME_exc += OBME_J_exc;
	}
    }

  if (is_it_SGI) 
    {
      const complex<double> OBME = OBME_dir - OBME_exc;
      
      return OBME;
    }

  if (is_it_MSGI)
    {
      const complex<double> OBME = MSGI_part_common::total_OBME_calc (shell_n_in , shell_n_out , Gaussian_table_GL , OBME_dir , OBME_exc , shell_p_occ);

      return OBME;
    }	

  return NADA;
}

complex<double> MSDHF_potentials::SGI_MSGI_OBMEs::neut_OBME_HF_nn_part_calc (
									       const class spherical_state &shell_n_HF_in , 
									       const class spherical_state &shell_n_HF_out , 
									       const bool is_it_only_poles , 
									       const class CG_str &CGs , 
									       const class interaction_class &inter_data , 
									       const class array<double> &Gaussian_table_GL , 
									       const class multipolar_expansion_str &multipolar_expansion , 
									       const class baryons_data &neut_data_one_configuration_GSM , 
									       const class HF_nucleons_data &neut_HF_data)
{  
  const bool S_matrix_pole_in  = shell_n_HF_in.get_S_matrix_pole ();
  const bool S_matrix_pole_out = shell_n_HF_out.get_S_matrix_pole ();

  if (!same_lj_particle (shell_n_HF_in , shell_n_HF_out) || (is_it_only_poles && (!S_matrix_pole_in || !S_matrix_pole_out))) return 0.0;

  const int NYval = neut_data_one_configuration_GSM.get_N_valence_nucleons_basis ();

  if (NYval <= 1) return 0.0;

  const int NYval_m1 = NYval - 1;

  const class array<class nljm_struct> &phi_n_table = neut_data_one_configuration_GSM.get_phi_table ();

  const class array<class spherical_state> &shells_n = neut_data_one_configuration_GSM.get_shells ();

  const class lj_table<unsigned int> &dimensions_GS = neut_HF_data.get_dimensions_GS ();

  const class lj_table<complex<double> > &Un_HF_normalizing_sums = neut_HF_data.get_U_HF_normalizing_sums ();

  const class lj_table<class array<class Slater_determinant> > &SDp_tab_GS = neut_HF_data.get_SDp_tab_GS ();
  const class lj_table<class array<class Slater_determinant> > &SDn_tab_GS = neut_HF_data.get_SDn_tab_GS ();
  const class lj_table<class array<class Slater_determinant> > &SDn_tab_1h = neut_HF_data.get_SDs_1h ();

  const class lj_table<class array<complex<double> > > &SDs_GS_coefficients = neut_HF_data.get_SDs_GS_coefficients ();
  const class lj_table<class array<complex<double> > > &SDs_1h_coefficients = neut_HF_data.get_SDs_1h_coefficients ();

  const class lj_table<class array<bool> > &SDn_tab_1h_existence_tab = neut_HF_data.get_SDs_1h_existence_tab ();

  const double jn = shell_n_HF_in.get_j ();
  
  const int ln = shell_n_HF_in.get_l ();

  const int imn_number = make_int (2.0*jn + 1.0);
  
  const unsigned int dimension_GS = dimensions_GS(ln , jn);

  const complex<double> Un_HF_normalizing_sum = Un_HF_normalizing_sums(ln , jn);

  const class array<class Slater_determinant> &SDp_tab_GS_lj = SDp_tab_GS(ln , jn);
  const class array<class Slater_determinant> &SDn_tab_GS_lj = SDn_tab_GS(ln , jn);
  const class array<class Slater_determinant> &SDn_tab_1h_lj = SDn_tab_1h(ln , jn);
  
  const class array<complex<double> > &SDs_GS_coefficients_lj = SDs_GS_coefficients(ln , jn);
  const class array<complex<double> > &SDs_1h_coefficients_lj = SDs_1h_coefficients(ln , jn);

  const class array<bool> &SDn_tab_1h_existence_tab_lj = SDn_tab_1h_existence_tab(ln , jn);
	
  unsigned int n_jump_states_number_GS_in  = 0;
  unsigned int n_jump_states_number_1h_out = 0;
  
  class array<unsigned int> n_jump_states_GS_in(NYval);
  class array<unsigned int> n_jump_states_1h_out(NYval_m1);

  complex<double> neut_OBME_HF_nn_part = 0.0;

  for (unsigned int i_GS_in = 0 ; i_GS_in < dimension_GS ; i_GS_in++)
    {
      const complex<double> SD_GS_coefficient_in = SDs_GS_coefficients_lj(i_GS_in);

      if (SD_GS_coefficient_in == 0.0) continue;

      const class Slater_determinant &SDp_lj_GS_in = SDp_tab_GS_lj(i_GS_in);
      const class Slater_determinant &SDn_lj_GS_in = SDn_tab_GS_lj(i_GS_in);

      for (unsigned int i_GS_out = 0 ; i_GS_out < dimension_GS ; i_GS_out++)
	{
	  const class Slater_determinant &SDp_lj_GS_out = SDp_tab_GS_lj(i_GS_out);

	  if (SDp_lj_GS_in == SDp_lj_GS_out)
	    {
	      for (int imn_out = 0 ; imn_out < imn_number ; imn_out++)
		{
		  const bool SDn_lj_1h_out_exists = SDn_tab_1h_existence_tab_lj(i_GS_out , imn_out);

		  if (!SDn_lj_1h_out_exists) continue;

		  const complex<double> SD_1h_coefficient_out = SDs_1h_coefficients_lj(i_GS_out , imn_out);

		  if (SD_1h_coefficient_out == 0.0) continue;

		  const class Slater_determinant &SDn_lj_1h_out = SDn_tab_1h_lj(i_GS_out , imn_out);

		  SDn_lj_GS_in.different_states_determine (SDn_lj_1h_out , n_jump_states_number_GS_in , n_jump_states_GS_in);

		  if (n_jump_states_number_GS_in == 1)
		    {
		      const unsigned int n_jump_state = n_jump_states_GS_in(0);

		      const unsigned int n_jump_state_place = SDn_lj_GS_in.state_place_find (n_jump_state);
		    
		      const int reordering_phase_n = minus_one_pow (n_jump_state_place + NYval_m1);

		      const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase_n/Un_HF_normalizing_sum;
										
		      for (int n_occ = 0 ; n_occ < NYval_m1 ; n_occ++)
			{
			  const unsigned int state_n_occ = SDn_lj_1h_out[n_occ];

			  const class nljm_struct &phi_n_occ = phi_n_table(state_n_occ);
			
			  const unsigned int sn_occ = phi_n_occ.get_shell_index ();

			  const class spherical_state &shell_n_occ = shells_n(sn_occ);

			  const double mn_occ = phi_n_occ.get_m ();

			  const double mn_out = imn_out - jn;
							
			  neut_OBME_HF_nn_part += neut_OBME_HF_nn_subpart_calc (shell_n_HF_in , shell_n_HF_out , shell_n_occ , mn_out , mn_out , mn_occ , mn_occ ,
										    SDs_weight , CGs , inter_data , Gaussian_table_GL , multipolar_expansion);
			}
		    }
		  else if (n_jump_states_number_GS_in == 2)
		    {
		      SDn_lj_1h_out.different_states_determine (SDn_lj_GS_in , n_jump_states_number_1h_out , n_jump_states_1h_out);
		    
		      const unsigned int sa_GS = n_jump_states_GS_in(1);
		      const unsigned int sc_GS = n_jump_states_GS_in(0);
		      const unsigned int sd_1h = n_jump_states_1h_out(0);
		    
		      const unsigned int sa_GS_place = SDn_lj_GS_in.state_place_find (sa_GS);
		      const unsigned int sc_GS_place = SDn_lj_GS_in.state_place_find (sc_GS);
		      const unsigned int sd_1h_place = SDn_lj_1h_out.state_place_find (sd_1h);
		    
		      const class nljm_struct &phi_a_GS = phi_n_table(sa_GS);
		      const class nljm_struct &phi_c_GS = phi_n_table(sc_GS);
		      const class nljm_struct &phi_d_1h = phi_n_table(sd_1h);

		      if (same_nlj_particle (phi_a_GS , phi_c_GS) && same_nlj_particle (phi_a_GS , phi_d_1h))
			{
			  const unsigned int shell_n_occ_index = phi_a_GS.get_shell_index ();

			  const class spherical_state &shell_n_occ = shells_n(shell_n_occ_index);
			
			  const int reordering_phase_n = minus_one_pow (sa_GS_place + sc_GS_place + sd_1h_place + NYval_m1);

			  const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase_n/Un_HF_normalizing_sum;

			  const double ma_GS = phi_a_GS.get_m ();
			  const double mc_GS = phi_c_GS.get_m ();
			  const double md_1h = phi_d_1h.get_m ();

			  const double mb_1h = imn_out - jn;

			  neut_OBME_HF_nn_part += neut_OBME_HF_nn_subpart_calc (shell_n_HF_in , shell_n_HF_out , shell_n_occ , ma_GS , mb_1h , mc_GS , md_1h ,
										    SDs_weight , CGs , inter_data , Gaussian_table_GL , multipolar_expansion);
			}
		    }
		}
	    }
	}
    }

  return neut_OBME_HF_nn_part;
}

complex<double> MSDHF_potentials::SGI_MSGI_OBMEs::neut_OBME_HF_pn_part_calc (
									       const class spherical_state &shell_n_HF_in , 
									       const class spherical_state &shell_n_HF_out , 
									       const bool is_it_only_poles , 
									       const class CG_str &CGs , 
									       const class interaction_class &inter_data , 
									       const class array<double> &Gaussian_table_GL , 
									       const class multipolar_expansion_str &multipolar_expansion , 
									       const class baryons_data &prot_data_one_configuration_GSM , 
									       const class baryons_data &neut_data_one_configuration_GSM , 
									       const class HF_nucleons_data &neut_HF_data)
{ 
  const bool S_matrix_pole_in = shell_n_HF_in.get_S_matrix_pole ();
  const bool S_matrix_pole_out = shell_n_HF_out.get_S_matrix_pole ();

  if (!same_lj_particle (shell_n_HF_in , shell_n_HF_out) || (is_it_only_poles && (!S_matrix_pole_in || !S_matrix_pole_out))) return 0.0;

  const int ZYval = prot_data_one_configuration_GSM.get_N_valence_nucleons_basis ();
  const int NYval = neut_data_one_configuration_GSM.get_N_valence_nucleons_basis ();

  if ((ZYval == 0) || (NYval == 0)) return 0.0;

  const int NYval_m1 = NYval - 1;

  const class array<class nljm_struct> &phi_p_table = prot_data_one_configuration_GSM.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data_one_configuration_GSM.get_phi_table ();
  
  const class array<class spherical_state> &shells_p = prot_data_one_configuration_GSM.get_shells ();

  const class lj_table<unsigned int> &dimensions_GS = neut_HF_data.get_dimensions_GS ();
  
  const class lj_table<complex<double> > &Un_HF_normalizing_sums = neut_HF_data.get_U_HF_normalizing_sums ();

  const class lj_table<class array<class Slater_determinant> > &SDp_tab_GS = neut_HF_data.get_SDp_tab_GS ();
  const class lj_table<class array<class Slater_determinant> > &SDn_tab_GS = neut_HF_data.get_SDn_tab_GS ();
  const class lj_table<class array<class Slater_determinant> > &SDn_tab_1h = neut_HF_data.get_SDs_1h ();

  const class lj_table<class array<complex<double> > > &SDs_GS_coefficients = neut_HF_data.get_SDs_GS_coefficients ();
  const class lj_table<class array<complex<double> > > &SDs_1h_coefficients = neut_HF_data.get_SDs_1h_coefficients ();

  const class lj_table<class array<bool> > &SDn_tab_1h_existence_tab = neut_HF_data.get_SDs_1h_existence_tab ();

  const double jn = shell_n_HF_in.get_j ();
  
  const int ln = shell_n_HF_in.get_l ();

  const int imn_number = make_int (2.0*jn + 1.0);

  const unsigned int dimension_GS = dimensions_GS(ln , jn);

  const complex<double> Un_HF_normalizing_sum = Un_HF_normalizing_sums(ln , jn);

  const class array<class Slater_determinant> &SDp_tab_GS_lj = SDp_tab_GS(ln , jn);
  const class array<class Slater_determinant> &SDn_tab_GS_lj = SDn_tab_GS(ln , jn);
  const class array<class Slater_determinant> &SDn_tab_1h_lj = SDn_tab_1h(ln , jn);
  
  const class array<complex<double> > &SDs_GS_coefficients_lj = SDs_GS_coefficients(ln , jn);
  const class array<complex<double> > &SDs_1h_coefficients_lj = SDs_1h_coefficients(ln , jn);
  
  const class array<bool> &SDn_tab_1h_existence_tab_lj = SDn_tab_1h_existence_tab(ln , jn);
	
  unsigned int p_jump_states_number_GS_in  = 0;
  unsigned int p_jump_states_number_GS_out = 0;
  unsigned int n_jump_states_number_GS_in  = 0;
  
  class array<unsigned int> p_jump_states_GS_in(ZYval);
  class array<unsigned int> p_jump_states_GS_out(ZYval);
  class array<unsigned int> n_jump_states_GS_in(NYval);

  complex<double> neut_OBME_HF_pn_part = 0.0;

  for (unsigned int i_GS_in = 0 ; i_GS_in < dimension_GS ; i_GS_in++)
    {
      const complex<double> SD_GS_coefficient_in = SDs_GS_coefficients_lj(i_GS_in);

      if (SD_GS_coefficient_in == 0.0) continue;

      const class Slater_determinant &SDp_lj_GS_in = SDp_tab_GS_lj(i_GS_in);
      const class Slater_determinant &SDn_lj_GS_in = SDn_tab_GS_lj(i_GS_in);

      for (unsigned int i_GS_out = 0 ; i_GS_out < dimension_GS ; i_GS_out++)
	{
	  const class Slater_determinant &SDp_lj_GS_out = SDp_tab_GS_lj(i_GS_out);

	  SDp_lj_GS_in.different_states_determine (SDp_lj_GS_out , p_jump_states_number_GS_in , p_jump_states_GS_in);

	  if (p_jump_states_number_GS_in <= 1)
	    {
	      for (int imn_out = 0 ; imn_out < imn_number ; imn_out++)
		{
		  const bool SDn_lj_1h_out_exists = SDn_tab_1h_existence_tab_lj(i_GS_out , imn_out);

		  if (!SDn_lj_1h_out_exists) continue;

		  const complex<double> SD_1h_coefficient_out = SDs_1h_coefficients_lj(i_GS_out , imn_out);

		  if (SD_1h_coefficient_out == 0.0) continue;

		  const class Slater_determinant &SDn_lj_1h_out = SDn_tab_1h_lj(i_GS_out , imn_out);

		  SDn_lj_GS_in.different_states_determine (SDn_lj_1h_out , n_jump_states_number_GS_in , n_jump_states_GS_in);

		  if ((p_jump_states_number_GS_in == 0) && (n_jump_states_number_GS_in == 1))
		    {
		      const unsigned int n_jump_state = n_jump_states_GS_in(0);

		      const unsigned int n_jump_state_place = SDn_lj_GS_in.state_place_find (n_jump_state);

		      const int reordering_phase_n = minus_one_pow (n_jump_state_place + NYval_m1);

		      const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase_n/Un_HF_normalizing_sum;

		      for (int p_occ = 0 ; p_occ < ZYval ; p_occ++)
			{
			  const unsigned int state_p_occ = SDp_lj_GS_out[p_occ];

			  const class nljm_struct &phi_p_occ = phi_p_table(state_p_occ);
			  
			  const unsigned int sp_occ = phi_p_occ.get_shell_index (); 

			  const class spherical_state &shell_p_occ = shells_p(sp_occ);
			  
			  const double mp_occ = phi_p_occ.get_m ();
			  
			  const double mn_out = imn_out - jn;

			  neut_OBME_HF_pn_part += neut_OBME_HF_pn_subpart_calc (shell_n_HF_in , shell_n_HF_out , shell_p_occ , mn_out , mn_out , mp_occ , mp_occ ,
										    SDs_weight , CGs , inter_data , Gaussian_table_GL , multipolar_expansion);
			}
		    }
		  else if ((p_jump_states_number_GS_in == 1) && (n_jump_states_number_GS_in == 1))
		    {
		      SDp_lj_GS_out.different_states_determine (SDp_lj_GS_in , p_jump_states_number_GS_out , p_jump_states_GS_out);
		      
		      const unsigned int p_in  = p_jump_states_GS_in(0);
		      const unsigned int n_in  = n_jump_states_GS_in(0);
		      const unsigned int p_out = p_jump_states_GS_out(0);
		      
		      const unsigned int p_in_place  = SDp_lj_GS_in.state_place_find (p_in);		      
		      const unsigned int n_in_place  = SDn_lj_GS_in.state_place_find (n_in);
		      const unsigned int p_out_place = SDp_lj_GS_out.state_place_find (p_out);
		      
		      const int reordering_phase = minus_one_pow (p_in_place + p_out_place + n_in_place + NYval_m1);
		      
		      const class nljm_struct &phi_p_in  = phi_p_table(p_in);
		      const class nljm_struct &phi_n_in  = phi_n_table(n_in);
		      const class nljm_struct &phi_p_out = phi_p_table(p_out);
		      
		      if (same_nlj_particle (phi_p_in , phi_p_out))
			{
			  const unsigned int shell_p_in_index = phi_p_in.get_shell_index ();

			  const class spherical_state &shell_p_in = shells_p(shell_p_in_index);

			  const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase/Un_HF_normalizing_sum;
			  
			  const double mp_in  = phi_p_in.get_m ();
			  const double mn_in  = phi_n_in.get_m ();			  
			  const double mp_out = phi_p_out.get_m ();

			  const double mn_out = imn_out - jn;

			  neut_OBME_HF_pn_part += neut_OBME_HF_pn_subpart_calc (shell_n_HF_in , shell_n_HF_out , shell_p_in , mn_in , mn_out , mp_in , mp_out ,
										    SDs_weight , CGs , inter_data , Gaussian_table_GL , multipolar_expansion);
			}
		    }
		}
	    }
	}
    }
  
  return neut_OBME_HF_pn_part;
}

complex<double> MSDHF_potentials::SGI_MSGI_OBMEs::prot_OBME_HF_hole_double_counting_pp_subpart_calc (
												       const class spherical_state &shell_p_in , 
												       const class spherical_state &shell_p_out , 
												       const class spherical_state &shell_p_occ , 
												       const class interaction_class &inter_data , 
												       const class array<double> &Gaussian_table_GL , 
												       const class multipolar_expansion_str &multipolar_expansion)
{
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);
  
  const int lp = shell_p_in.get_l ();

  const int lp_occ = shell_p_occ.get_l ();
  
  const double jp = shell_p_in.get_j ();

  const double jp_occ = shell_p_occ.get_j ();
  
  const unsigned int bp = binary_parity_from_orbital_angular_momentum (lp + lp_occ);
    
  const int Jmin = abs (make_int (jp - jp_occ));
  const int Jmax =      make_int (jp + jp_occ);

  complex<double> OBME_dir = 0.0;
  complex<double> OBME_exc = 0.0;

  for (int J = Jmin ; J <= Jmax ; J++)
    {
      const int lmax_multipole_expansion_dir = min (2*lp , 2*lp_occ);

      const int lmin_multipole_expansion_exc = abs (lp - lp_occ);
      const int lmax_multipole_expansion_exc =      lp + lp_occ;

      const double hats_ratio = (2.0*J + 1.0)/(2.0*jp + 1.0);
      
      const double J_coefficient_dir = hats_ratio;
      const double J_coefficient_exc = hats_ratio*minus_one_pow (jp_occ + jp - J);

      complex<double> OBME_J_dir = 0.0;
      complex<double> OBME_J_exc = 0.0;
      
      for (int ll = 0 ; ll <= lmax_multipole_expansion_dir ; ll++)
	{
	  if (ll % 2 == 0)
	    {
	      const double angular_part_multipolar_dir = multipolar_expansion(lp , jp , lp_occ , jp_occ , lp , jp , lp_occ , jp_occ , ll , J);

	      const complex<double> angular_part_dir = angular_part_multipolar_dir*J_coefficient_dir;

	      if (is_it_SGI) OBME_J_dir += SGI_part_common::OBME_nas_fixed_multipole_calc (inter_data , ll , true , angular_part_dir , shell_p_occ , shell_p_in , shell_p_out);

	      if (is_it_MSGI) OBME_J_dir += angular_part_dir;
	    }
	}
      
      for (int ll = lmin_multipole_expansion_exc ; ll <= lmax_multipole_expansion_exc ; ll++)
	{
	  if ((lp + ll + lp_occ) % 2 == 0)
	    {
	      const double angular_part_multipolar_exc = multipolar_expansion(lp , jp , lp_occ , jp_occ , lp_occ , jp_occ , lp , jp , ll , J);

	      const complex<double> angular_part_exc = angular_part_multipolar_exc*J_coefficient_exc;

	      if (is_it_SGI) OBME_J_exc += SGI_part_common::OBME_nas_fixed_multipole_calc (inter_data , ll , false , angular_part_exc , shell_p_occ , shell_p_in , shell_p_out);

	      if (is_it_MSGI) OBME_J_exc += angular_part_exc;
	    }
	}
      
      const double coupling_constant = inter_data.Gaussian_coupling_constant (bp , J , false , false);

      OBME_J_dir *= coupling_constant , OBME_dir += OBME_J_dir;
      OBME_J_exc *= coupling_constant , OBME_exc += OBME_J_exc;
    }

  if (is_it_SGI) 
    {
      const complex<double> OBME = OBME_dir - OBME_exc;
      
      return OBME;
    }

  if (is_it_MSGI)	
    {
      const complex<double> OBME = MSGI_part_common::total_OBME_calc (shell_p_in , shell_p_out , Gaussian_table_GL , OBME_dir , OBME_exc , shell_p_occ);

      return OBME;
    }

  return NADA;
}

complex<double> MSDHF_potentials::SGI_MSGI_OBMEs::prot_OBME_HF_hole_double_counting_pn_subpart_calc (
												       const class spherical_state &shell_p_in , 
												       const class spherical_state &shell_p_out , 
												       const class spherical_state &shell_n_occ , 
												       const class interaction_class &inter_data , 
												       const class array<double> &Gaussian_table_GL , 
												       const class multipolar_expansion_str &multipolar_expansion)
{
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);
  
  const int lp = shell_p_in.get_l ();

  const int ln_occ = shell_n_occ.get_l ();
  
  const double jp = shell_p_in.get_j ();

  const double jn_occ = shell_n_occ.get_j ();
  
  const unsigned int bp = binary_parity_from_orbital_angular_momentum (lp + ln_occ);
    
  const int Jmin = abs (make_int (jp - jn_occ));
  const int Jmax =      make_int (jp + jn_occ);

  complex<double> OBME_dir = 0.0;
  complex<double> OBME_exc = 0.0;

  for (int J = Jmin ; J <= Jmax ; J++)
    {
      const int lmax_multipole_expansion_dir = min (2*lp , 2*ln_occ);
      
      const int lmin_multipole_expansion_exc = abs (lp - ln_occ);
      const int lmax_multipole_expansion_exc =      lp + ln_occ;

      const double hats_ratio = (2.0*J + 1.0)/(2.0*jp + 1.0);
	  
      const double J_coefficient_dir = hats_ratio;
      const double J_coefficient_exc = hats_ratio*minus_one_pow (jn_occ + jp - J);

      complex<double> OBME_J_dir = 0.0;
      complex<double> OBME_J_exc = 0.0;
      
      for (int ll = 0 ; ll <= lmax_multipole_expansion_dir ; ll++)
	{
	  if (ll % 2 == 0)
	    {
	      const double angular_part_multipolar_dir = multipolar_expansion(lp , jp , ln_occ , jn_occ , lp , jp , ln_occ , jn_occ , ll , J);

	      const complex<double> angular_part_dir = angular_part_multipolar_dir*J_coefficient_dir;

	      if (is_it_SGI) OBME_J_dir += SGI_part_common::OBME_nas_fixed_multipole_calc (inter_data , ll , true , angular_part_dir , shell_n_occ , shell_p_in , shell_p_out);

	      if (is_it_MSGI) OBME_J_dir += angular_part_dir;
	    }
	}
      
      for (int ll = lmin_multipole_expansion_exc ; ll <= lmax_multipole_expansion_exc ; ll++)
	{
	  if ((lp + ll + ln_occ) % 2 == 0)
	    {
	      const double angular_part_multipolar_exc = multipolar_expansion(lp , jp , ln_occ , jn_occ , ln_occ , jn_occ , lp , jp , ll , J);

	      const complex<double> angular_part_exc = angular_part_multipolar_exc*J_coefficient_exc;

	      if (is_it_SGI) OBME_J_exc += SGI_part_common::OBME_nas_fixed_multipole_calc (inter_data , ll , false , angular_part_exc , shell_n_occ , shell_p_in , shell_p_out);

	      if (is_it_MSGI) OBME_J_exc += angular_part_exc;
	    }
	}
      
      const double coupling_constant_dir = inter_data.Gaussian_coupling_constant (bp , J , true , false);
      const double coupling_constant_exc = inter_data.Gaussian_coupling_constant (bp , J , false , true);

      OBME_J_dir *= coupling_constant_dir , OBME_dir += OBME_J_dir;
      OBME_J_exc *= coupling_constant_exc , OBME_exc += OBME_J_exc;
    }

  if (is_it_SGI) 
    {
      const complex<double> OBME = OBME_dir - OBME_exc;
      
      return OBME;
    }

  if (is_it_MSGI)
    {
      const complex<double> OBME = MSGI_part_common::total_OBME_calc (shell_p_in , shell_p_out , Gaussian_table_GL , OBME_dir , OBME_exc , shell_n_occ);

      return OBME;
    }	

  return NADA;
}

complex<double> MSDHF_potentials::SGI_MSGI_OBMEs::prot_OBME_HF_hole_double_counting_pp_part_calc (
												    const class spherical_state &shell_p_in , 
												    const class spherical_state &shell_p_out , 
												    const bool is_it_only_poles , 
												    const class interaction_class &inter_data , 
												    const class array<double> &Gaussian_table_GL , 
												    const class multipolar_expansion_str &multipolar_expansion , 
												    const class HF_nucleons_data &prot_HF_data)
{
  const bool S_matrix_pole_in  = shell_p_in.get_S_matrix_pole ();
  const bool S_matrix_pole_out = shell_p_out.get_S_matrix_pole ();
  
  if (!same_lj_particle (shell_p_in , shell_p_out) || (is_it_only_poles && (!S_matrix_pole_in || !S_matrix_pole_out))) return 0.0;

  const int ZYval = prot_HF_data.get_N_valence_nucleons_basis ();
  
  if (ZYval <= 1) return 0.0;

  const unsigned int Np_nlj = prot_HF_data.get_N_nlj ();

  const class array<class spherical_state> &shells_p = prot_HF_data.get_shells ();

  const class array<class nlj_struct> &shells_p_qn = prot_HF_data.get_shells_quantum_numbers ();

  complex<double> prot_OBME_HF_hole_double_counting_pp_part = 0.0;
	
  for (unsigned int sp = 0 ; sp < Np_nlj ; sp++)
    {
      const class nlj_struct &shell_p_qn_possible_hole = shells_p_qn(sp);

      const bool hole_state_p = shell_p_qn_possible_hole.get_hole_state ();

      if (hole_state_p) 
	{
	  const class spherical_state &shell_p_hole = shells_p(sp);
			
	  prot_OBME_HF_hole_double_counting_pp_part += prot_OBME_HF_hole_double_counting_pp_subpart_calc (shell_p_in , shell_p_out , shell_p_hole , inter_data , Gaussian_table_GL , multipolar_expansion);
	}
    }

  return prot_OBME_HF_hole_double_counting_pp_part;
}

complex<double> MSDHF_potentials::SGI_MSGI_OBMEs::prot_OBME_HF_hole_double_counting_pn_part_calc (
												    const class spherical_state &shell_p_in , 
												    const class spherical_state &shell_p_out , 
												    const bool is_it_only_poles , 
												    const class interaction_class &inter_data , 
												    const class array<double> &Gaussian_table_GL , 
												    const class multipolar_expansion_str &multipolar_expansion , 
												    const class HF_nucleons_data &prot_HF_data , 
												    const class HF_nucleons_data &neut_HF_data)
{
  const bool S_matrix_pole_in  = shell_p_in.get_S_matrix_pole ();
  const bool S_matrix_pole_out = shell_p_out.get_S_matrix_pole ();
  
  if (!same_lj_particle (shell_p_in , shell_p_out) || (is_it_only_poles && (!S_matrix_pole_in || !S_matrix_pole_out))) return 0.0;

  const int ZYval = prot_HF_data.get_N_valence_nucleons_basis ();
  const int NYval = neut_HF_data.get_N_valence_nucleons_basis ();

  if ((ZYval == 0) || (NYval == 0)) return 0.0;

  const unsigned int Nn_nlj = neut_HF_data.get_N_nlj ();

  const class array<class spherical_state> &shells_n = neut_HF_data.get_shells ();

  const class array<class nlj_struct> &shells_n_qn = neut_HF_data.get_shells_quantum_numbers ();

  complex<double> prot_OBME_HF_hole_double_counting_pn_part = 0.0;

  for (unsigned int sn = 0 ; sn < Nn_nlj ; sn++)
    {
      const class nlj_struct &shell_n_qn_possible_hole = shells_n_qn(sn);

      const bool hole_state_n = shell_n_qn_possible_hole.get_hole_state ();

      if (hole_state_n) 
	{
	  const class spherical_state &shell_n_hole = shells_n(sn);

	  prot_OBME_HF_hole_double_counting_pn_part += prot_OBME_HF_hole_double_counting_pn_subpart_calc (shell_p_in , shell_p_out , shell_n_hole , inter_data , Gaussian_table_GL , multipolar_expansion);
	}
    }

  return prot_OBME_HF_hole_double_counting_pn_part;
}

complex<double> MSDHF_potentials::SGI_MSGI_OBMEs::neut_OBME_HF_hole_double_counting_nn_subpart_calc (
												       const class spherical_state &shell_n_in , 
												       const class spherical_state &shell_n_out , 
												       const class spherical_state &shell_n_occ , 
												       const class interaction_class &inter_data , 
												       const class array<double> &Gaussian_table_GL , 
												       const class multipolar_expansion_str &multipolar_expansion)
{
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);
  
  const int ln = shell_n_in.get_l ();

  const int ln_occ = shell_n_occ.get_l ();

  const double jn = shell_n_in.get_j ();

  const double jn_occ = shell_n_occ.get_j ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (ln + ln_occ);
    
  const int Jmin = abs (make_int (jn - jn_occ));
  const int Jmax =      make_int (jn + jn_occ);

  complex<double> OBME_dir = 0.0;
  complex<double> OBME_exc = 0.0;

  for (int J = Jmin ; J <= Jmax ; J++)
    {
      const int lmax_multipole_expansion_dir = min (2*ln , 2*ln_occ);

      const int lmin_multipole_expansion_exc = abs (ln - ln_occ);
      const int lmax_multipole_expansion_exc =      ln + ln_occ;
      
      const double hats_ratio = (2.0*J + 1.0)/(2.0*jn + 1.0);
      
      const double J_coefficient_dir = hats_ratio;
      const double J_coefficient_exc = hats_ratio*minus_one_pow (jn_occ + jn - J);

      complex<double> OBME_J_dir = 0.0;
      complex<double> OBME_J_exc = 0.0;
      
      for (int ll = 0 ; ll <= lmax_multipole_expansion_dir ; ll++)
	{
	  if (ll % 2 == 0)
	    {
	      const double angular_part_multipolar_dir = multipolar_expansion(ln , jn , ln_occ , jn_occ , ln , jn , ln_occ , jn_occ , ll , J);
	      
	      const complex<double> angular_part_dir = angular_part_multipolar_dir*J_coefficient_dir;

	      if (is_it_SGI) OBME_J_dir += SGI_part_common::OBME_nas_fixed_multipole_calc (inter_data , ll , true , angular_part_dir , shell_n_occ , shell_n_in , shell_n_out);

	      if (is_it_MSGI) OBME_J_dir += angular_part_dir;
	    }
	}
      
      for (int ll = lmin_multipole_expansion_exc ; ll <= lmax_multipole_expansion_exc ; ll++)
	{
	  if ((ln + ll + ln_occ) % 2 == 0)
	    {
	      const double angular_part_multipolar_exc = multipolar_expansion(ln , jn , ln_occ , jn_occ , ln_occ , jn_occ , ln , jn , ll , J);

	      const complex<double> angular_part_exc = angular_part_multipolar_exc*J_coefficient_exc;

	      if (is_it_SGI) OBME_J_exc += SGI_part_common::OBME_nas_fixed_multipole_calc (inter_data , ll , false , angular_part_exc , shell_n_occ , shell_n_in , shell_n_out);

	      if (is_it_MSGI) OBME_J_exc += angular_part_exc;
	    }
	}
      
      const double coupling_constant = inter_data.Gaussian_coupling_constant (bp , J , false , false);

      OBME_J_dir *= coupling_constant , OBME_dir += OBME_J_dir;
      OBME_J_exc *= coupling_constant , OBME_exc += OBME_J_exc;
    }

  if (is_it_SGI) 
    {
      const complex<double> OBME = OBME_dir - OBME_exc;

      return OBME;
    }

  if (is_it_MSGI)
    {
      const complex<double> OBME = MSGI_part_common::total_OBME_calc (shell_n_in , shell_n_out , Gaussian_table_GL , OBME_dir , OBME_exc , shell_n_occ);

      return OBME;
    }

  return NADA;
}

complex<double> MSDHF_potentials::SGI_MSGI_OBMEs::neut_OBME_HF_hole_double_counting_pn_subpart_calc (
												       const class spherical_state &shell_n_in , 
												       const class spherical_state &shell_n_out , 
												       const class spherical_state &shell_p_occ , 
												       const class interaction_class &inter_data , 
												       const class array<double> &Gaussian_table_GL , 
												       const class multipolar_expansion_str &multipolar_expansion)
{
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);
  
  const int ln = shell_n_in.get_l ();

  const int lp_occ = shell_p_occ.get_l ();

  const double jn = shell_n_in.get_j ();

  const double jp_occ = shell_p_occ.get_j ();
  
  const unsigned int bp = binary_parity_from_orbital_angular_momentum (ln + lp_occ);
    
  const int Jmin = abs (make_int (jn - jp_occ));
  const int Jmax =      make_int (jn + jp_occ);

  complex<double> OBME_dir = 0.0;
  complex<double> OBME_exc = 0.0;

  for (int J = Jmin ; J <= Jmax ; J++)
    {
      const int lmax_multipole_expansion_dir = min (2*ln , 2*lp_occ);
      
      const int lmin_multipole_expansion_exc = abs (ln - lp_occ);
      const int lmax_multipole_expansion_exc =      ln + lp_occ;

      const double hats_ratio = (2.0*J + 1.0)/(2.0*jn + 1.0);
	  
      const double J_coefficient_dir = hats_ratio;
      const double J_coefficient_exc = hats_ratio*minus_one_pow (jp_occ + jn - J);

      complex<double> OBME_J_dir = 0.0;
      complex<double> OBME_J_exc = 0.0;
      
      for (int ll = 0 ; ll <= lmax_multipole_expansion_dir ; ll++)
	{
	  if (ll % 2 == 0)
	    {
	      const double angular_part_multipolar_dir = multipolar_expansion(ln , jn , lp_occ , jp_occ , ln , jn , lp_occ , jp_occ , ll , J);

	      const complex<double> angular_part_dir = angular_part_multipolar_dir*J_coefficient_dir;

	      if (is_it_SGI) OBME_J_dir += SGI_part_common::OBME_nas_fixed_multipole_calc (inter_data , ll , true , angular_part_dir , shell_p_occ , shell_n_in , shell_n_out);
	      
	      if (is_it_MSGI) OBME_J_dir += angular_part_dir;
	    }
	}
      
      for (int ll = lmin_multipole_expansion_exc ; ll <= lmax_multipole_expansion_exc ; ll++)
	{
	  if ((ln + ll + lp_occ) % 2 == 0)
	    {
	      const double angular_part_multipolar_exc = multipolar_expansion(ln , jn , lp_occ , jp_occ , lp_occ , jp_occ , ln , jn , ll , J);

	      const complex<double> angular_part_exc = angular_part_multipolar_exc*J_coefficient_exc;

	      if (is_it_SGI) OBME_J_exc += SGI_part_common::OBME_nas_fixed_multipole_calc (inter_data , ll , false , angular_part_exc , shell_p_occ , shell_n_in , shell_n_out);

	      if (is_it_MSGI) OBME_J_exc += angular_part_exc;
	    }
	}
      
      const double coupling_constant_dir = inter_data.Gaussian_coupling_constant (bp , J , true , false);
      const double coupling_constant_exc = inter_data.Gaussian_coupling_constant (bp , J , false , true);

      OBME_J_dir *= coupling_constant_dir , OBME_dir += OBME_J_dir;
      OBME_J_exc *= coupling_constant_exc , OBME_exc += OBME_J_exc;
    }

  if (is_it_SGI) 
    {
      const complex<double> OBME = OBME_dir - OBME_exc;
      
      return OBME;
    }

  if (is_it_MSGI)
    {
      const complex<double> OBME = MSGI_part_common::total_OBME_calc (shell_n_in , shell_n_out , Gaussian_table_GL , OBME_dir , OBME_exc , shell_p_occ);

      return OBME;
    }

  return NADA;
}

complex<double> MSDHF_potentials::SGI_MSGI_OBMEs::neut_OBME_HF_hole_double_counting_nn_part_calc (
												    const class spherical_state &shell_n_in , 
												    const class spherical_state &shell_n_out , 
												    const bool is_it_only_poles , 
												    const class interaction_class &inter_data , 
												    const class array<double> &Gaussian_table_GL , 
												    const class multipolar_expansion_str &multipolar_expansion , 
												    const class HF_nucleons_data &neut_HF_data)
{  
  const bool S_matrix_pole_in  = shell_n_in.get_S_matrix_pole ();
  const bool S_matrix_pole_out = shell_n_out.get_S_matrix_pole ();

  if (!same_lj_particle (shell_n_in , shell_n_out) || (is_it_only_poles && (!S_matrix_pole_in || !S_matrix_pole_out))) return 0.0;

  const int NYval = neut_HF_data.get_N_valence_nucleons_basis ();
  
  if (NYval <= 1) return 0.0;

  const unsigned int Nn_nlj = neut_HF_data.get_N_nlj ();

  const class array<class spherical_state> &shells_n = neut_HF_data.get_shells ();

  const class array<class nlj_struct> &shells_n_qn = neut_HF_data.get_shells_quantum_numbers ();
	
  complex<double> neut_OBME_HF_hole_double_counting_nn_part = 0.0;
	
  for (unsigned int sn = 0 ; sn < Nn_nlj ; sn++)
    {
      const class nlj_struct &shell_n_qn_possible_hole = shells_n_qn(sn);

      const bool hole_state_n = shell_n_qn_possible_hole.get_hole_state ();

      if (hole_state_n) 
	{
	  const class spherical_state &shell_n_hole = shells_n(sn);

	  neut_OBME_HF_hole_double_counting_nn_part += neut_OBME_HF_hole_double_counting_nn_subpart_calc (shell_n_in , shell_n_out , shell_n_hole , inter_data , Gaussian_table_GL , multipolar_expansion);
	}
    }

  return neut_OBME_HF_hole_double_counting_nn_part;
}

complex<double> MSDHF_potentials::SGI_MSGI_OBMEs::neut_OBME_HF_hole_double_counting_pn_part_calc (
												    const class spherical_state &shell_n_in , 
												    const class spherical_state &shell_n_out , 
												    const bool is_it_only_poles , 
												    const class interaction_class &inter_data , 
												    const class array<double> &Gaussian_table_GL , 
												    const class multipolar_expansion_str &multipolar_expansion , 
												    const class HF_nucleons_data &prot_HF_data , 
												    const class HF_nucleons_data &neut_HF_data)
{ 
  const bool S_matrix_pole_in  = shell_n_in.get_S_matrix_pole ();
  const bool S_matrix_pole_out = shell_n_out.get_S_matrix_pole ();

  if (!same_lj_particle (shell_n_in , shell_n_out) || (is_it_only_poles && (!S_matrix_pole_in || !S_matrix_pole_out))) return 0.0;

  const int ZYval = prot_HF_data.get_N_valence_nucleons_basis ();
  const int NYval = neut_HF_data.get_N_valence_nucleons_basis ();
  
  if ((ZYval == 0) || (NYval == 0)) return 0.0;

  const unsigned int Np_nlj = prot_HF_data.get_N_nlj ();

  const class array<class spherical_state> &shells_p = prot_HF_data.get_shells ();
  
  const class array<class nlj_struct> &shells_p_qn = prot_HF_data.get_shells_quantum_numbers ();

  complex<double> neut_OBME_HF_hole_double_counting_pn_part = 0.0;

  for (unsigned int sp = 0 ; sp < Np_nlj ; sp++)
    {
      const class nlj_struct &shell_p_qn_possible_hole = shells_p_qn(sp);

      const bool hole_state_p = shell_p_qn_possible_hole.get_hole_state ();

      if (hole_state_p) 
	{
	  const class spherical_state &shell_p_hole = shells_p(sp);
			
	  neut_OBME_HF_hole_double_counting_pn_part += neut_OBME_HF_hole_double_counting_pn_subpart_calc (shell_n_in , shell_n_out , shell_p_hole , inter_data , Gaussian_table_GL , multipolar_expansion);
	}
    }

  return neut_OBME_HF_hole_double_counting_pn_part;
}


















// Calculation of the MSDHF potential OBMEs for the proton or neutron case
// ---------------------------------------------------------------------------------------
// Proton-proton, neutron-neutron and proton-neutron parts are summed here.

complex<double> MSDHF_potentials::SGI_MSGI_OBMEs::prot_OBME_HF_calc (
								       const class spherical_state &shell_p_in , 
								       const class spherical_state &shell_p_out , 
								       const bool is_it_only_poles , 
								       const class CG_str &CGs , 
								       const class interaction_class &inter_data , 
								       const class array<double> &Gaussian_table_GL , 
								       const class multipolar_expansion_str &multipolar_expansion , 
								       const class baryons_data &prot_data_one_configuration_GSM , 
								       const class baryons_data &neut_data_one_configuration_GSM , 
								       const class HF_nucleons_data &prot_HF_data , 
								       const class HF_nucleons_data &neut_HF_data)
{
  if (!same_lj_particle (shell_p_in , shell_p_out)) return 0.0;

  const complex<double> prot_OBME_pp_HF = prot_OBME_HF_pp_part_calc (shell_p_in , shell_p_out , is_it_only_poles , CGs , inter_data ,
								       Gaussian_table_GL , multipolar_expansion , prot_data_one_configuration_GSM , prot_HF_data); 

  const complex<double> prot_OBME_pn_HF = prot_OBME_HF_pn_part_calc (shell_p_in , shell_p_out , is_it_only_poles , CGs , inter_data ,
								       Gaussian_table_GL , multipolar_expansion , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , prot_HF_data);

  const complex<double> prot_OBME_HF_hole_double_counting_pp_HF = prot_OBME_HF_hole_double_counting_pp_part_calc (shell_p_in , shell_p_out , is_it_only_poles , inter_data ,
														      Gaussian_table_GL , multipolar_expansion , prot_HF_data); 

  const complex<double> prot_OBME_HF_hole_double_counting_pn_HF = prot_OBME_HF_hole_double_counting_pn_part_calc (shell_p_in , shell_p_out , is_it_only_poles , inter_data ,
														      Gaussian_table_GL , multipolar_expansion , prot_HF_data , neut_HF_data);

  const complex<double> prot_OBME_HF = prot_OBME_pp_HF + prot_OBME_pn_HF - prot_OBME_HF_hole_double_counting_pp_HF - prot_OBME_HF_hole_double_counting_pn_HF;

  return prot_OBME_HF;
}

complex<double> MSDHF_potentials::SGI_MSGI_OBMEs::neut_OBME_HF_calc (
								       const class spherical_state &shell_n_in , 
								       const class spherical_state &shell_n_out , 
								       const bool is_it_only_poles , 
								       const class CG_str &CGs , 
								       const class interaction_class &inter_data , 
								       const class array<double> &Gaussian_table_GL , 
								       const class multipolar_expansion_str &multipolar_expansion , 
								       const class baryons_data &prot_data_one_configuration_GSM , 
								       const class baryons_data &neut_data_one_configuration_GSM , 
								       const class HF_nucleons_data &prot_HF_data , 
								       const class HF_nucleons_data &neut_HF_data)
{
  if (!same_lj_particle (shell_n_in , shell_n_out)) return 0.0;

  const complex<double> neut_Y_OBME_nn_HF = neut_OBME_HF_nn_part_calc (shell_n_in , shell_n_out , is_it_only_poles , CGs , inter_data ,
								       Gaussian_table_GL , multipolar_expansion , neut_data_one_configuration_GSM , neut_HF_data);
  
  const complex<double> neut_OBME_pn_HF = neut_OBME_HF_pn_part_calc (shell_n_in , shell_n_out , is_it_only_poles , CGs , inter_data ,
								       Gaussian_table_GL , multipolar_expansion , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , neut_HF_data);

  const complex<double> neut_OBME_HF_hole_double_counting_nn_HF = neut_OBME_HF_hole_double_counting_nn_part_calc (shell_n_in , shell_n_out , is_it_only_poles , inter_data ,
														      Gaussian_table_GL , multipolar_expansion , neut_HF_data);
  
  const complex<double> neut_OBME_HF_hole_double_counting_pn_HF = neut_OBME_HF_hole_double_counting_pn_part_calc (shell_n_in , shell_n_out , is_it_only_poles , inter_data ,
														      Gaussian_table_GL , multipolar_expansion , prot_HF_data , neut_HF_data);

  const complex<double> neut_OBME_HF = neut_Y_OBME_nn_HF + neut_OBME_pn_HF - neut_OBME_HF_hole_double_counting_nn_HF - neut_OBME_HF_hole_double_counting_pn_HF;

  return neut_OBME_HF;
}






// Calculation of the MSDHF potential OBMEs for the proton or neutron case for all states
// ------------------------------------------------------------------------------------------------------
// MSDHF potential OBMEs for the proton or neutron case for all states are calculated here.

void MSDHF_potentials::SGI_MSGI_OBMEs::prot_OBMEs_HF_calc (
							   const bool is_it_only_poles , 
							   const class CG_str &CGs , 
							   const class interaction_class &inter_data , 
							   const class array<double> &Gaussian_table_GL , 
							   const class multipolar_expansion_str &multipolar_expansion , 
							   const class baryons_data &prot_data_one_configuration_GSM , 
							   const class baryons_data &neut_data_one_configuration_GSM , 
							   const class HF_nucleons_data &neut_HF_data , 
							   class HF_nucleons_data &prot_HF_data)
{
  const unsigned int Np_nlj = prot_HF_data.get_N_nlj ();

  if (Np_nlj == 0) return;

  const class array<class spherical_state> &shells_p = prot_HF_data.get_shells ();

  class lj_table<complex<double> > &prot_OBMEs_HF_SGI_MSGI = prot_HF_data.get_OBMEs_HF_SGI_MSGI ();	

  prot_OBMEs_HF_SGI_MSGI = 0.0;

  for (unsigned int sp_in = 0 ; sp_in < Np_nlj ; sp_in++)
    for (unsigned int sp_out = 0 ; sp_out < Np_nlj ; sp_out++)
      {
	const class spherical_state &shell_p_in  = shells_p(sp_in);
	const class spherical_state &shell_p_out = shells_p(sp_out);
	
	if (shell_p_in.is_it_filled () && shell_p_out.is_it_filled ())
	  {
	    if (same_lj_particle (shell_p_in , shell_p_out))
	      {
		const int lp = shell_p_in.get_l ();

		const double jp = shell_p_in.get_j ();
		
		const int np_in  = shell_p_in.get_n ();
		const int np_out = shell_p_out.get_n ();
		
		prot_OBMEs_HF_SGI_MSGI(lp , jp , np_in , np_out) = prot_OBME_HF_calc (shell_p_in , shell_p_out , is_it_only_poles , CGs , inter_data , Gaussian_table_GL , 
											multipolar_expansion , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , prot_HF_data , neut_HF_data);
	      }	
	  }
      }
}

void MSDHF_potentials::SGI_MSGI_OBMEs::neut_OBMEs_HF_calc (
							   const bool is_it_only_poles , 
							   const class CG_str &CGs , 
							   const class interaction_class &inter_data , 
							   const class array<double> &Gaussian_table_GL , 
							   const class multipolar_expansion_str &multipolar_expansion , 
							   const class baryons_data &prot_data_one_configuration_GSM , 
							   const class baryons_data &neut_data_one_configuration_GSM , 
							   const class HF_nucleons_data &prot_HF_data , 
							   class HF_nucleons_data &neut_HF_data)
{
  const unsigned int Nn_nlj = neut_HF_data.get_N_nlj ();

  if (Nn_nlj == 0) return;

  const class array<class spherical_state> &shells_n = neut_HF_data.get_shells ();

  class lj_table<complex<double> > &neut_OBMEs_HF_SGI_MSGI = neut_HF_data.get_OBMEs_HF_SGI_MSGI ();	

  neut_OBMEs_HF_SGI_MSGI = 0.0;

  for (unsigned int sn_in = 0 ; sn_in < Nn_nlj ; sn_in++)
    for (unsigned int sn_out = 0 ; sn_out < Nn_nlj ; sn_out++)
      {
	const class spherical_state &shell_n_in  = shells_n(sn_in);
	const class spherical_state &shell_n_out = shells_n(sn_out);
	
	if (shell_n_in.is_it_filled () && shell_n_out.is_it_filled ())
	  {
	    if (same_lj_particle (shell_n_in , shell_n_out))
	      {
		const int ln = shell_n_in.get_l ();
		
		const double jn = shell_n_in.get_j ();
		
		const int nn_in  = shell_n_in.get_n ();
		const int nn_out = shell_n_out.get_n ();
		
		neut_OBMEs_HF_SGI_MSGI(ln , jn , nn_in , nn_out) = neut_OBME_HF_calc (shell_n_in , shell_n_out , is_it_only_poles , CGs , inter_data , Gaussian_table_GL , 
											multipolar_expansion , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , prot_HF_data , neut_HF_data);
	      }	
	  }
      }
}




