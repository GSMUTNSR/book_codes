#include "../GSM_include/GSM_include_def.h"

// MPI transfer is done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

using namespace string_routines;
using namespace lj_matrix_common;
using namespace inputs_misc;
using namespace configuration_SD_in_space_one_jump_out_to_in;
using namespace GSM_vector_dimensions;



// TYPE is double or complex
// -------------------------


void natural_orbitals_ESPEs::calc_print (
					 const bool is_there_cout ,
					 const bool are_there_ESPEs , 
					 const class input_data_str &input_data ,
					 const class TBMEs_class &TBMEs_pn ,  
					 class nucleons_data &prot_data ,
					 class nucleons_data &neut_data ,
					 class GSM_vector &PSI_full)
{  
  if (is_there_cout && (THIS_PROCESS == MASTER_PROCESS))
    {
      cout << endl << "Natural orbitals and effective single particle energies" << endl;
      cout <<         "-------------------------------------------------------" << endl << endl;
    }

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const int n_holes_max_p = prot_data.get_n_holes_max ();
  const int n_holes_max_n = neut_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_data.get_n_scat_max ();
  const int n_scat_max_n = neut_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_data.get_E_max_hw ();
  const int En_max_hw = neut_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();

  const int lp_max = prot_data.get_lmax ();
  const int ln_max = neut_data.get_lmax ();

  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
    
  if (space != NEUTRONS_ONLY) scalar_density_matrices_allocate_initialize (prot_data);
  if (space != PROTONS_ONLY)  scalar_density_matrices_allocate_initialize (neut_data);

  class lj_table<class matrix<TYPE> > &prot_scalar_density_matrices = prot_data.get_scalar_density_matrices ();
  class lj_table<class matrix<TYPE> > &neut_scalar_density_matrices = neut_data.get_scalar_density_matrices ();

  const class array<class correlated_state_str> &natural_orbitals_reference_states = (space == PROTONS_ONLY)
    ? (prot_data.get_natural_orbitals_reference_states ())
    : (neut_data.get_natural_orbitals_reference_states ());

  const unsigned int natural_orbitals_reference_states_number = natural_orbitals_reference_states.dimension (0);

  class lj_table<class matrix<TYPE> > prot_scalar_density_matrices_reference_state_fixed(0.5 , lp_max);
  class lj_table<class matrix<TYPE> > neut_scalar_density_matrices_reference_state_fixed(0.5 , ln_max);

  if (space != NEUTRONS_ONLY) lj_matrices_parts_allocate_initialize (prot_data , prot_scalar_density_matrices_reference_state_fixed);
  if (space != PROTONS_ONLY)  lj_matrices_parts_allocate_initialize (neut_data , neut_scalar_density_matrices_reference_state_fixed);
  
  for (unsigned int i = 0 ; i < natural_orbitals_reference_states_number ; i++)
    {
      const class correlated_state_str &natural_orbitals_reference_state = natural_orbitals_reference_states(i);

      const unsigned int BP = natural_orbitals_reference_state.get_BP ();

      const unsigned int vector_index = natural_orbitals_reference_state.get_vector_index ();
      
      const double J = natural_orbitals_reference_state.get_J ();

      const double M = optimal_M_calc (input_data , prot_data , neut_data , BP , J);

      class GSM_vector_helper_class GSM_vector_helper(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
						      n_holes_max   , n_scat_max   , E_max_hw  ,
						      n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						      n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , true , prot_data , neut_data);
      
      class GSM_vector_helper_class GSM_vector_helper_full(false , space , inter , false , truncation_hw , truncation_ph ,
							   n_holes_max   , n_scat_max   , E_max_hw  ,
							   n_holes_max_p , n_scat_max_p , Ep_max_hw ,
							   n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , true , prot_data , neut_data);

      const class GSM_vector_helper_class dummy_helper;
  
      class GSM_vector PSI(GSM_vector_helper);

      PSI.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , natural_orbitals_reference_state);
      
      PSI_full.change_GSM_vector_helper_reallocate (GSM_vector_helper_full);
    
      PSI_full.full_vector_fill (PSI);

      configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , true , false , false , false , GSM_vector_helper_full , GSM_vector_helper , dummy_helper , prot_data , neut_data);
 
      if (space != NEUTRONS_ONLY) lj_matrices_initialize (prot_scalar_density_matrices_reference_state_fixed);
      if (space != PROTONS_ONLY)  lj_matrices_initialize (neut_scalar_density_matrices_reference_state_fixed);

      scalar_density_matrix::calc (PSI , PSI_full , prot_scalar_density_matrices_reference_state_fixed , neut_scalar_density_matrices_reference_state_fixed);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  if (space != NEUTRONS_ONLY) add_parts (prot_scalar_density_matrices_reference_state_fixed , prot_scalar_density_matrices);
	  if (space != PROTONS_ONLY)  add_parts (neut_scalar_density_matrices_reference_state_fixed , neut_scalar_density_matrices);

	  if (is_there_cout) cout << "Scalar density matrix of " << J_Pi_vector_index_string (BP , J , vector_index) << " calculated" << endl << endl;
	}
    }
 
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      if (space != NEUTRONS_ONLY) normalize (natural_orbitals_reference_states_number , prot_scalar_density_matrices);
      if (space != PROTONS_ONLY)  normalize (natural_orbitals_reference_states_number , neut_scalar_density_matrices);
    }
 
  if (space != NEUTRONS_ONLY) lj_matrices_core_states_handling (prot_data , prot_scalar_density_matrices);
  if (space != PROTONS_ONLY)  lj_matrices_core_states_handling (neut_data , neut_scalar_density_matrices);
  
#ifdef UseMPI
      
  if (is_it_MPI_parallelized)
    {
      if (space != NEUTRONS_ONLY) lj_matrices_MPI_Bcast (MPI_COMM_WORLD , MASTER_PROCESS , prot_scalar_density_matrices);
      if (space != PROTONS_ONLY)  lj_matrices_MPI_Bcast (MPI_COMM_WORLD , MASTER_PROCESS , neut_scalar_density_matrices);
    }
  
#endif
  
  if (are_there_ESPEs) ESPEs_Hamiltonian::prot_neut_alloc_calc (input_data , TBMEs_pn ,  prot_data , neut_data);
  
  if (space != NEUTRONS_ONLY) natural_orbitals_occupancies_ESPEs_alloc_calc_print (is_there_cout , are_there_ESPEs , prot_data);
  if (space != PROTONS_ONLY)  natural_orbitals_occupancies_ESPEs_alloc_calc_print (is_there_cout , are_there_ESPEs , neut_data);
}

