#include "../GSM_include/GSM_include_def.h"

// MPI transfer is done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

using namespace string_routines;
using namespace lj_matrix_common;
using namespace inputs_misc;
using namespace configuration_SD_in_space_one_jump_out_to_in;
using namespace GSM_vector_dimensions;



// TYPE is double or complex
// -------------------------


void natural_orbitals_ESPEs::calc_print (
					 const bool is_there_cout ,
					 const bool are_there_ESPEs , 
					 const class input_data_str &input_data ,
					 const class TBMEs_class &TBMEs_pn ,  
					 class baryons_data &prot_Y_data ,
					 class baryons_data &neut_Y_data ,
					 class GSM_vector &PSI_full)
{  
  if (is_there_cout && (THIS_PROCESS == MASTER_PROCESS))
    {
      cout << endl << "Natural orbitals and effective single particle energies" << endl;
      cout <<         "-------------------------------------------------------" << endl << endl;
    }

  const enum space_type space = input_data.get_space ();

  const int S = input_data.get_hypernucleus_strangeness ();

  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (S);
  
  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (S);  

  const enum interaction_type inter = input_data.get_inter ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();

  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
    
  if (space != NEUT_Y_ONLY) scalar_density_matrices_allocate_initialize (prot_Y_data);
  if (space != PROT_Y_ONLY) scalar_density_matrices_allocate_initialize (neut_Y_data);

  class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_p_tab = prot_Y_data.get_scalar_density_matrices_tab ();
  class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_n_tab = neut_Y_data.get_scalar_density_matrices_tab ();

  const class array<class correlated_state_str> &natural_orbitals_reference_states = (space == PROT_Y_ONLY)
    ? (prot_Y_data.get_natural_orbitals_reference_states ())
    : (neut_Y_data.get_natural_orbitals_reference_states ());

  const unsigned int natural_orbitals_reference_states_number = natural_orbitals_reference_states.dimension (0);

  class array<class lj_table<class matrix<TYPE> > > scalar_density_matrices_p_tabs_reference_state_fixed(Np_baryon_type);
  class array<class lj_table<class matrix<TYPE> > > scalar_density_matrices_n_tabs_reference_state_fixed(Nn_baryon_type);

  if (space != NEUT_Y_ONLY) lj_matrices_parts_tab_allocate_initialize (prot_Y_data , scalar_density_matrices_p_tabs_reference_state_fixed);
  if (space != PROT_Y_ONLY) lj_matrices_parts_tab_allocate_initialize (neut_Y_data , scalar_density_matrices_n_tabs_reference_state_fixed);
  
  for (unsigned int i = 0 ; i < natural_orbitals_reference_states_number ; i++)
    {
      const class correlated_state_str &natural_orbitals_reference_state = natural_orbitals_reference_states(i);

      const unsigned int BP = natural_orbitals_reference_state.get_BP ();

      const unsigned int vector_index = natural_orbitals_reference_state.get_vector_index ();
      
      const double J = natural_orbitals_reference_state.get_J ();

      const double M = optimal_M_calc (input_data , prot_Y_data , neut_Y_data , BP , J);

      class GSM_vector_helper_class GSM_vector_helper(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
						      n_holes_max   , n_scat_max   , E_max_hw  ,
						      n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						      n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , true , prot_Y_data , neut_Y_data);
      
      class GSM_vector_helper_class GSM_vector_helper_full(false , space , inter , false , truncation_hw , truncation_ph ,
							   n_holes_max   , n_scat_max   , E_max_hw  ,
							   n_holes_max_p , n_scat_max_p , Ep_max_hw ,
							   n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , true , prot_Y_data , neut_Y_data);

      const class GSM_vector_helper_class dummy_helper;
  
      class GSM_vector PSI(GSM_vector_helper);

      PSI.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , natural_orbitals_reference_state);
      
      PSI_full.change_GSM_vector_helper_reallocate (GSM_vector_helper_full);
    
      PSI_full.full_vector_fill (PSI);

      configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , true , false , false , false , GSM_vector_helper_full , GSM_vector_helper , dummy_helper , prot_Y_data , neut_Y_data);
 
      if (space != NEUT_Y_ONLY) lj_matrices_tab_initialize (scalar_density_matrices_p_tabs_reference_state_fixed);
      if (space != PROT_Y_ONLY) lj_matrices_tab_initialize (scalar_density_matrices_n_tabs_reference_state_fixed);

      scalar_density_matrix::calc (PSI , PSI_full , scalar_density_matrices_p_tabs_reference_state_fixed , scalar_density_matrices_n_tabs_reference_state_fixed);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  if (space != NEUT_Y_ONLY) add_parts (scalar_density_matrices_p_tabs_reference_state_fixed , scalar_density_matrices_p_tab);
	  if (space != PROT_Y_ONLY) add_parts (scalar_density_matrices_n_tabs_reference_state_fixed , scalar_density_matrices_n_tab);

	  if (is_there_cout) cout << "Scalar density matrix of " << J_Pi_vector_index_string (BP , J , vector_index) << " calculated" << endl << endl;
	}
    }
 
  if (space != NEUT_Y_ONLY) normalize (natural_orbitals_reference_states_number , scalar_density_matrices_p_tab);
  if (space != PROT_Y_ONLY) normalize (natural_orbitals_reference_states_number , scalar_density_matrices_n_tab);

  if (space != NEUT_Y_ONLY) lj_matrices_tab_core_states_handling (prot_Y_data , scalar_density_matrices_p_tab);
  if (space != PROT_Y_ONLY) lj_matrices_tab_core_states_handling (neut_Y_data , scalar_density_matrices_n_tab);
  
#ifdef UseMPI
      
  if (is_it_MPI_parallelized)
    {
      if (space != NEUT_Y_ONLY) lj_matrices_tab_MPI_Bcast (MPI_COMM_WORLD , MASTER_PROCESS , scalar_density_matrices_p_tab);
      if (space != PROT_Y_ONLY) lj_matrices_tab_MPI_Bcast (MPI_COMM_WORLD , MASTER_PROCESS , scalar_density_matrices_n_tab);
    }
  
#endif
  
  if (are_there_ESPEs) ESPEs_Hamiltonian::pn_alloc_calc (input_data , TBMEs_pn ,  prot_Y_data , neut_Y_data);
  
  if (space != NEUT_Y_ONLY) natural_orbitals_occupancies_ESPEs_alloc_calc_print (is_there_cout , are_there_ESPEs , prot_Y_data);
  if (space != PROT_Y_ONLY) natural_orbitals_occupancies_ESPEs_alloc_calc_print (is_there_cout , are_there_ESPEs , neut_Y_data);
}

