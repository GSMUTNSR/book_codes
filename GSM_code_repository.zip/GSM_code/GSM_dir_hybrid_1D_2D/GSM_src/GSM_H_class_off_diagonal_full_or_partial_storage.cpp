#include "../GSM_include/GSM_include_def.h"

// Loops for two_jumps_pn routines are on in tables but output is on out tables => beware of OpenMP race conditions
// Critical regions are added in pp/nn routines as critical locks are not too numerous.

// One must only use GSM_vector operators and functions looping on space_dimensions_all_processes_max if one considered unoccupied squares on the right-hand side.
// Indeed, dimensions can be different on symmetric squares.

using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;
using namespace GSM_vector_NBMEs_handling::in_to_out;
using namespace MPI_2D_partitioning;
using namespace configuration_SD_in_space_one_jump_in_to_out;


// TYPE is double or complex
// -------------------------


// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons
// ------------------------------------------------------------------------------------------------------------------------------------------------------



// Storage of non-zero NBMEs of the Hamiltonian when full storage options are used and application of H times vector for the off-diagonal part
// --------------------------------------------------------------------------------------------------------------------------------------------
// Non-zero NBMEs of the Hamiltonian are calculated and stored therein. Array dimensions have been calculated in GSM_H_class_non_zero_NBMEs_numbers.cpp .
//
// TRS is time-reversal symmetry and can be used therein.
// It allows to to calculate about one half of |Psi[out]> if M=0, while the rest is given from the first half up to a phase in |Psi[in]> and |Psi[out]>.
// Thus, Hamiltonian storage is divided by about two when TRS is used.
//
// One calculates non-zero NBMEs occurring in one node only as they are not used in other nodes due to Hamiltonian 1D partitioning (see GSM_vector.cpp).
//
// One loops over proton and neutron Slater determinants, the first loop being proton or neutron according to the case.
//
//
// One does not use M_TBMEs in one jump routines even if they are stored as one does not necessarily have (a < b) and (c < d) in <ab|V|cd> TBMEs entering the NBME.
// One uses the symmetry relation <ab|V|cd> = <cd|V|ab> for pn TBMEs, and the latter are not necessarily stored as well.
// Recalculation time is negligible.
//
//
// hybrid 1D/2D partitioning
// -------------------------
// One uses hybrid 1D/2D partitioning for GSM vectors and operators, so that each node takes care of only one part of the input and output GSM vectors (2D partitioning),
// but where operators are stored as columns on each node (1D partitioning):
//
//        H            x  Psi[in]  =  Psi[out]
// * n * n * n * n *        *            *   
// *   *   *   *   *      node 0       node 0
// * o * o * o * o *        *            *
// *   *   *   *   *      node 1       node 1
// * d * d * d * d *        *            *
// *   *   *   *   *      node 2       node 2
// * e * e * e * e *        *            *
// *   *   *   *   *      node 3       node 3
// * 0 * 1 * 2 * 3 *        *            *
//
// H is stored by looping on inSD indices. However, H is applied by looping on outSD indices, so that arrays are function of outSD indices, and then race condition would occur with OpenMP using a naive implementation.
// Thus, OpenMP is not used for the 1p-1h parts involving protons or neutrons only in the pn case.
// These routines are quickly so that OpenMP is not important there.
// OpenMP is, however, done with valence protons or neutrons only for the 1p-1h part, as it is simpler there to do so.
// One uses critical statements if OpenMP parallelization is used when storing arrays.
// As the most expensive calculations occur before, it is efficient.
// For the 1p-1h parts involving both protons and neutrons, no race condition can occur:
// As inSDn = inSDn = SDn in the proton  1p-1h part, the same outSD basis index cannot occur for different SDn's so that no critical region is needed here.
// As inSDp = inSDp = SDp in the neutron 1p-1h part, the same outSD basis index cannot occur for different SDp's so that no critical region is needed here.
//
// For the 2p-2h proton-neutron part, one does the OpenMP parallelization on an index providing with the parity and M quantum numbers of outSDp (N_valence larger, see below) or outSDn (Z_valence larger, see below).
// Indeed, the same PSI_out_index cannot occur for different parity and M quantum numbers so that no critical region is needed here.
// This loop is inside a loop on the parity and M quantum numbers of inSDp (N_valence larger, see below) or inSDn (Z_valence larger, see below)., so that it is not done too many times.
//
//
//
// Each node calculates only part of Psi[out] and stores only part of H. 
// What is called a square is a part of H connecting the node i storing a part of |Psi[in]> to the node j storing a part of |Psi[out]>.
// An MPI communication of all newly calculated components on each row to the node taking care of the considered part of |Psi[out]> has to be done.
//
// Hamiltonian symmetry is used so that about half of H is stored.
// For this, one stores H only in occupied squares, i.e. squares where 2D partitioning allows for storage (see MPI_2D_partitioning.cpp).
// Let us take 5 nodes. One then has 15 squares:
//
// 0 - - 11 13
// 1 3 - -  14
// 2 4 6 -  -
// - 5 7 9  -
// - - 8 10 12
//
// H is stored only in the 0,...,14 squares.
// Diagonal squares are separated in two triangles to take into account symmetry, so that occupied and unoccupied relate to triangles therein.
// Nodes 0,1,2,3,4 store squares (0,1,2), (3,4,5), (6,7,8), (9,10,11), (12,13,14), respectively, due to the column storage of hybrid 1D/2D partitioning (see above).
// To do MPI reduction of results, one uses row communicators. In this example, they consist of the nodes storing the squares (0,11,13), (1,3,14), (2,4,6), (5,7,9), (8,10,12), respectively.
//
// H is now stored at this level and one considers |Psi[out]> -> |Psi[out]> + (H + E.Id).|Psi[in]>.
// One loops over all rows for all nodes. One only considers occupied squares.
// H.|Psi[in]> is applied on this occupied square with apply_add_off_diagonal_full_or_partial_storage_occupied_squares_part. The result is stored in H_PSI_occupied_squares.
// Then, by using the fact that H is symmetric, one applies H.|Psi[in]> reversing in and out indices with apply_add_off_diagonal_full_or_partial_storage_unoccupied_squares_part,
// so that the data stored in the occupied square are used in the opposite unoccupied square.
// As inSD and outSD indices are reversed, race condition would occur with OpnMP using a naive implementation in apply_add_off_diagonal_full_or_partial_storage_unoccupied_squares_part.
// Thus, each thread has a copy of H.|Psi[in]> and updates only its components. Then, no H.|Psi[in]> component can be updated by two different threads.
// All results are summed and put in H_PSI_unoccupied_squares_master_thread, added to |Psi[out]> at the end of the loop on rows.
// Overlapping of MPI communication and calculations is coded.
// For this, |Psi[in]> is firstly cast to PSI_in_unoccupied_squares in apply_add_off_diagonal_full_or_partial_storage_occupied_squares_part, which is used in apply_add_off_diagonal_full_or_partial_storage_unoccupied_squares_part afterwards.
// H_PSI_occupied_squares is reduced in apply_add_off_diagonal_full_or_partial_storage_unoccupied_squares_part on the row master process, to be added to |Psi[out]> in this process at the end of the loop on rows.
//
// MPI communication time and the average multiplications number per thread are also calculated and written on screen if is_there_cout_detailed is true.
//
//
// NBMEs_one_jump_pp_nn_calc_store, NBMEs_two_jumps_indices_pp_nn_calc_store
// -------------------------------------------------------------------------
// One considers only the proton or neutron 1p-1h or 2p-2h part (PARTIAL_STORAGE only for 2p2-2h, see GSM_H_class.cpp), and one uses the notation mu for proton or neutron.
// This is for p -> p', n -> n', p1 p2 -> p1' p2' and n1 n2 -> n1' n2' only.
// The routine NBMEs_two_jumps_pp_nn_calc_store of GSM_H_class.cpp is used for FULL_OR_PARTIAL_STORAGE (see GSM_H_class.cpp).
// This provides with non-zero off-diagonal NBMEs for 1p-1h or 2p-2h jumps from a proton/neutron out Slater determinant to an in proton/neutron Slater determinant.
// Jumps have already been calculated at this level, so that one calculates the NBME without reordering phase, 
// which is multiplied afterwards by the reordering phase, calculated along with jumps data and stored in jumps data arrays.
//
// Hamiltonian_part_one_jump_pp_nn_store
// -------------------------------------
// This provides with non-zero off-diagonal NBMEs for 1p-1h jumps from a proton/neutron out Slater determinant to an in proton/neutron Slater determinant.
// This is for p -> p', n -> n' only.
// Jumps have already been calculated at this level, so that one just checks if the obtained configuration after the 1p-1h or 2p-2h jump is part of the model space,
// i.e. is accepted with used truncations. The index of the in Slater determinant and the associated NBMEs are then stored and added to Hamiltonian arrays.
//
// Hamiltonian_part_two_jumps_indices_pp_nn_store, Hamiltonian_part_two_jumps_pp_nn_store
// --------------------------------------------------------------------------------------
// This provides with non-zero off-diagonal NBMEs for 2p-2h jumps from a proton/neutron out Slater determinant to an in proton/neutron Slater determinant.
// This is for p1 p2 -> p1' p2' and n1 n2 -> n1' n2' only.
// The first routine is used with PARTIAL_STORAGE only and the second one with FULL_OR_PARTIAL_STORAGE only (see GSM_H_class.cpp).
// Jumps have already been calculated at this level, so that one just checks if the obtained configuration after the 1p-1h or 2p-2h jump is part of the model space,
// i.e. is accepted with used truncations. The index of the in Slater determinant and the associated NBMEs (or NBME index) are then stored and/or added to Hamiltonian arrays.
// 
// jumps_p_prot_one_body_part_pn_calc_store, jumps_p_prot_two_body_part_pn_calc_store, jumps_n_neut_one_body_part_pn_calc_store, jumps_n_neut_two_body_part_pn_calc_store
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------------
// This provides with non-zero off-diagonal NBMEs for 1p-1h or 2p-2h jumps from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// This is for p -> p', n -> n', p1 p2 -> p1' p2' and n1 n2 -> n1' n2' only, and these routines are used when one has both valence protons and neutrons.
// One considers pp and nn OBMEs and TBMEs only in these routines.
// In this routine, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the indices of the in Slater determinant and the associated NBMEs from them.
// If there is a TBMEs pn part, it will be added afterwards. In order to know where to add pm NBMEs in Hamiltonian arrays, 
// the one_jump_start_non_zero_NBMEs_indices array is stored, which provides with the NBME index related to the considered out Slater determinant.
//
// one_jump_p_pn_part_pn_calc_store, one_jump_n_pn_part_pn_calc_store
// ------------------------------------------------------------------
// This provides with non-zero off-diagonal NBMEs of 1p-1h type  from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// This is for p -> p', n -> n' only, and these routines are used when one has both valence protons and neutrons.
// One considers pn TBMEs only in these routines.
// In this routine, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the indices of the in Slater determinant and the associated NBMEs from them.
// This part of 1p-1h NBME has to be added to the already calculated pp or nn NBME of the previous pp or nn routines.
// Hence, one has to know where to add NBMEs in Hamiltonian arrays.
// This is done with the one_jump_start_non_zero_NBMEs_indices array, which provides with the NBME index related to the considered out Slater determinant (see previous routines).
// In order to save time, one partially stored the pn NBME without phase, as it depends only on n and n' for a fixed proton SD (or p and p' for a fixed neutron SD).
// Hence, when one runs over neutrons SDs for a fixed proton SD (or over protons SDs for a fixed neutron SD), the same pn NBME can be reused several times.
// Only the reordering phase has to multiplied to it, and it has been calculated and stored in jumps arrays.
//
// two_jumps_pn_part_pn_N/Z_valence_larger_calc_store
// --------------------------------------------------
// This provides with non-zero off-diagonal NBMEs (or their indices, see GSM_H_class.cpp) for 2p-2h pn jumps from an out Slater determinant to an in Slater determinant.
// One routine is used if Nval >= Zval (N_valence_larger), and another if not (Z_valence_larger),
// as SD indices are calculated differently in each case to optimize their use (see GSM_vector_dimensions.cpp).
// One calculates 1p-1h proton or neutron jumps partially when Hamiltonian storage is full or partial storage (see one_jump_p_tabs, one_jump_n_tabs discussion in GSM_H_class.cpp).
// Indeed, if Hamiltonian full or partial storage is possible, one can assume that one can partially store 1p-1h proton or neutron jumps, i.e. storing the 1p-1h jumps of the proton (neutron) part if Nval >= Zval (Nval < Zval).
//
// jumps_part_pp_nn_calc_store
// ---------------------------
// This provides with the non-zero off-diagonal NBMEs for 1p-1h or 2p-2h jumps from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// This is for p -> p', n -> n', p1 p2 -> p1' p2' and n1 n2 -> n1' n2' only, and this routine is used when one has valence protons only or valence neutrons only.
// In this routine, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the number of non-zero NBMEs from them.
//
// matrix_off_diagonal_store
// -------------------------
// This routine calls the previous routine and calculates and stores non-zero NBMEs for each row of the Hamiltonian for each node.
// 
// apply_add_off_diagonal_full_or_partial_storage_occupied_squares_part, apply_add_off_diagonal_full_or_partial_storage_unoccupied_squares_part, apply_add_off_diagonal_full_or_partial_storage
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One applies here |Psi[out]> -> |Psi[out]> + (H + E.Id).|Psi[in]> using arrays previously stored for occupied or unoccupied squares with MPI communication overlapping  (see above).
// The 1p-1h and 2p-2h parts are separated. The diagonal part is not considered here, as it is taken into in apply_add (see GSM_H_class.cpp).
// The method used to deal with NBMEs indices when using PARTIAL_STORAGE is described in GSM_H_class.cpp .

void H_class::NBMEs_one_jump_pp_nn_calc_store (
					       const unsigned int BPmu , 
					       const int iMmu , 
					       const int n_scat_mu_in , 
					       const unsigned int iCmu_in , 
					       const unsigned int inSDmu_index , 
					       const class Slater_determinant &inSDmu ,
					       const class nucleons_data &data , 
					       bool &is_there_one_jump_calc , 
					       class jumps_data_in_to_out_str &one_jump_mu ,
					       class array<TYPE> &NBMEs_one_jump_mu) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum particle_type particle_mu = data.get_particle ();
 
  const enum interaction_type inter = GSM_vector_helper.get_inter ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 

  const bool is_one_body_mu_non_zero = (particle_mu == PROTON) ? (is_prot_one_body_non_zero) : (is_neut_one_body_non_zero);
  const bool is_two_body_mu_non_zero = (particle_mu == PROTON) ? (is_pp_non_zero) : (is_nn_non_zero);
  
  const int n_holes_max_mu = (particle_mu == PROTON) ? (n_holes_max_p) : (n_holes_max_n);
  
  const int n_scat_max_mu = (particle_mu == PROTON) ? (n_scat_max_p) : (n_scat_max_n);

  const int Emu_max_hw = (particle_mu == PROTON) ? (Ep_max_hw) : (En_max_hw);
   
  is_there_one_jump_calc = false;
      
  if (is_one_body_mu_non_zero || is_two_body_mu_non_zero || is_pn_non_zero)
    {
      one_jump_mu.one_jump_mu_store (BPmu , iMmu , n_holes_max_mu , n_scat_max_mu , Emu_max_hw , BPmu , n_scat_mu_in , iCmu_in , iMmu , inSDmu_index , data);

      const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();
	      
      if (dimension_one_jump_mu > 0)
	{ 
	  for (unsigned int i = 0 ; i < dimension_one_jump_mu ; i++)
	    { 
	      const class jumps_data_outSD_str &one_jump_mu_outSD = one_jump_mu(i);

	      const unsigned int mu_in  = one_jump_mu_outSD.get_mu_in ();
	      const unsigned int mu_out = one_jump_mu_outSD.get_mu_out ();

	      const unsigned int total_bin_phase_mu = one_jump_mu_outSD.get_total_bin_phase ();
	      
	      const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);
	      
	      const TYPE NBME_one_jump_mu_no_phase = H_NBMEs::no_pn_one_jump_mu_no_phase_calc (inter , is_one_body_mu_non_zero , is_two_body_mu_non_zero , mu_in , mu_out , inSDmu , data);
	      
	      NBMEs_one_jump_mu(i) = (total_phase_mu == 1) ? (NBME_one_jump_mu_no_phase) : (-NBME_one_jump_mu_no_phase);
	    }
	  
	  is_there_one_jump_calc = true;
	}
    }
}







void H_class::NBMEs_two_jumps_indices_pp_nn_calc_store (
							const unsigned int BPmu , 
							const int iMmu , 
							const int n_scat_mu_in , 
							const unsigned int iCmu_in , 
							const unsigned int inSDmu_index ,  
							const class nucleons_data &data , 
							bool &are_there_two_jumps_calc , 
							class jumps_data_in_to_out_str &two_jumps_mu ,  
							class array<unsigned int> &NBMEs_two_jumps_mu_indices) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum particle_type particle_mu = data.get_particle ();
  
  const enum space_type TBME_space_mu = (particle_mu == PROTON) ? (PROTONS_ONLY) : (NEUTRONS_ONLY);
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 

  const bool is_two_body_mu_non_zero = (particle_mu == PROTON) ? (is_pp_non_zero) : (is_nn_non_zero);

  const int N_valence_nucleons = data.get_N_valence_nucleons ();

  const int n_holes_max_mu = (particle_mu == PROTON) ? (n_holes_max_p) : (n_holes_max_n);
  
  const int n_scat_max_mu = (particle_mu == PROTON) ? (n_scat_max_p) : (n_scat_max_n);

  const int Emu_max_hw = (particle_mu == PROTON) ? (Ep_max_hw) : (En_max_hw);
    
  are_there_two_jumps_calc = false;

  if (is_two_body_mu_non_zero && (N_valence_nucleons >= 2))
    {
      two_jumps_mu.two_jumps_mu_store (BPmu , iMmu , n_holes_max_mu , n_scat_max_mu , Emu_max_hw , BPmu , n_scat_mu_in , iCmu_in , iMmu , inSDmu_index , data);

      const unsigned int dimension_two_jumps_mu = two_jumps_mu.get_dimension ();

      if (dimension_two_jumps_mu > 0)
	{  
	  for (unsigned int i = 0 ; i < dimension_two_jumps_mu ; i++)
	    { 
	      const class jumps_data_outSD_str &two_jumps_mu_outSD = two_jumps_mu(i);

	      const unsigned int mu_left_in  = two_jumps_mu_outSD.get_left_in ();
	      const unsigned int mu_right_in = two_jumps_mu_outSD.get_right_in ();
	      
	      const unsigned int mu_left_out  = two_jumps_mu_outSD.get_left_out ();
	      const unsigned int mu_right_out = two_jumps_mu_outSD.get_right_out ();
	      
	      const unsigned int total_bin_phase_mu = two_jumps_mu_outSD.get_total_bin_phase ();

	      const unsigned int TBME_mu_index = M_TBMEs.index_determine (TBME_space_mu , mu_left_in , mu_right_in , mu_left_out , mu_right_out);
	      
	      NBMEs_two_jumps_mu_indices(i) = total_bin_phase_mu + 2*TBME_mu_index;
	    }
 
	  are_there_two_jumps_calc = true;
	}
    }
}












// Calculation and storage of the 2p-2h NBMEs involving an outSD basis state of proton or neutron type from TBMEs and reordering phases
// ------------------------------------------------------------------------------------------------------------------------------------
// One considers only the pp or nn 2p-2h part, and one used the notation mu for proton or neutron.
// This routine can be used with valence protons only, valence neutrons only, or both valence protons and neutrons.
// It is used with both full storage and on the fly methods.
// The difference is that it is used only once with full storage, when calculating and storing the Hamiltoniam,
// whereas it is called for each Hamiltonian time vector operation with on the fly methods.
//
// One has a fixed proton or neutron outSD, whose quantum numbers and index are provided, and the array of 2p-2h jumps data to generate all inSD is calculated and stored.
// One loops over all possible 2p-2h jumps, so that one can find the one-body states alpha, beta, gamma, delta to form the TBME <alpha beta | V | gamma delta>,
// and one can find the reordering phase +/- 1, so that the NBME is equal to phase time TBME. The TBME is then stored in NBMEs_two_jumps_mu.

void H_class::NBMEs_two_jumps_pp_nn_calc_store (
						const unsigned int BPmu , 
						const int iMmu , 
						const int n_scat_mu_in , 
						const unsigned int iCmu_in , 
						const unsigned int inSDmu_index ,  
						const class nucleons_data &data , 
						bool &are_there_two_jumps_calc , 
						class jumps_data_in_to_out_str &two_jumps_mu ,  
						class array<TYPE> &NBMEs_two_jumps_mu) const
{
  are_there_two_jumps_calc = false;
  
  const int N_valence_nucleons = data.get_N_valence_nucleons ();

  if (N_valence_nucleons == 1) return;
  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum particle_type particle_mu = data.get_particle ();
  
  const enum space_type TBME_mu_space = (particle_mu == PROTON) ? (PROTONS_ONLY) : (NEUTRONS_ONLY);

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 

  const bool is_two_body_mu_non_zero = (particle_mu == PROTON) ? (is_pp_non_zero) : (is_nn_non_zero);
  
  const int n_holes_max_mu = (particle_mu == PROTON) ? (n_holes_max_p) : (n_holes_max_n);
  
  const int n_scat_max_mu = (particle_mu == PROTON) ? (n_scat_max_p) : (n_scat_max_n);

  const int Emu_max_hw = (particle_mu == PROTON) ? (Ep_max_hw) : (En_max_hw);
  
  const class TBMEs_class &TBMEs = data.get_TBMEs ();
  
  const bool are_M_TBMEs_stored = (M_TBMEs_storage == FULL_STORAGE);

  if (is_two_body_mu_non_zero && (N_valence_nucleons >= 2))
    {
      two_jumps_mu.two_jumps_mu_store (BPmu , iMmu , n_holes_max_mu , n_scat_max_mu , Emu_max_hw , BPmu , n_scat_mu_in , iCmu_in , iMmu , inSDmu_index , data);

      const unsigned int dimension_two_jumps_mu = two_jumps_mu.get_dimension ();

      if (dimension_two_jumps_mu > 0)
	{  
	  for (unsigned int i = 0 ; i < dimension_two_jumps_mu ; i++)
	    { 
	      const class jumps_data_outSD_str &two_jumps_mu_outSD = two_jumps_mu(i);

	      const unsigned int mu_left_in  = two_jumps_mu_outSD.get_left_in ();
	      const unsigned int mu_right_in = two_jumps_mu_outSD.get_right_in ();
	      
	      const unsigned int mu_left_out  = two_jumps_mu_outSD.get_left_out ();
	      const unsigned int mu_right_out = two_jumps_mu_outSD.get_right_out ();
	      
	      const unsigned int total_bin_phase_mu = two_jumps_mu_outSD.get_total_bin_phase ();
	      
	      const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);
	      
	      const TYPE TBME_mu = (are_M_TBMEs_stored) ? (M_TBMEs (TBME_mu_space , mu_left_in , mu_right_in , mu_left_out , mu_right_out)) : (TBMEs.M_TBME (mu_left_in , mu_right_in , mu_left_out , mu_right_out));
	    
	      NBMEs_two_jumps_mu(i) = (total_phase_mu == 1) ? (TBME_mu) : (-TBME_mu);
	    }
 
	  are_there_two_jumps_calc = true;
	}
    }
}















void H_class::Hamiltonian_part_one_jump_pp_nn_store (
						     const unsigned int PSI_in_index , 
						     const unsigned int dimension_one_jump ,
						     const class array<bool> &are_PSI_out_indices_accepted , 
						     const class array<unsigned int> &occupied_squares_row_indices ,  
						     const class array<unsigned int> &PSI_out_indices ,
						     const class array<TYPE> &NBMEs_one_jump)
{
  for (unsigned int i = 0 ; i < dimension_one_jump ; i++)
    {
      const bool is_PSI_out_index_accepted = are_PSI_out_indices_accepted(i);

      if (is_PSI_out_index_accepted)
	{
	  const unsigned int occupied_squares_row_index = occupied_squares_row_indices(i);

	  const unsigned int PSI_out_index = PSI_out_indices(i);

	  const TYPE NBME_one_jump = NBMEs_one_jump(i);
 
	  const unsigned int non_zero_NBMEs_index_one_jump = squares_non_zero_NBMEs_one_jump_numbers(occupied_squares_row_index , PSI_out_index)++;
	  
	  unsigned int *const square_non_zero_NBMEs_one_jump_PSI_column_indices = squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables(occupied_squares_row_index , PSI_out_index);
	  
	  TYPE *const square_non_zero_NBMEs_one_jump = squares_non_zero_NBMEs_one_jump_tables(occupied_squares_row_index , PSI_out_index);
	  
	  square_non_zero_NBMEs_one_jump_PSI_column_indices[non_zero_NBMEs_index_one_jump] = PSI_in_index;

	  square_non_zero_NBMEs_one_jump[non_zero_NBMEs_index_one_jump] += NBME_one_jump;
	}
    }
}








void H_class::Hamiltonian_part_two_jumps_indices_pp_nn_store (
							      const unsigned int PSI_in_index , 
							      const unsigned int dimension_two_jumps ,
							      const class array<bool> &are_PSI_out_indices_accepted , 
							      const class array<unsigned int> &occupied_squares_row_indices ,  
							      const class array<unsigned int> &PSI_out_indices ,
							      const class array<unsigned int> &NBMEs_two_jumps_indices)
{  
  for (unsigned int i = 0 ; i < dimension_two_jumps ; i++)
    {
      const bool is_PSI_out_index_accepted = are_PSI_out_indices_accepted(i);

      if (is_PSI_out_index_accepted)
	{
	  const unsigned int occupied_squares_row_index = occupied_squares_row_indices(i);

	  const unsigned int PSI_out_index = PSI_out_indices(i);

	  const unsigned int NBME_two_jumps_index = NBMEs_two_jumps_indices(i);
	  
	  const unsigned int non_zero_NBMEs_index_two_jumps = squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_out_index)++;
	  
	  unsigned int *const square_non_zero_NBMEs_two_jumps_PSI_column_indices = squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables(occupied_squares_row_index , PSI_out_index);
	  
	  unsigned int *const square_non_zero_NBMEs_two_jumps_indices = squares_non_zero_NBMEs_two_jumps_indices_tables(occupied_squares_row_index , PSI_out_index);
	  
	  square_non_zero_NBMEs_two_jumps_PSI_column_indices[non_zero_NBMEs_index_two_jumps] = PSI_in_index;

	  square_non_zero_NBMEs_two_jumps_indices[non_zero_NBMEs_index_two_jumps] = NBME_two_jumps_index;
	}
    }
}









void H_class::Hamiltonian_part_two_jumps_pp_nn_store (
						      const unsigned int PSI_in_index , 
						      const unsigned int dimension_two_jumps ,
						      const class array<bool> &are_PSI_out_indices_accepted , 
						      const class array<unsigned int> &occupied_squares_row_indices ,  
						      const class array<unsigned int> &PSI_out_indices ,
						      const class array<TYPE> &NBMEs_two_jumps)
{  
  for (unsigned int i = 0 ; i < dimension_two_jumps ; i++)
    {
      const bool is_PSI_out_index_accepted = are_PSI_out_indices_accepted(i);

      if (is_PSI_out_index_accepted)
	{
	  const unsigned int occupied_squares_row_index = occupied_squares_row_indices(i);

	  const unsigned int PSI_out_index = PSI_out_indices(i);

	  const TYPE &NBME_two_jumps = NBMEs_two_jumps(i);
	  
	  const unsigned int non_zero_NBMEs_index_two_jumps = squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_out_index)++;
	  
	  unsigned int *const square_non_zero_NBMEs_two_jumps_PSI_column_indices = squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables(occupied_squares_row_index , PSI_out_index);
	  
	  TYPE *const square_non_zero_NBMEs_two_jumps = squares_non_zero_NBMEs_two_jumps_tables(occupied_squares_row_index , PSI_out_index);
	  
	  square_non_zero_NBMEs_two_jumps_PSI_column_indices[non_zero_NBMEs_index_two_jumps] = PSI_in_index;

	  square_non_zero_NBMEs_two_jumps[non_zero_NBMEs_index_two_jumps] = NBME_two_jumps;
	}
    }
}










										      


void H_class::jumps_p_prot_one_body_part_pn_calc_store ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
    
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
      
  const int Zval = prot_data.get_N_valence_nucleons ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int iM = GSM_vector_helper.get_iM (); 

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
    
  const unsigned int dimension_p_1p1h_space_BP_iM_fixed_max = prot_data.get_dimension_1p1h_space_BP_iM_fixed_max ();     
  
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index ();
    
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
    
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_inSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_inSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  if (total_inSDp_index_min > total_inSDp_index_max) return;
    
  class Slater_determinant inSDp(Zval);
  
  class jumps_data_in_to_out_str one_jump_p(ONE_JUMP , PROTONS_NEUTRONS , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_iM_fixed_max);
  
  class array<TYPE> NBMEs_prot_one_jump_p(dimension_p_1p1h_space_BP_iM_fixed_max);
  
  class array<bool> are_PSI_out_indices_accepted_one_jump_p_tab(dimension_p_1p1h_space_BP_iM_fixed_max);

  class array<unsigned int> occupied_squares_row_indices_one_jump_p(dimension_p_1p1h_space_BP_iM_fixed_max);

  class array<unsigned int> PSI_out_indices_one_jump_p(dimension_p_1p1h_space_BP_iM_fixed_max);
  
  for (unsigned long int total_inSDp_index = total_inSDp_index_min ; total_inSDp_index <= total_inSDp_index_max ; total_inSDp_index++)
    {      
      const class SD_quantum_numbers &inSDp_qn = SDp_quantum_numbers_tab(total_inSDp_index);

      const int iMp = inSDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = inSDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int n_scat_p_in = inSDp_qn.get_n_scat ();
	
      const unsigned int iCp_in = inSDp_qn.get_iC ();

      const int n_holes_p_in = n_holes_p_table(BPp , n_scat_p_in , iCp_in);
      
      const int Ep_in = Ep_hw_table(BPp , n_scat_p_in , iCp_in);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_in , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_inSDp = dimensions_SDp_set(BPp , n_scat_p_in , iCp_in , iMp);

      if (dimension_inSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , n_scat_p_in , iCp_in , iMp);

      if (all_dimensions_SDn_zero) continue;

      const int iMn = iM - iMp;

      const unsigned int inSDp_index = inSDp_qn.get_SD_index ();
      		
      bool are_jumps_p_calculated = false;

      bool is_there_one_jump_calc_all = true;

      inSDp = SDp_set(BPp , n_scat_p_in , iCp_in , iMp , inSDp_index);
      
      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && is_there_one_jump_calc_all ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_process_tab(BPn , n_scat_n);
	  const unsigned int iCn_max = iCn_max_process_tab(BPn , n_scat_n);
		  			  
	  for (unsigned int iCn = iCn_min ; (iCn <= iCn_max) && is_there_one_jump_calc_all ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
	      const int En = En_hw_table(BPn , n_scat_n , iCn);
	  
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph ,
					       n_holes_p_in  , n_scat_p_in , Ep_in ,
					       n_holes_n     , n_scat_n    , En    ,
					       n_holes_max   , n_scat_max  , E_max_hw)) continue;

	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

	      if (dimension_SDn == 0) continue;
				  
	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1; 

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp , n_scat_p_in , n_scat_n , iCp_in , iCn , iMp);
	      
	      const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_SDn*inSDp_index;

	      const unsigned long int total_PSI_in_index_dimension_minus_one = total_PSI_in_index_zero + dimension_SDn_minus_one;
				  
	      if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
		{	     
		  if (!are_jumps_p_calculated)
		    {
		      NBMEs_one_jump_pp_nn_calc_store (BPp , iMp , n_scat_p_in , iCp_in , inSDp_index , inSDp , prot_data , is_there_one_jump_calc_all , one_jump_p , NBMEs_prot_one_jump_p);
			      
		      are_jumps_p_calculated = true;
		    }
			  
		  if (!is_there_one_jump_calc_all) continue;
			    
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero + SDn_index;

		      if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
			{
			  const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
				
			  bool is_there_one_jump_calc = false;
			  
			  are_PSI_out_indices_accepted_PSI_out_indices_prot_fill (BPn , n_holes_n , n_scat_n , iCn , iMn , SDn_index , En , one_jump_p , GSM_vector_helper , dimension_SDn , PSI_in_index ,
										  are_PSI_out_indices_accepted_one_jump_p_tab , occupied_squares_row_indices_one_jump_p , PSI_out_indices_one_jump_p , is_there_one_jump_calc);

			  if (is_there_one_jump_calc)
			    {
			      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				  
			      Hamiltonian_part_one_jump_pp_nn_store (PSI_in_index , dimension_one_jump_p , are_PSI_out_indices_accepted_one_jump_p_tab ,
								     occupied_squares_row_indices_one_jump_p , PSI_out_indices_one_jump_p , NBMEs_prot_one_jump_p);
			    }}}}}}}
}















							    

void H_class::jumps_p_prot_two_body_part_pn_calc_store ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
    
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int iM = GSM_vector_helper.get_iM (); 

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();

  if (Zval == 1) return;
  
  const unsigned int dimension_pp_2p2h_space_BP_iM_fixed_max = prot_data.get_dimension_2p2h_space_BP_iM_fixed_max ();      
    
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
    
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index ();
    
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
    
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_inSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_inSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  const bool is_it_partial_storage = (Hamiltonian_storage == PARTIAL_STORAGE);

  const bool is_it_full_storage = (Hamiltonian_storage == FULL_STORAGE);
    
  if (total_inSDp_index_min > total_inSDp_index_max) return;
  
  class array<class jumps_data_in_to_out_str> two_jumps_p_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > occupied_squares_row_indices_two_jumps_p_tab(NUMBER_OF_THREADS);  

  class array<class array<bool> > are_PSI_out_indices_accepted_two_jumps_p_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > PSI_out_indices_two_jumps_p_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > NBMEs_two_jumps_p_indices_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > NBMEs_two_jumps_p_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {   
      two_jumps_p_tab(i).allocate (TWO_JUMPS , PROTONS_NEUTRONS , truncation_hw , truncation_ph , dimension_pp_2p2h_space_BP_iM_fixed_max);
		
      occupied_squares_row_indices_two_jumps_p_tab(i).allocate (dimension_pp_2p2h_space_BP_iM_fixed_max);

      are_PSI_out_indices_accepted_two_jumps_p_tabs(i).allocate (dimension_pp_2p2h_space_BP_iM_fixed_max);

      PSI_out_indices_two_jumps_p_tab(i).allocate (dimension_pp_2p2h_space_BP_iM_fixed_max);

      if (is_it_partial_storage)  NBMEs_two_jumps_p_indices_tab(i).allocate (dimension_pp_2p2h_space_BP_iM_fixed_max);
      if (is_it_full_storage)     NBMEs_two_jumps_p_tab(i).allocate         (dimension_pp_2p2h_space_BP_iM_fixed_max);
    }      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_inSDp_index = total_inSDp_index_min ; total_inSDp_index <= total_inSDp_index_max ; total_inSDp_index++)
    {
      const class SD_quantum_numbers &inSDp_qn = SDp_quantum_numbers_tab(total_inSDp_index);

      const int iMp = inSDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = inSDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int n_scat_p_in = inSDp_qn.get_n_scat ();
	
      const unsigned int iCp_in = inSDp_qn.get_iC ();

      const int n_holes_p_in = n_holes_p_table(BPp , n_scat_p_in , iCp_in);
      
      const int Ep_in = Ep_hw_table(BPp , n_scat_p_in , iCp_in);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_in , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_inSDp = dimensions_SDp_set(BPp , n_scat_p_in , iCp_in , iMp);

      if (dimension_inSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , n_scat_p_in , iCp_in , iMp);

      if (all_dimensions_SDn_zero) continue;

      const int iMn = iM - iMp;

      const unsigned int inSDp_index = inSDp_qn.get_SD_index ();
            
      const unsigned int i_thread = OpenMP_thread_number_determine ();
		
      class jumps_data_in_to_out_str &two_jumps_p = two_jumps_p_tab(i_thread);
            
      class array<unsigned int> &occupied_squares_row_indices_two_jumps_p = occupied_squares_row_indices_two_jumps_p_tab(i_thread);  

      class array<bool> &are_PSI_out_indices_accepted_two_jumps_p_tab = are_PSI_out_indices_accepted_two_jumps_p_tabs(i_thread);
      
      class array<unsigned int> &PSI_out_indices_two_jumps_p = PSI_out_indices_two_jumps_p_tab(i_thread);

      class array<unsigned int> &NBMEs_two_jumps_p_indices = NBMEs_two_jumps_p_indices_tab(i_thread);
      
      class array<TYPE> &NBMEs_two_jumps_p = NBMEs_two_jumps_p_tab(i_thread);
      
      bool are_jumps_p_calculated = false;

      bool are_there_two_jumps_calc_all = true;

      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && are_there_two_jumps_calc_all ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_process_tab(BPn , n_scat_n);
	  const unsigned int iCn_max = iCn_max_process_tab(BPn , n_scat_n);
		  			  
	  for (unsigned int iCn = iCn_min ; (iCn <= iCn_max) && are_there_two_jumps_calc_all ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
	      const int En = En_hw_table(BPn , n_scat_n , iCn);
	  
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_in , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);
	      if (dimension_SDn == 0) continue;
				  
	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1; 

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp , n_scat_p_in , n_scat_n , iCp_in , iCn , iMp);
	      
	      const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_SDn*inSDp_index;

	      const unsigned long int total_PSI_in_index_dimension_minus_one = total_PSI_in_index_zero + dimension_SDn_minus_one;
				  
	      if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
		{
		  if (!are_jumps_p_calculated)
		    {
		      are_there_two_jumps_calc_all = false;

		      if (is_it_partial_storage)
			NBMEs_two_jumps_indices_pp_nn_calc_store (BPp , iMp , n_scat_p_in , iCp_in , inSDp_index , prot_data ,  are_there_two_jumps_calc_all , two_jumps_p , NBMEs_two_jumps_p_indices);
				    
		      if (is_it_full_storage)
			NBMEs_two_jumps_pp_nn_calc_store (BPp , iMp , n_scat_p_in , iCp_in , inSDp_index , prot_data , are_there_two_jumps_calc_all , two_jumps_p , NBMEs_two_jumps_p);
				  
		      are_jumps_p_calculated = true;
		    }
			      
		  if (!are_there_two_jumps_calc_all) continue;
		  
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero + SDn_index;

		      if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
			{
			  const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
			  
			  bool are_there_two_jumps_calc = false;
			      
			  are_PSI_out_indices_accepted_PSI_out_indices_prot_fill (BPn , n_holes_n , n_scat_n , iCn , iMn , SDn_index , En , two_jumps_p , GSM_vector_helper , dimension_SDn , PSI_in_index ,
										  are_PSI_out_indices_accepted_two_jumps_p_tab , occupied_squares_row_indices_two_jumps_p , PSI_out_indices_two_jumps_p , are_there_two_jumps_calc);
			      
#ifdef UseOpenMP
#pragma omp critical
#endif
			  {
			    if (are_there_two_jumps_calc)
			      {
				const unsigned int dimension_two_jumps_p = two_jumps_p.get_dimension ();
	    
				if (is_it_partial_storage)
				  Hamiltonian_part_two_jumps_indices_pp_nn_store (PSI_in_index , dimension_two_jumps_p , are_PSI_out_indices_accepted_two_jumps_p_tab ,
										  occupied_squares_row_indices_two_jumps_p , PSI_out_indices_two_jumps_p , NBMEs_two_jumps_p_indices);
							      				
				if (is_it_full_storage)
				  Hamiltonian_part_two_jumps_pp_nn_store (PSI_in_index , dimension_two_jumps_p , are_PSI_out_indices_accepted_two_jumps_p_tab ,
									  occupied_squares_row_indices_two_jumps_p , PSI_out_indices_two_jumps_p , NBMEs_two_jumps_p);
				
			      }}}}}}}}
}















							    
							    


void H_class::jumps_n_neut_one_body_part_pn_calc_store ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int iM = GSM_vector_helper.get_iM (); 

  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();
    
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
    
  const unsigned int dimension_n_1p1h_space_BP_iM_fixed_max = neut_data.get_dimension_1p1h_space_BP_iM_fixed_max ();
  
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
    
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();
  
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
      
  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_inSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_inSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();

  if (total_inSDn_index_min > total_inSDn_index_max) return;
    
  class Slater_determinant inSDn(Nval);
  
  class jumps_data_in_to_out_str one_jump_n(ONE_JUMP , PROTONS_NEUTRONS , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_iM_fixed_max);
  
  class array<TYPE> NBMEs_neut_one_jump_n(dimension_n_1p1h_space_BP_iM_fixed_max);

  class array<bool> are_PSI_out_indices_accepted_one_jump_n_tab(dimension_n_1p1h_space_BP_iM_fixed_max);

  class array<unsigned int> occupied_squares_row_indices_one_jump_n(dimension_n_1p1h_space_BP_iM_fixed_max);

  class array<unsigned int> PSI_out_indices_one_jump_n(dimension_n_1p1h_space_BP_iM_fixed_max);

  for (unsigned long int total_inSDn_index = total_inSDn_index_min ; total_inSDn_index <= total_inSDn_index_max ; total_inSDn_index++)
    {
      const class SD_quantum_numbers &inSDn_qn = SDn_quantum_numbers_tab(total_inSDn_index);

      const int iMn = inSDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = inSDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int n_scat_n_in = inSDn_qn.get_n_scat ();
	
      const unsigned int iCn_in = inSDn_qn.get_iC ();

      const int n_holes_n_in = n_holes_n_table(BPn , n_scat_n_in , iCn_in);
      
      const int En_in = En_hw_table(BPn , n_scat_n_in , iCn_in);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_in , n_scat_n_in , En_in , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn , n_scat_n_in , iCn_in , iMn);

      if (dimension_inSDn == 0) continue;

      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , n_scat_n_in , iCn_in , iMn);

      if (all_dimensions_SDp_zero) continue;

      const unsigned int inSDn_index = inSDn_qn.get_SD_index ();
            
      const int iMp = iM - iMn;

      bool are_jumps_n_calculated = false , is_there_one_jump_calc_all = true;

      inSDn = SDn_set(BPn , n_scat_n_in , iCn_in , iMn , inSDn_index);
      
      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && is_there_one_jump_calc_all ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , n_scat_p);
	  
	  for (unsigned int iCp = iCp_min ; (iCp <= iCp_max) && is_there_one_jump_calc_all ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

	      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);
	  
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph ,
					       n_holes_p     , n_scat_p    , Ep ,
					       n_holes_n_in  , n_scat_n_in , En_in ,
					       n_holes_max   , n_scat_max  , E_max_hw)) continue;
	      
	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);

	      if (dimension_SDp == 0) continue;

	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp , n_scat_p , n_scat_n_in , iCp , iCn_in , iMp);
	      
	      const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;
	      const unsigned long int total_PSI_in_index_dimension_minus_one = total_PSI_in_index_zero + dimension_inSDn*dimension_SDp_minus_one;

	      if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
		{
		  if (!are_jumps_n_calculated)
		    {
		      NBMEs_one_jump_pp_nn_calc_store (BPn , iMn , n_scat_n_in , iCn_in , inSDn_index , inSDn , neut_data , is_there_one_jump_calc_all , one_jump_n , NBMEs_neut_one_jump_n);
			      
		      are_jumps_n_calculated = true;
		    }
			  		
		  if (!is_there_one_jump_calc_all) continue;
			    
		  for (unsigned int SDp_index = 0 ; (SDp_index < dimension_SDp) && is_there_one_jump_calc_all ; SDp_index++)
		    {
		      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero + dimension_inSDn*SDp_index;
					
		      if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
			{
			  const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
			  
			  bool is_there_one_jump_calc = false;
			      
			  are_PSI_out_indices_accepted_PSI_out_indices_neut_fill (BPp , n_holes_p , n_scat_p , iCp , iMp , SDp_index , Ep , one_jump_n , GSM_vector_helper , PSI_in_index , 
										  are_PSI_out_indices_accepted_one_jump_n_tab , occupied_squares_row_indices_one_jump_n , PSI_out_indices_one_jump_n , is_there_one_jump_calc);

			  if (is_there_one_jump_calc)
			    {
			      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
				      			      
			      Hamiltonian_part_one_jump_pp_nn_store (PSI_in_index , dimension_one_jump_n , are_PSI_out_indices_accepted_one_jump_n_tab ,
								     occupied_squares_row_indices_one_jump_n , PSI_out_indices_one_jump_n , NBMEs_neut_one_jump_n);				
			    }}}}}}}
}
















void H_class::jumps_n_neut_two_body_part_pn_calc_store ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int iM = GSM_vector_helper.get_iM (); 

  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();
    
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
          
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
  
  const int Nval = neut_data.get_N_valence_nucleons ();

  if (Nval == 1) return;
  
  const unsigned int dimension_nn_2p2h_space_BP_iM_fixed_max = neut_data.get_dimension_2p2h_space_BP_iM_fixed_max (); 

  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
    
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
      
  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_inSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_inSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();

  const bool is_it_partial_storage = (Hamiltonian_storage == PARTIAL_STORAGE);

  const bool is_it_full_storage = (Hamiltonian_storage == FULL_STORAGE);

  if (total_inSDn_index_min > total_inSDn_index_max) return;
      
  class array<class jumps_data_in_to_out_str> two_jumps_n_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > occupied_squares_row_indices_two_jumps_n_tab(NUMBER_OF_THREADS);  

  class array<class array<bool> > are_PSI_out_indices_accepted_two_jumps_n_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > PSI_out_indices_two_jumps_n_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > NBMEs_two_jumps_n_indices_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > NBMEs_two_jumps_n_tab(NUMBER_OF_THREADS);
     
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      two_jumps_n_tab(i).allocate (TWO_JUMPS , PROTONS_NEUTRONS , truncation_hw , truncation_ph , dimension_nn_2p2h_space_BP_iM_fixed_max);
		
      occupied_squares_row_indices_two_jumps_n_tab(i).allocate (dimension_nn_2p2h_space_BP_iM_fixed_max);

      are_PSI_out_indices_accepted_two_jumps_n_tabs(i).allocate (dimension_nn_2p2h_space_BP_iM_fixed_max);

      PSI_out_indices_two_jumps_n_tab(i).allocate (dimension_nn_2p2h_space_BP_iM_fixed_max);
		
      if (is_it_partial_storage) NBMEs_two_jumps_n_indices_tab(i).allocate (dimension_nn_2p2h_space_BP_iM_fixed_max);
      if (is_it_full_storage)    NBMEs_two_jumps_n_tab(i).allocate         (dimension_nn_2p2h_space_BP_iM_fixed_max);
    }      

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_inSDn_index = total_inSDn_index_min ; total_inSDn_index <= total_inSDn_index_max ; total_inSDn_index++)
    {
      const class SD_quantum_numbers &inSDn_qn = SDn_quantum_numbers_tab(total_inSDn_index);

      const int iMn = inSDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = inSDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int n_scat_n_in = inSDn_qn.get_n_scat ();
	
      const unsigned int iCn_in = inSDn_qn.get_iC ();

      const int n_holes_n_in = n_holes_n_table(BPn , n_scat_n_in , iCn_in);
      
      const int En_in = En_hw_table(BPn , n_scat_n_in , iCn_in);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_in , n_scat_n_in , En_in , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn , n_scat_n_in , iCn_in , iMn);

      if (dimension_inSDn == 0) continue;

      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , n_scat_n_in , iCn_in , iMn);

      if (all_dimensions_SDp_zero) continue;

      const unsigned int inSDn_index = inSDn_qn.get_SD_index ();
            
      const int iMp = iM - iMn;
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	      
      class jumps_data_in_to_out_str &two_jumps_n = two_jumps_n_tab(i_thread);
      
      class array<bool> &are_PSI_out_indices_accepted_two_jumps_n_tab = are_PSI_out_indices_accepted_two_jumps_n_tabs(i_thread);
      
      class array<unsigned int> &occupied_squares_row_indices_two_jumps_n = occupied_squares_row_indices_two_jumps_n_tab(i_thread);
      
      class array<unsigned int> &PSI_out_indices_two_jumps_n = PSI_out_indices_two_jumps_n_tab(i_thread);

      class array<unsigned int> &NBMEs_two_jumps_n_indices = NBMEs_two_jumps_n_indices_tab(i_thread);

      class array<TYPE> &NBMEs_two_jumps_n = NBMEs_two_jumps_n_tab(i_thread);
      
      bool are_jumps_n_calculated = false;

      bool are_there_two_jumps_calc_all = true;

      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && are_there_two_jumps_calc_all ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , n_scat_p);
	  
	  for (unsigned int iCp = iCp_min ; (iCp <= iCp_max) && are_there_two_jumps_calc_all ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

	      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);
	  
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph ,
					       n_holes_p     , n_scat_p    , Ep ,
					       n_holes_n_in  , n_scat_n_in , En_in ,
					       n_holes_max   , n_scat_max  , E_max_hw)) continue;
	      
	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);

	      if (dimension_SDp == 0) continue;

	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp , n_scat_p , n_scat_n_in , iCp , iCn_in , iMp);
	      
	      const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;

	      const unsigned long int total_PSI_in_index_dimension_minus_one = total_PSI_in_index_zero + dimension_inSDn*dimension_SDp_minus_one;

	      if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
		{
		  
		  if (!are_jumps_n_calculated)
		    {
		      are_there_two_jumps_calc_all = false;

		      if (is_it_partial_storage)
			NBMEs_two_jumps_indices_pp_nn_calc_store (BPn , iMn , n_scat_n_in , iCn_in , inSDn_index , neut_data , are_there_two_jumps_calc_all , two_jumps_n , NBMEs_two_jumps_n_indices);
				    
		      if (is_it_full_storage)
			NBMEs_two_jumps_pp_nn_calc_store (BPn , iMn , n_scat_n_in , iCn_in , inSDn_index , neut_data , are_there_two_jumps_calc_all , two_jumps_n , NBMEs_two_jumps_n);
				  
		      are_jumps_n_calculated = true;
		    }

		  if (!are_there_two_jumps_calc_all) continue;
			      
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero + dimension_inSDn*SDp_index;
					
		      if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
			{
			  const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
			  
			  bool are_there_two_jumps_calc = false;
			      				
			  are_PSI_out_indices_accepted_PSI_out_indices_neut_fill (BPp , n_holes_p , n_scat_p , iCp , iMp , SDp_index , Ep , two_jumps_n , GSM_vector_helper , PSI_in_index ,
										  are_PSI_out_indices_accepted_two_jumps_n_tab , occupied_squares_row_indices_two_jumps_n , PSI_out_indices_two_jumps_n , are_there_two_jumps_calc);
				      
			  								   
#ifdef UseOpenMP
#pragma omp critical
#endif
			  {
			    if (are_there_two_jumps_calc)
			      {
				const unsigned int dimension_two_jumps_n = two_jumps_n.get_dimension ();
	    
				if (is_it_partial_storage)
				  Hamiltonian_part_two_jumps_indices_pp_nn_store (PSI_in_index , dimension_two_jumps_n , are_PSI_out_indices_accepted_two_jumps_n_tab ,
										  occupied_squares_row_indices_two_jumps_n , PSI_out_indices_two_jumps_n , NBMEs_two_jumps_n_indices);
					  
				if (is_it_full_storage)
				  Hamiltonian_part_two_jumps_pp_nn_store (PSI_in_index , dimension_two_jumps_n , are_PSI_out_indices_accepted_two_jumps_n_tab ,
									  occupied_squares_row_indices_two_jumps_n , PSI_out_indices_two_jumps_n , NBMEs_two_jumps_n);
			      }}}}}}}}
}



















void H_class::one_jump_p_pn_part_pn_calc_store ()
{  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();

  const class array<bool> &MPI_are_squares_occupied = GSM_vector_helper.get_MPI_are_squares_occupied ();

  const class array<unsigned int> &MPI_occupied_squares_row_indices = GSM_vector_helper.get_MPI_occupied_squares_row_indices ();
	
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int iM = GSM_vector_helper.get_iM (); 

  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
  
  const unsigned int dimension_p_1p1h_space_BP_iM_fixed_max = prot_data.get_dimension_1p1h_space_BP_iM_fixed_max ();
    
  const unsigned int Np_nljm = prot_data.get_N_nljm ();
        		  
  const unsigned int dimension_configuration_total_p = prot_data.get_dimension_configuration_total (); 
  
  const class array<unsigned int> &sum_dimensions_configuration_set_p = prot_data.get_sum_dimensions_configuration_set ();
  
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();
    
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const class array<unsigned long int> &first_total_PSI_indices = GSM_vector_helper.get_first_total_PSI_indices ();
  const class array<unsigned long int> &last_total_PSI_indices = GSM_vector_helper.get_last_total_PSI_indices ();

  const class array<class SD_quantum_numbers> &SD_quantum_numbers_neut_tab = neut_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_in_min_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_in_max_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const unsigned long int total_SDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_SDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();
      
  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn ();
  
  if (total_SDn_index_min > total_SDn_index_max) return;
    
  class array<class Slater_determinant> SDn_tab(NUMBER_OF_THREADS);
  
  class array<class array_BP_Nscat_iC<bool> > is_configuration_accepted_tabs(NUMBER_OF_THREADS);
	      
  class array<class array_BP_Nscat_iC<unsigned int> > dimensions_SDp_Mp_fixed_tab(NUMBER_OF_THREADS);

  class array<class array_BP_Nscat_iC<unsigned int> > sum_dimensions_configuration_Mp_Mn_fixed_tabs(NUMBER_OF_THREADS);
      
  class array<class jumps_data_in_to_out_str> one_jump_p_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > NBMEs_pn_one_jump_p_no_phase_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > NBMEs_pn_one_jump_p_no_phase_calculated_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SDn_tab(i).allocate (Nval);
      
      is_configuration_accepted_tabs(i).allocate (dimension_configuration_total_p , sum_dimensions_configuration_set_p);
	      
      dimensions_SDp_Mp_fixed_tab(i).allocate (dimension_configuration_total_p , sum_dimensions_configuration_set_p);

      sum_dimensions_configuration_Mp_Mn_fixed_tabs(i).allocate (dimension_configuration_total_p , sum_dimensions_configuration_set_p);
            
      one_jump_p_tab(i).allocate (ONE_JUMP , PROTONS_NEUTRONS , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_iM_fixed_max);

      NBMEs_pn_one_jump_p_no_phase_tab(i).allocate (Np_nljm , Np_nljm);

      NBMEs_pn_one_jump_p_no_phase_calculated_tab(i).allocate (Np_nljm , Np_nljm);
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_SDn_index = total_SDn_index_min ; total_SDn_index <= total_SDn_index_max ; total_SDn_index++)
    {
      const class SD_quantum_numbers &SDn_qn = SD_quantum_numbers_neut_tab(total_SDn_index);

      const int iMn = SDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = SDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int n_scat_n = SDn_qn.get_n_scat ();
	
      const unsigned int iCn = SDn_qn.get_iC ();

      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
      const int En = En_hw_table(BPn , n_scat_n , iCn);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

      if (dimension_SDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , n_scat_n , iCn , iMn);

      if (all_dimensions_SDp_zero) continue;
		  
      const unsigned int SDn_index = SDn_qn.get_SD_index ();
            
      const int iMp = iM - iMn;
  
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class Slater_determinant &SDn = SDn_tab(i_thread);
      
      class array_BP_Nscat_iC<bool> &is_configuration_accepted_tab = is_configuration_accepted_tabs(i_thread);
	      
      class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_Mp_fixed = dimensions_SDp_Mp_fixed_tab(i_thread);

      class array_BP_Nscat_iC<unsigned int> &sum_dimensions_configuration_Mp_Mn_fixed_tab = sum_dimensions_configuration_Mp_Mn_fixed_tabs(i_thread);
      
      class jumps_data_in_to_out_str &one_jump_p = one_jump_p_tab(i_thread);
	      
      class array<TYPE> &NBMEs_pn_one_jump_p_no_phase = NBMEs_pn_one_jump_p_no_phase_tab(i_thread);

      class array<bool> &NBMEs_pn_one_jump_p_no_phase_calculated = NBMEs_pn_one_jump_p_no_phase_calculated_tab(i_thread);
      
      is_configuration_accepted_prot_fill (n_holes_n , n_scat_n , En , BPp , GSM_vector_helper , is_configuration_accepted_tab);
      
      dimensions_SDp_sum_dimensions_configuration_Mp_Mn_fixed_prot_fill (BPn , n_scat_n , iCn , iMn , GSM_vector_helper , is_configuration_accepted_tab ,
									 dimensions_SDp_Mp_fixed , sum_dimensions_configuration_Mp_Mn_fixed_tab);
      
      SDn = SDn_set(BPn , n_scat_n , iCn , iMn , SDn_index);

      NBMEs_pn_one_jump_p_no_phase = 0.0;

      NBMEs_pn_one_jump_p_no_phase_calculated = false;

      for (int n_scat_p_in = 0 ; n_scat_p_in <= n_scat_max_p ; n_scat_p_in++)
	{
	  const unsigned int is_configuration_accepted_tab_in_BP_n_scat_p_in_zero_index = is_configuration_accepted_tab.index_determine (BPp , n_scat_p_in , 0);

	  const unsigned int dimensions_SDp_Mp_fixed_BP_n_scat_p_in_zero_index = dimensions_SDp_Mp_fixed.index_determine(BPp , n_scat_p_in , 0);

	  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_BP_n_scat_p_tab_in_zero_index = sum_dimensions_configuration_Mp_Mn_fixed_tab.index_determine(BPp , n_scat_p_in , 0);

	  const unsigned int iCp_in_min = iCp_in_min_tab(BPp , n_scat_p_in);
	  const unsigned int iCp_in_max = iCp_in_max_tab(BPp , n_scat_p_in);
			  
	  for (unsigned int iCp_in = iCp_in_min ; iCp_in <= iCp_in_max ; iCp_in++)
	    {
	      const unsigned int is_configuration_accepted_tab_in_index = is_configuration_accepted_tab_in_BP_n_scat_p_in_zero_index + iCp_in;
	      const bool is_configuration_accepted_in = is_configuration_accepted_tab[is_configuration_accepted_tab_in_index];

	      if (is_configuration_accepted_in)
		{
		  const unsigned int dimensions_SDp_Mp_fixed_in_index = dimensions_SDp_Mp_fixed_BP_n_scat_p_in_zero_index + iCp_in;

		  const unsigned int dimension_inSDp = dimensions_SDp_Mp_fixed[dimensions_SDp_Mp_fixed_in_index];
				  
		  if (dimension_inSDp == 0) continue;

		  const unsigned int dimension_inSDp_minus_one = dimension_inSDp - 1;

		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in_index = sum_dimensions_configuration_Mp_Mn_fixed_BP_n_scat_p_tab_in_zero_index + iCp_in;

		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_configuration_Mp_Mn_fixed_tab[sum_dimensions_configuration_Mp_Mn_fixed_in_index];

		  const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in + SDn_index;

		  const unsigned long int total_PSI_in_index_dimension_minus_one = total_PSI_in_index_zero + dimension_SDn*dimension_inSDp_minus_one;

		  if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
		    {
		      for (unsigned int inSDp_index = 0 ; inSDp_index < dimension_inSDp ; inSDp_index++)
			{
			  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero + dimension_SDn*inSDp_index;
					      
			  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
			    {
			      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
					      
			      one_jump_p.one_jump_mu_store (BPp , iMp , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp , n_scat_p_in , iCp_in , iMp , inSDp_index , prot_data);

			      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();

			      unsigned long int total_PSI_out_index_zero = 0;

			      bool is_configuration_accepted = true;
					      
			      for (unsigned int i = 0 ; i < dimension_one_jump_p ; i++)
				{
				  const class jumps_data_outSD_str &one_jump_p_outSDp = one_jump_p(i);

				  const bool is_configuration_changing = one_jump_p_outSDp.get_is_configuration_changing ();

				  if (is_configuration_changing)
				    { 
				      const int n_holes_p_out = one_jump_p_outSDp.get_n_holes ();
				      
				      const int n_scat_p_out = one_jump_p_outSDp.get_n_scat ();

				      const int Ep_hw_out = one_jump_p_outSDp.get_E_hw ();

				      is_configuration_accepted = is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw);

				      if (is_configuration_accepted) 
					{
					  const unsigned int iCp_out = one_jump_p_outSDp.get_iC ();

					  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , n_scat_p_out , n_scat_n , iCp_out , iCn , iMp);
						      
					  total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + SDn_index;
					}
				    }
				  
				  if (is_configuration_accepted)
				    {
				      const unsigned int outSDp_index = one_jump_p_outSDp.get_outSD_index ();
						  
				      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + dimension_SDn*outSDp_index;

				      const unsigned int square_row_index = square_row_index_determine_hybrid_1D_2D (total_PSI_out_index , first_total_PSI_indices , last_total_PSI_indices);
				      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);

				      if (is_square_occupied)
					{
					  const unsigned long int first_total_PSI_out_index = first_total_PSI_indices(square_row_index);

					  const bool is_it_diagonal_square = is_it_diagonal_square_determine_hybrid_1D_2D (is_it_MPI_parallelized_local , square_row_index);		      
					  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

					  if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index))
					    {
					      const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
					      
					      const unsigned int p_in  = one_jump_p_outSDp.get_mu_in ();
					      const unsigned int p_out = one_jump_p_outSDp.get_mu_out ();

					      const unsigned int total_bin_phase_p = one_jump_p_outSDp.get_total_bin_phase ();
					      
					      const bool NBME_pn_one_jump_p_no_phase_calculated = NBMEs_pn_one_jump_p_no_phase_calculated(p_in , p_out);

					      const int total_phase_p = parity_from_binary_parity (total_bin_phase_p);
				      
					      const unsigned int non_zero_NBMEs_index_one_jump = squares_non_zero_NBMEs_one_jump_numbers(occupied_squares_row_index , PSI_out_index)++;
							      
					      unsigned int *const square_non_zero_NBMEs_one_jump_PSI_column_indices = squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables(occupied_squares_row_index , PSI_out_index);

					      TYPE *const square_non_zero_NBMEs_one_jump = squares_non_zero_NBMEs_one_jump_tables(occupied_squares_row_index , PSI_out_index);  
								  
					      if (square_non_zero_NBMEs_one_jump_PSI_column_indices[non_zero_NBMEs_index_one_jump] != PSI_in_index)
						error_message_print_abort ("Problem with PSI_in_index in H_class:one_jump_p_pn_part_calc_store");
						
					      if (!NBME_pn_one_jump_p_no_phase_calculated)
						{ 
						  const TYPE NBME_pn_one_jump_p_no_phase = H_NBMEs::pn_no_phase_one_jump_p_calc (p_in , p_out , SDn , TBMEs_pn);

						  NBMEs_pn_one_jump_p_no_phase(p_in , p_out) = NBMEs_pn_one_jump_p_no_phase(p_out , p_in) = NBME_pn_one_jump_p_no_phase;
						  NBMEs_pn_one_jump_p_no_phase_calculated(p_in , p_out) = NBMEs_pn_one_jump_p_no_phase_calculated(p_out , p_in) = true;
					  
						  (total_phase_p == 1)
						    ? (square_non_zero_NBMEs_one_jump[non_zero_NBMEs_index_one_jump] += NBME_pn_one_jump_p_no_phase)
						    : (square_non_zero_NBMEs_one_jump[non_zero_NBMEs_index_one_jump] -= NBME_pn_one_jump_p_no_phase);
						}	      
					      else
						{
						  const TYPE NBME_pn_one_jump_p_no_phase = NBMEs_pn_one_jump_p_no_phase(p_in , p_out);
						  
						  (total_phase_p == 1)
						    ? (square_non_zero_NBMEs_one_jump[non_zero_NBMEs_index_one_jump] += NBME_pn_one_jump_p_no_phase)
						    : (square_non_zero_NBMEs_one_jump[non_zero_NBMEs_index_one_jump] -= NBME_pn_one_jump_p_no_phase);
						}}}}}}}}}}}}
}








void H_class::one_jump_n_pn_part_pn_calc_store ()
{  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
    
  const class array<bool> &MPI_are_squares_occupied = GSM_vector_helper.get_MPI_are_squares_occupied ();

  const class array<unsigned int> &MPI_occupied_squares_row_indices = GSM_vector_helper.get_MPI_occupied_squares_row_indices ();
	
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int iM = GSM_vector_helper.get_iM (); 
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
  
  const unsigned int dimension_n_1p1h_space_BP_iM_fixed_max = neut_data.get_dimension_1p1h_space_BP_iM_fixed_max ();
    
  const unsigned int Nn_nljm = neut_data.get_N_nljm ();
        
  const unsigned int dimension_configuration_total_n = neut_data.get_dimension_configuration_total ();

  const class array<unsigned int> &sum_dimensions_configuration_set_n = neut_data.get_sum_dimensions_configuration_set ();
  
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const class array<unsigned long int> &first_total_PSI_indices = GSM_vector_helper.get_first_total_PSI_indices ();
  const class array<unsigned long int> &last_total_PSI_indices = GSM_vector_helper.get_last_total_PSI_indices ();

  const class array<class SD_quantum_numbers> &SD_quantum_numbers_prot_tab = prot_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_in_min_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_in_max_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int total_SDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_SDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();
      
  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn ();
  
  if (total_SDp_index_min > total_SDp_index_max) return;
  
  class array<class array_BP_Nscat_iC<bool> > is_configuration_accepted_tabs(NUMBER_OF_THREADS);
	      
  class array<class array_BP_Nscat_iC<unsigned int> > dimensions_SDn_Mn_fixed_tab(NUMBER_OF_THREADS);

  class array<class array_BP_Nscat_iC<unsigned int> > sum_dimensions_configuration_Mp_Mn_fixed_tabs(NUMBER_OF_THREADS);
  
  class array<class Slater_determinant> SDp_tab(NUMBER_OF_THREADS);
  
  class array<class jumps_data_in_to_out_str> one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > NBMEs_pn_one_jump_n_no_phase_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > NBMEs_pn_one_jump_n_no_phase_calculated_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SDp_tab(i).allocate (Zval);
      
      is_configuration_accepted_tabs(i).allocate (dimension_configuration_total_n , sum_dimensions_configuration_set_n);
	      
      dimensions_SDn_Mn_fixed_tab(i).allocate (dimension_configuration_total_n , sum_dimensions_configuration_set_n);

      sum_dimensions_configuration_Mp_Mn_fixed_tabs(i).allocate (dimension_configuration_total_n , sum_dimensions_configuration_set_n);
      
      one_jump_n_tab(i).allocate (ONE_JUMP , PROTONS_NEUTRONS , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_iM_fixed_max);

      NBMEs_pn_one_jump_n_no_phase_tab(i).allocate (Nn_nljm , Nn_nljm);

      NBMEs_pn_one_jump_n_no_phase_calculated_tab(i).allocate (Nn_nljm , Nn_nljm);
    }

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_SDp_index = total_SDp_index_min ; total_SDp_index <= total_SDp_index_max ; total_SDp_index++)
    {
      const class SD_quantum_numbers &SDp_qn = SD_quantum_numbers_prot_tab(total_SDp_index);

      const int iMp = SDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = SDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int n_scat_p = SDp_qn.get_n_scat ();
	
      const unsigned int iCp = SDp_qn.get_iC ();

      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);

      if (dimension_SDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , n_scat_p , iCp , iMp);

      if (all_dimensions_SDn_zero) continue;

      const int iMn = iM - iMp;

      const unsigned int SDp_index = SDp_qn.get_SD_index ();
            
      const unsigned int i_thread = OpenMP_thread_number_determine ();
  
      class Slater_determinant &SDp = SDp_tab(i_thread);
      
      class array_BP_Nscat_iC<bool> &is_configuration_accepted_tab = is_configuration_accepted_tabs(i_thread);
	      
      class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_Mn_fixed = dimensions_SDn_Mn_fixed_tab(i_thread);

      class array_BP_Nscat_iC<unsigned int> &sum_dimensions_configuration_Mp_Mn_fixed_tab = sum_dimensions_configuration_Mp_Mn_fixed_tabs(i_thread);
      
      class jumps_data_in_to_out_str &one_jump_n = one_jump_n_tab(i_thread);
	      
      class array<TYPE> &NBMEs_pn_one_jump_n_no_phase = NBMEs_pn_one_jump_n_no_phase_tab(i_thread);

      class array<bool> &NBMEs_pn_one_jump_n_no_phase_calculated = NBMEs_pn_one_jump_n_no_phase_calculated_tab(i_thread);
	      
      is_configuration_accepted_neut_fill (n_holes_p , n_scat_p , Ep , BPn , GSM_vector_helper , is_configuration_accepted_tab);
	      
      dimensions_SDn_sum_dimensions_configuration_Mp_Mn_fixed_neut_fill (BPp , n_scat_p , iCp , iMp , GSM_vector_helper , is_configuration_accepted_tab ,
									 dimensions_SDn_Mn_fixed , sum_dimensions_configuration_Mp_Mn_fixed_tab);
	      
      SDp = SDp_set(BPp , n_scat_p , iCp , iMp , SDp_index);
      
      NBMEs_pn_one_jump_n_no_phase = 0.0;

      NBMEs_pn_one_jump_n_no_phase_calculated = false;
 
      for (int n_scat_n_in = 0 ; n_scat_n_in <= n_scat_max_n ; n_scat_n_in++)
	{
	  const unsigned int is_configuration_accepted_tab_in_BP_n_scat_n_in_zero_index = is_configuration_accepted_tab.index_determine(BPn , n_scat_n_in , 0);

	  const unsigned int dimensions_SDn_Mn_fixed_BP_n_scat_n_in_zero_index = dimensions_SDn_Mn_fixed.index_determine(BPn , n_scat_n_in , 0);

	  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_BP_n_scat_n_tab_in_zero_index = sum_dimensions_configuration_Mp_Mn_fixed_tab.index_determine(BPn , n_scat_n_in , 0);

	  const unsigned int iCn_in_min = iCn_in_min_tab(BPn , n_scat_n_in);
	  const unsigned int iCn_in_max = iCn_in_max_tab(BPn , n_scat_n_in);
		  
	  for (unsigned int iCn_in = iCn_in_min ; iCn_in <= iCn_in_max ; iCn_in++)
	    {
	      const unsigned int is_configuration_accepted_tab_in_index = is_configuration_accepted_tab_in_BP_n_scat_n_in_zero_index + iCn_in;

	      const bool is_configuration_accepted_in = is_configuration_accepted_tab[is_configuration_accepted_tab_in_index];

	      if (is_configuration_accepted_in)
		{
		  const unsigned int dimensions_SDn_Mn_fixed_in_index = dimensions_SDn_Mn_fixed_BP_n_scat_n_in_zero_index + iCn_in;

		  const unsigned int dimension_inSDn = dimensions_SDn_Mn_fixed[dimensions_SDn_Mn_fixed_in_index];

		  if (dimension_inSDn == 0) continue;

		  const unsigned int dimension_inSDn_minus_one = dimension_inSDn - 1;

		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in_index = sum_dimensions_configuration_Mp_Mn_fixed_BP_n_scat_n_tab_in_zero_index + iCn_in;

		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_configuration_Mp_Mn_fixed_tab[sum_dimensions_configuration_Mp_Mn_fixed_in_index];

		  const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*SDp_index;

		  const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_inSDn_minus_one;

		  if ((total_PSI_index_zero <= last_total_PSI_in_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_in_index))
		    {							      
		      for (unsigned int inSDn_index = 0 ; inSDn_index < dimension_inSDn ; inSDn_index++)
			{
			  const unsigned long int total_PSI_in_index = total_PSI_index_zero + inSDn_index;

			  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
			    {
			      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
 
			      one_jump_n.one_jump_mu_store (BPn , iMn , n_holes_max_n , n_scat_max_n , En_max_hw , BPn , n_scat_n_in , iCn_in , iMn , inSDn_index , neut_data);

			      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
			      
			      unsigned long int total_PSI_out_index_zero = 0;
					      
			      bool is_configuration_accepted = true;
						
			      for (unsigned int i = 0 ; i < dimension_one_jump_n ; i++)
				{
				  const class jumps_data_outSD_str &one_jump_n_outSDn = one_jump_n(i);

				  const bool is_configuration_changing = one_jump_n_outSDn.get_is_configuration_changing ();

				  if (is_configuration_changing)
				    { 
				      const int n_holes_n_out = one_jump_n_outSDn.get_n_holes ();

				      const int n_scat_n_out = one_jump_n_outSDn.get_n_scat ();

				      const int En_hw_out = one_jump_n_outSDn.get_E_hw ();

				      is_configuration_accepted = is_basis_state_in_space_pn (truncation_hw , truncation_ph ,
											      n_holes_p     , n_scat_p     , Ep ,
											      n_holes_n_out , n_scat_n_out , En_hw_out ,
											      n_holes_max   , n_scat_max   , E_max_hw); 

				      if (is_configuration_accepted)
					{
					  const unsigned int iCn_out = one_jump_n_outSDn.get_iC ();

					  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , n_scat_p , n_scat_n_out , iCp , iCn_out , iMp);

					  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , n_scat_n_out , iCn_out , iMn);
							  
					  total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*SDp_index;
					}
				    }

				  if (is_configuration_accepted)
				    {
				      const unsigned int outSDn_index = one_jump_n_outSDn.get_outSD_index ();
				      
				      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDn_index;
				      
				      const unsigned int square_row_index = square_row_index_determine_hybrid_1D_2D (total_PSI_out_index , first_total_PSI_indices , last_total_PSI_indices);

				      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);

				      if (is_square_occupied)
					{
					  const unsigned long int first_total_PSI_out_index = first_total_PSI_indices(square_row_index);

					  const bool is_it_diagonal_square = is_it_diagonal_square_determine_hybrid_1D_2D (is_it_MPI_parallelized_local , square_row_index);		      
					  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
					      
					  if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index))
					    {
					      const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
					      
					      const unsigned int n_in  = one_jump_n_outSDn.get_mu_in ();
					      const unsigned int n_out = one_jump_n_outSDn.get_mu_out ();

					      const unsigned int total_bin_phase_n = one_jump_n_outSDn.get_total_bin_phase ();
					      
					      const bool NBME_pn_one_jump_n_no_phase_calculated = NBMEs_pn_one_jump_n_no_phase_calculated(n_in , n_out);

					      const int total_phase_n = parity_from_binary_parity (total_bin_phase_n);
				      
					      const unsigned int non_zero_NBMEs_index_one_jump = squares_non_zero_NBMEs_one_jump_numbers(occupied_squares_row_index , PSI_out_index)++;
							   
					      unsigned int *const square_non_zero_NBMEs_one_jump_PSI_column_indices = squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables(occupied_squares_row_index , PSI_out_index);

					      TYPE *const square_non_zero_NBMEs_one_jump = squares_non_zero_NBMEs_one_jump_tables(occupied_squares_row_index , PSI_out_index);								  

					      if (square_non_zero_NBMEs_one_jump_PSI_column_indices[non_zero_NBMEs_index_one_jump] != PSI_in_index)
						error_message_print_abort ("Problem with PSI_in_index in H_class:one_jump_n_pn_part_calc_store");
					       
					      if (!NBME_pn_one_jump_n_no_phase_calculated)
						{
						  const TYPE NBME_pn_one_jump_n_no_phase = H_NBMEs::pn_no_phase_one_jump_n_calc (n_in , n_out , SDp , TBMEs_pn);

						  NBMEs_pn_one_jump_n_no_phase(n_in , n_out) = NBMEs_pn_one_jump_n_no_phase(n_out , n_in) = NBME_pn_one_jump_n_no_phase;
						  
						  NBMEs_pn_one_jump_n_no_phase_calculated(n_in , n_out) = NBMEs_pn_one_jump_n_no_phase_calculated(n_out , n_in) = true;

						  (total_phase_n == 1)
						    ? (square_non_zero_NBMEs_one_jump[non_zero_NBMEs_index_one_jump] += NBME_pn_one_jump_n_no_phase)
						    : (square_non_zero_NBMEs_one_jump[non_zero_NBMEs_index_one_jump] -= NBME_pn_one_jump_n_no_phase);
						}
					      else
						{
						  const TYPE NBME_pn_one_jump_n_no_phase = NBMEs_pn_one_jump_n_no_phase(n_in , n_out);

						  (total_phase_n == 1)
						    ? (square_non_zero_NBMEs_one_jump[non_zero_NBMEs_index_one_jump] += NBME_pn_one_jump_n_no_phase)
						    : (square_non_zero_NBMEs_one_jump[non_zero_NBMEs_index_one_jump] -= NBME_pn_one_jump_n_no_phase);
						}}}}}}}}}}}}
}








void H_class::two_jumps_pn_part_pn_N_valence_larger_calc_store ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class array<bool> &MPI_are_squares_occupied = GSM_vector_helper.get_MPI_are_squares_occupied ();

  const class array<unsigned int> &MPI_occupied_squares_row_indices = GSM_vector_helper.get_MPI_occupied_squares_row_indices ();
      
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 
        
  const bool are_M_TBMEs_stored = (M_TBMEs_storage == FULL_STORAGE);
  
  const unsigned int dimension_SDp_max = prot_data.get_dimension_SD_max ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  
  const unsigned int dimension_p_1p1h_space_BP_iM_fixed_max = prot_data.get_dimension_1p1h_space_BP_iM_fixed_max (); 
  const unsigned int dimension_n_1p1h_space_BP_iM_fixed_max = neut_data.get_dimension_1p1h_space_BP_iM_fixed_max ();
    
  const int two_mp_max = prot_data.get_two_m_max ();
  const int two_mn_max = neut_data.get_two_m_max ();
  
  const int four_mp_max = prot_data.get_four_m_max ();
  const int four_mn_max = neut_data.get_four_m_max ();
  
  const int mp_max_minus_mp_min = prot_data.get_m_max_minus_m_min ();

  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const array<unsigned long int> &first_total_PSI_indices = GSM_vector_helper.get_first_total_PSI_indices ();
  const array<unsigned long int> &last_total_PSI_indices = GSM_vector_helper.get_last_total_PSI_indices ();
  
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const class array<unsigned int> &iCp_in_min_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_in_max_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_in_min_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_in_max_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn ();
  
  class array<class array<class jumps_data_in_to_out_str> > one_jump_p_tabs_local(NUMBER_OF_THREADS);
  
  class array<class jumps_data_in_to_out_str> one_jump_n_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      class array<class jumps_data_in_to_out_str> &one_jump_p_tab = one_jump_p_tabs_local(i);

      one_jump_p_tab.allocate (dimension_SDp_max);
	
      for (unsigned int ip = 0 ; ip < dimension_SDp_max ; ip++) one_jump_p_tab(ip).allocate (ONE_JUMP , PROTONS_NEUTRONS , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_iM_fixed_max);
      
      one_jump_n_tab(i).allocate (ONE_JUMP , PROTONS_NEUTRONS , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_iM_fixed_max);
    }
    
  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
    {
      const unsigned int BPn_in = binary_parity_product (BPp_in , BP);

      for (int iMp_in = iMp_min_M ; iMp_in <= iMp_max_M ; iMp_in++)
	{
	  const int iMn_in = iM - iMp_in;

	  const int iMp_out_min_M = max (iMp_min_M , iMp_in - mp_max_minus_mp_min);
	  const int iMp_out_max_M = min (iMp_max_M , iMp_in + mp_max_minus_mp_min);

	  const unsigned int BPp_iMp_out_number = (iMp_out_max_M >= iMp_out_min_M) ? (2*(iMp_out_max_M - iMp_out_min_M) + 2) : (0);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif      
	  for (unsigned int BPp_iMp_out_index = 0 ; BPp_iMp_out_index < BPp_iMp_out_number ; BPp_iMp_out_index++)
	    {	  
	      const unsigned int BPp_out = BPp_iMp_out_index%2;

	      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);

	      const int iMp_out_shift = make_int (BPp_iMp_out_index/2);

	      const int iMp_out = iMp_out_min_M + iMp_out_shift;

	      const int iMn_out = iM - iMp_out;

	      const int Delta_iMn_out = iMn_out - iMn_in + two_mn_max;
	      const int Delta_iMp_out = iMp_out - iMp_in + two_mp_max;

	      if ((Delta_iMp_out < 0) || (Delta_iMp_out > four_mp_max)) continue;
	      if ((Delta_iMn_out < 0) || (Delta_iMn_out > four_mn_max)) continue;
	      
	      const unsigned int i_thread = OpenMP_thread_number_determine ();

	      class array<class jumps_data_in_to_out_str> &one_jump_p_tab = one_jump_p_tabs_local(i_thread);
	      
	      class jumps_data_in_to_out_str &one_jump_n = one_jump_n_tab(i_thread);
				      
	      for (int n_scat_p_in = 0 ; n_scat_p_in <= n_scat_max_p ; n_scat_p_in++)
		{
		  const unsigned int iCp_in_min = iCp_in_min_tab(BPp_in , n_scat_p_in);
		  const unsigned int iCp_in_max = iCp_in_max_tab(BPp_in , n_scat_p_in);
		  
		  for (unsigned int iCp_in = iCp_in_min ; iCp_in <= iCp_in_max ; iCp_in++)
		    {
		      const int n_holes_p_in = n_holes_p_table(BPp_in , n_scat_p_in , iCp_in);
		      
		      const int Ep_in = Ep_hw_table(BPp_in , n_scat_p_in , iCp_in);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_in , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
		      for (int n_scat_n_in = 0 ; n_scat_n_in <= n_scat_max_n ; n_scat_n_in++)
			{
			  const unsigned int iCn_in_min = iCn_in_min_tab(BPn_in , n_scat_n_in);
			  const unsigned int iCn_in_max = iCn_in_max_tab(BPn_in , n_scat_n_in);
			  
			  for (unsigned int iCn_in = iCn_in_min ; iCn_in <= iCn_in_max ; iCn_in++)
			    {
			      const int n_holes_n_in = n_holes_n_table(BPn_in , n_scat_n_in , iCn_in);
			      
			      const int En_in = En_hw_table(BPn_in , n_scat_n_in , iCn_in);
			      
			      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph ,
							      n_holes_p_in  , n_scat_p_in , Ep_in ,
							      n_holes_n_in  , n_scat_n_in , En_in ,
							      n_holes_max   , n_scat_max  , E_max_hw))
				{
				  const unsigned int dimension_inSDp = dimensions_SDp_set(BPp_in , n_scat_p_in , iCp_in , iMp_in);
				  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , n_scat_n_in , iCn_in , iMn_in);
				  
				  if ((dimension_inSDp == 0) || (dimension_inSDn == 0)) continue;
				  
				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);

				  const unsigned int dimension_inSDp_minus_one = dimension_inSDp - 1;
				  const unsigned int dimension_inSDn_minus_one = dimension_inSDn - 1;

				  const unsigned int dimensions_inSDn_inSDp_minus_one_product = dimension_inSDn*dimension_inSDp_minus_one;
			      
				  const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in;
			      
				  const unsigned long int total_PSI_in_index_dimension_minus_one = sum_dimensions_configuration_Mp_Mn_fixed_in + dimensions_inSDn_inSDp_minus_one_product + dimension_inSDn_minus_one;
 
				  if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
				    {
				      for (unsigned int inSDp_index = 0 ; inSDp_index < dimension_inSDp ; inSDp_index++)
					{
					  const unsigned long int total_PSI_in_index_zero_inSDp_fixed = total_PSI_in_index_zero + dimension_inSDn*inSDp_index;

					  const unsigned long int total_PSI_in_index_dimension_minus_one_inSDp_fixed = total_PSI_in_index_zero_inSDp_fixed + dimension_inSDn_minus_one;
					  
					  if ((total_PSI_in_index_zero_inSDp_fixed <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one_inSDp_fixed >= first_total_PSI_in_index))
					    {
					      class jumps_data_in_to_out_str &one_jump_p = one_jump_p_tab(inSDp_index);

					      if (!one_jump_p.is_it_filled ()) one_jump_p.allocate (ONE_JUMP , PROTONS_NEUTRONS , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_iM_fixed_max);
					      
					      one_jump_p.one_jump_mu_store (BPp_out , iMp_out , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp_in , n_scat_p_in , iCp_in , iMp_in , inSDp_index , prot_data);
					    }
					}
				      
				      for (unsigned int inSDn_index = 0 ; inSDn_index < dimension_inSDn ; inSDn_index++)
					{
					  const unsigned long int total_PSI_in_index_zero_inSDn_fixed = total_PSI_in_index_zero + inSDn_index;

					  const unsigned long int total_PSI_in_index_dimension_minus_one_inSDn_fixed = total_PSI_in_index_zero_inSDn_fixed + dimensions_inSDn_inSDp_minus_one_product;
					  
					  if ((total_PSI_in_index_zero_inSDn_fixed <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one_inSDn_fixed >= first_total_PSI_in_index))
					    {	
					      bool is_one_jump_n_calculated = false;
					      
					      for (unsigned int inSDp_index = 0 ; inSDp_index < dimension_inSDp ; inSDp_index++)
						{
						  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDn_fixed + dimension_inSDn*inSDp_index;
					      
						  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						    {						      
						      if (!is_one_jump_n_calculated)
							{
							  one_jump_n.one_jump_mu_store (BPn_out , iMn_out , n_holes_max_n , n_scat_max_n , En_max_hw , BPn_in , n_scat_n_in , iCn_in , iMn_in , inSDn_index , neut_data);

							  is_one_jump_n_calculated = true;
							}
						      
						      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

						      if (dimension_one_jump_n == 0) continue;
						      
						      const class jumps_data_in_to_out_str &one_jump_p = one_jump_p_tab(inSDp_index);

						      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();

						      if (dimension_one_jump_p == 0) continue;
						      				      
						      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
						      
						      unsigned long int total_PSI_out_index_zero_outSDn = 0;
						      
						      bool is_configuration_accepted = true;
							  
						      for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
							{
							  const class jumps_data_outSD_str &one_jump_p_outSDp = one_jump_p(ip);

							  const unsigned int iCp_out = one_jump_p_outSDp.get_iC ();

							  const unsigned int outSDp_index = one_jump_p_outSDp.get_outSD_index ();

							  const int n_holes_p_out = one_jump_p_outSDp.get_n_holes ();
							  
							  const int n_scat_p_out = one_jump_p_outSDp.get_n_scat ();

							  const int Ep_hw_out = one_jump_p_outSDp.get_E_hw ();

							  const unsigned int p_in = one_jump_p_outSDp.get_mu_in ();
							  const unsigned int p_out = one_jump_p_outSDp.get_mu_out ();

							  const class nljm_struct &phi_p_out = phi_p_table(p_out);
  
							  const unsigned int p_out_shell = phi_p_out.get_shell_index ();
					  
							  const unsigned int total_bin_phase_p = one_jump_p_outSDp.get_total_bin_phase ();
				      
							  for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)
							    {
							      const class jumps_data_outSD_str &one_jump_n_outSDn = one_jump_n(in);

							      const bool is_configuration_changing = one_jump_n_outSDn.get_is_configuration_changing ();

							      if (is_configuration_changing) 
								{
								  const int n_holes_n_out = one_jump_n_outSDn.get_n_holes ();
								  
								  const int n_scat_n_out = one_jump_n_outSDn.get_n_scat ();
								  
								  const int En_hw_out = one_jump_n_outSDn.get_E_hw ();
								      
								  is_configuration_accepted = true;
									  
								  if (truncation_hw && (Ep_hw_out + En_hw_out > E_max_hw)) is_configuration_accepted = false;
								  
								  if (truncation_ph && ((n_holes_p_out + n_holes_n_out > n_holes_max) || (n_scat_p_out + n_scat_n_out > n_scat_max))) is_configuration_accepted = false;
								      
								  if (is_configuration_accepted) 
								    {
								      const unsigned int iCn_out = one_jump_n_outSDn.get_iC ();
								      
								      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);
								      
								      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
				  
								      total_PSI_out_index_zero_outSDn = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;
								    }
								}

							      if (is_configuration_accepted)
								{
								  const unsigned int outSDn_index = one_jump_n_outSDn.get_outSD_index ();

								  const unsigned long int total_PSI_out_index = total_PSI_out_index_zero_outSDn + outSDn_index;

								  const unsigned int square_row_index = square_row_index_determine_hybrid_1D_2D (total_PSI_out_index , first_total_PSI_indices , last_total_PSI_indices);

								  const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
								      
								  if (is_square_occupied)
								    {	
								      const unsigned long int first_total_PSI_out_index = first_total_PSI_indices(square_row_index);
										  
								      const bool is_it_diagonal_square = is_it_diagonal_square_determine_hybrid_1D_2D (is_it_MPI_parallelized_local , square_row_index);		      

								      const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
						  
								      if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index))
									{
									  const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
									  
									  const unsigned int n_in  = one_jump_n_outSDn.get_mu_in ();
									  const unsigned int n_out = one_jump_n_outSDn.get_mu_out ();

									  const unsigned int total_bin_phase_n = one_jump_n_outSDn.get_total_bin_phase ();
										  
									  unsigned int *const square_non_zero_NBMEs_PSI_column_indices = squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables(occupied_squares_row_index , PSI_out_index);
									  
									  const unsigned int non_zero_NBMEs_index_two_jumps = squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_out_index)++;
									  
									  square_non_zero_NBMEs_PSI_column_indices[non_zero_NBMEs_index_two_jumps] = PSI_in_index;

									  if (are_M_TBMEs_stored)
									    {
									      unsigned int *const square_non_zero_NBMEs_indices = squares_non_zero_NBMEs_two_jumps_indices_tables(occupied_squares_row_index , PSI_out_index);
									  
									      const unsigned int total_bin_phase = binary_parity_product (total_bin_phase_p , total_bin_phase_n);
									  
									      const unsigned int TBME_index = M_TBMEs_pn_indices(p_in , n_in , p_out_shell , n_out);
									      
									      const unsigned int NBME_index = total_bin_phase + 2*TBME_index;
						  
									      square_non_zero_NBMEs_indices[non_zero_NBMEs_index_two_jumps] = NBME_index;
									    }
									  else
									    {
									      TYPE *const square_non_zero_NBMEs = squares_non_zero_NBMEs_two_jumps_tables(occupied_squares_row_index , PSI_out_index);
									  
									      const TYPE TBME = TBMEs_pn.M_TBME (p_in , n_in , p_out , n_out);
									      
									      const TYPE NBME = (total_bin_phase_p == total_bin_phase_n) ? (TBME) : (-TBME);
						  
									      square_non_zero_NBMEs[non_zero_NBMEs_index_two_jumps] = NBME;
									    }									  
									}}}}}}}}}}}}}}}}}}
}






void H_class::two_jumps_pn_part_pn_Z_valence_larger_calc_store ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class array<bool> &MPI_are_squares_occupied = GSM_vector_helper.get_MPI_are_squares_occupied ();

  const class array<unsigned int> &MPI_occupied_squares_row_indices = GSM_vector_helper.get_MPI_occupied_squares_row_indices ();
      
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 
    
  const bool are_M_TBMEs_stored = (M_TBMEs_storage == FULL_STORAGE);
      
  const unsigned int dimension_SDn_max = neut_data.get_dimension_SD_max ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();
  
  const unsigned int dimension_p_1p1h_space_BP_iM_fixed_max = prot_data.get_dimension_1p1h_space_BP_iM_fixed_max (); 
  const unsigned int dimension_n_1p1h_space_BP_iM_fixed_max = neut_data.get_dimension_1p1h_space_BP_iM_fixed_max ();
    
  const int two_mp_max = prot_data.get_two_m_max ();
  const int two_mn_max = neut_data.get_two_m_max ();
  
  const int four_mp_max = prot_data.get_four_m_max ();
  const int four_mn_max = neut_data.get_four_m_max ();
  
  const int mp_max_minus_mp_min = prot_data.get_m_max_minus_m_min ();
  
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const array<unsigned long int> &first_total_PSI_indices = GSM_vector_helper.get_first_total_PSI_indices ();
  const array<unsigned long int> &last_total_PSI_indices = GSM_vector_helper.get_last_total_PSI_indices ();
  
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const class array<unsigned int> &iCp_in_min_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_in_max_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_in_min_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_in_max_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn ();
  
  class array<class array<class jumps_data_in_to_out_str> > one_jump_n_tabs_local(NUMBER_OF_THREADS);

  class array<class jumps_data_in_to_out_str> one_jump_p_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      class array<class jumps_data_in_to_out_str> &one_jump_n_tab = one_jump_n_tabs_local(i);

      one_jump_n_tab.allocate (dimension_SDn_max);
	
      for (unsigned int in = 0 ; in < dimension_SDn_max ; in++) one_jump_n_tab(in).allocate (ONE_JUMP , PROTONS_NEUTRONS , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_iM_fixed_max);
      
      one_jump_p_tab(i).allocate (ONE_JUMP , PROTONS_NEUTRONS , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_iM_fixed_max);
    }
  
  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
    {
      const unsigned int BPn_in = binary_parity_product (BPp_in , BP);

      for (int iMp_in = iMp_min_M ; iMp_in <= iMp_max_M ; iMp_in++)
	{
	  const int iMn_in = iM - iMp_in;

	  const int iMp_out_min_M = max (iMp_min_M , iMp_in - mp_max_minus_mp_min);
	  const int iMp_out_max_M = min (iMp_max_M , iMp_in + mp_max_minus_mp_min);

	  const unsigned int BPp_iMp_out_number = (iMp_out_max_M >= iMp_out_min_M) ? (2*(iMp_out_max_M - iMp_out_min_M) + 2) : (0);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif      
	  for (unsigned int BPp_iMp_out_index = 0 ; BPp_iMp_out_index < BPp_iMp_out_number ; BPp_iMp_out_index++)
	    {	  
	      const unsigned int BPp_out = BPp_iMp_out_index%2;
	      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);

	      const int iMp_out_shift = make_int (BPp_iMp_out_index/2);

	      const int iMp_out = iMp_out_min_M + iMp_out_shift;

	      const int iMn_out = iM - iMp_out;

	      const int Delta_iMn_out = iMn_out - iMn_in + two_mn_max;
	      const int Delta_iMp_out = iMp_out - iMp_in + two_mp_max;

	      if ((Delta_iMp_out < 0) || (Delta_iMp_out > four_mp_max)) continue;
	      if ((Delta_iMn_out < 0) || (Delta_iMn_out > four_mn_max)) continue;
	      
	      const unsigned int i_thread = OpenMP_thread_number_determine ();

	      class array<class jumps_data_in_to_out_str> &one_jump_n_tab = one_jump_n_tabs_local(i_thread);
	      
	      class jumps_data_in_to_out_str &one_jump_p = one_jump_p_tab(i_thread);	      
				      
	      for (int n_scat_p_in = 0 ; n_scat_p_in <= n_scat_max_p ; n_scat_p_in++)
		{
		  const unsigned int iCp_in_min = iCp_in_min_tab(BPp_in , n_scat_p_in);
		  const unsigned int iCp_in_max = iCp_in_max_tab(BPp_in , n_scat_p_in);
		  
		  for (unsigned int iCp_in = iCp_in_min ; iCp_in <= iCp_in_max ; iCp_in++)
		    {
		      const int n_holes_p_in = n_holes_p_table(BPp_in , n_scat_p_in , iCp_in);
		      
		      const int Ep_in = Ep_hw_table(BPp_in , n_scat_p_in , iCp_in);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_in , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
		      for (int n_scat_n_in = 0 ; n_scat_n_in <= n_scat_max_n ; n_scat_n_in++)
			{
			  const unsigned int iCn_in_min = iCn_in_min_tab(BPn_in , n_scat_n_in);
			  const unsigned int iCn_in_max = iCn_in_max_tab(BPn_in , n_scat_n_in);
			  
			  for (unsigned int iCn_in = iCn_in_min ; iCn_in <= iCn_in_max ; iCn_in++)
			    {
			      const int n_holes_n_in = n_holes_n_table(BPn_in , n_scat_n_in , iCn_in);
			      
			      const int En_in = En_hw_table(BPn_in , n_scat_n_in , iCn_in);
			      
			      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph ,
							      n_holes_p_in  , n_scat_p_in , Ep_in ,
							      n_holes_n_in  , n_scat_n_in , En_in ,
							      n_holes_max   , n_scat_max  , E_max_hw))
				{
				  const unsigned int dimension_inSDp = dimensions_SDp_set(BPp_in , n_scat_p_in , iCp_in , iMp_in);
				  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , n_scat_n_in , iCn_in , iMn_in);
				  
				  if ((dimension_inSDp == 0) || (dimension_inSDn == 0)) continue;
				  
				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);

				  const unsigned int dimension_inSDp_minus_one = dimension_inSDp - 1;
				  const unsigned int dimension_inSDn_minus_one = dimension_inSDn - 1;
			      
				  const unsigned int dimensions_inSDn_inSDp_minus_one_product = dimension_inSDn*dimension_inSDp_minus_one;

				  const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in;
				  
				  const unsigned long int total_PSI_in_index_dimension_minus_one = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*dimension_inSDp_minus_one + dimension_inSDn_minus_one;
			      
				  if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
				    {
				      for (unsigned int inSDn_index = 0 ; inSDn_index < dimension_inSDn ; inSDn_index++)
					{
					  const unsigned long int total_PSI_in_index_zero_inSDn_fixed = total_PSI_in_index_zero + inSDn_index;

					  const unsigned long int total_PSI_in_index_dimension_minus_one_inSDn_fixed = total_PSI_in_index_zero_inSDn_fixed + dimensions_inSDn_inSDp_minus_one_product;
					  
					  if ((total_PSI_in_index_zero_inSDn_fixed <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one_inSDn_fixed >= first_total_PSI_in_index))
					    {
					      class jumps_data_in_to_out_str &one_jump_n = one_jump_n_tab(inSDn_index);

					      if (!one_jump_n.is_it_filled ()) one_jump_n.allocate (ONE_JUMP , PROTONS_NEUTRONS , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_iM_fixed_max);
					      
					      one_jump_n.one_jump_mu_store (BPn_out , iMn_out , n_holes_max_n , n_scat_max_n , En_max_hw , BPn_in , n_scat_n_in , iCn_in , iMn_in , inSDn_index , neut_data);
					    }
					}
				      
				      for (unsigned int inSDp_index = 0 ; inSDp_index < dimension_inSDp ; inSDp_index++)
					{
					  const unsigned long int total_PSI_in_index_zero_inSDp_fixed = total_PSI_in_index_zero + inSDp_index*dimension_inSDn;
					  const unsigned long int total_PSI_in_index_dimension_minus_one_inSDp_fixed = total_PSI_in_index_zero_inSDp_fixed + dimension_inSDn_minus_one;

					  if ((total_PSI_in_index_zero_inSDp_fixed <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one_inSDp_fixed >= first_total_PSI_in_index))
					    {
					      bool is_one_jump_p_calculated = false;
					      
					      for (unsigned int inSDn_index = 0 ; inSDn_index < dimension_inSDn ; inSDn_index++)
						{
						  const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDp_fixed + inSDn_index;
					      
						  if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
						    {
						      if (!is_one_jump_p_calculated)
							{
							  one_jump_p.one_jump_mu_store (BPp_out , iMp_out , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp_in , n_scat_p_in , iCp_in , iMp_in , inSDp_index , prot_data);

							  is_one_jump_p_calculated = true;
							}
						      
						      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();

						      if (dimension_one_jump_p == 0) continue;
						      
						      const class jumps_data_in_to_out_str &one_jump_n = one_jump_n_tab(inSDn_index);

						      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

						      if (dimension_one_jump_n == 0) continue;

						      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
						      
						      unsigned long int total_PSI_out_index_zero_outSDp = 0;
						      
						      bool is_configuration_accepted = true;
							  
						      for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)  
							{
							  const class jumps_data_outSD_str &one_jump_n_outSDn = one_jump_n(in);

							  const unsigned int iCn_out = one_jump_n_outSDn.get_iC ();
							  
							  const unsigned int outSDn_index = one_jump_n_outSDn.get_outSD_index ();

							  const int n_holes_n_out = one_jump_n_outSDn.get_n_holes ();
							  
							  const int n_scat_n_out = one_jump_n_outSDn.get_n_scat ();

							  const int En_hw_out = one_jump_n_outSDn.get_E_hw ();

							  const unsigned int n_in  = one_jump_n_outSDn.get_mu_in ();
							  const unsigned int n_out = one_jump_n_outSDn.get_mu_out ();

							  const class nljm_struct &phi_n_out = phi_n_table(n_out);
  
							  const unsigned int n_out_shell = phi_n_out.get_shell_index ();
					  
							  const unsigned int total_bin_phase_n = one_jump_n_outSDn.get_total_bin_phase ();

							  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);
									  
							  for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)
							    {
							      const class jumps_data_outSD_str &one_jump_p_outSDp = one_jump_p(ip);
							      
							      const bool is_configuration_changing = one_jump_p_outSDp.get_is_configuration_changing ();

							      if (is_configuration_changing) 
								{
								  const int n_holes_p_out = one_jump_p_outSDp.get_n_holes ();
								  
								  const int n_scat_p_out = one_jump_p_outSDp.get_n_scat ();

								  const int Ep_hw_out = one_jump_p_outSDp.get_E_hw ();
								      
								  is_configuration_accepted = true;
									  
								  if (truncation_hw && (Ep_hw_out + En_hw_out > E_max_hw)) is_configuration_accepted = false;
								  
								  if (truncation_ph && ((n_holes_p_out + n_holes_n_out > n_holes_max) || (n_scat_p_out + n_scat_n_out > n_scat_max))) is_configuration_accepted = false;
								      
								  if (is_configuration_accepted) 
								    {
								      const unsigned int iCp_out = one_jump_p_outSDp.get_iC ();
								      
								      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
				  
								      total_PSI_out_index_zero_outSDp = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
								    }
								}

							      if (is_configuration_accepted)
								{
								  const unsigned int outSDp_index = one_jump_p_outSDp.get_outSD_index ();

								  const unsigned long int total_PSI_out_index = total_PSI_out_index_zero_outSDp + dimension_outSDn*outSDp_index;

								  const unsigned int square_row_index = square_row_index_determine_hybrid_1D_2D (total_PSI_out_index , first_total_PSI_indices , last_total_PSI_indices);

								  const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);

								  if (is_square_occupied)
								    {	
								      const unsigned long int first_total_PSI_out_index = first_total_PSI_indices(square_row_index);
										  
								      const bool is_it_diagonal_square = is_it_diagonal_square_determine_hybrid_1D_2D (is_it_MPI_parallelized_local , square_row_index);		      

								      const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

								      if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index))
									{
									  const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
									  
									  const unsigned int p_in  = one_jump_p_outSDp.get_mu_in ();
									  const unsigned int p_out = one_jump_p_outSDp.get_mu_out ();

									  const unsigned int total_bin_phase_p = one_jump_p_outSDp.get_total_bin_phase ();

									  const unsigned int non_zero_NBMEs_index_two_jumps = squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_out_index)++;
										  
									  unsigned int *const square_non_zero_NBMEs_PSI_column_indices = squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables(occupied_squares_row_index , PSI_out_index);
									  
									  square_non_zero_NBMEs_PSI_column_indices[non_zero_NBMEs_index_two_jumps] = PSI_in_index;

									  if (are_M_TBMEs_stored)
									    {
									      unsigned int *const square_non_zero_NBMEs_indices = squares_non_zero_NBMEs_two_jumps_indices_tables(occupied_squares_row_index , PSI_out_index);
									  
									      const unsigned int total_bin_phase = binary_parity_product (total_bin_phase_p , total_bin_phase_n);
									  
									      const unsigned int TBME_index = M_TBMEs_pn_indices(p_in , n_in , p_out , n_out_shell);
									      
									      const unsigned int NBME_index = total_bin_phase + 2*TBME_index;
						  
									      square_non_zero_NBMEs_indices[non_zero_NBMEs_index_two_jumps] = NBME_index;
									    }
									  else
									    {
									      TYPE *const square_non_zero_NBMEs = squares_non_zero_NBMEs_two_jumps_tables(occupied_squares_row_index , PSI_out_index);
									  
									      const TYPE TBME = TBMEs_pn.M_TBME (p_in , n_in , p_out , n_out);
									      
									      const TYPE NBME = (total_bin_phase_p == total_bin_phase_n) ? (TBME) : (-TBME);
						  
									      square_non_zero_NBMEs[non_zero_NBMEs_index_two_jumps] = NBME;
									    }
									}}}}}}}}}}}}}}}}}}
}









void H_class::jumps_part_pp_nn_calc_store ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int iM = GSM_vector_helper.get_iM (); 
        
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector (); 
  
  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);
      
  const int N_valence_nucleons = data.get_N_valence_nucleons ();
  
  const unsigned int dimension_1p1h_space_BP_iM_fixed_max = data.get_dimension_1p1h_space_BP_iM_fixed_max ();
  const unsigned int dimension_2p2h_space_BP_iM_fixed_max = data.get_dimension_2p2h_space_BP_iM_fixed_max ();
      
  const class array_BP_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const class array_of_SD &SD_set = data.get_SD_set ();
  
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index ();

  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_inSD_index_min = GSM_vector_helper.get_total_SD_index_min ();
  const unsigned long int total_inSD_index_max = GSM_vector_helper.get_total_SD_index_max ();

  const bool is_it_partial_storage = (Hamiltonian_storage == PARTIAL_STORAGE);

  const bool is_it_full_storage = (Hamiltonian_storage == FULL_STORAGE);

  if (total_inSD_index_min > total_inSD_index_max) return;
      
  class array<class Slater_determinant> inSDmu_tab(NUMBER_OF_THREADS);
  
  class array<class jumps_data_in_to_out_str> one_jump_mu_tab(NUMBER_OF_THREADS);
  class array<class jumps_data_in_to_out_str> two_jumps_mu_tab(NUMBER_OF_THREADS);
  
  class array<class array<unsigned int> > occupied_squares_row_indices_one_jump_mu_tab(NUMBER_OF_THREADS);
  class array<class array<unsigned int> > occupied_squares_row_indices_two_jumps_mu_tab(NUMBER_OF_THREADS);
  
  class array<class array<bool> > are_PSI_out_indices_accepted_one_jump_mu_tabs(NUMBER_OF_THREADS);
  class array<class array<bool> > are_PSI_out_indices_accepted_two_jumps_mu_tabs(NUMBER_OF_THREADS);
  
  class array<class array<unsigned int> > PSI_out_indices_one_jump_mu_tab(NUMBER_OF_THREADS); 
  class array<class array<unsigned int> > PSI_out_indices_two_jumps_mu_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > NBMEs_one_jump_mu_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > NBMEs_two_jumps_mu_tab(NUMBER_OF_THREADS);
   
  class array<class array<unsigned int> > NBMEs_two_jumps_indices_mu_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {            
      inSDmu_tab(i).allocate (N_valence_nucleons);
      
      one_jump_mu_tab(i).allocate (ONE_JUMP , space , truncation_hw , truncation_ph , dimension_1p1h_space_BP_iM_fixed_max);

      occupied_squares_row_indices_one_jump_mu_tab(i).allocate (dimension_1p1h_space_BP_iM_fixed_max);

      are_PSI_out_indices_accepted_one_jump_mu_tabs(i).allocate (dimension_1p1h_space_BP_iM_fixed_max);

      PSI_out_indices_one_jump_mu_tab(i).allocate (dimension_1p1h_space_BP_iM_fixed_max);

      NBMEs_one_jump_mu_tab(i).allocate (dimension_1p1h_space_BP_iM_fixed_max);
      
      if (N_valence_nucleons >= 2)
	{
	  two_jumps_mu_tab(i).allocate (TWO_JUMPS , space , truncation_hw , truncation_ph , dimension_2p2h_space_BP_iM_fixed_max);
		
	  occupied_squares_row_indices_two_jumps_mu_tab(i).allocate (dimension_2p2h_space_BP_iM_fixed_max);
	  
	  are_PSI_out_indices_accepted_two_jumps_mu_tabs(i).allocate (dimension_2p2h_space_BP_iM_fixed_max);

	  PSI_out_indices_two_jumps_mu_tab(i).allocate (dimension_2p2h_space_BP_iM_fixed_max);
		
	  if (is_it_partial_storage) NBMEs_two_jumps_indices_mu_tab(i).allocate (dimension_2p2h_space_BP_iM_fixed_max);
	  if (is_it_full_storage)    NBMEs_two_jumps_mu_tab(i).allocate (dimension_2p2h_space_BP_iM_fixed_max);
	}
    }
     
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_inSD_index = total_inSD_index_min ; total_inSD_index <= total_inSD_index_max ; total_inSD_index++)
    {
      const class SD_quantum_numbers &inSD_qn = SD_quantum_numbers_tab(total_inSD_index);
 
      const int iM_in = inSD_qn.get_iM ();

      if (iM_in != iM) continue;

      const unsigned int BP_in = inSD_qn.get_BP ();

      if (BP_in != BP) continue;
      
      const unsigned int n_scat_in = inSD_qn.get_n_scat ();

      const unsigned int iC_in = inSD_qn.get_iC ();

      const int n_holes_in = n_holes_table(BP , n_scat_in , iC_in);
      
      const int E_in = E_hw_table(BP , n_scat_in , iC_in);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_in , n_scat_in , E_in , n_holes_max , n_scat_max , E_max_hw)) continue;
      
      const unsigned int inSD_index = inSD_qn.get_SD_index ();

      const unsigned long int sum_dimensions_configuration_fixed_in = sum_dimensions_GSM_vector(n_scat_in , iC_in);

      const unsigned long int total_PSI_in_index = sum_dimensions_configuration_fixed_in + inSD_index;

      const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
	     
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	
      class Slater_determinant &inSDmu = inSDmu_tab(i_thread);
	  
      class jumps_data_in_to_out_str &one_jump_mu  = one_jump_mu_tab(i_thread);
      class jumps_data_in_to_out_str &two_jumps_mu = two_jumps_mu_tab(i_thread);
      
      class array<unsigned int> &occupied_squares_row_indices_one_jump_mu  = occupied_squares_row_indices_one_jump_mu_tab(i_thread);
      class array<unsigned int> &occupied_squares_row_indices_two_jumps_mu = occupied_squares_row_indices_two_jumps_mu_tab(i_thread);
      
      class array<bool> &are_PSI_out_indices_accepted_one_jump_mu_tab  = are_PSI_out_indices_accepted_one_jump_mu_tabs(i_thread);
      class array<bool> &are_PSI_out_indices_accepted_two_jumps_mu_tab = are_PSI_out_indices_accepted_two_jumps_mu_tabs(i_thread);
      
      class array<unsigned int> &PSI_out_indices_one_jump_mu  = PSI_out_indices_one_jump_mu_tab(i_thread); 
      class array<unsigned int> &PSI_out_indices_two_jumps_mu = PSI_out_indices_two_jumps_mu_tab(i_thread);
      
      class array<TYPE> &NBMEs_one_jump_mu  = NBMEs_one_jump_mu_tab(i_thread);
      class array<TYPE> &NBMEs_two_jumps_mu = NBMEs_two_jumps_mu_tab(i_thread);
              
      class array<unsigned int> &NBMEs_two_jumps_indices_mu = NBMEs_two_jumps_indices_mu_tab(i_thread);
  
      bool is_there_one_jump_calc = false;

      bool are_there_two_jumps_calc = false;

      inSDmu = SD_set(BP , n_scat_in , iC_in , iM , inSD_index);
	  
      NBMEs_one_jump_pp_nn_calc_store (BP , iM , n_scat_in , iC_in , inSD_index , inSDmu , data , is_there_one_jump_calc  , one_jump_mu , NBMEs_one_jump_mu);
      
      if (is_there_one_jump_calc)
	are_PSI_out_indices_accepted_PSI_out_indices_pp_nn_fill (one_jump_mu , GSM_vector_helper , PSI_in_index , are_PSI_out_indices_accepted_one_jump_mu_tab ,
								 occupied_squares_row_indices_one_jump_mu , PSI_out_indices_one_jump_mu , is_there_one_jump_calc);	    
	    
      if (is_it_partial_storage)
	NBMEs_two_jumps_indices_pp_nn_calc_store (BP , iM , n_scat_in , iC_in , inSD_index , data , are_there_two_jumps_calc , two_jumps_mu , NBMEs_two_jumps_indices_mu);
	    
      if (is_it_full_storage)
	NBMEs_two_jumps_pp_nn_calc_store (BP , iM , n_scat_in , iC_in , inSD_index , data , are_there_two_jumps_calc , two_jumps_mu , NBMEs_two_jumps_mu);
		  
      if (are_there_two_jumps_calc)
	are_PSI_out_indices_accepted_PSI_out_indices_pp_nn_fill (two_jumps_mu , GSM_vector_helper , PSI_in_index , are_PSI_out_indices_accepted_two_jumps_mu_tab ,
								 occupied_squares_row_indices_two_jumps_mu , PSI_out_indices_two_jumps_mu , are_there_two_jumps_calc);
            
#ifdef UseOpenMP
#pragma omp critical
#endif
      {
	if (is_there_one_jump_calc)
	  {
	    const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();
	    
	    Hamiltonian_part_one_jump_pp_nn_store (PSI_in_index , dimension_one_jump_mu , are_PSI_out_indices_accepted_one_jump_mu_tab , occupied_squares_row_indices_one_jump_mu , PSI_out_indices_one_jump_mu , NBMEs_one_jump_mu);
	  }
	
	if (are_there_two_jumps_calc)
	  {
	    const unsigned int dimension_two_jumps_mu = two_jumps_mu.get_dimension ();
	    
	    if (is_it_partial_storage)
	      Hamiltonian_part_two_jumps_indices_pp_nn_store (PSI_in_index , dimension_two_jumps_mu , are_PSI_out_indices_accepted_two_jumps_mu_tab ,
							      occupied_squares_row_indices_two_jumps_mu , PSI_out_indices_two_jumps_mu , NBMEs_two_jumps_indices_mu);
		  
	    if (is_it_full_storage)
	      Hamiltonian_part_two_jumps_pp_nn_store (PSI_in_index , dimension_two_jumps_mu , are_PSI_out_indices_accepted_two_jumps_mu_tab ,
						      occupied_squares_row_indices_two_jumps_mu , PSI_out_indices_two_jumps_mu , NBMEs_two_jumps_mu);
	  }
      }
    }
}





void H_class::matrix_off_diagonal_store ()
{
  class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const class GSM_vector_helper_class dummy_helper;
      
  const unsigned int MPI_occupied_squares_row_number = GSM_vector_helper.get_MPI_occupied_squares_row_number ();

  const enum space_type space = GSM_vector_helper.get_space ();

  const bool is_it_one_body = (!is_pp_non_zero && !is_nn_non_zero && !is_pn_non_zero);
  
  const unsigned int space_dimensions_all_processes_max = GSM_vector_helper.get_space_dimensions_all_processes_max ();

  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);

  class nucleons_data &prot_data = GSM_vector_helper.get_prot_data ();
  class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
    for (unsigned int PSI_index = 0 ; PSI_index < space_dimensions_all_processes_max ; PSI_index++) 
      {
	const unsigned int squares_non_zero_NBMEs_one_jump_number  = squares_non_zero_NBMEs_one_jump_numbers(occupied_squares_row_index , PSI_index);
	      
	unsigned int *const squares_non_zero_NBMEs_one_jump_PSI_column_indices_table  = squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables(occupied_squares_row_index , PSI_index);
	
	TYPE *const squares_non_zero_NBMEs_one_jump_table  = squares_non_zero_NBMEs_one_jump_tables(occupied_squares_row_index , PSI_index);
			
	for (unsigned int i = 0 ; i < squares_non_zero_NBMEs_one_jump_number ; i++)
	  {
	    squares_non_zero_NBMEs_one_jump_PSI_column_indices_table[i] = space_dimensions_all_processes_max;
	    
	    squares_non_zero_NBMEs_one_jump_table[i] = 0.0;
	  }
      }
  
  if (Hamiltonian_storage == PARTIAL_STORAGE)
    {
      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	for (unsigned int PSI_index = 0 ; PSI_index < space_dimensions_all_processes_max ; PSI_index++) 
	  {
	    const unsigned int squares_non_zero_NBMEs_two_jumps_number = squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_index);
	      
	    unsigned int *const squares_non_zero_NBMEs_two_jumps_PSI_column_indices_table = squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables(occupied_squares_row_index , PSI_index);
	
	    unsigned int *const squares_non_zero_NBMEs_two_jumps_indices_table = squares_non_zero_NBMEs_two_jumps_indices_tables(occupied_squares_row_index , PSI_index);
			
	    for (unsigned int i = 0 ; i < squares_non_zero_NBMEs_two_jumps_number ; i++)
	      {
		squares_non_zero_NBMEs_two_jumps_PSI_column_indices_table[i] = space_dimensions_all_processes_max;
		
		squares_non_zero_NBMEs_two_jumps_indices_table[i] = 0;
	      }
	  }
    }
  
  if (Hamiltonian_storage == FULL_STORAGE)
    {
      for (unsigned int occupied_squares_row_index = 0 ; occupied_squares_row_index < MPI_occupied_squares_row_number ; occupied_squares_row_index++)
	for (unsigned int PSI_index = 0 ; PSI_index < space_dimensions_all_processes_max ; PSI_index++) 
	  {
	    const unsigned int squares_non_zero_NBMEs_two_jumps_number = squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_index);
	      
	    unsigned int *const squares_non_zero_NBMEs_two_jumps_PSI_column_indices_table = squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables(occupied_squares_row_index , PSI_index);
	
	    TYPE *const squares_non_zero_NBMEs_two_jumps_table = squares_non_zero_NBMEs_two_jumps_tables(occupied_squares_row_index , PSI_index);
			
	    for (unsigned int i = 0 ; i < squares_non_zero_NBMEs_two_jumps_number ; i++)
	      {
		squares_non_zero_NBMEs_two_jumps_PSI_column_indices_table[i] = space_dimensions_all_processes_max;
		
		squares_non_zero_NBMEs_two_jumps_table[i] = 0.0;
	      }
	  }
    }
  
  squares_non_zero_NBMEs_one_jump_numbers  = 0;
  squares_non_zero_NBMEs_two_jumps_numbers = 0;

  if (configuration_SD_one_jump_tables_to_recalculate_for_matrices)  
    configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (is_there_cout , is_it_one_body , false , false , false , GSM_vector_helper , GSM_vector_helper , dummy_helper , prot_data , neut_data);
	  
  if (space == PROTONS_NEUTRONS)
    {
      class array<unsigned int> squares_non_zero_NBMEs_one_jump_numbers_copy;
      
      if (is_prot_one_body_non_zero || is_pp_non_zero || is_pn_non_zero) jumps_p_prot_one_body_part_pn_calc_store ();
      
      if (is_pn_non_zero)
	{
	  squares_non_zero_NBMEs_one_jump_numbers = 0;
	  
	  one_jump_p_pn_part_pn_calc_store ();
	  
	  squares_non_zero_NBMEs_one_jump_numbers_copy.allocate_fill (squares_non_zero_NBMEs_one_jump_numbers);
	}
            
      if (is_neut_one_body_non_zero || is_nn_non_zero || is_pn_non_zero) jumps_n_neut_one_body_part_pn_calc_store ();
            
      if (is_pn_non_zero)
	{
	  squares_non_zero_NBMEs_one_jump_numbers = squares_non_zero_NBMEs_one_jump_numbers_copy;
	  
	  one_jump_n_pn_part_pn_calc_store ();
	}

      if (is_pp_non_zero) jumps_p_prot_two_body_part_pn_calc_store ();
      if (is_nn_non_zero) jumps_n_neut_two_body_part_pn_calc_store ();
      
      if (is_pn_non_zero)
	{
	  const int Zval = prot_data.get_N_valence_nucleons ();
	  const int Nval = neut_data.get_N_valence_nucleons ();

	  if (Nval >= Zval)
	    two_jumps_pn_part_pn_N_valence_larger_calc_store ();
	  else
	    two_jumps_pn_part_pn_Z_valence_larger_calc_store ();
	}
    }
  else
    jumps_part_pp_nn_calc_store ();
  
  if (configuration_SD_one_jump_tables_to_recalculate_for_matrices)
    {
      prot_data.one_jump_tables_in_to_out_deallocate ();
      neut_data.one_jump_tables_in_to_out_deallocate ();
    }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time;
      
      cout << "Hamiltonian calculated and stored. time:" << relative_time << " s" << endl << endl;
    }
}










void H_class::apply_add_off_diagonal_full_or_partial_storage_occupied_squares_part (
										    const unsigned int square_row_index ,
										    const class GSM_vector &PSI_in) const
{ 
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const class array<unsigned int> &MPI_occupied_squares_row_indices = GSM_vector_helper.get_MPI_occupied_squares_row_indices ();

  const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  const class array<unsigned int *> &PSI_row_indices_non_zero_one_jump_tables  = (is_it_TRS) ? (PSI_row_indices_non_zero_one_jump_TRS_tables)  : (PSI_row_indices_non_zero_one_jump_no_TRS_tables);
  const class array<unsigned int *> &PSI_row_indices_non_zero_two_jumps_tables = (is_it_TRS) ? (PSI_row_indices_non_zero_two_jumps_TRS_tables) : (PSI_row_indices_non_zero_two_jumps_no_TRS_tables);

  const unsigned int *const PSI_row_indices_non_zero_one_jump  = PSI_row_indices_non_zero_one_jump_tables(occupied_squares_row_index);
  const unsigned int *const PSI_row_indices_non_zero_two_jumps = PSI_row_indices_non_zero_two_jumps_tables(occupied_squares_row_index);
  
  const unsigned int space_dimension_non_zero_one_jump  = (is_it_TRS) ? (space_dimensions_non_zero_one_jump_TRS(occupied_squares_row_index))  : (space_dimensions_non_zero_one_jump_no_TRS(occupied_squares_row_index));
  const unsigned int space_dimension_non_zero_two_jumps = (is_it_TRS) ? (space_dimensions_non_zero_two_jumps_TRS(occupied_squares_row_index)) : (space_dimensions_non_zero_two_jumps_no_TRS(occupied_squares_row_index));
    
  class GSM_vector &H_PSI_occupied_squares = get_H_PSI_occupied_squares ();

  H_PSI_occupied_squares = 0.0;

  double H_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized)
#endif
  {

#ifdef UseMPI
    
    const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
    if (is_it_MPI_parallelized_local)
      {        
	const unsigned int i_thread = OpenMP_thread_number_determine ();
    	
	if (i_thread == MASTER_THREAD)
	  {
	    const class array<MPI_Comm> &MPI_row_communicators = GSM_vector_helper.get_MPI_row_communicators ();
	    
	    const class array<unsigned int> &MPI_row_group_master_processes = GSM_vector_helper.get_MPI_row_group_master_processes ();
	
	    const MPI_Comm MPI_row_communicator = MPI_row_communicators(square_row_index);
	    
	    const unsigned int MPI_row_master_process = MPI_row_group_master_processes (square_row_index);

	    class GSM_vector &PSI_in_unoccupied_squares = get_PSI_in_unoccupied_squares ();
	    
	    const double reference_time = absolute_time_determine ();

	    PSI_in_unoccupied_squares.MPI_Bcast (MPI_row_master_process , MPI_row_communicator);

	    const double MPI_Bcast_absolute_time = absolute_time_determine ();
		
	    H_MPI_communication_time += MPI_Bcast_absolute_time - reference_time;
	  }
      }
    
#endif

#ifdef UseOpenMP
#pragma omp for schedule (dynamic)
#endif
    for (unsigned int PSI_non_zero_index_one_jump = 0 ; PSI_non_zero_index_one_jump < space_dimension_non_zero_one_jump ; PSI_non_zero_index_one_jump++)
      {
	const unsigned int PSI_out_index = PSI_row_indices_non_zero_one_jump[PSI_non_zero_index_one_jump];

	const unsigned int square_non_zero_NBMEs_one_jump_number = squares_non_zero_NBMEs_one_jump_numbers(occupied_squares_row_index , PSI_out_index);
	  
	const unsigned int *const square_non_zero_NBMEs_one_jump_PSI_column_indices = squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables(occupied_squares_row_index , PSI_out_index);
	
	const TYPE *const square_non_zero_NBMEs_one_jump = squares_non_zero_NBMEs_one_jump_tables(occupied_squares_row_index , PSI_out_index);
	
	TYPE component_part = 0.0;
	
	for (unsigned int i = 0 ; i < square_non_zero_NBMEs_one_jump_number ; i++) 
	  {
	    const unsigned int PSI_in_index = square_non_zero_NBMEs_one_jump_PSI_column_indices[i];
	    
	    const TYPE &PSI_in_component = PSI_in[PSI_in_index];
	    
	    const TYPE &NBME = square_non_zero_NBMEs_one_jump[i];
	    
	    component_part += NBME*PSI_in_component;
	  }
	
	H_PSI_occupied_squares[PSI_out_index] += component_part;

	H_multiplications_number_local += square_non_zero_NBMEs_one_jump_number;
      }

    if (Hamiltonian_storage == PARTIAL_STORAGE)
      {
#ifdef UseOpenMP
#pragma omp for schedule (dynamic)
#endif  
	for (unsigned int PSI_non_zero_index_two_jumps = 0 ; PSI_non_zero_index_two_jumps < space_dimension_non_zero_two_jumps ; PSI_non_zero_index_two_jumps++)
	  {
	    const unsigned int PSI_out_index = PSI_row_indices_non_zero_two_jumps[PSI_non_zero_index_two_jumps];
	
	    const unsigned int square_non_zero_NBMEs_two_jumps_number = squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_out_index);

	    const unsigned int *const square_non_zero_NBMEs_two_jumps_PSI_column_indices = squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables(occupied_squares_row_index , PSI_out_index);

	    const unsigned int *const square_non_zero_NBMEs_two_jumps_indices = squares_non_zero_NBMEs_two_jumps_indices_tables(occupied_squares_row_index , PSI_out_index);

	    TYPE component_part = 0.0;

	    for (unsigned int i = 0 ; i < square_non_zero_NBMEs_two_jumps_number ; i++) 
	      {
		const unsigned int PSI_in_index = square_non_zero_NBMEs_two_jumps_PSI_column_indices[i];
		
		const TYPE &PSI_in_component = PSI_in[PSI_in_index];

		const unsigned int NBME_index = square_non_zero_NBMEs_two_jumps_indices[i];
		
		const unsigned int TBME_index = NBME_index/2;

		const unsigned int total_bin_phase = NBME_index%2;
 
		const int total_phase = parity_from_binary_parity (total_bin_phase);
	  
		const TYPE &TBME = M_TBMEs[TBME_index];
	    
		(total_phase == 1) ? (component_part += TBME*PSI_in_component) : (component_part -= TBME*PSI_in_component);
	      }

	    H_PSI_occupied_squares[PSI_out_index] += component_part;
	
	    H_multiplications_number_local += square_non_zero_NBMEs_two_jumps_number;
	  }
      }
    
    if (Hamiltonian_storage == FULL_STORAGE)
      {
#ifdef UseOpenMP
#pragma omp for schedule (dynamic)
#endif  
	for (unsigned int PSI_non_zero_index_two_jumps = 0 ; PSI_non_zero_index_two_jumps < space_dimension_non_zero_two_jumps ; PSI_non_zero_index_two_jumps++)
	  {
	    const unsigned int PSI_out_index = PSI_row_indices_non_zero_two_jumps[PSI_non_zero_index_two_jumps];
	
	    const unsigned int square_non_zero_NBMEs_two_jumps_number = squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_out_index);

	    const unsigned int *const square_non_zero_NBMEs_two_jumps_PSI_column_indices = squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables(occupied_squares_row_index , PSI_out_index);

	    const TYPE *const square_non_zero_NBMEs_two_jumps = squares_non_zero_NBMEs_two_jumps_tables(occupied_squares_row_index , PSI_out_index);

	    TYPE component_part = 0.0;

	    for (unsigned int i = 0 ; i < square_non_zero_NBMEs_two_jumps_number ; i++) 
	      {
		const unsigned int PSI_in_index = square_non_zero_NBMEs_two_jumps_PSI_column_indices[i];
		
		const TYPE &PSI_in_component = PSI_in[PSI_in_index];

		const TYPE &NBME = square_non_zero_NBMEs_two_jumps[i];
	    
		component_part += NBME*PSI_in_component;
	      }
		
	    H_PSI_occupied_squares[PSI_out_index] += component_part;
	
	    H_multiplications_number_local += square_non_zero_NBMEs_two_jumps_number;
	  }    
      }
  }
  
  H_multiplications_number += H_multiplications_number_local;
}








void H_class::apply_add_off_diagonal_full_or_partial_storage_unoccupied_squares_part (const unsigned int square_row_index) const 
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const class array<unsigned int> &MPI_occupied_squares_row_indices = GSM_vector_helper.get_MPI_occupied_squares_row_indices ();

  const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
    	      
  const class array<unsigned long int> &TRS_total_PSI_indices = GSM_vector_helper.get_TRS_total_PSI_indices ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const unsigned int space_dimension_non_zero_one_jump  = space_dimensions_non_zero_one_jump_no_TRS(occupied_squares_row_index);
  const unsigned int space_dimension_non_zero_two_jumps = space_dimensions_non_zero_two_jumps_no_TRS(occupied_squares_row_index);

  const unsigned int *const PSI_row_indices_non_zero_one_jump  = PSI_row_indices_non_zero_one_jump_no_TRS_tables(occupied_squares_row_index);
  const unsigned int *const PSI_row_indices_non_zero_two_jumps = PSI_row_indices_non_zero_two_jumps_no_TRS_tables(occupied_squares_row_index);
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
    
  const class GSM_vector &PSI_in_unoccupied_squares = get_PSI_in_unoccupied_squares ();
 
  class array<class GSM_vector> &H_PSI_unoccupied_squares_parts = get_H_PSI_table ();

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) H_PSI_unoccupied_squares_parts(i).zero ();

  double H_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized)
#endif
  {
    const unsigned int i_thread = OpenMP_thread_number_determine ();
	   
#ifdef UseMPI
         
    const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();

    if (is_it_MPI_parallelized_local && (i_thread == MASTER_THREAD))
      {
 	const class array<MPI_Comm> &MPI_row_communicators = GSM_vector_helper.get_MPI_row_communicators ();

	const MPI_Comm MPI_row_communicator = MPI_row_communicators(square_row_index);
   
	const class array<unsigned int> &MPI_row_processes = GSM_vector_helper.get_MPI_row_processes ();

	const class array<unsigned int> &MPI_row_group_master_processes = GSM_vector_helper.get_MPI_row_group_master_processes ();

	const unsigned int MPI_row_master_process = MPI_row_group_master_processes (square_row_index);

	const unsigned int MPI_row_process = MPI_row_processes (square_row_index);
 
	const double reference_time = absolute_time_determine ();

	class GSM_vector &H_PSI_occupied_squares = get_H_PSI_occupied_squares ();

	H_PSI_occupied_squares.MPI_Reduce (MPI_SUM , MPI_row_master_process , MPI_row_process , MPI_row_communicator);

	const double MPI_Reduce_absolute_time = absolute_time_determine ();
	
	H_MPI_communication_time += MPI_Reduce_absolute_time - reference_time;
      }
    
#endif
    
    class GSM_vector &H_PSI_unoccupied_squares_part = H_PSI_unoccupied_squares_parts(i_thread);
    
#ifdef UseOpenMP
#pragma omp for schedule (dynamic)
#endif
    for (unsigned int PSI_non_zero_index_one_jump = 0 ; PSI_non_zero_index_one_jump < space_dimension_non_zero_one_jump ; PSI_non_zero_index_one_jump++)
      {
	const unsigned int PSI_in_index = PSI_row_indices_non_zero_one_jump[PSI_non_zero_index_one_jump];
	
	const unsigned int square_non_zero_NBMEs_one_jump_number = squares_non_zero_NBMEs_one_jump_numbers(occupied_squares_row_index , PSI_in_index);

	const unsigned int *const square_non_zero_NBMEs_one_jump_PSI_column_indices = squares_non_zero_NBMEs_one_jump_PSI_column_indices_tables(occupied_squares_row_index , PSI_in_index);
	
	const TYPE *const square_non_zero_NBMEs_one_jump = squares_non_zero_NBMEs_one_jump_tables(occupied_squares_row_index , PSI_in_index);

	const TYPE &PSI_in_component = PSI_in_unoccupied_squares[PSI_in_index];

	if (is_it_TRS)
	  {
	    unsigned int square_non_zero_NBMEs_one_jump_number_TRS = 0;
	    
	    for (unsigned int i = 0 ; i < square_non_zero_NBMEs_one_jump_number ; i++) 
	      {
		const unsigned int PSI_out_index = square_non_zero_NBMEs_one_jump_PSI_column_indices[i];
		
		const unsigned long int total_PSI_out_index = first_total_PSI_out_index + PSI_out_index;
      
		if (TRS_total_PSI_indices(PSI_out_index) >= total_PSI_out_index)
		  {
		    const TYPE &NBME = square_non_zero_NBMEs_one_jump[i];
		
		    H_PSI_unoccupied_squares_part[PSI_out_index] += NBME*PSI_in_component;

		    square_non_zero_NBMEs_one_jump_number_TRS++;
		  }
	      }

	    H_multiplications_number_local += square_non_zero_NBMEs_one_jump_number_TRS;
	  }
	else
	  {
	    for (unsigned int i = 0 ; i < square_non_zero_NBMEs_one_jump_number ; i++) 
	      {
		const unsigned int PSI_out_index = square_non_zero_NBMEs_one_jump_PSI_column_indices[i];
		
		const TYPE &NBME = square_non_zero_NBMEs_one_jump[i];
		
		H_PSI_unoccupied_squares_part[PSI_out_index] += NBME*PSI_in_component;
	      }
	    
	    H_multiplications_number_local += square_non_zero_NBMEs_one_jump_number;
	  }
      }
    
    if (Hamiltonian_storage == PARTIAL_STORAGE)
      {
#ifdef UseOpenMP
#pragma omp for schedule (dynamic)
#endif
	for (unsigned int PSI_non_zero_index_two_jumps = 0 ; PSI_non_zero_index_two_jumps < space_dimension_non_zero_two_jumps ; PSI_non_zero_index_two_jumps++)
	  {
	    const unsigned int PSI_in_index = PSI_row_indices_non_zero_two_jumps[PSI_non_zero_index_two_jumps];
	
	    const unsigned int square_non_zero_NBMEs_two_jumps_number = squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_in_index);
	
	    const unsigned int *const square_non_zero_NBMEs_two_jumps_PSI_column_indices = squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables(occupied_squares_row_index , PSI_in_index);
	
	    const unsigned int *const square_non_zero_NBMEs_two_jumps_indices = squares_non_zero_NBMEs_two_jumps_indices_tables(occupied_squares_row_index , PSI_in_index);

	    const TYPE &PSI_in_component = PSI_in_unoccupied_squares[PSI_in_index];
	    
	    if (is_it_TRS)
	      {
		unsigned int square_non_zero_NBMEs_two_jumps_number_TRS = 0;
	    
		for (unsigned int i = 0 ; i < square_non_zero_NBMEs_two_jumps_number ; i++)
		  {
		    const unsigned int PSI_out_index = square_non_zero_NBMEs_two_jumps_PSI_column_indices[i];

		    const unsigned long int total_PSI_out_index = first_total_PSI_out_index + PSI_out_index;
      
		    if (TRS_total_PSI_indices(PSI_out_index) >= total_PSI_out_index)
		      {
			const unsigned int NBME_index = square_non_zero_NBMEs_two_jumps_indices[i];
			
			const unsigned int TBME_index = NBME_index/2;

			const unsigned int total_bin_phase = NBME_index%2;
 
			const int total_phase = parity_from_binary_parity (total_bin_phase);
	  
			const TYPE &TBME = M_TBMEs[TBME_index];
		    
			(total_phase == 1) ? (H_PSI_unoccupied_squares_part[PSI_out_index] += TBME*PSI_in_component) : (H_PSI_unoccupied_squares_part[PSI_out_index] -= TBME*PSI_in_component);

			square_non_zero_NBMEs_two_jumps_number_TRS++;
		      }
		  }
	    
		H_multiplications_number_local += square_non_zero_NBMEs_two_jumps_number_TRS;
	      }
	    else
	      {
		for (unsigned int i = 0 ; i < square_non_zero_NBMEs_two_jumps_number ; i++)
		  {
		    const unsigned int PSI_out_index = square_non_zero_NBMEs_two_jumps_PSI_column_indices[i];

		    const unsigned int NBME_index = square_non_zero_NBMEs_two_jumps_indices[i];

		    const unsigned int TBME_index = NBME_index/2;

		    const unsigned int total_bin_phase = NBME_index%2;
 
		    const int total_phase = parity_from_binary_parity (total_bin_phase);
		    
		    const TYPE &TBME = M_TBMEs[TBME_index];
		
		    (total_phase == 1) ? (H_PSI_unoccupied_squares_part[PSI_out_index] += TBME*PSI_in_component) : (H_PSI_unoccupied_squares_part[PSI_out_index] -= TBME*PSI_in_component);
		  }
	    
		H_multiplications_number_local += square_non_zero_NBMEs_two_jumps_number;
	      }
	  }
      }
    
    if (Hamiltonian_storage == FULL_STORAGE)
      {
#ifdef UseOpenMP
#pragma omp for schedule (dynamic)
#endif
	for (unsigned int PSI_non_zero_index_two_jumps = 0 ; PSI_non_zero_index_two_jumps < space_dimension_non_zero_two_jumps ; PSI_non_zero_index_two_jumps++)
	  {
	    const unsigned int PSI_in_index = PSI_row_indices_non_zero_two_jumps[PSI_non_zero_index_two_jumps];
	
	    const unsigned int square_non_zero_NBMEs_two_jumps_number = squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_in_index);
	
	    const unsigned int *const square_non_zero_NBMEs_two_jumps_PSI_column_indices = squares_non_zero_NBMEs_two_jumps_PSI_column_indices_tables(occupied_squares_row_index , PSI_in_index);
	
	    const TYPE *const square_non_zero_NBMEs_two_jumps = squares_non_zero_NBMEs_two_jumps_tables(occupied_squares_row_index , PSI_in_index);

	    const TYPE &PSI_in_component = PSI_in_unoccupied_squares[PSI_in_index];
	    
	    if (is_it_TRS)
	      {
		unsigned int square_non_zero_NBMEs_two_jumps_number_TRS = 0;
	    
		for (unsigned int i = 0 ; i < square_non_zero_NBMEs_two_jumps_number ; i++)
		  {
		    const unsigned int PSI_out_index = square_non_zero_NBMEs_two_jumps_PSI_column_indices[i];

		    const unsigned long int total_PSI_out_index = first_total_PSI_out_index + PSI_out_index;
      
		    if (TRS_total_PSI_indices(PSI_out_index) >= total_PSI_out_index)
		      {
			const TYPE &NBME = square_non_zero_NBMEs_two_jumps[i];
		    
			H_PSI_unoccupied_squares_part[PSI_out_index] += NBME*PSI_in_component;

			square_non_zero_NBMEs_two_jumps_number_TRS++;
		      }
		  }
	    
		H_multiplications_number_local += square_non_zero_NBMEs_two_jumps_number_TRS;
	      }
	    else
	      {
		for (unsigned int i = 0 ; i < square_non_zero_NBMEs_two_jumps_number ; i++)
		  {
		    const unsigned int PSI_out_index = square_non_zero_NBMEs_two_jumps_PSI_column_indices[i];

		    const TYPE &NBME = square_non_zero_NBMEs_two_jumps[i];
		    
		    H_PSI_unoccupied_squares_part[PSI_out_index] += NBME*PSI_in_component;
		  }
	    
		H_multiplications_number_local += square_non_zero_NBMEs_two_jumps_number;
	      }
	  }
      }
  }
  
  H_multiplications_number += H_multiplications_number_local;
  
  class GSM_vector &H_PSI_unoccupied_squares_master_thread = H_PSI_unoccupied_squares_parts(MASTER_THREAD);
  
  const unsigned int space_dimensions_all_processes_max = H_PSI_unoccupied_squares_master_thread.get_space_dimensions_all_processes_max ();  

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      if (i != MASTER_THREAD)
	{
	  const class GSM_vector &H_PSI_unoccupied_squares_part = H_PSI_unoccupied_squares_parts(i);
  
	  for (unsigned int j = 0 ; j < space_dimensions_all_processes_max ; j++)
	    H_PSI_unoccupied_squares_master_thread[j] += H_PSI_unoccupied_squares_part[j];
	}
    }
}








void H_class::apply_add_off_diagonal_full_or_partial_storage (
							      const class GSM_vector &PSI_in ,
							      class GSM_vector &PSI_out) const
{    
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  const unsigned int N = (is_it_MPI_parallelized_local) ? (NUMBER_OF_PROCESSES) : (1);
  
  const class array<bool> &MPI_are_squares_occupied = GSM_vector_helper.get_MPI_are_squares_occupied ();
  
  const class array<unsigned int> &MPI_row_processes = GSM_vector_helper.get_MPI_row_processes ();

  const class array<unsigned int> &MPI_row_group_master_processes = GSM_vector_helper.get_MPI_row_group_master_processes ();
    
  class array<class GSM_vector> &H_PSI_unoccupied_squares_parts = get_H_PSI_table ();
  
  class GSM_vector &PSI_in_unoccupied_squares = get_PSI_in_unoccupied_squares ();
  
  class GSM_vector &H_PSI_occupied_squares = get_H_PSI_occupied_squares ();
  
  class GSM_vector &H_PSI_unoccupied_squares_master_thread = H_PSI_unoccupied_squares_parts(MASTER_THREAD);
  
  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
    {
      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);
      
      const unsigned int MPI_row_master_process = MPI_row_group_master_processes (square_row_index);

      const unsigned int MPI_row_process = MPI_row_processes (square_row_index);
	  
      if (is_square_occupied)
	{		    
	  if (MPI_row_process == MPI_row_master_process) PSI_in_unoccupied_squares = PSI_in;

	  apply_add_off_diagonal_full_or_partial_storage_occupied_squares_part (square_row_index , PSI_in);

	  apply_add_off_diagonal_full_or_partial_storage_unoccupied_squares_part (square_row_index);
      
	  PSI_out += H_PSI_unoccupied_squares_master_thread;
      
	  if (!is_it_MPI_parallelized_local || (MPI_row_process == MPI_row_master_process)) PSI_out += H_PSI_occupied_squares;
	}
    }
}


