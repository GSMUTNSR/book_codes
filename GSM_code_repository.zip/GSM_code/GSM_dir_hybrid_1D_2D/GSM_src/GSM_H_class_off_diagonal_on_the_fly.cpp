#include "../GSM_include/GSM_include_def.h"

using namespace inputs_misc;
using namespace GSM_vector_NBMEs_handling;
using namespace GSM_vector_NBMEs_handling::out_to_in;
using namespace GSM_vector_dimensions;
using namespace MPI_2D_partitioning;
using namespace configuration_SD_in_space_one_jump_out_to_in;


// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons
// ------------------------------------------------------------------------------------------------------------------------------------------------------



// Application of H times vector for the off-diagonal part with the on the fly method
// ----------------------------------------------------------------------------------
// One uses 1D partitioning here. For this, one copies the initial |Psi[in]>, parallelized in 2D format, to |Psi[in]-full>, not parallelized, and copied to every node.
// Otherwise, MPI communications would be too lengthy. Then, H is applied with the on the fly method to |Psi[in]-full>, to get |Psi[out], parallelized in 2D format.
//
// MPI average multiplications number per thread is calculated and written on screen if is_there_cout_detailed is true.
//
// The off-diagonal part of the Hamiltonian is applied therein as |Psi[out]> -> |Psi[out]> + (H + E.Id).|Psi[in]>
//
// TRS is time-reversal symmetry and can be used therein.
// It allows to calculate about one half of |Psi[out]> if M=0, while the rest is given from the first half up to a phase in |Psi[in]> and |Psi[out]>.
// Thus, Hamiltonian storage is divided by about two when TRS is used.
//
// One considers non-zero NBMEs occurring in one node only as they are not used in other nodes due to Hamiltonian partitioning (see GSM_vector.cpp).
//
// One loops over proton and neutron Slater determinants, the first loop being proton or neutron according to the case.
//
// One does not use M_TBMEs in one jump routines even if they are stored as one does not necessarily have (a < b) and (c < d) in <ab|V|cd> TBMEs entering the NBME.
// One uses the symmetry relation <ab|V|cd> = <cd|V|ab> for pn TBMEs, and the latter are not necessarily stored as well.
// Recalculation time is negligible.
//
// NBMEs_one_jump_pp_nn_calc_partial_storage_on_the_fly
// ----------------------------------------------------
// One considers only the proton or neutron 1p-1h part, and one uses the notation mu for proton or neutron.
// This is for p -> p', n -> n' only.
// This provides with non-zero off-diagonal NBMEs for 1p-1h jumps from a proton/neutron out Slater determinant to an in proton/neutron Slater determinant.
// Jumps have already been calculated at this level, so that one calculates the NBME without reordering phase, 
// which is multiplied afterwards by the reordering phase, calculated along with jumps data and stored in jumps data arrays.
// Even though it is the on the fly method, the NBMEs for a fixed proton/neutron out Slater determinant are stored, as storage memory is negligible.
// Indeed, when one runs over neutrons SDs for a fixed proton SD (or over protons SDs for a fixed neutron SD), the same NBME can be reused several times.
//
// jumps_p_one_body_part_pn_calc_on_the_fly, jumps_p_two_body_part_pn_calc_on_the_fly, jumps_n_one_body_part_pn_calc_on_the_fly, jumps_n_two_body_part_pn_calc_on_the_fly
// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One considers here off-diagonal NBMEs for 1p-1h or 2p-2h jumps from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// This is for p -> p', n -> n', p1 p2 -> p1' p2' and n1 n2 -> n1' n2' only, and these routines are used when one has both valence protons and neutrons.
// One considers pp and nn OBMEs and TBMEs only in these routines.
// In this routine, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates the indices of the in Slater determinant and the associated NBMEs from them, and apply them to obtain a part of |Psi[out]> + (H + E.Id).|Psi[in]>.
//
// one_jump_p_pn_part_pn_calc_on_the_fly, one_jump_n_pn_part_pn_calc_on_the_fly
// ----------------------------------------------------------------------------
// Non-zero off-diagonal NBMEs of 1p-1h type are considered here, from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// This is for p -> p', n -> n' only, and these routines are used when one has both valence protons and neutrons.
// One considers pn TBMEs only in these routines.
// In this routine, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates the indices of the in Slater determinant and the associated NBMEs from them, and apply them to obtain a part of |Psi[out]> + (H + E.Id).|Psi[in]>.
// In order to save time, one partially stored the pn NBME without phase, as it depends only on n and n' for a fixed proton SD (or p and p' for a fixed neutron SD).
// Hence, when one runs over neutrons SDs for a fixed proton SD (or over protons SDs for a fixed neutron SD), the same pn NBME can be reused several times.
// Only the reordering phase has to multiplied to it, and it has been calculated and stored in jumps arrays.
//
// two_jumps_pn_part_pn_on_the_fly_one_jumps_stored_N/Z_valence_larger_calc, two_jumps_pn_part_pn_on_the_fly_one_jumps_partially_stored_N/Z_valence_larger_calc, two_jumps_pn_part_pn_on_the_fly_one_jumps_recalculated_N/Z_valence_larger_calc
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Non-zero off-diagonal NBMEs (or their indices, see GSM_H_class.cpp) for 2p-2h pn jumps from an out Slater determinant to an in Slater determinant are considered here.
// One routine is used if NYval >= ZYval (N_valence_larger), and another if not (Z_valence_larger), as SD indices are calculated differently in each case to optimize their use (see GSM_vector_dimensions.cpp).
// One calculates 1p-1h proton or neutron jumps totally (...recalculated... routines), partially (...one_jumps_partially_stored...), or one takes then from arrays (...one_jumps_stored...) according to one_jumps_pn_storage.
// (see one_jump_p_tabs, one_jump_n_tabs discussion in GSM_H_class.cpp).
//
// For this, one loop over parity and M quantum numbers of the in Slater determinant, and one calculates 1p-1h proton and neutron jumps using quantum number conservation,
// so that the pn 2p-2h jump can be generated from it. Once they are calculated, one loops over obtained proton and neutron in Slater determinants for a fixed out Slater determinant,
// and one calculates non-zero NBMEs if model space truncations are respected, i.e. if hw truncation energy and number of particles in the continuum are below their limit.
// One then apply them to obtain a part of |Psi[out]> + (H + E.Id).|Psi[in]>.
//
// For this, one loop over parity and M quantum numbers of the in Slater determinant, and one calculates 1p-1h proton and neutron jumps using quantum number conservation,
// so that the pn 2p-2h jump can be generated from it. Once they are calculated, one loops over obtained proton and neutron in Slater determinants for a fixed out Slater determinant,
// and one calculates non-zero NBMEs if model space truncations are respected, i.e. if hw truncation energy and number of particles in the continuum are below their limit.
// One then apply them to obtain a part of |Psi[out]> + (H + E.Id).|Psi[in]>.
//
// jumps_part_pp_nn_calc_on_the_fly
// --------------------------------------------
// Non-zero off-diagonal NBMEs for 1p-1h or 2p-2h jumps from a proton/neutron Slater determinant to another proton/neutron Slater determinant are considered here.
// This is for p -> p', n -> n', p1 p2 -> p1' p2' and n1 n2 -> n1' n2' only, and this routine is used when one has valence protons only or valence neutrons only.
// In this routine, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the number of non-zero NBMEs from them. One then apply them to obtain a part of |Psi[out]> + (H + E.Id).|Psi[in]>.
// 
// apply_add_off_diagonal_on_the_fly
// ---------------------------------
// One applies here |Psi[out]> -> |Psi[out]> + (H + E.Id).|Psi[in]> using previous routines.
// The 1p-1h and 2p-2h parts are separated. The diagonal part is not considered here, as it is taken into in apply_add (see GSM_H_class.cpp).

void H_class::NBMEs_one_jump_pp_nn_calc_partial_storage_on_the_fly (
								    const unsigned int BPmu , 
								    const int Smu , 
								    const int n_spec_mu , 
								    const int iMmu , 
								    const int n_scat_mu_out , 
								    const unsigned int iCmu_out , 
								    const unsigned int outSDmu_index , 
								    const class Slater_determinant &outSDmu , 
								    const class baryons_data &data , 
								    bool &is_there_one_jump_calc , 
								    class jumps_data_out_to_in_str &one_jump_mu , 
								    class array<TYPE> &NBMEs_one_jump_mu) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum particle_type nucleonic_particle_mu = data.get_nucleonic_particle ();

  const bool is_it_charged = (nucleonic_particle_mu == PROTON);
  
  const enum interaction_type inter = GSM_vector_helper.get_inter ();

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 

  const bool is_one_body_mu_non_zero = (is_it_charged) ? (is_one_body_p_non_zero) : (is_one_body_n_non_zero);
  const bool is_two_body_mu_non_zero = (is_it_charged) ? (is_pp_non_zero)              : (is_nn_non_zero);
  
  const int n_holes_max_mu = (is_it_charged) ? (n_holes_max_p) : (n_holes_max_n);
  
  const int n_scat_max_mu = (is_it_charged) ? (n_scat_max_p) : (n_scat_max_n);

  const int Emu_max_hw = (is_it_charged) ? (Ep_max_hw) : (En_max_hw);
    
  is_there_one_jump_calc = false;
      
  if (is_one_body_mu_non_zero || is_two_body_mu_non_zero || is_pn_non_zero)
    {
      one_jump_mu.one_jump_mu_store (BPmu , Smu , n_spec_mu , iMmu , n_holes_max_mu , n_scat_max_mu , Emu_max_hw , BPmu , Smu , n_spec_mu , n_scat_mu_out , iCmu_out , iMmu , outSDmu_index , data);
      
      const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();
	      
      if (dimension_one_jump_mu > 0)
	{ 
	  for (unsigned int i = 0 ; i < dimension_one_jump_mu ; i++)
	    { 
	      const class jumps_data_inSD_str &one_jump_mu_inSD = one_jump_mu(i);

	      const unsigned int mu_in  = one_jump_mu_inSD.get_mu_in ();
	      const unsigned int mu_out = one_jump_mu_inSD.get_mu_out ();
	      
	      const unsigned int total_bin_phase_mu = one_jump_mu_inSD.get_total_bin_phase ();
	      
	      const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);
	      
	      const TYPE NBME_one_jump_mu_no_phase = H_NBMEs::no_pn_one_jump_mu_no_phase_calc (inter , is_one_body_mu_non_zero , is_two_body_mu_non_zero , mu_in , mu_out , outSDmu , data);
	      
	      NBMEs_one_jump_mu(i) = (total_phase_mu == 1) ? (NBME_one_jump_mu_no_phase) : (-NBME_one_jump_mu_no_phase);
	    }
	  
	  is_there_one_jump_calc = true;
	}
    }
}









void H_class::NBMEs_two_jumps_pp_nn_calc_partial_storage_on_the_fly (
								     const unsigned int BPmu , 
								     const int Smu , 
								     const int n_spec_mu , 
								     const int iMmu , 
								     const int n_scat_mu_out , 
								     const unsigned int iCmu_out , 
								     const unsigned int outSDmu_index , 
								     const class baryons_data &data ,
								     bool &are_there_two_jumps_calc , 
								     class jumps_data_out_to_in_str &two_jumps_mu , 
								     class array<TYPE> &NBMEs_two_jumps_mu) const
{
  are_there_two_jumps_calc = false;

  const int N_valence_baryons = data.get_N_valence_baryons ();

  if (N_valence_baryons == 1) return;
  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const enum particle_type nucleonic_particle_mu = data.get_nucleonic_particle ();
  
  const bool is_it_largest_subspace = (((nucleonic_particle_mu == NEUTRON) && (NYval >= ZYval)) || ((nucleonic_particle_mu == PROTON) && (NYval < ZYval)));
    
  const enum space_type TBME_space_mu = (nucleonic_particle_mu == PROTON) ? (PROT_Y_ONLY) : (NEUT_Y_ONLY);
  
  const class TBMEs_class &TBMEs = data.get_TBMEs ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const bool is_two_body_mu_non_zero = (TBME_space_mu == PROT_Y_ONLY) ? (is_pp_non_zero) : (is_nn_non_zero);

  const int n_holes_max_mu_in = (TBME_space_mu == PROT_Y_ONLY) ? (n_holes_max_p) : (n_holes_max_n);
  
  const int n_scat_max_mu_in = (TBME_space_mu == PROT_Y_ONLY) ? (n_scat_max_p) : (n_scat_max_n);

  const int Emu_max_hw_in = (TBME_space_mu == PROT_Y_ONLY) ? (Ep_max_hw) : (En_max_hw);
  
  const bool are_M_TBMEs_stored = ((M_TBMEs_storage == FULL_STORAGE) || (!is_it_largest_subspace && (M_TBMEs_storage == PARTIAL_STORAGE)));
       
  if (is_two_body_mu_non_zero && (N_valence_baryons >= 2))
    {
      two_jumps_mu.two_jumps_mu_store (BPmu , Smu , n_spec_mu , iMmu , n_holes_max_mu_in , n_scat_max_mu_in , Emu_max_hw_in , BPmu , Smu , n_spec_mu , n_scat_mu_out , iCmu_out , iMmu , outSDmu_index , false , false , data);

      const unsigned int dimension_two_jumps_mu = two_jumps_mu.get_dimension ();

      if (dimension_two_jumps_mu > 0)
	{  
	  for (unsigned int i = 0 ; i < dimension_two_jumps_mu ; i++)
	    { 
	      const class jumps_data_inSD_str &two_jumps_mu_inSD = two_jumps_mu(i);

	      const unsigned int mu_left_in  = two_jumps_mu_inSD.get_left_in ();
	      const unsigned int mu_right_in = two_jumps_mu_inSD.get_right_in ();
	      
	      const unsigned int mu_left_out  = two_jumps_mu_inSD.get_left_out ();
	      const unsigned int mu_right_out = two_jumps_mu_inSD.get_right_out ();
	      
	      const unsigned int total_bin_phase_mu = two_jumps_mu_inSD.get_total_bin_phase ();

	      const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);
	      
	      const TYPE TBME_mu = (are_M_TBMEs_stored) ? (M_TBMEs (TBME_space_mu , false , mu_left_in , mu_right_in , mu_left_out , mu_right_out)) : (TBMEs.M_TBME (false , mu_left_in , mu_right_in , mu_left_out , mu_right_out));
	      	      
	      NBMEs_two_jumps_mu(i) = (total_phase_mu == 1) ? (TBME_mu) : (-TBME_mu);
	    }
 
	  are_there_two_jumps_calc = true;
	}
    }
}








void H_class::jumps_p_one_body_part_pn_calc_on_the_fly (class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
      
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
 
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
    
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
    
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
        
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();
  
  if (total_outSDp_index_min > total_outSDp_index_max) return;
    
  class array<class Slater_determinant> outSDp_tab(NUMBER_OF_THREADS);
  
  class array<class jumps_data_out_to_in_str> one_jump_p_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > NBMEs_p_one_jump_p_tab(NUMBER_OF_THREADS);
	      
  class array<class array<bool> > is_configuration_accepted_one_jump_p_tabs(NUMBER_OF_THREADS);
	      
  class array<class array<unsigned long int> > total_PSI_in_indices_one_jump_p_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {     
      outSDp_tab(i).allocate (ZYval);
      
      one_jump_p_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
	  
      NBMEs_p_one_jump_p_tab(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);
	      	      
      is_configuration_accepted_one_jump_p_tabs(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);
	      
      total_PSI_in_indices_one_jump_p_tab(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);
    }
    
  class GSM_vector &PSI_in_full = get_PSI_in_full ();
    
  double H_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp = outSDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = outSDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sp = outSDp_qn.get_S ();

      const int Sn = S - Sp;
      
      const int n_spec_p = outSDp_qn.get_n_spec ();

      const int n_spec_n = n_spec_max - n_spec_p;

      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

      if (all_dimensions_SDn_zero) continue;

      const int iMn = iM - iMp;

      const int TRS_iMp = iMp_max - iMp;

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();

      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index)) : (NADA);

      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class Slater_determinant &outSDp = outSDp_tab(i_thread);
      
      class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(i_thread);
      
      class array<TYPE> &NBMEs_p_one_jump_p = NBMEs_p_one_jump_p_tab(i_thread);
	      
      class array<bool> &is_configuration_accepted_one_jump_p_tab = is_configuration_accepted_one_jump_p_tabs(i_thread);
	      
      class array<unsigned long int> &total_PSI_in_indices_one_jump_p = total_PSI_in_indices_one_jump_p_tab(i_thread);
		
      bool are_jumps_p_calculated = false;

      bool is_there_one_jump_calc_all = true;

      outSDp = SDp_set(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index);
      
      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && is_there_one_jump_calc_all ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
	  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
			  
	  for (unsigned int iCn = iCn_min ; (iCn <= iCn_max) && is_there_one_jump_calc_all ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
	      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

	      if (dimension_SDn == 0) continue;
				  
	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , iMp);
				  
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_SDn*outSDp_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_SDn_minus_one;
				  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , TRS_iMp)) : (NADA);
		  				  
		  const unsigned long int total_SDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_SDn*outSDp_TRS_index) : (NADA);
				      
		  if (!are_jumps_p_calculated)
		    {
		      bool is_there_one_jump_calc = false;
		      
		      NBMEs_one_jump_pp_nn_calc_partial_storage_on_the_fly (BPp , Sp , n_spec_p , iMp , n_scat_p_out , iCp_out , outSDp_index , outSDp , prot_Y_data , is_there_one_jump_calc , one_jump_p , NBMEs_p_one_jump_p);
						
		      is_there_one_jump_calc_all = is_there_one_jump_calc;
		      
		      are_jumps_p_calculated = true;
		    }
		  
		  if (!is_there_one_jump_calc_all) continue;

		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + SDn_index;

		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  const unsigned long int total_SDn_TRS_indices_index = (is_it_TRS) ? (total_SDn_TRS_indices_zero_index + SDn_index) : (NADA);

			  const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_SDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + SDn_TRS_index) : (NADA);

			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {					
			      bool is_there_one_jump_calc = false;
						      
			      is_configuration_accepted_total_PSI_in_indices_p_fill (BPn , Sn , n_spec_n , n_holes_n , n_scat_n , iCn , iMn , SDn_index , En_hw , one_jump_p , GSM_vector_helper , dimension_SDn , 
										     is_configuration_accepted_one_jump_p_tab , total_PSI_in_indices_one_jump_p , is_there_one_jump_calc);

			      if (is_there_one_jump_calc)
				{
				  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
			      
				  PSI_out[PSI_out_index] += component_part_jumps_calc (dimension_one_jump_p , is_configuration_accepted_one_jump_p_tab ,
										       total_PSI_in_indices_one_jump_p , NBMEs_p_one_jump_p , PSI_in_full);
				  
				  H_multiplications_number_local += component_part_jumps_number_calc (dimension_one_jump_p , is_configuration_accepted_one_jump_p_tab);
				}
						  
			    }}}}}}}
  
  H_multiplications_number += H_multiplications_number_local;
}






void H_class::jumps_p_two_body_part_pn_calc_on_the_fly (class GSM_vector &PSI_out) const
{ 
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
 
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();

  if (ZYval == 1) return;
  
  const unsigned int dimension_pp_2p2h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_2p2h_space_BP_S_iM_fixed_max (); 

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
    
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  if (total_outSDp_index_min > total_outSDp_index_max) return;
    
  class array<class jumps_data_out_to_in_str> two_jumps_p_tab(NUMBER_OF_THREADS);
	      
  class array<class array<TYPE> > NBMEs_two_jumps_p_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_configuration_accepted_two_jumps_p_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_in_indices_two_jumps_p_tab(NUMBER_OF_THREADS);
    
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {      
      two_jumps_p_tab(i).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_pp_2p2h_space_BP_S_iM_fixed_max);
		
      NBMEs_two_jumps_p_tab(i).allocate (dimension_pp_2p2h_space_BP_S_iM_fixed_max);

      is_configuration_accepted_two_jumps_p_tabs(i).allocate (dimension_pp_2p2h_space_BP_S_iM_fixed_max);

      total_PSI_in_indices_two_jumps_p_tab(i).allocate (dimension_pp_2p2h_space_BP_S_iM_fixed_max);
    }
      
  class GSM_vector &PSI_in_full = get_PSI_in_full ();
    
  double H_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp = outSDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = outSDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sp = outSDp_qn.get_S ();

      const int Sn = S - Sp;
      
      const int n_spec_p = outSDp_qn.get_n_spec ();

      const int n_spec_n = n_spec_max - n_spec_p;
      
      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

      if (all_dimensions_SDn_zero) continue;

      const int iMn = iM - iMp;

      const int TRS_iMp = iMp_max - iMp;

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();
      
      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class jumps_data_out_to_in_str &two_jumps_p = two_jumps_p_tab(i_thread);
	     
      class array<TYPE> &NBMEs_two_jumps_p = NBMEs_two_jumps_p_tab(i_thread);
	      
      class array<bool> &is_configuration_accepted_two_jumps_p_tab = is_configuration_accepted_two_jumps_p_tabs(i_thread);
	      
      class array<unsigned long int> &total_PSI_in_indices_two_jumps_p = total_PSI_in_indices_two_jumps_p_tab(i_thread);
		
      bool are_jumps_p_calculated = false;

      bool are_there_two_jumps_calc_all = true;

      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && are_there_two_jumps_calc_all ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
	  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
			  
	  for (unsigned int iCn = iCn_min ; (iCn <= iCn_max) && are_there_two_jumps_calc_all ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
	      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

	      if (dimension_SDn == 0) continue;
				  
	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , iMp);
				  
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_SDn*outSDp_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_SDn_minus_one;
				  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , TRS_iMp)) : (NADA);
		  				  
		  const unsigned long int total_SDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_SDn*outSDp_TRS_index) : (NADA);
			      
		  if (!are_jumps_p_calculated)
		    {
		      are_there_two_jumps_calc_all = false;
		
		      NBMEs_two_jumps_pp_nn_calc_partial_storage_on_the_fly (BPp , Sp , n_spec_p , iMp , n_scat_p_out , iCp_out , outSDp_index , prot_Y_data , are_there_two_jumps_calc_all , two_jumps_p , NBMEs_two_jumps_p);
		
		      are_jumps_p_calculated = true;
		    }

		  if (!are_there_two_jumps_calc_all) continue;
		  		  
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + SDn_index;

		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  const unsigned long int total_SDn_TRS_indices_index = (is_it_TRS) ? (total_SDn_TRS_indices_zero_index + SDn_index) : (NADA);

			  const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_SDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + SDn_TRS_index) : (NADA);

			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {					
			      bool are_there_two_jumps_calc = false;

			      is_configuration_accepted_total_PSI_in_indices_p_fill (BPn , Sn , n_spec_n , n_holes_n , n_scat_n , iCn , iMn , SDn_index , En_hw , two_jumps_p , GSM_vector_helper , dimension_SDn , 
										     is_configuration_accepted_two_jumps_p_tab , total_PSI_in_indices_two_jumps_p , are_there_two_jumps_calc);

			      if (are_there_two_jumps_calc)
				{
				  const unsigned int dimension_two_jumps_p = two_jumps_p.get_dimension ();
	    
				  PSI_out[PSI_out_index] += component_part_jumps_calc (dimension_two_jumps_p , is_configuration_accepted_two_jumps_p_tab , total_PSI_in_indices_two_jumps_p , NBMEs_two_jumps_p , PSI_in_full);
					    
				  H_multiplications_number_local += component_part_jumps_number_calc (dimension_two_jumps_p , is_configuration_accepted_two_jumps_p_tab);
				}
			      
			    }}}}}}}

  H_multiplications_number += H_multiplications_number_local;
}








void H_class::jumps_n_one_body_part_pn_calc_on_the_fly (class GSM_vector &PSI_out) const
{ 
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw ();  
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
      
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
 
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM (); 

  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();

  const int iMp_max = prot_Y_data.get_iM_max ();   
    
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
    
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
    
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
  
  class array<class Slater_determinant> outSDn_tab(NUMBER_OF_THREADS);
  
  class array<class jumps_data_out_to_in_str> one_jump_n_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > NBMEs_n_one_jump_n_tab(NUMBER_OF_THREADS);
	      
  class array<class array<bool> > is_configuration_accepted_one_jump_n_tabs(NUMBER_OF_THREADS);
	      
  class array<class array<unsigned long int> > total_PSI_in_indices_one_jump_n_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      outSDn_tab(i).allocate (NYval);
      
      one_jump_n_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      NBMEs_n_one_jump_n_tab(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);	      
	      
      is_configuration_accepted_one_jump_n_tabs(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);
	      
      total_PSI_in_indices_one_jump_n_tab(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);
    }
      
  class GSM_vector &PSI_in_full = get_PSI_in_full ();
      
  double H_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn = outSDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = outSDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sn = outSDn_qn.get_S ();

      const int Sp = S - Sn;
      
      const int n_spec_n = outSDn_qn.get_n_spec ();

      const int n_spec_p = n_spec_max - n_spec_n;

      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

      if (dimension_outSDn == 0) continue;

      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

      if (all_dimensions_SDp_zero) continue;

      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const int iMp = iM - iMn;

      const int TRS_iMp = iMp_max - iMp;

      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index)) : (NADA);

      const unsigned int i_thread = OpenMP_thread_number_determine ();
	      
      class Slater_determinant &outSDn = outSDn_tab(i_thread);
      
      class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(i_thread);
      
      class array<TYPE> &NBMEs_n_one_jump_n = NBMEs_n_one_jump_n_tab(i_thread);
	      
      class array<bool> &is_configuration_accepted_one_jump_n_tab = is_configuration_accepted_one_jump_n_tabs(i_thread);
	      
      class array<unsigned long int> &total_PSI_in_indices_one_jump_n = total_PSI_in_indices_one_jump_n_tab(i_thread);

      bool are_jumps_n_calculated = false;

      bool is_there_one_jump_calc_all = true;

      outSDn = SDn_set(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index);
      
      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && is_there_one_jump_calc_all ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
			  
	  for (unsigned int iCp = iCp_min ; (iCp <= iCp_max) && is_there_one_jump_calc_all ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

	      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

	      if (dimension_SDp == 0) continue;
	      				  
	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;
				  
	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , iMp);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_SDp_minus_one*dimension_outSDn;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_SDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);
				      
		  if (!are_jumps_n_calculated)
		    {			    
		      bool is_there_one_jump_calc = false;
		      
		      NBMEs_one_jump_pp_nn_calc_partial_storage_on_the_fly (BPn , Sn , n_spec_n , iMn , n_scat_n_out , iCn_out , outSDn_index , outSDn , neut_Y_data , is_there_one_jump_calc , one_jump_n , NBMEs_n_one_jump_n);
		      
		      is_there_one_jump_calc_all = is_there_one_jump_calc;

		      are_jumps_n_calculated = true;
		    }

		  if (!is_there_one_jump_calc_all) continue;
		  
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + SDp_index*dimension_outSDn;

		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  const unsigned long int total_SDp_TRS_indices_index = (is_it_TRS) ? (total_SDp_TRS_indices_zero_index + SDp_index) : (NADA);

			  const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_SDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + dimension_outSDn*SDp_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {
			      bool is_there_one_jump_calc = false;
						      
			      is_configuration_accepted_total_PSI_in_indices_n_fill (BPp , Sp , n_spec_p , n_holes_p , n_scat_p , iCp , iMp , SDp_index , Ep_hw , one_jump_n , GSM_vector_helper , 
										     is_configuration_accepted_one_jump_n_tab , total_PSI_in_indices_one_jump_n , is_there_one_jump_calc);

			      if (is_there_one_jump_calc)
				{
				  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
				  
				  PSI_out[PSI_out_index] += component_part_jumps_calc (dimension_one_jump_n , is_configuration_accepted_one_jump_n_tab ,
										       total_PSI_in_indices_one_jump_n , NBMEs_n_one_jump_n , PSI_in_full);
				  
				  H_multiplications_number_local += component_part_jumps_number_calc (dimension_one_jump_n , is_configuration_accepted_one_jump_n_tab);
				}

			    }}}}}}}

  H_multiplications_number += H_multiplications_number_local;
}








void H_class::jumps_n_two_body_part_pn_calc_on_the_fly (class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw ();  
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
 
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM (); 

  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();

  const int iMp_max = prot_Y_data.get_iM_max ();   
    
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  if (NYval == 1) return;
  
  const unsigned int dimension_nn_2p2h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_2p2h_space_BP_S_iM_fixed_max ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
    
  class array<class jumps_data_out_to_in_str> two_jumps_n_tab(NUMBER_OF_THREADS);  	      
  
  class array<class array<TYPE> > NBMEs_two_jumps_n_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_configuration_accepted_two_jumps_n_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_in_indices_two_jumps_n_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      two_jumps_n_tab(i).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_nn_2p2h_space_BP_S_iM_fixed_max);
		
      NBMEs_two_jumps_n_tab(i).allocate (dimension_nn_2p2h_space_BP_S_iM_fixed_max);
      
      is_configuration_accepted_two_jumps_n_tabs(i).allocate (dimension_nn_2p2h_space_BP_S_iM_fixed_max);

      total_PSI_in_indices_two_jumps_n_tab(i).allocate (dimension_nn_2p2h_space_BP_S_iM_fixed_max);
    }
          
  class GSM_vector &PSI_in_full = get_PSI_in_full ();
     
  double H_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn = outSDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = outSDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sn = outSDn_qn.get_S ();

      const int Sp = S - Sn;
      
      const int n_spec_n = outSDn_qn.get_n_spec ();

      const int n_spec_p = n_spec_max - n_spec_n;
      
      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

      if (dimension_outSDn == 0) continue;

      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

      if (all_dimensions_SDp_zero) continue;

      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
      
      const int iMp = iM - iMn;

      const int TRS_iMp = iMp_max - iMp;		  

      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index)) : (NADA);
            
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class jumps_data_out_to_in_str &two_jumps_n = two_jumps_n_tab(i_thread);
	            
      class array<TYPE> &NBMEs_two_jumps_n = NBMEs_two_jumps_n_tab(i_thread);
      
      class array<bool> &is_configuration_accepted_two_jumps_n_tab = is_configuration_accepted_two_jumps_n_tabs(i_thread);
	      
      class array<unsigned long int> &total_PSI_in_indices_two_jumps_n = total_PSI_in_indices_two_jumps_n_tab(i_thread);

      bool are_jumps_n_calculated = false;

      bool are_there_two_jumps_calc_all = true;

      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && are_there_two_jumps_calc_all ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
			  
	  for (unsigned int iCp = iCp_min ; (iCp <= iCp_max) && are_there_two_jumps_calc_all ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

	      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

	      if (dimension_SDp == 0) continue;
	      				  
	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;
				  
	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , iMp);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_SDp_minus_one*dimension_outSDn;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_SDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);
				      	      
		  if (!are_jumps_n_calculated)
		    {
		      are_there_two_jumps_calc_all = false;
		      
		      NBMEs_two_jumps_pp_nn_calc_partial_storage_on_the_fly (BPn , Sn , n_spec_n , iMn , n_scat_n_out , iCn_out , outSDn_index , neut_Y_data , are_there_two_jumps_calc_all , two_jumps_n , NBMEs_two_jumps_n);

		      are_jumps_n_calculated = true;
		    }

		  if (!are_there_two_jumps_calc_all) continue;
		  		  
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + SDp_index*dimension_outSDn;

		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  const unsigned long int total_SDp_TRS_indices_index = (is_it_TRS) ? (total_SDp_TRS_indices_zero_index + SDp_index) : (NADA);

			  const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_SDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + dimension_outSDn*SDp_TRS_index) : (NADA);

			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {
			      bool are_there_two_jumps_calc = false;

			      is_configuration_accepted_total_PSI_in_indices_n_fill (BPp , Sp , n_spec_p , n_holes_p , n_scat_p , iCp , iMp , SDp_index , Ep_hw , two_jumps_n , GSM_vector_helper , 
										     is_configuration_accepted_two_jumps_n_tab , total_PSI_in_indices_two_jumps_n , are_there_two_jumps_calc);
			      
			      if (are_there_two_jumps_calc)
				{
				  const unsigned int dimension_two_jumps_n = two_jumps_n.get_dimension ();
				    
				  PSI_out[PSI_out_index] += component_part_jumps_calc (dimension_two_jumps_n , is_configuration_accepted_two_jumps_n_tab , total_PSI_in_indices_two_jumps_n , NBMEs_two_jumps_n , PSI_in_full);
				  
				  H_multiplications_number_local += component_part_jumps_number_calc (dimension_two_jumps_n , is_configuration_accepted_two_jumps_n_tab);
				}
			      
			    }}}}}}}

  H_multiplications_number += H_multiplications_number_local;
}









void H_class::one_jump_p_pn_part_pn_calc_on_the_fly (class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
 
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM (); 

  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
  
  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
      
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const unsigned int Np_nljm = prot_Y_data.get_N_nljm_baryon ();
        	
  const int two_mp_max = prot_Y_data.get_two_m_max ();

  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
 		  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
      
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_out_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const unsigned long int total_SDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_SDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();

  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  
  const bool is_one_jump_p_tabs_filled = one_jump_p_tabs.is_it_filled ();
  
  if (total_SDn_index_min > total_SDn_index_max) return;
  
  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn ();
  
  const bool are_M_TBMEs_stored = (M_TBMEs_storage != ON_THE_FLY);
  
  class array<class Slater_determinant> SDn_tab(NUMBER_OF_THREADS);
  
  class array<class jumps_data_out_to_in_str> one_jump_p_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > NBMEs_pn_one_jump_p_no_phase_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > NBMEs_pn_one_jump_p_no_phase_calculated_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SDn_tab(i).allocate (NYval);
      
      if (!is_one_jump_p_tabs_filled) one_jump_p_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
      
      NBMEs_pn_one_jump_p_no_phase_tab(i).allocate (Np_nljm , Np_nljm);

      NBMEs_pn_one_jump_p_no_phase_calculated_tab(i).allocate (Np_nljm , Np_nljm);
    }
  
  class GSM_vector &PSI_in_full = get_PSI_in_full ();
   
  double H_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_SDn_index = total_SDn_index_min ; total_SDn_index <= total_SDn_index_max ; total_SDn_index++)
    {
      const class SD_quantum_numbers &SDn_qn = SDn_quantum_numbers_tab(total_SDn_index);

      const int iMn = SDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = SDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sn = SDn_qn.get_S ();

      const int Sp = S - Sn;
      
      const int n_spec_n = SDn_qn.get_n_spec ();

      const int n_spec_p = n_spec_max - n_spec_n;

      const int n_scat_n = SDn_qn.get_n_scat ();
	
      const unsigned int iCn = SDn_qn.get_iC ();

      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (dimension_SDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (all_dimensions_SDp_zero) continue;
		  
      const unsigned int SDn_index = SDn_qn.get_SD_index ();
            
      const int iMp = iM - iMn;

      const int TRS_iMp = iMp_max - iMp;
      
      const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class Slater_determinant &SDn = SDn_tab(i_thread);
      
      class array<TYPE> &NBMEs_pn_one_jump_p_no_phase = NBMEs_pn_one_jump_p_no_phase_tab(i_thread);

      class array<bool> &NBMEs_pn_one_jump_p_no_phase_calculated = NBMEs_pn_one_jump_p_no_phase_calculated_tab(i_thread);
        
      SDn = SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index);
      
      NBMEs_pn_one_jump_p_no_phase = 0.0;

      NBMEs_pn_one_jump_p_no_phase_calculated = false;

      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_process_tab(BPp , Sp , n_spec_p , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_process_tab(BPp , Sp , n_spec_p , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , iMp);
	          
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + SDn_index;
	      
	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_SDn*dimension_outSDp_minus_one;
				  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{		  
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_outSDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + SDn_TRS_index) : (NADA);
				    
		  const unsigned long int total_outSDp_index_zero = SDp_set.index_determine (BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , 0);
		  
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDp_index*dimension_SDn;
				      
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
						  
			  const unsigned long int total_outSDp_TRS_indices_index = (is_it_TRS) ? (total_outSDp_TRS_indices_zero_index + outSDp_index) : (NADA);

			  const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_outSDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + dimension_SDn*outSDp_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {
			      const unsigned long int total_outSDp_index = total_outSDp_index_zero + outSDp_index;

			      const unsigned long int total_outSDp_index_shifted = total_outSDp_index - total_outSDp_index_min;

			      class jumps_data_out_to_in_str &one_jump_p = (is_one_jump_p_tabs_filled) ? (one_jump_p_tabs(total_outSDp_index_shifted)(BPp , Sp , two_mp_max)) : (one_jump_p_tab(i_thread));

			      if (!is_one_jump_p_tabs_filled) one_jump_p.one_jump_mu_store (BPp , Sp , n_spec_p , iMp , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index , prot_Y_data);
			      
			      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();

			      unsigned long int total_PSI_in_index_zero = 0;

			      bool is_configuration_accepted = true; 

			      unsigned int H_multiplications_number_sublocal = 0;
			      
			      TYPE component_part = 0.0;

			      for (unsigned int i = 0 ; i < dimension_one_jump_p ; i++)
				{
				  const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(i);

				  const bool is_configuration_changing = one_jump_p_inSDp.get_is_configuration_changing ();

				  if (is_configuration_changing)
				    { 
				      const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
				      
				      const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();

				      const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();

				      is_configuration_accepted =
					is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_hw_in , n_holes_max_p , n_scat_max_p , Ep_max_hw) &&
					is_basis_state_in_space_pn    (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_hw_in , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw);

				      if (is_configuration_accepted) 
					{
					  const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();

					  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p_in , n_scat_n , iCp_in , iCn , iMp);

					  total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in + SDn_index;
					}
				    }

				  if (is_configuration_accepted)
				    {
				      const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

				      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero + dimension_SDn*inSDp_index;

				      const unsigned int p_in  = one_jump_p_inSDp.get_mu_in ();
				      const unsigned int p_out = one_jump_p_inSDp.get_mu_out ();

				      const unsigned int total_bin_phase_p = one_jump_p_inSDp.get_total_bin_phase ();

				      const bool NBME_pn_one_jump_p_no_phase_calculated = NBMEs_pn_one_jump_p_no_phase_calculated(p_in , p_out);

				      const int total_phase_p = parity_from_binary_parity (total_bin_phase_p);
				      
				      const TYPE &PSI_in_component = PSI_in_full[total_PSI_in_index];
					      
				      if (!NBME_pn_one_jump_p_no_phase_calculated)
					{ 
					  const TYPE NBME_pn_one_jump_p_no_phase = (are_M_TBMEs_stored)
					    ? (H_NBMEs::pn_no_phase_one_jump_p_calc (p_in , p_out , SDn , M_TBMEs))
					    : (H_NBMEs::pn_no_phase_one_jump_p_calc (p_in , p_out , SDn , TBMEs_pn));
 
					  NBMEs_pn_one_jump_p_no_phase(p_in , p_out) = NBMEs_pn_one_jump_p_no_phase(p_out , p_in) = NBME_pn_one_jump_p_no_phase;
					  NBMEs_pn_one_jump_p_no_phase_calculated(p_in , p_out) = NBMEs_pn_one_jump_p_no_phase_calculated(p_out , p_in) = true;
						  
					  (total_phase_p == 1) ? (component_part += PSI_in_component*NBME_pn_one_jump_p_no_phase) : (component_part -= PSI_in_component*NBME_pn_one_jump_p_no_phase);
					}
				      else
					{
					  const TYPE NBME_pn_one_jump_p_no_phase = NBMEs_pn_one_jump_p_no_phase(p_in , p_out);
						  
					  (total_phase_p == 1) ? (component_part += PSI_in_component*NBME_pn_one_jump_p_no_phase) : (component_part -= PSI_in_component*NBME_pn_one_jump_p_no_phase);
					}
				      
				      H_multiplications_number_sublocal++;
				    }
				}
					    
			      PSI_out[PSI_out_index] += component_part;
			      
			      H_multiplications_number_local += H_multiplications_number_sublocal;

			    }}}}}}}
  
  H_multiplications_number += H_multiplications_number_local;
}









void H_class::one_jump_n_pn_part_pn_calc_on_the_fly (class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
 
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM (); 

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
      
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  const unsigned int Nn_nljm = neut_Y_data.get_N_nljm_baryon ();

  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
 
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
    
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
 
  const class array<unsigned int> &iCn_out_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_out_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int total_SDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_SDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  
  const bool is_one_jump_n_tabs_filled = one_jump_n_tabs.is_it_filled ();
    
  if (total_SDp_index_min > total_SDp_index_max) return;
  
  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn ();
      
  const bool are_M_TBMEs_stored = (M_TBMEs_storage != ON_THE_FLY);
  
  class array<class Slater_determinant> SDp_tab(NUMBER_OF_THREADS);
  
  class array<class jumps_data_out_to_in_str> one_jump_n_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > NBMEs_pn_one_jump_n_no_phase_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > NBMEs_pn_one_jump_n_no_phase_calculated_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SDp_tab(i).allocate (ZYval);
      
      if (!is_one_jump_n_tabs_filled) one_jump_n_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      NBMEs_pn_one_jump_n_no_phase_tab(i).allocate (Nn_nljm , Nn_nljm);

      NBMEs_pn_one_jump_n_no_phase_calculated_tab(i).allocate (Nn_nljm , Nn_nljm);
    }
    
  class GSM_vector &PSI_in_full = get_PSI_in_full ();
    
  double H_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_SDp_index = total_SDp_index_min ; total_SDp_index <= total_SDp_index_max ; total_SDp_index++)
    {
      const class SD_quantum_numbers &SDp_qn = SDp_quantum_numbers_tab(total_SDp_index);

      const int iMp = SDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = SDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sp = SDp_qn.get_S ();

      const int Sn = S - Sp;
      
      const int n_spec_p = SDp_qn.get_n_spec ();

      const int n_spec_n = n_spec_max - n_spec_p;

      const int n_scat_p = SDp_qn.get_n_scat ();
	
      const unsigned int iCp = SDp_qn.get_iC ();

      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (dimension_SDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (all_dimensions_SDn_zero) continue;

      const int iMn = iM - iMp;

      const int TRS_iMp = iMp_max - iMp;

      const unsigned int SDp_index = SDp_qn.get_SD_index ();
      
      const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class Slater_determinant &SDp = SDp_tab(i_thread);

      class array<TYPE> &NBMEs_pn_one_jump_n_no_phase = NBMEs_pn_one_jump_n_no_phase_tab(i_thread);

      class array<bool> &NBMEs_pn_one_jump_n_no_phase_calculated = NBMEs_pn_one_jump_n_no_phase_calculated_tab(i_thread);

      SDp = SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index);
      
      NBMEs_pn_one_jump_n_no_phase = 0.0;

      NBMEs_pn_one_jump_n_no_phase_calculated = false;

      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_process_tab(BPn , Sn , n_spec_n , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_process_tab(BPn , Sn , n_spec_n , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);
      
	      const int En_hw_out = En_hw_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , iMp);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*SDp_index;
	      
	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{		  
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , TRS_iMp)) : (NADA);
		  
		  const unsigned long int total_outSDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_outSDn*SDp_TRS_index) : (NADA);
				      
		  const unsigned long int total_outSDn_index_zero = SDn_set.index_determine (BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , 0);
		  
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDn_index;
				      
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
					      
			  const unsigned long int total_outSDn_TRS_indices_index = (is_it_TRS) ? (total_outSDn_TRS_indices_zero_index + outSDn_index) : (NADA);

			  const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_outSDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + outSDn_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {
			      const unsigned long int total_outSDn_index = total_outSDn_index_zero + outSDn_index;

			      const unsigned long int total_outSDn_index_shifted = total_outSDn_index - total_outSDn_index_min;

			      class jumps_data_out_to_in_str &one_jump_n = (is_one_jump_n_tabs_filled) ? (one_jump_n_tabs(total_outSDn_index_shifted)(BPn , Sn , two_mn_max)) : (one_jump_n_tab(i_thread));
				  
			      if (!is_one_jump_n_tabs_filled) one_jump_n.one_jump_mu_store (BPn , Sn , n_spec_n , iMn , n_holes_max_n , n_scat_max_n , En_max_hw , BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index , neut_Y_data);
			  
			      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

			      unsigned long int total_PSI_in_index_zero = 0;

			      bool is_configuration_accepted = true; 

			      unsigned int H_multiplications_number_sublocal = 0;
			      
			      TYPE component_part = 0.0;

			      for (unsigned int i = 0 ; i < dimension_one_jump_n ; i++)
				{
				  const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(i);

				  const bool is_configuration_changing = one_jump_n_inSDn.get_is_configuration_changing ();

				  if (is_configuration_changing)
				    { 
				      const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
				      
				      const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();

				      const int En_hw_in = one_jump_n_inSDn.get_E_hw ();
				      
				      is_configuration_accepted =
					is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_in , n_scat_n_in , En_hw_in , n_holes_max_n , n_scat_max_n , En_max_hw) &&
					is_basis_state_in_space_pn    (truncation_hw , truncation_ph , n_holes_p    , n_scat_p    , Ep_hw , n_holes_n_in , n_scat_n_in , En_hw_in , n_holes_max , n_scat_max , E_max_hw);

				      if (is_configuration_accepted)
					{
					  const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();

					  const int iMn = iM - iMp;

					  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_in , iCp , iCn_in , iMp);

					  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_in , iCn_in , iMn);

					  total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*SDp_index;
					}
				    } 

				  if (is_configuration_accepted)
				    {
				      const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

				      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero + inSDn_index;

				      const unsigned int n_in  = one_jump_n_inSDn.get_mu_in ();
				      const unsigned int n_out = one_jump_n_inSDn.get_mu_out ();

				      const unsigned int total_bin_phase_n = one_jump_n_inSDn.get_total_bin_phase ();

				      const bool NBME_pn_one_jump_n_no_phase_calculated = NBMEs_pn_one_jump_n_no_phase_calculated(n_in , n_out);

				      const int total_phase_n = parity_from_binary_parity (total_bin_phase_n);
				      
				      const TYPE &PSI_in_component = PSI_in_full[total_PSI_in_index];
					      
				      if (!NBME_pn_one_jump_n_no_phase_calculated)
					{
					  const TYPE NBME_pn_one_jump_n_no_phase = (are_M_TBMEs_stored)
					    ? (H_NBMEs::pn_no_phase_one_jump_n_calc (n_in , n_out , SDp , M_TBMEs))
					    : (H_NBMEs::pn_no_phase_one_jump_n_calc (n_in , n_out , SDp , TBMEs_pn));

					  NBMEs_pn_one_jump_n_no_phase(n_in , n_out) = NBMEs_pn_one_jump_n_no_phase(n_out , n_in) = NBME_pn_one_jump_n_no_phase;
					  
					  NBMEs_pn_one_jump_n_no_phase_calculated(n_in , n_out) = NBMEs_pn_one_jump_n_no_phase_calculated(n_out , n_in) = true;
						  
					  (total_phase_n == 1) ? (component_part += PSI_in_component*NBME_pn_one_jump_n_no_phase) : (component_part -= PSI_in_component*NBME_pn_one_jump_n_no_phase);
					}
				      else
					{
					  const TYPE NBME_pn_one_jump_n_no_phase = NBMEs_pn_one_jump_n_no_phase(n_in , n_out);
						  
					  (total_phase_n == 1) ? (component_part += PSI_in_component*NBME_pn_one_jump_n_no_phase) : (component_part -= PSI_in_component*NBME_pn_one_jump_n_no_phase);
					}
				      
				      H_multiplications_number_sublocal++;
				    }
				}
						  
			      PSI_out[PSI_out_index] += component_part;
			     
			      H_multiplications_number_local += H_multiplications_number_sublocal; 

			    }}}}}}}
  
  H_multiplications_number += H_multiplications_number_local;
}




		
		





void H_class::two_jumps_pn_part_pn_on_the_fly_one_jumps_stored_N_valence_larger_calc (class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
 
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
  
  const int iMp_max = prot_Y_data.get_iM_max ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
 
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const bool are_M_TBMEs_stored = (M_TBMEs_storage != ON_THE_FLY);
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_out_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
    
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();
      
  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn ();
  
  class GSM_vector &PSI_in_full = get_PSI_in_full ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
    
  double H_multiplications_number_local = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();
      
      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();
      
      const unsigned int BPp_out = binary_parity_product (BPn_out , BP);

      const int Sn_out = outSDn_qn.get_S ();

      const int Sp_out = S - Sn_out;
      
      const int n_spec_n_out = outSDn_qn.get_n_spec ();

      const int n_spec_p_out = n_spec_max - n_spec_n_out;

      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;
		  
      const int n_spec_p_in = n_spec_p_out;
      const int n_spec_n_in = n_spec_n_out;
      
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const int iMp_out = iM - iMn_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);
      
      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index)) : (NADA);
        
      const unsigned long int total_outSDn_index_shifted = total_outSDn_index - total_outSDn_index_min;

      const class array<class jumps_data_out_to_in_str> &one_jump_n_tab = one_jump_n_tabs(total_outSDn_index_shifted);
			  
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
	      
	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
	      
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS)
		    ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out))
		    : (NADA);
				  
		  const unsigned long int total_outSDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);
		      
		  const unsigned long int total_outSDp_index_zero = SDp_set.index_determine (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , 0);
		  
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDp_index*dimension_outSDn;
      
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned long int total_outSDp_index = total_outSDp_index_zero + outSDp_index;

			  const unsigned long int total_outSDp_index_shifted = total_outSDp_index - total_outSDp_index_min;

			  const class array<class jumps_data_out_to_in_str> &one_jump_p_tab = one_jump_p_tabs(total_outSDp_index_shifted);
			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
						  
			  const unsigned long int total_outSDp_TRS_indices_index = (is_it_TRS) ? (total_outSDp_TRS_indices_zero_index + outSDp_index) : (NADA);
			  
			  const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_outSDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + dimension_outSDn*outSDp_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {			      
			      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
				{
				  const unsigned int BPn_in = binary_parity_product (BP , BPp_in);
	  
				  for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				    {
				      const int Sn_in = S - Sp_in;
				      
				      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
					{
					  const int iMn_in = iM - iMp_in;
				      
					  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
					  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
					  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
					  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				      
					  const class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in);
				
					  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
				      
					  if (dimension_one_jump_n == 0) continue;

					  const class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in);
				      
					  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				      
					  if (dimension_one_jump_p == 0) continue;
		  				  
					  unsigned long int total_PSI_in_index_zero_inSDn = 0;
					      
					  bool is_configuration_accepted = true;
											      
					  unsigned int H_multiplications_number_sublocal = 0;
				      
					  TYPE component_part = 0.0;
				      
					  for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
					    {
					      const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);

					      const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
					  
					      const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();

					      const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();

					      const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();
					  
					      const unsigned int p_in  = one_jump_p_inSDp.get_mu_in ();
					      const unsigned int p_out = one_jump_p_inSDp.get_mu_out ();

					      const class nljm_struct &phi_p_out = phi_p_table(p_out);
  
					      const unsigned int p_out_shell = phi_p_out.get_shell_index ();
					  
					      const unsigned int total_bin_phase_p = one_jump_p_inSDp.get_total_bin_phase ();
					  
					      const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();
					
					      for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)
						{
						  const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);

						  const bool is_configuration_changing = one_jump_n_inSDn.get_is_configuration_changing ();

						  if (is_configuration_changing) 
						    {
						      const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
						  
						      const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();

						      const int En_hw_in = one_jump_n_inSDn.get_E_hw ();

						      is_configuration_accepted = true;
									  
						      if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) is_configuration_accepted = false;
						  
						      if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max)))    is_configuration_accepted = false;
									  
						      if (is_configuration_accepted) 
							{					  
							  const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();

							  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
						      
							  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
			      			      
							  total_PSI_in_index_zero_inSDn = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*inSDp_index;
							}
						    }
					           
						  if (is_configuration_accepted)
						    {
						      const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

						      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDn + inSDn_index;

						      const unsigned int n_in  = one_jump_n_inSDn.get_mu_in ();
						      const unsigned int n_out = one_jump_n_inSDn.get_mu_out ();

						      const TYPE &PSI_in_component = PSI_in_full[total_PSI_in_index];
						      
						      const unsigned int total_bin_phase_n = one_jump_n_inSDn.get_total_bin_phase ();

						      if (are_M_TBMEs_stored)
							{
							  const unsigned int M_TBMEs_pn_index = M_TBMEs_pn_indices(p_in , n_in , p_out_shell , n_out);
						  
							  const TYPE TBME = M_TBMEs[M_TBMEs_pn_index];
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}
						      else
							{						  
							  const TYPE TBME = TBMEs_pn.M_TBME (false , p_in , n_in , p_out , n_out);							  
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}

						      H_multiplications_number_sublocal++;
						    }
						}
					    }
							  
					  PSI_out[PSI_out_index] += component_part;
				  
					  H_multiplications_number_local += H_multiplications_number_sublocal;
				      
					}}}}}}}}}}
  
  H_multiplications_number += H_multiplications_number_local;
}








void H_class::two_jumps_pn_part_pn_on_the_fly_one_jumps_stored_Z_valence_larger_calc (class GSM_vector &PSI_out) const
{  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
 
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const int iMp_max = prot_Y_data.get_iM_max ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
    
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
 
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
	  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  const bool are_M_TBMEs_stored = (M_TBMEs_storage != ON_THE_FLY);
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
 
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_out_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
    
  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn ();
  
  class GSM_vector &PSI_in_full = get_PSI_in_full ();
  
  if (total_outSDp_index_min > total_outSDp_index_max) return;
  
  double H_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();

      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);

      const int Sp_out = outSDp_qn.get_S ();

      const int Sn_out = S - Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();

      const int n_spec_n_out = n_spec_max - n_spec_p_out;

      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;
      
      const int n_spec_p_in = n_spec_p_out;
      const int n_spec_n_in = n_spec_n_out;

      const int iMn_out = iM - iMp_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();

      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index)) : (NADA);
                  
      const unsigned long int total_outSDp_index_shifted = total_outSDp_index - total_outSDp_index_min;
      
      const class array<class jumps_data_out_to_in_str> &one_jump_p_tab = one_jump_p_tabs(total_outSDp_index_shifted);
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;
	      
	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out)) : (NADA);
		  
		  const unsigned long int total_outSDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_outSDn*outSDp_TRS_index) : (NADA);
		  
		  const unsigned long int total_outSDn_index_zero = SDn_set.index_determine (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , 0);
		  
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDn_index;
		     			  
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned long int total_outSDn_index = total_outSDn_index_zero + outSDn_index;
			  
			  const unsigned long int total_outSDn_index_shifted = total_outSDn_index - total_outSDn_index_min;

			  const class array<class jumps_data_out_to_in_str> &one_jump_n_tab = one_jump_n_tabs(total_outSDn_index_shifted);
			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
					      
			  const unsigned long int total_outSDn_TRS_indices_index = (is_it_TRS) ? (total_outSDn_TRS_indices_zero_index + outSDn_index) : (NADA);
			  
			  const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_outSDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + outSDn_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {
			      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
				{
				  const unsigned int BPn_in = binary_parity_product (BP , BPp_in);
	  
				  for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				    {
				      const int Sn_in = S - Sp_in;
				      
				      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
					{
					  const int iMn_in = iM - iMp_in;
				      
					  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
					  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
					  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
					  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;

					  const class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in);
				
					  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				      
					  if (dimension_one_jump_p == 0) continue;

					  const class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in);
				      
					  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
				  
					  if (dimension_one_jump_n == 0) continue;

					  unsigned long int total_PSI_in_index_zero_inSDp = 0;
				      
					  unsigned int H_multiplications_number_sublocal = 0;
					      
					  bool is_configuration_accepted = true;
									  
					  TYPE component_part = 0.0;
				      
					  for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++) 
					    {
					      const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);
					  
					      const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
					  
					      const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();
					  
					      const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();
					  
					      const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();
					  
					      const unsigned int n_in  = one_jump_n_inSDn.get_mu_in ();
					      const unsigned int n_out = one_jump_n_inSDn.get_mu_out ();
					  
					      const class nljm_struct &phi_n_out = phi_n_table(n_out);
  
					      const unsigned int n_out_shell = phi_n_out.get_shell_index ();
					  
					      const unsigned int total_bin_phase_n = one_jump_n_inSDn.get_total_bin_phase ();
					  
					      const int En_hw_in = one_jump_n_inSDn.get_E_hw ();
					  
					      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
				      
					      for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
						{
						  const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);
					  
						  const bool is_configuration_changing = one_jump_p_inSDp.get_is_configuration_changing ();
		      
						  if (is_configuration_changing) 
						    { 
						      const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
						  
						      const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();
						  
						      const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();

						      is_configuration_accepted = true;
									  
						      if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) is_configuration_accepted = false;
						  
						      if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) is_configuration_accepted = false;
	  
						      if (is_configuration_accepted) 
							{
							  const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();
							  
							  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
							  
							  total_PSI_in_index_zero_inSDp = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;
							}
						    }
					      
						  if (is_configuration_accepted)
						    {
						      const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

						      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDp + dimension_inSDn*inSDp_index;
						  
						      const unsigned int p_in  = one_jump_p_inSDp.get_mu_in ();
						      const unsigned int p_out = one_jump_p_inSDp.get_mu_out ();

						      const unsigned int total_bin_phase_p = one_jump_p_inSDp.get_total_bin_phase ();
							  							      
						      const TYPE &PSI_in_component = PSI_in_full[total_PSI_in_index];
				      
						      if (are_M_TBMEs_stored)
							{
							  const unsigned int M_TBMEs_pn_index = M_TBMEs_pn_indices(p_in , n_in , p_out , n_out_shell);
						  
							  const TYPE TBME = M_TBMEs[M_TBMEs_pn_index];
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}
						      else
							{						  
							  const TYPE TBME = TBMEs_pn.M_TBME (false , p_in , n_in , p_out , n_out);							  
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}

						      H_multiplications_number_sublocal++;
						    }
						}
					    }
				      
					  PSI_out[PSI_out_index] += component_part;
				      
					  H_multiplications_number_local += H_multiplications_number_sublocal;
				      
					}}}}}}}}}}
  
  H_multiplications_number += H_multiplications_number_local;
}














void H_class::two_jumps_pn_part_pn_on_the_fly_one_jumps_partially_stored_N_valence_larger_calc (class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
 
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int S_plus_one = S + 1;
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
  
  const int iMp_max = prot_Y_data.get_iM_max ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();

  const int four_mn_max_plus_one = four_mn_max + 1;
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
 
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
    
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_out_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
    
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();
  
  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn ();

  const bool are_M_TBMEs_stored = (M_TBMEs_storage != ON_THE_FLY);
    
  class GSM_vector &PSI_in_full = get_PSI_in_full ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
  
  class array<class array<class jumps_data_out_to_in_str> > one_jump_n_tabs_local(NUMBER_OF_THREADS);
  
  class array<class array<bool> > is_one_jump_n_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      class array<class jumps_data_out_to_in_str> &one_jump_n_tab = one_jump_n_tabs_local(i);
      
      one_jump_n_tab.allocate (2 , S_plus_one , four_mn_max_plus_one);
      
      for (unsigned int BPn_in = 0 ; BPn_in <= 1 ; BPn_in++)
	for (int Sn_in = 0 ; Sn_in <= S ; Sn_in++)
	  for (int Delta_iMn_in = 0 ; Delta_iMn_in <= four_mn_max ; Delta_iMn_in++)
	    one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      is_one_jump_n_calculated_tabs(i).allocate (2 , S_plus_one , four_mn_max_plus_one);
    }
  
  double H_multiplications_number_local = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();
      
      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();
      
      const unsigned int BPp_out = binary_parity_product (BPn_out , BP);

      const int Sn_out = outSDn_qn.get_S ();
      
      const int Sp_out = S - Sn_out;
      
      const int n_spec_n_out = outSDn_qn.get_n_spec ();

      const int n_spec_p_out = n_spec_max - n_spec_n_out;

      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;	  
		  
      const int n_spec_p_in = n_spec_p_out;
      const int n_spec_n_in = n_spec_n_out;
		  
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const int iMp_out = iM - iMn_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);
      
      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index)) : (NADA);
  
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class array<bool> &is_one_jump_n_calculated_tab = is_one_jump_n_calculated_tabs(i_thread);

      class array<class jumps_data_out_to_in_str> &one_jump_n_tab = one_jump_n_tabs_local(i_thread);
        
      is_one_jump_n_calculated_tab = false;
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
	      
	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
	      
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS)
		    ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out))
		    : (NADA);
				  
		  const unsigned long int total_outSDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);
		      
		  const unsigned long int total_outSDp_index_zero = SDp_set.index_determine (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , 0);
		  
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDp_index*dimension_outSDn;
      
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned long int total_outSDp_index = total_outSDp_index_zero + outSDp_index;

			  const unsigned long int total_outSDp_index_shifted = total_outSDp_index - total_outSDp_index_min;

			  const class array<class jumps_data_out_to_in_str> &one_jump_p_tab = one_jump_p_tabs(total_outSDp_index_shifted);
			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
						  
			  const unsigned long int total_outSDp_TRS_indices_index = (is_it_TRS) ? (total_outSDp_TRS_indices_zero_index + outSDp_index) : (NADA);
			  
			  const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_outSDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + dimension_outSDn*outSDp_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {			      
			      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
				{
				  const unsigned int BPn_in = binary_parity_product (BP , BPp_in);
	  
				  for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				    {
				      const int Sn_in = S - Sp_in;
				      
				      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
					{
					  const int iMn_in = iM - iMp_in;
				      
					  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
					  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
					  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
					  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				      
					  class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in);
				      
					  bool &is_one_jump_n_calculated = is_one_jump_n_calculated_tab(BPn_in , Sn_in , Delta_iMn_in);

					  if (!is_one_jump_n_calculated)
					    {
					      one_jump_n.one_jump_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw , BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , neut_Y_data);
				      
					      is_one_jump_n_calculated = true;
					    }
				
					  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
				      
					  if (dimension_one_jump_n == 0) continue;

					  const class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in);
				      
					  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				      
					  if (dimension_one_jump_p == 0) continue;
		  				  
					  unsigned long int total_PSI_in_index_zero_inSDn = 0;
					      
					  bool is_configuration_accepted = true;
											      
					  unsigned int H_multiplications_number_sublocal = 0;
				      
					  TYPE component_part = 0.0;
				      
					  for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
					    {
					      const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);

					      const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
					  
					      const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();

					      const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();

					      const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();
					  
					      const unsigned int p_in  = one_jump_p_inSDp.get_mu_in ();
					      const unsigned int p_out = one_jump_p_inSDp.get_mu_out ();

					      const class nljm_struct &phi_p_out = phi_p_table(p_out);
  
					      const unsigned int p_out_shell = phi_p_out.get_shell_index ();
					  
					      const unsigned int total_bin_phase_p = one_jump_p_inSDp.get_total_bin_phase ();
					  
					      const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();
					
					      for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)
						{
						  const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);

						  const bool is_configuration_changing = one_jump_n_inSDn.get_is_configuration_changing ();

						  if (is_configuration_changing) 
						    {
						      const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
						  
						      const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();

						      const int En_hw_in = one_jump_n_inSDn.get_E_hw ();

						      is_configuration_accepted = true;
									  
						      if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) is_configuration_accepted = false;
						  
						      if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max)))    is_configuration_accepted = false;
									  
						      if (is_configuration_accepted) 
							{					  
							  const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();

							  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
						      
							  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
			      			      
							  total_PSI_in_index_zero_inSDn = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*inSDp_index;
							}
						    }
					           
						  if (is_configuration_accepted)
						    {
						      const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

						      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDn + inSDn_index;

						      const unsigned int n_in  = one_jump_n_inSDn.get_mu_in ();
						      const unsigned int n_out = one_jump_n_inSDn.get_mu_out ();

						      const unsigned int total_bin_phase_n = one_jump_n_inSDn.get_total_bin_phase ();
							  
						      const TYPE &PSI_in_component = PSI_in_full[total_PSI_in_index];
							  
						      if (are_M_TBMEs_stored)
							{
							  const unsigned int M_TBMEs_pn_index = M_TBMEs_pn_indices(p_in , n_in , p_out_shell , n_out);
						  
							  const TYPE TBME = M_TBMEs[M_TBMEs_pn_index];
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}
						      else
							{						  
							  const TYPE TBME = TBMEs_pn.M_TBME (false , p_in , n_in , p_out , n_out);							  
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}
						  
						      H_multiplications_number_sublocal++;
						    }
						}
					    }
							  
					  PSI_out[PSI_out_index] += component_part;
				  
					  H_multiplications_number_local += H_multiplications_number_sublocal;
				      
					}}}}}}}}}}
  
  H_multiplications_number += H_multiplications_number_local;
}








void H_class::two_jumps_pn_part_pn_on_the_fly_one_jumps_partially_stored_Z_valence_larger_calc (class GSM_vector &PSI_out) const
{  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
 
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int S_plus_one = S + 1;
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const int iMp_max = prot_Y_data.get_iM_max ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int four_mp_max_plus_one = four_mp_max + 1;
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();

  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
 
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
	  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
 
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_out_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();

  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn ();

  const bool are_M_TBMEs_stored = (M_TBMEs_storage != ON_THE_FLY);
    
  class GSM_vector &PSI_in_full = get_PSI_in_full ();
  
  if (total_outSDp_index_min > total_outSDp_index_max) return;
  
  class array<class array<class jumps_data_out_to_in_str> > one_jump_p_tabs_local(NUMBER_OF_THREADS);
  
  class array<class array<bool> > is_one_jump_p_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      class array<class jumps_data_out_to_in_str> &one_jump_p_tab = one_jump_p_tabs_local(i);
      
      one_jump_p_tab.allocate (2 , S_plus_one , four_mp_max_plus_one);
      
      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
	for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
	  for (int Delta_iMp_in = 0 ; Delta_iMp_in <= four_mp_max ; Delta_iMp_in++)
	    one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
      
      is_one_jump_p_calculated_tabs(i).allocate (2 , S_plus_one , four_mp_max_plus_one);
    }
  
  double H_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();

      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);

      const int Sp_out = outSDp_qn.get_S ();

      const int Sn_out = S - Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();

      const int n_spec_n_out = n_spec_max - n_spec_p_out;

      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;	  
		  
      const int n_spec_p_in = n_spec_p_out;
      const int n_spec_n_in = n_spec_n_out;

      const int iMn_out = iM - iMp_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();

      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index)) : (NADA);
                  
      const unsigned int i_thread = OpenMP_thread_number_determine ();
            
      class array<bool> &is_one_jump_p_calculated_tab = is_one_jump_p_calculated_tabs(i_thread);

      class array<class jumps_data_out_to_in_str> &one_jump_p_tab = one_jump_p_tabs_local(i_thread);
                  
      is_one_jump_p_calculated_tab = false;
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;
	      
	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out)) : (NADA);
		  
		  const unsigned long int total_outSDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_outSDn*outSDp_TRS_index) : (NADA);
		  
		  const unsigned long int total_outSDn_index_zero = SDn_set.index_determine (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , 0);
		  
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDn_index;
		     			  
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned long int total_outSDn_index = total_outSDn_index_zero + outSDn_index;
			  const unsigned long int total_outSDn_index_shifted = total_outSDn_index - total_outSDn_index_min;

			  const class array<class jumps_data_out_to_in_str> &one_jump_n_tab = one_jump_n_tabs(total_outSDn_index_shifted);
			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
					      
			  const unsigned long int total_outSDn_TRS_indices_index = (is_it_TRS) ? (total_outSDn_TRS_indices_zero_index + outSDn_index) : (NADA);
			  const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_outSDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + outSDn_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {
			      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
				{
				  const unsigned int BPn_in = binary_parity_product (BP , BPp_in);
	  	  
				  for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				    {
				      const int Sn_in = S - Sp_in;
				      
				      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
					{
					  const int iMn_in = iM - iMp_in;
				      
					  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
					  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
					  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
					  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;

					  class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in);

					  bool &is_one_jump_p_calculated = is_one_jump_p_calculated_tab(BPp_in , Sp_in , Delta_iMp_in);

					  if (!is_one_jump_p_calculated)
					    {
					      one_jump_p.one_jump_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , prot_Y_data);
				      
					      is_one_jump_p_calculated = true;
					    }
				
					  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				      
					  if (dimension_one_jump_p == 0) continue;

					  const class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in);
				      
					  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
				  
					  if (dimension_one_jump_n == 0) continue;

					  unsigned long int total_PSI_in_index_zero_inSDp = 0;
				      
					  unsigned int H_multiplications_number_sublocal = 0;
					      
					  bool is_configuration_accepted = true;
									  
					  TYPE component_part = 0.0;
				      
					  for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++) 
					    {
					      const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);
					  
					      const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
					  
					      const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();
					  
					      const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();
					  
					      const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();
					  
					      const unsigned int n_in  = one_jump_n_inSDn.get_mu_in ();
					      const unsigned int n_out = one_jump_n_inSDn.get_mu_out ();
					  
					      const class nljm_struct &phi_n_out = phi_n_table(n_out);
  
					      const unsigned int n_out_shell = phi_n_out.get_shell_index ();
					  
					      const unsigned int total_bin_phase_n = one_jump_n_inSDn.get_total_bin_phase ();
					  
					      const int En_hw_in = one_jump_n_inSDn.get_E_hw ();
					  
					      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
				      
					      for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
						{
						  const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);
					  
						  const bool is_configuration_changing = one_jump_p_inSDp.get_is_configuration_changing ();
		      
						  if (is_configuration_changing) 
						    { 
						      const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
						  
						      const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();
						  
						      const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();

						      is_configuration_accepted = true;
									  
						      if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) is_configuration_accepted = false;
						  
						      if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) is_configuration_accepted = false;
	  
						      if (is_configuration_accepted) 
							{
							  const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();
							  
							  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
							  
							  total_PSI_in_index_zero_inSDp = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;
							}
						    }
					      
						  if (is_configuration_accepted)
						    {
						      const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

						      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDp + dimension_inSDn*inSDp_index;
						  
						      const unsigned int p_in  = one_jump_p_inSDp.get_mu_in ();
						      const unsigned int p_out = one_jump_p_inSDp.get_mu_out ();

						      const unsigned int total_bin_phase_p = one_jump_p_inSDp.get_total_bin_phase ();
							  
						      const TYPE &PSI_in_component = PSI_in_full[total_PSI_in_index];

						      if (are_M_TBMEs_stored)
							{
							  const unsigned int M_TBMEs_pn_index = M_TBMEs_pn_indices(p_in , n_in , p_out , n_out_shell);
						  
							  const TYPE TBME = M_TBMEs[M_TBMEs_pn_index];
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}
						      else
							{						  
							  const TYPE TBME = TBMEs_pn.M_TBME (false , p_in , n_in , p_out , n_out);							  
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}						      

						      H_multiplications_number_sublocal++;
						    }
						}
					    }
				      
					  PSI_out[PSI_out_index] += component_part;
				      
					  H_multiplications_number_local += H_multiplications_number_sublocal;
				      
					}}}}}}}}}}
  
  H_multiplications_number += H_multiplications_number_local;
}











void H_class::two_jumps_pn_part_pn_on_the_fly_one_jumps_recalculated_N_valence_larger_calc (class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
 
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int S_plus_one = S + 1;
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
  
  const int iMp_max = prot_Y_data.get_iM_max ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int four_mn_max_plus_one = four_mn_max + 1;
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max (); 
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
    
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_out_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
    
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();
  
  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn ();

  const bool are_M_TBMEs_stored = (M_TBMEs_storage != ON_THE_FLY);
    
  class GSM_vector &PSI_in_full = get_PSI_in_full ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
  
  class array<class jumps_data_out_to_in_str> one_jump_p_tab(NUMBER_OF_THREADS);
  
  class array<class array<class jumps_data_out_to_in_str> > one_jump_n_tabs_local(NUMBER_OF_THREADS);
  
  class array<class array<bool> > is_one_jump_n_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_p_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
      
      class array<class jumps_data_out_to_in_str> &one_jump_n_tab = one_jump_n_tabs_local(i);
      
      one_jump_n_tab.allocate (2 , S_plus_one , four_mn_max_plus_one);
      
      for (unsigned int BPn_in = 0 ; BPn_in <= 1 ; BPn_in++)
	for (int Sn_in = 0 ; Sn_in <= S ; Sn_in++)
	  for (int Delta_iMn_in = 0 ; Delta_iMn_in <= four_mn_max ; Delta_iMn_in++)
	    one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      is_one_jump_n_calculated_tabs(i).allocate (2 , S_plus_one , four_mn_max_plus_one);
    }
  
  double H_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();

      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();

      const unsigned int BPp_out = binary_parity_product (BPn_out , BP);

      const int Sn_out = outSDn_qn.get_S ();

      const int Sp_out = S - Sn_out;
      
      const int n_spec_n_out = outSDn_qn.get_n_spec ();

      const int n_spec_p_out = n_spec_max - n_spec_n_out;

      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;	  
		  
      const int n_spec_p_in = n_spec_p_out;
      const int n_spec_n_in = n_spec_n_out;
		  
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const int iMp_out = iM - iMn_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);
      
      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index)) : (NADA);
  
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(i_thread);      
      
      class array<class jumps_data_out_to_in_str> &one_jump_n_tab = one_jump_n_tabs_local(i_thread);
      
      class array<bool> &is_one_jump_n_calculated_tab = is_one_jump_n_calculated_tabs(i_thread);
      
      is_one_jump_n_calculated_tab = false;
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
	      
	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
	      
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out)) : (NADA);
				  
		  const unsigned long int total_outSDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);
		      
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDp_index*dimension_outSDn;
      
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  const unsigned long int total_outSDp_TRS_indices_index = (is_it_TRS) ? (total_outSDp_TRS_indices_zero_index + outSDp_index) : (NADA);
			  const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_outSDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + dimension_outSDn*outSDp_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {			      
			      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
				{
				  const unsigned int BPn_in = binary_parity_product (BP , BPp_in);
	  
				  for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				    {
				      const int Sn_in = S - Sp_in;
	  
				      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
					{
					  const int iMn_in = iM - iMp_in;
				      
					  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
					  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
					  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
					  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;

					  class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in);

					  bool &is_one_jump_n_calculated = is_one_jump_n_calculated_tab(BPn_in , Sn_in , Delta_iMn_in);

					  if (!is_one_jump_n_calculated)
					    {
					      one_jump_n.one_jump_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw , BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , neut_Y_data);
				      
					      is_one_jump_n_calculated = true;
					    }
				
					  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
				      
					  if (dimension_one_jump_n == 0) continue;
				      
					  one_jump_p.one_jump_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , prot_Y_data);

					  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				  				    
					  if (dimension_one_jump_p == 0) continue;
		  				  
					  unsigned long int total_PSI_in_index_zero_inSDn = 0;
					      
					  bool is_configuration_accepted = true;
											      
					  unsigned int H_multiplications_number_sublocal = 0;
				      
					  TYPE component_part = 0.0;
				      
					  for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
					    {
					      const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);

					      const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
					  
					      const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();

					      const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();

					      const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();
					  
					      const unsigned int p_in  = one_jump_p_inSDp.get_mu_in ();
					      const unsigned int p_out = one_jump_p_inSDp.get_mu_out ();

					      const class nljm_struct &phi_p_out = phi_p_table(p_out);
  
					      const unsigned int p_out_shell = phi_p_out.get_shell_index ();
					  
					      const unsigned int total_bin_phase_p = one_jump_p_inSDp.get_total_bin_phase ();
					  
					      const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();
					  
					      for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)
						{
						  const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);
					      
						  const bool is_configuration_changing = one_jump_n_inSDn.get_is_configuration_changing ();
		      
						  if (is_configuration_changing) 
						    { 
						      const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
						  
						      const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();

						      const int En_hw_in = one_jump_n_inSDn.get_E_hw ();

						      is_configuration_accepted = true;
									  
						      if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) is_configuration_accepted = false;
						  
						      if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) is_configuration_accepted = false;
									  
						      if (is_configuration_accepted) 
							{					  
							  const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();
						      
							  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
			      
							  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
			      			      
							  total_PSI_in_index_zero_inSDn = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*inSDp_index;
							}
						    }
					           
						  if (is_configuration_accepted)
						    {
						      const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

						      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDn + inSDn_index;

						      const unsigned int n_in  = one_jump_n_inSDn.get_mu_in ();
						      const unsigned int n_out = one_jump_n_inSDn.get_mu_out ();

						      const unsigned int total_bin_phase_n = one_jump_n_inSDn.get_total_bin_phase ();
						  							  
						      const TYPE &PSI_in_component = PSI_in_full[total_PSI_in_index];

						      if (are_M_TBMEs_stored)
							{
							  const unsigned int M_TBMEs_pn_index = M_TBMEs_pn_indices(p_in , n_in , p_out_shell , n_out);
						  
							  const TYPE TBME = M_TBMEs[M_TBMEs_pn_index];
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}
						      else
							{						  
							  const TYPE TBME = TBMEs_pn.M_TBME (false , p_in , n_in , p_out , n_out);							  
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}						      

						      H_multiplications_number_sublocal++;
						    }
						}
					    }
							  
					  PSI_out[PSI_out_index] += component_part;
				  
					  H_multiplications_number_local += H_multiplications_number_sublocal;
				      
					}}}}}}}}}}
  
  H_multiplications_number += H_multiplications_number_local;
}








void H_class::two_jumps_pn_part_pn_on_the_fly_one_jumps_recalculated_Z_valence_larger_calc (class GSM_vector &PSI_out) const
{  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
 
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int S_plus_one = S + 1;
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const int iMp_max = prot_Y_data.get_iM_max ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
    
  const int four_mp_max_plus_one = four_mp_max + 1;
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();

  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max (); 
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
 
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_out_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn ();

  const bool are_M_TBMEs_stored = (M_TBMEs_storage != ON_THE_FLY);
    
  class GSM_vector &PSI_in_full = get_PSI_in_full ();
  
  if (total_outSDp_index_min > total_outSDp_index_max) return;
  
  class array<class jumps_data_out_to_in_str> one_jump_n_tab(NUMBER_OF_THREADS);
  
  class array<class array<class jumps_data_out_to_in_str> > one_jump_p_tabs_local(NUMBER_OF_THREADS);
  
  class array<class array<bool> > is_one_jump_p_calculated_tabs(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_n_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      class array<class jumps_data_out_to_in_str> &one_jump_p_tab = one_jump_p_tabs_local(i);
      
      one_jump_p_tab.allocate (2 , S_plus_one , four_mp_max_plus_one);
      
      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
	for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
	  for (int Delta_iMp_in = 0 ; Delta_iMp_in <= four_mp_max ; Delta_iMp_in++)
	    one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
      
      is_one_jump_p_calculated_tabs(i).allocate (2 , S_plus_one , four_mp_max_plus_one);
    }
  
  double H_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();

      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);

      const int Sp_out = outSDp_qn.get_S ();

      const int Sn_out = S - Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();

      const int n_spec_n_out = n_spec_max - n_spec_p_out;

      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;	  
		  
      const int n_spec_p_in = n_spec_p_out;
      const int n_spec_n_in = n_spec_n_out;

      const int iMn_out = iM - iMp_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();

      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index)) : (NADA);
                  
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(i_thread);      
      
      class array<class jumps_data_out_to_in_str> &one_jump_p_tab = one_jump_p_tabs_local(i_thread);
      
      class array<bool> &is_one_jump_p_calculated_tab = is_one_jump_p_calculated_tabs(i_thread);
      
      is_one_jump_p_calculated_tab = false;
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;
	      
	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out)) : (NADA);
		  
		  const unsigned long int total_outSDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_outSDn*outSDp_TRS_index) : (NADA);
		  		  
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDn_index;
		     			  
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
					      
			  const unsigned long int total_outSDn_TRS_indices_index = (is_it_TRS) ? (total_outSDn_TRS_indices_zero_index + outSDn_index) : (NADA);
			  
			  const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_outSDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + outSDn_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {
			      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
				{
				  const unsigned int BPn_in = binary_parity_product (BP , BPp_in);
	  	  
				  for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				    {
				      const int Sn_in = S - Sp_in;
				      
				      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
					{
					  const int iMn_in = iM - iMp_in;

					  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
					  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
					  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
					  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				      
					  class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in);

					  bool &is_one_jump_p_calculated = is_one_jump_p_calculated_tab(BPp_in , Sp_in , Delta_iMp_in);

					  if (!is_one_jump_p_calculated)
					    {
					      one_jump_p.one_jump_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , prot_Y_data);
				      
					      is_one_jump_p_calculated = true;
					    }
				
					  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				      
					  if (dimension_one_jump_p == 0) continue;
				      
					  one_jump_n.one_jump_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw , BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , neut_Y_data);
				      
					  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
				  
					  if (dimension_one_jump_n == 0) continue;

					  unsigned long int total_PSI_in_index_zero_inSDp = 0;
				      
					  unsigned int H_multiplications_number_sublocal = 0;
					      
					  bool is_configuration_accepted = true;
									  
					  TYPE component_part = 0.0;
				      
					  for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++) 
					    {
					      const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);
					  
					      const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
					  
					      const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();
					  
					      const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();

					      const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();
					  
					      const unsigned int n_in  = one_jump_n_inSDn.get_mu_in ();
					      const unsigned int n_out = one_jump_n_inSDn.get_mu_out ();

					      const class nljm_struct &phi_n_out = phi_n_table(n_out);
  
					      const unsigned int n_out_shell = phi_n_out.get_shell_index ();
					  
					      const unsigned int total_bin_phase_n = one_jump_n_inSDn.get_total_bin_phase ();

					      const int En_hw_in = one_jump_n_inSDn.get_E_hw ();

					      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
				      
					      for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
						{
						  const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);
					  
						  const bool is_configuration_changing = one_jump_p_inSDp.get_is_configuration_changing ();
		      
						  if (is_configuration_changing) 
						    { 
						      const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
						  
						      const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();

						      const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();

						      is_configuration_accepted = true;
									  
						      if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) is_configuration_accepted = false;
						  
						      if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) is_configuration_accepted = false;
	  
						      if (is_configuration_accepted) 
							{
							  const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();
							  
							  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
							  
							  total_PSI_in_index_zero_inSDp = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;
							}
						    }
					      
						  if (is_configuration_accepted)
						    {
						      const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

						      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDp + dimension_inSDn*inSDp_index;
						  
						      const unsigned int p_in  = one_jump_p_inSDp.get_mu_in ();
						      const unsigned int p_out = one_jump_p_inSDp.get_mu_out ();
						  
						      const unsigned int total_bin_phase_p = one_jump_p_inSDp.get_total_bin_phase ();
							  
						      const TYPE &PSI_in_component = PSI_in_full[total_PSI_in_index];
						      
						      if (are_M_TBMEs_stored)
							{
							  const unsigned int M_TBMEs_pn_index = M_TBMEs_pn_indices(p_in , n_in , p_out , n_out_shell);
						  
							  const TYPE TBME = M_TBMEs[M_TBMEs_pn_index];
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}
						      else
							{						  
							  const TYPE TBME = TBMEs_pn.M_TBME (false , p_in , n_in , p_out , n_out);							  
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}

						      H_multiplications_number_sublocal++;
						    }
						}
					    }
				      
					  PSI_out[PSI_out_index] += component_part;
				      
					  H_multiplications_number_local += H_multiplications_number_sublocal;
				      
					}}}}}}}}}}
  
  H_multiplications_number += H_multiplications_number_local;
}












void H_class::two_jumps_cv_part_pn_on_the_fly_two_jumps_stored_N_valence_larger_calc (
										      const bool is_it_cv_pp_to_nn ,
										      class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
 
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
  
  const int iMp_max = prot_Y_data.get_iM_max ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
 
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const bool are_M_TBMEs_stored = (M_TBMEs_storage != ON_THE_FLY);
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_out_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
    
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();
      
  const class TBMEs_class &TBMEs_cv = get_TBMEs_cv ();
  
  class GSM_vector &PSI_in_full = get_PSI_in_full ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
    
  double H_multiplications_number_local = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();
      
      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();
      
      const unsigned int BPp_out = binary_parity_product (BPn_out , BP);

      const int Sn_out = outSDn_qn.get_S ();

      const int Sp_out = S - Sn_out;
      
      const int n_spec_n_out = outSDn_qn.get_n_spec ();

      const int n_spec_p_out = n_spec_max - n_spec_n_out;

      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;
		  
      const int n_spec_p_in = (is_it_cv_pp_to_nn) ? (n_spec_p_out - 2) : (n_spec_p_out + 2);
      const int n_spec_n_in = (is_it_cv_pp_to_nn) ? (n_spec_n_out + 2) : (n_spec_n_out - 2);
		  
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const int iMp_out = iM - iMn_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);
      
      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index)) : (NADA);
        
      const unsigned long int total_outSDn_index_shifted = total_outSDn_index - total_outSDn_index_min;

      const class array<class jumps_data_out_to_in_str> &two_jumps_cv_n_tab = (is_it_cv_pp_to_nn) ? (two_jumps_cv_n_pp_to_nn_tabs(total_outSDn_index_shifted)) : (two_jumps_cv_n_nn_to_pp_tabs(total_outSDn_index_shifted));
			  
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
	      
	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
	      
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS)
		    ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out))
		    : (NADA);
				  
		  const unsigned long int total_outSDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);
		      
		  const unsigned long int total_outSDp_index_zero = SDp_set.index_determine (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , 0);
		  
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDp_index*dimension_outSDn;
      
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned long int total_outSDp_index = total_outSDp_index_zero + outSDp_index;

			  const unsigned long int total_outSDp_index_shifted = total_outSDp_index - total_outSDp_index_min;

			  const class array<class jumps_data_out_to_in_str> &two_jumps_cv_p_tab = (is_it_cv_pp_to_nn) ? (two_jumps_cv_p_pp_to_nn_tabs(total_outSDp_index_shifted)) : (two_jumps_cv_p_nn_to_pp_tabs(total_outSDp_index_shifted));
			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
						  
			  const unsigned long int total_outSDp_TRS_indices_index = (is_it_TRS) ? (total_outSDp_TRS_indices_zero_index + outSDp_index) : (NADA);
			  
			  const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_outSDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + dimension_outSDn*outSDp_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {			      
			      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
				{
				  const unsigned int BPn_in = binary_parity_product (BP , BPp_in);
	  
				  for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				    {
				      const int Sn_in = S - Sp_in;
				      
				      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
					{
					  const int iMn_in = iM - iMp_in;
				      
					  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
					  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
					  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
					  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				      
					  const class jumps_data_out_to_in_str &two_jumps_cv_n = two_jumps_cv_n_tab(BPn_in , Sn_in , Delta_iMn_in);
				
					  const unsigned int dimension_two_jumps_cv_n = two_jumps_cv_n.get_dimension ();
				      
					  if (dimension_two_jumps_cv_n == 0) continue;

					  const class jumps_data_out_to_in_str &two_jumps_cv_p = two_jumps_cv_p_tab(BPp_in , Sp_in , Delta_iMp_in);
				      
					  const unsigned int dimension_two_jumps_cv_p = two_jumps_cv_p.get_dimension ();
				      
					  if (dimension_two_jumps_cv_p == 0) continue;
		  				  
					  unsigned long int total_PSI_in_index_zero_inSDn = 0;
					      
					  bool is_configuration_accepted = true;
											      
					  unsigned int H_multiplications_number_sublocal = 0;
				      
					  TYPE component_part = 0.0;
				      
					  for (unsigned int ip = 0 ; ip < dimension_two_jumps_cv_p ; ip++)  
					    {
					      const class jumps_data_inSD_str &two_jumps_cv_p_inSDp = two_jumps_cv_p(ip);

					      const int n_holes_p_in = two_jumps_cv_p_inSDp.get_n_holes ();
					  
					      const int n_scat_p_in = two_jumps_cv_p_inSDp.get_n_scat ();

					      const unsigned int iCp_in = two_jumps_cv_p_inSDp.get_iC ();

					      const unsigned int inSDp_index = two_jumps_cv_p_inSDp.get_inSD_index ();
					  
					      const unsigned int p_in  = two_jumps_cv_p_inSDp.get_left_in ();
					      const unsigned int pp_in = two_jumps_cv_p_inSDp.get_right_in ();

					      const unsigned int  p_out = two_jumps_cv_p_inSDp.get_left_out ();
					      const unsigned int pp_out = two_jumps_cv_p_inSDp.get_right_out ();

					      const class nljm_struct &phi_p_in  = phi_p_table(p_in);
					      const class nljm_struct &phi_p_out = phi_p_table(p_out);
  
					      const unsigned int p_in_shell  = phi_p_in.get_shell_index ();
					      const unsigned int p_out_shell = phi_p_out.get_shell_index ();
					  
					      const unsigned int total_bin_phase_p = two_jumps_cv_p_inSDp.get_total_bin_phase ();
					  
					      const int Ep_hw_in = two_jumps_cv_p_inSDp.get_E_hw ();
					
					      for (unsigned int in = 0 ; in < dimension_two_jumps_cv_n ; in++)
						{
						  const class jumps_data_inSD_str &two_jumps_cv_n_inSDn = two_jumps_cv_n(in);

						  const bool is_configuration_changing = two_jumps_cv_n_inSDn.get_is_configuration_changing ();

						  if (is_configuration_changing) 
						    {
						      const int n_holes_n_in = two_jumps_cv_n_inSDn.get_n_holes ();
						  
						      const int n_scat_n_in = two_jumps_cv_n_inSDn.get_n_scat ();

						      const int En_hw_in = two_jumps_cv_n_inSDn.get_E_hw ();

						      is_configuration_accepted = true;
									  
						      if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) is_configuration_accepted = false;
						  
						      if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max)))    is_configuration_accepted = false;
									  
						      if (is_configuration_accepted) 
							{					  
							  const unsigned int iCn_in = two_jumps_cv_n_inSDn.get_iC ();

							  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
						      
							  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
			      			      
							  total_PSI_in_index_zero_inSDn = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*inSDp_index;
							}
						    }
					           
						  if (is_configuration_accepted)
						    {
						      const unsigned int inSDn_index = two_jumps_cv_n_inSDn.get_inSD_index ();

						      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDn + inSDn_index;

						      const unsigned int n_in  = two_jumps_cv_n_inSDn.get_left_in ();
						      const unsigned int nn_in = two_jumps_cv_n_inSDn.get_right_in ();

						      const unsigned int  n_out = two_jumps_cv_n_inSDn.get_left_out ();
						      const unsigned int nn_out = two_jumps_cv_n_inSDn.get_right_out ();

						      const unsigned int total_bin_phase_n = two_jumps_cv_n_inSDn.get_total_bin_phase ();

						      const TYPE &PSI_in_component = PSI_in_full[total_PSI_in_index];
						      
						      if (are_M_TBMEs_stored)
							{
							  const unsigned int M_TBMEs_cv_index = (is_it_cv_pp_to_nn) ? (M_TBMEs_cv_pp_to_nn_indices(p_in_shell , pp_in , n_out , nn_out)) : (M_TBMEs_cv_nn_to_pp_indices(n_in , nn_in , p_out_shell , pp_out));
						  
							  const TYPE TBME = M_TBMEs[M_TBMEs_cv_index];							  
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}
						      else
							{						  
							  const TYPE TBME = (is_it_cv_pp_to_nn) ? (TBMEs_cv.M_TBME (true , p_in , pp_in , n_out , nn_out)) : (TBMEs_cv.M_TBME (false , n_in , nn_in , p_out , pp_out));
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}

						      H_multiplications_number_sublocal++;
						    }
						}
					    }
							  
					  PSI_out[PSI_out_index] += component_part;
				  
					  H_multiplications_number_local += H_multiplications_number_sublocal;
				      
					}}}}}}}}}}
  
  H_multiplications_number += H_multiplications_number_local;
}








void H_class::two_jumps_cv_part_pn_on_the_fly_two_jumps_stored_Z_valence_larger_calc (
										      const bool is_it_cv_pp_to_nn ,
										      class GSM_vector &PSI_out) const
{  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
 
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const int iMp_max = prot_Y_data.get_iM_max ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
    
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
 
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
	  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  const bool are_M_TBMEs_stored = (M_TBMEs_storage != ON_THE_FLY);
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
 
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_out_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
    
  const class TBMEs_class &TBMEs_cv = get_TBMEs_cv ();
  
  class GSM_vector &PSI_in_full = get_PSI_in_full ();
  
  if (total_outSDp_index_min > total_outSDp_index_max) return;
  
  double H_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();

      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);

      const int Sp_out = outSDp_qn.get_S ();

      const int Sn_out = S - Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();

      const int n_spec_n_out = n_spec_max - n_spec_p_out;

      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;
		  
      const int n_spec_p_in = (is_it_cv_pp_to_nn) ? (n_spec_p_out - 2) : (n_spec_p_out + 2);
      const int n_spec_n_in = (is_it_cv_pp_to_nn) ? (n_spec_n_out + 2) : (n_spec_n_out - 2);

      const int iMn_out = iM - iMp_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();

      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index)) : (NADA);
                  
      const unsigned long int total_outSDp_index_shifted = total_outSDp_index - total_outSDp_index_min;
      
      const class array<class jumps_data_out_to_in_str> &two_jumps_cv_p_tab = (is_it_cv_pp_to_nn) ? (two_jumps_cv_p_pp_to_nn_tabs(total_outSDp_index_shifted)) : (two_jumps_cv_p_nn_to_pp_tabs(total_outSDp_index_shifted));
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;
	      
	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out)) : (NADA);
		  
		  const unsigned long int total_outSDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_outSDn*outSDp_TRS_index) : (NADA);
		  
		  const unsigned long int total_outSDn_index_zero = SDn_set.index_determine (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , 0);
		  
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDn_index;
		     			  
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned long int total_outSDn_index = total_outSDn_index_zero + outSDn_index;
			  
			  const unsigned long int total_outSDn_index_shifted = total_outSDn_index - total_outSDn_index_min;

			  const class array<class jumps_data_out_to_in_str> &two_jumps_cv_n_tab = (is_it_cv_pp_to_nn) ? (two_jumps_cv_n_pp_to_nn_tabs(total_outSDn_index_shifted)) : (two_jumps_cv_n_nn_to_pp_tabs(total_outSDn_index_shifted));
			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
					      
			  const unsigned long int total_outSDn_TRS_indices_index = (is_it_TRS) ? (total_outSDn_TRS_indices_zero_index + outSDn_index) : (NADA);
			  
			  const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_outSDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + outSDn_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {
			      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
				{
				  const unsigned int BPn_in = binary_parity_product (BP , BPp_in);
	  
				  for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				    {
				      const int Sn_in = S - Sp_in;
				      
				      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
					{
					  const int iMn_in = iM - iMp_in;
				      
					  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
					  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
					  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
					  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;

					  const class jumps_data_out_to_in_str &two_jumps_cv_p = two_jumps_cv_p_tab(BPp_in , Sp_in , Delta_iMp_in);
				
					  const unsigned int dimension_two_jumps_cv_p = two_jumps_cv_p.get_dimension ();
				      
					  if (dimension_two_jumps_cv_p == 0) continue;

					  const class jumps_data_out_to_in_str &two_jumps_cv_n = two_jumps_cv_n_tab(BPn_in , Sn_in , Delta_iMn_in);
				      
					  const unsigned int dimension_two_jumps_cv_n = two_jumps_cv_n.get_dimension ();
				  
					  if (dimension_two_jumps_cv_n == 0) continue;

					  unsigned long int total_PSI_in_index_zero_inSDp = 0;
				      
					  unsigned int H_multiplications_number_sublocal = 0;
					      
					  bool is_configuration_accepted = true;
									  
					  TYPE component_part = 0.0;
				      
					  for (unsigned int in = 0 ; in < dimension_two_jumps_cv_n ; in++) 
					    {
					      const class jumps_data_inSD_str &two_jumps_cv_n_inSDn = two_jumps_cv_n(in);
					  
					      const int n_holes_n_in = two_jumps_cv_n_inSDn.get_n_holes ();
					  
					      const int n_scat_n_in = two_jumps_cv_n_inSDn.get_n_scat ();
					  
					      const unsigned int iCn_in = two_jumps_cv_n_inSDn.get_iC ();
					  
					      const unsigned int inSDn_index = two_jumps_cv_n_inSDn.get_inSD_index ();
					  
					      const unsigned int n_in  = two_jumps_cv_n_inSDn.get_left_in ();
					      const unsigned int nn_in = two_jumps_cv_n_inSDn.get_right_in ();

					      const unsigned int  n_out = two_jumps_cv_n_inSDn.get_left_out ();
					      const unsigned int nn_out = two_jumps_cv_n_inSDn.get_right_out ();
					  
					      const class nljm_struct &phi_n_in  = phi_n_table(n_in);
					      const class nljm_struct &phi_n_out = phi_n_table(n_out);
  
					      const unsigned int n_in_shell  = phi_n_in.get_shell_index ();
					      const unsigned int n_out_shell = phi_n_out.get_shell_index ();
					  
					      const unsigned int total_bin_phase_n = two_jumps_cv_n_inSDn.get_total_bin_phase ();
					  
					      const int En_hw_in = two_jumps_cv_n_inSDn.get_E_hw ();
					  
					      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
				      
					      for (unsigned int ip = 0 ; ip < dimension_two_jumps_cv_p ; ip++)  
						{
						  const class jumps_data_inSD_str &two_jumps_cv_p_inSDp = two_jumps_cv_p(ip);
					  
						  const bool is_configuration_changing = two_jumps_cv_p_inSDp.get_is_configuration_changing ();
		      
						  if (is_configuration_changing) 
						    { 
						      const int n_holes_p_in = two_jumps_cv_p_inSDp.get_n_holes ();
						  
						      const int n_scat_p_in = two_jumps_cv_p_inSDp.get_n_scat ();
						  
						      const int Ep_hw_in = two_jumps_cv_p_inSDp.get_E_hw ();

						      is_configuration_accepted = true;
									  
						      if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) is_configuration_accepted = false;
						  
						      if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) is_configuration_accepted = false;
	  
						      if (is_configuration_accepted) 
							{
							  const unsigned int iCp_in = two_jumps_cv_p_inSDp.get_iC ();
							  
							  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
							  
							  total_PSI_in_index_zero_inSDp = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;
							}
						    }
					      
						  if (is_configuration_accepted)
						    {
						      const unsigned int inSDp_index = two_jumps_cv_p_inSDp.get_inSD_index ();

						      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDp + dimension_inSDn*inSDp_index;
						  
						      const unsigned int p_in  = two_jumps_cv_p_inSDp.get_left_in ();
						      const unsigned int pp_in = two_jumps_cv_p_inSDp.get_right_in ();

						      const unsigned int  p_out = two_jumps_cv_p_inSDp.get_left_out ();
						      const unsigned int pp_out = two_jumps_cv_p_inSDp.get_right_out ();
					  
						      const unsigned int total_bin_phase_p = two_jumps_cv_p_inSDp.get_total_bin_phase ();
							  
						      const TYPE &PSI_in_component = PSI_in_full[total_PSI_in_index];
						      
						      if (are_M_TBMEs_stored)
							{
							  const unsigned int M_TBMEs_cv_index = (is_it_cv_pp_to_nn) ? (M_TBMEs_cv_pp_to_nn_indices(p_in , pp_in , n_out_shell , nn_out)) : (M_TBMEs_cv_nn_to_pp_indices(n_in_shell , nn_in , p_out , pp_out));
						  
							  const TYPE TBME = M_TBMEs[M_TBMEs_cv_index];							  
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}
						      else
							{						  
							  const TYPE TBME = (is_it_cv_pp_to_nn) ? (TBMEs_cv.M_TBME (true , p_in , pp_in , n_out , nn_out)) : (TBMEs_cv.M_TBME (false , n_in , nn_in , p_out , pp_out));
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}

						      H_multiplications_number_sublocal++;
						    }
						}
					    }
				      
					  PSI_out[PSI_out_index] += component_part;
				      
					  H_multiplications_number_local += H_multiplications_number_sublocal;
				      
					}}}}}}}}}}
  
  H_multiplications_number += H_multiplications_number_local;
}














void H_class::two_jumps_cv_part_pn_on_the_fly_two_jumps_partially_stored_N_valence_larger_calc (
												const bool is_it_cv_pp_to_nn ,
												class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
 
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int S_plus_one = S + 1;

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
  
  const int iMp_max = prot_Y_data.get_iM_max ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();

  const int four_mn_max_plus_one = four_mn_max + 1;
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
 
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
    
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_out_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
    
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();
  
  const class TBMEs_class &TBMEs_cv = get_TBMEs_cv ();

  const bool are_M_TBMEs_stored = (M_TBMEs_storage != ON_THE_FLY);
    
  class GSM_vector &PSI_in_full = get_PSI_in_full ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
  
  class array<class array<class jumps_data_out_to_in_str> > two_jumps_cv_n_tabs_local(NUMBER_OF_THREADS);
  
  class array<class array<bool> > are_two_jumps_cv_n_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      class array<class jumps_data_out_to_in_str> &two_jumps_cv_n_tab = two_jumps_cv_n_tabs_local(i);
      
      two_jumps_cv_n_tab.allocate (2 , S_plus_one , four_mn_max_plus_one);
      
      for (unsigned int BPn_in = 0 ; BPn_in <= 1 ; BPn_in++)
	for (int Sn_in = 0 ; Sn_in <= S ; Sn_in++)
	  for (int Delta_iMn_in = 0 ; Delta_iMn_in <= four_mn_max ; Delta_iMn_in++)
	    two_jumps_cv_n_tab(BPn_in , Sn_in , Delta_iMn_in).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      are_two_jumps_cv_n_calculated_tabs(i).allocate (2 , S_plus_one , four_mn_max_plus_one);
    }
  
  double H_multiplications_number_local = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();
      
      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();
      
      const unsigned int BPp_out = binary_parity_product (BPn_out , BP);

      const int Sn_out = outSDn_qn.get_S ();
      
      const int Sp_out = S - Sn_out;
      
      const int n_spec_n_out = outSDn_qn.get_n_spec ();

      const int n_spec_p_out = n_spec_max - n_spec_n_out;

      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;
		  
      const int n_spec_p_in = (is_it_cv_pp_to_nn) ? (n_spec_p_out - 2) : (n_spec_p_out + 2);
      const int n_spec_n_in = (is_it_cv_pp_to_nn) ? (n_spec_n_out + 2) : (n_spec_n_out - 2);
		  
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const int iMp_out = iM - iMn_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);
      
      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index)) : (NADA);
  
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class array<bool> &are_two_jumps_cv_n_calculated_tab = are_two_jumps_cv_n_calculated_tabs(i_thread);

      class array<class jumps_data_out_to_in_str> &two_jumps_cv_n_tab = two_jumps_cv_n_tabs_local(i_thread);
        
      are_two_jumps_cv_n_calculated_tab = false;
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
	      
	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
	      
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS)
		    ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out))
		    : (NADA);
				  
		  const unsigned long int total_outSDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);
		      
		  const unsigned long int total_outSDp_index_zero = SDp_set.index_determine (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , 0);
		  
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDp_index*dimension_outSDn;
      
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned long int total_outSDp_index = total_outSDp_index_zero + outSDp_index;

			  const unsigned long int total_outSDp_index_shifted = total_outSDp_index - total_outSDp_index_min;

			  const class array<class jumps_data_out_to_in_str> &two_jumps_cv_p_tab = (is_it_cv_pp_to_nn) ? (two_jumps_cv_p_pp_to_nn_tabs(total_outSDp_index_shifted)) : (two_jumps_cv_p_nn_to_pp_tabs(total_outSDp_index_shifted));
			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
						  
			  const unsigned long int total_outSDp_TRS_indices_index = (is_it_TRS) ? (total_outSDp_TRS_indices_zero_index + outSDp_index) : (NADA);
			  
			  const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_outSDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + dimension_outSDn*outSDp_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {			      
			      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
				{
				  const unsigned int BPn_in = binary_parity_product (BP , BPp_in);
	  
				  for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				    {
				      const int Sn_in = S - Sp_in;
				      
				      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
					{
					  const int iMn_in = iM - iMp_in;
				      
					  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
					  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
					  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
					  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				      
					  class jumps_data_out_to_in_str &two_jumps_cv_n = two_jumps_cv_n_tab(BPn_in , Sn_in , Delta_iMn_in);
				      
					  bool &are_two_jumps_cv_n_calculated = are_two_jumps_cv_n_calculated_tab(BPn_in , Sn_in , Delta_iMn_in);

					  if (!are_two_jumps_cv_n_calculated)
					    {
					      two_jumps_cv_n.two_jumps_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw ,
										 BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , is_it_cv_pp_to_nn , !is_it_cv_pp_to_nn , neut_Y_data);
				      
					      are_two_jumps_cv_n_calculated = true;
					    }
				
					  const unsigned int dimension_two_jumps_cv_n = two_jumps_cv_n.get_dimension ();
				      
					  if (dimension_two_jumps_cv_n == 0) continue;

					  const class jumps_data_out_to_in_str &two_jumps_cv_p = two_jumps_cv_p_tab(BPp_in , Sp_in , Delta_iMp_in);
				      
					  const unsigned int dimension_two_jumps_cv_p = two_jumps_cv_p.get_dimension ();
				      
					  if (dimension_two_jumps_cv_p == 0) continue;
		  				  
					  unsigned long int total_PSI_in_index_zero_inSDn = 0;
					      
					  bool is_configuration_accepted = true;
											      
					  unsigned int H_multiplications_number_sublocal = 0;
				      
					  TYPE component_part = 0.0;
				      
					  for (unsigned int ip = 0 ; ip < dimension_two_jumps_cv_p ; ip++)  
					    {
					      const class jumps_data_inSD_str &two_jumps_cv_p_inSDp = two_jumps_cv_p(ip);

					      const int n_holes_p_in = two_jumps_cv_p_inSDp.get_n_holes ();
					  
					      const int n_scat_p_in = two_jumps_cv_p_inSDp.get_n_scat ();

					      const unsigned int iCp_in = two_jumps_cv_p_inSDp.get_iC ();

					      const unsigned int inSDp_index = two_jumps_cv_p_inSDp.get_inSD_index ();
					  
					      const unsigned int p_in  = two_jumps_cv_p_inSDp.get_left_in ();
					      const unsigned int pp_in = two_jumps_cv_p_inSDp.get_right_in ();

					      const unsigned int  p_out = two_jumps_cv_p_inSDp.get_left_out ();
					      const unsigned int pp_out = two_jumps_cv_p_inSDp.get_right_out ();

					      const class nljm_struct &phi_p_in  = phi_p_table(p_in);
					      const class nljm_struct &phi_p_out = phi_p_table(p_out);
  
					      const unsigned int p_in_shell  = phi_p_in.get_shell_index ();
					      const unsigned int p_out_shell = phi_p_out.get_shell_index ();
					  
					      const unsigned int total_bin_phase_p = two_jumps_cv_p_inSDp.get_total_bin_phase ();
					  
					      const int Ep_hw_in = two_jumps_cv_p_inSDp.get_E_hw ();
					
					      for (unsigned int in = 0 ; in < dimension_two_jumps_cv_n ; in++)
						{
						  const class jumps_data_inSD_str &two_jumps_cv_n_inSDn = two_jumps_cv_n(in);

						  const bool is_configuration_changing = two_jumps_cv_n_inSDn.get_is_configuration_changing ();

						  if (is_configuration_changing) 
						    {
						      const int n_holes_n_in = two_jumps_cv_n_inSDn.get_n_holes ();
						  
						      const int n_scat_n_in = two_jumps_cv_n_inSDn.get_n_scat ();

						      const int En_hw_in = two_jumps_cv_n_inSDn.get_E_hw ();

						      is_configuration_accepted = true;
									  
						      if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) is_configuration_accepted = false;
						  
						      if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max)))    is_configuration_accepted = false;
									  
						      if (is_configuration_accepted) 
							{					  
							  const unsigned int iCn_in = two_jumps_cv_n_inSDn.get_iC ();

							  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
						      
							  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
			      			      
							  total_PSI_in_index_zero_inSDn = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*inSDp_index;
							}
						    }
					           
						  if (is_configuration_accepted)
						    {
						      const unsigned int inSDn_index = two_jumps_cv_n_inSDn.get_inSD_index ();

						      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDn + inSDn_index;

						      const unsigned int n_in  = two_jumps_cv_n_inSDn.get_left_in ();
						      const unsigned int nn_in = two_jumps_cv_n_inSDn.get_right_in ();

						      const unsigned int  n_out = two_jumps_cv_n_inSDn.get_left_out ();
						      const unsigned int nn_out = two_jumps_cv_n_inSDn.get_right_out ();
					      
						      const unsigned int total_bin_phase_n = two_jumps_cv_n_inSDn.get_total_bin_phase ();
						      
						      const TYPE &PSI_in_component = PSI_in_full[total_PSI_in_index];
						      
						      if (are_M_TBMEs_stored)
							{
							  const unsigned int M_TBMEs_cv_index = (is_it_cv_pp_to_nn) ? (M_TBMEs_cv_pp_to_nn_indices(p_in_shell , pp_in , n_out , nn_out)) : (M_TBMEs_cv_nn_to_pp_indices(n_in , nn_in , p_out_shell , pp_out));
						  
							  const TYPE TBME = M_TBMEs[M_TBMEs_cv_index];							  
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}
						      else
							{						  
							  const TYPE TBME = (is_it_cv_pp_to_nn) ? (TBMEs_cv.M_TBME (true , p_in , pp_in , n_out , nn_out)) : (TBMEs_cv.M_TBME (false , n_in , nn_in , p_out , pp_out));
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}

						      H_multiplications_number_sublocal++;
						    }
						}
					    }
							  
					  PSI_out[PSI_out_index] += component_part;
				  
					  H_multiplications_number_local += H_multiplications_number_sublocal;
				      
					}}}}}}}}}}
  
  H_multiplications_number += H_multiplications_number_local;
}








void H_class::two_jumps_cv_part_pn_on_the_fly_two_jumps_partially_stored_Z_valence_larger_calc (
												const bool is_it_cv_pp_to_nn ,
												class GSM_vector &PSI_out) const
{  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
 
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int S_plus_one = S + 1;
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const int iMp_max = prot_Y_data.get_iM_max ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int four_mp_max_plus_one = four_mp_max + 1;
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();

  const unsigned int ZYval = prot_Y_data.get_N_valence_baryons ();
      
  const unsigned int ZY_valence_pairs_number = (ZYval*(ZYval - 1))/2;
  
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
   
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
	  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
 
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_out_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();

  const class TBMEs_class &TBMEs_cv = get_TBMEs_cv ();

  const bool are_M_TBMEs_stored = (M_TBMEs_storage != ON_THE_FLY);
    
  class GSM_vector &PSI_in_full = get_PSI_in_full ();
  
  if (total_outSDp_index_min > total_outSDp_index_max) return;
  
  class array<class array<class jumps_data_out_to_in_str> > two_jumps_cv_p_tabs_local(NUMBER_OF_THREADS);
  
  class array<class array<bool> > are_two_jumps_cv_p_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      class array<class jumps_data_out_to_in_str> &two_jumps_cv_p_tab = two_jumps_cv_p_tabs_local(i);
      
      two_jumps_cv_p_tab.allocate (2 , S_plus_one , four_mp_max_plus_one);
      
      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
	for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
	    for (int Delta_iMp_in = 0 ; Delta_iMp_in <= four_mp_max ; Delta_iMp_in++)
	      two_jumps_cv_p_tab(BPp_in , Sp_in , Delta_iMp_in).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , ZY_valence_pairs_number);
      
      are_two_jumps_cv_p_calculated_tabs(i).allocate (2 , S_plus_one , four_mp_max_plus_one);
    }
  
  double H_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();

      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);

      const int Sp_out = outSDp_qn.get_S ();

      const int Sn_out = S - Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();

      const int n_spec_n_out = n_spec_max - n_spec_p_out;

      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;
		  
      const int n_spec_p_in = (is_it_cv_pp_to_nn) ? (n_spec_p_out - 2) : (n_spec_p_out + 2);
      const int n_spec_n_in = (is_it_cv_pp_to_nn) ? (n_spec_n_out + 2) : (n_spec_n_out - 2);

      const int iMn_out = iM - iMp_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();

      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index)) : (NADA);
                  
      const unsigned int i_thread = OpenMP_thread_number_determine ();
            
      class array<bool> &are_two_jumps_cv_p_calculated_tab = are_two_jumps_cv_p_calculated_tabs(i_thread);

      class array<class jumps_data_out_to_in_str> &two_jumps_cv_p_tab = two_jumps_cv_p_tabs_local(i_thread);
                  
      are_two_jumps_cv_p_calculated_tab = false;
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;
	      
	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out)) : (NADA);
		  
		  const unsigned long int total_outSDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_outSDn*outSDp_TRS_index) : (NADA);
		  
		  const unsigned long int total_outSDn_index_zero = SDn_set.index_determine (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , 0);
		  
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDn_index;
		     			  
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned long int total_outSDn_index = total_outSDn_index_zero + outSDn_index;
			  const unsigned long int total_outSDn_index_shifted = total_outSDn_index - total_outSDn_index_min;

			  const class array<class jumps_data_out_to_in_str> &two_jumps_cv_n_tab = (is_it_cv_pp_to_nn) ? (two_jumps_cv_n_pp_to_nn_tabs(total_outSDn_index_shifted)) : (two_jumps_cv_n_nn_to_pp_tabs(total_outSDn_index_shifted));
			  
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
					      
			  const unsigned long int total_outSDn_TRS_indices_index = (is_it_TRS) ? (total_outSDn_TRS_indices_zero_index + outSDn_index) : (NADA);
			  const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_outSDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + outSDn_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {
			      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
				{
				  const unsigned int BPn_in = binary_parity_product (BP , BPp_in);
	  
				  for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				    {
				      const int Sn_in = S - Sp_in;
				      
				      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
					{
					  const int iMn_in = iM - iMp_in;
				      
					  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
					  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
					  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
					  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;

					  class jumps_data_out_to_in_str &two_jumps_cv_p = two_jumps_cv_p_tab(BPp_in , Sp_in , Delta_iMp_in);

					  bool &are_two_jumps_cv_p_calculated = are_two_jumps_cv_p_calculated_tab(BPp_in , Sp_in , Delta_iMp_in);

					  if (!are_two_jumps_cv_p_calculated)
					    {
					      two_jumps_cv_p.two_jumps_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw ,
										 BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , !is_it_cv_pp_to_nn , is_it_cv_pp_to_nn , prot_Y_data);
					      				      
					      are_two_jumps_cv_p_calculated = true;
					    }
				
					  const unsigned int dimension_two_jumps_cv_p = two_jumps_cv_p.get_dimension ();
				      
					  if (dimension_two_jumps_cv_p == 0) continue;

					  const class jumps_data_out_to_in_str &two_jumps_cv_n = two_jumps_cv_n_tab(BPn_in , Sn_in , Delta_iMn_in);
				      
					  const unsigned int dimension_two_jumps_cv_n = two_jumps_cv_n.get_dimension ();
				  
					  if (dimension_two_jumps_cv_n == 0) continue;

					  unsigned long int total_PSI_in_index_zero_inSDp = 0;
				      
					  unsigned int H_multiplications_number_sublocal = 0;
					      
					  bool is_configuration_accepted = true;
									  
					  TYPE component_part = 0.0;
				      
					  for (unsigned int in = 0 ; in < dimension_two_jumps_cv_n ; in++) 
					    {
					      const class jumps_data_inSD_str &two_jumps_cv_n_inSDn = two_jumps_cv_n(in);
					  
					      const int n_holes_n_in = two_jumps_cv_n_inSDn.get_n_holes ();
					  
					      const int n_scat_n_in = two_jumps_cv_n_inSDn.get_n_scat ();
					  
					      const unsigned int iCn_in = two_jumps_cv_n_inSDn.get_iC ();
					  
					      const unsigned int inSDn_index = two_jumps_cv_n_inSDn.get_inSD_index ();
					  
					      const unsigned int n_in  = two_jumps_cv_n_inSDn.get_left_in ();
					      const unsigned int nn_in = two_jumps_cv_n_inSDn.get_right_in ();

					      const unsigned int  n_out = two_jumps_cv_n_inSDn.get_left_out ();
					      const unsigned int nn_out = two_jumps_cv_n_inSDn.get_right_out ();
					  
					      const class nljm_struct &phi_n_in  = phi_n_table(n_in);
					      const class nljm_struct &phi_n_out = phi_n_table(n_out);
  
					      const unsigned int n_in_shell  = phi_n_in.get_shell_index ();
					      const unsigned int n_out_shell = phi_n_out.get_shell_index ();
					  
					      const unsigned int total_bin_phase_n = two_jumps_cv_n_inSDn.get_total_bin_phase ();
					  
					      const int En_hw_in = two_jumps_cv_n_inSDn.get_E_hw ();
					  
					      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
				      
					      for (unsigned int ip = 0 ; ip < dimension_two_jumps_cv_p ; ip++)  
						{
						  const class jumps_data_inSD_str &two_jumps_cv_p_inSDp = two_jumps_cv_p(ip);
					  
						  const bool is_configuration_changing = two_jumps_cv_p_inSDp.get_is_configuration_changing ();
		      
						  if (is_configuration_changing) 
						    { 
						      const int n_holes_p_in = two_jumps_cv_p_inSDp.get_n_holes ();
						  
						      const int n_scat_p_in = two_jumps_cv_p_inSDp.get_n_scat ();
						  
						      const int Ep_hw_in = two_jumps_cv_p_inSDp.get_E_hw ();

						      is_configuration_accepted = true;
									  
						      if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) is_configuration_accepted = false;
						  
						      if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) is_configuration_accepted = false;
	  
						      if (is_configuration_accepted) 
							{
							  const unsigned int iCp_in = two_jumps_cv_p_inSDp.get_iC ();
							  
							  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
							  
							  total_PSI_in_index_zero_inSDp = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;
							}
						    }
					      
						  if (is_configuration_accepted)
						    {
						      const unsigned int inSDp_index = two_jumps_cv_p_inSDp.get_inSD_index ();

						      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDp + dimension_inSDn*inSDp_index;
						  
						      const unsigned int p_in  = two_jumps_cv_p_inSDp.get_left_in ();
						      const unsigned int pp_in = two_jumps_cv_p_inSDp.get_right_in ();

						      const unsigned int  p_out = two_jumps_cv_p_inSDp.get_left_out ();
						      const unsigned int pp_out = two_jumps_cv_p_inSDp.get_right_out ();

						      const unsigned int total_bin_phase_p = two_jumps_cv_p_inSDp.get_total_bin_phase ();
							  
						      const TYPE &PSI_in_component = PSI_in_full[total_PSI_in_index];

						      if (are_M_TBMEs_stored)
							{
							  const unsigned int M_TBMEs_cv_index = (is_it_cv_pp_to_nn) ? (M_TBMEs_cv_pp_to_nn_indices(p_in , pp_in , n_out_shell , nn_out)) : (M_TBMEs_cv_nn_to_pp_indices(n_in_shell , nn_in , p_out , pp_out));
						  
							  const TYPE TBME = M_TBMEs[M_TBMEs_cv_index];							  
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}
						      else
							{						  
							  const TYPE TBME = (is_it_cv_pp_to_nn) ? (TBMEs_cv.M_TBME (true , p_in , pp_in , n_out , nn_out)) : (TBMEs_cv.M_TBME (false , n_in , nn_in , p_out , pp_out));
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}						      

						      H_multiplications_number_sublocal++;
						    }
						}
					    }
				      
					  PSI_out[PSI_out_index] += component_part;
				      
					  H_multiplications_number_local += H_multiplications_number_sublocal;
				      
					}}}}}}}}}}
  
  H_multiplications_number += H_multiplications_number_local;
}











void H_class::two_jumps_cv_part_pn_on_the_fly_two_jumps_recalculated_N_valence_larger_calc (
											    const bool is_it_cv_pp_to_nn ,
											    class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
 
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int S_plus_one = S + 1;

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
  
  const int iMp_max = prot_Y_data.get_iM_max ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int four_mn_max_plus_one = four_mn_max + 1;
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();

  const unsigned int ZYval = prot_Y_data.get_N_valence_baryons ();
  const unsigned int NYval = neut_Y_data.get_N_valence_baryons ();
      
  const unsigned int ZY_valence_pairs_number = (ZYval*(ZYval - 1))/2;
  const unsigned int NY_valence_pairs_number = (NYval*(NYval - 1))/2;

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
    
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_out_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
    
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();
  
  const class TBMEs_class &TBMEs_cv = get_TBMEs_cv ();

  const bool are_M_TBMEs_stored = (M_TBMEs_storage != ON_THE_FLY);
    
  class GSM_vector &PSI_in_full = get_PSI_in_full ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
  
  class array<class jumps_data_out_to_in_str> two_jumps_cv_p_tab(NUMBER_OF_THREADS);
  
  class array<class array<class jumps_data_out_to_in_str> > two_jumps_cv_n_tabs_local(NUMBER_OF_THREADS);
  
  class array<class array<bool> > are_two_jumps_cv_n_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      two_jumps_cv_p_tab(i).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , ZY_valence_pairs_number);
      
      class array<class jumps_data_out_to_in_str> &two_jumps_cv_n_tab = two_jumps_cv_n_tabs_local(i);
      
      two_jumps_cv_n_tab.allocate (2 , S_plus_one , four_mn_max_plus_one);
      
      for (unsigned int BPn_in = 0 ; BPn_in <= 1 ; BPn_in++)
	for (int Sn_in = 0 ; Sn_in <= S ; Sn_in++)
	  for (int Delta_iMn_in = 0 ; Delta_iMn_in <= four_mn_max ; Delta_iMn_in++)
	    two_jumps_cv_n_tab(BPn_in , Sn_in , Delta_iMn_in).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , NY_valence_pairs_number);
      
      are_two_jumps_cv_n_calculated_tabs(i).allocate (2 , S_plus_one , four_mn_max_plus_one);
    }
  
  double H_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();

      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();

      const unsigned int BPp_out = binary_parity_product (BPn_out , BP);

      const int Sn_out = outSDn_qn.get_S ();

      const int Sp_out = S - Sn_out;
      
      const int n_spec_n_out = outSDn_qn.get_n_spec ();

      const int n_spec_p_out = n_spec_max - n_spec_n_out;

      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;	 
		  
      const int n_spec_p_in = (is_it_cv_pp_to_nn) ? (n_spec_p_out - 2) : (n_spec_p_out + 2);
      const int n_spec_n_in = (is_it_cv_pp_to_nn) ? (n_spec_n_out + 2) : (n_spec_n_out - 2);
		  
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const int iMp_out = iM - iMn_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);
      
      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index)) : (NADA);
  
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class jumps_data_out_to_in_str &two_jumps_cv_p = two_jumps_cv_p_tab(i_thread);      
      
      class array<class jumps_data_out_to_in_str> &two_jumps_cv_n_tab = two_jumps_cv_n_tabs_local(i_thread);
      
      class array<bool> &are_two_jumps_cv_n_calculated_tab = are_two_jumps_cv_n_calculated_tabs(i_thread);
      
      are_two_jumps_cv_n_calculated_tab = false;
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
	      
	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
	      
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out)) : (NADA);
				  
		  const unsigned long int total_outSDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);
		      
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDp_index*dimension_outSDn;
      
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  const unsigned long int total_outSDp_TRS_indices_index = (is_it_TRS) ? (total_outSDp_TRS_indices_zero_index + outSDp_index) : (NADA);
			  const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_outSDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + dimension_outSDn*outSDp_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {			      
			      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
				{
				  const unsigned int BPn_in = binary_parity_product (BP , BPp_in);
	  
				  for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				    {
				      const int Sn_in = S - Sp_in;
				      
				      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
					{
					  const int iMn_in = iM - iMp_in;
				      
					  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
					  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
					  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
					  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;

					  class jumps_data_out_to_in_str &two_jumps_cv_n = two_jumps_cv_n_tab(BPn_in , Sn_in , Delta_iMn_in);

					  bool &are_two_jumps_cv_n_calculated = are_two_jumps_cv_n_calculated_tab(BPn_in , Sn_in , Delta_iMn_in);

					  if (!are_two_jumps_cv_n_calculated)
					    {
					      two_jumps_cv_n.two_jumps_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw ,
										 BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , is_it_cv_pp_to_nn , !is_it_cv_pp_to_nn , neut_Y_data);
				      
					      are_two_jumps_cv_n_calculated = true;
					    }
				
					  const unsigned int dimension_two_jumps_cv_n = two_jumps_cv_n.get_dimension ();
				      
					  if (dimension_two_jumps_cv_n == 0) continue;
				      
					  two_jumps_cv_p.two_jumps_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw ,
									     BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , !is_it_cv_pp_to_nn , is_it_cv_pp_to_nn , prot_Y_data);

					  const unsigned int dimension_two_jumps_cv_p = two_jumps_cv_p.get_dimension ();
				  				    
					  if (dimension_two_jumps_cv_p == 0) continue;
		  				  
					  unsigned long int total_PSI_in_index_zero_inSDn = 0;
					      
					  bool is_configuration_accepted = true;
											      
					  unsigned int H_multiplications_number_sublocal = 0;
				      
					  TYPE component_part = 0.0;
				      
					  for (unsigned int ip = 0 ; ip < dimension_two_jumps_cv_p ; ip++)  
					    {
					      const class jumps_data_inSD_str &two_jumps_cv_p_inSDp = two_jumps_cv_p(ip);

					      const int n_holes_p_in = two_jumps_cv_p_inSDp.get_n_holes ();
					  
					      const int n_scat_p_in = two_jumps_cv_p_inSDp.get_n_scat ();

					      const unsigned int iCp_in = two_jumps_cv_p_inSDp.get_iC ();

					      const unsigned int inSDp_index = two_jumps_cv_p_inSDp.get_inSD_index ();
					  
					      const unsigned int p_in  = two_jumps_cv_p_inSDp.get_left_in ();
					      const unsigned int pp_in = two_jumps_cv_p_inSDp.get_right_in ();

					      const unsigned int  p_out = two_jumps_cv_p_inSDp.get_left_out ();
					      const unsigned int pp_out = two_jumps_cv_p_inSDp.get_right_out ();
					  
					      const class nljm_struct &phi_p_in  = phi_p_table(p_in);
					      const class nljm_struct &phi_p_out = phi_p_table(p_out);
  
					      const unsigned int p_in_shell  = phi_p_in.get_shell_index ();
					      const unsigned int p_out_shell = phi_p_out.get_shell_index ();
					  
					      const unsigned int total_bin_phase_p = two_jumps_cv_p_inSDp.get_total_bin_phase ();
					  
					      const int Ep_hw_in = two_jumps_cv_p_inSDp.get_E_hw ();
					  
					      for (unsigned int in = 0 ; in < dimension_two_jumps_cv_n ; in++)
						{
						  const class jumps_data_inSD_str &two_jumps_cv_n_inSDn = two_jumps_cv_n(in);
					      
						  const bool is_configuration_changing = two_jumps_cv_n_inSDn.get_is_configuration_changing ();
		      
						  if (is_configuration_changing) 
						    { 
						      const int n_holes_n_in = two_jumps_cv_n_inSDn.get_n_holes ();
						  
						      const int n_scat_n_in = two_jumps_cv_n_inSDn.get_n_scat ();

						      const int En_hw_in = two_jumps_cv_n_inSDn.get_E_hw ();

						      is_configuration_accepted = true;
									  
						      if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) is_configuration_accepted = false;
						  
						      if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) is_configuration_accepted = false;
									  
						      if (is_configuration_accepted) 
							{					  
							  const unsigned int iCn_in = two_jumps_cv_n_inSDn.get_iC ();
						      
							  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
			      
							  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
			      			      
							  total_PSI_in_index_zero_inSDn = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*inSDp_index;
							}
						    }
					           
						  if (is_configuration_accepted)
						    {
						      const unsigned int inSDn_index = two_jumps_cv_n_inSDn.get_inSD_index ();

						      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDn + inSDn_index;

						      const unsigned int n_in  = two_jumps_cv_n_inSDn.get_left_in ();
						      const unsigned int nn_in = two_jumps_cv_n_inSDn.get_right_in ();

						      const unsigned int  n_out = two_jumps_cv_n_inSDn.get_left_out ();
						      const unsigned int nn_out = two_jumps_cv_n_inSDn.get_right_out ();
						      
						      const unsigned int total_bin_phase_n = two_jumps_cv_n_inSDn.get_total_bin_phase ();

						      const TYPE &PSI_in_component = PSI_in_full[total_PSI_in_index];
						      
						      if (are_M_TBMEs_stored)
							{
							  const unsigned int M_TBMEs_cv_index = (is_it_cv_pp_to_nn) ? (M_TBMEs_cv_pp_to_nn_indices(p_in_shell , pp_in , n_out , nn_out)) : (M_TBMEs_cv_nn_to_pp_indices(n_in , nn_in , p_out_shell , pp_out));
						  
							  const TYPE TBME = M_TBMEs[M_TBMEs_cv_index];							  
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}
						      else
							{						  
							  const TYPE TBME = (is_it_cv_pp_to_nn) ? (TBMEs_cv.M_TBME (true , p_in , pp_in , n_out , nn_out)) : (TBMEs_cv.M_TBME (false , n_in , nn_in , p_out , pp_out));
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}

						      H_multiplications_number_sublocal++;
						    }
						}
					    }
							  
					  PSI_out[PSI_out_index] += component_part;
				  
					  H_multiplications_number_local += H_multiplications_number_sublocal;
				      
					}}}}}}}}}}
  
  H_multiplications_number += H_multiplications_number_local;
}








void H_class::two_jumps_cv_part_pn_on_the_fly_two_jumps_recalculated_Z_valence_larger_calc (
											    const bool is_it_cv_pp_to_nn ,
											    class GSM_vector &PSI_out) const
{  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
 
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int S_plus_one = S + 1;
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const int iMp_max = prot_Y_data.get_iM_max ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
    
  const int four_mp_max_plus_one = four_mp_max + 1;
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();

  const unsigned int ZYval = prot_Y_data.get_N_valence_baryons ();
  const unsigned int NYval = neut_Y_data.get_N_valence_baryons ();
      
  const unsigned int ZY_valence_pairs_number = (ZYval*(ZYval - 1))/2;
  const unsigned int NY_valence_pairs_number = (NYval*(NYval - 1))/2;

  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
 
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_out_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  const class TBMEs_class &TBMEs_cv = get_TBMEs_cv ();

  const bool are_M_TBMEs_stored = (M_TBMEs_storage != ON_THE_FLY);
    
  class GSM_vector &PSI_in_full = get_PSI_in_full ();
  
  if (total_outSDp_index_min > total_outSDp_index_max) return;
  
  class array<class jumps_data_out_to_in_str> two_jumps_cv_n_tab(NUMBER_OF_THREADS);
  
  class array<class array<class jumps_data_out_to_in_str> > two_jumps_cv_p_tabs_local(NUMBER_OF_THREADS);
  
  class array<class array<bool> > are_two_jumps_cv_p_calculated_tabs(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      two_jumps_cv_n_tab(i).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , NY_valence_pairs_number);
      
      class array<class jumps_data_out_to_in_str> &two_jumps_cv_p_tab = two_jumps_cv_p_tabs_local(i);
      
      two_jumps_cv_p_tab.allocate (2 , S_plus_one , four_mp_max_plus_one);
      
      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
	for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
	  for (int Delta_iMp_in = 0 ; Delta_iMp_in <= four_mp_max ; Delta_iMp_in++)
	    two_jumps_cv_p_tab(BPp_in , Sp_in , Delta_iMp_in).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , ZY_valence_pairs_number);
      
      are_two_jumps_cv_p_calculated_tabs(i).allocate (2 , S_plus_one , four_mp_max_plus_one);
    }
  
  double H_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();

      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);

      const int Sp_out = outSDp_qn.get_S ();

      const int Sn_out = S - Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();

      const int n_spec_n_out = n_spec_max - n_spec_p_out;

      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;	 
		  
      const int n_spec_p_in = (is_it_cv_pp_to_nn) ? (n_spec_p_out - 2) : (n_spec_p_out + 2);
      const int n_spec_n_in = (is_it_cv_pp_to_nn) ? (n_spec_n_out + 2) : (n_spec_n_out - 2);

      const int iMn_out = iM - iMp_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();

      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index)) : (NADA);
                  
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class jumps_data_out_to_in_str &two_jumps_cv_n = two_jumps_cv_n_tab(i_thread);      
      
      class array<class jumps_data_out_to_in_str> &two_jumps_cv_p_tab = two_jumps_cv_p_tabs_local(i_thread);
      
      class array<bool> &are_two_jumps_cv_p_calculated_tab = are_two_jumps_cv_p_calculated_tabs(i_thread);
      
      are_two_jumps_cv_p_calculated_tab = false;
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;
	      
	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out)) : (NADA);
		  
		  const unsigned long int total_outSDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_outSDn*outSDp_TRS_index) : (NADA);
		  		  
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDn_index;
		     			  
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
					      
			  const unsigned long int total_outSDn_TRS_indices_index = (is_it_TRS) ? (total_outSDn_TRS_indices_zero_index + outSDn_index) : (NADA);
			  
			  const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_outSDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + outSDn_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {
			      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
				{
				  const unsigned int BPn_in = binary_parity_product (BP , BPp_in);
	  
				  for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				    {
				      const int Sn_in = S - Sp_in;
				      
				      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
					{
					  const int iMn_in = iM - iMp_in;

					  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
					  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
	      
					  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
					  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
				      
					  class jumps_data_out_to_in_str &two_jumps_cv_p = two_jumps_cv_p_tab(BPp_in , Sp_in , Delta_iMp_in);

					  bool &are_two_jumps_cv_p_calculated = are_two_jumps_cv_p_calculated_tab(BPp_in , Sp_in , Delta_iMp_in);

					  if (!are_two_jumps_cv_p_calculated)
					    {
					      two_jumps_cv_p.two_jumps_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw ,
										 BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , !is_it_cv_pp_to_nn , is_it_cv_pp_to_nn , prot_Y_data);
				      
					      are_two_jumps_cv_p_calculated = true;
					    }
				
					  const unsigned int dimension_two_jumps_cv_p = two_jumps_cv_p.get_dimension ();
				      
					  if (dimension_two_jumps_cv_p == 0) continue;
				      
					  two_jumps_cv_n.two_jumps_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw ,
									     BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , is_it_cv_pp_to_nn , !is_it_cv_pp_to_nn , neut_Y_data);
				      
					  const unsigned int dimension_two_jumps_cv_n = two_jumps_cv_n.get_dimension ();
				  
					  if (dimension_two_jumps_cv_n == 0) continue;

					  unsigned long int total_PSI_in_index_zero_inSDp = 0;
				      
					  unsigned int H_multiplications_number_sublocal = 0;
					      
					  bool is_configuration_accepted = true;
									  
					  TYPE component_part = 0.0;
				      
					  for (unsigned int in = 0 ; in < dimension_two_jumps_cv_n ; in++) 
					    {
					      const class jumps_data_inSD_str &two_jumps_cv_n_inSDn = two_jumps_cv_n(in);
					  
					      const int n_holes_n_in = two_jumps_cv_n_inSDn.get_n_holes ();
					  
					      const int n_scat_n_in = two_jumps_cv_n_inSDn.get_n_scat ();
					  
					      const unsigned int iCn_in = two_jumps_cv_n_inSDn.get_iC ();

					      const unsigned int inSDn_index = two_jumps_cv_n_inSDn.get_inSD_index ();
					  
					      const unsigned int n_in  = two_jumps_cv_n_inSDn.get_left_in ();
					      const unsigned int nn_in = two_jumps_cv_n_inSDn.get_right_in ();

					      const unsigned int  n_out = two_jumps_cv_n_inSDn.get_left_out ();
					      const unsigned int nn_out = two_jumps_cv_n_inSDn.get_right_out ();
					  
					      const class nljm_struct &phi_n_in  = phi_n_table(n_in);
					      const class nljm_struct &phi_n_out = phi_n_table(n_out);
  
					      const unsigned int n_in_shell  = phi_n_in.get_shell_index ();
					      const unsigned int n_out_shell = phi_n_out.get_shell_index ();
					  
					      const unsigned int total_bin_phase_n = two_jumps_cv_n_inSDn.get_total_bin_phase ();

					      const int En_hw_in = two_jumps_cv_n_inSDn.get_E_hw ();

					      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
				      
					      for (unsigned int ip = 0 ; ip < dimension_two_jumps_cv_p ; ip++)  
						{
						  const class jumps_data_inSD_str &two_jumps_cv_p_inSDp = two_jumps_cv_p(ip);
					  
						  const bool is_configuration_changing = two_jumps_cv_p_inSDp.get_is_configuration_changing ();
		      
						  if (is_configuration_changing) 
						    { 
						      const int n_holes_p_in = two_jumps_cv_p_inSDp.get_n_holes ();
						  
						      const int n_scat_p_in = two_jumps_cv_p_inSDp.get_n_scat ();

						      const int Ep_hw_in = two_jumps_cv_p_inSDp.get_E_hw ();

						      is_configuration_accepted = true;
									  
						      if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw)) is_configuration_accepted = false;
						  
						      if (truncation_ph && ((n_holes_p_in + n_holes_n_in > n_holes_max) || (n_scat_p_in + n_scat_n_in > n_scat_max))) is_configuration_accepted = false;
	  
						      if (is_configuration_accepted) 
							{
							  const unsigned int iCp_in = two_jumps_cv_p_inSDp.get_iC ();
							  
							  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
							  
							  total_PSI_in_index_zero_inSDp = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;
							}
						    }
					      
						  if (is_configuration_accepted)
						    {
						      const unsigned int inSDp_index = two_jumps_cv_p_inSDp.get_inSD_index ();

						      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDp + dimension_inSDn*inSDp_index;
						  
						      const unsigned int p_in  = two_jumps_cv_p_inSDp.get_left_in ();
						      const unsigned int pp_in = two_jumps_cv_p_inSDp.get_right_in ();

						      const unsigned int  p_out = two_jumps_cv_p_inSDp.get_left_out ();
						      const unsigned int pp_out = two_jumps_cv_p_inSDp.get_right_out ();
						  
						      const unsigned int total_bin_phase_p = two_jumps_cv_p_inSDp.get_total_bin_phase ();
							  
						      const TYPE &PSI_in_component = PSI_in_full[total_PSI_in_index];
						      
						      if (are_M_TBMEs_stored)
							{
							  const unsigned int M_TBMEs_cv_index = (is_it_cv_pp_to_nn) ? (M_TBMEs_cv_pp_to_nn_indices(p_in , pp_in , n_out_shell , nn_out)) : (M_TBMEs_cv_nn_to_pp_indices(n_in_shell , nn_in , p_out , pp_out));
						  
							  const TYPE TBME = M_TBMEs[M_TBMEs_cv_index];							  
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}
						      else
							{						  
							  const TYPE TBME = (is_it_cv_pp_to_nn) ? (TBMEs_cv.M_TBME (true , p_in , pp_in , n_out , nn_out)) : (TBMEs_cv.M_TBME (false , n_in , nn_in , p_out , pp_out));
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							}

						      H_multiplications_number_sublocal++;
						    }
						}
					    }
				      
					  PSI_out[PSI_out_index] += component_part;
				      
					  H_multiplications_number_local += H_multiplications_number_sublocal;
				      
					}}}}}}}}}}
  
  H_multiplications_number += H_multiplications_number_local;
}


















void H_class::jumps_part_pp_nn_calc_on_the_fly (class GSM_vector &PSI_out) const
{  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();
  
  const int iM = GSM_vector_helper.get_iM (); 
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector (); 

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);
    
  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const class array_of_SD &SD_set = data.get_SD_set ();
  
  const unsigned int dimension_1p1h_space_BP_S_iM_fixed_max = data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  const unsigned int dimension_2p2h_space_BP_S_iM_fixed_max = data.get_dimension_2p2h_space_BP_S_iM_fixed_max ();
      
  const unsigned int dimension_max = max (dimension_1p1h_space_BP_S_iM_fixed_max , dimension_2p2h_space_BP_S_iM_fixed_max);

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
    
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = data.get_SD_TRS_indices ();

  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = data.get_SD_quantum_numbers_tab ();
    
  const unsigned long int total_outSD_index_min = GSM_vector_helper.get_total_SD_index_min ();
  const unsigned long int total_outSD_index_max = GSM_vector_helper.get_total_SD_index_max ();

  if (total_outSD_index_min > total_outSD_index_max) return;
      
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  class array<bool> is_configuration_accepted_tab(dimension_max);

  is_configuration_accepted_tab = true;
  
  class array<class Slater_determinant> outSDmu_tab(NUMBER_OF_THREADS);
  
  class array<class jumps_data_out_to_in_str> one_jump_mu_tab(NUMBER_OF_THREADS);
  class array<class jumps_data_out_to_in_str> two_jumps_mu_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > NBMEs_one_jump_mu_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > NBMEs_two_jumps_mu_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_in_indices_one_jump_mu_tab(NUMBER_OF_THREADS);
  class array<class array<unsigned long int> > total_PSI_in_indices_two_jumps_mu_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      outSDmu_tab(i).allocate (N_valence_baryons);
      
      one_jump_mu_tab(i).allocate  (ONE_JUMP  , space , truncation_hw , truncation_ph , dimension_1p1h_space_BP_S_iM_fixed_max);
      two_jumps_mu_tab(i).allocate (TWO_JUMPS , space , truncation_hw , truncation_ph , dimension_2p2h_space_BP_S_iM_fixed_max);

      NBMEs_one_jump_mu_tab(i).allocate  (dimension_1p1h_space_BP_S_iM_fixed_max);
      NBMEs_two_jumps_mu_tab(i).allocate (dimension_2p2h_space_BP_S_iM_fixed_max);

      total_PSI_in_indices_one_jump_mu_tab(i).allocate  (dimension_1p1h_space_BP_S_iM_fixed_max);
      total_PSI_in_indices_two_jumps_mu_tab(i).allocate (dimension_2p2h_space_BP_S_iM_fixed_max);
    }
  
  class GSM_vector &PSI_in_full = get_PSI_in_full ();
  
  double H_multiplications_number_local = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) reduction(+:H_multiplications_number_local) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSD_index = total_outSD_index_min ; total_outSD_index <= total_outSD_index_max ; total_outSD_index++)
    {
      const class SD_quantum_numbers &outSD_qn = SD_quantum_numbers_tab(total_outSD_index);

      const unsigned int BP_out = outSD_qn.get_BP ();

      if (BP_out != BP) continue;
      
      const int S_out = outSD_qn.get_S ();

      if (S_out != S) continue;

      const int iM_out = outSD_qn.get_iM ();

      if (iM_out != iM) continue;
      
      const unsigned int n_scat_out = outSD_qn.get_n_scat ();

      const unsigned int iC_out = outSD_qn.get_iC ();

      const int n_holes_out = n_holes_table(BP , S , 0 , n_scat_out , iC_out);
      
      const int E_out_hw = E_hw_table(BP , S , 0 , n_scat_out , iC_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
      
      const unsigned int outSD_index = outSD_qn.get_SD_index ();

      const unsigned long int sum_dimensions_configuration_fixed_out = sum_dimensions_GSM_vector(n_scat_out , iC_out);

      const unsigned long int total_PSI_out_index = sum_dimensions_configuration_fixed_out + outSD_index;
      
      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
	{
	  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

	  const unsigned int outSD_TRS_index = (is_it_TRS) ? (SD_TRS_indices(BP , S , 0 , n_scat_out , iC_out , iM , outSD_index)) : (NADA);

	  const unsigned long int sum_dimensions_configuration_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(n_scat_out , iC_out)) : (NADA);

	  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (sum_dimensions_configuration_fixed_TRS_out + outSD_TRS_index) : (NADA);
      
	  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
	    {			
	      const unsigned int i_thread = OpenMP_thread_number_determine ();

	      class Slater_determinant &outSDmu = outSDmu_tab(i_thread);
	  
	      class jumps_data_out_to_in_str &one_jump_mu  = one_jump_mu_tab(i_thread);
	      class jumps_data_out_to_in_str &two_jumps_mu = two_jumps_mu_tab(i_thread);

	      class array<TYPE> &NBMEs_one_jump_mu  = NBMEs_one_jump_mu_tab(i_thread);
	      class array<TYPE> &NBMEs_two_jumps_mu = NBMEs_two_jumps_mu_tab(i_thread);

	      class array<unsigned long int> &total_PSI_in_indices_one_jump_mu  = total_PSI_in_indices_one_jump_mu_tab(i_thread);
	      class array<unsigned long int> &total_PSI_in_indices_two_jumps_mu = total_PSI_in_indices_two_jumps_mu_tab(i_thread);

	      bool is_there_one_jump_calc = false;

	      bool are_there_two_jumps_calc = false;

	      outSDmu = SD_set(BP , S , 0 , n_scat_out , iC_out , iM , outSD_index);
	  
	      NBMEs_one_jump_pp_nn_calc_partial_storage_on_the_fly (BP , S , 0 , iM , n_scat_out , iC_out , outSD_index , outSDmu , data , is_there_one_jump_calc , one_jump_mu , NBMEs_one_jump_mu);
      
	      if (is_there_one_jump_calc)
		{
		  total_PSI_in_indices_pp_nn_fill (one_jump_mu , GSM_vector_helper , total_PSI_in_indices_one_jump_mu , is_there_one_jump_calc);
		
		  if (is_there_one_jump_calc)
		    {
		      const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();
	    
		      PSI_out[PSI_out_index] += component_part_jumps_calc (dimension_one_jump_mu , is_configuration_accepted_tab , total_PSI_in_indices_one_jump_mu , NBMEs_one_jump_mu , PSI_in_full);

		      H_multiplications_number_local += component_part_jumps_number_calc (dimension_one_jump_mu , is_configuration_accepted_tab);
		    }
		}
	  
	      NBMEs_two_jumps_pp_nn_calc_partial_storage_on_the_fly (BP , S , 0 , iM , n_scat_out , iC_out , outSD_index , data , are_there_two_jumps_calc , two_jumps_mu , NBMEs_two_jumps_mu);
			    
	      if (are_there_two_jumps_calc)
		{
		  total_PSI_in_indices_pp_nn_fill (two_jumps_mu , GSM_vector_helper , total_PSI_in_indices_two_jumps_mu , are_there_two_jumps_calc);
		
		  if (are_there_two_jumps_calc)
		    {
		      const unsigned int dimension_two_jumps_mu = two_jumps_mu.get_dimension ();
		  
		      PSI_out[PSI_out_index] += component_part_jumps_calc (dimension_two_jumps_mu , is_configuration_accepted_tab , total_PSI_in_indices_two_jumps_mu , NBMEs_two_jumps_mu , PSI_in_full);
			
		      H_multiplications_number_local += component_part_jumps_number_calc (dimension_two_jumps_mu , is_configuration_accepted_tab);
		    }
		}	   
	    }
	}
    }
 
  H_multiplications_number += H_multiplications_number_local;
}











void H_class::apply_add_off_diagonal_on_the_fly (
						 const class GSM_vector &PSI_in ,
						 class GSM_vector &PSI_out) const
{  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();
        
  class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  class GSM_vector &PSI_in_full = get_PSI_in_full ();

  PSI_in_full.change_GSM_vector_helper_reallocate (GSM_vector_helper_full);
  
  const double reference_time = absolute_time_determine ();
  
  PSI_in_full.full_vector_fill (PSI_in);
  
  const double MPI_Bcast_absolute_time = absolute_time_determine ();
      
  H_MPI_communication_time += MPI_Bcast_absolute_time - reference_time;
 
  if (configuration_SD_one_jump_tables_to_recalculate_for_matrices)
    {
      const class GSM_vector_helper_class dummy_helper;

      const bool is_it_one_body = (!is_pp_non_zero && !is_nn_non_zero && !is_pn_non_zero);
      
      configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , is_it_one_body , false , false , false , GSM_vector_helper_full , GSM_vector_helper , dummy_helper , prot_Y_data , neut_Y_data);
    }
 
  if (space == PROT_NEUT_Y)
    {
      const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
      const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
	      
      const int ZYval = prot_Y_data.get_N_valence_baryons ();
      const int NYval = neut_Y_data.get_N_valence_baryons ();
	   
      if (is_one_body_p_non_zero || is_pp_non_zero) jumps_p_one_body_part_pn_calc_on_the_fly (PSI_out);
      if (is_one_body_n_non_zero || is_nn_non_zero) jumps_n_one_body_part_pn_calc_on_the_fly (PSI_out);
      
      if (is_pp_non_zero) jumps_p_two_body_part_pn_calc_on_the_fly (PSI_out);      
      if (is_nn_non_zero) jumps_n_two_body_part_pn_calc_on_the_fly (PSI_out);
      
      if (is_pn_non_zero)
	{
	  one_jump_p_pn_part_pn_calc_on_the_fly (PSI_out);
	  one_jump_n_pn_part_pn_calc_on_the_fly (PSI_out);

	  switch (one_jumps_pn_two_jumps_cv_storage)
	    {
	    case FULL_STORAGE:
	      {
		if (NYval >= ZYval)
		  two_jumps_pn_part_pn_on_the_fly_one_jumps_stored_N_valence_larger_calc (PSI_out);
		else
		  two_jumps_pn_part_pn_on_the_fly_one_jumps_stored_Z_valence_larger_calc (PSI_out);
	      } break;

	    case PARTIAL_STORAGE:
	      {
		if (NYval >= ZYval)
		  two_jumps_pn_part_pn_on_the_fly_one_jumps_partially_stored_N_valence_larger_calc (PSI_out);
		else
		  two_jumps_pn_part_pn_on_the_fly_one_jumps_partially_stored_Z_valence_larger_calc (PSI_out);
	      } break;

	    case ON_THE_FLY:
	      {
		if (NYval >= ZYval)
		  two_jumps_pn_part_pn_on_the_fly_one_jumps_recalculated_N_valence_larger_calc (PSI_out);
		else
		  two_jumps_pn_part_pn_on_the_fly_one_jumps_recalculated_Z_valence_larger_calc (PSI_out);
	      } break;

	    default: abort_all ();
	    }      
	}
      
      if (is_cv_non_zero)
	{
	  switch (one_jumps_pn_two_jumps_cv_storage)
	    {
	    case FULL_STORAGE:
	      {
		if (NYval >= ZYval)
		  {
		    two_jumps_cv_part_pn_on_the_fly_two_jumps_stored_N_valence_larger_calc (true  , PSI_out);
		    two_jumps_cv_part_pn_on_the_fly_two_jumps_stored_N_valence_larger_calc (false , PSI_out);
		  }
		else
		  {
		    two_jumps_cv_part_pn_on_the_fly_two_jumps_stored_Z_valence_larger_calc (true  , PSI_out);
		    two_jumps_cv_part_pn_on_the_fly_two_jumps_stored_Z_valence_larger_calc (false , PSI_out);
		  }
	      } break;

	    case PARTIAL_STORAGE:
	      {
		if (NYval >= ZYval)
		  {
		    two_jumps_cv_part_pn_on_the_fly_two_jumps_partially_stored_N_valence_larger_calc (true  , PSI_out);
		    two_jumps_cv_part_pn_on_the_fly_two_jumps_partially_stored_N_valence_larger_calc (false , PSI_out);
		  }
		else
		  {
		    two_jumps_cv_part_pn_on_the_fly_two_jumps_partially_stored_Z_valence_larger_calc (true  , PSI_out);
		    two_jumps_cv_part_pn_on_the_fly_two_jumps_partially_stored_Z_valence_larger_calc (false , PSI_out);
		  }
	      } break;

	    case ON_THE_FLY:
	      {
		if (NYval >= ZYval)
		  {
		    two_jumps_cv_part_pn_on_the_fly_two_jumps_recalculated_N_valence_larger_calc (true  , PSI_out);
		    two_jumps_cv_part_pn_on_the_fly_two_jumps_recalculated_N_valence_larger_calc (false , PSI_out);
		  }
		else
		  {
		    two_jumps_cv_part_pn_on_the_fly_two_jumps_recalculated_Z_valence_larger_calc (true  , PSI_out);
		    two_jumps_cv_part_pn_on_the_fly_two_jumps_recalculated_Z_valence_larger_calc (false , PSI_out);
		  }
	      } break;

	    default: abort_all ();
	    }      
	}
    }
  else
    jumps_part_pp_nn_calc_on_the_fly (PSI_out);

  if (configuration_SD_one_jump_tables_to_recalculate_for_matrices)
    {
      prot_Y_data.one_jump_tables_out_to_in_deallocate ();
      neut_Y_data.one_jump_tables_out_to_in_deallocate ();
    }
          
  PSI_in_full.remove_GSM_vector_helper ();
  
  if (is_there_cout_detailed) H_MPI_communication_times_multiplications_number_print ();
}

