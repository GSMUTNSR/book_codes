#include "../GSM_include/GSM_include_def.h"

// MPI transfer is sometimes done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

using namespace string_routines;
using namespace inputs_misc;
using namespace correlated_state_routines;
using namespace total_diagonalization::symmetric;

extern enum called_code_type called_code;

// TYPE is double or complex
// -------------------------



// Implementation of the Lanczos method
// ------------------------------------
//
// Hamiltonian
// -----------
//
// One used here the Lanczos method to diagonalize the Hamiltonian H with pole approximation or using a HO basis, as the Lanczos method provides with extremal eigenpairs.
// One can diagonalize H exactly (full diagonalization), as is the case with pole approximation, or only calculate the lowest eigenstates, as in standard shell model.
// J-scheme dimension should be typically smaller than 500 if one does a full diagonalization of H.
//
// One can calculate N eigenvectors of same J-Pi at the same time, of arbitrary indices, from n=0 (ground state) to n=dimension[H[J.scheme]]-1.
// In this case, one has N Lanczos vectors |Phi[i]> and N eigenvectors Psi[i] in the following.
// We will consider N=1 only in explanations for simplicity, as the N > 1 case is a straightforward generalization.
//
// One starts from a pivot |Phi[0]>, either random (+ J (and/or T) projection), obtained from a previous diagonalization or from a file.
// This also provides with the first eigenpair approximation |Psi[0]> = Phi[0], of energy E[0] = <Psi[0] | H | Psi[0]>.
// If the GSM dimension is 1, the Lanczos method stops here.
//
// 1) One calculate the next Lanczos vector:
//    It is |Phi[1]>   = H|Phi[0]> - <Phi[0] | H | Phi[0]> |Phi[0]> + orthonormalization (see after) for i = 0 and
//          |Phi[i+1]> = H|Phi[i]> - <Phi[i] | H | Phi[i]> |Phi[i]> - <Phi[i] | H | Phi[i-1]> |Phi[i-1]> + orthonormalization (see after) for i >= 1.
// 
// 2) Orthogonalize |Phi[i+1]> to all previous Lanczos vectors |Phi[j]>, 0 <= j <= i.
//    Orthogonalization is necessary from numerical reasons. Indeed, as is well known, Lanczos vectors are orthogonal theoretically,
//    but lose orthogonality once convergence to an eigenvector starts.
//    Hence, they are orthogonalized with the modified Gram-Schmidt method as if they were non orthogonal.
//
// 3) Project |Phi[i+1]> on J (and/or T) if necessary and normalize.
//    Indeed, even though H commutes with \vec{J} (and \vec{T} if there is no Coulomb interaction) theoretically,
//    it is not true numerically and one sometimes has to project on J (and/or T) because good quantum number character is lost due to numerical inaccuracy.
//
// 4) Project H onto the extended basis set |Phi[j]>, 0 <= j <= i+1.
//    If full diagonalization is not used, the obtained tridiagonal complex symmetric matrix is diagonalized exactly using standard methods. 
//    This provides with a new approximation to the eigenpair E[i+1] and |Psi[i+1]>.
//
// 5) If one does not do a full diagonalization, the |Psi[i]> eigenstate is the extremal eigenstate.
//
// 6) Repeat the above steps until convergence, as indicated by the |<Phi[i] | Psi[i]>|oo or until GSM dimension is reached for full diagonalization.
//    If N eigenvectors are calculated, one takes the infinite norm of all N residues.
// 
// An array of GSM vectors, of number the number of OpenMP threads, one 1 if OpenMP is not used, is used for orthogonalization.
// Its first vector is also used as storage vector for Hamiltonian times vector, the two parts of the Lanczos vectors after H|Phi[i]>, and residue R[i].
//
// Isospin projection has been used for testing purposes only, using small model spaces.

// new_Lanczos_vector_alloc_calc
// -----------------------------
// The new Lanczos vector |Phi[i+1]>, for i >= 0, is calculated in this routine using points 1), 2), 3).
// One does J projection and orthogonalization afterwards.
//
// tridiagonalization
// ------------------
// The H matrix is tridiagonalized using the Lanczos method using the routine new_Lanczos_vector_alloc_calc.
// It is represented using already calculated Lanczos vectors (see point 4).
// H is diagonalized at each iteration in Lanczos_matrix_diagonalization_test (point 5 using partial diagonalization) or when GSM dimension is reached (full diagonalization).
// Hamiltonian is applied to the current Lanczos vector |Phi[i+1]> therein. H |Phi[0]> was also calculated before Lanczos iterations start.
// <Phi[i+1] | H | Phi[i]> is calculated for the next iteration by using H |Phi[i]> and the newly calculated |Phi[i+1]> Lanczos vector.
// The time taken for the calculation of Lanczos vectors can be printed on screen. 
// The generalized Lawson method has been coded with the L^2[CM] operator, but it is kept only for testing purposes and has never been used otherwise.
//
// Lanczos_matrix_diagonalization_test
// ----------------------------
// One calculated here the convergence test of the Lanczos method if partial diagonalization is used, as well as the approximation of eigenenergies at this level.
// Infinite is returned if one has not reached the N-th Lanczos iteration when calculating N Lanczos eigenvectors.
// The Lanczos matrix is diagonalized exactly and eigenvectors are the extremal eigenvectors.
// Their energy can be printed on screen, as well as the residue test.
// 
// all_eigenvectors_energies_alloc_calc
// ------------------------------------
// If full diagonalization is used, all Hamiltonian eigenvectors are calculated here in Slater determinant basis from their representation with Lanczos vectors.
// For this, Lanczos vectors are multiplied by their eigenvector component and added to the Hamiltonian eigenvector in Slater determinant basis.
// Hamiltonian eigenvectors in Slater determinant basis are distributed over all MPI ranks.
// Lanczos vectors are read in parallel in different OpenMP threads, and sequentially added to the Hamiltonian eigenvector in Slater determinant basis.
// The aforementioned array of GSM vectors is used for independent storage on each thread.
//
// lowest_eigenvectors_calc_store_write_expectation_values
// -------------------------------------------------------
// If full diagonalization is not used, all |Psi[i]> eigenvectors are calculated from the Lanczos basis to the Slater determinant basis and stored on disk when convergence is reached.
// Expectation values of operators and configuration mixing can be printed at the end of the calculation.
// 
// iterative_diagonalization_lowest_states
// --------------------------------------- 
// The pivot vector is initialized at a random value (+ J projection) and is obtained from pole approximation or another calculation.
// One can use full or patial diagonalization.
// tridiagonalization, all_eigenvectors_energies_alloc_calc and lowest_eigenvectors_calc_store_write_expectation_values are called here.
// The Lanczos process can be restarted, by taking the last |Psi[i]> as pivot. This allows not to have many lengthy orthogonalizations if one has many iterations.
////
//
//
//
//
//
// J^2 projection
// --------------
//
// J-projection has been coded with the Lanczos method.
// One needs a number of Lanczos iterations equal to the number N of possible angular quantum numbers J' in the model space verifying J' >= M.
// Indeed, as a pivot has at most N J'-components, J^2 is closed in the Lanczos subspace built with N Lanczos iterations.
// One then needs an additional array of GSM vectors for that matter, which is equal to the number of possible angular quantum numbers J' in the model space verifying J' >= M.
// The Lowdin and Lanczos J-projections have, in fact, the same numerical cost besides storage.
// One assumes that the vector to project on J has all its J'-components different from zero.
// This occurs in practice because the numerical inaccuracies leading to the non-commutation of H and \vec{J} generates small random components for all values J' different from J.
// The routines for J^2 projection are tridiagonalization and J_projected_GSM_vector_calc. Method is the same as for H diagonalization, except that one does a full diagonalization every time.
// The projected vector is immediate to find as it is the only J^2 matrix eigenvector with an eigenvalue of J(J+1).


void Lanczos_GSM_not_disk::Hamiltonian::new_Lanczos_vector_alloc_calc (
								       const bool is_there_cout_detailed ,
								       const bool J_projected , 
								       const bool is_it_Lowdin , 
								       const unsigned int J_number ,
								       const class J2_class &J2 , 
								       const double J ,
								       const class array<TYPE> &diagonal_tab , 
								       const class array<TYPE> &off_diagonal_tab , 
								       const unsigned int i , 
								       const class GSM_vector &HV_im1 ,
								       class GSM_vector &Vstore ,
								       class array<class GSM_vector> &V_tab , 
								       class array<class GSM_vector> &Vp_tab)
{
  const unsigned int im1 = i - 1;

  const unsigned int im2 = (i >= 2) ? (i - 2) : (NADA);
  
  class GSM_vector &Vi = V_tab(i);

  if (!Vi.is_it_filled ())
    Vi.allocate_fill (HV_im1);
  else
    Vi = HV_im1;
  
  if (i == 1)
    Vi -= diagonal_tab(im1)*V_tab(im1);
  else
    Vi -= diagonal_tab(im1)*V_tab(im1) + off_diagonal_tab(im2)*V_tab(im2);

  orthogonalization_not_disk (is_there_cout_detailed , i , V_tab);

  Vi.normalization ();
    
  if (J_projected) Vi.project_good_J (is_there_cout_detailed , J2 , J , J_number , is_it_Lowdin , false , Vp_tab , Vstore);
}




void Lanczos_GSM_not_disk::Hamiltonian::tridiagonalization (
							    const bool is_there_cout , 
							    const class input_data_str &input_data , 
							    const bool full_diagonalization , 
							    const unsigned int J_number ,
							    const unsigned int dimension_good_J_or_M , 
							    const unsigned int Lanczos_max_dimension , 
							    const unsigned int vectors_to_find_number , 
							    const double J , 
							    const class J2_class &J2 ,
							    const class H_class &H , 
							    class GSM_vector &HV , 
							    class GSM_vector &Vstore , 
							    class array<class GSM_vector> &V_tab , 
							    class array<class GSM_vector> &Vp_tab , 
							    class array<TYPE> &diagonal_tab , 
							    class array<TYPE> &off_diagonal_tab , 
							    class array<TYPE> &E_tab , 
							    unsigned int &Lanczos_dimension , 
							    double &test)
{
  const class GSM_vector_helper_class &GSM_vector_helper = Vstore.get_GSM_vector_helper ();
  
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
      
  const int Z = prot_data.get_N_nucleons ();
  const int N = neut_data.get_N_nucleons ();
  
  const bool J_projected = input_data.get_J_projected ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
	  
  const bool print_detailed_information = input_data.get_print_detailed_information ();

  const bool is_there_cout_detailed = (is_there_cout && print_detailed_information);

  const bool is_there_cout_not_detailed = (is_there_cout && !print_detailed_information);
    
  const bool is_it_Lowdin = input_data.get_is_it_Lowdin ();
  
  const double test_vector_solution = input_data.get_test_vector_solution ();

  const class GSM_vector &V0 = V_tab(0);
  
  class GSM_vector &HV0 = HV;
  
  HV0 = H*V0;
  
  diagonal_tab(0) = (V0*HV0);

  if (Lanczos_max_dimension == 1)
    {
      E_tab(0) = diagonal_tab(0);

      Lanczos_dimension = 1;

      test = 0.0;

      return;
    }

  const TYPE E0 = diagonal_tab(0);

  class GSM_vector &Res = Vstore;	  

  Res = HV0 - E0*V0;
      
  const double Res_norm = Res.infinite_norm ();
  
  if (Res_norm < precision)
    {
      E_tab(0) = E0;

      Lanczos_dimension = 1;

      test = 0.0;
      
      return;
    }

  cout.precision (10);
    
  for (unsigned int i = 1 ; ((i < Lanczos_max_dimension) && ((test > test_vector_solution) || full_diagonalization)) ; i++)
    {
      const bool is_time_considered = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_not_detailed);

      const double reference_time = (is_time_considered) ? (absolute_time_determine ()) : (NADA);

      const class GSM_vector &HV_im1 = HV;          
      
      new_Lanczos_vector_alloc_calc (is_there_cout_detailed , J_projected , is_it_Lowdin , J_number , J2 , J , diagonal_tab , off_diagonal_tab , i , HV_im1 , Vstore , V_tab , Vp_tab);

      const class GSM_vector &Vi = V_tab(i);
      
      off_diagonal_tab(i-1) = (Vi*HV_im1);

      class GSM_vector &HVi = HV;
      
      HVi = H*Vi;

      diagonal_tab(i) = (Vi*HVi);

      off_diagonal_tab(i) = 0.0; 

      if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_detailed)
	{	        
	  cout << endl << "Iteration:" << i << endl;
	  cout <<  "---------------" << endl << endl;

	  if (J_projected)
	    cout << J_Pi_string (BP , J) << " Z:" << Z << " , N:" << N << endl;
	  else
	    cout << J_Pi_string (BP , J) << " [Jmin] Z:" << Z << " , N:" << N << endl;
	}
        
      if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_not_detailed) cout << "Iteration " << i << "  ";
      
      Lanczos_dimension = i + 1;

      if (!full_diagonalization) 
	Lanczos_matrix_diagonalization_test (is_there_cout , print_detailed_information , dimension_good_J_or_M , Lanczos_dimension , vectors_to_find_number , diagonal_tab , off_diagonal_tab , E_tab , test);
      
      if ((THIS_PROCESS == MASTER_PROCESS) && is_time_considered)
	{
	  const double now = absolute_time_determine () , relative_time = now - reference_time;
	  
	  cout << "time:" << relative_time << " s" << endl;
	}
    }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << endl;

  cout.precision (15);
}



void Lanczos_GSM_not_disk::Hamiltonian::Lanczos_matrix_diagonalization_test (
									     const bool is_there_cout , 
									     const bool print_detailed_information ,
									     const unsigned int dimension_good_J_or_M , 
									     const unsigned int Lanczos_dimension , 
									     const unsigned int vectors_to_find_number , 
									     const class array<TYPE> &diagonal_tab , 
									     const class array<TYPE> &off_diagonal_tab , 
									     class array<TYPE> &E_tab , 
									     double &test)
{
  if (Lanczos_dimension < vectors_to_find_number) 
    {
      if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout && print_detailed_information) cout << endl; 

      test = INFINITE;
      
      return;
    }
	      
  const unsigned int Lanczos_dimension_minus_one = Lanczos_dimension - 1;
  
  class array<TYPE> diagonal_small_tab(Lanczos_dimension);

  class array<TYPE> off_diagonal_small_tab(Lanczos_dimension);

  diagonal_small_tab.assign (diagonal_tab);

  off_diagonal_small_tab.assign (off_diagonal_tab);
    
  class matrix<TYPE> Lanczos(Lanczos_dimension);

  class array<TYPE> E_small_tab(Lanczos_dimension);
  
  all_eigenpairs (off_diagonal_small_tab , diagonal_small_tab , Lanczos , E_small_tab);

  E_tab.assign (E_small_tab);

  test = 0.0;
  
  if (Lanczos_dimension < dimension_good_J_or_M) 
    {
      for (unsigned int i = 0 ; i < vectors_to_find_number ; i++)
	{
	  const class vector_class<TYPE> &eigenvector_i =  Lanczos.eigenvector(i);

	  const TYPE eigenvector_i_last_Lanczos_vector_overlap = eigenvector_i(Lanczos_dimension_minus_one);

	  test = max (test , inf_norm (eigenvector_i_last_Lanczos_vector_overlap));

	  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
	    {	      
	      const TYPE E_tilde = E_tab(i);

	      cout << "E:" << E_tilde << " ";	      
	    }
	}
      
      if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout && print_detailed_information) cout << endl;
    }

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      if (print_detailed_information)
	cout << "test:" << test << endl << endl;
      else
	cout << " test:" << test << "  ";
    }
}







void Lanczos_GSM_not_disk::Hamiltonian::all_eigenvectors_energies_alloc_calc (
									      const bool is_it_pole_approximation ,
									      const double J , 
									      const class array<TYPE> &diagonal_tab , 
									      const class array<TYPE> &off_diagonal_tab , 
									      const class array<class GSM_vector> &V_tab , 
									      class matrix<TYPE> &Lanczos , 
									      class array<TYPE> &E_tab , 
									      class array<TYPE> &E_subspace_tab , 
									      class array<class GSM_vector_helper_class> &GSM_vector_helper_subspace_tab , 
									      class array<class GSM_vector> &eigenvector_subspace_tab)
{ 
  all_eigenpairs (off_diagonal_tab , diagonal_tab , Lanczos , E_tab);
  
  if (!is_it_pole_approximation) return;

  class GSM_vector_helper_class &GSM_vector_helper_M = V_tab(0).get_GSM_vector_helper ();

  const int two_J = make_int (2.0*J);

  const unsigned int BP = GSM_vector_helper_M.get_BP ();

  const unsigned int J_index = (two_J%2 == 0) ? (make_uns_int (J)) : (make_uns_int (J - 0.5));

  const unsigned int Lanczos_max_dimension = diagonal_tab.dimension (0);
  
  class GSM_vector_helper_class &GSM_vector_helper_subspace = GSM_vector_helper_subspace_tab(BP , J_index);      

  GSM_vector_helper_subspace.allocate_fill (GSM_vector_helper_M);
        
  for (unsigned int i = 0 ; i < Lanczos_max_dimension ; i++)
    {
      const class vector_class<TYPE> &eigenvector_Lanczos = Lanczos.eigenvector (i);

      class GSM_vector &PSI_subspace = eigenvector_subspace_tab(BP , J_index , i);
  
      E_subspace_tab(BP , J_index , i) = E_tab(i);
  
      PSI_subspace.allocate (GSM_vector_helper_subspace);

      PSI_subspace = 0.0;
      
      for (unsigned int ii = 0 ; ii < Lanczos_max_dimension ; ii++) PSI_subspace += eigenvector_Lanczos(ii)*V_tab(ii);

      PSI_subspace.good_phase ();
    }
}  









void Lanczos_GSM_not_disk::Hamiltonian::lowest_eigenvectors_calc_store_write_expectation_values (
												 const bool is_there_cout , 
												 const bool vectors_write , 
												 const bool full_common_vectors_used_in_file , 
												 const bool full_diagonalization ,
												 const class input_data_str &input_data , 
												 const class J2_class &J2 , 
												 const class T2_class &T2 , 
												 const class H_class &H , 
												 const class L2_CM_class &L2_CM , 
												 const unsigned int Lanczos_dimension , 
												 const unsigned int eigenset_index , 
												 const unsigned int vectors_to_find_number , 
												 const class array<TYPE> &diagonal_tab , 
												 const class array<TYPE> &off_diagonal_tab , 
												 const class array<TYPE> &E_tab , 
												 const class matrix<TYPE> &Lanczos , 
												 const class array<class GSM_vector> &V_tab , 
												 const bool are_PSI_expectation_values_written , 
												 class GSM_vector &PSI_full ,
												 class GSM_vector &Vstore , 
												 class GSM_vector &PSI , 
												 class array<class correlated_state_str> &PSI_qn_tab)
{  
  const bool J_projected = input_data.get_J_projected ();
  
  const bool is_there_reindexation = (!J_projected && are_PSI_expectation_values_written);
  
  const class GSM_vector_helper_class &GSM_vector_helper_M = PSI.get_GSM_vector_helper ();
  
  class array<TYPE> diagonal_small_tab(Lanczos_dimension);

  class array<TYPE> off_diagonal_small_tab(Lanczos_dimension);
  
  diagonal_small_tab.assign (diagonal_tab);

  off_diagonal_small_tab.assign (off_diagonal_tab);
    
  const double Jmin = GSM_vector_helper_M.get_M ();
  const double Jmax = GSM_vector_helper_M.get_Jmax ();
  
  const unsigned int J_PSI_number = make_uns_int (Jmax - Jmin) + 1;
  
  class array<unsigned int> new_eigenvector_J_indices_J_not_projected(J_PSI_number);

  new_eigenvector_J_indices_J_not_projected = (is_there_reindexation) ? (0) : (NADA);
  
  for (unsigned int i = 0 ; i < vectors_to_find_number ; i++)
    {      
      class correlated_state_str &PSI_qn = PSI_qn_tab(eigenset_index , i);
      
      const unsigned int eigenvector_index = PSI_qn.get_vector_index ();
      
      const TYPE E = E_tab(eigenvector_index);

      const class vector_class<TYPE> eigenvector_Lanczos = (full_diagonalization) ? (Lanczos.eigenvector(eigenvector_index)) : (eigenvector_tridiagonal_calc (E , precision , diagonal_small_tab , off_diagonal_small_tab));

      PSI = 0.0;

      for (unsigned int ii = 0 ; ii < Lanczos_dimension ; ii++) PSI += eigenvector_Lanczos(ii)*V_tab(ii);

      PSI.good_phase ();
      
      PSI_qn.initialize (
			 PSI_qn.get_Z () ,
			 PSI_qn.get_N () ,
			 PSI_qn.get_BP () ,
			 PSI_qn.get_J () ,
			 PSI_qn.get_vector_index () , 
			 E ,
			 PSI_qn.get_weight () ,
			 PSI_qn.get_experimental_energy () ,
			 PSI_qn.get_energy_error () ,
			 PSI_qn.get_is_it_optimization_reference_state ());
      
      if (vectors_write) 
	{
	  const TYPE average_n_scat = PSI.average_n_scat_calc ();
	  
	  if (J_projected)
	    {
	      PSI.space_dimension_SDs_components_eigenvector_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);
	      
	      if (THIS_PROCESS == MASTER_PROCESS) GSM_vector_eigenenergy_average_n_scat_copy_disk ("eigenvector_E_averaged_n_scat" , PSI_qn , average_n_scat);
	    }
	  else
	    PSI.space_dimension_SDs_components_eigenvector_Jmin_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);
	    	  
	  if (is_there_reindexation)
	    {
	      class GSM_vector &J2_PSI = Vstore;
      
	      J2_PSI = J2*PSI;
      
	      const double J_PSI = rint (real_dc (-1.0 + sqrt (1.0 + 4.0*(PSI*J2_PSI))))/2.0;
  
	      const unsigned int J_index = make_uns_int (J_PSI - Jmin);
											      
	      const unsigned int vector_index_PSI = new_eigenvector_J_indices_J_not_projected(J_index)++;
      
	      PSI_qn.initialize (
				 PSI_qn.get_Z () ,
				 PSI_qn.get_N () ,
				 PSI_qn.get_BP () ,
				 J_PSI ,
				 vector_index_PSI ,
				 E ,
				 PSI_qn.get_weight () ,
				 PSI_qn.get_experimental_energy () ,
				 PSI_qn.get_energy_error () ,
				 PSI_qn.get_is_it_optimization_reference_state ());
	      
	      PSI.space_dimension_SDs_components_eigenvector_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);
	      
	      if (THIS_PROCESS == MASTER_PROCESS) GSM_vector_eigenenergy_average_n_scat_copy_disk ("eigenvector_E_averaged_n_scat" , PSI_qn , average_n_scat);
	    }
	}
      
      if (are_PSI_expectation_values_written && is_there_cout)
	eigenvector_functions::write_expectation_values (input_data , PSI , J2 , T2 , H , L2_CM , PSI_full , Vstore , PSI_qn);
    }
}










void Lanczos_GSM_not_disk::Hamiltonian::iterative_diagonalization_lowest_states (
										 const bool is_there_cout , 
										 const bool is_it_pole_approximation , 
										 const bool vectors_write ,  
										 const class input_data_str &input_data , 
										 const bool full_diagonalization , 
										 const unsigned int J_number ,
										 const unsigned int dimension_good_J_or_M , 
										 const unsigned int Lanczos_max_dimension , 
										 const double J , 
										 const class H_class &H , 
										 const class J2_class &J2 , 
										 const unsigned int eigenset_index , 
										 const unsigned int eigenset_vectors_number ,
										 class array<TYPE> &E_subspace_tab , 
										 class array<class GSM_vector_helper_class> &GSM_vector_helper_subspace_tab , 
										 class array<class GSM_vector> &eigenvector_subspace_tab , 
										 class GSM_vector &PSI_full ,
										 class GSM_vector &V ,  
										 class GSM_vector &Vstore ,
										 class array<class GSM_vector> &PSI_M_tab , 
										 class array<class GSM_vector> &PSI_Mp1_tab , 
										 class array<class GSM_vector> &V_tab , 
										 class array<class GSM_vector> &Vp_tab ,
										 class array<class correlated_state_str> &PSI_qn_tab)
{
  const bool is_it_Lanczos_only = input_data.get_is_it_Lanczos (); 
  
  const bool initial_pivot_from_file = input_data.get_initial_pivot_from_file ();
  
  if (!is_it_Lanczos_only && !is_it_pole_approximation && !full_diagonalization)
    error_message_print_abort ("The Lanczos method is used at pole approximation level along with full diagonalization only with the Davidson method");

  if (is_it_pole_approximation && is_it_Lanczos_only && initial_pivot_from_file)
    error_message_print_abort ("The Lanczos method is never used at pole approximation level with a pivot from file");
  
  const bool print_detailed_information = input_data.get_print_detailed_information ();

  const bool is_there_cout_detailed = (is_there_cout && print_detailed_information);
  
  const bool is_there_cout_not_detailed = (is_there_cout && !print_detailed_information);
    
  const bool J_projected = input_data.get_J_projected ();
  
  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();

  const bool full_common_vectors_used_in_file_local = (full_common_vectors_used_in_file || is_it_pole_approximation);
 
  const bool is_it_Lowdin = input_data.get_is_it_Lowdin ();

  const double test_vector_solution = input_data.get_test_vector_solution ();

  const unsigned int N_restarts = input_data.get_N_restarts ();

  const unsigned int N_restarts_plus_one = N_restarts + 1;
  
  const enum interaction_type inter = input_data.get_inter ();

  const bool is_it_COSM = is_it_COSM_determine (inter);

  const bool T2_CM_operators_calculated = input_data.get_T2_CM_operators_calculated ();

  const bool is_L2_CM_applied = (!is_it_COSM && T2_CM_operators_calculated); 
    
  class GSM_vector &PSI0_M = PSI_M_tab(0);

  class GSM_vector &PSI0_Mp1 = PSI_Mp1_tab(0);

  class GSM_vector_helper_class &GSM_vector_helper_M = PSI0_M.get_GSM_vector_helper ();
  
  class GSM_vector_helper_class &GSM_vector_helper_Mp1 = PSI0_Mp1.get_GSM_vector_helper ();
        
  const class T2_class T2(false , J , GSM_vector_helper_M , PSI_full);

  class CM_operator_class Lplus;
  class CM_operator_class Lminus;
  
  class CM_operator_class Lz;

  class L2_CM_class L2_CM;

  if (is_L2_CM_applied)
    {	
      Lplus.allocate  (LPLUS  , false , J , true , GSM_vector_helper_M   , GSM_vector_helper_Mp1 , PSI_full);
      Lminus.allocate (LMINUS , false , J , true , GSM_vector_helper_Mp1 , GSM_vector_helper_M   , PSI_full);
      Lz.allocate     (LZ     , false , J , true , GSM_vector_helper_M   , GSM_vector_helper_M   , PSI_full);
      
      L2_CM.allocate (Lplus , Lminus , Lz , PSI0_M , PSI0_Mp1);
    }

  double test = INFINITE;

  class GSM_vector &V0 = V_tab(0);
  
  if (!V0.is_it_filled ()) V0.allocate_fill (Vstore);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_not_detailed)
    {	  
      const unsigned int BP = GSM_vector_helper_M.get_BP ();
  
      const class nucleons_data &prot_data = GSM_vector_helper_M.get_prot_data (); 
      const class nucleons_data &neut_data = GSM_vector_helper_M.get_neut_data ();
      
      const int Z = prot_data.get_N_nucleons ();
      const int N = neut_data.get_N_nucleons ();
  
      cout << endl << J_Pi_string (BP , J) << " Z:" << Z << " , N:" << N << endl;
      cout << "--------------------" << endl << endl;
    }
  
  if (full_diagonalization)
    {
      class array<TYPE> E_tab(dimension_good_J_or_M);

      class array<TYPE> diagonal_tab(dimension_good_J_or_M);

      class array<TYPE> off_diagonal_tab(dimension_good_J_or_M);

      V0.pivot_init_Lanczos (is_there_cout_detailed , false , false , J_projected , eigenset_index , eigenset_vectors_number , PSI_qn_tab , J2 , J , J_number , false , is_it_Lowdin , Vp_tab , Vstore);
        
      unsigned int Lanczos_dimension = 0;

      const unsigned int vectors_to_find_number = (is_it_pole_approximation) ? (eigenset_vectors_number) : (dimension_good_J_or_M);

      tridiagonalization (is_there_cout , input_data , full_diagonalization , J_number , dimension_good_J_or_M , dimension_good_J_or_M , vectors_to_find_number ,
			  J , J2 , H , V , Vstore , V_tab , Vp_tab , diagonal_tab , off_diagonal_tab , E_tab , Lanczos_dimension , test);
      
      class matrix<TYPE> Lanczos(dimension_good_J_or_M);

      all_eigenvectors_energies_alloc_calc (is_it_pole_approximation , J , diagonal_tab , off_diagonal_tab , V_tab , Lanczos , E_tab ,
					    E_subspace_tab , GSM_vector_helper_subspace_tab , eigenvector_subspace_tab);

      lowest_eigenvectors_calc_store_write_expectation_values (is_there_cout , vectors_write , full_common_vectors_used_in_file_local , full_diagonalization , input_data , 
							       J2 , T2 , H , L2_CM , dimension_good_J_or_M , eigenset_index , vectors_to_find_number , 
							       diagonal_tab , off_diagonal_tab , E_tab , Lanczos , V_tab , is_it_pole_approximation ,
							       PSI_full , Vstore , V , PSI_qn_tab);
    }
  else
    {     
      class array<TYPE> E_tab(Lanczos_max_dimension);

      class array<TYPE> diagonal_tab(Lanczos_max_dimension);

      class array<TYPE> off_diagonal_tab(Lanczos_max_dimension);

      for (unsigned int r = 0 ; ((r < N_restarts_plus_one) && (test > test_vector_solution)) ; r++)
	{
	  const bool is_there_pivot_from_file_or_restart = (initial_pivot_from_file || (r > 0));
	  
	  if (is_there_pivot_from_file_or_restart)
	    V0.pivot_init_Lanczos (is_there_cout_detailed , full_common_vectors_used_in_file_local , true , J_projected , eigenset_index , eigenset_vectors_number ,
				   PSI_qn_tab , J2 , J , J_number , false , is_it_Lowdin , Vp_tab , Vstore);
	  else
	    V0.pivot_init_Lanczos (is_there_cout_detailed , true , !is_it_pole_approximation , J_projected , eigenset_index , eigenset_vectors_number ,
				   PSI_qn_tab , J2 , J , J_number , false , is_it_Lowdin , Vp_tab , Vstore);
	  
	  unsigned int Lanczos_dimension = 0;

	  tridiagonalization (is_there_cout , input_data , full_diagonalization , J_number , dimension_good_J_or_M , Lanczos_max_dimension , eigenset_vectors_number , 
			      J , J2 , H , V , Vstore , V_tab , Vp_tab , diagonal_tab , off_diagonal_tab , E_tab , Lanczos_dimension , test);

	  const bool are_PSI_expectation_values_written = ((test < test_vector_solution) || (r == N_restarts));

	  const class matrix<TYPE> dummy_matrix;

	  lowest_eigenvectors_calc_store_write_expectation_values (is_there_cout , vectors_write , full_common_vectors_used_in_file_local , full_diagonalization , input_data ,  
								   J2 , T2 , H , L2_CM , Lanczos_dimension , eigenset_index , eigenset_vectors_number , 
								   diagonal_tab , off_diagonal_tab , E_tab , dummy_matrix , V_tab , are_PSI_expectation_values_written ,
								   PSI_full , Vstore , V , PSI_qn_tab);
	}
    }

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << endl << endl;
}





void Lanczos_GSM_not_disk::J2_projection::tridiagonalization (
							      const unsigned int J_number ,
							      const class J2_class &J2 ,  
							      class GSM_vector &J2_Vp , 
							      class array<class GSM_vector> &Vp_tab ,
							      class array<TYPE> &diagonal_tab , 
							      class array<TYPE> &off_diagonal_tab)
{    
  const class GSM_vector &Vp0 = Vp_tab(0);
  
  class GSM_vector &J2_Vp0 = J2_Vp;
  
  J2_Vp0 = J2*Vp0;
  
  diagonal_tab(0) = (Vp0*J2_Vp0);
  
  for (unsigned int i = 1 ; i < J_number ; i++)
    {      
      const unsigned int im1 = i - 1;
  
      const unsigned int im2 = (i >= 2) ? (i - 2) : (NADA);
  
      const class GSM_vector &J2_Vp_im1 = J2_Vp;
      
      class GSM_vector &Vp_i = Vp_tab(i);
    
      if (i == 1)
	Vp_i = J2_Vp_im1 - diagonal_tab(im1)*Vp_tab(im1);
      else
	Vp_i = J2_Vp_im1 - diagonal_tab(im1)*Vp_tab(im1) - off_diagonal_tab(im2)*Vp_tab(im2);
  
      orthogonalization_not_disk (false , i , Vp_tab);
        
      Vp_i.normalization ();
      
      off_diagonal_tab(i-1) = (Vp_i*J2_Vp_im1);

      class GSM_vector &J2_Vp_i = J2_Vp;
      
      J2_Vp_i = J2*Vp_i;

      diagonal_tab(i) = (Vp_i*J2_Vp_i);

      off_diagonal_tab(i) = 0.0; 
    }
}







void Lanczos_GSM_not_disk::J2_projection::J_projected_GSM_vector_calc (
								       const bool is_there_cout_detailed , 
								       const double J ,
								       const unsigned int J_number ,
								       const class J2_class &J2 ,
								       class array<class GSM_vector> &Vp_tab ,   
								       class GSM_vector &PSI)
{
  const bool is_time_considered = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_detailed);
  
  const double reference_time = (is_time_considered) ? (absolute_time_determine ()) : (NADA);
    
  const double J_J_plus_one = J*(J + 1.0);
  
  const class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
  
  const double M = GSM_vector_helper.get_M ();

  const double precision_for_projection = 0.1*precision;
  
  const TYPE PSI_inf_norm = PSI.infinite_norm ();
  
  class array<TYPE> diagonal_tab(J_number);

  class array<TYPE> off_diagonal_tab(J_number);
  
  class array<TYPE> Jc_Jc_plus_one_tab(J_number);
									 
  class GSM_vector &Vp0 = Vp_tab(0);
  
  Vp0.pseudo_random_vector ();
  
  Vp0 *= precision_for_projection*PSI_inf_norm;
  
  Vp0 += PSI;
  
  Vp0.normalization ();
      
  class GSM_vector &J2_Vp = PSI;
  
  tridiagonalization (J_number , J2 , J2_Vp , Vp_tab , diagonal_tab , off_diagonal_tab);
	  
  all_eigenvalues (off_diagonal_tab , diagonal_tab , Jc_Jc_plus_one_tab);
  
  for (unsigned int i = 0 ; i < J_number ; i++)
    {      
      const TYPE Jc_Jc_plus_one = Jc_Jc_plus_one_tab(i);
  
      if (inf_norm (Jc_Jc_plus_one - J_J_plus_one) < 1.9)
	{
	  const class vector_class<TYPE> eigenvector_Lanczos = eigenvector_tridiagonal_calc (Jc_Jc_plus_one , precision , diagonal_tab , off_diagonal_tab);

	  PSI = 0.0;
      
	  for (unsigned int ii = 0 ; ii < J_number ; ii++) PSI += eigenvector_Lanczos(ii)*Vp_tab(ii);
            
	  PSI.good_phase ();
	  
	  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_detailed)
	    {
	      const double now = absolute_time_determine () , relative_time = now - reference_time;
      
	      cout << "J^2 projection applied (Lanczos). time:" << relative_time << " s" << endl;
	    }
	  
	  return;
	}
    }
  
  error_message_print_abort ("J-projection failed using the Lanczos method for J=" + J_string (J) + " and M=" + M_string (M) + " (Lanczos vectors not stored on disk)");
}




