#include "../GSM_include/GSM_include_def.h"

using namespace string_routines;

// TYPE is double or complex
// -------------------------


// Routines of operator overloading used with GSM vectors when only one configuration is occupied in basis space for MSDHF calculations
// ------------------------------------------------------------------------------------------------------------------------------------
// In order to calculate the MSDHF potential, one has to diagonalize H on the MSDHF configuration, as its ground state is used in the HF-like formulas defining the MSDHF potential.
// As only one configuration occurs, it is much more efficient to recode H in this particular case, than to use the full H class of the general case.
//
// The class Op_PSI_closure_str is a closure class, i.e. a wrapper with which all numerical operations are deferred, to deal with Op.Psi, with Op an operator and Psi a GSM vector.
// It allows to avoid intermediates when having Psi = x*(Op0.Psi0) + y*(Op1.Psi1), for example, as, without closure classes,
// 5 temporary vectors would be created, one for Op0.Psi0, one for x*(Op0.Psi0), one for Op1.Psi1, one for y*(Op1.Psi1), and one for the sum.
// Closure classes allow to avoid it, but one has to restrict the number of terms in expression such as (H - E)*PSI0 + J2*PSI1 + ...
// Up to 10 terms (which is CLOSURE_TERMS_MAX in const.h) can be taken into account in the code. As one rarely has more than 3 terms, this is sufficient.
// All the arrays of a Op_PSI_closure_str class then have 10 terms.
// An error message occurs if one has more than 10 terms,
//
// Format of an operator: +/- x.O +/- alpha , +/- O.x +/- alpha , +/- O/x +/- alpha
//                         +/- alpha +/- x.O , +/- alpha +/- O.x , +/- alpha +/- O/x
//
// O operators: H , J2 , Jpm
//
// Products of O operators are not accepted: Jplus.Jminus, H.J2, for example, cannot be handled with overloading.
// alpha has to be zero if |Psi[in]> and |Psi[out]> do not have the same quantum numbers.
// alpha is then not zero only for H , J2.
// For the identity times scalar operator, x is zero by definition, so that the operator is alpha.Id.
// No test is made to check whether x or alpha is equal to zero or not.
// 
// Default values are those of Id: operator is Id, x=0 and alpha=1.
//
// Straightforward routines are not commented.





Op_PSI_one_configuration_closure_str::Op_PSI_one_configuration_closure_str (const unsigned int closure_terms_number_c)
  : closure_terms_number (closure_terms_number_c)
{
  if (closure_terms_number > CLOSURE_TERMS_MAX) error_message_print_abort ("closure_terms_number cannot be larger than CLOSURE_TERMS_MAX=" + make_string<unsigned int> (CLOSURE_TERMS_MAX) + " (GSM_vector_one_configuration)");

  default_values_init ();
}

Op_PSI_one_configuration_closure_str::Op_PSI_one_configuration_closure_str (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure_old)
{
  default_values_init ();

  const unsigned int Op_PSI_closure_old_closure_terms_number = Op_PSI_closure_old.closure_terms_number;

  closure_terms_number = Op_PSI_closure_old_closure_terms_number;

  const enum operator_type *const Op_PSI_closure_old_Op_tab = Op_PSI_closure_old.Op_tab;

  const TYPE *const Op_PSI_closure_old_x_tab = Op_PSI_closure_old.x_tab;
  
  const TYPE *const Op_PSI_closure_old_alpha_tab = Op_PSI_closure_old.alpha_tab;

  const void *const *const Op_PSI_old_ptrs = Op_PSI_closure_old.Op_ptrs;

  const class GSM_vector_one_configuration *const *const PSI_in_old_ptrs = Op_PSI_closure_old.PSI_in_ptrs;

  for (unsigned int index = 0 ; index < closure_terms_number ; index++)
    {
      Op_tab[index] = Op_PSI_closure_old_Op_tab[index];

      x_tab[index] = Op_PSI_closure_old_x_tab[index];

      alpha_tab[index] = Op_PSI_closure_old_alpha_tab[index];

      Op_ptrs[index] = Op_PSI_old_ptrs[index];

      PSI_in_ptrs[index] = PSI_in_old_ptrs[index];
    } 
}



Op_PSI_one_configuration_closure_str::Op_PSI_one_configuration_closure_str (const class GSM_vector_one_configuration &PSI_in)
  : closure_terms_number (1)
{
  default_values_init ();

  Op_tab[0] = IDENTITY;

  x_tab[0] = 0.0;

  alpha_tab[0] = 1.0;

  PSI_in_ptrs[0] = &PSI_in;
}




const class Op_PSI_one_configuration_closure_str & Op_PSI_one_configuration_closure_str::operator = (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure)
{
  default_values_init ();

  const unsigned int Op_PSI_closure_closure_terms_number = Op_PSI_closure.closure_terms_number;

  closure_terms_number = Op_PSI_closure_closure_terms_number;

  const enum operator_type *const Op_PSI_closure_Op_tab = Op_PSI_closure.Op_tab;

  const TYPE *const Op_PSI_closure_x_tab = Op_PSI_closure.x_tab;

  const TYPE *const Op_PSI_closure_alpha_tab = Op_PSI_closure.alpha_tab;

  const void *const *const Op_PSI_closure_Op_ptrs = Op_PSI_closure.Op_ptrs;
  const class GSM_vector_one_configuration *const *const Op_PSI_closure_PSI_in_ptrs = Op_PSI_closure.PSI_in_ptrs;

  for (unsigned int index = 0 ; index < closure_terms_number ; index++)
    {
      Op_tab[index] = Op_PSI_closure_Op_tab[index];

      x_tab[index] = Op_PSI_closure_x_tab[index];

      alpha_tab[index] = Op_PSI_closure_alpha_tab[index];

      Op_ptrs[index] = Op_PSI_closure_Op_ptrs[index];

      PSI_in_ptrs[index] = Op_PSI_closure_PSI_in_ptrs[index];
    } 

  return *this;
}


unsigned int Op_PSI_one_configuration_closure_str::get_closure_terms_number () const
{
  return closure_terms_number;	
}

enum operator_type Op_PSI_one_configuration_closure_str::get_Op (const unsigned int index) const
{
  return Op_tab[index];	
}

TYPE Op_PSI_one_configuration_closure_str::get_x (const unsigned int index) const
{
  return x_tab[index];
}

TYPE Op_PSI_one_configuration_closure_str::get_alpha (const unsigned int index) const
{
  return alpha_tab[index];
}

const class H_one_configuration_class & Op_PSI_one_configuration_closure_str::get_H (const unsigned int index) const
{
  return *(static_cast<const class H_one_configuration_class *> (Op_ptrs[index]));
}

const class Jpm_one_configuration_class & Op_PSI_one_configuration_closure_str::get_Jpm (const unsigned int index) const
{
  return *(static_cast<const class Jpm_one_configuration_class *> (Op_ptrs[index]));
}

const class J2_one_configuration_class & Op_PSI_one_configuration_closure_str::get_J2 (const unsigned int index) const
{
  return *(static_cast<const class J2_one_configuration_class *> (Op_ptrs[index]));
}

const class GSM_vector_one_configuration & Op_PSI_one_configuration_closure_str::get_PSI_in (const unsigned int index) const
{
  return *(PSI_in_ptrs[index]);
}


void Op_PSI_one_configuration_closure_str::default_values_init ()
{
  for (unsigned int index = 0 ; index < CLOSURE_TERMS_MAX ; index++)
    {
      Op_tab[index] = IDENTITY;

      x_tab[index] = 0.0;

      alpha_tab[index] = 1.0;

      Op_ptrs[index] = NULL;

      PSI_in_ptrs[index] = NULL;
    } 
}




void Op_PSI_one_configuration_closure_str::fill_data (
						      const enum operator_type Op , 
						      const TYPE x , 
						      const TYPE alpha , 
						      const void *const Op_ptr , 
						      const class GSM_vector_one_configuration *const PSI_in_ptr , 
						      const unsigned int index)
{
  Op_tab[index] = Op;

  x_tab[index] = x;

  alpha_tab[index] = alpha;

  Op_ptrs[index] = Op_ptr;

  PSI_in_ptrs[index] = PSI_in_ptr;
}




void Op_PSI_one_configuration_closure_str::fill_data (
						      const class Op_PSI_one_configuration_closure_str &Op_PSI_closure , 
						      const unsigned int i , 
						      const unsigned int index)
{
  const enum operator_type *const Op_PSI_closure_Op_tab = Op_PSI_closure.Op_tab;

  const TYPE *const Op_PSI_closure_x_tab = Op_PSI_closure.x_tab;

  const TYPE *const Op_PSI_closure_alpha_tab = Op_PSI_closure.alpha_tab;

  const void *const *const Op_PSI_closure_Op_ptrs = Op_PSI_closure.Op_ptrs;

  const class GSM_vector_one_configuration *const *const Op_PSI_closure_PSI_in_ptrs = Op_PSI_closure.PSI_in_ptrs;

  const enum operator_type Op = Op_PSI_closure_Op_tab[i];

  const TYPE x = Op_PSI_closure_x_tab[i];

  const TYPE alpha = Op_PSI_closure_alpha_tab[i];

  const void *const Op_ptr = Op_PSI_closure_Op_ptrs[i];

  const class GSM_vector_one_configuration *const PSI_in_ptr = Op_PSI_closure_PSI_in_ptrs[i];

  Op_tab[index] = Op;
  
  x_tab[index] = x;

  alpha_tab[index] = alpha;

  Op_ptrs[index] = Op_ptr;

  PSI_in_ptrs[index] = PSI_in_ptr;
}


bool Op_PSI_one_configuration_closure_str::is_it_only_scalar_identity () const
{
  for (unsigned int index = 0 ; index < closure_terms_number ; index++)
    {
      if (Op_tab[index] != IDENTITY) return false;
    }

  return true;
}

void Op_PSI_one_configuration_closure_str::sign_change (const unsigned int index)
{
  x_tab[index] = -x_tab[index];

  alpha_tab[index] = -alpha_tab[index];
}

void Op_PSI_one_configuration_closure_str::global_sign_change ()
{
  for (unsigned int index = 0 ; index < closure_terms_number ; index++) sign_change (index);
}

void Op_PSI_one_configuration_closure_str::factor_multiplication (const unsigned int index , const TYPE &factor)
{
  x_tab[index] *= factor;

  alpha_tab[index] *= factor;
}

void Op_PSI_one_configuration_closure_str::global_factor_multiplication (const TYPE &factor)
{
  for (unsigned int index = 0 ; index < closure_terms_number ; index++) factor_multiplication (index , factor);
}







// GSM_vector_helper_class class reference from closure wrappers
// -------------------------------------------------------------
// When a GSM_vector_helper_class class is demanded, one takes it from an allocated PSI_in vector or operator.
// The GSM_vector_helper_class class must correspond to the out space. Hence, it is GSM_vector_helper_out for non-scalar operators.
// It is the unique GSM_vector_helper_class class if scalar operator classes are used.
// One takes that of PSI_in if identity is used.

const class GSM_vector_helper_one_configuration_class & Op_PSI_one_configuration_closure_str::GSM_vector_helper_determine () const
{
  const enum operator_type Op = Op_tab[0];

  switch (Op)
    {
    case IDENTITY:                    return get_PSI_in (0).get_GSM_vector_helper ();
    case HAMILTONIAN:                 return      get_H (0).get_GSM_vector_helper ();
    case J_PLUS_MINUS:                return    get_Jpm (0).get_GSM_vector_helper_out ();
    case J_SQUARE:                    return     get_J2 (0).get_GSM_vector_helper_M ();

    default: error_message_print_abort ("No operator recognized in Op_PSI_one_configuration_closure_str::GSM_vector_helper_determine");
    }

  return get_PSI_in (0).get_GSM_vector_helper ();
}




// Check if |Psi[out]> is part of the vectors used in the closure
// --------------------------------------------------------------
// If it does, a copy of |Psi[out]> must be used to store the resulting vector before assigning it to the initial PSI_out.

bool Op_PSI_one_configuration_closure_str::is_PSI_out_used (const class GSM_vector_one_configuration &PSI_out) const
{
  const class GSM_vector_one_configuration *const PSI_out_ptr = &PSI_out;

  for (unsigned int index = 0 ; index < closure_terms_number ; index++)
    {
      if (PSI_in_ptrs[index] == PSI_out_ptr) return true;
    }

  return false;
}




// closure application of all operators
// ------------------------------------
// In order to apply (x.Op + alpha).Psi[in], one first checks if x != 0. If x == 0, one just has to multiply alpha by Psi[in] and add it to Psi[out].
// Otherwise, one calculates (Op + alpha/x).Psi[in], one adds it to Psi[out]/x, one multiplies Psi[out]/x by x, so that one has effectively added (x.Op + alpha).Psi[in] to Psi[out].
// If x == 0, one treats alpha = -1,0,1 separately, as they are just sign change, doing nothing, or identity.

void Op_PSI_one_configuration_closure_str::all_Op_PSI_in_calc_add (class GSM_vector_one_configuration &PSI_out) const
{
  for (unsigned int index = 0 ; index < closure_terms_number ; index++)
    {
      const enum operator_type Op = get_Op (index);

      const TYPE &x = get_x (index);

      const TYPE &alpha = get_alpha (index);
	
      if ((x != 0.0) && (Op != IDENTITY))
	{
	  PSI_out /= x;

	  switch (Op)
	    {
	    case HAMILTONIAN:
	      {
		const TYPE &alpha = get_alpha (index);

		const TYPE alpha_over_x = alpha/x;

		const class H_one_configuration_class &H = get_H (index);

		const class GSM_vector_one_configuration &PSI_in = get_PSI_in (index);

		H.apply_add (PSI_in , alpha_over_x , PSI_out);
	      } break;

	    case J_PLUS_MINUS:
	      {
		const class Jpm_one_configuration_class &Jpm = get_Jpm (index);
		
		const class GSM_vector_one_configuration &PSI_in = get_PSI_in (index);

		Jpm.apply_add (PSI_in , PSI_out);
	      } break;

	    case J_SQUARE:
	      {
		const TYPE &alpha = get_alpha (index);

		const TYPE alpha_over_x = alpha/x;

		const class J2_one_configuration_class &J2 = get_J2 (index);
		
		const class GSM_vector_one_configuration &PSI_in = get_PSI_in (index);

		J2.apply_add (PSI_in , alpha_over_x , PSI_out);
	      } break;

	    default: error_message_print_abort ("No operator recognized in GSM_vector_one_configuration::operator =");
	    }

	  PSI_out *= x;
	}	
      else if (alpha != 0.0)
	{
	  const class GSM_vector_one_configuration &PSI_in = get_PSI_in (index);

	  const unsigned int space_dimension = PSI_in.get_space_dimension ();
	  
	  if (alpha == 1.0)
	    {
	      for (unsigned int i = 0 ; i < space_dimension ; i++) PSI_out[i] += PSI_in[i];
	    }
	  else if (alpha == -1.0)
	    {
	      for (unsigned int i = 0 ; i < space_dimension ; i++) PSI_out[i] -= PSI_in[i];
	    }
	  else
	    {
	      for (unsigned int i = 0 ; i < space_dimension ; i++) PSI_out[i] += alpha*PSI_in[i];
	    }
	}
    }
}






class Op_PSI_one_configuration_closure_str operator * (const class H_one_configuration_class &H , const class GSM_vector_one_configuration &PSI_in)
{
  class Op_PSI_one_configuration_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (HAMILTONIAN , 1.0 , 0.0 , &H , &PSI_in , 0);

  return Op_PSI_closure;
}

class Op_PSI_one_configuration_closure_str operator * (const class Jpm_one_configuration_class &Jpm , const class GSM_vector_one_configuration &PSI_in)
{
  class Op_PSI_one_configuration_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (J_PLUS_MINUS , 1.0 , 0.0 , &Jpm , &PSI_in , 0);

  return Op_PSI_closure;
}

class Op_PSI_one_configuration_closure_str operator * (const class J2_one_configuration_class &J2 , const class GSM_vector_one_configuration &PSI_in)
{
  class Op_PSI_one_configuration_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (J_SQUARE , 1.0 , 0.0 , &J2 , &PSI_in , 0);

  return Op_PSI_closure;
}


class Op_PSI_one_configuration_closure_str operator * (const class xH_one_configuration_plus_alpha_str &xH_plus_alpha , const class GSM_vector_one_configuration &PSI_in)
{
  const TYPE &x = xH_plus_alpha.x;
  const TYPE &alpha = xH_plus_alpha.alpha;
  const class H_one_configuration_class &H = xH_plus_alpha.H;

  class Op_PSI_one_configuration_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (HAMILTONIAN , x , alpha , &H , &PSI_in , 0);

  return Op_PSI_closure;
}


class Op_PSI_one_configuration_closure_str operator * (const class xJpm_one_configuration_str &xJpm , const class GSM_vector_one_configuration &PSI_in)
{
  const TYPE &x = xJpm.x;
  const class Jpm_one_configuration_class &Jpm = xJpm.Jpm;

  class Op_PSI_one_configuration_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (J_PLUS_MINUS , x , 0.0 , &Jpm , &PSI_in , 0);

  return Op_PSI_closure;
}


class Op_PSI_one_configuration_closure_str operator * (const class xJ2_one_configuration_plus_alpha_str &xJ2_plus_alpha , const class GSM_vector_one_configuration &PSI_in)
{
  const TYPE &x = xJ2_plus_alpha.x;
  
  const TYPE &alpha = xJ2_plus_alpha.alpha;

  const class J2_one_configuration_class &J2 = xJ2_plus_alpha.J2;

  class Op_PSI_one_configuration_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (J_SQUARE , x , alpha , &J2 , &PSI_in , 0);

  return Op_PSI_closure;
}

class Op_PSI_one_configuration_closure_str Op_PSI_one_configuration_closure_str::operator_times_scalar_identity (
														 const enum operator_type Op , 
														 const TYPE x_Op , 
														 const TYPE alpha_Op ,  
														 const void *const Op_ptr) const
{
  if (!is_it_only_scalar_identity ())
    error_message_print_abort ("One can only multiply an operator by a vector or scalar multiples of vectors in Op_PSI_closure_str::operator_times_scalar_identity.");

  class Op_PSI_one_configuration_closure_str Op_PSI_closure(closure_terms_number);

  for (unsigned int index = 0 ; index < closure_terms_number ; index++)
    {
      const TYPE alpha = alpha_tab[index];

      const TYPE x_Op_alpha =  x_Op*alpha;

      const TYPE alpha_Op_alpha = alpha_Op*alpha;

      const class GSM_vector_one_configuration *const PSI_in_ptr =  PSI_in_ptrs[index];

      Op_PSI_closure.fill_data (Op , x_Op_alpha , alpha_Op_alpha , Op_ptr , PSI_in_ptr , index);
    }

  return Op_PSI_closure;
}

class Op_PSI_one_configuration_closure_str operator * (const class H_one_configuration_class &H , const class Op_PSI_one_configuration_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (HAMILTONIAN , 1.0 , 0.0 , &H);
}

class Op_PSI_one_configuration_closure_str operator * (const class Jpm_one_configuration_class &Jpm , const class Op_PSI_one_configuration_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (J_PLUS_MINUS , 1.0 , 0.0 , &Jpm);
}

class Op_PSI_one_configuration_closure_str operator * (const class J2_one_configuration_class &J2 , const class Op_PSI_one_configuration_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (J_SQUARE , 1.0 , 0.0 , &J2);
}

class Op_PSI_one_configuration_closure_str operator * (const class xH_one_configuration_plus_alpha_str &xH_plus_alpha , const class Op_PSI_one_configuration_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (HAMILTONIAN , xH_plus_alpha.x , xH_plus_alpha.alpha , &xH_plus_alpha.H);
}

class Op_PSI_one_configuration_closure_str operator * (const class xJpm_one_configuration_str &xJpm , const class Op_PSI_one_configuration_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (J_PLUS_MINUS , xJpm.x , 0.0 , &xJpm.Jpm);
}

class Op_PSI_one_configuration_closure_str operator * (const class xJ2_one_configuration_plus_alpha_str &xJ2_plus_alpha , const class Op_PSI_one_configuration_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (J_SQUARE , xJ2_plus_alpha.x , xJ2_plus_alpha.alpha , &xJ2_plus_alpha.J2);
}





class Op_PSI_one_configuration_closure_str operator + (const class GSM_vector_one_configuration &PSI_in)
{
  class Op_PSI_one_configuration_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (IDENTITY , 0.0 , 1.0 , NULL , &PSI_in , 0);

  return Op_PSI_closure;
}

class Op_PSI_one_configuration_closure_str operator - (const class GSM_vector_one_configuration &PSI_in)
{
  class Op_PSI_one_configuration_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (IDENTITY , 0.0 , -1.0 , NULL , &PSI_in , 0);

  return Op_PSI_closure;
}

class Op_PSI_one_configuration_closure_str operator * (const TYPE &alpha , const class GSM_vector_one_configuration &PSI_in)
{	
  class Op_PSI_one_configuration_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (IDENTITY , 0.0 , alpha , NULL , &PSI_in , 0);

  return Op_PSI_closure;
}

class Op_PSI_one_configuration_closure_str operator * (const class GSM_vector_one_configuration &PSI_in , const TYPE &alpha)
{	
  class Op_PSI_one_configuration_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (IDENTITY , 0.0 , alpha , NULL , &PSI_in , 0);

  return Op_PSI_closure;
}

class Op_PSI_one_configuration_closure_str operator / (const class GSM_vector_one_configuration &PSI_in , const TYPE &one_over_alpha)
{
  const TYPE alpha = 1.0/one_over_alpha;

  class Op_PSI_one_configuration_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (IDENTITY , 0.0 , alpha , NULL , &PSI_in , 0);

  return Op_PSI_closure;
}




class Op_PSI_one_configuration_closure_str operator + (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure)
{
  class Op_PSI_one_configuration_closure_str Op_PSI_closure_new = Op_PSI_closure;

  return Op_PSI_closure_new;
}

class Op_PSI_one_configuration_closure_str operator - (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure)
{
  class Op_PSI_one_configuration_closure_str Op_PSI_closure_new = Op_PSI_closure;

  Op_PSI_closure_new.global_sign_change ();

  return Op_PSI_closure_new;
}

class Op_PSI_one_configuration_closure_str operator * (const TYPE &factor , const class Op_PSI_one_configuration_closure_str &Op_PSI_closure)
{
  class Op_PSI_one_configuration_closure_str Op_PSI_closure_new = Op_PSI_closure;

  Op_PSI_closure_new.global_factor_multiplication (factor);

  return Op_PSI_closure_new;
}

class Op_PSI_one_configuration_closure_str operator * (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure , const TYPE &factor)
{
  class Op_PSI_one_configuration_closure_str Op_PSI_closure_new = Op_PSI_closure;

  Op_PSI_closure_new.global_factor_multiplication (factor);

  return Op_PSI_closure_new;
}

class Op_PSI_one_configuration_closure_str operator / (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure , const TYPE &one_over_factor)
{
  const TYPE factor = 1.0/one_over_factor;

  class Op_PSI_one_configuration_closure_str Op_PSI_closure_new = Op_PSI_closure;

  Op_PSI_closure_new.global_factor_multiplication (factor);

  return Op_PSI_closure_new;
}











// Addition or subtraction of two closure wrappers
// -----------------------------------------------
// A new closure relation is created from the addition or subtraction of two closure wrappers.
// "sign" takes care of subtraction, as it is 1 for addition and -1 for subtraction when using operators + or - on two closures 

class Op_PSI_one_configuration_closure_str Op_PSI_closure_add (
							       const int sign , 
							       const class Op_PSI_one_configuration_closure_str &Op_PSI_closure_a , 
							       const class Op_PSI_one_configuration_closure_str &Op_PSI_closure_b)
{
  const unsigned int closure_terms_number_a = Op_PSI_closure_a.get_closure_terms_number ();
  const unsigned int closure_terms_number_b = Op_PSI_closure_b.get_closure_terms_number ();
  
  const unsigned int closure_terms_number_ab = closure_terms_number_a + closure_terms_number_b;

  class Op_PSI_one_configuration_closure_str Op_PSI_closure(closure_terms_number_ab);

  for (unsigned int i = 0 ; i < closure_terms_number_ab ; i++)
    {
      const unsigned int i_ab = (i < closure_terms_number_a) ? (i) : (i - closure_terms_number_a);

      const int sign_ab = (i < closure_terms_number_a) ? (1) : (sign);

      const class Op_PSI_one_configuration_closure_str &Op_PSI_closure_ab = (i < closure_terms_number_a) ? (Op_PSI_closure_a) : (Op_PSI_closure_b);

      Op_PSI_closure.fill_data (Op_PSI_closure_ab , i_ab , i);

      if (sign_ab == -1) Op_PSI_closure.sign_change (i);
    }

  return Op_PSI_closure;
}



class Op_PSI_one_configuration_closure_str operator + (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure_a , const class Op_PSI_one_configuration_closure_str &Op_PSI_closure_b)
{
  return Op_PSI_closure_add (1 , Op_PSI_closure_a , Op_PSI_closure_b);
}


class Op_PSI_one_configuration_closure_str operator - (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure_a , const class Op_PSI_one_configuration_closure_str &Op_PSI_closure_b)
{
  return Op_PSI_closure_add (-1 , Op_PSI_closure_a , Op_PSI_closure_b);
}
















const class GSM_vector_one_configuration & GSM_vector_one_configuration::operator = (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure)
{
  class GSM_vector_one_configuration &PSI_out = *this;

  if (Op_PSI_closure.is_PSI_out_used (PSI_out))
    {
      class GSM_vector_one_configuration PSI_out_copy = PSI_out;

      PSI_out_copy = 0.0;

      Op_PSI_closure.all_Op_PSI_in_calc_add (PSI_out_copy);

      PSI_out = PSI_out_copy;
    }
  else
    {
      PSI_out = 0.0;

      Op_PSI_closure.all_Op_PSI_in_calc_add (PSI_out);
    }

  return PSI_out;
}






class GSM_vector_one_configuration & GSM_vector_one_configuration::operator += (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure)
{
  class GSM_vector_one_configuration &PSI_out = *this;

  if (Op_PSI_closure.is_PSI_out_used (PSI_out))
    {
      class GSM_vector_one_configuration PSI_out_copy = PSI_out;

      Op_PSI_closure.all_Op_PSI_in_calc_add (PSI_out_copy);

      PSI_out = PSI_out_copy;
    }
  else
    {
      Op_PSI_closure.all_Op_PSI_in_calc_add (PSI_out);
    }

  return PSI_out;
}





class GSM_vector_one_configuration & GSM_vector_one_configuration::operator -= (const class Op_PSI_one_configuration_closure_str &Op_PSI_closure)
{
  class GSM_vector_one_configuration &PSI_out = *this;

  if (Op_PSI_closure.is_PSI_out_used (PSI_out))
    {
      class GSM_vector_one_configuration PSI_out_copy = PSI_out;

      PSI_out_copy.opposite ();

      Op_PSI_closure.all_Op_PSI_in_calc_add (PSI_out_copy);

      PSI_out_copy.opposite ();

      PSI_out = PSI_out_copy;
    }
  else
    {
      PSI_out.opposite ();

      Op_PSI_closure.all_Op_PSI_in_calc_add (PSI_out);

      PSI_out.opposite ();
    }

  return PSI_out;
}







// No closures are used here, these are simple overloading operators as they create no intermediates
// -------------------------------------------------------------------------------------------------


const class GSM_vector_one_configuration & GSM_vector_one_configuration::operator = (const class GSM_vector_one_configuration &PSI)
{
  class GSM_vector_one_configuration &PSI_out = *this;

  for (unsigned int i = 0 ; i < space_dimension ; i++) PSI_out[i] = PSI[i];

  return PSI_out;
}


#ifdef TYPEisDOUBLECOMPLEX

const class GSM_vector_one_configuration& GSM_vector_one_configuration::operator = (const complex<double> &x)
{
  class GSM_vector_one_configuration &PSI = *this;

  for (unsigned int i = 0 ; i < space_dimension ; i++) PSI[i] = x;

  return PSI;
}

#endif


const class GSM_vector_one_configuration& GSM_vector_one_configuration::operator = (const double x)
{
  class GSM_vector_one_configuration &PSI = *this;

  for (unsigned int i = 0 ; i < space_dimension ; i++) PSI[i] = x;

  return PSI;
}



class GSM_vector_one_configuration & GSM_vector_one_configuration::operator += (const class GSM_vector_one_configuration &PSI)
{
  class GSM_vector_one_configuration &PSI_out = *this;

  for (unsigned int i = 0 ; i < space_dimension ; i++) PSI_out[i] += PSI[i];

  return PSI_out;
}


class GSM_vector_one_configuration& GSM_vector_one_configuration::operator += (const TYPE &x)
{
  class GSM_vector_one_configuration &PSI = *this;

  for (unsigned int i = 0 ; i < space_dimension ; i++) PSI[i] += x;

  return PSI;
}



class GSM_vector_one_configuration & GSM_vector_one_configuration::operator -= (const class GSM_vector_one_configuration &PSI)
{
  class GSM_vector_one_configuration &PSI_out = *this;

  for (unsigned int i = 0 ; i < space_dimension ; i++) PSI_out[i] -= PSI[i];

  return PSI_out;
}



class GSM_vector_one_configuration& GSM_vector_one_configuration::operator -= (const TYPE &x)
{
  class GSM_vector_one_configuration &PSI = *this;

  for (unsigned int i = 0 ; i < space_dimension ; i++) PSI[i] -= x;

  return PSI;
}




class GSM_vector_one_configuration & GSM_vector_one_configuration::operator *= (const TYPE &x)
{
  class GSM_vector_one_configuration &PSI = *this;

  if (x == 0.0)
    PSI = 0.0;
  else if (x == -1.0)
    PSI.opposite ();
  else if (x != 1.0)
    {
      for (unsigned int i = 0 ; i < space_dimension ; i++) PSI[i] *= x;
    }

  return *this;
}




class GSM_vector_one_configuration & GSM_vector_one_configuration::operator /= (const TYPE &x)
{
  class GSM_vector_one_configuration &PSI = *this;

  if (x == -1.0)
    PSI.opposite ();
  else if (x != 1.0)
    {
      for (unsigned int i = 0 ; i < space_dimension ; i++) PSI[i] /= x;
    }

  return *this;
}

