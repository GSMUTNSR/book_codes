#include "../GSM_include/GSM_include_def.h"

// MPI transfer is sometimes done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

using namespace string_routines;
using namespace rms_radius_one_body_strength_OBMEs;
using namespace correlated_state_routines;


// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// CM means center of mass
// -----------------------

// Calculation of the proton or neutron rms radius one-body strengths of the one-body part of the rms radius <Psi[out] | rms.radius^2(r) | Psi[in]> and for <Psi | rms.radius^2(r) | Psi>
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Proton and neutron squared rms radius are:
//
// Rp^2 = (1/Z) \sum_{p} (\vec{r_p,lab - R_CM})^2
// Rn^2 = (1/N) \sum_{n} (\vec{r_n,lab - R_CM})^2
//
// so that, using COSM coordinates, one obtains, after removing core terms and the two-body terms in Rp^2, Rn^2 (see GSM_rms_radius.cpp):
//
// Rp^2(one-body valence) = \sum_{p val} ((1/Z) - (2/Z) (mp/M) + (mp/M)^2) r_p^2 + \sum_{n val} (mn/M)^2 r_n^2 
// Rn^2(one-body valence) = \sum_{n val} ((1/N) - (2/N) (mn/M) + (mn/M)^2) r_n^2 + \sum_{p val} (mp/M)^2 r_p^2
//
// where mp, mn, M are the masses of proton, neutron and nucleus.
// All constants are included in pre-calculated terms and Rp,Rn and calculated from the CM operator class.
//
// Strengths are defined by replacing radial OBMEs by its integrand, function of r, for all r radii.
//
//
// calc_one_strength
// -----------------
// One calculates the rms radius one-body strength <Psi[out] | rms.radius^2(r) | Psi[in]> for fixed states |Psi[in]> and |Psi[out]> for all r radii.
//
// calc_store_one_strength
// -----------------------
// One calculates the rms radius one-body strength of a fixed state |Psi> <Psi | rms.radius^2(r) | Psi> for all r radii.
// It is stored in disk in a file whose name looks like rms_radius_one_body_strength_0+_0.dat .
//
// calc_store
// ----------
// Eigenvectors are read from disk and calc_store_one_state is called for the rms radius one-body strength associated to these eigenvectors.

void rms_radius_one_body_strength::calc_one_strength (
						      const enum particle_type particle ,
						      const bool is_it_Gauss_Legendre ,
						      class GSM_vector &PSI_full , 
						      const class GSM_vector &PSI_IN ,
						      const class GSM_vector &PSI_OUT , 
						      class array<TYPE> &rms_radius_one_body_strength_tab)
{
  const enum operator_type rms_radius_operator = rms_radius_operator_determine (particle);
  
  class GSM_vector_helper_class &PSI_helper_IN  = PSI_IN.get_GSM_vector_helper ();
  class GSM_vector_helper_class &PSI_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
 
  const class baryons_data &prot_Y_data = PSI_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = PSI_helper_OUT.get_neut_Y_data ();

  const enum space_type space = PSI_helper_OUT.get_space ();
  
  const int S = prot_Y_data.get_hypernucleus_strangeness ();
  
  const unsigned int Np_nljm = prot_Y_data.get_N_nljm_baryon ();
  const unsigned int Nn_nljm = neut_Y_data.get_N_nljm_baryon ();

  const unsigned int N_bef_R_GL = prot_Y_data.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = prot_Y_data.get_N_bef_R_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const int s = particle_strangeness_determine (particle);
    
  const int Z = prot_Y_data.get_N_nucleons () , Zmin = max (Z - S , 0) , Zmax = Z + S;
  const int N = neut_Y_data.get_N_nucleons () , Nmin = max (N - S , 0) , Nmax = N + S;

  const int N_nucleons_min = (particle == PROTON) ? (Zmin) : (Nmin) , N_particle_min = (s == 0) ? (N_nucleons_min) : (0);
  const int N_nucleons_max = (particle == PROTON) ? (Zmax) : (Nmax) , N_particle_max = (s == 0) ? (N_nucleons_max) : (S/s);
            
  const double M = prot_Y_data.get_total_nucleus_mass ();
  
  class array<TYPE> OBMEs_p(Np_nljm , Np_nljm , Nr);
  class array<TYPE> OBMEs_n(Nn_nljm , Nn_nljm , Nr);

  class array<TYPE> rms_radius_one_body_strength_p_tab(Nr);
  class array<TYPE> rms_radius_one_body_strength_n_tab(Nr);
      
  class GSM_vector PSI_IN_N_particle_fixed;
      
  if (S != 0) PSI_IN_N_particle_fixed.allocate (PSI_helper_IN);

  rms_radius_one_body_strength_tab = 0.0;
  
  for (int N_particle = N_particle_min ; N_particle <= N_particle_max ; N_particle++)
    {
      if (space != NEUT_Y_ONLY) OBMEs_calc (rms_radius_operator , M , N_particle , is_it_Gauss_Legendre , prot_Y_data , OBMEs_p);  
      if (space != PROT_Y_ONLY) OBMEs_calc (rms_radius_operator , M , N_particle , is_it_Gauss_Legendre , neut_Y_data , OBMEs_n);
  
      rms_radius_one_body_strength_p_tab = 0.0;
      rms_radius_one_body_strength_n_tab = 0.0;
  
      if (S == 0)
	scalar_strength::calc (PSI_full , OBMEs_p , OBMEs_n , PSI_IN , PSI_OUT , rms_radius_one_body_strength_p_tab , rms_radius_one_body_strength_n_tab);
      else
	{
	  PSI_IN_N_particle_fixed = PSI_IN;

	  PSI_IN_N_particle_fixed.fixed_particle_type_number_impose_normalize (particle , N_particle);

	  const double PSI_IN_N_particle_fixed_infinite_norm = PSI_IN_N_particle_fixed.infinite_norm ();

	  if (PSI_IN_N_particle_fixed_infinite_norm > 0) scalar_strength::calc (PSI_full , OBMEs_p , OBMEs_n , PSI_IN , PSI_OUT , rms_radius_one_body_strength_p_tab , rms_radius_one_body_strength_n_tab);
	}
      
      rms_radius_one_body_strength_tab += rms_radius_one_body_strength_p_tab + rms_radius_one_body_strength_n_tab;
    }
}





void rms_radius_one_body_strength::calc_store_one_strength (
							    const enum particle_type particle ,
							    const bool is_it_Gauss_Legendre ,
							    const class array<double> &r_bef_R_tab ,
							    class GSM_vector &PSI_full , 
							    const class correlated_state_str &PSI_qn , 
							    const class GSM_vector &PSI)
{
  const enum operator_type rms_radius_operator = rms_radius_operator_determine (particle);
  
  const class GSM_vector_helper_class &PSI_helper = PSI.get_GSM_vector_helper ();
  
  const class baryons_data &prot_Y_data = PSI_helper.get_prot_Y_data ();
  
  const unsigned int N_bef_R_GL = prot_Y_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = prot_Y_data.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  class array<TYPE> rms_radius_one_body_strength(Nr);

  calc_one_strength (particle , is_it_Gauss_Legendre , PSI_full , PSI , PSI , rms_radius_one_body_strength);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      const string PSI_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_qn);

      const string rms_radius_one_body_strength_string = operator_type_string_for_file_name (rms_radius_operator) + "_one_body_strength_" + PSI_qn_string + ".dat";
      
      ofstream rms_radius_one_body_strength_file(rms_radius_one_body_strength_string.c_str () , ios::out);

      rms_radius_one_body_strength_file.precision (15);

      for (unsigned int i = 0 ; i < Nr ; i++)
	{
	  const double r = r_bef_R_tab(i);

#ifdef TYPEisDOUBLECOMPLEX
	  rms_radius_one_body_strength_file << r << " " << real (rms_radius_one_body_strength(i)) << " " << imag (rms_radius_one_body_strength(i)) << endl;
#endif

#ifdef TYPEisDOUBLE
	  rms_radius_one_body_strength_file << r << " " << rms_radius_one_body_strength(i) << endl;
#endif
	}

      rms_radius_one_body_strength_file.close ();
    }
}



void rms_radius_one_body_strength::calc_store (
					       const class input_data_str &input_data , 
					       const class array<class correlated_state_str> &PSI_qn_tab ,
					       class baryons_data &prot_Y_data , 
					       class baryons_data &neut_Y_data ,
					       class GSM_vector &PSI_full) 
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "rms radius one-body strengths" << endl;
      cout <<         "-----------------------------" << endl << endl;
    }

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();

  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();

  const int Z = prot_Y_data.get_N_nucleons ();
  const int N = neut_Y_data.get_N_nucleons ();

  const int S = prot_Y_data.get_hypernucleus_strangeness ();
  
  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
  
  const unsigned int rms_radius_one_body_strength_number = input_data.get_rms_radius_one_body_strength_number ();

  const class array<unsigned int> &rms_radius_one_body_strength_BP_tab = input_data.get_rms_radius_one_body_strength_BP_tab ();

  const class array<double> &rms_radius_one_body_strength_J_tab = input_data.get_rms_radius_one_body_strength_J_tab ();

  const class array<unsigned int> &rms_radius_one_body_strength_vector_index_tab = input_data.get_rms_radius_one_body_strength_vector_index_tab ();

  const class array<enum particle_type> &rms_radius_one_body_strength_particle_tab = input_data.get_rms_radius_one_body_strength_particle_tab ();

  const class array<bool> &rms_radius_one_body_strength_is_it_Gauss_Legendre_tab = input_data.get_rms_radius_one_body_strength_is_it_Gauss_Legendre_tab ();

  const unsigned int N_bef_R_GL = input_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = input_data.get_N_bef_R_uniform ();

  const double R = input_data.get_R ();

  const double step_bef_R_uniform = input_data.get_step_bef_R_uniform ();

  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);

  class array<double> r_bef_R_tab_uniform(N_bef_R_uniform);

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;

  for (unsigned int rms_radius_one_body_strength_index = 0 ; rms_radius_one_body_strength_index < rms_radius_one_body_strength_number ; rms_radius_one_body_strength_index++)
    {
      const enum particle_type particle = rms_radius_one_body_strength_particle_tab[rms_radius_one_body_strength_index];

      const bool is_it_Gauss_Legendre = rms_radius_one_body_strength_is_it_Gauss_Legendre_tab[rms_radius_one_body_strength_index];

      const unsigned int BP = rms_radius_one_body_strength_BP_tab[rms_radius_one_body_strength_index];

      const unsigned int vector_index = rms_radius_one_body_strength_vector_index_tab[rms_radius_one_body_strength_index];

      const double J = rms_radius_one_body_strength_J_tab[rms_radius_one_body_strength_index] , M = J;

      const class correlated_state_str PSI_qn = PSI_quantum_numbers_find (Z , N , BP , S , J , vector_index , PSI_qn_tab);

      class GSM_vector_helper_class PSI_helper(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
					       n_holes_max   , n_scat_max   , E_max_hw  ,
					       n_holes_max_p , n_scat_max_p , Ep_max_hw ,
					       n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , true , prot_Y_data , neut_Y_data);

      class GSM_vector PSI(PSI_helper);

      PSI.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);

      const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (r_bef_R_tab_GL) : (r_bef_R_tab_uniform);

      calc_store_one_strength (particle , is_it_Gauss_Legendre , r_bef_R_tab , PSI_full , PSI_qn , PSI);

      if (THIS_PROCESS == MASTER_PROCESS) cout << "particle : " << particle << " rms radius one-body strength of " << J_Pi_vector_index_string (BP , J , vector_index) << " calculated" << endl;
    }
}


