#include "../GSM_include/GSM_include_def.h"

// MPI transfer is sometimes done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

using namespace string_routines;
using namespace rms_radius_one_body_strength_OBMEs;
using namespace correlated_state_routines;


// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// CM means center of mass
// -----------------------

// Calculation of the proton or neutron rms radius one-body strengths of the one-body part of the rms radius <Psi[out] | rms.radius^2(r) | Psi[in]> and for <Psi | rms.radius^2(r) | Psi>
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Proton and neutron squared rms radius are:
//
// Rp^2 = (1/Z) \sum_{p} (\vec{r_p,lab - R_CM})^2
// Rn^2 = (1/N) \sum_{n} (\vec{r_n,lab - R_CM})^2
//
// so that, using COSM coordinates, one obtains, after removing core terms and the two-body terms in Rp^2, Rn^2 (see GSM_rms_radius.cpp):
//
// Rp^2(one-body valence) = \sum_{p val} ((1/Z) - (2/Z) (mp/M) + (mp/M)^2) r_p^2 + \sum_{n val} (mn/M)^2 r_n^2 
// Rn^2(one-body valence) = \sum_{n val} ((1/N) - (2/N) (mn/M) + (mn/M)^2) r_n^2 + \sum_{p val} (mp/M)^2 r_p^2
//
// where mp, mn, M are the masses of proton, neutron and nucleus.
// All constants are included in pre-calculated terms and Rp,Rn and calculated from the CM operator class.
//
// Strengths are defined by replacing radial OBMEs by its integrand, function of r, for all r radii.
//
//
// calc_one_strength
// -----------------
// One calculates the rms radius one-body strength <Psi[out] | rms.radius^2(r) | Psi[in]> for fixed states |Psi[in]> and |Psi[out]> for all r radii.
//
// calc_store_one_strength
// -----------------------
// One calculates the rms radius one-body strength of a fixed state |Psi> <Psi | rms.radius^2(r) | Psi> for all r radii.
// It is stored in disk in a file whose name looks like rms_radius_one_body_strength_0+_0.dat .
//
// calc_store
// ----------
// Eigenvectors are read from disk and calc_store_one_state is called for the rms radius one-body strength associated to these eigenvectors.

void rms_radius_one_body_strength::calc_one_strength (
						      const enum operator_type rms_radius_operator , 
						      const bool is_it_Gauss_Legendre ,
						      class GSM_vector &PSI_full , 
						      const class GSM_vector &PSI_IN ,
						      const class GSM_vector &PSI_OUT ,   
						      class nucleons_data &prot_data , 
						      class nucleons_data &neut_data ,  
						      class array<TYPE> &rms_radius_one_body_strength_tab)
{
  const class GSM_vector_helper_class &PSI_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
      
  const class GSM_vector_helper_class dummy_helper;
 
  const enum space_type space = PSI_helper_OUT.get_space ();
    
  const unsigned int Np_nljm = prot_data.get_N_nljm ();
  const unsigned int Nn_nljm = neut_data.get_N_nljm ();

  const unsigned int N_bef_R_GL = prot_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = prot_data.get_N_bef_R_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const int Z = prot_data.get_N_nucleons ();
  const int N = neut_data.get_N_nucleons ();
  
  const double mp = prot_data.get_effective_mass_for_calc ();
  const double mn = neut_data.get_effective_mass_for_calc ();
    
  class array<TYPE> OBMEs_prot(Np_nljm , Np_nljm , Nr);
  class array<TYPE> OBMEs_neut(Nn_nljm , Nn_nljm , Nr);

  if (space != NEUTRONS_ONLY)
    {
      const double factor_prot = rms_radius_one_body_factor_calc (rms_radius_operator , PROTON , mp , mn , Z , N);
  
      OBMEs_calc (factor_prot , is_it_Gauss_Legendre , prot_data , OBMEs_prot);
    }
  
  if (space != PROTONS_ONLY)
    {
      const double factor_neut = rms_radius_one_body_factor_calc (rms_radius_operator , NEUTRON , mp , mn , Z , N);
  
      OBMEs_calc (factor_neut , is_it_Gauss_Legendre , neut_data , OBMEs_neut);
    }
  
  class array<TYPE> prot_rms_radius_one_body_strength_tab(Nr);
  class array<TYPE> neut_rms_radius_one_body_strength_tab(Nr);
 
  scalar_strength::calc (PSI_full , OBMEs_prot , OBMEs_neut , PSI_IN , PSI_OUT , prot_rms_radius_one_body_strength_tab , neut_rms_radius_one_body_strength_tab);

  rms_radius_one_body_strength_tab = prot_rms_radius_one_body_strength_tab + neut_rms_radius_one_body_strength_tab;
}





void rms_radius_one_body_strength::calc_store_one_strength (
							    const enum operator_type rms_radius_operator , 
							    const bool is_it_Gauss_Legendre ,
							    const class array<double> &r_bef_R_tab ,
							    class nucleons_data &prot_data , 
							    class nucleons_data &neut_data ,  
							    class GSM_vector &PSI_full , 
							    const class correlated_state_str &PSI_qn , 
							    const class GSM_vector &PSI)
{
  const unsigned int N_bef_R_GL = prot_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = prot_data.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  class array<TYPE> rms_radius_one_body_strength(Nr);

  calc_one_strength (rms_radius_operator , is_it_Gauss_Legendre , PSI_full , PSI , PSI , prot_data , neut_data , rms_radius_one_body_strength);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      const string PSI_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_qn);

      const string particle_str = (rms_radius_operator == RMS_RADIUS_PROTON) ? ("proton") : ("neutron");

      const string rms_radius_one_body_strength_string = "rms_radius_one_body_strength_" + particle_str + "_" + PSI_qn_string + ".dat";

      ofstream rms_radius_one_body_strength_file(rms_radius_one_body_strength_string.c_str() , ios::out);

      rms_radius_one_body_strength_file.precision (15);

      for (unsigned int i = 0 ; i < Nr ; i++)
	{
	  const double r = r_bef_R_tab(i);

#ifdef TYPEisDOUBLECOMPLEX
	  rms_radius_one_body_strength_file << r << " " << real (rms_radius_one_body_strength(i)) << " " << imag (rms_radius_one_body_strength(i)) << endl;
#endif

#ifdef TYPEisDOUBLE
	  rms_radius_one_body_strength_file << r << " " << rms_radius_one_body_strength(i) << endl;
#endif
	}

      rms_radius_one_body_strength_file.close ();
    }
}



void rms_radius_one_body_strength::calc_store (
					       const class input_data_str &input_data , 
					       const class array<class correlated_state_str> &PSI_qn_tab ,
					       class nucleons_data &prot_data , 
					       class nucleons_data &neut_data ,
					       class GSM_vector &PSI_full) 
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "rms radius one-body strengths" << endl;
      cout <<         "-----------------------------" << endl << endl;
    }

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();

  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const int n_holes_max_p = prot_data.get_n_holes_max ();
  const int n_holes_max_n = neut_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_data.get_n_scat_max ();
  const int n_scat_max_n = neut_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_data.get_E_max_hw ();
  const int En_max_hw = neut_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();

  const int Z = prot_data.get_N_nucleons ();
  const int N = neut_data.get_N_nucleons ();

  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
  
  const unsigned int rms_radius_one_body_strength_number = input_data.get_rms_radius_one_body_strength_number ();

  const class array<unsigned int> &rms_radius_one_body_strength_BP_tab = input_data.get_rms_radius_one_body_strength_BP_tab ();

  const class array<double> &rms_radius_one_body_strength_J_tab = input_data.get_rms_radius_one_body_strength_J_tab ();

  const class array<unsigned int> &rms_radius_one_body_strength_vector_index_tab = input_data.get_rms_radius_one_body_strength_vector_index_tab ();

  const class array<enum particle_type> &rms_radius_one_body_strength_particle_tab = input_data.get_rms_radius_one_body_strength_particle_tab ();

  const class array<bool> &rms_radius_one_body_strength_is_it_Gauss_Legendre_tab = input_data.get_rms_radius_one_body_strength_is_it_Gauss_Legendre_tab ();

  const unsigned int N_bef_R_GL = input_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = input_data.get_N_bef_R_uniform ();

  const double R = input_data.get_R ();

  const double step_bef_R_uniform = input_data.get_step_bef_R_uniform ();

  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);

  class array<double> r_bef_R_tab_uniform(N_bef_R_uniform);

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;

  for (unsigned int rms_radius_one_body_strength_index = 0 ; rms_radius_one_body_strength_index < rms_radius_one_body_strength_number ; rms_radius_one_body_strength_index++)
    {
      const enum particle_type particle = rms_radius_one_body_strength_particle_tab[rms_radius_one_body_strength_index];

      const enum operator_type rms_radius_operator = rms_radius_operator_determine (particle);

      const bool is_it_Gauss_Legendre = rms_radius_one_body_strength_is_it_Gauss_Legendre_tab[rms_radius_one_body_strength_index];

      const unsigned int BP = rms_radius_one_body_strength_BP_tab[rms_radius_one_body_strength_index];

      const unsigned int vector_index = rms_radius_one_body_strength_vector_index_tab[rms_radius_one_body_strength_index];

      const double J = rms_radius_one_body_strength_J_tab[rms_radius_one_body_strength_index] , M = J;

      const class correlated_state_str PSI_qn = PSI_quantum_numbers_find (Z , N , BP , J , vector_index , PSI_qn_tab);

      class GSM_vector_helper_class PSI_helper(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
					       n_holes_max   , n_scat_max   , E_max_hw  ,
					       n_holes_max_p , n_scat_max_p , Ep_max_hw ,
					       n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , true , prot_data , neut_data);

      class GSM_vector PSI(PSI_helper);

      PSI.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);

      const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (r_bef_R_tab_GL) : (r_bef_R_tab_uniform);

      calc_store_one_strength (rms_radius_operator , is_it_Gauss_Legendre , r_bef_R_tab , prot_data , neut_data , PSI_full , PSI_qn , PSI);

      if (THIS_PROCESS == MASTER_PROCESS) cout << "particle : " << particle << " rms radius one-body strength of " << J_Pi_vector_index_string (BP , J , vector_index) << " calculated" << endl;
    }
}


