#include "../GSM_include/GSM_include_def.h"


using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace MPI_2D_partitioning;

// TYPE is double or complex
// -------------------------


// NBMEs means N-body matrix elements
// ----------------------------------

// See GSM_cluster_HO_to_Berggren_class.h for definitions. Routines here are rather straightforward so that no details are provided, only general explanations
// -----------------------------------------------------------------------------------------------------------------------------------------------------------


// Class x_cluster_HO_to_Berggren_str is used only in closures and then is not commented.



// Class converting a GSM vector defined in a one-body HO basis to a one-body Berggren basis
// -----------------------------------------------------------------------------------------
// One uses overlaps of the form <SD-Berggren | SD-HO> for it (see GSM_cluster_SD_HO_Berggren_overlaps.cpp for their calculation):
//
// |Psi-HO> = \sum_{SD-HO} c_{SD-HO} |SD-HO> => cluster_HO_to_Berggren |Psi-HO> = \sum_{SD-HO , SD-Berggren} c_{SD-HO} <SD-Berggren | SD-HO> |SD-Berggren>.
// The cluster_HO_to_Berggren operator is stored in the class as a sparse matrix or applied on the fly.
// Indeed, <SD-Berggren | SD-HO> is not zero only if the angular parts of its reordered proton and neutron one-body states are equal.
// Time-reversal summetry (TRS) is used if both |Psi-HO> and cluster_HO_to_Berggren |Psi-HO> states have M=0.
//
// This routine is used to calculate cluster projectile wave functions from the HO basis to the Berggren basis for GSM-CC.
//
// Allocators, deallocators, class NBMEs print, memory use, apply routine and operator overloading routines are defined here
//
// One can print NBMEs along with their in and out Slater determinants.




cluster_HO_to_Berggren_class::cluster_HO_to_Berggren_class () :
  storage (NO_STORAGE) ,
  J (0.0) ,
  total_space_dimension_non_zeros (0) ,
  cluster_data_ptr (NULL) ,
  GSM_vector_helper_HO_ptr (NULL) ,
  GSM_vector_helper_ptr (NULL) ,
  PSI_HO_part_table_ptr (NULL)
{}





cluster_HO_to_Berggren_class::cluster_HO_to_Berggren_class (
							    const bool is_there_cout ,
							    const enum storage_type storage_c ,
							    const double J_c , 
							    const class cluster_data &data , 
							    class GSM_vector_helper_class &GSM_vector_helper_HO ,
							    class GSM_vector_helper_class &GSM_vector_helper) :
  storage (NO_STORAGE) ,
  J (0.0) ,
  total_space_dimension_non_zeros (0) ,
  cluster_data_ptr (NULL) ,
  GSM_vector_helper_HO_ptr (NULL) ,
  GSM_vector_helper_ptr (NULL) ,
  PSI_HO_part_table_ptr (NULL)
{
  allocate (is_there_cout , storage_c , J_c , data , GSM_vector_helper_HO , GSM_vector_helper);
}



cluster_HO_to_Berggren_class::cluster_HO_to_Berggren_class (
							    const bool is_there_cout ,
							    const enum storage_type storage_c , 
							    const double J_c , 
							    const class cluster_data &data , 
							    class GSM_vector_helper_class &GSM_vector_helper_HO , 
							    class GSM_vector_helper_class &GSM_vector_helper , 
							    class array<class GSM_vector> &PSI_HO_part_table) :
  storage (NO_STORAGE) ,
  J (0.0) ,
  total_space_dimension_non_zeros (0) ,
  cluster_data_ptr (NULL) , 
  GSM_vector_helper_HO_ptr (NULL) ,
  GSM_vector_helper_ptr (NULL) ,
  PSI_HO_part_table_ptr (NULL)
{
  allocate (is_there_cout , storage_c , J_c , data , GSM_vector_helper_HO , GSM_vector_helper , PSI_HO_part_table);
}



cluster_HO_to_Berggren_class::cluster_HO_to_Berggren_class (const class cluster_HO_to_Berggren_class &X) :
  storage (NO_STORAGE) ,
  J (0.0) ,
  total_space_dimension_non_zeros (0) ,
  cluster_data_ptr (NULL) , 
  GSM_vector_helper_HO_ptr (NULL) ,
  GSM_vector_helper_ptr (NULL) ,
  PSI_HO_part_table_ptr (NULL)
{
  allocate_fill (X);
}




cluster_HO_to_Berggren_class::~cluster_HO_to_Berggren_class () {}








void cluster_HO_to_Berggren_class::allocate (
					     const bool is_there_cout ,
					     const enum storage_type storage_c ,
					     const double J_c , 
					     const class cluster_data &data , 
					     class GSM_vector_helper_class &GSM_vector_helper_HO ,
					     class GSM_vector_helper_class &GSM_vector_helper)
{

  if (is_it_filled ()) error_message_print_abort ("cluster_HO_to_Berggren_class cannot be allocated twice in cluster_HO_to_Berggren_class::allocate");

  if (GSM_vector_helper_HO.get_total_space_dimension () == 0) return;
  
  const unsigned int total_space_dimension_out = GSM_vector_helper.get_total_space_dimension ();
  
  if (total_space_dimension_out == 0) return;
  
  storage = storage_c;

  J = J_c;

  cluster_data_ptr = &data;
    
  GSM_vector_helper_HO_ptr = &GSM_vector_helper_HO;

  GSM_vector_helper_ptr = &GSM_vector_helper;

  if (storage == FULL_STORAGE)
    {
      non_zero_overlaps_numbers.allocate (total_space_dimension_out);

      non_zero_overlaps_numbers_calc_store ();

      total_space_dimension_non_zeros = 0;
     
      non_zero_overlaps_PSI_HO_indices_tab.allocate (total_space_dimension_out);

      non_zero_overlaps_tab.allocate (total_space_dimension_out);
 
      for (unsigned int total_PSI_out_index = 0 ; total_PSI_out_index < total_space_dimension_out ; total_PSI_out_index++)
	{
	  const unsigned int non_zero_overlaps_number = non_zero_overlaps_numbers(total_PSI_out_index);
	      
	  if (non_zero_overlaps_number > 0)
	    {
	      non_zero_overlaps_PSI_HO_indices_tab(total_PSI_out_index).allocate (non_zero_overlaps_number);
	      
	      non_zero_overlaps_tab(total_PSI_out_index).allocate (non_zero_overlaps_number);
	      
	      total_space_dimension_non_zeros++;
	    }
	}
      
      total_PSI_indices_non_zeros.allocate (total_space_dimension_non_zeros);
      
      total_space_dimension_non_zeros = 0;
      	  
      for (unsigned int total_PSI_index = 0 ; total_PSI_index < total_space_dimension_out ; total_PSI_index++)
	{
	  const unsigned int non_zero_overlaps_number = non_zero_overlaps_numbers(total_PSI_index);
	      
	  if (non_zero_overlaps_number > 0) total_PSI_indices_non_zeros(total_space_dimension_non_zeros++) = total_PSI_index;
	}
    
      matrix_store ();
    }
  
  if (is_there_cout)
    {
      const double used_memory_process = used_memory_calc (*this);
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << "Cluster HO to Berggren memory used for a process:" << used_memory_process << " Mb" << endl;
    }
}




void cluster_HO_to_Berggren_class::allocate (
					     const bool is_there_cout , 
					     const enum storage_type storage_c , 
					     const double J_c , 
					     const class cluster_data &data , 
					     class GSM_vector_helper_class &GSM_vector_helper_HO , 
					     class GSM_vector_helper_class &GSM_vector_helper , 
					     class array<class GSM_vector> &PSI_HO_part_table)
{
  if (is_it_filled ()) error_message_print_abort ("cluster_HO_to_Berggren_class cannot be allocated twice in cluster_HO_to_Berggren_class::allocate");
    
  PSI_HO_part_table_ptr = &PSI_HO_part_table;
  
  allocate (is_there_cout , storage_c , J_c , data , GSM_vector_helper_HO , GSM_vector_helper);
}
















void cluster_HO_to_Berggren_class::allocate_fill (const class cluster_HO_to_Berggren_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("cluster_HO_to_Berggren_class cannot be allocated twice in cluster_HO_to_Berggren_class::allocate_fill");

  storage = X.storage;

  J = X.J;

  total_space_dimension_non_zeros = X.total_space_dimension_non_zeros;

  cluster_data_ptr = X.cluster_data_ptr;
    
  GSM_vector_helper_HO_ptr = X.GSM_vector_helper_HO_ptr;

  GSM_vector_helper_ptr = X.GSM_vector_helper_ptr;
  
  PSI_HO_part_table_ptr = X.PSI_HO_part_table_ptr;
  	
  total_PSI_indices_non_zeros.allocate_fill (X.total_PSI_indices_non_zeros);
  
  non_zero_overlaps_numbers.allocate_fill (X.non_zero_overlaps_numbers);
      
  non_zero_overlaps_PSI_HO_indices_tab.allocate_fill (X.non_zero_overlaps_PSI_HO_indices_tab);

  non_zero_overlaps_tab.allocate_fill (X.non_zero_overlaps_tab);
}






void cluster_HO_to_Berggren_class::deallocate ()
{
  total_PSI_indices_non_zeros.deallocate ();
  
  non_zero_overlaps_numbers.deallocate ();

  non_zero_overlaps_PSI_HO_indices_tab.deallocate ();

  non_zero_overlaps_tab.deallocate ();
  
  storage = NO_STORAGE;

  J = 0.0;

  total_space_dimension_non_zeros = 0;
  
  cluster_data_ptr = NULL; 
    
  GSM_vector_helper_HO_ptr = NULL;

  GSM_vector_helper_ptr = NULL;
  
  PSI_HO_part_table_ptr = NULL;
}






double used_memory_calc (const class cluster_HO_to_Berggren_class &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;
  
  const double used_memory_allocated_arrays = used_memory_calc (T.non_zero_overlaps_numbers) +
    used_memory_calc (T.total_PSI_indices_non_zeros) +
    used_memory_calc (T.non_zero_overlaps_PSI_HO_indices_tab) +
    used_memory_calc (T.non_zero_overlaps_tab)
    - (sizeof (T.non_zero_overlaps_numbers) +
       sizeof (T.total_PSI_indices_non_zeros) +
       sizeof (T.non_zero_overlaps_PSI_HO_indices_tab) +
       sizeof (T.non_zero_overlaps_tab))/1000000.0;
    
  const double used_memory = used_memory_constants + used_memory_allocated_arrays;
  
  return used_memory;
}







void cluster_HO_to_Berggren_class::print () const
{
  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Only serial processes allowed for the use of print of cluster_HO_to_Berggren_class.");
  
  if (storage != FULL_STORAGE) error_message_print_abort ("Full storage option must be used in print of cluster_HO_to_Berggren_class.");

  class GSM_vector_helper_class &GSM_vector_helper    = get_GSM_vector_helper ();
  class GSM_vector_helper_class &GSM_vector_helper_HO = get_GSM_vector_helper_HO ();

  const enum space_type space = GSM_vector_helper.get_space (); 

  const class cluster_data &cluster_data = get_cluster_data ();
  
  const class baryons_data &cluster_prot_Y_data = cluster_data.get_cluster_prot_Y_data (); 
  const class baryons_data &cluster_neut_Y_data = cluster_data.get_cluster_neut_Y_data ();
  
  const class baryons_data &cluster_prot_Y_data_HO = cluster_data.get_cluster_prot_Y_data_HO (); 
  const class baryons_data &cluster_neut_Y_data_HO = cluster_data.get_cluster_neut_Y_data_HO ();
  
  const unsigned int total_space_dimension = GSM_vector_helper.get_total_space_dimension ();

  const class array<class nljm_struct> &phi_p_table = cluster_prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = cluster_neut_Y_data.get_phi_table ();

  const class array<class nljm_struct> &phi_p_table_HO = cluster_prot_Y_data_HO.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table_HO = cluster_neut_Y_data_HO.get_phi_table ();

  const class Slater_determinant dummy_SD;
  
  const class GSM_vector V_HO(GSM_vector_helper_HO);

  const class GSM_vector V(GSM_vector_helper);

  for (unsigned int PSI_index = 0 ; PSI_index < total_space_dimension ; PSI_index++)
    {
      const class Slater_determinant SDp = (space != NEUT_Y_ONLY) ? (V.basis_SD_from_index (PROT_Y_ONLY , PSI_index)) : (dummy_SD);
      const class Slater_determinant SDn = (space != PROT_Y_ONLY) ? (V.basis_SD_from_index (NEUT_Y_ONLY , PSI_index)) : (dummy_SD);

      const unsigned int square_non_zero_overlaps_number = non_zero_overlaps_numbers(PSI_index);

      const class array<unsigned int> &non_zero_overlaps_PSI_HO_indices = non_zero_overlaps_PSI_HO_indices_tab(PSI_index);

      const class array<TYPE> &non_zero_overlaps = non_zero_overlaps_tab(PSI_index);
  
      for (unsigned int i = 0 ; i < square_non_zero_overlaps_number ; i++) 
	{
	  const unsigned int PSI_HO_index = non_zero_overlaps_PSI_HO_indices(i);
	  
	  const TYPE &overlap = non_zero_overlaps(i);

	  const class Slater_determinant SDp_HO = (space != NEUT_Y_ONLY) ? (V_HO.basis_SD_from_index (PROT_Y_ONLY , PSI_HO_index)) : (dummy_SD);
	  const class Slater_determinant SDn_HO = (space != PROT_Y_ONLY) ? (V_HO.basis_SD_from_index (NEUT_Y_ONLY , PSI_HO_index)) : (dummy_SD);

	  switch (space)
	    {
	    case PROT_Y_ONLY: 
	      {
		cout << "SD[HO]: " , SDp_HO.print (phi_p_table_HO);

		cout << "SD: " , SDp.print (phi_p_table);
	      } break;

	    case NEUT_Y_ONLY:
	      {
		cout << "SD[HO]: " , SDn_HO.print (phi_n_table_HO);

		cout << "SD: " , SDn.print (phi_n_table);
	      } break;

	    case PROT_NEUT_Y:
	      {
		cout << "SDp[HO]: " , SDp_HO.print (phi_p_table_HO);
		cout << "SDn[HO]: " , SDn_HO.print (phi_n_table_HO);
		
		cout << "SDp: " , SDp.print (phi_p_table);
		cout << "SDn: " , SDn.print (phi_n_table);
	      } break;

	    default: abort_all ();
	    }

	  cout << "SD[HO] index: " << PSI_HO_index << " SD index: " << PSI_index << " <SD | SD[HO]>: " << overlap << endl << endl;
	}
    }
}







void cluster_HO_to_Berggren_class::apply_add (
					      const class GSM_vector &PSI_HO_in ,
					      class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper_HO_in = get_GSM_vector_helper_HO ();

  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper ();
  
  if (!PSI_HO_in.same_parity_strangeness_M_projection (GSM_vector_helper_HO_in)) return;

  if (!PSI_out.same_parity_strangeness_M_projection (GSM_vector_helper_out)) return;
  
  const unsigned int BP_in = GSM_vector_helper_HO_in.get_BP ();

  const unsigned int BP_out = GSM_vector_helper_out.get_BP ();

  if (BP_out != BP_in) return;
  
  const int S_in = GSM_vector_helper_HO_in.get_S ();
  
  const int S_out = GSM_vector_helper_out.get_S ();

  if (S_out != S_in) return;
  
  const int iM_in = GSM_vector_helper_HO_in.get_iM ();

  const int iM_out = GSM_vector_helper_out.get_iM ();
  
  if (iM_out != iM_in) return;
  
  const bool is_it_TRS_HO_in = GSM_vector_helper_HO_in.get_is_it_TRS ();
  
  const bool is_it_TRS_out = GSM_vector_helper_out.get_is_it_TRS ();

  const bool is_it_TRS = (is_it_TRS_HO_in && is_it_TRS_out);
  
  switch (storage)
    {
    case FULL_STORAGE:    apply_add_full_storage (PSI_HO_in , PSI_out); break;
    case PARTIAL_STORAGE: apply_add_full_storage (PSI_HO_in , PSI_out); break;
      
    case ON_THE_FLY: apply_add_on_the_fly (PSI_HO_in , PSI_out); break;
      
    default: abort_all ();
    }

  if (is_it_TRS) PSI_out.TRS_rest_part_fill (false , J);
}




void cluster_HO_to_Berggren_class::apply_add_inverse (
						      const class GSM_vector &PSI_in , 
						      class GSM_vector &PSI_HO_out) const
{
  if (PSI_HO_part_table_ptr == NULL) error_message_print_abort ("PSI_HO_part_table must be allocated to be able to use cluster_HO_to_Berggren_class::apply_add_inverse");
  
  const class GSM_vector_helper_class &GSM_vector_helper_in = get_GSM_vector_helper ();
  
  const class GSM_vector_helper_class &GSM_vector_helper_HO_out = get_GSM_vector_helper_HO ();
  
  if (!PSI_in.same_parity_strangeness_M_projection (GSM_vector_helper_HO_out)) return;

  if (!PSI_HO_out.same_parity_strangeness_M_projection (GSM_vector_helper_in)) return;
  
  const unsigned int BP_in = GSM_vector_helper_in.get_BP ();
  
  const unsigned int BP_out = GSM_vector_helper_HO_out.get_BP ();

  if (BP_in != BP_out) return;
  
  const int S_in = GSM_vector_helper_in.get_S ();
  
  const int S_out = GSM_vector_helper_HO_out.get_S ();

  if (S_in != S_out) return;

  const int iM_in = GSM_vector_helper_in.get_iM ();
  
  const int iM_out = GSM_vector_helper_HO_out.get_iM ();
  
  if (iM_in != iM_out) return;

  const bool is_it_TRS_in = GSM_vector_helper_in.get_is_it_TRS ();
  
  const bool is_it_TRS_HO_out = GSM_vector_helper_HO_out.get_is_it_TRS ();

  const bool is_it_TRS = (is_it_TRS_in && is_it_TRS_HO_out);

  switch (storage)
    {
    case FULL_STORAGE:    apply_add_inverse_full_storage (PSI_in , PSI_HO_out); break;
    case PARTIAL_STORAGE: apply_add_inverse_full_storage (PSI_in , PSI_HO_out); break;
      
    case ON_THE_FLY: apply_add_inverse_on_the_fly (PSI_in , PSI_HO_out); break;
      
    default: abort_all ();
    }
    
  if (is_it_TRS) PSI_HO_out.TRS_rest_part_fill (false , J);
}




















x_cluster_HO_to_Berggren_str::x_cluster_HO_to_Berggren_str (
							    const TYPE &x_c ,
							    const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren_c) :
  x (x_c) ,
  cluster_HO_to_Berggren (cluster_HO_to_Berggren_c)
{}

class x_cluster_HO_to_Berggren_str operator + (const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren)
{
  return x_cluster_HO_to_Berggren_str (1.0 , cluster_HO_to_Berggren);
}

class x_cluster_HO_to_Berggren_str operator - (const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren)
{
  return x_cluster_HO_to_Berggren_str (-1.0 , cluster_HO_to_Berggren);
}

class x_cluster_HO_to_Berggren_str operator * (const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren , const double x)
{
  return x_cluster_HO_to_Berggren_str (x , cluster_HO_to_Berggren);
}

class x_cluster_HO_to_Berggren_str operator * (const double x , const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren)
{
  return x_cluster_HO_to_Berggren_str (x , cluster_HO_to_Berggren);
}

class x_cluster_HO_to_Berggren_str operator / (const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren , const double x)
{
  const double one_over_x = 1.0/x;

  return x_cluster_HO_to_Berggren_str (one_over_x , cluster_HO_to_Berggren);
}

class x_cluster_HO_to_Berggren_str operator + (const class x_cluster_HO_to_Berggren_str &x_cluster_HO_to_Berggren)
{
  return x_cluster_HO_to_Berggren_str (x_cluster_HO_to_Berggren.x , x_cluster_HO_to_Berggren.cluster_HO_to_Berggren);
}

class x_cluster_HO_to_Berggren_str operator - (const class x_cluster_HO_to_Berggren_str &x_cluster_HO_to_Berggren)
{
  return x_cluster_HO_to_Berggren_str (-x_cluster_HO_to_Berggren.x , x_cluster_HO_to_Berggren.cluster_HO_to_Berggren);
}

#ifdef TYPEisDOUBLECOMPLEX

class x_cluster_HO_to_Berggren_str operator * (const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren , const complex<double> &x)
{
  return x_cluster_HO_to_Berggren_str (x , cluster_HO_to_Berggren);
}

class x_cluster_HO_to_Berggren_str operator * (const complex<double> &x , const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren)
{
  return x_cluster_HO_to_Berggren_str (x , cluster_HO_to_Berggren);
}

class x_cluster_HO_to_Berggren_str operator / (const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return x_cluster_HO_to_Berggren_str (one_over_x , cluster_HO_to_Berggren);
}

#endif


