#include "../GSM_include/GSM_include_def.h"

using namespace GSM_vector_NBMEs_handling;
using namespace GSM_vector_dimensions;


// TYPE is double or complex
// -------------------------

// Class storing a GSM vector when only one configuration is occupied in basis space for MSDHF calculations
// --------------------------------------------------------------------------------------------------------
// In order to calculate the MSDHF potential, one has to diagonalize H on the MSDHF configuration, as its ground state is used in the HF-like formulas defining the MSDHF potential.
// As only one configuration occurs, it is much more efficient to recode H in this particular case, than to use the full H class of the general case.
//
// One has here constructors, destructors, and a constructor for operator overloading involving +, -, *, /, H, J^2, T^2, ... (see GSM_vector_operator_overloading_one_configuration.cpp).
//
// TRS is time-reversal symmetry and can be used therein (see GSM_TRS_class.cpp).
// It allows to calculate about one half of |Psi[out]> if M=0, while the rest is given from the first half up to a phase in |Psi[in]> and |Psi[out]>.
// Thus, storage is divided by about two when TRS is used. The rest of the vector is recovered in this class (see TRS_rest_part_fill).
//
// Neither MPI nor OpenMP is used in this class, as parallelization is done an another level with MSDHF.
// It is done at level of the calculation of one-body scattering states, as they can be in large number, so that it is efficient for nodes to calculate them independently.
// Conversely, the space dimensions on one configuration are very small, so that a sequential calculation therein is efficient as well.
//
//
//
// One can use the following coded routines:
//
// good_phase
// ----------
// fix the phase of the GSM vector, so that its largest real or imaginary part in modulus has positive sign
//
// copy_disk and read_disk routines
// --------------------------------
// read/copy GSM components on file using unformatted data.
//
// basis_SD_from_index
// -------------------
// print the proton or neutron basis Slater determinant from its index (typically for tests)
//
// print
// -----
// print the GSM vector, basis Slater determinants and components (typically for tests)
//
// orthogonalization
// -----------------
// orthogonalize a GSM vector with respect to other already calculated, as is the case in the Lanczos and Jacobi-Davidson method. Orthogonalization is done with modified Gram-Schmidt.
//
//
// good_J
// ------
// One projects on J, as is the case in the Lanczos and Jacobi-Davidson method.
// One uses the Lowdin method:  PJ|PSI> = \prod_{Jc != J} [J^2 - Jc.(Jc+1)]/(J(J+1) - Jc(Jc+1))|PSI>.
// These routines are straightforward so that they are not commented.
//
// pivot_init
// ----------
// generate a random pivot projected on J, for the Lanczos method.
//
// TRS_rest_part_fill
// ------------------
// If time-reversal symmetry is used, when M=0, and about half of components have been calculated, one obtains the remaining components from the latter up to a phase (see GSM_TRS_class.cpp).
//
// diagonal_part_PSI_add
// ---------------------
// apply and add a diagonal operator to a GSM vector, as used for the diagonal part of H for example. TRS is used for scalar operators.
//
// operator *
// ----------
// calculate a scalar product between two GSM vectors
//
// infinite_norm
// -------------
// calculate the infinite norm, i.e. the largest real or imaginary part in modulus of a GSM vector
//
// normalization
// -------------
// normalize a GSM vector with the Berggren norm
//
// random_vector
// -------------
// calculate a random GSM vector
//
// opposite
// --------
// provides with the opposite GSM vector (|Psi> -> -|Psi>)
//
// same_parity_M_projection
// ------------------------
// check if two GSM vectors have the same parity or total angular quantum number (as scalars provide with zero if it is not the case)
//
// operator >>, <<
// ---------------
// put or get GSM vector components from a stream using formatted data
//
//
// Routines whose name reads ..._pp_nn... or ..._pn... are not supposed to be used directly.


GSM_vector_one_configuration::GSM_vector_one_configuration () :
  space_dimension (0) ,
  GSM_vector_helper_ptr (NULL) ,
  table (NULL)
{}

GSM_vector_one_configuration::GSM_vector_one_configuration (const class GSM_vector_helper_one_configuration_class &GSM_vector_helper) :
  space_dimension (0) ,
  GSM_vector_helper_ptr (NULL) ,
  table (NULL)
{ 
  allocate (GSM_vector_helper);
}

GSM_vector_one_configuration::GSM_vector_one_configuration (const class GSM_vector_one_configuration &V) :
  space_dimension (0) ,
  GSM_vector_helper_ptr (NULL) ,
  table (NULL)
{
  allocate_fill (V);
}

GSM_vector_one_configuration::GSM_vector_one_configuration (const class Op_PSI_one_configuration_closure_str &closure) :
  space_dimension (0) ,
  GSM_vector_helper_ptr (NULL) ,
  table (NULL)
{
  allocate_calc (closure); 
}


GSM_vector_one_configuration::~GSM_vector_one_configuration ()
{ 
  delete [] table;
}



void GSM_vector_one_configuration::allocate (const class GSM_vector_helper_one_configuration_class &GSM_vector_helper) 
{
  if (is_it_filled ()) error_message_print_abort ("GSM_vector_one_configuration cannot be allocated twice in GSM_vector_one_configuration::allocate");
  
  GSM_vector_helper_ptr = &GSM_vector_helper;

  space_dimension = GSM_vector_helper.get_space_dimension ();

  table = (space_dimension > 0) ? (new TYPE [space_dimension]) : (NULL);
}




void GSM_vector_one_configuration::allocate_fill (const class GSM_vector_one_configuration &V)
{
  if (is_it_filled ()) error_message_print_abort ("GSM_vector_one_configuration cannot be allocated twice in GSM_vector_one_configuration::allocate_fill");
  
  GSM_vector_helper_ptr = V.GSM_vector_helper_ptr;

  space_dimension = V.space_dimension;

  class GSM_vector_one_configuration &PSI = *this;

  table = (space_dimension > 0) ? (new TYPE [space_dimension]) : (NULL);

  for (unsigned int i = 0 ; i < space_dimension ; i++) PSI[i] = V[i];
}







void GSM_vector_one_configuration::allocate_calc (const class Op_PSI_one_configuration_closure_str &closure)
{
  if (is_it_filled ()) error_message_print_abort ("GSM_vector_one_configuration cannot be allocated twice in GSM_vector_one_configuration::allocate_calc");
  
  if (!closure.is_it_filled ()) return;
    
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = closure.GSM_vector_helper_determine ();
  
  space_dimension = GSM_vector_helper.get_space_dimension ();
  
  GSM_vector_helper_ptr = &GSM_vector_helper;
  
  table = (space_dimension > 0) ? (new TYPE [space_dimension]) : (NULL);

  class GSM_vector_one_configuration &PSI_out = *this;

  PSI_out = 0.0;

  closure.all_Op_PSI_in_calc_add (PSI_out);
}




void GSM_vector_one_configuration::deallocate ()
{ 
  delete [] table;

  space_dimension = 0;
  
  table = NULL;
  
  GSM_vector_helper_ptr = NULL;
}








TYPE & GSM_vector_one_configuration::operator [] (const unsigned int i) const
{
  return table[i];
}






TYPE operator * (
		 const class GSM_vector_one_configuration &X ,
		 const class GSM_vector_one_configuration &Y)
{
  const unsigned int space_dimension = X.get_space_dimension ();

  TYPE overlap = 0.0;

  for (unsigned int i = 0 ; i < space_dimension ; i++)
    {
      const TYPE XYi = X[i]*Y[i];

      overlap += XYi;
    }

  return overlap;
}






double GSM_vector_one_configuration::infinite_norm () const
{
  const class GSM_vector_one_configuration &PSI = *this;

  double norm = 0.0;

  for (unsigned int i = 0 ; i < space_dimension ; i++)
    {
      const double try_norm = inf_norm (PSI[i]);

      if (norm < try_norm) norm = try_norm;
    }

  return norm;
}






void GSM_vector_one_configuration::normalization ()
{
  class GSM_vector_one_configuration &PSI = *this;

  const TYPE PSI_norm = sqrt (PSI*PSI);  

  PSI /= PSI_norm;
}







void GSM_vector_one_configuration::random_vector ()
{
  class GSM_vector_one_configuration &PSI = *this;

  for (unsigned int i = 0 ; i < space_dimension ; i++)
    PSI[i] = random_number<TYPE> () - 0.5;
}








void GSM_vector_one_configuration::good_phase ()
{
  class GSM_vector_one_configuration &PSI = *this;

  double norm = 0.0;

  unsigned int i_max = 0;

  for (unsigned int i = 0 ; i < space_dimension ; i++)
    {
      const double try_norm = inf_norm (PSI[i]);

      if (norm < try_norm) 
	{
	  norm = try_norm;
	  i_max = i;
	}
    }

  const double Re_max = real_dc (PSI[i_max]);
  const double Im_max = imag_dc (PSI[i_max]);

  const int phase = (abs (Re_max) > abs (Im_max)) ? (SIGN (Re_max)) : (SIGN (Im_max));

  if (phase == -1) PSI.opposite ();
}


void GSM_vector_one_configuration::copy_disk (const string &file_name) const
{
  basic_copy_disk<TYPE> (file_name , space_dimension , table);
}


void GSM_vector_one_configuration::read_disk (const string &file_name)
{
  basic_read_disk<TYPE> (file_name , space_dimension , table);
}




class Slater_determinant GSM_vector_one_configuration::basis_SD_from_index_pn (
									       const enum space_type basis_space , 
									       const unsigned int total_PSI_index) const
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const unsigned int BPp = GSM_vector_helper.get_BPp ();
  const unsigned int iCp = GSM_vector_helper.get_iCp ();

  const unsigned int BPn = GSM_vector_helper.get_BPn ();
  const unsigned int iCn = GSM_vector_helper.get_iCn ();

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();

  const int iM = GSM_vector_helper.get_iM ();
  
  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
    {
      const int iMn = iM - iMp;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , 0 , 0 , 0  , iCp , iMp);
      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , 0 , 0 , 0 , iCn , iMn);

      if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

      const unsigned int sum_dimensions = sum_dimensions_GSM_vector(iMp);

      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;
      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

      const unsigned int PSI_index_min = sum_dimensions;
      const unsigned int PSI_index_max = sum_dimensions + dimension_SDn*dimension_SDp_minus_one + dimension_SDn_minus_one;

      if ((total_PSI_index >= PSI_index_min) && (total_PSI_index <= PSI_index_max))
	{
	  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
	    {
	      const unsigned int PSI_index_min_SDp_fixed = sum_dimensions + dimension_SDn*SDp_index;
	      const unsigned int PSI_index_max_SDp_fixed = PSI_index_min_SDp_fixed + dimension_SDn_minus_one;

	      if ((total_PSI_index >= PSI_index_min_SDp_fixed) && (total_PSI_index <= PSI_index_max_SDp_fixed))
		{
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      const unsigned int current_PSI_index = PSI_index_min_SDp_fixed + SDn_index;

		      if (current_PSI_index == total_PSI_index) 
			{
			  switch (basis_space)
			    {
			    case PROT_Y_ONLY: return SDp_set(BPp , 0 , 0 , 0  , iCp , iMp , SDp_index);
			    case NEUT_Y_ONLY: return SDn_set(BPn , 0 , 0 , 0 , iCn , iMn , SDn_index);
			      
			    default: abort_all ();
			    }
			}
		    }
		}
	    }
	}
    }

  error_message_print_abort ("No basis SD state found.");

  class Slater_determinant dummy_SD;

  return dummy_SD;
}




class Slater_determinant GSM_vector_one_configuration::basis_SD_from_index_pp_nn (
										  const enum space_type basis_space , 
										  const unsigned int total_PSI_index) const
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();
  
  if (basis_space != space) error_message_print_abort ("space and basis_space are different in GSM_vector_one_configuration::basis_SD_from_index.");

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
  const unsigned int iC = GSM_vector_helper.get_iC ();

  const int iM = GSM_vector_helper.get_iM ();
 
  const class array_of_SD &SD_set = data.get_SD_set ();

  return SD_set(BP , 0 , 0 , 0 , iC , iM , total_PSI_index);
}



class Slater_determinant GSM_vector_one_configuration::basis_SD_from_index (
									    const enum space_type basis_space , 
									    const unsigned int total_PSI_index) const
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();
  
  if (space == PROT_NEUT_Y) 
    return basis_SD_from_index_pn (basis_space , total_PSI_index);
  else
    return basis_SD_from_index_pp_nn (basis_space , total_PSI_index);
}



void GSM_vector_one_configuration::print_pn () const
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const unsigned int BPp = GSM_vector_helper.get_BPp ();
  const unsigned int iCp = GSM_vector_helper.get_iCp ();
  
  const unsigned int BPn = GSM_vector_helper.get_BPn ();
  const unsigned int iCn = GSM_vector_helper.get_iCn ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  const int iM = GSM_vector_helper.get_iM ();
  
  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  const class GSM_vector_one_configuration &PSI = *this;

  class array<unsigned int> SDp_tab(space_dimension , ZYval);
  class array<unsigned int> SDn_tab(space_dimension , NYval);
  
  class Slater_determinant SDp(ZYval);
  class Slater_determinant SDn(NYval);
  
  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
    {
      const int iMn = iM - iMp;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , 0 , 0 , 0  , iCp , iMp);
      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , 0 , 0 , 0 , iCn , iMn);
      
      if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

      const unsigned int sum_dimensions = sum_dimensions_GSM_vector(iMp);

      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
	{
	  SDp = SDp_set(BPp , 0 , 0 , 0  , iCp , iMp , SDp_index);

	  const unsigned int PSI_index_zero_SDp = sum_dimensions + dimension_SDn*SDp_index;

	  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
	    {
	      SDn = SDn_set(BPn , 0 , 0 , 0 , iCn , iMn , SDn_index);

	      const unsigned int PSI_index = PSI_index_zero_SDp + SDn_index;

	      const TYPE PSI_component = PSI[PSI_index];

	      if (PSI_component != 0.0)
		{
		  cout << "P:" , SDp.print (phi_p_table);
		  cout << "N:" , SDn.print (phi_n_table);
		  
		  cout << PSI_component << endl << endl;
		}
	    }
	}
    }
}




void GSM_vector_one_configuration::print_pp_nn () const
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();
 
  const unsigned int BP = GSM_vector_helper.get_BP ();
  const unsigned int iC = GSM_vector_helper.get_iC ();
  
  const int iM = GSM_vector_helper.get_iM ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);
  
  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array<class nljm_struct> &phi_table = data.get_phi_table ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const unsigned int dimension_SD_set = dimensions_SD_set(BP , 0 , 0 , 0 , iC , iM);

  const class GSM_vector_one_configuration &PSI = *this;

  class Slater_determinant SD(N_valence_baryons);
  
  for (unsigned int SD_index = 0 ; SD_index < dimension_SD_set ; SD_index++)
    {
      SD = SD_set(BP , 0 , 0 , 0 , iC , iM , SD_index);
      
      const TYPE PSI_component = PSI[SD_index];

      if (PSI_component != 0.0)
	{
	  SD.print (phi_table);

	  cout << PSI[SD_index] << endl << endl;
	}
    }
}




void GSM_vector_one_configuration::print () const
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();
  
  if (space == PROT_NEUT_Y) 
    print_pn ();
  else
    print_pp_nn ();
}







void GSM_vector_one_configuration::orthogonalization (
						      const unsigned int i , 
						      const class array<class GSM_vector_one_configuration> &V_tab)
{
  if (i == 0) return;

  class GSM_vector_one_configuration &Vi = *this;

  for (unsigned int ii = 0 ; ii < i ; ii++) 
    {
      const class GSM_vector_one_configuration &Vii = V_tab(ii);

      Vi -= (Vi*Vii)*Vii;
    }
}




// Projection of the vector on good J: PJ|PSI> = \prod_{Jc != J} [J^2 - Jc.(Jc+1)]/[J(J+1) - Jc(Jc+1)] |PSI>

void GSM_vector_one_configuration::good_J (
					   const class J2_one_configuration_class &J2 ,
					   const double J)
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const double M = GSM_vector_helper.get_M ();
  
  const double Jmax = GSM_vector_helper.get_Jmax ();

  const int Jc_index_max = make_int (Jmax - M);
  
  const int J_index = make_int (J - M);

  const double J_J_plus_one = J*(J + 1.0);

  class GSM_vector_one_configuration &PSI = *this;

  class GSM_vector_one_configuration PSI_temp = PSI;

  for (int Jc_index = 0 ; Jc_index <= Jc_index_max ; Jc_index++)
    {
      if (Jc_index != J_index)
	{
	  const double Jc = Jc_index + M;

	  const double Jc_Jc_plus_one = Jc*(Jc + 1.0);

	  PSI = (J2 - Jc_Jc_plus_one)*PSI_temp;

	  PSI /= J_J_plus_one - Jc_Jc_plus_one;

	  if (Jc_index < Jc_index_max) PSI_temp = PSI;
	}
    }
}



void GSM_vector_one_configuration::pivot_init (
					       const double J , 
					       const class J2_one_configuration_class &J2)
{
  random_vector ();

  good_J (J2 , J);

  normalization ();  
}




void GSM_vector_one_configuration::TRS_rest_part_fill (const double J)
{
  if (space_dimension == 0) return;
  
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  if (!is_it_TRS) error_message_print_abort ("M=0 only in GSM_vector_one_configuration::TRS_rest_part_fill.");

  const class array<unsigned int> &TRS_PSI_indices = GSM_vector_helper.get_TRS_PSI_indices ();

  const class array<unsigned char> &TRS_bin_phases = GSM_vector_helper.get_TRS_bin_phases ();
    
  const unsigned int bin_phase_J = make_uns_int (J)%2;

  class GSM_vector_one_configuration &PSI = *this;

  for (unsigned int PSI_index = 0 ; PSI_index < space_dimension ; PSI_index++)
    {
      const unsigned int TRS_PSI_index = TRS_PSI_indices(PSI_index);

      if (TRS_PSI_index > PSI_index) 
	{ 
	  const unsigned int TRS_bin_phase = TRS_bin_phases(PSI_index);

	  PSI[TRS_PSI_index] = (TRS_bin_phase == bin_phase_J) ? (PSI[PSI_index]) : (-PSI[PSI_index]);
	}
    }
}




// opposite vector 

void GSM_vector_one_configuration::opposite ()
{
  class GSM_vector_one_configuration &PSI = *this;

  for (unsigned int i = 0 ; i < space_dimension ; i++) PSI[i] = -PSI[i];
}




void GSM_vector_one_configuration::diagonal_part_PSI_add (
							  const class GSM_vector_one_configuration &PSI , 
							  const class array<TYPE> &diagonal_tab , 
							  const TYPE &alpha)
{

  if (space_dimension == 0) return;
  
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  const class array<unsigned int> &TRS_PSI_indices = GSM_vector_helper.get_TRS_PSI_indices ();
 
  class GSM_vector_one_configuration &PSI_out = *this;
			      
  for (unsigned int PSI_index = 0 ; PSI_index < space_dimension ; PSI_index++)
    {
      if (!is_it_TRS || (TRS_PSI_indices(PSI_index) >= PSI_index))
	PSI_out[PSI_index] += (diagonal_tab(PSI_index) + alpha)*PSI[PSI_index];
    }
}



bool GSM_vector_one_configuration::same_parity_M_projection (const class GSM_vector_one_configuration &PSI) const
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_PSI = PSI.get_GSM_vector_helper ();

  return GSM_vector_helper.same_parity_M_projection (GSM_vector_helper_PSI);
}

bool GSM_vector_one_configuration::same_parity_M_projection (const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_PSI) const
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  return GSM_vector_helper.same_parity_M_projection (GSM_vector_helper_PSI);
}




istream & operator >> (istream &is , class GSM_vector_one_configuration &PSI)
{
  const unsigned int space_dimension = PSI.get_space_dimension ();

  for (unsigned int i = 0 ; i < space_dimension ; i++) is >> PSI[i];

  return is;
}

ostream & operator << (ostream &os , const class GSM_vector_one_configuration &PSI)
{
  const unsigned int space_dimension = PSI.get_space_dimension ();

  for (unsigned int i = 0 ; i < space_dimension ; i++) os << PSI[i] << " ";

  return os;
}



double used_memory_calc (const class GSM_vector_one_configuration &T)
{
  return ((sizeof (T) + sizeof (TYPE)*T.space_dimension)/1000000.0);
}






