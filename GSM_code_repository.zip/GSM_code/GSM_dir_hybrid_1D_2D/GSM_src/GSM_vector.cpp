#include "../GSM_include/GSM_include_def.h"

using namespace string_routines;
using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;
using namespace correlated_state_routines;



// MPI transfer is sometimes done here even if is_it_MPI_parallelized is false as disk access cannot be done by many processes at the same time



// TYPE is double or complex
// -------------------------

// Class storing a GSM vector
// --------------------------
// This class stores the components of a GSM vector in a standard array.
// One also stores the GSM dimension and a pointer to GSM_vector_helper_class, which contains data common to all GSM vectors,
// such as those necessary to calculate basis Slater determinant indices.
//
// One has here constructors, destructors, and a constructor for operator overloading involving +, -, *, /, H, J^2, T^2, ... (see GSM_vector_operator_overloading.cpp).
//
// TRS is time-reversal symmetry and can be used therein (see GSM_TRS_class.cpp).
// It allows to calculate about one half of |Psi[out]> if M=0, while the rest is given from the first half up to a phase in |Psi[in]> and |Psi[out]>.
// Thus, storage is divided by about two when TRS is used. The rest of the vector is recovered in this class (see TRS_rest_part_fill).
//
// In order to save memory, one can use virtual allocation, i.e. one uses the array of another GSM vector to store components.
// The dimension of the other GSM vector must naturally be larger than that of the current vector.
// One just has to make sure that both these vectors are used independently.
//
//
// hybrid 1D/2D partitioning
// -------------------------------------
// One uses hybrid 1D/2D partitioning for GSM vectors and operators, so that each node takes care of only one part of the input and output GSM vectors (2D partitioning), but where operators are stored as columns on each node (1D partitioning):
//
//        O p          x  Psi[in]  =  Psi[out]
// * n * n * n * n *        *           *   
// *   *   *   *   *      node 0       node 0
// * o * o * o * o *        *           *
// *   *   *   *   *      node 1       node 1
// * d * d * d * d *        *           *
// *   *   *   *   *      node 2       node 2
// * e * e * e * e *        *           *
// *   *   *   *   *      node 3       node 3
// * 0 * 1 * 2 * 3 *        *           *
//                                                  
// Hence, each node calculates only part of Psi[out] and stores only part of Op, and Psi[in].
// However, it is sometimes necessary to have the full Psi[in] on each node, in which case it is written as Psi[in]-full .
// One does not consider the symmetry of Op if it is symmetric.
// The number of GSM components in Psi[out] considered by one node is denoted as space_dimension_process in the code. 
// Psi[out] is typically reduced on the master process afterwards, so that the master process contains all Psi[out] components.
//
// In order to have Psi[in] and Psi[out] distributed on nodes, one should use the hybrid 1D/2D or 2D partitioning codes.
// 
// MPI transfer is sometimes done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time
//
// One can use the following coded routines:
//
//
//
//
// configuration_occupation_print
// ------------------------------
// If all configurations occupations are printed, one prints the occupation of pole and scattering configurations explicitly.
// Otherwise, one prints the occupation of pole configurations explicitly,
// and one sums over probabilities of configurations which have scattering states of same partial wave and same poles.
// This defines super configurations (see GSM_configuration.cpp), and associated super probabilities.
// Configuration mixings are ordered according to their occupation probabilities.
// They are printed on screen.
//
// assign
// ------
// copy as many components as possible from a GSM vector to another GSM vector or larger/smaller dimension,
//
// good_phase
// ----------
// fix the phase of the GSM vector, so that its largest real or imaginary part in modulus has positive sign
//
// ...copy... and ...read... routines
// ----------------------------------
// read/copy GSM components and/or basis and/or GSM space dimension on file using unformatted data.
// copy/read_disk_indexed_name means that one adds a number to the initial name of the vector, so that for example V0, V1, V2, ... are stored on disk providing with "V" and 0,1,2, ....
// eigenvector_read/copy_disk create the file name of the eigenvector from its quantum numbers.
// 
//
// ...J_scheme... routines
// -----------------------
// for the case of 2 nucleons, read from disk and convert a previously calculated GSM vector in J scheme to M scheme for use in the M scheme code
//
// basis_SD_from_index
// -------------------
// print the proton or neutron basis Slater determinant from its index (typically for tests)
//
// print
// -----
// print the GSM vector, basis Slater determinants and components (typically for tests)
//
//
//
//
// orthogonalization_disk, orthogonalization_not_disk
// --------------------------------------------------
// orthogonalize a GSM vector with respect to other already calculated, as is the case in the Lanczos and Jacobi-Davidson method. Orthogonalization is done with modified Gram-Schmidt.
// |Vi> is replaced by |Vi> - <Vi|Vii> |Vii> after each new ii , which goes from 0 to i. It is a sequential procedure.
// Already calculated GSM vectors are either stored on disk or fast memory.
//
// orthogonalization_disk
// ----------------------
// The best that can be done to parallelize the method is to read all stored vectors from disk in parallel , 
// and then to send them one by one from the current process to the master process where orthogonalization is processed.
// In order to take all cores into account , one associates an integer ii = [number of threads].[process id] + vectors_subset_shift , 
// where vectors_subset_shift goes from 0 to i/[number of cores] , so that ii goes from 0 to i-1 (side effect occurrences of ii >= i are explicity removed).
// Each thread takes care of one vector , which is read from disk and send to the master process afterwards via a loop over all processes.
// As orthogonalization takes time, the time taken to orthogonalize a vector is printed on screen.
//
//
//
//
// good_J_Lowdin, project_good_J
// -----------------------------
// One projects on J, as is the case in the Lanczos and Jacobi-Davidson method.
// These routines are straightforward so that they are not commented.
// One can use the Lowdin method (PJ|PSI> = \prod_{Jc != J} [J^2 - Jc.(Jc+1)]/(J(J+1) - Jc(Jc+1))|PSI>) or J-projection using the Lanczos method.
// The Lowdin method is numerically stable for nuclei before the sdg and fph shells, i.e. for nuclei with A < 100.
// Once shells with j >= 9/2, 11/2 are occupied in the pole space, i.e. for nuclei with A ~ 100 typically, the Lowdin method becomes unstable and one should use the Lanczos method.
// The disadvantage of the Lanczos method to project on J is that about one must store about 50 additional Lanczos vectors for this procedure.
// As projection takes time, the time taken to project a vector on J is printed on screen.
//
//
//
// pivot_init_Davidson/Lanczos
// ---------------------------
// generate a pivot, random + J-projection, or from an already calculated GSM vector, from pole approximation or from a file, as is the case in the Lanczos and Jacobi-Davidson method
// One routine is used when one considers only one pivot from file, as in the Jacobi-Davidson method, or several, as in the Lanczos method.
// With the Lowdin method, it can be necessary to project on J several times, especially if the pivot is random.
// However, this occurs typically at pole approximation level, so that recalculation time is negligible.
//
//
//
//
// used_memory_calc
// ----------------
// calculate the memory used by a GSM vector
//
// TRS_rest_part_fill
// ------------------
// If time-reversal symmetry is used, when M=0, and about half of components have been calculated, one obtains the remaining components from the latter up to a phase (see GSM_TRS_class.cpp).
//
// pole_space_project, scat_space_project
// ------------------------------------
// Projection of the GSM vector on its pole or scattering configurations.
//
// average_n_scat_calc
// -------------------
// calculate the average number of occupied scattering states
//
// diagonal_part_PSI_add
// ---------------------
// apply and add a diagonal operator to a GSM vector, as used for the diagonal part of H for example. TRS is used for scalar operators.
//
// operator *
// ----------
// calculate a scalar product between two GSM vectors
//
// infinite_norm
// -------------
// calculate the infinite norm, i.e. the largest real or imaginary part in modulus of a GSM vector
//
// normalization
// -------------
// normalize a GSM vector with the Berggren norm
//
// random_vector
// -------------
// calculate a random GSM vector
//
// pseudo_random_vector
// --------------------
// calculate a pseudo-random GSM vector whose seed is always generated by the GSM space dimension, so that it is the same for all MPI nodes for example.
//
// opposite
// --------
// provides with the opposite GSM vector (|Psi> -> -|Psi>)
//
// same_parity_M_projection
// ------------------------
// check if two GSM vectors have the same parity or total angular quantum number (as scalars provide with zero if it is not the case)
//
// first_index_determine_for_MPI, last_index_determine_for_MPI
// -----------------------------------------------------------
// calculate the first and last GSM component index to be considered by one node
//
// active_process_determine_for_MPI
// --------------------------------
// returns true if an MPI rank is active, and false if not.
// The MPI rank of index 10 is not active, for example, if the distributed array has a dimension of 5, as only the MPI nodes 0,1,2,3,4 are active therein.
// 
// 
// MPI_Send, MPI_Recv, MPI_Sendrecv_replace, MPI_Bcast, MPI_Reduce, MPI_Allreduce
// ------------------------------------------------------------------------------
// make standard MPI transfers fo GSM vector components, such as Send, Recv, Send_Recv_Replace, Bcast, Reduce, Allreduce
//
// sum
// ---
// sum all components (typically for tests)
//
// operator >>, <<
// ---------------
// put or get GSM vector components from a stream using formatted data
//
//
// Routines whose name reads ..._pp_nn... or ..._pn... are not supposed to be used directly.

GSM_vector::GSM_vector () :
  is_it_virtual_allocation (false) ,
  space_dimensions_all_processes_max (0) , 
  GSM_vector_helper_ptr (NULL) ,
  table (NULL)
{}

GSM_vector::GSM_vector (class GSM_vector_helper_class &GSM_vector_helper) :
  is_it_virtual_allocation (false) ,
  space_dimensions_all_processes_max (0) , 
  GSM_vector_helper_ptr (NULL) ,
  table (NULL)
{
  allocate (GSM_vector_helper);
}

GSM_vector::GSM_vector (const class GSM_vector &V) :
  is_it_virtual_allocation (false) ,
  space_dimensions_all_processes_max (0) , 
  GSM_vector_helper_ptr (NULL) ,
  table (NULL)
{
  allocate_fill (V);
}

GSM_vector::GSM_vector (const class Op_PSI_closure_str &closure) :
  is_it_virtual_allocation (false) ,
  space_dimensions_all_processes_max (0) , 
  GSM_vector_helper_ptr (NULL) ,
  table (NULL)
{
  allocate_calc (closure);
}







GSM_vector::~GSM_vector ()
{ 
  if (!is_it_virtual_allocation) delete [] table;
}


void GSM_vector::allocate (class GSM_vector_helper_class &GSM_vector_helper)
{
  if (is_it_filled ()) error_message_print_abort ("GSM_vector cannot be allocated twice in GSM_vector::allocate");

  is_it_virtual_allocation = false;
  
  GSM_vector_helper_ptr = &GSM_vector_helper;

  space_dimensions_all_processes_max = GSM_vector_helper.get_space_dimensions_all_processes_max ();

  table = (space_dimensions_all_processes_max > 0) ? (new TYPE [space_dimensions_all_processes_max]) : (NULL);
}


void GSM_vector::virtual_allocate (class GSM_vector_helper_class &GSM_vector_helper , const class GSM_vector &V)
{  
  if (is_it_filled ()) error_message_print_abort ("GSM_vector cannot be allocated twice in GSM_vector::virtual_allocate");
  
  is_it_virtual_allocation = true;
  
  const unsigned int V_space_dimensions_all_processes_max = V.get_space_dimensions_all_processes_max ();

  GSM_vector_helper_ptr = &GSM_vector_helper;
  
  space_dimensions_all_processes_max = GSM_vector_helper.get_space_dimensions_all_processes_max ();
  
  if (V_space_dimensions_all_processes_max < space_dimensions_all_processes_max) error_message_print_abort ("GSM_vector helper must have a larger or equal dimension than the current GSM vector in GSM_vector::virtual_allocate");
  
  table = V.table;
}




void GSM_vector::allocate_fill (const class GSM_vector &V)
{
  if (is_it_filled ()) error_message_print_abort ("GSM_vector cannot be allocated twice in GSM_vector::allocate_fill");

  is_it_virtual_allocation = false;
  
  GSM_vector_helper_ptr = V.GSM_vector_helper_ptr;

  space_dimensions_all_processes_max = V.space_dimensions_all_processes_max;

  class GSM_vector &PSI = *this;

  table = (space_dimensions_all_processes_max > 0) ? (new TYPE [space_dimensions_all_processes_max]) : (NULL);

  for (unsigned int i = 0 ; i < space_dimensions_all_processes_max ; i++) PSI[i] = V[i];
}



void GSM_vector::allocate_calc (const class Op_PSI_closure_str &closure)
{
  if (is_it_filled ()) error_message_print_abort ("GSM_vector cannot be allocated twice in GSM_vector::allocate_calc");

  is_it_virtual_allocation = false;
  
  if (!closure.is_it_filled ()) return;

  class GSM_vector_helper_class &GSM_vector_helper = closure.GSM_vector_helper_determine ();

  space_dimensions_all_processes_max = GSM_vector_helper.get_space_dimensions_all_processes_max ();

  GSM_vector_helper_ptr = &GSM_vector_helper;

  table = (space_dimensions_all_processes_max > 0) ? (new TYPE [space_dimensions_all_processes_max]) : (NULL);

  class GSM_vector &PSI_out = *this;

  PSI_out = 0.0;

  closure.all_Op_PSI_in_calc_add (PSI_out);
}




void GSM_vector::deallocate ()
{ 
  if (!is_it_virtual_allocation) delete [] table;

  is_it_virtual_allocation = false;
  
  space_dimensions_all_processes_max = 0;

  table = NULL;

  GSM_vector_helper_ptr = NULL;
}



void GSM_vector::change_GSM_vector_helper_reallocate (class GSM_vector_helper_class &new_GSM_vector_helper)
{
  if (is_it_virtual_allocation) error_message_print_abort ("Virtual allocation cannot be used in GSM_vector::change_GSM_vector_helper_reallocate");
  
  const unsigned int space_dimensions_all_processes_max_new_helper = new_GSM_vector_helper.get_space_dimensions_all_processes_max ();  
  
  GSM_vector_helper_ptr = &new_GSM_vector_helper;
      
  if (space_dimensions_all_processes_max < space_dimensions_all_processes_max_new_helper)
    {
      space_dimensions_all_processes_max = space_dimensions_all_processes_max_new_helper;
  
      delete [] table;
      
      table = new TYPE [space_dimensions_all_processes_max];

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  const double used_memory = used_memory_calc (*this);

	  if (used_memory >= 500) cout << endl << "Large memory of reallocated general storage GSM vector: " << used_memory << " Mb" << endl << endl;
	}
    }  
}


void GSM_vector::remove_GSM_vector_helper ()
{
  GSM_vector_helper_ptr = NULL;
}




void GSM_vector::zero ()
{  
  for (unsigned long int i = 0 ; i < space_dimensions_all_processes_max ; i++) table[i] = 0.0;
}







void GSM_vector::configuration_mixing_tab_fill_pp_nn (class array<class configuration_mixing_data> &configuration_mixing_tab) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();

  const double M = GSM_vector_helper.get_M ();  

  const int iM = GSM_vector_helper.get_iM (); 

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();
  
  const class GSM_vector &PSI = *this;

  class configuration C(N_valence_baryons);
  
  unsigned int index = 0;

  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int dimension_C = dimensions_configuration_set(BP , S , 0 , n_scat);

      for (unsigned int iC = 0 ; iC < dimension_C ; iC++)
	{
	  const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
	  const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  C = configuration_set(BP , S , 0 , n_scat , iC);
	  
	  const double M_max_C = C.M_max_determine (shells_qn);

	  const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions(n_scat , iC);

	  if (M <= M_max_C)
	    {
	      const unsigned int dimension_SD = dimensions_SD_set(BP , S , 0 , n_scat , iC , iM);

	      TYPE probability = 0.0;

	      for (unsigned int SD_index = 0 ; SD_index < dimension_SD ; SD_index++)
		{
		  const unsigned long int total_PSI_index = sum_dimensions_configuration_fixed + SD_index;

		  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
		    {
		      const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

		      const TYPE component = PSI[PSI_index];

		      const TYPE component_square = component*component;

		      probability += component_square;
		    }
		}
	      
	      configuration_mixing_tab(index++) = configuration_mixing_data (NADA , NADA , NADA , NADA , NADA , NADA , NADA , iC , n_scat , probability);
	    }
	}
    }

#ifdef UseMPI

  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();

  if (is_it_MPI_parallelized_local) 
    {
      const unsigned int dimension = configuration_mixing_tab.dimension (0);

      class array<TYPE> probabilities(dimension);

      for (unsigned int i = 0 ; i < dimension ; i++)
	{
	  const class configuration_mixing_data &configuration_mixing = configuration_mixing_tab(i);
	  
	  probabilities(i) = configuration_mixing.get_probability ();
	}

      probabilities.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  for (unsigned int i = 0 ; i < dimension ; i++)
	    {
	      class configuration_mixing_data &configuration_mixing = configuration_mixing_tab(i);

	      const unsigned int iC = configuration_mixing.get_iC ();

	      const int n_scat = configuration_mixing.get_n_scat ();

	      const TYPE probability = probabilities(i);

	      configuration_mixing.initialize (NADA , NADA , NADA , NADA , NADA , NADA , NADA , iC , n_scat , probability);
	    }
	}
    }

#endif
}





void GSM_vector::configuration_mixing_tab_fill_pn (class array<class configuration_mixing_data> &configuration_mixing_tab) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 

  const double M = GSM_vector_helper.get_M ();

  const int iM = GSM_vector_helper.get_iM ();

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array<unsigned int> &dimensions_configuration_set_p = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_set_n = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_set_p = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_set_n = neut_Y_data.get_configuration_set ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class GSM_vector &PSI = *this;

  class configuration Cp(ZYval);
  class configuration Cn(NYval);
  
  unsigned int index = 0;

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP);
      
      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;
	  
	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p;
	  
	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int dimension_iCp = dimensions_configuration_set_p(BPp , Sp , n_spec_p , n_scat_p);
	  
		  for (unsigned int iCp = 0 ; iCp < dimension_iCp ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      Cp = configuration_set_p(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	  
		      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
			{
			  const unsigned int dimension_iCn = dimensions_configuration_set_n(BPn , Sn , n_spec_n , n_scat_n);
	  
			  for (unsigned int iCn = 0 ; iCn < dimension_iCn ; iCn++)
			    {
			      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
			      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

			      Cn = configuration_set_n(BPn , Sn , n_spec_n , n_scat_n , iCn);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	  
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			
			      const double M_max_Cp = Cp.M_max_determine (shells_qn_p);
			      const double M_max_Cn = Cn.M_max_determine (shells_qn_n);

			      const double M_max_C = M_max_Cp + M_max_Cn;

			      TYPE probability = 0.0;

			      if (M <= M_max_C)
				{
				  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
				    {
				      const int iMn = iM - iMp;

				      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
				      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

				      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

				      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
					{
					  const unsigned long int total_PSI_index_zero_SDp = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;

					  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
					    {
					      const unsigned long int total_PSI_index = total_PSI_index_zero_SDp + SDn_index;

					      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
						{
						  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

						  const TYPE component = PSI[PSI_index];

						  const TYPE component_square = component*component;

						  probability += component_square;
						}
					    }
					}
				    }
			      
				  configuration_mixing_tab(index) = configuration_mixing_data (BPp , Sp , n_spec_p , iCp , iCn , n_scat_p , n_scat_n , NADA , NADA , probability);
				}}}}}}}}
  
#ifdef UseMPI
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  if (is_it_MPI_parallelized_local) 
    {
      const unsigned int dimension = configuration_mixing_tab.dimension (0);

      class array<TYPE> probabilities(dimension);

      for (unsigned int i = 0 ; i < dimension ; i++)
	{
	  const class configuration_mixing_data &configuration_mixing = configuration_mixing_tab(i);
	  
	  probabilities(i) = configuration_mixing.get_probability ();
	}

      probabilities.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  for (unsigned int i = 0 ; i < dimension ; i++)
	    {
	      class configuration_mixing_data &configuration_mixing = configuration_mixing_tab(i);

	      const unsigned int BPp = configuration_mixing.get_BPp ();

	      const int Sp = configuration_mixing.get_Sp ();

	      const int n_spec_p = configuration_mixing.get_n_spec_p ();

	      const unsigned int iCp = configuration_mixing.get_iCp ();
	      const unsigned int iCn = configuration_mixing.get_iCn ();

	      const int n_scat_p = configuration_mixing.get_n_scat_p ();
	      const int n_scat_n = configuration_mixing.get_n_scat_n ();

	      const TYPE probability = probabilities(i);

	      configuration_mixing.initialize (BPp , Sp , n_spec_p , iCp , iCn , n_scat_p , n_scat_n , NADA , NADA , probability);
	    }
	}
    }

#endif
}







void GSM_vector::configuration_occupation_print (
						 const bool are_scattering_configuration_probabilities_printed ,
						 const double configuration_precision) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const unsigned int BP = GSM_vector_helper.get_BP ();
    
  const double M = GSM_vector_helper.get_M ();

  const enum space_type space = GSM_vector_helper.get_space ();  

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();

  const int n_scat_max   = GSM_vector_helper.get_n_scat_max ();

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  if (space == PROT_NEUT_Y)
    {  
      const unsigned int dimension = configuration_mixing_tab_dimension_pn_calc (BP , M , truncation_hw , truncation_ph ,
										 n_holes_max_p , n_holes_max_n , n_holes_max , n_scat_max_p , n_scat_max_n , n_scat_max , Ep_max_hw , En_max_hw , E_max_hw ,
										 prot_Y_data , neut_Y_data);

      const unsigned int dimension_minus_one = dimension - 1;

      class array<class configuration_mixing_data> configuration_mixing_tab(dimension);

      configuration_mixing_tab_fill_pn (configuration_mixing_tab);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  configuration_mixing_tab_sort (0 , dimension_minus_one , configuration_mixing_tab);

	  configuration_occupation_print_pn (BP , truncation_ph , n_scat_max , n_scat_max_p , n_scat_max_n , prot_Y_data , neut_Y_data ,
					     are_scattering_configuration_probabilities_printed , configuration_mixing_tab , configuration_precision);

	  bool is_it_negligible = true;

	  for (unsigned int i = 0 ; is_it_negligible && (i < dimension_minus_one) ; i++)
	    is_it_negligible = is_it_negligible && (inf_norm (configuration_mixing_tab(i).get_probability ()) < precision);

	  if (!is_it_negligible) maximal_probability_configuration_print (BP , space , prot_Y_data , neut_Y_data , configuration_mixing_tab);
	}
    }
  else
    {
      const unsigned int dimension = configuration_mixing_tab_dimension_pp_nn_calc (BP , M , space , truncation_hw , truncation_ph , n_holes_max , n_scat_max , E_max_hw , prot_Y_data , neut_Y_data);

      const unsigned int dimension_minus_one = dimension - 1;

      class array<class configuration_mixing_data> configuration_mixing_tab(dimension);

      configuration_mixing_tab_fill_pp_nn (configuration_mixing_tab);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  configuration_mixing_tab_sort (0 , dimension_minus_one , configuration_mixing_tab);

	  configuration_occupation_print_pp_nn (BP , space , n_scat_max , prot_Y_data , neut_Y_data , are_scattering_configuration_probabilities_printed , configuration_mixing_tab , configuration_precision);

	  bool is_it_negligible = true;

	  for (unsigned int i = 0 ; is_it_negligible && (i < dimension_minus_one) ; i++)
	    is_it_negligible = is_it_negligible && (inf_norm (configuration_mixing_tab(i).get_probability ()) < precision);

	  if (!is_it_negligible) maximal_probability_configuration_print (BP , space , prot_Y_data , neut_Y_data , configuration_mixing_tab);
	}
    }
}







void GSM_vector::assign (const class GSM_vector &PSI_other_space)
{
  if (!PSI_other_space.is_it_filled ()) return;

  class GSM_vector &PSI = *this;

  const class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();

  const class GSM_vector_helper_class &GSM_vector_helper_other_space = PSI_other_space.get_GSM_vector_helper ();

  const unsigned long int total_space_dimension = GSM_vector_helper.get_total_space_dimension ();

  const unsigned long int total_space_dimension_other_space = GSM_vector_helper_other_space.get_total_space_dimension ();

  const bool PSI_is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();

  const bool PSI_other_space_is_it_MPI_parallelized_local = GSM_vector_helper_other_space.get_is_it_MPI_parallelized_local ();

  if (PSI_is_it_MPI_parallelized_local && PSI_other_space_is_it_MPI_parallelized_local)
    error_message_print_abort ("PSI or PSI_other_space must be defined without MPI distribution in GSM_vector::assign");

  if (PSI_is_it_MPI_parallelized_local || PSI_other_space_is_it_MPI_parallelized_local)
    { 
      if (!PSI_is_it_MPI_parallelized_local && (total_space_dimension > total_space_dimension_other_space))
	error_message_print_abort ("PSI must have a dimension smaller or equal to PSI_other_space if PSI is defined without MPI distribution and PSI_other_space is defined with MPI distribution in GSM_vector::assign");

      if (!PSI_other_space_is_it_MPI_parallelized_local && (total_space_dimension_other_space > total_space_dimension))
	error_message_print_abort ("PSI must have a dimension larger or equal to PSI_other_space if PSI is defined with MPI distribution and PSI_other_space is defined without MPI distribution in GSM_vector::assign");
    }

  if (total_space_dimension <= total_space_dimension_other_space) zero ();

  const enum space_type space = GSM_vector_helper.get_space ();

  const enum space_type other_space = GSM_vector_helper_other_space.get_space ();

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const unsigned int BP_other_space = GSM_vector_helper_other_space.get_BP ();

  const double M = GSM_vector_helper.get_M ();

  const double M_other_space = GSM_vector_helper_other_space.get_M ();  

  const int iM = GSM_vector_helper.get_iM ();

  const int iM_other_space = GSM_vector_helper_other_space.get_iM ();

  if ((space != other_space) || (BP != BP_other_space) || (rint (M - M_other_space) != 0.0) || (iM != iM_other_space))
    error_message_print_abort ("PSI and PSI_other_space must have the same space, BP, M and/or M_max in GSM_vector::assign");

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const bool truncation_hw_other_space = GSM_vector_helper_other_space.get_truncation_hw ();
  const bool truncation_ph_other_space = GSM_vector_helper_other_space.get_truncation_ph ();

  const int n_holes_max_other_space = GSM_vector_helper_other_space.get_n_holes_max ();
  
  const int n_scat_max_other_space = GSM_vector_helper_other_space.get_n_scat_max ();

  const int E_max_hw_other_space = GSM_vector_helper_other_space.get_E_max_hw ();

  const bool truncation_hw_assign = (truncation_hw || truncation_hw_other_space);
  const bool truncation_ph_assign = (truncation_ph || truncation_ph_other_space);    

  const int smallest_n_holes_max = min (n_holes_max , n_holes_max_other_space);
  
  const int smallest_n_scat_max = min (n_scat_max , n_scat_max_other_space);

  const int smallest_E_max_hw = min (E_max_hw , E_max_hw_other_space);

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_other_space = GSM_vector_helper_other_space.get_sum_dimensions_GSM_vector ();

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const unsigned long int first_total_PSI_index_other_space = GSM_vector_helper_other_space.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index_other_space = GSM_vector_helper_other_space.get_last_total_PSI_index ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  if (space == PROT_NEUT_Y)
    {
      const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
      const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();

      const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
      const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();

      const int n_holes_max_p_other_space = GSM_vector_helper_other_space.get_n_holes_max_p ();
      const int n_holes_max_n_other_space = GSM_vector_helper_other_space.get_n_holes_max_n ();

      const int smallest_n_holes_max_p = min (n_holes_max_p , n_holes_max_p_other_space);
      const int smallest_n_holes_max_n = min (n_holes_max_n , n_holes_max_n_other_space);
      
      const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p ();
      const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

      const int n_scat_max_p_other_space = GSM_vector_helper_other_space.get_n_scat_max_p ();
      const int n_scat_max_n_other_space = GSM_vector_helper_other_space.get_n_scat_max_n ();

      const int smallest_n_scat_max_p = min (n_scat_max_p , n_scat_max_p_other_space);
      const int smallest_n_scat_max_n = min (n_scat_max_n , n_scat_max_n_other_space);

      const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
      const int En_max_hw = GSM_vector_helper.get_En_max_hw ();

      const int Ep_max_hw_other_space = GSM_vector_helper_other_space.get_Ep_max_hw ();
      const int En_max_hw_other_space = GSM_vector_helper_other_space.get_En_max_hw ();

      const int smallest_Ep_max_hw = min (Ep_max_hw , Ep_max_hw_other_space);
      const int smallest_En_max_hw = min (En_max_hw , En_max_hw_other_space);

      const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
      const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
      
      const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
      const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();

      const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
      const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

      const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
      const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
      const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
      const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
      for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
	{
	  const unsigned int BPn = binary_parity_product (BPp , BP);
	  
	  for (int Sp = 0 ; Sp <= S ; Sp++)
	    {
	      const int Sn = S - Sp;
	  
	      for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
		{
		  const int n_spec_n = n_spec_max - n_spec_p;
	      
		  for (int n_scat_p = 0 ; n_scat_p <= smallest_n_scat_max_p ; n_scat_p++)
		    {
		      const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
		      const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  
		      for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
			{
			  const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

			  const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
			  if (!is_basis_state_in_space_pp_nn (truncation_hw_assign , truncation_ph_assign , n_holes_p , n_scat_p , Ep_hw , smallest_n_holes_max_p , smallest_n_scat_max_p , smallest_Ep_max_hw)) continue;

			  for (int n_scat_n = 0 ; n_scat_n <= smallest_n_scat_max_n ; n_scat_n++)
			    {
			      const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
			      const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  
			      for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
				{
				  const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
				  const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

				  if (!is_basis_state_in_space_pp_nn (truncation_hw_assign , truncation_ph_assign , n_holes_n , n_scat_n , En_hw , smallest_n_holes_max_n , smallest_n_scat_max_n , smallest_En_max_hw)) continue;
		  
				  if (!is_basis_state_in_space_pn (truncation_hw_assign , truncation_ph_assign , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , smallest_n_holes_max , smallest_n_scat_max , smallest_E_max_hw)) continue;
			    
				  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
				    {
				      const int iMn = iM - iMp;

				      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
				      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

				      if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

				      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);
				      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_other_space = sum_dimensions_other_space(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

				      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
					{
					  const unsigned int dimension_SDn_times_SDp_index = dimension_SDn*SDp_index;
				      
					  const unsigned long int total_PSI_index_zero_SDp = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn_times_SDp_index;
				      
					  const unsigned long int total_PSI_index_other_space_zero_SDp = sum_dimensions_configuration_Mp_Mn_fixed_other_space + dimension_SDn_times_SDp_index;

					  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
					    {
					      const unsigned long int total_PSI_index = total_PSI_index_zero_SDp + SDn_index;

					      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
						{
						  const unsigned long int total_PSI_index_other_space = total_PSI_index_other_space_zero_SDp + SDn_index;

						  if ((total_PSI_index_other_space >= first_total_PSI_index_other_space) && (total_PSI_index_other_space <= last_total_PSI_index_other_space))
						    {
						      const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;
						      const unsigned int PSI_index_other_space = total_PSI_index_other_space - first_total_PSI_index_other_space;

						      PSI[PSI_index] = PSI_other_space[PSI_index_other_space];
						    }}}}}}}}}}}}
    }
  else
    {
      const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

      const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
      const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();

      const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

      const class array<unsigned int> &iC_min_process_tab = GSM_vector_helper.get_iC_min_process_tab ();
      const class array<unsigned int> &iC_max_process_tab = GSM_vector_helper.get_iC_max_process_tab ();
      
      for (int n_scat = 0 ; n_scat <= smallest_n_scat_max ; n_scat++) 
	{
	  const unsigned int iC_min = iC_min_process_tab(n_scat);
	  const unsigned int iC_max = iC_max_process_tab(n_scat);
	  
	  for (unsigned int iC = iC_min ; iC <= iC_max ; iC++)
	    {      
	      const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
	      const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw_assign , truncation_ph_assign , n_holes , n_scat , E_hw , smallest_n_holes_max , smallest_n_scat_max , smallest_E_max_hw)) continue;

	      const unsigned int dimension_SD = dimensions_SD_set(BP , S , 0 , n_scat , iC , iM);

	      const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions(n_scat , iC);

	      const unsigned long int sum_dimensions_configuration_fixed_other_space = sum_dimensions_other_space(n_scat , iC);
	      
	      for (unsigned int SD_index = 0 ; SD_index < dimension_SD ; SD_index++)
		{
		  const unsigned long int total_PSI_index = sum_dimensions_configuration_fixed + SD_index;
		    
		  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
		    {
		      const unsigned long int total_PSI_index_other_space = sum_dimensions_configuration_fixed_other_space + SD_index;

		      if ((total_PSI_index_other_space >= first_total_PSI_index_other_space) && (total_PSI_index_other_space <= last_total_PSI_index_other_space))
			{
			  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

			  const unsigned int PSI_index_other_space = total_PSI_index_other_space - first_total_PSI_index_other_space;
			  
			  PSI[PSI_index] = PSI_other_space[PSI_index_other_space];
			}}}}}}
  
#ifdef UseMPI

  if (PSI_other_space_is_it_MPI_parallelized_local && !PSI_is_it_MPI_parallelized_local) MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);

#endif
}







void GSM_vector::good_phase ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();

  class GSM_vector &PSI = *this;

  double PSI_infinite_norm = 0.0;

  TYPE PSI_component_max = 0.0;

  for (unsigned int i = 0 ; i < space_dimension_process ; i++)
    {
      const TYPE PSI_component = PSI[i];
      
      const double try_PSI_infinite_norm = inf_norm (PSI_component);

      if (PSI_infinite_norm < try_PSI_infinite_norm) 
	{
	  PSI_infinite_norm = try_PSI_infinite_norm;

	  PSI_component_max = PSI_component;
	}
    }

#ifdef UseMPI

  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();

  if (is_it_MPI_parallelized_local) 
    {
      class array<double> PSI_infinite_norm_tab(NUMBER_OF_PROCESSES);

      class array<TYPE> PSI_component_max_tab(NUMBER_OF_PROCESSES);

      PSI_infinite_norm_tab = 0.0;
      PSI_infinite_norm_tab(THIS_PROCESS) = PSI_infinite_norm;
      PSI_infinite_norm_tab.MPI_Allreduce (MPI_MAX , MPI_COMM_WORLD);

      PSI_component_max_tab = 0.0;
      PSI_component_max_tab(THIS_PROCESS) = PSI_component_max;
      PSI_component_max_tab.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);

      PSI_infinite_norm = 0.0;

      PSI_component_max = 0.0;

      for (unsigned int i = 0 ; i < NUMBER_OF_PROCESSES ; i++)
	{
	  const double try_PSI_infinite_norm = PSI_infinite_norm_tab(i);

	  if (PSI_infinite_norm < try_PSI_infinite_norm) 
	    {
	      PSI_infinite_norm = try_PSI_infinite_norm;

	      PSI_component_max = PSI_component_max_tab(i);
	    }
	}
    }

#endif

  const double Re_PSI_component_max = real_dc (PSI_component_max);
  const double Im_PSI_component_max = imag_dc (PSI_component_max);

  const int phase = (abs (Re_PSI_component_max) > abs (Im_PSI_component_max)) ? (SIGN (Re_PSI_component_max)) : (SIGN (Im_PSI_component_max));

  if (phase == -1) opposite ();
}







void GSM_vector::copy_disk (
			    const bool full_common_vectors_used_in_file ,
			    const bool full_common_vectors_used_in_file_with_MPI_calls ,
			    const string &file_name) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const unsigned long int total_space_dimension = GSM_vector_helper.get_total_space_dimension ();
  
  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();

  if (!full_common_vectors_used_in_file && full_common_vectors_used_in_file_with_MPI_calls)
    error_message_print_abort ("One cannot have full_common_vectors_used_in_file false and full_common_vectors_used_in_file_with_MPI_calls true in GSM_vector::copy_disk");
      
  if (full_common_vectors_used_in_file && full_common_vectors_used_in_file_with_MPI_calls)
    {
      const class GSM_vector &PSI = *this;
   
      class GSM_vector_helper_class PSI_full_helper;

      PSI_full_helper.allocate_fill_without_MPI_parallelization (GSM_vector_helper);
      
      class GSM_vector PSI_full(PSI_full_helper);
  
      PSI_full.full_vector_fill (PSI);
      
      if (THIS_PROCESS == MASTER_PROCESS) basic_copy_disk<TYPE> (file_name , total_space_dimension , PSI_full.table);	  
    }
  else
    basic_copy_disk<TYPE> (file_name , space_dimension_process , table);
}




void GSM_vector::eigenvector_copy_disk (
					const bool full_common_vectors_used_in_file ,
					const bool full_common_vectors_used_in_file_with_MPI_calls ,
					const class correlated_state_str &PSI_qn) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const double M = GSM_vector_helper.get_M ();

  const string file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector" , PSI_qn , M);
  
  copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , file_name);
}

void GSM_vector::space_dimension_eigenvector_copy_disk (
							const bool full_common_vectors_used_in_file ,
							const class correlated_state_str &PSI_qn) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const double M = GSM_vector_helper.get_M ();

  const string space_dimension_file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_qn , M);
  
  space_dimension_copy_disk (full_common_vectors_used_in_file , space_dimension_file_name);
}

void GSM_vector::space_dimension_SDs_components_eigenvector_copy_disk (
								       const bool full_common_vectors_used_in_file ,
								       const bool full_common_vectors_used_in_file_with_MPI_calls ,
								       const class correlated_state_str &PSI_qn) const
{
  space_dimension_eigenvector_copy_disk (full_common_vectors_used_in_file , PSI_qn);

  SDs_components_eigenvector_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , PSI_qn);
}

void GSM_vector::SDs_components_eigenvector_copy_disk (
						       const bool full_common_vectors_used_in_file ,
						       const bool full_common_vectors_used_in_file_with_MPI_calls ,
						       const class correlated_state_str &PSI_qn) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const double M = GSM_vector_helper.get_M ();

  const string file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector" , PSI_qn , M);
  
  SDs_components_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , file_name);
}










void GSM_vector::eigenvector_good_T_copy_disk (
					       const bool full_common_vectors_used_in_file ,
					       const bool full_common_vectors_used_in_file_with_MPI_calls ,
					       const class correlated_state_str &PSI_qn) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const double M = GSM_vector_helper.get_M ();

  const string file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_good_T" , PSI_qn , M);
  
  copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , file_name);
}

void GSM_vector::space_dimension_eigenvector_good_T_copy_disk (
							       const bool full_common_vectors_used_in_file ,
							       const class correlated_state_str &PSI_qn) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const double M = GSM_vector_helper.get_M ();

  const string space_dimension_file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_good_T_dimension" , PSI_qn , M);
  
  space_dimension_copy_disk (full_common_vectors_used_in_file , space_dimension_file_name);
}

void GSM_vector::space_dimension_SDs_components_eigenvector_good_T_copy_disk (
									      const bool full_common_vectors_used_in_file ,
									      const bool full_common_vectors_used_in_file_with_MPI_calls ,
									      const class correlated_state_str &PSI_qn) const
{
  space_dimension_eigenvector_good_T_copy_disk (full_common_vectors_used_in_file , PSI_qn);

  SDs_components_eigenvector_good_T_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , PSI_qn);
}

void GSM_vector::SDs_components_eigenvector_good_T_copy_disk (
							      const bool full_common_vectors_used_in_file ,
							      const bool full_common_vectors_used_in_file_with_MPI_calls ,
							      const class correlated_state_str &PSI_qn) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const double M = GSM_vector_helper.get_M ();

  const string file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_good_T" , PSI_qn , M);
  
  SDs_components_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , file_name);
}











void GSM_vector::eigenvector_Jmin_copy_disk (
					     const bool full_common_vectors_used_in_file ,
					     const bool full_common_vectors_used_in_file_with_MPI_calls ,
					     const class correlated_state_str &PSI_qn) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const double M = GSM_vector_helper.get_M ();

  const string file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_Jmin" , PSI_qn , M);
  
  copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , file_name);
}

void GSM_vector::space_dimension_eigenvector_Jmin_copy_disk (
							     const bool full_common_vectors_used_in_file ,
							     const class correlated_state_str &PSI_qn) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const double M = GSM_vector_helper.get_M ();

  const string space_dimension_file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_Jmin_dimension" , PSI_qn , M);
  
  space_dimension_copy_disk (full_common_vectors_used_in_file , space_dimension_file_name);
}

void GSM_vector::space_dimension_SDs_components_eigenvector_Jmin_copy_disk (
									    const bool full_common_vectors_used_in_file ,
									    const bool full_common_vectors_used_in_file_with_MPI_calls ,
									    const class correlated_state_str &PSI_qn) const
{
  space_dimension_eigenvector_Jmin_copy_disk (full_common_vectors_used_in_file , PSI_qn);

  SDs_components_eigenvector_Jmin_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , PSI_qn);
}

void GSM_vector::SDs_components_eigenvector_Jmin_copy_disk (
							    const bool full_common_vectors_used_in_file ,
							    const bool full_common_vectors_used_in_file_with_MPI_calls ,
							    const class correlated_state_str &PSI_qn) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const double M = GSM_vector_helper.get_M ();

  const string file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_Jmin" , PSI_qn , M);
  
  SDs_components_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , file_name);
}












void GSM_vector::copy_disk_indexed_name (
					 const bool full_common_vectors_used_in_file ,
					 const bool full_common_vectors_used_in_file_with_MPI_calls ,
					 const string &file_name_debut ,
					 const unsigned int index) const
{
  const string file_name = file_name_debut + make_string<unsigned int> (index);

  copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , file_name);
}

void GSM_vector::space_dimension_copy_disk (
					    const bool full_common_vectors_used_in_file ,
					    const string &space_dimension_file_name) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const unsigned long int total_space_dimension = GSM_vector_helper.get_total_space_dimension ();
  
  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();
  
  if (full_common_vectors_used_in_file)
    {  
      if (THIS_PROCESS == MASTER_PROCESS) dimension_copy_disk (space_dimension_file_name , total_space_dimension);
    }
  else
    dimension_copy_disk (space_dimension_file_name , space_dimension_process);
}

void GSM_vector::SDs_components_copy_disk (
					   const bool full_common_vectors_used_in_file ,
					   const bool full_common_vectors_used_in_file_with_MPI_calls ,
					   const string &file_name) const
{

  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  if (!full_common_vectors_used_in_file && full_common_vectors_used_in_file_with_MPI_calls)
    error_message_print_abort ("One cannot have full_common_vectors_used_in_file false and full_common_vectors_used_in_file_with_MPI_calls true in GSM_vector::SDs_components_copy_disk");
  
  if (full_common_vectors_used_in_file && full_common_vectors_used_in_file_with_MPI_calls)
    {
      const class GSM_vector &PSI = *this;
 
      class GSM_vector_helper_class PSI_full_helper;

      PSI_full_helper.allocate_fill_without_MPI_parallelization (GSM_vector_helper);
      
      class GSM_vector PSI_full(PSI_full_helper);

      PSI_full.full_vector_fill (PSI);
      
      if (THIS_PROCESS == MASTER_PROCESS) PSI_full.SDs_components_copy_disk (file_name);
    }
  else
    SDs_components_copy_disk (file_name);
}



void GSM_vector::SDs_components_copy_disk (const string &file_name) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();

  if (space == PROT_NEUT_Y)
    SDs_components_pn_copy_disk (file_name);
  else 
    SDs_components_pp_nn_copy_disk (file_name);
}




void GSM_vector::SDs_components_pn_copy_disk (const string &file_name) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM ();

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
	  
  const unsigned int Np_nljm = prot_Y_data.get_N_nljm_baryon ();
  const unsigned int Nn_nljm = neut_Y_data.get_N_nljm_baryon ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  const int ZYval = prot_Y_data.get_N_valence_baryons ();

  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();

  basic_copy_disk<TYPE> (file_name , space_dimension_process , table);

  class array<unsigned int> SDp_tab(space_dimension_process , ZYval);
  class array<unsigned int> SDn_tab(space_dimension_process , NYval);

  class Slater_determinant SDp(ZYval);
  class Slater_determinant SDn(NYval);
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP);
      
      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;
	  
	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p;
	  
	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
		  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
		  
		  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
		      
		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

		      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
			{
			  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
			  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  
			  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
			    {
			      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
			      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			
			      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
				{
				  const int iMn = iM - iMp;

				  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
				  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

				  if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

				  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
				    {
				      SDp = SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index);

				      const unsigned long int total_PSI_index_zero_SDp = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;
				  
				      for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
					{
					  const unsigned long int total_PSI_index = total_PSI_index_zero_SDp + SDn_index;

					  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
					    {
					      const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

					      SDn = SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index);
					      
					      for (int ip = 0 ; ip < ZYval ; ip++) SDp_tab(PSI_index , ip) = SDp[ip];
					      for (int in = 0 ; in < NYval ; in++) SDn_tab(PSI_index , in) = SDn[in];					  
					    }}}}}}}}}}}

  const string file_name_Np_nljm = file_name + "_Np_nljm.dat";
  const string file_name_Nn_nljm = file_name + "_Nn_nljm.dat";

  dimension_copy_disk (file_name_Np_nljm , Np_nljm);
  dimension_copy_disk (file_name_Nn_nljm , Nn_nljm);

  const string file_name_phi_p_table = file_name + "_phi_p_table.dat";
  const string file_name_phi_n_table = file_name + "_phi_n_table.dat";

  phi_p_table.copy_disk (file_name_phi_p_table);
  phi_n_table.copy_disk (file_name_phi_n_table);

  const string SDp_table_file_name = file_name + "_SDp_basis.dat";
  const string SDn_table_file_name = file_name + "_SDn_basis.dat";

  SDp_tab.copy_disk (SDp_table_file_name);
  SDn_tab.copy_disk (SDn_table_file_name);
}







void GSM_vector::SDs_components_pp_nn_copy_disk (const string &file_name) const
{ 
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int iM = GSM_vector_helper.get_iM ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<class nljm_struct> &phi_table = data.get_phi_table ();

  const unsigned int N_nljm = data.get_N_nljm_baryon ();

  const int N_valence_baryons = data.get_N_valence_baryons ();

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();

  const class array<unsigned int> &iC_min_process_tab = GSM_vector_helper.get_iC_min_process_tab ();
  const class array<unsigned int> &iC_max_process_tab = GSM_vector_helper.get_iC_max_process_tab ();
  
  basic_copy_disk<TYPE> (file_name , space_dimension_process , table);

  class array<unsigned int> SD_tab(space_dimension_process , N_valence_baryons);

  class Slater_determinant SD(N_valence_baryons);
  
  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int iC_min = iC_min_process_tab(n_scat);
      const unsigned int iC_max = iC_max_process_tab(n_scat);

      for (unsigned int iC = iC_min ; iC <= iC_max ; iC++)
	{      
	  const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
	  const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD = dimensions_SD_set(BP , S , 0 , n_scat , iC , iM);

	  if (dimension_SD == 0) continue;

	  const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions(n_scat , iC);

	  for (unsigned int SD_index = 0 ; SD_index < dimension_SD ; SD_index++)
	    {
	      const unsigned long int total_PSI_index = sum_dimensions_configuration_fixed + SD_index;

	      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
		{
		  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;	      

		  SD = SD_set(BP , S , 0 , n_scat , iC , iM , SD_index);

		  for (int i = 0 ; i < N_valence_baryons ; i++) SD_tab(PSI_index , i) = SD[i];
		}
	    }
	}
    }

  const string file_name_N_nljm = (space == PROT_Y_ONLY) ? (file_name + "_Np_nljm.dat") : (file_name + "_Nn_nljm.dat");

  dimension_copy_disk (file_name_N_nljm , N_nljm);

  const string file_name_phi_table = (space == PROT_Y_ONLY) ? (file_name + "_phi_p_table.dat") : (file_name + "_phi_n_table.dat");

  phi_table.copy_disk (file_name_phi_table);

  const string SD_table_file_name = (space == PROT_Y_ONLY) ? (file_name + "_SDp_basis.dat") : (file_name + "_SDn_basis.dat");

  SD_tab.copy_disk (SD_table_file_name);
}




void GSM_vector::space_dimension_SDs_components_copy_disk (
							   const bool full_common_vectors_used_in_file ,
							   const bool full_common_vectors_used_in_file_with_MPI_calls ,
							   const string &space_dimension_file_name ,
							   const string &file_name) const
{  
  space_dimension_copy_disk (full_common_vectors_used_in_file , space_dimension_file_name);

  SDs_components_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , file_name);
}










void GSM_vector::eigenvector_read_disk (
					const bool full_common_vectors_used_in_file ,
					const bool full_common_vectors_used_in_file_with_MPI_calls ,
					const class correlated_state_str &PSI_qn)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const double M = GSM_vector_helper.get_M ();

  const string file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector" , PSI_qn , M);
  
  read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , file_name);
}

void GSM_vector::SDs_components_eigenvector_read_disk (
						       const bool full_common_vectors_used_in_file ,
						       const bool full_common_vectors_used_in_file_with_MPI_calls ,
						       const class correlated_state_str &PSI_qn)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const double M = GSM_vector_helper.get_M ();

  const string space_dimension_file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_qn , M);

  const string file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector" , PSI_qn , M);
  
  SDs_components_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , space_dimension_file_name , file_name);
}

void GSM_vector::J_scheme_components_eigenvector_read_disk_M_scheme_conversion (
										const bool full_common_vectors_used_in_file ,
										const bool full_common_vectors_used_in_file_with_MPI_calls ,
										const class correlated_state_str &PSI_qn)
{
  const string space_dimension_file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_qn);

  const string file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector" , PSI_qn);
  
  const int J = make_int (PSI_qn.get_J ());

  J_scheme_components_read_disk_M_scheme_conversion (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , J , space_dimension_file_name , file_name);
}











void GSM_vector::eigenvector_good_T_read_disk (
					       const bool full_common_vectors_used_in_file ,
					       const bool full_common_vectors_used_in_file_with_MPI_calls ,
					       const class correlated_state_str &PSI_qn)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const double M = GSM_vector_helper.get_M ();

  const string file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_good_T" , PSI_qn , M);
  
  read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , file_name);
}

void GSM_vector::SDs_components_eigenvector_good_T_read_disk (
							      const bool full_common_vectors_used_in_file ,
							      const bool full_common_vectors_used_in_file_with_MPI_calls ,
							      const class correlated_state_str &PSI_qn)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const double M = GSM_vector_helper.get_M ();

  const string space_dimension_file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_good_T_dimension" , PSI_qn , M);

  const string file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_good_T" , PSI_qn , M);
  
  SDs_components_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , space_dimension_file_name , file_name);
}













void GSM_vector::eigenvector_Jmin_read_disk (
					     const bool full_common_vectors_used_in_file ,
					     const bool full_common_vectors_used_in_file_with_MPI_calls ,
					     const class correlated_state_str &PSI_qn)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const double M = GSM_vector_helper.get_M ();

  const string file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_Jmin" , PSI_qn , M);
  
  read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , file_name);
}

void GSM_vector::SDs_components_eigenvector_Jmin_read_disk (
							    const bool full_common_vectors_used_in_file ,
							    const bool full_common_vectors_used_in_file_with_MPI_calls ,
							    const class correlated_state_str &PSI_qn)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const double M = GSM_vector_helper.get_M ();

  const string space_dimension_file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_Jmin_dimension" , PSI_qn , M);

  const string file_name = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_Jmin" , PSI_qn , M);
  
  SDs_components_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , space_dimension_file_name , file_name);
}

















void GSM_vector::read_disk (
			    const bool full_common_vectors_used_in_file ,
			    const bool full_common_vectors_used_in_file_with_MPI_calls ,
			    const string &file_name)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const unsigned long int total_space_dimension = GSM_vector_helper.get_total_space_dimension ();
  
  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();

  zero ();

  if (!full_common_vectors_used_in_file && full_common_vectors_used_in_file_with_MPI_calls)
    error_message_print_abort ("One cannot have full_common_vectors_used_in_file false and full_common_vectors_used_in_file_with_MPI_calls true in GSM_vector::read_disk");
  
  if (full_common_vectors_used_in_file && full_common_vectors_used_in_file_with_MPI_calls)
    {
      class GSM_vector &PSI = *this;
      
      class GSM_vector_helper_class PSI_full_helper;

      PSI_full_helper.allocate_fill_without_MPI_parallelization (GSM_vector_helper);
 
      class GSM_vector PSI_full(PSI_full_helper);
	  
      if (THIS_PROCESS == MASTER_PROCESS) basic_read_disk<TYPE> (file_name , total_space_dimension , PSI_full.table);
 	  
#ifdef UseMPI
      PSI_full.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
      
      PSI.partitioned_vector_fill (PSI_full);
    }
  else
    basic_read_disk<TYPE> (file_name , space_dimension_process , table);
}





void GSM_vector::read_disk_indexed_name (
					 const bool full_common_vectors_used_in_file ,
					 const bool full_common_vectors_used_in_file_with_MPI_calls ,
					 const string &file_name_debut ,
					 const unsigned int index)
{
  const string file_name = file_name_debut + make_string<unsigned int> (index);

  read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file_with_MPI_calls , file_name);
}


void GSM_vector::SDs_components_read_disk (
					   const bool full_common_vectors_used_in_file ,
					   const bool full_common_vectors_used_in_file_with_MPI_calls ,
					   const string &space_dimension_file_name ,
					   const string &file_name)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  zero ();
  
  if (!full_common_vectors_used_in_file && full_common_vectors_used_in_file_with_MPI_calls)
    error_message_print_abort ("One cannot have full_common_vectors_used_in_file false and full_common_vectors_used_in_file_with_MPI_calls true in GSM_vector::SDs_components_read_disk (1)");
  
  if (full_common_vectors_used_in_file && full_common_vectors_used_in_file_with_MPI_calls)
    {
      class GSM_vector &PSI = *this;
			
      class GSM_vector_helper_class PSI_full_helper;
      PSI_full_helper.allocate_fill_without_MPI_parallelization (GSM_vector_helper);
 
      class GSM_vector PSI_full(PSI_full_helper);
	  
      if (THIS_PROCESS == MASTER_PROCESS) PSI_full.SDs_components_read_disk (space_dimension_file_name , file_name);
	  	  
#ifdef UseMPI
      PSI_full.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif

      PSI.partitioned_vector_fill (PSI_full);
    }
  else
    SDs_components_read_disk (space_dimension_file_name , file_name);
}




void GSM_vector::SDs_components_read_disk (
					   const string &space_dimension_file_name ,
					   const string &file_name)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();

  if (space == PROT_NEUT_Y)
    SDs_components_pn_read_disk (space_dimension_file_name , file_name);
  else 
    SDs_components_pp_nn_read_disk (space_dimension_file_name , file_name);
}



void GSM_vector::SDs_components_pn_read_disk (
					      const string &space_dimension_file_name ,
					      const string &file_name)
{ 
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();

  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 
 
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 

  const int iM = GSM_vector_helper.get_iM (); 

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class array<unsigned int> &dimensions_configuration_set_p = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_set_n = neut_Y_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set_p = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_set_n = neut_Y_data.get_configuration_set ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const class one_body_indices_str &one_body_indices_p = prot_Y_data.get_one_body_indices ();
  const class one_body_indices_str &one_body_indices_n = neut_Y_data.get_one_body_indices ();

  const class array<class lj_table<int> > &nmax_lj_tabs_p = prot_Y_data.get_nmax_lj_tabs ();
  const class array<class lj_table<int> > &nmax_lj_tabs_n = neut_Y_data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_p = prot_Y_data.get_is_it_valence_shell_tabs ();
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_n = neut_Y_data.get_is_it_valence_shell_tabs ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  class configuration Cp(ZYval);
  class configuration Cn(NYval);

  class configuration Cp_try(ZYval);
  class configuration Cn_try(NYval);

  class Slater_determinant SDp(ZYval);
  class Slater_determinant SDn(NYval);

  class Slater_determinant SDp_try(ZYval);
  class Slater_determinant SDn_try(NYval);

  const string file_name_Np_nljm = file_name + "_Np_nljm.dat";
  const string file_name_Nn_nljm = file_name + "_Nn_nljm.dat";

  const string file_name_phi_p_table = file_name + "_phi_p_table.dat";
  const string file_name_phi_n_table = file_name + "_phi_n_table.dat";

  const string SDp_table_file_name = file_name + "_SDp_basis.dat";
  const string SDn_table_file_name = file_name + "_SDn_basis.dat";

  const unsigned int space_dimension_from_file = space_dimension_read_disk (ZYval , NYval , space_dimension_file_name);

  const unsigned int Np_nljm_from_file = dimension_read_disk (file_name_Np_nljm);
  const unsigned int Nn_nljm_from_file = dimension_read_disk (file_name_Nn_nljm);

  class array<class nljm_struct> phi_p_table_from_file(Np_nljm_from_file);
  class array<class nljm_struct> phi_n_table_from_file(Nn_nljm_from_file);

  phi_p_table_from_file.read_disk (file_name_phi_p_table);
  phi_n_table_from_file.read_disk (file_name_phi_n_table);

  class array<TYPE> PSI_component_tab_from_file(space_dimension_from_file);
  
  PSI_component_tab_from_file.read_disk (file_name);

  class array<unsigned int> SDp_tab_from_file(space_dimension_from_file , ZYval);
  class array<unsigned int> SDn_tab_from_file(space_dimension_from_file , NYval);

  SDp_tab_from_file.read_disk (SDp_table_file_name);
  SDn_tab_from_file.read_disk (SDn_table_file_name);

  class GSM_vector &PSI = *this;

  PSI = 0.0;   

  for (unsigned int PSI_index_from_file = 0 ; PSI_index_from_file < space_dimension_from_file ; PSI_index_from_file++)
    {
      for (int ip = 0 ; ip < ZYval ; ip++) SDp[ip] = SDp_tab_from_file(PSI_index_from_file , ip);
      for (int in = 0 ; in < NYval ; in++) SDn[in] = SDn_tab_from_file(PSI_index_from_file , in);
           
      if (!SDp.is_it_in_new_space (phi_p_table_from_file , nmax_lj_tabs_p , is_it_valence_shell_tabs_p)) continue;
      if (!SDn.is_it_in_new_space (phi_n_table_from_file , nmax_lj_tabs_n , is_it_valence_shell_tabs_n)) continue;

      unsigned int bin_phase_p = 0;
      unsigned int bin_phase_n = 0;

      SDp.reindexation_and_bin_phase (phi_p_table_from_file , one_body_indices_p , bin_phase_p);
      SDn.reindexation_and_bin_phase (phi_n_table_from_file , one_body_indices_n , bin_phase_n);

      Cp.get_SD_configuration(phi_p_table , SDp);
      Cn.get_SD_configuration(phi_n_table , SDn);

      const int n_holes_p = Cp.n_holes_determine (shells_qn_p);
      const int n_holes_n = Cn.n_holes_determine (shells_qn_n);
      
      const int n_scat_p = Cp.n_scat_determine (shells_qn_p);
      const int n_scat_n = Cn.n_scat_determine (shells_qn_n);      
      
      const int Ep_hw = Cp.E_hw_determine (shells_qn_p);
      const int En_hw = Cn.E_hw_determine (shells_qn_n);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;	  
      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
	  
      const unsigned int BPp = Cp.BP_determine (shells_qn_p);

      const unsigned int BPn = binary_parity_product (BP , BPp);

      const int Sp = Cp.strangeness_determine (shells_qn_p);
	  
      const int Sn = S - Sp;
      
      const int n_spec_p = Cp.n_spec_determine (shells_qn_p);
	  
      const int n_spec_n = n_spec_max - n_spec_p;
      
      const unsigned int iCp = Cp.index_search (BPp , Sp , n_spec_p , n_scat_p , dimensions_configuration_set_p , configuration_set_p , Cp_try);
      const unsigned int iCn = Cn.index_search (BPn , Sn , n_spec_n , n_scat_n , dimensions_configuration_set_n , configuration_set_n , Cn_try);

      const int iMp = SDp.iM_determine (phi_p_table);

      const int iMn = iM - iMp;

      const unsigned int SDp_index = SDp.index_search (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , dimensions_SDp_set , SDp_set , SDp_try);
      const unsigned int SDn_index = SDn.index_search (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , dimensions_SDn_set , SDn_set , SDn_try);

      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

      const unsigned long int total_PSI_index = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index + SDn_index;

      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
	{
	  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

	  PSI[PSI_index] = (bin_phase_p == bin_phase_n) ? (PSI_component_tab_from_file(PSI_index_from_file)) : (-PSI_component_tab_from_file(PSI_index_from_file));
	}
    }
}










void GSM_vector::SDs_components_pp_nn_read_disk (
						 const string &space_dimension_file_name ,
						 const string &file_name)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int iM = GSM_vector_helper.get_iM ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  const class array<class nljm_struct> &phi_table = data.get_phi_table ();

  const class one_body_indices_str &one_body_indices = data.get_one_body_indices ();

  const class array<class lj_table<int> > &nmax_lj_tabs = data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs = data.get_is_it_valence_shell_tabs ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  class configuration C(N_valence_baryons);

  class configuration C_try(N_valence_baryons);

  class Slater_determinant SD(N_valence_baryons);

  class Slater_determinant SD_try(N_valence_baryons);

  const string file_name_N_nljm = (space == PROT_Y_ONLY) ? (file_name + "_Np_nljm.dat") : (file_name + "_Nn_nljm.dat");

  const string file_name_phi_table = (space == PROT_Y_ONLY) ? (file_name + "_phi_p_table.dat") : (file_name + "_phi_n_table.dat");

  const string SD_table_file_name = (space == PROT_Y_ONLY) ? (file_name + "_SDp_basis.dat") : (file_name + "_SDn_basis.dat");

  const unsigned int space_dimension_from_file = space_dimension_read_disk (ZYval , NYval , space_dimension_file_name);

  const unsigned int N_nljm_from_file = dimension_read_disk (file_name_N_nljm);

  class array<class nljm_struct> phi_table_from_file(N_nljm_from_file);

  phi_table_from_file.read_disk (file_name_phi_table);

  class array<TYPE> PSI_component_tab_from_file(space_dimension_from_file);

  PSI_component_tab_from_file.read_disk (file_name);

  class array<unsigned int> SD_tab_from_file(space_dimension_from_file , N_valence_baryons);

  SD_tab_from_file.read_disk (SD_table_file_name);

  class GSM_vector &PSI = *this;

  PSI = 0.0;

  for (unsigned int PSI_index_from_file = 0 ; PSI_index_from_file < space_dimension_from_file ; PSI_index_from_file++)
    {
      for (int i = 0 ; i < N_valence_baryons ; i++) SD[i] = SD_tab_from_file(PSI_index_from_file , i);

      if (!SD.is_it_in_new_space (phi_table_from_file , nmax_lj_tabs , is_it_valence_shell_tabs)) continue;

      unsigned int bin_phase = 0;

      SD.reindexation_and_bin_phase (phi_table_from_file , one_body_indices , bin_phase);

      C.get_SD_configuration (phi_table , SD);

      const int E_hw = C.E_hw_determine (shells_qn);

      const int n_holes = C.n_holes_determine (shells_qn);
      
      const int n_scat = C.n_scat_determine (shells_qn);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
	
      const unsigned int iC = C.index_search (BP , S , 0 , n_scat , dimensions_configuration_set , configuration_set , C_try);

      const unsigned int SD_index = SD.index_search (BP , S , 0 , n_scat , iC , iM , dimensions_SD_set , SD_set , SD_try);

      const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions(n_scat , iC);

      const unsigned long int total_PSI_index = sum_dimensions_configuration_fixed + SD_index;

      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
	{
	  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

	  const int phase = parity_from_binary_parity (bin_phase);
	  
	  PSI[PSI_index] = (phase == 1) ? (PSI_component_tab_from_file(PSI_index_from_file)) : (-PSI_component_tab_from_file(PSI_index_from_file));
	}
    }
}


void GSM_vector::J_scheme_components_read_disk_M_scheme_conversion (
								    const bool full_common_vectors_used_in_file ,
								    const bool full_common_vectors_used_in_file_with_MPI_calls ,
								    const int J , 
								    const string &space_dimension_file_name ,
								    const string &file_name)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  zero ();
  
  if (!full_common_vectors_used_in_file && full_common_vectors_used_in_file_with_MPI_calls)
    error_message_print_abort ("One cannot have full_common_vectors_used_in_file false and full_common_vectors_used_in_file_with_MPI_calls true in GSM_vector::J_scheme_components_read_disk_M_scheme_conversion (1)");
  
  if (full_common_vectors_used_in_file && full_common_vectors_used_in_file_with_MPI_calls)
    {
      class GSM_vector &PSI = *this;
			
      class GSM_vector_helper_class PSI_full_helper;
      PSI_full_helper.allocate_fill_without_MPI_parallelization (GSM_vector_helper);
 
      class GSM_vector PSI_full(PSI_full_helper);
	  
      if (THIS_PROCESS == MASTER_PROCESS) PSI_full.J_scheme_components_read_disk_M_scheme_conversion (J , space_dimension_file_name , file_name);
	  	  
#ifdef UseMPI
      PSI_full.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif

      PSI.partitioned_vector_fill (PSI_full);
    }
  else
    J_scheme_components_read_disk_M_scheme_conversion (J , space_dimension_file_name , file_name);
}







void GSM_vector::J_scheme_components_read_disk_M_scheme_conversion (
								    const int J , 
								    const string &space_dimension_file_name ,
								    const string &file_name)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();

  if (space == PROT_NEUT_Y)
    J_scheme_components_pn_read_disk_M_scheme_conversion (J , space_dimension_file_name , file_name);
  else 
    J_scheme_components_pp_nn_read_disk_M_scheme_conversion (J , space_dimension_file_name , file_name);
}





void GSM_vector::J_scheme_components_pn_read_disk_M_scheme_conversion (
								       const int J , 
								       const string &space_dimension_file_name ,
								       const string &file_name)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph (); 

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data (); 

  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n (); 

  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 

  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM (); 

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class array<unsigned int> &dimensions_configuration_set_p = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_set_n = neut_Y_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set_p = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_set_n = neut_Y_data.get_configuration_set ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_p = prot_Y_data.get_one_body_indices ();
  const class one_body_indices_str &one_body_indices_n = neut_Y_data.get_one_body_indices ();

  const class array<class nlj_table<unsigned int> > &shells_indices_p_tab = prot_Y_data.get_shells_indices_tab ();
  const class array<class nlj_table<unsigned int> > &shells_indices_n_tab = neut_Y_data.get_shells_indices_tab ();

  const class array<class lj_table<int> > &nmax_lj_tabs_p = prot_Y_data.get_nmax_lj_tabs ();
  const class array<class lj_table<int> > &nmax_lj_tabs_n = neut_Y_data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_p = prot_Y_data.get_is_it_valence_shell_tabs ();
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_n = neut_Y_data.get_is_it_valence_shell_tabs ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  const int Aval = ZYval + NYval;

  if (Aval != 2) error_message_print_abort ("Two-valence-nucleon systems only in GSM_vector::J_scheme_components_pn_read_disk_M_scheme_conversion");

  const double mp_max = prot_Y_data.get_m_max ();
  const double mn_max = neut_Y_data.get_m_max ();
				   
  const double m_max = max (mp_max , mn_max);
				   
  const class CG_str CGs(m_max);

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  class configuration Cp(ZYval);
  class configuration Cn(NYval);

  class configuration Cp_try(ZYval);
  class configuration Cn_try(NYval);

  class Slater_determinant SDp(ZYval);
  class Slater_determinant SDn(NYval);

  class Slater_determinant SDp_try(ZYval);
  class Slater_determinant SDn_try(NYval);

  const unsigned int space_dimension_from_file = space_dimension_read_disk (ZYval , NYval , space_dimension_file_name);

  const string file_name_Np_nlj = file_name + "_Np_nlj.dat";
  const string file_name_Nn_nlj = file_name + "_Nn_nlj.dat";
  
  const unsigned int Np_nlj_from_file = dimension_read_disk (file_name_Np_nlj);
  const unsigned int Nn_nlj_from_file = dimension_read_disk (file_name_Nn_nlj);

  class array<class nlj_struct> shells_qn_p_from_file(Np_nlj_from_file);
  class array<class nlj_struct> shells_qn_n_from_file(Nn_nlj_from_file);
  
  const string file_name_shells_qn_p = file_name + "_shells_quantum_numbers_p.dat";
  const string file_name_shells_qn_n = file_name + "_shells_quantum_numbers_n.dat";
  
  shells_qn_p_from_file.read_disk (file_name_shells_qn_p);
  shells_qn_n_from_file.read_disk (file_name_shells_qn_n);
				   
  class array<TYPE> PSI_J_coupled_component_tab_from_file(space_dimension_from_file);
				   
  PSI_J_coupled_component_tab_from_file.read_disk (file_name);
				   
  class array<class pair_str> pairs_from_file(space_dimension_from_file);
				   
  const string eigenvector_pairs_file_name = file_name + "_pair_basis.dat";
				   
  pairs_from_file.read_disk (eigenvector_pairs_file_name);

  class GSM_vector &PSI = *this;

  PSI = 0.0;
				   
  for (unsigned int PSI_index_from_file = 0 ; PSI_index_from_file < space_dimension_from_file ; PSI_index_from_file++)
    {
      class pair_str pair = pairs_from_file(PSI_index_from_file);

      const bool is_pair_in_space = pair.is_it_in_new_space (shells_qn_p_from_file , shells_qn_n_from_file , nmax_lj_tabs_p , nmax_lj_tabs_n , is_it_valence_shell_tabs_p , is_it_valence_shell_tabs_n);

      if (is_pair_in_space)
	{
	  int phase = 1;
	  
	  pair.reindexation_and_phase (shells_qn_p_from_file , shells_qn_n_from_file , shells_indices_p_tab , shells_indices_n_tab , J , phase);
	  
	  const unsigned int p_shell_index = pair.get_left (); 
	  const unsigned int n_shell_index = pair.get_right (); 

	  Cp[0] = p_shell_index;
	  Cn[0] = n_shell_index;

	  const int n_holes_p = Cp.n_holes_determine (shells_qn_p);
	  const int n_holes_n = Cn.n_holes_determine (shells_qn_n);
	  
	  const int n_scat_p = Cp.n_scat_determine (shells_qn_p);
	  const int n_scat_n = Cn.n_scat_determine (shells_qn_n);
	  
	  const int Ep_hw = Cp.E_hw_determine (shells_qn_p);
	  const int En_hw = Cn.E_hw_determine (shells_qn_n);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

	  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int BPp = Cp.BP_determine (shells_qn_p);
	  
	  const unsigned int BPn = binary_parity_product (BP , BPp);

	  const int Sp = Cp.strangeness_determine (shells_qn_p);
	  
	  const int Sn = S - Sp;
      
	  const int n_spec_p = Cp.n_spec_determine (shells_qn_p);
	  
	  const int n_spec_n = n_spec_max - n_spec_p;

	  const unsigned int iCp = Cp.index_search (BPp , Sp , n_spec_p , n_scat_p , dimensions_configuration_set_p , configuration_set_p , Cp_try);
	  const unsigned int iCn = Cn.index_search (BPn , Sn , n_spec_n , n_scat_n , dimensions_configuration_set_n , configuration_set_n , Cn_try);

	  const class nlj_struct &shell_qn_p = shells_qn_p(p_shell_index);
	  const class nlj_struct &shell_qn_n = shells_qn_n(n_shell_index);

	  const double jp = shell_qn_p.get_j ();
	  const double jn = shell_qn_n.get_j ();

	  const int mp_number = shell_qn_p.m_number_determine ();
	  const int mn_number = shell_qn_n.m_number_determine ();

	  for (int mp_index = 0 ; mp_index < mp_number ; mp_index++)
	    for (int mn_index = 0 ; mn_index < mn_number ; mn_index++)
	      {
		const double mp = mp_index - jp;
		const double mn = mn_index - jn;
		    
		const int imp = make_int (mp + mp_max);
		const int imn = make_int (mn + mn_max);

		const int iMp = imp;
		const int iMn = imn;

		const int iM_pair = iMp + iMn;
		    
		if (iM_pair == iM)
		  {			
		    const unsigned int phi_p_index = one_body_indices_p(p_shell_index , imp);
		    const unsigned int phi_n_index = one_body_indices_n(n_shell_index , imn);

		    SDp[0] = phi_p_index;
		    SDn[0] = phi_n_index;

		    const unsigned int SDp_index = SDp.index_search (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , dimensions_SDp_set , SDp_set , SDp_try);
		    const unsigned int SDn_index = SDn.index_search (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , dimensions_SDn_set , SDn_set , SDn_try);
			
		    const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);
			
		    const unsigned int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

		    const unsigned long int total_PSI_index = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index + SDn_index;
	  
		    if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
		      {
			const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

			const double M = mp + mn;

			const double CG = CGs(jp , mp , jn , mn , J , M);

			const double phase_CG = phase*CG;
			    
			const TYPE PSI_J_coupled_component = PSI_J_coupled_component_tab_from_file(PSI_index_from_file);

			PSI[PSI_index] = phase_CG * PSI_J_coupled_component;
		      }}}}}
}










void GSM_vector::J_scheme_components_pp_nn_read_disk_M_scheme_conversion (
									  const int J , 
									  const string &space_dimension_file_name ,
									  const string &file_name)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph (); 

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data (); 

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int iM = GSM_vector_helper.get_iM ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();

  if (N_valence_baryons != 2) error_message_print_abort ("Two-valence-nucleon systems only in GSM_vector::J_scheme_components_pp_nn_read_disk_M_scheme_conversion");

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices = data.get_one_body_indices ();

  const class array<class nlj_table<unsigned int> > &shells_indices_tab = data.get_shells_indices_tab ();

  const class array<class lj_table<int> > &nmax_lj_tabs = data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs = data.get_is_it_valence_shell_tabs ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  const double m_max = data.get_m_max ();

  class configuration C(N_valence_baryons);

  class configuration C_try(N_valence_baryons);

  class Slater_determinant SD(N_valence_baryons);

  class Slater_determinant SD_try(N_valence_baryons);

  const unsigned int space_dimension_from_file = space_dimension_read_disk (ZYval , NYval , space_dimension_file_name);

  const string file_name_N_nlj = (space == PROT_Y_ONLY) ? (file_name + "_Np_nlj.dat") : (file_name + "_Nn_nlj.dat");
  
  const unsigned int N_nlj_from_file = dimension_read_disk (file_name_N_nlj);

  class array<class nlj_struct> shells_qn_from_file(N_nlj_from_file);

  const string file_name_shells_qn = (space == PROT_Y_ONLY) ? (file_name + "_shells_quantum_numbers_p.dat") : (file_name + "_shells_quantum_numbers_n.dat");
  
  shells_qn_from_file.read_disk  (file_name_shells_qn);
  
  class array<TYPE> PSI_J_coupled_component_tab_from_file(space_dimension_from_file);

  PSI_J_coupled_component_tab_from_file.read_disk (file_name);

  class array<class pair_str> pairs_from_file(space_dimension_from_file);

  const string eigenvector_pairs_file_name = file_name + "_pair_basis.dat";

  pairs_from_file.read_disk (eigenvector_pairs_file_name);

  const class CG_str CGs(m_max);

  class GSM_vector &PSI = *this;

  PSI = 0.0;

  for (unsigned int PSI_index_from_file = 0 ; PSI_index_from_file < space_dimension_from_file ; PSI_index_from_file++)
    {
      class pair_str pair = pairs_from_file(PSI_index_from_file);

      const bool is_pair_in_space = pair.is_it_in_new_space (shells_qn_from_file , shells_qn_from_file , nmax_lj_tabs , nmax_lj_tabs , is_it_valence_shell_tabs , is_it_valence_shell_tabs);

      if (is_pair_in_space)
	{
	  int phase = 1;
	  
	  pair.reindexation_and_phase (shells_qn_from_file , shells_qn_from_file , shells_indices_tab , shells_indices_tab , J , phase);
	  
	  const unsigned int shell_index_left = pair.get_left (); 
	  const unsigned int shell_index_right = pair.get_right (); 

	  const double antisymmetric_norm = (shell_index_left == shell_index_right) ? (M_SQRT2) : (1.0);

	  const double phase_antisymmetric_norm = phase*antisymmetric_norm;

	  C[0] = shell_index_left;
	  C[1] = shell_index_right;

	  const int E_hw = C.E_hw_determine (shells_qn);

	  const int n_holes = C.n_holes_determine (shells_qn);
	  
	  const int n_scat = C.n_scat_determine (shells_qn);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int iC = C.index_search (BP , S , 0 , n_scat , dimensions_configuration_set , configuration_set , C_try);

	  const class nlj_struct &shell_qn_left = shells_qn(shell_index_left);
	  const class nlj_struct &shell_qn_right = shells_qn(shell_index_right);

	  const double j_left = shell_qn_left.get_j ();
	  const double j_right = shell_qn_right.get_j ();

	  const int m_left_number = shell_qn_left.m_number_determine ();
	  const int m_right_number = shell_qn_right.m_number_determine ();

	  for (int m_index_left = 0 ; m_index_left < m_left_number ; m_index_left++)
	    for (int m_index_right = 0 ; m_index_right < m_right_number ; m_index_right++)
	      {
		const double m_left = m_index_left - j_left;
		const double m_right = m_index_right - j_right;

		const int im_left = make_int (m_left + m_max);
		const int im_right = make_int (m_right + m_max);

		const int iM_pair = im_left + im_right;
	  
		if (iM_pair == iM)
		  {
		    const unsigned int phi_index_left = one_body_indices(shell_index_left , im_left);
		    const unsigned int phi_index_right = one_body_indices(shell_index_right , im_right);
			
		    if (phi_index_left < phi_index_right)
		      {
			SD[0] = phi_index_left;
			SD[1] = phi_index_right;

			const unsigned int SD_index = SD.index_search (BP , S , 0 , n_scat , iC , iM , dimensions_SD_set , SD_set , SD_try);

			const unsigned int sum_dimensions_configuration_fixed = sum_dimensions(n_scat , iC);
		  
			const unsigned long int total_PSI_index = sum_dimensions_configuration_fixed + SD_index;

			if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
			  {
			    const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

			    const double M = m_left + m_right;

			    const double CG = CGs(j_left , m_left , j_right , m_right , J , M);

			    const double phase_antisymmetric_norm_CG = phase_antisymmetric_norm*CG;
			    
			    const TYPE PSI_J_coupled_component = PSI_J_coupled_component_tab_from_file(PSI_index_from_file);

			    PSI[PSI_index] = phase_antisymmetric_norm_CG * PSI_J_coupled_component;
			  }}}}}}
}








class Slater_determinant GSM_vector::basis_SD_from_index_pn (
							     const enum space_type basis_space , 
							     const unsigned long int total_PSI_index) const
{ 
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();

  const int iM = GSM_vector_helper.get_iM ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP);
      
      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;
	  
	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p;
      
	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
		  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);

		  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	  
		      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
			{
			  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
			  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);

			  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
			    {
			      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
			      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			
			      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
				{
				  const int iMn = iM - iMp;

				  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
				  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);
			      
				  if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

				  const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;
				  const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

				  const unsigned long int total_PSI_index_min = sum_dimensions_configuration_Mp_Mn_fixed;
				  const unsigned long int total_PSI_index_max = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*dimension_SDp_minus_one + dimension_SDn_minus_one;

				  if ((total_PSI_index >= total_PSI_index_min) && (total_PSI_index <= total_PSI_index_max))
				    {
				      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
					{
					  const unsigned long int total_PSI_index_min_SDp_fixed = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;
					  const unsigned long int total_PSI_index_max_SDp_fixed = total_PSI_index_min_SDp_fixed + dimension_SDn_minus_one;

					  if ((total_PSI_index >= total_PSI_index_min_SDp_fixed) && (total_PSI_index <= total_PSI_index_max_SDp_fixed))
					    {
					      for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
						{
						  const unsigned long int total_PSI_current_index = total_PSI_index_min_SDp_fixed + SDn_index;

						  if (total_PSI_current_index == total_PSI_index) 
						    {
						      switch (basis_space)
							{
							case PROT_Y_ONLY: return SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index);
							case NEUT_Y_ONLY: return SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index);
						      
							default: abort_all ();
							}}}}}}}}}}}}}}

  error_message_print_abort ("No basis SD state found (pn)");

  class Slater_determinant dummy_SD;

  return dummy_SD;
}




class Slater_determinant GSM_vector::basis_SD_from_index_pp_nn (
								const enum space_type basis_space , 
								const unsigned long int total_PSI_index) const
{ 
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();

  if (basis_space != space) error_message_print_abort ("space and basis_space are different in GSM_vector::basis_SD_from_index_pp_nn");

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int iM = GSM_vector_helper.get_iM ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &iC_min_process_tab = GSM_vector_helper.get_iC_min_process_tab ();
  const class array<unsigned int> &iC_max_process_tab = GSM_vector_helper.get_iC_max_process_tab ();
  
  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++) 
    {
      const unsigned int iC_min = iC_min_process_tab(n_scat);
      const unsigned int iC_max = iC_max_process_tab(n_scat);

      for (unsigned int iC = iC_min ; iC <= iC_max ; iC++)
	{    
	  const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
	  const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD = dimensions_SD_set(BP , S , 0 , n_scat , iC , iM);

	  if (dimension_SD == 0) continue;

	  const unsigned int dimension_SD_minus_one = dimension_SD - 1;
	  
	  const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions(n_scat , iC);

	  const unsigned long int total_PSI_index_min = sum_dimensions_configuration_fixed;
	  const unsigned long int total_PSI_index_max = sum_dimensions_configuration_fixed + dimension_SD_minus_one;

	  if ((total_PSI_index >= total_PSI_index_min) && (total_PSI_index <= total_PSI_index_max))
	    {
	      for (unsigned int SD_index = 0 ; SD_index < dimension_SD ; SD_index++)
		{
		  const unsigned long int total_PSI_current_index = sum_dimensions_configuration_fixed + SD_index;
		  
		  if (total_PSI_current_index == total_PSI_index) return SD_set(BP , S , 0 , n_scat , iC , iM , SD_index);
		}
	    }
	}
    }

  error_message_print_abort ("No basis SD state found (pp nn)");

  class Slater_determinant dummy_SD;

  return dummy_SD;
}



class Slater_determinant GSM_vector::basis_SD_from_index (
							  const enum space_type basis_space , 
							  const unsigned long int total_PSI_index) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();

  if (space == PROT_NEUT_Y) 
    return basis_SD_from_index_pn (basis_space , total_PSI_index);
  else
    return basis_SD_from_index_pp_nn (basis_space , total_PSI_index);
}




void GSM_vector::print_pn () const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
      
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM (); 

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();

  const class GSM_vector &PSI = *this;

  class Slater_determinant SDp(ZYval);
  class Slater_determinant SDn(NYval);
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP);
      
      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;
	  
	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p;

	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
		  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  
		  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
		      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
			{
			  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
			  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  
			  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
			    {
			      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
			      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		      
			      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
				{
				  const int iMn = iM - iMp;

				  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
				  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

				  if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

				  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
				    {
				      SDp = SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index);

				      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;

				      for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
					{
					  SDn = SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index);

					  const unsigned long int total_PSI_index = total_PSI_index_zero + SDn_index;

					  const TYPE PSI_component = PSI[total_PSI_index];

					  if (inf_norm (PSI_component) > precision)
					    {
					      cout << "P:" , SDp.print (phi_p_table);
					      cout << "N:" , SDn.print (phi_n_table);

					      cout << PSI_component << endl << endl;
					    }}}}}}}}}}}
}






void GSM_vector::print_pp_nn () const
{ 
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int iM = GSM_vector_helper.get_iM ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();
      
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array<class nljm_struct> &phi_table = data.get_phi_table ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &iC_min_process_tab = GSM_vector_helper.get_iC_min_process_tab ();
  const class array<unsigned int> &iC_max_process_tab = GSM_vector_helper.get_iC_max_process_tab ();
  
  const class GSM_vector &PSI = *this;

  class Slater_determinant SD(N_valence_baryons);
  
  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++) 
    {
      const unsigned int iC_min = iC_min_process_tab(n_scat);
      const unsigned int iC_max = iC_max_process_tab(n_scat);
      
      for (unsigned int iC = iC_min ; iC <= iC_max ; iC++)
	{
	  const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
	  const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD = dimensions_SD_set(BP , S , 0 , n_scat , iC , iM);

	  if (dimension_SD == 0) continue;

	  const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions(n_scat , iC);

	  for (unsigned int SD_index = 0 ; SD_index < dimension_SD ; SD_index++)
	    {
	      SD = SD_set(BP , S , 0 , n_scat , iC , iM , SD_index); 

	      const unsigned long int total_PSI_index = sum_dimensions_configuration_fixed + SD_index;

	      const TYPE PSI_component = PSI[total_PSI_index];

	      if (inf_norm (PSI_component) > precision)
		{
		  SD.print (phi_table);

		  cout << PSI_component << endl << endl;
		}
	    }
	}
    }
}




void GSM_vector::print () const
{
  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("GSM_vector::print available with serial calculation only");

  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();

  if (space == PROT_NEUT_Y) 
    print_pn ();
  else
    print_pp_nn ();
}














void GSM_vector::orthogonalization_disk (
					 const bool is_there_cout_detailed ,
					 const bool is_it_J2_projection ,
					 const unsigned int i , 
					 class array<class GSM_vector> &V_tab)
{ 
  if (i == 0) return;
  
  class GSM_vector &Vi = *this;
  
  const string node_string = node_string_determine (false , THIS_PROCESS);

  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_detailed) ? (absolute_time_determine ()) : (NADA);
  
  const unsigned int vectors_subset_number = i/NUMBER_OF_THREADS;

  for (unsigned int vectors_subset_index = 0 ; vectors_subset_index <= vectors_subset_number ; vectors_subset_index++)
    {
      const unsigned int ii_debut = vectors_subset_index*NUMBER_OF_THREADS;

#ifdef UseOpenMP
#pragma omp parallel default(shared) if (is_it_OpenMP_parallelized)
#endif
      {
	const unsigned int this_thread = OpenMP_thread_number_determine ();

	const unsigned int ii = ii_debut + this_thread;

	if (ii < i)
	  {
	    class GSM_vector &Vii = V_tab(this_thread);

	    if (is_it_J2_projection)
	      Vii.read_disk_indexed_name (false , false , STORAGE_DIR + node_string + "Vp" , ii);
	    else
	      Vii.read_disk_indexed_name (false , false , STORAGE_DIR + node_string + "V" , ii);
	  }
      }

      for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++)
	{
	  const unsigned int ii = ii_debut + i_thread;

	  if (ii < i)
	    {
	      const class GSM_vector &Vii = V_tab(i_thread);

	      const TYPE Vi_scalar_Vii = (Vi*Vii);

	      Vi -= Vi_scalar_Vii*Vii;
	    }
	}
    }	


  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_detailed)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time;
      
      cout << "Orthogonalization applied (GSM vectors stored on disk). time:" << relative_time << " s" << endl;
    }
}






// Projection of the vector on good J with the Lowdin method: PJ|PSI> = \prod_{Jc != J} [J^2 - Jc.(Jc+1)]/[J(J+1) - Jc(Jc+1)]|PSI>

void GSM_vector::good_J_Lowdin (
				const bool is_there_cout_detailed , 
				const class J2_class &J2 , 
				const double J , 
				class GSM_vector &PSI_temp)
{
  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_detailed) ? (absolute_time_determine ()) : (NADA);
  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const double M = GSM_vector_helper.get_M ();

  const double Jmax = GSM_vector_helper.get_Jmax ();

  const int Jc_index_max = make_int (Jmax - M);

  const int J_index = make_int (J - M);
  
  const double J_J_plus_one = J*(J + 1.0);

  class GSM_vector &PSI = *this;

  PSI_temp = PSI;

  for (int Jc_index = 0 ; Jc_index <= Jc_index_max ; Jc_index++)
    {
      if (Jc_index != J_index)
	{
	  const double Jc = Jc_index + M;

	  const double Jc_Jc_plus_one = Jc*(Jc + 1.0);

	  PSI = (J2 - Jc_Jc_plus_one)*PSI_temp;
    
	  PSI /= J_J_plus_one - Jc_Jc_plus_one;

	  if (Jc_index < Jc_index_max) PSI_temp = PSI;
	}
    }
  
  PSI.normalization ();

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_detailed)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time;
	  
      cout << "J^2 projection applied (Lowdin). time:" << relative_time << " s" << endl;
    }
}










void GSM_vector::project_good_J (
				 const bool is_there_cout_detailed , 
				 const class J2_class &J2 , 
				 const double J ,
				 const unsigned int J_number ,
				 const bool is_it_Lowdin ,
				 const bool are_GSM_vectors_stored_on_disk ,
				 class array<class GSM_vector> &Vp_tab , 
				 class GSM_vector &Vstore)
{
  class GSM_vector &PSI = *this;
  
  const double J_coupling_precision = J2.J_coupling_precision_calc (PSI , J , Vstore);

  if (J_coupling_precision > precision) 
    {
      if (is_it_Lowdin)
	PSI.good_J_Lowdin (is_there_cout_detailed , J2 , J , Vstore);
      else if (are_GSM_vectors_stored_on_disk)
	Lanczos_GSM_disk::J2_projection::J_projected_GSM_vector_calc (is_there_cout_detailed , J , J_number , J2 , Vp_tab , Vstore , PSI);
      else
	Lanczos_GSM_not_disk::J2_projection::J_projected_GSM_vector_calc (is_there_cout_detailed , J , J_number , J2 , Vp_tab , PSI);	
    }
}








void GSM_vector::pivot_init_Davidson (
				      const bool is_there_cout_detailed ,
				      const bool full_common_vectors_used_in_file ,
				      const bool pivot_from_file ,
				      const bool J_projected , 
				      const class correlated_state_str &Pivot_qn ,
				      const class J2_class &J2 , 
				      const double J , 
				      const unsigned int J_number ,				      
				      const bool is_it_Lowdin ,
				      const bool are_GSM_vectors_stored_on_disk , 
				      class array<class GSM_vector> &Vp_tab ,
				      class GSM_vector &Vstore)
{
  class GSM_vector &V = *this;

  if (pivot_from_file) 
    V.SDs_components_eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , Pivot_qn);
  else
    V.pseudo_random_vector ();

  V.normalization ();
  
  if (!J_projected) return;
  
  double J_coupling_precision = J2.J_coupling_precision_calc (V , J , Vstore);

  if (J_coupling_precision > precision)
    {
      if (is_it_Lowdin)
	V.good_J_Lowdin (is_there_cout_detailed , J2 , J , Vstore);
      else if (are_GSM_vectors_stored_on_disk)
	Lanczos_GSM_disk::J2_projection::J_projected_GSM_vector_calc (is_there_cout_detailed , J , J_number , J2 , Vp_tab , Vstore , V);
      else
	Lanczos_GSM_not_disk::J2_projection::J_projected_GSM_vector_calc (is_there_cout_detailed , J , J_number , J2 , Vp_tab , V);
            
      J_coupling_precision = J2.J_coupling_precision_calc (V , J , Vstore);
      
      if (J_coupling_precision > precision) error_message_print_abort ("The pivot cannot be coupled to J (Davidson)");
    }
}








void GSM_vector::pivot_init_Lanczos (
				     const bool is_there_cout_detailed ,
				     const bool full_common_vectors_used_in_file ,
				     const bool pivot_from_file ,
				     const bool J_projected , 
				     const unsigned int eigenset_index ,
				     const unsigned int eigenset_vectors_number ,
				     const class array<class correlated_state_str> &PSI_qn_tab ,
				     const class J2_class &J2 , 
				     const double J , 
				     const unsigned int J_number ,
				     const bool are_GSM_vectors_stored_on_disk , 
				     const bool is_it_Lowdin ,
				     class array<class GSM_vector> &Vp_tab , 
				     class GSM_vector &Vstore)
{
  class GSM_vector &V = *this;

  if (pivot_from_file) 
    {
      V = 0.0;
      
      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	{
	  const class correlated_state_str &Pivot_qn = PSI_qn_tab(eigenset_index , i);

	  if (J_projected)
	    Vstore.SDs_components_eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , Pivot_qn);
	  else
	    Vstore.SDs_components_eigenvector_Jmin_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , Pivot_qn);
	    
	  V += Vstore;
	}
    }
  else
    V.pseudo_random_vector ();

  V.normalization ();

  if (!J_projected) return;
  
  double J_coupling_precision = J2.J_coupling_precision_calc (V , J , Vstore);

  unsigned int count = 0;
  
  while (J_coupling_precision > precision)
    {      
      if (count++ == 5) error_message_print_abort ("The pivot cannot be coupled to J (Lanczos)");
      
      if (is_it_Lowdin)
	V.good_J_Lowdin (is_there_cout_detailed , J2 , J , Vstore);
      else if (are_GSM_vectors_stored_on_disk)
	Lanczos_GSM_disk::J2_projection::J_projected_GSM_vector_calc (is_there_cout_detailed , J , J_number , J2 , Vp_tab , Vstore , V);
      else
	Lanczos_GSM_not_disk::J2_projection::J_projected_GSM_vector_calc (is_there_cout_detailed , J , J_number , J2 , Vp_tab , V);
            
      J_coupling_precision = J2.J_coupling_precision_calc (V , J , Vstore);
    }
}






double used_memory_calc (const class GSM_vector &T)
{
  return ((sizeof (T) + sizeof (TYPE)*T.space_dimensions_all_processes_max)/1000000.0);
}








#ifdef UseMPI

void GSM_vector::TRS_rest_part_fill_one_transfer (
						  const unsigned int i_Send ,
						  const unsigned int i_Recv ,
						  const double J)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool is_process_Send = (i_Send == THIS_PROCESS);
  const bool is_process_Recv = (i_Recv == THIS_PROCESS);
		
  const unsigned int bin_phase_J = make_uns_int (J)%2;

  const class array<unsigned long int> &TRS_total_PSI_indices = GSM_vector_helper.get_TRS_total_PSI_indices ();

  const class array<unsigned char> &TRS_bin_phases = GSM_vector_helper.get_TRS_bin_phases ();

  const class array<unsigned int> &space_dimensions_all_processes = GSM_vector_helper.get_space_dimensions_all_processes ();
  
  const class array<unsigned long int> &first_total_PSI_process_indices = GSM_vector_helper.get_first_total_PSI_indices ();
  const class array<unsigned long int> &last_total_PSI_process_indices = GSM_vector_helper.get_last_total_PSI_indices ();

  const unsigned int space_dimension_process_Send = space_dimensions_all_processes(i_Send);
  const unsigned int space_dimension_process_Recv = space_dimensions_all_processes(i_Recv);
  
  const unsigned long int first_total_PSI_index_Send = first_total_PSI_process_indices(i_Send);
  const unsigned long int last_total_PSI_index_Send = last_total_PSI_process_indices(i_Send);

  const unsigned long int first_total_PSI_index_Recv = first_total_PSI_process_indices(i_Recv);
  const unsigned long int last_total_PSI_index_Recv = last_total_PSI_process_indices(i_Recv);

  class GSM_vector &PSI = *this;

  unsigned int N = 0;

  if (is_process_Send)
    {
      for (unsigned int TRS_PSI_index = 0 ; TRS_PSI_index < space_dimension_process_Send ; TRS_PSI_index++) 
	{
	  const unsigned long int TRS_total_PSI_index = TRS_PSI_index + first_total_PSI_index_Send , total_PSI_index = TRS_total_PSI_indices(TRS_PSI_index);

	  if ((total_PSI_index >= first_total_PSI_index_Recv) && (total_PSI_index <= last_total_PSI_index_Recv) && (TRS_total_PSI_index < total_PSI_index)) N++;
	}
    }

  if (is_process_Recv)
    {
      for (unsigned int PSI_index = 0 ; PSI_index < space_dimension_process_Recv ; PSI_index++) 
	{
	  const unsigned long int total_PSI_index = PSI_index + first_total_PSI_index_Recv , TRS_total_PSI_index = TRS_total_PSI_indices(PSI_index);

	  if ((TRS_total_PSI_index >= first_total_PSI_index_Send) && (TRS_total_PSI_index <= last_total_PSI_index_Send) && (TRS_total_PSI_index < total_PSI_index)) N++;
	}
    }	 

  if (N > 0)
    { 
      const unsigned int tag = i_Recv + NUMBER_OF_PROCESSES*i_Send;

      const unsigned int indices_tag = 2*tag;

      const unsigned int components_tag = 2*tag + 1;

      class array<unsigned int> PSI_indices_TRS(N);

      class array<TYPE> PSI_components_TRS(N);

      if (is_process_Send)
	{
	  N = 0;

	  for (unsigned int TRS_PSI_index = 0 ; TRS_PSI_index < space_dimension_process_Send ; TRS_PSI_index++)
	    {
	      const unsigned long int TRS_total_PSI_index = TRS_PSI_index + first_total_PSI_index_Send , total_PSI_index = TRS_total_PSI_indices(TRS_PSI_index);

	      if ((total_PSI_index >= first_total_PSI_index_Recv) && (total_PSI_index <= last_total_PSI_index_Recv) && (TRS_total_PSI_index < total_PSI_index))
		{
		  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index_Recv;

		  const unsigned int TRS_bin_phase = TRS_bin_phases(TRS_PSI_index);

		  PSI_indices_TRS(N) = PSI_index;

		  PSI_components_TRS(N) = (TRS_bin_phase == bin_phase_J) ? (PSI[TRS_PSI_index]) : (-PSI[TRS_PSI_index]);

		  N++;
		}
	    }

	  PSI_indices_TRS.MPI_Send (i_Recv , indices_tag , MPI_COMM_WORLD);

	  PSI_components_TRS.MPI_Send (i_Recv , components_tag , MPI_COMM_WORLD);
	}

      if (is_process_Recv)
	{
	  PSI_indices_TRS.MPI_Recv (i_Send , indices_tag , MPI_COMM_WORLD);

	  PSI_components_TRS.MPI_Recv (i_Send  , components_tag , MPI_COMM_WORLD);

	  for (unsigned int i = 0 ; i < N ; i++)
	    {
	      const unsigned int PSI_index = PSI_indices_TRS(i);

	      const TYPE PSI_component = PSI_components_TRS(i);

	      PSI[PSI_index] = PSI_component;
	    }
	}
    }
}

#endif



void GSM_vector::TRS_rest_part_fill (
				     const bool is_there_cout_detailed,
				     const double J)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  if (!is_it_TRS) error_message_print_abort ("TRS forbidden in GSM_vector::TRS_rest_part_fill");

  const unsigned int bin_phase_J = make_uns_int (J)%2;

  const class array<unsigned long int> &TRS_total_PSI_indices = GSM_vector_helper.get_TRS_total_PSI_indices ();

  const class array<unsigned char> &TRS_bin_phases = GSM_vector_helper.get_TRS_bin_phases ();

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();

  class GSM_vector &PSI = *this;

  for (unsigned int PSI_index = 0 ; PSI_index < space_dimension_process ; PSI_index++) 
    {
      const unsigned long int total_PSI_index = PSI_index + first_total_PSI_index , TRS_total_PSI_index = TRS_total_PSI_indices(PSI_index) , TRS_bin_phase = TRS_bin_phases(PSI_index);

      if ((TRS_total_PSI_index >= first_total_PSI_index) && (TRS_total_PSI_index <= last_total_PSI_index) && (TRS_total_PSI_index < total_PSI_index))
	{
	  const unsigned long int TRS_PSI_total_index = TRS_total_PSI_index - first_total_PSI_index;
	  
	  PSI[PSI_index] = (TRS_bin_phase == bin_phase_J) ? (PSI[TRS_PSI_total_index]) : (-PSI[TRS_PSI_total_index]);
	}
    }

  if (is_it_MPI_parallelized_local)
    {   
      const bool is_time_considered = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_detailed);
  
      const double reference_time = (is_time_considered) ? (absolute_time_determine ()) : (NADA);
  
#ifdef UseMPI
      
      for (unsigned int i_Send = 0 ; i_Send < NUMBER_OF_PROCESSES ; i_Send++)
	for (unsigned int i_Recv = 0 ; i_Recv < i_Send ; i_Recv++)
	  {
	    if ((i_Send == THIS_PROCESS) || (i_Recv == THIS_PROCESS))
	      TRS_rest_part_fill_one_transfer (i_Send , i_Recv , J);
	  }

      for (unsigned int i_Recv = 0 ; i_Recv < NUMBER_OF_PROCESSES ; i_Recv++)
	for (unsigned int i_Send = 0 ; i_Send < i_Recv ; i_Send++)
	  {
	    if ((i_Send == THIS_PROCESS) || (i_Recv == THIS_PROCESS))
	      TRS_rest_part_fill_one_transfer (i_Send , i_Recv , J);
	  }
      
#endif
      
      if (is_time_considered)
	{
	  const double MPI_Bcast_absolute_time = absolute_time_determine ();
	  
	  const double TRS_MPI_communication_time = MPI_Bcast_absolute_time - reference_time;

	  cout << "TRS MPI communication time (GSM vector):" << TRS_MPI_communication_time << " s" << endl;
	}
    }
}






TYPE GSM_vector::average_n_scat_calc_pn () const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM (); 

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const class GSM_vector &PSI = *this;

  TYPE average_n_scat_partial = 0.0;

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP);
      
      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;
	  
	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p;
      
	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
		  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);

		  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
		      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
			{		  
			  const int n_scat = n_scat_p + n_scat_n;

			  if (n_scat > 0)
			    {
			      TYPE probability_n_scat = 0.0;

			      const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
			      const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  
			      for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
				{
				  const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
				  const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

				  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	  
				  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		      
				  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
				    {
				      const int iMn = iM - iMp;

				      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
				      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

				      if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

				      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

				      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
					{
					  const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;

					  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
					    {
					      const unsigned long int total_PSI_index = total_PSI_index_zero + SDn_index;

					      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
						{
						  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

						  const TYPE PSI_component = PSI[PSI_index];

						  probability_n_scat += PSI_component*PSI_component;
						}}}}}

			      average_n_scat_partial += n_scat*probability_n_scat;			  
			    }}}}}}}

  const TYPE average_n_scat = sum_Allreduce<TYPE> (is_it_MPI_parallelized_local , average_n_scat_partial);
  
  return average_n_scat;
}






TYPE GSM_vector::average_n_scat_calc_pp_nn () const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int iM = GSM_vector_helper.get_iM ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  const class array<unsigned int> &iC_min_process_tab = GSM_vector_helper.get_iC_min_process_tab ();
  const class array<unsigned int> &iC_max_process_tab = GSM_vector_helper.get_iC_max_process_tab ();
  
  const class GSM_vector &PSI = *this;

  TYPE average_n_scat_partial = 0.0;

  for (int n_scat = 1 ; n_scat <= n_scat_max ; n_scat++) 
    {
      const unsigned int iC_min = iC_min_process_tab(n_scat);
      const unsigned int iC_max = iC_max_process_tab(n_scat);

      TYPE probability_n_scat = 0.0;

      for (unsigned int iC = iC_min ; iC <= iC_max ; iC++)
	{
	  const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
	  const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD = dimensions_SD_set(BP , S , 0 , n_scat , iC , iM);

	  if (dimension_SD == 0) continue;

	  const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions(n_scat , iC);

	  for (unsigned int SD_index = 0 ; SD_index < dimension_SD ; SD_index++)
	    {
	      const unsigned long int total_PSI_index = sum_dimensions_configuration_fixed + SD_index;

	      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
		{
		  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

		  const TYPE PSI_component = PSI[PSI_index];

		  probability_n_scat += PSI_component*PSI_component;
		}
	    }
	}

      average_n_scat_partial += n_scat*probability_n_scat;
    }

  const TYPE average_n_scat = sum_Allreduce<TYPE> (is_it_MPI_parallelized_local , average_n_scat_partial);
  
  return average_n_scat;
}







TYPE GSM_vector::average_n_scat_calc () const
{ 
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();

  if (space == PROT_NEUT_Y) 
    return average_n_scat_calc_pn ();
  else
    return average_n_scat_calc_pp_nn ();
}








void GSM_vector::pole_space_project_pn ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM (); 

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  class GSM_vector &PSI = *this;

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP);
      
      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;
	  
	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p;
      
	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
		  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);

		  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
		      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
			{		  
			  const int n_scat = n_scat_p + n_scat_n;

			  if (n_scat > 0)
			    {
			      const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
			      const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  
			      for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
				{
				  const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
				  const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

				  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	  
				  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		      
				  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
				    {
				      const int iMn = iM - iMp;

				      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
				      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

				      if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

				      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

				      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
					{
					  const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;

					  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
					    {
					      const unsigned long int total_PSI_index = total_PSI_index_zero + SDn_index;

					      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
						{
						  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

						  PSI[PSI_index] = 0.0;
						}}}}}}}}}}}}
}






void GSM_vector::pole_space_project_pp_nn ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int iM = GSM_vector_helper.get_iM ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  const class array<unsigned int> &iC_min_process_tab = GSM_vector_helper.get_iC_min_process_tab ();
  const class array<unsigned int> &iC_max_process_tab = GSM_vector_helper.get_iC_max_process_tab ();
  
  class GSM_vector &PSI = *this;

  for (int n_scat = 1 ; n_scat <= n_scat_max ; n_scat++) 
    {
      const unsigned int iC_min = iC_min_process_tab(n_scat);
      const unsigned int iC_max = iC_max_process_tab(n_scat);

      for (unsigned int iC = iC_min ; iC <= iC_max ; iC++)
	{
	  const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
	  const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD = dimensions_SD_set(BP , S , 0 , n_scat , iC , iM);

	  if (dimension_SD == 0) continue;

	  const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions(n_scat , iC);

	  for (unsigned int SD_index = 0 ; SD_index < dimension_SD ; SD_index++)
	    {
	      const unsigned long int total_PSI_index = sum_dimensions_configuration_fixed + SD_index;

	      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
		{
		  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

		  PSI[PSI_index] = 0.0;
		}
	    }
	}
    }
}







void GSM_vector::pole_space_project ()
{ 
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();

  if (space == PROT_NEUT_Y) 
    pole_space_project_pn ();
  else
    pole_space_project_pp_nn ();
}









void GSM_vector::scat_space_project_pn ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM (); 

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  class GSM_vector &PSI = *this;

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP);
      
      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;
	  
	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p;
      
	      const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , 0);
	      const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , 0);

	      for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
		{
		  const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , 0 , iCp);

		  const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , 0 , iCp);

		  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , 0 , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
		  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , 0);
		  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , 0);
		  
		  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
		    {
		      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , 0 , iCn);
	      
		      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , 0 , iCn);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , 0 , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	  
		      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , 0 , Ep_hw , n_holes_n , 0 , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		      
		      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
			{
			  const int iMn = iM - iMp;

			  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , 0 , iCp , iMp);
			  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , 0 , iCn , iMn);

			  if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

			  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions(BPp , Sp , n_spec_p , 0 , 0 , iCp , iCn , iMp);

			  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
			    {
			      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;

			      for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
				{
				  const unsigned long int total_PSI_index = total_PSI_index_zero + SDn_index;

				  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
				    {
				      const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

				      PSI[PSI_index] = 0.0;
				    }}}}}}}}}
}






void GSM_vector::scat_space_project_pp_nn ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int iM = GSM_vector_helper.get_iM ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  const class array<unsigned int> &iC_min_process_tab = GSM_vector_helper.get_iC_min_process_tab ();
  const class array<unsigned int> &iC_max_process_tab = GSM_vector_helper.get_iC_max_process_tab ();
  
  class GSM_vector &PSI = *this;
  
  const unsigned int iC_min = iC_min_process_tab(0);
  const unsigned int iC_max = iC_max_process_tab(0);

  for (unsigned int iC = iC_min ; iC <= iC_max ; iC++)
    {
      const int n_holes = n_holes_table(BP , S , 0 , 0 , iC);
	  
      const int E_hw = E_hw_table(BP , S , 0 , 0 , iC);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , 0 , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

      const unsigned int dimension_SD = dimensions_SD_set(BP , S , 0 , 0 , iC , iM);

      if (dimension_SD == 0) continue;

      const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions(0 , iC);

      for (unsigned int SD_index = 0 ; SD_index < dimension_SD ; SD_index++)
	{
	  const unsigned long int total_PSI_index = sum_dimensions_configuration_fixed + SD_index;

	  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
	    {
	      const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

	      PSI[PSI_index] = 0.0;
	    }
	}
    }
}







void GSM_vector::scat_space_project ()
{ 
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();

  if (space == PROT_NEUT_Y) 
    scat_space_project_pn ();
  else
    scat_space_project_pp_nn ();
}








void GSM_vector::fixed_particle_type_number_impose_normalize_pn (
								 const enum particle_type particle ,
								 const int N_particle)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM (); 

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();

  const class array_of_configuration &configuration_set_p = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_set_n = neut_Y_data.get_configuration_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  class GSM_vector &PSI = *this;

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP);
      
      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;
	  
	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p;
      
	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
		  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);

		  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
		      const class configuration Cp = configuration_set_p(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int N_particle_Cp = Cp.N_baryon_fixed_type_determine (particle , shells_qn_p);
		      
		      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
			{
			  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
			  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  
			  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
			    {
			      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
			      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	  
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		      
			      const class configuration Cn = configuration_set_n(BPn , Sn , n_spec_n , n_scat_n , iCn);
			      
			      const int N_particle_Cn = Cn.N_baryon_fixed_type_determine (particle , shells_qn_n);
		      
			      const int N_particle_C = N_particle_Cp + N_particle_Cn;

			      if (N_particle_C == N_particle) continue;
			      
			      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
				{
				  const int iMn = iM - iMp;

				  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
				  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

				  if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

				  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
				    {
				      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;

				      for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
					{
					  const unsigned long int total_PSI_index = total_PSI_index_zero + SDn_index;

					  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
					    {
					      const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

					      PSI[PSI_index] = 0.0;
					    }}}}}}}}}}}
  
  if (PSI.infinite_norm () != 0.0) PSI.normalization ();
}






void GSM_vector::fixed_particle_type_number_impose_normalize_pp_nn (
								    const enum particle_type particle ,
								    const int N_particle)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int iM = GSM_vector_helper.get_iM ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  const class array<unsigned int> &iC_min_process_tab = GSM_vector_helper.get_iC_min_process_tab ();
  const class array<unsigned int> &iC_max_process_tab = GSM_vector_helper.get_iC_max_process_tab ();
  
  class GSM_vector &PSI = *this;

  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++) 
    {
      const unsigned int iC_min = iC_min_process_tab(n_scat);
      const unsigned int iC_max = iC_max_process_tab(n_scat);

      for (unsigned int iC = iC_min ; iC <= iC_max ; iC++)
	{
	  const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
	  const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const class configuration C = configuration_set(BP , S , 0 , n_scat , iC);
				  
	  const int N_particle_C = C.N_baryon_fixed_type_determine (particle , shells_qn);

	  if (N_particle_C == N_particle) continue;
	  
	  const unsigned int dimension_SD = dimensions_SD_set(BP , S , 0 , n_scat , iC , iM);

	  if (dimension_SD == 0) continue;

	  const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions(n_scat , iC);

	  for (unsigned int SD_index = 0 ; SD_index < dimension_SD ; SD_index++)
	    {
	      const unsigned long int total_PSI_index = sum_dimensions_configuration_fixed + SD_index;

	      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
		{
		  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

		  PSI[PSI_index] = 0.0;
		}
	    }
	}
    }
  
  if (PSI.infinite_norm () != 0.0) PSI.normalization ();
}







void GSM_vector::fixed_particle_type_number_impose_normalize (
							      const enum particle_type particle ,
							      const int N_particle)
{ 
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();

  if (space == PROT_NEUT_Y) 
    fixed_particle_type_number_impose_normalize_pn (particle , N_particle);
  else
    fixed_particle_type_number_impose_normalize_pp_nn (particle , N_particle);
}







void GSM_vector::get_SDs_pn (
			     class array<unsigned int> &SDp_tab ,
			     class array<unsigned int> &SDn_tab) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM ();

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
	    
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  const int ZYval = prot_Y_data.get_N_valence_baryons ();

  class Slater_determinant SDp(ZYval);
  class Slater_determinant SDn(NYval);
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP);
      
      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;
	  
	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p;
	  
	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
		  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  
		  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

		      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
			{
			  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
			  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  
			  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
			    {
			      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
			      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	  
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			  
			      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
				{
				  const int iMn = iM - iMp;

				  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
				  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

				  if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

				  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
				    {
				      SDp = SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index);

				      const unsigned long int total_PSI_index_zero_SDp = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;
				  
				      for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
					{
					  const unsigned long int total_PSI_index = total_PSI_index_zero_SDp + SDn_index;

					  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
					    {
					      const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;

					      SDn = SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index);

					      for (int ip = 0 ; ip < ZYval ; ip++) SDp_tab(PSI_index , ip) = SDp[ip];
					      for (int in = 0 ; in < NYval ; in++) SDn_tab(PSI_index , in) = SDn[in];					  
					    }}}}}}}}}}}
}







void GSM_vector::get_SDs_pp_nn (class array<unsigned int> &SD_tab) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int iM = GSM_vector_helper.get_iM ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const int N_valence_baryons = data.get_N_valence_baryons ();

  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  const class array<unsigned int> &iC_min_process_tab = GSM_vector_helper.get_iC_min_process_tab ();
  const class array<unsigned int> &iC_max_process_tab = GSM_vector_helper.get_iC_max_process_tab ();

  class Slater_determinant SD(N_valence_baryons);
  
  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int iC_min = iC_min_process_tab(n_scat);
      const unsigned int iC_max = iC_max_process_tab(n_scat);

      for (unsigned int iC = iC_min ; iC <= iC_max ; iC++)
	{      
	  const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
	  const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD = dimensions_SD_set(BP , S , 0 , n_scat , iC , iM);

	  if (dimension_SD == 0) continue;

	  const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions(n_scat , iC);

	  for (unsigned int SD_index = 0 ; SD_index < dimension_SD ; SD_index++)
	    {
	      const unsigned long int total_PSI_index = sum_dimensions_configuration_fixed + SD_index;

	      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
		{
		  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;	      

		  SD = SD_set(BP , S , 0 , n_scat , iC , iM , SD_index);

		  for (int i = 0 ; i < N_valence_baryons ; i++) SD_tab(PSI_index , i) = SD[i];
		}
	    }
	}
    }
}







void GSM_vector::diagonal_part_PSI_add (
					const class GSM_vector &PSI_in , 
					const class array<TYPE> &diagonal_tab ,
					const TYPE &alpha)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array<unsigned long int> &TRS_total_PSI_indices = GSM_vector_helper.get_TRS_total_PSI_indices ();
   
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
 
  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();

  class GSM_vector &PSI_out = *this;

  for (unsigned int PSI_index = 0 ; PSI_index < space_dimension_process ; PSI_index++) 
    {
      const unsigned long int total_PSI_index = PSI_index + first_total_PSI_index;

      if (!is_it_TRS || (TRS_total_PSI_indices(PSI_index) >= total_PSI_index))
	{
	  const TYPE &diagonal_ME = diagonal_tab[PSI_index];

	  const TYPE &PSI_in_component = PSI_in[PSI_index];
	  
	  const TYPE diagonal_ME_plus_alpha = diagonal_ME + alpha;
	  
	  PSI_out[PSI_index] += diagonal_ME_plus_alpha*PSI_in_component;
	}
    }
}












// Op is a (nucleon annihilation) or a+ (nucleon creation) in ...one_baryon... routines

#ifdef UseMPI

void GSM_vector::Op_PSI_IN_indices_components_transfer_add_one_baryon (
									const unsigned int i_Send ,
									const unsigned int i_Recv ,
									const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
									const class array<TYPE> &Op_PSI_IN_all_components)
{
  const bool is_process_Send = (i_Send == THIS_PROCESS);
  const bool is_process_Recv = (i_Recv == THIS_PROCESS);
  
  if (is_process_Send || is_process_Recv)
    {
      class GSM_vector &PSI_OUT = *this;
  
      const unsigned int space_dimension_IN_max = Op_PSI_IN_total_PSI_indices.dimension (0);
  
      const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

      const class array<unsigned long int> &first_total_PSI_OUT_process_indices = GSM_vector_helper_OUT.get_first_total_PSI_indices ();
      const class array<unsigned long int> &last_total_PSI_OUT_process_indices = GSM_vector_helper_OUT.get_last_total_PSI_indices ();
      
      const unsigned long int first_total_PSI_OUT_index = first_total_PSI_OUT_process_indices(i_Recv);
      const unsigned long int last_total_PSI_OUT_index = last_total_PSI_OUT_process_indices(i_Recv);
  
      unsigned int N = 0;
      
      if (is_process_Send)
	{
	  for (unsigned int i = 0 ; i < space_dimension_IN_max ; i++)
	    {
	      const unsigned long int total_PSI_OUT_index = Op_PSI_IN_total_PSI_indices(i);
	  
	      if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index)) N++;
	    }
	}
      
      const unsigned int tag = i_Recv + NUMBER_OF_PROCESSES*i_Send;

      const unsigned int N_tag = 3*tag;

      const unsigned int indices_tag = 3*tag + 1;

      const unsigned int components_tag = 3*tag + 2;
	  
      if (is_process_Send) MPI_helper::Send<unsigned int> (N , i_Recv , N_tag , MPI_COMM_WORLD);
      if (is_process_Recv) MPI_helper::Recv<unsigned int> (N , i_Send , N_tag , MPI_COMM_WORLD);
      
      if (N > 0)
	{
	  class array<unsigned int> Op_PSI_IN_indices(N);
	  class array<TYPE> Op_PSI_IN_components(N);

	  if (is_process_Send)
	    {
	      N = 0;
	      
	      for (unsigned int i = 0 ; i < space_dimension_IN_max ; i++)
		{
		  const unsigned long int total_PSI_OUT_index = Op_PSI_IN_total_PSI_indices(i);
	  
		  if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
		    {
		      const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;
		      
		      Op_PSI_IN_indices(N) = PSI_OUT_index;

		      Op_PSI_IN_components(N) = Op_PSI_IN_all_components(i);

		      N++;
		    }
		}
	      
	      Op_PSI_IN_indices.MPI_Send (i_Recv , indices_tag , MPI_COMM_WORLD);

	      Op_PSI_IN_components.MPI_Send (i_Recv , components_tag , MPI_COMM_WORLD);
	    }
	  
	  if (is_process_Recv)
	    {
	      Op_PSI_IN_indices.MPI_Recv (i_Send , indices_tag , MPI_COMM_WORLD);

	      Op_PSI_IN_components.MPI_Recv (i_Send , components_tag , MPI_COMM_WORLD);

	      for (unsigned int i = 0 ; i < N ; i++)
		{
		  const unsigned int PSI_OUT_index = Op_PSI_IN_indices(i);

		  const TYPE &Op_PSI_IN_component = Op_PSI_IN_components(i);

		  PSI_OUT[PSI_OUT_index] += Op_PSI_IN_component;
		}
	    }
	}
    }
}

#endif








void GSM_vector::Op_PSI_IN_components_add_one_baryon_all_processes (
								     const bool full_common_vectors_used_in_file ,
								     const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
								     const class array<TYPE> &Op_PSI_IN_all_components)
{					      
  const unsigned int space_dimension_IN_max = Op_PSI_IN_total_PSI_indices.dimension (0);

  class GSM_vector &PSI_OUT = *this;
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const unsigned long int first_total_PSI_OUT_index = GSM_vector_helper_OUT.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_OUT_index = GSM_vector_helper_OUT.get_last_total_PSI_index ();
  
  for (unsigned int i = 0 ; i < space_dimension_IN_max ; i++)
    {
      const unsigned long int total_PSI_OUT_index = Op_PSI_IN_total_PSI_indices(i);
      
      if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
	{
	  const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;
	  
	  const TYPE &Op_PSI_IN_component = Op_PSI_IN_all_components(i);
	  
	  PSI_OUT[PSI_OUT_index] += Op_PSI_IN_component;
	}
    }
  
    
  if (!full_common_vectors_used_in_file)
    {
#ifdef UseMPI
      for (unsigned int i_Send = 0 ; i_Send < NUMBER_OF_PROCESSES ; i_Send++)
	for (unsigned int i_Recv = 0 ; i_Recv < i_Send ; i_Recv++)
	  {
	    if ((i_Send == THIS_PROCESS) || (i_Recv == THIS_PROCESS))
	      Op_PSI_IN_indices_components_transfer_add_one_baryon (i_Send , i_Recv , Op_PSI_IN_total_PSI_indices , Op_PSI_IN_all_components);
	  }

      for (unsigned int i_Recv = 0 ; i_Recv < NUMBER_OF_PROCESSES ; i_Recv++)
	for (unsigned int i_Send = 0 ; i_Send < i_Recv ; i_Send++)
	  {
	    if ((i_Send == THIS_PROCESS) || (i_Recv == THIS_PROCESS))
	      Op_PSI_IN_indices_components_transfer_add_one_baryon (i_Send , i_Recv , Op_PSI_IN_total_PSI_indices , Op_PSI_IN_all_components);
	  }
#endif
    }
}






#ifdef UseMPI

TYPE GSM_vector::Op_PSI_IN_indices_components_transfer_scalar_product_add_one_baryon (
										       const unsigned int i_Send ,
										       const unsigned int i_Recv ,
										       const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
										       const class array<TYPE> &Op_PSI_IN_all_components) const
{  
   
  const bool is_process_Send = (i_Send == THIS_PROCESS);
  const bool is_process_Recv = (i_Recv == THIS_PROCESS);

  double Re_Op_amplitude_part = 0.0;
  double Im_Op_amplitude_part = 0.0;
  
  if (is_process_Send || is_process_Recv)
    {
      const class GSM_vector &PSI_OUT = *this;
  
      const unsigned int space_dimension_IN_max = Op_PSI_IN_total_PSI_indices.dimension (0);
  
      const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();  
  
      const class array<unsigned long int> &first_total_PSI_OUT_process_indices = GSM_vector_helper_OUT.get_first_total_PSI_indices ();
      const class array<unsigned long int> &last_total_PSI_OUT_process_indices = GSM_vector_helper_OUT.get_last_total_PSI_indices ();
      
      const unsigned long int first_total_PSI_OUT_index = first_total_PSI_OUT_process_indices(i_Recv);
      const unsigned long int last_total_PSI_OUT_index = last_total_PSI_OUT_process_indices(i_Recv);
      
      unsigned int N = 0;
      
      if (is_process_Send)
	{
	  for (unsigned int i = 0 ; i < space_dimension_IN_max ; i++)
	    {
	      const unsigned long int total_PSI_OUT_index = Op_PSI_IN_total_PSI_indices(i);
	  
	      if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index)) N++;
	    }
	}
      
      const unsigned int tag = i_Recv + NUMBER_OF_PROCESSES*i_Send;

      const unsigned int N_tag = 3*tag;

      const unsigned int indices_tag = 3*tag + 1;

      const unsigned int components_tag = 3*tag + 2;
	  
      if (is_process_Send) MPI_helper::Send<unsigned int> (N , i_Recv , N_tag , MPI_COMM_WORLD);
      if (is_process_Recv) MPI_helper::Recv<unsigned int> (N , i_Send , N_tag , MPI_COMM_WORLD);
      
      if (N > 0)
	{
	  class array<unsigned int> Op_PSI_IN_indices(N);
	  class array<TYPE> Op_PSI_IN_components(N);

	  if (is_process_Send)
	    {
	      N = 0;
	      
	      for (unsigned int i = 0 ; i < space_dimension_IN_max ; i++)
		{
		  const unsigned long int total_PSI_OUT_index = Op_PSI_IN_total_PSI_indices(i);
	  
		  if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
		    {
		      const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;
		      
		      Op_PSI_IN_indices(N) = PSI_OUT_index;

		      Op_PSI_IN_components(N) = Op_PSI_IN_all_components(i);

		      N++;
		    }
		}
	      
	      Op_PSI_IN_indices.MPI_Send (i_Recv , indices_tag , MPI_COMM_WORLD);

	      Op_PSI_IN_components.MPI_Send (i_Recv , components_tag , MPI_COMM_WORLD);
	    }
	  
	  if (is_process_Recv)
	    {
	      Op_PSI_IN_indices.MPI_Recv (i_Send , indices_tag , MPI_COMM_WORLD);

	      Op_PSI_IN_components.MPI_Recv (i_Send , components_tag , MPI_COMM_WORLD);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) reduction(+:Re_Op_amplitude_part , Im_Op_amplitude_part)
#endif
	      for (unsigned int i = 0 ; i < N ; i++)
		{
		  const unsigned int PSI_OUT_index = Op_PSI_IN_indices(i);

		  const TYPE &Op_PSI_IN_component = Op_PSI_IN_components(i);

		  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
		  
		  const TYPE Op_amplitude_subpart = PSI_OUT_component*Op_PSI_IN_component;
		  
		  Re_Op_amplitude_part += real_dc (Op_amplitude_subpart);
		  Im_Op_amplitude_part += imag_dc (Op_amplitude_subpart);
		}
	    }
	}
    }
  
  const TYPE Op_amplitude_part = generate_scalar<TYPE> (Re_Op_amplitude_part , Im_Op_amplitude_part);
  
  return Op_amplitude_part;
}

#endif










TYPE GSM_vector::Op_PSI_IN_scalar_product_add_one_baryon_all_processes (
									 const bool full_common_vectors_used_in_file ,
									 const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
									 const class array<TYPE> &Op_PSI_IN_all_components) const
{
  const unsigned int space_dimension_IN_max = Op_PSI_IN_total_PSI_indices.dimension (0);
  
  const class GSM_vector &PSI_OUT = *this;

  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
    
  const bool is_it_MPI_parallelized_local_OUT = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
  
  const unsigned long int first_total_PSI_OUT_index = GSM_vector_helper_OUT.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_OUT_index = GSM_vector_helper_OUT.get_last_total_PSI_index ();
    
  double Re_Op_amplitude_part = 0.0;
  double Im_Op_amplitude_part = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) reduction(+:Re_Op_amplitude_part , Im_Op_amplitude_part)
#endif
  for (unsigned int i = 0 ; i < space_dimension_IN_max ; i++)
    {
      const unsigned long int total_PSI_OUT_index = Op_PSI_IN_total_PSI_indices(i);
	      
      if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
	{
	  const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;
	  
	  const TYPE &Op_PSI_IN_component = Op_PSI_IN_all_components(i);

	  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
	  
	  const TYPE Op_amplitude_subpart = PSI_OUT_component*Op_PSI_IN_component;
	  
	  Re_Op_amplitude_part += real_dc (Op_amplitude_subpart);
	  Im_Op_amplitude_part += imag_dc (Op_amplitude_subpart);
	}
    }
      
  TYPE Op_amplitude_part = generate_scalar<TYPE> (Re_Op_amplitude_part , Im_Op_amplitude_part);
    
  if (!full_common_vectors_used_in_file)
    {
#ifdef UseMPI
      for (unsigned int i_Send = 0 ; i_Send < NUMBER_OF_PROCESSES ; i_Send++)
	for (unsigned int i_Recv = 0 ; i_Recv < i_Send ; i_Recv++)
	  {
	    if ((i_Send == THIS_PROCESS) || (i_Recv == THIS_PROCESS))
	      Op_amplitude_part += Op_PSI_IN_indices_components_transfer_scalar_product_add_one_baryon (i_Send , i_Recv , Op_PSI_IN_total_PSI_indices , Op_PSI_IN_all_components);
	  }

      for (unsigned int i_Recv = 0 ; i_Recv < NUMBER_OF_PROCESSES ; i_Recv++)
	for (unsigned int i_Send = 0 ; i_Send < i_Recv ; i_Send++)
	  {
	    if ((i_Send == THIS_PROCESS) || (i_Recv == THIS_PROCESS))
	      Op_amplitude_part += Op_PSI_IN_indices_components_transfer_scalar_product_add_one_baryon (i_Send , i_Recv , Op_PSI_IN_total_PSI_indices , Op_PSI_IN_all_components);
	  }
#endif
    }
  
  const TYPE Op_amplitude = sum_Reduce<TYPE> (is_it_MPI_parallelized_local_OUT , MASTER_PROCESS , THIS_PROCESS , Op_amplitude_part);
  
  return Op_amplitude;
}









// Op is A (cluster annihilation) or A+ (cluster creation) in ...one_baryon... routines



#ifdef UseMPI

void GSM_vector::Op_PSI_IN_indices_components_transfer_add_cluster (
								    const unsigned int i_Send ,
								    const unsigned int i_Recv ,
								    const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
								    const class array<TYPE> &Op_PSI_IN_all_components)
{
  const bool is_process_Send = (i_Send == THIS_PROCESS);
  const bool is_process_Recv = (i_Recv == THIS_PROCESS);

  if (is_process_Send || is_process_Recv)
    {
      class GSM_vector &PSI_OUT = *this;
  
      const unsigned int space_dimension_IN_max = Op_PSI_IN_total_PSI_indices.dimension (0);

      const unsigned int space_dimension_cluster = Op_PSI_IN_total_PSI_indices.dimension (1);
  
      const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();  
  
      const class array<unsigned long int> &first_total_PSI_OUT_process_indices = GSM_vector_helper_OUT.get_first_total_PSI_indices ();
      const class array<unsigned long int> &last_total_PSI_OUT_process_indices = GSM_vector_helper_OUT.get_last_total_PSI_indices ();
      
      const unsigned long int first_total_PSI_OUT_index = first_total_PSI_OUT_process_indices(i_Recv);
      const unsigned long int last_total_PSI_OUT_index = last_total_PSI_OUT_process_indices(i_Recv);
      
      unsigned int N = 0;
      
      if (is_process_Send)
	{
	  for (unsigned int i = 0 ; i < space_dimension_IN_max ; i++)
	    for (unsigned int ii = 0 ; ii < space_dimension_cluster ; ii++)
	      {
		const unsigned long int total_PSI_OUT_index = Op_PSI_IN_total_PSI_indices(i , ii);
	    
		if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index)) N++;
	      }
	}
      
      const unsigned int tag = i_Recv + NUMBER_OF_PROCESSES*i_Send;

      const unsigned int N_tag = 3*tag;

      const unsigned int indices_tag = 3*tag + 1;

      const unsigned int components_tag = 3*tag + 2;
	  
      if (is_process_Send) MPI_helper::Send<unsigned int> (N , i_Recv , N_tag , MPI_COMM_WORLD);
      if (is_process_Recv) MPI_helper::Recv<unsigned int> (N , i_Send , N_tag , MPI_COMM_WORLD);
      
      if (N > 0)
	{
	  class array<unsigned int> Op_PSI_IN_indices(N);

	  class array<TYPE> Op_PSI_IN_components(N);

	  if (is_process_Send)
	    {
	      N = 0;
	      
	      for (unsigned int i = 0 ; i < space_dimension_IN_max ; i++)
		for (unsigned int ii = 0 ; ii < space_dimension_cluster ; ii++)
		  {
		    const unsigned long int total_PSI_OUT_index = Op_PSI_IN_total_PSI_indices(i , ii);
		    
		    if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
		      {
			const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;
			
			Op_PSI_IN_indices(N) = PSI_OUT_index;

			Op_PSI_IN_components(N) = Op_PSI_IN_all_components(i , ii);

			N++;
		      }
		  }
	      
	      Op_PSI_IN_indices.MPI_Send (i_Recv , indices_tag , MPI_COMM_WORLD);

	      Op_PSI_IN_components.MPI_Send (i_Recv , components_tag , MPI_COMM_WORLD);
	    }
	  
	  if (is_process_Recv)
	    {
	      Op_PSI_IN_indices.MPI_Recv (i_Send , indices_tag , MPI_COMM_WORLD);

	      Op_PSI_IN_components.MPI_Recv (i_Send , components_tag , MPI_COMM_WORLD);

	      for (unsigned int i = 0 ; i < N ; i++)
		{
		  const unsigned int PSI_OUT_index = Op_PSI_IN_indices(i);

		  const TYPE &Op_PSI_IN_component = Op_PSI_IN_components(i);

		  PSI_OUT[PSI_OUT_index] += Op_PSI_IN_component;
		}
	    }
	}
    }
}

#endif



void GSM_vector::Op_PSI_IN_components_add_cluster_all_processes (
								 const bool full_common_vectors_used_in_file ,
								 const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
								 const class array<TYPE> &Op_PSI_IN_all_components)
{
  const unsigned int space_dimension_IN_max  = Op_PSI_IN_total_PSI_indices.dimension (0);
  const unsigned int space_dimension_cluster = Op_PSI_IN_total_PSI_indices.dimension (1);

  const class GSM_vector &PSI_OUT = *this;
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const unsigned long int first_total_PSI_OUT_index = GSM_vector_helper_OUT.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_OUT_index = GSM_vector_helper_OUT.get_last_total_PSI_index ();
    
  for (unsigned int i = 0 ; i < space_dimension_IN_max ; i++)
    for (unsigned int ii = 0 ; ii < space_dimension_cluster ; ii++)
      {
	const unsigned long int total_PSI_OUT_index = Op_PSI_IN_total_PSI_indices(i , ii);

	if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
	  {
	    const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;
		
	    const TYPE &Op_PSI_IN_component = Op_PSI_IN_all_components(i , ii);

	    PSI_OUT[PSI_OUT_index] += Op_PSI_IN_component;
	  }
      }
 
    
  if (!full_common_vectors_used_in_file)
    {
#ifdef UseMPI
      for (unsigned int i_Send = 0 ; i_Send < NUMBER_OF_PROCESSES ; i_Send++)
	for (unsigned int i_Recv = 0 ; i_Recv < i_Send ; i_Recv++)
	  {
	    if ((i_Send == THIS_PROCESS) || (i_Recv == THIS_PROCESS))
	      Op_PSI_IN_indices_components_transfer_add_cluster (i_Send , i_Recv , Op_PSI_IN_total_PSI_indices , Op_PSI_IN_all_components);
	  }

      for (unsigned int i_Recv = 0 ; i_Recv < NUMBER_OF_PROCESSES ; i_Recv++)
	for (unsigned int i_Send = 0 ; i_Send < i_Recv ; i_Send++)
	  {
	    if ((i_Send == THIS_PROCESS) || (i_Recv == THIS_PROCESS))
	      Op_PSI_IN_indices_components_transfer_add_cluster (i_Send , i_Recv , Op_PSI_IN_total_PSI_indices , Op_PSI_IN_all_components);
	  }
#endif
    }  
}




#ifdef UseMPI

TYPE GSM_vector::Op_PSI_IN_indices_components_transfer_scalar_product_add_cluster (
										   const unsigned int i_Send ,
										   const unsigned int i_Recv ,
										   const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
										   const class array<TYPE> &Op_PSI_IN_all_components) const
{
  const bool is_process_Send = (i_Send == THIS_PROCESS);
  const bool is_process_Recv = (i_Recv == THIS_PROCESS);
  
  double Re_Op_amplitude_part = 0.0;
  double Im_Op_amplitude_part = 0.0;
  
  if (is_process_Send || is_process_Recv)
    {
      const class GSM_vector &PSI_OUT = *this;
  
      const unsigned int space_dimension_IN_max = Op_PSI_IN_total_PSI_indices.dimension (0);

      const unsigned int space_dimension_cluster = Op_PSI_IN_total_PSI_indices.dimension (1);
  
      const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();  
  
      const class array<unsigned long int> &first_total_PSI_OUT_process_indices = GSM_vector_helper_OUT.get_first_total_PSI_indices ();
      const class array<unsigned long int> &last_total_PSI_OUT_process_indices = GSM_vector_helper_OUT.get_last_total_PSI_indices ();
      
      const unsigned long int first_total_PSI_OUT_index = first_total_PSI_OUT_process_indices(i_Recv);
      const unsigned long int last_total_PSI_OUT_index = last_total_PSI_OUT_process_indices(i_Recv);
      
      unsigned int N = 0;
      
      if (is_process_Send)
	{
	  for (unsigned int i = 0 ; i < space_dimension_IN_max ; i++)
	    for (unsigned int ii = 0 ; ii < space_dimension_cluster ; ii++)
	      {
		const unsigned long int total_PSI_OUT_index = Op_PSI_IN_total_PSI_indices(i , ii);
	    
		if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index)) N++;
	      }
	}
      
      const unsigned int tag = i_Recv + NUMBER_OF_PROCESSES*i_Send;

      const unsigned int N_tag = 3*tag;

      const unsigned int indices_tag = 3*tag + 1;

      const unsigned int components_tag = 3*tag + 2;
	  
      if (is_process_Send) MPI_helper::Send<unsigned int> (N , i_Recv , N_tag , MPI_COMM_WORLD);
      if (is_process_Recv) MPI_helper::Recv<unsigned int> (N , i_Send , N_tag , MPI_COMM_WORLD);
      
      if (N > 0)
	{
	  class array<unsigned int> Op_PSI_IN_indices(N);

	  class array<TYPE> Op_PSI_IN_components(N);

	  if (is_process_Send)
	    {
	      N = 0;
	      
	      for (unsigned int i = 0 ; i < space_dimension_IN_max ; i++)
		for (unsigned int ii = 0 ; ii < space_dimension_cluster ; ii++)
		  {
		    const unsigned long int total_PSI_OUT_index = Op_PSI_IN_total_PSI_indices(i , ii);
		    
		    if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
		      {
			const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;
			
			Op_PSI_IN_indices(N) = PSI_OUT_index;

			Op_PSI_IN_components(N) = Op_PSI_IN_all_components(i , ii);

			N++;
		      }
		  }
	      
	      Op_PSI_IN_indices.MPI_Send (i_Recv , indices_tag , MPI_COMM_WORLD);

	      Op_PSI_IN_components.MPI_Send (i_Recv , components_tag , MPI_COMM_WORLD);
	    }
	  
	  if (is_process_Recv)
	    {
	      Op_PSI_IN_indices.MPI_Recv (i_Send , indices_tag , MPI_COMM_WORLD);

	      Op_PSI_IN_components.MPI_Recv (i_Send , components_tag , MPI_COMM_WORLD);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) reduction(+:Re_Op_amplitude_part , Im_Op_amplitude_part)
#endif
	      for (unsigned int i = 0 ; i < N ; i++)
		{
		  const unsigned int PSI_OUT_index = Op_PSI_IN_indices(i);

		  const TYPE &Op_PSI_IN_component = Op_PSI_IN_components(i);

		  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
		  
		  const TYPE Op_amplitude_subpart = PSI_OUT_component*Op_PSI_IN_component;
		  
		  Re_Op_amplitude_part += real_dc (Op_amplitude_subpart);
		  Im_Op_amplitude_part += imag_dc (Op_amplitude_subpart);
		}
	    }
	}
    }
  
  const TYPE Op_amplitude_part = generate_scalar<TYPE> (Re_Op_amplitude_part , Im_Op_amplitude_part);
  
  return Op_amplitude_part;
}

#endif



TYPE GSM_vector::Op_PSI_IN_scalar_product_add_cluster_all_processes (
								     const bool full_common_vectors_used_in_file ,
								     const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
								     const class array<TYPE> &Op_PSI_IN_all_components) const
{
  const unsigned int space_dimension_IN_max = Op_PSI_IN_total_PSI_indices.dimension (0);

  const unsigned int space_dimension_cluster = Op_PSI_IN_total_PSI_indices.dimension (1);

  const class GSM_vector &PSI_OUT = *this;

  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
    
  const bool is_it_MPI_parallelized_local_OUT = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
  
  const unsigned long int first_total_PSI_OUT_index = GSM_vector_helper_OUT.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_OUT_index = GSM_vector_helper_OUT.get_last_total_PSI_index ();
  
  double Re_Op_amplitude_part = 0.0;
  double Im_Op_amplitude_part = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) reduction(+:Re_Op_amplitude_part , Im_Op_amplitude_part)
#endif
  for (unsigned int i = 0 ; i < space_dimension_IN_max ; i++)
    for (unsigned int ii = 0 ; ii < space_dimension_cluster ; ii++)
      {
	const unsigned long int total_PSI_OUT_index = Op_PSI_IN_total_PSI_indices(i , ii);
	      
	if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
	  {
	    const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;
	    
	    const TYPE &Op_PSI_IN_component = Op_PSI_IN_all_components(i , ii);

	    const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
	    
	    const TYPE Op_amplitude_subpart = PSI_OUT_component*Op_PSI_IN_component;
	    
	    Re_Op_amplitude_part += real_dc (Op_amplitude_subpart);
	    Im_Op_amplitude_part += imag_dc (Op_amplitude_subpart);
	  }
      }
      
  TYPE Op_amplitude_part = generate_scalar<TYPE> (Re_Op_amplitude_part , Im_Op_amplitude_part);
    
  if (!full_common_vectors_used_in_file)
    {
#ifdef UseMPI
      for (unsigned int i_Send = 0 ; i_Send < NUMBER_OF_PROCESSES ; i_Send++)
	for (unsigned int i_Recv = 0 ; i_Recv < i_Send ; i_Recv++)
	  {
	    if ((i_Send == THIS_PROCESS) || (i_Recv == THIS_PROCESS))
	      Op_amplitude_part += Op_PSI_IN_indices_components_transfer_scalar_product_add_cluster (i_Send , i_Recv , Op_PSI_IN_total_PSI_indices , Op_PSI_IN_all_components);
	  }

      for (unsigned int i_Recv = 0 ; i_Recv < NUMBER_OF_PROCESSES ; i_Recv++)
	for (unsigned int i_Send = 0 ; i_Send < i_Recv ; i_Send++)
	  {
	    if ((i_Send == THIS_PROCESS) || (i_Recv == THIS_PROCESS))
	      Op_amplitude_part += Op_PSI_IN_indices_components_transfer_scalar_product_add_cluster (i_Send , i_Recv , Op_PSI_IN_total_PSI_indices , Op_PSI_IN_all_components);
	  }
#endif
    }
  
  const TYPE Op_amplitude = sum_Reduce<TYPE> (is_it_MPI_parallelized_local_OUT , MASTER_PROCESS , THIS_PROCESS , Op_amplitude_part);
  
  return Op_amplitude;
}





// Op is beta+ or beta- in ...beta... routines


#ifdef UseMPI

TYPE GSM_vector::Op_PSI_IN_indices_partial_components_transfer_scalar_product_beta_add (
											const unsigned int i_Send ,
											const unsigned int i_Recv ,
											const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
											const class array<TYPE> &Op_PSI_IN_all_partial_components) const
{
  const bool is_process_Send = (i_Send == THIS_PROCESS);
  const bool is_process_Recv = (i_Recv == THIS_PROCESS);

  double Re_Op_amplitude_part = 0.0;
  double Im_Op_amplitude_part = 0.0;
  
  if (is_process_Send || is_process_Recv)
    {
      const class GSM_vector &PSI_OUT = *this;
  
      const unsigned int space_dimension_IN_max = Op_PSI_IN_total_PSI_indices.dimension (0);
      const unsigned int N_nlj = Op_PSI_IN_total_PSI_indices.dimension (1);
  
      const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();  
  
      const class array<unsigned long int> &first_total_PSI_OUT_process_indices = GSM_vector_helper_OUT.get_first_total_PSI_indices ();
      const class array<unsigned long int> &last_total_PSI_OUT_process_indices = GSM_vector_helper_OUT.get_last_total_PSI_indices ();
      
      const unsigned long int first_total_PSI_OUT_index = first_total_PSI_OUT_process_indices(i_Recv);
      const unsigned long int last_total_PSI_OUT_index = last_total_PSI_OUT_process_indices(i_Recv);
      
      unsigned int N = 0;
      
      if (is_process_Send)
	{
	  for (unsigned int i = 0 ; i < space_dimension_IN_max ; i++)
	    for (unsigned int s = 0 ; s < N_nlj ; s++)
	      {
		const unsigned long int total_PSI_OUT_index = Op_PSI_IN_total_PSI_indices(i , s);
	  
		if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index)) N++;
	      }
	}
      
      const unsigned int tag = i_Recv + NUMBER_OF_PROCESSES*i_Send;

      const unsigned int N_tag = 3*tag;

      const unsigned int indices_tag = 3*tag + 1;

      const unsigned int partial_components_tag = 3*tag + 2;
	  
      if (is_process_Send) MPI_helper::Send<unsigned int> (N , i_Recv , N_tag , MPI_COMM_WORLD);
      if (is_process_Recv) MPI_helper::Recv<unsigned int> (N , i_Send , N_tag , MPI_COMM_WORLD);
      
      if (N > 0)
	{
	  class array<unsigned int> Op_PSI_IN_indices(N);

	  class array<TYPE> Op_PSI_IN_partial_components(N);

	  if (is_process_Send)
	    {
	      N = 0;
	      
	      for (unsigned int i = 0 ; i < space_dimension_IN_max ; i++)
		for (unsigned int s = 0 ; s < N_nlj ; s++)
		  {
		    const unsigned long int total_PSI_OUT_index = Op_PSI_IN_total_PSI_indices(i , s);
	  
		    if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
		      {
			const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;
			
			Op_PSI_IN_indices(N) = PSI_OUT_index;

			Op_PSI_IN_partial_components(N) = Op_PSI_IN_all_partial_components(i , s);

			N++;
		      }
		  }
	      
	      Op_PSI_IN_indices.MPI_Send (i_Recv , indices_tag , MPI_COMM_WORLD);

	      Op_PSI_IN_partial_components.MPI_Send (i_Recv , partial_components_tag , MPI_COMM_WORLD);
	    }
	  
	  if (is_process_Recv)
	    {
	      Op_PSI_IN_indices.MPI_Recv (i_Send , indices_tag , MPI_COMM_WORLD);

	      Op_PSI_IN_partial_components.MPI_Recv (i_Send , partial_components_tag , MPI_COMM_WORLD);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) reduction(+:Re_Op_amplitude_part , Im_Op_amplitude_part)
#endif
	      for (unsigned int i = 0 ; i < N ; i++)
		{
		  const unsigned int PSI_OUT_index = Op_PSI_IN_indices(i);

		  const TYPE &Op_PSI_IN_component = Op_PSI_IN_partial_components(i);

		  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
		  
		  const TYPE Op_amplitude_subpart = PSI_OUT_component*Op_PSI_IN_component;
		  
		  Re_Op_amplitude_part += real_dc (Op_amplitude_subpart);
		  Im_Op_amplitude_part += imag_dc (Op_amplitude_subpart);
		}
	    }
	}
    }
  
  const TYPE Op_amplitude_part = generate_scalar<TYPE> (Re_Op_amplitude_part , Im_Op_amplitude_part);
  
  return Op_amplitude_part;
}

#endif





TYPE GSM_vector::Op_PSI_IN_beta_add_all_processes (
						   const bool full_common_vectors_used_in_file ,
						   const class array<unsigned int> &Op_PSI_IN_total_PSI_indices ,
						   const class array<TYPE> &Op_PSI_IN_all_partial_components) const
{
  const unsigned int space_dimension_IN_max = Op_PSI_IN_total_PSI_indices.dimension (0);

  const unsigned int N_nlj = Op_PSI_IN_total_PSI_indices.dimension (1);
  
  const class GSM_vector &PSI_OUT = *this;

  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local_OUT = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
      
  const unsigned long int first_total_PSI_OUT_index = GSM_vector_helper_OUT.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_OUT_index = GSM_vector_helper_OUT.get_last_total_PSI_index ();
      
  double Re_Op_amplitude_part = 0.0;
  double Im_Op_amplitude_part = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) reduction(+:Re_Op_amplitude_part , Im_Op_amplitude_part)
#endif
  for (unsigned int i = 0 ; i < space_dimension_IN_max ; i++)
    for (unsigned int s = 0 ; s < N_nlj ; s++)
      {
	const unsigned long int total_PSI_OUT_index = Op_PSI_IN_total_PSI_indices(i , s);
	      
	if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
	  {
	    const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;
	    
	    const TYPE &Op_PSI_IN_partial_component = Op_PSI_IN_all_partial_components(i , s);

	    const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
	    
	    const TYPE Op_amplitude_subpart = PSI_OUT_component*Op_PSI_IN_partial_component;
	    
	    Re_Op_amplitude_part += real_dc (Op_amplitude_subpart);
	    Im_Op_amplitude_part += imag_dc (Op_amplitude_subpart);
	  }
      }
     
  TYPE Op_amplitude_part = generate_scalar<TYPE> (Re_Op_amplitude_part , Im_Op_amplitude_part);
    
  if (!full_common_vectors_used_in_file)
    {
#ifdef UseMPI
      for (unsigned int i_Send = 0 ; i_Send < NUMBER_OF_PROCESSES ; i_Send++)
	for (unsigned int i_Recv = 0 ; i_Recv < i_Send ; i_Recv++)
	  {
	    if ((i_Send == THIS_PROCESS) || (i_Recv == THIS_PROCESS))
	      Op_amplitude_part += Op_PSI_IN_indices_partial_components_transfer_scalar_product_beta_add (i_Send , i_Recv , Op_PSI_IN_total_PSI_indices , Op_PSI_IN_all_partial_components);
	  }

      for (unsigned int i_Recv = 0 ; i_Recv < NUMBER_OF_PROCESSES ; i_Recv++)
	for (unsigned int i_Send = 0 ; i_Send < i_Recv ; i_Send++)
	  {
	    if ((i_Send == THIS_PROCESS) || (i_Recv == THIS_PROCESS))
	      Op_amplitude_part += Op_PSI_IN_indices_partial_components_transfer_scalar_product_beta_add (i_Send , i_Recv , Op_PSI_IN_total_PSI_indices , Op_PSI_IN_all_partial_components);
	  }
#endif
    }
  
  const TYPE Op_amplitude = sum_Reduce<TYPE> (is_it_MPI_parallelized_local_OUT , MASTER_PROCESS , THIS_PROCESS , Op_amplitude_part);
    
  return Op_amplitude;
}












// Vector having all its components in each node from a partitioned vector
// The dimension of PSI_full changes everytime it reaches a value larger than the previous one, with PSI_full then reallocated, and then it is not necessarily the GSM dimension of the current parity and M.
// One uses then the MPI_helper::Allgatherv routine directly with the GSM dimension of the current parity and M. This why MPI_Allgatherv is not in the GSM_vector class.

void GSM_vector::full_vector_fill (const class GSM_vector &PSI)
{  
  class GSM_vector &PSI_full = *this;

  const class GSM_vector_helper_class &PSI_full_GSM_vector_helper = PSI_full.get_GSM_vector_helper ();

  const class GSM_vector_helper_class &PSI_GSM_vector_helper = PSI.get_GSM_vector_helper ();

  const bool PSI_full_is_it_MPI_parallelized_local = PSI_full_GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  if (PSI_full_is_it_MPI_parallelized_local) error_message_print_abort ("PSI_full must not be parallelized in GSM_vector::full_vector_fill");
    
  const unsigned long int PSI_full_total_space_dimension = PSI_full_GSM_vector_helper.get_total_space_dimension ();
  
  const unsigned long int PSI_total_space_dimension = PSI_GSM_vector_helper.get_total_space_dimension ();
  
  if (PSI_full_total_space_dimension != PSI_total_space_dimension) error_message_print_abort ("PSI_full and PSI must have the same total dimension in GSM_vector::full_vector_fill");
  
  const bool PSI_is_it_MPI_parallelized_local = PSI_GSM_vector_helper.get_is_it_MPI_parallelized_local ();

  if (!PSI_is_it_MPI_parallelized_local)
    {
      PSI_full = PSI;

      return;
    }

#ifdef UseMPI
  
  const unsigned long int first_total_PSI_index = PSI_GSM_vector_helper.get_first_total_PSI_index ();

  const unsigned int space_dimension_process = PSI_GSM_vector_helper.get_space_dimension_process ();
  
  PSI_full = 0.0;
  
  for (unsigned int PSI_index = 0 ; PSI_index < space_dimension_process ; PSI_index++)
    {
      const unsigned long int total_PSI_index = first_total_PSI_index + PSI_index;
      
      PSI_full[total_PSI_index] = PSI[PSI_index];
    }
  
  MPI_helper::Allgatherv<TYPE> (PSI_full_total_space_dimension , table , NUMBER_OF_PROCESSES , MPI_COMM_WORLD);
    
#endif
  
}




// Partitioned vector between all nodes from a vector having all its components in one node

void GSM_vector::partitioned_vector_fill (const class GSM_vector &PSI_full)
{  
  class GSM_vector &PSI = *this;

  const class GSM_vector_helper_class &PSI_full_GSM_vector_helper = PSI_full.get_GSM_vector_helper ();

  const class GSM_vector_helper_class &PSI_GSM_vector_helper = PSI.get_GSM_vector_helper ();

  const bool PSI_full_is_it_MPI_parallelized_local = PSI_full_GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  if (PSI_full_is_it_MPI_parallelized_local) error_message_print_abort ("PSI_full must not be parallelized in GSM_vector::partitioned_vector_fill");
  
  const unsigned int PSI_full_total_space_dimension = PSI_full_GSM_vector_helper.get_total_space_dimension ();

  const unsigned long int PSI_total_space_dimension = PSI_GSM_vector_helper.get_total_space_dimension ();

  const bool PSI_is_it_MPI_parallelized_local = PSI_GSM_vector_helper.get_is_it_MPI_parallelized_local ();

  if (PSI_full_total_space_dimension != PSI_total_space_dimension) error_message_print_abort ("PSI_full and PSI must have the same total dimension in GSM_vector::partitioned_vector_fill");
  
  if (!PSI_is_it_MPI_parallelized_local)
    {
      PSI = PSI_full;

      return;
    }

#ifdef UseMPI

  const unsigned int space_dimension_process = PSI_GSM_vector_helper.get_space_dimension_process ();

  const unsigned long int first_total_PSI_index = PSI_GSM_vector_helper.get_first_total_PSI_index ();

  PSI = 0.0;
  
  for (unsigned int PSI_index = 0 ; PSI_index < space_dimension_process ; PSI_index++)
    {
      const unsigned long int total_PSI_index = first_total_PSI_index + PSI_index;

      PSI[PSI_index] = PSI_full[total_PSI_index];
    }

#endif
  
}



// * overloading : dot product;

TYPE GSM_vector_node_overlap (
			      const class GSM_vector &X ,
			      const class GSM_vector &Y)
{
  const class GSM_vector_helper_class &GSM_vector_helper = X.get_GSM_vector_helper ();

  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();

  TYPE overlap = 0.0;

  for (unsigned int i = 0 ; i < space_dimension_process ; i++)
    {
      const TYPE XYi = X[i]*Y[i];

      overlap += XYi;
    }

  return overlap;
}



TYPE operator * (
		 const class GSM_vector &X ,
		 const class GSM_vector &Y)
{
  const class GSM_vector_helper_class &GSM_vector_helper = X.get_GSM_vector_helper ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  const TYPE overlap_partial = GSM_vector_node_overlap (X , Y);

  const TYPE overlap = sum_Allreduce<TYPE> (is_it_MPI_parallelized_local , overlap_partial);
  
  return overlap;
}




bool operator == (
		  const class GSM_vector &X ,
		  const class GSM_vector &Y)
{
  const class GSM_vector_helper_class &GSM_vector_helper = X.get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();

  bool is_it_equal_partial = true;

  for (unsigned int i = 0 ; is_it_equal_partial && (i < space_dimension_process) ; i++) is_it_equal_partial = (X[i] == Y[i]);

  const bool is_it_equal = and_Allreduce (is_it_MPI_parallelized_local , is_it_equal_partial);
  
  return is_it_equal;
}



bool operator != (
		  const class GSM_vector &X ,
		  const class GSM_vector &Y)
{
  return (!(X == Y));
}







// Infinite norm.


double GSM_vector::infinite_norm () const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();

  const class GSM_vector &PSI = *this;

  double infinite_norm_value_partial = 0.0;

  for (unsigned int i = 0 ; i < space_dimension_process ; i++)
    {
      const double try_infinite_norm_value = inf_norm (PSI[i]);

      infinite_norm_value_partial = max (infinite_norm_value_partial , try_infinite_norm_value);
    }

  const double infinite_norm_value = max_Allreduce<double> (is_it_MPI_parallelized_local , infinite_norm_value_partial);
  
  return infinite_norm_value;
}






//  normalization with the Berggren norm.

void GSM_vector::normalization ()
{
  class GSM_vector &PSI = *this;

  const TYPE PSI_norm = sqrt (PSI*PSI);

  PSI /= PSI_norm;
}






// Initialization to a random vector.
void GSM_vector::random_vector ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();

  class GSM_vector &PSI = *this;

  zero ();

  for (unsigned int i = 0 ; i < space_dimension_process ; i++) PSI[i] = random_number<double> () - 0.5;
}




// Initialization to a pseudo random vector identical for all nodes.
void GSM_vector::pseudo_random_vector ()
{
  seed (space_dimensions_all_processes_max);

  random_vector ();

  seed ();
}








// opposite vector 

void GSM_vector::opposite ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();

  class GSM_vector &PSI = *this;

  for (unsigned int i = 0 ; i < space_dimension_process ; i++) PSI[i] = -PSI[i];
}




// sum of all vector components. Used typically for testing.

TYPE GSM_vector::sum () const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();

  const class GSM_vector &PSI = *this;

  TYPE sum_value_partial = 0.0;
    
  for (unsigned int i = 0 ; i < space_dimension_process ; i++) sum_value_partial += PSI[i];
  
  const TYPE sum_value = sum_Allreduce<TYPE> (is_it_MPI_parallelized_local , sum_value_partial);
  
  return sum_value;
}


bool GSM_vector::same_parity_strangeness_M_projection (const class GSM_vector &PSI) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const class GSM_vector_helper_class &GSM_vector_helper_PSI = PSI.get_GSM_vector_helper ();

  return GSM_vector_helper.same_parity_strangeness_M_projection (GSM_vector_helper_PSI);
}

bool GSM_vector::same_parity_strangeness_M_projection (const class GSM_vector_helper_class &GSM_vector_helper_PSI) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  return GSM_vector_helper.same_parity_strangeness_M_projection (GSM_vector_helper_PSI);
}




unsigned int GSM_vector::first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
{
  return basic_first_index_determine_for_MPI (space_dimensions_all_processes_max , group_processes_number , process);
}

unsigned int GSM_vector::last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
{
  return basic_last_index_determine_for_MPI (space_dimensions_all_processes_max , group_processes_number , process);
}

unsigned int GSM_vector::active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
{
  return basic_active_process_determine_for_MPI (space_dimensions_all_processes_max , group_processes_number , index);
}






#ifdef UseMPI

void GSM_vector::MPI_Send (const unsigned int Recv_process , const unsigned int tag , const MPI_Comm MPI_C)
{
  if (space_dimensions_all_processes_max == 0) return;

  MPI_helper::Send<TYPE> (space_dimensions_all_processes_max , table ,  Recv_process , tag , MPI_C);
}

void GSM_vector::MPI_Recv (const unsigned int Send_process , const unsigned int tag , const MPI_Comm MPI_C)
{
  if (space_dimensions_all_processes_max == 0) return;

  MPI_helper::Recv<TYPE> (space_dimensions_all_processes_max , table ,  Send_process , tag , MPI_C);
}

void GSM_vector::MPI_Sendrecv_replace (
				       const unsigned int Send_process , 
				       const unsigned int Recv_process ,
				       const int Send_tag ,
				       const int Recv_tag ,
				       const MPI_Comm MPI_C)
{
  if (space_dimensions_all_processes_max == 0) return;

  MPI_helper::Sendrecv_replace<TYPE> (space_dimensions_all_processes_max , table , Send_process , Recv_process , Send_tag , Recv_tag , MPI_C);
}

void GSM_vector::MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  if (space_dimensions_all_processes_max == 0) return;
  
  MPI_helper::Bcast<TYPE> (space_dimensions_all_processes_max , table ,  Send_process , MPI_C);
}

void GSM_vector::MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  if (space_dimensions_all_processes_max == 0) return;
  
  MPI_helper::Reduce<TYPE> (space_dimensions_all_processes_max , table , op , Recv_process , process , MPI_C);
}

void GSM_vector::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  if (space_dimensions_all_processes_max == 0) return;

  MPI_helper::Allreduce<TYPE> (space_dimensions_all_processes_max , table , op , MPI_C);
}

#endif





istream & operator >> (istream &is , class GSM_vector &PSI)
{
  const class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();

  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();

  PSI.zero ();

  for (unsigned int i = 0 ; i < space_dimension_process ; i++) is >> PSI[i];

  return is;
}





ostream & operator << (ostream &os , const class GSM_vector &PSI)
{
  const unsigned int space_dimensions_all_processes_max = PSI.get_space_dimensions_all_processes_max ();
  
  for (unsigned int i = 0 ; i < space_dimensions_all_processes_max ; i++) os << PSI[i] << " ";

  return os;
}







void orthogonalization_not_disk (
				 const bool is_there_cout_detailed ,
				 const unsigned int i , 
				 class array<class GSM_vector> &V_tab)
{ 
  if (i == 0) return;

  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_detailed) ? (absolute_time_determine ()) : (NADA);
  
  class GSM_vector &Vi = V_tab(i);

  for (unsigned int ii = 0 ; ii < i ; ii++)
    {
      const class GSM_vector &Vii = V_tab(ii);
      
      const TYPE Vi_scalar_Vii = (Vi*Vii);
      
      Vi -= Vi_scalar_Vii*Vii;
    }

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_detailed)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time;
      
      cout << "Orthogonalization applied. time:" << relative_time << " s" << endl;
    }
}




