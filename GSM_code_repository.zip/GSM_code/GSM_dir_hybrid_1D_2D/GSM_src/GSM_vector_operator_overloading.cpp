#include "../GSM_include/GSM_include_def.h"

using namespace string_routines;

// TYPE is double or complex
// -------------------------

// Routines of operator overloading used with GSM vectors
// ------------------------------------------------------
// The class Op_PSI_closure_str is a closure class, i.e. a wrapper with which all numerical operations are deferred, to deal with Op.Psi, with Op an operator and Psi a GSM vector.
// It allows to avoid intermediates when having Psi = x*(Op0.Psi0) + y*(Op1.Psi1), for example, as, without closure classes,
// 5 temporary vectors would be created, one for Op0.Psi0, one for x*(Op0.Psi0), one for Op1.Psi1, one for y*(Op1.Psi1), and one for the sum.
// Closure classes allow to avoid it, but one has to restrict the number of terms in expression such as (H - E)*PSI0 + J2*PSI1 + (x*L2_CM)*PSI2 + ...
// Up to 10 terms (which is CLOSURE_TERMS_MAX in const.h) can be taken into account in the code. As one rarely has more than 3 terms, this is sufficient.
// All the arrays of a Op_PSI_closure_str class then have 10 terms.
// An error message occurs if one has more than 10 terms,
//
// Format of an operator: +/- x.O +/- alpha , +/- O.x +/- alpha , +/- O/x +/- alpha
//                        +/- alpha +/- x.O , +/- alpha +/- O.x , +/- alpha +/- O/x
//
// O operators: H , J2 , Jpm , T2 , CM_operator , L2_CM , cluster_HO_to_Berggren.
//              TRS (time-reversal symmetry) can be used along with other operators, but with TRS (Psi), not TRS*PSI, if TRS is of TRS_class type (see GSM_TRS_class.cpp).
//              (x*TRS) has then not been coded, as one cannot write (x*TRS)*Psi. But one can write x*TRS (PSI) + ..., as TRS (PSI) is of Op_PSI_closure_str type.
//
// Products of O operators are not accepted: Jplus.Jminus, H.J2, for example, cannot be handled with overloading.
// alpha has to be zero if |Psi[in]> and |Psi[out]> do not have the same quantum numbers.
// alpha is then not zero only for Id , H , J2 , T2 , CM_operator if |Psi[in]> and |Psi[out]> have the same quantum numbers and L2_CM.
// For the identity times scalar operator, x is zero by definition, so that the operator is alpha.Id.
// No test is made to check whether x or alpha is equal to zero or not.
// 
//
// a+ and A+ cluster are treated outside Op_PSI_closure_str as operator action crashes with parallel computation (reason unknown).
// PSI_out = , += , -= a+ (...) , x.a+ (...) , A+ cluster (...) , x.A+ cluster (...) are implemented.
//
// Default values are those of Id: operator is Id, x=0 and alpha=1.
//
// Straightforward routines are not commented.




Op_PSI_closure_str::Op_PSI_closure_str (const unsigned int closure_terms_number_c)
  : closure_terms_number (closure_terms_number_c)
{
  if (closure_terms_number > CLOSURE_TERMS_MAX) error_message_print_abort ("closure_terms_number cannot be larger than CLOSURE_TERMS_MAX=" + make_string<unsigned int> (CLOSURE_TERMS_MAX) + " (GSM_vector)");

  default_values_init ();
}

Op_PSI_closure_str::Op_PSI_closure_str (const class Op_PSI_closure_str &Op_PSI_closure_old) 
{
  default_values_init ();

  const unsigned int Op_PSI_closure_old_closure_terms_number = Op_PSI_closure_old.closure_terms_number;

  closure_terms_number = Op_PSI_closure_old_closure_terms_number;

  const enum operator_type *const Op_PSI_closure_old_Op_tab = Op_PSI_closure_old.Op_tab;

  const TYPE *const Op_PSI_closure_old_x_tab = Op_PSI_closure_old.x_tab;

  const TYPE *const Op_PSI_closure_old_alpha_tab = Op_PSI_closure_old.alpha_tab;

  const void *const *const Op_old_ptrs = Op_PSI_closure_old.Op_ptrs;

  const class GSM_vector *const *const PSI_in_old_ptrs = Op_PSI_closure_old.PSI_in_ptrs;

  for (unsigned int index = 0 ; index < closure_terms_number ; index++)
    {
      Op_tab[index] = Op_PSI_closure_old_Op_tab[index];

      x_tab[index] = Op_PSI_closure_old_x_tab[index];

      alpha_tab[index] = Op_PSI_closure_old_alpha_tab[index];

      Op_ptrs[index] = Op_old_ptrs[index];

      PSI_in_ptrs[index] = PSI_in_old_ptrs[index];
    } 
}

Op_PSI_closure_str::Op_PSI_closure_str (const class GSM_vector &PSI_in)
  : closure_terms_number (1)
{
  default_values_init ();

  Op_tab[0] = IDENTITY;

  x_tab[0] = 0.0;

  alpha_tab[0] = 1.0;

  PSI_in_ptrs[0] = &PSI_in;
}


Op_PSI_closure_str::Op_PSI_closure_str (const class TRS_class &TRS , const class GSM_vector &PSI)
  : closure_terms_number (1)
{
  default_values_init ();

  Op_tab[0] = TIME_REVERSAL_SYMMETRY;

  x_tab[0] = 1.0;

  alpha_tab[0] = 0.0;

  Op_ptrs[0] = &TRS;

  PSI_in_ptrs[0] = &PSI;
}


const class Op_PSI_closure_str & Op_PSI_closure_str::operator = (const class Op_PSI_closure_str &Op_PSI_closure)
{
  default_values_init ();

  const unsigned int Op_PSI_closure_closure_terms_number = Op_PSI_closure.closure_terms_number;

  closure_terms_number = Op_PSI_closure_closure_terms_number;

  const enum operator_type *const Op_PSI_closure_Op_tab = Op_PSI_closure.Op_tab;

  const TYPE *const Op_PSI_closure_x_tab = Op_PSI_closure.x_tab;

  const TYPE *const Op_PSI_closure_alpha_tab = Op_PSI_closure.alpha_tab;

  const void *const *const Op_PSI_closure_Op_ptrs = Op_PSI_closure.Op_ptrs;

  const class GSM_vector *const *const Op_PSI_closure_PSI_in_ptrs = Op_PSI_closure.PSI_in_ptrs;

  for (unsigned int index = 0 ; index < closure_terms_number ; index++)
    {
      Op_tab[index] = Op_PSI_closure_Op_tab[index];

      x_tab[index] = Op_PSI_closure_x_tab[index];

      alpha_tab[index] = Op_PSI_closure_alpha_tab[index];

      Op_ptrs[index] = Op_PSI_closure_Op_ptrs[index];

      PSI_in_ptrs[index] = Op_PSI_closure_PSI_in_ptrs[index];
    } 

  return *this;
}


unsigned int Op_PSI_closure_str::get_closure_terms_number () const
{
  return closure_terms_number;	
}

enum operator_type Op_PSI_closure_str::get_Op (const unsigned int index) const
{
  return Op_tab[index];	
}

TYPE Op_PSI_closure_str::get_x (const unsigned int index) const
{
  return x_tab[index];
}

TYPE Op_PSI_closure_str::get_alpha (const unsigned int index) const
{
  return alpha_tab[index];
}

const class H_class & Op_PSI_closure_str::get_H (const unsigned int index) const
{
  return *(static_cast<const class H_class *> (Op_ptrs[index]));
}

const class Jpm_class & Op_PSI_closure_str::get_Jpm (const unsigned int index) const
{
  return *(static_cast<const class Jpm_class *> (Op_ptrs[index]));
}

const class J2_class & Op_PSI_closure_str::get_J2 (const unsigned int index) const
{
  return *(static_cast<const class J2_class *> (Op_ptrs[index]));
}

const class T2_class & Op_PSI_closure_str::get_T2 (const unsigned int index) const
{
  return *(static_cast<const class T2_class *> (Op_ptrs[index]));
}

const class CM_operator_class & Op_PSI_closure_str::get_CM_operator (const unsigned int index) const
{
  return *(static_cast<const class CM_operator_class *> (Op_ptrs[index]));
}

const class L2_CM_class & Op_PSI_closure_str::get_L2_CM (const unsigned int index) const
{
  return *(static_cast<const class L2_CM_class *> (Op_ptrs[index]));
}

const class TRS_class & Op_PSI_closure_str::get_TRS (const unsigned int index) const
{
  return *(static_cast<const class TRS_class *> (Op_ptrs[index]));
}

const class cluster_HO_to_Berggren_class & Op_PSI_closure_str::get_cluster_HO_to_Berggren (const unsigned int index) const
{
  return *(static_cast<const class cluster_HO_to_Berggren_class *> (Op_ptrs[index]));
}

const class GSM_vector & Op_PSI_closure_str::get_PSI_in (const unsigned int index) const
{
  return *(PSI_in_ptrs[index]);
}


void Op_PSI_closure_str::default_values_init ()
{
  for (unsigned int index = 0 ; index < CLOSURE_TERMS_MAX ; index++)
    {
      Op_tab[index] = IDENTITY;

      x_tab[index] = 0.0;

      alpha_tab[index] = 1.0;

      Op_ptrs[index] = NULL;

      PSI_in_ptrs[index] = NULL;
    } 
}




void Op_PSI_closure_str::fill_data (
				    const enum operator_type Op , 
				    const TYPE x , 
				    const TYPE alpha , 
				    const void *const Op_ptr , 
				    const class GSM_vector *const PSI_in_ptr , 
				    const unsigned int index)
{
  Op_tab[index] = Op;

  x_tab[index] = x;

  alpha_tab[index] = alpha;

  Op_ptrs[index] = Op_ptr;

  PSI_in_ptrs[index] = PSI_in_ptr;
}



void Op_PSI_closure_str::fill_data (
				    const class Op_PSI_closure_str &Op_PSI_closure , 
				    const unsigned int i , 
				    const unsigned int index)
{
  const enum operator_type *const Op_PSI_closure_Op_tab = Op_PSI_closure.Op_tab;

  const TYPE *const Op_PSI_closure_x_tab = Op_PSI_closure.x_tab;

  const TYPE *const Op_PSI_closure_alpha_tab = Op_PSI_closure.alpha_tab;

  const void *const *const Op_PSI_closure_Op_ptrs = Op_PSI_closure.Op_ptrs;

  const class GSM_vector *const *const Op_PSI_closure_PSI_in_ptrs = Op_PSI_closure.PSI_in_ptrs;

  const enum operator_type Op = Op_PSI_closure_Op_tab[i];

  const TYPE x = Op_PSI_closure_x_tab[i];

  const TYPE alpha = Op_PSI_closure_alpha_tab[i];

  const void *const Op_ptr = Op_PSI_closure_Op_ptrs[i];

  const class GSM_vector *const PSI_in_ptr = Op_PSI_closure_PSI_in_ptrs[i];
	
  Op_tab[index] = Op;

  x_tab[index] = x;

  alpha_tab[index] = alpha;

  Op_ptrs[index] = Op_ptr;

  PSI_in_ptrs[index] = PSI_in_ptr;
}



bool Op_PSI_closure_str::is_it_only_scalar_identity () const
{
  for (unsigned int index = 0 ; index < closure_terms_number ; index++)
    {
      if (Op_tab[index] != IDENTITY) return false;
    }

  return true;
}

void Op_PSI_closure_str::sign_change (const unsigned int index)
{
  x_tab[index] = -x_tab[index];

  alpha_tab[index] = -alpha_tab[index];
}

void Op_PSI_closure_str::global_sign_change ()
{
  for (unsigned int index = 0 ; index < closure_terms_number ; index++) sign_change (index);
}

void Op_PSI_closure_str::factor_multiplication (const unsigned int index , const TYPE &factor)
{
  x_tab[index] *= factor;

  alpha_tab[index] *= factor;
}

void Op_PSI_closure_str::global_factor_multiplication (const TYPE &factor)
{
  for (unsigned int index = 0 ; index < closure_terms_number ; index++) factor_multiplication (index , factor);
}

class GSM_vector_helper_class & Op_PSI_closure_str::GSM_vector_helper_determine () const
{
  if (PSI_in_ptrs[0] == NULL) error_message_print_abort ("At least one PSI_in vector must be allocated in Op_PSI_closure_str::GSM_vector_helper_determine");
 
  const enum operator_type Op = Op_tab[0];
  
  switch (Op)
    {
    case IDENTITY:                    return                 get_PSI_in (0).get_GSM_vector_helper ();
    case HAMILTONIAN:                 return                      get_H (0).get_GSM_vector_helper ();
    case T_SQUARE:                    return                     get_T2 (0).get_GSM_vector_helper ();
    case J_PLUS_MINUS:                return                    get_Jpm (0).get_GSM_vector_helper_out ();
    case J_SQUARE:                    return       get_J2 (0).get_Jminus ().get_GSM_vector_helper_out ();
    case CENTER_OF_MASS:              return            get_CM_operator (0).get_GSM_vector_helper_out ();
    case L_SQUARE_CENTER_OF_MASS:     return        get_L2_CM (0).get_Lz ().get_GSM_vector_helper_out ();
    case TIME_REVERSAL_SYMMETRY:      return                    get_TRS (0).get_GSM_vector_helper_out ();
    case CLUSTER_HO_TO_BERGGREN:      return get_cluster_HO_to_Berggren (0).get_GSM_vector_helper ();
      
    default: error_message_print_abort ("No operator recognized in Op_PSI_closure_str::GSM_vector_helper_determine");
    }

  return get_PSI_in (0).get_GSM_vector_helper ();
}




// Check if PSI_out is part of the vectors used in the closure.
// If it does , a copy of PSI_out must be used to store the resulting vector before assigning it to the initial PSI_out.

bool Op_PSI_closure_str::is_PSI_out_used (const class GSM_vector &PSI_out) const
{
  const class GSM_vector *const PSI_out_ptr = &PSI_out;

  for (unsigned int index = 0 ; index < closure_terms_number ; index++)
    {
      if (PSI_in_ptrs[index] == PSI_out_ptr) return true;
    }

  return false;
}




// closure application of all operators

void Op_PSI_closure_str::all_Op_PSI_in_calc_add (class GSM_vector &PSI_out) const
{  
  for (unsigned int index = 0 ; index < closure_terms_number ; index++)
    {
      const enum operator_type Op = get_Op (index);

      const TYPE x = get_x (index);

      const TYPE alpha = get_alpha (index);

      if ((x != 0.0) && (Op != IDENTITY))
	{
	  PSI_out /= x;

	  switch (Op)
	    {
	    case HAMILTONIAN:
	      {
		const TYPE alpha_over_x = alpha/x;

		const class H_class &H = get_H (index);

		const class GSM_vector &PSI_in = get_PSI_in (index);

		H.apply_add (PSI_in , alpha_over_x , PSI_out);
	      } break;

	    case J_PLUS_MINUS:
	      {
		const class Jpm_class &Jpm = get_Jpm (index);

		const class GSM_vector &PSI_in = get_PSI_in (index);

		Jpm.apply_add (PSI_in , PSI_out);
	      } break;

	    case J_SQUARE:
	      {
		const TYPE alpha_over_x = alpha/x;

		const class J2_class &J2 = get_J2 (index);

		const class GSM_vector &PSI_in = get_PSI_in (index);

		J2.apply_add (PSI_in , alpha_over_x , PSI_out);
	      } break;

	    case T_SQUARE:
	      {
		const TYPE alpha_over_x = alpha/x;

		const class T2_class &T2 = get_T2 (index);

		const class GSM_vector &PSI_in = get_PSI_in (index);

		T2.apply_add (PSI_in , alpha_over_x , PSI_out);
	      } break;

	    case CENTER_OF_MASS:
	      {
		const TYPE alpha_over_x = alpha/x;

		const class CM_operator_class &CM_operator = get_CM_operator (index);

		const class GSM_vector &PSI_in = get_PSI_in (index);

		CM_operator.apply_add (PSI_in , alpha_over_x , PSI_out);
	      } break;

	    case L_SQUARE_CENTER_OF_MASS:
	      {
		const TYPE alpha_over_x = alpha/x;

		const class L2_CM_class &L2_CM = get_L2_CM (index);

		const class GSM_vector &PSI_in = get_PSI_in (index);
		
		L2_CM.apply_add (PSI_in , alpha_over_x , PSI_out);
	      } break;

	    case TIME_REVERSAL_SYMMETRY:
	      {	
		const class TRS_class &TRS = get_TRS (index);

		const class GSM_vector &PSI_in = get_PSI_in (index);		

		TRS.apply_add (PSI_in , PSI_out);
	      } break;

	    case CLUSTER_HO_TO_BERGGREN:
	      {
		const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren = get_cluster_HO_to_Berggren (index);

		const class GSM_vector &PSI_in = get_PSI_in (index);

		cluster_HO_to_Berggren.apply_add (PSI_in , PSI_out);
	      } break;

	    default: error_message_print_abort ("No operator recognized in GSM_vector::operator =");
	    }

	  PSI_out *= x;
	}	
      else if (alpha != 0.0)
	{
	  const class GSM_vector &PSI_in = get_PSI_in (index);

	  const class GSM_vector_helper_class &GSM_vector_helper = PSI_in.get_GSM_vector_helper ();

	  const unsigned int space_dimensions_all_processes_max = GSM_vector_helper.get_space_dimensions_all_processes_max ();
	  
	  if (alpha == 1.0)
	    {
	      for (unsigned int i = 0 ; i < space_dimensions_all_processes_max ; i++) PSI_out[i] += PSI_in[i];
	    }
	  else if (alpha == -1.0)
	    {
	      for (unsigned int i = 0 ; i < space_dimensions_all_processes_max ; i++) PSI_out[i] -= PSI_in[i];
	    }
	  else
	    {
	      for (unsigned int i = 0 ; i < space_dimensions_all_processes_max ; i++) PSI_out[i] += alpha*PSI_in[i];
	    }
	}
    }
}






class Op_PSI_closure_str operator * (const class H_class &H , const class GSM_vector &PSI_in)
{
  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (HAMILTONIAN , 1.0 , 0.0 , &H , &PSI_in , 0);

  return Op_PSI_closure;
}

class Op_PSI_closure_str operator * (const class Jpm_class &Jpm , const class GSM_vector &PSI_in)
{
  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (J_PLUS_MINUS , 1.0 , 0.0 , &Jpm , &PSI_in , 0);

  return Op_PSI_closure;
}

class Op_PSI_closure_str operator * (const class J2_class &J2 , const class GSM_vector &PSI_in)
{	
  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (J_SQUARE , 1.0 , 0.0 , &J2 , &PSI_in , 0);

  return Op_PSI_closure;
}

class Op_PSI_closure_str operator * (const class T2_class &T2 , const class GSM_vector &PSI_in)
{
  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (T_SQUARE , 1.0 , 0.0 , &T2 , &PSI_in , 0);

  return Op_PSI_closure;
}

class Op_PSI_closure_str operator * (const class CM_operator_class &CM_operator , const class GSM_vector &PSI_in)
{
  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (CENTER_OF_MASS , 1.0 , 0.0 , &CM_operator , &PSI_in , 0);

  return Op_PSI_closure;
}

class Op_PSI_closure_str operator * (const class L2_CM_class &L2_CM , const class GSM_vector &PSI_in)
{	
  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (L_SQUARE_CENTER_OF_MASS , 1.0 , 0.0 , &L2_CM , &PSI_in , 0);

  return Op_PSI_closure;
}


class Op_PSI_closure_str operator * (const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren , const class GSM_vector &PSI_HO_in)
{
  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (CLUSTER_HO_TO_BERGGREN , 1.0 , 0.0 , &cluster_HO_to_Berggren , &PSI_HO_in , 0);

  return Op_PSI_closure;
}



class Op_PSI_closure_str operator * (const class xH_plus_alpha_str &xH_plus_alpha , const class GSM_vector &PSI_in)
{
  const TYPE &x = xH_plus_alpha.x;

  const TYPE &alpha = xH_plus_alpha.alpha;

  const class H_class &H = xH_plus_alpha.H;

  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (HAMILTONIAN , x , alpha , &H , &PSI_in , 0);

  return Op_PSI_closure;
}


class Op_PSI_closure_str operator * (const class xJpm_str &xJpm , const class GSM_vector &PSI_in)
{
  const TYPE &x = xJpm.x;

  const class Jpm_class &Jpm = xJpm.Jpm;

  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (J_PLUS_MINUS , x , 0.0 , &Jpm , &PSI_in , 0);

  return Op_PSI_closure;
}


class Op_PSI_closure_str operator * (const class xJ2_plus_alpha_str &xJ2_plus_alpha , const class GSM_vector &PSI_in)
{
  const TYPE &x = xJ2_plus_alpha.x;

  const TYPE &alpha = xJ2_plus_alpha.alpha;

  const class J2_class &J2 = xJ2_plus_alpha.J2;

  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (J_SQUARE , x , alpha , &J2 , &PSI_in , 0);

  return Op_PSI_closure;
}


class Op_PSI_closure_str operator * (const class xT2_plus_alpha_str &xT2_plus_alpha , const class GSM_vector &PSI_in)
{
  const TYPE &x = xT2_plus_alpha.x;

  const TYPE &alpha = xT2_plus_alpha.alpha;

  const class T2_class &T2 = xT2_plus_alpha.T2;

  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (T_SQUARE , x , alpha , &T2 , &PSI_in , 0);

  return Op_PSI_closure;
}


class Op_PSI_closure_str operator * (const class xCM_operator_plus_alpha_str &xCM_operator_plus_alpha , const class GSM_vector &PSI_in)
{
  const TYPE &x = xCM_operator_plus_alpha.x;

  const TYPE &alpha = xCM_operator_plus_alpha.alpha;

  const class CM_operator_class &CM_operator = xCM_operator_plus_alpha.CM_operator;

  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (CENTER_OF_MASS , x , alpha , &CM_operator , &PSI_in , 0);

  return Op_PSI_closure;
}


class Op_PSI_closure_str operator * (const class xL2_CM_plus_alpha_str &xL2_CM_plus_alpha , const class GSM_vector &PSI_in)
{
  const TYPE &x = xL2_CM_plus_alpha.x;

  const TYPE &alpha = xL2_CM_plus_alpha.alpha;

  const class L2_CM_class &L2_CM = xL2_CM_plus_alpha.L2_CM;

  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (L_SQUARE_CENTER_OF_MASS , x , alpha , &L2_CM , &PSI_in , 0);

  return Op_PSI_closure;
}


class Op_PSI_closure_str operator * (const class x_cluster_HO_to_Berggren_str &x_cluster_HO_to_Berggren , const class GSM_vector &PSI_HO_in)
{
  const TYPE &x = x_cluster_HO_to_Berggren.x;

  const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren = x_cluster_HO_to_Berggren.cluster_HO_to_Berggren;

  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (CLUSTER_HO_TO_BERGGREN , x , 0.0 , &cluster_HO_to_Berggren , &PSI_HO_in , 0);

  return Op_PSI_closure;
}





class Op_PSI_closure_str Op_PSI_closure_str::operator_times_scalar_identity (
									     const enum operator_type Op , 
									     const TYPE x_Op , 
									     const TYPE alpha_Op ,  
									     const void *const Op_ptr) const
{
  if (!is_it_only_scalar_identity ())
    error_message_print_abort ("One can only multiply an operator by a vector or scalar multiples of vectors in Op_PSI_closure_str::operator_times_scalar_identity.");

  class Op_PSI_closure_str Op_PSI_closure(closure_terms_number);

  for (unsigned int index = 0 ; index < closure_terms_number ; index++)
    {
      const TYPE alpha = alpha_tab[index];

      const TYPE x_Op_alpha =  x_Op*alpha;

      const TYPE alpha_Op_alpha = alpha_Op*alpha;

      const class GSM_vector *const PSI_in_ptr = PSI_in_ptrs[index];

      Op_PSI_closure.fill_data (Op , x_Op_alpha , alpha_Op_alpha , Op_ptr , PSI_in_ptr , index);
    }

  return Op_PSI_closure;
}

class Op_PSI_closure_str operator * (const class H_class &H , const class Op_PSI_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (HAMILTONIAN , 1.0 , 0.0 , &H);
}

class Op_PSI_closure_str operator * (const class Jpm_class &Jpm , const class Op_PSI_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (J_PLUS_MINUS , 1.0 , 0.0 , &Jpm);
}

class Op_PSI_closure_str operator * (const class J2_class &J2 , const class Op_PSI_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (J_SQUARE , 1.0 , 0.0 , &J2);
}

class Op_PSI_closure_str operator * (const class T2_class &T2 , const class Op_PSI_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (T_SQUARE , 1.0 , 0.0 , &T2);	
}

class Op_PSI_closure_str operator * (const class CM_operator_class &CM_operator , const class Op_PSI_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (CENTER_OF_MASS , 1.0 , 0.0 , &CM_operator);
}

class Op_PSI_closure_str operator * (const class L2_CM_class &L2_CM , const class Op_PSI_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (L_SQUARE_CENTER_OF_MASS , 1.0 , 0.0 , &L2_CM);
}

class Op_PSI_closure_str operator * (const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren , const class Op_PSI_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (CLUSTER_HO_TO_BERGGREN , 1.0 , 0.0 , &cluster_HO_to_Berggren);
}










class Op_PSI_closure_str operator * (const class xH_plus_alpha_str &xH_plus_alpha , const class Op_PSI_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (HAMILTONIAN , xH_plus_alpha.x , xH_plus_alpha.alpha , &xH_plus_alpha.H);
}

class Op_PSI_closure_str operator * (const class xJpm_str &xJpm , const class Op_PSI_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (J_PLUS_MINUS , xJpm.x , 0.0 , &xJpm.Jpm);
}

class Op_PSI_closure_str operator * (const class xJ2_plus_alpha_str &xJ2_plus_alpha , const class Op_PSI_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (J_SQUARE , xJ2_plus_alpha.x , xJ2_plus_alpha.alpha , &xJ2_plus_alpha.J2);
}

class Op_PSI_closure_str operator * (const class xT2_plus_alpha_str &xT2_plus_alpha , const class Op_PSI_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (T_SQUARE , xT2_plus_alpha.x , xT2_plus_alpha.alpha , &xT2_plus_alpha.T2);	
}

class Op_PSI_closure_str operator * (const class xCM_operator_plus_alpha_str &xCM_operator_plus_alpha , const class Op_PSI_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (CENTER_OF_MASS , xCM_operator_plus_alpha.x , xCM_operator_plus_alpha.alpha , &xCM_operator_plus_alpha.CM_operator);
}

class Op_PSI_closure_str operator * (const class xL2_CM_plus_alpha_str &xL2_CM_plus_alpha , const class Op_PSI_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (L_SQUARE_CENTER_OF_MASS , xL2_CM_plus_alpha.x , xL2_CM_plus_alpha.alpha , &xL2_CM_plus_alpha.L2_CM);
}

class Op_PSI_closure_str operator * (const class x_cluster_HO_to_Berggren_str &x_cluster_HO_to_Berggren , const class Op_PSI_closure_str &Op_PSI_closure)
{
  return Op_PSI_closure.operator_times_scalar_identity (CLUSTER_HO_TO_BERGGREN , x_cluster_HO_to_Berggren.x , 0.0 , &x_cluster_HO_to_Berggren.cluster_HO_to_Berggren);
}






class Op_PSI_closure_str operator + (const class GSM_vector &PSI_in)
{
  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (IDENTITY , 0.0 , 1.0 , NULL , &PSI_in , 0);

  return Op_PSI_closure;
}

class Op_PSI_closure_str operator - (const class GSM_vector &PSI_in)
{
  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (IDENTITY , 0.0 , -1.0 , NULL , &PSI_in , 0);

  return Op_PSI_closure;
}

class Op_PSI_closure_str operator * (const TYPE &alpha , const class GSM_vector &PSI_in)
{	
  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (IDENTITY , 0.0 , alpha , NULL , &PSI_in , 0);

  return Op_PSI_closure;
}

class Op_PSI_closure_str operator * (const class GSM_vector &PSI_in , const TYPE &alpha)
{	
  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (IDENTITY , 0.0 , alpha , NULL , &PSI_in , 0);

  return Op_PSI_closure;
}

class Op_PSI_closure_str operator / (const class GSM_vector &PSI_in , const TYPE &one_over_alpha)
{
  const TYPE alpha = 1.0/one_over_alpha;

  class Op_PSI_closure_str Op_PSI_closure(1);

  Op_PSI_closure.fill_data (IDENTITY , 0.0 , alpha , NULL , &PSI_in , 0);

  return Op_PSI_closure;
}




class Op_PSI_closure_str operator + (const class Op_PSI_closure_str &Op_PSI_closure)
{
  class Op_PSI_closure_str Op_PSI_closure_new = Op_PSI_closure;

  return Op_PSI_closure_new;
}

class Op_PSI_closure_str operator - (const class Op_PSI_closure_str &Op_PSI_closure)
{
  class Op_PSI_closure_str Op_PSI_closure_new = Op_PSI_closure;

  Op_PSI_closure_new.global_sign_change ();

  return Op_PSI_closure_new;
}

class Op_PSI_closure_str operator * (const TYPE &factor , const class Op_PSI_closure_str &Op_PSI_closure)
{
  class Op_PSI_closure_str Op_PSI_closure_new = Op_PSI_closure;

  Op_PSI_closure_new.global_factor_multiplication (factor);

  return Op_PSI_closure_new;
}

class Op_PSI_closure_str operator * (const class Op_PSI_closure_str &Op_PSI_closure , const TYPE &factor)
{
  class Op_PSI_closure_str Op_PSI_closure_new = Op_PSI_closure;

  Op_PSI_closure_new.global_factor_multiplication (factor);

  return Op_PSI_closure_new;
}

class Op_PSI_closure_str operator / (const class Op_PSI_closure_str &Op_PSI_closure , const TYPE &factor)
{
  const TYPE one_over_factor = 1.0/factor;

  class Op_PSI_closure_str Op_PSI_closure_new = Op_PSI_closure;

  Op_PSI_closure_new.global_factor_multiplication (one_over_factor);

  return Op_PSI_closure_new;
}













class Op_PSI_closure_str Op_PSI_closure_add (
					     const int sign , 
					     const class Op_PSI_closure_str &Op_PSI_closure_a , 
					     const class Op_PSI_closure_str &Op_PSI_closure_b)
{
  const unsigned int closure_terms_number_a = Op_PSI_closure_a.get_closure_terms_number ();
  const unsigned int closure_terms_number_b = Op_PSI_closure_b.get_closure_terms_number ();

  const unsigned int closure_terms_number_ab = closure_terms_number_a + closure_terms_number_b;
	
  class Op_PSI_closure_str Op_PSI_closure(closure_terms_number_ab);

  for (unsigned int i = 0 ; i < closure_terms_number_ab ; i++)
    {
      const unsigned int i_ab = (i < closure_terms_number_a) ? (i) : (i - closure_terms_number_a);

      const int sign_ab = (i < closure_terms_number_a) ? (1) : (sign);

      const class Op_PSI_closure_str &Op_PSI_closure_ab = (i < closure_terms_number_a) ? (Op_PSI_closure_a) : (Op_PSI_closure_b);

      Op_PSI_closure.fill_data (Op_PSI_closure_ab , i_ab , i);

      if (sign_ab == -1) Op_PSI_closure.sign_change (i);
    }

  return Op_PSI_closure;
}



class Op_PSI_closure_str operator + (const class Op_PSI_closure_str &Op_PSI_closure_a , const class Op_PSI_closure_str &Op_PSI_closure_b)
{
  return Op_PSI_closure_add (1 , Op_PSI_closure_a , Op_PSI_closure_b);
}


class Op_PSI_closure_str operator - (const class Op_PSI_closure_str &Op_PSI_closure_a , const class Op_PSI_closure_str &Op_PSI_closure_b)
{
  return Op_PSI_closure_add (-1 , Op_PSI_closure_a , Op_PSI_closure_b);
}



















const class GSM_vector & GSM_vector::operator = (const class Op_PSI_closure_str &Op_PSI_closure)
{
  class GSM_vector &PSI_out = *this;

  if (Op_PSI_closure.is_PSI_out_used (PSI_out))
    {
      class GSM_vector PSI_out_copy = PSI_out;

      PSI_out_copy = 0.0;

      Op_PSI_closure.all_Op_PSI_in_calc_add (PSI_out_copy);

      PSI_out = PSI_out_copy;
    }
  else
    {
      PSI_out = 0.0;

      Op_PSI_closure.all_Op_PSI_in_calc_add (PSI_out);
    }

  return PSI_out;
}






const class GSM_vector & GSM_vector::operator = (const class a_dagger_baryon_PSI_str &a_dagger_baryon_PSI)
{
  const bool full_common_vectors_used_in_file = a_dagger_baryon_PSI.full_common_vectors_used_in_file;

  const class nljm_struct &phi_projectile = a_dagger_baryon_PSI.phi_projectile;
  
  const class correlated_state_str &PSI_IN_qn = a_dagger_baryon_PSI.PSI_IN_qn;

  const double M_IN = a_dagger_baryon_PSI.M_IN;

  class GSM_vector &PSI_out = *this;

  PSI_out = 0.0;
    
  a_dagger_baryon_helper::a_dagger_baryon_apply_add (full_common_vectors_used_in_file , phi_projectile , PSI_IN_qn , M_IN , PSI_out);

  return PSI_out;
}




const class GSM_vector & GSM_vector::operator = (const class A_dagger_cluster_PSI_str &A_dagger_cluster_PSI)
{
  const bool full_common_vectors_used_in_file = A_dagger_cluster_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_dagger_cluster_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_dagger_cluster_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_dagger_cluster_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_dagger_cluster_PSI.LCM_cluster_projectile;
  
  const double M_cluster_projectile = A_dagger_cluster_PSI.M_cluster_projectile;

  const class correlated_state_str &PSI_cluster_projectile_qn = A_dagger_cluster_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_dagger_cluster_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_dagger_cluster_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_dagger_cluster_PSI.NCM_HO_IN;

  const int LCM_IN = A_dagger_cluster_PSI.LCM_IN;
  
  const double M_IN = A_dagger_cluster_PSI.M_IN;

  const class correlated_state_str &PSI_IN_qn = A_dagger_cluster_PSI.PSI_IN_qn;  
	
  class GSM_vector &PSI_out = *this;

  PSI_out = 0.0;
  
  A_dagger_cluster_helper::A_dagger_cluster_apply_add (full_common_vectors_used_in_file ,
						       is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , M_cluster_projectile , PSI_cluster_projectile_qn , 
						       is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , M_IN                 , PSI_IN_qn                 , PSI_out);

  return PSI_out;
}





const class GSM_vector & GSM_vector::operator = (const class x_a_dagger_baryon_PSI_str &x_a_dagger_baryon_PSI)
{
  const class a_dagger_baryon_PSI_str &a_dagger_baryon_PSI = x_a_dagger_baryon_PSI.a_dagger_baryon_PSI;

  const TYPE &x = x_a_dagger_baryon_PSI.x;

  class GSM_vector &PSI_out = *this;

  PSI_out = 0.0;

  if (x == 0.0) return PSI_out;
  
  const bool full_common_vectors_used_in_file = a_dagger_baryon_PSI.full_common_vectors_used_in_file; 

  const class nljm_struct &phi_projectile = a_dagger_baryon_PSI.phi_projectile;

  const class correlated_state_str &PSI_IN_qn = a_dagger_baryon_PSI.PSI_IN_qn;

  const double M_IN = a_dagger_baryon_PSI.M_IN;
	
  a_dagger_baryon_helper::a_dagger_baryon_apply_add (full_common_vectors_used_in_file , phi_projectile , PSI_IN_qn , M_IN , PSI_out);

  PSI_out *= x;

  return PSI_out;
}






const class GSM_vector & GSM_vector::operator = (const class x_A_dagger_cluster_PSI_str &x_A_dagger_cluster_PSI)
{
  const class A_dagger_cluster_PSI_str &A_dagger_cluster_PSI = x_A_dagger_cluster_PSI.A_dagger_cluster_PSI;

  const TYPE &x = x_A_dagger_cluster_PSI.x;	

  class GSM_vector &PSI_out = *this;

  PSI_out = 0.0;

  if (x == 0.0) return PSI_out;

  const bool full_common_vectors_used_in_file = A_dagger_cluster_PSI.full_common_vectors_used_in_file;
  
  const bool is_it_CM_relative_cluster_projectile = A_dagger_cluster_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_dagger_cluster_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_dagger_cluster_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_dagger_cluster_PSI.LCM_cluster_projectile;
  
  const double M_cluster_projectile = A_dagger_cluster_PSI.M_cluster_projectile;

  const class correlated_state_str &PSI_cluster_projectile_qn = A_dagger_cluster_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_dagger_cluster_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_dagger_cluster_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_dagger_cluster_PSI.NCM_HO_IN;

  const int LCM_IN = A_dagger_cluster_PSI.LCM_IN;
  
  const double M_IN = A_dagger_cluster_PSI.M_IN;

  const class correlated_state_str &PSI_IN_qn = A_dagger_cluster_PSI.PSI_IN_qn;  
	
  A_dagger_cluster_helper::A_dagger_cluster_apply_add (full_common_vectors_used_in_file ,
						       is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , M_cluster_projectile , PSI_cluster_projectile_qn , 
						       is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , M_IN                 , PSI_IN_qn                 , PSI_out);

  PSI_out *= x;

  return PSI_out;
}




const class GSM_vector & GSM_vector::operator = (const class a_dagger_baryon_coupled_to_J_PSI_str &a_dagger_baryon_coupled_to_J_PSI)
{
  const bool full_common_vectors_used_in_file = a_dagger_baryon_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const class nlj_struct &shell_projectile = a_dagger_baryon_coupled_to_J_PSI.shell_projectile;
  
  const class correlated_state_str &PSI_IN_qn = a_dagger_baryon_coupled_to_J_PSI.PSI_IN_qn;

  const double J_OUT = a_dagger_baryon_coupled_to_J_PSI.J_OUT;
  
  class GSM_vector &PSI_out = *this;

  PSI_out = 0.0;
	
  a_dagger_baryon_helper::a_dagger_baryon_coupled_to_J_apply_add (full_common_vectors_used_in_file , shell_projectile , PSI_IN_qn , J_OUT , PSI_out);

  return PSI_out;
}




const class GSM_vector & GSM_vector::operator = (const class A_dagger_cluster_coupled_to_J_PSI_str &A_dagger_cluster_coupled_to_J_PSI)
{
  const bool full_common_vectors_used_in_file = A_dagger_cluster_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.LCM_cluster_projectile;
 
  const class correlated_state_str &PSI_cluster_projectile_qn = A_dagger_cluster_coupled_to_J_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_dagger_cluster_coupled_to_J_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_dagger_cluster_coupled_to_J_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_dagger_cluster_coupled_to_J_PSI.NCM_HO_IN;

  const int LCM_IN = A_dagger_cluster_coupled_to_J_PSI.LCM_IN;
 
  const class correlated_state_str &PSI_IN_qn = A_dagger_cluster_coupled_to_J_PSI.PSI_IN_qn;  

  const double J_OUT = A_dagger_cluster_coupled_to_J_PSI.J_OUT;
  
  class GSM_vector &PSI_out = *this;

  PSI_out = 0.0;

  A_dagger_cluster_helper::A_dagger_cluster_coupled_to_J_apply_add (full_common_vectors_used_in_file ,
								    is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , PSI_cluster_projectile_qn , 
								    is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , PSI_IN_qn                 , J_OUT , PSI_out);
  
  return PSI_out;
}





const class GSM_vector & GSM_vector::operator = (const class x_a_dagger_baryon_coupled_to_J_PSI_str &x_a_dagger_baryon_coupled_to_J_PSI)
{
  const class a_dagger_baryon_coupled_to_J_PSI_str &a_dagger_baryon_coupled_to_J_PSI = x_a_dagger_baryon_coupled_to_J_PSI.a_dagger_baryon_coupled_to_J_PSI;

  const TYPE &x = x_a_dagger_baryon_coupled_to_J_PSI.x;

  class GSM_vector &PSI_out = *this;

  PSI_out = 0.0;

  if (x == 0.0) return PSI_out;
  
  const bool full_common_vectors_used_in_file = a_dagger_baryon_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const class nlj_struct &shell_projectile = a_dagger_baryon_coupled_to_J_PSI.shell_projectile;

  const class correlated_state_str &PSI_IN_qn = a_dagger_baryon_coupled_to_J_PSI.PSI_IN_qn;

  const double J_OUT = a_dagger_baryon_coupled_to_J_PSI.J_OUT;
	
  a_dagger_baryon_helper::a_dagger_baryon_coupled_to_J_apply_add (full_common_vectors_used_in_file , shell_projectile , PSI_IN_qn , J_OUT , PSI_out);

  PSI_out *= x;

  return PSI_out;
}




const class GSM_vector & GSM_vector::operator = (const class x_A_dagger_cluster_coupled_to_J_PSI_str &x_A_dagger_cluster_coupled_to_J_PSI)
{
  const class A_dagger_cluster_coupled_to_J_PSI_str &A_dagger_cluster_coupled_to_J_PSI = x_A_dagger_cluster_coupled_to_J_PSI.A_dagger_cluster_coupled_to_J_PSI;

  const TYPE &x = x_A_dagger_cluster_coupled_to_J_PSI.x;	

  const bool full_common_vectors_used_in_file = A_dagger_cluster_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.LCM_cluster_projectile;
 
  const class correlated_state_str &PSI_cluster_projectile_qn = A_dagger_cluster_coupled_to_J_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_dagger_cluster_coupled_to_J_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_dagger_cluster_coupled_to_J_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_dagger_cluster_coupled_to_J_PSI.NCM_HO_IN;

  const int LCM_IN = A_dagger_cluster_coupled_to_J_PSI.LCM_IN;
 
  const class correlated_state_str &PSI_IN_qn = A_dagger_cluster_coupled_to_J_PSI.PSI_IN_qn;  

  const double J_OUT = A_dagger_cluster_coupled_to_J_PSI.J_OUT;

  class GSM_vector &PSI_out = *this;

  PSI_out = 0.0;
  
  A_dagger_cluster_helper::A_dagger_cluster_coupled_to_J_apply_add (full_common_vectors_used_in_file ,
								    is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , PSI_cluster_projectile_qn , 
								    is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , PSI_IN_qn                 , J_OUT , PSI_out);

  PSI_out *= x;

  return PSI_out;
}



const class GSM_vector & GSM_vector::operator = (const class a_baryon_PSI_str &a_baryon_PSI)
{
  const bool full_common_vectors_used_in_file = a_baryon_PSI.full_common_vectors_used_in_file;

  const class nljm_struct &phi_ejectile = a_baryon_PSI.phi_ejectile;
  
  const class correlated_state_str &PSI_IN_qn = a_baryon_PSI.PSI_IN_qn;

  const double M_IN = a_baryon_PSI.M_IN;

  class GSM_vector &PSI_out = *this;

  PSI_out = 0.0;
    
  a_dagger_baryon_helper::a_baryon_apply_add (full_common_vectors_used_in_file , phi_ejectile , PSI_IN_qn , M_IN , PSI_out);

  return PSI_out;
}




const class GSM_vector & GSM_vector::operator = (const class A_cluster_PSI_str &A_cluster_PSI)
{
  const bool full_common_vectors_used_in_file = A_cluster_PSI.full_common_vectors_used_in_file;
  
  const bool is_it_CM_relative_cluster_projectile = A_cluster_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_cluster_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_cluster_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_cluster_PSI.LCM_cluster_projectile;
  
  const double M_cluster_projectile = A_cluster_PSI.M_cluster_projectile;

  const class correlated_state_str &PSI_cluster_projectile_qn = A_cluster_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_cluster_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_cluster_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_cluster_PSI.NCM_HO_IN;

  const int LCM_IN = A_cluster_PSI.LCM_IN;
  
  const double M_IN = A_cluster_PSI.M_IN;

  const class correlated_state_str &PSI_IN_qn = A_cluster_PSI.PSI_IN_qn;  
	
  class GSM_vector &PSI_out = *this;

  PSI_out = 0.0;
  
  A_dagger_cluster_helper::A_cluster_apply_add (full_common_vectors_used_in_file ,
						is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , M_cluster_projectile , PSI_cluster_projectile_qn , 
						is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , M_IN                 , PSI_IN_qn                 , PSI_out);

  return PSI_out;
}





const class GSM_vector & GSM_vector::operator = (const class x_a_baryon_PSI_str &x_a_baryon_PSI)
{
  const class a_baryon_PSI_str &a_baryon_PSI = x_a_baryon_PSI.a_baryon_PSI;

  const TYPE &x = x_a_baryon_PSI.x;

  class GSM_vector &PSI_out = *this;

  PSI_out = 0.0;

  if (x == 0.0) return PSI_out;
  
  const bool full_common_vectors_used_in_file = a_baryon_PSI.full_common_vectors_used_in_file;

  const class nljm_struct &phi_ejectile = a_baryon_PSI.phi_ejectile;

  const class correlated_state_str &PSI_IN_qn = a_baryon_PSI.PSI_IN_qn;

  const double M_IN = a_baryon_PSI.M_IN;
	
  a_dagger_baryon_helper::a_baryon_apply_add (full_common_vectors_used_in_file , phi_ejectile , PSI_IN_qn , M_IN , PSI_out);

  PSI_out *= x;

  return PSI_out;
}




const class GSM_vector & GSM_vector::operator = (const class x_A_cluster_PSI_str &x_A_cluster_PSI)
{
  const class A_cluster_PSI_str &A_cluster_PSI = x_A_cluster_PSI.A_cluster_PSI;

  const TYPE &x = x_A_cluster_PSI.x;	

  class GSM_vector &PSI_out = *this;

  PSI_out = 0.0;

  if (x == 0.0) return PSI_out;
  
  const bool full_common_vectors_used_in_file = A_cluster_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_cluster_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_cluster_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_cluster_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_cluster_PSI.LCM_cluster_projectile;
  
  const double M_cluster_projectile = A_cluster_PSI.M_cluster_projectile;

  const class correlated_state_str &PSI_cluster_projectile_qn = A_cluster_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_cluster_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_cluster_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_cluster_PSI.NCM_HO_IN;

  const int LCM_IN = A_cluster_PSI.LCM_IN;
  
  const double M_IN = A_cluster_PSI.M_IN;

  const class correlated_state_str &PSI_IN_qn = A_cluster_PSI.PSI_IN_qn;  
	
  A_dagger_cluster_helper::A_cluster_apply_add (full_common_vectors_used_in_file ,
						is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , M_cluster_projectile , PSI_cluster_projectile_qn , 
						is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , M_IN                 , PSI_IN_qn                 , PSI_out);
	
  PSI_out *= x;

  return PSI_out;
}






const class GSM_vector & GSM_vector::operator = (const class a_baryon_coupled_to_J_PSI_str &a_baryon_coupled_to_J_PSI)
{
  const bool full_common_vectors_used_in_file = a_baryon_coupled_to_J_PSI.full_common_vectors_used_in_file;
  
  const class nlj_struct &shell_ejectile = a_baryon_coupled_to_J_PSI.shell_ejectile;
  
  const class correlated_state_str &PSI_IN_qn = a_baryon_coupled_to_J_PSI.PSI_IN_qn;
  
  const double J_OUT = a_baryon_coupled_to_J_PSI.J_OUT;

  class GSM_vector &PSI_out = *this;

  PSI_out = 0.0;
	
  a_dagger_baryon_helper::a_baryon_coupled_to_J_apply_add (full_common_vectors_used_in_file , shell_ejectile , PSI_IN_qn , J_OUT , PSI_out);

  return PSI_out;
}




const class GSM_vector & GSM_vector::operator = (const class A_cluster_coupled_to_J_PSI_str &A_cluster_coupled_to_J_PSI)
{
  const bool full_common_vectors_used_in_file = A_cluster_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_cluster_coupled_to_J_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_cluster_coupled_to_J_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_cluster_coupled_to_J_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_cluster_coupled_to_J_PSI.LCM_cluster_projectile;
 
  const class correlated_state_str &PSI_cluster_projectile_qn = A_cluster_coupled_to_J_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_cluster_coupled_to_J_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_cluster_coupled_to_J_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_cluster_coupled_to_J_PSI.NCM_HO_IN;

  const int LCM_IN = A_cluster_coupled_to_J_PSI.LCM_IN;
 
  const class correlated_state_str &PSI_IN_qn = A_cluster_coupled_to_J_PSI.PSI_IN_qn;  

  const double J_OUT = A_cluster_coupled_to_J_PSI.J_OUT;
  
  class GSM_vector &PSI_out = *this;

  PSI_out = 0.0;

  A_dagger_cluster_helper::A_cluster_coupled_to_J_apply_add (full_common_vectors_used_in_file ,
							     is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , PSI_cluster_projectile_qn , 
							     is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , PSI_IN_qn                 , J_OUT , PSI_out);

  return PSI_out;
}





const class GSM_vector & GSM_vector::operator = (const class x_a_baryon_coupled_to_J_PSI_str &x_a_baryon_coupled_to_J_PSI)
{
  const class a_baryon_coupled_to_J_PSI_str &a_baryon_coupled_to_J_PSI = x_a_baryon_coupled_to_J_PSI.a_baryon_coupled_to_J_PSI;
  const TYPE &x = x_a_baryon_coupled_to_J_PSI.x;

  class GSM_vector &PSI_out = *this;

  PSI_out = 0.0;

  if (x == 0.0) return PSI_out;
  
  const bool full_common_vectors_used_in_file = a_baryon_coupled_to_J_PSI.full_common_vectors_used_in_file;
  
  const class nlj_struct &shell_ejectile = a_baryon_coupled_to_J_PSI.shell_ejectile;
    
  const class correlated_state_str &PSI_IN_qn = a_baryon_coupled_to_J_PSI.PSI_IN_qn;
	
  const double J_OUT = a_baryon_coupled_to_J_PSI.J_OUT;
  
  a_dagger_baryon_helper::a_baryon_coupled_to_J_apply_add (full_common_vectors_used_in_file , shell_ejectile , PSI_IN_qn , J_OUT , PSI_out);

  PSI_out *= x;

  return PSI_out;
}




const class GSM_vector & GSM_vector::operator = (const class x_A_cluster_coupled_to_J_PSI_str &x_A_cluster_coupled_to_J_PSI)
{
  const class A_cluster_coupled_to_J_PSI_str &A_cluster_coupled_to_J_PSI = x_A_cluster_coupled_to_J_PSI.A_cluster_coupled_to_J_PSI;

  const TYPE &x = x_A_cluster_coupled_to_J_PSI.x;	
  
  const bool full_common_vectors_used_in_file = A_cluster_coupled_to_J_PSI.full_common_vectors_used_in_file;
  
  const bool is_it_CM_relative_cluster_projectile = A_cluster_coupled_to_J_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_cluster_coupled_to_J_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_cluster_coupled_to_J_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_cluster_coupled_to_J_PSI.LCM_cluster_projectile;
 
  const class correlated_state_str &PSI_cluster_projectile_qn = A_cluster_coupled_to_J_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_cluster_coupled_to_J_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_cluster_coupled_to_J_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_cluster_coupled_to_J_PSI.NCM_HO_IN;

  const int LCM_IN = A_cluster_coupled_to_J_PSI.LCM_IN;
 
  const class correlated_state_str &PSI_IN_qn = A_cluster_coupled_to_J_PSI.PSI_IN_qn;  

  const double J_OUT = A_cluster_coupled_to_J_PSI.J_OUT;
  
  class GSM_vector &PSI_out = *this;

  PSI_out = 0.0;
  
  A_dagger_cluster_helper::A_cluster_coupled_to_J_apply_add (full_common_vectors_used_in_file ,
							     is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , PSI_cluster_projectile_qn , 
							     is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , PSI_IN_qn                 , J_OUT , PSI_out);

  PSI_out *= x;

  return PSI_out;
}





class GSM_vector & GSM_vector::operator += (const class Op_PSI_closure_str &Op_PSI_closure)
{
  class GSM_vector &PSI_out = *this;

  if (Op_PSI_closure.is_PSI_out_used (PSI_out))
    {
      class GSM_vector PSI_out_copy = PSI_out;

      Op_PSI_closure.all_Op_PSI_in_calc_add (PSI_out_copy);

      PSI_out = PSI_out_copy;
    }
  else
    {
      Op_PSI_closure.all_Op_PSI_in_calc_add (PSI_out);
    }

  return PSI_out;
}






class GSM_vector & GSM_vector::operator += (const class a_dagger_baryon_PSI_str &a_dagger_baryon_PSI)
{
  const bool full_common_vectors_used_in_file = a_dagger_baryon_PSI.full_common_vectors_used_in_file;

  const class nljm_struct &phi_projectile = a_dagger_baryon_PSI.phi_projectile;
  
  const class correlated_state_str &PSI_IN_qn = a_dagger_baryon_PSI.PSI_IN_qn;

  const double M_IN = a_dagger_baryon_PSI.M_IN;

  class GSM_vector &PSI_out = *this;

  a_dagger_baryon_helper::a_dagger_baryon_apply_add (full_common_vectors_used_in_file , phi_projectile , PSI_IN_qn , M_IN , PSI_out);

  return PSI_out;
}







class GSM_vector & GSM_vector::operator += (const class A_dagger_cluster_PSI_str &A_dagger_cluster_PSI)
{
  const bool full_common_vectors_used_in_file = A_dagger_cluster_PSI.full_common_vectors_used_in_file;
  
  const bool is_it_CM_relative_cluster_projectile = A_dagger_cluster_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_dagger_cluster_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_dagger_cluster_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_dagger_cluster_PSI.LCM_cluster_projectile;
  
  const double M_cluster_projectile = A_dagger_cluster_PSI.M_cluster_projectile;

  const class correlated_state_str &PSI_cluster_projectile_qn = A_dagger_cluster_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_dagger_cluster_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_dagger_cluster_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_dagger_cluster_PSI.NCM_HO_IN;

  const int LCM_IN = A_dagger_cluster_PSI.LCM_IN;
  
  const double M_IN = A_dagger_cluster_PSI.M_IN;

  const class correlated_state_str &PSI_IN_qn = A_dagger_cluster_PSI.PSI_IN_qn;  
	
  class GSM_vector &PSI_out = *this;

  A_dagger_cluster_helper::A_dagger_cluster_apply_add (full_common_vectors_used_in_file ,
						       is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , M_cluster_projectile , PSI_cluster_projectile_qn , 
						       is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , M_IN                 , PSI_IN_qn                 , PSI_out);

  return PSI_out;
}






class GSM_vector & GSM_vector::operator += (const class x_a_dagger_baryon_PSI_str &x_a_dagger_baryon_PSI)
{
  const class a_dagger_baryon_PSI_str &a_dagger_baryon_PSI = x_a_dagger_baryon_PSI.a_dagger_baryon_PSI;

  const TYPE &x = x_a_dagger_baryon_PSI.x;

  class GSM_vector &PSI_out = *this;
  
  if (x == 0.0) return PSI_out;
  
  const bool full_common_vectors_used_in_file = a_dagger_baryon_PSI.full_common_vectors_used_in_file;

  const class nljm_struct &phi_projectile = a_dagger_baryon_PSI.phi_projectile;
  
  const class correlated_state_str &PSI_IN_qn = a_dagger_baryon_PSI.PSI_IN_qn;

  const double M_IN = a_dagger_baryon_PSI.M_IN;

  PSI_out /= x;
	
  a_dagger_baryon_helper::a_dagger_baryon_apply_add (full_common_vectors_used_in_file , phi_projectile , PSI_IN_qn , M_IN , PSI_out);

  PSI_out *= x;

  return PSI_out;
}




class GSM_vector & GSM_vector::operator += (const class x_A_dagger_cluster_PSI_str &x_A_dagger_cluster_PSI)
{
  const class A_dagger_cluster_PSI_str &A_dagger_cluster_PSI = x_A_dagger_cluster_PSI.A_dagger_cluster_PSI;

  const TYPE &x = x_A_dagger_cluster_PSI.x;

  class GSM_vector &PSI_out = *this;
  
  if (x == 0.0) return PSI_out;
  
  const bool full_common_vectors_used_in_file = A_dagger_cluster_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_dagger_cluster_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_dagger_cluster_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_dagger_cluster_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_dagger_cluster_PSI.LCM_cluster_projectile;
  
  const double M_cluster_projectile = A_dagger_cluster_PSI.M_cluster_projectile;

  const class correlated_state_str &PSI_cluster_projectile_qn = A_dagger_cluster_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_dagger_cluster_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_dagger_cluster_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_dagger_cluster_PSI.NCM_HO_IN;

  const int LCM_IN = A_dagger_cluster_PSI.LCM_IN;
  
  const double M_IN = A_dagger_cluster_PSI.M_IN;

  const class correlated_state_str &PSI_IN_qn = A_dagger_cluster_PSI.PSI_IN_qn;  
  
  PSI_out /= x;
	
  A_dagger_cluster_helper::A_dagger_cluster_apply_add (full_common_vectors_used_in_file ,
						       is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , M_cluster_projectile , PSI_cluster_projectile_qn , 
						       is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , M_IN                 , PSI_IN_qn                 , PSI_out);

  PSI_out *= x;

  return PSI_out;
}




class GSM_vector & GSM_vector::operator += (const class a_dagger_baryon_coupled_to_J_PSI_str &a_dagger_baryon_coupled_to_J_PSI)
{
  const bool full_common_vectors_used_in_file = a_dagger_baryon_coupled_to_J_PSI.full_common_vectors_used_in_file;
  
  const class nlj_struct &shell_projectile = a_dagger_baryon_coupled_to_J_PSI.shell_projectile;
    
  const class correlated_state_str &PSI_IN_qn = a_dagger_baryon_coupled_to_J_PSI.PSI_IN_qn;

  const double J_OUT = a_dagger_baryon_coupled_to_J_PSI.J_OUT;
  
  class GSM_vector &PSI_out = *this;

  a_dagger_baryon_helper::a_dagger_baryon_coupled_to_J_apply_add (full_common_vectors_used_in_file , shell_projectile , PSI_IN_qn , J_OUT , PSI_out);

  return PSI_out;
}




class GSM_vector & GSM_vector::operator += (const class A_dagger_cluster_coupled_to_J_PSI_str &A_dagger_cluster_coupled_to_J_PSI)
{
  const bool full_common_vectors_used_in_file = A_dagger_cluster_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.LCM_cluster_projectile;
 
  const class correlated_state_str &PSI_cluster_projectile_qn = A_dagger_cluster_coupled_to_J_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_dagger_cluster_coupled_to_J_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_dagger_cluster_coupled_to_J_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_dagger_cluster_coupled_to_J_PSI.NCM_HO_IN;

  const int LCM_IN = A_dagger_cluster_coupled_to_J_PSI.LCM_IN;
 
  const class correlated_state_str &PSI_IN_qn = A_dagger_cluster_coupled_to_J_PSI.PSI_IN_qn;  

  const double J_OUT = A_dagger_cluster_coupled_to_J_PSI.J_OUT;
  
  class GSM_vector &PSI_out = *this;

  A_dagger_cluster_helper::A_dagger_cluster_coupled_to_J_apply_add (full_common_vectors_used_in_file ,
								    is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , PSI_cluster_projectile_qn , 
								    is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , PSI_IN_qn                 , J_OUT , PSI_out);

  return PSI_out;
}


class GSM_vector & GSM_vector::operator += (const class x_a_dagger_baryon_coupled_to_J_PSI_str &x_a_dagger_baryon_coupled_to_J_PSI)
{
  const class a_dagger_baryon_coupled_to_J_PSI_str &a_dagger_baryon_coupled_to_J_PSI = x_a_dagger_baryon_coupled_to_J_PSI.a_dagger_baryon_coupled_to_J_PSI;

  const TYPE &x = x_a_dagger_baryon_coupled_to_J_PSI.x;

  class GSM_vector &PSI_out = *this;
    
  if (x == 0.0) return PSI_out;
  
  const bool full_common_vectors_used_in_file = a_dagger_baryon_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const class nlj_struct &shell_projectile = a_dagger_baryon_coupled_to_J_PSI.shell_projectile;
    
  const class correlated_state_str &PSI_IN_qn = a_dagger_baryon_coupled_to_J_PSI.PSI_IN_qn;

  const double J_OUT = a_dagger_baryon_coupled_to_J_PSI.J_OUT;
  
  PSI_out /= x;
	
  a_dagger_baryon_helper::a_dagger_baryon_coupled_to_J_apply_add (full_common_vectors_used_in_file , shell_projectile , PSI_IN_qn , J_OUT , PSI_out);

  PSI_out *= x;

  return PSI_out;
}




class GSM_vector & GSM_vector::operator += (const class x_A_dagger_cluster_coupled_to_J_PSI_str &x_A_dagger_cluster_coupled_to_J_PSI)
{
  const class A_dagger_cluster_coupled_to_J_PSI_str &A_dagger_cluster_coupled_to_J_PSI = x_A_dagger_cluster_coupled_to_J_PSI.A_dagger_cluster_coupled_to_J_PSI;

  const TYPE &x = x_A_dagger_cluster_coupled_to_J_PSI.x;

  class GSM_vector &PSI_out = *this;
    
  if (x == 0.0) return PSI_out;

  const bool full_common_vectors_used_in_file = A_dagger_cluster_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.LCM_cluster_projectile;
 
  const class correlated_state_str &PSI_cluster_projectile_qn = A_dagger_cluster_coupled_to_J_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_dagger_cluster_coupled_to_J_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_dagger_cluster_coupled_to_J_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_dagger_cluster_coupled_to_J_PSI.NCM_HO_IN;

  const int LCM_IN = A_dagger_cluster_coupled_to_J_PSI.LCM_IN;
 
  const class correlated_state_str &PSI_IN_qn = A_dagger_cluster_coupled_to_J_PSI.PSI_IN_qn;  

  const double J_OUT = A_dagger_cluster_coupled_to_J_PSI.J_OUT;
  
  PSI_out /= x;
	
  A_dagger_cluster_helper::A_dagger_cluster_coupled_to_J_apply_add (full_common_vectors_used_in_file ,
								    is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , PSI_cluster_projectile_qn , 
								    is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , PSI_IN_qn                 , J_OUT , PSI_out);

  PSI_out *= x;

  return PSI_out;
}





class GSM_vector & GSM_vector::operator += (const class a_baryon_PSI_str &a_baryon_PSI)
{
  const bool full_common_vectors_used_in_file = a_baryon_PSI.full_common_vectors_used_in_file;

  const class nljm_struct &phi_ejectile = a_baryon_PSI.phi_ejectile;
  
  const class correlated_state_str &PSI_IN_qn = a_baryon_PSI.PSI_IN_qn;

  const double M_IN = a_baryon_PSI.M_IN;

  class GSM_vector &PSI_out = *this;

  a_dagger_baryon_helper::a_baryon_apply_add (full_common_vectors_used_in_file , phi_ejectile , PSI_IN_qn , M_IN , PSI_out);

  return PSI_out;
}







class GSM_vector & GSM_vector::operator += (const class A_cluster_PSI_str &A_cluster_PSI)
{
  const bool full_common_vectors_used_in_file = A_cluster_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_cluster_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_cluster_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_cluster_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_cluster_PSI.LCM_cluster_projectile;
  
  const double M_cluster_projectile = A_cluster_PSI.M_cluster_projectile;

  const class correlated_state_str &PSI_cluster_projectile_qn = A_cluster_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_cluster_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_cluster_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_cluster_PSI.NCM_HO_IN;

  const int LCM_IN = A_cluster_PSI.LCM_IN;
  
  const double M_IN = A_cluster_PSI.M_IN;

  const class correlated_state_str &PSI_IN_qn = A_cluster_PSI.PSI_IN_qn;
  
  class GSM_vector &PSI_out = *this;

  A_dagger_cluster_helper::A_cluster_apply_add (full_common_vectors_used_in_file ,
						is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , M_cluster_projectile , PSI_cluster_projectile_qn , 
						is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , M_IN                 , PSI_IN_qn                 , PSI_out);

  return PSI_out;
}






class GSM_vector & GSM_vector::operator += (const class x_a_baryon_PSI_str &x_a_baryon_PSI)
{
  const class a_baryon_PSI_str &a_baryon_PSI = x_a_baryon_PSI.a_baryon_PSI;

  const TYPE &x = x_a_baryon_PSI.x;

  class GSM_vector &PSI_out = *this;
  
  if (x == 0.0) return PSI_out;
  
  const bool full_common_vectors_used_in_file = a_baryon_PSI.full_common_vectors_used_in_file;

  const class nljm_struct &phi_ejectile = a_baryon_PSI.phi_ejectile;
  
  const class correlated_state_str &PSI_IN_qn = a_baryon_PSI.PSI_IN_qn;

  const double M_IN = a_baryon_PSI.M_IN;

  PSI_out /= x;
	
  a_dagger_baryon_helper::a_baryon_apply_add (full_common_vectors_used_in_file , phi_ejectile , PSI_IN_qn , M_IN , PSI_out);

  PSI_out *= x;

  return PSI_out;
}




class GSM_vector & GSM_vector::operator += (const class x_A_cluster_PSI_str &x_A_cluster_PSI)
{
  const class A_cluster_PSI_str &A_cluster_PSI = x_A_cluster_PSI.A_cluster_PSI;

  const TYPE &x = x_A_cluster_PSI.x;

  class GSM_vector &PSI_out = *this;
  
  if (x == 0.0) return PSI_out;
  
  const bool full_common_vectors_used_in_file = A_cluster_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_cluster_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_cluster_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_cluster_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_cluster_PSI.LCM_cluster_projectile;
  
  const double M_cluster_projectile = A_cluster_PSI.M_cluster_projectile;

  const class correlated_state_str &PSI_cluster_projectile_qn = A_cluster_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_cluster_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_cluster_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_cluster_PSI.NCM_HO_IN;

  const int LCM_IN = A_cluster_PSI.LCM_IN;
  
  const double M_IN = A_cluster_PSI.M_IN;

  const class correlated_state_str &PSI_IN_qn = A_cluster_PSI.PSI_IN_qn;  
  
  PSI_out /= x;
	
  A_dagger_cluster_helper::A_cluster_apply_add (full_common_vectors_used_in_file ,
						is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , M_cluster_projectile , PSI_cluster_projectile_qn , 
						is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , M_IN                 , PSI_IN_qn                 , PSI_out);

  PSI_out *= x;

  return PSI_out;
}




class GSM_vector & GSM_vector::operator += (const class a_baryon_coupled_to_J_PSI_str &a_baryon_coupled_to_J_PSI)
{
  const bool full_common_vectors_used_in_file = a_baryon_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const class nlj_struct &shell_ejectile = a_baryon_coupled_to_J_PSI.shell_ejectile;
    
  const class correlated_state_str &PSI_IN_qn = a_baryon_coupled_to_J_PSI.PSI_IN_qn;

  const double J_OUT = a_baryon_coupled_to_J_PSI.J_OUT;
  
  class GSM_vector &PSI_out = *this;

  a_dagger_baryon_helper::a_baryon_coupled_to_J_apply_add (full_common_vectors_used_in_file , shell_ejectile , PSI_IN_qn , J_OUT , PSI_out);

  return PSI_out;
}




class GSM_vector & GSM_vector::operator += (const class A_cluster_coupled_to_J_PSI_str &A_cluster_coupled_to_J_PSI)
{
  const bool full_common_vectors_used_in_file = A_cluster_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_cluster_coupled_to_J_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_cluster_coupled_to_J_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_cluster_coupled_to_J_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_cluster_coupled_to_J_PSI.LCM_cluster_projectile;
 
  const class correlated_state_str &PSI_cluster_projectile_qn = A_cluster_coupled_to_J_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_cluster_coupled_to_J_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_cluster_coupled_to_J_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_cluster_coupled_to_J_PSI.NCM_HO_IN;

  const int LCM_IN = A_cluster_coupled_to_J_PSI.LCM_IN;
 
  const class correlated_state_str &PSI_IN_qn = A_cluster_coupled_to_J_PSI.PSI_IN_qn;  

  const double J_OUT = A_cluster_coupled_to_J_PSI.J_OUT;
  
  class GSM_vector &PSI_out = *this;

  A_dagger_cluster_helper::A_cluster_coupled_to_J_apply_add (full_common_vectors_used_in_file ,
							     is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , PSI_cluster_projectile_qn , 
							     is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , PSI_IN_qn                 , J_OUT , PSI_out);

  return PSI_out;
}


class GSM_vector & GSM_vector::operator += (const class x_a_baryon_coupled_to_J_PSI_str &x_a_baryon_coupled_to_J_PSI)
{
  const class a_baryon_coupled_to_J_PSI_str &a_baryon_coupled_to_J_PSI = x_a_baryon_coupled_to_J_PSI.a_baryon_coupled_to_J_PSI;

  const TYPE &x = x_a_baryon_coupled_to_J_PSI.x;

  class GSM_vector &PSI_out = *this;
    
  if (x == 0.0) return PSI_out;
  
  const bool full_common_vectors_used_in_file = a_baryon_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const class nlj_struct &shell_ejectile = a_baryon_coupled_to_J_PSI.shell_ejectile;
    
  const class correlated_state_str &PSI_IN_qn = a_baryon_coupled_to_J_PSI.PSI_IN_qn;

  const double J_OUT = a_baryon_coupled_to_J_PSI.J_OUT;
  
  PSI_out /= x;
	
  a_dagger_baryon_helper::a_baryon_coupled_to_J_apply_add (full_common_vectors_used_in_file , shell_ejectile , PSI_IN_qn , J_OUT , PSI_out);

  PSI_out *= x;

  return PSI_out;
}




class GSM_vector & GSM_vector::operator += (const class x_A_cluster_coupled_to_J_PSI_str &x_A_cluster_coupled_to_J_PSI)
{
  const class A_cluster_coupled_to_J_PSI_str &A_cluster_coupled_to_J_PSI = x_A_cluster_coupled_to_J_PSI.A_cluster_coupled_to_J_PSI;

  const TYPE &x = x_A_cluster_coupled_to_J_PSI.x;

  class GSM_vector &PSI_out = *this;
    
  if (x == 0.0) return PSI_out;

  const bool full_common_vectors_used_in_file = A_cluster_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_cluster_coupled_to_J_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_cluster_coupled_to_J_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_cluster_coupled_to_J_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_cluster_coupled_to_J_PSI.LCM_cluster_projectile;
 
  const class correlated_state_str &PSI_cluster_projectile_qn = A_cluster_coupled_to_J_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_cluster_coupled_to_J_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_cluster_coupled_to_J_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_cluster_coupled_to_J_PSI.NCM_HO_IN;

  const int LCM_IN = A_cluster_coupled_to_J_PSI.LCM_IN;
 
  const class correlated_state_str &PSI_IN_qn = A_cluster_coupled_to_J_PSI.PSI_IN_qn;  

  const double J_OUT = A_cluster_coupled_to_J_PSI.J_OUT;
  
  PSI_out /= x;
	
  A_dagger_cluster_helper::A_cluster_coupled_to_J_apply_add (full_common_vectors_used_in_file ,
							     is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , PSI_cluster_projectile_qn , 
							     is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , PSI_IN_qn                 , J_OUT , PSI_out);

  PSI_out *= x;

  return PSI_out;
}






class GSM_vector & GSM_vector::operator -= (const class Op_PSI_closure_str &Op_PSI_closure)
{
  class GSM_vector &PSI_out = *this;

  if (Op_PSI_closure.is_PSI_out_used (PSI_out))
    {
      class GSM_vector PSI_out_copy = PSI_out;

      PSI_out_copy.opposite ();

      Op_PSI_closure.all_Op_PSI_in_calc_add (PSI_out_copy);

      PSI_out_copy.opposite ();

      PSI_out = PSI_out_copy;
    }
  else
    {
      PSI_out.opposite ();

      Op_PSI_closure.all_Op_PSI_in_calc_add (PSI_out);

      PSI_out.opposite ();
    }

  return PSI_out;
}





class GSM_vector & GSM_vector::operator -= (const class a_dagger_baryon_PSI_str &a_dagger_baryon_PSI)
{
  const bool full_common_vectors_used_in_file = a_dagger_baryon_PSI.full_common_vectors_used_in_file;

  const class nljm_struct &phi_projectile = a_dagger_baryon_PSI.phi_projectile;
  
  const class correlated_state_str &PSI_IN_qn = a_dagger_baryon_PSI.PSI_IN_qn;

  const double M_IN = a_dagger_baryon_PSI.M_IN;
  
  class GSM_vector &PSI_out = *this;

  PSI_out.opposite ();

  a_dagger_baryon_helper::a_dagger_baryon_apply_add (full_common_vectors_used_in_file , phi_projectile , PSI_IN_qn , M_IN , PSI_out);

  PSI_out.opposite ();

  return PSI_out;
}





class GSM_vector & GSM_vector::operator -= (const class A_dagger_cluster_PSI_str &A_dagger_cluster_PSI)
{
  const bool full_common_vectors_used_in_file = A_dagger_cluster_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_dagger_cluster_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_dagger_cluster_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_dagger_cluster_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_dagger_cluster_PSI.LCM_cluster_projectile;
  
  const double M_cluster_projectile = A_dagger_cluster_PSI.M_cluster_projectile;

  const class correlated_state_str &PSI_cluster_projectile_qn = A_dagger_cluster_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_dagger_cluster_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_dagger_cluster_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_dagger_cluster_PSI.NCM_HO_IN;

  const int LCM_IN = A_dagger_cluster_PSI.LCM_IN;
  
  const double M_IN = A_dagger_cluster_PSI.M_IN;

  const class correlated_state_str &PSI_IN_qn = A_dagger_cluster_PSI.PSI_IN_qn;  
	
  class GSM_vector &PSI_out = *this;
    
  PSI_out.opposite ();

  A_dagger_cluster_helper::A_dagger_cluster_apply_add (full_common_vectors_used_in_file ,
						       is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , M_cluster_projectile , PSI_cluster_projectile_qn , 
						       is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , M_IN                 , PSI_IN_qn                 , PSI_out);

  PSI_out.opposite ();

  return PSI_out;
}






class GSM_vector & GSM_vector::operator -= (const class x_a_dagger_baryon_PSI_str &x_a_dagger_baryon_PSI)
{
  const class a_dagger_baryon_PSI_str &a_dagger_baryon_PSI = x_a_dagger_baryon_PSI.a_dagger_baryon_PSI;

  const TYPE &x = x_a_dagger_baryon_PSI.x;

  class GSM_vector &PSI_out = *this;
  
  if (x == 0.0) return PSI_out;
  
  const TYPE minus_x = -x;
  
  const bool full_common_vectors_used_in_file = a_dagger_baryon_PSI.full_common_vectors_used_in_file;

  const class nljm_struct &phi_projectile = a_dagger_baryon_PSI.phi_projectile;
  
  const class correlated_state_str &PSI_IN_qn = a_dagger_baryon_PSI.PSI_IN_qn;

  const double M_IN = a_dagger_baryon_PSI.M_IN;

  PSI_out /= minus_x;
	
  a_dagger_baryon_helper::a_dagger_baryon_apply_add (full_common_vectors_used_in_file , phi_projectile , PSI_IN_qn , M_IN , PSI_out);

  PSI_out *= minus_x;

  return PSI_out;
}







class GSM_vector & GSM_vector::operator -= (const class x_A_dagger_cluster_PSI_str &x_A_dagger_cluster_PSI)
{
  const class A_dagger_cluster_PSI_str &A_dagger_cluster_PSI = x_A_dagger_cluster_PSI.A_dagger_cluster_PSI;

  const TYPE &x = x_A_dagger_cluster_PSI.x;

  class GSM_vector &PSI_out = *this;
  
  if (x == 0.0) return PSI_out;
  
  const TYPE minus_x = -x;
  
  const bool full_common_vectors_used_in_file = A_dagger_cluster_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_dagger_cluster_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_dagger_cluster_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_dagger_cluster_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_dagger_cluster_PSI.LCM_cluster_projectile;
  
  const double M_cluster_projectile = A_dagger_cluster_PSI.M_cluster_projectile;

  const class correlated_state_str &PSI_cluster_projectile_qn = A_dagger_cluster_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_dagger_cluster_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_dagger_cluster_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_dagger_cluster_PSI.NCM_HO_IN;

  const int LCM_IN = A_dagger_cluster_PSI.LCM_IN;
  
  const double M_IN = A_dagger_cluster_PSI.M_IN;

  const class correlated_state_str &PSI_IN_qn = A_dagger_cluster_PSI.PSI_IN_qn;  
  
  PSI_out /= minus_x;
	
  A_dagger_cluster_helper::A_dagger_cluster_apply_add (full_common_vectors_used_in_file ,
						       is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , M_cluster_projectile , PSI_cluster_projectile_qn , 
						       is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , M_IN                 , PSI_IN_qn                 , PSI_out);

  PSI_out *= minus_x;

  return PSI_out;
}







class GSM_vector & GSM_vector::operator -= (const class a_dagger_baryon_coupled_to_J_PSI_str &a_dagger_baryon_coupled_to_J_PSI)
{
  const bool full_common_vectors_used_in_file = a_dagger_baryon_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const class nlj_struct &shell_projectile = a_dagger_baryon_coupled_to_J_PSI.shell_projectile;
  
  const class correlated_state_str &PSI_IN_qn = a_dagger_baryon_coupled_to_J_PSI.PSI_IN_qn;

  const double J_OUT = a_dagger_baryon_coupled_to_J_PSI.J_OUT;
  
  class GSM_vector &PSI_out = *this;

  PSI_out.opposite ();

  a_dagger_baryon_helper::a_dagger_baryon_coupled_to_J_apply_add (full_common_vectors_used_in_file , shell_projectile , PSI_IN_qn , J_OUT , PSI_out);

  PSI_out.opposite ();

  return PSI_out;
}








class GSM_vector & GSM_vector::operator -= (const class A_dagger_cluster_coupled_to_J_PSI_str &A_dagger_cluster_coupled_to_J_PSI)
{
  const bool full_common_vectors_used_in_file = A_dagger_cluster_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.LCM_cluster_projectile;
 
  const class correlated_state_str &PSI_cluster_projectile_qn = A_dagger_cluster_coupled_to_J_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_dagger_cluster_coupled_to_J_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_dagger_cluster_coupled_to_J_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_dagger_cluster_coupled_to_J_PSI.NCM_HO_IN;

  const int LCM_IN = A_dagger_cluster_coupled_to_J_PSI.LCM_IN;
 
  const class correlated_state_str &PSI_IN_qn = A_dagger_cluster_coupled_to_J_PSI.PSI_IN_qn;  

  const double J_OUT = A_dagger_cluster_coupled_to_J_PSI.J_OUT;
  
  class GSM_vector &PSI_out = *this;

  PSI_out.opposite ();

  A_dagger_cluster_helper::A_dagger_cluster_coupled_to_J_apply_add (full_common_vectors_used_in_file ,
								    is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , PSI_cluster_projectile_qn , 
								    is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , PSI_IN_qn                 , J_OUT , PSI_out);

  PSI_out.opposite ();

  return PSI_out;
}






class GSM_vector & GSM_vector::operator -= (const class x_a_dagger_baryon_coupled_to_J_PSI_str &x_a_dagger_baryon_coupled_to_J_PSI)
{
  const class a_dagger_baryon_coupled_to_J_PSI_str &a_dagger_baryon_coupled_to_J_PSI = x_a_dagger_baryon_coupled_to_J_PSI.a_dagger_baryon_coupled_to_J_PSI;
  
  const TYPE &x = x_a_dagger_baryon_coupled_to_J_PSI.x;

  class GSM_vector &PSI_out = *this;
  
  if (x == 0.0) return PSI_out;
  
  const TYPE minus_x = -x;
  
  const bool full_common_vectors_used_in_file = a_dagger_baryon_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const class nlj_struct &shell_projectile = a_dagger_baryon_coupled_to_J_PSI.shell_projectile;

  const class correlated_state_str &PSI_IN_qn = a_dagger_baryon_coupled_to_J_PSI.PSI_IN_qn;
 
  const double J_OUT = a_dagger_baryon_coupled_to_J_PSI.J_OUT;
  
  PSI_out /= minus_x;
	
  a_dagger_baryon_helper::a_dagger_baryon_coupled_to_J_apply_add (full_common_vectors_used_in_file , shell_projectile , PSI_IN_qn , J_OUT , PSI_out);

  PSI_out *= minus_x;

  return PSI_out;
}







class GSM_vector & GSM_vector::operator -= (const class x_A_dagger_cluster_coupled_to_J_PSI_str &x_A_dagger_cluster_coupled_to_J_PSI)
{
  const class A_dagger_cluster_coupled_to_J_PSI_str &A_dagger_cluster_coupled_to_J_PSI = x_A_dagger_cluster_coupled_to_J_PSI.A_dagger_cluster_coupled_to_J_PSI;

  const TYPE &x = x_A_dagger_cluster_coupled_to_J_PSI.x;

  class GSM_vector &PSI_out = *this;
  
  if (x == 0.0) return PSI_out;
  
  const TYPE minus_x = -x;

  const bool full_common_vectors_used_in_file = A_dagger_cluster_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_dagger_cluster_coupled_to_J_PSI.LCM_cluster_projectile;
 
  const class correlated_state_str &PSI_cluster_projectile_qn = A_dagger_cluster_coupled_to_J_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_dagger_cluster_coupled_to_J_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_dagger_cluster_coupled_to_J_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_dagger_cluster_coupled_to_J_PSI.NCM_HO_IN;

  const int LCM_IN = A_dagger_cluster_coupled_to_J_PSI.LCM_IN;
 
  const class correlated_state_str &PSI_IN_qn = A_dagger_cluster_coupled_to_J_PSI.PSI_IN_qn;  

  const double J_OUT = A_dagger_cluster_coupled_to_J_PSI.J_OUT;
  
  PSI_out /= minus_x;
	
  A_dagger_cluster_helper::A_dagger_cluster_coupled_to_J_apply_add (full_common_vectors_used_in_file ,
								    is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , PSI_cluster_projectile_qn , 
								    is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , PSI_IN_qn                 , J_OUT , PSI_out);

  PSI_out *= minus_x;

  return PSI_out;
}







class GSM_vector & GSM_vector::operator -= (const class a_baryon_PSI_str &a_baryon_PSI)
{
  const bool full_common_vectors_used_in_file = a_baryon_PSI.full_common_vectors_used_in_file;

  const class nljm_struct &phi_ejectile = a_baryon_PSI.phi_ejectile;
  
  const class correlated_state_str &PSI_IN_qn = a_baryon_PSI.PSI_IN_qn;

  const double M_IN = a_baryon_PSI.M_IN;

  class GSM_vector &PSI_out = *this;

  PSI_out.opposite ();

  a_dagger_baryon_helper::a_baryon_apply_add (full_common_vectors_used_in_file , phi_ejectile , PSI_IN_qn , M_IN , PSI_out);

  PSI_out.opposite ();

  return PSI_out;
}





class GSM_vector & GSM_vector::operator -= (const class A_cluster_PSI_str &A_cluster_PSI)
{
  const bool full_common_vectors_used_in_file = A_cluster_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_cluster_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_cluster_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_cluster_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_cluster_PSI.LCM_cluster_projectile;
  
  const double M_cluster_projectile = A_cluster_PSI.M_cluster_projectile;

  const class correlated_state_str &PSI_cluster_projectile_qn = A_cluster_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_cluster_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_cluster_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_cluster_PSI.NCM_HO_IN;

  const int LCM_IN = A_cluster_PSI.LCM_IN;
  
  const double M_IN = A_cluster_PSI.M_IN;

  const class correlated_state_str &PSI_IN_qn = A_cluster_PSI.PSI_IN_qn;  
	
  class GSM_vector &PSI_out = *this;
  
  PSI_out.opposite ();

  A_dagger_cluster_helper::A_cluster_apply_add (full_common_vectors_used_in_file ,
						is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , M_cluster_projectile , PSI_cluster_projectile_qn , 
						is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , M_IN                 , PSI_IN_qn                 , PSI_out);

  PSI_out.opposite ();

  return PSI_out;
}






class GSM_vector & GSM_vector::operator -= (const class x_a_baryon_PSI_str &x_a_baryon_PSI)
{
  const class a_baryon_PSI_str &a_baryon_PSI = x_a_baryon_PSI.a_baryon_PSI;

  const TYPE &x = x_a_baryon_PSI.x;

  class GSM_vector &PSI_out = *this;
  
  if (x == 0.0) return PSI_out;
  
  const TYPE minus_x = -x;
  
  const bool full_common_vectors_used_in_file = a_baryon_PSI.full_common_vectors_used_in_file;

  const class nljm_struct &phi_ejectile = a_baryon_PSI.phi_ejectile;
  
  const class correlated_state_str &PSI_IN_qn = a_baryon_PSI.PSI_IN_qn;

  const double M_IN = a_baryon_PSI.M_IN;

  PSI_out /= minus_x;
	
  a_dagger_baryon_helper::a_baryon_apply_add (full_common_vectors_used_in_file , phi_ejectile , PSI_IN_qn , M_IN , PSI_out);

  PSI_out *= minus_x;

  return PSI_out;
}







class GSM_vector & GSM_vector::operator -= (const class x_A_cluster_PSI_str &x_A_cluster_PSI)
{
  const class A_cluster_PSI_str &A_cluster_PSI = x_A_cluster_PSI.A_cluster_PSI;

  const TYPE &x = x_A_cluster_PSI.x;

  class GSM_vector &PSI_out = *this;
  
  if (x == 0.0) return PSI_out;
  
  const TYPE minus_x = -x;
  
  const bool full_common_vectors_used_in_file = A_cluster_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_cluster_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_cluster_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_cluster_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_cluster_PSI.LCM_cluster_projectile;
  
  const double M_cluster_projectile = A_cluster_PSI.M_cluster_projectile;

  const class correlated_state_str &PSI_cluster_projectile_qn = A_cluster_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_cluster_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_cluster_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_cluster_PSI.NCM_HO_IN;

  const int LCM_IN = A_cluster_PSI.LCM_IN;
  
  const double M_IN = A_cluster_PSI.M_IN;

  const class correlated_state_str &PSI_IN_qn = A_cluster_PSI.PSI_IN_qn;
  
  PSI_out /= minus_x;
	
  A_dagger_cluster_helper::A_cluster_apply_add (full_common_vectors_used_in_file ,
						is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , M_cluster_projectile , PSI_cluster_projectile_qn , 
						is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , M_IN                 , PSI_IN_qn                 , PSI_out);

  PSI_out *= minus_x;

  return PSI_out;
}







class GSM_vector & GSM_vector::operator -= (const class a_baryon_coupled_to_J_PSI_str &a_baryon_coupled_to_J_PSI)
{
  const bool full_common_vectors_used_in_file = a_baryon_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const class nlj_struct &shell_ejectile = a_baryon_coupled_to_J_PSI.shell_ejectile;
    
  const class correlated_state_str &PSI_IN_qn = a_baryon_coupled_to_J_PSI.PSI_IN_qn;

  const double J_OUT = a_baryon_coupled_to_J_PSI.J_OUT;
  
  class GSM_vector &PSI_out = *this;

  PSI_out.opposite ();

  a_dagger_baryon_helper::a_baryon_coupled_to_J_apply_add (full_common_vectors_used_in_file , shell_ejectile , PSI_IN_qn , J_OUT , PSI_out);

  PSI_out.opposite ();

  return PSI_out;
}








class GSM_vector & GSM_vector::operator -= (const class A_cluster_coupled_to_J_PSI_str &A_cluster_coupled_to_J_PSI)
{
  const bool full_common_vectors_used_in_file = A_cluster_coupled_to_J_PSI.full_common_vectors_used_in_file;
  
  const bool is_it_CM_relative_cluster_projectile = A_cluster_coupled_to_J_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_cluster_coupled_to_J_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_cluster_coupled_to_J_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_cluster_coupled_to_J_PSI.LCM_cluster_projectile;
 
  const class correlated_state_str &PSI_cluster_projectile_qn = A_cluster_coupled_to_J_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_cluster_coupled_to_J_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_cluster_coupled_to_J_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_cluster_coupled_to_J_PSI.NCM_HO_IN;

  const int LCM_IN = A_cluster_coupled_to_J_PSI.LCM_IN;
 
  const class correlated_state_str &PSI_IN_qn = A_cluster_coupled_to_J_PSI.PSI_IN_qn;  

  const double J_OUT = A_cluster_coupled_to_J_PSI.J_OUT;
  
  class GSM_vector &PSI_out = *this;

  PSI_out.opposite ();

  A_dagger_cluster_helper::A_cluster_coupled_to_J_apply_add (full_common_vectors_used_in_file ,
							     is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , PSI_cluster_projectile_qn , 
							     is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , PSI_IN_qn                 , J_OUT , PSI_out);

  PSI_out.opposite ();

  return PSI_out;
}






class GSM_vector & GSM_vector::operator -= (const class x_a_baryon_coupled_to_J_PSI_str &x_a_baryon_coupled_to_J_PSI)
{
  const class a_baryon_coupled_to_J_PSI_str &a_baryon_coupled_to_J_PSI = x_a_baryon_coupled_to_J_PSI.a_baryon_coupled_to_J_PSI;
  
  const TYPE &x = x_a_baryon_coupled_to_J_PSI.x;

  class GSM_vector &PSI_out = *this;
  
  if (x == 0.0) return PSI_out;
  
  const TYPE minus_x = -x;
  
  const bool full_common_vectors_used_in_file = a_baryon_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const class nlj_struct &shell_ejectile = a_baryon_coupled_to_J_PSI.shell_ejectile;

  const class correlated_state_str &PSI_IN_qn = a_baryon_coupled_to_J_PSI.PSI_IN_qn;
 
  const double J_OUT = a_baryon_coupled_to_J_PSI.J_OUT;
  
  PSI_out /= minus_x;
	
  a_dagger_baryon_helper::a_baryon_coupled_to_J_apply_add (full_common_vectors_used_in_file , shell_ejectile , PSI_IN_qn , J_OUT , PSI_out);

  PSI_out *= minus_x;

  return PSI_out;
}







class GSM_vector & GSM_vector::operator -= (const class x_A_cluster_coupled_to_J_PSI_str &x_A_cluster_coupled_to_J_PSI)
{
  const class A_cluster_coupled_to_J_PSI_str &A_cluster_coupled_to_J_PSI = x_A_cluster_coupled_to_J_PSI.A_cluster_coupled_to_J_PSI;

  const TYPE &x = x_A_cluster_coupled_to_J_PSI.x;

  class GSM_vector &PSI_out = *this;
  
  if (x == 0.0) return PSI_out;
  
  const TYPE minus_x = -x;

  const bool full_common_vectors_used_in_file = A_cluster_coupled_to_J_PSI.full_common_vectors_used_in_file;

  const bool is_it_CM_relative_cluster_projectile = A_cluster_coupled_to_J_PSI.is_it_CM_relative_cluster_projectile;
  
  const enum particle_type cluster_projectile = A_cluster_coupled_to_J_PSI.cluster_projectile;
  
  const int NCM_HO_cluster_projectile = A_cluster_coupled_to_J_PSI.NCM_HO_cluster_projectile;

  const int LCM_cluster_projectile = A_cluster_coupled_to_J_PSI.LCM_cluster_projectile;
 
  const class correlated_state_str &PSI_cluster_projectile_qn = A_cluster_coupled_to_J_PSI.PSI_cluster_projectile_qn;  

  const bool is_it_CM_relative_IN = A_cluster_coupled_to_J_PSI.is_it_CM_relative_IN;
  
  const enum particle_type cluster_IN = A_cluster_coupled_to_J_PSI.cluster_IN;
  
  const int NCM_HO_IN = A_cluster_coupled_to_J_PSI.NCM_HO_IN;

  const int LCM_IN = A_cluster_coupled_to_J_PSI.LCM_IN;
 
  const class correlated_state_str &PSI_IN_qn = A_cluster_coupled_to_J_PSI.PSI_IN_qn;  

  const double J_OUT = A_cluster_coupled_to_J_PSI.J_OUT;
  
  PSI_out /= minus_x;
	
  A_dagger_cluster_helper::A_cluster_coupled_to_J_apply_add (full_common_vectors_used_in_file ,
							     is_it_CM_relative_cluster_projectile , cluster_projectile , NCM_HO_cluster_projectile , LCM_cluster_projectile , PSI_cluster_projectile_qn , 
							     is_it_CM_relative_IN                 , cluster_IN         , NCM_HO_IN                 , LCM_IN                 , PSI_IN_qn                 , J_OUT , PSI_out);

  PSI_out *= minus_x;

  return PSI_out;
}









// No closures are used here, these are simple overloading operators as they create no intermediates
// -------------------------------------------------------------------------------------------------




const class GSM_vector & GSM_vector::operator = (const class GSM_vector &PSI)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const unsigned int space_dimensions_all_processes_max = GSM_vector_helper.get_space_dimensions_all_processes_max ();

  class GSM_vector &PSI_out = *this;
  	  
  for (unsigned int i = 0 ; i < space_dimensions_all_processes_max ; i++) PSI_out[i] = PSI[i];

  return PSI_out;
}



#ifdef TYPEisDOUBLECOMPLEX

const class GSM_vector& GSM_vector::operator = (const complex<double> &x)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const unsigned int space_dimensions_all_processes_max = GSM_vector_helper.get_space_dimensions_all_processes_max ();

  class GSM_vector &PSI = *this;

  for (unsigned int i = 0 ; i < space_dimensions_all_processes_max ; i++) PSI[i] = x;

  return PSI;
}

#endif




const class GSM_vector& GSM_vector::operator = (const double x)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const unsigned int space_dimensions_all_processes_max = GSM_vector_helper.get_space_dimensions_all_processes_max ();

  class GSM_vector &PSI = *this;

  for (unsigned int i = 0 ; i < space_dimensions_all_processes_max ; i++) PSI[i] = x;

  return PSI;
}





class GSM_vector & GSM_vector::operator += (const class GSM_vector &PSI)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const unsigned int space_dimensions_all_processes_max = GSM_vector_helper.get_space_dimensions_all_processes_max ();

  class GSM_vector &PSI_out = *this;

  for (unsigned int i = 0 ; i < space_dimensions_all_processes_max ; i++)
    PSI_out[i] += PSI[i];

  return PSI_out;
}



class GSM_vector& GSM_vector::operator += (const TYPE &x)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const unsigned int space_dimensions_all_processes_max = GSM_vector_helper.get_space_dimensions_all_processes_max ();

  class GSM_vector &PSI = *this;

  for (unsigned int i = 0 ; i < space_dimensions_all_processes_max ; i++) PSI[i] += x;

  return PSI;
}



class GSM_vector & GSM_vector::operator -= (const class GSM_vector &PSI)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const unsigned int space_dimensions_all_processes_max = GSM_vector_helper.get_space_dimensions_all_processes_max ();

  class GSM_vector &PSI_out = *this;

  for (unsigned int i = 0 ; i < space_dimensions_all_processes_max ; i++) PSI_out[i] -= PSI[i];

  return PSI_out;
}




class GSM_vector& GSM_vector::operator -= (const TYPE &x)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
   
  const unsigned int space_dimensions_all_processes_max = GSM_vector_helper.get_space_dimensions_all_processes_max ();

  class GSM_vector &PSI = *this;

  for (unsigned int i = 0 ; i < space_dimensions_all_processes_max ; i++) PSI[i] -= x;

  return PSI;
}




class GSM_vector & GSM_vector::operator *= (const TYPE &x)
{
  class GSM_vector &PSI = *this;

  if (x == 0.0)
    PSI = 0.0;
  else if (x == -1.0)
    PSI.opposite ();
  else if (x != 1.0)
    {
      const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
      const unsigned int space_dimensions_all_processes_max = GSM_vector_helper.get_space_dimensions_all_processes_max ();

      for (unsigned int i = 0 ; i < space_dimensions_all_processes_max ; i++) PSI[i] *= x;
    }

  return *this;
}








class GSM_vector & GSM_vector::operator /= (const TYPE &x)
{
  class GSM_vector &PSI = *this;
 
  if (x == -1.0)
    PSI.opposite ();
  else if (x != 1.0)
    {
      const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
      const unsigned int space_dimensions_all_processes_max = GSM_vector_helper.get_space_dimensions_all_processes_max ();

      for (unsigned int i = 0 ; i < space_dimensions_all_processes_max ; i++) PSI[i] /= x;
    }

  return *this;
}





