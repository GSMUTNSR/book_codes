#include "../GSM_include/GSM_include_def.h"

using namespace string_routines;
using namespace beta_transitions_common;
using namespace inputs_misc;
using namespace correlated_state_routines;

// TYPE is double or complex
// -------------------------


// Calculation of the beta transition matrix elements for a given suboperator for all one-body basis states
// --------------------------------------------------------------------------------------------------------
// Beta transitions are functions of several operators.
// One consider a single operator here, such as Fermi or Gamow-Teller for allowed beta decay,
// or x, w, u, z, xi, xi'y and xi'v, with or without Coulomb correction for first-forbidden beta decay.
// Reduced beta transition matrix elements are calculated first, and dereduced afterwards.

void beta_transitions::beta_suboperator_OBMEs_calc (
						    const bool is_it_HO_expansion , 
						    const enum radial_operator_type radial_operator , 
						    const enum beta_suboperator_type beta_suboperator , 
						    const class interaction_class &inter_data , 
						    const int rank_Op_projection , 
						    const class nucleons_data &data_in , 
						    const class nucleons_data &data_out , 
						    class array<TYPE> &OBMEs)
{
  const unsigned int N_nlj_in  = data_in.get_N_nlj ();
  const unsigned int N_nlj_out = data_out.get_N_nlj ();

  class array<TYPE> OBMEs_reduced(N_nlj_in , N_nlj_out);

  beta_suboperator_OBMEs_reduced_calc (is_it_HO_expansion , radial_operator , beta_suboperator , inter_data , data_in , data_out , OBMEs_reduced);

  const int rank_Op = rank_beta_suboperator_determine (beta_suboperator);

  OBMEs_dereduced_calc<TYPE> (rank_Op , rank_Op_projection , data_in , data_out , OBMEs_reduced , OBMEs);
}







// Calculation of the beta transition many-body matrix elements <Psi[out] | Op | Psi[in]> for a given suboperator 
// --------------------------------------------------------------------------------------------------------------
// Beta transitions are functions of several operators.
// One consider a single operator here, such as Fermi or Gamow-Teller for allowed beta decay,
// or x, w, u, z, xi, xi'y and xi'v, with or without Coulomb correction for first-forbidden beta decay.
// <Psi[out] | Op | Psi[in]> is calculated and stored in an array of beta transition many-body matrix elements.

void beta_transitions::beta_suboperator_NBME_calc (
						   const enum beta_pm_type beta_pm , 
						   const bool is_it_HO_expansion , 
						   const bool full_common_vectors_used_in_file ,
						   const enum radial_operator_type radial_operator , 
						   const enum beta_suboperator_type beta_suboperator , 
						   const class interaction_class &inter_data , 
						   const class correlated_state_str &PSI_IN_qn , 
						   const class correlated_state_str &PSI_OUT_qn , 
						   const class GSM_vector &PSI_OUT , 
						   class array<TYPE> &beta_suboperators_NBMEs)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data_in  = data_in_determine  (beta_pm , prot_data , neut_data);
  const class nucleons_data &data_out = data_out_determine (beta_pm , prot_data , neut_data);

  const unsigned int N_nlj_in  = data_in.get_N_nlj ();
  const unsigned int N_nlj_out = data_out.get_N_nlj ();

  const unsigned int N_nljm_in  = data_in.get_N_nljm ();
  const unsigned int N_nljm_out = data_out.get_N_nljm ();

  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();

  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;

  const int rank_Op = rank_beta_suboperator_determine (beta_suboperator);
  
  const int rank_Op_projection = make_int (M_OUT - M_IN);

  const unsigned int beta_suboperator_index = beta_suboperator_type_index_determine (beta_suboperator);

  class array<TYPE> OBMEs_reduced(N_nlj_in , N_nlj_out);

  class array<TYPE> OBMEs(N_nljm_in , N_nljm_out);

  beta_suboperator_OBMEs_reduced_calc (is_it_HO_expansion , radial_operator , beta_suboperator , inter_data , data_in , data_out , OBMEs_reduced);
  
  OBMEs_dereduced_calc<TYPE> (rank_Op , rank_Op_projection , data_in , data_out , OBMEs_reduced , OBMEs);
  
  beta_suboperators_NBMEs(beta_suboperator_index) = beta_transitions_NBMEs::calc (beta_pm ,  beta_suboperator , full_common_vectors_used_in_file , OBMEs , PSI_IN_qn , PSI_OUT_qn , PSI_OUT);
}

void beta_transitions::beta_suboperators_NBMEs_calc (
						     const enum beta_type beta , 
						     const enum beta_pm_type beta_pm , 
						     const bool is_it_HO_expansion , 
						     const bool full_common_vectors_used_in_file ,
						     const class interaction_class &inter_data , 
						     const class correlated_state_str &PSI_IN_qn ,  
						     const class correlated_state_str &PSI_OUT_qn ,  
						     const class GSM_vector &PSI_OUT , 
						     class array<TYPE> &beta_suboperators_NBMEs)

{
  switch (beta)
    {
    case ALLOWED:
      {
	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , full_common_vectors_used_in_file , OVERLAP , FERMI_ALLOWED        , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);
	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , full_common_vectors_used_in_file , OVERLAP , GAMOW_TELLER_ALLOWED , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);	
      } break;

    case FIRST_FORBIDDEN:
      {
	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , full_common_vectors_used_in_file , FFBD , W_FFBD , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);
	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , full_common_vectors_used_in_file , FFBD , U_FFBD , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);
	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , full_common_vectors_used_in_file , FFBD , Z_FFBD , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);
	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , full_common_vectors_used_in_file , FFBD , X_FFBD , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);

	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , full_common_vectors_used_in_file , FFBD_COULOMB , W_FFBD_COULOMB , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);
	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , full_common_vectors_used_in_file , FFBD_COULOMB , U_FFBD_COULOMB , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);
	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , full_common_vectors_used_in_file , FFBD_COULOMB , X_FFBD_COULOMB , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);

	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , full_common_vectors_used_in_file , REDUCED_GRADIENT , XI_PRIME_V_FFBD , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);
	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , full_common_vectors_used_in_file , REDUCED_GRADIENT , XI_PRIME_Y_FFBD , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);
      } break;

    default: error_message_print_abort ("No beta transition recognized in beta_transitions::beta_suboperators_NBMEs_calc");
    }
}










// Calculation and print on screen of beta transition many-body matrix elements <Psi[out] | Op | Psi[in]> for all operators
// ------------------------------------------------------------------------------------------------------------------------
// First-forbidden or allowed beta decays are calculated and printed on screen, by looping over the demanded values in the input file.
// All possible allowed or first-forbidden beta decay suboperators are calculated if one asks for allowed or first-forbidden beta decay operators (one or the other).

void beta_transitions::calc_print (
				   const input_data_str &input_data , 
				   const class interaction_class &inter_data , 
				   const class array<class correlated_state_str> &PSI_qn_tab ,
				   class nucleons_data &prot_data , 
				   class nucleons_data &neut_data)
{ 
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "beta transitions" << endl;
      cout <<         "----------------" << endl << endl;
    }

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
  
  const int n_holes_max_p = prot_data.get_n_holes_max ();
  const int n_holes_max_n = neut_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_data.get_n_scat_max ();
  const int n_scat_max_n = neut_data.get_n_scat_max ();
  
  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_data.get_E_max_hw ();
  const int En_max_hw = neut_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();

  const int A = prot_data.get_A ();

  const int Z_OUT = prot_data.get_N_nucleons ();
  const int N_OUT = neut_data.get_N_nucleons ();

  const unsigned int beta_transitions_number = input_data.get_beta_transitions_number ();
 
  const class array<enum beta_type> &beta_tab = input_data.get_beta_tab ();

  const class array<enum beta_pm_type> &beta_pm_tab = input_data.get_beta_pm_tab ();
  
  const class array<unsigned int> &beta_BP_IN_tab  = input_data.get_beta_BP_IN_tab ();
  const class array<unsigned int> &beta_BP_OUT_tab = input_data.get_beta_BP_OUT_tab ();
  
  const class array<double> &beta_J_IN_tab  = input_data.get_beta_J_IN_tab ();
  const class array<double> &beta_J_OUT_tab = input_data.get_beta_J_OUT_tab ();
  
  const class array<unsigned int> &beta_vector_index_IN_tab  = input_data.get_beta_vector_index_IN_tab ();
  const class array<unsigned int> &beta_vector_index_OUT_tab = input_data.get_beta_vector_index_OUT_tab ();
  
  const class array<bool> &beta_is_it_HO_expansion_tab = input_data.get_beta_is_it_HO_expansion_tab ();
  
  const class array<double> &beta_W0_tab = input_data.get_beta_W0_tab ();
  
  for (unsigned int beta_index = 0 ; beta_index < beta_transitions_number ; beta_index++)
    {
      const enum beta_type beta = beta_tab(beta_index);
      
      const enum beta_pm_type beta_pm = beta_pm_tab(beta_index);

      const bool is_it_HO_expansion = beta_is_it_HO_expansion_tab(beta_index);

      const double W0 = beta_W0_tab(beta_index);

      const unsigned int BP_IN  = beta_BP_IN_tab(beta_index);
      const unsigned int BP_OUT = beta_BP_OUT_tab(beta_index);
      
      const unsigned int vector_index_IN  = beta_vector_index_IN_tab(beta_index);
      const unsigned int vector_index_OUT = beta_vector_index_OUT_tab(beta_index);
      
      const double J_IN  = beta_J_IN_tab(beta_index);
      const double J_OUT = beta_J_OUT_tab(beta_index);

      const double M_OUT = J_OUT;
      
      const int Z_IN = Z_IN_beta_determine (beta_pm , Z_OUT);
      const int N_IN = N_IN_beta_determine (beta_pm , N_OUT);

      const class correlated_state_str PSI_IN_qn(Z_IN , N_IN , BP_IN , J_IN , vector_index_IN , NADA , NADA , NADA , NADA , false);

      const class correlated_state_str PSI_OUT_qn = PSI_quantum_numbers_find (Z_OUT , N_OUT , BP_OUT , J_OUT , vector_index_OUT , PSI_qn_tab);

      class GSM_vector_helper_class PSI_OUT_helper(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
						   n_holes_max   , n_scat_max   , E_max_hw  ,
						   n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						   n_holes_max_n , n_scat_max_n , En_max_hw , BP_OUT , M_OUT , false , prot_data , neut_data);
      
      class GSM_vector PSI_OUT(PSI_OUT_helper);

      PSI_OUT.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_OUT_qn);
      
      const unsigned int beta_suboperator_type_number = beta_suboperator_type_number_determine ();

      class array<TYPE> beta_suboperators_NBMEs(beta_suboperator_type_number);

      beta_suboperators_NBMEs = 0.0;

      beta_suboperators_NBMEs_calc (beta , beta_pm , is_it_HO_expansion , full_common_vectors_used_in_file , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  cout << J_Pi_vector_index_string (BP_IN , J_IN , vector_index_IN) << " --> " << J_Pi_vector_index_string (BP_OUT , J_OUT , vector_index_OUT) << endl;

	  beta_transitions_common::calc_print (beta , beta_pm , A , Z_OUT , W0 , J_IN , beta_suboperators_NBMEs);
	}
    }
}

/*

//Yi hua Lam calculatons A = 78 or 79

class array<correlated_state_str > qn_tab_1D(PSI_qn_tab.dimension_total ());
	  
for (unsigned int i = 0 ; i < PSI_qn_tab.dimension_total () ; i++) qn_tab_1D(i) = PSI_qn_tab[i];
	  
eigenvectors_sort (0 , PSI_qn_tab.dimension_total () - 1 , qn_tab_1D);
	  
cout << "     E[in] : " << 0.0;
cout << " MeV      E[out] : " << real (PSI_OUT_qn.get_E () - qn_tab_1D[0].get_E ()) << " MeV" << endl << endl;
*/

/*
//Yi hua Lam calculatons A = 80-81

class array<correlated_state_str > qn_tab_1D(PSI_qn_tab.dimension_total ());
	  
for (unsigned int i = 0 ; i < PSI_qn_tab.dimension_total () ; i++) qn_tab_1D(i) = PSI_qn_tab[i];
	  
eigenvectors_sort (0 , PSI_qn_tab.dimension_total () - 1 , qn_tab_1D);
	  
if (BP_IN == 0)
{
if (J_IN == 0)
{
if (vector_index_IN == 0) cout << "     E[in] : " << 0.0;
if (vector_index_IN == 1) cout << "     E[in] : " << 1.625979701036;
}
	  
if (J_IN == 1)
{
if (vector_index_IN == 0) cout << "     E[in] : " << 1.95098005085751;
if (vector_index_IN == 1) cout << "     E[in] : " << 3.27713455502345;
}
	  
if (J_IN == 2)
{
if (vector_index_IN == 0) cout << "     E[in] : " << 1.36523722728418;
if (vector_index_IN == 1) cout << "     E[in] : " << 2.25170834590669;
if (vector_index_IN == 2) cout << "     E[in] : " << 3.7049351498006;
if (vector_index_IN == 3) cout << "     E[in] : " << 4.74421400928349;
}
	      
if (J_IN == 3)
{
if (vector_index_IN == 0) cout << "     E[in] : " << 2.65086993154442;
}
	      
if (J_IN == 4)
{
if (vector_index_IN == 0) cout << "     E[in] : " << 2.55563439300021;
if (vector_index_IN == 1) cout << "     E[in] : " << 3.97359978149414;
}
}

if (BP_IN == 1)
{
if (J_IN == 3) if (vector_index_IN == 0) cout << "     E[in] : " << 4.87791514209598;
if (J_IN == 4) if (vector_index_IN == 0) cout << "     E[in] : " << 4.79207441866836;
if (J_IN == 5) if (vector_index_IN == 0) cout << "     E[in] : " << 4.64926128183106;
if (J_IN == 6) if (vector_index_IN == 0) cout << "     E[in] : " << 4.61352105394023;

if (J_IN == 0.5)
{
if (vector_index_IN == 0) cout << "     E[in] : " << 0.473445684532756;
if (vector_index_IN == 1) cout << "     E[in] : " << 2.00579338252533;
if (vector_index_IN == 2) cout << "     E[in] : " << 2.66169053223673;
if (vector_index_IN == 3) cout << "     E[in] : " << 3.99094820336121;
}

if (J_IN == 1.5)
{
if (vector_index_IN == 0) cout << "     E[in] : " << 0;
if (vector_index_IN == 1) cout << "     E[in] : " << 0.842549956629611;
if (vector_index_IN == 2) cout << "     E[in] : " << 1.06668814753054;
if (vector_index_IN == 3) cout << "     E[in] : " << 2.05961118489034;
if (vector_index_IN == 4) cout << "     E[in] : " << 2.49411526762025;
if (vector_index_IN == 5) cout << "     E[in] : " << 2.83897218199648;
if (vector_index_IN == 6) cout << "     E[in] : " << 3.28782603787702;
if (vector_index_IN == 7) cout << "     E[in] : " << 4.03537027374118;
}
	      
if (J_IN == 2.5)
{
if (vector_index_IN == 0) cout << "     E[in] : " << 0.49005903238595;
if (vector_index_IN == 1) cout << "     E[in] : " << 0.981208700394141;
if (vector_index_IN == 2) cout << "     E[in] : " << 1.73211851041975;
if (vector_index_IN == 3) cout << "     E[in] : " << 2.02309742153301;
if (vector_index_IN == 4) cout << "     E[in] : " << 2.32623082025005;
if (vector_index_IN == 5) cout << "     E[in] : " << 3.15866050827063;
if (vector_index_IN == 7) cout << "     E[in] : " << 4.33714524908675;
if (vector_index_IN == 6) cout << "     E[in] : " << 3.57727440950632;
}
	      
if (J_IN == 3.5)
{
if (vector_index_IN == 0)   cout << "     E[in] : " << 1.0326141536517;
if (vector_index_IN == 2)   cout << "     E[in] : " << 2.44447153558318;
if (vector_index_IN == 1)   cout << "     E[in] : " << 1.99376424288003;
if (vector_index_IN == 3)   cout << "     E[in] : " << 3.29048085152806;
if (vector_index_IN == 4)   cout << "     E[in] : " << 4.05525089163805;
if (vector_index_IN == 5)   cout << "     E[in] : " << 5.06320642828208;
}

if (J_IN == 4.5)
{
if (vector_index_IN == 0)   cout << "     E[in] : " << 1.3829392888489;
if (vector_index_IN == 1)   cout << "     E[in] : " << 2.1611035187525;
if (vector_index_IN == 2)   cout << "     E[in] : " << 3.7072173315462;
if (vector_index_IN == 3)   cout << "     E[in] : " << 4.3835427887977;
if (vector_index_IN == 4)   cout << "     E[in] : " << 5.01931163022721;
}
	      
if (J_IN == 5.5) if (vector_index_IN == 0)   cout << "     E[in] : " << 2.41117791514068;
}
	  	  
cout << " MeV      E[out] : " << real (PSI_OUT_qn.get_E () - qn_tab_1D[0].get_E ()) << " MeV" << endl << endl;
	  
*/

/*	  
//Yi hua Lam calculatons A = 82
		  
class array<correlated_state_str > qn_tab_1D(PSI_qn_tab.dimension_total ());
	  
for (unsigned int i = 0 ; i < PSI_qn_tab.dimension_total () ; i++) qn_tab_1D(i) = PSI_qn_tab[i];
	  
eigenvectors_sort (0 , PSI_qn_tab.dimension_total () - 1 , qn_tab_1D);
	  
if (BP_IN == 0)
{
if (J_IN == 0)
{
if (vector_index_IN == 0) cout << "     E[in] : " << 0.0;
if (vector_index_IN == 1) cout << "     E[in] : " << 2.37825630968683;
 if (vector_index_IN == 2) cout << "     E[in] : " << 2.63371160225758;
 if (vector_index_IN == 3) cout << "     E[in] : " << 3.05436511728463;
 if (vector_index_IN == 4) cout << "     E[in] : " << 4.11667734007668;
 }
	  
 if (J_IN == 1)
 {
 if (vector_index_IN == 0) cout << "     E[in] : " << 1.65402876506961;
 if (vector_index_IN == 1) cout << "     E[in] : " << 2.65349875387154;
 if (vector_index_IN == 2) cout << "     E[in] : " << 2.72117813899984;
 if (vector_index_IN == 3) cout << "     E[in] : " << 3.29321429446317;
 if (vector_index_IN == 4) cout << "     E[in] : " << 4.15311051656036;
 if (vector_index_IN == 5) cout << "     E[in] : " << 4.30832674857652;
 if (vector_index_IN == 6) cout << "     E[in] : " << 4.5410653995668;
 }
	  
 if (J_IN == 2)
 {
 if (vector_index_IN == 0) cout << "     E[in] : " << 1.32362116896577;
 if (vector_index_IN == 1) cout << "     E[in] : " << 1.46982073530209;
 if (vector_index_IN == 2) cout << "     E[in] : " << 2.31991027160807;
 if (vector_index_IN == 3) cout << "     E[in] : " << 2.6485123489372;
 if (vector_index_IN == 4) cout << "     E[in] : " << 2.98290994272622;
 if (vector_index_IN == 5) cout << "     E[in] : " << 3.24384442833604;
 if (vector_index_IN == 6) cout << "     E[in] : " << 4.01668729795736;
 if (vector_index_IN == 7) cout << "     E[in] : " << 4.39176470031536;
 if (vector_index_IN == 8) cout << "     E[in] : " << 4.44395577274692;
 if (vector_index_IN == 9) cout << "     E[in] : " << 4.56184033079892;
 }
	      
 if (J_IN == 3)
 {
 if (vector_index_IN == 0) cout << "     E[in] : " << 1.70502420493257;
 if (vector_index_IN == 1) cout << "     E[in] : " << 2.6876654187861;
 if (vector_index_IN == 2) cout << "     E[in] : " << 3.2254625591012;
 if (vector_index_IN == 3) cout << "     E[in] : " << 3.30820544719191;
 if (vector_index_IN == 4) cout << "     E[in] : " << 4.04236652165469;
 if (vector_index_IN == 5) cout << "     E[in] : " << 4.2921473584578;
 if (vector_index_IN == 6) cout << "     E[in] : " << 4.39651911739902;
 if (vector_index_IN == 7) cout << "     E[in] : " << 4.79730800803581;
 }
	  
 if (J_IN == 4)
 {
 if (vector_index_IN == 0) cout << "     E[in] : " << 2.11104195121295;
 if (vector_index_IN == 1) cout << "     E[in] : " << 2.36424142425857;
 if (vector_index_IN == 2) cout << "     E[in] : " << 2.84973043575591;
 if (vector_index_IN == 3) cout << "     E[in] : " << 3.40993144222601;
 if (vector_index_IN == 4) cout << "     E[in] : " << 3.62343212407595;
 if (vector_index_IN == 5) cout << "     E[in] : " << 4.21873709158749;
 if (vector_index_IN == 6) cout << "     E[in] : " << 4.56184033079892;
 }

 if (J_IN == 5)
 {
 if (vector_index_IN == 0) cout << "     E[in] : " << 3.3467972512954;
 if (vector_index_IN == 1) cout << "     E[in] : " << 4.43372838139669;
 }
	  
 if (J_IN == 6)
 {
 if (vector_index_IN == 0) cout << "     E[in] : " << 3.57790651272133;
 if (vector_index_IN == 1) cout << "     E[in] : " << 4.99851467511388;
 }
	  
 }

 if (BP_IN == 1)
 {
 if (J_IN == 3) if (vector_index_IN == 0) cout << "     E[in] : " << 4.79404130459915;
 if (J_IN == 4) if (vector_index_IN == 0) cout << "     E[in] : " << 4.703946422573;
 if (J_IN == 5) if (vector_index_IN == 0) cout << "     E[in] : " << 4.76763688707156;
 if (J_IN == 6) if (vector_index_IN == 0) cout << "     E[in] : " << 4.76568995082911;
 }
	  	  
 cout << " MeV      E[out] : " << real (PSI_OUT_qn.get_E () - qn_tab_1D[0].get_E ()) << " MeV" << endl << endl;
*/

 /*

 //Yi hua Lam calculatons A = 82
		  
 class array<correlated_state_str > qn_tab_1D(PSI_qn_tab.dimension_total ());
	  
 for (unsigned int i = 0 ; i < PSI_qn_tab.dimension_total () ; i++) qn_tab_1D(i) = PSI_qn_tab[i];
	  
 eigenvectors_sort (0 , PSI_qn_tab.dimension_total () - 1 , qn_tab_1D);
	  
 if (BP_IN == 0)
 {
 if (J_IN == 0)
 {
 if (vector_index_IN == 0) cout << "     E[in] : " << 0.0;
 if (vector_index_IN == 1) cout << "     E[in] : " << 2.37825630968683;
 if (vector_index_IN == 2) cout << "     E[in] : " << 2.63371160225758;
 if (vector_index_IN == 3) cout << "     E[in] : " << 3.05436511728463;
 if (vector_index_IN == 4) cout << "     E[in] : " << 4.11667734007668;
 }
	  
 if (J_IN == 1)
 {
 if (vector_index_IN == 0) cout << "     E[in] : " << 1.65402876506961;
 if (vector_index_IN == 1) cout << "     E[in] : " << 2.65349875387154;
 if (vector_index_IN == 2) cout << "     E[in] : " << 2.72117813899984;
 if (vector_index_IN == 3) cout << "     E[in] : " << 3.29321429446317;
 if (vector_index_IN == 4) cout << "     E[in] : " << 4.15311051656036;
 if (vector_index_IN == 5) cout << "     E[in] : " << 4.30832674857652;
 if (vector_index_IN == 6) cout << "     E[in] : " << 4.5410653995668;
 }
	  
 if (J_IN == 2)
 {
 if (vector_index_IN == 0) cout << "     E[in] : " << 1.32362116896577;
 if (vector_index_IN == 1) cout << "     E[in] : " << 1.46982073530209;
 if (vector_index_IN == 2) cout << "     E[in] : " << 2.31991027160807;
 if (vector_index_IN == 3) cout << "     E[in] : " << 2.6485123489372;
 if (vector_index_IN == 4) cout << "     E[in] : " << 2.98290994272622;
 if (vector_index_IN == 5) cout << "     E[in] : " << 3.24384442833604;
 if (vector_index_IN == 6) cout << "     E[in] : " << 4.01668729795736;
 if (vector_index_IN == 7) cout << "     E[in] : " << 4.39176470031536;
 if (vector_index_IN == 8) cout << "     E[in] : " << 4.44395577274692;
 if (vector_index_IN == 9) cout << "     E[in] : " << 4.56184033079892;
 }
	      
 if (J_IN == 3)
 {
 if (vector_index_IN == 0) cout << "     E[in] : " << 1.70502420493257;
 if (vector_index_IN == 1) cout << "     E[in] : " << 2.6876654187861;
 if (vector_index_IN == 2) cout << "     E[in] : " << 3.2254625591012;
 if (vector_index_IN == 3) cout << "     E[in] : " << 3.30820544719191;
 if (vector_index_IN == 4) cout << "     E[in] : " << 4.04236652165469;
 if (vector_index_IN == 5) cout << "     E[in] : " << 4.2921473584578;
 if (vector_index_IN == 6) cout << "     E[in] : " << 4.39651911739902;
 if (vector_index_IN == 7) cout << "     E[in] : " << 4.79730800803581;
 }
	  
 if (J_IN == 4)
 {
 if (vector_index_IN == 0) cout << "     E[in] : " << 2.11104195121295;
 if (vector_index_IN == 1) cout << "     E[in] : " << 2.36424142425857;
 if (vector_index_IN == 2) cout << "     E[in] : " << 2.84973043575591;
 if (vector_index_IN == 3) cout << "     E[in] : " << 3.40993144222601;
 if (vector_index_IN == 4) cout << "     E[in] : " << 3.62343212407595;
 if (vector_index_IN == 5) cout << "     E[in] : " << 4.21873709158749;
 if (vector_index_IN == 6) cout << "     E[in] : " << 4.56184033079892;
 }

 if (J_IN == 5)
 {
 if (vector_index_IN == 0) cout << "     E[in] : " << 3.3467972512954;
 if (vector_index_IN == 1) cout << "     E[in] : " << 4.43372838139669;
 }
	  
 if (J_IN == 6)
 {
 if (vector_index_IN == 0) cout << "     E[in] : " << 3.57790651272133;
 if (vector_index_IN == 1) cout << "     E[in] : " << 4.99851467511388;
 }
	  
 }

 if (BP_IN == 1)
 {
 if (J_IN == 3) if (vector_index_IN == 0) cout << "     E[in] : " << 4.79404130459915;
 if (J_IN == 4) if (vector_index_IN == 0) cout << "     E[in] : " << 4.703946422573;
 if (J_IN == 5) if (vector_index_IN == 0) cout << "     E[in] : " << 4.76763688707156;
 if (J_IN == 6) if (vector_index_IN == 0) cout << "     E[in] : " << 4.76568995082911;
 }
	  	  
 cout << " MeV      E[out] : " << real (PSI_OUT_qn.get_E () - qn_tab_1D[0].get_E ()) << " MeV" << endl << endl;
 }
 */
