#include "../GSM_include/GSM_include_def.h"

// Z_cluster_charge_potential: charge felt by the cluster , equal to Z_Target = Z - Z_cluster

// TYPE is double or complex
// -------------------------

// CM means center of mass
// -----------------------

// See GSM_cluster_data.h for definitions for information about its data. Routines here are rather straightforward so that no details are provided, only general explanations and used mathematical formulas
// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Class storing all data related to a cluster (deuteron, alpha, proton, neutron, ...)
// -----------------------------------------------------------------------------------
// One builds configurations and SDs and jumps for the cluster in one-body HO and Berggren bases to be able to apply operators on cluster wave functions.
// One also takes care of its CM part by defining radial potentials acting on CM parts in GSM-CC from cluster approximation.

using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace Gauss_Legendre;



cluster_data::cluster_data () :
  H_potential (NO_POTENTIAL) , 
  basis_potential (NO_POTENTIAL) , 
  is_it_Lowdin (false) , 
  cluster (NO_PARTICLE) , 
  S_matrix_pole (false) ,
  Z_cluster (0) , 
  N_cluster (0) , 
  A_cluster (0) , 
  A_composite (0) , 
  BP_intrinsic (2) , 
  J_intrinsic (0.0) , 
  vector_index_intrinsic (0) , 
  Lmax (0) , 
  Nmax (0) , 
  cluster_mass_for_calc (0) , 
  N_bef_R_GL (0) , 
  N_aft_R_GL (0) , 
  N_bef_R_uniform (0) , 
  N_aft_R_uniform (0) ,
  Nk_momentum_GL (0) , 
  Nk_momentum_uniform (0) ,  
  R (0.0) , 
  step_bef_R_uniform (0.0) , 
  R_real_max (0.0) , 
  kmax_momentum (0.0) , 
  R_Fermi_momentum (0.0) , 
  R_charge (0.0) , 
  nucleus_mass (0.0) , 
  R_cut_function (0.0) , 
  d_cut_function (0.0) , 
  b_lab_cluster (0.0) , 
  hbar_omega_cluster (0.0) , 
  Z_cluster_charge_potential (0.0) , 
  E_intrinsic_cluster (0.0) , 
  E_CM_HO_max (0) , 
  potential_cluster_CM_derivative_R (0.0)
{}



cluster_data::cluster_data (
			    const bool is_there_cout , 
			    const bool is_it_GSM_basis , 
			    const bool is_it_CM_HO_basis , 
			    const class input_data_str &input_data , 
			    const class nucleons_data &prot_data , 
			    const class nucleons_data &neut_data , 
			    const class interaction_class &inter_data_basis , 
			    const unsigned int ic) :
  H_potential (NO_POTENTIAL) , 
  basis_potential (NO_POTENTIAL) , 
  is_it_Lowdin (false) , 
  cluster (NO_PARTICLE) ,
  S_matrix_pole (false) ,
  Z_cluster (0) , 
  N_cluster (0) , 
  A_cluster (0) , 
  A_composite (0) , 
  BP_intrinsic (2) , 
  J_intrinsic (0.0) , 
  vector_index_intrinsic (0) , 
  Lmax (0) , 
  Nmax (0) , 
  cluster_mass_for_calc (0) , 
  N_bef_R_GL (0) , 
  N_aft_R_GL (0) , 
  N_bef_R_uniform (0) , 
  N_aft_R_uniform (0) , 
  Nk_momentum_GL (0) , 
  Nk_momentum_uniform (0) ,  
  R (0.0) , 
  step_bef_R_uniform (0.0) , 
  R_real_max (0.0) , 
  kmax_momentum (0.0) , 
  R_Fermi_momentum (0.0) , 
  R_charge (0.0) , 
  nucleus_mass (0.0) , 
  R_cut_function (0.0) , 
  d_cut_function (0.0) , 
  b_lab_cluster (0.0) , 
  hbar_omega_cluster (0.0) , 
  Z_cluster_charge_potential (0.0) , 
  E_intrinsic_cluster (0.0) , 
  E_CM_HO_max (0) , 
  potential_cluster_CM_derivative_R (0.0)
{
  allocate (is_there_cout , is_it_GSM_basis , is_it_CM_HO_basis , input_data , prot_data , neut_data , inter_data_basis , ic);
}



cluster_data::cluster_data (
			    const bool is_it_CM_HO_basis , 
			    const class input_data_str &input_data , 
			    const class nucleons_data &prot_data , 
			    const class nucleons_data &neut_data , 
			    const class interaction_class &inter_data_basis , 
			    const class cluster_data &cluster_data_helper ,
			    const unsigned int ic) :
  H_potential (NO_POTENTIAL) , 
  basis_potential (NO_POTENTIAL) , 
  is_it_Lowdin (false) , 
  cluster (NO_PARTICLE) ,
  S_matrix_pole (false) ,
  Z_cluster (0) , 
  N_cluster (0) , 
  A_cluster (0) , 
  A_composite (0) , 
  BP_intrinsic (2) , 
  J_intrinsic (0.0) , 
  vector_index_intrinsic (0) , 
  Lmax (0) , 
  Nmax (0) , 
  cluster_mass_for_calc (0) , 
  N_bef_R_GL (0) , 
  N_aft_R_GL (0) , 
  N_bef_R_uniform (0) , 
  N_aft_R_uniform (0) , 
  Nk_momentum_GL (0) , 
  Nk_momentum_uniform (0) , 
  R (0.0) , 
  step_bef_R_uniform (0.0) , 
  R_real_max (0.0) , 
  kmax_momentum (0.0) , 
  R_Fermi_momentum (0.0) , 
  R_charge (0.0) , 
  nucleus_mass (0.0) , 
  R_cut_function (0.0) , 
  d_cut_function (0.0) , 
  b_lab_cluster (0.0) , 
  hbar_omega_cluster (0.0) , 
  Z_cluster_charge_potential (0.0) , 
  E_intrinsic_cluster (0.0) , 
  E_CM_HO_max (0) , 
  potential_cluster_CM_derivative_R (0.0)
{
  allocate (is_it_CM_HO_basis , input_data , prot_data , neut_data , inter_data_basis , cluster_data_helper , ic);
}


cluster_data::cluster_data (
			    const bool is_there_cout , 
			    const class input_data_str &input_data , 
			    const class nucleons_data &prot_data , 
			    const class nucleons_data &neut_data , 
			    const class interaction_class &inter_data_basis,
			    const unsigned int eigenset_index , 
			    const unsigned int eigenset_vector_number) :
  H_potential (NO_POTENTIAL) , 
  basis_potential (NO_POTENTIAL) ,  
  is_it_Lowdin (false) ,
  cluster (NO_PARTICLE) ,
  S_matrix_pole (false) ,
  Z_cluster (0) , 
  N_cluster (0) , 
  A_cluster (0) , 
  A_composite (0) , 
  BP_intrinsic (2) , 
  J_intrinsic (0.0) , 
  vector_index_intrinsic (0) , 
  Lmax (0) , 
  Nmax (0) , 
  cluster_mass_for_calc (0) , 
  N_bef_R_GL (0) , 
  N_aft_R_GL (0) , 
  N_bef_R_uniform (0) , 
  N_aft_R_uniform (0) ,
  Nk_momentum_GL (0) , 
  Nk_momentum_uniform (0) ,  
  R (0.0) , 
  step_bef_R_uniform (0.0) , 
  R_real_max (0.0) , 
  kmax_momentum (0.0) , 
  R_Fermi_momentum (0.0) , 
  R_charge (0.0) , 
  nucleus_mass (0.0) , 
  R_cut_function (0.0) , 
  d_cut_function (0.0) , 
  b_lab_cluster (0.0) , 
  hbar_omega_cluster (0.0) , 
  Z_cluster_charge_potential (0.0) , 
  E_intrinsic_cluster (0.0) , 
  E_CM_HO_max (0) , 
  potential_cluster_CM_derivative_R (0.0)
{
  allocate (is_there_cout , input_data , prot_data , neut_data , inter_data_basis , eigenset_index , eigenset_vector_number);
}





cluster_data::cluster_data (const class cluster_data &X) :
  H_potential (NO_POTENTIAL) , 
  basis_potential (NO_POTENTIAL) ,  
  is_it_Lowdin (false) ,
  cluster (NO_PARTICLE) ,
  S_matrix_pole (false) ,
  Z_cluster (0) , 
  N_cluster (0) , 
  A_cluster (0) , 
  A_composite (0) , 
  BP_intrinsic (2) , 
  J_intrinsic (0.0) , 
  vector_index_intrinsic (0) , 
  Lmax (0) , 
  Nmax (0) , 
  cluster_mass_for_calc (0) , 
  N_bef_R_GL (0) , 
  N_aft_R_GL (0) , 
  N_bef_R_uniform (0) , 
  N_aft_R_uniform (0) ,
  Nk_momentum_GL (0) , 
  Nk_momentum_uniform (0) ,  
  R (0.0) , 
  step_bef_R_uniform (0.0) , 
  R_real_max (0.0) , 
  kmax_momentum (0.0) , 
  R_Fermi_momentum (0.0) , 
  R_charge (0.0) , 
  nucleus_mass (0.0) , 
  R_cut_function (0.0) , 
  d_cut_function (0.0) , 
  b_lab_cluster (0.0) , 
  hbar_omega_cluster (0.0) , 
  Z_cluster_charge_potential (0.0) , 
  E_intrinsic_cluster (0.0) , 
  E_CM_HO_max (0) , 
  potential_cluster_CM_derivative_R (0.0)
{
  allocate_fill (X);
}







void cluster_data::allocate (
			     const bool is_there_cout , 
			     const bool is_it_GSM_basis , 
			     const bool is_it_CM_HO_basis , 
			     const class input_data_str &input_data , 
			     const class nucleons_data &prot_data , 
			     const class nucleons_data &neut_data , 
			     const class interaction_class &inter_data_basis , 
			     const unsigned int ic)
{
  if (cluster != NO_PARTICLE)
    error_message_print_abort ("cluster_data cannot be initialized twice in cluster_data::allocate (1)");

  const bool is_it_cluster_CM_HO_basis_calculation = input_data.get_is_it_cluster_CM_HO_basis_calculation ();

  if (is_it_cluster_CM_HO_basis_calculation)
    error_message_print_abort ("This cluster_data::allocate (1) function can be called only if is_it_cluster_CM_HO_basis_calculation is false");

  const int Z = input_data.get_Z ();

  const double prot_mass_for_calc = prot_data.get_effective_mass_for_calc ();
  const double neut_mass_for_calc = neut_data.get_effective_mass_for_calc ();

  const double b_lab = input_data.get_b_lab ();

  const class array<enum particle_type> &CC_cluster_tab = input_data.get_CC_cluster_tab ();

  const class array<int> &CC_Lmax_cluster_CM_tab = input_data.get_CC_Lmax_cluster_CM_tab ();

  H_potential = input_data.get_H_potential ();

  basis_potential = (is_it_CM_HO_basis) ? (HO_POTENTIAL) : (INTERPOLATED_POTENTIAL);

  is_it_Lowdin = input_data.get_is_it_Lowdin ();
  
  cluster = CC_cluster_tab(ic); 

  S_matrix_pole = S_matrix_pole_projectile_determine (cluster);

  Z_cluster = Z_projectile_determine (cluster); 
  N_cluster = N_projectile_determine (cluster); 
  A_cluster = A_projectile_determine (cluster); 

  A_composite = input_data.get_A (); 

  BP_intrinsic = BP_intrinsic_projectile_determine (cluster); 

  J_intrinsic = J_intrinsic_projectile_determine (cluster); 

  vector_index_intrinsic = vector_index_intrinsic_projectile_determine (cluster); 

  Lmax = CC_Lmax_cluster_CM_tab(ic); 

  Nmax = input_data.Nmax_cluster_determine (ic) + make_int (input_data.N_channels_max_calc ()); 

  cluster_mass_for_calc = mass_projectile_determine (cluster , prot_mass_for_calc , neut_mass_for_calc); 

  N_bef_R_GL = input_data.get_N_bef_R_GL (); 
  N_aft_R_GL = input_data.get_N_aft_R_GL (); 

  N_bef_R_uniform = input_data.get_N_bef_R_uniform (); 
  N_aft_R_uniform = input_data.get_N_aft_R_uniform (); 

  Nk_momentum_GL = input_data.get_Nk_momentum_GL ();

  Nk_momentum_uniform = input_data.get_Nk_momentum_uniform ();
  
  R = input_data.get_R (); 	

  step_bef_R_uniform = input_data.get_step_bef_R_uniform ();

  R_real_max = input_data.get_R_real_max ();
  
  kmax_momentum = input_data.get_kmax_momentum (); 

  R_Fermi_momentum = input_data.get_R_Fermi_momentum (); 

  R_charge = input_data.get_R_charge (); 

  nucleus_mass = input_data.get_nucleus_mass (); 

  R_cut_function = input_data.get_R_cut_function (); 
  d_cut_function = input_data.get_d_cut_function (); 

  b_lab_cluster = b_lab/sqrt (A_cluster);

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);

  const double mass_modif = (!is_it_COSM) ? (-nucleus_mass) : (nucleus_mass);

  const int Lmax_plus_one = Lmax + 1;
  
  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const bool is_it_full_or_partial_storage = is_it_full_or_partial_storage_determine (Hamiltonian_storage);
    
  hbar_omega_cluster = HO_wave_functions::hbar_omega_calc (false , mass_modif , cluster_mass_for_calc , b_lab_cluster);
  
  Z_cluster_charge_potential = Z - Z_cluster; 

  E_intrinsic_cluster = input_data.E_intrinsic_cluster_determine (ic); 

  E_CM_HO_max = input_data.get_E_CM_HO_max ();

  const class nucleons_data &data_for_KKNN = (prot_data.get_N_valence_nucleons () > 0) ? (prot_data) : (neut_data);

  for (unsigned int i = 0 ; i < 5 ; i++)
    {
      V0_KKNN[i] = data_for_KKNN.get_V0_KKNN(i);

      rho_KKNN[i] = data_for_KKNN.get_rho_KKNN(i);
    }
  
  for (unsigned int i = 0 ; i < 3 ; i++)
    {
      Vls_KKNN[i] = data_for_KKNN.get_Vls_KKNN(i);

      rho_ls_KKNN[i] = data_for_KKNN.get_rho_ls_KKNN(i);
    }
  
  N_poles_cluster_CM_tab.allocate (J_intrinsic , Lmax);
  N_poles_cluster_CM_tab = 0;

  Nmin_PCM_cluster_tab.allocate (J_intrinsic , Lmax);
  Nmin_PCM_cluster_tab = 0;

  Nmax_cluster_CM_tab.allocate (J_intrinsic , Lmax);
  Nmax_cluster_CM_tab = 0;

  cluster_CM_S_matrix_poles.allocate (J_intrinsic , Nmax , Lmax);

  cluster_CM_R0_tab.allocate (Lmax_plus_one); 

  cluster_CM_K_tab.allocate (J_intrinsic , Nmax , Lmax);
  cluster_CM_W_tab.allocate (J_intrinsic , Nmax , Lmax);
  cluster_CM_E_tab.allocate (J_intrinsic , Nmax , Lmax);

  cluster_CM_K_tab = SQRT_INFINITE;
  cluster_CM_W_tab = 1.0;
  cluster_CM_E_tab = INFINITE;

  cluster_CM_C0_tab.allocate (J_intrinsic , Nmax , Lmax);
  cluster_CM_C0_tab = 1.0;
  
  cluster_CM_Cplus_tab.allocate (J_intrinsic , Nmax , Lmax);
  cluster_CM_Cplus_tab = 1.0;
  
  potential_cluster_CM_bef_R_tab_uniform.allocate (J_intrinsic , Lmax , N_bef_R_uniform);
  potential_cluster_CM_bef_R_tab_uniform = 0.0;

  potential_cluster_CM_bef_R_tab_GL.allocate (J_intrinsic , Lmax , N_bef_R_GL);
  potential_cluster_CM_bef_R_tab_GL = 0.0;

  potential_cluster_CM_aft_R_tab_GL.allocate (J_intrinsic , Lmax , N_aft_R_GL);
  potential_cluster_CM_aft_R_tab_GL = 0.0;

  potential_cluster_CM_derivative_r0_tab.allocate (J_intrinsic , Lmax);
  potential_cluster_CM_derivative_r0_tab = 0.0;

  cluster_CM_shells.allocate (J_intrinsic , Nmax , Lmax); 

  Nmax_HO_tab.allocate (Lmax_plus_one);

  NCM_HO_max_tab_calc (E_CM_HO_max , Nmax_HO_tab);

  const int Nmax_HO_lab = nmax_calc (Nmax_HO_tab);
  
  const int Nmax_HO_lab_plus_one = Nmax_HO_lab + 1;

  r_bef_R_tab_uniform.allocate (N_bef_R_uniform);

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;

  r_bef_R_tab_GL.allocate (N_bef_R_GL);
  w_bef_R_tab_GL.allocate (N_bef_R_GL);

  HO_wfs_bef_R_tab_GL.allocate  (Nmax_HO_lab_plus_one , Lmax_plus_one , N_bef_R_GL);
  HO_dwfs_bef_R_tab_GL.allocate (Nmax_HO_lab_plus_one , Lmax_plus_one , N_bef_R_GL);

  r_aft_R_tab_GL.allocate (N_aft_R_GL);
  w_aft_R_tab_GL.allocate (N_aft_R_GL);

  HO_wfs_aft_R_tab_GL.allocate  (Nmax_HO_lab_plus_one , Lmax_plus_one , N_aft_R_GL);
  HO_dwfs_aft_R_tab_GL.allocate (Nmax_HO_lab_plus_one , Lmax_plus_one , N_aft_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R          , r_bef_R_tab_GL , w_bef_R_tab_GL);
  Gauss_Legendre::abscissas_weights_tables_calc (R   , R_real_max , r_aft_R_tab_GL , w_aft_R_tab_GL);

  HO_wave_functions::HO_3D::u_du_r_tables_calc (b_lab_cluster , r_bef_R_tab_GL , HO_wfs_bef_R_tab_GL , HO_dwfs_bef_R_tab_GL);
  HO_wave_functions::HO_3D::u_du_r_tables_calc (b_lab_cluster , r_aft_R_tab_GL , HO_wfs_aft_R_tab_GL , HO_dwfs_aft_R_tab_GL);

  HO_overlaps_cluster_CM.allocate (J_intrinsic , Nmax , Lmax);
  
  HO_overlaps_Fermi_cluster_CM.allocate (J_intrinsic , Nmax , Lmax);

  PCM_matrices_cluster.allocate (J_intrinsic , Lmax);

  if (is_it_CM_HO_basis )
    HO_CM_basis_data_fill (input_data , ic);
  else
    contours_data_fill (input_data , ic);

  for (int L = 0 ; L <= Lmax ; L++)
    {
      const double J_min = abs (J_intrinsic - L);
      const double J_max = J_intrinsic + L;
      
      const int J_number = make_int (J_max - J_min) + 1;

      const int Nmax_HO_L = Nmax_HO_tab(L);

      const int Nmax_HO_L_plus_one = Nmax_HO_L + 1;

      for (int J_index = 0 ; J_index < J_number ; J_index++)
	{
	  const double J = J_min + J_index;
	  
	  const int Nmax_LJ = Nmax_cluster_CM_tab(L , J);

	  PCM_matrices_cluster(L , J).allocate (Nmax_HO_L_plus_one , Nmax_HO_L_plus_one);

	  for (int N = 0 ; N <= Nmax_LJ ; N++)
	    {
	      HO_overlaps_cluster_CM(N , L , J).allocate (Nmax_HO_L_plus_one);

	      HO_overlaps_Fermi_cluster_CM(N , L , J).allocate (Nmax_HO_L_plus_one);
	    }
	}
    }

  const class array<double> &prot_R0_tab = prot_data.get_R0_core_potential_tab ();
  const class array<double> &neut_R0_tab = neut_data.get_R0_core_potential_tab ();

  if (Z_cluster == 0)
    {
      for (int L = 0 ; L <= Lmax ; L++) cluster_CM_R0_tab(L) = neut_R0_tab(L);
    }
  else if (N_cluster == 0)
    {
      for (int L = 0 ; L <= Lmax ; L++) cluster_CM_R0_tab(L) = prot_R0_tab(L);
    }
  else
    {
      const double Z_over_A_cluster = Z_cluster/static_cast<double> (A_cluster);
      const double N_over_A_cluster = N_cluster/static_cast<double> (A_cluster);

      for (int L = 0 ; L <= Lmax ; L++) cluster_CM_R0_tab(L) = Z_over_A_cluster*prot_R0_tab(L) + N_over_A_cluster*neut_R0_tab(L);
    }

  cluster_prot_data.initialize_constants_from_other_nucleus (true , Z_cluster , N_cluster , cluster_mass_for_calc , prot_data);
  cluster_neut_data.initialize_constants_from_other_nucleus (true , Z_cluster , N_cluster , cluster_mass_for_calc , neut_data);

  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();

  const class array<class array<class JT_coupled_TBME> > dummy_array_JT_coupled_TBME;

  cluster_prot_data_HO.initialize_constants_from_other_nucleus (true , Z_cluster , N_cluster , cluster_mass_for_calc , prot_data);
  cluster_neut_data_HO.initialize_constants_from_other_nucleus (true , Z_cluster , N_cluster , cluster_mass_for_calc , neut_data);
  
  if (Z_cluster > 0)
    {	
      cluster_prot_data.alloc_copy_one_body_data_tables_E_min_max_hw (prot_data);

      cluster_prot_data_HO.alloc_fill_one_body_data_tables_E_min_max_hw_HO_expansion (input_data);

      if (is_it_GSM_basis)
	{
	  configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (is_there_cout , false , truncation_hw , truncation_ph , false, cluster_prot_data_HO);

	  SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (is_there_cout , false , false , false , cluster_prot_data_HO , false);

	  OBMEs_TBMEs::HO_wfs::OBMEs_alloc_calc (input_data , inter_data_basis , cluster_prot_data_HO);

	  configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (is_there_cout , false , truncation_hw , truncation_ph , false , cluster_prot_data);

	  SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (is_there_cout , false , false , false, cluster_prot_data , false);

	  class TBMEs_class &prot_TBMEs = cluster_prot_data.get_TBMEs ();

	  if (Z_cluster >= 2) prot_TBMEs.allocate_fill (prot_data.get_TBMEs ());

	  cluster_prot_data.configuration_SD_in_in_space_BPin_iMin_tables_init (true);

	  cluster_prot_data.configuration_SD_inter_to_include_tables_init (true);

	  cluster_prot_data.configuration_SD_out_in_space_BPout_iMout_tables_init (true);
	  
	  cluster_prot_data_HO.configuration_SD_in_in_space_BPin_iMin_tables_init (true);

	  cluster_prot_data_HO.configuration_SD_inter_to_include_tables_init (true);

	  cluster_prot_data_HO.configuration_SD_out_in_space_BPout_iMout_tables_init (true);

	  if (is_it_full_or_partial_storage)
	    {
	      configuration_SD_in_space_one_jump_in_to_out::one_jump_tables_alloc_calc_pp_nn (is_there_cout , false , false , false , true , truncation_hw , truncation_ph , cluster_prot_data);	  

	      configuration_SD_in_space_one_jump_in_to_out::one_jump_tables_alloc_calc_pp_nn (is_there_cout , true  , false , false , true , truncation_hw , truncation_ph , cluster_prot_data_HO);
	    }
	  
	  configuration_SD_in_space_one_jump_out_to_in::one_jump_tables_alloc_calc_pp_nn (is_there_cout , false , false , false , true , truncation_hw , truncation_ph , cluster_prot_data);	  

	  configuration_SD_in_space_one_jump_out_to_in::one_jump_tables_alloc_calc_pp_nn (is_there_cout , true  , false , false , true , truncation_hw , truncation_ph , cluster_prot_data_HO);	  
	}
    }

  if (N_cluster > 0)
    {
      cluster_neut_data.alloc_copy_one_body_data_tables_E_min_max_hw (neut_data);

      cluster_neut_data_HO.alloc_fill_one_body_data_tables_E_min_max_hw_HO_expansion (input_data);

      if (is_it_GSM_basis)
	{
	  configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (is_there_cout , false , truncation_hw , truncation_ph , false , cluster_neut_data_HO);

	  SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (is_there_cout , false , false , false , cluster_neut_data_HO , false);

	  OBMEs_TBMEs::HO_wfs::OBMEs_alloc_calc (input_data , inter_data_basis , cluster_neut_data_HO);

	  configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (is_there_cout , false , truncation_hw , truncation_ph , false , cluster_neut_data);

	  SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (is_there_cout , false , false , false , cluster_neut_data , false);

	  class TBMEs_class &neut_TBMEs = cluster_neut_data.get_TBMEs ();

	  if (N_cluster >= 2) neut_TBMEs.allocate_fill (neut_data.get_TBMEs ());

	  cluster_neut_data.configuration_SD_in_in_space_BPin_iMin_tables_init (true);

	  cluster_neut_data.configuration_SD_inter_to_include_tables_init (true);

	  cluster_neut_data.configuration_SD_out_in_space_BPout_iMout_tables_init (true);
	  
	  cluster_neut_data_HO.configuration_SD_in_in_space_BPin_iMin_tables_init (true);

	  cluster_neut_data_HO.configuration_SD_inter_to_include_tables_init (true);

	  cluster_neut_data_HO.configuration_SD_out_in_space_BPout_iMout_tables_init (true);

	  if (is_it_full_or_partial_storage)
	    {
	      configuration_SD_in_space_one_jump_in_to_out::one_jump_tables_alloc_calc_pp_nn (is_there_cout , false , false , false , true , truncation_hw , truncation_ph , cluster_neut_data);	  

	      configuration_SD_in_space_one_jump_in_to_out::one_jump_tables_alloc_calc_pp_nn (is_there_cout , true  , false , false , true , truncation_hw , truncation_ph , cluster_neut_data_HO);
	    }
	  
	  configuration_SD_in_space_one_jump_out_to_in::one_jump_tables_alloc_calc_pp_nn (is_there_cout , false , false , false , true , truncation_hw , truncation_ph , cluster_neut_data);	  

	  configuration_SD_in_space_one_jump_out_to_in::one_jump_tables_alloc_calc_pp_nn (is_there_cout , true  , false , false , true , truncation_hw , truncation_ph , cluster_neut_data_HO);
	}
    }

  for (int L = 0 ; L <= Lmax ; L++)
    {
      const double J_min = abs (J_intrinsic - L);
      const double J_max = J_intrinsic + L;
      
      const int J_number = make_int (J_max - J_min) + 1;

      for (int J_index = 0 ; J_index < J_number ; J_index++)
	{
	  const double J = J_min + J_index;

	  cluster_CM_potential_tables_calc (L , J);
	}
    }

  const class Coulomb_potential_class Coulomb_potential(false , cluster , Z_cluster_charge_potential , NADA);

  potential_cluster_CM_derivative_R = Coulomb_potential.point_potential_derivative_calc (R);
}







void cluster_data::allocate (
			     const bool is_it_CM_HO_basis , 
			     const class input_data_str &input_data , 
			     const class nucleons_data &prot_data , 
			     const class nucleons_data &neut_data , 
			     const class interaction_class &inter_data_basis , 
			     const class cluster_data &cluster_data_helper ,
			     const unsigned int ic)
{
  if (cluster != NO_PARTICLE)
    error_message_print_abort ("cluster_data cannot be initialized twice in cluster_data::allocate (2)");

  const bool is_it_cluster_CM_HO_basis_calculation = input_data.get_is_it_cluster_CM_HO_basis_calculation ();

  if (is_it_cluster_CM_HO_basis_calculation)
    error_message_print_abort ("This cluster_data::allocate (2) function can be called only if is_it_cluster_CM_HO_basis_calculation is false");

  const class array<enum particle_type> &CC_cluster_tab = input_data.get_CC_cluster_tab ();

  is_it_Lowdin = input_data.get_is_it_Lowdin ();
  
  cluster = CC_cluster_tab(ic); 

  Z_cluster = Z_projectile_determine (cluster); 
  N_cluster = N_projectile_determine (cluster); 
  A_cluster = A_projectile_determine (cluster); 

  const int Z_cluster_helper = cluster_data_helper.get_Z_cluster ();
  const int N_cluster_helper = cluster_data_helper.get_N_cluster ();

  const enum particle_type helper_cluster = cluster_data_helper.get_cluster ();

  if ((Z_cluster_helper != Z_cluster) || (N_cluster_helper != N_cluster))
    error_message_print_abort ("Improper helper cluster in cluster_data::allocate (2): cluster:" + make_string<enum particle_type> (cluster) + " helper cluster:" + make_string<enum particle_type> (helper_cluster));

  const int Z = input_data.get_Z ();

  const double prot_mass_for_calc = prot_data.get_effective_mass_for_calc ();
  const double neut_mass_for_calc = neut_data.get_effective_mass_for_calc ();

  const double b_lab = input_data.get_b_lab ();

  const class array<int> &CC_Lmax_cluster_CM_tab = input_data.get_CC_Lmax_cluster_CM_tab ();

  H_potential = input_data.get_H_potential ();

  basis_potential = (is_it_CM_HO_basis) ? (HO_POTENTIAL) : (INTERPOLATED_POTENTIAL);

  S_matrix_pole = S_matrix_pole_projectile_determine (cluster);

  A_composite = input_data.get_A (); 

  BP_intrinsic = BP_intrinsic_projectile_determine (cluster); 

  J_intrinsic = J_intrinsic_projectile_determine (cluster); 

  vector_index_intrinsic = vector_index_intrinsic_projectile_determine (cluster); 

  Lmax = CC_Lmax_cluster_CM_tab(ic); 

  Nmax = input_data.Nmax_cluster_determine (ic) + make_int (input_data.N_channels_max_calc ()); 

  cluster_mass_for_calc = mass_projectile_determine (cluster , prot_mass_for_calc , neut_mass_for_calc); 

  N_bef_R_GL = input_data.get_N_bef_R_GL (); 
  N_aft_R_GL = input_data.get_N_aft_R_GL (); 

  N_bef_R_uniform = input_data.get_N_bef_R_uniform (); 
  N_aft_R_uniform = input_data.get_N_aft_R_uniform (); 

  Nk_momentum_GL = input_data.get_Nk_momentum_GL ();

  Nk_momentum_uniform = input_data.get_Nk_momentum_uniform ();
  
  R = input_data.get_R (); 	

  step_bef_R_uniform = input_data.get_step_bef_R_uniform ();

  R_real_max = input_data.get_R_real_max (); 

  kmax_momentum = input_data.get_kmax_momentum ();

  R_Fermi_momentum = input_data.get_R_Fermi_momentum ();
  
  R_charge = input_data.get_R_charge (); 

  nucleus_mass = input_data.get_nucleus_mass (); 

  R_cut_function = input_data.get_R_cut_function (); 
  d_cut_function = input_data.get_d_cut_function (); 

  b_lab_cluster = b_lab/sqrt (A_cluster);

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);

  const double mass_modif = (!is_it_COSM) ? (-nucleus_mass) : (nucleus_mass);

  const int Lmax_plus_one = Lmax + 1;
  
  hbar_omega_cluster = HO_wave_functions::hbar_omega_calc (false , mass_modif , cluster_mass_for_calc , b_lab_cluster);
  
  Z_cluster_charge_potential = Z - Z_cluster; 

  E_intrinsic_cluster = input_data.E_intrinsic_cluster_determine (ic); 

  E_CM_HO_max = input_data.get_E_CM_HO_max ();

  const class nucleons_data &data_for_KKNN = (prot_data.get_N_valence_nucleons () > 0) ? (prot_data) : (neut_data);

  for (unsigned int i = 0 ; i < 5 ; i++)
    {
      V0_KKNN[i] = data_for_KKNN.get_V0_KKNN(i);

      rho_KKNN[i] = data_for_KKNN.get_rho_KKNN(i);
    }
  
  for (unsigned int i = 0 ; i < 3 ; i++)
    {
      Vls_KKNN[i] = data_for_KKNN.get_Vls_KKNN(i);

      rho_ls_KKNN[i] = data_for_KKNN.get_rho_ls_KKNN(i);
    }
  
  N_poles_cluster_CM_tab.allocate (J_intrinsic , Lmax);
  N_poles_cluster_CM_tab = 0;

  Nmin_PCM_cluster_tab.allocate (J_intrinsic , Lmax);
  Nmin_PCM_cluster_tab = 0;

  Nmax_cluster_CM_tab.allocate (J_intrinsic , Lmax);
  Nmax_cluster_CM_tab = 0;

  cluster_CM_S_matrix_poles.allocate (J_intrinsic , Nmax , Lmax);

  cluster_CM_R0_tab.allocate (Lmax_plus_one); 

  cluster_CM_K_tab.allocate (J_intrinsic , Nmax , Lmax);
  cluster_CM_W_tab.allocate (J_intrinsic , Nmax , Lmax);
  cluster_CM_E_tab.allocate (J_intrinsic , Nmax , Lmax);

  cluster_CM_K_tab = SQRT_INFINITE;
  cluster_CM_W_tab = 1.0;
  cluster_CM_E_tab = INFINITE;

  cluster_CM_C0_tab.allocate (J_intrinsic , Nmax , Lmax);
  cluster_CM_C0_tab = 1.0;
  
  cluster_CM_Cplus_tab.allocate (J_intrinsic , Nmax , Lmax);
  cluster_CM_Cplus_tab = 1.0;
  
  potential_cluster_CM_bef_R_tab_uniform.allocate (J_intrinsic , Lmax , N_bef_R_uniform);
  potential_cluster_CM_bef_R_tab_uniform = 0.0;

  potential_cluster_CM_bef_R_tab_GL.allocate (J_intrinsic , Lmax , N_bef_R_GL);
  potential_cluster_CM_bef_R_tab_GL = 0.0;

  potential_cluster_CM_aft_R_tab_GL.allocate (J_intrinsic , Lmax , N_aft_R_GL);
  potential_cluster_CM_aft_R_tab_GL = 0.0;

  potential_cluster_CM_derivative_r0_tab.allocate (J_intrinsic , Lmax);
  potential_cluster_CM_derivative_r0_tab = 0.0;

  cluster_CM_shells.allocate (J_intrinsic , Nmax , Lmax); 

  Nmax_HO_tab.allocate (Lmax_plus_one);

  NCM_HO_max_tab_calc (E_CM_HO_max , Nmax_HO_tab);

  const int Nmax_HO_lab = nmax_calc (Nmax_HO_tab);
  const int Nmax_HO_lab_plus_one = Nmax_HO_lab + 1;

  r_bef_R_tab_uniform.allocate (N_bef_R_uniform);

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;

  r_bef_R_tab_GL.allocate (N_bef_R_GL);
  w_bef_R_tab_GL.allocate (N_bef_R_GL);

  HO_wfs_bef_R_tab_GL.allocate  (Nmax_HO_lab_plus_one , Lmax_plus_one , N_bef_R_GL);
  HO_dwfs_bef_R_tab_GL.allocate (Nmax_HO_lab_plus_one , Lmax_plus_one , N_bef_R_GL);

  r_aft_R_tab_GL.allocate (N_aft_R_GL);
  w_aft_R_tab_GL.allocate (N_aft_R_GL);

  HO_wfs_aft_R_tab_GL.allocate  (Nmax_HO_lab_plus_one , Lmax_plus_one , N_aft_R_GL);
  HO_dwfs_aft_R_tab_GL.allocate (Nmax_HO_lab_plus_one , Lmax_plus_one , N_aft_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R          , r_bef_R_tab_GL , w_bef_R_tab_GL);
  Gauss_Legendre::abscissas_weights_tables_calc (R   , R_real_max , r_aft_R_tab_GL , w_aft_R_tab_GL);

  HO_wave_functions::HO_3D::u_du_r_tables_calc (b_lab_cluster , r_bef_R_tab_GL , HO_wfs_bef_R_tab_GL , HO_dwfs_bef_R_tab_GL);
  HO_wave_functions::HO_3D::u_du_r_tables_calc (b_lab_cluster , r_aft_R_tab_GL , HO_wfs_aft_R_tab_GL , HO_dwfs_aft_R_tab_GL);

  HO_overlaps_cluster_CM.allocate (J_intrinsic , Nmax , Lmax);
  
  HO_overlaps_Fermi_cluster_CM.allocate (J_intrinsic , Nmax , Lmax);

  PCM_matrices_cluster.allocate (J_intrinsic , Lmax);

  if (is_it_CM_HO_basis )
    HO_CM_basis_data_fill (input_data , ic);
  else
    contours_data_fill (input_data , ic);

  for (int L = 0 ; L <= Lmax ; L++)
    {
      const double J_min = abs (J_intrinsic - L);
      const double J_max = J_intrinsic + L;
      
      const int J_number = make_int (J_max - J_min) + 1;

      const int Nmax_HO_L = Nmax_HO_tab(L);

      const int Nmax_HO_L_plus_one = Nmax_HO_L + 1;

      for (int J_index = 0 ; J_index < J_number ; J_index++)
	{
	  const double J = J_min + J_index;
	  
	  const int Nmax_LJ = Nmax_cluster_CM_tab(L , J);

	  PCM_matrices_cluster(L , J).allocate (Nmax_HO_L_plus_one , Nmax_HO_L_plus_one);

	  for (int N = 0 ; N <= Nmax_LJ ; N++)
	    {
	      HO_overlaps_cluster_CM(N , L , J).allocate (Nmax_HO_L_plus_one);

	      HO_overlaps_Fermi_cluster_CM(N , L , J).allocate (Nmax_HO_L_plus_one);
	    }
	}
    }

  const class array<double> &prot_R0_tab = prot_data.get_R0_core_potential_tab ();
  const class array<double> &neut_R0_tab = neut_data.get_R0_core_potential_tab ();

  if (Z_cluster == 0)
    {
      for (int L = 0 ; L <= Lmax ; L++) cluster_CM_R0_tab(L) = neut_R0_tab(L);
    }
  else if (N_cluster == 0)
    {
      for (int L = 0 ; L <= Lmax ; L++) cluster_CM_R0_tab(L) = prot_R0_tab(L);
    }
  else
    {
      const double Z_over_A_cluster = Z_cluster/static_cast<double> (A_cluster);
      const double N_over_A_cluster = N_cluster/static_cast<double> (A_cluster);

      for (int L = 0 ; L <= Lmax ; L++) cluster_CM_R0_tab(L) = Z_over_A_cluster*prot_R0_tab(L) + N_over_A_cluster*neut_R0_tab(L);
    }

  const class nucleons_data &cluster_prot_data_helper = cluster_data_helper.get_cluster_prot_data ();
  const class nucleons_data &cluster_neut_data_helper = cluster_data_helper.get_cluster_neut_data ();

  const class nucleons_data &cluster_prot_data_HO_helper = cluster_data_helper.get_cluster_prot_data_HO ();
  const class nucleons_data &cluster_neut_data_HO_helper = cluster_data_helper.get_cluster_neut_data_HO ();

  cluster_prot_data.allocate_fill (cluster_prot_data_helper);
  cluster_neut_data.allocate_fill (cluster_neut_data_helper);
  
  cluster_prot_data_HO.allocate_fill (cluster_prot_data_HO_helper);
  cluster_neut_data_HO.allocate_fill (cluster_neut_data_HO_helper);

  for (int L = 0 ; L <= Lmax ; L++)
    {
      const double J_min = abs (J_intrinsic - L);
      const double J_max = J_intrinsic + L;
      
      const int J_number = make_int (J_max - J_min) + 1;

      for (int J_index = 0 ; J_index < J_number ; J_index++)
	{
	  const double J = J_min + J_index;

	  cluster_CM_potential_tables_calc (L , J);
	}
    }

  const class Coulomb_potential_class Coulomb_potential(false , cluster , Z_cluster_charge_potential , NADA);

  potential_cluster_CM_derivative_R = Coulomb_potential.point_potential_derivative_calc (R);
}








void cluster_data::allocate (
			     const bool is_there_cout , 
			     const class input_data_str &input_data , 
			     const class nucleons_data &prot_data , 
			     const class nucleons_data &neut_data , 
			     const class interaction_class &inter_data_basis, 
			     const unsigned int eigenset_index , 
			     const unsigned int eigenset_vector_number)
{
  if (cluster != NO_PARTICLE)
    error_message_print_abort ("cluster_data cannot be initialized twice in cluster_data::allocate (3)");

  const bool is_it_cluster_CM_HO_basis_calculation = input_data.get_is_it_cluster_CM_HO_basis_calculation ();

  if (!is_it_cluster_CM_HO_basis_calculation)
    error_message_print_abort ("This cluster_data::allocate (3) function can be called only if is_it_cluster_CM_HO_basis_calculation is true");

  const int Z = input_data.get_Z ();

  const double prot_mass_for_calc = prot_data.get_effective_mass_for_calc ();
  const double neut_mass_for_calc = neut_data.get_effective_mass_for_calc ();

  const double b_lab = input_data.get_b_lab ();

  const class array<class correlated_state_str> &PSI_qn_from_file_tab = input_data.get_PSI_qn_from_file_tab ();

  const class correlated_state_str &PSI_cluster_qn = PSI_qn_from_file_tab(eigenset_index , eigenset_vector_number);
  
  H_potential = HO_POTENTIAL;

  basis_potential = HO_POTENTIAL;

  Z_cluster = input_data.get_Z ();
  N_cluster = input_data.get_N ();
  A_cluster = input_data.get_A ();

  is_it_Lowdin = input_data.get_is_it_Lowdin ();
  
  cluster = projectile_determine (Z_cluster , N_cluster);

  S_matrix_pole = S_matrix_pole_projectile_determine (cluster);

  BP_intrinsic = BP_intrinsic_projectile_determine (cluster);

  J_intrinsic = J_intrinsic_projectile_determine (cluster);

  vector_index_intrinsic = vector_index_intrinsic_projectile_determine (cluster);

  if ((BP_intrinsic != PSI_cluster_qn.get_BP ()) || (rint (J_intrinsic - PSI_cluster_qn.get_J ()) != 0.0) || (vector_index_intrinsic != PSI_cluster_qn.get_vector_index ()))
    error_message_print_abort ("Calculations of CM+intrinsic clusters with the HO basis using A+[CM-HO] can be used only with cluster ground states in cluster_data::allocate (3)");

  Lmax = input_data.get_CC_Lmax_all ();

  cluster_mass_for_calc = mass_projectile_determine (cluster , prot_mass_for_calc , neut_mass_for_calc); 

  N_bef_R_GL = input_data.get_N_bef_R_GL (); 
  N_aft_R_GL = input_data.get_N_aft_R_GL (); 

  N_bef_R_uniform = input_data.get_N_bef_R_uniform (); 
  N_aft_R_uniform = input_data.get_N_aft_R_uniform (); 

  Nk_momentum_GL = input_data.get_Nk_momentum_GL ();

  Nk_momentum_uniform = input_data.get_Nk_momentum_uniform ();
  
  R = input_data.get_R (); 	

  step_bef_R_uniform = input_data.get_step_bef_R_uniform ();

  R_real_max = input_data.get_R_real_max (); 

  kmax_momentum = input_data.get_kmax_momentum ();

  R_Fermi_momentum = input_data.get_R_Fermi_momentum ();
  
  R_charge = input_data.get_R_charge (); 

  nucleus_mass = input_data.get_nucleus_mass (); 

  R_cut_function = input_data.get_R_cut_function (); 
  d_cut_function = input_data.get_d_cut_function (); 

  b_lab_cluster = b_lab/sqrt (A_cluster); 

  hbar_omega_cluster = HO_wave_functions::hbar_omega_calc (false , 0.0 , A_cluster , b_lab_cluster); 

  Z_cluster_charge_potential = Z - Z_cluster; 

  E_CM_HO_max = input_data.get_E_CM_HO_max ();

  const class nucleons_data &data_for_KKNN = (prot_data.get_N_valence_nucleons () > 0) ? (prot_data) : (neut_data);

  for (unsigned int i = 0 ; i < 5 ; i++)
    {
      V0_KKNN[i] = data_for_KKNN.get_V0_KKNN(i);

      rho_KKNN[i] = data_for_KKNN.get_rho_KKNN(i);
    }
  
  for (unsigned int i = 0 ; i < 3 ; i++)
    {
      Vls_KKNN[i] = data_for_KKNN.get_Vls_KKNN(i);

      rho_ls_KKNN[i] = data_for_KKNN.get_rho_ls_KKNN(i);
    }
  
  Nmax_HO_tab.allocate (Lmax + 1);

  NCM_HO_max_tab_calc (E_CM_HO_max , Nmax_HO_tab);

  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();

  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const bool is_it_full_or_partial_storage = is_it_full_or_partial_storage_determine (Hamiltonian_storage);

  const class array<class array<class JT_coupled_TBME> > dummy_array_JT_coupled_TBME;

  cluster_prot_data_HO.initialize_constants_from_other_nucleus (true , Z_cluster , N_cluster , cluster_mass_for_calc , prot_data);
  cluster_neut_data_HO.initialize_constants_from_other_nucleus (true , Z_cluster , N_cluster , cluster_mass_for_calc , neut_data);
  
  if (Z_cluster > 0)
    {	
      cluster_prot_data_HO.alloc_fill_one_body_data_tables_E_min_max_hw_HO_expansion (input_data);

      configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (is_there_cout , false , truncation_hw , truncation_ph , false , cluster_prot_data_HO);
      
      SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (is_there_cout , false , false , false , cluster_prot_data_HO , false);

      OBMEs_TBMEs::HO_wfs::OBMEs_alloc_calc (input_data , inter_data_basis , cluster_prot_data_HO);

      cluster_prot_data_HO.configuration_SD_in_in_space_BPin_iMin_tables_init (true);

      cluster_prot_data_HO.configuration_SD_inter_to_include_tables_init (true);

      cluster_prot_data_HO.configuration_SD_out_in_space_BPout_iMout_tables_init (true);
      
      if (is_it_full_or_partial_storage)
	configuration_SD_in_space_one_jump_in_to_out::one_jump_tables_alloc_calc_pp_nn (is_there_cout , true , false , false , true , truncation_hw , truncation_ph , cluster_prot_data_HO);

      configuration_SD_in_space_one_jump_out_to_in::one_jump_tables_alloc_calc_pp_nn (is_there_cout , false , false , false , true , truncation_hw , truncation_ph , cluster_prot_data_HO);
    }
      
  if (N_cluster > 0)
    {
      cluster_neut_data_HO.alloc_fill_one_body_data_tables_E_min_max_hw_HO_expansion (input_data);

      configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (is_there_cout , false , truncation_hw , truncation_ph , false , cluster_neut_data_HO);

      SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (is_there_cout , false , false , false , cluster_neut_data_HO , false);

      OBMEs_TBMEs::HO_wfs::OBMEs_alloc_calc (input_data , inter_data_basis , cluster_neut_data_HO);

      cluster_neut_data_HO.configuration_SD_in_in_space_BPin_iMin_tables_init (true);

      cluster_neut_data_HO.configuration_SD_inter_to_include_tables_init (true);

      cluster_neut_data_HO.configuration_SD_out_in_space_BPout_iMout_tables_init (true);
      
      if (is_it_full_or_partial_storage)
	configuration_SD_in_space_one_jump_in_to_out::one_jump_tables_alloc_calc_pp_nn (is_there_cout , true , false , false , true , truncation_hw , truncation_ph , cluster_neut_data_HO);

      configuration_SD_in_space_one_jump_out_to_in::one_jump_tables_alloc_calc_pp_nn (is_there_cout , false , false , false , true , truncation_hw , truncation_ph , cluster_neut_data_HO);
    }

  const enum space_type space = space_determine (Z_cluster , N_cluster);
	
  const int n_scat_max = input_data.get_n_scat_max ();
  	
  const unsigned int J_index_max = J_index_max_calc (space , cluster_prot_data_HO , cluster_neut_data_HO);

  class array<unsigned long int> dimensions_good_J(2 , n_scat_max + 1 , J_index_max + 1);

  J_total_space_dimensions_calc_print (true , false , input_data , cluster_prot_data_HO , cluster_neut_data_HO , dimensions_good_J);
}









void cluster_data::allocate_fill (const class cluster_data &X)
{
  if (cluster != NO_PARTICLE)
    error_message_print_abort ("cluster_data cannot be initialized twice in cluster_data::allocate_fill");

  H_potential = X.H_potential; 

  basis_potential = X.basis_potential;

  is_it_Lowdin = X.is_it_Lowdin;
  
  cluster = X.cluster;

  S_matrix_pole = X.S_matrix_pole;

  Z_cluster = X.Z_cluster;
  N_cluster = X.N_cluster;
  A_cluster = X.A_cluster;

  A_composite = X.A_composite; 

  BP_intrinsic = X.BP_intrinsic;

  J_intrinsic = X.J_intrinsic;

  vector_index_intrinsic = X.vector_index_intrinsic;

  Lmax = X.Lmax;
  Nmax = X.Nmax;

  cluster_mass_for_calc = X.cluster_mass_for_calc;

  N_bef_R_GL = X.N_bef_R_GL; 
  N_aft_R_GL = X.N_aft_R_GL; 

  N_bef_R_uniform = X.N_bef_R_uniform; 
  N_aft_R_uniform = X.N_aft_R_uniform; 

  Nk_momentum_GL = X.Nk_momentum_GL;

  Nk_momentum_uniform = X.Nk_momentum_uniform;
  
  R = X.R; 	

  step_bef_R_uniform = X.step_bef_R_uniform;

  R_real_max = X.R_real_max; 

  kmax_momentum = X.kmax_momentum;

  R_Fermi_momentum = X.R_Fermi_momentum;
  
  R_charge = X.R_charge; 

  nucleus_mass = X.nucleus_mass; 

  R_cut_function = X.R_cut_function; 
  d_cut_function = X.d_cut_function; 

  b_lab_cluster = X.b_lab_cluster;

  hbar_omega_cluster = X.hbar_omega_cluster;

  Z_cluster_charge_potential = X.Z_cluster_charge_potential;

  E_intrinsic_cluster = X.E_intrinsic_cluster;

  E_CM_HO_max = X.E_CM_HO_max;

  potential_cluster_CM_derivative_R = X.potential_cluster_CM_derivative_R;

  N_poles_cluster_CM_tab.allocate_fill (X.N_poles_cluster_CM_tab);

  Nmin_PCM_cluster_tab.allocate_fill (X.Nmin_PCM_cluster_tab);

  Nmax_cluster_CM_tab.allocate_fill (X.Nmax_cluster_CM_tab);

  cluster_CM_S_matrix_poles.allocate_fill (X.cluster_CM_S_matrix_poles);

  cluster_CM_R0_tab.allocate_fill (X.cluster_CM_R0_tab);

  cluster_CM_K_tab.allocate_fill (X.cluster_CM_K_tab);
  cluster_CM_W_tab.allocate_fill (X.cluster_CM_W_tab);
  cluster_CM_E_tab.allocate_fill (X.cluster_CM_E_tab);

  cluster_CM_C0_tab.allocate_fill (X.cluster_CM_C0_tab);

  cluster_CM_Cplus_tab.allocate_fill (X.cluster_CM_Cplus_tab);

  potential_cluster_CM_bef_R_tab_uniform.allocate_fill (X.potential_cluster_CM_bef_R_tab_uniform);
  potential_cluster_CM_bef_R_tab_GL.allocate_fill (X.potential_cluster_CM_bef_R_tab_GL);
  potential_cluster_CM_aft_R_tab_GL.allocate_fill (X.potential_cluster_CM_aft_R_tab_GL);

  potential_cluster_CM_derivative_r0_tab.allocate_fill (X.potential_cluster_CM_derivative_r0_tab);

  cluster_CM_shells.allocate_fill_object_elements (X.cluster_CM_shells);

  Nmax_HO_tab.allocate_fill (X.Nmax_HO_tab);

  r_bef_R_tab_uniform.allocate_fill (X.r_bef_R_tab_uniform);

  r_bef_R_tab_GL.allocate_fill (X.r_bef_R_tab_GL);
  w_bef_R_tab_GL.allocate_fill (X.w_bef_R_tab_GL);

  HO_wfs_bef_R_tab_GL.allocate_fill  (X.HO_wfs_bef_R_tab_GL);
  HO_dwfs_bef_R_tab_GL.allocate_fill (X.HO_dwfs_bef_R_tab_GL);

  r_aft_R_tab_GL.allocate_fill (X.r_aft_R_tab_GL);
  w_aft_R_tab_GL.allocate_fill (X.w_aft_R_tab_GL);

  HO_wfs_aft_R_tab_GL.allocate_fill  (X.HO_wfs_aft_R_tab_GL);
  HO_dwfs_aft_R_tab_GL.allocate_fill (X.HO_dwfs_aft_R_tab_GL);

  HO_overlaps_cluster_CM.allocate_fill (X.HO_overlaps_cluster_CM);

  HO_overlaps_Fermi_cluster_CM.allocate_fill (X.HO_overlaps_Fermi_cluster_CM);

  PCM_matrices_cluster.allocate_fill (X.PCM_matrices_cluster);

  cluster_prot_data.allocate_fill (X.cluster_prot_data);
  cluster_neut_data.allocate_fill (X.cluster_neut_data);

  cluster_prot_data_HO.allocate_fill (X.cluster_prot_data_HO);
  cluster_neut_data_HO.allocate_fill (X.cluster_neut_data_HO);
}


void cluster_data::deallocate ()
{
  N_poles_cluster_CM_tab.deallocate ();

  Nmin_PCM_cluster_tab.deallocate ();

  Nmax_cluster_CM_tab.deallocate ();

  cluster_CM_S_matrix_poles.deallocate ();

  cluster_CM_R0_tab.deallocate ();

  cluster_CM_K_tab.deallocate ();
  cluster_CM_W_tab.deallocate ();
  cluster_CM_E_tab.deallocate ();

  cluster_CM_C0_tab.deallocate ();

  cluster_CM_Cplus_tab.deallocate ();

  potential_cluster_CM_bef_R_tab_uniform.deallocate ();
  potential_cluster_CM_bef_R_tab_GL.deallocate ();
  potential_cluster_CM_aft_R_tab_GL.deallocate ();

  potential_cluster_CM_derivative_r0_tab.deallocate ();

  cluster_CM_shells.deallocate ();

  Nmax_HO_tab.deallocate ();

  r_bef_R_tab_uniform.deallocate ();

  r_bef_R_tab_GL.deallocate ();
  w_bef_R_tab_GL.deallocate ();

  HO_wfs_bef_R_tab_GL.deallocate ();
  HO_dwfs_bef_R_tab_GL.deallocate ();

  r_aft_R_tab_GL.deallocate ();
  w_aft_R_tab_GL.deallocate ();

  HO_wfs_aft_R_tab_GL.deallocate ();
  HO_dwfs_aft_R_tab_GL.deallocate ();

  HO_overlaps_cluster_CM.deallocate ();

  HO_overlaps_Fermi_cluster_CM.deallocate ();

  PCM_matrices_cluster.deallocate ();

  cluster_prot_data.deallocate ();
  cluster_neut_data.deallocate ();

  cluster_prot_data_HO.deallocate ();
  cluster_neut_data_HO.deallocate ();

  H_potential = NO_POTENTIAL; 

  basis_potential = NO_POTENTIAL; 

  is_it_Lowdin = false;
  
  cluster = NO_PARTICLE;

  S_matrix_pole = false;

  Z_cluster = 0; 
  N_cluster = 0; 
  A_cluster = 0; 

  A_composite = 0; 

  BP_intrinsic = 2; 

  J_intrinsic = 0.0; 

  vector_index_intrinsic = 0;

  Lmax = 0; 
  Nmax = 0; 

  cluster_mass_for_calc = 0; 

  N_bef_R_GL = 0; 
  N_aft_R_GL = 0; 

  N_bef_R_uniform = 0; 
  N_aft_R_uniform = 0; 

  Nk_momentum_GL = 0;
  Nk_momentum_uniform = 0;
  
  R = 0.0; 

  step_bef_R_uniform = 0.0; 

  R_real_max = 0.0; 

  kmax_momentum = 0.0;

  R_Fermi_momentum = 0.0;
  
  R_charge = 0.0; 

  nucleus_mass = 0.0; 

  R_cut_function = 0.0; 
  d_cut_function = 0.0; 

  b_lab_cluster = 0.0; 

  hbar_omega_cluster = 0.0; 

  Z_cluster_charge_potential = 0.0; 

  E_intrinsic_cluster = 0.0; 

  E_CM_HO_max = 0;

  potential_cluster_CM_derivative_R = 0.0;
}





//--// Definition of the contour and HO shells of the CM part of the cluster (discretization of the complex contour , Nmax of HO shells, ...)
//--// direct copy of input_data arrays to the class

void cluster_data::contours_data_fill (
				       const class input_data_str &input_data , 
				       const unsigned int ic)
{	
  const class array<unsigned int> &CC_N_poles_cluster_CM_tab = input_data.get_CC_N_poles_cluster_CM_tab ();

  const class array<int> &CC_Nmin_PCM_cluster_tab = input_data.get_CC_Nmin_PCM_cluster_tab ();

  const class array<complex<double> > &CC_K_peak_cluster_CM_tab   = input_data.get_CC_K_peak_cluster_CM_tab ();
  const class array<complex<double> > &CC_K_middle_cluster_CM_tab = input_data.get_CC_K_middle_cluster_CM_tab ();
  const class array<complex<double> > &CC_K_max_cluster_CM_tab    = input_data.get_CC_K_max_cluster_CM_tab ();

  const class array<unsigned int> &CC_N_K_peak_cluster_CM_tab   = input_data.get_CC_N_K_peak_cluster_CM_tab ();
  const class array<unsigned int> &CC_N_K_middle_cluster_CM_tab = input_data.get_CC_N_K_middle_cluster_CM_tab ();
  const class array<unsigned int> &CC_N_K_max_cluster_CM_tab    = input_data.get_CC_N_K_max_cluster_CM_tab ();

  cluster_CM_S_matrix_poles = false;

  for (int L = 0 ; L <= Lmax ; L++)
    {
      const complex<double> CC_K_start = k_start_calc (false , cluster , L , Z_cluster_charge_potential , R);

      const double J_min = abs (J_intrinsic - L);
      
      const double J_max = J_intrinsic + L;

      const int J_number = make_int (J_max - J_min) + 1;

      for (int J_index = 0 ; J_index < J_number ; J_index++)
	{
	  const double J = J_min + J_index;

	  const complex<double> CC_K_peak   = CC_K_peak_cluster_CM_tab  (ic , L , J_index);
	  const complex<double> CC_K_middle = CC_K_middle_cluster_CM_tab(ic , L , J_index);
	  const complex<double> CC_K_max    = CC_K_max_cluster_CM_tab   (ic , L , J_index);

	  const unsigned int CC_N_K_peak   = CC_N_K_peak_cluster_CM_tab  (ic , L , J_index);
	  const unsigned int CC_N_K_middle = CC_N_K_middle_cluster_CM_tab(ic , L , J_index);
	  const unsigned int CC_N_K_max    = CC_N_K_max_cluster_CM_tab   (ic , L , J_index);

	  const unsigned int CC_N_scat = CC_N_K_peak + CC_N_K_middle + CC_N_K_max;

	  //--// some temporary constants from "input_data"
	  const int CC_N_poles_LJ = make_int (CC_N_poles_cluster_CM_tab(ic , L , J_index));

	  const int Nmin_PCM_LJ = CC_Nmin_PCM_cluster_tab(ic , L , J_index);

	  const int Nmax_LJ = input_data.Nmax_LJ_cluster_determine (ic , L , J);

	  //--// temporary tab to store the positions and associated weights and contour index of the complex contour points (contour shells)
	  class array<complex<double> > CC_K_tab(CC_N_scat);

	  class array<complex<double> > W_tab(CC_N_scat);

	  //--// for each part of the complex contour
	  if (CC_N_K_peak > 0)
	    {
	      //--// discretizes the part of the contour with gauss legendre
	      k_w_tab_segment_part_calc (0 , CC_N_K_peak , CC_K_start , CC_K_peak , CC_K_tab , W_tab);
	    }

	  if (CC_N_K_middle > 0)
	    {
	      //--// discretizes the part of the contour with gauss legendre
	      k_w_tab_segment_part_calc (CC_N_K_peak , CC_N_K_middle , CC_K_peak , CC_K_middle , CC_K_tab , W_tab);
	    }

	  if (CC_N_K_max > 0)
	    {
	      //--// discretizes the part of the contour with gauss legendre
	      k_w_tab_segment_part_calc (CC_N_K_peak + CC_N_K_middle , CC_N_K_max , CC_K_middle , CC_K_max , CC_K_tab , W_tab);
	    }

	  N_poles_cluster_CM_tab(L , J) = CC_N_poles_cluster_CM_tab(ic , L , J_index);

	  Nmin_PCM_cluster_tab(L , J) = Nmin_PCM_LJ;

	  Nmax_cluster_CM_tab(L , J) = Nmax_LJ;

	  for (int N = 0 ; N < CC_N_poles_LJ ; N++) cluster_CM_S_matrix_poles(N , L , J) = true;

	  for (int N = CC_N_poles_LJ ; N <= Nmax_LJ ; N++)
	    {
	      const int I_scat = N - CC_N_poles_LJ;

	      cluster_CM_K_tab(N , L , J) = CC_K_tab(I_scat);

	      cluster_CM_W_tab(N , L , J) = W_tab(I_scat);
	    }
	}
    }
}

void cluster_data::HO_CM_basis_data_fill (
					  const class input_data_str &input_data , 
					  const unsigned int ic)
{	
  const class array<unsigned int> &CC_N_poles_cluster_CM_tab = input_data.get_CC_N_poles_cluster_CM_tab ();

  const class array<int> &CC_Nmin_PCM_cluster_tab = input_data.get_CC_Nmin_PCM_cluster_tab ();

  cluster_CM_S_matrix_poles = false;

  for (int L = 0 ; L <= Lmax ; L++) 
    {	
      const double J_min = abs (J_intrinsic - L);
      
      const double J_max = J_intrinsic + L;

      const int J_number = make_int (J_max - J_min) + 1;

      for (int J_index = 0 ; J_index < J_number ; J_index++)
	{
	  //--// some temporary constants from "input_data"

	  const double J = J_min + J_index;

	  const int CC_N_poles_LJ = make_int (CC_N_poles_cluster_CM_tab(ic , L , J_index));

	  N_poles_cluster_CM_tab(L , J) = CC_N_poles_LJ;

	  Nmin_PCM_cluster_tab(L , J) = CC_Nmin_PCM_cluster_tab(ic , L , J_index);

	  Nmax_cluster_CM_tab(L , J) = Nmax_HO_tab(L);

	  for (int N = 0 ; N < CC_N_poles_LJ ; N++) cluster_CM_S_matrix_poles(N , L , J) = true;
	}
    }
}






// Calculation of the potential acting on the CM part of a cluster with cluster approximation
// ------------------------------------------------------------------------------------------
// One uses the Berggren basis of the CM of clusters to solve CC equations in GSM-CC.
// It is generated by a CM potential, calculated and stored here.
// One uses for that cluster approximation from the WS basis potential or KKNN potential (see GSM_nucleons_data.h), i.e. one considers that the cluster is punctual for that purpose.
//
// One notes a its number of nucleons, a(p) its number of protons and a(n) its number of neutrons.
// Hence, all nucleons i of the cluster verify: ri ~ R_CM (seen as vector), li ~ LCM/s (seen as operator), \sum_{i in cluster} si ~ J_intrinsic.
//
// Let us define the CM potential as U(R_CM) = U[ctr](R_CM) + U[so](R_CM) LCM.J_intrinsic . 
// One has from cluster approximation:
//
// U[ctr](R_CM) ~ \sum_{i in cluster} U[ctr](ri) => U[ctr](R_CM) = a(p) Up[ctr](R_CM) + a(n) Un[ctr](R_CM), with ri and R_CM seen as vectors.
// One obtains similar equations for all LCM and R_CM seen as scalar.
//
// U[so](R_CM) ~ \sum_{i in cluster} U[so](ri) (li.si) ~ (a(p) Up[so](R_CM) + a(n) Un[so](R_CM)) \sum_{i in cluster} (li.si) ~ (a(p)/a) Up[so](R_CM) + (a(n)/a) Un[so](R_CM) (LCM.J_intrinsic), with ri and R_CM seen as vectors
// => U[so](R_CM) = (a(p)/a) Up[so](R_CM) + (a(n)/a) Un[so](R_CM).
// One obtains similar equations for all LCM and R_CM seen as scalar.
//
// U(R_CM) potentials are stored on Gauss-Legendre and uniform grids on [0:R], with R the rotation point.
// The Coulomb part is included here as well.
// The spin-orbit divergence for r -> 0 of the WS potential is removed with an extrapolation of r = step_bef_R_uniform, 2.step_bef_R_uniform values of the uniform grid to r ~ 0 therein.


void cluster_data::potential_part_r_tab_fixed_calc (
						    const enum particle_type particle ,
						    const int L , 
						    const double J , 
						    const class array<double> &r_tab ,
						    class array<double> &potential_part_tab) const
{
  const unsigned int N_bef_R = r_tab.dimension (0);

  const unsigned int N_nucleons_cluster = (particle == PROTON) ? (Z_cluster) : (N_cluster);

  const int Z_cluster_charge_potential_particle = (particle == PROTON) ? (Z_cluster_charge_potential) : (0);

  const double Vso_factor = N_nucleons_cluster / static_cast<double> (A_cluster * A_cluster);

  const class array<double> &d_basis_tab   = (particle == PROTON) ? (cluster_prot_data.get_d_basis_tab ())   : (cluster_neut_data.get_d_basis_tab ());
  const class array<double> &R0_basis_tab  = (particle == PROTON) ? (cluster_prot_data.get_R0_basis_tab ())  : (cluster_neut_data.get_R0_basis_tab ());
  const class array<double> &Vo_basis_tab  = (particle == PROTON) ? (cluster_prot_data.get_Vo_basis_tab ())  : (cluster_neut_data.get_Vo_basis_tab ());
  const class array<double> &Vso_basis_tab = (particle == PROTON) ? (cluster_prot_data.get_Vso_basis_tab ()) : (cluster_neut_data.get_Vso_basis_tab ());

  const double d_cluster   = d_basis_tab(L);
  const double R0_cluster  = R0_basis_tab(L);
  const double Vo_cluster  = Vo_basis_tab(L) * N_nucleons_cluster;
  const double Vso_cluster = Vso_basis_tab(L) * Vso_factor;

  switch (H_potential)
    {
    case WS:
      {	
	const class WS_class WS_potential(false , d_cluster , R0_cluster , Vo_cluster , Vso_cluster , cluster , Z_cluster_charge_potential_particle , R_charge , L , J);

	for (unsigned int i = 0 ; i < N_bef_R ; i++) potential_part_tab(i) += WS_potential(r_tab(i));

	potential_cluster_CM_derivative_r0_tab(L , J) += (WS_potential(sqrt_precision) - WS_potential(-sqrt_precision))/(2.0*sqrt_precision);
      } break;

    case WS_ANALYTIC:
      {	
	const class WS_analytic_class WS_potential(false , d_cluster , R0_cluster , Vo_cluster , Vso_cluster , cluster , Z_cluster_charge_potential_particle , R_charge , L , J);

	for (unsigned int i = 0 ; i < N_bef_R ; i++) potential_part_tab(i) += WS_potential(r_tab(i));

	potential_cluster_CM_derivative_r0_tab(L , J) += (WS_potential(sqrt_precision) - WS_potential(-sqrt_precision))/(2.0*sqrt_precision);
      } break;

    case KKNN:
      {
	double V0_KKNN_cluster[5];
	for (unsigned int i = 0 ; i < 5 ; i++) V0_KKNN_cluster[i] = V0_KKNN[i] * N_nucleons_cluster;

	double Vls_KKNN_cluster[3];
	for (unsigned int i = 0 ; i < 3 ; i++) Vls_KKNN_cluster[i] = Vls_KKNN[i] * Vso_factor;

	const class KKNN_class KKNN_potential (false , V0_KKNN_cluster , rho_KKNN , Vls_KKNN_cluster , rho_ls_KKNN , cluster , Z_cluster_charge_potential_particle , R_charge , L , J);

	for (unsigned int i = 0 ; i < N_bef_R ; i++) potential_part_tab(i) += KKNN_potential(r_tab(i));

	potential_cluster_CM_derivative_r0_tab(L , J) += (KKNN_potential(sqrt_precision) - KKNN_potential(-sqrt_precision))/(2.0*sqrt_precision);
      } break;

    default:
      error_message_print_abort ("Hamiltonian potential invalid in cluster_data::potential_part_r_tab_fixed_calc");
    }
}

void cluster_data::potential_part_calc (
					const int L , 
					const double J)
{
  class array<double> potential_bef_R_tab_uniform(N_bef_R_uniform);
  class array<double> potential_bef_R_tab_GL(N_bef_R_GL);
  class array<double> potential_aft_R_tab_GL(N_aft_R_GL);
 
  potential_bef_R_tab_uniform = 0.0;

  potential_bef_R_tab_GL = 0.0;
  potential_aft_R_tab_GL = 0.0;

  potential_cluster_CM_derivative_r0_tab(L , J) = 0.0;

  if (Z_cluster > 0)
    {
      potential_part_r_tab_fixed_calc (PROTON , L , J , r_bef_R_tab_uniform , potential_bef_R_tab_uniform);
      potential_part_r_tab_fixed_calc (PROTON , L , J , r_bef_R_tab_GL  , potential_bef_R_tab_GL);
      potential_part_r_tab_fixed_calc (PROTON , L , J , r_aft_R_tab_GL  , potential_aft_R_tab_GL);
    }

  if (N_cluster > 0)
    {
      potential_part_r_tab_fixed_calc (NEUTRON , L , J , r_bef_R_tab_uniform , potential_bef_R_tab_uniform);
      potential_part_r_tab_fixed_calc (NEUTRON , L , J , r_bef_R_tab_GL  , potential_bef_R_tab_GL);
      potential_part_r_tab_fixed_calc (NEUTRON , L , J , r_aft_R_tab_GL  , potential_aft_R_tab_GL);
    }

  const bool is_there_infinite = !finite (potential_bef_R_tab_uniform(0));
	  
  const double slope = (potential_bef_R_tab_uniform(2) - potential_bef_R_tab_uniform(1))/step_bef_R_uniform;

  const double shift = potential_bef_R_tab_uniform(1);

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double r = r_bef_R_tab_GL(i);
      
      if (is_there_infinite && (r < step_bef_R_uniform)) 
	potential_bef_R_tab_GL(i) = slope*(r - step_bef_R_uniform) + shift;  
    }
  
  if (is_there_infinite) 
    {
      potential_bef_R_tab_uniform(0) = 2.0*potential_bef_R_tab_uniform(1) - potential_bef_R_tab_uniform(2);

      potential_cluster_CM_derivative_r0_tab(L , J) = slope;
    }

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) potential_cluster_CM_bef_R_tab_uniform(L , J , i) = potential_bef_R_tab_uniform(i);
  
  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) potential_cluster_CM_bef_R_tab_GL(L , J , i) = potential_bef_R_tab_GL(i);
  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) potential_cluster_CM_aft_R_tab_GL(L , J , i) = potential_aft_R_tab_GL(i);
}

void cluster_data::cluster_CM_potential_tables_calc (
						     const int L , 
						     const double J)
{
  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) potential_cluster_CM_bef_R_tab_uniform(L , J , i) = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) potential_cluster_CM_bef_R_tab_GL(L , J , i) = 0.0;
  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) potential_cluster_CM_aft_R_tab_GL(L , J , i) = 0.0;

  potential_part_calc (L , J);
}









// Calculation of the overlaps between CM wave functions with HO states for the HO expansion of the interaction
// ------------------------------------------------------------------------------------------------------------
// One calculates <NCM LCM J | NCM-HO LCM J> and <NCM LCM J | F(r) | NCM-HO LCM J> where F(r) is a Fermi function used for stability, as potentials do not necessarily vanish at large distance.

void cluster_data::HO_overlaps_CM_calc ()
{
  for (int L = 0 ; L <= Lmax ; L++)
    {
      const double J_min = abs (J_intrinsic - L);
      const double J_max = J_intrinsic + L;
      
      const int J_number = make_int (J_max - J_min) + 1;

      const int Nmax_HO_L = Nmax_HO_tab(L);

      for (int J_index = 0 ; J_index < J_number ; J_index++)
	{
	  const double J = J_min + J_index;

	  const int Nmax_LJ = Nmax_cluster_CM_tab(L , J);

	  for (int NCM = 0 ; NCM <= Nmax_LJ ; NCM++)
	    {
	      const class spherical_state &cluster_CM_shell = cluster_CM_shells(NCM , L , J);

	      const class array<complex<double> > &wf_bef_R_tab_GL = cluster_CM_shell.get_wf_bef_R_tab_GL ();
	      const class array<complex<double> > &wf_aft_R_tab_GL = cluster_CM_shell.get_wf_aft_R_tab_GL_real (); 

	      class vector_class<complex<double> > &HO_overlaps_cluster_NCM_LJ = HO_overlaps_cluster_CM(NCM , L , J);

	      class vector_class<complex<double> > &HO_overlaps_Fermi_cluster_NCM_LJ = HO_overlaps_Fermi_cluster_CM(NCM , L , J);

	      if (basis_potential == HO_POTENTIAL)
		{
		  for (int NCM_HO = 0 ; NCM_HO <= Nmax_HO_L ; NCM_HO++)
		    {
		      HO_overlaps_cluster_NCM_LJ(NCM_HO) = (NCM == NCM_HO) ? (1.0) : (0.0); 

		      complex<double> HO_overlaps_Fermi_cluster_NCM_LJ_NCM_HO = 0.0;

		      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
			{
			  const double r = r_bef_R_tab_GL(i);
			  
			  const double HO_wf_r = HO_wfs_bef_R_tab_GL(NCM_HO , L , i);
			  
			  const double Fermi_r = Fermi_like_function (R_cut_function , d_cut_function , r);
			  
			  HO_overlaps_Fermi_cluster_NCM_LJ_NCM_HO += w_bef_R_tab_GL(i)*wf_bef_R_tab_GL(i)*HO_wf_r*Fermi_r;
			}

		      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
			{
			  const double r = r_aft_R_tab_GL(i);
			  
			  const double HO_wf_r = HO_wfs_aft_R_tab_GL(NCM_HO , L , i);
			  
			  const double Fermi_r = Fermi_like_function (R_cut_function , d_cut_function , r);
			  
			  HO_overlaps_Fermi_cluster_NCM_LJ_NCM_HO += w_aft_R_tab_GL(i)*wf_aft_R_tab_GL(i)*HO_wf_r*Fermi_r;
			}

		      HO_overlaps_Fermi_cluster_NCM_LJ(NCM_HO) = HO_overlaps_Fermi_cluster_NCM_LJ_NCM_HO;
		    }
		}
	      else
		{
		  for (int NCM_HO = 0 ; NCM_HO <= Nmax_HO_L ; NCM_HO++)
		    {
		      complex<double> HO_overlaps_cluster_NCM_LJ_NCM_HO = 0.0;

		      complex<double> HO_overlaps_Fermi_cluster_NCM_LJ_NCM_HO = 0.0;

		      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
			{
			  const double r = r_bef_R_tab_GL(i);
			  const double w = w_bef_R_tab_GL(i);

			  const double Fermi_r = Fermi_like_function (R_cut_function , d_cut_function , r);

			  const complex<double> wfs_w_product = wf_bef_R_tab_GL(i)*HO_wfs_bef_R_tab_GL(NCM_HO , L , i)*w;

			  HO_overlaps_cluster_NCM_LJ_NCM_HO += wfs_w_product;
			  
			  HO_overlaps_Fermi_cluster_NCM_LJ_NCM_HO += wfs_w_product*Fermi_r;
			}

		      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
			{	
			  const double r = r_aft_R_tab_GL(i);
			  const double w = w_aft_R_tab_GL(i);

			  const double Fermi_r = Fermi_like_function (R_cut_function , d_cut_function , r);

			  const complex<double> wfs_w_product = wf_aft_R_tab_GL(i)*HO_wfs_aft_R_tab_GL(NCM_HO , L , i)*w;

			  HO_overlaps_cluster_NCM_LJ_NCM_HO += wfs_w_product; 

			  HO_overlaps_Fermi_cluster_NCM_LJ_NCM_HO += wfs_w_product*Fermi_r;
			}

		      HO_overlaps_cluster_NCM_LJ(NCM_HO) = HO_overlaps_cluster_NCM_LJ_NCM_HO;

		      HO_overlaps_Fermi_cluster_NCM_LJ(NCM_HO) = HO_overlaps_Fermi_cluster_NCM_LJ_NCM_HO;
		    }
		}
	    }
	}
    }
}








// Calculation of projection matrices defined in CM space which project CM cluster wave functions in a Berggren CM space for which NCM >= Nmin_PCM
// -----------------------------------------------------------------------------------------------------------------------------------------------
// Indeed, Berggren CM wave functions for which NCM < Nmin_PCM are considered to almost fully occupied in the core, and hence projected out with PCM projector.
//
// One has PCM = Id - \sum{NCM < Nmin} |NCM><NCM|, with |NCM>< a Berggren CM wave function generated by the potential above.
//
// One stores as a matrix: <HO CM out | PCM | HO CM in> = \delta(NCM-HO-in , NCM-HO-out) - \sum{NCM < Nmin} <HO CM out | NCM> <NCM | HO CM in>
// with |HO CM> = [NCM-HO LCM> a standard HO CM state, using the overlaps <HO CM | NCM> calculated above.

void cluster_data::PCM_matrices_cluster_calc ()
{
  for (int L = 0 ; L <= Lmax ; L++)
    {
      const double J_min = abs (J_intrinsic - L);

      const double J_max = J_intrinsic + L;

      const int J_number = make_int (J_max - J_min) + 1;

      const int Nmax_HO_L = Nmax_HO_tab(L);

      for (int J_index = 0 ; J_index < J_number ; J_index++)
	{
	  const double J = J_min + J_index;

	  const int Nmin_PCM_LJ = Nmin_PCM_cluster_tab(L , J);

	  class matrix<double> &PCM_matrix_LJ = PCM_matrices_cluster(L , J);

	  for (int NCM_HO = 0 ; NCM_HO <= Nmax_HO_L ; NCM_HO++)
	    for (int NCM_HO_p = 0 ; NCM_HO_p <= Nmax_HO_L ; NCM_HO_p++)
	      {
		double PCM_ME_LJ = (NCM_HO == NCM_HO_p) ? (1.0) : (0.0);

		for (int NCM = 0 ; NCM < Nmin_PCM_LJ ; NCM++)
		  {
		    const class vector_class<complex<double> > &HO_overlaps_cluster_NCM_LJ = HO_overlaps_cluster_CM(NCM , L , J);

		    PCM_ME_LJ -= real (HO_overlaps_cluster_NCM_LJ(NCM_HO)*HO_overlaps_cluster_NCM_LJ(NCM_HO_p));
		  }

		PCM_matrix_LJ(NCM_HO , NCM_HO_p) = PCM_ME_LJ;
	      }
	}
    }
}




void cluster_data::get_PCM_matrices_cluster (const class cluster_data &data_CC_Berggren)
{
  const class lj_table<class matrix<double> > &PCM_matrices_cluster_CC_Berggren = data_CC_Berggren.get_PCM_matrices_cluster ();

  for (int L = 0 ; L <= Lmax ; L++)
    {
      const double J_min = abs (J_intrinsic - L);

      const double J_max = J_intrinsic + L;

      const int J_number = make_int (J_max - J_min) + 1;

      for (int J_index = 0 ; J_index < J_number ; J_index++)
	{
	  const double J = J_min + J_index;

	  PCM_matrices_cluster(L , J) = PCM_matrices_cluster_CC_Berggren(L , J);
	}
    }
}




// Memory used by the class
// ------------------------

double used_memory_calc (const class cluster_data &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.N_poles_cluster_CM_tab) + used_memory_calc (T.Nmin_PCM_cluster_tab) + used_memory_calc (T.Nmax_cluster_CM_tab) + used_memory_calc (T.cluster_CM_S_matrix_poles) + used_memory_calc (T.cluster_CM_R0_tab) + used_memory_calc (T.cluster_CM_K_tab) + used_memory_calc (T.cluster_CM_W_tab) + used_memory_calc (T.cluster_CM_E_tab) + used_memory_calc (T.cluster_CM_C0_tab) + used_memory_calc (T.cluster_CM_Cplus_tab) + used_memory_calc (T.potential_cluster_CM_bef_R_tab_uniform) + used_memory_calc (T.potential_cluster_CM_bef_R_tab_GL) + used_memory_calc (T.potential_cluster_CM_aft_R_tab_GL) + used_memory_calc (T.potential_cluster_CM_derivative_r0_tab) + used_memory_calc (T.cluster_CM_shells) + used_memory_calc (T.Nmax_HO_tab) + used_memory_calc (T.r_bef_R_tab_uniform) + used_memory_calc (T.r_bef_R_tab_GL) + used_memory_calc (T.w_bef_R_tab_GL) + used_memory_calc (T.HO_wfs_bef_R_tab_GL) + used_memory_calc (T.HO_dwfs_bef_R_tab_GL) + used_memory_calc (T.r_aft_R_tab_GL) + used_memory_calc (T.w_aft_R_tab_GL) + used_memory_calc (T.HO_wfs_aft_R_tab_GL) + used_memory_calc (T.HO_dwfs_aft_R_tab_GL) + used_memory_calc (T.HO_overlaps_cluster_CM) + used_memory_calc (T.HO_overlaps_Fermi_cluster_CM) + used_memory_calc (T.PCM_matrices_cluster) + used_memory_calc (T.cluster_prot_data_HO) + used_memory_calc (T.cluster_prot_data) + used_memory_calc (T.cluster_neut_data_HO) + used_memory_calc (T.cluster_neut_data) - (sizeof (T.N_poles_cluster_CM_tab) + sizeof (T.Nmin_PCM_cluster_tab) + sizeof (T.Nmax_cluster_CM_tab) + sizeof (T.cluster_CM_S_matrix_poles) + sizeof (T.cluster_CM_R0_tab) + sizeof (T.cluster_CM_K_tab) + sizeof (T.cluster_CM_W_tab) + sizeof (T.cluster_CM_E_tab) + sizeof (T.cluster_CM_C0_tab) + sizeof (T.cluster_CM_Cplus_tab) + sizeof (T.potential_cluster_CM_bef_R_tab_uniform) + sizeof (T.potential_cluster_CM_bef_R_tab_GL) + sizeof (T.potential_cluster_CM_aft_R_tab_GL) + sizeof (T.potential_cluster_CM_derivative_r0_tab) + sizeof (T.cluster_CM_shells) + sizeof (T.Nmax_HO_tab) + sizeof (T.r_bef_R_tab_uniform) + sizeof (T.r_bef_R_tab_GL) + sizeof (T.w_bef_R_tab_GL) + sizeof (T.HO_wfs_bef_R_tab_GL) + sizeof (T.HO_dwfs_bef_R_tab_GL) + sizeof (T.r_aft_R_tab_GL) + sizeof (T.w_aft_R_tab_GL) + sizeof (T.HO_wfs_aft_R_tab_GL) + sizeof (T.HO_dwfs_aft_R_tab_GL) + sizeof (T.HO_overlaps_cluster_CM) + sizeof (T.HO_overlaps_Fermi_cluster_CM) + sizeof (T.PCM_matrices_cluster) + sizeof (T.cluster_prot_data_HO) + sizeof (T.cluster_prot_data) + sizeof (T.cluster_neut_data_HO) + sizeof (T.cluster_neut_data))/1000000.0;

  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;
}



