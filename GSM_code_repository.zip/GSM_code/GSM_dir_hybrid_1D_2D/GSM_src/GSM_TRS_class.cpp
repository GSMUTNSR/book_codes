#include "../GSM_include/GSM_include_def.h"



// TYPE is double or complex
// -------------------------

// Class applying time-reversal symmetry to |Psi[in]> to obtain |Psi[out]>
// -----------------------------------------------------------------------
// One has here initializers (they are neither allocations nor deallocations, so that implicit constructors/destructors are sufficient),
// time-reversal symmetry (TRS) operator apply call and operators overloading of TRS call.
//
// For a one-body state, TRS|nlj m> = (-1)^(j - m) |nlj -m>.
// It is straightforward to extend TRS to Slater determinant.
// TRS|SD> is then another Slater determinant multiplied by a phase (-1)^(alpha_SD), arising from both (-1)^(j - m) and reordering phases.
//
// The main interest of TRS is that [H , TRS] = 0 for M=0, so that H |Psi> = E |Psi> => TRS |Psi> = (-1)^J |Psi>.
// Hence, one can check that <Psi|TRS|SD> = <Psi|SD> (-1)^(J + alpha_SD), so that one just has to calculate about half of the |Psi> components
// (there is no gain if TRS|SD> = +/- |SD>, which is a rare case), the others being obtained with the previous relation.
//
// TRS is also useful to obtain the GSM vector |J -M> from a GSM vector |J M>, with M > 0, as |J -M> = (-1)^(J - M) TRS |J M>.
// This occurs with reactions, where the composite [|Psi[target]> |Psi[projectile]>]^J_M is calculated from Clebsch-Gordans coefficients and |Psi[target] MT> |Psi[projectile] mp> states.
//
// Routines here are rather straightforward so that they are not detailed. Only general explanations are given.
//
// The TRS of a Slater determinant |inSD>, |outSD> = +/- TRS |inSD> is another Slater determinant multiplied by a phase.
// The index and phases of |outSD> are stored, so that one loops over |inSD> to obtained |Psi[out]> -> |Psi[out]> + TRS |Psi[in]>.
//
// Operator overloading only consists of a wrapper routine so that TRS is called elsewhere from a instruction of the form "PSI_out += alpha*TRS (PSI_in)".
//
// Tests are done to check if |Psi[in]> and |Psi[out]> have same parities, opposite total angular quantum numbers and same GSM dimensions.
//
// apply_add and apply_add_one_transfer
// ------------------------------------
// One calculates |Psi[out]> -> |Psi[out]> + TRS.|Psi[in]>.
// |SD[in]> and |SD[out]> = +/- TRS |SD[in]> might not be on the same node.
// One calculates then all TRS |SD[in]> in onde and one transfers them to the node where |SD[out]> is by looping over all nodes and checking on which node |SD[out]> is.
// The indices of all |SD[out]> and their components are transfered with simple Send/Recv routines.
// This is done by calling apply_add_one_transfer many times. One has two loops over nodes in apply_add, one with node[in] < node[out] and conversely, as otherwise one obtains a race condition.



TRS_class::TRS_class () :
  GSM_vector_helper_in_ptr (NULL) ,
  GSM_vector_helper_out_ptr (NULL)
{}



TRS_class::TRS_class (
		      class GSM_vector_helper_class &GSM_vector_helper_in , 
		      class GSM_vector_helper_class &GSM_vector_helper_out)
{
  initialize (GSM_vector_helper_in , GSM_vector_helper_out);
}



void TRS_class::initialize (
			    class GSM_vector_helper_class &GSM_vector_helper_in , 
			    class GSM_vector_helper_class &GSM_vector_helper_out)
{
  GSM_vector_helper_in_ptr  = &GSM_vector_helper_in;
  GSM_vector_helper_out_ptr = &GSM_vector_helper_out;
	  
  if (GSM_vector_helper_in.get_BP () != GSM_vector_helper_out.get_BP ()) error_message_print_abort ("Parities are not equal in TRS_class");

  if (GSM_vector_helper_in.get_iM () != GSM_vector_helper_out.get_TRS_iM ()) error_message_print_abort ("J projections are not opposite in TRS_class"); 
}



void TRS_class::initialize (const class TRS_class &X)
{
  GSM_vector_helper_in_ptr  = X.GSM_vector_helper_in_ptr;
  GSM_vector_helper_out_ptr = X.GSM_vector_helper_out_ptr;
}

void TRS_class::allocate_fill (const class TRS_class &X)
{
  initialize (X);
}

void TRS_class::deallocate ()
{
  GSM_vector_helper_in_ptr  = NULL;
  GSM_vector_helper_out_ptr = NULL;
}





#ifdef UseMPI

void TRS_class::apply_add_one_transfer (
					const unsigned int i_in_Send ,
					const unsigned int i_out_Recv ,
					const class GSM_vector &PSI_in , 
					class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();

  const bool is_it_process_in_Send  = (i_in_Send == THIS_PROCESS);
  const bool is_it_process_out_Recv = (i_out_Recv == THIS_PROCESS);
  
  const class array<unsigned int> &space_dimensions_all_processes_in  = GSM_vector_helper_in.get_space_dimensions_all_processes ();
  const class array<unsigned int> &space_dimensions_all_processes_out = GSM_vector_helper_out.get_space_dimensions_all_processes ();
  
  const class array<unsigned long int> &TRS_total_PSI_indices_in_to_out = GSM_vector_helper_in.get_TRS_total_PSI_indices ();
  
  const class array<unsigned char> &TRS_bin_phases_in_to_out = GSM_vector_helper_in.get_TRS_bin_phases ();
     
  const class array<unsigned long int> &first_total_PSI_process_indices = GSM_vector_helper_in.get_first_total_PSI_indices ();
  const class array<unsigned long int> &last_total_PSI_process_indices = GSM_vector_helper_in.get_last_total_PSI_indices ();
      
  const class array<unsigned long int> &TRS_total_PSI_indices_out_to_in = GSM_vector_helper_out.get_TRS_total_PSI_indices ();

  const unsigned int space_dimension_process_in_Send  = space_dimensions_all_processes_in(i_in_Send);
  const unsigned int space_dimension_process_out_Recv = space_dimensions_all_processes_out(i_out_Recv);
  
  const unsigned long int first_total_PSI_in_index_Send = first_total_PSI_process_indices(i_in_Send);
  const unsigned long int last_total_PSI_in_index_Send = last_total_PSI_process_indices(i_in_Send);

  const unsigned long int first_total_PSI_out_index_Recv = first_total_PSI_process_indices(i_out_Recv);
  const unsigned long int last_total_PSI_out_index_Recv = last_total_PSI_process_indices(i_out_Recv);
	      
  unsigned int N = 0;
	      
  if (is_it_process_in_Send)
    {
      for (unsigned int PSI_in_index = 0 ; PSI_in_index < space_dimension_process_in_Send ; PSI_in_index++) 
	{
	  const unsigned long int total_PSI_out_index = TRS_total_PSI_indices_in_to_out(PSI_in_index);
		  
	  if ((total_PSI_out_index >= first_total_PSI_out_index_Recv) && (total_PSI_out_index <= last_total_PSI_out_index_Recv)) N++;
	}
    }
	      
  if (is_it_process_out_Recv)
    {
      for (unsigned int PSI_out_index = 0 ; PSI_out_index < space_dimension_process_out_Recv ; PSI_out_index++) 
	{
	  const unsigned long int total_PSI_in_index = TRS_total_PSI_indices_out_to_in(PSI_out_index);
      
	  if ((total_PSI_in_index >= first_total_PSI_in_index_Send) && (total_PSI_in_index <= last_total_PSI_in_index_Send)) N++;
	}      
    }
      
  if (N > 0)
    {
      const unsigned int tag = i_out_Recv + NUMBER_OF_PROCESSES*i_in_Send;

      const unsigned int indices_tag = 2*tag;

      const unsigned int components_tag = 2*tag + 1;
	      
      class array<unsigned int> PSI_out_indices(N);

      class array<TYPE> TRS_PSI_in_components(N);
      
      if (is_it_process_in_Send)
	{
	  N = 0;

	  for (unsigned int PSI_in_index = 0 ; PSI_in_index < space_dimension_process_in_Send ; PSI_in_index++)
	    {
	      const unsigned long int total_PSI_out_index = TRS_total_PSI_indices_in_to_out(PSI_in_index);
			  
	      if ((total_PSI_out_index >= first_total_PSI_out_index_Recv) && (total_PSI_out_index <= last_total_PSI_out_index_Recv))
		{
		  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index_Recv;

		  const unsigned int TRS_bin_phase_out = TRS_bin_phases_in_to_out(PSI_in_index);
			  
		  const int TRS_phase_out = parity_from_binary_parity (TRS_bin_phase_out);
      
		  PSI_out_indices(N) = PSI_out_index;

		  TRS_PSI_in_components(N) = (TRS_phase_out == 1) ? (PSI_in[PSI_in_index]) : (-PSI_in[PSI_in_index]);

		  N++;
		}
	    }

	  PSI_out_indices.MPI_Send (i_out_Recv , indices_tag , MPI_COMM_WORLD);

	  TRS_PSI_in_components.MPI_Send (i_out_Recv , components_tag , MPI_COMM_WORLD);
	}
	
      
      if (is_it_process_out_Recv)
	{
	  PSI_out_indices.MPI_Recv (i_in_Send , indices_tag , MPI_COMM_WORLD);

	  TRS_PSI_in_components.MPI_Recv (i_in_Send , components_tag , MPI_COMM_WORLD);

	  for (unsigned int i = 0 ; i < N ; i++)
	    {
	      const unsigned int TRS_PSI_in_index = PSI_out_indices(i);

	      const TYPE TRS_PSI_in_component = TRS_PSI_in_components(i);

	      PSI_out[TRS_PSI_in_index] += TRS_PSI_in_component;
	    }
	}
    }
}

#endif







void TRS_class::apply_add (
			   const class GSM_vector &PSI_in , 
			   class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  const class GSM_vector_helper_class &GSM_vector_helper_PSI_in  = PSI_in.get_GSM_vector_helper ();
  const class GSM_vector_helper_class &GSM_vector_helper_PSI_out = PSI_out.get_GSM_vector_helper ();

  if (GSM_vector_helper_PSI_in.get_BP () != GSM_vector_helper_in.get_BP ()) error_message_print_abort ("in/PSI_in parities are not equal in TRS_class::apply_add");
  
  if (GSM_vector_helper_PSI_in.get_iM () != GSM_vector_helper_in.get_iM ()) error_message_print_abort ("in/PSI_in M projections are not equal in TRS_class::apply_add"); 

  if (GSM_vector_helper_PSI_out.get_BP () != GSM_vector_helper_out.get_BP ()) error_message_print_abort ("out/PSI_out parities are not equal in TRS_class::apply_add");

  if (GSM_vector_helper_PSI_out.get_iM () != GSM_vector_helper_out.get_iM ()) error_message_print_abort ("out/PSI_out M projections are not equal in TRS_class::apply_add"); 
  
  const unsigned int space_dimension_process_in = GSM_vector_helper_in.get_space_dimension_process ();
  
  const class array<unsigned long int> &TRS_total_PSI_indices_in_to_out = GSM_vector_helper_in.get_TRS_total_PSI_indices (); 

  const class array<unsigned char> &TRS_bin_phases_in_to_out = GSM_vector_helper_in.get_TRS_bin_phases ();
    
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper_out.get_first_total_PSI_index ();

  const unsigned long int last_total_PSI_out_index = GSM_vector_helper_out.get_last_total_PSI_index ();
  
  for (unsigned int PSI_in_index = 0 ; PSI_in_index < space_dimension_process_in ; PSI_in_index++)
    {
      const unsigned long int total_PSI_out_index = TRS_total_PSI_indices_in_to_out(PSI_in_index);
      
      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
	{
	  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

	  const unsigned int TRS_bin_phase_out = TRS_bin_phases_in_to_out(PSI_in_index);
  
	  const int TRS_phase_out = parity_from_binary_parity (TRS_bin_phase_out);
      
	  (TRS_phase_out == 1) ? (PSI_out[PSI_out_index] += PSI_in[PSI_in_index]) : (PSI_out[PSI_out_index] -= PSI_in[PSI_in_index]);
	}
    }

#ifdef UseMPI

  const bool is_it_MPI_parallelized_local = GSM_vector_helper_in.get_is_it_MPI_parallelized_local ();
 
  if (is_it_MPI_parallelized_local)
    {
      for (unsigned int i_in_Send = 0 ; i_in_Send < NUMBER_OF_PROCESSES ; i_in_Send++)
	for (unsigned int i_out_Recv = 0 ; i_out_Recv < i_in_Send ; i_out_Recv++)
	  {
	    if ((i_in_Send == THIS_PROCESS) || (i_out_Recv == THIS_PROCESS))
	      apply_add_one_transfer (i_in_Send , i_out_Recv , PSI_in , PSI_out);
	  }

      for (unsigned int i_out_Recv = 0 ; i_out_Recv < NUMBER_OF_PROCESSES ; i_out_Recv++)
	for (unsigned int i_in_Send = 0 ; i_in_Send < i_out_Recv ; i_in_Send++)
	  {
	    if ((i_in_Send == THIS_PROCESS) || (i_out_Recv == THIS_PROCESS))
	      apply_add_one_transfer (i_in_Send , i_out_Recv , PSI_in , PSI_out);
	  }
    }
  
#endif
}



class Op_PSI_closure_str TRS_class::operator () (const class GSM_vector &PSI) const
{  
  return Op_PSI_closure_str (*this , PSI);
}



double used_memory_calc (const class TRS_class &T)
{
  return sizeof (T)/1000000.0;
}



