#include "../GSM_include/GSM_include_def.h"

using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;
using namespace GSM_vector_NBMEs_handling::out_to_in;
using namespace MPI_2D_partitioning;
using namespace configuration_SD_in_space_one_jump_out_to_in;


// TYPE is double or complex
// -------------------------


// OBMEs means one-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons
// ------------------------------------------------------------------------------------------------------------------------------------------------------


// Calculation of the scalar strength for one pair of many-body states <Psi[out] | O(r) | Psi[in]> for all r radii
// ---------------------------------------------------------------------------------------------------------------
// O(r) is a one-body scalar type, such as density.
//
// One first loops over Slater determinants to obtain 0p-0h and 1p-1h NBMEs, and then one lops over r radii as all data related to inSD and outSD have been calculated and stored.
// This much faster than calling the many-body operator for each radius one after the other.
// 
// The non-zero NBMEs are of 0p-0h and 1p-1h type:
// <outSD | O(r) | inSD> = \sum_i <i | O(r) |i> if |inSD> = |outSD>.
// <outSD | O(r) | inSD> = +/- <i' | O(r) |i> if |inSD> and |outSD> differ by i,i'. The +/- 1 reordering phase is stored in an array.
//
// One separates the proton and neutron parts of <outSD | O(r) | inSD> in the proton-neutron case.
// One loops over Slater determinants, and one sums over <outSD | O(r) | inSD> NBMEs multiplied by <Psi[out] | outSD> and <inSD | Psi[in]>.
//
// TRS is time-reversal symmetry and can be used therein.
// It allows to divide calculations about one half if M=0 for |Psi[in]> and |Psi[out]>, as the rest is given from the first half by symmetry.
//
// OpenMP parallelization is used on the loop of proton or neutron Slater determinants. Reduction is done on the O(r) amplitude at the end of each routine.
// MPI parallelization here is implicit, as on considers only the Slater determinants of the current node. MPI reduction is done at the very end of the calculation.

void scalar_strength::diagonal_part_pp_nn_calc (
						const class array<TYPE> &OBMEs , 
						const class Slater_determinant &SD ,
						class array<TYPE> &diagonal_part)
{
  const int N_valence_nucleons = SD.get_N_valence_nucleons ();

  const unsigned int Nrk = diagonal_part.dimension (0);
  
  diagonal_part = 0.0;

  for (int mu = 0 ; mu < N_valence_nucleons ; mu++)
    {
      const unsigned int state = SD[mu];

      for (unsigned int i = 0 ; i < Nrk ; i++)
	diagonal_part(i) += OBMEs(state , state , i);
    }
}







void scalar_strength::NBMEs_one_jump_mu_calc (
					      const class array<TYPE> &OBMEs_mu , 
					      const class jumps_data_out_to_in_str &one_jump_mu , 
					      class array<TYPE> &NBMEs_one_jump_mu)
{
  const unsigned int dimension_one_jump = one_jump_mu.get_dimension ();
  const unsigned int Nrk = NBMEs_one_jump_mu.dimension (0);

  for (unsigned int ii = 0 ; ii < dimension_one_jump ; ii++)
    {
      const class jumps_data_inSD_str &one_jump_mu_inSDmu = one_jump_mu(ii);

      const unsigned int mu_in  = one_jump_mu_inSDmu.get_mu_in ();
      const unsigned int mu_out = one_jump_mu_inSDmu.get_mu_out ();

      const unsigned int total_bin_phase_mu = one_jump_mu_inSDmu.get_total_bin_phase ();

      const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);
      
      for (unsigned int i = 0 ; i < Nrk ; i++) 
	{
	  const TYPE OBME_mu = OBMEs_mu(mu_in , mu_out , i);

	  NBMEs_one_jump_mu(i , ii) = (total_phase_mu == 1) ? (OBME_mu) : (-OBME_mu);
	}
    }
}






void scalar_strength::scalar_strength_part_calc (
						 const class jumps_data_out_to_in_str &jump , 
						 const class array<bool> &is_configuration_accepted_tab , 
						 const class array<unsigned long int> &total_PSI_in_indices , 
						 const class array<TYPE> &NBMEs_one_jump , 
						 const TYPE &PSI_OUT_component_TRS_factor , 
						 const class GSM_vector &PSI_IN_full ,
						 class array<TYPE> &scalar_strength_part_tab)
{
  const unsigned int Nrk = scalar_strength_part_tab.dimension (0);

  for (unsigned int i = 0 ; i < Nrk ; i++) 
    {
      TYPE component_part = 0.0;

      const unsigned int dimension = jump.get_dimension ();

      for (unsigned int ii = 0 ; ii < dimension ; ii++)
	{
	  const bool is_configuration_accepted = is_configuration_accepted_tab(ii);

	  if (is_configuration_accepted) 
	    {
	      const unsigned long int total_PSI_in_index = total_PSI_in_indices(ii);
	      
	      const TYPE &PSI_in_component = PSI_IN_full[total_PSI_in_index];

	      const TYPE &NBME = NBMEs_one_jump(i , ii);
	      
	      component_part += PSI_in_component*NBME;
	    }
	}

      scalar_strength_part_tab(i) += PSI_OUT_component_TRS_factor*component_part;
    }
}






void scalar_strength::pp_nn_diagonal_part_calc (
						const class array<TYPE> &OBMEs_mu ,
						const class GSM_vector &PSI_IN_full ,
						const class GSM_vector &PSI_OUT , 
						class array<TYPE> &scalar_strength_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
      
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);

  const int N_valence_nucleons = data.get_N_valence_nucleons ();
  
  const class array_BP_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const class array_of_SD &SD_set = data.get_SD_set ();
  
  const unsigned int Nrk = scalar_strength_tab.dimension (0);

  const bool is_it_TRS = GSM_vector_helper_OUT.get_is_it_TRS ();
  
  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = data.get_SD_TRS_indices ();
  
  const int iM = GSM_vector_helper_OUT.get_iM ();

  const unsigned int BP = GSM_vector_helper_OUT.get_BP ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector     = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector_TRS ();
  
  const unsigned long int first_total_PSI_index = GSM_vector_helper_OUT.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper_OUT.get_last_total_PSI_index ();
    
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_SD_index_min = GSM_vector_helper_OUT.get_total_SD_index_min ();
  const unsigned long int total_SD_index_max = GSM_vector_helper_OUT.get_total_SD_index_max ();
  
  if (total_SD_index_min > total_SD_index_max) return;
  
  class array<class Slater_determinant> SD_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > diagonal_part_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > scalar_strength_part_tabs(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SD_tab(i).allocate (N_valence_nucleons);
      
      diagonal_part_tab(i).allocate (Nrk);

      scalar_strength_part_tabs(i).allocate (Nrk);

      scalar_strength_part_tabs(i) = 0.0;
    }

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_SD_index = total_SD_index_min ; total_SD_index <= total_SD_index_max ; total_SD_index++)
    {
      const class SD_quantum_numbers &SD_qn = SD_quantum_numbers_tab(total_SD_index);

      const int iM_SD = SD_qn.get_iM ();

      if (iM_SD != iM) continue;

      const unsigned int BP_SD = SD_qn.get_BP ();

      if (BP_SD != BP) continue;
 
      const unsigned int n_scat = SD_qn.get_n_scat ();

      const unsigned int iC = SD_qn.get_iC ();

      const int n_holes = n_holes_table(BP , n_scat , iC);
	  
      const int E = E_hw_table(BP , n_scat , iC);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E , n_holes_max , n_scat_max , E_max_hw)) continue;
      
      const unsigned int SD_index = SD_qn.get_SD_index ();

      const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions_GSM_vector(n_scat , iC);

      const unsigned long int total_PSI_index = sum_dimensions_configuration_fixed + SD_index;
      
      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
	{
	  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;
      
	  const unsigned int SD_TRS_index = (is_it_TRS) ? (SD_TRS_indices(BP , n_scat , iC , iM , SD_index)) : (NADA);

	  const unsigned long int sum_dimensions_configuration_fixed_TRS = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(n_scat , iC)) : (NADA);

	  const unsigned long int TRS_total_PSI_index = (is_it_TRS) ? (sum_dimensions_configuration_fixed_TRS + SD_TRS_index) : (NADA);
	  
	  if (!is_it_TRS || (TRS_total_PSI_index >= total_PSI_index))
	    {
	      const TYPE &PSI_OUT_component = PSI_OUT[PSI_index];						  

	      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_index == total_PSI_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
						  
	      const unsigned int i_thread = OpenMP_thread_number_determine ();

	      class Slater_determinant &SD = SD_tab(i_thread);
      
	      class array<TYPE> &diagonal_part = diagonal_part_tab(i_thread);

	      class array<TYPE> &scalar_strength_part_tab = scalar_strength_part_tabs(i_thread);
			 
	      const TYPE &PSI_IN_component = PSI_IN_full[total_PSI_index];

	      const TYPE PSI_components_TRS_factor_product = PSI_IN_component*PSI_OUT_component_TRS_factor;
      
	      SD = SD_set(BP , n_scat , iC , iM , SD_index);
      
	      diagonal_part_pp_nn_calc (OBMEs_mu , SD , diagonal_part);
      
	      scalar_strength_part_tab += diagonal_part*PSI_components_TRS_factor_product;
	    }
	}
    }
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    scalar_strength_tab += scalar_strength_part_tabs(i);
}










void scalar_strength::pp_nn_one_jump_part_calc (
						const class array<TYPE> &OBMEs_mu ,
						const class GSM_vector &PSI_IN_full ,
						const class GSM_vector &PSI_OUT , 
						class array<TYPE> &scalar_strength_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
      
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);
  
  const unsigned int dimension_1p1h_space_BP_iM_fixed_max = data.get_dimension_1p1h_space_BP_iM_fixed_max ();

  const class array_BP_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const unsigned int Nrk = scalar_strength_tab.dimension (0);

  const bool is_it_TRS = GSM_vector_helper_OUT.get_is_it_TRS ();
  
  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = data.get_SD_TRS_indices ();
  
  const int iM = GSM_vector_helper_OUT.get_iM ();

  const unsigned int BP = GSM_vector_helper_OUT.get_BP ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector_TRS ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper_OUT.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper_OUT.get_last_total_PSI_index ();
    
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_outSD_index_min = GSM_vector_helper_OUT.get_total_SD_index_min ();
  const unsigned long int total_outSD_index_max = GSM_vector_helper_OUT.get_total_SD_index_max ();
  
  if (total_outSD_index_min > total_outSD_index_max) return;
  
  class array<class jumps_data_out_to_in_str> one_jump_mu_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_in_indices_one_jump_mu_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > NBMEs_one_jump_mu_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > scalar_strength_part_tabs(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_mu_tab(i).allocate (ONE_JUMP , space , truncation_hw , truncation_ph , dimension_1p1h_space_BP_iM_fixed_max);

      total_PSI_in_indices_one_jump_mu_tab(i).allocate (dimension_1p1h_space_BP_iM_fixed_max);

      NBMEs_one_jump_mu_tab(i).allocate (Nrk , dimension_1p1h_space_BP_iM_fixed_max);

      scalar_strength_part_tabs(i).allocate (Nrk);

      scalar_strength_part_tabs(i) = 0.0;
    }

  class array<bool> is_configuration_accepted_tab(dimension_1p1h_space_BP_iM_fixed_max);

  is_configuration_accepted_tab = true;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSD_index = total_outSD_index_min ; total_outSD_index <= total_outSD_index_max ; total_outSD_index++)
    {
      const class SD_quantum_numbers &outSD_qn = SD_quantum_numbers_tab(total_outSD_index);

      const int iM_out = outSD_qn.get_iM ();

      if (iM_out != iM) continue;

      const unsigned int BP_out = outSD_qn.get_BP ();

      if (BP_out != BP) continue;
 
      const unsigned int n_scat_out = outSD_qn.get_n_scat ();

      const unsigned int iC_out = outSD_qn.get_iC ();

      const int n_holes_out = n_holes_table(BP , n_scat_out , iC_out);
      
      const int E_out = E_hw_table(BP , n_scat_out , iC_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out , n_holes_max , n_scat_max , E_max_hw)) continue;
      
      const unsigned int outSD_index = outSD_qn.get_SD_index ();

      const unsigned long int sum_dimensions_configuration_fixed_out = sum_dimensions_GSM_vector(n_scat_out , iC_out);

      const unsigned long int total_PSI_out_index = sum_dimensions_configuration_fixed_out + outSD_index;
      
      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
	{
	  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
      
	  const unsigned int outSD_TRS_index = (is_it_TRS) ? (SD_TRS_indices(BP , n_scat_out , iC_out , iM , outSD_index)) : (NADA);

	  const unsigned long int sum_dimensions_configuration_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(n_scat_out , iC_out)) : (NADA);
	  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (sum_dimensions_configuration_fixed_TRS_out + outSD_TRS_index) : (NADA);
	  		  
	  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
	    {
	      const TYPE &PSI_OUT_component = PSI_OUT[PSI_out_index];						  

	      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_out_index == total_PSI_out_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
						  
	      const unsigned int i_thread = OpenMP_thread_number_determine ();

	      class jumps_data_out_to_in_str &one_jump_mu = one_jump_mu_tab(i_thread);

	      class array<unsigned long int> &total_PSI_in_indices_one_jump_mu = total_PSI_in_indices_one_jump_mu_tab(i_thread);

	      class array<TYPE> &NBMEs_one_jump_mu = NBMEs_one_jump_mu_tab(i_thread);

	      class array<TYPE> &scalar_strength_part_tab = scalar_strength_part_tabs(i_thread);
      	
	      one_jump_mu.one_jump_mu_store (BP , iM , n_holes_max , n_scat_max , E_max_hw , BP , n_scat_out , iC_out , iM , outSD_index , data);
      
	      const unsigned int dimension_one_jump = one_jump_mu.get_dimension ();
      
	      if (dimension_one_jump > 0)
		{
		  NBMEs_one_jump_mu_calc (OBMEs_mu , one_jump_mu , NBMEs_one_jump_mu);
	  
		  bool is_there_one_jump_calc = false;
	  
		  total_PSI_in_indices_pp_nn_fill (one_jump_mu , GSM_vector_helper_OUT , total_PSI_in_indices_one_jump_mu , is_there_one_jump_calc);
	  
		  if (is_there_one_jump_calc)
		    scalar_strength_part_calc (one_jump_mu , is_configuration_accepted_tab , total_PSI_in_indices_one_jump_mu , NBMEs_one_jump_mu ,
					       PSI_OUT_component_TRS_factor , PSI_IN_full , scalar_strength_part_tab);
		}
	    }
	}
    }
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    scalar_strength_tab += scalar_strength_part_tabs(i);
}










void scalar_strength::diagonal_part_pn_prot_part_calc (
						       const class array<TYPE> &OBMEs_p , 
						       const class GSM_vector &PSI_IN_full ,
						       const class GSM_vector &PSI_OUT , 
						       class array<TYPE> &scalar_strength_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
        
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
    
  const int Zval = prot_data.get_N_valence_nucleons ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const unsigned int BP = GSM_vector_helper_OUT.get_BP ();
  
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int iM = GSM_vector_helper_OUT.get_iM ();

  const int iMp_min_M = GSM_vector_helper_OUT.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper_OUT.get_iMp_max_M ();
  
  const int iMp_max = prot_data.get_iM_max ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  
  const unsigned int Nrk = scalar_strength_tab.dimension (0);
  
  const unsigned long int first_total_PSI_index = GSM_vector_helper_OUT.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper_OUT.get_last_total_PSI_index ();
  	       
  const bool is_it_TRS = GSM_vector_helper_OUT.get_is_it_TRS ();
  
  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_data.get_SD_TRS_indices ();
  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_data.get_SD_TRS_indices ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper_OUT.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper_OUT.get_iCn_max_process_tab ();

  const unsigned long int total_SDp_index_min = GSM_vector_helper_OUT.get_total_SDp_index_min ();
  const unsigned long int total_SDp_index_max = GSM_vector_helper_OUT.get_total_SDp_index_max ();

  if (total_SDp_index_min > total_SDp_index_max) return;
  
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_prot_tab = prot_data.get_SD_quantum_numbers_tab ();
  
  class array<class Slater_determinant> SDp_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > PSI_components_TRS_factor_product_diagonal_p_part_tabs(NUMBER_OF_THREADS);

  class array<class array<TYPE> > diagonal_p_part_tabs(NUMBER_OF_THREADS);

  class array<class array<TYPE> > scalar_strength_part_tabs(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SDp_tab(i).allocate (Zval);
      
      PSI_components_TRS_factor_product_diagonal_p_part_tabs(i).allocate (Nrk);

      diagonal_p_part_tabs(i).allocate (Nrk);

      scalar_strength_part_tabs(i).allocate (Nrk);

      scalar_strength_part_tabs(i) = 0.0;
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_SDp_index = total_SDp_index_min ; total_SDp_index <= total_SDp_index_max ; total_SDp_index++)
    {
      const class SD_quantum_numbers &SDp_qn = SD_quantum_numbers_prot_tab(total_SDp_index);

      const int iMp = SDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = SDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int n_scat_p = SDp_qn.get_n_scat ();
	
      const unsigned int iCp = SDp_qn.get_iC ();

      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const int iMn = iM - iMp;

      const int TRS_iMp = iMp_max - iMp;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);

      if (dimension_SDp == 0) continue;
      
      const unsigned int SDp_index = SDp_qn.get_SD_index ();
      
      const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , n_scat_p , iCp , iMp , SDp_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class Slater_determinant &SDp = SDp_tab(i_thread);
      
      class array<TYPE> &PSI_components_TRS_factor_product_diagonal_p_part_tab = PSI_components_TRS_factor_product_diagonal_p_part_tabs(i_thread);

      class array<TYPE> &diagonal_p_part_tab = diagonal_p_part_tabs(i_thread);

      class array<TYPE> &scalar_strength_part_tab = scalar_strength_part_tabs(i_thread);
            
      bool is_scalar_strength_p_part_calculated = false;
      
      SDp = SDp_set(BPp , n_scat_p , iCp , iMp , SDp_index);
      
      diagonal_p_part_tab = 0.0;
		      
      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_process_tab(BPn , n_scat_n);
	  const unsigned int iCn_max = iCn_max_process_tab(BPn , n_scat_n);
	  
	  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
	      const int En = En_hw_table(BPn , n_scat_n , iCn);
			      
	      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw))
		{
		  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

		  if (dimension_SDn == 0) continue;
		  
		  const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector_OUT(BPp , n_scat_p , n_scat_n , iCp , iCn , iMp);

		  const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;

		  const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDn_minus_one;
		  
		  if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
		    {				     					  
		      if (!is_scalar_strength_p_part_calculated)
			{
			  diagonal_part_pp_nn_calc (OBMEs_p , SDp , diagonal_p_part_tab);
			  
			  is_scalar_strength_p_part_calculated = true;
			}
		      
		      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS_OUT(BPp , n_scat_p , n_scat_n , iCp , iCn , TRS_iMp)) : (NADA);
				      
		      const unsigned long int TRS_total_PSI_index_zero_SDp_fixed = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS + dimension_SDn*SDp_TRS_index) : (NADA);
		      
		      const unsigned long int total_SDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , n_scat_n , iCn , iMn , 0)) : (NADA);
		      
		      for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
			{
			  const unsigned long int total_PSI_index = total_PSI_index_zero + SDn_index;
			  
			  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
			    {
			      const unsigned long int total_SDn_TRS_indices_index = (is_it_TRS) ? (total_SDn_TRS_indices_zero_index + SDn_index) : (NADA);

			      const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_SDn_TRS_indices_index]) : (NADA);
			      
			      const unsigned long int TRS_total_PSI_index = (is_it_TRS) ? (TRS_total_PSI_index_zero_SDp_fixed + SDn_TRS_index) : (NADA);
			      
			      if (!is_it_TRS || (TRS_total_PSI_index >= total_PSI_index))
				{
				  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;
			  
				  const TYPE &PSI_IN_component = PSI_IN_full[total_PSI_index];

				  const TYPE &PSI_OUT_component = PSI_OUT[PSI_index];

				  const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_index == total_PSI_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
				  
				  const TYPE PSI_components_TRS_factor_product = PSI_IN_component*PSI_OUT_component_TRS_factor;
				  
				  PSI_components_TRS_factor_product_diagonal_p_part_tab = diagonal_p_part_tab;
				  PSI_components_TRS_factor_product_diagonal_p_part_tab *= PSI_components_TRS_factor_product;

				  scalar_strength_part_tab += PSI_components_TRS_factor_product_diagonal_p_part_tab;
				}}}}}}}}
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    scalar_strength_tab += scalar_strength_part_tabs(i);
}









void scalar_strength::diagonal_part_pn_neut_part_calc (
						       const class array<TYPE> &OBMEs_n , 
						       const class GSM_vector &PSI_IN_full ,
						       const class GSM_vector &PSI_OUT , 
						       class array<TYPE> &scalar_strength_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
    
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const unsigned int BP = GSM_vector_helper_OUT.get_BP ();
  
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int iM = GSM_vector_helper_OUT.get_iM ();

  const int iMn_min_M = GSM_vector_helper_OUT.get_iMn_min_M ();
  const int iMn_max_M = GSM_vector_helper_OUT.get_iMn_max_M ();

  const int iMp_max = prot_data.get_iM_max ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_OUT     = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_of_SD &SDn_set = neut_data.get_SD_set ();
  
  const unsigned int Nrk = scalar_strength_tab.dimension (0);

  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper_OUT.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper_OUT.get_iCp_max_process_tab ();
  
  const unsigned long int total_SDn_index_min = GSM_vector_helper_OUT.get_total_SDn_index_min ();
  const unsigned long int total_SDn_index_max = GSM_vector_helper_OUT.get_total_SDn_index_max ();

  if (total_SDn_index_min > total_SDn_index_max) return;
      
  const unsigned long int first_total_PSI_index = GSM_vector_helper_OUT.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper_OUT.get_last_total_PSI_index ();
  
  const bool is_it_TRS = GSM_vector_helper_OUT.get_is_it_TRS ();
  
  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_data.get_SD_TRS_indices ();
  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_data.get_SD_TRS_indices ();
  	      
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_neut_tab = neut_data.get_SD_quantum_numbers_tab ();
  
  class array<class Slater_determinant> SDn_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > PSI_components_TRS_factor_product_diagonal_n_part_tabs(NUMBER_OF_THREADS);

  class array<class array<TYPE> > diagonal_n_part_tabs(NUMBER_OF_THREADS);

  class array<class array<TYPE> > scalar_strength_part_tabs(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SDn_tab(i).allocate (Nval);
      
      PSI_components_TRS_factor_product_diagonal_n_part_tabs(i).allocate (Nrk);

      diagonal_n_part_tabs(i).allocate (Nrk);

      scalar_strength_part_tabs(i).allocate (Nrk);

      scalar_strength_part_tabs(i) = 0.0;
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_SDn_index = total_SDn_index_min ; total_SDn_index <= total_SDn_index_max ; total_SDn_index++)
    {
      const class SD_quantum_numbers &SDn_qn = SD_quantum_numbers_neut_tab(total_SDn_index);

      const int iMn = SDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = SDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int n_scat_n = SDn_qn.get_n_scat ();
	
      const unsigned int iCn = SDn_qn.get_iC ();

      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
      const int En = En_hw_table(BPn , n_scat_n , iCn);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
      const int iMp = iM - iMn;

      const int TRS_iMp = iMp_max - iMp;

      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

      if (dimension_SDn == 0) continue;
      
      const unsigned int SDn_index = SDn_qn.get_SD_index ();
      
      const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , n_scat_n , iCn , iMn , SDn_index)) : (NADA);
		  
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class Slater_determinant &SDn = SDn_tab(i_thread);
      
      class array<TYPE> &PSI_components_TRS_factor_product_diagonal_n_part_tab = PSI_components_TRS_factor_product_diagonal_n_part_tabs(i_thread);

      class array<TYPE> &diagonal_n_part_tab = diagonal_n_part_tabs(i_thread);

      class array<TYPE> &scalar_strength_part_tab = scalar_strength_part_tabs(i_thread);
					      
      bool is_scalar_strength_n_part_calculated = false;

      SDn = SDn_set(BPn , n_scat_n , iCn , iMn , SDn_index);
      
      diagonal_n_part_tab = 0.0;					  

      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , n_scat_p);
				  
	  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

	      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);
				      
	      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph ,
					      n_holes_p  , n_scat_p   , Ep ,
					      n_holes_n  , n_scat_n   , En ,
					      n_holes_max , n_scat_max , E_max_hw))
		{
		  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);

		  if (dimension_SDp == 0) continue;
				  
		  const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;
				  
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector_OUT(BPp , n_scat_p , n_scat_n , iCp , iCn , iMp);
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS_OUT(BPp , n_scat_p , n_scat_n , iCp , iCn , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + SDn_index;

		  const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDn*dimension_SDp_minus_one;
  
		  if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
		    {						      
		      const unsigned long int TRS_total_PSI_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS + SDn_TRS_index) : (NADA);
				      
		      const unsigned long int total_SDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , n_scat_p , iCp , iMp , 0)) : (NADA);
					      
		      if (!is_scalar_strength_n_part_calculated)
			{
			  diagonal_part_pp_nn_calc (OBMEs_n , SDn , diagonal_n_part_tab);
			  
			  is_scalar_strength_n_part_calculated = true;
			}
 
		      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
			{					 		      
			  const unsigned long int total_PSI_index = total_PSI_index_zero + dimension_SDn*SDp_index;
					  
			  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
			    {
			      const unsigned long int total_SDp_TRS_indices_index = (is_it_TRS) ? (total_SDp_TRS_indices_zero_index + SDp_index) : (NADA);

			      const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_SDp_TRS_indices_index]) : (NADA);
					      
			      const unsigned long int TRS_total_PSI_index = (is_it_TRS) ? (TRS_total_PSI_index_zero + dimension_SDn*SDp_TRS_index) : (NADA);

			      if (!is_it_TRS || (TRS_total_PSI_index >= total_PSI_index))
				{
				  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;
			  
				  const TYPE &PSI_IN_component = PSI_IN_full[total_PSI_index];

				  const TYPE &PSI_OUT_component = PSI_OUT[PSI_index];

				  const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_index == total_PSI_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);

				  const TYPE PSI_components_TRS_factor_product = PSI_IN_component*PSI_OUT_component_TRS_factor;

				  PSI_components_TRS_factor_product_diagonal_n_part_tab = diagonal_n_part_tab;
				  PSI_components_TRS_factor_product_diagonal_n_part_tab *= PSI_components_TRS_factor_product;

				  scalar_strength_part_tab += PSI_components_TRS_factor_product_diagonal_n_part_tab;
				}}}}}}}}
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    scalar_strength_tab += scalar_strength_part_tabs(i);
}









void scalar_strength::one_jump_p_part_pn_calc (
					       const class array<TYPE> &OBMEs_p , 
					       const class GSM_vector &PSI_IN_full ,
					       const class GSM_vector &PSI_OUT , 
					       class array<TYPE> &scalar_strength_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_IN_full = PSI_IN_full.get_GSM_vector_helper ();

  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  
  const unsigned int BP = GSM_vector_helper_OUT.get_BP ();

  const int iM = GSM_vector_helper_OUT.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper_OUT.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper_OUT.get_iMp_max_M ();

  const int iMp_max = prot_data.get_iM_max ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const unsigned int dimension_p_1p1h_space_BP_iM_fixed_max = prot_data.get_dimension_1p1h_space_BP_iM_fixed_max ();
  
  const bool is_it_TRS = GSM_vector_helper_OUT.get_is_it_TRS ();
  
  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_data.get_SD_TRS_indices ();
  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_data.get_SD_TRS_indices ();
  
  const class array_BP_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper_OUT.get_all_dimensions_SDn_zero_tab ();

  const unsigned int Nrk = scalar_strength_tab.dimension (0);
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper_OUT.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper_OUT.get_last_total_PSI_index ();

  const class array<class SD_quantum_numbers> &SD_quantum_numbers_prot_tab = prot_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper_OUT.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper_OUT.get_iCn_max_process_tab ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper_OUT.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper_OUT.get_total_SDp_index_max ();

  if (total_outSDp_index_min > total_outSDp_index_max) return;
    
  class array<class jumps_data_out_to_in_str> one_jump_p_tab(NUMBER_OF_THREADS);	      

  class array<class array<TYPE> > NBMEs_one_jump_p_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_configuration_accepted_one_jump_p_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_in_indices_one_jump_p_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > scalar_strength_part_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {      
      one_jump_p_tab(i).allocate (ONE_JUMP , PROTONS_NEUTRONS , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_iM_fixed_max);

      NBMEs_one_jump_p_tab(i).allocate (Nrk , dimension_p_1p1h_space_BP_iM_fixed_max);

      is_configuration_accepted_one_jump_p_tabs(i).allocate (dimension_p_1p1h_space_BP_iM_fixed_max);

      total_PSI_in_indices_one_jump_p_tab(i).allocate (dimension_p_1p1h_space_BP_iM_fixed_max);

      scalar_strength_part_tabs(i).allocate (Nrk);

      scalar_strength_part_tabs(i) = 0.0;
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SD_quantum_numbers_prot_tab(total_outSDp_index);

      const int iMp = outSDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = outSDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp , n_scat_p_out , iCp_out);
	      
      const int Ep_out = Ep_hw_table(BPp , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , n_scat_p_out , iCp_out , iMp);

      if (dimension_outSDp == 0) continue;
      
      const int iMn = iM - iMp;

      const int TRS_iMp = iMp_max - iMp;

      const unsigned int outSDp_index =  outSDp_qn.get_SD_index ();
 
      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , n_scat_p_out , iCp_out , iMp , outSDp_index)) : (NADA);

      const unsigned int i_thread = OpenMP_thread_number_determine ();	      
	      
      class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(i_thread);

      class array<TYPE> &NBMEs_one_jump_p = NBMEs_one_jump_p_tab(i_thread);

      class array<bool> &is_configuration_accepted_one_jump_p_tab = is_configuration_accepted_one_jump_p_tabs(i_thread);

      class array<unsigned long int> &total_PSI_in_indices_one_jump_p = total_PSI_in_indices_one_jump_p_tab(i_thread);

      class array<TYPE> &scalar_strength_part_tab = scalar_strength_part_tabs(i_thread);
      
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , n_scat_p_out , iCp_out , iMp);

      if (all_dimensions_SDn_zero) continue;
		  
      bool one_jump_p_calculated = false;

      bool is_there_one_jump_calc_all = true;

      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && is_there_one_jump_calc_all ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_process_tab(BPn , n_scat_n);
	  const unsigned int iCn_max = iCn_max_process_tab(BPn , n_scat_n);
	  
	  for (unsigned int iCn = iCn_min ; (iCn <= iCn_max) && is_there_one_jump_calc_all ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
	      const int En = En_hw_table(BPn , n_scat_n , iCn);
	  
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

	      if (dimension_SDn == 0) continue;

	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , n_scat_p_out , n_scat_n , iCp_out , iCn , iMp);
				  
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_SDn*outSDp_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_SDn_minus_one;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , n_scat_p_out , n_scat_n , iCp_out , iCn , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_SDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , n_scat_n , iCn , iMn , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_SDn*outSDp_TRS_index) : (NADA);
				      
		  if (!one_jump_p_calculated)
		    {
		      one_jump_p.one_jump_mu_store (BPp , iMp , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp , n_scat_p_out , iCp_out , iMp , outSDp_index , prot_data);
					  
		      one_jump_p_calculated = true;
					  
		      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
					  
		      is_there_one_jump_calc_all = (dimension_one_jump_p > 0);
					  					  
		      if (is_there_one_jump_calc_all) NBMEs_one_jump_mu_calc (OBMEs_p , one_jump_p , NBMEs_one_jump_p);
		    }

		  if (!is_there_one_jump_calc_all) continue;
					  
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + SDn_index;

		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
					      
			  const unsigned long int total_SDn_TRS_indices_index = (is_it_TRS) ? (total_SDn_TRS_indices_zero_index + SDn_index) : (NADA);

			  const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_SDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + SDn_TRS_index) : (NADA);
						      
			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    {
			      bool is_there_one_jump_calc = false;
						  
			      is_configuration_accepted_total_PSI_in_indices_prot_fill (BPn , n_holes_n , n_scat_n , iCn , iMn , SDn_index , En , one_jump_p , GSM_vector_helper_IN_full , dimension_SDn ,
											is_configuration_accepted_one_jump_p_tab , total_PSI_in_indices_one_jump_p , is_there_one_jump_calc);

			      if (is_there_one_jump_calc)
				{
				  const TYPE &PSI_OUT_component = PSI_OUT[PSI_out_index];

				  const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_out_index == total_PSI_out_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);

				  scalar_strength_part_calc (one_jump_p , is_configuration_accepted_one_jump_p_tab , total_PSI_in_indices_one_jump_p ,
							     NBMEs_one_jump_p , PSI_OUT_component_TRS_factor , PSI_IN_full , scalar_strength_part_tab);
				}}}}}}}}
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    scalar_strength_tab += scalar_strength_part_tabs(i);
}








void scalar_strength::one_jump_n_part_pn_calc (
					       const class array<TYPE> &OBMEs_n ,
					       const class GSM_vector &PSI_IN_full ,
					       const class GSM_vector &PSI_OUT , 
					       class array<TYPE> &scalar_strength_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_IN_full = PSI_IN_full.get_GSM_vector_helper ();

  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
    
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper_OUT.get_BP ();
  
  const int iM = GSM_vector_helper_OUT.get_iM ();
  
  const int iMn_min_M = GSM_vector_helper_OUT.get_iMn_min_M ();
  const int iMn_max_M = GSM_vector_helper_OUT.get_iMn_max_M ();
  
  const int iMp_max = prot_data.get_iM_max (); 
  
  const unsigned int dimension_n_1p1h_space_BP_iM_fixed_max = neut_data.get_dimension_1p1h_space_BP_iM_fixed_max ();
    
  const unsigned int Nrk = scalar_strength_tab.dimension (0);
  
  const bool is_it_TRS = GSM_vector_helper_OUT.get_is_it_TRS ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector     = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_neut_tab = neut_data.get_SD_quantum_numbers_tab ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
 
  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_data.get_SD_TRS_indices ();
  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_data.get_SD_TRS_indices ();

  const class array_BP_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper_OUT.get_all_dimensions_SDp_zero_tab ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper_OUT.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper_OUT.get_last_total_PSI_index ();

  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper_OUT.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper_OUT.get_iCp_max_process_tab ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper_OUT.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper_OUT.get_total_SDn_index_max ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
    
  class array<class jumps_data_out_to_in_str> one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > NBMEs_one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_configuration_accepted_one_jump_n_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_in_indices_one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > scalar_strength_part_tabs(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {      
      one_jump_n_tab(i).allocate (ONE_JUMP , PROTONS_NEUTRONS , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_iM_fixed_max);

      NBMEs_one_jump_n_tab(i).allocate (Nrk , dimension_n_1p1h_space_BP_iM_fixed_max);

      is_configuration_accepted_one_jump_n_tabs(i).allocate (dimension_n_1p1h_space_BP_iM_fixed_max);

      total_PSI_in_indices_one_jump_n_tab(i).allocate (dimension_n_1p1h_space_BP_iM_fixed_max);

      scalar_strength_part_tabs(i).allocate (Nrk);

      scalar_strength_part_tabs(i) = 0.0;
    }

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SD_quantum_numbers_neut_tab(total_outSDn_index);

      const int iMn = outSDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = outSDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn , n_scat_n_out , iCn_out);
      
      const int En_out = En_hw_table(BPn , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , n_scat_n_out , iCn_out , iMn);

      if (dimension_outSDn == 0) continue;
      
      const int iMp = iM - iMn;

      const int TRS_iMp = iMp_max - iMp;
            
      const unsigned int outSDn_index =  outSDn_qn.get_SD_index ();
      
      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , n_scat_n_out , iCn_out , iMn , outSDn_index)) : (NADA);
      
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , n_scat_n_out , iCn_out , iMn);

      if (all_dimensions_SDp_zero) continue;
		  
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	      
      class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(i_thread);

      class array<TYPE> &NBMEs_one_jump_n = NBMEs_one_jump_n_tab(i_thread);

      class array<bool> &is_configuration_accepted_one_jump_n_tab = is_configuration_accepted_one_jump_n_tabs(i_thread);

      class array<unsigned long int> &total_PSI_in_indices_one_jump_n = total_PSI_in_indices_one_jump_n_tab(i_thread);

      class array<TYPE> &scalar_strength_part_tab = scalar_strength_part_tabs(i_thread);

      bool one_jump_n_calculated = false;

      bool is_there_one_jump_calc_all = true;
  
      for (int n_scat_p = 0 ; n_scat_p <= (n_scat_max_p) && is_there_one_jump_calc_all ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , n_scat_p);
	  
	  for (unsigned int iCp = iCp_min ; (iCp <= iCp_max) && is_there_one_jump_calc_all ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

	      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);
	  
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_n_out , n_scat_n_out , En_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);

	      if (dimension_SDp == 0) continue;

	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , n_scat_p , n_scat_n_out , iCp , iCn_out , iMp);

	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_SDp_minus_one*dimension_outSDn;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , n_scat_p , n_scat_n_out , iCp , iCn_out , TRS_iMp)) : (NADA);

		  const unsigned long int total_SDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , n_scat_p , iCp , iMp , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);
				      
		  if (!one_jump_n_calculated)
		    {
		      one_jump_n.one_jump_mu_store (BPn , iMn , n_holes_max_n , n_scat_max_n , En_max_hw , BPn , n_scat_n_out , iCn_out , iMn , outSDn_index , neut_data);
					  
		      one_jump_n_calculated = true;

		      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
					  
		      is_there_one_jump_calc_all = (dimension_one_jump_n > 0);
					  
		      if (is_there_one_jump_calc_all) NBMEs_one_jump_mu_calc (OBMEs_n , one_jump_n , NBMEs_one_jump_n);
		    }

		  if (!is_there_one_jump_calc_all) continue;
					  
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + dimension_outSDn*SDp_index;

		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  const unsigned long int total_SDp_TRS_indices_index = (is_it_TRS) ? (total_SDp_TRS_indices_zero_index + SDp_index) : (NADA);

			  const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_SDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + dimension_outSDn*SDp_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
			    { 
			      bool is_there_one_jump_calc = false;
		      
			      is_configuration_accepted_total_PSI_in_indices_neut_fill (BPp , n_holes_p , n_scat_p , iCp , iMp , SDp_index , Ep , one_jump_n , GSM_vector_helper_IN_full , 
											is_configuration_accepted_one_jump_n_tab , total_PSI_in_indices_one_jump_n , is_there_one_jump_calc);

			      if (is_there_one_jump_calc)
				{
				  const TYPE &PSI_OUT_component = PSI_OUT[PSI_out_index];

				  const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_out_index == total_PSI_out_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
			      
				  scalar_strength_part_calc (one_jump_n , is_configuration_accepted_one_jump_n_tab , total_PSI_in_indices_one_jump_n ,
							     NBMEs_one_jump_n , PSI_OUT_component_TRS_factor , PSI_IN_full , scalar_strength_part_tab);
						  
				}}}}}}}}
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    scalar_strength_tab += scalar_strength_part_tabs(i);
}








void scalar_strength::calc (
			    class GSM_vector &PSI_IN_full , 
			    const class array<TYPE> &OBMEs_p , 
			    const class array<TYPE> &OBMEs_n , 
			    const class GSM_vector &PSI_IN ,
			    const class GSM_vector &PSI_OUT , 
			    class array<TYPE> &prot_scalar_strength_tab , 
			    class array<TYPE> &neut_scalar_strength_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_IN  = PSI_IN.get_GSM_vector_helper ();
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  prot_scalar_strength_tab = 0.0;
  neut_scalar_strength_tab = 0.0;
  
  const unsigned int BP_IN  = GSM_vector_helper_IN.get_BP ();
  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();

  if (BP_OUT != BP_IN) return;
  
  const int iM_IN  = GSM_vector_helper_IN.get_iM ();
  const int iM_OUT = GSM_vector_helper_OUT.get_iM ();

  if (iM_OUT != iM_IN) return;
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
 
  const class GSM_vector_helper_class dummy_helper;

  class nucleons_data &prot_data = GSM_vector_helper_IN.get_prot_data ();
  class nucleons_data &neut_data = GSM_vector_helper_IN.get_neut_data ();

  class GSM_vector_helper_class GSM_vector_helper_IN_full;

  GSM_vector_helper_IN_full.allocate_fill_without_MPI_parallelization (GSM_vector_helper_IN);
  
  PSI_IN_full.change_GSM_vector_helper_reallocate (GSM_vector_helper_IN_full);
  
  PSI_IN_full.full_vector_fill (PSI_IN);      

  configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , true , false , false , false ,
							       GSM_vector_helper_IN_full , GSM_vector_helper_OUT , dummy_helper , prot_data , neut_data);
     
  switch (space)
    {
    case PROTONS_ONLY:  
      {
	pp_nn_diagonal_part_calc (OBMEs_p , PSI_IN_full , PSI_OUT , prot_scalar_strength_tab);	
	pp_nn_one_jump_part_calc (OBMEs_p , PSI_IN_full , PSI_OUT , prot_scalar_strength_tab);
	
      } break;
      
    case NEUTRONS_ONLY:
      {
	pp_nn_diagonal_part_calc (OBMEs_n , PSI_IN_full , PSI_OUT , neut_scalar_strength_tab);	
	pp_nn_one_jump_part_calc (OBMEs_n , PSI_IN_full , PSI_OUT , neut_scalar_strength_tab);
	
      } break;
 
    case PROTONS_NEUTRONS:
      {
	diagonal_part_pn_prot_part_calc (OBMEs_p , PSI_IN_full , PSI_OUT , prot_scalar_strength_tab);	
	diagonal_part_pn_neut_part_calc (OBMEs_n , PSI_IN_full , PSI_OUT , neut_scalar_strength_tab);
      	
	one_jump_p_part_pn_calc (OBMEs_p , PSI_IN_full , PSI_OUT , prot_scalar_strength_tab);
	one_jump_n_part_pn_calc (OBMEs_n , PSI_IN_full , PSI_OUT , neut_scalar_strength_tab);
	
      } break;

    default: abort_all ();
    }

  PSI_IN_full.remove_GSM_vector_helper ();
  
#ifdef UseMPI

  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
  
  if (is_it_MPI_parallelized_local)
    {
      MPI_helper::Barrier ();
  
      prot_scalar_strength_tab.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
      neut_scalar_strength_tab.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
    }
  
#endif
}







