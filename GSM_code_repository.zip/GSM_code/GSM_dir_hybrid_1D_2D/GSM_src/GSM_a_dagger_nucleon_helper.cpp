#include "../GSM_include/GSM_include_def.h"

using namespace string_routines;
using namespace Wigner_signs;
using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;
using namespace correlated_state_routines;

// TYPE is double or complex
// -------------------------

// MPI transfer is sometimes done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

// mu means proton or neutron in routines with valence protons only or valence neutrons only.

// Classes a_dagger_nucleon_coupled_to_J_PSI_str, a_nucleon_PSI_str, a_nucleon_coupled_to_J_PSI_str are used only in closures and then are not commented.





// a+/a[nljm]|Psi[in]> and [a+/a[nlj]|Psi[in]>]^JM vector calculated and added to |Psi[out]> in the proton-neutron (pn), and proton-proton or neutron-neutron (pp, nn) case
// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One can add or remove a nucleon of quantum numbers nlj(m) here.
// If one calculates [a+/a[nljm]|Psi[in]>]^JM, one uses ..._coupled_to_J_... routines.
// Only the value of <Psi[out] | Op | Psi[in]> in the master process is meaningful after MPI reduction.
//
// Coupled case
// ------------
// One must have (-1)^l.Pi[in] = Pi[out] and \vec{j} + \vec{J[in]} = \vec{J[out]} otherwise <Psi[out] | [a+/a[nljm] | Psi[in]>]^JM = 0 (with JM = J_out, M_out).
// One uses: [a+[nljm]|Psi[in]>]^JM = \sum_{M(in] , m}              <J[in] M[in] j  m | J[out] M[out]> a+[nljm]|Psi[in]> (calculated from uncoupled case)
//            [a[nljm]|Psi[in]>]^JM = \sum_{M(in] , m} (-1)^(j - m) <J[in] M[in] j -m | J[out] M[out]>  a[nljm]|Psi[in]> (calculated from uncoupled case)
//
// Uncoupled case
// --------------
// One must have (-1)^l.Pi[in] = Pi[out] and m + M[in] = M[out] (a+), -m + M[in] = M[out] (a) otherwise <Psi[out] | a+/a[nljm] | Psi[in]> = 0.
//
// |nljm> and |Psi[in] are read from files, where components and basis Slater determinants are stored, the latter as sequences of one-body state indices.
// One adds one nucleon of quantum numbers |nljm> to an already existing |Psi[in]> many-body wave function. 
// This is used in GSM-CC, where one build composites this way, or for the calculation of overlap functions and spectroscopic factors.
//
// |nljm> and |Psi[in]> are given as input, with both components and basis Slater determinants.
// Thus: a+/a[nljm]|Psi[in]> = \sum_{SD_in} c_in[SD_in] a+/a[nljm]|SD[in]>.
// Thus, one loops over SD_in basis states, proton and neutron parts being taken into account separately (pn case only).
// If Slater determinants do not belong to the GSM model space of |Psi[out]>, which can occur with different truncation schemes used for |Psi[in]>, |Psi[out]>, they are ignored.
// One also always checks if Slater determinants verify truncations in terms of energy and number of particles in the continuum of the GSM model space of |Psi[out]>.
// a+/a[nljm]|SD[in]> is calculated with creation/annihilation operators, using stored occupied state indices of Slater determinants and reordering phases.
// One firstly checks if |nljm> is unoccupied (occupied for a) |SD[in]>. Otherwise, a+/a[nljm]|SD[in]> = 0.
// If a+/a[nljm]|SD[in]> is not trivially equal to zero, |nljm> is to added to |SD[in]> (see excitation_SD_add_and_bin_phase in GSM_Slater_determinant.cpp).
// Its proton and neutron parts are taken into account separately (pn case only).
// Once |SD> = a+/a[nljm]|SD[in]> is obtained, its basis index in a+/a[nljm]|Psi[in]> must be found to add c_in[SD_in] in |Psi[out]>.
// This is done with binary searches, where the indices of proton and neutron configurations (see GSM_configuration_construction_set.cpp) and then of Slater determinants (see GSM_SD_construction_set.cpp) are found.
// The basis index of |SD> can be then be calculated with the latter and the sum_GSM_vector_dimensions_class class of |Psi[out]> (see GSM_vector_dimensions.cpp for the definition of sum_GSM_vector_dimensions_class).
// 
// OpenMP and MPI parallelization can be used therein.
// If MPI parallelization is used and |Psi[out]> != 0, |Psi[out]> is firstly transfered to all nodes, as only the master process has a copy of it, and divided by the number of nodes.
// Consequently, the |Psi[out]> parts in all nodes can be summed up in the end to obtain |Psi[out]> -> |Psi[out]> + a+/a[nljm]|Psi[in]>
// One node takes care of one part of all c_in components, and the whole |nljm> vector is considered in each node for a fixed c_in component.
// OpenMP parallelization is done at the level of the loop on c_in components, which is the first loop of the routine
// Work arrays, one for each thread, are allocated to avoid race conditions.


void a_dagger_nucleon_helper::a_dagger_proton_PSI_IN_total_PSI_indices_components_calc_pn (
											   const class nljm_struct &phi_p_projectile ,
											   const class correlated_state_str &PSI_IN_qn ,
											   const class GSM_vector_helper_class &GSM_vector_helper_OUT ,
											   const class array<unsigned int> &inSDp_tab ,
											   const class array<unsigned int> &SDn_tab ,
											   const class array<TYPE> &PSI_IN_component_tab ,
											   const class array<bool> &is_inSDp_in_new_space_tab ,
											   const class array<bool> &is_SDn_in_new_space_tab ,
											   const class array<unsigned char> &reordering_bin_phases_p ,
											   const class array<unsigned char> &reordering_bin_phases_n ,
											   class array<unsigned int> &a_dagger_PSI_IN_total_PSI_indices ,
											   class array<TYPE> &a_dagger_PSI_IN_components)
{
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data (); 
 
  const class one_body_indices_str &one_body_indices_p = prot_data.get_one_body_indices ();
  
  const int n = phi_p_projectile.get_n ();
  const int l = phi_p_projectile.get_l ();
  
  const double j = phi_p_projectile.get_j (); 
  const double m = phi_p_projectile.get_m ();
  
  const unsigned int phi_p_added_index = one_body_indices_p(n , l , j , m);

  if (phi_p_added_index == OUT_OF_RANGE) error_message_print_abort ("Problem with the proton added");
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int Z_core = prot_data.get_Z_core ();

  const int Zval = prot_data.get_N_valence_nucleons (); 
  const int Nval = neut_data.get_N_valence_nucleons ();

  const int Z_IN = PSI_IN_qn.get_Z ();

  const int prot_hole_states_number = prot_data.get_hole_states_number ();
  
  const int Zval_IN = Z_IN - Z_core + prot_hole_states_number;
  
  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();
    
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();
  
  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();
  
  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
  
  const unsigned long int total_space_dimension_OUT = GSM_vector_helper_OUT.get_total_space_dimension ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  class array<class Slater_determinant>  inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cn_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (Zval_IN);
      outSDp_work_tab(i).allocate (Zval);
      
      SDn_work_tab(i).allocate (Nval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_out_work_tab(i).allocate (Zval);

      Cn_work_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);
    }
  
  a_dagger_PSI_IN_total_PSI_indices = total_space_dimension_OUT;

  a_dagger_PSI_IN_components = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int i = 0 ; i < space_dimension_IN ; i++)
    {
      if (!is_inSDp_in_new_space_tab(i) || !is_SDn_in_new_space_tab(i)) continue;
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      unsigned int bin_phase_p = reordering_bin_phases_p(i);
      unsigned int bin_phase_n = reordering_bin_phases_n(i);
	      
      class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

      for (int p = 0 ; p < Zval_IN ; p++) inSDp[p] = inSDp_tab(i , p);
		  
      if (!inSDp.is_valence_state_occupied (phi_p_added_index))
	{
	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);

	  inSDp.excitation_1p_and_bin_phase(phi_p_added_index , outSDp , bin_phase_p);

	  class configuration &Cp_out = Cp_out_work_tab(i_thread);

	  Cp_out.get_SD_configuration (phi_p_table , outSDp);

	  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_prot);
	      
	  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_prot);

	  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_prot);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	    
	  class Slater_determinant &SDn = SDn_work_tab(i_thread);

	  for (int n = 0 ; n < Nval ; n++) SDn[n] = SDn_tab(i , n);
		  
	  class configuration &Cn = Cn_work_tab(i_thread);

	  Cn.get_SD_configuration (phi_n_table , SDn);

	  const int n_holes_n = Cn.n_holes_determine (shells_qn_neut);
		  
	  const int En_hw = Cn.E_hw_determine (shells_qn_neut);

	  const int n_scat_n = Cn.n_scat_determine (shells_qn_neut); 

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	  
	  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	  class configuration &Cp_try = Cp_try_tab(i_thread);
	  class configuration &Cn_try = Cn_try_tab(i_thread);

	  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);

	  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_prot);

	  const unsigned int BPn = Cn.BP_determine (shells_qn_neut);

	  const int iMp_out = outSDp.iM_determine (phi_p_table);

	  const int iMn = SDn.iM_determine (phi_n_table);

	  const unsigned int iCp_out = Cp_out.index_search (BPp_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
	  const unsigned int iCn = Cn.index_search (BPn , n_scat_n , dimensions_configuration_n_set , configuration_n_set , Cn_try);

	  const unsigned int outSDp_index = outSDp.index_search (BPp_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
	  const unsigned int SDn_index = SDn.index_search (BPn , n_scat_n , iCn , iMn , dimensions_SDn_set , SDn_set , SDn_try);

	  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , n_scat_p_out , n_scat_n , iCp_out , iCn , iMp_out);
	  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);
			  
	  const unsigned int a_dagger_PSI_IN_total_PSI_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_SDn*outSDp_index + SDn_index;

	  const TYPE PSI_IN_component = PSI_IN_component_tab(i);
			  
	  a_dagger_PSI_IN_total_PSI_indices(i) = a_dagger_PSI_IN_total_PSI_index;

	  a_dagger_PSI_IN_components(i) = (bin_phase_p == bin_phase_n) ? (PSI_IN_component) : (-PSI_IN_component);
	}
    }
}






void a_dagger_nucleon_helper::a_dagger_neutron_PSI_IN_total_PSI_indices_components_calc_pn (
											    const class nljm_struct &phi_n_projectile ,
											    const class correlated_state_str &PSI_IN_qn ,
											    const class GSM_vector_helper_class &GSM_vector_helper_OUT , 
											    const class array<unsigned int> &SDp_tab ,
											    const class array<unsigned int> &inSDn_tab ,
											    const class array<TYPE> &PSI_IN_component_tab ,
											    const class array<bool> &is_SDp_in_new_space_tab ,
											    const class array<bool> &is_inSDn_in_new_space_tab ,
											    const class array<unsigned char> &reordering_bin_phases_p ,
											    const class array<unsigned char> &reordering_bin_phases_n ,
											    class array<unsigned int> &a_dagger_PSI_IN_total_PSI_indices ,
											    class array<TYPE> &a_dagger_PSI_IN_components)
{
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const class one_body_indices_str &one_body_indices_n = neut_data.get_one_body_indices ();
  
  const int n = phi_n_projectile.get_n ();
  const int l = phi_n_projectile.get_l ();
  
  const double j = phi_n_projectile.get_j (); 
  const double m = phi_n_projectile.get_m ();
  
  const unsigned int phi_n_added_index = one_body_indices_n(n , l , j , m);

  if (phi_n_added_index == OUT_OF_RANGE) error_message_print_abort ("Problem with the neutron added");
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int N_core = prot_data.get_N_core ();

  const int Zval = prot_data.get_N_valence_nucleons (); 
  const int Nval = neut_data.get_N_valence_nucleons ();

  const int N_IN = PSI_IN_qn.get_N ();

  const int neut_hole_states_number = neut_data.get_hole_states_number ();
  
  const int Nval_IN = N_IN - N_core + neut_hole_states_number;

  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();
    
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();
  
  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);

  const unsigned long int total_space_dimension_OUT = GSM_vector_helper_OUT.get_total_space_dimension ();
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSDn_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> Cp_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDn_work_tab(i).allocate (Nval_IN);
      outSDn_work_tab(i).allocate (Nval);

      SDp_work_tab(i).allocate (Zval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_work_tab(i).allocate (Zval);

      Cn_out_work_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);
    }
  
  a_dagger_PSI_IN_total_PSI_indices = total_space_dimension_OUT;

  a_dagger_PSI_IN_components = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int i = 0 ; i < space_dimension_IN ; i++)
    {
      if (!is_SDp_in_new_space_tab(i) || !is_inSDn_in_new_space_tab(i)) continue;
	      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      unsigned int bin_phase_p = reordering_bin_phases_p(i);
      unsigned int bin_phase_n = reordering_bin_phases_n(i);
	      
      class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

      for (int n = 0 ; n < Nval_IN ; n++) inSDn[n] = inSDn_tab(i , n);
		  
      if (!inSDn.is_valence_state_occupied (phi_n_added_index))
	{
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);

	  inSDn.excitation_1p_and_bin_phase (phi_n_added_index , outSDn , bin_phase_n);

	  class configuration &Cn_out = Cn_out_work_tab(i_thread);

	  Cn_out.get_SD_configuration (phi_n_table , outSDn);

	  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_neut);
	      
	  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_neut);
	  
	  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_neut);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	    
	  class Slater_determinant &SDp = SDp_work_tab(i_thread);

	  for (int p = 0 ; p < Zval ; p++) SDp[p] = SDp_tab(i , p);
			  
	  class configuration &Cp = Cp_work_tab(i_thread);

	  Cp.get_SD_configuration (phi_p_table , SDp);

	  const int n_holes_p = Cp.n_holes_determine (shells_qn_prot);
		  
	  const int Ep_hw = Cp.E_hw_determine (shells_qn_prot);

	  const int n_scat_p = Cp.n_scat_determine (shells_qn_prot);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	  
	  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	  class configuration &Cp_try = Cp_try_tab(i_thread);
	  class configuration &Cn_try = Cn_try_tab(i_thread);

	  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);

	  const unsigned int BPp = Cp.BP_determine (shells_qn_prot);
		      
	  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_neut);

	  const int iMp = SDp.iM_determine (phi_p_table);

	  const int iMn_out = outSDn.iM_determine (phi_n_table);
		  
	  const unsigned int iCp = Cp.index_search (BPp , n_scat_p , dimensions_configuration_p_set , configuration_p_set , Cp_try);

	  const unsigned int iCn_out = Cn_out.index_search (BPn_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);

	  const unsigned int SDp_index = SDp.index_search (BPp , n_scat_p , iCp , iMp , dimensions_SDp_set , SDp_set , SDp_try);

	  const unsigned int outSDn_index = outSDn.index_search (BPn_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try); 

	  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp , n_scat_p , n_scat_n_out , iCp , iCn_out , iMp);
	  
	  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);
			  
	  const unsigned int a_dagger_PSI_IN_total_PSI_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*SDp_index + outSDn_index;

	  const TYPE PSI_IN_component = PSI_IN_component_tab(i);
			  
	  a_dagger_PSI_IN_total_PSI_indices(i) = a_dagger_PSI_IN_total_PSI_index;

	  a_dagger_PSI_IN_components(i) = (bin_phase_p == bin_phase_n) ? (PSI_IN_component) : (-PSI_IN_component);
	}
    }
}










void a_dagger_nucleon_helper::a_dagger_mu_PSI_IN_total_PSI_indices_components_calc_pp_nn (
											  const class nljm_struct &phi_mu_projectile ,
											  const class correlated_state_str &PSI_IN_qn ,
											  const class GSM_vector_helper_class &GSM_vector_helper_OUT , 
											  const class array<unsigned int> &inSD_tab ,
											  const class array<TYPE> &PSI_IN_component_tab ,
											  const class array<bool> &is_inSD_in_new_space_tab ,
											  const class array<unsigned char> &reordering_bin_phases ,
											  class array<unsigned int> &a_dagger_PSI_IN_total_PSI_indices ,
											  class array<TYPE> &a_dagger_PSI_IN_components)
{
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
    
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);
  
  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();
  
  const int n = phi_mu_projectile.get_n ();
  const int l = phi_mu_projectile.get_l ();
  
  const double j = phi_mu_projectile.get_j (); 
  const double m = phi_mu_projectile.get_m ();
  
  const unsigned int phi_mu_added_index = one_body_indices_mu(n , l , j , m);

  if (phi_mu_added_index == OUT_OF_RANGE) error_message_print_abort ("Problem with the nucleon added");
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int Z_core = prot_data.get_Z_core (); 
  const int N_core = prot_data.get_N_core ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int N_core_mu = (space == PROTONS_ONLY) ? (Z_core) : (N_core);

  const int Nval_mu = data.get_N_valence_nucleons ();

  const int N_IN_mu = (space == PROTONS_ONLY) ? (PSI_IN_qn.get_Z ()) : (PSI_IN_qn.get_N ());

  const int hole_states_number_mu = data.get_hole_states_number ();
  
  const int Nval_IN_mu = N_IN_mu - N_core_mu + hole_states_number_mu;
  
  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
  
  const unsigned long int total_space_dimension_OUT = GSM_vector_helper_OUT.get_total_space_dimension ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (Nval_IN_mu);

      outSD_work_tab(i).allocate (Nval_mu);

      SD_try_tab(i).allocate (Nval_mu);

      C_out_work_tab(i).allocate (Nval_mu);

      C_try_tab(i).allocate (Nval_mu);
    }
  
  a_dagger_PSI_IN_total_PSI_indices = total_space_dimension_OUT;

  a_dagger_PSI_IN_components = 0.0;	  

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int i = 0 ; i < space_dimension_IN ; i++)
    {
      if (!is_inSD_in_new_space_tab(i)) continue;
	      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      unsigned int bin_phase = reordering_bin_phases(i);
	      
      class Slater_determinant &inSD = inSD_work_tab(i_thread);
      
      for (int mu = 0 ; mu < Nval_IN_mu ; mu++) inSD[mu] = inSD_tab(i , mu);
		  
      if (!inSD.is_valence_state_occupied (phi_mu_added_index))
	{
	  class Slater_determinant &outSD = outSD_work_tab(i_thread);

	  inSD.excitation_1p_and_bin_phase (phi_mu_added_index , outSD , bin_phase);

	  class configuration &C_out = C_out_work_tab(i_thread);

	  C_out.get_SD_configuration (phi_mu_table , outSD);
		 
	  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
	      
	  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);
	  
	  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);
	  
	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
	    
	  class configuration &C_try = C_try_tab(i_thread);

	  class Slater_determinant &SD_try = SD_try_tab(i_thread);

	  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);

	  const int iM_out = outSD.iM_determine (phi_mu_table);

	  const unsigned int iC_out = C_out.index_search (BP_out , n_scat_out , dimensions_configuration_set , configuration_set , C_try);

	  const unsigned int outSD_index = outSD.index_search (BP_out , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try); 

	  const unsigned long int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);
		      
	  const unsigned int a_dagger_PSI_IN_total_PSI_index = sum_dimensions_configuration_fixed_out + outSD_index;

	  const TYPE PSI_IN_component = PSI_IN_component_tab(i);
		      
	  const int phase = parity_from_binary_parity (bin_phase);
		  
	  a_dagger_PSI_IN_total_PSI_indices(i) = a_dagger_PSI_IN_total_PSI_index;

	  a_dagger_PSI_IN_components(i) = (phase == 1) ? (PSI_IN_component) : (-PSI_IN_component);
	}
    }
}









void a_dagger_nucleon_helper::a_dagger_proton_apply_add_pn (
							    const bool full_common_vectors_used_in_file , 
							    const class nljm_struct &phi_p_projectile ,
							    const class correlated_state_str &PSI_IN_qn ,
							    const double M_IN , 
							    class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
 
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data (); 
    
  const int Z_core = prot_data.get_Z_core (); 

  const int Nval = neut_data.get_N_valence_nucleons ();

  const int Z_IN = PSI_IN_qn.get_Z ();

  const int prot_hole_states_number = prot_data.get_hole_states_number ();
  
  const int Zval_IN = Z_IN - Z_core + prot_hole_states_number;

  const int Nval_IN = Nval;
    
  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);
  
  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Zval_IN , Nval_IN , file_name_IN_dimension);
  
  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));
 
  class array<unsigned int> inSDp_tab(space_dimension_IN , Zval_IN);

  class array<unsigned int> SDn_tab(space_dimension_IN , Nval_IN);

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);

  class array<bool> is_inSDp_in_new_space_tab(space_dimension_IN);

  class array<bool> is_SDn_in_new_space_tab(space_dimension_IN);

  class array<unsigned char> reordering_bin_phases_p(space_dimension_IN);
  class array<unsigned char> reordering_bin_phases_n(space_dimension_IN);

  files_IN_tables_read_pn_one_nucleon (full_common_vectors_used_in_file , Zval_IN , Nval_IN , PSI_IN_qn , M_IN , prot_data , neut_data , inSDp_tab , SDn_tab , PSI_IN_component_tab ,
				       is_inSDp_in_new_space_tab , is_SDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n);
  
  class array<unsigned int> a_dagger_nucleon_PSI_IN_total_PSI_indices(space_dimension_IN_max);
  
  class array<TYPE> a_dagger_nucleon_PSI_IN_components(space_dimension_IN_max);
  
  a_dagger_proton_PSI_IN_total_PSI_indices_components_calc_pn (phi_p_projectile , PSI_IN_qn , GSM_vector_helper_OUT ,
							       inSDp_tab , SDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_SDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n ,
							       a_dagger_nucleon_PSI_IN_total_PSI_indices , a_dagger_nucleon_PSI_IN_components);

  PSI_OUT.Op_PSI_IN_components_add_one_nucleon_all_processes (full_common_vectors_used_in_file , a_dagger_nucleon_PSI_IN_total_PSI_indices , a_dagger_nucleon_PSI_IN_components);
}










void a_dagger_nucleon_helper::a_dagger_neutron_apply_add_pn (
							     const bool full_common_vectors_used_in_file , 
							     const class nljm_struct &phi_n_projectile , 
							     const class correlated_state_str &PSI_IN_qn ,
							     const double M_IN , 
							     class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
    
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
    
  const int N_core = prot_data.get_N_core ();

  const int Zval = prot_data.get_N_valence_nucleons (); 

  const int N_IN = PSI_IN_qn.get_N ();

  const int neut_hole_states_number = neut_data.get_hole_states_number ();
  
  const int Nval_IN = N_IN - N_core + neut_hole_states_number;

  const int Zval_IN = Zval;
  
  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);
  
  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Zval_IN , Nval_IN , file_name_IN_dimension);
  
  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));
 
  class array<unsigned int> SDp_tab(space_dimension_IN , Zval);

  class array<unsigned int> inSDn_tab(space_dimension_IN , Nval_IN);

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);
 
  class array<bool> is_SDp_in_new_space_tab(space_dimension_IN);

  class array<bool> is_inSDn_in_new_space_tab(space_dimension_IN);

  class array<unsigned char> reordering_bin_phases_p(space_dimension_IN);
  class array<unsigned char> reordering_bin_phases_n(space_dimension_IN);
    
  files_IN_tables_read_pn_one_nucleon (full_common_vectors_used_in_file , Zval_IN , Nval_IN , PSI_IN_qn , M_IN , prot_data , neut_data , SDp_tab , inSDn_tab , PSI_IN_component_tab ,
				       is_SDp_in_new_space_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n);
 
  class array<unsigned int> a_dagger_nucleon_PSI_IN_total_PSI_indices(space_dimension_IN_max);

  class array<TYPE> a_dagger_nucleon_PSI_IN_components(space_dimension_IN_max);
	  
  a_dagger_neutron_PSI_IN_total_PSI_indices_components_calc_pn (phi_n_projectile , PSI_IN_qn , GSM_vector_helper_OUT ,
								SDp_tab , inSDn_tab , PSI_IN_component_tab , is_SDp_in_new_space_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n ,
								a_dagger_nucleon_PSI_IN_total_PSI_indices , a_dagger_nucleon_PSI_IN_components);
  	  
  PSI_OUT.Op_PSI_IN_components_add_one_nucleon_all_processes (full_common_vectors_used_in_file , a_dagger_nucleon_PSI_IN_total_PSI_indices , a_dagger_nucleon_PSI_IN_components);
}









void a_dagger_nucleon_helper::a_dagger_mu_apply_add_pp_nn (
							   const bool full_common_vectors_used_in_file , 
							   const class nljm_struct &phi_projectile ,
							   const class correlated_state_str &PSI_IN_qn ,
							   const double M_IN , 
							   class GSM_vector &PSI_OUT)
{  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
    
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const int Z_core = prot_data.get_Z_core (); 
  const int N_core = prot_data.get_N_core ();
	  			
  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);

  const int N_core_mu = (space == PROTONS_ONLY) ? (Z_core) : (N_core);

  const int N_IN_mu = (space == PROTONS_ONLY) ? (PSI_IN_qn.get_Z ()) : (PSI_IN_qn.get_N ());

  const int hole_states_number_mu = data.get_hole_states_number ();
  
  const int Nval_IN_mu = N_IN_mu - N_core_mu + hole_states_number_mu;
  
  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);
  
  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Nval_IN_mu , file_name_IN_dimension);
  
  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));
  
  class array<unsigned int> inSD_tab(space_dimension_IN , Nval_IN_mu);
  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);

  class array<bool> is_inSD_in_new_space_tab(space_dimension_IN);
  class array<unsigned char> reordering_bin_phases(space_dimension_IN);

  files_IN_tables_read_pp_nn_one_nucleon (full_common_vectors_used_in_file , PSI_IN_qn , M_IN , data , inSD_tab , PSI_IN_component_tab , is_inSD_in_new_space_tab , reordering_bin_phases);
  
  class array<unsigned int> a_dagger_nucleon_PSI_IN_total_PSI_indices(space_dimension_IN_max);

  class array<TYPE> a_dagger_nucleon_PSI_IN_components(space_dimension_IN_max);

  a_dagger_mu_PSI_IN_total_PSI_indices_components_calc_pp_nn (phi_projectile , PSI_IN_qn , GSM_vector_helper_OUT ,
							      inSD_tab , PSI_IN_component_tab , is_inSD_in_new_space_tab , reordering_bin_phases ,
							      a_dagger_nucleon_PSI_IN_total_PSI_indices , a_dagger_nucleon_PSI_IN_components);
      
  PSI_OUT.Op_PSI_IN_components_add_one_nucleon_all_processes (full_common_vectors_used_in_file , a_dagger_nucleon_PSI_IN_total_PSI_indices , a_dagger_nucleon_PSI_IN_components);
}





void a_dagger_nucleon_helper::a_dagger_nucleon_apply_add (
							  const bool full_common_vectors_used_in_file , 
							  const class nljm_struct &phi_projectile ,
							  const enum particle_type particle , 
							  const class correlated_state_str &PSI_IN_qn ,
							  const double M_IN , 
							  class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();

  const double M_OUT = GSM_vector_helper_OUT.get_M ();

  const int l = phi_projectile.get_l ();

  const double m = phi_projectile.get_m ();
  
  const unsigned int BP_IN = PSI_IN_qn.get_BP ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (l);

  if (binary_parity_product (BP_IN , bp) != BP_OUT) return;
  
  if (make_int (M_IN + m - M_OUT) != 0) return;
  
  switch (space)
    {
    case PROTONS_ONLY:  a_dagger_mu_apply_add_pp_nn (full_common_vectors_used_in_file , phi_projectile , PSI_IN_qn , M_IN , PSI_OUT); break;    
    case NEUTRONS_ONLY: a_dagger_mu_apply_add_pp_nn (full_common_vectors_used_in_file , phi_projectile , PSI_IN_qn , M_IN , PSI_OUT); break;
      
    case PROTONS_NEUTRONS:
      {
	switch (particle)
	  {
	  case PROTON:  a_dagger_proton_apply_add_pn  (full_common_vectors_used_in_file , phi_projectile , PSI_IN_qn , M_IN , PSI_OUT); break;	  
	  case NEUTRON: a_dagger_neutron_apply_add_pn (full_common_vectors_used_in_file , phi_projectile , PSI_IN_qn , M_IN , PSI_OUT); break;
	  
	  default: abort_all ();
	  }
      } break;
      
    default: abort_all ();
    }
}















void a_dagger_nucleon_helper::a_dagger_nucleon_coupled_to_J_apply_add (
								       const bool full_common_vectors_used_in_file , 
								       const class nlj_struct &shell_projectile , 
								       const enum particle_type particle , 
								       const class correlated_state_str &PSI_IN_qn , 
								       const double J_OUT , 
								       class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();

  const unsigned int BP_IN = PSI_IN_qn.get_BP ();

  const double J_IN = PSI_IN_qn.get_J ();

  const int l = shell_projectile.get_l ();
  
  const double j = shell_projectile.get_j ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (l);
  
  if (binary_parity_product (BP_IN , bp) != BP_OUT) return;
  
  if (!is_it_triangle (J_IN , J_OUT , j)) return;
  
  const double M_OUT = GSM_vector_helper_OUT.get_M ();

  const int n = shell_projectile.get_n ();
    
  const int M_IN_number = make_int (2.0*J_IN + 1.0);
  
  for (int iM_IN = 0 ; iM_IN < M_IN_number ; iM_IN++)
    {
      const double M_IN = iM_IN - J_IN;

      const double m = M_OUT - M_IN;

      if (rint (abs (m) - j) <= 0.0)
	{
	  const class nljm_struct phi_projectile (n , l , j , m , false , false , false , NADA , NADA , m);
	  
	  const double CG = Clebsch_Gordan (J_IN , M_IN , j , m , J_OUT , M_OUT);

	  PSI_OUT += CG*a_dagger_nucleon (full_common_vectors_used_in_file , phi_projectile , particle , PSI_IN_qn , M_IN);
	}
    }
}





string a_dagger_nucleon_helper::PSI_OUT_coupled_to_J_file_name_a_dagger_nucleon_determine (
											   const bool full_common_vectors_used_in_file , 
											   const string &file_name_debut , 
											   const class nlj_struct &shell_projectile , 
											   const enum particle_type particle , 
											   const class correlated_state_str &PSI_IN_qn ,
											   const double J_OUT , 
											   const double M_OUT)
{
  const string node_string = node_string_determine (full_common_vectors_used_in_file , THIS_PROCESS);
  
  const int n = shell_projectile.get_n ();
  const int l = shell_projectile.get_l ();
  
  const double j = shell_projectile.get_j (); 
  
  const unsigned int BP_IN = PSI_IN_qn.get_BP ();
  
  const unsigned int bp = binary_parity_from_orbital_angular_momentum (l);
    
  const unsigned int BP_OUT = binary_parity_product (BP_IN , bp);

  const string lj = angular_state_for_file_name (l , j);

  const string PSI_IN_string = PSI_quantum_numbers_string_for_file_name (PSI_IN_qn);	

  const string PSI_projectile_string = make_string<int> (n) + lj + "_" + make_string <enum particle_type> (particle);

  const string JM_Pi_OUT_string = JM_Pi_string_for_file_name (BP_OUT , J_OUT , M_OUT);
  
  const string file_name = STORAGE_DIR + node_string + file_name_debut + "_" + PSI_projectile_string + "_applied_to_" + PSI_IN_string + "_target_coupled_to_" + JM_Pi_OUT_string;

  return file_name;
}







void a_dagger_nucleon_helper::a_proton_PSI_IN_total_PSI_indices_components_calc_pn (
										    const class nljm_struct &phi_p_projectile ,
										    const class correlated_state_str &PSI_IN_qn ,
										    const class GSM_vector_helper_class &GSM_vector_helper_OUT ,
										    const class array<unsigned int> &inSDp_tab ,
										    const class array<unsigned int> &SDn_tab ,
										    const class array<TYPE> &PSI_IN_component_tab ,
										    const class array<bool> &is_inSDp_in_new_space_tab ,
										    const class array<bool> &is_SDn_in_new_space_tab ,
										    const class array<unsigned char> &reordering_bin_phases_p ,
										    const class array<unsigned char> &reordering_bin_phases_n ,
										    class array<unsigned int> &a_PSI_IN_total_PSI_indices ,
										    class array<TYPE> &a_PSI_IN_components)
{
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data (); 
 
  const class one_body_indices_str &one_body_indices_p = prot_data.get_one_body_indices ();
  
  const int n = phi_p_projectile.get_n ();
  const int l = phi_p_projectile.get_l ();
  
  const double j = phi_p_projectile.get_j (); 
  const double m = phi_p_projectile.get_m ();
  
  const unsigned int phi_p_removed_index = one_body_indices_p(n , l , j , m);

  if (phi_p_removed_index == OUT_OF_RANGE) error_message_print_abort ("Problem with the proton removed");
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int Z_core = prot_data.get_Z_core ();

  const int Zval = prot_data.get_N_valence_nucleons (); 
  const int Nval = neut_data.get_N_valence_nucleons ();

  const int Z_IN = PSI_IN_qn.get_Z ();

  const int prot_hole_states_number = prot_data.get_hole_states_number ();
  
  const int Zval_IN = Z_IN - Z_core + prot_hole_states_number;
  
  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();
    
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();
  
  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();
  
  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
  
  const unsigned long int total_space_dimension_OUT = GSM_vector_helper_OUT.get_total_space_dimension ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
    
  class array<class Slater_determinant>  inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cn_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (Zval_IN);
      outSDp_work_tab(i).allocate (Zval);

      SDn_work_tab(i).allocate (Nval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_out_work_tab(i).allocate (Zval);

      Cn_work_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);
    }
  
  a_PSI_IN_total_PSI_indices = total_space_dimension_OUT;

  a_PSI_IN_components = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int i = 0 ; i < space_dimension_IN ; i++)
    {
      if (!is_inSDp_in_new_space_tab(i) || !is_SDn_in_new_space_tab(i)) continue;

      const unsigned int i_thread = OpenMP_thread_number_determine ();
		    
      unsigned int bin_phase_p = reordering_bin_phases_p(i);
      unsigned int bin_phase_n = reordering_bin_phases_n(i);
	      
      class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

      for (int p = 0 ; p < Zval_IN ; p++) inSDp[p] = inSDp_tab(i , p);
		  
      if (inSDp.is_valence_state_occupied (phi_p_removed_index))
	{
	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);

	  inSDp.excitation_1h_and_bin_phase(phi_p_removed_index , outSDp , bin_phase_p);

	  class configuration &Cp_out = Cp_out_work_tab(i_thread);

	  Cp_out.get_SD_configuration (phi_p_table , outSDp);

	  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_prot);
	      
	  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_prot);

	  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_prot);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	    
	  class Slater_determinant &SDn = SDn_work_tab(i_thread);

	  for (int n = 0 ; n < Nval ; n++) SDn[n] = SDn_tab(i , n);
		  
	  class configuration &Cn = Cn_work_tab(i_thread);

	  Cn.get_SD_configuration (phi_n_table , SDn);

	  const int n_holes_n = Cn.n_holes_determine (shells_qn_neut);
		  
	  const int En_hw = Cn.E_hw_determine (shells_qn_neut);

	  const int n_scat_n = Cn.n_scat_determine (shells_qn_neut); 

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	  
	  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	  class configuration &Cp_try = Cp_try_tab(i_thread);
	  class configuration &Cn_try = Cn_try_tab(i_thread);

	  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);

	  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_prot);

	  const unsigned int BPn = Cn.BP_determine (shells_qn_neut);

	  const int iMp_out = outSDp.iM_determine (phi_p_table);

	  const int iMn = SDn.iM_determine (phi_n_table);

	  const unsigned int iCp_out = Cp_out.index_search (BPp_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
	  
	  const unsigned int iCn = Cn.index_search (BPn , n_scat_n , dimensions_configuration_n_set , configuration_n_set , Cn_try);

	  const unsigned int outSDp_index = outSDp.index_search (BPp_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);

	  const unsigned int SDn_index = SDn.index_search (BPn , n_scat_n , iCn , iMn , dimensions_SDn_set , SDn_set , SDn_try);

	  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , n_scat_p_out , n_scat_n , iCp_out , iCn , iMp_out);

	  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);
			  
	  const unsigned int a_PSI_IN_total_PSI_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_SDn*outSDp_index + SDn_index;

	  const TYPE PSI_IN_component = PSI_IN_component_tab(i);
			  
	  a_PSI_IN_total_PSI_indices(i) = a_PSI_IN_total_PSI_index;

	  a_PSI_IN_components(i) = (bin_phase_p == bin_phase_n) ? (PSI_IN_component) : (-PSI_IN_component);
	}
    }
}






void a_dagger_nucleon_helper::a_neutron_PSI_IN_total_PSI_indices_components_calc_pn (
										     const class nljm_struct &phi_n_projectile ,
										     const class correlated_state_str &PSI_IN_qn ,
										     const class GSM_vector_helper_class &GSM_vector_helper_OUT , 
										     const class array<unsigned int> &SDp_tab ,
										     const class array<unsigned int> &inSDn_tab ,
										     const class array<TYPE> &PSI_IN_component_tab ,
										     const class array<bool> &is_SDp_in_new_space_tab ,
										     const class array<bool> &is_inSDn_in_new_space_tab ,
										     const class array<unsigned char> &reordering_bin_phases_p ,
										     const class array<unsigned char> &reordering_bin_phases_n ,
										     class array<unsigned int> &a_PSI_IN_total_PSI_indices ,
										     class array<TYPE> &a_PSI_IN_components)
{
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const class one_body_indices_str &one_body_indices_n = neut_data.get_one_body_indices ();
  
  const int n = phi_n_projectile.get_n ();
  const int l = phi_n_projectile.get_l ();
  
  const double j = phi_n_projectile.get_j (); 
  const double m = phi_n_projectile.get_m ();
  
  const unsigned int phi_n_removed_index = one_body_indices_n(n , l , j , m);

  if (phi_n_removed_index == OUT_OF_RANGE) error_message_print_abort ("Problem with the neutron removed");
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();

  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int N_core = prot_data.get_N_core ();

  const int Zval = prot_data.get_N_valence_nucleons (); 
  const int Nval = neut_data.get_N_valence_nucleons ();

  const int N_IN = PSI_IN_qn.get_N ();

  const int neut_hole_states_number = neut_data.get_hole_states_number ();
  
  const int Nval_IN = N_IN - N_core + neut_hole_states_number;

  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();
    
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();
  
  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();
  
  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
  
  const unsigned long int total_space_dimension_OUT = GSM_vector_helper_OUT.get_total_space_dimension ();
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSDn_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> Cp_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDn_work_tab(i).allocate (Nval_IN);
      outSDn_work_tab(i).allocate (Nval);

      SDp_work_tab(i).allocate (Zval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_work_tab(i).allocate (Zval);

      Cn_out_work_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);
    }
  
  a_PSI_IN_total_PSI_indices = total_space_dimension_OUT;

  a_PSI_IN_components = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int i = 0 ; i < space_dimension_IN ; i++)
    {
      if (!is_SDp_in_new_space_tab(i) || !is_inSDn_in_new_space_tab(i)) continue;
	      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      unsigned int bin_phase_p = reordering_bin_phases_p(i);
      unsigned int bin_phase_n = reordering_bin_phases_n(i);
	      
      class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

      for (int n = 0 ; n < Nval_IN ; n++) inSDn[n] = inSDn_tab(i , n);
		  
      if (inSDn.is_valence_state_occupied (phi_n_removed_index))
	{
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);

	  inSDn.excitation_1h_and_bin_phase (phi_n_removed_index , outSDn , bin_phase_n);

	  class configuration &Cn_out = Cn_out_work_tab(i_thread);

	  Cn_out.get_SD_configuration (phi_n_table , outSDn);

	  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_neut);
	      
	  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_neut);

	  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_neut);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	    
	  class Slater_determinant &SDp = SDp_work_tab(i_thread);

	  for (int p = 0 ; p < Zval ; p++) SDp[p] = SDp_tab(i , p);
			  
	  class configuration &Cp = Cp_work_tab(i_thread);

	  Cp.get_SD_configuration (phi_p_table , SDp);

	  const int n_holes_p = Cp.n_holes_determine (shells_qn_prot);
		  
	  const int Ep_hw = Cp.E_hw_determine (shells_qn_prot);

	  const int n_scat_p = Cp.n_scat_determine (shells_qn_prot);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	  
	  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	  class configuration &Cp_try = Cp_try_tab(i_thread);
	  class configuration &Cn_try = Cn_try_tab(i_thread);

	  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);

	  const unsigned int BPp = Cp.BP_determine (shells_qn_prot);

	  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_neut);

	  const int iMp = SDp.iM_determine (phi_p_table);

	  const int iMn_out = outSDn.iM_determine (phi_n_table);

	  const unsigned int iCp = Cp.index_search (BPp , n_scat_p , dimensions_configuration_p_set , configuration_p_set , Cp_try);

	  const unsigned int iCn_out = Cn_out.index_search (BPn_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
	  const unsigned int SDp_index = SDp.index_search (BPp , n_scat_p , iCp , iMp , dimensions_SDp_set , SDp_set , SDp_try);

	  const unsigned int outSDn_index = outSDn.index_search (BPn_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try); 

	  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp , n_scat_p , n_scat_n_out , iCp , iCn_out , iMp);
	  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);
			  
	  const unsigned int a_PSI_IN_total_PSI_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*SDp_index + outSDn_index;

	  const TYPE PSI_IN_component = PSI_IN_component_tab(i);
			  
	  a_PSI_IN_total_PSI_indices(i) = a_PSI_IN_total_PSI_index;

	  a_PSI_IN_components(i) = (bin_phase_p == bin_phase_n) ? (PSI_IN_component) : (-PSI_IN_component);
	}
    }
}










void a_dagger_nucleon_helper::a_mu_PSI_IN_total_PSI_indices_components_calc_pp_nn (
										   const class nljm_struct &phi_mu_projectile ,
										   const class correlated_state_str &PSI_IN_qn ,
										   const class GSM_vector_helper_class &GSM_vector_helper_OUT , 
										   const class array<unsigned int> &inSD_tab ,
										   const class array<TYPE> &PSI_IN_component_tab ,
										   const class array<bool> &is_inSD_in_new_space_tab ,
										   const class array<unsigned char> &reordering_bin_phases ,
										   class array<unsigned int> &a_PSI_IN_total_PSI_indices ,
										   class array<TYPE> &a_PSI_IN_components)
{
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
    
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);
  
  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();
  
  const int n = phi_mu_projectile.get_n ();
  const int l = phi_mu_projectile.get_l ();
  
  const double j = phi_mu_projectile.get_j (); 
  const double m = phi_mu_projectile.get_m ();
  
  const unsigned int phi_mu_removed_index = one_body_indices_mu(n , l , j , m);

  if (phi_mu_removed_index == OUT_OF_RANGE) error_message_print_abort ("Problem with the nucleon removed");
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int Z_core = prot_data.get_Z_core (); 
  const int N_core = prot_data.get_N_core ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int N_core_mu = (space == PROTONS_ONLY) ? (Z_core) : (N_core);

  const int Nval_mu = data.get_N_valence_nucleons ();

  const int N_IN_mu = (space == PROTONS_ONLY) ? (PSI_IN_qn.get_Z ()) : (PSI_IN_qn.get_N ());

  const int hole_states_number_mu = data.get_hole_states_number ();
  
  const int Nval_IN_mu = N_IN_mu - N_core_mu + hole_states_number_mu;
  
  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
  
  const unsigned long int total_space_dimension_OUT = GSM_vector_helper_OUT.get_total_space_dimension ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (Nval_IN_mu);

      outSD_work_tab(i).allocate (Nval_mu);

      SD_try_tab(i).allocate (Nval_mu);

      C_out_work_tab(i).allocate (Nval_mu);

      C_try_tab(i).allocate (Nval_mu);
    }
  
  a_PSI_IN_total_PSI_indices = total_space_dimension_OUT;

  a_PSI_IN_components = 0.0;	  

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int i = 0 ; i < space_dimension_IN ; i++)
    {
      if (!is_inSD_in_new_space_tab(i)) continue;
	      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      unsigned int bin_phase = reordering_bin_phases(i);
	      
      class Slater_determinant &inSD = inSD_work_tab(i_thread);

      for (int mu = 0 ; mu < Nval_IN_mu ; mu++) inSD[mu] = inSD_tab(i , mu);
		  
      if (inSD.is_valence_state_occupied (phi_mu_removed_index))
	{
	  class Slater_determinant &outSD = outSD_work_tab(i_thread);

	  inSD.excitation_1h_and_bin_phase (phi_mu_removed_index , outSD , bin_phase);

	  class configuration &C_out = C_out_work_tab(i_thread);

	  C_out.get_SD_configuration (phi_mu_table , outSD);
	
	  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
	      
	  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

	  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
	    
	  class configuration &C_try = C_try_tab(i_thread);

	  class Slater_determinant &SD_try = SD_try_tab(i_thread);

	  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);

	  const int iM_out = outSD.iM_determine (phi_mu_table);

	  const unsigned int iC_out = C_out.index_search (BP_out , n_scat_out , dimensions_configuration_set , configuration_set , C_try);

	  const unsigned int outSD_index = outSD.index_search (BP_out , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try); 

	  const unsigned long int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);
		      
	  const unsigned int a_PSI_IN_total_PSI_index = sum_dimensions_configuration_fixed_out + outSD_index;

	  const TYPE PSI_IN_component = PSI_IN_component_tab(i);
		      
	  const int phase = parity_from_binary_parity (bin_phase);
		  
	  a_PSI_IN_total_PSI_indices(i) = a_PSI_IN_total_PSI_index;

	  a_PSI_IN_components(i) = (phase == 1) ? (PSI_IN_component) : (-PSI_IN_component);
	}
    }
}










void a_dagger_nucleon_helper::a_proton_apply_add_pn (
						     const bool full_common_vectors_used_in_file , 
						     const class nljm_struct &phi_p_projectile ,
						     const class correlated_state_str &PSI_IN_qn ,
						     const double M_IN , 
						     class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
   
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data (); 
    
  const int Z_core = prot_data.get_Z_core ();

  const int Nval = neut_data.get_N_valence_nucleons ();

  const int Z_IN = PSI_IN_qn.get_Z ();

  const int prot_hole_states_number = prot_data.get_hole_states_number ();
  
  const int Zval_IN = Z_IN - Z_core + prot_hole_states_number;

  const int Nval_IN = Nval;
      
  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);
  
  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Zval_IN , Nval_IN , file_name_IN_dimension);
  
  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));
  
  class array<unsigned int> inSDp_tab(space_dimension_IN , Zval_IN);

  class array<unsigned int> SDn_tab(space_dimension_IN , Nval_IN);

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);

  class array<bool> is_inSDp_in_new_space_tab(space_dimension_IN);

  class array<bool> is_SDn_in_new_space_tab(space_dimension_IN);

  class array<unsigned char> reordering_bin_phases_p(space_dimension_IN);
  class array<unsigned char> reordering_bin_phases_n(space_dimension_IN);

  files_IN_tables_read_pn_one_nucleon (full_common_vectors_used_in_file , Zval_IN , Nval_IN , PSI_IN_qn , M_IN , prot_data , neut_data , inSDp_tab , SDn_tab , PSI_IN_component_tab ,
				       is_inSDp_in_new_space_tab , is_SDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n);
  
  class array<unsigned int> a_nucleon_PSI_IN_total_PSI_indices(space_dimension_IN_max);

  class array<TYPE> a_nucleon_PSI_IN_components(space_dimension_IN_max);

  a_proton_PSI_IN_total_PSI_indices_components_calc_pn (phi_p_projectile , PSI_IN_qn , GSM_vector_helper_OUT ,
							inSDp_tab , SDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_SDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n ,
							a_nucleon_PSI_IN_total_PSI_indices , a_nucleon_PSI_IN_components);

  PSI_OUT.Op_PSI_IN_components_add_one_nucleon_all_processes (full_common_vectors_used_in_file , a_nucleon_PSI_IN_total_PSI_indices , a_nucleon_PSI_IN_components);
}






void a_dagger_nucleon_helper::a_neutron_apply_add_pn (
						      const bool full_common_vectors_used_in_file , 
						      const class nljm_struct &phi_n_projectile , 
						      const class correlated_state_str &PSI_IN_qn ,
						      const double M_IN , 
						      class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
    
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
    
  const int N_core = prot_data.get_N_core ();

  const int Zval = prot_data.get_N_valence_nucleons (); 

  const int N_IN = PSI_IN_qn.get_N ();

  const int neut_hole_states_number = neut_data.get_hole_states_number ();
  
  const int Nval_IN = N_IN - N_core + neut_hole_states_number;

  const int Zval_IN = Zval;
      
  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);
  
  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Zval_IN , Nval_IN , file_name_IN_dimension);
  
  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));
 
  class array<unsigned int> SDp_tab(space_dimension_IN , Zval);

  class array<unsigned int> inSDn_tab(space_dimension_IN , Nval_IN);

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);
 
  class array<bool> is_SDp_in_new_space_tab(space_dimension_IN);

  class array<bool> is_inSDn_in_new_space_tab(space_dimension_IN);

  class array<unsigned char> reordering_bin_phases_p(space_dimension_IN);
  class array<unsigned char> reordering_bin_phases_n(space_dimension_IN);

  files_IN_tables_read_pn_one_nucleon (full_common_vectors_used_in_file , Zval_IN , Nval_IN , PSI_IN_qn , M_IN , prot_data , neut_data , SDp_tab , inSDn_tab , PSI_IN_component_tab ,
				       is_SDp_in_new_space_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n);
  
  class array<unsigned int> a_nucleon_PSI_IN_total_PSI_indices(space_dimension_IN_max);

  class array<TYPE> a_nucleon_PSI_IN_components(space_dimension_IN_max);
	  
  a_neutron_PSI_IN_total_PSI_indices_components_calc_pn (phi_n_projectile , PSI_IN_qn , GSM_vector_helper_OUT ,
							 SDp_tab , inSDn_tab , PSI_IN_component_tab , is_SDp_in_new_space_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n ,
							 a_nucleon_PSI_IN_total_PSI_indices , a_nucleon_PSI_IN_components);
  	  
  PSI_OUT.Op_PSI_IN_components_add_one_nucleon_all_processes (full_common_vectors_used_in_file , a_nucleon_PSI_IN_total_PSI_indices , a_nucleon_PSI_IN_components);
}









void a_dagger_nucleon_helper::a_mu_apply_add_pp_nn (
						    const bool full_common_vectors_used_in_file , 
						    const class nljm_struct &phi_projectile ,
						    const class correlated_state_str &PSI_IN_qn ,
						    const double M_IN , 
						    class GSM_vector &PSI_OUT)
{  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
    
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const int Z_core = prot_data.get_Z_core (); 
  const int N_core = prot_data.get_N_core ();
	  			
  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);

  const int N_core_mu = (space == PROTONS_ONLY) ? (Z_core) : (N_core);

  const int N_IN_mu = (space == PROTONS_ONLY) ? (PSI_IN_qn.get_Z ()) : (PSI_IN_qn.get_N ());

  const int hole_states_number_mu = data.get_hole_states_number ();
  
  const int Nval_IN_mu = N_IN_mu - N_core_mu + hole_states_number_mu;
  
  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);
  
  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Nval_IN_mu , file_name_IN_dimension);
  
  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));

  class array<unsigned int> inSD_tab(space_dimension_IN , Nval_IN_mu);

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);

  class array<bool> is_inSD_in_new_space_tab(space_dimension_IN);

  class array<unsigned char> reordering_bin_phases(space_dimension_IN);

  files_IN_tables_read_pp_nn_one_nucleon (full_common_vectors_used_in_file , PSI_IN_qn , M_IN , data , inSD_tab , PSI_IN_component_tab , is_inSD_in_new_space_tab , reordering_bin_phases);

  class array<unsigned int> a_nucleon_PSI_IN_total_PSI_indices(space_dimension_IN_max);

  class array<TYPE> a_nucleon_PSI_IN_components(space_dimension_IN_max);

  a_mu_PSI_IN_total_PSI_indices_components_calc_pp_nn (phi_projectile , PSI_IN_qn , GSM_vector_helper_OUT ,
						       inSD_tab , PSI_IN_component_tab , is_inSD_in_new_space_tab , reordering_bin_phases , 
						       a_nucleon_PSI_IN_total_PSI_indices , a_nucleon_PSI_IN_components);
      
  PSI_OUT.Op_PSI_IN_components_add_one_nucleon_all_processes (full_common_vectors_used_in_file , a_nucleon_PSI_IN_total_PSI_indices , a_nucleon_PSI_IN_components);
}





void a_dagger_nucleon_helper::a_nucleon_apply_add (
						   const bool full_common_vectors_used_in_file , 
						   const class nljm_struct &phi_projectile ,
						   const enum particle_type particle , 
						   const class correlated_state_str &PSI_IN_qn ,
						   const double M_IN , 
						   class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();

  const double M_OUT = GSM_vector_helper_OUT.get_M ();

  const int l = phi_projectile.get_l ();

  const double m = phi_projectile.get_m ();
  
  const unsigned int BP_IN = PSI_IN_qn.get_BP ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (l);

  if (binary_parity_product (BP_IN , bp) != BP_OUT) return;
  
  if (make_int (M_IN - m - M_OUT) != 0) return;
  
  switch (space)
    {
    case PROTONS_ONLY:  a_mu_apply_add_pp_nn (full_common_vectors_used_in_file , phi_projectile , PSI_IN_qn , M_IN , PSI_OUT); break;    
    case NEUTRONS_ONLY: a_mu_apply_add_pp_nn (full_common_vectors_used_in_file , phi_projectile , PSI_IN_qn , M_IN , PSI_OUT); break;
      
    case PROTONS_NEUTRONS:
      {
	switch (particle)
	  {
	  case PROTON:  a_proton_apply_add_pn  (full_common_vectors_used_in_file , phi_projectile , PSI_IN_qn , M_IN , PSI_OUT); break;	  
	  case NEUTRON: a_neutron_apply_add_pn (full_common_vectors_used_in_file , phi_projectile , PSI_IN_qn , M_IN , PSI_OUT); break;
	  
	  default: abort_all ();
	  }
      } break;
      
    default: abort_all ();
    }
}














void a_dagger_nucleon_helper::a_nucleon_coupled_to_J_apply_add (
								const bool full_common_vectors_used_in_file , 
								const class nlj_struct &shell_ejectile , 
								const enum particle_type particle , 
								const class correlated_state_str &PSI_IN_qn , 
								const double J_OUT , 
								class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();

  const unsigned int BP_IN = PSI_IN_qn.get_BP ();

  const double J_IN = PSI_IN_qn.get_J ();

  const int l = shell_ejectile.get_l ();
  
  const double j = shell_ejectile.get_j ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (l);
  
  if (binary_parity_product (BP_IN , bp) != BP_OUT) return;
  
  if (!is_it_triangle (J_IN , J_OUT , j)) return;
  
  const double M_OUT = GSM_vector_helper_OUT.get_M ();

  const int n = shell_ejectile.get_n ();
    
  const int M_IN_number = make_int (2.0*J_IN + 1.0);
  
  for (int iM_IN = 0 ; iM_IN < M_IN_number ; iM_IN++)
    {
      const double M_IN = iM_IN - J_IN;

      const double m = M_IN - M_OUT;

      if (rint (abs (m) - j) <= 0.0)
	{
	  const class nljm_struct phi_ejectile (n , l , j , m , false , false , false , NADA , NADA , m);
	  
	  const double CG_phase = minus_one_pow (j - m)*Clebsch_Gordan (J_IN , M_IN , j , -m , J_OUT , M_OUT);

	  PSI_OUT += CG_phase*a_nucleon (full_common_vectors_used_in_file , phi_ejectile , particle , PSI_IN_qn , M_IN);
	}
    }
}







string a_dagger_nucleon_helper::PSI_OUT_coupled_to_J_file_name_a_nucleon_determine (
										    const bool full_common_vectors_used_in_file , 
										    const string &file_name_debut , 
										    const class nlj_struct &shell_ejectile , 
										    const enum particle_type particle , 
										    const class correlated_state_str &PSI_IN_qn ,
										    const double J_OUT , 
										    const double M_OUT)
{
  const string node_string = node_string_determine (full_common_vectors_used_in_file , THIS_PROCESS);
    
  const int n = shell_ejectile.get_n ();
  const int l = shell_ejectile.get_l ();
  
  const double j = shell_ejectile.get_j (); 
  
  const unsigned int BP_IN = PSI_IN_qn.get_BP ();
  
  const unsigned int bp = binary_parity_from_orbital_angular_momentum (l);
    
  const unsigned int BP_OUT = binary_parity_product (BP_IN , bp);

  const string lj = angular_state_for_file_name (l , j);

  const string PSI_IN_string = PSI_quantum_numbers_string_for_file_name (PSI_IN_qn);	

  const string PSI_ejectile_string = make_string<int> (n) + lj + "_" + make_string <enum particle_type> (particle);

  const string JM_Pi_OUT_string = JM_Pi_string_for_file_name (BP_OUT , J_OUT , M_OUT);
  
  const string file_name = STORAGE_DIR + node_string + file_name_debut + "_" + PSI_ejectile_string + "_applied_to_" + PSI_IN_string + "_target_coupled_to_" + JM_Pi_OUT_string;

  return file_name;
}











a_dagger_nucleon_PSI_str::a_dagger_nucleon_PSI_str (
						    const bool full_common_vectors_used_in_file_c ,
						    const class nljm_struct &phi_projectile_c , 
						    const enum particle_type particle_c , 
						    const class correlated_state_str &PSI_IN_qn_c ,
						    const double M_IN_c) 
  : full_common_vectors_used_in_file (full_common_vectors_used_in_file_c) ,
    phi_projectile (phi_projectile_c) , 
    particle (particle_c) , 
    PSI_IN_qn (PSI_IN_qn_c) ,
    M_IN (M_IN_c) {}




class a_dagger_nucleon_PSI_str a_dagger_nucleon_helper::a_dagger_nucleon (
									  const bool full_common_vectors_used_in_file_c ,
									  const class nljm_struct &phi_projectile_c , 
									  const enum particle_type particle_c , 
									  const class correlated_state_str &PSI_IN_qn_c ,
									  const double M_IN_c) 
{
  return a_dagger_nucleon_PSI_str (full_common_vectors_used_in_file_c , phi_projectile_c , particle_c , PSI_IN_qn_c , M_IN_c);
}





a_dagger_nucleon_coupled_to_J_PSI_str::a_dagger_nucleon_coupled_to_J_PSI_str (
									      const bool full_common_vectors_used_in_file_c ,
									      const class nlj_struct &shell_projectile_c , 
									      const enum particle_type particle_c , 
									      const class correlated_state_str &PSI_IN_qn_c ,
									      const double J_OUT_c , 
									      const double M_OUT_c) 
  : full_common_vectors_used_in_file (full_common_vectors_used_in_file_c) ,
    shell_projectile (shell_projectile_c) ,
    particle (particle_c) , 
    PSI_IN_qn (PSI_IN_qn_c) ,
    J_OUT (J_OUT_c) ,
    M_OUT (M_OUT_c) {}



x_a_dagger_nucleon_PSI_str::x_a_dagger_nucleon_PSI_str (const TYPE &x_c , const class a_dagger_nucleon_PSI_str &a_dagger_nucleon_PSI_c) 
  : x (x_c) , a_dagger_nucleon_PSI (a_dagger_nucleon_PSI_c) {}

class x_a_dagger_nucleon_PSI_str operator + (const class a_dagger_nucleon_PSI_str &a_dagger_nucleon_PSI)
{
  return x_a_dagger_nucleon_PSI_str (1.0 , a_dagger_nucleon_PSI);
}

class x_a_dagger_nucleon_PSI_str operator - (const class a_dagger_nucleon_PSI_str &a_dagger_nucleon_PSI)
{
  return x_a_dagger_nucleon_PSI_str (-1.0 , a_dagger_nucleon_PSI);
}

class x_a_dagger_nucleon_PSI_str operator * (const class a_dagger_nucleon_PSI_str &a_dagger_nucleon_PSI , const double x)
{
  return x_a_dagger_nucleon_PSI_str (x , a_dagger_nucleon_PSI);
}

class x_a_dagger_nucleon_PSI_str operator * (const double x , const class a_dagger_nucleon_PSI_str &a_dagger_nucleon_PSI)
{
  return x_a_dagger_nucleon_PSI_str (x , a_dagger_nucleon_PSI);
}

class x_a_dagger_nucleon_PSI_str operator / (const class a_dagger_nucleon_PSI_str &a_dagger_nucleon_PSI , const double x)
{
  const double one_over_x = 1.0/x;

  return x_a_dagger_nucleon_PSI_str (one_over_x , a_dagger_nucleon_PSI);
}

class x_a_dagger_nucleon_PSI_str operator + (const class x_a_dagger_nucleon_PSI_str &x_a_dagger_nucleon_PSI)
{
  return x_a_dagger_nucleon_PSI_str (x_a_dagger_nucleon_PSI.x , x_a_dagger_nucleon_PSI.a_dagger_nucleon_PSI);
}

class x_a_dagger_nucleon_PSI_str operator - (const class x_a_dagger_nucleon_PSI_str &x_a_dagger_nucleon_PSI)
{
  return x_a_dagger_nucleon_PSI_str (-x_a_dagger_nucleon_PSI.x , x_a_dagger_nucleon_PSI.a_dagger_nucleon_PSI);
}

#ifdef TYPEisDOUBLECOMPLEX

class x_a_dagger_nucleon_PSI_str operator * (const class a_dagger_nucleon_PSI_str &a_dagger_nucleon_PSI , const complex<double> &x)
{
  return x_a_dagger_nucleon_PSI_str (x , a_dagger_nucleon_PSI);
}

class x_a_dagger_nucleon_PSI_str operator * (const complex<double> &x , const class a_dagger_nucleon_PSI_str &a_dagger_nucleon_PSI)
{
  return x_a_dagger_nucleon_PSI_str (x , a_dagger_nucleon_PSI);
}

class x_a_dagger_nucleon_PSI_str operator / (const class a_dagger_nucleon_PSI_str &a_dagger_nucleon_PSI , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return x_a_dagger_nucleon_PSI_str (one_over_x , a_dagger_nucleon_PSI);
}

#endif






class a_dagger_nucleon_coupled_to_J_PSI_str a_dagger_nucleon_helper::a_dagger_nucleon_coupled_to_J (
												    const bool full_common_vectors_used_in_file_c ,
												    const class nlj_struct &shell_projectile_c ,  
												    const enum particle_type particle_c , 
												    const class correlated_state_str &PSI_IN_qn_c ,
												    const double J_OUT_c , 
												    const double M_OUT_c) 
{
  return a_dagger_nucleon_coupled_to_J_PSI_str (full_common_vectors_used_in_file_c , shell_projectile_c , particle_c , PSI_IN_qn_c , J_OUT_c , M_OUT_c);
}



x_a_dagger_nucleon_coupled_to_J_PSI_str::x_a_dagger_nucleon_coupled_to_J_PSI_str (const TYPE &x_c , const class a_dagger_nucleon_coupled_to_J_PSI_str &a_dagger_nucleon_coupled_to_J_PSI_c) 
  : x (x_c) , a_dagger_nucleon_coupled_to_J_PSI (a_dagger_nucleon_coupled_to_J_PSI_c) {}

class x_a_dagger_nucleon_coupled_to_J_PSI_str operator + (const class a_dagger_nucleon_coupled_to_J_PSI_str &a_dagger_nucleon_coupled_to_J_PSI)
{
  return x_a_dagger_nucleon_coupled_to_J_PSI_str (1.0 , a_dagger_nucleon_coupled_to_J_PSI);
}

class x_a_dagger_nucleon_coupled_to_J_PSI_str operator - (const class a_dagger_nucleon_coupled_to_J_PSI_str &a_dagger_nucleon_coupled_to_J_PSI)
{
  return x_a_dagger_nucleon_coupled_to_J_PSI_str (-1.0 , a_dagger_nucleon_coupled_to_J_PSI);
}

class x_a_dagger_nucleon_coupled_to_J_PSI_str operator * (const class a_dagger_nucleon_coupled_to_J_PSI_str &a_dagger_nucleon_coupled_to_J_PSI , const double x)
{
  return x_a_dagger_nucleon_coupled_to_J_PSI_str (x , a_dagger_nucleon_coupled_to_J_PSI);
}

class x_a_dagger_nucleon_coupled_to_J_PSI_str operator * (const double x , const class a_dagger_nucleon_coupled_to_J_PSI_str &a_dagger_nucleon_coupled_to_J_PSI)
{
  return x_a_dagger_nucleon_coupled_to_J_PSI_str (x , a_dagger_nucleon_coupled_to_J_PSI);
}

class x_a_dagger_nucleon_coupled_to_J_PSI_str operator / (const class a_dagger_nucleon_coupled_to_J_PSI_str &a_dagger_nucleon_coupled_to_J_PSI , const double x)
{
  const double one_over_x = 1.0/x;

  return x_a_dagger_nucleon_coupled_to_J_PSI_str (one_over_x , a_dagger_nucleon_coupled_to_J_PSI);
}

class x_a_dagger_nucleon_coupled_to_J_PSI_str operator + (const class x_a_dagger_nucleon_coupled_to_J_PSI_str &x_a_dagger_nucleon_coupled_to_J_PSI)
{
  return x_a_dagger_nucleon_coupled_to_J_PSI_str (x_a_dagger_nucleon_coupled_to_J_PSI.x , x_a_dagger_nucleon_coupled_to_J_PSI.a_dagger_nucleon_coupled_to_J_PSI);
}

class x_a_dagger_nucleon_coupled_to_J_PSI_str operator - (const class x_a_dagger_nucleon_coupled_to_J_PSI_str &x_a_dagger_nucleon_coupled_to_J_PSI)
{
  return x_a_dagger_nucleon_coupled_to_J_PSI_str (-x_a_dagger_nucleon_coupled_to_J_PSI.x , x_a_dagger_nucleon_coupled_to_J_PSI.a_dagger_nucleon_coupled_to_J_PSI);
}

#ifdef TYPEisDOUBLECOMPLEX

class x_a_dagger_nucleon_coupled_to_J_PSI_str operator * (const class a_dagger_nucleon_coupled_to_J_PSI_str &a_dagger_nucleon_coupled_to_J_PSI , const complex<double> &x)
{
  return x_a_dagger_nucleon_coupled_to_J_PSI_str (x , a_dagger_nucleon_coupled_to_J_PSI);
}

class x_a_dagger_nucleon_coupled_to_J_PSI_str operator * (const complex<double> &x , const class a_dagger_nucleon_coupled_to_J_PSI_str &a_dagger_nucleon_coupled_to_J_PSI)
{
  return x_a_dagger_nucleon_coupled_to_J_PSI_str (x , a_dagger_nucleon_coupled_to_J_PSI);
}

class x_a_dagger_nucleon_coupled_to_J_PSI_str operator / (const class a_dagger_nucleon_coupled_to_J_PSI_str &a_dagger_nucleon_coupled_to_J_PSI , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return x_a_dagger_nucleon_coupled_to_J_PSI_str (one_over_x , a_dagger_nucleon_coupled_to_J_PSI);
}

#endif





a_nucleon_PSI_str::a_nucleon_PSI_str (
				      const bool full_common_vectors_used_in_file_c ,
				      const class nljm_struct &phi_ejectile_c , 
				      const enum particle_type particle_c , 
				      const class correlated_state_str &PSI_IN_qn_c ,
				      const double M_IN_c) 
  : full_common_vectors_used_in_file (full_common_vectors_used_in_file_c) ,
    phi_ejectile (phi_ejectile_c) , 
    particle (particle_c) , 
    PSI_IN_qn (PSI_IN_qn_c) ,
    M_IN (M_IN_c) {}






class a_nucleon_PSI_str a_dagger_nucleon_helper::a_nucleon (
							    const bool full_common_vectors_used_in_file_c ,
							    const class nljm_struct &phi_ejectile_c , 
							    const enum particle_type particle_c , 
							    const class correlated_state_str &PSI_IN_qn_c ,
							    const double M_IN_c) 
{
  return a_nucleon_PSI_str (full_common_vectors_used_in_file_c , phi_ejectile_c , particle_c , PSI_IN_qn_c , M_IN_c);
}


x_a_nucleon_PSI_str::x_a_nucleon_PSI_str (const TYPE &x_c , const class a_nucleon_PSI_str &a_nucleon_PSI_c) 
  : x (x_c) , a_nucleon_PSI (a_nucleon_PSI_c) {}

class x_a_nucleon_PSI_str operator + (const class a_nucleon_PSI_str &a_nucleon_PSI)
{
  return x_a_nucleon_PSI_str (1.0 , a_nucleon_PSI);
}

class x_a_nucleon_PSI_str operator - (const class a_nucleon_PSI_str &a_nucleon_PSI)
{
  return x_a_nucleon_PSI_str (-1.0 , a_nucleon_PSI);
}

class x_a_nucleon_PSI_str operator * (const class a_nucleon_PSI_str &a_nucleon_PSI , const double x)
{
  return x_a_nucleon_PSI_str (x , a_nucleon_PSI);
}

class x_a_nucleon_PSI_str operator * (const double x , const class a_nucleon_PSI_str &a_nucleon_PSI)
{
  return x_a_nucleon_PSI_str (x , a_nucleon_PSI);
}

class x_a_nucleon_PSI_str operator / (const class a_nucleon_PSI_str &a_nucleon_PSI , const double x)
{
  const double one_over_x = 1.0/x;

  return x_a_nucleon_PSI_str (one_over_x , a_nucleon_PSI);
}

class x_a_nucleon_PSI_str operator + (const class x_a_nucleon_PSI_str &x_a_nucleon_PSI)
{
  return x_a_nucleon_PSI_str (x_a_nucleon_PSI.x , x_a_nucleon_PSI.a_nucleon_PSI);
}

class x_a_nucleon_PSI_str operator - (const class x_a_nucleon_PSI_str &x_a_nucleon_PSI)
{
  return x_a_nucleon_PSI_str (-x_a_nucleon_PSI.x , x_a_nucleon_PSI.a_nucleon_PSI);
}

#ifdef TYPEisDOUBLECOMPLEX

class x_a_nucleon_PSI_str operator * (const class a_nucleon_PSI_str &a_nucleon_PSI , const complex<double> &x)
{
  return x_a_nucleon_PSI_str (x , a_nucleon_PSI);
}

class x_a_nucleon_PSI_str operator * (const complex<double> &x , const class a_nucleon_PSI_str &a_nucleon_PSI)
{
  return x_a_nucleon_PSI_str (x , a_nucleon_PSI);
}

class x_a_nucleon_PSI_str operator / (const class a_nucleon_PSI_str &a_nucleon_PSI , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return x_a_nucleon_PSI_str (one_over_x , a_nucleon_PSI);
}

#endif







a_nucleon_coupled_to_J_PSI_str::a_nucleon_coupled_to_J_PSI_str (
								const bool full_common_vectors_used_in_file_c ,
								const class nlj_struct &shell_ejectile_c , 
								const enum particle_type particle_c , 
								const class correlated_state_str &PSI_IN_qn_c ,
								const double J_OUT_c , 
								const double M_OUT_c) 
  :
  full_common_vectors_used_in_file (full_common_vectors_used_in_file_c) ,
  shell_ejectile (shell_ejectile_c) ,
  particle (particle_c) , 
  PSI_IN_qn (PSI_IN_qn_c) ,
  J_OUT (J_OUT_c) ,
  M_OUT (M_OUT_c) {}






class a_nucleon_coupled_to_J_PSI_str a_dagger_nucleon_helper::a_nucleon_coupled_to_J (
										      const bool full_common_vectors_used_in_file_c ,
										      const class nlj_struct &shell_ejectile_c ,  
										      const enum particle_type particle_c , 
										      const class correlated_state_str &PSI_IN_qn_c ,
										      const double J_OUT_c , 
										      const double M_OUT_c) 
{
  return a_nucleon_coupled_to_J_PSI_str (full_common_vectors_used_in_file_c , shell_ejectile_c , particle_c , PSI_IN_qn_c , J_OUT_c , M_OUT_c);
}







x_a_nucleon_coupled_to_J_PSI_str::x_a_nucleon_coupled_to_J_PSI_str (const TYPE &x_c , const class a_nucleon_coupled_to_J_PSI_str &a_nucleon_coupled_to_J_PSI_c) 
  : x (x_c) , a_nucleon_coupled_to_J_PSI (a_nucleon_coupled_to_J_PSI_c) {}

class x_a_nucleon_coupled_to_J_PSI_str operator + (const class a_nucleon_coupled_to_J_PSI_str &a_nucleon_coupled_to_J_PSI)
{
  return x_a_nucleon_coupled_to_J_PSI_str (1.0 , a_nucleon_coupled_to_J_PSI);
}

class x_a_nucleon_coupled_to_J_PSI_str operator - (const class a_nucleon_coupled_to_J_PSI_str &a_nucleon_coupled_to_J_PSI)
{
  return x_a_nucleon_coupled_to_J_PSI_str (-1.0 , a_nucleon_coupled_to_J_PSI);
}

class x_a_nucleon_coupled_to_J_PSI_str operator * (const class a_nucleon_coupled_to_J_PSI_str &a_nucleon_coupled_to_J_PSI , const double x)
{
  return x_a_nucleon_coupled_to_J_PSI_str (x , a_nucleon_coupled_to_J_PSI);
}

class x_a_nucleon_coupled_to_J_PSI_str operator * (const double x , const class a_nucleon_coupled_to_J_PSI_str &a_nucleon_coupled_to_J_PSI)
{
  return x_a_nucleon_coupled_to_J_PSI_str (x , a_nucleon_coupled_to_J_PSI);
}

class x_a_nucleon_coupled_to_J_PSI_str operator / (const class a_nucleon_coupled_to_J_PSI_str &a_nucleon_coupled_to_J_PSI , const double x)
{
  const double one_over_x = 1.0/x;

  return x_a_nucleon_coupled_to_J_PSI_str (one_over_x , a_nucleon_coupled_to_J_PSI);
}

class x_a_nucleon_coupled_to_J_PSI_str operator + (const class x_a_nucleon_coupled_to_J_PSI_str &x_a_nucleon_coupled_to_J_PSI)
{
  return x_a_nucleon_coupled_to_J_PSI_str (x_a_nucleon_coupled_to_J_PSI.x , x_a_nucleon_coupled_to_J_PSI.a_nucleon_coupled_to_J_PSI);
}

class x_a_nucleon_coupled_to_J_PSI_str operator - (const class x_a_nucleon_coupled_to_J_PSI_str &x_a_nucleon_coupled_to_J_PSI)
{
  return x_a_nucleon_coupled_to_J_PSI_str (-x_a_nucleon_coupled_to_J_PSI.x , x_a_nucleon_coupled_to_J_PSI.a_nucleon_coupled_to_J_PSI);
}

#ifdef TYPEisDOUBLECOMPLEX

class x_a_nucleon_coupled_to_J_PSI_str operator * (const class a_nucleon_coupled_to_J_PSI_str &a_nucleon_coupled_to_J_PSI , const complex<double> &x)
{
  return x_a_nucleon_coupled_to_J_PSI_str (x , a_nucleon_coupled_to_J_PSI);
}

class x_a_nucleon_coupled_to_J_PSI_str operator * (const complex<double> &x , const class a_nucleon_coupled_to_J_PSI_str &a_nucleon_coupled_to_J_PSI)
{
  return x_a_nucleon_coupled_to_J_PSI_str (x , a_nucleon_coupled_to_J_PSI);
}

class x_a_nucleon_coupled_to_J_PSI_str operator / (const class a_nucleon_coupled_to_J_PSI_str &a_nucleon_coupled_to_J_PSI , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return x_a_nucleon_coupled_to_J_PSI_str (one_over_x , a_nucleon_coupled_to_J_PSI);
}

#endif



