#include "../GSM_include/GSM_include_def.h"


// Loops for two_jumps_pn routines are on in tables but output is on out tables => beware of OpenMP race conditions
// Critical regions are added in pp/nn routines as critical locks are not too numerous.
// BPp_out, Mp_out in non_zero_NBMEs_numbers_two_jumps_pn_part_pn_[N/Z]_valence_larger_calc are considered so that the same PSI_out_index cannot occur for different BPp_out, Mp_out


// TYPE is double or complex
// -------------------------



using namespace inputs_misc;
using namespace GSM_vector_NBMEs_handling;
using namespace GSM_vector_NBMEs_handling::in_to_out;
using namespace GSM_vector_dimensions;
using namespace MPI_2D_partitioning;
using namespace configuration_SD_in_space_one_jump_in_to_out;





void H_class::non_zero_NBMEs_numbers_pp_nn_calc (
						 const class jumps_data_in_to_out_str &jumps , 
						 const class array<bool> &are_PSI_out_indices_accepted , 
						 const class array<unsigned int> &occupied_squares_row_indices ,  
						 const class array<unsigned int> &PSI_out_indices ,
						 class array<unsigned int> &squares_non_zero_NBMEs_numbers)
{
  const unsigned int dimension_jumps = jumps.get_dimension ();
  
  for (unsigned int i = 0 ; i < dimension_jumps ; i++)
    {
      const bool is_PSI_out_index_accepted = are_PSI_out_indices_accepted(i);

      if (is_PSI_out_index_accepted)
	{
	  const unsigned int occupied_squares_row_index = occupied_squares_row_indices(i);

	  const unsigned int PSI_out_index = PSI_out_indices(i);

#ifdef UseOpenMP
#pragma omp atomic
#endif
	  squares_non_zero_NBMEs_numbers(occupied_squares_row_index , PSI_out_index)++;
	}
    }
}






void H_class::non_zero_NBMEs_numbers_jumps_p_part_pn_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
    
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
          
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 

  const int iM = GSM_vector_helper.get_iM (); 

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max  = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max (); 
  const unsigned int dimension_pp_2p2h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_2p2h_space_BP_S_iM_fixed_max ();      
    
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();

  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_inSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_inSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  if (total_inSDp_index_min > total_inSDp_index_max) return;
    
  class array<class jumps_data_in_to_out_str> one_jump_p_tab(NUMBER_OF_THREADS);
  class array<class jumps_data_in_to_out_str> two_jumps_p_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > occupied_squares_row_indices_one_jump_p_tab(NUMBER_OF_THREADS);
  class array<class array<unsigned int> > occupied_squares_row_indices_two_jumps_p_tab(NUMBER_OF_THREADS); 

  class array<class array<bool> > are_PSI_out_indices_accepted_one_jump_p_tabs(NUMBER_OF_THREADS);
  class array<class array<bool> > are_PSI_out_indices_accepted_two_jumps_p_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > PSI_out_indices_one_jump_p_tab(NUMBER_OF_THREADS);
  class array<class array<unsigned int> > PSI_out_indices_two_jumps_p_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_p_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);

      occupied_squares_row_indices_one_jump_p_tab(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);

      are_PSI_out_indices_accepted_one_jump_p_tabs(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);

      PSI_out_indices_one_jump_p_tab(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);
            
      if (ZYval >= 2)
	{
	  two_jumps_p_tab(i).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_pp_2p2h_space_BP_S_iM_fixed_max);
		
	  occupied_squares_row_indices_two_jumps_p_tab(i).allocate (dimension_pp_2p2h_space_BP_S_iM_fixed_max);

	  are_PSI_out_indices_accepted_two_jumps_p_tabs(i).allocate (dimension_pp_2p2h_space_BP_S_iM_fixed_max);

	  PSI_out_indices_two_jumps_p_tab(i).allocate (dimension_pp_2p2h_space_BP_S_iM_fixed_max);
	}      
    }
       
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule(dynamic)
#endif
  for (unsigned long int total_inSDp_index = total_inSDp_index_min ; total_inSDp_index <= total_inSDp_index_max ; total_inSDp_index++)
    {
      const class SD_quantum_numbers &inSDp_qn = SDp_quantum_numbers_tab(total_inSDp_index);

      const int iMp = inSDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = inSDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sp = inSDp_qn.get_S ();

      const int Sn = S - Sp;
      
      const int n_spec_p = inSDp_qn.get_n_spec ();

      const int n_spec_n = n_spec_max - n_spec_p;

      const int n_scat_p_in = inSDp_qn.get_n_scat ();
	
      const unsigned int iCp_in = inSDp_qn.get_iC ();

      const int n_holes_p_in = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p_in , iCp_in);
      
      const int Ep_hw_in = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p_in , iCp_in);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_hw_in , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_inSDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p_in , iCp_in , iMp);

      if (dimension_inSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p_in , iCp_in , iMp);

      if (all_dimensions_SDn_zero) continue;

      const int iMn = iM - iMp;
      
      const unsigned int inSDp_index = inSDp_qn.get_SD_index ();
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class jumps_data_in_to_out_str &one_jump_p  = one_jump_p_tab(i_thread); 
      class jumps_data_in_to_out_str &two_jumps_p = two_jumps_p_tab(i_thread);
      
      class array<unsigned int> &occupied_squares_row_indices_one_jump_p  = occupied_squares_row_indices_one_jump_p_tab(i_thread);
      class array<unsigned int> &occupied_squares_row_indices_two_jumps_p = occupied_squares_row_indices_two_jumps_p_tab(i_thread);
      
      class array<bool> &are_PSI_out_indices_accepted_one_jump_p_tab  = are_PSI_out_indices_accepted_one_jump_p_tabs(i_thread);
      class array<bool> &are_PSI_out_indices_accepted_two_jumps_p_tab = are_PSI_out_indices_accepted_two_jumps_p_tabs(i_thread);
      
      class array<unsigned int> &PSI_out_indices_one_jump_p  = PSI_out_indices_one_jump_p_tab(i_thread);                
      class array<unsigned int> &PSI_out_indices_two_jumps_p = PSI_out_indices_two_jumps_p_tab(i_thread);
		
      bool are_jumps_p_calculated = false;

      bool is_there_one_jump_calc_all = true;

      bool are_there_two_jumps_calc_all = true;

      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && (is_there_one_jump_calc_all || are_there_two_jumps_calc_all) ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
	  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  			  
	  for (unsigned int iCn = iCn_min ; (iCn <= iCn_max) && (is_there_one_jump_calc_all || are_there_two_jumps_calc_all) ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
	      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_hw_in , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);
	      
	      if (dimension_SDn == 0) continue;
				  
	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1; 

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p_in , n_scat_n , iCp_in , iCn , iMp);
	      
	      const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_SDn*inSDp_index;

	      const unsigned long int total_PSI_in_index_dimension_minus_one = total_PSI_in_index_zero + dimension_SDn_minus_one;
				  
	      if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
		{	     
		  if (!are_jumps_p_calculated)
		    {						  			      
		      one_jump_p.one_jump_mu_store (BPp , Sp , n_spec_p , iMp , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp , Sp , n_spec_p , n_scat_p_in , iCp_in , iMp , inSDp_index , prot_Y_data);
			      
		      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();

		      is_there_one_jump_calc_all = (dimension_one_jump_p > 0);
				    
		      if (is_pp_non_zero && (ZYval >= 2))
			{
			  two_jumps_p.two_jumps_mu_store (BPp , Sp , n_spec_p , iMp , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp , Sp , n_spec_p , n_scat_p_in , iCp_in , iMp , inSDp_index , false , false , prot_Y_data);

			  const unsigned int dimension_two_jumps_p = two_jumps_p.get_dimension ();
			      
			  are_there_two_jumps_calc_all = (dimension_two_jumps_p > 0);
			}
			      
		      are_jumps_p_calculated = true;
		    }
		  
		  if (!is_there_one_jump_calc_all && !are_there_two_jumps_calc_all) continue;
		      
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero + SDn_index;

		      if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
			{
			  const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
					  
			  if (is_there_one_jump_calc_all)
			    {
			      bool is_there_one_jump_calc = false;
			  
			      are_PSI_out_indices_accepted_PSI_out_indices_p_fill (BPn , Sn , n_spec_n ,n_holes_n , n_scat_n , iCn , iMn , SDn_index , En_hw , one_jump_p , GSM_vector_helper , dimension_SDn , PSI_in_index ,
										   are_PSI_out_indices_accepted_one_jump_p_tab , occupied_squares_row_indices_one_jump_p , PSI_out_indices_one_jump_p , is_there_one_jump_calc);

			      if (is_there_one_jump_calc)
				non_zero_NBMEs_numbers_pp_nn_calc (one_jump_p , are_PSI_out_indices_accepted_one_jump_p_tab ,
								   occupied_squares_row_indices_one_jump_p , PSI_out_indices_one_jump_p , squares_non_zero_NBMEs_one_jump_numbers);
			    }
			  
			  if (are_there_two_jumps_calc_all)
			    {
			      bool are_there_two_jumps_calc = false;
			  
			      are_PSI_out_indices_accepted_PSI_out_indices_p_fill (BPn , Sn , n_spec_n ,n_holes_n , n_scat_n , iCn , iMn , SDn_index , En_hw , two_jumps_p , GSM_vector_helper , dimension_SDn , PSI_in_index ,
										   are_PSI_out_indices_accepted_two_jumps_p_tab , occupied_squares_row_indices_two_jumps_p , PSI_out_indices_two_jumps_p , are_there_two_jumps_calc);
			  				    
			      if (are_there_two_jumps_calc)				    
				non_zero_NBMEs_numbers_pp_nn_calc (two_jumps_p , are_PSI_out_indices_accepted_two_jumps_p_tab ,
								   occupied_squares_row_indices_two_jumps_p , PSI_out_indices_two_jumps_p , squares_non_zero_NBMEs_two_jumps_numbers);				
			    }}}}}}}
}








void H_class::non_zero_NBMEs_numbers_jumps_n_part_pn_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
    
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM (); 

  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
        
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max  = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max (); 
  const unsigned int dimension_nn_2p2h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_2p2h_space_BP_S_iM_fixed_max (); 

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index ();

  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
      
  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_inSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_inSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();

  if (total_inSDn_index_min > total_inSDn_index_max) return;
    
  class array<class jumps_data_in_to_out_str> one_jump_n_tab(NUMBER_OF_THREADS);
  class array<class jumps_data_in_to_out_str> two_jumps_n_tab(NUMBER_OF_THREADS);
  
  class array<class array<unsigned int> > occupied_squares_row_indices_one_jump_n_tab(NUMBER_OF_THREADS);
  class array<class array<unsigned int> > occupied_squares_row_indices_two_jumps_n_tab(NUMBER_OF_THREADS);
  
  class array<class array<bool> > are_PSI_out_indices_accepted_one_jump_n_tabs(NUMBER_OF_THREADS);
  class array<class array<bool> > are_PSI_out_indices_accepted_two_jumps_n_tabs(NUMBER_OF_THREADS);
  
  class array<class array<unsigned int> > PSI_out_indices_one_jump_n_tab(NUMBER_OF_THREADS);
  class array<class array<unsigned int> > PSI_out_indices_two_jumps_n_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_n_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);

      occupied_squares_row_indices_one_jump_n_tab(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);

      are_PSI_out_indices_accepted_one_jump_n_tabs(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);

      PSI_out_indices_one_jump_n_tab(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      if (NYval >= 2)
	{
	  two_jumps_n_tab(i).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_nn_2p2h_space_BP_S_iM_fixed_max);		

	  occupied_squares_row_indices_two_jumps_n_tab(i).allocate (dimension_nn_2p2h_space_BP_S_iM_fixed_max);

	  are_PSI_out_indices_accepted_two_jumps_n_tabs(i).allocate (dimension_nn_2p2h_space_BP_S_iM_fixed_max);

	  PSI_out_indices_two_jumps_n_tab(i).allocate (dimension_nn_2p2h_space_BP_S_iM_fixed_max);
	}    
    }

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule(dynamic)
#endif
  for (unsigned long int total_inSDn_index = total_inSDn_index_min ; total_inSDn_index <= total_inSDn_index_max ; total_inSDn_index++)
    {
      const class SD_quantum_numbers &inSDn_qn = SDn_quantum_numbers_tab(total_inSDn_index);

      const int iMn = inSDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = inSDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sn = inSDn_qn.get_S ();

      const int Sp = S - Sn;
      
      const int n_spec_n = inSDn_qn.get_n_spec ();

      const int n_spec_p = n_spec_max - n_spec_n;

      const int n_scat_n_in = inSDn_qn.get_n_scat ();
	
      const unsigned int iCn_in = inSDn_qn.get_iC ();

      const int n_holes_n_in = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n_in , iCn_in);
      
      const int En_hw_in = En_hw_table(BPn , Sn , n_spec_n , n_scat_n_in , iCn_in);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_in , n_scat_n_in , En_hw_in , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_in , iCn_in , iMn);

      if (dimension_inSDn == 0) continue;

      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n_in , iCn_in , iMn);

      if (all_dimensions_SDp_zero) continue;

      const unsigned int inSDn_index = inSDn_qn.get_SD_index ();
      
      const int iMp = iM - iMn;
            
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	      
      class jumps_data_in_to_out_str &one_jump_n  = one_jump_n_tab(i_thread);
      class jumps_data_in_to_out_str &two_jumps_n = two_jumps_n_tab(i_thread);
      
      class array<unsigned int> &occupied_squares_row_indices_one_jump_n  = occupied_squares_row_indices_one_jump_n_tab(i_thread);
      class array<unsigned int> &occupied_squares_row_indices_two_jumps_n = occupied_squares_row_indices_two_jumps_n_tab(i_thread);
      
      class array<bool> &are_PSI_out_indices_accepted_one_jump_n_tab  = are_PSI_out_indices_accepted_one_jump_n_tabs(i_thread);
      class array<bool> &are_PSI_out_indices_accepted_two_jumps_n_tab = are_PSI_out_indices_accepted_two_jumps_n_tabs(i_thread);
      
      class array<unsigned int> &PSI_out_indices_one_jump_n  = PSI_out_indices_one_jump_n_tab(i_thread);
      class array<unsigned int> &PSI_out_indices_two_jumps_n = PSI_out_indices_two_jumps_n_tab(i_thread);

      bool are_jumps_n_calculated = false;

      bool is_there_one_jump_calc_all = true;

      bool are_there_two_jumps_calc_all = true;

      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && (is_there_one_jump_calc_all || are_there_two_jumps_calc_all) ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  
	  for (unsigned int iCp = iCp_min ; (iCp <= iCp_max) && (is_there_one_jump_calc_all || are_there_two_jumps_calc_all) ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

	      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n_in , n_scat_n_in , En_hw_in , n_holes_max , n_scat_max  , E_max_hw)) continue;
	      
	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

	      if (dimension_SDp == 0) continue;

	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_in , iCp , iCn_in , iMp);
	      
	      const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;

	      const unsigned long int total_PSI_in_index_dimension_minus_one = total_PSI_in_index_zero + dimension_inSDn*dimension_SDp_minus_one;

	      if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
		{
		  if (!are_jumps_n_calculated)
		    {
		      one_jump_n.one_jump_mu_store (BPn , Sn , n_spec_n , iMn , n_holes_max_n , n_scat_max_n , En_max_hw , BPn , Sn , n_spec_n , n_scat_n_in , iCn_in , iMn , inSDn_index , neut_Y_data);

		      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
						  								  
		      is_there_one_jump_calc_all = (dimension_one_jump_n > 0);
			      				    
		      if (is_nn_non_zero && (NYval >= 2))
			{
			  two_jumps_n.two_jumps_mu_store (BPn , Sn , n_spec_n , iMn , n_holes_max_n , n_scat_max_n , En_max_hw , BPn , Sn , n_spec_n , n_scat_n_in , iCn_in , iMn , inSDn_index , false , false , neut_Y_data);
					
			  const unsigned int dimension_two_jumps_n = two_jumps_n.get_dimension ();
					
			  are_there_two_jumps_calc_all = (dimension_two_jumps_n > 0);
			}
			      
		      are_jumps_n_calculated = true;
		    }
			  
		  if (!is_there_one_jump_calc_all && !are_there_two_jumps_calc_all) continue;
			  
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero + dimension_inSDn*SDp_index;
					
		      if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
			{
			  const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
			  			  
			  if (is_there_one_jump_calc_all)
			    {
			      bool is_there_one_jump_calc = false;
			  
			      are_PSI_out_indices_accepted_PSI_out_indices_n_fill (BPp , Sp , n_spec_p , n_holes_p , n_scat_p , iCp , iMp , SDp_index , Ep_hw , one_jump_n , GSM_vector_helper , PSI_in_index , 
										   are_PSI_out_indices_accepted_one_jump_n_tab , occupied_squares_row_indices_one_jump_n , PSI_out_indices_one_jump_n , is_there_one_jump_calc);
			      
			      non_zero_NBMEs_numbers_pp_nn_calc (one_jump_n , are_PSI_out_indices_accepted_one_jump_n_tab ,
								 occupied_squares_row_indices_one_jump_n , PSI_out_indices_one_jump_n , squares_non_zero_NBMEs_one_jump_numbers);
			    }
			  
			  if (are_there_two_jumps_calc_all)
			    {
			      bool are_there_two_jumps_calc = false;
			      					
			      are_PSI_out_indices_accepted_PSI_out_indices_n_fill (BPp , Sp , n_spec_p , n_holes_p , n_scat_p , iCp , iMp , SDp_index , Ep_hw , two_jumps_n , GSM_vector_helper , PSI_in_index , 
										   are_PSI_out_indices_accepted_two_jumps_n_tab , occupied_squares_row_indices_two_jumps_n ,  PSI_out_indices_two_jumps_n , are_there_two_jumps_calc);
			    
					 
			      if (are_there_two_jumps_calc)
				non_zero_NBMEs_numbers_pp_nn_calc (two_jumps_n , are_PSI_out_indices_accepted_two_jumps_n_tab ,
								   occupied_squares_row_indices_two_jumps_n , PSI_out_indices_two_jumps_n , squares_non_zero_NBMEs_two_jumps_numbers);
			    }}}}}}}
}






























void H_class::non_zero_NBMEs_numbers_two_jumps_pn_part_pn_N_valence_larger_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class array<bool> &MPI_are_squares_occupied = GSM_vector_helper.get_MPI_are_squares_occupied ();

  const class array<unsigned int> &MPI_occupied_squares_row_indices = GSM_vector_helper.get_MPI_occupied_squares_row_indices ();
      
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 

  const int S_plus_one = S + 1;
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();   
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max (); 
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();

  const unsigned int dimension_SDp_max = prot_Y_data.get_dimension_SD_max ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array<unsigned long int> &first_total_PSI_indices = GSM_vector_helper.get_first_total_PSI_indices ();
  const class array<unsigned long int> &last_total_PSI_indices = GSM_vector_helper.get_last_total_PSI_indices ();

  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index ();
      
  const class array<unsigned int> &iCp_in_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_in_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_in_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_in_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  class array<class array<class jumps_data_in_to_out_str> > one_jump_p_tabs_local(NUMBER_OF_THREADS);
  
  class array<class jumps_data_in_to_out_str> one_jump_n_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_p_tabs_local(i).allocate (dimension_SDp_max);
      
      one_jump_n_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
    }
    
  const unsigned int iMp_out_number_max = iMp_max_M - iMp_min_M + 1;

  const unsigned int BPp_Sp_n_spec_p_iMp_out_number_max = 2*S_plus_one*iMp_out_number_max;
		  
  class array<unsigned int> BPp_out_indices(BPp_Sp_n_spec_p_iMp_out_number_max);
  class array<unsigned int> Sp_out_indices (BPp_Sp_n_spec_p_iMp_out_number_max);
  class array<unsigned int> iMp_out_indices(BPp_Sp_n_spec_p_iMp_out_number_max);

  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
    {
      const unsigned int BPn_in = binary_parity_product (BPp_in , BP);

      for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
	{
	  const int Sn_in = S - Sp_in;
		  
	  for (int n_spec_p_in = 0 ; n_spec_p_in <= n_spec_max ; n_spec_p_in++)
	    {
	      const int n_spec_n_in = n_spec_max - n_spec_p_in;
		  
	      const int n_spec_p_out = n_spec_p_in;
	      const int n_spec_n_out = n_spec_n_in;
		      
	      for (int iMp_in = iMp_min_M ; iMp_in <= iMp_max_M ; iMp_in++)
		{
		  const int iMn_in = iM - iMp_in;

		  const int iMp_out_min_M = max (iMp_min_M , iMp_in - mp_max_minus_mp_min);
		  const int iMp_out_max_M = min (iMp_max_M , iMp_in + mp_max_minus_mp_min);

		  if (iMp_out_max_M < iMp_out_min_M) continue;
  
		  const int iMp_out_number = iMp_out_max_M - iMp_out_min_M + 1;

		  const unsigned int BPp_Sp_n_spec_p_iMp_out_number = 2*S_plus_one*iMp_out_number;

		  unsigned int BPp_Sp_n_spec_p_iMp_out_index_init = 0;
		  
		  for (unsigned int BPp_out = 0 ; BPp_out <= 1 ; BPp_out++)
		    for (int Sp_out = 0 ; Sp_out <= S ; Sp_out++)
		      for (int iMp_out = iMp_out_min_M ; iMp_out <= iMp_out_max_M ; iMp_out++)
			{
			  BPp_out_indices(BPp_Sp_n_spec_p_iMp_out_index_init) = BPp_out;
			  Sp_out_indices (BPp_Sp_n_spec_p_iMp_out_index_init) = Sp_out;
			  iMp_out_indices(BPp_Sp_n_spec_p_iMp_out_index_init) = iMp_out;
			  
			  BPp_Sp_n_spec_p_iMp_out_index_init++;
			}

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif      
		  for (unsigned int BPp_Sp_n_spec_p_iMp_out_index = 0 ; BPp_Sp_n_spec_p_iMp_out_index < BPp_Sp_n_spec_p_iMp_out_number ; BPp_Sp_n_spec_p_iMp_out_index++)
		    {	  
		      const unsigned int BPp_out =  BPp_out_indices(BPp_Sp_n_spec_p_iMp_out_index);

		      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);
		      
		      const unsigned int Sp_out =  Sp_out_indices(BPp_Sp_n_spec_p_iMp_out_index);

		      const unsigned int Sn_out = S - Sp_out;

		      const int iMp_out = iMp_out_indices(BPp_Sp_n_spec_p_iMp_out_index);

		      const int iMn_out = iM - iMp_out;

		      const int Delta_iMn_out = iMn_out - iMn_in + two_mn_max;
		      const int Delta_iMp_out = iMp_out - iMp_in + two_mp_max;

		      if ((Delta_iMp_out < 0) || (Delta_iMp_out > four_mp_max)) continue;
		      if ((Delta_iMn_out < 0) || (Delta_iMn_out > four_mn_max)) continue;
	      
		      const unsigned int i_thread = OpenMP_thread_number_determine ();

		      class array<class jumps_data_in_to_out_str> &one_jump_p_tab = one_jump_p_tabs_local(i_thread);
	      
		      class jumps_data_in_to_out_str &one_jump_n = one_jump_n_tab(i_thread);	      
		    
		      for (int n_scat_p_in = 0 ; n_scat_p_in <= n_scat_max_p ; n_scat_p_in++)
			{
			  const unsigned int iCp_in_min = iCp_in_min_process_tab(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in);
			  const unsigned int iCp_in_max = iCp_in_max_process_tab(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in);
		  
			  for (unsigned int iCp_in = iCp_in_min ; iCp_in <= iCp_in_max ; iCp_in++)
			    {
			      const int n_holes_p_in = n_holes_p_table(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in);
		      
			      const int Ep_hw_in = Ep_hw_table(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_hw_in , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
			      for (int n_scat_n_in = 0 ; n_scat_n_in <= n_scat_max_n ; n_scat_n_in++)
				{
				  const unsigned int iCn_in_min = iCn_in_min_process_tab(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in);
				  const unsigned int iCn_in_max = iCn_in_max_process_tab(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in);
			  
				  for (unsigned int iCn_in = iCn_in_min ; iCn_in <= iCn_in_max ; iCn_in++)
				    {
				      const int n_holes_n_in = n_holes_n_table(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in);
			      
				      const int En_hw_in = En_hw_table(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in);
			      
				      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_in , n_scat_n_in , En_hw_in , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
				      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_hw_in , n_holes_n_in , n_scat_n_in , En_hw_in , n_holes_max   , n_scat_max  , E_max_hw)) continue;
				
				      const unsigned int dimension_inSDp = dimensions_SDp_set(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in , iMp_in);
				      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
				  
				      if ((dimension_inSDp == 0) || (dimension_inSDn == 0)) continue;
				  
				      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);

				      const unsigned int dimension_inSDp_minus_one = dimension_inSDp - 1;
				      const unsigned int dimension_inSDn_minus_one = dimension_inSDn - 1;

				      const unsigned int dimensions_inSDn_inSDp_minus_one_product = dimension_inSDn*dimension_inSDp_minus_one;
				
				      const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in;
			      
				      const unsigned long int total_PSI_in_index_dimension_minus_one = sum_dimensions_configuration_Mp_Mn_fixed_in + dimensions_inSDn_inSDp_minus_one_product + dimension_inSDn_minus_one;
 
				      if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
					{
					  for (unsigned int inSDp_index = 0 ; inSDp_index < dimension_inSDp ; inSDp_index++)
					    {
					      const unsigned long int total_PSI_in_index_zero_inSDp_fixed = total_PSI_in_index_zero + dimension_inSDn*inSDp_index;

					      const unsigned long int total_PSI_in_index_dimension_minus_one_inSDp_fixed = total_PSI_in_index_zero_inSDp_fixed + dimension_inSDn_minus_one;
					  
					      if ((total_PSI_in_index_zero_inSDp_fixed <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one_inSDp_fixed >= first_total_PSI_in_index))
						{
						  class jumps_data_in_to_out_str &one_jump_p = one_jump_p_tab(inSDp_index);

						  if (!one_jump_p.is_it_filled ()) one_jump_p.allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
					      
						  one_jump_p.one_jump_mu_store (BPp_out , Sp_out , n_spec_p_out , iMp_out , n_holes_max_p , n_scat_max_p , Ep_max_hw ,
										BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in , iMp_in , inSDp_index , prot_Y_data);
						}
					    }
				      
					  for (unsigned int inSDn_index = 0 ; inSDn_index < dimension_inSDn ; inSDn_index++)
					    {
					      const unsigned long int total_PSI_in_index_zero_inSDn_fixed = total_PSI_in_index_zero + inSDn_index;

					      const unsigned long int total_PSI_in_index_dimension_minus_one_inSDn_fixed = total_PSI_in_index_zero_inSDn_fixed + dimensions_inSDn_inSDp_minus_one_product;
					  
					      if ((total_PSI_in_index_zero_inSDn_fixed <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one_inSDn_fixed >= first_total_PSI_in_index))
						{	
						  bool is_one_jump_n_calculated = false;
					      
						  for (unsigned int inSDp_index = 0 ; inSDp_index < dimension_inSDp ; inSDp_index++)
						    {
						      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDn_fixed + dimension_inSDn*inSDp_index;
					      
						      if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
							{						      
							  if (!is_one_jump_n_calculated)
							    {
							      one_jump_n.one_jump_mu_store (BPn_out , Sn_out , n_spec_n_out , iMn_out , n_holes_max_n , n_scat_max_n , En_max_hw ,
											    BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in , inSDn_index , neut_Y_data);

							      is_one_jump_n_calculated = true;
							    }
						      
							  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

							  if (dimension_one_jump_n == 0) continue;
						      
							  const class jumps_data_in_to_out_str &one_jump_p = one_jump_p_tab(inSDp_index);

							  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();

							  if (dimension_one_jump_p == 0) continue;
						      
							  const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
						      
							  bool is_configuration_accepted = true;
							  
							  unsigned long int total_PSI_out_index_zero_outSDn = 0;

							  for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
							    {
							      const class jumps_data_outSD_str &one_jump_p_outSDp = one_jump_p(ip);

							      const unsigned int iCp_out = one_jump_p_outSDp.get_iC ();

							      const unsigned int outSDp_index = one_jump_p_outSDp.get_outSD_index ();

							      const int n_holes_p_out = one_jump_p_outSDp.get_n_holes ();
							  
							      const int n_scat_p_out = one_jump_p_outSDp.get_n_scat ();

							      const int Ep_hw_out = one_jump_p_outSDp.get_E_hw ();
												  
							      for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)
								{
								  const class jumps_data_outSD_str &one_jump_n_outSDn = one_jump_n(in);

								  const bool is_configuration_changing = one_jump_n_outSDn.get_is_configuration_changing ();

								  if (is_configuration_changing) 
								    {
								      const int n_holes_n_out = one_jump_n_outSDn.get_n_holes ();
								  
								      const int n_scat_n_out = one_jump_n_outSDn.get_n_scat ();

								      const int En_hw_out = one_jump_n_outSDn.get_E_hw ();
								      
								      is_configuration_accepted = true;
									  
								      if (truncation_hw && (Ep_hw_out + En_hw_out > E_max_hw)) is_configuration_accepted = false;
								  
								      if (truncation_ph && ((n_holes_p_out + n_holes_n_out > n_holes_max) || (n_scat_p_out + n_scat_n_out > n_scat_max))) is_configuration_accepted = false;
								      
								      if (is_configuration_accepted) 
									{
									  const unsigned int iCn_out = one_jump_n_outSDn.get_iC ();

									  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out ,
																					   iCp_out , iCn_out , iMp_out);

									  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

									  total_PSI_out_index_zero_outSDn = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;
									}
								    }

								  if (is_configuration_accepted)
								    {
								      const unsigned int outSDn_index = one_jump_n_outSDn.get_outSD_index ();

								      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero_outSDn + outSDn_index;
								  
								      const unsigned int square_row_index = square_row_index_determine_hybrid_1D_2D (total_PSI_out_index , first_total_PSI_indices , last_total_PSI_indices);

								      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);

								      if (is_square_occupied)
									{	
									  const unsigned long int first_total_PSI_out_index = first_total_PSI_indices(square_row_index);
										  
									  const bool is_it_diagonal_square = is_it_diagonal_square_determine_hybrid_1D_2D (is_it_MPI_parallelized_local , square_row_index);
								      
									  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
										  
									  if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index))
									    {
									      const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
									  
									      squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_out_index)++;
									  
									    }}}}}}}}}}}}}}}}}}}
}










void H_class::non_zero_NBMEs_numbers_two_jumps_pn_part_pn_Z_valence_larger_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class array<bool> &MPI_are_squares_occupied = GSM_vector_helper.get_MPI_are_squares_occupied ();

  const class array<unsigned int> &MPI_occupied_squares_row_indices = GSM_vector_helper.get_MPI_occupied_squares_row_indices ();
      
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 

  const int S_plus_one = S + 1;
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();   
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max (); 
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();

  const unsigned int dimension_SDn_max = neut_Y_data.get_dimension_SD_max ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array<unsigned long int> &first_total_PSI_indices = GSM_vector_helper.get_first_total_PSI_indices ();
  const class array<unsigned long int> &last_total_PSI_indices = GSM_vector_helper.get_last_total_PSI_indices ();

  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index ();
      
  const class array<unsigned int> &iCp_in_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_in_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_in_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_in_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();  
  
  class array<class array<class jumps_data_in_to_out_str> > one_jump_n_tabs_local(NUMBER_OF_THREADS);

  class array<class jumps_data_in_to_out_str> one_jump_p_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_n_tabs_local(i).allocate (dimension_SDn_max);
	      
      one_jump_p_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
    }
  
  const int iMp_out_number_max = iMp_max_M - iMp_min_M + 1;

  const unsigned int BPp_Sp_n_spec_p_iMp_out_number_max = 2*S_plus_one*iMp_out_number_max;
		  
  class array<unsigned int> BPp_out_indices(BPp_Sp_n_spec_p_iMp_out_number_max);
  class array<unsigned int> Sp_out_indices (BPp_Sp_n_spec_p_iMp_out_number_max);
  class array<unsigned int> iMp_out_indices(BPp_Sp_n_spec_p_iMp_out_number_max);

  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
    {
      const unsigned int BPn_in = binary_parity_product (BPp_in , BP);

      for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
	{
	  const int Sn_in = S - Sp_in;
		  
	  for (int n_spec_p_in = 0 ; n_spec_p_in <= n_spec_max ; n_spec_p_in++)
	    {
	      const int n_spec_n_in = n_spec_max - n_spec_p_in;
		  
	      const int n_spec_p_out = n_spec_p_in;
	      const int n_spec_n_out = n_spec_n_in;
		      
	      for (int iMp_in = iMp_min_M ; iMp_in <= iMp_max_M ; iMp_in++)
		{
		  const int iMn_in = iM - iMp_in;

		  const int iMp_out_min_M = max (iMp_min_M , iMp_in - mp_max_minus_mp_min);
		  const int iMp_out_max_M = min (iMp_max_M , iMp_in + mp_max_minus_mp_min);

		  if (iMp_out_max_M < iMp_out_min_M) continue;
  
		  const int iMp_out_number = iMp_out_max_M - iMp_out_min_M + 1;

		  const unsigned int BPp_Sp_n_spec_p_iMp_out_number = 2*S_plus_one*iMp_out_number;

		  unsigned int BPp_Sp_n_spec_p_iMp_out_index_init = 0;
		  
		  for (unsigned int BPp_out = 0 ; BPp_out <= 1 ; BPp_out++)
		    for (int Sp_out = 0 ; Sp_out <= S ; Sp_out++)
		      for (int iMp_out = iMp_out_min_M ; iMp_out <= iMp_out_max_M ; iMp_out++)
			{
			  BPp_out_indices(BPp_Sp_n_spec_p_iMp_out_index_init) = BPp_out;
			  Sp_out_indices (BPp_Sp_n_spec_p_iMp_out_index_init) = Sp_out;
			  iMp_out_indices(BPp_Sp_n_spec_p_iMp_out_index_init) = iMp_out;
			  
			  BPp_Sp_n_spec_p_iMp_out_index_init++;
			}

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif      
		  for (unsigned int BPp_Sp_n_spec_p_iMp_out_index = 0 ; BPp_Sp_n_spec_p_iMp_out_index < BPp_Sp_n_spec_p_iMp_out_number ; BPp_Sp_n_spec_p_iMp_out_index++)
		    {	  
		      const unsigned int BPp_out =  BPp_out_indices(BPp_Sp_n_spec_p_iMp_out_index);

		      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);
		      
		      const unsigned int Sp_out =  Sp_out_indices(BPp_Sp_n_spec_p_iMp_out_index);

		      const unsigned int Sn_out = S - Sp_out;

		      const int iMp_out = iMp_out_indices(BPp_Sp_n_spec_p_iMp_out_index);

		      const int iMn_out = iM - iMp_out;

		      const int Delta_iMn_out = iMn_out - iMn_in + two_mn_max;
		      const int Delta_iMp_out = iMp_out - iMp_in + two_mp_max;

		      if ((Delta_iMp_out < 0) || (Delta_iMp_out > four_mp_max)) continue;
		      if ((Delta_iMn_out < 0) || (Delta_iMn_out > four_mn_max)) continue;
	      
		      const unsigned int i_thread = OpenMP_thread_number_determine ();

		      class array<class jumps_data_in_to_out_str> &one_jump_n_tab = one_jump_n_tabs_local(i_thread);
	      
		      class jumps_data_in_to_out_str &one_jump_p = one_jump_p_tab(i_thread);
		      
		      for (int n_scat_p_in = 0 ; n_scat_p_in <= n_scat_max_p ; n_scat_p_in++)
			{
			  const unsigned int iCp_in_min = iCp_in_min_process_tab(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in);
			  const unsigned int iCp_in_max = iCp_in_max_process_tab(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in);
		  
			  for (unsigned int iCp_in = iCp_in_min ; iCp_in <= iCp_in_max ; iCp_in++)
			    {
			      const int n_holes_p_in = n_holes_p_table(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in);
		      
			      const int Ep_hw_in = Ep_hw_table(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_hw_in , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
			      for (int n_scat_n_in = 0 ; n_scat_n_in <= n_scat_max_n ; n_scat_n_in++)
				{
				  const unsigned int iCn_in_min = iCn_in_min_process_tab(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in);
				  const unsigned int iCn_in_max = iCn_in_max_process_tab(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in);
			  
				  for (unsigned int iCn_in = iCn_in_min ; iCn_in <= iCn_in_max ; iCn_in++)
				    {
				      const int n_holes_n_in = n_holes_n_table(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in);
			      
				      const int En_hw_in = En_hw_table(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in);
			      
				      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_in , n_scat_n_in , En_hw_in , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
				      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_hw_in , n_holes_n_in , n_scat_n_in , En_hw_in , n_holes_max , n_scat_max , E_max_hw)) continue;
				
				      const unsigned int dimension_inSDp = dimensions_SDp_set(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in , iMp_in);
				      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
				  
				      if ((dimension_inSDp == 0) || (dimension_inSDn == 0)) continue;
				  
				      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);

				      const unsigned int dimension_inSDp_minus_one = dimension_inSDp - 1;
				      const unsigned int dimension_inSDn_minus_one = dimension_inSDn - 1;

				      const unsigned int dimensions_inSDn_inSDp_minus_one_product = dimension_inSDn*dimension_inSDp_minus_one;
			      
				      const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in;
			      
				      const unsigned long int total_PSI_in_index_dimension_minus_one = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*dimension_inSDp_minus_one + dimension_inSDn_minus_one;
 
				      if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
					{		
					  for (unsigned int inSDn_index = 0 ; inSDn_index < dimension_inSDn ; inSDn_index++)
					    {
					      const unsigned long int total_PSI_in_index_zero_inSDn_fixed = total_PSI_in_index_zero + inSDn_index;

					      const unsigned long int total_PSI_in_index_dimension_minus_one_inSDn_fixed = total_PSI_in_index_zero_inSDn_fixed + dimensions_inSDn_inSDp_minus_one_product;
					  
					      if ((total_PSI_in_index_zero_inSDn_fixed <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one_inSDn_fixed >= first_total_PSI_in_index))
						{
						  class jumps_data_in_to_out_str &one_jump_n = one_jump_n_tab(inSDn_index);

						  if (!one_jump_n.is_it_filled ()) one_jump_n.allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
					      
						  one_jump_n.one_jump_mu_store (BPn_out , Sn_out , n_spec_n_out , iMn_out , n_holes_max_n , n_scat_max_n , En_max_hw ,
										BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in , inSDn_index , neut_Y_data);
						}
					    }
				      
					  for (unsigned int inSDp_index = 0 ; inSDp_index < dimension_inSDp ; inSDp_index++)
					    {
					      const unsigned long int total_PSI_in_index_zero_inSDp_fixed = total_PSI_in_index_zero + inSDp_index*dimension_inSDn;

					      const unsigned long int total_PSI_in_index_dimension_minus_one_inSDp_fixed = total_PSI_in_index_zero_inSDp_fixed + dimension_inSDn_minus_one;

					      if ((total_PSI_in_index_zero_inSDp_fixed <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one_inSDp_fixed >= first_total_PSI_in_index))
						{		
						  bool is_one_jump_p_calculated = false;
				      
						  for (unsigned int inSDn_index = 0 ; inSDn_index < dimension_inSDn ; inSDn_index++)
						    {
						      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDp_fixed + inSDn_index;
					      
						      if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
							{
							  if (!is_one_jump_p_calculated)
							    {
							      one_jump_p.one_jump_mu_store (BPp_out , Sp_out , n_spec_p_out , iMp_out , n_holes_max_p , n_scat_max_p , Ep_max_hw ,
											    BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in , iMp_in , inSDp_index , prot_Y_data);

							      is_one_jump_p_calculated = true;
							    }
						      
							  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();

							  if (dimension_one_jump_p == 0) continue;
						      
							  const class jumps_data_in_to_out_str &one_jump_n = one_jump_n_tab(inSDn_index);

							  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

							  if (dimension_one_jump_n == 0) continue;

							  const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
						      
							  bool is_configuration_accepted = true;
							  
							  unsigned long int total_PSI_out_index_zero_outSDp = 0;

							  for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)  
							    {
							      const class jumps_data_outSD_str &one_jump_n_outSDn = one_jump_n(in);

							      const unsigned int iCn_out = one_jump_n_outSDn.get_iC ();

							      const unsigned int outSDn_index = one_jump_n_outSDn.get_outSD_index ();

							      const int n_holes_n_out = one_jump_n_outSDn.get_n_holes ();
							  
							      const int n_scat_n_out = one_jump_n_outSDn.get_n_scat ();

							      const int En_hw_out = one_jump_n_outSDn.get_E_hw ();

							      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);
												  
							      for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)
								{
								  const class jumps_data_outSD_str &one_jump_p_outSDp = one_jump_p(ip);

								  const bool is_configuration_changing = one_jump_p_outSDp.get_is_configuration_changing ();

								  if (is_configuration_changing) 
								    {
								      const int n_holes_p_out = one_jump_p_outSDp.get_n_holes ();
								  
								      const int n_scat_p_out = one_jump_p_outSDp.get_n_scat ();

								      const int Ep_hw_out = one_jump_p_outSDp.get_E_hw ();
								      
								      is_configuration_accepted = true;
									  
								      if (truncation_hw && (Ep_hw_out + En_hw_out > E_max_hw)) is_configuration_accepted = false;
								  
								      if (truncation_ph && ((n_holes_p_out + n_holes_n_out > n_holes_max) || (n_scat_p_out + n_scat_n_out > n_scat_max))) is_configuration_accepted = false;
								      
								      if (is_configuration_accepted) 
									{
									  const unsigned int iCp_out = one_jump_p_outSDp.get_iC ();

									  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out ,
																					   iCp_out , iCn_out , iMp_out);

									  total_PSI_out_index_zero_outSDp = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
									}
								    }

								  if (is_configuration_accepted)
								    {
								      const unsigned int outSDp_index = one_jump_p_outSDp.get_outSD_index ();

								      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero_outSDp + dimension_outSDn*outSDp_index;
								  
								      const unsigned int square_row_index = square_row_index_determine_hybrid_1D_2D (total_PSI_out_index , first_total_PSI_indices , last_total_PSI_indices);

								      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);

								      if (is_square_occupied)
									{	
									  const unsigned long int first_total_PSI_out_index = first_total_PSI_indices(square_row_index);
										  
									  const bool is_it_diagonal_square = is_it_diagonal_square_determine_hybrid_1D_2D (is_it_MPI_parallelized_local , square_row_index);
								      
									  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
										  
									  if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index))
									    {
									      const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
									  
									      squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_out_index)++;
									  
									    }}}}}}}}}}}}}}}}}}}
}















void H_class::non_zero_NBMEs_numbers_two_jumps_cv_part_pn_N_valence_larger_calc (const bool is_it_cv_pp_to_nn)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class array<bool> &MPI_are_squares_occupied = GSM_vector_helper.get_MPI_are_squares_occupied ();

  const class array<unsigned int> &MPI_occupied_squares_row_indices = GSM_vector_helper.get_MPI_occupied_squares_row_indices ();
      
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 

  const int S_plus_one = S + 1;
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();   
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();

  const unsigned int ZYval = prot_Y_data.get_N_valence_baryons ();
  const unsigned int NYval = neut_Y_data.get_N_valence_baryons ();
      
  const unsigned int ZY_valence_pairs_number = (ZYval*(ZYval - 1))/2;
  const unsigned int NY_valence_pairs_number = (NYval*(NYval - 1))/2;
  
  const unsigned int dimension_SDp_max = prot_Y_data.get_dimension_SD_max ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array<unsigned long int> &first_total_PSI_indices = GSM_vector_helper.get_first_total_PSI_indices ();
  const class array<unsigned long int> &last_total_PSI_indices = GSM_vector_helper.get_last_total_PSI_indices ();

  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index ();
      
  const class array<unsigned int> &iCp_in_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_in_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_in_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_in_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  class array<class array<class jumps_data_in_to_out_str> > two_jumps_p_tabs_local(NUMBER_OF_THREADS);
  
  class array<class jumps_data_in_to_out_str> two_jumps_n_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      class array<class jumps_data_in_to_out_str> &two_jumps_p_tab = two_jumps_p_tabs_local(i);

      two_jumps_p_tab.allocate (dimension_SDp_max);
	
      for (unsigned int ip = 0 ; ip < dimension_SDp_max ; ip++) two_jumps_p_tab(ip).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , ZY_valence_pairs_number);
      
      two_jumps_n_tab(i).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , NY_valence_pairs_number);
    }
  
  const int iMp_out_number_max = iMp_max_M - iMp_min_M + 1;

  const unsigned int BPp_Sp_n_spec_p_iMp_out_number_max = 2*S_plus_one*iMp_out_number_max;
		  
  class array<unsigned int> BPp_out_indices(BPp_Sp_n_spec_p_iMp_out_number_max);
  class array<unsigned int> Sp_out_indices (BPp_Sp_n_spec_p_iMp_out_number_max);
  class array<unsigned int> iMp_out_indices(BPp_Sp_n_spec_p_iMp_out_number_max);

  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
    {
      const unsigned int BPn_in = binary_parity_product (BPp_in , BP);

      for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
	{
	  const int Sn_in = S - Sp_in;
		  
	  for (int n_spec_p_in = 0 ; n_spec_p_in <= n_spec_max ; n_spec_p_in++)
	    {
	      const int n_spec_n_in = n_spec_max - n_spec_p_in;
		  
	      const int n_spec_p_out = (is_it_cv_pp_to_nn) ? (n_spec_p_in + 2) : (n_spec_p_in - 2);
	      const int n_spec_n_out = (is_it_cv_pp_to_nn) ? (n_spec_n_in - 2) : (n_spec_n_in + 2);
      		      
	      for (int iMp_in = iMp_min_M ; iMp_in <= iMp_max_M ; iMp_in++)
		{
		  const int iMn_in = iM - iMp_in;

		  const int iMp_out_min_M = max (iMp_min_M , iMp_in - mp_max_minus_mp_min);
		  const int iMp_out_max_M = min (iMp_max_M , iMp_in + mp_max_minus_mp_min);

		  if (iMp_out_max_M < iMp_out_min_M) continue;
  
		  const int iMp_out_number = iMp_out_max_M - iMp_out_min_M + 1;

		  const unsigned int BPp_Sp_n_spec_p_iMp_out_number = 2*S_plus_one*iMp_out_number;

		  unsigned int BPp_Sp_n_spec_p_iMp_out_index_init = 0;
		  
		  for (unsigned int BPp_out = 0 ; BPp_out <= 1 ; BPp_out++)
		    for (int Sp_out = 0 ; Sp_out <= S ; Sp_out++)
		      for (int iMp_out = iMp_out_min_M ; iMp_out <= iMp_out_max_M ; iMp_out++)
			{
			  BPp_out_indices(BPp_Sp_n_spec_p_iMp_out_index_init) = BPp_out;
			  Sp_out_indices (BPp_Sp_n_spec_p_iMp_out_index_init) = Sp_out;
			  iMp_out_indices(BPp_Sp_n_spec_p_iMp_out_index_init) = iMp_out;
			  
			  BPp_Sp_n_spec_p_iMp_out_index_init++;
			}

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif      
		  for (unsigned int BPp_Sp_n_spec_p_iMp_out_index = 0 ; BPp_Sp_n_spec_p_iMp_out_index < BPp_Sp_n_spec_p_iMp_out_number ; BPp_Sp_n_spec_p_iMp_out_index++)
		    {	  
		      const unsigned int BPp_out =  BPp_out_indices(BPp_Sp_n_spec_p_iMp_out_index);

		      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);
		      
		      const unsigned int Sp_out =  Sp_out_indices(BPp_Sp_n_spec_p_iMp_out_index);

		      const unsigned int Sn_out = S - Sp_out;

		      const int iMp_out = iMp_out_indices(BPp_Sp_n_spec_p_iMp_out_index);

		      const int iMn_out = iM - iMp_out;

		      const int Delta_iMn_out = iMn_out - iMn_in + two_mn_max;
		      const int Delta_iMp_out = iMp_out - iMp_in + two_mp_max;

		      if ((Delta_iMp_out < 0) || (Delta_iMp_out > four_mp_max)) continue;
		      if ((Delta_iMn_out < 0) || (Delta_iMn_out > four_mn_max)) continue;
	      
		      const unsigned int i_thread = OpenMP_thread_number_determine ();

		      class array<class jumps_data_in_to_out_str> &two_jumps_p_tab = two_jumps_p_tabs_local(i_thread);
	      
		      class jumps_data_in_to_out_str &two_jumps_n = two_jumps_n_tab(i_thread);
		    
		      for (int n_scat_p_in = 0 ; n_scat_p_in <= n_scat_max_p ; n_scat_p_in++)
			{
			  const unsigned int iCp_in_min = iCp_in_min_process_tab(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in);
			  const unsigned int iCp_in_max = iCp_in_max_process_tab(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in);
		  
			  for (unsigned int iCp_in = iCp_in_min ; iCp_in <= iCp_in_max ; iCp_in++)
			    {
			      const int n_holes_p_in = n_holes_p_table(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in);
		      
			      const int Ep_hw_in = Ep_hw_table(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_hw_in , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
			      for (int n_scat_n_in = 0 ; n_scat_n_in <= n_scat_max_n ; n_scat_n_in++)
				{
				  const unsigned int iCn_in_min = iCn_in_min_process_tab(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in);
				  const unsigned int iCn_in_max = iCn_in_max_process_tab(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in);
			  
				  for (unsigned int iCn_in = iCn_in_min ; iCn_in <= iCn_in_max ; iCn_in++)
				    {
				      const int n_holes_n_in = n_holes_n_table(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in);
			      
				      const int En_hw_in = En_hw_table(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in);
			      
				      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_in , n_scat_n_in , En_hw_in , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
				      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_hw_in , n_holes_n_in , n_scat_n_in , En_hw_in , n_holes_max   , n_scat_max  , E_max_hw)) continue;
				
				      const unsigned int dimension_inSDp = dimensions_SDp_set(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in , iMp_in);
				      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
				  
				      if ((dimension_inSDp == 0) || (dimension_inSDn == 0)) continue;
				  
				      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);

				      const unsigned int dimension_inSDp_minus_one = dimension_inSDp - 1;
				      const unsigned int dimension_inSDn_minus_one = dimension_inSDn - 1;

				      const unsigned int dimensions_inSDn_inSDp_minus_one_product = dimension_inSDn*dimension_inSDp_minus_one;
				
				      const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in;
			      
				      const unsigned long int total_PSI_in_index_dimension_minus_one = sum_dimensions_configuration_Mp_Mn_fixed_in + dimensions_inSDn_inSDp_minus_one_product + dimension_inSDn_minus_one;
 
				      if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
					{
					  for (unsigned int inSDp_index = 0 ; inSDp_index < dimension_inSDp ; inSDp_index++)
					    {
					      const unsigned long int total_PSI_in_index_zero_inSDp_fixed = total_PSI_in_index_zero + dimension_inSDn*inSDp_index;

					      const unsigned long int total_PSI_in_index_dimension_minus_one_inSDp_fixed = total_PSI_in_index_zero_inSDp_fixed + dimension_inSDn_minus_one;
					  
					      if ((total_PSI_in_index_zero_inSDp_fixed <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one_inSDp_fixed >= first_total_PSI_in_index))
						{
						  class jumps_data_in_to_out_str &two_jumps_p = two_jumps_p_tab(inSDp_index);

						  if (!two_jumps_p.is_it_filled ()) two_jumps_p.allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , ZY_valence_pairs_number);
					      
						  two_jumps_p.two_jumps_mu_store (BPp_out , Sp_out , n_spec_p_out , iMp_out , n_holes_max_p , n_scat_max_p , Ep_max_hw ,
										  BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in , iMp_in , inSDp_index , is_it_cv_pp_to_nn , !is_it_cv_pp_to_nn , prot_Y_data);
						}
					    }
				      
					  for (unsigned int inSDn_index = 0 ; inSDn_index < dimension_inSDn ; inSDn_index++)
					    {
					      const unsigned long int total_PSI_in_index_zero_inSDn_fixed = total_PSI_in_index_zero + inSDn_index;

					      const unsigned long int total_PSI_in_index_dimension_minus_one_inSDn_fixed = total_PSI_in_index_zero_inSDn_fixed + dimensions_inSDn_inSDp_minus_one_product;
					  
					      if ((total_PSI_in_index_zero_inSDn_fixed <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one_inSDn_fixed >= first_total_PSI_in_index))
						{	
						  bool are_two_jumps_n_calculated = false;
					      
						  for (unsigned int inSDp_index = 0 ; inSDp_index < dimension_inSDp ; inSDp_index++)
						    {
						      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDn_fixed + dimension_inSDn*inSDp_index;
					      
						      if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
							{						      
							  if (!are_two_jumps_n_calculated)
							    {
							      two_jumps_n.two_jumps_mu_store (BPn_out , Sn_out , n_spec_n_out , iMn_out , n_holes_max_n , n_scat_max_n , En_max_hw ,
											      BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in , inSDn_index , !is_it_cv_pp_to_nn , is_it_cv_pp_to_nn , neut_Y_data);

							      are_two_jumps_n_calculated = true;
							    }
						      
							  const unsigned int dimension_two_jumps_n = two_jumps_n.get_dimension ();

							  if (dimension_two_jumps_n == 0) continue;
						      
							  const class jumps_data_in_to_out_str &two_jumps_p = two_jumps_p_tab(inSDp_index);

							  const unsigned int dimension_two_jumps_p = two_jumps_p.get_dimension ();

							  if (dimension_two_jumps_p == 0) continue;
						      
							  const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
						      
							  bool is_configuration_accepted = true;
							  
							  unsigned long int total_PSI_out_index_zero_outSDn = 0;

							  for (unsigned int ip = 0 ; ip < dimension_two_jumps_p ; ip++)  
							    {
							      const class jumps_data_outSD_str &two_jumps_p_outSDp = two_jumps_p(ip);

							      const unsigned int iCp_out = two_jumps_p_outSDp.get_iC ();

							      const unsigned int outSDp_index = two_jumps_p_outSDp.get_outSD_index ();

							      const int n_holes_p_out = two_jumps_p_outSDp.get_n_holes ();
							  
							      const int n_scat_p_out = two_jumps_p_outSDp.get_n_scat ();

							      const int Ep_hw_out = two_jumps_p_outSDp.get_E_hw ();
												  
							      for (unsigned int in = 0 ; in < dimension_two_jumps_n ; in++)
								{
								  const class jumps_data_outSD_str &two_jumps_n_outSDn = two_jumps_n(in);

								  const bool is_configuration_changing = two_jumps_n_outSDn.get_is_configuration_changing ();

								  if (is_configuration_changing) 
								    {
								      const int n_holes_n_out = two_jumps_n_outSDn.get_n_holes ();
								  
								      const int n_scat_n_out = two_jumps_n_outSDn.get_n_scat ();

								      const int En_hw_out = two_jumps_n_outSDn.get_E_hw ();
								      
								      is_configuration_accepted = true;
									  
								      if (truncation_hw && (Ep_hw_out + En_hw_out > E_max_hw)) is_configuration_accepted = false;
								  
								      if (truncation_ph && ((n_holes_p_out + n_holes_n_out > n_holes_max) || (n_scat_p_out + n_scat_n_out > n_scat_max))) is_configuration_accepted = false;
								      
								      if (is_configuration_accepted) 
									{
									  const unsigned int iCn_out = two_jumps_n_outSDn.get_iC ();

									  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out ,
																					   iCp_out , iCn_out , iMp_out);

									  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

									  total_PSI_out_index_zero_outSDn = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;
									}
								    }

								  if (is_configuration_accepted)
								    {
								      const unsigned int outSDn_index = two_jumps_n_outSDn.get_outSD_index ();

								      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero_outSDn + outSDn_index;
								  
								      const unsigned int square_row_index = square_row_index_determine_hybrid_1D_2D (total_PSI_out_index , first_total_PSI_indices , last_total_PSI_indices);

								      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);

								      if (is_square_occupied)
									{	
									  const unsigned long int first_total_PSI_out_index = first_total_PSI_indices(square_row_index);
										  
									  const bool is_it_diagonal_square = is_it_diagonal_square_determine_hybrid_1D_2D (is_it_MPI_parallelized_local , square_row_index);
								      
									  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
										  
									  if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index))
									    {
									      const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
									  
									      squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_out_index)++;
									  
									    }}}}}}}}}}}}}}}}}}}
}










void H_class::non_zero_NBMEs_numbers_two_jumps_cv_part_pn_Z_valence_larger_calc (const bool is_it_cv_pp_to_nn)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class array<bool> &MPI_are_squares_occupied = GSM_vector_helper.get_MPI_are_squares_occupied ();

  const class array<unsigned int> &MPI_occupied_squares_row_indices = GSM_vector_helper.get_MPI_occupied_squares_row_indices ();
      
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 

  const int S_plus_one = S + 1;
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();   
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();

  const unsigned int ZYval = prot_Y_data.get_N_valence_baryons ();
  const unsigned int NYval = neut_Y_data.get_N_valence_baryons ();
      
  const unsigned int ZY_valence_pairs_number = (ZYval*(ZYval - 1))/2;
  const unsigned int NY_valence_pairs_number = (NYval*(NYval - 1))/2;
  
  const unsigned int dimension_SDn_max = neut_Y_data.get_dimension_SD_max ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array<unsigned long int> &first_total_PSI_indices = GSM_vector_helper.get_first_total_PSI_indices ();
  const class array<unsigned long int> &last_total_PSI_indices = GSM_vector_helper.get_last_total_PSI_indices ();

  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index ();
      
  const class array<unsigned int> &iCp_in_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_in_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_in_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_in_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();  
  
  class array<class array<class jumps_data_in_to_out_str> > two_jumps_n_tabs_local(NUMBER_OF_THREADS);

  class array<class jumps_data_in_to_out_str> two_jumps_p_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      two_jumps_n_tabs_local(i).allocate (dimension_SDn_max);
      
      two_jumps_p_tab(i).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , ZY_valence_pairs_number);
    }
  
  const int iMp_out_number_max = iMp_max_M - iMp_min_M + 1;

  const unsigned int BPp_Sp_n_spec_p_iMp_out_number_max = 2*S_plus_one*iMp_out_number_max;
		  
  class array<unsigned int> BPp_out_indices(BPp_Sp_n_spec_p_iMp_out_number_max);
  class array<unsigned int> Sp_out_indices (BPp_Sp_n_spec_p_iMp_out_number_max);
  class array<unsigned int> iMp_out_indices(BPp_Sp_n_spec_p_iMp_out_number_max);

  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
    {
      const unsigned int BPn_in = binary_parity_product (BPp_in , BP);

      for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
	{
	  const int Sn_in = S - Sp_in;
		  
	  for (int n_spec_p_in = 0 ; n_spec_p_in <= n_spec_max ; n_spec_p_in++)
	    {
	      const int n_spec_n_in = n_spec_max - n_spec_p_in;
		  
	      const int n_spec_p_out = (is_it_cv_pp_to_nn) ? (n_spec_p_in + 2) : (n_spec_p_in - 2);
	      const int n_spec_n_out = (is_it_cv_pp_to_nn) ? (n_spec_n_in - 2) : (n_spec_n_in + 2);
		      
	      for (int iMp_in = iMp_min_M ; iMp_in <= iMp_max_M ; iMp_in++)
		{
		  const int iMn_in = iM - iMp_in;

		  const int iMp_out_min_M = max (iMp_min_M , iMp_in - mp_max_minus_mp_min);
		  const int iMp_out_max_M = min (iMp_max_M , iMp_in + mp_max_minus_mp_min);

		  if (iMp_out_max_M < iMp_out_min_M) continue;
  
		  const int iMp_out_number = iMp_out_max_M - iMp_out_min_M + 1;

		  const unsigned int BPp_Sp_n_spec_p_iMp_out_number = 2*S_plus_one*iMp_out_number;

		  unsigned int BPp_Sp_n_spec_p_iMp_out_index_init = 0;
		  
		  for (unsigned int BPp_out = 0 ; BPp_out <= 1 ; BPp_out++)
		    for (int Sp_out = 0 ; Sp_out <= S ; Sp_out++)
		      for (int iMp_out = iMp_out_min_M ; iMp_out <= iMp_out_max_M ; iMp_out++)
			{
			  BPp_out_indices(BPp_Sp_n_spec_p_iMp_out_index_init) = BPp_out;
			  Sp_out_indices (BPp_Sp_n_spec_p_iMp_out_index_init) = Sp_out;
			  iMp_out_indices(BPp_Sp_n_spec_p_iMp_out_index_init) = iMp_out;
			  
			  BPp_Sp_n_spec_p_iMp_out_index_init++;
			}

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif      
		  for (unsigned int BPp_Sp_n_spec_p_iMp_out_index = 0 ; BPp_Sp_n_spec_p_iMp_out_index < BPp_Sp_n_spec_p_iMp_out_number ; BPp_Sp_n_spec_p_iMp_out_index++)
		    {	  
		      const unsigned int BPp_out =  BPp_out_indices(BPp_Sp_n_spec_p_iMp_out_index);

		      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);
		      
		      const unsigned int Sp_out =  Sp_out_indices(BPp_Sp_n_spec_p_iMp_out_index);

		      const unsigned int Sn_out = S - Sp_out;

		      const int iMp_out = iMp_out_indices(BPp_Sp_n_spec_p_iMp_out_index);

		      const int iMn_out = iM - iMp_out;

		      const int Delta_iMn_out = iMn_out - iMn_in + two_mn_max;
		      const int Delta_iMp_out = iMp_out - iMp_in + two_mp_max;

		      if ((Delta_iMp_out < 0) || (Delta_iMp_out > four_mp_max)) continue;
		      if ((Delta_iMn_out < 0) || (Delta_iMn_out > four_mn_max)) continue;
	      
		      const unsigned int i_thread = OpenMP_thread_number_determine ();

		      class array<class jumps_data_in_to_out_str> &two_jumps_n_tab = two_jumps_n_tabs_local(i_thread);
	      
		      class jumps_data_in_to_out_str &two_jumps_p = two_jumps_p_tab(i_thread);
		    
		      for (int n_scat_p_in = 0 ; n_scat_p_in <= n_scat_max_p ; n_scat_p_in++)
			{
			  const unsigned int iCp_in_min = iCp_in_min_process_tab(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in);
			  const unsigned int iCp_in_max = iCp_in_max_process_tab(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in);
		  
			  for (unsigned int iCp_in = iCp_in_min ; iCp_in <= iCp_in_max ; iCp_in++)
			    {
			      const int n_holes_p_in = n_holes_p_table(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in);
		      
			      const int Ep_hw_in = Ep_hw_table(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_hw_in , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
			      for (int n_scat_n_in = 0 ; n_scat_n_in <= n_scat_max_n ; n_scat_n_in++)
				{
				  const unsigned int iCn_in_min = iCn_in_min_process_tab(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in);
				  const unsigned int iCn_in_max = iCn_in_max_process_tab(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in);
			  
				  for (unsigned int iCn_in = iCn_in_min ; iCn_in <= iCn_in_max ; iCn_in++)
				    {
				      const int n_holes_n_in = n_holes_n_table(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in);
			      
				      const int En_hw_in = En_hw_table(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in);
			      
				      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_in , n_scat_n_in , En_hw_in , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
				      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_hw_in , n_holes_n_in , n_scat_n_in , En_hw_in , n_holes_max , n_scat_max , E_max_hw)) continue;
				
				      const unsigned int dimension_inSDp = dimensions_SDp_set(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in , iMp_in);
				      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
				  
				      if ((dimension_inSDp == 0) || (dimension_inSDn == 0)) continue;
				  
				      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);

				      const unsigned int dimension_inSDp_minus_one = dimension_inSDp - 1;
				      const unsigned int dimension_inSDn_minus_one = dimension_inSDn - 1;

				      const unsigned int dimensions_inSDn_inSDp_minus_one_product = dimension_inSDn*dimension_inSDp_minus_one;
			      
				      const unsigned long int total_PSI_in_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_in;
			      
				      const unsigned long int total_PSI_in_index_dimension_minus_one = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*dimension_inSDp_minus_one + dimension_inSDn_minus_one;
 
				      if ((total_PSI_in_index_zero <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one >= first_total_PSI_in_index))
					{		
					  for (unsigned int inSDn_index = 0 ; inSDn_index < dimension_inSDn ; inSDn_index++)
					    {
					      const unsigned long int total_PSI_in_index_zero_inSDn_fixed = total_PSI_in_index_zero + inSDn_index;

					      const unsigned long int total_PSI_in_index_dimension_minus_one_inSDn_fixed = total_PSI_in_index_zero_inSDn_fixed + dimensions_inSDn_inSDp_minus_one_product;
					  
					      if ((total_PSI_in_index_zero_inSDn_fixed <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one_inSDn_fixed >= first_total_PSI_in_index))
						{
						  class jumps_data_in_to_out_str &two_jumps_n = two_jumps_n_tab(inSDn_index);

						  if (!two_jumps_n.is_it_filled ()) two_jumps_n.allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , NY_valence_pairs_number);
					      
						  two_jumps_n.two_jumps_mu_store (BPn_out , Sn_out , n_spec_n_out , iMn_out , n_holes_max_n , n_scat_max_n , En_max_hw ,
										  BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in , inSDn_index , !is_it_cv_pp_to_nn , is_it_cv_pp_to_nn , neut_Y_data);
						}
					    }
				      
					  for (unsigned int inSDp_index = 0 ; inSDp_index < dimension_inSDp ; inSDp_index++)
					    {
					      const unsigned long int total_PSI_in_index_zero_inSDp_fixed = total_PSI_in_index_zero + inSDp_index*dimension_inSDn;

					      const unsigned long int total_PSI_in_index_dimension_minus_one_inSDp_fixed = total_PSI_in_index_zero_inSDp_fixed + dimension_inSDn_minus_one;

					      if ((total_PSI_in_index_zero_inSDp_fixed <= last_total_PSI_in_index) && (total_PSI_in_index_dimension_minus_one_inSDp_fixed >= first_total_PSI_in_index))
						{		
						  bool are_two_jumps_p_calculated = false;
				      
						  for (unsigned int inSDn_index = 0 ; inSDn_index < dimension_inSDn ; inSDn_index++)
						    {
						      const unsigned long int total_PSI_in_index = total_PSI_in_index_zero_inSDp_fixed + inSDn_index;
					      
						      if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
							{
							  if (!are_two_jumps_p_calculated)
							    {
							      two_jumps_p.two_jumps_mu_store (BPp_out , Sp_out , n_spec_p_out , iMp_out , n_holes_max_p , n_scat_max_p , Ep_max_hw ,
											      BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , iCp_in , iMp_in , inSDp_index , is_it_cv_pp_to_nn , !is_it_cv_pp_to_nn , prot_Y_data);

							      are_two_jumps_p_calculated = true;
							    }
						      
							  const unsigned int dimension_two_jumps_p = two_jumps_p.get_dimension ();

							  if (dimension_two_jumps_p == 0) continue;
						      
							  const class jumps_data_in_to_out_str &two_jumps_n = two_jumps_n_tab(inSDn_index);

							  const unsigned int dimension_two_jumps_n = two_jumps_n.get_dimension ();

							  if (dimension_two_jumps_n == 0) continue;

							  const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
						      
							  bool is_configuration_accepted = true;
							  
							  unsigned long int total_PSI_out_index_zero_outSDp = 0;

							  for (unsigned int in = 0 ; in < dimension_two_jumps_n ; in++)  
							    {
							      const class jumps_data_outSD_str &two_jumps_n_outSDn = two_jumps_n(in);

							      const unsigned int iCn_out = two_jumps_n_outSDn.get_iC ();

							      const unsigned int outSDn_index = two_jumps_n_outSDn.get_outSD_index ();

							      const int n_holes_n_out = two_jumps_n_outSDn.get_n_holes ();
							  
							      const int n_scat_n_out = two_jumps_n_outSDn.get_n_scat ();

							      const int En_hw_out = two_jumps_n_outSDn.get_E_hw ();

							      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);
												  
							      for (unsigned int ip = 0 ; ip < dimension_two_jumps_p ; ip++)
								{
								  const class jumps_data_outSD_str &two_jumps_p_outSDp = two_jumps_p(ip);

								  const bool is_configuration_changing = two_jumps_p_outSDp.get_is_configuration_changing ();

								  if (is_configuration_changing) 
								    {
								      const int n_holes_p_out = two_jumps_p_outSDp.get_n_holes ();
								  
								      const int n_scat_p_out = two_jumps_p_outSDp.get_n_scat ();

								      const int Ep_hw_out = two_jumps_p_outSDp.get_E_hw ();
								      
								      is_configuration_accepted = true;
									  
								      if (truncation_hw && (Ep_hw_out + En_hw_out > E_max_hw)) is_configuration_accepted = false;
								  
								      if (truncation_ph && ((n_holes_p_out + n_holes_n_out > n_holes_max) || (n_scat_p_out + n_scat_n_out > n_scat_max))) is_configuration_accepted = false;
								      
								      if (is_configuration_accepted) 
									{
									  const unsigned int iCp_out = two_jumps_p_outSDp.get_iC ();

									  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out ,
																					   iCp_out , iCn_out , iMp_out);

									  total_PSI_out_index_zero_outSDp = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
									}
								    }

								  if (is_configuration_accepted)
								    {
								      const unsigned int outSDp_index = two_jumps_p_outSDp.get_outSD_index ();

								      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero_outSDp + dimension_outSDn*outSDp_index;
								  
								      const unsigned int square_row_index = square_row_index_determine_hybrid_1D_2D (total_PSI_out_index , first_total_PSI_indices , last_total_PSI_indices);

								      const bool is_square_occupied = MPI_are_squares_occupied(square_row_index);

								      if (is_square_occupied)
									{	
									  const unsigned long int first_total_PSI_out_index = first_total_PSI_indices(square_row_index);
										  
									  const bool is_it_diagonal_square = is_it_diagonal_square_determine_hybrid_1D_2D (is_it_MPI_parallelized_local , square_row_index);
								      
									  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
										  
									  if (!is_it_diagonal_square || (PSI_out_index < PSI_in_index))
									    {
									      const unsigned int occupied_squares_row_index = MPI_occupied_squares_row_indices(square_row_index);
									  
									      squares_non_zero_NBMEs_two_jumps_numbers(occupied_squares_row_index , PSI_out_index)++;
									  
									    }}}}}}}}}}}}}}}}}}}
}


















void H_class::non_zero_NBMEs_numbers_off_diagonal_pp_nn_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int iM = GSM_vector_helper.get_iM (); 
        
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector (); 
  
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  const unsigned int dimension_1p1h_space_BP_S_iM_fixed_max = data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  const unsigned int dimension_2p2h_space_BP_S_iM_fixed_max = data.get_dimension_2p2h_space_BP_S_iM_fixed_max ();
      
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
    
  const unsigned long int first_total_PSI_in_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_in_index = GSM_vector_helper.get_last_total_PSI_index ();

  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_inSD_index_min = GSM_vector_helper.get_total_SD_index_min ();
  const unsigned long int total_inSD_index_max = GSM_vector_helper.get_total_SD_index_max ();

  if (total_inSD_index_min > total_inSD_index_max) return;
      
  class array<class jumps_data_in_to_out_str> one_jump_mu_tab(NUMBER_OF_THREADS);
  class array<class jumps_data_in_to_out_str> two_jumps_mu_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > occupied_squares_row_indices_one_jump_mu_tab(NUMBER_OF_THREADS);
  class array<class array<unsigned int> > occupied_squares_row_indices_two_jumps_mu_tab(NUMBER_OF_THREADS);  

  class array<class array<bool> > are_PSI_out_indices_accepted_one_jump_mu_tabs(NUMBER_OF_THREADS);
  class array<class array<bool> > are_PSI_out_indices_accepted_two_jumps_mu_tabs(NUMBER_OF_THREADS);
  
  class array<class array<unsigned int> > PSI_out_indices_one_jump_mu_tab(NUMBER_OF_THREADS);
  class array<class array<unsigned int> > PSI_out_indices_two_jumps_mu_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_mu_tab(i).allocate (ONE_JUMP , space , truncation_hw , truncation_ph , dimension_1p1h_space_BP_S_iM_fixed_max);

      occupied_squares_row_indices_one_jump_mu_tab(i).allocate (dimension_1p1h_space_BP_S_iM_fixed_max);

      are_PSI_out_indices_accepted_one_jump_mu_tabs(i).allocate (dimension_1p1h_space_BP_S_iM_fixed_max);

      PSI_out_indices_one_jump_mu_tab(i).allocate (dimension_1p1h_space_BP_S_iM_fixed_max);
          
      if (N_valence_baryons >= 2)
	{
	  two_jumps_mu_tab(i).allocate (TWO_JUMPS , space , truncation_hw , truncation_ph , dimension_2p2h_space_BP_S_iM_fixed_max);

	  occupied_squares_row_indices_two_jumps_mu_tab(i).allocate (dimension_2p2h_space_BP_S_iM_fixed_max);

	  are_PSI_out_indices_accepted_two_jumps_mu_tabs(i).allocate (dimension_2p2h_space_BP_S_iM_fixed_max);

	  PSI_out_indices_two_jumps_mu_tab(i).allocate (dimension_2p2h_space_BP_S_iM_fixed_max);
	}
    }
     
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_inSD_index = total_inSD_index_min ; total_inSD_index <= total_inSD_index_max ; total_inSD_index++)
    {
      const class SD_quantum_numbers &inSD_qn = SD_quantum_numbers_tab(total_inSD_index);

      const unsigned int BP_in = inSD_qn.get_BP ();

      if (BP_in != BP) continue;
      
      const int S_in = inSD_qn.get_S ();

      if (S_in != S) continue;
      
      const int iM_in = inSD_qn.get_iM ();

      if (iM_in != iM) continue;
      
      const unsigned int n_scat_in = inSD_qn.get_n_scat ();

      const unsigned int iC_in = inSD_qn.get_iC ();

      const int n_holes_in = n_holes_table(BP , S , 0 , n_scat_in , iC_in);
      
      const int E_in_hw = E_hw_table(BP , S , 0 , n_scat_in , iC_in);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_in , n_scat_in , E_in_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
      
      const unsigned int inSD_index = inSD_qn.get_SD_index ();

      const unsigned long int sum_dimensions_configuration_fixed_in = sum_dimensions_GSM_vector(n_scat_in , iC_in);

      const unsigned long int total_PSI_in_index = sum_dimensions_configuration_fixed_in + inSD_index;
      
      if ((total_PSI_in_index >= first_total_PSI_in_index) && (total_PSI_in_index <= last_total_PSI_in_index))
	{
	  const unsigned int PSI_in_index = total_PSI_in_index - first_total_PSI_in_index;
       
	  const unsigned int i_thread = OpenMP_thread_number_determine ();

	  class jumps_data_in_to_out_str &one_jump_mu  = one_jump_mu_tab(i_thread);
	  class jumps_data_in_to_out_str &two_jumps_mu = two_jumps_mu_tab(i_thread);
      
	  class array<unsigned int> &occupied_squares_row_indices_one_jump_mu  = occupied_squares_row_indices_one_jump_mu_tab(i_thread);
	  class array<unsigned int> &occupied_squares_row_indices_two_jumps_mu = occupied_squares_row_indices_two_jumps_mu_tab(i_thread);
      
	  class array<bool> &are_PSI_out_indices_accepted_one_jump_mu_tab  = are_PSI_out_indices_accepted_one_jump_mu_tabs(i_thread);
	  class array<bool> &are_PSI_out_indices_accepted_two_jumps_mu_tab = are_PSI_out_indices_accepted_two_jumps_mu_tabs(i_thread);
      
	  class array<unsigned int> &PSI_out_indices_one_jump_mu  = PSI_out_indices_one_jump_mu_tab(i_thread); 
	  class array<unsigned int> &PSI_out_indices_two_jumps_mu = PSI_out_indices_two_jumps_mu_tab(i_thread);
   
	  one_jump_mu.one_jump_mu_store (BP , S , 0 , iM , n_holes_max , n_scat_max , E_max_hw , BP , S , 0 , n_scat_in , iC_in , iM , inSD_index , data);

	  const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();

	  bool is_there_one_jump_calc = (dimension_one_jump_mu > 0);
      
	  if (is_there_one_jump_calc)
	    {
	      are_PSI_out_indices_accepted_PSI_out_indices_pp_nn_fill (one_jump_mu , GSM_vector_helper , PSI_in_index , are_PSI_out_indices_accepted_one_jump_mu_tab ,
								       occupied_squares_row_indices_one_jump_mu , PSI_out_indices_one_jump_mu , is_there_one_jump_calc);
	    
	      if (is_there_one_jump_calc)
		non_zero_NBMEs_numbers_pp_nn_calc (one_jump_mu , are_PSI_out_indices_accepted_one_jump_mu_tab , occupied_squares_row_indices_one_jump_mu , PSI_out_indices_one_jump_mu , squares_non_zero_NBMEs_one_jump_numbers);
	    }
      
	  if (N_valence_baryons >= 2)
	    {
	      two_jumps_mu.two_jumps_mu_store (BP , S , 0 , iM , n_holes_max , n_scat_max , E_max_hw , BP , S , 0 , n_scat_in , iC_in , iM , inSD_index , false , false , data);

	      const unsigned int dimension_two_jumps_mu = two_jumps_mu.get_dimension ();
      
	      bool are_there_two_jumps_calc = (dimension_two_jumps_mu > 0);
		      
	      if (are_there_two_jumps_calc)
		{
		  are_PSI_out_indices_accepted_PSI_out_indices_pp_nn_fill (two_jumps_mu , GSM_vector_helper , PSI_in_index , are_PSI_out_indices_accepted_two_jumps_mu_tab ,
									   occupied_squares_row_indices_two_jumps_mu , PSI_out_indices_two_jumps_mu , are_there_two_jumps_calc);

		  if (are_there_two_jumps_calc)
		    non_zero_NBMEs_numbers_pp_nn_calc (two_jumps_mu , are_PSI_out_indices_accepted_two_jumps_mu_tab , occupied_squares_row_indices_two_jumps_mu , PSI_out_indices_two_jumps_mu , squares_non_zero_NBMEs_two_jumps_numbers);
		}
	    }
	}
    }
}








  
void H_class::squares_non_zero_NBMEs_off_diagonal_numbers_calc ()
{
  const bool is_it_on_the_fly = (Hamiltonian_storage == ON_THE_FLY);

  if (is_it_on_the_fly && !is_there_cout) return;
  
  class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const class GSM_vector_helper_class dummy_helper;

  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);
    
  const enum space_type space = GSM_vector_helper.get_space ();

  const bool configuration_SD_one_jump_tables_to_recalculate_for_off_diagonal_numbers = (is_it_on_the_fly || configuration_SD_one_jump_tables_to_recalculate_for_matrices);
  
  const bool is_it_one_body = (!is_pp_non_zero && !is_nn_non_zero && !is_pn_non_zero);
  
  class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  squares_non_zero_NBMEs_one_jump_numbers  = 0;
  squares_non_zero_NBMEs_two_jumps_numbers = 0;

  if (configuration_SD_one_jump_tables_to_recalculate_for_off_diagonal_numbers)
    configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , is_it_one_body , false , false , false , GSM_vector_helper , GSM_vector_helper , dummy_helper , prot_Y_data , neut_Y_data);

  if (space == PROT_NEUT_Y)
    {   
      const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
      const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
      const int ZYval = prot_Y_data.get_N_valence_baryons ();
      const int NYval = neut_Y_data.get_N_valence_baryons ();
	  
      if (is_one_body_p_non_zero || is_pp_non_zero || is_pn_non_zero) non_zero_NBMEs_numbers_jumps_p_part_pn_calc ();
      if (is_one_body_n_non_zero || is_nn_non_zero || is_pn_non_zero) non_zero_NBMEs_numbers_jumps_n_part_pn_calc ();  
            
      if (is_pn_non_zero)
	{
	  if (NYval >= ZYval)
	    non_zero_NBMEs_numbers_two_jumps_pn_part_pn_N_valence_larger_calc ();
	  else
	    non_zero_NBMEs_numbers_two_jumps_pn_part_pn_Z_valence_larger_calc ();
	}
      
      if (is_cv_non_zero)
	{
	  if (NYval >= ZYval)
	    {
	      non_zero_NBMEs_numbers_two_jumps_cv_part_pn_N_valence_larger_calc (true);
	      non_zero_NBMEs_numbers_two_jumps_cv_part_pn_N_valence_larger_calc (false);
	    }
	  else
	    {
	      non_zero_NBMEs_numbers_two_jumps_cv_part_pn_Z_valence_larger_calc (true);
	      non_zero_NBMEs_numbers_two_jumps_cv_part_pn_Z_valence_larger_calc (false);
	    }
	}
    }
  else
    non_zero_NBMEs_numbers_off_diagonal_pp_nn_calc ();
  
  if (configuration_SD_one_jump_tables_to_recalculate_for_off_diagonal_numbers)
    {
      prot_Y_data.one_jump_tables_in_to_out_deallocate ();
      neut_Y_data.one_jump_tables_in_to_out_deallocate ();
    }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time; 
      
      cout << endl << "Number of non zeros H NBMEs calculated and stored. time:" << relative_time << " s" << endl << endl;
    }
}







double H_class::non_zero_NBMEs_proportion_calc () const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
  
  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();
    
  const unsigned long int total_space_dimension = GSM_vector_helper.get_total_space_dimension ();
  
  const double total_space_dimension_double = total_space_dimension;
  
  const double half_off_diagonal_non_zero_NBMEs_number_process = squares_non_zero_NBMEs_one_jump_numbers.sum () + squares_non_zero_NBMEs_two_jumps_numbers.sum ();
  
  if (is_there_cout)
    {  
      const double off_diagonal_non_zero_NBMEs_number_process = 2.0*half_off_diagonal_non_zero_NBMEs_number_process;
  
      const double off_diagonal_non_zero_NBMEs_number_process_square = off_diagonal_non_zero_NBMEs_number_process*off_diagonal_non_zero_NBMEs_number_process;
  
      const double off_diagonal_non_zero_NBMEs_number_min = min_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , off_diagonal_non_zero_NBMEs_number_process);
      const double off_diagonal_non_zero_NBMEs_number_max = max_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , off_diagonal_non_zero_NBMEs_number_process);
      
      const double off_diagonal_non_zero_NBMEs_number_sum         = sum_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , off_diagonal_non_zero_NBMEs_number_process);
      const double off_diagonal_non_zero_NBMEs_number_squares_sum = sum_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , off_diagonal_non_zero_NBMEs_number_process_square);
      
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  const double off_diagonal_non_zero_NBMEs_number_average = off_diagonal_non_zero_NBMEs_number_sum/NUMBER_OF_PROCESSES;

	  const double off_diagonal_non_zero_NBMEs_number_sigma = statistical_sigma_calc (NUMBER_OF_PROCESSES , off_diagonal_non_zero_NBMEs_number_sum , off_diagonal_non_zero_NBMEs_number_squares_sum);
	  
	  const double TYPE_memory = sizeof (TYPE)/1000000.0;
	  
	  const double off_diagonal_non_zero_NBMEs_equivalent_memory_min     = off_diagonal_non_zero_NBMEs_number_min*TYPE_memory;
	  const double off_diagonal_non_zero_NBMEs_equivalent_memory_max     = off_diagonal_non_zero_NBMEs_number_max*TYPE_memory;
	  const double off_diagonal_non_zero_NBMEs_equivalent_memory_average = off_diagonal_non_zero_NBMEs_number_average*TYPE_memory;
	  const double off_diagonal_non_zero_NBMEs_equivalent_memory_sigma   = off_diagonal_non_zero_NBMEs_number_sigma*TYPE_memory;

	  cout << endl;
	  cout << "Off diagonal non zero NBMEs equivalent memory min used by a process        : " << off_diagonal_non_zero_NBMEs_equivalent_memory_min     << " Mb" << endl;
	  cout << "Off diagonal non zero NBMEs equivalent memory max used by a process        : " << off_diagonal_non_zero_NBMEs_equivalent_memory_max     << " Mb" << endl;
	  cout << "Off diagonal non zero NBMEs equivalent memory average for all processes    : " << off_diagonal_non_zero_NBMEs_equivalent_memory_average << " Mb" << endl;
	  cout << "Off diagonal non zero NBMEs equivalent memory dispersion for all processes : " << off_diagonal_non_zero_NBMEs_equivalent_memory_sigma   << " Mb" << endl;
	  cout << endl;
	}
    }
      
  const double non_zero_NBMEs_number_process = space_dimension_process + half_off_diagonal_non_zero_NBMEs_number_process;
  
  const double non_zero_NBMEs_proportion_process = 100.0*non_zero_NBMEs_number_process/(total_space_dimension_double*total_space_dimension_double);
  
  const double non_zero_NBMEs_proportion = sum_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , non_zero_NBMEs_proportion_process);
    
  return non_zero_NBMEs_proportion;
}


