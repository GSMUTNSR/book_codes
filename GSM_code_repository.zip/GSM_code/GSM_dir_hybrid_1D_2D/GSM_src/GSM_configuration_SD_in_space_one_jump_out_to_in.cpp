#include "../GSM_include/GSM_include_def.h"


using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;
using namespace MPI_2D_partitioning;


// TYPE is double or complex
// -------------------------


// OpenMP is not used in all routines as one can have race conditions

// out_to_in means that one starts from |outSD> and one creates |inSD> from a+ a operations
// ----------------------------------------------------------------------------------------






// Checks if configurations or Slater determinants belong to the in or out space for the protons only, neutrons only or proton-neutron case 
// ----------------------------------------------------------------------------------------------------------------------------------------
// One loops over the configurations and Slater determinants and one considers only those respecting truncations, and parity, M quantum number conservation.
// One does not consider MPI here as one uses hybrid 1D/2D partitioning (see GSM_vector.cpp), where the Hamiltonian is divided in vertical stripes. 
// MPI indeed only distributes the in space of the Hamiltonian.
// One then checks if configurations or Slater determinants belong to the model space (pp/nn or pn case) after one jump a+(a) a(b).
// Associated booleans are stored in arrays.
// These arrays are especially important with MPI, as one uses only parts of the full GSM space on each node.
// One use time-reversal symmetry when dealing with jumps a+(a) a(b). 
// However, proton or neutron Slater determinants are considered to belong to the model space even if Mp, Mn < 0 (pn case only, as otherwise M[SD] is fixed) due to MPI.
// Indeed, |SD> and TRS|SD> do not have to belong to the same MPI node, and data would be missing if suppressing |SDp>, |SDn> because Mp, Mn < 0.
// Hence, one includes all |SD> and TRS|SD> in a node to avoid it.

void configuration_SD_in_space_one_jump_out_to_in::is_configuration_in_inSD_BPin_Sin_Nspec_in_iMin_in_space_pp_nn_determine (
															     const class GSM_vector_helper_class &GSM_vector_helper_in , 
															     class baryons_data &particles_data)
{
  const unsigned long int total_space_dimension_in = GSM_vector_helper_in.get_total_space_dimension ();

  if (total_space_dimension_in == 0) return;

  const bool truncation_hw = GSM_vector_helper_in.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_in.get_truncation_ph ();
  
  const class array<unsigned int> &dimensions_configuration_set = particles_data.get_dimensions_configuration_set ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = particles_data.get_dimensions_SD_set ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = particles_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = particles_data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = particles_data.get_SD_TRS_indices ();
  
  class array<bool> &BPin_Sin_Nspec_in_for_one_jump_tab = particles_data.get_BPin_Sin_Nspec_in_for_one_jump_tab ();

  class array<bool> &BPin_Sin_Nspec_in_iMin_for_one_jump_tab = particles_data.get_BPin_Sin_Nspec_in_iMin_for_one_jump_tab ();
  
  const unsigned int BP = GSM_vector_helper_in.get_BP ();

  const int S = GSM_vector_helper_in.get_S ();

  const int iM = GSM_vector_helper_in.get_iM ();

  const int TRS_iM = GSM_vector_helper_in.get_TRS_iM ();
  
  const int n_holes_max = GSM_vector_helper_in.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_in.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_in.get_E_max_hw ();
      
  class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_in_in_space_tab = particles_data.get_is_configuration_in_in_space_tab (0);

  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_inSD_in_space_tab = particles_data.get_is_inSD_in_space_tab (0);
  
  BPin_Sin_Nspec_in_for_one_jump_tab(BP , S , 0) = true;

  BPin_Sin_Nspec_in_iMin_for_one_jump_tab(BP , S , 0 , iM) = true;
    
  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int dimension_C = dimensions_configuration_set(BP , S , 0 , n_scat);

      for (unsigned int iC = 0 ; iC < dimension_C ; iC++)
	{
	  const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
	  const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD = dimensions_SD_set(BP , S , 0 , n_scat , iC , iM);

	  if (dimension_SD == 0) continue;

	  const unsigned long int SD_TRS_indices_zero_index = SD_TRS_indices.index_determine (BP , S , 0 , n_scat , iC , iM , 0);
	      
	  const unsigned long int is_inSD_in_space_tab_zero_index = is_inSD_in_space_tab.index_determine (BP , S , 0 , n_scat , iC , iM , 0);

	  const unsigned long int is_inSD_in_space_tab_TRS_zero_index = is_inSD_in_space_tab.index_determine (BP , S , 0 , n_scat , iC , TRS_iM , 0);
	      
	  is_configuration_in_in_space_tab(BP , S , 0 , n_scat , iC) = true;
	  
	  for (unsigned int SD_index = 0 ; SD_index < dimension_SD ; SD_index++)
	    {
	      const unsigned long int is_inSD_in_space_tab_index = is_inSD_in_space_tab_zero_index + SD_index;
		      
	      is_inSD_in_space_tab[is_inSD_in_space_tab_index] = true;
			  
	      const unsigned long int SD_TRS_indices_index = SD_TRS_indices_zero_index + SD_index;

	      const unsigned int SD_TRS_index = SD_TRS_indices[SD_TRS_indices_index];

	      const unsigned long int is_inSD_in_space_tab_TRS_index = is_inSD_in_space_tab_TRS_zero_index + SD_TRS_index;
		  
	      is_inSD_in_space_tab[is_inSD_in_space_tab_TRS_index] = true;	
	    }
	}
    }
}

void configuration_SD_in_space_one_jump_out_to_in::is_configuration_out_outSD_in_space_pp_nn_determine (
													const class GSM_vector_helper_class &GSM_vector_helper_out , 
													class baryons_data &particles_data)
{
  const unsigned long int total_space_dimension_out = GSM_vector_helper_out.get_total_space_dimension ();

  if (total_space_dimension_out == 0) return;

  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const class array<unsigned int> &dimensions_configuration_set = particles_data.get_dimensions_configuration_set ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = particles_data.get_dimensions_SD_set ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = particles_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = particles_data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = particles_data.get_SD_TRS_indices ();
  
  const unsigned int BP = GSM_vector_helper_out.get_BP ();
  
  const int S = GSM_vector_helper_out.get_S ();

  const int iM = GSM_vector_helper_out.get_iM ();

  const int TRS_iM = GSM_vector_helper_out.get_TRS_iM ();
  
  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();
    
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper_out.get_first_total_PSI_index ();
  
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper_out.get_last_total_PSI_index ();
    
  class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_out_in_space_tab = particles_data.get_is_configuration_out_in_space_tab ();

  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_outSD_in_space_tab = particles_data.get_is_outSD_in_space_tab ();
    
  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int dimension_C = dimensions_configuration_set(BP , S , 0 , n_scat);

      for (unsigned int iC = 0 ; iC < dimension_C ; iC++)
	{
	  const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
	  const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD = dimensions_SD_set(BP , S , 0 , n_scat , iC , iM);

	  if (dimension_SD == 0) continue;

	  const unsigned int dimension_SD_minus_one = dimension_SD - 1;

	  const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions_GSM_vector(n_scat , iC);

	  const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_fixed;

	  const unsigned long int total_PSI_out_index_dimension_minus_one = sum_dimensions_configuration_fixed + dimension_SD_minus_one;

	  if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
	    { 
	      const unsigned long int SD_TRS_indices_zero_index = SD_TRS_indices.index_determine (BP , S , 0 , n_scat , iC , iM , 0);
	      
	      const unsigned long int is_outSD_in_space_tab_zero_index = is_outSD_in_space_tab.index_determine (BP , S , 0 , n_scat , iC , iM , 0);

	      const unsigned long int is_outSD_in_space_tab_TRS_zero_index = is_outSD_in_space_tab.index_determine (BP , S , 0 , n_scat , iC , TRS_iM , 0);
	      
	      is_configuration_out_in_space_tab(BP , S , 0 , n_scat , iC) = true;
	      	  
	      for (unsigned int SD_index = 0 ; SD_index < dimension_SD ; SD_index++)
		{
		  const unsigned long int total_PSI_out_index = sum_dimensions_configuration_fixed + SD_index;
		  
		  if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
		    {
		      const unsigned long int is_outSD_in_space_tab_index = is_outSD_in_space_tab_zero_index + SD_index;
		      
		      is_outSD_in_space_tab[is_outSD_in_space_tab_index] = true;
			  
		      const unsigned long int SD_TRS_indices_index = SD_TRS_indices_zero_index + SD_index;

		      const unsigned int SD_TRS_index = SD_TRS_indices[SD_TRS_indices_index];

		      const unsigned long int is_outSD_in_space_tab_TRS_index = is_outSD_in_space_tab_TRS_zero_index + SD_TRS_index;
			  
		      is_outSD_in_space_tab[is_outSD_in_space_tab_TRS_index] = true;
		    }}}}}
}

void configuration_SD_in_space_one_jump_out_to_in::is_configuration_in_inSD_BPin_Sin_Nspec_in_iMin_in_space_pn_determine (
															  const class GSM_vector_helper_class &GSM_vector_helper_in , 
															  class baryons_data &prot_Y_data , 
															  class baryons_data &neut_Y_data)
{  
  const unsigned long int total_space_dimension_in = GSM_vector_helper_in.get_total_space_dimension ();

  if (total_space_dimension_in == 0) return;

  const class array<unsigned int> &dimensions_configuration_set_p = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_set_n = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const unsigned int BP = GSM_vector_helper_in.get_BP ();
  
  const int S = GSM_vector_helper_in.get_S ();
  
  const int n_spec_max = GSM_vector_helper_in.get_n_spec_max ();

  const int iM = GSM_vector_helper_in.get_iM ();

  const int iMp_max = prot_Y_data.get_iM_max ();
  const int iMn_max = neut_Y_data.get_iM_max ();
  
  const int iMp_min_M = GSM_vector_helper_in.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper_in.get_iMp_max_M ();
  
  const int n_holes_max_p = GSM_vector_helper_in.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_in.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_in.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_in.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_in.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_in.get_En_max_hw ();

  const bool truncation_hw = GSM_vector_helper_in.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_in.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_in.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_in.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_in.get_E_max_hw ();
   
  class array<bool> &BPin_Sin_Nspec_in_for_one_jump_p_tab = prot_Y_data.get_BPin_Sin_Nspec_in_for_one_jump_tab ();
  class array<bool> &BPin_Sin_Nspec_in_for_one_jump_n_tab = neut_Y_data.get_BPin_Sin_Nspec_in_for_one_jump_tab ();

  class array<bool> &BPin_Sin_Nspec_in_iMin_for_one_jump_p_tab = prot_Y_data.get_BPin_Sin_Nspec_in_iMin_for_one_jump_tab ();
  class array<bool> &BPin_Sin_Nspec_in_iMin_for_one_jump_n_tab = neut_Y_data.get_BPin_Sin_Nspec_in_iMin_for_one_jump_tab ();
  
  class array_BP_S_Nspec_Nscat_iC<bool> &is_p_configuration_in_in_space_tab = prot_Y_data.get_is_configuration_in_in_space_tab (0);
  class array_BP_S_Nspec_Nscat_iC<bool> &is_n_configuration_in_in_space_tab = neut_Y_data.get_is_configuration_in_in_space_tab (0);
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_inSDp_in_space_tab = prot_Y_data.get_is_inSD_in_space_tab (0);
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_inSDn_in_space_tab = neut_Y_data.get_is_inSD_in_space_tab (0);
      
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP); 
      
      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;
	  
	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p;
	  
	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int dimension_Cp = dimensions_configuration_set_p(BPp , Sp , n_spec_p , n_scat_p);

		  for (unsigned int iCp = 0 ; iCp < dimension_Cp ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
		      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
			{
			  const unsigned int dimension_Cn = dimensions_configuration_set_n(BPn , Sn , n_spec_n , n_scat_n);

			  for (unsigned int iCn = 0 ; iCn < dimension_Cn ; iCn++)
			    {
			      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
			      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			
			      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
				{
				  const int iMn = iM - iMp;

				  const int TRS_iMp = iMp_max - iMp;
				  const int TRS_iMn = iMn_max - iMn;

				  const int two_iMp = 2*iMp;
				  const int two_iMn = 2*iMn;
			      
				  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
				  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);
			    
				  if ((dimension_SDn == 0) || (dimension_SDp == 0)) continue;

				  is_p_configuration_in_in_space_tab(BPp , Sp , n_spec_p , n_scat_p , iCp) = true;
				  is_n_configuration_in_in_space_tab(BPn , Sn , n_spec_n , n_scat_n , iCn) = true;

				  BPin_Sin_Nspec_in_for_one_jump_p_tab(BPp , Sp , n_spec_p) = true;
				  BPin_Sin_Nspec_in_for_one_jump_n_tab(BPn , Sn , n_spec_n) = true;
			      
				  (two_iMp >= iMp_max) ? (BPin_Sin_Nspec_in_iMin_for_one_jump_p_tab(BPp , Sp , n_spec_p , iMp) = true) : (BPin_Sin_Nspec_in_iMin_for_one_jump_p_tab(BPp , Sp , n_spec_p , TRS_iMp) = true);				    
				  (two_iMn >= iMn_max) ? (BPin_Sin_Nspec_in_iMin_for_one_jump_n_tab(BPn , Sn , n_spec_n , iMn) = true) : (BPin_Sin_Nspec_in_iMin_for_one_jump_n_tab(BPn , Sn , n_spec_n , TRS_iMn) = true);
				  				  
				  const unsigned long int SDp_TRS_indices_zero_index = SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0);
				  const unsigned long int SDn_TRS_indices_zero_index = SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0);
	      
				  const unsigned long int is_inSDp_in_space_tab_zero_index = is_inSDp_in_space_tab.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0);
				  const unsigned long int is_inSDn_in_space_tab_zero_index = is_inSDn_in_space_tab.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0);
				  
				  const unsigned long int is_inSDp_in_space_tab_TRS_zero_index = is_inSDp_in_space_tab.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , TRS_iMp , 0);
				  const unsigned long int is_inSDn_in_space_tab_TRS_zero_index = is_inSDn_in_space_tab.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , TRS_iMn , 0);
	      
				  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
				    for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
				      {
					const unsigned long int is_inSDp_in_space_tab_index = is_inSDp_in_space_tab_zero_index + SDp_index;
					const unsigned long int is_inSDn_in_space_tab_index = is_inSDn_in_space_tab_zero_index + SDn_index;
						  
					is_inSDp_in_space_tab[is_inSDp_in_space_tab_index] = true;
					is_inSDn_in_space_tab[is_inSDn_in_space_tab_index] = true;
						  
					const unsigned long int SDp_TRS_indices_index = SDp_TRS_indices_zero_index + SDp_index;
					const unsigned long int SDn_TRS_indices_index = SDn_TRS_indices_zero_index + SDn_index;
						  
					const unsigned int SDp_TRS_index = SDp_TRS_indices[SDp_TRS_indices_index];
					const unsigned int SDn_TRS_index = SDn_TRS_indices[SDn_TRS_indices_index];
						  
					const unsigned long int is_inSDp_in_space_tab_TRS_index = is_inSDp_in_space_tab_TRS_zero_index + SDp_TRS_index;
					const unsigned long int is_inSDn_in_space_tab_TRS_index = is_inSDn_in_space_tab_TRS_zero_index + SDn_TRS_index;
		      
					is_inSDp_in_space_tab[is_inSDp_in_space_tab_TRS_index] = true;
					is_inSDn_in_space_tab[is_inSDn_in_space_tab_TRS_index] = true;
					
				      }}}}}}}}}
}

void configuration_SD_in_space_one_jump_out_to_in::is_configuration_out_outSD_in_space_pn_determine (
												     const class GSM_vector_helper_class &GSM_vector_helper_out , 
												     class baryons_data &prot_Y_data , 
												     class baryons_data &neut_Y_data)
{
  const unsigned long int total_space_dimension_out = GSM_vector_helper_out.get_total_space_dimension ();

  if (total_space_dimension_out == 0) return;
  
  const class array<unsigned int> &dimensions_configuration_set_p = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_set_n = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
    
  const unsigned int BP = GSM_vector_helper_out.get_BP ();

  const int S = GSM_vector_helper_out.get_S ();
  
  const int n_spec_max = GSM_vector_helper_out.get_n_spec_max ();

  const int iM = GSM_vector_helper_out.get_iM ();
  
  const int iMp_max = prot_Y_data.get_iM_max ();
  const int iMn_max = neut_Y_data.get_iM_max ();
    
  const int iMp_min_M = GSM_vector_helper_out.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper_out.get_iMp_max_M ();
  
  const int n_holes_max_p = GSM_vector_helper_out.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_out.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_out.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_out.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_out.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_out.get_En_max_hw ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();
  
  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper_out.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper_out.get_last_total_PSI_index ();
  
  class array_BP_S_Nspec_Nscat_iC<bool> &is_p_configuration_out_in_space_tab = prot_Y_data.get_is_configuration_out_in_space_tab ();
  class array_BP_S_Nspec_Nscat_iC<bool> &is_n_configuration_out_in_space_tab = neut_Y_data.get_is_configuration_out_in_space_tab ();
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_outSDp_in_space_tab = prot_Y_data.get_is_outSD_in_space_tab ();
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_outSDn_in_space_tab = neut_Y_data.get_is_outSD_in_space_tab ();
    
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP); 

      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;
      
	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p;
	  
	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int dimension_Cp = dimensions_configuration_set_p(BPp , Sp , n_spec_p , n_scat_p);

		  for (unsigned int iCp = 0 ; iCp < dimension_Cp ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
		      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
			{
			  const unsigned int dimension_Cn = dimensions_configuration_set_n(BPn , Sn , n_spec_n , n_scat_n);

			  for (unsigned int iCn = 0 ; iCn < dimension_Cn ; iCn++)
			    {
			      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
			      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				      
			      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
				{			
				  const int iMn = iM - iMp;

				  const int TRS_iMp = iMp_max - iMp;
				  const int TRS_iMn = iMn_max - iMn;
	      
				  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
				  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);
			      
				  if ((dimension_SDn == 0) || (dimension_SDp == 0)) continue;

				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

				  const unsigned int dimension_SDp_minus_one = dimension_SDp - 1 , dimension_SDn_minus_one = dimension_SDn - 1;
			      
				  const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed;
			      
				  const unsigned long int total_PSI_out_index_dimension_minus_one = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*dimension_SDp_minus_one + dimension_SDn_minus_one;

				  if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
				    {
				      const unsigned long int SDp_TRS_indices_zero_index = SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0);
				      const unsigned long int SDn_TRS_indices_zero_index = SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0);
	      
				      const unsigned long int is_outSDp_in_space_tab_zero_index = is_outSDp_in_space_tab.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0);
				      const unsigned long int is_outSDn_in_space_tab_zero_index = is_outSDn_in_space_tab.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0);
				  
				      const unsigned long int is_outSDp_in_space_tab_TRS_zero_index = is_outSDp_in_space_tab.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , TRS_iMp , 0);
				      const unsigned long int is_outSDn_in_space_tab_TRS_zero_index = is_outSDn_in_space_tab.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , TRS_iMn , 0);
				  
				      is_p_configuration_out_in_space_tab(BPp , Sp , n_spec_p , n_scat_p , iCp) = true;
				      is_n_configuration_out_in_space_tab(BPn , Sn , n_spec_n , n_scat_n , iCn) = true;
				  			      
				      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
					{
					  const unsigned long int total_PSI_out_index_zero_SDp_fixed = total_PSI_out_index_zero + SDp_index*dimension_SDn;
					  const unsigned long int total_PSI_out_index_dimension_minus_one_SDp_fixed = total_PSI_out_index_zero_SDp_fixed + dimension_SDn_minus_one;

					  if ((total_PSI_out_index_zero_SDp_fixed <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one_SDp_fixed >= first_total_PSI_out_index))
					    {
					      for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
						{
						  const unsigned long int total_PSI_out_index = total_PSI_out_index_zero_SDp_fixed + SDn_index;
						    
						  if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
						    {
						      const unsigned long int is_outSDp_in_space_tab_index = is_outSDp_in_space_tab_zero_index + SDp_index;
						      const unsigned long int is_outSDn_in_space_tab_index = is_outSDn_in_space_tab_zero_index + SDn_index;
						  
						      is_outSDp_in_space_tab[is_outSDp_in_space_tab_index] = true;
						      is_outSDn_in_space_tab[is_outSDn_in_space_tab_index] = true;
						  
						      const unsigned long int SDp_TRS_indices_index = SDp_TRS_indices_zero_index + SDp_index;
						      const unsigned long int SDn_TRS_indices_index = SDn_TRS_indices_zero_index + SDn_index;
						  
						      const unsigned int SDp_TRS_index = SDp_TRS_indices[SDp_TRS_indices_index];
						      const unsigned int SDn_TRS_index = SDn_TRS_indices[SDn_TRS_indices_index];
						  
						      const unsigned long int is_outSDp_in_space_tab_TRS_index = is_outSDp_in_space_tab_TRS_zero_index + SDp_TRS_index;
						      const unsigned long int is_outSDn_in_space_tab_TRS_index = is_outSDn_in_space_tab_TRS_zero_index + SDn_TRS_index;
		      
						      is_outSDp_in_space_tab[is_outSDp_in_space_tab_TRS_index] = true;
						      is_outSDn_in_space_tab[is_outSDn_in_space_tab_TRS_index] = true;
						  
						    }}}}}}}}}}}}}
}















// Checks if configurations or Slater determinants belong to the intermediate space for the protons only, neutrons only or proton-neutron case 
// -------------------------------------------------------------------------------------------------------------------------------------------
// A many-body operator is written in second quantization: Op = \sum_ab <a | Op | b> a+(a) a(b) +  \sum_abcd <ab | Op | cd> a+(a) a+(b) a(d) a(c).
// Hence, in order to apply Op to a GSM vector vector, one has to calculate jumps of the form <outSD | a+(a) a(b) | inSD> and <outSD | a+(a) a+(b) a(d) a(c) | inSD>.

// The pp, nn two-body jumps are written as <outSD | a+(a) a+(b) a(d) a(c) | inSD> = <outSD | a+(a) a(c) | SDint> <SDint | a+(b) a(d) | inSD>, with |SDint> an intermediate Slater determinant.
// The pn two-body jumps <outSD | a+(a) a+(b) a(d) a(c) | inSD> are equal to <outSDp | a+(a) a(c) | inSDp> <outSDn | a+(b) a(d) | inSDn>, so that no intermediate Slater determinant is needed here.
// Hence, all jumps can be calculated from those of the form <outSD | a+(a) a(b) | inSD>. 
//
// One then checks if configurations belong to the intermediate space after one jump a+(a) a(b) on a configuration which does not belong to the out space only because of truncations.
// If one arrives in the in space with one of these jumps, it means that the initial configuration belongs to the intermediate space and one can check for the next configuration. 
// Otherwise, it does not belong to the intermediate space.
//
// To check if Slater determinants belong to the intermediate space, one also applies one jump a+(a) a(b) on a Slater determinant which does not belong to the out space only because of truncations.
// One loops over intermediate and out configurations, which have been found in the previous step. 
// One also loops over M_jump = m_in - m_out, which fixes m_in, m_out and M_intermediate as M_out is already fixed. 
// As configurations are fixed, the obtained Slater determinant belongs to the intermediate space if the in state, defined by a+(a) and m_in, is not occupied in the out Slater determinant.
// Otherwise, it does not belong to the intermediate space.
//
// Associated booleans are stored in arrays.

void configuration_SD_in_space_one_jump_out_to_in::is_it_configuration_inter_to_include_determine_all_configurations (
														      const bool is_it_pole_approximation , 
														      class baryons_data &particles_data)
{
  const int strangeness_max = particles_data.get_hypernucleus_strangeness ();
  
  const int n_spec_max = particles_data.get_n_spec_max ();
  
  const int n_scat_max = (is_it_pole_approximation) ? (0) : (particles_data.get_n_scat_max ());

  const class array<unsigned int> &dimensions_configuration_set = particles_data.get_dimensions_configuration_set ();

  const class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_in_in_space_tab = particles_data.get_is_configuration_in_in_space_tab (0);
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_out_in_space_tab = particles_data.get_is_configuration_out_in_space_tab ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_configuration_one_jump_table = particles_data.get_dimensions_configuration_one_jump_table_out_to_in ();
  
  const class array_of_configuration_one_jump_data_out_to_in &configuration_one_jump_table = particles_data.get_configuration_one_jump_table_out_to_in ();

  class array_BP_S_Nspec_Nscat_iC<bool> &is_it_configuration_inter_to_include_tab = particles_data.get_is_it_configuration_inter_to_include_tab ();
  
  for (unsigned int BP_out = 0 ; BP_out <= 1 ; BP_out++)
    for (int S_out = 0 ; S_out <= strangeness_max ; S_out++)
      for (int n_spec_out = 0 ; n_spec_out <= n_spec_max ; n_spec_out++)
	for (int n_scat_out = 0 ; n_scat_out <= n_scat_max ; n_scat_out++)
	  {
	    const unsigned int dimension_C_out = dimensions_configuration_set(BP_out , S_out , n_spec_out , n_scat_out);
	
	    const unsigned int is_configuration_out_in_space_zero_index = is_configuration_out_in_space_tab.index_determine (BP_out , S_out , n_spec_out , n_scat_out , 0);

	    const unsigned int is_it_configuration_inter_to_include_tab_zero_index = is_it_configuration_inter_to_include_tab.index_determine (BP_out , S_out , n_spec_out , n_scat_out , 0);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
	    for (unsigned int iC_out = 0 ; iC_out < dimension_C_out ; iC_out++)
	      {	
		const unsigned int is_configuration_out_in_space_iC_out_index = is_configuration_out_in_space_zero_index + iC_out;

		const unsigned int is_it_configuration_inter_to_include_iC_out_index = is_it_configuration_inter_to_include_tab_zero_index + iC_out;

		const bool is_configuration_out_in_space = is_configuration_out_in_space_tab[is_configuration_out_in_space_iC_out_index];
	    
		if (!is_configuration_out_in_space)
		  {
		    bool &is_it_configuration_inter_to_include = is_it_configuration_inter_to_include_tab[is_it_configuration_inter_to_include_iC_out_index];

		    for (unsigned int BP_in = 0 ; (BP_in <= 1) && (!is_it_configuration_inter_to_include) ; BP_in++)
		      for (int n_spec_in = 0 ; (n_spec_in <= n_spec_max) && (!is_it_configuration_inter_to_include) ; n_spec_in++)
			for (int S_in = 0 ; (S_in <= strangeness_max) && (!is_it_configuration_inter_to_include) ; S_in++)
			  {
			    const unsigned int dimensions_configuration_one_jump_index = dimensions_configuration_one_jump_table.index_determine (BP_out , S_out , n_spec_out , n_scat_out , iC_out , BP_in , S_in , n_spec_in);

			    const unsigned int dimensions_configuration_one_jump_table_C_out = dimensions_configuration_one_jump_table[dimensions_configuration_one_jump_index];

			    const unsigned int configuration_one_jump_table_zero_index = configuration_one_jump_table.index_determine (BP_out , S_out , n_spec_out , n_scat_out , iC_out , BP_in , S_in , n_spec_in , 0);

			    for (unsigned int C_one_jump_index = 0 ; (C_one_jump_index < dimensions_configuration_one_jump_table_C_out) && (!is_it_configuration_inter_to_include) ; C_one_jump_index++)
			      {	
				const unsigned int C_one_jump_table_index = configuration_one_jump_table_zero_index + C_one_jump_index;

				const class configuration_one_jump_data_out_to_in_str &C_one_jump_data_out = configuration_one_jump_table[C_one_jump_table_index];

				const unsigned int iC_in = C_one_jump_data_out.get_iC_in ();

				const int n_scat_in = C_one_jump_data_out.get_n_scat_in ();

				const bool is_configuration_in_in_space = is_configuration_in_in_space_tab(BP_in , S_in , n_spec_in , n_scat_in , iC_in);
			
				if (is_configuration_in_in_space) is_it_configuration_inter_to_include = true;      
			      }}}}}
}

bool configuration_SD_in_space_one_jump_out_to_in::is_it_SD_inter_to_include_fixed_configuration_in_determine (
													       const class configuration &C_out , 
													       const class Slater_determinant &outSD ,
													       const int M_jump , 
													       const unsigned int C_in_jump_shell , 
													       const unsigned int C_out_jump_shell , 
													       class baryons_data &particles_data)
{ 
  const int N_valence_baryons = particles_data.get_N_valence_baryons ();

  const int m_max_minus_half = particles_data.get_m_max_minus_half ();

  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();

  const class one_body_indices_str &one_body_indices = particles_data.get_one_body_indices ();

  const class nlj_struct &shell_qn_in = shells_qn(C_in_jump_shell);

  const int ij_in = shell_qn_in.get_ij ();

  const int im_in_min = -ij_in + m_max_minus_half;
  const int im_in_max =  ij_in + m_max_minus_half + 1;

  const bool shell_in_in_C_out = C_out.is_shell_occupied (C_in_jump_shell);			

  for (int i = 0 ; i < N_valence_baryons ; i++)
    {
      const unsigned int shell_out_index = C_out[i];
      
      if (shell_out_index == C_out_jump_shell)
	{
	  const unsigned int out_jump = outSD[i];
	  
	  const class nljm_struct &phi_out_jump = phi_table(out_jump);
	  
	  const int im_out = phi_out_jump.get_im ();

	  const int im_in = im_out + M_jump;
	  
	  if ((im_in >= im_in_min) && (im_in <= im_in_max))
	    {   
	      const unsigned int in_jump = one_body_indices(C_in_jump_shell , im_in);

	      const bool is_in_jump_occupied_in_outSD = (shell_in_in_C_out && outSD.is_valence_state_occupied (in_jump));

	      if (!is_in_jump_occupied_in_outSD) return true;
	    }
	}
    }

  return false;
}

void configuration_SD_in_space_one_jump_out_to_in::is_it_SD_inter_to_include_determine_all_SDs (
												const bool is_it_pole_approximation , 
												class baryons_data &particles_data)
{ 
  const int strangeness_max = particles_data.get_hypernucleus_strangeness ();
  
  const int n_spec_max = particles_data.get_n_spec_max ();
  
  const int n_scat_max = (is_it_pole_approximation) ? (0) : (particles_data.get_n_scat_max ());

  const int iM_max = particles_data.get_iM_max ();
  
  const int two_m_max = particles_data.get_two_m_max ();

  const int four_m_max = particles_data.get_four_m_max ();

  const int N_valence_baryons = particles_data.get_N_valence_baryons ();
  
  const unsigned long int dimension_SD_total = particles_data.get_dimension_SD_total ();

  const class array_of_configuration &configuration_set = particles_data.get_configuration_set ();
    
  const class array_of_SD &SD_set = particles_data.get_SD_set ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_outSD_in_space_tab = particles_data.get_is_outSD_in_space_tab ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_configuration_one_jump_table = particles_data.get_dimensions_configuration_one_jump_table_out_to_in ();

  const class array_of_configuration_one_jump_data_out_to_in &configuration_one_jump_table = particles_data.get_configuration_one_jump_table_out_to_in ();

  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = particles_data.get_SD_quantum_numbers_tab ();
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_it_SD_inter_to_include_tab = particles_data.get_is_it_SD_inter_to_include_tab ();

  class array<class configuration> C_out_tab(NUMBER_OF_THREADS);
  
  class array<class Slater_determinant> outSD_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      C_out_tab(i).allocate (N_valence_baryons);     

      outSD_tab(i).allocate (N_valence_baryons);
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSD_index = 0 ; total_outSD_index < dimension_SD_total ; total_outSD_index++)
    {
      const class SD_quantum_numbers &outSD_qn = SD_quantum_numbers_tab(total_outSD_index);
      
      const int n_scat_out = outSD_qn.get_n_scat ();

      if (n_scat_out > n_scat_max) continue;
      
      const unsigned int BP_out = outSD_qn.get_BP ();      

      const int S_out = outSD_qn.get_S ();
      
      const int n_spec_out = outSD_qn.get_n_spec ();
      
      const unsigned int iC_out = outSD_qn.get_iC ();

      const int iM_out = outSD_qn.get_iM ();

      const unsigned int outSD_index = outSD_qn.get_SD_index ();

      const bool is_outSD_in_space = is_outSD_in_space_tab(BP_out , S_out , n_spec_out , n_scat_out , iC_out , iM_out , outSD_index);

      if (!is_outSD_in_space)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();

	  class configuration &C_out = C_out_tab(i_thread);

	  class Slater_determinant &outSD = outSD_tab(i_thread);	  

	  bool &is_it_SD_inter_to_include = is_it_SD_inter_to_include_tab(BP_out , S_out , n_spec_out , n_scat_out , iC_out , iM_out , outSD_index);
	  
	  C_out = configuration_set(BP_out , S_out , n_spec_out , n_scat_out , iC_out);
	  
	  outSD = SD_set(BP_out , S_out , n_spec_out , n_scat_out , iC_out , iM_out , outSD_index);
	  
	  for (int Delta_iM_in = 0 ; (Delta_iM_in <= four_m_max) && (!is_it_SD_inter_to_include) ; Delta_iM_in++)
	    {
	      const int M_jump = Delta_iM_in - two_m_max;

	      const int iM_in = iM_out + M_jump;

	      const int two_iM_in = 2*iM_in;
		  
	      if ((two_iM_in >= iM_max) && (iM_in <= iM_max))
		{	
		  for (unsigned int BP_in = 0 ; (BP_in <= 1) && (!is_it_SD_inter_to_include) ; BP_in++)
		    for (int n_spec_in = 0 ; (n_spec_in <= n_spec_max) && (!is_it_SD_inter_to_include) ; n_spec_in++)
		      for (int S_in = 0 ; (S_in <= strangeness_max) && (!is_it_SD_inter_to_include) ; S_in++)
			{
			  const unsigned int dimensions_configuration_one_jump_table_C_out = dimensions_configuration_one_jump_table(BP_out , S_out , n_spec_out , n_scat_out , iC_out , BP_in , S_in , n_spec_in);
	      
			  const unsigned int configuration_one_jump_table_zero_index = configuration_one_jump_table.index_determine (BP_out , S_out , n_spec_out , n_scat_out , iC_out , BP_in , S_in , n_spec_in , 0);

			  unsigned int C_eq_one_jump_index_bef = dimensions_configuration_one_jump_table_C_out;

			  for (unsigned int C_one_jump_index = 0 ; (C_one_jump_index < dimensions_configuration_one_jump_table_C_out) && (!is_it_SD_inter_to_include) ; C_one_jump_index++)
			    {	
			      const unsigned int C_one_jump_table_index = configuration_one_jump_table_zero_index + C_one_jump_index;
			  
			      const class configuration_one_jump_data_out_to_in_str &C_one_jump_data_out = configuration_one_jump_table[C_one_jump_table_index];
			  
			      const unsigned int C_eq_one_jump_index = C_one_jump_data_out.get_C_eq_one_jump_index ();
			  
			      if ((C_one_jump_index == 0) || (C_eq_one_jump_index != C_eq_one_jump_index_bef))
				{
				  const unsigned int C_in_jump_shell  = C_one_jump_data_out.get_C_in_shell ();
				  const unsigned int C_out_jump_shell = C_one_jump_data_out.get_C_out_shell ();
			      
				  const bool is_it_SD_inter_to_include_fixed_configuration_in = is_it_SD_inter_to_include_fixed_configuration_in_determine (C_out , outSD , M_jump , C_in_jump_shell , C_out_jump_shell , particles_data);
			      
				  if (is_it_SD_inter_to_include_fixed_configuration_in) is_it_SD_inter_to_include = true;
				}
			  
			      C_eq_one_jump_index_bef = C_eq_one_jump_index;
			    }}}}}}
}















// Calculations of all booleans checking if configurations or Slater determinants belong to the in or out space for the protons only, neutrons only or proton-neutron case 
// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Routines above are called according to the case.
//
// Intermediate space routines are not called for one-body and T^2 operators, as they are of 1p-1h nature inside proton or neutron space, so that there is no intermediate therein.
//
// If L^2[CM] or J^2 operators are considered, one has M -> M+1 or M -> M-1 as L^2[CM] = L^-[CM].L^+[CM] + Lz[CM].(Lz[CM] + 1) or J^2 = J-.J+ + Jz.(Jz + 1).
// The M -> M-1 is not considered as it symmetric to M-1 -> M, included in M -> M+1 as one sum over all M values.
//
// M is the current angular momentum projection.
// If is_L2_CM_J2_applied is true , GSM_vector_helper_in and GSM_vector_helper_out must be equal. Test is made for M and parity only.
// One must have GSM_vector_helper_in.M = GSM_vector_helper_out.M = M and GSM_vector_helper_Mp1.M = M+1.
// It is compatible with all two-body operators having GSM_vector_helper_in(out).M equal to M , such as H.
// If not, GSM_vector_helper_Mp1 is not used and can be arbitrary.

void configuration_SD_in_space_one_jump_out_to_in::one_jump_tables_alloc_calc_pp_nn (
										     const bool is_there_cout , 
										     const bool is_it_one_body ,
										     const bool is_it_two_body_pn_only , 
										     const bool is_it_pole_approximation , 
										     const bool is_J2_applied ,
										     const bool truncation_hw , 
										     const bool truncation_ph ,  
										     class baryons_data &particles_data)
{
  if (is_J2_applied) SD_one_jump_construction_set_out_to_in::all_SDs_one_jump_all_SDs_alloc_calc_Jpm (is_there_cout , is_it_pole_approximation , true , NADA , particles_data);
  
  const bool is_it_one_body_T2_only = (is_it_one_body || is_it_two_body_pn_only);

  configuration_one_jump_construction_set_out_to_in::all_configurations_one_jump_all_configurations_alloc_calc (is_there_cout , false , is_it_one_body_T2_only , truncation_hw , truncation_ph , is_it_pole_approximation , particles_data);
  
  if (!is_it_one_body_T2_only) 
    {
      is_it_configuration_inter_to_include_determine_all_configurations (is_it_pole_approximation , particles_data);

      is_it_SD_inter_to_include_determine_all_SDs (is_it_pole_approximation , particles_data);
    }

  SD_one_jump_construction_set_out_to_in::all_SDs_one_jump_all_SDs_alloc_calc (is_there_cout , is_it_one_body , is_it_two_body_pn_only , is_it_pole_approximation , particles_data);
}





void configuration_SD_in_space_one_jump_out_to_in::configuration_SD_in_in_space_determine (
											   const bool is_L2_CM_J2_applied ,  
											   const class GSM_vector_helper_class &GSM_vector_helper_in , 
											   const class GSM_vector_helper_class &GSM_vector_helper_Mp1 , 
											   class baryons_data &prot_Y_data , 
											   class baryons_data &neut_Y_data)
{
  const enum space_type space = GSM_vector_helper_in.get_space ();
  
  if (space != NEUT_Y_ONLY)
    {
      prot_Y_data.configuration_SD_in_in_space_BPin_Sin_Nspec_in_iMin_tables_init (false);

      prot_Y_data.configuration_SD_inter_to_include_tables_init (false);
    }

  if (space != PROT_Y_ONLY)
    {
      neut_Y_data.configuration_SD_in_in_space_BPin_Sin_Nspec_in_iMin_tables_init (false);

      neut_Y_data.configuration_SD_inter_to_include_tables_init (false);
    }
  
  if (is_L2_CM_J2_applied)
    {
      const class GSM_vector_helper_class &GSM_vector_helper_M = GSM_vector_helper_in;

      switch (space)
	{
	case PROT_Y_ONLY:
	  {
	    is_configuration_in_inSD_BPin_Sin_Nspec_in_iMin_in_space_pp_nn_determine (GSM_vector_helper_M   , prot_Y_data);
	    is_configuration_in_inSD_BPin_Sin_Nspec_in_iMin_in_space_pp_nn_determine (GSM_vector_helper_Mp1 , prot_Y_data);
	  } break;

	case NEUT_Y_ONLY:	
	  {
	    is_configuration_in_inSD_BPin_Sin_Nspec_in_iMin_in_space_pp_nn_determine (GSM_vector_helper_M   , neut_Y_data);
	    is_configuration_in_inSD_BPin_Sin_Nspec_in_iMin_in_space_pp_nn_determine (GSM_vector_helper_Mp1 , neut_Y_data);
	  } break;

	case PROT_NEUT_Y:
	  {
	    is_configuration_in_inSD_BPin_Sin_Nspec_in_iMin_in_space_pn_determine (GSM_vector_helper_M   , prot_Y_data , neut_Y_data);
	    is_configuration_in_inSD_BPin_Sin_Nspec_in_iMin_in_space_pn_determine (GSM_vector_helper_Mp1 , prot_Y_data , neut_Y_data);
	  } break;

	default: abort_all ();
	}
    }
  else
    {
      switch (space)
	{
	case PROT_Y_ONLY:
	  {
	    is_configuration_in_inSD_BPin_Sin_Nspec_in_iMin_in_space_pp_nn_determine (GSM_vector_helper_in , prot_Y_data);
	  } break;

	case NEUT_Y_ONLY:	
	  {
	    is_configuration_in_inSD_BPin_Sin_Nspec_in_iMin_in_space_pp_nn_determine (GSM_vector_helper_in , neut_Y_data);
	  } break;

	case PROT_NEUT_Y:
	  {
	    is_configuration_in_inSD_BPin_Sin_Nspec_in_iMin_in_space_pn_determine (GSM_vector_helper_in , prot_Y_data , neut_Y_data);
	  } break;

	default: abort_all ();
	}
    }
}

void configuration_SD_in_space_one_jump_out_to_in::configuration_SD_out_in_space_determine (
											    const bool is_L2_CM_J2_applied , 
											    const class GSM_vector_helper_class &GSM_vector_helper_out , 
											    const class GSM_vector_helper_class &GSM_vector_helper_Mp1 , 
											    class baryons_data &prot_Y_data , 
											    class baryons_data &neut_Y_data)
{
  const enum space_type space = GSM_vector_helper_out.get_space ();
  
  if (space != NEUT_Y_ONLY) prot_Y_data.configuration_SD_out_in_space_BPout_Sout_Nspec_out_iMout_tables_init (false);
  if (space != PROT_Y_ONLY) neut_Y_data.configuration_SD_out_in_space_BPout_Sout_Nspec_out_iMout_tables_init (false);

  if (is_L2_CM_J2_applied)
    {
      const class GSM_vector_helper_class &GSM_vector_helper_M = GSM_vector_helper_out;

      switch (space)
	{
	case PROT_Y_ONLY:
	  {
	    is_configuration_out_outSD_in_space_pp_nn_determine (GSM_vector_helper_M   , prot_Y_data);
	    is_configuration_out_outSD_in_space_pp_nn_determine (GSM_vector_helper_Mp1 , prot_Y_data);
	  } break;

	case NEUT_Y_ONLY:	
	  {
	    is_configuration_out_outSD_in_space_pp_nn_determine (GSM_vector_helper_M   , neut_Y_data);
	    is_configuration_out_outSD_in_space_pp_nn_determine (GSM_vector_helper_Mp1 , neut_Y_data);
	  } break;

	case PROT_NEUT_Y:
	  {
	    is_configuration_out_outSD_in_space_pn_determine (GSM_vector_helper_M   , prot_Y_data , neut_Y_data);
	    is_configuration_out_outSD_in_space_pn_determine (GSM_vector_helper_Mp1 , prot_Y_data , neut_Y_data);
	  } break;

	default: abort_all ();
	}
    }
  else
    {
      switch (space)
	{
	case PROT_Y_ONLY:
	  {
	    is_configuration_out_outSD_in_space_pp_nn_determine (GSM_vector_helper_out , prot_Y_data);
	  } break;

	case NEUT_Y_ONLY:	
	  {
	    is_configuration_out_outSD_in_space_pp_nn_determine (GSM_vector_helper_out , neut_Y_data);
	  } break;

	case PROT_NEUT_Y:
	  {
	    is_configuration_out_outSD_in_space_pn_determine (GSM_vector_helper_out , prot_Y_data , neut_Y_data);
	  } break;

	default: abort_all ();
	}
    }
}

void configuration_SD_in_space_one_jump_out_to_in::configuration_SD_in_out_in_space_one_jump_tables_alloc_calc_Jpm (
														    const bool is_there_cout , 
														    const int pm ,
														    const class GSM_vector_helper_class &GSM_vector_helper_in , 
														    const class GSM_vector_helper_class &GSM_vector_helper_out , 
														    class baryons_data &prot_Y_data , 
														    class baryons_data &neut_Y_data)
{
  const class GSM_vector_helper_class dummy_helper;

  const enum space_type space = GSM_vector_helper_out.get_space ();

  const bool is_it_pole_approximation_in  = GSM_vector_helper_in.get_is_it_pole_approximation ();
  const bool is_it_pole_approximation_out = GSM_vector_helper_out.get_is_it_pole_approximation ();

  const bool is_it_pole_approximation = (is_it_pole_approximation_in && is_it_pole_approximation_out);
  
  configuration_SD_in_in_space_determine  (false , GSM_vector_helper_in  , dummy_helper , prot_Y_data , neut_Y_data);
  configuration_SD_out_in_space_determine (false , GSM_vector_helper_out , dummy_helper , prot_Y_data , neut_Y_data);

  if (space != NEUT_Y_ONLY) SD_one_jump_construction_set_out_to_in::all_SDs_one_jump_all_SDs_alloc_calc_Jpm (is_there_cout , is_it_pole_approximation , false , pm , prot_Y_data);
  if (space != PROT_Y_ONLY) SD_one_jump_construction_set_out_to_in::all_SDs_one_jump_all_SDs_alloc_calc_Jpm (is_there_cout , is_it_pole_approximation , false , pm , neut_Y_data);
}

void configuration_SD_in_space_one_jump_out_to_in::configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (
														const bool is_there_cout , 
														const bool is_it_one_body ,
														const bool is_it_two_body_pn_only , 
														const bool is_J2_applied ,
														const bool is_L2_CM_applied ,
														const class GSM_vector_helper_class &GSM_vector_helper_in , 
														const class GSM_vector_helper_class &GSM_vector_helper_out , 
														const class GSM_vector_helper_class &GSM_vector_helper_Mp1 , 
														class baryons_data &prot_Y_data , 
														class baryons_data &neut_Y_data)
{
  const bool is_it_one_body_T2_only = (is_it_one_body || is_it_two_body_pn_only);

  if (is_it_one_body_T2_only && is_L2_CM_applied)
    error_message_print_abort ("is_L2_CM_applied and is_it_one_body_T2_only are incompatible in configuration_SD_in_space_one_jump_out_to_in::configuration_SD_in_out_in_space_one_jump_tables_alloc_calc");

  const bool is_L2_CM_J2_applied = (is_J2_applied || is_L2_CM_applied);
  
  if (is_L2_CM_J2_applied)
    {
      const unsigned int BP_in  = GSM_vector_helper_in.get_BP ();
      const unsigned int BP_out = GSM_vector_helper_out.get_BP ();
      
      const int S_in  = GSM_vector_helper_in.get_S ()  , iM_in  = GSM_vector_helper_in.get_iM ();
      const int S_out = GSM_vector_helper_out.get_S () , iM_out = GSM_vector_helper_out.get_iM ();

      if ((BP_in != BP_out) || (S_in != S_out) || (iM_in != iM_out))
	error_message_print_abort ("With L2_CM or Jpm applied, GSM_vector_helper_[in/out] must have same parity, strangeness and M in onfiguration_SD_in_space_one_jump_in_to_out::configuration_SD_in_out_in_space_one_jump_tables_alloc_calc");
    }
  
  const enum space_type space = GSM_vector_helper_out.get_space ();
 
  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const bool is_it_pole_approximation_in  = GSM_vector_helper_in.get_is_it_pole_approximation ();
  const bool is_it_pole_approximation_out = GSM_vector_helper_out.get_is_it_pole_approximation ();
  const bool is_it_pole_approximation_Mp1 = GSM_vector_helper_Mp1.get_is_it_pole_approximation ();
  
  const bool is_it_pole_approximation_in_out = (is_it_pole_approximation_in && is_it_pole_approximation_out);
  
  const bool is_it_pole_approximation = (is_L2_CM_J2_applied) ? (is_it_pole_approximation_in_out && is_it_pole_approximation_Mp1) : (is_it_pole_approximation_in_out);

  configuration_SD_in_in_space_determine  (is_L2_CM_J2_applied , GSM_vector_helper_in  , GSM_vector_helper_Mp1 , prot_Y_data , neut_Y_data);
  configuration_SD_out_in_space_determine (is_L2_CM_J2_applied , GSM_vector_helper_out , GSM_vector_helper_Mp1 , prot_Y_data , neut_Y_data);
  
  if (space != NEUT_Y_ONLY) one_jump_tables_alloc_calc_pp_nn (is_there_cout , is_it_one_body , is_it_two_body_pn_only , is_it_pole_approximation , is_J2_applied , truncation_hw , truncation_ph , prot_Y_data);
  if (space != PROT_Y_ONLY) one_jump_tables_alloc_calc_pp_nn (is_there_cout , is_it_one_body , is_it_two_body_pn_only , is_it_pole_approximation , is_J2_applied , truncation_hw , truncation_ph , neut_Y_data);
}


