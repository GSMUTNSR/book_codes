#include "../GSM_include/GSM_include_def.h"

// MPI transfer is done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time



// TYPE is double or complex
// -------------------------

// Calculation of overlap functions involving one nucleon
// ------------------------------------------------------
// Spectroscopic factors and overlap functions are related to transfer reactions:
// A stripping reaction removes a nucleon from the projectile and then adds it to the target.
// A pick-up reaction adds a nucleon to the projectile after removing it from the target.
//
// One considers spectroscopic factor amplitudes of one proton or one neutron of a fixed (l,j) partial wave.
// The latter nucleon is called the projectile/ejectile for stripping/pick-up and the initial nucleus the target.
// 
// Spectroscopic factors are of the form S = \sum_{n <= nmax} (<Psi[out] || a+_{nlj} || Psi[in]>^J[out]/hat(J[out]))^2 for stripping
//                                   and S = \sum_{n <= nmax} (<Psi[out] || a~_{nlj} || Psi[in]>^J[out]/hat(J[in]))^2  for pick-up
//
// Overlap functions read: I(r) = \sum_{n <= nmax} <Psi[out] || a+_{nlj} || Psi[in]>^J[out]/hat(J[out]) u_{nlj}(r) for stripping
//                     and I(r) = \sum_{n <= nmax} <Psi[out] || a~_{nlj} || Psi[in]>^J[out]/hat(J[in])  u_{nlj}(r) for pick-up
//
// using the Berggren basis of |nlj> shells, with u_{nlj}(r)/r = <nlj | rlj>.
//
// S = \int_{0}^{+oo} I(r)^2 dr, as u_{nlj}(r) one-body radial basis wave functions are orthogonal.
//
// The spectroscopic amplitude is defined to be equal to <Psi[out] | a+_{nljm} | Psi[in]> for stripping, with m = M[out] - M[in]
//                                                   and <Psi[out] |  a_{nljm} | Psi[in]> for pick-up,   with m = M[in]  - M[out]
//
// One uses M[in] = J[in] and M[out] = J[out] for convenience.
//
// Thus, one first calculates and stores an array of nmax + 1 spectroscopic factor amplitudes.
// Reduced matrix elements function of a+_{nlj} and a~_{nlj} are calculated from the latter using Wigner-Eckart theorem, and one sums over 0 <= n <= nmax afterwards.
// The overlap function directly follows from reduced matrix elements function of a+_{nlj} and a~_{nlj}.
//
// |Psi[out]> is given as input and |Psi[in]> will be read from disk from its provided quantum numbers.
//
// Different routines are used for stripping and pick-up, for proton or neutron projectiles, and if one has both valence protons and neutrons, or only valence protons or neutrons (plus a few hyperons if any).
//
// As the GSM vectors resulting from the action of a+ or a~ on |Psi[in]> are meaningful only in the master process, overlap functions are only calculated in the master process.
//
// 
//
//
// stripping_calc, pick_up_calc
// ----------------------------
// Routines calculating the overlap functions for stripping or pick-up.

void overlap_function::one_baryon::stripping_calc (
						    const bool full_common_vectors_used_in_file ,
						    const class ljm_struct &ljm , 
						    const bool is_it_Gauss_Legendre ,
						    const class correlated_state_str &PSI_IN_qn , 
						    const class correlated_state_str &PSI_OUT_qn , 
						    const class GSM_vector &PSI_OUT , 
						    class array<TYPE> &overlap_function_tab)
{
   const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
 
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const enum particle_type particle = ljm.get_particle ();
  
  const bool is_it_charged = (particle_charge_determine (particle) != 0);
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (is_it_charged) ? (prot_Y_data) : (neut_Y_data);

  if ((space == PROT_Y_ONLY) && !is_it_charged)  error_message_print_abort ("Protons have to be used in a proton space in overlap_function::one_baryon::stripping_calc");
  if ((space == NEUT_Y_ONLY) &&  is_it_charged) error_message_print_abort ("Neutron have to be used in a neutron space in overlap_function::one_baryon::stripping_calc");

  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = data.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
  
  const int nmax = data.get_nmax ();
  
  const int nmax_plus_one = nmax + 1;
  
  const class one_body_indices_str &one_body_indices = data.get_one_body_indices ();

  const class array<class nljm_struct> &phi_table = data.get_phi_table ();

  const class array<class spherical_state> &shells = data.get_shells ();
    	
  const int l = ljm.get_l ();

  const double j = ljm.get_j ();
  const double m = ljm.get_m ();

  const double J_IN  = PSI_IN_qn.get_J ();  
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M (); 

  const double M_IN = M_OUT - m;
  
  class array<TYPE> amplitude_tab(nmax_plus_one);

  spectroscopic_factor_amplitude::one_baryon::stripping_calc (full_common_vectors_used_in_file , ljm , PSI_IN_qn , PSI_OUT , amplitude_tab);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      for (int n = 0 ; n <= nmax ; n++)
	{
	  const unsigned int phi_stripping_index = one_body_indices(particle , n , l , j , m);

	  if (phi_stripping_index != OUT_OF_RANGE)
	    {
	      const class nljm_struct &phi_stripping = phi_table(phi_stripping_index);
	      
	      const unsigned int shell_index = phi_stripping.get_shell_index ();
	      
	      const class spherical_state &wf_stripping = shells(shell_index);

	      const class array<complex<double> > &wf_nlj_bef_R_tab = (is_it_Gauss_Legendre) ? (wf_stripping.get_wf_bef_R_tab_GL ()) : (wf_stripping.get_wf_bef_R_tab_uniform ()); 
	      
	      const TYPE &amplitude = amplitude_tab(n);

	      const TYPE amplitude_reduced = ME_reduced (amplitude , j , m , J_IN , M_IN , J_OUT , M_OUT)/hat (J_OUT);

#ifdef TYPEisDOUBLECOMPLEX
	      for (unsigned int i = 0 ; i < Nr ; i++) overlap_function_tab(i) += amplitude_reduced*wf_nlj_bef_R_tab(i);
#endif
	      
#ifdef TYPEisDOUBLE
	      for (unsigned int i = 0 ; i < Nr ; i++) overlap_function_tab(i) += amplitude_reduced*real (wf_nlj_bef_R_tab(i));
#endif
	    }
	}
    }
}



void overlap_function::one_baryon::pick_up_calc (
						  const bool full_common_vectors_used_in_file ,
						  const class ljm_struct &ljm , 
						  const bool is_it_Gauss_Legendre ,
						  const class correlated_state_str &PSI_IN_qn , 
						  const class correlated_state_str &PSI_OUT_qn , 
						  const class GSM_vector &PSI_OUT , 
						  class array<TYPE> &overlap_function_tab)
{
   const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
 
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const enum particle_type particle = ljm.get_particle ();

  const bool is_it_charged = (particle_charge_determine (particle) != 0);
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (is_it_charged) ? (prot_Y_data) : (neut_Y_data);

  if ((space == PROT_Y_ONLY) && !is_it_charged) error_message_print_abort ("Protons have to be used in a proton space in overlap_function::one_baryon::pick_up_calc");
  if ((space == NEUT_Y_ONLY) &&  is_it_charged) error_message_print_abort ("Neutron have to be used in a neutron space in overlap_function::one_baryon::pick_up_calc");
  
  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = data.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
  
  const int nmax = data.get_nmax ();

  const int nmax_plus_one = nmax + 1;
  
  const class one_body_indices_str &one_body_indices = data.get_one_body_indices ();

  const class array<class nljm_struct> &phi_table = data.get_phi_table ();

  const class array<class spherical_state> &shells = data.get_shells ();
  
  const int l = ljm.get_l ();

  const double j = ljm.get_j ();
  const double m = ljm.get_m ();

  const double J_IN  = PSI_IN_qn.get_J ();  
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M (); 

  const double M_IN = M_OUT + m;
  
  class array<TYPE> amplitude_tab(nmax_plus_one);

  spectroscopic_factor_amplitude::one_baryon::pick_up_calc (full_common_vectors_used_in_file , ljm , PSI_IN_qn , PSI_OUT , amplitude_tab);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      for (int n = 0 ; n <= nmax ; n++)
	{
	  const unsigned int phi_pick_up_index = one_body_indices(particle , n , l , j , m);

	  if (phi_pick_up_index != OUT_OF_RANGE)
	    {    
	      const class nljm_struct &phi_pick_up = phi_table(phi_pick_up_index);
	    
	      const unsigned int shell_index = phi_pick_up.get_shell_index ();
	    
	      const class spherical_state &wf_pick_up = shells(shell_index);
	    
	      const class array<complex<double> > &wf_nlj_bef_R_tab = (is_it_Gauss_Legendre) ? (wf_pick_up.get_wf_bef_R_tab_GL ()) : (wf_pick_up.get_wf_bef_R_tab_uniform ()); 
	  
	      const TYPE &amplitude = amplitude_tab(n);

	      const TYPE amplitude_reduced = ME_reduced (amplitude , j , -m , J_IN , M_IN , J_OUT , M_OUT)/hat (J_IN);

#ifdef TYPEisDOUBLECOMPLEX
	      for (unsigned int i = 0 ; i < Nr ; i++) overlap_function_tab(i) += amplitude_reduced*wf_nlj_bef_R_tab(i);
#endif
	      
#ifdef TYPEisDOUBLE
	      for (unsigned int i = 0 ; i < Nr ; i++) overlap_function_tab(i) += amplitude_reduced*real (wf_nlj_bef_R_tab(i));
#endif
	    }
	}
    }
}


