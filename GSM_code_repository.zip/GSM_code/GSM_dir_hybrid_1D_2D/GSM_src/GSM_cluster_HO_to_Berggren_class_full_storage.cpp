#include "../GSM_include/GSM_include_def.h"



using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;



// TYPE is double or complex
// -------------------------



// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons
// ------------------------------------------------------------------------------------------------------------------------------------------------------





// Calculation and storage of the <SD-Berggren | SD-HO> matrix elements of the operator
// ------------------------------------------------------------------------------------
// One loops over all out basis states |SD-Berggren>, and the proton and neutron overlap <SDp-Berggren | SDp-HO> and <SDn-Berggren | SDn-HO> are stored arrays.
// 
// One stores the NBMEs <SD-Berggren | SD-HO> = <SDp-Berggren | SDp-HO> (pp), <SD-Berggren | SD-HO> = <SDn-Berggren | SDn-HO> (nn),
// <SD-Berggren | SD-HO> = <SDp-Berggren | SDp-HO> . <SDn-Berggren | SDn-HO> (pn), and the index of |SD-HO> in the class.
//
// OpenMP parallelization is used therein, but not MPI. 
// Indeed, cluster wave functions are small, on the one hand, and these routines are used in MPI-distributed loops on the other hand.
// Hence, MPI parallelization has not been implemented.
//
// For the proton-neutron case, one routine is used if Nval >= Zval, and another if not, as SD indices are calculated differently in each case to optimize their use (see GSM_vector_dimensions.cpp).
//
// Once the operator matrix is stored, it can be applied to a |Psi[HO-in]> GSM vector to obtain |Psi[Berggren-out]>.
//
// TRS is time-reversal symmetry. It allows to to calculate about one half of |Psi[out]>, while the rest is given from the first half up to a phase if M=0 in |Psi[in]> and |Psi[out]>.
// Indeed, the components of |SD> and TRS|SD> differ only by a +/-1 phase, which is straightforward to calculate. Hence, only about half of diagonal NBMEs are stored here in this case.



void cluster_HO_to_Berggren_class::non_zero_overlaps_pn_N_valence_larger_calc_store ()
{
  const class GSM_vector_helper_class &GSM_vector_helper_HO_in = get_GSM_vector_helper_HO_in ();
  
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
    
  const class cluster_data &cluster_data = get_cluster_data ();
  
  const class nucleons_data &cluster_prot_data = cluster_data.get_cluster_prot_data (); 
  const class nucleons_data &cluster_neut_data = cluster_data.get_cluster_neut_data ();
  
  const class nucleons_data &cluster_prot_data_HO = cluster_data.get_cluster_prot_data_HO (); 
  const class nucleons_data &cluster_neut_data_HO = cluster_data.get_cluster_neut_data_HO ();
  
  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();
 
  const int n_holes_max_p = GSM_vector_helper_out.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_out.get_n_holes_max_n ();
  
  const int n_holes_max_HO = GSM_vector_helper_HO_in.get_n_holes_max ();
  
  const int n_holes_max_p_HO = GSM_vector_helper_HO_in.get_n_holes_max_p ();
  const int n_holes_max_n_HO = GSM_vector_helper_HO_in.get_n_holes_max_n ();

  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max ();

  const int n_scat_max_p = GSM_vector_helper_out.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_out.get_n_scat_max_n ();
  
  const int n_scat_max_p_HO = GSM_vector_helper_HO_in.get_n_scat_max_p ();
  const int n_scat_max_n_HO = GSM_vector_helper_HO_in.get_n_scat_max_n ();
  
  const int n_scat_max_HO = GSM_vector_helper_HO_in.get_n_scat_max ();
    
  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper_out.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_out.get_En_max_hw ();
  
  const int E_max_hw_HO = GSM_vector_helper_HO_in.get_E_max_hw ();
  
  const int Ep_max_hw_HO = GSM_vector_helper_HO_in.get_Ep_max_hw ();
  const int En_max_hw_HO = GSM_vector_helper_HO_in.get_En_max_hw ();
  
  const int BP = GSM_vector_helper_out.get_BP ();

  const int iM = GSM_vector_helper_out.get_iM ();

  const int iMn_min_M = GSM_vector_helper_out.get_iMn_min_M ();
  const int iMn_max_M = GSM_vector_helper_out.get_iMn_max_M ();
      
  const int iMp_max = cluster_prot_data.get_iM_max ();
  
  const bool is_it_TRS_HO_in = GSM_vector_helper_HO_in.get_is_it_TRS ();

  const bool is_it_TRS_out = GSM_vector_helper_out.get_is_it_TRS ();

  const bool is_it_TRS = (is_it_TRS_HO_in && is_it_TRS_out);
  
  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = cluster_prot_data.get_SD_TRS_indices ();
  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = cluster_neut_data.get_SD_TRS_indices ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector_TRS ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_HO_in = GSM_vector_helper_HO_in.get_sum_dimensions_GSM_vector ();
    
  const class array_BP_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper_out.get_all_dimensions_SDp_zero_tab ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = cluster_prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = cluster_neut_data.get_dimensions_SD_set ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set_HO = cluster_neut_data_HO.get_dimensions_SD_set ();

  const class array_BP_Nscat_iC<int> &n_holes_p_table = cluster_prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = cluster_neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = cluster_prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = cluster_neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<int> &n_holes_table_HO_p = cluster_prot_data_HO.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_table_HO_n = cluster_neut_data_HO.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table_HO = cluster_prot_data_HO.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table_HO = cluster_neut_data_HO.get_E_hw_table ();  

  const class array_BP_Nscat_iC_iM_SD<unsigned int> &prot_dimensions_SD_HO_Berggren_overlaps_table = cluster_prot_data.get_dimensions_SD_HO_Berggren_overlaps_table ();

  const class array_of_SD_HO_Berggren_overlaps_data_str &prot_SD_HO_Berggren_overlaps_table = cluster_prot_data.get_SD_HO_Berggren_overlaps_table ();
  const class array_of_SD_HO_Berggren_overlaps_data_str &neut_SD_HO_Berggren_overlaps_table = cluster_neut_data.get_SD_HO_Berggren_overlaps_table ();

  const class array<unsigned int> &iCp_out_min_process_tab = GSM_vector_helper_out.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_out_max_process_tab = GSM_vector_helper_out.get_iCp_max_process_tab ();
    
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_neut_tab = cluster_neut_data.get_SD_quantum_numbers_tab ();
  
  const unsigned int total_outSDn_index_min = GSM_vector_helper_out.get_total_SDn_index_min ();
  const unsigned int total_outSDn_index_max = GSM_vector_helper_out.get_total_SDn_index_max ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SD_quantum_numbers_neut_tab(total_outSDn_index);

      const int iMn = outSDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = outSDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();
      
      const int n_holes_n_out = n_holes_n_table(BPn , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , n_scat_n_out , iCn_out , iMn);

      if (dimension_outSDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , n_scat_n_out , iCn_out , iMn);

      if (all_dimensions_SDp_zero) continue;
		  
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const int iMp = iM - iMn;

      const int TRS_iMp = iMp_max - iMp;
      
      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , n_scat_n_out , iCn_out , iMn , outSDn_index)) : (NADA);
            
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_process_tab(BPp , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_process_tab(BPp , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , n_scat_p_out , iCp_out , iMp);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector_out(BPp , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp);
	          
	      const unsigned int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
	      
	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS)
		? (sum_dimensions_GSM_vector_TRS_out(BPp , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp))
		: (NADA);
				  
	      const unsigned int total_outSDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , n_scat_p_out , iCp_out , iMp , 0)) : (NADA);
				      
	      const unsigned int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);
				      
	      for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		{
		  const unsigned int total_PSI_out_index = total_PSI_out_index_zero + outSDp_index*dimension_outSDn;
						  
		  const unsigned int total_outSDp_TRS_indices_index = (is_it_TRS) ? (total_outSDp_TRS_indices_zero_index + outSDp_index) : (NADA);

		  const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_outSDp_TRS_indices_index]) : (NADA);
					      
		  const unsigned int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + dimension_outSDn*outSDp_TRS_index) : (NADA);
      
		  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
		    {
		      const unsigned int prot_dimension_SD_HO_Berggren_overlaps = prot_dimensions_SD_HO_Berggren_overlaps_table(BPp , n_scat_p_out , iCp_out , iMp , outSDp_index);
		      const unsigned int neut_dimension_SD_HO_Berggren_overlaps = prot_dimensions_SD_HO_Berggren_overlaps_table(BPn , n_scat_n_out , iCn_out , iMn , outSDn_index);

		      const unsigned int prot_SD_HO_Berggren_overlaps_debut_index = prot_SD_HO_Berggren_overlaps_table.index_determine (BPp , n_scat_p_out , iCp_out , iMp , outSDp_index , 0);
		      const unsigned int neut_SD_HO_Berggren_overlaps_debut_index = neut_SD_HO_Berggren_overlaps_table.index_determine (BPn , n_scat_n_out , iCn_out , iMn , outSDn_index , 0);
						  
		      class array<unsigned int> &non_zero_overlaps_PSI_HO_in_indices = non_zero_overlaps_PSI_HO_in_indices_tab(total_PSI_out_index);
		      class array<TYPE> &non_zero_overlaps = non_zero_overlaps_tab(total_PSI_out_index);
  
		      unsigned int &non_zero_overlaps_index = non_zero_overlaps_numbers(total_PSI_out_index);

		      for (unsigned int ip = 0 ; ip < prot_dimension_SD_HO_Berggren_overlaps ; ip++)
			{
			  const unsigned int prot_SD_HO_Berggren_overlaps_data_index = prot_SD_HO_Berggren_overlaps_debut_index + ip;

			  const class SD_HO_Berggren_overlaps_data_str &prot_SD_HO_Berggren_overlaps_data = prot_SD_HO_Berggren_overlaps_table[prot_SD_HO_Berggren_overlaps_data_index];

			  const int n_scat_p_HO_in = prot_SD_HO_Berggren_overlaps_data.get_n_scat_HO_in ();

			  const unsigned int iCp_HO_in = prot_SD_HO_Berggren_overlaps_data.get_iC_HO_in ();

			  const int Ep_hw_HO_in = Ep_hw_table_HO(BPp , n_scat_p_HO_in , iCp_HO_in);

			  const int n_holes_p_HO_in = n_holes_table_HO_p(BPp , n_scat_p_HO_in , iCp_HO_in);
			  
			  const unsigned int inSDp_HO_index = prot_SD_HO_Berggren_overlaps_data.get_inSD_HO_index ();

			  const TYPE prot_SD_HO_Berggren_overlap = prot_SD_HO_Berggren_overlaps_data.get_SD_HO_Berggren_overlap ();

			  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_HO_in , n_scat_p_HO_in , Ep_hw_HO_in , n_holes_max_p_HO , n_scat_max_p_HO , Ep_max_hw_HO)) continue;
			  
			  for (unsigned int in = 0 ; in < neut_dimension_SD_HO_Berggren_overlaps ; in++)
			    {
			      const unsigned int neut_SD_HO_Berggren_overlaps_data_index = neut_SD_HO_Berggren_overlaps_debut_index + in;

			      const class SD_HO_Berggren_overlaps_data_str &neut_SD_HO_Berggren_overlaps_data = neut_SD_HO_Berggren_overlaps_table[neut_SD_HO_Berggren_overlaps_data_index];

			      const int n_scat_n_HO_in = neut_SD_HO_Berggren_overlaps_data.get_n_scat_HO_in ();

			      const unsigned int iCn_HO_in = neut_SD_HO_Berggren_overlaps_data.get_iC_HO_in ();
																
			      const int En_hw_HO_in = En_hw_table_HO(BPn , n_scat_n_HO_in , iCn_HO_in);

			      const int n_holes_n_HO_in = n_holes_table_HO_n(BPn , n_scat_n_HO_in , iCn_HO_in);
			      
			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_HO_in , n_scat_n_HO_in , En_hw_HO_in , n_holes_max_n_HO , n_scat_max_n_HO , En_max_hw_HO)) continue;
			  
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_HO_in , n_scat_p_HO_in , Ep_hw_HO_in , n_holes_n_HO_in , n_scat_n_HO_in , En_hw_HO_in , n_holes_max_HO , n_scat_max_HO  , E_max_hw_HO)) continue;
			      
			      const unsigned int inSDn_HO_index = neut_SD_HO_Berggren_overlaps_data.get_inSD_HO_index ();
																	
			      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_HO_in = sum_dimensions_GSM_vector_HO_in(BPp , n_scat_p_HO_in , n_scat_n_HO_in ,
																  iCp_HO_in , iCn_HO_in , iMp);

			      const unsigned int dimension_inSDn_HO = dimensions_SDn_set_HO(BPn , n_scat_n_HO_in , iCn_HO_in , iMn);
								    
			      const unsigned int total_PSI_HO_in_index = sum_dimensions_configuration_Mp_Mn_fixed_HO_in + dimension_inSDn_HO*inSDp_HO_index + inSDn_HO_index;

			      const TYPE neut_SD_HO_Berggren_overlap = neut_SD_HO_Berggren_overlaps_data.get_SD_HO_Berggren_overlap ();

			      non_zero_overlaps_PSI_HO_in_indices(non_zero_overlaps_index) = total_PSI_HO_in_index;

			      non_zero_overlaps(non_zero_overlaps_index) = prot_SD_HO_Berggren_overlap*neut_SD_HO_Berggren_overlap;

			      non_zero_overlaps_index++;
			    }}}}}}}
}	













void cluster_HO_to_Berggren_class::non_zero_overlaps_pn_Z_valence_larger_calc_store ()
{
  const class GSM_vector_helper_class &GSM_vector_helper_HO_in = get_GSM_vector_helper_HO_in ();

  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
    
  const class cluster_data &cluster_data = get_cluster_data ();
  
  const class nucleons_data &cluster_prot_data = cluster_data.get_cluster_prot_data (); 
  const class nucleons_data &cluster_neut_data = cluster_data.get_cluster_neut_data ();
  
  const class nucleons_data &cluster_prot_data_HO = cluster_data.get_cluster_prot_data_HO (); 
  const class nucleons_data &cluster_neut_data_HO = cluster_data.get_cluster_neut_data_HO ();
  
  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();
 
  const int n_holes_max_p = GSM_vector_helper_out.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_out.get_n_holes_max_n ();
  
  const int n_holes_max_HO = GSM_vector_helper_HO_in.get_n_holes_max ();
  
  const int n_holes_max_p_HO = GSM_vector_helper_HO_in.get_n_holes_max_p ();
  const int n_holes_max_n_HO = GSM_vector_helper_HO_in.get_n_holes_max_n ();

  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max ();

  const int n_scat_max_p = GSM_vector_helper_out.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_out.get_n_scat_max_n ();
  
  const int n_scat_max_p_HO = GSM_vector_helper_HO_in.get_n_scat_max_p ();
  const int n_scat_max_n_HO = GSM_vector_helper_HO_in.get_n_scat_max_n ();
  
  const int n_scat_max_HO = GSM_vector_helper_HO_in.get_n_scat_max ();
    
  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper_out.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_out.get_En_max_hw ();
  
  const int E_max_hw_HO = GSM_vector_helper_HO_in.get_E_max_hw ();
  
  const int Ep_max_hw_HO = GSM_vector_helper_HO_in.get_Ep_max_hw ();
  const int En_max_hw_HO = GSM_vector_helper_HO_in.get_En_max_hw ();

  const unsigned int BP = GSM_vector_helper_out.get_BP ();
  
  const int iM = GSM_vector_helper_out.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper_out.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper_out.get_iMp_max_M ();
  
  const int iMp_max = cluster_prot_data.get_iM_max ();
  
  const bool is_it_TRS_HO_in = GSM_vector_helper_HO_in.get_is_it_TRS ();

  const bool is_it_TRS_out = GSM_vector_helper_out.get_is_it_TRS ();

  const bool is_it_TRS = (is_it_TRS_HO_in && is_it_TRS_out);
  
  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = cluster_prot_data.get_SD_TRS_indices ();
  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = cluster_neut_data.get_SD_TRS_indices ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector_TRS ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_HO_in = GSM_vector_helper_HO_in.get_sum_dimensions_GSM_vector ();
    
  const class array_BP_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper_out.get_all_dimensions_SDn_zero_tab ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = cluster_prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = cluster_neut_data.get_dimensions_SD_set ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set_HO = cluster_neut_data_HO.get_dimensions_SD_set ();

  const class array_BP_Nscat_iC<int> &n_holes_p_table = cluster_prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = cluster_neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = cluster_prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = cluster_neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<int> &n_holes_table_HO_p = cluster_prot_data_HO.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_table_HO_n = cluster_neut_data_HO.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table_HO = cluster_prot_data_HO.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table_HO = cluster_neut_data_HO.get_E_hw_table ();  

  const class array_BP_Nscat_iC_iM_SD<unsigned int> &prot_dimensions_SD_HO_Berggren_overlaps_table = cluster_prot_data.get_dimensions_SD_HO_Berggren_overlaps_table ();

  const class array_of_SD_HO_Berggren_overlaps_data_str &prot_SD_HO_Berggren_overlaps_table = cluster_prot_data.get_SD_HO_Berggren_overlaps_table ();
  const class array_of_SD_HO_Berggren_overlaps_data_str &neut_SD_HO_Berggren_overlaps_table = cluster_neut_data.get_SD_HO_Berggren_overlaps_table ();

  const class array<unsigned int> &iCn_out_min_process_tab = GSM_vector_helper_out.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_out_max_process_tab = GSM_vector_helper_out.get_iCn_max_process_tab ();

  const class array<class SD_quantum_numbers> &SD_quantum_numbers_prot_tab = cluster_prot_data.get_SD_quantum_numbers_tab ();
  
  const unsigned int total_outSDp_index_min = GSM_vector_helper_out.get_total_SDp_index_min ();
  const unsigned int total_outSDp_index_max = GSM_vector_helper_out.get_total_SDp_index_max ();

  if (total_outSDp_index_min > total_outSDp_index_max) return;
      
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SD_quantum_numbers_prot_tab(total_outSDp_index);

      const int iMp = outSDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = outSDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , n_scat_p_out , iCp_out , iMp);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , n_scat_p_out , iCp_out , iMp);

      if (all_dimensions_SDn_zero) continue;

      const int iMn = iM - iMp;

      const int TRS_iMp = iMp_max - iMp;

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();
      
      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , n_scat_p_out , iCp_out , iMp , outSDp_index)) : (NADA);
            
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_process_tab(BPn , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_process_tab(BPn , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn , n_scat_n_out , iCn_out);
 
	      const int En_hw_out = En_hw_table(BPn , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;
	      
	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , n_scat_n_out , iCn_out , iMn);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector_out(BPp , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp);
	      
	      const unsigned int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;
	      
	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS_out(BPp , n_scat_p_out , n_scat_n_out ,
																     iCp_out , iCn_out , TRS_iMp)) : (NADA);
		  
	      const unsigned int total_outSDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , n_scat_n_out , iCn_out , iMn , 0)) : (NADA);
				      
	      const unsigned int TRS_total_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_outSDn*outSDp_TRS_index) : (NADA);
		  
	      for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		{
		  const unsigned int total_PSI_out_index = total_PSI_out_index_zero + outSDn_index;
					      
		  const unsigned int total_outSDn_TRS_indices_index = (is_it_TRS) ? (total_outSDn_TRS_indices_zero_index + outSDn_index) : (NADA);

		  const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_outSDn_TRS_indices_index]) : (NADA);
					      
		  const unsigned int TRS_total_PSI_out_index = (is_it_TRS) ? (TRS_total_PSI_out_index_zero + outSDn_TRS_index) : (NADA);
      
		  if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
		    {	
		      const unsigned int prot_dimension_SD_HO_Berggren_overlaps = prot_dimensions_SD_HO_Berggren_overlaps_table(BPp , n_scat_p_out , iCp_out , iMp , outSDp_index);
		      const unsigned int neut_dimension_SD_HO_Berggren_overlaps = prot_dimensions_SD_HO_Berggren_overlaps_table(BPn , n_scat_n_out , iCn_out , iMn , outSDn_index);

		      const unsigned int prot_SD_HO_Berggren_overlaps_debut_index = prot_SD_HO_Berggren_overlaps_table.index_determine (BPp , n_scat_p_out , iCp_out , iMp , outSDp_index , 0);
		      const unsigned int neut_SD_HO_Berggren_overlaps_debut_index = neut_SD_HO_Berggren_overlaps_table.index_determine (BPn , n_scat_n_out , iCn_out , iMn , outSDn_index , 0);

		      class array<unsigned int> &non_zero_overlaps_PSI_HO_in_indices = non_zero_overlaps_PSI_HO_in_indices_tab(total_PSI_out_index);

		      class array<TYPE> &non_zero_overlaps = non_zero_overlaps_tab(total_PSI_out_index);
  
		      unsigned int &non_zero_overlaps_index = non_zero_overlaps_numbers(total_PSI_out_index);
			      
		      for (unsigned int ip = 0 ; ip < prot_dimension_SD_HO_Berggren_overlaps ; ip++)
			{
			  const unsigned int prot_SD_HO_Berggren_overlaps_data_index = prot_SD_HO_Berggren_overlaps_debut_index + ip;

			  const class SD_HO_Berggren_overlaps_data_str &prot_SD_HO_Berggren_overlaps_data = prot_SD_HO_Berggren_overlaps_table[prot_SD_HO_Berggren_overlaps_data_index];

			  const int n_scat_p_HO_in = prot_SD_HO_Berggren_overlaps_data.get_n_scat_HO_in ();

			  const unsigned int iCp_HO_in = prot_SD_HO_Berggren_overlaps_data.get_iC_HO_in ();

			  const int Ep_hw_HO_in = Ep_hw_table_HO(BPp , n_scat_p_HO_in , iCp_HO_in);

			  const int n_holes_p_HO_in = n_holes_table_HO_p(BPp , n_scat_p_HO_in , iCp_HO_in);
			  
			  const unsigned int inSDp_HO_index = prot_SD_HO_Berggren_overlaps_data.get_inSD_HO_index ();

			  const TYPE prot_SD_HO_Berggren_overlap = prot_SD_HO_Berggren_overlaps_data.get_SD_HO_Berggren_overlap ();

			  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_HO_in , n_scat_p_HO_in , Ep_hw_HO_in , n_holes_max_p_HO , n_scat_max_p_HO , Ep_max_hw_HO)) continue;
			  
			  for (unsigned int in = 0 ; in < neut_dimension_SD_HO_Berggren_overlaps ; in++)
			    {
			      const unsigned int neut_SD_HO_Berggren_overlaps_data_index = neut_SD_HO_Berggren_overlaps_debut_index + in;

			      const class SD_HO_Berggren_overlaps_data_str &neut_SD_HO_Berggren_overlaps_data = neut_SD_HO_Berggren_overlaps_table[neut_SD_HO_Berggren_overlaps_data_index];

			      const int n_scat_n_HO_in = neut_SD_HO_Berggren_overlaps_data.get_n_scat_HO_in ();

			      const unsigned int iCn_HO_in = neut_SD_HO_Berggren_overlaps_data.get_iC_HO_in ();
																
			      const int En_hw_HO_in = En_hw_table_HO(BPn , n_scat_n_HO_in , iCn_HO_in);

			      const int n_holes_n_HO_in = n_holes_table_HO_n(BPn , n_scat_n_HO_in , iCn_HO_in);
			      
			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_HO_in , n_scat_n_HO_in , En_hw_HO_in , n_holes_max_n_HO , n_scat_max_n_HO , En_max_hw_HO)) continue;

			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_HO_in , n_scat_p_HO_in , Ep_hw_HO_in , n_holes_n_HO_in , n_scat_n_HO_in , En_hw_HO_in , n_holes_max_HO , n_scat_max_HO  , E_max_hw_HO)) continue;
			      
			      const unsigned int inSDn_HO_index = neut_SD_HO_Berggren_overlaps_data.get_inSD_HO_index ();
																	
			      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_HO_in = sum_dimensions_GSM_vector_HO_in(BPp , n_scat_p_HO_in , n_scat_n_HO_in ,
																  iCp_HO_in , iCn_HO_in , iMp);

			      const unsigned int dimension_inSDn_HO = dimensions_SDn_set_HO(BPn , n_scat_n_HO_in , iCn_HO_in , iMn);
								    
			      const unsigned int total_PSI_HO_in_index = sum_dimensions_configuration_Mp_Mn_fixed_HO_in + dimension_inSDn_HO*inSDp_HO_index + inSDn_HO_index;

			      const TYPE neut_SD_HO_Berggren_overlap = neut_SD_HO_Berggren_overlaps_data.get_SD_HO_Berggren_overlap ();

			      non_zero_overlaps_PSI_HO_in_indices(non_zero_overlaps_index) = total_PSI_HO_in_index;

			      non_zero_overlaps(non_zero_overlaps_index) = prot_SD_HO_Berggren_overlap*neut_SD_HO_Berggren_overlap;

			      non_zero_overlaps_index++;
			    }}}}}}}
}					















void cluster_HO_to_Berggren_class::non_zero_overlaps_pp_nn_calc_store ()
{
  const class GSM_vector_helper_class &GSM_vector_helper_HO_in = get_GSM_vector_helper_HO_in ();
  
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();

  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw ();
  
  const int n_holes_max_HO = GSM_vector_helper_HO_in.get_n_holes_max ();
  
  const int n_scat_max_HO = GSM_vector_helper_HO_in.get_n_scat_max ();

  const int E_max_hw_HO = GSM_vector_helper_HO_in.get_E_max_hw ();
  
  const enum space_type space = GSM_vector_helper_out.get_space ();
      
  const unsigned int BP = GSM_vector_helper_out.get_BP (); 

  const int iM = GSM_vector_helper_out.get_iM ();
  
  const bool is_it_TRS_HO_in = GSM_vector_helper_HO_in.get_is_it_TRS ();

  const bool is_it_TRS_out = GSM_vector_helper_out.get_is_it_TRS ();

  const bool is_it_TRS = (is_it_TRS_HO_in && is_it_TRS_out);
  
  const class cluster_data &cluster_data = get_cluster_data ();
  
  const class nucleons_data &cluster_prot_data = cluster_data.get_cluster_prot_data (); 
  const class nucleons_data &cluster_neut_data = cluster_data.get_cluster_neut_data ();
  
  const class nucleons_data &cluster_prot_data_HO = cluster_data.get_cluster_prot_data_HO (); 
  const class nucleons_data &cluster_neut_data_HO = cluster_data.get_cluster_neut_data_HO ();
  
  const class nucleons_data &cluster_particles_data = (space == PROTONS_ONLY) ? (cluster_prot_data) : (cluster_neut_data);
  
  const class nucleons_data &cluster_particles_data_HO = (space == PROTONS_ONLY) ? (cluster_prot_data_HO) : (cluster_neut_data_HO);
  
  const class array_BP_Nscat_iC<int> &n_holes_table_HO = cluster_particles_data_HO.get_n_holes_table ();

  const class array_BP_Nscat_iC<int> &E_hw_table_HO = cluster_particles_data_HO.get_E_hw_table ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector (); 

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector_TRS ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_HO_in = GSM_vector_helper_HO_in.get_sum_dimensions_GSM_vector ();
   
  const class array_BP_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = cluster_particles_data.get_SD_TRS_indices ();
  
  const class array_BP_Nscat_iC<int> &n_holes_table = cluster_particles_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &E_hw_table = cluster_particles_data.get_E_hw_table ();

  const class array_BP_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_HO_Berggren_overlaps_table = cluster_particles_data.get_dimensions_SD_HO_Berggren_overlaps_table ();
  
  const class array_of_SD_HO_Berggren_overlaps_data_str &SD_HO_Berggren_overlaps_table = cluster_particles_data.get_SD_HO_Berggren_overlaps_table ();
  
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = cluster_particles_data.get_SD_quantum_numbers_tab ();

  const unsigned int total_outSD_index_min = GSM_vector_helper_out.get_total_SD_index_min ();
  const unsigned int total_outSD_index_max = GSM_vector_helper_out.get_total_SD_index_max ();

  if (total_outSD_index_min > total_outSD_index_max) return;
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int total_outSD_index = total_outSD_index_min ; total_outSD_index <= total_outSD_index_max ; total_outSD_index++)
    {
      const class SD_quantum_numbers &outSD_qn = SD_quantum_numbers_tab(total_outSD_index);
 
      const int iM_out = outSD_qn.get_iM ();

      if (iM_out != iM) continue;

      const unsigned int BP_out = outSD_qn.get_BP ();

      if (BP_out != BP) continue;
      
      const unsigned int n_scat_out = outSD_qn.get_n_scat ();

      const unsigned int iC_out = outSD_qn.get_iC ();

      const int n_holes_out = n_holes_table(BP_out , n_scat_out , iC_out);
      
      const int E_out_hw = E_hw_table(BP_out , n_scat_out , iC_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
      
      const unsigned int outSD_index = outSD_qn.get_SD_index ();

      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_GSM_vector_out(n_scat_out , iC_out);

      const unsigned int total_PSI_out_index = sum_dimensions_configuration_fixed_out + outSD_index;
      
      const unsigned int outSD_TRS_index = (is_it_TRS) ? (SD_TRS_indices(BP , n_scat_out , iC_out , iM , outSD_index)) : (NADA);

      const unsigned int sum_dimensions_configuration_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS_out(n_scat_out , iC_out)) : (NADA);

      const unsigned int TRS_total_PSI_out_index = (is_it_TRS) ? (sum_dimensions_configuration_fixed_TRS_out + outSD_TRS_index) : (NADA);

      if (!is_it_TRS || (TRS_total_PSI_out_index >= total_PSI_out_index))
	{
	  const unsigned int dimension_SD_HO_Berggren_overlaps = dimensions_SD_HO_Berggren_overlaps_table(BP , n_scat_out , iC_out , iM , outSD_index);

	  class array<unsigned int> &non_zero_overlaps_PSI_HO_in_indices = non_zero_overlaps_PSI_HO_in_indices_tab(total_PSI_out_index);

	  class array<TYPE> &non_zero_overlaps = non_zero_overlaps_tab(total_PSI_out_index);
  		
	  unsigned int &non_zero_overlaps_index = non_zero_overlaps_numbers(total_PSI_out_index);
			   
	  const unsigned int SD_HO_Berggren_overlaps_debut_index = SD_HO_Berggren_overlaps_table.index_determine (BP , n_scat_out , iC_out , iM , outSD_index , 0);

	  for (unsigned int i = 0 ; i < dimension_SD_HO_Berggren_overlaps ; i++)
	    {
	      const unsigned int SD_HO_Berggren_overlaps_data_index = SD_HO_Berggren_overlaps_debut_index + i;

	      const class SD_HO_Berggren_overlaps_data_str &SD_HO_Berggren_overlaps_data = SD_HO_Berggren_overlaps_table[SD_HO_Berggren_overlaps_data_index];

	      const int n_scat_HO_in = SD_HO_Berggren_overlaps_data.get_n_scat_HO_in ();
				  
	      const unsigned int iC_HO_in = SD_HO_Berggren_overlaps_data.get_iC_HO_in ();

	      const int n_holes_HO_in = n_holes_table_HO(BP , n_scat_HO_in , iC_HO_in);
				      
	      const int E_HO_in_hw = E_hw_table_HO(BP , n_scat_HO_in , iC_HO_in);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_HO_in , n_scat_HO_in , E_HO_in_hw , n_holes_max_HO , n_scat_max_HO , E_max_hw_HO)) continue;

	      const unsigned int inSD_HO_index = SD_HO_Berggren_overlaps_data.get_inSD_HO_index ();
																	
	      const unsigned int sum_dimensions_configuration_fixed_HO_in = sum_dimensions_GSM_vector_HO_in(n_scat_HO_in , iC_HO_in);

	      const unsigned int total_PSI_HO_in_index = sum_dimensions_configuration_fixed_HO_in + inSD_HO_index;
			      
	      const TYPE SD_HO_Berggren_overlap = SD_HO_Berggren_overlaps_data.get_SD_HO_Berggren_overlap ();

	      non_zero_overlaps_PSI_HO_in_indices(non_zero_overlaps_index) = total_PSI_HO_in_index;

	      non_zero_overlaps(non_zero_overlaps_index) = SD_HO_Berggren_overlap;

	      non_zero_overlaps_index++;
	    }
	}
    }
}





















void cluster_HO_to_Berggren_class::matrix_store ()
{  
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
    
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_out.get_is_it_MPI_parallelized_local ();
  
  const unsigned int N = (is_it_MPI_parallelized_local) ? (NUMBER_OF_PROCESSES) : (1);
  
  const enum space_type space = GSM_vector_helper_out.get_space ();

  const unsigned int total_space_dimension_out = GSM_vector_helper_out.get_total_space_dimension ();

  non_zero_overlaps_numbers = 0;
  
  // Arrays are put to zero inside the loop, as one cannot write non_zero_overlaps_tab = 0.0 for example, as it is an array of array of numbers.
  
  for (unsigned int total_PSI_out_index = 0 ; total_PSI_out_index < total_space_dimension_out ; total_PSI_out_index++) 
    {
      non_zero_overlaps_PSI_HO_in_indices_tab(total_PSI_out_index) = total_space_dimension_out;

      non_zero_overlaps_tab(total_PSI_out_index) = 0.0;
    }
  
  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
    {
      if (space == PROTONS_NEUTRONS)
	{
	  const class nucleons_data &prot_data = GSM_vector_helper_out.get_prot_data ();
	  const class nucleons_data &neut_data = GSM_vector_helper_out.get_neut_data ();
  
	  const int Zval = prot_data.get_N_valence_nucleons ();
	  const int Nval = neut_data.get_N_valence_nucleons ();

	  if (Nval >= Zval)
	    non_zero_overlaps_pn_N_valence_larger_calc_store ();
	  else
	    non_zero_overlaps_pn_Z_valence_larger_calc_store ();
	}
      else
	non_zero_overlaps_pp_nn_calc_store ();
    }
}











void cluster_HO_to_Berggren_class::apply_add_full_storage (
							   const class GSM_vector &PSI_HO_in ,
							   class GSM_vector &PSI_out) const
{
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned int PSI_out_index_non_zeros = 0 ; PSI_out_index_non_zeros < total_space_dimension_non_zeros ; PSI_out_index_non_zeros++)
    {
      const unsigned int total_PSI_out_index = total_PSI_out_indices_non_zeros(PSI_out_index_non_zeros);

      const unsigned int non_zero_overlaps_number = non_zero_overlaps_numbers(total_PSI_out_index);

      const class array<unsigned int> &non_zero_overlaps_PSI_HO_in_indices = non_zero_overlaps_PSI_HO_in_indices_tab(total_PSI_out_index);
	
      const class array<TYPE> &non_zero_overlaps = non_zero_overlaps_tab(total_PSI_out_index);

      TYPE component_part = 0.0;
      
      for (unsigned int i = 0 ; i < non_zero_overlaps_number ; i++) 
	{
	  const unsigned int PSI_HO_in_index = non_zero_overlaps_PSI_HO_in_indices(i);
	  
	  const TYPE &NBME = non_zero_overlaps(i);
	  
	  const TYPE &PSI_HO_in_component = PSI_HO_in[PSI_HO_in_index];

	  component_part += NBME*PSI_HO_in_component;
	}

      PSI_out[total_PSI_out_index] += component_part;
    }
}








