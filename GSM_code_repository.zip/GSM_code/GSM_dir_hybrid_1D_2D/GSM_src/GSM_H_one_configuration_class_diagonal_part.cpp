#include "../GSM_include/GSM_include_def.h"

using namespace GSM_vector_NBMEs_handling;

// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons
// ------------------------------------------------------------------------------------------------------------------------------------------------------





// Calculation and storage of the diagonal matrix elements of H
// ------------------------------------------------------------
// One calculates here the diagonal matrix elements of H, of the form <SD | H | SD>. 
// <SD | H | SD> = \sum_i <i | h |i> + \sum_(i<j) <ij | V |ij>, with h and V the one-body and two-body parts of H.
// One separates the pp, nn and pn parts of <SD | H | SD> in the proton-neutron case.
//
// One loops over proton and neutron Slater determinants, the first loop being proton or neutron according to the case.
// As the same proton  NBME occurs for fixed SDp and varying SDn, it is calculated only once and reused for all such cases.
// As the same neutron NBME occurs for fixed SDn and varying SDp, it is calculated only once and reused for all such cases.
// For the pn part of H, one routine is used if NYval >= ZYval, and another if not, as SD indices are calculated differently in each case to optimize their use (see GSM_vector_dimensions.cpp).
//
// A direct calculation of uncoupled TBMEs from coupled TBMEs is always done as full storage is always used, so that it is done only at H construction level.
//
// TRS is time-reversal symmetry. It allows to to calculate about one half of |Psi[out]>, while the rest is given from the first half up to a phase if M=0 in |Psi[in]> and |Psi[out]>.
// Indeed, the components of |SD> and TRS|SD> differ only by a +/-1 phase, which is straightforward to calculate. Hence, only about half of diagonal NBMEs are stored here in this case.

void H_one_configuration_class::diagonal_part_pn_p_part_calc ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const enum interaction_type inter = GSM_vector_helper.get_inter ();

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const unsigned int BPp = prot_Y_data.get_BP_one_configuration ();
  const unsigned int BPn = neut_Y_data.get_BP_one_configuration ();
  
  const unsigned int iCp = prot_Y_data.get_iC_one_configuration (); 
  const unsigned int iCn = neut_Y_data.get_iC_one_configuration ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS (); 

  const class array<unsigned int> &TRS_PSI_indices = GSM_vector_helper.get_TRS_PSI_indices (); 

  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
  
  const class TBMEs_class &TBMEs_pp = prot_Y_data.get_TBMEs ();

  class Slater_determinant SDp(ZYval);
  
  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
    {
      const int iMn = iM - iMp;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , 0 , 0 , 0 , iCp , iMp);
      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , 0 , 0 , 0 , iCn , iMn);
      
      if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

      const unsigned long int index_zero_SDp = SDp_set.index_determine (BPp , 0 , 0 , 0 , iCp , iMp , 0);

      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
	{
	  const unsigned long int index_SDp = index_zero_SDp + SDp_index;

	  SDp = SDp_set[index_SDp];

	  const TYPE NBME = H_NBMEs::diagonal_pp_nn_calc (true , true , OBMEs_p_inter_set , inter , TBMEs_pp , SDp);

	  const unsigned int sum_dimensions_Mp_Mn_fixed = sum_dimensions(iMp);

	  const unsigned int PSI_out_index_zero = sum_dimensions_Mp_Mn_fixed + dimension_SDn*SDp_index;
	      
	  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
	    {
	      const unsigned int PSI_out_index = PSI_out_index_zero + SDn_index;

	      if (!is_it_TRS || (TRS_PSI_indices(PSI_out_index) >= PSI_out_index)) H_diagonal_tab(PSI_out_index) += NBME;
	    }
	}
    }
}



void H_one_configuration_class::diagonal_part_pn_n_part_calc ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const enum interaction_type inter  = GSM_vector_helper.get_inter ();

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M ();
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();
  
  const unsigned int BPp = prot_Y_data.get_BP_one_configuration (); 
  const unsigned int BPn = neut_Y_data.get_BP_one_configuration ();
  
  const unsigned int iCp = prot_Y_data.get_iC_one_configuration (); 
  const unsigned int iCn = neut_Y_data.get_iC_one_configuration ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array<unsigned int> &TRS_PSI_indices = GSM_vector_helper.get_TRS_PSI_indices (); 
  
  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  const class OBMEs_inter_set_str &OBMEs_n_inter_set = neut_Y_data.get_OBMEs_inter_set ();
  
  const class TBMEs_class &TBMEs_nn = neut_Y_data.get_TBMEs ();

  class Slater_determinant SDn(NYval);
  
  for (int iMn = iMn_min_M ; iMn <= iMn_max_M ; iMn++)
    {
      const int iMp = iM - iMn;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , 0 , 0 , 0 , iCp , iMp);
      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , 0 , 0 , 0 , iCn , iMn);
      
      if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

      const unsigned long int index_zero_SDn = SDn_set.index_determine (BPn , 0 , 0 , 0 , iCn , iMn , 0);

      for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
	{
	  const unsigned long int index_SDn = index_zero_SDn + SDn_index;

	  SDn = SDn_set[index_SDn];

	  const TYPE NBME = H_NBMEs::diagonal_pp_nn_calc (true , true , OBMEs_n_inter_set , inter , TBMEs_nn , SDn);

	  const unsigned int sum_dimensions_Mp_Mn_fixed = sum_dimensions(iMp);

	  const unsigned int PSI_out_index_zero = sum_dimensions_Mp_Mn_fixed + SDn_index;
	      
	  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
	    {
	      const unsigned int PSI_out_index = PSI_out_index_zero + SDp_index*dimension_SDn;

	      if (!is_it_TRS || (TRS_PSI_indices(PSI_out_index) >= PSI_out_index)) H_diagonal_tab(PSI_out_index) += NBME;
	    }
	}
    }
}



void H_one_configuration_class::diagonal_part_pn_pn_part_calc ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn (); 

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 

  const int iM = GSM_vector_helper.get_iM ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array<unsigned int> &TRS_PSI_indices = GSM_vector_helper.get_TRS_PSI_indices (); 
  
  const unsigned int BPp = prot_Y_data.get_BP_one_configuration (); 
  const unsigned int BPn = neut_Y_data.get_BP_one_configuration ();
  
  const unsigned int iCp = prot_Y_data.get_iC_one_configuration (); 
  const unsigned int iCn = neut_Y_data.get_iC_one_configuration ();

  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
    
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set (); 

  class Slater_determinant SDp(ZYval);
  class Slater_determinant SDn(NYval);
  
  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
    {
      const int iMn = iM - iMp;
      
      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , 0 , 0 , 0 , iCp , iMp);
      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , 0 , 0 , 0 , iCn , iMn);
      
      if ((dimension_SDn == 0) || (dimension_SDp == 0)) continue;

      const unsigned int sum_dimensions_Mp_Mn_fixed = sum_dimensions(iMp);

      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
	{
	  const unsigned int PSI_out_index_zero = sum_dimensions_Mp_Mn_fixed + dimension_SDn*SDp_index;

	  SDp = SDp_set(BPp , 0 , 0 , 0 , iCp , iMp , SDp_index);
		  
	  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
	    {
	      const unsigned int PSI_out_index = PSI_out_index_zero + SDn_index;

	      if (!is_it_TRS || (TRS_PSI_indices(PSI_out_index) >= PSI_out_index))
		{
		  SDn = SDn_set(BPn , 0 , 0 , 0 , iCn , iMn , SDn_index);

		  const TYPE NBME = H_NBMEs::diagonal_pn_calc (TBMEs_pn , SDp , SDn);

		  H_diagonal_tab(PSI_out_index) += NBME;
		}
	    }
	}
    }
}





void H_one_configuration_class::diagonal_part_pp_nn_calc ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum interaction_type inter  = GSM_vector_helper.get_inter ();

  const enum space_type space = GSM_vector_helper.get_space ();

  const int iM = GSM_vector_helper.get_iM ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS (); 

  const class array<unsigned int> &TRS_PSI_indices = GSM_vector_helper.get_TRS_PSI_indices (); 
   
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);
  
  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  const unsigned int BP = data.get_BP_one_configuration ();
  const unsigned int iC = data.get_iC_one_configuration ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class OBMEs_inter_set_str &OBMEs_inter_set = data.get_OBMEs_inter_set ();

  const class TBMEs_class &TBMEs = data.get_TBMEs ();

  const unsigned int dimension_SD_set = dimensions_SD_set(BP , 0 , 0 , 0 , iC , iM);

  const unsigned long int total_SD_index_zero = SD_set.index_determine (BP , 0 , 0 , 0 , iC , iM , 0);

  class Slater_determinant SD(N_valence_baryons);
  
  for (unsigned int SD_index = 0 ; SD_index < dimension_SD_set ; SD_index++)
    { 
      if (!is_it_TRS || (TRS_PSI_indices(SD_index) >= SD_index))
	{
	  const unsigned long int total_SD_index = total_SD_index_zero + SD_index;
	  
	  SD = SD_set[total_SD_index];

	  const TYPE NBME = H_NBMEs::diagonal_pp_nn_calc (true , true , OBMEs_inter_set , inter , TBMEs , SD);

	  H_diagonal_tab(SD_index) = NBME;
	}
    }
}
