#include "../GSM_include/GSM_include_def.h"

using namespace string_routines;
using namespace Wigner_signs;
using namespace correlated_state_routines;
using namespace beta_transitions_common;
using namespace beta_transitions_strength_OBMEs;
using namespace beta_transitions_NBMEs;
using namespace inputs_misc;



// TYPE is double or complex
// -------------------------





// Calculation of the radial array of the beta transition strength matrix elements <Psi[out] | Op | Psi[in]> for a given suboperator
// ---------------------------------------------------------------------------------------------------------------------------------
// Beta transitions strengths (i.e. a as function of r, not integrated) are functions of several operators.
// One consider a single operator here, such as Fermi or Gamow-Teller for allowed beta decay,
// or x, w, u, z, xi, xi'y and xi'v, with or without Coulomb correction for first-forbidden beta decay.
// Reduced beta transition matrix elements are calculated first, and dereduced afterwards.

void beta_transitions_strength::beta_suboperator_NBMEs_calc (
							     const enum beta_pm_type beta_pm , 
							     const enum radial_operator_type radial_operator , 
							     const enum beta_suboperator_type beta_suboperator , 
							     const bool is_it_Gauss_Legendre ,
							     const bool full_common_vectors_used_in_file ,  
							     const class correlated_state_str &PSI_IN_qn , 
							     const class correlated_state_str &PSI_OUT_qn , 
							     const class GSM_vector &PSI_OUT , 
							     class array<TYPE> &beta_suboperator_NBMEs)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data_in  = data_in_determine  (beta_pm , prot_data , neut_data);
  const class nucleons_data &data_out = data_out_determine (beta_pm , prot_data , neut_data);

  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();

  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;

  const unsigned int N_nlj_in  = data_in.get_N_nlj ();
  const unsigned int N_nlj_out = data_out.get_N_nlj ();

  const unsigned int N_nljm_in  = data_in.get_N_nljm ();
  const unsigned int N_nljm_out = data_out.get_N_nljm ();

  const unsigned int N_bef_R_GL = data_in.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = data_in.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const int rank_Op = rank_beta_suboperator_determine (beta_suboperator);
  
  const int rank_Op_projection = make_int (M_OUT - M_IN);

  const unsigned int beta_suboperator_index = beta_suboperator_type_index_determine (beta_suboperator);

  class array<TYPE> OBMEs_reduced(N_nlj_in , N_nlj_out , Nr);

  class array<TYPE> OBMEs(N_nljm_in , N_nljm_out , Nr);

  class array<TYPE> OBMEs_part(N_nljm_in , N_nljm_out);

  beta_suboperator_OBMEs_reduced_calc (radial_operator , beta_suboperator , is_it_Gauss_Legendre , data_in , data_out , OBMEs_reduced);

  OBMEs_dereduced_strength_calc<TYPE> (rank_Op , rank_Op_projection , data_in , data_out , OBMEs_reduced , OBMEs);

  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      for (unsigned int s_in = 0 ; s_in < N_nljm_in ; s_in++)
	for (unsigned int s_out = 0 ; s_out < N_nljm_out ; s_out++)
	  OBMEs_part(s_in , s_out) = OBMEs(s_in , s_out , i);

      beta_suboperator_NBMEs(beta_suboperator_index , i) = beta_transitions_NBMEs::calc (beta_pm ,  beta_suboperator , full_common_vectors_used_in_file , OBMEs_part , PSI_IN_qn , PSI_OUT_qn , PSI_OUT);
    }
}

void beta_transitions_strength::beta_suboperators_NBMEs_calc (
							      const enum beta_type beta , 
							      const enum beta_pm_type beta_pm , 
							      const bool is_it_Gauss_Legendre ,
							      const bool full_common_vectors_used_in_file ,  
							      const class correlated_state_str &PSI_IN_qn ,  
							      const class correlated_state_str &PSI_OUT_qn ,  
							      const class GSM_vector &PSI_OUT , 
							      class array<TYPE> &beta_suboperator_NBMEs)

{
  const unsigned int BP_IN  = PSI_IN_qn.get_BP ();
  const unsigned int BP_OUT = PSI_OUT_qn.get_BP ();

  const unsigned int vector_index_IN  = PSI_IN_qn.get_vector_index ();
  const unsigned int vector_index_OUT = PSI_OUT_qn.get_vector_index ();

  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();

  if (THIS_PROCESS == MASTER_PROCESS)
    cout << J_Pi_vector_index_string (BP_IN , J_IN , vector_index_IN) << " --> " << J_Pi_vector_index_string (BP_OUT , J_OUT , vector_index_OUT) << " : ";

  switch (beta)
    {
    case ALLOWED:
      {
	beta_suboperator_NBMEs_calc (beta_pm , OVERLAP , FERMI_ALLOWED        , is_it_Gauss_Legendre , full_common_vectors_used_in_file , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperator_NBMEs);
	beta_suboperator_NBMEs_calc (beta_pm , OVERLAP , GAMOW_TELLER_ALLOWED , is_it_Gauss_Legendre , full_common_vectors_used_in_file , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperator_NBMEs);
      } break;

    case FIRST_FORBIDDEN:
      {
	beta_suboperator_NBMEs_calc (beta_pm , FFBD , W_FFBD , is_it_Gauss_Legendre , full_common_vectors_used_in_file , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperator_NBMEs);
	beta_suboperator_NBMEs_calc (beta_pm , FFBD , U_FFBD , is_it_Gauss_Legendre , full_common_vectors_used_in_file , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperator_NBMEs);
	beta_suboperator_NBMEs_calc (beta_pm , FFBD , Z_FFBD , is_it_Gauss_Legendre , full_common_vectors_used_in_file , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperator_NBMEs);
	beta_suboperator_NBMEs_calc (beta_pm , FFBD , X_FFBD , is_it_Gauss_Legendre , full_common_vectors_used_in_file , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperator_NBMEs);

	beta_suboperator_NBMEs_calc (beta_pm , FFBD_COULOMB , W_FFBD_COULOMB , is_it_Gauss_Legendre , full_common_vectors_used_in_file , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperator_NBMEs);
	beta_suboperator_NBMEs_calc (beta_pm , FFBD_COULOMB , U_FFBD_COULOMB , is_it_Gauss_Legendre , full_common_vectors_used_in_file , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperator_NBMEs);
	beta_suboperator_NBMEs_calc (beta_pm , FFBD_COULOMB , X_FFBD_COULOMB , is_it_Gauss_Legendre , full_common_vectors_used_in_file , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperator_NBMEs);

	beta_suboperator_NBMEs_calc (beta_pm , REDUCED_GRADIENT , XI_PRIME_V_FFBD , is_it_Gauss_Legendre , full_common_vectors_used_in_file , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperator_NBMEs);
	beta_suboperator_NBMEs_calc (beta_pm , REDUCED_GRADIENT , XI_PRIME_Y_FFBD , is_it_Gauss_Legendre , full_common_vectors_used_in_file , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperator_NBMEs);
      } break;

    default: error_message_print_abort ("No beta transition recognized in beta_transitions_strength::beta_suboperator_NBMEs_calc");
    }
}















// Calculation and print on disk of beta transition strength functions of many-body matrix elements <Psi[out] | Op | Psi[in]> for all operators
// --------------------------------------------------------------------------------------------------------------------------------------------
// Beta transitions strengths (i.e. a as function of r, not integrated) are calculated and stored on disk.
// First-forbidden or allowed beta decays are calculated by looping over the demanded values in the input file.
// All possible allowed or first-forbidden beta decay suboperators are calculated if one asks for allowed or first-forbidden beta decay operators (one or the other).
// A message is written on screen after the calculation.

void beta_transitions_strength::calc_store (
					    const input_data_str &input_data , 
					    const class array<class correlated_state_str> &PSI_qn_tab , 
					    class nucleons_data &prot_data , 
					    class nucleons_data &neut_data) 
{ 
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "beta transitions strengths" << endl;
      cout <<         "--------------------------" << endl << endl;
    }

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
  
  const int Z_OUT = prot_data.get_N_nucleons ();
  const int N_OUT = neut_data.get_N_nucleons ();
  
  const int n_holes_max_p = prot_data.get_n_holes_max ();
  const int n_holes_max_n = neut_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_data.get_n_scat_max ();
  const int n_scat_max_n = neut_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_data.get_E_max_hw ();
  const int En_max_hw = neut_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();

  const unsigned int beta_transitions_strength_number = input_data.get_beta_transitions_strength_number ();

  const class array<enum beta_type> &beta_strength_tab = input_data.get_beta_strength_tab ();

  const class array<enum beta_pm_type> &beta_strength_pm_tab = input_data.get_beta_strength_pm_tab ();
  
  const class array<bool> &beta_strength_is_it_Gauss_Legendre_tab = input_data.get_beta_strength_is_it_Gauss_Legendre_tab ();
  
  const class array<unsigned int> &beta_strength_BP_IN_tab  = input_data.get_beta_strength_BP_IN_tab ();
  const class array<unsigned int> &beta_strength_BP_OUT_tab = input_data.get_beta_strength_BP_OUT_tab ();
  
  const class array<double> &beta_strength_J_IN_tab  = input_data.get_beta_strength_J_IN_tab ();
  const class array<double> &beta_strength_J_OUT_tab = input_data.get_beta_strength_J_OUT_tab ();
  
  const class array<unsigned int> &beta_strength_vector_index_IN_tab  = input_data.get_beta_strength_vector_index_IN_tab ();
  const class array<unsigned int> &beta_strength_vector_index_OUT_tab = input_data.get_beta_strength_vector_index_OUT_tab (); 

  const unsigned int N_bef_R_GL = input_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = input_data.get_N_bef_R_uniform ();

  const double R = input_data.get_R ();

  const double step_bef_R_uniform = input_data.get_step_bef_R_uniform ();

  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);

  class array<double> r_bef_R_tab_uniform(N_bef_R_uniform);
  
  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;

  for (unsigned int beta_index = 0 ; beta_index < beta_transitions_strength_number ; beta_index++)
    {
      const enum beta_type beta = beta_strength_tab[beta_index];

      const enum beta_pm_type beta_pm = beta_strength_pm_tab[beta_index];

      const bool is_it_Gauss_Legendre = beta_strength_is_it_Gauss_Legendre_tab[beta_index];

      const unsigned int BP_IN  = beta_strength_BP_IN_tab[beta_index];
      const unsigned int BP_OUT = beta_strength_BP_OUT_tab[beta_index];
      
      const unsigned int vector_index_IN  = beta_strength_vector_index_IN_tab[beta_index];
      const unsigned int vector_index_OUT = beta_strength_vector_index_OUT_tab[beta_index];
      
      const double J_IN  = beta_strength_J_IN_tab[beta_index];
      const double J_OUT = beta_strength_J_OUT_tab[beta_index];

      const double M_OUT = J_OUT;
      
      const int Z_IN = Z_IN_beta_determine (beta_pm , Z_OUT);
      const int N_IN = N_IN_beta_determine (beta_pm , N_OUT);

      const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

      const class correlated_state_str PSI_IN_qn(Z_IN , N_IN , BP_IN , J_IN , vector_index_IN , NADA , NADA , NADA , NADA , false);

      const class correlated_state_str PSI_OUT_qn = PSI_quantum_numbers_find (Z_OUT , N_OUT , BP_OUT , J_OUT , vector_index_OUT , PSI_qn_tab);

      class GSM_vector_helper_class PSI_OUT_helper(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
						   n_holes_max   , n_scat_max   , E_max_hw  ,
						   n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						   n_holes_max_n , n_scat_max_n , En_max_hw , BP_OUT , M_OUT , false , prot_data , neut_data);

      class GSM_vector PSI_OUT(PSI_OUT_helper);
      
      PSI_OUT.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_OUT_qn);
      
      const unsigned int beta_suboperator_type_number = beta_suboperator_type_number_determine ();

      class array<TYPE> beta_suboperator_NBMEs(beta_suboperator_type_number , Nr);

      beta_suboperator_NBMEs = 0.0;

      beta_suboperators_NBMEs_calc (beta , beta_pm , is_it_Gauss_Legendre , full_common_vectors_used_in_file , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperator_NBMEs);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  const string PSI_IN_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_IN_qn);
	  const string PSI_OUT_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_OUT_qn);

	  const string beta_strength_string = "beta_strength_" + PSI_IN_qn_string + "_" + PSI_OUT_qn_string;

	  const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (r_bef_R_tab_GL) : (r_bef_R_tab_uniform);

	  strength::calc_store (beta , r_bef_R_tab , beta_strength_string , beta_suboperator_NBMEs);

	  cout << "beta transition strength " << beta << " " << beta_pm << " "
	       << J_Pi_vector_index_string (BP_IN  , J_IN  , vector_index_IN) << " --> "
	       << J_Pi_vector_index_string (BP_OUT , J_OUT , vector_index_OUT) << " calculated." << endl;
	}
    }
}


