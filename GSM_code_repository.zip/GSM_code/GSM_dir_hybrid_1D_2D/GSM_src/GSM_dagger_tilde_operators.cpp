#include "../GSM_include/GSM_include_def.h"

using namespace string_routines;
using namespace Wigner_signs;
using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;
using namespace correlated_state_routines;
using namespace GSM_vector_dimensions;
using namespace dagger_tilde_operators_common;




// TYPE is double or complex
// -------------------------




 




void dagger_tilde_operators::a_dagger_a_tilde_MK_table_pn_calc (
								const enum dagger_tilde_operator_type dagger_tilde_operator , 
								const class nlj_struct &shell_dagger_a_qn , 
								const class nlj_struct &shell_tilde_b_qn , 
								const class correlated_state_str &PSI_IN_qn , 
								const class correlated_state_str &PSI_OUT_qn , 
								const class GSM_vector &PSI_OUT_full ,
								const class array<unsigned int> &inSDp_tab ,
								const class array<unsigned int> &inSDn_tab ,
								const class array<TYPE> &PSI_IN_component_tab ,
								const class array<bool> &is_inSDp_in_new_space_tab ,
								const class array<bool> &is_inSDn_in_new_space_tab ,
								const class array<unsigned char> &reordering_bin_phases_p ,
								const class array<unsigned char> &reordering_bin_phases_n ,
								class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data_dagger_a = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
  const class nucleons_data &data_tilde_b  = data_find (dagger_tilde_operator , 1 , prot_data , neut_data);

  const enum particle_type particle_dagger_a = data_dagger_a.get_particle ();
  const enum particle_type particle_tilde_b = data_tilde_b.get_particle ();

  const bool particle_dagger_a_tilde_b_same = (particle_dagger_a == particle_tilde_b);

  const class one_body_indices_str &one_body_dagger_a_indices = data_dagger_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_b_indices = data_tilde_b.get_one_body_indices ();
  
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();

  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const int Zval_IN = Z_IN_calc (dagger_tilde_operator , Zval);
  const int Nval_IN = N_IN_calc (dagger_tilde_operator , Nval);

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();

  const class lj_table<int> &nmax_lj_tab_p = prot_data.get_nmax_lj_tab ();
  const class lj_table<int> &nmax_lj_tab_n = neut_data.get_nmax_lj_tab ();

  const class nlj_table<bool> &is_it_valence_shell_tab_p = prot_data.get_is_it_valence_shell_tab ();
  const class nlj_table<bool> &is_it_valence_shell_tab_n = neut_data.get_is_it_valence_shell_tab ();

  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  
  const int n_tilde_b = shell_tilde_b_qn.get_n ();
  const int l_tilde_b = shell_tilde_b_qn.get_l ();
  
  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_tilde_b = shell_tilde_b_qn.get_j ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int MK = make_int (M_OUT - M_IN);

  const int m_dagger_a_number = shell_dagger_a_qn.m_number_determine ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_tilde_MK_tables(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {      
      inSDp_work_tab(i).allocate (Zval_IN);
      inSDn_work_tab(i).allocate (Nval_IN);
      
      outSDp_work_tab(i).allocate (Zval);
      outSDn_work_tab(i).allocate (Nval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_out_work_tab(i).allocate (Zval);
      Cn_out_work_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);
      
      a_dagger_a_tilde_MK_tables(i).allocate (j_dagger_a , j_tilde_b);

      a_dagger_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &inSDp = inSDp_work_tab(i_thread);
      class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

      for (int p = 0 ; p < Zval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);
      for (int n = 0 ; n < Nval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

      if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tab_p , is_it_valence_shell_tab_p)) continue;
      if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tab_n , is_it_valence_shell_tab_n)) continue;
 
      const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
      const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
	  
      const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

      const class Slater_determinant &inSD_dagger_a = SD_find (dagger_tilde_operator , 0 , inSDp , inSDn);
      const class Slater_determinant &inSD_tilde_b  = SD_find (dagger_tilde_operator , 1 , inSDp , inSDn);

      class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
      class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
      if (Zval_IN == Zval) outSDp = inSDp;
      if (Nval_IN == Nval) outSDn = inSDn;

      class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_MK_table = a_dagger_a_tilde_MK_tables(i_thread);
  
      for (int im_dagger_a = 0 ; im_dagger_a < m_dagger_a_number ; im_dagger_a++)
	{
	  const double m_dagger_a = im_dagger_a - j_dagger_a;

	  const double m_tilde_b = MK - m_dagger_a;

	  if (rint (abs (m_tilde_b) - j_tilde_b) <= 0.0)
	    {
	      const unsigned int phi_dagger_a_index = one_body_dagger_a_indices(n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);

	      const unsigned int phi_tilde_b_index = one_body_tilde_b_indices(n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);

	      if ((phi_dagger_a_index != OUT_OF_RANGE) && (phi_tilde_b_index != OUT_OF_RANGE))
		{
		  const bool is_phi_dagger_a_in_inSD_dagger_a = inSD_dagger_a.is_valence_state_occupied (phi_dagger_a_index);

		  const bool is_phi_tilde_b_in_inSD_tilde_b = inSD_tilde_b.is_valence_state_occupied (phi_tilde_b_index);

		  const bool are_phi_dagger_a_phi_tilde_b_equal = (particle_dagger_a_tilde_b_same && (phi_dagger_a_index == phi_tilde_b_index));

		  const bool no_phi_dagger_a_case = (!is_phi_dagger_a_in_inSD_dagger_a && is_phi_tilde_b_in_inSD_tilde_b);

		  const bool phi_dagger_a_phi_tilde_b_equal_case = (are_phi_dagger_a_phi_tilde_b_equal && is_phi_dagger_a_in_inSD_dagger_a && is_phi_tilde_b_in_inSD_tilde_b);

		  if (no_phi_dagger_a_case || phi_dagger_a_phi_tilde_b_equal_case)
		    {
		      unsigned int bin_phase_p = reordering_bin_phase_p;
		      unsigned int bin_phase_n = reordering_bin_phase_n;
			  
		      switch (dagger_tilde_operator)
			{
			case A_DAGGER_A_TILDE_PP: inSDp.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , outSDp , bin_phase_p); break;
			case A_DAGGER_A_TILDE_NN: inSDn.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , outSDn , bin_phase_n); break;

			case RHO_COUPLED_REDUCED_RDM_PP: inSDp.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , outSDp , bin_phase_p); break;
			case RHO_COUPLED_REDUCED_RDM_NN: inSDn.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , outSDn , bin_phase_n); break;
			      
			case A_DAGGER_A_TILDE_NP:
			  {
			    inSDn.excitation_1p_and_bin_phase (phi_dagger_a_index , outSDn , bin_phase_n);
			    inSDp.excitation_1h_and_bin_phase (phi_tilde_b_index  , outSDp , bin_phase_p);
			  } break;
			    
			case A_DAGGER_A_TILDE_PN:
			  {
			    inSDp.excitation_1p_and_bin_phase (phi_dagger_a_index , outSDp , bin_phase_p);
			    inSDn.excitation_1h_and_bin_phase (phi_tilde_b_index  , outSDn , bin_phase_n);
			  } break;
	      
			default: abort_all ();
			}

		      class configuration &Cp_out = Cp_out_work_tab(i_thread);
		      class configuration &Cn_out = Cn_out_work_tab(i_thread);
			  
		      Cp_out.get_SD_configuration (phi_p_table , outSDp);
		      Cn_out.get_SD_configuration (phi_n_table , outSDn);

		      const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_prot);
		      const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_neut);

		      const int iMp_out = outSDp.iM_determine (phi_p_table);
		      const int iMn_out = outSDn.iM_determine (phi_n_table);

		      const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_prot);
		      const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_neut);
			
		      const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_prot);
		      const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_neut);
			  
		      const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_prot);
		      const int En_out_hw = Cn_out.E_hw_determine (shells_qn_neut);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
		      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			    
		      class configuration &Cp_try = Cp_try_tab(i_thread);
		      class configuration &Cn_try = Cn_try_tab(i_thread);

		      class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
		      class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
		      const unsigned int iCp_out = Cp_out.index_search (BPp_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
		      const unsigned int iCn_out = Cn_out.index_search (BPn_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				
		      const unsigned int outSDp_index = outSDp.index_search (BPp_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
		      const unsigned int outSDn_index = outSDn.index_search (BPn_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try); 

		      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
				
		      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);

		      const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

		      const TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];

		      (bin_phase_p == bin_phase_n)
			? (a_dagger_a_tilde_MK_table(m_dagger_a , m_tilde_b) += PSI_IN_component*PSI_OUT_component)
			: (a_dagger_a_tilde_MK_table(m_dagger_a , m_tilde_b) -= PSI_IN_component*PSI_OUT_component);
				    
		    }}}}}
  
  a_dagger_a_tilde_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_tilde_MK_table += a_dagger_a_tilde_MK_tables(i);
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
  
}











void dagger_tilde_operators::a_dagger_a_tilde_MK_RDM_pn_calc (
							      const enum dagger_tilde_operator_type dagger_tilde_operator ,
							      const class nljm_struct &phi_dagger_d , 
							      const class nljm_struct &phi_tilde_c , 
							      const class array<unsigned int> &inSDp_tab ,
							      const class array<unsigned int> &inSDn_tab ,
							      const class GSM_vector &PSI_IN ,
							      class GSM_vector &PSI_OUT_full)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data_dagger_d = data_find (dagger_tilde_operator , 2 , prot_data , neut_data);
  const class nucleons_data &data_tilde_c  = data_find (dagger_tilde_operator , 3 , prot_data , neut_data);

  const enum particle_type particle_dagger_d = data_dagger_d.get_particle ();
  const enum particle_type particle_tilde_c = data_tilde_c.get_particle ();

  const bool particle_dagger_d_tilde_c_same = (particle_dagger_d == particle_tilde_c);

  const class one_body_indices_str &one_body_dagger_d_indices = data_dagger_d.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_c_indices = data_tilde_c.get_one_body_indices ();
  
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();

  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const int Zval_IN = Z_IN_calc (dagger_tilde_operator , Zval);
  const int Nval_IN = N_IN_calc (dagger_tilde_operator , Nval);

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();

  const int n_dagger_d = phi_dagger_d.get_n ();
  const int l_dagger_d = phi_dagger_d.get_l ();
  
  const int n_tilde_c = phi_tilde_c.get_n ();
  const int l_tilde_c = phi_tilde_c.get_l ();
  
  const double j_dagger_d = phi_dagger_d.get_j ();
  const double m_dagger_d = phi_dagger_d.get_m ();
  
  const double j_tilde_c = phi_tilde_c.get_j ();
  const double m_tilde_c = phi_tilde_c.get_m ();

  const unsigned int phi_dagger_d_index = one_body_dagger_d_indices(n_dagger_d , l_dagger_d , j_dagger_d , m_dagger_d);
  
  const unsigned int phi_tilde_c_index = one_body_tilde_c_indices(n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);
  
  const bool are_phi_dagger_d_phi_tilde_c_equal = (particle_dagger_d_tilde_c_same && (phi_dagger_d_index == phi_tilde_c_index));
	  
  PSI_OUT_full = 0.0;
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {      
      inSDp_work_tab(i).allocate (Zval_IN);
      inSDn_work_tab(i).allocate (Nval_IN);
      
      outSDp_work_tab(i).allocate (Zval);
      outSDn_work_tab(i).allocate (Nval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_out_work_tab(i).allocate (Zval);
      Cn_out_work_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);      
    }

  const class GSM_vector_helper_class &PSI_IN_helper = PSI_IN.get_GSM_vector_helper ();
  
  const unsigned int space_dimension_IN = PSI_IN_helper.get_space_dimension_process ();

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &inSDp = inSDp_work_tab(i_thread);
      class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

      for (int p = 0 ; p < Zval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);
      for (int n = 0 ; n < Nval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);
 
      unsigned int bin_phase_p = 0;
      unsigned int bin_phase_n = 0;
	  
      const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];
      
      const class Slater_determinant &inSD_dagger_d = SD_find (dagger_tilde_operator , 2 , inSDp , inSDn);
      const class Slater_determinant &inSD_tilde_c  = SD_find (dagger_tilde_operator , 3 , inSDp , inSDn);
  
      const bool is_phi_dagger_d_in_inSD_dagger_d = inSD_dagger_d.is_valence_state_occupied (phi_dagger_d_index);
	      
      const bool is_phi_tilde_c_in_inSD_tilde_c = inSD_tilde_c.is_valence_state_occupied (phi_tilde_c_index);
	  
      const bool no_phi_dagger_d_case = (!is_phi_dagger_d_in_inSD_dagger_d && is_phi_tilde_c_in_inSD_tilde_c);
	  	  
      const bool phi_dagger_d_phi_tilde_c_equal_case = (are_phi_dagger_d_phi_tilde_c_equal && is_phi_dagger_d_in_inSD_dagger_d);
		      
      if (no_phi_dagger_d_case || phi_dagger_d_phi_tilde_c_equal_case)
	{
	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	  if (Zval_IN == Zval) outSDp = inSDp;
	  if (Nval_IN == Nval) outSDn = inSDn;
	      
	  switch (dagger_tilde_operator)
	    {
	    case G_RDM_PP: inSDp.excitation_1p_1h_and_bin_phase (phi_dagger_d_index , phi_tilde_c_index , outSDp , bin_phase_p); break;
	    case G_RDM_NN: inSDn.excitation_1p_1h_and_bin_phase (phi_dagger_d_index , phi_tilde_c_index , outSDn , bin_phase_n); break;
		  
	    case G_RDM_PN:
	      {
		inSDn.excitation_1p_and_bin_phase (phi_dagger_d_index , outSDn , bin_phase_n);
		inSDp.excitation_1h_and_bin_phase (phi_tilde_c_index  , outSDp , bin_phase_p);
	      } break;
	      
	    case G_RDM_NP:
	      {
		inSDp.excitation_1p_and_bin_phase (phi_dagger_d_index , outSDp , bin_phase_p);
		inSDn.excitation_1h_and_bin_phase (phi_tilde_c_index  , outSDn , bin_phase_n);
	      } break;
	      
	    default: abort_all ();
	    }
	  
	  class configuration &Cp_out = Cp_out_work_tab(i_thread);
	  class configuration &Cn_out = Cn_out_work_tab(i_thread);
	  
	  Cp_out.get_SD_configuration (phi_p_table , outSDp);
	  Cn_out.get_SD_configuration (phi_n_table , outSDn);
	  
	  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_prot);
	  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_neut);

	  const int iMp_out = outSDp.iM_determine (phi_p_table);
	  const int iMn_out = outSDn.iM_determine (phi_n_table);

	  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_prot);
	  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_neut);
			
	  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_prot);
	  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_neut);
	  
	  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_prot);
	  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_neut);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
	  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	  class configuration &Cp_try = Cp_try_tab(i_thread);
	  class configuration &Cn_try = Cn_try_tab(i_thread);
		  
	  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		  
	  const unsigned int iCp_out = Cp_out.index_search (BPp_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
	  const unsigned int iCn_out = Cn_out.index_search (BPn_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
		  
	  const unsigned int outSDp_index = outSDp.index_search (BPp_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
	  const unsigned int outSDn_index = outSDn.index_search (BPn_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try); 
		  
	  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
		  
	  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);
		  
	  const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;
		  
	  TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];
		  
#ifdef UseOpenMP
#pragma omp critical
#endif
	  (bin_phase_p == bin_phase_n) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);
				    
	}
    }
    
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_OUT_full.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
#endif
  
}









void dagger_tilde_operators::a_dagger_a_dagger_MK_table_pn_calc (
								 const enum dagger_tilde_operator_type dagger_tilde_operator , 
								 const class nlj_struct &shell_dagger_a_qn , 
								 const class nlj_struct &shell_dagger_b_qn , 
								 const class correlated_state_str &PSI_IN_qn , 
								 const class correlated_state_str &PSI_OUT_qn , 
								 const class GSM_vector &PSI_OUT_full ,
								 const class array<unsigned int> &inSDp_tab ,
								 const class array<unsigned int> &inSDn_tab ,
								 const class array<TYPE> &PSI_IN_component_tab ,
								 const class array<bool> &is_inSDp_in_new_space_tab ,
								 const class array<bool> &is_inSDn_in_new_space_tab ,
								 const class array<unsigned char> &reordering_bin_phases_p ,
								 const class array<unsigned char> &reordering_bin_phases_n ,
								 class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data_dagger_a = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
  const class nucleons_data &data_dagger_b = data_find (dagger_tilde_operator , 1 , prot_data , neut_data);
  
  const enum particle_type particle_dagger_a = data_dagger_a.get_particle ();
  const enum particle_type particle_dagger_b = data_dagger_b.get_particle ();

  const bool particle_dagger_ab_same = (particle_dagger_a == particle_dagger_b);

  const class one_body_indices_str &one_body_dagger_a_indices = data_dagger_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_b_indices = data_dagger_b.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
    
  const int Zval_IN = Z_IN_calc (dagger_tilde_operator , Zval);
  const int Nval_IN = N_IN_calc (dagger_tilde_operator , Nval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();

  const class lj_table<int> &nmax_lj_tab_p = prot_data.get_nmax_lj_tab ();
  const class lj_table<int> &nmax_lj_tab_n = neut_data.get_nmax_lj_tab ();

  const class nlj_table<bool> &is_it_valence_shell_tab_p = prot_data.get_is_it_valence_shell_tab ();
  const class nlj_table<bool> &is_it_valence_shell_tab_n = neut_data.get_is_it_valence_shell_tab ();

  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int n_dagger_b = shell_dagger_b_qn.get_n ();
  
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  const int l_dagger_b = shell_dagger_b_qn.get_l ();

  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_dagger_b = shell_dagger_b_qn.get_j ();

  const int m_dagger_a_number = shell_dagger_a_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int MK = make_int (M_OUT - M_IN);
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_dagger_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (Zval_IN);
      inSDn_work_tab(i).allocate (Nval_IN);

      outSDp_work_tab(i).allocate (Zval);
      outSDn_work_tab(i).allocate (Nval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_out_work_tab(i).allocate (Zval);
      Cn_out_work_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);
      
      a_dagger_a_dagger_MK_tables(i).allocate (j_dagger_a , j_dagger_b);

      a_dagger_a_dagger_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

      for (int p = 0 ; p < Zval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

      if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tab_p , is_it_valence_shell_tab_p)) continue;

      class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

      for (int n = 0 ; n < Nval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

      if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tab_n , is_it_valence_shell_tab_n)) continue;

      const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
      const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
      
      const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

      const class Slater_determinant &inSD_dagger_a = SD_find (dagger_tilde_operator , 0 , inSDp , inSDn);
      const class Slater_determinant &inSD_dagger_b = SD_find (dagger_tilde_operator , 1 , inSDp , inSDn);

      class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
      class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
      if (Zval_IN == Zval) outSDp = inSDp;
      if (Nval_IN == Nval) outSDn = inSDn;

      class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_MK_table = a_dagger_a_dagger_MK_tables(i_thread);

      for (int im_dagger_a = 0 ; im_dagger_a < m_dagger_a_number ; im_dagger_a++)
	{
	  const double m_dagger_a = im_dagger_a - j_dagger_a;

	  const double m_dagger_b = MK - m_dagger_a;

	  if (rint (abs (m_dagger_b) - j_dagger_b) <= 0.0)
	    {
	      const unsigned int phi_dagger_a_index = one_body_dagger_a_indices(n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
	      const unsigned int phi_dagger_b_index = one_body_dagger_b_indices(n_dagger_b , l_dagger_b , j_dagger_b , m_dagger_b);

	      if ((phi_dagger_a_index != OUT_OF_RANGE) && (phi_dagger_b_index != OUT_OF_RANGE))
		{ 
		  const bool are_phi_dagger_ab_different = (!particle_dagger_ab_same || (phi_dagger_a_index != phi_dagger_b_index));

		  if (are_phi_dagger_ab_different && !inSD_dagger_a.is_valence_state_occupied (phi_dagger_a_index) && !inSD_dagger_b.is_valence_state_occupied (phi_dagger_b_index))
		    {
		      unsigned int bin_phase_p = reordering_bin_phase_p;
		      unsigned int bin_phase_n = reordering_bin_phase_n;
			  
		      switch (dagger_tilde_operator)
			{
			case A_DAGGER_A_DAGGER_PP: inSDp.excitation_2p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , outSDp , bin_phase_p); break;
			case A_DAGGER_A_DAGGER_NN: inSDn.excitation_2p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , outSDn , bin_phase_n); break;
			    
			case A_DAGGER_A_DAGGER_PN:
			  {
			    inSDp.excitation_1p_and_bin_phase (phi_dagger_a_index , outSDp , bin_phase_p);
			    inSDn.excitation_1p_and_bin_phase (phi_dagger_b_index , outSDn , bin_phase_n);
			  } break;
			    			      
			default: abort_all ();
			}
							
		      class configuration &Cp_out = Cp_out_work_tab(i_thread);
		      class configuration &Cn_out = Cn_out_work_tab(i_thread);

		      Cp_out.get_SD_configuration (phi_p_table , outSDp);
		      Cn_out.get_SD_configuration (phi_n_table , outSDn);			

		      const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_prot);
		      const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_neut);
			
		      const int iMp_out = outSDp.iM_determine (phi_p_table);
		      const int iMn_out = outSDn.iM_determine (phi_n_table);

		      const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_prot);
		      const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_neut);
			
		      const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_prot);
		      const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_neut);
			  
		      const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_prot);
		      const int En_out_hw = Cn_out.E_hw_determine (shells_qn_neut); 

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
		      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			    
		      class configuration &Cp_try = Cp_try_tab(i_thread);
		      class configuration &Cn_try = Cn_try_tab(i_thread);

		      class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
		      class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
		      const unsigned int iCp_out = Cp_out.index_search (BPp_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
		      const unsigned int iCn_out = Cn_out.index_search (BPn_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				
		      const unsigned int outSDp_index = outSDp.index_search (BPp_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
		      const unsigned int outSDn_index = outSDn.index_search (BPn_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

		      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

		      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);

		      const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

		      const TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];
	
		      (bin_phase_p == bin_phase_n)
			? (a_dagger_a_dagger_MK_table(m_dagger_a , m_dagger_b) += PSI_IN_component*PSI_OUT_component)
			: (a_dagger_a_dagger_MK_table(m_dagger_a , m_dagger_b) -= PSI_IN_component*PSI_OUT_component);
				      
		    }}}}}

  a_dagger_a_dagger_MK_table = 0.0;
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_dagger_MK_table += a_dagger_a_dagger_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_dagger_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}







void dagger_tilde_operators::a_dagger_a_dagger_MK_RDM_pn_calc (
							       const enum dagger_tilde_operator_type dagger_tilde_operator , 
							       const class nljm_struct &phi_dagger_d , 
							       const class nljm_struct &phi_dagger_c , 
							       const class array<unsigned int> &inSDp_tab ,
							       const class array<unsigned int> &inSDn_tab ,
							       const class GSM_vector &PSI_IN ,
							       class GSM_vector &PSI_OUT_full)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data_dagger_d = data_find (dagger_tilde_operator , 2 , prot_data , neut_data);
  const class nucleons_data &data_dagger_c = data_find (dagger_tilde_operator , 3 , prot_data , neut_data);
  
  const enum particle_type particle_dagger_d = data_dagger_d.get_particle ();
  const enum particle_type particle_dagger_c = data_dagger_c.get_particle ();

  const bool particle_dagger_dc_same = (particle_dagger_d == particle_dagger_c);

  const class one_body_indices_str &one_body_dagger_d_indices = data_dagger_d.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_c_indices = data_dagger_c.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
    
  const int Zval_IN = Z_IN_calc (dagger_tilde_operator , Zval);
  const int Nval_IN = N_IN_calc (dagger_tilde_operator , Nval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();

  const int n_dagger_d = phi_dagger_d.get_n ();
  const int n_dagger_c = phi_dagger_c.get_n ();
  
  const int l_dagger_d = phi_dagger_d.get_l ();
  const int l_dagger_c = phi_dagger_c.get_l ();
  
  const double j_dagger_d = phi_dagger_d.get_j ();
  const double m_dagger_d = phi_dagger_d.get_m ();

  const double j_dagger_c = phi_dagger_c.get_j ();
  const double m_dagger_c = phi_dagger_c.get_m ();

  const unsigned int phi_dagger_d_index = one_body_dagger_d_indices(n_dagger_d , l_dagger_d , j_dagger_d , m_dagger_d);
  const unsigned int phi_dagger_c_index = one_body_dagger_c_indices(n_dagger_c , l_dagger_c , j_dagger_c , m_dagger_c);
		  
  const bool are_phi_dagger_dc_different = (!particle_dagger_dc_same || (phi_dagger_d_index != phi_dagger_c_index));

  PSI_OUT_full = 0.0;
  
  if (!are_phi_dagger_dc_different) return;
	  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (Zval_IN);
      inSDn_work_tab(i).allocate (Nval_IN);

      outSDp_work_tab(i).allocate (Zval);
      outSDn_work_tab(i).allocate (Nval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_out_work_tab(i).allocate (Zval);
      Cn_out_work_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);      
    }

  const class GSM_vector_helper_class &PSI_IN_helper = PSI_IN.get_GSM_vector_helper ();
  
  const unsigned int space_dimension_IN = PSI_IN_helper.get_space_dimension_process ();
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

      for (int p = 0 ; p < Zval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

      class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

      for (int n = 0 ; n < Nval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

      unsigned int bin_phase_p = 0;
      unsigned int bin_phase_n = 0;
      
      const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];

      const class Slater_determinant &inSD_dagger_d = SD_find (dagger_tilde_operator , 2 , inSDp , inSDn);
      const class Slater_determinant &inSD_dagger_c = SD_find (dagger_tilde_operator , 3 , inSDp , inSDn);

      if (!inSD_dagger_d.is_valence_state_occupied (phi_dagger_d_index) && !inSD_dagger_c.is_valence_state_occupied (phi_dagger_c_index))
	{
	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	  if (Zval_IN == Zval) outSDp = inSDp;
	  if (Nval_IN == Nval) outSDn = inSDn;

	  switch (dagger_tilde_operator)
	    {
	    case Q_RDM_PP: inSDp.excitation_2p_and_bin_phase (phi_dagger_d_index , phi_dagger_c_index , outSDp , bin_phase_p); break;
	    case Q_RDM_NN: inSDn.excitation_2p_and_bin_phase (phi_dagger_d_index , phi_dagger_c_index , outSDn , bin_phase_n); break;
			    
	    case Q_RDM_PN:
	      {
		inSDn.excitation_1p_and_bin_phase (phi_dagger_d_index , outSDn , bin_phase_n);
		inSDp.excitation_1p_and_bin_phase (phi_dagger_c_index , outSDp , bin_phase_p);
	      } break;
			    			    
	    default: abort_all ();
	    }
							
	  class configuration &Cp_out = Cp_out_work_tab(i_thread);
	  class configuration &Cn_out = Cn_out_work_tab(i_thread);

	  Cp_out.get_SD_configuration (phi_p_table , outSDp);
	  Cn_out.get_SD_configuration (phi_n_table , outSDn);			

	  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_prot);
	  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_neut);
			
	  const int iMp_out = outSDp.iM_determine (phi_p_table);
	  const int iMn_out = outSDn.iM_determine (phi_n_table);

	  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_prot);
	  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_neut);
			
	  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_prot);
	  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_neut);
			  
	  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_prot);
	  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_neut); 

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
	  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	  class configuration &Cp_try = Cp_try_tab(i_thread);
	  class configuration &Cn_try = Cn_try_tab(i_thread);

	  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
	  const unsigned int iCp_out = Cp_out.index_search (BPp_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
	  const unsigned int iCn_out = Cn_out.index_search (BPn_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				
	  const unsigned int outSDp_index = outSDp.index_search (BPp_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
	  const unsigned int outSDn_index = outSDn.index_search (BPn_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

	  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

	  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);

	  const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

	  TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];

#ifdef UseOpenMP
#pragma omp critical
#endif
	  (bin_phase_p == bin_phase_n) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);
				    
	}
    }
      
#ifdef UseMPI
      
  if (is_it_MPI_parallelized) PSI_OUT_full.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);

#endif
  
}







void dagger_tilde_operators::a_tilde_a_tilde_MK_table_pn_calc (
							       const enum dagger_tilde_operator_type dagger_tilde_operator , 
							       const class nlj_struct &shell_tilde_a_qn , 
							       const class nlj_struct &shell_tilde_b_qn , 
							       const class correlated_state_str &PSI_IN_qn , 
							       const class correlated_state_str &PSI_OUT_qn , 
							       const class GSM_vector &PSI_OUT_full ,
							       const class array<unsigned int> &inSDp_tab ,
							       const class array<unsigned int> &inSDn_tab ,
							       const class array<TYPE> &PSI_IN_component_tab ,
							       const class array<bool> &is_inSDp_in_new_space_tab ,
							       const class array<bool> &is_inSDn_in_new_space_tab ,
							       const class array<unsigned char> &reordering_bin_phases_p ,
							       const class array<unsigned char> &reordering_bin_phases_n ,
							       class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_MK_table)
{  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data_tilde_a = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
  const class nucleons_data &data_tilde_b = data_find (dagger_tilde_operator , 1 , prot_data , neut_data);
  
  const enum particle_type particle_tilde_a = data_tilde_a.get_particle ();
  const enum particle_type particle_tilde_b = data_tilde_b.get_particle ();

  const bool particle_tilde_ab_same = (particle_tilde_a == particle_tilde_b);

  const class one_body_indices_str &one_body_tilde_a_indices = data_tilde_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_b_indices = data_tilde_b.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
   
  const int Zval_IN = Z_IN_calc (dagger_tilde_operator , Zval);
  const int Nval_IN = N_IN_calc (dagger_tilde_operator , Nval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();

  const class lj_table<int> &nmax_lj_tab_p = prot_data.get_nmax_lj_tab ();
  const class lj_table<int> &nmax_lj_tab_n = neut_data.get_nmax_lj_tab ();

  const class nlj_table<bool> &is_it_valence_shell_tab_p = prot_data.get_is_it_valence_shell_tab ();
  const class nlj_table<bool> &is_it_valence_shell_tab_n = neut_data.get_is_it_valence_shell_tab ();

  const int n_tilde_a = shell_tilde_a_qn.get_n ();
  const int n_tilde_b = shell_tilde_b_qn.get_n ();
  
  const int l_tilde_a = shell_tilde_a_qn.get_l ();  
  const int l_tilde_b = shell_tilde_b_qn.get_l ();

  const double j_tilde_a = shell_tilde_a_qn.get_j ();
  const double j_tilde_b = shell_tilde_b_qn.get_j ();

  const int m_tilde_a_number = shell_tilde_a_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int MK = make_int (M_OUT - M_IN);
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
    
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_tilde_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (Zval_IN);
      inSDn_work_tab(i).allocate (Nval_IN);
      
      outSDp_work_tab(i).allocate (Zval);
      outSDn_work_tab(i).allocate (Nval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_out_work_tab(i).allocate (Zval);
      Cn_out_work_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);
      
      a_tilde_a_tilde_MK_tables(i).allocate (j_tilde_a , j_tilde_b);

      a_tilde_a_tilde_MK_tables(i) = 0.0;
    }
  
  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &inSDp = inSDp_work_tab(i_thread);
      class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

      for (int p = 0 ; p < Zval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);
      for (int n = 0 ; n < Nval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

      if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tab_p , is_it_valence_shell_tab_p)) continue;
      if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tab_n , is_it_valence_shell_tab_n)) continue;
 
      const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
      const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
      
      const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

      const class Slater_determinant &inSD_tilde_a = SD_find (dagger_tilde_operator , 0 , inSDp , inSDn);
      const class Slater_determinant &inSD_tilde_b = SD_find (dagger_tilde_operator , 1 , inSDp , inSDn);
      
      class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
      class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
      if (Zval_IN == Zval) outSDp = inSDp;
      if (Nval_IN == Nval) outSDn = inSDn;

      class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_MK_table = a_tilde_a_tilde_MK_tables(i_thread);
	  
      for (int im_tilde_a = 0 ; im_tilde_a < m_tilde_a_number ; im_tilde_a++)
	{
	  const double m_tilde_a = im_tilde_a - j_tilde_a;
	  const double m_tilde_b = MK - m_tilde_a;

	  if (rint (abs (m_tilde_b) - j_tilde_b) <= 0.0)
	    {
	      const unsigned int phi_tilde_a_index = one_body_tilde_a_indices(n_tilde_a , l_tilde_a , j_tilde_a , -m_tilde_a);
	      const unsigned int phi_tilde_b_index = one_body_tilde_b_indices(n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);

	      if ((phi_tilde_a_index != OUT_OF_RANGE) && (phi_tilde_b_index != OUT_OF_RANGE))
		{
		  const bool are_phi_tilde_ab_different = (!particle_tilde_ab_same || (phi_tilde_a_index != phi_tilde_b_index));

		  if (are_phi_tilde_ab_different && inSD_tilde_a.is_valence_state_occupied (phi_tilde_a_index) && inSD_tilde_b.is_valence_state_occupied (phi_tilde_b_index))
		    {
		      unsigned int bin_phase_p = reordering_bin_phase_p;
		      unsigned int bin_phase_n = reordering_bin_phase_n;
			  
		      switch (dagger_tilde_operator)
			{
			case A_TILDE_A_TILDE_PP: inSDp.excitation_2h_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , outSDp , bin_phase_p); break;			    
			case A_TILDE_A_TILDE_NN: inSDn.excitation_2h_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , outSDn , bin_phase_n); break;
			    
			case A_TILDE_A_TILDE_PN:
			  {
			    inSDp.excitation_1h_and_bin_phase (phi_tilde_a_index , outSDp , bin_phase_p);
			    inSDn.excitation_1h_and_bin_phase (phi_tilde_b_index , outSDn , bin_phase_n);
			  } break;
			    			      
			default: abort_all ();
			}
							
		      class configuration &Cp_out = Cp_out_work_tab(i_thread);
		      class configuration &Cn_out = Cn_out_work_tab(i_thread);
			  
		      Cp_out.get_SD_configuration (phi_p_table , outSDp);
		      Cn_out.get_SD_configuration (phi_n_table , outSDn);

		      const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_prot);
		      const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_neut);
			
		      const int iMp_out = outSDp.iM_determine (phi_p_table);
		      const int iMn_out = outSDn.iM_determine (phi_n_table);

		      const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_prot);
		      const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_neut);
			
		      const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_prot);
		      const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_neut);
			  
		      const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_prot);
		      const int En_out_hw = Cn_out.E_hw_determine (shells_qn_neut);
 
		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
		      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			    
		      class configuration &Cp_try = Cp_try_tab(i_thread);
		      class configuration &Cn_try = Cn_try_tab(i_thread);

		      class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
		      class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
		      const unsigned int iCp_out = Cp_out.index_search (BPp_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
		      const unsigned int iCn_out = Cn_out.index_search (BPn_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				
		      const unsigned int outSDp_index = outSDp.index_search (BPp_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
		      const unsigned int outSDn_index = outSDn.index_search (BPn_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

		      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

		      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);

		      const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

		      const TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];

		      (bin_phase_p == bin_phase_n)
			? (a_tilde_a_tilde_MK_table(m_tilde_a , m_tilde_b) += PSI_IN_component*PSI_OUT_component)
			: (a_tilde_a_tilde_MK_table(m_tilde_a , m_tilde_b) -= PSI_IN_component*PSI_OUT_component);
 
		    }}}}}
  
  a_tilde_a_tilde_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_tilde_a_tilde_MK_table += a_tilde_a_tilde_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_tilde_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}





void dagger_tilde_operators::a_tilde_a_tilde_MK_RDM_pn_calc (
							     const enum dagger_tilde_operator_type dagger_tilde_operator ,  
							     const class nljm_struct &phi_tilde_d , 
							     const class nljm_struct &phi_tilde_c , 
							     const class array<unsigned int> &inSDp_tab ,
							     const class array<unsigned int> &inSDn_tab ,
							     const class GSM_vector &PSI_IN ,
							     class GSM_vector &PSI_OUT_full)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data_tilde_d = data_find (dagger_tilde_operator , 2 , prot_data , neut_data);
  const class nucleons_data &data_tilde_c = data_find (dagger_tilde_operator , 3 , prot_data , neut_data);
  
  const enum particle_type particle_tilde_d = data_tilde_d.get_particle ();
  const enum particle_type particle_tilde_c = data_tilde_c.get_particle ();

  const bool particle_tilde_dc_same = (particle_tilde_d == particle_tilde_c);

  const class one_body_indices_str &one_body_tilde_d_indices = data_tilde_d.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_c_indices = data_tilde_c.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
   
  const int Zval_IN = Z_IN_calc (dagger_tilde_operator , Zval);
  const int Nval_IN = N_IN_calc (dagger_tilde_operator , Nval);
    
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();

  const int n_tilde_d = phi_tilde_d.get_n ();
  const int n_tilde_c = phi_tilde_c.get_n ();
    
  const int l_tilde_d = phi_tilde_d.get_l ();
  const int l_tilde_c = phi_tilde_c.get_l ();
  
  const double j_tilde_d = phi_tilde_d.get_j ();
  const double m_tilde_d = phi_tilde_d.get_m ();

  const double j_tilde_c = phi_tilde_c.get_j ();
  const double m_tilde_c = phi_tilde_c.get_m ();
  
  const unsigned int phi_tilde_d_index = one_body_tilde_d_indices(n_tilde_d , l_tilde_d , j_tilde_d , -m_tilde_d);
  const unsigned int phi_tilde_c_index = one_body_tilde_c_indices(n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);
  
  const bool are_phi_tilde_dc_different = (!particle_tilde_dc_same || (phi_tilde_d_index != phi_tilde_c_index));

  PSI_OUT_full = 0.0;
  
  if (!are_phi_tilde_dc_different) return;
	  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
    
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (Zval_IN);
      inSDn_work_tab(i).allocate (Nval_IN);
      
      outSDp_work_tab(i).allocate (Zval);
      outSDn_work_tab(i).allocate (Nval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_out_work_tab(i).allocate (Zval);
      Cn_out_work_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);      
    }

  const class GSM_vector_helper_class &PSI_IN_helper = PSI_IN.get_GSM_vector_helper ();
  
  const unsigned int space_dimension_IN = PSI_IN_helper.get_space_dimension_process ();        
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &inSDp = inSDp_work_tab(i_thread);
      class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

      for (int p = 0 ; p < Zval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);
      for (int n = 0 ; n < Nval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);
 
      unsigned int bin_phase_p = 0;
      unsigned int bin_phase_n = 0;
      
      const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];
      
      const class Slater_determinant &inSD_tilde_d = SD_find (dagger_tilde_operator , 2 , inSDp , inSDn);
      const class Slater_determinant &inSD_tilde_c = SD_find (dagger_tilde_operator , 3 , inSDp , inSDn);
      
      if (inSD_tilde_d.is_valence_state_occupied (phi_tilde_d_index) && inSD_tilde_c.is_valence_state_occupied (phi_tilde_c_index))
	{
	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	  if (Zval_IN == Zval) outSDp = inSDp;
	  if (Nval_IN == Nval) outSDn = inSDn;
	      
	  switch (dagger_tilde_operator)
	    {
	    case P_RDM_PP: inSDp.excitation_2h_and_bin_phase (phi_tilde_d_index , phi_tilde_c_index , outSDp , bin_phase_p); break;			    
	    case P_RDM_NN: inSDn.excitation_2h_and_bin_phase (phi_tilde_d_index , phi_tilde_c_index , outSDn , bin_phase_n); break;
			    
	    case P_RDM_PN:
	      {
		inSDn.excitation_1h_and_bin_phase (phi_tilde_d_index , outSDn , bin_phase_n);
		inSDp.excitation_1h_and_bin_phase (phi_tilde_c_index , outSDp , bin_phase_p);
	      } break;
		  
	    default: abort_all ();
	    }
	      
	  class configuration &Cp_out = Cp_out_work_tab(i_thread);
	  class configuration &Cn_out = Cn_out_work_tab(i_thread);
	      
	  Cp_out.get_SD_configuration (phi_p_table , outSDp);
	  Cn_out.get_SD_configuration (phi_n_table , outSDn);

	  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_prot);
	  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_neut);
			
	  const int iMp_out = outSDp.iM_determine (phi_p_table);
	  const int iMn_out = outSDn.iM_determine (phi_n_table);

	  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_prot);
	  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_neut);
			
	  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_prot);
	  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_neut);
			  
	  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_prot);
	  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_neut);
 
	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
	  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	  class configuration &Cp_try = Cp_try_tab(i_thread);
	  class configuration &Cn_try = Cn_try_tab(i_thread);

	  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
	  const unsigned int iCp_out = Cp_out.index_search (BPp_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
	  const unsigned int iCn_out = Cn_out.index_search (BPn_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				
	  const unsigned int outSDp_index = outSDp.index_search (BPp_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
	  const unsigned int outSDn_index = outSDn.index_search (BPn_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

	  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

	  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);

	  const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

	  TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];

#ifdef UseOpenMP
#pragma omp critical
#endif
	  (bin_phase_p == bin_phase_n) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);
				    
	}
    }
    
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_OUT_full.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);

#endif
  
}

















void dagger_tilde_operators::a_dagger_a_dagger_a_tilde_MK_table_pn_calc (
									 const enum dagger_tilde_operator_type dagger_tilde_operator ,
									 const class nlj_struct &shell_dagger_a_qn , 
									 const class nlj_struct &shell_dagger_b_qn ,  
									 const class nlj_struct &shell_tilde_c_qn , 
									 const class correlated_state_str &PSI_IN_qn , 
									 const class correlated_state_str &PSI_OUT_qn , 
									 const class GSM_vector &PSI_OUT_full ,
									 const class array<unsigned int> &inSDp_tab ,
									 const class array<unsigned int> &inSDn_tab ,
									 const class array<TYPE> &PSI_IN_component_tab ,
									 const class array<bool> &is_inSDp_in_new_space_tab ,
									 const class array<bool> &is_inSDn_in_new_space_tab ,
									 const class array<unsigned char> &reordering_bin_phases_p ,
									 const class array<unsigned char> &reordering_bin_phases_n ,
									 class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data_dagger_a = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
  const class nucleons_data &data_dagger_b = data_find (dagger_tilde_operator , 1 , prot_data , neut_data); 
  const class nucleons_data &data_tilde_c  = data_find (dagger_tilde_operator , 2 , prot_data , neut_data);
  
  const enum particle_type particle_tilde_c = data_tilde_c.get_particle ();
  
  const enum particle_type particle_dagger_a = data_dagger_a.get_particle ();
  const enum particle_type particle_dagger_b = data_dagger_b.get_particle ();

  const bool particle_tilde_c_dagger_a_same = (particle_tilde_c == particle_dagger_a);
  const bool particle_tilde_c_dagger_b_same = (particle_tilde_c == particle_dagger_b);
  
  const bool particle_dagger_ab_same = (particle_dagger_a == particle_dagger_b);

  const class one_body_indices_str &one_body_tilde_c_indices = data_tilde_c.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_a_indices = data_dagger_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_b_indices = data_dagger_b.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
    
  const int Zval_IN = Z_IN_calc (dagger_tilde_operator , Zval);
  const int Nval_IN = N_IN_calc (dagger_tilde_operator , Nval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();

  const class lj_table<int> &nmax_lj_tab_p = prot_data.get_nmax_lj_tab ();
  const class lj_table<int> &nmax_lj_tab_n = neut_data.get_nmax_lj_tab ();

  const class nlj_table<bool> &is_it_valence_shell_tab_p = prot_data.get_is_it_valence_shell_tab ();
  const class nlj_table<bool> &is_it_valence_shell_tab_n = neut_data.get_is_it_valence_shell_tab ();

  const int n_tilde_c = shell_tilde_c_qn.get_n ();
  const int l_tilde_c = shell_tilde_c_qn.get_l ();
  
  const double j_tilde_c = shell_tilde_c_qn.get_j ();
  
  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int n_dagger_b = shell_dagger_b_qn.get_n ();
  
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  const int l_dagger_b = shell_dagger_b_qn.get_l ();  
  
  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_dagger_b = shell_dagger_b_qn.get_j ();
  
  const int m_dagger_a_number = shell_dagger_a_qn.m_number_determine ();
  const int m_dagger_b_number = shell_dagger_b_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
      
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_dagger_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (Zval_IN);
      inSDn_work_tab(i).allocate (Nval_IN);

      outSDp_work_tab(i).allocate (Zval);
      outSDn_work_tab(i).allocate (Nval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_out_work_tab(i).allocate (Zval);
      Cn_out_work_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);
      
      a_dagger_a_dagger_a_tilde_MK_tables(i).allocate (j_dagger_a , j_dagger_b , j_tilde_c);

      a_dagger_a_dagger_a_tilde_MK_tables(i) = 0.0;
    }

  
  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

      for (int p = 0 ; p < Zval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

      if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tab_p , is_it_valence_shell_tab_p)) continue;

      class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

      for (int n = 0 ; n < Nval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

      if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tab_n , is_it_valence_shell_tab_n)) continue;

      const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
      const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
      
      const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

      const class Slater_determinant &inSD_dagger_a = SD_find (dagger_tilde_operator , 0 , inSDp , inSDn);
      const class Slater_determinant &inSD_dagger_b = SD_find (dagger_tilde_operator , 1 , inSDp , inSDn);
      const class Slater_determinant &inSD_tilde_c  = SD_find (dagger_tilde_operator , 2 , inSDp , inSDn);
      
      class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
      class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
      if (Zval_IN == Zval) outSDp = inSDp;
      if (Nval_IN == Nval) outSDn = inSDn;

      class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_tilde_MK_table = a_dagger_a_dagger_a_tilde_MK_tables(i_thread);

      for (int im_dagger_a = 0 ; im_dagger_a < m_dagger_a_number ; im_dagger_a++)
	{
	  const double m_dagger_a = im_dagger_a - j_dagger_a;
	  
	  for (int im_dagger_b = 0 ; im_dagger_b < m_dagger_b_number ; im_dagger_b++)
	    {
	      const double m_dagger_b = im_dagger_b - j_dagger_b;
		  
	      const double ML = m_dagger_a + m_dagger_b;

	      const double m_tilde_c = MK - ML;
	  
	      if (rint (abs (m_tilde_c) - j_tilde_c) <= 0.0)
		{
		  const unsigned int phi_tilde_c_index = one_body_tilde_c_indices(n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);

		  const unsigned int phi_dagger_a_index = one_body_dagger_a_indices(n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
		  const unsigned int phi_dagger_b_index = one_body_dagger_b_indices(n_dagger_b , l_dagger_b , j_dagger_b , m_dagger_b);

		  if ((phi_tilde_c_index != OUT_OF_RANGE) && (phi_dagger_a_index != OUT_OF_RANGE) && (phi_dagger_b_index != OUT_OF_RANGE))
		    {
		      const bool is_phi_tilde_c_in_inSD_tilde_c = inSD_tilde_c.is_valence_state_occupied (phi_tilde_c_index);

		      const bool are_phi_dagger_ab_different = (!particle_dagger_ab_same || (phi_dagger_a_index != phi_dagger_b_index));

		      if (is_phi_tilde_c_in_inSD_tilde_c && are_phi_dagger_ab_different)
			{
			  const bool is_phi_dagger_a_not_in_inSD_dagger_a = !inSD_dagger_a.is_valence_state_occupied (phi_dagger_a_index);
			  const bool is_phi_dagger_b_not_in_inSD_dagger_b = !inSD_dagger_b.is_valence_state_occupied (phi_dagger_b_index);

			  const bool no_dagger_ab_case = is_phi_dagger_a_not_in_inSD_dagger_a && is_phi_dagger_b_not_in_inSD_dagger_b;

			  const bool are_phi_tilde_c_phi_dagger_a_equal = (particle_tilde_c_dagger_a_same && (phi_tilde_c_index == phi_dagger_a_index));
			  const bool are_phi_tilde_c_phi_dagger_b_equal = (particle_tilde_c_dagger_b_same && (phi_tilde_c_index == phi_dagger_b_index));

			  const bool phi_tilde_c_phi_dagger_a_equal_case = (are_phi_tilde_c_phi_dagger_a_equal && is_phi_dagger_b_not_in_inSD_dagger_b);
			  const bool phi_tilde_c_phi_dagger_b_equal_case = (are_phi_tilde_c_phi_dagger_b_equal && is_phi_dagger_a_not_in_inSD_dagger_a);

			  if (no_dagger_ab_case || phi_tilde_c_phi_dagger_a_equal_case || phi_tilde_c_phi_dagger_b_equal_case)
			    {
			      unsigned int bin_phase_p = reordering_bin_phase_p;
			      unsigned int bin_phase_n = reordering_bin_phase_n;
			  
			      switch (dagger_tilde_operator)
				{ 
				case A_DAGGER_A_DAGGER_A_TILDE_PPP: inSDp.excitation_2p_1h_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , phi_tilde_c_index , outSDp , bin_phase_p); break;
				case A_DAGGER_A_DAGGER_A_TILDE_NNN: inSDn.excitation_2p_1h_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , phi_tilde_c_index , outSDn , bin_phase_n); break;
				  
				case A_DAGGER_A_DAGGER_A_TILDE_PPN:
				  {
				    inSDn.excitation_1h_and_bin_phase (phi_tilde_c_index , outSDn , bin_phase_n);
				    inSDp.excitation_2p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , outSDp , bin_phase_p);
				  } break;
				      
				case A_DAGGER_A_DAGGER_A_TILDE_PNN:
				  {
				    inSDn.excitation_1p_1h_and_bin_phase (phi_dagger_b_index , phi_tilde_c_index , outSDn , bin_phase_n);
				    inSDp.excitation_1p_and_bin_phase (phi_dagger_a_index , outSDp , bin_phase_p);
				  } break;				  

				case A_DAGGER_A_DAGGER_A_TILDE_PNP:
				  {
				    inSDp.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_c_index , outSDp , bin_phase_p);
				    inSDn.excitation_1p_and_bin_phase (phi_dagger_b_index , outSDn , bin_phase_n);
				  } break;				  
				  
				case A_DAGGER_A_DAGGER_A_TILDE_NNP:
				  {
				    inSDp.excitation_1h_and_bin_phase (phi_tilde_c_index , outSDp , bin_phase_p);
				    inSDn.excitation_2p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , outSDn , bin_phase_n);
				  } break;
				  				      
				default: abort_all ();
				}
									
			      class configuration &Cp_out = Cp_out_work_tab(i_thread);
			      class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
			      Cp_out.get_SD_configuration (phi_p_table , outSDp);
			      Cn_out.get_SD_configuration (phi_n_table , outSDn);

			      const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_prot);
			      const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_neut);
			      
			      const int iMp_out = outSDp.iM_determine (phi_p_table);
			      const int iMn_out = outSDn.iM_determine (phi_n_table);

			      const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_prot);
			      const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_neut);
				  
			      const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_prot);
			      const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_neut); 

			      const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_prot);
			      const int En_out_hw = Cn_out.E_hw_determine (shells_qn_neut);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				    
			      class configuration &Cp_try = Cp_try_tab(i_thread);
			      class configuration &Cn_try = Cn_try_tab(i_thread);
					  
			      class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
			      class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
			      const unsigned int iCp_out = Cp_out.index_search (BPp_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
			      const unsigned int iCn_out = Cn_out.index_search (BPn_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				      
			      const unsigned int outSDp_index = outSDp.index_search (BPp_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
			      const unsigned int outSDn_index = outSDn.index_search (BPn_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

			      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

			      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);

			      const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

			      const TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];

			      (bin_phase_p == bin_phase_n)
				? (a_dagger_a_dagger_a_tilde_MK_table(m_dagger_a , m_dagger_b , m_tilde_c) += PSI_IN_component*PSI_OUT_component) 
				: (a_dagger_a_dagger_a_tilde_MK_table(m_dagger_a , m_dagger_b , m_tilde_c) -= PSI_IN_component*PSI_OUT_component);
					  
			    }}}}}}}
  
  a_dagger_a_dagger_a_tilde_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_dagger_a_tilde_MK_table += a_dagger_a_dagger_a_tilde_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_dagger_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}




















void dagger_tilde_operators::a_dagger_a_dagger_a_tilde_MK_RDM_pn_calc (
								       const enum dagger_tilde_operator_type dagger_tilde_operator ,   
								       const class nljm_struct &phi_dagger_f , 
								       const class nljm_struct &phi_dagger_e , 
								       const class nljm_struct &phi_tilde_d , 
								       const class array<unsigned int> &inSDp_tab ,
								       const class array<unsigned int> &inSDn_tab ,
								       const class GSM_vector &PSI_IN ,
								       class GSM_vector &PSI_OUT_full)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const class nucleons_data &data_dagger_f = data_find (dagger_tilde_operator , 3 , prot_data , neut_data);
  const class nucleons_data &data_dagger_e = data_find (dagger_tilde_operator , 4 , prot_data , neut_data); 
  const class nucleons_data &data_tilde_d  = data_find (dagger_tilde_operator , 5 , prot_data , neut_data);
  
  const enum particle_type particle_dagger_f = data_dagger_f.get_particle ();
  const enum particle_type particle_dagger_e = data_dagger_e.get_particle ();
  const enum particle_type particle_tilde_d  = data_tilde_d.get_particle ();

  const bool particle_tilde_d_dagger_f_same = (particle_tilde_d == particle_dagger_f);
  const bool particle_tilde_d_dagger_e_same = (particle_tilde_d == particle_dagger_e);
  
  const bool particle_dagger_fe_same = (particle_dagger_f == particle_dagger_e);

  const class one_body_indices_str &one_body_dagger_f_indices = data_dagger_f.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_e_indices = data_dagger_e.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_d_indices = data_tilde_d.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
    
  const int Zval_IN = Z_IN_calc (dagger_tilde_operator , Zval);
  const int Nval_IN = N_IN_calc (dagger_tilde_operator , Nval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();

  const int n_dagger_f = phi_dagger_f.get_n ();
  const int n_dagger_e = phi_dagger_e.get_n ();
  const int n_tilde_d  = phi_tilde_d.get_n ();
  
  const int l_dagger_f = phi_dagger_f.get_l ();
  const int l_dagger_e = phi_dagger_e.get_l ();
  const int l_tilde_d  = phi_tilde_d.get_l ();  
  
  const double j_dagger_f = phi_dagger_f.get_j ();
  const double m_dagger_f = phi_dagger_f.get_m ();
  
  const double j_dagger_e = phi_dagger_e.get_j ();
  const double m_dagger_e = phi_dagger_e.get_m ();
  
  const double j_tilde_d = phi_tilde_d.get_j ();
  const double m_tilde_d = phi_tilde_d.get_m ();
  
  const unsigned int phi_dagger_f_index = one_body_dagger_f_indices(n_dagger_f , l_dagger_f , j_dagger_f , m_dagger_f);
  const unsigned int phi_dagger_e_index = one_body_dagger_e_indices(n_dagger_e , l_dagger_e , j_dagger_e , m_dagger_e);
  const unsigned int phi_tilde_d_index  = one_body_tilde_d_indices (n_tilde_d  , l_tilde_d  , j_tilde_d  ,-m_tilde_d);
		      
  const bool are_phi_dagger_fe_different = (!particle_dagger_fe_same || (phi_dagger_f_index != phi_dagger_e_index));
 
  PSI_OUT_full = 0.0;
  
  if (!are_phi_dagger_fe_different) return;
	        
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
      
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (Zval_IN);
      inSDn_work_tab(i).allocate (Nval_IN);

      outSDp_work_tab(i).allocate (Zval);
      outSDn_work_tab(i).allocate (Nval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_out_work_tab(i).allocate (Zval);
      Cn_out_work_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);      
    }

  const class GSM_vector_helper_class &PSI_IN_helper = PSI_IN.get_GSM_vector_helper ();
  
  const unsigned int space_dimension_IN = PSI_IN_helper.get_space_dimension_process ();
        
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

      for (int p = 0 ; p < Zval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

      class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

      for (int n = 0 ; n < Nval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

      unsigned int bin_phase_p = 0;
      unsigned int bin_phase_n = 0;
      
      const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];
		
      const class Slater_determinant &inSD_dagger_f = SD_find (dagger_tilde_operator , 3 , inSDp , inSDn);
      const class Slater_determinant &inSD_dagger_e = SD_find (dagger_tilde_operator , 4 , inSDp , inSDn);
      const class Slater_determinant &inSD_tilde_d  = SD_find (dagger_tilde_operator , 5 , inSDp , inSDn);
	  
      const bool is_phi_tilde_d_in_inSD_tilde_d = inSD_tilde_d.is_valence_state_occupied (phi_tilde_d_index);

      if (is_phi_tilde_d_in_inSD_tilde_d)
	{
	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	      
	  if (Zval_IN == Zval) outSDp = inSDp;
	  if (Nval_IN == Nval) outSDn = inSDn;
	  
	  const bool is_phi_dagger_f_not_in_inSD_dagger_f = !inSD_dagger_f.is_valence_state_occupied (phi_dagger_f_index);
	  const bool is_phi_dagger_e_not_in_inSD_dagger_e = !inSD_dagger_e.is_valence_state_occupied (phi_dagger_e_index);

	  const bool no_dagger_fe_case = (is_phi_dagger_f_not_in_inSD_dagger_f && is_phi_dagger_e_not_in_inSD_dagger_e);

	  const bool are_phi_tilde_d_phi_dagger_f_equal = (particle_tilde_d_dagger_f_same && (phi_tilde_d_index == phi_dagger_f_index));
	  const bool are_phi_tilde_d_phi_dagger_e_equal = (particle_tilde_d_dagger_e_same && (phi_tilde_d_index == phi_dagger_e_index));

	  const bool phi_tilde_d_phi_dagger_f_equal_case = (are_phi_tilde_d_phi_dagger_f_equal && is_phi_dagger_e_not_in_inSD_dagger_e);
	  const bool phi_tilde_d_phi_dagger_e_equal_case = (are_phi_tilde_d_phi_dagger_e_equal && is_phi_dagger_f_not_in_inSD_dagger_f);				  

	  if (no_dagger_fe_case || phi_tilde_d_phi_dagger_f_equal_case || phi_tilde_d_phi_dagger_e_equal_case)
	    {
	      switch (dagger_tilde_operator)
		{ 
		case T2_2_RDM_PPP: inSDp.excitation_2p_1h_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , phi_tilde_d_index , outSDp , bin_phase_p); break;
		case T2_2_RDM_NNN: inSDn.excitation_2p_1h_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , phi_tilde_d_index , outSDn , bin_phase_n); break;
		  
		case T2_2_RDM_PPN:
		  {
		    inSDn.excitation_1h_and_bin_phase (phi_tilde_d_index , outSDn , bin_phase_n);
		    inSDp.excitation_2p_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , outSDp , bin_phase_p);
		  } break;
				      
		case T2_2_RDM_PNN:
		  {
		    inSDn.excitation_1p_1h_and_bin_phase (phi_dagger_e_index , phi_tilde_d_index , outSDn , bin_phase_n);
		    inSDp.excitation_1p_and_bin_phase (phi_dagger_f_index , outSDp , bin_phase_p);
		  } break;				  

		case T2_2_RDM_PNP:
		  {
		    inSDp.excitation_1p_1h_and_bin_phase (phi_dagger_f_index , phi_tilde_d_index , outSDp , bin_phase_p);
		    inSDn.excitation_1p_and_bin_phase (phi_dagger_e_index , outSDn , bin_phase_n);
		  } break;				  
				  
		case T2_2_RDM_NNP:
		  {
		    inSDp.excitation_1h_and_bin_phase (phi_tilde_d_index , outSDp , bin_phase_p);
		    inSDn.excitation_2p_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , outSDn , bin_phase_n);
		  } break;
				  
		default: abort_all ();
		}
					      
	      class configuration &Cp_out = Cp_out_work_tab(i_thread);
	      class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
	      Cp_out.get_SD_configuration (phi_p_table , outSDp);
	      Cn_out.get_SD_configuration (phi_n_table , outSDn);

	      const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_prot);
	      const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_neut);
			      
	      const int iMp_out = outSDp.iM_determine (phi_p_table);
	      const int iMn_out = outSDn.iM_determine (phi_n_table);

	      const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_prot);
	      const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_neut);
				  
	      const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_prot);
	      const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_neut); 

	      const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_prot);
	      const int En_out_hw = Cn_out.E_hw_determine (shells_qn_neut);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		    
	      class configuration &Cp_try = Cp_try_tab(i_thread);
	      class configuration &Cn_try = Cn_try_tab(i_thread);
					  
	      class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	      class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
	      const unsigned int iCp_out = Cp_out.index_search (BPp_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
	      const unsigned int iCn_out = Cn_out.index_search (BPn_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
					  
	      const unsigned int outSDp_index = outSDp.index_search (BPp_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
	      const unsigned int outSDn_index = outSDn.index_search (BPn_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);

	      const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

	      TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];

#ifdef UseOpenMP
#pragma omp critical
#endif
	      (bin_phase_p == bin_phase_n) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);
				    
	    }
	}
    }
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_OUT_full.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
#endif
  
}























void dagger_tilde_operators::a_dagger_a_tilde_a_tilde_MK_table_pn_calc (
									const enum dagger_tilde_operator_type dagger_tilde_operator , 
									const class nlj_struct &shell_dagger_a_qn , 
									const class nlj_struct &shell_tilde_b_qn , 
									const class nlj_struct &shell_tilde_c_qn , 
									const class correlated_state_str &PSI_IN_qn , 
									const class correlated_state_str &PSI_OUT_qn , 
									const class GSM_vector &PSI_OUT_full ,
									const class array<unsigned int> &inSDp_tab ,
									const class array<unsigned int> &inSDn_tab ,
									const class array<TYPE> &PSI_IN_component_tab ,
									const class array<bool> &is_inSDp_in_new_space_tab ,
									const class array<bool> &is_inSDn_in_new_space_tab ,
									const class array<unsigned char> &reordering_bin_phases_p ,
									const class array<unsigned char> &reordering_bin_phases_n ,
									class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data_dagger_a  = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
  const class nucleons_data &data_tilde_b   = data_find (dagger_tilde_operator , 1 , prot_data , neut_data);
  const class nucleons_data &data_tilde_c   = data_find (dagger_tilde_operator , 2 , prot_data , neut_data);
  
  const enum particle_type particle_dagger_a = data_dagger_a.get_particle ();

  const enum particle_type particle_tilde_b = data_tilde_b.get_particle ();
  const enum particle_type particle_tilde_c = data_tilde_c.get_particle ();

  const bool particle_dagger_a_tilde_b_same = (particle_dagger_a == particle_tilde_b);
  const bool particle_dagger_a_tilde_c_same = (particle_dagger_a == particle_tilde_c);

  const bool particle_dagger_a_tilde_bc_same = (particle_tilde_b == particle_tilde_c);

  const class one_body_indices_str &one_body_dagger_a_indices = data_dagger_a.get_one_body_indices ();

  const class one_body_indices_str &one_body_tilde_b_indices = data_tilde_b.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_c_indices = data_tilde_c.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
    
  const int Zval_IN = Z_IN_calc (dagger_tilde_operator , Zval);
  const int Nval_IN = N_IN_calc (dagger_tilde_operator , Nval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();
  
  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();

  const class lj_table<int> &nmax_lj_tab_p = prot_data.get_nmax_lj_tab ();
  const class lj_table<int> &nmax_lj_tab_n = neut_data.get_nmax_lj_tab ();

  const class nlj_table<bool> &is_it_valence_shell_tab_p = prot_data.get_is_it_valence_shell_tab ();
  const class nlj_table<bool> &is_it_valence_shell_tab_n = neut_data.get_is_it_valence_shell_tab ();
  
  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  
  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  
  const int n_tilde_b = shell_tilde_b_qn.get_n ();
  const int n_tilde_c = shell_tilde_c_qn.get_n ();
  
  const int l_tilde_b = shell_tilde_b_qn.get_l ();
  const int l_tilde_c = shell_tilde_c_qn.get_l ();
  
  const double j_tilde_b = shell_tilde_b_qn.get_j ();
  const double j_tilde_c = shell_tilde_c_qn.get_j ();
  
  const int m_tilde_b_number = shell_tilde_b_qn.m_number_determine ();
  const int m_tilde_c_number = shell_tilde_c_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
    
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_tilde_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (Zval_IN);
      inSDn_work_tab(i).allocate (Nval_IN);
      
      outSDp_work_tab(i).allocate (Zval);
      outSDn_work_tab(i).allocate (Nval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_out_work_tab(i).allocate (Zval);
      Cn_out_work_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);
      
      a_dagger_a_tilde_a_tilde_MK_tables(i).allocate (j_dagger_a , j_tilde_b , j_tilde_c);

      a_dagger_a_tilde_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
        
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class Slater_determinant &inSDp = inSDp_work_tab(i_thread);
      class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

      for (int p = 0 ; p < Zval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);
      for (int n = 0 ; n < Nval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

      if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tab_p , is_it_valence_shell_tab_p)) continue;
      if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tab_n , is_it_valence_shell_tab_n)) continue;

      const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
      const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
      
      const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

      const class Slater_determinant &inSD_dagger_a  = SD_find (dagger_tilde_operator , 0 , inSDp , inSDn);
      const class Slater_determinant &inSD_tilde_b   = SD_find (dagger_tilde_operator , 1 , inSDp , inSDn);
      const class Slater_determinant &inSD_tilde_c   = SD_find (dagger_tilde_operator , 2 , inSDp , inSDn);

      class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
      class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
      if (Zval_IN == Zval) outSDp = inSDp;
      if (Nval_IN == Nval) outSDn = inSDn;

      class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_a_tilde_MK_table = a_dagger_a_tilde_a_tilde_MK_tables(i_thread);
      
      for (int im_tilde_b = 0 ; im_tilde_b < m_tilde_b_number ; im_tilde_b++)
	{
	  const double m_tilde_b = im_tilde_b - j_tilde_b;
	  
	  for (int im_tilde_c = 0 ; im_tilde_c < m_tilde_c_number ; im_tilde_c++)
	    {
	      const double m_tilde_c = im_tilde_c - j_tilde_c;
		  
	      const double ML = m_tilde_b + m_tilde_c;

	      const double m_dagger_a = MK - ML;
	  
	      if (rint (abs (m_dagger_a) - j_dagger_a) <= 0.0)
		{	      
		  const unsigned int phi_dagger_a_index = one_body_dagger_a_indices(n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);

		  const unsigned int phi_tilde_b_index = one_body_tilde_b_indices(n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);
		  const unsigned int phi_tilde_c_index = one_body_tilde_c_indices(n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);

		  if ((phi_dagger_a_index != OUT_OF_RANGE) && (phi_tilde_b_index != OUT_OF_RANGE) && (phi_tilde_c_index != OUT_OF_RANGE))
		    {
		      const bool is_phi_tilde_b_in_inSD_tilde_b = inSD_tilde_b.is_valence_state_occupied (phi_tilde_b_index);
		      const bool is_phi_tilde_c_in_inSD_tilde_c = inSD_tilde_c.is_valence_state_occupied (phi_tilde_c_index);

		      const bool are_phi_tilde_bc_different = (!particle_dagger_a_tilde_bc_same || (phi_tilde_b_index != phi_tilde_c_index));

		      if (are_phi_tilde_bc_different && is_phi_tilde_b_in_inSD_tilde_b && is_phi_tilde_c_in_inSD_tilde_c)
			{
			  const bool is_phi_dagger_a_in_inSD_dagger_a = inSD_dagger_a.is_valence_state_occupied (phi_dagger_a_index);

			  const bool no_phi_dagger_a_case = !is_phi_dagger_a_in_inSD_dagger_a;

			  const bool are_phi_dagger_a_phi_tilde_b_equal = (particle_dagger_a_tilde_b_same && (phi_dagger_a_index == phi_tilde_b_index));
			  const bool are_phi_dagger_a_phi_tilde_c_equal = (particle_dagger_a_tilde_c_same && (phi_dagger_a_index == phi_tilde_c_index));

			  const bool phi_dagger_a_phi_tilde_b_equal_case = (are_phi_dagger_a_phi_tilde_b_equal && is_phi_dagger_a_in_inSD_dagger_a);
			  const bool phi_dagger_a_phi_tilde_c_equal_case = (are_phi_dagger_a_phi_tilde_c_equal && is_phi_dagger_a_in_inSD_dagger_a);

			  if (no_phi_dagger_a_case || phi_dagger_a_phi_tilde_b_equal_case || phi_dagger_a_phi_tilde_c_equal_case)
			    {
			      unsigned int bin_phase_p = reordering_bin_phase_p;
			      unsigned int bin_phase_n = reordering_bin_phase_n;
			  
			      switch (dagger_tilde_operator)
				{ 
				case A_DAGGER_A_TILDE_A_TILDE_PPP: inSDp.excitation_1p_2h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , phi_tilde_c_index , outSDp , bin_phase_p); break;
				case A_DAGGER_A_TILDE_A_TILDE_NNN: inSDn.excitation_1p_2h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , phi_tilde_c_index , outSDn , bin_phase_n); break;
				    
				case A_DAGGER_A_TILDE_A_TILDE_PPN:
				  {
				    inSDp.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , outSDp , bin_phase_p);
				    inSDn.excitation_1h_and_bin_phase (phi_tilde_c_index , outSDn , bin_phase_n);
				  } break;
				      
				case A_DAGGER_A_TILDE_A_TILDE_NPP:
				  {
				    inSDn.excitation_1p_and_bin_phase (phi_dagger_a_index , outSDn , bin_phase_n);
				    inSDp.excitation_2h_and_bin_phase (phi_tilde_b_index , phi_tilde_c_index , outSDp , bin_phase_p);
				  } break;
				  
				case A_DAGGER_A_TILDE_A_TILDE_PNN:
				  {
				    inSDp.excitation_1p_and_bin_phase (phi_dagger_a_index , outSDp , bin_phase_p);
				    inSDn.excitation_2h_and_bin_phase (phi_tilde_b_index , phi_tilde_c_index , outSDn , bin_phase_n);
				  } break;
				      
				case A_DAGGER_A_TILDE_A_TILDE_NPN:
				  {
				    inSDn.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_c_index , outSDn , bin_phase_n);
				    inSDp.excitation_1h_and_bin_phase (phi_tilde_b_index , outSDp , bin_phase_p);
				  } break;				  				
				  				  
				default: abort_all ();
				}

			      class configuration &Cp_out = Cp_out_work_tab(i_thread);
			      class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
			      Cp_out.get_SD_configuration (phi_p_table , outSDp);
			      Cn_out.get_SD_configuration (phi_n_table , outSDn);

			      const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_prot);
			      const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_neut);
			      
			      const int iMp_out = outSDp.iM_determine (phi_p_table);
			      const int iMn_out = outSDn.iM_determine (phi_n_table);

			      const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_prot);
			      const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_neut);
				  
			      const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_prot);
			      const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_neut);
			      
			      const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_prot);
			      const int En_out_hw = Cn_out.E_hw_determine (shells_qn_neut);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				    
			      class configuration &Cp_try = Cp_try_tab(i_thread);
			      class configuration &Cn_try = Cn_try_tab(i_thread);

			      class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
			      class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
			      const unsigned int iCp_out = Cp_out.index_search (BPp_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
			      const unsigned int iCn_out = Cn_out.index_search (BPn_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				      
			      const unsigned int outSDp_index = outSDp.index_search (BPp_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
			      const unsigned int outSDn_index = outSDn.index_search (BPn_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

			      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
				      
			      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);

			      const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

			      const TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];

			      (bin_phase_p == bin_phase_n)
				? (a_dagger_a_tilde_a_tilde_MK_table(m_dagger_a , m_tilde_b , m_tilde_c) += PSI_IN_component*PSI_OUT_component)
				: (a_dagger_a_tilde_a_tilde_MK_table(m_dagger_a , m_tilde_b , m_tilde_c) -= PSI_IN_component*PSI_OUT_component);

			    }}}}}}}

  a_dagger_a_tilde_a_tilde_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_tilde_a_tilde_MK_table += a_dagger_a_tilde_a_tilde_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_tilde_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}












void dagger_tilde_operators::a_dagger_a_tilde_a_tilde_MK_RDM_pn_calc (
								      const enum dagger_tilde_operator_type dagger_tilde_operator ,
								      const class nljm_struct &phi_dagger_f , 
								      const class nljm_struct &phi_tilde_e , 
								      const class nljm_struct &phi_tilde_d ,
								      const class array<unsigned int> &inSDp_tab ,
								      const class array<unsigned int> &inSDn_tab ,
								      const class GSM_vector &PSI_IN ,
								      class GSM_vector &PSI_OUT_full)
{
  if (!is_it_RDM_determine (dagger_tilde_operator)) error_message_print_abort ("RDM operators only in dagger_tilde_operators::a_dagger_a_tilde_a_tilde_MK_RDM_pn_calc");
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data_dagger_f  = data_find (dagger_tilde_operator , 3 , prot_data , neut_data);
  const class nucleons_data &data_tilde_e   = data_find (dagger_tilde_operator , 4 , prot_data , neut_data);
  const class nucleons_data &data_tilde_d   = data_find (dagger_tilde_operator , 5 , prot_data , neut_data);
  
  const enum particle_type particle_dagger_f = data_dagger_f.get_particle ();

  const enum particle_type particle_tilde_e = data_tilde_e.get_particle ();
  const enum particle_type particle_tilde_d = data_tilde_d.get_particle ();

  const bool particle_dagger_f_tilde_e_same = (particle_dagger_f == particle_tilde_e);
  const bool particle_dagger_f_tilde_d_same = (particle_dagger_f == particle_tilde_d);

  const bool particle_tilde_ed_same = (particle_tilde_e == particle_tilde_d);

  const class one_body_indices_str &one_body_dagger_f_indices = data_dagger_f.get_one_body_indices ();

  const class one_body_indices_str &one_body_tilde_e_indices = data_tilde_e.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_d_indices = data_tilde_d.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
    
  const int Zval_IN = Z_IN_calc (dagger_tilde_operator , Zval);
  const int Nval_IN = N_IN_calc (dagger_tilde_operator , Nval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();
  
  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();
    
  const int n_dagger_f = phi_dagger_f.get_n ();
  const int n_tilde_e  = phi_tilde_e.get_n ();
  const int n_tilde_d  = phi_tilde_d.get_n ();
  
  const int l_dagger_f = phi_dagger_f.get_l ();
  const int l_tilde_e  = phi_tilde_e.get_l ();
  const int l_tilde_d  = phi_tilde_d.get_l ();
  
  const double j_dagger_f = phi_dagger_f.get_j ();
  const double m_dagger_f = phi_dagger_f.get_m ();
  
  const double j_tilde_e  = phi_tilde_e.get_j ();
  const double m_tilde_e  = phi_tilde_e.get_m ();
  
  const double j_tilde_d  = phi_tilde_d.get_j ();
  const double m_tilde_d  = phi_tilde_d.get_m ();

  const unsigned int phi_dagger_f_index = one_body_dagger_f_indices(n_dagger_f , l_dagger_f , j_dagger_f ,  m_dagger_f);
  const unsigned int phi_tilde_e_index  = one_body_tilde_e_indices (n_tilde_e  , l_tilde_e  , j_tilde_e  , -m_tilde_e);
  const unsigned int phi_tilde_d_index  = one_body_tilde_d_indices (n_tilde_d  , l_tilde_d  , j_tilde_d  , -m_tilde_d);
		      
  const bool are_phi_tilde_ed_different = (!particle_tilde_ed_same || (phi_tilde_e_index != phi_tilde_d_index));

  PSI_OUT_full = 0.0;
  
  if (!are_phi_tilde_ed_different) return;			    
  
  const bool are_phi_dagger_f_phi_tilde_e_equal = (particle_dagger_f_tilde_e_same && (phi_dagger_f_index == phi_tilde_e_index));
  const bool are_phi_dagger_f_phi_tilde_d_equal = (particle_dagger_f_tilde_d_same && (phi_dagger_f_index == phi_tilde_d_index));
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
    
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (Zval_IN);
      inSDn_work_tab(i).allocate (Nval_IN);
      
      outSDp_work_tab(i).allocate (Zval);
      outSDn_work_tab(i).allocate (Nval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_out_work_tab(i).allocate (Zval);
      Cn_out_work_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);      
    }

  const class GSM_vector_helper_class &PSI_IN_helper = PSI_IN.get_GSM_vector_helper ();
  
  const unsigned int space_dimension_IN = PSI_IN_helper.get_space_dimension_process ();
            
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class Slater_determinant &inSDp = inSDp_work_tab(i_thread);
      class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

      for (int p = 0 ; p < Zval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);
      for (int n = 0 ; n < Nval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

      unsigned int bin_phase_p = 0;
      unsigned int bin_phase_n = 0;
      
      const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];
      
      const class Slater_determinant &inSD_dagger_f  = SD_find (dagger_tilde_operator , 3 , inSDp , inSDn);
      const class Slater_determinant &inSD_tilde_e   = SD_find (dagger_tilde_operator , 4 , inSDp , inSDn);
      const class Slater_determinant &inSD_tilde_d   = SD_find (dagger_tilde_operator , 5 , inSDp , inSDn);

      const bool is_phi_tilde_e_in_inSD_tilde_e = inSD_tilde_e.is_valence_state_occupied (phi_tilde_e_index);
      const bool is_phi_tilde_d_in_inSD_tilde_d = inSD_tilde_d.is_valence_state_occupied (phi_tilde_d_index);

      if (is_phi_tilde_e_in_inSD_tilde_e && is_phi_tilde_d_in_inSD_tilde_d)
	{
	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	  if (Zval_IN == Zval) outSDp = inSDp;
	  if (Nval_IN == Nval) outSDn = inSDn;
	  
	  const bool is_phi_dagger_f_in_inSD_dagger_f = inSD_dagger_f.is_valence_state_occupied (phi_dagger_f_index);

	  const bool no_phi_dagger_f_case = !is_phi_dagger_f_in_inSD_dagger_f;
	      
	  const bool phi_dagger_f_phi_tilde_e_equal_case = (are_phi_dagger_f_phi_tilde_e_equal && is_phi_dagger_f_in_inSD_dagger_f);
	  const bool phi_dagger_f_phi_tilde_d_equal_case = (are_phi_dagger_f_phi_tilde_d_equal && is_phi_dagger_f_in_inSD_dagger_f);

	  if (no_phi_dagger_f_case || phi_dagger_f_phi_tilde_e_equal_case || phi_dagger_f_phi_tilde_d_equal_case)
	    {
	      switch (dagger_tilde_operator)
		{ 
		case T2_1_RDM_PPP: inSDp.excitation_1p_2h_and_bin_phase (phi_dagger_f_index , phi_tilde_e_index , phi_tilde_d_index , outSDp , bin_phase_p); break;
		case T2_1_RDM_NNN: inSDn.excitation_1p_2h_and_bin_phase (phi_dagger_f_index , phi_tilde_e_index , phi_tilde_d_index , outSDn , bin_phase_n); break;				    
				      
		case T2_1_RDM_PPN:
		  {
		    inSDn.excitation_1p_and_bin_phase (phi_dagger_f_index , outSDn , bin_phase_n);
		    inSDp.excitation_2h_and_bin_phase (phi_tilde_e_index , phi_tilde_d_index , outSDp , bin_phase_p);
		  } break;
				  
		case T2_1_RDM_NNP:
		  {
		    inSDp.excitation_1p_and_bin_phase (phi_dagger_f_index , outSDp , bin_phase_p);
		    inSDn.excitation_2h_and_bin_phase (phi_tilde_e_index , phi_tilde_d_index , outSDn , bin_phase_n);
		  } break;
				      
		case T2_1_RDM_PNN:
		  {
		    inSDn.excitation_1p_1h_and_bin_phase (phi_dagger_f_index , phi_tilde_e_index , outSDn , bin_phase_n);
		    inSDp.excitation_1h_and_bin_phase (phi_tilde_d_index , outSDp , bin_phase_p);
		  } break;				  				
				  
		case T2_1_RDM_PNP:
		  {
		    inSDp.excitation_1p_1h_and_bin_phase (phi_dagger_f_index , phi_tilde_d_index , outSDp , bin_phase_p);
		    inSDn.excitation_1h_and_bin_phase (phi_tilde_e_index , outSDn , bin_phase_n);
		  } break;
		      
		default: abort_all ();
		}

	      class configuration &Cp_out = Cp_out_work_tab(i_thread);
	      class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
	      Cp_out.get_SD_configuration (phi_p_table , outSDp);
	      Cn_out.get_SD_configuration (phi_n_table , outSDn);

	      const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_prot);
	      const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_neut);
			      
	      const int iMp_out = outSDp.iM_determine (phi_p_table);
	      const int iMn_out = outSDn.iM_determine (phi_n_table);

	      const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_prot);
	      const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_neut);
				  
	      const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_prot);
	      const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_neut);
			      
	      const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_prot);
	      const int En_out_hw = Cn_out.E_hw_determine (shells_qn_neut);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		    
	      class configuration &Cp_try = Cp_try_tab(i_thread);
	      class configuration &Cn_try = Cn_try_tab(i_thread);

	      class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	      class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
	      const unsigned int iCp_out = Cp_out.index_search (BPp_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
	      const unsigned int iCn_out = Cn_out.index_search (BPn_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				      
	      const unsigned int outSDp_index = outSDp.index_search (BPp_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
	      const unsigned int outSDn_index = outSDn.index_search (BPn_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
				      
	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);

	      const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

	      TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];

#ifdef UseOpenMP
#pragma omp critical
#endif
	      (bin_phase_p == bin_phase_n) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);
				    
	    }
	}
    }
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_OUT_full.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
#endif
  
}



















void dagger_tilde_operators::a_dagger_a_dagger_a_dagger_MK_table_pn_calc (
									  const enum dagger_tilde_operator_type dagger_tilde_operator , 
									  const class nlj_struct &shell_dagger_a_qn , 
									  const class nlj_struct &shell_dagger_b_qn , 
									  const class nlj_struct &shell_dagger_c_qn , 
									  const class correlated_state_str &PSI_IN_qn , 
									  const class correlated_state_str &PSI_OUT_qn , 
									  const class GSM_vector &PSI_OUT_full ,
									  const class array<unsigned int> &inSDp_tab ,
									  const class array<unsigned int> &inSDn_tab ,
									  const class array<TYPE> &PSI_IN_component_tab ,
									  const class array<bool> &is_inSDp_in_new_space_tab ,
									  const class array<bool> &is_inSDn_in_new_space_tab ,
									  const class array<unsigned char> &reordering_bin_phases_p ,
									  const class array<unsigned char> &reordering_bin_phases_n ,
									  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_dagger_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const class nucleons_data &data_dagger_a = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
  const class nucleons_data &data_dagger_b = data_find (dagger_tilde_operator , 1 , prot_data , neut_data); 
  const class nucleons_data &data_dagger_c = data_find (dagger_tilde_operator , 2 , prot_data , neut_data);
    
  const enum particle_type particle_dagger_a = data_dagger_a.get_particle ();
  const enum particle_type particle_dagger_b = data_dagger_b.get_particle ();
  const enum particle_type particle_dagger_c = data_dagger_c.get_particle ();

  const bool particle_dagger_ab_same = (particle_dagger_a == particle_dagger_b);
  const bool particle_dagger_ac_same = (particle_dagger_a == particle_dagger_c);
  const bool particle_dagger_bc_same = (particle_dagger_b == particle_dagger_c);

  const class one_body_indices_str &one_body_dagger_a_indices = data_dagger_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_b_indices = data_dagger_b.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_c_indices = data_dagger_c.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
    
  const int Zval_IN = Z_IN_calc (dagger_tilde_operator , Zval);
  const int Nval_IN = N_IN_calc (dagger_tilde_operator , Nval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();

  const class lj_table<int> &nmax_lj_tab_p = prot_data.get_nmax_lj_tab ();
  const class lj_table<int> &nmax_lj_tab_n = neut_data.get_nmax_lj_tab ();

  const class nlj_table<bool> &is_it_valence_shell_tab_p = prot_data.get_is_it_valence_shell_tab ();
  const class nlj_table<bool> &is_it_valence_shell_tab_n = neut_data.get_is_it_valence_shell_tab ();
  
  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int n_dagger_b = shell_dagger_b_qn.get_n ();
  const int n_dagger_c = shell_dagger_c_qn.get_n ();
  
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  const int l_dagger_b = shell_dagger_b_qn.get_l ();  
  const int l_dagger_c = shell_dagger_c_qn.get_l ();  
  
  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_dagger_b = shell_dagger_b_qn.get_j ();
  const double j_dagger_c = shell_dagger_c_qn.get_j ();
  
  const int m_dagger_a_number = shell_dagger_a_qn.m_number_determine ();
  const int m_dagger_b_number = shell_dagger_b_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
      
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_dagger_a_dagger_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (Zval_IN);
      inSDn_work_tab(i).allocate (Nval_IN);

      outSDp_work_tab(i).allocate (Zval);
      outSDn_work_tab(i).allocate (Nval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_out_work_tab(i).allocate (Zval);
      Cn_out_work_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);
      
      a_dagger_a_dagger_a_dagger_MK_tables(i).allocate (j_dagger_a , j_dagger_b , j_dagger_c);

      a_dagger_a_dagger_a_dagger_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

      for (int p = 0 ; p < Zval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

      if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tab_p , is_it_valence_shell_tab_p)) continue;

      class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

      for (int n = 0 ; n < Nval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

      if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tab_n , is_it_valence_shell_tab_n)) continue;

      const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
      const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
      
      const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);
      
      const class Slater_determinant &inSD_dagger_a = SD_find (dagger_tilde_operator , 0 , inSDp , inSDn);
      const class Slater_determinant &inSD_dagger_b = SD_find (dagger_tilde_operator , 1 , inSDp , inSDn);
      const class Slater_determinant &inSD_dagger_c = SD_find (dagger_tilde_operator , 2 , inSDp , inSDn);

      class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
      class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
      if (Zval_IN == Zval) outSDp = inSDp;
      if (Nval_IN == Nval) outSDn = inSDn;

      class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_dagger_MK_table = a_dagger_a_dagger_a_dagger_MK_tables(i_thread);

      for (int im_dagger_a = 0 ; im_dagger_a < m_dagger_a_number ; im_dagger_a++)
	{
	  const double m_dagger_a = im_dagger_a - j_dagger_a;
	  
	  for (int im_dagger_b = 0 ; im_dagger_b < m_dagger_b_number ; im_dagger_b++)
	    {
	      const double m_dagger_b = im_dagger_b - j_dagger_b;
		  
	      const double ML = m_dagger_a + m_dagger_b;

	      const double m_dagger_c = MK - ML;
	  
	      if (rint (abs (m_dagger_c) - j_dagger_c) <= 0.0)
		{
		  const unsigned int phi_dagger_a_index = one_body_dagger_a_indices(n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
		  const unsigned int phi_dagger_b_index = one_body_dagger_b_indices(n_dagger_b , l_dagger_b , j_dagger_b , m_dagger_b);
		  const unsigned int phi_dagger_c_index = one_body_dagger_c_indices(n_dagger_c , l_dagger_c , j_dagger_c , m_dagger_c);

		  if ((phi_dagger_a_index != OUT_OF_RANGE) && (phi_dagger_b_index != OUT_OF_RANGE) && (phi_dagger_c_index != OUT_OF_RANGE))
		    {
		      const bool are_phi_dagger_ab_different = (!particle_dagger_ab_same || (phi_dagger_a_index != phi_dagger_b_index));
		      const bool are_phi_dagger_ac_different = (!particle_dagger_ac_same || (phi_dagger_a_index != phi_dagger_c_index));
		      const bool are_phi_dagger_bc_different = (!particle_dagger_bc_same || (phi_dagger_b_index != phi_dagger_c_index));

		      if (are_phi_dagger_ab_different && are_phi_dagger_ac_different && are_phi_dagger_bc_different)
			{
			  if (!inSD_dagger_a.is_valence_state_occupied (phi_dagger_a_index) &&
			      !inSD_dagger_b.is_valence_state_occupied (phi_dagger_b_index) &&
			      !inSD_dagger_c.is_valence_state_occupied (phi_dagger_c_index))
			    {
			      unsigned int bin_phase_p = reordering_bin_phase_p;
			      unsigned int bin_phase_n = reordering_bin_phase_n;
			  
			      switch (dagger_tilde_operator)
				{ 
				case A_DAGGER_A_DAGGER_A_DAGGER_PPP: inSDp.excitation_3p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , phi_dagger_c_index , outSDp , bin_phase_p); break;
				case A_DAGGER_A_DAGGER_A_DAGGER_NNN: inSDn.excitation_3p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , phi_dagger_c_index , outSDn , bin_phase_n); break;
				  
				case A_DAGGER_A_DAGGER_A_DAGGER_PPN:
				  {
				    inSDp.excitation_2p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , outSDp , bin_phase_p);
				    inSDn.excitation_1p_and_bin_phase (phi_dagger_c_index , outSDn , bin_phase_n);
				  } break;
				  				  
				case A_DAGGER_A_DAGGER_A_DAGGER_NNP:
				  {
				    inSDn.excitation_2p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , outSDn , bin_phase_n);
				    inSDp.excitation_1p_and_bin_phase (phi_dagger_c_index , outSDp , bin_phase_p);
				  } break;
				  				  
				default: abort_all ();
				}
									
			      class configuration &Cp_out = Cp_out_work_tab(i_thread);
			      class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
			      Cp_out.get_SD_configuration (phi_p_table , outSDp);
			      Cn_out.get_SD_configuration (phi_n_table , outSDn);

			      const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_prot);
			      const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_neut);
			      
			      const int iMp_out = outSDp.iM_determine (phi_p_table);
			      const int iMn_out = outSDn.iM_determine (phi_n_table);

			      const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_prot);
			      const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_neut);
				  
			      const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_prot);
			      const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_neut); 

			      const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_prot);
			      const int En_out_hw = Cn_out.E_hw_determine (shells_qn_neut);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				    
			      class configuration &Cp_try = Cp_try_tab(i_thread);
			      class configuration &Cn_try = Cn_try_tab(i_thread);
					  
			      class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
			      class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
			      const unsigned int iCp_out = Cp_out.index_search (BPp_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
			      const unsigned int iCn_out = Cn_out.index_search (BPn_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				      
			      const unsigned int outSDp_index = outSDp.index_search (BPp_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
			      const unsigned int outSDn_index = outSDn.index_search (BPn_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

			      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

			      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);

			      const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

			      const TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];

			      (bin_phase_p == bin_phase_n)
				? (a_dagger_a_dagger_a_dagger_MK_table(m_dagger_a , m_dagger_b , m_dagger_c) += PSI_IN_component*PSI_OUT_component) 
				: (a_dagger_a_dagger_a_dagger_MK_table(m_dagger_a , m_dagger_b , m_dagger_c) -= PSI_IN_component*PSI_OUT_component);
					  
			    }}}}}}}
  
  a_dagger_a_dagger_a_dagger_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_dagger_a_dagger_MK_table += a_dagger_a_dagger_a_dagger_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_dagger_a_dagger_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}












void dagger_tilde_operators::a_dagger_a_dagger_a_dagger_MK_RDM_pn_calc (
									const enum dagger_tilde_operator_type dagger_tilde_operator ,
									const class nljm_struct &phi_dagger_f , 
									const class nljm_struct &phi_dagger_e ,
									const class nljm_struct &phi_dagger_d ,  
									const class array<unsigned int> &inSDp_tab ,
									const class array<unsigned int> &inSDn_tab ,
									const class GSM_vector &PSI_IN ,
									class GSM_vector &PSI_OUT_full)
{  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const class nucleons_data &data_dagger_f = data_find (dagger_tilde_operator , 3 , prot_data , neut_data);
  const class nucleons_data &data_dagger_e = data_find (dagger_tilde_operator , 4 , prot_data , neut_data); 
  const class nucleons_data &data_dagger_d = data_find (dagger_tilde_operator , 5 , prot_data , neut_data);
    
  const enum particle_type particle_dagger_f = data_dagger_f.get_particle ();
  const enum particle_type particle_dagger_e = data_dagger_e.get_particle ();
  const enum particle_type particle_dagger_d = data_dagger_d.get_particle ();

  const bool particle_dagger_fe_same = (particle_dagger_f == particle_dagger_e);
  const bool particle_dagger_fd_same = (particle_dagger_f == particle_dagger_d);
  const bool particle_dagger_ed_same = (particle_dagger_e == particle_dagger_d);

  const class one_body_indices_str &one_body_dagger_f_indices = data_dagger_f.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_e_indices = data_dagger_e.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_d_indices = data_dagger_d.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
    
  const int Zval_IN = Z_IN_calc (dagger_tilde_operator , Zval);
  const int Nval_IN = N_IN_calc (dagger_tilde_operator , Nval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();
  
  const int n_dagger_f = phi_dagger_f.get_n ();
  const int n_dagger_e = phi_dagger_e.get_n ();
  const int n_dagger_d = phi_dagger_d.get_n ();
  
  const int l_dagger_f = phi_dagger_f.get_l ();
  const int l_dagger_e = phi_dagger_e.get_l ();  
  const int l_dagger_d = phi_dagger_d.get_l ();  
  
  const double j_dagger_f = phi_dagger_f.get_j ();
  const double m_dagger_f = phi_dagger_f.get_m ();
  
  const double j_dagger_e = phi_dagger_e.get_j ();
  const double m_dagger_e = phi_dagger_e.get_m ();
  
  const double j_dagger_d = phi_dagger_d.get_j ();
  const double m_dagger_d = phi_dagger_d.get_m ();

  const unsigned int phi_dagger_f_index = one_body_dagger_f_indices(n_dagger_f , l_dagger_f , j_dagger_f , m_dagger_f);
  const unsigned int phi_dagger_e_index = one_body_dagger_e_indices(n_dagger_e , l_dagger_e , j_dagger_e , m_dagger_e);
  const unsigned int phi_dagger_d_index = one_body_dagger_d_indices(n_dagger_d , l_dagger_d , j_dagger_d , m_dagger_d);
		      
  const bool are_phi_dagger_fe_different = (!particle_dagger_fe_same || (phi_dagger_f_index != phi_dagger_e_index));
  const bool are_phi_dagger_fd_different = (!particle_dagger_fd_same || (phi_dagger_f_index != phi_dagger_d_index));
  const bool are_phi_dagger_ed_different = (!particle_dagger_ed_same || (phi_dagger_e_index != phi_dagger_d_index));

  PSI_OUT_full = 0.0;
  
  if (!are_phi_dagger_fe_different || !are_phi_dagger_fd_different || !are_phi_dagger_ed_different) return;
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
      
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (Zval_IN);
      inSDn_work_tab(i).allocate (Nval_IN);

      outSDp_work_tab(i).allocate (Zval);
      outSDn_work_tab(i).allocate (Nval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_out_work_tab(i).allocate (Zval);
      Cn_out_work_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);      
    }

  const class GSM_vector_helper_class &PSI_IN_helper = PSI_IN.get_GSM_vector_helper ();
  
  const unsigned int space_dimension_IN = PSI_IN_helper.get_space_dimension_process ();    
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

      for (int p = 0 ; p < Zval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

      class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

      for (int n = 0 ; n < Nval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

      unsigned int bin_phase_p = 0;
      unsigned int bin_phase_n = 0;
      
      const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];
      
      const class Slater_determinant &inSD_dagger_f = SD_find (dagger_tilde_operator , 3 , inSDp , inSDn);
      const class Slater_determinant &inSD_dagger_e = SD_find (dagger_tilde_operator , 4 , inSDp , inSDn);
      const class Slater_determinant &inSD_dagger_d = SD_find (dagger_tilde_operator , 5 , inSDp , inSDn);

      if (!inSD_dagger_f.is_valence_state_occupied (phi_dagger_f_index) &&
	  !inSD_dagger_e.is_valence_state_occupied (phi_dagger_e_index) &&
	  !inSD_dagger_d.is_valence_state_occupied (phi_dagger_d_index))
	{
	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	  if (Zval_IN == Zval) outSDp = inSDp;
	  if (Nval_IN == Nval) outSDn = inSDn;
	  
	  switch (dagger_tilde_operator)
	    { 
	    case T1_2_RDM_PPP: inSDp.excitation_3p_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , phi_dagger_d_index , outSDp , bin_phase_p); break;
	    case T1_2_RDM_NNN: inSDn.excitation_3p_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , phi_dagger_d_index , outSDn , bin_phase_n); break;
				  
	    case T1_2_RDM_PPN:
	      {
		inSDp.excitation_2p_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , outSDp , bin_phase_p);
		inSDn.excitation_1p_and_bin_phase (phi_dagger_d_index , outSDn , bin_phase_n);
	      } break;
				  				  
	    case T1_2_RDM_NNP:
	      {
		inSDn.excitation_2p_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , outSDn , bin_phase_n);
		inSDp.excitation_1p_and_bin_phase (phi_dagger_d_index , outSDp , bin_phase_p);
	      } break;
				  
	    default: abort_all ();
	    }
								
	  class configuration &Cp_out = Cp_out_work_tab(i_thread);
	  class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
	  Cp_out.get_SD_configuration (phi_p_table , outSDp);
	  Cn_out.get_SD_configuration (phi_n_table , outSDn);

	  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_prot);
	  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_neut);
			      
	  const int iMp_out = outSDp.iM_determine (phi_p_table);
	  const int iMn_out = outSDn.iM_determine (phi_n_table);

	  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_prot);
	  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_neut);
				  
	  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_prot);
	  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_neut); 

	  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_prot);
	  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_neut);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
	  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	  class configuration &Cp_try = Cp_try_tab(i_thread);
	  class configuration &Cn_try = Cn_try_tab(i_thread);
					  
	  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
	  const unsigned int iCp_out = Cp_out.index_search (BPp_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
	  const unsigned int iCn_out = Cn_out.index_search (BPn_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				      
	  const unsigned int outSDp_index = outSDp.index_search (BPp_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
	  const unsigned int outSDn_index = outSDn.index_search (BPn_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

	  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

	  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);

	  const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

	  TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];

#ifdef UseOpenMP
#pragma omp critical
#endif
	  (bin_phase_p == bin_phase_n) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);
				    
	}
    }
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_OUT_full.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
#endif
  
}

















void dagger_tilde_operators::a_tilde_a_tilde_a_tilde_MK_table_pn_calc (
								       const enum dagger_tilde_operator_type dagger_tilde_operator , 
								       const class nlj_struct &shell_tilde_a_qn , 
								       const class nlj_struct &shell_tilde_b_qn , 
								       const class nlj_struct &shell_tilde_c_qn , 
								       const class correlated_state_str &PSI_IN_qn , 
								       const class correlated_state_str &PSI_OUT_qn , 
								       const class GSM_vector &PSI_OUT_full ,
								       const class array<unsigned int> &inSDp_tab ,
								       const class array<unsigned int> &inSDn_tab ,
								       const class array<TYPE> &PSI_IN_component_tab ,
								       const class array<bool> &is_inSDp_in_new_space_tab ,
								       const class array<bool> &is_inSDn_in_new_space_tab ,
								       const class array<unsigned char> &reordering_bin_phases_p ,
								       const class array<unsigned char> &reordering_bin_phases_n ,
								       class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const class nucleons_data &data_tilde_a = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
  const class nucleons_data &data_tilde_b = data_find (dagger_tilde_operator , 1 , prot_data , neut_data); 
  const class nucleons_data &data_tilde_c = data_find (dagger_tilde_operator , 2 , prot_data , neut_data);
    
  const enum particle_type particle_tilde_a = data_tilde_a.get_particle ();
  const enum particle_type particle_tilde_b = data_tilde_b.get_particle ();
  const enum particle_type particle_tilde_c = data_tilde_c.get_particle ();

  const bool particle_tilde_ab_same = (particle_tilde_a == particle_tilde_b);
  const bool particle_tilde_ac_same = (particle_tilde_a == particle_tilde_c);
  const bool particle_tilde_bc_same = (particle_tilde_b == particle_tilde_c);

  const class one_body_indices_str &one_body_tilde_a_indices = data_tilde_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_b_indices = data_tilde_b.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_c_indices = data_tilde_c.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
    
  const int Zval_IN = Z_IN_calc (dagger_tilde_operator , Zval);
  const int Nval_IN = N_IN_calc (dagger_tilde_operator , Nval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();

  const class lj_table<int> &nmax_lj_tab_p = prot_data.get_nmax_lj_tab ();
  const class lj_table<int> &nmax_lj_tab_n = neut_data.get_nmax_lj_tab ();

  const class nlj_table<bool> &is_it_valence_shell_tab_p = prot_data.get_is_it_valence_shell_tab ();
  const class nlj_table<bool> &is_it_valence_shell_tab_n = neut_data.get_is_it_valence_shell_tab ();
  
  const int n_tilde_a = shell_tilde_a_qn.get_n ();
  const int n_tilde_b = shell_tilde_b_qn.get_n ();
  const int n_tilde_c = shell_tilde_c_qn.get_n ();
  
  const int l_tilde_a = shell_tilde_a_qn.get_l ();
  const int l_tilde_b = shell_tilde_b_qn.get_l ();  
  const int l_tilde_c = shell_tilde_c_qn.get_l ();  
  
  const double j_tilde_a = shell_tilde_a_qn.get_j ();
  const double j_tilde_b = shell_tilde_b_qn.get_j ();
  const double j_tilde_c = shell_tilde_c_qn.get_j ();
  
  const int m_tilde_a_number = shell_tilde_a_qn.m_number_determine ();
  const int m_tilde_b_number = shell_tilde_b_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
      
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_tilde_a_tilde_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (Zval_IN);
      inSDn_work_tab(i).allocate (Nval_IN);

      outSDp_work_tab(i).allocate (Zval);
      outSDn_work_tab(i).allocate (Nval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_out_work_tab(i).allocate (Zval);
      Cn_out_work_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);
      
      a_tilde_a_tilde_a_tilde_MK_tables(i).allocate (j_tilde_a , j_tilde_b , j_tilde_c);

      a_tilde_a_tilde_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

      for (int p = 0 ; p < Zval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

      if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tab_p , is_it_valence_shell_tab_p)) continue;

      class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

      for (int n = 0 ; n < Nval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

      if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tab_n , is_it_valence_shell_tab_n)) continue;

      const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
      const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
      
      const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);
      
      const class Slater_determinant &inSD_tilde_a = SD_find (dagger_tilde_operator , 0 , inSDp , inSDn);
      const class Slater_determinant &inSD_tilde_b = SD_find (dagger_tilde_operator , 1 , inSDp , inSDn);
      const class Slater_determinant &inSD_tilde_c = SD_find (dagger_tilde_operator , 2 , inSDp , inSDn);

      class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
      class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
      if (Zval_IN == Zval) outSDp = inSDp;
      if (Nval_IN == Nval) outSDn = inSDn;

      class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_a_tilde_MK_table = a_tilde_a_tilde_a_tilde_MK_tables(i_thread);

      for (int im_tilde_a = 0 ; im_tilde_a < m_tilde_a_number ; im_tilde_a++)
	{
	  const double m_tilde_a = im_tilde_a - j_tilde_a;
	  
	  for (int im_tilde_b = 0 ; im_tilde_b < m_tilde_b_number ; im_tilde_b++)
	    {
	      const double m_tilde_b = im_tilde_b - j_tilde_b;
		  
	      const double ML = m_tilde_a + m_tilde_b;

	      const double m_tilde_c = MK - ML;
	  
	      if (rint (abs (m_tilde_c) - j_tilde_c) <= 0.0)
		{
		  const unsigned int phi_tilde_a_index = one_body_tilde_a_indices(n_tilde_a , l_tilde_a , j_tilde_a , -m_tilde_a);
		  const unsigned int phi_tilde_b_index = one_body_tilde_b_indices(n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);
		  const unsigned int phi_tilde_c_index = one_body_tilde_c_indices(n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);

		  if ((phi_tilde_a_index != OUT_OF_RANGE) && (phi_tilde_b_index != OUT_OF_RANGE) && (phi_tilde_c_index != OUT_OF_RANGE))
		    {
		      const bool are_phi_tilde_ab_different = (!particle_tilde_ab_same || (phi_tilde_a_index != phi_tilde_b_index));
		      const bool are_phi_tilde_ac_different = (!particle_tilde_ac_same || (phi_tilde_a_index != phi_tilde_c_index));
		      const bool are_phi_tilde_bc_different = (!particle_tilde_bc_same || (phi_tilde_b_index != phi_tilde_c_index));

		      if (are_phi_tilde_ab_different && are_phi_tilde_ac_different && are_phi_tilde_bc_different)
			{
			  if (inSD_tilde_a.is_valence_state_occupied (phi_tilde_a_index) &&
			      inSD_tilde_b.is_valence_state_occupied (phi_tilde_b_index) &&
			      inSD_tilde_c.is_valence_state_occupied (phi_tilde_c_index))
			    {
			      unsigned int bin_phase_p = reordering_bin_phase_p;
			      unsigned int bin_phase_n = reordering_bin_phase_n;
			  
			      switch (dagger_tilde_operator)
				{ 
				case A_TILDE_A_TILDE_A_TILDE_PPP: inSDp.excitation_3h_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , phi_tilde_c_index , outSDp , bin_phase_p); break;		      
				case A_TILDE_A_TILDE_A_TILDE_NNN: inSDn.excitation_3h_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , phi_tilde_c_index , outSDn , bin_phase_n); break;
				  
				case A_TILDE_A_TILDE_A_TILDE_PPN:
				  {
				    inSDp.excitation_2h_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , outSDp , bin_phase_p);
				    inSDn.excitation_1h_and_bin_phase (phi_tilde_c_index , outSDn , bin_phase_n);
				  } break;
				  				  
				case A_TILDE_A_TILDE_A_TILDE_NNP:
				  {
				    inSDn.excitation_2h_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , outSDn , bin_phase_n);
				    inSDp.excitation_1h_and_bin_phase (phi_tilde_c_index , outSDp , bin_phase_p);
				  } break;
				  				  
				default: abort_all ();
				}
									
			      class configuration &Cp_out = Cp_out_work_tab(i_thread);
			      class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
			      Cp_out.get_SD_configuration (phi_p_table , outSDp);
			      Cn_out.get_SD_configuration (phi_n_table , outSDn);

			      const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_prot);
			      const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_neut);
			      
			      const int iMp_out = outSDp.iM_determine (phi_p_table);
			      const int iMn_out = outSDn.iM_determine (phi_n_table);

			      const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_prot);
			      const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_neut);
				  
			      const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_prot);
			      const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_neut); 

			      const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_prot);
			      const int En_out_hw = Cn_out.E_hw_determine (shells_qn_neut);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				    
			      class configuration &Cp_try = Cp_try_tab(i_thread);
			      class configuration &Cn_try = Cn_try_tab(i_thread);
					  
			      class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
			      class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
			      const unsigned int iCp_out = Cp_out.index_search (BPp_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
			      const unsigned int iCn_out = Cn_out.index_search (BPn_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				      
			      const unsigned int outSDp_index = outSDp.index_search (BPp_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
			      const unsigned int outSDn_index = outSDn.index_search (BPn_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

			      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

			      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);

			      const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

			      const TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];

			      (bin_phase_p == bin_phase_n)
				? (a_tilde_a_tilde_a_tilde_MK_table(m_tilde_a , m_tilde_b , m_tilde_c) += PSI_IN_component*PSI_OUT_component) 
				: (a_tilde_a_tilde_a_tilde_MK_table(m_tilde_a , m_tilde_b , m_tilde_c) -= PSI_IN_component*PSI_OUT_component);
					  
			    }}}}}}}
  
  a_tilde_a_tilde_a_tilde_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_tilde_a_tilde_a_tilde_MK_table += a_tilde_a_tilde_a_tilde_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_tilde_a_tilde_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}





















void dagger_tilde_operators::a_tilde_a_tilde_a_tilde_MK_RDM_pn_calc (
								     const enum dagger_tilde_operator_type dagger_tilde_operator , 
								     const class nljm_struct &phi_tilde_f , 
								     const class nljm_struct &phi_tilde_e , 
								     const class nljm_struct &phi_tilde_d , 
								     const class array<unsigned int> &inSDp_tab ,
								     const class array<unsigned int> &inSDn_tab ,
								     const class GSM_vector &PSI_IN ,
								     class GSM_vector &PSI_OUT_full)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const class nucleons_data &data_tilde_f = data_find (dagger_tilde_operator , 3 , prot_data , neut_data);
  const class nucleons_data &data_tilde_e = data_find (dagger_tilde_operator , 4 , prot_data , neut_data); 
  const class nucleons_data &data_tilde_d = data_find (dagger_tilde_operator , 5 , prot_data , neut_data);
    
  const enum particle_type particle_tilde_f = data_tilde_f.get_particle ();
  const enum particle_type particle_tilde_e = data_tilde_e.get_particle ();
  const enum particle_type particle_tilde_d = data_tilde_d.get_particle ();

  const bool particle_tilde_fe_same = (particle_tilde_f == particle_tilde_e);
  const bool particle_tilde_fd_same = (particle_tilde_f == particle_tilde_d);
  const bool particle_tilde_ed_same = (particle_tilde_e == particle_tilde_d);

  const class one_body_indices_str &one_body_tilde_f_indices = data_tilde_f.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_e_indices = data_tilde_e.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_d_indices = data_tilde_d.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
    
  const int Zval_IN = Z_IN_calc (dagger_tilde_operator , Zval);
  const int Nval_IN = N_IN_calc (dagger_tilde_operator , Nval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();
  
  const int n_tilde_f = phi_tilde_f.get_n ();
  const int n_tilde_e = phi_tilde_e.get_n ();
  const int n_tilde_d = phi_tilde_d.get_n ();
  
  const int l_tilde_f = phi_tilde_f.get_l ();
  const int l_tilde_e = phi_tilde_e.get_l ();  
  const int l_tilde_d = phi_tilde_d.get_l ();  
  
  const double j_tilde_f = phi_tilde_f.get_j ();
  const double m_tilde_f = phi_tilde_f.get_m ();
  
  const double j_tilde_e = phi_tilde_e.get_j ();
  const double m_tilde_e = phi_tilde_e.get_m ();
  
  const double j_tilde_d = phi_tilde_d.get_j ();
  const double m_tilde_d = phi_tilde_d.get_m ();

  const unsigned int phi_tilde_f_index = one_body_tilde_f_indices(n_tilde_f , l_tilde_f , j_tilde_f , -m_tilde_f);
  const unsigned int phi_tilde_e_index = one_body_tilde_e_indices(n_tilde_e , l_tilde_e , j_tilde_e , -m_tilde_e);
  const unsigned int phi_tilde_d_index = one_body_tilde_d_indices(n_tilde_d , l_tilde_d , j_tilde_d , -m_tilde_d);
		      
  const bool are_phi_tilde_fe_different = (!particle_tilde_fe_same || (phi_tilde_f_index != phi_tilde_e_index));
  const bool are_phi_tilde_fd_different = (!particle_tilde_fd_same || (phi_tilde_f_index != phi_tilde_d_index));
  const bool are_phi_tilde_ed_different = (!particle_tilde_ed_same || (phi_tilde_e_index != phi_tilde_d_index));
 
  PSI_OUT_full = 0.0;
  
  if (!are_phi_tilde_fe_different || !are_phi_tilde_fd_different || !are_phi_tilde_ed_different) return;
		    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
      
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (Zval_IN);
      inSDn_work_tab(i).allocate (Nval_IN);

      outSDp_work_tab(i).allocate (Zval);
      outSDn_work_tab(i).allocate (Nval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_out_work_tab(i).allocate (Zval);
      Cn_out_work_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);      
    }

  const class GSM_vector_helper_class &PSI_IN_helper = PSI_IN.get_GSM_vector_helper ();
  
  const unsigned int space_dimension_IN = PSI_IN_helper.get_space_dimension_process ();    
    
  PSI_OUT_full = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN  ; PSI_IN_index++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

      for (int p = 0 ; p < Zval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

      class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

      for (int n = 0 ; n < Nval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

      unsigned int bin_phase_p = 0;
      unsigned int bin_phase_n = 0;
      
      const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];

      const class Slater_determinant &inSD_tilde_f = SD_find (dagger_tilde_operator , 3 , inSDp , inSDn);
      const class Slater_determinant &inSD_tilde_e = SD_find (dagger_tilde_operator , 4 , inSDp , inSDn);
      const class Slater_determinant &inSD_tilde_d = SD_find (dagger_tilde_operator , 5 , inSDp , inSDn);

      if (inSD_tilde_f.is_valence_state_occupied (phi_tilde_f_index) &&
	  inSD_tilde_e.is_valence_state_occupied (phi_tilde_e_index) &&
	  inSD_tilde_d.is_valence_state_occupied (phi_tilde_d_index))
	{
	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	  if (Zval_IN == Zval) outSDp = inSDp;
	  if (Nval_IN == Nval) outSDn = inSDn;	      
	      
	  switch (dagger_tilde_operator)
	    { 				  
	    case T1_1_RDM_PPP: inSDp.excitation_3h_and_bin_phase (phi_tilde_f_index , phi_tilde_e_index , phi_tilde_d_index , outSDp , bin_phase_p); break;		      
	    case T1_1_RDM_NNN: inSDn.excitation_3h_and_bin_phase (phi_tilde_f_index , phi_tilde_e_index , phi_tilde_d_index , outSDn , bin_phase_n); break;
				  
	    case T1_1_RDM_PPN:
	      {
		inSDp.excitation_2h_and_bin_phase (phi_tilde_e_index , phi_tilde_d_index , outSDp , bin_phase_p);
		inSDn.excitation_1h_and_bin_phase (phi_tilde_f_index , outSDn , bin_phase_n);
	      } break;
				  				  
	    case T1_1_RDM_NNP:
	      {
		inSDn.excitation_2h_and_bin_phase (phi_tilde_e_index , phi_tilde_d_index , outSDn , bin_phase_n);
		inSDp.excitation_1h_and_bin_phase (phi_tilde_f_index , outSDp , bin_phase_p);
	      } break;
				  
	    default: abort_all ();
	    }

	  class configuration &Cp_out = Cp_out_work_tab(i_thread);
	  class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
	  Cp_out.get_SD_configuration (phi_p_table , outSDp);
	  Cn_out.get_SD_configuration (phi_n_table , outSDn);

	  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_prot);
	  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_neut);
			      
	  const int iMp_out = outSDp.iM_determine (phi_p_table);
	  const int iMn_out = outSDn.iM_determine (phi_n_table);

	  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_prot);
	  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_neut);
				  
	  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_prot);
	  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_neut); 

	  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_prot);
	  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_neut);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
	  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	  class configuration &Cp_try = Cp_try_tab(i_thread);
	  class configuration &Cn_try = Cn_try_tab(i_thread);
					  
	  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
	  const unsigned int iCp_out = Cp_out.index_search (BPp_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
	  const unsigned int iCn_out = Cn_out.index_search (BPn_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				      
	  const unsigned int outSDp_index = outSDp.index_search (BPp_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
	  const unsigned int outSDn_index = outSDn.index_search (BPn_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

	  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

	  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);

	  const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

	  TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];

#ifdef UseOpenMP
#pragma omp critical
#endif
	  (bin_phase_p == bin_phase_n) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);
				    
	}
    }
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_OUT_full.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
#endif
  
}




















void dagger_tilde_operators::a_dagger_a_tilde_MK_table_pp_nn_calc (
								   const class nlj_struct &shell_dagger_a_qn , 
								   const class nlj_struct &shell_tilde_b_qn , 
								   const class correlated_state_str &PSI_IN_qn , 
								   const class correlated_state_str &PSI_OUT_qn , 
								   const class GSM_vector &PSI_OUT_full ,
								   const class array<unsigned int> &inSD_tab ,
								   const class array<TYPE> &PSI_IN_component_tab ,
								   const class array<bool> &is_inSD_in_new_space_tab ,
								   const class array<unsigned char> &reordering_bin_phases ,
								   class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (space == NEUTRONS_ONLY) ? (neut_data) : (prot_data);
  
  const int N_valence_nucleons = data.get_N_valence_nucleons ();
  
  const int N_valence_nucleons_IN = data.get_N_valence_nucleons ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class lj_table<int> &nmax_lj_tab_mu = data.get_nmax_lj_tab ();

  const class nlj_table<bool> &is_it_valence_shell_tab_mu = data.get_is_it_valence_shell_tab ();

  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  
  const int n_tilde_b = shell_tilde_b_qn.get_n ();
  const int l_tilde_b = shell_tilde_b_qn.get_l ();

  const double j_dagger_a = shell_dagger_a_qn.get_j ();

  const double j_tilde_b = shell_tilde_b_qn.get_j ();

  const int m_dagger_a_number = shell_dagger_a_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int MK = make_int (M_OUT - M_IN);

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_nucleons_IN);

      outSD_work_tab(i).allocate (N_valence_nucleons);

      SD_try_tab(i).allocate (N_valence_nucleons);

      C_out_work_tab(i).allocate (N_valence_nucleons);

      C_try_tab(i).allocate (N_valence_nucleons);
      
      a_dagger_a_tilde_MK_tables(i).allocate (j_dagger_a , j_tilde_b);

      a_dagger_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);
	      
      class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

      for (int i = 0 ; i < N_valence_nucleons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);

      if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tab_mu , is_it_valence_shell_tab_mu)) continue;
      
      const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

      class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_MK_table = a_dagger_a_tilde_MK_tables(i_thread);

      for (int im_dagger_a = 0 ; im_dagger_a < m_dagger_a_number ; im_dagger_a++)
	{
	  const double m_dagger_a = im_dagger_a - j_dagger_a;

	  const double m_tilde_b = MK - m_dagger_a;

	  if (rint (abs (m_tilde_b) - j_tilde_b) <= 0.0)
	    {
	      const unsigned int phi_dagger_a_index = one_body_indices_mu(n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);

	      const unsigned int phi_tilde_b_index = one_body_indices_mu(n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);

	      if ((phi_dagger_a_index != OUT_OF_RANGE) && (phi_tilde_b_index != OUT_OF_RANGE))
		{
		  const bool is_phi_dagger_a_in_inSD = inSD.is_valence_state_occupied (phi_dagger_a_index);

		  const bool is_phi_tilde_b_in_inSD = inSD.is_valence_state_occupied (phi_tilde_b_index);

		  const bool no_phi_dagger_a_case = (!is_phi_dagger_a_in_inSD && is_phi_tilde_b_in_inSD);

		  const bool phi_dagger_a_phi_tilde_b_equal_case = ((phi_dagger_a_index == phi_tilde_b_index) && is_phi_dagger_a_in_inSD && is_phi_tilde_b_in_inSD);

		  if (no_phi_dagger_a_case || phi_dagger_a_phi_tilde_b_equal_case)
		    {
		      unsigned int bin_phase = reordering_bin_phase;
			  
		      class Slater_determinant &outSD = outSD_work_tab(i_thread);

		      inSD.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , outSD , bin_phase);

		      class configuration &C_out = C_out_work_tab(i_thread);

		      C_out.get_SD_configuration (phi_mu_table , outSD);

		      const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);

		      const int iM_out = outSD.iM_determine (phi_mu_table);

		      const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
		      const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);
			
		      const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			
		      class configuration &C_try = C_try_tab(i_thread);

		      class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
		      const unsigned int iC_out = C_out.index_search (BP_out , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
			      
		      const unsigned int outSD_index = outSD.index_search (BP_out , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

		      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

		      const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;
								    
		      const int phase = parity_from_binary_parity (bin_phase);
			  
		      const TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];

		      (phase == 1)
			? (a_dagger_a_tilde_MK_table(m_dagger_a , m_tilde_b) += PSI_IN_component*PSI_OUT_component)
			: (a_dagger_a_tilde_MK_table(m_dagger_a , m_tilde_b) -= PSI_IN_component*PSI_OUT_component);

		    }}}}}
  
  a_dagger_a_tilde_MK_table = 0.0;
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_tilde_MK_table += a_dagger_a_tilde_MK_tables(i);
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
  
#endif
}

















void dagger_tilde_operators::a_dagger_a_tilde_MK_RDM_pp_nn_calc (
								 const enum dagger_tilde_operator_type dagger_tilde_operator , 
								 const class nljm_struct &phi_dagger_d , 
								 const class nljm_struct &phi_tilde_c , 
								 const class array<unsigned int> &inSD_tab ,
								 const class GSM_vector &PSI_IN ,
								 class GSM_vector &PSI_OUT_full)
{
  if (!is_it_RDM_determine (dagger_tilde_operator)) error_message_print_abort ("RDM operator only in dagger_tilde_operators::a_dagger_a_tilde_MK_RDM_pp_nn_calc");
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (space == NEUTRONS_ONLY) ? (neut_data) : (prot_data);
  
  const int N_valence_nucleons = data.get_N_valence_nucleons ();
  
  const int N_valence_nucleons_IN = data.get_N_valence_nucleons ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const int n_dagger_d = phi_dagger_d.get_n ();
  const int l_dagger_d = phi_dagger_d.get_l ();
  
  const int n_tilde_c = phi_tilde_c.get_n ();
  const int l_tilde_c = phi_tilde_c.get_l ();

  const double j_dagger_d = phi_dagger_d.get_j ();
  const double m_dagger_d = phi_dagger_d.get_m ();

  const double j_tilde_c = phi_tilde_c.get_j ();
  const double m_tilde_c = phi_tilde_c.get_m ();

  const unsigned int phi_dagger_d_index = one_body_indices_mu(n_dagger_d , l_dagger_d , j_dagger_d , m_dagger_d);

  const unsigned int phi_tilde_c_index = one_body_indices_mu(n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);
		  	  
  const bool are_phi_dagger_d_phi_tilde_c_equal = (phi_dagger_d_index == phi_tilde_c_index);
	  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_nucleons_IN);

      outSD_work_tab(i).allocate (N_valence_nucleons);

      SD_try_tab(i).allocate (N_valence_nucleons);

      C_out_work_tab(i).allocate (N_valence_nucleons);

      C_try_tab(i).allocate (N_valence_nucleons);      
    }

  const class GSM_vector_helper_class &PSI_IN_helper = PSI_IN.get_GSM_vector_helper ();
  
  const unsigned int space_dimension_IN = PSI_IN_helper.get_space_dimension_process ();    
    
  PSI_OUT_full = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN  ; PSI_IN_index++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      unsigned int bin_phase = 0;
	      
      class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

      for (int i = 0 ; i < N_valence_nucleons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);
      
      const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];
      
      const bool is_phi_dagger_d_in_inSD = inSD.is_valence_state_occupied (phi_dagger_d_index);

      const bool is_phi_tilde_c_in_inSD = inSD.is_valence_state_occupied (phi_tilde_c_index);

      const bool no_phi_dagger_d_case = (!is_phi_dagger_d_in_inSD && is_phi_tilde_c_in_inSD);
	  
      const bool phi_dagger_d_phi_tilde_c_equal_case = (are_phi_dagger_d_phi_tilde_c_equal && is_phi_tilde_c_in_inSD);
  
      if (no_phi_dagger_d_case || phi_dagger_d_phi_tilde_c_equal_case)
	{
	  class Slater_determinant &outSD = outSD_work_tab(i_thread);

	  inSD.excitation_1p_1h_and_bin_phase (phi_dagger_d_index , phi_tilde_c_index , outSD , bin_phase);
  
	  class configuration &C_out = C_out_work_tab(i_thread);
	      
	  C_out.get_SD_configuration (phi_mu_table , outSD);

	  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);

	  const int iM_out = outSD.iM_determine (phi_mu_table);

	  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
	  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);
			
	  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
	    
	  class configuration &C_try = C_try_tab(i_thread);

	  class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
	  const unsigned int iC_out = C_out.index_search (BP_out , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
			      
	  const unsigned int outSD_index = outSD.index_search (BP_out , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

	  const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

	  const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

	  const int phase = parity_from_binary_parity (bin_phase);
						      
	  TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];				    

#ifdef UseOpenMP
#pragma omp critical
#endif
	  (phase == 1) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);

	}
    }
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_OUT_full.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
#endif
  
}




















void dagger_tilde_operators::a_dagger_a_dagger_MK_table_pp_nn_calc (
								    const class nlj_struct &shell_dagger_a_qn , 
								    const class nlj_struct &shell_dagger_b_qn , 
								    const class correlated_state_str &PSI_IN_qn , 
								    const class correlated_state_str &PSI_OUT_qn , 
								    const class GSM_vector &PSI_OUT_full ,
								    const class array<unsigned int> &inSD_tab ,
								    const class array<TYPE> &PSI_IN_component_tab ,
								    const class array<bool> &is_inSD_in_new_space_tab ,
								    const class array<unsigned char> &reordering_bin_phases ,
								    class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (space == NEUTRONS_ONLY) ? (neut_data) : (prot_data);

  const int N_valence_nucleons = data.get_N_valence_nucleons ();

  const int N_valence_nucleons_IN = N_valence_nucleons - 2;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class lj_table<int> &nmax_lj_tab_mu = data.get_nmax_lj_tab ();

  const class nlj_table<bool> &is_it_valence_shell_tab_mu = data.get_is_it_valence_shell_tab ();
  
  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int n_dagger_b = shell_dagger_b_qn.get_n ();
  
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  const int l_dagger_b = shell_dagger_b_qn.get_l ();

  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_dagger_b = shell_dagger_b_qn.get_j ();

  const int m_dagger_a_number = shell_dagger_a_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int MK = make_int (M_OUT - M_IN);

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_dagger_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_nucleons_IN);

      outSD_work_tab(i).allocate (N_valence_nucleons);

      SD_try_tab(i).allocate (N_valence_nucleons);

      C_out_work_tab(i).allocate (N_valence_nucleons);

      C_try_tab(i).allocate (N_valence_nucleons);
      
      a_dagger_a_dagger_MK_tables(i).allocate (j_dagger_a , j_dagger_b);

      a_dagger_a_dagger_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);

      class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

      for (int i = 0 ; i < N_valence_nucleons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);

      if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tab_mu , is_it_valence_shell_tab_mu)) continue;

      const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);
      
      class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_MK_table = a_dagger_a_dagger_MK_tables(i_thread);

      for (int im_dagger_a = 0 ; im_dagger_a < m_dagger_a_number ; im_dagger_a++)
	{
	  const double m_dagger_a = im_dagger_a - j_dagger_a;

	  const double m_dagger_b = MK - m_dagger_a;

	  if (rint (abs (m_dagger_b) - j_dagger_b) <= 0.0)
	    {
	      const unsigned int phi_dagger_a_index = one_body_indices_mu(n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
	      const unsigned int phi_dagger_b_index = one_body_indices_mu(n_dagger_b , l_dagger_b , j_dagger_b , m_dagger_b);

	      if ((phi_dagger_a_index != OUT_OF_RANGE) && (phi_dagger_b_index != OUT_OF_RANGE) && (phi_dagger_a_index != phi_dagger_b_index))
		{
		  if (!inSD.is_valence_state_occupied (phi_dagger_a_index) && !inSD.is_valence_state_occupied (phi_dagger_b_index))
		    {
		      unsigned int bin_phase = reordering_bin_phase;
			  
		      class Slater_determinant &outSD = outSD_work_tab(i_thread);

		      inSD.excitation_2p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , outSD , bin_phase);

		      class configuration &C_out = C_out_work_tab(i_thread);

		      C_out.get_SD_configuration (phi_mu_table , outSD);

		      const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);

		      const int iM_out = outSD.iM_determine (phi_mu_table);

		      const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

		      const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
		      const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			
		      class configuration &C_try = C_try_tab(i_thread);

		      class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
		      const unsigned int iC_out = C_out.index_search (BP_out , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
		      const unsigned int outSD_index = outSD.index_search (BP_out , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try); 

		      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

		      const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;
				    
		      const int phase = parity_from_binary_parity (bin_phase);
			  
		      const TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];
		
		      (phase == 1)
			? (a_dagger_a_dagger_MK_table(m_dagger_a , m_dagger_b) += PSI_IN_component*PSI_OUT_component)
			: (a_dagger_a_dagger_MK_table(m_dagger_a , m_dagger_b) -= PSI_IN_component*PSI_OUT_component);
			      
		    }}}}}

  a_dagger_a_dagger_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_dagger_MK_table += a_dagger_a_dagger_MK_tables(i);
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_dagger_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}




























void dagger_tilde_operators::a_dagger_a_dagger_MK_RDM_pp_nn_calc (
								  const enum dagger_tilde_operator_type dagger_tilde_operator , 
								  const class nljm_struct &phi_dagger_d , 
								  const class nljm_struct &phi_dagger_c , 
								  const class array<unsigned int> &inSD_tab ,
								  const class GSM_vector &PSI_IN ,
								  class GSM_vector &PSI_OUT_full)
{
  if (!is_it_RDM_determine (dagger_tilde_operator)) error_message_print_abort ("RDM operator only in dagger_tilde_operators::a_dagger_a_dagger_MK_RDM_pp_nn_calc");
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (space == NEUTRONS_ONLY) ? (neut_data) : (prot_data);

  const int N_valence_nucleons = data.get_N_valence_nucleons ();

  const int N_valence_nucleons_IN = N_valence_nucleons - 2;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const int n_dagger_d = phi_dagger_d.get_n ();
  const int n_dagger_c = phi_dagger_c.get_n ();
  
  const int l_dagger_d = phi_dagger_d.get_l ();
  const int l_dagger_c = phi_dagger_c.get_l ();
  
  const double j_dagger_d = phi_dagger_d.get_j ();
  const double m_dagger_d = phi_dagger_d.get_m ();

  const double j_dagger_c = phi_dagger_c.get_j ();
  const double m_dagger_c = phi_dagger_c.get_m ();

  const unsigned int phi_dagger_d_index = one_body_indices_mu(n_dagger_d , l_dagger_d , j_dagger_d , m_dagger_d);
  const unsigned int phi_dagger_c_index = one_body_indices_mu(n_dagger_c , l_dagger_c , j_dagger_c , m_dagger_c);
		  
  PSI_OUT_full = 0.0;
  
  if (phi_dagger_d_index == phi_dagger_c_index) return;
	  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_nucleons_IN);

      outSD_work_tab(i).allocate (N_valence_nucleons);

      SD_try_tab(i).allocate (N_valence_nucleons);

      C_out_work_tab(i).allocate (N_valence_nucleons);

      C_try_tab(i).allocate (N_valence_nucleons);      
    }

  const class GSM_vector_helper_class &PSI_IN_helper = PSI_IN.get_GSM_vector_helper ();
  
  const unsigned int space_dimension_IN = PSI_IN_helper.get_space_dimension_process ();    
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN  ; PSI_IN_index++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      unsigned int bin_phase = 0;

      class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

      for (int i = 0 ; i < N_valence_nucleons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);

      const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];
      
      if (!inSD.is_valence_state_occupied (phi_dagger_d_index) && !inSD.is_valence_state_occupied (phi_dagger_c_index))
	{
	  class Slater_determinant &outSD = outSD_work_tab(i_thread);

	  inSD.excitation_2p_and_bin_phase (phi_dagger_d_index , phi_dagger_c_index , outSD , bin_phase);

	  class configuration &C_out = C_out_work_tab(i_thread);

	  C_out.get_SD_configuration (phi_mu_table , outSD);

	  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);

	  const int iM_out = outSD.iM_determine (phi_mu_table);

	  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

	  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
	  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
	    
	  class configuration &C_try = C_try_tab(i_thread);

	  class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
	  const unsigned int iC_out = C_out.index_search (BP_out , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
	      
	  const unsigned int outSD_index = outSD.index_search (BP_out , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try); 

	  const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

	  const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

	  const int phase = parity_from_binary_parity (bin_phase);
						      
	  TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];
				    
#ifdef UseOpenMP
#pragma omp critical
#endif
	  (phase == 1) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);

	}
    }
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_OUT_full.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
#endif
  
}




















void dagger_tilde_operators::a_tilde_a_tilde_MK_table_pp_nn_calc (
								  const class nlj_struct &shell_tilde_a_qn , 
								  const class nlj_struct &shell_tilde_b_qn , 
								  const class correlated_state_str &PSI_IN_qn , 
								  const class correlated_state_str &PSI_OUT_qn , 
								  const class GSM_vector &PSI_OUT_full ,
								  const class array<unsigned int> &inSD_tab ,
								  const class array<TYPE> &PSI_IN_component_tab ,
								  const class array<bool> &is_inSD_in_new_space_tab ,
								  const class array<unsigned char> &reordering_bin_phases ,
								  class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (space == NEUTRONS_ONLY) ? (neut_data) : (prot_data);
  
  const int N_valence_nucleons = data.get_N_valence_nucleons ();

  const int N_valence_nucleons_IN = N_valence_nucleons + 2;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class lj_table<int> &nmax_lj_tab_mu = data.get_nmax_lj_tab ();

  const class nlj_table<bool> &is_it_valence_shell_tab_mu = data.get_is_it_valence_shell_tab ();

  const int n_tilde_a = shell_tilde_a_qn.get_n ();
  const int n_tilde_b = shell_tilde_b_qn.get_n ();
  
  const int l_tilde_a = shell_tilde_a_qn.get_l ();
  const int l_tilde_b = shell_tilde_b_qn.get_l ();

  const double j_tilde_a = shell_tilde_a_qn.get_j ();
  const double j_tilde_b = shell_tilde_b_qn.get_j ();

  const int m_tilde_a_number = shell_tilde_a_qn.m_number_determine ();
  
  const double J_IN = PSI_IN_qn.get_J ();
  const double M_IN = J_IN;

  const double J_OUT = PSI_OUT_qn.get_J ();
  const double M_OUT = J_OUT;

  const int MK = make_int (M_OUT - M_IN);

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_tilde_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_nucleons_IN);

      outSD_work_tab(i).allocate (N_valence_nucleons);

      SD_try_tab(i).allocate (N_valence_nucleons);

      C_out_work_tab(i).allocate (N_valence_nucleons);

      C_try_tab(i).allocate (N_valence_nucleons);
      
      a_tilde_a_tilde_MK_tables(i).allocate (j_tilde_a , j_tilde_b);

      a_tilde_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);
	    
      class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

      for (int i = 0 ; i < N_valence_nucleons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);

      if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tab_mu , is_it_valence_shell_tab_mu)) continue;
      
      const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

      class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_MK_table = a_tilde_a_tilde_MK_tables(i_thread);

      for (int im_tilde_a = 0 ; im_tilde_a < m_tilde_a_number ; im_tilde_a++)
	{
	  const double m_tilde_a = im_tilde_a - j_tilde_a;

	  const double m_tilde_b = MK - m_tilde_a;

	  if (rint (abs (m_tilde_b) - j_tilde_b) <= 0.0)
	    {
	      const unsigned int phi_tilde_a_index = one_body_indices_mu(n_tilde_a , l_tilde_a , j_tilde_a , -m_tilde_a);
	      const unsigned int phi_tilde_b_index = one_body_indices_mu(n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);

	      if ((phi_tilde_a_index != OUT_OF_RANGE) && (phi_tilde_b_index != OUT_OF_RANGE) && (phi_tilde_a_index != phi_tilde_b_index))
		{
		  if (inSD.is_valence_state_occupied (phi_tilde_a_index) && inSD.is_valence_state_occupied (phi_tilde_b_index))
		    {
		      unsigned int bin_phase = reordering_bin_phase;
			  
		      class Slater_determinant &outSD = outSD_work_tab(i_thread);

		      inSD.excitation_2h_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , outSD , bin_phase);

		      class configuration &C_out = C_out_work_tab(i_thread);

		      C_out.get_SD_configuration (phi_mu_table , outSD);

		      const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
		      
		      const int iM_out = outSD.iM_determine (phi_mu_table);

		      const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
		      const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);
		      
		      const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			
		      class configuration &C_try = C_try_tab(i_thread);
		      
		      class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
		      const unsigned int iC_out = C_out.index_search (BP_out , n_scat_out , dimensions_configuration_set , configuration_set , C_try);

		      const unsigned int outSD_index = outSD.index_search (BP_out , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try); 

		      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

		      const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;
			      
		      const int phase = parity_from_binary_parity (bin_phase);
			  
		      const TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];
			    			
		      (phase == 1)
			? (a_tilde_a_tilde_MK_table(m_tilde_a , m_tilde_b) += PSI_IN_component*PSI_OUT_component)
			: (a_tilde_a_tilde_MK_table(m_tilde_a , m_tilde_b) -= PSI_IN_component*PSI_OUT_component);
			      
		    }}}}}

  a_tilde_a_tilde_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_tilde_a_tilde_MK_table += a_tilde_a_tilde_MK_tables(i);
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_tilde_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}


















void dagger_tilde_operators::a_tilde_a_tilde_MK_RDM_pp_nn_calc (
								const enum dagger_tilde_operator_type dagger_tilde_operator ,  
								const class nljm_struct &phi_tilde_d , 
								const class nljm_struct &phi_tilde_c , 
								const class array<unsigned int> &inSD_tab ,
								const class GSM_vector &PSI_IN ,
								class GSM_vector &PSI_OUT_full)
{
  if (!is_it_RDM_determine (dagger_tilde_operator)) error_message_print_abort ("RDM operator only in dagger_tilde_operators::a_tilde_a_tilde_MK_RDM_pp_nn_calc");
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (space == NEUTRONS_ONLY) ? (neut_data) : (prot_data);
  
  const int N_valence_nucleons = data.get_N_valence_nucleons ();

  const int N_valence_nucleons_IN = N_valence_nucleons + 2;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const int n_tilde_d = phi_tilde_d.get_n ();
  const int n_tilde_c = phi_tilde_c.get_n ();
  
  const int l_tilde_d = phi_tilde_d.get_l ();
  const int l_tilde_c = phi_tilde_c.get_l ();
  
  const double j_tilde_d = phi_tilde_d.get_j ();
  const double m_tilde_d = phi_tilde_d.get_m ();

  const double j_tilde_c = phi_tilde_c.get_j ();
  const double m_tilde_c = phi_tilde_c.get_m ();

  const unsigned int phi_tilde_d_index = one_body_indices_mu(n_tilde_d , l_tilde_d , j_tilde_d , -m_tilde_d);
  const unsigned int phi_tilde_c_index = one_body_indices_mu(n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);

  PSI_OUT_full = 0.0;
  
  if (phi_tilde_c_index == phi_tilde_d_index) return;
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_nucleons_IN);

      outSD_work_tab(i).allocate (N_valence_nucleons);

      SD_try_tab(i).allocate (N_valence_nucleons);

      C_out_work_tab(i).allocate (N_valence_nucleons);

      C_try_tab(i).allocate (N_valence_nucleons);      
    }

  const class GSM_vector_helper_class &PSI_IN_helper = PSI_IN.get_GSM_vector_helper ();
  
  const unsigned int space_dimension_IN = PSI_IN_helper.get_space_dimension_process ();    
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN  ; PSI_IN_index++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      unsigned int bin_phase = 0;
	    
      class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

      for (int i = 0 ; i < N_valence_nucleons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);
      
      const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];

      if (inSD.is_valence_state_occupied (phi_tilde_c_index) && inSD.is_valence_state_occupied (phi_tilde_d_index))
	{
	  class Slater_determinant &outSD = outSD_work_tab(i_thread);
	      
	  inSD.excitation_2h_and_bin_phase (phi_tilde_d_index , phi_tilde_c_index , outSD , bin_phase);
	  
	  class configuration &C_out = C_out_work_tab(i_thread);

	  C_out.get_SD_configuration (phi_mu_table , outSD);

	  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
		      
	  const int iM_out = outSD.iM_determine (phi_mu_table);

	  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
	  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);
		      
	  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
	    
	  class configuration &C_try = C_try_tab(i_thread);
	  
	  class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
	  const unsigned int iC_out = C_out.index_search (BP_out , n_scat_out , dimensions_configuration_set , configuration_set , C_try);

	  const unsigned int outSD_index = outSD.index_search (BP_out , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try); 

	  const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

	  const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

	  const int phase = parity_from_binary_parity (bin_phase);
			      
	  TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];				    

#ifdef UseOpenMP
#pragma omp critical
#endif
	  (phase == 1) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);

	}
    }
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_OUT_full.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
#endif
  
}

























void dagger_tilde_operators::a_dagger_a_dagger_a_tilde_MK_table_pp_nn_calc (
									    const class nlj_struct &shell_dagger_a_qn , 
									    const class nlj_struct &shell_dagger_b_qn , 
									    const class nlj_struct &shell_tilde_c_qn , 
									    const class correlated_state_str &PSI_IN_qn , 
									    const class correlated_state_str &PSI_OUT_qn , 
									    const class GSM_vector &PSI_OUT_full ,
									    const class array<unsigned int> &inSD_tab ,
									    const class array<TYPE> &PSI_IN_component_tab ,
									    const class array<bool> &is_inSD_in_new_space_tab ,
									    const class array<unsigned char> &reordering_bin_phases ,
									    class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (space == NEUTRONS_ONLY) ? (neut_data) : (prot_data);

  const int N_valence_nucleons = data.get_N_valence_nucleons ();

  const int N_valence_nucleons_IN = N_valence_nucleons - 1;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class lj_table<int> &nmax_lj_tab_mu = data.get_nmax_lj_tab ();

  const class nlj_table<bool> &is_it_valence_shell_tab_mu = data.get_is_it_valence_shell_tab ();
  
  const int n_tilde_c = shell_tilde_c_qn.get_n ();
  const int l_tilde_c = shell_tilde_c_qn.get_l ();

  const double j_tilde_c = shell_tilde_c_qn.get_j ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;

  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int n_dagger_b = shell_dagger_b_qn.get_n ();
  
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  const int l_dagger_b = shell_dagger_b_qn.get_l ();

  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_dagger_b = shell_dagger_b_qn.get_j ();

  const int m_dagger_a_number = shell_dagger_a_qn.m_number_determine ();
  const int m_dagger_b_number = shell_dagger_b_qn.m_number_determine ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_dagger_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_nucleons_IN);

      outSD_work_tab(i).allocate (N_valence_nucleons);

      SD_try_tab(i).allocate (N_valence_nucleons);

      C_out_work_tab(i).allocate (N_valence_nucleons);

      C_try_tab(i).allocate (N_valence_nucleons);
      
      a_dagger_a_dagger_a_tilde_MK_tables(i).allocate (j_dagger_a , j_dagger_b , j_tilde_c);

      a_dagger_a_dagger_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
   
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);

      class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

      for (int i = 0 ; i < N_valence_nucleons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);

      if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tab_mu , is_it_valence_shell_tab_mu)) continue;
      
      const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

      class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_tilde_MK_table = a_dagger_a_dagger_a_tilde_MK_tables(i_thread);

      for (int im_dagger_a = 0 ; im_dagger_a < m_dagger_a_number ; im_dagger_a++)
	{
	  const double m_dagger_a = im_dagger_a - j_dagger_a;
	  
	  for (int im_dagger_b = 0 ; im_dagger_b < m_dagger_b_number ; im_dagger_b++)
	    {
	      const double m_dagger_b = im_dagger_b - j_dagger_b;
		  
	      const double ML = m_dagger_a + m_dagger_b;

	      const double m_tilde_c = MK - ML;
	  
	      if (rint (abs (m_tilde_c) - j_tilde_c) <= 0.0)
		{
		  const unsigned int phi_tilde_c_index = one_body_indices_mu(n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);

		  const unsigned int phi_dagger_a_index = one_body_indices_mu(n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
		  const unsigned int phi_dagger_b_index = one_body_indices_mu(n_dagger_b , l_dagger_b , j_dagger_b , m_dagger_b);

		  if ((phi_tilde_c_index != OUT_OF_RANGE) && (phi_dagger_a_index != OUT_OF_RANGE) && (phi_dagger_b_index != OUT_OF_RANGE))
		    {
		      const bool is_phi_tilde_c_in_inSD = inSD.is_valence_state_occupied (phi_tilde_c_index);

		      const bool are_phi_dagger_ab_different = (phi_dagger_a_index != phi_dagger_b_index);

		      if (is_phi_tilde_c_in_inSD && are_phi_dagger_ab_different)
			{
			  const bool is_phi_dagger_a_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_a_index);
			  const bool is_phi_dagger_b_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_b_index);

			  const bool no_dagger_ab_case = (is_phi_dagger_a_not_in_inSD && is_phi_dagger_b_not_in_inSD);

			  const bool phi_tilde_c_phi_dagger_a_equal_case = ((phi_tilde_c_index == phi_dagger_a_index) && is_phi_dagger_b_not_in_inSD);
			  const bool phi_tilde_c_phi_dagger_b_equal_case = ((phi_tilde_c_index == phi_dagger_b_index) && is_phi_dagger_a_not_in_inSD);

			  if (no_dagger_ab_case || phi_tilde_c_phi_dagger_a_equal_case || phi_tilde_c_phi_dagger_b_equal_case)
			    {
			      unsigned int bin_phase = reordering_bin_phase;
			  
			      class Slater_determinant &outSD = outSD_work_tab(i_thread);

			      inSD.excitation_2p_1h_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , phi_tilde_c_index , outSD , bin_phase);

			      class configuration &C_out = C_out_work_tab(i_thread);

			      C_out.get_SD_configuration (phi_mu_table , outSD);

			      const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);

			      const int iM_out = outSD.iM_determine (phi_mu_table);

			      const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

			      const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
			      const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				
			      class configuration &C_try = C_try_tab(i_thread);

			      class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
			      const unsigned int iC_out = C_out.index_search (BP_out , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
			      
			      const unsigned int outSD_index = outSD.index_search (BP_out , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

			      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

			      const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;
				    
			      const int phase = parity_from_binary_parity (bin_phase);
				  
			      const TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];

			      (phase == 1)
				? (a_dagger_a_dagger_a_tilde_MK_table(m_dagger_a , m_dagger_b , m_tilde_c) += PSI_IN_component*PSI_OUT_component) 
				: (a_dagger_a_dagger_a_tilde_MK_table(m_dagger_a , m_dagger_b , m_tilde_c) -= PSI_IN_component*PSI_OUT_component);

			    }}}}}}}

  a_dagger_a_dagger_a_tilde_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_dagger_a_tilde_MK_table += a_dagger_a_dagger_a_tilde_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_dagger_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}



















void dagger_tilde_operators::a_dagger_a_dagger_a_tilde_MK_RDM_pp_nn_calc (
									  const enum dagger_tilde_operator_type dagger_tilde_operator ,  
									  const class nljm_struct &phi_dagger_f , 
									  const class nljm_struct &phi_dagger_e , 
									  const class nljm_struct &phi_tilde_d , 
									  const class array<unsigned int> &inSD_tab ,
									  const class GSM_vector &PSI_IN ,
									  class GSM_vector &PSI_OUT_full)
{
  if (!is_it_RDM_determine (dagger_tilde_operator)) error_message_print_abort ("RDM operator only in dagger_tilde_operators::a_dagger_a_dagger_a_tilde_MK_RDM_pp_nn_calc");
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (space == NEUTRONS_ONLY) ? (neut_data) : (prot_data);

  const int N_valence_nucleons = data.get_N_valence_nucleons ();

  const int N_valence_nucleons_IN = N_valence_nucleons - 1;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();
  
  const int n_dagger_f = phi_dagger_f.get_n ();
  const int n_dagger_e = phi_dagger_e.get_n ();
  const int n_tilde_d  = phi_tilde_d.get_n ();
  
  const int l_dagger_f = phi_dagger_f.get_l ();
  const int l_dagger_e = phi_dagger_e.get_l ();
  const int l_tilde_d  = phi_tilde_d.get_l ();

  const double j_dagger_f = phi_dagger_f.get_j ();
  const double m_dagger_f = phi_dagger_f.get_m ();
  
  const double j_dagger_e = phi_dagger_e.get_j ();
  const double m_dagger_e = phi_dagger_e.get_m ();
  
  const double j_tilde_d  = phi_tilde_d.get_j ();
  const double m_tilde_d  = phi_tilde_d.get_m ();

  const unsigned int phi_dagger_f_index = one_body_indices_mu(n_dagger_f , l_dagger_f , j_dagger_f , m_dagger_f);
  const unsigned int phi_dagger_e_index = one_body_indices_mu(n_dagger_e , l_dagger_e , j_dagger_e , m_dagger_e);
  const unsigned int phi_tilde_d_index  = one_body_indices_mu(n_tilde_d  , l_tilde_d  , j_tilde_d  ,-m_tilde_d);
		      
  PSI_OUT_full = 0.0;
  
  if (phi_dagger_f_index == phi_dagger_e_index) return;
	
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_nucleons_IN);

      outSD_work_tab(i).allocate (N_valence_nucleons);

      SD_try_tab(i).allocate (N_valence_nucleons);

      C_out_work_tab(i).allocate (N_valence_nucleons);

      C_try_tab(i).allocate (N_valence_nucleons);      
    }

  const class GSM_vector_helper_class &PSI_IN_helper = PSI_IN.get_GSM_vector_helper ();
  
  const unsigned int space_dimension_IN = PSI_IN_helper.get_space_dimension_process ();    
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN  ; PSI_IN_index++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      unsigned int bin_phase = 0;

      class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

      for (int i = 0 ; i < N_valence_nucleons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);
      
      const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];

      const bool is_phi_tilde_d_in_inSD = inSD.is_valence_state_occupied (phi_tilde_d_index);

      if (is_phi_tilde_d_in_inSD)
	{
	  const bool is_phi_dagger_f_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_f_index);
	  const bool is_phi_dagger_e_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_e_index);

	  const bool no_dagger_fe_case = (is_phi_dagger_f_not_in_inSD && is_phi_dagger_e_not_in_inSD);

	  const bool phi_tilde_d_phi_dagger_f_equal_case = ((phi_tilde_d_index == phi_dagger_f_index) && is_phi_dagger_e_not_in_inSD);
	  const bool phi_tilde_d_phi_dagger_e_equal_case = ((phi_tilde_d_index == phi_dagger_e_index) && is_phi_dagger_f_not_in_inSD);

	  if (no_dagger_fe_case || phi_tilde_d_phi_dagger_f_equal_case || phi_tilde_d_phi_dagger_e_equal_case)
	    {
	      class Slater_determinant &outSD = outSD_work_tab(i_thread);

	      inSD.excitation_2p_1h_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , phi_tilde_d_index , outSD , bin_phase);

	      class configuration &C_out = C_out_work_tab(i_thread);

	      C_out.get_SD_configuration (phi_mu_table , outSD);

	      const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);

	      const int iM_out = outSD.iM_determine (phi_mu_table);

	      const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

	      const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
	      const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	      class configuration &C_try = C_try_tab(i_thread);

	      class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
	      const unsigned int iC_out = C_out.index_search (BP_out , n_scat_out , dimensions_configuration_set , configuration_set , C_try);

	      const unsigned int outSD_index = outSD.index_search (BP_out , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

	      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

	      const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

	      const int phase = parity_from_binary_parity (bin_phase);
				      
	      TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];
				    
#ifdef UseOpenMP
#pragma omp critical
#endif
	      (phase == 1) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);

	    }
	}
    }
      
#ifdef UseMPI
      
  if (is_it_MPI_parallelized) PSI_OUT_full.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
      
#endif
  
}







































void dagger_tilde_operators::a_dagger_a_tilde_a_tilde_MK_table_pp_nn_calc (
									   const class nlj_struct &shell_dagger_a_qn , 
									   const class nlj_struct &shell_tilde_b_qn , 
									   const class nlj_struct &shell_tilde_c_qn , 
									   const class correlated_state_str &PSI_IN_qn , 
									   const class correlated_state_str &PSI_OUT_qn , 
									   const class GSM_vector &PSI_OUT_full ,
									   const class array<unsigned int> &inSD_tab ,
									   const class array<TYPE> &PSI_IN_component_tab ,
									   const class array<bool> &is_inSD_in_new_space_tab ,
									   const class array<unsigned char> &reordering_bin_phases ,
									   class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (space == NEUTRONS_ONLY) ? (neut_data) : (prot_data);

  const int N_valence_nucleons = data.get_N_valence_nucleons () ;

  const int N_valence_nucleons_IN = N_valence_nucleons + 1;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class lj_table<int> &nmax_lj_tab_mu = data.get_nmax_lj_tab ();

  const class nlj_table<bool> &is_it_valence_shell_tab_mu = data.get_is_it_valence_shell_tab ();

  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int l_dagger_a = shell_dagger_a_qn.get_l ();

  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;

  const int n_tilde_b = shell_tilde_b_qn.get_n ();
  const int n_tilde_c = shell_tilde_c_qn.get_n ();
  
  const int l_tilde_b = shell_tilde_b_qn.get_l ();
  const int l_tilde_c = shell_tilde_c_qn.get_l ();

  const double j_tilde_b = shell_tilde_b_qn.get_j ();
  const double j_tilde_c = shell_tilde_c_qn.get_j ();

  const int m_tilde_b_number = shell_tilde_b_qn.m_number_determine ();
  const int m_tilde_c_number = shell_tilde_c_qn.m_number_determine ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_tilde_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_nucleons_IN);

      outSD_work_tab(i).allocate (N_valence_nucleons);

      SD_try_tab(i).allocate (N_valence_nucleons);

      C_out_work_tab(i).allocate (N_valence_nucleons);

      C_try_tab(i).allocate (N_valence_nucleons);
      
      a_dagger_a_tilde_a_tilde_MK_tables(i).allocate (j_dagger_a , j_tilde_b , j_tilde_c);

      a_dagger_a_tilde_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);

      class Slater_determinant &inSD = inSD_work_tab(i_thread);

      for (int i = 0 ; i < N_valence_nucleons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);

      if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tab_mu , is_it_valence_shell_tab_mu)) continue;
      
      const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

      class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_a_tilde_MK_table = a_dagger_a_tilde_a_tilde_MK_tables(i_thread);

      for (int im_tilde_b = 0 ; im_tilde_b < m_tilde_b_number ; im_tilde_b++)
	{
	  const double m_tilde_b = im_tilde_b - j_tilde_b;
	  
	  for (int im_tilde_c = 0 ; im_tilde_c < m_tilde_c_number ; im_tilde_c++)
	    {
	      const double m_tilde_c = im_tilde_c - j_tilde_c;
		  
	      const double ML = m_tilde_b + m_tilde_c;

	      const double m_dagger_a = MK - ML;
	  
	      if (rint (abs (m_dagger_a) - j_dagger_a) <= 0.0)
		{
		  const unsigned int phi_dagger_a_index = one_body_indices_mu(n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);

		  const unsigned int phi_tilde_b_index = one_body_indices_mu(n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);
		  const unsigned int phi_tilde_c_index = one_body_indices_mu(n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);

		  if ((phi_dagger_a_index != OUT_OF_RANGE) && (phi_tilde_b_index != OUT_OF_RANGE) && (phi_tilde_c_index != OUT_OF_RANGE) && (phi_tilde_b_index != phi_tilde_c_index))
		    {
		      if (inSD.is_valence_state_occupied (phi_tilde_b_index) && inSD.is_valence_state_occupied (phi_tilde_c_index))
			{
			  const bool is_phi_dagger_a_in_inSD = inSD.is_valence_state_occupied (phi_dagger_a_index);

			  const bool no_phi_dagger_a_case = !is_phi_dagger_a_in_inSD;

			  const bool phi_dagger_a_phi_tilde_b_equal_case = ((phi_dagger_a_index == phi_tilde_b_index) && is_phi_dagger_a_in_inSD);
			  const bool phi_dagger_a_phi_tilde_c_equal_case = ((phi_dagger_a_index == phi_tilde_c_index) && is_phi_dagger_a_in_inSD);

			  if (no_phi_dagger_a_case || phi_dagger_a_phi_tilde_b_equal_case || phi_dagger_a_phi_tilde_c_equal_case)
			    {
			      unsigned int bin_phase = reordering_bin_phase;
			  
			      class Slater_determinant &outSD = outSD_work_tab(i_thread);

			      inSD.excitation_1p_2h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , phi_tilde_c_index , outSD , bin_phase);

			      class configuration &C_out = C_out_work_tab(i_thread);

			      C_out.get_SD_configuration (phi_mu_table , outSD);

			      const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);

			      const int iM_out = outSD.iM_determine (phi_mu_table);

			      const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

			      const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
			      const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				
			      class configuration &C_try = C_try_tab(i_thread);
				    
			      class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
			      const unsigned int iC_out = C_out.index_search (BP_out , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
				    
			      const unsigned int outSD_index = outSD.index_search (BP_out , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try); 

			      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

			      const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;
				    
			      const int phase = parity_from_binary_parity (bin_phase);
				
			      const TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];

			      (phase == 1)
				? (a_dagger_a_tilde_a_tilde_MK_table(m_dagger_a , m_tilde_b , m_tilde_c) += PSI_IN_component*PSI_OUT_component)
				: (a_dagger_a_tilde_a_tilde_MK_table(m_dagger_a , m_tilde_b , m_tilde_c) -= PSI_IN_component*PSI_OUT_component);

			    }}}}}}}

  a_dagger_a_tilde_a_tilde_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_tilde_a_tilde_MK_table += a_dagger_a_tilde_a_tilde_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_tilde_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}

















void dagger_tilde_operators::a_dagger_a_tilde_a_tilde_MK_RDM_pp_nn_calc (
									 const enum dagger_tilde_operator_type dagger_tilde_operator , 
									 const class nljm_struct &phi_dagger_f , 
									 const class nljm_struct &phi_tilde_e , 
									 const class nljm_struct &phi_tilde_d , 
									 const class array<unsigned int> &inSD_tab ,
									 const class GSM_vector &PSI_IN ,
									 class GSM_vector &PSI_OUT_full)
{
  if (!is_it_RDM_determine (dagger_tilde_operator)) error_message_print_abort ("RDM operator only in dagger_tilde_operators::a_dagger_a_tilde_a_tilde_MK_RDM_pp_nn_calc");
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (space == NEUTRONS_ONLY) ? (neut_data) : (prot_data);

  const int N_valence_nucleons = data.get_N_valence_nucleons () ;

  const int N_valence_nucleons_IN = N_valence_nucleons + 1;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const int n_dagger_f = phi_dagger_f.get_n ();
  const int n_tilde_e  = phi_tilde_e.get_n ();
  const int n_tilde_d  = phi_tilde_d.get_n ();
  
  const int l_dagger_f = phi_dagger_f.get_l ();
  const int l_tilde_e  = phi_tilde_e.get_l ();
  const int l_tilde_d  = phi_tilde_d.get_l ();

  const double j_dagger_f = phi_dagger_f.get_j ();
  const double m_dagger_f = phi_dagger_f.get_m ();
  
  const double j_tilde_e  = phi_tilde_e.get_j ();
  const double m_tilde_e  = phi_tilde_e.get_m ();
  
  const double j_tilde_d  = phi_tilde_d.get_j ();
  const double m_tilde_d  = phi_tilde_d.get_m ();

  const unsigned int phi_dagger_f_index = one_body_indices_mu(n_dagger_f , l_dagger_f , j_dagger_f ,  m_dagger_f);
  const unsigned int phi_tilde_e_index  = one_body_indices_mu(n_tilde_e  , l_tilde_e  , j_tilde_e  , -m_tilde_e);
  const unsigned int phi_tilde_d_index  = one_body_indices_mu(n_tilde_d  , l_tilde_d  , j_tilde_d  , -m_tilde_d);

  PSI_OUT_full = 0.0;
  
  if (phi_tilde_e_index == phi_tilde_d_index) return;
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_nucleons_IN);

      outSD_work_tab(i).allocate (N_valence_nucleons);

      SD_try_tab(i).allocate (N_valence_nucleons);

      C_out_work_tab(i).allocate (N_valence_nucleons);

      C_try_tab(i).allocate (N_valence_nucleons);
    }

  const class GSM_vector_helper_class &PSI_IN_helper = PSI_IN.get_GSM_vector_helper ();
  
  const unsigned int space_dimension_IN = PSI_IN_helper.get_space_dimension_process ();    
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN  ; PSI_IN_index++)
    {	      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      unsigned int bin_phase = 0;

      class Slater_determinant &inSD = inSD_work_tab(i_thread);

      for (int i = 0 ; i < N_valence_nucleons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);
      
      const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];

      if (inSD.is_valence_state_occupied (phi_tilde_e_index) && inSD.is_valence_state_occupied (phi_tilde_d_index))
	{
	  const bool is_phi_dagger_f_in_inSD = inSD.is_valence_state_occupied (phi_dagger_f_index);

	  const bool no_phi_dagger_f_case = !is_phi_dagger_f_in_inSD;

	  const bool are_phi_dagger_f_phi_tilde_e_equal = (phi_dagger_f_index == phi_tilde_e_index);
	  const bool are_phi_dagger_f_phi_tilde_d_equal = (phi_dagger_f_index == phi_tilde_d_index);
		      
	  const bool phi_dagger_f_phi_tilde_e_equal_case = (are_phi_dagger_f_phi_tilde_e_equal && is_phi_dagger_f_in_inSD);
	  const bool phi_dagger_f_phi_tilde_d_equal_case = (are_phi_dagger_f_phi_tilde_d_equal && is_phi_dagger_f_in_inSD);

	  if (no_phi_dagger_f_case || phi_dagger_f_phi_tilde_e_equal_case || phi_dagger_f_phi_tilde_d_equal_case)
	    {
	      class Slater_determinant &outSD = outSD_work_tab(i_thread);

	      inSD.excitation_1p_2h_and_bin_phase (phi_dagger_f_index , phi_tilde_e_index , phi_tilde_d_index , outSD , bin_phase);

	      class configuration &C_out = C_out_work_tab(i_thread);

	      C_out.get_SD_configuration (phi_mu_table , outSD);

	      const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);

	      const int iM_out = outSD.iM_determine (phi_mu_table);

	      const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

	      const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
	      const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	      class configuration &C_try = C_try_tab(i_thread);
				    
	      class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
	      const unsigned int iC_out = C_out.index_search (BP_out , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
				    
	      const unsigned int outSD_index = outSD.index_search (BP_out , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try); 

	      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

	      const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

	      const int phase = parity_from_binary_parity (bin_phase);
				      
	      TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];				    

#ifdef UseOpenMP
#pragma omp critical
#endif
	      (phase == 1) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);

	    }
	}
    }
      
#ifdef UseMPI
      
  if (is_it_MPI_parallelized) PSI_OUT_full.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
      
#endif
  
}





















void dagger_tilde_operators::a_dagger_a_dagger_a_dagger_MK_table_pp_nn_calc (
									     const class nlj_struct &shell_dagger_a_qn , 
									     const class nlj_struct &shell_dagger_b_qn , 
									     const class nlj_struct &shell_dagger_c_qn , 
									     const class correlated_state_str &PSI_IN_qn , 
									     const class correlated_state_str &PSI_OUT_qn , 
									     const class GSM_vector &PSI_OUT_full ,
									     const class array<unsigned int> &inSD_tab ,
									     const class array<TYPE> &PSI_IN_component_tab ,
									     const class array<bool> &is_inSD_in_new_space_tab ,
									     const class array<unsigned char> &reordering_bin_phases ,
									     class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_dagger_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (space == NEUTRONS_ONLY) ? (neut_data) : (prot_data);

  const int N_valence_nucleons = data.get_N_valence_nucleons ();

  const int N_valence_nucleons_IN = N_valence_nucleons - 3;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();
  
  const class lj_table<int> &nmax_lj_tab_mu = data.get_nmax_lj_tab ();

  const class nlj_table<bool> &is_it_valence_shell_tab_mu = data.get_is_it_valence_shell_tab ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;

  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int n_dagger_b = shell_dagger_b_qn.get_n ();
  const int n_dagger_c = shell_dagger_c_qn.get_n ();
  
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  const int l_dagger_b = shell_dagger_b_qn.get_l ();
  const int l_dagger_c = shell_dagger_c_qn.get_l ();

  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_dagger_b = shell_dagger_b_qn.get_j ();
  const double j_dagger_c = shell_dagger_c_qn.get_j ();

  const int m_dagger_a_number = shell_dagger_a_qn.m_number_determine ();
  const int m_dagger_b_number = shell_dagger_b_qn.m_number_determine ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_dagger_a_dagger_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_nucleons_IN);

      outSD_work_tab(i).allocate (N_valence_nucleons);

      SD_try_tab(i).allocate (N_valence_nucleons);

      C_out_work_tab(i).allocate (N_valence_nucleons);

      C_try_tab(i).allocate (N_valence_nucleons);
      
      a_dagger_a_dagger_a_dagger_MK_tables(i).allocate (j_dagger_a , j_dagger_b , j_dagger_c);

      a_dagger_a_dagger_a_dagger_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);

      class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

      for (int i = 0 ; i < N_valence_nucleons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);

      if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tab_mu , is_it_valence_shell_tab_mu)) continue;
      
      const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

      class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_dagger_MK_table = a_dagger_a_dagger_a_dagger_MK_tables(i_thread);

      for (int im_dagger_a = 0 ; im_dagger_a < m_dagger_a_number ; im_dagger_a++)
	{
	  const double m_dagger_a = im_dagger_a - j_dagger_a;
	  
	  for (int im_dagger_b = 0 ; im_dagger_b < m_dagger_b_number ; im_dagger_b++)
	    {
	      const double m_dagger_b = im_dagger_b - j_dagger_b;
		  
	      const double ML = m_dagger_a + m_dagger_b;

	      const double m_dagger_c = MK - ML;
	  
	      if (rint (abs (m_dagger_c) - j_dagger_c) <= 0.0)
		{
		  const unsigned int phi_dagger_a_index = one_body_indices_mu(n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
		  const unsigned int phi_dagger_b_index = one_body_indices_mu(n_dagger_b , l_dagger_b , j_dagger_b , m_dagger_b);
		  const unsigned int phi_dagger_c_index = one_body_indices_mu(n_dagger_c , l_dagger_c , j_dagger_c , m_dagger_c);

		  if ((phi_dagger_a_index != OUT_OF_RANGE) && (phi_dagger_b_index != OUT_OF_RANGE) && (phi_dagger_c_index != OUT_OF_RANGE))
		    {
		      const bool are_phi_dagger_ab_different = (phi_dagger_a_index != phi_dagger_b_index);
		      const bool are_phi_dagger_ac_different = (phi_dagger_a_index != phi_dagger_c_index);
		      const bool are_phi_dagger_bc_different = (phi_dagger_b_index != phi_dagger_c_index);

		      if (are_phi_dagger_ab_different && are_phi_dagger_ac_different && are_phi_dagger_bc_different)
			{
			  if (!inSD.is_valence_state_occupied (phi_dagger_a_index) &&
			      !inSD.is_valence_state_occupied (phi_dagger_b_index) &&
			      !inSD.is_valence_state_occupied (phi_dagger_c_index))
			    {
			      unsigned int bin_phase = reordering_bin_phase;
			  
			      class Slater_determinant &outSD = outSD_work_tab(i_thread);

			      inSD.excitation_3p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , phi_dagger_c_index , outSD , bin_phase);

			      class configuration &C_out = C_out_work_tab(i_thread);

			      C_out.get_SD_configuration (phi_mu_table , outSD);

			      const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);

			      const int iM_out = outSD.iM_determine (phi_mu_table);

			      const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

			      const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
			      const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				
			      class configuration &C_try = C_try_tab(i_thread);

			      class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
			      const unsigned int iC_out = C_out.index_search (BP_out , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
				      
			      const unsigned int outSD_index = outSD.index_search (BP_out , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

			      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

			      const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;
				    
			      const int phase = parity_from_binary_parity (bin_phase);
				  
			      const TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];

			      (phase == 1)
				? (a_dagger_a_dagger_a_dagger_MK_table(m_dagger_a , m_dagger_b , m_dagger_c) += PSI_IN_component*PSI_OUT_component) 
				: (a_dagger_a_dagger_a_dagger_MK_table(m_dagger_a , m_dagger_b , m_dagger_c) -= PSI_IN_component*PSI_OUT_component);

			    }}}}}}}

  a_dagger_a_dagger_a_dagger_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_dagger_a_dagger_MK_table += a_dagger_a_dagger_a_dagger_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_dagger_a_dagger_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}













void dagger_tilde_operators::a_dagger_a_dagger_a_dagger_MK_RDM_pp_nn_calc (
									   const enum dagger_tilde_operator_type dagger_tilde_operator , 
									   const class nljm_struct &phi_dagger_f , 
									   const class nljm_struct &phi_dagger_e , 
									   const class nljm_struct &phi_dagger_d , 
									   const class array<unsigned int> &inSD_tab ,
									   const class GSM_vector &PSI_IN ,
									   class GSM_vector &PSI_OUT_full)
{
  if (!is_it_RDM_determine (dagger_tilde_operator)) error_message_print_abort ("RDM operator only in dagger_tilde_operators::a_dagger_a_dagger_a_dagger_MK_RDM_pp_nn_calc");
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (space == NEUTRONS_ONLY) ? (neut_data) : (prot_data);

  const int N_valence_nucleons = data.get_N_valence_nucleons ();

  const int N_valence_nucleons_IN = N_valence_nucleons - 3;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();
  
  const int n_dagger_f = phi_dagger_f.get_n ();
  const int n_dagger_e = phi_dagger_e.get_n ();
  const int n_dagger_d = phi_dagger_d.get_n ();
  
  const int l_dagger_f = phi_dagger_f.get_l ();
  const int l_dagger_e = phi_dagger_e.get_l ();
  const int l_dagger_d = phi_dagger_d.get_l ();
  
  const double j_dagger_f = phi_dagger_f.get_j ();
  const double m_dagger_f = phi_dagger_f.get_m ();
  
  const double j_dagger_e = phi_dagger_e.get_j ();
  const double m_dagger_e = phi_dagger_e.get_m ();

  const double j_dagger_d = phi_dagger_d.get_j ();
  const double m_dagger_d = phi_dagger_d.get_m ();

  const unsigned int phi_dagger_f_index = one_body_indices_mu(n_dagger_f , l_dagger_f , j_dagger_f , m_dagger_f);
  const unsigned int phi_dagger_e_index = one_body_indices_mu(n_dagger_e , l_dagger_e , j_dagger_e , m_dagger_e);
  const unsigned int phi_dagger_d_index = one_body_indices_mu(n_dagger_d , l_dagger_d , j_dagger_d , m_dagger_d);
  
  const bool are_phi_dagger_fe_different = (phi_dagger_f_index != phi_dagger_e_index);
  const bool are_phi_dagger_fd_different = (phi_dagger_f_index != phi_dagger_d_index);
  const bool are_phi_dagger_ed_different = (phi_dagger_e_index != phi_dagger_d_index);

  PSI_OUT_full = 0.0;
  
  if (!are_phi_dagger_fe_different || !are_phi_dagger_fd_different || !are_phi_dagger_ed_different) return;
	
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_nucleons_IN);

      outSD_work_tab(i).allocate (N_valence_nucleons);

      SD_try_tab(i).allocate (N_valence_nucleons);

      C_out_work_tab(i).allocate (N_valence_nucleons);

      C_try_tab(i).allocate (N_valence_nucleons);
    }

  const class GSM_vector_helper_class &PSI_IN_helper = PSI_IN.get_GSM_vector_helper ();
  
  const unsigned int space_dimension_IN = PSI_IN_helper.get_space_dimension_process ();    
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN  ; PSI_IN_index++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      unsigned int bin_phase = 0;

      class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

      for (int i = 0 ; i < N_valence_nucleons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);
      
      const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];

      if (!inSD.is_valence_state_occupied (phi_dagger_d_index) &&
	  !inSD.is_valence_state_occupied (phi_dagger_e_index) &&
	  !inSD.is_valence_state_occupied (phi_dagger_f_index))
	{
	  class Slater_determinant &outSD = outSD_work_tab(i_thread);

	  inSD.excitation_3p_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , phi_dagger_d_index , outSD , bin_phase);
	      
	  class configuration &C_out = C_out_work_tab(i_thread);

	  C_out.get_SD_configuration (phi_mu_table , outSD);

	  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);

	  const int iM_out = outSD.iM_determine (phi_mu_table);

	  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

	  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
	  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
	    
	  class configuration &C_try = C_try_tab(i_thread);

	  class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
	  const unsigned int iC_out = C_out.index_search (BP_out , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
				      
	  const unsigned int outSD_index = outSD.index_search (BP_out , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

	  const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

	  const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

	  const int phase = parity_from_binary_parity (bin_phase);
				      
	  TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];
				    
#ifdef UseOpenMP
#pragma omp critical
#endif
	  (phase == 1) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);

	}
    }
      
#ifdef UseMPI
      
  if (is_it_MPI_parallelized) PSI_OUT_full.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
      
#endif
  
}



























void dagger_tilde_operators::a_tilde_a_tilde_a_tilde_MK_table_pp_nn_calc (
									  const class nlj_struct &shell_tilde_a_qn , 
									  const class nlj_struct &shell_tilde_b_qn , 
									  const class nlj_struct &shell_tilde_c_qn , 
									  const class correlated_state_str &PSI_IN_qn , 
									  const class correlated_state_str &PSI_OUT_qn , 
									  const class GSM_vector &PSI_OUT_full ,
									  const class array<unsigned int> &inSD_tab ,
									  const class array<TYPE> &PSI_IN_component_tab ,
									  const class array<bool> &is_inSD_in_new_space_tab ,
									  const class array<unsigned char> &reordering_bin_phases ,
									  class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (space == NEUTRONS_ONLY) ? (neut_data) : (prot_data);

  const int N_valence_nucleons = data.get_N_valence_nucleons ();

  const int N_valence_nucleons_IN = N_valence_nucleons + 3;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();
  
  const class lj_table<int> &nmax_lj_tab_mu = data.get_nmax_lj_tab ();

  const class nlj_table<bool> &is_it_valence_shell_tab_mu = data.get_is_it_valence_shell_tab ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;

  const int n_tilde_a = shell_tilde_a_qn.get_n ();
  const int n_tilde_b = shell_tilde_b_qn.get_n ();
  const int n_tilde_c = shell_tilde_c_qn.get_n ();
  
  const int l_tilde_a = shell_tilde_a_qn.get_l ();
  const int l_tilde_b = shell_tilde_b_qn.get_l ();
  const int l_tilde_c = shell_tilde_c_qn.get_l ();

  const double j_tilde_a = shell_tilde_a_qn.get_j ();
  const double j_tilde_b = shell_tilde_b_qn.get_j ();
  const double j_tilde_c = shell_tilde_c_qn.get_j ();

  const int m_tilde_a_number = shell_tilde_a_qn.m_number_determine ();
  const int m_tilde_b_number = shell_tilde_b_qn.m_number_determine ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_tilde_a_tilde_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_nucleons_IN);

      outSD_work_tab(i).allocate (N_valence_nucleons);

      SD_try_tab(i).allocate (N_valence_nucleons);

      C_out_work_tab(i).allocate (N_valence_nucleons);

      C_try_tab(i).allocate (N_valence_nucleons);
      
      a_tilde_a_tilde_a_tilde_MK_tables(i).allocate (j_tilde_a , j_tilde_b , j_tilde_c);

      a_tilde_a_tilde_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN ; PSI_IN_index++)
    {
      if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);

      class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

      for (int i = 0 ; i < N_valence_nucleons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);
      
      if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tab_mu , is_it_valence_shell_tab_mu)) continue;
      
      const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

      class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_a_tilde_MK_table = a_tilde_a_tilde_a_tilde_MK_tables(i_thread);

      for (int im_tilde_a = 0 ; im_tilde_a < m_tilde_a_number ; im_tilde_a++)
	{
	  const double m_tilde_a = im_tilde_a - j_tilde_a;
	  
	  for (int im_tilde_b = 0 ; im_tilde_b < m_tilde_b_number ; im_tilde_b++)
	    {
	      const double m_tilde_b = im_tilde_b - j_tilde_b;
		  
	      const double ML = m_tilde_a + m_tilde_b;

	      const double m_tilde_c = MK - ML;
	  
	      if (rint (abs (m_tilde_c) - j_tilde_c) <= 0.0)
		{
		  const unsigned int phi_tilde_a_index = one_body_indices_mu(n_tilde_a , l_tilde_a , j_tilde_a , -m_tilde_a);
		  const unsigned int phi_tilde_b_index = one_body_indices_mu(n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);
		  const unsigned int phi_tilde_c_index = one_body_indices_mu(n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);

		  if ((phi_tilde_a_index != OUT_OF_RANGE) && (phi_tilde_b_index != OUT_OF_RANGE) && (phi_tilde_c_index != OUT_OF_RANGE))
		    {
		      const bool are_phi_tilde_ab_different = (phi_tilde_a_index != phi_tilde_b_index);
		      const bool are_phi_tilde_ac_different = (phi_tilde_a_index != phi_tilde_c_index);
		      const bool are_phi_tilde_bc_different = (phi_tilde_b_index != phi_tilde_c_index);

		      if (are_phi_tilde_ab_different && are_phi_tilde_ac_different && are_phi_tilde_bc_different)
			{			      
			  if (inSD.is_valence_state_occupied (phi_tilde_a_index) && inSD.is_valence_state_occupied (phi_tilde_b_index) && inSD.is_valence_state_occupied (phi_tilde_c_index))
			    {
			      unsigned int bin_phase = reordering_bin_phase;
			  
			      class Slater_determinant &outSD = outSD_work_tab(i_thread);

			      inSD.excitation_3h_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , phi_tilde_c_index , outSD , bin_phase);

			      class configuration &C_out = C_out_work_tab(i_thread);

			      C_out.get_SD_configuration (phi_mu_table , outSD);

			      const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);

			      const int iM_out = outSD.iM_determine (phi_mu_table);

			      const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

			      const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
			      const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				
			      class configuration &C_try = C_try_tab(i_thread);

			      class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
			      const unsigned int iC_out = C_out.index_search (BP_out , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
				      
			      const unsigned int outSD_index = outSD.index_search (BP_out , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

			      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

			      const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;
				    
			      const int phase = parity_from_binary_parity (bin_phase);
				  
			      const TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];

			      (phase == 1)
				? (a_tilde_a_tilde_a_tilde_MK_table(m_tilde_a , m_tilde_b , m_tilde_c) += PSI_IN_component*PSI_OUT_component) 
				: (a_tilde_a_tilde_a_tilde_MK_table(m_tilde_a , m_tilde_b , m_tilde_c) -= PSI_IN_component*PSI_OUT_component);

			    }}}}}}}

  a_tilde_a_tilde_a_tilde_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_tilde_a_tilde_a_tilde_MK_table += a_tilde_a_tilde_a_tilde_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_tilde_a_tilde_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}












void dagger_tilde_operators::a_tilde_a_tilde_a_tilde_MK_RDM_pp_nn_calc (
									const enum dagger_tilde_operator_type dagger_tilde_operator ,
									const class nljm_struct &phi_tilde_f , 
									const class nljm_struct &phi_tilde_e , 
									const class nljm_struct &phi_tilde_d , 
									const class array<unsigned int> &inSD_tab ,
									const class GSM_vector &PSI_IN ,
									class GSM_vector &PSI_OUT_full)
{
  if (!is_it_RDM_determine (dagger_tilde_operator)) error_message_print_abort ("RDM operators only in dagger_tilde_operators::a_tilde_a_tilde_a_tilde_MK_RDM_pp_nn_calc");
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (space == NEUTRONS_ONLY) ? (neut_data) : (prot_data);

  const int N_valence_nucleons = data.get_N_valence_nucleons ();

  const int N_valence_nucleons_IN = N_valence_nucleons + 3;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();
  
  const int n_tilde_f = phi_tilde_f.get_n ();
  const int n_tilde_e = phi_tilde_e.get_n ();
  const int n_tilde_d = phi_tilde_d.get_n ();
  
  const int l_tilde_f = phi_tilde_f.get_l ();
  const int l_tilde_e = phi_tilde_e.get_l ();
  const int l_tilde_d = phi_tilde_d.get_l ();
  
  const double j_tilde_f = phi_tilde_f.get_j ();
  const double m_tilde_f = phi_tilde_f.get_m ();
  
  const double j_tilde_e = phi_tilde_e.get_j ();
  const double m_tilde_e = phi_tilde_e.get_m ();

  const double j_tilde_d = phi_tilde_d.get_j ();
  const double m_tilde_d = phi_tilde_d.get_m ();

  const unsigned int phi_tilde_f_index = one_body_indices_mu(n_tilde_f , l_tilde_f , j_tilde_f , -m_tilde_f);
  const unsigned int phi_tilde_e_index = one_body_indices_mu(n_tilde_e , l_tilde_e , j_tilde_e , -m_tilde_e);
  const unsigned int phi_tilde_d_index = one_body_indices_mu(n_tilde_d , l_tilde_d , j_tilde_d , -m_tilde_d);
  
  const bool are_phi_tilde_fe_different = (phi_tilde_f_index != phi_tilde_e_index);
  const bool are_phi_tilde_fd_different = (phi_tilde_f_index != phi_tilde_d_index);
  const bool are_phi_tilde_ed_different = (phi_tilde_e_index != phi_tilde_d_index);

  PSI_OUT_full = 0.0;
  
  if (!are_phi_tilde_fe_different || !are_phi_tilde_fd_different || !are_phi_tilde_ed_different) return;
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_nucleons_IN);

      outSD_work_tab(i).allocate (N_valence_nucleons);

      SD_try_tab(i).allocate (N_valence_nucleons);

      C_out_work_tab(i).allocate (N_valence_nucleons);

      C_try_tab(i).allocate (N_valence_nucleons);
    }

  const class GSM_vector_helper_class &PSI_IN_helper = PSI_IN.get_GSM_vector_helper ();
  
  const unsigned int space_dimension_IN = PSI_IN_helper.get_space_dimension_process ();    
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int PSI_IN_index = 0 ; PSI_IN_index < space_dimension_IN  ; PSI_IN_index++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      unsigned int bin_phase = 0;

      class Slater_determinant &inSD = inSD_work_tab(i_thread);	  
      
      for (int i = 0 ; i < N_valence_nucleons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);
      
      const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];

      if (inSD.is_valence_state_occupied (phi_tilde_d_index) && inSD.is_valence_state_occupied (phi_tilde_e_index) && inSD.is_valence_state_occupied (phi_tilde_f_index))
	{	      
	  class Slater_determinant &outSD = outSD_work_tab(i_thread);

	  inSD.excitation_3h_and_bin_phase (phi_tilde_f_index , phi_tilde_e_index , phi_tilde_d_index , outSD , bin_phase);
	      
	  class configuration &C_out = C_out_work_tab(i_thread);

	  C_out.get_SD_configuration (phi_mu_table , outSD);

	  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);

	  const int iM_out = outSD.iM_determine (phi_mu_table);

	  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

	  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
	  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
	    
	  class configuration &C_try = C_try_tab(i_thread);

	  class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
	  const unsigned int iC_out = C_out.index_search (BP_out , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
				      
	  const unsigned int outSD_index = outSD.index_search (BP_out , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

	  const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

	  const unsigned int total_PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

	  const int phase = parity_from_binary_parity (bin_phase);
				      
	  TYPE &PSI_OUT_component = PSI_OUT_full[total_PSI_OUT_index];
				    
#ifdef UseOpenMP
#pragma omp critical
#endif
	  (phase == 1) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);

	}
    }
      
#ifdef UseMPI
      
  if (is_it_MPI_parallelized) PSI_OUT_full.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
      
#endif
  
}










void dagger_tilde_operators::two_body_K_tables_calc_store (
							   const bool full_common_vectors_used_in_file , 
							   const enum dagger_tilde_operator_type dagger_tilde_operator , 
							   const class correlated_state_str &PSI_IN_qn , 
							   const class correlated_state_str &PSI_OUT_qn , 
							   const class GSM_vector &PSI_OUT_full)
{
  if (!is_it_two_body_determine (dagger_tilde_operator)) error_message_print_abort ("Two-body operators only in dagger_tilde_operators::two_body_K_tables_calc_store");
    
  if (is_it_RDM_determine (dagger_tilde_operator)) error_message_print_abort ("No RDM operator in dagger_tilde_operators::two_body_K_tables_calc_store");
  
  const bool is_it_dagger_a = is_it_dagger_determine (dagger_tilde_operator , 0);
  const bool is_it_dagger_b = is_it_dagger_determine (dagger_tilde_operator , 1);
  
  const bool is_it_a_dagger_a_tilde  = ( is_it_dagger_a && !is_it_dagger_b);
  const bool is_it_a_dagger_a_dagger = ( is_it_dagger_a &&  is_it_dagger_b);
  const bool is_it_a_tilde_a_tilde   = (!is_it_dagger_a && !is_it_dagger_b);
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data_a = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
  const class nucleons_data &data_b = data_find (dagger_tilde_operator , 1 , prot_data , neut_data);

  const unsigned int N_nlj_a = data_a.get_N_nlj ();
  const unsigned int N_nlj_b = data_b.get_N_nlj ();

  const unsigned int BP_IN  = PSI_IN_qn.get_BP ();
  const unsigned int BP_OUT = PSI_OUT_qn.get_BP ();

  const unsigned int BP_dagger_tilde = binary_parity_product (BP_IN , BP_OUT);

  const class array<class nlj_struct> &shells_a_qn = data_a.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_b_qn = data_b.get_shells_quantum_numbers ();

  const enum particle_type particle_a = data_a.get_particle ();
  const enum particle_type particle_b = data_b.get_particle ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int Kmin_PSI = abs (make_int (J_IN - J_OUT));
  
  const int Kmax_PSI = make_int (J_IN + J_OUT);

  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (dagger_tilde_operator);
        
  const string PSI_IN_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_IN_qn);
  const string PSI_OUT_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_OUT_qn);
  
  const string outfile_name = dagger_tilde_operator_string + "_" + PSI_IN_qn_string + "_" + PSI_OUT_qn_string;
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const int Zval_IN = Z_IN_calc (dagger_tilde_operator , Zval);
  const int Nval_IN = N_IN_calc (dagger_tilde_operator , Nval);
  
  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);

  const unsigned int N_valence_nucleons_IN = (space == PROTONS_ONLY) ? (Zval_IN ) : (Nval_IN);
  
  const unsigned int space_dimension_IN = (space == PROTONS_NEUTRONS)
    ? (space_dimension_read_disk (full_common_vectors_used_in_file , Zval_IN , Nval_IN , file_name_IN_dimension))
    : (space_dimension_read_disk (full_common_vectors_used_in_file , N_valence_nucleons_IN , file_name_IN_dimension));
  
  class array<unsigned int> inSDp_tab;
  class array<unsigned int> inSDn_tab;

  class array<bool> is_inSDp_in_new_space_tab;
  class array<bool> is_inSDn_in_new_space_tab;

  class array<unsigned char> reordering_bin_phases_p;
  class array<unsigned char> reordering_bin_phases_n;  

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);
	
  switch (space)
    {
    case PROTONS_ONLY:
      {
	inSDp_tab.allocate (space_dimension_IN , Zval_IN);
	
	is_inSDp_in_new_space_tab.allocate (space_dimension_IN);

	reordering_bin_phases_p.allocate (space_dimension_IN);
	
	files_IN_tables_read_pp_nn_one_nucleon (full_common_vectors_used_in_file , PSI_IN_qn , M_IN , prot_data , inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p);
      } break;

    case NEUTRONS_ONLY:
      {
	inSDn_tab.allocate (space_dimension_IN , Nval_IN);
	
	is_inSDn_in_new_space_tab.allocate (space_dimension_IN);

	reordering_bin_phases_n.allocate (space_dimension_IN);
	
	files_IN_tables_read_pp_nn_one_nucleon (full_common_vectors_used_in_file , PSI_IN_qn , M_IN , neut_data , inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n);
      } break;
		
    case PROTONS_NEUTRONS:
      {
	inSDp_tab.allocate (space_dimension_IN , Zval_IN);
	inSDn_tab.allocate (space_dimension_IN , Nval_IN);
	
	is_inSDp_in_new_space_tab.allocate (space_dimension_IN);
	is_inSDn_in_new_space_tab.allocate (space_dimension_IN);

	reordering_bin_phases_p.allocate (space_dimension_IN);
	reordering_bin_phases_n.allocate (space_dimension_IN);

	files_IN_tables_read_pn_one_nucleon (full_common_vectors_used_in_file , Zval_IN , Nval_IN , PSI_IN_qn , M_IN , prot_data , neut_data , inSDp_tab , inSDn_tab , PSI_IN_component_tab ,
					     is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n);
      } break;
      
    default: abort_all ();
    }
  
  const double ma_max = data_a.get_m_max ();
  const double mb_max = data_b.get_m_max ();

  const double m_max = max (ma_max , mb_max);
  
  const class CG_str CGs(m_max);
  
  const int K_number_PSI = Kmax_PSI - Kmin_PSI + 1;

  class array<double> K_reducing_terms(K_number_PSI);

  K_reducing_terms_calc (J_IN , J_OUT , M_IN , M_OUT , K_reducing_terms);
  
  ofstream outfile;

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      outfile.open (outfile_name.c_str ());

      outfile.precision (15);
    }

  for (unsigned int sa = 0 ; sa < N_nlj_a ; sa++)
    for (unsigned int sb = 0 ; sb < N_nlj_b ; sb++)
      {
	const bool ab_shells_ordered = ((particle_a != particle_b) || (sa <= sb));

	if (is_it_a_dagger_a_dagger && !ab_shells_ordered) continue;
	if (is_it_a_tilde_a_tilde   && !ab_shells_ordered) continue;
	  	  
	const class nlj_struct &shell_sa_qn = shells_a_qn(sa);
	const class nlj_struct &shell_sb_qn = shells_b_qn(sb);

	const bool frozen_state_a = shell_sa_qn.get_frozen_state ();
	const bool frozen_state_b = shell_sb_qn.get_frozen_state ();
		    
	if (!frozen_state_a && !frozen_state_b)
	  {	
	    const int la = shell_sa_qn.get_l ();
	    const int lb = shell_sb_qn.get_l ();

	    const unsigned int bp_ab = binary_parity_from_orbital_angular_momentum (la + lb);

	    if (bp_ab == BP_dagger_tilde)
	      {
		const double ja = shell_sa_qn.get_j ();
		const double jb = shell_sb_qn.get_j ();

		class uncoupled_dagger_tilde_table<TYPE> two_body_MK_table(ja , jb);

		switch (space)
		  {
		  case PROTONS_ONLY:
		    {
		      if (is_it_a_dagger_a_tilde)
			a_dagger_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
							      inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , two_body_MK_table);

		      if (is_it_a_dagger_a_dagger)
			a_dagger_a_dagger_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
							       inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , two_body_MK_table);
		      
		      if (is_it_a_tilde_a_tilde)
			a_tilde_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
							     inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , two_body_MK_table);
		    } break;

		  case NEUTRONS_ONLY:
		    {
		      if (is_it_a_dagger_a_tilde)
			a_dagger_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
							      inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , two_body_MK_table);
		      
		      if (is_it_a_dagger_a_dagger)
			a_dagger_a_dagger_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
							       inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , two_body_MK_table);
		      
		      if (is_it_a_tilde_a_tilde)
			a_tilde_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
							     inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , two_body_MK_table);
		    } break;

		
		  case PROTONS_NEUTRONS:
		    {
		      if (is_it_a_dagger_a_tilde)
			a_dagger_a_tilde_MK_table_pn_calc (dagger_tilde_operator , shell_sa_qn , shell_sb_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
							   inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
							   reordering_bin_phases_p , reordering_bin_phases_n ,two_body_MK_table);

		      if (is_it_a_dagger_a_dagger)
			a_dagger_a_dagger_MK_table_pn_calc (dagger_tilde_operator , shell_sa_qn , shell_sb_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
							    inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
							    reordering_bin_phases_p , reordering_bin_phases_n ,two_body_MK_table);
		      
		      if (is_it_a_tilde_a_tilde)
			a_tilde_a_tilde_MK_table_pn_calc (dagger_tilde_operator , shell_sa_qn , shell_sb_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
							  inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
							  reordering_bin_phases_p , reordering_bin_phases_n ,two_body_MK_table);
		      
		    } break;
		    
		  default: abort_all ();
		  }
		
		if (THIS_PROCESS == MASTER_PROCESS)
		  {		    
		    class coupled_dagger_tilde_table<TYPE> two_body_K_table(dagger_tilde_operator , ja , jb);

		    two_body_K_table_from_MK_table_calc  (J_IN , J_OUT , M_IN , M_OUT , CGs , K_reducing_terms , two_body_MK_table , two_body_K_table);
		    
		    const bool are_ab_same_shell = ((particle_a == particle_b) && same_nlj (shell_sa_qn , shell_sb_qn));

		    const int Kmin_j = two_body_K_table.get_Kmin ();
		    const int Kmax_j = two_body_K_table.get_Kmax ();
	    
		    const int Kmin = max (Kmin_j , Kmin_PSI);
		    const int Kmax = min (Kmax_j , Kmax_PSI);

		    bool is_it_to_write = false;
	    
		    for (int K = Kmin ; K <= Kmax ; K++)
		      {
			if (!is_it_to_write) is_it_to_write = (!are_ab_same_shell || (minus_one_pow (K) == 1));
		      }
	    
		    if (is_it_to_write)
		      {
			outfile << "[" << shell_sa_qn;

			if (!is_it_dagger_a) outfile << "~";

			outfile << " " << shell_sb_qn;

			if (!is_it_dagger_b) outfile << "~";
			
			outfile << "]^K" << endl;

			for (int K = Kmin ; K <= Kmax ; K++)
			  {
			    if (!are_ab_same_shell || (minus_one_pow (K) == 1)) outfile << K << " " << two_body_K_table(K) << endl;
			  }
			
			outfile << endl;
		      }}}}}
}






void dagger_tilde_operators::three_body_L_K_tables_calc_store (
							       const bool full_common_vectors_used_in_file , 
							       const enum dagger_tilde_operator_type dagger_tilde_operator , 
							       const class correlated_state_str &PSI_IN_qn , 
							       const class correlated_state_str &PSI_OUT_qn , 
							       const class GSM_vector &PSI_OUT_full)
{
  if (is_it_two_body_determine (dagger_tilde_operator)) error_message_print_abort ("Three-body operators only in dagger_tilde_operators::three_body_L_K_tables_calc_store");
  
  if (is_it_RDM_determine (dagger_tilde_operator)) error_message_print_abort ("No RDM operator in dagger_tilde_operators::three_body_L_K_tables_calc_store");
      
  const bool is_it_dagger_a = is_it_dagger_determine (dagger_tilde_operator , 0);
  const bool is_it_dagger_b = is_it_dagger_determine (dagger_tilde_operator , 1);
  const bool is_it_dagger_c = is_it_dagger_determine (dagger_tilde_operator , 2);
  
  const bool is_it_a_dagger_a_tilde_a_tilde   = ( is_it_dagger_a && !is_it_dagger_b && !is_it_dagger_c);
  const bool is_it_a_dagger_a_dagger_a_tilde  = ( is_it_dagger_a &&  is_it_dagger_b && !is_it_dagger_c);
  const bool is_it_a_dagger_a_dagger_a_dagger = ( is_it_dagger_a &&  is_it_dagger_b &&  is_it_dagger_c);
  const bool is_it_a_tilde_a_tilde_a_tilde    = (!is_it_dagger_a && !is_it_dagger_b && !is_it_dagger_c);
    
  const bool are_ab_coupled_first = (is_it_a_dagger_a_dagger_a_tilde || is_it_a_dagger_a_dagger_a_dagger);
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT_full.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data_a = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
  const class nucleons_data &data_b = data_find (dagger_tilde_operator , 1 , prot_data , neut_data);
  const class nucleons_data &data_c = data_find (dagger_tilde_operator , 2 , prot_data , neut_data);

  const unsigned int N_nlj_a = data_a.get_N_nlj ();
  const unsigned int N_nlj_b = data_b.get_N_nlj ();
  const unsigned int N_nlj_c = data_c.get_N_nlj ();

  const unsigned int BP_IN  = PSI_IN_qn.get_BP ();
  const unsigned int BP_OUT = PSI_OUT_qn.get_BP ();
  
  const unsigned int BP_dagger_tilde = binary_parity_product (BP_IN , BP_OUT);
    
  const class array<class nlj_struct> &shells_a_qn = data_a.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_b_qn = data_b.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_c_qn = data_c.get_shells_quantum_numbers ();

  const enum particle_type particle_a = data_a.get_particle ();
  const enum particle_type particle_b = data_b.get_particle ();
  const enum particle_type particle_c = data_b.get_particle ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double Kmin_PSI = abs (J_IN - J_OUT);
  const double Kmax_PSI = J_IN + J_OUT;

  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (dagger_tilde_operator);
  
  const string PSI_IN_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_IN_qn);
  const string PSI_OUT_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_OUT_qn);
  
  const string outfile_name = dagger_tilde_operator_string + "_" + PSI_IN_qn_string + "_" + PSI_OUT_qn_string;
  
  const double ma_max = data_a.get_m_max ();
  const double mb_max = data_b.get_m_max ();
  const double mc_max = data_b.get_m_max ();

  const double m_max_ab = max (ma_max , mb_max);
  
  const double m_max = max (m_max_ab , mc_max);
    
  const double three_m_max = 3.0*m_max;

  const class CG_str CGs(three_m_max);
  
  const int K_number_PSI = make_int (Kmax_PSI - Kmin_PSI) + 1;

  class array<double> K_reducing_terms(K_number_PSI);

  K_reducing_terms_calc (J_IN , J_OUT , M_IN , M_OUT , K_reducing_terms);
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const int Zval_IN = Z_IN_calc (dagger_tilde_operator , Zval);
  const int Nval_IN = N_IN_calc (dagger_tilde_operator , Nval);
  
  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);

  const unsigned int N_valence_nucleons_IN = (space == PROTONS_ONLY) ? (Zval_IN ) : (Nval_IN);
  
  const unsigned int space_dimension_IN = (space == PROTONS_NEUTRONS)
    ? (space_dimension_read_disk (full_common_vectors_used_in_file , Zval_IN , Nval_IN , file_name_IN_dimension))
    : (space_dimension_read_disk (full_common_vectors_used_in_file , N_valence_nucleons_IN , file_name_IN_dimension));
  
  class array<unsigned int> inSDp_tab;
  class array<unsigned int> inSDn_tab;

  class array<bool> is_inSDp_in_new_space_tab;
  class array<bool> is_inSDn_in_new_space_tab;

  class array<unsigned char> reordering_bin_phases_p;
  class array<unsigned char> reordering_bin_phases_n;  

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);
	
  switch (space)
    {
    case PROTONS_ONLY:
      {
	inSDp_tab.allocate (space_dimension_IN , Zval_IN);
	
	is_inSDp_in_new_space_tab.allocate (space_dimension_IN);

	reordering_bin_phases_p.allocate (space_dimension_IN);
	
	files_IN_tables_read_pp_nn_one_nucleon (full_common_vectors_used_in_file , PSI_IN_qn , M_IN , prot_data , inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p);
      } break;

    case NEUTRONS_ONLY:
      {
	inSDn_tab.allocate (space_dimension_IN , Nval_IN);
	
	is_inSDn_in_new_space_tab.allocate (space_dimension_IN);

	reordering_bin_phases_n.allocate (space_dimension_IN);
	
	files_IN_tables_read_pp_nn_one_nucleon (full_common_vectors_used_in_file , PSI_IN_qn , M_IN , neut_data , inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n);
      } break;
		
    case PROTONS_NEUTRONS:
      {
	inSDp_tab.allocate (space_dimension_IN , Zval_IN);
	inSDn_tab.allocate (space_dimension_IN , Nval_IN);
	
	is_inSDp_in_new_space_tab.allocate (space_dimension_IN);
	is_inSDn_in_new_space_tab.allocate (space_dimension_IN);

	reordering_bin_phases_p.allocate (space_dimension_IN);
	reordering_bin_phases_n.allocate (space_dimension_IN);

	files_IN_tables_read_pn_one_nucleon (full_common_vectors_used_in_file , Zval_IN , Nval_IN , PSI_IN_qn , M_IN , prot_data , neut_data , inSDp_tab , inSDn_tab , PSI_IN_component_tab ,
					     is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n);
      } break;
      
    default: abort_all ();
    }
    
  ofstream outfile;

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      outfile.open (outfile_name.c_str ());

      outfile.precision (15);
    }
  
  for (unsigned int sa = 0 ; sa < N_nlj_a ; sa++)
    for (unsigned int sb = 0 ; sb < N_nlj_b ; sb++)
      for (unsigned int sc = 0 ; sc < N_nlj_c ; sc++)
	{
	  const bool ab_shells_ordered = ((particle_a != particle_b) || (sa <= sb));
	  const bool bc_shells_ordered = ((particle_b != particle_c) || (sb <= sc));
	  	  
	  if (!are_ab_coupled_first && !bc_shells_ordered)  continue;
	  if ( are_ab_coupled_first && !ab_shells_ordered)  continue;
  		
	  const class nlj_struct &shell_sa_qn = shells_a_qn(sa);
	  const class nlj_struct &shell_sb_qn = shells_b_qn(sb);
	  const class nlj_struct &shell_sc_qn = shells_c_qn(sc);

	  const bool frozen_state_a = shell_sa_qn.get_frozen_state ();
	  const bool frozen_state_b = shell_sb_qn.get_frozen_state ();
	  const bool frozen_state_c = shell_sc_qn.get_frozen_state ();

	  if (!frozen_state_a && !frozen_state_b && !frozen_state_c)
	    {	
	      const int la = shell_sa_qn.get_l ();
	      const int lb = shell_sb_qn.get_l ();
	      const int lc = shell_sc_qn.get_l ();

	      const unsigned int bp_abc = binary_parity_from_orbital_angular_momentum (la + lb + lc);

	      if (bp_abc == BP_dagger_tilde)
		{
		  const double ja = shell_sa_qn.get_j ();
		  const double jb = shell_sb_qn.get_j ();
		  const double jc = shell_sc_qn.get_j ();
	      
		  class uncoupled_dagger_tilde_table<TYPE> three_body_MK_table(ja , jb , jc);

		  switch (space)
		    {
		    case PROTONS_ONLY:
		      {
			if (is_it_a_dagger_a_tilde_a_tilde)
			  a_dagger_a_tilde_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
									inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , three_body_MK_table);

			if (is_it_a_dagger_a_dagger_a_tilde)
			  a_dagger_a_dagger_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
									 inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , three_body_MK_table);

			if (is_it_a_dagger_a_dagger_a_dagger)
			  a_dagger_a_dagger_a_dagger_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
									  inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , three_body_MK_table);
		      
			if (is_it_a_tilde_a_tilde_a_tilde)
			  a_tilde_a_tilde_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
								       inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , three_body_MK_table);
		      } break;

		    case NEUTRONS_ONLY:
		      {
			if (is_it_a_dagger_a_tilde_a_tilde)
			  a_dagger_a_tilde_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
									inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , three_body_MK_table);

			if (is_it_a_dagger_a_dagger_a_tilde)
			  a_dagger_a_dagger_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
									 inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , three_body_MK_table);

			if (is_it_a_dagger_a_dagger_a_dagger)
			  a_dagger_a_dagger_a_dagger_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
									  inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , three_body_MK_table);
		      
			if (is_it_a_tilde_a_tilde_a_tilde)
			  a_tilde_a_tilde_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
								       inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , three_body_MK_table);
		     
		      } break;
		
		    case PROTONS_NEUTRONS:
		      {
			if (is_it_a_dagger_a_tilde_a_tilde)
			  a_dagger_a_tilde_a_tilde_MK_table_pn_calc (dagger_tilde_operator , shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
								     inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
								     reordering_bin_phases_p , reordering_bin_phases_n , three_body_MK_table);

			if (is_it_a_dagger_a_dagger_a_tilde)
			  a_dagger_a_dagger_a_tilde_MK_table_pn_calc (dagger_tilde_operator , shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
								      inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
								      reordering_bin_phases_p , reordering_bin_phases_n , three_body_MK_table);

			if (is_it_a_dagger_a_dagger_a_dagger)
			  a_dagger_a_dagger_a_dagger_MK_table_pn_calc (dagger_tilde_operator , shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
								       inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
								       reordering_bin_phases_p , reordering_bin_phases_n , three_body_MK_table);
		      
			if (is_it_a_tilde_a_tilde_a_tilde)
			  a_tilde_a_tilde_a_tilde_MK_table_pn_calc (dagger_tilde_operator , shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full ,
								    inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
								    reordering_bin_phases_p , reordering_bin_phases_n , three_body_MK_table);
		      } break;
		    
		    default: abort_all ();
		    }

		  if (THIS_PROCESS == MASTER_PROCESS)
		    {
		      class coupled_dagger_tilde_table<TYPE> three_body_L_K_table(dagger_tilde_operator , ja , jb , jc);

		      three_body_L_K_table_from_MK_table_calc (J_IN , J_OUT , M_IN , M_OUT , CGs , K_reducing_terms , three_body_MK_table , three_body_L_K_table);
			  
		      const bool are_ab_same_shell = ((particle_a == particle_b) && same_nlj (shell_sa_qn , shell_sb_qn));
		      const bool are_bc_same_shell = ((particle_b == particle_c) && same_nlj (shell_sb_qn , shell_sc_qn));
		      
		      const bool is_it_same_shell_case = (are_ab_coupled_first) ? (are_ab_same_shell) : (are_bc_same_shell);
		      
		      const int Lmin = make_int (three_body_L_K_table.get_Lmin ());
		      const int Lmax = make_int (three_body_L_K_table.get_Lmax ());

		      bool is_it_to_write = false;
	      
		      for (int L = Lmin ; L <= Lmax ; L++)
			{
			  if (!is_it_to_write)
			    {
			      const double Kmin_j = (are_ab_coupled_first) ? (abs (jc - L)) : (abs (ja - L));
			      
			      const double Kmax_j = (are_ab_coupled_first) ? (jc + L) : (ja + L);
		      
			      const double Kmin = max (Kmin_PSI , Kmin_j);
			      const double Kmax = min (Kmax_PSI , Kmax_j);
		      
			      is_it_to_write = ((!is_it_same_shell_case || (minus_one_pow (L) == 1)) && (make_int (Kmax - Kmin) >= 0));
			    } 
			}
	      
		      if (is_it_to_write)
			{
			  if (are_ab_coupled_first)
			    {
			      outfile << "[[" << shell_sa_qn;

			      if (!is_it_dagger_a) outfile << "~";

			      outfile << " " << shell_sb_qn;

			      if (!is_it_dagger_b) outfile << "~";
			
			      outfile << "]^L " << shell_sc_qn;
			  
			      if (!is_it_dagger_c) outfile << "~";
			    }
			  else
			    {
			      outfile << "[" << shell_sa_qn;

			      if (!is_it_dagger_a) outfile << "~";

			      outfile << "[" << shell_sb_qn;

			      if (!is_it_dagger_b) outfile << "~";
			
			      outfile << " " << shell_sc_qn;
			  
			      if (!is_it_dagger_c) outfile << "~";
			      
			      outfile << "]^L";
			    }
			  
			  outfile << "]^K" << endl;

			  for (int L = Lmin ; L <= Lmax ; L++)
			    {
			      if (!is_it_same_shell_case || (minus_one_pow (L) == 1))
				{
				  const double Kmin_j = (are_ab_coupled_first) ? (abs (jc - L)) : (abs (ja - L));
				  
				  const double Kmax_j = (are_ab_coupled_first) ? (jc + L) : (ja + L);
			
				  const double Kmin = max (Kmin_PSI , Kmin_j);
				  const double Kmax = min (Kmax_PSI , Kmax_j);

				  for (double K = Kmin ; make_int (K - Kmax) <= 0 ; K++) outfile << L << " " << K << " " << three_body_L_K_table(L , K) << endl;
				}
			    }
		  
			  outfile << endl;
			  
			}}}}}
}














void dagger_tilde_operators::PQG_uncoupled_MEs_table_calc (
							   const bool full_common_vectors_used_in_file , 
							   const enum dagger_tilde_operator_type dagger_tilde_operator ,
							   const class correlated_state_str &PSI_IN_qn , 
							   class GSM_vector_helper_class &GSM_vector_helper_IN ,
							   class array<TYPE> &PQG_uncoupled_MEs_table)
{
  if (!is_it_two_body_determine (dagger_tilde_operator)) error_message_print_abort ("Two-body operators only in dagger_tilde_operators::PQG_uncoupled_MEs_tables_calc_store");
  
  if (!is_it_RDM_determine (dagger_tilde_operator)) error_message_print_abort ("RDM operators only in dagger_tilde_operators::PQG_uncoupled_MEs_tables_calc_store");

  const bool is_it_dagger_a = is_it_dagger_determine (dagger_tilde_operator , 0);
  const bool is_it_dagger_b = is_it_dagger_determine (dagger_tilde_operator , 1);
  const bool is_it_dagger_c = is_it_dagger_determine (dagger_tilde_operator , 3);
  const bool is_it_dagger_d = is_it_dagger_determine (dagger_tilde_operator , 2);
  
  const bool is_it_a_dagger_a_dagger_ab = ( is_it_dagger_a &&  is_it_dagger_b);
  const bool is_it_a_tilde_a_tilde_ab   = (!is_it_dagger_a && !is_it_dagger_b);
    
  const bool is_it_a_dagger_a_tilde_dc  = ( is_it_dagger_d && !is_it_dagger_c);
  const bool is_it_a_dagger_a_dagger_dc = ( is_it_dagger_d &&  is_it_dagger_c);
  const bool is_it_a_tilde_a_tilde_dc   = (!is_it_dagger_d && !is_it_dagger_c);
  
  const enum space_type space = GSM_vector_helper_IN.get_space ();

  const enum interaction_type inter = GSM_vector_helper_IN.get_inter ();

  const bool truncation_hw = GSM_vector_helper_IN.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_IN.get_truncation_ph ();

  const int n_holes_max_p = GSM_vector_helper_IN.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_IN.get_n_holes_max_n ();

  const int n_holes_max = GSM_vector_helper_IN.get_n_holes_max ();
  
  const int n_scat_max_p_init = GSM_vector_helper_IN.get_n_scat_max_p ();
  const int n_scat_max_n_init = GSM_vector_helper_IN.get_n_scat_max_n ();
  
  const int n_scat_max_init = GSM_vector_helper_IN.get_n_scat_max ();
  
  const int Ep_max_hw = GSM_vector_helper_IN.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_IN.get_En_max_hw ();

  const int E_max_hw = GSM_vector_helper_IN.get_E_max_hw ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_IN.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_IN.get_neut_data ();

  const class nucleons_data &data_a = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
  const class nucleons_data &data_b = data_find (dagger_tilde_operator , 1 , prot_data , neut_data);
  const class nucleons_data &data_c = data_find (dagger_tilde_operator , 3 , prot_data , neut_data);
  const class nucleons_data &data_d = data_find (dagger_tilde_operator , 2 , prot_data , neut_data);
  
  const unsigned int N_nljm_a = data_a.get_N_nljm ();
  const unsigned int N_nljm_b = data_b.get_N_nljm ();
  const unsigned int N_nljm_c = data_c.get_N_nljm ();
  const unsigned int N_nljm_d = data_d.get_N_nljm ();

  const unsigned int BP_IN = GSM_vector_helper_IN.get_BP ();
  
  const double M_IN = GSM_vector_helper_IN.get_M ();

  const class one_body_indices_str &one_body_a_indices = data_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_b_indices = data_b.get_one_body_indices ();
    
  const enum particle_type particle_a = data_a.get_particle ();
  const enum particle_type particle_b = data_b.get_particle ();
  const enum particle_type particle_c = data_c.get_particle ();
  const enum particle_type particle_d = data_d.get_particle ();
  
  const bool particles_ab_different = (particle_a != particle_b);
  const bool particles_cd_different = (particle_c != particle_d);
  
  const double ma_max = data_a.get_m_max ();
  const double mb_max = data_b.get_m_max ();
  const double mc_max = data_c.get_m_max ();
  const double md_max = data_d.get_m_max ();
    
  const int ma_max_plus_mb_max = make_int (ma_max + mb_max);
  const int mc_max_plus_md_max = make_int (mc_max + md_max);
  
  const int two_ma_max = data_a.get_two_m_max ();
  const int two_mb_max = data_b.get_two_m_max ();

  const class array<class nljm_struct> &phi_table_a = data_a.get_phi_table ();
  const class array<class nljm_struct> &phi_table_b = data_b.get_phi_table ();
  const class array<class nljm_struct> &phi_table_d = data_d.get_phi_table ();
  const class array<class nljm_struct> &phi_table_c = data_c.get_phi_table ();

  const int Zval_IN = prot_data.get_N_valence_nucleons ();
  const int Nval_IN = neut_data.get_N_valence_nucleons ();
        
  const int Zval_OUT = Z_OUT_calc (dagger_tilde_operator , Zval_IN);
  const int Nval_OUT = N_OUT_calc (dagger_tilde_operator , Nval_IN);

  if ((Zval_OUT < 0) || (Nval_OUT < 0)) return;
  
  const int Z_IN = prot_data.get_N_nucleons ();
  const int N_IN = neut_data.get_N_nucleons ();
      
  const int Z_OUT = Z_OUT_calc (dagger_tilde_operator , Z_IN);
  const int N_OUT = N_OUT_calc (dagger_tilde_operator , N_IN);
    
  const double prot_mass_for_calc = prot_data.get_effective_mass_for_calc ();
  const double neut_mass_for_calc = neut_data.get_effective_mass_for_calc ();

  const double nucleus_mass_OUT = Z_OUT*prot_mass_for_calc + N_OUT*neut_mass_for_calc;
      
  const unsigned int space_dimension_IN = (full_common_vectors_used_in_file) ? (GSM_vector_helper_IN.get_total_space_dimension ()) : (GSM_vector_helper_IN.get_space_dimension_process ());
  
  class array<unsigned int> inSDp_tab;
  class array<unsigned int> inSDn_tab;

  class nucleons_data prot_data_OUT;
  class nucleons_data neut_data_OUT;
	
  prot_data_OUT.initialize_constants_from_other_nucleus (false , Z_OUT , N_OUT , nucleus_mass_OUT , prot_data);
  neut_data_OUT.initialize_constants_from_other_nucleus (false , Z_OUT , N_OUT , nucleus_mass_OUT , neut_data);
  
  prot_data_OUT.alloc_copy_one_body_data_tables_E_min_max_hw (prot_data);
  neut_data_OUT.alloc_copy_one_body_data_tables_E_min_max_hw (neut_data);
  
  const int n_scat_max_p = n_scat_max_pp_nn_calc (truncation_ph , n_scat_max_p_init , prot_data_OUT);
  const int n_scat_max_n = n_scat_max_pp_nn_calc (truncation_ph , n_scat_max_n_init , neut_data_OUT);

  const int n_scat_max = n_scat_max_pn_calc (truncation_ph , n_scat_max_init , prot_data_OUT , neut_data_OUT);

  prot_data_OUT.set_n_scat_max (n_scat_max_p);
  neut_data_OUT.set_n_scat_max (n_scat_max_n);
  
  class GSM_vector PSI_IN(GSM_vector_helper_IN);

  PSI_IN.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_IN_qn);
  
  switch (space)
    {
    case PROTONS_ONLY:
      {
	inSDp_tab.allocate (space_dimension_IN , Zval_IN);
	
	PSI_IN.get_SDs_pp_nn (inSDp_tab);
	
	configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , prot_data_OUT);
	
	SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , prot_data_OUT , false);

      } break;

    case NEUTRONS_ONLY:
      {
	inSDn_tab.allocate (space_dimension_IN , Nval_IN);
	
	PSI_IN.get_SDs_pp_nn (inSDn_tab);
	
	configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , neut_data_OUT);
	
	SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , neut_data_OUT , false);
      } break;
		
    case PROTONS_NEUTRONS:
      {
	inSDp_tab.allocate (space_dimension_IN , Zval_IN);
	inSDn_tab.allocate (space_dimension_IN , Nval_IN);
	
	PSI_IN.get_SDs_pn (inSDp_tab , inSDn_tab);
	
	configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , prot_data_OUT);
	configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , neut_data_OUT);
	
	SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , prot_data_OUT , false);
	SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , neut_data_OUT , false);
      } break;
      
    default: abort_all ();
    }

  class array<class GSM_vector_helper_class> PSI_OUT_full_helpers(N_nljm_c , N_nljm_d);
  
  class array<class GSM_vector> PSI_OUT_full_tab(N_nljm_c , N_nljm_d);
    
  for (unsigned int sc = 0 ; sc < N_nljm_c ; sc++)
    for (unsigned int sd = 0 ; sd < N_nljm_d ; sd++)
      {
	const class nljm_struct &phi_c = phi_table_c(sc);
	const class nljm_struct &phi_d = phi_table_d(sd);

	const unsigned int sc_shell_index = phi_c.get_shell_index (); 
	const unsigned int sd_shell_index = phi_d.get_shell_index ();
	    
	const bool cd_shells_ordered = (particles_cd_different || (sc_shell_index <= sd_shell_index));

	if (is_it_a_dagger_a_dagger_dc && !cd_shells_ordered) continue;
	if (is_it_a_tilde_a_tilde_dc   && !cd_shells_ordered) continue;
		  
	const bool frozen_state_c = phi_c.get_frozen_state ();
	const bool frozen_state_d = phi_d.get_frozen_state ();
		    
	if (!frozen_state_c && !frozen_state_d)
	  {	
	    const int lc = phi_c.get_l ();
	    const int ld = phi_d.get_l ();

	    const unsigned int bp_cd = binary_parity_from_orbital_angular_momentum (lc + ld);

	    const unsigned int BP_OUT = binary_parity_product (BP_IN , bp_cd);

	    const int im_c = phi_c.get_im ();
	    const int im_d = phi_d.get_im ();
	    
	    const int MK = im_c + im_d - mc_max_plus_md_max;
	    
	    const double M_OUT = MK + M_IN;

	    class GSM_vector_helper_class &PSI_OUT_full_helper = PSI_OUT_full_helpers(sc , sd);
	    
	    class GSM_vector &PSI_OUT_full = PSI_OUT_full_tab(sc , sd);
		
	    PSI_OUT_full_helper.allocate (false , space , inter , false , truncation_hw , truncation_ph ,
					  n_holes_max   , n_scat_max   , E_max_hw  ,
					  n_holes_max_p , n_scat_max_p , Ep_max_hw ,
					  n_holes_max_n , n_scat_max_n , En_max_hw , BP_OUT , M_OUT , false , prot_data_OUT , neut_data_OUT);

	    PSI_OUT_full.allocate (PSI_OUT_full_helper);
		
	    switch (space)
	      {
	      case PROTONS_ONLY:
		{
		  if (is_it_a_dagger_a_tilde_dc)  a_dagger_a_tilde_MK_RDM_pp_nn_calc  (dagger_tilde_operator , phi_d , phi_c , inSDp_tab , PSI_IN , PSI_OUT_full);
		  if (is_it_a_dagger_a_dagger_dc) a_dagger_a_dagger_MK_RDM_pp_nn_calc (dagger_tilde_operator , phi_d , phi_c , inSDp_tab , PSI_IN , PSI_OUT_full);
		  if (is_it_a_tilde_a_tilde_dc)   a_tilde_a_tilde_MK_RDM_pp_nn_calc   (dagger_tilde_operator , phi_d , phi_c , inSDp_tab , PSI_IN , PSI_OUT_full);

		} break;

	      case NEUTRONS_ONLY:
		{
		  if (is_it_a_dagger_a_tilde_dc)  a_dagger_a_tilde_MK_RDM_pp_nn_calc  (dagger_tilde_operator , phi_d , phi_c , inSDn_tab , PSI_IN , PSI_OUT_full);
		  if (is_it_a_dagger_a_dagger_dc) a_dagger_a_dagger_MK_RDM_pp_nn_calc (dagger_tilde_operator , phi_d , phi_c , inSDn_tab , PSI_IN , PSI_OUT_full);
		  if (is_it_a_tilde_a_tilde_dc)   a_tilde_a_tilde_MK_RDM_pp_nn_calc   (dagger_tilde_operator , phi_d , phi_c , inSDn_tab , PSI_IN , PSI_OUT_full);
		  
		} break;
		
	      case PROTONS_NEUTRONS:
		{
		  if (is_it_a_dagger_a_tilde_dc)  a_dagger_a_tilde_MK_RDM_pn_calc  (dagger_tilde_operator , phi_d , phi_c , inSDp_tab , inSDn_tab , PSI_IN , PSI_OUT_full);
		  if (is_it_a_dagger_a_dagger_dc) a_dagger_a_dagger_MK_RDM_pn_calc (dagger_tilde_operator , phi_d , phi_c , inSDp_tab , inSDn_tab , PSI_IN , PSI_OUT_full);		      
		  if (is_it_a_tilde_a_tilde_dc)   a_tilde_a_tilde_MK_RDM_pn_calc   (dagger_tilde_operator , phi_d , phi_c , inSDp_tab , inSDn_tab , PSI_IN , PSI_OUT_full);
		      
		} break;
		    
	      default: abort_all ();
	      }
	  }
      }

  const unsigned int abcd_total_indices_dimension = N_nljm_a*N_nljm_b*N_nljm_c*N_nljm_d;

  const unsigned int first_abcd_total_index = basic_first_index_determine_for_MPI (abcd_total_indices_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_abcd_total_index = basic_last_index_determine_for_MPI (abcd_total_indices_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);

  const bool is_process_active = is_process_active_for_MPI (abcd_total_indices_dimension ,  THIS_PROCESS);
    
  class array<unsigned int> a_nljm_indices(abcd_total_indices_dimension) , b_nljm_indices(abcd_total_indices_dimension);
  class array<unsigned int> c_nljm_indices(abcd_total_indices_dimension) , d_nljm_indices(abcd_total_indices_dimension);

  unsigned int total_index = 0;
  
  for (unsigned int sa = 0 ; sa < N_nljm_a ; sa++)
    for (unsigned int sb = 0 ; sb < N_nljm_b ; sb++)
      for (unsigned int sc = 0 ; sc < N_nljm_c ; sc++)
	for (unsigned int sd = 0 ; sd < N_nljm_d ; sd++)
	  {	    
	    a_nljm_indices(total_index) = sa , b_nljm_indices(total_index) = sb;
	    c_nljm_indices(total_index) = sc , d_nljm_indices(total_index) = sd;

	    total_index++;
	  }

  if (is_process_active)
    {
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int abcd_total_index = first_abcd_total_index ; abcd_total_index <= last_abcd_total_index ; abcd_total_index++)
	{
	  const unsigned int sa = a_nljm_indices(abcd_total_index) , sb = b_nljm_indices(abcd_total_index);
	  const unsigned int sc = c_nljm_indices(abcd_total_index) , sd = d_nljm_indices(abcd_total_index);
      
	  const class nljm_struct &phi_a = phi_table_a(sa) , &phi_b = phi_table_b(sb);
	  const class nljm_struct &phi_c = phi_table_c(sc) , &phi_d = phi_table_d(sd);

	  const bool frozen_state_a = phi_a.get_frozen_state () , frozen_state_b = phi_b.get_frozen_state ();
	  const bool frozen_state_c = phi_c.get_frozen_state () , frozen_state_d = phi_d.get_frozen_state ();
		    
	  if (!frozen_state_a && !frozen_state_b && !frozen_state_c && !frozen_state_d)
	    {	
	      const int la = phi_a.get_l () , lb = phi_b.get_l ();
	      const int lc = phi_c.get_l () , ld = phi_d.get_l ();
	    
	      const unsigned int sa_shell_index = phi_a.get_shell_index () , sb_shell_index = phi_b.get_shell_index (); 
	      const unsigned int sc_shell_index = phi_c.get_shell_index () , sd_shell_index = phi_d.get_shell_index ();

	      const bool ab_shells_ordered = (particles_ab_different || (sa_shell_index <= sb_shell_index));
	      const bool cd_shells_ordered = (particles_cd_different || (sc_shell_index <= sd_shell_index));

	      if (is_it_a_dagger_a_dagger_ab && !ab_shells_ordered) continue;
	      if (is_it_a_tilde_a_tilde_ab   && !ab_shells_ordered) continue;
		  
	      if (is_it_a_dagger_a_dagger_dc && !cd_shells_ordered) continue;
	      if (is_it_a_tilde_a_tilde_dc   && !cd_shells_ordered) continue;
		  		  
	      const unsigned int bp_ab = binary_parity_from_orbital_angular_momentum (la + lb);
	      const unsigned int bp_cd = binary_parity_from_orbital_angular_momentum (lc + ld);
		      
	      if (bp_ab == bp_cd)
		{
		  const int im_a = phi_a.get_im () , im_b = phi_b.get_im ();
		  const int im_c = phi_c.get_im () , im_d = phi_d.get_im ();
		      
		  const int im_a_minus = two_ma_max - im_a;
		  const int im_b_minus = two_mb_max - im_b;
	    
		  const unsigned int sa_minus = one_body_a_indices(sa_shell_index , im_a_minus);
		  const unsigned int sb_minus = one_body_b_indices(sb_shell_index , im_b_minus);
		    
		  const int MK_ab = im_a + im_b - ma_max_plus_mb_max;		    
		  const int MK_cd = im_c + im_d - mc_max_plus_md_max;
	    			      
		  if (MK_ab == MK_cd)
		    {			      
		      const class GSM_vector &PSI_OUT_full_ab = PSI_OUT_full_tab(sa , sb);
		      const class GSM_vector &PSI_OUT_full_cd = PSI_OUT_full_tab(sc , sd);
			  			  
		      const unsigned int sd_shell_index = phi_d.get_shell_index ();

		      if (is_it_a_tilde_a_tilde_dc)   PQG_uncoupled_MEs_table(sa_minus , sb_minus , sc , sd_shell_index) = PSI_OUT_full_ab*PSI_OUT_full_cd;
		      if (is_it_a_dagger_a_dagger_dc) PQG_uncoupled_MEs_table(sa_minus , sb_minus , sc , sd_shell_index) = PSI_OUT_full_ab*PSI_OUT_full_cd;
		      if (is_it_a_dagger_a_tilde_dc)  PQG_uncoupled_MEs_table(sa_minus , sb_minus , sc , sd_shell_index) = PSI_OUT_full_ab*PSI_OUT_full_cd;
						      
		    }}}}}
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PQG_uncoupled_MEs_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}






void dagger_tilde_operators::T1_T2_part_uncoupled_MEs_table_calc (
								  const bool full_common_vectors_used_in_file , 
								  const enum dagger_tilde_operator_type dagger_tilde_operator ,
								  const class correlated_state_str &PSI_IN_qn ,
								  class GSM_vector_helper_class &GSM_vector_helper_IN ,
								  class array<TYPE> &T1_T2_part_uncoupled_MEs_table)
{
  if (is_it_two_body_determine (dagger_tilde_operator)) error_message_print_abort ("Three-body operators only in dagger_tilde_operators::T1_T2_part_uncoupled_MEs_table");
  
  if (!is_it_RDM_determine (dagger_tilde_operator)) error_message_print_abort ("RDM operators only in dagger_tilde_operators::T1_T2_part_uncoupled_MEs_tables_calc");

  const bool is_it_dagger_a = is_it_dagger_determine (dagger_tilde_operator , 0);
  const bool is_it_dagger_b = is_it_dagger_determine (dagger_tilde_operator , 1);
  const bool is_it_dagger_c = is_it_dagger_determine (dagger_tilde_operator , 2);
  const bool is_it_dagger_d = is_it_dagger_determine (dagger_tilde_operator , 5);
  const bool is_it_dagger_e = is_it_dagger_determine (dagger_tilde_operator , 4);
  const bool is_it_dagger_f = is_it_dagger_determine (dagger_tilde_operator , 3);
  
  const bool is_it_a_dagger_a_dagger_a_dagger_abc = ( is_it_dagger_a &&  is_it_dagger_b &&  is_it_dagger_c); 
  const bool is_it_a_dagger_a_dagger_a_tilde_abc  = ( is_it_dagger_a &&  is_it_dagger_b && !is_it_dagger_c);
    
  const bool is_it_a_dagger_a_tilde_a_tilde_fed   = ( is_it_dagger_f && !is_it_dagger_e && !is_it_dagger_d);
  const bool is_it_a_dagger_a_dagger_a_tilde_fed  = ( is_it_dagger_f &&  is_it_dagger_e && !is_it_dagger_d);
  const bool is_it_a_dagger_a_dagger_a_dagger_fed = ( is_it_dagger_f &&  is_it_dagger_e &&  is_it_dagger_d);
  const bool is_it_a_tilde_a_tilde_a_tilde_fed    = (!is_it_dagger_f && !is_it_dagger_e && !is_it_dagger_d);
  
  const bool are_ab_coupled_first = (is_it_a_dagger_a_dagger_a_dagger_abc || is_it_a_dagger_a_dagger_a_tilde_abc);

  const bool are_de_coupled_first = (is_it_a_tilde_a_tilde_a_tilde_fed || is_it_a_dagger_a_tilde_a_tilde_fed);
        
  const enum space_type space = GSM_vector_helper_IN.get_space ();

  const enum interaction_type inter = GSM_vector_helper_IN.get_inter ();

  const bool truncation_hw = GSM_vector_helper_IN.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_IN.get_truncation_ph ();

  const int n_holes_max_p = GSM_vector_helper_IN.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_IN.get_n_holes_max_n ();

  const int n_holes_max = GSM_vector_helper_IN.get_n_holes_max ();
  
  const int n_scat_max_p_init = GSM_vector_helper_IN.get_n_scat_max_p ();
  const int n_scat_max_n_init = GSM_vector_helper_IN.get_n_scat_max_n ();
  
  const int n_scat_max_init = GSM_vector_helper_IN.get_n_scat_max ();
    
  const int Ep_max_hw = GSM_vector_helper_IN.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_IN.get_En_max_hw ();

  const int E_max_hw = GSM_vector_helper_IN.get_E_max_hw ();

  const class nucleons_data &prot_data = GSM_vector_helper_IN.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_IN.get_neut_data ();
  
  const class nucleons_data &data_a = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
  const class nucleons_data &data_b = data_find (dagger_tilde_operator , 1 , prot_data , neut_data);
  const class nucleons_data &data_c = data_find (dagger_tilde_operator , 2 , prot_data , neut_data);
  const class nucleons_data &data_d = data_find (dagger_tilde_operator , 5 , prot_data , neut_data);
  const class nucleons_data &data_e = data_find (dagger_tilde_operator , 4 , prot_data , neut_data);
  const class nucleons_data &data_f = data_find (dagger_tilde_operator , 3 , prot_data , neut_data);
    
  const enum particle_type particle_a = data_a.get_particle ();
  const enum particle_type particle_b = data_b.get_particle ();
  const enum particle_type particle_c = data_c.get_particle ();
  const enum particle_type particle_d = data_d.get_particle ();
  const enum particle_type particle_e = data_e.get_particle ();
  const enum particle_type particle_f = data_f.get_particle ();
  
  const bool particles_ab_different = (particle_a != particle_b);
  const bool particles_bc_different = (particle_b != particle_c);
  
  const bool particles_de_different = (particle_d != particle_e);
  const bool particles_ef_different = (particle_e != particle_f);
  
  const int two_ma_max = data_a.get_two_m_max ();
  const int two_mb_max = data_b.get_two_m_max ();
  const int two_mc_max = data_c.get_two_m_max ();
  
  const unsigned int N_nljm_a = data_a.get_N_nljm ();
  const unsigned int N_nljm_b = data_b.get_N_nljm ();
  const unsigned int N_nljm_c = data_c.get_N_nljm ();
  const unsigned int N_nljm_d = data_d.get_N_nljm ();
  const unsigned int N_nljm_e = data_e.get_N_nljm ();
  const unsigned int N_nljm_f = data_f.get_N_nljm ();

  const unsigned int BP_IN = GSM_vector_helper_IN.get_BP ();
  
  const double M_IN = GSM_vector_helper_IN.get_M ();

  const class array<class nljm_struct> &phi_table_a = data_a.get_phi_table ();
  const class array<class nljm_struct> &phi_table_b = data_b.get_phi_table ();
  const class array<class nljm_struct> &phi_table_c = data_c.get_phi_table ();
  const class array<class nljm_struct> &phi_table_d = data_d.get_phi_table ();
  const class array<class nljm_struct> &phi_table_e = data_e.get_phi_table ();
  const class array<class nljm_struct> &phi_table_f = data_f.get_phi_table ();
  
  const class one_body_indices_str &one_body_a_indices = data_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_b_indices = data_b.get_one_body_indices ();
  const class one_body_indices_str &one_body_c_indices = data_c.get_one_body_indices ();
  
  const int Zval_IN = prot_data.get_N_valence_nucleons ();
  const int Nval_IN = neut_data.get_N_valence_nucleons ();
  
  const int Zval_OUT = Z_OUT_calc (dagger_tilde_operator , Zval_IN);
  const int Nval_OUT = N_OUT_calc (dagger_tilde_operator , Nval_IN);
  
  if ((Zval_OUT < 0) || (Nval_OUT < 0)) return;
  
  const int Z_IN = prot_data.get_N_nucleons ();
  const int N_IN = neut_data.get_N_nucleons ();
  
  const int Z_OUT = Z_OUT_calc (dagger_tilde_operator , Z_IN);
  const int N_OUT = N_OUT_calc (dagger_tilde_operator , N_IN);
    
  const double prot_mass_for_calc = prot_data.get_effective_mass_for_calc ();
  const double neut_mass_for_calc = neut_data.get_effective_mass_for_calc ();

  const double nucleus_mass_OUT = Z_OUT*prot_mass_for_calc + N_OUT*neut_mass_for_calc;
        
  const unsigned int space_dimension_IN = (full_common_vectors_used_in_file) ? (GSM_vector_helper_IN.get_total_space_dimension ()) : (GSM_vector_helper_IN.get_space_dimension_process ());
  
  class array<unsigned int> inSDp_tab;
  class array<unsigned int> inSDn_tab;

  class nucleons_data prot_data_OUT;
  class nucleons_data neut_data_OUT;
	
  prot_data_OUT.initialize_constants_from_other_nucleus (false , Z_OUT , N_OUT , nucleus_mass_OUT , prot_data);
  neut_data_OUT.initialize_constants_from_other_nucleus (false , Z_OUT , N_OUT , nucleus_mass_OUT , neut_data);
  
  prot_data_OUT.alloc_copy_one_body_data_tables_E_min_max_hw (prot_data);
  neut_data_OUT.alloc_copy_one_body_data_tables_E_min_max_hw (neut_data);
   
  const int n_scat_max_p = n_scat_max_pp_nn_calc (truncation_ph , n_scat_max_p_init , prot_data_OUT);
  const int n_scat_max_n = n_scat_max_pp_nn_calc (truncation_ph , n_scat_max_n_init , neut_data_OUT);

  const int n_scat_max = n_scat_max_pn_calc (truncation_ph , n_scat_max_init , prot_data_OUT , neut_data_OUT);

  prot_data_OUT.set_n_scat_max (n_scat_max_p);
  neut_data_OUT.set_n_scat_max (n_scat_max_n);
  
  class GSM_vector PSI_IN(GSM_vector_helper_IN);

  PSI_IN.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_IN_qn);
  
  switch (space)
    {
    case PROTONS_ONLY:
      {
	inSDp_tab.allocate (space_dimension_IN , Zval_IN);
	
	PSI_IN.get_SDs_pp_nn (inSDp_tab);
	
	configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , prot_data_OUT);
	
	SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , prot_data_OUT , false);

      } break;

    case NEUTRONS_ONLY:
      {
	inSDn_tab.allocate (space_dimension_IN , Nval_IN);
	
	PSI_IN.get_SDs_pp_nn (inSDn_tab);
	
	configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , neut_data_OUT);
	
	SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , neut_data_OUT , false);
      } break;
		
    case PROTONS_NEUTRONS:
      {
	inSDp_tab.allocate (space_dimension_IN , Zval_IN);
	inSDn_tab.allocate (space_dimension_IN , Nval_IN);
	
	PSI_IN.get_SDs_pn (inSDp_tab , inSDn_tab);
	
	configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , prot_data_OUT);
	configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , neut_data_OUT);
	
	SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , prot_data_OUT , false);
	SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , neut_data_OUT , false);
      } break;
      
    default: abort_all ();
    }

  class array<class GSM_vector_helper_class> PSI_OUT_full_helpers(N_nljm_d , N_nljm_e , N_nljm_f);
  
  class array<class GSM_vector> PSI_OUT_full_tab(N_nljm_d , N_nljm_e , N_nljm_f);
  
  for (unsigned int sd = 0 ; sd < N_nljm_d ; sd++)
    for (unsigned int se = 0 ; se < N_nljm_e ; se++)
      for (unsigned int sf = 0 ; sf < N_nljm_f ; sf++)
	{
	  const class nljm_struct &phi_d = phi_table_d(sd);
	  const class nljm_struct &phi_e = phi_table_e(se);
	  const class nljm_struct &phi_f = phi_table_f(sf);

	  const unsigned int sd_shell_index = phi_d.get_shell_index (); 
	  const unsigned int se_shell_index = phi_e.get_shell_index ();
	  const unsigned int sf_shell_index = phi_f.get_shell_index ();
		  
	  const bool de_shells_ordered = (particles_de_different || (sd_shell_index <= se_shell_index));	  
	  const bool fe_shells_ordered = (particles_ef_different || (sf_shell_index <= se_shell_index));
	  
	  if ( are_de_coupled_first && !de_shells_ordered) continue;
	  if (!are_de_coupled_first && !fe_shells_ordered) continue;
	  	  
	  const bool frozen_state_d = phi_d.get_frozen_state ();
	  const bool frozen_state_e = phi_e.get_frozen_state ();
	  const bool frozen_state_f = phi_f.get_frozen_state ();
		    
	  if (!frozen_state_d && !frozen_state_e && !frozen_state_f)
	    {
	      const int ld = phi_d.get_l ();
	      const int le = phi_e.get_l ();
	      const int lf = phi_f.get_l ();

	      const unsigned int bp_def = binary_parity_from_orbital_angular_momentum (ld + le + lf);

	      const unsigned int BP_OUT = binary_parity_product (BP_IN , bp_def);

	      const double md = phi_d.get_m ();
	      const double me = phi_e.get_m ();
	      const double mf = phi_f.get_m ();

	      const double MK = md + me + mf;
	    
	      const double M_OUT = MK + M_IN;

	      class GSM_vector_helper_class &PSI_OUT_full_helper = PSI_OUT_full_helpers(sd , se , sf);
	    
	      class GSM_vector &PSI_OUT_full = PSI_OUT_full_tab(sd , se , sf);
		
	      PSI_OUT_full_helper.allocate (false , space , inter , false , truncation_hw , truncation_ph ,
					    n_holes_max   , n_scat_max   , E_max_hw  ,
					    n_holes_max_p , n_scat_max_p , Ep_max_hw ,
					    n_holes_max_n , n_scat_max_n , En_max_hw , BP_OUT , M_OUT , false , prot_data_OUT , neut_data_OUT);

	      PSI_OUT_full.allocate (PSI_OUT_full_helper);
	      
	      switch (space)
		{
		case PROTONS_ONLY:
		  {
		    if (is_it_a_dagger_a_tilde_a_tilde_fed)   a_dagger_a_tilde_a_tilde_MK_RDM_pp_nn_calc   (dagger_tilde_operator , phi_f , phi_e , phi_d , inSDp_tab , PSI_IN , PSI_OUT_full);
		    if (is_it_a_dagger_a_dagger_a_tilde_fed)  a_dagger_a_dagger_a_tilde_MK_RDM_pp_nn_calc  (dagger_tilde_operator , phi_f , phi_e , phi_d , inSDp_tab , PSI_IN , PSI_OUT_full);
		    if (is_it_a_dagger_a_dagger_a_dagger_fed) a_dagger_a_dagger_a_dagger_MK_RDM_pp_nn_calc (dagger_tilde_operator , phi_f , phi_e , phi_d , inSDp_tab , PSI_IN , PSI_OUT_full);		      
		    if (is_it_a_tilde_a_tilde_a_tilde_fed)    a_tilde_a_tilde_a_tilde_MK_RDM_pp_nn_calc    (dagger_tilde_operator , phi_f , phi_e , phi_d , inSDp_tab , PSI_IN , PSI_OUT_full);
		  
		  } break;

		case NEUTRONS_ONLY:
		  {
		    if (is_it_a_dagger_a_tilde_a_tilde_fed)   a_dagger_a_tilde_a_tilde_MK_RDM_pp_nn_calc   (dagger_tilde_operator , phi_f , phi_e , phi_d , inSDn_tab , PSI_IN , PSI_OUT_full);
		    if (is_it_a_dagger_a_dagger_a_tilde_fed)  a_dagger_a_dagger_a_tilde_MK_RDM_pp_nn_calc  (dagger_tilde_operator , phi_f , phi_e , phi_d , inSDn_tab , PSI_IN , PSI_OUT_full);
		    if (is_it_a_dagger_a_dagger_a_dagger_fed) a_dagger_a_dagger_a_dagger_MK_RDM_pp_nn_calc (dagger_tilde_operator , phi_f , phi_e , phi_d , inSDn_tab , PSI_IN , PSI_OUT_full);		      
		    if (is_it_a_tilde_a_tilde_a_tilde_fed)    a_tilde_a_tilde_a_tilde_MK_RDM_pp_nn_calc    (dagger_tilde_operator , phi_f , phi_e , phi_d , inSDn_tab , PSI_IN , PSI_OUT_full);
		     
		  } break;
		
		case PROTONS_NEUTRONS:
		  {
		    if (is_it_a_dagger_a_tilde_a_tilde_fed)   a_dagger_a_tilde_a_tilde_MK_RDM_pn_calc   (dagger_tilde_operator , phi_f , phi_e , phi_d , inSDp_tab , inSDn_tab , PSI_IN , PSI_OUT_full);
		    if (is_it_a_dagger_a_dagger_a_tilde_fed)  a_dagger_a_dagger_a_tilde_MK_RDM_pn_calc  (dagger_tilde_operator , phi_f , phi_e , phi_d , inSDp_tab , inSDn_tab , PSI_IN , PSI_OUT_full);
		    if (is_it_a_dagger_a_dagger_a_dagger_fed) a_dagger_a_dagger_a_dagger_MK_RDM_pn_calc (dagger_tilde_operator , phi_f , phi_e , phi_d , inSDp_tab , inSDn_tab , PSI_IN , PSI_OUT_full);		      
		    if (is_it_a_tilde_a_tilde_a_tilde_fed)    a_tilde_a_tilde_a_tilde_MK_RDM_pn_calc    (dagger_tilde_operator , phi_f , phi_e , phi_d , inSDp_tab , inSDn_tab , PSI_IN , PSI_OUT_full);
		  } break;
		    
		default: abort_all ();
		}
	    }
	}
 
  const unsigned int abcdef_total_indices_dimension = N_nljm_a*N_nljm_b*N_nljm_c*N_nljm_d*N_nljm_e*N_nljm_f;

  const unsigned int first_abcdef_total_index = basic_first_index_determine_for_MPI (abcdef_total_indices_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_abcdef_total_index = basic_last_index_determine_for_MPI (abcdef_total_indices_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);

  const bool is_process_active = is_process_active_for_MPI (abcdef_total_indices_dimension ,  THIS_PROCESS);
      
  class array<unsigned int> a_nljm_indices(abcdef_total_indices_dimension) , b_nljm_indices(abcdef_total_indices_dimension) , c_nljm_indices(abcdef_total_indices_dimension);
  class array<unsigned int> d_nljm_indices(abcdef_total_indices_dimension) , e_nljm_indices(abcdef_total_indices_dimension) , f_nljm_indices(abcdef_total_indices_dimension);

  unsigned int total_index = 0;
  
  for (unsigned int sa = 0 ; sa < N_nljm_a ; sa++)
    for (unsigned int sb = 0 ; sb < N_nljm_b ; sb++)
      for (unsigned int sc = 0 ; sc < N_nljm_c ; sc++)
	for (unsigned int sd = 0 ; sd < N_nljm_d ; sd++)
	  for (unsigned int se = 0 ; se < N_nljm_e ; se++)
	    for (unsigned int sf = 0 ; sf < N_nljm_f ; sf++)
	      {	    
		a_nljm_indices(total_index) = sa , b_nljm_indices(total_index) = sb , c_nljm_indices(total_index) = sc;
		d_nljm_indices(total_index) = sd , e_nljm_indices(total_index) = se , f_nljm_indices(total_index) = sf;

		total_index++;
	      }

  if (is_process_active)
    {
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int abcdef_total_index = first_abcdef_total_index ; abcdef_total_index <= last_abcdef_total_index ; abcdef_total_index++)
	{		
	  const unsigned int sa = a_nljm_indices(abcdef_total_index) , sb = b_nljm_indices(abcdef_total_index) , sc = c_nljm_indices(abcdef_total_index);
	  const unsigned int sd = d_nljm_indices(abcdef_total_index) , se = e_nljm_indices(abcdef_total_index) , sf = f_nljm_indices(abcdef_total_index);
	  
	  const class nljm_struct &phi_a = phi_table_a(sa) , &phi_b = phi_table_b(sb) , &phi_c = phi_table_c(sc);
	  const class nljm_struct &phi_d = phi_table_d(sd) , &phi_e = phi_table_e(se) , &phi_f = phi_table_f(sf);
	  	  	  	  	  
	  const bool frozen_state_a = phi_a.get_frozen_state () , frozen_state_b = phi_b.get_frozen_state () , frozen_state_c = phi_c.get_frozen_state ();
	  const bool frozen_state_d = phi_d.get_frozen_state () , frozen_state_e = phi_e.get_frozen_state () , frozen_state_f = phi_f.get_frozen_state ();
		    
	  if (!frozen_state_a && !frozen_state_b && !frozen_state_c && !frozen_state_d && !frozen_state_e && !frozen_state_f)
	    {	
	      const unsigned int sa_shell_index = phi_a.get_shell_index () , sb_shell_index = phi_b.get_shell_index () , sc_shell_index = phi_c.get_shell_index ();
	      const unsigned int sd_shell_index = phi_d.get_shell_index () , se_shell_index = phi_e.get_shell_index () , sf_shell_index = phi_f.get_shell_index ();
		  	  
	      const bool ab_shells_ordered = (particles_ab_different || (sa_shell_index <= sb_shell_index)) , cb_shells_ordered = (particles_bc_different || (sc_shell_index <= sb_shell_index));
	      const bool de_shells_ordered = (particles_de_different || (sd_shell_index <= se_shell_index)) , fe_shells_ordered = (particles_ef_different || (sf_shell_index <= se_shell_index));
	      	  
	      if ( are_ab_coupled_first && !ab_shells_ordered) continue;
	      if (!are_ab_coupled_first && !cb_shells_ordered) continue;
	      if ( are_de_coupled_first && !de_shells_ordered) continue;
	      if (!are_de_coupled_first && !fe_shells_ordered) continue;
	      	      	  
	      const int la = phi_a.get_l () , lb = phi_b.get_l () , lc = phi_c.get_l ();
	      const int ld = phi_d.get_l () , le = phi_e.get_l () , lf = phi_f.get_l ();

	      const unsigned int bp_abc = binary_parity_from_orbital_angular_momentum (la + lb + lc);
	      const unsigned int bp_def = binary_parity_from_orbital_angular_momentum (ld + le + lf);

	      if (bp_abc == bp_def)
		{
		  const int im_a = phi_a.get_im () , im_b = phi_b.get_im () , im_c = phi_c.get_im ();
		  const int im_d = phi_d.get_im () , im_e = phi_e.get_im () , im_f = phi_f.get_im ();
	      
		  const int iMK_abc = im_a + im_b + im_c;
		  const int iMK_def = im_d + im_e + im_f;
	    			      
		  if (iMK_abc == iMK_def)
		    {	
		      const int im_a_minus = two_ma_max - im_a;
		      const int im_b_minus = two_mb_max - im_b;
		      const int im_c_minus = two_mc_max - im_c;
	    
		      const unsigned int sa_shell_index = phi_a.get_shell_index (); 
		      const unsigned int sb_shell_index = phi_b.get_shell_index (); 
		      const unsigned int sc_shell_index = phi_c.get_shell_index (); 
	    
		      const unsigned int sa_minus = one_body_a_indices(sa_shell_index , im_a_minus);
		      const unsigned int sb_minus = one_body_b_indices(sb_shell_index , im_b_minus);
		      const unsigned int sc_minus = one_body_c_indices(sc_shell_index , im_c_minus);
	    		      
		      const class GSM_vector &PSI_OUT_full_abc = PSI_OUT_full_tab(sa , sb , sc);
		      const class GSM_vector &PSI_OUT_full_def = PSI_OUT_full_tab(sd , se , sf);      
		    	    
		      const unsigned int sf_shell_index = phi_f.get_shell_index (); 
	      
		      if (is_it_a_tilde_a_tilde_a_tilde_fed)    T1_T2_part_uncoupled_MEs_table(sa_minus , sb_minus , sc_minus , sd , se , sf_shell_index) = PSI_OUT_full_abc*PSI_OUT_full_def;
		      if (is_it_a_dagger_a_dagger_a_dagger_fed) T1_T2_part_uncoupled_MEs_table(sa_minus , sb_minus , sc_minus , sd , se , sf_shell_index) = PSI_OUT_full_abc*PSI_OUT_full_def;
		      if (is_it_a_dagger_a_tilde_a_tilde_fed)   T1_T2_part_uncoupled_MEs_table(sa_minus , sb_minus , sc_minus , sd , se , sf_shell_index) = PSI_OUT_full_abc*PSI_OUT_full_def;
		      if (is_it_a_dagger_a_dagger_a_tilde_fed)  T1_T2_part_uncoupled_MEs_table(sa_minus , sb_minus , sc_minus , sd , se , sf_shell_index) = PSI_OUT_full_abc*PSI_OUT_full_def;
		    }}}}}

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) T1_T2_part_uncoupled_MEs_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
  
#endif
}

















void dagger_tilde_operators::rho_coupled_reduced_MEs_table_calc (
								 const bool full_common_vectors_used_in_file , 
								 const enum dagger_tilde_operator_type dagger_tilde_operator ,
								 const class correlated_state_str &PSI_qn , 
								 class GSM_vector_helper_class &GSM_vector_helper ,
								 class array<TYPE> &rho_coupled_reduced_MEs_table)
{
  if (!is_it_rho_coupled_reduced_determine (dagger_tilde_operator)) error_message_print_abort ("rho.coupled.modified operators only in dagger_tilde_operators::rho_coupled_reduced_MEs_table_calc");
  
  if (!is_it_RDM_determine (dagger_tilde_operator)) error_message_print_abort ("RDM operators only in dagger_tilde_operators::rho_coupled_reduced_MEs_table_calc");
    
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();

  const class nucleons_data &data = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);

  const unsigned int N_nlj = data.get_N_nlj ();

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
  
  const double J = PSI_qn.get_J ();
  
  const double M = J;
  
  const int Kmax_PSI = make_int (2.0*J);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (dagger_tilde_operator);
  
  const string PSI_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_qn);      
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  const string file_name_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_qn , M);

  const unsigned int N_valence_nucleons = (space == PROTONS_ONLY) ? (Zval) : (Nval);
  
  const unsigned int space_dimension = (space == PROTONS_NEUTRONS)
    ? (space_dimension_read_disk (full_common_vectors_used_in_file , Zval , Nval , file_name_dimension))
    : (space_dimension_read_disk (full_common_vectors_used_in_file , N_valence_nucleons , file_name_dimension));
  
  class array<unsigned int> inSDp_tab;
  class array<unsigned int> inSDn_tab;

  class array<bool> is_inSDp_in_new_space_tab;
  class array<bool> is_inSDn_in_new_space_tab;

  class array<unsigned char> reordering_bin_phases_p;
  class array<unsigned char> reordering_bin_phases_n;  

  class array<TYPE> PSI_component_tab(space_dimension);
	
  class GSM_vector PSI(GSM_vector_helper);

  PSI.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);
  
  class GSM_vector_helper_class PSI_full_helper;
  
  PSI_full_helper.allocate_fill_without_MPI_parallelization (GSM_vector_helper);
  
  class GSM_vector PSI_full(PSI_full_helper);
  
  PSI_full.full_vector_fill (PSI);
  
  switch (space)
    {
    case PROTONS_ONLY:
      {
	inSDp_tab.allocate (space_dimension , Zval);
	
	is_inSDp_in_new_space_tab.allocate (space_dimension);

	reordering_bin_phases_p.allocate (space_dimension);
	
	files_IN_tables_read_pp_nn_one_nucleon (full_common_vectors_used_in_file , PSI_qn , M , prot_data , inSDp_tab , PSI_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p);
      } break;

    case NEUTRONS_ONLY:
      {
	inSDn_tab.allocate (space_dimension , Nval);
	
	is_inSDn_in_new_space_tab.allocate (space_dimension);

	reordering_bin_phases_n.allocate (space_dimension);
	
	files_IN_tables_read_pp_nn_one_nucleon (full_common_vectors_used_in_file , PSI_qn , M , neut_data , inSDn_tab , PSI_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n);
      } break;
		
    case PROTONS_NEUTRONS:
      {
	inSDp_tab.allocate (space_dimension , Zval);
	inSDn_tab.allocate (space_dimension , Nval);
	
	is_inSDp_in_new_space_tab.allocate (space_dimension);
	is_inSDn_in_new_space_tab.allocate (space_dimension);

	reordering_bin_phases_p.allocate (space_dimension);
	reordering_bin_phases_n.allocate (space_dimension);

	files_IN_tables_read_pn_one_nucleon (full_common_vectors_used_in_file , Zval , Nval , PSI_qn , M , prot_data , neut_data , inSDp_tab , inSDn_tab , PSI_component_tab ,
					     is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n);
      } break;
      
    default: abort_all ();
    }
  
  const double m_max = data.get_m_max ();
  
  const class CG_str CGs(m_max);
  
  const int K_number_PSI = make_int (2*J) + 1;

  class array<double> K_reducing_terms(K_number_PSI);

  K_reducing_terms_calc (J , J , M , M , K_reducing_terms);
  
  for (unsigned int sa = 0 ; sa < N_nlj ; sa++)
    for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
      {
	const class nlj_struct &shell_sa_qn = shells_qn(sa);
	const class nlj_struct &shell_sb_qn = shells_qn(sb);

	const bool frozen_state_a = shell_sa_qn.get_frozen_state ();
	const bool frozen_state_b = shell_sb_qn.get_frozen_state ();
		    
	if (!frozen_state_a && !frozen_state_b)
	  {	
	    const int la = shell_sa_qn.get_l ();
	    const int lb = shell_sb_qn.get_l ();

	    const unsigned int bp_a = binary_parity_from_orbital_angular_momentum (la);
	    const unsigned int bp_b = binary_parity_from_orbital_angular_momentum (lb);

	    if (bp_a == bp_b)
	      {
		const double ja = shell_sa_qn.get_j ();
		const double jb = shell_sb_qn.get_j ();

		class uncoupled_dagger_tilde_table<TYPE> two_body_MK_table(ja , jb);

		switch (space)
		  {
		  case PROTONS_ONLY:
		    {
		      a_dagger_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , PSI_qn , PSI_qn , PSI_full ,
							    inSDp_tab , PSI_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , two_body_MK_table);
		    } break;

		  case NEUTRONS_ONLY:
		    {
		      a_dagger_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , PSI_qn , PSI_qn , PSI_full ,
							    inSDn_tab , PSI_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , two_body_MK_table);
		    } break;

		
		  case PROTONS_NEUTRONS:
		    {
		      a_dagger_a_tilde_MK_table_pn_calc (dagger_tilde_operator , shell_sa_qn , shell_sb_qn , PSI_qn , PSI_qn , PSI_full ,
							 inSDp_tab , inSDn_tab , PSI_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
							 reordering_bin_phases_p , reordering_bin_phases_n , two_body_MK_table);
		      
		    } break;
		    
		  default: abort_all ();
		  }
			    
		class coupled_dagger_tilde_table<TYPE> two_body_K_table(dagger_tilde_operator , ja , jb);

		two_body_K_table_from_MK_table_calc  (J , J , M , M , CGs , K_reducing_terms , two_body_MK_table , two_body_K_table);
		    
		const int Kmin = two_body_K_table.get_Kmin ();
		
		const int Kmax_j = two_body_K_table.get_Kmax ();
	    
		const int Kmax = min (Kmax_j , Kmax_PSI);
	    
		for (int K = Kmin ; K <= Kmax ; K++) rho_coupled_reduced_MEs_table(sa , sb , K) = two_body_K_table(K);
	      }
	  }
      }
}















void dagger_tilde_operators::calc_store_PSI_IN_OUT (
						    const input_data_str &input_data , 
						    const class array<class correlated_state_str> &PSI_qn_tab ,
						    const unsigned int dagger_tilde_operators_index ,
						    class nucleons_data &prot_data , 
						    class nucleons_data &neut_data)
{   
  const class array<enum dagger_tilde_operator_type> &dagger_tilde_operators_tab = input_data.get_dagger_tilde_operators_tab ();
  
  const enum dagger_tilde_operator_type dagger_tilde_operator = dagger_tilde_operators_tab(dagger_tilde_operators_index);

  if (is_it_RDM_determine (dagger_tilde_operator)) error_message_print_abort ("No RDM operator in dagger_tilde_operators::calc_store_PSI_IN_OUT");
  
  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();

  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();

  const int Z_OUT = prot_data.get_N_nucleons ();
  const int N_OUT = neut_data.get_N_nucleons ();

  const int n_holes_max_p = prot_data.get_n_holes_max ();
  const int n_holes_max_n = neut_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_data.get_n_scat_max ();
  const int n_scat_max_n = neut_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_data.get_E_max_hw ();
  const int En_max_hw = neut_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();
  
  const class array<unsigned int> &dagger_tilde_operators_BP_IN_tab  = input_data.get_dagger_tilde_operators_BP_IN_tab ();
  const class array<unsigned int> &dagger_tilde_operators_BP_OUT_tab = input_data.get_dagger_tilde_operators_BP_OUT_tab ();
  
  const class array<double> &dagger_tilde_operators_J_IN_tab  = input_data.get_dagger_tilde_operators_J_IN_tab ();
  const class array<double> &dagger_tilde_operators_J_OUT_tab = input_data.get_dagger_tilde_operators_J_OUT_tab ();
  
  const class array<unsigned int> &dagger_tilde_operators_vector_index_IN_tab  = input_data.get_dagger_tilde_operators_vector_index_IN_tab ();
  const class array<unsigned int> &dagger_tilde_operators_vector_index_OUT_tab = input_data.get_dagger_tilde_operators_vector_index_OUT_tab (); 
  
  const unsigned int BP_IN  = dagger_tilde_operators_BP_IN_tab(dagger_tilde_operators_index);
  const unsigned int BP_OUT = dagger_tilde_operators_BP_OUT_tab(dagger_tilde_operators_index);
      
  const unsigned int vector_index_IN  = dagger_tilde_operators_vector_index_IN_tab(dagger_tilde_operators_index);
  const unsigned int vector_index_OUT = dagger_tilde_operators_vector_index_OUT_tab(dagger_tilde_operators_index);
      
  const double J_IN  = dagger_tilde_operators_J_IN_tab(dagger_tilde_operators_index);
  const double J_OUT = dagger_tilde_operators_J_OUT_tab(dagger_tilde_operators_index);
      
  const double M_OUT = J_OUT;
      
  const int Z_IN = Z_IN_calc (dagger_tilde_operator , Z_OUT);
  const int N_IN = N_IN_calc (dagger_tilde_operator , N_OUT);

  const class correlated_state_str PSI_IN_qn(Z_IN , N_IN , BP_IN , J_IN , vector_index_IN , NADA , NADA , NADA , NADA , false);

  const class correlated_state_str PSI_OUT_qn = PSI_quantum_numbers_find (Z_OUT , N_OUT , BP_OUT , J_OUT , vector_index_OUT , PSI_qn_tab);

  class GSM_vector_helper_class PSI_OUT_helper(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
					       n_holes_max   , n_scat_max   , E_max_hw  ,
					       n_holes_max_p , n_scat_max_p , Ep_max_hw ,
					       n_holes_max_n , n_scat_max_n , En_max_hw , BP_OUT , M_OUT , false , prot_data , neut_data);

  class GSM_vector PSI_OUT(PSI_OUT_helper);

  PSI_OUT.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_OUT_qn);

  class GSM_vector_helper_class PSI_OUT_full_helper;
  
  PSI_OUT_full_helper.allocate_fill_without_MPI_parallelization (PSI_OUT_helper);
  
  class GSM_vector PSI_OUT_full(PSI_OUT_full_helper);
  
  PSI_OUT_full.full_vector_fill (PSI_OUT);
      
  if (is_it_two_body_determine (dagger_tilde_operator))
    two_body_K_tables_calc_store (full_common_vectors_used_in_file , dagger_tilde_operator , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full);
  else
    three_body_L_K_tables_calc_store (full_common_vectors_used_in_file , dagger_tilde_operator , PSI_IN_qn , PSI_OUT_qn , PSI_OUT_full);
  
  if (THIS_PROCESS == MASTER_PROCESS) cout << dagger_tilde_operator  << " matrix elements calculated and stored for " << PSI_IN_qn << " --> " << PSI_OUT_qn << endl;
}






void dagger_tilde_operators::calc_store_RDM (
					     const input_data_str &input_data , 
					     const class array<class correlated_state_str> &PSI_qn_tab ,
					     const unsigned int dagger_tilde_operators_index , 
					     class nucleons_data &prot_data , 
					     class nucleons_data &neut_data)
{   
  const class array<enum dagger_tilde_operator_type> &dagger_tilde_operators_tab = input_data.get_dagger_tilde_operators_tab ();
  
  const enum dagger_tilde_operator_type dagger_tilde_operator = dagger_tilde_operators_tab(dagger_tilde_operators_index);

  if (!is_it_RDM_determine (dagger_tilde_operator)) error_message_print_abort ("RDM operators only dagger_tilde_operators::calc_store_RDM");
  
  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();

  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();

  const int Z_IN = prot_data.get_N_nucleons ();
  const int N_IN = neut_data.get_N_nucleons ();

  const int n_holes_max_p = prot_data.get_n_holes_max ();
  const int n_holes_max_n = neut_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_data.get_n_scat_max ();
  const int n_scat_max_n = neut_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_data.get_E_max_hw ();
  const int En_max_hw = neut_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();
  
  const class array<unsigned int> &dagger_tilde_operators_BP_IN_tab = input_data.get_dagger_tilde_operators_BP_IN_tab ();
    
  const class array<double> &dagger_tilde_operators_J_IN_tab = input_data.get_dagger_tilde_operators_J_IN_tab ();
    
  const class array<unsigned int> &dagger_tilde_operators_vector_index_IN_tab = input_data.get_dagger_tilde_operators_vector_index_IN_tab ();  
  
  const unsigned int BP_IN = dagger_tilde_operators_BP_IN_tab(dagger_tilde_operators_index);
      
  const unsigned int vector_index_IN = dagger_tilde_operators_vector_index_IN_tab(dagger_tilde_operators_index);
      
  const double J_IN = dagger_tilde_operators_J_IN_tab(dagger_tilde_operators_index);
      
  const double M_IN = J_IN;

  const class correlated_state_str PSI_IN_qn = PSI_quantum_numbers_find (Z_IN , N_IN , BP_IN , J_IN , vector_index_IN , PSI_qn_tab);

  class GSM_vector_helper_class PSI_IN_helper(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
					      n_holes_max   , n_scat_max   , E_max_hw  ,
					      n_holes_max_p , n_scat_max_p , Ep_max_hw ,
					      n_holes_max_n , n_scat_max_n , En_max_hw , BP_IN , M_IN , false , prot_data , neut_data);
  	  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (dagger_tilde_operator);
  
  const string PSI_IN_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_IN_qn);
  
  const string outfile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_IN_qn_string;
  
  ofstream outfile;

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      outfile.open (outfile_name.c_str ());

      outfile.precision (15);
    }

  if (is_it_two_body_determine (dagger_tilde_operator))
    {
      if (is_it_rho_coupled_reduced_determine (dagger_tilde_operator))
	{
	  const class nucleons_data &data = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
  
	  const unsigned int N_nlj = data.get_N_nlj ();
      
	  const double jmax = data.get_jmax ();
	  
	  const int Kmax_j = make_int (2.0*jmax);

	  const int Kmax_PSI = make_int (2.0*J_IN);
  
	  const int Kmax = min (Kmax_j , Kmax_PSI);
		
	  const int Kmax_plus_one = Kmax + 1;

	  class array<TYPE> rho_coupled_reduced_MEs_table(N_nlj , N_nlj , Kmax_plus_one);
      
	  rho_coupled_reduced_MEs_table = 0.0;
      
	  rho_coupled_reduced_MEs_table_calc (full_common_vectors_used_in_file , dagger_tilde_operator , PSI_IN_qn , PSI_IN_helper , rho_coupled_reduced_MEs_table);	 

	  if (THIS_PROCESS == MASTER_PROCESS) rho_coupled_reduced_MEs_table.copy_disk (outfile_name);
	}
      else
	{
	  const class nucleons_data &data_a = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
	  const class nucleons_data &data_b = data_find (dagger_tilde_operator , 1 , prot_data , neut_data);
	  const class nucleons_data &data_c = data_find (dagger_tilde_operator , 3 , prot_data , neut_data);
	  const class nucleons_data &data_d = data_find (dagger_tilde_operator , 2 , prot_data , neut_data);
  
	  const unsigned int N_nlj_a = data_a.get_N_nlj () , N_nljm_a = data_a.get_N_nljm ();
	  const unsigned int N_nlj_b = data_b.get_N_nlj () , N_nljm_b = data_b.get_N_nljm ();
	  const unsigned int N_nlj_c = data_c.get_N_nlj () , N_nljm_c = data_c.get_N_nljm ();
	  const unsigned int N_nlj_d = data_d.get_N_nlj () , N_nljm_d = data_d.get_N_nljm ();
      
	  const double ja_max = data_a.get_jmax ();
	  const double jb_max = data_b.get_jmax ();
	  
	  const int Kmax = make_int (ja_max + jb_max);

	  const int Kmax_plus_one = Kmax + 1;
	  
	  class array<TYPE> PQG_uncoupled_MEs_table(N_nljm_a , N_nljm_b , N_nljm_c , N_nlj_d);

	  class array<TYPE> PQG_partially_coupled_MEs_table(N_nlj_a , N_nlj_b , N_nljm_c , N_nljm_d , Kmax_plus_one);

	  class array<TYPE> PQG_coupled_MEs_table(N_nlj_a , N_nlj_b , N_nlj_c , N_nlj_d , Kmax_plus_one);
      
	  PQG_uncoupled_MEs_table = 0.0;
      
	  PQG_uncoupled_MEs_table_calc (full_common_vectors_used_in_file , dagger_tilde_operator , PSI_IN_qn , PSI_IN_helper , PQG_uncoupled_MEs_table);	 

	  if (THIS_PROCESS == MASTER_PROCESS)
	    {
	      PQG_partially_coupled_MEs_table = 0.0;
	  
	      PQG_partially_coupled_MEs_table_calc (dagger_tilde_operator , prot_data , neut_data , PQG_uncoupled_MEs_table , PQG_partially_coupled_MEs_table); 
	  
	      PQG_coupled_MEs_table = 0.0;
	  
	      PQG_coupled_MEs_table_calc (dagger_tilde_operator , prot_data , neut_data , PQG_partially_coupled_MEs_table , PQG_coupled_MEs_table);
	  
	      PQG_coupled_MEs_table.copy_disk (outfile_name);
	    }
	}
    }
  else
    {
      const enum dagger_tilde_operator_type dagger_tilde_operator_1 = T1_T2_dagger_tilde_operator_part_determine (1 , dagger_tilde_operator);
      const enum dagger_tilde_operator_type dagger_tilde_operator_2 = T1_T2_dagger_tilde_operator_part_determine (2 , dagger_tilde_operator);
      
      const class nucleons_data &data_a = data_find (dagger_tilde_operator_1 , 0 , prot_data , neut_data);
      const class nucleons_data &data_b = data_find (dagger_tilde_operator_1 , 1 , prot_data , neut_data);
      const class nucleons_data &data_c = data_find (dagger_tilde_operator_1 , 2 , prot_data , neut_data);
      const class nucleons_data &data_d = data_find (dagger_tilde_operator_1 , 5 , prot_data , neut_data);
      const class nucleons_data &data_e = data_find (dagger_tilde_operator_1 , 4 , prot_data , neut_data);
      const class nucleons_data &data_f = data_find (dagger_tilde_operator_1 , 3 , prot_data , neut_data);
  
      const unsigned int N_nlj_a = data_a.get_N_nlj () , N_nljm_a = data_a.get_N_nljm ();
      const unsigned int N_nlj_b = data_b.get_N_nlj () , N_nljm_b = data_b.get_N_nljm ();
      const unsigned int N_nlj_c = data_c.get_N_nlj () , N_nljm_c = data_c.get_N_nljm ();
      const unsigned int N_nlj_d = data_d.get_N_nlj () , N_nljm_d = data_d.get_N_nljm ();
      const unsigned int N_nlj_e = data_e.get_N_nlj () , N_nljm_e = data_e.get_N_nljm ();
      const unsigned int N_nlj_f = data_f.get_N_nlj () , N_nljm_f = data_f.get_N_nljm ();
  
      const double ja_max = data_a.get_jmax ();
      const double jb_max = data_b.get_jmax ();
      const double jc_max = data_c.get_jmax ();
	  
      const class array<class nlj_struct> &shells_a_qn = data_a.get_shells_quantum_numbers ();
      const class array<class nlj_struct> &shells_b_qn = data_b.get_shells_quantum_numbers ();
      const class array<class nlj_struct> &shells_c_qn = data_c.get_shells_quantum_numbers ();
      const class array<class nlj_struct> &shells_d_qn = data_d.get_shells_quantum_numbers ();
      const class array<class nlj_struct> &shells_e_qn = data_e.get_shells_quantum_numbers ();
      const class array<class nlj_struct> &shells_f_qn = data_f.get_shells_quantum_numbers ();  
            
      const int Lmax_ab = make_int (ja_max + jb_max);
      const int Lmax_bc = make_int (jb_max + jc_max);

      const int Lmax = max (Lmax_ab , Lmax_bc);
      
      const int Lmax_plus_one = Lmax + 1;
	  
      const double Kmax = ja_max + jb_max + jc_max;

      const unsigned int K_number = make_uns_int (Kmax - 0.5) + 1;
	  	  
      class array<TYPE> T1_T2_coupled_MEs_table     (N_nlj_a , N_nlj_b , N_nlj_c , Lmax_plus_one , N_nlj_d , N_nlj_e , N_nlj_f , Lmax_plus_one , K_number);
      class array<TYPE> T1_T2_coupled_MEs_table_comm(N_nlj_f , N_nlj_e , N_nlj_d , Lmax_plus_one , N_nlj_c , N_nlj_b , N_nlj_a , Lmax_plus_one , K_number);
      
      class array<TYPE> T1_T2_uncoupled_MEs_table(N_nljm_a , N_nljm_b , N_nljm_c , N_nljm_d , N_nljm_e , N_nlj_f);
      
      T1_T2_uncoupled_MEs_table = 0.0;

      T1_T2_part_uncoupled_MEs_table_calc (full_common_vectors_used_in_file , dagger_tilde_operator_1 , PSI_IN_qn , PSI_IN_helper , T1_T2_uncoupled_MEs_table);
      
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  class array<TYPE> T1_T2_partially_coupled_MEs_table(N_nlj_a , N_nlj_b , N_nlj_c , Lmax_plus_one , N_nljm_d , N_nljm_e , N_nljm_f , K_number);
      
	  T1_T2_partially_coupled_MEs_table = 0.0;
      
	  T1_T2_partially_coupled_MEs_table_calc (dagger_tilde_operator_1 , prot_data , neut_data , T1_T2_uncoupled_MEs_table , T1_T2_partially_coupled_MEs_table);

	  T1_T2_coupled_MEs_table = 0.0;
      
	  T1_T2_coupled_MEs_table_calc (dagger_tilde_operator_1 , prot_data , neut_data , T1_T2_partially_coupled_MEs_table , T1_T2_coupled_MEs_table);
	}
      
      T1_T2_uncoupled_MEs_table.deallocate ();
      
      class array<TYPE> T1_T2_uncoupled_MEs_table_comm(N_nljm_f , N_nljm_e , N_nljm_d , N_nljm_c , N_nljm_b , N_nlj_a);

      T1_T2_uncoupled_MEs_table_comm = 0.0;

      T1_T2_part_uncoupled_MEs_table_calc (full_common_vectors_used_in_file , dagger_tilde_operator_2 , PSI_IN_qn , PSI_IN_helper , T1_T2_uncoupled_MEs_table_comm);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  class array<TYPE> T1_T2_partially_coupled_MEs_table_comm(N_nlj_f , N_nlj_e , N_nlj_d , Lmax_plus_one , N_nljm_c , N_nljm_b , N_nljm_a , K_number);
      
	  T1_T2_partially_coupled_MEs_table_comm = 0.0;
	  
	  T1_T2_partially_coupled_MEs_table_calc (dagger_tilde_operator_2 , prot_data , neut_data , T1_T2_uncoupled_MEs_table_comm , T1_T2_partially_coupled_MEs_table_comm);

	  T1_T2_coupled_MEs_table_comm = 0.0;
      
	  T1_T2_coupled_MEs_table_calc (dagger_tilde_operator_2 , prot_data , neut_data , T1_T2_partially_coupled_MEs_table_comm , T1_T2_coupled_MEs_table_comm);
	}
      
      T1_T2_uncoupled_MEs_table_comm.deallocate ();
      		      
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  // Same shell case in T1 is taken into account as one goes from L=0 to L=Lmax. Thus, L and L' must be understood as alpha and alpha' in the same shell case with T1.
	  
	  for (unsigned int sa = 0 ; sa < N_nlj_a ; sa++)
	    for (unsigned int sb = 0 ; sb < N_nlj_b ; sb++)
	      for (unsigned int sc = 0 ; sc < N_nlj_c ; sc++)
		for (unsigned int sd = 0 ; sd < N_nlj_d ; sd++)
		  for (unsigned int se = 0 ; se < N_nlj_e ; se++)
		    for (unsigned int sf = 0 ; sf < N_nlj_f ; sf++)
		      {
			const class nlj_struct &shell_sa_qn = shells_a_qn(sa) , &shell_sb_qn = shells_b_qn(sb) , &shell_sc_qn = shells_c_qn(sc);
			const class nlj_struct &shell_sd_qn = shells_d_qn(sd) , &shell_se_qn = shells_e_qn(se) , &shell_sf_qn = shells_f_qn(sf);
	  
			const int ija = shell_sa_qn.get_ij () , ijb = shell_sb_qn.get_ij () , ijc = shell_sc_qn.get_ij ();
			const int ijd = shell_sd_qn.get_ij () , ije = shell_se_qn.get_ij () , ijf = shell_sf_qn.get_ij ();

			const int phase = minus_one_pow (ija + ijb + ijc + ijd + ije + ijf);
			
			for (int L = 0 ; L <= Lmax ; L++)
			  for (int Lp = 0 ; Lp <= Lmax ; Lp++)
			    for (unsigned int iK = 0 ; iK < K_number ; iK++)
			      {				
				(phase == 1)
				  ? (T1_T2_coupled_MEs_table(sa , sb , sc , L , sd , se , sf , Lp , iK) += T1_T2_coupled_MEs_table_comm(sf , se , sd , Lp , sc , sb , sa , L , iK))
				  : (T1_T2_coupled_MEs_table(sa , sb , sc , L , sd , se , sf , Lp , iK) -= T1_T2_coupled_MEs_table_comm(sf , se , sd , Lp , sc , sb , sa , L , iK));
			      }
		      }
	  	  
	  T1_T2_coupled_MEs_table.copy_disk (outfile_name);
	}
    }
	
  
  if (THIS_PROCESS == MASTER_PROCESS) cout << dagger_tilde_operator << " matrix elements calculated and stored for " << PSI_IN_qn << endl << endl;
}







void dagger_tilde_operators::calc_store (
					 const input_data_str &input_data , 
					 const class array<class correlated_state_str> &PSI_qn_tab ,
					 class nucleons_data &prot_data , 
					 class nucleons_data &neut_data)
{ 
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "dagger tilde operators matrix elements" << endl;
      cout <<         "--------------------------------------" << endl << endl;
    }

  const unsigned int dagger_tilde_operators_number = input_data.get_dagger_tilde_operators_number ();

  const class array<enum dagger_tilde_operator_type> &dagger_tilde_operators_tab = input_data.get_dagger_tilde_operators_tab ();
  	
  for (unsigned int dagger_tilde_operators_index = 0 ; dagger_tilde_operators_index < dagger_tilde_operators_number ; dagger_tilde_operators_index++)
    {
      const enum dagger_tilde_operator_type dagger_tilde_operator = dagger_tilde_operators_tab(dagger_tilde_operators_index);

      if (is_it_RDM_determine (dagger_tilde_operator))
	calc_store_RDM (input_data , PSI_qn_tab , dagger_tilde_operators_index , prot_data , neut_data);
      else
	calc_store_PSI_IN_OUT (input_data , PSI_qn_tab , dagger_tilde_operators_index , prot_data , neut_data);
    }
}






