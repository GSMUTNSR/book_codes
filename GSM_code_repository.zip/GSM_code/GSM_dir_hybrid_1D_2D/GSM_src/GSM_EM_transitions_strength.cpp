#include "../GSM_include/GSM_include_def.h"

// MPI transfer is done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

using namespace string_routines;
using namespace EM_transitions_common;
using namespace EM_transitions_strength_NBMEs;
using namespace correlated_state_routines;
using namespace configuration_SD_in_space_one_jump_out_to_in;


// TYPE is double or complex
// -------------------------



// EM means electromagnetic
// ------------------------



// Calculation and storage of the EM transition strength <Psi[out] || Op(r) || Psi[in]>^2 for all demanded EM transition strengths in the input file
// -------------------------------------------------------------------------------------------------------------------------------------------------
// Eigenvectors are read from disk and B_amplitude_tab_calc is called for the EM transitions, for  <Psi[out] || Op(r) || Psi[in]>^2 values to be stored on disk afterwards,
// in a file whose name looks like "E2_strength_longwavelength_approximation_2+_0_0+_0.dat".

void EM_transitions_strength::calc_store (
					  const class input_data_str &input_data , 
					  class baryons_data &prot_Y_data , 
					  class baryons_data &neut_Y_data , 
					  const class array<class correlated_state_str> &PSI_qn_tab , 
					  class GSM_vector &PSI_full)
{ 
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "EM transitions strengths" << endl;
      cout <<         "------------------------" << endl << endl;
    }

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const int S = input_data.get_hypernucleus_strangeness ();
  
  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();

  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();

  const int Z = prot_Y_data.get_N_nucleons ();
  const int N = neut_Y_data.get_N_nucleons ();

  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();

  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();
  
  const int E_max_hw = input_data.get_E_max_hw ();
    
  const unsigned int EM_transitions_strength_number = input_data.get_EM_transitions_strength_number ();
  
  const class array<enum EM_type> &EM_strength_tab = input_data.get_EM_strength_tab ();

  const class array<int> &EM_strength_L_tab = input_data.get_EM_strength_L_tab ();

  const class array<unsigned int> &EM_strength_BP_IN_tab  = input_data.get_EM_strength_BP_IN_tab ();
  const class array<unsigned int> &EM_strength_BP_OUT_tab = input_data.get_EM_strength_BP_OUT_tab ();

  const class array<double> &EM_strength_J_IN_tab  = input_data.get_EM_strength_J_IN_tab ();
  const class array<double> &EM_strength_J_OUT_tab = input_data.get_EM_strength_J_OUT_tab ();

  const class array<unsigned int> &EM_strength_vector_index_IN_tab  = input_data.get_EM_strength_vector_index_IN_tab ();
  const class array<unsigned int> &EM_strength_vector_index_OUT_tab = input_data.get_EM_strength_vector_index_OUT_tab (); 

  const class array<bool> &EM_strength_is_it_longwavelength_approximation_tab = input_data.get_EM_strength_is_it_longwavelength_approximation_tab ();

  const class array<bool> &EM_strength_is_it_Gauss_Legendre_tab = input_data.get_EM_strength_is_it_Gauss_Legendre_tab ();

  const int A = prot_Y_data.get_A ();

  const unsigned int N_bef_R_GL = prot_Y_data.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = prot_Y_data.get_N_bef_R_uniform ();

  const double R = prot_Y_data.get_R ();

  const double step_bef_R_uniform = prot_Y_data.get_step_bef_R_uniform ();

  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);

  class array<double> r_bef_R_tab_uniform(N_bef_R_uniform);
  
  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;
  
  for (unsigned int EM_index = 0 ; EM_index < EM_transitions_strength_number ; EM_index++)
    {
      const enum EM_type EM = EM_strength_tab(EM_index);

      const int L = EM_strength_L_tab(EM_index);
      
      const bool is_it_Gauss_Legendre = EM_strength_is_it_Gauss_Legendre_tab(EM_index);

      const unsigned int BP_IN  = EM_strength_BP_IN_tab(EM_index);
      const unsigned int BP_OUT = EM_strength_BP_OUT_tab(EM_index);

      const unsigned int vector_index_IN  = EM_strength_vector_index_IN_tab(EM_index);
      const unsigned int vector_index_OUT = EM_strength_vector_index_OUT_tab(EM_index);

      const double J_IN  = EM_strength_J_IN_tab(EM_index);
      const double J_OUT = EM_strength_J_OUT_tab(EM_index);

      const double M_IN  = J_IN;
      const double M_OUT = J_OUT;

      const class correlated_state_str PSI_IN_qn = PSI_quantum_numbers_find (Z , N , BP_IN , S , J_IN , vector_index_IN , PSI_qn_tab);

      class GSM_vector_helper_class PSI_IN_helper(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph , 
						  n_holes_max   , n_scat_max   , E_max_hw  ,
						  n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						  n_holes_max_n , n_scat_max_n , En_max_hw , BP_IN , M_IN , false , prot_Y_data , neut_Y_data);
      
      class GSM_vector PSI_IN(PSI_IN_helper);

      PSI_IN.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_IN_qn);
      
      const class correlated_state_str PSI_OUT_qn = PSI_quantum_numbers_find (Z , N , BP_OUT , S , J_OUT , vector_index_OUT , PSI_qn_tab);

      class GSM_vector_helper_class PSI_OUT_helper(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
						   n_holes_max   , n_scat_max   , E_max_hw  ,
						   n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						   n_holes_max_n , n_scat_max_n , En_max_hw , BP_OUT , M_OUT , false , prot_Y_data , neut_Y_data);
      
      class GSM_vector PSI_OUT(PSI_OUT_helper);
      
      PSI_OUT.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_OUT_qn);

      const class GSM_vector_helper_class dummy_helper;

      class GSM_vector_helper_class PSI_IN_full_helper;

      PSI_IN_full_helper.allocate_fill_without_MPI_parallelization (PSI_IN_helper);

      configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , true , false , false , false , PSI_IN_full_helper , PSI_OUT_helper , dummy_helper , prot_Y_data , neut_Y_data);

      const bool is_it_longwavelength_approximation = EM_strength_is_it_longwavelength_approximation_tab(EM_index);

      const string longwavelength_approximation_str = (is_it_longwavelength_approximation) ? ("longwavelength_approximation") : ("no_longwavelength_approximation");

      const complex<double> E_IN_complex  = PSI_IN_qn.get_E ();
      const complex<double> E_OUT_complex = PSI_OUT_qn.get_E (); 

      const TYPE E_IN  = generate_scalar<TYPE> (real (E_IN_complex)  , imag (E_IN_complex));
      const TYPE E_OUT = generate_scalar<TYPE> (real (E_OUT_complex) , imag (E_OUT_complex));
      
      const TYPE q = (E_IN - E_OUT)/hbar_c;

      const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

      class array<TYPE> B_amplitude_tab(Nr);
      
      B_amplitude_tab_calc (EM , q , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , PSI_full , J_IN , PSI_IN , J_OUT , PSI_OUT , B_amplitude_tab);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  const string PSI_IN_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_IN_qn);

	  const string PSI_OUT_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_OUT_qn);

	  const string EM_letter = EM_letter_determine (EM);

	  const string EM_strength_string = EM_letter + make_string<int> (L) + "_strength_" + longwavelength_approximation_str + "_" + PSI_IN_qn_string + "_" + PSI_OUT_qn_string + ".dat";

	  const string long_wavelength_str = (is_it_longwavelength_approximation) ? ("with long wavelength approximation calculated.") : ("without long wavelength approximation calculated.");

	  const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (r_bef_R_tab_GL) : (r_bef_R_tab_uniform);

	  print_B_G_amplitude_tab (EM , q , L , A , J_IN , r_bef_R_tab , B_amplitude_tab , EM_strength_string);

	  cout << EM_letter << L << " transition strength "
	       << J_Pi_vector_index_string (BP_IN , J_IN , vector_index_IN) << " --> " << J_Pi_vector_index_string (BP_OUT , J_OUT , vector_index_OUT) << " " << long_wavelength_str << endl << endl;
	}
    }
}


