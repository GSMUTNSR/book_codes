#include "../GSM_include/GSM_include_def.h"

// TYPE is double or complex
// -------------------------


// MPI transfer is sometimes done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time


// mu means proton or neutron in routines with valence protons only or valence neutrons only.

// Classes A_dagger_cluster_coupled_to_J_PSI_str, A_cluster_PSI_str, A_cluster_coupled_to_J_PSI_str are used only in closures and then are not commented.

// A+/A[Psi(cluster)]|Psi[in]> and [A+/A[Psi(cluster)]|Psi[in]>]^JM vector calculated and added to |Psi[out]> in the proton-neutron (pn), and proton-proton or neutron-neutron (pp, nn) case
// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One can add or remove a cluster of several nucleons here.
// If one calculates [A+/A[Psi(cluster)]|Psi[in]>]^JM, one uses ..._coupled_to_J_... routines.
//
// Coupled case
// ------------
// One must have Pi[cluster].Pi[in] = Pi[out] and \vec{J[cluster]} + \vec{J[in]} = \vec{J[out]} otherwise <Psi[out] | [A+/A[Psi(cluster)] | Psi[in]>]^JM = 0 (with JM = J_out, M_out).
// One uses: [A+[Psi(cluster)]|Psi[in]>]^JM = \sum_{M(in] , M[cluster]}                                <J[in] M[in] J[cluster]  M[cluster] | J[out] M[out]> A+[Psi(cluster)]|Psi[in]> (calculated from uncoupled case)
//            [A[Psi(cluster)]|Psi[in]>]^JM = \sum_{M(in] , M[cluster]} (-1)^(J[cluster] - M[cluster]) <J[in] M[in] J[cluster] -M[cluster] | J[out] M[out]>  A[Psi(cluster)]|Psi[in]> (calculated from uncoupled case)
//
// Uncoupled case
// --------------
// One must have Pi[cluster].Pi[in] = Pi[out] and M[cluster] + M[in] = M[out] (A+), -M[cluster] + M[in] = M[out] (A) otherwise <Psi[out] | A+/A[Psi(cluster)] | Psi[in]> = 0.
//
// |Psi[cluster]> and |Psi[in] are read from files, where components and basis Slater determinants are stored, the latter as sequences of one-body state indices.
// One adds one cluster many-body wave function |Psi[cluster]> to an already existing |Psi[in]> many-body wave function. 
// This is used in GSM-CC, where one build composites this way, or for the calculation of overlap functions and spectroscopic factors.
//
// |Psi[cluster]> and |Psi[in]> are given as input, with both components and basis Slater determinants.
// Thus: A+/A[Psi(cluster)]|Psi[in]> = \sum_{SD_cluster, SD_in} c_cluster[SD_cluster] c_in[SD_in] A+/A[SD(cluster)]|SD[in]>.
// Thus, one loops over SD_cluster, SD_in basis states, proton and neutron parts being taken into account separately (pn case only).
// If Slater determinants do not belong to the GSM model space of |Psi[out]>, which can occur with different truncation schemes used for |Psi[in]>, |Psi[cluster]> and |Psi[out]>, they are ignored.
// One also always checks if Slater determinants verify truncations in terms of energy and number of particles in the continuum of the GSM model space of |Psi[out]>.
// A+/A[SD(cluster)]|SD[in]> is calculated with creation/annihilation operators, using stored occupied state indices of Slater determinants and reordering phases.
// One firstly checks if |SD(cluster)> is fully unoccupied in |SD[in]> is unoccupied (fully occupied for A). Otherwise, A+/A[SD(cluster)]|SD[in]> = 0.
// If A+/A[SD(cluster)]|SD[in]> is not trivially equal to zero, |SD(cluster)> is to added to |SD[in]> (see excitation_SD_add_and_bin_phase in GSM_Slater_determinant.cpp).
// Its proton and neutron parts are taken into account separately (pn case only).
// Once |SD> = A+/A[SD(cluster)]|SD[in]> is obtained, its basis index in A+/A[Psi(cluster)]|Psi[in]> must be found to add c_cluster[SD_cluster] c_in[SD_in] in |Psi[out]>.
// This is done with binary searches, where the indices of proton and neutron configurations (see GSM_configuration_construction_set.cpp) and then of Slater determinants (see GSM_SD_construction_set.cpp) are found.
// The basis index of |SD> can be then be calculated with the latter and the sum_GSM_vector_dimensions_class class of |Psi[out]> (see GSM_vector_dimensions.cpp for the definition of sum_GSM_vector_dimensions_class).
// The components of A+/A[Psi(cluster)] | Psi[in]> and their Slater determinants indices are firstly stored in arrays and summed up afterwards.
// 
// OpenMP and MPI parallelization can be used therein.
// One node takes care of one part of all c_in components, and the whole |Psi[cluster]> vector is considered in each node for a fixed c_in component.
// OpenMP parallelization is done at the level of the loop on c_in components, which is the first loop of the routine
// Work arrays, one for each thread, are allocated to avoid race conditions.
// One can use GSM vectors fully stored on files or not.
// In the first case, the GSM vector is entirely stored in a file, so that the master process reads it and distributes it to all nodes, as in the 1D code.
// In the second case, the GSM vector is separated in several files, one for each node, and each takes care of its GSM vector file part independently.





using namespace string_routines;
using namespace Wigner_signs;
using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;
using namespace correlated_state_routines;






void A_dagger_cluster_helper::A_dagger_PSI_IN_total_PSI_indices_components_calc_pn (
										    const class correlated_state_str &PSI_cluster_qn ,
										    const class correlated_state_str &PSI_IN_qn ,
										    const class GSM_vector_helper_class &GSM_vector_helper_OUT ,
										    const class array<unsigned int> &inSDp_tab ,
										    const class array<unsigned int> &inSDn_tab ,
										    const class array<unsigned int> &SDp_cluster_tab ,
										    const class array<unsigned int> &SDn_cluster_tab ,
										    const class array<TYPE> &PSI_IN_component_tab ,
										    const class array<TYPE> &PSI_cluster_component_tab ,
										    const class array<bool> &is_inSDp_in_new_space_tab ,
										    const class array<bool> &is_inSDn_in_new_space_tab ,
										    const class array<bool> &is_SDp_cluster_in_new_space_tab ,
										    const class array<bool> &is_SDn_cluster_in_new_space_tab ,
										    const class array<unsigned char> &reordering_bin_phases_p_IN ,
										    const class array<unsigned char> &reordering_bin_phases_n_IN ,
										    const class array<unsigned char> &reordering_bin_phases_p_cluster ,
										    const class array<unsigned char> &reordering_bin_phases_n_cluster ,
										    class array<unsigned int> &A_dagger_SD_cluster_PSI_IN_total_PSI_indices ,
										    class array<TYPE> &A_dagger_SD_cluster_PSI_IN_components)
{
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int Z_core = prot_data.get_Z_core (); 
  const int N_core = prot_data.get_N_core ();
  
  const int Zval = prot_data.get_N_valence_nucleons (); 
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max (); 

  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();     

  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int Z_cluster = PSI_cluster_qn.get_Z ();
  const int N_cluster = PSI_cluster_qn.get_N ();
  
  const int Z_IN = PSI_IN_qn.get_Z ();
  const int N_IN = PSI_IN_qn.get_N ();
  
  const int prot_hole_states_number = prot_data.get_hole_states_number (); 
  const int neut_hole_states_number = neut_data.get_hole_states_number ();
  
  const int Zval_IN = Z_IN - Z_core + prot_hole_states_number;  
  const int Nval_IN = N_IN - N_core + neut_hole_states_number;
  
  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();
  
  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  const unsigned long int total_space_dimension_OUT = GSM_vector_helper_OUT.get_total_space_dimension ();
  
  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);

  const unsigned int space_dimension_cluster = A_dagger_SD_cluster_PSI_IN_total_PSI_indices.dimension (1);

  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_cluster_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_cluster_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (Zval_IN);
      inSDn_work_tab(i).allocate (Nval_IN);

      SDp_cluster_work_tab(i).allocate (Z_cluster);
      SDn_cluster_work_tab(i).allocate (N_cluster);      

      outSDp_work_tab(i).allocate (Zval);
      outSDn_work_tab(i).allocate (Nval);

      Cp_out_work_tab(i).allocate (Zval);
      Cn_out_work_tab(i).allocate (Nval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);
    }

  A_dagger_SD_cluster_PSI_IN_total_PSI_indices = total_space_dimension_OUT;

  A_dagger_SD_cluster_PSI_IN_components = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int i = 0 ; i < space_dimension_IN ; i++)
    {
      if (!is_inSDp_in_new_space_tab(i) || !is_inSDn_in_new_space_tab(i)) continue;

      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      const unsigned int reordering_bin_phase_p_IN = reordering_bin_phases_p_IN(i);
      const unsigned int reordering_bin_phase_n_IN = reordering_bin_phases_n_IN(i);

      class Slater_determinant &inSDp = inSDp_work_tab(i_thread);
      class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

      for (int p = 0 ; p < Zval_IN ; p++) inSDp[p] = inSDp_tab(i , p);
      for (int n = 0 ; n < Nval_IN ; n++) inSDn[n] = inSDn_tab(i , n);

      const TYPE &PSI_IN_component = PSI_IN_component_tab(i);
	  
      for (unsigned int ii = 0 ; ii < space_dimension_cluster ; ii++)
	{
	  if (!is_SDp_cluster_in_new_space_tab(ii) || !is_SDn_cluster_in_new_space_tab(ii)) continue;

	  class Slater_determinant &SDp_cluster = SDp_cluster_work_tab(i_thread);
	  class Slater_determinant &SDn_cluster = SDn_cluster_work_tab(i_thread);
	      
	  for (int p = 0 ; p < Z_cluster ; p++) SDp_cluster[p] = SDp_cluster_tab(ii , p);
	  for (int n = 0 ; n < N_cluster ; n++) SDn_cluster[n] = SDn_cluster_tab(ii , n);
	  
	  if (inSDp.is_SD_partially_occupied (SDp_cluster)) continue;
	  if (inSDn.is_SD_partially_occupied (SDn_cluster)) continue;
	  
	  const unsigned int reordering_bin_phase_p_cluster = reordering_bin_phases_p_cluster(ii);
	  const unsigned int reordering_bin_phase_n_cluster = reordering_bin_phases_n_cluster(ii);
	      
	  unsigned int bin_phase_p = binary_parity_product (reordering_bin_phase_p_IN , reordering_bin_phase_p_cluster);
	  unsigned int bin_phase_n = binary_parity_product (reordering_bin_phase_n_IN , reordering_bin_phase_n_cluster);
		  
	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  
	  inSDp.excitation_SD_add_and_bin_phase (SDp_cluster , outSDp , bin_phase_p);
		  
	  class configuration &Cp_out = Cp_out_work_tab(i_thread);

	  Cp_out.get_SD_configuration (phi_p_table , outSDp);

	  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_prot);

	  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_prot);
	  
	  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_prot);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	  
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);

	  inSDn.excitation_SD_add_and_bin_phase (SDn_cluster , outSDn , bin_phase_n);

	  class configuration &Cn_out = Cn_out_work_tab(i_thread);

	  Cn_out.get_SD_configuration (phi_n_table , outSDn);

	  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_neut);

	  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_neut);
	      
	  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_neut); 

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

	  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw))  continue;
		
	  class configuration &Cp_try = Cp_try_tab(i_thread);
	  class configuration &Cn_try = Cn_try_tab(i_thread);

	  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
	      
	  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_prot);
	  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_neut);

	  const int iMp_out = outSDp.iM_determine (phi_p_table);
	  const int iMn_out = outSDn.iM_determine (phi_n_table);

	  const unsigned int iCp_out = Cp_out.index_search (BPp_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
	  const unsigned int iCn_out = Cn_out.index_search (BPn_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);

	  const unsigned int outSDp_index = outSDp.index_search (BPp_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
	  const unsigned int outSDn_index = outSDn.index_search (BPn_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

	  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
		  
	  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);

	  const unsigned int A_dagger_SD_cluster_PSI_IN_total_PSI_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

	  const TYPE PSI_cluster_component = PSI_cluster_component_tab(ii);
		      		      
	  A_dagger_SD_cluster_PSI_IN_total_PSI_indices(i , ii) = A_dagger_SD_cluster_PSI_IN_total_PSI_index;
	  
	  A_dagger_SD_cluster_PSI_IN_components(i , ii) = (bin_phase_p == bin_phase_n) ? (PSI_cluster_component*PSI_IN_component) : (-PSI_cluster_component*PSI_IN_component);
	}
    }
}






void A_dagger_cluster_helper::A_dagger_PSI_IN_total_PSI_indices_components_calc_pp_nn (
										       const class correlated_state_str &PSI_cluster_qn ,
										       const class correlated_state_str &PSI_IN_qn ,
										       const class GSM_vector_helper_class &GSM_vector_helper_OUT ,
										       const class array<unsigned int> &inSD_tab ,
										       const class array<unsigned int> &SD_cluster_tab ,
										       const class array<TYPE> &PSI_IN_component_tab ,
										       const class array<TYPE> &PSI_cluster_component_tab ,
										       const class array<bool> &is_inSD_in_new_space_tab ,
										       const class array<bool> &is_SD_cluster_in_new_space_tab ,
										       const class array<unsigned char> &reordering_bin_phases_IN ,
										       const class array<unsigned char> &reordering_bin_phases_cluster ,
										       class array<unsigned int> &A_dagger_SD_cluster_PSI_IN_total_PSI_indices ,
										       class array<TYPE> &A_dagger_SD_cluster_PSI_IN_components)
{
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int Z_core = prot_data.get_Z_core (); 
  const int N_core = prot_data.get_N_core ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max (); 
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();  
  
  const int Z_cluster = PSI_cluster_qn.get_Z ();
  const int N_cluster = PSI_cluster_qn.get_N ();

  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);
  
  const int N_core_mu = (space == PROTONS_ONLY) ? (Z_core) : (N_core);

  const int Nval_mu = data.get_N_valence_nucleons ();

  const int N_IN_mu = (space == PROTONS_ONLY) ? (PSI_IN_qn.get_Z ()) : (PSI_IN_qn.get_N ());

  const int hole_states_number_mu = data.get_hole_states_number ();
  
  const int Nval_IN_mu = N_IN_mu - N_core_mu + hole_states_number_mu;

  const int N_cluster_mu = (space == PROTONS_ONLY) ? (Z_cluster) : (N_cluster);

  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  const unsigned long int total_space_dimension_OUT = GSM_vector_helper_OUT.get_total_space_dimension ();
  
  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);	  

  const unsigned int space_dimension_cluster = A_dagger_SD_cluster_PSI_IN_total_PSI_indices.dimension (1);
 
  class array<class Slater_determinant> inSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_cluster_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (Nval_IN_mu);

      SD_cluster_work_tab(i).allocate (N_cluster_mu);    

      outSD_work_tab(i).allocate (Nval_mu);

      C_out_work_tab(i).allocate (Nval_mu);

      SD_try_tab(i).allocate (Nval_mu);

      C_try_tab(i).allocate (Nval_mu);
    }
  
  A_dagger_SD_cluster_PSI_IN_total_PSI_indices = total_space_dimension_OUT;

  A_dagger_SD_cluster_PSI_IN_components = 0.0;
	  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int i = 0 ; i < space_dimension_IN ; i++)
    {
      if (!is_inSD_in_new_space_tab(i)) continue;

      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      const unsigned int reordering_bin_phase_IN = reordering_bin_phases_IN(i);

      class Slater_determinant &inSD = inSD_work_tab(i_thread);

      for (int mu = 0 ; mu < Nval_IN_mu ; mu++) inSD[mu] = inSD_tab(i , mu);

      const TYPE &PSI_IN_component = PSI_IN_component_tab(i);

      for (unsigned int ii = 0 ; ii < space_dimension_cluster ; ii++)
	{
	  if (!is_SD_cluster_in_new_space_tab(ii)) continue;

	  class Slater_determinant &SD_cluster = SD_cluster_work_tab(i_thread);

	  for (int mu = 0 ; mu < N_cluster_mu ; mu++) SD_cluster[mu] = SD_cluster_tab(ii , mu);

	  if (inSD.is_SD_partially_occupied (SD_cluster)) continue;

	  const unsigned int reordering_bin_phase_cluster = reordering_bin_phases_cluster(ii);
	      
	  unsigned int bin_phase = binary_parity_product (reordering_bin_phase_IN , reordering_bin_phase_cluster);

	  class Slater_determinant &outSD = outSD_work_tab(i_thread);

	  inSD.excitation_SD_add_and_bin_phase (SD_cluster , outSD , bin_phase);

	  class configuration &C_out = C_out_work_tab(i_thread);	

	  C_out.get_SD_configuration (phi_mu_table , outSD);

	  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

	  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
	  
	  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
	    
	  class configuration &C_try = C_try_tab(i_thread);

	  class Slater_determinant &SD_try = SD_try_tab(i_thread);

	  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);

	  const int iM_out = outSD.iM_determine (phi_mu_table);

	  const unsigned int iC_out = C_out.index_search (BP_out , n_scat_out , dimensions_configuration_set , configuration_set , C_try);

	  const unsigned int outSD_index = outSD.index_search (BP_out , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try); 

	  const unsigned long int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

	  const unsigned int A_dagger_SD_cluster_PSI_IN_total_PSI_index = sum_dimensions_configuration_fixed_out + outSD_index;

	  const TYPE PSI_cluster_component = PSI_cluster_component_tab(ii);

	  const int phase = parity_from_binary_parity (bin_phase);
		  
	  A_dagger_SD_cluster_PSI_IN_total_PSI_indices(i , ii) = A_dagger_SD_cluster_PSI_IN_total_PSI_index;

	  A_dagger_SD_cluster_PSI_IN_components(i , ii) = (phase == 1) ? (PSI_cluster_component*PSI_IN_component) : (-PSI_cluster_component*PSI_IN_component);
	}
    }
}








void A_dagger_cluster_helper::A_dagger_cluster_apply_add_pn (
							     const bool full_common_vectors_used_in_file ,
							     const bool is_it_CM_relative_cluster , 
							     const enum particle_type cluster , 
							     const int NCM_HO , 
							     const int LCM , 
							     const class correlated_state_str &PSI_cluster_qn ,
							     const double M_cluster ,  
							     const class correlated_state_str &PSI_IN_qn ,
							     const double M_IN , 
							     class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();

  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
    
  const int Z_core = prot_data.get_Z_core (); 
  const int N_core = prot_data.get_N_core ();
  
  const int Z_cluster = PSI_cluster_qn.get_Z ();
  const int N_cluster = PSI_cluster_qn.get_N ();
  
  const int Z_IN = PSI_IN_qn.get_Z ();
  const int N_IN = PSI_IN_qn.get_N ();
  
  const int prot_hole_states_number = prot_data.get_hole_states_number (); 
  const int neut_hole_states_number = neut_data.get_hole_states_number ();
  
  const int Zval_IN = Z_IN - Z_core + prot_hole_states_number;  
  const int Nval_IN = N_IN - N_core + neut_hole_states_number;
    
  const double J_cluster = PSI_cluster_qn.get_J ();
      
  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);
  
  const string file_name_cluster_dimension = (is_it_CM_relative_cluster)
    ? (file_name_intrinsic_CM_cluster_string ("Berggren_basis_state_dimension" , cluster , NCM_HO , LCM , J_cluster , M_cluster))
    : (file_name_eigenvector_string (true , "eigenvector_dimension" , PSI_cluster_qn , M_cluster));
 
  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Zval_IN , Nval_IN , file_name_IN_dimension);
  
  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));

  const unsigned int space_dimension_cluster = space_dimension_read_disk (true , Z_cluster , N_cluster , file_name_cluster_dimension);

  class array<unsigned int> inSDp_tab(space_dimension_IN , Zval_IN);
  class array<unsigned int> inSDn_tab(space_dimension_IN , Nval_IN);

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);
 
  class array<bool> is_inSDp_in_new_space_tab(space_dimension_IN);
  class array<bool> is_inSDn_in_new_space_tab(space_dimension_IN);

  class array<unsigned char> reordering_bin_phases_p_IN(space_dimension_IN);
  class array<unsigned char> reordering_bin_phases_n_IN(space_dimension_IN);
  
  class array<unsigned int> SDp_cluster_tab(space_dimension_cluster , Z_cluster);
  class array<unsigned int> SDn_cluster_tab(space_dimension_cluster , N_cluster);

  class array<TYPE> PSI_cluster_component_tab(space_dimension_cluster);
	  
  class array<bool> is_SDp_cluster_in_new_space_tab(space_dimension_cluster);
  class array<bool> is_SDn_cluster_in_new_space_tab(space_dimension_cluster);    

  class array<unsigned char> reordering_bin_phases_p_cluster(space_dimension_cluster);
  class array<unsigned char> reordering_bin_phases_n_cluster(space_dimension_cluster);
  
  files_IN_tables_read_pn_cluster (full_common_vectors_used_in_file , is_it_CM_relative_cluster , cluster , NCM_HO , LCM , PSI_cluster_qn , M_cluster , PSI_IN_qn , M_IN , prot_data , neut_data ,
				   inSDp_tab , inSDn_tab , SDp_cluster_tab , SDn_cluster_tab , PSI_IN_component_tab , PSI_cluster_component_tab ,
				   is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab , is_SDp_cluster_in_new_space_tab , is_SDn_cluster_in_new_space_tab ,
				   reordering_bin_phases_p_IN , reordering_bin_phases_n_IN , reordering_bin_phases_p_cluster , reordering_bin_phases_n_cluster);
      	  
  class array<unsigned int> A_dagger_SD_cluster_PSI_IN_total_PSI_indices(space_dimension_IN_max , space_dimension_cluster);

  class array<TYPE> A_dagger_SD_cluster_PSI_IN_components(space_dimension_IN_max , space_dimension_cluster);
  
  A_dagger_PSI_IN_total_PSI_indices_components_calc_pn (PSI_cluster_qn , PSI_IN_qn , GSM_vector_helper_OUT ,
							inSDp_tab , inSDn_tab , SDp_cluster_tab , SDn_cluster_tab , PSI_IN_component_tab , PSI_cluster_component_tab ,
							is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab , is_SDp_cluster_in_new_space_tab , is_SDn_cluster_in_new_space_tab ,
							reordering_bin_phases_p_IN , reordering_bin_phases_n_IN , reordering_bin_phases_p_cluster , reordering_bin_phases_n_cluster ,
							A_dagger_SD_cluster_PSI_IN_total_PSI_indices , A_dagger_SD_cluster_PSI_IN_components);
  
  PSI_OUT.Op_PSI_IN_components_add_cluster_all_processes (full_common_vectors_used_in_file , A_dagger_SD_cluster_PSI_IN_total_PSI_indices , A_dagger_SD_cluster_PSI_IN_components);	  
}











void A_dagger_cluster_helper::A_dagger_cluster_apply_add_pp_nn (
								const bool full_common_vectors_used_in_file ,
								const bool is_it_CM_relative_cluster , 
								const enum particle_type cluster , 
								const int NCM_HO , 
								const int LCM , 
								const class correlated_state_str &PSI_cluster_qn ,
								const double M_cluster ,  
								const class correlated_state_str &PSI_IN_qn ,
								const double M_IN , 
								class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
    
  const int Z_core = prot_data.get_Z_core (); 
  const int N_core = prot_data.get_N_core ();
    
  const int Z_cluster = PSI_cluster_qn.get_Z ();
  const int N_cluster = PSI_cluster_qn.get_N ();

  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);
  
  const int N_core_mu = (space == PROTONS_ONLY) ? (Z_core) : (N_core);

  const int N_IN_mu = (space == PROTONS_ONLY) ? (PSI_IN_qn.get_Z ()) : (PSI_IN_qn.get_N ());

  const int hole_states_number_mu = data.get_hole_states_number ();
  
  const int Nval_IN_mu = N_IN_mu - N_core_mu + hole_states_number_mu;

  const int N_cluster_mu = (space == PROTONS_ONLY) ? (Z_cluster) : (N_cluster);
  
  const double J_cluster = PSI_cluster_qn.get_J ();

  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);
 
  const string file_name_cluster_dimension = (is_it_CM_relative_cluster)
    ? (file_name_intrinsic_CM_cluster_string ("Berggren_basis_state_dimension" , cluster , NCM_HO , LCM , J_cluster , M_cluster))
    : (file_name_eigenvector_string (true , "eigenvector_dimension" , PSI_cluster_qn , M_cluster));
  
  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Nval_IN_mu , file_name_IN_dimension);
  
  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));

  const unsigned int space_dimension_cluster = space_dimension_read_disk (true , N_cluster_mu , file_name_cluster_dimension);
  
  class array<unsigned int> inSD_tab(space_dimension_IN , Nval_IN_mu);

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);

  class array<unsigned int> SD_cluster_tab(space_dimension_cluster , N_cluster_mu);

  class array<TYPE> PSI_cluster_component_tab(space_dimension_cluster);
  
  class array<bool> is_inSD_in_new_space_tab(space_dimension_IN);

  class array<bool> is_SD_cluster_in_new_space_tab(space_dimension_cluster);

  class array<unsigned char> reordering_bin_phases_IN(space_dimension_IN);

  class array<unsigned char> reordering_bin_phases_cluster(space_dimension_cluster);
  
  files_IN_tables_read_pp_nn_cluster (full_common_vectors_used_in_file , is_it_CM_relative_cluster , cluster , NCM_HO , LCM , PSI_cluster_qn , M_cluster , PSI_IN_qn , M_IN , data , 
				      inSD_tab , SD_cluster_tab , PSI_IN_component_tab , PSI_cluster_component_tab ,
				      is_inSD_in_new_space_tab , is_SD_cluster_in_new_space_tab , reordering_bin_phases_IN , reordering_bin_phases_cluster);
  
  class array<unsigned int> A_dagger_SD_cluster_PSI_IN_total_PSI_indices(space_dimension_IN_max , space_dimension_cluster);

  class array<TYPE> A_dagger_SD_cluster_PSI_IN_components(space_dimension_IN_max , space_dimension_cluster);
  
  A_dagger_PSI_IN_total_PSI_indices_components_calc_pp_nn (PSI_cluster_qn , PSI_IN_qn , GSM_vector_helper_OUT ,
							   inSD_tab , SD_cluster_tab , PSI_IN_component_tab , PSI_cluster_component_tab ,
							   is_inSD_in_new_space_tab , is_SD_cluster_in_new_space_tab , reordering_bin_phases_IN , reordering_bin_phases_cluster ,
							   A_dagger_SD_cluster_PSI_IN_total_PSI_indices , A_dagger_SD_cluster_PSI_IN_components);
		
  PSI_OUT.Op_PSI_IN_components_add_cluster_all_processes (full_common_vectors_used_in_file , A_dagger_SD_cluster_PSI_IN_total_PSI_indices , A_dagger_SD_cluster_PSI_IN_components);
}












void A_dagger_cluster_helper::A_dagger_cluster_apply_add (
							  const bool full_common_vectors_used_in_file ,
							  const bool is_it_CM_relative_cluster , 
							  const enum particle_type cluster , 
							  const int NCM_HO , 
							  const int LCM , 
							  const class correlated_state_str &PSI_cluster_qn ,
							  const double M_cluster ,  
							  const class correlated_state_str &PSI_IN_qn ,
							  const double M_IN , 
							  class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();

  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();

  const double M_OUT = GSM_vector_helper_OUT.get_M ();

  const unsigned int BP_IN = PSI_IN_qn.get_BP ();

  const unsigned int BP_cluster = PSI_cluster_qn.get_BP ();

  if (binary_parity_product (BP_IN , BP_cluster) != BP_OUT) return;
  
  if (make_int (M_IN + M_cluster - M_OUT) != 0) return;

  switch (space)
    {
    case PROTONS_ONLY:  A_dagger_cluster_apply_add_pp_nn (full_common_vectors_used_in_file , is_it_CM_relative_cluster , cluster , NCM_HO , LCM , PSI_cluster_qn , M_cluster , PSI_IN_qn , M_IN , PSI_OUT); break;      
    case NEUTRONS_ONLY: A_dagger_cluster_apply_add_pp_nn (full_common_vectors_used_in_file , is_it_CM_relative_cluster , cluster , NCM_HO , LCM , PSI_cluster_qn , M_cluster , PSI_IN_qn , M_IN , PSI_OUT); break;
      
    case PROTONS_NEUTRONS: A_dagger_cluster_apply_add_pn (full_common_vectors_used_in_file , is_it_CM_relative_cluster , cluster , NCM_HO , LCM , PSI_cluster_qn , M_cluster , PSI_IN_qn , M_IN , PSI_OUT); break;
      
    default: abort_all ();
    }
}








void A_dagger_cluster_helper::A_dagger_cluster_coupled_to_J_apply_add (
								       const bool full_common_vectors_used_in_file ,
								       const bool is_it_CM_relative_cluster , 
								       const enum particle_type cluster , 
								       const int NCM_HO , 
								       const int LCM , 
								       const class correlated_state_str &PSI_cluster_qn , 
								       const class correlated_state_str &PSI_IN_qn , 
								       const double J_OUT , 
								       class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();

  const unsigned int BP_cluster = PSI_cluster_qn.get_BP ();

  const double J_cluster = PSI_cluster_qn.get_J ();
  
  const unsigned int BP_IN = PSI_IN_qn.get_BP ();

  const double J_IN = PSI_IN_qn.get_J ();

  if (binary_parity_product (BP_OUT , BP_IN) != BP_cluster) return;

  if (!is_it_triangle (J_IN , J_OUT , J_cluster)) return;

  const double M_OUT = GSM_vector_helper_OUT.get_M ();
    
  const int M_IN_number = make_int (2.0*J_IN + 1.0);
  
  for (int iM_IN = 0 ; iM_IN < M_IN_number ; iM_IN++)
    {
      const double M_IN = iM_IN - J_IN;

      const double M_cluster = M_OUT - M_IN;

      if (rint (abs (M_cluster) - J_cluster) <= 0.0)
	{
	  const double CG = Clebsch_Gordan (J_IN , M_IN , J_cluster , M_cluster , J_OUT , M_OUT);
	  
	  PSI_OUT += CG*A_dagger_cluster (full_common_vectors_used_in_file , is_it_CM_relative_cluster , cluster , NCM_HO , LCM , PSI_cluster_qn , M_cluster , PSI_IN_qn , M_IN);	  
	}
    }
}

















void A_dagger_cluster_helper::A_PSI_IN_total_PSI_indices_components_calc_pn (
									     const class correlated_state_str &PSI_cluster_qn ,
									     const class correlated_state_str &PSI_IN_qn ,
									     const class GSM_vector_helper_class &GSM_vector_helper_OUT ,
									     const class array<unsigned int> &inSDp_tab ,
									     const class array<unsigned int> &inSDn_tab ,
									     const class array<unsigned int> &SDp_cluster_tab ,
									     const class array<unsigned int> &SDn_cluster_tab ,
									     const class array<TYPE> &PSI_IN_component_tab ,
									     const class array<TYPE> &PSI_cluster_component_tab ,
									     const class array<bool> &is_inSDp_in_new_space_tab ,
									     const class array<bool> &is_inSDn_in_new_space_tab ,
									     const class array<bool> &is_SDp_cluster_in_new_space_tab ,
									     const class array<bool> &is_SDn_cluster_in_new_space_tab ,
									     const class array<unsigned char> &reordering_bin_phases_p_IN ,
									     const class array<unsigned char> &reordering_bin_phases_n_IN ,
									     const class array<unsigned char> &reordering_bin_phases_p_cluster ,
									     const class array<unsigned char> &reordering_bin_phases_n_cluster ,
									     class array<unsigned int> &A_SD_cluster_PSI_IN_total_PSI_indices ,
									     class array<TYPE> &A_SD_cluster_PSI_IN_components)
{
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int Z_core = prot_data.get_Z_core (); 
  const int N_core = prot_data.get_N_core ();
  
  const int Zval = prot_data.get_N_valence_nucleons (); 
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max (); 

  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();     

  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();

  const int Z_cluster = PSI_cluster_qn.get_Z ();
  const int N_cluster = PSI_cluster_qn.get_N ();
  
  const int Z_IN = PSI_IN_qn.get_Z ();
  const int N_IN = PSI_IN_qn.get_N ();
  
  const int prot_hole_states_number = prot_data.get_hole_states_number (); 
  const int neut_hole_states_number = neut_data.get_hole_states_number ();
  
  const int Zval_IN = Z_IN - Z_core + prot_hole_states_number;  
  const int Nval_IN = N_IN - N_core + neut_hole_states_number;
  
  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_data.get_configuration_set ();
  
  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  const unsigned long int total_space_dimension_OUT = GSM_vector_helper_OUT.get_total_space_dimension ();
  
  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);

  const unsigned int space_dimension_cluster = A_SD_cluster_PSI_IN_total_PSI_indices.dimension (1);
  
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_cluster_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_cluster_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
      
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (Zval_IN);
      inSDn_work_tab(i).allocate (Nval_IN);

      SDp_cluster_work_tab(i).allocate (Z_cluster);
      SDn_cluster_work_tab(i).allocate (N_cluster);      

      outSDp_work_tab(i).allocate (Zval);
      outSDn_work_tab(i).allocate (Nval);

      Cp_out_work_tab(i).allocate (Zval);
      Cn_out_work_tab(i).allocate (Nval);

      SDp_try_tab(i).allocate (Zval);
      SDn_try_tab(i).allocate (Nval);

      Cp_try_tab(i).allocate (Zval);
      Cn_try_tab(i).allocate (Nval);
    }
  
  A_SD_cluster_PSI_IN_total_PSI_indices = total_space_dimension_OUT;

  A_SD_cluster_PSI_IN_components = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int i = 0 ; i < space_dimension_IN ; i++)
    {
      if (!is_inSDp_in_new_space_tab(i) || !is_inSDn_in_new_space_tab(i)) continue;

      const unsigned int i_thread = OpenMP_thread_number_determine ();

      const unsigned int reordering_bin_phase_p_IN = reordering_bin_phases_p_IN(i);
      const unsigned int reordering_bin_phase_n_IN = reordering_bin_phases_n_IN(i);

      class Slater_determinant &inSDp = inSDp_work_tab(i_thread);
      class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

      for (int p = 0 ; p < Zval_IN ; p++) inSDp[p] = inSDp_tab(i , p);
      for (int n = 0 ; n < Nval_IN ; n++) inSDn[n] = inSDn_tab(i , n);

      const TYPE &PSI_IN_component = PSI_IN_component_tab(i);

      for (unsigned int ii = 0 ; ii < space_dimension_cluster ; ii++)
	{
	  if (!is_SDp_cluster_in_new_space_tab(ii) || !is_SDn_cluster_in_new_space_tab(ii)) continue;

	  class Slater_determinant &SDp_cluster = SDp_cluster_work_tab(i_thread);
	  class Slater_determinant &SDn_cluster = SDn_cluster_work_tab(i_thread);
	      
	  for (int p = 0 ; p < Z_cluster ; p++) SDp_cluster[p] = SDp_cluster_tab(ii , p);
	  for (int n = 0 ; n < N_cluster ; n++) SDn_cluster[n] = SDn_cluster_tab(ii , n);

	  if (!inSDp.is_SD_occupied (SDp_cluster)) continue;
	  if (!inSDn.is_SD_occupied (SDn_cluster)) continue;

	  const unsigned int reordering_bin_phase_p_cluster = reordering_bin_phases_p_cluster(ii);
	  const unsigned int reordering_bin_phase_n_cluster = reordering_bin_phases_n_cluster(ii);
	      
	  unsigned int bin_phase_p = binary_parity_product (reordering_bin_phase_p_IN , reordering_bin_phase_p_cluster);
	  unsigned int bin_phase_n = binary_parity_product (reordering_bin_phase_n_IN , reordering_bin_phase_n_cluster);
		  
	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	      
	  inSDp.excitation_SD_remove_and_bin_phase (SDp_cluster , outSDp , bin_phase_p);
		  
	  class configuration &Cp_out = Cp_out_work_tab(i_thread);

	  Cp_out.get_SD_configuration (phi_p_table , outSDp);

	  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_prot);

	  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_prot);
	  
	  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_prot);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	    
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);

	  inSDn.excitation_SD_remove_and_bin_phase (SDn_cluster , outSDn , bin_phase_n);

	  class configuration &Cn_out = Cn_out_work_tab(i_thread);

	  Cn_out.get_SD_configuration (phi_n_table , outSDn);

	  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_neut);

	  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_neut);
	      
	  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_neut); 

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	  
	  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	  class configuration &Cp_try = Cp_try_tab(i_thread);
	  class configuration &Cn_try = Cn_try_tab(i_thread);

	  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
	      
	  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_prot);
	  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_neut);

	  const int iMp_out = outSDp.iM_determine (phi_p_table);
	  const int iMn_out = outSDn.iM_determine (phi_n_table);

	  const unsigned int iCp_out = Cp_out.index_search (BPp_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
	  const unsigned int iCn_out = Cn_out.index_search (BPn_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);

	  const unsigned int outSDp_index = outSDp.index_search (BPp_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
	  const unsigned int outSDn_index = outSDn.index_search (BPn_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

	  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

	  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , n_scat_n_out , iCn_out , iMn_out);

	  const unsigned int A_SD_cluster_PSI_IN_total_PSI_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

	  const TYPE PSI_cluster_component = PSI_cluster_component_tab(ii);

	  A_SD_cluster_PSI_IN_total_PSI_indices(i , ii) = A_SD_cluster_PSI_IN_total_PSI_index;

	  A_SD_cluster_PSI_IN_components(i , ii) = (bin_phase_p == bin_phase_n) ? (PSI_cluster_component*PSI_IN_component) : (-PSI_cluster_component*PSI_IN_component);
	}
    }
}






void A_dagger_cluster_helper::A_PSI_IN_total_PSI_indices_components_calc_pp_nn (
										const class correlated_state_str &PSI_cluster_qn ,
										const class correlated_state_str &PSI_IN_qn ,
										const class GSM_vector_helper_class &GSM_vector_helper_OUT ,
										const class array<unsigned int> &inSD_tab ,
										const class array<unsigned int> &SD_cluster_tab ,
										const class array<TYPE> &PSI_IN_component_tab ,
										const class array<TYPE> &PSI_cluster_component_tab ,
										const class array<bool> &is_inSD_in_new_space_tab ,
										const class array<bool> &is_SD_cluster_in_new_space_tab ,
										const class array<unsigned char> &reordering_bin_phases_IN ,
										const class array<unsigned char> &reordering_bin_phases_cluster ,
										class array<unsigned int> &A_SD_cluster_PSI_IN_total_PSI_indices ,
										class array<TYPE> &A_SD_cluster_PSI_IN_components)
{
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int Z_core = prot_data.get_Z_core (); 
  const int N_core = prot_data.get_N_core ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max (); 

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();     
  
  const int Z_cluster = PSI_cluster_qn.get_Z ();
  const int N_cluster = PSI_cluster_qn.get_N ();

  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);
  
  const int N_core_mu = (space == PROTONS_ONLY) ? (Z_core) : (N_core);

  const int Nval_mu = data.get_N_valence_nucleons ();

  const int N_IN_mu = (space == PROTONS_ONLY) ? (PSI_IN_qn.get_Z ()) : (PSI_IN_qn.get_N ());

  const int hole_states_number_mu = data.get_hole_states_number ();
  
  const int Nval_IN_mu = N_IN_mu - N_core_mu + hole_states_number_mu;

  const int N_cluster_mu = (space == PROTONS_ONLY) ? (Z_cluster) : (N_cluster);
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  const unsigned long int total_space_dimension_OUT = GSM_vector_helper_OUT.get_total_space_dimension ();
    
  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);	  

  const unsigned int space_dimension_cluster = A_SD_cluster_PSI_IN_total_PSI_indices.dimension (1);

  class array<class Slater_determinant> inSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_cluster_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (Nval_IN_mu);

      SD_cluster_work_tab(i).allocate (N_cluster_mu);    

      outSD_work_tab(i).allocate (Nval_mu);

      C_out_work_tab(i).allocate (Nval_mu);

      SD_try_tab(i).allocate (Nval_mu);

      C_try_tab(i).allocate (Nval_mu);
    }
  
  A_SD_cluster_PSI_IN_total_PSI_indices = total_space_dimension_OUT;

  A_SD_cluster_PSI_IN_components = 0.0;
	  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int i = 0 ; i < space_dimension_IN ; i++)
    {
      if (!is_inSD_in_new_space_tab(i)) continue;

      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      const unsigned int reordering_bin_phase_IN = reordering_bin_phases_IN(i);

      class Slater_determinant &inSD = inSD_work_tab(i_thread);

      for (int mu = 0 ; mu < Nval_IN_mu ; mu++) inSD[mu] = inSD_tab(i , mu);

      const TYPE &PSI_IN_component = PSI_IN_component_tab(i);

      for (unsigned int ii = 0 ; ii < space_dimension_cluster ; ii++)
	{
	  if (!is_SD_cluster_in_new_space_tab(ii)) continue;

	  class Slater_determinant &SD_cluster = SD_cluster_work_tab(i_thread);

	  for (int mu = 0 ; mu < N_cluster_mu ; mu++) SD_cluster[mu] = SD_cluster_tab(ii , mu);

	  if (!inSD.is_SD_occupied (SD_cluster)) continue;

	  const unsigned int reordering_bin_phase_cluster = reordering_bin_phases_cluster(ii);
	      
	  unsigned int bin_phase = binary_parity_product (reordering_bin_phase_IN , reordering_bin_phase_cluster);

	  class Slater_determinant &outSD = outSD_work_tab(i_thread);

	  inSD.excitation_SD_remove_and_bin_phase (SD_cluster , outSD , bin_phase);

	  class configuration &C_out = C_out_work_tab(i_thread);

	  C_out.get_SD_configuration (phi_mu_table , outSD);

	  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

	  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
	  
	  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  class configuration &C_try = C_try_tab(i_thread);

	  class Slater_determinant &SD_try = SD_try_tab(i_thread);

	  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);

	  const int iM_out = outSD.iM_determine (phi_mu_table);

	  const unsigned int iC_out = C_out.index_search (BP_out , n_scat_out , dimensions_configuration_set , configuration_set , C_try);

	  const unsigned int outSD_index = outSD.index_search (BP_out , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try); 

	  const unsigned long int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

	  const unsigned int A_SD_cluster_PSI_IN_total_PSI_index = sum_dimensions_configuration_fixed_out + outSD_index;

	  const TYPE PSI_cluster_component = PSI_cluster_component_tab(ii);

	  const int phase = parity_from_binary_parity (bin_phase);
		  
	  A_SD_cluster_PSI_IN_total_PSI_indices(i , ii) = A_SD_cluster_PSI_IN_total_PSI_index;

	  A_SD_cluster_PSI_IN_components(i , ii) = (phase == 1) ? (PSI_cluster_component*PSI_IN_component) : (-PSI_cluster_component*PSI_IN_component);
	}
    }
}










void A_dagger_cluster_helper::A_cluster_apply_add_pn (
						      const bool full_common_vectors_used_in_file ,
						      const bool is_it_CM_relative_cluster , 
						      const enum particle_type cluster , 
						      const int NCM_HO , 
						      const int LCM , 
						      const class correlated_state_str &PSI_cluster_qn ,
						      const double M_cluster ,  
						      const class correlated_state_str &PSI_IN_qn ,
						      const double M_IN , 
						      class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();

  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
    
  const int Z_core = prot_data.get_Z_core (); 
  const int N_core = prot_data.get_N_core ();
  
  const int Z_cluster = PSI_cluster_qn.get_Z ();
  const int N_cluster = PSI_cluster_qn.get_N ();
  
  const int Z_IN = PSI_IN_qn.get_Z ();
  const int N_IN = PSI_IN_qn.get_N ();
  
  const int prot_hole_states_number = prot_data.get_hole_states_number (); 
  const int neut_hole_states_number = neut_data.get_hole_states_number ();
  
  const int Zval_IN = Z_IN - Z_core + prot_hole_states_number;  
  const int Nval_IN = N_IN - N_core + neut_hole_states_number;
  
  const double J_cluster = PSI_cluster_qn.get_J ();

  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);
  
  const string file_name_cluster_dimension = (is_it_CM_relative_cluster)
    ? (file_name_intrinsic_CM_cluster_string ("Berggren_basis_state_dimension" , cluster , NCM_HO , LCM , J_cluster , M_cluster))
    : (file_name_eigenvector_string (true , "eigenvector_dimension" , PSI_cluster_qn , M_cluster));
  
  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Zval_IN , Nval_IN , file_name_IN_dimension);
  
  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));
  
  const unsigned int space_dimension_cluster = space_dimension_read_disk (true , Z_cluster , N_cluster , file_name_cluster_dimension);
    
  class array<unsigned int> inSDp_tab(space_dimension_IN , Zval_IN);
  class array<unsigned int> inSDn_tab(space_dimension_IN , Nval_IN);

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);
 
  class array<bool> is_inSDp_in_new_space_tab(space_dimension_IN);
  class array<bool> is_inSDn_in_new_space_tab(space_dimension_IN);

  class array<unsigned char> reordering_bin_phases_p_IN(space_dimension_IN);
  class array<unsigned char> reordering_bin_phases_n_IN(space_dimension_IN);
  
  class array<unsigned int> SDp_cluster_tab(space_dimension_cluster , Z_cluster);
  class array<unsigned int> SDn_cluster_tab(space_dimension_cluster , N_cluster);

  class array<TYPE> PSI_cluster_component_tab(space_dimension_cluster);
	  
  class array<bool> is_SDp_cluster_in_new_space_tab(space_dimension_cluster);
  class array<bool> is_SDn_cluster_in_new_space_tab(space_dimension_cluster);    

  class array<unsigned char> reordering_bin_phases_p_cluster(space_dimension_cluster);
  class array<unsigned char> reordering_bin_phases_n_cluster(space_dimension_cluster);

  files_IN_tables_read_pn_cluster (full_common_vectors_used_in_file , is_it_CM_relative_cluster , cluster , NCM_HO , LCM , PSI_cluster_qn , M_cluster , PSI_IN_qn , M_IN , prot_data , neut_data ,
				   inSDp_tab , inSDn_tab , SDp_cluster_tab , SDn_cluster_tab , PSI_IN_component_tab , PSI_cluster_component_tab ,
				   is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab , is_SDp_cluster_in_new_space_tab , is_SDn_cluster_in_new_space_tab ,
				   reordering_bin_phases_p_IN , reordering_bin_phases_n_IN , reordering_bin_phases_p_cluster , reordering_bin_phases_n_cluster);
  
  class array<unsigned int> A_SD_cluster_PSI_IN_total_PSI_indices(space_dimension_IN_max , space_dimension_cluster);

  class array<TYPE> A_SD_cluster_PSI_IN_components(space_dimension_IN_max , space_dimension_cluster);
  
  A_PSI_IN_total_PSI_indices_components_calc_pn (PSI_cluster_qn , PSI_IN_qn , GSM_vector_helper_OUT ,
						 inSDp_tab , inSDn_tab , SDp_cluster_tab , SDn_cluster_tab , PSI_IN_component_tab , PSI_cluster_component_tab ,
						 is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab , is_SDp_cluster_in_new_space_tab , is_SDn_cluster_in_new_space_tab ,
						 reordering_bin_phases_p_IN , reordering_bin_phases_n_IN , reordering_bin_phases_p_cluster , reordering_bin_phases_n_cluster ,
						 A_SD_cluster_PSI_IN_total_PSI_indices , A_SD_cluster_PSI_IN_components);
	  
  PSI_OUT.Op_PSI_IN_components_add_cluster_all_processes (full_common_vectors_used_in_file , A_SD_cluster_PSI_IN_total_PSI_indices , A_SD_cluster_PSI_IN_components);	  
}











void A_dagger_cluster_helper::A_cluster_apply_add_pp_nn (
							 const bool full_common_vectors_used_in_file ,
							 const bool is_it_CM_relative_cluster , 
							 const enum particle_type cluster , 
							 const int NCM_HO , 
							 const int LCM , 
							 const class correlated_state_str &PSI_cluster_qn ,
							 const double M_cluster ,  
							 const class correlated_state_str &PSI_IN_qn ,
							 const double M_IN , 
							 class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();

  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
    
  const int Z_core = prot_data.get_Z_core (); 
  const int N_core = prot_data.get_N_core ();
    
  const int Z_cluster = PSI_cluster_qn.get_Z ();
  const int N_cluster = PSI_cluster_qn.get_N ();

  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);
  
  const int N_core_mu = (space == PROTONS_ONLY) ? (Z_core) : (N_core);

  const int N_IN_mu = (space == PROTONS_ONLY) ? (PSI_IN_qn.get_Z ()) : (PSI_IN_qn.get_N ());

  const int hole_states_number_mu = data.get_hole_states_number ();
  
  const int Nval_IN_mu = N_IN_mu - N_core_mu + hole_states_number_mu;

  const int N_cluster_mu = (space == PROTONS_ONLY) ? (Z_cluster) : (N_cluster);

  const double J_cluster = PSI_cluster_qn.get_J ();

  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);
  
  const string file_name_cluster_dimension = (is_it_CM_relative_cluster)
    ? (file_name_intrinsic_CM_cluster_string ("Berggren_basis_state_dimension" , cluster , NCM_HO , LCM , J_cluster , M_cluster))
    : (file_name_eigenvector_string (true , "eigenvector_dimension" , PSI_cluster_qn , M_cluster));
  
  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Nval_IN_mu , file_name_IN_dimension);
  
  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));

  const unsigned int space_dimension_cluster = space_dimension_read_disk (true , N_cluster_mu , file_name_cluster_dimension);
 
  class array<unsigned int> inSD_tab(space_dimension_IN , Nval_IN_mu);

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);

  class array<unsigned int> SD_cluster_tab(space_dimension_cluster , N_cluster_mu);

  class array<TYPE> PSI_cluster_component_tab(space_dimension_cluster);
  
  class array<bool> is_inSD_in_new_space_tab(space_dimension_IN);

  class array<bool> is_SD_cluster_in_new_space_tab(space_dimension_cluster);

  class array<unsigned char> reordering_bin_phases_IN(space_dimension_IN);
  
  class array<unsigned char> reordering_bin_phases_cluster(space_dimension_cluster);
  
  files_IN_tables_read_pp_nn_cluster (full_common_vectors_used_in_file , is_it_CM_relative_cluster , cluster , NCM_HO , LCM , PSI_cluster_qn , M_cluster , PSI_IN_qn , M_IN , data ,
				      inSD_tab , SD_cluster_tab , PSI_IN_component_tab , PSI_cluster_component_tab ,
				      is_inSD_in_new_space_tab , is_SD_cluster_in_new_space_tab , reordering_bin_phases_IN , reordering_bin_phases_cluster);
  
  class array<unsigned int> A_SD_cluster_PSI_IN_total_PSI_indices(space_dimension_IN_max , space_dimension_cluster);

  class array<TYPE> A_SD_cluster_PSI_IN_components(space_dimension_IN_max , space_dimension_cluster);
  
  A_PSI_IN_total_PSI_indices_components_calc_pp_nn (PSI_cluster_qn , PSI_IN_qn , GSM_vector_helper_OUT ,
						    inSD_tab , SD_cluster_tab , PSI_IN_component_tab , PSI_cluster_component_tab ,
						    is_inSD_in_new_space_tab , is_SD_cluster_in_new_space_tab , reordering_bin_phases_IN , reordering_bin_phases_cluster ,
						    A_SD_cluster_PSI_IN_total_PSI_indices , A_SD_cluster_PSI_IN_components);
		
  PSI_OUT.Op_PSI_IN_components_add_cluster_all_processes (full_common_vectors_used_in_file , A_SD_cluster_PSI_IN_total_PSI_indices , A_SD_cluster_PSI_IN_components);
}











void A_dagger_cluster_helper::A_cluster_apply_add (
						   const bool full_common_vectors_used_in_file ,
						   const bool is_it_CM_relative_cluster , 
						   const enum particle_type cluster , 
						   const int NCM_HO , 
						   const int LCM , 
						   const class correlated_state_str &PSI_cluster_qn ,
						   const double M_cluster ,  
						   const class correlated_state_str &PSI_IN_qn ,
						   const double M_IN , 
						   class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();

  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();

  const double M_OUT = GSM_vector_helper_OUT.get_M ();

  const unsigned int BP_IN = PSI_IN_qn.get_BP ();

  const unsigned int BP_cluster = PSI_cluster_qn.get_BP ();

  if (binary_parity_product (BP_IN , BP_cluster) != BP_OUT) return;
  
  if (make_int (M_IN - M_cluster - M_OUT) != 0) return;
  
  switch (space)
    {
    case PROTONS_ONLY:  A_cluster_apply_add_pp_nn (full_common_vectors_used_in_file , is_it_CM_relative_cluster , cluster , NCM_HO , LCM , PSI_cluster_qn , M_cluster , PSI_IN_qn , M_IN , PSI_OUT); break;    
    case NEUTRONS_ONLY: A_cluster_apply_add_pp_nn (full_common_vectors_used_in_file , is_it_CM_relative_cluster , cluster , NCM_HO , LCM , PSI_cluster_qn , M_cluster , PSI_IN_qn , M_IN , PSI_OUT); break;
      
    case PROTONS_NEUTRONS: A_cluster_apply_add_pn (full_common_vectors_used_in_file , is_it_CM_relative_cluster , cluster , NCM_HO , LCM , PSI_cluster_qn , M_cluster , PSI_IN_qn , M_IN , PSI_OUT); break;
      
    default: abort_all ();
    }
}







void A_dagger_cluster_helper::A_cluster_coupled_to_J_apply_add (
								const bool full_common_vectors_used_in_file ,
								const bool is_it_CM_relative_cluster , 
								const enum particle_type cluster , 
								const int NCM_HO , 
								const int LCM , 
								const class correlated_state_str &PSI_cluster_qn , 
								const class correlated_state_str &PSI_IN_qn , 
								const double J_OUT , 
								class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();

  const unsigned int BP_cluster = PSI_cluster_qn.get_BP ();

  const double J_cluster = PSI_cluster_qn.get_J ();
  
  const unsigned int BP_IN = PSI_IN_qn.get_BP ();

  const double J_IN = PSI_IN_qn.get_J ();

  if (binary_parity_product (BP_OUT , BP_IN) != BP_cluster) return;

  if (!is_it_triangle (J_IN , J_OUT , J_cluster)) return;

  const double M_OUT = GSM_vector_helper_OUT.get_M ();
    
  const int M_IN_number = make_int (2.0*J_IN + 1.0);
  
  for (int iM_IN = 0 ; iM_IN < M_IN_number ; iM_IN++)
    {
      const double M_IN = iM_IN - J_IN;

      const double M_cluster = M_IN - M_OUT;

      if (rint (abs (M_cluster) - J_cluster) <= 0.0)
	{
	  const double CG_phase = minus_one_pow (J_cluster - M_cluster)*Clebsch_Gordan (J_IN , M_IN , J_cluster , -M_cluster , J_OUT , M_OUT);

	  PSI_OUT += CG_phase*A_cluster (full_common_vectors_used_in_file , is_it_CM_relative_cluster , cluster , NCM_HO , LCM , PSI_cluster_qn , M_cluster , PSI_IN_qn , M_IN);
	}
    }
}















A_dagger_cluster_PSI_str::A_dagger_cluster_PSI_str (
						    const bool full_common_vectors_used_in_file_c ,
						    const bool is_it_CM_relative_cluster_c , 
						    const enum particle_type cluster_c , 
						    const int NCM_HO_c , 
						    const int LCM_c , 
						    const class correlated_state_str &PSI_cluster_qn_c , 
						    const double M_cluster_c ,  
						    const class correlated_state_str &PSI_IN_qn_c ,
						    const double M_IN_c)
  : full_common_vectors_used_in_file (full_common_vectors_used_in_file_c) ,
    is_it_CM_relative_cluster (is_it_CM_relative_cluster_c) ,  
    cluster (cluster_c) , 
    NCM_HO (NCM_HO_c) , 
    LCM (LCM_c) , 
    PSI_cluster_qn (PSI_cluster_qn_c) ,
    M_cluster (M_cluster_c) ,  
    PSI_IN_qn (PSI_IN_qn_c) ,
    M_IN (M_IN_c) {}








class A_dagger_cluster_PSI_str A_dagger_cluster_helper::A_dagger_cluster (
									  const bool full_common_vectors_used_in_file_c ,
									  const bool is_it_CM_relative_cluster_c , 
									  const enum particle_type cluster_c , 
									  const int NCM_HO_c , 
									  const int LCM_c , 
									  const class correlated_state_str &PSI_cluster_qn_c , 
									  const double M_cluster_c ,  
									  const class correlated_state_str &PSI_IN_qn_c ,
									  const double M_IN_c)
{
  return A_dagger_cluster_PSI_str (full_common_vectors_used_in_file_c , is_it_CM_relative_cluster_c , cluster_c , NCM_HO_c , LCM_c , PSI_cluster_qn_c , M_cluster_c , PSI_IN_qn_c , M_IN_c);
}



x_A_dagger_cluster_PSI_str::x_A_dagger_cluster_PSI_str (const TYPE &x_c , const class A_dagger_cluster_PSI_str &A_dagger_cluster_PSI_c) 
  : x (x_c) , A_dagger_cluster_PSI (A_dagger_cluster_PSI_c) {}

class x_A_dagger_cluster_PSI_str operator + (const class A_dagger_cluster_PSI_str &A_dagger_cluster_PSI)
{
  return x_A_dagger_cluster_PSI_str (1.0 , A_dagger_cluster_PSI);
}

class x_A_dagger_cluster_PSI_str operator - (const class A_dagger_cluster_PSI_str &A_dagger_cluster_PSI)
{
  return x_A_dagger_cluster_PSI_str (-1.0 , A_dagger_cluster_PSI);
}

class x_A_dagger_cluster_PSI_str operator * (const class A_dagger_cluster_PSI_str &A_dagger_cluster_PSI , const double x)
{
  return x_A_dagger_cluster_PSI_str (x , A_dagger_cluster_PSI);
}

class x_A_dagger_cluster_PSI_str operator * (const double x , const class A_dagger_cluster_PSI_str &A_dagger_cluster_PSI)
{
  return x_A_dagger_cluster_PSI_str (x , A_dagger_cluster_PSI);
}

class x_A_dagger_cluster_PSI_str operator / (const class A_dagger_cluster_PSI_str &A_dagger_cluster_PSI , const double x)
{
  const double one_over_x = 1.0/x;

  return x_A_dagger_cluster_PSI_str (one_over_x , A_dagger_cluster_PSI);
}

class x_A_dagger_cluster_PSI_str operator + (const class x_A_dagger_cluster_PSI_str &x_A_dagger_cluster_PSI)
{
  return x_A_dagger_cluster_PSI_str (x_A_dagger_cluster_PSI.x , x_A_dagger_cluster_PSI.A_dagger_cluster_PSI);
}

class x_A_dagger_cluster_PSI_str operator - (const class x_A_dagger_cluster_PSI_str &x_A_dagger_cluster_PSI)
{
  return x_A_dagger_cluster_PSI_str (-x_A_dagger_cluster_PSI.x , x_A_dagger_cluster_PSI.A_dagger_cluster_PSI);
}

#ifdef TYPEisDOUBLECOMPLEX

class x_A_dagger_cluster_PSI_str operator * (const class A_dagger_cluster_PSI_str &A_dagger_cluster_PSI , const complex<double> &x)
{
  return x_A_dagger_cluster_PSI_str (x , A_dagger_cluster_PSI);
}

class x_A_dagger_cluster_PSI_str operator * (const complex<double> &x , const class A_dagger_cluster_PSI_str &A_dagger_cluster_PSI)
{
  return x_A_dagger_cluster_PSI_str (x , A_dagger_cluster_PSI);
}

class x_A_dagger_cluster_PSI_str operator / (const class A_dagger_cluster_PSI_str &A_dagger_cluster_PSI , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return x_A_dagger_cluster_PSI_str (one_over_x , A_dagger_cluster_PSI);
}

#endif






A_dagger_cluster_coupled_to_J_PSI_str::A_dagger_cluster_coupled_to_J_PSI_str (
									      const bool full_common_vectors_used_in_file_c ,
									      const bool is_it_CM_relative_cluster_c , 
									      const enum particle_type cluster_c , 
									      const int NCM_HO_c , 
									      const int LCM_c , 
									      const class correlated_state_str &PSI_cluster_qn_c , 
									      const class correlated_state_str &PSI_IN_qn_c ,
									      const double J_OUT_c , 
									      const double M_OUT_c)
  : full_common_vectors_used_in_file (full_common_vectors_used_in_file_c) ,
    is_it_CM_relative_cluster (is_it_CM_relative_cluster_c) , 
    cluster (cluster_c) , 
    NCM_HO (NCM_HO_c) , 
    LCM (LCM_c) , 
    PSI_cluster_qn (PSI_cluster_qn_c) , 
    PSI_IN_qn (PSI_IN_qn_c) ,
    J_OUT (J_OUT_c) ,
    M_OUT (M_OUT_c) {}



class A_dagger_cluster_coupled_to_J_PSI_str A_dagger_cluster_helper::A_dagger_cluster_coupled_to_J (
												    const bool full_common_vectors_used_in_file_c ,
												    const bool is_it_CM_relative_cluster_c , 
												    const enum particle_type cluster_c , 
												    const int NCM_HO_c , 
												    const int LCM_c , 
												    const class correlated_state_str &PSI_cluster_qn_c , 
												    const class correlated_state_str &PSI_IN_qn_c ,
												    const double J_OUT_c , 
												    const double M_OUT_c)
{
  return A_dagger_cluster_coupled_to_J_PSI_str (full_common_vectors_used_in_file_c , is_it_CM_relative_cluster_c ,  cluster_c , NCM_HO_c , LCM_c , PSI_cluster_qn_c , PSI_IN_qn_c , J_OUT_c , M_OUT_c);
}



x_A_dagger_cluster_coupled_to_J_PSI_str::x_A_dagger_cluster_coupled_to_J_PSI_str (const TYPE &x_c , const class A_dagger_cluster_coupled_to_J_PSI_str &A_dagger_cluster_coupled_to_J_PSI_c) 
  : x (x_c) , A_dagger_cluster_coupled_to_J_PSI (A_dagger_cluster_coupled_to_J_PSI_c) {}

class x_A_dagger_cluster_coupled_to_J_PSI_str operator + (const class A_dagger_cluster_coupled_to_J_PSI_str &A_dagger_cluster_coupled_to_J_PSI)
{
  return x_A_dagger_cluster_coupled_to_J_PSI_str (1.0 , A_dagger_cluster_coupled_to_J_PSI);
}

class x_A_dagger_cluster_coupled_to_J_PSI_str operator - (const class A_dagger_cluster_coupled_to_J_PSI_str &A_dagger_cluster_coupled_to_J_PSI)
{
  return x_A_dagger_cluster_coupled_to_J_PSI_str (-1.0 , A_dagger_cluster_coupled_to_J_PSI);
}

class x_A_dagger_cluster_coupled_to_J_PSI_str operator * (const class A_dagger_cluster_coupled_to_J_PSI_str &A_dagger_cluster_coupled_to_J_PSI , const double x)
{
  return x_A_dagger_cluster_coupled_to_J_PSI_str (x , A_dagger_cluster_coupled_to_J_PSI);
}

class x_A_dagger_cluster_coupled_to_J_PSI_str operator * (const double x , const class A_dagger_cluster_coupled_to_J_PSI_str &A_dagger_cluster_coupled_to_J_PSI)
{
  return x_A_dagger_cluster_coupled_to_J_PSI_str (x , A_dagger_cluster_coupled_to_J_PSI);
}

class x_A_dagger_cluster_coupled_to_J_PSI_str operator / (const class A_dagger_cluster_coupled_to_J_PSI_str &A_dagger_cluster_coupled_to_J_PSI , const double x)
{
  const double one_over_x = 1.0/x;

  return x_A_dagger_cluster_coupled_to_J_PSI_str (one_over_x , A_dagger_cluster_coupled_to_J_PSI);
}

class x_A_dagger_cluster_coupled_to_J_PSI_str operator + (const class x_A_dagger_cluster_coupled_to_J_PSI_str &x_A_dagger_cluster_coupled_to_J_PSI)
{
  return x_A_dagger_cluster_coupled_to_J_PSI_str (x_A_dagger_cluster_coupled_to_J_PSI.x , x_A_dagger_cluster_coupled_to_J_PSI.A_dagger_cluster_coupled_to_J_PSI);
}

class x_A_dagger_cluster_coupled_to_J_PSI_str operator - (const class x_A_dagger_cluster_coupled_to_J_PSI_str &x_A_dagger_cluster_coupled_to_J_PSI)
{
  return x_A_dagger_cluster_coupled_to_J_PSI_str (-x_A_dagger_cluster_coupled_to_J_PSI.x , x_A_dagger_cluster_coupled_to_J_PSI.A_dagger_cluster_coupled_to_J_PSI);
}

#ifdef TYPEisDOUBLECOMPLEX

class x_A_dagger_cluster_coupled_to_J_PSI_str operator * (const class A_dagger_cluster_coupled_to_J_PSI_str &A_dagger_cluster_coupled_to_J_PSI , const complex<double> &x)
{
  return x_A_dagger_cluster_coupled_to_J_PSI_str (x , A_dagger_cluster_coupled_to_J_PSI);
}

class x_A_dagger_cluster_coupled_to_J_PSI_str operator * (const complex<double> &x , const class A_dagger_cluster_coupled_to_J_PSI_str &A_dagger_cluster_coupled_to_J_PSI)
{
  return x_A_dagger_cluster_coupled_to_J_PSI_str (x , A_dagger_cluster_coupled_to_J_PSI);
}

class x_A_dagger_cluster_coupled_to_J_PSI_str operator / (const class A_dagger_cluster_coupled_to_J_PSI_str &A_dagger_cluster_coupled_to_J_PSI , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return x_A_dagger_cluster_coupled_to_J_PSI_str (one_over_x , A_dagger_cluster_coupled_to_J_PSI);
}

#endif









A_cluster_PSI_str::A_cluster_PSI_str (
				      const bool full_common_vectors_used_in_file_c ,
				      const bool is_it_CM_relative_cluster_c , 
				      const enum particle_type cluster_c , 
				      const int NCM_HO_c , 
				      const int LCM_c , 
				      const class correlated_state_str &PSI_cluster_qn_c , 
				      const double M_cluster_c ,  
				      const class correlated_state_str &PSI_IN_qn_c ,
				      const double M_IN_c)
  : full_common_vectors_used_in_file (full_common_vectors_used_in_file_c) ,
    is_it_CM_relative_cluster (is_it_CM_relative_cluster_c) ,  
    cluster (cluster_c) , 
    NCM_HO (NCM_HO_c) , 
    LCM (LCM_c) , 
    PSI_cluster_qn (PSI_cluster_qn_c) ,
    M_cluster (M_cluster_c) ,  
    PSI_IN_qn (PSI_IN_qn_c) ,
    M_IN (M_IN_c) {}








class A_cluster_PSI_str A_dagger_cluster_helper::A_cluster (
							    const bool full_common_vectors_used_in_file_c ,
							    const bool is_it_CM_relative_cluster_c , 
							    const enum particle_type cluster_c , 
							    const int NCM_HO_c , 
							    const int LCM_c , 
							    const class correlated_state_str &PSI_cluster_qn_c , 
							    const double M_cluster_c ,  
							    const class correlated_state_str &PSI_IN_qn_c ,
							    const double M_IN_c)
{
  return A_cluster_PSI_str (full_common_vectors_used_in_file_c , is_it_CM_relative_cluster_c , cluster_c , NCM_HO_c , LCM_c , PSI_cluster_qn_c , M_cluster_c , PSI_IN_qn_c , M_IN_c);
}







x_A_cluster_PSI_str::x_A_cluster_PSI_str (const TYPE &x_c , const class A_cluster_PSI_str &A_cluster_PSI_c) 
  : x (x_c) , A_cluster_PSI (A_cluster_PSI_c) {}

class x_A_cluster_PSI_str operator + (const class A_cluster_PSI_str &A_cluster_PSI)
{
  return x_A_cluster_PSI_str (1.0 , A_cluster_PSI);
}

class x_A_cluster_PSI_str operator - (const class A_cluster_PSI_str &A_cluster_PSI)
{
  return x_A_cluster_PSI_str (-1.0 , A_cluster_PSI);
}

class x_A_cluster_PSI_str operator * (const class A_cluster_PSI_str &A_cluster_PSI , const double x)
{
  return x_A_cluster_PSI_str (x , A_cluster_PSI);
}

class x_A_cluster_PSI_str operator * (const double x , const class A_cluster_PSI_str &A_cluster_PSI)
{
  return x_A_cluster_PSI_str (x , A_cluster_PSI);
}

class x_A_cluster_PSI_str operator / (const class A_cluster_PSI_str &A_cluster_PSI , const double x)
{
  const double one_over_x = 1.0/x;

  return x_A_cluster_PSI_str (one_over_x , A_cluster_PSI);
}

class x_A_cluster_PSI_str operator + (const class x_A_cluster_PSI_str &x_A_cluster_PSI)
{
  return x_A_cluster_PSI_str (x_A_cluster_PSI.x , x_A_cluster_PSI.A_cluster_PSI);
}

class x_A_cluster_PSI_str operator - (const class x_A_cluster_PSI_str &x_A_cluster_PSI)
{
  return x_A_cluster_PSI_str (-x_A_cluster_PSI.x , x_A_cluster_PSI.A_cluster_PSI);
}

#ifdef TYPEisDOUBLECOMPLEX

class x_A_cluster_PSI_str operator * (const class A_cluster_PSI_str &A_cluster_PSI , const complex<double> &x)
{
  return x_A_cluster_PSI_str (x , A_cluster_PSI);
}

class x_A_cluster_PSI_str operator * (const complex<double> &x , const class A_cluster_PSI_str &A_cluster_PSI)
{
  return x_A_cluster_PSI_str (x , A_cluster_PSI);
}

class x_A_cluster_PSI_str operator / (const class A_cluster_PSI_str &A_cluster_PSI , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return x_A_cluster_PSI_str (one_over_x , A_cluster_PSI);
}

#endif






A_cluster_coupled_to_J_PSI_str::A_cluster_coupled_to_J_PSI_str (
								const bool full_common_vectors_used_in_file_c ,
								const bool is_it_CM_relative_cluster_c ,  
								const enum particle_type cluster_c , 
								const int NCM_HO_c , 
								const int LCM_c , 
								const class correlated_state_str &PSI_cluster_qn_c , 
								const class correlated_state_str &PSI_IN_qn_c ,
								const double J_OUT_c , 
								const double M_OUT_c)
  : full_common_vectors_used_in_file (full_common_vectors_used_in_file_c) ,
    is_it_CM_relative_cluster (is_it_CM_relative_cluster_c) , 
    cluster (cluster_c) , 
    NCM_HO (NCM_HO_c) , 
    LCM (LCM_c) , 
    PSI_cluster_qn (PSI_cluster_qn_c) , 
    PSI_IN_qn (PSI_IN_qn_c) ,
    J_OUT (J_OUT_c) ,
    M_OUT (M_OUT_c) {}



class A_cluster_coupled_to_J_PSI_str A_dagger_cluster_helper::A_cluster_coupled_to_J (
										      const bool full_common_vectors_used_in_file_c ,
										      const bool is_it_CM_relative_cluster_c ,  
										      const enum particle_type cluster_c , 
										      const int NCM_HO_c , 
										      const int LCM_c , 
										      const class correlated_state_str &PSI_cluster_qn_c , 
										      const class correlated_state_str &PSI_IN_qn_c ,
										      const double J_OUT_c , 
										      const double M_OUT_c)
{
  return A_cluster_coupled_to_J_PSI_str (full_common_vectors_used_in_file_c , is_it_CM_relative_cluster_c , cluster_c , NCM_HO_c , LCM_c , PSI_cluster_qn_c , PSI_IN_qn_c , J_OUT_c , M_OUT_c);
}



x_A_cluster_coupled_to_J_PSI_str::x_A_cluster_coupled_to_J_PSI_str (const TYPE &x_c , const class A_cluster_coupled_to_J_PSI_str &A_cluster_coupled_to_J_PSI_c) 
  : x (x_c) , A_cluster_coupled_to_J_PSI (A_cluster_coupled_to_J_PSI_c) {}

class x_A_cluster_coupled_to_J_PSI_str operator + (const class A_cluster_coupled_to_J_PSI_str &A_cluster_coupled_to_J_PSI)
{
  return x_A_cluster_coupled_to_J_PSI_str (1.0 , A_cluster_coupled_to_J_PSI);
}

class x_A_cluster_coupled_to_J_PSI_str operator - (const class A_cluster_coupled_to_J_PSI_str &A_cluster_coupled_to_J_PSI)
{
  return x_A_cluster_coupled_to_J_PSI_str (-1.0 , A_cluster_coupled_to_J_PSI);
}

class x_A_cluster_coupled_to_J_PSI_str operator * (const class A_cluster_coupled_to_J_PSI_str &A_cluster_coupled_to_J_PSI , const double x)
{
  return x_A_cluster_coupled_to_J_PSI_str (x , A_cluster_coupled_to_J_PSI);
}

class x_A_cluster_coupled_to_J_PSI_str operator * (const double x , const class A_cluster_coupled_to_J_PSI_str &A_cluster_coupled_to_J_PSI)
{
  return x_A_cluster_coupled_to_J_PSI_str (x , A_cluster_coupled_to_J_PSI);
}

class x_A_cluster_coupled_to_J_PSI_str operator / (const class A_cluster_coupled_to_J_PSI_str &A_cluster_coupled_to_J_PSI , const double x)
{
  const double one_over_x = 1.0/x;

  return x_A_cluster_coupled_to_J_PSI_str (one_over_x , A_cluster_coupled_to_J_PSI);
}

class x_A_cluster_coupled_to_J_PSI_str operator + (const class x_A_cluster_coupled_to_J_PSI_str &x_A_cluster_coupled_to_J_PSI)
{
  return x_A_cluster_coupled_to_J_PSI_str (x_A_cluster_coupled_to_J_PSI.x , x_A_cluster_coupled_to_J_PSI.A_cluster_coupled_to_J_PSI);
}

class x_A_cluster_coupled_to_J_PSI_str operator - (const class x_A_cluster_coupled_to_J_PSI_str &x_A_cluster_coupled_to_J_PSI)
{
  return x_A_cluster_coupled_to_J_PSI_str (-x_A_cluster_coupled_to_J_PSI.x , x_A_cluster_coupled_to_J_PSI.A_cluster_coupled_to_J_PSI);
}

#ifdef TYPEisDOUBLECOMPLEX

class x_A_cluster_coupled_to_J_PSI_str operator * (const class A_cluster_coupled_to_J_PSI_str &A_cluster_coupled_to_J_PSI , const complex<double> &x)
{
  return x_A_cluster_coupled_to_J_PSI_str (x , A_cluster_coupled_to_J_PSI);
}

class x_A_cluster_coupled_to_J_PSI_str operator * (const complex<double> &x , const class A_cluster_coupled_to_J_PSI_str &A_cluster_coupled_to_J_PSI)
{
  return x_A_cluster_coupled_to_J_PSI_str (x , A_cluster_coupled_to_J_PSI);
}

class x_A_cluster_coupled_to_J_PSI_str operator / (const class A_cluster_coupled_to_J_PSI_str &A_cluster_coupled_to_J_PSI , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return x_A_cluster_coupled_to_J_PSI_str (one_over_x , A_cluster_coupled_to_J_PSI);
}

#endif

