#include "../GSM_include/GSM_include_def.h"

using namespace inputs_misc;

class nucleons_data;



// TYPE is double or complex
// -------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------


// Calculation and storage of uncoupled TBMEs for Hamiltonian times vector
// -----------------------------------------------------------------------
// As one uses M-scheme, TBMEs must be uncoupled to calculate the Hamiltonian NBMEs.
// As J-coupled TBMEs as always stored, uncoupled TBMEs can be directly calculated from J-coupled TBMEs with Clebsch-Gordan coefficients.
//
// One needs to consider uncoupled TBMEs using the following Hamiltonian storage options:
// PARTIAL_STORAGE: uncoupled TBMEs indices are stored along with reordering phases, and NBMEs, so that one needs the present array of uncoupled TBMEs to reobtain NBMEs.
// ON_THE_FLY: Hamiltonian is recalculated on the fly for H.Psi operation and can use the present array of uncoupled TBMEs to obtain NBMEs.
//
// pp, nn and pn uncoupled TBMEs are all stored in a single standard array. Their indices read, for fixed parity and M[pair]:
// pair_index[out] + dimension_pairs_out.pair_index[in] + sum.dimensions,
// where pair_index[in], pair_index[out] and dimension_pairs_in have fixed parity and M[pair],
// and sum.dimensions is the sum of all TBMEs space dimensions of binary parity (see observables_basic_functions.cpp for definition)
// and M[pair] index (see GSM_vector_dimensions.cpp) smaller than the current one.
// If a pair is not considered in one node, its index is put to INFINITE_PAIR_INDEX (4294967295 in const.h), and to dimension_List afterwards.
//
// One does not use symmetry as, using MPI, the pairs entering the in and out GSM vectors can be different, so that symmetry is broken at this level.
// One does not use time-reveral symmetry either for the same reason.
//
// One first stores pp TBMEs (if any), then nn TBMEs (if any), and finally pn TBMEs (if any) in the array of TBMEs.
//
// There are constructors when one considers pp/nn TBMEs only, for example if one has valence protons only or valence neutrons only,
// or pp, nn and pn TBMEs if one has both valence protons and neutrons.
//
// MPI distribution is implicit therein as the pairs of the in and out spaces, which are input of constructors, have been selected so as to be used in the current MPI node.
// OpenMP distribution is used for the calculation of TBMEs, by distributing over the pairs indices of the in space for pp, nn and pn TBMEs.


uncoupled_TBMEs_class::uncoupled_TBMEs_class ()
  : zero_TBME (0.0) ,
    is_it_pp_nn (false) ,
    dimension_List_pp (0) ,
    dimension_List_nn (0) , 
    dimension_List_pn (0) , 
    dimension_List_pp_nn (0) , 
    dimension_List (0) , 
    List (NULL)
{}

uncoupled_TBMEs_class::uncoupled_TBMEs_class (
					      const bool is_there_cout , 
					      const unsigned int N_nljm ,
					      const class array<class pair_str> &pairs_in_tab , 
					      const class array<class pair_str> &pairs_out_tab , 
					      const class array<class nljm_struct> &phi_table , 
					      const class TBMEs_class &TBMEs)
  : zero_TBME (0.0) ,
    is_it_pp_nn (false) ,
    dimension_List_pp (0) ,
    dimension_List_nn (0) , 
    dimension_List_pn (0) , 
    dimension_List_pp_nn (0) , 
    dimension_List (0) , 
    List (NULL)
{
  allocate (is_there_cout , N_nljm , pairs_in_tab , pairs_out_tab , phi_table , TBMEs);
}

uncoupled_TBMEs_class::uncoupled_TBMEs_class (
					      const bool is_there_cout , 
					      const unsigned int Np_nljm ,
					      const unsigned int Nn_nljm ,
					      const bool is_pp_calculated , 
					      const bool is_nn_calculated , 
					      const bool is_pn_non_zero , 
					      const class array<class pair_str> &pp_pairs_in_tab , 
					      const class array<class pair_str> &nn_pairs_in_tab , 
					      const class array<class pair_str> &pn_pairs_in_tab , 
					      const class array<class pair_str> &pp_pairs_out_tab , 
					      const class array<class pair_str> &nn_pairs_out_tab , 
					      const class array<class pair_str> &pn_pairs_out_tab , 
					      const class array<class nljm_struct> &phi_p_table , 
					      const class array<class nljm_struct> &phi_n_table , 
					      const class TBMEs_class &TBMEs_pp , 
					      const class TBMEs_class &TBMEs_nn , 
					      const class TBMEs_class &TBMEs_pn)
: zero_TBME (0.0) ,
  is_it_pp_nn (false) ,
  dimension_List_pp (0) ,
  dimension_List_nn (0) , 
  dimension_List_pn (0) , 
  dimension_List_pp_nn (0) , 
  dimension_List (0) , 
  List (NULL)
{
  allocate (is_there_cout , Np_nljm , Nn_nljm , is_pp_calculated , is_nn_calculated , is_pn_non_zero , pp_pairs_in_tab , nn_pairs_in_tab , pn_pairs_in_tab ,
	    pp_pairs_out_tab , nn_pairs_out_tab , pn_pairs_out_tab , phi_p_table , phi_n_table , TBMEs_pp , TBMEs_nn , TBMEs_pn);
}

uncoupled_TBMEs_class::uncoupled_TBMEs_class (const class uncoupled_TBMEs_class &X)
  : zero_TBME (0.0) ,
    is_it_pp_nn (false) ,
    dimension_List_pp (0) ,
    dimension_List_nn (0) , 
    dimension_List_pn (0) , 
    dimension_List_pp_nn (0) , 
    dimension_List (0) , 
    List (NULL)
{
  allocate_fill (X);
}
	
uncoupled_TBMEs_class::~uncoupled_TBMEs_class ()
{
  delete [] List;
}
				      
void uncoupled_TBMEs_class::allocate (
				      const bool is_there_cout , 
				      const unsigned int N_nljm ,
				      const class array<class pair_str> &pairs_in_tab , 
				      const class array<class pair_str> &pairs_out_tab , 
				      const class array<class nljm_struct> &phi_table , 
				      const class TBMEs_class &TBMEs)
{
  is_it_pp_nn = true;

  dimension_List_pp = 0;
  dimension_List_nn = 0;
  dimension_List_pn = 0;

  dimension_List_pp_nn = 0;

  dimension_List = 0;  

  List = NULL;

  if (N_nljm == 0) return;

  bp_table.allocate (N_nljm , N_nljm);
  im_table.allocate (N_nljm , N_nljm);

  int im_max = 0;

  for (unsigned int mu = 0 ; mu < N_nljm ; mu++)
    for (unsigned int mu_p = 0 ; mu_p < N_nljm ; mu_p++)
      {
	const class pair_str pair(mu , mu_p);

	const unsigned int bp = pair.bp_determine (phi_table , phi_table);

	bp_table(mu , mu_p) = bp;

	const int im = pair.im_determine (phi_table , phi_table);

	im_table(mu , mu_p) = im;

	im_max = max (im_max , im);
      }

  const int im_max_plus_one = im_max + 1;

  dimensions_pairs_in.allocate  (2 , im_max_plus_one);  
  dimensions_pairs_out.allocate (2 , im_max_plus_one);

  dimensions_pairs_in  = 0;
  dimensions_pairs_out = 0;

  pairs_in_indices.allocate  (N_nljm , N_nljm);
  pairs_out_indices.allocate (N_nljm , N_nljm);

  pairs_in_indices  = INFINITE_PAIR_INDEX;
  pairs_out_indices = INFINITE_PAIR_INDEX; 

  const unsigned int dimension_pairs_in  = pairs_in_tab.dimension (0);
  const unsigned int dimension_pairs_out = pairs_out_tab.dimension (0);

  for (unsigned int i_pair_in = 0 ; i_pair_in < dimension_pairs_in ; i_pair_in++)
    {
      const class pair_str &pair = pairs_in_tab(i_pair_in);

      const unsigned int mu = pair.get_left ();
      const unsigned int mu_p = pair.get_right ();

      const unsigned int bp = bp_table(mu , mu_p);

      const int im = im_table(mu , mu_p);

      pairs_in_indices(mu , mu_p) = dimensions_pairs_in(bp , im)++;
    }
  
  for (unsigned int i_pair_out = 0 ; i_pair_out < dimension_pairs_out ; i_pair_out++)
    {
      const class pair_str &pair = pairs_out_tab(i_pair_out);

      const unsigned int mu = pair.get_left ();
      const unsigned int mu_p = pair.get_right ();

      const unsigned int bp = bp_table(mu , mu_p);
      
      const int im = im_table(mu , mu_p);

      pairs_out_indices(mu , mu_p) = dimensions_pairs_out(bp , im)++;
    }

  unsigned int sum_dimensions_bef = 0;

  unsigned int dimension_bef = 0;

  sum_dimensions.allocate (2 , im_max_plus_one);

  for (unsigned int bp = 0 ; bp <= 1 ; bp++)
    for (int im = 0 ; im <= im_max ; im++)
      {
	const unsigned int dimension = dimensions_pairs_in(bp , im)*dimensions_pairs_out(bp , im);

	sum_dimensions(bp , im) = sum_dimensions_bef + dimension_bef;

	dimension_List += dimension;

	dimension_bef = dimension;

	sum_dimensions_bef = sum_dimensions(bp , im);
      }
  
  if (dimension_List == 0) return;

  List = new TYPE [dimension_List];

  for (unsigned int i = 0 ; i < dimension_List ; i++) List[i] = 0.0;

  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif  
  for (unsigned int i_pair_in = 0 ; i_pair_in < dimension_pairs_in ; i_pair_in++)
    {
      const class pair_str &pair_in = pairs_in_tab(i_pair_in);

      const unsigned int mu_in   = pair_in.get_left ();
      const unsigned int mu_p_in = pair_in.get_right ();

      const unsigned int bp_in = bp_table(mu_in , mu_p_in);
      
      const int im_in = im_table(mu_in , mu_p_in);
      
      for (unsigned int i_pair_out = 0 ; i_pair_out < dimension_pairs_out ; i_pair_out++)
	{
	  const class pair_str &pair_out = pairs_out_tab(i_pair_out);

	  const unsigned int mu_out   = pair_out.get_left ();
	  const unsigned int mu_p_out = pair_out.get_right ();

	  const unsigned int bp_out = bp_table(mu_out , mu_p_out);
	  
	  const int im_out = im_table(mu_out , mu_p_out);
	  
	  if ((bp_in == bp_out) && (im_in == im_out))
	    {
	      const unsigned int index = index_determine_pp_nn (mu_in , mu_p_in , mu_out , mu_p_out);
	      
	      List[index] = TBMEs.M_TBME (mu_in , mu_p_in , mu_out , mu_p_out);
	    }
	}
    }

  for (unsigned int mu = 0 ; mu < N_nljm ; mu++)
    for (unsigned int mu_p = 0 ; mu_p < N_nljm ; mu_p++)
      {
	pairs_in_indices (mu , mu_p) = min (pairs_in_indices (mu , mu_p) , dimension_List);
	pairs_out_indices(mu , mu_p) = min (pairs_out_indices(mu , mu_p) , dimension_List);
      }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time;
  
      cout << endl << "Uncoupled TBMEs calculated. time:" << relative_time << " s" << endl << endl;
    }
}


void uncoupled_TBMEs_class::allocate (
				      const bool is_there_cout , 
				      const unsigned int Np_nljm ,				      
				      const unsigned int Nn_nljm ,
				      const bool is_pp_calculated , 
				      const bool is_nn_calculated , 
				      const bool is_pn_non_zero , 
				      const class array<class pair_str> &pp_pairs_in_tab , 
				      const class array<class pair_str> &nn_pairs_in_tab , 
				      const class array<class pair_str> &pn_pairs_in_tab , 
				      const class array<class pair_str> &pp_pairs_out_tab , 
				      const class array<class pair_str> &nn_pairs_out_tab , 
				      const class array<class pair_str> &pn_pairs_out_tab , 
				      const class array<class nljm_struct> &phi_p_table , 
				      const class array<class nljm_struct> &phi_n_table , 
				      const class TBMEs_class &TBMEs_pp , 
				      const class TBMEs_class &TBMEs_nn , 
				      const class TBMEs_class &TBMEs_pn)
{
  is_it_pp_nn = false;
  
  dimension_List_pp = 0;
  dimension_List_nn = 0;
  dimension_List_pn = 0;

  dimension_List_pp_nn = 0;

  dimension_List = 0;

  List = NULL;
  
  if (is_pp_calculated && (Np_nljm > 0)) pp_constructor_part (Np_nljm , pp_pairs_in_tab , pp_pairs_out_tab , phi_p_table);
  if (is_nn_calculated && (Nn_nljm > 0)) nn_constructor_part (Nn_nljm , nn_pairs_in_tab , nn_pairs_out_tab , phi_n_table);

  if (is_pn_non_zero && (Np_nljm > 0) && (Nn_nljm > 0)) pn_constructor_part (Np_nljm , Nn_nljm , pn_pairs_in_tab , pn_pairs_out_tab , phi_p_table , phi_n_table);

  dimension_List_pp_nn = dimension_List_pp + dimension_List_nn;
  
  dimension_List = dimension_List_pp_nn + dimension_List_pn;
  
  nn_sum_dimensions += dimension_List_pp;
 
  pn_sum_dimensions += dimension_List_pp_nn;

  if (is_pp_calculated)
    {  
      for (unsigned int p = 0 ; p < Np_nljm ; p++)
	for (unsigned int pp = 0 ; pp < Np_nljm ; pp++)
	  {
	    pp_pairs_in_indices (p , pp) = min (pp_pairs_in_indices (p , pp) , dimension_List);
	    pp_pairs_out_indices(p , pp) = min (pp_pairs_out_indices(p , pp) , dimension_List);
	  }
    }

  if (is_nn_calculated)
    {
      for (unsigned int n = 0 ; n < Nn_nljm ; n++)
	for (unsigned int nn = 0 ; nn < Nn_nljm ; nn++)
	  {
	    nn_pairs_in_indices (n , nn) = min (nn_pairs_in_indices (n , nn) , dimension_List);
	    nn_pairs_out_indices(n , nn) = min (nn_pairs_out_indices(n , nn) , dimension_List);
	  }
    }
  
  if (is_pn_non_zero)
    {
      for (unsigned int p = 0 ; p < Np_nljm ; p++)
	for (unsigned int n = 0 ; n < Nn_nljm ; n++)
	  {
	    pn_pairs_in_indices (p , n) = min (pn_pairs_in_indices (p , n) , dimension_List);
	    pn_pairs_out_indices(p , n) = min (pn_pairs_out_indices(p , n) , dimension_List);
	  }
    }
  
  if (dimension_List == 0) return;

  List = new TYPE [dimension_List];

  for (unsigned int i = 0 ; i < dimension_List ; i++) List[i] = 0.0;
	
  const unsigned int dimension_pp_pairs_in = pp_pairs_in_tab.dimension (0);
  const unsigned int dimension_nn_pairs_in = nn_pairs_in_tab.dimension (0);
  const unsigned int dimension_pn_pairs_in = pn_pairs_in_tab.dimension (0);

  const unsigned int dimension_pp_pairs_out = pp_pairs_out_tab.dimension (0);
  const unsigned int dimension_nn_pairs_out = nn_pairs_out_tab.dimension (0);
  const unsigned int dimension_pn_pairs_out = pn_pairs_out_tab.dimension (0);

  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif  
  for (unsigned int i_pair_in = 0 ; i_pair_in < dimension_pp_pairs_in ; i_pair_in++)
    {
      const class pair_str &pair_in = pp_pairs_in_tab(i_pair_in);

      const unsigned int p_in  = pair_in.get_left ();
      const unsigned int pp_in = pair_in.get_right ();

      const unsigned int bp_in = bp_pp_table(p_in , pp_in);
      
      const int im_in = im_pp_table(p_in , pp_in);

      for (unsigned int i_pair_out = 0 ; i_pair_out < dimension_pp_pairs_out ; i_pair_out++)
	{
	  const class pair_str &pair_out = pp_pairs_out_tab(i_pair_out);

	  const unsigned int p_out  = pair_out.get_left ();
	  const unsigned int pp_out = pair_out.get_right ();

	  const unsigned int bp_out = bp_pp_table(p_out , pp_out);

	  const int im_out = im_pp_table(p_out , pp_out);

	  if ((bp_in == bp_out) && (im_in == im_out))
	    {
	      const unsigned int index = pp_index_determine (p_in , pp_in , p_out , pp_out);

	      List[index] = TBMEs_pp.M_TBME (p_in , pp_in , p_out , pp_out);
	    }
	}
    }

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif  
  for (unsigned int i_pair_in = 0 ; i_pair_in < dimension_nn_pairs_in ; i_pair_in++)
    {
      const class pair_str &pair_in = nn_pairs_in_tab(i_pair_in);

      const unsigned int n_in  = pair_in.get_left ();
      const unsigned int nn_in = pair_in.get_right ();

      const unsigned int bp_in = bp_nn_table(n_in , nn_in);

      const int im_in = im_nn_table(n_in , nn_in);

      for (unsigned int i_pair_out = 0 ; i_pair_out < dimension_nn_pairs_out ; i_pair_out++)
	{
	  const class pair_str &pair_out = nn_pairs_out_tab(i_pair_out);

	  const unsigned int n_out  = pair_out.get_left ();
	  const unsigned int nn_out = pair_out.get_right ();

	  const unsigned int bp_out = bp_nn_table(n_out , nn_out);
	  
	  const int im_out = im_nn_table(n_out , nn_out);

	  if ((bp_in == bp_out) && (im_in == im_out))
	    {
	      const unsigned int index = nn_index_determine (n_in , nn_in , n_out , nn_out);

	      List[index] = TBMEs_nn.M_TBME (n_in , nn_in , n_out , nn_out);
	    }
	}
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif  
  for (unsigned int i_pair_in = 0 ; i_pair_in < dimension_pn_pairs_in ; i_pair_in++)
    {
      const class pair_str &pair_in = pn_pairs_in_tab(i_pair_in);
      
      const unsigned int p_in = pair_in.get_left ();
      const unsigned int n_in = pair_in.get_right ();

      const unsigned int bp_in = bp_pn_table(p_in , n_in);

      const int im_in = im_pn_table(p_in , n_in);

      for (unsigned int i_pair_out = 0 ; i_pair_out < dimension_pn_pairs_out ; i_pair_out++)
	{
	  const class pair_str &pair_out = pn_pairs_out_tab(i_pair_out);

	  const unsigned int p_out = pair_out.get_left ();
	  const unsigned int n_out = pair_out.get_right ();

	  const unsigned int bp_out = bp_pn_table(p_out , n_out);

	  const int im_out = im_pn_table(p_out , n_out);

	  if ((bp_in == bp_out) && (im_in == im_out))
	    {
	      const unsigned int index = pn_index_determine (p_in , n_in , p_out , n_out);

	      List[index] = TBMEs_pn.M_TBME (p_in , n_in , p_out , n_out);
	    }
	}
    }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time;
  
      cout << endl << "Uncoupled TBMEs calculated. time:" << relative_time << " s" << endl << endl;
    }
}







void uncoupled_TBMEs_class::pp_constructor_part (
						 const unsigned int Np_nljm ,
						 const class array<class pair_str> &pp_pairs_in_tab , 
						 const class array<class pair_str> &pp_pairs_out_tab , 
						 const class array<class nljm_struct> &phi_p_table)
{ 
  bp_pp_table.allocate (Np_nljm , Np_nljm);
  im_pp_table.allocate (Np_nljm , Np_nljm);

  int im_pp_max = 0;

  for (unsigned int p = 0 ; p < Np_nljm ; p++)
    for (unsigned int pp = 0 ; pp < Np_nljm ; pp++)
      {
	const class pair_str pair(p , pp);

	const unsigned int bp = pair.bp_determine (phi_p_table , phi_p_table);

	const int im = pair.im_determine (phi_p_table , phi_p_table);
	
	bp_pp_table(p , pp) = bp;
	im_pp_table(p , pp) = im;

	im_pp_max = max (im_pp_max , im);
      }

  const int im_pp_max_plus_one = im_pp_max + 1;

  dimensions_pp_pairs_in.allocate  (2 , im_pp_max_plus_one);  
  dimensions_pp_pairs_out.allocate (2 , im_pp_max_plus_one);

  dimensions_pp_pairs_in  = 0;
  dimensions_pp_pairs_out = 0;

  pp_pairs_in_indices.allocate  (Np_nljm , Np_nljm);
  pp_pairs_out_indices.allocate (Np_nljm , Np_nljm);

  pp_pairs_in_indices  = INFINITE_PAIR_INDEX;
  pp_pairs_out_indices = INFINITE_PAIR_INDEX;

  const unsigned int dimension_pp_pairs_in = pp_pairs_in_tab.dimension (0);
  const unsigned int dimension_pp_pairs_out = pp_pairs_out_tab.dimension (0);

  for (unsigned int i_pair_in = 0 ; i_pair_in < dimension_pp_pairs_in ; i_pair_in++)
    {
      const class pair_str &pair = pp_pairs_in_tab(i_pair_in);

      const unsigned int p  = pair.get_left ();
      const unsigned int pp = pair.get_right ();

      const unsigned int bp = bp_pp_table(p , pp);

      const int im = im_pp_table(p , pp);

      pp_pairs_in_indices(p , pp) = dimensions_pp_pairs_in(bp , im)++;
    }

  for (unsigned int i_pair_out = 0 ; i_pair_out < dimension_pp_pairs_out ; i_pair_out++)
    {
      const class pair_str &pair = pp_pairs_out_tab(i_pair_out);

      const unsigned int p  = pair.get_left ();
      const unsigned int pp = pair.get_right ();

      const unsigned int bp = bp_pp_table(p , pp);

      const int im = im_pp_table(p , pp);

      pp_pairs_out_indices(p , pp) = dimensions_pp_pairs_out(bp , im)++;
    }

  unsigned int pp_sum_dimensions_bef = 0 , pp_dimension_bef = 0;

  pp_sum_dimensions.allocate (2 , im_pp_max_plus_one);

  for (unsigned int bp = 0 ; bp <= 1 ; bp++)
    for (int im = 0 ; im <= im_pp_max ; im++)
      {
	const unsigned int pp_dimension = dimensions_pp_pairs_in(bp , im)*dimensions_pp_pairs_out(bp , im);
	
	pp_sum_dimensions(bp , im) = pp_sum_dimensions_bef + pp_dimension_bef;

	dimension_List_pp += pp_dimension;

	pp_dimension_bef = pp_dimension;

	pp_sum_dimensions_bef = pp_sum_dimensions(bp , im);
      }
}



void uncoupled_TBMEs_class::nn_constructor_part (
						 const unsigned int Nn_nljm ,
						 const class array<class pair_str> &nn_pairs_in_tab , 
						 const class array<class pair_str> &nn_pairs_out_tab , 
						 const class array<class nljm_struct> &phi_n_table)
{ 
  bp_nn_table.allocate (Nn_nljm , Nn_nljm);
  im_nn_table.allocate (Nn_nljm , Nn_nljm);

  int im_nn_max = 0;

  for (unsigned int n = 0 ; n < Nn_nljm ; n++)
    for (unsigned int nn = 0 ; nn < Nn_nljm ; nn++)
      {
	const class pair_str pair(n , nn);

	const unsigned int bp = pair.bp_determine (phi_n_table , phi_n_table);

	const int im = pair.im_determine (phi_n_table , phi_n_table);
		
	bp_nn_table(n , nn) = bp;
	im_nn_table(n , nn) = im;

	im_nn_max = max (im_nn_max , im);
      }

  const int im_nn_max_plus_one = im_nn_max + 1;

  dimensions_nn_pairs_in.allocate  (2 , im_nn_max_plus_one);  
  dimensions_nn_pairs_out.allocate (2 , im_nn_max_plus_one);

  dimensions_nn_pairs_in  = 0;
  dimensions_nn_pairs_out = 0;

  nn_pairs_in_indices.allocate  (Nn_nljm , Nn_nljm);
  nn_pairs_out_indices.allocate (Nn_nljm , Nn_nljm);

  nn_pairs_in_indices  = INFINITE_PAIR_INDEX ;
  nn_pairs_out_indices = INFINITE_PAIR_INDEX;
  
  const unsigned int dimension_nn_pairs_in = nn_pairs_in_tab.dimension (0);
  const unsigned int dimension_nn_pairs_out = nn_pairs_out_tab.dimension (0);
      
  for (unsigned int i_pair_in = 0 ; i_pair_in < dimension_nn_pairs_in ; i_pair_in++)
    {
      const class pair_str &pair = nn_pairs_in_tab(i_pair_in);

      const unsigned int n  = pair.get_left ();
      const unsigned int nn = pair.get_right ();

      const unsigned int bp = pair.bp_determine (phi_n_table , phi_n_table);

      const int im = pair.im_determine (phi_n_table , phi_n_table);
  
      nn_pairs_in_indices(n , nn) = dimensions_nn_pairs_in(bp , im)++;      
    }  

  for (unsigned int i_pair_out = 0 ; i_pair_out < dimension_nn_pairs_out ; i_pair_out++)
    {
      const class pair_str &pair = nn_pairs_out_tab(i_pair_out);
      
      const unsigned int n  = pair.get_left ();
      const unsigned int nn = pair.get_right ();

      const unsigned int bp = pair.bp_determine (phi_n_table , phi_n_table);

      const int im = pair.im_determine (phi_n_table , phi_n_table);
            
      nn_pairs_out_indices(n , nn) = dimensions_nn_pairs_out(bp , im)++;
    }
      
  unsigned int nn_sum_dimensions_bef = 0 , nn_dimension_bef = 0;

  nn_sum_dimensions.allocate (2 , im_nn_max_plus_one);
      
  for (unsigned int bp = 0 ; bp <= 1 ; bp++)
    for (int im = 0 ; im <= im_nn_max ; im++)
      {
	const unsigned int nn_dimension = dimensions_nn_pairs_in(bp , im)*dimensions_nn_pairs_out(bp , im);

	nn_sum_dimensions(bp , im) = nn_sum_dimensions_bef + nn_dimension_bef;

	dimension_List_nn += nn_dimension;

	nn_dimension_bef = nn_dimension;

	nn_sum_dimensions_bef = nn_sum_dimensions(bp , im);
      }
}



void uncoupled_TBMEs_class::pn_constructor_part (
						 const unsigned int Np_nljm ,
						 const unsigned int Nn_nljm ,
						 const class array<class pair_str> &pn_pairs_in_tab , 
						 const class array<class pair_str> &pn_pairs_out_tab , 
						 const class array<class nljm_struct> &phi_p_table , 
						 const class array<class nljm_struct> &phi_n_table)
{
  bp_pn_table.allocate (Np_nljm , Nn_nljm);
  im_pn_table.allocate (Np_nljm , Nn_nljm);

  int im_pn_max = 0;

  for (unsigned int p = 0 ; p < Np_nljm ; p++)
    for (unsigned int n = 0 ; n < Nn_nljm ; n++)
      {
	const class pair_str pair(p , n);

	const unsigned int bp = pair.bp_determine (phi_p_table , phi_n_table);
	
	const int im = pair.im_determine (phi_p_table , phi_n_table);

	bp_pn_table(p , n) = bp;
	im_pn_table(p , n) = im;

	im_pn_max = max (im_pn_max , im);
      }

  const int im_pn_max_plus_one = im_pn_max + 1;

  dimensions_pn_pairs_in.allocate  (2 , im_pn_max_plus_one);
  dimensions_pn_pairs_out.allocate (2 , im_pn_max_plus_one);

  dimensions_pn_pairs_in  = 0;
  dimensions_pn_pairs_out = 0;
  
  pn_pairs_in_indices.allocate  (Np_nljm , Nn_nljm);
  pn_pairs_out_indices.allocate (Np_nljm , Nn_nljm);

  pn_pairs_in_indices  = INFINITE_PAIR_INDEX;
  pn_pairs_out_indices = INFINITE_PAIR_INDEX;

  const unsigned int dimension_pn_pairs_in = pn_pairs_in_tab.dimension (0);
  const unsigned int dimension_pn_pairs_out = pn_pairs_out_tab.dimension (0);

  for (unsigned int i_pair_in = 0 ; i_pair_in < dimension_pn_pairs_in ; i_pair_in++)
    {
      const class pair_str &pair = pn_pairs_in_tab(i_pair_in);

      const unsigned int p = pair.get_left ();
      const unsigned int n = pair.get_right ();

      const unsigned int bp = bp_pn_table(p , n);

      const int im = im_pn_table(p , n);

      pn_pairs_in_indices(p , n) = dimensions_pn_pairs_in(bp , im)++;
    }
  
  for (unsigned int i_pair_out = 0 ; i_pair_out < dimension_pn_pairs_out ; i_pair_out++)
    {
      const class pair_str &pair = pn_pairs_out_tab(i_pair_out);

      const unsigned int p = pair.get_left ();
      const unsigned int n = pair.get_right ();

      const unsigned int bp = bp_pn_table(p , n);

      const int im = im_pn_table(p , n);

      pn_pairs_out_indices(p , n) = dimensions_pn_pairs_out(bp , im)++;
    }

  unsigned int pn_sum_dimensions_bef = 0;

  unsigned int pn_dimension_bef = 0;

  pn_sum_dimensions.allocate (2 , im_pn_max_plus_one);

  for (unsigned int bp = 0 ; bp <= 1 ; bp++)
    for (int im = 0 ; im <= im_pn_max ; im++)
      {
	const unsigned int pn_dimension = dimensions_pn_pairs_in(bp , im)*dimensions_pn_pairs_out(bp , im);

	pn_sum_dimensions(bp , im) = pn_sum_dimensions_bef + pn_dimension_bef;

	dimension_List_pn += pn_dimension;

	pn_dimension_bef = pn_dimension;

	pn_sum_dimensions_bef = pn_sum_dimensions(bp , im);
      }
}




void uncoupled_TBMEs_class::allocate_fill (const class uncoupled_TBMEs_class &X)
{
  zero_TBME = X.zero_TBME;
  
  is_it_pp_nn = X.is_it_pp_nn;
  
  dimension_List_pp = X.dimension_List_pp;
  dimension_List_nn = X.dimension_List_nn;
  dimension_List_pn = X.dimension_List_pn;
  
  dimension_List_pp_nn = X.dimension_List_pp_nn;
  
  dimension_List = X.dimension_List;
    
  dimensions_pp_pairs_in.allocate_fill (X.dimensions_pp_pairs_in);
  dimensions_nn_pairs_in.allocate_fill (X.dimensions_nn_pairs_in);
  dimensions_pn_pairs_in.allocate_fill (X.dimensions_pn_pairs_in);
  
  dimensions_pp_pairs_out.allocate_fill (X.dimensions_pp_pairs_out);
  dimensions_nn_pairs_out.allocate_fill (X.dimensions_nn_pairs_out);
  dimensions_pn_pairs_out.allocate_fill (X.dimensions_pn_pairs_out);

  pp_sum_dimensions.allocate_fill (X.pp_sum_dimensions);
  nn_sum_dimensions.allocate_fill (X.nn_sum_dimensions);
  pn_sum_dimensions.allocate_fill (X.pn_sum_dimensions);

  dimensions_pairs_in.allocate_fill (X.dimensions_pairs_in);
  
  dimensions_pairs_out.allocate_fill (X.dimensions_pairs_out);

  sum_dimensions.allocate_fill (X.sum_dimensions);

  bp_pp_table.allocate_fill (X.bp_pp_table);
  bp_nn_table.allocate_fill (X.bp_nn_table);
  bp_pn_table.allocate_fill (X.bp_pn_table);
  
  im_pp_table.allocate_fill (X.im_pp_table);
  im_nn_table.allocate_fill (X.im_nn_table);
  im_pn_table.allocate_fill (X.im_pn_table);
  
  pp_pairs_in_indices.allocate_fill (X.pp_pairs_in_indices);
  nn_pairs_in_indices.allocate_fill (X.nn_pairs_in_indices);
  pn_pairs_in_indices.allocate_fill (X.pn_pairs_in_indices);
  
  pp_pairs_out_indices.allocate_fill (X.pp_pairs_out_indices);
  nn_pairs_out_indices.allocate_fill (X.nn_pairs_out_indices);
  pn_pairs_out_indices.allocate_fill (X.pn_pairs_out_indices);

  bp_table.allocate_fill (X.bp_table);

  im_table.allocate_fill (X.im_table);
  
  pairs_in_indices.allocate_fill (X.pairs_in_indices);

  pairs_out_indices.allocate_fill (X.pairs_out_indices);	

  List = (dimension_List > 0) ? (new TYPE [dimension_List]) : (NULL);

  for (unsigned int i = 0 ; i < dimension_List ; i++) List[i] = X.List[i]; 
}











void uncoupled_TBMEs_class::deallocate ()
{
  dimensions_pp_pairs_in.deallocate ();
  dimensions_nn_pairs_in.deallocate ();
  dimensions_pn_pairs_in.deallocate ();
  
  dimensions_pp_pairs_out.deallocate ();
  dimensions_nn_pairs_out.deallocate ();
  dimensions_pn_pairs_out.deallocate ();
  
  pp_sum_dimensions.deallocate ();
  nn_sum_dimensions.deallocate ();
  pn_sum_dimensions.deallocate ();

  dimensions_pairs_in.deallocate ();
  
  dimensions_pairs_out.deallocate ();
  
  sum_dimensions.deallocate ();

  bp_pp_table.deallocate ();
  bp_nn_table.deallocate ();
  bp_pn_table.deallocate ();
  
  im_pp_table.deallocate ();
  im_nn_table.deallocate ();
  im_pn_table.deallocate ();
  
  pp_pairs_in_indices.deallocate ();
  nn_pairs_in_indices.deallocate ();
  pn_pairs_in_indices.deallocate ();
  
  pp_pairs_out_indices.deallocate ();
  nn_pairs_out_indices.deallocate ();
  pn_pairs_out_indices.deallocate ();

  bp_table.deallocate ();
  
  im_table.deallocate ();
  
  pairs_in_indices.deallocate ();

  pairs_out_indices.deallocate ();

  dimension_List_pp = 0;
  dimension_List_nn = 0;
  dimension_List_pn = 0;
  
  dimension_List_pp_nn = 0;
  
  dimension_List = 0;
    
  delete [] List;

  List = NULL;
  
  zero_TBME = 0.0;
}








unsigned int uncoupled_TBMEs_class::pp_index_determine (
							const unsigned int p_in ,
							const unsigned int pp_in , 
							const unsigned int p_out ,
							const unsigned int pp_out) const
{
  const unsigned int pp_pair_index_in = pp_pairs_in_indices(p_in , pp_in);

  const unsigned int p_pp_out_index = pp_pairs_out_indices.index_determine (p_out , pp_out);
  
  const unsigned int pp_pair_index_out = pp_pairs_out_indices[p_pp_out_index];
    
  const unsigned int bp = bp_pp_table[p_pp_out_index];

  const int im = im_pp_table[p_pp_out_index];

  const unsigned int bp_im_index = dimensions_pp_pairs_out.index_determine (bp , im);
  
  const unsigned int dimension_pp_pairs_out_bp_im = dimensions_pp_pairs_out[bp_im_index];

  const unsigned int pp_sum_dimensions_bp_im = pp_sum_dimensions[bp_im_index];
  
  const unsigned int index = pp_pair_index_out + dimension_pp_pairs_out_bp_im*pp_pair_index_in + pp_sum_dimensions_bp_im;

  return index;
}



unsigned int uncoupled_TBMEs_class::nn_index_determine (
							const unsigned int n_in ,
							const unsigned int nn_in , 
							const unsigned int n_out ,
							const unsigned int nn_out) const
{
  const unsigned int nn_pair_index_in = nn_pairs_in_indices(n_in , nn_in);
  
  const unsigned int n_nn_out_index = nn_pairs_out_indices.index_determine (n_out , nn_out);
  
  const unsigned int nn_pair_index_out = nn_pairs_out_indices[n_nn_out_index];
    
  const unsigned int bp = bp_nn_table[n_nn_out_index];
  
  const int im = im_nn_table[n_nn_out_index];
  
  const unsigned int bp_im_index = dimensions_nn_pairs_out.index_determine (bp , im);
  
  const unsigned int dimension_nn_pairs_out_bp_im = dimensions_nn_pairs_out[bp_im_index];

  const unsigned int nn_sum_dimensions_bp_im = nn_sum_dimensions[bp_im_index];
  
  const unsigned int index = nn_pair_index_out + dimension_nn_pairs_out_bp_im*nn_pair_index_in + nn_sum_dimensions_bp_im;

  return index;
}



unsigned int uncoupled_TBMEs_class::pn_index_determine (
							const unsigned int p_in ,
							const unsigned int n_in , 
							const unsigned int p_out ,
							const unsigned int n_out) const
{
  const unsigned int pn_pair_index_in = pn_pairs_in_indices(p_in , n_in);

  const unsigned int pn_out_index = pn_pairs_out_indices.index_determine (p_out , n_out);
  
  const unsigned int pn_pair_index_out = pn_pairs_out_indices[pn_out_index];
    
  const unsigned int bp = bp_pn_table[pn_out_index];

  const int im = im_pn_table[pn_out_index];
  
  const unsigned int bp_im_index = dimensions_pn_pairs_out.index_determine (bp , im);
  
  const unsigned int dimension_pn_pairs_out_bp_im = dimensions_pn_pairs_out[bp_im_index];

  const unsigned int pn_sum_dimensions_bp_im = pn_sum_dimensions[bp_im_index];
  
  const unsigned int index = pn_pair_index_out + dimension_pn_pairs_out_bp_im*pn_pair_index_in + pn_sum_dimensions_bp_im;

  return index;
}



unsigned int uncoupled_TBMEs_class::index_determine_pp_nn (
							   const unsigned int mu_in ,
							   const unsigned int mu_p_in , 
							   const unsigned int mu_out ,
							   const unsigned int mu_p_out) const
{
  const unsigned int pair_index_in = pairs_in_indices(mu_in , mu_p_in);

  const unsigned int mu_mu_p_out_index = pairs_out_indices.index_determine (mu_out , mu_p_out);
  
  const unsigned int pair_index_out = pairs_out_indices[mu_mu_p_out_index];
    
  const unsigned int bp = bp_table[mu_mu_p_out_index];
  
  const int im = im_table[mu_mu_p_out_index];
  
  const unsigned int bp_im_index = dimensions_pairs_out.index_determine (bp , im);
  
  const unsigned int dimension_pairs_out_bp_im = dimensions_pairs_out[bp_im_index];

  const unsigned int sum_dimensions_bp_im = sum_dimensions[bp_im_index];
  
  const unsigned int index = pair_index_out + dimension_pairs_out_bp_im*pair_index_in + sum_dimensions_bp_im;

  return index;
}



unsigned int uncoupled_TBMEs_class::index_determine (
						     const enum space_type TBME_space ,
						     const unsigned int left_in , 
						     const unsigned int right_in ,
						     const unsigned int left_out ,
						     const unsigned int right_out) const
{  
  switch (TBME_space)
    {
    case PROTONS_ONLY:
      {
	const unsigned int index = (is_it_pp_nn) ? (index_determine_pp_nn (left_in , right_in , left_out , right_out)) : (pp_index_determine (left_in , right_in , left_out , right_out));

	return index;
      }

    case NEUTRONS_ONLY:
      {
	const unsigned int index = (is_it_pp_nn) ? (index_determine_pp_nn (left_in , right_in , left_out , right_out)) : (nn_index_determine (left_in , right_in , left_out , right_out));

	return index;
      }

    case PROTONS_NEUTRONS:
      {
	const unsigned int index = pn_index_determine (left_in , right_in , left_out , right_out);

	return index;
      }  

    default:
      {
	abort_all ();

	return NADA;
      }  
    }
}



double used_memory_calc (const class uncoupled_TBMEs_class &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = T.dimension_List*sizeof (TYPE)/1000000.0 + used_memory_calc (T.dimensions_pp_pairs_in) + used_memory_calc (T.dimensions_pp_pairs_out) + used_memory_calc (T.pp_sum_dimensions) + used_memory_calc (T.dimensions_nn_pairs_in) + used_memory_calc (T.dimensions_nn_pairs_out) + used_memory_calc (T.nn_sum_dimensions) + used_memory_calc (T.dimensions_pn_pairs_in) + used_memory_calc (T.dimensions_pn_pairs_out) + used_memory_calc (T.pn_sum_dimensions) + used_memory_calc (T.dimensions_pairs_in) + used_memory_calc (T.dimensions_pairs_out) + used_memory_calc (T.sum_dimensions) + used_memory_calc (T.bp_pp_table) + used_memory_calc (T.bp_nn_table) + used_memory_calc (T.bp_pn_table) + used_memory_calc (T.bp_table) + used_memory_calc (T.im_pp_table) + used_memory_calc (T.im_nn_table) + used_memory_calc (T.im_pn_table) + used_memory_calc (T.im_table) + used_memory_calc (T.pp_pairs_in_indices) + used_memory_calc (T.pp_pairs_out_indices) + used_memory_calc (T.nn_pairs_in_indices) + used_memory_calc (T.nn_pairs_out_indices) + used_memory_calc (T.pn_pairs_in_indices) + used_memory_calc (T.pn_pairs_out_indices) + used_memory_calc (T.pairs_in_indices) + used_memory_calc (T.pairs_out_indices) - (sizeof (T.dimensions_pp_pairs_in) + sizeof (T.dimensions_pp_pairs_out) + sizeof (T.pp_sum_dimensions) + sizeof (T.dimensions_nn_pairs_in) + sizeof (T.dimensions_nn_pairs_out) + sizeof (T.nn_sum_dimensions) + sizeof (T.dimensions_pn_pairs_in) + sizeof (T.dimensions_pn_pairs_out) + sizeof (T.pn_sum_dimensions) + sizeof (T.dimensions_pairs_in) + sizeof (T.dimensions_pairs_out) + sizeof (T.sum_dimensions) + sizeof (T.bp_pp_table) + sizeof (T.bp_nn_table) + sizeof (T.bp_pn_table) + sizeof (T.bp_table) + sizeof (T.im_pp_table) + sizeof (T.im_nn_table) + sizeof (T.im_pn_table) + sizeof (T.im_table) + sizeof (T.pp_pairs_in_indices) + sizeof (T.pp_pairs_out_indices) + sizeof (T.nn_pairs_in_indices) + sizeof (T.nn_pairs_out_indices) + sizeof (T.pn_pairs_in_indices) + sizeof (T.pn_pairs_out_indices) + sizeof (T.pairs_in_indices) + sizeof (T.pairs_out_indices))/1000000.0;
  
  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;
}
