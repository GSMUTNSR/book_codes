#include "../GSM_include/GSM_include_def.h"


using namespace string_routines;
using namespace Wigner_signs;
using namespace inputs_misc;
using namespace eigenvector_functions;
using namespace configuration_SD_in_space_one_jump_out_to_in;

// TYPE is double or complex
// -------------------------

// CM means center of mass
// -----------------------


// One has to suppress OpenMP and MPI parallelization inside distributed loops to avoid race conditions, as operators inside distributed loops would be parallelized as well.
// This is done critically to avoid a race condition.



// GSM vectors are typically read and copied to disk independently by all cores. full_common_vectors_used_in_file is then put to false in read_disk/copy_disk routines (see GSM_vector.cpp).






// Allocations of CM operators and GSM vector classes used in this namespace for the calculation of |NCM-HO LCM M_LCM intrinsic M[intrinsic]> states
// -------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates HO many-body states of the form |NCM-HO LCM M_LCM intrinsic M[intrinsic]> in Nhw spaces, given with a basis of HO Slater determinants.
// M[intrinsic] is fixed here and |NCM-HO LCM M_LCM intrinsic M[intrinsic]> is then not fully coupled. 
//
// Routines of this namespace are used in conjunction with GSM-CC, where targets/projectiles in composites have the form |NCM-HO LCM intrinsic>^JM when constructing the GSM-CC Hamiltonian.
// |NCM-HO LCM intrinsic>^JM is calculated from not fully coupled |NCM-HO LCM M_LCM intrinsic M[intrinsic]> states.
// |NCM-HO LCM M_LCM intrinsic M[intrinsic]> is the many-body state of a cluster of a given intrinsic part, and whose CM part is that of a HO CM state. 
// It will be calculated from |NCM-HO=0 LCM=0 M_LCM=0 intrinsic> provided from a HO shell model calculation using the Lawson method.
// For this, one uses A+_mu[CM-HO] operators to go from |NCM-HO LCM M_LCM intrinsic M[intrinsic]> to |NCM-HO' LCM' intrinsic M[intrinsic]>, where 2 NCM-HO' + LCM' = 2 NCM-HO + LCM + 1.
// A+_mu[CM-HO] has a rank projection mu equal to -1,0,1, so that they transform HO many-body vectors of total angular momentum projection M to that with M-1, M or M+1.
//
// Classes providing with A+_mu[CM-HO], GSM vector classes for HO many-body vectors storing |NCM-HO LCM M_LCM intrinsic M[intrinsic]> and helper classes (see GSM_vector_helper_class.cpp) are allocated and initialized here.
// One considers all LCM <= LCM_max_all, M_LCM >= 0 possible values for HO many-body vectors, and all Pi[CM] = +/-1 and M_LCM >= 0 possible values for operators (operators are only dependent on M and parity).
// No calculation is done otherwise.



void cluster_CM_intrinsic_basis_states::PSI_HO_A_dagger_CM_HO_LCM_M_LCM_tabs_alloc (
										    const class input_data_str &input_data , 
										    const double M_intrinsic , 
										    class cluster_data &data , 
										    class array<class GSM_vector_helper_class> &GSM_vector_helper_M_E_CM_HO_tab , 
										    class array<class GSM_vector_helper_class> &GSM_vector_helper_M_E_CM_HO_m1_tab , 
										    class array<class GSM_vector> &GSM_vector_M_E_CM_HO_m1_tab , 
										    class array<class CM_operator_class> &A_dagger_CM_HO_minus_tab , 
										    class array<class CM_operator_class> &A_dagger_CM_HO_zero_tab , 
										    class array<class CM_operator_class> &A_dagger_CM_HO_plus_tab , 
										    class array<class GSM_vector> &PSI_HO_LCM_M_LCM_tab)
{
  const enum interaction_type inter = input_data.get_inter ();

  class nucleons_data &cluster_prot_data_HO = data.get_cluster_prot_data_HO ();
  class nucleons_data &cluster_neut_data_HO = data.get_cluster_neut_data_HO ();

  const unsigned int BP_intrinsic = data.get_BP_intrinsic ();

  const int E_relative_max_hw = input_data.get_E_relative_max_hw ();
  
  const int E_min_hw_HO = cluster_prot_data_HO.get_E_min_hw () + cluster_neut_data_HO.get_E_min_hw ();

  const int Z_cluster = cluster_prot_data_HO.get_N_nucleons ();
  const int N_cluster = cluster_neut_data_HO.get_N_nucleons ();

  const enum space_type space = space_determine (Z_cluster , N_cluster);

  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();

  const int n_holes_max_p_HO = cluster_prot_data_HO.get_n_holes_max ();
  const int n_holes_max_n_HO = cluster_neut_data_HO.get_n_holes_max ();

  const int n_holes_max_HO = n_holes_max_p_HO + n_holes_max_n_HO;
  
  const int n_scat_max_p_HO = cluster_prot_data_HO.get_n_scat_max ();
  const int n_scat_max_n_HO = cluster_neut_data_HO.get_n_scat_max ();

  const int n_scat_max_HO = n_scat_max_p_HO + n_scat_max_n_HO;
    
  const int Ep_max_hw_HO = cluster_prot_data_HO.get_E_max_hw ();
  const int En_max_hw_HO = cluster_neut_data_HO.get_E_max_hw ();
  
  const int E_max_hw_HO = E_relative_max_hw + E_min_hw_HO;

  const int LCM_max_all = PSI_HO_LCM_M_LCM_tab.dimension (0) - 1;

  const int M_LCM_max_all_number = 2*LCM_max_all + 1;

  const int M_LCM_max_all_number_minus_one = M_LCM_max_all_number - 1;
    
  // Parallelization has to be suppressed in order to be able to use operators independently from each other in different nodes.
  
  for (int BP_CM = 0 ; BP_CM <= 1 ; BP_CM++)
    {
      const unsigned int BP_cluster = binary_parity_product (BP_CM , BP_intrinsic);

      const unsigned int BP_opp_cluster = opposite_binary_parity (BP_cluster);

      for (int iM_LCM_max_all = 0 ; iM_LCM_max_all < M_LCM_max_all_number ; iM_LCM_max_all++)
	{
	  const int M_LCM = iM_LCM_max_all - LCM_max_all;
	  
	  const double M_cluster = M_LCM + M_intrinsic;

	  class GSM_vector_helper_class &GSM_vector_helper_M_E_CM_HO    = GSM_vector_helper_M_E_CM_HO_tab   (BP_CM , iM_LCM_max_all);
	  class GSM_vector_helper_class &GSM_vector_helper_M_E_CM_HO_m1 = GSM_vector_helper_M_E_CM_HO_m1_tab(BP_CM , iM_LCM_max_all);
	  
	  class GSM_vector &GSM_vector_M_E_CM_HO_m1 = GSM_vector_M_E_CM_HO_m1_tab(BP_CM , iM_LCM_max_all);
	  
	  GSM_vector_helper_M_E_CM_HO.allocate (false , space , inter , false , truncation_hw , truncation_ph ,
						n_holes_max_HO   , n_scat_max_HO   , E_max_hw_HO  ,
						n_holes_max_p_HO , n_scat_max_p_HO , Ep_max_hw_HO ,
						n_holes_max_n_HO , n_scat_max_n_HO , En_max_hw_HO , 
						BP_cluster , M_cluster , true , cluster_prot_data_HO , cluster_neut_data_HO);
	      
	  GSM_vector_helper_M_E_CM_HO_m1.allocate (false , space , inter , false , truncation_hw , truncation_ph , 
						   n_holes_max_HO   , n_scat_max_HO   , E_max_hw_HO  ,
						   n_holes_max_p_HO , n_scat_max_p_HO , Ep_max_hw_HO ,
						   n_holes_max_n_HO , n_scat_max_n_HO , En_max_hw_HO ,  
						   BP_opp_cluster , M_cluster , true , cluster_prot_data_HO , cluster_neut_data_HO);
	  
	  GSM_vector_M_E_CM_HO_m1.allocate (GSM_vector_helper_M_E_CM_HO_m1);
	  GSM_vector_M_E_CM_HO_m1 = 0.0;
	}
      
      for (int iM_LCM_max_all = 0 ; iM_LCM_max_all < M_LCM_max_all_number ; iM_LCM_max_all++)
	{
	  class GSM_vector_helper_class &GSM_vector_helper_M_E_CM_HO    = GSM_vector_helper_M_E_CM_HO_tab   (BP_CM , iM_LCM_max_all);
	  class GSM_vector_helper_class &GSM_vector_helper_M_E_CM_HO_m1 = GSM_vector_helper_M_E_CM_HO_m1_tab(BP_CM , iM_LCM_max_all);

	  class CM_operator_class &A_dagger_CM_HO_zero  = A_dagger_CM_HO_zero_tab (BP_CM , iM_LCM_max_all);
	  class CM_operator_class &A_dagger_CM_HO_minus = A_dagger_CM_HO_minus_tab(BP_CM , iM_LCM_max_all);
	  class CM_operator_class &A_dagger_CM_HO_plus  = A_dagger_CM_HO_plus_tab (BP_CM , iM_LCM_max_all);
	  
	  class GSM_vector &GSM_vector_M_E_CM_HO_m1 = GSM_vector_M_E_CM_HO_m1_tab(BP_CM , iM_LCM_max_all);	

	  A_dagger_CM_HO_zero.allocate (A_DAGGER_CM_HO_ZERO , false , NADA , true , GSM_vector_helper_M_E_CM_HO_m1 , GSM_vector_helper_M_E_CM_HO , GSM_vector_M_E_CM_HO_m1);
	      
	  if (iM_LCM_max_all >= 1)
	    {
	      const int iM_LCM_max_all_minus_one = iM_LCM_max_all - 1;
	      
	      class GSM_vector_helper_class &GSM_vector_helper_Mm1_E_CM_HO_m1 = GSM_vector_helper_M_E_CM_HO_m1_tab(BP_CM , iM_LCM_max_all_minus_one);
	      
	      class GSM_vector &GSM_vector_Mm1_E_CM_HO_m1 = GSM_vector_M_E_CM_HO_m1_tab(BP_CM , iM_LCM_max_all_minus_one);
	  
	      A_dagger_CM_HO_plus.allocate (A_DAGGER_CM_HO_PLUS_ONE , false , NADA , true , GSM_vector_helper_Mm1_E_CM_HO_m1 , GSM_vector_helper_M_E_CM_HO , GSM_vector_Mm1_E_CM_HO_m1);
	    }
	  
	  if (iM_LCM_max_all < M_LCM_max_all_number_minus_one)
	    {
	      const int iM_LCM_max_all_plus_one = iM_LCM_max_all + 1;
	      
	      class GSM_vector_helper_class &GSM_vector_helper_Mp1_E_CM_HO_m1 = GSM_vector_helper_M_E_CM_HO_m1_tab(BP_CM , iM_LCM_max_all_plus_one);
	      
	      class GSM_vector &GSM_vector_Mp1_E_CM_HO_m1 = GSM_vector_M_E_CM_HO_m1_tab(BP_CM , iM_LCM_max_all_plus_one);
	  
	      A_dagger_CM_HO_minus.allocate (A_DAGGER_CM_HO_MINUS_ONE , false , NADA , true , GSM_vector_helper_Mp1_E_CM_HO_m1 , GSM_vector_helper_M_E_CM_HO , GSM_vector_Mp1_E_CM_HO_m1);
	    }
	}
    }
  
  for (int LCM = 0 ; LCM <= LCM_max_all ; LCM++)
    {
      const unsigned int BP_CM = binary_parity_from_orbital_angular_momentum (LCM);

      const int M_LCM_number = 2*LCM + 1;

      for (int iM_LCM = 0 ; iM_LCM < M_LCM_number ; iM_LCM++)
	{	  
	  const int M_LCM = iM_LCM - LCM;

	  const int iM_LCM_max_all = M_LCM + LCM_max_all;
	  
	  class GSM_vector_helper_class &GSM_vector_helper_M_E_CM_HO = GSM_vector_helper_M_E_CM_HO_tab(BP_CM , iM_LCM_max_all);

	  class GSM_vector &PSI_HO_LCM_M_LCM_E_CM_HO = PSI_HO_LCM_M_LCM_tab(LCM , iM_LCM);
	  
	  PSI_HO_LCM_M_LCM_E_CM_HO.allocate (GSM_vector_helper_M_E_CM_HO);
	  PSI_HO_LCM_M_LCM_E_CM_HO = 0.0;
	}
    }
}






// Storage of |NCM-HO=0 LCM=0 M_LCM=0 intrinsic M[intrinsic]> for a fixed value of M[intrinsic]
// --------------------------------------------------------------------------------------------
// The HO many-body state |NCM-HO=0 LCM=0 M_LCM=0 intrinsic M[intrinsic] has been calculated with the Lawson method and stored on disk.
// It is read from disk, where it was considered as a shell model eigenstate, stored in an array,
// and stored in a file bearing another name, so that it can be read in routines looping on CM quantum numbers.

void cluster_CM_intrinsic_basis_states::PSI_HO_CM_0s_M_intrinsic_store (
									const class input_data_str &input_data , 
									const int iM_intrinsic , 
									class cluster_data &data , 
									class array<class GSM_vector> &PSI_HO_LCM_M_LCM_tab)
{
  const enum particle_type cluster = data.get_cluster ();

  const unsigned int BP_intrinsic = data.get_BP_intrinsic ();
  
  const double J_intrinsic = data.get_J_intrinsic ();

  const unsigned int vector_index_intrinsic = data.get_vector_index_intrinsic ();

  const int Z_cluster = data.get_Z_cluster ();
  const int N_cluster = data.get_N_cluster ();
  const int A_cluster = data.get_A_cluster ();

  const class correlated_state_str PSI_HO_CM_0s_J_intrinsic_qn(Z_cluster , N_cluster , BP_intrinsic , J_intrinsic , vector_index_intrinsic , NADA , NADA , NADA , NADA , false);
  
  class GSM_vector &PSI_HO_0s = PSI_HO_LCM_M_LCM_tab(0 , 0);

  PSI_HO_0s.SDs_components_eigenvector_read_disk (true , true , PSI_HO_CM_0s_J_intrinsic_qn);
  
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      const double M_intrinsic_min = (A_cluster%2 == 0) ? (0.0) : (0.5);

      const double M_intrinsic = M_intrinsic_min + iM_intrinsic;

      const int two_M_intrinsic = make_int (2.0*M_intrinsic);
      
      const string PSI_HO_dimension_string = file_name_intrinsic_CM_cluster_string ("HO_basis_state_dimension" , cluster , 0 , 0 , J_intrinsic , M_intrinsic);
      const string PSI_HO_string           = file_name_intrinsic_CM_cluster_string ("HO_basis_state"           , cluster , 0 , 0 , J_intrinsic , M_intrinsic);
  
      // This is for the case where the Berggren basis states are used in the following, even though they are equal to HO basis states.
      const string PSI_Berggren_dimension_string = file_name_intrinsic_CM_cluster_string ("Berggren_basis_state_dimension" , cluster , 0 , 0 , J_intrinsic , M_intrinsic);
      const string PSI_Berggren_string           = file_name_intrinsic_CM_cluster_string ("Berggren_basis_state"           , cluster , 0 , 0 , J_intrinsic , M_intrinsic);
      
      PSI_HO_0s.space_dimension_SDs_components_copy_disk (false , false , PSI_HO_dimension_string , PSI_HO_string);
      
      PSI_HO_0s.space_dimension_SDs_components_copy_disk (false , false , PSI_Berggren_dimension_string , PSI_Berggren_string);
      
      // This is for the case where the Berggren basis states are used in the following, even though they are equal to HO basis states.
      if (two_M_intrinsic != 0)
	{
	  const enum interaction_type inter = input_data.get_inter ();

	  class nucleons_data &cluster_prot_data_HO = data.get_cluster_prot_data_HO ();
	  class nucleons_data &cluster_neut_data_HO = data.get_cluster_neut_data_HO ();

	  const int E_relative_max_hw = input_data.get_E_relative_max_hw ();

	  const int E_min_hw_HO = cluster_prot_data_HO.get_E_min_hw () + cluster_neut_data_HO.get_E_min_hw ();

	  const enum space_type space = space_determine (Z_cluster , N_cluster);

	  const bool truncation_hw = input_data.get_truncation_hw ();
	  const bool truncation_ph = input_data.get_truncation_ph ();

	  const int n_holes_max_p_HO = cluster_prot_data_HO.get_n_holes_max ();
	  const int n_holes_max_n_HO = cluster_neut_data_HO.get_n_holes_max ();
 
	  const int n_holes_max_HO = n_holes_max_p_HO + n_holes_max_n_HO;
  
	  const int n_scat_max_p_HO = cluster_prot_data_HO.get_n_scat_max ();
	  const int n_scat_max_n_HO = cluster_neut_data_HO.get_n_scat_max ();

	  const int n_scat_max_HO = n_scat_max_p_HO + n_scat_max_n_HO;
  
	  const int Ep_max_hw_HO = cluster_prot_data_HO.get_E_max_hw ();
	  const int En_max_hw_HO = cluster_neut_data_HO.get_E_max_hw ();
	  
	  const int E_max_hw_HO = E_relative_max_hw + E_min_hw_HO;

	  class GSM_vector_helper_class &PSI_HO_helper = PSI_HO_0s.get_GSM_vector_helper ();
	  
	  class GSM_vector_helper_class PSI_HO_TRS_helper(false , space , inter , false , truncation_hw , truncation_ph ,
							  n_holes_max_HO   , n_scat_max_HO   , E_max_hw_HO  ,
							  n_holes_max_p_HO , n_scat_max_p_HO , Ep_max_hw_HO ,
							  n_holes_max_n_HO , n_scat_max_n_HO , En_max_hw_HO , 
							  BP_intrinsic , -M_intrinsic , true , cluster_prot_data_HO , cluster_neut_data_HO);
	  
	  const class TRS_class TRS(PSI_HO_helper , PSI_HO_TRS_helper);
	  
	  const string PSI_Berggren_dimension_TRS_string = file_name_intrinsic_CM_cluster_string ("Berggren_basis_state_dimension" , cluster , 0 , 0 , J_intrinsic , -M_intrinsic);
	  const string PSI_Berggren_TRS_string           = file_name_intrinsic_CM_cluster_string ("Berggren_basis_state"           , cluster , 0 , 0 , J_intrinsic , -M_intrinsic);
	  	  
	  const class GSM_vector PSI_HO_0s_TRS = minus_one_pow (J_intrinsic - M_intrinsic)*TRS (PSI_HO_0s);
	  
	  PSI_HO_0s_TRS.space_dimension_SDs_components_copy_disk (false , false , PSI_Berggren_dimension_TRS_string , PSI_Berggren_TRS_string);	}
    }
}








// Calculation of |NCM-HO LCM M_LCM intrinsic M[intrinsic]> HO many-body vectors by repeated actions of A+_mu[CM-HO] operators on |NCM-HO=0 LCM=0 M_LCM intrinsic M[intrinsic]>
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// |NCM-HO LCM M_LCM intrinsic M[intrinsic]> has an HO energy of 2 NCM-HO + LCM. One has to have 2 NCM-HO + LCM >= 0, as the previous routine takes care of states with NCM-HO=0 and LCM=0.
// Hence, it is a linear combinations of all A+_mu[CM-HO]|NCM-HO' LCM' M_LCM' intrinsic M[intrinsic]> states, of HO energy 2 NCM-HO' + LCM' = 2 NCM-HO + LCM - 1.
// The rank projection of A+_mu[CM-HO], denoted as mu, is fixed from M_LCM' + mu = M_LCM. 
// By coupling LCM' and 1 (the rank of A+_mu[CM-HO]) with Clebsch-Gordan coefficients,
// one can sum obtained A+_mu[CM-HO]|NCM-HO' LCM' M_LCM' intrinsic M[intrinsic]> states so that the result is coupled to LCM:
// As there is only one state coupled to LCM bearing a fixed HO energy, it is has to be |NCM-HO LCM M_LCM intrinsic M[intrinsic]> up to normalization.
// 
// The formula is:
// |NCM-HO LCM M_LCM intrinsic M[intrinsic]> = \sum_{M_LCM' + mu = M_LCM} <1 mu LCM' M_LCM' | LCM M_LCM> A+_mu[CM-HO]|NCM-HO' LCM' M_LCM' intrinsic M[intrinsic]> up to normalization.
//
// One loops LCM from 0 to LCM_max = min (E_CM_HO , LCM_max_all). It poses no problem.
// Indeed, unless LCM=0, one always starts from A+_mu[CM-HO]|NCM-HO-1 LCM> to calculate |NCM-HO LCM>, 
// and if LCM=0, one starts from A+_mu[CM-HO]|NCM-HO-1 1> to calculate |NCM-HO 0>. NCM-HO >= 1 necessarily as E_CM_HO >= 1, and having LCM_max_all >= 1 is necessary in practice.
//
// OpenMP parallelization is done at the level of the M_LCM loop, as it is typically the loop with the most elements.
// It comes after the first loop in LCM, but they are in small number so that OpenMP distribution is not too long.
// MPI parallelization is done at the level of the M_LCM loop as well, where a node takes care of a part of M_LCM values, hence of a part of all |NCM-HO LCM M_LCM intrinsic M[intrinsic]> vectors.
// One has to cast |NCM-HO LCM M_LCM intrinsic M[intrinsic]> afterwards to all nodes from the process where it was calculated.

void cluster_CM_intrinsic_basis_states::PSI_HO_LCM_M_LCM_tab_all_LCM_E_CM_HO_fixed_calc (
											 const int E_CM_HO , 
											 const class array<class CM_operator_class> &A_dagger_CM_HO_minus_tab , 
											 const class array<class CM_operator_class> &A_dagger_CM_HO_zero_tab , 
											 const class array<class CM_operator_class> &A_dagger_CM_HO_plus_tab , 
											 class array<class GSM_vector> &PSI_HO_LCM_M_LCM_tab)
{	
  const int LCM_max_all = PSI_HO_LCM_M_LCM_tab.dimension (0) - 1;

  const int LCM_max = min (E_CM_HO , LCM_max_all);

  const unsigned int BP_CM = make_uns_int (E_CM_HO % 2);

  const int LCM_min = (BP_CM == 0) ? (0) : (1);

  const int LCM_number_max = LCM_max + 1;

  const int M_LCM_number_max = 2*LCM_max + 1;

  const unsigned int LCM_M_LCM_number = LCM_M_LCM_number_determine (LCM_min , LCM_max);

  class array<unsigned int> LCM_M_LCM_indices(LCM_number_max , M_LCM_number_max);

  LCM_M_LCM_indices = LCM_M_LCM_number;

  LCM_M_LCM_indices_determine (LCM_min , LCM_max , LCM_M_LCM_indices);

  // Parallelization has to be suppressed in order to use operators independently from each other in different nodes.

  const unsigned int first_index = basic_first_index_determine_for_MPI (LCM_M_LCM_number , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_index = basic_last_index_determine_for_MPI (LCM_M_LCM_number , NUMBER_OF_PROCESSES , THIS_PROCESS);
	
  for (int LCM = LCM_min ; LCM <= LCM_max ; LCM += 2)
    {
      const int LCM_E_CM_HO_m1 = (LCM == 0) ? (1) : (LCM - 1);

      const int M_LCM_number = 2*LCM + 1;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
      for (int iM_LCM = 0 ; iM_LCM < M_LCM_number ; iM_LCM++)
	{
	  const unsigned int index = LCM_M_LCM_indices(LCM , iM_LCM);
	  
	  if ((index >= first_index) && (index <= last_index))
	    {

#ifdef UseOpenMP
#pragma omp critical
#endif
	      {
		OpenMP_parallelization_disabled ();

		MPI_parallelization_disabled ();
	      }
	      
	      const int M_LCM = iM_LCM - LCM;

	      const int iM_LCM_max_all = M_LCM + LCM_max_all;
	  
	      const class CM_operator_class &A_dagger_CM_HO_minus = A_dagger_CM_HO_minus_tab(BP_CM , iM_LCM_max_all);
	      const class CM_operator_class &A_dagger_CM_HO_zero  = A_dagger_CM_HO_zero_tab (BP_CM , iM_LCM_max_all);
	      const class CM_operator_class &A_dagger_CM_HO_plus  = A_dagger_CM_HO_plus_tab (BP_CM , iM_LCM_max_all);

	      class GSM_vector &PSI_HO_LCM_M_LCM_E_CM_HO = PSI_HO_LCM_M_LCM_tab(LCM , iM_LCM);

	      PSI_HO_LCM_M_LCM_E_CM_HO = 0.0;
	  
	      for (int mu = -1 ; mu <= 1 ; mu++)
		{
		  const int M_LCM_E_CM_HO_m1 = M_LCM - mu;

		  if (abs (M_LCM_E_CM_HO_m1) > LCM_E_CM_HO_m1) continue;

		  const int iM_LCM_E_CM_HO_m1 = M_LCM_E_CM_HO_m1 + LCM_E_CM_HO_m1;

		  const class CM_operator_class &A_dagger_CM_HO_mu = A_dagger_CM_HO_component_determine (mu , A_dagger_CM_HO_minus , A_dagger_CM_HO_zero , A_dagger_CM_HO_plus);

		  const double CG = Clebsch_Gordan (1 , mu , LCM_E_CM_HO_m1 , M_LCM_E_CM_HO_m1 , LCM , M_LCM);

		  const class GSM_vector &PSI_HO_LCM_M_LCM_E_CM_HO_m1 = PSI_HO_LCM_M_LCM_tab(LCM_E_CM_HO_m1 , iM_LCM_E_CM_HO_m1);

		  PSI_HO_LCM_M_LCM_E_CM_HO += CG*(A_dagger_CM_HO_mu*PSI_HO_LCM_M_LCM_E_CM_HO_m1);
		}
		  
	      PSI_HO_LCM_M_LCM_E_CM_HO.normalization ();	      
	    }	  
	}

      OpenMP_parallelization_enabled ();

      MPI_parallelization_enabled ();
	  
#ifdef UseMPI
      MPI_helper::Barrier ();
      
      if (is_it_MPI_parallelized)
	{
	  for (int iM_LCM = 0 ; iM_LCM < M_LCM_number ; iM_LCM++)
	    {
	      const unsigned int index = LCM_M_LCM_indices(LCM , iM_LCM);

	      const unsigned int sending_process = basic_active_process_determine_for_MPI (LCM_M_LCM_number , NUMBER_OF_PROCESSES , index);

	      class GSM_vector &PSI_HO_LCM_M_LCM_E_CM_HO = PSI_HO_LCM_M_LCM_tab(LCM , iM_LCM);
	  
	      PSI_HO_LCM_M_LCM_E_CM_HO.MPI_Bcast (sending_process , MPI_COMM_WORLD);
	    }
	}
      
#endif
      
    }
}





// Calculation of the number and indices of (LCM,M_LCM) pairs
// ----------------------------------------------------------
// Distribution in MPI parallelization is done with one-dimensional indices. 
// As one loops on (LCM,M_LCM), one needs to associate one-dimensional indices to these pairs.
// It is done here. One simply loops on LCM_min <= LCM <=  LCM_max and -LCM <= M_LCM <= LCM and increment index.

unsigned int cluster_CM_intrinsic_basis_states::LCM_M_LCM_number_determine (
									    const int LCM_min ,
									    const int LCM_max)
{
  unsigned int LCM_M_LCM_number = 0;

  for (int LCM = LCM_min ; LCM <= LCM_max ; LCM += 2)
    for (int M_LCM = -LCM ; M_LCM <= LCM ; M_LCM++) 
      LCM_M_LCM_number++;

  return LCM_M_LCM_number;
}

void cluster_CM_intrinsic_basis_states::LCM_M_LCM_indices_determine (
								     const int LCM_min ,
								     const int LCM_max ,
								     class array<unsigned int> &LCM_M_LCM_indices)
{
  unsigned int index = 0;

  for (int LCM = LCM_min ; LCM <= LCM_max ; LCM += 2)
    {
      const int M_LCM_number = 2*LCM + 1;

      for (int iM_LCM = 0 ; iM_LCM < M_LCM_number ; iM_LCM++) 
	LCM_M_LCM_indices(LCM , iM_LCM) = index++;
    }
}





// Storage on disk of all |NCM-HO LCM M_LCM intrinsic M[intrinsic]> HO many-body vectors
// -------------------------------------------------------------------------------------
// |NCM-HO LCM M_LCM intrinsic M[intrinsic]> HO many-body vectors have been calculated by repeated actions of A+_mu[CM-HO] operators on |NCM-HO=0 LCM=0 M_LCM intrinsic M[intrinsic]> for M_intrinsic >= 0 (see above).
// They are now stored on disk. 
//
// HO many-body vectors with M_intrinsic < 0 are calculated from those with M_intrinsic > 0 with time-reversal symmetry (TRS), and stored afterwards.
// The formula is: |NCM-HO LCM -M_LCM intrinsic -M[intrinsic]> = (-1)^(LCM + J_intrinsic - M_cluster) TRS|NCM-HO LCM M_LCM intrinsic M[intrinsic]> 
// The phase comes from TRS = TRS_CM . TRS_CM, TRS_CM|LCM M_LCM> = (-1)^(LCM - M_LCM) |LCM -M_LCM>, and TRS_intrinsic|J_intrinsic M_intrinsic> = (-1)^(J_intrinsic -M_intrinsic) |J_intrinsic -M_intrinsic>.
//
// MPI and OpenMP parallelization can be used here. 
// A node takes care of parts of (LCM,M_LCM) pairs using their one-dimensional indices (see above). 
// The loop over iM_LCM, the index of M_LCM equal to M_LCM + LCM, is parallelized with OpenMP.
// Thus, all files copies are distributed among all cores. 
// MPI and OpenMP parallelization are disabled inside the parallelized loop, as otherwise parallelization would be used in TRS, which would create a race condition.
// It is reinitialized to default values at the end of the routine.

void cluster_CM_intrinsic_basis_states::PSI_HO_LCM_M_LCM_tab_all_LCM_E_CM_HO_fixed_store (
											  const class input_data_str &input_data , 
											  const double M_intrinsic , 
											  const int E_CM_HO , 
											  class cluster_data &data , 		
											  const class array<class GSM_vector> &PSI_HO_LCM_M_LCM_tab)
{
  const enum particle_type cluster = data.get_cluster ();

  const enum interaction_type inter = input_data.get_inter ();

  class nucleons_data &cluster_prot_data_HO = data.get_cluster_prot_data_HO ();
  class nucleons_data &cluster_neut_data_HO = data.get_cluster_neut_data_HO ();

  const int E_relative_max_hw = input_data.get_E_relative_max_hw ();

  const int E_min_hw_HO = cluster_prot_data_HO.get_E_min_hw () + cluster_neut_data_HO.get_E_min_hw ();

  const unsigned int BP_intrinsic = data.get_BP_intrinsic ();

  const double J_intrinsic = data.get_J_intrinsic ();

  const int Z_cluster = cluster_prot_data_HO.get_N_nucleons ();
  const int N_cluster = cluster_neut_data_HO.get_N_nucleons ();
  
  const enum space_type space = space_determine (Z_cluster , N_cluster);
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const int n_holes_max_p_HO = cluster_prot_data_HO.get_n_holes_max ();
  const int n_holes_max_n_HO = cluster_neut_data_HO.get_n_holes_max ();

  const int n_holes_max_HO = n_holes_max_p_HO + n_holes_max_n_HO;
  
  const int n_scat_max_p_HO = cluster_prot_data_HO.get_n_scat_max ();
  const int n_scat_max_n_HO = cluster_neut_data_HO.get_n_scat_max ();

  const int n_scat_max_HO = n_scat_max_p_HO + n_scat_max_n_HO;
  
  const int Ep_max_hw_HO = cluster_prot_data_HO.get_E_max_hw ();
  const int En_max_hw_HO = cluster_neut_data_HO.get_E_max_hw ();

  const int E_max_hw_HO = E_relative_max_hw + E_min_hw_HO;

  const unsigned int BP_CM = make_uns_int (E_CM_HO % 2);

  const int LCM_max_all = PSI_HO_LCM_M_LCM_tab.dimension (0) - 1;

  const int LCM_min = (BP_CM == 0) ? (0) : (1);

  const int LCM_max = min (E_CM_HO , LCM_max_all);

  const int two_M_intrinsic = make_int (2.0*M_intrinsic);

  const int LCM_number_max = LCM_max + 1;

  const int M_LCM_number_max = 2*LCM_max + 1;

  const unsigned int LCM_M_LCM_number = LCM_M_LCM_number_determine (LCM_min , LCM_max);

  class array<unsigned int> LCM_M_LCM_indices(LCM_number_max , M_LCM_number_max);

  LCM_M_LCM_indices = LCM_M_LCM_number;

  LCM_M_LCM_indices_determine (LCM_min , LCM_max , LCM_M_LCM_indices);

  const unsigned int first_index = basic_first_index_determine_for_MPI (LCM_M_LCM_number , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_index = basic_last_index_determine_for_MPI (LCM_M_LCM_number , NUMBER_OF_PROCESSES , THIS_PROCESS);

  // Parallelization has to be suppressed in order to copy many vectors from different cores.
    
  for (int LCM = LCM_min ; LCM <= LCM_max ; LCM += 2)
    {
      const unsigned int BP_CM = binary_parity_from_orbital_angular_momentum (LCM);

      const unsigned int BP_cluster = binary_parity_product (BP_CM , BP_intrinsic);

      const int NCM_HO = (E_CM_HO - LCM)/2;

      const int M_LCM_number = 2*LCM + 1;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
      for (int iM_LCM = 0 ; iM_LCM < M_LCM_number ; iM_LCM++)
	{
	  const unsigned int index = LCM_M_LCM_indices(LCM , iM_LCM);
  
#ifdef UseOpenMP
#pragma omp critical
#endif
	  {
	    OpenMP_parallelization_disabled ();

	    MPI_parallelization_disabled ();
	  }
	  
	  if ((index >= first_index) && (index <= last_index))
	    {
	      const int M_LCM = iM_LCM - LCM;

	      const double M_cluster = M_LCM + M_intrinsic;

	      const int two_M_cluster = make_int (2.0*M_cluster);

	      const class GSM_vector &PSI_HO_LCM_M_LCM_E_CM_HO = PSI_HO_LCM_M_LCM_tab(LCM , iM_LCM);

	      if (two_M_cluster >= 0)
		{
		  const string PSI_HO_string = file_name_intrinsic_CM_cluster_string ("HO_basis_state" , cluster , M_intrinsic , NCM_HO , LCM , M_LCM);

		  PSI_HO_LCM_M_LCM_E_CM_HO.copy_disk (false , false , PSI_HO_string);
		}

	      if ((two_M_intrinsic != 0) && (two_M_cluster <= 0))
		{	
		  class GSM_vector_helper_class &PSI_HO_helper = PSI_HO_LCM_M_LCM_E_CM_HO.get_GSM_vector_helper ();

		  class GSM_vector_helper_class PSI_HO_TRS_helper(false , space , inter , false , truncation_hw , truncation_ph ,
								  n_holes_max_HO   , n_scat_max_HO   , E_max_hw_HO  ,
								  n_holes_max_p_HO , n_scat_max_p_HO , Ep_max_hw_HO ,
								  n_holes_max_n_HO , n_scat_max_n_HO , En_max_hw_HO , 
								  BP_cluster , -M_cluster , true , cluster_prot_data_HO , cluster_neut_data_HO);

		  const string PSI_HO_TRS_string = file_name_intrinsic_CM_cluster_string ("HO_basis_state" , cluster , -M_intrinsic , NCM_HO , LCM , -M_LCM);

		  const class TRS_class TRS(PSI_HO_helper , PSI_HO_TRS_helper);
 
		  const class GSM_vector PSI_HO_cluster_TRS = minus_one_pow (LCM + J_intrinsic - M_cluster)*TRS (PSI_HO_LCM_M_LCM_E_CM_HO);

		  PSI_HO_cluster_TRS.copy_disk (false , false , PSI_HO_TRS_string);
		}	      
	    }
	}
    }
  
  OpenMP_parallelization_enabled ();
  
  MPI_parallelization_enabled ();	 
}


// Calculation of the number and indices of (NCM-HO,LCM) pairs
// -----------------------------------------------------------
// Distribution in MPI parallelization is done with one-dimensional indices. 
// As one loops on (NCM-HO,LCM), one needs to associate one-dimensional indices to these pairs.
// It is done here. One loops on 1 <= E[CM-HO] <= E_max[CM-HO] and LCM_min <= LCM <= LCM_max (E[CM-HO] and LCM fixed => NCM-HO fixed) and increment index.

unsigned int cluster_CM_intrinsic_basis_states::NCM_HO_LCM_number_determine (
									     const int E_CM_HO_max ,
									     const int LCM_max_all)
{	
  unsigned int NCM_HO_LCM_number = 0;

  for (int E_CM_HO = 1 ; E_CM_HO <= E_CM_HO_max ; E_CM_HO++)
    {
      const unsigned int BP_CM = make_uns_int (E_CM_HO % 2);

      const int LCM_min = (BP_CM == 0) ? (0) : (1);

      const int LCM_max = min (E_CM_HO , LCM_max_all);

      for (int LCM = LCM_min ; LCM <= LCM_max ; LCM += 2) NCM_HO_LCM_number++;
    }

  return NCM_HO_LCM_number;
}

void cluster_CM_intrinsic_basis_states::NCM_HO_LCM_indices_determine (
								      const int E_CM_HO_max ,
								      const int LCM_max_all ,
								      class array<unsigned int> &NCM_HO_LCM_indices)
{
  unsigned int index = 0;

  for (int E_CM_HO = 1 ; E_CM_HO <= E_CM_HO_max ; E_CM_HO++)
    {
      const unsigned int BP_CM = make_uns_int (E_CM_HO % 2);

      const int LCM_min = (BP_CM == 0) ? (0) : (1);
      
      const int LCM_max = min (E_CM_HO , LCM_max_all);

      for (int LCM = LCM_min ; LCM <= LCM_max ; LCM += 2)
	{
	  const int NCM_HO = (E_CM_HO - LCM)/2;

	  NCM_HO_LCM_indices(NCM_HO , LCM) = index++;
	}
    }
}










// |NCM-HO LCM intrinsic>^JM states: allocations of GSM vector classes and helpers, calculation and disk storage, test of calculated vectors
// -----------------------------------------------------------------------------------------------------------------------------------------
// One calculates HO many-body states of the form |NCM-HO LCM intrinsic>^JM in Nhw spaces, given with a basis of HO Slater determinants.
//
// Routines of this namespace are used in conjunction with GSM-CC, where targets/projectiles in composites have the form |NCM-HO LCM intrinsic>^JM when constructing the GSM-CC Hamiltonian.
// |NCM-HO LCM intrinsic>^JM is calculated from not fully coupled |NCM-HO LCM M_LCM intrinsic M[intrinsic]> states.
// |NCM-HO LCM M_LCM intrinsic M[intrinsic]> states have already been calculated (see above).
// |NCM-HO LCM intrinsic>^JM are then obtained with Clebsch-Gordan coefficients:
// |NCM-HO LCM intrinsic>^JM = \sum_{M_LCM + M_intrinsic = M} <LCM M_LCM J_intrinsic M_intrinsic | J M> |NCM-HO LCM M_LCM intrinsic M[intrinsic]>
// |NCM-HO LCM intrinsic>^JM is projected on J afterwards if necessary.
//
// The array of |NCM-HO LCM M_LCM intrinsic M[intrinsic]> states is considered with M = Jmax_cluster + 1, even though Jmax_cluster is the maximal cluster total angular momentum.
// It can occur because one will use J^2 afterwards. As one uses J^2 = J- J+ + Jz(Jz+1), the presence of J+ can induce many-body states having M = Jmax_cluster + 1 as total angular momentum projection.
//
// The precision of calculated |NCM-HO LCM intrinsic>^JM is done by considering the HO vector |Psi[test]> = |NCM-HO LCM intrinsic>^JM,
// for which the HO energy is maximal (E_CM_HO_max) and LCM is 0,1 for E_CM_HO_max even,odd.
// Indeed, it makes use of HO vectors |NCM-HO LCM intrinsic>^JM of smaller energy, so that they all have to be correct in practice for the test to hold.
// One calculates the norm of |Psi[test]>, which has to be 1, ||Hcm.Psi[test] - [(2.NCM_HO + LCM).hw].Psi[test]||oo and ||L^2[CM].Psi[test] - LCM.(LCM + 1).Psi[test]||oo, which have to be equal to zero.
// The latter values are printed on screen.


void cluster_CM_intrinsic_basis_states::all_PSI_HO_fixed_NCM_HO_LCM_alloc_init (
										const class input_data_str &input_data , 
										const unsigned int BP_cluster , 
										const int LCM , 
										class cluster_data &data , 
										class array<class GSM_vector_helper_class> &PSI_HO_BP_M_cluster_helper_tab , 
										class array<class GSM_vector_helper_class> &PSI_HO_coupled_to_J_cluster_helper_tab , 
										class array<class GSM_vector> &PSI_HO_BP_M_cluster_0_tab , 
										class array<class GSM_vector> &PSI_HO_BP_M_cluster_1_tab , 
										class array<class GSM_vector> &PSI_HO_BP_M_cluster_store_tab , 
										class array<class GSM_vector> &PSI_HO_coupled_to_J_cluster_tab)
{
  const enum interaction_type inter = input_data.get_inter ();

  class nucleons_data &cluster_prot_data_HO = data.get_cluster_prot_data_HO ();
  class nucleons_data &cluster_neut_data_HO = data.get_cluster_neut_data_HO ();

  const int E_relative_max_hw = input_data.get_E_relative_max_hw ();

  const int E_min_hw_HO = cluster_prot_data_HO.get_E_min_hw () + cluster_neut_data_HO.get_E_min_hw ();

  const double J_intrinsic = data.get_J_intrinsic ();

  const int Z_cluster = data.get_Z_cluster ();
  const int N_cluster = data.get_N_cluster ();
  const int A_cluster = data.get_A_cluster ();

  const double Jmin_cluster_all = (A_cluster%2 == 0) ? (0.0) : (0.5);
  
  const enum space_type space = space_determine (Z_cluster , N_cluster);
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const int n_holes_max_p_HO = cluster_prot_data_HO.get_n_holes_max ();
  const int n_holes_max_n_HO = cluster_neut_data_HO.get_n_holes_max ();
  
  const int n_holes_max_HO = n_holes_max_p_HO + n_holes_max_n_HO;
  
  const int n_scat_max_p_HO = cluster_prot_data_HO.get_n_scat_max ();
  const int n_scat_max_n_HO = cluster_neut_data_HO.get_n_scat_max ();
  
  const int n_scat_max_HO = n_scat_max_p_HO + n_scat_max_n_HO;
  
  const int Ep_max_hw_HO = cluster_prot_data_HO.get_E_max_hw ();
  const int En_max_hw_HO = cluster_neut_data_HO.get_E_max_hw ();

  const int E_max_hw_HO = E_relative_max_hw + E_min_hw_HO;
  
  const double Jmin_cluster = abs (J_intrinsic - LCM);

  const double Jmax_cluster = J_intrinsic + LCM;

  const int J_cluster_number = make_int (Jmax_cluster - Jmin_cluster) + 1;

  for (int iJ_cluster_LCM_J_intrinsic = 0 ; iJ_cluster_LCM_J_intrinsic < J_cluster_number ; iJ_cluster_LCM_J_intrinsic++)
    {
      const double J_cluster = Jmin_cluster + iJ_cluster_LCM_J_intrinsic;
      
      const int M_cluster_number = make_int (2.0*J_cluster) + 1;

      for (int iM_cluster_J = 0 ; iM_cluster_J < M_cluster_number ; iM_cluster_J++)
	{
	  const double M_cluster = iM_cluster_J - J_cluster;

	  const int two_M_cluster = make_int (2.0*M_cluster);

	  if (two_M_cluster >= 0)
	    {
	      const unsigned int iJ_cluster = make_int (J_cluster - Jmin_cluster_all);

	      const int iM_cluster = make_int (M_cluster - Jmin_cluster_all);

	      class GSM_vector_helper_class &PSI_HO_coupled_to_J_cluster_helper = PSI_HO_coupled_to_J_cluster_helper_tab(iJ_cluster , iM_cluster);
	      
	      class GSM_vector_helper_class &PSI_HO_BP_M_cluster_helper = PSI_HO_BP_M_cluster_helper_tab(iM_cluster);
	      
	      class GSM_vector &PSI_HO_BP_M_cluster_0 = PSI_HO_BP_M_cluster_0_tab(iM_cluster);
	      class GSM_vector &PSI_HO_BP_M_cluster_1 = PSI_HO_BP_M_cluster_1_tab(iM_cluster);
	      
	      class GSM_vector &PSI_HO_BP_M_cluster_store = PSI_HO_BP_M_cluster_store_tab(iM_cluster);
	      
	      class GSM_vector &PSI_HO_coupled_to_J_cluster = PSI_HO_coupled_to_J_cluster_tab(iJ_cluster , iM_cluster);

	      if (!PSI_HO_coupled_to_J_cluster_helper.is_it_filled ())
		{		  
		  PSI_HO_coupled_to_J_cluster_helper.allocate (false , space , inter , false , truncation_hw , truncation_ph , 
							       n_holes_max_HO   , n_scat_max_HO   , E_max_hw_HO  ,
							       n_holes_max_p_HO , n_scat_max_p_HO , Ep_max_hw_HO ,
							       n_holes_max_n_HO , n_scat_max_n_HO , En_max_hw_HO , 
							       BP_cluster , M_cluster , true , cluster_prot_data_HO , cluster_neut_data_HO);
		  
		  PSI_HO_coupled_to_J_cluster.allocate (PSI_HO_coupled_to_J_cluster_helper);
		}


	      if (!PSI_HO_BP_M_cluster_helper.is_it_filled ())
		{		  
		  PSI_HO_BP_M_cluster_helper.allocate (false , space , inter , false , truncation_hw , truncation_ph , 
						       n_holes_max_HO   , n_scat_max_HO   , E_max_hw_HO  ,
						       n_holes_max_p_HO , n_scat_max_p_HO , Ep_max_hw_HO ,
						       n_holes_max_n_HO , n_scat_max_n_HO , En_max_hw_HO , 
						       BP_cluster , M_cluster , true , cluster_prot_data_HO , cluster_neut_data_HO);

		  PSI_HO_BP_M_cluster_0.allocate (PSI_HO_BP_M_cluster_helper);
		  PSI_HO_BP_M_cluster_1.allocate (PSI_HO_BP_M_cluster_helper);
		  
		  PSI_HO_BP_M_cluster_store.allocate (PSI_HO_BP_M_cluster_helper);
		}

	      PSI_HO_coupled_to_J_cluster = 0.0;	
	    }
	}

      const double Jp1_cluster = J_cluster + 1;

      const unsigned int iJp1_cluster = make_uns_int (Jp1_cluster - Jmin_cluster_all);

      class GSM_vector_helper_class &PSI_HO_BP_M_is_Jp1_cluster_helper = PSI_HO_BP_M_cluster_helper_tab(iJp1_cluster);
      
      class GSM_vector &PSI_HO_BP_M_is_Jp1_cluster_0 = PSI_HO_BP_M_cluster_0_tab(iJp1_cluster);
      class GSM_vector &PSI_HO_BP_M_is_Jp1_cluster_1 = PSI_HO_BP_M_cluster_1_tab(iJp1_cluster);
      
      class GSM_vector &PSI_HO_BP_M_is_Jp1_cluster_store = PSI_HO_BP_M_cluster_store_tab(iJp1_cluster);

      if (!PSI_HO_BP_M_is_Jp1_cluster_helper.is_it_filled ())
	{
	  PSI_HO_BP_M_is_Jp1_cluster_helper.allocate (false , space , inter , false , truncation_hw , truncation_ph , 
						      n_holes_max_HO   , n_scat_max_HO   , E_max_hw_HO  ,
						      n_holes_max_p_HO , n_scat_max_p_HO , Ep_max_hw_HO ,
						      n_holes_max_n_HO , n_scat_max_n_HO , En_max_hw_HO , 
						      BP_cluster , Jp1_cluster , true , cluster_prot_data_HO , cluster_neut_data_HO);

	  PSI_HO_BP_M_is_Jp1_cluster_0.allocate (PSI_HO_BP_M_is_Jp1_cluster_helper);
	  PSI_HO_BP_M_is_Jp1_cluster_1.allocate (PSI_HO_BP_M_is_Jp1_cluster_helper);
	  
	  PSI_HO_BP_M_is_Jp1_cluster_store.allocate (PSI_HO_BP_M_is_Jp1_cluster_helper);
	}
    }
}

void cluster_CM_intrinsic_basis_states::all_PSI_HO_coupled_to_J_cluster_tabs_fixed_NCM_HO_LCM_calc (
												    const class cluster_data &data , 
												    const int NCM_HO , 
												    const int LCM , 
												    class array<class GSM_vector> &PSI_HO_BP_M_cluster_tab , 
												    class array<class GSM_vector> &PSI_HO_coupled_to_J_cluster_tab)
{
  const enum particle_type cluster = data.get_cluster ();

  const double J_intrinsic = data.get_J_intrinsic ();
  
  const double M_intrinsic_min = -J_intrinsic;

  const int M_intrinsic_number = make_int (2.0*J_intrinsic) + 1;

  const double Jmin_cluster = abs (J_intrinsic - LCM);

  const double Jmax_cluster = J_intrinsic + LCM;

  const int M_LCM_number = 2*LCM + 1;

  const int J_cluster_number = make_int (Jmax_cluster - Jmin_cluster) + 1;

  const int A_cluster = data.get_A_cluster ();

  const double Jmin_cluster_all = (A_cluster%2 == 0) ? (0.0) : (0.5);

  for (int iM_LCM = 0 ; iM_LCM < M_LCM_number ; iM_LCM++)
    {
      const int M_LCM = iM_LCM - LCM;

      for (int iM_intrinsic = 0 ; iM_intrinsic < M_intrinsic_number ; iM_intrinsic++)
	{
	  const double M_intrinsic = M_intrinsic_min + iM_intrinsic;

	  const double M_cluster = M_LCM + M_intrinsic;

	  const int two_M_cluster = make_int (2.0*M_cluster);
	  
	  if (two_M_cluster >= 0)
	    {
	      const int iM_cluster = make_int (M_cluster - Jmin_cluster_all);

	      const int abs_M_cluster = abs (M_cluster);

	      const string PSI_HO_string = file_name_intrinsic_CM_cluster_string ("HO_basis_state" , cluster , M_intrinsic , NCM_HO , LCM , M_LCM);

	      class GSM_vector &PSI_HO_LCM_M_LCM_J_intrinsic_M_intrinsic = PSI_HO_BP_M_cluster_tab(iM_cluster);

	      PSI_HO_LCM_M_LCM_J_intrinsic_M_intrinsic.read_disk (false , false , PSI_HO_string);
	    
	      for (int iJ_cluster_LCM_J_intrinsic = 0 ; iJ_cluster_LCM_J_intrinsic < J_cluster_number ; iJ_cluster_LCM_J_intrinsic++)
		{
		  const double J_cluster = Jmin_cluster + iJ_cluster_LCM_J_intrinsic;
			    
		  if (rint (abs_M_cluster - J_cluster) <= 0.0)
		    {
		      const unsigned int iJ_cluster = make_uns_int (J_cluster - Jmin_cluster_all);

		      const double CG = Clebsch_Gordan (LCM , M_LCM , J_intrinsic , M_intrinsic , J_cluster , M_cluster);

		      class GSM_vector &PSI_HO_coupled_to_J_cluster = PSI_HO_coupled_to_J_cluster_tab(iJ_cluster , iM_cluster);

		      PSI_HO_coupled_to_J_cluster += CG*PSI_HO_LCM_M_LCM_J_intrinsic_M_intrinsic;
		    }
		}
	    }	
	}
    }     
}

void cluster_CM_intrinsic_basis_states::all_PSI_HO_coupled_to_J_cluster_tabs_fixed_NCM_HO_LCM_project_store (
													     const class input_data_str &input_data ,
													     class cluster_data &data , 
													     const int NCM_HO , 
													     const int LCM , 
													     const class array<class GSM_vector_helper_class> &PSI_HO_BP_M_cluster_helper_tab ,
													     class array<class GSM_vector> &PSI_HO_BP_M_cluster_0_tab , 
													     class array<class GSM_vector> &PSI_HO_BP_M_cluster_1_tab , 
													     class array<class GSM_vector> &PSI_HO_BP_M_cluster_store_tab , 
													     class array<class GSM_vector> &PSI_HO_coupled_to_J_cluster_tab)
{
  const enum storage_type storage = input_data.get_Hamiltonian_storage ();
  
  const enum particle_type cluster = data.get_cluster ();

  const bool is_it_Lowdin = data.get_is_it_Lowdin ();
  
  const int A_cluster = data.get_A_cluster ();

  const double J_intrinsic = data.get_J_intrinsic ();

  const double Jmin_cluster_all = (A_cluster%2 == 0) ? (0.0) : (0.5);

  const double Jmin_cluster = abs (J_intrinsic - LCM);

  const double Jmax_cluster = J_intrinsic + LCM;

  const int J_cluster_number = make_int (Jmax_cluster - Jmin_cluster) + 1;

  class GSM_vector PSI_full;
  
  for (int iJ_cluster_LCM_J_intrinsic = 0 ; iJ_cluster_LCM_J_intrinsic < J_cluster_number ; iJ_cluster_LCM_J_intrinsic++)
    {
      const double J_cluster = Jmin_cluster + iJ_cluster_LCM_J_intrinsic;

      const int M_cluster_number = make_int (2.0*J_cluster) + 1;

      for (int iM_cluster_J = 0 ; iM_cluster_J < M_cluster_number ; iM_cluster_J++)
	{
	  const double M_cluster = iM_cluster_J - J_cluster;

	  const int two_M_cluster = make_int (2.0*M_cluster);

	  if (two_M_cluster >= 0)
	    {
	      const unsigned int iJ_cluster = make_int (J_cluster - Jmin_cluster_all);

	      const int iM_cluster = make_int (M_cluster - Jmin_cluster_all);

	      const int iMp1_cluster = iM_cluster + 1;

	      const string PSI_HO_dimension_string = file_name_intrinsic_CM_cluster_string ("HO_basis_state_dimension" , cluster , NCM_HO , LCM , J_cluster , M_cluster);
	      const string PSI_HO_string           = file_name_intrinsic_CM_cluster_string ("HO_basis_state"           , cluster , NCM_HO , LCM , J_cluster , M_cluster);

	      // This is for the case where the Berggren basis states are used in the following, even though they are equal to HO basis states.
	      const string PSI_Berggren_dimension_string = file_name_intrinsic_CM_cluster_string ("Berggren_basis_state_dimension" , cluster , NCM_HO , LCM , J_cluster , M_cluster);	      
	      const string PSI_Berggren_string           = file_name_intrinsic_CM_cluster_string ("Berggren_basis_state"           , cluster , NCM_HO , LCM , J_cluster , M_cluster);		  
	      
	      class GSM_vector_helper_class &PSI_HO_BP_M_cluster_helper   = PSI_HO_BP_M_cluster_helper_tab(iM_cluster);
	      class GSM_vector_helper_class &PSI_HO_BP_Mp1_cluster_helper = PSI_HO_BP_M_cluster_helper_tab(iMp1_cluster);

	      class GSM_vector &PSI_HO_BP_M_cluster_0   = PSI_HO_BP_M_cluster_0_tab(iM_cluster);
	      class GSM_vector &PSI_HO_BP_M_cluster_1   = PSI_HO_BP_M_cluster_1_tab(iM_cluster);
	      
	      class GSM_vector &PSI_HO_BP_Mp1_cluster_0 = PSI_HO_BP_M_cluster_0_tab(iMp1_cluster);
	      class GSM_vector &PSI_HO_BP_Mp1_cluster_1 = PSI_HO_BP_M_cluster_1_tab(iMp1_cluster);
	      
	      class GSM_vector &PSI_HO_BP_M_cluster_store   = PSI_HO_BP_M_cluster_store_tab(iM_cluster);	      
	      class GSM_vector &PSI_HO_BP_Mp1_cluster_store = PSI_HO_BP_M_cluster_store_tab(iMp1_cluster);
	      	      
	      class GSM_vector &PSI_HO_coupled_to_J_cluster = PSI_HO_coupled_to_J_cluster_tab(iJ_cluster , iM_cluster);
	      
	      const class Jpm_class Jplus(false  , false ,  1 , storage , false , PSI_HO_BP_M_cluster_helper   , PSI_HO_BP_Mp1_cluster_helper , PSI_full , PSI_HO_BP_Mp1_cluster_0 , PSI_HO_BP_Mp1_cluster_1);
	      const class Jpm_class Jminus(false , false , -1 , storage , false , PSI_HO_BP_Mp1_cluster_helper , PSI_HO_BP_M_cluster_helper   , PSI_full , PSI_HO_BP_M_cluster_0   , PSI_HO_BP_M_cluster_1);
      
	      const class J2_class J2(Jplus , Jminus , PSI_HO_BP_Mp1_cluster_store);
  
	      const double J_coupling_precision = J2.J_coupling_precision_calc (PSI_HO_coupled_to_J_cluster , J_cluster , PSI_HO_BP_M_cluster_store);
	      
	      if (J_coupling_precision > precision)
		{      
		  if (is_it_Lowdin)
		    PSI_HO_coupled_to_J_cluster.good_J_Lowdin (false , J2 , J_cluster , PSI_HO_BP_M_cluster_store);
		  else
		    {
		      class array<class GSM_vector> Vp_tab(J_cluster_number);
		      
		      for (int i = 0 ; i < J_cluster_number ; i++) Vp_tab(i).allocate (PSI_HO_BP_M_cluster_helper);
		      
		      Lanczos_GSM_not_disk::J2_projection::J_projected_GSM_vector_calc (false , J_cluster , J_cluster_number , J2 , Vp_tab , PSI_HO_coupled_to_J_cluster);
		    }
		}
	      
	      PSI_HO_coupled_to_J_cluster.space_dimension_SDs_components_copy_disk (false , false , PSI_HO_dimension_string , PSI_HO_string);
	      
	      PSI_HO_coupled_to_J_cluster.space_dimension_SDs_components_copy_disk (false , false , PSI_Berggren_dimension_string , PSI_Berggren_string);
	      
	      // This is for the case where the Berggren basis states are used in the following, even though they are equal to HO basis states.
	      if (two_M_cluster > 0)
		{
		  const enum particle_type cluster = data.get_cluster ();

		  const enum interaction_type inter = input_data.get_inter ();

		  class nucleons_data &cluster_prot_data_HO = data.get_cluster_prot_data_HO ();
		  class nucleons_data &cluster_neut_data_HO = data.get_cluster_neut_data_HO ();

		  const int E_relative_max_hw = input_data.get_E_relative_max_hw ();

		  const int E_min_hw_HO = cluster_prot_data_HO.get_E_min_hw () + cluster_neut_data_HO.get_E_min_hw ();

		  const unsigned int BP_intrinsic = data.get_BP_intrinsic ();

		  const unsigned int BP_CM = binary_parity_from_orbital_angular_momentum (LCM);

		  const unsigned int BP_cluster = binary_parity_product (BP_CM , BP_intrinsic);

		  const int Z_cluster = cluster_prot_data_HO.get_N_nucleons ();
		  const int N_cluster = cluster_neut_data_HO.get_N_nucleons ();

		  const enum space_type space = space_determine (Z_cluster , N_cluster);

		  const bool truncation_hw = input_data.get_truncation_hw ();
		  const bool truncation_ph = input_data.get_truncation_ph ();

		  const int n_holes_max_p_HO = cluster_prot_data_HO.get_n_holes_max ();
		  const int n_holes_max_n_HO = cluster_neut_data_HO.get_n_holes_max ();

		  const int n_holes_max_HO = n_holes_max_p_HO + n_holes_max_n_HO;
  
		  const int n_scat_max_p_HO = cluster_prot_data_HO.get_n_scat_max ();
		  const int n_scat_max_n_HO = cluster_neut_data_HO.get_n_scat_max ();

		  const int n_scat_max_HO = n_scat_max_p_HO + n_scat_max_n_HO;
  
		  const int Ep_max_hw_HO = cluster_prot_data_HO.get_E_max_hw ();
		  const int En_max_hw_HO = cluster_neut_data_HO.get_E_max_hw ();
		  
		  const int E_max_hw_HO = E_relative_max_hw + E_min_hw_HO;
		      
		  class GSM_vector_helper_class &PSI_HO_helper = PSI_HO_coupled_to_J_cluster.get_GSM_vector_helper ();
		      
		  class GSM_vector_helper_class PSI_HO_TRS_helper(false , space , inter , false , truncation_hw , truncation_ph ,
								  n_holes_max_HO   , n_scat_max_HO   , E_max_hw_HO  ,
								  n_holes_max_p_HO , n_scat_max_p_HO , Ep_max_hw_HO ,
								  n_holes_max_n_HO , n_scat_max_n_HO , En_max_hw_HO , 
								  BP_cluster , -M_cluster , true , cluster_prot_data_HO , cluster_neut_data_HO);
	  
		  const class TRS_class TRS(PSI_HO_helper , PSI_HO_TRS_helper);
	  
		  const string PSI_Berggren_dimension_TRS_string = file_name_intrinsic_CM_cluster_string ("Berggren_basis_state_dimension" , cluster , NCM_HO , LCM , J_cluster , -M_cluster);	      
		  const string PSI_Berggren_TRS_string           = file_name_intrinsic_CM_cluster_string ("Berggren_basis_state"           , cluster , NCM_HO , LCM , J_cluster , -M_cluster);
		  
		  const class GSM_vector PSI_HO_cluster_TRS = minus_one_pow (J_cluster - M_cluster)*TRS (PSI_HO_coupled_to_J_cluster);
	  
		  PSI_HO_coupled_to_J_cluster.space_dimension_SDs_components_copy_disk (false , false , PSI_Berggren_dimension_TRS_string , PSI_Berggren_TRS_string);
		}
	    }
	}
    }
}


  
void cluster_CM_intrinsic_basis_states::PSI_HO_coupled_to_J_cluster_E_CM_HO_max_precision_print (
												 const class input_data_str &input_data ,
												 class cluster_data &data)
{
  const enum particle_type cluster = data.get_cluster ();

  const unsigned int BP_intrinsic = data.get_BP_intrinsic ();

  const double J_intrinsic = data.get_J_intrinsic ();

  const int E_CM_HO_max = data.get_E_CM_HO_max ();

  const unsigned int BP_CM = make_uns_int (E_CM_HO_max % 2);

  const unsigned int BP_cluster = binary_parity_product (BP_CM , BP_intrinsic);

  const int LCM = (BP_CM == 0) ? (0) : (1);

  const enum interaction_type inter = input_data.get_inter ();

  class nucleons_data &cluster_prot_data_HO = data.get_cluster_prot_data_HO ();
  class nucleons_data &cluster_neut_data_HO = data.get_cluster_neut_data_HO ();

  const int E_relative_max_hw = input_data.get_E_relative_max_hw ();

  const int E_min_hw_HO = cluster_prot_data_HO.get_E_min_hw () + cluster_neut_data_HO.get_E_min_hw ();

  const int Z_cluster = cluster_prot_data_HO.get_N_nucleons ();
  const int N_cluster = cluster_neut_data_HO.get_N_nucleons ();
  
  const enum space_type space = space_determine (Z_cluster , N_cluster);
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const int n_holes_max_p_HO = cluster_prot_data_HO.get_n_holes_max ();
  const int n_holes_max_n_HO = cluster_neut_data_HO.get_n_holes_max ();

  const int n_holes_max_HO = n_holes_max_p_HO + n_holes_max_n_HO;
  
  const int n_scat_max_p_HO = cluster_prot_data_HO.get_n_scat_max ();
  const int n_scat_max_n_HO = cluster_neut_data_HO.get_n_scat_max ();

  const int n_scat_max_HO = n_scat_max_p_HO + n_scat_max_n_HO;
  
  const int Ep_max_hw_HO = cluster_prot_data_HO.get_E_max_hw ();
  const int En_max_hw_HO = cluster_neut_data_HO.get_E_max_hw ();

  const int E_max_hw_HO = E_relative_max_hw + E_min_hw_HO;

  const int NCM_HO = (E_CM_HO_max - LCM)/2;

  const double J_cluster = abs (J_intrinsic - LCM);

  const double M_cluster = J_cluster;

  const double Mp1_cluster = M_cluster + 1;

  const double hbar_omega_cluster = data.get_hbar_omega_cluster ();

  const double E_CM_HO_max_hbar_omega = E_CM_HO_max*hbar_omega_cluster;

  const string PSI_HO_string = file_name_intrinsic_CM_cluster_string ("HO_basis_state" , cluster , NCM_HO , LCM , J_cluster , M_cluster);
  
  class GSM_vector_helper_class PSI_HO_BP_M_cluster_helper (is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph , 
							    n_holes_max_HO   , n_scat_max_HO   , E_max_hw_HO  ,
							    n_holes_max_p_HO , n_scat_max_p_HO , Ep_max_hw_HO ,
							    n_holes_max_n_HO , n_scat_max_n_HO , En_max_hw_HO ,
							    BP_cluster , M_cluster , true , cluster_prot_data_HO , cluster_neut_data_HO);

  class GSM_vector_helper_class PSI_HO_BP_Mp1_cluster_helper (is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph , 
							      n_holes_max_HO   , n_scat_max_HO   , E_max_hw_HO  ,
							      n_holes_max_p_HO , n_scat_max_p_HO , Ep_max_hw_HO ,
							      n_holes_max_n_HO , n_scat_max_n_HO , En_max_hw_HO ,
							      BP_cluster , Mp1_cluster , true , cluster_prot_data_HO , cluster_neut_data_HO);

  class GSM_vector_helper_class PSI_HO_BP_M_cluster_helper_full (false , space , inter , false , truncation_hw , truncation_ph , 
								 n_holes_max_HO   , n_scat_max_HO   , E_max_hw_HO  ,
								 n_holes_max_p_HO , n_scat_max_p_HO , Ep_max_hw_HO ,
								 n_holes_max_n_HO , n_scat_max_n_HO , En_max_hw_HO , 
								 BP_cluster , M_cluster , true , cluster_prot_data_HO , cluster_neut_data_HO);
  
  class GSM_vector_helper_class PSI_HO_BP_Mp1_cluster_helper_full (false , space , inter , false , truncation_hw , truncation_ph , 
								   n_holes_max_HO   , n_scat_max_HO   , E_max_hw_HO  ,
								   n_holes_max_p_HO , n_scat_max_p_HO , Ep_max_hw_HO ,
								   n_holes_max_n_HO , n_scat_max_n_HO , En_max_hw_HO , 
								   BP_cluster , Mp1_cluster , true , cluster_prot_data_HO , cluster_neut_data_HO);

  class GSM_vector PSI_HO_coupled_to_J_cluster(PSI_HO_BP_M_cluster_helper);

  PSI_HO_coupled_to_J_cluster.read_disk (true , true , PSI_HO_string);

  if (THIS_PROCESS == MASTER_PROCESS) cout << JM_Pi_string (BP_cluster , J_cluster , M_cluster) << " : NCM[HO] = " << NCM_HO << " LCM = " << LCM << endl;

  const double PSI_norm = real_dc (sqrt (PSI_HO_coupled_to_J_cluster*PSI_HO_coupled_to_J_cluster));

  if (THIS_PROCESS == MASTER_PROCESS) cout << "||PSI|| = " << PSI_norm << endl;
      
  class GSM_vector PSI_M_full(PSI_HO_BP_M_cluster_helper_full);

  class GSM_vector PSI_Mp1_full(PSI_HO_BP_Mp1_cluster_helper_full);
  
  class GSM_vector Res(PSI_HO_BP_M_cluster_helper);

  class GSM_vector PSI_M(PSI_HO_BP_M_cluster_helper);

  class GSM_vector PSI_Mp1(PSI_HO_BP_Mp1_cluster_helper);
  
  const class CM_operator_class Hcm(HCM , false , J_cluster , true , PSI_HO_BP_M_cluster_helper , PSI_HO_BP_M_cluster_helper , PSI_M_full);

  Res = (Hcm - E_CM_HO_max_hbar_omega)*PSI_HO_coupled_to_J_cluster;
  
  const double Hcm_test = Res.infinite_norm ();

  if (THIS_PROCESS == MASTER_PROCESS) cout << "|Hcm.PSI - [(2.NCM_HO + LCM).hw].PSI|oo = " << Hcm_test << endl;

  const class CM_operator_class Lplus  (LPLUS  , false , J_cluster , true , PSI_HO_BP_M_cluster_helper   , PSI_HO_BP_Mp1_cluster_helper , PSI_M_full);
  const class CM_operator_class Lminus (LMINUS , false , J_cluster , true , PSI_HO_BP_Mp1_cluster_helper , PSI_HO_BP_M_cluster_helper   , PSI_Mp1_full);
  const class CM_operator_class Lz     (LZ     , false , J_cluster , true , PSI_HO_BP_M_cluster_helper   , PSI_HO_BP_M_cluster_helper   , PSI_M_full);

  const class L2_CM_class L2_CM(Lplus , Lminus , Lz , PSI_M , PSI_Mp1);

  Res = (L2_CM - LCM*(LCM + 1))*PSI_HO_coupled_to_J_cluster;
  
  const double L2_CM_test = Res.infinite_norm ();

  if (THIS_PROCESS == MASTER_PROCESS) cout << "|L^2[CM].PSI - LCM.(LCM + 1).PSI|oo = " << L2_CM_test << endl;
}

void cluster_CM_intrinsic_basis_states::all_PSI_HO_coupled_to_J_cluster_calc_store (
										    const class input_data_str &input_data , 
										    class cluster_data &data)
{
  const unsigned int BP_intrinsic = data.get_BP_intrinsic ();

  const int E_CM_HO_max = data.get_E_CM_HO_max ();

  const int LCM_max_all = data.get_Lmax ();

  const int A_cluster = data.get_A_cluster ();

  const double J_intrinsic = data.get_J_intrinsic ();

  const double Jmin_cluster_all = (A_cluster%2 == 0) ? (0.0) : (0.5);

  const double Jmax_cluster_all = J_intrinsic + LCM_max_all;

  const int J_cluster_number_max = make_int (Jmax_cluster_all - Jmin_cluster_all) + 1;

  const int M_cluster_number_max = J_cluster_number_max;

  const int Mp1_cluster_number_max = M_cluster_number_max + 1;

  const int NCM_HO_max = E_CM_HO_max/2;

  const unsigned int NCM_HO_LCM_number = NCM_HO_LCM_number_determine (E_CM_HO_max , LCM_max_all);

  const unsigned int NCM_HO_number_max = NCM_HO_max + 1;

  const unsigned int LCM_number_max = LCM_max_all + 1;

  class array<unsigned int> NCM_HO_LCM_indices(NCM_HO_number_max , LCM_number_max);

  NCM_HO_LCM_indices = NCM_HO_LCM_number;

  NCM_HO_LCM_indices_determine (E_CM_HO_max , LCM_max_all , NCM_HO_LCM_indices);

  const unsigned int first_index = basic_first_index_determine_for_MPI (NCM_HO_LCM_number , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_index = basic_last_index_determine_for_MPI (NCM_HO_LCM_number , NUMBER_OF_PROCESSES , THIS_PROCESS);

  // Parallelization has to be suppressed in order to calculate and copy many vectors from different cores.
  
  // M_cluster is always positive in this function and called functions.

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (int E_CM_HO = 1 ; E_CM_HO <= E_CM_HO_max ; E_CM_HO++)
    {
      const unsigned int BP_CM = make_uns_int (E_CM_HO % 2);

      const unsigned int BP_cluster = binary_parity_product (BP_CM , BP_intrinsic);

      const int LCM_min = (BP_CM == 0) ? (0) : (1);

      const int LCM_max = min (E_CM_HO , LCM_max_all);

      class array<class GSM_vector_helper_class> PSI_HO_coupled_to_J_cluster_helper_tab(J_cluster_number_max , M_cluster_number_max);

      class array<class GSM_vector_helper_class> PSI_HO_BP_M_cluster_helper_tab(Mp1_cluster_number_max);
      
      class array<class GSM_vector> PSI_HO_coupled_to_J_cluster_tab(J_cluster_number_max , M_cluster_number_max);
      
      class array<class GSM_vector> PSI_HO_BP_M_cluster_0_tab(Mp1_cluster_number_max);
      class array<class GSM_vector> PSI_HO_BP_M_cluster_1_tab(Mp1_cluster_number_max);
      
      class array<class GSM_vector> PSI_HO_BP_M_cluster_store_tab(Mp1_cluster_number_max);

      for (int LCM = LCM_min ; LCM <= LCM_max ; LCM += 2)
	{
	  const int NCM_HO = (E_CM_HO - LCM)/2;

	  const unsigned int index = NCM_HO_LCM_indices(NCM_HO , LCM);
	  
#ifdef UseOpenMP
#pragma omp critical
#endif
	  {
	    OpenMP_parallelization_disabled ();

	    MPI_parallelization_disabled ();
	  }
	  
	  if ((index >= first_index) && (index <= last_index))
	    {
	      all_PSI_HO_fixed_NCM_HO_LCM_alloc_init (input_data , BP_cluster , LCM ,data , PSI_HO_BP_M_cluster_helper_tab , PSI_HO_coupled_to_J_cluster_helper_tab ,
						      PSI_HO_BP_M_cluster_0_tab , PSI_HO_BP_M_cluster_1_tab , PSI_HO_BP_M_cluster_store_tab , PSI_HO_coupled_to_J_cluster_tab);

	      all_PSI_HO_coupled_to_J_cluster_tabs_fixed_NCM_HO_LCM_calc (data , NCM_HO , LCM , PSI_HO_BP_M_cluster_0_tab , PSI_HO_coupled_to_J_cluster_tab);

	      all_PSI_HO_coupled_to_J_cluster_tabs_fixed_NCM_HO_LCM_project_store (input_data , data , NCM_HO , LCM , PSI_HO_BP_M_cluster_helper_tab ,
										   PSI_HO_BP_M_cluster_0_tab , PSI_HO_BP_M_cluster_1_tab , PSI_HO_BP_M_cluster_store_tab , PSI_HO_coupled_to_J_cluster_tab);	      
	    } 
	}
    }
  
  OpenMP_parallelization_enabled ();

  MPI_parallelization_enabled ();
}
 
void cluster_CM_intrinsic_basis_states::GSM_vector_NCM_HO_LCM_HO_basis_tab_calc_store (
										       const bool is_there_cout , 
										       const class input_data_str &input_data , 
										       class cluster_data &data)
{
  const enum particle_type cluster = data.get_cluster ();

  const double J_intrinsic = data.get_J_intrinsic ();

  const int E_CM_HO_max = data.get_E_CM_HO_max ();

  const int LCM_max_all = data.get_Lmax ();

  const int A_cluster = data.get_A_cluster ();

  const int LCM_number_max = LCM_max_all + 1;

  const int M_LCM_number_max = 2*LCM_max_all + 1;

  const double M_intrinsic_max = J_intrinsic;

  const double M_intrinsic_min = (A_cluster%2 == 0) ? (0.0) : (0.5);

  const int M_intrinsic_number = make_int (M_intrinsic_max - M_intrinsic_min) + 1;

  const int M_intrinsic_number_minus_one = M_intrinsic_number - 1;
  
  // Negative M_intrinsic's are considered with TRS.
  
  for (int iM_intrinsic = M_intrinsic_number_minus_one ; iM_intrinsic >= 0 ; iM_intrinsic--)
    {
      const double M_intrinsic = M_intrinsic_min + iM_intrinsic;

      class array<class GSM_vector_helper_class> GSM_vector_helper_M_E_CM_HO_tab   (2 , M_LCM_number_max);      
      class array<class GSM_vector_helper_class> GSM_vector_helper_M_E_CM_HO_m1_tab(2 , M_LCM_number_max);

      // PSI_HO_LCM_M_LCM_tab will contain vectors for all E_CM energies. At the beginning of a E_CM_HO loop, they contain the vectors with E_CM_HO-1 energy.
      // As vectors with E_CM_HO-1 energy have a different parity as those of E_CM_HO energy, no overwriting problem can occur in a loop.

      class array<class GSM_vector> GSM_vector_M_E_CM_HO_m1_tab  (2 , M_LCM_number_max);

      class array<class CM_operator_class> A_dagger_CM_HO_minus_tab(2 , M_LCM_number_max);
      class array<class CM_operator_class> A_dagger_CM_HO_zero_tab (2 , M_LCM_number_max);
      class array<class CM_operator_class> A_dagger_CM_HO_plus_tab (2 , M_LCM_number_max);

      class array<class GSM_vector> PSI_HO_LCM_M_LCM_tab(LCM_number_max , M_LCM_number_max);
      
      PSI_HO_A_dagger_CM_HO_LCM_M_LCM_tabs_alloc (input_data , M_intrinsic , data , GSM_vector_helper_M_E_CM_HO_tab , GSM_vector_helper_M_E_CM_HO_m1_tab , GSM_vector_M_E_CM_HO_m1_tab ,
						  A_dagger_CM_HO_minus_tab , A_dagger_CM_HO_zero_tab , A_dagger_CM_HO_plus_tab , PSI_HO_LCM_M_LCM_tab);
      
      PSI_HO_CM_0s_M_intrinsic_store (input_data , iM_intrinsic , data , PSI_HO_LCM_M_LCM_tab);
      
      for (int E_CM_HO = 1 ; E_CM_HO <= E_CM_HO_max ; E_CM_HO++)
	{
	  PSI_HO_LCM_M_LCM_tab_all_LCM_E_CM_HO_fixed_calc (E_CM_HO , A_dagger_CM_HO_minus_tab , A_dagger_CM_HO_zero_tab , A_dagger_CM_HO_plus_tab , PSI_HO_LCM_M_LCM_tab);
	  
	  PSI_HO_LCM_M_LCM_tab_all_LCM_E_CM_HO_fixed_store (input_data , M_intrinsic , E_CM_HO , data , PSI_HO_LCM_M_LCM_tab);
	}
    }

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    cout << endl << "cluster : " << cluster << endl << endl << "LCM-coupled A+[CM].PSI HO cluster states calculated and stored" << endl;

  all_PSI_HO_coupled_to_J_cluster_calc_store (input_data , data);

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    cout << endl << "J-coupled A+[CM].PSI HO cluster states calculated and stored" << endl;

  if (is_there_cout)
    {
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
      
      PSI_HO_coupled_to_J_cluster_E_CM_HO_max_precision_print (input_data , data);
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
    }
}



















// Read of |NCM-HO LCM intrinsic>^JM states in HO basis from disk, conversion to the Berggren basis, disk storage of |NCM-HO LCM intrinsic>^JM states in Berggren basis
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Routines of this namespace are used in conjunction with GSM-CC, where targets/projectiles in composites have the form |NCM-HO LCM intrinsic>^JM when constructing the GSM-CC Hamiltonian.
//
// |NCM-HO LCM intrinsic>^JM states in HO basis can be calculated from previous routines (M scheme), but also from a direct calculation in relative coordinates for two-nucleon clusters (J scheme) (see GSM_two_relative_dir).
// In the latter case, two-nucleon intrinsic states are firsly calculated with the Berggren basis, and then projected to a HO basis.
// The passage from relative/CM coordinates to laboratory coordinates using the HO basis is handled by the Talmi transformation.
//
// |NCM-HO LCM intrinsic>^JM states are read from disk, and then converted to the Berggren basis. 
// For this, one has to calculate configurations and SDs in the in and out spaces as it is an N-body operator (see configuration_SD_in_space_one_jump.cpp), as well as the overlaps between HO and Berggren SDs.
// The nature of the many-body states does not change, only the one-body basis used for their expansion (up to truncations).
// Newly obtained GSM vectors are projected on J afterwards if necessary.
// |NCM-HO LCM intrinsic>^JM states in Berggren basis are then copied to disk for further use in GSM-CC.
//
// Berggren many-body vectors with M < 0 are calculated from those with M > 0 with time-reversal symmetry (TRS), and stored afterwards.
// The formula is: |NCM-HO LCM intrinsic>^(J,-M) = (-1)^(J - M) TRS|NCM-HO LCM intrinsic>^(J,-M)
// The phase comes from TRS|JM> = (-1)^(J - M) |J -M>.
//
// Vectors are copied to file as formatted as they have to be read by routines other than read_disk.
//
// MPI and OpenMP parallelization can be used here. 
// A node takes care of parts of NCM_HO indices for fixed LCM.
// The loop over NCM_HO is parallelized with OpenMP.
// Thus, all files copies are distributed among all cores. 
// MPI is disabled inside the parallelized loop, as otherwise parallelization would be used in J2, which would create a race condition.
// OpenMP is not disabled, as it is either absent from loops in the routine, or is used in the routine but not in the called routines inside the loop.
// MPI is reinitialized to default value at the end of the routine.


void cluster_CM_intrinsic_basis_states::GSM_vector_NCM_HO_LCM_HO_basis_tab_read_from_M_scheme ( 
											       const class cluster_data &data , 
											       const int LCM , 
											       const double J_cluster , 
											       const double M_cluster , 
											       class array<class GSM_vector> &GSM_vector_NCM_HO_LCM_HO_basis_tab)
{
  const enum particle_type cluster = data.get_cluster ();

  const class array<int> &Nmax_HO_tab = data.get_Nmax_HO_tab ();	

  const int NCM_HO_max_LCM = Nmax_HO_tab(LCM);

  const int NCM_HO_max_LCM_plus_one = NCM_HO_max_LCM + 1;

  const int first_NCM_HO = basic_first_index_determine_for_MPI (NCM_HO_max_LCM_plus_one , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const int last_NCM_HO = basic_last_index_determine_for_MPI (NCM_HO_max_LCM_plus_one , NUMBER_OF_PROCESSES , THIS_PROCESS);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (int NCM_HO = 0 ; NCM_HO <= NCM_HO_max_LCM ; NCM_HO++)
    {	
      if ((NCM_HO >= first_NCM_HO) && (NCM_HO <= last_NCM_HO))
	{	
	  const string PSI_HO_dimension_string = file_name_intrinsic_CM_cluster_string ("HO_basis_state_dimension" , cluster , NCM_HO , LCM , J_cluster , M_cluster);	  
	  const string PSI_HO_string           = file_name_intrinsic_CM_cluster_string ("HO_basis_state"           , cluster , NCM_HO , LCM , J_cluster , M_cluster);

	  class GSM_vector &GSM_vector_NCM_HO_LCM_HO_basis = GSM_vector_NCM_HO_LCM_HO_basis_tab(NCM_HO);

	  GSM_vector_NCM_HO_LCM_HO_basis.SDs_components_read_disk (PSI_HO_dimension_string , PSI_HO_string);	  	
	}
    }
}

void cluster_CM_intrinsic_basis_states::GSM_vector_NCM_HO_LCM_HO_basis_tab_read_from_J_scheme ( 
											       const class cluster_data &data , 
											       const int LCM , 
											       const double J_cluster , 
											       class array<class GSM_vector> &GSM_vector_NCM_HO_LCM_HO_basis_tab)
{
  const enum particle_type cluster = data.get_cluster ();

  const class array<int> &Nmax_HO_tab = data.get_Nmax_HO_tab ();	

  const int NCM_HO_max_LCM = Nmax_HO_tab(LCM);

  const int NCM_HO_max_LCM_plus_one = NCM_HO_max_LCM + 1;

  const int first_NCM_HO = basic_first_index_determine_for_MPI (NCM_HO_max_LCM_plus_one , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const int last_NCM_HO = basic_last_index_determine_for_MPI (NCM_HO_max_LCM_plus_one , NUMBER_OF_PROCESSES , THIS_PROCESS);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (int NCM_HO = 0 ; NCM_HO <= NCM_HO_max_LCM ; NCM_HO++)
    {	
      if ((NCM_HO >= first_NCM_HO) && (NCM_HO <= last_NCM_HO))
	{	
	  const string PSI_HO_dimension_string = file_name_intrinsic_CM_cluster_string ("HO_basis_state_dimension" , cluster , NCM_HO , LCM , J_cluster);	  
	  const string PSI_HO_string           = file_name_intrinsic_CM_cluster_string ("HO_basis_state"           , cluster , NCM_HO , LCM , J_cluster);

	  class GSM_vector &GSM_vector_NCM_HO_LCM_HO_basis = GSM_vector_NCM_HO_LCM_HO_basis_tab(NCM_HO);

	  GSM_vector_NCM_HO_LCM_HO_basis.J_scheme_components_read_disk_M_scheme_conversion (J_cluster , PSI_HO_dimension_string , PSI_HO_string);	  	
	}
    }
}

void cluster_CM_intrinsic_basis_states::GSM_vector_NCM_HO_LCM_HO_basis_tab_read ( 
										 const bool are_two_body_clusters_stored_in_J_scheme ,
										 const class cluster_data &data , 
										 const int LCM , 
										 const double J_cluster , 
										 const double M_cluster , 
										 class array<class GSM_vector> &GSM_vector_NCM_HO_LCM_HO_basis_tab)
{
  const unsigned int A_cluster = data.get_A_cluster ();

  if (are_two_body_clusters_stored_in_J_scheme && (A_cluster == 2))
    GSM_vector_NCM_HO_LCM_HO_basis_tab_read_from_J_scheme (data , LCM , J_cluster , GSM_vector_NCM_HO_LCM_HO_basis_tab);
  else
    GSM_vector_NCM_HO_LCM_HO_basis_tab_read_from_M_scheme (data , LCM , J_cluster , M_cluster , GSM_vector_NCM_HO_LCM_HO_basis_tab);
}

void cluster_CM_intrinsic_basis_states::GSM_vector_NCM_HO_LCM_Berggren_basis_tab_calc (
										       const class cluster_data &data , 
										       const int LCM , 
										       const double J_cluster , 	
										       const class J2_class &J2 , 
										       const class cluster_HO_to_Berggren_class &cluster_HO_to_Berggren , 
										       const class array<class GSM_vector> &GSM_vector_NCM_HO_LCM_HO_basis_tab , 
										       class GSM_vector &Vstore , 
										       class array<class GSM_vector> &GSM_vector_NCM_HO_LCM_Berggren_basis_tab)
{	
  const class array<int> &Nmax_HO_tab = data.get_Nmax_HO_tab ();	

  const int NCM_HO_max_LCM = Nmax_HO_tab(LCM);

  const int NCM_HO_max_LCM_plus_one = NCM_HO_max_LCM + 1;

  const int first_NCM_HO = basic_first_index_determine_for_MPI (NCM_HO_max_LCM_plus_one , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const int last_NCM_HO = basic_last_index_determine_for_MPI (NCM_HO_max_LCM_plus_one , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (int NCM_HO = 0 ; NCM_HO <= NCM_HO_max_LCM ; NCM_HO++)
    {
      if ((NCM_HO >= first_NCM_HO) && (NCM_HO <= last_NCM_HO))
	{
	  // No race condition can occur here. 
	  // Indeed , OpenMP parallelization is not explicitly used in the GSM_vector_NCM_HO_LCM_Berggren_basis_tab_calc routine (here) 
	  // and in the calling routine Berggren_basis_states_calc_store.

	  MPI_parallelization_disabled ();
	  
	  const class GSM_vector &GSM_vector_NCM_HO_LCM_HO_basis = GSM_vector_NCM_HO_LCM_HO_basis_tab(NCM_HO);	  
	  
	  class GSM_vector &GSM_vector_NCM_HO_LCM_Berggren_basis = GSM_vector_NCM_HO_LCM_Berggren_basis_tab(NCM_HO);

	  GSM_vector_NCM_HO_LCM_Berggren_basis = cluster_HO_to_Berggren*GSM_vector_NCM_HO_LCM_HO_basis;
	  
	  const double J_coupling_precision = J2.J_coupling_precision_calc (GSM_vector_NCM_HO_LCM_Berggren_basis , J_cluster , Vstore);
	  
	  if (J_coupling_precision > precision) GSM_vector_NCM_HO_LCM_Berggren_basis.good_J_Lowdin (false , J2 , J_cluster , Vstore);
	}
    }
  
  MPI_parallelization_enabled ();
}

void cluster_CM_intrinsic_basis_states::GSM_vector_NCM_HO_LCM_Berggren_basis_tab_store (
											const class cluster_data &data , 
											const int LCM , 
											const double J_cluster , 
											const double M_cluster , 
											class array<class GSM_vector> &GSM_vector_NCM_HO_LCM_Berggren_basis_TRS_tab , 
											class array<class GSM_vector> &GSM_vector_NCM_HO_LCM_Berggren_basis_tab)
{	
  const enum particle_type cluster = data.get_cluster ();

  const int NCM_HO_max_LCM = GSM_vector_NCM_HO_LCM_Berggren_basis_tab.dimension (0) - 1;

  const int two_M_cluster = make_int (2.0*M_cluster);

  const int NCM_HO_max_LCM_plus_one = NCM_HO_max_LCM + 1;

  const int first_NCM_HO = basic_first_index_determine_for_MPI (NCM_HO_max_LCM_plus_one , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const int last_NCM_HO = basic_last_index_determine_for_MPI (NCM_HO_max_LCM_plus_one , NUMBER_OF_PROCESSES , THIS_PROCESS);

  // Parallelization has to be suppressed in order to use operators independently from each other in different nodes.
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (int NCM_HO = 0 ; NCM_HO <= NCM_HO_max_LCM ; NCM_HO++)
    {
      if ((NCM_HO >= first_NCM_HO) && (NCM_HO <= last_NCM_HO))
	{
	  
#ifdef UseOpenMP
#pragma omp critical
#endif
	  {
	    OpenMP_parallelization_disabled ();

	    MPI_parallelization_disabled ();
	  }
	  
	  const string PSI_Berggren_basis_state_string           = file_name_intrinsic_CM_cluster_string ("Berggren_basis_state"           , cluster , NCM_HO , LCM , J_cluster , M_cluster);
	  const string PSI_Berggren_basis_state_dimension_string = file_name_intrinsic_CM_cluster_string ("Berggren_basis_state_dimension" , cluster , NCM_HO , LCM , J_cluster , M_cluster);

	  const class GSM_vector &GSM_vector_NCM_HO_LCM_Berggren_basis = GSM_vector_NCM_HO_LCM_Berggren_basis_tab(NCM_HO);			
	  
	  GSM_vector_NCM_HO_LCM_Berggren_basis.space_dimension_SDs_components_copy_disk (false , false , PSI_Berggren_basis_state_dimension_string , PSI_Berggren_basis_state_string);

	  if (two_M_cluster != 0)
	    {
	      class GSM_vector &GSM_vector_NCM_HO_LCM_Berggren_basis_TRS = GSM_vector_NCM_HO_LCM_Berggren_basis_TRS_tab(NCM_HO);

	      class GSM_vector_helper_class &GSM_vector_NCM_HO_LCM_Berggren_basis_helper = GSM_vector_NCM_HO_LCM_Berggren_basis.get_GSM_vector_helper ();

	      class GSM_vector_helper_class &GSM_vector_NCM_HO_LCM_Berggren_basis_TRS_helper = GSM_vector_NCM_HO_LCM_Berggren_basis_TRS.get_GSM_vector_helper ();

	      const class TRS_class TRS(GSM_vector_NCM_HO_LCM_Berggren_basis_helper , GSM_vector_NCM_HO_LCM_Berggren_basis_TRS_helper);
 
	      GSM_vector_NCM_HO_LCM_Berggren_basis_TRS = minus_one_pow (J_cluster - M_cluster)*TRS (GSM_vector_NCM_HO_LCM_Berggren_basis);

	      const string PSI_TRS_string           = file_name_intrinsic_CM_cluster_string ("Berggren_basis_state"           , cluster , NCM_HO , LCM , J_cluster , -M_cluster);
	      const string PSI_TRS_dimension_string = file_name_intrinsic_CM_cluster_string ("Berggren_basis_state_dimension" , cluster , NCM_HO , LCM , J_cluster , -M_cluster);

	      GSM_vector_NCM_HO_LCM_Berggren_basis_TRS.space_dimension_SDs_components_copy_disk (false , false , PSI_TRS_dimension_string , PSI_TRS_string);
	    }
	}	
    }
  
  OpenMP_parallelization_enabled ();

  MPI_parallelization_enabled ();
}

void cluster_CM_intrinsic_basis_states::Berggren_basis_states_calc_store (
									  const bool is_there_cout , 
									  const class input_data_str &input_data , 
									  const class array<int> &nmax_HO_lab_tab , 
									  class cluster_data &data)
{
  const enum interaction_type inter = input_data.get_inter ();

  class nucleons_data &cluster_prot_data_HO = data.get_cluster_prot_data_HO  ();
  class nucleons_data &cluster_neut_data_HO = data.get_cluster_neut_data_HO ();
  
  class nucleons_data &cluster_prot_data = data.get_cluster_prot_data ();
  class nucleons_data &cluster_neut_data = data.get_cluster_neut_data ();

  const int E_relative_max_hw = input_data.get_E_relative_max_hw ();

  const int E_min_hw_HO = cluster_prot_data_HO.get_E_min_hw () + cluster_neut_data_HO.get_E_min_hw ();
  const int E_min_hw = cluster_prot_data.get_E_min_hw () + cluster_neut_data.get_E_min_hw ();

  const int Z_cluster = cluster_prot_data_HO.get_N_nucleons ();
  const int N_cluster = cluster_neut_data_HO.get_N_nucleons ();
  const int A_cluster = data.get_A_cluster ();

  const int LCM_max_all = data.get_Lmax ();
  
  const enum space_type space = space_determine (Z_cluster , N_cluster);
  
  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const bool are_two_body_clusters_stored_in_J_scheme = input_data.get_are_two_body_clusters_stored_in_J_scheme ();

  const int n_holes_max_p_HO = cluster_prot_data_HO.get_n_holes_max ();
  const int n_holes_max_n_HO = cluster_neut_data_HO.get_n_holes_max ();

  const int n_holes_max_HO = n_holes_max_p_HO + n_holes_max_n_HO;
  
  const int n_scat_max_p_HO = cluster_prot_data_HO.get_n_scat_max ();
  const int n_scat_max_n_HO = cluster_neut_data_HO.get_n_scat_max ();

  const int n_scat_max_HO = n_scat_max_p_HO + n_scat_max_n_HO;
  
  const int Ep_max_hw_HO = cluster_prot_data_HO.get_E_max_hw ();
  const int En_max_hw_HO = cluster_neut_data_HO.get_E_max_hw ();

  const int E_max_hw_HO = E_relative_max_hw + E_min_hw_HO;

  const int Ep_max_hw = cluster_prot_data.get_E_max_hw ();
  const int En_max_hw = cluster_neut_data.get_E_max_hw ();

  const int E_max_hw = E_relative_max_hw + E_min_hw;

  const int n_holes_max_p = cluster_prot_data.get_n_holes_max ();
  const int n_holes_max_n = cluster_neut_data.get_n_holes_max ();

  const int n_holes_max = n_holes_max_p + n_holes_max_n;
  
  const int n_scat_max_p = cluster_prot_data.get_n_scat_max ();
  const int n_scat_max_n = cluster_neut_data.get_n_scat_max ();

  const int n_scat_max = n_scat_max_p + n_scat_max_n;
  
  const enum particle_type cluster = data.get_cluster ();

  const double J_intrinsic = data.get_J_intrinsic ();
  
  const double Jmin_cluster_all = (A_cluster%2 == 0) ? (0.0) : (0.5);
  const double Jmax_cluster_all = J_intrinsic + LCM_max_all;
  
  const unsigned int BP_intrinsic = data.get_BP_intrinsic ();
  
  const int J_cluster_number_max = make_int (Jmax_cluster_all - Jmin_cluster_all) + 1;
  const int M_cluster_number_max = J_cluster_number_max;
  
  const class array<int> &Nmax_HO_tab = data.get_Nmax_HO_tab ();	
  
  class GSM_vector PSI_full;
  
  for (unsigned int BP_cluster = 0 ; BP_cluster <= 1 ; BP_cluster++)
    for (int iM_cluster = 0 ; iM_cluster < M_cluster_number_max ; iM_cluster++)
      {
	// cluster_HO_to_Berggren is used without MPI parallelization.
	// No race condition can occur here. 
	// Indeed , OpenMP parallelization is not explicitly used in the Berggren_basis_states_calc_store routine (here) 
	// and in the called routines.

	const double M_cluster = Jmin_cluster_all + iM_cluster;

	const double Mp1_cluster = M_cluster + 1;

	const int two_M_cluster = make_int (2.0*M_cluster);

	class GSM_vector_helper_class GSM_vector_helper_HO_in_M(false , space , inter , false , truncation_hw , truncation_ph , 
								n_holes_max_HO   , n_scat_max_HO   , E_max_hw_HO  ,
								n_holes_max_p_HO , n_scat_max_p_HO , Ep_max_hw_HO ,
								n_holes_max_n_HO , n_scat_max_n_HO , En_max_hw_HO , 
								BP_cluster , M_cluster , true , cluster_prot_data_HO , cluster_neut_data_HO);

	class GSM_vector_helper_class GSM_vector_helper_out_M(false , space , inter , false , truncation_hw , truncation_ph ,
							      n_holes_max   , n_scat_max   , E_max_hw  ,
							      n_holes_max_p , n_scat_max_p , Ep_max_hw ,
							      n_holes_max_n , n_scat_max_n , En_max_hw ,
							      BP_cluster , M_cluster , true , cluster_prot_data , cluster_neut_data);
	
	class GSM_vector_helper_class GSM_vector_helper_out_Mp1(false , space , inter , false , truncation_hw , truncation_ph , 
								n_holes_max   , n_scat_max   , E_max_hw  ,
								n_holes_max_p , n_scat_max_p , Ep_max_hw ,
								n_holes_max_n , n_scat_max_n , En_max_hw ,
								BP_cluster , Mp1_cluster , true , cluster_prot_data , cluster_neut_data);
	
	class GSM_vector_helper_class GSM_vector_helper_out_TRS_M(false , space , inter , false , truncation_hw , truncation_ph , 
								  n_holes_max   , n_scat_max   , E_max_hw  ,
								  n_holes_max_p , n_scat_max_p , Ep_max_hw ,
								  n_holes_max_n , n_scat_max_n , En_max_hw ,
								  BP_cluster , -M_cluster , true , cluster_prot_data , cluster_neut_data);

	configuration_SD_in_in_space_determine  (false , GSM_vector_helper_HO_in_M , GSM_vector_helper_out_Mp1 , cluster_prot_data_HO , cluster_neut_data_HO);		
	configuration_SD_out_in_space_determine (false , GSM_vector_helper_out_M   , GSM_vector_helper_out_Mp1 , cluster_prot_data    , cluster_neut_data);
  
	if (Z_cluster > 0) cluster_SD_HO_Berggren_overlaps::tables_allocated_built (false , truncation_hw , truncation_ph , nmax_HO_lab_tab , cluster , cluster_prot_data_HO , cluster_prot_data);
	if (N_cluster > 0) cluster_SD_HO_Berggren_overlaps::tables_allocated_built (false , truncation_hw , truncation_ph , nmax_HO_lab_tab , cluster , cluster_neut_data_HO , cluster_neut_data);

	class GSM_vector PSI0_M(GSM_vector_helper_out_M);
	class GSM_vector PSI1_M(GSM_vector_helper_out_M);

	class GSM_vector Vstore(GSM_vector_helper_out_M);

	class GSM_vector PSI0_Mp1(GSM_vector_helper_out_Mp1);
	class GSM_vector PSI1_Mp1(GSM_vector_helper_out_Mp1);
	class GSM_vector PSI2_Mp1(GSM_vector_helper_out_Mp1);
  
	const class Jpm_class Jplus(false  , false ,  1 , Hamiltonian_storage , true , GSM_vector_helper_out_M   , GSM_vector_helper_out_Mp1 , PSI_full , PSI0_Mp1 , PSI1_Mp1);
	const class Jpm_class Jminus(false , false , -1 , Hamiltonian_storage , true , GSM_vector_helper_out_Mp1 , GSM_vector_helper_out_M   , PSI_full , PSI0_M   , PSI1_M);
	
	const class J2_class J2(Jplus , Jminus , PSI2_Mp1);
 
	class cluster_HO_to_Berggren_class cluster_HO_to_Berggren(false , Hamiltonian_storage , M_cluster , data , GSM_vector_helper_HO_in_M , GSM_vector_helper_out_M);

	for (int LCM = 0 ; LCM <= LCM_max_all ; LCM++)
	  {
	    const unsigned int BP_CM = binary_parity_from_orbital_angular_momentum (LCM);

	    if (binary_parity_product (BP_intrinsic , BP_CM) == BP_cluster)
	      {
		const double Jmin_cluster = max (M_cluster , abs (J_intrinsic - LCM));

		const double Jmax_cluster = J_intrinsic + LCM;

		const int J_cluster_number = make_int (Jmax_cluster - Jmin_cluster) + 1;

		const int NCM_HO_max_LCM = Nmax_HO_tab(LCM);

		const int NCM_HO_max_LCM_plus_one = NCM_HO_max_LCM + 1;
		
		class array<class GSM_vector> GSM_vector_NCM_HO_LCM_HO_basis_tab(NCM_HO_max_LCM_plus_one);
		class array<class GSM_vector> GSM_vector_NCM_HO_LCM_Berggren_basis_tab(NCM_HO_max_LCM_plus_one);
		class array<class GSM_vector> GSM_vector_NCM_HO_LCM_Berggren_basis_TRS_tab(NCM_HO_max_LCM_plus_one);

		const int first_NCM_HO = basic_first_index_determine_for_MPI (NCM_HO_max_LCM_plus_one , NUMBER_OF_PROCESSES , THIS_PROCESS);
		const int last_NCM_HO = basic_last_index_determine_for_MPI (NCM_HO_max_LCM_plus_one , NUMBER_OF_PROCESSES , THIS_PROCESS);

		for (int NCM_HO = 0 ; NCM_HO <= NCM_HO_max_LCM ; NCM_HO++)
		  {
		    if ((NCM_HO >= first_NCM_HO) && (NCM_HO <= last_NCM_HO))
		      {
			class GSM_vector &GSM_vector_NCM_HO_LCM_HO_basis = GSM_vector_NCM_HO_LCM_HO_basis_tab(NCM_HO);
			
			class GSM_vector &GSM_vector_NCM_HO_LCM_Berggren_basis = GSM_vector_NCM_HO_LCM_Berggren_basis_tab(NCM_HO);

			GSM_vector_NCM_HO_LCM_HO_basis.allocate (GSM_vector_helper_HO_in_M);
			
			GSM_vector_NCM_HO_LCM_Berggren_basis.allocate (GSM_vector_helper_out_M);

			if (two_M_cluster != 0)
			  {
			    class GSM_vector &GSM_vector_NCM_HO_LCM_Berggren_basis_TRS = GSM_vector_NCM_HO_LCM_Berggren_basis_TRS_tab(NCM_HO);

			    GSM_vector_NCM_HO_LCM_Berggren_basis_TRS.allocate (GSM_vector_helper_out_TRS_M);
			  }
		      }
		  }

		for (int iJ_cluster = 0 ; iJ_cluster < J_cluster_number ; iJ_cluster++)
		  {
		    const double J_cluster = Jmin_cluster + iJ_cluster;

		    cluster_HO_to_Berggren.set_J (J_cluster);
	
		    GSM_vector_NCM_HO_LCM_HO_basis_tab_read (are_two_body_clusters_stored_in_J_scheme , data , LCM , J_cluster , M_cluster , GSM_vector_NCM_HO_LCM_HO_basis_tab);

		    GSM_vector_NCM_HO_LCM_Berggren_basis_tab_calc (data , LCM , J_cluster , J2 , cluster_HO_to_Berggren , GSM_vector_NCM_HO_LCM_HO_basis_tab , Vstore , GSM_vector_NCM_HO_LCM_Berggren_basis_tab);

		    GSM_vector_NCM_HO_LCM_Berggren_basis_tab_store (data , LCM , J_cluster , M_cluster , GSM_vector_NCM_HO_LCM_Berggren_basis_TRS_tab , GSM_vector_NCM_HO_LCM_Berggren_basis_tab);
		  }						
	      }
	  }
      }

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << "J-coupled HO to Berggren cluster states calculated and stored for " << cluster << endl;
}








