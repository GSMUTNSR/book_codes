#include "../GSM_include/GSM_include_def.h"

using namespace string_routines;
using namespace correlated_state_routines;

// MPI transfer is done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

// TYPE is double or complex
// -------------------------

// Calculation of spectroscopic factor 
// -----------------------------------
// See called routines for details in GSM_overlap_function_...cpp files.

void overlap_function::calc (
			     const bool full_common_vectors_used_in_file ,
			     const enum spectroscopic_factor_type SF , 
			     const enum nucleus_type nucleus , 
			     const enum particle_type cluster , 
			     const double b_HO , 
			     const int NCM_HO_max_projectile , 
			     const class ljm_struct &LJM_projectile , 
			     const bool is_it_Gauss_Legendre ,
			     const class correlated_state_str &PSI_IN_qn , 
			     const class correlated_state_str &PSI_OUT_qn , 
			     const class correlated_state_str &PSI_projectile_qn , 
			     const class GSM_vector &PSI_OUT , 
			     const class array<double> &r_tab , 
			     class array<TYPE> &overlap_function_tab)
{
  overlap_function_tab = 0.0;

  
  switch (nucleus)
    {
    case CLUSTER:
      {
	switch (SF)
	  {
	  case STRIPPING:
	    cluster::stripping_calc (full_common_vectors_used_in_file , cluster , b_HO , NCM_HO_max_projectile , LJM_projectile , is_it_Gauss_Legendre ,
				     PSI_IN_qn , PSI_OUT_qn , PSI_projectile_qn , PSI_OUT , r_tab , overlap_function_tab); break;
	    
	  case PICK_UP:
	    cluster::pick_up_calc   (full_common_vectors_used_in_file , cluster , b_HO , NCM_HO_max_projectile , LJM_projectile , is_it_Gauss_Legendre ,
				     PSI_IN_qn , PSI_OUT_qn , PSI_projectile_qn , PSI_OUT , r_tab , overlap_function_tab); break;
	  default: abort_all ();
	  }
      } break;

    case NUCLEON:
      {				   
	switch (SF)
	  {
	  case STRIPPING: one_nucleon::stripping_calc (full_common_vectors_used_in_file , cluster , LJM_projectile , is_it_Gauss_Legendre , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , overlap_function_tab); break;
	  case PICK_UP:   one_nucleon::pick_up_calc   (full_common_vectors_used_in_file , cluster , LJM_projectile , is_it_Gauss_Legendre , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , overlap_function_tab); break;
	  default: abort_all ();
	  }
      } break;

    default: error_message_print_abort ("Only nucleon or cluster in overlap_function::calc : " + make_string<enum nucleus_type> (nucleus));
    }
}







// Calculation and print of all overlap functions demanded in the input file
// -------------------------------------------------------------------------
// Eigenvectors are read from disk and overlap functions are calculated and stored in a file.
// See called routines for details in GSM_overlap_function_...cpp files.
// One calls the nucleon projectile here, even though it is called ejectile afterwards for pick-up reactions.
//
// The overlap function is stored in disk in a file whose name looks like "overlap_function_0+_0_3I2-_0_p3I2.dat" (in eigenvector, out eigenvector, projectile partial wave)

void overlap_function::calc_store (
				   const class input_data_str &input_data , 
				   const class array<class correlated_state_str> &PSI_qn_tab ,
				   class nucleons_data &prot_data , 
				   class nucleons_data &neut_data) 
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Overlap transitions" << endl;
      cout <<         "-------------------" << endl << endl;
    }

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const int Z_OUT = prot_data.get_N_nucleons ();
  const int N_OUT = neut_data.get_N_nucleons ();
  
  const int n_holes_max_p = prot_data.get_n_holes_max ();
  const int n_holes_max_n = neut_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_data.get_n_scat_max ();
  const int n_scat_max_n = neut_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_data.get_E_max_hw ();
  const int En_max_hw = neut_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();
  
  const double b_HO = input_data.get_b_lab ();
  
  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
  
  const unsigned int overlap_function_number = input_data.get_overlap_function_number ();

  const class array<enum spectroscopic_factor_type> &overlap_function_type_tab = input_data.get_overlap_function_type_tab ();

  const class array<enum nucleus_type> &overlap_function_nucleus_projectile_tab = input_data.get_overlap_function_nucleus_projectile_tab ();

  const class array<enum particle_type> &overlap_function_cluster_projectile_tab = input_data.get_overlap_function_cluster_projectile_tab ();

  const class array<bool> &overlap_function_is_it_Gauss_Legendre_tab = input_data.get_overlap_function_is_it_Gauss_Legendre_tab ();
  
  const class array<int> &overlap_function_Z_projectile_tab = input_data.get_overlap_function_Z_projectile_tab ();
  const class array<int> &overlap_function_N_projectile_tab = input_data.get_overlap_function_N_projectile_tab ();

  const class array<int> &overlap_function_LCM_projectile_tab = input_data.get_overlap_function_LCM_projectile_tab ();

  const class array<int> &overlap_function_NCM_HO_max_projectile_tab = input_data.get_overlap_function_NCM_HO_max_projectile_tab ();
  
  const class array<unsigned int> &overlap_function_BP_IN_tab  = input_data.get_overlap_function_BP_IN_tab ();
  const class array<unsigned int> &overlap_function_BP_OUT_tab = input_data.get_overlap_function_BP_OUT_tab ();

  const class array<unsigned int> &overlap_function_BP_projectile_tab = input_data.get_overlap_function_BP_projectile_tab ();
  
  const class array<double> &overlap_function_J_IN_tab  = input_data.get_overlap_function_J_IN_tab ();
  const class array<double> &overlap_function_J_OUT_tab = input_data.get_overlap_function_J_OUT_tab ();

  const class array<double> &overlap_function_J_projectile_tab = input_data.get_overlap_function_J_projectile_tab ();
  
  const class array<unsigned int> &overlap_function_vector_index_IN_tab  = input_data.get_overlap_function_vector_index_IN_tab ();
  const class array<unsigned int> &overlap_function_vector_index_OUT_tab = input_data.get_overlap_function_vector_index_OUT_tab (); 

  const class array<unsigned int> &overlap_function_vector_index_projectile_tab = input_data.get_overlap_function_vector_index_projectile_tab ();
  
  const unsigned int N_bef_R_GL = input_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = input_data.get_N_bef_R_uniform ();

  const double R = input_data.get_R ();

  const double step_bef_R_uniform = input_data.get_step_bef_R_uniform ();

  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);
  
  class array<double> r_bef_R_tab_uniform(N_bef_R_uniform);
  
  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;
  
  for (unsigned int overlap_function_index = 0 ; overlap_function_index < overlap_function_number ; overlap_function_index++)
    {
      const enum spectroscopic_factor_type SF = overlap_function_type_tab(overlap_function_index);

      const enum nucleus_type nucleus = overlap_function_nucleus_projectile_tab(overlap_function_index);

      const enum particle_type cluster = overlap_function_cluster_projectile_tab(overlap_function_index);      

      const bool is_it_Gauss_Legendre = overlap_function_is_it_Gauss_Legendre_tab(overlap_function_index);
      
      const int Z_projectile = overlap_function_Z_projectile_tab(overlap_function_index);
      const int N_projectile = overlap_function_N_projectile_tab(overlap_function_index);

      const int LCM_projectile = overlap_function_LCM_projectile_tab(overlap_function_index);

      const int NCM_HO_max_projectile = overlap_function_NCM_HO_max_projectile_tab(overlap_function_index);
      
      const unsigned int BP_IN  = overlap_function_BP_IN_tab(overlap_function_index);
      const unsigned int BP_OUT = overlap_function_BP_OUT_tab(overlap_function_index);

      const unsigned int BP_projectile = overlap_function_BP_projectile_tab(overlap_function_index);
      
      const unsigned int vector_index_IN  = overlap_function_vector_index_IN_tab(overlap_function_index);
      const unsigned int vector_index_OUT = overlap_function_vector_index_OUT_tab(overlap_function_index);

      const unsigned int vector_index_projectile = overlap_function_vector_index_projectile_tab(overlap_function_index);

      const double J_IN  = overlap_function_J_IN_tab(overlap_function_index);
      const double J_OUT = overlap_function_J_OUT_tab(overlap_function_index);

      const double J_projectile = overlap_function_J_projectile_tab(overlap_function_index);
      
      const double M_IN  = J_IN;
      const double M_OUT = J_OUT;

      const double M_projectile = spectroscopic_factor_cluster_m_projection_calc (SF , M_IN , M_OUT);
      
      const class ljm_struct LJM_projectile(LCM_projectile , J_projectile , M_projectile , NADA);
      
      const int Z_IN = N_nucleons_IN_spectroscopic_factor_determine (Z_OUT , Z_projectile , SF);
      const int N_IN = N_nucleons_IN_spectroscopic_factor_determine (N_OUT , N_projectile , SF);
      
      const class correlated_state_str PSI_IN_qn(Z_IN , N_IN , BP_IN , J_IN , vector_index_IN , NADA , NADA , NADA , NADA , false);
      
      const class correlated_state_str PSI_OUT_qn = PSI_quantum_numbers_find (Z_OUT , N_OUT , BP_OUT , J_OUT , vector_index_OUT , PSI_qn_tab);
      
      const class correlated_state_str PSI_projectile_qn(Z_projectile , N_projectile , BP_projectile , J_projectile , vector_index_projectile , NADA , NADA , NADA , NADA , false);
    
      class GSM_vector_helper_class PSI_OUT_helper(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
						   n_holes_max   , n_scat_max   , E_max_hw  ,
						   n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						   n_holes_max_n , n_scat_max_n , En_max_hw , BP_OUT , M_OUT , false , prot_data , neut_data);

      class GSM_vector PSI_OUT(PSI_OUT_helper);

      PSI_OUT.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_OUT_qn);
      
      const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
      
      const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (r_bef_R_tab_GL) : (r_bef_R_tab_uniform);
	  
      class array<TYPE> overlap_function_tab(Nr);
	
      calc (full_common_vectors_used_in_file , SF , nucleus , cluster , b_HO , NCM_HO_max_projectile , LJM_projectile , is_it_Gauss_Legendre ,
	    PSI_IN_qn , PSI_OUT_qn , PSI_projectile_qn , PSI_OUT , r_bef_R_tab , overlap_function_tab);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  const string PSI_IN_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_IN_qn);
	  const string PSI_OUT_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_OUT_qn);
	  
	  const string lj = angular_state_for_file_name (LCM_projectile , J_projectile);

	  const string overlap_function_string = "overlap_function_" + PSI_IN_qn_string + "_" + PSI_OUT_qn_string + "_" + make_string<enum particle_type> (cluster) + "_" + lj + ".dat";

	  ofstream overlap_function_file(overlap_function_string.c_str ());

	  overlap_function_file.precision (15);

	  for (unsigned int i = 0 ; i < Nr ; i++)
	    {
	      const double r = r_bef_R_tab(i);
	
#ifdef TYPEisDOUBLECOMPLEX
	      overlap_function_file << r << " " << real (overlap_function_tab(i)) << " " << imag (overlap_function_tab(i)) << endl;
#endif

#ifdef TYPEisDOUBLE
	      overlap_function_file << r << " " << overlap_function_tab(i) << endl;
#endif
	    }

	  switch (SF)
	    {
	    case STRIPPING: cout << "Overlap function " << J_Pi_vector_index_string (BP_IN , J_IN , vector_index_IN) << " + "; break;	      
	    case PICK_UP:   cout << "Overlap function " << J_Pi_vector_index_string (BP_IN , J_IN , vector_index_IN) << " - "; break;
	      
	    default: abort_all ();
	    }

	  cout << angular_state_cluster (cluster , LCM_projectile , J_projectile) << " " << cluster << " --> ";

	  cout << J_Pi_vector_index_string (BP_OUT , J_OUT , vector_index_OUT) << " calculated " << endl << endl;
 	}
    }
}


