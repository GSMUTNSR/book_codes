#include "../GSM_include/GSM_include_def.h"

using namespace EM_transitions_common;
using namespace Wigner_signs;
using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;
using namespace GSM_vector_NBMEs_handling::out_to_in;
using namespace MPI_2D_partitioning;



// TYPE is double or complex
// -------------------------


// EM means electromagnetic
// ------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons
// ------------------------------------------------------------------------------------------------------------------------------------------------------




// Calculation of EM transitions
// -----------------------------
// One calculates here the diagonal and off-diagonal parts of the EM transition <Psi[out] || EM || Psi[in]>,
// equal to \sum_{inSD,outSD} <Psi[out] | outSD> <inSD | Psi[in]> <outSD | EM | inSD>.
// It is separated in diagonal and off-diagonal parts.
// The diagonal part is non-zero only if |Psi[in]> and |Psi[out]> have same parities and M projections.
//
// The non-zero NBMEs are of 0p-0h and 1p-1h type:
// <outSD | EM | inSD> = \sum_i <i | EM |i> if |inSD> = |outSD>.
// <outSD | EM | inSD> = +/- <i' | EM |i> if |inSD> and |outSD> differ by i,i'. The +/- 1 reordering phase is stored in an array.
//
// One separates the proton and neutron parts of <outSD | EM | inSD> in the proton-neutron case.
// One loops over Slater determinants, and one sums over <outSD | EM | inSD> NBMEs multiplied by <Psi[out] | outSD> and <inSD | Psi[in]>.
//
// OpenMP parallelization is used on the loop of proton or neutron Slater determinants. Reduction is done on the EM amplitude at the end of each routine.
// MPI parallelization here is implicit, as on considers only the Slater determinants of the current node. MPI reduction is done at the very end of the calculation.
//
// One calls B_EM_amplitude_from_OBMEs_calc. This routine calls diagonal and off-diagonal parts routines, sums them and reduces if MPI is used.
// One partially uses 1D partitioning here. Hence, all the parts of |Psi[in]> scattered over all nodes are gathered in |Psi[in]-full>, so that all nodes have a full copy of |Psi[in]>.
// Indeed, one would have too many MPI communications otherwise.
// Each node takes care of its part of |Psi[out]>.
// The reduced matrix element <Psi[out] || EM || Psi[in]> is calculated from the full matrix element <Psi[out] | EM | Psi[in]> calculated before with the Wigner-Eckart theorem and returned.
// Only the value borne by the master process is meaningful, as MPI reduction is done only therein.


TYPE EM_transitions_NBMEs::diagonal_part_pp_nn_calc (
						     const class array<TYPE> &OBMEs , 
						     const class Slater_determinant &SD)
{
  const int N_valence_baryons = SD.get_N_valence_baryons ();

  TYPE diagonal_NBME = 0.0;
  
  for (int i = 0 ; i < N_valence_baryons ; i++)
    {
      const unsigned int state = SD[i];
      
      diagonal_NBME += OBMEs(state , state);
    }

  return diagonal_NBME;
}












TYPE EM_transitions_NBMEs::B_EM_amplitude_diagonal_part_pp_nn_calc (
								    const class array<TYPE> &OBMEs , 
								    const class GSM_vector &PSI_IN_full , 
								    const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_IN_full = PSI_IN_full.get_GSM_vector_helper ();

  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
     
  const unsigned int BP_IN = GSM_vector_helper_IN_full.get_BP ();

  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();
  
  const int S_IN = GSM_vector_helper_IN_full.get_S ();

  const int S_OUT = GSM_vector_helper_OUT.get_S ();
  
  const int iM_IN = GSM_vector_helper_IN_full.get_iM ();
  
  const int iM_OUT = GSM_vector_helper_OUT.get_iM ();
  
  if ((BP_IN != BP_OUT) || (iM_IN != iM_OUT) || (S_IN != S_OUT)) return 0.0;
  
  const enum space_type space = GSM_vector_helper_IN_full.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_IN_full.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_IN_full.get_neut_Y_data ();
  
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
      
  const class array_of_SD &SD_set = data.get_SD_set ();
  
  const unsigned long int first_total_PSI_index = GSM_vector_helper_OUT.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper_OUT.get_last_total_PSI_index ();

  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = data.get_SD_quantum_numbers_tab ();

  const unsigned long int total_SD_index_min = GSM_vector_helper_OUT.get_total_SD_index_min ();
  const unsigned long int total_SD_index_max = GSM_vector_helper_OUT.get_total_SD_index_max ();

  if (total_SD_index_min > total_SD_index_max) return 0.0;
    
  class array<class Slater_determinant> SD_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) SD_tab(i).allocate (N_valence_baryons);
  
  double Re_B_EM_amplitude = 0.0;
  double Im_B_EM_amplitude = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_B_EM_amplitude , Im_B_EM_amplitude)
#endif
  for (unsigned long int total_SD_index = total_SD_index_min ; total_SD_index <= total_SD_index_max ; total_SD_index++)
    {
      const class SD_quantum_numbers &SD_qn = SD_quantum_numbers_tab(total_SD_index);

      const unsigned int BP_SD = SD_qn.get_BP ();

      if (BP_SD != BP_OUT) continue;
 
      const int S_SD = SD_qn.get_S ();

      if (S_SD != S_OUT) continue;

      const int iM_SD = SD_qn.get_iM ();

      if (iM_SD != iM_OUT) continue;
      
      const unsigned int n_scat = SD_qn.get_n_scat ();

      const unsigned int iC = SD_qn.get_iC ();

      const int n_holes = n_holes_table(BP_OUT , S_OUT , 0 , n_scat , iC);
      
      const int E_hw = E_hw_table(BP_OUT , S_OUT , 0 , n_scat , iC);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
      
      const unsigned int SD_index = SD_qn.get_SD_index ();

      const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions_GSM_vector_OUT(n_scat , iC);

      const unsigned long int total_PSI_index = sum_dimensions_configuration_fixed + SD_index;

      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
	{
	  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;
            
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  class Slater_determinant &SD = SD_tab(i_thread);
      
	  SD = SD_set(BP_OUT , S_OUT , 0 , n_scat , iC , iM_OUT , SD_index);
      
	  const TYPE diagonal_part = diagonal_part_pp_nn_calc (OBMEs , SD);
      
	  const TYPE &PSI_IN_component = PSI_IN_full[total_PSI_index];

	  const TYPE &PSI_OUT_component = PSI_OUT[PSI_index];

	  const TYPE B_EM_amplitude_part = diagonal_part*PSI_IN_component*PSI_OUT_component;
      
	  Re_B_EM_amplitude += real_dc (B_EM_amplitude_part);
	  Im_B_EM_amplitude += imag_dc (B_EM_amplitude_part);
	}
    }
  
  const TYPE B_EM_amplitude = generate_scalar<TYPE> (Re_B_EM_amplitude , Im_B_EM_amplitude);
	
  return B_EM_amplitude;
}  













TYPE EM_transitions_NBMEs::B_EM_amplitude_one_jump_part_pp_nn_calc (
								    const class array<TYPE> &OBMEs , 
								    const class GSM_vector &PSI_IN_full , 
								    const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_IN_full = PSI_IN_full.get_GSM_vector_helper ();

  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
     
  const enum space_type space = GSM_vector_helper_IN_full.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_IN_full.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_IN_full.get_neut_Y_data ();
  
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);
  
  const unsigned int BP_IN = GSM_vector_helper_IN_full.get_BP ();

  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();
  
  const int S_IN = GSM_vector_helper_IN_full.get_S ();
  
  const int S_OUT = GSM_vector_helper_OUT.get_S ();
  
  if (S_IN != S_OUT) return 0.0;
  
  const unsigned int dimension_1p1h_space_BP_S_iM_fixed_max = data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();

  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int iM_IN = GSM_vector_helper_IN_full.get_iM ();
  
  const int iM_OUT = GSM_vector_helper_OUT.get_iM ();
    
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
      
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper_OUT.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper_OUT.get_last_total_PSI_index ();

  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = data.get_SD_quantum_numbers_tab ();

  const unsigned long int total_outSD_index_min = GSM_vector_helper_OUT.get_total_SD_index_min ();
  const unsigned long int total_outSD_index_max = GSM_vector_helper_OUT.get_total_SD_index_max ();

  if (total_outSD_index_min > total_outSD_index_max) return 0.0;
    
  class array<class jumps_data_out_to_in_str> one_jump_mu_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > NBMEs_jump_mu_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_IN_indices_one_jump_mu_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_mu_tab(i).allocate (ONE_JUMP , space , truncation_hw , truncation_ph , dimension_1p1h_space_BP_S_iM_fixed_max);

      NBMEs_jump_mu_tab(i).allocate (dimension_1p1h_space_BP_S_iM_fixed_max);

      total_PSI_IN_indices_one_jump_mu_tab(i).allocate (dimension_1p1h_space_BP_S_iM_fixed_max);
    }
  
  class array<bool> is_configuration_accepted_tab(dimension_1p1h_space_BP_S_iM_fixed_max);

  is_configuration_accepted_tab = true;

  double Re_B_EM_amplitude = 0.0;
  double Im_B_EM_amplitude = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_B_EM_amplitude , Im_B_EM_amplitude)
#endif
  for (unsigned long int total_outSD_index = total_outSD_index_min ; total_outSD_index <= total_outSD_index_max ; total_outSD_index++)
    {
      const class SD_quantum_numbers &outSD_qn = SD_quantum_numbers_tab(total_outSD_index);

      const unsigned int BP_out = outSD_qn.get_BP ();

      if (BP_out != BP_OUT) continue;
 
      const int S_out = outSD_qn.get_S ();

      if (S_out != S_OUT) continue;

      const int iM_out = outSD_qn.get_iM ();

      if (iM_out != iM_OUT) continue;
      
      const unsigned int n_scat_out = outSD_qn.get_n_scat ();

      const unsigned int iC_out = outSD_qn.get_iC ();

      const int n_holes_out = n_holes_table(BP_out , S_out , 0 , n_scat_out , iC_out);
      
      const int E_out_hw = E_hw_table(BP_out , S_out , 0 , n_scat_out , iC_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
      
      const unsigned int outSD_index = outSD_qn.get_SD_index ();

      const unsigned long int sum_dimensions_configuration_fixed_out = sum_dimensions_GSM_vector_OUT(n_scat_out , iC_out);

      const unsigned long int total_PSI_out_index = sum_dimensions_configuration_fixed_out + outSD_index;
      
      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
	{
	  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
      
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  class jumps_data_out_to_in_str &one_jump_mu = one_jump_mu_tab(i_thread);

	  class array<TYPE> &NBMEs_jump_mu = NBMEs_jump_mu_tab(i_thread);

	  class array<unsigned long int> &total_PSI_IN_indices_one_jump_mu = total_PSI_IN_indices_one_jump_mu_tab(i_thread);

	  TYPE component_part = 0.0;

	  one_jump_mu.one_jump_mu_store (BP_IN , S_IN , 0 , iM_IN , n_holes_max , n_scat_max , E_max_hw , BP_OUT , S_OUT , 0 , n_scat_out , iC_out , iM_OUT , outSD_index , data);

	  const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();

	  if (dimension_one_jump_mu > 0)
	    {
	      bool is_there_one_jump_calc = false;
	  
	      total_PSI_in_indices_pp_nn_fill (one_jump_mu , GSM_vector_helper_IN_full , total_PSI_IN_indices_one_jump_mu , is_there_one_jump_calc);

	      if (is_there_one_jump_calc)
		{
		  NBMEs_one_jump_mu_calc_one_body_operator (OBMEs , one_jump_mu , NBMEs_jump_mu);

		  component_part += component_part_jumps_calc (dimension_one_jump_mu , is_configuration_accepted_tab , total_PSI_IN_indices_one_jump_mu , NBMEs_jump_mu , PSI_IN_full);
		}
	    }

	  const TYPE B_EM_amplitude_part = component_part*PSI_OUT[PSI_out_index];
	      
	  Re_B_EM_amplitude += real_dc (B_EM_amplitude_part);
	  Im_B_EM_amplitude += imag_dc (B_EM_amplitude_part);
	}
    }
  
  const TYPE B_EM_amplitude = generate_scalar<TYPE> (Re_B_EM_amplitude , Im_B_EM_amplitude);
	
  return B_EM_amplitude;
}  













TYPE EM_transitions_NBMEs::B_EM_amplitude_diagonal_part_pn_p_part_calc (
									const class array<TYPE> &OBMEs_p , 
									const class GSM_vector &PSI_IN_full , 
									const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_IN_full = PSI_IN_full.get_GSM_vector_helper ();

  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
   
  const unsigned int BP_IN = GSM_vector_helper_IN_full.get_BP ();

  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();
  
  const int S_IN = GSM_vector_helper_IN_full.get_S ();

  const int S_OUT = GSM_vector_helper_OUT.get_S ();
  
  const int iM_IN = GSM_vector_helper_IN_full.get_iM ();

  const int iM_OUT = GSM_vector_helper_OUT.get_iM ();
  
  if ((BP_IN != BP_OUT) || (iM_IN != iM_OUT) || (S_IN != S_OUT)) return 0.0;

  const class baryons_data &prot_Y_data = GSM_vector_helper_IN_full.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_IN_full.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const int n_spec_max = prot_Y_data.get_n_spec_max ();
  
  const bool truncation_hw = GSM_vector_helper_IN_full.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_IN_full.get_truncation_ph ();
    
  const int iMp_min_M = GSM_vector_helper_OUT.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper_OUT.get_iMp_max_M ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
    
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper_OUT.get_all_dimensions_SDn_zero_tab ();
  
  const unsigned long int first_total_PSI_index = GSM_vector_helper_OUT.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper_OUT.get_last_total_PSI_index ();
  
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper_OUT.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper_OUT.get_iCn_max_process_tab ();
  
  const unsigned long int total_SDp_index_min = GSM_vector_helper_OUT.get_total_SDp_index_min ();
  const unsigned long int total_SDp_index_max = GSM_vector_helper_OUT.get_total_SDp_index_max ();
  
  if (total_SDp_index_min > total_SDp_index_max) return 0.0;
  
  class array<class Slater_determinant> SDp_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) SDp_tab(i).allocate (ZYval);
  
  double Re_B_EM_amplitude = 0.0;
  double Im_B_EM_amplitude = 0.0;


#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_B_EM_amplitude , Im_B_EM_amplitude)
#endif
  for (unsigned long int total_SDp_index = total_SDp_index_min ; total_SDp_index <= total_SDp_index_max ; total_SDp_index++)
    {
      const class SD_quantum_numbers &SDp_qn = SDp_quantum_numbers_tab(total_SDp_index);

      const int iMp = SDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = SDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP_OUT);

      const int Sp = SDp_qn.get_S ();

      const int Sn = S_OUT - Sp;
      
      const int n_spec_p = SDp_qn.get_n_spec ();

      const int n_spec_n = n_spec_max - n_spec_p;
      
      const int n_scat_p = SDp_qn.get_n_scat ();
	
      const unsigned int iCp = SDp_qn.get_iC ();

      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (dimension_SDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (all_dimensions_SDn_zero) continue;
	      
      const int iMn = iM_OUT - iMp;
      
      const unsigned int SDp_index = SDp_qn.get_SD_index ();
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class Slater_determinant &SDp = SDp_tab(i_thread);
            
      bool is_p_diagonal_part_calculated = false;
		      
      TYPE p_diagonal_part = 0.0;
      
      SDp = SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index);
      
      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
	  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
	  
	  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
	      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

	      if (dimension_SDn == 0) continue;

	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector_OUT(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);
	      
	      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;

	      const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDn_minus_one;
  
	      if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
		{
		  if (!is_p_diagonal_part_calculated)
		    {
		      p_diagonal_part = diagonal_part_pp_nn_calc (OBMEs_p , SDp);
					  
		      is_p_diagonal_part_calculated = true;
		    }
				      
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      const unsigned long int total_PSI_index = total_PSI_index_zero + SDn_index;
					  
		      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
			{
			  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;
					      
			  const TYPE &PSI_IN_component = PSI_IN_full[total_PSI_index];
			  
			  const TYPE component_part = PSI_IN_component*p_diagonal_part;
					      
			  const TYPE B_EM_amplitude_part = component_part*PSI_OUT[PSI_index];
					      
			  Re_B_EM_amplitude += real_dc (B_EM_amplitude_part);
			  Im_B_EM_amplitude += imag_dc (B_EM_amplitude_part);
					      
			}}}}}}

  const TYPE B_EM_amplitude = generate_scalar<TYPE> (Re_B_EM_amplitude , Im_B_EM_amplitude);
	
  return B_EM_amplitude;
}  





TYPE EM_transitions_NBMEs::B_EM_amplitude_diagonal_part_pn_n_part_calc (
									const class array<TYPE> &OBMEs_n , 
									const class GSM_vector &PSI_IN_full , 
									const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_IN_full = PSI_IN_full.get_GSM_vector_helper ();

  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
   
  const unsigned int BP_IN = GSM_vector_helper_IN_full.get_BP ();

  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();
  
  const int S_IN = GSM_vector_helper_IN_full.get_S ();
  
  const int S_OUT = GSM_vector_helper_OUT.get_S ();
  
  const int iM_IN = GSM_vector_helper_IN_full.get_iM ();

  const int iM_OUT = GSM_vector_helper_OUT.get_iM ();

  if ((iM_IN != iM_OUT) || (BP_IN != BP_OUT) || (S_IN != S_OUT)) return 0.0;

  const class baryons_data &prot_Y_data = GSM_vector_helper_IN_full.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_IN_full.get_neut_Y_data ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int n_spec_max = prot_Y_data.get_n_spec_max ();
  
  const bool truncation_hw = GSM_vector_helper_IN_full.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_IN_full.get_truncation_ph ();
  
  const int iMn_min_M = GSM_vector_helper_OUT.get_iMn_min_M ();
  const int iMn_max_M = GSM_vector_helper_OUT.get_iMn_max_M ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
    
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
    
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper_OUT.get_all_dimensions_SDp_zero_tab ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const unsigned long int first_total_PSI_index = GSM_vector_helper_OUT.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper_OUT.get_last_total_PSI_index ();
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper_OUT.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper_OUT.get_iCp_max_process_tab ();
  
  const unsigned long int total_SDn_index_min = GSM_vector_helper_OUT.get_total_SDn_index_min ();
  const unsigned long int total_SDn_index_max = GSM_vector_helper_OUT.get_total_SDn_index_max ();
  
  if (total_SDn_index_min > total_SDn_index_max) return 0.0;
   
  class array<class Slater_determinant> SDn_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) SDn_tab(i).allocate (NYval);
  
  double Re_B_EM_amplitude = 0.0;
  double Im_B_EM_amplitude = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_B_EM_amplitude , Im_B_EM_amplitude)
#endif
  for (unsigned long int total_SDn_index = total_SDn_index_min ; total_SDn_index <= total_SDn_index_max ; total_SDn_index++)
    {
      const class SD_quantum_numbers &SDn_qn = SDn_quantum_numbers_tab(total_SDn_index);

      const int iMn = SDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = SDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP_OUT);

      const int Sn = SDn_qn.get_S ();

      const int Sp = S_OUT - Sn;
      
      const int n_spec_n = SDn_qn.get_n_spec ();

      const int n_spec_p = n_spec_max - n_spec_n;
      
      const int n_scat_n = SDn_qn.get_n_scat ();
	
      const unsigned int iCn = SDn_qn.get_iC ();

      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (dimension_SDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (all_dimensions_SDp_zero) continue;
            
      const unsigned int SDn_index = SDn_qn.get_SD_index ();
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class Slater_determinant &SDn = SDn_tab(i_thread);
      
      const int iMp = iM_OUT - iMn;
      
      bool is_n_diagonal_part_calculated = false;
      
      TYPE n_diagonal_part = 0.0;
      
      SDn = SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index);
      
      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  
	  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

	      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
	      
	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
	      
	      if (dimension_SDp == 0) continue;
	      
	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector_OUT(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

	      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + SDn_index;

	      const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDn*dimension_SDp_minus_one;
					  
	      if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
		{
		  if (!is_n_diagonal_part_calculated)
		    {
		      n_diagonal_part = diagonal_part_pp_nn_calc (OBMEs_n , SDn);
						  
		      is_n_diagonal_part_calculated = true;
		    }
					      
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      const unsigned long int total_PSI_index = total_PSI_index_zero + dimension_SDn*SDp_index;
					  
		      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
			{
			  const unsigned int PSI_index = total_PSI_index - first_total_PSI_index;
					      					      
			  const TYPE &PSI_IN_component = PSI_IN_full[total_PSI_index];

			  const TYPE component_part = PSI_IN_component*n_diagonal_part;
					      
			  const TYPE B_EM_amplitude_part = component_part*PSI_OUT[PSI_index];
					      
			  Re_B_EM_amplitude += real_dc (B_EM_amplitude_part);
			  Im_B_EM_amplitude += imag_dc (B_EM_amplitude_part);
					      
			}}}}}}

  const TYPE B_EM_amplitude = generate_scalar<TYPE> (Re_B_EM_amplitude , Im_B_EM_amplitude);
  
  return B_EM_amplitude;
}  






TYPE EM_transitions_NBMEs::B_EM_amplitude_one_jump_p_pn_calc (
							      const unsigned int BP_Op , 
							      const class array<TYPE> &OBMEs_p , 
							      const class GSM_vector &PSI_IN_full , 
							      const class GSM_vector &PSI_OUT)
{  
  const class GSM_vector_helper_class &GSM_vector_helper_IN_full = PSI_IN_full.get_GSM_vector_helper ();
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
   
  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();
  
  const int S_IN = GSM_vector_helper_IN_full.get_S ();
  
  const int S_OUT = GSM_vector_helper_OUT.get_S ();
  
  if (S_IN != S_OUT) return 0.0;
  
  const int iM_IN = GSM_vector_helper_IN_full.get_iM ();

  const int iM_OUT = GSM_vector_helper_OUT.get_iM ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_IN_full.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_IN_full.get_neut_Y_data ();
  
  const int n_spec_max = prot_Y_data.get_n_spec_max ();
  
  const bool truncation_hw = GSM_vector_helper_IN_full.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_IN_full.get_truncation_ph ();
  
  const int ML = iM_OUT - iM_IN;
  
  const int iMp_min_M = GSM_vector_helper_OUT.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper_OUT.get_iMp_max_M ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
    
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
    
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper_OUT.get_all_dimensions_SDn_zero_tab ();
  
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper_OUT.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper_OUT.get_last_total_PSI_index ();
  
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_process_tab = GSM_vector_helper_OUT.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_out_max_process_tab = GSM_vector_helper_OUT.get_iCn_max_process_tab ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper_OUT.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper_OUT.get_total_SDp_index_max ();

  if (total_outSDp_index_min > total_outSDp_index_max) return 0.0;
   
  class array<class jumps_data_out_to_in_str> one_jump_p_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > NBMEs_jump_p_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_configuration_accepted_one_jump_p_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_IN_indices_one_jump_p_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {  
      one_jump_p_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);

      NBMEs_jump_p_tab(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);

      is_configuration_accepted_one_jump_p_tabs(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);

      total_PSI_IN_indices_one_jump_p_tab(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);
    }

  double Re_B_EM_amplitude = 0.0;
  double Im_B_EM_amplitude = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_B_EM_amplitude , Im_B_EM_amplitude)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();
      
      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();

      const unsigned int BPn_out = binary_parity_product (BPp_out , BP_OUT);

      const unsigned int BPp_in = binary_parity_product (BPp_out , BP_Op);

      const int Sp_out = outSDp_qn.get_S ();

      const int Sn_out = S_OUT - Sp_out;

      const int Sp_in = Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();

      const int n_spec_n_out = n_spec_max - n_spec_p_out;

      const int n_spec_p_in = n_spec_p_out;
      
      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;
		  
      const int iMn_out = iM_OUT - iMp_out;

      const int iMp_in = iMp_out - ML;
      const int iMn_in = iMn_out - ML;
      
      const int Delta_iMp_in = two_mp_max - iMp_out + iMp_in;
      const int Delta_iMn_in = two_mn_max - iMn_out + iMn_in;
		  
      if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
      if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();
		  
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(i_thread);

      class array<TYPE> &NBMEs_jump_p = NBMEs_jump_p_tab(i_thread);

      class array<bool> &is_configuration_accepted_one_jump_p_tab = is_configuration_accepted_one_jump_p_tabs(i_thread);

      class array<unsigned long int> &total_PSI_IN_indices_one_jump_p = total_PSI_IN_indices_one_jump_p_tab(i_thread);

      bool one_jump_p_calculated = false;

      bool is_there_one_jump_calc_all = true;
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_process_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
			  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);
	      
	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  if (!one_jump_p_calculated)
		    {
		      one_jump_p.one_jump_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , prot_Y_data);

		      one_jump_p_calculated = true;
					  
		      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();

		      is_there_one_jump_calc_all = (dimension_one_jump_p > 0);
					  
		      if (is_there_one_jump_calc_all) NBMEs_one_jump_mu_calc_one_body_operator (OBMEs_p , one_jump_p , NBMEs_jump_p);
		    }
				      
		  if (!is_there_one_jump_calc_all) continue;

		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDn_index;

		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;

			  bool is_there_one_jump_calc = false;
						  
			  is_configuration_accepted_total_PSI_in_indices_p_fill (BPn_out , Sn_out , n_spec_n_out , n_holes_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , En_hw_out , one_jump_p , GSM_vector_helper_IN_full ,
										 dimension_outSDn , is_configuration_accepted_one_jump_p_tab , total_PSI_IN_indices_one_jump_p , is_there_one_jump_calc);

			  if (is_there_one_jump_calc)
			    {
			      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
		      
			      const TYPE component_part = component_part_jumps_calc (dimension_one_jump_p , is_configuration_accepted_one_jump_p_tab , total_PSI_IN_indices_one_jump_p , NBMEs_jump_p , PSI_IN_full);
					      
			      const TYPE B_EM_amplitude_part = component_part*PSI_OUT[PSI_out_index];
						  
			      Re_B_EM_amplitude += real_dc (B_EM_amplitude_part);
			      Im_B_EM_amplitude += imag_dc (B_EM_amplitude_part);
						  
			    }}}}}}}

  const TYPE B_EM_amplitude = generate_scalar<TYPE> (Re_B_EM_amplitude , Im_B_EM_amplitude);
  
  return B_EM_amplitude;
}  








TYPE EM_transitions_NBMEs::B_EM_amplitude_one_jump_n_pn_calc (
							      const unsigned int BP_Op , 
							      const class array<TYPE> &OBMEs_n , 
							      const class GSM_vector &PSI_IN_full , 
							      const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_IN_full = PSI_IN_full.get_GSM_vector_helper ();

  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
   
  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();
  
  const int S_IN = GSM_vector_helper_IN_full.get_S ();
  
  const int S_OUT = GSM_vector_helper_OUT.get_S ();
  
  if (S_IN != S_OUT) return 0.0;
  
  const int iM_IN = GSM_vector_helper_IN_full.get_iM ();

  const int iM_OUT = GSM_vector_helper_OUT.get_iM ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_IN_full.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_IN_full.get_neut_Y_data ();
  
  const int n_spec_max = neut_Y_data.get_n_spec_max ();
  
  const bool truncation_hw = GSM_vector_helper_IN_full.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_IN_full.get_truncation_ph ();
  
  const int ML = iM_OUT - iM_IN;
  
  const int iMn_min_M = GSM_vector_helper_OUT.get_iMn_min_M ();
  const int iMn_max_M = GSM_vector_helper_OUT.get_iMn_max_M ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();

  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
    
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
    
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper_OUT.get_all_dimensions_SDp_zero_tab ();
  
  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const unsigned long int first_total_PSI_out_index = GSM_vector_helper_OUT.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_out_index = GSM_vector_helper_OUT.get_last_total_PSI_index ();
  
  const class array<unsigned int> &iCp_out_min_process_tab = GSM_vector_helper_OUT.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_out_max_process_tab = GSM_vector_helper_OUT.get_iCp_max_process_tab ();

  const unsigned long int total_outSDn_index_min = GSM_vector_helper_OUT.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper_OUT.get_total_SDn_index_max ();

  if (total_outSDn_index_min > total_outSDn_index_max) return 0.0;
   
  class array<class jumps_data_out_to_in_str> one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > NBMEs_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_configuration_accepted_one_jump_n_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_IN_indices_one_jump_n_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      one_jump_n_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);

      NBMEs_jump_n_tab(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);

      is_configuration_accepted_one_jump_n_tabs(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);

      total_PSI_IN_indices_one_jump_n_tab(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);
    }
  
  double Re_B_EM_amplitude = 0.0;
  double Im_B_EM_amplitude = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic) reduction (+:Re_B_EM_amplitude , Im_B_EM_amplitude)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();

      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();

      const unsigned int BPp_out = binary_parity_product (BPn_out , BP_OUT);

      const unsigned int BPn_in = binary_parity_product (BPn_out , BP_Op);

      const int Sn_out = outSDn_qn.get_S ();

      const int Sp_out = S_OUT - Sn_out;

      const int Sn_in = Sn_out;
      
      const int n_spec_n_out = outSDn_qn.get_n_spec ();

      const int n_spec_p_out = n_spec_max - n_spec_n_out;

      const int n_spec_n_in = n_spec_n_out;
      
      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;
      
      const int iMp_out = iM_OUT - iMn_out;

      const int iMp_in = iMp_out - ML;
      const int iMn_in = iMn_out - ML;
      
      const int Delta_iMp_in = two_mp_max - iMp_out + iMp_in;
      const int Delta_iMn_in = two_mn_max - iMn_out + iMn_in;
	    
      if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
      if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
            
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	      
      class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(i_thread);

      class array<TYPE> &NBMEs_jump_n = NBMEs_jump_n_tab(i_thread);

      class array<bool> &is_configuration_accepted_one_jump_n_tab = is_configuration_accepted_one_jump_n_tabs(i_thread);

      class array<unsigned long int> &total_PSI_IN_indices_one_jump_n = total_PSI_IN_indices_one_jump_n_tab(i_thread);

      bool one_jump_n_calculated = false;

      bool is_there_one_jump_calc_all = true;
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{
	  const unsigned int iCp_out_min = iCp_out_min_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_process_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);

	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;

	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned long int total_PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;

	      const unsigned long int total_PSI_out_index_dimension_minus_one = total_PSI_out_index_zero + dimension_outSDp_minus_one*dimension_outSDn;
	      
	      if ((total_PSI_out_index_zero <= last_total_PSI_out_index) && (total_PSI_out_index_dimension_minus_one >= first_total_PSI_out_index))
		{
		  if (!one_jump_n_calculated)
		    {
		      one_jump_n.one_jump_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw , BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , neut_Y_data);
					  
		      one_jump_n_calculated = true;
					  
		      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
					 
		      is_there_one_jump_calc_all = (dimension_one_jump_n > 0);
					  
		      if (is_there_one_jump_calc_all) NBMEs_one_jump_mu_calc_one_body_operator (OBMEs_n , one_jump_n , NBMEs_jump_n);
		    }
					      
		  if (!is_there_one_jump_calc_all) continue;				      
				  
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)		 
		    {
		      const unsigned long int total_PSI_out_index = total_PSI_out_index_zero + outSDp_index*dimension_outSDn;
					      
		      if ((total_PSI_out_index >= first_total_PSI_out_index) && (total_PSI_out_index <= last_total_PSI_out_index))
			{
			  const unsigned int PSI_out_index = total_PSI_out_index - first_total_PSI_out_index;
			  
			  bool is_there_one_jump_calc = false;

			  is_configuration_accepted_total_PSI_in_indices_n_fill (BPp_out , Sp_out , n_spec_p_out , n_holes_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , Ep_hw_out , one_jump_n , GSM_vector_helper_IN_full ,
										 is_configuration_accepted_one_jump_n_tab , total_PSI_IN_indices_one_jump_n , is_there_one_jump_calc);
					      
			  if (is_there_one_jump_calc)
			    {
			      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
		      
			      const TYPE component_part = component_part_jumps_calc (dimension_one_jump_n , is_configuration_accepted_one_jump_n_tab , total_PSI_IN_indices_one_jump_n , NBMEs_jump_n , PSI_IN_full);

			      const TYPE B_EM_amplitude_part = component_part*PSI_OUT[PSI_out_index];
						    
			      Re_B_EM_amplitude += real_dc (B_EM_amplitude_part);
			      Im_B_EM_amplitude += imag_dc (B_EM_amplitude_part);
						  
			    }}}}}}}
  
  const TYPE B_EM_amplitude = generate_scalar<TYPE> (Re_B_EM_amplitude , Im_B_EM_amplitude);
  
  return B_EM_amplitude;
}  
















TYPE EM_transitions_NBMEs::B_EM_amplitude_from_OBMEs_calc (
							   class GSM_vector &PSI_IN_full ,
							   const int L ,
							   const unsigned int BP_Op , 
							   const class array<TYPE> &OBMEs_p , 
							   const class array<TYPE> &OBMEs_n ,
							   const double J_IN ,  
							   const class GSM_vector &PSI_IN ,
							   const double J_OUT , 
							   const class GSM_vector &PSI_OUT)
{
  if (!is_it_triangle (J_IN , L , J_OUT)) return 0.0;
    
  const class GSM_vector_helper_class &GSM_vector_helper_IN  = PSI_IN.get_GSM_vector_helper ();
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper_IN.get_is_it_MPI_parallelized_local ();
  
  const unsigned int BP_IN  = GSM_vector_helper_IN.get_BP ();
  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();

  if (BP_OUT != binary_parity_product (BP_Op , BP_IN)) return 0.0;
  
  const int S_IN  = GSM_vector_helper_IN.get_S ();
  const int S_OUT = GSM_vector_helper_OUT.get_S ();
  
  if (S_IN != S_OUT) return 0.0;
  
  const int iM_IN  = GSM_vector_helper_IN.get_iM ();
  const int iM_OUT = GSM_vector_helper_OUT.get_iM ();

  const int ML = iM_OUT - iM_IN;

  if (abs (ML) > L) return 0.0;
      
  const enum space_type space = GSM_vector_helper_OUT.get_space ();

  const double M_IN  = GSM_vector_helper_IN.get_M ();
  const double M_OUT = GSM_vector_helper_OUT.get_M ();
      
  class GSM_vector_helper_class GSM_vector_helper_IN_full;
  
  GSM_vector_helper_IN_full.allocate_fill_without_MPI_parallelization (GSM_vector_helper_IN);
  
  PSI_IN_full.change_GSM_vector_helper_reallocate (GSM_vector_helper_IN_full);
  
  PSI_IN_full.full_vector_fill (PSI_IN);
  
  TYPE B_EM_amplitude_partial = 0.0;
  
  switch (space)
    {
    case PROT_Y_ONLY:
      {
	B_EM_amplitude_partial += B_EM_amplitude_diagonal_part_pp_nn_calc (OBMEs_p , PSI_IN_full , PSI_OUT);	
	B_EM_amplitude_partial += B_EM_amplitude_one_jump_part_pp_nn_calc (OBMEs_p , PSI_IN_full , PSI_OUT);
      
      } break;
      
    case NEUT_Y_ONLY:
      {
	B_EM_amplitude_partial += B_EM_amplitude_diagonal_part_pp_nn_calc (OBMEs_n , PSI_IN_full , PSI_OUT);	
	B_EM_amplitude_partial += B_EM_amplitude_one_jump_part_pp_nn_calc (OBMEs_n , PSI_IN_full , PSI_OUT);
      
      } break;


    case PROT_NEUT_Y:
      {
	B_EM_amplitude_partial += B_EM_amplitude_diagonal_part_pn_p_part_calc (OBMEs_p , PSI_IN_full , PSI_OUT);
	B_EM_amplitude_partial += B_EM_amplitude_diagonal_part_pn_n_part_calc (OBMEs_n , PSI_IN_full , PSI_OUT);
	
	B_EM_amplitude_partial += B_EM_amplitude_one_jump_p_pn_calc (BP_Op , OBMEs_p , PSI_IN_full , PSI_OUT);
	B_EM_amplitude_partial += B_EM_amplitude_one_jump_n_pn_calc (BP_Op , OBMEs_n , PSI_IN_full , PSI_OUT);
	
      } break;

    default: abort_all ();
    }
    
  PSI_IN_full.remove_GSM_vector_helper ();
  
  const TYPE B_EM_amplitude = sum_Reduce<TYPE> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , B_EM_amplitude_partial);
  
  const TYPE reduced_B_EM_amplitude = (THIS_PROCESS == MASTER_PROCESS) ? (static_cast<TYPE> (ME_reduced (B_EM_amplitude , L , ML , J_IN , M_IN , J_OUT , M_OUT))) : (NADA);

  return reduced_B_EM_amplitude;
}


