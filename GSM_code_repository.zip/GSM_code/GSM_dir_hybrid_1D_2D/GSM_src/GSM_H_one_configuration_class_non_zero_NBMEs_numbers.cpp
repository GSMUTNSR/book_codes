#include "../GSM_include/GSM_include_def.h"

using namespace GSM_vector_NBMEs_handling;


// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons
// ------------------------------------------------------------------------------------------------------------------------------------------------------



// Calculation of the number of non-zero NBMEs of the Hamiltonian for a fixed configuration for the calculation of MSDHF potentials
// --------------------------------------------------------------------------------------------------------------------------------
// The number of non-zero NBMEs of the Hamiltonian is calculated to have the proportion of non-zero NBMEs, which provide with the time needed for Hamiltonian times vector.
// It is also necessary for Hamiltonian full storage options as one has to store all non-zero NBMEs, so that their number provides with array dimensions.
//
// TRS is time-reversal symmetry and can be used therein.
// It allows to to calculate about one half of |Psi[out]> if M=0, while the rest is given from the first half up to a phase in |Psi[in]> and |Psi[out]>.
// Thus, Hamiltonian storage is divided by about two when TRS is used.
//
// Neither MPI nor OpenMP is used in this class, as parallelization is done an another level with MSDHF.
// It is done at level of the calculation of one-body scattering states, as they can be in large number, so that it is efficient for nodes to calculate them independently.
// Conversely, the space dimensions on one configuration are very small, so that a sequential calculation therein is efficient as well..
// Evidently, only full storage is used in this case, due to the very small dimensions involved.
// One calculates the number of non-zero NBMEs occurring in one node only as these values define array dimensions in the first place.
// MPI reduction is done afterwards when one calculates the proportion of non-zero NBMEs, which is defined in the full space.
//
// non_zero_NBMEs_number_diagonal_part_calc
// ----------------------------------------
// It provides with the number of diagonal NBMEs on one node, as diagonal NBMEs are always non zero in general.
// This routine is used only in the routine calculating the proportion of non-zero NBMEs.
//
// non_zero_NBMEs_numbers_jumps_p_part_pn_calc, non_zero_NBMEs_numbers_jumps_n_part_pn_calc
// ----------------------------------------------------------------------------------------
// This provides with the number of non-zero off-diagonal NBMEs for 1p-1h or 2p-2h jumps from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// This is for p -> p', n -> n', p1 p2 -> p1' p2' and n1 n2 -> n1' n2' only, and this routine is used when one has both valence protons and neutrons.
// In this routine, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the number of non-zero NBMEs from them.
//
// non_zero_NBMEs_numbers_two_jumps_pn_part_calc
// ---------------------------------------------
// This provides with the number of non-zero off-diagonal NBMEs for 2p-2h pn jumps from an out Slater determinant to an in Slater determinant.
// One routine is used if NYval >= ZYval (N_valence_larger), and another if not (Z_valence_larger),
// as SD indices are calculated differently in each case to optimize their use (see GSM_vector_dimensions.cpp).
// One calculates 1p-1h proton or neutron jumps totally (...recalculated... routines) or partially (other routine) according the the value of all_H_proton_neutron_one_jumps_recalculated
// (see one_jump_p_tabs, one_jump_n_tabs discussion in GSM_H_class.cpp).
//
// For this, one loop over parity and M quantum numbers of the in Slater determinant, and one calculates 1p-1h proton and neutron jumps using quantum number conservation,
// so that the pn 2p-2h jump can be generated from it. Once they are calculated, one loops over obtained proton and neutron in Slater determinants for a fixed out Slater determinant,
// and one increases the number of non-zero NBMEs if model space truncations are respected, i.e. if hw truncation energy and number of particles in the continuum are below their limit.
//
// non_zero_NBMEs_numbers_jumps_part_pp_nn_calc
// --------------------------------------------
// This provides with the number of non-zero off-diagonal NBMEs for 1p-1h or 2p-2h jumps from a proton/neutron Slater determinant to another proton/neutron Slater determinant.
// This is for p -> p', n -> n', p1 p2 -> p1' p2' and n1 n2 -> n1' n2' only, and this routine is used when one has valence protons only or valence neutrons only.
// In this routine, one loops over all basis Slater determinants, one generates all jumps of the aforementioned forms,
// and one calculates and stores the number of non-zero NBMEs from them.
//
// rows_non_zero_NBMEs_off_diagonal_numbers_calc
// ---------------------------------------------
// This routine calls the previous routine and calculates the number of non-zero NBMEs for each row of the Hamiltonian for each node.


unsigned int H_one_configuration_class::non_zero_NBMEs_number_diagonal_part_calc () const
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const unsigned int space_dimension = GSM_vector_helper.get_space_dimension ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  unsigned int non_zero_NBMEs_number_diagonal_part = 0;

  if (!is_it_TRS)
    non_zero_NBMEs_number_diagonal_part = space_dimension;
  else
    {
      const class array<unsigned int> &TRS_PSI_indices = GSM_vector_helper.get_TRS_PSI_indices ();
      
      for (unsigned int PSI_out_index = 0 ; PSI_out_index < space_dimension ; PSI_out_index++)
	{
	  if (TRS_PSI_indices(PSI_out_index) >= PSI_out_index) non_zero_NBMEs_number_diagonal_part++;
	}
    }

  return non_zero_NBMEs_number_diagonal_part;
}



void H_one_configuration_class::non_zero_NBMEs_numbers_jumps_p_part_pn_calc ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int iM = GSM_vector_helper.get_iM ();

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const unsigned int BPp = prot_Y_data.get_BP_one_configuration ();
  const unsigned int BPn = neut_Y_data.get_BP_one_configuration ();
  
  const unsigned int iCp = prot_Y_data.get_iC_one_configuration ();   
  const unsigned int iCn = neut_Y_data.get_iC_one_configuration ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array<unsigned int> &TRS_PSI_indices = GSM_vector_helper.get_TRS_PSI_indices (); 

  const int np_holes_max = prot_Y_data.get_n_holes_max ();
  
  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();

  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max  = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  const unsigned int dimension_pp_2p2h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_2p2h_space_BP_S_iM_fixed_max ();

  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  class jumps_data_out_to_in_str one_jump_p(ONE_JUMP_ONE_CONFIGURATION   , PROT_NEUT_Y , true , true , dimension_p_1p1h_space_BP_S_iM_fixed_max);
  class jumps_data_out_to_in_str two_jumps_p(TWO_JUMPS_ONE_CONFIGURATION , PROT_NEUT_Y , true , true , dimension_pp_2p2h_space_BP_S_iM_fixed_max);

  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
    {
      const int iMn = iM - iMp;
      
      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , 0 , 0 , 0  , iCp , iMp);

      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , 0 , 0 , 0 , iCn , iMn);
      
      if ((dimension_outSDp == 0) || (dimension_SDn == 0)) continue;

      const unsigned int sum_dimensions_Mp_Mn_fixed = sum_dimensions(iMp);
      
      for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
	{
	  one_jump_p.one_jump_mu_store (BPp , 0 , 0 , iMp , np_holes_max , 0 , Ep_max_hw , BPp , 0 , 0 , 0  , iCp , iMp , outSDp_index , prot_Y_data);

	  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();

	  unsigned int row_non_zero_NBMEs_jumps_p_part = dimension_one_jump_p;

	  if (ZYval >= 2)
	    {
	      two_jumps_p.two_jumps_mu_store (BPp , 0 , 0 , iMp , np_holes_max , 0 , Ep_max_hw , BPp , 0 , 0 , 0  , iCp , iMp , outSDp_index , false , false , prot_Y_data);

	      const unsigned int dimension_two_jumps_p = two_jumps_p.get_dimension ();

	      row_non_zero_NBMEs_jumps_p_part += dimension_two_jumps_p;
	    }

	  if (row_non_zero_NBMEs_jumps_p_part != 0)
	    {
	      const unsigned int PSI_out_index_zero = sum_dimensions_Mp_Mn_fixed + dimension_SDn*outSDp_index;

	      for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		{
		  const unsigned int PSI_out_index = PSI_out_index_zero + SDn_index;

		  if (!is_it_TRS || (TRS_PSI_indices(PSI_out_index) >= PSI_out_index))
		    rows_non_zero_NBMEs_numbers(PSI_out_index) += row_non_zero_NBMEs_jumps_p_part;
		}
	    }
	}
    }
}



void H_one_configuration_class::non_zero_NBMEs_numbers_jumps_n_part_pn_calc ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int iM = GSM_vector_helper.get_iM ();

  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M ();
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons (); 

  const unsigned int BPp = prot_Y_data.get_BP_one_configuration ();
  const unsigned int BPn = neut_Y_data.get_BP_one_configuration ();
  
  const unsigned int iCp = prot_Y_data.get_iC_one_configuration (); 
  const unsigned int iCn = neut_Y_data.get_iC_one_configuration ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array<unsigned int> &TRS_PSI_indices = GSM_vector_helper.get_TRS_PSI_indices (); 
  
  const int nn_holes_max = neut_Y_data.get_n_holes_max ();
  
  const int En_max_hw = neut_Y_data.get_E_max_hw ();
  
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max  = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  const unsigned int dimension_nn_2p2h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_2p2h_space_BP_S_iM_fixed_max ();
  
  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  class jumps_data_out_to_in_str one_jump_n(ONE_JUMP_ONE_CONFIGURATION   , PROT_NEUT_Y , true , true , dimension_n_1p1h_space_BP_S_iM_fixed_max);
  class jumps_data_out_to_in_str two_jumps_n(TWO_JUMPS_ONE_CONFIGURATION , PROT_NEUT_Y , true , true , dimension_nn_2p2h_space_BP_S_iM_fixed_max);

  for (int iMn = iMn_min_M ; iMn <= iMn_max_M ; iMn++)
    {
      const int iMp = iM - iMn;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , 0 , 0 , 0  , iCp , iMp);

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , 0 , 0 , 0 , iCn , iMn);
      
      if ((dimension_SDp == 0) || (dimension_outSDn == 0)) continue;

      const unsigned int sum_dimensions_Mp_Mn_fixed = sum_dimensions(iMp);

      for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
	{
	  one_jump_n.one_jump_mu_store (BPn , 0 , 0 , iMn , nn_holes_max , 0 , En_max_hw , BPn , 0 , 0 , 0 , iCn , iMn , outSDn_index , neut_Y_data);

	  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

	  unsigned int row_non_zero_NBMEs_jumps_n_part = dimension_one_jump_n;

	  if (NYval >= 2)
	    {
	      two_jumps_n.two_jumps_mu_store (BPn , 0 , 0 , iMn , nn_holes_max , 0 , En_max_hw , BPn , 0 , 0 , 0 , iCn , iMn , outSDn_index , false , false , neut_Y_data);

	      const unsigned int dimension_two_jumps_n = two_jumps_n.get_dimension ();

	      row_non_zero_NBMEs_jumps_n_part += dimension_two_jumps_n;
	    }

	  if (row_non_zero_NBMEs_jumps_n_part != 0)
	    {
	      const unsigned int PSI_out_index_zero = sum_dimensions_Mp_Mn_fixed + outSDn_index;
		  
	      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		{
		  const unsigned int PSI_out_index = PSI_out_index_zero + SDp_index*dimension_outSDn;

		  if (!is_it_TRS || (TRS_PSI_indices(PSI_out_index) >= PSI_out_index))
		    rows_non_zero_NBMEs_numbers(PSI_out_index) += row_non_zero_NBMEs_jumps_n_part;
		}
	    }
	}
    }
}






void H_one_configuration_class::non_zero_NBMEs_numbers_two_jumps_pn_part_pn_calc ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 

  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array<unsigned int> &TRS_PSI_indices = GSM_vector_helper.get_TRS_PSI_indices (); 
  
  const int iMp_max_M_plus_one = iMp_max_M + 1;
  const int iMn_max_M_plus_one = iMn_max_M + 1;
  
  const unsigned int BPp = prot_Y_data.get_BP_one_configuration (); 
  const unsigned int BPn = neut_Y_data.get_BP_one_configuration ();
  
  const unsigned int iCp = prot_Y_data.get_iC_one_configuration (); 
  const unsigned int iCn = neut_Y_data.get_iC_one_configuration ();

  const int np_holes_max = prot_Y_data.get_n_holes_max ();
  const int nn_holes_max = neut_Y_data.get_n_holes_max ();
  
  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();
  
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max (); 

  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();

  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max (); 
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  
  const unsigned int dimension_SDp_max = prot_Y_data.get_dimension_SD_max ();
  const unsigned int dimension_SDn_max = neut_Y_data.get_dimension_SD_max ();
  
  const class sum_GSM_vector_dimensions_one_configuration_class &sum_dimensions = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  class array<class jumps_data_out_to_in_str> one_jump_p_tab(iMp_max_M_plus_one , dimension_SDp_max);
  class array<class jumps_data_out_to_in_str> one_jump_n_tab(iMn_max_M_plus_one , dimension_SDn_max);
      
  class array<bool> is_one_jump_p_calculated_tab(iMp_max_M_plus_one , dimension_SDp_max);
  class array<bool> is_one_jump_n_calculated_tab(iMn_max_M_plus_one , dimension_SDn_max);

  for (int iMp_out = iMp_min_M ; iMp_out <= iMp_max_M ; iMp_out++)
    {
      is_one_jump_p_calculated_tab = false;
      is_one_jump_n_calculated_tab = false;

      const int iMn_out = iM - iMp_out;

      const int iMp_in_min_M = max(iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min(iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , 0 , 0 , 0  , iCp , iMp_out);
      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , 0 , 0 , 0 , iCn , iMn_out);

      if ((dimension_outSDp == 0) || (dimension_outSDn == 0)) continue;

      const unsigned int sum_dimensions_Mp_Mn_fixed_out = sum_dimensions(iMp_out);

      for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
	{
	  const unsigned int PSI_out_index_zero_outSDp_fixed = sum_dimensions_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;

	  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
	    {
	      const unsigned int PSI_out_index = PSI_out_index_zero_outSDp_fixed + outSDn_index;

	      if (!is_it_TRS || (TRS_PSI_indices(PSI_out_index) >= PSI_out_index))
		{
		  for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
		    {
		      const int iMn_in = iM - iMp_in;

		      const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
		      const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
		      
		      if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
		      if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;

		      bool &is_one_jump_p_calculated = is_one_jump_p_calculated_tab(iMp_in , outSDp_index);
		      bool &is_one_jump_n_calculated = is_one_jump_n_calculated_tab(iMn_in , outSDn_index);

		      class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(iMp_in , outSDp_index);
		      class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(iMn_in , outSDn_index);

		      if (!is_one_jump_p_calculated)
			{
			  if (!one_jump_p.is_it_filled ()) one_jump_p.allocate (ONE_JUMP_ONE_CONFIGURATION , PROT_NEUT_Y , true , true , dimension_p_1p1h_space_BP_S_iM_fixed_max);

			  one_jump_p.one_jump_mu_store (BPp , 0 , 0 , iMp_in , np_holes_max , 0 , Ep_max_hw , BPp , 0 , 0 , 0  , iCp , iMp_out , outSDp_index , prot_Y_data);

			  is_one_jump_p_calculated = true;
			}

		      if (!is_one_jump_n_calculated)
			{
			  if (!one_jump_n.is_it_filled ()) one_jump_n.allocate (ONE_JUMP_ONE_CONFIGURATION ,PROT_NEUT_Y ,  true , true , dimension_n_1p1h_space_BP_S_iM_fixed_max);

			  one_jump_n.one_jump_mu_store (BPn , 0 , 0 , iMn_in , nn_holes_max , 0 , En_max_hw , BPn , 0 , 0 , 0 , iCn , iMn_out , outSDn_index , neut_Y_data); 

			  is_one_jump_n_calculated = true;				 
			}

		      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
		      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

		      const unsigned int row_non_zero_NBMEs_two_jumps_pn_component_part = dimension_one_jump_p*dimension_one_jump_n;

		      rows_non_zero_NBMEs_numbers(PSI_out_index) += row_non_zero_NBMEs_two_jumps_pn_component_part;
		    }}}}}
}








void H_one_configuration_class::non_zero_NBMEs_numbers_off_diagonal_pp_nn_calc ()
{  
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();

  const int iM = GSM_vector_helper.get_iM ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS (); 

  const class array<unsigned int> &TRS_PSI_indices = GSM_vector_helper.get_TRS_PSI_indices (); 
 
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);
  
  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  const int n_holes_max = data.get_n_holes_max ();
  
  const unsigned int BP = data.get_BP_one_configuration ();
  const unsigned int iC = data.get_iC_one_configuration ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();
  
  const unsigned int dimension_1p1h_space_BP_S_iM_fixed_max = data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  const unsigned int dimension_2p2h_space_BP_S_iM_fixed_max = data.get_dimension_2p2h_space_BP_S_iM_fixed_max ();

  const int E_max_hw = data.get_E_max_hw ();

  const unsigned int dimension_outSD_set = dimensions_SD_set(BP , 0 , 0 , 0 , iC , iM);

  class jumps_data_out_to_in_str one_jump_mu(ONE_JUMP_ONE_CONFIGURATION   , PROT_NEUT_Y , true , true , dimension_1p1h_space_BP_S_iM_fixed_max);
  class jumps_data_out_to_in_str two_jumps_mu(TWO_JUMPS_ONE_CONFIGURATION , PROT_NEUT_Y , true , true , dimension_2p2h_space_BP_S_iM_fixed_max);

  for (unsigned int outSD_index = 0 ; outSD_index < dimension_outSD_set ; outSD_index++)
    {
      if (!is_it_TRS || (TRS_PSI_indices(outSD_index) >= outSD_index))
	{
	  one_jump_mu.one_jump_mu_store (BP , 0 , 0 , iM , n_holes_max , 0 , E_max_hw , BP , 0 , 0 , 0 , iC , iM , outSD_index , data);

	  const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();

	  unsigned int row_non_zero_NBMEs_jumps_component_part = dimension_one_jump_mu;

	  if (N_valence_baryons >= 2)
	    {
	      two_jumps_mu.two_jumps_mu_store (BP , 0 , 0 , iM ,  n_holes_max , 0 , E_max_hw , BP , 0 , 0 , 0 , iC , iM , outSD_index , false , false , data);

	      const unsigned int dimension_two_jumps_mu = two_jumps_mu.get_dimension ();

	      row_non_zero_NBMEs_jumps_component_part += dimension_two_jumps_mu; 
	    }

	  rows_non_zero_NBMEs_numbers[outSD_index] += row_non_zero_NBMEs_jumps_component_part;
	}
    }
}






void H_one_configuration_class::rows_non_zero_NBMEs_off_diagonal_numbers_calc ()
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();
  
  rows_non_zero_NBMEs_numbers = 0;

  if (space == PROT_NEUT_Y)
    {
      non_zero_NBMEs_numbers_jumps_p_part_pn_calc ();
      non_zero_NBMEs_numbers_jumps_n_part_pn_calc ();
      
      non_zero_NBMEs_numbers_two_jumps_pn_part_pn_calc ();
    }
  else
    non_zero_NBMEs_numbers_off_diagonal_pp_nn_calc ();
}


