#include "../GSM_include/GSM_include_def.h"

using namespace lj_matrix_common;
using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;
using namespace GSM_vector_NBMEs_handling::out_to_in;
using namespace MPI_2D_partitioning;


// TYPE is double or complex
// -------------------------


// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons (plus a few hyperons if any)
// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------









// Calculation of scalar densities <Psi | norm.[a+_{nlj} a~_{nlj}]^0 | Psi>
// ------------------------------------------------------------------------.
// One uses norm = hat(j)/N.valence.nucleons for the scalar density operator.
// Indeed, hat(j).[a+_{nlj} a~_{nlj}]^0 = \sum_m a+(nljm) a(nljm), which provides the average number of occupied stated on the (n,l,j) shell.
// N.valence.nucleons = ZYval or NYval according the proton or neutron character of scalar densities.
// It allows to have normalized occupancies in shells, so that the sum of the eigenvalues of scalar densities for all (l,j) quantum numbers is equal to 1.
// N.valence.nucleons is considered only at the end of the calculation so that the operator considered in routines is hat(j).[a+_{nlj} a~_{nlj}]^0.
// 
// One calculates here scalar densities <Psi | hat(j).[a+_{nlj} a~_{nlj}]^0 | Psi> for a Hamiltonian eigenvector |Psi> and for all (l,j) as well as their diagonal and off-diagonal parts.
// As they are used for the calculation of natural orbitals, these matrix elements are stored in matrices M_{lj} of quantum numbers (l,j),
// so that their matrix elements are M_{lj}(n,n') = <Psi | hat(j).[a+_{nlj} a~_{nlj}]^0 | Psi>.
// M_{lj} matrices are symmetric so that only their lower half is calculated. The upper half is considered at the end of the calculation.
//
// <Psi | hat(j).[a+_{nlj} a~_{nlj}]^0 | Psi> = \sum_{inSD,outSD} <Psi | outSD> <inSD | Psi> <outSD | hat(j).[a+_{nlj} a~_{nlj}]^0 | inSD>.
// It is separated in diagonal and off-diagonal parts.
//
// Diagonal parts are: <SD | hat(j).[a+_{nlj} a~_{nlj}]^0 | SD> = N_{nlj}(SD), which is the number of occupied states on the (n,l,j) shell.
// This depends only on the SD configuration, so that it is recalculated for all |SD> but only for their configuration.
// 
// Off-diagonal parts are of 1p-1h type and are non-zero only if the differing state between the in and out SD states belong to the same (n,l,j) shell:
// <outSD | hat(j).[a+_{n_out lj} a~_{n_in lj}]^0 | inSD> = <outSD | a+(n_out lj m_out) a(n_in lj m_in) | inSD> = +/- 1, which is the reordering phase, stored in an array.
// 
// One separates the proton and neutron parts of <outSD | hat(j).[a+_{nlj} a~_{nlj}]^0 | inSD> in the proton-neutron case.
// One loops over Slater determinants, and one sums over <outSD | hat(j).[a+_{nlj} a~_{nlj}]^0 | inSD> NBMEs multiplied by <Psi | outSD> and <inSD | Psi>.
//
// OpenMP parallelization is used on the loop of proton or neutron configurations for the diagonal part, as NBMEs only depend on configurations,
// and proton or neutron Slater determinants for the off-diagonal part.
// MPI parallelization here is implicit, as on considers only the Slater determinants of the current node. MPI reduction is done at the end of the calculation.
//
// One calls the "calc" routine. This routine calls diagonal and off-diagonal parts routines, sums them and reduces if MPI is used.
// Only the value borne by the master process is meaningful, as MPI reduction is done only therein.
//
// TRS is time-reversal symmetry and can be used therein.
// It allows to divide calculations about one half if M=0 for |Psi>, as the rest is given from the first half by symmetry.
//
// One partially uses 1D partitioning here.
// Indeed, all the parts of |Psi> scattered over all nodes are gathered in |Psi-full>, so that all nodes have a full copy of |Psi>. This for |Psi> (not <Psi|) in <Psi | norm.[a+_{nlj} a~_{nlj}]^0 | Psi>.
// Indeed, one would have too many MPI communications otherwise.
// Each node takes care of its part of <Psi| when calculating <Psi | norm.[a+_{nlj} a~_{nlj}]^0 | Psi>.
//
//
// diagonal_parts_pp_nn_fixed_configuration_calc
// ---------------------------------------------
// This routine calculates <SD | hat(j).[a+_{nlj} a~_{nlj}]^0 | SD> = N_{nlj}(SD) for a fixed proton or neutron (plus a few hyperons if any) SD for all (n,l,j) shells
//
// components_parts_one_jump_mu_calc
// ---------------------------------
// This routine adds the part of <outSD | hat(j).[a+_{n_out lj} a~_{n_in lj}]^0 | SD> <inSD | Psi> = <outSD | a+(n_out lj m_out) a(n_in lj m_in) | SD> <inSD | Psi>
// for a fixed |outSD> for all 1p-1h NBMEs in arrays functions of l, j, n_in, n_out .
//
// diagonal_parts_calc
// -------------------
// This routine adds the part of <SD | hat(j).[a+_{nlj} a~_{nlj}]^0 | SD> <SD | Psi>^2 to parts of M_{lj} matrices for a fixed configuration in the M_{lj}(n,n) matrix element.
//
// one_jump_mu_part_calc
// ---------------------
// This routine adds the part of <outSD | hat(j).[a+_{n_in lj} a~_{n_out lj}]^0 | inSD> <inSD | Psi> <outSD | Psi>
// to parts of M_{lj} matrices for a fixed configuration in the M_{lj}(n_in,n_out) matrix element.
//
// pp_nn_diagonal_parts_calc
// -------------------------
// This routine calculates the diagonal part of scalar density matrices <Psi | hat(j).[a+_{n_in lj} a~_{n_out lj}]^0 | Psi> with valence protons only or valence neutrons only.
//
// pp_nn_one_jump_parts_calc
// -------------------------
// This routine calculates the 1p-1h part of scalar density matrices <Psi | hat(j).[a+_{n_in lj} a~_{n_out lj}]^0 | Psi> with valence protons only or valence neutrons only.
//
// diagonal_parts_pn_p_part_calc, diagonal_parts_pn_n_part_calc
// ------------------------------------------------------------------
// These routines calculate the diagonal proton and neutron parts of scalar density matrices <Psi | hat(j).[a+_{n_in lj} a~_{n_out lj}]^0 | Psi> with valence protons and neutrons.
//
// one_jump_p_parts_pn_calc, one_jump_n_parts_pn_calc
// --------------------------------------------------
// These routines calculate the proton and neutron 1p-1h part of scalar density matrices <Psi | hat(j).[a+_{n_in lj} a~_{n_out lj}]^0 | Psi> with valence protons and neutrons.
//
// calc
// ----
// This routine calculates proton and neutron lower parts of scalar density matrices, MPI reduce them,
// fill their symmetric upper parts and divide them by ZYval or NYval (see above).


void scalar_density_matrix::diagonal_parts_pp_nn_fixed_configuration_calc (
									   const class baryons_data &data , 
									   const class configuration &C ,
									   class array<class nlj_table<int> > &diagonal_parts_fixed_iC_tab)
{
  const unsigned int N_nlj = data.get_N_nlj_baryon ();
  
  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_qn(s);

      const enum particle_type particle = shell_qn.get_particle ();
      
      const unsigned int particle_index = charge_baryon_index_determine (particle);
      
      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();
	      
      const double j = shell_qn.get_j ();
	      
      const class nlj_table<int> &diagonal_parts_fixed_iC = diagonal_parts_fixed_iC_tab(particle_index);
	      
      diagonal_parts_fixed_iC(n , l , j) = C.occupancy_determine (s);
    }
}


void scalar_density_matrix::components_parts_one_jump_mu_calc (
							       const class baryons_data &data , 
							       const class jumps_data_out_to_in_str &one_jump_mu , 
							       const class array<bool> &is_configuration_accepted_tab , 
							       const class array<unsigned long int> &total_PSI_IN_indices_one_jump_mu ,
							       const class GSM_vector &PSI_full ,
							       class array<class lj_table<TYPE> > &components_parts_one_jump_mu_tab)
{
  const class array<class nljm_struct> &phi_table = data.get_phi_table ();

  const unsigned int dimension_one_jump = one_jump_mu.get_dimension ();

  const unsigned int N_baryon_types = components_parts_one_jump_mu_tab.dimension (0);
  
  for (unsigned int i = 0 ; i < N_baryon_types ; i++) components_parts_one_jump_mu_tab(i) = 0.0;

  for (unsigned int i = 0 ; i < dimension_one_jump ; i++)
    {
      const bool is_configuration_accepted = is_configuration_accepted_tab(i);

      if (is_configuration_accepted)
	{
	  const class jumps_data_inSD_str &one_jump_mu_inSD = one_jump_mu(i);

	  const unsigned int mu_in  = one_jump_mu_inSD.get_mu_in ();
	  const unsigned int mu_out = one_jump_mu_inSD.get_mu_out ();

	  const class nljm_struct &phi_in  = phi_table(mu_in);
	  const class nljm_struct &phi_out = phi_table(mu_out);

	  const int n_in  = phi_in.get_n ();
	  const int n_out = phi_out.get_n ();
	      
	  if ((n_out <= n_in) && same_lj_particle (phi_in , phi_out))
	    {		  
	      const unsigned long int total_PSI_IN_index = total_PSI_IN_indices_one_jump_mu(i);

	      const int l = phi_in.get_l ();
	      
	      const double j = phi_in.get_j ();

	      const enum particle_type particle = phi_in.get_particle ();
	      
	      const unsigned int particle_index = charge_baryon_index_determine (particle);
	      
	      const unsigned int total_bin_phase_mu = one_jump_mu_inSD.get_total_bin_phase ();

	      const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);
	      
	      class lj_table<TYPE> &components_parts_one_jump_mu = components_parts_one_jump_mu_tab(particle_index);
	      
	      (total_phase_mu == 1)
		? (components_parts_one_jump_mu(l , j , n_in , n_out) += PSI_full[total_PSI_IN_index])
		: (components_parts_one_jump_mu(l , j , n_in , n_out) -= PSI_full[total_PSI_IN_index]);
	    }
	}
    }
}




void scalar_density_matrix::diagonal_parts_calc (
						 const class array<class nlj_table<int> > &diagonal_parts_fixed_iC_tab ,
						 const TYPE &PSI_OUT_component ,
						 const TYPE &PSI_OUT_component_TRS_factor ,
						 class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_fixed_iC_tab)
{
  const unsigned int N_baryon_types = scalar_density_matrices_fixed_iC_tab.dimension (0);
  
  const TYPE PSI_OUT_component_square_TRS_factor = PSI_OUT_component*PSI_OUT_component_TRS_factor;

  for (unsigned int i = 0 ; i < N_baryon_types ; i++)
    {
      const class nlj_table<int> &diagonal_parts_fixed_iC = diagonal_parts_fixed_iC_tab(i);
      
      class lj_table<class matrix<TYPE> > &scalar_density_matrices_fixed_iC = scalar_density_matrices_fixed_iC_tab(i);
            
      const int lmax = scalar_density_matrices_fixed_iC.get_lmax ();
      
      for (int l = 0 ; l <= lmax ; l++)
	for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	  {
	    class matrix<TYPE> &scalar_density_matrix_fixed_iC = scalar_density_matrices_fixed_iC(l , j);
	
	    if (scalar_density_matrix_fixed_iC.is_it_filled ())
	      {
		const int nmax_lj = scalar_density_matrix_fixed_iC.get_dimension () - 1;
	    
		for (int n = 0 ; n <= nmax_lj ; n++)
		  {
		    const int diagonal_part_fixed_iC = diagonal_parts_fixed_iC(n , l , j);
		
		    scalar_density_matrix_fixed_iC(n , n) += diagonal_part_fixed_iC*PSI_OUT_component_square_TRS_factor;
		  }
	      }
	  }
    }
}




void scalar_density_matrix::one_jump_mu_part_calc (
						   const class array<class lj_table<TYPE> > &components_parts_one_jump_mu_tab ,
						   const TYPE &PSI_OUT_component_TRS_factor ,
						   class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_fixed_iC_tab)
{
  const unsigned int N_baryon_types = components_parts_one_jump_mu_tab.dimension (0);
  
  for (unsigned int i = 0 ; i < N_baryon_types ; i++)
    {
      const class lj_table<TYPE> &components_parts_one_jump_mu = components_parts_one_jump_mu_tab(i);
      
      class lj_table<class matrix<TYPE> > &scalar_density_matrices_fixed_iC = scalar_density_matrices_fixed_iC_tab(i);
      
      const int lmax = scalar_density_matrices_fixed_iC.get_lmax ();
      
      for (int l = 0 ; l <= lmax ; l++)
	for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	  {
	    class matrix<TYPE> &scalar_density_matrix_fixed_iC = scalar_density_matrices_fixed_iC(l , j);
	
	    if (scalar_density_matrix_fixed_iC.is_it_filled ())
	      {
		const int nmax_lj = scalar_density_matrix_fixed_iC.get_dimension () - 1;

		for (int n_in = 0 ; n_in <= nmax_lj ; n_in++)
		  for (int n_out = 0 ; n_out <= n_in ; n_out++)
		    scalar_density_matrix_fixed_iC(n_in , n_out) += components_parts_one_jump_mu(l , j , n_in , n_out)*PSI_OUT_component_TRS_factor;
	      }
	  }
    }
}






void scalar_density_matrix::pp_nn_diagonal_parts_calc (
						       const class GSM_vector &PSI ,
						       const class GSM_vector &PSI_full ,
						       class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
    
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);
    
  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  const unsigned int N_baryon_types = scalar_density_matrices_tab.dimension (0);
  
  const class array_of_configuration &configuration_set = data.get_configuration_set ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector     = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();
  
  const array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const int lmax = data.get_lmax ();
  const int nmax = data.get_nmax ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();

  const int iM = GSM_vector_helper.get_iM ();
      
  const unsigned int dimension_1p1h_space_BP_S_iM_fixed_max = data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();

  class array<bool> is_configuration_accepted_tab(dimension_1p1h_space_BP_S_iM_fixed_max);

  is_configuration_accepted_tab = true;
  
  const unsigned long int first_total_PSI_OUT_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_OUT_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = data.get_SD_TRS_indices ();

  const class array<unsigned int> &iC_min_process_tab = GSM_vector_helper.get_iC_min_process_tab ();
  const class array<unsigned int> &iC_max_process_tab = GSM_vector_helper.get_iC_max_process_tab ();
  
  class array<class configuration> C_tab(NUMBER_OF_THREADS);
    
  class array<class array<class nlj_table<int> > > diagonal_parts_fixed_iC_tabs(NUMBER_OF_THREADS);

  class array<class array<class lj_table<class matrix<TYPE> > > > scalar_density_matrices_fixed_iC_tabs(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {      
      class array<class nlj_table<int> > &diagonal_parts_fixed_iC_tab = diagonal_parts_fixed_iC_tabs(i);
  
      C_tab(i).allocate (N_valence_baryons);
      
      diagonal_parts_fixed_iC_tab.allocate (N_baryon_types);
						    
      for (unsigned int ii = 0 ; ii < N_baryon_types ; ii++) diagonal_parts_fixed_iC_tab(ii).allocate (0.5 , nmax , lmax);
    }
  
  lj_matrices_parts_tabs_allocate_initialize (data , scalar_density_matrices_fixed_iC_tabs);

  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int iC_min = iC_min_process_tab(n_scat);
      const unsigned int iC_max = iC_max_process_tab(n_scat);

      if (iC_max < iC_min) continue;
      
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
      for (unsigned int iC = iC_min ; iC <= iC_max ; iC++)
	{
	  const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
	  const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD_set = dimensions_SD_set(BP , S , 0 , n_scat , iC , iM);

	  if (dimension_SD_set == 0) continue;

	  const unsigned int i_thread = OpenMP_thread_number_determine ();

	  class configuration &C = C_tab(i_thread);

	  class array<class nlj_table<int> > &diagonal_parts_fixed_iC_tab = diagonal_parts_fixed_iC_tabs(i_thread);

	  class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_fixed_iC_tab = scalar_density_matrices_fixed_iC_tabs(i_thread);
  
	  const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions_GSM_vector(n_scat , iC);

	  const unsigned long int sum_dimensions_configuration_fixed_TRS = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(n_scat , iC)) : (NADA);

	  const unsigned int dimension_SD_set_minus_one = dimension_SD_set - 1;

	  const unsigned long int total_PSI_OUT_index_zero = sum_dimensions_configuration_fixed;

	  const unsigned long int total_PSI_OUT_index_dimension_minus_one = total_PSI_OUT_index_zero + dimension_SD_set_minus_one;
	  
	  if ((total_PSI_OUT_index_zero <= last_total_PSI_OUT_index) && (total_PSI_OUT_index_dimension_minus_one >= first_total_PSI_OUT_index))
	    {
	      const unsigned long int total_SD_TRS_indices_zero_index = (is_it_TRS) ? (SD_TRS_indices.index_determine (BP , S , 0 , n_scat , iC , iM , 0)) : (NADA);		      

	      const unsigned long int TRS_total_PSI_OUT_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_fixed_TRS) : (NADA);

	      C = configuration_set(BP , S , 0 , n_scat , iC);
  
	      diagonal_parts_pp_nn_fixed_configuration_calc (data , C , diagonal_parts_fixed_iC_tab);

	      for (unsigned int SD_index = 0 ; SD_index < dimension_SD_set ; SD_index++)
		{
		  const unsigned long int total_PSI_OUT_index = total_PSI_OUT_index_zero + SD_index;

		  if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
		    {
		      const unsigned long int total_SD_TRS_indices_index = (is_it_TRS) ? (total_SD_TRS_indices_zero_index + SD_index) : (NADA);

		      const unsigned int SD_TRS_index = (is_it_TRS) ? (SD_TRS_indices[total_SD_TRS_indices_index]) : (NADA);
		      
		      const unsigned long int TRS_total_PSI_OUT_index = (is_it_TRS) ? (TRS_total_PSI_OUT_index_zero + SD_TRS_index) : (NADA);
			      
		      if (!is_it_TRS || (TRS_total_PSI_OUT_index >= total_PSI_OUT_index))
			{
			  const TYPE &PSI_OUT_component = PSI_full[total_PSI_OUT_index];

			  const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_OUT_index == total_PSI_OUT_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
			 
			  diagonal_parts_calc (diagonal_parts_fixed_iC_tab , PSI_OUT_component , PSI_OUT_component_TRS_factor , scalar_density_matrices_fixed_iC_tab);
			}}}}}}
  
  add_parts (scalar_density_matrices_fixed_iC_tabs , scalar_density_matrices_tab);
}













void scalar_density_matrix::pp_nn_one_jump_parts_calc (
						       const class GSM_vector &PSI ,
						       const class GSM_vector &PSI_full ,
						       class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
    
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const unsigned int N_baryon_types = scalar_density_matrices_tab.dimension (0);
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector     = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();
  
  const array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const int lmax = data.get_lmax ();
  const int nmax = data.get_nmax ();

  const int nmax_plus_one = nmax + 1;
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int iM = GSM_vector_helper.get_iM ();
      
  const unsigned int dimension_1p1h_space_BP_S_iM_fixed_max = data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();

  class array<bool> is_configuration_accepted_tab(dimension_1p1h_space_BP_S_iM_fixed_max);

  is_configuration_accepted_tab = true;
  
  const unsigned long int first_total_PSI_OUT_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_OUT_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = data.get_SD_TRS_indices ();

  const class array<unsigned int> &iC_out_min_process_tab = GSM_vector_helper.get_iC_min_process_tab ();
  const class array<unsigned int> &iC_out_max_process_tab = GSM_vector_helper.get_iC_max_process_tab ();
  
  class array<class jumps_data_out_to_in_str> one_jump_mu_tab(NUMBER_OF_THREADS);
  
  class array<class array<unsigned long int> > total_PSI_in_indices_one_jump_mu_tab(NUMBER_OF_THREADS);
  
  class array<class array<class lj_table<TYPE> > > components_parts_one_jump_mu_tabs(NUMBER_OF_THREADS);

  class array<class array<class lj_table<class matrix<TYPE> > > > scalar_density_matrices_fixed_iC_out_tabs(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      class array<class lj_table<TYPE> > &components_parts_one_jump_mu_tab = components_parts_one_jump_mu_tabs(i);
      
      one_jump_mu_tab(i).allocate (ONE_JUMP , space , truncation_hw , truncation_ph , dimension_1p1h_space_BP_S_iM_fixed_max);

      total_PSI_in_indices_one_jump_mu_tab(i).allocate (dimension_1p1h_space_BP_S_iM_fixed_max);
      
      components_parts_one_jump_mu_tab.allocate (N_baryon_types);  
			    
      for (unsigned int ii = 0 ; ii < N_baryon_types ; ii++) components_parts_one_jump_mu_tab(ii).allocate (0.5 , lmax , nmax_plus_one , nmax_plus_one);
    }
  
  lj_matrices_parts_tabs_allocate_initialize (data , scalar_density_matrices_fixed_iC_out_tabs);

  for (int n_scat_out = 0 ; n_scat_out <= n_scat_max ; n_scat_out++)
    {
      const unsigned int iC_out_min = iC_out_min_process_tab(n_scat_out);
      const unsigned int iC_out_max = iC_out_max_process_tab(n_scat_out);

      if (iC_out_max < iC_out_min) continue;
      
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
      for (unsigned int iC_out = iC_out_min ; iC_out <= iC_out_max ; iC_out++)
	{
	  const int n_holes_out = n_holes_table(BP , S , 0 , n_scat_out , iC_out);
      
	  const int E_out_hw = E_hw_table(BP , S , 0 , n_scat_out , iC_out);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_outSD_set = dimensions_SD_set(BP , S , 0 , n_scat_out , iC_out , iM);

	  if (dimension_outSD_set == 0) continue;

	  const unsigned int i_thread = OpenMP_thread_number_determine ();

	  class jumps_data_out_to_in_str &one_jump_mu = one_jump_mu_tab(i_thread);

	  class array<unsigned long int> &total_PSI_in_indices_one_jump_mu = total_PSI_in_indices_one_jump_mu_tab(i_thread);

	  class array<class lj_table<TYPE> > &components_parts_one_jump_mu_tab = components_parts_one_jump_mu_tabs(i_thread);

	  class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_fixed_iC_out_tab = scalar_density_matrices_fixed_iC_out_tabs(i_thread);
  
	  const unsigned long int sum_dimensions_configuration_fixed_out = sum_dimensions_GSM_vector(n_scat_out , iC_out);

	  const unsigned long int sum_dimensions_configuration_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(n_scat_out , iC_out)) : (NADA);

	  const unsigned int dimension_outSD_set_minus_one = dimension_outSD_set - 1;

	  const unsigned long int total_PSI_OUT_index_zero = sum_dimensions_configuration_fixed_out;

	  const unsigned long int total_PSI_OUT_index_dimension_minus_one = total_PSI_OUT_index_zero + dimension_outSD_set_minus_one;
	  
	  if ((total_PSI_OUT_index_zero <= last_total_PSI_OUT_index) && (total_PSI_OUT_index_dimension_minus_one >= first_total_PSI_OUT_index))
	    {
	      const unsigned long int total_outSD_TRS_indices_zero_index = (is_it_TRS) ? (SD_TRS_indices.index_determine (BP , S , 0 , n_scat_out , iC_out , iM , 0)) : (NADA);
	      
	      const unsigned long int TRS_total_PSI_OUT_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_fixed_TRS_out) : (NADA);

	      for (unsigned int outSD_index = 0 ; outSD_index < dimension_outSD_set ; outSD_index++)
		{
		  const unsigned long int total_PSI_OUT_index = total_PSI_OUT_index_zero + outSD_index;

		  if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
		    {
		      const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;

		      const unsigned long int total_outSD_TRS_indices_index = (is_it_TRS) ? (total_outSD_TRS_indices_zero_index + outSD_index) : (NADA);

		      const unsigned int outSD_TRS_index = (is_it_TRS) ? (SD_TRS_indices[total_outSD_TRS_indices_index]) : (NADA);
		      
		      const unsigned long int TRS_total_PSI_OUT_index = (is_it_TRS) ? (TRS_total_PSI_OUT_index_zero + outSD_TRS_index) : (NADA);
			      
		      if (!is_it_TRS || (TRS_total_PSI_OUT_index >= total_PSI_OUT_index))
			{
			  const TYPE &PSI_OUT_component = PSI[PSI_OUT_index];

			  const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_OUT_index == total_PSI_OUT_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
			 
			  one_jump_mu.one_jump_mu_store (BP , S , 0 , iM , n_holes_max , n_scat_max , E_max_hw , BP , S , 0 , n_scat_out , iC_out , iM , outSD_index , data);

			  const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();

			  if (dimension_one_jump_mu > 0)
			    {
			      bool is_there_one_jump_calc = false;
			      
			      total_PSI_in_indices_pp_nn_fill (one_jump_mu , GSM_vector_helper , total_PSI_in_indices_one_jump_mu , is_there_one_jump_calc);

			      if (is_there_one_jump_calc)
				{
				  components_parts_one_jump_mu_calc (data , one_jump_mu , is_configuration_accepted_tab , total_PSI_in_indices_one_jump_mu , PSI_full , components_parts_one_jump_mu_tab);
			      
				  one_jump_mu_part_calc (components_parts_one_jump_mu_tab , PSI_OUT_component_TRS_factor , scalar_density_matrices_fixed_iC_out_tab);
				}}}}}}}}
  
  add_parts (scalar_density_matrices_fixed_iC_out_tabs , scalar_density_matrices_tab);
}











void scalar_density_matrix::diagonal_parts_pn_p_part_calc (
							   const class GSM_vector &PSI ,
							   const class GSM_vector &PSI_full ,
							   class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_p_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
	
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const unsigned int N_baryon_types = scalar_density_matrices_p_tab.dimension (0);
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector     = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const int iMp_max = prot_Y_data.get_iM_max ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const int lp_max = prot_Y_data.get_lmax ();
  const int np_max = prot_Y_data.get_nmax ();
  
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array_of_configuration &configuration_set_p = prot_Y_data.get_configuration_set ();
  
  const array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();

  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  class array<class configuration> Cp_tab(NUMBER_OF_THREADS);

  class array<class array<class nlj_table<int> > > diagonal_parts_p_fixed_iCp_tabs(NUMBER_OF_THREADS);

  class array<class array<class lj_table<class matrix<TYPE> > > > scalar_density_matrices_p_fixed_iCp_tabs(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      class array<class nlj_table<int> > &diagonal_parts_p_fixed_iCp_tab = diagonal_parts_p_fixed_iCp_tabs(i);
  
      Cp_tab(i).allocate (ZYval);
      
      diagonal_parts_p_fixed_iCp_tab.allocate (N_baryon_types);
      						    
      for (unsigned int ii = 0 ; ii < N_baryon_types ; ii++) diagonal_parts_p_fixed_iCp_tab(ii).allocate (0.5 , np_max , lp_max);
    }
  
  lj_matrices_parts_tabs_allocate_initialize (prot_Y_data , scalar_density_matrices_p_fixed_iCp_tabs);
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP);

      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;
	  
	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p;
	  
	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
		  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);

		  if (iCp_max < iCp_min) continue;
	  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
		  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
			  
		      const unsigned int i_thread = OpenMP_thread_number_determine ();

		      class configuration &Cp = Cp_tab(i_thread);
	      
		      class array<class nlj_table<int> > &diagonal_parts_p_fixed_iCp_tab = diagonal_parts_p_fixed_iCp_tabs(i_thread);

		      class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_p_fixed_iCp_tab = scalar_density_matrices_p_fixed_iCp_tabs(i_thread);
	      
		      Cp = configuration_set_p(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
		      diagonal_parts_pp_nn_fixed_configuration_calc (prot_Y_data , Cp , diagonal_parts_p_fixed_iCp_tab);

		      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
			{
			  const int iMn = iM - iMp , TRS_iMp = iMp_max - iMp;

			  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

			  if (dimension_SDp == 0) continue;
        		  
			  for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
			    {
			      const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
			      const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		      
			      for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
				{
				  const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
				  const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
				      	  
				  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
				  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			    
				  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

				  if (dimension_SDn == 0) continue;
				  
				  const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);
			    
				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS = (is_it_TRS)
				    ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , TRS_iMp))
				    : (NADA);

				  const unsigned long int total_SDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0)) : (NADA);

				  const unsigned long int total_SDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0)) : (NADA);
						  
				  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
				    {
				      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;

				      const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDn_minus_one;
  
				      if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))				    
					{			      	  
					  const unsigned long int total_SDp_TRS_indices_index = (is_it_TRS) ? (total_SDp_TRS_indices_zero_index + SDp_index) : (NADA);

					  const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_SDp_TRS_indices_index]) : (NADA);
				      
					  const unsigned long int TRS_total_PSI_index_zero_SDp_fixed = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS + dimension_SDn*SDp_TRS_index) : (NADA);
				      
					  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
					    {
					      const unsigned long int total_PSI_index = total_PSI_index_zero + SDn_index;
					  
					      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
						{
						  const unsigned long int total_SDn_TRS_indices_index = (is_it_TRS) ? (total_SDn_TRS_indices_zero_index + SDn_index) : (NADA);

						  const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_SDn_TRS_indices_index]) : (NADA);
						  
						  const unsigned long int TRS_total_PSI_index = (is_it_TRS) ? (TRS_total_PSI_index_zero_SDp_fixed + SDn_TRS_index) : (NADA);
							  
						  if (!is_it_TRS || (TRS_total_PSI_index >= total_PSI_index))
						    {
						      const TYPE &PSI_IN_component = PSI_full[total_PSI_index];

						      const TYPE PSI_IN_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_index == total_PSI_index)) ? (PSI_IN_component) : (2.0*PSI_IN_component);
						  
						      diagonal_parts_calc (diagonal_parts_p_fixed_iCp_tab , PSI_IN_component , PSI_IN_component_TRS_factor , scalar_density_matrices_p_fixed_iCp_tab);
						    }}}}}}}}}}}}}

  add_parts (scalar_density_matrices_p_fixed_iCp_tabs , scalar_density_matrices_p_tab);
}












void scalar_density_matrix::diagonal_parts_pn_n_part_calc (
							   const class GSM_vector &PSI ,
							   const class GSM_vector &PSI_full ,
							   class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_n_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const unsigned int N_baryon_types = scalar_density_matrices_n_tab.dimension (0);
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const class array_of_configuration &configuration_set_n = neut_Y_data.get_configuration_set ();
      
  const array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector     = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();

  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M ();
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();

  const int iMp_max = prot_Y_data.get_iM_max ();
    
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();

  const int ln_max = neut_Y_data.get_lmax ();
  const int nn_max = neut_Y_data.get_nmax ();
  
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  	      
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  class array<class configuration> Cn_tab(NUMBER_OF_THREADS);
  
  class array<class array<class nlj_table<int> > > diagonal_parts_n_fixed_iCn_tabs(NUMBER_OF_THREADS);

  class array<class array<class lj_table<class matrix<TYPE> > > > scalar_density_matrices_n_fixed_iCn_tabs(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      class array<class nlj_table<int> > &diagonal_parts_n_fixed_iCn_tab = diagonal_parts_n_fixed_iCn_tabs(i);
  
      Cn_tab(i).allocate (NYval);
      
      diagonal_parts_n_fixed_iCn_tab.allocate (N_baryon_types);
      						    
      for (unsigned int ii = 0 ; ii < N_baryon_types ; ii++) diagonal_parts_n_fixed_iCn_tab(ii).allocate (0.5 , nn_max , ln_max);
    }
  
  lj_matrices_parts_tabs_allocate_initialize (neut_Y_data , scalar_density_matrices_n_fixed_iCn_tabs);
  
  for (unsigned int BPn = 0 ; BPn <= 1 ; BPn++)
    {
      const unsigned int BPp = binary_parity_product (BPn , BP);

      for (int Sn = 0 ; Sn <= S ; Sn++)
	{
	  const int Sp = S - Sn;
	  
	  for (int n_spec_n = 0 ; n_spec_n <= n_spec_max ; n_spec_n++)
	    {
	      const int n_spec_p = n_spec_max - n_spec_n;
	  
	      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
		{
		  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);

		  if (iCn_max < iCn_min) continue;
	  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
		  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
		    {
		      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
		      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
			  
		      const unsigned int i_thread = OpenMP_thread_number_determine ();
	      
		      class configuration &Cn = Cn_tab(i_thread);
	      
		      class array<class nlj_table<int> > &diagonal_parts_n_fixed_iCn = diagonal_parts_n_fixed_iCn_tabs(i_thread);
	      
		      class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_n_fixed_iCn = scalar_density_matrices_n_fixed_iCn_tabs(i_thread);
	      	      
		      Cn = configuration_set_n(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
		      diagonal_parts_pp_nn_fixed_configuration_calc (neut_Y_data , Cn , diagonal_parts_n_fixed_iCn);
	      
		      for (int iMn = iMn_min_M ; iMn <= iMn_max_M ; iMn++)
			{			
			  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

			  if (dimension_SDn == 0) continue;
        
			  const int iMp = iM - iMn;

			  const int TRS_iMp = iMp_max - iMp;
		  
			  const unsigned long int total_SDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0)) : (NADA);
			  		  		  
			  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
			    {
			      const unsigned long int total_SDn_TRS_indices_index = (is_it_TRS) ? (total_SDn_TRS_indices_zero_index + SDn_index) : (NADA);

			      const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_SDn_TRS_indices_index]) : (NADA);
		
			      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
				{
				  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
				  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
				  
				  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
				    {
				      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

				      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
				      
				      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
				      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				
				      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

				      if (dimension_SDp == 0) continue;
				  
				      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

				      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

				      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS = (is_it_TRS)
					? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , TRS_iMp))
					: (NADA);
				  
				      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + SDn_index;

				      const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDn*dimension_SDp_minus_one;
  
				      if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
					{
					  const unsigned long int TRS_total_PSI_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS + SDn_TRS_index) : (NADA);
				      
					  const unsigned long int total_SDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0)) : (NADA);
				      
					  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
					    {
					      const unsigned long int total_PSI_index = total_PSI_index_zero + dimension_SDn*SDp_index;
					  
					      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
						{
						  const unsigned long int total_SDp_TRS_indices_index = (is_it_TRS) ? (total_SDp_TRS_indices_zero_index + SDp_index) : (NADA);

						  const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_SDp_TRS_indices_index]) : (NADA);
					      
						  const unsigned long int TRS_total_PSI_index = (is_it_TRS) ? (TRS_total_PSI_index_zero + dimension_SDn*SDp_TRS_index) : (NADA);

						  if (!is_it_TRS || (TRS_total_PSI_index >= total_PSI_index))
						    {
						      const TYPE &PSI_IN_component = PSI_full[total_PSI_index];

						      const TYPE PSI_IN_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_index == total_PSI_index)) ? (PSI_IN_component) : (2.0*PSI_IN_component);
					    
						      diagonal_parts_calc (diagonal_parts_n_fixed_iCn , PSI_IN_component , PSI_IN_component_TRS_factor , scalar_density_matrices_n_fixed_iCn);
						    }}}}}}}}}}}}}
  
  add_parts (scalar_density_matrices_n_fixed_iCn_tabs , scalar_density_matrices_n_tab);
}









void scalar_density_matrix::one_jump_p_parts_pn_calc (
						      const class GSM_vector &PSI ,
						      const class GSM_vector &PSI_full ,
						      class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_p_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();

  const class GSM_vector_helper_class &GSM_vector_helper_full = PSI_full.get_GSM_vector_helper ();
      
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  
  const unsigned int N_baryon_types = scalar_density_matrices_p_tab.dimension (0);
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();

  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
      
  const int lp_max = prot_Y_data.get_lmax ();
  const int np_max = prot_Y_data.get_nmax ();

  const int np_max_plus_one = np_max + 1;
    
  const unsigned long int first_total_PSI_OUT_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_OUT_index = GSM_vector_helper.get_last_total_PSI_index ();
    
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  if (total_outSDp_index_min > total_outSDp_index_max) return;
      
  class array<class jumps_data_out_to_in_str> one_jump_p_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_configuration_accepted_one_jump_p_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_in_indices_one_jump_p_tab(NUMBER_OF_THREADS);
  
  class array<class array<class lj_table<TYPE> > > components_parts_one_jump_p_tabs(NUMBER_OF_THREADS);

  class array<class array<class lj_table<class matrix<TYPE> > > > scalar_density_matrices_p_fixed_iCp_out_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      class array<class lj_table<TYPE> > &components_parts_one_jump_p_tab = components_parts_one_jump_p_tabs(i);
      
      one_jump_p_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);

      is_configuration_accepted_one_jump_p_tabs(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);

      total_PSI_in_indices_one_jump_p_tab(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);

      components_parts_one_jump_p_tab.allocate (N_baryon_types);
      
      for (unsigned int ii = 0 ; ii < N_baryon_types ; ii++) components_parts_one_jump_p_tab(ii).allocate (0.5 , lp_max , np_max_plus_one , np_max_plus_one);
    }
  
  lj_matrices_parts_tabs_allocate_initialize (prot_Y_data , scalar_density_matrices_p_fixed_iCp_out_tabs);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp = outSDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = outSDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sp = outSDp_qn.get_S ();

      const int Sn = S - Sp;
      
      const int n_spec_p = outSDp_qn.get_n_spec ();
      
      const int n_spec_n = n_spec_max - n_spec_p;
      
      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

      if (dimension_outSDp == 0) continue;
      
      const int iMn = iM - iMp;

      const int TRS_iMp = iMp_max - iMp;

      const unsigned int outSDp_index =  outSDp_qn.get_SD_index ();
 
      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index)) : (NADA);

      const unsigned int i_thread = OpenMP_thread_number_determine ();	      
	      
      class jumps_data_out_to_in_str &one_jump_p = one_jump_p_tab(i_thread);

      class array<bool> &is_configuration_accepted_one_jump_p_tab = is_configuration_accepted_one_jump_p_tabs(i_thread);

      class array<unsigned long int> &total_PSI_in_indices_one_jump_p = total_PSI_in_indices_one_jump_p_tab(i_thread);

      class array<class lj_table<TYPE> > &components_parts_one_jump_p_tab = components_parts_one_jump_p_tabs(i_thread);

      class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_p_fixed_iCp_out_tab = scalar_density_matrices_p_fixed_iCp_out_tabs(i_thread);
      
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

      if (all_dimensions_SDn_zero) continue;
		  
      bool one_jump_p_calculated = false;

      bool is_there_one_jump_calc_all = true;

      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && is_there_one_jump_calc_all ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
	  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
	  
	  for (unsigned int iCn = iCn_min ; (iCn <= iCn_max) && is_there_one_jump_calc_all ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
	      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

	      if (dimension_SDn == 0) continue;

	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , iMp);
				  
	      const unsigned long int total_PSI_OUT_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_SDn*outSDp_index;

	      const unsigned long int total_PSI_OUT_index_dimension_minus_one = total_PSI_OUT_index_zero + dimension_SDn_minus_one;
  
	      if ((total_PSI_OUT_index_zero <= last_total_PSI_OUT_index) && (total_PSI_OUT_index_dimension_minus_one >= first_total_PSI_OUT_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_SDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_OUT_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_SDn*outSDp_TRS_index) : (NADA);
				      
		  if (!one_jump_p_calculated)
		    {
		      one_jump_p.one_jump_mu_store (BPp , Sp , n_spec_p , iMp , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index , prot_Y_data);
					  
		      one_jump_p_calculated = true;
					  
		      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
					  
		      is_there_one_jump_calc_all = (dimension_one_jump_p > 0);
		    }

		  if (!is_there_one_jump_calc_all) continue;
					  
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      const unsigned long int total_PSI_OUT_index = total_PSI_OUT_index_zero + SDn_index;

		      if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
			{
			  const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;
					      
			  const unsigned long int total_SDn_TRS_indices_index = (is_it_TRS) ? (total_SDn_TRS_indices_zero_index + SDn_index) : (NADA);

			  const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_SDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_OUT_index = (is_it_TRS) ? (TRS_total_PSI_OUT_index_zero + SDn_TRS_index) : (NADA);
						      
			  if (!is_it_TRS || (TRS_total_PSI_OUT_index >= total_PSI_OUT_index))
			    {
			      bool is_there_one_jump_calc = false;
						  
			      is_configuration_accepted_total_PSI_in_indices_p_fill (BPn , Sn , n_spec_n , n_holes_n , n_scat_n , iCn , iMn , SDn_index , En_hw , one_jump_p , GSM_vector_helper_full , dimension_SDn ,
										     is_configuration_accepted_one_jump_p_tab , total_PSI_in_indices_one_jump_p , is_there_one_jump_calc);

			      if (is_there_one_jump_calc)
				{
				  const TYPE &PSI_OUT_component = PSI[PSI_OUT_index];

				  const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_OUT_index == total_PSI_OUT_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
				  
				  components_parts_one_jump_mu_calc (prot_Y_data , one_jump_p , is_configuration_accepted_one_jump_p_tab , total_PSI_in_indices_one_jump_p , PSI_full , components_parts_one_jump_p_tab);
				  
				  one_jump_mu_part_calc (components_parts_one_jump_p_tab , PSI_OUT_component_TRS_factor , scalar_density_matrices_p_fixed_iCp_out_tab);
				}}}}}}}}
      
  add_parts (scalar_density_matrices_p_fixed_iCp_out_tabs , scalar_density_matrices_p_tab);
}














void scalar_density_matrix::one_jump_n_parts_pn_calc (
						      const class GSM_vector &PSI ,
						      const class GSM_vector &PSI_full ,
						      class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_n_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();

  const class GSM_vector_helper_class &GSM_vector_helper_full = PSI_full.get_GSM_vector_helper ();
      
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const unsigned int N_baryon_types = scalar_density_matrices_n_tab.dimension (0);
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();

  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M ();
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();
  
  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const int ln_max = neut_Y_data.get_lmax ();
  const int nn_max = neut_Y_data.get_nmax ();

  const int nn_max_plus_one = nn_max + 1;
  
  const unsigned long int first_total_PSI_OUT_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_OUT_index = GSM_vector_helper.get_last_total_PSI_index ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
  
  const array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();

  const array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
  
  class array<class jumps_data_out_to_in_str> one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_configuration_accepted_one_jump_n_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned long int> > total_PSI_in_indices_one_jump_n_tab(NUMBER_OF_THREADS);
  
  class array<class array<class lj_table<TYPE> > > components_parts_one_jump_n_tabs(NUMBER_OF_THREADS);

  class array<class array<class lj_table<class matrix<TYPE> > > > scalar_density_matrices_n_fixed_iCn_out_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      class array<class lj_table<TYPE> > &components_parts_one_jump_n_tab = components_parts_one_jump_n_tabs(i);
      
      one_jump_n_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);

      is_configuration_accepted_one_jump_n_tabs(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);

      total_PSI_in_indices_one_jump_n_tab(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);

      components_parts_one_jump_n_tab.allocate (N_baryon_types);
      
      for (unsigned int ii = 0 ; ii < N_baryon_types ; ii++) components_parts_one_jump_n_tab(ii).allocate (0.5 , ln_max , nn_max_plus_one , nn_max_plus_one);
    }
  
  lj_matrices_parts_tabs_allocate_initialize (neut_Y_data , scalar_density_matrices_n_fixed_iCn_out_tabs);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn = outSDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = outSDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sn = outSDn_qn.get_S ();

      const int Sp = S - Sn;
      
      const int n_spec_n = outSDn_qn.get_n_spec ();
      
      const int n_spec_p = n_spec_max - n_spec_n;

      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

      if (dimension_outSDn == 0) continue;

      const int iMp = iM - iMn;

      const int TRS_iMp = iMp_max - iMp;
            
      const unsigned int outSDn_index =  outSDn_qn.get_SD_index ();
      
      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index)) : (NADA);
      
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

      if (all_dimensions_SDp_zero) continue;
		  
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	      
      class jumps_data_out_to_in_str &one_jump_n = one_jump_n_tab(i_thread);

      class array<bool> &is_configuration_accepted_one_jump_n_tab = is_configuration_accepted_one_jump_n_tabs(i_thread);

      class array<unsigned long int> &total_PSI_in_indices_one_jump_n = total_PSI_in_indices_one_jump_n_tab(i_thread);

      class array<class lj_table<TYPE> > &components_parts_one_jump_n_tab = components_parts_one_jump_n_tabs(i_thread);

      class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_n_fixed_iCn_out_tab = scalar_density_matrices_n_fixed_iCn_out_tabs(i_thread);

      bool one_jump_n_calculated = false;

      bool is_there_one_jump_calc_all = true;
  
      for (int n_scat_p = 0 ; n_scat_p <= (n_scat_max_p) && is_there_one_jump_calc_all ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  
	  for (unsigned int iCp = iCp_min ; (iCp <= iCp_max) && is_there_one_jump_calc_all ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

	      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

	      if (dimension_SDp == 0) continue;

	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

	      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , iMp);

	      const unsigned long int total_PSI_OUT_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;

	      const unsigned long int total_PSI_OUT_index_dimension_minus_one = total_PSI_OUT_index_zero + dimension_SDp_minus_one*dimension_outSDn;
  
	      if ((total_PSI_OUT_index_zero <= last_total_PSI_OUT_index) && (total_PSI_OUT_index_dimension_minus_one >= first_total_PSI_OUT_index))
		{
		  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , TRS_iMp)) : (NADA);

		  const unsigned long int total_SDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0)) : (NADA);
				      
		  const unsigned long int TRS_total_PSI_OUT_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);
				      
		  if (!one_jump_n_calculated)
		    {
		      one_jump_n.one_jump_mu_store (BPn , Sn , n_spec_n , iMn , n_holes_max_n , n_scat_max_n , En_max_hw , BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index , neut_Y_data);
					  
		      one_jump_n_calculated = true;

		      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
					  
		      is_there_one_jump_calc_all = (dimension_one_jump_n > 0);					  
		    }

		  if (!is_there_one_jump_calc_all) continue;
					  
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      const unsigned long int total_PSI_OUT_index = total_PSI_OUT_index_zero + dimension_outSDn*SDp_index;

		      if ((total_PSI_OUT_index >= first_total_PSI_OUT_index) && (total_PSI_OUT_index <= last_total_PSI_OUT_index))
			{
			  const unsigned int PSI_OUT_index = total_PSI_OUT_index - first_total_PSI_OUT_index;

			  const unsigned long int total_SDp_TRS_indices_index = (is_it_TRS) ? (total_SDp_TRS_indices_zero_index + SDp_index) : (NADA);

			  const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_SDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned long int TRS_total_PSI_OUT_index = (is_it_TRS) ? (TRS_total_PSI_OUT_index_zero + dimension_outSDn*SDp_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_total_PSI_OUT_index >= total_PSI_OUT_index))
			    { 
			      bool is_there_one_jump_calc = false;
		      
			      is_configuration_accepted_total_PSI_in_indices_n_fill (BPp , Sp , n_spec_p , n_holes_p , n_scat_p , iCp , iMp , SDp_index , Ep_hw , one_jump_n , GSM_vector_helper_full , 
										     is_configuration_accepted_one_jump_n_tab , total_PSI_in_indices_one_jump_n , is_there_one_jump_calc);

			      if (is_there_one_jump_calc)
				{
				  const TYPE &PSI_OUT_component = PSI[PSI_OUT_index];

				  const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_total_PSI_OUT_index == total_PSI_OUT_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
				  
				  components_parts_one_jump_mu_calc (neut_Y_data , one_jump_n , is_configuration_accepted_one_jump_n_tab , total_PSI_in_indices_one_jump_n , PSI_full , components_parts_one_jump_n_tab);
				  
				  one_jump_mu_part_calc (components_parts_one_jump_n_tab , PSI_OUT_component_TRS_factor , scalar_density_matrices_n_fixed_iCn_out_tab);
				}}}}}}}}
  
  add_parts (scalar_density_matrices_n_fixed_iCn_out_tabs , scalar_density_matrices_n_tab);
}











void scalar_density_matrix::calc (
				  const class GSM_vector &PSI ,
				  const class GSM_vector &PSI_full ,
				  class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_p_tab ,
				  class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_n_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper = PSI.get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
     
  switch (space)
    {
    case PROT_Y_ONLY:
      {
	pp_nn_diagonal_parts_calc (PSI , PSI_full , scalar_density_matrices_p_tab);
	pp_nn_one_jump_parts_calc (PSI , PSI_full , scalar_density_matrices_p_tab);
      } break;
      
    case NEUT_Y_ONLY:
      {
	pp_nn_diagonal_parts_calc (PSI , PSI_full , scalar_density_matrices_n_tab);
	pp_nn_one_jump_parts_calc (PSI , PSI_full , scalar_density_matrices_n_tab);
      } break;

    case PROT_NEUT_Y:
      {
	diagonal_parts_pn_p_part_calc (PSI , PSI_full , scalar_density_matrices_p_tab);	    
	diagonal_parts_pn_n_part_calc (PSI , PSI_full , scalar_density_matrices_n_tab);
  
	one_jump_p_parts_pn_calc (PSI , PSI_full , scalar_density_matrices_p_tab);	    
	one_jump_n_parts_pn_calc (PSI , PSI_full , scalar_density_matrices_n_tab);
      } break;

    default: abort_all ();
    }
  
#ifdef UseMPI

  const bool is_it_MPI_parallelized_local = GSM_vector_helper.get_is_it_MPI_parallelized_local ();
	
  if (is_it_MPI_parallelized_local)
    {
      MPI_helper::Barrier ();
      
      if (space != NEUT_Y_ONLY) lj_matrices_tab_MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD , scalar_density_matrices_p_tab);
      if (space != PROT_Y_ONLY) lj_matrices_tab_MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD , scalar_density_matrices_n_tab);
    }
  
#endif

  if (THIS_PROCESS == MASTER_PROCESS)
    {  
      if (space != NEUT_Y_ONLY) fill_upper_part (scalar_density_matrices_p_tab);
      if (space != PROT_Y_ONLY) fill_upper_part (scalar_density_matrices_n_tab);
  
      if (space != NEUT_Y_ONLY) normalize (ZYval , scalar_density_matrices_p_tab);
      if (space != PROT_Y_ONLY) normalize (NYval , scalar_density_matrices_n_tab);
    }
}

