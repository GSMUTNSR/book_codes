#include "../GSM_include/GSM_include_def.h"

using namespace string_routines;
using namespace inputs_misc;
using namespace GSM_vector_dimensions;

// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------





// See GSM_MSDHF_potentials.cpp for definitions and general explanations related to the MSDHF potential
// ----------------------------------------------------------------------------------------------------




// Calculation of the Slater determinant expansion of a_{k l j m'} |Psi[k]> for a fixed (l,j) partial wave and all m quantum numbers
// ---------------------------------------------------------------------------------------------------------------------------------
// |Psi[GS]> has been calculated in a basis of Slater determinants, and |Psi[k]> = [a+_{k l j} a~_{n l j}]^0_0 |Psi[GS]>.
// Thus, |Psi[GS]> \propto \sum_{m} a+_{k l j m} a_{n l j m} | Psi[GS]> => a_{k l j m} |Psi[k]> \propto a_{n l j m} | Psi[GS]>.
// The constant of proportionality is -1/hat(j) and is ignored (see GSM_MSDHF_potentials.cpp).
// Thus, one justs applies a_{k l j m} to the Slater determinant basis expansion of |Psi[GS]>,
// which provides for the Slater determinant basis expansion of a_{k l j m} |Psi[k]> ~ a_{n l j m} | Psi[GS]>.
// It is a_{n l j m} | Psi[GS]> which is effectively calculated.
// If |n l j m> is occupied in |Psi[GS]>, a_{n l j m} | Psi[GS]> = 0 and is not calculated.
// An array of booleans is also defined here, which states whether a_{n l j m} | Psi[GS]> = 0 or not.
//
// |Psi[GS]> = \sum_{i} c[i] |SDi[GS]> and a_{k l j m} |Psi[k]> = \sum_{j} d[j] |SDj[k]>, where the |k l j m> state is not present in |SDj[k]>, and d[j] depends on m.
//
// One considers proton or neutron (l,j) partial waves only.

void MSDHF_potentials::one_configuration::SDs_1h_coefficients_alloc_calc (
									  const class nucleons_data &data_one_configuration , 
									  const unsigned int new_dimension_GS , 
									  const int highest_occupied_lj_n , 
									  const int l , 
									  const double j , 
									  class HF_nucleons_data &HF_data)
{
  const enum particle_type particle = HF_data.get_particle ();
  
  const int N_valence_nucleons = data_one_configuration.get_N_valence_nucleons_basis ();

  const int N_valence_nucleons_minus_one = N_valence_nucleons - 1;
  
  const class one_body_indices_str &one_body_indices = data_one_configuration.get_one_body_indices ();

  const int im_number = make_int (2*j + 1.0);

  const class lj_table<class array<class Slater_determinant> > &SDs_GS = (particle == PROTON) ? (HF_data.get_prot_SDs_GS ()) : (HF_data.get_neut_SDs_GS ());
  
  const class lj_table<class array<complex<double> > > &SDs_GS_coefficients = HF_data.get_SDs_GS_coefficients ();

  const class array<class Slater_determinant> &SDs_GS_lj = SDs_GS(l , j);

  const class array<complex<double> > &SDs_GS_coefficients_lj = SDs_GS_coefficients(l , j);

  class lj_table<class array<class Slater_determinant> > &SDs_1h = HF_data.get_SDs_1h ();

  class lj_table<class array<complex<double> > > &SDs_1h_coefficients = HF_data.get_SDs_1h_coefficients ();

  class lj_table<class array<bool> > &SDs_1h_existence_table = HF_data.get_SDs_1h_existence_table ();

  class array<class Slater_determinant> &SDs_1h_lj = SDs_1h(l , j);

  class array<complex<double> > &SDs_1h_coefficients_lj = SDs_1h_coefficients(l , j);

  class array<bool> &SDs_1h_existence_table_lj = SDs_1h_existence_table(l , j);

  SDs_1h_lj.deallocate ();
  SDs_1h_lj.allocate (new_dimension_GS , im_number);

  SDs_1h_coefficients_lj.deallocate ();
  SDs_1h_coefficients_lj.allocate (new_dimension_GS , im_number);

  SDs_1h_existence_table_lj.deallocate ();
  SDs_1h_existence_table_lj.allocate (new_dimension_GS , im_number);

  for (int im = 0 ; im < im_number ; im++)
    {  
      const double m = im - j;
      
      const unsigned int s = one_body_indices(highest_occupied_lj_n , l , j , m);

      for (unsigned int i_GS = 0 ; i_GS < new_dimension_GS ; i_GS++) 
	{
	  const class Slater_determinant &SD_GS_lj = SDs_GS_lj(i_GS);
	  
	  const complex<double> SD_GS_coefficient = SDs_GS_coefficients_lj(i_GS);

	  if (SD_GS_lj.is_valence_state_occupied (s))
	    { 
	      SDs_1h_lj(i_GS , im).allocate (N_valence_nucleons_minus_one);

	      class Slater_determinant &SD_1h_lj = SDs_1h_lj(i_GS , im);

	      unsigned int bin_phase = 0;

	      SD_GS_lj.excitation_1h_and_bin_phase (s , SD_1h_lj , bin_phase);

	      const int phase = parity_from_binary_parity (bin_phase);
		  
	      SDs_1h_coefficients_lj(i_GS , im) = (phase == 1) ? (SD_GS_coefficient) : (-SD_GS_coefficient);

	      SDs_1h_existence_table_lj(i_GS , im) = true;
	    }
	  else
	    {
	      SDs_1h_existence_table_lj(i_GS , im) = false;

	      SDs_1h_coefficients_lj(i_GS , im) = NADA;
	    }
	} 
    }
}


// Storage of the Slater determinants coming from the expansion of |Psi[GS]> for a fixed (l,j) partial wave
// --------------------------------------------------------------------------------------------------------
// |Psi[GS]> = \sum_{i} c[i] |SDi[GS]> (see GSM_MSDHF_potentials.cpp)
// As one needs to know the occupied states of |SDi[GS]> states, and as GSM vector space dimension is very small,
// one explicitely stored Slater determinants as class Slater_determinant in an array.
// The array of Slater determinants and Slater determinants are reallocated here.
// See GSM_vector_one_configuration.cpp for the routine basis_SD_from_index providing with basis Slater determinants from a GSM vector.

void MSDHF_potentials::one_configuration::SDs_GS_alloc_fill (
							     const enum space_type SD_space , 
							     const class GSM_vector_one_configuration &PSI , 
							     const int N_valence_nucleons , 
							     const unsigned int new_dimension_GS , 
							     const int l , 
							     const double j , 
							     class HF_nucleons_data &HF_data)
{
  class lj_table<class array<class Slater_determinant> > &SDs_GS = (SD_space == PROTONS_ONLY) ? (HF_data.get_prot_SDs_GS ()) : (HF_data.get_neut_SDs_GS ());

  class array<class Slater_determinant> &SDs_GS_lj = SDs_GS(l , j);

  SDs_GS_lj.deallocate ();
  SDs_GS_lj.allocate (new_dimension_GS);

  for (unsigned int i_GS = 0 ; i_GS < new_dimension_GS ; i_GS++)
    {
      class Slater_determinant &SD_GS_lj = SDs_GS_lj(i_GS);

      if (N_valence_nucleons > 0)
	{
	  SD_GS_lj.allocate (N_valence_nucleons);
	      
	  SD_GS_lj = PSI.basis_SD_from_index (SD_space , i_GS); 
	}
    }
}








// Storage of the configuration in which GSM diagonalization is performed for MSDHF and of its quantum numbers
// -----------------------------------------------------------------------------------------------------------
// The configuration in which GSM diagonalization is performed has been determined in occupied_poles_configurations_to_diagonalize_determine (see GSM_HF_wave_function.cpp).
// If one looks for the proton configuration for proton MSDHF potentials, or for the neutron configuration for neutron MSDHF potentials, 
// it is looked for in an array depending on parity and configuration index, and binary and configuration index are stored once found.
//
// For proton  MSDHF potentials, the neutron configuration is the ground state configuration, as there is no variation acting on neutron states when calculating proton  MSDHF potentials.
// For neutron MSDHF potentials, the proton  configuration is the ground state configuration, as there is no variation acting on proton  states when calculating neutron MSDHF potentials.

void MSDHF_potentials::one_configuration::configuration_to_diagonalize_index_BP_determine (
											   const enum space_type space , 
											   const int l , 
											   const double j , 
											   const class HF_nucleons_data &HF_data , 
											   class nucleons_data &data_one_configuration)
{
  const enum particle_type particle_HF = HF_data.get_particle ();

  const enum particle_type particle_data_one_configuration = data_one_configuration.get_particle ();

  if ((space == PROTONS_ONLY)  && (particle_HF == NEUTRON)) return;
  if ((space == NEUTRONS_ONLY) && (particle_HF == PROTON))  return;

  const int N_valence_nucleons = data_one_configuration.get_N_valence_nucleons ();
  
  const class array<unsigned int> &dimensions_configuration_set = data_one_configuration.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data_one_configuration.get_configuration_set ();

  class configuration C(N_valence_nucleons);
  
  if (particle_HF == particle_data_one_configuration)
    {   
      const class lj_table<class configuration> &configurations_to_diagonalize = HF_data.get_configurations_to_diagonalize ();

      const class configuration &configuration_to_diagonalize_lj = configurations_to_diagonalize(l , j);

      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
	{
	  const unsigned int dimension_configuration_set_BP_n_scat = dimensions_configuration_set(BP , 0);

	  for (unsigned int iC = 0 ; iC < dimension_configuration_set_BP_n_scat ; iC++)
	    {
	      C = configuration_set(BP , 0 , iC);

	      if (C == configuration_to_diagonalize_lj)
		{
		  data_one_configuration.set_BP_iC_one_configuration (BP , iC);

		  return;
		}
	    }
	}
    }
  else
    {
      const int N_valence_nucleons = data_one_configuration.get_N_valence_nucleons ();

      if (N_valence_nucleons == 0) return;

      const class array<class nlj_struct> &shells_qn = data_one_configuration.get_shells_quantum_numbers ();

      class configuration C_GS(N_valence_nucleons);

      C_GS.ground_state (0 , shells_qn);

      const unsigned int BP = C_GS.BP_determine (shells_qn);

      const unsigned int dimension_configuration_set_BP_n_scat = dimensions_configuration_set(BP , 0);

      for (unsigned int iC = 0 ; iC < dimension_configuration_set_BP_n_scat ; iC++)
	{
	  C = configuration_set(BP , 0 , iC);

	  if (C == C_GS)
	    {
	      data_one_configuration.set_BP_iC_one_configuration (BP , iC);
	      
	      return;
	    }
	}
    }

  error_message_print_abort ("No MSDHF configuration found in MSDHF_potentials::one_configuration::configuration_to_diagonalize_index_BP_determine ");
}





// Calculation of all gSM vectors |Psi[GS]> for all (l,j) partial waves of proton or neutron character
// ---------------------------------------------------------------------------------------------------
// One loop over proton or neutron (l,j) partial waves, one generates the model space of total angular momentum M and M+1 (for J+ application in J^2),
// one generates GSM vector helper classes (see GSM_vector_helper_one_configuration_class.cpp) to apply Hamiltonian and J^2 operators, one diagonalizes Hamiltonian with the Lanczos method,
// and one calls previous routines to store basis Slater determinants and generate a_{k l j m} |Psi[k]>.
// The array of Slater coefficients c[i] is obtained from the GSM eigenvector, as well as its recalculated dimension.

void MSDHF_potentials::one_configuration::HF_many_body_data_alloc_calc (
									const bool is_there_cout , 
									const enum space_type space , 
									const enum interaction_type inter , 
									const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
									const class TBMEs_class &TBMEs_pn , 
									class nucleons_data &prot_data_one_configuration , 
									class nucleons_data &neut_data_one_configuration , 
									class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj_HF = HF_data.get_N_nlj ();
  
  if (N_nlj_HF == 0) return;

  const enum particle_type particle = HF_data.get_particle ();

  const class nucleons_data &data_one_configuration = (particle == PROTON) ? (prot_data_one_configuration) : (neut_data_one_configuration);
  
  const int lmax_HF = HF_data.get_lmax ();
  
  const int Zval = prot_data_one_configuration.get_N_valence_nucleons_basis ();
  const int Nval = neut_data_one_configuration.get_N_valence_nucleons_basis ();

  const class lj_table<bool> &is_partial_wave_optimized_HF_MSDHF_tab = HF_data.get_is_partial_wave_optimized_HF_MSDHF_tab ();

  const class lj_table<int> &highest_occupied_n_tab = HF_data.get_highest_occupied_n_tab ();

  class lj_table<unsigned int> &dimensions_GS = HF_data.get_dimensions_GS ();

  dimensions_GS = 0;

  class lj_table<class array<complex<double> > > &SDs_GS_coefficients = HF_data.get_SDs_GS_coefficients ();

  for (int l = 0 ; l <= lmax_HF ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	if (is_partial_wave_optimized_HF_MSDHF_tab(l , j))
	  {
	    const class correlated_state_str&basis_PSI_qn = basis_PSI_qn_tab(l , j);

	    if (basis_PSI_qn.get_is_it_filled ())
	      {
		const double J = basis_PSI_qn.get_J ();

		const unsigned int BP = basis_PSI_qn.get_BP ();

		configuration_to_diagonalize_index_BP_determine (space , l , j , HF_data , prot_data_one_configuration);
		configuration_to_diagonalize_index_BP_determine (space , l , j , HF_data , neut_data_one_configuration);

		const unsigned int dimension_BP_J = BP_J_dimension_calc_print_one_configuration (space , prot_data_one_configuration , neut_data_one_configuration , BP , J);

		//const class lj_table<class configuration > &configurations_to_diagonalize = HF_data.get_configurations_to_diagonalize ();
		//const class configuration &configuration_to_diagonalize_lj = configurations_to_diagonalize(l , j);
		//configuration_to_diagonalize_lj.print (HF_data.get_shells_quantum_numbers_res ());

		//if (space == PROTONS_ONLY)
		// cout << "id: " << THIS_PROCESS << " " << J_Pi_string (BP , J) << " " << particle << " " << angular_state (l , j) << " BP[p]: " << prot_data_one_configuration.get_BP_one_configuration () << endl;
		//
		//if (space == NEUTRONS_ONLY)
		// cout << "id: " << THIS_PROCESS << " " << J_Pi_string (BP , J) << " " << particle << " " << angular_state (l , j) << " BP[n]: " << neut_data_one_configuration.get_BP_one_configuration () << endl;
		//
		// if (space == PROTONS_NEUTRONS)
		// cout << "id: " << THIS_PROCESS << " " << J_Pi_string (BP , J) << " " << particle << " " << angular_state (l , j) << " BP[p]: "
		// << prot_data_one_configuration.get_BP_one_configuration () << " BP[n]: " << neut_data_one_configuration.get_BP_one_configuration () << " dimension(BP , J): " << dimension_BP_J << endl;

		if (dimension_BP_J > 0)
		  {
		    const double M = optimal_M_calc_one_configuration (space , prot_data_one_configuration , neut_data_one_configuration , J);

		    const double Mp1 = M + 1.0;

		    const unsigned int dimension_GS = total_space_dimension_M_calc_one_configuration (space , prot_data_one_configuration , neut_data_one_configuration , M);

		    const class GSM_vector_helper_one_configuration_class GSM_vector_helper_one_configuration_M  (space , inter , prot_data_one_configuration , neut_data_one_configuration , J , M   , true);
		    const class GSM_vector_helper_one_configuration_class GSM_vector_helper_one_configuration_Mp1(space , inter , prot_data_one_configuration , neut_data_one_configuration , J , Mp1 , true);

		    class GSM_vector_one_configuration PSI(GSM_vector_helper_one_configuration_M);

		    configuration_SD_in_space_one_jump_only_basis::configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (GSM_vector_helper_one_configuration_M , GSM_vector_helper_one_configuration_Mp1 ,
																prot_data_one_configuration , neut_data_one_configuration);
		    
		    Lanczos_one_configuration::iterative_diagonalization_lowest_states (is_there_cout , GSM_vector_helper_one_configuration_M , GSM_vector_helper_one_configuration_Mp1 , TBMEs_pn , dimension_BP_J , J , PSI);

		    SDs_GS_alloc_fill (PROTONS_ONLY  , PSI , Zval , dimension_GS , l , j , HF_data);
		    SDs_GS_alloc_fill (NEUTRONS_ONLY , PSI , Nval , dimension_GS , l , j , HF_data);

		    SDs_GS_coefficients(l , j).deallocate ();
		    SDs_GS_coefficients(l , j).allocate (dimension_GS);

		    class array<complex<double> > &SDs_GS_coefficients_lj = SDs_GS_coefficients(l , j);

		    for (unsigned int i = 0 ; i < dimension_GS ; i++) SDs_GS_coefficients_lj(i) = PSI[i];

		    const int highest_occupied_lj_n = highest_occupied_n_tab(l , j);

		    SDs_1h_coefficients_alloc_calc (data_one_configuration , dimension_GS , highest_occupied_lj_n , l , j , HF_data);

		    dimensions_GS(l , j) = dimension_GS;
		    
		    prot_data_one_configuration.one_jump_tables_Jpm_out_to_in_deallocate ();
		    neut_data_one_configuration.one_jump_tables_Jpm_out_to_in_deallocate ();

		    prot_data_one_configuration.one_jump_tables_out_to_in_deallocate ();
		    neut_data_one_configuration.one_jump_tables_out_to_in_deallocate ();
		  }
	      }
	  }
      }
}

void MSDHF_potentials::one_configuration::all_HF_many_body_data_alloc_calc (
									    const bool is_there_cout , 
									    const class input_data_str &input_data , 
									    const class interaction_class &inter_data ,
									    const class TBMEs_class &TBMEs_pn ,
									    class nucleons_data &prot_data_one_configuration , 
									    class nucleons_data &neut_data_one_configuration , 
									    class HF_nucleons_data &prot_HF_data , 
									    class HF_nucleons_data &neut_HF_data)
{
  const enum space_type basis_space = input_data.get_basis_space ();

  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  const class lj_table<class correlated_state_str> &prot_basis_PSI_qn_tab = prot_data_one_configuration.get_basis_PSI_quantum_numbers_tab ();
  const class lj_table<class correlated_state_str> &neut_basis_PSI_qn_tab = neut_data_one_configuration.get_basis_PSI_quantum_numbers_tab ();
  
  HF_many_body_data_alloc_calc (is_there_cout , basis_space , TBME_inter , prot_basis_PSI_qn_tab , TBMEs_pn , prot_data_one_configuration , neut_data_one_configuration , prot_HF_data);
  HF_many_body_data_alloc_calc (is_there_cout , basis_space , TBME_inter , neut_basis_PSI_qn_tab , TBMEs_pn , prot_data_one_configuration , neut_data_one_configuration , neut_HF_data);
}











// Allocation and calculation of nucleons data, OBMEs, TBMEs, and jumps associated to the optimized optimization at MSDHF level
// ----------------------------------------------------------------------------------------------------------------------------
// Proton and neutron class nucleons-data are allocated here from already existing arrays for MSDHF potentials.
// OBMEs, TBMEs are calculated, removing double counting OBMEs and TBMEs one has holes (see GSM_hole_double_counting.cpp)
// 1p-1h and -2p-2h jumps are calculated and stored to be able to apply Hamiltonian and J^2 operators.
// This routine is called at every MSDHF iteration.
// Its cost is however, very small if not negligible, as the most expensive part is the calculation of scattering states, which had to be parallelized.

void MSDHF_potentials::one_configuration::data_alloc_calc (
							   const class input_data_str &input_data , 
							   const class nucleons_data &prot_data , 
							   const class nucleons_data &neut_data , 
							   const class interaction_class &inter_data , 
							   const class HF_nucleons_data &prot_HF_data , 
							   const class HF_nucleons_data &neut_HF_data , 
							   class nucleons_data &prot_data_one_configuration , 
							   class nucleons_data &neut_data_one_configuration ,
							   class TBMEs_class &TBMEs_pn)
{
  const enum space_type basis_space = input_data.get_basis_space ();

  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const class array<class array<class JT_coupled_TBME> > dummy_JT_TBMEs;

  const bool is_hole_double_counting_suppressed = input_data.get_is_hole_double_counting_suppressed ();
  
  prot_data_one_configuration.data_MSDHF_one_configuration_one_body_alloc_fill (input_data , inter_data , prot_data , prot_HF_data);
  neut_data_one_configuration.data_MSDHF_one_configuration_one_body_alloc_fill (input_data , inter_data , neut_data , neut_HF_data);

  OBMEs_TBMEs::all_OBMEs_TBMEs_alloc_calc (false , true , dummy_JT_TBMEs , inter_data , inter_data , input_data , prot_data_one_configuration , neut_data_one_configuration , TBMEs_pn);

  if (basis_space != NEUTRONS_ONLY)
    {
      class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data_one_configuration.get_OBMEs_inter_set ();
      
      hole_double_counting::prot_OBMEs_calc_store (is_hole_double_counting_suppressed , false , basis_space , 0 , TBMEs_pn , neut_data_one_configuration , prot_data_one_configuration);

      if (is_hole_double_counting_suppressed) prot_OBMEs_inter_set (TBME_inter) -= prot_OBMEs_inter_set (HOLE_DOUBLE_COUNTING);
    }
    
  if (basis_space != PROTONS_ONLY)
    {
      class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data_one_configuration.get_OBMEs_inter_set ();
      
      hole_double_counting::neut_OBMEs_calc_store (is_hole_double_counting_suppressed , false , basis_space , 0 , TBMEs_pn , prot_data_one_configuration , neut_data_one_configuration);

      if (is_hole_double_counting_suppressed) neut_OBMEs_inter_set (TBME_inter) -= neut_OBMEs_inter_set (HOLE_DOUBLE_COUNTING);
    }
    
  configuration_SD_sets::configuration_SD_tables_pp_nn_alloc_calc (false , true , false , input_data , prot_data_one_configuration , neut_data_one_configuration);
}


