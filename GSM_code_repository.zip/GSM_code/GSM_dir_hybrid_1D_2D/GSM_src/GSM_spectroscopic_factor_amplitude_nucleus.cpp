#include "../GSM_include/GSM_include_def.h"


using namespace inputs_misc;
using namespace correlated_state_routines;
using namespace A_dagger_cluster_helper;

// TYPE is double or complex
// -------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons
// ------------------------------------------------------------------------------------------------------------------------------------------------------




// Calculation of spectroscopic factor amplitude involving one nucleus
// -------------------------------------------------------------------
// Spectroscopic factors and overlap functions are related to transfer reactions:
// A stripping reaction removes a cluster from the projectile and then adds it to the target.
// A pick-up reaction adds a cluster to the projectile after removing it from the target.
//
// One considers spectroscopic factor amplitudes of one cluster, or nucleus, as its wave function is that of a GSM vector issued from a structure calculation.
// The latter cluster is called the projectile/ejectile for stripping/pick-up and the initial nucleus the target.
// 
// Spectroscopic factors are of the form S = (<Psi[out] || A+_{cluster} || Psi[in]>^J[out]/hat(J[out]))^2 for stripping
//                                   and S = (<Psi[out] || A~_{cluster} || Psi[in]>^J[out]/hat(J[in]))^2  for pick-up
//
// The spectroscopic amplitude is defined to be equal to <Psi[out] | A+_{cluster M[cluster]} | Psi[in]> for stripping, with M[cluster] = M[out] - M[in]
//                                                   and <Psi[out] | A~_{cluster M[cluster]} | Psi[in]> for pick-up,   with M[cluster] = M[in]  - M[out]
//
// One uses M[in] = J[in] and M[out] = J[out] for convenience.

// Spectroscopic factor directly follows from reduced matrix elements function of A+_{NCM[HO] LCM J[cluster]} and A~_{NCM[HO] LCM J[cluster]}.
//
// |Psi[out]> is given as input and |Psi[in]> will be read from disk from its provided quantum numbers.
//
// Different routines are used for stripping and pick-up, for proton or neutron projectiles, and if one has both valence protons and neutrons, or only valence protons or neutrons.
//
// mu is for proton or neutron in routines where one hase only valence protons or neutrons.
//
// The GSM vectors resulting from the action of A+ or A~ on |Psi[in]> are meaningful only in the master process, even if it is not written.
//
// 
// stripping_pn_calc, stripping_pp_nn_calc
// ---------------------------------------
// Routines calculating spectroscopic factor amplitudes for cluster projectile,
// if one has both valence protons and neutrons, or only valence protons or neutrons for stripping reactions.
// 
// pick_up_pn_calc, pick_up_pp_nn_calc
// -----------------------------------
// Routines calculating spectroscopic factor amplitudes for cluster ejectile
// and if one has both valence protons and neutrons, or only valence protons or neutrons for pick-up reactions.
//
// stripping_calc, pick_up_calc
// ----------------------------
// Routines calling previous routines for stripping or pick-up.


TYPE spectroscopic_factor_amplitude::nucleus::stripping_pn_calc (
								 const bool full_common_vectors_used_in_file ,
								 const class correlated_state_str &PSI_IN_qn , 
								 const class correlated_state_str &PSI_cluster_qn ,
								 const double M_cluster , 
								 const class GSM_vector &PSI_OUT)
{  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const int Z_core = prot_data.get_Z_core ();
  const int N_core = prot_data.get_N_core ();
  
  const int Z_IN = PSI_IN_qn.get_Z ();
  const int N_IN = PSI_IN_qn.get_N ();
  
  const int prot_hole_states_number = prot_data.get_hole_states_number ();
  const int neut_hole_states_number = neut_data.get_hole_states_number ();
  
  const int Zval_IN = Z_IN - Z_core + prot_hole_states_number;
  const int Nval_IN = N_IN - N_core + neut_hole_states_number;
    
  const int Z_cluster = PSI_cluster_qn.get_Z ();
  const int N_cluster = PSI_cluster_qn.get_N ();
  
  const double M_IN = M_OUT - M_cluster;
  
  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);

  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Zval_IN , Nval_IN , file_name_IN_dimension);
    
  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));
  
  const string file_name_cluster_dimension = file_name_eigenvector_string (true , "eigenvector_dimension" , PSI_cluster_qn , M_cluster);
  
  const unsigned int space_dimension_cluster = space_dimension_read_disk (true , Z_cluster , N_cluster , file_name_cluster_dimension);

  const unsigned int space_dimension_cluster_max = max_Allreduce<unsigned int> (is_it_MPI_parallelized_local , space_dimension_cluster);
  
  class array<unsigned int> SDp_IN_tab(space_dimension_IN , Zval_IN);
  class array<unsigned int> SDn_IN_tab(space_dimension_IN , Nval_IN);

  class array<unsigned int> SDp_cluster_tab(space_dimension_cluster , Z_cluster);
  class array<unsigned int> SDn_cluster_tab(space_dimension_cluster , N_cluster);
  
  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);
  
  class array<TYPE> PSI_cluster_component_tab(space_dimension_cluster);
  
  class array<bool> is_SDp_IN_in_new_space_tab(space_dimension_IN);
  class array<bool> is_SDn_IN_in_new_space_tab(space_dimension_IN);
  
  class array<bool> is_SDp_cluster_in_new_space_tab(space_dimension_cluster);
  class array<bool> is_SDn_cluster_in_new_space_tab(space_dimension_cluster);

  class array<unsigned char> reordering_bin_phases_p_IN(space_dimension_IN);
  class array<unsigned char> reordering_bin_phases_n_IN(space_dimension_IN);
  
  class array<unsigned char> reordering_bin_phases_p_cluster(space_dimension_cluster);
  class array<unsigned char> reordering_bin_phases_n_cluster(space_dimension_cluster);
  
  files_IN_tables_read_pn_cluster_projectile (full_common_vectors_used_in_file , false , NO_PARTICLE , NADA , NADA , M_cluster , PSI_cluster_qn , false , NO_PARTICLE , NADA , NADA , M_IN , PSI_IN_qn , prot_data , neut_data ,
					      SDp_IN_tab , SDn_IN_tab , SDp_cluster_tab , SDn_cluster_tab , PSI_IN_component_tab , PSI_cluster_component_tab ,
					      is_SDp_IN_in_new_space_tab , is_SDn_IN_in_new_space_tab , is_SDp_cluster_in_new_space_tab , is_SDn_cluster_in_new_space_tab ,
					      reordering_bin_phases_p_IN , reordering_bin_phases_n_IN , reordering_bin_phases_p_cluster , reordering_bin_phases_n_cluster);
  
  class array<unsigned int> A_dagger_SD_cluster_PSI_IN_total_PSI_indices(space_dimension_IN_max , space_dimension_cluster_max);

  class array<TYPE> A_dagger_SD_cluster_PSI_IN_components(space_dimension_IN_max , space_dimension_cluster_max);

  A_dagger_PSI_IN_total_PSI_indices_components_calc_pn (PSI_cluster_qn , PSI_IN_qn , GSM_vector_helper_OUT , SDp_IN_tab , SDn_IN_tab , SDp_cluster_tab , SDn_cluster_tab , PSI_IN_component_tab , PSI_cluster_component_tab ,
							is_SDp_IN_in_new_space_tab , is_SDn_IN_in_new_space_tab , is_SDp_cluster_in_new_space_tab , is_SDn_cluster_in_new_space_tab ,
							reordering_bin_phases_p_IN , reordering_bin_phases_n_IN , reordering_bin_phases_p_cluster , reordering_bin_phases_n_cluster ,
							A_dagger_SD_cluster_PSI_IN_total_PSI_indices , A_dagger_SD_cluster_PSI_IN_components);
      
  const TYPE amplitude = PSI_OUT.Op_PSI_IN_scalar_product_add_cluster_all_processes (full_common_vectors_used_in_file , A_dagger_SD_cluster_PSI_IN_total_PSI_indices , A_dagger_SD_cluster_PSI_IN_components);

  return amplitude;
}







TYPE spectroscopic_factor_amplitude::nucleus::stripping_pp_nn_calc (
								    const bool full_common_vectors_used_in_file ,
								    const class correlated_state_str &PSI_IN_qn , 
								    const class correlated_state_str &PSI_cluster_qn , 
								    const double M_cluster , 
								    const class GSM_vector &PSI_OUT)
{  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);

  const int N_core_mu = (space == PROTONS_ONLY) ? (data.get_Z_core ()) : (data.get_N_core ());

  const int N_IN_mu = (space == PROTONS_ONLY) ? (PSI_IN_qn.get_Z ()) : (PSI_IN_qn.get_N ());

  const int hole_states_number_mu = data.get_hole_states_number ();
  
  const int Nval_IN_mu = N_IN_mu - N_core_mu + hole_states_number_mu;
  
  const int N_cluster_mu = (space == PROTONS_ONLY) ? (PSI_cluster_qn.get_Z ()) : (PSI_cluster_qn.get_N ());
  
  const double M_IN = M_OUT - M_cluster;

  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);
  
  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Nval_IN_mu , file_name_IN_dimension);
   
  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));

  const string file_name_cluster_dimension = file_name_eigenvector_string (true , "eigenvector_dimension" , PSI_cluster_qn , M_cluster);
   
  const unsigned int space_dimension_cluster = space_dimension_read_disk (true , N_cluster_mu , file_name_cluster_dimension);

  const unsigned int space_dimension_cluster_max = max_Allreduce<unsigned int> (is_it_MPI_parallelized_local , space_dimension_cluster);
  
  class array<unsigned int> SD_IN_tab(space_dimension_IN , Nval_IN_mu);
  
  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);
    
  class array<bool> is_SD_IN_in_new_space_tab(space_dimension_IN);

  class array<unsigned char> reordering_bin_phases_IN(space_dimension_IN);

  class array<unsigned int> SD_cluster_tab(space_dimension_cluster , N_cluster_mu);

  class array<TYPE> PSI_cluster_component_tab(space_dimension_cluster);

  class array<bool> is_SD_cluster_in_new_space_tab(space_dimension_cluster);

  class array<unsigned char> reordering_bin_phases_cluster(space_dimension_cluster);

  files_IN_tables_read_pp_nn_cluster_projectile (full_common_vectors_used_in_file , false , NO_PARTICLE , NADA , NADA , M_cluster , PSI_cluster_qn , false , NO_PARTICLE , NADA , NADA , M_IN , PSI_IN_qn , data ,
						 SD_IN_tab , SD_cluster_tab , PSI_IN_component_tab , PSI_cluster_component_tab ,
						 is_SD_IN_in_new_space_tab , is_SD_cluster_in_new_space_tab , reordering_bin_phases_IN , reordering_bin_phases_cluster);

  class array<unsigned int> A_dagger_SD_cluster_PSI_IN_total_PSI_indices(space_dimension_IN_max , space_dimension_cluster_max);

  class array<TYPE> A_dagger_SD_cluster_PSI_IN_components(space_dimension_IN_max , space_dimension_cluster_max);
					
  A_dagger_PSI_IN_total_PSI_indices_components_calc_pp_nn (PSI_cluster_qn , PSI_IN_qn , GSM_vector_helper_OUT , SD_IN_tab , SD_cluster_tab , PSI_IN_component_tab , PSI_cluster_component_tab ,
							   is_SD_IN_in_new_space_tab , is_SD_cluster_in_new_space_tab , reordering_bin_phases_IN , reordering_bin_phases_cluster ,
							   A_dagger_SD_cluster_PSI_IN_total_PSI_indices , A_dagger_SD_cluster_PSI_IN_components);

  const TYPE amplitude = PSI_OUT.Op_PSI_IN_scalar_product_add_cluster_all_processes (full_common_vectors_used_in_file , A_dagger_SD_cluster_PSI_IN_total_PSI_indices , A_dagger_SD_cluster_PSI_IN_components);

  return amplitude;
}












TYPE spectroscopic_factor_amplitude::nucleus::stripping_calc (
							      const bool full_common_vectors_used_in_file ,
							      const class correlated_state_str &PSI_IN_qn , 
							      const class correlated_state_str &PSI_cluster_qn , 
							      const double M_cluster , 
							      const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const int Z_IN = PSI_IN_qn.get_Z ();
  const int N_IN = PSI_IN_qn.get_N ();
  
  const int Z_OUT = prot_data.get_N_nucleons ();
  const int N_OUT = neut_data.get_N_nucleons ();
  
  const int Z_cluster = PSI_cluster_qn.get_Z ();
  const int N_cluster = PSI_cluster_qn.get_N ();

  if (Z_OUT != Z_IN + Z_cluster) return 0.0;
  if (N_OUT != N_IN + N_cluster) return 0.0;

  const unsigned int BP_cluster = PSI_cluster_qn.get_BP ();

  const unsigned int BP_IN = PSI_IN_qn.get_BP ();

  if (BP_OUT != binary_parity_product (BP_IN , BP_cluster)) return 0.0;
  
  const double J_cluster = PSI_cluster_qn.get_J ();

  if (rint (abs (M_cluster) - J_cluster) > 0.0) return 0.0;
  
  const double J_IN = PSI_IN_qn.get_J ();

  const double M_IN = M_OUT - M_cluster;

  if (rint (abs (M_IN) - J_IN) > 0.0) return 0.0;
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();

  const TYPE amplitude = (space == PROTONS_NEUTRONS)
    ? (spectroscopic_factor_amplitude::nucleus::stripping_pn_calc    (full_common_vectors_used_in_file , PSI_IN_qn , PSI_cluster_qn , M_cluster , PSI_OUT))
    : (spectroscopic_factor_amplitude::nucleus::stripping_pp_nn_calc (full_common_vectors_used_in_file , PSI_IN_qn , PSI_cluster_qn , M_cluster , PSI_OUT));

  return amplitude;
}







TYPE spectroscopic_factor_amplitude::nucleus::pick_up_pn_calc (
							       const bool full_common_vectors_used_in_file ,
							       const class correlated_state_str &PSI_IN_qn , 
							       const class correlated_state_str &PSI_cluster_qn , 
							       const double M_cluster , 
							       const class GSM_vector &PSI_OUT)
{  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const int Z_core = prot_data.get_Z_core ();
  const int N_core = prot_data.get_N_core ();
  
  const int Z_IN = PSI_IN_qn.get_Z ();
  const int N_IN = PSI_IN_qn.get_N ();
  
  const int prot_hole_states_number = prot_data.get_hole_states_number ();
  const int neut_hole_states_number = neut_data.get_hole_states_number ();
  
  const int Zval_IN = Z_IN - Z_core + prot_hole_states_number;
  const int Nval_IN = N_IN - N_core + neut_hole_states_number;
  
  const int Z_cluster = PSI_cluster_qn.get_Z ();
  const int N_cluster = PSI_cluster_qn.get_N ();
  
  const double M_IN = M_OUT + M_cluster;

  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);

  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Zval_IN , Nval_IN , file_name_IN_dimension);

  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));
												    
  const string file_name_cluster_dimension = file_name_eigenvector_string (true , "eigenvector_dimension" , PSI_cluster_qn , M_cluster);
  
  const unsigned int space_dimension_cluster = space_dimension_read_disk (true , Z_cluster , N_cluster , file_name_cluster_dimension);

  const unsigned int space_dimension_cluster_max = max_Allreduce<unsigned int> (is_it_MPI_parallelized_local , space_dimension_cluster);
   
  class array<unsigned int> SDp_IN_tab(space_dimension_IN , Zval_IN);
  class array<unsigned int> SDn_IN_tab(space_dimension_IN , Nval_IN);

  class array<unsigned int> SDp_cluster_tab(space_dimension_cluster , Z_cluster);
  class array<unsigned int> SDn_cluster_tab(space_dimension_cluster , N_cluster);
  
  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);

  class array<TYPE> PSI_cluster_component_tab(space_dimension_cluster);
  
  class array<bool> is_SDp_IN_in_new_space_tab(space_dimension_IN);
  class array<bool> is_SDn_IN_in_new_space_tab(space_dimension_IN);

  class array<bool> is_SDp_cluster_in_new_space_tab(space_dimension_cluster);
  class array<bool> is_SDn_cluster_in_new_space_tab(space_dimension_cluster);

  class array<unsigned char> reordering_bin_phases_p_IN(space_dimension_IN);
  class array<unsigned char> reordering_bin_phases_n_IN(space_dimension_IN);

  class array<unsigned char> reordering_bin_phases_p_cluster(space_dimension_cluster);
  class array<unsigned char> reordering_bin_phases_n_cluster(space_dimension_cluster);
      
  files_IN_tables_read_pn_cluster_projectile (full_common_vectors_used_in_file , false , NO_PARTICLE , NADA , NADA , M_cluster , PSI_cluster_qn , false , NO_PARTICLE , NADA , NADA , M_IN , PSI_IN_qn , prot_data , neut_data ,
					      SDp_IN_tab , SDn_IN_tab , SDp_cluster_tab , SDn_cluster_tab , PSI_IN_component_tab , PSI_cluster_component_tab ,
					      is_SDp_IN_in_new_space_tab , is_SDn_IN_in_new_space_tab , is_SDp_cluster_in_new_space_tab , is_SDn_cluster_in_new_space_tab ,
					      reordering_bin_phases_p_IN , reordering_bin_phases_n_IN , reordering_bin_phases_p_cluster , reordering_bin_phases_n_cluster);

  class array<unsigned int> A_SD_cluster_PSI_IN_total_PSI_indices(space_dimension_IN_max , space_dimension_cluster_max);
  
  class array<TYPE> A_SD_cluster_PSI_IN_components(space_dimension_IN_max , space_dimension_cluster_max);

  A_PSI_IN_total_PSI_indices_components_calc_pn (PSI_cluster_qn , PSI_IN_qn , GSM_vector_helper_OUT , SDp_IN_tab , SDn_IN_tab , SDp_cluster_tab , SDn_cluster_tab , PSI_IN_component_tab , PSI_cluster_component_tab ,
						 is_SDp_IN_in_new_space_tab , is_SDn_IN_in_new_space_tab , is_SDp_cluster_in_new_space_tab , is_SDn_cluster_in_new_space_tab ,
						 reordering_bin_phases_p_IN , reordering_bin_phases_n_IN , reordering_bin_phases_p_cluster , reordering_bin_phases_n_cluster ,
						 A_SD_cluster_PSI_IN_total_PSI_indices , A_SD_cluster_PSI_IN_components);
  
  const TYPE amplitude = PSI_OUT.Op_PSI_IN_scalar_product_add_cluster_all_processes (full_common_vectors_used_in_file , A_SD_cluster_PSI_IN_total_PSI_indices , A_SD_cluster_PSI_IN_components);

  return amplitude;
}







TYPE spectroscopic_factor_amplitude::nucleus::pick_up_pp_nn_calc (
								  const bool full_common_vectors_used_in_file ,
								  const class correlated_state_str &PSI_IN_qn , 
								  const class correlated_state_str &PSI_cluster_qn , 
								  const double M_cluster , 
								  const class GSM_vector &PSI_OUT)
{  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const bool is_it_MPI_parallelized_local = GSM_vector_helper_OUT.get_is_it_MPI_parallelized_local ();
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();

  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);

  const int N_core_mu = (space == PROTONS_ONLY) ? (data.get_Z_core ()) : (data.get_N_core ());

  const int N_IN_mu = (space == PROTONS_ONLY) ? (PSI_IN_qn.get_Z ()) : (PSI_IN_qn.get_N ());

  const int hole_states_number_mu = data.get_hole_states_number ();
 
  const int Nval_IN_mu = N_IN_mu - N_core_mu + hole_states_number_mu;
  
  const int N_cluster_mu = (space == PROTONS_ONLY) ? (PSI_cluster_qn.get_Z ()) : (PSI_cluster_qn.get_N ());
    
  const double M_IN = M_OUT + M_cluster;  

  const string file_name_IN_dimension = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector_dimension" , PSI_IN_qn , M_IN);
  
  const unsigned int space_dimension_IN = space_dimension_read_disk (full_common_vectors_used_in_file , Nval_IN_mu , file_name_IN_dimension);

  const unsigned int space_dimension_IN_max = (full_common_vectors_used_in_file) ? (space_dimension_IN) : (max_Allreduce (is_it_MPI_parallelized_local , space_dimension_IN));  
  
  const string file_name_cluster_dimension = file_name_eigenvector_string (true , "eigenvector_dimension" , PSI_cluster_qn , M_cluster);
  
  const unsigned int space_dimension_cluster = space_dimension_read_disk (true , N_cluster_mu , file_name_cluster_dimension);

  const unsigned int space_dimension_cluster_max = max_Allreduce<unsigned int> (is_it_MPI_parallelized_local , space_dimension_cluster);
 
  class array<unsigned int> SD_IN_tab(space_dimension_IN , Nval_IN_mu);
  
  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);

  class array<bool> is_SD_IN_in_new_space_tab(space_dimension_IN);

  class array<unsigned char> reordering_bin_phases_IN(space_dimension_IN);
  
  class array<unsigned int> SD_cluster_tab(space_dimension_cluster , N_cluster_mu);
    
  class array<TYPE> PSI_cluster_component_tab(space_dimension_cluster);
    
  class array<bool> is_SD_cluster_in_new_space_tab(space_dimension_cluster);
  
  class array<unsigned char> reordering_bin_phases_cluster(space_dimension_cluster);

  files_IN_tables_read_pp_nn_cluster_projectile (full_common_vectors_used_in_file , false , NO_PARTICLE , NADA , NADA , M_cluster , PSI_cluster_qn , false , NO_PARTICLE , NADA , NADA , M_IN , PSI_IN_qn , data ,
						 SD_IN_tab , SD_cluster_tab , PSI_IN_component_tab , PSI_cluster_component_tab ,
						 is_SD_IN_in_new_space_tab , is_SD_cluster_in_new_space_tab , reordering_bin_phases_IN , reordering_bin_phases_cluster);

  class array<unsigned int> A_SD_cluster_PSI_IN_total_PSI_indices(space_dimension_IN_max , space_dimension_cluster_max);

  class array<TYPE> A_SD_cluster_PSI_IN_components(space_dimension_IN_max , space_dimension_cluster_max);

  A_PSI_IN_total_PSI_indices_components_calc_pp_nn (PSI_cluster_qn , PSI_IN_qn , GSM_vector_helper_OUT , SD_IN_tab , SD_cluster_tab , PSI_IN_component_tab , PSI_cluster_component_tab ,
						    is_SD_IN_in_new_space_tab , is_SD_cluster_in_new_space_tab , reordering_bin_phases_IN , reordering_bin_phases_cluster ,
						    A_SD_cluster_PSI_IN_total_PSI_indices , A_SD_cluster_PSI_IN_components);
  
  const TYPE amplitude = PSI_OUT.Op_PSI_IN_scalar_product_add_cluster_all_processes (full_common_vectors_used_in_file , A_SD_cluster_PSI_IN_total_PSI_indices , A_SD_cluster_PSI_IN_components);

  return amplitude;
}








TYPE spectroscopic_factor_amplitude::nucleus::pick_up_calc (
							    const bool full_common_vectors_used_in_file ,
							    const class correlated_state_str &PSI_IN_qn , 
							    const class correlated_state_str &PSI_cluster_qn , 
							    const double M_cluster , 
							    const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_OUT.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_OUT.get_neut_data ();
  
  const int Z_IN = PSI_IN_qn.get_Z ();
  const int N_IN = PSI_IN_qn.get_N ();
  
  const int Z_OUT = prot_data.get_N_nucleons ();
  const int N_OUT = neut_data.get_N_nucleons ();
  
  const int Z_cluster = PSI_cluster_qn.get_Z ();
  const int N_cluster = PSI_cluster_qn.get_N ();

  if (Z_OUT != Z_IN - Z_cluster) return 0.0;
  if (N_OUT != N_IN - N_cluster) return 0.0;
  
  const unsigned int BP_cluster = PSI_cluster_qn.get_BP ();

  const unsigned int BP_IN = PSI_IN_qn.get_BP ();

  if (BP_OUT != binary_parity_product (BP_IN , BP_cluster)) return 0.0;
  
  const double J_cluster = PSI_cluster_qn.get_J ();

  if (rint (abs (M_cluster) - J_cluster) > 0.0) return 0.0;
  
  const double J_IN = PSI_IN_qn.get_J ();

  const double M_IN = M_OUT + M_cluster;

  if (rint (abs (M_IN) - J_IN) > 0.0) return 0.0;
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();

  const TYPE amplitude = (space == PROTONS_NEUTRONS)
    ? (spectroscopic_factor_amplitude::nucleus::pick_up_pn_calc    (full_common_vectors_used_in_file , PSI_IN_qn , PSI_cluster_qn , M_cluster , PSI_OUT))
    : (spectroscopic_factor_amplitude::nucleus::pick_up_pp_nn_calc (full_common_vectors_used_in_file , PSI_IN_qn , PSI_cluster_qn , M_cluster , PSI_OUT));

  return amplitude;
}


