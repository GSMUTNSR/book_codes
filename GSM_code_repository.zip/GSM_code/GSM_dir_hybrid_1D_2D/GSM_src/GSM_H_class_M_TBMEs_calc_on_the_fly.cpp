#include "../GSM_include/GSM_include_def.h"
#include "../GSM_include/GSM_include_def.h"

#include "../GSM_include/GSM_include_def.h"



// TYPE is double or complex
// -------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons
// ------------------------------------------------------------------------------------------------------------------------------------------------------


using namespace inputs_misc;
using namespace GSM_vector_NBMEs_handling;
using namespace GSM_vector_dimensions;


// Allocation, calculation and storage of uncoupled TBMEs for the on the fly method
// --------------------------------------------------------------------------------
// For some storage options of the on the fly method (see GSM_H_class.cpp), uncoupled TBMEs are stored instead of being recalculated from J-coupled TBMEs and Clebsch-Gordan coefficients.
//
// For this, one first counts the number of pp, nn and pn pairs of one-body states occurring in the basis SDs of one node, then one generates all these pairs,
// and one allocates the class containing uncoupled TBMEs, where the array containing all uncoupled TBMEs will be allocated and calculated.
//
// In this, one loops over proton and neutron Slater determinants, the first loop being proton or neutron according to the case.
//
// As the in and out SD spaces can be different when using MPI parallelization (i.e. those occurring in H.|Psi[in]> = |Psi[out]>),
// the pairs occurring in the in and out SD spaces are considered independently.
//
// OpenMP parallelization is not used here as routines counting and generating pairs are sequential, fast enough, and it would be cumbersome to parallelize them.
// MPI parallelization here is implicit, as on considers only the Slater determinants of the current node.
// OpenMP parallelization is, however, fully taken into account when allocating and calculating the uncoupled TBMEs in the M_TBMEs class.
//
// As the time taken to calculate all uncoupled TBMEs can be long, it can be written on screen.
//
// See GSM_vector_helper.cpp for the definition of total PSI indices.

unsigned int H_class::pp_pairs_in_number_pn_calc_on_the_fly () const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int iM = GSM_vector_helper.get_iM ();
    
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 

  const int Zval = prot_data.get_N_valence_nucleons ();
  
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_data.get_N_nljm ()) : (prot_data.get_N_nljm_res ());
  
  class Slater_determinant SDp(Zval);
  
  class array<bool> has_pair_been_considered(Np_nljm , Np_nljm);
  
  has_pair_been_considered = false;

  unsigned int pp_pairs_in_number = 0;
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP); 

      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int dimension_iCp = dimensions_configuration_p_set(BPp , n_scat_p);
	  
	  for (unsigned int iCp = 0 ; iCp < dimension_iCp ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

	      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);

	      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
		{			
		  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);

		  if (dimension_SDp == 0) continue;
        
		  const int iMn = iM - iMp;
		  
		  const unsigned long int total_SDp_index_zero = SDp_set.index_determine (BPp , n_scat_p , iCp , iMp , 0);
		  
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      bool has_SDp_been_considered = false;
			      
		      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && (!has_SDp_been_considered) ; n_scat_n++)
			{
			  const unsigned int dimension_iCn = dimensions_configuration_n_set(BPn , n_scat_n);
		  
			  for (unsigned int iCn = 0 ; (iCn < dimension_iCn) && (!has_SDp_been_considered) ; iCn++)
			    {
			      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
			      const int En = En_hw_table(BPn , n_scat_n , iCn);
				      
			      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw))
				{
				  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

				  if (dimension_SDn == 0) continue;
				  
				  const unsigned long int total_index_SDp = total_SDp_index_zero + SDp_index;

				  SDp = SDp_set[total_index_SDp];
					      
				  for (int ip = 0 ; ip < Zval ; ip++)
				    for (int ipp = 0 ; ipp < Zval ; ipp++)
				      {
					const unsigned int p  = SDp[ip];
					const unsigned int pp = SDp[ipp];
						    
					if (p < pp)
					  {
					    if (!has_pair_been_considered(p , pp))
					      {
						pp_pairs_in_number++;
								
						has_pair_been_considered(p , pp) = true;
					      }
					  }
				      }
						  
				  has_SDp_been_considered = true;
						  
				}}}}}}}}
  
  return pp_pairs_in_number;
}





unsigned int H_class::nn_pairs_in_number_pn_calc_on_the_fly () const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();

  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();
  
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_data.get_N_nljm ()) : (neut_data.get_N_nljm_res ());
    
  class Slater_determinant SDn(Nval);
  
  class array<bool> has_pair_been_considered(Nn_nljm , Nn_nljm);
  
  has_pair_been_considered = false;

  unsigned int nn_pairs_in_number = 0;
  	  
  for (unsigned int BPn = 0 ; BPn <= 1 ; BPn++)
    {
      const unsigned int BPp = binary_parity_product (BPn , BP); 

      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	{
	  const unsigned int dimension_iCn = dimensions_configuration_n_set(BPn , n_scat_n);
		  
	  for (unsigned int iCn = 0 ; iCn < dimension_iCn ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
	      const int En = En_hw_table(BPn , n_scat_n , iCn);

	      for (int iMn = iMn_min_M ; iMn <= iMn_max_M ; iMn++)
		{			
		  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

		  if (dimension_SDn == 0) continue;
        
		  const int iMp = iM - iMn;
		  
		  const unsigned long int total_SDn_index_zero = SDn_set.index_determine (BPn , n_scat_n , iCn , iMn , 0);
		  
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      bool has_SDn_been_considered = false;

		      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && (!has_SDn_been_considered) ; n_scat_p++)
			{
			  const unsigned int dimension_iCp = dimensions_configuration_p_set(BPp , n_scat_p);
	  
			  for (unsigned int iCp = 0 ; (iCp < dimension_iCp) && (!has_SDn_been_considered) ; iCp++)
			    {
			      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

			      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);
				      
			      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw))
				{
				  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);
				  
				  if (dimension_SDp == 0) continue;
				
				  const unsigned long int total_index_SDn = total_SDn_index_zero + SDn_index;

				  SDn = SDn_set[total_index_SDn];
						  
				  for (int in = 0 ; in < Nval ; in++)
				    for (int inn = 0 ; inn < Nval ; inn++)
				      {
					const unsigned int n  = SDn[in];
					const unsigned int nn = SDn[inn];

					if (n < nn)
					  {
					    if (!has_pair_been_considered(n , nn))
					      {
						nn_pairs_in_number++;
								
						has_pair_been_considered(n , nn) = true;						    
					      }
					  }
				      }
						  
				  has_SDn_been_considered = true;
						  
				}}}}}}}}

  return nn_pairs_in_number;
}










unsigned int H_class::pn_pairs_in_number_pn_calc_on_the_fly () const
{
  if (!is_pn_non_zero) return 0;
   
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
   
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 
  
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set (); 
    
  const int Zval = prot_data.get_N_valence_nucleons (); 
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_data.get_N_nljm ()) : (prot_data.get_N_nljm_res ());
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_data.get_N_nljm ()) : (neut_data.get_N_nljm_res ());
        
  class Slater_determinant SDp(Zval);
  class Slater_determinant SDn(Nval);
  
  class array<bool> has_pair_been_considered(Np_nljm , Nn_nljm);
  
  has_pair_been_considered = false;

  unsigned int pn_pairs_in_number = 0;
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP); 

      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int dimension_iCp = dimensions_configuration_p_set(BPp , n_scat_p);
	  
	  for (unsigned int iCp = 0 ; iCp < dimension_iCp ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

	      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);
	      
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

	      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
		{
		  const unsigned int dimension_iCn = dimensions_configuration_n_set(BPn , n_scat_n);
		  
		  for (unsigned int iCn = 0 ; iCn < dimension_iCn ; iCn++)
		    {
		      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
		      const int En = En_hw_table(BPn , n_scat_n , iCn);

		      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw))
			{
			  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
			    {			
			      const int iMn = iM - iMp;

			      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);
			      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

			      if ((dimension_SDn == 0) || (dimension_SDp == 0)) continue;

			      const unsigned long int total_index_zero_SDp = SDp_set.index_determine (BPp , n_scat_p , iCp , iMp , 0);
			      const unsigned long int total_index_zero_SDn = SDn_set.index_determine (BPn , n_scat_n , iCn , iMn , 0);

			      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
				{
				  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
				    {
				      const unsigned long int total_index_SDp = total_index_zero_SDp + SDp_index;
				      const unsigned long int total_index_SDn = total_index_zero_SDn + SDn_index;
						      
				      SDp = SDp_set[total_index_SDp];
				      SDn = SDn_set[total_index_SDn];
						  
				      for (int ip = 0 ; ip < Zval ; ip++)
					for (int in = 0 ; in < Nval ; in++)
					  {
					    const unsigned int p = SDp[ip];
					    const unsigned int n = SDn[in];

					    if (!has_pair_been_considered(p , n))
					      {
						pn_pairs_in_number++;
								
						has_pair_been_considered(p , n) = true;
						
					      }}}}}}}}}}}

  return pn_pairs_in_number;
}







unsigned int H_class::pairs_in_number_pp_nn_calc_on_the_fly () const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
   
  const int iM = GSM_vector_helper.get_iM ();
   
  
  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);
  
  const class array_BP_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();
  
  const class array_of_SD &SD_set = data.get_SD_set ();
  
  const unsigned int N_nljm = (n_scat_max > 0) ? (data.get_N_nljm ()) : (data.get_N_nljm_res ());
  const int N_valence_nucleons = data.get_N_valence_nucleons ();
  
  class Slater_determinant SD(N_valence_nucleons);
  
  class array<bool> has_pair_been_considered(N_nljm , N_nljm);
  
  has_pair_been_considered = false;

  unsigned int pairs_in_number = 0;
  	  
  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int dimension_iC = dimensions_configuration_set(BP , n_scat);
      
      for (unsigned int iC = 0 ; iC < dimension_iC ; iC++)
	{ 
	  const int n_holes = n_holes_table(BP , n_scat , iC);
	  
	  const int E = E_hw_table(BP , n_scat , iC);
	  
	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD_set = dimensions_SD_set(BP , n_scat , iC , iM);
	  if (dimension_SD_set == 0) continue;
	  
	  const unsigned long int total_index_zero_SD = SD_set.index_determine (BP , n_scat , iC , iM , 0);

	  for (unsigned int SD_index = 0 ; SD_index < dimension_SD_set ; SD_index++)
	    {
	      const unsigned long int total_index_SD = total_index_zero_SD + SD_index;
			  
	      SD = SD_set[total_index_SD];

	      for (int i = 0 ; i < N_valence_nucleons ; i++)
		for (int ii = 0 ; ii < N_valence_nucleons ; ii++)
		  {
		    const unsigned int mu   = SD[i];
		    const unsigned int mu_p = SD[ii];

		    if (mu < mu_p)
		      {
			if (!has_pair_been_considered(mu , mu_p))
			  {
			    pairs_in_number++;
					
			    has_pair_been_considered(mu , mu_p) = true;
				    
			  }}}}}}

  return pairs_in_number;
}






unsigned int H_class::pp_pairs_out_number_pn_calc_on_the_fly () const
{ 
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();

  const int Zval = prot_data.get_N_valence_nucleons ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
   
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_data.get_N_nljm ()) : (prot_data.get_N_nljm_res ());
    
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index =  GSM_vector_helper.get_last_total_PSI_index ();
  
  class Slater_determinant SDp(Zval);
  
  class array<bool> has_pair_been_considered(Np_nljm , Np_nljm);
  
  has_pair_been_considered = false;

  unsigned int pp_pairs_out_number = 0;
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP); 

      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , n_scat_p);
							    
	  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

	      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);

	      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
		{			
		  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);

		  if (dimension_SDp == 0) continue;
        
		  const int iMn = iM - iMp;
			  
		  const unsigned long int total_SDp_index_zero = SDp_set.index_determine (BPp , n_scat_p , iCp , iMp , 0);
			  
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      bool has_SDp_been_considered = false;
							    
		      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && (!has_SDp_been_considered) ; n_scat_n++)
			{
			  const unsigned int iCn_min = iCn_min_process_tab(BPn , n_scat_n);
			  const unsigned int iCn_max = iCn_max_process_tab(BPn , n_scat_n);
		  
			  for (unsigned int iCn = iCn_min ; (iCn <= iCn_max) && (!has_SDp_been_considered) ; iCn++)
			    {
			      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
			      const int En = En_hw_table(BPn , n_scat_n , iCn);
				      
			      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw))
				{
				  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

				  if (dimension_SDn == 0) continue;
				  
				  const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , n_scat_p , n_scat_n , iCp , iCn , iMp);

				  const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;

				  const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDn_minus_one;
				  
				  if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
				    {
				      for (unsigned int SDn_index = 0 ; (SDn_index < dimension_SDn) && (!has_SDp_been_considered) ; SDn_index++)
					{
					  const unsigned long int total_PSI_index = total_PSI_index_zero + SDn_index;
				      					     
					  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
					    {
					      const unsigned long int total_index_SDp = total_SDp_index_zero + SDp_index;

					      SDp = SDp_set[total_index_SDp];
					      
					      for (int ip = 0 ; ip < Zval ; ip++)
						for (int ipp = 0 ; ipp < Zval ; ipp++)
						  {
						    const unsigned int p  = SDp[ip];
						    const unsigned int pp = SDp[ipp];
						    
						    if (p < pp)
						      {
							if (!has_pair_been_considered(p , pp))
							  {
							    pp_pairs_out_number++;
								    
							    has_pair_been_considered(p , pp) = true;
							  }
						      }
						  }
						  
					      has_SDp_been_considered = true;
						  
					    }}}}}}}}}}}
  
  return pp_pairs_out_number;
}


unsigned int H_class::nn_pairs_out_number_pn_calc_on_the_fly () const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
      
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();
  
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_data.get_N_nljm ()) : (neut_data.get_N_nljm_res ());
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
    	      
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  class Slater_determinant SDn(Nval);
  
  class array<bool> has_pair_been_considered(Nn_nljm , Nn_nljm);
  
  has_pair_been_considered = false;

  unsigned int nn_pairs_out_number = 0;
  
  for (unsigned int BPn = 0 ; BPn <= 1 ; BPn++)
    {
      const unsigned int BPp = binary_parity_product (BPn , BP); 

      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_process_tab(BPn , n_scat_n);
	  const unsigned int iCn_max = iCn_max_process_tab(BPn , n_scat_n);
		  
	  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
	      const int En = En_hw_table(BPn , n_scat_n , iCn);

	      for (int iMn = iMn_min_M ; iMn <= iMn_max_M ; iMn++)
		{			
		  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

		  if (dimension_SDn == 0) continue;
        
		  const int iMp = iM - iMn;
			  
		  const unsigned long int total_SDn_index_zero = SDn_set.index_determine (BPn , n_scat_n , iCn , iMn , 0);
			  
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {					      
		      bool has_SDn_been_considered = false;

		      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && (!has_SDn_been_considered) ; n_scat_p++)
			{
			  const unsigned int iCp_min = iCp_min_process_tab(BPp , n_scat_p);
			  const unsigned int iCp_max = iCp_max_process_tab(BPp , n_scat_p);
	  
			  for (unsigned int iCp = iCp_min ; (iCp <= iCp_max) && (!has_SDn_been_considered) ; iCp++)
			    {
			      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

			      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);
				      
			      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw))
				{
				  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);

				  if (dimension_SDp == 0) continue;
				  
				  const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;
				  
				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , n_scat_p , n_scat_n , iCp , iCn , iMp);					  
				  
				  const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + SDn_index;

				  const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDp_minus_one*dimension_SDn;

				  if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
				    {
				      for (unsigned int SDp_index = 0 ; (SDp_index < dimension_SDp) && (!has_SDn_been_considered) ; SDp_index++)
					{
					  const unsigned long int total_PSI_index = total_PSI_index_zero + SDp_index*dimension_SDn;

					  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
					    {
					      const unsigned long int total_index_SDn = total_SDn_index_zero + SDn_index;

					      SDn = SDn_set[total_index_SDn];
						  
					      for (int in = 0 ; in < Nval ; in++)
						for (int inn = 0 ; inn < Nval ; inn++)
						  {
						    const unsigned int n  = SDn[in];
						    const unsigned int nn = SDn[inn];

						    if (n < nn)
						      {
							if (!has_pair_been_considered(n , nn))
							  {
							    nn_pairs_out_number++;
								    
							    has_pair_been_considered(n , nn) = true;
							  }
						      }
						  }
						  
					      has_SDn_been_considered = true;
						  
					    }}}}}}}}}}}

  return nn_pairs_out_number;
}








unsigned int H_class::pn_pairs_out_number_pn_calc_on_the_fly () const
{
  if (!is_pn_non_zero) return 0;
   
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
   
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector (); 
  
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set (); 
    
  const int Zval = prot_data.get_N_valence_nucleons (); 
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_data.get_N_nljm ()) : (prot_data.get_N_nljm_res ());
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_data.get_N_nljm ()) : (neut_data.get_N_nljm_res ());
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
            
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  class Slater_determinant SDp(Zval);
  class Slater_determinant SDn(Nval);
  
  class array<bool> has_pair_been_considered(Np_nljm , Nn_nljm);
  
  has_pair_been_considered = false;

  unsigned int pn_pairs_out_number = 0;
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP); 

      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , n_scat_p);
	  
	  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

	      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

	      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
		{
		  const unsigned int iCn_min = iCn_min_process_tab(BPn , n_scat_n);
		  const unsigned int iCn_max = iCn_max_process_tab(BPn , n_scat_n);
		  
		  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
		    {
		      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
		      const int En = En_hw_table(BPn , n_scat_n , iCn);

		      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw))
			{
			  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
			    {
			      const int iMn = iM - iMp;
				      
			      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);
			      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);
				      
			      if ((dimension_SDn == 0) || (dimension_SDp == 0)) continue;
				      
			      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , n_scat_p , n_scat_n , iCp , iCn , iMp);			  
					  
			      const unsigned long int total_index_zero_SDp = SDp_set.index_determine (BPp , n_scat_p , iCp , iMp , 0);
			      const unsigned long int total_index_zero_SDn = SDn_set.index_determine (BPn , n_scat_n , iCn , iMn , 0);
				      
			      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;
			      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;
				      
			      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed;
				      
			      const unsigned long int total_PSI_index_dimension_minus_one = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*dimension_SDp_minus_one + dimension_SDn_minus_one;
						  
			      if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
				{
				  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
				    {
				      const unsigned long int total_PSI_index_zero_SDp_fixed = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;
				      const unsigned long int total_PSI_index_dimension_minus_one_SDp_fixed = total_PSI_index_zero_SDp_fixed + dimension_SDn_minus_one;

				      if ((total_PSI_index_zero_SDp_fixed <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one_SDp_fixed >= first_total_PSI_index))
					{
					  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
					    {
					      const unsigned long int total_PSI_index = total_PSI_index_zero_SDp_fixed + SDn_index;

					      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
						{
						  const unsigned long int total_index_SDp = total_index_zero_SDp + SDp_index;
						  const unsigned long int total_index_SDn = total_index_zero_SDn + SDn_index;
						      
						  SDp = SDp_set[total_index_SDp];
						  SDn = SDn_set[total_index_SDn];
					  
						  for (int ip = 0 ; ip < Zval ; ip++)
						    for (int in = 0 ; in < Nval ; in++)
						      {
							const unsigned int p = SDp[ip];
							const unsigned int n = SDn[in];

							if (!has_pair_been_considered(p , n))
							  {
							    pn_pairs_out_number++;
								
							    has_pair_been_considered(p , n) = true;
							    
							  }}}}}}}}}}}}}}

  return pn_pairs_out_number;
}









unsigned int H_class::pairs_out_number_pp_nn_calc_on_the_fly () const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
      
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
   
  const int iM = GSM_vector_helper.get_iM ();
         
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector (); 
 
  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);
  
  const class array_BP_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();
  
  const class array_of_SD &SD_set = data.get_SD_set ();
  
  const unsigned int N_nljm = (n_scat_max > 0) ? (data.get_N_nljm ()) : (data.get_N_nljm_res ());

  const int N_valence_nucleons = data.get_N_valence_nucleons ();

  const class array<unsigned int> &iC_min_process_tab = GSM_vector_helper.get_iC_min_process_tab ();
  const class array<unsigned int> &iC_max_process_tab = GSM_vector_helper.get_iC_max_process_tab ();
          
  const unsigned long int first_total_PSI_index =  GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  class Slater_determinant SD(N_valence_nucleons);
  
  class array<bool> has_pair_been_considered(N_nljm , N_nljm);
  
  has_pair_been_considered = false;

  unsigned int pairs_out_number = 0;

  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int iC_min = iC_min_process_tab(n_scat);
      const unsigned int iC_max = iC_max_process_tab(n_scat);
      
      for (unsigned int iC = iC_min ; iC <= iC_max ; iC++)
	{ 
	  const int n_holes = n_holes_table(BP , n_scat , iC);
	  
	  const int E = E_hw_table(BP , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD_set = dimensions_SD_set(BP , n_scat , iC , iM);

	  if (dimension_SD_set == 0) continue;
	  
	  const unsigned long int total_index_zero_SD = SD_set.index_determine (BP , n_scat , iC , iM , 0);
	      
	  const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions_GSM_vector(n_scat , iC);

	  const unsigned int dimension_SD_set_minus_one = dimension_SD_set - 1;

	  const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_fixed;

	  const unsigned long int total_PSI_index_dimension_minus_one = sum_dimensions_configuration_fixed + dimension_SD_set_minus_one;
	  
	  if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
	    {
	      for (unsigned int SD_index = 0 ; SD_index < dimension_SD_set ; SD_index++)
		{
		  const unsigned long int total_PSI_index = total_PSI_index_zero + SD_index;

		  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
		    {
		      const unsigned long int total_index_SD = total_index_zero_SD + SD_index;
			  
		      SD = SD_set[total_index_SD];

		      for (int i = 0 ; i < N_valence_nucleons ; i++)
			for (int ii = 0 ; ii < N_valence_nucleons ; ii++)
			  {
			    const unsigned int mu   = SD[i];
			    const unsigned int mu_p = SD[ii];

			    if (mu < mu_p)
			      {
				if (!has_pair_been_considered(mu , mu_p))
				  {
				    pairs_out_number++;
					
				    has_pair_been_considered(mu , mu_p) = true;
				    
				  }}}}}}}}
  
  return pairs_out_number;
}




void H_class::pp_pairs_in_tab_pn_calc_on_the_fly (class array<class pair_str> &pp_pairs_in_tab) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 

  const int Zval = prot_data.get_N_valence_nucleons ();
  
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_data.get_N_nljm ()) : (prot_data.get_N_nljm_res ());

  class Slater_determinant SDp(Zval);
  
  class array<bool> has_pair_been_considered(Np_nljm , Np_nljm);
  
  has_pair_been_considered = false;

  unsigned int pp_pair_index = 0;
						    
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP); 

      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int dimension_iCp = dimensions_configuration_p_set(BPp , n_scat_p);
	  
	  for (unsigned int iCp = 0 ; iCp < dimension_iCp ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

	      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);

	      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
		{			
		  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);

		  if (dimension_SDp == 0) continue;
        
		  const int iMn = iM - iMp;
		  
		  const unsigned long int total_SDp_index_zero = SDp_set.index_determine (BPp , n_scat_p , iCp , iMp , 0);
		  
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      bool has_SDp_been_considered = false;
			      
		      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && (!has_SDp_been_considered) ; n_scat_n++)
			{
			  const unsigned int dimension_iCn = dimensions_configuration_n_set(BPn , n_scat_n);
		  
			  for (unsigned int iCn = 0 ; (iCn < dimension_iCn) && (!has_SDp_been_considered) ; iCn++)
			    {
			      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
			      const int En = En_hw_table(BPn , n_scat_n , iCn);
				      
			      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw))
				{
				  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

				  if (dimension_SDn == 0) continue;
				  
				  const unsigned long int total_index_SDp = total_SDp_index_zero + SDp_index;

				  SDp = SDp_set[total_index_SDp];
					      
				  for (int ip = 0 ; ip < Zval ; ip++)
				    for (int ipp = 0 ; ipp < Zval ; ipp++)
				      {
					const unsigned int p  = SDp[ip];
					const unsigned int pp = SDp[ipp];
						    
					if (p < pp)
					  {
					    if (!has_pair_been_considered(p , pp))
					      {
						pp_pairs_in_tab(pp_pair_index++) = pair_str (p , pp);
						    
						has_pair_been_considered(p , pp) = true;
					      }
					  }
				      }
						  
				  has_SDp_been_considered = true;
						  
				}}}}}}}}
}









								
void H_class::nn_pairs_in_tab_pn_calc_on_the_fly (class array<class pair_str> &nn_pairs_in_tab) const  
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();

  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();
  
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_data.get_N_nljm ()) : (neut_data.get_N_nljm_res ());
  
  class Slater_determinant SDn(Nval);
  
  class array<bool> has_pair_been_considered(Nn_nljm , Nn_nljm);
  
  has_pair_been_considered = false;
  	  
  unsigned int nn_pair_index = 0;
  
  for (unsigned int BPn = 0 ; BPn <= 1 ; BPn++)
    {
      const unsigned int BPp = binary_parity_product (BPn , BP); 

      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	{
	  const unsigned int dimension_iCn = dimensions_configuration_n_set(BPn , n_scat_n);
		  
	  for (unsigned int iCn = 0 ; iCn < dimension_iCn ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
	      const int En = En_hw_table(BPn , n_scat_n , iCn);

	      for (int iMn = iMn_min_M ; iMn <= iMn_max_M ; iMn++)
		{			
		  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

		  if (dimension_SDn == 0) continue;
        
		  const int iMp = iM - iMn;
		  
		  const unsigned long int total_SDn_index_zero = SDn_set.index_determine (BPn , n_scat_n , iCn , iMn , 0);
		  
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      bool has_SDn_been_considered = false;

		      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && (!has_SDn_been_considered) ; n_scat_p++)
			{
			  const unsigned int dimension_iCp = dimensions_configuration_p_set(BPp , n_scat_p);
	  
			  for (unsigned int iCp = 0 ; (iCp < dimension_iCp) && (!has_SDn_been_considered) ; iCp++)
			    {
			      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

			      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);
				      
			      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw))
				{
				  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);

				  if (dimension_SDp == 0) continue;
				  
				  const unsigned long int total_index_SDn = total_SDn_index_zero + SDn_index;

				  SDn = SDn_set[total_index_SDn];
						  
				  for (int in = 0 ; in < Nval ; in++)
				    for (int inn = 0 ; inn < Nval ; inn++)
				      {
					const unsigned int n  = SDn[in];
					const unsigned int nn = SDn[inn];

					if (n < nn)
					  {
					    if (!has_pair_been_considered(n , nn))
					      {
						nn_pairs_in_tab(nn_pair_index++) = pair_str (n , nn);						    
								
						has_pair_been_considered(n , nn) = true;
					      }
					  }
				      }
						  
				  has_SDn_been_considered = true;
						  
				}}}}}}}}
}


void H_class::pn_pairs_in_tab_pn_calc_on_the_fly (class array<class pair_str> &pn_pairs_in_tab) const
{
  if (!is_pn_non_zero) return;
  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
   
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 
  
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_data.get_dimensions_configuration_set ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set (); 
    
  const int Zval = prot_data.get_N_valence_nucleons (); 
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_data.get_N_nljm ()) : (prot_data.get_N_nljm_res ());
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_data.get_N_nljm ()) : (neut_data.get_N_nljm_res ());
  
  class Slater_determinant SDp(Zval);
  class Slater_determinant SDn(Nval);
  
  class array<bool> has_pair_been_considered(Np_nljm , Nn_nljm);
  
  has_pair_been_considered = false;

  unsigned int pn_pair_index = 0;
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP); 

      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int dimension_iCp = dimensions_configuration_p_set(BPp , n_scat_p);
	  
	  for (unsigned int iCp = 0 ; iCp < dimension_iCp ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

	      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);
	      
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

	      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
		{
		  const unsigned int dimension_iCn = dimensions_configuration_n_set(BPn , n_scat_n);
		  
		  for (unsigned int iCn = 0 ; iCn < dimension_iCn ; iCn++)
		    {
		      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
		      const int En = En_hw_table(BPn , n_scat_n , iCn);

		      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw))
			{
			  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
			    {			
			      const int iMn = iM - iMp;

			      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);
			      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

			      if ((dimension_SDn == 0) || (dimension_SDp == 0)) continue;

			      const unsigned long int total_index_zero_SDp = SDp_set.index_determine (BPp , n_scat_p , iCp , iMp , 0);
			      const unsigned long int total_index_zero_SDn = SDn_set.index_determine (BPn , n_scat_n , iCn , iMn , 0);

			      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
				{
				  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
				    {
				      const unsigned long int total_index_SDp = total_index_zero_SDp + SDp_index;
				      const unsigned long int total_index_SDn = total_index_zero_SDn + SDn_index;
						      
				      SDp = SDp_set[total_index_SDp];
				      SDn = SDn_set[total_index_SDn];
						  
				      for (int ip = 0 ; ip < Zval ; ip++)
					for (int in = 0 ; in < Nval ; in++)
					  {
					    const unsigned int p = SDp[ip];
					    const unsigned int n = SDn[in];

					    if (!has_pair_been_considered(p , n))
					      {
						pn_pairs_in_tab(pn_pair_index++) = pair_str (p , n);
								
						has_pair_been_considered(p , n) = true;
							    
					      }}}}}}}}}}}
}
  




void H_class::pairs_in_tab_pp_nn_calc_on_the_fly (class array<class pair_str> &pairs_in_tab) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
   
  const int iM = GSM_vector_helper.get_iM ();
     
  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);
  
  const class array_BP_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();
  
  const class array_of_SD &SD_set = data.get_SD_set ();
  
  const unsigned int N_nljm = (n_scat_max > 0) ? (data.get_N_nljm ()) : (data.get_N_nljm_res ());

  const int N_valence_nucleons = data.get_N_valence_nucleons ();

  class Slater_determinant SD(N_valence_nucleons);
    
  class array<bool> has_pair_been_considered(N_nljm , N_nljm);
  
  has_pair_been_considered = false;

  unsigned int pair_index = 0;
  
  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int dimension_iC = dimensions_configuration_set(BP , n_scat);
      
      for (unsigned int iC = 0 ; iC < dimension_iC ; iC++)
	{ 
	  const int n_holes = n_holes_table(BP , n_scat , iC);
	  
	  const int E = E_hw_table(BP , n_scat , iC);
	  
	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD_set = dimensions_SD_set(BP , n_scat , iC , iM);

	  if (dimension_SD_set == 0) continue;
	  
	  const unsigned long int total_index_zero_SD = SD_set.index_determine (BP , n_scat , iC , iM , 0);
	  
	  for (unsigned int SD_index = 0 ; SD_index < dimension_SD_set ; SD_index++)
	    {
	      const unsigned long int total_index_SD = total_index_zero_SD + SD_index;
			  
	      SD = SD_set[total_index_SD];

	      for (int i = 0 ; i < N_valence_nucleons ; i++)
		for (int ii = 0 ; ii < N_valence_nucleons ; ii++)
		  {
		    const unsigned int mu   = SD[i];
		    const unsigned int mu_p = SD[ii];

		    if (mu < mu_p)
		      {
			if (!has_pair_been_considered(mu , mu_p))
			  {
			    pairs_in_tab(pair_index++) = pair_str (mu , mu_p);
				    
			    has_pair_been_considered(mu , mu_p) = true;
			  }}}}}}
}



















void H_class::pp_pairs_out_tab_pn_calc_on_the_fly (class array<class pair_str> &pp_pairs_out_tab) const
{ 
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
       
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 
  
  const int Zval = prot_data.get_N_valence_nucleons ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
   
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_data.get_N_nljm ()) : (prot_data.get_N_nljm_res ());
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
        
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  class Slater_determinant SDp(Zval);
  
  class array<bool> has_pair_been_considered(Np_nljm , Np_nljm);
  
  has_pair_been_considered = false;

  unsigned int pp_pair_index = 0;

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP); 

      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , n_scat_p);
	  
	  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

	      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);

	      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
		{			
		  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);

		  if (dimension_SDp == 0) continue;
        
		  const int iMn = iM - iMp;
		  
		  const unsigned long int total_SDp_index_zero = SDp_set.index_determine (BPp , n_scat_p , iCp , iMp , 0);
				  
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      bool has_SDp_been_considered = false;
			      
		      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && (!has_SDp_been_considered) ; n_scat_n++)
			{
			  const unsigned int iCn_min = iCn_min_process_tab(BPn , n_scat_n);
			  const unsigned int iCn_max = iCn_max_process_tab(BPn , n_scat_n);
		  
			  for (unsigned int iCn = iCn_min ; (iCn <= iCn_max) && (!has_SDp_been_considered) ; iCn++)
			    {
			      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
			      const int En = En_hw_table(BPn , n_scat_n , iCn);
				      
			      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw))
				{
				  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);
				  if (dimension_SDn == 0) continue;
				  
				  const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , n_scat_p , n_scat_n , iCp , iCn , iMp);
				      
				  const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;
				  const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDn_minus_one;
				  
				  if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
				    {
				      for (unsigned int SDn_index = 0 ; (SDn_index < dimension_SDn) && (!has_SDp_been_considered) ; SDn_index++)
					{
					  const unsigned long int total_PSI_index = total_PSI_index_zero + SDn_index;
				      					     
					  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
					    {
					      const unsigned long int total_index_SDp = total_SDp_index_zero + SDp_index;

					      SDp = SDp_set[total_index_SDp];
					      
					      for (int ip = 0 ; ip < Zval ; ip++)
						for (int ipp = 0 ; ipp < Zval ; ipp++)
						  {
						    const unsigned int p  = SDp[ip];
						    const unsigned int pp = SDp[ipp];
						    
						    if (p < pp)
						      {
							if (!has_pair_been_considered(p , pp))
							  {
							    pp_pairs_out_tab(pp_pair_index++) = pair_str (p , pp);
								
							    has_pair_been_considered(p , pp) = true;
							  }
						      }
						  }
						  
					      has_SDp_been_considered = true;
						  
					    }}}}}}}}}}}
}





void H_class::nn_pairs_out_tab_pn_calc_on_the_fly (class array<class pair_str> &nn_pairs_out_tab) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
      
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDn_set = neut_data.get_SD_set ();
  
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_data.get_N_nljm ()) : (neut_data.get_N_nljm_res ());
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
        
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  class Slater_determinant SDn(Nval);
  
  class array<bool> has_pair_been_considered(Nn_nljm , Nn_nljm);
  
  has_pair_been_considered = false;

  unsigned int nn_pair_index = 0;
  
  for (unsigned int BPn = 0 ; BPn <= 1 ; BPn++)
    {
      const unsigned int BPp = binary_parity_product (BPn , BP); 

      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_process_tab(BPn , n_scat_n);
	  const unsigned int iCn_max = iCn_max_process_tab(BPn , n_scat_n);
		  
	  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
	      const int En = En_hw_table(BPn , n_scat_n , iCn);

	      for (int iMn = iMn_min_M ; iMn <= iMn_max_M ; iMn++)
		{			
		  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

		  if (dimension_SDn == 0) continue;
        
		  const int iMp = iM - iMn;
			  			  
		  const unsigned long int total_SDn_index_zero = SDn_set.index_determine (BPn , n_scat_n , iCn , iMn , 0);

		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      bool has_SDn_been_considered = false;

		      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && (!has_SDn_been_considered) ; n_scat_p++)
			{
			  const unsigned int iCp_min = iCp_min_process_tab(BPp , n_scat_p);
			  const unsigned int iCp_max = iCp_max_process_tab(BPp , n_scat_p);
	  
			  for (unsigned int iCp = iCp_min ; (iCp <= iCp_max) && (!has_SDn_been_considered) ; iCp++)
			    {
			      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

			      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);
				      
			      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw))
				{
				  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);

				  if (dimension_SDp == 0) continue;
				  
				  const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;
				  
				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , n_scat_p , n_scat_n , iCp , iCn , iMp);
					  
				  const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + SDn_index;
				  const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDp_minus_one*dimension_SDn;

				  if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
				    {
				      for (unsigned int SDp_index = 0 ; (SDp_index < dimension_SDp) && (!has_SDn_been_considered) ; SDp_index++)
					{
					  const unsigned long int total_PSI_index = total_PSI_index_zero + SDp_index*dimension_SDn;
						  
					  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
					    {	
					      const unsigned long int total_index_SDn = total_SDn_index_zero + SDn_index;

					      SDn = SDn_set[total_index_SDn];
						      
					      for (int in = 0 ; in < Nval ; in++)
						for (int inn = 0 ; inn < Nval ; inn++)
						  {
						    const unsigned int n  = SDn[in];
						    const unsigned int nn = SDn[inn];

						    if (n < nn)
						      {
							if (!has_pair_been_considered(n , nn))
							  {
							    nn_pairs_out_tab(nn_pair_index++) = pair_str (n , nn);
		  								    
							    has_pair_been_considered(n , nn) = true;
							  }
						      }
						  }
						  
					      has_SDn_been_considered = true;
						  
					    }}}}}}}}}}}
}





void H_class::pn_pairs_out_tab_pn_calc_on_the_fly (class array<class pair_str> &pn_pairs_out_tab) const
{
  if (!is_pn_non_zero) return;
   
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
   
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector (); 
  
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_data.get_SD_set (); 
    
  const int Zval = prot_data.get_N_valence_nucleons (); 
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_data.get_N_nljm ()) : (prot_data.get_N_nljm_res ());
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_data.get_N_nljm ()) : (neut_data.get_N_nljm_res ());
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
                
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  class Slater_determinant SDp(Zval);
  class Slater_determinant SDn(Nval);
  
  class array<bool> has_pair_been_considered(Np_nljm , Nn_nljm);
  
  has_pair_been_considered = false;

  unsigned int pn_pair_index = 0;

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP); 

      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_process_tab(BPp , n_scat_p);
	  const unsigned int iCp_max = iCp_max_process_tab(BPp , n_scat_p);
	  
	  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);

	      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);
	      
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

	      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
		{
		  const unsigned int iCn_min = iCn_min_process_tab(BPn , n_scat_n);
		  const unsigned int iCn_max = iCn_max_process_tab(BPn , n_scat_n);
		  
		  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
		    {
		      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
		      const int En = En_hw_table(BPn , n_scat_n , iCn);

		      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw))
			{
			  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
			    {
			      const int iMn = iM - iMp;
				      
			      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);
			      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);

			      if ((dimension_SDn == 0) || (dimension_SDp == 0)) continue;
				      
			      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , n_scat_p , n_scat_n , iCp , iCn , iMp);
			      
			      const unsigned long int total_index_zero_SDp = SDp_set.index_determine (BPp , n_scat_p , iCp , iMp , 0);
			      const unsigned long int total_index_zero_SDn = SDn_set.index_determine (BPn , n_scat_n , iCn , iMn , 0);
							  
			      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;
			      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;
				      
			      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed;			      

			      const unsigned long int total_PSI_index_dimension_minus_one = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*dimension_SDp_minus_one + dimension_SDn_minus_one;

			      if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
				{
				  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
				    {
				      const unsigned long int total_PSI_index_zero_SDp_fixed = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;
				      const unsigned long int total_PSI_index_dimension_minus_one_SDp_fixed = total_PSI_index_zero_SDp_fixed + dimension_SDn_minus_one;

				      if ((total_PSI_index_zero_SDp_fixed <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one_SDp_fixed >= first_total_PSI_index))
					{
					  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
					    {
					      const unsigned long int total_PSI_index = total_PSI_index_zero_SDp_fixed + SDn_index;

					      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
						{
						  const unsigned long int total_index_SDp = total_index_zero_SDp + SDp_index;
						  const unsigned long int total_index_SDn = total_index_zero_SDn + SDn_index;
						      
						  SDp = SDp_set[total_index_SDp];
						  SDn = SDn_set[total_index_SDn];
					  
						  for (int ip = 0 ; ip < Zval ; ip++)
						    for (int in = 0 ; in < Nval ; in++)
						      {
							const unsigned int p = SDp[ip];
							const unsigned int n = SDn[in];

							if (!has_pair_been_considered(p , n))
							  {
							    pn_pairs_out_tab(pn_pair_index++) = pair_str (p , n);
								
							    has_pair_been_considered(p , n) = true;
							    
							  }}}}}}}}}}}}}}
}








void H_class::pairs_out_tab_pp_nn_calc_on_the_fly (class array<class pair_str> &pairs_out_tab) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
      
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
   
  const int iM = GSM_vector_helper.get_iM (); 

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector (); 
 
  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);
  
  const class array_BP_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();
  
  const class array_of_SD &SD_set = data.get_SD_set ();
  
  const unsigned int N_nljm = (n_scat_max > 0) ? (data.get_N_nljm ()) : (data.get_N_nljm_res ());

  const int N_valence_nucleons = data.get_N_valence_nucleons ();
  
  const class array<unsigned int> &iC_min_process_tab = GSM_vector_helper.get_iC_min_process_tab ();
  const class array<unsigned int> &iC_max_process_tab = GSM_vector_helper.get_iC_max_process_tab ();
            
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  class Slater_determinant SD(N_valence_nucleons);
  
  class array<bool> has_pair_been_considered(N_nljm , N_nljm);
  
  has_pair_been_considered = false;

  unsigned int pair_index = 0;

  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int iC_min = iC_min_process_tab(n_scat);
      const unsigned int iC_max = iC_max_process_tab(n_scat);
      
      for (unsigned int iC = iC_min ; iC <= iC_max ; iC++)
	{ 
	  const int n_holes = n_holes_table(BP , n_scat , iC);
	  
	  const int E = E_hw_table(BP , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD_set = dimensions_SD_set(BP , n_scat , iC , iM);

	  if (dimension_SD_set == 0) continue;
	  
	  const unsigned long int total_index_zero_SD = SD_set.index_determine (BP , n_scat , iC , iM , 0);
	      
	  const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions_GSM_vector(n_scat , iC);

	  const unsigned int dimension_SD_set_minus_one = dimension_SD_set - 1;

	  const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_fixed;

	  const unsigned long int total_PSI_index_dimension_minus_one = sum_dimensions_configuration_fixed + dimension_SD_set_minus_one;
	  
	  if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
	    {
	      for (unsigned int SD_index = 0 ; SD_index < dimension_SD_set ; SD_index++)
		{
		  const unsigned long int total_PSI_index = total_PSI_index_zero + SD_index;

		  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
		    {
		      const unsigned long int total_index_SD = total_index_zero_SD + SD_index;
			  
		      SD = SD_set[total_index_SD];

		      for (int i = 0 ; i < N_valence_nucleons ; i++)
			for (int ii = 0 ; ii < N_valence_nucleons ; ii++)
			  {
			    const unsigned int mu   = SD[i];
			    const unsigned int mu_p = SD[ii];

			    if (mu < mu_p)
			      {
				if (!has_pair_been_considered(mu , mu_p))
				  {
				    pairs_out_tab(pair_index++) = pair_str (mu , mu_p);
					
				    has_pair_been_considered(mu , mu_p) = true;
				    
				  }}}}}}}}
}




void H_class::M_TBMEs_pp_nn_alloc_calc_on_the_fly ()
{  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
       
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const bool is_two_body_part_non_zero = (space == PROTONS_ONLY) ? (is_pp_non_zero) : (is_nn_non_zero);

  if (!is_two_body_part_non_zero) return;

  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);
  
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
      
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
     
  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);

  const unsigned int N_nljm = (n_scat_max > 0) ? (data.get_N_nljm ()) : (data.get_N_nljm_res ());
  
  const class array<class nljm_struct> &phi_table = data.get_phi_table ();
  
  const class TBMEs_class &TBMEs = data.get_TBMEs ();
  
  const unsigned int pairs_in_number  = pairs_in_number_pp_nn_calc_on_the_fly ();
  
  const unsigned int pairs_out_number = pairs_out_number_pp_nn_calc_on_the_fly ();
  
  class array<class pair_str> pairs_in_tab (pairs_in_number);
  
  class array<class pair_str> pairs_out_tab(pairs_out_number);
  
  pairs_in_tab_pp_nn_calc_on_the_fly  (pairs_in_tab);
  
  pairs_out_tab_pp_nn_calc_on_the_fly (pairs_out_tab);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time;
  
      cout << endl << space << " pairs for Hamiltonian uncoupled TBMEs calculated (on the fly). time:" << relative_time << " s" << endl << endl;
    }
  
  M_TBMEs.allocate (is_there_cout , N_nljm , pairs_in_tab , pairs_out_tab , phi_table , TBMEs);
}







void H_class::M_TBMEs_pn_alloc_calc_on_the_fly ()
{
  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);
    
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const class nucleons_data &prot_data = GSM_vector_helper.get_prot_data (); 
  const class nucleons_data &neut_data = GSM_vector_helper.get_neut_data ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const bool is_it_M_TBMEs_storage_full_storage = (M_TBMEs_storage == FULL_STORAGE);
  
  const bool is_it_M_TBMEs_partial_storage = (M_TBMEs_storage == PARTIAL_STORAGE);
  
  const bool is_it_M_TBMEs_pp_partial_storage = (is_it_M_TBMEs_partial_storage && (Nval >= Zval));      
  const bool is_it_M_TBMEs_nn_partial_storage = (is_it_M_TBMEs_partial_storage && (Nval <  Zval));
          
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_data.get_N_nljm ()) : (prot_data.get_N_nljm_res ());
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_data.get_N_nljm ()) : (neut_data.get_N_nljm_res ());
   
  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();
  
  const class TBMEs_class &TBMEs_pp = prot_data.get_TBMEs ();
  const class TBMEs_class &TBMEs_nn = neut_data.get_TBMEs ();

  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn (); 

  const bool is_pp_considered = (is_pp_non_zero && (is_it_M_TBMEs_storage_full_storage || is_it_M_TBMEs_pp_partial_storage));
  const bool is_nn_considered = (is_nn_non_zero && (is_it_M_TBMEs_storage_full_storage || is_it_M_TBMEs_nn_partial_storage));
  const bool is_pn_considered =  is_pn_non_zero;
  
  const unsigned int pp_pairs_in_number = (is_pp_considered) ? (pp_pairs_in_number_pn_calc_on_the_fly ()) : (0);
  const unsigned int nn_pairs_in_number = (is_nn_considered) ? (nn_pairs_in_number_pn_calc_on_the_fly ()) : (0);
  const unsigned int pn_pairs_in_number = (is_pn_considered) ? (pn_pairs_in_number_pn_calc_on_the_fly ()) : (0);

  const unsigned int pp_pairs_out_number = (is_pp_considered) ? (pp_pairs_out_number_pn_calc_on_the_fly ()) : (0);
  const unsigned int nn_pairs_out_number = (is_nn_considered) ? (nn_pairs_out_number_pn_calc_on_the_fly ()) : (0);  
  const unsigned int pn_pairs_out_number = (is_pn_considered) ? (pn_pairs_out_number_pn_calc_on_the_fly ()) : (0);
  
  class array<class pair_str> pp_pairs_in_tab(pp_pairs_in_number);
  class array<class pair_str> nn_pairs_in_tab(nn_pairs_in_number);
  class array<class pair_str> pn_pairs_in_tab(pn_pairs_in_number);

  class array<class pair_str> pp_pairs_out_tab(pp_pairs_out_number);
  class array<class pair_str> nn_pairs_out_tab(nn_pairs_out_number);
  class array<class pair_str> pn_pairs_out_tab(pn_pairs_out_number);

  if (is_pp_considered)
    {
      pp_pairs_in_tab_pn_calc_on_the_fly  (pp_pairs_in_tab);
      
      pp_pairs_out_tab_pn_calc_on_the_fly (pp_pairs_out_tab);
    }

  if (is_nn_considered)
    {
      nn_pairs_in_tab_pn_calc_on_the_fly  (nn_pairs_in_tab);
      
      nn_pairs_out_tab_pn_calc_on_the_fly (nn_pairs_out_tab);
    }
  
  if (is_pn_considered)
    {
      pn_pairs_in_tab_pn_calc_on_the_fly  (pn_pairs_in_tab);
      
      pn_pairs_out_tab_pn_calc_on_the_fly (pn_pairs_out_tab);
    }
  

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {      
      const double now = absolute_time_determine () , relative_time = now - reference_time;
      
      cout << endl << "pp, nn and pn pairs for Hamiltonian uncoupled TBMEs calculated (on the fly). time:" << relative_time << " s" << endl << endl;
    }
  
  M_TBMEs.allocate (is_there_cout , Np_nljm , Nn_nljm , is_pp_considered , is_nn_considered , is_pn_considered , pp_pairs_in_tab , nn_pairs_in_tab , pn_pairs_in_tab ,
		    pp_pairs_out_tab , nn_pairs_out_tab , pn_pairs_out_tab , phi_p_table , phi_n_table , TBMEs_pp , TBMEs_nn , TBMEs_pn);
}










