#include "../GSM_include/GSM_include_def.h"
#include "../GSM_include/GSM_include_def.h"

#include "../GSM_include/GSM_include_def.h"



// TYPE is double or complex
// -------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons
// ------------------------------------------------------------------------------------------------------------------------------------------------------


using namespace inputs_misc;
using namespace GSM_vector_NBMEs_handling;
using namespace GSM_vector_dimensions;


// Allocation, calculation and storage of uncoupled TBMEs for the on the fly method
// --------------------------------------------------------------------------------
// For some storage options of the on the fly method (see GSM_H_class.cpp), uncoupled TBMEs are stored instead of being recalculated from J-coupled TBMEs and Clebsch-Gordan coefficients.
//
// For this, one first counts the number of pp, nn and pn pairs of one-body states occurring in the basis SDs of one node, then one generates all these pairs,
// and one allocates the class containing uncoupled TBMEs, where the array containing all uncoupled TBMEs will be allocated and calculated.
//
// In this, one loops over proton and neutron Slater determinants, the first loop being proton or neutron according to the case.
//
// As the in and out SD spaces can be different when using MPI parallelization (i.e. those occurring in H.|Psi[in]> = |Psi[out]>),
// the pairs occurring in the in and out SD spaces are considered independently.
//
// OpenMP parallelization is not used here as routines counting and generating pairs are sequential, fast enough, and it would be cumbersome to parallelize them.
// MPI parallelization here is implicit, as on considers only the Slater determinants of the current node.
// OpenMP parallelization is, however, fully taken into account when allocating and calculating the uncoupled TBMEs in the M_TBMEs class.
//
// As the time taken to calculate all uncoupled TBMEs can be long, it can be written on screen.
//
// See GSM_vector_helper.cpp for the definition of total PSI indices.

unsigned int H_class::pp_pairs_in_number_pn_calc_on_the_fly () const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();   
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
    
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_Y_data.get_N_nljm_baryon ()) : (prot_Y_data.get_N_nljm_res_baryon ());
  
  class Slater_determinant SDp(ZYval);
  
  class array<bool> has_pair_been_considered(Np_nljm , Np_nljm);
  
  has_pair_been_considered = false;

  unsigned int pp_pairs_in_number = 0;
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BP , BPp);

      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;

	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p; 

	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int dimension_iCp = dimensions_configuration_p_set(BPp , Sp , n_spec_p , n_scat_p);
	  
		  for (unsigned int iCp = 0 ; iCp < dimension_iCp ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
		      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
			{			
			  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

			  if (dimension_SDp == 0) continue;
        
			  const int iMn = iM - iMp;
		  
			  const unsigned long int total_SDp_index_zero = SDp_set.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0);
		  
			  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
			    {
			      bool has_SDp_been_considered = false;
			      
			      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && (!has_SDp_been_considered) ; n_scat_n++)
				{
				  const unsigned int dimension_iCn = dimensions_configuration_n_set(BPn , Sn , n_spec_n , n_scat_n);
		  
				  for (unsigned int iCn = 0 ; (iCn < dimension_iCn) && (!has_SDp_been_considered) ; iCn++)
				    {
				      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
				      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
				      
				      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
				      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				
				      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

				      if (dimension_SDn == 0) continue;
				  
				      const unsigned long int total_index_SDp = total_SDp_index_zero + SDp_index;

				      SDp = SDp_set[total_index_SDp];
					      
				      for (int ip = 0 ; ip < ZYval ; ip++)
					for (int ipp = 0 ; ipp < ZYval ; ipp++)
					  {
					    const unsigned int p  = SDp[ip];
					    const unsigned int pp = SDp[ipp];
						    
					    if (p < pp)
					      {
						if (!has_pair_been_considered(p , pp))
						  {
						    pp_pairs_in_number++;
								
						    has_pair_been_considered(p , pp) = true;
						  }
					      }
					  }
						  
				      has_SDp_been_considered = true;
						  
				    }}}}}}}}}
  
  return pp_pairs_in_number;
}





unsigned int H_class::nn_pairs_in_number_pn_calc_on_the_fly () const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();   
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_Y_data.get_N_nljm_baryon ()) : (neut_Y_data.get_N_nljm_res_baryon ());
    
  class Slater_determinant SDn(NYval);
  
  class array<bool> has_pair_been_considered(Nn_nljm , Nn_nljm);
  
  has_pair_been_considered = false;

  unsigned int nn_pairs_in_number = 0;
  	  
  for (unsigned int BPn = 0 ; BPn <= 1 ; BPn++)
    {
      const unsigned int BPp = binary_parity_product (BPn , BP); 

      for (int Sn = 0 ; Sn <= S ; Sn++)
	{
	  const int Sp = S - Sn;
	  	  
	  for (int n_spec_n = 0 ; n_spec_n <= n_spec_max ; n_spec_n++)
	    {
	      const int n_spec_p = n_spec_max - n_spec_n; 

	      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
		{
		  const unsigned int dimension_iCn = dimensions_configuration_n_set(BPn , Sn , n_spec_n , n_scat_n);
		  
		  for (unsigned int iCn = 0 ; iCn < dimension_iCn ; iCn++)
		    {
		      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
		      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
		      for (int iMn = iMn_min_M ; iMn <= iMn_max_M ; iMn++)
			{			
			  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

			  if (dimension_SDn == 0) continue;
        
			  const int iMp = iM - iMn;
		  
			  const unsigned long int total_SDn_index_zero = SDn_set.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0);
		  
			  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
			    {
			      bool has_SDn_been_considered = false;

			      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && (!has_SDn_been_considered) ; n_scat_p++)
				{
				  const unsigned int dimension_iCp = dimensions_configuration_p_set(BPp , Sp , n_spec_p , n_scat_p);
	  
				  for (unsigned int iCp = 0 ; (iCp < dimension_iCp) && (!has_SDn_been_considered) ; iCp++)
				    {
				      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

				      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
				      
				      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
				      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			      
				      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
				  
				      if (dimension_SDp == 0) continue;
				
				      const unsigned long int total_index_SDn = total_SDn_index_zero + SDn_index;

				      SDn = SDn_set[total_index_SDn];
						  
				      for (int in = 0 ; in < NYval ; in++)
					for (int inn = 0 ; inn < NYval ; inn++)
					  {
					    const unsigned int n  = SDn[in];
					    const unsigned int nn = SDn[inn];

					    if (n < nn)
					      {
						if (!has_pair_been_considered(n , nn))
						  {
						    nn_pairs_in_number++;
								
						    has_pair_been_considered(n , nn) = true;						    
						  }
					      }
					  }
						  
				      has_SDn_been_considered = true;
						  
				    }}}}}}}}}

  return nn_pairs_in_number;
}










unsigned int H_class::pn_pairs_in_number_pn_calc_on_the_fly () const
{
  if (!is_pn_non_zero) return 0;
   
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
   
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set (); 
    
  const int ZYval = prot_Y_data.get_N_valence_baryons (); 
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_Y_data.get_N_nljm_baryon ()) : (prot_Y_data.get_N_nljm_res_baryon ());
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_Y_data.get_N_nljm_baryon ()) : (neut_Y_data.get_N_nljm_res_baryon ());
        
  class Slater_determinant SDp(ZYval);
  class Slater_determinant SDn(NYval);
  
  class array<bool> has_pair_been_considered(Np_nljm , Nn_nljm);
  
  has_pair_been_considered = false;

  unsigned int pn_pairs_in_number = 0;
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BP , BPp);

      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;

	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p; 

	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int dimension_iCp = dimensions_configuration_p_set(BPp , Sp , n_spec_p , n_scat_p);
	  
		  for (unsigned int iCp = 0 ; iCp < dimension_iCp ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

		      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
			{
			  const unsigned int dimension_iCn = dimensions_configuration_n_set(BPn , Sn , n_spec_n , n_scat_n);
		  
			  for (unsigned int iCn = 0 ; iCn < dimension_iCn ; iCn++)
			    {
			      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
			      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

			      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
				{			
				  const int iMn = iM - iMp;

				  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
				  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

				  if ((dimension_SDn == 0) || (dimension_SDp == 0)) continue;

				  const unsigned long int total_index_zero_SDp = SDp_set.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0);
				  const unsigned long int total_index_zero_SDn = SDn_set.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0);

				  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
				    {
				      for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
					{
					  const unsigned long int total_index_SDp = total_index_zero_SDp + SDp_index;
					  const unsigned long int total_index_SDn = total_index_zero_SDn + SDn_index;
						      
					  SDp = SDp_set[total_index_SDp];
					  SDn = SDn_set[total_index_SDn];
						  
					  for (int ip = 0 ; ip < ZYval ; ip++)
					    for (int in = 0 ; in < NYval ; in++)
					      {
						const unsigned int p = SDp[ip];
						const unsigned int n = SDn[in];

						if (!has_pair_been_considered(p , n))
						  {
						    pn_pairs_in_number++;
								
						    has_pair_been_considered(p , n) = true;
						
						  }}}}}}}}}}}}

  return pn_pairs_in_number;
}







unsigned int H_class::pairs_in_number_pp_nn_calc_on_the_fly () const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
     
  const int iM = GSM_vector_helper.get_iM ();
     
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();
  
  const class array_of_SD &SD_set = data.get_SD_set ();
  
  const unsigned int N_nljm = (n_scat_max > 0) ? (data.get_N_nljm_baryon ()) : (data.get_N_nljm_res_baryon ());
  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  class Slater_determinant SD(N_valence_baryons);
  
  class array<bool> has_pair_been_considered(N_nljm , N_nljm);
  
  has_pair_been_considered = false;

  unsigned int pairs_in_number = 0;
  	  
  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int dimension_iC = dimensions_configuration_set(BP , S , 0 , n_scat);
      
      for (unsigned int iC = 0 ; iC < dimension_iC ; iC++)
	{ 
	  const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
	  const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);
	  
	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD_set = dimensions_SD_set(BP , S , 0 , n_scat , iC , iM);
	  if (dimension_SD_set == 0) continue;
	  
	  const unsigned long int total_index_zero_SD = SD_set.index_determine (BP , S , 0 , n_scat , iC , iM , 0);

	  for (unsigned int SD_index = 0 ; SD_index < dimension_SD_set ; SD_index++)
	    {
	      const unsigned long int total_index_SD = total_index_zero_SD + SD_index;
			  
	      SD = SD_set[total_index_SD];

	      for (int i = 0 ; i < N_valence_baryons ; i++)
		for (int ii = 0 ; ii < N_valence_baryons ; ii++)
		  {
		    const unsigned int mu   = SD[i];
		    const unsigned int mu_p = SD[ii];

		    if (mu < mu_p)
		      {
			if (!has_pair_been_considered(mu , mu_p))
			  {
			    pairs_in_number++;
					
			    has_pair_been_considered(mu , mu_p) = true;
				    
			  }}}}}}

  return pairs_in_number;
}






unsigned int H_class::pp_pairs_out_number_pn_calc_on_the_fly () const
{ 
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();   
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
   
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_Y_data.get_N_nljm_baryon ()) : (prot_Y_data.get_N_nljm_res_baryon ());
    
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
  
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index =  GSM_vector_helper.get_last_total_PSI_index ();
  
  class Slater_determinant SDp(ZYval);
  
  class array<bool> has_pair_been_considered(Np_nljm , Np_nljm);
  
  has_pair_been_considered = false;

  unsigned int pp_pairs_out_number = 0;
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BP , BPp);

      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;

	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p; 

	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
		  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
							    
		  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
		      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
			{			
			  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

			  if (dimension_SDp == 0) continue;
        
			  const int iMn = iM - iMp;
			  
			  const unsigned long int total_SDp_index_zero = SDp_set.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0);
			  
			  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
			    {
			      bool has_SDp_been_considered = false;
							    
			      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && (!has_SDp_been_considered) ; n_scat_n++)
				{
				  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
				  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  
				  for (unsigned int iCn = iCn_min ; (iCn <= iCn_max) && (!has_SDp_been_considered) ; iCn++)
				    {
				      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
				      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
				
				      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
				      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

				      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

				      if (dimension_SDn == 0) continue;
				  
				      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

				      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

				      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;

				      const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDn_minus_one;
				  
				      if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
					{
					  for (unsigned int SDn_index = 0 ; (SDn_index < dimension_SDn) && (!has_SDp_been_considered) ; SDn_index++)
					    {
					      const unsigned long int total_PSI_index = total_PSI_index_zero + SDn_index;
				      					     
					      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
						{
						  const unsigned long int total_index_SDp = total_SDp_index_zero + SDp_index;

						  SDp = SDp_set[total_index_SDp];
					      
						  for (int ip = 0 ; ip < ZYval ; ip++)
						    for (int ipp = 0 ; ipp < ZYval ; ipp++)
						      {
							const unsigned int p  = SDp[ip];
							const unsigned int pp = SDp[ipp];
						    
							if (p < pp)
							  {
							    if (!has_pair_been_considered(p , pp))
							      {
								pp_pairs_out_number++;
								    
								has_pair_been_considered(p , pp) = true;
							      }
							  }
						      }
						  
						  has_SDp_been_considered = true;
						  
						}}}}}}}}}}}}
  
  return pp_pairs_out_number;
}


unsigned int H_class::nn_pairs_out_number_pn_calc_on_the_fly () const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
      
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();   
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_Y_data.get_N_nljm_baryon ()) : (neut_Y_data.get_N_nljm_res_baryon ());
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
    	      
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();

  class Slater_determinant SDn(NYval);
  
  class array<bool> has_pair_been_considered(Nn_nljm , Nn_nljm);
  
  has_pair_been_considered = false;

  unsigned int nn_pairs_out_number = 0;
  
  for (unsigned int BPn = 0 ; BPn <= 1 ; BPn++)
    {
      const unsigned int BPp = binary_parity_product (BPn , BP); 

      for (int Sn = 0 ; Sn <= S ; Sn++)
	{
	  const int Sp = S - Sn;
	  	  
	  for (int n_spec_n = 0 ; n_spec_n <= n_spec_max ; n_spec_n++)
	    {
	      const int n_spec_p = n_spec_max - n_spec_n; 

	      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
		{
		  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  
		  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
		    {
		      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
		      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
		      for (int iMn = iMn_min_M ; iMn <= iMn_max_M ; iMn++)
			{			
			  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

			  if (dimension_SDn == 0) continue;
        
			  const int iMp = iM - iMn;
			  
			  const unsigned long int total_SDn_index_zero = SDn_set.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0);
			  
			  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
			    {					      
			      bool has_SDn_been_considered = false;

			      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && (!has_SDn_been_considered) ; n_scat_p++)
				{
				  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
				  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  
				  for (unsigned int iCp = iCp_min ; (iCp <= iCp_max) && (!has_SDn_been_considered) ; iCp++)
				    {
				      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

				      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
				      
				      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
				      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

				      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

				      if (dimension_SDp == 0) continue;
				  
				      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;
				  
				      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);					  
				  
				      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + SDn_index;

				      const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDp_minus_one*dimension_SDn;

				      if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
					{
					  for (unsigned int SDp_index = 0 ; (SDp_index < dimension_SDp) && (!has_SDn_been_considered) ; SDp_index++)
					    {
					      const unsigned long int total_PSI_index = total_PSI_index_zero + SDp_index*dimension_SDn;

					      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
						{
						  const unsigned long int total_index_SDn = total_SDn_index_zero + SDn_index;

						  SDn = SDn_set[total_index_SDn];
						  
						  for (int in = 0 ; in < NYval ; in++)
						    for (int inn = 0 ; inn < NYval ; inn++)
						      {
							const unsigned int n  = SDn[in];
							const unsigned int nn = SDn[inn];

							if (n < nn)
							  {
							    if (!has_pair_been_considered(n , nn))
							      {
								nn_pairs_out_number++;
								    
								has_pair_been_considered(n , nn) = true;
							      }
							  }
						      }
						  
						  has_SDn_been_considered = true;
						  
						}}}}}}}}}}}}

  return nn_pairs_out_number;
}








unsigned int H_class::pn_pairs_out_number_pn_calc_on_the_fly () const
{
  if (!is_pn_non_zero) return 0;
   
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
   
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector (); 
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set (); 
    
  const int ZYval = prot_Y_data.get_N_valence_baryons (); 
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_Y_data.get_N_nljm_baryon ()) : (prot_Y_data.get_N_nljm_res_baryon ());
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_Y_data.get_N_nljm_baryon ()) : (neut_Y_data.get_N_nljm_res_baryon ());
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
            
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  class Slater_determinant SDp(ZYval);
  class Slater_determinant SDn(NYval);
  
  class array<bool> has_pair_been_considered(Np_nljm , Nn_nljm);
  
  has_pair_been_considered = false;

  unsigned int pn_pairs_out_number = 0;
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BP , BPp);

      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;

	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p; 

	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
		  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  
		  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

		      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
			{
			  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
			  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  
			  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
			    {
			      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
			      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

			      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
				{
				  const int iMn = iM - iMp;
				      
				  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
				  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);
				      
				  if ((dimension_SDn == 0) || (dimension_SDp == 0)) continue;
				      
				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);			  
					  
				  const unsigned long int total_index_zero_SDp = SDp_set.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0);
				  const unsigned long int total_index_zero_SDn = SDn_set.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0);
				      
				  const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;
				  const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;
				      
				  const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed;
				      
				  const unsigned long int total_PSI_index_dimension_minus_one = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*dimension_SDp_minus_one + dimension_SDn_minus_one;
						  
				  if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
				    {
				      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
					{
					  const unsigned long int total_PSI_index_zero_SDp_fixed = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;
					  const unsigned long int total_PSI_index_dimension_minus_one_SDp_fixed = total_PSI_index_zero_SDp_fixed + dimension_SDn_minus_one;

					  if ((total_PSI_index_zero_SDp_fixed <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one_SDp_fixed >= first_total_PSI_index))
					    {
					      for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
						{
						  const unsigned long int total_PSI_index = total_PSI_index_zero_SDp_fixed + SDn_index;

						  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
						    {
						      const unsigned long int total_index_SDp = total_index_zero_SDp + SDp_index;
						      const unsigned long int total_index_SDn = total_index_zero_SDn + SDn_index;
						      
						      SDp = SDp_set[total_index_SDp];
						      SDn = SDn_set[total_index_SDn];
					  
						      for (int ip = 0 ; ip < ZYval ; ip++)
							for (int in = 0 ; in < NYval ; in++)
							  {
							    const unsigned int p = SDp[ip];
							    const unsigned int n = SDn[in];

							    if (!has_pair_been_considered(p , n))
							      {
								pn_pairs_out_number++;
								
								has_pair_been_considered(p , n) = true;
							    
							      }}}}}}}}}}}}}}}

  return pn_pairs_out_number;
}









unsigned int H_class::pairs_out_number_pp_nn_calc_on_the_fly () const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
      
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
     
  const int iM = GSM_vector_helper.get_iM ();
         
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector (); 
 
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();
  
  const class array_of_SD &SD_set = data.get_SD_set ();
  
  const unsigned int N_nljm = (n_scat_max > 0) ? (data.get_N_nljm_baryon ()) : (data.get_N_nljm_res_baryon ());

  const int N_valence_baryons = data.get_N_valence_baryons ();

  const class array<unsigned int> &iC_min_process_tab = GSM_vector_helper.get_iC_min_process_tab ();
  const class array<unsigned int> &iC_max_process_tab = GSM_vector_helper.get_iC_max_process_tab ();
          
  const unsigned long int first_total_PSI_index =  GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  class Slater_determinant SD(N_valence_baryons);
  
  class array<bool> has_pair_been_considered(N_nljm , N_nljm);
  
  has_pair_been_considered = false;

  unsigned int pairs_out_number = 0;

  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int iC_min = iC_min_process_tab(n_scat);
      const unsigned int iC_max = iC_max_process_tab(n_scat);
      
      for (unsigned int iC = iC_min ; iC <= iC_max ; iC++)
	{ 
	  const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
	  const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD_set = dimensions_SD_set(BP , S , 0 , n_scat , iC , iM);

	  if (dimension_SD_set == 0) continue;
	  
	  const unsigned long int total_index_zero_SD = SD_set.index_determine (BP , S , 0 , n_scat , iC , iM , 0);
	      
	  const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions_GSM_vector(n_scat , iC);

	  const unsigned int dimension_SD_set_minus_one = dimension_SD_set - 1;

	  const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_fixed;

	  const unsigned long int total_PSI_index_dimension_minus_one = sum_dimensions_configuration_fixed + dimension_SD_set_minus_one;
	  
	  if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
	    {
	      for (unsigned int SD_index = 0 ; SD_index < dimension_SD_set ; SD_index++)
		{
		  const unsigned long int total_PSI_index = total_PSI_index_zero + SD_index;

		  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
		    {
		      const unsigned long int total_index_SD = total_index_zero_SD + SD_index;
			  
		      SD = SD_set[total_index_SD];

		      for (int i = 0 ; i < N_valence_baryons ; i++)
			for (int ii = 0 ; ii < N_valence_baryons ; ii++)
			  {
			    const unsigned int mu   = SD[i];
			    const unsigned int mu_p = SD[ii];

			    if (mu < mu_p)
			      {
				if (!has_pair_been_considered(mu , mu_p))
				  {
				    pairs_out_number++;
					
				    has_pair_been_considered(mu , mu_p) = true;
				    
				  }}}}}}}}
  
  return pairs_out_number;
}




void H_class::pp_pairs_in_tab_pn_calc_on_the_fly (class array<class pair_str> &pp_pairs_in_tab) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();   
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_Y_data.get_N_nljm_baryon ()) : (prot_Y_data.get_N_nljm_res_baryon ());

  class Slater_determinant SDp(ZYval);
  
  class array<bool> has_pair_been_considered(Np_nljm , Np_nljm);
  
  has_pair_been_considered = false;

  unsigned int pp_pair_index = 0;
						    
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BP , BPp);

      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;

	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p; 

	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int dimension_iCp = dimensions_configuration_p_set(BPp , Sp , n_spec_p , n_scat_p);
	  
		  for (unsigned int iCp = 0 ; iCp < dimension_iCp ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
		      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
			{			
			  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

			  if (dimension_SDp == 0) continue;
        
			  const int iMn = iM - iMp;
		  
			  const unsigned long int total_SDp_index_zero = SDp_set.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0);
		  
			  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
			    {
			      bool has_SDp_been_considered = false;
			      
			      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && (!has_SDp_been_considered) ; n_scat_n++)
				{
				  const unsigned int dimension_iCn = dimensions_configuration_n_set(BPn , Sn , n_spec_n , n_scat_n);
		  
				  for (unsigned int iCn = 0 ; (iCn < dimension_iCn) && (!has_SDp_been_considered) ; iCn++)
				    {
				      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
				      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
				      
				      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
				      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

				      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

				      if (dimension_SDn == 0) continue;
				  
				      const unsigned long int total_index_SDp = total_SDp_index_zero + SDp_index;

				      SDp = SDp_set[total_index_SDp];
					      
				      for (int ip = 0 ; ip < ZYval ; ip++)
					for (int ipp = 0 ; ipp < ZYval ; ipp++)
					  {
					    const unsigned int p  = SDp[ip];
					    const unsigned int pp = SDp[ipp];
						    
					    if (p < pp)
					      {
						if (!has_pair_been_considered(p , pp))
						  {
						    const class nljm_struct &phi_p  = phi_p_table(p);
						    const class nljm_struct &phi_pp = phi_p_table(pp);

						    const enum particle_type particle_p  = phi_p.get_particle ();	
						    const enum particle_type particle_pp = phi_pp.get_particle ();
		  
						    pp_pairs_in_tab(pp_pair_index++) = pair_str (particle_p , p , particle_pp , pp);
						    
						    has_pair_been_considered(p , pp) = true;
						  }
					      }
					  }
						  
				      has_SDp_been_considered = true;
						  
				    }}}}}}}}}
}









								
void H_class::nn_pairs_in_tab_pn_calc_on_the_fly (class array<class pair_str> &nn_pairs_in_tab) const  
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();   
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();

  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_Y_data.get_N_nljm_baryon ()) : (neut_Y_data.get_N_nljm_res_baryon ());
  
  class Slater_determinant SDn(NYval);
  
  class array<bool> has_pair_been_considered(Nn_nljm , Nn_nljm);
  
  has_pair_been_considered = false;
  	  
  unsigned int nn_pair_index = 0;
  
  for (unsigned int BPn = 0 ; BPn <= 1 ; BPn++)
    {
      const unsigned int BPp = binary_parity_product (BPn , BP); 

      for (int Sn = 0 ; Sn <= S ; Sn++)
	{
	  const int Sp = S - Sn;
	  	  
	  for (int n_spec_n = 0 ; n_spec_n <= n_spec_max ; n_spec_n++)
	    {
	      const int n_spec_p = n_spec_max - n_spec_n; 

	      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
		{
		  const unsigned int dimension_iCn = dimensions_configuration_n_set(BPn , Sn , n_spec_n , n_scat_n);
		  
		  for (unsigned int iCn = 0 ; iCn < dimension_iCn ; iCn++)
		    {
		      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
		      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
		      for (int iMn = iMn_min_M ; iMn <= iMn_max_M ; iMn++)
			{			
			  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

			  if (dimension_SDn == 0) continue;
        
			  const int iMp = iM - iMn;
		  
			  const unsigned long int total_SDn_index_zero = SDn_set.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0);
		  
			  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
			    {
			      bool has_SDn_been_considered = false;

			      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && (!has_SDn_been_considered) ; n_scat_p++)
				{
				  const unsigned int dimension_iCp = dimensions_configuration_p_set(BPp , Sp , n_spec_p , n_scat_p);
	  
				  for (unsigned int iCp = 0 ; (iCp < dimension_iCp) && (!has_SDn_been_considered) ; iCp++)
				    {
				      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

				      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
				      
				      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
				      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

				      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

				      if (dimension_SDp == 0) continue;
				  
				      const unsigned long int total_index_SDn = total_SDn_index_zero + SDn_index;

				      SDn = SDn_set[total_index_SDn];
						  
				      for (int in = 0 ; in < NYval ; in++)
					for (int inn = 0 ; inn < NYval ; inn++)
					  {
					    const unsigned int n  = SDn[in];
					    const unsigned int nn = SDn[inn];

					    if (n < nn)
					      {
						if (!has_pair_been_considered(n , nn))
						  {
						    const class nljm_struct &phi_n  = phi_n_table(n);
						    const class nljm_struct &phi_nn = phi_n_table(nn);

						    const enum particle_type particle_n  = phi_n.get_particle ();	
						    const enum particle_type particle_nn = phi_nn.get_particle ();
						      
						    nn_pairs_in_tab(nn_pair_index++) = pair_str (particle_n , n , particle_nn , nn);
								
						    has_pair_been_considered(n , nn) = true;
						  }
					      }
					  }
						  
				      has_SDn_been_considered = true;
						  
				    }}}}}}}}}
}


void H_class::pn_pairs_in_tab_pn_calc_on_the_fly (class array<class pair_str> &pn_pairs_in_tab) const
{
  if (!is_pn_non_zero) return;
  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
   
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 
  
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set (); 
    
  const int ZYval = prot_Y_data.get_N_valence_baryons (); 
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_Y_data.get_N_nljm_baryon ()) : (prot_Y_data.get_N_nljm_res_baryon ());
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_Y_data.get_N_nljm_baryon ()) : (neut_Y_data.get_N_nljm_res_baryon ());
  
  class Slater_determinant SDp(ZYval);
  class Slater_determinant SDn(NYval);
  
  class array<bool> has_pair_been_considered(Np_nljm , Nn_nljm);
  
  has_pair_been_considered = false;

  unsigned int pn_pair_index = 0;
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BP , BPp);

      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;

	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p; 

	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int dimension_iCp = dimensions_configuration_p_set(BPp , Sp , n_spec_p , n_scat_p);
	  
		  for (unsigned int iCp = 0 ; iCp < dimension_iCp ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

		      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
			{
			  const unsigned int dimension_iCn = dimensions_configuration_n_set(BPn , Sn , n_spec_n , n_scat_n);
		  
			  for (unsigned int iCn = 0 ; iCn < dimension_iCn ; iCn++)
			    {
			      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
			      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

			      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
				{			
				  const int iMn = iM - iMp;

				  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
				  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

				  if ((dimension_SDn == 0) || (dimension_SDp == 0)) continue;

				  const unsigned long int total_index_zero_SDp = SDp_set.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0);
				  const unsigned long int total_index_zero_SDn = SDn_set.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0);

				  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
				    {
				      for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
					{
					  const unsigned long int total_index_SDp = total_index_zero_SDp + SDp_index;
					  const unsigned long int total_index_SDn = total_index_zero_SDn + SDn_index;
						      
					  SDp = SDp_set[total_index_SDp];
					  SDn = SDn_set[total_index_SDn];
						  
					  for (int ip = 0 ; ip < ZYval ; ip++)
					    for (int in = 0 ; in < NYval ; in++)
					      {
						const unsigned int p = SDp[ip];
						const unsigned int n = SDn[in];

						if (!has_pair_been_considered(p , n))
						  {
						    const class nljm_struct &phi_p = phi_p_table(p);
						    const class nljm_struct &phi_n = phi_n_table(n);

						    const enum particle_type particle_p = phi_p.get_particle ();	
						    const enum particle_type particle_n = phi_n.get_particle ();
						    
						    pn_pairs_in_tab(pn_pair_index++) = pair_str (particle_p , p , particle_n , n);
								
						    has_pair_been_considered(p , n) = true;
							    
						  }}}}}}}}}}}}
}





void H_class::pairs_in_tab_pp_nn_calc_on_the_fly (class array<class pair_str> &pairs_in_tab) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
     
  const int iM = GSM_vector_helper.get_iM ();
     
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);
  
  const class array<class nljm_struct> &phi_table = data.get_phi_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();
  
  const class array_of_SD &SD_set = data.get_SD_set ();
  
  const unsigned int N_nljm = (n_scat_max > 0) ? (data.get_N_nljm_baryon ()) : (data.get_N_nljm_res_baryon ());

  const int N_valence_baryons = data.get_N_valence_baryons ();

  class Slater_determinant SD(N_valence_baryons);
    
  class array<bool> has_pair_been_considered(N_nljm , N_nljm);
  
  has_pair_been_considered = false;

  unsigned int pair_index = 0;
  
  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int dimension_iC = dimensions_configuration_set(BP , S , 0 , n_scat);
      
      for (unsigned int iC = 0 ; iC < dimension_iC ; iC++)
	{ 
	  const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
	  const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);
	  
	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD_set = dimensions_SD_set(BP , S , 0 , n_scat , iC , iM);

	  if (dimension_SD_set == 0) continue;
	  
	  const unsigned long int total_index_zero_SD = SD_set.index_determine (BP , S , 0 , n_scat , iC , iM , 0);
	  
	  for (unsigned int SD_index = 0 ; SD_index < dimension_SD_set ; SD_index++)
	    {
	      const unsigned long int total_index_SD = total_index_zero_SD + SD_index;
			  
	      SD = SD_set[total_index_SD];

	      for (int i = 0 ; i < N_valence_baryons ; i++)
		for (int ii = 0 ; ii < N_valence_baryons ; ii++)
		  {
		    const unsigned int mu   = SD[i];
		    const unsigned int mu_p = SD[ii];

		    if (mu < mu_p)
		      {
			if (!has_pair_been_considered(mu , mu_p))
			  {
			    const class nljm_struct &phi_mu   = phi_table(mu);
			    const class nljm_struct &phi_mu_p = phi_table(mu_p);

			    const enum particle_type particle_mu   = phi_mu.get_particle ();	
			    const enum particle_type particle_mu_p = phi_mu_p.get_particle ();
						    
			    pairs_in_tab(pair_index++) = pair_str (particle_mu , mu , particle_mu_p , mu_p);
				    
			    has_pair_been_considered(mu , mu_p) = true;
			    
			  }}}}}}
}



















void H_class::pp_pairs_out_tab_pn_calc_on_the_fly (class array<class pair_str> &pp_pairs_out_tab) const
{ 
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
       
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();   
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
   
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_Y_data.get_N_nljm_baryon ()) : (prot_Y_data.get_N_nljm_res_baryon ());
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
        
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  class Slater_determinant SDp(ZYval);
  
  class array<bool> has_pair_been_considered(Np_nljm , Np_nljm);
  
  has_pair_been_considered = false;

  unsigned int pp_pair_index = 0;

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BP , BPp);

      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;

	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p; 

	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
		  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  
		  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
		      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
			{			
			  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

			  if (dimension_SDp == 0) continue;
        
			  const int iMn = iM - iMp;
		  
			  const unsigned long int total_SDp_index_zero = SDp_set.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0);
				  
			  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
			    {
			      bool has_SDp_been_considered = false;
			      
			      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && (!has_SDp_been_considered) ; n_scat_n++)
				{
				  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
				  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  
				  for (unsigned int iCn = iCn_min ; (iCn <= iCn_max) && (!has_SDp_been_considered) ; iCn++)
				    {
				      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
				      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
				 
				      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
				      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

				      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

				      if (dimension_SDn == 0) continue;
				  
				      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

				      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);
				      
				      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;
				      const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDn_minus_one;
				  
				      if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
					{
					  for (unsigned int SDn_index = 0 ; (SDn_index < dimension_SDn) && (!has_SDp_been_considered) ; SDn_index++)
					    {
					      const unsigned long int total_PSI_index = total_PSI_index_zero + SDn_index;
				      					     
					      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
						{
						  const unsigned long int total_index_SDp = total_SDp_index_zero + SDp_index;

						  SDp = SDp_set[total_index_SDp];
					      
						  for (int ip = 0 ; ip < ZYval ; ip++)
						    for (int ipp = 0 ; ipp < ZYval ; ipp++)
						      {
							const unsigned int p  = SDp[ip];
							const unsigned int pp = SDp[ipp];
						    
							if (p < pp)
							  {
							    if (!has_pair_been_considered(p , pp))
							      {
								const class nljm_struct &phi_p  = phi_p_table(p);
								const class nljm_struct &phi_pp = phi_p_table(pp);

								const enum particle_type particle_p  = phi_p.get_particle ();	
								const enum particle_type particle_pp = phi_pp.get_particle ();
						    
								pp_pairs_out_tab(pp_pair_index++) = pair_str (particle_p , p , particle_pp , pp);
								
								has_pair_been_considered(p , pp) = true;
							      }
							  }
						      }
						  
						  has_SDp_been_considered = true;
						  
						}}}}}}}}}}}}
}





void H_class::nn_pairs_out_tab_pn_calc_on_the_fly (class array<class pair_str> &nn_pairs_out_tab) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
      
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();   
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_Y_data.get_N_nljm_baryon ()) : (neut_Y_data.get_N_nljm_res_baryon ());
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
        
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  class Slater_determinant SDn(NYval);
  
  class array<bool> has_pair_been_considered(Nn_nljm , Nn_nljm);
  
  has_pair_been_considered = false;

  unsigned int nn_pair_index = 0;
  
  for (unsigned int BPn = 0 ; BPn <= 1 ; BPn++)
    {
      const unsigned int BPp = binary_parity_product (BPn , BP); 

      for (int Sn = 0 ; Sn <= S ; Sn++)
	{
	  const int Sp = S - Sn;
	  	  
	  for (int n_spec_n = 0 ; n_spec_n <= n_spec_max ; n_spec_n++)
	    {
	      const int n_spec_p = n_spec_max - n_spec_n; 

	      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
		{
		  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  
		  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
		    {
		      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
		      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
		      for (int iMn = iMn_min_M ; iMn <= iMn_max_M ; iMn++)
			{			
			  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

			  if (dimension_SDn == 0) continue;
        
			  const int iMp = iM - iMn;
			  			  
			  const unsigned long int total_SDn_index_zero = SDn_set.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0);

			  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
			    {
			      bool has_SDn_been_considered = false;

			      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && (!has_SDn_been_considered) ; n_scat_p++)
				{
				  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
				  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  
				  for (unsigned int iCp = iCp_min ; (iCp <= iCp_max) && (!has_SDn_been_considered) ; iCp++)
				    {
				      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

				      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
				      
				      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
				      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

				      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

				      if (dimension_SDp == 0) continue;
				  
				      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;
				  
				      const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);
					  
				      const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + SDn_index;
				      const unsigned long int total_PSI_index_dimension_minus_one = total_PSI_index_zero + dimension_SDp_minus_one*dimension_SDn;

				      if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
					{
					  for (unsigned int SDp_index = 0 ; (SDp_index < dimension_SDp) && (!has_SDn_been_considered) ; SDp_index++)
					    {
					      const unsigned long int total_PSI_index = total_PSI_index_zero + SDp_index*dimension_SDn;
						  
					      if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
						{	
						  const unsigned long int total_index_SDn = total_SDn_index_zero + SDn_index;

						  SDn = SDn_set[total_index_SDn];
						      
						  for (int in = 0 ; in < NYval ; in++)
						    for (int inn = 0 ; inn < NYval ; inn++)
						      {
							const unsigned int n  = SDn[in];
							const unsigned int nn = SDn[inn];

							if (n < nn)
							  {
							    if (!has_pair_been_considered(n , nn))
							      {
								const class nljm_struct &phi_n  = phi_n_table(n);
								const class nljm_struct &phi_nn = phi_n_table(nn);

								const enum particle_type particle_n  = phi_n.get_particle ();	
								const enum particle_type particle_nn = phi_nn.get_particle ();
						    
								nn_pairs_out_tab(nn_pair_index++) = pair_str (particle_n , n , particle_nn , nn);
		  								    
								has_pair_been_considered(n , nn) = true;
							      }
							  }
						      }
						  
						  has_SDn_been_considered = true;
						  
						}}}}}}}}}}}}
}





void H_class::pn_pairs_out_tab_pn_calc_on_the_fly (class array<class pair_str> &pn_pairs_out_tab) const
{
  if (!is_pn_non_zero) return;
   
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();   
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
   
  const int iM = GSM_vector_helper.get_iM ();
   
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector (); 
  
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set (); 
    
  const int ZYval = prot_Y_data.get_N_valence_baryons (); 
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_Y_data.get_N_nljm_baryon ()) : (prot_Y_data.get_N_nljm_res_baryon ());
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_Y_data.get_N_nljm_baryon ()) : (neut_Y_data.get_N_nljm_res_baryon ());
  
  const class array<unsigned int> &iCp_min_process_tab = GSM_vector_helper.get_iCp_min_process_tab ();
  const class array<unsigned int> &iCp_max_process_tab = GSM_vector_helper.get_iCp_max_process_tab ();
  
  const class array<unsigned int> &iCn_min_process_tab = GSM_vector_helper.get_iCn_min_process_tab ();
  const class array<unsigned int> &iCn_max_process_tab = GSM_vector_helper.get_iCn_max_process_tab ();
                
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  class Slater_determinant SDp(ZYval);
  class Slater_determinant SDn(NYval);
  
  class array<bool> has_pair_been_considered(Np_nljm , Nn_nljm);
  
  has_pair_been_considered = false;

  unsigned int pn_pair_index = 0;

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BP , BPp);

      for (int Sp = 0 ; Sp <= S ; Sp++)
	{
	  const int Sn = S - Sp;

	  for (int n_spec_p = 0 ; n_spec_p <= n_spec_max ; n_spec_p++)
	    {
	      const int n_spec_n = n_spec_max - n_spec_p; 

	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int iCp_min = iCp_min_process_tab(BPp , Sp , n_spec_p , n_scat_p);
		  const unsigned int iCp_max = iCp_max_process_tab(BPp , Sp , n_spec_p , n_scat_p);
	  
		  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

		      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

		      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
			{
			  const unsigned int iCn_min = iCn_min_process_tab(BPn , Sn , n_spec_n , n_scat_n);
			  const unsigned int iCn_max = iCn_max_process_tab(BPn , Sn , n_spec_n , n_scat_n);
		  
			  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
			    {
			      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
			      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

			      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
				{
				  const int iMn = iM - iMp;
				      
				  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);
				  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

				  if ((dimension_SDn == 0) || (dimension_SDp == 0)) continue;
				      
				  const unsigned long int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);
			      
				  const unsigned long int total_index_zero_SDp = SDp_set.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0);
				  const unsigned long int total_index_zero_SDn = SDn_set.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0);
							  
				  const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;
				  const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;
				      
				  const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed;			      

				  const unsigned long int total_PSI_index_dimension_minus_one = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*dimension_SDp_minus_one + dimension_SDn_minus_one;

				  if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
				    {
				      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
					{
					  const unsigned long int total_PSI_index_zero_SDp_fixed = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;
					  const unsigned long int total_PSI_index_dimension_minus_one_SDp_fixed = total_PSI_index_zero_SDp_fixed + dimension_SDn_minus_one;

					  if ((total_PSI_index_zero_SDp_fixed <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one_SDp_fixed >= first_total_PSI_index))
					    {
					      for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
						{
						  const unsigned long int total_PSI_index = total_PSI_index_zero_SDp_fixed + SDn_index;

						  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
						    {
						      const unsigned long int total_index_SDp = total_index_zero_SDp + SDp_index;
						      const unsigned long int total_index_SDn = total_index_zero_SDn + SDn_index;
						      
						      SDp = SDp_set[total_index_SDp];
						      SDn = SDn_set[total_index_SDn];
					  
						      for (int ip = 0 ; ip < ZYval ; ip++)
							for (int in = 0 ; in < NYval ; in++)
							  {
							    const unsigned int p = SDp[ip];
							    const unsigned int n = SDn[in];

							    if (!has_pair_been_considered(p , n))
							      {
								const class nljm_struct &phi_p = phi_p_table(p);
								const class nljm_struct &phi_n = phi_n_table(n);

								const enum particle_type particle_p = phi_p.get_particle ();	
								const enum particle_type particle_n = phi_n.get_particle ();
						    
								pn_pairs_out_tab(pn_pair_index++) = pair_str (particle_p , p , particle_n , n);
								
								has_pair_been_considered(p , n) = true;
							    
							      }}}}}}}}}}}}}}}
}








void H_class::pairs_out_tab_pp_nn_calc_on_the_fly (class array<class pair_str> &pairs_out_tab) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
      
  const enum space_type space = GSM_vector_helper.get_space ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
      
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
   
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
     
  const int iM = GSM_vector_helper.get_iM (); 

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector (); 
 
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);
  
  const class array<class nljm_struct> &phi_table = data.get_phi_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();
  
  const class array_of_SD &SD_set = data.get_SD_set ();
  
  const unsigned int N_nljm = (n_scat_max > 0) ? (data.get_N_nljm_baryon ()) : (data.get_N_nljm_res_baryon ());

  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  const class array<unsigned int> &iC_min_process_tab = GSM_vector_helper.get_iC_min_process_tab ();
  const class array<unsigned int> &iC_max_process_tab = GSM_vector_helper.get_iC_max_process_tab ();
            
  const unsigned long int first_total_PSI_index = GSM_vector_helper.get_first_total_PSI_index ();
  const unsigned long int last_total_PSI_index = GSM_vector_helper.get_last_total_PSI_index ();
  
  class Slater_determinant SD(N_valence_baryons);
  
  class array<bool> has_pair_been_considered(N_nljm , N_nljm);
  
  has_pair_been_considered = false;

  unsigned int pair_index = 0;

  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int iC_min = iC_min_process_tab(n_scat);
      const unsigned int iC_max = iC_max_process_tab(n_scat);
      
      for (unsigned int iC = iC_min ; iC <= iC_max ; iC++)
	{ 
	  const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
	  const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension_SD_set = dimensions_SD_set(BP , S , 0 , n_scat , iC , iM);

	  if (dimension_SD_set == 0) continue;
	  
	  const unsigned long int total_index_zero_SD = SD_set.index_determine (BP , S , 0 , n_scat , iC , iM , 0);
	      
	  const unsigned long int sum_dimensions_configuration_fixed = sum_dimensions_GSM_vector(n_scat , iC);

	  const unsigned int dimension_SD_set_minus_one = dimension_SD_set - 1;

	  const unsigned long int total_PSI_index_zero = sum_dimensions_configuration_fixed;

	  const unsigned long int total_PSI_index_dimension_minus_one = sum_dimensions_configuration_fixed + dimension_SD_set_minus_one;
	  
	  if ((total_PSI_index_zero <= last_total_PSI_index) && (total_PSI_index_dimension_minus_one >= first_total_PSI_index))
	    {
	      for (unsigned int SD_index = 0 ; SD_index < dimension_SD_set ; SD_index++)
		{
		  const unsigned long int total_PSI_index = total_PSI_index_zero + SD_index;

		  if ((total_PSI_index >= first_total_PSI_index) && (total_PSI_index <= last_total_PSI_index))
		    {
		      const unsigned long int total_index_SD = total_index_zero_SD + SD_index;
			  
		      SD = SD_set[total_index_SD];

		      for (int i = 0 ; i < N_valence_baryons ; i++)
			for (int ii = 0 ; ii < N_valence_baryons ; ii++)
			  {
			    const unsigned int mu   = SD[i];
			    const unsigned int mu_p = SD[ii];

			    if (mu < mu_p)
			      {
				if (!has_pair_been_considered(mu , mu_p))
				  {
				    const class nljm_struct &phi_mu   = phi_table(mu);
				    const class nljm_struct &phi_mu_p = phi_table(mu_p);

				    const enum particle_type particle_mu   = phi_mu.get_particle ();	
				    const enum particle_type particle_mu_p = phi_mu_p.get_particle ();
						    
				    pairs_out_tab(pair_index++) = pair_str (particle_mu , mu , particle_mu_p , mu_p);
					
				    has_pair_been_considered(mu , mu_p) = true;
				    
				  }}}}}}}}
}




void H_class::M_TBMEs_pp_nn_alloc_calc_on_the_fly ()
{  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
       
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const bool is_two_body_part_non_zero = (space == PROT_Y_ONLY) ? (is_pp_non_zero) : (is_nn_non_zero);

  if (!is_two_body_part_non_zero) return;

  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
        
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
     
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const unsigned int N_nljm = (n_scat_max > 0) ? (data.get_N_nljm_baryon ()) : (data.get_N_nljm_res_baryon ());
  
  const class array<class nljm_struct> &phi_table = data.get_phi_table ();
  
  const class TBMEs_class &TBMEs = data.get_TBMEs ();
  
  const unsigned int pairs_in_number  = pairs_in_number_pp_nn_calc_on_the_fly ();
  
  const unsigned int pairs_out_number = pairs_out_number_pp_nn_calc_on_the_fly ();
  
  class array<class pair_str> pairs_in_tab (pairs_in_number);
  
  class array<class pair_str> pairs_out_tab(pairs_out_number);
  
  pairs_in_tab_pp_nn_calc_on_the_fly  (pairs_in_tab);
  
  pairs_out_tab_pp_nn_calc_on_the_fly (pairs_out_tab);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time;
  
      const int strangeness_max_global = TBMEs.get_strangeness_max_global ();
      
      cout << endl << physical_space_determine (space , strangeness_max_global) << " pairs for Hamiltonian uncoupled TBMEs calculated. time:" << relative_time << " s" << endl << endl;
    }
  
  M_TBMEs.allocate (is_there_cout , N_nljm , pairs_in_tab , pairs_out_tab , phi_table , TBMEs);
}







void H_class::M_TBMEs_pn_alloc_calc_on_the_fly ()
{
  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);
    
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const bool is_it_M_TBMEs_storage_full_storage = (M_TBMEs_storage == FULL_STORAGE);
  
  const bool is_it_M_TBMEs_partial_storage = (M_TBMEs_storage == PARTIAL_STORAGE);
  
  const bool is_it_M_TBMEs_pp_partial_storage = (is_it_M_TBMEs_partial_storage && (NYval >= ZYval));      
  const bool is_it_M_TBMEs_nn_partial_storage = (is_it_M_TBMEs_partial_storage && (NYval <  ZYval));
          
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_Y_data.get_N_nljm_baryon ()) : (prot_Y_data.get_N_nljm_res_baryon ());
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_Y_data.get_N_nljm_baryon ()) : (neut_Y_data.get_N_nljm_res_baryon ());
   
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  const class TBMEs_class &TBMEs_pp = prot_Y_data.get_TBMEs ();
  const class TBMEs_class &TBMEs_nn = neut_Y_data.get_TBMEs ();

  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn (); 
  const class TBMEs_class &TBMEs_cv = get_TBMEs_cv (); 

  const bool is_pp_considered = (is_pp_non_zero && (is_it_M_TBMEs_storage_full_storage || is_it_M_TBMEs_pp_partial_storage));
  const bool is_nn_considered = (is_nn_non_zero && (is_it_M_TBMEs_storage_full_storage || is_it_M_TBMEs_nn_partial_storage));
  const bool is_pn_considered =  is_pn_non_zero;
  const bool is_cv_considered =  is_cv_non_zero;
  
  const unsigned int pp_pairs_in_number = (is_pp_considered) ? (pp_pairs_in_number_pn_calc_on_the_fly ()) : (0);
  const unsigned int nn_pairs_in_number = (is_nn_considered) ? (nn_pairs_in_number_pn_calc_on_the_fly ()) : (0);
  const unsigned int pn_pairs_in_number = (is_pn_considered) ? (pn_pairs_in_number_pn_calc_on_the_fly ()) : (0);

  const unsigned int pp_pairs_out_number = (is_pp_considered) ? (pp_pairs_out_number_pn_calc_on_the_fly ()) : (0);
  const unsigned int nn_pairs_out_number = (is_nn_considered) ? (nn_pairs_out_number_pn_calc_on_the_fly ()) : (0);  
  const unsigned int pn_pairs_out_number = (is_pn_considered) ? (pn_pairs_out_number_pn_calc_on_the_fly ()) : (0);
  
  class array<class pair_str> pp_pairs_in_tab(pp_pairs_in_number);
  class array<class pair_str> nn_pairs_in_tab(nn_pairs_in_number);
  class array<class pair_str> pn_pairs_in_tab(pn_pairs_in_number);

  class array<class pair_str> pp_pairs_out_tab(pp_pairs_out_number);
  class array<class pair_str> nn_pairs_out_tab(nn_pairs_out_number);
  class array<class pair_str> pn_pairs_out_tab(pn_pairs_out_number);

  if (is_pp_considered)
    {
      pp_pairs_in_tab_pn_calc_on_the_fly  (pp_pairs_in_tab);
      
      pp_pairs_out_tab_pn_calc_on_the_fly (pp_pairs_out_tab);
    }

  if (is_nn_considered)
    {
      nn_pairs_in_tab_pn_calc_on_the_fly  (nn_pairs_in_tab);
      
      nn_pairs_out_tab_pn_calc_on_the_fly (nn_pairs_out_tab);
    }
  
  if (is_pn_considered)
    {
      pn_pairs_in_tab_pn_calc_on_the_fly  (pn_pairs_in_tab);
      
      pn_pairs_out_tab_pn_calc_on_the_fly (pn_pairs_out_tab);
    }
  

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {      
      const double now = absolute_time_determine () , relative_time = now - reference_time;
      
      cout << endl << "pp, nn and pn pairs for Hamiltonian uncoupled TBMEs calculated (on the fly). time:" << relative_time << " s" << endl << endl;
    }
  
  M_TBMEs.allocate (is_there_cout , Np_nljm , Nn_nljm , is_pp_considered , is_nn_considered , is_pn_considered , is_cv_considered , pp_pairs_in_tab , nn_pairs_in_tab , pn_pairs_in_tab ,
		    pp_pairs_out_tab , nn_pairs_out_tab , pn_pairs_out_tab , phi_p_table , phi_n_table , TBMEs_pp , TBMEs_nn , TBMEs_pn , TBMEs_cv);
}





		
void H_class::M_TBMEs_pn_cv_indices_alloc_calc (const bool is_it_Nval_larger)
{	
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const unsigned int Np_nlj = prot_Y_data.get_N_nlj_baryon ();
  const unsigned int Nn_nlj = neut_Y_data.get_N_nlj_baryon ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_Y_data.get_N_nljm_baryon ()) : (prot_Y_data.get_N_nljm_res_baryon ());
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_Y_data.get_N_nljm_baryon ()) : (neut_Y_data.get_N_nljm_res_baryon ());
  
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  if (is_pn_non_zero)
    {  
      if (is_it_Nval_larger)
	M_TBMEs_pn_indices.allocate (Np_nljm , Nn_nljm , Np_nlj , Nn_nljm);
      else
	M_TBMEs_pn_indices.allocate (Np_nljm , Nn_nljm , Np_nljm , Nn_nlj);
  
      M_TBMEs_pn_indices = INFINITE_INDEX;

      for (unsigned int p_in = 0 ; p_in < Np_nljm ; p_in++)
	for (unsigned int n_in = 0 ; n_in < Nn_nljm ; n_in++)
	  {
	    const class nljm_struct &phi_p_in = phi_p_table(p_in);
	    const class nljm_struct &phi_n_in = phi_n_table(n_in);
	    
	    const enum particle_type particle_p_in = phi_p_in.get_particle ();	
	    const enum particle_type particle_n_in = phi_n_in.get_particle ();
	    
	    const class pair_str pair_in(particle_p_in , p_in , particle_n_in , n_in);

	    const int im_in = pair_in.im_determine (phi_p_table , phi_n_table);
	
	    for (unsigned int p_out = 0 ; p_out < Np_nljm ; p_out++)
	      for (unsigned int n_out = 0 ; n_out < Nn_nljm ; n_out++)
		{
		  const class nljm_struct &phi_p_out = phi_p_table(p_out);
		  const class nljm_struct &phi_n_out = phi_n_table(n_out);
	    
		  const enum particle_type particle_p_out = phi_p_out.get_particle ();	
		  const enum particle_type particle_n_out = phi_n_out.get_particle ();
	    
		  const class pair_str pair_out(particle_p_out , p_out , particle_n_out , n_out);
	    
		  const int im_out = pair_out.im_determine (phi_p_table , phi_n_table);

		  if (im_in == im_out)
		    {  
		      const unsigned int p_out_shell = phi_p_out.get_shell_index ();
		      const unsigned int n_out_shell = phi_n_out.get_shell_index ();
		      
		      if (is_it_Nval_larger)
			M_TBMEs_pn_indices(p_in , n_in , p_out_shell , n_out) = M_TBMEs.index_determine (PROT_NEUT_Y , false , p_in , n_in , p_out , n_out);
		      else
			M_TBMEs_pn_indices(p_in , n_in , p_out , n_out_shell) = M_TBMEs.index_determine (PROT_NEUT_Y , false , p_in , n_in , p_out , n_out);
		    }
		}
	  }
    }
  
  if (is_cv_non_zero)
    {
      if (is_it_Nval_larger)
	{
	  M_TBMEs_cv_pp_to_nn_indices.allocate (Np_nlj  , Np_nljm , Nn_nljm , Nn_nljm);
	  M_TBMEs_cv_nn_to_pp_indices.allocate (Nn_nljm , Nn_nljm , Np_nlj  , Np_nlj );
	}
      else
	{
	  M_TBMEs_cv_pp_to_nn_indices.allocate (Np_nljm , Np_nljm , Nn_nlj  , Nn_nljm);
	  M_TBMEs_cv_nn_to_pp_indices.allocate (Nn_nlj  , Nn_nljm , Np_nljm , Np_nljm);
	}
  
      M_TBMEs_cv_pp_to_nn_indices = INFINITE_INDEX;
      M_TBMEs_cv_nn_to_pp_indices = INFINITE_INDEX;
      
      for (unsigned int p_in = 0 ; p_in < Np_nljm ; p_in++)
	for (unsigned int pp_in = 0 ; pp_in < Np_nljm ; pp_in++)
	  {
	    const class nljm_struct &phi_p_in  = phi_p_table(p_in);
	    const class nljm_struct &phi_pp_in = phi_p_table(pp_in);
	    
	    const enum particle_type particle_p_in  = phi_p_in.get_particle ();	
	    const enum particle_type particle_pp_in = phi_pp_in.get_particle ();
	    
	    const class pair_str pair_in(particle_p_in , p_in , particle_pp_in , pp_in);

	    const int im_in = pair_in.im_determine (phi_p_table , phi_p_table);
			        
	    const unsigned int p_in_shell = phi_p_in.get_shell_index ();
		      
	    for (unsigned int n_out = 0 ; n_out < Nn_nljm ; n_out++)
	      for (unsigned int nn_out = 0 ; nn_out < Nn_nljm ; nn_out++)
		{
		  const class nljm_struct &phi_n_out  = phi_n_table(n_out);
		  const class nljm_struct &phi_nn_out = phi_n_table(nn_out);
	    
		  const enum particle_type particle_n_out  = phi_n_out.get_particle ();	
		  const enum particle_type particle_nn_out = phi_nn_out.get_particle ();
	    
		  const class pair_str pair_out(particle_n_out , n_out , particle_nn_out , nn_out);

		  const int im_out = pair_out.im_determine (phi_n_table , phi_n_table);

		  if (im_in == im_out)
		    {  
		      const unsigned int n_out_shell = phi_n_out.get_shell_index ();
		      
		      if (is_it_Nval_larger)
			M_TBMEs_cv_pp_to_nn_indices(p_in_shell , pp_in , n_out , nn_out) = M_TBMEs.index_determine (PROT_NEUT_UNMIXED_Y , true , p_in , pp_in , n_out , nn_out);
		      else
			M_TBMEs_cv_pp_to_nn_indices(p_in , pp_in , n_out_shell , nn_out) = M_TBMEs.index_determine (PROT_NEUT_UNMIXED_Y , true , p_in , pp_in , n_out , nn_out);
		    }
		}
	  }
      
      for (unsigned int n_in = 0 ; n_in < Nn_nljm ; n_in++)
	for (unsigned int nn_in = 0 ; nn_in < Nn_nljm ; nn_in++)
	  {
	    const class nljm_struct &phi_n_in  = phi_n_table(n_in);
	    const class nljm_struct &phi_nn_in = phi_n_table(nn_in);
	    
	    const enum particle_type particle_n_in  = phi_n_in.get_particle ();	
	    const enum particle_type particle_nn_in = phi_nn_in.get_particle ();
	    
	    const class pair_str pair_in(particle_n_in , n_in , particle_nn_in , nn_in);

	    const int im_in = pair_in.im_determine (phi_n_table , phi_n_table);
			        
	    const unsigned int n_in_shell = phi_n_in.get_shell_index ();
		      
	    for (unsigned int p_out = 0 ; p_out < Np_nljm ; p_out++)
	      for (unsigned int pp_out = 0 ; p_out < Np_nljm ; pp_out++)
		{
		  const class nljm_struct &phi_p_out  = phi_p_table(p_out);
		  const class nljm_struct &phi_pp_out = phi_p_table(pp_out);
	    
		  const enum particle_type particle_p_out  = phi_p_out.get_particle ();	
		  const enum particle_type particle_pp_out = phi_pp_out.get_particle ();
	    
		  const class pair_str pair_out(particle_p_out , p_out , particle_pp_out , pp_out);

		  const int im_out = pair_out.im_determine (phi_p_table , phi_p_table);

		  if (im_in == im_out)
		    {  
		      const unsigned int p_out_shell = phi_p_out.get_shell_index ();
		      
		      if (is_it_Nval_larger)
			M_TBMEs_cv_nn_to_pp_indices(n_in , nn_in , p_out_shell , pp_out) = M_TBMEs.index_determine (PROT_NEUT_UNMIXED_Y , false , n_in , nn_in , p_out , pp_out);
		      else
			M_TBMEs_cv_nn_to_pp_indices(n_in_shell , nn_in , p_out , pp_out) = M_TBMEs.index_determine (PROT_NEUT_UNMIXED_Y , false , n_in , nn_in , p_out , pp_out);
		    }
		}
	  }
    }    
}







