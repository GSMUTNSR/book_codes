#include "../GSM_include/GSM_include_def.h"

using namespace inputs_misc;
using namespace MPI_2D_partitioning;



// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------


// Class xJpm_str is used only in closures and then is not commented.




// Class applying J+ or J- to |Psi[in]> to obtain |Psi[out]>
// ---------------------------------------------------------
// Jpm means J+ or J-, as pm = +/1. One uses Jpm for J+ or J- in all Jpm classes files.
//
// One uses Jpm in J^2 = J-.J+ + Jz.(Jz + 1), and to generate |J M> Hamiltonian eigenstates for all M values starting from an eigenstate with a fixed M value.
//
// One has here constructors, destructors, Hamiltonian operator apply call and operators overloading of operations of the type a.Jpm + b.
//
// Routines here are rather straightforward so that they are not detailed. Only general explanations are given.
//
// The maximal memory occupied in MPI ranks is written on screen after memory allocation.
// The maximal memory is equal to the memory used for a sequential calculation.
//
//
// used_memory_calc
// ----------------
// This routine calculates the memory used by the class in Mb by looping over its data and adding their used memory.
//
// print
// -----
// This routine prints non-zero Jpm NBMEs on screen, This can be used only in a sequential calculation and using the FULL_STORAGE option. It is typically used for tests.
// 
// apply_add
// ---------
// One calculates |Psi[out]> -> |Psi[out]> + Jpm.|Psi[in]>.
// Full storage and on the fly methods can be used.
//
// time_multiplications_data_print
// -------------------------------
// Print of the number of multiplications and time spent with MPI communications in the routine calculating J+/- |Psi[in]>
//
// xJpm_str
// --------
// Operators overloading of operations are of the type a.Jpm, to which operators of the form b.Jpm as well can be added.
// One cannot add another operator to a.Jpm besides b.Jpm, however, as one would have to call different many-body routines for it, which would be too complicated to handle.
// Indeed, the latter is seen as (a + b).Jpm.
// Moreover, as Jpm does not conserve M, one cannot add constant.Id to Jpm.
// One can use instead (a*Jpm)*PSI_0 + J^2*PSI_1 for example, up to 10 terms.
// Products of operators are not accepted with operator overloading.

Jpm_class::Jpm_class () :
  is_there_cout (false) , 
  is_there_cout_detailed (false) , 
  pm (0) ,
  storage (NO_STORAGE) ,
  configuration_SD_one_jump_tables_to_recalculate (false) ,
  GSM_vector_helper_in_ptr (NULL) ,
  GSM_vector_helper_out_ptr (NULL) ,
  PSI_in_full_ptr (NULL) ,
  Jpm_PSI_in_0_ptr (NULL) ,
  Jpm_PSI_in_1_ptr (NULL)
{}





Jpm_class::Jpm_class (
		      const bool is_there_cout_c , 
		      const bool print_detailed_information_c , 
		      const int pm_c ,
		      const enum storage_type storage_c ,
		      const bool configuration_SD_one_jump_tables_to_recalculate_c ,   
		      class GSM_vector_helper_class &GSM_vector_helper_in ,
		      class GSM_vector_helper_class &GSM_vector_helper_out ,
		      class GSM_vector &PSI_in_full ,
		      class GSM_vector &Jpm_PSI_in_0 ,
		      class GSM_vector &Jpm_PSI_in_1) :
  is_there_cout (false) , 
  is_there_cout_detailed (false) , 
  pm (0) ,
  storage (NO_STORAGE) ,
  configuration_SD_one_jump_tables_to_recalculate (false) ,
  GSM_vector_helper_in_ptr (NULL) ,
  GSM_vector_helper_out_ptr (NULL) ,
  PSI_in_full_ptr (NULL) ,
  Jpm_PSI_in_0_ptr (NULL) ,
  Jpm_PSI_in_1_ptr (NULL)
{
  allocate (is_there_cout_c , print_detailed_information_c , pm_c , storage_c , configuration_SD_one_jump_tables_to_recalculate_c ,
	    GSM_vector_helper_in , GSM_vector_helper_out , PSI_in_full , Jpm_PSI_in_0 , Jpm_PSI_in_1);
}






Jpm_class::Jpm_class (const class Jpm_class &X) :
  is_there_cout (false) , 
  is_there_cout_detailed (false) , 
  pm (0) ,
  storage (NO_STORAGE) ,
  configuration_SD_one_jump_tables_to_recalculate (false) ,
  GSM_vector_helper_in_ptr (NULL) ,
  GSM_vector_helper_out_ptr (NULL) ,
  PSI_in_full_ptr (NULL) ,
  Jpm_PSI_in_0_ptr (NULL) ,
  Jpm_PSI_in_1_ptr (NULL)
{
  allocate_fill (X);
}




Jpm_class::~Jpm_class ()
{
  if (PSI_row_non_zero_indices_tables.is_it_filled ())
    {
      const unsigned int N = PSI_row_non_zero_indices_tables.dimension (0);
  
      for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	delete [] PSI_row_non_zero_indices_tables(square_row_index);
    }

  if (PSI_row_indices_non_zero_tables.is_it_filled ())
    {
      const unsigned int N = PSI_row_indices_non_zero_tables.dimension (0);
      
      for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	delete [] PSI_row_indices_non_zero_tables(square_row_index);
    }

  if (squares_non_zero_NBMEs_PSI_column_indices_tables.is_it_filled ())
    {
      const unsigned int N = squares_non_zero_NBMEs_PSI_column_indices_tables.dimension (0);
      
      for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	{
	  class array<unsigned int *> &squares_non_zero_NBMEs_PSI_column_indices_table = squares_non_zero_NBMEs_PSI_column_indices_tables(square_row_index);
	  
	  const unsigned int space_dimension_non_zero = squares_non_zero_NBMEs_PSI_column_indices_table.dimension (0);
	  
	  for (unsigned int PSI_row_non_zero_index = 0 ; PSI_row_non_zero_index < space_dimension_non_zero ; PSI_row_non_zero_index++)
	    delete [] squares_non_zero_NBMEs_PSI_column_indices_table(PSI_row_non_zero_index);
	}
    }
      
  if (squares_non_zero_NBMEs_tables.is_it_filled ())
    {
      const unsigned int N = squares_non_zero_NBMEs_tables.dimension (0);
      
      for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	{
	  class array<double *> &squares_non_zero_NBMEs_table = squares_non_zero_NBMEs_tables(square_row_index);
	  
	  const unsigned int space_dimension_non_zero = squares_non_zero_NBMEs_table.dimension (0);
	  
	  for (unsigned int PSI_row_non_zero_index = 0 ; PSI_row_non_zero_index < space_dimension_non_zero ; PSI_row_non_zero_index++)
	    delete [] squares_non_zero_NBMEs_table(PSI_row_non_zero_index);
	}
    }  
}







void Jpm_class::allocate (
			  const bool is_there_cout_c , 
			  const bool print_detailed_information_c , 
			  const int pm_c ,
			  const enum storage_type storage_c ,
			  const bool configuration_SD_one_jump_tables_to_recalculate_c ,   
			  class GSM_vector_helper_class &GSM_vector_helper_in ,
			  class GSM_vector_helper_class &GSM_vector_helper_out ,
			  class GSM_vector &PSI_in_full ,
			  class GSM_vector &Jpm_PSI_in_0 ,
			  class GSM_vector &Jpm_PSI_in_1)
{
  if (is_it_filled ()) error_message_print_abort ("Jpm_class cannot be allocated twice in Jpm_class::allocate");  

  Jpm_MPI_communication_time = 0.0;

  Jpm_multiplications_number = 0.0;

  if (GSM_vector_helper_in.get_space_dimensions_all_processes_max () == 0) return;
  
  if (GSM_vector_helper_out.get_space_dimensions_all_processes_max () == 0) return;

  const bool is_it_MPI_parallelized_local = GSM_vector_helper_out.get_is_it_MPI_parallelized_local ();
  
  is_there_cout = is_there_cout_c;

  is_there_cout_detailed = (is_there_cout && print_detailed_information_c);

  pm = pm_c;

  storage = storage_c;

  configuration_SD_one_jump_tables_to_recalculate = configuration_SD_one_jump_tables_to_recalculate_c;
  
  GSM_vector_helper_in_ptr  = &GSM_vector_helper_in;
  GSM_vector_helper_out_ptr = &GSM_vector_helper_out;

  GSM_vector_helper_in_full.allocate_fill_without_MPI_parallelization (GSM_vector_helper_in);
  
  PSI_in_full_ptr = &PSI_in_full;
    
  Jpm_PSI_in_0_ptr = &Jpm_PSI_in_0;
  Jpm_PSI_in_1_ptr = &Jpm_PSI_in_1;  
  
  if (is_it_full_or_partial_storage_determine (storage))
    {
      if (Jpm_PSI_in_0.get_space_dimensions_all_processes_max () == 0) return;
      if (Jpm_PSI_in_1.get_space_dimensions_all_processes_max () == 0) return;
    }
  
  const enum space_type space = GSM_vector_helper_out.get_space ();

  const int n_scat_max_p = GSM_vector_helper_out.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper_out.get_n_scat_max_n (); 

  const class nucleons_data &prot_data = GSM_vector_helper_out.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_out.get_neut_data ();

  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_data.get_N_nljm ()) : (prot_data.get_N_nljm_res ());
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_data.get_N_nljm ()) : (neut_data.get_N_nljm_res ());

  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();

  if (space != NEUTRONS_ONLY)
    {
      Jpm_prot_OBMEs_tab.allocate (Np_nljm , Np_nljm);

      Jpm_OBMEs_calc (pm , phi_p_table , Jpm_prot_OBMEs_tab);
    }

  if (space != PROTONS_ONLY)
    {
      Jpm_neut_OBMEs_tab.allocate (Nn_nljm , Nn_nljm);

      Jpm_OBMEs_calc (pm , phi_n_table , Jpm_neut_OBMEs_tab);
    }

  if (is_it_full_or_partial_storage_determine (storage))
    {
      const unsigned int N = (is_it_MPI_parallelized_local) ? (NUMBER_OF_PROCESSES) : (1);

      const class array<unsigned int> &space_dimensions_all_processes_out = GSM_vector_helper_out.get_space_dimensions_all_processes ();
      
      const unsigned int space_dimensions_all_processes_out_max = GSM_vector_helper_out.get_space_dimensions_all_processes_max ();
      
      squares_non_zero_NBMEs_numbers.allocate (N , space_dimensions_all_processes_out_max);

      squares_non_zero_NBMEs_numbers_calc ();
      
      PSI_row_non_zero_indices_tables.allocate (N);

      PSI_row_non_zero_indices_tables = NULL;
      
      PSI_row_indices_non_zero_tables.allocate (N);

      PSI_row_indices_non_zero_tables = NULL;
      
      space_dimensions_non_zero.allocate (N);

      space_dimensions_non_zero = 0;
      
      squares_non_zero_NBMEs_PSI_column_indices_tables.allocate (N);

      squares_non_zero_NBMEs_tables.allocate (N);
            
      for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	{
	  const unsigned int space_dimension_process = space_dimensions_all_processes_out(square_row_index);

	  for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimension_process ; PSI_row_index++)
	    {
	      const unsigned int squares_non_zero_NBMEs_number = squares_non_zero_NBMEs_numbers(square_row_index , PSI_row_index);
   	  
	      if (squares_non_zero_NBMEs_number > 0) space_dimensions_non_zero(square_row_index)++;	      
	    }
	}
            
      for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	{
	  const unsigned int space_dimension_process = space_dimensions_all_processes_out(square_row_index);

	  const unsigned int space_dimension_non_zero = space_dimensions_non_zero(square_row_index);
	  
	  class array<unsigned int *> &squares_non_zero_NBMEs_PSI_column_indices_table = squares_non_zero_NBMEs_PSI_column_indices_tables(square_row_index);

	  class array<double *> &squares_non_zero_NBMEs_table = squares_non_zero_NBMEs_tables(square_row_index);
	  
	  squares_non_zero_NBMEs_PSI_column_indices_table.allocate (space_dimension_non_zero);

	  squares_non_zero_NBMEs_table.allocate (space_dimension_non_zero);

	  squares_non_zero_NBMEs_PSI_column_indices_table = NULL;

	  squares_non_zero_NBMEs_table = NULL;
	  
	  PSI_row_non_zero_indices_tables(square_row_index) = (space_dimension_process > 0) ? (new unsigned int [space_dimension_process]) : (NULL);

	  PSI_row_indices_non_zero_tables(square_row_index) = (space_dimension_non_zero > 0) ? (new unsigned int [space_dimension_non_zero]) : (NULL);
	}
      
      space_dimensions_non_zero = 0;
      
      for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	{
	  const unsigned int space_dimension_process = space_dimensions_all_processes_out(square_row_index);

	  class array<unsigned int *> &squares_non_zero_NBMEs_PSI_column_indices_table = squares_non_zero_NBMEs_PSI_column_indices_tables(square_row_index);
	  
	  class array<double *> &squares_non_zero_NBMEs_table = squares_non_zero_NBMEs_tables(square_row_index);

	  unsigned int *const PSI_row_non_zero_indices = PSI_row_non_zero_indices_tables(square_row_index);

	  unsigned int *const PSI_row_indices_non_zero = PSI_row_indices_non_zero_tables(square_row_index);
	  
	  for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimension_process ; PSI_row_index++)
	    {
	      const unsigned int squares_non_zero_NBMEs_number = squares_non_zero_NBMEs_numbers(square_row_index , PSI_row_index);
		
	      if (squares_non_zero_NBMEs_number > 0)
		{
		  const unsigned int PSI_row_non_zero_index = space_dimensions_non_zero(square_row_index)++;
		  
		  PSI_row_non_zero_indices[PSI_row_index] = PSI_row_non_zero_index;		  

		  PSI_row_indices_non_zero[PSI_row_non_zero_index] = PSI_row_index;
		  		  
		  squares_non_zero_NBMEs_PSI_column_indices_table(PSI_row_non_zero_index) = new unsigned int [squares_non_zero_NBMEs_number];

		  squares_non_zero_NBMEs_table(PSI_row_non_zero_index) = new double [squares_non_zero_NBMEs_number];
		}
	      else
		PSI_row_non_zero_indices[PSI_row_index] = space_dimension_process;
	    }
	}
      
      matrix_store ();
    }

  const double Jpm_used_memory_process = used_memory_calc (*this);

  const double Jpm_used_memory_process_max = max_Reduce<double> (is_it_MPI_parallelized_local , MASTER_PROCESS , THIS_PROCESS , Jpm_used_memory_process);

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_detailed)
    {
      const string pm_string = (pm == 1) ? ("+") : ("-");

      cout << "J" << pm_string <<" memory max used for a process:" << Jpm_used_memory_process_max << " Mb" << endl;
    }
}



void Jpm_class::allocate_fill (const class Jpm_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("Jpm_class cannot be allocated twice in Jpm_class::allocate_fill");

  is_there_cout_detailed = X.is_there_cout_detailed;

  pm = X.pm;

  storage = X.storage;

  configuration_SD_one_jump_tables_to_recalculate = X.configuration_SD_one_jump_tables_to_recalculate;

  GSM_vector_helper_in_ptr  = X.GSM_vector_helper_in_ptr;
  GSM_vector_helper_out_ptr = X.GSM_vector_helper_out_ptr;

  PSI_in_full_ptr = X.PSI_in_full_ptr;
    
  Jpm_PSI_in_0_ptr = X.Jpm_PSI_in_0_ptr;
  Jpm_PSI_in_1_ptr = X.Jpm_PSI_in_1_ptr;

  GSM_vector_helper_in_full.allocate_fill (X.GSM_vector_helper_in_full);
  
  squares_non_zero_NBMEs_numbers.allocate_fill (X.squares_non_zero_NBMEs_numbers);

  space_dimensions_non_zero.allocate_fill (X.space_dimensions_non_zero);
  
  if (X.is_it_filled () && is_it_full_or_partial_storage_determine (storage))
    {     
      const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
      const bool is_it_MPI_parallelized_local = GSM_vector_helper_out.get_is_it_MPI_parallelized_local ();
  
      const unsigned int N = (is_it_MPI_parallelized_local) ? (NUMBER_OF_PROCESSES) : (1);
  
      const class array<unsigned int> &space_dimensions_all_processes_out = GSM_vector_helper_out.get_space_dimensions_all_processes ();

      if (X.PSI_row_non_zero_indices_tables.is_it_filled ())
	{ 	  
	  PSI_row_non_zero_indices_tables.allocate (N);
	  PSI_row_non_zero_indices_tables = NULL;

	  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	    {
	      const unsigned int space_dimension_process = space_dimensions_all_processes_out(square_row_index);

	      const unsigned int *const X_PSI_row_non_zero_indices = X.PSI_row_non_zero_indices_tables(square_row_index);
		  	  
	      PSI_row_non_zero_indices_tables(square_row_index) = (space_dimension_process > 0) ? (new unsigned int [space_dimension_process]) : (NULL);

	      unsigned int *const PSI_row_non_zero_indices = PSI_row_non_zero_indices_tables(square_row_index);
	
	      for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimension_process ; PSI_row_index++)
		PSI_row_non_zero_indices[PSI_row_index] = X_PSI_row_non_zero_indices[PSI_row_index];
	    }
	}
      
      if (X.PSI_row_indices_non_zero_tables.is_it_filled ())
	{ 	  
	  PSI_row_indices_non_zero_tables.allocate (N);
	  PSI_row_indices_non_zero_tables = NULL;

	  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	    {
	      const unsigned int space_dimension_non_zero = space_dimensions_non_zero(square_row_index);

	      const unsigned int *const X_PSI_row_indices_non_zero = X.PSI_row_indices_non_zero_tables(square_row_index);
		  	  
	      PSI_row_indices_non_zero_tables(square_row_index) = (space_dimension_non_zero > 0) ? (new unsigned int [space_dimension_non_zero]) : (NULL);

	      unsigned int *const PSI_row_indices_non_zero = PSI_row_indices_non_zero_tables(square_row_index);
	
	      for (unsigned int PSI_row_index = 0 ; PSI_row_index < space_dimension_non_zero ; PSI_row_index++)
		PSI_row_indices_non_zero[PSI_row_index] = X_PSI_row_indices_non_zero[PSI_row_index];
	    }
	}

      if (PSI_row_indices_non_zero_tables.is_it_filled () && X.squares_non_zero_NBMEs_PSI_column_indices_tables.is_it_filled ())
	{
	  squares_non_zero_NBMEs_PSI_column_indices_tables.allocate (N);
	  
	  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	    {
	      const unsigned int space_dimension_non_zero = space_dimensions_non_zero(square_row_index);
		  
	      const unsigned int *const PSI_row_indices_non_zero = PSI_row_indices_non_zero_tables(square_row_index);
	  
	      const class array<unsigned int *> &X_squares_non_zero_NBMEs_PSI_column_indices_table = X.squares_non_zero_NBMEs_PSI_column_indices_tables(square_row_index);
	  
	      class array<unsigned int *> &squares_non_zero_NBMEs_PSI_column_indices_table = squares_non_zero_NBMEs_PSI_column_indices_tables(square_row_index);
	  
	      squares_non_zero_NBMEs_PSI_column_indices_table.allocate (space_dimension_non_zero);
	  
	      squares_non_zero_NBMEs_PSI_column_indices_table = NULL;
	  	    
	      for (unsigned int PSI_row_non_zero_index = 0 ; PSI_row_non_zero_index < space_dimension_non_zero ; PSI_row_non_zero_index++)
		{
		  const unsigned int PSI_row_index = PSI_row_indices_non_zero[PSI_row_non_zero_index];
		  
		  const unsigned int squares_non_zero_NBMEs_number = squares_non_zero_NBMEs_numbers(square_row_index , PSI_row_index);
			    
		  squares_non_zero_NBMEs_PSI_column_indices_table(PSI_row_non_zero_index) = (squares_non_zero_NBMEs_number > 0) ? (new unsigned int [squares_non_zero_NBMEs_number]) : (NULL);

		  const unsigned int *const X_squares_non_zero_NBMEs_PSI_column_indices = X_squares_non_zero_NBMEs_PSI_column_indices_table(PSI_row_non_zero_index);
		  
		  unsigned int *const squares_non_zero_NBMEs_PSI_column_indices = squares_non_zero_NBMEs_PSI_column_indices_table(PSI_row_non_zero_index);

		  for (unsigned int i = 0 ; i < squares_non_zero_NBMEs_number ; i++)
		    squares_non_zero_NBMEs_PSI_column_indices[i] = X_squares_non_zero_NBMEs_PSI_column_indices[i];
		}
	    }  
	}


      if (PSI_row_indices_non_zero_tables.is_it_filled () && X.squares_non_zero_NBMEs_tables.is_it_filled ())
	{
	  squares_non_zero_NBMEs_tables.allocate (N);
	  
	  for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	    {
	      const unsigned int space_dimension_non_zero = space_dimensions_non_zero(square_row_index);
		  
	      const unsigned int *const PSI_row_indices_non_zero = PSI_row_indices_non_zero_tables(square_row_index);
	      
	      const class array<double *> &X_squares_non_zero_NBMEs_table = X.squares_non_zero_NBMEs_tables(square_row_index);
	  
	      class array<double *> &squares_non_zero_NBMEs_table = squares_non_zero_NBMEs_tables(square_row_index);
	  
	      squares_non_zero_NBMEs_table.allocate (space_dimension_non_zero);
	  
	      squares_non_zero_NBMEs_table = NULL;
	  	    
	      for (unsigned int PSI_row_non_zero_index = 0 ; PSI_row_non_zero_index < space_dimension_non_zero ; PSI_row_non_zero_index++)
		{	      
		  const unsigned int PSI_row_index = PSI_row_indices_non_zero[PSI_row_non_zero_index];
		  
		  const unsigned int squares_non_zero_NBMEs_number = squares_non_zero_NBMEs_numbers(square_row_index , PSI_row_index); 
		  
		  squares_non_zero_NBMEs_table(PSI_row_non_zero_index) = (squares_non_zero_NBMEs_number > 0) ? (new double [squares_non_zero_NBMEs_number]) : (NULL);

		  const double *const X_squares_non_zero_NBMEs = X_squares_non_zero_NBMEs_table(PSI_row_non_zero_index);
		  
		  double *const squares_non_zero_NBMEs = squares_non_zero_NBMEs_table(PSI_row_non_zero_index);

		  for (unsigned int i = 0 ; i < squares_non_zero_NBMEs_number ; i++)
		    squares_non_zero_NBMEs[i] = X_squares_non_zero_NBMEs[i];
		}
	    }  
	}
    }
}








void Jpm_class::deallocate ()
{
  if (PSI_row_non_zero_indices_tables.is_it_filled ())
    {
      const unsigned int N = PSI_row_non_zero_indices_tables.dimension (0);
  
      for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	delete [] PSI_row_non_zero_indices_tables(square_row_index);
    }

  if (PSI_row_indices_non_zero_tables.is_it_filled ())
    {
      const unsigned int N = PSI_row_indices_non_zero_tables.dimension (0);
      
      for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	delete [] PSI_row_indices_non_zero_tables(square_row_index);
    }

  if (squares_non_zero_NBMEs_PSI_column_indices_tables.is_it_filled ())
    {
      const unsigned int N = squares_non_zero_NBMEs_PSI_column_indices_tables.dimension (0);
      
      for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	{
	  class array<unsigned int *> &squares_non_zero_NBMEs_PSI_column_indices_table = squares_non_zero_NBMEs_PSI_column_indices_tables(square_row_index);
	  
	  const unsigned int space_dimension_non_zero = squares_non_zero_NBMEs_PSI_column_indices_table.dimension (0);
	  
	  for (unsigned int PSI_row_non_zero_index = 0 ; PSI_row_non_zero_index < space_dimension_non_zero ; PSI_row_non_zero_index++)
	    delete [] squares_non_zero_NBMEs_PSI_column_indices_table(PSI_row_non_zero_index);
	}
    }
      
  if (squares_non_zero_NBMEs_tables.is_it_filled ())
    {
      const unsigned int N = squares_non_zero_NBMEs_tables.dimension (0);
      
      for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	{
	  class array<double *> &squares_non_zero_NBMEs_table = squares_non_zero_NBMEs_tables(square_row_index);
	  
	  const unsigned int space_dimension_non_zero = squares_non_zero_NBMEs_table.dimension (0);
	  
	  for (unsigned int PSI_row_non_zero_index = 0 ; PSI_row_non_zero_index < space_dimension_non_zero ; PSI_row_non_zero_index++)
	    delete [] squares_non_zero_NBMEs_table(PSI_row_non_zero_index);
	}
    }  
  
  Jpm_prot_OBMEs_tab.deallocate ();
  Jpm_neut_OBMEs_tab.deallocate ();
  
  GSM_vector_helper_in_full.deallocate ();
  
  PSI_row_non_zero_indices_tables.deallocate ();

  PSI_row_indices_non_zero_tables.deallocate ();
	 
  squares_non_zero_NBMEs_numbers.deallocate ();

  space_dimensions_non_zero.deallocate ();
  
  squares_non_zero_NBMEs_PSI_column_indices_tables.deallocate ();

  squares_non_zero_NBMEs_tables.deallocate ();
  
  is_there_cout_detailed = false;

  pm = 0;

  storage = NO_STORAGE;

  configuration_SD_one_jump_tables_to_recalculate = false;

  GSM_vector_helper_in_ptr  = NULL;
  GSM_vector_helper_out_ptr = NULL;
  
  PSI_in_full_ptr = NULL;
  
  Jpm_PSI_in_0_ptr = NULL;
  Jpm_PSI_in_1_ptr = NULL;
}





void Jpm_class::apply_add (
			   const class GSM_vector &PSI_in , 
			   class GSM_vector &PSI_out) const
{
  Jpm_MPI_communication_time = 0.0;

  Jpm_multiplications_number = 0.0;
  
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  if (!PSI_in.same_parity_M_projection (GSM_vector_helper_in)) return;
  if (!PSI_out.same_parity_M_projection (GSM_vector_helper_out)) return;
  
  const unsigned int BP_in  = GSM_vector_helper_in.get_BP ();
  const unsigned int BP_out = GSM_vector_helper_out.get_BP ();

  if (BP_out != BP_in) return;
  
  const int iM_in  = GSM_vector_helper_in.get_iM ();
  const int iM_out = GSM_vector_helper_out.get_iM ();
  
  if (iM_out != iM_in + pm) return;
  
  switch (storage)
    {
    case FULL_STORAGE:    apply_add_full_storage (PSI_in , PSI_out); break;
    case PARTIAL_STORAGE: apply_add_full_storage (PSI_in , PSI_out); break;
     
    case ON_THE_FLY: apply_add_on_the_fly (PSI_in , PSI_out); break; 

    default: abort_all ();
    }
    
  Jpm_multiplications_number /= NUMBER_OF_THREADS;
}





void Jpm_class::print () const
{
  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Only serial processes allowed for the use of print of Jpm_class.");
  
  if (storage != FULL_STORAGE) error_message_print_abort ("Full storage option must be used in print of Jpm_class.");

  class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  const enum space_type space = GSM_vector_helper_out.get_space ();
    
  const unsigned int space_dimension_non_zero = space_dimensions_non_zero(0);
  
  const class nucleons_data &prot_data = GSM_vector_helper_out.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_out.get_neut_data ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();

  const class Slater_determinant dummy_SD(0);
  
  const class GSM_vector V_in(GSM_vector_helper_in);
  const class GSM_vector V_out(GSM_vector_helper_out);

  const class array<unsigned int *> &squares_non_zero_NBMEs_PSI_column_indices_table = squares_non_zero_NBMEs_PSI_column_indices_tables(0);
  
  const class array<double *> &squares_non_zero_NBMEs_table = squares_non_zero_NBMEs_tables(0);
	  
  const unsigned int *const PSI_row_indices_non_zero = PSI_row_indices_non_zero_tables(0);

  class Slater_determinant inSDp(Zval);
  class Slater_determinant inSDn(Nval);
  
  class Slater_determinant outSDp(Zval);
  class Slater_determinant outSDn(Nval);
	    
  for (unsigned int PSI_row_non_zero_index = 0 ; PSI_row_non_zero_index < space_dimension_non_zero ; PSI_row_non_zero_index++)
    {
      const unsigned int PSI_out_index = PSI_row_indices_non_zero[PSI_row_non_zero_index];
	  
      outSDp = (space != NEUTRONS_ONLY) ? (V_out.basis_SD_from_index (PROTONS_ONLY  , PSI_out_index)) : (dummy_SD);
      outSDn = (space != PROTONS_ONLY)  ? (V_out.basis_SD_from_index (NEUTRONS_ONLY , PSI_out_index)) : (dummy_SD);

      const unsigned int square_non_zero_NBMEs_number = squares_non_zero_NBMEs_numbers(0 , PSI_out_index);

      const unsigned int *const squares_non_zero_NBMEs_PSI_column_indices = squares_non_zero_NBMEs_PSI_column_indices_table(PSI_row_non_zero_index);

      const double *const squares_non_zero_NBMEs = squares_non_zero_NBMEs_table(PSI_row_non_zero_index);
        
      for (unsigned int i = 0 ; i < square_non_zero_NBMEs_number ; i++) 
	{
	  const unsigned int PSI_in_index = squares_non_zero_NBMEs_PSI_column_indices[i];

	  const TYPE NBME = squares_non_zero_NBMEs[i];

	  inSDp = (space != NEUTRONS_ONLY) ? (V_in.basis_SD_from_index (PROTONS_ONLY  , PSI_in_index)) : (dummy_SD);
	  inSDn = (space != PROTONS_ONLY)  ? (V_in.basis_SD_from_index (NEUTRONS_ONLY , PSI_in_index)) : (dummy_SD);

	  switch (space)
	    {
	    case PROTONS_ONLY: 
	      {
		cout << "inSD: " , inSDp.print (phi_p_table);
		cout << "outSD: " , outSDp.print (phi_p_table);
	      } break;

	    case NEUTRONS_ONLY:
	      {
		cout << "inSD: " , inSDn.print (phi_n_table);
		cout << "outSD: " , outSDn.print (phi_n_table);
	      } break;

	    case PROTONS_NEUTRONS:
	      {
		cout << "inSDp: " , inSDp.print (phi_p_table);
		cout << "inSDn: " , inSDn.print (phi_n_table);
		
		cout << "outSDp: " , outSDp.print (phi_p_table);
		cout << "outSDn: " , outSDn.print (phi_n_table);
	      } break;

	    default: abort_all ();
	    }

	  cout << "inSD index: " << PSI_in_index << " outSD index: " << PSI_out_index << " NBME: " << NBME << endl << endl;
	}
    }
}






double used_memory_calc (const class Jpm_class &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  double used_memory_allocated_arrays = used_memory_calc (T.Jpm_prot_OBMEs_tab) + used_memory_calc (T.Jpm_neut_OBMEs_tab) + used_memory_calc (T.squares_non_zero_NBMEs_numbers) + used_memory_calc (T.space_dimensions_non_zero) + used_memory_calc (T.PSI_row_non_zero_indices_tables) + used_memory_calc (T.PSI_row_indices_non_zero_tables) + used_memory_calc (T.squares_non_zero_NBMEs_PSI_column_indices_tables) + used_memory_calc (T.squares_non_zero_NBMEs_tables) - (sizeof (T.Jpm_prot_OBMEs_tab) + sizeof (T.Jpm_neut_OBMEs_tab) + sizeof (T.squares_non_zero_NBMEs_numbers) + sizeof (T.space_dimensions_non_zero) + sizeof (T.PSI_row_non_zero_indices_tables) + sizeof (T.PSI_row_indices_non_zero_tables) + sizeof (T.squares_non_zero_NBMEs_PSI_column_indices_tables) + sizeof (T.squares_non_zero_NBMEs_tables))/1000000.0;

  if (T.space_dimensions_non_zero.is_it_filled () && T.squares_non_zero_NBMEs_numbers.is_it_filled ())
    {
      const class GSM_vector_helper_class &GSM_vector_helper_out = T.get_GSM_vector_helper_out ();
      
      const class array<unsigned int> &space_dimensions_all_processes_out = GSM_vector_helper_out.get_space_dimensions_all_processes ();
  
      const bool is_it_MPI_parallelized_local = GSM_vector_helper_out.get_is_it_MPI_parallelized_local ();
      
      const unsigned int N = (is_it_MPI_parallelized_local) ? (NUMBER_OF_PROCESSES) : (1);
      
      const double unsigned_int_memory = sizeof (unsigned int)/1000000.0;
      
      const double unsigned_int_double_memory = (sizeof (unsigned int) + sizeof (double))/1000000.0;
      	      
      for (unsigned int square_row_index = 0 ; square_row_index < N ; square_row_index++)
	{
	  const unsigned int space_dimension_process = space_dimensions_all_processes_out(square_row_index);
      
	  const unsigned int space_dimension_non_zero = T.space_dimensions_non_zero(square_row_index);
	  
	  used_memory_allocated_arrays += (space_dimension_process + space_dimension_non_zero)*unsigned_int_memory;
      
	  for (unsigned int PSI_row_non_zero_index = 0 ; PSI_row_non_zero_index < space_dimension_non_zero ; PSI_row_non_zero_index++)
	    {
	      const unsigned int squares_non_zero_NBMEs_number = T.squares_non_zero_NBMEs_numbers(square_row_index , PSI_row_non_zero_index);
	      
	      used_memory_allocated_arrays += squares_non_zero_NBMEs_number*unsigned_int_double_memory;
	    }
	}
    }
  
  const double used_memory = used_memory_constants + used_memory_allocated_arrays;
  
  return used_memory;
}



void Jpm_class::time_multiplications_data_print () const
{
  const string Jpm_str = (pm == 1) ? ("J+") : ("J-");
  
  if (Jpm_multiplications_number != 0.0) cout << Jpm_str << " average multiplications number per thread:" << Jpm_multiplications_number << endl;
      
  if (Jpm_MPI_communication_time != 0.0) cout << Jpm_str << " MPI communication time:" << Jpm_MPI_communication_time << " s" << endl;
}



xJpm_str::xJpm_str (const TYPE &x_c , const class Jpm_class &Jpm_c) : x (x_c) , Jpm (Jpm_c) {}

class xJpm_str operator + (const class Jpm_class &Jpm)
{
  return xJpm_str (1.0 , Jpm);
}

class xJpm_str operator - (const class Jpm_class &Jpm)
{
  return xJpm_str (-1.0 , Jpm);
}

class xJpm_str operator * (const class Jpm_class &Jpm , const double x)
{
  return xJpm_str (x , Jpm);
}

class xJpm_str operator * (const double x , const class Jpm_class &Jpm)
{
  return xJpm_str (x , Jpm);
}

class xJpm_str operator / (const class Jpm_class &Jpm , const double x)
{
  const double one_over_x = 1.0/x;

  return xJpm_str (one_over_x , Jpm);
}

class xJpm_str operator + (const class xJpm_str &xJpm)
{
  return xJpm_str (xJpm.x , xJpm.Jpm);
}

class xJpm_str operator - (const class xJpm_str &xJpm)
{
  return xJpm_str (-xJpm.x , xJpm.Jpm);
}

class xJpm_str operator * (const class xJpm_str &Op , const double factor)
{
  return xJpm_str (Op.x*factor , Op.Jpm);
}

class xJpm_str operator / (const class xJpm_str &Op , const double factor)
{
  return xJpm_str (Op.x/factor , Op.Jpm);
}

class xJpm_str operator * (const double factor , const class xJpm_str &Op)
{
  return xJpm_str (factor*Op.x , Op.Jpm);
}

#ifdef TYPEisDOUBLECOMPLEX

class xJpm_str operator * (const class Jpm_class &Jpm , const complex<double> &x)
{
  return xJpm_str (x , Jpm);
}

class xJpm_str operator * (const complex<double> &x , const class Jpm_class &Jpm)
{
  return xJpm_str (x , Jpm);
}

class xJpm_str operator / (const class Jpm_class &Jpm , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return xJpm_str (one_over_x , Jpm);
}

class xJpm_str operator * (const class xJpm_str &Op , const complex<double> &factor)
{
  return xJpm_str (Op.x*factor , Op.Jpm);
}

class xJpm_str operator / (const class xJpm_str &Op , const complex<double> &factor)
{
  return xJpm_str (Op.x/factor , Op.Jpm);
}

class xJpm_str operator * (const complex<double> &factor , const class xJpm_str &Op)
{
  return xJpm_str (factor*Op.x , Op.Jpm);
}

#endif

class xJpm_str operator + (const class xJpm_str &Op_a , const class xJpm_str &Op_b)
{
  if (&(Op_a.Jpm) != &(Op_b.Jpm)) error_message_print_abort ("Jpm must be the same in both Op_a and Op_b in class xJpm_str operator +");

  return xJpm_str (Op_a.x + Op_b.x , Op_a.Jpm);
}

class xJpm_str operator - (const class xJpm_str &Op_a , const class xJpm_str &Op_b)
{	
  if (&(Op_a.Jpm) != &(Op_b.Jpm)) error_message_print_abort ("Jpm must be the same in both Op_a and Op_b in class xJpm_str operator -");

  return xJpm_str (Op_a.x - Op_b.x , Op_a.Jpm);
}


