#include "../GSM_include/GSM_include_def.h"

using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;


// TYPE is double or complex
// -------------------------


// OBMEs means one-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------



// Class applying J+ or J- to |Psi[in]> to obtain |Psi[out]> when only one configuration is occupied in basis space for MSDHF calculations
// ---------------------------------------------------------------------------------------------------------------------------------------
// In order to calculate the MSDHF potential, one has to diagonalize H on the MSDHF configuration, as its ground state is used in the HF-like formulas defining the MSDHF potential.
// The J^2 operator when only one configuration is occupied is also used, to check if GSM vectors are coupled to J and to project them on good J.
// As only one configuration occurs, it is much more efficient to recode J^2 in this particular case, than to use the full J^2 class of the general case.
//
// Jpm means J+ or J-, as pm = +/1. One uses Jpm for J+ or J- in all Jpm classes files.
// One uses Jpm in J^2 = J-.J+ + Jz.(Jz + 1).
//
// One has here constructors, destructors, Hamiltonian operator apply call and operators overloading of operations of the type a.Jpm + b.
//
// Routines here are rather straightforward so that they are not detailed. Only general explanations are given.
//
// The maximal memory occupied in MPI ranks is written on screen after memory allocation.
// The maximal memory is equal to the memory used for a sequential calculation.
//
//
// used_memory_calc
// ----------------
// This routine calculates the memory used by the class in Mb by looping over its data and adding their used memory.
//
// print
// -----
// This routine prints non-zero Jpm NBMEs on screen, This can be used only in a sequential calculation and using the FULL_STORAGE option. It is typically used for tests.
// 
// apply_add
// ---------
// One calculates |Psi[out]> -> |Psi[out]> + Jpm.|Psi[in]>.
// If MPI parallelization is used and |Psi[out]> != 0, |Psi[out]> is firstly transfered to all nodes, as only the master process has a copy of it, and divided by the number of nodes.
// Consequently, the |Psi[out]> parts in all nodes can be summed up in the end to obtain |Psi[out]> -> |Psi[out]> + Jpm.|Psi[in]>
// 
// Full storage and on the fly methods can be used.
//
//
// xJpm_str
// --------
// Operators overloading of operations are of the type a.Jpm, to which operators of the form b.Jpm as well can be added.
// One cannot add another operator to a.Jpm besides b.Jpm, however, as one would have to call different many-body routines for it, which would be too complicated to handle.
// Indeed, the latter is seen as (a + b).Jpm.
// Moreover, as Jpm does not conserve M, one cannot add constant.Id to Jpm.
// One can use instead (a*Jpm)*PSI_0 + J^2*PSI_1 for example, up to 10 terms.
// Products of operators are not accepted with operator overloading.


Jpm_one_configuration_class::Jpm_one_configuration_class () :
  pm (0) , 
  GSM_vector_helper_in_ptr (NULL) ,
  GSM_vector_helper_out_ptr (NULL)
{}
  
Jpm_one_configuration_class::Jpm_one_configuration_class (
							  const int pm_c , 
							  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in , 
							  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_out) :
  pm (0) , 
  GSM_vector_helper_in_ptr (NULL) ,
  GSM_vector_helper_out_ptr (NULL)
{
  allocate (pm_c , GSM_vector_helper_in , GSM_vector_helper_out);
}

Jpm_one_configuration_class::Jpm_one_configuration_class (const class Jpm_one_configuration_class &X) :
  pm (0) , 
  GSM_vector_helper_in_ptr (NULL) ,
  GSM_vector_helper_out_ptr (NULL)
{
  allocate_fill (X);
}

Jpm_one_configuration_class::~Jpm_one_configuration_class () {}


void Jpm_one_configuration_class::allocate (
					    const int pm_c , 
					    const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in , 
					    const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_out)
{
  pm = pm_c;
  
  GSM_vector_helper_in_ptr = &GSM_vector_helper_in;
  GSM_vector_helper_out_ptr = &GSM_vector_helper_out;
  
  const unsigned int space_dimension_out = GSM_vector_helper_out.get_space_dimension ();

  const enum space_type space = GSM_vector_helper_out.get_space ();
 
  const class nucleons_data &prot_data = GSM_vector_helper_out.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_out.get_neut_data ();
  
  const unsigned int Np_nljm = prot_data.get_N_nljm ();
  const unsigned int Nn_nljm = neut_data.get_N_nljm ();
  
  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();

  if (space != NEUTRONS_ONLY)
    {
      Jpm_prot_OBMEs_tab.allocate (Np_nljm , Np_nljm);

      Jpm_OBMEs_calc (pm , phi_p_table , Jpm_prot_OBMEs_tab);
    }

  if (space != PROTONS_ONLY)
    {
      Jpm_neut_OBMEs_tab.allocate (Nn_nljm , Nn_nljm);

      Jpm_OBMEs_calc (pm , phi_n_table , Jpm_neut_OBMEs_tab);
    }

  rows_non_zero_NBMEs_numbers.allocate (space_dimension_out);

  rows_non_zero_NBMEs_numbers_calc ();
  
  const unsigned int rows_non_zero_NBMEs_number_max = rows_non_zero_NBMEs_numbers.max ();
      
  rows_non_zero_NBMEs_PSI_in_indices.allocate (space_dimension_out , rows_non_zero_NBMEs_number_max);

  rows_non_zero_NBMEs.allocate (space_dimension_out , rows_non_zero_NBMEs_number_max);

  matrix_store ();
}




void Jpm_one_configuration_class::allocate_fill (const class Jpm_one_configuration_class &X)
{
  pm = X.pm;
  
  GSM_vector_helper_in_ptr  = X.GSM_vector_helper_in_ptr; 
  GSM_vector_helper_out_ptr = X.GSM_vector_helper_out_ptr;
   
  Jpm_prot_OBMEs_tab.allocate_fill (X.Jpm_prot_OBMEs_tab);
  Jpm_neut_OBMEs_tab.allocate_fill (X.Jpm_neut_OBMEs_tab);
  
  rows_non_zero_NBMEs_numbers.allocate_fill (X.rows_non_zero_NBMEs_numbers);
  
  rows_non_zero_NBMEs_PSI_in_indices.allocate_fill (X.rows_non_zero_NBMEs_PSI_in_indices);

  rows_non_zero_NBMEs.allocate_fill (X.rows_non_zero_NBMEs);
}


void Jpm_one_configuration_class::deallocate ()
{
  Jpm_prot_OBMEs_tab.deallocate ();
  Jpm_neut_OBMEs_tab.deallocate ();

  rows_non_zero_NBMEs_numbers.deallocate ();

  rows_non_zero_NBMEs_PSI_in_indices.deallocate ();

  rows_non_zero_NBMEs.deallocate ();
    
  GSM_vector_helper_in_ptr  = NULL;
  GSM_vector_helper_out_ptr = NULL;
  
  pm = 0;
}



bool Jpm_one_configuration_class::is_it_filled () const
{
  return (pm != 0);
}


void Jpm_one_configuration_class::print () const
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
     
  const enum space_type space = GSM_vector_helper_out.get_space ();
  
  const unsigned int space_dimension_out = GSM_vector_helper_out.get_space_dimension ();
  
  const class nucleons_data &prot_data = GSM_vector_helper_out.get_prot_data ();
  const class nucleons_data &neut_data = GSM_vector_helper_out.get_neut_data ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
      
  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();

  const class Slater_determinant dummy_SD;

  const class GSM_vector_one_configuration V_in(GSM_vector_helper_in);
  const class GSM_vector_one_configuration V_out(GSM_vector_helper_out);

  class Slater_determinant inSDp(Zval);
  class Slater_determinant inSDn(Nval);
  
  class Slater_determinant outSDp(Zval);
  class Slater_determinant outSDn(Nval);
  
  for (unsigned int PSI_out_index = 0 ; PSI_out_index < space_dimension_out ; PSI_out_index++)
    {
      outSDp = (space != NEUTRONS_ONLY) ? (V_out.basis_SD_from_index (PROTONS_ONLY  , PSI_out_index)) : (dummy_SD);
      outSDn = (space != PROTONS_ONLY)  ? (V_out.basis_SD_from_index (NEUTRONS_ONLY , PSI_out_index)) : (dummy_SD);

      const unsigned int row_non_zero_NBMEs_number = rows_non_zero_NBMEs_numbers(PSI_out_index);
      
      switch (space)
	{
	case PROTONS_ONLY: 
	  {
	    cout << "inSD: "  , outSDp.print (phi_p_table);
	    cout << "outSD: " , outSDp.print (phi_p_table);
	  } break;

	case NEUTRONS_ONLY:
	  {
	    cout << "inSD: "  , outSDn.print (phi_n_table);
	    cout << "outSD: " , outSDn.print (phi_n_table);
	  } break;

	case PROTONS_NEUTRONS:
	  {
	    cout << "inSDp: "  , outSDp.print (phi_p_table);
	    cout << "inSDn: "  , outSDn.print (phi_n_table);
	    
	    cout << "outSDp: " , outSDp.print (phi_p_table);
	    cout << "outSDn: " , outSDn.print (phi_n_table);
	  } break;

	default: abort_all ();
	}

      for (unsigned int i = 0 ; i < row_non_zero_NBMEs_number ; i++) 
	{
	  const unsigned int PSI_in_index = rows_non_zero_NBMEs_PSI_in_indices(PSI_out_index , i);
	  
	  if (PSI_out_index < PSI_in_index)
	    {
	      const double NBME = rows_non_zero_NBMEs(PSI_out_index , i);	

	      inSDp = (space != NEUTRONS_ONLY) ? (V_in.basis_SD_from_index (PROTONS_ONLY  , PSI_in_index)) : (dummy_SD);
	      inSDn = (space != PROTONS_ONLY)  ? (V_in.basis_SD_from_index (NEUTRONS_ONLY , PSI_in_index)) : (dummy_SD);

	      switch (space)
		{
		case PROTONS_ONLY: 
		  {
		    cout << "inSD: "  , inSDp.print (phi_p_table);
		    
		    cout << "outSD: " , outSDp.print (phi_p_table);
		  } break;

		case NEUTRONS_ONLY:
		  {
		    cout << "inSD: "  , inSDn.print (phi_n_table);
		    
		    cout << "outSD: " , outSDn.print (phi_n_table);
		  } break;

		case PROTONS_NEUTRONS:
		  {
		    cout << "inSDp: "  , inSDp.print (phi_p_table);
		    cout << "inSDn: "  , inSDn.print (phi_n_table);

		    cout << "outSDp: " , outSDp.print (phi_p_table);
		    cout << "outSDn: " , outSDn.print (phi_n_table);
		  } break;

		default: abort_all ();
		}

	      cout << "inSD index: " << PSI_in_index << " outSD index: " << PSI_out_index << " NBME: " << NBME << endl << endl;
	    }
	}      
    }
}



xJpm_one_configuration_str::xJpm_one_configuration_str (const TYPE &x_c , const class Jpm_one_configuration_class &Jpm_c) : x (x_c) , Jpm (Jpm_c) {}

class xJpm_one_configuration_str operator + (const class Jpm_one_configuration_class &Jpm)
{
  return xJpm_one_configuration_str (1.0 , Jpm);
}

class xJpm_one_configuration_str operator - (const class Jpm_one_configuration_class &Jpm)
{
  return xJpm_one_configuration_str (-1.0 , Jpm);
}

class xJpm_one_configuration_str operator * (const class Jpm_one_configuration_class &Jpm , const double x)
{
  return xJpm_one_configuration_str (x , Jpm);
}

class xJpm_one_configuration_str operator * (const double x , const class Jpm_one_configuration_class &Jpm)
{
  return xJpm_one_configuration_str (x , Jpm);
}

class xJpm_one_configuration_str operator / (const class Jpm_one_configuration_class &Jpm , const double x)
{
  const double one_over_x = 1.0/x;

  return xJpm_one_configuration_str (one_over_x , Jpm);
}

class xJpm_one_configuration_str operator + (const class xJpm_one_configuration_str &xJpm)
{
  return xJpm_one_configuration_str (xJpm.x , xJpm.Jpm);
}

class xJpm_one_configuration_str operator - (const class xJpm_one_configuration_str &xJpm)
{
  return xJpm_one_configuration_str (-xJpm.x , xJpm.Jpm);
}

class xJpm_one_configuration_str operator * (const class xJpm_one_configuration_str &Op , const double factor)
{
  return xJpm_one_configuration_str (Op.x*factor , Op.Jpm);
}

class xJpm_one_configuration_str operator / (const class xJpm_one_configuration_str &Op , const double factor)
{
  return xJpm_one_configuration_str (Op.x/factor , Op.Jpm);
}

class xJpm_one_configuration_str operator * (const double factor , const class xJpm_one_configuration_str &Op)
{
  return xJpm_one_configuration_str (factor*Op.x , Op.Jpm);
}

#ifdef TYPEisDOUBLECOMPLEX

class xJpm_one_configuration_str operator * (const class Jpm_one_configuration_class &Jpm , const complex<double> &x)
{
  return xJpm_one_configuration_str (x , Jpm);
}

class xJpm_one_configuration_str operator * (const complex<double> &x , const class Jpm_one_configuration_class &Jpm)
{
  return xJpm_one_configuration_str (x , Jpm);
}

class xJpm_one_configuration_str operator / (const class Jpm_one_configuration_class &Jpm , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return xJpm_one_configuration_str (one_over_x , Jpm);
}

class xJpm_one_configuration_str operator * (const class xJpm_one_configuration_str &Op , const complex<double> &factor)
{
  return xJpm_one_configuration_str (Op.x*factor , Op.Jpm);
}

class xJpm_one_configuration_str operator / (const class xJpm_one_configuration_str &Op , const complex<double> &factor)
{
  return xJpm_one_configuration_str (Op.x/factor , Op.Jpm);
}

class xJpm_one_configuration_str operator * (const complex<double> &factor , const class xJpm_one_configuration_str &Op)
{
  return xJpm_one_configuration_str (factor*Op.x , Op.Jpm);
}

#endif

class xJpm_one_configuration_str operator + (const class xJpm_one_configuration_str &Op_a , const class xJpm_one_configuration_str &Op_b)
{
  if (&(Op_a.Jpm) != &(Op_b.Jpm)) error_message_print_abort ("Jpm_one_configuration must be the same in both Op_a and Op_b in class xJpm_one_configuration_str operator +");

  return xJpm_one_configuration_str (Op_a.x + Op_b.x , Op_a.Jpm);
}

class xJpm_one_configuration_str operator - (const class xJpm_one_configuration_str &Op_a , const class xJpm_one_configuration_str &Op_b)
{	
  if (&(Op_a.Jpm) != &(Op_b.Jpm)) error_message_print_abort ("Jpm_one_configuration must be the same in both Op_a and Op_b in class xJpm_one_configuration_str operator -");

  return xJpm_one_configuration_str (Op_a.x - Op_b.x , Op_a.Jpm);
}


double used_memory_calc (const class Jpm_one_configuration_class &T)
{
  return ((sizeof (int) + 2*sizeof (void *))/1000000.0 + used_memory_calc (T.Jpm_prot_OBMEs_tab) + used_memory_calc (T.Jpm_neut_OBMEs_tab) + used_memory_calc (T.rows_non_zero_NBMEs_numbers) + used_memory_calc (T.rows_non_zero_NBMEs_PSI_in_indices) + used_memory_calc (T.rows_non_zero_NBMEs));
}
