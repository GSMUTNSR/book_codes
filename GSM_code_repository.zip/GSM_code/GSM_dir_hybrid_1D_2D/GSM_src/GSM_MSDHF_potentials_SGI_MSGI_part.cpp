#include "../GSM_include/GSM_include_def.h"

using namespace HF_potentials_common::SGI_MSGI_part_common;





// TYPE is double or complex
// -------------------------


// Calculation of the direct and exchange parts of the MSDHF potential
// -------------------------------------------------------------------
// One has:
// <wf_out | U[MSDHF] | wf_in> = <wf_out | U[core] | wf_in>
// -  (\sum_{occ J'} hat(J') <wf_out occ | V | wf_in occ>_{J'} <Psi[GS] | [[a+_{n l j} a+_{occ}]^{J'} [a~_{k l j} a~_{occ} ]^{J'}]^0_0 | Psi[k]>)
//  / (<Psi[GS] | [a+_{n l j} a~_{k l j}]^0_0 | Psi[k]>)
//
// The one-body part issued from the core, i.e. <wf_out | U[core] | wf_in>, is not considered here.
// The normalizing factor <Psi[GS] | [a+_{n l j} a~_{k l j}]^0_0 | Psi[k]> has already been calculated (see U_HF_normalizing_sums_calc).
// As <wf_out | U[MSDHF] | wf_in> matrices are symmetric, one considers firstly wf_out <= wf_in, and the rest of the matrix is filled by symmetry at the end of the calculation.
// As <Psi[GS] | [[a+_{occ} a+_{n l j}]^{J'} [a~_{occ} a~_{k l j}]^{J'}]^0_0 | Psi[k]> is independent of wf_out and wf_in, it is calculated only once for all wf_out and wf_in.
//
//
// Firstly, one writes -hat(J') <Psi[GS] | [[a+_{n l j} a+_{occ}]^{J'} [a~_{k l j} a~_{occ} ]^{J'}]^0_0 | Psi[k]>
// \propto \sum_{m's}   <j m j[occ] m[occ] | J' M> <j m' j[occ] m[occ]' | J' M> (-1)^(j + j[occ] - J)
//                    x <Psi[GS] | a+_{n l j m} a+_{occ m[occ]} a_{occ m[occ]'} a_{k l j m'} | Psi[k]> (see GSM_MSDHF_potentials.cpp)
//
// As |Psi[k]> = [a+_{k l j} a~_{n l j}]^0_0 |Psi[GS]>, |Psi[GS]> \propto \sum_{m} a+_{k l j m} a_{n l j m} | Psi[GS]> => a_{k l j m} |Psi[k]> \propto a_{n l j m} | Psi[GS]>.
// |Psi[GS]> and a_{k l j m} |Psi[k]> have been expanded with Slater determinants.
// |Psi[GS]> = \sum_{i} c[i] |SDi[GS]> and a_{k l j m} |Psi[k]> = \sum_{j} d[j] |SDj[k]>, where the |k l j m> state is not present in |SDj[k]>, and d[j] depends on m.
//
// Thus:
// \sum_{m's}   <j m j[occ] m[occ] | J' M> <j m' j[occ] m[occ]' | J' M> (-1)^(j + j[occ] - J)
//            x <Psi[GS] | a+_{n l j m} a+_{occ m[occ]}  a_{occ m[occ]'} a_{k l j m'} | Psi[k]>
// = \sum_{ij, m's}    c[i] d[j] <j m j[occ] m[occ] | J' M> <j m' j[occ] m[occ]' | J' M> (-1)^(j + j[occ] - J)
//                  x <SDi[GS] | a+_{n l j m} a+_{occ m[occ]} a_{occ m[occ]'} | SDj[k]>
//
// where a_{k l j m'} | Psi[k]> has been expanded in terms of |SDj[k]> basis states, and d[j] depends on m'.
//
//
// Thus:
//
// The equivalent MSDHF potential U_MSDHF = U_MSDHF(direct) - U_MSDHF(exchange) writes, for MSGI, along with its source:
//
// U_MSDHF(dir)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . F_Gaussian(r) . \int u_occ^2(r') F_Gaussian(r') dr'
// U_MSDHF(exc)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' . F(r)
//
// The equivalent MSDHF potential U_MSDHF = U_MSDHF(direct) - U_MSDHF(exchange) writes, for SGI, along with its source:
//
// U_MSDHF(dir)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . Vl'_SGI(r , 2R0-r) . u_occ^2(2R0-r)
// U_MSDHF(exc)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ, l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) . F(r)
//
// where weight is function of Clebsch-Gordan coefficients and of the SD components of the GSM ground state on the optimized configuration,
// obtained from the decoupling of tensor operators in the MSDHF potential (see above).
// coupling_constant(Pi,J) is the Pi-J-dependent coupling constant of the SGI/MSGI interaction, 
// F_Gaussian(r) is the Gaussian form factor entering the MSGI interaction (see GSM_TBME_MSGI.cpp) and
// Vl'_SGI(r) is the multipolar expansion of the SGI interaction (see GSM_interaction_class.cpp) and R0 is the radius of the SGI/MSGI interaction.
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
// Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
// The ratio |u(r)|^2/|u'(r)|^2) prevents F(r) to be non zero when r -> +oo.
// Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// This routine loops over all proton and neutron states and occupied states and calls routines of the namespaces SGI_part_common and MSGI_part_common.


void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potential_pp_part_calc (
											const bool is_it_res , 
											const bool is_it_pm , 
											const int pm , 
											const class CG_str &CGs , 
											const class array<double> &Gaussian_table_GL , 
											const class multipolar_expansion_str &multipolar_expansion , 
											const class interaction_class &inter_data_basis , 
											const class SGI_radial_tabs_str &prot_radial_tabs , 
											const class nucleons_data &prot_data_one_configuration_GSM , 
											const class spherical_state &shell_prot_HF , 
											class HF_nucleons_data &prot_HF_data)
{
  const int Zval = prot_data_one_configuration_GSM.get_N_valence_nucleons_basis ();

  const int Zval_m1 = Zval - 1;
  
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_prot = prot_data_one_configuration_GSM.get_shells ();

  const class array<class nljm_struct> &phi_p_table = prot_data_one_configuration_GSM.get_phi_table ();

  const class lj_table<unsigned int> &dimensions_GS = prot_HF_data.get_dimensions_GS ();

  const class lj_table<complex<double> > &Up_HF_normalizing_sums = prot_HF_data.get_U_HF_normalizing_sums ();

  const class lj_table<class array<class Slater_determinant> > &prot_SDs_GS = prot_HF_data.get_prot_SDs_GS ();
  const class lj_table<class array<class Slater_determinant> > &neut_SDs_GS = prot_HF_data.get_neut_SDs_GS ();
  const class lj_table<class array<class Slater_determinant> > &prot_SDs_1h = prot_HF_data.get_SDs_1h ();

  const class lj_table<class array<complex<double> > > &SDs_GS_coefficients = prot_HF_data.get_SDs_GS_coefficients ();
  const class lj_table<class array<complex<double> > > &SDs_1h_coefficients = prot_HF_data.get_SDs_1h_coefficients ();

  const class lj_table<class array<bool> > &prot_SDs_1h_existence_table = prot_HF_data.get_SDs_1h_existence_table ();

  const double jp = shell_prot_HF.get_j ();

  const int lp = shell_prot_HF.get_l ();

  const int imp_number = make_int (2.0*jp + 1.0);

  const unsigned int dimension_GS = dimensions_GS(lp , jp);

  const complex<double> Up_HF_normalizing_sum = Up_HF_normalizing_sums(lp , jp);

  const class array<class Slater_determinant> &prot_SDs_GS_lj = prot_SDs_GS(lp , jp);
  const class array<class Slater_determinant> &neut_SDs_GS_lj = neut_SDs_GS(lp , jp);
  const class array<class Slater_determinant> &prot_SDs_1h_lj = prot_SDs_1h(lp , jp);

  const class array<complex<double> > &SDs_GS_coefficients_lj = SDs_GS_coefficients(lp , jp);
  const class array<complex<double> > &SDs_1h_coefficients_lj = SDs_1h_coefficients(lp , jp);

  const class array<bool> &prot_SDs_1h_existence_table_lj = prot_SDs_1h_existence_table(lp , jp);

  unsigned int prot_jump_states_number_GS_in  = 0;
  unsigned int prot_jump_states_number_1h_out = 0;

  class array<unsigned int> prot_jump_states_GS_in(Zval);
  class array<unsigned int> prot_jump_states_1h_out(Zval_m1); 

  for (unsigned int i_GS_in = 0 ; i_GS_in < dimension_GS ; i_GS_in++)
    {
      const complex<double> SD_GS_coefficient_in = SDs_GS_coefficients_lj(i_GS_in);
      
      if (SD_GS_coefficient_in == 0.0) continue;

      const class Slater_determinant &prot_SD_lj_GS_in = prot_SDs_GS_lj(i_GS_in);
      const class Slater_determinant &neut_SD_lj_GS_in = neut_SDs_GS_lj(i_GS_in);

      for (unsigned int i_GS_out = 0 ; i_GS_out < dimension_GS ; i_GS_out++)
	{
	  const class Slater_determinant &neut_SD_lj_GS_out = neut_SDs_GS_lj(i_GS_out);

	  if (neut_SD_lj_GS_in == neut_SD_lj_GS_out)
	    {
	      for (int imp_out = 0 ; imp_out < imp_number ; imp_out++)
		{
		  const bool prot_SD_lj_1h_out_exists = prot_SDs_1h_existence_table_lj(i_GS_out , imp_out);

		  if (!prot_SD_lj_1h_out_exists) continue;

		  const complex<double> SD_GS_coefficient_in  = SDs_GS_coefficients_lj(i_GS_in);
		  const complex<double> SD_1h_coefficient_out = SDs_1h_coefficients_lj(i_GS_out , imp_out);

		  if ((SD_GS_coefficient_in == 0.0) || (SD_1h_coefficient_out == 0.0)) continue;

		  const class Slater_determinant &prot_SD_lj_1h_out = prot_SDs_1h_lj(i_GS_out , imp_out);

		  prot_SD_lj_GS_in.different_states_determine (prot_SD_lj_1h_out , prot_jump_states_number_GS_in , prot_jump_states_GS_in);

		  if (prot_jump_states_number_GS_in == 1)
		    {
		      const unsigned int p_jump_state = prot_jump_states_GS_in(0);

		      const unsigned int p_jump_state_place = prot_SD_lj_GS_in.state_place_find (p_jump_state);

		      const int reordering_phase_p = minus_one_pow (p_jump_state_place + Zval_m1);

		      const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase_p/Up_HF_normalizing_sum;

		      for (int p_occ = 0 ; p_occ < Zval_m1 ; p_occ++)
			{
			  const unsigned int state_p_occ = prot_SD_lj_1h_out[p_occ];

			  const class nljm_struct &phi_p_occ = phi_p_table(state_p_occ);
			
			  const unsigned int sp_occ = phi_p_occ.get_shell_index ();

			  const class spherical_state &shell_prot_occ = shells_prot(sp_occ);

			  const double mp_occ = phi_p_occ.get_m ();

			  const double mp_out = imp_out - jp;

			  if (is_it_SGI)
			    SGI_part::Up_pp_part_calc (is_it_res , is_it_pm , pm , sp_occ , shell_prot_HF , shell_prot_occ , mp_out , mp_out , mp_occ , mp_occ ,
						       SDs_weight , CGs , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data);
			
			  if (is_it_MSGI)
			    MSGI_part::Up_pp_part_calc (is_it_res , is_it_pm , pm , shell_prot_HF , shell_prot_occ , mp_out , mp_out , mp_occ , mp_occ ,
							SDs_weight , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_HF_data);
			}
		    }
		  else if (prot_jump_states_number_GS_in == 2)
		    {
		      prot_SD_lj_1h_out.different_states_determine (prot_SD_lj_GS_in , prot_jump_states_number_1h_out , prot_jump_states_1h_out);
		    
		      const unsigned int sa_GS = prot_jump_states_GS_in(1);
		      const unsigned int sc_GS = prot_jump_states_GS_in(0);
		      const unsigned int sd_1h = prot_jump_states_1h_out(0);

		      const unsigned int sa_GS_place = prot_SD_lj_GS_in.state_place_find (sa_GS);
		      const unsigned int sc_GS_place = prot_SD_lj_GS_in.state_place_find (sc_GS);
		      const unsigned int sd_1h_place = prot_SD_lj_1h_out.state_place_find (sd_1h);

		      const class nljm_struct &phi_a_GS = phi_p_table(sa_GS);
		      const class nljm_struct &phi_c_GS = phi_p_table(sc_GS);
		      const class nljm_struct &phi_d_1h = phi_p_table(sd_1h);

		      if (same_nlj (phi_a_GS , phi_c_GS) && same_nlj (phi_a_GS , phi_d_1h))
			{
			  const unsigned int shell_prot_occ_index = phi_a_GS.get_shell_index ();

			  const class spherical_state &shell_prot_occ = shells_prot(shell_prot_occ_index);
			
			  const int reordering_phase_p = minus_one_pow (sa_GS_place + sc_GS_place + sd_1h_place + Zval_m1);

			  const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase_p/Up_HF_normalizing_sum;

			  const double ma_GS = phi_a_GS.get_m ();
			  const double mc_GS = phi_c_GS.get_m ();
			  const double md_1h = phi_d_1h.get_m ();

			  const double mb_1h = imp_out - jp;

			  if (is_it_SGI)
			    SGI_part::Up_pp_part_calc (is_it_res , is_it_pm , pm , shell_prot_occ_index , shell_prot_HF , shell_prot_occ , ma_GS , mb_1h , mc_GS , md_1h ,
						       SDs_weight , CGs , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data);
			
			  if (is_it_MSGI)
			    MSGI_part::Up_pp_part_calc (is_it_res , is_it_pm , pm , shell_prot_HF , shell_prot_occ , ma_GS , mb_1h , mc_GS , md_1h ,
							SDs_weight , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_HF_data);
			}
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potential_pn_part_calc (
											const bool is_it_res , 
											const bool is_it_pm , 
											const int pm , 
											const class CG_str &CGs , 
											const class array<double> &Gaussian_table_GL , 
											const class multipolar_expansion_str &multipolar_expansion , 
											const class interaction_class &inter_data_basis , 
											const class SGI_radial_tabs_str &neut_radial_tabs , 
											const class nucleons_data &prot_data_one_configuration_GSM , 
											const class nucleons_data &neut_data_one_configuration_GSM , 
											const class spherical_state &shell_prot_HF , 
											class HF_nucleons_data &prot_HF_data)
{ 
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const int Zval = prot_data_one_configuration_GSM.get_N_valence_nucleons_basis ();
  const int Nval = neut_data_one_configuration_GSM.get_N_valence_nucleons_basis ();
  
  const int Zval_m1 = Zval - 1;

  const class array<class nljm_struct> &phi_p_table = prot_data_one_configuration_GSM.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data_one_configuration_GSM.get_phi_table ();

  const class array<class spherical_state> &shells_neut = neut_data_one_configuration_GSM.get_shells ();

  const class lj_table<unsigned int> &dimensions_GS = prot_HF_data.get_dimensions_GS ();

  const class lj_table<complex<double> > &Up_HF_normalizing_sums = prot_HF_data.get_U_HF_normalizing_sums ();
  
  const class lj_table<class array<class Slater_determinant> > &prot_SDs_GS = prot_HF_data.get_prot_SDs_GS ();
  const class lj_table<class array<class Slater_determinant> > &neut_SDs_GS = prot_HF_data.get_neut_SDs_GS ();
  const class lj_table<class array<class Slater_determinant> > &prot_SDs_1h = prot_HF_data.get_SDs_1h ();

  const class lj_table<class array<complex<double> > > &SDs_GS_coefficients = prot_HF_data.get_SDs_GS_coefficients ();
  const class lj_table<class array<complex<double> > > &SDs_1h_coefficients = prot_HF_data.get_SDs_1h_coefficients ();

  const class lj_table<class array<bool> > &prot_SDs_1h_existence_table = prot_HF_data.get_SDs_1h_existence_table ();

  const double jp = shell_prot_HF.get_j ();

  const int lp = shell_prot_HF.get_l ();

  const int imp_number = make_int (2.0*jp + 1.0);

  const unsigned int dimension_GS = dimensions_GS(lp , jp);

  const complex<double> Up_HF_normalizing_sum = Up_HF_normalizing_sums(lp , jp);

  const class array<class Slater_determinant> &prot_SDs_GS_lj = prot_SDs_GS(lp , jp);
  const class array<class Slater_determinant> &neut_SDs_GS_lj = neut_SDs_GS(lp , jp);
  const class array<class Slater_determinant> &prot_SDs_1h_lj = prot_SDs_1h(lp , jp);

  const class array<complex<double> > &SDs_GS_coefficients_lj = SDs_GS_coefficients(lp , jp);
  const class array<complex<double> > &SDs_1h_coefficients_lj = SDs_1h_coefficients(lp , jp);

  const class array<bool> &prot_SDs_1h_existence_table_lj = prot_SDs_1h_existence_table(lp , jp);

  unsigned int prot_jump_states_number_GS_in  = 0;
  unsigned int neut_jump_states_number_GS_in  = 0;
  unsigned int neut_jump_states_number_GS_out = 0;

  class array<unsigned int> prot_jump_states_GS_in(Zval);
  class array<unsigned int> neut_jump_states_GS_in(Nval);
  class array<unsigned int> neut_jump_states_GS_out(Nval);

  for (unsigned int i_GS_in = 0 ; i_GS_in < dimension_GS ; i_GS_in++)
    {
      const complex<double> SD_GS_coefficient_in = SDs_GS_coefficients_lj(i_GS_in);
      if (SD_GS_coefficient_in == 0.0) continue;

      const class Slater_determinant &prot_SD_lj_GS_in = prot_SDs_GS_lj(i_GS_in);
      const class Slater_determinant &neut_SD_lj_GS_in = neut_SDs_GS_lj(i_GS_in);

      for (unsigned int i_GS_out = 0 ; i_GS_out < dimension_GS ; i_GS_out++)
	{
	  const class Slater_determinant &neut_SD_lj_GS_out = neut_SDs_GS_lj(i_GS_out);

	  neut_SD_lj_GS_in.different_states_determine (neut_SD_lj_GS_out , neut_jump_states_number_GS_in , neut_jump_states_GS_in);

	  if (neut_jump_states_number_GS_in <= 1)
	    {
	      for (int imp_out = 0 ; imp_out < imp_number ; imp_out++)
		{
		  const bool prot_SD_lj_1h_out_exists = prot_SDs_1h_existence_table_lj(i_GS_out , imp_out);

		  if (!prot_SD_lj_1h_out_exists) continue;

		  const complex<double> SD_1h_coefficient_out = SDs_1h_coefficients_lj(i_GS_out , imp_out);

		  if (SD_1h_coefficient_out == 0.0) continue;

		  const class Slater_determinant &prot_SD_lj_1h_out = prot_SDs_1h_lj(i_GS_out , imp_out);

		  prot_SD_lj_GS_in.different_states_determine (prot_SD_lj_1h_out , prot_jump_states_number_GS_in , prot_jump_states_GS_in);

		  if ((prot_jump_states_number_GS_in == 1) && (neut_jump_states_number_GS_in == 0))
		    {
		      const unsigned int p_jump_state = prot_jump_states_GS_in(0);

		      const unsigned int p_jump_state_place = prot_SD_lj_GS_in.state_place_find (p_jump_state);

		      const int reordering_phase_p = minus_one_pow (p_jump_state_place + Zval_m1);

		      const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase_p/Up_HF_normalizing_sum;

		      for (int n_occ = 0 ; n_occ < Nval ; n_occ++)
			{
			  const unsigned int state_n_occ = neut_SD_lj_GS_out[n_occ];

			  const class nljm_struct &phi_n_occ = phi_n_table(state_n_occ);
			  
			  const unsigned int sn_occ = phi_n_occ.get_shell_index ();

			  const class spherical_state &shell_neut_occ = shells_neut(sn_occ);

			  const double mn_occ = phi_n_occ.get_m ();

			  const double mp_out = imp_out - jp;

			  if (is_it_SGI)
			    SGI_part::Up_pn_part_calc (is_it_res , is_it_pm , pm , sn_occ , shell_prot_HF , shell_neut_occ , mp_out , mp_out , mn_occ , mn_occ ,
						       SDs_weight , CGs , multipolar_expansion , inter_data_basis , neut_radial_tabs , prot_HF_data);
			  
			  if (is_it_MSGI)
			    MSGI_part::Up_pn_part_calc (is_it_res , is_it_pm , pm , shell_prot_HF , shell_neut_occ , mp_out , mp_out , mn_occ , mn_occ ,
							SDs_weight , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_HF_data);
			}
		    }
		  else if ((prot_jump_states_number_GS_in == 1) && (neut_jump_states_number_GS_in == 1))
		    {
		      neut_SD_lj_GS_out.different_states_determine (neut_SD_lj_GS_in , neut_jump_states_number_GS_out , neut_jump_states_GS_out);
		      
		      const unsigned int p_in  = prot_jump_states_GS_in(0);
		      const unsigned int n_in  = neut_jump_states_GS_in(0);
		      const unsigned int n_out = neut_jump_states_GS_out(0);
		      
		      const unsigned int p_in_place  = prot_SD_lj_GS_in.state_place_find (p_in);
		      const unsigned int n_in_place  = neut_SD_lj_GS_in.state_place_find (n_in);
		      const unsigned int n_out_place = neut_SD_lj_GS_out.state_place_find (n_out);
		      
		      const int reordering_phase = minus_one_pow (n_in_place + n_out_place + p_in_place + Zval_m1);

		      const class nljm_struct &phi_p_in  = phi_p_table(p_in);
		      const class nljm_struct &phi_n_in  = phi_n_table(n_in);
		      const class nljm_struct &phi_n_out = phi_n_table(n_out);

		      if (same_nlj (phi_n_in , phi_n_out))
			{
			  const unsigned int shell_neut_in_index = phi_n_in.get_shell_index ();
			  
			  const class spherical_state &shell_neut_in = shells_neut(shell_neut_in_index);
			  
			  const double mp_in  = phi_p_in.get_m ();
			  const double mn_in  = phi_n_in.get_m ();
			  const double mn_out = phi_n_out.get_m ();
			  
			  const double mp_out = imp_out - jp;

			  const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase/Up_HF_normalizing_sum;

			  if (is_it_SGI)
			    SGI_part::Up_pn_part_calc (is_it_res , is_it_pm , pm , shell_neut_in_index , shell_prot_HF , shell_neut_in , mp_in , mp_out , mn_in , mn_out ,
						       SDs_weight , CGs , multipolar_expansion , inter_data_basis , neut_radial_tabs , prot_HF_data);
			  
			  if (is_it_MSGI)
			    MSGI_part::Up_pn_part_calc (is_it_res , is_it_pm , pm , shell_prot_HF , shell_neut_in , mp_in , mp_out , mn_in , mn_out ,
							SDs_weight , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_HF_data);
			}
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potential_nn_part_calc (
											const bool is_it_res , 
											const bool is_it_pm , 
											const int pm , 
											const class CG_str &CGs , 
											const class array<double> &Gaussian_table_GL , 
											const class multipolar_expansion_str &multipolar_expansion , 
											const class interaction_class &inter_data_basis , 
											const class SGI_radial_tabs_str &neut_radial_tabs , 
											const class nucleons_data &neut_data_one_configuration_GSM , 
											const class spherical_state &shell_neut_HF , 
											class HF_nucleons_data &neut_HF_data)
{ 
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const int Nval = neut_data_one_configuration_GSM.get_N_valence_nucleons_basis ();

  const int Nval_m1 = Nval - 1;

  const class array<class nljm_struct> &phi_n_table = neut_data_one_configuration_GSM.get_phi_table ();

  const class array<class spherical_state> &shells_neut = neut_data_one_configuration_GSM.get_shells ();

  const class lj_table<unsigned int> &dimensions_GS = neut_HF_data.get_dimensions_GS ();

  const class lj_table<complex<double> > &Un_HF_normalizing_sums = neut_HF_data.get_U_HF_normalizing_sums ();
  
  const class lj_table<class array<class Slater_determinant> > &prot_SDs_GS = neut_HF_data.get_prot_SDs_GS ();
  const class lj_table<class array<class Slater_determinant> > &neut_SDs_GS = neut_HF_data.get_neut_SDs_GS ();
  const class lj_table<class array<class Slater_determinant> > &neut_SDs_1h = neut_HF_data.get_SDs_1h ();

  const class lj_table<class array<complex<double> > > &SDs_GS_coefficients = neut_HF_data.get_SDs_GS_coefficients ();
  const class lj_table<class array<complex<double> > > &SDs_1h_coefficients = neut_HF_data.get_SDs_1h_coefficients ();
  
  const class lj_table<class array<bool> > &neut_SDs_1h_existence_table = neut_HF_data.get_SDs_1h_existence_table ();

  const double jn = shell_neut_HF.get_j ();

  const int ln = shell_neut_HF.get_l ();

  const int imn_number = make_int (2.0*jn + 1.0);

  const unsigned int dimension_GS = dimensions_GS(ln , jn);

  const complex<double> Un_HF_normalizing_sum = Un_HF_normalizing_sums(ln , jn);
	
  const class array<class Slater_determinant > &prot_SDs_GS_lj = prot_SDs_GS(ln , jn);
  const class array<class Slater_determinant > &neut_SDs_GS_lj = neut_SDs_GS(ln , jn);
  const class array<class Slater_determinant > &neut_SDs_1h_lj = neut_SDs_1h(ln , jn);
  
  const class array<complex<double> > &SDs_GS_coefficients_lj = SDs_GS_coefficients(ln , jn);
  const class array<complex<double> > &SDs_1h_coefficients_lj = SDs_1h_coefficients(ln , jn);
  
  const class array<bool> &neut_SDs_1h_existence_table_lj = neut_SDs_1h_existence_table(ln , jn);

  unsigned int neut_jump_states_number_GS_in  = 0;
  unsigned int neut_jump_states_number_1h_out = 0;

  class array<unsigned int> neut_jump_states_GS_in(Nval);
  class array<unsigned int> neut_jump_states_1h_out(Nval_m1);

  for (unsigned int i_GS_in = 0 ; i_GS_in < dimension_GS ; i_GS_in++)
    {
      const complex<double> SD_GS_coefficient_in = SDs_GS_coefficients_lj(i_GS_in);
      
      if (SD_GS_coefficient_in == 0.0) continue;

      const class Slater_determinant &prot_SD_lj_GS_in = prot_SDs_GS_lj(i_GS_in);
      const class Slater_determinant &neut_SD_lj_GS_in = neut_SDs_GS_lj(i_GS_in);

      for (unsigned int i_GS_out = 0 ; i_GS_out < dimension_GS ; i_GS_out++)
	{
	  const class Slater_determinant &prot_SD_lj_GS_out = prot_SDs_GS_lj(i_GS_out);

	  if (prot_SD_lj_GS_in == prot_SD_lj_GS_out)
	    {
	      for (int imn_out = 0 ; imn_out < imn_number ; imn_out++)
		{
		  const bool neut_SD_lj_1h_out_exists = neut_SDs_1h_existence_table_lj(i_GS_out , imn_out);

		  if (!neut_SD_lj_1h_out_exists) continue;

		  const complex<double> SD_1h_coefficient_out = SDs_1h_coefficients_lj(i_GS_out , imn_out);

		  if (SD_1h_coefficient_out == 0.0) continue;

		  const class Slater_determinant &neut_SD_lj_1h_out = neut_SDs_1h_lj(i_GS_out , imn_out);

		  neut_SD_lj_GS_in.different_states_determine (neut_SD_lj_1h_out , neut_jump_states_number_GS_in , neut_jump_states_GS_in);
					
		  if (neut_jump_states_number_GS_in == 1)
		    {
		      const unsigned int n_jump_state = neut_jump_states_GS_in(0);

		      const unsigned int n_jump_state_place = neut_SD_lj_GS_in.state_place_find (n_jump_state);
		    
		      const int reordering_phase_n = minus_one_pow (n_jump_state_place + Nval_m1);
		    
		      const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase_n/Un_HF_normalizing_sum;

		      for (int n_occ = 0 ; n_occ < Nval_m1 ; n_occ++)
			{
			  const unsigned int state_n_occ = neut_SD_lj_1h_out[n_occ];

			  const class nljm_struct &phi_n_occ = phi_n_table(state_n_occ);
			
			  const unsigned int sn_occ = phi_n_occ.get_shell_index ();

			  const class spherical_state &shell_neut_occ = shells_neut(sn_occ);

			  const double mn_occ = phi_n_occ.get_m ();

			  const double mn_out = imn_out - jn;

			  if (is_it_SGI)
			    SGI_part::Un_nn_part_calc (is_it_res , is_it_pm , pm , sn_occ , shell_neut_HF , shell_neut_occ , mn_out , mn_out , mn_occ , mn_occ ,
						       SDs_weight , CGs , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data);
			
			  if (is_it_MSGI)
			    MSGI_part::Un_nn_part_calc (is_it_res , is_it_pm , pm , shell_neut_HF , shell_neut_occ , mn_out , mn_out , mn_occ , mn_occ ,
							SDs_weight , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_HF_data);
			}
		    }
		  else if (neut_jump_states_number_GS_in == 2)
		    {
		      neut_SD_lj_1h_out.different_states_determine (neut_SD_lj_GS_in , neut_jump_states_number_1h_out , neut_jump_states_1h_out);
		    
		      const unsigned int sa_GS = neut_jump_states_GS_in(1);
		      const unsigned int sc_GS = neut_jump_states_GS_in(0);
		      const unsigned int sd_1h = neut_jump_states_1h_out(0);
		    
		      const unsigned int sa_GS_place = neut_SD_lj_GS_in.state_place_find (sa_GS);
		      const unsigned int sc_GS_place = neut_SD_lj_GS_in.state_place_find (sc_GS);
		      const unsigned int sd_1h_place = neut_SD_lj_1h_out.state_place_find (sd_1h);
		    
		      const class nljm_struct &phi_a_GS = phi_n_table(sa_GS);
		      const class nljm_struct &phi_c_GS = phi_n_table(sc_GS);
		      const class nljm_struct &phi_d_1h = phi_n_table(sd_1h);

		      if (same_nlj (phi_a_GS , phi_c_GS) && same_nlj (phi_a_GS , phi_d_1h))
			{
			  const unsigned int shell_neut_occ_index = phi_a_GS.get_shell_index ();

			  const class spherical_state &shell_neut_occ = shells_neut(shell_neut_occ_index);
			
			  const int reordering_phase_n = minus_one_pow (sa_GS_place + sc_GS_place + sd_1h_place + Nval_m1);

			  const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase_n/Un_HF_normalizing_sum;

			  const double ma_GS = phi_a_GS.get_m ();
			  const double mc_GS = phi_c_GS.get_m ();
			  const double md_1h = phi_d_1h.get_m ();
			  
			  const double mb_1h = imn_out - jn;

			  if (is_it_SGI)
			    SGI_part::Un_nn_part_calc (is_it_res , is_it_pm , pm , shell_neut_occ_index , shell_neut_HF , shell_neut_occ , ma_GS , mb_1h , mc_GS , md_1h ,
						       SDs_weight , CGs , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data);
			
			  if (is_it_MSGI)
			    MSGI_part::Un_nn_part_calc (is_it_res , is_it_pm , pm , shell_neut_HF , shell_neut_occ , ma_GS , mb_1h , mc_GS , md_1h ,
							SDs_weight , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_HF_data);
			}
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potential_pn_part_calc (
											const bool is_it_res , 
											const bool is_it_pm , 
											const int pm , 
											const class CG_str &CGs , 
											const class array<double> &Gaussian_table_GL , 
											const class multipolar_expansion_str &multipolar_expansion , 
											const class interaction_class &inter_data_basis , 
											const class SGI_radial_tabs_str &prot_radial_tabs , 
											const class nucleons_data &prot_data_one_configuration_GSM , 
											const class nucleons_data &neut_data_one_configuration_GSM , 
											const class spherical_state &shell_neut_HF , 
											class HF_nucleons_data &neut_HF_data)
{
  const int Zval = prot_data_one_configuration_GSM.get_N_valence_nucleons_basis ();
  const int Nval = neut_data_one_configuration_GSM.get_N_valence_nucleons_basis ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const int Nval_m1 = Nval - 1;

  const class array<class nljm_struct> &phi_p_table = prot_data_one_configuration_GSM.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data_one_configuration_GSM.get_phi_table ();

  const class array<class spherical_state> &shells_prot = prot_data_one_configuration_GSM.get_shells ();

  const class lj_table<unsigned int> &dimensions_GS = neut_HF_data.get_dimensions_GS ();

  const class lj_table<complex<double> > &Un_HF_normalizing_sums = neut_HF_data.get_U_HF_normalizing_sums ();

  const class lj_table<class array<class Slater_determinant> > &prot_SDs_GS = neut_HF_data.get_prot_SDs_GS ();
  const class lj_table<class array<class Slater_determinant> > &neut_SDs_GS = neut_HF_data.get_neut_SDs_GS ();
  const class lj_table<class array<class Slater_determinant> > &neut_SDs_1h = neut_HF_data.get_SDs_1h ();

  const class lj_table<class array<complex<double> > > &SDs_GS_coefficients = neut_HF_data.get_SDs_GS_coefficients ();
  const class lj_table<class array<complex<double> > > &SDs_1h_coefficients = neut_HF_data.get_SDs_1h_coefficients ();

  const class lj_table<class array<bool> > &neut_SDs_1h_existence_table = neut_HF_data.get_SDs_1h_existence_table ();

  const double jn = shell_neut_HF.get_j ();

  const int ln = shell_neut_HF.get_l ();

  const int imn_number = make_int (2.0*jn + 1.0);

  const unsigned int dimension_GS = dimensions_GS(ln , jn);

  const complex<double> Un_HF_normalizing_sum = Un_HF_normalizing_sums(ln , jn);

  const class array<class Slater_determinant > &prot_SDs_GS_lj = prot_SDs_GS(ln , jn);
  const class array<class Slater_determinant > &neut_SDs_GS_lj = neut_SDs_GS(ln , jn);
  const class array<class Slater_determinant > &neut_SDs_1h_lj = neut_SDs_1h(ln , jn);

  const class array<complex<double> > &SDs_GS_coefficients_lj = SDs_GS_coefficients(ln , jn);
  const class array<complex<double> > &SDs_1h_coefficients_lj = SDs_1h_coefficients(ln , jn);

  const class array<bool> &neut_SDs_1h_existence_table_lj = neut_SDs_1h_existence_table(ln , jn);

  unsigned int prot_jump_states_number_GS_in  = 0;
  unsigned int prot_jump_states_number_GS_out = 0;
  unsigned int neut_jump_states_number_GS_in  = 0;

  class array<unsigned int> prot_jump_states_GS_in(Zval);
  class array<unsigned int> prot_jump_states_GS_out(Zval);
  class array<unsigned int> neut_jump_states_GS_in(Nval);

  for (unsigned int i_GS_in = 0 ; i_GS_in < dimension_GS ; i_GS_in++)
    {
      const complex<double> SD_GS_coefficient_in = SDs_GS_coefficients_lj(i_GS_in);
      
      if (SD_GS_coefficient_in == 0.0) continue;

      const class Slater_determinant &prot_SD_lj_GS_in = prot_SDs_GS_lj(i_GS_in);
      const class Slater_determinant &neut_SD_lj_GS_in = neut_SDs_GS_lj(i_GS_in);

      for (unsigned int i_GS_out = 0 ; i_GS_out < dimension_GS ; i_GS_out++)
	{
	  const class Slater_determinant &prot_SD_lj_GS_out = prot_SDs_GS_lj(i_GS_out);

	  prot_SD_lj_GS_in.different_states_determine (prot_SD_lj_GS_out , prot_jump_states_number_GS_in , prot_jump_states_GS_in);
			
	  if (prot_jump_states_number_GS_in <= 1)
	    {
	      for (int imn_out = 0 ; imn_out < imn_number ; imn_out++)
		{
		  const bool neut_SD_lj_1h_out_exists = neut_SDs_1h_existence_table_lj(i_GS_out , imn_out);

		  if (!neut_SD_lj_1h_out_exists) continue;
					
		  const complex<double> SD_1h_coefficient_out = SDs_1h_coefficients_lj(i_GS_out , imn_out);

		  if (SD_1h_coefficient_out == 0.0) continue;

		  const class Slater_determinant &neut_SD_lj_1h_out = neut_SDs_1h_lj(i_GS_out , imn_out);

		  neut_SD_lj_GS_in.different_states_determine (neut_SD_lj_1h_out , neut_jump_states_number_GS_in , neut_jump_states_GS_in);

		  if ((prot_jump_states_number_GS_in == 0) && (neut_jump_states_number_GS_in == 1))
		    {
		      const unsigned int n_jump_state = neut_jump_states_GS_in(0);

		      const unsigned int n_jump_state_place = neut_SD_lj_GS_in.state_place_find (n_jump_state);

		      const int reordering_phase_n = minus_one_pow (n_jump_state_place + Nval_m1);

		      const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase_n/Un_HF_normalizing_sum;

		      for (int p_occ = 0 ; p_occ < Zval ; p_occ++)
			{
			  const unsigned int state_p_occ = prot_SD_lj_GS_out[p_occ];

			  const class nljm_struct &phi_p_occ = phi_p_table(state_p_occ);
			  
			  const unsigned int sp_occ = phi_p_occ.get_shell_index ();

			  const class spherical_state &shell_prot_occ = shells_prot(sp_occ);

			  const double mp_occ = phi_p_occ.get_m ();

			  const double mn_out = imn_out - jn;

			  if (is_it_SGI)
			    SGI_part::Un_pn_part_calc (is_it_res , is_it_pm , pm , sp_occ , shell_neut_HF , shell_prot_occ , mn_out , mn_out , mp_occ , mp_occ ,
						       SDs_weight , CGs , multipolar_expansion , inter_data_basis , prot_radial_tabs , neut_HF_data);
			  
			  if (is_it_MSGI)
			    MSGI_part::Un_pn_part_calc (is_it_res , is_it_pm , pm , shell_neut_HF , shell_prot_occ , mn_out , mn_out , mp_occ , mp_occ ,
							SDs_weight , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_HF_data);
			}
		    }
		  else if ((prot_jump_states_number_GS_in == 1) && (neut_jump_states_number_GS_in == 1))
		    {
		      prot_SD_lj_GS_out.different_states_determine (prot_SD_lj_GS_in , prot_jump_states_number_GS_out , prot_jump_states_GS_out);
		      
		      const unsigned int p_in  = prot_jump_states_GS_in(0);
		      const unsigned int n_in  = neut_jump_states_GS_in(0);
		      const unsigned int p_out = prot_jump_states_GS_out(0);

		      const unsigned int p_in_place  = prot_SD_lj_GS_in.state_place_find (p_in);
		      const unsigned int n_in_place  = neut_SD_lj_GS_in.state_place_find (n_in);
		      const unsigned int p_out_place = prot_SD_lj_GS_out.state_place_find (p_out);

		      const int reordering_phase = minus_one_pow (p_in_place + p_out_place + n_in_place + Nval_m1);
		      
		      const class nljm_struct &phi_p_in  = phi_p_table(p_in);
		      const class nljm_struct &phi_n_in  = phi_n_table(n_in);
		      const class nljm_struct &phi_p_out = phi_p_table(p_out);

		      if (same_nlj (phi_p_in , phi_p_out))
			{
			  const unsigned int shell_prot_in_index = phi_p_in.get_shell_index ();
			  
			  const class spherical_state &shell_prot_in = shells_prot(shell_prot_in_index);

			  const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase/Un_HF_normalizing_sum;

			  const double mp_in  = phi_p_in.get_m ();
			  const double mn_in  = phi_n_in.get_m ();
			  const double mp_out = phi_p_out.get_m ();
			  
			  const double mn_out = imn_out - jn;
							
			  if (is_it_SGI)
			    SGI_part::Un_pn_part_calc (is_it_res , is_it_pm , pm , shell_prot_in_index , shell_neut_HF , shell_prot_in , mn_in , mn_out , mp_in , mp_out ,
						       SDs_weight , CGs , multipolar_expansion , inter_data_basis , prot_radial_tabs , neut_HF_data);
			  
			  if (is_it_MSGI)
			    MSGI_part::Un_pn_part_calc (is_it_res , is_it_pm , pm , shell_neut_HF , shell_prot_in , mn_in , mn_out , mp_in , mp_out ,
							SDs_weight , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_HF_data);
			}
		    }
		}
	    }
	}
    }
}




// Calculation of the direct and exchange parts of the MSDHF potential
// ----------------------------------------------------------------
// The equivalent MSDHF potential U[HF] = U[MSDHF](direct) - U[MSDHF](exchange) writes, for MSGI, along with its source:
//
// U_HF(dir)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . F_Gaussian(r) . \int u_occ^2(r') F_Gaussian(r') dr'
// U_HF(exc)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' . F(r)
//
// The equivalent MSDHF potential U_HF = U_HF(direct) - U_HF(exchange) writes, for SGI, along with its source:
//
// U_HF(dir)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . Vl'_SGI(r , 2R0-r) . u_occ^2(2R0-r)
// U_HF(exc)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ, l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) . F(r)
//
// where weight is function of Clebsch-Gordan coefficients and of the SD components of the GSM ground state of the optimized configuration (see above).
// coupling_constant(Pi,J) is the Pi-J-dependent coupling constant of the MSGI interaction, 
// F_Gaussian(r) is the Gaussian form factor entering the MSGI interaction (see GSM_TBME_MSGI.cpp) and
// Vl'_SGI(r) is the multipolar expansion of the SGI interaction (see GSM_interaction_class.cpp) and R0 is the radius of the SGI/MSGI interaction.
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
// Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
// The ratio |u(r)|^2/|u'(r)|^2) prevents F(r) to be non zero when r -> +oo.
// Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// If one uses holes, there is an additional double-counting potential term  <wf[out] | U[hole-double-counting] | wf[in]> term to remove (see GSM_hole_double_counting.cpp).
// The formula is: < wf[out] | U[hole-double-counting] | wf[in] > = \sum_{holes,J'} (2J' + 1)/(2j + 1) <wf[out] wf[hole] | V | wf[in] wf[hole]>_J,
// which is removed from the MSDHF potential. There is no 1p-1h term, as it is diagonal only, so that it cannot enter HF or MSDHF potentials.
//
// This routine loops over all proton and neutron states and occupied states and calls routines of the namespaces SGI_part_common and MSGI_part_common.

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_pp_part_calc (
											 const bool HO_diag , 
											 const class CG_str &CGs , 
											 const class array<double> &Gaussian_table_GL , 
											 const class multipolar_expansion_str &multipolar_expansion , 
											 const class interaction_class &inter_data_basis , 
											 const class SGI_radial_tabs_str &prot_radial_tabs , 
											 const class nucleons_data &prot_data_one_configuration_GSM , 
											 class HF_nucleons_data &prot_HF_data)
{
  const unsigned int Np_nlj     = prot_HF_data.get_N_nlj ();
  const unsigned int Np_nlj_res = prot_HF_data.get_N_nlj_res ();

  const class array<class nlj_struct> &shells_prot_qn = prot_HF_data.get_shells_quantum_numbers ();

  const class array<class spherical_state> &shells_prot     = prot_HF_data.get_shells ();
  const class array<class spherical_state> &shells_prot_res = prot_HF_data.get_shells_res ();

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj_res ; sp_HF++)
    {
      const class spherical_state &shell_prot_res = shells_prot_res(sp_HF);
      
      if (shell_prot_res.is_it_filled ())
	prot_trivially_equivalent_potential_pp_part_calc (true , false , NADA , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_data_one_configuration_GSM , shell_prot_res , prot_HF_data);
    }

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class nlj_struct &shell_prot_qn = shells_prot_qn(sp_HF);

      const bool is_it_HO = shell_prot_qn.get_is_it_HO ();
      
      const bool S_matrix_pole = shell_prot_qn.get_S_matrix_pole ();

      const bool no_HO = (!is_it_HO) && (!HO_diag);

      const class spherical_state &shell_prot_HF = shells_prot(sp_HF);

      if ((S_matrix_pole || no_HO) && shell_prot_HF.is_it_filled ())
	{
	  if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	    {
	      prot_trivially_equivalent_potential_pp_part_calc (false , false , NADA , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_data_one_configuration_GSM , shell_prot_HF , prot_HF_data);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_pn_part_calc (
											 const bool HO_diag , 
											 const class CG_str &CGs , 
											 const class array<double> &Gaussian_table_GL , 
											 const class multipolar_expansion_str &multipolar_expansion , 
											 const class interaction_class &inter_data_basis , 
											 const class SGI_radial_tabs_str &neut_radial_tabs , 
											 const class nucleons_data &prot_data_one_configuration_GSM , 
											 const class nucleons_data &neut_data_one_configuration_GSM , 
											 class HF_nucleons_data &prot_HF_data)
{
  const unsigned int Np_nlj     = prot_HF_data.get_N_nlj ();
  const unsigned int Np_nlj_res = prot_HF_data.get_N_nlj_res ();

  const class array<class nlj_struct> &shells_prot_qn = prot_HF_data.get_shells_quantum_numbers ();

  const class array<class spherical_state> &shells_prot     = prot_HF_data.get_shells ();
  const class array<class spherical_state> &shells_prot_res = prot_HF_data.get_shells_res ();

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj_res ; sp_HF++)
    {
      const class spherical_state &shell_prot_res = shells_prot_res(sp_HF);
      
      if (shell_prot_res.is_it_filled ())
	prot_trivially_equivalent_potential_pn_part_calc (true , false , NADA , CGs , Gaussian_table_GL , multipolar_expansion ,
							  inter_data_basis , neut_radial_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , shell_prot_res , prot_HF_data);
    }

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class nlj_struct &shell_prot_qn = shells_prot_qn(sp_HF);

      const bool is_it_HO = shell_prot_qn.get_is_it_HO ();
      
      const bool S_matrix_pole = shell_prot_qn.get_S_matrix_pole ();

      const bool no_HO = (!is_it_HO) && (!HO_diag);

      const class spherical_state &shell_prot_HF = shells_prot(sp_HF);

      if ((S_matrix_pole || no_HO) && shell_prot_HF.is_it_filled ())
	{
	  if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	    {
	      prot_trivially_equivalent_potential_pn_part_calc (false , false , NADA , CGs , Gaussian_table_GL , multipolar_expansion ,
								inter_data_basis , neut_radial_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , shell_prot_HF , prot_HF_data);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_nn_part_calc (
											 const bool HO_diag , 
											 const class CG_str &CGs , 
											 const class array<double> &Gaussian_table_GL , 
											 const class multipolar_expansion_str &multipolar_expansion , 
											 const class interaction_class &inter_data_basis , 
											 const class SGI_radial_tabs_str &neut_radial_tabs , 
											 const class nucleons_data &neut_data_one_configuration_GSM , 
											 class HF_nucleons_data &neut_HF_data)
{
  const unsigned int Nn_nlj     = neut_HF_data.get_N_nlj ();
  const unsigned int Nn_nlj_res = neut_HF_data.get_N_nlj_res ();

  const class array<class nlj_struct> &shells_neut_qn = neut_HF_data.get_shells_quantum_numbers ();

  const class array<class spherical_state> &shells_neut     = neut_HF_data.get_shells ();
  const class array<class spherical_state> &shells_neut_res = neut_HF_data.get_shells_res ();

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj_res ; sn_HF++)
    {
      const class spherical_state &shell_neut_res = shells_neut_res(sn_HF);
      
      if (shell_neut_res.is_it_filled ())
	neut_trivially_equivalent_potential_nn_part_calc (true , false , NADA , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_data_one_configuration_GSM , shell_neut_res , neut_HF_data);
    }

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class nlj_struct &shell_neut_qn = shells_neut_qn(sn_HF);

      const bool is_it_HO = shell_neut_qn.get_is_it_HO ();
      
      const bool S_matrix_pole = shell_neut_qn.get_S_matrix_pole ();

      const bool no_HO = (!is_it_HO) && (!HO_diag);

      const class spherical_state &shell_neut_HF = shells_neut(sn_HF);

      if ((S_matrix_pole || no_HO) && shell_neut_HF.is_it_filled ())
	{
	  if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	    {
	      neut_trivially_equivalent_potential_nn_part_calc (false , false , NADA , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_data_one_configuration_GSM , shell_neut_HF , neut_HF_data);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_pn_part_calc (
											 const bool HO_diag , 
											 const class CG_str &CGs , 
											 const class array<double> &Gaussian_table_GL , 
											 const class multipolar_expansion_str &multipolar_expansion , 
											 const class interaction_class &inter_data_basis , 
											 const class SGI_radial_tabs_str &prot_radial_tabs , 
											 const class nucleons_data &prot_data_one_configuration_GSM , 
											 const class nucleons_data &neut_data_one_configuration_GSM , 
											 class HF_nucleons_data &neut_HF_data)
{
  const unsigned int Nn_nlj     = neut_HF_data.get_N_nlj ();
  const unsigned int Nn_nlj_res = neut_HF_data.get_N_nlj_res ();

  const class array<class nlj_struct> &shells_neut_qn = neut_HF_data.get_shells_quantum_numbers ();

  const class array<class spherical_state> &shells_neut     = neut_HF_data.get_shells ();
  const class array<class spherical_state> &shells_neut_res = neut_HF_data.get_shells_res ();

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj_res ; sn_HF++)
    {
      const class spherical_state &shell_neut_res = shells_neut_res(sn_HF);
      
      if (shell_neut_res.is_it_filled ())
	neut_trivially_equivalent_potential_pn_part_calc (true , false , NADA , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis ,
							  prot_radial_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , shell_neut_res , neut_HF_data);
    }

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class nlj_struct &shell_neut_qn = shells_neut_qn(sn_HF);

      const bool is_it_HO = shell_neut_qn.get_is_it_HO ();
      
      const bool S_matrix_pole = shell_neut_qn.get_S_matrix_pole ();

      const bool no_HO = (!is_it_HO) && (!HO_diag);

      const class spherical_state &shell_neut_HF = shells_neut(sn_HF);

      if ((S_matrix_pole || no_HO) && shell_neut_HF.is_it_filled ())
	{
	  if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	    {		
	      neut_trivially_equivalent_potential_pn_part_calc (false , false , NADA , CGs , Gaussian_table_GL , multipolar_expansion ,
								inter_data_basis , prot_radial_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , shell_neut_HF , neut_HF_data);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_pp_part_shells_pm_calc (
												   const int pm , 
												   const class CG_str &CGs , 
												   const class array<double> &Gaussian_table_GL , 
												   const class multipolar_expansion_str &multipolar_expansion , 
												   const class interaction_class &inter_data_basis , 
												   const class SGI_radial_tabs_str &prot_radial_tabs , 
												   const class nucleons_data &prot_data_one_configuration_GSM , 
												   class HF_nucleons_data &prot_HF_data)
{ 
  const unsigned int Np_nlj = prot_HF_data.get_N_nlj ();

  const class array<class spherical_state> &shells_prot_pm = (pm == 1) ? (prot_HF_data.get_shells_plus ()) : (prot_HF_data.get_shells_minus ());

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class spherical_state &shell_prot_pm = shells_prot_pm(sp_HF);
      
      if (shell_prot_pm.is_it_filled ())
	{
	  if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	    {
	      prot_trivially_equivalent_potential_pp_part_calc (false , true , pm , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_data_one_configuration_GSM , shell_prot_pm , prot_HF_data);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_pn_part_shells_pm_calc (
												   const int pm , 
												   const class CG_str &CGs , 
												   const class array<double> &Gaussian_table_GL , 
												   const class multipolar_expansion_str &multipolar_expansion , 
												   const class interaction_class &inter_data_basis , 
												   const class SGI_radial_tabs_str &neut_radial_tabs , 
												   const class nucleons_data &prot_data_one_configuration_GSM , 
												   const class nucleons_data &neut_data_one_configuration_GSM , 
												   class HF_nucleons_data &prot_HF_data)
{ 
  const unsigned int Np_nlj = prot_HF_data.get_N_nlj ();

  const class array<class spherical_state> &shells_prot_pm = (pm == 1) ? (prot_HF_data.get_shells_plus ()) : (prot_HF_data.get_shells_minus ());

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class spherical_state &shell_prot_pm = shells_prot_pm(sp_HF);
      
      if (shell_prot_pm.is_it_filled ())
	{
	  if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	    {
	      prot_trivially_equivalent_potential_pn_part_calc (false , true , pm , CGs , Gaussian_table_GL , multipolar_expansion ,
								inter_data_basis , neut_radial_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , shell_prot_pm , prot_HF_data);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_nn_part_shells_pm_calc (
												   const int pm , 
												   const class CG_str &CGs , 
												   const class array<double> &Gaussian_table_GL , 
												   const class multipolar_expansion_str &multipolar_expansion , 
												   const class interaction_class &inter_data_basis , 
												   const class SGI_radial_tabs_str &neut_radial_tabs , 
												   const class nucleons_data &neut_data_one_configuration_GSM , 
												   class HF_nucleons_data &neut_HF_data)
{
  const unsigned int Nn_nlj = neut_HF_data.get_N_nlj ();

  const class array<class spherical_state> &shells_neut_pm = (pm == 1) ? (neut_HF_data.get_shells_plus ()) : (neut_HF_data.get_shells_minus ());

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class spherical_state &shell_neut_pm = shells_neut_pm(sn_HF);
      
      if (shells_neut_pm(sn_HF).is_it_filled ())
	{
	  if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	    {
	      neut_trivially_equivalent_potential_nn_part_calc (false , true , pm , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_data_one_configuration_GSM , shell_neut_pm , neut_HF_data);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_pn_part_shells_pm_calc (
												   const int pm , 
												   const class CG_str &CGs , 
												   const class array<double> &Gaussian_table_GL , 
												   const class multipolar_expansion_str &multipolar_expansion , 
												   const class interaction_class &inter_data_basis , 
												   const class SGI_radial_tabs_str &prot_radial_tabs , 
												   const class nucleons_data &prot_data_one_configuration_GSM , 
												   const class nucleons_data &neut_data_one_configuration_GSM , 
												   class HF_nucleons_data &neut_HF_data)
{
  const unsigned int Nn_nlj = neut_HF_data.get_N_nlj ();

  const class array<class spherical_state> &shells_neut_pm = (pm == 1) ? (neut_HF_data.get_shells_plus ()) : (neut_HF_data.get_shells_minus ());

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class spherical_state &shell_neut_pm = shells_neut_pm(sn_HF);
      
      if (shells_neut_pm(sn_HF).is_it_filled ())
	{
	  if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	    {
	      neut_trivially_equivalent_potential_pn_part_calc (false , true , pm , CGs , Gaussian_table_GL , multipolar_expansion ,
								inter_data_basis , prot_radial_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , shell_neut_pm , neut_HF_data);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_hole_double_counting_pp_part_remove (
														const bool HO_diag , 
														const class array<double> &Gaussian_table_GL , 
														const class multipolar_expansion_str &multipolar_expansion , 
														const class interaction_class &inter_data_basis , 
														const class SGI_radial_tabs_str &prot_radial_tabs , 
														class HF_nucleons_data &prot_HF_data)
{
  const unsigned int Np_nlj     = prot_HF_data.get_N_nlj ();
  const unsigned int Np_nlj_res = prot_HF_data.get_N_nlj_res ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);
  
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_prot     = prot_HF_data.get_shells ();
  const class array<class spherical_state> &shells_prot_res = prot_HF_data.get_shells_res ();

  const class array<class nlj_struct> &shells_prot_qn     = prot_HF_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_prot_res_qn = prot_HF_data.get_shells_quantum_numbers_res ();

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj_res ; sp_HF++)
    {
      const class spherical_state &shell_prot_res = shells_prot_res(sp_HF);
      
      if (shell_prot_res.is_it_filled ())
	{
	  for (unsigned int sp = 0 ; sp < Np_nlj_res ; sp++)
	    {
	      const class nlj_struct &shell_prot_qn_possible_hole = shells_prot_res_qn(sp);
	      
	      const bool hole_state_p = shell_prot_qn_possible_hole.get_hole_state ();

	      if (hole_state_p)
		{
		  const class spherical_state &shell_prot_hole = shells_prot_res(sp);

		  if (is_it_SGI)
		    SGI_part::Up_hole_double_counting_pp_part_remove (true , false , NADA , sp , shell_prot_res , shell_prot_hole , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data);

		  if (is_it_MSGI)
		    MSGI_part::Up_hole_double_counting_pp_part_remove (true , false , NADA , shell_prot_res , shell_prot_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_HF_data);
		}
	    }
	}
    }

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class nlj_struct &shell_prot_qn = shells_prot_qn(sp_HF);

      const bool is_it_HO = shell_prot_qn.get_is_it_HO ();
      
      const bool S_matrix_pole = shell_prot_qn.get_S_matrix_pole ();
      
      const bool no_HO = (!is_it_HO) && (!HO_diag);

      const class spherical_state &shell_prot_HF = shells_prot(sp_HF);
      
      if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	{
	  if ((S_matrix_pole || no_HO) && shell_prot_HF.is_it_filled ())
	    {
	      for (unsigned int sp = 0 ; sp < Np_nlj_res ; sp++)
		{
		  const class nlj_struct &shell_prot_qn_possible_hole = shells_prot_res_qn(sp);

		  const bool hole_state_p = shell_prot_qn_possible_hole.get_hole_state ();

		  if (hole_state_p)
		    {
		      const class spherical_state &shell_prot_hole = shells_prot_res(sp);

		      if (is_it_SGI)
			SGI_part::Up_hole_double_counting_pp_part_remove (false , false , NADA , sp , shell_prot_HF , shell_prot_hole , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data);

		      if (is_it_MSGI)
			MSGI_part::Up_hole_double_counting_pp_part_remove (false , false , NADA , shell_prot_HF , shell_prot_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_HF_data);
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_hole_double_counting_pn_part_remove (
														const bool HO_diag , 
														const class array<double> &Gaussian_table_GL , 
														const class multipolar_expansion_str &multipolar_expansion , 
														const class interaction_class &inter_data_basis , 
														const class SGI_radial_tabs_str &neut_radial_tabs , 
														const class HF_nucleons_data &neut_HF_data , 
														class HF_nucleons_data &prot_HF_data)
{ 
  const unsigned int Np_nlj = prot_HF_data.get_N_nlj ();

  const unsigned int Np_nlj_res = prot_HF_data.get_N_nlj_res ();
  const unsigned int Nn_nlj_res = neut_HF_data.get_N_nlj_res ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_prot = prot_HF_data.get_shells ();

  const class array<class spherical_state> &shells_prot_res = prot_HF_data.get_shells_res ();
  const class array<class spherical_state> &shells_neut_res = neut_HF_data.get_shells_res ();

  const class array<class nlj_struct> &shells_prot_qn = prot_HF_data.get_shells_quantum_numbers ();

  const class array<class nlj_struct> &shells_neut_res_qn = neut_HF_data.get_shells_quantum_numbers_res ();

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj_res ; sp_HF++)
    {
      const class spherical_state &shell_prot_res = shells_prot_res(sp_HF);
      
      if (shell_prot_res.is_it_filled ())
	{
	  for (unsigned int sn = 0 ; sn < Nn_nlj_res ; sn++)
	    {
	      const class nlj_struct &shell_neut_qn_possible_hole = shells_neut_res_qn(sn);

	      const bool hole_state_n = shell_neut_qn_possible_hole.get_hole_state ();

	      if (hole_state_n)
		{
		  const class spherical_state &shell_neut_hole = shells_neut_res(sn);
					
		  if (is_it_SGI)
		    SGI_part::Up_hole_double_counting_pn_part_remove (true , false , NADA , sn , shell_prot_res , shell_neut_hole , multipolar_expansion , inter_data_basis , neut_radial_tabs , prot_HF_data);

		  if (is_it_MSGI)
		    MSGI_part::Up_hole_double_counting_pn_part_remove (true , false , NADA , shell_prot_res , shell_neut_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_HF_data);
		}
	    }
	}
    }

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class nlj_struct &shell_prot_qn = shells_prot_qn(sp_HF);
      
      const bool is_it_HO = shell_prot_qn.get_is_it_HO ();

      const bool S_matrix_pole = shell_prot_qn.get_S_matrix_pole ();

      const bool no_HO = (!is_it_HO) && (!HO_diag);

      const class spherical_state &shell_prot_HF = shells_prot(sp_HF);
      
      if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	{
	  if ((S_matrix_pole || no_HO) && shell_prot_HF.is_it_filled ())
	    {
	      for (unsigned int sn = 0 ; sn < Nn_nlj_res ; sn++)
		{
		  const class nlj_struct &shell_neut_qn_possible_hole = shells_neut_res_qn(sn);

		  const bool hole_state_n = shell_neut_qn_possible_hole.get_hole_state ();

		  if (hole_state_n)
		    {
		      const class spherical_state &shell_neut_hole = shells_neut_res(sn);

		      if (is_it_SGI)
			SGI_part::Up_hole_double_counting_pn_part_remove (false , false , NADA , sn , shell_prot_HF , shell_neut_hole , multipolar_expansion , inter_data_basis , neut_radial_tabs , prot_HF_data);

		      if (is_it_MSGI)
			MSGI_part::Up_hole_double_counting_pn_part_remove (false , false , NADA , shell_prot_HF , shell_neut_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_HF_data);
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_hole_double_counting_nn_part_remove (
														const bool HO_diag , 
														const class array<double> &Gaussian_table_GL , 
														const class multipolar_expansion_str &multipolar_expansion , 
														const class interaction_class &inter_data_basis , 
														const class SGI_radial_tabs_str &neut_radial_tabs , 
														class HF_nucleons_data &neut_HF_data)
{
  const unsigned int Nn_nlj     = neut_HF_data.get_N_nlj ();
  const unsigned int Nn_nlj_res = neut_HF_data.get_N_nlj_res ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);
  
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_neut     = neut_HF_data.get_shells ();
  const class array<class spherical_state> &shells_neut_res = neut_HF_data.get_shells_res ();

  const class array<class nlj_struct> &shells_neut_qn     = neut_HF_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_neut_res_qn = neut_HF_data.get_shells_quantum_numbers_res ();

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj_res ; sn_HF++)
    {
      const class spherical_state &shell_neut_res = shells_neut_res(sn_HF);
      
      if (shell_neut_res.is_it_filled ())
	{
	  for (unsigned int sn = 0 ; sn < Nn_nlj_res ; sn++)
	    {
	      const class nlj_struct &shell_neut_qn_possible_hole = shells_neut_res_qn(sn);
	      
	      const bool hole_state_n = shell_neut_qn_possible_hole.get_hole_state ();

	      if (hole_state_n)
		{
		  const class spherical_state &shell_neut_hole = shells_neut_res(sn);

		  if (is_it_SGI)
		    SGI_part::Un_hole_double_counting_nn_part_remove (true , false , NADA , sn , shell_neut_res , shell_neut_hole , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data);

		  if (is_it_MSGI)
		    MSGI_part::Un_hole_double_counting_nn_part_remove (true , false , NADA , shell_neut_res , shell_neut_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_HF_data);
		}
	    }
	}
    }

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class nlj_struct &shell_neut_qn = shells_neut_qn(sn_HF);

      const bool is_it_HO = shell_neut_qn.get_is_it_HO ();

      const bool S_matrix_pole = shell_neut_qn.get_S_matrix_pole ();

      const bool no_HO = (!is_it_HO) && (!HO_diag);

      const class spherical_state &shell_neut_HF = shells_neut(sn_HF);
      
      if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	{
	  if ((S_matrix_pole || no_HO) && shell_neut_HF.is_it_filled ())
	    {
	      for (unsigned int sn = 0 ; sn < Nn_nlj_res ; sn++)
		{
		  const class nlj_struct &shell_neut_qn_possible_hole = shells_neut_res_qn(sn);

		  const bool hole_state_n = shell_neut_qn_possible_hole.get_hole_state ();

		  if (hole_state_n)
		    {
		      const class spherical_state &shell_neut_hole = shells_neut_res(sn);

		      if (is_it_SGI)
			SGI_part::Un_hole_double_counting_nn_part_remove (false , false , NADA , sn , shell_neut_HF , shell_neut_hole , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data);

		      if (is_it_MSGI)
			MSGI_part::Un_hole_double_counting_nn_part_remove (false , false , NADA , shell_neut_HF , shell_neut_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_HF_data);
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_hole_double_counting_pn_part_remove (
														const bool HO_diag , 
														const class array<double> &Gaussian_table_GL , 
														const class multipolar_expansion_str &multipolar_expansion , 
														const class interaction_class &inter_data_basis , 
														const class SGI_radial_tabs_str &prot_radial_tabs , 
														const class HF_nucleons_data &prot_HF_data , 
														class HF_nucleons_data &neut_HF_data)
{
  const unsigned int Nn_nlj = neut_HF_data.get_N_nlj ();
  
  const unsigned int Nn_nlj_res = neut_HF_data.get_N_nlj_res ();
  const unsigned int Np_nlj_res = prot_HF_data.get_N_nlj_res ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_prot_res = prot_HF_data.get_shells_res ();
  const class array<class spherical_state> &shells_neut_res = neut_HF_data.get_shells_res ();
  
  const class array<class spherical_state> &shells_neut = neut_HF_data.get_shells ();

  const class array<class nlj_struct> &shells_prot_res_qn = prot_HF_data.get_shells_quantum_numbers_res ();
  
  const class array<class nlj_struct> &shells_neut_qn = neut_HF_data.get_shells_quantum_numbers ();
  
  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj_res ; sn_HF++)
    {
      const class spherical_state &shell_neut_res = shells_neut_res(sn_HF);
      
      if (shell_neut_res.is_it_filled ())
	{
	  for (unsigned int sp = 0 ; sp < Np_nlj_res ; sp++)
	    {
	      const class nlj_struct &shell_prot_qn_possible_hole = shells_prot_res_qn(sp);

	      const bool hole_state_p = shell_prot_qn_possible_hole.get_hole_state ();

	      if (hole_state_p)
		{
		  const class spherical_state &shell_prot_hole = shells_prot_res(sp);

		  if (is_it_SGI)
		    SGI_part::Un_hole_double_counting_pn_part_remove (true , false , NADA , sp , shell_neut_res , shell_prot_hole , multipolar_expansion , inter_data_basis , prot_radial_tabs , neut_HF_data);

		  if (is_it_MSGI)
		    MSGI_part::Un_hole_double_counting_pn_part_remove (true , false , NADA , shell_neut_res , shell_prot_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_HF_data);
		}
	    }
	}
    }

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class nlj_struct &shell_neut_qn = shells_neut_qn(sn_HF);

      const bool is_it_HO = shell_neut_qn.get_is_it_HO ();

      const bool S_matrix_pole = shell_neut_qn.get_S_matrix_pole ();

      const bool no_HO = (!is_it_HO) && (!HO_diag);

      const class spherical_state &shell_neut_HF = shells_neut(sn_HF);
      
      if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	{
	  if ((S_matrix_pole || no_HO) && shell_neut_HF.is_it_filled ())
	    {
	      for (unsigned int sp = 0 ; sp < Np_nlj_res ; sp++)
		{
		  const class nlj_struct &shell_prot_qn_possible_hole = shells_prot_res_qn(sp);

		  const bool hole_state_p = shell_prot_qn_possible_hole.get_hole_state ();

		  if (hole_state_p)
		    {
		      const class spherical_state &shell_prot_hole = shells_prot_res(sp);

		      if (is_it_SGI)
			SGI_part::Un_hole_double_counting_pn_part_remove (false , false , NADA , sp , shell_neut_HF , shell_prot_hole , multipolar_expansion , inter_data_basis , prot_radial_tabs , neut_HF_data);

		      if (is_it_MSGI)
			MSGI_part::Un_hole_double_counting_pn_part_remove (false , false , NADA , shell_neut_HF , shell_prot_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_HF_data);
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_hole_double_counting_pp_part_shells_pm_remove (
															  const int pm , 
															  const class array<double> &Gaussian_table_GL , 
															  const class multipolar_expansion_str &multipolar_expansion , 
															  const class interaction_class &inter_data_basis , 
															  const class SGI_radial_tabs_str &prot_radial_tabs , 
															  class HF_nucleons_data &prot_HF_data)
{
  const unsigned int Np_nlj     = prot_HF_data.get_N_nlj ();
  const unsigned int Np_nlj_res = prot_HF_data.get_N_nlj_res ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);
  
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_prot_pm = (pm == 1) ? (prot_HF_data.get_shells_plus ()) : (prot_HF_data.get_shells_minus ());

  const class array<class spherical_state> &shells_prot_res = prot_HF_data.get_shells_res ();

  const class array<class nlj_struct> &shells_prot_res_qn = prot_HF_data.get_shells_quantum_numbers_res ();

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class spherical_state &shell_prot_pm = shells_prot_pm(sp_HF);
      
      if (shell_prot_pm.is_it_filled ())
	{
	  if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	    {
	      for (unsigned int sp = 0 ; sp < Np_nlj_res ; sp++)
		{
		  const class nlj_struct &shell_prot_qn_possible_hole = shells_prot_res_qn(sp);

		  const bool hole_state_p = shell_prot_qn_possible_hole.get_hole_state ();

		  if (hole_state_p)
		    {
		      const class spherical_state &shell_prot_hole = shells_prot_res(sp);

		      if (is_it_SGI)
			SGI_part::Up_hole_double_counting_pp_part_remove (false , true , pm , sp , shell_prot_pm , shell_prot_hole , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data);

		      if (is_it_MSGI)
			MSGI_part::Up_hole_double_counting_pp_part_remove (false , true , pm , shell_prot_pm , shell_prot_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_HF_data);
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_hole_double_counting_pn_part_shells_pm_remove (
															  const int pm , 
															  const class array<double> &Gaussian_table_GL , 
															  const class multipolar_expansion_str &multipolar_expansion , 
															  const class interaction_class &inter_data_basis , 
															  const class SGI_radial_tabs_str &neut_radial_tabs , 
															  const class HF_nucleons_data &neut_HF_data , 
															  class HF_nucleons_data &prot_HF_data)
{ 
  const unsigned int Np_nlj     = prot_HF_data.get_N_nlj ();
  const unsigned int Nn_nlj_res = neut_HF_data.get_N_nlj_res ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);
  
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_prot_pm = (pm == 1) ? (prot_HF_data.get_shells_plus ()) : (prot_HF_data.get_shells_minus ());

  const class array<class spherical_state> &shells_neut_res = neut_HF_data.get_shells_res ();

  const class array<class nlj_struct> &shells_neut_res_qn = neut_HF_data.get_shells_quantum_numbers_res ();

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class spherical_state &shell_prot_pm = shells_prot_pm(sp_HF);
      
      if (shell_prot_pm.is_it_filled ())
	{
	  if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	    {
	      for (unsigned int sn = 0 ; sn < Nn_nlj_res ; sn++)
		{
		  const class nlj_struct &shell_neut_qn_possible_hole = shells_neut_res_qn(sn);

		  const bool hole_state_n = shell_neut_qn_possible_hole.get_hole_state ();

		  if (hole_state_n)
		    {
		      const class spherical_state &shell_neut_hole = shells_neut_res(sn);

		      if (is_it_SGI)
			SGI_part::Up_hole_double_counting_pn_part_remove (false , true , pm , sn , shell_prot_pm , shell_neut_hole , multipolar_expansion , inter_data_basis , neut_radial_tabs , prot_HF_data);

		      if (is_it_MSGI)
			MSGI_part::Up_hole_double_counting_pn_part_remove (false , true , pm , shell_prot_pm , shell_neut_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_HF_data);
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_hole_double_counting_nn_part_shells_pm_remove (
															  const int pm , 
															  const class array<double> &Gaussian_table_GL , 
															  const class multipolar_expansion_str &multipolar_expansion , 
															  const class interaction_class &inter_data_basis , 
															  const class SGI_radial_tabs_str &neut_radial_tabs , 
															  class HF_nucleons_data &neut_HF_data)
{ 
  const unsigned int Nn_nlj     = neut_HF_data.get_N_nlj ();
  const unsigned int Nn_nlj_res = neut_HF_data.get_N_nlj_res ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_neut_pm = (pm == 1) ? (neut_HF_data.get_shells_plus ()) : (neut_HF_data.get_shells_minus ());

  const class array<class spherical_state> &shells_neut_res = neut_HF_data.get_shells_res ();

  const class array<class nlj_struct> &shells_neut_res_qn = neut_HF_data.get_shells_quantum_numbers_res ();

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class spherical_state &shell_neut_pm = shells_neut_pm(sn_HF);
      
      if (shell_neut_pm.is_it_filled ())
	{
	  if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	    {
	      for (unsigned int sn = 0 ; sn < Nn_nlj_res ; sn++)
		{
		  const class nlj_struct &shell_neut_qn_possible_hole = shells_neut_res_qn(sn);

		  const bool hole_state_n = shell_neut_qn_possible_hole.get_hole_state ();

		  if (hole_state_n)
		    {
		      const class spherical_state &shell_neut_hole = shells_neut_res(sn);

		      if (is_it_SGI)
			SGI_part::Un_hole_double_counting_nn_part_remove (false , true , pm , sn , shell_neut_pm , shell_neut_hole , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data);

		      if (is_it_MSGI)
			MSGI_part::Un_hole_double_counting_nn_part_remove (false , true , pm , shell_neut_pm , shell_neut_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_HF_data);
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_hole_double_counting_pn_part_shells_pm_remove (
															  const int pm , 
															  const class array<double> &Gaussian_table_GL , 
															  const class multipolar_expansion_str &multipolar_expansion , 
															  const class interaction_class &inter_data_basis , 
															  const class SGI_radial_tabs_str &prot_radial_tabs , 
															  const class HF_nucleons_data &prot_HF_data , 
															  class HF_nucleons_data &neut_HF_data)
{
  const unsigned int Nn_nlj = neut_HF_data.get_N_nlj ();
  
  const unsigned int Np_nlj_res = prot_HF_data.get_N_nlj_res ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_neut_pm = (pm == 1) ? (neut_HF_data.get_shells_plus ()) : (neut_HF_data.get_shells_minus ());

  const class array<class spherical_state> &shells_prot_res = prot_HF_data.get_shells_res ();

  const class array<class nlj_struct> &shells_prot_res_qn = prot_HF_data.get_shells_quantum_numbers_res ();

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class spherical_state &shell_neut_pm = shells_neut_pm(sn_HF);
      
      if (shell_neut_pm.is_it_filled ())
	{
	  if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	    {
	      for (unsigned int sp = 0 ; sp < Np_nlj_res ; sp++)
		{
		  const class nlj_struct &shell_prot_qn_possible_hole = shells_prot_res_qn(sp);

		  const bool hole_state_p = shell_prot_qn_possible_hole.get_hole_state ();

		  if (hole_state_p)
		    {
		      const class spherical_state &shell_prot_hole = shells_prot_res(sp);

		      if (is_it_SGI)
			SGI_part::Un_hole_double_counting_pn_part_remove (false , true , pm , sp , shell_neut_pm , shell_prot_hole , multipolar_expansion , inter_data_basis , prot_radial_tabs , neut_HF_data);

		      if (is_it_MSGI)
			MSGI_part::Un_hole_double_counting_pn_part_remove (false , true , pm , shell_neut_pm , shell_prot_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_HF_data);
		    }
		}
	    }
	}
    }
}








// Calculation of the all HF equivalent potentials and sources
// -----------------------------------------------------------
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) writes, for MSGI, along with its source:
//
// U_HF(dir)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . F_Gaussian(r) . \int u_occ^2(r') F_Gaussian(r') dr'
// U_HF(exc)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' . F(r)
//
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) writes, for SGI, along with its source:
//
// U_HF(dir)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . Vl'_SGI(r , 2R0-r) . u_occ^2(2R0-r)
// U_HF(exc)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ, l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) . F(r)
//
// where weight is function of Clebsch-Gordan coefficients and of the SD components of the GSM ground state on the optimized configuration,
// coupling_constant(Pi,J) is the Pi-J-dependent coupling constant of the MSGI interaction, 
// F_Gaussian(r) is the Gaussian form factor entering the MSGI interaction (see GSM_TBME_MSGI.cpp) and
// Vl'_SGI(r) is the multipolar expansion of the SGI interaction (see GSM_interaction_class.cpp) and R0 is the radius of the SGI/MSGI interaction.
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
// Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
// The ratio |u(r)|^2/|u'(r)|^2) prevents F(r) to be non zero when r -> +oo.
// Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// One sums over all Vpp, Vnn or Vpn interaction two-body matrix elements, according to the number of valence protons and neutrons. 
// HF equivalent potentials and sources are then splined to be calculated on the [0:R] radial grid with Gauss-Legendre and uniformly spaced radii, with R the cimplex scaling rotation point,
// as they are initially calculated in the [0:2.R0] radial grid, with R0 the radius of the SGI/MSGI interaction.

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_calc (
										 const bool HO_diag , 
										 const class CG_str &CGs , 
										 const class array<double> &Gaussian_table_GL , 
										 const class multipolar_expansion_str &multipolar_expansion , 
										 const class interaction_class &inter_data_basis , 
										 const class SGI_radial_tabs_str &prot_radial_tabs , 
										 const class SGI_radial_tabs_str &neut_radial_tabs , 
										 const class nucleons_data &prot_data_one_configuration_GSM , 
										 const class nucleons_data &neut_data_one_configuration_GSM , 
										 const class HF_nucleons_data &neut_HF_data , 
										 class HF_nucleons_data &prot_HF_data)
{
  const enum particle_type particle = prot_HF_data.get_particle ();
  
  if (particle != PROTON) abort_all ();

  const unsigned int Np_nlj = prot_HF_data.get_N_nlj ();

  if (Np_nlj == 0) return;

  const int Zval = prot_data_one_configuration_GSM.get_N_valence_nucleons_basis ();
  const int Nval = neut_data_one_configuration_GSM.get_N_valence_nucleons_basis ();

  if (Zval >= 2) 
    {
      prot_trivially_equivalent_potentials_pp_part_calc (HO_diag , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_data_one_configuration_GSM , prot_HF_data);

      prot_trivially_equivalent_potentials_hole_double_counting_pp_part_remove (HO_diag , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data);
    }

  if ((Zval >= 1) && (Nval >= 1)) 
    {
      prot_trivially_equivalent_potentials_pn_part_calc (HO_diag , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_radial_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , prot_HF_data);

      prot_trivially_equivalent_potentials_hole_double_counting_pn_part_remove (HO_diag , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data , prot_HF_data);
    }

  trivially_equivalent_potentials_splines_calc (HO_diag , prot_HF_data);
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_calc (
										 const bool HO_diag , 
										 const class CG_str &CGs , 
										 const class array<double> &Gaussian_table_GL , 
										 const class multipolar_expansion_str &multipolar_expansion , 
										 const class interaction_class &inter_data_basis , 
										 const class SGI_radial_tabs_str &prot_radial_tabs , 
										 const class SGI_radial_tabs_str &neut_radial_tabs , 
										 const class nucleons_data &prot_data_one_configuration_GSM , 
										 const class nucleons_data &neut_data_one_configuration_GSM , 
										 const class HF_nucleons_data &prot_HF_data , 
										 class HF_nucleons_data &neut_HF_data)
{
  const enum particle_type particle = neut_HF_data.get_particle ();

  if (particle != NEUTRON) abort_all ();

  const unsigned int Nn_nlj = neut_HF_data.get_N_nlj ();

  if (Nn_nlj == 0) return;

  const int Zval = prot_data_one_configuration_GSM.get_N_valence_nucleons_basis () , Nval = neut_data_one_configuration_GSM.get_N_valence_nucleons_basis ();

  if (Nval >= 2) 
    {
      neut_trivially_equivalent_potentials_nn_part_calc (HO_diag , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_data_one_configuration_GSM , neut_HF_data);

      neut_trivially_equivalent_potentials_hole_double_counting_nn_part_remove (HO_diag , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data);
    }

  if ((Zval >= 1) && (Nval >= 1)) 
    {
      neut_trivially_equivalent_potentials_pn_part_calc (HO_diag , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , neut_HF_data);

      neut_trivially_equivalent_potentials_hole_double_counting_pn_part_remove (HO_diag , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data , neut_HF_data);
    }

  trivially_equivalent_potentials_splines_calc (HO_diag , neut_HF_data);
}

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_shells_pm_calc (
											   const int pm , 
											   const class CG_str &CGs , 
											   const class array<double> &Gaussian_table_GL , 
											   const class multipolar_expansion_str &multipolar_expansion , 
											   const class interaction_class &inter_data_basis , 
											   const class SGI_radial_tabs_str &prot_radial_tabs , 
											   const class SGI_radial_tabs_str &neut_radial_tabs , 
											   const class nucleons_data &prot_data_one_configuration_GSM , 
											   const class nucleons_data &neut_data_one_configuration_GSM , 
											   const class HF_nucleons_data &neut_HF_data , 
											   class HF_nucleons_data &prot_HF_data)
{
  const enum particle_type particle = prot_HF_data.get_particle ();

  if (particle != PROTON) return;

  const unsigned int Np_nlj = prot_HF_data.get_N_nlj ();

  if (Np_nlj == 0) return;

  const int Zval = prot_data_one_configuration_GSM.get_N_valence_nucleons_basis ();
  const int Nval = neut_data_one_configuration_GSM.get_N_valence_nucleons_basis ();

  if (Zval >= 2) 
    {
      prot_trivially_equivalent_potentials_pp_part_shells_pm_calc (pm , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_data_one_configuration_GSM , prot_HF_data);

      prot_trivially_equivalent_potentials_hole_double_counting_pp_part_shells_pm_remove (pm , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data);
    }

  if ((Zval >= 1) && (Nval >= 1)) 
    {
      prot_trivially_equivalent_potentials_pn_part_shells_pm_calc (pm , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_radial_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , prot_HF_data);

      prot_trivially_equivalent_potentials_hole_double_counting_pn_part_shells_pm_remove (pm , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data , prot_HF_data);
    }

  trivially_equivalent_potentials_splines_pm_calc (pm , prot_HF_data);
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_shells_pm_calc (
											   const int pm , 
											   const class CG_str &CGs , 
											   const class array<double> &Gaussian_table_GL , 
											   const class multipolar_expansion_str &multipolar_expansion , 
											   const class interaction_class &inter_data_basis , 
											   const class SGI_radial_tabs_str &prot_radial_tabs , 
											   const class SGI_radial_tabs_str &neut_radial_tabs , 
											   const class nucleons_data &prot_data_one_configuration_GSM , 
											   const class nucleons_data &neut_data_one_configuration_GSM , 
											   const class HF_nucleons_data &prot_HF_data , 
											   class HF_nucleons_data &neut_HF_data)
{
  const enum particle_type particle = neut_HF_data.get_particle ();

  if (particle != NEUTRON) return;

  const unsigned int Nn_nlj = neut_HF_data.get_N_nlj ();

  if (Nn_nlj == 0) return;

  const int Zval = prot_data_one_configuration_GSM.get_N_valence_nucleons_basis ();
  const int Nval = neut_data_one_configuration_GSM.get_N_valence_nucleons_basis ();

  if (Nval >= 2) 
    {
      neut_trivially_equivalent_potentials_nn_part_shells_pm_calc (pm , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_data_one_configuration_GSM , neut_HF_data);

      neut_trivially_equivalent_potentials_hole_double_counting_nn_part_shells_pm_remove (pm , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data);
    } 

  if ((Zval >= 1) && (Nval >= 1)) 
    {
      neut_trivially_equivalent_potentials_pn_part_shells_pm_calc (pm , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , neut_HF_data);

      neut_trivially_equivalent_potentials_hole_double_counting_pn_part_shells_pm_remove (pm , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data , neut_HF_data);
    }

  trivially_equivalent_potentials_splines_pm_calc (pm , neut_HF_data);
}

