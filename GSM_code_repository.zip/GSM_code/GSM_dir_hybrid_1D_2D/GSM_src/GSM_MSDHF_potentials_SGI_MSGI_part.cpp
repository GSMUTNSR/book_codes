#include "../GSM_include/GSM_include_def.h"

using namespace HF_potentials_common::SGI_MSGI_part_common;






// TYPE is double or complex
// -------------------------

// Calculation of the direct and exchange parts of the MSDHF potential
// -------------------------------------------------------------------
// One has:
// <wf_out | U[MSDHF] | wf_in> = <wf_out | U[core] | wf_in>
// -  (\sum_{occ J'} hat(J') <wf_out occ | V | wf_in occ>_{J'} <Psi[GS] | [[a+_{n l j} a+_{occ}]^{J'} [a~_{k l j} a~_{occ} ]^{J'}]^0_0 | Psi[k]>)
//  / (<Psi[GS] | [a+_{n l j} a~_{k l j}]^0_0 | Psi[k]>)
//
// The one-body part issued from the core, i.e. <wf_out | U[core] | wf_in>, is not considered here.
// The normalizing factor <Psi[GS] | [a+_{n l j} a~_{k l j}]^0_0 | Psi[k]> has already been calculated (see U_HF_normalizing_sums_calc).
// As <wf_out | U[MSDHF] | wf_in> matrices are symmetric, one considers firstly wf_out <= wf_in, and the rest of the matrix is filled by symmetry at the end of the calculation.
// As <Psi[GS] | [[a+_{occ} a+_{n l j}]^{J'} [a~_{occ} a~_{k l j}]^{J'}]^0_0 | Psi[k]> is independent of wf_out and wf_in, it is calculated only once for all wf_out and wf_in.
//
//
// Firstly, one writes -hat(J') <Psi[GS] | [[a+_{n l j} a+_{occ}]^{J'} [a~_{k l j} a~_{occ} ]^{J'}]^0_0 | Psi[k]>
// \propto \sum_{m's}   <j m j[occ] m[occ] | J' M> <j m' j[occ] m[occ]' | J' M> (-1)^(j + j[occ] - J)
//                    x <Psi[GS] | a+_{n l j m} a+_{occ m[occ]} a_{occ m[occ]'} a_{k l j m'} | Psi[k]> (see GSM_MSDHF_potentials.cpp)
//
// As |Psi[k]> = [a+_{k l j} a~_{n l j}]^0_0 |Psi[GS]>, |Psi[GS]> \propto \sum_{m} a+_{k l j m} a_{n l j m} | Psi[GS]> => a_{k l j m} |Psi[k]> \propto a_{n l j m} | Psi[GS]>.
// |Psi[GS]> and a_{k l j m} |Psi[k]> have been expanded with Slater determinants.
// |Psi[GS]> = \sum_{i} c[i] |SDi[GS]> and a_{k l j m} |Psi[k]> = \sum_{j} d[j] |SDj[k]>, where the |k l j m> state is not present in |SDj[k]>, and d[j] depends on m.
//
// Thus:
// \sum_{m's}   <j m j[occ] m[occ] | J' M> <j m' j[occ] m[occ]' | J' M> (-1)^(j + j[occ] - J)
//            x <Psi[GS] | a+_{n l j m} a+_{occ m[occ]}  a_{occ m[occ]'} a_{k l j m'} | Psi[k]>
// = \sum_{ij, m's}    c[i] d[j] <j m j[occ] m[occ] | J' M> <j m' j[occ] m[occ]' | J' M> (-1)^(j + j[occ] - J)
//                  x <SDi[GS] | a+_{n l j m} a+_{occ m[occ]} a_{occ m[occ]'} | SDj[k]>
//
// where a_{k l j m'} | Psi[k]> has been expanded in terms of |SDj[k]> basis states, and d[j] depends on m'.
//
//
// Thus:
//
// The equivalent MSDHF potential U_MSDHF = U_MSDHF(direct) - U_MSDHF(exchange) writes, for MSGI, along with its source:
//
// U_MSDHF(dir)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . F_Gaussian(r) . \int u_occ^2(r') F_Gaussian(r') dr'
// U_MSDHF(exc)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' . F(r)
//
// The equivalent MSDHF potential U_MSDHF = U_MSDHF(direct) - U_MSDHF(exchange) writes, for SGI, along with its source:
//
// U_MSDHF(dir)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . Vl'_SGI(r , 2R0-r) . u_occ^2(2R0-r)
// U_MSDHF(exc)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ, l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) . F(r)
//
// where weight is function of Clebsch-Gordan coefficients and of the SD components of the GSM ground state on the optimized configuration,
// obtained from the decoupling of tensor operators in the MSDHF potential (see above).
// coupling_constant(Pi,J) is the Pi-J-dependent coupling constant of the SGI/MSGI interaction, 
// F_Gaussian(r) is the Gaussian form factor entering the MSGI interaction (see GSM_TBME_MSGI.cpp) and
// Vl'_SGI(r) is the multipolar expansion of the SGI interaction (see GSM_interaction_class.cpp) and R0 is the radius of the SGI/MSGI interaction.
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
// Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
// The ratio |u(r)|^2/|u'(r)|^2) prevents F(r) to be non zero when r -> +oo.
// Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// This routine loops over all proton and neutron states and occupied states and calls routines of the namespaces SGI_part_common and MSGI_part_common.


void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potential_pp_part_calc (
											const bool is_it_res , 
											const bool is_it_pm , 
											const int pm , 
											const class CG_str &CGs , 
											const class array<double> &Gaussian_table_GL , 
											const class multipolar_expansion_str &multipolar_expansion , 
											const class interaction_class &inter_data_basis , 
											const class SGI_radial_tabs_str &radial_p_tabs , 
											const class baryons_data &prot_data_one_configuration_GSM , 
											const class spherical_state &shell_p_HF , 
											class HF_nucleons_data &prot_Y_HF_data)
{
  const int ZYval = prot_data_one_configuration_GSM.get_N_valence_nucleons_basis ();

  const int ZYval_m1 = ZYval - 1;
  
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_p = prot_data_one_configuration_GSM.get_shells ();

  const class array<class nljm_struct> &phi_p_table = prot_data_one_configuration_GSM.get_phi_table ();

  const class lj_table<unsigned int> &dimensions_GS = prot_Y_HF_data.get_dimensions_GS ();

  const class lj_table<complex<double> > &Up_HF_normalizing_sums = prot_Y_HF_data.get_U_HF_normalizing_sums ();

  const class lj_table<class array<class Slater_determinant> > &SDp_tab_GS = prot_Y_HF_data.get_SDp_tab_GS ();
  const class lj_table<class array<class Slater_determinant> > &SDn_tab_GS = prot_Y_HF_data.get_SDn_tab_GS ();
  const class lj_table<class array<class Slater_determinant> > &SDp_tab_1h = prot_Y_HF_data.get_SDs_1h ();

  const class lj_table<class array<complex<double> > > &SDs_GS_coefficients = prot_Y_HF_data.get_SDs_GS_coefficients ();
  const class lj_table<class array<complex<double> > > &SDs_1h_coefficients = prot_Y_HF_data.get_SDs_1h_coefficients ();

  const class lj_table<class array<bool> > &SDp_tab_1h_existence_tab = prot_Y_HF_data.get_SDs_1h_existence_tab();

  const double jp = shell_p_HF.get_j ();

  const int lp = shell_p_HF.get_l ();

  const int imp_number = make_int (2.0*jp + 1.0);

  const unsigned int dimension_GS = dimensions_GS(lp , jp);

  const complex<double> Up_HF_normalizing_sum = Up_HF_normalizing_sums(lp , jp);

  const class array<class Slater_determinant> &SDp_tab_GS_lj = SDp_tab_GS(lp , jp);
  const class array<class Slater_determinant> &SDn_tab_GS_lj = SDn_tab_GS(lp , jp);
  const class array<class Slater_determinant> &SDp_tab_1h_lj = SDp_tab_1h(lp , jp);

  const class array<complex<double> > &SDs_GS_coefficients_lj = SDs_GS_coefficients(lp , jp);
  const class array<complex<double> > &SDs_1h_coefficients_lj = SDs_1h_coefficients(lp , jp);

  const class array<bool> &SDp_tab_1h_existence_tab_lj = SDp_tab_1h_existence_tab(lp , jp);

  unsigned int p_jump_states_number_GS_in  = 0;
  unsigned int p_jump_states_number_1h_out = 0;

  class array<unsigned int> p_jump_states_GS_in(ZYval);
  class array<unsigned int> p_jump_states_1h_out(ZYval_m1); 

  for (unsigned int i_GS_in = 0 ; i_GS_in < dimension_GS ; i_GS_in++)
    {
      const complex<double> SD_GS_coefficient_in = SDs_GS_coefficients_lj(i_GS_in);
      
      if (SD_GS_coefficient_in == 0.0) continue;

      const class Slater_determinant &SDp_lj_GS_in = SDp_tab_GS_lj(i_GS_in);
      const class Slater_determinant &SDn_lj_GS_in = SDn_tab_GS_lj(i_GS_in);

      for (unsigned int i_GS_out = 0 ; i_GS_out < dimension_GS ; i_GS_out++)
	{
	  const class Slater_determinant &SDn_lj_GS_out = SDn_tab_GS_lj(i_GS_out);

	  if (SDn_lj_GS_in == SDn_lj_GS_out)
	    {
	      for (int imp_out = 0 ; imp_out < imp_number ; imp_out++)
		{
		  const bool SDp_lj_1h_out_exists = SDp_tab_1h_existence_tab_lj(i_GS_out , imp_out);

		  if (!SDp_lj_1h_out_exists) continue;

		  const complex<double> SD_GS_coefficient_in  = SDs_GS_coefficients_lj(i_GS_in);
		  const complex<double> SD_1h_coefficient_out = SDs_1h_coefficients_lj(i_GS_out , imp_out);

		  if ((SD_GS_coefficient_in == 0.0) || (SD_1h_coefficient_out == 0.0)) continue;

		  const class Slater_determinant &SDp_lj_1h_out = SDp_tab_1h_lj(i_GS_out , imp_out);

		  SDp_lj_GS_in.different_states_determine (SDp_lj_1h_out , p_jump_states_number_GS_in , p_jump_states_GS_in);

		  if (p_jump_states_number_GS_in == 1)
		    {
		      const unsigned int p_jump_state = p_jump_states_GS_in(0);

		      const unsigned int p_jump_state_place = SDp_lj_GS_in.state_place_find (p_jump_state);

		      const int reordering_phase_p = minus_one_pow (p_jump_state_place + ZYval_m1);

		      const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase_p/Up_HF_normalizing_sum;

		      for (int p_occ = 0 ; p_occ < ZYval_m1 ; p_occ++)
			{
			  const unsigned int state_p_occ = SDp_lj_1h_out[p_occ];

			  const class nljm_struct &phi_p_occ = phi_p_table(state_p_occ);
			
			  const unsigned int sp_occ = phi_p_occ.get_shell_index ();

			  const class spherical_state &shell_p_occ = shells_p(sp_occ);

			  const double mp_occ = phi_p_occ.get_m ();

			  const double mp_out = imp_out - jp;

			  if (is_it_SGI)
			    SGI_part::Up_pp_part_calc (is_it_res , is_it_pm , pm , sp_occ , shell_p_HF , shell_p_occ , mp_out , mp_out , mp_occ , mp_occ ,
						       SDs_weight , CGs , multipolar_expansion , inter_data_basis , radial_p_tabs , prot_Y_HF_data);
			
			  if (is_it_MSGI)
			    MSGI_part::Up_pp_part_calc (is_it_res , is_it_pm , pm , shell_p_HF , shell_p_occ , mp_out , mp_out , mp_occ , mp_occ ,
							SDs_weight , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_Y_HF_data);
			}
		    }
		  else if (p_jump_states_number_GS_in == 2)
		    {
		      SDp_lj_1h_out.different_states_determine (SDp_lj_GS_in , p_jump_states_number_1h_out , p_jump_states_1h_out);
		    
		      const unsigned int sa_GS = p_jump_states_GS_in(1);
		      const unsigned int sc_GS = p_jump_states_GS_in(0);
		      const unsigned int sd_1h = p_jump_states_1h_out(0);

		      const unsigned int sa_GS_place = SDp_lj_GS_in.state_place_find (sa_GS);
		      const unsigned int sc_GS_place = SDp_lj_GS_in.state_place_find (sc_GS);
		      const unsigned int sd_1h_place = SDp_lj_1h_out.state_place_find (sd_1h);

		      const class nljm_struct &phi_a_GS = phi_p_table(sa_GS);
		      const class nljm_struct &phi_c_GS = phi_p_table(sc_GS);
		      const class nljm_struct &phi_d_1h = phi_p_table(sd_1h);

		      if (same_nlj_particle (phi_a_GS , phi_c_GS) && same_nlj_particle (phi_a_GS , phi_d_1h))
			{
			  const unsigned int shell_p_occ_index = phi_a_GS.get_shell_index ();

			  const class spherical_state &shell_p_occ = shells_p(shell_p_occ_index);
			
			  const int reordering_phase_p = minus_one_pow (sa_GS_place + sc_GS_place + sd_1h_place + ZYval_m1);

			  const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase_p/Up_HF_normalizing_sum;

			  const double ma_GS = phi_a_GS.get_m ();
			  const double mc_GS = phi_c_GS.get_m ();
			  const double md_1h = phi_d_1h.get_m ();

			  const double mb_1h = imp_out - jp;

			  if (is_it_SGI)
			    SGI_part::Up_pp_part_calc (is_it_res , is_it_pm , pm , shell_p_occ_index , shell_p_HF , shell_p_occ , ma_GS , mb_1h , mc_GS , md_1h ,
						       SDs_weight , CGs , multipolar_expansion , inter_data_basis , radial_p_tabs , prot_Y_HF_data);
			
			  if (is_it_MSGI)
			    MSGI_part::Up_pp_part_calc (is_it_res , is_it_pm , pm , shell_p_HF , shell_p_occ , ma_GS , mb_1h , mc_GS , md_1h ,
							SDs_weight , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_Y_HF_data);
			}
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potential_pn_part_calc (
											const bool is_it_res , 
											const bool is_it_pm , 
											const int pm , 
											const class CG_str &CGs , 
											const class array<double> &Gaussian_table_GL , 
											const class multipolar_expansion_str &multipolar_expansion , 
											const class interaction_class &inter_data_basis , 
											const class SGI_radial_tabs_str &radial_n_tabs , 
											const class baryons_data &prot_data_one_configuration_GSM , 
											const class baryons_data &neut_data_one_configuration_GSM , 
											const class spherical_state &shell_p_HF , 
											class HF_nucleons_data &prot_Y_HF_data)
{ 
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const int ZYval = prot_data_one_configuration_GSM.get_N_valence_nucleons_basis ();
  const int NYval = neut_data_one_configuration_GSM.get_N_valence_nucleons_basis ();
  
  const int ZYval_m1 = ZYval - 1;

  const class array<class nljm_struct> &phi_p_table = prot_data_one_configuration_GSM.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data_one_configuration_GSM.get_phi_table ();

  const class array<class spherical_state> &shells_n = neut_data_one_configuration_GSM.get_shells ();

  const class lj_table<unsigned int> &dimensions_GS = prot_Y_HF_data.get_dimensions_GS ();

  const class lj_table<complex<double> > &Up_HF_normalizing_sums = prot_Y_HF_data.get_U_HF_normalizing_sums ();
  
  const class lj_table<class array<class Slater_determinant> > &SDp_tab_GS = prot_Y_HF_data.get_SDp_tab_GS ();
  const class lj_table<class array<class Slater_determinant> > &SDn_tab_GS = prot_Y_HF_data.get_SDn_tab_GS ();
  const class lj_table<class array<class Slater_determinant> > &SDp_tab_1h = prot_Y_HF_data.get_SDs_1h ();

  const class lj_table<class array<complex<double> > > &SDs_GS_coefficients = prot_Y_HF_data.get_SDs_GS_coefficients ();
  const class lj_table<class array<complex<double> > > &SDs_1h_coefficients = prot_Y_HF_data.get_SDs_1h_coefficients ();

  const class lj_table<class array<bool> > &SDp_tab_1h_existence_tab = prot_Y_HF_data.get_SDs_1h_existence_tab();

  const double jp = shell_p_HF.get_j ();

  const int lp = shell_p_HF.get_l ();

  const int imp_number = make_int (2.0*jp + 1.0);

  const unsigned int dimension_GS = dimensions_GS(lp , jp);

  const complex<double> Up_HF_normalizing_sum = Up_HF_normalizing_sums(lp , jp);

  const class array<class Slater_determinant> &SDp_tab_GS_lj = SDp_tab_GS(lp , jp);
  const class array<class Slater_determinant> &SDn_tab_GS_lj = SDn_tab_GS(lp , jp);
  const class array<class Slater_determinant> &SDp_tab_1h_lj = SDp_tab_1h(lp , jp);

  const class array<complex<double> > &SDs_GS_coefficients_lj = SDs_GS_coefficients(lp , jp);
  const class array<complex<double> > &SDs_1h_coefficients_lj = SDs_1h_coefficients(lp , jp);

  const class array<bool> &SDp_tab_1h_existence_tab_lj = SDp_tab_1h_existence_tab(lp , jp);

  unsigned int p_jump_states_number_GS_in  = 0;
  unsigned int n_jump_states_number_GS_in  = 0;
  unsigned int n_jump_states_number_GS_out = 0;

  class array<unsigned int> p_jump_states_GS_in(ZYval);
  class array<unsigned int> n_jump_states_GS_in(NYval);
  class array<unsigned int> n_jump_states_GS_out(NYval);

  for (unsigned int i_GS_in = 0 ; i_GS_in < dimension_GS ; i_GS_in++)
    {
      const complex<double> SD_GS_coefficient_in = SDs_GS_coefficients_lj(i_GS_in);
      if (SD_GS_coefficient_in == 0.0) continue;

      const class Slater_determinant &SDp_lj_GS_in = SDp_tab_GS_lj(i_GS_in);
      const class Slater_determinant &SDn_lj_GS_in = SDn_tab_GS_lj(i_GS_in);

      for (unsigned int i_GS_out = 0 ; i_GS_out < dimension_GS ; i_GS_out++)
	{
	  const class Slater_determinant &SDn_lj_GS_out = SDn_tab_GS_lj(i_GS_out);

	  SDn_lj_GS_in.different_states_determine (SDn_lj_GS_out , n_jump_states_number_GS_in , n_jump_states_GS_in);

	  if (n_jump_states_number_GS_in <= 1)
	    {
	      for (int imp_out = 0 ; imp_out < imp_number ; imp_out++)
		{
		  const bool SDp_lj_1h_out_exists = SDp_tab_1h_existence_tab_lj(i_GS_out , imp_out);

		  if (!SDp_lj_1h_out_exists) continue;

		  const complex<double> SD_1h_coefficient_out = SDs_1h_coefficients_lj(i_GS_out , imp_out);

		  if (SD_1h_coefficient_out == 0.0) continue;

		  const class Slater_determinant &SDp_lj_1h_out = SDp_tab_1h_lj(i_GS_out , imp_out);

		  SDp_lj_GS_in.different_states_determine (SDp_lj_1h_out , p_jump_states_number_GS_in , p_jump_states_GS_in);

		  if ((p_jump_states_number_GS_in == 1) && (n_jump_states_number_GS_in == 0))
		    {
		      const unsigned int p_jump_state = p_jump_states_GS_in(0);

		      const unsigned int p_jump_state_place = SDp_lj_GS_in.state_place_find (p_jump_state);

		      const int reordering_phase_p = minus_one_pow (p_jump_state_place + ZYval_m1);

		      const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase_p/Up_HF_normalizing_sum;

		      for (int n_occ = 0 ; n_occ < NYval ; n_occ++)
			{
			  const unsigned int state_n_occ = SDn_lj_GS_out[n_occ];

			  const class nljm_struct &phi_n_occ = phi_n_table(state_n_occ);
			  
			  const unsigned int sn_occ = phi_n_occ.get_shell_index ();

			  const class spherical_state &shell_n_occ = shells_n(sn_occ);

			  const double mn_occ = phi_n_occ.get_m ();

			  const double mp_out = imp_out - jp;

			  if (is_it_SGI)
			    SGI_part::Up_pn_part_calc (is_it_res , is_it_pm , pm , sn_occ , shell_p_HF , shell_n_occ , mp_out , mp_out , mn_occ , mn_occ ,
						       SDs_weight , CGs , multipolar_expansion , inter_data_basis , radial_n_tabs , prot_Y_HF_data);
			  
			  if (is_it_MSGI)
			    MSGI_part::Up_pn_part_calc (is_it_res , is_it_pm , pm , shell_p_HF , shell_n_occ , mp_out , mp_out , mn_occ , mn_occ ,
							SDs_weight , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_Y_HF_data);
			}
		    }
		  else if ((p_jump_states_number_GS_in == 1) && (n_jump_states_number_GS_in == 1))
		    {
		      SDn_lj_GS_out.different_states_determine (SDn_lj_GS_in , n_jump_states_number_GS_out , n_jump_states_GS_out);
		      
		      const unsigned int p_in  = p_jump_states_GS_in(0);
		      const unsigned int n_in  = n_jump_states_GS_in(0);
		      const unsigned int n_out = n_jump_states_GS_out(0);
		      
		      const unsigned int p_in_place  = SDp_lj_GS_in.state_place_find (p_in);
		      const unsigned int n_in_place  = SDn_lj_GS_in.state_place_find (n_in);
		      const unsigned int n_out_place = SDn_lj_GS_out.state_place_find (n_out);
		      
		      const int reordering_phase = minus_one_pow (n_in_place + n_out_place + p_in_place + ZYval_m1);

		      const class nljm_struct &phi_p_in  = phi_p_table(p_in);
		      const class nljm_struct &phi_n_in  = phi_n_table(n_in);
		      const class nljm_struct &phi_n_out = phi_n_table(n_out);

		      if (same_nlj_particle (phi_n_in , phi_n_out))
			{
			  const unsigned int shell_n_in_index = phi_n_in.get_shell_index ();
			  
			  const class spherical_state &shell_n_in = shells_n(shell_n_in_index);
			  
			  const double mp_in  = phi_p_in.get_m ();
			  const double mn_in  = phi_n_in.get_m ();
			  const double mn_out = phi_n_out.get_m ();
			  
			  const double mp_out = imp_out - jp;

			  const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase/Up_HF_normalizing_sum;

			  if (is_it_SGI)
			    SGI_part::Up_pn_part_calc (is_it_res , is_it_pm , pm , shell_n_in_index , shell_p_HF , shell_n_in , mp_in , mp_out , mn_in , mn_out ,
						       SDs_weight , CGs , multipolar_expansion , inter_data_basis , radial_n_tabs , prot_Y_HF_data);
			  
			  if (is_it_MSGI)
			    MSGI_part::Up_pn_part_calc (is_it_res , is_it_pm , pm , shell_p_HF , shell_n_in , mp_in , mp_out , mn_in , mn_out ,
							SDs_weight , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_Y_HF_data);
			}
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potential_nn_part_calc (
											const bool is_it_res , 
											const bool is_it_pm , 
											const int pm , 
											const class CG_str &CGs , 
											const class array<double> &Gaussian_table_GL , 
											const class multipolar_expansion_str &multipolar_expansion , 
											const class interaction_class &inter_data_basis , 
											const class SGI_radial_tabs_str &radial_n_tabs , 
											const class baryons_data &neut_data_one_configuration_GSM , 
											const class spherical_state &shell_n_HF , 
											class HF_nucleons_data &neut_Y_HF_data)
{ 
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const int NYval = neut_data_one_configuration_GSM.get_N_valence_nucleons_basis ();

  const int NYval_m1 = NYval - 1;

  const class array<class nljm_struct> &phi_n_table = neut_data_one_configuration_GSM.get_phi_table ();

  const class array<class spherical_state> &shells_n = neut_data_one_configuration_GSM.get_shells ();

  const class lj_table<unsigned int> &dimensions_GS = neut_Y_HF_data.get_dimensions_GS ();

  const class lj_table<complex<double> > &Un_HF_normalizing_sums = neut_Y_HF_data.get_U_HF_normalizing_sums ();
  
  const class lj_table<class array<class Slater_determinant> > &SDp_tab_GS = neut_Y_HF_data.get_SDp_tab_GS ();
  const class lj_table<class array<class Slater_determinant> > &SDn_tab_GS = neut_Y_HF_data.get_SDn_tab_GS ();
  const class lj_table<class array<class Slater_determinant> > &SDn_tab_1h = neut_Y_HF_data.get_SDs_1h ();

  const class lj_table<class array<complex<double> > > &SDs_GS_coefficients = neut_Y_HF_data.get_SDs_GS_coefficients ();
  const class lj_table<class array<complex<double> > > &SDs_1h_coefficients = neut_Y_HF_data.get_SDs_1h_coefficients ();
  
  const class lj_table<class array<bool> > &SDn_tab_1h_existence_tab = neut_Y_HF_data.get_SDs_1h_existence_tab();

  const double jn = shell_n_HF.get_j ();

  const int ln = shell_n_HF.get_l ();

  const int imn_number = make_int (2.0*jn + 1.0);

  const unsigned int dimension_GS = dimensions_GS(ln , jn);

  const complex<double> Un_HF_normalizing_sum = Un_HF_normalizing_sums(ln , jn);
	
  const class array<class Slater_determinant > &SDp_tab_GS_lj = SDp_tab_GS(ln , jn);
  const class array<class Slater_determinant > &SDn_tab_GS_lj = SDn_tab_GS(ln , jn);
  const class array<class Slater_determinant > &SDn_tab_1h_lj = SDn_tab_1h(ln , jn);
  
  const class array<complex<double> > &SDs_GS_coefficients_lj = SDs_GS_coefficients(ln , jn);
  const class array<complex<double> > &SDs_1h_coefficients_lj = SDs_1h_coefficients(ln , jn);
  
  const class array<bool> &SDn_tab_1h_existence_tab_lj = SDn_tab_1h_existence_tab(ln , jn);

  unsigned int n_jump_states_number_GS_in  = 0;
  unsigned int n_jump_states_number_1h_out = 0;

  class array<unsigned int> n_jump_states_GS_in(NYval);
  class array<unsigned int> n_jump_states_1h_out(NYval_m1);

  for (unsigned int i_GS_in = 0 ; i_GS_in < dimension_GS ; i_GS_in++)
    {
      const complex<double> SD_GS_coefficient_in = SDs_GS_coefficients_lj(i_GS_in);
      
      if (SD_GS_coefficient_in == 0.0) continue;

      const class Slater_determinant &SDp_lj_GS_in = SDp_tab_GS_lj(i_GS_in);
      const class Slater_determinant &SDn_lj_GS_in = SDn_tab_GS_lj(i_GS_in);

      for (unsigned int i_GS_out = 0 ; i_GS_out < dimension_GS ; i_GS_out++)
	{
	  const class Slater_determinant &SDp_lj_GS_out = SDp_tab_GS_lj(i_GS_out);

	  if (SDp_lj_GS_in == SDp_lj_GS_out)
	    {
	      for (int imn_out = 0 ; imn_out < imn_number ; imn_out++)
		{
		  const bool SDn_lj_1h_out_exists = SDn_tab_1h_existence_tab_lj(i_GS_out , imn_out);

		  if (!SDn_lj_1h_out_exists) continue;

		  const complex<double> SD_1h_coefficient_out = SDs_1h_coefficients_lj(i_GS_out , imn_out);

		  if (SD_1h_coefficient_out == 0.0) continue;

		  const class Slater_determinant &SDn_lj_1h_out = SDn_tab_1h_lj(i_GS_out , imn_out);

		  SDn_lj_GS_in.different_states_determine (SDn_lj_1h_out , n_jump_states_number_GS_in , n_jump_states_GS_in);
					
		  if (n_jump_states_number_GS_in == 1)
		    {
		      const unsigned int n_jump_state = n_jump_states_GS_in(0);

		      const unsigned int n_jump_state_place = SDn_lj_GS_in.state_place_find (n_jump_state);
		    
		      const int reordering_phase_n = minus_one_pow (n_jump_state_place + NYval_m1);
		    
		      const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase_n/Un_HF_normalizing_sum;

		      for (int n_occ = 0 ; n_occ < NYval_m1 ; n_occ++)
			{
			  const unsigned int state_n_occ = SDn_lj_1h_out[n_occ];

			  const class nljm_struct &phi_n_occ = phi_n_table(state_n_occ);
			
			  const unsigned int sn_occ = phi_n_occ.get_shell_index ();

			  const class spherical_state &shell_n_occ = shells_n(sn_occ);

			  const double mn_occ = phi_n_occ.get_m ();

			  const double mn_out = imn_out - jn;

			  if (is_it_SGI)
			    SGI_part::Un_nn_part_calc (is_it_res , is_it_pm , pm , sn_occ , shell_n_HF , shell_n_occ , mn_out , mn_out , mn_occ , mn_occ ,
						       SDs_weight , CGs , multipolar_expansion , inter_data_basis , radial_n_tabs , neut_Y_HF_data);
			
			  if (is_it_MSGI)
			    MSGI_part::Un_nn_part_calc (is_it_res , is_it_pm , pm , shell_n_HF , shell_n_occ , mn_out , mn_out , mn_occ , mn_occ ,
							SDs_weight , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_Y_HF_data);
			}
		    }
		  else if (n_jump_states_number_GS_in == 2)
		    {
		      SDn_lj_1h_out.different_states_determine (SDn_lj_GS_in , n_jump_states_number_1h_out , n_jump_states_1h_out);
		    
		      const unsigned int sa_GS = n_jump_states_GS_in(1);
		      const unsigned int sc_GS = n_jump_states_GS_in(0);
		      const unsigned int sd_1h = n_jump_states_1h_out(0);
		    
		      const unsigned int sa_GS_place = SDn_lj_GS_in.state_place_find (sa_GS);
		      const unsigned int sc_GS_place = SDn_lj_GS_in.state_place_find (sc_GS);
		      const unsigned int sd_1h_place = SDn_lj_1h_out.state_place_find (sd_1h);
		    
		      const class nljm_struct &phi_a_GS = phi_n_table(sa_GS);
		      const class nljm_struct &phi_c_GS = phi_n_table(sc_GS);
		      const class nljm_struct &phi_d_1h = phi_n_table(sd_1h);

		      if (same_nlj_particle (phi_a_GS , phi_c_GS) && same_nlj_particle (phi_a_GS , phi_d_1h))
			{
			  const unsigned int shell_n_occ_index = phi_a_GS.get_shell_index ();

			  const class spherical_state &shell_n_occ = shells_n(shell_n_occ_index);
			
			  const int reordering_phase_n = minus_one_pow (sa_GS_place + sc_GS_place + sd_1h_place + NYval_m1);

			  const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase_n/Un_HF_normalizing_sum;

			  const double ma_GS = phi_a_GS.get_m ();
			  const double mc_GS = phi_c_GS.get_m ();
			  const double md_1h = phi_d_1h.get_m ();
			  
			  const double mb_1h = imn_out - jn;

			  if (is_it_SGI)
			    SGI_part::Un_nn_part_calc (is_it_res , is_it_pm , pm , shell_n_occ_index , shell_n_HF , shell_n_occ , ma_GS , mb_1h , mc_GS , md_1h ,
						       SDs_weight , CGs , multipolar_expansion , inter_data_basis , radial_n_tabs , neut_Y_HF_data);
			
			  if (is_it_MSGI)
			    MSGI_part::Un_nn_part_calc (is_it_res , is_it_pm , pm , shell_n_HF , shell_n_occ , ma_GS , mb_1h , mc_GS , md_1h ,
							SDs_weight , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_Y_HF_data);
			}
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potential_pn_part_calc (
											const bool is_it_res , 
											const bool is_it_pm , 
											const int pm , 
											const class CG_str &CGs , 
											const class array<double> &Gaussian_table_GL , 
											const class multipolar_expansion_str &multipolar_expansion , 
											const class interaction_class &inter_data_basis , 
											const class SGI_radial_tabs_str &radial_p_tabs , 
											const class baryons_data &prot_data_one_configuration_GSM , 
											const class baryons_data &neut_data_one_configuration_GSM , 
											const class spherical_state &shell_n_HF , 
											class HF_nucleons_data &neut_Y_HF_data)
{
  const int ZYval = prot_data_one_configuration_GSM.get_N_valence_nucleons_basis ();
  const int NYval = neut_data_one_configuration_GSM.get_N_valence_nucleons_basis ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const int NYval_m1 = NYval - 1;

  const class array<class nljm_struct> &phi_p_table = prot_data_one_configuration_GSM.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data_one_configuration_GSM.get_phi_table ();

  const class array<class spherical_state> &shells_p = prot_data_one_configuration_GSM.get_shells ();

  const class lj_table<unsigned int> &dimensions_GS = neut_Y_HF_data.get_dimensions_GS ();

  const class lj_table<complex<double> > &Un_HF_normalizing_sums = neut_Y_HF_data.get_U_HF_normalizing_sums ();

  const class lj_table<class array<class Slater_determinant> > &SDp_tab_GS = neut_Y_HF_data.get_SDp_tab_GS ();
  const class lj_table<class array<class Slater_determinant> > &SDn_tab_GS = neut_Y_HF_data.get_SDn_tab_GS ();
  const class lj_table<class array<class Slater_determinant> > &SDn_tab_1h = neut_Y_HF_data.get_SDs_1h ();

  const class lj_table<class array<complex<double> > > &SDs_GS_coefficients = neut_Y_HF_data.get_SDs_GS_coefficients ();
  const class lj_table<class array<complex<double> > > &SDs_1h_coefficients = neut_Y_HF_data.get_SDs_1h_coefficients ();

  const class lj_table<class array<bool> > &SDn_tab_1h_existence_tab = neut_Y_HF_data.get_SDs_1h_existence_tab();

  const double jn = shell_n_HF.get_j ();

  const int ln = shell_n_HF.get_l ();

  const int imn_number = make_int (2.0*jn + 1.0);

  const unsigned int dimension_GS = dimensions_GS(ln , jn);

  const complex<double> Un_HF_normalizing_sum = Un_HF_normalizing_sums(ln , jn);

  const class array<class Slater_determinant > &SDp_tab_GS_lj = SDp_tab_GS(ln , jn);
  const class array<class Slater_determinant > &SDn_tab_GS_lj = SDn_tab_GS(ln , jn);
  const class array<class Slater_determinant > &SDn_tab_1h_lj = SDn_tab_1h(ln , jn);

  const class array<complex<double> > &SDs_GS_coefficients_lj = SDs_GS_coefficients(ln , jn);
  const class array<complex<double> > &SDs_1h_coefficients_lj = SDs_1h_coefficients(ln , jn);

  const class array<bool> &SDn_tab_1h_existence_tab_lj = SDn_tab_1h_existence_tab(ln , jn);

  unsigned int p_jump_states_number_GS_in  = 0;
  unsigned int p_jump_states_number_GS_out = 0;
  unsigned int n_jump_states_number_GS_in  = 0;

  class array<unsigned int> p_jump_states_GS_in(ZYval);
  class array<unsigned int> p_jump_states_GS_out(ZYval);
  class array<unsigned int> n_jump_states_GS_in(NYval);

  for (unsigned int i_GS_in = 0 ; i_GS_in < dimension_GS ; i_GS_in++)
    {
      const complex<double> SD_GS_coefficient_in = SDs_GS_coefficients_lj(i_GS_in);
      
      if (SD_GS_coefficient_in == 0.0) continue;

      const class Slater_determinant &SDp_lj_GS_in = SDp_tab_GS_lj(i_GS_in);
      const class Slater_determinant &SDn_lj_GS_in = SDn_tab_GS_lj(i_GS_in);

      for (unsigned int i_GS_out = 0 ; i_GS_out < dimension_GS ; i_GS_out++)
	{
	  const class Slater_determinant &SDp_lj_GS_out = SDp_tab_GS_lj(i_GS_out);

	  SDp_lj_GS_in.different_states_determine (SDp_lj_GS_out , p_jump_states_number_GS_in , p_jump_states_GS_in);
			
	  if (p_jump_states_number_GS_in <= 1)
	    {
	      for (int imn_out = 0 ; imn_out < imn_number ; imn_out++)
		{
		  const bool SDn_lj_1h_out_exists = SDn_tab_1h_existence_tab_lj(i_GS_out , imn_out);

		  if (!SDn_lj_1h_out_exists) continue;
					
		  const complex<double> SD_1h_coefficient_out = SDs_1h_coefficients_lj(i_GS_out , imn_out);

		  if (SD_1h_coefficient_out == 0.0) continue;

		  const class Slater_determinant &SDn_lj_1h_out = SDn_tab_1h_lj(i_GS_out , imn_out);

		  SDn_lj_GS_in.different_states_determine (SDn_lj_1h_out , n_jump_states_number_GS_in , n_jump_states_GS_in);

		  if ((p_jump_states_number_GS_in == 0) && (n_jump_states_number_GS_in == 1))
		    {
		      const unsigned int n_jump_state = n_jump_states_GS_in(0);

		      const unsigned int n_jump_state_place = SDn_lj_GS_in.state_place_find (n_jump_state);

		      const int reordering_phase_n = minus_one_pow (n_jump_state_place + NYval_m1);

		      const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase_n/Un_HF_normalizing_sum;

		      for (int p_occ = 0 ; p_occ < ZYval ; p_occ++)
			{
			  const unsigned int state_p_occ = SDp_lj_GS_out[p_occ];

			  const class nljm_struct &phi_p_occ = phi_p_table(state_p_occ);
			  
			  const unsigned int sp_occ = phi_p_occ.get_shell_index ();

			  const class spherical_state &shell_p_occ = shells_p(sp_occ);

			  const double mp_occ = phi_p_occ.get_m ();

			  const double mn_out = imn_out - jn;

			  if (is_it_SGI)
			    SGI_part::Un_pn_part_calc (is_it_res , is_it_pm , pm , sp_occ , shell_n_HF , shell_p_occ , mn_out , mn_out , mp_occ , mp_occ ,
						       SDs_weight , CGs , multipolar_expansion , inter_data_basis , radial_p_tabs , neut_Y_HF_data);
			  
			  if (is_it_MSGI)
			    MSGI_part::Un_pn_part_calc (is_it_res , is_it_pm , pm , shell_n_HF , shell_p_occ , mn_out , mn_out , mp_occ , mp_occ ,
							SDs_weight , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_Y_HF_data);
			}
		    }
		  else if ((p_jump_states_number_GS_in == 1) && (n_jump_states_number_GS_in == 1))
		    {
		      SDp_lj_GS_out.different_states_determine (SDp_lj_GS_in , p_jump_states_number_GS_out , p_jump_states_GS_out);
		      
		      const unsigned int p_in  = p_jump_states_GS_in(0);
		      const unsigned int n_in  = n_jump_states_GS_in(0);
		      const unsigned int p_out = p_jump_states_GS_out(0);

		      const unsigned int p_in_place  = SDp_lj_GS_in.state_place_find (p_in);
		      const unsigned int n_in_place  = SDn_lj_GS_in.state_place_find (n_in);
		      const unsigned int p_out_place = SDp_lj_GS_out.state_place_find (p_out);

		      const int reordering_phase = minus_one_pow (p_in_place + p_out_place + n_in_place + NYval_m1);
		      
		      const class nljm_struct &phi_p_in  = phi_p_table(p_in);
		      const class nljm_struct &phi_n_in  = phi_n_table(n_in);
		      const class nljm_struct &phi_p_out = phi_p_table(p_out);

		      if (same_nlj_particle (phi_p_in , phi_p_out))
			{
			  const unsigned int shell_p_in_index = phi_p_in.get_shell_index ();
			  
			  const class spherical_state &shell_p_in = shells_p(shell_p_in_index);

			  const complex<double> SDs_weight = SD_GS_coefficient_in*SD_1h_coefficient_out*reordering_phase/Un_HF_normalizing_sum;

			  const double mp_in  = phi_p_in.get_m ();
			  const double mn_in  = phi_n_in.get_m ();
			  const double mp_out = phi_p_out.get_m ();
			  
			  const double mn_out = imn_out - jn;
							
			  if (is_it_SGI)
			    SGI_part::Un_pn_part_calc (is_it_res , is_it_pm , pm , shell_p_in_index , shell_n_HF , shell_p_in , mn_in , mn_out , mp_in , mp_out ,
						       SDs_weight , CGs , multipolar_expansion , inter_data_basis , radial_p_tabs , neut_Y_HF_data);
			  
			  if (is_it_MSGI)
			    MSGI_part::Un_pn_part_calc (is_it_res , is_it_pm , pm , shell_n_HF , shell_p_in , mn_in , mn_out , mp_in , mp_out ,
							SDs_weight , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_Y_HF_data);
			}
		    }
		}
	    }
	}
    }
}




// Calculation of the direct and exchange parts of the MSDHF potential
// ----------------------------------------------------------------
// The equivalent MSDHF potential U[HF] = U[MSDHF](direct) - U[MSDHF](exchange) writes, for MSGI, along with its source:
//
// U_HF(dir)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . F_Gaussian(r) . \int u_occ^2(r') F_Gaussian(r') dr'
// U_HF(exc)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' . F(r)
//
// The equivalent MSDHF potential U_HF = U_HF(direct) - U_HF(exchange) writes, for SGI, along with its source:
//
// U_HF(dir)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . Vl'_SGI(r , 2R0-r) . u_occ^2(2R0-r)
// U_HF(exc)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ, l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) . F(r)
//
// where weight is function of Clebsch-Gordan coefficients and of the SD components of the GSM ground state of the optimized configuration (see above).
// coupling_constant(Pi,J) is the Pi-J-dependent coupling constant of the MSGI interaction, 
// F_Gaussian(r) is the Gaussian form factor entering the MSGI interaction (see GSM_TBME_MSGI.cpp) and
// Vl'_SGI(r) is the multipolar expansion of the SGI interaction (see GSM_interaction_class.cpp) and R0 is the radius of the SGI/MSGI interaction.
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
// Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
// The ratio |u(r)|^2/|u'(r)|^2) prevents F(r) to be non zero when r -> +oo.
// Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// If one uses holes, there is an additional double-counting potential term  <wf[out] | U[hole-double-counting] | wf[in]> term to remove (see GSM_hole_double_counting.cpp).
// The formula is: < wf[out] | U[hole-double-counting] | wf[in] > = \sum_{holes,J'} (2J' + 1)/(2j + 1) <wf[out] wf[hole] | V | wf[in] wf[hole]>_J,
// which is removed from the MSDHF potential. There is no 1p-1h term, as it is diagonal only, so that it cannot enter HF or MSDHF potentials.
//
// This routine loops over all proton and neutron states and occupied states and calls routines of the namespaces SGI_part_common and MSGI_part_common.

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_pp_part_calc (
											 const bool HO_diag , 
											 const class CG_str &CGs , 
											 const class array<double> &Gaussian_table_GL , 
											 const class multipolar_expansion_str &multipolar_expansion , 
											 const class interaction_class &inter_data_basis , 
											 const class SGI_radial_tabs_str &radial_p_tabs , 
											 const class baryons_data &prot_data_one_configuration_GSM , 
											 class HF_nucleons_data &prot_Y_HF_data)
{
  const unsigned int Np_nlj     = prot_Y_HF_data.get_N_nlj ();
  const unsigned int Np_nlj_res = prot_Y_HF_data.get_N_nlj_res ();

  const class array<class nlj_struct> &shells_pqn = prot_Y_HF_data.get_shells_quantum_numbers ();

  const class array<class spherical_state> &shells_p     = prot_Y_HF_data.get_shells ();
  const class array<class spherical_state> &shells_p_res = prot_Y_HF_data.get_shells_res ();

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj_res ; sp_HF++)
    {
      const class spherical_state &shell_p_res = shells_p_res(sp_HF);
      
      if (shell_p_res.is_it_filled ())
	prot_trivially_equivalent_potential_pp_part_calc (true , false , NADA , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_p_tabs , prot_data_one_configuration_GSM , shell_p_res , prot_Y_HF_data);
    }

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class nlj_struct &shell_p_qn = shells_pqn(sp_HF);

      const bool is_it_HO = shell_p_qn.get_is_it_HO ();
      
      const bool S_matrix_pole = shell_p_qn.get_S_matrix_pole ();

      const bool no_HO = (!is_it_HO) && (!HO_diag);

      const class spherical_state &shell_p_HF = shells_p(sp_HF);

      if ((S_matrix_pole || no_HO) && shell_p_HF.is_it_filled ())
	{
	  if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	    {
	      prot_trivially_equivalent_potential_pp_part_calc (false , false , NADA , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_p_tabs , prot_data_one_configuration_GSM , shell_p_HF , prot_Y_HF_data);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_pn_part_calc (
											 const bool HO_diag , 
											 const class CG_str &CGs , 
											 const class array<double> &Gaussian_table_GL , 
											 const class multipolar_expansion_str &multipolar_expansion , 
											 const class interaction_class &inter_data_basis , 
											 const class SGI_radial_tabs_str &radial_n_tabs , 
											 const class baryons_data &prot_data_one_configuration_GSM , 
											 const class baryons_data &neut_data_one_configuration_GSM , 
											 class HF_nucleons_data &prot_Y_HF_data)
{
  const unsigned int Np_nlj     = prot_Y_HF_data.get_N_nlj ();
  const unsigned int Np_nlj_res = prot_Y_HF_data.get_N_nlj_res ();

  const class array<class nlj_struct> &shells_pqn = prot_Y_HF_data.get_shells_quantum_numbers ();

  const class array<class spherical_state> &shells_p     = prot_Y_HF_data.get_shells ();
  const class array<class spherical_state> &shells_p_res = prot_Y_HF_data.get_shells_res ();

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj_res ; sp_HF++)
    {
      const class spherical_state &shell_p_res = shells_p_res(sp_HF);
      
      if (shell_p_res.is_it_filled ())
	prot_trivially_equivalent_potential_pn_part_calc (true , false , NADA , CGs , Gaussian_table_GL , multipolar_expansion ,
							  inter_data_basis , radial_n_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , shell_p_res , prot_Y_HF_data);
    }

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class nlj_struct &shell_p_qn = shells_pqn(sp_HF);

      const bool is_it_HO = shell_p_qn.get_is_it_HO ();
      
      const bool S_matrix_pole = shell_p_qn.get_S_matrix_pole ();

      const bool no_HO = (!is_it_HO) && (!HO_diag);

      const class spherical_state &shell_p_HF = shells_p(sp_HF);

      if ((S_matrix_pole || no_HO) && shell_p_HF.is_it_filled ())
	{
	  if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	    {
	      prot_trivially_equivalent_potential_pn_part_calc (false , false , NADA , CGs , Gaussian_table_GL , multipolar_expansion ,
								inter_data_basis , radial_n_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , shell_p_HF , prot_Y_HF_data);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_nn_part_calc (
											 const bool HO_diag , 
											 const class CG_str &CGs , 
											 const class array<double> &Gaussian_table_GL , 
											 const class multipolar_expansion_str &multipolar_expansion , 
											 const class interaction_class &inter_data_basis , 
											 const class SGI_radial_tabs_str &radial_n_tabs , 
											 const class baryons_data &neut_data_one_configuration_GSM , 
											 class HF_nucleons_data &neut_Y_HF_data)
{
  const unsigned int Nn_nlj     = neut_Y_HF_data.get_N_nlj ();
  const unsigned int Nn_nlj_res = neut_Y_HF_data.get_N_nlj_res ();

  const class array<class nlj_struct> &shells_n_qn = neut_Y_HF_data.get_shells_quantum_numbers ();

  const class array<class spherical_state> &shells_n     = neut_Y_HF_data.get_shells ();
  const class array<class spherical_state> &shells_n_res = neut_Y_HF_data.get_shells_res ();

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj_res ; sn_HF++)
    {
      const class spherical_state &shell_n_res = shells_n_res(sn_HF);
      
      if (shell_n_res.is_it_filled ())
	neut_trivially_equivalent_potential_nn_part_calc (true , false , NADA , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_n_tabs , neut_data_one_configuration_GSM , shell_n_res , neut_Y_HF_data);
    }

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class nlj_struct &shell_n_qn = shells_n_qn(sn_HF);

      const bool is_it_HO = shell_n_qn.get_is_it_HO ();
      
      const bool S_matrix_pole = shell_n_qn.get_S_matrix_pole ();

      const bool no_HO = (!is_it_HO) && (!HO_diag);

      const class spherical_state &shell_n_HF = shells_n(sn_HF);

      if ((S_matrix_pole || no_HO) && shell_n_HF.is_it_filled ())
	{
	  if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	    {
	      neut_trivially_equivalent_potential_nn_part_calc (false , false , NADA , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_n_tabs , neut_data_one_configuration_GSM , shell_n_HF , neut_Y_HF_data);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_pn_part_calc (
											 const bool HO_diag , 
											 const class CG_str &CGs , 
											 const class array<double> &Gaussian_table_GL , 
											 const class multipolar_expansion_str &multipolar_expansion , 
											 const class interaction_class &inter_data_basis , 
											 const class SGI_radial_tabs_str &radial_p_tabs , 
											 const class baryons_data &prot_data_one_configuration_GSM , 
											 const class baryons_data &neut_data_one_configuration_GSM , 
											 class HF_nucleons_data &neut_Y_HF_data)
{
  const unsigned int Nn_nlj     = neut_Y_HF_data.get_N_nlj ();
  const unsigned int Nn_nlj_res = neut_Y_HF_data.get_N_nlj_res ();

  const class array<class nlj_struct> &shells_n_qn = neut_Y_HF_data.get_shells_quantum_numbers ();

  const class array<class spherical_state> &shells_n     = neut_Y_HF_data.get_shells ();
  const class array<class spherical_state> &shells_n_res = neut_Y_HF_data.get_shells_res ();

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj_res ; sn_HF++)
    {
      const class spherical_state &shell_n_res = shells_n_res(sn_HF);
      
      if (shell_n_res.is_it_filled ())
	neut_trivially_equivalent_potential_pn_part_calc (true , false , NADA , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis ,
							  radial_p_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , shell_n_res , neut_Y_HF_data);
    }

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class nlj_struct &shell_n_qn = shells_n_qn(sn_HF);

      const bool is_it_HO = shell_n_qn.get_is_it_HO ();
      
      const bool S_matrix_pole = shell_n_qn.get_S_matrix_pole ();

      const bool no_HO = (!is_it_HO) && (!HO_diag);

      const class spherical_state &shell_n_HF = shells_n(sn_HF);

      if ((S_matrix_pole || no_HO) && shell_n_HF.is_it_filled ())
	{
	  if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	    {		
	      neut_trivially_equivalent_potential_pn_part_calc (false , false , NADA , CGs , Gaussian_table_GL , multipolar_expansion ,
								inter_data_basis , radial_p_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , shell_n_HF , neut_Y_HF_data);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_pp_part_shells_pm_calc (
												   const int pm , 
												   const class CG_str &CGs , 
												   const class array<double> &Gaussian_table_GL , 
												   const class multipolar_expansion_str &multipolar_expansion , 
												   const class interaction_class &inter_data_basis , 
												   const class SGI_radial_tabs_str &radial_p_tabs , 
												   const class baryons_data &prot_data_one_configuration_GSM , 
												   class HF_nucleons_data &prot_Y_HF_data)
{ 
  const unsigned int Np_nlj = prot_Y_HF_data.get_N_nlj ();

  const class array<class spherical_state> &shells_ppm = (pm == 1) ? (prot_Y_HF_data.get_shells_plus ()) : (prot_Y_HF_data.get_shells_minus ());

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class spherical_state &shell_p_pm = shells_ppm(sp_HF);
      
      if (shell_p_pm.is_it_filled ())
	{
	  if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	    {
	      prot_trivially_equivalent_potential_pp_part_calc (false , true , pm , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_p_tabs , prot_data_one_configuration_GSM , shell_p_pm , prot_Y_HF_data);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_pn_part_shells_pm_calc (
												   const int pm , 
												   const class CG_str &CGs , 
												   const class array<double> &Gaussian_table_GL , 
												   const class multipolar_expansion_str &multipolar_expansion , 
												   const class interaction_class &inter_data_basis , 
												   const class SGI_radial_tabs_str &radial_n_tabs , 
												   const class baryons_data &prot_data_one_configuration_GSM , 
												   const class baryons_data &neut_data_one_configuration_GSM , 
												   class HF_nucleons_data &prot_Y_HF_data)
{ 
  const unsigned int Np_nlj = prot_Y_HF_data.get_N_nlj ();

  const class array<class spherical_state> &shells_ppm = (pm == 1) ? (prot_Y_HF_data.get_shells_plus ()) : (prot_Y_HF_data.get_shells_minus ());

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class spherical_state &shell_p_pm = shells_ppm(sp_HF);
      
      if (shell_p_pm.is_it_filled ())
	{
	  if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	    {
	      prot_trivially_equivalent_potential_pn_part_calc (false , true , pm , CGs , Gaussian_table_GL , multipolar_expansion ,
								inter_data_basis , radial_n_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , shell_p_pm , prot_Y_HF_data);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_nn_part_shells_pm_calc (
												   const int pm , 
												   const class CG_str &CGs , 
												   const class array<double> &Gaussian_table_GL , 
												   const class multipolar_expansion_str &multipolar_expansion , 
												   const class interaction_class &inter_data_basis , 
												   const class SGI_radial_tabs_str &radial_n_tabs , 
												   const class baryons_data &neut_data_one_configuration_GSM , 
												   class HF_nucleons_data &neut_Y_HF_data)
{
  const unsigned int Nn_nlj = neut_Y_HF_data.get_N_nlj ();

  const class array<class spherical_state> &shells_n_pm = (pm == 1) ? (neut_Y_HF_data.get_shells_plus ()) : (neut_Y_HF_data.get_shells_minus ());

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class spherical_state &shell_n_pm = shells_n_pm(sn_HF);
      
      if (shells_n_pm(sn_HF).is_it_filled ())
	{
	  if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	    {
	      neut_trivially_equivalent_potential_nn_part_calc (false , true , pm , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_n_tabs , neut_data_one_configuration_GSM , shell_n_pm , neut_Y_HF_data);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_pn_part_shells_pm_calc (
												   const int pm , 
												   const class CG_str &CGs , 
												   const class array<double> &Gaussian_table_GL , 
												   const class multipolar_expansion_str &multipolar_expansion , 
												   const class interaction_class &inter_data_basis , 
												   const class SGI_radial_tabs_str &radial_p_tabs , 
												   const class baryons_data &prot_data_one_configuration_GSM , 
												   const class baryons_data &neut_data_one_configuration_GSM , 
												   class HF_nucleons_data &neut_Y_HF_data)
{
  const unsigned int Nn_nlj = neut_Y_HF_data.get_N_nlj ();

  const class array<class spherical_state> &shells_n_pm = (pm == 1) ? (neut_Y_HF_data.get_shells_plus ()) : (neut_Y_HF_data.get_shells_minus ());

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class spherical_state &shell_n_pm = shells_n_pm(sn_HF);
      
      if (shells_n_pm(sn_HF).is_it_filled ())
	{
	  if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	    {
	      neut_trivially_equivalent_potential_pn_part_calc (false , true , pm , CGs , Gaussian_table_GL , multipolar_expansion ,
								inter_data_basis , radial_p_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , shell_n_pm , neut_Y_HF_data);
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_hole_double_counting_pp_part_remove (
														const bool HO_diag , 
														const class array<double> &Gaussian_table_GL , 
														const class multipolar_expansion_str &multipolar_expansion , 
														const class interaction_class &inter_data_basis , 
														const class SGI_radial_tabs_str &radial_p_tabs , 
														class HF_nucleons_data &prot_Y_HF_data)
{
  const unsigned int Np_nlj     = prot_Y_HF_data.get_N_nlj ();
  const unsigned int Np_nlj_res = prot_Y_HF_data.get_N_nlj_res ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);
  
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_p     = prot_Y_HF_data.get_shells ();
  const class array<class spherical_state> &shells_p_res = prot_Y_HF_data.get_shells_res ();

  const class array<class nlj_struct> &shells_pqn     = prot_Y_HF_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_p_res_qn = prot_Y_HF_data.get_shells_quantum_numbers_res ();

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj_res ; sp_HF++)
    {
      const class spherical_state &shell_p_res = shells_p_res(sp_HF);
      
      if (shell_p_res.is_it_filled ())
	{
	  for (unsigned int sp = 0 ; sp < Np_nlj_res ; sp++)
	    {
	      const class nlj_struct &shell_p_qn_possible_hole = shells_p_res_qn(sp);
	      
	      const bool hole_state_p = shell_p_qn_possible_hole.get_hole_state ();

	      if (hole_state_p)
		{
		  const class spherical_state &shell_p_hole = shells_p_res(sp);

		  if (is_it_SGI)
		    SGI_part::Up_hole_double_counting_pp_part_remove (true , false , NADA , sp , shell_p_res , shell_p_hole , multipolar_expansion , inter_data_basis , radial_p_tabs , prot_Y_HF_data);

		  if (is_it_MSGI)
		    MSGI_part::Up_hole_double_counting_pp_part_remove (true , false , NADA , shell_p_res , shell_p_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_Y_HF_data);
		}
	    }
	}
    }

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class nlj_struct &shell_p_qn = shells_pqn(sp_HF);

      const bool is_it_HO = shell_p_qn.get_is_it_HO ();
      
      const bool S_matrix_pole = shell_p_qn.get_S_matrix_pole ();
      
      const bool no_HO = (!is_it_HO) && (!HO_diag);

      const class spherical_state &shell_p_HF = shells_p(sp_HF);
      
      if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	{
	  if ((S_matrix_pole || no_HO) && shell_p_HF.is_it_filled ())
	    {
	      for (unsigned int sp = 0 ; sp < Np_nlj_res ; sp++)
		{
		  const class nlj_struct &shell_p_qn_possible_hole = shells_p_res_qn(sp);

		  const bool hole_state_p = shell_p_qn_possible_hole.get_hole_state ();

		  if (hole_state_p)
		    {
		      const class spherical_state &shell_p_hole = shells_p_res(sp);

		      if (is_it_SGI)
			SGI_part::Up_hole_double_counting_pp_part_remove (false , false , NADA , sp , shell_p_HF , shell_p_hole , multipolar_expansion , inter_data_basis , radial_p_tabs , prot_Y_HF_data);

		      if (is_it_MSGI)
			MSGI_part::Up_hole_double_counting_pp_part_remove (false , false , NADA , shell_p_HF , shell_p_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_Y_HF_data);
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_hole_double_counting_pn_part_remove (
														const bool HO_diag , 
														const class array<double> &Gaussian_table_GL , 
														const class multipolar_expansion_str &multipolar_expansion , 
														const class interaction_class &inter_data_basis , 
														const class SGI_radial_tabs_str &radial_n_tabs , 
														const class HF_nucleons_data &neut_Y_HF_data , 
														class HF_nucleons_data &prot_Y_HF_data)
{ 
  const unsigned int Np_nlj = prot_Y_HF_data.get_N_nlj ();

  const unsigned int Np_nlj_res = prot_Y_HF_data.get_N_nlj_res ();
  const unsigned int Nn_nlj_res = neut_Y_HF_data.get_N_nlj_res ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_p = prot_Y_HF_data.get_shells ();

  const class array<class spherical_state> &shells_p_res = prot_Y_HF_data.get_shells_res ();
  const class array<class spherical_state> &shells_n_res = neut_Y_HF_data.get_shells_res ();

  const class array<class nlj_struct> &shells_pqn = prot_Y_HF_data.get_shells_quantum_numbers ();

  const class array<class nlj_struct> &shells_n_res_qn = neut_Y_HF_data.get_shells_quantum_numbers_res ();

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj_res ; sp_HF++)
    {
      const class spherical_state &shell_p_res = shells_p_res(sp_HF);
      
      if (shell_p_res.is_it_filled ())
	{
	  for (unsigned int sn = 0 ; sn < Nn_nlj_res ; sn++)
	    {
	      const class nlj_struct &shell_n_qn_possible_hole = shells_n_res_qn(sn);

	      const bool hole_state_n = shell_n_qn_possible_hole.get_hole_state ();

	      if (hole_state_n)
		{
		  const class spherical_state &shell_n_hole = shells_n_res(sn);
					
		  if (is_it_SGI)
		    SGI_part::Up_hole_double_counting_pn_part_remove (true , false , NADA , sn , shell_p_res , shell_n_hole , multipolar_expansion , inter_data_basis , radial_n_tabs , prot_Y_HF_data);

		  if (is_it_MSGI)
		    MSGI_part::Up_hole_double_counting_pn_part_remove (true , false , NADA , shell_p_res , shell_n_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_Y_HF_data);
		}
	    }
	}
    }

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class nlj_struct &shell_p_qn = shells_pqn(sp_HF);
      
      const bool is_it_HO = shell_p_qn.get_is_it_HO ();

      const bool S_matrix_pole = shell_p_qn.get_S_matrix_pole ();

      const bool no_HO = (!is_it_HO) && (!HO_diag);

      const class spherical_state &shell_p_HF = shells_p(sp_HF);
      
      if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	{
	  if ((S_matrix_pole || no_HO) && shell_p_HF.is_it_filled ())
	    {
	      for (unsigned int sn = 0 ; sn < Nn_nlj_res ; sn++)
		{
		  const class nlj_struct &shell_n_qn_possible_hole = shells_n_res_qn(sn);

		  const bool hole_state_n = shell_n_qn_possible_hole.get_hole_state ();

		  if (hole_state_n)
		    {
		      const class spherical_state &shell_n_hole = shells_n_res(sn);

		      if (is_it_SGI)
			SGI_part::Up_hole_double_counting_pn_part_remove (false , false , NADA , sn , shell_p_HF , shell_n_hole , multipolar_expansion , inter_data_basis , radial_n_tabs , prot_Y_HF_data);

		      if (is_it_MSGI)
			MSGI_part::Up_hole_double_counting_pn_part_remove (false , false , NADA , shell_p_HF , shell_n_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_Y_HF_data);
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_hole_double_counting_nn_part_remove (
														const bool HO_diag , 
														const class array<double> &Gaussian_table_GL , 
														const class multipolar_expansion_str &multipolar_expansion , 
														const class interaction_class &inter_data_basis , 
														const class SGI_radial_tabs_str &radial_n_tabs , 
														class HF_nucleons_data &neut_Y_HF_data)
{
  const unsigned int Nn_nlj     = neut_Y_HF_data.get_N_nlj ();
  const unsigned int Nn_nlj_res = neut_Y_HF_data.get_N_nlj_res ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);
  
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_n     = neut_Y_HF_data.get_shells ();
  const class array<class spherical_state> &shells_n_res = neut_Y_HF_data.get_shells_res ();

  const class array<class nlj_struct> &shells_n_qn     = neut_Y_HF_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_n_res_qn = neut_Y_HF_data.get_shells_quantum_numbers_res ();

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj_res ; sn_HF++)
    {
      const class spherical_state &shell_n_res = shells_n_res(sn_HF);
      
      if (shell_n_res.is_it_filled ())
	{
	  for (unsigned int sn = 0 ; sn < Nn_nlj_res ; sn++)
	    {
	      const class nlj_struct &shell_n_qn_possible_hole = shells_n_res_qn(sn);
	      
	      const bool hole_state_n = shell_n_qn_possible_hole.get_hole_state ();

	      if (hole_state_n)
		{
		  const class spherical_state &shell_n_hole = shells_n_res(sn);

		  if (is_it_SGI)
		    SGI_part::Un_hole_double_counting_nn_part_remove (true , false , NADA , sn , shell_n_res , shell_n_hole , multipolar_expansion , inter_data_basis , radial_n_tabs , neut_Y_HF_data);

		  if (is_it_MSGI)
		    MSGI_part::Un_hole_double_counting_nn_part_remove (true , false , NADA , shell_n_res , shell_n_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_Y_HF_data);
		}
	    }
	}
    }

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class nlj_struct &shell_n_qn = shells_n_qn(sn_HF);

      const bool is_it_HO = shell_n_qn.get_is_it_HO ();

      const bool S_matrix_pole = shell_n_qn.get_S_matrix_pole ();

      const bool no_HO = (!is_it_HO) && (!HO_diag);

      const class spherical_state &shell_n_HF = shells_n(sn_HF);
      
      if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	{
	  if ((S_matrix_pole || no_HO) && shell_n_HF.is_it_filled ())
	    {
	      for (unsigned int sn = 0 ; sn < Nn_nlj_res ; sn++)
		{
		  const class nlj_struct &shell_n_qn_possible_hole = shells_n_res_qn(sn);

		  const bool hole_state_n = shell_n_qn_possible_hole.get_hole_state ();

		  if (hole_state_n)
		    {
		      const class spherical_state &shell_n_hole = shells_n_res(sn);

		      if (is_it_SGI)
			SGI_part::Un_hole_double_counting_nn_part_remove (false , false , NADA , sn , shell_n_HF , shell_n_hole , multipolar_expansion , inter_data_basis , radial_n_tabs , neut_Y_HF_data);

		      if (is_it_MSGI)
			MSGI_part::Un_hole_double_counting_nn_part_remove (false , false , NADA , shell_n_HF , shell_n_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_Y_HF_data);
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_hole_double_counting_pn_part_remove (
														const bool HO_diag , 
														const class array<double> &Gaussian_table_GL , 
														const class multipolar_expansion_str &multipolar_expansion , 
														const class interaction_class &inter_data_basis , 
														const class SGI_radial_tabs_str &radial_p_tabs , 
														const class HF_nucleons_data &prot_Y_HF_data , 
														class HF_nucleons_data &neut_Y_HF_data)
{
  const unsigned int Nn_nlj = neut_Y_HF_data.get_N_nlj ();
  
  const unsigned int Nn_nlj_res = neut_Y_HF_data.get_N_nlj_res ();
  const unsigned int Np_nlj_res = prot_Y_HF_data.get_N_nlj_res ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_p_res = prot_Y_HF_data.get_shells_res ();
  const class array<class spherical_state> &shells_n_res = neut_Y_HF_data.get_shells_res ();
  
  const class array<class spherical_state> &shells_n = neut_Y_HF_data.get_shells ();

  const class array<class nlj_struct> &shells_p_res_qn = prot_Y_HF_data.get_shells_quantum_numbers_res ();
  
  const class array<class nlj_struct> &shells_n_qn = neut_Y_HF_data.get_shells_quantum_numbers ();
  
  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj_res ; sn_HF++)
    {
      const class spherical_state &shell_n_res = shells_n_res(sn_HF);
      
      if (shell_n_res.is_it_filled ())
	{
	  for (unsigned int sp = 0 ; sp < Np_nlj_res ; sp++)
	    {
	      const class nlj_struct &shell_p_qn_possible_hole = shells_p_res_qn(sp);

	      const bool hole_state_p = shell_p_qn_possible_hole.get_hole_state ();

	      if (hole_state_p)
		{
		  const class spherical_state &shell_p_hole = shells_p_res(sp);

		  if (is_it_SGI)
		    SGI_part::Un_hole_double_counting_pn_part_remove (true , false , NADA , sp , shell_n_res , shell_p_hole , multipolar_expansion , inter_data_basis , radial_p_tabs , neut_Y_HF_data);

		  if (is_it_MSGI)
		    MSGI_part::Un_hole_double_counting_pn_part_remove (true , false , NADA , shell_n_res , shell_p_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_Y_HF_data);
		}
	    }
	}
    }

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class nlj_struct &shell_n_qn = shells_n_qn(sn_HF);

      const bool is_it_HO = shell_n_qn.get_is_it_HO ();

      const bool S_matrix_pole = shell_n_qn.get_S_matrix_pole ();

      const bool no_HO = (!is_it_HO) && (!HO_diag);

      const class spherical_state &shell_n_HF = shells_n(sn_HF);
      
      if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	{
	  if ((S_matrix_pole || no_HO) && shell_n_HF.is_it_filled ())
	    {
	      for (unsigned int sp = 0 ; sp < Np_nlj_res ; sp++)
		{
		  const class nlj_struct &shell_p_qn_possible_hole = shells_p_res_qn(sp);

		  const bool hole_state_p = shell_p_qn_possible_hole.get_hole_state ();

		  if (hole_state_p)
		    {
		      const class spherical_state &shell_p_hole = shells_p_res(sp);

		      if (is_it_SGI)
			SGI_part::Un_hole_double_counting_pn_part_remove (false , false , NADA , sp , shell_n_HF , shell_p_hole , multipolar_expansion , inter_data_basis , radial_p_tabs , neut_Y_HF_data);

		      if (is_it_MSGI)
			MSGI_part::Un_hole_double_counting_pn_part_remove (false , false , NADA , shell_n_HF , shell_p_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_Y_HF_data);
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_hole_double_counting_pp_part_shells_pm_remove (
															  const int pm , 
															  const class array<double> &Gaussian_table_GL , 
															  const class multipolar_expansion_str &multipolar_expansion , 
															  const class interaction_class &inter_data_basis , 
															  const class SGI_radial_tabs_str &radial_p_tabs , 
															  class HF_nucleons_data &prot_Y_HF_data)
{
  const unsigned int Np_nlj     = prot_Y_HF_data.get_N_nlj ();
  const unsigned int Np_nlj_res = prot_Y_HF_data.get_N_nlj_res ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);
  
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_ppm = (pm == 1) ? (prot_Y_HF_data.get_shells_plus ()) : (prot_Y_HF_data.get_shells_minus ());

  const class array<class spherical_state> &shells_p_res = prot_Y_HF_data.get_shells_res ();

  const class array<class nlj_struct> &shells_p_res_qn = prot_Y_HF_data.get_shells_quantum_numbers_res ();

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class spherical_state &shell_p_pm = shells_ppm(sp_HF);
      
      if (shell_p_pm.is_it_filled ())
	{
	  if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	    {
	      for (unsigned int sp = 0 ; sp < Np_nlj_res ; sp++)
		{
		  const class nlj_struct &shell_p_qn_possible_hole = shells_p_res_qn(sp);

		  const bool hole_state_p = shell_p_qn_possible_hole.get_hole_state ();

		  if (hole_state_p)
		    {
		      const class spherical_state &shell_p_hole = shells_p_res(sp);

		      if (is_it_SGI)
			SGI_part::Up_hole_double_counting_pp_part_remove (false , true , pm , sp , shell_p_pm , shell_p_hole , multipolar_expansion , inter_data_basis , radial_p_tabs , prot_Y_HF_data);

		      if (is_it_MSGI)
			MSGI_part::Up_hole_double_counting_pp_part_remove (false , true , pm , shell_p_pm , shell_p_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_Y_HF_data);
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_hole_double_counting_pn_part_shells_pm_remove (
															  const int pm , 
															  const class array<double> &Gaussian_table_GL , 
															  const class multipolar_expansion_str &multipolar_expansion , 
															  const class interaction_class &inter_data_basis , 
															  const class SGI_radial_tabs_str &radial_n_tabs , 
															  const class HF_nucleons_data &neut_Y_HF_data , 
															  class HF_nucleons_data &prot_Y_HF_data)
{ 
  const unsigned int Np_nlj     = prot_Y_HF_data.get_N_nlj ();
  const unsigned int Nn_nlj_res = neut_Y_HF_data.get_N_nlj_res ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);
  
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_ppm = (pm == 1) ? (prot_Y_HF_data.get_shells_plus ()) : (prot_Y_HF_data.get_shells_minus ());

  const class array<class spherical_state> &shells_n_res = neut_Y_HF_data.get_shells_res ();

  const class array<class nlj_struct> &shells_n_res_qn = neut_Y_HF_data.get_shells_quantum_numbers_res ();

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class spherical_state &shell_p_pm = shells_ppm(sp_HF);
      
      if (shell_p_pm.is_it_filled ())
	{
	  if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	    {
	      for (unsigned int sn = 0 ; sn < Nn_nlj_res ; sn++)
		{
		  const class nlj_struct &shell_n_qn_possible_hole = shells_n_res_qn(sn);

		  const bool hole_state_n = shell_n_qn_possible_hole.get_hole_state ();

		  if (hole_state_n)
		    {
		      const class spherical_state &shell_n_hole = shells_n_res(sn);

		      if (is_it_SGI)
			SGI_part::Up_hole_double_counting_pn_part_remove (false , true , pm , sn , shell_p_pm , shell_n_hole , multipolar_expansion , inter_data_basis , radial_n_tabs , prot_Y_HF_data);

		      if (is_it_MSGI)
			MSGI_part::Up_hole_double_counting_pn_part_remove (false , true , pm , shell_p_pm , shell_n_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_Y_HF_data);
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_hole_double_counting_nn_part_shells_pm_remove (
															  const int pm , 
															  const class array<double> &Gaussian_table_GL , 
															  const class multipolar_expansion_str &multipolar_expansion , 
															  const class interaction_class &inter_data_basis , 
															  const class SGI_radial_tabs_str &radial_n_tabs , 
															  class HF_nucleons_data &neut_Y_HF_data)
{ 
  const unsigned int Nn_nlj     = neut_Y_HF_data.get_N_nlj ();
  const unsigned int Nn_nlj_res = neut_Y_HF_data.get_N_nlj_res ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_n_pm = (pm == 1) ? (neut_Y_HF_data.get_shells_plus ()) : (neut_Y_HF_data.get_shells_minus ());

  const class array<class spherical_state> &shells_n_res = neut_Y_HF_data.get_shells_res ();

  const class array<class nlj_struct> &shells_n_res_qn = neut_Y_HF_data.get_shells_quantum_numbers_res ();

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class spherical_state &shell_n_pm = shells_n_pm(sn_HF);
      
      if (shell_n_pm.is_it_filled ())
	{
	  if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	    {
	      for (unsigned int sn = 0 ; sn < Nn_nlj_res ; sn++)
		{
		  const class nlj_struct &shell_n_qn_possible_hole = shells_n_res_qn(sn);

		  const bool hole_state_n = shell_n_qn_possible_hole.get_hole_state ();

		  if (hole_state_n)
		    {
		      const class spherical_state &shell_n_hole = shells_n_res(sn);

		      if (is_it_SGI)
			SGI_part::Un_hole_double_counting_nn_part_remove (false , true , pm , sn , shell_n_pm , shell_n_hole , multipolar_expansion , inter_data_basis , radial_n_tabs , neut_Y_HF_data);

		      if (is_it_MSGI)
			MSGI_part::Un_hole_double_counting_nn_part_remove (false , true , pm , shell_n_pm , shell_n_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_Y_HF_data);
		    }
		}
	    }
	}
    }
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_hole_double_counting_pn_part_shells_pm_remove (
															  const int pm , 
															  const class array<double> &Gaussian_table_GL , 
															  const class multipolar_expansion_str &multipolar_expansion , 
															  const class interaction_class &inter_data_basis , 
															  const class SGI_radial_tabs_str &radial_p_tabs , 
															  const class HF_nucleons_data &prot_Y_HF_data , 
															  class HF_nucleons_data &neut_Y_HF_data)
{
  const unsigned int Nn_nlj = neut_Y_HF_data.get_N_nlj ();
  
  const unsigned int Np_nlj_res = prot_Y_HF_data.get_N_nlj_res ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_n_pm = (pm == 1) ? (neut_Y_HF_data.get_shells_plus ()) : (neut_Y_HF_data.get_shells_minus ());

  const class array<class spherical_state> &shells_p_res = prot_Y_HF_data.get_shells_res ();

  const class array<class nlj_struct> &shells_p_res_qn = prot_Y_HF_data.get_shells_quantum_numbers_res ();

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class spherical_state &shell_n_pm = shells_n_pm(sn_HF);
      
      if (shell_n_pm.is_it_filled ())
	{
	  if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	    {
	      for (unsigned int sp = 0 ; sp < Np_nlj_res ; sp++)
		{
		  const class nlj_struct &shell_p_qn_possible_hole = shells_p_res_qn(sp);

		  const bool hole_state_p = shell_p_qn_possible_hole.get_hole_state ();

		  if (hole_state_p)
		    {
		      const class spherical_state &shell_p_hole = shells_p_res(sp);

		      if (is_it_SGI)
			SGI_part::Un_hole_double_counting_pn_part_remove (false , true , pm , sp , shell_n_pm , shell_p_hole , multipolar_expansion , inter_data_basis , radial_p_tabs , neut_Y_HF_data);

		      if (is_it_MSGI)
			MSGI_part::Un_hole_double_counting_pn_part_remove (false , true , pm , shell_n_pm , shell_p_hole , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_Y_HF_data);
		    }
		}
	    }
	}
    }
}








// Calculation of the all HF equivalent potentials and sources
// -----------------------------------------------------------
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) writes, for MSGI, along with its source:
//
// U_HF(dir)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . F_Gaussian(r) . \int u_occ^2(r') F_Gaussian(r') dr'
// U_HF(exc)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' . F(r)
//
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) writes, for SGI, along with its source:
//
// U_HF(dir)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . Vl'_SGI(r , 2R0-r) . u_occ^2(2R0-r)
// U_HF(exc)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ, l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) . F(r)
//
// where weight is function of Clebsch-Gordan coefficients and of the SD components of the GSM ground state on the optimized configuration,
// coupling_constant(Pi,J) is the Pi-J-dependent coupling constant of the MSGI interaction, 
// F_Gaussian(r) is the Gaussian form factor entering the MSGI interaction (see GSM_TBME_MSGI.cpp) and
// Vl'_SGI(r) is the multipolar expansion of the SGI interaction (see GSM_interaction_class.cpp) and R0 is the radius of the SGI/MSGI interaction.
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
// Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
// The ratio |u(r)|^2/|u'(r)|^2) prevents F(r) to be non zero when r -> +oo.
// Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// One sums over all Vpp, Vnn or Vpn interaction two-body matrix elements, according to the number of valence protons and neutrons. 
// HF equivalent potentials and sources are then splined to be calculated on the [0:R] radial grid with Gauss-Legendre and uniformly spaced radii, with R the cimplex scaling rotation point,
// as they are initially calculated in the [0:2.R0] radial grid, with R0 the radius of the SGI/MSGI interaction.

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_calc (
										 const bool HO_diag , 
										 const class CG_str &CGs , 
										 const class array<double> &Gaussian_table_GL , 
										 const class multipolar_expansion_str &multipolar_expansion , 
										 const class interaction_class &inter_data_basis , 
										 const class SGI_radial_tabs_str &radial_p_tabs , 
										 const class SGI_radial_tabs_str &radial_n_tabs , 
										 const class baryons_data &prot_data_one_configuration_GSM , 
										 const class baryons_data &neut_data_one_configuration_GSM , 
										 const class HF_nucleons_data &neut_Y_HF_data , 
										 class HF_nucleons_data &prot_Y_HF_data)
{
  const enum particle_type particle = prot_Y_HF_data.get_particle ();
  
  if (particle != PROTON) abort_all ();

  const unsigned int Np_nlj = prot_Y_HF_data.get_N_nlj ();

  if (Np_nlj == 0) return;

  const int ZYval = prot_data_one_configuration_GSM.get_N_valence_nucleons_basis ();
  const int NYval = neut_data_one_configuration_GSM.get_N_valence_nucleons_basis ();

  if (ZYval >= 2) 
    {
      prot_trivially_equivalent_potentials_pp_part_calc (HO_diag , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_p_tabs , prot_data_one_configuration_GSM , prot_Y_HF_data);

      prot_trivially_equivalent_potentials_hole_double_counting_pp_part_remove (HO_diag , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_p_tabs , prot_Y_HF_data);
    }

  if ((ZYval >= 1) && (NYval >= 1)) 
    {
      prot_trivially_equivalent_potentials_pn_part_calc (HO_diag , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_n_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , prot_Y_HF_data);

      prot_trivially_equivalent_potentials_hole_double_counting_pn_part_remove (HO_diag , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_n_tabs , neut_Y_HF_data , prot_Y_HF_data);
    }

  trivially_equivalent_potentials_splines_calc (HO_diag , prot_Y_HF_data);
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_calc (
										 const bool HO_diag , 
										 const class CG_str &CGs , 
										 const class array<double> &Gaussian_table_GL , 
										 const class multipolar_expansion_str &multipolar_expansion , 
										 const class interaction_class &inter_data_basis , 
										 const class SGI_radial_tabs_str &radial_p_tabs , 
										 const class SGI_radial_tabs_str &radial_n_tabs , 
										 const class baryons_data &prot_data_one_configuration_GSM , 
										 const class baryons_data &neut_data_one_configuration_GSM , 
										 const class HF_nucleons_data &prot_Y_HF_data , 
										 class HF_nucleons_data &neut_Y_HF_data)
{
  const enum particle_type particle = neut_Y_HF_data.get_particle ();

  if (particle != NEUTRON) abort_all ();

  const unsigned int Nn_nlj = neut_Y_HF_data.get_N_nlj ();

  if (Nn_nlj == 0) return;

  const int ZYval = prot_data_one_configuration_GSM.get_N_valence_nucleons_basis () , NYval = neut_data_one_configuration_GSM.get_N_valence_nucleons_basis ();

  if (NYval >= 2) 
    {
      neut_trivially_equivalent_potentials_nn_part_calc (HO_diag , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_n_tabs , neut_data_one_configuration_GSM , neut_Y_HF_data);

      neut_trivially_equivalent_potentials_hole_double_counting_nn_part_remove (HO_diag , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_n_tabs , neut_Y_HF_data);
    }

  if ((ZYval >= 1) && (NYval >= 1)) 
    {
      neut_trivially_equivalent_potentials_pn_part_calc (HO_diag , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_p_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , neut_Y_HF_data);

      neut_trivially_equivalent_potentials_hole_double_counting_pn_part_remove (HO_diag , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_p_tabs , prot_Y_HF_data , neut_Y_HF_data);
    }

  trivially_equivalent_potentials_splines_calc (HO_diag , neut_Y_HF_data);
}

void MSDHF_potentials::SGI_MSGI_part::prot_trivially_equivalent_potentials_shells_pm_calc (
											   const int pm , 
											   const class CG_str &CGs , 
											   const class array<double> &Gaussian_table_GL , 
											   const class multipolar_expansion_str &multipolar_expansion , 
											   const class interaction_class &inter_data_basis , 
											   const class SGI_radial_tabs_str &radial_p_tabs , 
											   const class SGI_radial_tabs_str &radial_n_tabs , 
											   const class baryons_data &prot_data_one_configuration_GSM , 
											   const class baryons_data &neut_data_one_configuration_GSM , 
											   const class HF_nucleons_data &neut_Y_HF_data , 
											   class HF_nucleons_data &prot_Y_HF_data)
{
  const enum particle_type particle = prot_Y_HF_data.get_particle ();

  if (particle != PROTON) return;

  const unsigned int Np_nlj = prot_Y_HF_data.get_N_nlj ();

  if (Np_nlj == 0) return;

  const int ZYval = prot_data_one_configuration_GSM.get_N_valence_nucleons_basis ();
  const int NYval = neut_data_one_configuration_GSM.get_N_valence_nucleons_basis ();

  if (ZYval >= 2) 
    {
      prot_trivially_equivalent_potentials_pp_part_shells_pm_calc (pm , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_p_tabs , prot_data_one_configuration_GSM , prot_Y_HF_data);

      prot_trivially_equivalent_potentials_hole_double_counting_pp_part_shells_pm_remove (pm , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_p_tabs , prot_Y_HF_data);
    }

  if ((ZYval >= 1) && (NYval >= 1)) 
    {
      prot_trivially_equivalent_potentials_pn_part_shells_pm_calc (pm , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_n_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , prot_Y_HF_data);

      prot_trivially_equivalent_potentials_hole_double_counting_pn_part_shells_pm_remove (pm , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_n_tabs , neut_Y_HF_data , prot_Y_HF_data);
    }

  trivially_equivalent_potentials_splines_pm_calc (pm , prot_Y_HF_data);
}

void MSDHF_potentials::SGI_MSGI_part::neut_trivially_equivalent_potentials_shells_pm_calc (
											   const int pm , 
											   const class CG_str &CGs , 
											   const class array<double> &Gaussian_table_GL , 
											   const class multipolar_expansion_str &multipolar_expansion , 
											   const class interaction_class &inter_data_basis , 
											   const class SGI_radial_tabs_str &radial_p_tabs , 
											   const class SGI_radial_tabs_str &radial_n_tabs , 
											   const class baryons_data &prot_data_one_configuration_GSM , 
											   const class baryons_data &neut_data_one_configuration_GSM , 
											   const class HF_nucleons_data &prot_Y_HF_data , 
											   class HF_nucleons_data &neut_Y_HF_data)
{
  const enum particle_type particle = neut_Y_HF_data.get_particle ();

  if (particle != NEUTRON) return;

  const unsigned int Nn_nlj = neut_Y_HF_data.get_N_nlj ();

  if (Nn_nlj == 0) return;

  const int ZYval = prot_data_one_configuration_GSM.get_N_valence_nucleons_basis ();
  const int NYval = neut_data_one_configuration_GSM.get_N_valence_nucleons_basis ();

  if (NYval >= 2) 
    {
      neut_trivially_equivalent_potentials_nn_part_shells_pm_calc (pm , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_n_tabs , neut_data_one_configuration_GSM , neut_Y_HF_data);

      neut_trivially_equivalent_potentials_hole_double_counting_nn_part_shells_pm_remove (pm , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_n_tabs , neut_Y_HF_data);
    } 

  if ((ZYval >= 1) && (NYval >= 1)) 
    {
      neut_trivially_equivalent_potentials_pn_part_shells_pm_calc (pm , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_p_tabs , prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , neut_Y_HF_data);

      neut_trivially_equivalent_potentials_hole_double_counting_pn_part_shells_pm_remove (pm , Gaussian_table_GL , multipolar_expansion , inter_data_basis , radial_p_tabs , prot_Y_HF_data , neut_Y_HF_data);
    }

  trivially_equivalent_potentials_splines_pm_calc (pm , neut_Y_HF_data);
}

