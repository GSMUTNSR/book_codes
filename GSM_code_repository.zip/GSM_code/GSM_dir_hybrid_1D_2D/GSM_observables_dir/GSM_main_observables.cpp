#include "../GSM_include/GSM_include_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

enum called_code_type called_code = OBSERVABLES_CODE;

using namespace inputs_misc;
using namespace GSM_vector_dimensions;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    print_array_vector_test_status<int> ();

    //--// dummy variables

    class array<double> dummy_array_double;

    class array<string> dummy_array_string;

    class array<class input_data_str> dummy_input_data_tab;

    class input_data_str dummy_input_data;
    
    const class array <class array<class JT_coupled_TBME> > dummy_array_JT_coupled_TBME;
    
    //================================== input data and nucleons data ==================================//
    
    //--// initialization of the class which contains all input values and some pointers on tables (not all initialized here)

    class input_data_str input_data;

    call_common_routines::input_data_read_MPI_transfer (dummy_array_double , dummy_array_double , dummy_array_string , input_data , dummy_input_data , dummy_input_data_tab);
    
    //--// initialization of the classes which contain information on protons and neutrons

    class nucleons_data prot_data;
    class nucleons_data neut_data;

    nucleons_data_initialization (true , input_data , prot_data , neut_data);
    
    const enum space_type space = input_data.get_space ();
    
    //================================== Berggren one-body basis and space truncation  ==================================//

    radial_wfs_HF_data_HO_overlaps_basis_prot_neut_alloc_read_disk (input_data , prot_data , neut_data);
	
    space_truncation_data_best_hbar_omega_calc (true , input_data , prot_data , neut_data);
    
    //================================== GSM interaction  ==================================//

    //--// class which contains information on the interaction
    
    class interaction_class inter_data(true , false , false , input_data);

    inter_data.inter_data_calc (input_data);
    
    //================================== OBMEs, TBMEs ==================================//

    all_OBMEs_inter_HO_GHF_overlaps_alloc_read_disk (input_data , prot_data , neut_data);
    
    all_OBMEs_CM_reduced_r_grad_sets_alloc_read_disk (space , prot_data , neut_data);

    //--// initialization of the class which contains proton-neutron TBMEs

    class TBMEs_class TBMEs_pn;

    TBMEs_pp_nn_pn_alloc_read_disk (true , false , input_data , prot_data , neut_data , TBMEs_pn);
 
    //================================== configurations, SDs  ==================================//
    
    configuration_SD_sets::configuration_SD_tables_pp_nn_alloc_calc (true , false , false , input_data , prot_data , neut_data);
    
    //================================== GSM space dimensions ==================================//
        
    const int n_scat_max = input_data.get_n_scat_max ();

    const int n_scat_max_plus_one = n_scat_max + 1;

    const unsigned int J_index_max = J_index_max_calc (space , prot_data , neut_data);

    const unsigned int J_index_max_plus_one = J_index_max + 1;
    
    //--// initialization of the tables containing the GSM space dimensions at pole approximation and in full space

    class array<unsigned long int> total_space_dimensions_good_J_pole_approximation(2 , 1 , J_index_max_plus_one);

    class array<unsigned long int> total_space_dimensions_good_J(2 , n_scat_max_plus_one , J_index_max_plus_one);

    all_J_total_space_dimensions_calc_print (true , input_data , prot_data , neut_data , total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J);
    
    //================================== Calculations of SM observables ==================================//
    
    class GSM_vector PSI_full;
  
    const bool non_zero_NBMEs_proportion_only = input_data.get_non_zero_NBMEs_proportion_only ();
    
    //--// initialization of the table of classes containing GSM eigenstates quantum numbers (qn)

    const unsigned int eigensets_number = input_data.get_eigensets_number ();

    const unsigned int vectors_to_find_number_max = vectors_to_find_number_max_determine (input_data , total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J);    
    
    //--// initialization of the table of classes containing GSM eigenstates quantum numbers (qn)

    class array<class correlated_state_str> PSI_qn_tab(eigensets_number , vectors_to_find_number_max);

    input_data.PSI_quantum_numbers_tab_partial_fill (total_space_dimensions_good_J , PSI_qn_tab);
    
    //--// Calculations of observables at full space level

    if (!non_zero_NBMEs_proportion_only) GSM_observables::calculation (input_data , PSI_qn_tab , inter_data , TBMEs_pn , prot_data , neut_data , PSI_full);

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
    
    return 0;
  }


