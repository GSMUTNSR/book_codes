#include "../CC_include/CC_include_def.h"

using namespace Wigner_signs;
using namespace angular_matrix_elements;

using namespace CC_scalar_strength_MEs::radial_momentum;

// is_it_radial is always true here.

void CC_scalar_strength_MEs::cluster::MEs_calc (
						const bool is_it_Gauss_Legendre ,  
						const class CC_target_projectile_composite_data &Tpc_data , 
						const double rms_radius_CM_factor ,
						const unsigned int ic , 
						const unsigned int icp , 
						const class CC_state_class &CC_state , 
						const unsigned int ic_in , 
						const unsigned int ic_out,
						class array<TYPE> &MEs)
{
  const class array<class CC_channel_class> &channels_tab = CC_state.get_channels_tab ();
  
  const class CC_channel_class &channel_c_in = channels_tab(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab(ic_out);
  
  MEs = 0.0;
  
  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  if (LCM_projectile_in != LCM_projectile_out) return;
  
  const enum particle_type projectile_in  = channel_c_in.get_projectile ();
  const enum particle_type projectile_out = channel_c_out.get_projectile ();

  if (projectile_in != projectile_out) return;
  
  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  if (make_int (J_projectile_in - J_projectile_out) != 0) return;

  const class array<TYPE> &scalar_intrinsic_NBMEs_strength = Tpc_data.get_scalar_intrinsic_NBMEs_strength ();
    
  const unsigned int N_bef_R_GL = CC_state.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state.get_N_bef_R_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL)     : (N_bef_R_uniform);
    
  class array<TYPE> radial_CM_OBMEs(Nr);
  
  radial_momentum::radial_OBMEs_calc (R2_RADIAL , is_it_Gauss_Legendre , CC_state , ic_in , ic_out , radial_CM_OBMEs);
    
  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      const TYPE intrinsic_ME = scalar_intrinsic_NBMEs_strength(ic , icp , i);

      const TYPE radial_momentum_CM_ME = radial_CM_OBMEs(i);

      const TYPE CM_ME = rms_radius_CM_factor*radial_momentum_CM_ME;

      const TYPE ME = intrinsic_ME + CM_ME;
  
      MEs(i) = ME;
    }
}

