#include "../CC_include/CC_include_def.h"

using namespace Wigner_signs;
using namespace angular_matrix_elements;

using namespace CC_scalar_strength_MEs::radial_momentum;




// TYPE is double or complex
// -------------------------





// Calculation of the strength function of a scalar operator between two clusters
// ------------------------------------------------------------------------------
// One calculates <PSI[cluster-c'] | Op(r) | PSI[cluster-c]> for all r radii on [0:R], where the radial part reduces to one point (i.e. no integration over r).
// One has |PSI[cluster-c]> = [|N[HO-CM] L[CM]> |PSI[intrinsic-cluster-c]>]^JM, where CM is the center of mass of the projectile.
// For the moment, this routine is used only for rms radius one-body strength, so that Op(r) = r^2.
//
// One uses the decomposition Rrms^2[one-body] ~ Rrms^2[one-body][intrinsic] + rms_radius_CM_factor.R[CM]^2, which arises from r = r[intrinsic] + R[CM] in vector form.
// This matrix element is used only with non-antisymmetrized target-projectile states.
// Couplings between intrinsic and CM parts are then neglected because they occur only close to the target.
// rms_radius_CM_factor is defined in observables_basic_functions.cpp.
//
// One then has <PSI[cluster-c'] | Rrms^2[one-body] | PSI[cluster-c]> = <PSI[intrinsic-cluster-c'] | Rrms^2[one-body][intrinsic] | PSI[intrinsic-cluster-c]>.<u[c'](R[CM]) |           u[c](R[CM])>
//                                                                    + <PSI[intrinsic-cluster-c'] |                               PSI[intrinsic-cluster-c]>.<u[c'](R[CM]) | R[CM]^2 | u[c](R[CM])>.rms_radius_CM_factor .

void CC_scalar_strength_MEs::cluster::MEs_calc (
						const bool is_it_Gauss_Legendre ,  
						const class CC_target_projectile_composite_data &Tpc_data , 
						const double rms_radius_CM_factor ,
						const unsigned int ic , 
						const unsigned int icp , 
						const class CC_state_class &CC_state , 
						const unsigned int ic_in , 
						const unsigned int ic_out,
						class array<TYPE> &MEs)
{
  const class array<class CC_channel_class> &channels_tab = CC_state.get_channels_tab ();
  
  const class CC_channel_class &channel_c_in = channels_tab(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab(ic_out);
  
  MEs = 0.0;
  
  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  if (LCM_projectile_in != LCM_projectile_out) return;
  
  const enum particle_type projectile_in  = channel_c_in.get_projectile ();
  const enum particle_type projectile_out = channel_c_out.get_projectile ();

  if (projectile_in != projectile_out) return;
  
  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  if (make_int (J_projectile_in - J_projectile_out) != 0) return;

  const class array<TYPE> &scalar_intrinsic_NBMEs_strength = Tpc_data.get_scalar_intrinsic_NBMEs_strength ();
    
  const unsigned int N_bef_R_GL  = CC_state.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = CC_state.get_N_bef_R_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
    
  class array<TYPE> radial_overlap_CM_OBMEs(Nr);
  
  radial_momentum::radial_OBMEs_calc (OVERLAP , is_it_Gauss_Legendre , CC_state , ic_in , ic_out , radial_overlap_CM_OBMEs);
  
  class array<TYPE> radial_R2_CM_OBMEs(Nr);

  if (ic != icp)
    radial_R2_CM_OBMEs = 0.0;
  else
    radial_momentum::radial_OBMEs_calc (R2_RADIAL , is_it_Gauss_Legendre , CC_state , ic_in , ic_out , radial_R2_CM_OBMEs);
    
  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      const TYPE radial_overlap_CM_ME = radial_overlap_CM_OBMEs(i);
      
      const TYPE intrinsic_ME = scalar_intrinsic_NBMEs_strength(ic , icp , i);

      const TYPE radial_R2_CM_ME = radial_R2_CM_OBMEs(i);

      const TYPE rms_radius_CM_factor_R2_CM_ME = (ic == icp) ? (rms_radius_CM_factor*radial_R2_CM_ME) : (0.0);

      const TYPE ME = radial_overlap_CM_ME*intrinsic_ME + rms_radius_CM_factor_R2_CM_ME;
  
      MEs(i) = ME;
    }
}


