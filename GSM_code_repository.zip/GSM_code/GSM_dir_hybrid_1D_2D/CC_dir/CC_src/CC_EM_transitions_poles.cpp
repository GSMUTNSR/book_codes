#include "../CC_include/CC_include_def.h"

using namespace inputs_misc;
using namespace correlated_state_routines;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_observables_common;
using namespace CC_EM_transitions_MEs;
using namespace EM_transitions_common;
using namespace EM_transitions;
using namespace configuration_SD_in_space_one_jump_out_to_in;







// TYPE is double or complex
// -------------------------





// EM is for electromagnetic
// -------------------------

// E is for electric
// -----------------

// M is for magnetic
// -----------------







// Calculation of the EM transition reduced matrix element for a given suboperator between two channel wave functions
// ------------------------------------------------------------------------------------------------------------------
// One calculates <J[f] || EM || J[i]>.
// For this, one uses the decomposition <J[f] || EM || J[i]> = <J[f] || EM || J[i]> [nas] + (<J[f] || EM || J[i]> [as-HO] - <J[f] || EM || J[i]> [nas-HO]),
// where as means antisymmetrized channel functions and nas non-antisymmetrized channel functions.
// It is indeed impossible to calculate matrix elements with antisymmetrized channel functions directly because channel wave functions have two-body asymptotes, where target and projectile are not antisymmetrized.
//
// In nas, target and projectile arise from GSM and GSM-CC calculations but are not antisymmetrized with respect to each other in matrix elements formulas.
// One has EM = EM[projectile] + EM[target], so that one calculates separately the matrix elements of EM[projectile] and EM[target].
// nas matrix elements <J[f] || EM[target or projectile] || J[i]> = sum_{c[f], c[i]} <J[f] c[f] || EM[target or projectile] || J[i] c[i]>.
// <J[f] c[f] || EM[target or projectile] || J[i] c[i]> are then straightforward to calculate from <JT[f] c[f] || EM[target] or Id || JT[i] c[i]> and <Jp[f] || EM[projectile] or Id || Jp[i]>.
// <JT[f] c[f] || EM[target] || JT[i] c[i]> are given by shell model formulas and <Jp[f] || EM[projectile] || Jp[i]> are calculated in CC_EM_transitions_MEs::cluster or CC_EM_transitions_MEs::one_baryon.
// nas-HO is the same as nas except that channel wave functions and targets are all projected in the HO basis.
//
// In as, target and projectile are antisymmetrized in the HO basis : one projects all target and projectile states in the HO basis, so that antisymmetrization is handled with Slater determinants.
// Matrix elements of EM in as are then given by shell model formulas.
//
// As antisymmetrization effects between target and projectile only occur close to the target, it is sufficient to use the HO basis therein (as[HO]).
// The two-body asymptote is taken into account in the non-antisymmetrized calculation.
// It is clear that as, as-HO and nas, nas-HO matrix elements are equal at the limit of infinite HO basis.
// The previous decomposition is thus justified.





// Calculation of reduced EM transition matrix elements for all suboperators between all intrinsic clusters
// --------------------------------------------------------------------------------------------------------
// One calculates <PSI[intrinsic-cluster-c'] || EM || PSI[intrinsic-cluster-c]>.
// |PSI[intrinsic-cluster-c or intrinsic-cluster-c']> is the intrinsic wave function of the considered cluster c or c' projectile.
// For example, one has |PSI[cluster-c]> = [|N[HO-CM] L[CM]> |PSI[intrinsic-cluster-c]>]^JM, where CM is the center of mass of the projectile.

void CC_EM_transitions_poles::EM_suboperators_intrinsic_MEs_calc (
								  const TYPE &q , 
								  const int L , 
								  const bool is_it_longwavelength_approximation , 
								  const bool is_it_HO_expansion ,
								  const class interaction_class &inter_data_basis ,  
								  class array<class cluster_data> &cluster_projectile_data_tab , 
								  class CC_target_projectile_composite_data &Tpc_data ,
								  class GSM_vector &PSI_full)
{
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const unsigned int EM_suboperator_number = EM_suboperator_type_number_determine ();
  
  const unsigned int cluster_number = cluster_projectile_data_tab.dimension (0);

  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();

  const int n_holes_max = Tpc_data.get_n_holes_max ();
  
  const int n_scat_max = Tpc_data.get_n_scat_max ();
      
  const int E_relative_max_hw = Tpc_data.get_E_relative_max_hw ();
  
  const class GSM_vector_helper_class dummy_helper;
    
  class array<TYPE> &EM_suboperator_intrinsic_NBMEs = Tpc_data.get_EM_suboperator_intrinsic_NBMEs ();

  EM_suboperator_intrinsic_NBMEs = 0.0;
  
  // cluster intrinsic state
  for (unsigned int icp = 0 ; icp < cluster_number ; icp++)
    {      
      class cluster_data &data_cp = cluster_projectile_data_tab(icp);

      class baryons_data &cluster_prot_Y_data_HO_cp = data_cp.get_cluster_prot_Y_data_HO ();
      class baryons_data &cluster_neut_Y_data_HO_cp = data_cp.get_cluster_neut_Y_data_HO ();

      const unsigned int BP_cp = data_cp.get_BP_intrinsic ();
      
      const int Scp = data_cp.get_S_intrinsic ();
      
      const double Jcp = data_cp.get_J_intrinsic ();

      const double Mcp = Jcp;

      const int Zcp_cluster = data_cp.get_Z_cluster ();
      const int Ncp_cluster = data_cp.get_N_cluster ();

      const int n_holes_max_p_cp = cluster_prot_Y_data_HO_cp.get_n_holes_max ();
      const int n_holes_max_n_cp = cluster_neut_Y_data_HO_cp.get_n_holes_max ();
      
      const int n_scat_max_p_cp = cluster_prot_Y_data_HO_cp.get_n_scat_max ();
      const int n_scat_max_n_cp = cluster_neut_Y_data_HO_cp.get_n_scat_max ();

      const int n_scat_max_cp = min (n_scat_max , n_scat_max_p_cp + n_scat_max_n_cp);
      
      const int Ep_max_hw_cp = cluster_prot_Y_data_HO_cp.get_E_max_hw ();
      const int En_max_hw_cp = cluster_neut_Y_data_HO_cp.get_E_max_hw ();
      
      const int Ep_min_hw_cp = cluster_prot_Y_data_HO_cp.get_E_min_hw ();
      const int En_min_hw_cp = cluster_neut_Y_data_HO_cp.get_E_min_hw ();

      const int E_min_hw_cp = Ep_min_hw_cp + En_min_hw_cp;

      const int E_max_hw_cp = E_relative_max_hw + E_min_hw_cp;

      const enum space_type space_cp = space_determine (Zcp_cluster , Ncp_cluster);

      const class correlated_state_str PSI_cluster_qn_cp (Zcp_cluster , Ncp_cluster , BP_cp , Scp , Jcp , 0 , NADA , NADA , NADA , NADA , false);

      class GSM_vector_helper_class PSI_cluster_helper_cp (false , space_cp , TBME_inter , false , truncation_hw , truncation_ph ,
							   n_holes_max      , n_scat_max_cp   , E_max_hw_cp  , 
							   n_holes_max_p_cp , n_scat_max_p_cp , Ep_max_hw_cp ,
							   n_holes_max_n_cp , n_scat_max_n_cp , En_max_hw_cp , 
							   BP_cp , Mcp , true , cluster_prot_Y_data_HO_cp , cluster_neut_Y_data_HO_cp);

      class GSM_vector PSI_cluster_cp (PSI_cluster_helper_cp);

      PSI_cluster_cp.eigenvector_read_disk (true , true , PSI_cluster_qn_cp);
	  
      for (unsigned int ic = 0 ; ic < cluster_number ; ic++)
	{
	  class cluster_data &data_c = cluster_projectile_data_tab(ic);
 
	  const int Zc_cluster = data_c.get_Z_cluster ();
	  const int Nc_cluster = data_c.get_N_cluster ();

	  if ((Zcp_cluster == Zc_cluster) && (Ncp_cluster == Nc_cluster))
	    {
	      const int Sc = data_c.get_S_intrinsic ();
	      
	      const double Jc = data_c.get_J_intrinsic ();

	      const double Mc = Jc;

	      const int Lmin = abs (make_int (Jc - Jcp));
	      const int Lmax =      make_int (Jc + Jcp);
	      
	      if ((L < Lmin) || (L > Lmax))
		{
		  class baryons_data &cluster_prot_Y_data_HO_c = data_c.get_cluster_prot_Y_data_HO ();
		  class baryons_data &cluster_neut_Y_data_HO_c = data_c.get_cluster_neut_Y_data_HO ();
		  
		  const unsigned int BP_c = data_c.get_BP_intrinsic ();
	
		  const int n_holes_max_p_c = cluster_prot_Y_data_HO_c.get_n_holes_max ();
		  const int n_holes_max_n_c = cluster_neut_Y_data_HO_c.get_n_holes_max ();
		  
		  const int n_scat_max_p_c = cluster_prot_Y_data_HO_c.get_n_scat_max ();
		  const int n_scat_max_n_c = cluster_neut_Y_data_HO_c.get_n_scat_max ();

		  const int n_scat_max_c = min (n_scat_max , n_scat_max_p_c + n_scat_max_n_c);
		  
		  const int Ep_max_hw_c = cluster_prot_Y_data_HO_c.get_E_max_hw ();
		  const int En_max_hw_c = cluster_neut_Y_data_HO_c.get_E_max_hw ();
		  
		  const int Ep_min_hw_c = cluster_prot_Y_data_HO_c.get_E_min_hw ();
		  const int En_min_hw_c = cluster_neut_Y_data_HO_c.get_E_min_hw ();

		  const int E_min_hw_c = Ep_min_hw_c + En_min_hw_c;

		  const int E_max_hw_c = E_relative_max_hw + E_min_hw_c;

		  const enum space_type space_c = space_determine (Zc_cluster , Nc_cluster);

		  const class correlated_state_str PSI_cluster_qn_c (Zc_cluster , Nc_cluster , BP_c , Sc , Jc , 0 , NADA , NADA , NADA , NADA , false);

		  class GSM_vector_helper_class PSI_cluster_helper_c (false , space_c , TBME_inter , false , truncation_hw , truncation_ph ,
								      n_holes_max     , n_scat_max_c   , E_max_hw_c  , 
								      n_holes_max_p_c , n_scat_max_p_c , Ep_max_hw_c ,
								      n_holes_max_n_c , n_scat_max_n_c , En_max_hw_c , 
								      BP_c , Mc , true , cluster_prot_Y_data_HO_c , cluster_neut_Y_data_HO_c);

		  class GSM_vector PSI_cluster_c (PSI_cluster_helper_c);

		  PSI_cluster_c.eigenvector_read_disk (true , true , PSI_cluster_qn_c);
      
		  bool are_configuration_SD_in_space_one_jump_tables_calculated = false;
		  
		  for (unsigned int EM_suboperator_index = 0 ; EM_suboperator_index < EM_suboperator_number ; EM_suboperator_index++)
		    {
		      const enum EM_suboperator_type EM_suboperator = EM_suboperator_type_from_index (EM_suboperator_index);

		      const unsigned int BP_EM = BP_EM_suboperator_determine (EM_suboperator , L);
		      
		      // delta (quantum numbers are conserved)
  
		      if (binary_parity_product (BP_c , BP_cp) == BP_EM)
			{
			  if (!are_configuration_SD_in_space_one_jump_tables_calculated)
			    {
			      class GSM_vector_helper_class dummy_helper;
			      
			      class GSM_vector_helper_class PSI_cluster_helper_c_full;
			      
			      PSI_cluster_helper_c_full.allocate_fill_without_MPI_parallelization (PSI_cluster_helper_c);
			      
			      configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , true , false , false , false ,
											   PSI_cluster_helper_c_full , PSI_cluster_helper_cp , dummy_helper ,
											   cluster_prot_Y_data_HO_c , cluster_neut_Y_data_HO_c);
			      
			      are_configuration_SD_in_space_one_jump_tables_calculated = true;			      
			    }
			  	
			  const TYPE EM_suboperator_intrinsic_NBME = cluster::EM_suboperator_intrinsic_NBME_calc (EM_suboperator , q , L ,
														  is_it_longwavelength_approximation , is_it_HO_expansion , 
														  inter_data_basis , data_c , data_cp ,
														  PSI_cluster_c , PSI_cluster_cp , PSI_full);

			  if (THIS_PROCESS == MASTER_PROCESS) EM_suboperator_intrinsic_NBMEs(0 , 0 , ic , icp , L , EM_suboperator_index) = EM_suboperator_intrinsic_NBME;
			}//BP_EM test
		    }//loop EM_suboperator_index
		}// test L coupling
	    }//loop ic
	}//test N Z clusters
    }//loop icp
  
#ifdef UseMPI
  if (is_it_MPI_parallelized) EM_suboperator_intrinsic_NBMEs.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}
















// Calculation of the EM amplitude <J[f] || B(EM) || J[i]>
// -------------------------------------------------------

TYPE CC_EM_transitions_poles::B_amplitude_calc (
						const enum EM_type EM , 
						const bool is_it_longwavelength_approximation , 
						const bool is_it_HO_expansion , 
						const bool is_it_nas_only ,
						const int L , 
						const class CC_target_projectile_composite_data &Tpc_data , 
						const class input_data_str &input_data_CC_Berggren , 
						const class interaction_class &inter_data_basis ,  
						const class array<class cluster_data> &cluster_projectile_data_tab , 
						const class CC_Hamiltonian_data &CC_H_data_in , 
						const class CC_state_class &CC_state_in ,
						const class CC_Hamiltonian_data &CC_H_data_out ,  
						const class CC_state_class &CC_state_out , 
						class baryons_data &prot_Y_data , 
						class baryons_data &neut_Y_data ,
						class GSM_vector &PSI_full)
{
  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();
  
  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();

  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();

  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();
  
  const bool full_common_vectors_used_in_file = input_data_CC_Berggren.get_full_common_vectors_used_in_file ();
    
  const enum storage_type Hamiltonian_storage = input_data_CC_Berggren.get_Hamiltonian_storage ();

  const bool is_it_full_or_partial_storage = is_it_full_or_partial_storage_determine (Hamiltonian_storage);
  
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const int Z_cluster_max = (!is_it_one_baryon_COSM_case) ? (Z_cluster_max_determine (cluster_projectile_data_tab)) : (1);
  const int N_cluster_max = (!is_it_one_baryon_COSM_case) ? (N_cluster_max_determine (cluster_projectile_data_tab)) : (1);
  
  const int Z_cluster_number = Z_cluster_max + 1;
  const int N_cluster_number = N_cluster_max + 1;

  const complex<double> E_in_complex  = CC_state_in.get_E ();
  const complex<double> E_out_complex = CC_state_out.get_E ();
  
  const TYPE E_in  = generate_scalar<TYPE> (real (E_in_complex)  , imag (E_in_complex));
  const TYPE E_out = generate_scalar<TYPE> (real (E_out_complex) , imag (E_out_complex));
  
  const TYPE q = (E_in - E_out)/hbar_c;

  class array<class baryons_data> prot_Y_data_one_projectile_less_tab(Z_cluster_number , N_cluster_number , 2);
  class array<class baryons_data> neut_Y_data_one_projectile_less_tab(Z_cluster_number , N_cluster_number , 2);
  
  data_one_projectile_less_alloc_calc (is_it_full_or_partial_storage , is_it_one_baryon_COSM_case , TBME_inter , truncation_hw , truncation_ph , prot_Y_data , neut_Y_data , projectile_tab ,
				       cluster_projectile_data_tab , prot_Y_data_one_projectile_less_tab , neut_Y_data_one_projectile_less_tab);
  
  class array<TYPE> target_reduced_NBMEs(N_target_projectile_states , N_target_projectile_states);
  
  target_reduced_NBMEs = 0.0;
      
  composite::target_reduced_NBMEs_calc (PSI_full , EM , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , full_common_vectors_used_in_file , Tpc_data ,
					inter_data_basis , prot_Y_data_one_projectile_less_tab , neut_Y_data_one_projectile_less_tab , target_reduced_NBMEs);

  const TYPE B_amplitude = composite::CC_NBME_calc (EM , L , is_it_longwavelength_approximation , is_it_HO_expansion , 0 , 0 ,
						    Tpc_data , cluster_projectile_data_tab , is_it_nas_only , CC_H_data_in , CC_state_in , CC_H_data_out , CC_state_out , 
						    prot_Y_data , neut_Y_data , inter_data_basis , input_data_CC_Berggren , target_reduced_NBMEs , PSI_full);
  
  return B_amplitude;
}











// Calculation and print of the EM transitions associated to <J[f] || B(EM) || J[i]> for all the EM transitions listed in the input file
// -------------------------------------------------------------------------------------------------------------------------------------
// The decomposition <J[f] || B(EM) || J[i]> = <J[f] || B(EM) || J[i]> [nas] + (<J[f] || B(EM) || J[i]> [as-HO] - <J[f] || B(EM) || J[i]> [nas-HO]) is used here (see above).
// One also prints the EM transitions associated to <J[f] || B(EM) || J[i]> = <J[f] || B(EM) || J[i]> [nas] only.

void CC_EM_transitions_poles::calc_print (
					  const class input_data_str &input_data ,
					  const class input_data_str &input_data_CC_Berggren ,  
					  const class interaction_class &inter_data_basis ,
					  const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
					  const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
					  class baryons_data &prot_Y_data_CC_Berggren , 
					  class baryons_data &neut_Y_data_CC_Berggren , 
					  class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
					  class baryons_data &prot_Y_data , 
					  class baryons_data &neut_Y_data , 
					  class array<class cluster_data> &cluster_projectile_data_tab , 
					  class CC_target_projectile_composite_data &Tpc_data , 
					  class TBMEs_class &TBMEs_pn , 
					  class TBMEs_class &TBMEs_cv)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "EM transitions" << endl;
      cout <<         "--------------" << endl << endl;
    }

  const int Z = input_data.get_Z ();
  const int N = input_data.get_N ();
  const int A = input_data.get_A ();

  const int S = input_data.get_hypernucleus_strangeness ();
  
  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();

  const unsigned int N_bef_R_uniform = input_data_CC_Berggren.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = input_data_CC_Berggren.get_N_aft_R_uniform ();

  const unsigned int N_bef_R_GL = input_data_CC_Berggren.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = input_data_CC_Berggren.get_N_aft_R_GL ();

  const unsigned int Nk_momentum_GL = input_data_CC_Berggren.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = input_data_CC_Berggren.get_Nk_momentum_uniform ();
  
  const double R_real_max = input_data_CC_Berggren.get_R_real_max ();

  const double R = input_data_CC_Berggren.get_R ();

  const double kmax_momentum = input_data_CC_Berggren.get_kmax_momentum ();

  const double R_Fermi_momentum = input_data_CC_Berggren.get_R_Fermi_momentum ();

  const double R0_inter = inter_data_basis.get_R0 ();

  const double R0 = 1.27*cbrt (A);

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);

  const class array<unsigned int> &N_channels_tab = Tpc_data.get_N_channels_tab ();

  const class array<unsigned int> &BP_A_tab = Tpc_data.get_BP_A_tab (); 

  const class array<double> &J_A_tab = Tpc_data.get_J_A_tab ();
		  
  const class array<class CC_channel_class> &channels_tab = Tpc_data.get_channels_tab ();

  const unsigned int EM_transitions_number = input_data.get_EM_transitions_number ();

  const class array<enum EM_type> &EM_tab = input_data.get_EM_tab ();

  const class array<int> &EM_L_tab = input_data.get_EM_L_tab ();

  const class array<unsigned int> &EM_BP_IN_tab  = input_data.get_EM_BP_IN_tab ();
  const class array<unsigned int> &EM_BP_OUT_tab = input_data.get_EM_BP_OUT_tab ();

  const class array<double> &EM_J_IN_tab  = input_data.get_EM_J_IN_tab ();
  const class array<double> &EM_J_OUT_tab = input_data.get_EM_J_OUT_tab ();

  const class array<unsigned int> &EM_vector_index_IN_tab  = input_data.get_EM_vector_index_IN_tab ();
  const class array<unsigned int> &EM_vector_index_OUT_tab = input_data.get_EM_vector_index_OUT_tab (); 

  const class array<bool> &EM_is_it_longwavelength_approximation_tab = input_data.get_EM_is_it_longwavelength_approximation_tab ();
  
  const class array<bool> &EM_is_it_HO_expansion_tab = input_data.get_EM_is_it_HO_expansion_tab (); 

  class GSM_vector PSI_full;
  
  for (unsigned int EM_index = 0 ; EM_index < EM_transitions_number ; EM_index++)
    {
      const enum EM_type EM = EM_tab(EM_index);

      const int L = EM_L_tab(EM_index);

      const unsigned int BP_IN  = EM_BP_IN_tab(EM_index);
      const unsigned int BP_OUT = EM_BP_OUT_tab(EM_index);

      const unsigned int vector_index_IN  = EM_vector_index_IN_tab(EM_index);
      const unsigned int vector_index_OUT = EM_vector_index_OUT_tab(EM_index);

      const double J_IN  = EM_J_IN_tab(EM_index);
      const double J_OUT = EM_J_OUT_tab(EM_index);

      const double M_IN  = J_IN;
      const double M_OUT = J_OUT;

      class correlated_state_str PSI_IN_qn (Z , N , BP_IN  , S , J_IN  , vector_index_IN  , NADA , NADA , NADA , NADA , false);
      class correlated_state_str PSI_OUT_qn(Z , N , BP_OUT , S , J_OUT , vector_index_OUT , NADA , NADA , NADA , NADA , false);
            
      const unsigned int iJPi_IN  = JPi_index_determine (S , BP_A_tab , J_A_tab , BP_IN , J_IN);
      const unsigned int iJPi_OUT = JPi_index_determine (S , BP_A_tab , J_A_tab , BP_OUT , J_OUT);
      
      const unsigned int N_channels_JPi_IN  = N_channels_tab(iJPi_IN);
      const unsigned int N_channels_JPi_OUT = N_channels_tab(iJPi_OUT);

      class array<class CC_channel_class> channels_JPi_IN_tab  (N_channels_JPi_IN);
      class array<class CC_channel_class> channels_JPi_OUT_tab (N_channels_JPi_OUT);

      JPi_channels_tab_BP_J_vector_index_E_fill (S , channels_tab , BP_IN  , J_IN  , vector_index_IN  , NADA , channels_JPi_IN_tab);
      JPi_channels_tab_BP_J_vector_index_E_fill (S , channels_tab , BP_OUT , J_OUT , vector_index_OUT , NADA , channels_JPi_OUT_tab);

      class CC_state_class CC_state_IN (is_it_one_baryon_COSM_case , nmax_HO_lab_tab , cluster_projectile_data_tab , true , true , N_channels_JPi_IN ,
					NADA , channels_JPi_IN_tab , N_bef_R_uniform , N_aft_R_uniform , N_bef_R_GL , N_aft_R_GL , Nk_momentum_uniform , Nk_momentum_GL ,
					R , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , A , BP_IN , J_IN , M_IN , vector_index_IN , NADA);

      class CC_Hamiltonian_data CC_H_data_IN(N_channels_JPi_IN , input_data_CC_Berggren);
	    
      CC_eigenstate_H_data_calc (Tpc_data , inter_data_basis , input_data_CC_Berggren , 
				 prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab , 
				 prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , prot_Y_data , neut_Y_data , PSI_IN_qn , TBMEs_pn , TBMEs_cv , CC_H_data_IN , CC_state_IN);
  
      class CC_state_class CC_state_OUT (is_it_one_baryon_COSM_case , nmax_HO_lab_tab , cluster_projectile_data_tab , true , true , N_channels_JPi_OUT ,
					 NADA , channels_JPi_OUT_tab , N_bef_R_uniform , N_aft_R_uniform , N_bef_R_GL , N_aft_R_GL , Nk_momentum_uniform , Nk_momentum_GL , 
					 R , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , A , BP_OUT , J_OUT , M_OUT , vector_index_OUT , NADA); 

      class CC_Hamiltonian_data CC_H_data_OUT(N_channels_JPi_OUT , input_data_CC_Berggren);
	    
      CC_eigenstate_H_data_calc (Tpc_data , inter_data_basis , input_data_CC_Berggren , 
				 prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab , 
				 prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , prot_Y_data , neut_Y_data , PSI_OUT_qn , TBMEs_pn , TBMEs_cv , CC_H_data_OUT , CC_state_OUT);
      
      const bool is_it_longwavelength_approximation = EM_is_it_longwavelength_approximation_tab(EM_index);

      const bool is_it_HO_expansion = EM_is_it_HO_expansion_tab(EM_index);

      const complex<double> E_IN_complex  = PSI_IN_qn.get_E ();
      const complex<double> E_OUT_complex = PSI_OUT_qn.get_E (); 

      const TYPE E_IN  = generate_scalar<TYPE> (real (E_IN_complex)  , imag (E_IN_complex));
      const TYPE E_OUT = generate_scalar<TYPE> (real (E_OUT_complex) , imag (E_OUT_complex));
      
      const TYPE q = (E_IN - E_OUT)/hbar_c;

      if (!is_it_one_baryon_COSM_case) EM_suboperators_intrinsic_MEs_calc (q , L , is_it_longwavelength_approximation , is_it_HO_expansion ,
									   inter_data_basis , cluster_projectile_data_tab , Tpc_data , PSI_full);
		
      const TYPE B_amplitude_nas = B_amplitude_calc (EM , is_it_longwavelength_approximation , is_it_HO_expansion , true , L , Tpc_data , 
						     input_data_CC_Berggren , inter_data_basis , cluster_projectile_data_tab , CC_H_data_IN , CC_state_IN , CC_H_data_OUT , CC_state_OUT , prot_Y_data , neut_Y_data , PSI_full);
      
      const TYPE B_amplitude_as = B_amplitude_calc (EM , is_it_longwavelength_approximation , is_it_HO_expansion , false , L , Tpc_data , 
						    input_data_CC_Berggren , inter_data_basis , cluster_projectile_data_tab , CC_H_data_IN , CC_state_IN , CC_H_data_OUT , CC_state_OUT , prot_Y_data , neut_Y_data , PSI_full);

      if (THIS_PROCESS == MASTER_PROCESS)
	{  
	  if (is_it_HO_expansion)
	    cout << "HO expansion" << endl;
	  else
	    cout << "R cut" << endl;

	  cout << "Non antisymmetrized matrix elements " << endl;
	  
	  print_B_G (EM , q , L , is_it_longwavelength_approximation , A , PSI_IN_qn , PSI_OUT_qn , B_amplitude_nas);

	  cout << endl << "Antisymmetrized matrix elements " << endl;

	  print_B_G (EM , q , L , is_it_longwavelength_approximation , A , PSI_IN_qn , PSI_OUT_qn , B_amplitude_as);
	}
    }
}



