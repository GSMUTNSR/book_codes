#include "../CC_include/CC_include_def.h"

using namespace inputs_misc;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_observables_common;
using namespace correlated_state_routines;


// calculation of the antisymetrized + HO ME
void CC_overlap_function_composite::target_projectile_as_HO_NBMEs_calc (
									const bool is_it_one_nucleon_COSM_case , 
									const enum spectroscopic_factor_type SF , 
									const enum nucleus_type nucleus , 
									const enum particle_type projectile ,
									const double b_HO , 
									const int NCM_HO_max_projectile ,
									const int LCM_projectile ,
									const bool is_it_Gauss_Legendre , 
									const class CC_Hamiltonian_data &CC_H_data , 
									const class CC_state_class &CC_state , 
									const class input_data_str &input_data_CC_Berggren , 
									class nucleons_data &prot_data_out , 
									class nucleons_data &neut_data_out ,
									class array<class cluster_data> &cluster_projectile_data_tab , 
									const class array<class vector_class<complex<double> > > &CC_HO_overlaps , 
									const class correlated_state_str &PSI_in_qn , 
									const class correlated_state_str &PSI_out_qn , 
									const class correlated_state_str &PSI_projectile_qn , 
									const class array<double> &r_tab , 
									class array<TYPE> &target_projectile_as_HO_overlap_function_tab)
{
  target_projectile_as_HO_overlap_function_tab = 0.0;

  const bool full_common_vectors_used_in_file = input_data_CC_Berggren.get_full_common_vectors_used_in_file ();
  
  const unsigned int BP_in  = PSI_in_qn.get_BP ();
  const unsigned int BP_out = PSI_out_qn.get_BP ();

  const double J_in  = PSI_in_qn.get_J ();
  const double J_out = PSI_out_qn.get_J ();
  
  const double M_in  = J_in;
  const double M_out = J_out;

  const int Z_in = PSI_in_qn.get_Z ();
  const int N_in = PSI_in_qn.get_N ();

  const int Z_out = PSI_out_qn.get_Z  ();
  const int N_out = PSI_out_qn.get_N ();

  const int Z_projectile = PSI_projectile_qn.get_Z ();
  const int N_projectile = PSI_projectile_qn.get_N ();

  if (Z_in != N_nucleons_IN_spectroscopic_factor_determine (Z_out , Z_projectile , SF)) return;
  if (N_in != N_nucleons_IN_spectroscopic_factor_determine (N_out , N_projectile , SF)) return;

  const unsigned int BP_projectile = PSI_projectile_qn.get_BP ();

  const double J_projectile = PSI_projectile_qn.get_J ();

  if (binary_parity_product (BP_in , BP_projectile) != BP_out) return;

  const double Jmin = abs (J_out - J_in);

  const double Jmax = J_out + J_in;

  if ((make_int (J_projectile - Jmin) < 0) || (make_int (J_projectile - Jmax) > 0)) return;
	
  const double M_projectile = spectroscopic_factor_cluster_m_projection_calc (SF , M_in , M_out);

  const class ljm_struct LJM_projectile(LCM_projectile , J_projectile , M_projectile , NADA);

  // composite states (they have to be read in files)
  // they correspond to the [a^+ PSI_GSM]_M^J

  const enum space_type space_out = input_data_CC_Berggren.get_space ();

  const enum interaction_type inter = input_data_CC_Berggren.get_inter ();

  const bool truncation_hw = input_data_CC_Berggren.get_truncation_hw ();
  const bool truncation_ph = input_data_CC_Berggren.get_truncation_ph ();

  const int n_holes_max = input_data_CC_Berggren.get_n_holes_max ();
  
  const int n_scat_max_out = input_data_CC_Berggren.get_n_scat_max ();

  const int E_max_hw = input_data_CC_Berggren.get_E_max_hw ();
  
  const int n_holes_max_p_out = prot_data_out.get_n_holes_max ();
  const int n_holes_max_n_out = neut_data_out.get_n_holes_max ();
  
  const int n_scat_max_p_out = prot_data_out.get_n_scat_max ();
  const int n_scat_max_n_out = neut_data_out.get_n_scat_max ();

  const int Ep_max_hw_out = prot_data_out.get_E_max_hw ();
  const int En_max_hw_out = neut_data_out.get_E_max_hw ();

  class GSM_vector_helper_class PSI_HO_out_helper (is_it_MPI_parallelized , space_out , inter , false , truncation_hw , truncation_ph ,
						   n_holes_max       , n_scat_max_out   , E_max_hw ,
						   n_holes_max_p_out , n_scat_max_p_out , Ep_max_hw_out ,
						   n_holes_max_n_out , n_scat_max_n_out , En_max_hw_out , BP_out , M_out , true , prot_data_out , neut_data_out);

  class GSM_vector PSI_HO_out (PSI_HO_out_helper);

  target_projectile_PSI_HO_calc (is_it_one_nucleon_COSM_case , input_data_CC_Berggren , cluster_projectile_data_tab , CC_H_data , CC_state , CC_HO_overlaps , prot_data_out , neut_data_out , PSI_HO_out);
  
  PSI_HO_out.space_dimension_SDs_components_eigenvector_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_out_qn);

  overlap_function::calc (full_common_vectors_used_in_file , SF , nucleus , projectile , b_HO , NCM_HO_max_projectile , LJM_projectile , is_it_Gauss_Legendre ,
			  PSI_in_qn , PSI_out_qn , PSI_projectile_qn , PSI_HO_out , r_tab , target_projectile_as_HO_overlap_function_tab);

#ifdef UseMPI
  if (is_it_MPI_parallelized) target_projectile_as_HO_overlap_function_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}

























// projectile
// for the non antisymmetrized (nas) NBME
// the CC_state_out/in are used
// common to nas and nas+HO
void CC_overlap_function_composite::projectile_nas_NBMEs_calc (
							       const enum spectroscopic_factor_type SF , 
							       const enum particle_type projectile , 
							       const int LCM_projectile ,
							       const bool is_it_Gauss_Legendre , 
							       const class CC_state_class &CC_state ,
							       const class correlated_state_str &PSI_in_qn , 
							       const class correlated_state_str &PSI_out_qn , 
							       const class correlated_state_str &PSI_projectile_qn , 
							       class array<TYPE> &projectile_nas_overlap_function_tab)
{
  const unsigned int BP_projectile = PSI_projectile_qn.get_BP ();

  const double J_projectile = PSI_projectile_qn.get_J ();

  const int Z_projectile = PSI_projectile_qn.get_Z ();
  const int N_projectile = PSI_projectile_qn.get_N ();

  const unsigned int BP_in  = PSI_in_qn.get_BP ();
  const unsigned int BP_out = PSI_out_qn.get_BP ();

  if (binary_parity_product (BP_in , BP_projectile) != BP_out) return;

  const double J_in  = PSI_in_qn.get_J ();
  const double J_out = PSI_out_qn.get_J ();

  const int Z_in = PSI_in_qn.get_Z ();
  const int N_in = PSI_in_qn.get_N ();

  const int Z_out = PSI_out_qn.get_Z ();
  const int N_out = PSI_out_qn.get_N ();

  if (Z_in != N_nucleons_IN_spectroscopic_factor_determine (Z_out , Z_projectile , SF)) return;
  if (N_in != N_nucleons_IN_spectroscopic_factor_determine (N_out , N_projectile , SF)) return;

  const double Jmin = abs (J_out - J_in);

  const double Jmax = J_out + J_in;

  if ((make_int (J_projectile - Jmin) < 0) || (make_int (J_projectile - Jmax) > 0)) return;

  CC_state.overlap_function_calc (is_it_Gauss_Legendre , PSI_in_qn , projectile , LCM_projectile , J_projectile , projectile_nas_overlap_function_tab);
}







void CC_overlap_function_composite::calc (
					  const bool is_it_one_nucleon_COSM_case , 
					  const enum spectroscopic_factor_type SF , 
					  const enum nucleus_type nucleus , 
					  const enum particle_type projectile , 
					  const double b_HO , 
					  const int NCM_HO_max_projectile ,
					  const int LCM_projectile ,
					  const bool is_it_Gauss_Legendre , 
					  const bool is_it_nas_only , 
					  const class CC_Hamiltonian_data &CC_H_data , 
					  const class CC_state_class &CC_state , 
					  class nucleons_data &prot_data_out , 
					  class nucleons_data &neut_data_out ,
					  class array<class cluster_data> &cluster_projectile_data_tab , 
					  const class input_data_str &input_data_CC_Berggren , 
					  const class correlated_state_str &PSI_in_qn , 
					  const class correlated_state_str &PSI_out_qn , 
					  const class correlated_state_str &PSI_projectile_qn , 
					  const class array<double> &r_tab , 
					  class array<TYPE> &overlap_function_tab)
{
  const unsigned int N_bef_R_GL = CC_state.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
   
  //================================== projectile ==================================//
  // for the non antisymetrized (nas) the CC_state_out/in are used
  // for the non antisymetrized + HO (nas_HO) the CC_state_out/in are projected in the HO basis

  // projection of the CC state in the HO basis

  class CC_state_class CC_state_HO (CC_state);

  CC_state_HO.CC_HO_wfs_projection ();

  //===================================non antisymetrized (nas)==============================================================================

  class array<TYPE> projectile_nas_overlap_function_tab(Nr);

  // sum of the reduced matrix elts for the projectile
  projectile_nas_NBMEs_calc (SF , projectile , LCM_projectile , is_it_Gauss_Legendre , CC_state , PSI_in_qn , PSI_out_qn , PSI_projectile_qn , projectile_nas_overlap_function_tab);

  // calculation of <Jf || O_L || Ji> = sum_{cf , ci} ( cf_<Jf || O_L (p) || Ji>_ci + cf_<Jf || O_L (T) || Ji>_ci )
  // nas

  if (is_it_nas_only)
    {
      overlap_function_tab = projectile_nas_overlap_function_tab;

      return;
    }

  class array<TYPE> projectile_nas_HO_overlap_function_tab(Nr);

  class array<TYPE> target_projectile_as_HO_overlap_function_tab(Nr);

  // sum of the reduced matrix elts for the projectile (HO)

  projectile_nas_NBMEs_calc (SF , projectile , LCM_projectile , is_it_Gauss_Legendre , CC_state_HO , PSI_in_qn , PSI_out_qn , PSI_projectile_qn , projectile_nas_HO_overlap_function_tab);

  //================================== antisymetrized and HO projection (as_HO) ===================================//
  //===============================================================================================================//


  //================================== CC_HO overlaps (<u_c^{HO} | u_n>) ==================================//

  // for the composite state
  const class array<class vector_class<complex<double> > > &CC_HO_overlaps = CC_state.get_HO_overlaps ();

  //================================== calculation of the antisymetrized + HO ME ==================================//

  // <Jf || O_L || Ji>
  // antisymetrized andf in the HO basis
  target_projectile_as_HO_NBMEs_calc (is_it_one_nucleon_COSM_case , SF , nucleus , projectile , b_HO , NCM_HO_max_projectile , LCM_projectile , is_it_Gauss_Legendre , CC_H_data , CC_state , input_data_CC_Berggren ,
				      prot_data_out , neut_data_out , cluster_projectile_data_tab ,  CC_HO_overlaps , PSI_in_qn , PSI_out_qn , PSI_projectile_qn , r_tab , target_projectile_as_HO_overlap_function_tab);
  
  // final result
  overlap_function_tab = projectile_nas_overlap_function_tab + (target_projectile_as_HO_overlap_function_tab - projectile_nas_HO_overlap_function_tab);
}



