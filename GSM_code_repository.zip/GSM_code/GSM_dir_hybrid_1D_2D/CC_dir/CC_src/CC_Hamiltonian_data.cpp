#include "../CC_include/CC_include_def.h"

using namespace string_routines;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;

CC_Hamiltonian_data::CC_Hamiltonian_data () :
  N_channels (0) , 
  N_restarts (0) , 
  Davidson_max_dimension (0) , 
  Davidson_eigenvector_precision (0) , 
  relative_SVD_precision (0) , 
  R_cut_function (0.0) , 
  d_cut_function (0.0) , 
  Ueq_regularizor (0.0) , 
  CC_average_n_scat_target_projectile_max (0.0) , 
  dimension_matrices_pole_approximation (0) , 
  dimension_matrices (0) , 
  dimension_matrices_HO (0) , 
  dimension_matrices_pole_approximation_CC_Berggren (0) , 
  dimension_matrices_partial_pole_approximation_CC_Berggren (0) , 
  dimension_matrices_CC_Berggren (0)
{}

CC_Hamiltonian_data::CC_Hamiltonian_data (
					  const unsigned int N_channels_c , 
					  const class input_data_str &input_data_CC_Berggren) :
  N_channels (0) , 
  N_restarts (0) , 
  Davidson_max_dimension (0) , 
  Davidson_eigenvector_precision (0) , 
  relative_SVD_precision (0) , 
  R_cut_function (0.0) , 
  d_cut_function (0.0) , 
  Ueq_regularizor (0.0) , 
  CC_average_n_scat_target_projectile_max (0.0) , 
  dimension_matrices_pole_approximation (0) , 
  dimension_matrices (0) , 
  dimension_matrices_HO (0) , 
  dimension_matrices_pole_approximation_CC_Berggren (0) , 
  dimension_matrices_partial_pole_approximation_CC_Berggren (0) , 
  dimension_matrices_CC_Berggren (0)
{
  allocate (N_channels_c , input_data_CC_Berggren);
}

CC_Hamiltonian_data::CC_Hamiltonian_data (const class CC_Hamiltonian_data &X) :
  N_channels (0) , 
  N_restarts (0) , 
  Davidson_max_dimension (0) , 
  Davidson_eigenvector_precision (0) , 
  relative_SVD_precision (0) , 
  R_cut_function (0.0) , 
  d_cut_function (0.0) , 
  Ueq_regularizor (0.0) , 
  CC_average_n_scat_target_projectile_max (0.0) , 
  dimension_matrices_pole_approximation (0) , 
  dimension_matrices (0) , 
  dimension_matrices_HO (0) , 
  dimension_matrices_pole_approximation_CC_Berggren (0) , 
  dimension_matrices_partial_pole_approximation_CC_Berggren (0) , 
  dimension_matrices_CC_Berggren (0)
{
  allocate_fill (X);
}

void CC_Hamiltonian_data::allocate (
				    const unsigned int N_channels_c , 
				    const class input_data_str &input_data_CC_Berggren)
{
  N_channels = N_channels_c;

  N_restarts = input_data_CC_Berggren.get_CC_Davidson_N_restarts ();

  Davidson_max_dimension = input_data_CC_Berggren.get_CC_Davidson_max_dimension ();

  Davidson_eigenvector_precision = input_data_CC_Berggren.get_CC_Davidson_eigenvector_precision ();

  relative_SVD_precision = input_data_CC_Berggren.get_CC_relative_SVD_precision (); 

  R_cut_function = input_data_CC_Berggren.get_R_cut_function (); 

  d_cut_function = input_data_CC_Berggren.get_d_cut_function (); 

  Ueq_regularizor = input_data_CC_Berggren.get_Ueq_regularizor ();

  CC_average_n_scat_target_projectile_max = input_data_CC_Berggren.get_CC_average_n_scat_target_projectile_max ();

  dimension_matrices_pole_approximation = 0; 

  dimension_matrices = 0; 

  dimension_matrices_HO = 0; 

  dimension_matrices_pole_approximation_CC_Berggren = 0; 

  dimension_matrices_partial_pole_approximation_CC_Berggren = 0; 

  dimension_matrices_CC_Berggren = 0;
}






void CC_Hamiltonian_data::allocate_fill (const class CC_Hamiltonian_data &X)
{
  N_channels = X.N_channels; 

  N_restarts = X.N_restarts;

  Davidson_max_dimension = X.Davidson_max_dimension;

  Davidson_eigenvector_precision = X.Davidson_eigenvector_precision;

  relative_SVD_precision = X.relative_SVD_precision;

  R_cut_function = X.R_cut_function;
  d_cut_function = X.d_cut_function; 

  Ueq_regularizor = X.Ueq_regularizor; 

  CC_average_n_scat_target_projectile_max = X.CC_average_n_scat_target_projectile_max;

  dimension_matrices_pole_approximation = X.dimension_matrices_pole_approximation;

  dimension_matrices = X.dimension_matrices; 

  dimension_matrices_HO = X.dimension_matrices_HO;

  dimension_matrices_pole_approximation_CC_Berggren = X.dimension_matrices_pole_approximation_CC_Berggren; 

  dimension_matrices_partial_pole_approximation_CC_Berggren = X.dimension_matrices_partial_pole_approximation_CC_Berggren;

  dimension_matrices_CC_Berggren = X.dimension_matrices_CC_Berggren;

  multipolar_expansion.allocate_fill (X.multipolar_expansion);

  CGs.allocate_fill (X.CGs);

  HO_wfs_bef_R_tab_uniform.allocate_fill (X.HO_wfs_bef_R_tab_uniform);

  HO_wfs_bef_R_tab_GL.allocate_fill (X.HO_wfs_bef_R_tab_GL);
  HO_wfs_aft_R_tab_GL.allocate_fill (X.HO_wfs_bef_R_tab_GL);

  Gaussian_table_GL.allocate_fill (X.Gaussian_table_GL);

  CC_corrective_factors_TBMEs_tab.allocate_fill (X.CC_corrective_factors_TBMEs_tab);
  
  CC_corrective_factors_cluster_tab.allocate_fill (X.CC_corrective_factors_cluster_tab);

  if (X.QCM_HO_submatrices.is_it_filled ())
    {
      QCM_HO_submatrices.allocate (N_channels , N_channels);

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	QCM_HO_submatrices(ic).allocate_fill (X.QCM_HO_submatrices(ic));
    }

  if (X.QCM_HCM_QCM_HO_submatrices.is_it_filled ())
    {
      QCM_HCM_QCM_HO_submatrices.allocate (N_channels , N_channels);

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	QCM_HCM_QCM_HO_submatrices(ic).allocate_fill (X.QCM_HCM_QCM_HO_submatrices(ic));
    }

  if (X.PCM_HCM_PCM_HO_submatrices.is_it_filled ())
    {
      PCM_HCM_PCM_HO_submatrices.allocate (N_channels , N_channels);

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	PCM_HCM_PCM_HO_submatrices(ic).allocate_fill (X.PCM_HCM_PCM_HO_submatrices(ic));
    }

  if (X.finite_range_orthogonalized_potential_HO_submatrices.is_it_filled ())
    {	
      finite_range_orthogonalized_potential_HO_submatrices.allocate (N_channels , N_channels);

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	  finite_range_orthogonalized_potential_HO_submatrices(ic , icp).allocate_fill (X.finite_range_orthogonalized_potential_HO_submatrices(ic , icp));
    }

  if (X.finite_range_overlaps_HO_submatrices.is_it_filled ())
    {	
      finite_range_overlaps_HO_submatrices.allocate (N_channels , N_channels);

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	  finite_range_overlaps_HO_submatrices(ic , icp).allocate_fill (X.finite_range_overlaps_HO_submatrices(ic , icp));
    }

  if (X.finite_range_potential_HO_submatrices.is_it_filled ())
    {	
      finite_range_potential_HO_submatrices.allocate (N_channels , N_channels);

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	  finite_range_potential_HO_submatrices(ic , icp).allocate_fill (X.finite_range_potential_HO_submatrices(ic , icp));
    }

  if (X.Delta_HO_submatrices.is_it_filled ())
    {	
      Delta_HO_submatrices.allocate (N_channels , N_channels);

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	  Delta_HO_submatrices(ic , icp).allocate_fill (X.Delta_HO_submatrices(ic , icp));
    }

  is_it_forbidden_channel_tab.allocate_fill (X.is_it_forbidden_channel_tab);

  is_it_forbidden_channel_CC_Berggren_tab.allocate_fill (X.is_it_forbidden_channel_CC_Berggren_tab);

  matrices_indices.allocate_fill (X.matrices_indices);

  matrices_indices_HO.allocate_fill (X.matrices_indices_HO);

  matrices_indices_CC_Berggren.allocate_fill (X.matrices_indices_CC_Berggren);

  finite_range_overlaps_HO_matrix.allocate_fill (X.finite_range_overlaps_HO_matrix);

  finite_range_potential_HO_matrix.allocate_fill (X.finite_range_potential_HO_matrix);

  Ho_HO_matrix.allocate_fill (X.Ho_HO_matrix);

  finite_range_orthogonalized_potential_HO_matrix.allocate_fill (X.finite_range_orthogonalized_potential_HO_matrix);

  overlaps_HO_matrix.allocate_fill (X.overlaps_HO_matrix);

  sqrt_overlaps_HO_matrix.allocate_fill (X.sqrt_overlaps_HO_matrix);

  sqrt_inv_overlaps_HO_matrix.allocate_fill (X.sqrt_inv_overlaps_HO_matrix);

  H_HO_matrix.allocate_fill (X.H_HO_matrix);

  H_Delta_plus_Delta_H_HO_matrix.allocate_fill (X.H_Delta_plus_Delta_H_HO_matrix);

  Delta_H_Delta_HO_matrix.allocate_fill (X.Delta_H_Delta_HO_matrix);

  Delta_HO_matrix.allocate_fill (X.Delta_HO_matrix);

  overlaps_matrix_pole_approximation.allocate_fill (X.overlaps_matrix_pole_approximation);

  H_matrix_pole_approximation.allocate_fill (X.H_matrix_pole_approximation);

  overlaps_matrix.allocate_fill (X.overlaps_matrix);

  H_matrix.allocate_fill (X.H_matrix);

  orthogonalized_H_matrix_CC_Berggren.allocate_fill (X.orthogonalized_H_matrix_CC_Berggren);

  orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren.allocate_fill (X.orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren);

  orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren.allocate_fill (X.orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren);

  orthogonalized_H_tridiagonalized_diagonal_CC_Berggren.allocate_fill (X.orthogonalized_H_tridiagonalized_diagonal_CC_Berggren);

  orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren.allocate_fill (X.orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren);

  Ueq_tab.allocate_fill (X.Ueq_tab);

  source_tab.allocate_fill (X.source_tab);
}







void CC_Hamiltonian_data::deallocate ()
{
  multipolar_expansion.deallocate ();

  CGs.deallocate ();

  HO_wfs_bef_R_tab_uniform.deallocate ();

  HO_wfs_bef_R_tab_GL.deallocate ();
  HO_wfs_aft_R_tab_GL.deallocate ();

  Gaussian_table_GL.deallocate ();

  CC_corrective_factors_TBMEs_tab.deallocate ();
  
  CC_corrective_factors_cluster_tab.deallocate ();

  QCM_HO_submatrices.deallocate ();

  QCM_HCM_QCM_HO_submatrices.deallocate ();
  PCM_HCM_PCM_HO_submatrices.deallocate ();

  finite_range_orthogonalized_potential_HO_submatrices.deallocate ();

  finite_range_overlaps_HO_submatrices.deallocate ();
  
  finite_range_potential_HO_submatrices.deallocate ();

  Delta_HO_submatrices.deallocate ();

  is_it_forbidden_channel_tab.deallocate ();

  is_it_forbidden_channel_CC_Berggren_tab.deallocate ();

  matrices_indices.deallocate ();

  matrices_indices_HO.deallocate ();

  matrices_indices_CC_Berggren.deallocate ();

  finite_range_overlaps_HO_matrix.deallocate ();

  finite_range_potential_HO_matrix.deallocate ();

  Ho_HO_matrix.deallocate ();

  finite_range_orthogonalized_potential_HO_matrix.deallocate ();

  overlaps_HO_matrix.deallocate ();

  sqrt_overlaps_HO_matrix.deallocate ();

  sqrt_inv_overlaps_HO_matrix.deallocate ();

  H_HO_matrix.deallocate ();

  H_Delta_plus_Delta_H_HO_matrix.deallocate ();

  Delta_H_Delta_HO_matrix.deallocate ();

  Delta_HO_matrix.deallocate ();

  overlaps_matrix_pole_approximation.deallocate ();

  H_matrix_pole_approximation.deallocate ();

  overlaps_matrix.deallocate ();

  H_matrix.deallocate ();

  orthogonalized_H_matrix_CC_Berggren.deallocate ();

  orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren.deallocate ();

  orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren.deallocate ();

  orthogonalized_H_tridiagonalized_diagonal_CC_Berggren.deallocate ();

  orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren.deallocate ();

  Ueq_tab.deallocate ();

  source_tab.deallocate ();
}









void CC_Hamiltonian_data::submatrices_realloc_one_baryon_init (
							       const class array<class CC_channel_class> &channels_tab , 
							       const class array<int> &nmax_HO_lab_tab)
{
  finite_range_orthogonalized_potential_HO_submatrices.deallocate ();

  finite_range_overlaps_HO_submatrices.deallocate ();
  
  finite_range_potential_HO_submatrices.deallocate ();

  Delta_HO_submatrices.deallocate ();

  finite_range_orthogonalized_potential_HO_submatrices.allocate (N_channels , N_channels);

  finite_range_overlaps_HO_submatrices.allocate (N_channels , N_channels);

  finite_range_potential_HO_submatrices.allocate (N_channels , N_channels);

  Delta_HO_submatrices.allocate (N_channels , N_channels);

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const int lc = channel_c.get_LCM_projectile ();

      const int nmax_HO_c_plus_one = nmax_HO_lab_tab(lc) + 1;

      for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	{
	  const class CC_channel_class &channel_cp = channels_tab(icp);

	  const int lcp = channel_cp.get_LCM_projectile ();

	  const int nmax_HO_cp_plus_one = nmax_HO_lab_tab(lcp) + 1;

	  class matrix<complex<double> > &finite_range_orthogonalized_potential_HO_submatrix = finite_range_orthogonalized_potential_HO_submatrices(ic , icp);

	  class matrix<complex<double> > &finite_range_overlaps_HO_submatrix = finite_range_overlaps_HO_submatrices(ic , icp);
	  
	  class matrix<complex<double> > &finite_range_potential_HO_submatrix = finite_range_potential_HO_submatrices(ic , icp);

	  class matrix<complex<double> > &Delta_HO_submatrix = Delta_HO_submatrices(ic , icp);

	  finite_range_orthogonalized_potential_HO_submatrix.allocate (nmax_HO_c_plus_one , nmax_HO_cp_plus_one);

	  finite_range_overlaps_HO_submatrix.allocate (nmax_HO_c_plus_one , nmax_HO_cp_plus_one);
	  
	  finite_range_potential_HO_submatrix.allocate (nmax_HO_c_plus_one , nmax_HO_cp_plus_one);

	  Delta_HO_submatrix.allocate (nmax_HO_c_plus_one , nmax_HO_cp_plus_one);

	  finite_range_orthogonalized_potential_HO_submatrix = 0.0;

	  finite_range_overlaps_HO_submatrix = 0.0;
	  
	  finite_range_potential_HO_submatrix = 0.0;

	  Delta_HO_submatrix = 0.0;
	}
    }
}





void CC_Hamiltonian_data::submatrices_realloc_cluster_init (
							    const class array<class CC_channel_class> &channels_tab , 
							    const class array<class cluster_data> &cluster_projectile_data_tab)
{
  QCM_HO_submatrices.deallocate ();

  QCM_HCM_QCM_HO_submatrices.deallocate ();
  PCM_HCM_PCM_HO_submatrices.deallocate ();

  finite_range_orthogonalized_potential_HO_submatrices.deallocate ();

  finite_range_overlaps_HO_submatrices.deallocate ();
  
  finite_range_potential_HO_submatrices.deallocate ();

  Delta_HO_submatrices.deallocate ();

  QCM_HO_submatrices.allocate (N_channels);

  QCM_HCM_QCM_HO_submatrices.allocate (N_channels);
  PCM_HCM_PCM_HO_submatrices.allocate (N_channels);

  finite_range_orthogonalized_potential_HO_submatrices.allocate (N_channels , N_channels);

  finite_range_overlaps_HO_submatrices.allocate (N_channels , N_channels);
  
  finite_range_potential_HO_submatrices.allocate (N_channels , N_channels);

  Delta_HO_submatrices.allocate (N_channels , N_channels);

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {	
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);	

      const class array<int> &Nmax_HO_tab_c = data_c.get_Nmax_HO_tab ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const int NCM_HO_max_LCM_projectile_c_plus_one = Nmax_HO_tab_c(LCM_projectile_c) + 1;

      class matrix<complex<double> > &QCM_HO_submatrix = QCM_HO_submatrices(ic);

      class matrix<complex<double> > &QCM_HCM_QCM_HO_submatrix = QCM_HCM_QCM_HO_submatrices(ic);

      class matrix<double> &PCM_HCM_PCM_HO_submatrix = PCM_HCM_PCM_HO_submatrices(ic);

      QCM_HO_submatrix.allocate (NCM_HO_max_LCM_projectile_c_plus_one , NCM_HO_max_LCM_projectile_c_plus_one);

      QCM_HCM_QCM_HO_submatrix.allocate (NCM_HO_max_LCM_projectile_c_plus_one , NCM_HO_max_LCM_projectile_c_plus_one);
      PCM_HCM_PCM_HO_submatrix.allocate (NCM_HO_max_LCM_projectile_c_plus_one , NCM_HO_max_LCM_projectile_c_plus_one);

      for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	{
	  const class CC_channel_class &channel_cp = channels_tab(icp);
	  
	  const enum particle_type projectile_cp = channel_cp.get_projectile ();

	  const class cluster_data &data_cp = get_cluster_projectile_data (projectile_cp , cluster_projectile_data_tab);	

	  const class array<int> &Nmax_HO_tab_cp = data_cp.get_Nmax_HO_tab ();

	  const int LCM_projectile_cp = channel_cp.get_LCM_projectile ();

	  const int NCM_HO_max_LCM_projectile_cp_plus_one = Nmax_HO_tab_cp(LCM_projectile_cp) + 1;

	  class matrix<complex<double> > &finite_range_orthogonalized_potential_HO_submatrix = finite_range_orthogonalized_potential_HO_submatrices(ic , icp);

	  class matrix<complex<double> > &finite_range_overlaps_HO_submatrix = finite_range_overlaps_HO_submatrices(ic , icp);
	  
	  class matrix<complex<double> > &finite_range_potential_HO_submatrix = finite_range_potential_HO_submatrices(ic , icp);

	  class matrix<complex<double> > &Delta_HO_submatrix = Delta_HO_submatrices(ic , icp);

	  finite_range_orthogonalized_potential_HO_submatrix.allocate (NCM_HO_max_LCM_projectile_c_plus_one , NCM_HO_max_LCM_projectile_cp_plus_one);

	  finite_range_overlaps_HO_submatrix.allocate (NCM_HO_max_LCM_projectile_c_plus_one , NCM_HO_max_LCM_projectile_cp_plus_one);
	  
	  finite_range_potential_HO_submatrix.allocate (NCM_HO_max_LCM_projectile_c_plus_one , NCM_HO_max_LCM_projectile_cp_plus_one);

	  Delta_HO_submatrix.allocate (NCM_HO_max_LCM_projectile_c_plus_one , NCM_HO_max_LCM_projectile_cp_plus_one);

	  finite_range_orthogonalized_potential_HO_submatrix = 0.0;

	  finite_range_potential_HO_submatrix = 0.0;
	  
	  finite_range_overlaps_HO_submatrix = 0.0;

	  Delta_HO_submatrix = 0.0;
	}
    }
}




void CC_Hamiltonian_data::dimension_matrices_independent_data_realloc_init (
									    const bool is_it_one_baryon_COSM_case , 
									    const class input_data_str &input_data_CC_Berggren , 
									    const class interaction_class &inter_data_basis , 
									    const class array<class CC_channel_class> &channels_tab , 
									    const class baryons_data &prot_Y_data , 
									    const class baryons_data &neut_Y_data , 
									    const class array<class cluster_data> &cluster_projectile_data_tab , 
									    const class baryons_data &prot_Y_data_CC_Berggren , 
									    const class baryons_data &neut_Y_data_CC_Berggren , 
									    const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab)
{
  const enum CC_reaction_type CC_reaction = input_data_CC_Berggren.get_CC_reaction ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const double mp_max = prot_Y_data.get_m_max ();
  const double mn_max = neut_Y_data.get_m_max ();

  const double m_max = max (mp_max , mn_max);

  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();
  
  const int nmax_HO = (is_it_one_baryon_COSM_case) ? (nmax_HO_lab_tab.max ()) : (Nmax_HO_clusters_calc (cluster_projectile_data_tab));

  const int nmax_HO_potentials_plus_one = nmax_HO + 1;

  const int nmax_all = nmax_all_determine (is_it_one_baryon_COSM_case , channels_tab , prot_Y_data , neut_Y_data , cluster_projectile_data_tab);

  const int nmax_all_CC_Berggren = nmax_all_determine (is_it_one_baryon_COSM_case , channels_tab , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , cluster_projectile_data_CC_Berggren_tab);

  const int nmax_all_plus_one = nmax_all + 1;

  const int nmax_all_plus_one_CC_Berggren = nmax_all_CC_Berggren + 1;

  const int nmax_HO_wfs_plus_one = max (16 , nmax_HO_potentials_plus_one);

  const unsigned int N_bef_R_uniform = input_data_CC_Berggren.get_N_bef_R_uniform ();

  const unsigned int N_bef_R_GL = input_data_CC_Berggren.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = input_data_CC_Berggren.get_N_aft_R_GL ();

  const unsigned int cluster_projectile_number = input_data_CC_Berggren.get_CC_cluster_projectile_number ();
  
  multipolar_expansion.deallocate ();

  CGs.deallocate ();

  HO_wfs_bef_R_tab_uniform.deallocate (); 

  HO_wfs_bef_R_tab_GL.deallocate (); 
  HO_wfs_aft_R_tab_GL.deallocate (); 

  Gaussian_table_GL.deallocate ();

  CC_corrective_factors_TBMEs_tab.deallocate ();
  
  CC_corrective_factors_cluster_tab.deallocate ();
      
  if (is_it_SGI_MSGI) multipolar_expansion.allocate_calc (m_max);

  CGs.allocate_calc (m_max);

  HO_wfs_bef_R_tab_uniform.allocate (N_channels , nmax_HO_wfs_plus_one , N_bef_R_uniform);

  HO_wfs_bef_R_tab_GL.allocate (N_channels , nmax_HO_wfs_plus_one , N_bef_R_GL);
  HO_wfs_aft_R_tab_GL.allocate (N_channels , nmax_HO_wfs_plus_one , N_aft_R_GL);

  if (is_it_SGI_MSGI) Gaussian_table_GL.allocate (N_bef_R_GL);

  if (CC_reaction == SCATTERING)
    {
      const class array<double> &J_A_tab = input_data_CC_Berggren.get_CC_J_A_composite_tab ();

      const int two_J_A_max = make_int (2.0*J_A_tab.max ());
      
      const int two_J_A_max_plus_one = two_J_A_max + 1;

      CC_corrective_factors_TBMEs_tab.allocate (2 , two_J_A_max_plus_one);
      
      CC_corrective_factors_cluster_tab.allocate (cluster_projectile_number , 2 , two_J_A_max_plus_one);
    }

  if (CC_reaction == RADIATIVE_CAPTURE)
    {
      const class array<double> &J_A_tab_in  = input_data_CC_Berggren.get_CC_J_A_in_composite_tab ();
      const class array<double> &J_A_tab_out = input_data_CC_Berggren.get_CC_J_A_out_composite_tab ();

      const int two_J_A_in_max  = make_int (2.0*J_A_tab_in.max ());
      const int two_J_A_out_max = make_int (2.0*J_A_tab_out.max ());

      const int two_J_A_max = max (two_J_A_in_max , two_J_A_out_max);
      
      const int two_J_A_max_plus_one = two_J_A_max + 1;

      CC_corrective_factors_TBMEs_tab.allocate (2 , two_J_A_max_plus_one);
      
      CC_corrective_factors_cluster_tab.allocate (cluster_projectile_number , 2 , two_J_A_max_plus_one);
    }

  is_it_forbidden_channel_tab.deallocate ();

  is_it_forbidden_channel_CC_Berggren_tab.deallocate ();

  matrices_indices.deallocate ();

  matrices_indices_HO.deallocate ();

  matrices_indices_CC_Berggren.deallocate ();

  Ueq_tab.deallocate ();

  source_tab.deallocate ();

  is_it_forbidden_channel_tab.allocate (N_channels , nmax_all_plus_one);

  matrices_indices.allocate (N_channels , nmax_all_plus_one);

  matrices_indices_HO.allocate (N_channels , nmax_HO_potentials_plus_one);

  is_it_forbidden_channel_CC_Berggren_tab.allocate (N_channels , nmax_all_plus_one_CC_Berggren);

  matrices_indices_CC_Berggren.allocate (N_channels , nmax_all_plus_one_CC_Berggren);

  Ueq_tab.allocate (N_channels , N_channels , N_bef_R_uniform);

  source_tab.allocate (N_channels , N_bef_R_uniform);

  HO_wfs_bef_R_tab_uniform = 0.0;

  HO_wfs_bef_R_tab_GL = 0.0;
  HO_wfs_aft_R_tab_GL = 0.0;

  Gaussian_table_GL = 0.0;

  CC_corrective_factors_TBMEs_tab = 0.0;
  
  CC_corrective_factors_cluster_tab = 0.0;
      
  is_it_forbidden_channel_tab = false;

  is_it_forbidden_channel_CC_Berggren_tab = false;

  matrices_indices = OUT_OF_RANGE;

  matrices_indices_HO = OUT_OF_RANGE;

  matrices_indices_CC_Berggren = OUT_OF_RANGE;

  Ueq_tab = 0.0 ;

  source_tab = 0.0;

  if (is_it_one_baryon_COSM_case)
    submatrices_realloc_one_baryon_init (channels_tab , nmax_HO_lab_tab);
  else
    submatrices_realloc_cluster_init (channels_tab , cluster_projectile_data_tab);
}





void CC_Hamiltonian_data::HO_wfs_Gaussian_tables_calc (
						       const double R , 
						       const double R_max , 
						       const class array<class CC_channel_class> &channels_tab , 
						       const class interaction_class &inter_data_basis)
{
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const unsigned int N_bef_R_uniform = HO_wfs_bef_R_tab_uniform.dimension (2);

  const unsigned int N_bef_R_GL = HO_wfs_bef_R_tab_GL.dimension (2);
  const unsigned int N_aft_R_GL = HO_wfs_aft_R_tab_GL.dimension (2);

  const double step_bef_R_uniform = R/static_cast<double> (N_bef_R_uniform - 1);

  class array<double> r_bef_R_tab_uniform (N_bef_R_uniform);

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i * step_bef_R_uniform;

  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);

  class array<double> r_aft_R_tab_GL(N_aft_R_GL);
  class array<double> w_aft_R_tab_GL(N_aft_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R     , r_bef_R_tab_GL , w_bef_R_tab_GL);
  Gauss_Legendre::abscissas_weights_tables_calc (R   , R_max , r_aft_R_tab_GL , w_aft_R_tab_GL);    

  CC_HO_wave_functions::wfs_radial_calc (channels_tab , r_bef_R_tab_uniform , HO_wfs_bef_R_tab_uniform);
  CC_HO_wave_functions::wfs_radial_calc (channels_tab , r_bef_R_tab_GL  , HO_wfs_bef_R_tab_GL);
  CC_HO_wave_functions::wfs_radial_calc (channels_tab , r_aft_R_tab_GL  , HO_wfs_aft_R_tab_GL);

  if (is_it_MSGI)	
    HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::Gaussian_table_GL_calc (inter_data_basis , Gaussian_table_GL);
}






void CC_Hamiltonian_data::dimensions_matrices_one_baryon_calc (
							       const class interaction_class &inter_data_basis , 
							       const class baryons_data &prot_Y_data , 
							       const class baryons_data &neut_Y_data , 
							       const class baryons_data &prot_Y_data_CC_Berggren , 
							       const class baryons_data &neut_Y_data_CC_Berggren , 
							       const class array<class CC_channel_class> &channels_tab)
{
  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  dimension_matrices = 0;

  dimension_matrices_pole_approximation = 0;

  dimension_matrices_HO = 0 ;

  dimension_matrices_pole_approximation_CC_Berggren = 0;

  dimension_matrices_partial_pole_approximation_CC_Berggren = 0;

  dimension_matrices_CC_Berggren = 0;
	      
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);
      
      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const enum particle_type particle_c = channel_c.get_projectile ();
		
      const int particle_c_charge = particle_charge_determine (particle_c);

      const bool is_particle_c_charged = (particle_c_charge != 0);
      		
      const int lc = channel_c.get_LCM_projectile ();

      const double jc = channel_c.get_J_projectile ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const bool S_matrix_pole_Tc = channel_c.get_S_matrix_pole_Tc ();

      const class baryons_data &data_tau_c = (is_particle_c_charged) ? (prot_Y_data) : (neut_Y_data);

      const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_c = data_tau_c.get_is_it_valence_shell_tabs ();
      
      const class array<class lj_table<int> > &nmax_lj_c_tabs = data_tau_c.get_nmax_lj_tabs ();

      const class array<class nlj_table<unsigned int> > &shells_indices_c_tab = data_tau_c.get_shells_indices_tab ();

      const unsigned int particle_index_c = charge_baryon_index_determine (particle_c);
      
      const class lj_table<int> &nmax_lj_c_tab = nmax_lj_c_tabs(particle_index_c);
      
      const class nlj_table<unsigned int> &shells_indices_c = shells_indices_c_tab(particle_index_c);

      const class nlj_table<bool> &is_it_valence_shell_tab_c = is_it_valence_shell_tabs_c(particle_index_c);

      const class array<class nlj_struct> &shells_qn_c = data_tau_c.get_shells_quantum_numbers ();

      const int nmax_c = nmax_lj_c_tab(lc , jc);
      
      const class baryons_data &data_tau_c_CC_Berggren = (is_particle_c_charged) ? (prot_Y_data_CC_Berggren) : (neut_Y_data_CC_Berggren);

      const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_c_CC_Berggren = data_tau_c_CC_Berggren.get_is_it_valence_shell_tabs ();

      const class array<class lj_table<int> > &nmax_lj_tabs_c_CC_Berggren = data_tau_c_CC_Berggren.get_nmax_lj_tabs ();

      const class array<class nlj_table<unsigned int> > &shells_indices_c_CC_Berggren_tab = data_tau_c_CC_Berggren.get_shells_indices_tab ();

      const class array<class nlj_struct> &shells_qn_c_CC_Berggren = data_tau_c_CC_Berggren.get_shells_quantum_numbers ();
            
      const class nlj_table<bool> &is_it_valence_shell_tab_c_CC_Berggren = is_it_valence_shell_tabs_c_CC_Berggren(particle_index_c);

      const class lj_table<int> &nmax_lj_tab_c_CC_Berggren = nmax_lj_tabs_c_CC_Berggren(particle_index_c);

      const class nlj_table<unsigned int> &shells_indices_c_CC_Berggren = shells_indices_c_CC_Berggren_tab(particle_index_c);

      const int nmax_c_CC_Berggren = nmax_lj_tab_c_CC_Berggren(lc , jc);

      const int nmax_HO_c = nmax_HO_lab_tab(lc);

      for (int nc = 0 ; nc <= nmax_c ; nc++)
	{	
	  if (is_it_valence_shell_tab_c(nc , lc , jc))
	    {
	      const unsigned int shell_index_c = shells_indices_c(nc , lc , jc);

	      const class nlj_struct &shell_qn_c = shells_qn_c(shell_index_c);

	      const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	      const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	      if ((real_average_n_scat_c <= CC_average_n_scat_target_projectile_max) && !is_it_forbidden_channel_tab(ic , nc))
		{
		  if (S_matrix_pole_Tc && S_matrix_pole_nc) dimension_matrices_pole_approximation++;

		  dimension_matrices++;
		}
	    }
	}

      for (int nc = 0 ; nc <= nmax_c_CC_Berggren ; nc++)
	{
	  if (is_it_valence_shell_tab_c_CC_Berggren(nc , lc , jc))
	    {	
	      const unsigned int sc = shells_indices_c_CC_Berggren(nc , lc , jc);

	      const class nlj_struct &shell_qn_c = shells_qn_c_CC_Berggren(sc);

	      const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	      const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);
	      
	      if ((real_average_n_scat_c <= CC_average_n_scat_target_projectile_max) && !is_it_forbidden_channel_CC_Berggren_tab(ic , nc))
		{
		  if (S_matrix_pole_Tc && S_matrix_pole_nc) dimension_matrices_pole_approximation_CC_Berggren++;

		  if (S_matrix_pole_Tc || S_matrix_pole_nc) dimension_matrices_partial_pole_approximation_CC_Berggren++;

		  dimension_matrices_CC_Berggren++;
		}
	    }
	}

      dimension_matrices_HO += nmax_HO_c + 1;
    }
}




void CC_Hamiltonian_data::dimensions_matrices_cluster_calc (
							    const class array<class CC_channel_class> &channels_tab , 
							    const class array<class cluster_data> &cluster_projectile_data_tab , 
							    const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab)
{
  dimension_matrices = 0;

  dimension_matrices_pole_approximation = 0;

  dimension_matrices_HO = 0;

  dimension_matrices_pole_approximation_CC_Berggren = 0;

  dimension_matrices_partial_pole_approximation_CC_Berggren = 0;

  dimension_matrices_CC_Berggren = 0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const int A_projectile_c = channel_c.get_A_projectile ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const bool S_matrix_pole_Tc = channel_c.get_S_matrix_pole_Tc ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const double J_projectile_c = channel_c.get_J_projectile ();

      const bool S_matrix_pole_projectile_c = channel_c.get_S_matrix_pole_projectile ();

      const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);	

      const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c = data_c.get_Nmax_cluster_projectile_CM_tab ();

      const int NCM_max_LCM_projectile_c = Nmax_cluster_projectile_CM_tab_c(LCM_projectile_c , J_projectile_c);

      const class nlj_table<bool> &cluster_CM_S_matrix_poles_c = data_c.get_cluster_CM_S_matrix_poles ();

      const class cluster_data &data_c_CC_Berggren = get_cluster_projectile_data (projectile_c , cluster_projectile_data_CC_Berggren_tab);

      const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c_CC_Berggren = data_c_CC_Berggren.get_Nmax_cluster_projectile_CM_tab ();

      const int NCM_max_LCM_projectile_c_CC_Berggren = Nmax_cluster_projectile_CM_tab_c_CC_Berggren(LCM_projectile_c , J_projectile_c);

      const class array<int> &Nmax_HO_tab_c = data_c.get_Nmax_HO_tab ();

      const int NCM_HO_max_LCM_projectile_c = Nmax_HO_tab_c(LCM_projectile_c);

      const class nlj_table<bool> &cluster_CM_S_matrix_poles_c_CC_Berggren = data_c_CC_Berggren.get_cluster_CM_S_matrix_poles ();

      for (int NCM_c = 0 ; NCM_c <= NCM_max_LCM_projectile_c ; NCM_c++)
	{
	  const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c(NCM_c , LCM_projectile_c , J_projectile_c);

	  const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_tab(ic , NCM_c) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max))
	    {
	      dimension_matrices ++;

	      if (S_matrix_pole_Tc && S_matrix_pole_NCM_c && S_matrix_pole_projectile_c) dimension_matrices_pole_approximation ++;
	    }
	}

      for (int NCM_c = 0 ; NCM_c <= NCM_max_LCM_projectile_c_CC_Berggren ; NCM_c++)
	{
	  const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c_CC_Berggren(NCM_c , LCM_projectile_c , J_projectile_c);

	  const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_CC_Berggren_tab(ic , NCM_c) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max))
	    {
	      dimension_matrices_CC_Berggren ++;

	      if (S_matrix_pole_Tc && S_matrix_pole_NCM_c && S_matrix_pole_projectile_c) dimension_matrices_pole_approximation_CC_Berggren ++;
	      
	      if (S_matrix_pole_Tc || S_matrix_pole_NCM_c || S_matrix_pole_projectile_c) dimension_matrices_partial_pole_approximation_CC_Berggren ++;
	    }
	}

      dimension_matrices_HO += NCM_HO_max_LCM_projectile_c + 1;
    }
}





void CC_Hamiltonian_data::matrices_indices_pole_approximation_one_baryon_calc (
									       const class baryons_data &prot_Y_data , 
									       const class baryons_data &neut_Y_data , 
									       const class baryons_data &prot_Y_data_CC_Berggren , 
									       const class baryons_data &neut_Y_data_CC_Berggren , 
									       const class array<class CC_channel_class> &channels_tab)
{
  unsigned int index_pole_approximation = 0 , index_pole_approximation_CC_Berggren = 0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const enum particle_type particle_c = channel_c.get_projectile ();
		
      const int particle_c_charge = particle_charge_determine (particle_c);

      const bool is_particle_c_charged = (particle_c_charge != 0);

      const int lc = channel_c.get_LCM_projectile ();

      const double jc = channel_c.get_J_projectile ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const bool S_matrix_pole_Tc = channel_c.get_S_matrix_pole_Tc ();

      const class baryons_data &data_tau_c = (is_particle_c_charged) ? (prot_Y_data) : (neut_Y_data);

      const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_c = data_tau_c.get_is_it_valence_shell_tabs ();
      
      const class array<class lj_table<int> > &nmax_lj_c_tabs = data_tau_c.get_nmax_lj_tabs ();

      const class array<class nlj_table<unsigned int> > &shells_indices_c_tab = data_tau_c.get_shells_indices_tab ();

      const unsigned int particle_index_c = charge_baryon_index_determine (particle_c);
      
      const class lj_table<int> &nmax_lj_c_tab = nmax_lj_c_tabs(particle_index_c);
      
      const class nlj_table<unsigned int> &shells_indices_c = shells_indices_c_tab(particle_index_c);

      const class nlj_table<bool> &is_it_valence_shell_tab_c = is_it_valence_shell_tabs_c(particle_index_c);

      const class array<class nlj_struct> &shells_qn_c = data_tau_c.get_shells_quantum_numbers ();

      const int nmax_c = nmax_lj_c_tab(lc , jc);

      const class baryons_data &data_tau_c_CC_Berggren = (is_particle_c_charged) ? (prot_Y_data_CC_Berggren) : (neut_Y_data_CC_Berggren);

      const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_c_CC_Berggren = data_tau_c_CC_Berggren.get_is_it_valence_shell_tabs ();

      const class array<class lj_table<int> > &nmax_lj_tabs_c_CC_Berggren = data_tau_c_CC_Berggren.get_nmax_lj_tabs ();

      const class array<class nlj_table<unsigned int> > &shells_indices_c_CC_Berggren_tab = data_tau_c_CC_Berggren.get_shells_indices_tab ();

      const class array<class nlj_struct> &shells_qn_c_CC_Berggren = data_tau_c_CC_Berggren.get_shells_quantum_numbers ();
            
      const class nlj_table<bool> &is_it_valence_shell_tab_c_CC_Berggren = is_it_valence_shell_tabs_c_CC_Berggren(particle_index_c);

      const class lj_table<int> &nmax_lj_tab_c_CC_Berggren = nmax_lj_tabs_c_CC_Berggren(particle_index_c);

      const class nlj_table<unsigned int> &shells_indices_c_CC_Berggren = shells_indices_c_CC_Berggren_tab(particle_index_c);

      const int nmax_c_CC_Berggren = nmax_lj_tab_c_CC_Berggren(lc , jc);

      for (int nc = 0 ; nc <= nmax_c ; nc++)
	{
	  if (is_it_valence_shell_tab_c(nc , lc , jc))
	    {
	      const unsigned int shell_index_c = shells_indices_c(nc , lc , jc);

	      const class nlj_struct &shell_qn_c = shells_qn_c(shell_index_c);

	      const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	      const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	      if ((real_average_n_scat_c <= CC_average_n_scat_target_projectile_max) && !is_it_forbidden_channel_tab(ic , nc) && S_matrix_pole_Tc && S_matrix_pole_nc) 
		matrices_indices(ic , nc) = index_pole_approximation ++;
	    }
	}

      for (int nc = 0 ; nc <= nmax_c_CC_Berggren ; nc++)
	{
	  if (is_it_valence_shell_tab_c_CC_Berggren(nc , lc , jc))
	    {
	      const unsigned int shell_index_c = shells_indices_c_CC_Berggren(nc , lc , jc);

	      const class nlj_struct &shell_qn_c = shells_qn_c_CC_Berggren(shell_index_c);

	      const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	      const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	      if ((real_average_n_scat_c <= CC_average_n_scat_target_projectile_max) && !is_it_forbidden_channel_CC_Berggren_tab(ic , nc) && S_matrix_pole_Tc && S_matrix_pole_nc) 
		matrices_indices_CC_Berggren(ic , nc) = index_pole_approximation_CC_Berggren ++;
	    }
	}
    }
}









void CC_Hamiltonian_data::matrices_indices_partial_pole_approximation_CC_Berggren_one_baryon_calc (
												   const class baryons_data &prot_Y_data_CC_Berggren , 
												   const class baryons_data &neut_Y_data_CC_Berggren , 
												   const class array<class CC_channel_class> &channels_tab)
{
  unsigned int index_partial_pole_approximation_CC_Berggren = dimension_matrices_pole_approximation_CC_Berggren;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const enum particle_type particle_c = channel_c.get_projectile ();
		
      const int particle_c_charge = particle_charge_determine (particle_c);

      const bool is_particle_c_charged = (particle_c_charge != 0);

      const int lc = channel_c.get_LCM_projectile ();

      const double jc = channel_c.get_J_projectile ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const bool S_matrix_pole_Tc = channel_c.get_S_matrix_pole_Tc ();

      const class baryons_data &data_tau_c_CC_Berggren = (is_particle_c_charged) ? (prot_Y_data_CC_Berggren) : (neut_Y_data_CC_Berggren);

      const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_c_CC_Berggren = data_tau_c_CC_Berggren.get_is_it_valence_shell_tabs ();

      const class array<class lj_table<int> > &nmax_lj_tabs_c_CC_Berggren = data_tau_c_CC_Berggren.get_nmax_lj_tabs ();

      const class array<class nlj_table<unsigned int> > &shells_indices_c_CC_Berggren_tab = data_tau_c_CC_Berggren.get_shells_indices_tab ();

      const class array<class nlj_struct> &shells_qn_c_CC_Berggren = data_tau_c_CC_Berggren.get_shells_quantum_numbers ();
            
      const unsigned int particle_index_c = charge_baryon_index_determine (particle_c);
  
      const class nlj_table<bool> &is_it_valence_shell_tab_c_CC_Berggren = is_it_valence_shell_tabs_c_CC_Berggren(particle_index_c);

      const class lj_table<int> &nmax_lj_tab_c_CC_Berggren = nmax_lj_tabs_c_CC_Berggren(particle_index_c);

      const class nlj_table<unsigned int> &shells_indices_c_CC_Berggren = shells_indices_c_CC_Berggren_tab(particle_index_c);

      const int nmax_c_CC_Berggren = nmax_lj_tab_c_CC_Berggren(lc , jc);

      for (int nc = 0 ; nc <= nmax_c_CC_Berggren ; nc++)
	{
	  if (is_it_valence_shell_tab_c_CC_Berggren(nc , lc , jc))
	    {
	      const unsigned int shell_index_c = shells_indices_c_CC_Berggren(nc , lc , jc);

	      const class nlj_struct &shell_qn_c = shells_qn_c_CC_Berggren(shell_index_c);

	      const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	      if (S_matrix_pole_Tc && S_matrix_pole_nc) continue;

	      const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	      if ((real_average_n_scat_c <= CC_average_n_scat_target_projectile_max) && !is_it_forbidden_channel_CC_Berggren_tab(ic , nc) && (S_matrix_pole_Tc || S_matrix_pole_nc))
		matrices_indices_CC_Berggren(ic , nc) = index_partial_pole_approximation_CC_Berggren ++;
	    }
	}
    }
}








void CC_Hamiltonian_data::matrices_indices_one_baryon_calc (
							    const class interaction_class &inter_data_basis , 
							    const class baryons_data &prot_Y_data , 
							    const class baryons_data &neut_Y_data , 
							    const class baryons_data &prot_Y_data_CC_Berggren , 
							    const class baryons_data &neut_Y_data_CC_Berggren , 
							    const class array<class CC_channel_class> &channels_tab)
{
  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  unsigned int index = dimension_matrices_pole_approximation;

  unsigned int index_HO = 0;

  unsigned int index_CC_Berggren = dimension_matrices_partial_pole_approximation_CC_Berggren;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const enum particle_type particle_c = channel_c.get_projectile ();
		
      const int particle_c_charge = particle_charge_determine (particle_c);

      const bool is_particle_c_charged = (particle_c_charge != 0);

      const int lc = channel_c.get_LCM_projectile ();

      const double jc = channel_c.get_J_projectile ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const bool S_matrix_pole_Tc = channel_c.get_S_matrix_pole_Tc ();

      const class baryons_data &data_tau_c = (is_particle_c_charged) ? (prot_Y_data) : (neut_Y_data);

      const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_c = data_tau_c.get_is_it_valence_shell_tabs ();
      
      const class array<class lj_table<int> > &nmax_lj_c_tabs = data_tau_c.get_nmax_lj_tabs ();

      const class array<class nlj_table<unsigned int> > &shells_indices_c_tab = data_tau_c.get_shells_indices_tab ();

      const unsigned int particle_index_c = charge_baryon_index_determine (particle_c);
      
      const class lj_table<int> &nmax_lj_c_tab = nmax_lj_c_tabs(particle_index_c);
      
      const class nlj_table<unsigned int> &shells_indices_c = shells_indices_c_tab(particle_index_c);

      const class nlj_table<bool> &is_it_valence_shell_tab_c = is_it_valence_shell_tabs_c(particle_index_c);

      const class array<class nlj_struct> &shells_qn_c = data_tau_c.get_shells_quantum_numbers ();

      const int nmax_c = nmax_lj_c_tab(lc , jc);

      const class baryons_data &data_tau_c_CC_Berggren = (is_particle_c_charged) ? (prot_Y_data_CC_Berggren) : (neut_Y_data_CC_Berggren);

      const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_c_CC_Berggren = data_tau_c_CC_Berggren.get_is_it_valence_shell_tabs ();

      const class array<class lj_table<int> > &nmax_lj_tabs_c_CC_Berggren = data_tau_c_CC_Berggren.get_nmax_lj_tabs ();

      const class array<class nlj_table<unsigned int> > &shells_indices_c_CC_Berggren_tab = data_tau_c_CC_Berggren.get_shells_indices_tab ();

      const class array<class nlj_struct> &shells_qn_c_CC_Berggren = data_tau_c_CC_Berggren.get_shells_quantum_numbers ();
            
      const class nlj_table<bool> &is_it_valence_shell_tab_c_CC_Berggren = is_it_valence_shell_tabs_c_CC_Berggren(particle_index_c);

      const class lj_table<int> &nmax_lj_tab_c_CC_Berggren = nmax_lj_tabs_c_CC_Berggren(particle_index_c);

      const class nlj_table<unsigned int> &shells_indices_c_CC_Berggren = shells_indices_c_CC_Berggren_tab(particle_index_c);

      const int nmax_c_CC_Berggren = nmax_lj_tab_c_CC_Berggren(lc , jc);

      const int nmax_HO_c = nmax_HO_lab_tab(lc);

      for (int nc = 0 ; nc <= nmax_c ; nc++)
	{
	  if (is_it_valence_shell_tab_c(nc , lc , jc))
	    {
	      const unsigned int shell_index_c = shells_indices_c(nc , lc , jc);

	      const class nlj_struct &shell_qn_c = shells_qn_c(shell_index_c);

	      const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	      if (S_matrix_pole_Tc && S_matrix_pole_nc) continue;

	      const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	      if ((real_average_n_scat_c <= CC_average_n_scat_target_projectile_max) && !is_it_forbidden_channel_tab(ic , nc)) 
		matrices_indices(ic , nc) = index ++;
	    }
	}

      for (int nc = 0 ; nc <= nmax_c_CC_Berggren ; nc++)
	{
	  if (is_it_valence_shell_tab_c_CC_Berggren(nc , lc , jc))
	    {
	      const unsigned int shell_index_c = shells_indices_c_CC_Berggren(nc , lc , jc);

	      const class nlj_struct &shell_qn_c = shells_qn_c_CC_Berggren(shell_index_c);

	      const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	      if (S_matrix_pole_Tc || S_matrix_pole_nc) continue;

	      const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	      if ((real_average_n_scat_c <= CC_average_n_scat_target_projectile_max) && !is_it_forbidden_channel_CC_Berggren_tab(ic , nc))
		matrices_indices_CC_Berggren(ic , nc) = index_CC_Berggren ++;
	    }
	}

      for (int nHOc = 0 ; nHOc <= nmax_HO_c ; nHOc++)
	matrices_indices_HO(ic , nHOc) = index_HO ++;
    }
}





void CC_Hamiltonian_data::all_matrices_indices_one_baryon_calc (
								const class interaction_class &inter_data_basis , 
								const class baryons_data &prot_Y_data , 
								const class baryons_data &neut_Y_data , 
								const class baryons_data &prot_Y_data_CC_Berggren , 
								const class baryons_data &neut_Y_data_CC_Berggren , 
								const class array<class CC_channel_class> &channels_tab)
{
  matrices_indices = dimension_matrices*dimension_matrices;

  matrices_indices_HO = dimension_matrices_HO*dimension_matrices_HO;

  matrices_indices_CC_Berggren = dimension_matrices_CC_Berggren*dimension_matrices_CC_Berggren;

  matrices_indices_pole_approximation_one_baryon_calc (prot_Y_data , neut_Y_data , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , channels_tab);

  matrices_indices_partial_pole_approximation_CC_Berggren_one_baryon_calc (prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , channels_tab);

  matrices_indices_one_baryon_calc (inter_data_basis , prot_Y_data , neut_Y_data , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , channels_tab);
}







void CC_Hamiltonian_data::matrices_indices_pole_approximation_cluster_calc (
									    const class array<class CC_channel_class> &channels_tab , 
									    const class array<class cluster_data> &cluster_projectile_data_tab , 
									    const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab) 
{
  unsigned int index_pole_approximation = 0 , index_pole_approximation_CC_Berggren = 0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const int A_projectile_c = channel_c.get_A_projectile ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const bool S_matrix_pole_Tc = channel_c.get_S_matrix_pole_Tc ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const double J_projectile_c = channel_c.get_J_projectile ();

      const bool S_matrix_pole_projectile_c = channel_c.get_S_matrix_pole_projectile ();

      const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);

      const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c = data_c.get_Nmax_cluster_projectile_CM_tab ();

      const int NCM_max_LCM_projectile_c = Nmax_cluster_projectile_CM_tab_c(LCM_projectile_c , J_projectile_c);

      const class nlj_table<bool> &cluster_CM_S_matrix_poles_c = data_c.get_cluster_CM_S_matrix_poles ();

      const class cluster_data &data_c_CC_Berggren = get_cluster_projectile_data (projectile_c , cluster_projectile_data_CC_Berggren_tab);

      const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c_CC_Berggren = data_c_CC_Berggren.get_Nmax_cluster_projectile_CM_tab ();

      const int NCM_max_LCM_projectile_c_CC_Berggren = Nmax_cluster_projectile_CM_tab_c_CC_Berggren(LCM_projectile_c , J_projectile_c);

      const class nlj_table<bool> &cluster_CM_S_matrix_poles_c_CC_Berggren = data_c_CC_Berggren.get_cluster_CM_S_matrix_poles ();

      for (int NCM_c = 0 ; NCM_c <= NCM_max_LCM_projectile_c ; NCM_c++)
	{
	  const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c(NCM_c , LCM_projectile_c , J_projectile_c);

	  const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_tab(ic , NCM_c) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max) && S_matrix_pole_Tc && S_matrix_pole_NCM_c && S_matrix_pole_projectile_c) 
	    matrices_indices(ic , NCM_c) = index_pole_approximation ++;
	}

      for (int NCM_c = 0 ; NCM_c <= NCM_max_LCM_projectile_c_CC_Berggren ; NCM_c++)
	{
	  const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c_CC_Berggren(NCM_c , LCM_projectile_c , J_projectile_c);

	  const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_CC_Berggren_tab(ic , NCM_c) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max) && S_matrix_pole_Tc && S_matrix_pole_NCM_c && S_matrix_pole_projectile_c)
	    matrices_indices_CC_Berggren(ic , NCM_c) = index_pole_approximation_CC_Berggren ++;
	}
    }
}


void CC_Hamiltonian_data::matrices_indices_partial_pole_approximation_CC_Berggren_cluster_calc (
												const class array<class CC_channel_class> &channels_tab , 
												const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab) 
{
  unsigned int index_partial_pole_approximation_CC_Berggren = dimension_matrices_pole_approximation_CC_Berggren;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const int A_projectile_c = channel_c.get_A_projectile ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const bool S_matrix_pole_Tc = channel_c.get_S_matrix_pole_Tc ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const double J_projectile_c = channel_c.get_J_projectile ();

      const bool S_matrix_pole_projectile_c = channel_c.get_S_matrix_pole_projectile ();

      const class cluster_data &data_c_CC_Berggren = get_cluster_projectile_data (projectile_c , cluster_projectile_data_CC_Berggren_tab);

      const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c_CC_Berggren = data_c_CC_Berggren.get_Nmax_cluster_projectile_CM_tab ();

      const int NCM_max_LCM_projectile_c_CC_Berggren = Nmax_cluster_projectile_CM_tab_c_CC_Berggren(LCM_projectile_c , J_projectile_c);

      const class nlj_table<bool> &cluster_CM_S_matrix_poles_c_CC_Berggren = data_c_CC_Berggren.get_cluster_CM_S_matrix_poles ();

      for (int NCM_c = 0 ; NCM_c <= NCM_max_LCM_projectile_c_CC_Berggren ; NCM_c++)
	{
	  const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c_CC_Berggren(NCM_c , LCM_projectile_c , J_projectile_c);

	  const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_CC_Berggren_tab(ic , NCM_c) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max)) 
	    {
	      if (S_matrix_pole_Tc && S_matrix_pole_NCM_c && S_matrix_pole_projectile_c) continue;

	      if (S_matrix_pole_Tc || S_matrix_pole_NCM_c || S_matrix_pole_projectile_c)  
		matrices_indices_CC_Berggren(ic , NCM_c) = index_partial_pole_approximation_CC_Berggren ++;
	    }
	}
    }
}


void CC_Hamiltonian_data::matrices_indices_cluster_calc (
							 const class array<class CC_channel_class> &channels_tab , 
							 const class array<class cluster_data> &cluster_projectile_data_tab , 
							 const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab)
{
  unsigned int index = dimension_matrices_pole_approximation;

  unsigned int index_HO = 0;

  unsigned int index_CC_Berggren = dimension_matrices_partial_pole_approximation_CC_Berggren;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const int A_projectile_c = channel_c.get_A_projectile ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const bool S_matrix_pole_Tc = channel_c.get_S_matrix_pole_Tc ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const double J_projectile_c = channel_c.get_J_projectile ();

      const bool S_matrix_pole_projectile_c = channel_c.get_S_matrix_pole_projectile ();

      const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);

      const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c = data_c.get_Nmax_cluster_projectile_CM_tab ();

      const int NCM_max_LCM_projectile_c = Nmax_cluster_projectile_CM_tab_c(LCM_projectile_c , J_projectile_c);

      const class nlj_table<bool> &cluster_CM_S_matrix_poles_c = data_c.get_cluster_CM_S_matrix_poles ();

      const class cluster_data &data_c_CC_Berggren = get_cluster_projectile_data (projectile_c , cluster_projectile_data_CC_Berggren_tab);

      const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c_CC_Berggren = data_c_CC_Berggren.get_Nmax_cluster_projectile_CM_tab ();

      const int NCM_max_LCM_projectile_c_CC_Berggren = Nmax_cluster_projectile_CM_tab_c_CC_Berggren(LCM_projectile_c , J_projectile_c);

      const class nlj_table<bool> &cluster_CM_S_matrix_poles_c_CC_Berggren = data_c_CC_Berggren.get_cluster_CM_S_matrix_poles ();

      const class array<int> &Nmax_HO_tab_c = data_c.get_Nmax_HO_tab ();

      const int NCM_HO_max_LCM_projectile_c = Nmax_HO_tab_c(LCM_projectile_c);

      for (int NCM_c = 0 ; NCM_c <= NCM_max_LCM_projectile_c ; NCM_c++)
	{
	  const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c(NCM_c , LCM_projectile_c , J_projectile_c);

	  if (S_matrix_pole_Tc && S_matrix_pole_NCM_c && S_matrix_pole_projectile_c) continue;

	  const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_tab(ic , NCM_c) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max)) 
	    matrices_indices(ic , NCM_c) = index ++;
	}

      for (int NCM_c = 0 ; NCM_c <= NCM_max_LCM_projectile_c_CC_Berggren ; NCM_c++)
	{
	  const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c_CC_Berggren(NCM_c , LCM_projectile_c , J_projectile_c);

	  if (S_matrix_pole_Tc || S_matrix_pole_NCM_c || S_matrix_pole_projectile_c) continue;

	  const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_CC_Berggren_tab(ic , NCM_c) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max)) 
	    matrices_indices_CC_Berggren(ic , NCM_c) = index_CC_Berggren ++;
	}

      for (int NCM_HO_c = 0 ; NCM_HO_c <= NCM_HO_max_LCM_projectile_c ; NCM_HO_c++) 
	matrices_indices_HO(ic , NCM_HO_c) = index_HO ++;
    }
}




void CC_Hamiltonian_data::all_matrices_indices_cluster_calc (
							     const class array<class CC_channel_class> &channels_tab , 
							     const class array<class cluster_data> &cluster_projectile_data_tab , 
							     const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab)
{
  matrices_indices = dimension_matrices*dimension_matrices;

  matrices_indices_HO = dimension_matrices_HO*dimension_matrices_HO;

  matrices_indices_CC_Berggren = dimension_matrices_CC_Berggren*dimension_matrices_CC_Berggren;

  matrices_indices_pole_approximation_cluster_calc (channels_tab , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab);

  matrices_indices_partial_pole_approximation_CC_Berggren_cluster_calc (channels_tab , cluster_projectile_data_CC_Berggren_tab);

  matrices_indices_cluster_calc (channels_tab , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab);
}








void CC_Hamiltonian_data::is_it_forbidden_channel_CC_Berggren_tab_one_baryon_determine (
											const class array<class CC_channel_class> &channels_tab , 
											const class baryons_data &prot_Y_data , 
											const class baryons_data &neut_Y_data )
{
  is_it_forbidden_channel_CC_Berggren_tab = false;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const bool is_it_HO_channel_decomposition_c = channel_c.get_is_it_HO_channel_decomposition ();

      if (!is_it_HO_channel_decomposition_c)
	{
	  const enum particle_type particle_c = channel_c.get_projectile ();
		
	  const int particle_c_charge = particle_charge_determine (particle_c);

	  const bool is_particle_c_charged = (particle_c_charge != 0);

	  const unsigned int particle_index_c = charge_baryon_index_determine (particle_c);
      
	  const int lc = channel_c.get_LCM_projectile ();

	  const double jc = channel_c.get_J_projectile ();

	  const class baryons_data &data_tau_c = (is_particle_c_charged) ? (prot_Y_data) : (neut_Y_data);

	  const class array<class lj_table<int> > &nmax_lj_c_tabs = data_tau_c.get_nmax_lj_tabs ();
      
	  const class lj_table<int> &nmax_lj_c_tab = nmax_lj_c_tabs(particle_index_c);

	  const int nmax_c = nmax_lj_c_tab(lc , jc);

	  for (int nc = 0 ; nc <= nmax_c ; nc++)
	    is_it_forbidden_channel_CC_Berggren_tab(ic , nc) = is_it_forbidden_channel_tab(ic , nc);
	}
    }
}








void CC_Hamiltonian_data::is_it_forbidden_channel_CC_Berggren_tab_cluster_determine (
										     const class array<class CC_channel_class> &channels_tab , 
										     const class array<class cluster_data> &cluster_projectile_data_tab)
{
  is_it_forbidden_channel_CC_Berggren_tab = false;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const bool is_it_HO_channel_decomposition_c = channel_c.get_is_it_HO_channel_decomposition ();

      if (!is_it_HO_channel_decomposition_c)
	{
	  const enum particle_type projectile_c = channel_c.get_projectile ();

	  const int LCM_projectile_c = channel_c.get_LCM_projectile ();

	  const double J_projectile_c = channel_c.get_J_projectile ();

	  const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);

	  const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c = data_c.get_Nmax_cluster_projectile_CM_tab ();

	  const int NCM_max_LCM_projectile_c = Nmax_cluster_projectile_CM_tab_c(LCM_projectile_c , J_projectile_c);

	  for (int NCM_c = 0 ; NCM_c <= NCM_max_LCM_projectile_c ; NCM_c++)
	    is_it_forbidden_channel_CC_Berggren_tab(ic , NCM_c) = is_it_forbidden_channel_tab(ic , NCM_c);
	}
    }
}











void CC_Hamiltonian_data::dimension_matrices_dependent_data_realloc_init ()
{
  finite_range_overlaps_HO_matrix.deallocate ();

  finite_range_potential_HO_matrix.deallocate ();

  Ho_HO_matrix.deallocate ();

  finite_range_orthogonalized_potential_HO_matrix.deallocate ();

  overlaps_HO_matrix.deallocate ();

  sqrt_overlaps_HO_matrix.deallocate ();

  sqrt_inv_overlaps_HO_matrix.deallocate ();

  H_HO_matrix.deallocate ();

  H_Delta_plus_Delta_H_HO_matrix.deallocate ();

  Delta_H_Delta_HO_matrix.deallocate ();

  Delta_HO_matrix.deallocate ();

  overlaps_matrix_pole_approximation.deallocate ();

  H_matrix_pole_approximation.deallocate ();

  overlaps_matrix.deallocate ();

  H_matrix.deallocate ();

  orthogonalized_H_matrix_CC_Berggren.deallocate ();

  orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren.deallocate ();

  orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren.deallocate ();

  orthogonalized_H_tridiagonalized_diagonal_CC_Berggren.deallocate ();

  orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren.deallocate ();

  finite_range_overlaps_HO_matrix.allocate (dimension_matrices_HO);

  finite_range_potential_HO_matrix.allocate (dimension_matrices_HO);

  Ho_HO_matrix.allocate (dimension_matrices_HO);

  finite_range_orthogonalized_potential_HO_matrix.allocate (dimension_matrices_HO);

  overlaps_HO_matrix.allocate (dimension_matrices_HO);

  sqrt_overlaps_HO_matrix.allocate (dimension_matrices_HO);

  sqrt_inv_overlaps_HO_matrix.allocate (dimension_matrices_HO);

  H_HO_matrix.allocate (dimension_matrices_HO);

  H_Delta_plus_Delta_H_HO_matrix.allocate (dimension_matrices_HO);

  Delta_H_Delta_HO_matrix.allocate (dimension_matrices_HO);

  Delta_HO_matrix.allocate (dimension_matrices_HO);

  overlaps_matrix_pole_approximation.allocate (dimension_matrices_pole_approximation);

  H_matrix_pole_approximation.allocate (dimension_matrices_pole_approximation);

  overlaps_matrix.allocate (dimension_matrices);

  H_matrix.allocate (dimension_matrices);

  orthogonalized_H_matrix_CC_Berggren.allocate (dimension_matrices_CC_Berggren);

  orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren.allocate (dimension_matrices_CC_Berggren);

  orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren.allocate (dimension_matrices_CC_Berggren);

  orthogonalized_H_tridiagonalized_diagonal_CC_Berggren.allocate (dimension_matrices_CC_Berggren);
 
  orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren.allocate (dimension_matrices_CC_Berggren);

  finite_range_overlaps_HO_matrix = 0.0;

  finite_range_potential_HO_matrix = 0.0;

  Ho_HO_matrix = 0.0 ;

  finite_range_orthogonalized_potential_HO_matrix = 0.0;

  overlaps_HO_matrix = 0.0;

  sqrt_overlaps_HO_matrix = 0.0;

  sqrt_inv_overlaps_HO_matrix = 0.0;

  H_HO_matrix = 0.0;

  H_Delta_plus_Delta_H_HO_matrix = 0.0;

  Delta_H_Delta_HO_matrix = 0.0;

  Delta_HO_matrix = 0.0;

  overlaps_matrix_pole_approximation = 0.0;

  H_matrix_pole_approximation = 0.0;

  overlaps_matrix = 0.0;

  H_matrix = 0.0;

  orthogonalized_H_matrix_CC_Berggren = 0.0;

  orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren = 0.0;

  orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren = 0.0;

  orthogonalized_H_tridiagonalized_diagonal_CC_Berggren = 0.0;
 
  orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren = 0.0;
}








void CC_Hamiltonian_data::corrective_factors_read (const class input_data_str &input_data_CC_Berggren)
{	
  const unsigned int cluster_projectile_number = input_data_CC_Berggren.get_CC_cluster_projectile_number ();
  
  const unsigned int CC_corrective_factors_TBMEs_composite_number = input_data_CC_Berggren.get_CC_corrective_factors_TBMEs_composite_number ();

  const int CC_corrective_factors_TBMEs_two_J_A_max = CC_corrective_factors_TBMEs_tab.dimension (1) - 1;
      
  const class array<unsigned int> &CC_corrective_factors_TBMEs_BP_A_composite_tab = input_data_CC_Berggren.get_CC_corrective_factors_TBMEs_BP_A_composite_tab ();

  const class array<double> &CC_corrective_factors_TBMEs_J_A_composite_tab = input_data_CC_Berggren.get_CC_corrective_factors_TBMEs_J_A_composite_tab ();

  const class array<double> &CC_corrective_factors_TBMEs_composite_tab = input_data_CC_Berggren.get_CC_corrective_factors_TBMEs_composite_tab ();

  const class array<unsigned int> &CC_corrective_factors_cluster_composite_numbers = input_data_CC_Berggren.get_CC_corrective_factors_cluster_composite_numbers ();

  const int CC_corrective_factors_cluster_two_J_A_max = CC_corrective_factors_cluster_tab.dimension (2) - 1;
      
  const class array<unsigned int> &CC_corrective_factors_cluster_BP_A_composite_tab = input_data_CC_Berggren.get_CC_corrective_factors_cluster_BP_A_composite_tab ();

  const class array<double> &CC_corrective_factors_cluster_J_A_composite_tab = input_data_CC_Berggren.get_CC_corrective_factors_cluster_J_A_composite_tab ();

  const class array<double> &CC_corrective_factors_cluster_composite_tab = input_data_CC_Berggren.get_CC_corrective_factors_cluster_composite_tab ();
  
  CC_corrective_factors_TBMEs_tab = 1.0;

  for (unsigned int i = 0 ; i < CC_corrective_factors_TBMEs_composite_number ; i++)
    {
      const unsigned int BP_A = CC_corrective_factors_TBMEs_BP_A_composite_tab(i);

      const double J_A = CC_corrective_factors_TBMEs_J_A_composite_tab(i);

      const int two_J_A =  make_int (2.0*J_A);

      if (two_J_A > CC_corrective_factors_TBMEs_two_J_A_max) error_message_print_abort ("An angular quantum number is too large in CC interaction corrective factors");

      CC_corrective_factors_TBMEs_tab(BP_A , two_J_A) = CC_corrective_factors_TBMEs_composite_tab(i);
    }

  CC_corrective_factors_cluster_tab = 1.0;

  for (unsigned int cluster_index_c = 0 ; cluster_index_c < cluster_projectile_number ; cluster_index_c++)
    {
      const unsigned int CC_corrective_factors_cluster_composite_number = CC_corrective_factors_cluster_composite_numbers(cluster_index_c);
  
      for (unsigned int i = 0 ; i < CC_corrective_factors_cluster_composite_number ; i++)
	{
	  const unsigned int BP_A = CC_corrective_factors_cluster_BP_A_composite_tab(cluster_index_c , i);

	  const double J_A = CC_corrective_factors_cluster_J_A_composite_tab(cluster_index_c , i);

	  const int two_J_A =  make_int (2.0*J_A);

	  if (two_J_A > CC_corrective_factors_cluster_two_J_A_max) error_message_print_abort ("An angular quantum number is too large in CC cluster corrective factors");

	  CC_corrective_factors_cluster_tab(cluster_index_c , BP_A , two_J_A) = CC_corrective_factors_cluster_composite_tab(cluster_index_c , i);
	}
    }
}


void CC_Hamiltonian_data::cluster_corrective_factors_modification (
								   const class array<class CC_channel_class> &channels_tab ,
								   const class array<enum particle_type> &cluster_projectile_tab ,
								   const class array<class cluster_data> &cluster_projectile_data_tab)
{
  const unsigned int cluster_projectile_number = cluster_projectile_tab.dimension (0);

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type projectile_c = channel_c.get_projectile ();

      for (unsigned int cluster_index_c  = 0 ; cluster_index_c < cluster_projectile_number ; cluster_index_c++)
	{	  
	  const enum particle_type projectile_try_c = cluster_projectile_tab(cluster_index_c);

	  if (projectile_try_c == projectile_c)
	    {	      	      
	      const int A_projectile_c = channel_c.get_A_projectile ();
      
	      const double BP_c = channel_c.get_BP ();
      
	      const double Jc = channel_c.get_J ();

	      const int two_Jc = make_int (2.0*Jc);

	      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

	      const double J_projectile_c = channel_c.get_J_projectile ();
      
	      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();
	      
	      const double real_average_n_scat_Tc = real (average_n_scat_Tc);
      
	      const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);
      	      
	      const class nlj_table<bool> &cluster_CM_S_matrix_poles_c = data_c.get_cluster_CM_S_matrix_poles ();
      
	      const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c = data_c.get_Nmax_cluster_projectile_CM_tab ();	
      
	      const int Nmax_cluster_LCM_J_projectile_c = Nmax_cluster_projectile_CM_tab_c(LCM_projectile_c , J_projectile_c);
	      
	      const double CC_corrective_factors_cluster_composite_c = CC_corrective_factors_cluster_tab(cluster_index_c , BP_c , two_Jc);
	      
	      for (unsigned int icp = 0 ; icp <= ic ; icp++)
		{				
		  const class CC_channel_class &channel_cp = channels_tab(icp);

		  const enum particle_type projectile_cp = channel_cp.get_projectile ();
		  
		  for (unsigned int cluster_index_cp = 0 ; cluster_index_cp < cluster_projectile_number ; cluster_index_cp++)
		    {	  
		      const enum particle_type projectile_try_cp = cluster_projectile_tab(cluster_index_cp);

		      if (projectile_try_cp == projectile_cp)
			{				  
			  const int A_projectile_cp = channel_cp.get_A_projectile ();
			  
			  const double BP_cp = channel_cp.get_BP ();
			  
			  const double Jcp = channel_cp.get_J ();
			  
			  const int two_Jcp = make_int (2.0*Jcp);
			  
			  const int LCM_projectile_cp = channel_cp.get_LCM_projectile ();

			  const double J_projectile_cp = channel_cp.get_J_projectile ();
		  
			  const complex<double> average_n_scat_Tcp = channel_cp.get_average_n_scat_Tc ();
		  
			  const double real_average_n_scat_Tcp = real (average_n_scat_Tcp);

			  const class cluster_data &data_cp = get_cluster_projectile_data (projectile_cp , cluster_projectile_data_tab);
		  
			  const class lj_table<int> &Nmax_cluster_projectile_CM_tab_cp = data_cp.get_Nmax_cluster_projectile_CM_tab ();	

			  const int Nmax_cluster_LCM_J_projectile_cp = Nmax_cluster_projectile_CM_tab_cp(LCM_projectile_cp , J_projectile_cp);

			  const class nlj_table<bool> &cluster_CM_S_matrix_poles_cp = data_cp.get_cluster_CM_S_matrix_poles ();
		  
			  const double CC_corrective_factors_cluster_composite_cp = CC_corrective_factors_cluster_tab(cluster_index_cp , BP_cp , two_Jcp);
	      
			  const double CC_corrective_factors_cluster_composite_c_cp = CC_corrective_factors_cluster_composite_c*CC_corrective_factors_cluster_composite_cp;

			  if (CC_corrective_factors_cluster_composite_c_cp != 1.0)
			    {
			      for (int NCM_c = 0 ; NCM_c <= Nmax_cluster_LCM_J_projectile_c ; NCM_c++)  
				{	
				  const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c(NCM_c , LCM_projectile_c , J_projectile_c);
		  	  
				  const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

				  if (!is_it_forbidden_channel_tab(ic , NCM_c) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max))
				    {	
				      const int NCM_max_LCM_J_cp_NCM_c = (icp < ic) ? (Nmax_cluster_LCM_J_projectile_cp) : (NCM_c);
			  
				      const unsigned int index_in = matrices_indices(ic , NCM_c);

				      for (int NCM_cp = 0 ; NCM_cp <= NCM_max_LCM_J_cp_NCM_c ; NCM_cp++) 
					{
					  const bool S_matrix_pole_NCM_cp = cluster_CM_S_matrix_poles_cp(NCM_cp , LCM_projectile_cp , J_projectile_cp);
		      
					  const double real_average_n_scat_cp = (!S_matrix_pole_NCM_cp) ? (real_average_n_scat_Tcp + A_projectile_cp) : (real_average_n_scat_Tcp);

					  if (!is_it_forbidden_channel_tab(icp , NCM_cp) && (real_average_n_scat_cp <= CC_average_n_scat_target_projectile_max))
					    {	
					      const unsigned int index_out = matrices_indices(icp , NCM_cp);

					      overlaps_matrix(index_in , index_out) *= CC_corrective_factors_cluster_composite_c_cp;
					      H_matrix       (index_in , index_out) *= CC_corrective_factors_cluster_composite_c_cp;
					  
					      overlaps_matrix(index_out , index_in) = overlaps_matrix(index_in , index_out);
					      H_matrix       (index_out , index_in) =        H_matrix(index_in , index_out);				  
					  				  
					    }}}}}}}}}}}
}




void CC_Hamiltonian_data::overlaps_H_HO_matrices_calc ()
{
  if (dimension_matrices_HO > 1000)
    {
      OpenMP_parallelization_linear_algebra_enabled ();

      MPI_parallelization_linear_algebra_enabled ();
    }

  overlaps_HO_matrix.identity ();

  overlaps_HO_matrix += finite_range_overlaps_HO_matrix;

  sqrt_overlaps_HO_matrix = overlaps_HO_matrix;

  sqrt_inv_overlaps_HO_matrix = overlaps_HO_matrix;

  Moore_Penrose_sqrt (sqrt_overlaps_HO_matrix , relative_SVD_precision);

  Moore_Penrose_sqrt_inv (sqrt_inv_overlaps_HO_matrix , relative_SVD_precision);

  H_HO_matrix = Ho_HO_matrix + finite_range_potential_HO_matrix;

  OpenMP_parallelization_linear_algebra_disabled ();

  MPI_parallelization_linear_algebra_disabled ();
}






void CC_Hamiltonian_data::orthogonalized_H_matrix_CC_Berggren_one_baryon_calc (
									       const class array<class CC_channel_class> &channels_tab , 
									       const class baryons_data &prot_Y_data_CC_Berggren , 
									       const class baryons_data &neut_Y_data_CC_Berggren)
{
  const unsigned int N_channels = channels_tab.dimension (0);

  orthogonalized_H_matrix_CC_Berggren = 0.0;
  
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);
      
      const complex<double> E_Tc = channel_c.get_E_Tc ();

      const complex<double> &average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const enum particle_type particle_c = channel_c.get_projectile ();
		
      const int particle_c_charge = particle_charge_determine (particle_c);

      const bool is_particle_c_charged = (particle_c_charge != 0);
      
      const class baryons_data &data_tau_c_CC_Berggren = (is_particle_c_charged) ? (prot_Y_data_CC_Berggren) : (neut_Y_data_CC_Berggren);

      const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_c_CC_Berggren = data_tau_c_CC_Berggren.get_is_it_valence_shell_tabs ();

      const class array<class lj_table<int> > &nmax_lj_tabs_c_CC_Berggren = data_tau_c_CC_Berggren.get_nmax_lj_tabs ();

      const class array<class nlj_table<unsigned int> > &shells_indices_c_CC_Berggren_tab = data_tau_c_CC_Berggren.get_shells_indices_tab ();

      const class array<class nlj_struct> &shells_qn_c_CC_Berggren = data_tau_c_CC_Berggren.get_shells_quantum_numbers ();
            
      const unsigned int particle_index_c = charge_baryon_index_determine (particle_c);
  
      const class nlj_table<bool> &is_it_valence_shell_tab_c_CC_Berggren = is_it_valence_shell_tabs_c_CC_Berggren(particle_index_c);

      const class lj_table<int> &nmax_lj_tab_c_CC_Berggren = nmax_lj_tabs_c_CC_Berggren(particle_index_c);

      const class nlj_table<unsigned int> &shells_indices_c_CC_Berggren = shells_indices_c_CC_Berggren_tab(particle_index_c);

      const int lc = channel_c.get_LCM_projectile ();
      
      const double jc = channel_c.get_J_projectile ();
      
      const int nmax_c_CC_Berggren = nmax_lj_tab_c_CC_Berggren(lc , jc);

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const class array<class nlj_table<TYPE> > &h_basis_CC_Berggren_c_tab = data_tau_c_CC_Berggren.get_h_basis_tab ();
  
      const class nlj_table<TYPE> &h_basis_CC_Berggren_c = h_basis_CC_Berggren_c_tab(particle_index_c);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (int nc = 0 ; nc <= nmax_c_CC_Berggren ; nc++)
	{
	  if (is_it_valence_shell_tab_c_CC_Berggren(nc , lc , jc))
	    {
	      const unsigned int shell_index_c = shells_indices_c_CC_Berggren(nc , lc , jc);

	      const class nlj_struct &shell_qn_c = shells_qn_c_CC_Berggren(shell_index_c);

	      const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();
	      
	      const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);
	      
	      if (!is_it_forbidden_channel_CC_Berggren_tab(ic , nc) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max))
		{
		  const unsigned int index_in = matrices_indices_CC_Berggren(ic , nc);

		  const complex<double> e_nc = h_basis_CC_Berggren_c(nc , lc , jc);

		  orthogonalized_H_matrix_CC_Berggren(index_in , index_in) = e_nc + E_Tc;
				  
		  for (unsigned int icp = 0 ; icp < N_channels ; icp++)
		    {
		      const class CC_channel_class &channel_cp = channels_tab(icp);

		      const complex<double> average_n_scat_Tcp = channel_cp.get_average_n_scat_Tc ();

		      const enum particle_type particle_cp = channel_cp.get_projectile ();
		      
		      const int particle_cp_charge = particle_charge_determine (particle_cp);

		      const bool is_particle_cp_charged = (particle_cp_charge != 0);
		      
		      const class baryons_data &data_tau_cp_CC_Berggren = (is_particle_cp_charged) ? (prot_Y_data_CC_Berggren) : (neut_Y_data_CC_Berggren);
		      
		      const class array<class lj_table<int> > &nmax_lj_cp_tabs_CC_Berggren = data_tau_cp_CC_Berggren.get_nmax_lj_tabs ();
		      
		      const class array<class nlj_table<unsigned int> > &shells_indices_cp_tab_CC_Berggren = data_tau_cp_CC_Berggren.get_shells_indices_tab ();

		      const class array<class nlj_struct> &shells_qn_cp_CC_Berggren = data_tau_cp_CC_Berggren.get_shells_quantum_numbers ();

		      const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_cp_CC_Berggren = data_tau_cp_CC_Berggren.get_is_it_valence_shell_tabs ();
		      
		      const unsigned int particle_index_cp = charge_baryon_index_determine (particle_cp);
  
		      const class lj_table<int> &nmax_lj_cp_tab_CC_Berggren = nmax_lj_cp_tabs_CC_Berggren(particle_index_cp);

		      const class nlj_table<unsigned int> &shells_indices_cp_CC_Berggren = shells_indices_cp_tab_CC_Berggren(particle_index_cp);
		      
		      const class nlj_table<bool> &is_it_valence_shell_tab_cp_CC_Berggren = is_it_valence_shell_tabs_cp_CC_Berggren(particle_index_cp);
		      
		      const double jcp = channel_cp.get_J_projectile ();

		      const double real_average_n_scat_Tcp = real (average_n_scat_Tcp);

		      const int lcp = channel_cp.get_LCM_projectile ();

		      const int nmax_cp_CC_Berggren = nmax_lj_cp_tab_CC_Berggren(lcp , jcp);

		      for (int ncp = 0 ; ncp <= nmax_cp_CC_Berggren ; ncp++)
			{
			  if (is_it_valence_shell_tab_cp_CC_Berggren(ncp , lcp , jcp))
			    {	
			      const unsigned int shell_index_cp = shells_indices_cp_CC_Berggren(ncp , lcp , jcp);
			      
			      const class nlj_struct &shell_qn_cp = shells_qn_cp_CC_Berggren(shell_index_cp);

			      const bool S_matrix_pole_ncp = shell_qn_cp.get_S_matrix_pole ();

			      const double real_average_n_scat_cp = (!S_matrix_pole_ncp) ? (real_average_n_scat_Tcp + 1) : (real_average_n_scat_Tcp);

			      if (!is_it_forbidden_channel_CC_Berggren_tab(icp , ncp) && (real_average_n_scat_cp <= CC_average_n_scat_target_projectile_max))
				{	
				  const unsigned int index_out = matrices_indices_CC_Berggren(icp , ncp);
				  
				  const complex<double> ME_part = CC_H_MEs_one_baryon::finite_range_orthogonalized_potential_two_channels_two_CC_Berggren_calc (channels_tab , ic , icp , nc , ncp , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren ,
																				finite_range_orthogonalized_potential_HO_submatrices);
				  
				  orthogonalized_H_matrix_CC_Berggren(index_in , index_out) += ME_part;				
				}
			    }
			}
		    }
		}
	    }
	}
    }

  orthogonalized_H_matrix_CC_Berggren.symmetrize ();  
}







void CC_Hamiltonian_data::orthogonalized_H_matrix_CC_Berggren_cluster_calc (
									    const class array<class CC_channel_class> &channels_tab , 
									    const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab)
{	
  const unsigned int N_channels = channels_tab.dimension (0);

  orthogonalized_H_matrix_CC_Berggren = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const complex<double> E_Tc = channel_c.get_E_Tc ();

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const int A_projectile_c = channel_c.get_A_projectile ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const double J_projectile_c = channel_c.get_J_projectile ();

      const class cluster_data &data_c_CC_Berggren = get_cluster_projectile_data (projectile_c , cluster_projectile_data_CC_Berggren_tab);

      const class nlj_table<bool> &cluster_CM_S_matrix_poles_c_CC_Berggren = data_c_CC_Berggren.get_cluster_CM_S_matrix_poles ();

      const class lj_table<int> &Nmax_cluster_projectile_CM_CC_Berggren_tab_c = data_c_CC_Berggren.get_Nmax_cluster_projectile_CM_tab ();

      const int NCM_max_LCM_projectile_c_CC_Berggren = Nmax_cluster_projectile_CM_CC_Berggren_tab_c(LCM_projectile_c , J_projectile_c);

      const complex<double> E_intrinsic_projectile_c = channel_c.get_E_intrinsic_projectile_c ();

      const class nlj_table<complex<double> > &cluster_CM_E_CC_Berggren_tab_c = data_c_CC_Berggren.get_cluster_CM_E_tab ();

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (int NCM_c = 0 ; NCM_c <= NCM_max_LCM_projectile_c_CC_Berggren ; NCM_c++)
	{
	  const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c_CC_Berggren(NCM_c , LCM_projectile_c , J_projectile_c);

	  const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);
	      
	  if (!is_it_forbidden_channel_CC_Berggren_tab(ic , NCM_c) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max))
	    {	
	      const unsigned int index_in = matrices_indices_CC_Berggren(ic , NCM_c);
	      
	      const complex<double> E_CM_c = cluster_CM_E_CC_Berggren_tab_c(NCM_c , LCM_projectile_c , J_projectile_c);

	      orthogonalized_H_matrix_CC_Berggren(index_in , index_in) = E_CM_c + E_Tc + E_intrinsic_projectile_c;
  
	      for (int NCM_cp = 0 ; NCM_cp <= NCM_max_LCM_projectile_c_CC_Berggren ; NCM_cp++)
		{
		  const bool S_matrix_pole_NCM_cp = cluster_CM_S_matrix_poles_c_CC_Berggren(NCM_cp , LCM_projectile_c , J_projectile_c);

		  const double real_average_n_scat_cp = (!S_matrix_pole_NCM_cp) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

		  if (!is_it_forbidden_channel_CC_Berggren_tab(ic , NCM_cp) && (real_average_n_scat_cp <= CC_average_n_scat_target_projectile_max))
		    {	
		      const unsigned int index_out = matrices_indices_CC_Berggren(ic , NCM_cp);
		      
		      const complex<double> E_CM_cp = cluster_CM_E_CC_Berggren_tab_c(NCM_cp , LCM_projectile_c , J_projectile_c);

		      const complex<double> ME_OCM_part = CC_H_MEs_cluster::OCM_potential_part_two_channels_two_CC_Berggren_calc (channels_tab , ic , NCM_c , NCM_cp , E_CM_c , E_CM_cp , cluster_projectile_data_CC_Berggren_tab ,
																  QCM_HO_submatrices , QCM_HCM_QCM_HO_submatrices);

		      orthogonalized_H_matrix_CC_Berggren(index_in , index_out) += ME_OCM_part;
		    }
		}
	    }
	}
    }
		      
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const int A_projectile_c = channel_c.get_A_projectile ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const double J_projectile_c = channel_c.get_J_projectile ();

      const class cluster_data &data_c_CC_Berggren = get_cluster_projectile_data (projectile_c , cluster_projectile_data_CC_Berggren_tab);

      const class nlj_table<bool> &cluster_CM_S_matrix_poles_c_CC_Berggren = data_c_CC_Berggren.get_cluster_CM_S_matrix_poles ();

      const class lj_table<int> &Nmax_cluster_projectile_CM_CC_Berggren_tab_c = data_c_CC_Berggren.get_Nmax_cluster_projectile_CM_tab ();

      const int NCM_max_LCM_projectile_c_CC_Berggren = Nmax_cluster_projectile_CM_CC_Berggren_tab_c(LCM_projectile_c , J_projectile_c);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (int NCM_c = 0 ; NCM_c <= NCM_max_LCM_projectile_c_CC_Berggren ; NCM_c++)
	{
	  const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c_CC_Berggren(NCM_c , LCM_projectile_c , J_projectile_c);

	  const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_CC_Berggren_tab(ic , NCM_c) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max))
	    {	
	      const unsigned int index_in = matrices_indices_CC_Berggren(ic , NCM_c);

	      for (unsigned int icp = 0 ; icp < N_channels ; icp++)
		{
		  const class CC_channel_class &channel_cp = channels_tab(icp);

		  const enum particle_type projectile_cp = channel_cp.get_projectile ();

		  const complex<double> average_n_scat_Tcp = channel_cp.get_average_n_scat_Tc ();

		  const int A_projectile_cp = channel_cp.get_A_projectile ();

		  const int LCM_projectile_cp = channel_cp.get_LCM_projectile ();

		  const double real_average_n_scat_Tcp = real (average_n_scat_Tcp);

		  const double J_projectile_cp = channel_cp.get_J_projectile ();

		  const class cluster_data &data_cp_CC_Berggren = get_cluster_projectile_data (projectile_cp , cluster_projectile_data_CC_Berggren_tab);

		  const class lj_table<int> &Nmax_cluster_projectile_CM_CC_Berggren_tab_cp = data_cp_CC_Berggren.get_Nmax_cluster_projectile_CM_tab ();

		  const int NCM_max_LCM_projectile_cp_CC_Berggren = Nmax_cluster_projectile_CM_CC_Berggren_tab_cp(LCM_projectile_cp , J_projectile_cp);

		  const class nlj_table<bool> &cluster_CM_S_matrix_poles_cp_CC_Berggren = data_cp_CC_Berggren.get_cluster_CM_S_matrix_poles ();

		  for (int NCM_cp = 0 ; NCM_cp <= NCM_max_LCM_projectile_cp_CC_Berggren ; NCM_cp++)
		    {
		      const bool S_matrix_pole_NCM_cp = cluster_CM_S_matrix_poles_cp_CC_Berggren(NCM_cp , LCM_projectile_cp , J_projectile_cp);

		      const double real_average_n_scat_cp = (!S_matrix_pole_NCM_cp) ? (real_average_n_scat_Tcp + A_projectile_cp) : (real_average_n_scat_Tcp);

		      if (!is_it_forbidden_channel_CC_Berggren_tab(icp , NCM_cp) && (real_average_n_scat_cp <= CC_average_n_scat_target_projectile_max))
			{	
			  const unsigned int index_out = matrices_indices_CC_Berggren(icp , NCM_cp);

			  const complex<double> ME_potential_part = CC_H_MEs_cluster::finite_range_orthogonalized_potential_two_channels_two_CC_Berggren_calc (channels_tab , ic , icp , NCM_c , NCM_cp , cluster_projectile_data_CC_Berggren_tab ,
																			       finite_range_orthogonalized_potential_HO_submatrices);
			  
			  orthogonalized_H_matrix_CC_Berggren(index_in , index_out) += ME_potential_part;
			}
		    }
		}
	    }
	}
    }

  orthogonalized_H_matrix_CC_Berggren.symmetrize ();
}







void CC_Hamiltonian_data::HO_submatrices_one_baryon_fill (
							  const class array<class CC_channel_class> &channels_tab , 
							  const class interaction_class &inter_data_basis)
{	
  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const int lc = channel_c.get_LCM_projectile ();

      const int nmax_HO_c = nmax_HO_lab_tab(lc);

      for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	{
	  const class CC_channel_class &channel_cp = channels_tab(icp);

	  const int lcp = channel_cp.get_LCM_projectile ();

	  const int nmax_HO_cp = nmax_HO_lab_tab(lcp);

	  class matrix<complex<double> > &finite_range_overlaps_HO_submatrix = finite_range_overlaps_HO_submatrices(ic , icp);
	  
	  class matrix<complex<double> > &finite_range_potential_HO_submatrix = finite_range_potential_HO_submatrices(ic , icp); 

	  class matrix<complex<double> > &Delta_HO_submatrix = Delta_HO_submatrices(ic , icp);

	  class matrix<complex<double> > &finite_range_orthogonalized_potential_HO_submatrix = finite_range_orthogonalized_potential_HO_submatrices(ic , icp);

	  for (int nHOc = 0 ; nHOc <= nmax_HO_c ; nHOc++)
	    {
	      const unsigned int in_HO = matrices_indices_HO(ic , nHOc);

	      for (int nHOcp = 0 ; nHOcp <= nmax_HO_cp ; nHOcp++)
		{
		  const unsigned int out_HO = matrices_indices_HO(icp , nHOcp);

		  finite_range_overlaps_HO_submatrix(nHOc , nHOcp) = finite_range_overlaps_HO_matrix(in_HO , out_HO);
		  
		  finite_range_potential_HO_submatrix(nHOc , nHOcp) = finite_range_potential_HO_matrix(in_HO , out_HO);

		  Delta_HO_submatrix(nHOc , nHOcp) = Delta_HO_matrix(in_HO , out_HO);

		  finite_range_orthogonalized_potential_HO_submatrix(nHOc , nHOcp) = finite_range_orthogonalized_potential_HO_matrix(in_HO , out_HO);
		}
	    }
	}
    }
}






void CC_Hamiltonian_data::HO_submatrices_cluster_fill (
						       const class array<class CC_channel_class> &channels_tab , 
						       const class array<class cluster_data> &cluster_projectile_data_tab)
{
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);	

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const class array<int> &Nmax_HO_tab_c = data_c.get_Nmax_HO_tab ();

      const int NCM_HO_max_LCM_projectile_c = Nmax_HO_tab_c(LCM_projectile_c);

      for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	{		
	  const class CC_channel_class &channel_cp = channels_tab(icp);

	  const enum particle_type projectile_cp = channel_cp.get_projectile ();	

	  const class cluster_data &data_cp = get_cluster_projectile_data (projectile_cp , cluster_projectile_data_tab);	

	  const int LCM_projectile_cp = channel_cp.get_LCM_projectile ();

	  const class array<int> &Nmax_HO_tab_cp = data_cp.get_Nmax_HO_tab ();

	  const int NCM_HO_max_LCM_projectile_cp = Nmax_HO_tab_cp(LCM_projectile_cp);

	  class matrix<complex<double> > &finite_range_overlaps_HO_submatrix = finite_range_overlaps_HO_submatrices(ic , icp);
	  
	  class matrix<complex<double> > &finite_range_potential_HO_submatrix = finite_range_potential_HO_submatrices(ic , icp); 

	  class matrix<complex<double> > &Delta_HO_submatrix = Delta_HO_submatrices(ic , icp);

	  class matrix<complex<double> > &finite_range_orthogonalized_potential_HO_submatrix = finite_range_orthogonalized_potential_HO_submatrices(ic , icp);
	  
	  for (int NCM_HO_c = 0 ; NCM_HO_c <= NCM_HO_max_LCM_projectile_c ; NCM_HO_c++)
	    {
	      const unsigned int in_HO = matrices_indices_HO(ic , NCM_HO_c);

	      for (int NCM_HO_cp = 0 ; NCM_HO_cp <= NCM_HO_max_LCM_projectile_cp ; NCM_HO_cp++)
		{
		  const unsigned int out_HO = matrices_indices_HO(icp , NCM_HO_cp);

		  finite_range_overlaps_HO_submatrix(NCM_HO_c , NCM_HO_cp) = finite_range_overlaps_HO_matrix(in_HO , out_HO);
		  
		  finite_range_potential_HO_submatrix(NCM_HO_c , NCM_HO_cp) = finite_range_potential_HO_matrix(in_HO , out_HO);

		  Delta_HO_submatrix(NCM_HO_c , NCM_HO_cp) = Delta_HO_matrix(in_HO , out_HO);

		  finite_range_orthogonalized_potential_HO_submatrix(NCM_HO_c , NCM_HO_cp) = finite_range_orthogonalized_potential_HO_matrix(in_HO , out_HO);
		}
	    }
	}
    }
}



void CC_Hamiltonian_data::H_overlaps_matrices_copy_disk (const unsigned int BP , const double J) const
{
  class array<complex<double> > overlaps_pole_approximation(dimension_matrices_pole_approximation , dimension_matrices_pole_approximation);

  class array<complex<double> > H_MEs_pole_approximation(dimension_matrices_pole_approximation , dimension_matrices_pole_approximation);

  class array<complex<double> > overlaps(dimension_matrices , dimension_matrices);

  class array<complex<double> > H_MEs(dimension_matrices , dimension_matrices);

  for (unsigned int i = 0 ; i < dimension_matrices_pole_approximation ; i++)
    for (unsigned int j = 0 ; j < dimension_matrices_pole_approximation ; j++)
      {
	overlaps_pole_approximation(i , j) = overlaps_matrix_pole_approximation(i , j);

	H_MEs_pole_approximation(i , j) = H_matrix_pole_approximation(i , j);
      }

  for (unsigned int i = 0 ; i < dimension_matrices ; i++)
    for (unsigned int j = 0 ; j < dimension_matrices ; j++)
      {
	overlaps(i , j) = overlaps_matrix(i , j);

	H_MEs(i , j) = H_matrix(i , j);
      }

  const string overlaps_pole_approximation_file_name = file_name_J_Pi_string ("CC_overlaps_matrix_pole_approximation" , BP , J);
  const string H_matrix_pole_approximation_file_name = file_name_J_Pi_string ("CC_H_matrix_pole_approximation" , BP , J);	

  const string overlaps_file_name = file_name_J_Pi_string ("CC_overlaps_matrix" , BP , J);
  const string H_matrix_file_name = file_name_J_Pi_string ("CC_H_matrix" , BP , J);	

  overlaps_pole_approximation.copy_disk (overlaps_pole_approximation_file_name);

  H_MEs_pole_approximation.copy_disk (H_matrix_pole_approximation_file_name); 

  overlaps.copy_disk (overlaps_file_name);

  H_MEs.copy_disk (H_matrix_file_name); 
}







void CC_Hamiltonian_data::H_overlaps_matrices_read_from_file (const unsigned int BP , const double J)
{	
  const string overlaps_pole_approximation_file_name = file_name_J_Pi_string ("CC_overlaps_matrix_pole_approximation" , BP , J);
  const string H_matrix_pole_approximation_file_name = file_name_J_Pi_string ("CC_H_matrix_pole_approximation" , BP , J);	

  const string overlaps_file_name = file_name_J_Pi_string ("CC_overlaps_matrix" , BP , J);
  const string H_matrix_file_name = file_name_J_Pi_string ("CC_H_matrix" , BP , J);	

  class array<complex<double> > overlaps_pole_approximation(dimension_matrices_pole_approximation , dimension_matrices_pole_approximation);

  class array<complex<double> > H_MEs_pole_approximation(dimension_matrices_pole_approximation , dimension_matrices_pole_approximation);

  class array<complex<double> > overlaps(dimension_matrices , dimension_matrices);

  class array<complex<double> > H_MEs(dimension_matrices , dimension_matrices); 

  overlaps_pole_approximation.read_disk (overlaps_pole_approximation_file_name);

  H_MEs_pole_approximation.read_disk (H_matrix_pole_approximation_file_name);

  overlaps.read_disk (overlaps_file_name);

  H_MEs.read_disk (H_matrix_file_name);

  for (unsigned int i = 0 ; i < dimension_matrices_pole_approximation ; i++)
    for (unsigned int j = 0 ; j < dimension_matrices_pole_approximation ; j++)
      {
	overlaps_matrix_pole_approximation(i , j) = overlaps_pole_approximation(i , j);

	H_matrix_pole_approximation(i , j) = H_MEs_pole_approximation(i , j);
      }

  for (unsigned int i = 0 ; i < dimension_matrices ; i++)
    for (unsigned int j = 0 ; j < dimension_matrices ; j++)
      {
	overlaps_matrix(i , j) = overlaps(i , j);

	H_matrix(i , j) = H_MEs(i , j);
      }
}




void CC_Hamiltonian_data::H_tridiagonalized_copy_disk (const unsigned int BP , const double J) const
{
  class array<complex<double> > orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren_array(dimension_matrices_CC_Berggren , dimension_matrices_CC_Berggren);

  class array<complex<double> > orthogonalized_H_tridiagonalized_diagonal_CC_Berggren_array(dimension_matrices_CC_Berggren);

  class array<complex<double> > orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren_array(dimension_matrices_CC_Berggren);

  for (unsigned int i = 0 ; i < dimension_matrices_CC_Berggren ; i++)
    for (unsigned int j = 0 ; j < dimension_matrices_CC_Berggren ; j++)
      orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren_array(i , j) = orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren(i , j);

  for (unsigned int i = 0 ; i < dimension_matrices_CC_Berggren ; i++) 
    {
      orthogonalized_H_tridiagonalized_diagonal_CC_Berggren_array(i) = orthogonalized_H_tridiagonalized_diagonal_CC_Berggren(i);

      orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren_array(i) = orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren(i);
    }

  const string orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren_file_name = file_name_J_Pi_string ("orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren" , BP , J);

  const string orthogonalized_H_tridiagonalized_diagonal_CC_Berggren_file_name = file_name_J_Pi_string ("orthogonalized_H_tridiagonalized_diagonal_CC_Berggren" , BP , J);

  const string orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren_file_name = file_name_J_Pi_string ("orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren" , BP , J);

  orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren_array.copy_disk (orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren_file_name);
  
  orthogonalized_H_tridiagonalized_diagonal_CC_Berggren_array.copy_disk (orthogonalized_H_tridiagonalized_diagonal_CC_Berggren_file_name);

  orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren_array.copy_disk (orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren_file_name);
}







void CC_Hamiltonian_data::H_tridiagonalized_read_from_file (const unsigned int BP , const double J)
{
  const string orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren_file_name = file_name_J_Pi_string ("orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren" , BP , J);

  const string orthogonalized_H_tridiagonalized_diagonal_CC_Berggren_file_name = file_name_J_Pi_string ("orthogonalized_H_tridiagonalized_diagonal_CC_Berggren" , BP , J);

  const string orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren_file_name = file_name_J_Pi_string ("orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren" , BP , J);

  class array<complex<double> > orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren_array(dimension_matrices_CC_Berggren , dimension_matrices_CC_Berggren);

  class array<complex<double> > orthogonalized_H_tridiagonalized_diagonal_CC_Berggren_array(dimension_matrices_CC_Berggren);

  class array<complex<double> > orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren_array(dimension_matrices_CC_Berggren);

  orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren_array.read_disk (orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren_file_name);
  
  orthogonalized_H_tridiagonalized_diagonal_CC_Berggren_array.read_disk (orthogonalized_H_tridiagonalized_diagonal_CC_Berggren_file_name);

  orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren_array.read_disk (orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren_file_name);

  for (unsigned int i = 0 ; i < dimension_matrices_CC_Berggren ; i++)
    for (unsigned int j = 0 ; j < dimension_matrices_CC_Berggren ; j++)
      orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren(i , j) = orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren_array(i , j);

  for (unsigned int i = 0 ; i < dimension_matrices_CC_Berggren ; i++) 
    {
      orthogonalized_H_tridiagonalized_diagonal_CC_Berggren(i) = orthogonalized_H_tridiagonalized_diagonal_CC_Berggren_array(i);

      orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren(i) = orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren_array(i);
    }

  orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren = orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren;

  orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren.transpose ();
}








#ifdef UseMPI

void CC_Hamiltonian_data::H_overlaps_matrices_MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  overlaps_matrix_pole_approximation.MPI_Bcast (Send_process , MPI_C);

  H_matrix_pole_approximation.MPI_Bcast (Send_process , MPI_C);

  overlaps_matrix.MPI_Bcast (Send_process , MPI_C);

  H_matrix.MPI_Bcast (Send_process , MPI_C);
}

void CC_Hamiltonian_data::H_overlaps_matrices_MPI_Allreduce (const MPI_Op op , const MPI_Comm MPI_C)
{
  overlaps_matrix_pole_approximation.MPI_Allreduce (op , MPI_C);

  H_matrix_pole_approximation.MPI_Allreduce (op , MPI_C);

  overlaps_matrix.MPI_Allreduce (op , MPI_C);

  H_matrix.MPI_Allreduce (op , MPI_C);
}

void CC_Hamiltonian_data::H_tridiagonalized_MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren.MPI_Bcast (Send_process , MPI_C);

  orthogonalized_H_tridiagonalized_diagonal_CC_Berggren.MPI_Bcast (Send_process , MPI_C);

  orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren.MPI_Bcast (Send_process , MPI_C);
}

#endif










void CC_Hamiltonian_data::overlaps_H_matrices_diagonalization_test (const unsigned int BP , const double J) const
{
  const unsigned int N_limit_HO = min (dimension_matrices_HO , make_uns_int (50));

  const unsigned int N_limit = min (dimension_matrices , make_uns_int (50));

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << "dimension matrices HO : " << dimension_matrices_HO << endl << endl;
      cout << "dimension matrices pole approximation : " << dimension_matrices_pole_approximation << endl << endl;
      cout << "dimension matrices : " << dimension_matrices << endl << endl;
    }

  class matrix<complex<double> > overlaps_test_matrix_pole_approximation = overlaps_matrix_pole_approximation;

  class array<complex<double> > overlaps_eigenvalue_pole_approximation (dimension_matrices_pole_approximation);

  total_diagonalization::symmetric::all_eigenvalues_Householder (overlaps_test_matrix_pole_approximation , overlaps_eigenvalue_pole_approximation);
  
  class matrix<complex<double> > sqrt_inv_overlaps_matrix_pole_approximation = overlaps_matrix_pole_approximation;

  Moore_Penrose_sqrt_inv (sqrt_inv_overlaps_matrix_pole_approximation , relative_SVD_precision);

  class matrix<complex<double> > orthogonalized_H_matrix_pole_approximation = sqrt_inv_overlaps_matrix_pole_approximation*H_matrix_pole_approximation*sqrt_inv_overlaps_matrix_pole_approximation;
  
  class array<complex<double> > orthogonalized_H_eigenvalues_pole_approximation (dimension_matrices_pole_approximation);

  orthogonalized_H_matrix_pole_approximation.symmetrize ();

  total_diagonalization::symmetric::all_eigenvalues (orthogonalized_H_matrix_pole_approximation , orthogonalized_H_eigenvalues_pole_approximation);

  if (dimension_matrices_HO > 1000)
    {
      OpenMP_parallelization_linear_algebra_enabled ();

      MPI_parallelization_linear_algebra_enabled ();
    }

  class matrix<double> overlaps_test_HO_matrix = overlaps_HO_matrix;

  class array<double> overlaps_eigenvalues_HO (dimension_matrices_HO);

  total_diagonalization::symmetric::all_eigenvalues_Householder (overlaps_test_HO_matrix , overlaps_eigenvalues_HO);

  class matrix<double> sqrt_inv_overlaps_HO_matrix = overlaps_HO_matrix;

  Moore_Penrose_sqrt_inv (sqrt_inv_overlaps_HO_matrix , relative_SVD_precision);

  class matrix<double> H_matrix_to_diag_HO = sqrt_inv_overlaps_HO_matrix*H_HO_matrix*sqrt_inv_overlaps_HO_matrix;

  class array<double> H_eigenvalues_HO (dimension_matrices_HO);

  H_matrix_to_diag_HO.symmetrize ();

  total_diagonalization::symmetric::all_eigenvalues (H_matrix_to_diag_HO , H_eigenvalues_HO);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      unsigned int i_print_HO_overlaps = 0;

      for (unsigned int i = 0 ; i < dimension_matrices_HO  ; i++)
	{
	  if ((abs (overlaps_eigenvalues_HO(i)) > sqrt_precision) && (i_print_HO_overlaps++ < N_limit_HO))
	    cout << "Overlaps matrix " << J_Pi_string (BP , J) << " (" << i << ") HO eigenvalue : " << overlaps_eigenvalues_HO(i) << endl;
	}

      cout << endl;

      unsigned int i_print_HO_eigenvalues = 0;

      for (unsigned int i = 0 ; i < dimension_matrices_HO ; i++)
	{
	  if ((abs (H_eigenvalues_HO(i)) > sqrt_precision) && (i_print_HO_eigenvalues++ < N_limit_HO)) 
	    cout << "Orthogonalized H channel matrix " << J_Pi_string (BP , J) << " (" << i << ") HO eigenvalue : E(COSM) : " << H_eigenvalues_HO(i) << " MeV" << endl;
	}

      cout << endl;
    }

  OpenMP_parallelization_linear_algebra_disabled ();

  MPI_parallelization_linear_algebra_disabled ();

  if (dimension_matrices > 1000)
    {
      OpenMP_parallelization_linear_algebra_enabled ();

      MPI_parallelization_linear_algebra_enabled ();
    }

  class matrix<complex<double> > overlaps_test_matrix = overlaps_matrix;

  class array<complex<double> > overlaps_eigenvalue (dimension_matrices);

  total_diagonalization::symmetric::all_eigenvalues_Householder (overlaps_test_matrix , overlaps_eigenvalue);

  class matrix<complex<double> > sqrt_inv_overlaps_matrix = overlaps_matrix;

  Moore_Penrose_sqrt_inv (sqrt_inv_overlaps_matrix , relative_SVD_precision);

  class matrix<complex<double> > orthogonalized_H_matrix = sqrt_inv_overlaps_matrix*H_matrix*sqrt_inv_overlaps_matrix;

  class array<complex<double> > orthogonalized_H_eigenvalues (dimension_matrices);

  orthogonalized_H_matrix.symmetrize ();

  total_diagonalization::symmetric::all_eigenvalues (orthogonalized_H_matrix , orthogonalized_H_eigenvalues);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      for (unsigned int i = 0 ; i < dimension_matrices_pole_approximation ; i++)
	cout << "Overlaps matrix " << J_Pi_string (BP , J) << " (" << i << ") eigenvalue with GSM pole approximation : " << overlaps_eigenvalue_pole_approximation(i) << endl;

      cout << endl;

      unsigned int i_print_overlaps = 0;

      for (unsigned int i = 0 ; i < dimension_matrices ; i++)
	{
	  if ((inf_norm (overlaps_eigenvalue(i)) > sqrt_precision) && (i_print_overlaps++ < N_limit))
	    cout << "Overlaps matrix " << J_Pi_string (BP , J) << " (" << i << ") eigenvalue with GSM space : " << overlaps_eigenvalue(i) << endl;
	}

      cout << endl;

      for (unsigned int i = 0 ; i < dimension_matrices_pole_approximation ; i++) 
	{
	  cout << "Orthogonalized H channel matrix " << J_Pi_string (BP , J) << " (" << i << ") eigenvalue with GSM pole approximation : ";
	  cout << "E(COSM) : " << real (orthogonalized_H_eigenvalues_pole_approximation(i)) << " MeV G : " << - 2000.0 * imag (orthogonalized_H_eigenvalues_pole_approximation(i)) << " keV" << endl;
	}

      cout << endl;

      unsigned int i_print_eigenvalues = 0;

      for (unsigned int i = 0 ; i < dimension_matrices ; i++)
	{
	  if ((inf_norm (orthogonalized_H_eigenvalues(i)) > sqrt_precision) && (i_print_eigenvalues++ < N_limit))
	    {
	      cout << "Orthogonalized H channel matrix " << J_Pi_string (BP , J) << " (" << i << ") eigenvalue with GSM space : ";
	      cout << "E(COSM) : " << real (orthogonalized_H_eigenvalues(i)) << " MeV G : " << - 2000.0 * imag (orthogonalized_H_eigenvalues(i)) << " keV" << endl;
	    }
	}

      cout << endl;
    }

  OpenMP_parallelization_linear_algebra_disabled ();

  MPI_parallelization_linear_algebra_disabled ();
}








void CC_Hamiltonian_data::finite_range_overlaps_potential_Ho_HO_matrices_one_baryon_calc (
											  const class array<class CC_channel_class> &channels_tab , 
											  const class interaction_class &inter_data_basis , 
											  const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
											  const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
											  const class baryons_data &prot_Y_data_one_configuration_GSM , 
											  const class baryons_data &neut_Y_data_one_configuration_GSM , 
											  const class baryons_data &prot_Y_data , 
											  const class baryons_data &neut_Y_data , 
											  const class baryons_data &prot_Y_data_CC_Berggren , 
											  const class baryons_data &neut_Y_data_CC_Berggren)
{
  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  finite_range_overlaps_HO_matrix = 0.0;

  finite_range_potential_HO_matrix = 0.0;

  Ho_HO_matrix = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const int lc = channel_c.get_LCM_projectile ();

      const int nmax_HO_c = nmax_HO_lab_tab(lc);

      for (int nHOc = 0 ; nHOc <= nmax_HO_c ; nHOc++)
	{
	  const unsigned int in_HO = matrices_indices_HO(ic , nHOc);

	  for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	    {
	      const class CC_channel_class &channel_cp = channels_tab(icp);

	      const int lcp = channel_cp.get_LCM_projectile ();

	      const int nmax_HO_cp = nmax_HO_lab_tab(lcp);

	      for (int nHOcp = 0 ; nHOcp <= nmax_HO_cp ; nHOcp++)
		{
		  const unsigned int out_HO = matrices_indices_HO(icp , nHOcp);

		  finite_range_overlaps_HO_matrix(in_HO , out_HO)
		    = CC_H_MEs_one_baryon::finite_range_overlap_matrix_two_channels_two_HO_calc (CC_average_n_scat_target_projectile_max , channels_tab , is_it_forbidden_channel_tab , 
												 ic , icp , nHOc , nHOcp , prot_Y_data , neut_Y_data , matrices_indices , overlaps_matrix);

		  finite_range_potential_HO_matrix(in_HO , out_HO)
		    = CC_H_MEs_one_baryon::potential_two_channels_two_HO_calc (CC_average_n_scat_target_projectile_max , channels_tab , 
									       is_it_forbidden_channel_tab , is_it_forbidden_channel_CC_Berggren_tab , CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , 
									       prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , prot_Y_data_one_configuration_GSM , neut_Y_data_one_configuration_GSM , 
									       ic , icp , nHOc , nHOcp , prot_Y_data , neut_Y_data , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , matrices_indices , H_matrix);

		  if (ic == icp) 
		    {
		      Ho_HO_matrix(in_HO , out_HO) = CC_H_MEs_one_baryon::Ho_two_HO_calc (
											  CC_average_n_scat_target_projectile_max , channels_tab , is_it_forbidden_channel_tab , is_it_forbidden_channel_CC_Berggren_tab , 
											  CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , 
											  prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , prot_Y_data_one_configuration_GSM , neut_Y_data_one_configuration_GSM , 
											  ic , nHOc , nHOcp , prot_Y_data , neut_Y_data , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren);
		    }
		}
	    }
	}
    }

  finite_range_overlaps_HO_matrix.symmetrize ();

  finite_range_potential_HO_matrix.symmetrize ();

  Ho_HO_matrix.symmetrize ();
}








void CC_Hamiltonian_data::finite_range_overlaps_potential_Ho_HO_matrices_cluster_calc (
										       const class array<class CC_channel_class> &channels_tab , 
										       const class array<class cluster_data> &cluster_projectile_data_tab)
{
  finite_range_overlaps_HO_matrix = 0.0;

  finite_range_potential_HO_matrix = 0.0;

  Ho_HO_matrix = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);	

      const class array<int> &Nmax_HO_tab_c = data_c.get_Nmax_HO_tab ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const int NCM_HO_max_LCM_projectile_c = Nmax_HO_tab_c(LCM_projectile_c);

      for (int NCM_HO_c = 0 ; NCM_HO_c <= NCM_HO_max_LCM_projectile_c ; NCM_HO_c++) 
	{
	  const unsigned int in_HO = matrices_indices_HO(ic , NCM_HO_c);

	  for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	    {
	      const class CC_channel_class &channel_cp = channels_tab(icp);

	      const enum particle_type projectile_cp = channel_cp.get_projectile ();	

	      const class cluster_data &data_cp = get_cluster_projectile_data (projectile_cp , cluster_projectile_data_tab);	

	      const class array<int> &Nmax_HO_tab_cp = data_cp.get_Nmax_HO_tab ();

	      const int LCM_projectile_cp = channel_cp.get_LCM_projectile ();

	      const int NCM_HO_max_LCM_projectile_cp = Nmax_HO_tab_cp(LCM_projectile_cp);

	      for (int NCM_HO_cp = 0 ; NCM_HO_cp <= NCM_HO_max_LCM_projectile_cp ; NCM_HO_cp++)
		{
		  const unsigned int out_HO = matrices_indices_HO(icp , NCM_HO_cp);

		  finite_range_overlaps_HO_matrix(in_HO , out_HO)
		    = CC_H_MEs_cluster::finite_range_overlap_matrix_two_channels_two_HO_calc (CC_average_n_scat_target_projectile_max , channels_tab , is_it_forbidden_channel_tab , 
											      ic , icp , NCM_HO_c , NCM_HO_cp , cluster_projectile_data_tab , matrices_indices , overlaps_matrix);

		  finite_range_potential_HO_matrix(in_HO , out_HO)
		    = CC_H_MEs_cluster::potential_two_channels_two_HO_calc (CC_average_n_scat_target_projectile_max , channels_tab , is_it_forbidden_channel_tab , 
									    ic , icp , NCM_HO_c , NCM_HO_cp , cluster_projectile_data_tab , matrices_indices , H_matrix , PCM_HCM_PCM_HO_submatrices);

		  if (ic == icp) 
		    {
		      Ho_HO_matrix(in_HO , out_HO) = CC_H_MEs_cluster::Ho_two_HO_calc (channels_tab , ic , NCM_HO_c , NCM_HO_cp , PCM_HCM_PCM_HO_submatrices);
		    }
		}
	    }
	}
    }

  finite_range_overlaps_HO_matrix.symmetrize ();

  finite_range_potential_HO_matrix.symmetrize ();

  Ho_HO_matrix.symmetrize ();
}











// Beware of matrix references on matrix_CC_Berggren: they refer to the same object but have different names to infer their value.

void CC_Hamiltonian_data::Delta_H_HO_matrices_one_baryon_calc (
							       const class array<class CC_channel_class> &channels_tab , 
							       const class baryons_data &prot_Y_data , 
							       const class baryons_data &neut_Y_data , 
							       const class interaction_class &inter_data_basis)
{
  if (dimension_matrices > 1000)
    {
      OpenMP_parallelization_linear_algebra_enabled ();

      MPI_parallelization_linear_algebra_enabled ();
    }
  
  class matrix<complex<double> > Delta_matrix = overlaps_matrix;

  Moore_Penrose_sqrt_inv (Delta_matrix , relative_SVD_precision);

  Delta_matrix.remove_scalar_diagonal_part (1.0);

  original_to_HO_matrix_one_baryon_calc (channels_tab , prot_Y_data , neut_Y_data , inter_data_basis , Delta_matrix , Delta_HO_matrix);
  
  class matrix<complex<double> > storage_matrix(dimension_matrices);
  
  class matrix<complex<double> > &H_Delta_plus_Delta_H_matrix = storage_matrix;

  H_Delta_plus_Delta_H_matrix = H_matrix*Delta_matrix;

  H_Delta_plus_Delta_H_matrix += Delta_matrix*H_matrix;

  original_to_HO_matrix_one_baryon_calc (channels_tab , prot_Y_data , neut_Y_data , inter_data_basis , H_Delta_plus_Delta_H_matrix , H_Delta_plus_Delta_H_HO_matrix);

  class matrix<complex<double> > &Delta_H_Delta_matrix = storage_matrix;

  storage_matrix = Delta_matrix*H_matrix;

  Delta_H_Delta_matrix = storage_matrix*Delta_matrix;

  original_to_HO_matrix_one_baryon_calc (channels_tab , prot_Y_data , neut_Y_data , inter_data_basis , Delta_H_Delta_matrix , Delta_H_Delta_HO_matrix);

  finite_range_orthogonalized_potential_HO_matrix = finite_range_potential_HO_matrix;

  finite_range_orthogonalized_potential_HO_matrix += H_Delta_plus_Delta_H_HO_matrix;

  finite_range_orthogonalized_potential_HO_matrix += Delta_H_Delta_HO_matrix;

  OpenMP_parallelization_linear_algebra_disabled ();

  MPI_parallelization_linear_algebra_disabled ();
}







void CC_Hamiltonian_data::Delta_H_HO_matrices_cluster_calc (
							    const class array<class CC_channel_class> &channels_tab , 
							    const class array<class cluster_data> &cluster_projectile_data_tab)
{  
  if (dimension_matrices > 1000)
    {
      OpenMP_parallelization_linear_algebra_enabled ();

      MPI_parallelization_linear_algebra_enabled ();
    }
  
  class matrix<complex<double> > Delta_matrix = overlaps_matrix;

  Moore_Penrose_sqrt_inv (Delta_matrix , relative_SVD_precision);

  Delta_matrix.remove_scalar_diagonal_part (1.0);
  
  original_to_HO_matrix_cluster_calc (channels_tab , cluster_projectile_data_tab , Delta_matrix , Delta_HO_matrix);
  
  class matrix<complex<double> > storage_matrix(dimension_matrices);
  
  class matrix<complex<double> > &H_Delta_plus_Delta_H_matrix = storage_matrix;

  H_Delta_plus_Delta_H_matrix = H_matrix*Delta_matrix;

  H_Delta_plus_Delta_H_matrix += Delta_matrix*H_matrix;

  original_to_HO_matrix_cluster_calc (channels_tab , cluster_projectile_data_tab , H_Delta_plus_Delta_H_matrix , H_Delta_plus_Delta_H_HO_matrix);

  class matrix<complex<double> > &Delta_H_Delta_matrix = storage_matrix;

  storage_matrix = Delta_matrix*H_matrix;

  Delta_H_Delta_matrix = storage_matrix*Delta_matrix;

  original_to_HO_matrix_cluster_calc (channels_tab , cluster_projectile_data_tab , Delta_H_Delta_matrix , Delta_H_Delta_HO_matrix);

  finite_range_orthogonalized_potential_HO_matrix = finite_range_potential_HO_matrix;
  
  finite_range_orthogonalized_potential_HO_matrix += H_Delta_plus_Delta_H_HO_matrix;

  finite_range_orthogonalized_potential_HO_matrix += Delta_H_Delta_HO_matrix;

  OpenMP_parallelization_linear_algebra_disabled ();

  MPI_parallelization_linear_algebra_disabled ();
}








void CC_Hamiltonian_data::PCM_function_HO_matrices_cluster_calc (
								 const class array<class CC_channel_class> &channels_tab , 
								 const class array<class cluster_data> &cluster_projectile_data_tab)
{  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);

      const class array<int> &Nmax_HO_tab_c = data_c.get_Nmax_HO_tab ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const double J_projectile_c = channel_c.get_J_projectile ();

      const int NCM_HO_max_LCM_projectile_c = Nmax_HO_tab_c(LCM_projectile_c);

      const int NCM_HO_max_LCM_projectile_c_plus_one = NCM_HO_max_LCM_projectile_c + 1;

      const class lj_table<class matrix<double> > &PCM_matrices_cluster = data_c.get_PCM_matrices_cluster ();

      const class matrix<double> &PCM_matrix_LCM_J_c = PCM_matrices_cluster(LCM_projectile_c , J_projectile_c);

      const class matrix<complex<double> > PCM_matrix_LCM_J_c_complex = complex_matrix<double , complex<double> > (PCM_matrix_LCM_J_c);

      class matrix<double> HCM_HO_submatrix_c(NCM_HO_max_LCM_projectile_c_plus_one);

      for (int NCM_HO_c = 0 ; NCM_HO_c <= NCM_HO_max_LCM_projectile_c ; NCM_HO_c++) 
	for (int NCM_HO_cp = 0 ; NCM_HO_cp <= NCM_HO_max_LCM_projectile_c ; NCM_HO_cp++)
	  {
	    HCM_HO_submatrix_c(NCM_HO_c , NCM_HO_cp) = CC_H_MEs_cluster::HCM_two_HO_calc (channels_tab , ic , NCM_HO_c , NCM_HO_cp , cluster_projectile_data_tab);
	  }

      const class matrix<complex<double> > HCM_HO_submatrix_c_complex = complex_matrix<double , complex<double> > (HCM_HO_submatrix_c);

      class matrix<complex<double> > &QCM_HO_submatrix_c = QCM_HO_submatrices(ic);

      class matrix<complex<double> > &QCM_HCM_QCM_HO_submatrix_c = QCM_HCM_QCM_HO_submatrices(ic);

      class matrix<double> &PCM_HCM_PCM_HO_submatrix_c = PCM_HCM_PCM_HO_submatrices(ic);

      QCM_HO_submatrix_c.identity ();

      QCM_HO_submatrix_c -= PCM_matrix_LCM_J_c_complex;

      QCM_HCM_QCM_HO_submatrix_c = QCM_HO_submatrix_c*HCM_HO_submatrix_c_complex*QCM_HO_submatrix_c;

      PCM_HCM_PCM_HO_submatrix_c = PCM_matrix_LCM_J_c*HCM_HO_submatrix_c*PCM_matrix_LCM_J_c;
    }
}








void CC_Hamiltonian_data::original_to_HO_matrix_one_baryon_calc (
								 const class array<class CC_channel_class> &channels_tab , 
								 const class baryons_data &prot_Y_data , 
								 const class baryons_data &neut_Y_data , 
								 const class interaction_class &inter_data_basis , 
								 const class matrix<complex<double> > &original_matrix , 
								 class matrix<double> &HO_matrix)
{
  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const int lc = channel_c.get_LCM_projectile ();

      const int nmax_HO_c = nmax_HO_lab_tab(lc);

      for (int nHOc = 0 ; nHOc <= nmax_HO_c ; nHOc++)
	{
	  const unsigned int in_HO = matrices_indices_HO(ic , nHOc);

	  for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	    {
	      const class CC_channel_class &channel_cp = channels_tab(icp);
	      
	      const int lcp = channel_cp.get_LCM_projectile ();

	      const int nmax_HO_cp = nmax_HO_lab_tab(lcp);

	      for (int nHOcp = 0 ; nHOcp <= nmax_HO_cp ; nHOcp++)
		{
		  const unsigned int out_HO = matrices_indices_HO(icp , nHOcp);

		  HO_matrix(in_HO , out_HO) = CC_H_MEs_one_baryon::Berggren_to_HO_two_channels_two_HO_calc (CC_average_n_scat_target_projectile_max , channels_tab , is_it_forbidden_channel_tab , 
													    ic , icp , nHOc , nHOcp , prot_Y_data , neut_Y_data , matrices_indices , original_matrix);
		}
	    }
	}
    }

  HO_matrix.symmetrize ();
}





void CC_Hamiltonian_data::original_to_HO_matrix_cluster_calc (
							      const class array<class CC_channel_class> &channels_tab , 
							      const class array<class cluster_data> &cluster_projectile_data_tab , 
							      const class matrix<complex<double> > &original_matrix , 
							      class matrix<double> &HO_matrix)
{
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);	

      const class array<int> &Nmax_HO_tab_c = data_c.get_Nmax_HO_tab ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const int NCM_HO_max_LCM_projectile_c = Nmax_HO_tab_c(LCM_projectile_c);

      for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	{
	  const class CC_channel_class &channel_cp = channels_tab(icp);

	  const enum particle_type projectile_cp = channel_cp.get_projectile ();	

	  const class cluster_data &data_cp = get_cluster_projectile_data (projectile_cp , cluster_projectile_data_tab);	

	  const class array<int> &Nmax_HO_tab_cp = data_cp.get_Nmax_HO_tab ();

	  const int LCM_projectile_cp = channel_cp.get_LCM_projectile ();

	  const int NCM_HO_max_LCM_projectile_cp = Nmax_HO_tab_cp(LCM_projectile_cp);

	  for (int NCM_HO_c = 0 ; NCM_HO_c <= NCM_HO_max_LCM_projectile_c ; NCM_HO_c++)
	    {
	      const unsigned int in_HO = matrices_indices_HO(ic , NCM_HO_c);

	      for (int NCM_HO_cp = 0 ; NCM_HO_cp <= NCM_HO_max_LCM_projectile_cp ; NCM_HO_cp++)
		{
		  const unsigned int out_HO = matrices_indices_HO(icp , NCM_HO_cp);

		  HO_matrix(in_HO , out_HO) = CC_H_MEs_cluster::Berggren_to_HO_two_channels_two_HO_calc (CC_average_n_scat_target_projectile_max , channels_tab , is_it_forbidden_channel_tab , 
													 ic , icp , NCM_HO_c , NCM_HO_cp , cluster_projectile_data_tab , matrices_indices , original_matrix);
		}
	    }
	}
    }

  HO_matrix.symmetrize ();
}




void CC_Hamiltonian_data::orthogonalized_H_tridiagonalization_CC_Berggren ()
{  
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      if (dimension_matrices_CC_Berggren == 0) error_message_print_abort ("CC Berggren Hamiltonian matrix dimension is equal to zero");
      
      cout << "Matrix dimension : " << dimension_matrices_CC_Berggren << " ---- CC Berggren H tridiagonalization to solve Green function tridiagonal linear systems afterwards" << endl << endl;
    }

  orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren = orthogonalized_H_matrix_CC_Berggren;

  if (dimension_matrices_CC_Berggren > 1000)
    {
      OpenMP_parallelization_linear_algebra_enabled ();

      MPI_parallelization_linear_algebra_enabled ();
    }

  total_diagonalization::symmetric::tridiagonal_Lanczos (orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren , orthogonalized_H_tridiagonalized_diagonal_CC_Berggren , orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren);

  OpenMP_parallelization_linear_algebra_disabled ();

  MPI_parallelization_linear_algebra_disabled ();

  orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren = orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren;

  orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren.transpose ();
}




double used_memory_calc (const class CC_Hamiltonian_data &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.multipolar_expansion) +
    used_memory_calc (T.CGs) +
    used_memory_calc (T.HO_wfs_bef_R_tab_uniform) +
    used_memory_calc (T.HO_wfs_bef_R_tab_GL) +
    used_memory_calc (T.HO_wfs_aft_R_tab_GL) +
    used_memory_calc (T.Gaussian_table_GL) +
    used_memory_calc (T.CC_corrective_factors_TBMEs_tab) +
    used_memory_calc (T.CC_corrective_factors_cluster_tab) +
    used_memory_calc (T.QCM_HO_submatrices) +
    used_memory_calc (T.QCM_HCM_QCM_HO_submatrices) +
    used_memory_calc (T.PCM_HCM_PCM_HO_submatrices) +
    used_memory_calc (T.finite_range_orthogonalized_potential_HO_submatrices) +
    used_memory_calc (T.finite_range_overlaps_HO_submatrices) +
    used_memory_calc (T.Delta_HO_submatrices) +
    used_memory_calc (T.is_it_forbidden_channel_tab) +
    used_memory_calc (T.is_it_forbidden_channel_CC_Berggren_tab) +
    used_memory_calc (T.matrices_indices) +
    used_memory_calc (T.matrices_indices_HO) +
    used_memory_calc (T.matrices_indices_CC_Berggren) +
    used_memory_calc (T.finite_range_overlaps_HO_matrix) +
    used_memory_calc (T.finite_range_potential_HO_matrix) +
    used_memory_calc (T.Ho_HO_matrix) +
    used_memory_calc (T.finite_range_orthogonalized_potential_HO_matrix) +
    used_memory_calc (T.overlaps_HO_matrix) +
    used_memory_calc (T.sqrt_overlaps_HO_matrix) +
    used_memory_calc (T.sqrt_inv_overlaps_HO_matrix) +
    used_memory_calc (T.H_HO_matrix) +
    used_memory_calc (T.H_Delta_plus_Delta_H_HO_matrix) +
    used_memory_calc (T.Delta_H_Delta_HO_matrix) +
    used_memory_calc (T.Delta_HO_matrix) +
    used_memory_calc (T.overlaps_matrix_pole_approximation) +
    used_memory_calc (T.H_matrix_pole_approximation) +
    used_memory_calc (T.overlaps_matrix) +
    used_memory_calc (T.H_matrix) +
    used_memory_calc (T.orthogonalized_H_matrix_CC_Berggren) +
    used_memory_calc (T.orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren) +
    used_memory_calc (T.orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren) +
    used_memory_calc (T.orthogonalized_H_tridiagonalized_diagonal_CC_Berggren) +
    used_memory_calc (T.orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren) +
    used_memory_calc (T.Ueq_tab) +
    used_memory_calc (T.source_tab)
    - (sizeof (T.multipolar_expansion) +
       sizeof (T.CGs) +
       sizeof (T.HO_wfs_bef_R_tab_uniform) +
       sizeof (T.HO_wfs_bef_R_tab_GL) +
       sizeof (T.HO_wfs_aft_R_tab_GL) +
       sizeof (T.Gaussian_table_GL) +
       sizeof (T.CC_corrective_factors_cluster_tab) +
       sizeof (T.QCM_HO_submatrices) +
       sizeof (T.QCM_HCM_QCM_HO_submatrices) +
       sizeof (T.PCM_HCM_PCM_HO_submatrices) +
       sizeof (T.finite_range_orthogonalized_potential_HO_submatrices) +
       sizeof (T.finite_range_overlaps_HO_submatrices) +
       sizeof (T.Delta_HO_submatrices) +
       sizeof (T.is_it_forbidden_channel_tab) +
       sizeof (T.is_it_forbidden_channel_CC_Berggren_tab) +
       sizeof (T.matrices_indices) +
       sizeof (T.matrices_indices_HO) +
       sizeof (T.matrices_indices_CC_Berggren) +
       sizeof (T.finite_range_overlaps_HO_matrix) +
       sizeof (T.finite_range_potential_HO_matrix) +
       sizeof (T.Ho_HO_matrix) +
       sizeof (T.finite_range_orthogonalized_potential_HO_matrix) +
       sizeof (T.overlaps_HO_matrix) +
       sizeof (T.sqrt_overlaps_HO_matrix) +
       sizeof (T.sqrt_inv_overlaps_HO_matrix) +
       sizeof (T.H_HO_matrix) +
       sizeof (T.H_Delta_plus_Delta_H_HO_matrix) +
       sizeof (T.Delta_H_Delta_HO_matrix) +
       sizeof (T.Delta_HO_matrix) +
       sizeof (T.overlaps_matrix_pole_approximation) +
       sizeof (T.H_matrix_pole_approximation) +
       sizeof (T.overlaps_matrix) +
       sizeof (T.H_matrix) +
       sizeof (T.orthogonalized_H_matrix_CC_Berggren) +
       sizeof (T.orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren) +
       sizeof (T.orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren) +
       sizeof (T.orthogonalized_H_tridiagonalized_diagonal_CC_Berggren) +
       sizeof (T.orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren) +
       sizeof (T.Ueq_tab) +
       sizeof (T.source_tab))/1000000.0;

  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;
}
