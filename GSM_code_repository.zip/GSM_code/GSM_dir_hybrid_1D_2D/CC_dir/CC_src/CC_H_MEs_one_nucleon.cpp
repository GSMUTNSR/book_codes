#include "../CC_include/CC_include_def.h"

// Ho_two_HO_calc
// ---------------------------
// Calculates the intrinsic hamiltonian in harmonic oscillator basis for given (ic , nHOc;icp , nHOcp).
// = \delta_{ccp} \sum _nc <nHOc , c|nc , c>.(e_nc + E_Jc).<nc , c|nHOcp , c>





double CC_H_MEs_one_nucleon::HO_channel_decomposition_Ho_two_HO_calc (
								      const double CC_average_n_scat_target_projectile_max , 
								      const class array<class CC_channel_class> &channels_tab , 
								      const class array<bool> &is_it_forbidden_channel_tab , 
								      const class CG_str &CGs , 
								      const class interaction_class &inter_data_basis , 
								      const class array<double> &Gaussian_table_GL , 
								      const class multipolar_expansion_str &multipolar_expansion , 
								      const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
								      const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
								      const class nucleons_data &prot_data_one_configuration_GSM , 
								      const class nucleons_data &neut_data_one_configuration_GSM , 
								      const unsigned int ic , 
								      const int nHOc , 
								      const int nHOcp , 
								      const class nucleons_data &prot_data , 
								      const class nucleons_data &neut_data , 
								      const class nucleons_data &prot_data_CC_Berggren , 
								      const class nucleons_data &neut_data_CC_Berggren) 
{
  const class CC_channel_class &channel_c = channels_tab(ic);

  const enum particle_type particle_c = channel_c.get_projectile ();

  const int lc = channel_c.get_LCM_projectile ();

  const double jc = channel_c.get_J_projectile ();

  const complex<double> E_Tc = channel_c.get_E_Tc ();

  const class nucleons_data &data_tau_CC_Berggren_c = (particle_c == PROTON) ? (prot_data_CC_Berggren) : (neut_data_CC_Berggren);

  const class nucleons_data &data_tau_c = (particle_c == PROTON) ? (prot_data) : (neut_data);

  const class lj_table<int> &nmax_lj_c = data_tau_c.get_nmax_lj_tab ();

  const int nmax_c = nmax_lj_c(lc , jc);

  const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

  const double real_average_n_scat_Tc = real (average_n_scat_Tc);

  const class nlj_table<bool> &is_it_valence_shell_tab_c = data_tau_c.get_is_it_valence_shell_tab ();

  const class nlj_table<unsigned int> &shells_indices_tau_c = data_tau_c.get_shells_indices ();

  const class array<class nlj_struct> &shells_qn_tau_c = data_tau_c.get_shells_quantum_numbers ();

  const class array<class vector_class<complex<double> > > &HO_overlaps_c = data_tau_c.get_HO_overlaps ();

  const double OBME_projectile_c_cp = CC_H_CM_OBMEs::one_nucleon_CM::OBME_h_basis_calc (lc , jc , nHOc , nHOcp , CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , 
											prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren ,
											prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , neut_data_CC_Berggren , data_tau_CC_Berggren_c);
  
  double ME_nHOc_Ho_nHOcp = 0.0;

  for (int nc = 0 ; nc <= nmax_c ; nc++) 
    {
      if (is_it_valence_shell_tab_c(nc , lc , jc))
	{	
	  const unsigned int shell_index_nc = shells_indices_tau_c(nc , lc , jc);

	  const class nlj_struct &shell_qn_nc = shells_qn_tau_c(shell_index_nc);

	  const bool S_matrix_pole_nc = shell_qn_nc.get_S_matrix_pole ();

	  const double real_average_n_scat_nc = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_tab(ic , nc) && (real_average_n_scat_nc <= CC_average_n_scat_target_projectile_max))
	    {
	      const class vector_class<complex<double> > &HO_overlaps_nc = HO_overlaps_c(shell_index_nc);

	      const complex<double> HO_overlap_nc_nHOc = HO_overlaps_nc(nHOc);

	      for (int ncp = 0 ; ncp <= nmax_c ; ncp++) 
		{
		  if (is_it_valence_shell_tab_c(ncp , lc , jc))
		    {
		      const unsigned int shell_index_ncp = shells_indices_tau_c(ncp , lc , jc);

		      const class nlj_struct &shell_qn_ncp = shells_qn_tau_c(shell_index_ncp);

		      const bool S_matrix_pole_ncp = shell_qn_ncp.get_S_matrix_pole ();

		      const double real_average_n_scat_ncp = (!S_matrix_pole_ncp) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

		      if (!is_it_forbidden_channel_tab(ic , ncp) && (real_average_n_scat_ncp <= CC_average_n_scat_target_projectile_max))
			{
			  const class vector_class<complex<double> > &HO_overlaps_ncp = HO_overlaps_c(shell_index_ncp);

			  const complex<double> HO_overlap_ncp_nHOcp = HO_overlaps_ncp(nHOcp);

			  const complex<double> OBME = (nc == ncp) ? (OBME_projectile_c_cp + E_Tc) : (OBME_projectile_c_cp);
			  
			  ME_nHOc_Ho_nHOcp += real (HO_overlap_nc_nHOc * OBME * HO_overlap_ncp_nHOcp);
			}
		    }
		}
	    }
	}
    }
			  
  return ME_nHOc_Ho_nHOcp;
}







double CC_H_MEs_one_nucleon::Berggren_channel_decomposition_Ho_two_HO_calc (
									    const double CC_average_n_scat_target_projectile_max , 
									    const class array<class CC_channel_class> &channels_tab , 
									    const class array<bool> &is_it_forbidden_channel_CC_Berggren_tab , 
									    const unsigned int ic , 
									    const int nHOc , 
									    const int nHOcp , 
									    const class nucleons_data &prot_data_CC_Berggren , 
									    const class nucleons_data &neut_data_CC_Berggren) 
{
  const class CC_channel_class &channel_c = channels_tab(ic);

  const enum particle_type particle_c = channel_c.get_projectile ();

  const int lc = channel_c.get_LCM_projectile ();

  const double jc = channel_c.get_J_projectile ();

  const complex<double> E_Tc = channel_c.get_E_Tc ();

  const class nucleons_data &data_tau_CC_Berggren_c = (particle_c == PROTON) ? (prot_data_CC_Berggren) : (neut_data_CC_Berggren);

  const class lj_table<int> &nmax_lj_CC_Berggren_c = data_tau_CC_Berggren_c.get_nmax_lj_tab ();

  const class nlj_table<bool> &is_it_valence_shell_tab_CC_Berggren_c = data_tau_CC_Berggren_c.get_is_it_valence_shell_tab ();

  const class array<class vector_class<complex<double> > > &HO_overlaps_CC_Berggren_c = data_tau_CC_Berggren_c.get_HO_overlaps ();

  const class nlj_table<TYPE> &hc_CC_Berggren_basis = data_tau_CC_Berggren_c.get_h_basis ();

  const class nlj_table<unsigned int> &shells_indices_CC_Berggren_c = data_tau_CC_Berggren_c.get_shells_indices ();

  const class array<class nlj_struct> &shells_qn_CC_Berggren_c = data_tau_CC_Berggren_c.get_shells_quantum_numbers ();

  const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

  const double real_average_n_scat_Tc = real (average_n_scat_Tc);

  const int nmax_c_CC_Berggren = nmax_lj_CC_Berggren_c(lc , jc);

  double ME_nHOc_Ho_nHOcp = 0.0;

  for (int nc = 0 ; nc <= nmax_c_CC_Berggren ; nc++) 
    {
      if (is_it_valence_shell_tab_CC_Berggren_c(nc , lc , jc))
	{
	  const unsigned int shell_index_c = shells_indices_CC_Berggren_c(nc , lc , jc);

	  const class nlj_struct &shell_qn_c = shells_qn_CC_Berggren_c(shell_index_c);

	  const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	  const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_CC_Berggren_tab(ic , nc) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max))
	    {
	      const class vector_class<complex<double> > &HO_overlaps_nc = HO_overlaps_CC_Berggren_c(shell_index_c);

	      const complex<double> HO_overlap_nc_nHOc  = HO_overlaps_nc(nHOc);
	      const complex<double> HO_overlap_nc_nHOcp = HO_overlaps_nc(nHOcp);

	      const complex<double> e = hc_CC_Berggren_basis(nc , lc , jc);

	      ME_nHOc_Ho_nHOcp += real (HO_overlap_nc_nHOc * (E_Tc + e) * HO_overlap_nc_nHOcp);
	    }
	}
    }

  return ME_nHOc_Ho_nHOcp;
}







double CC_H_MEs_one_nucleon::Ho_two_HO_calc (
					     const double CC_average_n_scat_target_projectile_max , 
					     const class array<class CC_channel_class> &channels_tab , 
					     const class array<bool> &is_it_forbidden_channel_tab , 
					     const class array<bool> &is_it_forbidden_channel_CC_Berggren_tab , 
					     const class CG_str &CGs , 
					     const class interaction_class &inter_data_basis , 
					     const class array<double> &Gaussian_table_GL , 
					     const class multipolar_expansion_str &multipolar_expansion , 
					     const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
					     const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
					     const class nucleons_data &prot_data_one_configuration_GSM , 
					     const class nucleons_data &neut_data_one_configuration_GSM , 
					     const unsigned int ic , 
					     const int nHOc , 
					     const int nHOcp , 
					     const class nucleons_data &prot_data , 
					     const class nucleons_data &neut_data , 
					     const class nucleons_data &prot_data_CC_Berggren , 
					     const class nucleons_data &neut_data_CC_Berggren) 
{
  const class CC_channel_class &channel_c = channels_tab(ic);

  const bool is_it_HO_channel_decomposition_c = channel_c.get_is_it_HO_channel_decomposition ();
  
  if (is_it_HO_channel_decomposition_c)
    return HO_channel_decomposition_Ho_two_HO_calc (CC_average_n_scat_target_projectile_max , channels_tab , is_it_forbidden_channel_tab , 
						    CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
						    prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , ic , nHOc , nHOcp , prot_data , neut_data , prot_data_CC_Berggren , neut_data_CC_Berggren);
  else
    return Berggren_channel_decomposition_Ho_two_HO_calc (CC_average_n_scat_target_projectile_max , channels_tab , is_it_forbidden_channel_CC_Berggren_tab , 
							  ic , nHOc , nHOcp , prot_data_CC_Berggren , neut_data_CC_Berggren);
}






double CC_H_MEs_one_nucleon::Berggren_to_HO_two_channels_two_HO_calc (
								      const double CC_average_n_scat_target_projectile_max , 
								      const class array<class CC_channel_class> &channels_tab , 
								      const class array<bool> &is_it_forbidden_channel_tab , 
								      const unsigned int ic , 
								      const unsigned int icp , 
								      const int nHOc , 
								      const int nHOcp , 
								      const class nucleons_data &prot_data , 
								      const class nucleons_data &neut_data , 
								      const class array<unsigned int> &matrices_indices , 
								      const class matrix<complex<double> > &Berggren_matrix)
{
  const class CC_channel_class &channel_c  = channels_tab(ic);
  const class CC_channel_class &channel_cp = channels_tab(icp);

  const enum particle_type particle_c  = channel_c.get_projectile ();
  const enum particle_type particle_cp = channel_cp.get_projectile ();

  const class nucleons_data &data_tau_c  = (particle_c  == PROTON) ? (prot_data) : (neut_data);
  const class nucleons_data &data_tau_cp = (particle_cp == PROTON) ? (prot_data) : (neut_data);

  const class lj_table<int> &nmax_lj_c  = data_tau_c.get_nmax_lj_tab ();
  const class lj_table<int> &nmax_lj_cp = data_tau_cp.get_nmax_lj_tab ();

  const double jc  = channel_c.get_J_projectile ();
  const double jcp = channel_cp.get_J_projectile ();

  const int lc  = channel_c.get_LCM_projectile ();
  const int lcp = channel_cp.get_LCM_projectile ();

  const int nmax_c  = nmax_lj_c (lc  , jc);
  const int nmax_cp = nmax_lj_cp(lcp , jcp);

  const complex<double> average_n_scat_Tc  = channel_c.get_average_n_scat_Tc ();
  const complex<double> average_n_scat_Tcp = channel_cp.get_average_n_scat_Tc ();

  const double real_average_n_scat_Tc  = real (average_n_scat_Tc);
  const double real_average_n_scat_Tcp = real (average_n_scat_Tcp);

  const class nlj_table<bool> &is_it_valence_shell_tab_c  = data_tau_c.get_is_it_valence_shell_tab ();
  const class nlj_table<bool> &is_it_valence_shell_tab_cp = data_tau_cp.get_is_it_valence_shell_tab ();

  const class nlj_table<unsigned int> &shells_indices_tau_c  = data_tau_c.get_shells_indices ();
  const class nlj_table<unsigned int> &shells_indices_tau_cp = data_tau_cp.get_shells_indices ();

  const class array<class nlj_struct> &shells_qn_tau_c  = data_tau_c.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_tau_cp = data_tau_cp.get_shells_quantum_numbers ();

  const class array<class vector_class<complex<double> > > &HO_overlaps_c  = data_tau_c.get_HO_overlaps ();
  const class array<class vector_class<complex<double> > > &HO_overlaps_cp = data_tau_cp.get_HO_overlaps ();

  complex<double> ME_nHOc_nHOcp_complex = 0.0;

  for (int nc = 0 ; nc <= nmax_c ; nc++) 
    {
      if (is_it_valence_shell_tab_c(nc , lc , jc))
	{
	  const unsigned int shell_index_c = shells_indices_tau_c(nc , lc , jc);

	  const class nlj_struct &shell_qn_c = shells_qn_tau_c(shell_index_c);

	  const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	  const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_tab(ic , nc) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max))
	    {
	      const unsigned int index_in = matrices_indices(ic , nc);

	      const unsigned int sc = shells_indices_tau_c(nc , lc , jc);

	      const class vector_class<complex<double> > &HO_overlaps_nc = HO_overlaps_c(sc);

	      const complex<double> HO_overlap_nc_nHOc = HO_overlaps_nc(nHOc);

	      for (int ncp = 0 ; ncp <= nmax_cp ; ncp++) 
		{
		  if (is_it_valence_shell_tab_cp(ncp , lcp , jcp))
		    {
		      const unsigned int shell_index_cp = shells_indices_tau_cp(ncp , lcp , jcp);

		      const class nlj_struct &shell_qn_cp = shells_qn_tau_cp(shell_index_cp);

		      const bool S_matrix_pole_ncp = shell_qn_cp.get_S_matrix_pole ();

		      const double real_average_n_scat_cp = (!S_matrix_pole_ncp) ? (real_average_n_scat_Tcp + 1) : (real_average_n_scat_Tcp);

		      if (!is_it_forbidden_channel_tab(icp , ncp) && (real_average_n_scat_cp <= CC_average_n_scat_target_projectile_max))
			{
			  const unsigned int index_out = matrices_indices(icp , ncp);

			  const unsigned int scp = shells_indices_tau_cp(ncp , lcp , jcp);

			  const class vector_class<complex<double> > &HO_overlaps_ncp = HO_overlaps_cp(scp);

			  const complex<double> HO_overlap_ncp_nHOcp = HO_overlaps_ncp(nHOcp);

			  ME_nHOc_nHOcp_complex += HO_overlap_nc_nHOc * Berggren_matrix(index_in , index_out) * HO_overlap_ncp_nHOcp;
			}
		    }
		}
	    }
	}
    }

  const double ME_nHOc_nHOcp = real (ME_nHOc_nHOcp_complex);

  return ME_nHOc_nHOcp;
}





// CC_H_MEs_one_nucleon::potential_two_channels_two_HO_calc
// -------------------------------------------
// Calculates the finite-range potential V_ccp in harmonic oscillator basis for given (ic , nHOc;icp , nHOcp) , V being the finite-range potential , 
// = -\delta_{ccp} \sum _nc <nHOc , c|nc , c>.(e_nc + E_Jc).<nc , c|nHOcp , c>
// + \sum_{nc , ncp} <nHOc , c|nc , c> <a+_{nc , c} \Psi_c | H | a+_{ncp , cp} \Psi_cp> <ncp , cp|nHOcp , cp>
//
// The <a+_{nc , lc , jc} \Psi_c | H | a+_{ncp , lcp , jcp} \Psi_cp> are in H_matrix given as a variable.

double CC_H_MEs_one_nucleon::potential_two_channels_two_HO_calc (
								 const double CC_average_n_scat_target_projectile_max , 
								 const class array<class CC_channel_class> &channels_tab ,   
								 const class array<bool> &is_it_forbidden_channel_tab , 
								 const class array<bool> &is_it_forbidden_channel_CC_Berggren_tab , 
								 const class CG_str &CGs , 
								 const class interaction_class &inter_data_basis , 
								 const class array<double> &Gaussian_table_GL , 
								 const class multipolar_expansion_str &multipolar_expansion , 
								 const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
								 const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
								 const class nucleons_data &prot_data_one_configuration_GSM , 
								 const class nucleons_data &neut_data_one_configuration_GSM , 
								 const unsigned int ic , 
								 const unsigned int icp , 
								 const int nHOc , 
								 const int nHOcp , 
								 const class nucleons_data &prot_data , 
								 const class nucleons_data &neut_data , 
								 const class nucleons_data &prot_data_CC_Berggren , 
								 const class nucleons_data &neut_data_CC_Berggren , 
								 const class array<unsigned int> &matrices_indices , 
								 const class matrix<complex<double> > &H_matrix)
{
  const class CC_channel_class &channel_c = channels_tab(ic);
  const class CC_channel_class &channel_cp = channels_tab(icp);

  const enum particle_type particle_c  = channel_c.get_projectile ();
  const enum particle_type particle_cp = channel_cp.get_projectile ();

  const class nucleons_data &data_tau_c  = (particle_c  == PROTON) ? (prot_data) : (neut_data);
  const class nucleons_data &data_tau_cp = (particle_cp == PROTON) ? (prot_data) : (neut_data);

  const class lj_table<int> &nmax_lj_c  = data_tau_c.get_nmax_lj_tab ();
  const class lj_table<int> &nmax_lj_cp = data_tau_cp.get_nmax_lj_tab ();

  const double jc  = channel_c.get_J_projectile ();
  const double jcp = channel_cp.get_J_projectile ();

  const int lc  = channel_c.get_LCM_projectile ();
  const int lcp = channel_cp.get_LCM_projectile ();

  const int nmax_c  = nmax_lj_c (lc  , jc);
  const int nmax_cp = nmax_lj_cp(lcp , jcp);

  const complex<double> average_n_scat_Tc  = channel_c.get_average_n_scat_Tc ();
  const complex<double> average_n_scat_Tcp = channel_cp.get_average_n_scat_Tc ();

  const double real_average_n_scat_Tc  = real (average_n_scat_Tc);
  const double real_average_n_scat_Tcp = real (average_n_scat_Tcp);

  const class nlj_table<bool> &is_it_valence_shell_tab_c  = data_tau_c.get_is_it_valence_shell_tab ();
  const class nlj_table<bool> &is_it_valence_shell_tab_cp = data_tau_cp.get_is_it_valence_shell_tab ();

  const class nlj_table<unsigned int> &shells_indices_tau_c  = data_tau_c.get_shells_indices ();
  const class nlj_table<unsigned int> &shells_indices_tau_cp = data_tau_cp.get_shells_indices ();

  const class array<class nlj_struct> &shells_qn_tau_c  = data_tau_c.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_tau_cp = data_tau_cp.get_shells_quantum_numbers ();

  const class array<class vector_class<complex<double> > > &HO_overlaps_c  = data_tau_c.get_HO_overlaps ();
  const class array<class vector_class<complex<double> > > &HO_overlaps_cp = data_tau_cp.get_HO_overlaps ();

  double ME_nHOc_potential_nHOcp = 0.0;

  for (int nc = 0 ; nc <= nmax_c ; nc++) 
    {
      if (is_it_valence_shell_tab_c(nc , lc , jc))
	{	
	  const unsigned int shell_index_c = shells_indices_tau_c(nc , lc , jc);
	  
	  const class nlj_struct &shell_qn_c = shells_qn_tau_c(shell_index_c);

	  const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	  const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_tab(ic , nc) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max))
	    {
	      const unsigned int index_in = matrices_indices(ic , nc);

	      const unsigned int sc = shells_indices_tau_c(nc , lc , jc);

	      const class vector_class<complex<double> > &HO_overlaps_nc = HO_overlaps_c(sc);

	      const complex<double> HO_overlap_nc_nHOc = HO_overlaps_nc(nHOc);

	      for (int ncp = 0 ; ncp <= nmax_cp ; ncp++) 
		{
		  if (is_it_valence_shell_tab_cp(ncp , lcp , jcp))
		    {
		      const unsigned int shell_index_cp = shells_indices_tau_cp(ncp , lcp , jcp);
		      
		      const class nlj_struct &shell_qn_cp = shells_qn_tau_cp(shell_index_cp);

		      const bool S_matrix_pole_ncp = shell_qn_cp.get_S_matrix_pole ();

		      const double real_average_n_scat_cp = (!S_matrix_pole_ncp) ? (real_average_n_scat_Tcp + 1) : (real_average_n_scat_Tcp);

		      if (!is_it_forbidden_channel_tab(icp , ncp) && (real_average_n_scat_cp <= CC_average_n_scat_target_projectile_max))
			{
			  const unsigned int index_out = matrices_indices(icp , ncp);

			  const unsigned int scp = shells_indices_tau_cp(ncp , lcp , jcp);

			  const class vector_class<complex<double> > &HO_overlaps_ncp = HO_overlaps_cp(scp);

			  const complex<double> HO_overlap_ncp_nHOcp = HO_overlaps_ncp(nHOcp);

			  ME_nHOc_potential_nHOcp += real (HO_overlap_nc_nHOc * H_matrix(index_in , index_out) * HO_overlap_ncp_nHOcp);
			}
		    }
		}
	    }
	}
    }

  if (ic == icp)
    {
      ME_nHOc_potential_nHOcp -= Ho_two_HO_calc (CC_average_n_scat_target_projectile_max , channels_tab , is_it_forbidden_channel_tab , is_it_forbidden_channel_CC_Berggren_tab , 
						 CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren ,
						 prot_data_one_configuration_GSM , neut_data_one_configuration_GSM , ic , nHOc , nHOcp , prot_data , neut_data , prot_data_CC_Berggren , neut_data_CC_Berggren);
    }

  return ME_nHOc_potential_nHOcp;
}







// CC_H_MEs_one_nucleon::overlap_related_matrix_two_channels_two_HO_calc
// --------------------------------------------
// Calculates the finite-range overlap O_finite_range_ccp in harmonic oscillator basis for given (ic , nHOc;icp , nHOcp)
// = -\delta_{ccp} \sum _nc <nHOc , c|nc , c>.<nc , c|nHOcp , c> 
// + \sum_{nc , ncp} <nHOc , c|nc , c> <a+_{nc , c} \Psi_c | a+_{ncp , cp} \Psi_cp> <ncp , cp|nHOcp , cp>
//
// The <a+_{nc , lc , jc} \Psi_c | a+_{ncp , lcp , jcp} \Psi_cp> are in Ov_matrix given as a variable

double CC_H_MEs_one_nucleon::finite_range_overlap_matrix_two_channels_two_HO_calc (
										   const double CC_average_n_scat_target_projectile_max , 
										   const class array<class CC_channel_class> &channels_tab , 
										   const class array<bool> &is_it_forbidden_channel_tab , 
										   const unsigned int ic , 
										   const unsigned int icp , 
										   const int nHOc , 
										   const int nHOcp , 
										   const class nucleons_data &prot_data , 
										   const class nucleons_data &neut_data , 
										   const class array<unsigned int> &matrices_indices , 
										   const class matrix<complex<double> > &overlaps_matrix) 
{
  const class CC_channel_class &channel_c  = channels_tab(ic);
  const class CC_channel_class &channel_cp = channels_tab(icp);

  const enum particle_type particle_c  = channel_c.get_projectile ();
  const enum particle_type particle_cp = channel_cp.get_projectile ();

  const class nucleons_data &data_tau_c  = (particle_c  == PROTON) ? (prot_data) : (neut_data);
  const class nucleons_data &data_tau_cp = (particle_cp == PROTON) ? (prot_data) : (neut_data); 

  const class lj_table<int> &nmax_lj_c  = data_tau_c.get_nmax_lj_tab ();
  const class lj_table<int> &nmax_lj_cp = data_tau_cp.get_nmax_lj_tab ();

  const double jc  = channel_c.get_J_projectile ();
  const double jcp = channel_cp.get_J_projectile ();

  const int lc  = channel_c.get_LCM_projectile ();
  const int lcp = channel_cp.get_LCM_projectile ();

  const int nmax_c  = nmax_lj_c (lc  , jc);
  const int nmax_cp = nmax_lj_cp(lcp , jcp);

  const complex<double> average_n_scat_Tc  = channel_c.get_average_n_scat_Tc ();
  const complex<double> average_n_scat_Tcp = channel_cp.get_average_n_scat_Tc ();
  
  const double real_average_n_scat_Tc  = real (average_n_scat_Tc);
  const double real_average_n_scat_Tcp = real (average_n_scat_Tcp);

  const class nlj_table<bool> &is_it_valence_shell_tab_c  = data_tau_c.get_is_it_valence_shell_tab ();
  const class nlj_table<bool> &is_it_valence_shell_tab_cp = data_tau_cp.get_is_it_valence_shell_tab ();

  const class nlj_table<unsigned int> &shells_indices_tau_c  = data_tau_c.get_shells_indices ();
  const class nlj_table<unsigned int> &shells_indices_tau_cp = data_tau_cp.get_shells_indices ();

  const class array<class nlj_struct> &shells_qn_tau_c  = data_tau_c.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_tau_cp = data_tau_cp.get_shells_quantum_numbers ();

  const class array<class vector_class<complex<double> > > &HO_overlaps_c  = data_tau_c.get_HO_overlaps ();
  const class array<class vector_class<complex<double> > > &HO_overlaps_cp = data_tau_cp.get_HO_overlaps (); 

  double ME_nHOc_overlap_nHOcp = 0.0;

  for (int nc = 0 ; nc <= nmax_c ; nc++) 
    {
      if (is_it_valence_shell_tab_c(nc , lc , jc))
	{
	  const unsigned int shell_index_c = shells_indices_tau_c(nc , lc , jc);

	  const class nlj_struct &shell_qn_c = shells_qn_tau_c(shell_index_c);

	  const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	  const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_tab(ic , nc) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max))
	    {
	      const unsigned int index_in = matrices_indices(ic , nc);

	      const unsigned int sc = shells_indices_tau_c(nc , lc , jc);

	      const class vector_class<complex<double> > &HO_overlaps_nc = HO_overlaps_c(sc);

	      const complex<double> HO_overlap_nc_nHOc = HO_overlaps_nc(nHOc);

	      for (int ncp = 0 ; ncp <= nmax_cp ; ncp++) 
		{
		  if (is_it_valence_shell_tab_cp(ncp , lcp , jcp))
		    {
		      const unsigned int shell_index_cp = shells_indices_tau_cp(ncp , lcp , jcp);
		      
		      const class nlj_struct &shell_qn_cp = shells_qn_tau_cp(shell_index_cp);

		      const bool S_matrix_pole_ncp = shell_qn_cp.get_S_matrix_pole ();

		      const double real_average_n_scat_cp = (!S_matrix_pole_ncp) ? (real_average_n_scat_Tcp + 1) : (real_average_n_scat_Tcp);

		      if (!is_it_forbidden_channel_tab(icp , ncp) && (real_average_n_scat_cp <= CC_average_n_scat_target_projectile_max))
			{
			  const unsigned int index_out = matrices_indices(icp , ncp);

			  const unsigned int scp = shells_indices_tau_cp(ncp , lcp , jcp);

			  const class vector_class<complex<double> > &HO_overlaps_ncp = HO_overlaps_cp(scp);

			  const complex<double> HO_overlap_ncp_nHOcp = HO_overlaps_ncp(nHOcp);

			  ME_nHOc_overlap_nHOcp += real (HO_overlap_nc_nHOc * overlaps_matrix(index_in , index_out) * HO_overlap_ncp_nHOcp);

			  if ((ic == icp) && (nc == ncp)) ME_nHOc_overlap_nHOcp -= real (HO_overlap_nc_nHOc*HO_overlap_ncp_nHOcp);
			}
		    }
		}
	    }
	}
    }

  return ME_nHOc_overlap_nHOcp;
}







// Use of the HO matrix to make the elements really finite-range
// -------------------------------------------------------------

complex<double> CC_H_MEs_one_nucleon::finite_range_orthogonalized_potential_two_channels_two_CC_Berggren_calc (
													       const class array<class CC_channel_class> &channels_tab , 
													       const unsigned int ic , 
													       const unsigned int icp , 
													       const unsigned int nc , 
													       const unsigned int ncp , 
													       const class nucleons_data &prot_data_CC_Berggren , 
													       const class nucleons_data &neut_data_CC_Berggren , 
													       const class array<class matrix<complex<double> > > &finite_range_orthogonalized_potential_HO_submatrices)
{
  const class CC_channel_class &channel_c  = channels_tab(ic);
  const class CC_channel_class &channel_cp = channels_tab(icp);

  const enum particle_type particle_c  = channel_c.get_projectile ();
  const enum particle_type particle_cp = channel_cp.get_projectile ();

  const class nucleons_data &data_tau_CC_Berggren_c  = (particle_c  == PROTON) ? (prot_data_CC_Berggren) : (neut_data_CC_Berggren);
  const class nucleons_data &data_tau_CC_Berggren_cp = (particle_cp == PROTON) ? (prot_data_CC_Berggren) : (neut_data_CC_Berggren);

  const int lc  = channel_c.get_LCM_projectile ();
  const int lcp = channel_cp.get_LCM_projectile ();

  const double jc  = channel_c.get_J_projectile ();
  const double jcp = channel_cp.get_J_projectile ();

  // Fermi is used here , as one has to put a cut function in equivalent potentials for them to go to zero at infinity
  const class array<class vector_class<complex<double> > > &HO_overlaps_Fermi_CC_Berggren_c  = data_tau_CC_Berggren_c.get_HO_overlaps_Fermi ();
  const class array<class vector_class<complex<double> > > &HO_overlaps_Fermi_CC_Berggren_cp = data_tau_CC_Berggren_cp.get_HO_overlaps_Fermi ();

  const class nlj_table<unsigned int> &shells_indices_tau_CC_Berggren_c  = data_tau_CC_Berggren_c.get_shells_indices ();
  const class nlj_table<unsigned int> &shells_indices_tau_CC_Berggren_cp = data_tau_CC_Berggren_cp.get_shells_indices ();

  const unsigned int sc  = shells_indices_tau_CC_Berggren_c (nc  , lc  , jc);
  const unsigned int scp = shells_indices_tau_CC_Berggren_cp(ncp , lcp , jcp);

  const class matrix<complex<double> > &finite_range_orthogonalized_potential_HO_submatrix_c_cp = finite_range_orthogonalized_potential_HO_submatrices(ic , icp);

  const class vector_class<complex<double> > &HO_overlaps_Fermi_nc  = HO_overlaps_Fermi_CC_Berggren_c (sc);
  const class vector_class<complex<double> > &HO_overlaps_Fermi_ncp = HO_overlaps_Fermi_CC_Berggren_cp(scp);
  
  const complex<double> ME_nc_potential_ncp = HO_overlaps_Fermi_nc * (finite_range_orthogonalized_potential_HO_submatrix_c_cp * HO_overlaps_Fermi_ncp);
  
  return ME_nc_potential_ncp;
}



