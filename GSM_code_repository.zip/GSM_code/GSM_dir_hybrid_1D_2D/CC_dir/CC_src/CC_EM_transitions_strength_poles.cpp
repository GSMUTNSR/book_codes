#include "../CC_include/CC_include_def.h"


using namespace string_routines;
using namespace correlated_state_routines;
using namespace inputs_misc;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_observables_common;
using namespace CC_EM_transitions_strength_MEs;
using namespace EM_transitions_common;
using namespace EM_transitions;
using namespace configuration_SD_in_space_one_jump_out_to_in;


void CC_EM_transitions_strength_poles::EM_suboperators_intrinsic_MEs_calc (
									   const class input_data_str &input_data ,
									   const TYPE &q , 
									   const int L , 
									   const bool is_it_longwavelength_approximation , 
									   const bool is_it_Gauss_Legendre , 
									   const class interaction_class &inter_data_basis , 
									   class array<class cluster_data> &cluster_projectile_data_tab , 
									   class CC_target_projectile_composite_data &Tpc_data ,
									   class GSM_vector &PSI_full)
{
  const enum interaction_type inter = input_data.get_inter ();
  
  const unsigned int EM_suboperator_number = EM_suboperator_type_number_determine ();
  
  const unsigned int cluster_number = cluster_projectile_data_tab.dimension (0);
  
  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();

  const int n_holes_max = Tpc_data.get_n_holes_max ();
  
  const int n_scat_max = Tpc_data.get_n_scat_max ();
  
  const int E_relative_max_hw = Tpc_data.get_E_relative_max_hw ();

  const class GSM_vector_helper_class dummy_helper;

  class array<TYPE> &EM_suboperator_intrinsic_NBMEs_strength = Tpc_data.get_EM_suboperator_intrinsic_NBMEs_strength ();
  
  EM_suboperator_intrinsic_NBMEs_strength = 0.0;

  const unsigned int N_bef_R_GL = input_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = input_data.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const double J_intrinsic_max = Jmax_intrinsic_cluster_determine ();

  const int l_intrinsic_max = make_int (2.0*J_intrinsic_max);
	  
  const int l_intrinsic_max_plus_one = l_intrinsic_max + 1;
  
  class array<TYPE> EM_suboperator_intrinsic_NBMEs_strength_cluster_fixed_tab(Nr);

  // cluster intrinsic state
  for (unsigned int icp = 0 ; icp < cluster_number ; icp++)
    {      
      class cluster_data &data_cp = cluster_projectile_data_tab(icp);
      
      class nucleons_data &cluster_prot_data_HO_cp = data_cp.get_cluster_prot_data_HO ();
      class nucleons_data &cluster_neut_data_HO_cp = data_cp.get_cluster_neut_data_HO ();

      const unsigned int BP_cp = data_cp.get_BP_intrinsic ();
      
      const double Jcp = data_cp.get_J_intrinsic ();

      const double Mcp = Jcp;

      const int Zcp_cluster = data_cp.get_Z_cluster ();
      const int Ncp_cluster = data_cp.get_N_cluster ();

      const int n_holes_max_p_cp = cluster_prot_data_HO_cp.get_n_holes_max ();
      const int n_holes_max_n_cp = cluster_neut_data_HO_cp.get_n_holes_max ();
      
      const int n_scat_max_p_cp = cluster_prot_data_HO_cp.get_n_scat_max ();
      const int n_scat_max_n_cp = cluster_neut_data_HO_cp.get_n_scat_max ();

      const int n_scat_max_cp = min (n_scat_max , n_scat_max_p_cp + n_scat_max_n_cp);
      
      const int Ep_max_hw_cp = cluster_prot_data_HO_cp.get_E_max_hw ();
      const int En_max_hw_cp = cluster_neut_data_HO_cp.get_E_max_hw ();

      const int E_min_hw_cp = cluster_prot_data_HO_cp.get_E_min_hw () + cluster_neut_data_HO_cp.get_E_min_hw ();

      const int E_max_hw_cp = E_relative_max_hw + E_min_hw_cp;
      
      const enum space_type space_cp = space_determine (Zcp_cluster , Ncp_cluster);

      const class correlated_state_str PSI_cluster_qn_cp (Zcp_cluster , Ncp_cluster , BP_cp , Jcp , 0 , NADA , NADA , NADA , NADA , false);

      class GSM_vector_helper_class PSI_cluster_helper_cp (false , space_cp , inter , false , truncation_hw , truncation_ph , 
							   n_holes_max      , n_scat_max_cp   , E_max_hw_cp  , 
							   n_holes_max_p_cp , n_scat_max_p_cp , Ep_max_hw_cp ,
							   n_holes_max_n_cp , n_scat_max_n_cp , En_max_hw_cp , 
							   BP_cp , Mcp , true , cluster_prot_data_HO_cp , cluster_neut_data_HO_cp);

      class GSM_vector PSI_cluster_cp (PSI_cluster_helper_cp);

      PSI_cluster_cp.eigenvector_read_disk (true , true , PSI_cluster_qn_cp);

      for (unsigned int ic = 0 ; ic < cluster_number ; ic++)
	{
	  EM_suboperator_intrinsic_NBMEs_strength_cluster_fixed_tab = 0.0;

	  class cluster_data &data_c = cluster_projectile_data_tab(ic);

	  const int Zc_cluster = data_c.get_Z_cluster ();
	  const int Nc_cluster = data_c.get_N_cluster ();

	  if ((Zcp_cluster == Zc_cluster) && (Ncp_cluster == Nc_cluster))
	    {
	      const double Jc = data_c.get_J_intrinsic ();

	      const double Mc = Jc;

	      const int Lmin = abs (make_int (Jc - Jcp));

	      const int Lmax = make_int (Jc + Jcp);

	      if ((L < Lmin) || (L > Lmax))
		{
		  class nucleons_data &cluster_prot_data_HO_c = data_c.get_cluster_prot_data_HO ();
		  class nucleons_data &cluster_neut_data_HO_c = data_c.get_cluster_neut_data_HO ();

		  const unsigned int BP_c = data_c.get_BP_intrinsic ();
		  
		  const int n_holes_max_p_c = cluster_prot_data_HO_c.get_n_holes_max ();
		  const int n_holes_max_n_c = cluster_neut_data_HO_c.get_n_holes_max ();
		  
		  const int n_scat_max_p_c = cluster_prot_data_HO_c.get_n_scat_max ();
		  const int n_scat_max_n_c = cluster_neut_data_HO_c.get_n_scat_max ();

		  const int n_scat_max_c = min (n_scat_max , n_scat_max_p_c + n_scat_max_n_c);
		  
		  const int Ep_max_hw_c = cluster_prot_data_HO_c.get_E_max_hw ();
		  const int En_max_hw_c = cluster_neut_data_HO_c.get_E_max_hw ();

		  const int E_min_hw_c = cluster_prot_data_HO_c.get_E_min_hw () + cluster_neut_data_HO_c.get_E_min_hw ();

		  const int E_max_hw_c = E_relative_max_hw + E_min_hw_c;

		  const enum space_type space_c = space_determine (Zc_cluster , Nc_cluster);

		  const class correlated_state_str PSI_cluster_qn_c (Zc_cluster , Nc_cluster , BP_c , Jc , 0 , NADA , NADA , NADA , NADA , false);

		  class GSM_vector_helper_class PSI_cluster_helper_c (false , space_c , inter , false , truncation_hw , truncation_ph , 
								      n_holes_max     , n_scat_max_c   , E_max_hw_c  , 
								      n_holes_max_p_c , n_scat_max_p_c , Ep_max_hw_c ,
								      n_holes_max_n_c , n_scat_max_n_c , En_max_hw_c , 
								      BP_c , Mc , true , cluster_prot_data_HO_c , cluster_neut_data_HO_c);

		  class GSM_vector PSI_cluster_c (PSI_cluster_helper_c);

		  PSI_cluster_c.eigenvector_read_disk (true , true , PSI_cluster_qn_c);

		  bool are_configuration_SD_in_space_one_jump_tables_calculated = false;
	      
		  for (unsigned int EM_suboperator_index = 0 ; EM_suboperator_index < EM_suboperator_number ; EM_suboperator_index++)
		    {
		      const enum EM_suboperator_type EM_suboperator = EM_suboperator_type_from_index (EM_suboperator_index);

		      const unsigned int BP_EM = BP_EM_suboperator_determine (EM_suboperator , L);
		      // delta (quantum numbers are conserved)

		      if (binary_parity_product (BP_c , BP_cp) == BP_EM)
			{
			  if (!are_configuration_SD_in_space_one_jump_tables_calculated)
			    {
			      class GSM_vector_helper_class PSI_cluster_helper_c_full;
			      
			      PSI_cluster_helper_c_full.allocate_fill_without_MPI_parallelization (PSI_cluster_helper_c);
			      
			      configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , true , false , false , false ,
											   PSI_cluster_helper_c_full , PSI_cluster_helper_cp , dummy_helper ,
											   cluster_prot_data_HO_c , cluster_neut_data_HO_c);
			      
			      are_configuration_SD_in_space_one_jump_tables_calculated = true;			      
			    }
			  
			  for (int Lc = 0 ; Lc <= l_intrinsic_max_plus_one ; Lc++)
			    { 
			      cluster::EM_suboperator_intrinsic_NBMEs_calc (PSI_full , EM_suboperator , q , L , Lc ,
									    is_it_longwavelength_approximation , is_it_Gauss_Legendre , 
									    inter_data_basis , data_c , data_cp , PSI_cluster_c , PSI_cluster_cp ,
									    EM_suboperator_intrinsic_NBMEs_strength_cluster_fixed_tab);

			      if (THIS_PROCESS == MASTER_PROCESS)
				{
				  for (unsigned int i = 0 ; i < Nr ; i++) 
				    EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , Lc , EM_suboperator_index , i) = EM_suboperator_intrinsic_NBMEs_strength_cluster_fixed_tab(i);
				}
			    }
			}//BP_EM test
		    }//loop EM_suboperator_index
		}// test L coupling
	    }//loop ic
	}//test N Z clusters
    }//loop icp

#ifdef UseMPI
  if (is_it_MPI_parallelized) EM_suboperator_intrinsic_NBMEs_strength.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}
















void CC_EM_transitions_strength_poles::B_amplitude_tab_calc ( 
							     class GSM_vector &PSI_full , 
							     const enum EM_type EM , 
							     const int L , 
							     const bool is_it_longwavelength_approximation ,
							     const bool is_it_Gauss_Legendre , 
							     const bool is_it_nas_only ,
							     const class CC_target_projectile_composite_data &Tpc_data , 
							     const class input_data_str &input_data_CC_Berggren , 
							     const class interaction_class &inter_data_basis , 
							     const class array<class cluster_data> &cluster_projectile_data_tab , 
							     const class CC_Hamiltonian_data &CC_H_data_in ,  
							     const class CC_state_class &CC_state_in , 
							     const class CC_Hamiltonian_data &CC_H_data_out , 
							     const class CC_state_class &CC_state_out , 
							     class nucleons_data &prot_data , 
							     class nucleons_data &neut_data ,
							     class array<TYPE> &strength_tab)
{
  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();
  
  const bool full_common_vectors_used_in_file = input_data_CC_Berggren.get_full_common_vectors_used_in_file ();

  const bool is_it_one_nucleon_COSM_case = Tpc_data.get_is_it_one_nucleon_COSM_case ();

  const enum storage_type Hamiltonian_storage = input_data_CC_Berggren.get_Hamiltonian_storage ();

  const bool is_it_full_or_partial_storage = is_it_full_or_partial_storage_determine (Hamiltonian_storage);
  
  const unsigned int N_bef_R_GL = CC_state_in.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state_in.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
		
  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();

  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();

  //=================== calculations of the beta matrix elts < (J_i) || O_L || J_f > ====================//

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const int Z_cluster_max = (!is_it_one_nucleon_COSM_case) ? (Z_cluster_max_determine (cluster_projectile_data_tab)) : (1);
  const int N_cluster_max = (!is_it_one_nucleon_COSM_case) ? (N_cluster_max_determine (cluster_projectile_data_tab)) : (1);
  
  const int Z_cluster_number = Z_cluster_max + 1;
  const int N_cluster_number = N_cluster_max + 1;

  const complex<double> E_in_complex  = CC_state_in.get_E ();
  const complex<double> E_out_complex = CC_state_out.get_E ();

  const TYPE E_in  = generate_scalar<TYPE> (real (E_in_complex)  , imag (E_in_complex));
  const TYPE E_out = generate_scalar<TYPE> (real (E_out_complex) , imag (E_out_complex));
  
  const TYPE q = (E_in - E_out)/hbar_c;

  class array<class nucleons_data> prot_data_one_projectile_less_tab(Z_cluster_number , N_cluster_number);
  class array<class nucleons_data> neut_data_one_projectile_less_tab(Z_cluster_number , N_cluster_number);

  data_one_projectile_less_alloc_calc (is_it_full_or_partial_storage , is_it_one_nucleon_COSM_case , TBME_inter , truncation_hw , truncation_ph , 
				       prot_data , neut_data , projectile_tab , cluster_projectile_data_tab , prot_data_one_projectile_less_tab , neut_data_one_projectile_less_tab);

  class array<TYPE> target_reduced_NBMEs(N_target_projectile_states , N_target_projectile_states , Nr);

  target_reduced_NBMEs = 0.0;

  composite::target_reduced_NBMEs_calc (PSI_full , TBME_inter , EM , q , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , full_common_vectors_used_in_file ,
					Tpc_data , prot_data_one_projectile_less_tab , neut_data_one_projectile_less_tab , target_reduced_NBMEs);

  composite::calc (PSI_full , EM , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre ,
		   Tpc_data , cluster_projectile_data_tab , is_it_nas_only , CC_H_data_in , CC_state_in , CC_H_data_out , CC_state_out , 
		   prot_data , neut_data , input_data_CC_Berggren , target_reduced_NBMEs , strength_tab);
}




















void CC_EM_transitions_strength_poles::calc_store (
						   const class input_data_str &input_data ,
						   const class input_data_str &input_data_CC_Berggren ,  
						   const class interaction_class &inter_data_basis ,
						   const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
						   const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
						   class nucleons_data &prot_data_CC_Berggren , 
						   class nucleons_data &neut_data_CC_Berggren , 
						   class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab ,
						   class nucleons_data &prot_data , 
						   class nucleons_data &neut_data ,
						   class array<class cluster_data> &cluster_projectile_data_tab ,
						   class CC_target_projectile_composite_data &Tpc_data ,
						   class TBMEs_class &TBMEs_pn)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "EM transitions strengths" << endl;
      cout <<         "------------------------" << endl << endl;
    }

  const int Z = prot_data.get_N_nucleons ();
  const int N = neut_data.get_N_nucleons ();

  const int A = prot_data.get_A ();

  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  //// if true, the L_min/max are put to the L value for the total cross section
  //// the interferences between different L values disappear due to the orthogonality of the Wigner D-matrices
  //const bool is_total_cross_section_calculated = input_data.get_CC_beta_is_total_cross_section_calculated;
  //const int L_for_total_cross_section = input_data.get_CC_beta_L_for_total_cross_section;

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
  
  const bool is_it_one_nucleon_COSM_case = Tpc_data.get_is_it_one_nucleon_COSM_case ();

  const unsigned int N_bef_R_uniform = input_data_CC_Berggren.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = input_data_CC_Berggren.get_N_aft_R_uniform ();

  const unsigned int N_bef_R_GL = input_data_CC_Berggren.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = input_data_CC_Berggren.get_N_aft_R_GL ();

  const unsigned int Nk_momentum_GL = input_data_CC_Berggren.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = input_data_CC_Berggren.get_Nk_momentum_uniform ();
  
  const double R_real_max = input_data_CC_Berggren.get_R_real_max ();

  const double R = input_data_CC_Berggren.get_R ();

  const double kmax_momentum = input_data_CC_Berggren.get_kmax_momentum ();

  const double R_Fermi_momentum = input_data_CC_Berggren.get_R_Fermi_momentum ();

  const double R0_inter = inter_data_basis.get_R0 ();

  const double R0 = 1.27*cbrt (A);

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);
  
  const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);
  
  const class array<unsigned int> &N_channels_tab = Tpc_data.get_N_channels_tab ();

  const class array<unsigned int> &BP_A_tab = Tpc_data.get_BP_A_tab (); 

  const class array<double> &J_A_tab = Tpc_data.get_J_A_tab ();

  const class array<class CC_channel_class> &channels_tab = Tpc_data.get_channels_tab ();

  const unsigned int EM_transitions_strength_number = input_data.get_EM_transitions_strength_number ();

  const class array<enum EM_type> &EM_strength_tab = input_data.get_EM_strength_tab ();

  const class array<int> &EM_strength_L_tab = input_data.get_EM_strength_L_tab ();

  const class array<bool> &EM_strength_is_it_Gauss_Legendre_tab = input_data.get_EM_strength_is_it_Gauss_Legendre_tab ();

  const class array<unsigned int> &EM_strength_BP_IN_tab  = input_data.get_EM_strength_BP_IN_tab ();
  const class array<unsigned int> &EM_strength_BP_OUT_tab = input_data.get_EM_strength_BP_OUT_tab ();

  const class array<double> &EM_strength_J_IN_tab  = input_data.get_EM_strength_J_IN_tab ();
  const class array<double> &EM_strength_J_OUT_tab = input_data.get_EM_strength_J_OUT_tab ();

  const class array<unsigned int> &EM_strength_vector_index_IN_tab  = input_data.get_EM_strength_vector_index_IN_tab ();
  const class array<unsigned int> &EM_strength_vector_index_OUT_tab = input_data.get_EM_strength_vector_index_OUT_tab ();

  const class array<bool> &EM_strength_is_it_longwavelength_approximation_tab = input_data.get_EM_strength_is_it_longwavelength_approximation_tab ();

  const double step_bef_R_uniform = input_data_CC_Berggren.get_step_bef_R_uniform ();

  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);

  class array<double> r_bef_R_tab_uniform(N_bef_R_uniform);
  
  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;

  class GSM_vector PSI_full;
    
  for (unsigned int EM_index = 0 ; EM_index < EM_transitions_strength_number ; EM_index++)
    {
      const enum EM_type EM = EM_strength_tab(EM_index);
      
      const int L = EM_strength_L_tab(EM_index);

      const bool is_it_Gauss_Legendre = EM_strength_is_it_Gauss_Legendre_tab(EM_index);

      const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

      const unsigned int BP_IN  = EM_strength_BP_IN_tab(EM_index);
      const unsigned int BP_OUT = EM_strength_BP_OUT_tab(EM_index);

      const unsigned int vector_index_IN  = EM_strength_vector_index_IN_tab(EM_index);
      const unsigned int vector_index_OUT = EM_strength_vector_index_OUT_tab(EM_index);

      const double J_IN  = EM_strength_J_IN_tab(EM_index);
      const double J_OUT = EM_strength_J_OUT_tab(EM_index);

      const double M_IN  = J_IN;
      const double M_OUT = J_OUT;

      class correlated_state_str PSI_IN_qn (Z , N , BP_IN  , J_IN  , vector_index_IN  , NADA , NADA , NADA , NADA , false);
      class correlated_state_str PSI_OUT_qn(Z , N , BP_OUT , J_OUT , vector_index_OUT , NADA , NADA , NADA , NADA , false);

      const unsigned int iJPi_IN  = JPi_index_determine (BP_A_tab , J_A_tab , BP_IN  , J_IN);
      const unsigned int iJPi_OUT = JPi_index_determine (BP_A_tab , J_A_tab , BP_OUT , J_OUT);

      const unsigned int N_channels_JPi_IN  = N_channels_tab(iJPi_IN);
      const unsigned int N_channels_JPi_OUT = N_channels_tab(iJPi_OUT);

      // table of all channels for the given composite state

      class array<class CC_channel_class> channels_JPi_IN_tab (N_channels_JPi_IN);
      class array<class CC_channel_class> channels_JPi_OUT_tab(N_channels_JPi_OUT);

      JPi_channels_tab_BP_J_vector_index_E_fill (channels_tab , BP_IN  , J_IN  , vector_index_IN  , NADA , channels_JPi_IN_tab);
      JPi_channels_tab_BP_J_vector_index_E_fill (channels_tab , BP_OUT , J_OUT , vector_index_OUT , NADA , channels_JPi_OUT_tab);

      class CC_state_class CC_state_IN (is_it_one_nucleon_COSM_case , nmax_HO_lab_tab , cluster_projectile_data_tab , true , true , N_channels_JPi_IN ,
					NADA , channels_JPi_IN_tab , N_bef_R_uniform , N_aft_R_uniform , N_bef_R_GL , N_aft_R_GL , Nk_momentum_uniform , Nk_momentum_GL ,
					R , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , A , BP_IN , J_IN , M_IN , vector_index_IN , NADA);

      class CC_Hamiltonian_data CC_H_data_IN(N_channels_JPi_IN , input_data_CC_Berggren);
      
      CC_eigenstate_H_data_calc (Tpc_data , inter_data_basis , input_data_CC_Berggren , 
				 prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab , 
				 prot_data_CC_Berggren , neut_data_CC_Berggren , prot_data , neut_data , PSI_IN_qn , TBMEs_pn , CC_H_data_IN , CC_state_IN);

      class CC_state_class CC_state_OUT (is_it_one_nucleon_COSM_case , nmax_HO_lab_tab , cluster_projectile_data_tab , true , true , N_channels_JPi_OUT ,
					 NADA , channels_JPi_OUT_tab , N_bef_R_uniform , N_aft_R_uniform , N_bef_R_GL , N_aft_R_GL , Nk_momentum_uniform , Nk_momentum_GL , 
					 R , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , A , BP_OUT , J_OUT , M_OUT , vector_index_OUT , NADA); 

      class CC_Hamiltonian_data CC_H_data_OUT(N_channels_JPi_OUT , input_data_CC_Berggren);
      
      CC_eigenstate_H_data_calc (Tpc_data , inter_data_basis , input_data_CC_Berggren , 
				 prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab , 
				 prot_data_CC_Berggren , neut_data_CC_Berggren , prot_data , neut_data , PSI_OUT_qn , TBMEs_pn , CC_H_data_OUT , CC_state_OUT);

      const bool is_it_longwavelength_approximation = EM_strength_is_it_longwavelength_approximation_tab(EM_index);

      const string longwavelength_approximation_str = (is_it_longwavelength_approximation) ? ("longwavelength_approximation") : ("no_longwavelength_approximation");

      const complex<double> E_IN_complex  = PSI_IN_qn.get_E ();
      const complex<double> E_OUT_complex = PSI_OUT_qn.get_E (); 

      const TYPE E_IN  = generate_scalar<TYPE> (real (E_IN_complex)  , imag (E_IN_complex));
      const TYPE E_OUT = generate_scalar<TYPE> (real (E_OUT_complex) , imag (E_OUT_complex));
      
      const TYPE q = (E_IN - E_OUT)/hbar_c;

      if (!is_it_one_nucleon_COSM_case)
	EM_suboperators_intrinsic_MEs_calc (input_data , q , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , inter_data_basis , cluster_projectile_data_tab , Tpc_data , PSI_full);

      class array<TYPE> B_amplitude_strength_nas_tab(Nr);
      class array<TYPE> B_amplitude_strength_as_tab(Nr);

      B_amplitude_tab_calc (PSI_full , EM , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , true , Tpc_data ,
			    input_data_CC_Berggren , inter_data_basis , cluster_projectile_data_tab , CC_H_data_IN , CC_state_IN , CC_H_data_OUT , CC_state_OUT ,
			    prot_data , neut_data , B_amplitude_strength_nas_tab);

      B_amplitude_tab_calc (PSI_full , EM , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , false , Tpc_data ,
			    input_data_CC_Berggren , inter_data_basis , cluster_projectile_data_tab , CC_H_data_IN , CC_state_IN , CC_H_data_OUT , CC_state_OUT ,
			    prot_data , neut_data , B_amplitude_strength_as_tab);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  const string PSI_IN_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_IN_qn);
	  const string PSI_OUT_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_OUT_qn);

	  const string EM_letter = EM_letter_determine (EM);
	  
	  const string EM_strength_string = EM_letter + make_string<int> (L) + "_strength_" + longwavelength_approximation_str + "_" + PSI_IN_qn_string + "_" + PSI_OUT_qn_string;

	  const string EM_strength_nas_string = EM_strength_string + "_non_antisymmetrized";
	  const string EM_strength_as_string  = EM_strength_string + "_antisymmetrized";

	  const string long_wavelength_str = (is_it_longwavelength_approximation) ? ("with long wavelength approximation calculated") : ("without long wavelength approximation calculated");

	  const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (r_bef_R_tab_GL) : (r_bef_R_tab_uniform);

	  print_B_G_amplitude_tab (EM , q , L , A , J_IN , r_bef_R_tab , B_amplitude_strength_nas_tab , EM_strength_nas_string);
	  print_B_G_amplitude_tab (EM , q , L , A , J_IN , r_bef_R_tab , B_amplitude_strength_as_tab  , EM_strength_as_string);

	  cout << EM_letter << L << " transition strength "
	       << J_Pi_vector_index_string (BP_IN , J_IN , vector_index_IN) << " --> " << J_Pi_vector_index_string (BP_OUT , J_OUT , vector_index_OUT) << " " << long_wavelength_str << endl;
	}
    }
}


