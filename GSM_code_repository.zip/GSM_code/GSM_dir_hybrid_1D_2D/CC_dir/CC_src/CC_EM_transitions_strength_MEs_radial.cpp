#include "../CC_include/CC_include_def.h"

using namespace EM_transitions_common;
using namespace EM_transitions_radial_OBMEs;
using namespace Wigner_signs;




//--// return the radial part of <uc_f lf jf || E_L || uc_i li ji> before R
void CC_EM_transitions_strength_MEs::radial::radial_OBMEs_calc (
								const enum radial_operator_type radial_operator , 
								const int L , 
								const bool is_it_longwavelength_approximation ,
								const bool is_it_Gauss_Legendre ,
								const class CC_state_class &CC_state_in , 
								const class CC_state_class &CC_state_out , 
								const unsigned int ic_in , 
								const unsigned int ic_out , 
								class array<TYPE> &radial_OBMEs)
{
  //--// positions and weights
  const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (CC_state_out.get_r_bef_R_tab_GL ()) : (CC_state_out.get_r_bef_R_tab_uniform ());

  //--// tables containing the wfs of all channels
  const class array<complex<double> > &CC_wf_bef_R_tab_in  = (is_it_Gauss_Legendre) ? (CC_state_in.get_CC_wf_bef_R_tab_GL ())  : (CC_state_in.get_CC_wf_bef_R_tab_uniform ());
  const class array<complex<double> > &CC_wf_bef_R_tab_out = (is_it_Gauss_Legendre) ? (CC_state_out.get_CC_wf_bef_R_tab_GL ()) : (CC_state_out.get_CC_wf_bef_R_tab_uniform ());

  //--// number of discretization points , and a factor
  const unsigned int N_bef_R_GL = CC_state_out.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state_out.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
  
  const complex<double> E_in_complex  = CC_state_in.get_E ();
  const complex<double> E_out_complex = CC_state_out.get_E ();

  const TYPE E_in  = generate_scalar<TYPE> (real (E_in_complex)  , imag (E_in_complex));
  const TYPE E_out = generate_scalar<TYPE> (real (E_out_complex) , imag (E_out_complex));
  
  const TYPE q = (E_in - E_out)/hbar_c;
  
  const TYPE factor = double_factorial (2*L + 1)/(L + 1.0)/pow (q , L);

  class Coulomb_wave_functions Bessel(true , L , 0);

  if (Nr > 0)
    {
      const double r0 = r_bef_R_tab(0);

      const complex<double> CC_wf_bef_R_in_r0  = CC_wf_bef_R_tab_in  (ic_in  , 0);
      const complex<double> CC_wf_bef_R_out_r0 = CC_wf_bef_R_tab_out (ic_out , 0);
      
      const TYPE O_r0 = EM_transitions_radial_operator (radial_operator , q , L , is_it_longwavelength_approximation  , factor , Bessel , r0);
      
#ifdef TYPEisDOUBLECOMPLEX
      radial_OBMEs(0) = (r0 > 0.0) ? (CC_wf_bef_R_in_r0*CC_wf_bef_R_out_r0*O_r0) : (0.0);
#endif
      
#ifdef TYPEisDOUBLE
      radial_OBMEs(0) = (r0 > 0.0) ? (real (CC_wf_bef_R_in_r0)*real (CC_wf_bef_R_out_r0)*O_r0) : (0.0);
#endif
    }
  
  for (unsigned int i = 1 ; i < Nr ; i++)
    {
      const double r = r_bef_R_tab(i);

      const complex<double> CC_wf_bef_R_in_r  = CC_wf_bef_R_tab_in  (ic_in  , i);
      const complex<double> CC_wf_bef_R_out_r = CC_wf_bef_R_tab_out (ic_out , i);
      
      const TYPE Or = EM_transitions_radial_operator (radial_operator , q , L , is_it_longwavelength_approximation  , factor , Bessel , r);
      
#ifdef TYPEisDOUBLECOMPLEX
      radial_OBMEs(i) = CC_wf_bef_R_in_r*CC_wf_bef_R_out_r*Or;
#endif
      
#ifdef TYPEisDOUBLE
      radial_OBMEs(i) = real (CC_wf_bef_R_in_r)*real (CC_wf_bef_R_out_r)*Or;
#endif
    }
}
