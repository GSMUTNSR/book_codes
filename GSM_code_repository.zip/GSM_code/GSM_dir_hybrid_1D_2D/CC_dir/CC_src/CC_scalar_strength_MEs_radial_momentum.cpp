#include "../CC_include/CC_include_def.h"

using namespace Wigner_signs;



// TYPE is double or complex
// -------------------------




// Calculation of the radial strength function of a scalar operator between channel functions
// ------------------------------------------------------------------------------------------
// One calculates the radial part u[c[out]](r) . r^2 or Id . u[c[in]](r) for all r radii on [0:R], where the radial part reduces to one point (i.e. no integration over r).

void CC_scalar_strength_MEs::radial_momentum::radial_OBMEs_calc (
								 const enum radial_operator_type radial_operator , 
								 const bool is_it_Gauss_Legendre , 
								 const class CC_state_class &CC_state_in , 
								 const class CC_state_class &CC_state_out , 
								 const unsigned int ic_in , 
								 const unsigned int ic_out ,  
								 class array<TYPE> &radial_OBMEs)
{
  //--// positions and weights
  const class array<double> &r_bef_R_tab =  (is_it_Gauss_Legendre) ? (CC_state_in.get_r_bef_R_tab_GL ()) : (CC_state_in.get_r_bef_R_tab_uniform ());

  //--// tables containing the wfs of all channels
  const class array<complex<double> > &CC_wf_bef_R_in_tab  = (is_it_Gauss_Legendre) ? (CC_state_in.get_CC_wf_bef_R_tab_GL  ()) : (CC_state_in.get_CC_wf_bef_R_tab_uniform  ());
  const class array<complex<double> > &CC_wf_bef_R_out_tab = (is_it_Gauss_Legendre) ? (CC_state_out.get_CC_wf_bef_R_tab_GL ()) : (CC_state_out.get_CC_wf_bef_R_tab_uniform ());

  //--// number of discretization points

  const unsigned int N_bef_R_GL = CC_state_in.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state_in.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
  
  radial_OBMEs = 0.0;

  switch (radial_operator)
    {
    case OVERLAP:
      {
	for (unsigned int i = 0 ; i < Nr ; i++)
	  {      
	    const complex<double> CC_wf_bef_R_in_r  = CC_wf_bef_R_in_tab  (ic_in  , i);
	    const complex<double> CC_wf_bef_R_out_r = CC_wf_bef_R_out_tab (ic_out , i);
	    
#ifdef TYPEisDOUBLECOMPLEX
	    radial_OBMEs(i) = CC_wf_bef_R_in_r * CC_wf_bef_R_out_r;
#endif
      
#ifdef TYPEisDOUBLE
	    radial_OBMEs(i) = real (CC_wf_bef_R_in_r) * real (CC_wf_bef_R_out_r);
#endif
	  }
      } break;

    case R2_RADIAL:
      {
	for (unsigned int i = 0 ; i < Nr ; i++)
	  {
	    const double r = r_bef_R_tab(i);
      
	    const complex<double> CC_wf_bef_R_in_r  = CC_wf_bef_R_in_tab  (ic_in  , i);
	    const complex<double> CC_wf_bef_R_out_r = CC_wf_bef_R_out_tab (ic_out , i);
	    
#ifdef TYPEisDOUBLECOMPLEX
	    radial_OBMEs(i) = CC_wf_bef_R_in_r * CC_wf_bef_R_out_r * r * r;
#endif
      
#ifdef TYPEisDOUBLE
	    radial_OBMEs(i) = real (CC_wf_bef_R_in_r) * real (CC_wf_bef_R_out_r) * r * r;
#endif
	  }
      } break;

    default: error_message_print_abort ("radial operator is overlap or r^2 in CC_scalar_strength_MEs::radial_momentum::radial_OBMEs_calc");
    }
}



















// Calculation of the momentum strength function of a scalar operator between channel functions
// --------------------------------------------------------------------------------------------
// One calculates the momentum part u[c[out]](k) . u[c[in]](k) for all k momenta on [0:K], where the momentum part reduces to one point (i.e. no integration over k).

void CC_scalar_strength_MEs::radial_momentum::momentum_OBMEs_calc (
								   const bool is_it_Gauss_Legendre , 
								   const class CC_state_class &CC_state_in , 
								   const class CC_state_class &CC_state_out , 
								   const unsigned int ic_in , 
								   const unsigned int ic_out ,  
								   class array<TYPE> &momentum_OBMEs)
{
  //--// tables containing the wfs of all channels
  const class array<complex<double> > &CC_wf_momentum_in_tab  = (is_it_Gauss_Legendre) ? (CC_state_in.get_CC_wf_momentum_tab_GL  ()) : (CC_state_in.get_CC_wf_momentum_tab_uniform  ());
  const class array<complex<double> > &CC_wf_momentum_out_tab = (is_it_Gauss_Legendre) ? (CC_state_out.get_CC_wf_momentum_tab_GL ()) : (CC_state_out.get_CC_wf_momentum_tab_uniform ());

  //--// number of discretization points

  const unsigned int Nk_momentum_GL = CC_state_in.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = CC_state_in.get_Nk_momentum_uniform ();

  const unsigned int Nk = (is_it_Gauss_Legendre) ? (Nk_momentum_GL) : (Nk_momentum_uniform);
  
  momentum_OBMEs = 0.0;

  for (unsigned int i = 0 ; i < Nk ; i++)
    {      
      const complex<double> CC_wf_momentum_in_k  = CC_wf_momentum_in_tab  (ic_in  , i);
      const complex<double> CC_wf_momentum_out_k = CC_wf_momentum_out_tab (ic_out , i);
	    
#ifdef TYPEisDOUBLECOMPLEX
      momentum_OBMEs(i) = CC_wf_momentum_in_k * CC_wf_momentum_out_k;
#endif
      
#ifdef TYPEisDOUBLE
      momentum_OBMEs(i) = real (CC_wf_momentum_in_k) * real (CC_wf_momentum_out_k);
#endif
    }
}








// Calculation of the overlap matrix element between channel functions
// --------------------------------------------------------------------
// One calculates <u[c[out]] | u[c[in]]>.
//
// For u[c](r) functions solutions of GSM-CC, one uses complex scaling.
// The integral on [0:R] is calculate directly.
// The integral on [R:+oo[ is calculated with a change of variable so that one integrates on ]0:R^{-1/4}].
// u[c](r) = u[c]^+(r) + u[c]^-(r) (outgoing and incoming parts), so that four integrals are calculated on [R:+oo[ with complex scaling.
// Rotation angle is chosen for convergence to be the fastest for each u[c[in]]^{+/-}(r) u[c[out]]^{+/-}(r) product.
//
// For u[c](r) functions projected on the HO basis, radial integrals are directly calculated on [0:R] and [R:R[max]] and summed. 


// Calculation of the integral on [0:R] (see above)
// ------------------------------------------------
complex<double> CC_scalar_strength_MEs::radial_momentum::radial_integral_bef_R_calc (
										     const class CC_state_class &CC_state_in , 
										     const class CC_state_class &CC_state_out ,
										     const unsigned int ic_in , 
										     const unsigned int ic_out)
{
  //--// positions and weights
  const class array<double> &w_bef_R_tab_GL = CC_state_in.get_w_bef_R_tab_GL ();

  //--// tables containing the wfs of all channels
  const class array<complex<double> > &CC_wf_bef_R_in_tab_GL = CC_state_in.get_CC_wf_bef_R_tab_GL ();
  const class array<complex<double> > &CC_wf_bef_R_out_tab_GL = CC_state_out.get_CC_wf_bef_R_tab_GL ();

  //--// number of discretization points
  const unsigned int N_bef_R_GL = CC_state_in.get_N_bef_R_GL ();

  complex<double> radial_integral_bef_R = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double w = w_bef_R_tab_GL(i);

      const complex<double> CC_wf_bef_R_in_r  = CC_wf_bef_R_in_tab_GL  (ic_in  , i);
      const complex<double> CC_wf_bef_R_out_r = CC_wf_bef_R_out_tab_GL (ic_out , i);
	    
      radial_integral_bef_R += w * CC_wf_bef_R_in_r * CC_wf_bef_R_out_r;
    }

  return radial_integral_bef_R;
}






// Calculation of one of the four integrals on [R:+oo[, i.e. involving u[c[in]]^{+/-} and u[c[in]]^{+/-} (see above)
// -----------------------------------------------------------------------------------------------------------------
complex<double> CC_scalar_strength_MEs::radial_momentum::radial_integral_aft_R_part_of_four_calc (
												  const unsigned int asy_in , 
												  const unsigned int asy_out , 
												  const class CC_state_class &CC_state_in , 
												  const class CC_state_class &CC_state_out , 
												  const unsigned int ic_in , 
												  const unsigned int ic_out)
{
  const unsigned int N_aft_R_GL = CC_state_in.get_N_aft_R_GL ();

  const class array<class CC_channel_class> &channels_tab = CC_state_in.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab(ic_out);

  const class array<double> &um4_table = CC_state_in.get_um4_aft_R_tab_GL ();

  const class array<double> &w_aft_R_tab_GL = CC_state_in.get_w_aft_R_tab_GL ();

  const complex<double> k_projectile_in  = channel_c_in.get_k_projectile ();
  const complex<double> k_projectile_out = channel_c_out.get_k_projectile ();

  const complex<double> eta_projectile_in  = channel_c_in.get_eta_projectile ();
  const complex<double> eta_projectile_out = channel_c_out.get_eta_projectile ();

  const int omega_in  = minus_one_pow (asy_in);
  const int omega_out = minus_one_pow (asy_out);

  const complex<double> Sk_projectile = k_projectile_in*omega_in + k_projectile_out*omega_out;

  const complex<double> I_omega_in (0 , omega_in);
  const complex<double> I_omega_out(0 , omega_out);

  const unsigned int angle_index = optimal_angle_index (Sk_projectile);
  
  const complex<double> exp_Itheta(cos_theta_tab[angle_index] , sin_theta_tab[angle_index]);

  const class array<complex<double> > &CC_sc_wf_minus_in_aft_R_c_entrance_tab_GL  = CC_state_in.get_CC_scaled_wf_minus_aft_R_c_entrance_tab_GL ();
  const class array<complex<double> > &CC_sc_wf_minus_out_aft_R_c_entrance_tab_GL = CC_state_out.get_CC_scaled_wf_minus_aft_R_c_entrance_tab_GL ();
  
  const class array<complex<double> > &CC_sc_wf_plus_in_aft_R_tab_GL  = CC_state_in.get_CC_scaled_wf_plus_aft_R_tab_GL ();
  const class array<complex<double> > &CC_sc_wf_plus_out_aft_R_tab_GL = CC_state_out.get_CC_scaled_wf_plus_aft_R_tab_GL ();  

  const double R = CC_state_in.get_R ();

  complex<double> radial_integral_aft_R_part_of_four = 0.0;

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    { 
      const complex<double> z = R + (um4_table(i) - R)*exp_Itheta;

      const complex<double> k_projectile_in_z  = k_projectile_in*z;
      const complex<double> k_projectile_out_z = k_projectile_out*z;

      const complex<double> log_unscale_in  = (k_projectile_in  != 0.0) ? (I_omega_in *(k_projectile_in_z  - eta_projectile_in*(M_LN2  + log (k_projectile_in_z))))  : (0.0);
      const complex<double> log_unscale_out = (k_projectile_out != 0.0) ? (I_omega_out*(k_projectile_out_z - eta_projectile_out*(M_LN2 + log (k_projectile_out_z)))) : (0.0);
	    
      const complex<double> unscale_weight = exp (log_unscale_in + log_unscale_out)*w_aft_R_tab_GL(i);
      
      const complex<double> CC_sc_wf_in_z  = (asy_in == 0)  ? (CC_sc_wf_plus_in_aft_R_tab_GL(ic_in   , angle_index , i)) : (CC_sc_wf_minus_in_aft_R_c_entrance_tab_GL(angle_index  , i));
      const complex<double> CC_sc_wf_out_z = (asy_out == 0) ? (CC_sc_wf_plus_out_aft_R_tab_GL(ic_out , angle_index , i)) : (CC_sc_wf_minus_out_aft_R_c_entrance_tab_GL(angle_index , i));
      
      radial_integral_aft_R_part_of_four += CC_sc_wf_in_z * CC_sc_wf_out_z * unscale_weight;
    }

  radial_integral_aft_R_part_of_four *= 4.0*exp_Itheta;
  
  return radial_integral_aft_R_part_of_four;
}






// Calculation of the sum of four integrals on [R:+oo[, i.e. involving u[c[in]]^{+/-} and u[c[in]]^{+/-} (see above)
// -----------------------------------------------------------------------------------------------------------------
complex<double> CC_scalar_strength_MEs::radial_momentum::radial_integral_aft_R_calc (
										     const class CC_state_class &CC_state_in , 
										     const class CC_state_class &CC_state_out , 
										     const unsigned int ic_in , 
										     const unsigned int ic_out)
{
  const bool S_matrix_pole_in = CC_state_in.get_S_matrix_pole ();
  const bool S_matrix_pole_out = CC_state_out.get_S_matrix_pole ();
  
  const unsigned int ic_entrance_in = CC_state_in.get_ic_entrance ();
  const unsigned int ic_entrance_out = CC_state_out.get_ic_entrance ();

  const bool outgoing_in_case  = (S_matrix_pole_in  || (ic_in  != ic_entrance_in));
  const bool outgoing_out_case = (S_matrix_pole_out || (ic_out != ic_entrance_out));

  complex<double> integral_aft_R = 0.0;

  for (unsigned int asy_in = 0 ; (outgoing_in_case) ? (asy_in <= 0) : (asy_in <= 1) ; asy_in++)
    for (unsigned int asy_out = 0 ; (outgoing_out_case) ? (asy_out <= 0) : (asy_out <= 1) ; asy_out++)
      integral_aft_R += radial_integral_aft_R_part_of_four_calc (asy_in , asy_out , CC_state_in , CC_state_out , ic_in , ic_out);

  return integral_aft_R;
}




// Calculation of the integrals on [R:R[max] of u[c](r) functions (in practice projected on the HO basis)
// ------------------------------------------------------------------------------------------------------
complex<double> CC_scalar_strength_MEs::radial_momentum::radial_integral_aft_R_real_calc (
											  const class CC_state_class &CC_state_in , 
											  const class CC_state_class &CC_state_out , 
											  const unsigned int ic_in , 
											  const unsigned int ic_out)
{
  //--// positions and weights
  const class array<double> &w_aft_R_tab_GL_real = CC_state_in.get_w_aft_R_tab_GL_real ();

  //--// tables containing the wfs of all channels
  const class array<complex<double> > &CC_wf_aft_R_in_tab_GL = CC_state_in.get_CC_wf_aft_R_tab_GL ();
  const class array<complex<double> > &CC_wf_aft_R_out_tab_GL = CC_state_out.get_CC_wf_aft_R_tab_GL ();

  //--// number of discretization points
  const unsigned int N_aft_R_GL = CC_state_in.get_N_aft_R_GL ();

  complex<double> radial_integral_aft_R = 0.0;

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      const double w = w_aft_R_tab_GL_real(i);

      const complex<double> CC_wf_aft_R_in_r  = CC_wf_aft_R_in_tab_GL  (ic_in  , i) ;
      const complex<double> CC_wf_aft_R_out_r = CC_wf_aft_R_out_tab_GL (ic_out , i) ;
	    
      radial_integral_aft_R += w * CC_wf_aft_R_in_r * CC_wf_aft_R_out_r;
    }  
	
  return radial_integral_aft_R;
}




// Calculation of the radial overlap matrix element between channel functions (see above)
// --------------------------------------------------------------------------------------
TYPE CC_scalar_strength_MEs::radial_momentum::radial_integral_calc (
								    const class CC_state_class &CC_state_in , 
								    const class CC_state_class &CC_state_out , 
								    const unsigned int ic_in , 
								    const unsigned int ic_out)
{
  const complex<double> radial_integral_bef_R = radial_integral_bef_R_calc (CC_state_in , CC_state_out , ic_in , ic_out);

  const bool is_it_HO_projected_in = CC_state_in.get_is_it_HO_projected ();
  const bool is_it_HO_projected_out = CC_state_out.get_is_it_HO_projected ();

  if (is_it_HO_projected_in || is_it_HO_projected_out)
    {
      const complex<double> radial_integral_aft_R = radial_integral_aft_R_real_calc (CC_state_in , CC_state_out , ic_in , ic_out);
      
      const complex<double> radial_integral = radial_integral_bef_R + radial_integral_aft_R;
      
#ifdef TYPEisDOUBLECOMPLEX
      return radial_integral;  
#endif
      
#ifdef TYPEisDOUBLE
      return real (radial_integral);  
#endif
    }
  
  const class array<class CC_channel_class> &channels_tab = CC_state_in.get_channels_tab ();
  
  const class CC_channel_class &channel_c_in  = channels_tab(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab(ic_out);

  const bool S_matrix_pole_in = CC_state_in.get_S_matrix_pole ();
  const bool S_matrix_pole_out = CC_state_out.get_S_matrix_pole ();
  
  const complex<double> k_projectile_in  = channel_c_in.get_k_projectile ();
  const complex<double> k_projectile_out = channel_c_out.get_k_projectile ();

  const unsigned int ic_entrance_in = CC_state_in.get_ic_entrance ();
  const unsigned int ic_entrance_out = CC_state_out.get_ic_entrance ();
  
  const bool outgoing_in_case  = (S_matrix_pole_in  || (ic_in  != ic_entrance_in));
  const bool outgoing_out_case = (S_matrix_pole_out || (ic_out != ic_entrance_out));

  for (unsigned int asy_in = 0 ; (outgoing_in_case) ? (asy_in <= 0) : (asy_in <= 1) ; asy_in++)
    for (unsigned int asy_out = 0 ; (outgoing_out_case) ? (asy_out <= 0) : (asy_out <= 1) ; asy_out++)
      { 
	const complex<double> Sk_projectile = k_projectile_in*minus_one_pow (asy_in) + k_projectile_out*minus_one_pow (asy_out);
	
	if ((inf_norm (Sk_projectile) < precision) && !S_matrix_pole_in && !S_matrix_pole_out) error_message_print_abort ("Complex scaling impossible in CC_scalar_strength_MEs::radial_momentum::radial_integral_calc");
      }

  const complex<double> radial_integral_aft_R = radial_integral_aft_R_calc (CC_state_in , CC_state_out , ic_in , ic_out);

  const complex<double> radial_integral = radial_integral_bef_R + radial_integral_aft_R;
      
#ifdef TYPEisDOUBLECOMPLEX
  return radial_integral;  
#endif
      
#ifdef TYPEisDOUBLE
  return real (radial_integral);  
#endif
}











