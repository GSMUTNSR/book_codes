#include "../CC_include/CC_include_def.h"

using namespace Wigner_signs;



// TYPE is double or complex
// -------------------------




// Calculation of the radial strength function of a scalar operator between channel functions
// ------------------------------------------------------------------------------------------
// One calculates the radial part u[c[out]](r) . r^2 or Id . u[c[in]](r) for all r radii on [0:R], where the radial part reduces to one point (i.e. no integration over r).

void CC_scalar_strength_MEs::radial_momentum::radial_OBMEs_calc (
								 const enum radial_operator_type radial_operator , 
								 const bool is_it_Gauss_Legendre , 
								 const class CC_state_class &CC_state , 
								 const unsigned int ic_in , 
								 const unsigned int ic_out ,  
								 class array<TYPE> &radial_OBMEs)
{
  //--// positions and weights
  const class array<double> &r_bef_R_tab =  (is_it_Gauss_Legendre) ? (CC_state.get_r_bef_R_tab_GL ()) : (CC_state.get_r_bef_R_tab_uniform ());

  //--// tables containing the wfs of all channels
  const class array<complex<double> > &CC_wf_bef_R_tab = (is_it_Gauss_Legendre) ? (CC_state.get_CC_wf_bef_R_tab_GL ()) : (CC_state.get_CC_wf_bef_R_tab_uniform ());

  //--// number of discretization points

  const unsigned int N_bef_R_GL = CC_state.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
  
  radial_OBMEs = 0.0;

  switch (radial_operator)
    {
    case OVERLAP:
      {
	for (unsigned int i = 0 ; i < Nr ; i++)
	  {      
	    const complex<double> CC_wf_bef_R_in_r  = CC_wf_bef_R_tab (ic_in  , i);
	    const complex<double> CC_wf_bef_R_out_r = CC_wf_bef_R_tab (ic_out , i);
	    
#ifdef TYPEisDOUBLECOMPLEX
	    radial_OBMEs(i) = CC_wf_bef_R_in_r * CC_wf_bef_R_out_r;
#endif
      
#ifdef TYPEisDOUBLE
	    radial_OBMEs(i) = real (CC_wf_bef_R_in_r) * real (CC_wf_bef_R_out_r);
#endif
	  }
      } break;

    case R2_RADIAL:
      {
	for (unsigned int i = 0 ; i < Nr ; i++)
	  {
	    const double r = r_bef_R_tab(i);
      
	    const complex<double> CC_wf_bef_R_in_r  = CC_wf_bef_R_tab (ic_in  , i);
	    const complex<double> CC_wf_bef_R_out_r = CC_wf_bef_R_tab (ic_out , i);
	    
#ifdef TYPEisDOUBLECOMPLEX
	    radial_OBMEs(i) = CC_wf_bef_R_in_r * CC_wf_bef_R_out_r * r * r;
#endif
      
#ifdef TYPEisDOUBLE
	    radial_OBMEs(i) = real (CC_wf_bef_R_in_r) * real (CC_wf_bef_R_out_r) * r * r;
#endif
	  }
      } break;

    default: error_message_print_abort ("radial operator is overlap or r^2 in CC_scalar_strength_MEs::radial_momentum::radial_OBMEs_calc");
    }
}



















// Calculation of the momentum strength function of a scalar operator between channel functions
// --------------------------------------------------------------------------------------------
// One calculates the momentum part u[c[out]](k) . u[c[in]](k) for all k momenta on [0:K], where the momentum part reduces to one point (i.e. no integration over k).

void CC_scalar_strength_MEs::radial_momentum::momentum_OBMEs_calc (
								   const bool is_it_Gauss_Legendre , 
								   const class CC_state_class &CC_state , 
								   const unsigned int ic_in , 
								   const unsigned int ic_out ,  
								   class array<TYPE> &momentum_OBMEs)
{
  //--// tables containing the wfs of all channels
  const class array<complex<double> > &CC_wf_momentum_tab = (is_it_Gauss_Legendre) ? (CC_state.get_CC_wf_momentum_tab_GL ()) : (CC_state.get_CC_wf_momentum_tab_uniform ());

  //--// number of discretization points

  const unsigned int Nk_momentum_GL = CC_state.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = CC_state.get_Nk_momentum_uniform ();

  const unsigned int Nk = (is_it_Gauss_Legendre) ? (Nk_momentum_GL) : (Nk_momentum_uniform);
  
  momentum_OBMEs = 0.0;

  for (unsigned int i = 0 ; i < Nk ; i++)
    {      
      const complex<double> CC_wf_momentum_in_k  = CC_wf_momentum_tab (ic_in  , i);
      const complex<double> CC_wf_momentum_out_k = CC_wf_momentum_tab (ic_out , i);
	    
#ifdef TYPEisDOUBLECOMPLEX
      momentum_OBMEs(i) = CC_wf_momentum_in_k * CC_wf_momentum_out_k;
#endif
      
#ifdef TYPEisDOUBLE
      momentum_OBMEs(i) = real (CC_wf_momentum_in_k) * real (CC_wf_momentum_out_k);
#endif
    }
}








