#include "../CC_include/CC_include_def.h"

using namespace string_routines;
using namespace correlated_state_routines;
using namespace inputs_misc;
using namespace A_dagger_cluster_helper;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_H_MEs_cluster;






void CC_potentials_cluster::overlaps_and_H_matrices_cell_calc (
							       const class GSM_vector &V_in , 
							       const class GSM_vector &HV_in , 
							       const enum particle_type projectile_cp , 
							       const int NCM_cp , 
							       const int LCM_projectile_cp , 
							       const class correlated_state_str &PSI_projectile_qn_cp , 
							       const class correlated_state_str &PSI_qn_Tcp , 
							       const unsigned int index_in , 
							       const unsigned int index_out ,
							       const double J ,
							       class array<class GSM_vector> &V_out_tab , 
							       class matrix<complex<double> > &overlaps_matrix , 
							       class matrix<complex<double> > &H_matrix)
{
  const unsigned int this_thread = OpenMP_thread_number_determine ();

  class GSM_vector &V_out = V_out_tab(this_thread);
  
  const class GSM_vector_helper_class &V_out_helper = V_out.get_GSM_vector_helper ();
  
  const double M = V_out_helper.get_M ();
  
  const string A_dagger_PSI_cp_coupled_file_name = PSI_OUT_coupled_to_J_file_name_A_dagger_cluster_CM_relative_determine (false , "A_dagger_cluster" , projectile_cp , NCM_cp , LCM_projectile_cp , PSI_projectile_qn_cp , PSI_qn_Tcp , J , M);
 
  V_out.read_disk (false , false , A_dagger_PSI_cp_coupled_file_name);
  
  const complex<double> overlap = GSM_vector_node_overlap (V_in , V_out);

  const complex<double> H_ME = GSM_vector_node_overlap (HV_in , V_out);

  overlaps_matrix(index_in , index_out) = overlaps_matrix(index_out , index_in) = overlap;

  H_matrix(index_in , index_out) = H_matrix(index_out , index_in) = H_ME;
}











void CC_potentials_cluster::overlaps_and_H_matrices_calc (
							  const bool print_detailed_information ,
							  const class array<class CC_channel_class> &channels_tab , 
							  const class array<enum particle_type> &cluster_projectile_tab ,
							  const class array<class cluster_data> &cluster_projectile_data_tab ,  
							  const double J , 
							  class GSM_vector &V_in , 
							  class GSM_vector &HV_in , 
							  class CC_Hamiltonian_data &CC_H_data)
{  
  const class GSM_vector_helper_class &V_helper = V_in.get_GSM_vector_helper ();
  
  const unsigned int BP = V_helper.get_BP ();

  const unsigned int N_channels = channels_tab.dimension (0);
  
  const double M = V_helper.get_M ();
  
  const double CC_average_n_scat_target_projectile_max = CC_H_data.get_CC_average_n_scat_target_projectile_max ();

  const class array<bool> &is_it_forbidden_channel_tab = CC_H_data.get_is_it_forbidden_channel_tab ();

  const class array<unsigned int> &matrices_indices = CC_H_data.get_matrices_indices ();

  class matrix<complex<double> > &overlaps_matrix_pole_approximation = CC_H_data.get_overlaps_matrix_pole_approximation ();

  class matrix<complex<double> > &H_matrix_pole_approximation = CC_H_data.get_H_matrix_pole_approximation ();

  class matrix<complex<double> > &overlaps_matrix = CC_H_data.get_overlaps_matrix ();

  class matrix<complex<double> > &H_matrix = CC_H_data.get_H_matrix ();

  class array<class GSM_vector> V_out_tab(NUMBER_OF_THREADS);

  for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++) V_out_tab(i_thread).allocate_fill (V_in);

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const int Z_Tc = channel_c.get_Z_Tc ();
      const int N_Tc = channel_c.get_N_Tc ();

      const unsigned int BP_Tc = channel_c.get_BP_Tc ();

      const unsigned int vector_index_Tc = channel_c.get_vector_index_Tc ();

      const complex<double> E_Tc = channel_c.get_E_Tc ();

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const double J_projectile_c = channel_c.get_J_projectile ();

      const double J_Tc = channel_c.get_J_Tc ();	

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const int Z_projectile_c = channel_c.get_Z_projectile ();
      const int N_projectile_c = channel_c.get_N_projectile ();

      const int A_projectile_c = channel_c.get_A_projectile ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const bool S_matrix_pole_Tc = channel_c.get_S_matrix_pole_Tc ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const unsigned int BP_projectile_c = channel_c.get_BP_projectile ();

      const bool S_matrix_pole_projectile_c = channel_c.get_S_matrix_pole_projectile ();

      const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);

      const class nlj_table<bool> &cluster_CM_S_matrix_poles_c = data_c.get_cluster_CM_S_matrix_poles ();

      const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c = data_c.get_Nmax_cluster_projectile_CM_tab ();	

      const int Nmax_cluster_LCM_J_projectile_c = Nmax_cluster_projectile_CM_tab_c(LCM_projectile_c , J_projectile_c);

      const class nlj_table<complex<double> > &cluster_CM_E_tab_c = data_c.get_cluster_CM_E_tab ();

      const class correlated_state_str PSI_qn_Tc(Z_Tc , N_Tc , BP_Tc , J_Tc , vector_index_Tc , E_Tc , NADA , NADA , NADA , false);

      for (int NCM_c = 0 ; NCM_c <= Nmax_cluster_LCM_J_projectile_c ; NCM_c++)  
	{	
	  const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c(NCM_c , LCM_projectile_c , J_projectile_c);

	  const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_tab(ic , NCM_c) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max))
	    {	
	      const complex<double> E_CM_c = cluster_CM_E_tab_c(NCM_c , LCM_projectile_c , J_projectile_c);

	      const class correlated_state_str PSI_projectile_qn_c(Z_projectile_c , N_projectile_c , BP_projectile_c , J_projectile_c , NADA , E_CM_c , NADA , NADA , NADA , false);

	      const bool S_matrix_pole_c = (S_matrix_pole_Tc && S_matrix_pole_NCM_c && S_matrix_pole_projectile_c);
	      
	      const unsigned int index_in = matrices_indices(ic , NCM_c);

	      const string   A_dagger_cluster_PSI_c_coupled_file_name = PSI_OUT_coupled_to_J_file_name_A_dagger_cluster_CM_relative_determine (false ,   "A_dagger_cluster" , projectile_c , NCM_c , LCM_projectile_c , PSI_projectile_qn_c , PSI_qn_Tc , J , M);
	      const string H_A_dagger_cluster_PSI_c_coupled_file_name = PSI_OUT_coupled_to_J_file_name_A_dagger_cluster_CM_relative_determine (false , "H_A_dagger_cluster" , projectile_c , NCM_c , LCM_projectile_c , PSI_projectile_qn_c , PSI_qn_Tc , J , M);

	      V_in.read_disk  (false , false ,   A_dagger_cluster_PSI_c_coupled_file_name);
	      HV_in.read_disk (false , false , H_A_dagger_cluster_PSI_c_coupled_file_name);

	      for (unsigned int icp = 0 ; icp <= ic ; icp++)
		{
		  const class CC_channel_class &channel_cp = channels_tab(icp);

		  const int Z_Tcp = channel_cp.get_Z_Tc ();
		  const int N_Tcp = channel_cp.get_N_Tc ();

		  const unsigned int BP_Tcp = channel_cp.get_BP_Tc ();

		  const unsigned int vector_index_Tcp = channel_cp.get_vector_index_Tc ();

		  const complex<double> E_Tcp = channel_cp.get_E_Tc ();

		  const complex<double> average_n_scat_Tcp = channel_cp.get_average_n_scat_Tc ();

		  const double J_projectile_cp = channel_cp.get_J_projectile ();

		  const double J_Tcp = channel_cp.get_J_Tc ();

		  const enum particle_type projectile_cp = channel_cp.get_projectile ();

		  const int Z_projectile_cp = channel_cp.get_Z_projectile ();
		  const int N_projectile_cp = channel_cp.get_N_projectile ();
		  const int A_projectile_cp = channel_cp.get_A_projectile ();

		  const int LCM_projectile_cp = channel_cp.get_LCM_projectile ();

		  const bool S_matrix_pole_Tcp = channel_cp.get_S_matrix_pole_Tc ();

		  const double real_average_n_scat_Tcp = real (average_n_scat_Tcp);

		  const unsigned int BP_projectile_cp = channel_cp.get_BP_projectile ();

		  const bool S_matrix_pole_projectile_cp = channel_cp.get_S_matrix_pole_projectile ();

		  const class cluster_data &data_cp = get_cluster_projectile_data (projectile_cp , cluster_projectile_data_tab);

		  const complex<double> E_intrinsic_cp = data_cp.get_E_intrinsic_cluster ();

		  const class lj_table<int> &Nmax_cluster_projectile_CM_tab_cp = data_cp.get_Nmax_cluster_projectile_CM_tab ();	

		  const int Nmax_cluster_LCM_J_projectile_cp = Nmax_cluster_projectile_CM_tab_cp(LCM_projectile_cp , J_projectile_cp);

		  const int NCM_max_LCM_J_cp_NCM_c = (icp < ic) ? (Nmax_cluster_LCM_J_projectile_cp) : (NCM_c);

		  const class nlj_table<complex<double> > &cluster_CM_E_tab_cp = data_cp.get_cluster_CM_E_tab ();

		  const class nlj_table<bool> &cluster_CM_S_matrix_poles_cp = data_cp.get_cluster_CM_S_matrix_poles ();

		  const class correlated_state_str PSI_qn_Tcp(Z_Tcp , N_Tcp , BP_Tcp , J_Tcp , vector_index_Tcp , E_Tcp , NADA , NADA , NADA , false);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
		  for (int NCM_cp = 0 ; NCM_cp <= NCM_max_LCM_J_cp_NCM_c ; NCM_cp++) 
		    {
		      const bool S_matrix_pole_NCM_cp = cluster_CM_S_matrix_poles_cp(NCM_cp , LCM_projectile_cp , J_projectile_cp);

		      const double real_average_n_scat_cp = (!S_matrix_pole_NCM_cp) ? (real_average_n_scat_Tcp + A_projectile_cp) : (real_average_n_scat_Tcp);

		      if (!is_it_forbidden_channel_tab(icp , NCM_cp) && (real_average_n_scat_cp <= CC_average_n_scat_target_projectile_max))
			{
			  const complex<double> E_CM_cp = cluster_CM_E_tab_cp(NCM_cp , LCM_projectile_cp , J_projectile_cp);

			  const complex<double> E_projectile_cp = E_intrinsic_cp + E_CM_cp;

			  const class correlated_state_str PSI_projectile_qn_cp(Z_projectile_cp , N_projectile_cp , BP_projectile_cp , J_projectile_cp , NADA , E_projectile_cp , NADA , NADA , NADA , false);
			  
			  const bool S_matrix_pole_cp = (S_matrix_pole_Tcp && S_matrix_pole_NCM_cp && S_matrix_pole_projectile_cp);

			  const unsigned int index_out = matrices_indices(icp , NCM_cp);

			  if (S_matrix_pole_c && S_matrix_pole_cp)
			    overlaps_and_H_matrices_cell_calc (V_in , HV_in , projectile_cp , NCM_cp , LCM_projectile_cp , PSI_projectile_qn_cp , PSI_qn_Tcp ,
							       index_in , index_out , J , V_out_tab , overlaps_matrix_pole_approximation , H_matrix_pole_approximation);
			  
			  overlaps_and_H_matrices_cell_calc (V_in , HV_in , projectile_cp , NCM_cp , LCM_projectile_cp , PSI_projectile_qn_cp , PSI_qn_Tcp , index_in , index_out , J , V_out_tab , overlaps_matrix , H_matrix);
			}
		    }
		}
	    }
	}

      if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << "Files read for overlap and H matrices in channel " << channel_c << endl;
    }
      
#ifdef UseMPI
  
  CC_H_data.H_overlaps_matrices_MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
#endif

  CC_H_data.cluster_corrective_factors_modification (channels_tab , cluster_projectile_tab , cluster_projectile_data_tab);  
  
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      CC_H_data.H_overlaps_matrices_copy_disk (BP , J);

      cout << endl;
    }
}







void CC_potentials_cluster::potentials_overlaps_calc (
						      const class input_data_str &input_data , 
						      const bool are_GSM_a_dagger_vectors_calculated , 
						      const class array<class CC_channel_class> &channels_tab , 
						      const class array<class cluster_data> &cluster_projectile_data_tab , 
						      const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
						      const double J , 
						      const double M , 
						      const unsigned int BP , 
						      class nucleons_data &prot_data , 
						      class nucleons_data &neut_data , 
						      class TBMEs_class &TBMEs_pn , 
						      class CC_Hamiltonian_data &CC_H_data)
{
  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
    
  const bool print_detailed_information = input_data.get_print_detailed_information ();

  const double CC_average_n_scat_target_projectile_max = CC_H_data.get_CC_average_n_scat_target_projectile_max ();
  
  const int n_holes_max_p = prot_data.get_n_holes_max ();
  const int n_holes_max_n = neut_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_data.get_n_scat_max ();
  const int n_scat_max_n = neut_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_data.get_E_max_hw ();
  const int En_max_hw = neut_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();

  const int two_J = make_int (2.0*J);
  
  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage ();

  const enum storage_type one_jumps_pn_storage = input_data.get_one_jumps_pn_storage ();
  
  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();

  const class array<double> &CC_corrective_factors_TBMEs_tab = CC_H_data.get_CC_corrective_factors_TBMEs_tab ();

  const class array<enum particle_type> &cluster_projectile_tab = input_data.get_CC_cluster_projectile_tab ();

  const double CC_forbidden_channel_precision = input_data.get_CC_forbidden_channel_precision ();

  class array<bool> &is_it_forbidden_channel_tab = CC_H_data.get_is_it_forbidden_channel_tab ();

  if (are_GSM_a_dagger_vectors_calculated) 
    {
      const double CC_corrective_factor_TBME = CC_corrective_factors_TBMEs_tab(BP , two_J);

      corrective_factor_TBMEs_modification (space , CC_corrective_factor_TBME , prot_data , neut_data , TBMEs_pn);
      
      const double Mp1 = M + 1.0;

      class GSM_vector_helper_class GSM_vector_helper_M(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
							n_holes_max   , n_scat_max   , E_max_hw ,
							n_holes_max_p , n_scat_max_p , Ep_max_hw ,
							n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , true , prot_data , neut_data);
      
      class GSM_vector_helper_class GSM_vector_helper_Mp1(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
							  n_holes_max   , n_scat_max   , E_max_hw ,
							  n_holes_max_p , n_scat_max_p , Ep_max_hw ,
							  n_holes_max_n , n_scat_max_n , En_max_hw , BP , Mp1 , true , prot_data , neut_data);
      
      const class GSM_vector_helper_class dummy_helper;

      class GSM_vector V_in (GSM_vector_helper_M);
      class GSM_vector V_out(GSM_vector_helper_M);

      class GSM_vector PSI0_M(GSM_vector_helper_M);
      class GSM_vector PSI1_M(GSM_vector_helper_M);

      class GSM_vector PSI0_Mp1(GSM_vector_helper_Mp1);
      class GSM_vector PSI1_Mp1(GSM_vector_helper_Mp1);
      class GSM_vector PSI2_Mp1(GSM_vector_helper_Mp1);

      class array<class GSM_vector> V_tab(NUMBER_OF_THREADS);

      for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) V_tab(i).allocate (GSM_vector_helper_M);

      class GSM_vector PSI_full;
  	
      const class Jpm_class Jplus( true , print_detailed_information ,  1 , Hamiltonian_storage , true , GSM_vector_helper_M   , GSM_vector_helper_Mp1 , PSI_full , PSI0_Mp1 , PSI1_Mp1);
      const class Jpm_class Jminus(true , print_detailed_information , -1 , Hamiltonian_storage , true , GSM_vector_helper_Mp1 , GSM_vector_helper_M   , PSI_full , PSI0_M   , PSI1_M);
		 
      const class J2_class J2(Jplus , Jminus , PSI2_Mp1);

      const class CM_operator_class Hcm(HCM , true , J , true , GSM_vector_helper_M , GSM_vector_helper_M , PSI_full);
      
      if (inter == REALISTIC_INTERACTION)
	{
	  CC_H_A_dagger_cluster_forbidden_channels_no_core::A_dagger_calculations_and_copy_disk (print_detailed_information , channels_tab , cluster_projectile_data_tab , J , J2 , Hcm , V_in , V_out);
	  
	  CC_H_A_dagger_cluster_forbidden_channels_no_core::is_it_forbidden_channel_tab_calc (print_detailed_information , CC_forbidden_channel_precision , channels_tab , cluster_projectile_data_tab , J , V_in , is_it_forbidden_channel_tab);
	}
      else
	{
	  CC_H_A_dagger_cluster_forbidden_channels::A_dagger_calculations_and_copy_disk (print_detailed_information , CC_average_n_scat_target_projectile_max ,
											 full_common_vectors_used_in_file , channels_tab , cluster_projectile_data_tab , J , J2 , V_in , V_out);

	  CC_H_A_dagger_cluster_forbidden_channels::is_it_forbidden_channel_tab_calc (print_detailed_information , CC_average_n_scat_target_projectile_max , CC_forbidden_channel_precision ,
										      channels_tab , cluster_projectile_data_tab , J , V_in , is_it_forbidden_channel_tab);
	}

      CC_H_data.dimensions_matrices_cluster_calc (channels_tab , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab);

      CC_H_data.dimension_matrices_dependent_data_realloc_init ();

      CC_H_data.all_matrices_indices_cluster_calc (channels_tab , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab);

      CC_H_data.is_it_forbidden_channel_CC_Berggren_tab_cluster_determine (channels_tab , cluster_projectile_data_tab);

      const class H_class H(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage , true , false , false , TBMEs_pn ,
			    true , true , true , true , true , J , GSM_vector_helper_M , PSI_full , PSI0_M , PSI1_M , V_tab);
      
      if (inter == REALISTIC_INTERACTION)
	CC_H_A_dagger_cluster_forbidden_channels_no_core::H_A_dagger_calculations_and_copy_disk (print_detailed_information , channels_tab , cluster_projectile_data_tab , is_it_forbidden_channel_tab , J , J2 , Hcm , H , V_in , V_out);
      else
	CC_H_A_dagger_cluster_forbidden_channels::H_A_dagger_calculations_and_copy_disk (print_detailed_information , CC_average_n_scat_target_projectile_max ,
											 channels_tab , cluster_projectile_data_tab , is_it_forbidden_channel_tab , J , J2 , H , V_in , V_out);
	

      // Berggren basis matrix elements [index_in \equiv (ic , nc) -> in the comments , we'll write (ic , nc)]:
      // -------------------------------------------------------------------------------------------------
      // overlaps_matrix (ic , nc ; icp , ncp) = <a+_{nc , lc , jc} \Psi_c | a+_{ncp , lcp , jcp} \Psi_cp>
      // H_matrix (ic , nc ; icp , ncp) = <a+_{nc , lc , jc} \Psi_c | H | a+_{ncp , lcp , jcp} \Psi_cp>

      overlaps_and_H_matrices_calc (print_detailed_information , channels_tab , cluster_projectile_tab , cluster_projectile_data_tab , J , V_in , V_out , CC_H_data);      
    }
  else
    {
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  const string is_it_forbidden_channel_tab_file_name = file_name_J_Pi_string ("CC_is_it_forbidden_channel_tab" , BP , J);

	  is_it_forbidden_channel_tab.read_disk (is_it_forbidden_channel_tab_file_name);
	}

#ifdef UseMPI
      is_it_forbidden_channel_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif

      CC_H_data.dimensions_matrices_cluster_calc (channels_tab , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab);

      CC_H_data.dimension_matrices_dependent_data_realloc_init ();

      CC_H_data.all_matrices_indices_cluster_calc (channels_tab , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab);

      CC_H_data.is_it_forbidden_channel_CC_Berggren_tab_cluster_determine (channels_tab , cluster_projectile_data_tab);

      if (THIS_PROCESS == MASTER_PROCESS) CC_H_data.H_overlaps_matrices_read_from_file (BP , J);

#ifdef UseMPI
      CC_H_data.H_overlaps_matrices_MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
    }

  CC_H_data.PCM_function_HO_matrices_cluster_calc (channels_tab , cluster_projectile_data_tab);

  CC_H_data.finite_range_overlaps_potential_Ho_HO_matrices_cluster_calc (channels_tab , cluster_projectile_data_tab);

  CC_H_data.overlaps_H_HO_matrices_calc ();

  CC_H_data.Delta_H_HO_matrices_cluster_calc (channels_tab , cluster_projectile_data_tab);

  // HO submatrices filling:
  // -----------------------
  CC_H_data.HO_submatrices_cluster_fill (channels_tab , cluster_projectile_data_tab);

  // orthogonalized_H_matrix_Berggren calculation
  CC_H_data.orthogonalized_H_matrix_CC_Berggren_cluster_calc (channels_tab , cluster_projectile_data_CC_Berggren_tab);

  // Quick tests: Diagonalization of some matrices
  if (print_detailed_information) CC_H_data.overlaps_H_matrices_diagonalization_test (BP , J);

  if (are_GSM_a_dagger_vectors_calculated) 
    {		
      const double CC_corrective_factor_TBME = CC_corrective_factors_TBMEs_tab(BP , two_J);

      const double CC_corrective_factor_TBME_inv = 1.0/CC_corrective_factor_TBME;

      corrective_factor_TBMEs_modification (space , CC_corrective_factor_TBME_inv , prot_data , neut_data , TBMEs_pn);
    }
}








void CC_potentials_cluster::potential_diagonal_init (
						     const bool is_it_entrance_channel_only , 
						     class array<complex<double> > &Ueq_tab , 
						     const class CC_state_class &CC_state , 
						     const class array<class cluster_data> &cluster_projectile_data_tab)
{
  const class array<class CC_channel_class> &channels_tab = CC_state.get_channels_tab ();

  const unsigned int N_channels = CC_state.get_N_channels ();

  const unsigned int N_bef_R_uniform = CC_state.get_N_bef_R_uniform ();

  const unsigned int ic_entrance = CC_state.get_ic_entrance ();

  const unsigned int first_ir = basic_first_index_determine_for_MPI (N_bef_R_uniform , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_ir = basic_last_index_determine_for_MPI (N_bef_R_uniform , NUMBER_OF_PROCESSES , THIS_PROCESS); 
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      if (!is_it_entrance_channel_only || (ic == ic_entrance))
	{
	  const class CC_channel_class &channel_c = channels_tab(ic);

	  const enum particle_type projectile_c = channel_c.get_projectile ();

	  const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);

	  const int LCM_projectile_c = channel_c.get_LCM_projectile ();

	  const double J_projectile_c = channel_c.get_J_projectile ();

	  const class lj_table<double> &potential_cluster_CM_bef_R_tab_uniform = data_c.get_potential_cluster_CM_bef_R_tab_uniform ();

	  for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
	    {
	      if ((i >= first_ir) && (i <= last_ir))
		Ueq_tab(ic , ic , i) += potential_cluster_CM_bef_R_tab_uniform(LCM_projectile_c , J_projectile_c , i);
	    }
	  
	  if (first_ir == 0)
	    Ueq_tab(ic , ic , 0) = 2.0*Ueq_tab(ic , ic , 1) - Ueq_tab(ic , ic , 2);
	}
    }
}












void CC_potentials_cluster::Ueq_source_calc (
					     const bool is_it_entrance_channel_only_iterative , 
					     const bool is_it_entrance_channel_only , 
					     const bool is_it_symmetrized , 
					     const double new_potential_fraction , 
					     const class CC_state_class &CC_state , 
					     const class array<class cluster_data> &cluster_projectile_data_tab , 
					     class CC_Hamiltonian_data &CC_H_data)
{
  const unsigned int N_channels = CC_state.get_N_channels ();

  const unsigned int N_bef_R_uniform = CC_state.get_N_bef_R_uniform ();

  const unsigned int ic_entrance = CC_state.get_ic_entrance ();

  const double R_cut_function = CC_H_data.get_R_cut_function ();
  const double d_cut_function = CC_H_data.get_d_cut_function ();

  const double Ueq_regularizor = CC_H_data.get_Ueq_regularizor ();

  const class array<class CC_channel_class> &channels_tab = CC_state.get_channels_tab ();

  const class array<complex<double> > &CC_wf_bef_R_tab_uniform  = CC_state.get_CC_wf_bef_R_tab_uniform ();
  const class array<complex<double> > &CC_dwf_bef_R_tab_uniform = CC_state.get_CC_dwf_bef_R_tab_uniform ();

  const class array<complex<double> > &CC_asymptotic_in_zero_wf_bef_R_tab_uniform = CC_state.get_CC_asymptotic_in_zero_wf_bef_R_tab_uniform (); 

  const class array<double> &r_bef_R_tab_uniform = CC_state.get_r_bef_R_tab_uniform ();

  const class array<class vector_class<complex<double> > > &HO_overlaps_Fermi = CC_state.get_HO_overlaps_Fermi ();

  const class array<double> &HO_wfs_bef_R_tab_uniform = CC_H_data.get_HO_wfs_bef_R_tab_uniform ();

  class array<complex<double> > &Ueq_tab = CC_H_data.get_Ueq_tab ();

  class array<complex<double> > &source_tab = CC_H_data.get_source_tab ();

  class array<complex<double> > Ueq_tab_new = Ueq_tab;

  class array<complex<double> > source_tab_new = source_tab;
  
  Ueq_tab_new = 0.0;

  source_tab_new = 0.0;

  // Initialization of the part coming from the local hamiltonian
  potential_diagonal_init (is_it_entrance_channel_only , Ueq_tab_new , CC_state , cluster_projectile_data_tab);
  
  const unsigned int first_ir = basic_first_index_determine_for_MPI (N_bef_R_uniform , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_ir = basic_last_index_determine_for_MPI (N_bef_R_uniform , NUMBER_OF_PROCESSES , THIS_PROCESS); 

  // Calculation of the part coming from non-local matrix elements

  const class array<class matrix<complex<double> > > &finite_range_orthogonalized_potential_HO_submatrices = CC_H_data.get_finite_range_orthogonalized_potential_HO_submatrices ();

  if (!is_it_entrance_channel_only_iterative)
    {
      // Calculation of the part coming from non-local matrix elements
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  if (!is_it_entrance_channel_only || (ic == ic_entrance))
	    {
	      const class CC_channel_class &channel_c = channels_tab(ic);

	      const enum particle_type projectile_c = channel_c.get_projectile ();

	      const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);

	      const class array<int> &Nmax_HO_tab_c = data_c.get_Nmax_HO_tab ();

	      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

	      const int Nmax_HO_LCM_projectile_c = Nmax_HO_tab_c(LCM_projectile_c);

	      for (unsigned int icp = 0 ; icp < N_channels ; icp++)
		{
		  if (!is_it_entrance_channel_only || (icp == ic_entrance))
		    {
		      const class vector_class<complex<double> > &HO_overlaps_Fermi_cp = HO_overlaps_Fermi(icp); 

		      const class matrix<complex<double> > &finite_range_orthogonalized_potential_HO_submatrix_c_cp = finite_range_orthogonalized_potential_HO_submatrices(ic , icp);

		      const class vector_class<complex<double> > HO_MEs_Uccp_ucp = finite_range_orthogonalized_potential_HO_submatrix_c_cp*HO_overlaps_Fermi_cp;
		  
		      if (HO_MEs_Uccp_ucp.infinite_norm () != 0.0)
			{
			  for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
			    {
			      if ((i >= first_ir) && (i <= last_ir))
				{
				  const double r = r_bef_R_tab_uniform(i);

				  complex<double> Uccp_ucp_r = 0.;

				  for (int NCM_HO_c = 0 ; NCM_HO_c <= Nmax_HO_LCM_projectile_c ; NCM_HO_c++) Uccp_ucp_r += HO_wfs_bef_R_tab_uniform(ic , NCM_HO_c , i)*HO_MEs_Uccp_ucp(NCM_HO_c);
				  
				  Uccp_ucp_r *= Fermi_like_function (R_cut_function , d_cut_function , r);

				  const complex<double> asymptotic_value_cp_r = CC_asymptotic_in_zero_wf_bef_R_tab_uniform(icp , i);

				  const complex<double> wfcp_r  = CC_wf_bef_R_tab_uniform(icp , i);
				  const complex<double> dwfcp_r = CC_dwf_bef_R_tab_uniform(icp , i);

				  const double exp_term_1 = exp (-Ueq_regularizor * norm (wfcp_r) / norm (dwfcp_r));
				  const double exp_term_2 = exp (-Ueq_regularizor * norm (asymptotic_value_cp_r/wfcp_r - 1.));

				  const double Fcp = exp_term_1 * (1. - exp_term_2);
				  
				  const complex<double> Uccp_ucp_r_Fcp = Uccp_ucp_r*Fcp;

				  const complex<double> Ueq_part = (Uccp_ucp_r - Uccp_ucp_r_Fcp) / wfcp_r;

				  Ueq_tab_new(ic , icp , i) += Ueq_part;

				  source_tab_new(ic , i) += Uccp_ucp_r_Fcp;
				}}}}}}
	}
      
      // Symmetrization of the equivalent potential
      if (is_it_symmetrized)
	{
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
	  for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++) 
	    {
	      if ((i >= first_ir) && (i <= last_ir))
		{
		  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
		    {
		      if (!is_it_entrance_channel_only || (ic == ic_entrance))
			{
			  const complex<double> asymptotic_value_c_r = CC_asymptotic_in_zero_wf_bef_R_tab_uniform(ic , i);

			  const complex<double> wfc_r  = CC_wf_bef_R_tab_uniform(ic , i);
			  const complex<double> dwfc_r = CC_dwf_bef_R_tab_uniform(ic , i);
			  
			  const double exp_term_1 = exp (-Ueq_regularizor * norm (wfc_r) / norm (dwfc_r));
			  const double exp_term_2 = exp (-Ueq_regularizor * norm (asymptotic_value_c_r/wfc_r - 1.0));

			  const double Fc = exp_term_1 * (1.0 - exp_term_2);

			  const complex<double> one_minus_Fc_wfc_ratio = (1.0 - Fc)/wfc_r;

			  for (unsigned int icp = 0 ; icp < N_channels ; icp++)
			    {
			      if ((icp != ic) && ((!is_it_entrance_channel_only || (icp == ic_entrance))))
				{
				  const complex<double> wfcp_r = CC_wf_bef_R_tab_uniform(icp , i);
				  
				  const complex<double> Ueq_pots_half_diff_wfcp_r = 0.5 * (Ueq_tab_new(ic , icp , i) - Ueq_tab_new(icp , ic , i)) * wfcp_r;

				  Ueq_tab_new(ic , ic , i) += Ueq_pots_half_diff_wfcp_r * one_minus_Fc_wfc_ratio;

				  source_tab_new(ic , i) += Ueq_pots_half_diff_wfcp_r * Fc;
				}}}}
		}

	      for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
		{
		  if (!is_it_entrance_channel_only || (ic == ic_entrance))
		    {
		      for (unsigned int icp = 0 ; icp < ic ; icp++)
			{
			  if (!is_it_entrance_channel_only || (icp == ic_entrance))
			    {
			      Ueq_tab_new(ic , icp , i) = 0.5 * (Ueq_tab_new(ic , icp , i) + Ueq_tab_new(icp , ic , i));

			      Ueq_tab_new(icp , ic , i) = Ueq_tab_new(ic , icp , i); 
			    }}}}}}
    }
  else
    {
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  if (ic != ic_entrance)
	    {
	      for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++) 
		{
		  if ((i >= first_ir) && (i <= last_ir))
		    Ueq_tab_new(ic , ic_entrance , i) = 0.1*Ueq_tab_new(ic_entrance , ic_entrance , i);
		}
	    }
	}
    }
  
  // Calculation of the equivalent potential and source at r=0
  if (first_ir == 0)
    {
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	    Ueq_tab_new(ic , icp , 0) = 2.0*Ueq_tab_new(ic , icp , 1) - Ueq_tab_new(ic , icp , 2);

	  source_tab_new(ic , 0) = 0.0;
	}
    }
  
#ifdef UseMPI

  if (is_it_MPI_parallelized)
    {
      Ueq_tab_new.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);

      source_tab_new.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
    }
  
#endif
    
  Ueq_source_averaged_calc (new_potential_fraction , Ueq_tab_new , source_tab_new , Ueq_tab , source_tab);
}







