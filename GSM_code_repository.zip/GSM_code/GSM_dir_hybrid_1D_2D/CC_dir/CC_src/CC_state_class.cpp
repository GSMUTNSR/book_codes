#include "../CC_include/CC_include_def.h"

using namespace inputs_misc;
using namespace string_routines;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;


CC_state_class::CC_state_class () :
  are_there_scaled_wfs (false) ,
  N_channels (0) ,
  ic_entrance (0) , 
  R (0.0) , 
  matching_point (0.0) , 
  R0 (0.0) , 
  R_max (0.0) , 
  kmax_momentum (0.0) ,
  R_Fermi_momentum (0.0) ,
  N_bef_R_uniform (0) , 
  N_aft_R_uniform (0) , 
  N_bef_R_GL (0) , 
  N_aft_R_GL (0) , 
  Nk_momentum_uniform (0) ,
  Nk_momentum_GL (0) ,
  step_bef_R_uniform (0.0) ,
  step_aft_R_uniform (0.0) ,
  step_momentum_uniform (0.0) ,
  N_bef_mp_uniform (0) , 
  N_aft_mp_uniform (0) , 
  A (0) , 
  nmax_HO_local_plus_one (0) , 
  R_HO_end (0.0) , 
  J (0.0) ,
  M (0.0) , 
  BP (2) , 
  n (0) , 
  S_matrix_pole (false) ,
  is_it_HO_projected (false) , 
  N_bef_mp_GL (0) ,
  N_aft_mp_GL (0) ,
  N_bef_mp_GL_SGI_MSGI (0) ,
  N_aft_mp_GL_SGI_MSGI (0) ,
  E (0.0) , 
  Cminus_entrance_channel (0.0) ,
  is_E_ok (false)
{}



CC_state_class::CC_state_class (
				const bool is_it_one_nucleon_COSM_case , 
				const class array<int> &nmax_HO_lab_tab , 
				const class array<class cluster_data> &cluster_projectile_data_tab ,
				const bool S_matrix_pole_c , 
				const bool are_there_scaled_wfs_c , 
				const unsigned int N_channels_c , 
				const unsigned int ic_entrance_c , 
				const class array<class CC_channel_class> &channels_tab_c , 
				const unsigned int N_bef_R_uniform_c ,
				const unsigned int N_aft_R_uniform_c ,  
				const unsigned int N_bef_R_GL_c , 
				const unsigned int N_aft_R_GL_c , 
				const unsigned int Nk_momentum_uniform_c , 
				const unsigned int Nk_momentum_GL_c , 
				const double R_c , 
				const double R0_c , 
				const double R_real_max_c , 
				const double kmax_momentum_c , 
				const double R_Fermi_momentum_c , 
				const int A_c , 
				const unsigned int BP_c , 
				const double J_c , 
				const double M_c , 
				const int n_c , 
				const complex<double> &E_c) :
  are_there_scaled_wfs (false) ,
  N_channels (0) ,
  ic_entrance (0) , 
  R (0.0) , 
  matching_point (0.0) , 
  R0 (0.0) , 
  R_max (0.0) , 
  kmax_momentum (0.0) ,
  R_Fermi_momentum (0.0) ,
  N_bef_R_uniform (0) , 
  N_aft_R_uniform (0) , 
  N_bef_R_GL (0) , 
  N_aft_R_GL (0) , 
  Nk_momentum_uniform (0) ,
  Nk_momentum_GL (0) ,
  step_bef_R_uniform (0.0) ,
  step_aft_R_uniform (0.0) ,
  step_momentum_uniform (0.0) ,
  N_bef_mp_uniform (0) , 
  N_aft_mp_uniform (0) , 
  A (0) , 
  nmax_HO_local_plus_one (0) , 
  R_HO_end (0.0) , 
  J (0.0) ,
  M (0.0) , 
  BP (2) , 
  n (0) , 
  S_matrix_pole (false) ,
  is_it_HO_projected (false) , 
  N_bef_mp_GL (0) ,
  N_aft_mp_GL (0) ,
  N_bef_mp_GL_SGI_MSGI (0) ,
  N_aft_mp_GL_SGI_MSGI (0) ,
  E (0.0) , 
  Cminus_entrance_channel (0.0) ,
  is_E_ok (false)
{
  allocate (is_it_one_nucleon_COSM_case , nmax_HO_lab_tab , cluster_projectile_data_tab ,S_matrix_pole_c , are_there_scaled_wfs_c ,
	    N_channels_c , ic_entrance_c , channels_tab_c , N_bef_R_uniform_c , N_aft_R_uniform_c , N_bef_R_GL_c , N_aft_R_GL_c , Nk_momentum_uniform_c , Nk_momentum_GL_c ,  
	    R_c , R0_c , R_real_max_c , kmax_momentum_c , R_Fermi_momentum_c , A_c , BP_c , J_c , M_c , n_c , E_c);
}



CC_state_class::CC_state_class (const class CC_state_class &X) :
  are_there_scaled_wfs (false) ,
  N_channels (0) ,
  ic_entrance (0) , 
  R (0.0) , 
  matching_point (0.0) , 
  R0 (0.0) , 
  R_max (0.0) , 
  kmax_momentum (0.0) ,
  R_Fermi_momentum (0.0) ,
  N_bef_R_uniform (0) , 
  N_aft_R_uniform (0) , 
  N_bef_R_GL (0) , 
  N_aft_R_GL (0) , 
  Nk_momentum_uniform (0) ,
  Nk_momentum_GL (0) ,
  step_bef_R_uniform (0.0) ,
  step_aft_R_uniform (0.0) ,
  step_momentum_uniform (0.0) ,
  N_bef_mp_uniform (0) , 
  N_aft_mp_uniform (0) , 
  A (0) , 
  nmax_HO_local_plus_one (0) , 
  R_HO_end (0.0) , 
  J (0.0) ,
  M (0.0) , 
  BP (2) , 
  n (0) , 
  S_matrix_pole (false) ,
  is_it_HO_projected (false) , 
  N_bef_mp_GL (0) ,
  N_aft_mp_GL (0) ,
  N_bef_mp_GL_SGI_MSGI (0) ,
  N_aft_mp_GL_SGI_MSGI (0) ,
  E (0.0) , 
  Cminus_entrance_channel (0.0) ,
  is_E_ok (false)
{
  allocate_fill (X);
}



void CC_state_class::allocate (
			       const bool is_it_one_nucleon_COSM_case , 
			       const class array<int> &nmax_HO_lab_tab , 
			       const class array<class cluster_data> &cluster_projectile_data_tab , 
			       const bool S_matrix_pole_c , 
			       const bool are_there_scaled_wfs_c , 
			       const unsigned int N_channels_c , 
			       const unsigned int ic_entrance_c , 
			       const class array<class CC_channel_class> &channels_tab_c , 
			       const unsigned int N_bef_R_uniform_c , 
			       const unsigned int N_aft_R_uniform_c , 
			       const unsigned int N_bef_R_GL_c , 
			       const unsigned int N_aft_R_GL_c , 
			       const unsigned int Nk_momentum_uniform_c , 
			       const unsigned int Nk_momentum_GL_c , 
			       const double R_c , 
			       const double R0_c , 
			       const double R_real_max_c , 
			       const double kmax_momentum_c , 
			       const double R_Fermi_momentum_c , 
			       const int A_c , 
			       const unsigned int BP_c , 
			       const double J_c , 
			       const double M_c , 
			       const int n_c , 
			       const complex<double> &E_c)
{
  are_there_scaled_wfs = are_there_scaled_wfs_c; 

  N_channels = N_channels_c; 

  ic_entrance = ic_entrance_c; 

  R = R_c; 

  matching_point = R0_c; 

  R0 = R0_c; 

  R_max = R_real_max_c; 

  kmax_momentum = kmax_momentum_c;

  R_Fermi_momentum = R_Fermi_momentum_c;
  
  N_bef_R_uniform = N_bef_R_uniform_c; 
  N_aft_R_uniform = N_aft_R_uniform_c; 

  N_bef_R_GL = N_bef_R_GL_c; 
  N_aft_R_GL = N_aft_R_GL_c; 

  Nk_momentum_uniform = Nk_momentum_uniform_c;
  
  Nk_momentum_GL = Nk_momentum_GL_c;
				 
  step_bef_R_uniform = R/static_cast<double> (N_bef_R_uniform - 1); 

  step_aft_R_uniform = pow (R , -0.25)/static_cast<double> (N_aft_R_uniform - 1);

  step_momentum_uniform = kmax_momentum/static_cast<double> (Nk_momentum_uniform - 1);

  N_bef_mp_uniform = make_uns_int (floor (matching_point/step_bef_R_uniform)) + 1; 

  N_aft_mp_uniform = N_bef_R_uniform - N_bef_mp_uniform; 

  A = A_c; 

  nmax_HO_local_plus_one = 16; 

  R_HO_end = 50.; 

  J = J_c; 
  M = M_c; 

  BP = BP_c; 

  n = n_c; 

  S_matrix_pole = S_matrix_pole_c; 

  is_it_HO_projected = false; 

  E = E_c; 

  Cminus_entrance_channel = (S_matrix_pole) ? (0.0) : (1.0); 

  is_E_ok = (E != 0.0);

  // Channel class
  channels_tab.allocate_fill (channels_tab_c);

  //--// discretization of r (before R)

  r_bef_R_tab_uniform.allocate (N_bef_R_uniform);

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;

  k_tab_uniform.allocate (Nk_momentum_uniform);

  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++) k_tab_uniform(i) = i*step_momentum_uniform;

  r_bef_R_tab_GL.allocate (N_bef_R_GL);
  w_bef_R_tab_GL.allocate (N_bef_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);

  k_tab_GL.allocate  (Nk_momentum_GL);
  wk_tab_GL.allocate (Nk_momentum_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , kmax_momentum , k_tab_GL , wk_tab_GL);

  unsigned int iGL = 0;

  while ((iGL < N_bef_R_GL) && (r_bef_R_tab_GL(iGL) <= matching_point))
    {
      iGL++;
    }

  N_bef_mp_GL = iGL;

  N_aft_mp_GL = N_bef_R_GL - N_bef_mp_GL;

  r_bef_R_tab_GL_SGI_MSGI.allocate (N_bef_R_GL); // This set goes from 0 to 2.R0. R0 must be equal to matching_point.
  w_bef_R_tab_GL_SGI_MSGI.allocate (N_bef_R_GL); // This set goes from 0 to 2.R0. R0 must be equal to matching_point.

  const double R_SGI_MSGI = 2. * R0;

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R_SGI_MSGI , r_bef_R_tab_GL_SGI_MSGI , w_bef_R_tab_GL_SGI_MSGI);

  unsigned int iGL_SGI_MSGI = 0;

  while ((iGL_SGI_MSGI < N_bef_R_GL) && (r_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) <= matching_point))
    {
      iGL_SGI_MSGI++;
    }

  N_bef_mp_GL_SGI_MSGI = iGL_SGI_MSGI;

  N_aft_mp_GL_SGI_MSGI = N_bef_R_GL - N_bef_mp_GL_SGI_MSGI;

  //--// discretization of r (after R)
  r_aft_R_tab_GL_real.allocate (N_aft_R_GL);
  w_aft_R_tab_GL_real.allocate (N_aft_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (R , R_max , r_aft_R_tab_GL_real , w_aft_R_tab_GL_real);

  const double R_pow_minus_0p25 = pow (R , - 0.25);

  class array<double> u_aft_R(N_aft_R_GL);

  class array<double> weights_aft_R(N_aft_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R_pow_minus_0p25 , u_aft_R , weights_aft_R);

  um4_aft_R_tab_GL.allocate (N_aft_R_GL);

  w_aft_R_tab_GL.allocate (N_aft_R_GL);

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      const double u = u_aft_R(i);

      const double um4 = pow (u , -4);
      
      const double um3 = um4/u;
      
      um4_aft_R_tab_GL(i) = um4;
      
      w_aft_R_tab_GL(i) = weights_aft_R(i)*um3;
    }
  
  // Wave functions - Declarations
  
  CC_wf_bef_R_tab_uniform.allocate   (N_channels , N_bef_R_uniform);
  CC_dwf_bef_R_tab_uniform.allocate  (N_channels , N_bef_R_uniform);
  CC_d2wf_bef_R_tab_uniform.allocate (N_channels , N_bef_R_uniform);
  
  CC_asymptotic_in_zero_wf_bef_R_tab_uniform.allocate (N_channels , N_bef_R_uniform);

  if (are_there_scaled_wfs)
    {	
      CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform.allocate  (4 , N_bef_R_uniform); 
      CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform.allocate (4 , N_bef_R_uniform); 

      CC_scaled_wf_plus_aft_R_tab_uniform.allocate  (N_channels , 4 , N_bef_R_uniform); 
      CC_scaled_dwf_plus_aft_R_tab_uniform.allocate (N_channels , 4 , N_bef_R_uniform); 
    }

  CC_wf_bef_R_tab_GL.allocate   (N_channels , N_bef_R_GL);
  CC_dwf_bef_R_tab_GL.allocate  (N_channels , N_bef_R_GL);
  CC_d2wf_bef_R_tab_GL.allocate (N_channels , N_bef_R_GL);
  
  CC_wf_bef_R_tab_GL_SGI_MSGI.allocate  (N_channels , N_bef_R_GL);
  CC_dwf_bef_R_tab_GL_SGI_MSGI.allocate (N_channels , N_bef_R_GL);

  CC_wf_aft_R_tab_GL.allocate   (N_channels , N_aft_R_GL);
  CC_dwf_aft_R_tab_GL.allocate  (N_channels , N_aft_R_GL);
  CC_d2wf_aft_R_tab_GL.allocate (N_channels , N_aft_R_GL);

  if (are_there_scaled_wfs)
    {	
      CC_scaled_wf_minus_aft_R_c_entrance_tab_GL.allocate  (4 , N_bef_R_GL); 
      CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL.allocate (4 , N_bef_R_GL); 

      CC_scaled_wf_plus_aft_R_tab_GL.allocate  (N_channels , 4 , N_bef_R_GL); 
      CC_scaled_dwf_plus_aft_R_tab_GL.allocate (N_channels , 4 , N_bef_R_GL); 
    }

  CC_wf_momentum_tab_uniform.allocate  (N_channels , Nk_momentum_uniform);
  CC_dwf_momentum_tab_uniform.allocate (N_channels , Nk_momentum_uniform);

  CC_wf_momentum_tab_GL.allocate  (N_channels , Nk_momentum_GL);
  CC_dwf_momentum_tab_GL.allocate (N_channels , Nk_momentum_GL);
  
  // Wave functions - Initializations

  CC_wf_bef_R_tab_uniform   = INFINITE;
  CC_dwf_bef_R_tab_uniform  = INFINITE;
  CC_d2wf_bef_R_tab_uniform = INFINITE;

  CC_asymptotic_in_zero_wf_bef_R_tab_uniform = INFINITE;

  CC_wf_bef_R_tab_GL   = INFINITE;
  CC_dwf_bef_R_tab_GL  = INFINITE;
  CC_d2wf_bef_R_tab_GL = INFINITE;

  CC_wf_bef_R_tab_GL_SGI_MSGI  = INFINITE;
  CC_dwf_bef_R_tab_GL_SGI_MSGI = INFINITE;

  CC_wf_aft_R_tab_GL   = INFINITE;
  CC_dwf_aft_R_tab_GL  = INFINITE;
  CC_d2wf_aft_R_tab_GL = INFINITE;

  if (are_there_scaled_wfs)
    {	
      CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform  = INFINITE;
      CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform = INFINITE;

      CC_scaled_wf_plus_aft_R_tab_uniform  = INFINITE;
      CC_scaled_dwf_plus_aft_R_tab_uniform = INFINITE;

      CC_scaled_wf_minus_aft_R_c_entrance_tab_GL  = INFINITE;
      CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL = INFINITE;
      
      CC_scaled_wf_plus_aft_R_tab_GL  = INFINITE;
      CC_scaled_dwf_plus_aft_R_tab_GL = INFINITE;
    }

  CC_wf_momentum_tab_uniform  = INFINITE;
  CC_dwf_momentum_tab_uniform = INFINITE;

  CC_wf_momentum_tab_GL  = INFINITE;
  CC_dwf_momentum_tab_GL = INFINITE;
  
  HO_overlaps.allocate (N_channels);
  
  HO_overlaps_Fermi.allocate (N_channels);

  Nmax_HO_potentials_plus_one = 0;

  if (is_it_one_nucleon_COSM_case)
    {
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  const class CC_channel_class &channel_c = channels_tab(ic);

	  const int lc = channel_c.get_LCM_projectile ();

	  const int nmax_HO_lc = nmax_HO_lab_tab(lc);

	  const int nmax_HO_lc_plus_one = nmax_HO_lc + 1;

	  Nmax_HO_potentials_plus_one = max (Nmax_HO_potentials_plus_one , nmax_HO_lc_plus_one);

	  HO_overlaps(ic).allocate (nmax_HO_lc_plus_one);

	  HO_overlaps_Fermi(ic).allocate (nmax_HO_lc_plus_one);
	}
    }
  else
    {
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  const class CC_channel_class &channel_c = channels_tab(ic);

	  const enum particle_type projectile_c = channel_c.get_projectile ();

	  const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);

	  const class array<int> &Nmax_HO_tab_c = data_c.get_Nmax_HO_tab ();

	  const int LCM_projectile_c = channel_c.get_LCM_projectile ();

	  const int NCM_HO_max_LCM_projectile_c = Nmax_HO_tab_c(LCM_projectile_c);

	  const int NCM_HO_max_LCM_projectile_c_plus_one = NCM_HO_max_LCM_projectile_c + 1;
	  
	  Nmax_HO_potentials_plus_one = max (Nmax_HO_potentials_plus_one , NCM_HO_max_LCM_projectile_c_plus_one);

	  HO_overlaps(ic).allocate (NCM_HO_max_LCM_projectile_c_plus_one);
	  
	  HO_overlaps_Fermi(ic).allocate (NCM_HO_max_LCM_projectile_c_plus_one);
	}
    }

  // Forward basis and backward basis states
  fwd_basis.allocate (N_channels);
  bwd_basis.allocate (N_channels);

  const unsigned int first_ib = basic_first_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_ib = basic_last_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS); 

  for (unsigned int ib = 0 ; ib < N_channels ; ib++)
    {
      if ((ib >= first_ib) && (ib <= last_ib)) 
	{
	  fwd_basis(ib).allocate (S_matrix_pole , N_channels , ic_entrance , ib , channels_tab , N_bef_R_uniform , N_bef_R_GL , R0 , R , R0 , R_max);
	  
	  bwd_basis(ib).allocate (S_matrix_pole , N_channels , ic_entrance , ib , channels_tab , N_bef_R_uniform , N_bef_R_GL , R , R0 , R_max);
	}
    }

  if ((THIS_PROCESS == MASTER_PROCESS) && !S_matrix_pole)
    bwd_U_minus.allocate (S_matrix_pole , N_channels , ic_entrance , ic_entrance , channels_tab , N_bef_R_uniform , N_bef_R_GL , R , R0 , R_max);

  // C0 and Cplus tabs
  
  C0_tab.allocate (N_channels);

  Cplus_tab.allocate (N_channels);

  A0_tab.allocate (N_channels);

  Aplus_tab.allocate (N_channels);

  C0_tab = 1.0;

  Cplus_tab = 1.0;

  A0_tab = 1.0;

  Aplus_tab = 1.0;	
}






void CC_state_class::allocate_fill (const class CC_state_class &X)
{
  are_there_scaled_wfs = X.are_there_scaled_wfs; 

  N_channels = X.N_channels; 

  ic_entrance = X.ic_entrance; 

  R = X.R; 

  matching_point = X.matching_point; 

  R0 = X.R0; 

  R_max = X.R_max; 

  kmax_momentum = X.kmax_momentum;

  R_Fermi_momentum = X.R_Fermi_momentum;
  
  N_bef_R_uniform = X.N_bef_R_uniform; 
  N_aft_R_uniform = X.N_aft_R_uniform; 

  N_bef_R_GL = X.N_bef_R_GL; 
  N_aft_R_GL = X.N_aft_R_GL; 

  Nk_momentum_uniform = X.Nk_momentum_uniform;
  
  Nk_momentum_GL  = X.Nk_momentum_GL;
  
  step_bef_R_uniform = X.step_bef_R_uniform; 
  step_aft_R_uniform = X.step_aft_R_uniform; 

  step_momentum_uniform = X.step_momentum_uniform;
  
  N_bef_mp_uniform = X.N_bef_mp_uniform; 
  N_aft_mp_uniform = X.N_aft_mp_uniform; 

  A = X.A; 

  nmax_HO_local_plus_one = 16; 

  Nmax_HO_potentials_plus_one = X.Nmax_HO_potentials_plus_one;

  R_HO_end = 50.; 

  J = X.J; 
  M = X.M; 

  BP = X.BP; 

  n = X.n; 

  S_matrix_pole = X.S_matrix_pole; 

  is_it_HO_projected = X.is_it_HO_projected; 

  E = X.E; 

  Cminus_entrance_channel = X.Cminus_entrance_channel; 

  is_E_ok = X.is_E_ok;

  N_bef_mp_GL = X.N_bef_mp_GL;
  N_aft_mp_GL = X.N_aft_mp_GL;

  N_bef_mp_GL_SGI_MSGI = X.N_bef_mp_GL_SGI_MSGI;
  N_aft_mp_GL_SGI_MSGI = X.N_aft_mp_GL_SGI_MSGI;

  // Channel class
  channels_tab.allocate_fill (X.channels_tab);

  //--// discretization of r (before R) and k (before kmax_momentum)
  r_bef_R_tab_uniform.allocate_fill (X.r_bef_R_tab_uniform);
  
  k_tab_uniform.allocate_fill (X.k_tab_uniform);

  r_bef_R_tab_GL.allocate_fill (X.r_bef_R_tab_GL);
  w_bef_R_tab_GL.allocate_fill (X.w_bef_R_tab_GL);
  
  k_tab_GL.allocate_fill (X.k_tab_GL);
  wk_tab_GL.allocate_fill (X.wk_tab_GL);

  r_bef_R_tab_GL_SGI_MSGI.allocate_fill (X.r_bef_R_tab_GL_SGI_MSGI); // This set goes from 0 to 2.R0. R0 must be equal to matching_point.
  w_bef_R_tab_GL_SGI_MSGI.allocate_fill (X.w_bef_R_tab_GL_SGI_MSGI); // This set goes from 0 to 2.R0. R0 must be equal to matching_point.

  //--// discretization of r (after R)
  r_aft_R_tab_GL_real.allocate_fill (X.r_aft_R_tab_GL_real);
  w_aft_R_tab_GL_real.allocate_fill (X.w_aft_R_tab_GL_real);

  um4_aft_R_tab_GL.allocate_fill (X.um4_aft_R_tab_GL);

  w_aft_R_tab_GL.allocate_fill (X.w_aft_R_tab_GL);

  // Wave functions

  CC_wf_bef_R_tab_uniform.allocate_fill   (X.CC_wf_bef_R_tab_uniform);
  CC_dwf_bef_R_tab_uniform.allocate_fill  (X.CC_dwf_bef_R_tab_uniform);
  CC_d2wf_bef_R_tab_uniform.allocate_fill (X.CC_d2wf_bef_R_tab_uniform);

  CC_asymptotic_in_zero_wf_bef_R_tab_uniform.allocate_fill (X.CC_asymptotic_in_zero_wf_bef_R_tab_uniform);

  if (are_there_scaled_wfs)
    {	
      CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform.allocate_fill  (X.CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform);
      CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform.allocate_fill (X.CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform);

      CC_scaled_wf_plus_aft_R_tab_uniform.allocate_fill  (X.CC_scaled_wf_plus_aft_R_tab_uniform); 
      CC_scaled_dwf_plus_aft_R_tab_uniform.allocate_fill (X.CC_scaled_dwf_plus_aft_R_tab_uniform); 
    }

  CC_wf_bef_R_tab_GL.allocate_fill   (X.CC_wf_bef_R_tab_GL);
  CC_dwf_bef_R_tab_GL.allocate_fill  (X.CC_dwf_bef_R_tab_GL);
  CC_d2wf_bef_R_tab_GL.allocate_fill (X.CC_d2wf_bef_R_tab_GL);

  CC_wf_bef_R_tab_GL_SGI_MSGI.allocate_fill  (X.CC_wf_bef_R_tab_GL_SGI_MSGI);
  CC_dwf_bef_R_tab_GL_SGI_MSGI.allocate_fill (X.CC_dwf_bef_R_tab_GL_SGI_MSGI);

  CC_wf_aft_R_tab_GL.allocate_fill   (X.CC_wf_aft_R_tab_GL);
  CC_dwf_aft_R_tab_GL.allocate_fill  (X.CC_dwf_aft_R_tab_GL);
  CC_d2wf_aft_R_tab_GL.allocate_fill (X.CC_d2wf_aft_R_tab_GL);

  if (are_there_scaled_wfs)
    {	
      CC_scaled_wf_minus_aft_R_c_entrance_tab_GL.allocate_fill  (X.CC_scaled_wf_minus_aft_R_c_entrance_tab_GL);
      CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL.allocate_fill (X.CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL);

      CC_scaled_wf_plus_aft_R_tab_GL.allocate_fill  (X.CC_scaled_wf_plus_aft_R_tab_GL); 
      CC_scaled_dwf_plus_aft_R_tab_GL.allocate_fill (X.CC_scaled_dwf_plus_aft_R_tab_GL); 
    }

  CC_wf_momentum_tab_uniform.allocate_fill (X.CC_wf_momentum_tab_uniform);
  CC_dwf_momentum_tab_uniform.allocate_fill (X.CC_dwf_momentum_tab_uniform);

  CC_wf_momentum_tab_GL.allocate_fill (X.CC_wf_momentum_tab_GL);
  CC_dwf_momentum_tab_GL.allocate_fill (X.CC_dwf_momentum_tab_GL);
  
  HO_overlaps.allocate (N_channels);
  
  HO_overlaps_Fermi.allocate (N_channels);

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      HO_overlaps(ic).allocate_fill (X.HO_overlaps(ic));

      HO_overlaps_Fermi(ic).allocate_fill (X.HO_overlaps_Fermi(ic));
    }

  // Forward basis and backward basis states
  fwd_basis.allocate (N_channels);
  bwd_basis.allocate (N_channels);

  const unsigned int first_ib = basic_first_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_ib = basic_last_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS); 

  for (unsigned int ib = 0 ; ib < N_channels ; ib++)
    {
      if ((ib >= first_ib) && (ib <= last_ib))
	{
	  fwd_basis(ib).allocate_fill (X.fwd_basis(ib));

	  bwd_basis(ib).allocate_fill (X.bwd_basis(ib));
	}
    }

  if ((THIS_PROCESS == MASTER_PROCESS) && !S_matrix_pole) bwd_U_minus.allocate_fill  (X.bwd_U_minus);

  // C0 and Cplus tabs
  
  C0_tab.allocate_fill (X.C0_tab);

  Cplus_tab.allocate_fill (X.Cplus_tab);

  A0_tab.allocate_fill (X.A0_tab);

  Aplus_tab.allocate_fill (X.Aplus_tab);
}



void CC_state_class::deallocate ()
{
  // Channel class
  channels_tab.deallocate ();

  //--// discretization of r (before R) and k (before kmax_momentum)
  r_bef_R_tab_uniform.deallocate ();

  k_tab_uniform.deallocate ();
  
  r_bef_R_tab_GL.deallocate ();
  w_bef_R_tab_GL.deallocate ();

  k_tab_GL.deallocate ();
  wk_tab_GL.deallocate ();
  
  r_bef_R_tab_GL_SGI_MSGI.deallocate (); // This set goes from 0 to 2.R0. R0 must be equal to matching_point.
  w_bef_R_tab_GL_SGI_MSGI.deallocate (); // This set goes from 0 to 2.R0. R0 must be equal to matching_point.

  //--// discretization of r (after R)
  r_aft_R_tab_GL_real.deallocate ();
  w_aft_R_tab_GL_real.deallocate ();

  um4_aft_R_tab_GL.deallocate ();

  w_aft_R_tab_GL.deallocate ();

  // Wave functions

  CC_wf_bef_R_tab_uniform.deallocate ();
  CC_dwf_bef_R_tab_uniform.deallocate ();
  CC_d2wf_bef_R_tab_uniform.deallocate ();

  CC_asymptotic_in_zero_wf_bef_R_tab_uniform.deallocate ();

  CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform.deallocate ();
  CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform.deallocate ();

  CC_scaled_wf_plus_aft_R_tab_uniform.deallocate (); 
  CC_scaled_dwf_plus_aft_R_tab_uniform.deallocate ();

  CC_wf_bef_R_tab_GL.deallocate ();  
  CC_dwf_bef_R_tab_GL.deallocate (); 
  CC_d2wf_bef_R_tab_GL.deallocate ();

  CC_wf_bef_R_tab_GL_SGI_MSGI.deallocate (); 
  CC_dwf_bef_R_tab_GL_SGI_MSGI.deallocate ();

  CC_wf_aft_R_tab_GL.deallocate ();  
  CC_dwf_aft_R_tab_GL.deallocate (); 
  CC_d2wf_aft_R_tab_GL.deallocate ();

  CC_scaled_wf_minus_aft_R_c_entrance_tab_GL.deallocate (); 
  CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL.deallocate ();
  
  CC_scaled_wf_plus_aft_R_tab_GL.deallocate ();
  CC_scaled_dwf_plus_aft_R_tab_GL.deallocate ();

  CC_wf_momentum_tab_uniform.deallocate ();
  CC_dwf_momentum_tab_uniform.deallocate ();

  CC_wf_momentum_tab_GL.deallocate ();
  CC_dwf_momentum_tab_GL.deallocate ();
  
  HO_overlaps.deallocate ();
  
  HO_overlaps_Fermi.deallocate ();

  // Forward basis and backward basis states
  fwd_basis.deallocate ();
  bwd_basis.deallocate ();

  bwd_U_minus.deallocate ();

  // C0 and Cplus tabs
  
  C0_tab.deallocate ();

  Cplus_tab.deallocate ();

  A0_tab.deallocate ();

  Aplus_tab.deallocate ();

  are_there_scaled_wfs = false;

  N_channels = 0;

  ic_entrance = 0;

  R = 0.0; 

  matching_point = 0.0;

  R0 = 0.0; 

  R_max = 0.0;

  kmax_momentum = 0.0;

  R_Fermi_momentum = 0.0;
  
  N_bef_R_uniform = 0;
  N_aft_R_uniform = 0;

  N_bef_R_GL = 0;
  N_aft_R_GL = 0;

  Nk_momentum_uniform = 0;
  
  Nk_momentum_GL = 0;
  
  step_bef_R_uniform = 0.0;
  step_aft_R_uniform = 0.0;

  step_momentum_uniform = 0.0;
  
  N_bef_mp_uniform = 0;
  N_aft_mp_uniform = 0;

  A = 0; 

  nmax_HO_local_plus_one = 0; 

  Nmax_HO_potentials_plus_one = 0; 

  R_HO_end = 0.0; 

  J = 0.0; 
  M = 0.0; 

  BP = 0; 

  n = 0; 

  S_matrix_pole = false;

  is_it_HO_projected = false;

  E = 0.0; 

  Cminus_entrance_channel = 0.0;

  is_E_ok = false;

  N_bef_mp_GL = 0;
  N_aft_mp_GL = 0;

  N_bef_mp_GL_SGI_MSGI = 0;
  N_aft_mp_GL_SGI_MSGI = 0;
}






void CC_state_class::CC_wf_dwf_d2wf_zero () 
{
  CC_wf_bef_R_tab_uniform   = 0.0;
  CC_dwf_bef_R_tab_uniform  = 0.0;
  CC_d2wf_bef_R_tab_uniform = 0.0;

  CC_asymptotic_in_zero_wf_bef_R_tab_uniform = 0.0;

  CC_wf_bef_R_tab_GL   = 0.0;
  CC_dwf_bef_R_tab_GL  = 0.0;
  CC_d2wf_bef_R_tab_GL = 0.0;

  CC_wf_bef_R_tab_GL_SGI_MSGI  = 0.0;
  CC_dwf_bef_R_tab_GL_SGI_MSGI = 0.0;

  CC_wf_aft_R_tab_GL   = 0.0;
  CC_dwf_aft_R_tab_GL  = 0.0;
  CC_d2wf_aft_R_tab_GL = 0.0;

  CC_wf_momentum_tab_uniform  = 0.0;
  CC_dwf_momentum_tab_uniform = 0.0;

  CC_wf_momentum_tab_GL  = 0.0;
  CC_dwf_momentum_tab_GL = 0.0;
  
  if (are_there_scaled_wfs)
    {
      CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform  = 0.0;
      CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform = 0.0;

      CC_scaled_wf_plus_aft_R_tab_uniform  = 0.0;
      CC_scaled_dwf_plus_aft_R_tab_uniform = 0.0;

      CC_scaled_wf_minus_aft_R_c_entrance_tab_GL  = 0.0;
      CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL = 0.0;

      CC_scaled_wf_plus_aft_R_tab_GL  = 0.0;
      CC_scaled_dwf_plus_aft_R_tab_GL = 0.0;		
    }
}






complex<double> CC_state_class::Gamow_partial_squared_norm_no_channel_orthogonalization (const unsigned int ic) const
{
  const class CC_channel_class &channel_c = channels_tab(ic);

  const int LCM_projectile_c = channel_c.get_LCM_projectile ();

  const int Z_Tc_charge = channel_c.get_Z_Tc_charge ();
  
  const double kinetic_factor_projectile_c = channel_c.get_kinetic_factor_projectile ();

  const complex<double> kc_projectile = channel_c.get_k_projectile ();

  const complex<double> eta_projectile_c = channel_c.get_eta_projectile ();

  const complex<double> Cplus_c = Cplus_tab(ic);

  const bool is_it_bound_case = ((abs (real (kc_projectile)) < sqrt_precision) && (imag (kc_projectile) > sqrt_precision));

  complex<double> norm2_bef_R_c = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) norm2_bef_R_c += CC_wf_bef_R_tab_GL(ic , i) * CC_wf_bef_R_tab_GL(ic , i) * w_bef_R_tab_GL(i);

  const unsigned int angle_index_c = optimal_angle_index (2.0 * kc_projectile);

  const complex<double> exp_Itheta_projectile_c (cos_theta_tab[angle_index_c] , sin_theta_tab[angle_index_c]);

  const double two_Rt_c = (abs (real (kc_projectile)) > precision)
    ? (2.0 * (abs (eta_projectile_c/kc_projectile) + sqrt (abs (LCM_projectile_c * (LCM_projectile_c + 1)/kc_projectile) + abs (eta_projectile_c * eta_projectile_c/kc_projectile))))
    : (R);

  const double R_rotation = (two_Rt_c > R + 10) ? (two_Rt_c) : (R);

  class array<double> u_aft_R_rotation(N_aft_R_GL);

  class array<double> weights_aft_R_rotation(N_aft_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , pow (R_rotation , - 0.25) , u_aft_R_rotation , weights_aft_R_rotation);

  class Coulomb_wave_functions cwf_c(true , LCM_projectile_c , eta_projectile_c);

  complex<double> norm2_mid_c = 0.0;

  complex<double> norm2_aft_R_rotation_c = 0.0;

  complex<double> CC_wf_r_c = 0.0;

  complex<double> dummy = NADA;

  if (R_rotation > R)
    {
      const unsigned int N_mid_GL = N_bef_R_GL; 

      class array<double> r_mid_GL (N_mid_GL);

      class array<double> weights_mid_GL (N_mid_GL);

      Gauss_Legendre::abscissas_weights_tables_calc (R , R_rotation , r_mid_GL , weights_mid_GL);

      for (unsigned int i = 0 ; i < N_mid_GL ; i++)
	{
	  if (is_it_bound_case)
	    {
	      cwf_c.Wm_kz_dWm_kz (kc_projectile , r_mid_GL(i) , CC_wf_r_c , dummy);
	    }
	  else
	    {
	      cwf_c.H_kz_dH_kz (1 , kc_projectile , r_mid_GL(i) , CC_wf_r_c , dummy);
	    }

	  CC_wf_r_c *= Cplus_c;

	  norm2_mid_c += CC_wf_r_c * CC_wf_r_c * weights_mid_GL(i);
	}

      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  const double um4 = pow (u_aft_R_rotation(i) , - 4);

	  const complex<double> z = R_rotation + (um4 - R_rotation) * exp_Itheta_projectile_c;

	  if (is_it_bound_case)
	    {
	      cwf_c.Wm_kz_dWm_kz (kc_projectile , z , CC_wf_r_c , dummy);
	    }
	  else
	    {
	      cwf_c.H_kz_dH_kz (1 , kc_projectile , z , CC_wf_r_c , dummy);
	    }

	  CC_wf_r_c *= Cplus_c;

	  norm2_aft_R_rotation_c += CC_wf_r_c * CC_wf_r_c * weights_aft_R_rotation(i) * um4/u_aft_R_rotation(i);
	}

      norm2_aft_R_rotation_c *= 4. * exp_Itheta_projectile_c;
    }
  else
    {
      const enum particle_type projectile_c = channel_c.get_projectile ();
      
      const int projectile_c_charge = particle_charge_determine (projectile_c);
      
      const int Z_Tc_charge_times_projectile_c_charge = Z_Tc_charge*projectile_c_charge;
      
      const double LCM_projectile_c_term = 2. * LCM_projectile_c + 0.5;

      const complex<double> ILCM_projectile_c_term (0. , LCM_projectile_c_term);

      const complex<double> norm_kc_projectile_is_zero = exp (ILCM_projectile_c_term * M_PI_2);

      const complex<double> two_I_sqrt_Vc (0. , 2. * sqrt(kinetic_factor_projectile_c * Z_Tc_charge_times_projectile_c_charge * Coulomb_constant));

      class Coulomb_wave_functions cwf_zero_kc_projectile (true , LCM_projectile_c_term , 0.0);

      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  const double um4 = pow (u_aft_R_rotation(i) , - 4);

	  const complex<double> z = R + (um4 - R) * exp_Itheta_projectile_c;

	  if (kc_projectile == 0.0) 
	    {
	      wf_dwf_k_is_zero (LCM_projectile_c , Z_Tc_charge_times_projectile_c_charge , two_I_sqrt_Vc , norm_kc_projectile_is_zero , cwf_zero_kc_projectile , z , CC_wf_r_c , dummy);
	    }
	  else if (is_it_bound_case)
	    {
	      cwf_c.Wm_kz_dWm_kz (kc_projectile , z , CC_wf_r_c , dummy);
	    }
	  else
	    {
	      cwf_c.H_kz_dH_kz (1 , kc_projectile , z , CC_wf_r_c , dummy);
	    }

	  CC_wf_r_c *= Cplus_c;

	  norm2_aft_R_rotation_c += CC_wf_r_c * CC_wf_r_c * weights_aft_R_rotation(i) * um4/u_aft_R_rotation(i);
	}

      norm2_aft_R_rotation_c *= 4.0 * exp_Itheta_projectile_c;
    }

  const complex<double> norm2_c = norm2_bef_R_c + norm2_mid_c + norm2_aft_R_rotation_c;

  return norm2_c;
}






complex<double> CC_state_class::Gamow_norm_no_channel_orthogonalization () const
{
  if (is_it_HO_projected) error_message_print_abort ("Gamow norm (no channel orthogonalization) calculation is meaningless with HO projected functions.");

  if (!S_matrix_pole)
    {
      return 1.0;
    }
  else
    {
      double Re_norm2_partial = 0.0;
      double Im_norm2_partial = 0.0;

      const unsigned int first_ic = basic_first_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_ic = basic_last_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS); 

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) reduction(+:Re_norm2_partial , Im_norm2_partial)
#endif 
      for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
	{
	  if ((ic >= first_ic) && (ic <= last_ic))
	    {
	      const complex<double> norm2_partial_c = Gamow_partial_squared_norm_no_channel_orthogonalization (ic);

	      Re_norm2_partial += real (norm2_partial_c);
	      Im_norm2_partial += imag (norm2_partial_c);
	    }
	}

      const complex<double> norm2_partial(Re_norm2_partial , Im_norm2_partial);

      const complex<double> norm2 = sum_Allreduce<complex<double> > (is_it_MPI_parallelized , norm2_partial);

      const complex<double> norm_no_phase = sqrt (norm2);
      
      const complex<double> norm_value = norm_no_phase * SIGN (real (norm_no_phase));

      return norm_value;
    }
}




// 
// _ comes into the normalization of the CC bound or resonant states , when rescaling (as waves are not orthogonal). 

complex<double> CC_state_class::finite_range_overlaps_square_norm (const class CC_Hamiltonian_data &CC_H_data) const 
{
  double Re_finite_range_norm_partial = 0.0;
  double Im_finite_range_norm_partial = 0.0;

  const unsigned int first_ic = basic_first_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_ic = basic_last_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS); 

  const class array<class matrix<complex<double> > > &finite_range_overlaps_HO_submatrices = CC_H_data.get_finite_range_overlaps_HO_submatrices ();

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) reduction(+:Re_finite_range_norm_partial , Im_finite_range_norm_partial)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
    {
      const class vector_class<complex<double> > &HO_overlaps_c = HO_overlaps(ic);

      for (unsigned int icp = 0 ; icp < N_channels ; icp++) 
	{
	  if ((icp >= first_ic) && (icp <= last_ic))
	    {
	      const class vector_class<complex<double> > & HO_overlaps_cp = HO_overlaps(icp);

	      const class matrix<complex<double> > & finite_range_overlaps_HO_submatrix_c_cp = finite_range_overlaps_HO_submatrices(ic , icp);

	      const complex<double> finite_range_norm_partial_c_cp = HO_overlaps_c * (finite_range_overlaps_HO_submatrix_c_cp * HO_overlaps_cp);

	      Re_finite_range_norm_partial += real (finite_range_norm_partial_c_cp);
	      Im_finite_range_norm_partial += imag (finite_range_norm_partial_c_cp);
	    }
	}
    }

  const complex<double> finite_range_norm_partial(Re_finite_range_norm_partial , Im_finite_range_norm_partial);

  const complex<double> finite_range_norm = sum_Allreduce<complex<double> > (is_it_MPI_parallelized , finite_range_norm_partial);
  
  return finite_range_norm;
}







complex<double> CC_state_class::Gamow_norm_with_channel_orthogonalization (const class CC_Hamiltonian_data &CC_H_data) const 
{
  if (is_it_HO_projected) error_message_print_abort ("Gamow norm (channel orthogonalization) calculation is meaningless with HO projected functions.");

  if (!S_matrix_pole)
    {
      return 1.0;
    }
  else
    {
      const complex<double> norm_no_channel_orthogonalization = Gamow_norm_no_channel_orthogonalization ();

      const complex<double> norm2_no_channel_orthogonalization = norm_no_channel_orthogonalization*norm_no_channel_orthogonalization;

      const complex<double> norm2_channel_orthogonalization_rest = finite_range_overlaps_square_norm (CC_H_data);
      
      const complex<double> norm2 = norm2_no_channel_orthogonalization + norm2_channel_orthogonalization_rest;

      const complex<double> norm_no_phase = sqrt (norm2);

      const complex<double> norm_value = norm_no_phase * SIGN (real (norm_no_phase));

      return norm_value;
    }
}






void CC_state_class::normalization (const complex<double> &factor) 
{
  CC_wf_bef_R_tab_uniform   *= factor;
  CC_dwf_bef_R_tab_uniform  *= factor;
  CC_d2wf_bef_R_tab_uniform *= factor;

  CC_asymptotic_in_zero_wf_bef_R_tab_uniform *= factor;

  CC_wf_bef_R_tab_GL   *= factor;
  CC_dwf_bef_R_tab_GL  *= factor;
  CC_d2wf_bef_R_tab_GL *= factor;

  CC_wf_bef_R_tab_GL_SGI_MSGI  *= factor;
  CC_dwf_bef_R_tab_GL_SGI_MSGI *= factor;

  CC_wf_aft_R_tab_GL   *= factor;
  CC_dwf_aft_R_tab_GL  *= factor;
  CC_d2wf_aft_R_tab_GL *= factor;	

  C0_tab *= factor;

  Cplus_tab *= factor;
  Cplus_tab *= factor;

  Cminus_entrance_channel *= factor;

  if (are_there_scaled_wfs)
    {
      CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform  *= factor;
      CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform *= factor;

      CC_scaled_wf_plus_aft_R_tab_uniform  *= factor;
      CC_scaled_dwf_plus_aft_R_tab_uniform *= factor;

      CC_scaled_wf_minus_aft_R_c_entrance_tab_GL  *= factor;
      CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL *= factor;

      CC_scaled_wf_plus_aft_R_tab_GL  *= factor;
      CC_scaled_dwf_plus_aft_R_tab_GL *= factor;	
    }
  
  CC_wf_momentum_tab_uniform  *= factor;
  CC_dwf_momentum_tab_uniform *= factor;

  CC_wf_momentum_tab_GL  *= factor;
  CC_dwf_momentum_tab_GL *= factor;
}



void CC_state_class::change_channels_energy (const complex<double> &E_change) 
{
  if (is_it_HO_projected) error_message_print_abort ("Channels energy change is meaningless with HO projected functions.");

  E = E_change;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++) channels_tab(ic).E_dependent_values_change (E);

  const unsigned int first_ib = basic_first_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_ib = basic_last_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS); 

  for (unsigned int ib = 0 ; ib < N_channels ; ib++)
    {
      if ((ib >= first_ib) && (ib <= last_ib))
	{
	  class CC_fwd_basis_state &fwd_state_b = fwd_basis(ib);
	  class CC_bwd_basis_state &bwd_state_b = bwd_basis(ib);

	  fwd_state_b.change_channels (E);
	  bwd_state_b.change_channels (E);
	}

      if ((THIS_PROCESS == MASTER_PROCESS) && !S_matrix_pole) bwd_U_minus.change_channels (E);
    }
}









void CC_state_class::basis_states_calc (
					const bool is_it_entrance_channel_only , 
					const class potentials_effective_mass &T) 
{
  if (is_it_HO_projected) error_message_print_abort ("Basis states calculation is meaningless with HO projected functions.");

  const complex<double> source_factor = (!is_it_entrance_channel_only) ? (1.0/static_cast<double> (N_channels)) : (1.0);

  const unsigned int first_ib = basic_first_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_ib = basic_last_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS); 

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ib = 0 ; ib < N_channels ; ib++)
    {
      if (!is_it_entrance_channel_only || (ib == ic_entrance))
	{
	  if ((ib >= first_ib) && (ib <= last_ib))
	    {
	      class CC_system_integration SI (is_it_entrance_channel_only , ic_entrance , N_channels , T , channels_tab , source_factor);

	      class CC_fwd_basis_state &fwd_state_b = fwd_basis(ib);

	      const complex<double> C0_b = C0_tab(ib);

	      fwd_state_b.forward_integration_before_R (is_it_entrance_channel_only , C0_b , T , SI);
	    }
	}
    }

  if (S_matrix_pole) 
    {
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
      for (unsigned int ib = 0 ; ib < N_channels ; ib++)
	{
	  if (!is_it_entrance_channel_only || (ib == ic_entrance))
	    {
	      if ((ib >= first_ib) && (ib <= last_ib)) 
		{
		  class CC_system_integration SI (is_it_entrance_channel_only , ic_entrance , N_channels , T , channels_tab , source_factor);

		  class CC_bwd_basis_state &bwd_state_b = bwd_basis(ib);

		  const complex<double> Cplus_b = Cplus_tab(ib);

		  bwd_state_b.backward_integration_before_R (is_it_entrance_channel_only , false , Cplus_b , SI);
		}
	    }
	}
    }
  else
    {
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  class CC_system_integration SI_minus (is_it_entrance_channel_only , ic_entrance , N_channels , T , channels_tab , 1.0);

	  bwd_U_minus.backward_integration_before_R (is_it_entrance_channel_only , true , NADA , SI_minus);
	}

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
      for (unsigned int ib = 0 ; ib < N_channels ; ib++)
	{
	  if (!is_it_entrance_channel_only || (ib == ic_entrance))
	    {
	      if ((ib >= first_ib) && (ib <= last_ib)) 
		{
		  class CC_system_integration SI_plus (is_it_entrance_channel_only , ic_entrance , N_channels , T , channels_tab , 0.0);

		  class CC_bwd_basis_state &bwd_state_b = bwd_basis(ib);

		  const complex<double> Cplus_b = Cplus_tab(ib);

		  bwd_state_b.backward_integration_before_R (is_it_entrance_channel_only , false , Cplus_b , SI_plus);
		}
	    }
	}
    }
}


// 
// _ Calculation of the Jost determinant.
// _ The class elements are modified in this routine. 

complex<double> CC_state_class::Jost_determinant_calc (
						       const bool is_it_entrance_channel_only ,
						       const class potentials_effective_mass &T) 
{
  if (is_it_HO_projected) error_message_print_abort ("Jost function calculation is meaningless with HO projected functions.");

  basis_states_calc (is_it_entrance_channel_only , T);

  if (is_it_entrance_channel_only)
    {
      class matrix<complex<double> > Jost_matrix_entrance_channel_only(2);

      Jost_matrix_entrance_channel_only_calc (ic_entrance , fwd_basis , bwd_basis , Jost_matrix_entrance_channel_only);

      const complex<double> Jost_determinant = Jost_matrix_entrance_channel_only.determinant ();

      return Jost_determinant;
    }
  else
    {
      const unsigned int two_N_channels = 2*N_channels;

      class matrix<complex<double> > Jost_matrix(two_N_channels);

      Jost_matrix_calc (fwd_basis , bwd_basis , Jost_matrix);

      const complex<double> Jost_determinant = Jost_matrix.determinant ();

      return Jost_determinant;
    }
}







void CC_state_class::constants_calc (const bool is_it_entrance_channel_only) 
{	
  if (is_it_HO_projected) error_message_print_abort ("Integration constants calculation is meaningless with HO projected functions.");

  const unsigned int two_N_channels = 2*N_channels;

  class vector_class<complex<double> > A0_Aplus_tab(two_N_channels);

  A0_Aplus_tab = 0.0;

  if (is_it_entrance_channel_only)
    {
      const unsigned int ic_entrance_plus = ic_entrance + N_channels;

      class matrix<complex<double> > Jost_matrix_entrance_channel_only(2);

      Jost_matrix_entrance_channel_only_calc (ic_entrance , fwd_basis , bwd_basis , Jost_matrix_entrance_channel_only);

      class vector_class<complex<double> > A0_Aplus_tab_entrance_channel_only(2);

      if (S_matrix_pole)
	{
	  class matrix<complex<double> > symmetric_matrix = transpose (Jost_matrix_entrance_channel_only) * Jost_matrix_entrance_channel_only;

	  class array<complex<double> > eigenvalues(2);

	  total_diagonalization::symmetric::all_eigenpairs (symmetric_matrix , eigenvalues);

	  const unsigned int index_min = eigenvalues.closest_value_index_determine (0.0);

	  // One wants the A0 , Aplus to be equal to 1 at the end , hence the sqrt_2

	  class vector_class<complex<double> > A0_Aplus_tab_entrance_channel_only = complex<double> (M_SQRT2) * symmetric_matrix.eigenvector (index_min); 

	  if (real (A0_Aplus_tab(index_min)) <= 0) A0_Aplus_tab_entrance_channel_only = -A0_Aplus_tab_entrance_channel_only;
	}
      else
	{
	  class vector_class<complex<double> > U_dU_minus_tab_entrance_channel_only(2);

	  if (THIS_PROCESS == MASTER_PROCESS)
	    {
	      const class array<complex<double> > &CC_U_minus_bwd_wf_mp_tab  = bwd_U_minus.get_CC_bwd_wf_mp_tab ();
	      const class array<complex<double> > &CC_U_minus_bwd_dwf_mp_tab = bwd_U_minus.get_CC_bwd_dwf_mp_tab ();

	      U_dU_minus_tab_entrance_channel_only(0) = CC_U_minus_bwd_wf_mp_tab(ic_entrance);
	      U_dU_minus_tab_entrance_channel_only(1) = CC_U_minus_bwd_dwf_mp_tab(ic_entrance);
	    }

#ifdef UseMPI
	  if (is_it_MPI_parallelized) U_dU_minus_tab_entrance_channel_only.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif

	  linear_system_solution_calc (Jost_matrix_entrance_channel_only , U_dU_minus_tab_entrance_channel_only , A0_Aplus_tab_entrance_channel_only);
	}

      A0_Aplus_tab(ic_entrance)      = A0_Aplus_tab_entrance_channel_only(0);
      A0_Aplus_tab(ic_entrance_plus) = A0_Aplus_tab_entrance_channel_only(1); 	
    }
  else
    {
      class matrix<complex<double> > Jost_matrix(two_N_channels);
      
      Jost_matrix_calc (fwd_basis , bwd_basis , Jost_matrix);

      if (S_matrix_pole)
	{
	  const unsigned int dimension = Jost_matrix.get_dimension ();

	  const complex<double> sqrt_dimension = sqrt (static_cast<double> (dimension));

	  class matrix<complex<double> > symmetric_matrix = transpose (Jost_matrix) * Jost_matrix;

	  class array<complex<double> > eigenvalue(dimension);

	  total_diagonalization::symmetric::all_eigenpairs (symmetric_matrix , eigenvalue);

	  const unsigned int index_min = eigenvalue.closest_value_index_determine (0.0);

	  // One wants the A0 , Aplus to be equal to 1 at the end , hence the sqrt_dimension

	  A0_Aplus_tab = sqrt_dimension * symmetric_matrix.eigenvector (index_min); 

	  if (real (A0_Aplus_tab(index_min)) <= 0) A0_Aplus_tab = - A0_Aplus_tab;
	}
      else
	{
	  class vector_class<complex<double> > U_dU_minus_tab (two_N_channels);

	  if (THIS_PROCESS == MASTER_PROCESS)
	    {
	      const class array<complex<double> > &CC_U_minus_bwd_wf_mp_tab  = bwd_U_minus.get_CC_bwd_wf_mp_tab ();
	      const class array<complex<double> > &CC_U_minus_bwd_dwf_mp_tab = bwd_U_minus.get_CC_bwd_dwf_mp_tab ();

	      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
		{
		  const unsigned int ic_derivative = ic + N_channels;

		  U_dU_minus_tab(ic)            = CC_U_minus_bwd_wf_mp_tab(ic);
		  U_dU_minus_tab(ic_derivative) = CC_U_minus_bwd_dwf_mp_tab(ic);
		}
	    }

#ifdef UseMPI
	  if (is_it_MPI_parallelized) U_dU_minus_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif

	  linear_system_solution_calc (Jost_matrix , U_dU_minus_tab , A0_Aplus_tab);
	}
    }

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const unsigned int ic_plus = ic + N_channels;

      const complex<double> A0_c    = A0_Aplus_tab(ic);
      const complex<double> Aplus_c = A0_Aplus_tab(ic_plus);

      A0_tab(ic) = A0_c;
      C0_tab(ic) *= A0_c;

      Aplus_tab(ic) = Aplus_c;
      Cplus_tab(ic) *= Aplus_c;
    }
}








void CC_state_class::CC_asymptotic_in_zero_wf_before_R_calc (
							     const bool is_it_entrance_channel_only ,
							     const class potentials_effective_mass &T) 
{
  if (is_it_HO_projected) error_message_print_abort ("Asymptotic functions in zero calculation is meaningless with HO projected functions.");

  const class array<splines_class<complex<double> > > &Ueq_tab = T.get_CC_trivially_equivalent_potential_tab ();

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      if (!is_it_entrance_channel_only || (ic == ic_entrance))
	{
	  const class CC_channel_class &channel_c = channels_tab(ic);

	  const int LCM_projectile_c = channel_c.get_LCM_projectile ();

	  const double kinetic_factor_projectile_c = channel_c.get_kinetic_factor_projectile ();

	  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	    {
	      const double r = r_bef_R_tab_uniform(i);

	      for (unsigned int ib = 0 ; ib < N_channels ; ib++)
		{
		  if (!is_it_entrance_channel_only || (ib == ic_entrance))
		    {
		      const class splines_class<complex<double> > &Ueq_cb = Ueq_tab(ic , ib);

		      const complex<double> C0_b = C0_tab(ib);

		      const class CC_channel_class &channel_b = channels_tab(ib);

		      const int LCM_projectile_b = channel_b.get_LCM_projectile ();

		      const complex<double> a_cb = kinetic_factor_projectile_c * Ueq_cb(0.);

		      if (ic == ib)
			{
			  CC_asymptotic_in_zero_wf_bef_R_tab_uniform(ic , i) += C0_b * pow (r , LCM_projectile_c + 1);
			}
		      else if (LCM_projectile_c != LCM_projectile_b + 2)
			{
			  const complex<double> factor = a_cb / ((LCM_projectile_b + 2.) * (LCM_projectile_b + 3.) - LCM_projectile_c * (LCM_projectile_c + 1.));
			  CC_asymptotic_in_zero_wf_bef_R_tab_uniform(ic , i) += C0_b * factor * pow (r , LCM_projectile_b + 3);
			}
		      else
			{
			  const double log_r = log(r);

			  const double f1 = 1./(2. * LCM_projectile_b + 5.);

			  const complex<double> f2 = a_cb * f1;

			  CC_asymptotic_in_zero_wf_bef_R_tab_uniform(ic , i) += C0_b * f2 * pow (r , LCM_projectile_b + 3) * log_r;
			}}}}}}
}








void CC_state_class::CC_wfs_dwfs_bef_R_calc (const bool is_it_entrance_channel_only) 
{	
  if (is_it_HO_projected) error_message_print_abort ("Wave function integration before R is meaningless with HO projected functions.");

  const unsigned int first_ib = basic_first_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_ib = basic_last_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS); 

  for (unsigned int ib = 0 ; ib < N_channels ; ib++)
    {
      if (!is_it_entrance_channel_only || (ib == ic_entrance))
	{
	  if ((ib >= first_ib) && (ib <= last_ib)) 
	    {
	      const class CC_fwd_basis_state &fwd_state_b = fwd_basis(ib);
	      const class CC_bwd_basis_state &bwd_state_b = bwd_basis(ib);

	      const class array<complex<double> > &CC_fwd_wf_tab_uniform_b  = fwd_state_b.get_CC_fwd_wf_tab_uniform (); 
	      const class array<complex<double> > &CC_fwd_dwf_tab_uniform_b = fwd_state_b.get_CC_fwd_dwf_tab_uniform ();
	      
	      const class array<complex<double> > &CC_fwd_wf_tab_GL_b  = fwd_state_b.get_CC_fwd_wf_tab_GL (); 
	      const class array<complex<double> > &CC_fwd_dwf_tab_GL_b = fwd_state_b.get_CC_fwd_dwf_tab_GL ();

	      const class array<complex<double> > &CC_fwd_wf_tab_GL_SGI_MSGI_b  = fwd_state_b.get_CC_fwd_wf_tab_GL_SGI_MSGI (); 
	      const class array<complex<double> > &CC_fwd_dwf_tab_GL_SGI_MSGI_b = fwd_state_b.get_CC_fwd_dwf_tab_GL_SGI_MSGI ();

	      const class array<complex<double> > &CC_bwd_wf_tab_uniform_b  = bwd_state_b.get_CC_bwd_wf_tab_uniform (); 
	      const class array<complex<double> > &CC_bwd_dwf_tab_uniform_b = bwd_state_b.get_CC_bwd_dwf_tab_uniform ();
	      
	      const class array<complex<double> > &CC_bwd_wf_tab_GL_b  = bwd_state_b.get_CC_bwd_wf_tab_GL (); 
	      const class array<complex<double> > &CC_bwd_dwf_tab_GL_b = bwd_state_b.get_CC_bwd_dwf_tab_GL ();

	      const class array<complex<double> > &CC_bwd_wf_tab_GL_SGI_MSGI_b  = bwd_state_b.get_CC_bwd_wf_tab_GL_SGI_MSGI (); 
	      const class array<complex<double> > &CC_bwd_dwf_tab_GL_SGI_MSGI_b = bwd_state_b.get_CC_bwd_dwf_tab_GL_SGI_MSGI ();

	      const complex<double> &A0_b = A0_tab(ib);

	      const complex<double> &Aplus_b = Aplus_tab(ib);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
	      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
		{
		  if (!is_it_entrance_channel_only || (ic == ic_entrance))
		    {
		      // Calculation before matchpoint
		      for (unsigned int i = 0 ; i < N_bef_mp_uniform ; i++)
			{
			  CC_wf_bef_R_tab_uniform (ic , i) += A0_b * CC_fwd_wf_tab_uniform_b(ic , i);
			  CC_dwf_bef_R_tab_uniform(ic , i) += A0_b * CC_fwd_dwf_tab_uniform_b(ic , i);
			}

		      for (unsigned int i = 0 ; i < N_bef_mp_GL ; i++)
			{
			  CC_wf_bef_R_tab_GL (ic , i) += A0_b * CC_fwd_wf_tab_GL_b(ic , i);
			  CC_dwf_bef_R_tab_GL(ic , i) += A0_b * CC_fwd_dwf_tab_GL_b(ic , i);
			}

		      for (unsigned int i = 0 ; i < N_bef_mp_GL_SGI_MSGI ; i++) 
			{
			  CC_wf_bef_R_tab_GL_SGI_MSGI (ic , i) += A0_b * CC_fwd_wf_tab_GL_SGI_MSGI_b(ic , i);
			  CC_dwf_bef_R_tab_GL_SGI_MSGI(ic , i) += A0_b * CC_fwd_dwf_tab_GL_SGI_MSGI_b(ic , i);
			}

		      // Calculation after matchpoint (the outgoing part only)
		      for (unsigned int i = 0 ; i < N_aft_mp_uniform ; i++)
			{
			  const unsigned int ii = i + N_bef_mp_uniform;

			  CC_wf_bef_R_tab_uniform(ic , ii)  += Aplus_b * CC_bwd_wf_tab_uniform_b(ic , i);
			  CC_dwf_bef_R_tab_uniform(ic , ii) += Aplus_b * CC_bwd_dwf_tab_uniform_b(ic , i);
			}

		      for (unsigned int i = 0 ; i < N_aft_mp_GL ; i++)
			{
			  const unsigned int ii = i + N_bef_mp_GL;

			  CC_wf_bef_R_tab_GL(ic , ii)  += Aplus_b * CC_bwd_wf_tab_GL_b(ic , i);
			  CC_dwf_bef_R_tab_GL(ic , ii) += Aplus_b * CC_bwd_dwf_tab_GL_b(ic , i);
			}

		      for (unsigned int i = 0 ; i < N_aft_mp_GL_SGI_MSGI ; i++)
			{
			  const unsigned int ii = i + N_bef_mp_GL_SGI_MSGI;

			  CC_wf_bef_R_tab_GL_SGI_MSGI(ic , ii)  += Aplus_b * CC_bwd_wf_tab_GL_SGI_MSGI_b(ic , i);
			  CC_dwf_bef_R_tab_GL_SGI_MSGI(ic , ii) += Aplus_b * CC_bwd_dwf_tab_GL_SGI_MSGI_b(ic , i);
			}
		    }
		}
	    }
	}
    }

  // Addition of the incoming part for scattering states
  if ((THIS_PROCESS == MASTER_PROCESS) && !S_matrix_pole)
    {
      const class array<complex<double> > &bwd_U_minus_tab_uniform  = bwd_U_minus.get_CC_bwd_wf_tab_uniform (); 
      const class array<complex<double> > &bwd_dU_minus_tab_uniform = bwd_U_minus.get_CC_bwd_dwf_tab_uniform ();
      
      const class array<complex<double> > &bwd_U_minus_tab_GL  = bwd_U_minus.get_CC_bwd_wf_tab_GL (); 
      const class array<complex<double> > &bwd_dU_minus_tab_GL = bwd_U_minus.get_CC_bwd_dwf_tab_GL ();

      const class array<complex<double> > &bwd_U_minus_tab_GL_SGI_MSGI  = bwd_U_minus.get_CC_bwd_wf_tab_GL_SGI_MSGI (); 
      const class array<complex<double> > &bwd_dU_minus_tab_GL_SGI_MSGI = bwd_U_minus.get_CC_bwd_dwf_tab_GL_SGI_MSGI ();

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  if (!is_it_entrance_channel_only || (ic == ic_entrance))
	    {
	      for (unsigned int i = 0 ; i < N_aft_mp_uniform ; i++)
		{
		  const unsigned int ii = i + N_bef_mp_uniform;

		  CC_wf_bef_R_tab_uniform(ic , ii)  += bwd_U_minus_tab_uniform(ic , i);
		  CC_dwf_bef_R_tab_uniform(ic , ii) += bwd_dU_minus_tab_uniform(ic , i);
		}

	      for (unsigned int i = 0 ; i < N_aft_mp_GL ; i++)
		{
		  const unsigned int ii = i + N_bef_mp_GL;

		  CC_wf_bef_R_tab_GL(ic , ii)  += bwd_U_minus_tab_GL(ic , i);
		  CC_dwf_bef_R_tab_GL(ic , ii) += bwd_dU_minus_tab_GL(ic , i);
		}

	      for (unsigned int i = 0 ; i < N_aft_mp_GL_SGI_MSGI ; i++)
		{
		  const unsigned int ii = i + N_bef_mp_GL_SGI_MSGI;

		  CC_wf_bef_R_tab_GL_SGI_MSGI(ic , ii)  += bwd_U_minus_tab_GL_SGI_MSGI(ic , i);
		  CC_dwf_bef_R_tab_GL_SGI_MSGI(ic , ii) += bwd_dU_minus_tab_GL_SGI_MSGI(ic , i);
		}
	    }
	}
    }

#ifdef UseMPI
  
  if (is_it_MPI_parallelized)
    {
      CC_wf_bef_R_tab_uniform.MPI_Allreduce  (MPI_SUM , MPI_COMM_WORLD);	
      CC_dwf_bef_R_tab_uniform.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
      
      CC_wf_bef_R_tab_GL.MPI_Allreduce  (MPI_SUM , MPI_COMM_WORLD);	
      CC_dwf_bef_R_tab_GL.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);	

      CC_wf_bef_R_tab_GL_SGI_MSGI.MPI_Allreduce  (MPI_SUM , MPI_COMM_WORLD);
      CC_dwf_bef_R_tab_GL_SGI_MSGI.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
    }
  
#endif
}








void CC_state_class::CC_d2wfs_bef_R_calc (
					  const bool is_it_entrance_channel_only ,
					  const class potentials_effective_mass &T) 
{
  if (is_it_HO_projected) error_message_print_abort ("Wave function second derivative calculation before R is meaningless with HO projected functions.");

  const complex<double> source_factor = (!is_it_entrance_channel_only) ? (1.0/static_cast<double> (N_channels)) : (1.0);

  const class array<class splines_class<complex<double> > > &Ueq_tab = T.get_CC_trivially_equivalent_potential_tab ();

  const class array<class splines_class<complex<double> > > &source_tab = T.get_CC_source_tab ();

  const unsigned int first_ir_uniform = basic_first_index_determine_for_MPI (N_bef_R_uniform , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_ir_uniform = basic_last_index_determine_for_MPI (N_bef_R_uniform , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int first_ir_GL = basic_first_index_determine_for_MPI (N_bef_R_GL , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_ir_GL = basic_last_index_determine_for_MPI (N_bef_R_GL , NUMBER_OF_PROCESSES , THIS_PROCESS); 

  if (first_ir_uniform == 0)
    {
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  if (!is_it_entrance_channel_only || (ic == ic_entrance))
	    {
	      const class CC_channel_class &channel_c = channels_tab(ic);

	      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

	      CC_d2wf_bef_R_tab_uniform(ic , 0) = (LCM_projectile_c == 1) ? (2.0 * C0_tab(ic)) : (0.0);
	    }
	}
    }

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      if (!is_it_entrance_channel_only || (ic == ic_entrance))
	{
	  const class splines_class<complex<double> > &source_c = source_tab(ic);

	  const class CC_channel_class &channel_c = channels_tab(ic);

	  const int LCM_projectile_c = channel_c.get_LCM_projectile ();

	  const double LCM_projectile_c_LCM_projectile_c_p1 = LCM_projectile_c * (LCM_projectile_c + 1);

	  const double kinetic_factor_projectile_c = channel_c.get_kinetic_factor_projectile ();

	  const complex<double> source_factor_kinetic_factor_projectile_c = source_factor * kinetic_factor_projectile_c;

	  const complex<double> &kc_projectile = channel_c.get_k_projectile ();

	  const complex<double> kc_projectile_square = kc_projectile*kc_projectile;

	  for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
	    {
	      if ((i >= first_ir_uniform) && (i <= last_ir_uniform))
		{
		  const double r = r_bef_R_tab_uniform(i);

		  const double r2 = r*r;

		  CC_d2wf_bef_R_tab_uniform(ic , i) = (LCM_projectile_c_LCM_projectile_c_p1/r2 - kc_projectile_square) * CC_wf_bef_R_tab_uniform(ic , i) + source_factor_kinetic_factor_projectile_c * source_c(r);
		}
	    }

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	    {
	      if ((i >= first_ir_GL) && (i <= last_ir_GL))
		{
		  const double r = r_bef_R_tab_GL(i);

		  const double r2 = r*r;

		  CC_d2wf_bef_R_tab_GL(ic , i) = (LCM_projectile_c_LCM_projectile_c_p1/r2 - kc_projectile_square) * CC_wf_bef_R_tab_GL(ic , i) + source_factor_kinetic_factor_projectile_c * source_c(r);
		}
	    }
	}
    }

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      if (!is_it_entrance_channel_only || (ic == ic_entrance))
	{
	  const class CC_channel_class &channel_c = channels_tab(ic);

	  const double kinetic_factor_projectile_c = channel_c.get_kinetic_factor_projectile ();

	  for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	    {
	      if (!is_it_entrance_channel_only || (icp == ic_entrance))
		{	
		  const class splines_class<complex<double> > &Ueq_ccp = Ueq_tab(ic , icp);

		  for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
		    {
		      if ((i >= first_ir_uniform) && (i <= last_ir_uniform))
			{
			  const double r = r_bef_R_tab_uniform(i);
			  
			  CC_d2wf_bef_R_tab_uniform(ic , i) += kinetic_factor_projectile_c * Ueq_ccp(r) * CC_wf_bef_R_tab_uniform(icp , i);
			}
		    }

		  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
		    {
		      if ((i >= first_ir_GL) && (i <= last_ir_GL))
			{
			  const double r = r_bef_R_tab_GL(i);

			  CC_d2wf_bef_R_tab_GL(ic , i) += kinetic_factor_projectile_c * Ueq_ccp(r) * CC_wf_bef_R_tab_GL(icp , i);
			}
		    }
		}
	    }
	}
    }

#ifdef UseMPI

  if (is_it_MPI_parallelized)
    {
      CC_d2wf_bef_R_tab_uniform.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
      CC_d2wf_bef_R_tab_GL.MPI_Allreduce  (MPI_SUM , MPI_COMM_WORLD);
    }

#endif
}








void CC_state_class::CC_wfs_dwfs_d2wfs_aft_R_tab_GL_calc (const bool is_it_entrance_channel_only)
{
  if (is_it_HO_projected) error_message_print_abort ("Wave function calculation after R is meaningless with HO projected functions.");

  if (!S_matrix_pole)
    {
      const class CC_channel_class &entrance_channel = channels_tab(ic_entrance);
      
      const int LCM_projectile_entrance = entrance_channel.get_LCM_projectile ();

      const complex<double> k_projectile_entrance = entrance_channel.get_k_projectile ();

      const complex<double> eta_projectile_entrance = entrance_channel.get_eta_projectile ();

      class Coulomb_wave_functions cwf_entrance (true , LCM_projectile_entrance , eta_projectile_entrance);

      complex<double>  H_minus_r = 0.0;
      complex<double> dH_minus_r = 0.0;

      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  const double r = r_aft_R_tab_GL_real(i);
	  
	  cwf_entrance.H_kz_dH_kz (-1 , k_projectile_entrance , r , H_minus_r , dH_minus_r);

	  CC_wf_aft_R_tab_GL(ic_entrance , i)  = Cminus_entrance_channel*H_minus_r;
	  CC_dwf_aft_R_tab_GL(ic_entrance , i) = Cminus_entrance_channel*dH_minus_r;
	}
    }

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      if (!is_it_entrance_channel_only || (ic == ic_entrance))
	{
	  const class CC_channel_class &channel_c = channels_tab(ic);
	  
	  const int LCM_projectile_c = channel_c.get_LCM_projectile ();

	  const int Z_Tc_charge = channel_c.get_Z_Tc_charge ();
	  
	  const enum particle_type projectile_c = channel_c.get_projectile ();
      
	  const int projectile_c_charge = particle_charge_determine (projectile_c);
      
	  const int Z_Tc_charge_times_projectile_c_charge = Z_Tc_charge*projectile_c_charge;
      
	  const double kinetic_factor_projectile_c = channel_c.get_kinetic_factor_projectile ();
	  
	  const double LCM_projectile_c_LCM_projectile_c_p1 = LCM_projectile_c * (LCM_projectile_c + 1);

	  const double LCM_projectile_c_term = 2 * LCM_projectile_c + 0.5;
	  
	  const complex<double> kc_projectile = channel_c.get_k_projectile ();

	  const complex<double> eta_projectile_c = channel_c.get_eta_projectile ();

	  const complex<double> kc_projectile_square = kc_projectile*kc_projectile;
	  
	  const complex<double> Cplus_c = Cplus_tab(ic);
	  
	  const complex<double> ILCM_projectile_c_term (0. , LCM_projectile_c_term);

	  const complex<double> norm_kc_projectile_is_zero = exp (ILCM_projectile_c_term * M_PI_2);
	  
	  const complex<double> two_I_sqrt_V_Coul_c (0. , 2. * sqrt (kinetic_factor_projectile_c * Z_Tc_charge_times_projectile_c_charge * Coulomb_constant));

	  const bool is_it_bound_case = (S_matrix_pole && (abs (real (kc_projectile)) < sqrt_precision) && (imag (kc_projectile) > sqrt_precision));
  
	  const class Coulomb_potential_class Coulomb_potential(false , projectile_c , Z_Tc_charge , NADA);
	  
	  class Coulomb_wave_functions cwf_c (true , LCM_projectile_c , eta_projectile_c);

	  class Coulomb_wave_functions cwf_zero_k_r_c (true , LCM_projectile_c_term , 0.);

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      const double r = r_aft_R_tab_GL_real(i);

	      const double r2 = r * r;

	      const double Coulomb_point_potential_r = Coulomb_potential.point_potential_calc (r);

	      if ((kc_projectile == 0) && S_matrix_pole)
		{
		  complex<double>  H_plus_c_r = 0.0;
		  complex<double> dH_plus_c_r = 0.0;

		  wf_dwf_k_is_zero (LCM_projectile_c , Z_Tc_charge_times_projectile_c_charge , two_I_sqrt_V_Coul_c , norm_kc_projectile_is_zero , cwf_zero_k_r_c , r , H_plus_c_r , dH_plus_c_r);

		  CC_wf_aft_R_tab_GL (ic , i) += Cplus_c * H_plus_c_r;
		  CC_dwf_aft_R_tab_GL(ic , i) += Cplus_c * dH_plus_c_r;
		}
	      else
		{
		  if (is_it_bound_case)
		    {
		      complex<double>  W_plus_c_r = 0.0;
		      complex<double> dW_plus_c_r = 0.0;

		      cwf_c.Wm_kz_dWm_kz (kc_projectile , r , W_plus_c_r , dW_plus_c_r);

		      CC_wf_aft_R_tab_GL (ic , i) += Cplus_c * W_plus_c_r;
		      CC_dwf_aft_R_tab_GL(ic , i) += Cplus_c * dW_plus_c_r;
		    }
		  else
		    {
		      complex<double>  H_plus_c_r = 0.0;
		      complex<double> dH_plus_c_r = 0.0;

		      cwf_c.H_kz_dH_kz (1 , kc_projectile , r , H_plus_c_r , dH_plus_c_r);

		      CC_wf_aft_R_tab_GL (ic , i) += Cplus_c * H_plus_c_r;
		      CC_dwf_aft_R_tab_GL(ic , i) += Cplus_c * dH_plus_c_r;
		    }
		}

	      CC_d2wf_aft_R_tab_GL(ic , i) = (LCM_projectile_c_LCM_projectile_c_p1/r2 - kc_projectile_square + kinetic_factor_projectile_c * Coulomb_point_potential_r) * CC_wf_aft_R_tab_GL(ic , i);
	    }
	}
    }
}








// non_orthogonality_restoration:
// _ U = (Id + O^{-1/2}).V , U=rescaled , V=not rescaled , O^{-1/2} = finite range square inverse overlap matrix
// _ Equivalent to: 
// . |U_c> = |V_c> + \sum_{cp} O^{-1/2}_{c , cp} |V_cp> , 
// . U_c(r) = V_c(r) + \sum_{cp} <r |O^{-1/2}_{c , cp}| V_cp>
// . U_c(r) = V_c(r) + \sum_{cp}\sum_{nHOc , nHOcp} <r|nHOc , c>.<nHOc , c |O^{-1/2}| nHOcp , cp>.<nHOcp , cp|V_cp> -> FORMULA USED 
// _ The part coming from the finite range operator O does not affect the asymptotic behaviour , hence only the functions bef_R are calculated. 

void CC_state_class::non_orthogonality_restoration (const class CC_Hamiltonian_data &CC_H_data) 
{
  if (is_it_HO_projected) error_message_print_abort ("Non orthogonality restoration is meaningless with HO projected functions.");

  const class array<class matrix<complex<double> > > &Delta_HO_submatrices = CC_H_data.get_Delta_HO_submatrices ();
  
  // Calculation of the HO basis states |nHOc , c> = |nHOc , LCM_projectile_c , jc>
  
  class array<double> CC_HO_wfs_bef_R_tab_uniform  (N_channels , Nmax_HO_potentials_plus_one , N_bef_R_uniform);
  class array<double> CC_HO_dwfs_bef_R_tab_uniform (N_channels , Nmax_HO_potentials_plus_one , N_bef_R_uniform);
  class array<double> CC_HO_d2wfs_bef_R_tab_uniform(N_channels , Nmax_HO_potentials_plus_one , N_bef_R_uniform);

  class array<double> CC_HO_wfs_bef_R_tab_GL  (N_channels , Nmax_HO_potentials_plus_one , N_bef_R_GL);
  class array<double> CC_HO_dwfs_bef_R_tab_GL (N_channels , Nmax_HO_potentials_plus_one , N_bef_R_GL);
  class array<double> CC_HO_d2wfs_bef_R_tab_GL(N_channels , Nmax_HO_potentials_plus_one , N_bef_R_GL);

  class array<double> CC_HO_wfs_bef_R_tab_GL_SGI_MSGI (N_channels , Nmax_HO_potentials_plus_one , N_bef_R_GL);
  class array<double> CC_HO_dwfs_bef_R_tab_GL_SGI_MSGI(N_channels , Nmax_HO_potentials_plus_one , N_bef_R_GL);

  class array<double> CC_HO_wfs_aft_R_tab_GL(N_channels , Nmax_HO_potentials_plus_one , N_aft_R_GL);

  class array<double> CC_HO_wfs_momentum_tab_uniform  (N_channels , Nmax_HO_potentials_plus_one , Nk_momentum_uniform);
  class array<double> CC_HO_dwfs_momentum_tab_uniform (N_channels , Nmax_HO_potentials_plus_one , Nk_momentum_uniform);
  
  class array<double> CC_HO_wfs_momentum_tab_GL  (N_channels , Nmax_HO_potentials_plus_one , Nk_momentum_GL);
  class array<double> CC_HO_dwfs_momentum_tab_GL (N_channels , Nmax_HO_potentials_plus_one , Nk_momentum_GL);
  
  CC_HO_wave_functions::wfs_dwfs_d2wfs_radial_calc (channels_tab , r_bef_R_tab_uniform , CC_HO_wfs_bef_R_tab_uniform , CC_HO_dwfs_bef_R_tab_uniform , CC_HO_d2wfs_bef_R_tab_uniform);
  CC_HO_wave_functions::wfs_dwfs_d2wfs_radial_calc (channels_tab , r_bef_R_tab_GL      , CC_HO_wfs_bef_R_tab_GL      , CC_HO_dwfs_bef_R_tab_GL      , CC_HO_d2wfs_bef_R_tab_GL);

  CC_HO_wave_functions::wfs_dwfs_radial_calc (channels_tab , r_bef_R_tab_GL_SGI_MSGI , CC_HO_wfs_bef_R_tab_GL_SGI_MSGI , CC_HO_dwfs_bef_R_tab_GL_SGI_MSGI);

  CC_HO_wave_functions::wfs_radial_calc (channels_tab , r_aft_R_tab_GL_real , CC_HO_wfs_aft_R_tab_GL);

  CC_HO_wave_functions::wfs_dwfs_momentum_calc (channels_tab , k_tab_uniform , CC_HO_wfs_momentum_tab_uniform , CC_HO_dwfs_momentum_tab_uniform);
  CC_HO_wave_functions::wfs_dwfs_momentum_calc (channels_tab , k_tab_GL      , CC_HO_wfs_momentum_tab_GL      , CC_HO_dwfs_momentum_tab_GL);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
    {
      const class vector_class<complex<double> > & HO_overlaps_c = HO_overlaps(ic);
      
      const int nmax_HO_c_plus_one = HO_overlaps_c.get_dimension ();

      for (int nHOc = 0 ; nHOc < nmax_HO_c_plus_one ; nHOc++) 
	{
	  complex<double> rescale_c_nHOc = 0.0;

	  for (unsigned int icp = 0 ; icp < N_channels ; icp++) 
	    {
	      const class matrix<complex<double> > &Delta_HO_submatrix_c_cp = Delta_HO_submatrices (ic , icp);
	      
	      const class vector_class<complex<double> > &HO_overlaps_cp = HO_overlaps(icp);

	      const class vector_class<complex<double> > non_orthogonality_restoration_vector_c = Delta_HO_submatrix_c_cp * HO_overlaps_cp;

	      rescale_c_nHOc += non_orthogonality_restoration_vector_c(nHOc);
	      // = <nHOc , c |O^{1/2} Delta O^{1/2}| nHOcp , cp>.<nHOcp , cp| V_cp> (see formula)
	    }

	  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	    {						
	      CC_wf_bef_R_tab_uniform  (ic , i) += CC_HO_wfs_bef_R_tab_uniform  (ic , nHOc , i) * rescale_c_nHOc;
	      CC_dwf_bef_R_tab_uniform (ic , i) += CC_HO_dwfs_bef_R_tab_uniform (ic , nHOc , i) * rescale_c_nHOc;
	      CC_d2wf_bef_R_tab_uniform(ic , i) += CC_HO_d2wfs_bef_R_tab_uniform(ic , nHOc , i) * rescale_c_nHOc;

	      CC_asymptotic_in_zero_wf_bef_R_tab_uniform(ic , i) += CC_HO_wfs_bef_R_tab_uniform(ic , nHOc , i) * rescale_c_nHOc;
	    }

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	    {
	      CC_wf_bef_R_tab_GL  (ic , i) += CC_HO_wfs_bef_R_tab_GL  (ic , nHOc , i) * rescale_c_nHOc;
	      CC_dwf_bef_R_tab_GL (ic , i) += CC_HO_dwfs_bef_R_tab_GL (ic , nHOc , i) * rescale_c_nHOc;
	      CC_d2wf_bef_R_tab_GL(ic , i) += CC_HO_d2wfs_bef_R_tab_GL(ic , nHOc , i) * rescale_c_nHOc;

	      CC_wf_bef_R_tab_GL_SGI_MSGI (ic , i) += CC_HO_wfs_bef_R_tab_GL_SGI_MSGI (ic , nHOc , i) * rescale_c_nHOc;
	      CC_dwf_bef_R_tab_GL_SGI_MSGI(ic , i) += CC_HO_dwfs_bef_R_tab_GL_SGI_MSGI(ic , nHOc , i) * rescale_c_nHOc;
	    }

	  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
	    {						
	      CC_wf_momentum_tab_uniform  (ic , i) += CC_HO_wfs_momentum_tab_uniform  (ic , nHOc , i) * rescale_c_nHOc;
	      CC_dwf_momentum_tab_uniform (ic , i) += CC_HO_dwfs_momentum_tab_uniform (ic , nHOc , i) * rescale_c_nHOc;
	    }
	  
	  for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
	    {						
	      CC_wf_momentum_tab_GL  (ic , i) += CC_HO_wfs_momentum_tab_GL  (ic , nHOc , i) * rescale_c_nHOc;
	      CC_dwf_momentum_tab_GL (ic , i) += CC_HO_dwfs_momentum_tab_GL (ic , nHOc , i) * rescale_c_nHOc;
	    }
	}
    }
}













void CC_state_class::branch_cut_correction (
					    const complex<double> &exp_two_Pi_eta_projectile_c , 
					    const complex<double> &exp_two_Pi_eta_projectile_c_minus_one , 
					    class Coulomb_wave_functions &cwf , 
					    const class array<complex<double> > &z_tab , 
					    const unsigned int ic , 
					    const unsigned int angle_index , 
					    const unsigned int i , 
					    bool &is_it_crossed , 
					    class array<complex<double> > &scaled_wfs , 
					    class array<complex<double> > &scaled_dwfs)
{
  if (is_it_HO_projected) error_message_print_abort ("Branch cut correction is meaningless with HO projected functions.");

  const unsigned int N = z_tab.dimension (0);

  const class CC_channel_class &channel_c = channels_tab(ic);

  const int Z_Tc_charge = channel_c.get_Z_Tc_charge ();

  if ((Z_Tc_charge != 0) &&  (i < N-1))
    {
      const complex<double> kc_projectile = channel_c.get_k_projectile ();

      const complex<double> eta_projectile_c = channel_c.get_eta_projectile ();
      
      const complex<double> z = z_tab(i);

      const complex<double> z_bef = z_tab(i + 1);
      
      const complex<double> kc_projectile_z     = kc_projectile*z;
      const complex<double> kc_projectile_z_bef = kc_projectile*z_bef;

      if ((real (kc_projectile_z_bef) < 0.0) && (real (kc_projectile_z) < 0.0) && (SIGN (imag (kc_projectile_z_bef)) != SIGN (imag (kc_projectile_z)))) is_it_crossed = true;

      if (is_it_crossed)
	{
	  complex<double>  H_minus    = 0.0;
	  complex<double> dH_minus_dz = 0.0;
	  
	  cwf.H_kz_dH_kz (-1 , kc_projectile , z , H_minus , dH_minus_dz);

	  const complex<double> I(0 , 1);

	  const complex<double> exp_scale = exp (-I*(kc_projectile_z - eta_projectile_c*(M_LN2 + log (kc_projectile_z))));

	  const complex<double> branch_cut_factor_minus = exp_two_Pi_eta_projectile_c_minus_one*exp_scale;

	  scaled_wfs(ic , angle_index , i)  = exp_two_Pi_eta_projectile_c*scaled_wfs(ic , angle_index , i)  - branch_cut_factor_minus*H_minus;
	  scaled_dwfs(ic , angle_index , i) = exp_two_Pi_eta_projectile_c*scaled_dwfs(ic , angle_index , i) - branch_cut_factor_minus*dH_minus_dz;
	}
    }
}











void CC_state_class::CC_out_ingoing_waves_after_R (const unsigned int angle_index)
{
  if (is_it_HO_projected) error_message_print_abort ("Complex scaling for functions after R is meaningless with HO projected functions.");

  const unsigned int N_aft_R_uniform_minus_one = N_aft_R_uniform - 1;

  const complex<double> exp_Itheta(cos_theta_tab[angle_index] , sin_theta_tab[angle_index]);

  class array<double> u_aft_R_tab_uniform(N_aft_R_uniform);

  class array<double> u_aft_R_tab_GL(N_aft_R_GL);

  class array<complex<double> > z_aft_R_tab_uniform(N_aft_R_uniform);

  class array<complex<double> > z_aft_R_tab_GL(N_aft_R_GL);

  u_aft_R_tab_uniform(0) = 0.0 , z_aft_R_tab_uniform(0) = INFINITE*exp_Itheta;

  for (unsigned int i = 1 ; i < N_aft_R_uniform ; i++)
    {
      u_aft_R_tab_uniform(i) = i*step_aft_R_uniform;

      z_aft_R_tab_uniform(i) = R + (pow (u_aft_R_tab_uniform(i) , -4) - R)*exp_Itheta;
    }
  
  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      u_aft_R_tab_GL(i) = pow (um4_aft_R_tab_GL(i) , -0.25);

      z_aft_R_tab_GL(i) = R + (um4_aft_R_tab_GL(i) - R)*exp_Itheta;
    }
  
  if (!S_matrix_pole)
    {
      const class CC_channel_class &entrance_channel = channels_tab(ic_entrance);

      const int LCM_projectile_entrance = entrance_channel.get_LCM_projectile ();

      const complex<double> k_projectile_entrance = entrance_channel.get_k_projectile ();

      const complex<double> eta_projectile_entrance = entrance_channel.get_eta_projectile ();

      class Coulomb_wave_functions cwf_entrance (true , LCM_projectile_entrance , eta_projectile_entrance);

      unsigned int iGL = N_aft_R_GL - 1;

      for (unsigned int i = N_aft_R_uniform_minus_one ; i > 0 ; i--)
	{
	  cwf_entrance.H_kz_dH_kz_scaled (-1 , k_projectile_entrance , z_aft_R_tab_uniform(i) , CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform(angle_index , i) , CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform(angle_index , i));

	  while ((iGL < N_aft_R_GL) && (u_aft_R_tab_GL(iGL) <= u_aft_R_tab_uniform(i)) && (u_aft_R_tab_GL(iGL) >= u_aft_R_tab_uniform(i-1)))
	    {
	      cwf_entrance.H_kz_dH_kz_scaled (-1 , k_projectile_entrance , z_aft_R_tab_GL(iGL) , CC_scaled_wf_minus_aft_R_c_entrance_tab_GL(angle_index , iGL) , CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL(angle_index , iGL));
	      
	      iGL--;
	    }
	}	

      cwf_entrance.H_kz_dH_kz_scaled_limit_infinite (-1 , k_projectile_entrance , CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform(angle_index , 0) , CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform(angle_index , 0));	

      for (unsigned int i = 0 ; i < N_aft_R_uniform ; i++) 
	{
	  if (!finite (CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform(angle_index , i))) 
	    CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform(angle_index , i) = CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform(angle_index , i) = 0.0;
	}

      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  if (!finite (CC_scaled_wf_minus_aft_R_c_entrance_tab_GL(angle_index , i))) 
	    CC_scaled_wf_minus_aft_R_c_entrance_tab_GL(angle_index , i) = CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL(angle_index , i) = 0.0;
	}
    }

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const int Z_Tc_charge = channel_c.get_Z_Tc_charge ();

      const double kinetic_factor_projectile_c = channel_c.get_kinetic_factor_projectile (); 

      const complex<double> kc_projectile = channel_c.get_k_projectile ();

      const complex<double> eta_projectile_c = channel_c.get_eta_projectile ();

      const complex<double> Cplus_c = Cplus_tab(ic);

      const complex<double> exp_two_Pi_eta_projectile_c = exp (2.0*M_PI*eta_projectile_c);

      const complex<double> exp_two_Pi_eta_projectile_c_minus_one = expm1 (2.0*M_PI*eta_projectile_c);

      const bool is_it_bound_case = (S_matrix_pole && (abs (real (kc_projectile)) < sqrt_precision) && (imag (kc_projectile) > sqrt_precision));
	  
      bool is_it_crossed_tab_uniform = false;

      bool is_it_crossed_tab_GL = false;

      unsigned int iGL = N_aft_R_GL - 1;

      if (S_matrix_pole && (kc_projectile == 0.0))
	{
	  const enum particle_type projectile_c = channel_c.get_projectile ();
      
	  const int projectile_c_charge = particle_charge_determine (projectile_c);
      
	  const int Z_Tc_charge_times_projectile_c_charge = Z_Tc_charge*projectile_c_charge;
      
	  const double LCM_projectile_c_term = 2.*LCM_projectile_c + 0.5;

	  const complex<double> ILCM_projectile_c_term (0. , LCM_projectile_c_term);

	  const complex<double> norm_kc_projectile_is_zero = exp (ILCM_projectile_c_term*M_PI_2);

	  const complex<double> two_I_sqrt_V_Coul_c (0. , 2.*sqrt (kinetic_factor_projectile_c*Z_Tc_charge_times_projectile_c_charge*Coulomb_constant));

	  class Coulomb_wave_functions cwf_zero_kc_projectile (true , LCM_projectile_c_term , 0.);

	  for (unsigned int i = N_aft_R_uniform_minus_one ; i > 0 ; i--)
	    { 
	      wf_dwf_k_is_zero (LCM_projectile_c , Z_Tc_charge_times_projectile_c_charge , two_I_sqrt_V_Coul_c , norm_kc_projectile_is_zero , cwf_zero_kc_projectile , z_aft_R_tab_uniform(i) , 
				CC_scaled_wf_plus_aft_R_tab_uniform(ic , angle_index , i) , CC_scaled_dwf_plus_aft_R_tab_uniform(ic , angle_index , i));

	      while ((iGL < N_aft_R_GL) && (u_aft_R_tab_GL(iGL) <= u_aft_R_tab_uniform(i)) && (u_aft_R_tab_GL(iGL) >= u_aft_R_tab_uniform(i-1)))
		wf_dwf_k_is_zero (LCM_projectile_c , Z_Tc_charge_times_projectile_c_charge , two_I_sqrt_V_Coul_c , norm_kc_projectile_is_zero , cwf_zero_kc_projectile , z_aft_R_tab_GL(iGL) , 
				  CC_scaled_wf_plus_aft_R_tab_GL(ic , angle_index , iGL) , CC_scaled_dwf_plus_aft_R_tab_GL(ic , angle_index , iGL)) , iGL--;
	    }

	  CC_scaled_wf_plus_aft_R_tab_uniform(ic , angle_index , 0) = CC_scaled_dwf_plus_aft_R_tab_uniform(ic , angle_index , 0) = 0.0;
	} 
      else
	{
	  class Coulomb_wave_functions cwf(true , LCM_projectile_c , eta_projectile_c);

	  for (unsigned int i = N_aft_R_uniform_minus_one ; i > 0 ; i--)
	    {
	      cwf.H_kz_dH_kz_scaled (1 , kc_projectile , z_aft_R_tab_uniform(i) , CC_scaled_wf_plus_aft_R_tab_uniform(ic , angle_index , i) , CC_scaled_dwf_plus_aft_R_tab_uniform(ic , angle_index , i));

	      branch_cut_correction (exp_two_Pi_eta_projectile_c , exp_two_Pi_eta_projectile_c_minus_one , cwf , z_aft_R_tab_uniform , ic , 
				     angle_index , i , is_it_crossed_tab_uniform , CC_scaled_wf_plus_aft_R_tab_uniform , CC_scaled_dwf_plus_aft_R_tab_uniform);

	      while ((iGL < N_aft_R_GL) && (u_aft_R_tab_GL(iGL) <= u_aft_R_tab_uniform(i)) && (u_aft_R_tab_GL(iGL) >= u_aft_R_tab_uniform(i-1)))
		{
		  cwf.H_kz_dH_kz_scaled (1 , kc_projectile , z_aft_R_tab_GL(iGL) , CC_scaled_wf_plus_aft_R_tab_GL(ic , angle_index , iGL) , CC_scaled_dwf_plus_aft_R_tab_GL(ic , angle_index , iGL));

		  branch_cut_correction (exp_two_Pi_eta_projectile_c , exp_two_Pi_eta_projectile_c_minus_one , cwf , z_aft_R_tab_GL , ic , 
					 angle_index , iGL , is_it_crossed_tab_GL , CC_scaled_wf_plus_aft_R_tab_GL , CC_scaled_dwf_plus_aft_R_tab_GL);

		  iGL--;
		}
	    }

	  cwf.H_kz_dH_kz_scaled_limit_infinite (1 , kc_projectile , CC_scaled_wf_plus_aft_R_tab_uniform(ic , angle_index , 0) , CC_scaled_dwf_plus_aft_R_tab_uniform(ic , angle_index , 0));
	  
	  if (is_it_crossed_tab_uniform)
	    {
	      CC_scaled_wf_plus_aft_R_tab_uniform(ic , angle_index , 0)  *= exp_two_Pi_eta_projectile_c;
	      CC_scaled_dwf_plus_aft_R_tab_uniform(ic , angle_index , 0) *= exp_two_Pi_eta_projectile_c;
	    }
	}


      if (is_it_bound_case && (kc_projectile != 0.0))
	{
	  const complex<double> Whittaker_const = Whittaker_const_calc (LCM_projectile_c , eta_projectile_c);

	  const complex<double> Cplus_c_Whittaker_const = Cplus_c*Whittaker_const;

	  for (unsigned int i = 0 ; i < N_aft_R_uniform ; i++)
	    {
	      CC_scaled_wf_plus_aft_R_tab_uniform(ic , angle_index , i)  *= Cplus_c_Whittaker_const;
	      CC_scaled_dwf_plus_aft_R_tab_uniform(ic , angle_index , i) *= Cplus_c_Whittaker_const;
	    }
	  
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      CC_scaled_wf_plus_aft_R_tab_GL(ic , angle_index , i)  *= Cplus_c_Whittaker_const;
	      CC_scaled_dwf_plus_aft_R_tab_GL(ic , angle_index , i) *= Cplus_c_Whittaker_const;
	    }
	}
      else
	{
	  for (unsigned int i = 0 ; i < N_aft_R_uniform ; i++)
	    {
	      CC_scaled_wf_plus_aft_R_tab_uniform(ic , angle_index , i)  *= Cplus_c;
	      CC_scaled_dwf_plus_aft_R_tab_uniform(ic , angle_index , i) *= Cplus_c;
	    }
	  
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      CC_scaled_wf_plus_aft_R_tab_GL(ic , angle_index , i)  *= Cplus_c;
	      CC_scaled_dwf_plus_aft_R_tab_GL(ic , angle_index , i) *= Cplus_c;
	    }
	}

      for (unsigned int i = 0 ; i < N_aft_R_uniform ; i++) 
	{
	  if (!finite (CC_scaled_wf_plus_aft_R_tab_uniform(ic , angle_index , i)))
	    {
	      CC_scaled_wf_plus_aft_R_tab_uniform(ic , angle_index , i)  = 0.0;
	      CC_scaled_dwf_plus_aft_R_tab_uniform(ic , angle_index , i) = 0.0;
	    }
	}

      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	{
	  if (!finite (CC_scaled_wf_plus_aft_R_tab_GL(ic , angle_index , i)))
	    {
	      CC_scaled_wf_plus_aft_R_tab_GL(ic , angle_index , i)  = 0.0;
	      CC_scaled_dwf_plus_aft_R_tab_GL(ic , angle_index , i) = 0.0;
	    }
	}
    }
}





complex<double> CC_state_class::overlap_OCM_core_shell_calc (
							     const class spherical_state &OCM_core_shell , 
							     const unsigned int ic) const
{
  const class array<complex<double> > &wf_OCM_core_bef_R_tab_GL = OCM_core_shell.get_wf_bef_R_tab_GL ();

  const class array<complex<double> > &wf_OCM_core_aft_R_tab_GL_real = OCM_core_shell.get_wf_aft_R_tab_GL_real ();

  complex<double> overlap_OCM_core_shell = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double w = w_bef_R_tab_GL(i);

      const complex<double> wf_r = CC_wf_bef_R_tab_GL(ic , i);

      const complex<double> wf_OCM_core_r = wf_OCM_core_bef_R_tab_GL(i);

      overlap_OCM_core_shell += w*wf_r*wf_OCM_core_r;
    }

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      const double w = w_aft_R_tab_GL_real(i);

      const complex<double> wf_r = CC_wf_aft_R_tab_GL(ic , i);

      const complex<double> wf_OCM_core_r = wf_OCM_core_aft_R_tab_GL_real(i);

      overlap_OCM_core_shell += w*wf_r*wf_OCM_core_r;
    }

  return overlap_OCM_core_shell;
}








void CC_state_class::OCM_core_channel_orthogonalize (
						     const class spherical_state &OCM_core_shell , 
						     const unsigned int ic)
{
  const enum potential_type potential = OCM_core_shell.get_potential ();

  const class array<complex<double> > &wf_OCM_core_bef_R_tab_uniform = OCM_core_shell.get_wf_bef_R_tab_uniform ();
  const class array<complex<double> > &wf_OCM_core_bef_R_tab_GL      = OCM_core_shell.get_wf_bef_R_tab_GL ();
  const class array<complex<double> > &wf_OCM_core_aft_R_tab_GL_real = OCM_core_shell.get_wf_aft_R_tab_GL_real ();

  const class array<complex<double> > &dwf_OCM_core_bef_R_tab_uniform = OCM_core_shell.get_dwf_bef_R_tab_uniform ();
  const class array<complex<double> > &dwf_OCM_core_bef_R_tab_GL      = OCM_core_shell.get_dwf_bef_R_tab_GL ();
  const class array<complex<double> > &dwf_OCM_core_aft_R_tab_GL_real = OCM_core_shell.get_dwf_aft_R_tab_GL_real ();

  const class array<complex<double> > &d2wf_OCM_core_bef_R_tab_uniform = OCM_core_shell.get_d2wf_bef_R_tab_uniform ();
  const class array<complex<double> > &d2wf_OCM_core_bef_R_tab_GL      = OCM_core_shell.get_d2wf_bef_R_tab_GL ();
  const class array<complex<double> > &d2wf_OCM_core_aft_R_tab_GL_real = OCM_core_shell.get_d2wf_aft_R_tab_GL_real ();

  const complex<double> overlap_OCM_core_shell = overlap_OCM_core_shell_calc (OCM_core_shell , ic);
  
  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
    {
      CC_wf_bef_R_tab_GL(ic , i)   -= overlap_OCM_core_shell*wf_OCM_core_bef_R_tab_GL(i);
      CC_dwf_bef_R_tab_GL(ic , i)  -= overlap_OCM_core_shell*dwf_OCM_core_bef_R_tab_GL(i);
      CC_d2wf_bef_R_tab_GL(ic , i) -= overlap_OCM_core_shell*d2wf_OCM_core_bef_R_tab_GL(i);
    }

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) 
    {   
      CC_wf_bef_R_tab_uniform(ic , i)   -= overlap_OCM_core_shell*wf_OCM_core_bef_R_tab_uniform(i);
      CC_dwf_bef_R_tab_uniform(ic , i)  -= overlap_OCM_core_shell*dwf_OCM_core_bef_R_tab_uniform(i);
      CC_d2wf_bef_R_tab_uniform(ic , i) -= overlap_OCM_core_shell*d2wf_OCM_core_bef_R_tab_uniform(i);
    }

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      CC_wf_aft_R_tab_GL(ic , i)   -= overlap_OCM_core_shell*wf_OCM_core_aft_R_tab_GL_real(i);
      CC_dwf_aft_R_tab_GL(ic , i)  -= overlap_OCM_core_shell*dwf_OCM_core_aft_R_tab_GL_real(i);
      CC_d2wf_aft_R_tab_GL(ic , i) -= overlap_OCM_core_shell*d2wf_OCM_core_aft_R_tab_GL_real(i);
    }   

  if (potential != EFFECTIVE_MASS_POTENTIAL) 
    {
      const class array<complex<double> > &wf_OCM_core_bef_R_tab_GL_SGI_MSGI = OCM_core_shell.get_wf_bef_R_tab_GL_SGI_MSGI ();
      
      const class array<complex<double> > &dwf_OCM_core_bef_R_tab_GL_SGI_MSGI = OCM_core_shell.get_dwf_bef_R_tab_GL_SGI_MSGI ();

      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	{
	  CC_wf_bef_R_tab_GL_SGI_MSGI(ic , i)  -= overlap_OCM_core_shell*wf_OCM_core_bef_R_tab_GL_SGI_MSGI(i);
	  CC_dwf_bef_R_tab_GL_SGI_MSGI(ic , i) -= overlap_OCM_core_shell*dwf_OCM_core_bef_R_tab_GL_SGI_MSGI(i);
	}
    }
}






void CC_state_class::OCM_orthogonalization (const class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj = HF_data.get_N_nlj ();

  if (N_nlj == 0) return;
	  
  const enum particle_type particle_HF = HF_data.get_particle ();

  const class array<class nlj_struct> &shells_qn_res = HF_data.get_shells_quantum_numbers_res ();

  const class array<class spherical_state> &shells_res = HF_data.get_shells_res ();

  const unsigned int N_nlj_res = shells_qn_res.dimension (0);

  for (unsigned int t = 0 ; t < N_nlj_res ; t++)
    {
      const class nlj_struct &shell_OCM_possibly_core_qn = shells_qn_res(t);

      const bool core_state = shell_OCM_possibly_core_qn.get_core_state ();

      if (core_state)
	{
	  const class spherical_state &OCM_core_shell = shells_res(t);

	  const int l_core = OCM_core_shell.get_l ();

	  const double j_core = OCM_core_shell.get_j ();
	  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
	  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	    {
	      const class CC_channel_class &channel_c = channels_tab(ic);

	      const enum particle_type particle_c = channel_c.get_projectile ();

	      const int lc = channel_c.get_LCM_projectile ();
  
	      const double jc = channel_c.get_J_projectile ();

	      if ((particle_c == particle_HF) && same_lj (lc , jc , l_core , j_core) && !are_core_basis_potentials_equal (lc , HF_data)) OCM_core_channel_orthogonalize (OCM_core_shell , ic);
	    }
	}
    }
}




void CC_state_class::wave_calculation_no_scaled_tables_no_channel_orthogonalization ( 
										     const bool is_it_entrance_channel_only , 
										     const class CC_Hamiltonian_data &CC_H_data , 
										     const class HF_nucleons_data &prot_HF_data , 
										     const class HF_nucleons_data &neut_HF_data , 
										     const class potentials_effective_mass &T)
{	
  const bool is_it_OCM_basis = prot_HF_data.get_is_it_OCM_basis ();

  is_it_HO_projected = false;

  Cminus_entrance_channel = (S_matrix_pole) ? (0.0) : (1.0);

  // Calculation of the scaled CC - wave functions

  basis_states_calc (is_it_entrance_channel_only , T);

  constants_calc (is_it_entrance_channel_only);

  CC_wf_dwf_d2wf_zero ();

  CC_wfs_dwfs_bef_R_calc (is_it_entrance_channel_only);

  CC_d2wfs_bef_R_calc (is_it_entrance_channel_only , T);

  CC_asymptotic_in_zero_wf_before_R_calc (is_it_entrance_channel_only , T);

  CC_wfs_dwfs_d2wfs_aft_R_tab_GL_calc (is_it_entrance_channel_only);

  if (is_it_OCM_basis) 
    {
      OCM_orthogonalization (prot_HF_data);
      OCM_orthogonalization (neut_HF_data);
    }

  // Calculation of the norm of the state and normalization

  const complex<double> norm = Gamow_norm_no_channel_orthogonalization ();
  
  normalization (1.0/norm);

  // Calculation of the overlaps between the CC - wfs and the HO basis states without orthogonalization

  HO_overlaps_calc (is_it_entrance_channel_only , CC_H_data);

  wfs_dwfs_momentum_calc (is_it_entrance_channel_only);
}






void CC_state_class::scaled_tables_calc ()
{
  if (are_there_scaled_wfs)
    {
      CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform  = 0.0;
      CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform = 0.0;

      CC_scaled_wf_plus_aft_R_tab_uniform  = 0.0;
      CC_scaled_dwf_plus_aft_R_tab_uniform = 0.0;

      CC_scaled_wf_minus_aft_R_c_entrance_tab_GL  = 0.0;
      CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL = 0.0;

      CC_scaled_wf_plus_aft_R_tab_GL  = 0.0;
      CC_scaled_dwf_plus_aft_R_tab_GL = 0.0;		

      for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++) CC_out_ingoing_waves_after_R (angle_index);
    }
}








void CC_state_class::wave_channel_orthogonalization (const class CC_Hamiltonian_data &CC_H_data)
{	
  if (is_it_HO_projected) error_message_print_abort ("Wave channel_orthogonalization is meaningless with HO projected functions.");
  
  non_orthogonality_restoration (CC_H_data);

  // Calculation of the norm of the state and normalization

  const complex<double> norm = Gamow_norm_with_channel_orthogonalization (CC_H_data);

  normalization (1.0/norm);
  
  // Calculation of the overlaps between the CC - wfs and the HO basis states after orthogonalization 

  HO_overlaps_calc (false , CC_H_data);
}








unsigned int CC_state_class::HF_channel_index (
					       const unsigned int ic , 
					       const class HF_nucleons_data &CC_prot_HF_data , 
					       const class HF_nucleons_data &CC_neut_HF_data) const
{ 
  const class CC_channel_class &channel_c = channels_tab(ic);

  const enum particle_type projectile_c = channel_c.get_projectile ();

  const class HF_nucleons_data &CC_HF_data = (projectile_c == PROTON) ? (CC_prot_HF_data) : (CC_neut_HF_data);

  const class array<class nlj_struct> &CC_shells_qn_HF = CC_HF_data.get_shells_quantum_numbers ();

  const class lj_table<int> &CC_prot_nmin_lj_valence_tab = CC_prot_HF_data.get_nmin_lj_valence_tab ();
  const class lj_table<int> &CC_neut_nmin_lj_valence_tab = CC_neut_HF_data.get_nmin_lj_valence_tab ();

  const int CC_prot_nmin_lj_valence_all = (CC_prot_nmin_lj_valence_tab.dimension_total () > 0) ? (CC_prot_nmin_lj_valence_tab.max ()) : (0);
  const int CC_neut_nmin_lj_valence_all = (CC_neut_nmin_lj_valence_tab.dimension_total () > 0) ? (CC_neut_nmin_lj_valence_tab.max ()) : (0);

  const int CC_nmin_lj_valence_all = max (CC_prot_nmin_lj_valence_all , CC_neut_nmin_lj_valence_all);

  const int nc = make_int (ic) + CC_nmin_lj_valence_all;

  unsigned int index = 0;

  while (CC_shells_qn_HF(index).get_n () != nc)
    {
      index++;
    }

  return index;
}








void CC_state_class::put_shells_HF (
				    class HF_nucleons_data &CC_prot_HF_data , 
				    class HF_nucleons_data &CC_neut_HF_data) const 
{
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const complex<double> kc_projectile = channel_c.get_k_projectile ();

      const complex<double> eta_projectile_c = channel_c.get_eta_projectile ();

      const complex<double> C0_c = C0_tab(ic);

      const complex<double> Cplus_c = Cplus_tab(ic);

      const unsigned int index = HF_channel_index (ic , CC_prot_HF_data , CC_neut_HF_data);

      class HF_nucleons_data &CC_HF_data = (projectile_c == PROTON) ? (CC_prot_HF_data) : (CC_neut_HF_data);

      class array<class spherical_state> &CC_shells_HF = CC_HF_data.get_shells ();

      class spherical_state &CC_shell_HF = CC_shells_HF(index);

      class array<complex<double> > &wf_bef_R_tab_uniform   = CC_shell_HF.get_wf_bef_R_tab_uniform ();
      class array<complex<double> > &dwf_bef_R_tab_uniform  = CC_shell_HF.get_dwf_bef_R_tab_uniform ();
      class array<complex<double> > &d2wf_bef_R_tab_uniform = CC_shell_HF.get_d2wf_bef_R_tab_uniform ();

      class array<complex<double> > &wf_bef_R_tab_GL   = CC_shell_HF.get_wf_bef_R_tab_GL ();
      class array<complex<double> > &dwf_bef_R_tab_GL  = CC_shell_HF.get_dwf_bef_R_tab_GL ();
      class array<complex<double> > &d2wf_bef_R_tab_GL = CC_shell_HF.get_d2wf_bef_R_tab_GL ();

      class array<complex<double> > &wf_bef_R_tab_GL_SGI_MSGI  = CC_shell_HF.get_wf_bef_R_tab_GL_SGI_MSGI ();
      class array<complex<double> > &dwf_bef_R_tab_GL_SGI_MSGI = CC_shell_HF.get_dwf_bef_R_tab_GL_SGI_MSGI ();

      class array<complex<double> > &wf_aft_R_tab_GL_real   = CC_shell_HF.get_wf_aft_R_tab_GL_real ();
      class array<complex<double> > &dwf_aft_R_tab_GL_real  = CC_shell_HF.get_dwf_aft_R_tab_GL_real ();
      class array<complex<double> > &d2wf_aft_R_tab_GL_real = CC_shell_HF.get_d2wf_aft_R_tab_GL_real ();

      CC_shell_HF.set_k (kc_projectile);
      
      CC_shell_HF.set_eta (eta_projectile_c);

      CC_shell_HF.set_C0 (C0_c);

      CC_shell_HF.set_Cplus (Cplus_c);

      CC_shell_HF.accept ();

      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	{
	  wf_bef_R_tab_uniform(i)   = CC_wf_bef_R_tab_uniform(ic , i);
	  dwf_bef_R_tab_uniform(i)  = CC_dwf_bef_R_tab_uniform(ic , i);
	  d2wf_bef_R_tab_uniform(i) = CC_d2wf_bef_R_tab_uniform(ic , i);
	}

      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  wf_bef_R_tab_GL(i)   = CC_wf_bef_R_tab_GL(ic , i);
	  dwf_bef_R_tab_GL(i)  = CC_dwf_bef_R_tab_GL(ic , i);
	  d2wf_bef_R_tab_GL(i) = CC_d2wf_bef_R_tab_GL(ic , i); 
	}

      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  wf_bef_R_tab_GL_SGI_MSGI(i)  = CC_wf_bef_R_tab_GL_SGI_MSGI(ic , i);
	  dwf_bef_R_tab_GL_SGI_MSGI(i) = CC_dwf_bef_R_tab_GL_SGI_MSGI(ic , i);
	}

      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  wf_aft_R_tab_GL_real(i)   = CC_wf_aft_R_tab_GL(ic , i);
	  dwf_aft_R_tab_GL_real(i)  = CC_dwf_aft_R_tab_GL(ic , i);
	  d2wf_aft_R_tab_GL_real(i) = CC_d2wf_aft_R_tab_GL(ic , i); 
	}
    }
}



// The part after R is correct for bound and resonant channels only.

void CC_state_class::copy_to_file (const string &file_name) const
{
  ofstream out_file(file_name.c_str ());

  out_file.precision (15);

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
    {
      out_file << r_bef_R_tab_uniform(i) << " ";

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  out_file << real (CC_wf_bef_R_tab_uniform(ic , i))   << " " << imag (CC_wf_bef_R_tab_uniform(ic , i)) << " ";
	  out_file << real (CC_dwf_bef_R_tab_uniform(ic , i))  << " " << imag (CC_dwf_bef_R_tab_uniform(ic , i)) << " ";
	  out_file << real (CC_d2wf_bef_R_tab_uniform(ic , i)) << " " << imag (CC_d2wf_bef_R_tab_uniform(ic , i)) << " ";
	}

      out_file << endl;
    }

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      out_file << r_aft_R_tab_GL_real(i) << " ";

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  out_file << real (CC_wf_aft_R_tab_GL(ic , i))   << " " << imag (CC_wf_aft_R_tab_GL(ic , i)) << " ";
	  out_file << real (CC_dwf_aft_R_tab_GL(ic , i))  << " " << imag (CC_dwf_aft_R_tab_GL(ic , i)) << " ";
	  out_file << real (CC_d2wf_aft_R_tab_GL(ic , i)) << " " << imag (CC_d2wf_aft_R_tab_GL(ic , i)) << " ";
	}

      out_file << endl;
    }
}








ostream& operator << (ostream &os , const class CC_state_class &ps)
{
  return os << "Physical state " << ps.get_n () << " "; // a modif
} 





// lowest_channel_determine:
// _ Returns reference for the channel with lowest (real) energy 

class CC_channel_class & CC_state_class::lowest_channel_determine () const 
{
  unsigned int ic_min = 0;

  double E_Tc_min = INFINITE;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const double E_Tc = real (channel_c.get_E_Tc ());

      if (E_Tc < E_Tc_min)
	{
	  E_Tc_min = E_Tc;

	  ic_min = ic;
	}
    }

  return channels_tab(ic_min);
}



















// Berggren_expansion_state_waves_bef_R_calc:
// _ Calculates the eigenstates of the Hamiltonian , from the diagonalization in the Berggren basis.
// _ Input:
// _ .. Berggren_expansion_vector : vector expressed in the Berggren basis (can be changed to its opposite to fix the phase) , 
// _ Output : 
// _ .. C0_array : contains the C0 of the eigenstate for each channel c , 
// _ .. the wfs_array : contains the wave functions of the eigenstate for each channel c and position i 




void CC_state_class::CC_waves_bef_R_from_CC_Berggren_expansion_one_nucleon_calc (
										 const class CC_Hamiltonian_data &CC_H_data , 
										 const class nucleons_data &prot_data_CC_Berggren , 
										 const class nucleons_data &neut_data_CC_Berggren , 
										 class vector_class<complex<double> > &Berggren_expansion_vector)
{
  const double CC_average_n_scat_target_projectile_max = CC_H_data.get_CC_average_n_scat_target_projectile_max ();

  const class array<bool> &is_it_forbidden_channel_CC_Berggren_tab = CC_H_data.get_is_it_forbidden_channel_CC_Berggren_tab ();

  const class array<unsigned int> &matrices_indices_CC_Berggren = CC_H_data.get_matrices_indices_CC_Berggren (); 

  const unsigned int first_ic = basic_first_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_ic = basic_last_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);

  class array<complex<double> > CC_wf_bef_R_tab_uniform_add  (N_channels , N_bef_R_uniform);
  class array<complex<double> > CC_dwf_bef_R_tab_uniform_add (N_channels , N_bef_R_uniform);
  class array<complex<double> > CC_d2wf_bef_R_tab_uniform_add(N_channels , N_bef_R_uniform);
  
  class array<complex<double> > CC_wf_bef_R_tab_GL_add  (N_channels , N_bef_R_GL);
  class array<complex<double> > CC_dwf_bef_R_tab_GL_add (N_channels , N_bef_R_GL);
  class array<complex<double> > CC_d2wf_bef_R_tab_GL_add(N_channels , N_bef_R_GL);
  
  class array<complex<double> > CC_wf_bef_R_tab_GL_SGI_MSGI_add (N_channels , N_bef_R_GL);
  class array<complex<double> > CC_dwf_bef_R_tab_GL_SGI_MSGI_add(N_channels , N_bef_R_GL);

  CC_wf_bef_R_tab_uniform_add   = 0.0;
  CC_dwf_bef_R_tab_uniform_add  = 0.0;
  CC_d2wf_bef_R_tab_uniform_add = 0.0;
  
  CC_wf_bef_R_tab_GL_add   = 0.0;
  CC_dwf_bef_R_tab_GL_add  = 0.0;
  CC_d2wf_bef_R_tab_GL_add = 0.0;

  CC_wf_bef_R_tab_GL_SGI_MSGI_add  = 0.0;
  CC_dwf_bef_R_tab_GL_SGI_MSGI_add = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const enum particle_type particle_c = channel_c.get_projectile ();

      const int lc = channel_c.get_LCM_projectile ();

      const double jc = channel_c.get_J_projectile ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const class nucleons_data &data_tau_c_CC_Berggren = (particle_c == PROTON) ? (prot_data_CC_Berggren) : (neut_data_CC_Berggren);

      const class array<class spherical_state> &shells_CC_Berggren = data_tau_c_CC_Berggren.get_shells ();

      const class nlj_table<bool> &is_it_valence_shell_tab_c_CC_Berggren = data_tau_c_CC_Berggren.get_is_it_valence_shell_tab ();

      const class lj_table<int> &nmax_lj_c_CC_Berggren = data_tau_c_CC_Berggren.get_nmax_lj_tab ();

      const class nlj_table<unsigned int> &shells_indices_tau_c_CC_Berggren = data_tau_c_CC_Berggren.get_shells_indices ();

      const int nmax_c = nmax_lj_c_CC_Berggren(lc , jc);

      complex<double> C0_c = (!S_matrix_pole && (ic == ic_entrance)) ? (C0_tab(ic)) : (0.0);

      for (int nc = 0 ; nc <= nmax_c ; nc++)
	{
	  if (is_it_valence_shell_tab_c_CC_Berggren(nc , lc , jc))
	    {
	      const unsigned int shell_index_c = shells_indices_tau_c_CC_Berggren(nc , lc , jc);

	      const class spherical_state &wfc = shells_CC_Berggren(shell_index_c);

	      const bool S_matrix_pole_nc = wfc.get_S_matrix_pole ();

	      const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	      if ((real_average_n_scat_c < CC_average_n_scat_target_projectile_max) && !is_it_forbidden_channel_CC_Berggren_tab(ic , nc))
		{
		  const complex<double> C0_c_nc = wfc.get_C0 ();

		  const unsigned int index = matrices_indices_CC_Berggren(ic , nc);

		  C0_c += Berggren_expansion_vector(index)*C0_c_nc;
		}
	    }
	}

      // To fix the phase (only for bound/resonant states) 
      if (S_matrix_pole && (ic == 0) && (real (C0_c) < 0.0))
	{
	  Berggren_expansion_vector = -Berggren_expansion_vector;
	  
	  C0_c = -C0_c;
	}

      C0_tab(ic) = C0_c;
    }

  if (last_ic < N_channels)
    {
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 		      
      for (unsigned int ic = first_ic ; ic <= last_ic ; ic++)
	{
	  const class CC_channel_class &channel_c = channels_tab(ic);

	  const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

	  const enum particle_type particle_c = channel_c.get_projectile ();

	  const int lc = channel_c.get_LCM_projectile ();

	  const double jc = channel_c.get_J_projectile ();

	  const double real_average_n_scat_Tc = real (average_n_scat_Tc);

	  const class nucleons_data &data_tau_c_CC_Berggren = (particle_c == PROTON) ? (prot_data_CC_Berggren) : (neut_data_CC_Berggren);

	  const class array<class spherical_state> &shells_CC_Berggren = data_tau_c_CC_Berggren.get_shells ();

	  const class nlj_table<bool> &is_it_valence_shell_tab_c_CC_Berggren = data_tau_c_CC_Berggren.get_is_it_valence_shell_tab ();

	  const class lj_table<int> &nmax_lj_c_CC_Berggren = data_tau_c_CC_Berggren.get_nmax_lj_tab ();

	  const class nlj_table<unsigned int> &shells_indices_tau_c_CC_Berggren = data_tau_c_CC_Berggren.get_shells_indices ();

	  const int nmax_c = nmax_lj_c_CC_Berggren(lc , jc);

	  for (int nc = 0 ; nc <= nmax_c ; nc++)
	    {
	      if (is_it_valence_shell_tab_c_CC_Berggren(nc , lc , jc))
		{
		  const unsigned int shell_index_c = shells_indices_tau_c_CC_Berggren(nc , lc , jc);

		  const class spherical_state &wfc = shells_CC_Berggren(shell_index_c);

		  const bool S_matrix_pole_nc = wfc.get_S_matrix_pole ();

		  const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

		  if ((real_average_n_scat_c < CC_average_n_scat_target_projectile_max) && !is_it_forbidden_channel_CC_Berggren_tab(ic , nc))
		    {
		      const class array<complex<double> > &wfs_c_bef_R_tab_uniform   = wfc.get_wf_bef_R_tab_uniform ();
		      const class array<complex<double> > &dwfs_c_bef_R_tab_uniform  = wfc.get_dwf_bef_R_tab_uniform ();
		      const class array<complex<double> > &d2wfs_c_bef_R_tab_uniform = wfc.get_d2wf_bef_R_tab_uniform ();

		      const class array<complex<double> > &wfs_c_bef_R_tab_GL   = wfc.get_wf_bef_R_tab_GL ();
		      const class array<complex<double> > &dwfs_c_bef_R_tab_GL  = wfc.get_dwf_bef_R_tab_GL ();
		      const class array<complex<double> > &d2wfs_c_bef_R_tab_GL = wfc.get_d2wf_bef_R_tab_GL ();

		      const class array<complex<double> > &wfs_c_bef_R_tab_GL_SGI_MSGI  = wfc.get_wf_bef_R_tab_GL_SGI_MSGI ();
		      const class array<complex<double> > &dwfs_c_bef_R_tab_GL_SGI_MSGI = wfc.get_dwf_bef_R_tab_GL_SGI_MSGI ();

		      const unsigned int index = matrices_indices_CC_Berggren(ic , nc);
		      
		      const complex<double> Berggren_expansion_component = Berggren_expansion_vector(index);

		      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
			{
			  CC_wf_bef_R_tab_uniform_add  (ic , i) += Berggren_expansion_component*wfs_c_bef_R_tab_uniform(i);
			  CC_dwf_bef_R_tab_uniform_add (ic , i) += Berggren_expansion_component*dwfs_c_bef_R_tab_uniform(i);
			  CC_d2wf_bef_R_tab_uniform_add(ic , i) += Berggren_expansion_component*d2wfs_c_bef_R_tab_uniform(i);
			}

		      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
			{
			  CC_wf_bef_R_tab_GL_add  (ic , i) += Berggren_expansion_component*wfs_c_bef_R_tab_GL(i);
			  CC_dwf_bef_R_tab_GL_add (ic , i) += Berggren_expansion_component*dwfs_c_bef_R_tab_GL(i);
			  CC_d2wf_bef_R_tab_GL_add(ic , i) += Berggren_expansion_component*d2wfs_c_bef_R_tab_GL(i);

			  CC_wf_bef_R_tab_GL_SGI_MSGI_add (ic , i) += Berggren_expansion_component*wfs_c_bef_R_tab_GL_SGI_MSGI(i);
			  CC_dwf_bef_R_tab_GL_SGI_MSGI_add(ic , i) += Berggren_expansion_component*dwfs_c_bef_R_tab_GL_SGI_MSGI(i);
			}}}}}}

#ifdef UseMPI
  
  if (is_it_MPI_parallelized)
    {
      CC_wf_bef_R_tab_uniform_add.MPI_Allreduce   (MPI_SUM , MPI_COMM_WORLD);	
      CC_dwf_bef_R_tab_uniform_add.MPI_Allreduce  (MPI_SUM , MPI_COMM_WORLD);
      CC_d2wf_bef_R_tab_uniform_add.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
      
      CC_wf_bef_R_tab_GL_add.MPI_Allreduce   (MPI_SUM , MPI_COMM_WORLD);	
      CC_dwf_bef_R_tab_GL_add.MPI_Allreduce  (MPI_SUM , MPI_COMM_WORLD);	
      CC_d2wf_bef_R_tab_GL_add.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
      
      CC_wf_bef_R_tab_GL_SGI_MSGI_add.MPI_Allreduce  (MPI_SUM , MPI_COMM_WORLD);
      CC_dwf_bef_R_tab_GL_SGI_MSGI_add.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
    }
  
#endif

  CC_wf_bef_R_tab_uniform   += CC_wf_bef_R_tab_uniform_add;
  CC_dwf_bef_R_tab_uniform  += CC_dwf_bef_R_tab_uniform_add;
  CC_d2wf_bef_R_tab_uniform += CC_d2wf_bef_R_tab_uniform_add;

  CC_wf_bef_R_tab_GL   += CC_wf_bef_R_tab_GL_add;
  CC_dwf_bef_R_tab_GL  += CC_dwf_bef_R_tab_GL_add;
  CC_d2wf_bef_R_tab_GL += CC_d2wf_bef_R_tab_GL_add;

  CC_wf_bef_R_tab_GL_SGI_MSGI += CC_wf_bef_R_tab_GL_SGI_MSGI_add;
  CC_dwf_bef_R_tab_GL_SGI_MSGI += CC_dwf_bef_R_tab_GL_SGI_MSGI_add;
}








void CC_state_class::CC_waves_bef_R_from_CC_Berggren_expansion_cluster_calc (
									     const class CC_Hamiltonian_data &CC_H_data , 
									     const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
									     class vector_class<complex<double> > &Berggren_expansion_vector)
{
  const double CC_average_n_scat_target_projectile_max = CC_H_data.get_CC_average_n_scat_target_projectile_max ();

  const class array<bool> &is_it_forbidden_channel_CC_Berggren_tab = CC_H_data.get_is_it_forbidden_channel_CC_Berggren_tab ();

  const class array<unsigned int> &matrices_indices_CC_Berggren = CC_H_data.get_matrices_indices_CC_Berggren (); 

  const unsigned int first_ic = basic_first_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_ic = basic_last_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);

  class array<complex<double> > CC_wf_bef_R_tab_uniform_add  (N_channels , N_bef_R_uniform);
  class array<complex<double> > CC_dwf_bef_R_tab_uniform_add (N_channels , N_bef_R_uniform);
  class array<complex<double> > CC_d2wf_bef_R_tab_uniform_add(N_channels , N_bef_R_uniform);
  
  class array<complex<double> > CC_wf_bef_R_tab_GL_add  (N_channels , N_bef_R_GL);
  class array<complex<double> > CC_dwf_bef_R_tab_GL_add (N_channels , N_bef_R_GL);
  class array<complex<double> > CC_d2wf_bef_R_tab_GL_add(N_channels , N_bef_R_GL);
  
  class array<complex<double> > CC_wf_bef_R_tab_GL_SGI_MSGI_add (N_channels , N_bef_R_GL);
  class array<complex<double> > CC_dwf_bef_R_tab_GL_SGI_MSGI_add(N_channels , N_bef_R_GL);

  CC_wf_bef_R_tab_uniform_add   = 0.0;
  CC_dwf_bef_R_tab_uniform_add  = 0.0;
  CC_d2wf_bef_R_tab_uniform_add = 0.0;

  CC_wf_bef_R_tab_GL_add   = 0.0;
  CC_dwf_bef_R_tab_GL_add  = 0.0;
  CC_d2wf_bef_R_tab_GL_add = 0.0;

  CC_wf_bef_R_tab_GL_SGI_MSGI_add  = 0.0;
  CC_dwf_bef_R_tab_GL_SGI_MSGI_add = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const int A_projectile_c = channel_c.get_A_projectile ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const double J_projectile_c = channel_c.get_J_projectile ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const class cluster_data &data_c_CC_Berggren = get_cluster_projectile_data (projectile_c , cluster_projectile_data_CC_Berggren_tab);

      const class cluster_data &data_c_CC_Berggren_first_cluster = get_first_cluster_data (projectile_c , cluster_projectile_data_CC_Berggren_tab);

      const class nlj_table<bool> &cluster_CM_S_matrix_poles_c_CC_Berggren = data_c_CC_Berggren.get_cluster_CM_S_matrix_poles ();

      const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c = data_c_CC_Berggren.get_Nmax_cluster_projectile_CM_tab ();

      const int NCM_max_LCM_projectile_c = Nmax_cluster_projectile_CM_tab_c(LCM_projectile_c , J_projectile_c);

      const class nlj_table<class spherical_state> &cluster_CM_shells_c = data_c_CC_Berggren.get_cluster_CM_shells ();

      const class nlj_table<class spherical_state> &cluster_CM_shells_c_first_cluster = data_c_CC_Berggren_first_cluster.get_cluster_CM_shells ();

      complex<double> C0_c = (!S_matrix_pole && (ic == ic_entrance)) ? (C0_tab(ic)) : (0.0);

      for (int NCM_c = 0 ; NCM_c <= NCM_max_LCM_projectile_c ; NCM_c++) 
	{
	  const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c_CC_Berggren(NCM_c , LCM_projectile_c , J_projectile_c);

	  const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_CC_Berggren_tab(ic , NCM_c) && (real_average_n_scat_c < CC_average_n_scat_target_projectile_max))
	    {
	      const class spherical_state &wfc_cluster = cluster_CM_shells_c(NCM_c , LCM_projectile_c , J_projectile_c);

	      const class spherical_state &wfc = (wfc_cluster.is_it_filled ()) ? (wfc_cluster) : (cluster_CM_shells_c_first_cluster(NCM_c , LCM_projectile_c , J_projectile_c));

	      const unsigned int index = matrices_indices_CC_Berggren(ic , NCM_c);

	      const complex<double> C0_c_nc = wfc.get_C0 ();

	      C0_c += Berggren_expansion_vector(index)*C0_c_nc;
	    }
	}

      // To fix the phase (only for bound/resonant states) 
      if (S_matrix_pole && (ic == 0) && (real (C0_c) < 0.0))
	{
	  Berggren_expansion_vector = -Berggren_expansion_vector;
	}

      C0_tab(ic) = C0_c;
    }

  if (last_ic < N_channels)
    {
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 		      
      for (unsigned int ic = first_ic ; ic <= last_ic ; ic++)
	{
	  const class CC_channel_class &channel_c = channels_tab(ic);

	  const enum particle_type projectile_c = channel_c.get_projectile ();

	  const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

	  const int A_projectile_c = channel_c.get_A_projectile ();

	  const int LCM_projectile_c = channel_c.get_LCM_projectile ();

	  const double J_projectile_c = channel_c.get_J_projectile ();

	  const double real_average_n_scat_Tc = real (average_n_scat_Tc);

	  const class cluster_data &data_c_CC_Berggren = get_cluster_projectile_data (projectile_c , cluster_projectile_data_CC_Berggren_tab);

	  const class cluster_data &data_c_CC_Berggren_first_cluster = get_first_cluster_data (projectile_c , cluster_projectile_data_CC_Berggren_tab);

	  const class nlj_table<bool> &cluster_CM_S_matrix_poles_c_CC_Berggren = data_c_CC_Berggren.get_cluster_CM_S_matrix_poles ();

	  const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c = data_c_CC_Berggren.get_Nmax_cluster_projectile_CM_tab ();

	  const int NCM_max_LCM_projectile_c = Nmax_cluster_projectile_CM_tab_c(LCM_projectile_c , J_projectile_c);

	  const class nlj_table<class spherical_state> &cluster_CM_shells_c = data_c_CC_Berggren.get_cluster_CM_shells ();

	  const class nlj_table<class spherical_state> &cluster_CM_shells_c_first_cluster = data_c_CC_Berggren_first_cluster.get_cluster_CM_shells ();

	  for (int NCM_c = 0 ; NCM_c <= NCM_max_LCM_projectile_c ; NCM_c++) 
	    {
	      const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c_CC_Berggren(NCM_c , LCM_projectile_c , J_projectile_c);

	      const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

	      if (!is_it_forbidden_channel_CC_Berggren_tab(ic , NCM_c) && (real_average_n_scat_c < CC_average_n_scat_target_projectile_max))
		{		
		  const class spherical_state &wfc_cluster = cluster_CM_shells_c(NCM_c , LCM_projectile_c , J_projectile_c);

		  const class spherical_state &wfc = (wfc_cluster.is_it_filled ()) ? (wfc_cluster) : (cluster_CM_shells_c_first_cluster(NCM_c , LCM_projectile_c , J_projectile_c));

		  const class array<complex<double> > &wfs_c_bef_R_tab_uniform   = wfc.get_wf_bef_R_tab_uniform ();
		  const class array<complex<double> > &dwfs_c_bef_R_tab_uniform  = wfc.get_dwf_bef_R_tab_uniform ();
		  const class array<complex<double> > &d2wfs_c_bef_R_tab_uniform = wfc.get_d2wf_bef_R_tab_uniform ();

		  const class array<complex<double> > &wfs_c_bef_R_tab_GL   = wfc.get_wf_bef_R_tab_GL ();
		  const class array<complex<double> > &dwfs_c_bef_R_tab_GL  = wfc.get_dwf_bef_R_tab_GL ();
		  const class array<complex<double> > &d2wfs_c_bef_R_tab_GL = wfc.get_d2wf_bef_R_tab_GL ();

		  const class array<complex<double> > &wfs_c_bef_R_tab_GL_SGI_MSGI  = wfc.get_wf_bef_R_tab_GL_SGI_MSGI ();
		  const class array<complex<double> > &dwfs_c_bef_R_tab_GL_SGI_MSGI = wfc.get_dwf_bef_R_tab_GL_SGI_MSGI ();

		  const unsigned int index = matrices_indices_CC_Berggren(ic , NCM_c);
		  
		  const complex<double> Berggren_expansion_component = Berggren_expansion_vector(index);

		  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
		    {
		      CC_wf_bef_R_tab_uniform_add  (ic , i) += Berggren_expansion_component*wfs_c_bef_R_tab_uniform(i);
		      CC_dwf_bef_R_tab_uniform_add (ic , i) += Berggren_expansion_component*dwfs_c_bef_R_tab_uniform(i);
		      CC_d2wf_bef_R_tab_uniform_add(ic , i) += Berggren_expansion_component*d2wfs_c_bef_R_tab_uniform(i);
		    }

		  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
		    {
		      CC_wf_bef_R_tab_GL_add  (ic , i) += Berggren_expansion_component*wfs_c_bef_R_tab_GL(i);
		      CC_dwf_bef_R_tab_GL_add (ic , i) += Berggren_expansion_component*dwfs_c_bef_R_tab_GL(i);
		      CC_d2wf_bef_R_tab_GL_add(ic , i) += Berggren_expansion_component*d2wfs_c_bef_R_tab_GL(i);

		      CC_wf_bef_R_tab_GL_SGI_MSGI_add (ic , i) += Berggren_expansion_component*wfs_c_bef_R_tab_GL_SGI_MSGI(i);
		      CC_dwf_bef_R_tab_GL_SGI_MSGI_add(ic , i) += Berggren_expansion_component*dwfs_c_bef_R_tab_GL_SGI_MSGI(i);
		    }}}}
    }

#ifdef UseMPI
  
  if (is_it_MPI_parallelized)
    {
      CC_wf_bef_R_tab_uniform_add.MPI_Allreduce   (MPI_SUM , MPI_COMM_WORLD);	
      CC_dwf_bef_R_tab_uniform_add.MPI_Allreduce  (MPI_SUM , MPI_COMM_WORLD);
      CC_d2wf_bef_R_tab_uniform_add.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
      
      CC_wf_bef_R_tab_GL_add.MPI_Allreduce   (MPI_SUM , MPI_COMM_WORLD);	
      CC_dwf_bef_R_tab_GL_add.MPI_Allreduce  (MPI_SUM , MPI_COMM_WORLD);	
      CC_d2wf_bef_R_tab_GL_add.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
      
      CC_wf_bef_R_tab_GL_SGI_MSGI_add.MPI_Allreduce  (MPI_SUM , MPI_COMM_WORLD);
      CC_dwf_bef_R_tab_GL_SGI_MSGI_add.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
    }
  
#endif

  CC_wf_bef_R_tab_uniform   += CC_wf_bef_R_tab_uniform_add;
  CC_dwf_bef_R_tab_uniform  += CC_dwf_bef_R_tab_uniform_add;
  CC_d2wf_bef_R_tab_uniform += CC_d2wf_bef_R_tab_uniform_add;

  CC_wf_bef_R_tab_GL   += CC_wf_bef_R_tab_GL_add;
  CC_dwf_bef_R_tab_GL  += CC_dwf_bef_R_tab_GL_add;
  CC_d2wf_bef_R_tab_GL += CC_d2wf_bef_R_tab_GL_add;

  CC_wf_bef_R_tab_GL_SGI_MSGI  += CC_wf_bef_R_tab_GL_SGI_MSGI_add;
  CC_dwf_bef_R_tab_GL_SGI_MSGI += CC_dwf_bef_R_tab_GL_SGI_MSGI_add;
}












void CC_state_class::CC_waves_momentum_from_CC_Berggren_expansion_one_nucleon_calc (
										    const class CC_Hamiltonian_data &CC_H_data , 
										    const class nucleons_data &prot_data_CC_Berggren , 
										    const class nucleons_data &neut_data_CC_Berggren , 
										    class vector_class<complex<double> > &Berggren_expansion_vector)
{
  const double CC_average_n_scat_target_projectile_max = CC_H_data.get_CC_average_n_scat_target_projectile_max ();

  const class array<bool> &is_it_forbidden_channel_CC_Berggren_tab = CC_H_data.get_is_it_forbidden_channel_CC_Berggren_tab ();

  const class array<unsigned int> &matrices_indices_CC_Berggren = CC_H_data.get_matrices_indices_CC_Berggren (); 

  const unsigned int first_ic = basic_first_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_ic = basic_last_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);

  class array<complex<double> > CC_wf_momentum_tab_uniform_add  (N_channels , Nk_momentum_uniform);
  class array<complex<double> > CC_dwf_momentum_tab_uniform_add (N_channels , Nk_momentum_uniform);
  
  class array<complex<double> > CC_wf_momentum_tab_GL_add  (N_channels , Nk_momentum_GL);
  class array<complex<double> > CC_dwf_momentum_tab_GL_add (N_channels , Nk_momentum_GL);

  CC_wf_momentum_tab_uniform_add   = 0.0;
  CC_dwf_momentum_tab_uniform_add  = 0.0;
  
  CC_wf_momentum_tab_GL_add   = 0.0;
  CC_dwf_momentum_tab_GL_add  = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const enum particle_type particle_c = channel_c.get_projectile ();

      const int lc = channel_c.get_LCM_projectile ();

      const double jc = channel_c.get_J_projectile ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const class nucleons_data &data_tau_c_CC_Berggren = (particle_c == PROTON) ? (prot_data_CC_Berggren) : (neut_data_CC_Berggren);

      const class array<class spherical_state> &shells_CC_Berggren = data_tau_c_CC_Berggren.get_shells ();

      const class nlj_table<bool> &is_it_valence_shell_tab_c_CC_Berggren = data_tau_c_CC_Berggren.get_is_it_valence_shell_tab ();

      const class lj_table<int> &nmax_lj_c_CC_Berggren = data_tau_c_CC_Berggren.get_nmax_lj_tab ();

      const class nlj_table<unsigned int> &shells_indices_tau_c_CC_Berggren = data_tau_c_CC_Berggren.get_shells_indices ();

      const int nmax_c = nmax_lj_c_CC_Berggren(lc , jc);

      complex<double> C0_c = (!S_matrix_pole && (ic == ic_entrance)) ? (C0_tab(ic)) : (0.0);

      for (int nc = 0 ; nc <= nmax_c ; nc++)
	{
	  if (is_it_valence_shell_tab_c_CC_Berggren(nc , lc , jc))
	    {
	      const unsigned int shell_index_c = shells_indices_tau_c_CC_Berggren(nc , lc , jc);

	      const class spherical_state &wfc = shells_CC_Berggren(shell_index_c);

	      const bool S_matrix_pole_nc = wfc.get_S_matrix_pole ();

	      const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	      if ((real_average_n_scat_c < CC_average_n_scat_target_projectile_max) && !is_it_forbidden_channel_CC_Berggren_tab(ic , nc))
		{
		  const complex<double> C0_c_nc = wfc.get_C0 ();

		  const unsigned int index = matrices_indices_CC_Berggren(ic , nc);

		  C0_c += Berggren_expansion_vector(index)*C0_c_nc;
		}
	    }
	}

      // To fix the phase (only for bound/resonant states) 
      if (S_matrix_pole && (ic == 0) && (real (C0_c) < 0.0))
	{
	  Berggren_expansion_vector = -Berggren_expansion_vector;
	  
	  C0_c = -C0_c;
	}

      C0_tab(ic) = C0_c;
    }

  if (last_ic < N_channels)
    {
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 		      
      for (unsigned int ic = first_ic ; ic <= last_ic ; ic++)
	{
	  const class CC_channel_class &channel_c = channels_tab(ic);

	  const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

	  const enum particle_type particle_c = channel_c.get_projectile ();

	  const int lc = channel_c.get_LCM_projectile ();

	  const double jc = channel_c.get_J_projectile ();

	  const double real_average_n_scat_Tc = real (average_n_scat_Tc);

	  const class nucleons_data &data_tau_c_CC_Berggren = (particle_c == PROTON) ? (prot_data_CC_Berggren) : (neut_data_CC_Berggren);

	  const class array<class spherical_state> &shells_CC_Berggren = data_tau_c_CC_Berggren.get_shells ();

	  const class nlj_table<bool> &is_it_valence_shell_tab_c_CC_Berggren = data_tau_c_CC_Berggren.get_is_it_valence_shell_tab ();

	  const class lj_table<int> &nmax_lj_c_CC_Berggren = data_tau_c_CC_Berggren.get_nmax_lj_tab ();

	  const class nlj_table<unsigned int> &shells_indices_tau_c_CC_Berggren = data_tau_c_CC_Berggren.get_shells_indices ();

	  const int nmax_c = nmax_lj_c_CC_Berggren(lc , jc);

	  for (int nc = 0 ; nc <= nmax_c ; nc++)
	    {
	      if (is_it_valence_shell_tab_c_CC_Berggren(nc , lc , jc))
		{
		  const unsigned int shell_index_c = shells_indices_tau_c_CC_Berggren(nc , lc , jc);

		  const class spherical_state &wfc = shells_CC_Berggren(shell_index_c);

		  const bool S_matrix_pole_nc = wfc.get_S_matrix_pole ();

		  const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

		  if ((real_average_n_scat_c < CC_average_n_scat_target_projectile_max) && !is_it_forbidden_channel_CC_Berggren_tab(ic , nc))
		    {
		      const class array<complex<double> > &wfs_c_momentum_tab_uniform   = wfc.get_wf_momentum_tab_uniform ();
		      const class array<complex<double> > &dwfs_c_momentum_tab_uniform  = wfc.get_dwf_momentum_tab_uniform ();

		      const class array<complex<double> > &wfs_c_momentum_tab_GL  = wfc.get_wf_momentum_tab_GL ();
		      const class array<complex<double> > &dwfs_c_momentum_tab_GL = wfc.get_dwf_momentum_tab_GL ();

		      const unsigned int index = matrices_indices_CC_Berggren(ic , nc);
		      
		      const complex<double> Berggren_expansion_component = Berggren_expansion_vector(index);

		      for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
			{
			  CC_wf_momentum_tab_uniform_add  (ic , i) += Berggren_expansion_component*wfs_c_momentum_tab_uniform(i);
			  CC_dwf_momentum_tab_uniform_add (ic , i) += Berggren_expansion_component*dwfs_c_momentum_tab_uniform(i);
			}

		      for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
			{
			  CC_wf_momentum_tab_GL_add  (ic , i) += Berggren_expansion_component*wfs_c_momentum_tab_GL(i);
			  CC_dwf_momentum_tab_GL_add (ic , i) += Berggren_expansion_component*dwfs_c_momentum_tab_GL(i);
			}}}}}}

#ifdef UseMPI
  
  if (is_it_MPI_parallelized)
    {
      CC_wf_momentum_tab_uniform_add.MPI_Allreduce   (MPI_SUM , MPI_COMM_WORLD);	
      CC_dwf_momentum_tab_uniform_add.MPI_Allreduce  (MPI_SUM , MPI_COMM_WORLD);
      
      CC_wf_momentum_tab_GL_add.MPI_Allreduce   (MPI_SUM , MPI_COMM_WORLD);	
      CC_dwf_momentum_tab_GL_add.MPI_Allreduce  (MPI_SUM , MPI_COMM_WORLD);	
    }
  
#endif

  CC_wf_momentum_tab_uniform   += CC_wf_momentum_tab_uniform_add;
  CC_dwf_momentum_tab_uniform  += CC_dwf_momentum_tab_uniform_add;

  CC_wf_momentum_tab_GL   += CC_wf_momentum_tab_GL_add;
  CC_dwf_momentum_tab_GL  += CC_dwf_momentum_tab_GL_add;
}








void CC_state_class::CC_waves_momentum_from_CC_Berggren_expansion_cluster_calc (
										const class CC_Hamiltonian_data &CC_H_data , 
										const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
										class vector_class<complex<double> > &Berggren_expansion_vector)
{
  const double CC_average_n_scat_target_projectile_max = CC_H_data.get_CC_average_n_scat_target_projectile_max ();

  const class array<bool> &is_it_forbidden_channel_CC_Berggren_tab = CC_H_data.get_is_it_forbidden_channel_CC_Berggren_tab ();

  const class array<unsigned int> &matrices_indices_CC_Berggren = CC_H_data.get_matrices_indices_CC_Berggren (); 

  const unsigned int first_ic = basic_first_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_ic = basic_last_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);

  class array<complex<double> > CC_wf_momentum_tab_uniform_add  (N_channels , Nk_momentum_uniform);
  class array<complex<double> > CC_dwf_momentum_tab_uniform_add (N_channels , Nk_momentum_uniform);
  
  class array<complex<double> > CC_wf_momentum_tab_GL_add  (N_channels , Nk_momentum_GL);
  class array<complex<double> > CC_dwf_momentum_tab_GL_add (N_channels , Nk_momentum_GL);

  CC_wf_momentum_tab_uniform_add   = 0.0;
  CC_dwf_momentum_tab_uniform_add  = 0.0;

  CC_wf_momentum_tab_GL_add   = 0.0;
  CC_dwf_momentum_tab_GL_add  = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const int A_projectile_c = channel_c.get_A_projectile ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const double J_projectile_c = channel_c.get_J_projectile ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const class cluster_data &data_c_CC_Berggren = get_cluster_projectile_data (projectile_c , cluster_projectile_data_CC_Berggren_tab);

      const class cluster_data &data_c_CC_Berggren_first_cluster = get_first_cluster_data (projectile_c , cluster_projectile_data_CC_Berggren_tab);

      const class nlj_table<bool> &cluster_CM_S_matrix_poles_c_CC_Berggren = data_c_CC_Berggren.get_cluster_CM_S_matrix_poles ();

      const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c = data_c_CC_Berggren.get_Nmax_cluster_projectile_CM_tab ();

      const int NCM_max_LCM_projectile_c = Nmax_cluster_projectile_CM_tab_c(LCM_projectile_c , J_projectile_c);

      const class nlj_table<class spherical_state> &cluster_CM_shells_c = data_c_CC_Berggren.get_cluster_CM_shells ();

      const class nlj_table<class spherical_state> &cluster_CM_shells_c_first_cluster = data_c_CC_Berggren_first_cluster.get_cluster_CM_shells ();

      complex<double> C0_c = (!S_matrix_pole && (ic == ic_entrance)) ? (C0_tab(ic)) : (0.0);

      for (int NCM_c = 0 ; NCM_c <= NCM_max_LCM_projectile_c ; NCM_c++) 
	{
	  const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c_CC_Berggren(NCM_c , LCM_projectile_c , J_projectile_c);

	  const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_CC_Berggren_tab(ic , NCM_c) && (real_average_n_scat_c < CC_average_n_scat_target_projectile_max))
	    {
	      const class spherical_state &wfc_cluster = cluster_CM_shells_c(NCM_c , LCM_projectile_c , J_projectile_c);

	      const class spherical_state &wfc = (wfc_cluster.is_it_filled ()) ? (wfc_cluster) : (cluster_CM_shells_c_first_cluster(NCM_c , LCM_projectile_c , J_projectile_c));

	      const unsigned int index = matrices_indices_CC_Berggren(ic , NCM_c);

	      const complex<double> C0_c_nc = wfc.get_C0 ();

	      C0_c += Berggren_expansion_vector(index)*C0_c_nc;
	    }
	}

      // To fix the phase (only for bound/resonant states) 
      if (S_matrix_pole && (ic == 0) && (real (C0_c) < 0.0))
	{
	  Berggren_expansion_vector = -Berggren_expansion_vector;
	}

      C0_tab(ic) = C0_c;
    }

  if (last_ic < N_channels)
    {
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 		      
      for (unsigned int ic = first_ic ; ic <= last_ic ; ic++)
	{
	  const class CC_channel_class &channel_c = channels_tab(ic);

	  const enum particle_type projectile_c = channel_c.get_projectile ();

	  const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

	  const int A_projectile_c = channel_c.get_A_projectile ();

	  const int LCM_projectile_c = channel_c.get_LCM_projectile ();

	  const double J_projectile_c = channel_c.get_J_projectile ();

	  const double real_average_n_scat_Tc = real (average_n_scat_Tc);

	  const class cluster_data &data_c_CC_Berggren = get_cluster_projectile_data (projectile_c , cluster_projectile_data_CC_Berggren_tab);

	  const class cluster_data &data_c_CC_Berggren_first_cluster = get_first_cluster_data (projectile_c , cluster_projectile_data_CC_Berggren_tab);

	  const class nlj_table<bool> &cluster_CM_S_matrix_poles_c_CC_Berggren = data_c_CC_Berggren.get_cluster_CM_S_matrix_poles ();

	  const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c = data_c_CC_Berggren.get_Nmax_cluster_projectile_CM_tab ();

	  const int NCM_max_LCM_projectile_c = Nmax_cluster_projectile_CM_tab_c(LCM_projectile_c , J_projectile_c);

	  const class nlj_table<class spherical_state> &cluster_CM_shells_c = data_c_CC_Berggren.get_cluster_CM_shells ();

	  const class nlj_table<class spherical_state> &cluster_CM_shells_c_first_cluster = data_c_CC_Berggren_first_cluster.get_cluster_CM_shells ();

	  for (int NCM_c = 0 ; NCM_c <= NCM_max_LCM_projectile_c ; NCM_c++) 
	    {
	      const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c_CC_Berggren(NCM_c , LCM_projectile_c , J_projectile_c);

	      const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

	      if (!is_it_forbidden_channel_CC_Berggren_tab(ic , NCM_c) && (real_average_n_scat_c < CC_average_n_scat_target_projectile_max))
		{		
		  const class spherical_state &wfc_cluster = cluster_CM_shells_c(NCM_c , LCM_projectile_c , J_projectile_c);

		  const class spherical_state &wfc = (wfc_cluster.is_it_filled ()) ? (wfc_cluster) : (cluster_CM_shells_c_first_cluster(NCM_c , LCM_projectile_c , J_projectile_c));

		  const class array<complex<double> > &wfs_c_momentum_tab_uniform   = wfc.get_wf_momentum_tab_uniform ();
		  const class array<complex<double> > &dwfs_c_momentum_tab_uniform  = wfc.get_dwf_momentum_tab_uniform ();

		  const class array<complex<double> > &wfs_c_momentum_tab_GL  = wfc.get_wf_momentum_tab_GL ();
		  const class array<complex<double> > &dwfs_c_momentum_tab_GL = wfc.get_dwf_momentum_tab_GL ();

		  const unsigned int index = matrices_indices_CC_Berggren(ic , NCM_c);
		  
		  const complex<double> Berggren_expansion_component = Berggren_expansion_vector(index);

		  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
		    {
		      CC_wf_momentum_tab_uniform_add  (ic , i) += Berggren_expansion_component*wfs_c_momentum_tab_uniform(i);
		      CC_dwf_momentum_tab_uniform_add (ic , i) += Berggren_expansion_component*dwfs_c_momentum_tab_uniform(i);
		    }

		  for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
		    {
		      CC_wf_momentum_tab_GL_add  (ic , i) += Berggren_expansion_component*wfs_c_momentum_tab_GL(i);
		      CC_dwf_momentum_tab_GL_add (ic , i) += Berggren_expansion_component*dwfs_c_momentum_tab_GL(i);
		    }}}}
    }

#ifdef UseMPI
  
  if (is_it_MPI_parallelized)
    {
      CC_wf_momentum_tab_uniform_add.MPI_Allreduce   (MPI_SUM , MPI_COMM_WORLD);	
      CC_dwf_momentum_tab_uniform_add.MPI_Allreduce  (MPI_SUM , MPI_COMM_WORLD);
      
      CC_wf_momentum_tab_GL_add.MPI_Allreduce   (MPI_SUM , MPI_COMM_WORLD);	
      CC_dwf_momentum_tab_GL_add.MPI_Allreduce  (MPI_SUM , MPI_COMM_WORLD);
    }
  
#endif

  CC_wf_momentum_tab_uniform   += CC_wf_momentum_tab_uniform_add;
  CC_dwf_momentum_tab_uniform  += CC_dwf_momentum_tab_uniform_add;

  CC_wf_momentum_tab_GL   += CC_wf_momentum_tab_GL_add;
  CC_dwf_momentum_tab_GL  += CC_dwf_momentum_tab_GL_add;
}














// Cplus_calc:
// _ Calculates the approximate C+ for a given outgoing channel wave function.
// _ It is chosen to be the mean of u_c(R)/H+(eta_projectile_c , kc_proj.R) and du_c(R)/dH+(eta_projectile_c , kc_proj.R) , 
// _ as in the end one should have u_c(R)=C+_c.H+(eta_projectile_c , kc_proj.R)).
// _ Input:
// _ .. uc_R , d_uc_R : values of the wave functions and derivatives at R , 
// _ .. kc_projectile , eta_projectile_c : these values gives the asymptotic behaviour H+(eta_projectile_c , kc_proj.R) , 
// _ Output:
// _ .. Cplus : the C+ found. 

void CC_state_class::Cplus_calc (const unsigned int ic)
{
  if (is_it_HO_projected) error_message_print_abort ("Cplus calculation is meaningless with HO projected functions.");

  const class CC_channel_class &channel_c = channels_tab(ic);

  const int LCM_projectile_c = channel_c.get_LCM_projectile ();

  const int Z_Tc_charge = channel_c.get_Z_Tc_charge ();

  const double kinetic_factor_projectile_c = channel_c.get_kinetic_factor_projectile ();

  const complex<double> kc_projectile = channel_c.get_k_projectile ();

  const complex<double> eta_projectile_c = channel_c.get_eta_projectile ();
  
  const bool is_it_bound_case = (S_matrix_pole && (abs (real (kc_projectile)) < sqrt_precision) && (imag (kc_projectile) > sqrt_precision));
      
  const complex<double> uc_R = CC_wf_bef_R_tab_uniform(ic , N_bef_R_uniform-1);

  if (kc_projectile == 0)
    {
      const enum particle_type projectile_c = channel_c.get_projectile ();
      
      const int projectile_c_charge = particle_charge_determine (projectile_c);
      
      const int Z_Tc_charge_times_projectile_c_charge = Z_Tc_charge*projectile_c_charge;
	  
      const double LCM_projectile_c_term = 2.*LCM_projectile_c + 0.5;

      const complex<double> ILCM_projectile_c_term (0. , LCM_projectile_c_term);

      const complex<double> norm_kc_projectile_is_zero = exp (ILCM_projectile_c_term*M_PI_2);

      const complex<double> two_I_sqrt_V_Coul_c (0. , 2.*sqrt (kinetic_factor_projectile_c*Z_Tc_charge_times_projectile_c_charge*Coulomb_constant));

      class Coulomb_wave_functions cwf_zero_kc_projectile (true , LCM_projectile_c_term , 0.);

      complex<double>  Hplus_R = 0.0;
      complex<double> dHplus_R = 0.0;

      wf_dwf_k_is_zero (LCM_projectile_c , Z_Tc_charge_times_projectile_c_charge , two_I_sqrt_V_Coul_c , norm_kc_projectile_is_zero , cwf_zero_kc_projectile , R , Hplus_R , dHplus_R);

      Cplus_tab(ic) = uc_R/Hplus_R;
    }
  else
    {
      class Coulomb_wave_functions cwf_c (true , LCM_projectile_c , eta_projectile_c);

      if (is_it_bound_case)
	{
	  complex<double>  Wm_R = 0.0;
	  complex<double> dWm_R = 0.0;

	  cwf_c.Wm_kz_dWm_kz (kc_projectile , R , Wm_R , dWm_R);

	  Cplus_tab(ic) = uc_R/Wm_R;
	}
      else
	{
	  complex<double>  Hplus_R = 0.0;
	  complex<double> dHplus_R = 0.0;

	  cwf_c.H_kz_dH_kz (1 , kc_projectile , R , Hplus_R , dHplus_R);

	  Cplus_tab(ic) = uc_R/Hplus_R;
	}
    }
}






// Cplus_Cminus_calc:
// _ Calculates the C+ and C- for a given channel wave function.
// _ they are found matching the function and derivative at R , knowing that u_c(R) = C+_c.H+(eta_projectile_c , kc_proj.R) + C-_c.H-(eta_projectile_c , kc_proj.R)).
// _ Input:
// _ .. uc_R , d_uc_R : values of the wave functions and derivatives at R , 
// _ .. kc_projectile , eta_projectile_c : these values gives the asymptotic behaviour H+(eta_projectile_c , kc_proj.R) , 
// _ Output:
// _ .. Cplus , Cminus : the C+ and C- found. 

void CC_state_class::entrance_Cplus_Cminus_calc ()
{
  if (is_it_HO_projected) error_message_print_abort ("Asymptotic constants calculation is meaningless with HO projected functions.");

  const unsigned int N_bef_R_uniform_minus_one = N_bef_R_uniform - 1;
  
  const complex<double>   uc_R = CC_wf_bef_R_tab_uniform (ic_entrance , N_bef_R_uniform_minus_one);
  const complex<double> d_uc_R = CC_dwf_bef_R_tab_uniform(ic_entrance , N_bef_R_uniform_minus_one);

  const class CC_channel_class &entrance_channel = channels_tab(ic_entrance);

  const int LCM_projectile_entrance = entrance_channel.get_LCM_projectile ();

  const complex<double> k_projectile_entrance = entrance_channel.get_k_projectile ();

  const complex<double> eta_projectile_entrance = entrance_channel.get_eta_projectile ();

  complex<double>  F = 0.0;
  complex<double> dF = 0.0;

  complex<double>  G = 0.0;
  complex<double> dG = 0.0;

  class Coulomb_wave_functions cwf_c_entrance (true , LCM_projectile_entrance , eta_projectile_entrance);

  cwf_c_entrance.F_kz_dF_kz (k_projectile_entrance , R , F , dF);
  cwf_c_entrance.G_kz_dG_kz (k_projectile_entrance , R , G , dG);

  const complex<double> Det = dF*G - F*dG;

  const complex<double> CF =  (d_uc_R*G - uc_R*dG)/Det;
  const complex<double> CG = -(d_uc_R*F - uc_R*dF)/Det;

  const complex<double> I_CF(-imag (CF) , real (CF));

  Cplus_tab(ic_entrance)  = 0.5*(CG - I_CF);
  Cminus_entrance_channel = 0.5*(CG + I_CF);
}







void CC_state_class::pole_state_waves_from_CC_Berggren_expansion_calc (
								       const class CC_target_projectile_composite_data &Tpc_data , 
								       const class CC_Hamiltonian_data &CC_H_data , 
								       const class nucleons_data &prot_data_CC_Berggren , 
								       const class nucleons_data &neut_data_CC_Berggren , 
								       const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
								       const complex<double> &eigenvalue , 
								       class vector_class<complex<double> > &Berggren_expansion_vector)
{
  const bool is_it_one_nucleon_COSM_case = Tpc_data.get_is_it_one_nucleon_COSM_case ();

  const double e_projectile_no_threshold_effect = 1.0;

  const class CC_channel_class &lowest_channel = lowest_channel_determine ();

  const double e_projectile_lowest_channel = real (lowest_channel.get_e_projectile ());

  const complex<double> E_from_diag = (e_projectile_lowest_channel < -e_projectile_no_threshold_effect) ? (real (eigenvalue)) : (eigenvalue);

  change_channels_energy (E_from_diag);

  is_E_ok = true;

  CC_wf_dwf_d2wf_zero ();		

  // Calculation of the wave functions before R and in momentum space

  if (is_it_one_nucleon_COSM_case)
    {
      CC_waves_bef_R_from_CC_Berggren_expansion_one_nucleon_calc (CC_H_data , prot_data_CC_Berggren , neut_data_CC_Berggren , Berggren_expansion_vector);

      CC_waves_momentum_from_CC_Berggren_expansion_one_nucleon_calc (CC_H_data , prot_data_CC_Berggren , neut_data_CC_Berggren , Berggren_expansion_vector);
    }
  else
    {
      CC_waves_bef_R_from_CC_Berggren_expansion_cluster_calc (CC_H_data , cluster_projectile_data_CC_Berggren_tab , Berggren_expansion_vector);
      
      CC_waves_momentum_from_CC_Berggren_expansion_cluster_calc (CC_H_data , cluster_projectile_data_CC_Berggren_tab , Berggren_expansion_vector);
    }
  
  // Filling of the C0_tab and the asymptotic wave functions before R 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const complex<double> C0_c = C0_tab(ic);

      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	{
	  const double r = r_bef_R_tab_uniform(i);

	  CC_asymptotic_in_zero_wf_bef_R_tab_uniform(ic , i) = C0_c*pow (r , LCM_projectile_c + 1);
	}
    }

  // Calculation of the Cplus and the wave functions after R 

  for (unsigned int ic = 0 ; ic < N_channels ; ic++) Cplus_calc (ic);
  
  CC_wfs_dwfs_d2wfs_aft_R_tab_GL_calc (false);
}







void CC_state_class::scat_state_waves_from_CC_Berggren_expansion_calc (
								       const class CC_target_projectile_composite_data &Tpc_data , 
								       const class CC_Hamiltonian_data &CC_H_data , 
								       const class nucleons_data &prot_data_CC_Berggren , 
								       const class nucleons_data &neut_data_CC_Berggren , 
								       const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
								       class vector_class<complex<double> > &orthogonalized_H_CC_Berggren_scat)
{
  const bool is_it_one_nucleon_COSM_case = Tpc_data.get_is_it_one_nucleon_COSM_case ();

  // Calculation of the wave functions before R and in momentum space
  
  if (is_it_one_nucleon_COSM_case)
    {
      CC_waves_bef_R_from_CC_Berggren_expansion_one_nucleon_calc (CC_H_data , prot_data_CC_Berggren , neut_data_CC_Berggren , orthogonalized_H_CC_Berggren_scat);

      CC_waves_momentum_from_CC_Berggren_expansion_one_nucleon_calc (CC_H_data , prot_data_CC_Berggren , neut_data_CC_Berggren , orthogonalized_H_CC_Berggren_scat);
    }
  else
    {
      CC_waves_bef_R_from_CC_Berggren_expansion_cluster_calc (CC_H_data , cluster_projectile_data_CC_Berggren_tab , orthogonalized_H_CC_Berggren_scat);
      
      CC_waves_momentum_from_CC_Berggren_expansion_cluster_calc (CC_H_data , cluster_projectile_data_CC_Berggren_tab , orthogonalized_H_CC_Berggren_scat);
    }

  // Filling of the C0_tab and the asymptotic wave functions before R 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();
      
      const int LCM_projectile_c_plus_one = LCM_projectile_c + 1;

      const complex<double> &C0_c = C0_tab(ic);

      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	{
	  const double r = r_bef_R_tab_uniform(i);

	  CC_asymptotic_in_zero_wf_bef_R_tab_uniform(ic , i) = C0_c*pow (r , LCM_projectile_c_plus_one);
	}
    }

  // Calculation of the Cplus , Cminus and the wave functions after R 

  for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
    {
      if (ic != ic_entrance)
	Cplus_calc (ic);
      else
	entrance_Cplus_Cminus_calc ();
    }

  CC_wfs_dwfs_d2wfs_aft_R_tab_GL_calc (false);
  
  normalization (1.0/Cminus_entrance_channel);
}








void CC_state_class::Berggren_expansion_pole_state_eigenvalue_calc (
								    const class CC_target_projectile_composite_data &Tpc_data , 
								    const class CC_Hamiltonian_data &CC_H_data , 
								    complex<double> &orthogonalized_H_eigenvalue , 
								    class vector_class<complex<double> > &orthogonalized_H_CC_Berggren_eigenvector)
{	
  const bool is_it_one_nucleon_COSM_case = Tpc_data.get_is_it_one_nucleon_COSM_case ();

  const unsigned int dimension_matrices_pole_approximation_CC_Berggren = CC_H_data.get_dimension_matrices_pole_approximation_CC_Berggren ();

  const unsigned int dimension_matrices_CC_Berggren = CC_H_data.get_dimension_matrices_CC_Berggren ();

  const class matrix<complex<double> > &orthogonalized_H_matrix_CC_Berggren = CC_H_data.get_orthogonalized_H_matrix_CC_Berggren ();
  
  class matrix<complex<double> > orthogonalized_H_matrix_pole_approximation_CC_Berggren(dimension_matrices_pole_approximation_CC_Berggren);

  orthogonalized_H_matrix_pole_approximation_CC_Berggren.assign (orthogonalized_H_matrix_CC_Berggren);

  const unsigned int N_restarts = CC_H_data.get_N_restarts ();

  const unsigned int Davidson_max_dimension = CC_H_data.get_Davidson_max_dimension ();

  const double Davidson_eigenvector_precision = CC_H_data.get_Davidson_eigenvector_precision ();

  class matrix<complex<double> > orthogonalized_H_CC_Berggren_eigenvector_matrix_pole_approximation_CC_Berggren = orthogonalized_H_matrix_pole_approximation_CC_Berggren;

  class array<complex<double> > orthogonalized_H_eigenvalues_pole_approximation_CC_Berggren(dimension_matrices_pole_approximation_CC_Berggren);

  //Diagonalization
  
  total_diagonalization::symmetric::all_eigenpairs (orthogonalized_H_CC_Berggren_eigenvector_matrix_pole_approximation_CC_Berggren , orthogonalized_H_eigenvalues_pole_approximation_CC_Berggren);
  
  const complex<double> orthogonalized_H_eigenvalue_pole_approximation = orthogonalized_H_eigenvalues_pole_approximation_CC_Berggren(n);
      
  const class vector_class<complex<double> > &orthogonalized_H_CC_Berggren_eigenvector_pole_approximation = orthogonalized_H_CC_Berggren_eigenvector_matrix_pole_approximation_CC_Berggren.eigenvector(n);

  orthogonalized_H_eigenvalue = orthogonalized_H_eigenvalue_pole_approximation;	

  orthogonalized_H_CC_Berggren_eigenvector = 0.0;

  orthogonalized_H_CC_Berggren_eigenvector.assign (orthogonalized_H_CC_Berggren_eigenvector_pole_approximation);
  
  const double relative_SVD_precision = CC_H_data.get_relative_SVD_precision ();
  
  const class matrix<complex<double> > &H_matrix = CC_H_data.get_H_matrix ();
  
  const class matrix<complex<double> > &overlaps_matrix = CC_H_data.get_overlaps_matrix ();

  class matrix<complex<double> > sqrt_inv_overlaps_matrix = overlaps_matrix;

  Moore_Penrose_sqrt_inv (sqrt_inv_overlaps_matrix , relative_SVD_precision);

  class matrix<complex<double> > orthogonalized_H_matrix_CC_Berggren_test = sqrt_inv_overlaps_matrix*H_matrix*sqrt_inv_overlaps_matrix;
    
  Davidson::iterative_diagonalization_largest_overlap<complex<double> > (false , orthogonalized_H_eigenvalues_pole_approximation_CC_Berggren , orthogonalized_H_CC_Berggren_eigenvector_matrix_pole_approximation_CC_Berggren , 
									 N_restarts , Davidson_eigenvector_precision , Davidson_max_dimension , orthogonalized_H_matrix_CC_Berggren ,
									 orthogonalized_H_eigenvalue , orthogonalized_H_CC_Berggren_eigenvector);
    
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      const string projectile_str = (is_it_one_nucleon_COSM_case) ? ("(one nucleon)") : ("(cluster)");

      const double CM_to_COSM_kinetic_factor = Tpc_data.get_CM_to_COSM_kinetic_factor ();

      const double COSM_to_lab_kinetic_factor = Tpc_data.get_COSM_to_lab_kinetic_factor ();

      const double real_E_pole_approximation = real (orthogonalized_H_eigenvalue_pole_approximation);

      const double Gamma_pole_approximation = -2000.0*imag (orthogonalized_H_eigenvalue_pole_approximation);

      const double real_E_pole_approximation_lab = real_E_pole_approximation*COSM_to_lab_kinetic_factor;

      const double real_E_pole_approximation_CM = real_E_pole_approximation/CM_to_COSM_kinetic_factor;

      const double real_E = real (orthogonalized_H_eigenvalue);

      const double Gamma = -2000.0*imag (orthogonalized_H_eigenvalue);

      const double real_E_lab = real_E*COSM_to_lab_kinetic_factor;

      const double real_E_CM = real_E/CM_to_COSM_kinetic_factor;

      cout << endl;

      cout << "Matrix dimension:" << dimension_matrices_pole_approximation_CC_Berggren << " H-channels " << J_Pi_string (BP , J) << " (" << n << ") pole state with CC Berggren pole approximation " << projectile_str << endl;
      cout << "E(COSM):" << real_E_pole_approximation << " MeV" << endl;
      cout << "E(lab):" << real_E_pole_approximation_lab << endl; 
      cout << "E(CM):" << real_E_pole_approximation_CM << endl;
      cout << "G:" << Gamma_pole_approximation << " keV" << endl << endl;

      cout << "Matrix dimension:" << dimension_matrices_CC_Berggren << " H-channels " << J_Pi_string (BP , J) << " (" << n << ") pole state in CC Berggren space " << projectile_str << endl;
      cout << "E(COSM):" << real_E << " MeV" << endl; 
      cout << "E(lab):" << real_E_lab << " MeV" << endl; 
      cout << "E(CM):" << real_E_CM << " MeV" << endl;
      cout << "G:" << Gamma << " keV" << endl << endl;
    }
}





class vector_class<complex<double> > CC_state_class::Berggren_expansion_scat_source_one_nucleon_calc (
												      const class nucleons_data &prot_data_CC_Berggren , 
												      const class nucleons_data &neut_data_CC_Berggren , 
												      const class CC_Hamiltonian_data &CC_H_data)
{
  const unsigned int dimension_matrices_CC_Berggren = CC_H_data.get_dimension_matrices_CC_Berggren ();

  const double CC_average_n_scat_target_projectile_max = CC_H_data.get_CC_average_n_scat_target_projectile_max ();

  const class array<bool> &is_it_forbidden_channel_CC_Berggren_tab = CC_H_data.get_is_it_forbidden_channel_CC_Berggren_tab ();

  const class array<unsigned int> &matrices_indices_CC_Berggren = CC_H_data.get_matrices_indices_CC_Berggren ();

  const class vector_class<complex<double> > &CC_HO_overlaps_Fermi_c_entrance = HO_overlaps_Fermi(ic_entrance); 

  const class array<class matrix<complex<double> > > &finite_range_orthogonalized_potential_HO_submatrices = CC_H_data.get_finite_range_orthogonalized_potential_HO_submatrices ();

  class vector_class<complex<double> > Berggren_expansion_source_vector(dimension_matrices_CC_Berggren);

  Berggren_expansion_source_vector = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const enum particle_type particle_c = channel_c.get_projectile ();

      const int lc = channel_c.get_LCM_projectile ();

      const double jc = channel_c.get_J_projectile ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const class nucleons_data &data_tau_c_CC_Berggren = (particle_c == PROTON) ? (prot_data_CC_Berggren) : (neut_data_CC_Berggren);

      const class nlj_table<bool> &is_it_valence_shell_tab_c_CC_Berggren = data_tau_c_CC_Berggren.get_is_it_valence_shell_tab ();

      const class lj_table<int> &nmax_lj_c_CC_Berggren = data_tau_c_CC_Berggren.get_nmax_lj_tab ();

      const class array<class nlj_struct> &shells_qn_tau_c_CC_Berggren = data_tau_c_CC_Berggren.get_shells_quantum_numbers ();

      const class nlj_table<unsigned int> &shells_indices_tau_c_CC_Berggren = data_tau_c_CC_Berggren.get_shells_indices ();

      const class array<class vector_class<complex<double> > > &HO_overlaps_Fermi_c_CC_Berggren = data_tau_c_CC_Berggren.get_HO_overlaps_Fermi ();

      const int nmax_c = nmax_lj_c_CC_Berggren(lc , jc);

      const class matrix<complex<double> > &finite_range_orthogonalized_potential_HO_submatrix_c_c_entrance = finite_range_orthogonalized_potential_HO_submatrices(ic , ic_entrance);

      const class vector_class<complex<double> > HO_MEs_Ucc_entrance_uc_entrance = finite_range_orthogonalized_potential_HO_submatrix_c_c_entrance*CC_HO_overlaps_Fermi_c_entrance;
		  
      for (int nc = 0 ; nc <= nmax_c ; nc++)
	{
	  if (is_it_valence_shell_tab_c_CC_Berggren(nc , lc , jc))
	    {
	      const unsigned int shell_index_c = shells_indices_tau_c_CC_Berggren(nc , lc , jc);

	      const class nlj_struct &shell_qn_c = shells_qn_tau_c_CC_Berggren(shell_index_c);

	      const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	      const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	      if (!is_it_forbidden_channel_CC_Berggren_tab(ic , nc) && (real_average_n_scat_c < CC_average_n_scat_target_projectile_max))
		{
		  const unsigned int index = matrices_indices_CC_Berggren(ic , nc);

		  const class vector_class<complex<double> > &HO_overlaps_Fermi_nc = HO_overlaps_Fermi_c_CC_Berggren(shell_index_c);
		  
		  Berggren_expansion_source_vector(index) = -(HO_overlaps_Fermi_nc*HO_MEs_Ucc_entrance_uc_entrance);
		}
	    }
	}
    }

  return Berggren_expansion_source_vector;
}









class vector_class<complex<double> > CC_state_class::Berggren_expansion_scat_source_cluster_calc (
												  const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
												  const class CC_Hamiltonian_data &CC_H_data)
{
  const unsigned int dimension_matrices_CC_Berggren = CC_H_data.get_dimension_matrices_CC_Berggren ();

  const double CC_average_n_scat_target_projectile_max = CC_H_data.get_CC_average_n_scat_target_projectile_max ();

  const class array<bool> &is_it_forbidden_channel_CC_Berggren_tab = CC_H_data.get_is_it_forbidden_channel_CC_Berggren_tab ();

  const class array<unsigned int> &matrices_indices_CC_Berggren = CC_H_data.get_matrices_indices_CC_Berggren ();

  const class vector_class<complex<double> > &HO_overlaps_Fermi_c_entrance = HO_overlaps_Fermi(ic_entrance); 

  const class array<class matrix<complex<double> > > &finite_range_orthogonalized_potential_HO_submatrices = CC_H_data.get_finite_range_orthogonalized_potential_HO_submatrices ();

  class vector_class<complex<double> > Berggren_expansion_source_vector(dimension_matrices_CC_Berggren);

  Berggren_expansion_source_vector = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const int A_projectile_c = channel_c.get_A_projectile ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const double J_projectile_c = channel_c.get_J_projectile ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const class cluster_data &data_c_CC_Berggren = get_cluster_projectile_data (projectile_c , cluster_projectile_data_CC_Berggren_tab);

      const class nlj_table<bool> &cluster_CM_S_matrix_poles_c_CC_Berggren = data_c_CC_Berggren.get_cluster_CM_S_matrix_poles ();

      const class lj_table<int> &Nmax_cluster_projectile_CM_CC_Berggren_tab_c = data_c_CC_Berggren.get_Nmax_cluster_projectile_CM_tab ();

      const int NCM_max_LCM_projectile_c = Nmax_cluster_projectile_CM_CC_Berggren_tab_c(LCM_projectile_c , J_projectile_c);

      const class matrix<complex<double> > &finite_range_orthogonalized_potential_HO_submatrix_c_c_entrance = finite_range_orthogonalized_potential_HO_submatrices(ic , ic_entrance);

      const class vector_class<complex<double> > HO_MEs_Ucc_entrance_uc_entrance = finite_range_orthogonalized_potential_HO_submatrix_c_c_entrance*HO_overlaps_Fermi_c_entrance;
      
      const class nlj_table<class vector_class<complex<double> > > &HO_overlaps_Fermi_cluster_CM_c = data_c_CC_Berggren.get_HO_overlaps_Fermi_cluster_CM ();

      for (int NCM_c = 0 ; NCM_c <= NCM_max_LCM_projectile_c ; NCM_c++) 
	{	
	  const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c_CC_Berggren(NCM_c , LCM_projectile_c , J_projectile_c);

	  const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_CC_Berggren_tab(ic , NCM_c) && (real_average_n_scat_c < CC_average_n_scat_target_projectile_max))
	    {	
	      const unsigned int index = matrices_indices_CC_Berggren(ic , NCM_c);

	      const class vector_class<complex<double> > &HO_overlaps_Fermi_cluster_NCM_LCM_projectile_c = HO_overlaps_Fermi_cluster_CM_c(NCM_c , LCM_projectile_c , J_projectile_c);
	      
	      Berggren_expansion_source_vector(index) = -(HO_overlaps_Fermi_cluster_NCM_LCM_projectile_c*HO_MEs_Ucc_entrance_uc_entrance);
	    }
	}
    }

  return Berggren_expansion_source_vector;
}










class vector_class<complex<double> > CC_state_class::Berggren_expansion_scat_state_calc (
											 const class CC_target_projectile_composite_data &Tpc_data , 
											 const class nucleons_data &prot_data_CC_Berggren , 
											 const class nucleons_data &neut_data_CC_Berggren , 
											 const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
											 const class CC_Hamiltonian_data &CC_H_data)
{
  const bool is_it_one_nucleon_COSM_case = Tpc_data.get_is_it_one_nucleon_COSM_case ();

  const unsigned int dimension_matrices_CC_Berggren = CC_H_data.get_dimension_matrices_CC_Berggren ();

  class vector_class<complex<double> > Berggren_expansion_source_vector = (is_it_one_nucleon_COSM_case) 
    ? (Berggren_expansion_scat_source_one_nucleon_calc (prot_data_CC_Berggren , neut_data_CC_Berggren , CC_H_data)) 
    : (Berggren_expansion_scat_source_cluster_calc (cluster_projectile_data_CC_Berggren_tab , CC_H_data));

  const string one_nucleon_case_string = (is_it_one_nucleon_COSM_case) ? ("(one nucleon)") : ("(cluster)");

  if (THIS_PROCESS == MASTER_PROCESS)	
    cout << endl << "Matrix dimension:" << dimension_matrices_CC_Berggren << " H-channels " << J_Pi_string (BP , J) << " scattering state in CC Berggren space : E:" << E << " MeV " << one_nucleon_case_string << endl << endl;
  
  if (dimension_matrices_CC_Berggren > 1000)
    {
      OpenMP_parallelization_linear_algebra_enabled ();

      MPI_parallelization_linear_algebra_enabled ();
    }

  const class matrix<complex<double> > &orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren = CC_H_data.get_orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren ();

  const class matrix<complex<double> > &orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren = CC_H_data.get_orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren ();

  const class array<complex<double> > H_minus_E_diagonal_tab = CC_H_data.get_orthogonalized_H_tridiagonalized_diagonal_CC_Berggren () - E;

  const class array<complex<double> > &H_off_diagonal_tab = CC_H_data.get_orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren ();
  
  const class vector_class<complex<double> > P_Berggren_expansion_source_vector = orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren*Berggren_expansion_source_vector;
  
  const class vector_class<complex<double> > P_Berggren_expansion_scat_state = tridiagonal_linear_system_solution (H_off_diagonal_tab , H_minus_E_diagonal_tab , H_off_diagonal_tab , P_Berggren_expansion_source_vector);
  
  const class vector_class<complex<double> > Berggren_expansion_scat_state = orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren*P_Berggren_expansion_scat_state;
  
  OpenMP_parallelization_linear_algebra_disabled ();

  MPI_parallelization_linear_algebra_disabled ();

  return Berggren_expansion_scat_state;
}








void CC_state_class::Berggren_Green_function_CC_waves_no_scaled_tables_calc (
									     const class CC_target_projectile_composite_data &Tpc_data , 
									     const class nucleons_data &prot_data_CC_Berggren , 
									     const class nucleons_data &neut_data_CC_Berggren , 
									     const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
									     const class CC_Hamiltonian_data &CC_H_data)
{
  const unsigned int dimension_matrices_CC_Berggren = CC_H_data.get_dimension_matrices_CC_Berggren ();

  // Calculation of the CC-wave functions if the CC state is bound or resonant 
  if (S_matrix_pole)
    {
      const unsigned int dimension_matrices_pole_approximation_CC_Berggren = CC_H_data.get_dimension_matrices_pole_approximation_CC_Berggren ();

      if (make_uns_int (n) >= dimension_matrices_pole_approximation_CC_Berggren)
	error_message_print_abort ("Not enough coupled-channel pole states for n=" + make_string<int> (n) + " with " + J_Pi_string (BP , J) +
				   " coupled-channel states in CC_state_class::Berggren_Green_function_CC_waves_no_scaled_tables_calc");

      complex<double> orthogonalized_H_eigenvalue = 0.0;

      class vector_class<complex<double> > orthogonalized_H_CC_Berggren_eigenvector(dimension_matrices_CC_Berggren);

      Berggren_expansion_pole_state_eigenvalue_calc (Tpc_data , CC_H_data , orthogonalized_H_eigenvalue , orthogonalized_H_CC_Berggren_eigenvector);

      pole_state_waves_from_CC_Berggren_expansion_calc (Tpc_data , CC_H_data , prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_projectile_data_CC_Berggren_tab ,
							orthogonalized_H_eigenvalue , orthogonalized_H_CC_Berggren_eigenvector);
 
      class array<complex<double> > Gamow_partial_squared_norms(N_channels);
	  
      for (unsigned int ic = 0 ; ic < N_channels ; ic++) Gamow_partial_squared_norms(ic) = Gamow_partial_squared_norm_no_channel_orthogonalization (ic);

      const complex<double> squared_norm = Gamow_partial_squared_norms.sum ();

      Gamow_partial_squared_norms /= squared_norm;

      normalization (1.0/sqrt (squared_norm));
	  
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  cout << endl;

	  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	    {
	      const class CC_channel_class &channel_c = channels_tab(ic);
	  
	      const complex<double> kc_projectile = channel_c.get_k_projectile ();

	      const complex<double> ec_projectile = channel_c.get_e_projectile ();

	      const complex<double> Cplus_c = Cplus_tab(ic);

	      if (inf_norm (Cplus_c) < 100.0) cout << channel_c << " e[c]:" << ec_projectile << " k[c](if bound/resonance):" << kc_projectile << " C+[c]:" << Cplus_c << endl;
	    }

	  cout << endl << endl;
	  
	  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	    {
	      const class CC_channel_class &channel_c = channels_tab(ic);

	      cout << "Orthogonalized channel " << channel_c << " occupation probability : " << Gamow_partial_squared_norms(ic) << endl;
	    }

	  cout << endl << endl;
	  
	  copy_to_file ("CC_res_wf_" + J_Pi_vector_index_string_for_file_name (BP , J , n) + ".dat");
	}
    }
  // Calculation of the approximate wave functions if the CC state is a scattering state 
  else
    {
      class vector_class<complex<double> > orthogonalized_H_CC_Berggren_scat = Berggren_expansion_scat_state_calc (Tpc_data , prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_projectile_data_CC_Berggren_tab , CC_H_data);

      scat_state_waves_from_CC_Berggren_expansion_calc (Tpc_data , CC_H_data , prot_data_CC_Berggren , neut_data_CC_Berggren ,  cluster_projectile_data_CC_Berggren_tab , orthogonalized_H_CC_Berggren_scat);      
    }	

  A0_tab = 1.0;

  Aplus_tab = 1.0;	

  // Calculation of the overlaps between the CC-wfs and the HO basis states without orthogonalization

  HO_overlaps_calc (false , CC_H_data);

  if (THIS_PROCESS == MASTER_PROCESS) cout << "Green function solution calculated" << endl << endl;
}












//--// change the u_c (r) by their projection in an HO basis
void CC_state_class::CC_HO_wfs_projection ()
{
  is_it_HO_projected = true;

  // Calculation of the HO basis states |nHOc , c> = |nHOc , LCM_projectile_c , jc>
  class array<double> CC_HO_wfs_bef_R_tab_uniform  (N_channels , Nmax_HO_potentials_plus_one , N_bef_R_uniform); 
  class array<double> CC_HO_dwfs_bef_R_tab_uniform (N_channels , Nmax_HO_potentials_plus_one , N_bef_R_uniform); 
  class array<double> CC_HO_d2wfs_bef_R_tab_uniform(N_channels , Nmax_HO_potentials_plus_one , N_bef_R_uniform);

  class array<double> CC_HO_wfs_bef_R_tab_GL  (N_channels , Nmax_HO_potentials_plus_one , N_bef_R_GL); 
  class array<double> CC_HO_dwfs_bef_R_tab_GL (N_channels , Nmax_HO_potentials_plus_one , N_bef_R_GL); 
  class array<double> CC_HO_d2wfs_bef_R_tab_GL(N_channels , Nmax_HO_potentials_plus_one , N_bef_R_GL);

  class array<double> CC_HO_wfs_bef_R_tab_GL_SGI_MSGI (N_channels , Nmax_HO_potentials_plus_one , N_bef_R_GL); 
  class array<double> CC_HO_dwfs_bef_R_tab_GL_SGI_MSGI(N_channels , Nmax_HO_potentials_plus_one , N_bef_R_GL);

  class array<double> CC_HO_wfs_aft_R_tab_GL  (N_channels , Nmax_HO_potentials_plus_one , N_aft_R_GL); 
  class array<double> CC_HO_dwfs_aft_R_tab_GL (N_channels , Nmax_HO_potentials_plus_one , N_aft_R_GL);
  class array<double> CC_HO_d2wfs_aft_R_tab_GL(N_channels , Nmax_HO_potentials_plus_one , N_aft_R_GL);

  CC_HO_wave_functions::wfs_dwfs_d2wfs_radial_calc (channels_tab , r_bef_R_tab_uniform , CC_HO_wfs_bef_R_tab_uniform , CC_HO_dwfs_bef_R_tab_uniform , CC_HO_d2wfs_bef_R_tab_uniform);
  CC_HO_wave_functions::wfs_dwfs_d2wfs_radial_calc (channels_tab , r_bef_R_tab_GL      , CC_HO_wfs_bef_R_tab_GL      , CC_HO_dwfs_bef_R_tab_GL      , CC_HO_d2wfs_bef_R_tab_GL);
  
  CC_HO_wave_functions::wfs_dwfs_radial_calc (channels_tab , r_bef_R_tab_GL_SGI_MSGI , CC_HO_wfs_bef_R_tab_GL_SGI_MSGI , CC_HO_dwfs_bef_R_tab_GL_SGI_MSGI);

  CC_HO_wave_functions::wfs_dwfs_d2wfs_radial_calc (channels_tab , r_aft_R_tab_GL_real , CC_HO_wfs_aft_R_tab_GL , CC_HO_dwfs_aft_R_tab_GL , CC_HO_d2wfs_aft_R_tab_GL);

  CC_wf_dwf_d2wf_zero ();

  //--// for each channel
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {	
      const class vector_class<complex<double> > & HO_overlaps_c = HO_overlaps(ic);

      const int nmax_HO_c_plus_one = HO_overlaps_c.get_dimension ();

      //--// r_bef_R_tab_uniform
      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	{
	  complex<double> CC_wf_bef_R_tab_uniform_ic_i   = 0.0;
	  complex<double> CC_dwf_bef_R_tab_uniform_ic_i  = 0.0;
	  complex<double> CC_d2wf_bef_R_tab_uniform_ic_i = 0.0;

	  for (int nHOc = 0 ; nHOc < nmax_HO_c_plus_one ; nHOc++)
	    {
	      CC_wf_bef_R_tab_uniform_ic_i   += CC_HO_wfs_bef_R_tab_uniform   (ic , nHOc , i) * HO_overlaps_c (nHOc);
	      CC_dwf_bef_R_tab_uniform_ic_i  += CC_HO_dwfs_bef_R_tab_uniform  (ic , nHOc , i) * HO_overlaps_c (nHOc);
	      CC_d2wf_bef_R_tab_uniform_ic_i += CC_HO_d2wfs_bef_R_tab_uniform (ic , nHOc , i) * HO_overlaps_c (nHOc);
	    }

	  CC_wf_bef_R_tab_uniform  (ic , i) = CC_wf_bef_R_tab_uniform_ic_i;
	  CC_dwf_bef_R_tab_uniform (ic , i) = CC_dwf_bef_R_tab_uniform_ic_i;
	  CC_d2wf_bef_R_tab_uniform(ic , i) = CC_d2wf_bef_R_tab_uniform_ic_i;
	}

      //--// r_bef_R_tab_GL
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  complex<double> CC_wf_bef_R_tab_GL_ic_i   = 0.0;
	  complex<double> CC_dwf_bef_R_tab_GL_ic_i  = 0.0;
	  complex<double> CC_d2wf_bef_R_tab_GL_ic_i = 0.0;

	  for (int nHOc = 0 ; nHOc < nmax_HO_c_plus_one ; nHOc++)
	    {
	      CC_wf_bef_R_tab_GL_ic_i   += CC_HO_wfs_bef_R_tab_GL   (ic , nHOc , i) * HO_overlaps_c (nHOc);
	      CC_dwf_bef_R_tab_GL_ic_i  += CC_HO_dwfs_bef_R_tab_GL  (ic , nHOc , i) * HO_overlaps_c (nHOc);
	      CC_d2wf_bef_R_tab_GL_ic_i += CC_HO_d2wfs_bef_R_tab_GL (ic , nHOc , i) * HO_overlaps_c (nHOc);
	    }

	  CC_wf_bef_R_tab_GL  (ic , i) = CC_wf_bef_R_tab_GL_ic_i;
	  CC_dwf_bef_R_tab_GL (ic , i) = CC_dwf_bef_R_tab_GL_ic_i;
	  CC_d2wf_bef_R_tab_GL(ic , i) = CC_d2wf_bef_R_tab_GL_ic_i;
	}

      //--// r_bef_R_tab_GL (MSGI --> the range is different compare to the previous case)
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  complex<double> CC_wf_bef_R_tab_GL_SGI_MSGI_ic_i  = 0.0;
	  complex<double> CC_dwf_bef_R_tab_GL_SGI_MSGI_ic_i = 0.0;

	  for (int nHOc = 0 ; nHOc < nmax_HO_c_plus_one ; nHOc++)
	    {
	      CC_wf_bef_R_tab_GL_SGI_MSGI_ic_i  += CC_HO_wfs_bef_R_tab_GL_SGI_MSGI  (ic , nHOc , i) * HO_overlaps_c (nHOc);
	      CC_dwf_bef_R_tab_GL_SGI_MSGI_ic_i += CC_HO_dwfs_bef_R_tab_GL_SGI_MSGI (ic , nHOc , i) * HO_overlaps_c (nHOc);
	    }

	  CC_wf_bef_R_tab_GL_SGI_MSGI(ic , i)  = CC_wf_bef_R_tab_GL_SGI_MSGI_ic_i;
	  CC_dwf_bef_R_tab_GL_SGI_MSGI(ic , i) = CC_dwf_bef_R_tab_GL_SGI_MSGI_ic_i;
	}

      //--// r_aft_R_tab_GL
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  complex<double> CC_wf_aft_R_tab_GL_ic_i   = 0.0;
	  complex<double> CC_dwf_aft_R_tab_GL_ic_i  = 0.0;
	  complex<double> CC_d2wf_aft_R_tab_GL_ic_i = 0.0;

	  for (int nHOc = 0 ; nHOc < nmax_HO_c_plus_one ; nHOc++)
	    {
	      CC_wf_aft_R_tab_GL_ic_i   += CC_HO_wfs_aft_R_tab_GL   (ic , nHOc , i) * HO_overlaps_c (nHOc);
	      CC_dwf_aft_R_tab_GL_ic_i  += CC_HO_dwfs_aft_R_tab_GL  (ic , nHOc , i) * HO_overlaps_c (nHOc);
	      CC_d2wf_aft_R_tab_GL_ic_i += CC_HO_d2wfs_aft_R_tab_GL (ic , nHOc , i) * HO_overlaps_c (nHOc);
	    }

	  CC_wf_aft_R_tab_GL  (ic , i) = CC_wf_aft_R_tab_GL_ic_i;
	  CC_dwf_aft_R_tab_GL (ic , i) = CC_dwf_aft_R_tab_GL_ic_i;
	  CC_d2wf_aft_R_tab_GL(ic , i) = CC_d2wf_aft_R_tab_GL_ic_i;
	}
    }
}















//
// _ Overlaps between the channel wave functions and the harmonic oscillator functions 

void CC_state_class::HO_overlaps_calc (
				       const bool is_it_entrance_channel_only ,
				       const class CC_Hamiltonian_data &CC_H_data)
{ 
  const double R_cut_function = CC_H_data.get_R_cut_function ();
  const double d_cut_function = CC_H_data.get_d_cut_function ();

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      if (!is_it_entrance_channel_only || (ic == ic_entrance))
	{
	  const class array<double> &HO_wfs_bef_R_tab_GL = CC_H_data.get_HO_wfs_bef_R_tab_GL ();
	  const class array<double> &HO_wfs_aft_R_tab_GL = CC_H_data.get_HO_wfs_aft_R_tab_GL ();

	  class vector_class<complex<double> > & HO_overlaps_c       = HO_overlaps(ic);
	  class vector_class<complex<double> > & HO_overlaps_Fermi_c = HO_overlaps_Fermi(ic);

	  const int nmax_HO_c = HO_overlaps_c.get_dimension () - 1;

	  for (int nHOc = 0 ; nHOc <= nmax_HO_c ; nHOc++)
	    {
	      complex<double> HO_overlap_nHOc       = 0.0;
	      complex<double> HO_overlap_Fermi_nHOc = 0.0;

	      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
		{
		  const double r = r_bef_R_tab_GL(i);

		  const double Fermi_r = Fermi_like_function (R_cut_function , d_cut_function , r);

		  const complex<double> wfs_w_product = HO_wfs_bef_R_tab_GL(ic , nHOc , i)*CC_wf_bef_R_tab_GL(ic , i)*w_bef_R_tab_GL(i);
		  
		  HO_overlap_nHOc       += wfs_w_product;
		  HO_overlap_Fermi_nHOc += wfs_w_product*Fermi_r;
		}

	      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
		{
		  const double r = r_aft_R_tab_GL_real(i);

		  const double Fermi_r = Fermi_like_function (R_cut_function , d_cut_function , r);

		  const complex<double> wfs_w_product = HO_wfs_aft_R_tab_GL(ic , nHOc , i)*CC_wf_aft_R_tab_GL(ic , i)*w_aft_R_tab_GL_real(i);

		  HO_overlap_nHOc       += wfs_w_product;
		  HO_overlap_Fermi_nHOc += wfs_w_product*Fermi_r;
		}

	      HO_overlaps_c(nHOc)       = HO_overlap_nHOc;
	      HO_overlaps_Fermi_c(nHOc) = HO_overlap_Fermi_nHOc;
	    }
	}
    }
}



void CC_state_class::wfs_dwfs_momentum_calc (const bool is_it_entrance_channel_only)
{
  if (kmax_momentum == 0.0) error_message_print_abort ("kmax_momentum must be positive to use spherical_state::wave_calculation_momentum");
    
  if (R_Fermi_momentum == 0.0) error_message_print_abort ("R_Fermi_momentum must be positive to use spherical_state::wave_calculation_momentum");

  if (R_max == 0.0) error_message_print_abort ("R_real_max must be positive to use spherical_state::wave_calculation_momentum");
    
  if (inf_norm (CC_wf_bef_R_tab_GL(0 , 0)) > SQRT_INFINITE) error_message_print_abort ("The wave function must have been calculated in radial space in order to calculate it in momentum space in spherical_state::wave_calculation_momentum");

  const double d_Fermi_momentum = 10.0;
  
  const int Nmax_HO = 40;
  
  const int Nmax_HO_plus_one = Nmax_HO + 1;
  
  class array<double> CC_HO_wfs_bef_R_tab_GL  (N_channels , Nmax_HO_plus_one , N_bef_R_GL);
  class array<double> CC_HO_wfs_aft_R_tab_GL  (N_channels , Nmax_HO_plus_one , N_aft_R_GL);
  
  class array<double> CC_HO_wfs_momentum_tab_uniform  (N_channels , Nmax_HO_plus_one , Nk_momentum_uniform);
  class array<double> CC_HO_dwfs_momentum_tab_uniform (N_channels , Nmax_HO_plus_one , Nk_momentum_uniform);
  
  class array<double> CC_HO_wfs_momentum_tab_GL  (N_channels , Nmax_HO_plus_one , Nk_momentum_GL);
  class array<double> CC_HO_dwfs_momentum_tab_GL (N_channels , Nmax_HO_plus_one , Nk_momentum_GL);
  
  CC_HO_wave_functions::wfs_radial_calc (channels_tab , r_bef_R_tab_GL      , CC_HO_wfs_bef_R_tab_GL);
  CC_HO_wave_functions::wfs_radial_calc (channels_tab , r_aft_R_tab_GL_real , CC_HO_wfs_aft_R_tab_GL);
  
  CC_HO_wave_functions::wfs_dwfs_momentum_calc (channels_tab , k_tab_uniform , CC_HO_wfs_momentum_tab_uniform , CC_HO_dwfs_momentum_tab_uniform);
  CC_HO_wave_functions::wfs_dwfs_momentum_calc (channels_tab , k_tab_GL      , CC_HO_wfs_momentum_tab_GL      , CC_HO_dwfs_momentum_tab_GL);
  
  CC_wf_momentum_tab_uniform  = 0.0;
  CC_dwf_momentum_tab_uniform = 0.0;

  CC_wf_momentum_tab_GL  = 0.0;
  CC_dwf_momentum_tab_GL = 0.0;
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      if (!is_it_entrance_channel_only || (ic == ic_entrance))
	{
	  class array<complex<double> > wf_Fermi_w_bef_R_tab_GL (N_bef_R_GL);  
	  class array<complex<double> > wf_Fermi_w_aft_R_tab_GL (N_aft_R_GL);
  
	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) wf_Fermi_w_bef_R_tab_GL(i) = Fermi_like_function (R_Fermi_momentum , d_Fermi_momentum , r_bef_R_tab_GL(i))     *CC_wf_bef_R_tab_GL(ic , i)*w_bef_R_tab_GL(i);
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) wf_Fermi_w_aft_R_tab_GL(i) = Fermi_like_function (R_Fermi_momentum , d_Fermi_momentum , r_aft_R_tab_GL_real(i))*CC_wf_aft_R_tab_GL(ic , i)*w_aft_R_tab_GL_real(i);
  
	  for (int nHO = 0 ; nHO <= Nmax_HO ; nHO++)
	    {
	      complex<double> HO_overlap_Fermi_nHO = 0.0;
	      
	      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) HO_overlap_Fermi_nHO += wf_Fermi_w_bef_R_tab_GL(i)*CC_HO_wfs_bef_R_tab_GL(ic , nHO , i);
	      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) HO_overlap_Fermi_nHO += wf_Fermi_w_aft_R_tab_GL(i)*CC_HO_wfs_aft_R_tab_GL(ic , nHO , i);

	      for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
		{
		  CC_wf_momentum_tab_uniform (ic , i) += CC_HO_wfs_momentum_tab_uniform (ic , nHO , i)*HO_overlap_Fermi_nHO;
		  CC_dwf_momentum_tab_uniform(ic , i) += CC_HO_dwfs_momentum_tab_uniform(ic , nHO , i)*HO_overlap_Fermi_nHO;
		}
	      
	      for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
		{
		  CC_wf_momentum_tab_GL (ic , i) += CC_HO_wfs_momentum_tab_GL (ic , nHO , i)*HO_overlap_Fermi_nHO;
		  CC_dwf_momentum_tab_GL(ic , i) += CC_HO_dwfs_momentum_tab_GL(ic , nHO , i)*HO_overlap_Fermi_nHO;
		}
	    }
	}
    }
}







void CC_state_class::wfs_dwfs_HO_projection_momentum_calc (const bool is_it_entrance_channel_only)
{
  class array<double> CC_HO_wfs_momentum_tab_uniform  (N_channels , Nmax_HO_potentials_plus_one , Nk_momentum_uniform);
  class array<double> CC_HO_dwfs_momentum_tab_uniform (N_channels , Nmax_HO_potentials_plus_one , Nk_momentum_uniform);
  
  class array<double> CC_HO_wfs_momentum_tab_GL  (N_channels , Nmax_HO_potentials_plus_one , Nk_momentum_GL);
  class array<double> CC_HO_dwfs_momentum_tab_GL (N_channels , Nmax_HO_potentials_plus_one , Nk_momentum_GL);

  CC_HO_wave_functions::wfs_dwfs_momentum_calc (channels_tab , k_tab_uniform , CC_HO_wfs_momentum_tab_uniform , CC_HO_dwfs_momentum_tab_uniform);
  CC_HO_wave_functions::wfs_dwfs_momentum_calc (channels_tab , k_tab_GL      , CC_HO_wfs_momentum_tab_GL      , CC_HO_dwfs_momentum_tab_GL);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      if (!is_it_entrance_channel_only || (ic == ic_entrance))
	{
	  const class vector_class<complex<double> > & HO_overlaps_c = HO_overlaps(ic);

	  const int nmax_HO_c = HO_overlaps_c.get_dimension () - 1;

	  for (int nHOc = 0 ; nHOc <= nmax_HO_c ; nHOc++)
	    {
	      const complex<double> HO_overlap_nHOc = HO_overlaps_c(nHOc);
	      
	      for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
		{
		  CC_wf_momentum_tab_uniform (ic , i) += CC_HO_wfs_momentum_tab_uniform (ic , nHOc , i)*HO_overlap_nHOc;
		  CC_dwf_momentum_tab_uniform(ic , i) += CC_HO_dwfs_momentum_tab_uniform(ic , nHOc , i)*HO_overlap_nHOc;
		}
	      
	      for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
		{
		  CC_wf_momentum_tab_GL (ic , i) += CC_HO_wfs_momentum_tab_GL (ic , nHOc , i)*HO_overlap_nHOc;
		  CC_dwf_momentum_tab_GL(ic , i) += CC_HO_dwfs_momentum_tab_GL(ic , nHOc , i)*HO_overlap_nHOc;
		}
	    }
	}
    }
}



// test function modified
// ======================
double CC_state_class::test_calc (
				  const bool is_it_entrance_channel_only , 
				  const class array<complex<double> > &A0_bef_tab , 
				  const class array<complex<double> > &Aplus_bef_tab) const
{
  double test = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ++ic)
    {
      if (!is_it_entrance_channel_only || (ic == ic_entrance))
	{
	  const complex<double> &A0_bef_c = A0_bef_tab(ic);

	  const complex<double> &A0_c = A0_tab(ic);

	  const complex<double> &Aplus_bef_c = Aplus_bef_tab(ic);
	  
	  const complex<double> &Aplus_c  = Aplus_tab(ic);

	  test += inf_norm (A0_c - A0_bef_c);

	  test += inf_norm (Aplus_c - Aplus_bef_c);
	}
    }

  if (!is_it_entrance_channel_only) test /= N_channels;

  return test;
}






class CC_state_class & CC_state_class::operator = (const class CC_state_class &X)
{
  // Channel class
  channels_tab = X.channels_tab;

  //--// discretization of r (before R)
  r_bef_R_tab_uniform = X.r_bef_R_tab_uniform;

  r_bef_R_tab_GL = X.r_bef_R_tab_GL;
  w_bef_R_tab_GL = X.w_bef_R_tab_GL;

  N_bef_mp_GL = X.N_bef_mp_GL;
  N_aft_mp_GL = X.N_aft_mp_GL;

  r_bef_R_tab_GL_SGI_MSGI = X.r_bef_R_tab_GL_SGI_MSGI; // This set goes from 0 to 2.R0. R0 must be equal to matching_point.
  w_bef_R_tab_GL_SGI_MSGI = X.w_bef_R_tab_GL_SGI_MSGI; // This set goes from 0 to 2.R0. R0 must be equal to matching_point.

  N_bef_mp_GL_SGI_MSGI = X.N_bef_mp_GL_SGI_MSGI;
  N_aft_mp_GL_SGI_MSGI = X.N_aft_mp_GL_SGI_MSGI;

  //--// discretization of r (after R)
  r_aft_R_tab_GL_real = X.r_aft_R_tab_GL_real;
  w_aft_R_tab_GL_real = X.w_aft_R_tab_GL_real;

  um4_aft_R_tab_GL = X.um4_aft_R_tab_GL;
  
  w_aft_R_tab_GL = X.w_aft_R_tab_GL;

  // Wave functions

  CC_wf_bef_R_tab_uniform   = X.CC_wf_bef_R_tab_uniform;
  CC_dwf_bef_R_tab_uniform  = X.CC_dwf_bef_R_tab_uniform;
  CC_d2wf_bef_R_tab_uniform = X.CC_d2wf_bef_R_tab_uniform;

  CC_asymptotic_in_zero_wf_bef_R_tab_uniform = X.CC_asymptotic_in_zero_wf_bef_R_tab_uniform;

  if (are_there_scaled_wfs)
    {	
      CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform  = X.CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform;
      CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform = X.CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform;

      CC_scaled_wf_plus_aft_R_tab_uniform  = X.CC_scaled_wf_plus_aft_R_tab_uniform; 
      CC_scaled_dwf_plus_aft_R_tab_uniform = X.CC_scaled_dwf_plus_aft_R_tab_uniform; 
    }

  CC_wf_bef_R_tab_GL   = X.CC_wf_bef_R_tab_GL;
  CC_dwf_bef_R_tab_GL  = X.CC_dwf_bef_R_tab_GL;
  CC_d2wf_bef_R_tab_GL = X.CC_d2wf_bef_R_tab_GL;
  
  CC_wf_bef_R_tab_GL_SGI_MSGI  = X.CC_wf_bef_R_tab_GL_SGI_MSGI;
  CC_dwf_bef_R_tab_GL_SGI_MSGI = X.CC_dwf_bef_R_tab_GL_SGI_MSGI;

  CC_wf_aft_R_tab_GL   = X.CC_wf_aft_R_tab_GL;
  CC_dwf_aft_R_tab_GL  = X.CC_dwf_aft_R_tab_GL;
  CC_d2wf_aft_R_tab_GL = X.CC_d2wf_aft_R_tab_GL;

  if (are_there_scaled_wfs)
    {	
      CC_scaled_wf_minus_aft_R_c_entrance_tab_GL  = X.CC_scaled_wf_minus_aft_R_c_entrance_tab_GL;
      CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL = X.CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL;

      CC_scaled_wf_plus_aft_R_tab_GL  = X.CC_scaled_wf_plus_aft_R_tab_GL; 
      CC_scaled_dwf_plus_aft_R_tab_GL = X.CC_scaled_dwf_plus_aft_R_tab_GL; 
    }

  HO_overlaps       = X.HO_overlaps;
  HO_overlaps_Fermi = X.HO_overlaps_Fermi;

  // Forward basis and backward basis states

  const unsigned int first_ib = basic_first_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_ib = basic_last_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS); 

  for (unsigned int ib = 0 ; ib < N_channels ; ib++)
    {
      if ((ib >= first_ib) && (ib <= last_ib)) 
	{
	  fwd_basis(ib) = X.fwd_basis(ib);
	  bwd_basis(ib) = X.bwd_basis(ib);
	}
    }

  if ((THIS_PROCESS == MASTER_PROCESS) && !S_matrix_pole) bwd_U_minus = X.bwd_U_minus;

  // C0 and Cplus tabs 

  C0_tab = X.C0_tab;

  Cplus_tab = X.Cplus_tab;

  A0_tab = X.A0_tab;

  Aplus_tab = X.Aplus_tab;

  return *this;
}







void CC_state_class::overlap_function_calc (
					    const bool is_it_Gauss_Legendre , 
					    const class correlated_state_str &PSI_in_qn ,  
					    const enum particle_type projectile , 
					    const int LCM_projectile ,
					    const double J_projectile ,
					    class array<TYPE> &overlap_function_tab) const
{
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const class array<complex<double> > &CC_wf_bef_R_tab = (is_it_Gauss_Legendre) ? (CC_wf_bef_R_tab_GL) : (CC_wf_bef_R_tab_uniform);

  const unsigned int BP_in = PSI_in_qn.get_BP ();

  const unsigned int vector_index_in = PSI_in_qn.get_vector_index ();

  const double J_in = PSI_in_qn.get_J ();

  overlap_function_tab = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const unsigned int BP_Tc = channel_c.get_BP_Tc ();

      const unsigned int vector_index_Tc = channel_c.get_vector_index_Tc ();

      const double J_Tc = channel_c.get_J_Tc ();

      const bool BP_target_condition = (BP_Tc == BP_in);

      const bool J_target_condition = (make_int (J_Tc - J_in) == 0);

      const bool vector_index_target_condition = (vector_index_Tc == vector_index_in);

      // delta (if it is the same target)
      if (BP_target_condition && J_target_condition && vector_index_target_condition)
	{
	  const int LCM_projectile_c = channel_c.get_LCM_projectile ();

	  const double J_projectile_c = channel_c.get_J_projectile ();

	  const enum particle_type projectile_c = channel_c.get_projectile ();

	  const bool projectiles_condition = (projectile_c == projectile) && same_lj (LCM_projectile , J_projectile , LCM_projectile_c , J_projectile_c);
	  
	  // delta (if it is the same projectile)
	  if (projectiles_condition)
	    {
	      
#ifdef TYPEisDOUBLECOMPLEX
	      for (unsigned int i = 0 ; i < Nr ; i++) overlap_function_tab(i) += CC_wf_bef_R_tab(ic , i);
#endif
	      
#ifdef TYPEisDOUBLE
	      for (unsigned int i = 0 ; i < Nr ; i++) overlap_function_tab(i) += real (CC_wf_bef_R_tab(ic , i));
#endif
	      
	    }
	}
    }//loop ic
}




TYPE CC_state_class::spectroscopic_factor_calc ( 
						const class correlated_state_str &PSI_in_qn , 
						const enum particle_type projectile , 
						const int LCM_projectile ,
						const double J_projectile) const
{ 
  const unsigned int BP_in = PSI_in_qn.get_BP ();

  const unsigned int vector_index_in = PSI_in_qn.get_vector_index ();

  const double J_in = PSI_in_qn.get_J ();

  complex<double> spectroscopic_factor = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const unsigned int BP_Tc = channel_c.get_BP_Tc ();

      const unsigned int vector_index_Tc = channel_c.get_vector_index_Tc ();

      const double J_Tc = channel_c.get_J_Tc ();

      const bool BP_target_condition = (BP_Tc == BP_in);

      const bool J_target_condition = (make_int (J_Tc - J_in) == 0);

      const bool vector_index_target_condition = (vector_index_Tc == vector_index_in);

      // delta (if it is the same target)
      if (BP_target_condition && J_target_condition && vector_index_target_condition)
	{
	  const int LCM_projectile_c = channel_c.get_LCM_projectile ();

	  const double J_projectile_c = channel_c.get_J_projectile ();

	  const enum particle_type projectile_c = channel_c.get_projectile ();

	  const bool projectiles_condition = (projectile_c == projectile) && same_lj (LCM_projectile , J_projectile , LCM_projectile_c , J_projectile_c);
	  
	  // delta (if it is the same projectile)
	  if (projectiles_condition) spectroscopic_factor += Gamow_partial_squared_norm_no_channel_orthogonalization (ic);
	}
    }//loop ic

#ifdef TYPEisDOUBLECOMPLEX
  return spectroscopic_factor;
#endif
  
#ifdef TYPEisDOUBLE
  return real (spectroscopic_factor);
#endif
  
}





void CC_state_class::density_calc (
				   const bool is_it_radial , 
				   const bool is_it_Gauss_Legendre ,
				   class array<TYPE> &density_tab) const
{
  const double four_Pi = 12.566370614359173;

  const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (r_bef_R_tab_GL) : (r_bef_R_tab_uniform);

  const class array<double> &k_tab = (is_it_Gauss_Legendre) ? (k_tab_GL) : (k_tab_uniform);

  const class array<double> &rk_tab = (is_it_radial) ? (r_bef_R_tab) : (k_tab);
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const unsigned int Nk = (is_it_Gauss_Legendre) ? (Nk_momentum_GL) : (Nk_momentum_uniform);
  
  const unsigned int Nrk = (is_it_radial) ? (Nr) : (Nk);

  const class array<complex<double> > &CC_wf_bef_R_tab  = (is_it_Gauss_Legendre) ? (CC_wf_bef_R_tab_GL)  : (CC_wf_bef_R_tab_uniform);
  const class array<complex<double> > &CC_dwf_bef_R_tab = (is_it_Gauss_Legendre) ? (CC_dwf_bef_R_tab_GL) : (CC_dwf_bef_R_tab_uniform);
  
  const class array<complex<double> > &CC_wf_momentum_tab  = (is_it_Gauss_Legendre) ? (CC_wf_momentum_tab_GL)  : (CC_wf_momentum_tab_uniform);
  const class array<complex<double> > &CC_dwf_momentum_tab = (is_it_Gauss_Legendre) ? (CC_dwf_momentum_tab_GL) : (CC_dwf_momentum_tab_uniform);

  const class array<complex<double> > &CC_wf_rk_tab  = (is_it_radial) ? (CC_wf_bef_R_tab)  : (CC_wf_momentum_tab);
  const class array<complex<double> > &CC_dwf_rk_tab = (is_it_radial) ? (CC_dwf_bef_R_tab) : (CC_dwf_momentum_tab);
  
  for (unsigned ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);
      
      const enum particle_type projectile_c = channel_c.get_projectile ();

      const int A_projectile_c = A_cluster_determine (projectile_c);

      if (Nrk > 0)
	{
	  const double rk0 = rk_tab(0);

	  const double rk0_2 = rk0*rk0;
	  
	  const complex<double>  uc_rk0 = CC_wf_rk_tab (ic , 0);	  
	  const complex<double> duc_rk0 = CC_dwf_rk_tab(ic , 0);

#ifdef TYPEisDOUBLECOMPLEX
	  density_tab(0) += (rk0 > 0.0) ? (A_projectile_c*uc_rk0*uc_rk0/rk0_2) : (A_projectile_c*duc_rk0*duc_rk0);
#endif
  
#ifdef TYPEisDOUBLE
	  density_tab(0) += (rk0 > 0.0) ? (A_projectile_c*real (uc_rk0)*real (uc_rk0)/rk0_2) : (A_projectile_c*real (duc_rk0)*real (duc_rk0));
#endif
	}

      for (unsigned int i = 1 ; i < Nrk ; i++)
	{
	  const double rk = rk_tab(i);

	  const double rk2 = rk*rk;

	  const complex<double> uc_rk = CC_wf_rk_tab(ic , i);
	  
#ifdef TYPEisDOUBLECOMPLEX
	  density_tab(i) += A_projectile_c*uc_rk*uc_rk/rk2;
#endif
  
#ifdef TYPEisDOUBLE
	  density_tab(i) += A_projectile_c*real (uc_rk)*real (uc_rk)/rk2;
#endif
	}
    }

  density_tab /= four_Pi;
}





//--// return the T matrix associated to a given channel
complex<double> CC_state_class::get_T_matrix_value (const unsigned int ic_entrance , const unsigned int ic) const
{
  const complex<double> I (0.0 , 1.0);
  
  const complex<double> Cplus_c = Cplus_tab(ic);

  const complex<double> T_matrix_value_c = (ic == ic_entrance) ? (0.5 * I * (Cplus_c + 1.0)) : (0.5 * I * Cplus_c);

  return T_matrix_value_c;
}



//--// return the phase shift associated to a given channel
complex<double> CC_state_class::get_phase_shift (const unsigned int ic) const
{
  const complex<double> minus_half_I (0.0 , -0.5);
  
  const complex<double> Cplus_c = Cplus_tab(ic);

  const complex<double> phase_shift_c = minus_half_I*log (-Cplus_c);

  return phase_shift_c;
}




// function used for tests only by developers. Demands bases of GSM and CC to be equal. No test is made.
void CC_state_class::CC_uc_wfs_test_pole (
					  const class CC_target_projectile_composite_data &Tpc_data , 
					  const class nucleons_data &prot_data , 
					  const class nucleons_data &neut_data , 
					  const class array<class cluster_data> &cluster_projectile_data_tab , 
					  const class CC_Hamiltonian_data &CC_H_data) const
{
  if (is_it_HO_projected) error_message_print_abort ("CC equations test for u_c(r) is meaningless with HO projected functions.");
  
  if (!S_matrix_pole) error_message_print_abort ("CC equations test for u_c(r) only for S-matrix poles.");

  const unsigned int dimension_matrices = CC_H_data.get_dimension_matrices ();
  
  const double relative_SVD_precision = CC_H_data.get_relative_SVD_precision ();
  
  const class matrix<complex<double> > &H_matrix = CC_H_data.get_H_matrix ();
  
  const class matrix<complex<double> > &overlaps_matrix = CC_H_data.get_overlaps_matrix ();

  class matrix<complex<double> > sqrt_inv_overlaps_matrix = overlaps_matrix;

  Moore_Penrose_sqrt_inv (sqrt_inv_overlaps_matrix , relative_SVD_precision);

  class matrix<complex<double> > orthogonalized_H_matrix = sqrt_inv_overlaps_matrix*H_matrix*sqrt_inv_overlaps_matrix;
  
  class array<complex<double> > orthogonalized_H_eigenvalues (dimension_matrices);
  
  orthogonalized_H_matrix.symmetrize ();

  total_diagonalization::symmetric::all_eigenpairs (orthogonalized_H_matrix , orthogonalized_H_eigenvalues);

  class array<class vector_class<complex<double> > > eigenvectors(dimension_matrices);

  class CC_state_class CC_state_test = *this;
  
  //xyz
  cout << "!!! TEST !!!" << endl;  
  
  //for (unsigned int i = 0 ; i < dimension_matrices ; i++)
  const unsigned int i = n;
  {
    const complex<double> eigenvalue = orthogonalized_H_eigenvalues(i);
      
    class vector_class<complex<double> > &eigenvector = eigenvectors(i);

    eigenvector.allocate_fill (orthogonalized_H_matrix.eigenvector (i));

    eigenvector = -eigenvector;      
  
    eigenvector = sqrt_inv_overlaps_matrix*eigenvector;
      
    CC_state_test.CC_wf_dwf_d2wf_zero ();
  
    CC_state_test.pole_state_waves_from_CC_Berggren_expansion_calc (Tpc_data , CC_H_data , prot_data , neut_data , cluster_projectile_data_tab , eigenvalue , eigenvector);
      
    CC_state_test.HO_overlaps_calc (false , CC_H_data);
      
    const complex<double> norm = CC_state_test.Gamow_norm_no_channel_orthogonalization ();
      
    CC_state_test.normalization (1.0/norm);
  
    double CC_test = 0.0;
      
    for (unsigned int ic = 0 ; ic < N_channels ; ic++)
      {	  
	for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	  {
	    CC_test = max (CC_test , inf_norm (CC_state_test.CC_wf_bef_R_tab_uniform  (ic , i) - CC_wf_bef_R_tab_uniform  (ic , i)));
	    CC_test = max (CC_test , inf_norm (CC_state_test.CC_dwf_bef_R_tab_uniform (ic , i) - CC_dwf_bef_R_tab_uniform (ic , i)));
	    CC_test = max (CC_test , inf_norm (CC_state_test.CC_d2wf_bef_R_tab_uniform(ic , i) - CC_d2wf_bef_R_tab_uniform(ic , i)));

	    cout << ic << " " << r_bef_R_tab_uniform(i) << " " << real (CC_state_test.CC_wf_bef_R_tab_uniform  (ic , i)) << " " << real (CC_wf_bef_R_tab_uniform  (ic , i)) << endl;//xyz
	  }
	  
	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	  {
	    CC_test = max (CC_test , inf_norm (CC_state_test.CC_wf_bef_R_tab_GL  (ic , i) - CC_wf_bef_R_tab_GL  (ic , i)));
	    CC_test = max (CC_test , inf_norm (CC_state_test.CC_dwf_bef_R_tab_GL (ic , i) - CC_dwf_bef_R_tab_GL (ic , i)));
	    CC_test = max (CC_test , inf_norm (CC_state_test.CC_d2wf_bef_R_tab_GL(ic , i) - CC_d2wf_bef_R_tab_GL(ic , i)));	      
	  }
      }
      
    if (THIS_PROCESS == MASTER_PROCESS) cout << "Eigenstate : " << i << "    test uc(r) : " << CC_test << endl;
  }
 
  if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
}




double used_memory_calc (const class CC_state_class &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.channels_tab) + used_memory_calc (T.r_bef_R_tab_uniform) + used_memory_calc (T.k_tab_uniform) + used_memory_calc (T.r_bef_R_tab_GL) + used_memory_calc (T.k_tab_GL ) + used_memory_calc (T.r_bef_R_tab_GL_SGI_MSGI) + used_memory_calc (T.r_aft_R_tab_GL_real) + used_memory_calc (T.um4_aft_R_tab_GL) + used_memory_calc (T.w_bef_R_tab_GL) + used_memory_calc (T.wk_tab_GL) + used_memory_calc (T.w_bef_R_tab_GL_SGI_MSGI) + used_memory_calc (T.w_aft_R_tab_GL_real) + used_memory_calc (T.w_aft_R_tab_GL) + used_memory_calc (T.CC_wf_bef_R_tab_uniform) + used_memory_calc (T.CC_dwf_bef_R_tab_uniform) + used_memory_calc (T.CC_d2wf_bef_R_tab_uniform) + used_memory_calc (T.CC_wf_bef_R_tab_GL ) + used_memory_calc (T.CC_dwf_bef_R_tab_GL ) + used_memory_calc (T.CC_d2wf_bef_R_tab_GL) + used_memory_calc (T.CC_wf_aft_R_tab_GL ) + used_memory_calc (T.CC_dwf_aft_R_tab_GL ) + used_memory_calc (T.CC_d2wf_aft_R_tab_GL) + used_memory_calc (T.CC_wf_bef_R_tab_GL_SGI_MSGI) + used_memory_calc (T.CC_dwf_bef_R_tab_GL_SGI_MSGI) + used_memory_calc (T.CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform) + used_memory_calc (T.CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform) + used_memory_calc (T.CC_scaled_wf_minus_aft_R_c_entrance_tab_GL ) + used_memory_calc (T.CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL) + used_memory_calc (T.CC_scaled_wf_plus_aft_R_tab_uniform) + used_memory_calc (T.CC_scaled_dwf_plus_aft_R_tab_uniform) + used_memory_calc (T.CC_scaled_wf_plus_aft_R_tab_GL ) + used_memory_calc (T.CC_scaled_dwf_plus_aft_R_tab_GL) + used_memory_calc (T.CC_asymptotic_in_zero_wf_bef_R_tab_uniform) + used_memory_calc (T.CC_wf_momentum_tab_uniform) + used_memory_calc (T.CC_dwf_momentum_tab_uniform) + used_memory_calc (T.CC_wf_momentum_tab_GL ) + used_memory_calc (T.CC_dwf_momentum_tab_GL) + used_memory_calc (T.C0_tab) + used_memory_calc (T.Cplus_tab) + used_memory_calc (T.A0_tab) + used_memory_calc (T.Aplus_tab) + used_memory_calc (T.HO_overlaps) + used_memory_calc (T.HO_overlaps_Fermi) + used_memory_calc (T.fwd_basis) + used_memory_calc (T.bwd_basis) + used_memory_calc (T.bwd_U_minus) - (sizeof (T.channels_tab) + sizeof (T.r_bef_R_tab_uniform) + sizeof (T.k_tab_uniform) + sizeof (T.r_bef_R_tab_GL) + sizeof (T.k_tab_GL ) + sizeof (T.r_bef_R_tab_GL_SGI_MSGI) + sizeof (T.r_aft_R_tab_GL_real) + sizeof (T.um4_aft_R_tab_GL) + sizeof (T.w_bef_R_tab_GL) + sizeof (T.wk_tab_GL) + sizeof (T.w_bef_R_tab_GL_SGI_MSGI) + sizeof (T.w_aft_R_tab_GL_real) + sizeof (T.w_aft_R_tab_GL) + sizeof (T.CC_wf_bef_R_tab_uniform) + sizeof (T.CC_dwf_bef_R_tab_uniform) + sizeof (T.CC_d2wf_bef_R_tab_uniform) + sizeof (T.CC_wf_bef_R_tab_GL ) + sizeof (T.CC_dwf_bef_R_tab_GL ) + sizeof (T.CC_d2wf_bef_R_tab_GL) + sizeof (T.CC_wf_aft_R_tab_GL ) + sizeof (T.CC_dwf_aft_R_tab_GL ) + sizeof (T.CC_d2wf_aft_R_tab_GL) + sizeof (T.CC_wf_bef_R_tab_GL_SGI_MSGI) + sizeof (T.CC_dwf_bef_R_tab_GL_SGI_MSGI) + sizeof (T.CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform) + sizeof (T.CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform) + sizeof (T.CC_scaled_wf_minus_aft_R_c_entrance_tab_GL ) + sizeof (T.CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL) + sizeof (T.CC_scaled_wf_plus_aft_R_tab_uniform) + sizeof (T.CC_scaled_dwf_plus_aft_R_tab_uniform) + sizeof (T.CC_scaled_wf_plus_aft_R_tab_GL ) + sizeof (T.CC_scaled_dwf_plus_aft_R_tab_GL) + sizeof (T.CC_asymptotic_in_zero_wf_bef_R_tab_uniform) + sizeof (T.CC_wf_momentum_tab_uniform) + sizeof (T.CC_dwf_momentum_tab_uniform) + sizeof (T.CC_wf_momentum_tab_GL ) + sizeof (T.CC_dwf_momentum_tab_GL) + sizeof (T.C0_tab) + sizeof (T.Cplus_tab) + sizeof (T.A0_tab) + sizeof (T.Aplus_tab) + sizeof (T.HO_overlaps) + sizeof (T.HO_overlaps_Fermi) + sizeof (T.fwd_basis) + sizeof (T.bwd_basis) + sizeof (T.bwd_U_minus))/1000000.0;

  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;
}
