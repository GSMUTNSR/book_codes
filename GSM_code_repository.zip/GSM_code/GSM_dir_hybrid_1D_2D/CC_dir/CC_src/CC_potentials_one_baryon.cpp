#include "../CC_include/CC_include_def.h"


using namespace string_routines;
using namespace correlated_state_routines;
using namespace inputs_misc;
using namespace a_dagger_baryon_helper;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_common_routines;
using namespace CC_H_a_dagger_baryon_forbidden_channels;
using namespace CC_H_MEs_one_baryon;




void CC_potentials_one_baryon::overlaps_and_H_matrices_cell_calc (
								   const class GSM_vector &V_in , 
								   const class GSM_vector &HV_in , 
								   const class nlj_struct &shell_qn_cp , 
								   const enum particle_type particle_cp , 
								   const class correlated_state_str &PSI_qn_Tcp , 
								   const unsigned int index_in , 
								   const unsigned int index_out ,
								   const double J , 
								   class array<class GSM_vector> &V_out_tab , 
								   class matrix<complex<double> > &overlaps_matrix ,
								   class matrix<complex<double> > &H_matrix)
{
  const unsigned int this_thread = OpenMP_thread_number_determine ();

  class GSM_vector &V_out = V_out_tab(this_thread);
  
  const class GSM_vector_helper_class &V_out_helper = V_out.get_GSM_vector_helper ();
  
  const double M = V_out_helper.get_M ();
  
  const int ncp = shell_qn_cp.get_n ();
  const int lcp = shell_qn_cp.get_l ();

  const double jcp = shell_qn_cp.get_j ();

  const string a_dagger_PSI_cp_coupled_file_name = PSI_OUT_coupled_to_J_file_name_a_dagger_baryon_determine (false , "a_dagger_baryon" , ncp , lcp , jcp , particle_cp , PSI_qn_Tcp , J , M);
  
  V_out.read_disk (false , false , a_dagger_PSI_cp_coupled_file_name);
  
  const complex<double> overlap = GSM_vector_node_overlap (V_in , V_out);

  const complex<double> H_ME = GSM_vector_node_overlap (HV_in , V_out);

  overlaps_matrix(index_in , index_out) = overlaps_matrix(index_out , index_in) = overlap;

  H_matrix(index_in , index_out) = H_matrix(index_out , index_in) = H_ME;
}








void CC_potentials_one_baryon::overlaps_and_H_matrices_calc (
							      const bool print_detailed_information ,
							      const class array<class CC_channel_class> &channels_tab , 
							      const class baryons_data &prot_Y_data , 
							      const class baryons_data &neut_Y_data , 
							      const double J , 
							      class GSM_vector &V_in , 
							      class GSM_vector &HV_in , 
							      class CC_Hamiltonian_data &CC_H_data)
{
  const class GSM_vector_helper_class &V_helper = V_in.get_GSM_vector_helper ();

  const unsigned int BP = V_helper.get_BP ();

  const unsigned int N_channels = channels_tab.dimension (0);

  const double CC_average_n_scat_target_projectile_max = CC_H_data.get_CC_average_n_scat_target_projectile_max ();

  const double M = V_helper.get_M ();

  const class array<unsigned int> &matrices_indices = CC_H_data.get_matrices_indices ();

  const class array<bool> &is_it_forbidden_channel_tab = CC_H_data.get_is_it_forbidden_channel_tab ();

  class matrix<complex<double> > &overlaps_matrix_pole_approximation = CC_H_data.get_overlaps_matrix_pole_approximation ();

  class matrix<complex<double> > &H_matrix_pole_approximation = CC_H_data.get_H_matrix_pole_approximation ();

  class matrix<complex<double> > &overlaps_matrix = CC_H_data.get_overlaps_matrix ();

  class matrix<complex<double> > &H_matrix = CC_H_data.get_H_matrix ();

  class array<class GSM_vector> V_out_tab(NUMBER_OF_THREADS);

  for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++) V_out_tab(i_thread).allocate_fill (V_in);

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const complex<double> E_Tc = channel_c.get_E_Tc ();

      const complex<double> &average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const enum particle_type particle_c = channel_c.get_projectile ();

      const int particle_c_charge = particle_charge_determine (particle_c);

      const bool is_particle_c_charged = (particle_c_charge != 0);
		      
      const class baryons_data &data_tau_c = (is_particle_c_charged) ? (prot_Y_data) : (neut_Y_data);

      const int Z_Tc = channel_c.get_Z_Tc ();
      const int N_Tc = channel_c.get_N_Tc ();

      const int S_Tc = channel_c.get_S_Tc ();

      const double jc = channel_c.get_J_projectile ();

      const double J_Tc = channel_c.get_J_Tc ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_c = data_tau_c.get_is_it_valence_shell_tabs ();
      
      const class array<class lj_table<int> > &nmax_lj_c_tabs = data_tau_c.get_nmax_lj_tabs ();

      const class array<class nlj_table<unsigned int> > &shells_indices_c_tab = data_tau_c.get_shells_indices_tab ();

      const unsigned int particle_index_c = charge_baryon_index_determine (particle_c);
      
      const class lj_table<int> &nmax_lj_c_tab = nmax_lj_c_tabs(particle_index_c);
      
      const class nlj_table<unsigned int> &shells_indices_c = shells_indices_c_tab(particle_index_c);

      const class nlj_table<bool> &is_it_valence_shell_tab_c = is_it_valence_shell_tabs_c(particle_index_c);

      const class array<class nlj_struct> &shells_qn_c = data_tau_c.get_shells_quantum_numbers ();
      
      const int lc = channel_c.get_LCM_projectile ();

      const int nmax_c = nmax_lj_c_tab(lc , jc);

      const bool S_matrix_pole_Tc = channel_c.get_S_matrix_pole_Tc ();

      const unsigned int BP_Tc = channel_c.get_BP_Tc ();
      
      const unsigned int vector_index_Tc = channel_c.get_vector_index_Tc ();

      class correlated_state_str PSI_qn_Tc(Z_Tc , N_Tc , BP_Tc , S_Tc , J_Tc , vector_index_Tc , E_Tc , NADA , NADA , NADA , false);

      for (int nc = 0 ; nc <= nmax_c ; nc++) 
	{
	  if (is_it_valence_shell_tab_c(nc , lc , jc))
	    {
	      const unsigned int sc = shells_indices_c(nc , lc , jc);

	      const class nlj_struct &shell_qn_c = shells_qn_c(sc);

	      const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	      const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	      if (!is_it_forbidden_channel_tab(ic , nc) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max))
		{	
		  const bool S_matrix_pole_c = (S_matrix_pole_Tc && S_matrix_pole_nc);

		  const unsigned int index_in = matrices_indices(ic , nc);
		  //const complex<double> e_nc = hc_basis(nc , lc , jc);

		  const string   a_dagger_PSI_c_coupled_file_name = PSI_OUT_coupled_to_J_file_name_a_dagger_baryon_determine (false ,   "a_dagger_baryon" , nc , lc , jc , particle_c , PSI_qn_Tc , J , M);
		  const string H_a_dagger_PSI_c_coupled_file_name = PSI_OUT_coupled_to_J_file_name_a_dagger_baryon_determine (false , "H_a_dagger_baryon" , nc , lc , jc , particle_c , PSI_qn_Tc , J , M);

		  V_in.read_disk (false , false , a_dagger_PSI_c_coupled_file_name);
		  
		  HV_in.read_disk (false , false , H_a_dagger_PSI_c_coupled_file_name);

		  for (unsigned int icp = 0 ; icp <= ic ; icp++)
		    {
		      const class CC_channel_class &channel_cp = channels_tab(icp);

		      const complex<double> E_Tcp = channel_cp.get_E_Tc ();

		      const complex<double> &average_n_scat_Tcp = channel_cp.get_average_n_scat_Tc ();

		      const enum particle_type particle_cp = channel_cp.get_projectile ();

		      const int particle_cp_charge = particle_charge_determine (particle_cp);

		      const bool is_particle_cp_charged = (particle_cp_charge != 0);
		      
		      const class baryons_data &data_tau_cp = (is_particle_cp_charged) ? (prot_Y_data) : (neut_Y_data);

		      const int Z_Tcp = channel_cp.get_Z_Tc ();
		      const int N_Tcp = channel_cp.get_N_Tc ();
		      
		      const int S_Tcp = channel_cp.get_S_Tc ();

		      const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_cp = data_tau_cp.get_is_it_valence_shell_tabs ();
      
		      const class array<class lj_table<int> > &nmax_lj_cp_tabs = data_tau_cp.get_nmax_lj_tabs ();
      
		      const class array<class nlj_table<unsigned int> > &shells_indices_cp_tab = data_tau_cp.get_shells_indices_tab ();      

		      const class array<class nlj_struct> &shells_qn_cp = data_tau_cp.get_shells_quantum_numbers ();
		      
		      const unsigned int particle_index_cp = charge_baryon_index_determine (particle_cp);
      
		      const class lj_table<int> &nmax_lj_cp_tab = nmax_lj_cp_tabs(particle_index_cp);
		      
		      const class nlj_table<unsigned int> &shells_indices_cp = shells_indices_cp_tab(particle_index_cp);

		      const class nlj_table<bool> &is_it_valence_shell_tab_cp = is_it_valence_shell_tabs_cp(particle_index_cp);

		      const double jcp = channel_cp.get_J_projectile ();

		      const double J_Tcp = channel_cp.get_J_Tc ();

		      const double real_average_n_scat_Tcp = real (average_n_scat_Tcp);

		      const int lcp = channel_cp.get_LCM_projectile ();

		      const int nmax_cp = nmax_lj_cp_tab(lcp , jcp);

		      const int nmax_cp_nc = (icp < ic) ? (nmax_cp) : (nc);

		      const bool S_matrix_pole_Tcp = channel_cp.get_S_matrix_pole_Tc ();

		      const unsigned int BP_Tcp = channel_cp.get_BP_Tc ();

		      const unsigned int vector_index_Tcp = channel_cp.get_vector_index_Tc ();

		      class correlated_state_str PSI_qn_Tcp (Z_Tcp , N_Tcp , BP_Tcp , S_Tcp , J_Tcp , vector_index_Tcp , E_Tcp , NADA , NADA , NADA , false);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
		      for (int ncp = 0 ; ncp <= nmax_cp_nc ; ncp++) 
			{
			  if (is_it_valence_shell_tab_cp(ncp , lcp , jcp))
			    {
			      const unsigned int scp = shells_indices_cp(ncp , lcp , jcp);
			      
			      const class nlj_struct &shell_qn_cp = shells_qn_cp(scp);

			      const bool S_matrix_pole_ncp = shell_qn_cp.get_S_matrix_pole ();

			      const double real_average_n_scat_cp = (!S_matrix_pole_ncp) ? (real_average_n_scat_Tcp + 1) : (real_average_n_scat_Tcp);

			      if (!is_it_forbidden_channel_tab(icp , ncp) && (real_average_n_scat_cp <= CC_average_n_scat_target_projectile_max))
				{	
				  const bool S_matrix_pole_cp = (S_matrix_pole_Tcp && S_matrix_pole_ncp);

				  const unsigned int index_out = matrices_indices(icp , ncp);

				  if (S_matrix_pole_c && S_matrix_pole_cp)
				    overlaps_and_H_matrices_cell_calc (V_in , HV_in , shell_qn_cp , particle_cp , PSI_qn_Tcp , index_in , index_out , J , V_out_tab ,
								       overlaps_matrix_pole_approximation , H_matrix_pole_approximation);

				  overlaps_and_H_matrices_cell_calc (V_in , HV_in , shell_qn_cp , particle_cp , PSI_qn_Tcp , index_in , index_out , J , V_out_tab , overlaps_matrix , H_matrix);
				}
			    }
			}
		    }
		}
	    }
	}

      if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << "Files read for overlap and H matrices in channel " << channel_c << endl;
    }

#ifdef UseMPI
  
  CC_H_data.H_overlaps_matrices_MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
#endif
  
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      CC_H_data.H_overlaps_matrices_copy_disk (BP , J);

      cout << endl;
    }
}



















// HO basis matrix elements - 1 [index_in_HO \equiv (ic , nHOc) -> in the comments , we'll write (ic , nHOc)]:
// ======================================================================================================
// finite_range_overlaps_HO_matrix (ic , nHOc ; icp , nHOcp) = <HO , nHOc , lc , jc | O_finite_range_ccp | HO , nHOcp , lcp , jcp>
// O_finite_range_ccp being the finite-range overlap for given channels c , cp
//
// finite_range_pot_HO_matrix (ic , nHOc ; icp , nHOcp) = <HO , nHOc , lc , jc | V_ccp | HO , nHOcp , lcp , jcp>
// V_ccp being the finite-range potential
//
// Ho_HO_matrix (ic , nHOc ; icp , nHOcp) = <HO , nHOc , lc , jc | H0_ccp | HO , nHOcp , lcp , jcp>
// H0_ccp being the intrinsic hamiltonian (energy of the projectile + energy of the target)

// HO basis matrix elements - 2:
// -----------------------------
// H_HO_matrix = H_fr = finite_range_pot_HO_matrix + Ho_HO_matrix
// (at finite range , there actually only remains the H matrix elements !)
//
// overlaps_HO_matrix = O = Id + O_fr
// sqrt_overlaps_HO_matrix = O^{1/2}
// sqrt_inv_overlaps_HO_matrix = O^{-1/2}
// Delta_HO_matrix = O^{-1/2}_fr = O^{-1/2} - Id
// sqrt_overlaps_Delta_sqrt_overlaps_HO_matrix = O^{1/2} O^{-1/2}_fr O^{1/2} = O^{1/2} [O^{-1/2} - Id] O^{1/2} 
//
// finite_range_orthogonalized_potential_HO_matrix = O^{-1/2}*H*O^{-1/2} - [long-range]
// = H + H*O^{-1/2}_fr + O^{-1/2}_fr*H + O^{-1/2}_fr*H*O^{-1/2}_fr - [long-range]
// = finite_range_pot_HO_matrix + U_HF_fr + H*O^{-1/2}_fr + O^{-1/2}_fr*H + O^{-1/2}_fr*H*O^{-1/2}_fr 
// (finite_range_pot_HO_matrix being the non-long-range part of H , U_HF_fr is added elsewhere in the code)

// elimination of forbidden channels which lead to a non invertible overlap matrix
// ===============================================================================


void CC_potentials_one_baryon::potentials_overlaps_calc (
							  const class input_data_str &input_data , 
							  const bool are_GSM_a_dagger_vectors_calculated , 
							  const class array<class CC_channel_class> &channels_tab , 
							  const class interaction_class &inter_data_basis , 
							  const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
							  const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
							  const class baryons_data &prot_Y_data_one_configuration_GSM , 
							  const class baryons_data &neut_Y_data_one_configuration_GSM , 
							  const double J , 
							  const double M , 
							  const unsigned int BP ,
							  const class baryons_data &prot_Y_data_CC_Berggren , 
							  const class baryons_data &neut_Y_data_CC_Berggren , 
							  class baryons_data &prot_Y_data , 
							  class baryons_data &neut_Y_data , 
							  class TBMEs_class &TBMEs_pn , 
							  class TBMEs_class &TBMEs_cv , 
							  class CC_Hamiltonian_data &CC_H_data)
{
  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();

  const bool print_detailed_information = input_data.get_print_detailed_information ();
    
  const double CC_average_n_scat_target_projectile_max = CC_H_data.get_CC_average_n_scat_target_projectile_max ();
  
  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();
  
  const bool is_cv_possible = input_data.get_is_cv_possible ();
  
  const int two_J = make_int (2.0*J);
  
  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();

  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage ();

  const enum storage_type one_jumps_pn_two_jumps_cv_storage = input_data.get_one_jumps_pn_two_jumps_cv_storage ();
  
  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
								
  const double CC_forbidden_channel_precision = input_data.get_CC_forbidden_channel_precision ();

  const class array<double> &CC_corrective_factors_TBMEs_tab = CC_H_data.get_CC_corrective_factors_TBMEs_tab ();

  class array<bool> &is_it_forbidden_channel_tab = CC_H_data.get_is_it_forbidden_channel_tab ();

  if (are_GSM_a_dagger_vectors_calculated) 
    {
      const double CC_corrective_factor_TBME = CC_corrective_factors_TBMEs_tab(BP , two_J);

      corrective_factor_TBMEs_modification (space , CC_corrective_factor_TBME , prot_Y_data , neut_Y_data , TBMEs_pn , TBMEs_cv);
      
      const double Mp1 = M + 1.0;

      class GSM_vector_helper_class GSM_vector_helper_M(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
							n_holes_max   , n_scat_max   , E_max_hw ,
							n_holes_max_p , n_scat_max_p , Ep_max_hw ,
							n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , true , prot_Y_data , neut_Y_data);
      
      class GSM_vector_helper_class GSM_vector_helper_Mp1 (is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
							   n_holes_max   , n_scat_max   , E_max_hw ,
							   n_holes_max_p , n_scat_max_p , Ep_max_hw ,
							   n_holes_max_n , n_scat_max_n , En_max_hw , BP , Mp1 , true , prot_Y_data , neut_Y_data);

      const class GSM_vector_helper_class dummy_helper;

      class GSM_vector V_in (GSM_vector_helper_M);
      class GSM_vector V_out(GSM_vector_helper_M);

      class GSM_vector PSI0_M  (GSM_vector_helper_M);
      class GSM_vector PSI1_M  (GSM_vector_helper_M);
      
      class GSM_vector PSI0_Mp1(GSM_vector_helper_Mp1);
      class GSM_vector PSI1_Mp1(GSM_vector_helper_Mp1);
      class GSM_vector PSI2_Mp1(GSM_vector_helper_Mp1);

      class array<class GSM_vector> V_tab(NUMBER_OF_THREADS);
      
      for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) V_tab(i).allocate (GSM_vector_helper_M);

      class GSM_vector PSI_full;
	 
      const class Jpm_class Jplus( true , print_detailed_information ,  1 , Hamiltonian_storage , true , GSM_vector_helper_M   , GSM_vector_helper_Mp1 , PSI_full , PSI0_Mp1 , PSI1_Mp1);
      const class Jpm_class Jminus(true , print_detailed_information , -1 , Hamiltonian_storage , true , GSM_vector_helper_Mp1 , GSM_vector_helper_M   , PSI_full , PSI0_M   , PSI1_M);
		 
      const class J2_class J2(Jplus , Jminus , PSI2_Mp1);

      a_dagger_baryon_calculations_and_copy_disk (print_detailed_information , CC_average_n_scat_target_projectile_max , full_common_vectors_used_in_file , channels_tab , prot_Y_data , neut_Y_data , J , J2 , V_in , V_out);

      is_it_forbidden_channel_tab_calc (print_detailed_information , CC_average_n_scat_target_projectile_max , CC_forbidden_channel_precision , channels_tab , prot_Y_data , neut_Y_data , J , V_in , is_it_forbidden_channel_tab);

      CC_H_data.dimensions_matrices_one_baryon_calc (inter_data_basis , prot_Y_data , neut_Y_data , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , channels_tab);

      CC_H_data.dimension_matrices_dependent_data_realloc_init ();

      CC_H_data.all_matrices_indices_one_baryon_calc (inter_data_basis , prot_Y_data , neut_Y_data , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , channels_tab);

      CC_H_data.is_it_forbidden_channel_CC_Berggren_tab_one_baryon_determine (channels_tab , prot_Y_data , neut_Y_data);

      const class H_class H(false , false , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_two_jumps_cv_storage , true , false , false , TBMEs_pn , TBMEs_cv ,
			    true , true , true , true , true , is_cv_possible , J , GSM_vector_helper_M , PSI_full , PSI0_M , PSI1_M , V_tab);
      
      H_a_dagger_baryon_calculations_and_copy_disk (print_detailed_information , CC_average_n_scat_target_projectile_max , channels_tab , prot_Y_data , neut_Y_data , is_it_forbidden_channel_tab , J , J2 , H , V_in , V_out);

      // Berggren basis matrix elements [index_in \equiv (ic , nc) -> in the comments ,  we'll write (ic , nc)]:
      // -----------------------------------------------------------------------------------------------------
      // overlaps_matrix (ic , nc ; icp , ncp) = <a+_{nc , lc , jc} \Psi_c | a+_{ncp , lcp , jcp} \Psi_cp>
      // H_matrix (ic , nc ; icp , ncp) = <a+_{nc , lc , jc} \Psi_c | H | a+_{ncp , lcp , jcp} \Psi_cp>

      overlaps_and_H_matrices_calc (print_detailed_information , channels_tab , prot_Y_data , neut_Y_data , J , V_in , V_out , CC_H_data);
    }
  else
    {
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  const string is_it_forbidden_channel_tab_file_name = file_name_J_Pi_string ("CC_is_it_forbidden_channel_tab" , BP , J);

	  is_it_forbidden_channel_tab.read_disk (is_it_forbidden_channel_tab_file_name);
	}

#ifdef UseMPI
      is_it_forbidden_channel_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif

      CC_H_data.dimensions_matrices_one_baryon_calc (inter_data_basis , prot_Y_data , neut_Y_data , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , channels_tab);

      CC_H_data.dimension_matrices_dependent_data_realloc_init ();

      CC_H_data.all_matrices_indices_one_baryon_calc (inter_data_basis , prot_Y_data , neut_Y_data , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren ,  channels_tab);

      if (THIS_PROCESS == MASTER_PROCESS) CC_H_data.H_overlaps_matrices_read_from_file (BP , J);

#ifdef UseMPI
      CC_H_data.H_overlaps_matrices_MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
    }

  CC_H_data.finite_range_overlaps_potential_Ho_HO_matrices_one_baryon_calc (channels_tab , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
									     prot_Y_data_one_configuration_GSM , neut_Y_data_one_configuration_GSM , prot_Y_data , neut_Y_data , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren);

  CC_H_data.overlaps_H_HO_matrices_calc ();

  CC_H_data.Delta_H_HO_matrices_one_baryon_calc (channels_tab , prot_Y_data , neut_Y_data , inter_data_basis);

  // HO submatrices filling
  // ----------------------
  CC_H_data.HO_submatrices_one_baryon_fill (channels_tab , inter_data_basis);

  // orthogonalized_H_matrix_Berggren calculation
  CC_H_data.orthogonalized_H_matrix_CC_Berggren_one_baryon_calc (channels_tab , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren);

  if (are_GSM_a_dagger_vectors_calculated) 
    {	
      // Quick tests: Diagonalization of some matrices
      if (print_detailed_information) CC_H_data.overlaps_H_matrices_diagonalization_test (BP , J);	

      const double CC_corrective_factor_TBME = CC_corrective_factors_TBMEs_tab(BP , two_J);

      const double CC_corrective_factor_TBME_inv = 1.0/CC_corrective_factor_TBME;

      corrective_factor_TBMEs_modification (space , CC_corrective_factor_TBME_inv , prot_Y_data , neut_Y_data , TBMEs_pn , TBMEs_cv);
    }
}












void CC_potentials_one_baryon::potential_diagonal_source_init (
								const bool is_it_COSM , 
								const bool is_it_entrance_channel_only , 
								const class CC_state_class &CC_state , 
								const class baryons_data &prot_Y_data , 
								const class baryons_data &neut_Y_data , 
								const class HF_nucleons_data &CC_prot_HF_data , 
								const class HF_nucleons_data &CC_neut_HF_data , 
								class array<complex<double> > &Ueq_tab , 
								class array<complex<double> > &source_tab)
{
  const class array<class CC_channel_class> &channels_tab = CC_state.get_channels_tab ();

  const unsigned int N_channels = CC_state.get_N_channels ();

  const unsigned int N_bef_R_uniform = CC_state.get_N_bef_R_uniform ();

  const unsigned int ic_entrance = CC_state.get_ic_entrance ();

  const class array<double> &r_bef_R_tab_uniform = CC_state.get_r_bef_R_tab_uniform ();

  const class lj_table<int> &CC_prot_nmin_lj_valence_tab = CC_prot_HF_data.get_nmin_lj_valence_tab ();
  const class lj_table<int> &CC_neut_nmin_lj_valence_tab = CC_neut_HF_data.get_nmin_lj_valence_tab ();

  const int CC_prot_nmin_lj_valence_all = (CC_prot_nmin_lj_valence_tab.dimension_total () > 0) ? (CC_prot_nmin_lj_valence_tab.max ()) : (0);
  const int CC_neut_nmin_lj_valence_all = (CC_neut_nmin_lj_valence_tab.dimension_total () > 0) ? (CC_neut_nmin_lj_valence_tab.max ()) : (0);

  const int CC_nmin_lj_valence_all = max (CC_prot_nmin_lj_valence_all , CC_neut_nmin_lj_valence_all);
	
  const unsigned int first_ir = basic_first_index_determine_for_MPI (N_bef_R_uniform , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_ir = basic_last_index_determine_for_MPI (N_bef_R_uniform , NUMBER_OF_PROCESSES , THIS_PROCESS); 

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      if (!is_it_entrance_channel_only || (ic == ic_entrance))
	{
	  const class CC_channel_class &channel_c = channels_tab(ic);

	  const enum particle_type particle_c = channel_c.get_projectile ();
      
	  const unsigned int particle_index_c = charge_baryon_index_determine (particle_c);

	  const int particle_c_charge = particle_charge_determine (particle_c);

	  const bool is_particle_c_charged = (particle_c_charge != 0);
  
	  const class baryons_data &data_tau_c = (is_particle_c_charged) ? (prot_Y_data) : (neut_Y_data);

	  const class array<class nlj_struct> &shells_qn_c = data_tau_c.get_shells_quantum_numbers ();

	  const int lc = channel_c.get_LCM_projectile ();

	  const int ZY_charge_basis_potential_pos = data_tau_c.get_ZY_charge_basis_potential_pos ();
	  const int ZY_charge_basis_potential_neg = data_tau_c.get_ZY_charge_basis_potential_neg ();

	  const double jc = channel_c.get_J_projectile ();

	  const double R_charge = data_tau_c.get_R_charge ();

	  const class array<class lj_table<enum potential_type> > &basis_potential_partial_waves_tab_c = data_tau_c.get_basis_potential_partial_waves_tab ();

	  const class lj_table<enum potential_type> &basis_potential_partial_waves_c = basis_potential_partial_waves_tab_c(particle_index_c);
  
	  const enum potential_type H_potential_c = data_tau_c.get_H_potential ();

	  const enum potential_type basis_potential_init_c = basis_potential_partial_waves_c(lc , jc);

	  const bool are_core_basis_potentials_equal_c = are_core_basis_potentials_equal (lc , data_tau_c);

	  const bool OCM_valence_channel_state = OCM_valence_state_determine (shells_qn_c , is_it_COSM , false , false , false , particle_c , lc , jc);

	  const int nc = make_int (ic) + CC_nmin_lj_valence_all;

	  const enum potential_type basis_potential_c = (OCM_valence_channel_state && !are_core_basis_potentials_equal_c) ? (HF) : (basis_potential_init_c);

	  const class HF_nucleons_data &CC_HF_data = (is_particle_c_charged) ? (CC_prot_HF_data) : (CC_neut_HF_data);
	  
	  const bool is_it_OCM_basis = CC_HF_data.get_is_it_OCM_basis ();
	  
	  const class lj_table<bool> &CC_HF_data_is_partial_wave_optimized_HF_MSDHF_tab = CC_HF_data.get_is_partial_wave_optimized_HF_MSDHF_tab ();

	  if (((basis_potential_c == HF) || (basis_potential_c == MSDHF)) && (CC_HF_data_is_partial_wave_optimized_HF_MSDHF_tab(lc , jc) || is_it_OCM_basis))
	    { 
	      const class nlj_table<complex<double> > &CC_Ueq_finite_range_HF_tab = CC_HF_data.get_Ueq_finite_range_tab_uniform ();

	      const class nlj_table<complex<double> > &CC_source_HF_tab = CC_HF_data.get_source_tab_uniform ();

	      for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
		{
		  if ((i >= first_ir) && (i <= last_ir))
		    {
		      Ueq_tab(ic , ic , i) += CC_Ueq_finite_range_HF_tab(nc , lc , jc , i);

		      source_tab(ic , i) += CC_source_HF_tab(nc , lc , jc , i);
		    }
		}
	    }
	  else
	    {
	      const bool good_isospin_basis_potential_c = data_tau_c.get_good_isospin_basis_potential ();

	      const class baryons_data &data_for_potential_c = (good_isospin_basis_potential_c) ? (neut_Y_data) : (data_tau_c);

	      const class array<double> &d_basis_tab   = data_for_potential_c.get_d_basis_tab ();
	      const class array<double> &R0_basis_tab  = data_for_potential_c.get_R0_basis_tab ();	      
	      const class array<double> &Vo_basis_tab  = data_for_potential_c.get_Vo_basis_tab ();
	      const class array<double> &Vso_basis_tab = data_for_potential_c.get_Vso_basis_tab ();

	      const double d   = d_basis_tab  (particle_index_c , lc);
	      const double R0  = R0_basis_tab (particle_index_c , lc);
	      const double Vo  = Vo_basis_tab (particle_index_c , lc);
	      const double Vso = Vso_basis_tab(particle_index_c , lc);
	      
	      const class array<double> &V0_KKNN_tab     = data_for_potential_c.get_V0_KKNN_tab ();  
	      const class array<double> &rho_KKNN_tab    = data_for_potential_c.get_rho_KKNN_tab ();
	      const class array<double> &Vls_KKNN_tab    = data_for_potential_c.get_Vls_KKNN_tab ();
	      const class array<double> &rho_ls_KKNN_tab = data_for_potential_c.get_rho_ls_KKNN_tab ();
  
	      const double V0_KKNN[5] = {V0_KKNN_tab(particle_index_c , 0) ,
					 V0_KKNN_tab(particle_index_c , 1) ,
					 V0_KKNN_tab(particle_index_c , 2) ,
					 V0_KKNN_tab(particle_index_c , 3) ,
					 V0_KKNN_tab(particle_index_c , 4)};
  
	      const double rho_KKNN[5] = {rho_KKNN_tab(particle_index_c , 0) ,
					  rho_KKNN_tab(particle_index_c , 1) ,
					  rho_KKNN_tab(particle_index_c , 2) ,
					  rho_KKNN_tab(particle_index_c , 3) ,
					  rho_KKNN_tab(particle_index_c , 4)};

	      const double Vls_KKNN[3] = {Vls_KKNN_tab(particle_index_c , 0) ,
					  Vls_KKNN_tab(particle_index_c , 1) ,
					  Vls_KKNN_tab(particle_index_c , 2)};
  
	      const double rho_ls_KKNN[3] = {rho_ls_KKNN_tab(particle_index_c , 0) ,
					     rho_ls_KKNN_tab(particle_index_c , 1) ,
					     rho_ls_KKNN_tab(particle_index_c , 2)};
	      
	      switch (H_potential_c)
		{
		case WS:
		  {
		    // Coulomb is added after
		    const class WS_class WS_nuclear_potential (false , d , R0 , Vo , Vso , NEUTRON , NADA , NADA , lc , jc);
		    
		    for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
		      {
			if ((i >= first_ir) && (i <= last_ir)) 
			  {
			    const double r = r_bef_R_tab_uniform(i);
			    
			    Ueq_tab(ic , ic , i) += WS_nuclear_potential(r);
			  }
		      }
		  } break;

		case WS_ANALYTIC:
		  {
		    const class WS_analytic_class WS_nuclear_potential (false , d , R0 , Vo , Vso , NEUTRON , NADA , NADA , lc , jc);
		    
		    for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
		      {
			if ((i >= first_ir) && (i <= last_ir))
			  {
			    const double r = r_bef_R_tab_uniform(i);
			    
			    Ueq_tab(ic , ic , i) += WS_nuclear_potential(r);
			  }
		      }
		  } break;
		
		case KKNN:
		  {
		    const class KKNN_class KKNN_nuclear_potential (false , V0_KKNN , rho_KKNN , Vls_KKNN , rho_ls_KKNN , NEUTRON , NADA , NADA , lc , jc);

		    for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
		      {
			if ((i >= first_ir) && (i <= last_ir))
			  {
			    const double r = r_bef_R_tab_uniform(i);

			    Ueq_tab(ic , ic , i) += KKNN_nuclear_potential(r);
			  }
		      }
		  } break;

		default: abort_all ();
		}
	    }

	  if (first_ir == 0) 
	    Ueq_tab(ic , ic , 0) = 2.0*Ueq_tab(ic , ic , 1) - Ueq_tab(ic , ic , 2);

	  class array<double> V_Coulomb_tab (N_bef_R_uniform);
	  
	  Coulomb_potential::local_potential_calc (false , H_potential_c , particle_c , ZY_charge_basis_potential_pos , ZY_charge_basis_potential_neg , R_charge , r_bef_R_tab_uniform , V_Coulomb_tab);

	  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	    {
	      if ((i >= first_ir) && (i <= last_ir)) Ueq_tab(ic , ic , i) += V_Coulomb_tab(i);
	    }
	}
    }
}












void CC_potentials_one_baryon::Ueq_source_calc (
						 const bool is_it_entrance_channel_only_iterative , 
						 const bool is_it_entrance_channel_only , 
						 const bool is_it_symmetrized , 
						 const double new_potential_fraction , 
						 const class CC_state_class &CC_state , 
						 const class interaction_class &inter_data_basis , 
						 const class baryons_data &prot_Y_data , 
						 const class baryons_data &neut_Y_data , 
						 const class HF_nucleons_data &CC_prot_HF_data , 
						 const class HF_nucleons_data &CC_neut_HF_data , 
						 class CC_Hamiltonian_data &CC_H_data)
{
  const unsigned int N_channels = CC_state.get_N_channels ();

  const unsigned int N_bef_R_uniform = CC_state.get_N_bef_R_uniform ();

  const unsigned int ic_entrance = CC_state.get_ic_entrance ();

  const double R_cut_function = CC_H_data.get_R_cut_function ();
  const double d_cut_function = CC_H_data.get_d_cut_function ();

  const double Ueq_regularizor = CC_H_data.get_Ueq_regularizor ();

  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  const class array<class CC_channel_class> &channels_tab = CC_state.get_channels_tab ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);

  const class array<complex<double> > &CC_wf_bef_R_tab_uniform  = CC_state.get_CC_wf_bef_R_tab_uniform ();
  const class array<complex<double> > &CC_dwf_bef_R_tab_uniform = CC_state.get_CC_dwf_bef_R_tab_uniform ();

  const class array<complex<double> > &CC_asymptotic_in_zero_wf_bef_R_tab_uniform = CC_state.get_CC_asymptotic_in_zero_wf_bef_R_tab_uniform ();
  
  const class array<double> &r_bef_R_tab_uniform = CC_state.get_r_bef_R_tab_uniform ();

  const class array<class vector_class<complex<double> > > &HO_overlaps_Fermi = CC_state.get_HO_overlaps_Fermi ();

  const class array<double> &HO_wfs_bef_R_tab_uniform = CC_H_data.get_HO_wfs_bef_R_tab_uniform ();

  class array<complex<double> > &Ueq_tab = CC_H_data.get_Ueq_tab ();

  class array<complex<double> > &source_tab = CC_H_data.get_source_tab ();

  class array<complex<double> > Ueq_tab_new = Ueq_tab;

  class array<complex<double> > source_tab_new = source_tab;

  Ueq_tab_new = 0.0;
  
  source_tab_new = 0.0;

  // Initialization of the part coming from the local hamiltonian
  potential_diagonal_source_init (is_it_COSM , is_it_entrance_channel_only , CC_state , prot_Y_data , neut_Y_data , CC_prot_HF_data , CC_neut_HF_data , Ueq_tab_new , source_tab_new);

  const unsigned int first_ir = basic_first_index_determine_for_MPI (N_bef_R_uniform , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_ir = basic_last_index_determine_for_MPI (N_bef_R_uniform , NUMBER_OF_PROCESSES , THIS_PROCESS); 

  const class array<class matrix<complex<double> > > &finite_range_orthogonalized_potential_HO_submatrices = CC_H_data.get_finite_range_orthogonalized_potential_HO_submatrices ();
 
  if (!is_it_entrance_channel_only_iterative)
    {
      // Calculation of the part coming from non-local matrix elements
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  if (!is_it_entrance_channel_only || (ic == ic_entrance))
	    {
	      const class CC_channel_class &channel_c = channels_tab(ic);
	      
	      const int lc = channel_c.get_LCM_projectile ();

	      const int nmax_HO_lc = nmax_HO_lab_tab(lc);

	      for (unsigned int icp = 0 ; icp < N_channels ; icp++)
		{
		  if (!is_it_entrance_channel_only || (icp == ic_entrance))
		    {
		      const class vector_class<complex<double> > &HO_overlaps_Fermi_cp = HO_overlaps_Fermi(icp); 

		      const class matrix<complex<double> > &finite_range_orthogonalized_potential_HO_submatrix_c_cp = finite_range_orthogonalized_potential_HO_submatrices(ic , icp);

		      const class vector_class<complex<double> > HO_MEs_Uccp_ucp = finite_range_orthogonalized_potential_HO_submatrix_c_cp*HO_overlaps_Fermi_cp;

		      if (HO_MEs_Uccp_ucp.infinite_norm () != 0.0)
			{
			  for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
			    {
			      if ((i >= first_ir) && (i <= last_ir)) 
				{
				  const double r = r_bef_R_tab_uniform(i);

				  complex<double> Uccp_ucp_r = 0.0;

				  for (int nHOc = 0 ; nHOc <= nmax_HO_lc ; nHOc++)
				    Uccp_ucp_r += HO_wfs_bef_R_tab_uniform(ic , nHOc , i)*HO_MEs_Uccp_ucp(nHOc);

				  Uccp_ucp_r *= Fermi_like_function (R_cut_function , d_cut_function , r);
				  //Uccp_ucp_r *= 1.0 - Fermi_like_function (1.0 , d_cut_function , r);

				  const complex<double> asymptotic_value_cp_r = CC_asymptotic_in_zero_wf_bef_R_tab_uniform(icp , i);

				  const complex<double> wfcp_r  = CC_wf_bef_R_tab_uniform(icp , i);
				  const complex<double> dwfcp_r = CC_dwf_bef_R_tab_uniform(icp , i);

				  const double exp_term_wfcp_zeros_cancel = exp (-Ueq_regularizor * norm (wfcp_r) / norm (dwfcp_r));

				  const double exp_term_wfcp_origin_restore = exp (-Ueq_regularizor * norm (asymptotic_value_cp_r/wfcp_r - 1.0));

				  const double Fcp = exp_term_wfcp_zeros_cancel * (1.0 - exp_term_wfcp_origin_restore);

				  const complex<double> Uccp_ucp_r_Fcp = Uccp_ucp_r*Fcp;

				  const complex<double> Ueq_part = (Uccp_ucp_r - Uccp_ucp_r_Fcp) / wfcp_r;

				  Ueq_tab_new(ic , icp , i) += Ueq_part;

				  source_tab_new(ic , i) += Uccp_ucp_r_Fcp;
				}}}}}}
	}
      
      // Symmetrization of the equivalent potential
      if (is_it_symmetrized)
	{
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
	  for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++) 
	    {
	      if ((i >= first_ir) && (i <= last_ir)) 
		{
		  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
		    { 
		      if (!is_it_entrance_channel_only || (ic == ic_entrance))
			{
			  const complex<double> asymptotic_value_c_r = CC_asymptotic_in_zero_wf_bef_R_tab_uniform(ic , i);
			  
			  const complex<double> wfc_r  = CC_wf_bef_R_tab_uniform(ic , i);
			  const complex<double> dwfc_r = CC_dwf_bef_R_tab_uniform(ic , i);
			    
			  const double exp_term_wfcp_zeros_cancel = exp (-Ueq_regularizor * norm (wfc_r) / norm (dwfc_r));

			  const double exp_term_wfcp_origin_restore = exp (-Ueq_regularizor * norm (asymptotic_value_c_r/wfc_r - 1.0));

			  const double Fc = exp_term_wfcp_zeros_cancel * (1.0 - exp_term_wfcp_origin_restore);
			    
			  const complex<double> one_minus_Fc_wfc_ratio = (1.0 - Fc)/wfc_r;

			  for (unsigned int icp = 0 ; icp < N_channels ; icp++)
			    {
			      if ((icp != ic) && ((!is_it_entrance_channel_only || (icp == ic_entrance))))
				{
				  const complex<double> wfcp_r = CC_wf_bef_R_tab_uniform(icp , i);
				  
				  const complex<double> Ueq_potentials_half_difference_wfcp_r = 0.5 * (Ueq_tab(ic , icp , i) - Ueq_tab(icp , ic , i)) * wfcp_r;
				    
				  Ueq_tab_new(ic , ic , i) += Ueq_potentials_half_difference_wfcp_r * one_minus_Fc_wfc_ratio;
				  
				  source_tab_new(ic , i) += Ueq_potentials_half_difference_wfcp_r * Fc;
				}}}}
		}
	      
	      for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
		{
		  if (!is_it_entrance_channel_only || (ic == ic_entrance))
		    {
		      for (unsigned int icp = 0 ; icp < ic ; icp++)
			{
			  if (!is_it_entrance_channel_only || (icp == ic_entrance))
			    {
			      Ueq_tab_new(ic , icp , i) = 0.5 * (Ueq_tab_new(ic , icp , i) + Ueq_tab_new(icp , ic , i));
			      
			      Ueq_tab_new(icp , ic , i) = Ueq_tab_new(ic , icp , i); 
			    }}}}}}
    }
  else
    {
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  if (ic != ic_entrance)
	    {
	      for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++) 
		{
		  if ((i >= first_ir) && (i <= last_ir)) 
		    Ueq_tab_new(ic , ic_entrance , i) = 0.1*Ueq_tab_new(ic_entrance , ic_entrance , i);
		}
	    }
	}
    }
  
  // Calculation of the equivalent potential and source at r=0

  if (first_ir == 0)
    {
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	    Ueq_tab_new(ic , icp , 0) = 2.0*Ueq_tab_new(ic , icp , 1) - Ueq_tab_new(ic , icp , 2);
	
	  source_tab_new(ic , 0) = 0.0;
	}
    }
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized)
    {
      Ueq_tab_new.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);

      source_tab_new.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
    }
  
#endif

  Ueq_source_averaged_calc (new_potential_fraction , Ueq_tab_new , source_tab_new , Ueq_tab , source_tab);
}





