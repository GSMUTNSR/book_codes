#include "../CC_include/CC_include_def.h"

using namespace Wigner_signs;



//--// return <uc_f lf jf || E_L || uc_i li ji>
TYPE CC_EM_transitions_MEs::one_nucleon::electric::OBME_reduced_calc (
								      const int L , 
								      const bool is_it_longwavelength_approximation , 
								      const double effective_charge , 
								      const class CC_state_class &CC_state_in , 
								      const class CC_state_class &CC_state_out , 
								      const unsigned int ic_in , 
								      const unsigned int ic_out)
{
  const unsigned int BP_Op = BP_EM_determine (ELECTRIC , L);
  
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();
  
  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();
  
  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out) != BP_Op) return 0.0;
    
  const enum particle_type projectile_in  = channel_c_in.get_projectile ();
  const enum particle_type projectile_out = channel_c_out.get_projectile ();
  
  if (projectile_in != projectile_out) return 0.0;
  
  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();
  
  const int Lmin = abs (make_int (J_projectile_in - J_projectile_out));

  const int Lmax = make_int (J_projectile_in + J_projectile_out);

  if ((L < Lmin) || (L > Lmax)) return 0.0;

  //--// calculations of the radial electric charge and current
  const TYPE ECH_radial_ME = radial::radial_integral_calc (ELECTRIC_CHARGE_RADIAL  , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE EC_radial_ME  = radial::radial_integral_calc (ELECTRIC_CURRENT_RADIAL , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);

  //--// here the angular part <lf jf || E_L || li ji> is taken into account

  const TYPE ECH_ME = static_cast<TYPE> (EM_suboperator_OBME_reduced_calc (ELECTRIC_CHARGE  , L , NADA , projectile_out , effective_charge , NADA , ECH_radial_ME ,
									   LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out));
  
  const TYPE EC_ME  = static_cast<TYPE> (EM_suboperator_OBME_reduced_calc (ELECTRIC_CURRENT , L , NADA , projectile_out , effective_charge , NADA , EC_radial_ME ,
									   LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out));

  const TYPE electric_ME = ECH_ME + EC_ME;

  return electric_ME;
}









//--// return <uc_f lf jf || M_L || uc_i li ji>
TYPE CC_EM_transitions_MEs::one_nucleon::magnetic::OBME_reduced_calc (
								      const int L , 
								      const bool is_it_longwavelength_approximation , 
								      const class CC_state_class &CC_state_in , 
								      const class CC_state_class &CC_state_out , 
								      const unsigned int ic_in , 
								      const unsigned int ic_out)
{	
  const unsigned int BP_Op = BP_EM_determine (MAGNETIC , L);

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out) != BP_Op) return 0.0;
  
  const enum particle_type projectile_in  = channel_c_in.get_projectile ();
  const enum particle_type projectile_out = channel_c_out.get_projectile ();

  if (projectile_in != projectile_out) return 0.0;
  
  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  const int Lmin = abs (make_int (J_projectile_in - J_projectile_out));

  const int Lmax = make_int (J_projectile_in + J_projectile_out);

  if ((L < Lmin) || (L > Lmax)) return 0.0;
  
  // calculations of the radial magnetic charge and current

  const TYPE MOLP1_radial_ME = radial::radial_integral_calc (GRADIENT_BESSEL_YLP1                    , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE MOLM1_radial_ME = radial::radial_integral_calc (GRADIENT_BESSEL_YLM1                    , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE MSLP1_radial_ME = radial::radial_integral_calc (GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLP1 , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE MSLM1_radial_ME = radial::radial_integral_calc (GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLM1 , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE MSSCE_radial_ME = radial::radial_integral_calc (MAGNETIC_SPIN_S_SCALAR_E_RADIAL         , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);

  // here the angular part <lf jf || M_L || li ji> is taken into account

  const TYPE MOLP1_ME = static_cast<TYPE> (EM_suboperator_OBME_reduced_calc (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1 , L , NADA , projectile_out , NADA , NADA , MOLP1_radial_ME ,
									     LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out));
  
  const TYPE MOLM1_ME = static_cast<TYPE> (EM_suboperator_OBME_reduced_calc (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1 , L , NADA , projectile_out , NADA , NADA , MOLM1_radial_ME ,
									     LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out));
    
  const TYPE MSLP1_ME = static_cast<TYPE> (EM_suboperator_OBME_reduced_calc (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLP1 , L , NADA , projectile_out , NADA , NADA , MSLP1_radial_ME ,
									     LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out));

  const TYPE MSLM1_ME = static_cast<TYPE> (EM_suboperator_OBME_reduced_calc (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLM1 , L , NADA , projectile_out , NADA , NADA , MSLM1_radial_ME ,
									     LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out));
  
  const TYPE MSSCE_ME = static_cast<TYPE> (EM_suboperator_OBME_reduced_calc (MAGNETIC_SPIN_S_SCALAR_E , L , NADA , projectile_out , NADA , NADA , MSSCE_radial_ME ,
									     LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out));
  
  const TYPE magnetic_ME = MOLP1_ME + MOLM1_ME + MSLP1_ME + MSLM1_ME + MSSCE_ME;

  return magnetic_ME;
}







// return <uc_f lf jf || M/E_L || uc_i li ji>
TYPE CC_EM_transitions_MEs::one_nucleon::OBME_reduced_calc (
							    const enum EM_type EM , 
							    const int L , 
							    const bool is_it_longwavelength_approximation , 
							    const double effective_charge , 
							    const class CC_state_class &CC_state_in , 
							    const class CC_state_class &CC_state_out , 
							    const unsigned int ic_in , 
							    const unsigned int ic_out)
{
  switch (EM)
    {
    case ELECTRIC: return electric::OBME_reduced_calc (L , is_it_longwavelength_approximation , effective_charge , CC_state_in , CC_state_out , ic_in , ic_out);      
    case MAGNETIC: return magnetic::OBME_reduced_calc (L , is_it_longwavelength_approximation ,                    CC_state_in , CC_state_out , ic_in , ic_out);
      
    default: abort_all ();
    }

  return NADA;
}




