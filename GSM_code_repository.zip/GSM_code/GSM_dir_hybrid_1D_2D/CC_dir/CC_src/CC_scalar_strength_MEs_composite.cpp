#include "../CC_include/CC_include_def.h"

using namespace inputs_misc;
using namespace CC_observables_common;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;

// calculation of the antisymetrized + HO ME
void CC_scalar_strength_MEs::composite::target_projectile_as_HO_NBMEs_calc (
									    class GSM_vector &PSI_full , 
									    const bool is_it_one_nucleon_COSM_case ,
									    const enum operator_type Op ,
									    const bool is_it_radial , 
									    const bool is_it_Gauss_Legendre ,
									    const class CC_Hamiltonian_data &CC_H_data , 
									    const class CC_state_class &CC_state , 
									    const class input_data_str &input_data_CC_Berggren , 
									    class nucleons_data &prot_data , 
									    class nucleons_data &neut_data ,
									    const class array<class cluster_data> &cluster_projectile_data_tab , 
									    const class array<class vector_class<complex<double> > > &CC_HO_overlaps , 
									    class array<TYPE> &strength_tab)
{
  const enum space_type space = input_data_CC_Berggren.get_space ();

  const enum interaction_type inter = input_data_CC_Berggren.get_inter ();

  const bool truncation_hw = input_data_CC_Berggren.get_truncation_hw ();
  const bool truncation_ph = input_data_CC_Berggren.get_truncation_ph ();

  const int n_holes_max = input_data_CC_Berggren.get_n_holes_max ();

  const int n_holes_max_p = prot_data.get_n_holes_max ();
  const int n_holes_max_n = neut_data.get_n_holes_max ();
  
  const int n_scat_max = input_data_CC_Berggren.get_n_scat_max ();

  const int n_scat_max_p = prot_data.get_n_scat_max ();
  const int n_scat_max_n = neut_data.get_n_scat_max ();

  const int E_max_hw = input_data_CC_Berggren.get_E_max_hw ();

  const int Ep_max_hw = prot_data.get_E_max_hw ();
  const int En_max_hw = neut_data.get_E_max_hw ();

  const unsigned int BP = CC_state.get_BP ();

  const double J = CC_state.get_J ();

  const double M = J;

  // composite states (they have to be read in files)
  // they correspond to the [a^+ PSI_GSM]_M^J

  class GSM_vector_helper_class PSI_HO_helper (is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
					       n_holes_max   , n_scat_max   , E_max_hw  ,
					       n_holes_max_p , n_scat_max_p , Ep_max_hw ,
					       n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , true , prot_data , neut_data);

  class GSM_vector PSI_HO (PSI_HO_helper);
  target_projectile_PSI_HO_calc (is_it_one_nucleon_COSM_case , input_data_CC_Berggren , cluster_projectile_data_tab , CC_H_data , CC_state , CC_HO_overlaps , prot_data , neut_data , PSI_HO);

  switch (Op)
    {
    case DENSITY: density::calc_one_pair (is_it_radial , is_it_Gauss_Legendre , PSI_full , PSI_HO , PSI_HO , prot_data , neut_data , strength_tab); break;
      
    case RMS_RADIUS_PROTON:  rms_radius_one_body_strength::calc_one_strength (Op , is_it_Gauss_Legendre , PSI_full , PSI_HO , PSI_HO , prot_data , neut_data , strength_tab); break;
    case RMS_RADIUS_NEUTRON: rms_radius_one_body_strength::calc_one_strength (Op , is_it_Gauss_Legendre , PSI_full , PSI_HO , PSI_HO , prot_data , neut_data , strength_tab); break;

    default: error_message_print_abort ("Density or rms radii strength only in CC_scalar_strength_MEs::composite::target_projectile_as_HO_NBMEs_calc.get_");      
    }
  	
#ifdef UseMPI
  if (is_it_MPI_parallelized) strength_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}









// target nas
// common to the non antisymetrized (nas) and for the non antisymetrized + HO (nas_HO)
void CC_scalar_strength_MEs::composite::target_nas_NBMEs_calc (
							       const bool is_it_radial , 
							       const bool is_it_Gauss_Legendre ,
							       const class CC_target_projectile_composite_data &Tpc_data , 
							       const class CC_state_class &CC_state , 
							       const class array<TYPE> &target_NBMEs , 
							       class array<TYPE> &strength_tab)
{
  const class array<unsigned int> &target_indices = Tpc_data.get_target_indices ();

  const class array<class CC_channel_class> &channels_tab_JPi_A = CC_state.get_channels_tab ();

  const unsigned int N_channels_JPi_A = CC_state.get_N_channels ();

  const unsigned int N_bef_R_GL = CC_state.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state.get_N_bef_R_uniform ();
  
  const unsigned int Nk_momentum_GL = CC_state.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = CC_state.get_Nk_momentum_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL)     : (N_bef_R_uniform);
  const unsigned int Nk = (is_it_Gauss_Legendre) ? (Nk_momentum_GL) : (Nk_momentum_uniform);

  const unsigned int Nrk = (is_it_radial) ? (Nr) : (Nk);
  
  class array<TYPE> radial_momentum_OBMEs(Nrk);
  
  strength_tab = 0.0;

  // "out" target state
  for (unsigned int ic_out = 0 ; ic_out < N_channels_JPi_A ; ic_out++)
    {
      const class CC_channel_class &channel_c_out = channels_tab_JPi_A(ic_out);

      const enum particle_type projectile_c_out = channel_c_out.get_projectile ();

      const unsigned int BP_Tc_out = channel_c_out.get_BP_Tc ();

      const unsigned int vector_index_Tc_out = channel_c_out.get_vector_index_Tc ();

      const double J_Tc_out = channel_c_out.get_J_Tc ();

      const double J_projectile_c_out = channel_c_out.get_J_projectile ();

      const int LCM_projectile_c_out = channel_c_out.get_LCM_projectile ();

      const int two_J_Tc_out = make_int (2.0*J_Tc_out);

      const unsigned int iTc_out = target_indices(BP_Tc_out , two_J_Tc_out , vector_index_Tc_out);

      // "in" target state
      for (unsigned int ic_in = 0 ; ic_in < N_channels_JPi_A ; ic_in++)
	{
	  const class CC_channel_class &channel_c_in = channels_tab_JPi_A(ic_in);

	  const enum particle_type projectile_c_in = channel_c_in.get_projectile ();

	  const unsigned int BP_Tc_in = channel_c_in.get_BP_Tc ();

	  const unsigned int vector_index_Tc_in = channel_c_in.get_vector_index_Tc ();

	  const double J_Tc_in = channel_c_in.get_J_Tc ();

	  const double J_projectile_c_in = channel_c_in.get_J_projectile ();

	  const int LCM_projectile_c_in = channel_c_in.get_LCM_projectile ();

	  const int two_J_Tc_in = make_int (2.0*J_Tc_in);

	  const unsigned int iTc_in = target_indices(BP_Tc_in , two_J_Tc_in , vector_index_Tc_in);

	  const bool BP_targets_condition = (BP_Tc_in == BP_Tc_out);

	  const bool J_targets_condition = (make_int (J_Tc_out - J_Tc_in) == 0);
	  
	  const bool projectiles_condition = (projectile_c_in == projectile_c_out);

	  const bool LCM_projectiles_condition = (LCM_projectile_c_out == LCM_projectile_c_in);

	  const bool J_projectiles_condition = (make_int (J_projectile_c_out - J_projectile_c_in) == 0);

	  // deltas (is it the same projectile and quantum numbers are conserved)
	  if (BP_targets_condition && J_targets_condition && projectiles_condition && LCM_projectiles_condition && J_projectiles_condition)
	    {
	      if (is_it_radial)
		radial_momentum::radial_OBMEs_calc (OVERLAP , is_it_Gauss_Legendre , CC_state , ic_in , ic_out , radial_momentum_OBMEs);
	      else
		radial_momentum::momentum_OBMEs_calc (is_it_Gauss_Legendre , CC_state , ic_in , ic_out , radial_momentum_OBMEs);

	      for (unsigned int i = 0 ; i < Nrk ; i++)
		{
		  //get cf_<Jf | Op(scalar) (T) | Ji>_ci
		  const TYPE target_NBME = target_NBMEs(iTc_in , iTc_out , i);

		  // calculation of int_0^inf dr u_cf (r) * u_ci (r)
		  // radial factor
		  const TYPE factor_radial_momentum = radial_momentum_OBMEs(i);

		  // calculation of sum_{cf , ci} cf_<Jf | Op(scalar) (T) | Ji>_ci
		  const TYPE total_NBME = target_NBME * factor_radial_momentum;
	      
		  strength_tab(i) += total_NBME;
		} //loop Nrk
	    }//deltas
	}//loop ic_in
    }//loop ic_out
}











// projectile
// for the non antisymmetrized (nas) NBME
// the CC_state is used
// common to nas and nas+HO
void CC_scalar_strength_MEs::composite::projectile_nas_NBMEs_calc (
								   const enum operator_type Op ,
								   const bool is_it_radial , 
								   const bool is_it_Gauss_Legendre ,
								   const class input_data_str &input_data_CC_Berggren , 
								   const class CC_target_projectile_composite_data &Tpc_data , 
								   const class CC_state_class &CC_state ,
								   const class array<class cluster_data> &cluster_projectile_data_tab , 
								   class array<TYPE> &strength_tab)
{
  const bool is_it_one_nucleon_COSM_case = Tpc_data.get_is_it_one_nucleon_COSM_case ();

  const class array<class CC_channel_class> &channels_tab_JPi_A = CC_state.get_channels_tab ();
  
  const unsigned int N_channels_JPi_A = CC_state.get_N_channels ();

  const int Z = input_data_CC_Berggren.get_Z ();
  const int N = input_data_CC_Berggren.get_N ();

  const double mp = input_data_CC_Berggren.get_prot_mass_for_calc ();
  const double mn = input_data_CC_Berggren.get_neut_mass_for_calc ();
 
  const unsigned int N_bef_R_GL = CC_state.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state.get_N_bef_R_uniform ();
  
  const unsigned int Nk_momentum_GL = CC_state.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = CC_state.get_Nk_momentum_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL)     : (N_bef_R_uniform);
  const unsigned int Nk = (is_it_Gauss_Legendre) ? (Nk_momentum_GL) : (Nk_momentum_uniform);

  const unsigned int Nrk = (is_it_radial) ? (Nr) : (Nk);
  
  class array<TYPE> strength_tab_fixed_channels(Nrk);
  
  strength_tab = 0.0;

  if (Op == DENSITY)
    {
      CC_state.density_calc (is_it_radial , is_it_Gauss_Legendre , strength_tab);
      
      return;
    }
  
  if (!is_it_radial || ((Op != RMS_RADIUS_PROTON) && (Op != RMS_RADIUS_NEUTRON)))
    error_message_print_abort ("Rms radii strength only at this level in CC_scalar_strength_MEs::composite::projectile_nas_NBMEs_calc");
 
  for (unsigned int ic_out = 0 ; ic_out < N_channels_JPi_A ; ic_out++)
    {
      const class CC_channel_class &channel_c_out = channels_tab_JPi_A(ic_out);

      const int LCM_projectile_c_out = channel_c_out.get_LCM_projectile ();

      const unsigned int BP_Tc_out = channel_c_out.get_BP_Tc ();

      const unsigned int bp_c_out = binary_parity_from_orbital_angular_momentum (LCM_projectile_c_out);

      const unsigned int vector_index_Tc_out = channel_c_out.get_vector_index_Tc ();

      const double J_projectile_c_out = channel_c_out.get_J_projectile ();

      const double J_Tc_out = channel_c_out.get_J_Tc ();

      const enum particle_type projectile_c_out = channel_c_out.get_projectile ();

      for (unsigned int ic_in = 0 ; ic_in < N_channels_JPi_A ; ic_in++)
	{
	  const class CC_channel_class &channel_c_in = channels_tab_JPi_A(ic_in);

	  const int LCM_projectile_c_in = channel_c_in.get_LCM_projectile ();

	  const unsigned int BP_Tc_in = channel_c_in.get_BP_Tc ();

	  const unsigned int bp_c_in = binary_parity_from_orbital_angular_momentum (LCM_projectile_c_in);

	  const unsigned int vector_index_Tc_in = channel_c_in.get_vector_index_Tc ();

	  const double J_projectile_c_in = channel_c_in.get_J_projectile ();

	  const double J_Tc_in = channel_c_in.get_J_Tc ();

	  const enum particle_type projectile_c_in = channel_c_in.get_projectile ();

	  const bool BP_targets_condition = (BP_Tc_in == BP_Tc_out);

	  const bool J_targets_condition = (make_int (J_Tc_in - J_Tc_out) == 0);

	  const bool vector_index_targets_condition = (vector_index_Tc_in == vector_index_Tc_out);
	 
	  const bool projectiles_condition = (projectile_c_in == projectile_c_out);

	  const bool bp_projectiles_condition = (bp_c_in == bp_c_out);

	  const bool J_projectiles_condition = (make_int (J_projectile_c_in - J_projectile_c_out) == 0);
	  
	  // delta (if it is the same target and quantum numbers are conserved)
	  if (BP_targets_condition && J_targets_condition && vector_index_targets_condition && projectiles_condition && bp_projectiles_condition && J_projectiles_condition)
	    {
	      const unsigned int ic  = (!is_it_one_nucleon_COSM_case) ? (cluster_data_index_determine (projectile_c_in  , cluster_projectile_data_tab)) : (NADA);
	      const unsigned int icp = (!is_it_one_nucleon_COSM_case) ? (cluster_data_index_determine (projectile_c_out , cluster_projectile_data_tab)) : (NADA);
	    
	      const double rms_radius_factor = (is_it_one_nucleon_COSM_case) 
		? (rms_radius_one_body_factor_calc (Op , projectile_c_out , mp , mn , Z , N)) 
		: (rms_radius_CM_factor_calc (Op , projectile_c_out , mp , mn , Z , N));
 
	      //================================== nas ==================================//
	      // return <uc_f lf jf | Op(scalar) | uc_i li ji>
	      //:::// a voir si c'est correct

	      if (is_it_one_nucleon_COSM_case) 
		one_nucleon::OBMEs_calc (is_it_Gauss_Legendre , rms_radius_factor , CC_state , ic_in , ic_out , strength_tab_fixed_channels);
	      else
		cluster::MEs_calc (is_it_Gauss_Legendre , Tpc_data , rms_radius_factor , ic , icp , CC_state , ic_in , ic_out , strength_tab_fixed_channels);
	   	      
	      strength_tab += strength_tab_fixed_channels;
	    }//delta
	}//loop ic_in
    }//loop_ic_out
}







// cf_<J_Tf |Op(scalar) (T) | J_Ti>_ci NBMEs stored
void CC_scalar_strength_MEs::composite::target_NBMEs_calc (
							   class GSM_vector &PSI_full ,
							   const enum interaction_type inter ,
							   const enum operator_type Op ,
							   const bool is_it_radial , 
							   const bool is_it_Gauss_Legendre ,
							   const bool full_common_vectors_used_in_file ,
							   const class CC_target_projectile_composite_data &Tpc_data , 
							   class array<class nucleons_data> &prot_data_one_cluster_less_tab , 
							   class array<class nucleons_data> &neut_data_one_cluster_less_tab , 
							   class array<TYPE> &target_NBMEs)
{
  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();

  const int n_holes_max = Tpc_data.get_n_holes_max ();
  
  const int n_scat_max = Tpc_data.get_n_scat_max ();

  const int E_relative_max_hw = Tpc_data.get_E_relative_max_hw ();

  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();
  
  const class array<unsigned int> &BP_target_tab = Tpc_data.get_BP_target_tab ();

  const class array<double> &J_target_tab = Tpc_data.get_J_target_tab ();

  const class array<unsigned int> &vector_index_target_tab = Tpc_data.get_vector_index_target_tab ();

  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();

  const class array<TYPE> &E_target_tab =  Tpc_data.get_E_target_tab ();

  const class GSM_vector_helper_class dummy_helper;

  const unsigned int Nrk = target_NBMEs.dimension (2);
 	  
  class array<TYPE> target_NBMEs_fixed_targets(Nrk);
  
  // "out" target state
  for (unsigned int iT_out = 0 ; iT_out < N_target_projectile_states ; iT_out++)
    {
      const unsigned int BP_target_out = BP_target_tab(iT_out);

      const unsigned int vector_index_target_out = vector_index_target_tab(iT_out);

      const double J_target_out = J_target_tab(iT_out);

      const double M_target_out = J_target_out;

      const TYPE E_target_out = E_target_tab(iT_out);

      const enum particle_type projectile_out = projectile_tab(iT_out);

      const int Z_projectile_out = Z_cluster_determine (projectile_out);
      const int N_projectile_out = N_cluster_determine (projectile_out);

      class nucleons_data &prot_data_target_out = prot_data_one_cluster_less_tab(Z_projectile_out , N_projectile_out);
      class nucleons_data &neut_data_target_out = neut_data_one_cluster_less_tab(Z_projectile_out , N_projectile_out);

      const int n_holes_max_p_target_out = prot_data_target_out.get_n_holes_max ();
      const int n_holes_max_n_target_out = neut_data_target_out.get_n_holes_max ();
      
      const int n_scat_max_p_target_out = prot_data_target_out.get_n_scat_max ();
      const int n_scat_max_n_target_out = neut_data_target_out.get_n_scat_max ();

      const int Zval_target_out = prot_data_target_out.get_N_valence_nucleons ();
      const int Nval_target_out = neut_data_target_out.get_N_valence_nucleons ();

      const int n_scat_max_target_out = min (n_scat_max , n_scat_max_p_target_out + n_scat_max_n_target_out);

      const int Z_target_out = prot_data_target_out.get_N_nucleons ();
      const int N_target_out = neut_data_target_out.get_N_nucleons ();

      const int Ep_max_hw_target_out = prot_data_target_out.get_E_max_hw ();
      const int En_max_hw_target_out = neut_data_target_out.get_E_max_hw ();

      const int E_min_hw_target_out = prot_data_target_out.get_E_min_hw () + neut_data_target_out.get_E_min_hw ();

      const int E_max_hw_target_out = E_relative_max_hw + E_min_hw_target_out;

      const enum space_type space_target_out = space_determine (Zval_target_out , Nval_target_out);

      const class correlated_state_str PSI_target_out (Z_target_out , N_target_out , BP_target_out , J_target_out , vector_index_target_out , E_target_out , NADA , NADA , NADA , false);
 
      class GSM_vector_helper_class V_target_out_helper (is_it_MPI_parallelized , space_target_out , inter , false , truncation_hw , truncation_ph ,
							 n_holes_max              , n_scat_max_target_out   , E_max_hw_target_out  , 
							 n_holes_max_p_target_out , n_scat_max_p_target_out , Ep_max_hw_target_out ,
							 n_holes_max_n_target_out , n_scat_max_n_target_out , En_max_hw_target_out , 
							 BP_target_out , M_target_out , true , prot_data_target_out , neut_data_target_out);

      class GSM_vector V_target_out (V_target_out_helper);

      V_target_out.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_target_out);

      // "in" target state
      for (unsigned int iT_in = 0 ; iT_in < N_target_projectile_states ; iT_in++)
	{
	  const unsigned int BP_target_in = BP_target_tab(iT_in);

	  const unsigned int vector_index_target_in = vector_index_target_tab(iT_in);

	  const double J_target_in = J_target_tab(iT_in);

	  const double M_target_in = J_target_in;

	  const TYPE E_target_in = E_target_tab(iT_in);

	  const enum particle_type projectile_in = projectile_tab(iT_in);

	  const int Z_projectile_in = Z_cluster_determine (projectile_in);
	  const int N_projectile_in = N_cluster_determine (projectile_in);

	  class nucleons_data &prot_data_target_in = prot_data_one_cluster_less_tab(Z_projectile_in , N_projectile_in);
	  class nucleons_data &neut_data_target_in = neut_data_one_cluster_less_tab(Z_projectile_in , N_projectile_in);

	  const int n_holes_max_p_target_in = prot_data_target_in.get_n_holes_max ();
	  const int n_holes_max_n_target_in = neut_data_target_in.get_n_holes_max ();
	  
	  const int n_scat_max_p_target_in = prot_data_target_in.get_n_scat_max ();
	  const int n_scat_max_n_target_in = neut_data_target_in.get_n_scat_max ();

	  const int Zval_target_in = prot_data_target_in.get_N_valence_nucleons ();
	  const int Nval_target_in = neut_data_target_in.get_N_valence_nucleons ();

	  const int n_scat_max_target_in = min (n_scat_max , n_scat_max_p_target_in + n_scat_max_n_target_in);

	  const int Z_target_in = prot_data_target_in.get_N_nucleons ();
	  const int N_target_in = neut_data_target_in.get_N_nucleons ();

	  const int Ep_max_hw_target_in = prot_data_target_in.get_E_max_hw ();
	  const int En_max_hw_target_in = neut_data_target_in.get_E_max_hw ();

	  const int E_min_hw_target_in = prot_data_target_in.get_E_min_hw () + neut_data_target_in.get_E_min_hw ();

	  const int E_max_hw_target_in = E_relative_max_hw + E_min_hw_target_in;

	  const enum space_type space_target_in = space_determine (Zval_target_in , Nval_target_in);

	  const class correlated_state_str PSI_target_in (Z_target_in , N_target_in , BP_target_in , J_target_in , vector_index_target_in , E_target_in , NADA , NADA , NADA , false);

	  class GSM_vector_helper_class V_target_in_helper (is_it_MPI_parallelized , space_target_in , inter , false , truncation_hw , truncation_ph ,
							    n_holes_max             , n_scat_max_target_in   , E_max_hw_target_in  , 
							    n_holes_max_p_target_in , n_scat_max_p_target_in , Ep_max_hw_target_in ,
							    n_holes_max_n_target_in , n_scat_max_n_target_in , En_max_hw_target_in , 
							    BP_target_in , M_target_in , true , prot_data_target_in , neut_data_target_in);

	  // deltas (is it the same projectile)
	  if ((space_target_in == space_target_out) && (projectile_in == projectile_out))
	    {
	      class GSM_vector V_target_in (V_target_in_helper);

	      V_target_in.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_target_in);
	      
	      if ((BP_target_in == BP_target_out) && (make_int (J_target_in - J_target_out) == 0))
		{
		  // calculates cf_<J_Tf |Op(scalar) (T) | J_Ti>_ci	
		  
		  switch (Op)
		    {
		    case DENSITY: density::calc_one_pair (is_it_radial , is_it_Gauss_Legendre , PSI_full , V_target_in , V_target_out , prot_data_target_in , neut_data_target_in , target_NBMEs_fixed_targets); break;
      
		    case RMS_RADIUS_PROTON:  rms_radius_one_body_strength::calc_one_strength (Op , is_it_Gauss_Legendre , PSI_full , V_target_in , V_target_out , prot_data_target_in , neut_data_target_in , target_NBMEs_fixed_targets); break;
		    case RMS_RADIUS_NEUTRON: rms_radius_one_body_strength::calc_one_strength (Op , is_it_Gauss_Legendre , PSI_full , V_target_in , V_target_out , prot_data_target_in , neut_data_target_in , target_NBMEs_fixed_targets); break;

		    default: error_message_print_abort ("Density or rms radii strength only in CC_scalar_strength_MEs::composite::target_NBMEs_calc.");      
		    }
		  
		  if (THIS_PROCESS == MASTER_PROCESS)
		    {
		      for (unsigned int i = 0 ; i < Nrk ; i++)
			target_NBMEs(iT_in , iT_out , i) = target_NBMEs_fixed_targets(i);
		    }
		}//deltas projectile
	    }//deltas space projectile
	}//loop iT_in
    }//loop iT_out
  
#ifdef UseMPI
  if (is_it_MPI_parallelized) target_NBMEs.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}












void CC_scalar_strength_MEs::composite::CC_NBMEs_calc (
						       class GSM_vector &PSI_full , 
						       const enum operator_type Op , 
						       const bool is_it_radial , 
						       const bool is_it_Gauss_Legendre , 
						       const class CC_target_projectile_composite_data &Tpc_data , 
						       const class array<class cluster_data> &cluster_projectile_data_tab , 
						       const bool is_it_nas_only , 
						       const class CC_Hamiltonian_data &CC_H_data , 
						       const class CC_state_class &CC_state , 
						       class nucleons_data &prot_data , 
						       class nucleons_data &neut_data , 
						       const class input_data_str &input_data_CC_Berggren , 
						       const class array<TYPE> &target_NBMEs , 
						       class array<TYPE> &strength_tab)
{
  const unsigned int N_bef_R_GL = CC_state.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state.get_N_bef_R_uniform ();

  const unsigned int Nk_momentum_GL = CC_state.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = CC_state.get_Nk_momentum_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL)     : (N_bef_R_uniform);
  const unsigned int Nk = (is_it_Gauss_Legendre) ? (Nk_momentum_GL) : (Nk_momentum_uniform);

  const unsigned int Nrk = (is_it_radial) ? (Nr) : (Nk);
  
  const bool is_it_one_nucleon_COSM_case = Tpc_data.get_is_it_one_nucleon_COSM_case ();
  
  //================================== projectile ==================================//
  // for the non antisymetrized (nas) the CC_state_out/in are used
  // for the non antisymetrized + HO (nas_HO) the CC_state_out/in are projected in the HO basis

  // projection of the out and in states in the HO basis

  class CC_state_class CC_state_HO (CC_state);
  
  CC_state_HO.CC_HO_wfs_projection ();

  class array<TYPE> projectile_nas_strength_tab(Nrk);

  class array<TYPE> target_nas_strength_tab(Nrk);

  //===================================non antisymetrized (nas)==============================================================================

  // sum of the reduced matrix elts for the projectile
  projectile_nas_NBMEs_calc (Op , is_it_radial , is_it_Gauss_Legendre , input_data_CC_Berggren , Tpc_data , CC_state , cluster_projectile_data_tab , projectile_nas_strength_tab);

  // sum of the reduced matrix elts for the target
  target_nas_NBMEs_calc (is_it_radial , is_it_Gauss_Legendre , Tpc_data , CC_state , target_NBMEs , target_nas_strength_tab);

  // calculation of <Jf || O_L || Ji> = sum_{cf , ci} ( cf_<Jf || O_L (p) || Ji>_ci + cf_<Jf || O_L (T) || Ji>_ci )
  // nas

  if (is_it_nas_only)
    {
      strength_tab = projectile_nas_strength_tab + target_nas_strength_tab;

      return;
    }

  class array<TYPE> projectile_nas_HO_strength_tab(Nrk);

  class array<TYPE> target_nas_HO_strength_tab(Nrk);

  class array<TYPE> total_reduced_as_HO_strength_tab(Nrk);

  const class array<TYPE> total_reduced_nas_strength_tab = projectile_nas_strength_tab + target_nas_strength_tab;
      
  // sum of the reduced matrix elts for the projectile (HO)
  projectile_nas_NBMEs_calc (Op , is_it_radial , is_it_Gauss_Legendre , input_data_CC_Berggren , Tpc_data , CC_state_HO , cluster_projectile_data_tab , projectile_nas_HO_strength_tab);

  // sum of the reduced matrix elts for the target (nas_HO)
  target_nas_NBMEs_calc (is_it_radial , is_it_Gauss_Legendre , Tpc_data , CC_state_HO , target_NBMEs , target_nas_HO_strength_tab);

  // calculation of <Jf || O_L || Ji> = sum_{cf , ci} ( cf_<Jf || O_L (p) || Ji>_ci + cf_<Jf || O_L (T) || Ji>_ci )
  // nas and in HO basis
  const class array<TYPE> total_reduced_nas_HO_strength_tab = projectile_nas_HO_strength_tab + target_nas_HO_strength_tab;
     
  //================================== antisymetrized and HO projection (as_HO) ===================================//
  //===============================================================================================================//


  //================================== CC_HO overlaps (<u_c^{HO} | u_n>) ==================================//

  // for the "out" and "in" composite state
  const class array<class vector_class<complex<double> > > &CC_HO_overlaps = CC_state.get_HO_overlaps ();

  //================================== calculation of the antisymetrized + HO ME ==================================//

  // <Jf || O_L || Ji>
  // antisymetrized andf in the HO basis
  target_projectile_as_HO_NBMEs_calc (PSI_full , is_it_one_nucleon_COSM_case , Op , is_it_radial , is_it_Gauss_Legendre , CC_H_data , CC_state , input_data_CC_Berggren ,
				      prot_data , neut_data , cluster_projectile_data_tab , CC_HO_overlaps , total_reduced_as_HO_strength_tab);

  // final result
  strength_tab = total_reduced_nas_strength_tab + (total_reduced_as_HO_strength_tab - total_reduced_nas_HO_strength_tab);
}
