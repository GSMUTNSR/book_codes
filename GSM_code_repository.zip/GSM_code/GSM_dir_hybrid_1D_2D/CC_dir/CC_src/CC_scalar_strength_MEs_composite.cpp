#include "../CC_include/CC_include_def.h"

using namespace inputs_misc;
using namespace CC_observables_common;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_scalar_strength_MEs::radial_momentum;


// TYPE is double or complex
// -------------------------




// Calculation of the strength function of a scalar operator between two channel wave functions
// --------------------------------------------------------------------------------------------
// One calculates <J[f] | Op(r) | J[i]> for all r radii on [0:R], where the radial part reduces to one point (i.e. no integration over r).
// For this, one uses the decomposition <J[f] | Op(r) | J[i]> = <J[f] | Op(r) | J[i]> [nas] + (<J[f] | Op(r) | J[i]> [as-HO] - <J[f] | Op(r) | J[i]> [nas-HO]),
// where as means antisymmetrized channel functions and nas non-antisymmetrized channel functions.
// It is indeed impossible to calculate matrix elements with antisymmetrized channel functions directly because channel wave functions have two-body asymptotes, where target and projectile are not antisymmetrized.
//
// In nas, target and projectile arise from GSM and GSM-CC calculations but are not antisymmetrized with respect to each other in matrix elements formulas.
// One has Op(r) = Op[projectile](r) + Op[target](r), so that one calculates separately the matrix elements of Op[projectile](r) and Op[target](r).
// nas matrix elements <J[f] | Op(r)[target or projectile] | J[i]> = sum_{c[f], c[i]} <J[f] c[f] | Op(r)[target or projectile] | J[i] c[i]>.
// <J[f] c[f] | Op(r)[target or projectile] | J[i] c[i]> are then straightforward to calculate from <JT[f] c[f] | Op[target](r) or Id | JT[i] c[i]> and <Jp[f] | Op[projectile](r) or Id | Jp[i]>.
// <JT[f] c[f] | Op[target](r) | JT[i] c[i]> are given by shell model formulas and <Jp[f] | Op[projectile](r) | Jp[i]> are calculated in CC_scalar_strength_MEs::cluster or CC_scalar_strength_MEs::one_baryon.
// nas-HO is the same as nas except that channel wave functions and targets are all projected in the HO basis.
//
// In as, target and projectile are antisymmetrized in the HO basis : one projects all target and projectile states in the HO basis, so that antisymmetrization is handled with Slater determinants.
// Matrix elements of Op(r) in as are then given by shell model formulas.
//
// As antisymmetrization effects between target and projectile only occur close to the target, it is sufficient to use the HO basis therein (as[HO]).
// The two-body asymptote is taken into account in the non-antisymmetrized calculation.
// It is clear that as, as-HO and nas, nas-HO matrix elements are equal at the limit of infinite HO basis.
// The previous decomposition is thus justified.

void CC_scalar_strength_MEs::composite::target_projectile_as_HO_NBMEs_calc (
									    class GSM_vector &PSI_full , 
									    const bool is_it_one_baryon_COSM_case ,
									    const enum operator_type Op ,
									    const enum particle_type particle , 
									    const bool is_it_radial , 
									    const bool is_it_Gauss_Legendre ,
									    const class CC_Hamiltonian_data &CC_H_data , 
									    const class CC_state_class &CC_state_in , 
									    const class CC_state_class &CC_state_out , 
									    const class input_data_str &input_data_CC_Berggren , 
									    class baryons_data &prot_Y_data , 
									    class baryons_data &neut_Y_data ,
									    const class array<class cluster_data> &cluster_projectile_data_tab , 
									    class array<TYPE> &strength_tab)
{
  const enum space_type space = input_data_CC_Berggren.get_space ();

  const enum interaction_type inter = input_data_CC_Berggren.get_inter ();

  const bool truncation_hw = input_data_CC_Berggren.get_truncation_hw ();
  const bool truncation_ph = input_data_CC_Berggren.get_truncation_ph ();

  const int n_holes_max = input_data_CC_Berggren.get_n_holes_max ();

  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();
  
  const int n_scat_max = input_data_CC_Berggren.get_n_scat_max ();

  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int E_max_hw = input_data_CC_Berggren.get_E_max_hw ();

  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const unsigned int BP = CC_state_in.get_BP ();

  const double J = CC_state_in.get_J ();

  const double M = J;

  const int n_in = CC_state_in.get_n ();

  const int n_out = CC_state_out.get_n ();

  class GSM_vector_helper_class PSI_HO_helper (is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
					       n_holes_max   , n_scat_max   , E_max_hw  ,
					       n_holes_max_p , n_scat_max_p , Ep_max_hw ,
					       n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , true , prot_Y_data , neut_Y_data);

  class GSM_vector PSI_in_HO(PSI_HO_helper);

  target_projectile_PSI_HO_calc (is_it_one_baryon_COSM_case , cluster_projectile_data_tab , CC_H_data , CC_state_in , prot_Y_data , neut_Y_data , PSI_in_HO);

  if (n_in == n_out)
    {
      switch (Op)
	{
	case DENSITY: density::calc_one_pair (is_it_radial , is_it_Gauss_Legendre , PSI_full , PSI_in_HO , PSI_in_HO , strength_tab); break;
      
	default:
	  {
	    if (!is_it_rms_radius_determine (Op)) error_message_print_abort ("Density or rms radii strength only in CC_scalar_strength_MEs::composite::target_projectile_as_HO_NBMEs_calc (same in and out states)");

	    rms_radius_one_body_strength::calc_one_strength (particle , is_it_Gauss_Legendre , PSI_full , PSI_in_HO , PSI_in_HO , strength_tab);
	  } break;
	}
    }
  else
    {
      if (Op != DENSITY) error_message_print_abort ("Transition density only in CC_scalar_strength_MEs::composite::target_projectile_as_HO_NBMEs_calc (different in and out states)");

      class GSM_vector PSI_out_HO(PSI_HO_helper);

      target_projectile_PSI_HO_calc (is_it_one_baryon_COSM_case , cluster_projectile_data_tab , CC_H_data , CC_state_out , prot_Y_data , neut_Y_data , PSI_out_HO);

      density::calc_one_pair (is_it_radial , is_it_Gauss_Legendre , PSI_full , PSI_in_HO , PSI_out_HO , strength_tab);
    }
  	
#ifdef UseMPI
  if (is_it_MPI_parallelized) strength_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}








// Calculation of nas <J[f] | Op[target](r) | J[i]> matrix elements from <JT[f] c[f] | Op[target](r) | JT[i] c[i]> and <Jp[f] | Jp[i]> (see above)
// -----------------------------------------------------------------------------------------------------------------------------------------------

void CC_scalar_strength_MEs::composite::target_nas_NBMEs_calc (
							       const bool is_it_radial , 
							       const bool is_it_Gauss_Legendre ,
							       const class CC_target_projectile_composite_data &Tpc_data , 
							       const class CC_state_class &CC_state_in , 
							       const class CC_state_class &CC_state_out , 
							       const class array<TYPE> &target_NBMEs , 
							       class array<TYPE> &strength_tab)
{
  const class array<unsigned int> &target_indices = Tpc_data.get_target_indices ();

  const class array<class CC_channel_class> &channels_tab_JPi_A_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_JPi_A_out = CC_state_out.get_channels_tab ();

  const unsigned int N_channels_JPi_A_in  = CC_state_in.get_N_channels ();
  const unsigned int N_channels_JPi_A_out = CC_state_out.get_N_channels ();

  const unsigned int N_bef_R_GL = CC_state_in.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state_in.get_N_bef_R_uniform ();
  
  const unsigned int Nk_momentum_GL = CC_state_in.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = CC_state_in.get_Nk_momentum_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL)     : (N_bef_R_uniform);
  const unsigned int Nk = (is_it_Gauss_Legendre) ? (Nk_momentum_GL) : (Nk_momentum_uniform);

  const unsigned int Nrk = (is_it_radial) ? (Nr) : (Nk);
    
  strength_tab = 0.0;

  // "out" target state
  for (unsigned int ic_out = 0 ; ic_out < N_channels_JPi_A_out ; ic_out++)
    {
      const class CC_channel_class &channel_c_out = channels_tab_JPi_A_out(ic_out);

      const enum particle_type projectile_c_out = channel_c_out.get_projectile ();

      const unsigned int BP_Tc_out = channel_c_out.get_BP_Tc ();

      const unsigned int vector_index_Tc_out = channel_c_out.get_vector_index_Tc ();

      const double J_Tc_out = channel_c_out.get_J_Tc ();

      const double J_projectile_c_out = channel_c_out.get_J_projectile ();

      const int LCM_projectile_c_out = channel_c_out.get_LCM_projectile ();

      const int two_J_Tc_out = make_int (2.0*J_Tc_out);

      const unsigned int iTc_out = target_indices(BP_Tc_out , two_J_Tc_out , vector_index_Tc_out);

      // "in" target state
      for (unsigned int ic_in = 0 ; ic_in < N_channels_JPi_A_in ; ic_in++)
	{
	  const class CC_channel_class &channel_c_in = channels_tab_JPi_A_in(ic_in);

	  const enum particle_type projectile_c_in = channel_c_in.get_projectile ();

	  const unsigned int BP_Tc_in = channel_c_in.get_BP_Tc ();

	  const unsigned int vector_index_Tc_in = channel_c_in.get_vector_index_Tc ();

	  const double J_Tc_in = channel_c_in.get_J_Tc ();

	  const double J_projectile_c_in = channel_c_in.get_J_projectile ();

	  const int LCM_projectile_c_in = channel_c_in.get_LCM_projectile ();

	  const int two_J_Tc_in = make_int (2.0*J_Tc_in);

	  const unsigned int iTc_in = target_indices(BP_Tc_in , two_J_Tc_in , vector_index_Tc_in);

	  const bool BP_targets_condition = (BP_Tc_in == BP_Tc_out);

	  const bool J_targets_condition = (make_int (J_Tc_out - J_Tc_in) == 0);
	  
	  const bool projectiles_condition = (projectile_c_in == projectile_c_out);

	  const bool LCM_projectiles_condition = (LCM_projectile_c_out == LCM_projectile_c_in);

	  const bool J_projectiles_condition = (make_int (J_projectile_c_out - J_projectile_c_in) == 0);

	  // deltas (is it the same projectile and quantum numbers are conserved)
	  if (BP_targets_condition && J_targets_condition && projectiles_condition && LCM_projectiles_condition && J_projectiles_condition)
	    {
	      // calculation of int_0^inf dr u[cf] (r) u[ci] (r)
	      // radial factor
	      const TYPE factor_radial_momentum = radial_integral_calc (CC_state_in , CC_state_out ,  ic_in ,  ic_out);

	      for (unsigned int i = 0 ; i < Nrk ; i++)
		{
		  // get <JT[f] c[f] | Op[target](r) | JT[i] c[i]>
		  const TYPE target_NBME = target_NBMEs(iTc_in , iTc_out , i);

		  // calculation of sum_{cf , ci} <J[f] c[f] | Op[target](r) | J[i] c[i]>
		  const TYPE total_NBME = target_NBME * factor_radial_momentum;
	      
		  strength_tab(i) += total_NBME;
		} //loop Nrk
	    }//deltas
	}//loop ic_in
    }//loop ic_out
}











// Calculation of nas <J[f] | Op[projectile](r) | J[i]> matrix elements from <Jp[f] | Op[projectile](r) | Jp[i]> and <JT[f] | JT[i]> (see above)
// ---------------------------------------------------------------------------------------------------------------------------------------------

void CC_scalar_strength_MEs::composite::projectile_nas_NBMEs_calc (
								   const enum operator_type Op ,
								   const int N_particle ,
								   const bool is_it_radial , 
								   const bool is_it_Gauss_Legendre ,
								   const class input_data_str &input_data_CC_Berggren , 
								   const class CC_target_projectile_composite_data &Tpc_data , 
								   const class CC_state_class &CC_state_in ,
								   const class CC_state_class &CC_state_out ,
								   const class array<class cluster_data> &cluster_projectile_data_tab , 
								   class array<TYPE> &strength_tab)
{
  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();

  const class array<class CC_channel_class> &channels_tab_JPi_A_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_JPi_A_out = CC_state_out.get_channels_tab ();

  const unsigned int N_channels_JPi_A_in  = CC_state_in.get_N_channels ();
  const unsigned int N_channels_JPi_A_out = CC_state_out.get_N_channels ();

  const int Z = input_data_CC_Berggren.get_Z ();
  const int N = input_data_CC_Berggren.get_N ();

  const unsigned int prot_index = charge_baryon_index_determine (PROTON);
  const unsigned int neut_index = charge_baryon_index_determine (NEUTRON);
  
  const class array<double> &effective_masses_for_calc_p = input_data_CC_Berggren.get_effective_masses_for_calc_p ();
  const class array<double> &effective_masses_for_calc_n = input_data_CC_Berggren.get_effective_masses_for_calc_n ();

  const double mp = effective_masses_for_calc_p(prot_index);
  const double mn = effective_masses_for_calc_n(neut_index);
  
  const double M = input_data_CC_Berggren.get_total_nucleus_mass ();
 
  const unsigned int N_bef_R_GL = CC_state_in.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state_in.get_N_bef_R_uniform ();
  
  const unsigned int Nk_momentum_GL = CC_state_in.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = CC_state_in.get_Nk_momentum_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL)     : (N_bef_R_uniform);
  const unsigned int Nk = (is_it_Gauss_Legendre) ? (Nk_momentum_GL) : (Nk_momentum_uniform);

  const unsigned int Nrk = (is_it_radial) ? (Nr) : (Nk);
  
  const int n_in = CC_state_in.get_n ();

  const int n_out = CC_state_out.get_n ();

  class array<TYPE> strength_tab_fixed_channels(Nrk);
  
  strength_tab = 0.0;

  if (Op == DENSITY)
    {
      if (n_in == n_out)
	CC_state_in.density_calc (is_it_radial , is_it_Gauss_Legendre , strength_tab);
      else
	CC_state_out.transition_density_calc (is_it_radial , is_it_Gauss_Legendre , CC_state_in , strength_tab);

      return;
    }
  
  if (!is_it_radial || ((Op != RMS_RADIUS_PROTON) && (Op != RMS_RADIUS_NEUTRON)))
    error_message_print_abort ("Rms radii strength only at this level in CC_scalar_strength_MEs::composite::projectile_nas_NBMEs_calc");
 
  for (unsigned int ic_out = 0 ; ic_out < N_channels_JPi_A_out ; ic_out++)
    {
      const class CC_channel_class &channel_c_out = channels_tab_JPi_A_out(ic_out);

      const int LCM_projectile_c_out = channel_c_out.get_LCM_projectile ();

      const unsigned int BP_Tc_out = channel_c_out.get_BP_Tc ();

      const unsigned int bp_c_out = binary_parity_from_orbital_angular_momentum (LCM_projectile_c_out);

      const unsigned int vector_index_Tc_out = channel_c_out.get_vector_index_Tc ();

      const double J_projectile_c_out = channel_c_out.get_J_projectile ();

      const double J_Tc_out = channel_c_out.get_J_Tc ();

      const enum particle_type projectile_c_out = channel_c_out.get_projectile ();

      for (unsigned int ic_in = 0 ; ic_in < N_channels_JPi_A_in ; ic_in++)
	{
	  const class CC_channel_class &channel_c_in = channels_tab_JPi_A_in(ic_in);

	  const int LCM_projectile_c_in = channel_c_in.get_LCM_projectile ();

	  const unsigned int BP_Tc_in = channel_c_in.get_BP_Tc ();

	  const unsigned int bp_c_in = binary_parity_from_orbital_angular_momentum (LCM_projectile_c_in);

	  const unsigned int vector_index_Tc_in = channel_c_in.get_vector_index_Tc ();

	  const double J_projectile_c_in = channel_c_in.get_J_projectile ();

	  const double J_Tc_in = channel_c_in.get_J_Tc ();

	  const enum particle_type projectile_c_in = channel_c_in.get_projectile ();

	  const bool BP_targets_condition = (BP_Tc_in == BP_Tc_out);

	  const bool J_targets_condition = (make_int (J_Tc_in - J_Tc_out) == 0);

	  const bool vector_index_targets_condition = (vector_index_Tc_in == vector_index_Tc_out);
	 
	  const bool projectiles_condition = (projectile_c_in == projectile_c_out);

	  const bool bp_projectiles_condition = (bp_c_in == bp_c_out);

	  const bool J_projectiles_condition = (make_int (J_projectile_c_in - J_projectile_c_out) == 0);
	  
	  // delta (if it is the same target and quantum numbers are conserved)
	  if (BP_targets_condition && J_targets_condition && vector_index_targets_condition && projectiles_condition && bp_projectiles_condition && J_projectiles_condition)
	    {
	      if (is_it_one_baryon_COSM_case)
		{
		  const unsigned int projectile_c_in_index = charge_baryon_index_determine (projectile_c_in);
	  
		  const int charge_projectile_c_in = particle_charge_determine (projectile_c_in);
	  
		  const double m = (charge_projectile_c_in != 0) ? (effective_masses_for_calc_p(projectile_c_in_index)) : (effective_masses_for_calc_n(projectile_c_in_index));
	      
		  const double rms_radius_factor = rms_radius_one_body_factor_calc (Op , projectile_c_out , m , M , N_particle);
 	      
		  one_baryon::OBMEs_calc (is_it_Gauss_Legendre , rms_radius_factor , CC_state_in , CC_state_out , ic_in , ic_out , strength_tab_fixed_channels);
		}
	      else
		{
		  const unsigned int ic  = cluster_data_index_determine (projectile_c_in  , cluster_projectile_data_tab);
		  const unsigned int icp = cluster_data_index_determine (projectile_c_out , cluster_projectile_data_tab);
	      
		  const double rms_radius_factor = rms_radius_CM_factor_calc (Op , projectile_c_out , mp , mn , M , Z , N);
 	      
		  cluster::MEs_calc (is_it_Gauss_Legendre , Tpc_data , rms_radius_factor , ic , icp , CC_state_in , CC_state_out , ic_in , ic_out , strength_tab_fixed_channels);
		}//is_it_one_baryon_COSM_case
		  
	      strength_tab += strength_tab_fixed_channels;
	    }//delta
	}//loop ic_in
    }//loop_ic_out
}







// Calculation of <JT[f] c[f] | Op[target](r) | JT[i] c[i]> matrix elements entering nas matrix elements (see above)
// -----------------------------------------------------------------------------------------------------------------

void CC_scalar_strength_MEs::composite::target_NBMEs_calc (
							   class GSM_vector &PSI_full ,
							   const enum interaction_type inter ,
							   const enum operator_type Op ,
							   const enum particle_type particle , 
							   const bool is_it_radial , 
							   const bool is_it_Gauss_Legendre ,
							   const bool full_common_vectors_used_in_file ,
							   const class CC_target_projectile_composite_data &Tpc_data , 
							   class array<class baryons_data> &prot_Y_data_one_cluster_less_tab , 
							   class array<class baryons_data> &neut_Y_data_one_cluster_less_tab , 
							   class array<TYPE> &target_NBMEs)
{
  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();

  const int n_holes_max = Tpc_data.get_n_holes_max ();
  
  const int n_scat_max = Tpc_data.get_n_scat_max ();

  const int E_relative_max_hw = Tpc_data.get_E_relative_max_hw ();

  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();
  
  const class array<unsigned int> &BP_target_tab = Tpc_data.get_BP_target_tab ();

  const class array<double> &J_target_tab = Tpc_data.get_J_target_tab ();

  const class array<unsigned int> &vector_index_target_tab = Tpc_data.get_vector_index_target_tab ();

  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();

  const class array<TYPE> &E_target_tab =  Tpc_data.get_E_target_tab ();

  const class GSM_vector_helper_class dummy_helper;

  const unsigned int Nrk = target_NBMEs.dimension (2);
 	  
  class array<TYPE> target_NBMEs_fixed_targets(Nrk);
  
  // "out" target state
  for (unsigned int iT_out = 0 ; iT_out < N_target_projectile_states ; iT_out++)
    {
      const unsigned int BP_target_out = BP_target_tab(iT_out);

      const unsigned int vector_index_target_out = vector_index_target_tab(iT_out);

      const double J_target_out = J_target_tab(iT_out);

      const double M_target_out = J_target_out;

      const TYPE E_target_out = E_target_tab(iT_out);

      const enum particle_type projectile_out = projectile_tab(iT_out);

      const int Z_projectile_out = Z_cluster_determine (projectile_out);
      const int N_projectile_out = N_cluster_determine (projectile_out);
      
      const int S_projectile_out = particle_strangeness_determine (projectile_out);
      
      const int Y_projectile_out = (S_projectile_out > 0) ? (1) : (0);

      class baryons_data &prot_Y_data_target_out = prot_Y_data_one_cluster_less_tab(Z_projectile_out , N_projectile_out , Y_projectile_out);
      class baryons_data &neut_Y_data_target_out = neut_Y_data_one_cluster_less_tab(Z_projectile_out , N_projectile_out , Y_projectile_out);

      const int n_holes_max_p_target_out = prot_Y_data_target_out.get_n_holes_max ();
      const int n_holes_max_n_target_out = neut_Y_data_target_out.get_n_holes_max ();
      
      const int n_scat_max_p_target_out = prot_Y_data_target_out.get_n_scat_max ();
      const int n_scat_max_n_target_out = neut_Y_data_target_out.get_n_scat_max ();

      const int ZYval_target_out = prot_Y_data_target_out.get_N_valence_baryons ();
      const int NYval_target_out = neut_Y_data_target_out.get_N_valence_baryons ();

      if ((ZYval_target_out == 0) && (NYval_target_out == 0)) continue;
      
      const int n_scat_max_target_out = min (n_scat_max , n_scat_max_p_target_out + n_scat_max_n_target_out);

      const int Z_target_out = prot_Y_data_target_out.get_N_nucleons ();
      const int N_target_out = neut_Y_data_target_out.get_N_nucleons ();

      const int S_target_out = prot_Y_data_target_out.get_hypernucleus_strangeness ();

      const int Ep_max_hw_target_out = prot_Y_data_target_out.get_E_max_hw ();
      const int En_max_hw_target_out = neut_Y_data_target_out.get_E_max_hw ();
      
      const int Ep_min_hw_target_out = prot_Y_data_target_out.get_E_min_hw ();
      const int En_min_hw_target_out = neut_Y_data_target_out.get_E_min_hw ();

      const int E_min_hw_target_out = Ep_min_hw_target_out + En_min_hw_target_out;

      const int E_max_hw_target_out = E_relative_max_hw + E_min_hw_target_out;

      const enum space_type space_target_out = space_determine (ZYval_target_out , NYval_target_out);

      const class correlated_state_str PSI_target_out (Z_target_out , N_target_out , BP_target_out , S_target_out , J_target_out , vector_index_target_out , E_target_out , NADA , NADA , NADA , false);
 
      class GSM_vector_helper_class V_target_out_helper (is_it_MPI_parallelized , space_target_out , inter , false , truncation_hw , truncation_ph ,
							 n_holes_max              , n_scat_max_target_out   , E_max_hw_target_out  , 
							 n_holes_max_p_target_out , n_scat_max_p_target_out , Ep_max_hw_target_out ,
							 n_holes_max_n_target_out , n_scat_max_n_target_out , En_max_hw_target_out , 
							 BP_target_out , M_target_out , true , prot_Y_data_target_out , neut_Y_data_target_out);

      class GSM_vector V_target_out (V_target_out_helper);

      if (is_it_realistic_interaction (inter))
	V_target_out.eigenvector_read_disk (true , true , PSI_target_out);
      else
	V_target_out.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_target_out);

      // "in" target state
      for (unsigned int iT_in = 0 ; iT_in < N_target_projectile_states ; iT_in++)
	{
	  const unsigned int BP_target_in = BP_target_tab(iT_in);

	  const unsigned int vector_index_target_in = vector_index_target_tab(iT_in);

	  const double J_target_in = J_target_tab(iT_in);

	  const double M_target_in = J_target_in;

	  const TYPE E_target_in = E_target_tab(iT_in);

	  const enum particle_type projectile_in = projectile_tab(iT_in);

	  const int Z_projectile_in = Z_cluster_determine (projectile_in);
	  const int N_projectile_in = N_cluster_determine (projectile_in);
      
	  const int S_projectile_in = particle_strangeness_determine (projectile_in);
      
	  const int Y_projectile_in = (S_projectile_in > 0) ? (1) : (0);

	  class baryons_data &prot_Y_data_target_in = prot_Y_data_one_cluster_less_tab(Z_projectile_in , N_projectile_in , Y_projectile_in);
	  class baryons_data &neut_Y_data_target_in = neut_Y_data_one_cluster_less_tab(Z_projectile_in , N_projectile_in , Y_projectile_in);

	  const int n_holes_max_p_target_in = prot_Y_data_target_in.get_n_holes_max ();
	  const int n_holes_max_n_target_in = neut_Y_data_target_in.get_n_holes_max ();
	  
	  const int n_scat_max_p_target_in = prot_Y_data_target_in.get_n_scat_max ();
	  const int n_scat_max_n_target_in = neut_Y_data_target_in.get_n_scat_max ();

	  const int ZYval_target_in = prot_Y_data_target_in.get_N_valence_baryons ();
	  const int NYval_target_in = neut_Y_data_target_in.get_N_valence_baryons ();

	  if ((ZYval_target_in == 0) && (NYval_target_in == 0)) continue;
	  
	  const int n_scat_max_target_in = min (n_scat_max , n_scat_max_p_target_in + n_scat_max_n_target_in);

	  const int Z_target_in = prot_Y_data_target_in.get_N_nucleons ();
	  const int N_target_in = neut_Y_data_target_in.get_N_nucleons ();

	  const int S_target_in = prot_Y_data_target_in.get_hypernucleus_strangeness ();

	  const int Ep_max_hw_target_in = prot_Y_data_target_in.get_E_max_hw ();
	  const int En_max_hw_target_in = neut_Y_data_target_in.get_E_max_hw ();
	  
	  const int Ep_min_hw_target_in = prot_Y_data_target_in.get_E_min_hw ();
	  const int En_min_hw_target_in = neut_Y_data_target_in.get_E_min_hw ();

	  const int E_min_hw_target_in = Ep_min_hw_target_in + En_min_hw_target_in;

	  const int E_max_hw_target_in = E_relative_max_hw + E_min_hw_target_in;

	  const enum space_type space_target_in = space_determine (ZYval_target_in , NYval_target_in);

	  const class correlated_state_str PSI_target_in (Z_target_in , N_target_in , BP_target_in , S_target_in , J_target_in , vector_index_target_in , E_target_in , NADA , NADA , NADA , false);

	  class GSM_vector_helper_class V_target_in_helper (is_it_MPI_parallelized , space_target_in , inter , false , truncation_hw , truncation_ph ,
							    n_holes_max             , n_scat_max_target_in   , E_max_hw_target_in  , 
							    n_holes_max_p_target_in , n_scat_max_p_target_in , Ep_max_hw_target_in ,
							    n_holes_max_n_target_in , n_scat_max_n_target_in , En_max_hw_target_in , 
							    BP_target_in , M_target_in , true , prot_Y_data_target_in , neut_Y_data_target_in);

	  // deltas (is it the same projectile)
	  if ((space_target_in == space_target_out) && (projectile_in == projectile_out))
	    {
	      class GSM_vector V_target_in (V_target_in_helper);

	      if (is_it_realistic_interaction (inter))
		V_target_in.eigenvector_read_disk (true , true , PSI_target_in);
	      else
		V_target_in.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_target_in);
	      
	      if ((BP_target_in == BP_target_out) && (make_int (J_target_in - J_target_out) == 0))
		{		
		  // calculates <JT[f] c[f] | Op[target](r) | JT[i] c[i]>
		  
		  switch (Op)
		    {
		    case DENSITY: density::calc_one_pair (is_it_radial , is_it_Gauss_Legendre , PSI_full , V_target_in , V_target_out , target_NBMEs_fixed_targets); break;
      
		    default:
		      {
			if (!is_it_rms_radius_determine (Op)) error_message_print_abort ("Density or rms radii strength only in CC_scalar_strength_MEs::composite::target_NBMEs_calc");
			
			rms_radius_one_body_strength::calc_one_strength (particle , is_it_Gauss_Legendre , PSI_full , V_target_in , V_target_out , target_NBMEs_fixed_targets);
		      } break;
		    }
		  
		  if (THIS_PROCESS == MASTER_PROCESS)
		    {
		      for (unsigned int i = 0 ; i < Nrk ; i++)
			target_NBMEs(iT_in , iT_out , i) = target_NBMEs_fixed_targets(i);
		    }
		}//deltas projectile
	    }//deltas space projectile
	}//loop iT_in
    }//loop iT_out
  
#ifdef UseMPI
  if (is_it_MPI_parallelized) target_NBMEs.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}












// Calculation of the beta transition matrix elements <J[f] | Op(r) | J[i]> for a given suboperator between two channel wave functions
// -----------------------------------------------------------------------------------------------------------------------------------
// The decomposition <J[f] | Op(r) | J[i]> = <J[f] | Op(r) | J[i]> [nas] + (<J[f] | Op(r) | J[i]> [as-HO] - <J[f] | Op(r) | J[i]> [nas-HO]) is used here (see above).

void CC_scalar_strength_MEs::composite::CC_NBMEs_calc (
						       class GSM_vector &PSI_full , 
						       const enum operator_type Op , 
						       const enum particle_type particle , 
						       const int N_particle ,
						       const bool is_it_radial , 
						       const bool is_it_Gauss_Legendre , 
						       const class CC_target_projectile_composite_data &Tpc_data , 
						       const class array<class cluster_data> &cluster_projectile_data_tab , 
						       const bool is_it_nas_only , 
						       const class CC_Hamiltonian_data &CC_H_data , 
						       const class CC_state_class &CC_state_in , 
						       const class CC_state_class &CC_state_out , 
						       class baryons_data &prot_Y_data , 
						       class baryons_data &neut_Y_data , 
						       const class input_data_str &input_data_CC_Berggren , 
						       const class array<TYPE> &target_NBMEs , 
						       class array<TYPE> &strength_tab)
{
  const unsigned int N_bef_R_GL = CC_state_in.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state_in.get_N_bef_R_uniform ();

  const unsigned int Nk_momentum_GL = CC_state_in.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = CC_state_in.get_Nk_momentum_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL)     : (N_bef_R_uniform);
  const unsigned int Nk = (is_it_Gauss_Legendre) ? (Nk_momentum_GL) : (Nk_momentum_uniform);

  const unsigned int Nrk = (is_it_radial) ? (Nr) : (Nk);
  
  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();
  
  //================================== projectile ==================================//
  // for the non antisymmetrized (nas) the CC_state_out/in are used
  // for the non antisymmetrized + HO (nas-HO) the CC_state_out/in are projected in the HO basis

  // projection of the out and in states in the HO basis

  class CC_state_class CC_state_in_HO  (CC_state_in);
  class CC_state_class CC_state_out_HO (CC_state_out);

  CC_state_in_HO.CC_HO_wfs_projection ();
  CC_state_out_HO.CC_HO_wfs_projection ();

  class array<TYPE> projectile_nas_strength_tab(Nrk);

  class array<TYPE> target_nas_strength_tab(Nrk);

  //===================================non antisymmetrized (nas)==============================================================================

  // matrix elements for the projectile
  projectile_nas_NBMEs_calc (Op , N_particle , is_it_radial , is_it_Gauss_Legendre , input_data_CC_Berggren , Tpc_data , CC_state_in , CC_state_out , cluster_projectile_data_tab , projectile_nas_strength_tab);

  // matrix elements for the target
  target_nas_NBMEs_calc (is_it_radial , is_it_Gauss_Legendre , Tpc_data , CC_state_in , CC_state_out , target_NBMEs , target_nas_strength_tab);

  // calculation of nas matrix elements <J[f] | Op(r) | J[i]> = sum_{c[f] , c[i]} ( <J[f] c[f] | Op[projectile](r) | J[i] c[i]> + <J[f] c[f] | Op[target](r) | J[i] c[i]> )

  if (is_it_nas_only)
    {
      strength_tab = projectile_nas_strength_tab + target_nas_strength_tab;

      return;
    }

  class array<TYPE> projectile_nas_HO_strength_tab(Nrk);

  class array<TYPE> target_nas_HO_strength_tab(Nrk);

  class array<TYPE> total_reduced_as_HO_strength_tab(Nrk);

  const class array<TYPE> total_reduced_nas_strength_tab = projectile_nas_strength_tab + target_nas_strength_tab;
      
  // matrix elements for the projectile in the HO basis (nas-HO)
  projectile_nas_NBMEs_calc (Op , N_particle , is_it_radial , is_it_Gauss_Legendre , input_data_CC_Berggren , Tpc_data , CC_state_in_HO , CC_state_out_HO , cluster_projectile_data_tab , projectile_nas_HO_strength_tab);

  // matrix elements for the target in the HO basis (nas-HO)
  target_nas_NBMEs_calc (is_it_radial , is_it_Gauss_Legendre , Tpc_data , CC_state_in_HO , CC_state_out_HO , target_NBMEs , target_nas_HO_strength_tab);

  // calculation of nas matrix elements <J[f] | Op(r) | J[i]> = sum_{c[f] , c[i]} ( <J[f] c[f] | Op[projectile](r) | J[i] c[i]> + <J[f] c[f] | Op[target](r) | J[i] c[i]> ) in the HO basis (nas-HO)
  const class array<TYPE> total_reduced_nas_HO_strength_tab = projectile_nas_HO_strength_tab + target_nas_HO_strength_tab;
     
  //================================== antisymmetrized and HO projection (as-HO) ===================================//
  //================================================================================================================//

  //================================== calculation of the antisymmetrized matrix element in the HO basis ==================================//

  // <Jf | Op(r) | Ji> antisymmetrized in the HO basis
  target_projectile_as_HO_NBMEs_calc (PSI_full , is_it_one_baryon_COSM_case , Op , particle , is_it_radial , is_it_Gauss_Legendre , CC_H_data , CC_state_in , CC_state_out , input_data_CC_Berggren ,
				      prot_Y_data , neut_Y_data , cluster_projectile_data_tab , total_reduced_as_HO_strength_tab);

  // final result of the decomposition of the operator matrix elements
  strength_tab = total_reduced_nas_strength_tab + (total_reduced_as_HO_strength_tab - total_reduced_nas_HO_strength_tab);
}
