#include "../CC_include/CC_include_def.h"



// TYPE is double or complex
// -------------------------




// Calculation of the matrix element <c,n[HO] | Ho | c,n'[HO]> in the HO basis from HO matrix elements for the one-baryon case
// ---------------------------------------------------------------------------------------------------------------------------
// One has Ho = H[target] + H[projectile], with H[projectile] = T[projectile] + U[basis][projectile].
// H[target] is straightforward to obtain from the Berggren basis as H[target]|PSI[T]> = E[T]|PSI[T]> therein.
// H[projectile] is treated by direct integration (see CC_H_CM_OBMEs.cpp).
// The transformation from GSM to HO one-body states is then used.
// There is no channel mixing here as U[basis][projectile] is a one-body potential.

double CC_H_MEs_one_baryon::HO_channel_decomposition_Ho_two_HO_calc (
								     const double CC_average_n_scat_target_projectile_max_c , 
								     const double CC_average_n_scat_target_projectile_max_cp , 
								     const class array<class CC_channel_class> &channels_tab , 
								     const class array<bool> &is_it_forbidden_channel_tab , 
								     const class CG_str &CGs , 
								     const class interaction_class &inter_data_basis , 
								     const class array<double> &Gaussian_table_GL , 
								     const class multipolar_expansion_str &multipolar_expansion , 
								     const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
								     const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
								     const class baryons_data &prot_Y_data_one_configuration_GSM , 
								     const class baryons_data &neut_Y_data_one_configuration_GSM , 
								     const unsigned int ic , 
								     const int nHOc , 
								     const int nHOcp , 
								     const class baryons_data &prot_Y_data , 
								     const class baryons_data &neut_Y_data , 
								     const class baryons_data &prot_Y_data_CC_Berggren , 
								     const class baryons_data &neut_Y_data_CC_Berggren) 
{
  const class CC_channel_class &channel_c = channels_tab(ic);

  const enum particle_type particle_c = channel_c.get_projectile ();

  const int particle_c_charge = particle_charge_determine (particle_c);

  const bool is_particle_c_charged = (particle_c_charge != 0);
	  
  const int lc = channel_c.get_LCM_projectile ();

  const double jc = channel_c.get_J_projectile ();

  const complex<double> E_Tc = channel_c.get_E_Tc ();

  const class baryons_data &data_tau_c_CC_Berggren = (is_particle_c_charged) ? (prot_Y_data_CC_Berggren) : (neut_Y_data_CC_Berggren);

  const class baryons_data &data_tau_c = (is_particle_c_charged) ? (prot_Y_data) : (neut_Y_data);

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_c = data_tau_c.get_is_it_valence_shell_tabs ();
      
  const class array<class lj_table<int> > &nmax_lj_c_tabs = data_tau_c.get_nmax_lj_tabs ();

  const class array<class nlj_table<unsigned int> > &shells_indices_c_tab = data_tau_c.get_shells_indices_tab ();

  const unsigned int particle_index_c = charge_baryon_index_determine (particle_c);
      
  const class lj_table<int> &nmax_lj_c_tab = nmax_lj_c_tabs(particle_index_c);
      
  const class nlj_table<unsigned int> &shells_indices_c = shells_indices_c_tab(particle_index_c);

  const class nlj_table<bool> &is_it_valence_shell_tab_c = is_it_valence_shell_tabs_c(particle_index_c);

  const class array<class nlj_struct> &shells_qn_c = data_tau_c.get_shells_quantum_numbers ();

  const int nmax_c = nmax_lj_c_tab(lc , jc);

  const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

  const double real_average_n_scat_Tc = real (average_n_scat_Tc);

  const class array<class vector_class<complex<double> > > &HO_overlaps_c = data_tau_c.get_HO_overlaps ();

  const double OBME_projectile_c_cp = CC_H_CM_OBMEs::one_baryon_CM::OBME_h_basis_calc (particle_c , lc , jc , nHOc , nHOcp , CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , 
										       prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren ,
										       prot_Y_data_one_configuration_GSM , neut_Y_data_one_configuration_GSM , neut_Y_data_CC_Berggren , data_tau_c_CC_Berggren);
  
  double ME_nHOc_Ho_nHOcp = 0.0;

  for (int nc = 0 ; nc <= nmax_c ; nc++) 
    {
      if (is_it_valence_shell_tab_c(nc , lc , jc))
	{	
	  const unsigned int shell_index_nc = shells_indices_c(nc , lc , jc);

	  const class nlj_struct &shell_qn_nc = shells_qn_c(shell_index_nc);

	  const bool S_matrix_pole_nc = shell_qn_nc.get_S_matrix_pole ();

	  const double real_average_n_scat_nc = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_tab(ic , nc) && (real_average_n_scat_nc <= CC_average_n_scat_target_projectile_max_c))
	    {
	      const class vector_class<complex<double> > &HO_overlaps_nc = HO_overlaps_c(shell_index_nc);

	      const complex<double> HO_overlap_nc_nHOc = HO_overlaps_nc(nHOc);

	      for (int ncp = 0 ; ncp <= nmax_c ; ncp++) 
		{
		  if (is_it_valence_shell_tab_c(ncp , lc , jc))
		    {
		      const unsigned int shell_index_ncp = shells_indices_c(ncp , lc , jc);

		      const class nlj_struct &shell_qn_ncp = shells_qn_c(shell_index_ncp);

		      const bool S_matrix_pole_ncp = shell_qn_ncp.get_S_matrix_pole ();

		      const double real_average_n_scat_ncp = (!S_matrix_pole_ncp) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

		      if (!is_it_forbidden_channel_tab(ic , ncp) && (real_average_n_scat_ncp <= CC_average_n_scat_target_projectile_max_cp))
			{
			  const class vector_class<complex<double> > &HO_overlaps_ncp = HO_overlaps_c(shell_index_ncp);

			  const complex<double> HO_overlap_ncp_nHOcp = HO_overlaps_ncp(nHOcp);

			  const complex<double> OBME = (nc == ncp) ? (OBME_projectile_c_cp + E_Tc) : (OBME_projectile_c_cp);
			  
			  ME_nHOc_Ho_nHOcp += real (HO_overlap_nc_nHOc * OBME * HO_overlap_ncp_nHOcp);
			}
		    }
		}
	    }
	}
    }
			  
  return ME_nHOc_Ho_nHOcp;
}







// Calculation of the matrix element <c,n[HO] | Ho | c',n'[HO]> in the HO basis Berggren energies for the one-baryon case
// ----------------------------------------------------------------------------------------------------------------------
// One has Ho = H[target] + H[projectile].
// H[target] is straightforward to obtain from the Berggren basis as H[target]|PSI[T]> = E[T]|PSI[T]> therein.
// H[projectile] is also straightforward to obtain from the Berggren basis as H[projectile]|nlj> = e|nlj> therein.
// The transformation from GSM to HO one-body states is then used.

double CC_H_MEs_one_baryon::Berggren_channel_decomposition_Ho_two_HO_calc (
									   const double CC_average_n_scat_target_projectile_max_c , 
									   const class array<class CC_channel_class> &channels_tab , 
									   const class array<bool> &is_it_forbidden_channel_CC_Berggren_tab , 
									   const unsigned int ic , 
									   const int nHOc , 
									   const int nHOcp , 
									   const class baryons_data &prot_Y_data_CC_Berggren , 
									   const class baryons_data &neut_Y_data_CC_Berggren) 
{
  const class CC_channel_class &channel_c = channels_tab(ic);

  const enum particle_type particle_c = channel_c.get_projectile ();

  const int particle_c_charge = particle_charge_determine (particle_c);

  const bool is_particle_c_charged = (particle_c_charge != 0);
	  
  const int lc = channel_c.get_LCM_projectile ();

  const double jc = channel_c.get_J_projectile ();

  const complex<double> E_Tc = channel_c.get_E_Tc ();

  const class baryons_data &data_tau_c_CC_Berggren = (is_particle_c_charged) ? (prot_Y_data_CC_Berggren) : (neut_Y_data_CC_Berggren);

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_c_CC_Berggren = data_tau_c_CC_Berggren.get_is_it_valence_shell_tabs ();

  const class array<class lj_table<int> > &nmax_lj_tab_c_CC_Berggrens = data_tau_c_CC_Berggren.get_nmax_lj_tabs ();

  const class array<class nlj_table<unsigned int> > &shells_indices_c_CC_Berggren_tab = data_tau_c_CC_Berggren.get_shells_indices_tab ();

  const class array<class nlj_struct> &shells_qn_c_CC_Berggren = data_tau_c_CC_Berggren.get_shells_quantum_numbers ();
      
  const unsigned int particle_index_c = charge_baryon_index_determine (particle_c);
      
  const class nlj_table<bool> &is_it_valence_shell_tab_c_CC_Berggren = is_it_valence_shell_tabs_c_CC_Berggren(particle_index_c);

  const class lj_table<int> &nmax_lj_tab_c_CC_Berggren = nmax_lj_tab_c_CC_Berggrens(particle_index_c);

  const class nlj_table<unsigned int> &shells_indices_c_CC_Berggren = shells_indices_c_CC_Berggren_tab(particle_index_c);

  const class array<class vector_class<complex<double> > > &HO_overlaps_c_CC_Berggren = data_tau_c_CC_Berggren.get_HO_overlaps ();

  const class array<class nlj_table<TYPE> > &h_basis_c_CC_Berggren_tab = data_tau_c_CC_Berggren.get_h_basis_tab ();
  
  const class nlj_table<TYPE> &h_basis_c_CC_Berggren = h_basis_c_CC_Berggren_tab(particle_index_c);

  const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

  const double real_average_n_scat_Tc = real (average_n_scat_Tc);

  const int nmax_c_CC_Berggren = nmax_lj_tab_c_CC_Berggren(lc , jc);

  double ME_nHOc_Ho_nHOcp = 0.0;

  for (int nc = 0 ; nc <= nmax_c_CC_Berggren ; nc++) 
    {
      if (is_it_valence_shell_tab_c_CC_Berggren(nc , lc , jc))
	{
	  const unsigned int sc = shells_indices_c_CC_Berggren(nc , lc , jc);

	  const class nlj_struct &shell_qn_c = shells_qn_c_CC_Berggren(sc);

	  const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	  const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_CC_Berggren_tab(ic , nc) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max_c))
	    {
	      const class vector_class<complex<double> > &HO_overlaps_nc = HO_overlaps_c_CC_Berggren(sc);

	      const complex<double> HO_overlap_nc_nHOc  = HO_overlaps_nc(nHOc);
	      const complex<double> HO_overlap_nc_nHOcp = HO_overlaps_nc(nHOcp);

	      const complex<double> e = h_basis_c_CC_Berggren(nc , lc , jc);

	      ME_nHOc_Ho_nHOcp += real (HO_overlap_nc_nHOc * (E_Tc + e) * HO_overlap_nc_nHOcp);
	    }
	}
    }

  return ME_nHOc_Ho_nHOcp;
}







// Calculation of the matrix element <c,n[HO] | Ho | c,n'[HO]> in the HO basis in the one-baryon case
// --------------------------------------------------------------------------------------------------
// One has Ho = H[target] + H[projectile], with H[projectile] = T[projectile] + U[basis][projectile].
// If one uses a Berggren basis expansion of channels, i.e. of target and projectile, both are treated symmetrically, i.e. one uses Ho|PSI> = (E[T] + e)|PSI> and the transformation from GSM to HO one-body states afterwards.
// If it is not the case, i.e. the HO basis is used to expand the (l,j) partial wave, the matrix element <c,n[HO] | Ho | c,n'[HO]> is recalculated directly.
// One then has : <c,n[HO] | Ho | c,n'[HO]> = E[T].<c,n[HO] | c,n'[HO]> + <n[HO] | T[projectile] + U[basis][projectile] | n'[HO]>.
// <n[HO] | T[projectile] | n'[HO]> is analytical and <n[HO] | U[basis][projectile] | n'[HO]> is provided by direct integration.

double CC_H_MEs_one_baryon::Ho_two_HO_calc (
					    const double CC_average_n_scat_target_projectile_max_c , 
					    const double CC_average_n_scat_target_projectile_max_cp , 
					    const class array<class CC_channel_class> &channels_tab , 
					    const class array<bool> &is_it_forbidden_channel_tab , 
					    const class array<bool> &is_it_forbidden_channel_CC_Berggren_tab , 
					    const class CG_str &CGs , 
					    const class interaction_class &inter_data_basis , 
					    const class array<double> &Gaussian_table_GL , 
					    const class multipolar_expansion_str &multipolar_expansion , 
					    const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
					    const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
					    const class baryons_data &prot_Y_data_one_configuration_GSM , 
					    const class baryons_data &neut_Y_data_one_configuration_GSM , 
					    const unsigned int ic , 
					    const int nHOc , 
					    const int nHOcp , 
					    const class baryons_data &prot_Y_data , 
					    const class baryons_data &neut_Y_data , 
					    const class baryons_data &prot_Y_data_CC_Berggren , 
					    const class baryons_data &neut_Y_data_CC_Berggren) 
{
  const class CC_channel_class &channel_c = channels_tab(ic);

  const bool is_it_HO_channel_decomposition_c = channel_c.get_is_it_HO_channel_decomposition ();
  
  if (is_it_HO_channel_decomposition_c)
    return HO_channel_decomposition_Ho_two_HO_calc (CC_average_n_scat_target_projectile_max_c , CC_average_n_scat_target_projectile_max_cp , channels_tab , is_it_forbidden_channel_tab , 
						    CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
						    prot_Y_data_one_configuration_GSM , neut_Y_data_one_configuration_GSM , ic , nHOc , nHOcp , prot_Y_data , neut_Y_data , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren);
  else
    return Berggren_channel_decomposition_Ho_two_HO_calc (CC_average_n_scat_target_projectile_max_c , channels_tab , is_it_forbidden_channel_CC_Berggren_tab , 
							  ic , nHOc , nHOcp , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren);
}






// Calculation of the matrix element <c,n[HO] | M | c',n'[HO]> in the HO basis in the one-baryon case
// ---------------------------------------------------------------------------------------------------
// The matrix element <c,n | M | c',n'> in the GSM basis has already been calculated using shell model formulas (M can be the Hamiltonian or overlap matrix, for example).
// The transformation from GSM to HO one-body states is then used here.

double CC_H_MEs_one_baryon::Berggren_to_HO_two_channels_two_HO_calc (
								     const double CC_average_n_scat_target_projectile_max_c , 
								     const double CC_average_n_scat_target_projectile_max_cp , 
								     const class array<class CC_channel_class> &channels_tab , 
								     const class array<bool> &is_it_forbidden_channel_tab , 
								     const unsigned int ic , 
								     const unsigned int icp , 
								     const int nHOc , 
								     const int nHOcp , 
								     const class baryons_data &prot_Y_data , 
								     const class baryons_data &neut_Y_data , 
								     const class array<unsigned int> &matrices_indices , 
								     const class matrix<complex<double> > &Berggren_matrix)
{
  const class CC_channel_class &channel_c  = channels_tab(ic);
  const class CC_channel_class &channel_cp = channels_tab(icp);

  const enum particle_type particle_c  = channel_c.get_projectile ();
  const enum particle_type particle_cp = channel_cp.get_projectile ();

  const int particle_c_charge  = particle_charge_determine (particle_c);
  const int particle_cp_charge = particle_charge_determine (particle_cp);

  const bool is_particle_c_charged  = (particle_c_charge  != 0);
  const bool is_particle_cp_charged = (particle_cp_charge != 0);
	  
  const class baryons_data &data_tau_c  = (is_particle_c_charged)  ? (prot_Y_data) : (neut_Y_data);
  const class baryons_data &data_tau_cp = (is_particle_cp_charged) ? (prot_Y_data) : (neut_Y_data);

  const class array<class lj_table<int> > &nmax_lj_tabs_c  = data_tau_c.get_nmax_lj_tabs ();      
  const class array<class lj_table<int> > &nmax_lj_tabs_cp = data_tau_cp.get_nmax_lj_tabs ();
      
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_c  = data_tau_c.get_is_it_valence_shell_tabs ();
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_cp = data_tau_cp.get_is_it_valence_shell_tabs ();

  const class array<class nlj_table<unsigned int> > &shells_indices_tab_c  = data_tau_c.get_shells_indices_tab ();
  const class array<class nlj_table<unsigned int> > &shells_indices_tab_cp = data_tau_cp.get_shells_indices_tab ();
  
  const unsigned int particle_index_c  = charge_baryon_index_determine (particle_c);
  const unsigned int particle_index_cp = charge_baryon_index_determine (particle_cp);
      
  const class lj_table<int> &nmax_lj_tab_c  = nmax_lj_tabs_c (particle_index_c);
  const class lj_table<int> &nmax_lj_tab_cp = nmax_lj_tabs_cp(particle_index_cp);
      
  const class nlj_table<unsigned int> &shells_indices_c  = shells_indices_tab_c (particle_index_c);
  const class nlj_table<unsigned int> &shells_indices_cp = shells_indices_tab_cp(particle_index_cp);

  const class nlj_table<bool> &is_it_valence_shell_tab_c  = is_it_valence_shell_tabs_c (particle_index_c);
  const class nlj_table<bool> &is_it_valence_shell_tab_cp = is_it_valence_shell_tabs_cp(particle_index_cp);

  const class array<class nlj_struct> &shells_qn_c  = data_tau_c.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_cp = data_tau_cp.get_shells_quantum_numbers ();  

  const double jc  = channel_c.get_J_projectile ();
  const double jcp = channel_cp.get_J_projectile ();

  const int lc  = channel_c.get_LCM_projectile ();
  const int lcp = channel_cp.get_LCM_projectile ();

  const int nmax_c  = nmax_lj_tab_c (lc  , jc);
  const int nmax_cp = nmax_lj_tab_cp(lcp , jcp);

  const complex<double> average_n_scat_Tc  = channel_c.get_average_n_scat_Tc ();
  const complex<double> average_n_scat_Tcp = channel_cp.get_average_n_scat_Tc ();

  const double real_average_n_scat_Tc  = real (average_n_scat_Tc);
  const double real_average_n_scat_Tcp = real (average_n_scat_Tcp);

  const class array<class vector_class<complex<double> > > &HO_overlaps_c  = data_tau_c.get_HO_overlaps ();
  const class array<class vector_class<complex<double> > > &HO_overlaps_cp = data_tau_cp.get_HO_overlaps ();

  complex<double> ME_nHOc_nHOcp_complex = 0.0;

  for (int nc = 0 ; nc <= nmax_c ; nc++) 
    {
      if (is_it_valence_shell_tab_c(nc , lc , jc))
	{
	  const unsigned int sc = shells_indices_c(nc , lc , jc);

	  const class nlj_struct &shell_qn_c = shells_qn_c(sc);

	  const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	  const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_tab(ic , nc) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max_c))
	    {
	      const unsigned int index_in = matrices_indices(ic , nc);

	      const class vector_class<complex<double> > &HO_overlaps_nc = HO_overlaps_c(sc);

	      const complex<double> HO_overlap_nc_nHOc = HO_overlaps_nc(nHOc);

	      for (int ncp = 0 ; ncp <= nmax_cp ; ncp++) 
		{
		  if (is_it_valence_shell_tab_cp(ncp , lcp , jcp))
		    {
		      const unsigned int scp = shells_indices_cp(ncp , lcp , jcp);

		      const class nlj_struct &shell_qn_cp = shells_qn_cp(scp);

		      const bool S_matrix_pole_ncp = shell_qn_cp.get_S_matrix_pole ();

		      const double real_average_n_scat_cp = (!S_matrix_pole_ncp) ? (real_average_n_scat_Tcp + 1) : (real_average_n_scat_Tcp);

		      if (!is_it_forbidden_channel_tab(icp , ncp) && (real_average_n_scat_cp <= CC_average_n_scat_target_projectile_max_cp))
			{
			  const unsigned int index_out = matrices_indices(icp , ncp);

			  const class vector_class<complex<double> > &HO_overlaps_ncp = HO_overlaps_cp(scp);

			  const complex<double> HO_overlap_ncp_nHOcp = HO_overlaps_ncp(nHOcp);

			  ME_nHOc_nHOcp_complex += HO_overlap_nc_nHOc * Berggren_matrix(index_in , index_out) * HO_overlap_ncp_nHOcp;
			}
		    }
		}
	    }
	}
    }

  const double ME_nHOc_nHOcp = real (ME_nHOc_nHOcp_complex);

  return ME_nHOc_nHOcp;
}





// Calculation of the matrix element <c,n[HO] | H - Ho | c',n'[HO]> in the HO basis in the one-baryon case
// -------------------------------------------------------------------------------------------------------
// One has Ho = H[target] + H[projectile], with H[projectile] = T[projectile] + U[basis][projectile].
// The finite range part of H is then defined as H - Ho, which is negligible in the asymptotic zone.
// Thus, H - Ho is almost exactly represented with a finite number of HO states.
//
// The matrix element <c,n | H | c',n'> in the GSM basis has already been calculated using shell model formulas.
// The transformation from GSM to HO one-body states is then used.
// The matrix element <c,n[HO | Ho | c',n'[HO> in the GSM basis is calculated with previous routines.
// The matrix element <c,n[HO] | H - Ho | c',n'[HO]> comes forward.

double CC_H_MEs_one_baryon::potential_two_channels_two_HO_calc (
								const double CC_average_n_scat_target_projectile_max_c , 
								const double CC_average_n_scat_target_projectile_max_cp , 
								const class array<class CC_channel_class> &channels_tab ,   
								const class array<bool> &is_it_forbidden_channel_tab , 
								const class array<bool> &is_it_forbidden_channel_CC_Berggren_tab , 
								const class CG_str &CGs , 
								const class interaction_class &inter_data_basis , 
								const class array<double> &Gaussian_table_GL , 
								const class multipolar_expansion_str &multipolar_expansion , 
								const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
								const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
								const class baryons_data &prot_Y_data_one_configuration_GSM , 
								const class baryons_data &neut_Y_data_one_configuration_GSM , 
								const unsigned int ic , 
								const unsigned int icp , 
								const int nHOc , 
								const int nHOcp , 
								const class baryons_data &prot_Y_data , 
								const class baryons_data &neut_Y_data , 
								const class baryons_data &prot_Y_data_CC_Berggren , 
								const class baryons_data &neut_Y_data_CC_Berggren , 
								const class array<unsigned int> &matrices_indices , 
								const class matrix<complex<double> > &H_matrix)
{
  const class CC_channel_class &channel_c = channels_tab(ic);
  const class CC_channel_class &channel_cp = channels_tab(icp);

  const enum particle_type particle_c  = channel_c.get_projectile ();
  const enum particle_type particle_cp = channel_cp.get_projectile ();

  const int particle_c_charge  = particle_charge_determine (particle_c);
  const int particle_cp_charge = particle_charge_determine (particle_cp);

  const bool is_particle_c_charged  = (particle_c_charge  != 0);
  const bool is_particle_cp_charged = (particle_cp_charge != 0);
  
  const class baryons_data &data_tau_c  = (is_particle_c_charged)  ? (prot_Y_data) : (neut_Y_data);
  const class baryons_data &data_tau_cp = (is_particle_cp_charged) ? (prot_Y_data) : (neut_Y_data);
  
  const class array<class lj_table<int> > &nmax_lj_tabs_c  = data_tau_c.get_nmax_lj_tabs ();      
  const class array<class lj_table<int> > &nmax_lj_tabs_cp = data_tau_cp.get_nmax_lj_tabs ();
      
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_c  = data_tau_c.get_is_it_valence_shell_tabs ();
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_cp = data_tau_cp.get_is_it_valence_shell_tabs ();

  const class array<class nlj_table<unsigned int> > &shells_indices_tab_c  = data_tau_c.get_shells_indices_tab ();
  const class array<class nlj_table<unsigned int> > &shells_indices_tab_cp = data_tau_cp.get_shells_indices_tab ();
  
  const unsigned int particle_index_c  = charge_baryon_index_determine (particle_c);
  const unsigned int particle_index_cp = charge_baryon_index_determine (particle_cp);
      
  const class lj_table<int> &nmax_lj_tab_c  = nmax_lj_tabs_c (particle_index_c);
  const class lj_table<int> &nmax_lj_tab_cp = nmax_lj_tabs_cp(particle_index_cp);
      
  const class nlj_table<unsigned int> &shells_indices_c  = shells_indices_tab_c (particle_index_c);
  const class nlj_table<unsigned int> &shells_indices_cp = shells_indices_tab_cp(particle_index_cp);

  const class nlj_table<bool> &is_it_valence_shell_tab_c  = is_it_valence_shell_tabs_c (particle_index_c);
  const class nlj_table<bool> &is_it_valence_shell_tab_cp = is_it_valence_shell_tabs_cp(particle_index_cp);

  const class array<class nlj_struct> &shells_qn_c  = data_tau_c.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_cp = data_tau_cp.get_shells_quantum_numbers ();  

  const double jc  = channel_c.get_J_projectile ();
  const double jcp = channel_cp.get_J_projectile ();

  const int lc  = channel_c.get_LCM_projectile ();
  const int lcp = channel_cp.get_LCM_projectile ();

  const int nmax_c  = nmax_lj_tab_c (lc  , jc);
  const int nmax_cp = nmax_lj_tab_cp(lcp , jcp);

  const complex<double> average_n_scat_Tc  = channel_c.get_average_n_scat_Tc ();
  const complex<double> average_n_scat_Tcp = channel_cp.get_average_n_scat_Tc ();

  const double real_average_n_scat_Tc  = real (average_n_scat_Tc);
  const double real_average_n_scat_Tcp = real (average_n_scat_Tcp);

  const class array<class vector_class<complex<double> > > &HO_overlaps_c  = data_tau_c.get_HO_overlaps ();
  const class array<class vector_class<complex<double> > > &HO_overlaps_cp = data_tau_cp.get_HO_overlaps ();

  double ME_nHOc_potential_nHOcp = 0.0;

  for (int nc = 0 ; nc <= nmax_c ; nc++) 
    {
      if (is_it_valence_shell_tab_c(nc , lc , jc))
	{	
	  const unsigned int sc = shells_indices_c(nc , lc , jc);
	  
	  const class nlj_struct &shell_qn_c = shells_qn_c(sc);

	  const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	  const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_tab(ic , nc) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max_c))
	    {
	      const unsigned int index_in = matrices_indices(ic , nc);

	      const class vector_class<complex<double> > &HO_overlaps_nc = HO_overlaps_c(sc);

	      const complex<double> HO_overlap_nc_nHOc = HO_overlaps_nc(nHOc);

	      for (int ncp = 0 ; ncp <= nmax_cp ; ncp++) 
		{
		  if (is_it_valence_shell_tab_cp(ncp , lcp , jcp))
		    {
		      const unsigned int scp = shells_indices_cp(ncp , lcp , jcp);
		      
		      const class nlj_struct &shell_qn_cp = shells_qn_cp(scp);

		      const bool S_matrix_pole_ncp = shell_qn_cp.get_S_matrix_pole ();

		      const double real_average_n_scat_cp = (!S_matrix_pole_ncp) ? (real_average_n_scat_Tcp + 1) : (real_average_n_scat_Tcp);

		      if (!is_it_forbidden_channel_tab(icp , ncp) && (real_average_n_scat_cp <= CC_average_n_scat_target_projectile_max_cp))
			{
			  const unsigned int index_out = matrices_indices(icp , ncp);

			  const class vector_class<complex<double> > &HO_overlaps_ncp = HO_overlaps_cp(scp);

			  const complex<double> HO_overlap_ncp_nHOcp = HO_overlaps_ncp(nHOcp);

			  ME_nHOc_potential_nHOcp += real (HO_overlap_nc_nHOc * H_matrix(index_in , index_out) * HO_overlap_ncp_nHOcp);
			}
		    }
		}
	    }
	}
    }

  if (ic == icp)
    {
      ME_nHOc_potential_nHOcp -= Ho_two_HO_calc (CC_average_n_scat_target_projectile_max_c , CC_average_n_scat_target_projectile_max_cp , channels_tab , is_it_forbidden_channel_tab , is_it_forbidden_channel_CC_Berggren_tab , 
						 CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren ,
						 prot_Y_data_one_configuration_GSM , neut_Y_data_one_configuration_GSM , ic , nHOc , nHOcp , prot_Y_data , neut_Y_data , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren);
    }

  return ME_nHOc_potential_nHOcp;
}







// Calculation of the matrix element <c,n[HO] | O - Id | c',n'[HO]> in the HO basis in the one-baryon case
// --------------------------------------------------------------------------------------------------------
// O is the matrix of overlaps.
// The finite range part of O is then defined as O - Id, which is negligible in the asymptotic zone.
// Thus, O - Id is almost exactly represented with a finite number of HO states.
//
// The matrix element <c,n | O | c',n'> in the GSM basis has already been calculated using shell model formulas.
// The transformation from GSM to HO one-body states is then used.

double CC_H_MEs_one_baryon::finite_range_overlap_matrix_two_channels_two_HO_calc (
										  const double CC_average_n_scat_target_projectile_max_c , 
										  const double CC_average_n_scat_target_projectile_max_cp , 
										  const class array<class CC_channel_class> &channels_tab , 
										  const class array<bool> &is_it_forbidden_channel_tab , 
										  const unsigned int ic , 
										  const unsigned int icp , 
										  const int nHOc , 
										  const int nHOcp , 
										  const class baryons_data &prot_Y_data , 
										  const class baryons_data &neut_Y_data , 
										  const class array<unsigned int> &matrices_indices , 
										  const class matrix<complex<double> > &overlaps_matrix) 
{
  const class CC_channel_class &channel_c  = channels_tab(ic);
  const class CC_channel_class &channel_cp = channels_tab(icp);

  const enum particle_type particle_c  = channel_c.get_projectile ();
  const enum particle_type particle_cp = channel_cp.get_projectile ();

  const int particle_c_charge  = particle_charge_determine (particle_c);
  const int particle_cp_charge = particle_charge_determine (particle_cp);

  const bool is_particle_c_charged  = (particle_c_charge  != 0);
  const bool is_particle_cp_charged = (particle_cp_charge != 0);
  
  const class baryons_data &data_tau_c  = (is_particle_c_charged)  ? (prot_Y_data) : (neut_Y_data);
  const class baryons_data &data_tau_cp = (is_particle_cp_charged) ? (prot_Y_data) : (neut_Y_data); 

  const class array<class lj_table<int> > &nmax_lj_tabs_c  = data_tau_c.get_nmax_lj_tabs ();      
  const class array<class lj_table<int> > &nmax_lj_tabs_cp = data_tau_cp.get_nmax_lj_tabs ();
      
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_c  = data_tau_c.get_is_it_valence_shell_tabs ();
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_cp = data_tau_cp.get_is_it_valence_shell_tabs ();

  const class array<class nlj_table<unsigned int> > &shells_indices_tab_c  = data_tau_c.get_shells_indices_tab ();
  const class array<class nlj_table<unsigned int> > &shells_indices_tab_cp = data_tau_cp.get_shells_indices_tab ();
  
  const unsigned int particle_index_c  = charge_baryon_index_determine (particle_c);
  const unsigned int particle_index_cp = charge_baryon_index_determine (particle_cp);
      
  const class lj_table<int> &nmax_lj_tab_c  = nmax_lj_tabs_c (particle_index_c);
  const class lj_table<int> &nmax_lj_tab_cp = nmax_lj_tabs_cp(particle_index_cp);
      
  const class nlj_table<unsigned int> &shells_indices_c  = shells_indices_tab_c (particle_index_c);
  const class nlj_table<unsigned int> &shells_indices_cp = shells_indices_tab_cp(particle_index_cp);

  const class nlj_table<bool> &is_it_valence_shell_tab_c  = is_it_valence_shell_tabs_c (particle_index_c);
  const class nlj_table<bool> &is_it_valence_shell_tab_cp = is_it_valence_shell_tabs_cp(particle_index_cp);

  const class array<class nlj_struct> &shells_qn_c  = data_tau_c.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_cp = data_tau_cp.get_shells_quantum_numbers ();  

  const double jc  = channel_c.get_J_projectile ();
  const double jcp = channel_cp.get_J_projectile ();

  const int lc  = channel_c.get_LCM_projectile ();
  const int lcp = channel_cp.get_LCM_projectile ();

  const int nmax_c  = nmax_lj_tab_c (lc  , jc);
  const int nmax_cp = nmax_lj_tab_cp(lcp , jcp);

  const complex<double> average_n_scat_Tc  = channel_c.get_average_n_scat_Tc ();
  const complex<double> average_n_scat_Tcp = channel_cp.get_average_n_scat_Tc ();
  
  const double real_average_n_scat_Tc  = real (average_n_scat_Tc);
  const double real_average_n_scat_Tcp = real (average_n_scat_Tcp);

  const class array<class vector_class<complex<double> > > &HO_overlaps_c  = data_tau_c.get_HO_overlaps ();
  const class array<class vector_class<complex<double> > > &HO_overlaps_cp = data_tau_cp.get_HO_overlaps (); 

  double ME_nHOc_overlap_nHOcp = 0.0;

  for (int nc = 0 ; nc <= nmax_c ; nc++) 
    {
      if (is_it_valence_shell_tab_c(nc , lc , jc))
	{
	  const unsigned int sc = shells_indices_c(nc , lc , jc);
	  
	  const class nlj_struct &shell_qn_c = shells_qn_c(sc);

	  const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	  const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_tab(ic , nc) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max_c))
	    {
	      const unsigned int index_in = matrices_indices(ic , nc);

	      const class vector_class<complex<double> > &HO_overlaps_nc = HO_overlaps_c(sc);

	      const complex<double> HO_overlap_nc_nHOc = HO_overlaps_nc(nHOc);

	      for (int ncp = 0 ; ncp <= nmax_cp ; ncp++) 
		{
		  if (is_it_valence_shell_tab_cp(ncp , lcp , jcp))
		    {
		      const unsigned int scp = shells_indices_cp(ncp , lcp , jcp);
		      
		      const class nlj_struct &shell_qn_cp = shells_qn_cp(scp);

		      const bool S_matrix_pole_ncp = shell_qn_cp.get_S_matrix_pole ();

		      const double real_average_n_scat_cp = (!S_matrix_pole_ncp) ? (real_average_n_scat_Tcp + 1) : (real_average_n_scat_Tcp);

		      if (!is_it_forbidden_channel_tab(icp , ncp) && (real_average_n_scat_cp <= CC_average_n_scat_target_projectile_max_cp))
			{
			  const unsigned int index_out = matrices_indices(icp , ncp);

			  const class vector_class<complex<double> > &HO_overlaps_ncp = HO_overlaps_cp(scp);

			  const complex<double> HO_overlap_ncp_nHOcp = HO_overlaps_ncp(nHOcp);

			  ME_nHOc_overlap_nHOcp += real (HO_overlap_nc_nHOc * overlaps_matrix(index_in , index_out) * HO_overlap_ncp_nHOcp);

			  if ((ic == icp) && (nc == ncp)) ME_nHOc_overlap_nHOcp -= real (HO_overlap_nc_nHOc*HO_overlap_ncp_nHOcp);
			}
		    }
		}
	    }
	}
    }

  return ME_nHOc_overlap_nHOcp;
}







// Calculation of the matrix element <c,n | H - Ho | c',n'> in the GSM-CC Berggren basis in the one-baryon case
// ------------------------------------------------------------------------------------------------------------
// One has Ho = H[target] + H[projectile], with H[projectile] = T[projectile] + U[basis][projectile].
// The finite range part of H is then defined as H - Ho, which is negligible in the asymptotic zone.
// Thus, H - Ho is almost exactly represented with a finite number of HO states.
// One can then calculate <c,n | H - Ho | c',n'> almost exactly from the transformation from HO to GSM-CC one-body states using previously calculated <c,n[HO] | H - Ho | c',n'[HO]>
//
// One does not directly calculate <c,n | H - Ho | c',n'> in the GSM-CC Berggren basis because of discretization effects, which are different in H (discretized then diagonalized) and Ho (treated exacly then discretized).

complex<double> CC_H_MEs_one_baryon::finite_range_orthogonalized_potential_two_channels_two_CC_Berggren_calc (
													      const class array<class CC_channel_class> &channels_tab , 
													      const unsigned int ic , 
													      const unsigned int icp , 
													      const unsigned int nc , 
													      const unsigned int ncp , 
													      const class baryons_data &prot_Y_data_CC_Berggren , 
													      const class baryons_data &neut_Y_data_CC_Berggren , 
													      const class array<class matrix<complex<double> > > &finite_range_orthogonalized_potential_HO_submatrices)
{
  const class CC_channel_class &channel_c  = channels_tab(ic);
  const class CC_channel_class &channel_cp = channels_tab(icp);

  const enum particle_type particle_c  = channel_c.get_projectile ();
  const enum particle_type particle_cp = channel_cp.get_projectile ();

  const int particle_c_charge  = particle_charge_determine (particle_c);
  const int particle_cp_charge = particle_charge_determine (particle_cp);

  const bool is_particle_c_charged  = (particle_c_charge  != 0);
  const bool is_particle_cp_charged = (particle_cp_charge != 0);
  
  const class baryons_data &data_tau_c_CC_Berggren  = (is_particle_c_charged)  ? (prot_Y_data_CC_Berggren) : (neut_Y_data_CC_Berggren);
  const class baryons_data &data_tau_cp_CC_Berggren = (is_particle_cp_charged) ? (prot_Y_data_CC_Berggren) : (neut_Y_data_CC_Berggren);

  const int lc  = channel_c.get_LCM_projectile ();
  const int lcp = channel_cp.get_LCM_projectile ();

  const double jc  = channel_c.get_J_projectile ();
  const double jcp = channel_cp.get_J_projectile ();

  const class array<class vector_class<complex<double> > > &HO_overlaps_Fermi_c_CC_Berggren  = data_tau_c_CC_Berggren.get_HO_overlaps_Fermi ();
  const class array<class vector_class<complex<double> > > &HO_overlaps_Fermi_cp_CC_Berggren = data_tau_cp_CC_Berggren.get_HO_overlaps_Fermi ();

  const class array<class nlj_table<unsigned int> > &shells_indices_tab_c_CC_Berggren  = data_tau_c_CC_Berggren.get_shells_indices_tab ();
  const class array<class nlj_table<unsigned int> > &shells_indices_tab_cp_CC_Berggren = data_tau_cp_CC_Berggren.get_shells_indices_tab ();

  const unsigned int particle_index_c  = charge_baryon_index_determine (particle_c);
  const unsigned int particle_index_cp = charge_baryon_index_determine (particle_cp);
	  
  const class nlj_table<unsigned int> &shells_indices_c_CC_Berggren  = shells_indices_tab_c_CC_Berggren (particle_index_c);
  const class nlj_table<unsigned int> &shells_indices_cp_CC_Berggren = shells_indices_tab_cp_CC_Berggren(particle_index_cp);

  const unsigned int sc  = shells_indices_c_CC_Berggren (nc  , lc  , jc);
  const unsigned int scp = shells_indices_cp_CC_Berggren(ncp , lcp , jcp);

  const class matrix<complex<double> > &finite_range_orthogonalized_potential_HO_submatrix_c_cp = finite_range_orthogonalized_potential_HO_submatrices(ic , icp);

  const class vector_class<complex<double> > &HO_overlaps_Fermi_nc  = HO_overlaps_Fermi_c_CC_Berggren (sc);
  const class vector_class<complex<double> > &HO_overlaps_Fermi_ncp = HO_overlaps_Fermi_cp_CC_Berggren(scp);
  
  const complex<double> ME_nc_potential_ncp = HO_overlaps_Fermi_nc * (finite_range_orthogonalized_potential_HO_submatrix_c_cp * HO_overlaps_Fermi_ncp);
  
  return ME_nc_potential_ncp;
}



