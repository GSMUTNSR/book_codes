#include "../CC_include/CC_include_def.h"

using namespace Wigner_signs;




// TYPE is double or complex
// -------------------------



// Calculation of the GSM-multipole matrix element between channel functions
// -------------------------------------------------------------------------
// One calculates <u[c[out]] | R[CM]^2L | u[c[in]]>.
//
// For u[c](r) functions solutions of GSM-CC, one uses complex scaling.
// The integral on [0:R] is calculate directly.
// The integral on [R:+oo[ is calculated with a change of variable so that one integrates on ]0:R^{-1/4}].
// u[c](r) = u[c]^+(r) + u[c]^-(r) (outgoing and incoming parts), so that four integrals are calculated on [R:+oo[ with complex scaling.
// Rotation angle is chosen for convergence to be the fastest for each u[c[in]]^{+/-}(r) u[c[out]]^{+/-}(r) product.
//
// For u[c](r) functions projected on the HO basis, radial integrals are directly calculated on [0:R] and [R:R[max]] and summed. 


// Calculation of the integral on [0:R] (see above)
// ------------------------------------------------
complex<double> CC_multipoles_MEs::radial::radial_integral_bef_R_calc (
								       const enum radial_operator_type radial_operator ,
								       const int L , 
								       const class CC_state_class &CC_state , 
								       const unsigned int ic_in , 
								       const unsigned int ic_out)
{
  //--// positions and weights
  const class array<double> &r_bef_R_tab_GL = CC_state.get_r_bef_R_tab_GL ();
  const class array<double> &w_bef_R_tab_GL = CC_state.get_w_bef_R_tab_GL ();

  //--// tables containing the wfs of all channels
  const class array<complex<double> > &CC_wf_bef_R_tab_GL = CC_state.get_CC_wf_bef_R_tab_GL ();

  //--// number of discretization points
  const unsigned int N_bef_R_GL = CC_state.get_N_bef_R_GL ();

  complex<double> radial_integral_bef_R = 0.0;

  switch (radial_operator)
    {
    case OVERLAP:
      {
	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	  {
	    const double w = w_bef_R_tab_GL(i);

	    const complex<double> CC_wf_bef_R_in_r  = CC_wf_bef_R_tab_GL (ic_in  , i);
	    const complex<double> CC_wf_bef_R_out_r = CC_wf_bef_R_tab_GL (ic_out , i);
	    
	    radial_integral_bef_R += w * CC_wf_bef_R_in_r * CC_wf_bef_R_out_r;
	  }
      } break;

    case R2L_RADIAL:
      {
	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	  {
	    const double r = r_bef_R_tab_GL(i);
	    const double w = w_bef_R_tab_GL(i);
      
	    const complex<double> CC_wf_bef_R_in_r  = CC_wf_bef_R_tab_GL (ic_in  , i);
	    const complex<double> CC_wf_bef_R_out_r = CC_wf_bef_R_tab_GL (ic_out , i);
	    
	    radial_integral_bef_R += w * CC_wf_bef_R_in_r * CC_wf_bef_R_out_r * pow (r*r , L);
	  }
      } break;

    default: error_message_print_abort ("radial operator is overlap or r^(2L) in CC_multipoles_MEs::radial::radial_integral_bef_R_calc");
    }

  return radial_integral_bef_R;
}






// Calculation of one of the four integrals on [R:+oo[, i.e. involving u[c[in]]^{+/-} and u[c[in]]^{+/-} (see above)
// -----------------------------------------------------------------------------------------------------------------
complex<double> CC_multipoles_MEs::radial::radial_integral_aft_R_part_of_four_calc (
										    const enum radial_operator_type radial_operator ,
										    const int L , 
										    const unsigned int asy_in , 
										    const unsigned int asy_out , 
										    const class CC_state_class &CC_state , 
										    const unsigned int ic_in , 
										    const unsigned int ic_out)
{
  const unsigned int N_aft_R_GL = CC_state.get_N_aft_R_GL ();

  const class array<class CC_channel_class> &channels_tab = CC_state.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab(ic_out);

  const class array<double> &um4_table = CC_state.get_um4_aft_R_tab_GL ();

  const class array<double> &w_aft_R_tab_GL = CC_state.get_w_aft_R_tab_GL ();

  const complex<double> k_projectile_in  = channel_c_in.get_k_projectile ();
  const complex<double> k_projectile_out = channel_c_out.get_k_projectile ();

  const complex<double> eta_projectile_in  = channel_c_in.get_eta_projectile ();
  const complex<double> eta_projectile_out = channel_c_out.get_eta_projectile ();

  const int omega_in  = minus_one_pow (asy_in);
  const int omega_out = minus_one_pow (asy_out);

  const complex<double> Sk_projectile = k_projectile_in*omega_in + k_projectile_out*omega_out;

  const complex<double> I_omega_in (0 , omega_in);
  const complex<double> I_omega_out(0 , omega_out);

  const unsigned int angle_index = optimal_angle_index (Sk_projectile);
  
  const complex<double> exp_Itheta(cos_theta_tab[angle_index] , sin_theta_tab[angle_index]);

  const class array<complex<double> > &CC_sc_wf_minus_in_aft_R_c_entrance_tab_GL  = CC_state.get_CC_scaled_wf_minus_aft_R_c_entrance_tab_GL ();
  const class array<complex<double> > &CC_sc_wf_minus_out_aft_R_c_entrance_tab_GL = CC_state.get_CC_scaled_wf_minus_aft_R_c_entrance_tab_GL ();
  
  const class array<complex<double> > &CC_sc_wf_plus_in_aft_R_tab_GL  = CC_state.get_CC_scaled_wf_plus_aft_R_tab_GL ();
  const class array<complex<double> > &CC_sc_wf_plus_out_aft_R_tab_GL = CC_state.get_CC_scaled_wf_plus_aft_R_tab_GL ();  

  const double R = CC_state.get_R ();

  complex<double> radial_integral_aft_R_part_of_four = 0.0;

  switch (radial_operator)
    {
    case OVERLAP:
      {
	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	  { 
	    const complex<double> z = R + (um4_table(i) - R)*exp_Itheta;

	    const complex<double> k_projectile_in_z  = k_projectile_in*z;
	    const complex<double> k_projectile_out_z = k_projectile_out*z;

	    const complex<double> log_unscale_in  = (k_projectile_in  != 0.0) ? (I_omega_in*(k_projectile_in_z   - eta_projectile_in*(M_LN2  + log (k_projectile_in_z))))  : (0.0);
	    const complex<double> log_unscale_out = (k_projectile_out != 0.0) ? (I_omega_out*(k_projectile_out_z - eta_projectile_out*(M_LN2 + log (k_projectile_out_z)))) : (0.0);
	    
	    const complex<double> unscale_weight = exp (log_unscale_in + log_unscale_out)*w_aft_R_tab_GL(i);
      
	    const complex<double> CC_sc_wf_in_z  = (asy_in == 0)  ? (CC_sc_wf_plus_in_aft_R_tab_GL(ic_in   , angle_index , i)) : (CC_sc_wf_minus_in_aft_R_c_entrance_tab_GL(angle_index  , i));
	    const complex<double> CC_sc_wf_out_z = (asy_out == 0) ? (CC_sc_wf_plus_out_aft_R_tab_GL(ic_out , angle_index , i)) : (CC_sc_wf_minus_out_aft_R_c_entrance_tab_GL(angle_index , i));
      
	    radial_integral_aft_R_part_of_four += CC_sc_wf_in_z * CC_sc_wf_out_z * unscale_weight;
	  }
      } break;

    case R2L_RADIAL:
      {
	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	  { 
	    const complex<double> z = R + (um4_table(i) - R)*exp_Itheta;

	    const complex<double> k_projectile_in_z  = k_projectile_in*z;
	    const complex<double> k_projectile_out_z = k_projectile_out*z;

	    const complex<double> log_unscale_in  = (k_projectile_in  != 0.0) ? (I_omega_in*(k_projectile_in_z   - eta_projectile_in*(M_LN2  + log (k_projectile_in_z))))  : (0.0);
	    const complex<double> log_unscale_out = (k_projectile_out != 0.0) ? (I_omega_out*(k_projectile_out_z - eta_projectile_out*(M_LN2 + log (k_projectile_out_z)))) : (0.0);
	    
	    const complex<double> unscale_weight = exp (log_unscale_in + log_unscale_out)*w_aft_R_tab_GL(i);
      
	    const complex<double> CC_sc_wf_in_z  = (asy_in == 0)  ? (CC_sc_wf_plus_in_aft_R_tab_GL(ic_in   , angle_index , i)) : (CC_sc_wf_minus_in_aft_R_c_entrance_tab_GL(angle_index  , i));
	    const complex<double> CC_sc_wf_out_z = (asy_out == 0) ? (CC_sc_wf_plus_out_aft_R_tab_GL(ic_out , angle_index , i)) : (CC_sc_wf_minus_out_aft_R_c_entrance_tab_GL(angle_index , i));
      
	    radial_integral_aft_R_part_of_four += CC_sc_wf_in_z * CC_sc_wf_out_z * pow (z*z , L) * unscale_weight;
	  }
      } break;

    default: error_message_print_abort ("radial operator is overlap or r^(2L) in CC_multipoles_MEs::radial::radial_integral_aft_R_part_of_four_calc");
    }

  radial_integral_aft_R_part_of_four *= 4.0*exp_Itheta;
  
  return radial_integral_aft_R_part_of_four;
}






// Calculation of the sum of four integrals on [R:+oo[, i.e. involving u[c[in]]^{+/-} and u[c[in]]^{+/-} (see above)
// -----------------------------------------------------------------------------------------------------------------
complex<double> CC_multipoles_MEs::radial::radial_integral_aft_R_calc (
								       const enum radial_operator_type radial_operator ,
								       const int L , 
								       const class CC_state_class &CC_state , 
								       const unsigned int ic_in , 
								       const unsigned int ic_out)
{
  const bool S_matrix_pole = CC_state.get_S_matrix_pole ();
  
  const unsigned int ic_entrance = CC_state.get_ic_entrance ();

  const bool outgoing_in_case  = (S_matrix_pole || (ic_in  != ic_entrance));
  const bool outgoing_out_case = (S_matrix_pole || (ic_out != ic_entrance));

  complex<double> integral_aft_R = 0.0;

  for (unsigned int asy_in = 0 ; (outgoing_in_case) ? (asy_in <= 0) : (asy_in <= 1) ; asy_in++)
    for (unsigned int asy_out = 0 ; (outgoing_out_case) ? (asy_out <= 0) : (asy_out <= 1) ; asy_out++)
      integral_aft_R += radial_integral_aft_R_part_of_four_calc (radial_operator , L , asy_in , asy_out , CC_state , ic_in , ic_out);

  return integral_aft_R;
}




// Calculation of the integrals on [R:R[max] of u[c](r) functions (in practice projected on the HO basis)
// ------------------------------------------------------------------------------------------------------
complex<double> CC_multipoles_MEs::radial::radial_integral_aft_R_real_calc (
									    const enum radial_operator_type radial_operator ,
									    const int L , 
									    const class CC_state_class &CC_state , 
									    const unsigned int ic_in , 
									    const unsigned int ic_out)
{
  //--// positions and weights
  const class array<double> &r_aft_R_tab_GL_real = CC_state.get_r_aft_R_tab_GL_real ();
  const class array<double> &w_aft_R_tab_GL_real = CC_state.get_w_aft_R_tab_GL_real ();

  //--// tables containing the wfs of all channels
  const class array<complex<double> > &CC_wf_aft_R_tab_GL = CC_state.get_CC_wf_aft_R_tab_GL ();

  //--// number of discretization points
  const unsigned int N_aft_R_GL = CC_state.get_N_aft_R_GL ();

  complex<double> radial_integral_aft_R = 0.0;

  switch (radial_operator)
    {
    case OVERLAP:
      {
	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	  {
	    const double w = w_aft_R_tab_GL_real(i);

	    const complex<double> CC_wf_aft_R_in_r  = CC_wf_aft_R_tab_GL (ic_in  , i) ;
	    const complex<double> CC_wf_aft_R_out_r = CC_wf_aft_R_tab_GL (ic_out , i) ;
	    
	    radial_integral_aft_R += w * CC_wf_aft_R_in_r * CC_wf_aft_R_out_r;
	  }
      } break;

    case R2L_RADIAL:
      {
	
	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	  {
	    const double r = r_aft_R_tab_GL_real(i);
	    const double w = w_aft_R_tab_GL_real(i);

	    const complex<double> CC_wf_aft_R_in_r  = CC_wf_aft_R_tab_GL (ic_in  , i) ;
	    const complex<double> CC_wf_aft_R_out_r = CC_wf_aft_R_tab_GL (ic_out , i) ;
	    
	    radial_integral_aft_R += w * CC_wf_aft_R_in_r * CC_wf_aft_R_out_r * pow (r*r , L);
	  }
      } break;

    default: error_message_print_abort ("radial operator is overlap or r^(2L) in CC_multipoles_MEs::radial::radial_integral_aft_R_part_of_four_calc");
    }
  
	
  return radial_integral_aft_R;
}




// Calculation of the radial GSM-multipole matrix element between channel functions (see above)
// --------------------------------------------------------------------------------------------
TYPE CC_multipoles_MEs::radial::radial_integral_calc (
						      const enum radial_operator_type radial_operator ,
						      const int L , 
						      const class CC_state_class &CC_state , 
						      const unsigned int ic_in , 
						      const unsigned int ic_out)
{
  const complex<double> radial_integral_bef_R = radial_integral_bef_R_calc (radial_operator , L , CC_state , ic_in , ic_out);

  const bool is_it_HO_projected = CC_state.get_is_it_HO_projected ();

  if (is_it_HO_projected)
    {
      const complex<double> radial_integral_aft_R = radial_integral_aft_R_real_calc (radial_operator , L , CC_state , ic_in , ic_out);
      
      const complex<double> radial_integral = radial_integral_bef_R + radial_integral_aft_R;
      
#ifdef TYPEisDOUBLECOMPLEX
      return radial_integral;  
#endif
      
#ifdef TYPEisDOUBLE
      return real (radial_integral);  
#endif
    }
  
  const class array<class CC_channel_class> &channels_tab = CC_state.get_channels_tab ();
  
  const class CC_channel_class &channel_c_in  = channels_tab(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab(ic_out);

  const bool S_matrix_pole = CC_state.get_S_matrix_pole ();
  
  const complex<double> k_projectile_in  = channel_c_in.get_k_projectile ();
  const complex<double> k_projectile_out = channel_c_out.get_k_projectile ();

  const unsigned int ic_entrance = CC_state.get_ic_entrance ();
  
  const bool outgoing_in_case  = (S_matrix_pole || (ic_in  != ic_entrance));
  const bool outgoing_out_case = (S_matrix_pole || (ic_out != ic_entrance));

  for (unsigned int asy_in = 0 ; (outgoing_in_case) ? (asy_in <= 0) : (asy_in <= 1) ; asy_in++)
    for (unsigned int asy_out = 0 ; (outgoing_out_case) ? (asy_out <= 0) : (asy_out <= 1) ; asy_out++)
      { 
	const complex<double> Sk_projectile = k_projectile_in*minus_one_pow (asy_in) + k_projectile_out*minus_one_pow (asy_out);
	
	if ((inf_norm (Sk_projectile) < precision) && !S_matrix_pole) error_message_print_abort ("Complex scaling impossible in CC_multipoles_MEs::radial::radial_integral_calc");
      }

  const complex<double> radial_integral_aft_R = radial_integral_aft_R_calc (radial_operator , L , CC_state , ic_in , ic_out);

  const complex<double> radial_integral = radial_integral_bef_R + radial_integral_aft_R;
      
#ifdef TYPEisDOUBLECOMPLEX
  return radial_integral;  
#endif
      
#ifdef TYPEisDOUBLE
  return real (radial_integral);  
#endif
}











