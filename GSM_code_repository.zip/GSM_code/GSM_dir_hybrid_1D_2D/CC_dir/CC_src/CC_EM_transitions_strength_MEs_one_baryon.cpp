#include "../CC_include/CC_include_def.h"

using namespace Wigner_signs;

using namespace EM_transitions_common;
using namespace CC_EM_transitions_strength_MEs::radial;

//--// return <uc_f lf jf || E_L || uc_i li ji>
void CC_EM_transitions_strength_MEs::one_baryon::electric::OBMEs_reduced_calc (
									       const int L , 
									       const bool is_it_long_wavelength_approximation , 
									       const double effective_charge , 
									       const bool is_it_Gauss_Legendre , 
									       const class CC_state_class &CC_state_in , 
									       const class CC_state_class &CC_state_out , 
									       const unsigned int ic_in , 
									       const unsigned int ic_out , 
									       class array<TYPE> &electric_OBMEs)
{
  const unsigned int BP_Op = BP_EM_determine (ELECTRIC , L);

  const unsigned int N_bef_R_GL = CC_state_out.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state_out.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
 
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();
  
  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  electric_OBMEs = 0.0;
  
  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out) != BP_Op) return;

  const enum particle_type projectile_in  = channel_c_in.get_projectile ();
  const enum particle_type projectile_out = channel_c_out.get_projectile ();
  
  const int projectile_charge_in  = particle_charge_determine (projectile_in);	
  const int projectile_charge_out = particle_charge_determine (projectile_out);
  
  if (projectile_charge_in != projectile_charge_out) return;
    
  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  const int Lmin = abs (make_int (J_projectile_in - J_projectile_out));
  const int Lmax =      make_int (J_projectile_in + J_projectile_out);

  if ((L < Lmin) || (L > Lmax)) return;
  
  //--// calculations of the radial electric charge and current

  class array<TYPE> ECH_radial_OBMEs(Nr);
  class array<TYPE> EC_radial_OBMEs(Nr);
  
  radial_OBMEs_calc (ELECTRIC_CHARGE_RADIAL  , L , is_it_long_wavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , ECH_radial_OBMEs);
  radial_OBMEs_calc (ELECTRIC_CURRENT_RADIAL , L , is_it_long_wavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , EC_radial_OBMEs);
	
  //--// here the angular part <lf jf || E_L || li ji> is taken into account

  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      const TYPE ECH_radial_OBME = ECH_radial_OBMEs(i);
      const TYPE EC_radial_OBME  = EC_radial_OBMEs(i);

      const TYPE ECH_OBME = EM_suboperator_OBME_reduced_calc (ELECTRIC_CHARGE  , L , projectile_in , projectile_out , effective_charge , NADA , ECH_radial_OBME , LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out);
      const TYPE EC_OBME  = EM_suboperator_OBME_reduced_calc (ELECTRIC_CURRENT , L , projectile_in , projectile_out , effective_charge , NADA , EC_radial_OBME  , LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out);

      const TYPE electric_OBME = ECH_OBME + EC_OBME;
    
      electric_OBMEs(i) = electric_OBME;
    }
}








//--// calculates <uc_f lf jf || M_L || uc_i li ji>
void CC_EM_transitions_strength_MEs::one_baryon::magnetic::OBMEs_reduced_calc (
									       const int L , 
									       const bool is_it_long_wavelength_approximation , 
									       const bool is_it_Gauss_Legendre , 
									       const class CC_state_class &CC_state_in , 
									       const class CC_state_class &CC_state_out , 
									       const unsigned int ic_in , 
									       const unsigned int ic_out , 
									       class array<TYPE> &magnetic_OBMEs)
{	
  const unsigned int BP_Op = BP_EM_determine (MAGNETIC , L);

  const unsigned int N_bef_R_GL = CC_state_out.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state_out.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
 
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);
 
  magnetic_OBMEs = 0.0;
  
  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();
  
  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out) != BP_Op) return;

  const enum particle_type projectile_in  = channel_c_in.get_projectile ();
  const enum particle_type projectile_out = channel_c_out.get_projectile ();

  const int projectile_charge_in  = particle_charge_determine (projectile_in);	
  const int projectile_charge_out = particle_charge_determine (projectile_out);
  
  if (projectile_charge_in != projectile_charge_out) return;
  
  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  const int Lmin = abs (make_int (J_projectile_in - J_projectile_out));
  const int Lmax =      make_int (J_projectile_in + J_projectile_out);

  if ((L < Lmin) || (L > Lmax)) return;
  
  // calculations of the radial magnetic charge and current
  
  class array<TYPE> MOLP1_radial_OBMEs(Nr);
  class array<TYPE> MOLM1_radial_OBMEs(Nr);

  class array<TYPE> MSLP1_radial_OBMEs(Nr);
  class array<TYPE> MSLM1_radial_OBMEs(Nr);

  class array<TYPE> MSSCE_radial_OBMEs(Nr);

  radial_OBMEs_calc (GRADIENT_BESSEL_YLP1                    , L , is_it_long_wavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , MOLP1_radial_OBMEs);
  radial_OBMEs_calc (GRADIENT_BESSEL_YLM1                    , L , is_it_long_wavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , MOLM1_radial_OBMEs);
  radial_OBMEs_calc (GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLP1 , L , is_it_long_wavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , MSLP1_radial_OBMEs);
  radial_OBMEs_calc (GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLM1 , L , is_it_long_wavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , MSLM1_radial_OBMEs);
  radial_OBMEs_calc (MAGNETIC_SPIN_S_SCALAR_E_RADIAL         , L , is_it_long_wavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , MSSCE_radial_OBMEs);
	
  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      const TYPE MOLP1_radial_OBME = MOLP1_radial_OBMEs(i);
      const TYPE MOLM1_radial_OBME = MOLM1_radial_OBMEs(i);

      const TYPE MSLP1_radial_OBME = MSLP1_radial_OBMEs(i);
      const TYPE MSLM1_radial_OBME = MSLM1_radial_OBMEs(i);

      const TYPE MSSCE_radial_OBME = MSSCE_radial_OBMEs(i);

      const TYPE MOLP1_OBME = EM_suboperator_OBME_reduced_calc (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_L_L , L , projectile_in , projectile_out , NADA , NADA ,
								MOLP1_radial_OBME , LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out);
      
      const TYPE MOLM1_OBME = EM_suboperator_OBME_reduced_calc (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_L_L , L , projectile_in , projectile_out , NADA , NADA ,
								MOLM1_radial_OBME , LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out);
      
      const TYPE MSLP1_OBME = EM_suboperator_OBME_reduced_calc (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLP1_TENSOR_S_L , L , projectile_in , projectile_out , NADA , NADA ,
								MSLP1_radial_OBME , LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out);
      
      const TYPE MSLM1_OBME = EM_suboperator_OBME_reduced_calc (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLM1_TENSOR_S_L , L , projectile_in , projectile_out , NADA , NADA ,
								MSLM1_radial_OBME , LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out);
      
      const TYPE MSSCE_OBME = EM_suboperator_OBME_reduced_calc (MAGNETIC_SPIN_S_SCALAR_E , L , projectile_in , projectile_out , NADA , NADA ,
								MSSCE_radial_OBME , LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out);

      const TYPE magnetic_OBME = MOLP1_OBME + MOLM1_OBME + MSLP1_OBME + MSLM1_OBME + MSSCE_OBME;

      magnetic_OBMEs(i) = magnetic_OBME;
    }
}







// return <uc_f lf jf || M/E_L || uc_i li ji>
void CC_EM_transitions_strength_MEs::one_baryon::OBMEs_reduced_calc (
								     const enum EM_type EM ,
								     const int L ,  
								     const bool is_it_long_wavelength_approximation , 
								     const double effective_charge , 
								     const bool is_it_Gauss_Legendre , 
								     const class CC_state_class &CC_state_in , 
								     const class CC_state_class &CC_state_out , 
								     const unsigned int ic_in , 
								     const unsigned int ic_out , 
								     class array<TYPE> &OBMEs)
{
  switch (EM)
    {
    case ELECTRIC: electric::OBMEs_reduced_calc (is_it_long_wavelength_approximation , L , effective_charge , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , OBMEs); break;
      
    case MAGNETIC: magnetic::OBMEs_reduced_calc (is_it_long_wavelength_approximation , L , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , OBMEs); break;
      
    default: abort_all ();
    }
}




