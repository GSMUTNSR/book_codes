#include "../CC_include/CC_include_def.h"

using namespace string_routines;
using namespace correlated_state_routines;
using namespace inputs_misc;
using namespace A_dagger_cluster_helper;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;




void CC_H_A_dagger_cluster_forbidden_channels::A_dagger_calculations_and_copy_disk (
										    const bool print_detailed_information , 
										    const double CC_average_n_scat_target_projectile_max ,
										    const bool full_common_vectors_used_in_file , 
										    const class array<class CC_channel_class> &channels_tab , 
										    const class array<class cluster_data> &cluster_projectile_data_tab , 
										    const double J , 
										    const class J2_class &J2 , 
										    class GSM_vector &Vstore , 
										    class GSM_vector &A_dagger_PSI_c_coupled) 
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "A+(projectile) |target> cluster calculation" << endl;
      cout         << "-------------------------------------------" << endl << endl;
    }
  
  const class GSM_vector_helper_class &GSM_vector_helper = A_dagger_PSI_c_coupled.get_GSM_vector_helper ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const unsigned int N_channels = channels_tab.dimension (0);

  const double M = GSM_vector_helper.get_M ();

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const complex<double> E_Tc = channel_c.get_E_Tc ();

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const int Z_Tc = channel_c.get_Z_Tc ();
      const int N_Tc = channel_c.get_N_Tc ();

      const unsigned int BP_Tc = channel_c.get_BP_Tc ();

      const unsigned int vector_index_Tc = channel_c.get_vector_index_Tc ();

      const double J_projectile_c = channel_c.get_J_projectile ();

      const double J_Tc = channel_c.get_J_Tc ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const int Z_projectile_c = channel_c.get_Z_projectile ();
      const int N_projectile_c = channel_c.get_N_projectile ();
      const int A_projectile_c = channel_c.get_A_projectile ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const unsigned int BP_projectile_c = channel_c.get_BP_projectile ();

      const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);

      const class nlj_table<bool> &cluster_CM_S_matrix_poles_c = data_c.get_cluster_CM_S_matrix_poles ();

      const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c = data_c.get_Nmax_cluster_projectile_CM_tab ();	

      const int Nmax_cluster_LCM_J_projectile_c = Nmax_cluster_projectile_CM_tab_c(LCM_projectile_c , J_projectile_c);

      const string Tc_str = "Target[c] : Z:" + make_string<int> (Z_Tc) + " N:" + make_string<int> (N_Tc) + " " + J_Pi_vector_index_string (BP_Tc , J_Tc , vector_index_Tc);

      if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl << "ic:" << ic << " channel : " << channel_c << " Nmax : " << Nmax_cluster_LCM_J_projectile_c << endl << endl;

      const class correlated_state_str PSI_projectile_qn_c(Z_projectile_c , N_projectile_c , BP_projectile_c , J_projectile_c , NADA , NADA , NADA , NADA , NADA , false);
	      
      const class correlated_state_str PSI_qn_Tc(Z_Tc , N_Tc , BP_Tc , J_Tc , vector_index_Tc , E_Tc , NADA , NADA , NADA , false);

      for (int NCM_c = 0 ; NCM_c <= Nmax_cluster_LCM_J_projectile_c ; NCM_c++) 
	{
	  const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c(NCM_c , LCM_projectile_c , J_projectile_c);

	  const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

	  if (real_average_n_scat_c < CC_average_n_scat_target_projectile_max)
	    {	
	      const double reference_time = absolute_time_determine ();

	      A_dagger_PSI_c_coupled = A_dagger_cluster_coupled_to_J (full_common_vectors_used_in_file , true , projectile_c , NCM_c , LCM_projectile_c , PSI_projectile_qn_c , false , NO_PARTICLE , NADA , NADA , PSI_qn_Tc , J , M);
	      
	      const double J_coupling_precision = J2.J_coupling_precision_calc (A_dagger_PSI_c_coupled , J , Vstore);
 
	      const double now = absolute_time_determine () , relative_time = now - reference_time; 

	      if (THIS_PROCESS == MASTER_PROCESS) 
		{
		  if (print_detailed_information || (J_coupling_precision > sqrt_precision))
		    {
		      const string space_for_two_body_cluster = (A_projectile_c == 2) ? (" ") : ("");

		      cout << "[A+(" << projectile_c << " " << NCM_c << space_for_two_body_cluster << angular_state_cluster (projectile_c , LCM_projectile_c , J_projectile_c) << ") ";
		      
		      cout << Tc_str << "]^(" << J_Pi_string (BP , J) << ") calculated , J^2 precision:" << J_coupling_precision << " time:" << relative_time << " s" << endl;
		  
		      if (J_coupling_precision > sqrt_precision) error_message_print_abort ("The composite state is not coupled to J in CC_H_A_dagger_cluster_forbidden_channels::A_dagger_calculations_and_copy_disk");
		    }
		}
	      
	      const string A_dagger_PSI_c_coupled_file_name = PSI_OUT_coupled_to_J_file_name_A_dagger_cluster_CM_relative_determine (false , "A_dagger_cluster" , projectile_c , NCM_c , LCM_projectile_c ,
																     PSI_projectile_qn_c , PSI_qn_Tc , J , M);

	      A_dagger_PSI_c_coupled.copy_disk (false , false , A_dagger_PSI_c_coupled_file_name);
	    }
	}
    }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl;
}







void CC_H_A_dagger_cluster_forbidden_channels::is_it_forbidden_channel_tab_calc (
										 const bool print_detailed_information , 
										 const double CC_average_n_scat_target_projectile_max , 
										 const double CC_forbidden_channel_precision , 	
										 const class array<class CC_channel_class> &channels_tab , 
										 const class array<class cluster_data> &cluster_projectile_data_tab , 
										 const double J , 
										 class GSM_vector &V_in , 
										 class array<bool> &is_it_forbidden_channel_tab)
{	
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Forbidden channels cluster determination" << endl;
      cout <<         "----------------------------------------" << endl << endl;
    }
  
  const class GSM_vector_helper_class &V_helper = V_in.get_GSM_vector_helper ();

  const unsigned int BP = V_helper.get_BP ();

  const unsigned int N_channels = channels_tab.dimension (0);

  const double M =  V_helper.get_M ();

  const int NCM_max_all_plus_one = is_it_forbidden_channel_tab.dimension (1);

  const double reference_time = absolute_time_determine ();

  class array<class GSM_vector> V_out_tab(NUMBER_OF_THREADS);

  for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++) V_out_tab(i_thread).allocate_fill (V_in);

  class array<complex<double> > overlaps(N_channels , NCM_max_all_plus_one , N_channels , NCM_max_all_plus_one);

  overlaps = 0.0;
  
  is_it_forbidden_channel_tab = false;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const complex<double> E_Tc = channel_c.get_E_Tc ();

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const int Z_Tc = channel_c.get_Z_Tc ();
      const int N_Tc = channel_c.get_N_Tc ();

      const unsigned int BP_Tc = channel_c.get_BP_Tc ();

      const unsigned int vector_index_Tc = channel_c.get_vector_index_Tc ();

      const double J_projectile_c = channel_c.get_J_projectile ();

      const double J_Tc = channel_c.get_J_Tc ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const int Z_projectile_c = channel_c.get_Z_projectile ();
      const int N_projectile_c = channel_c.get_N_projectile ();
      const int A_projectile_c = channel_c.get_A_projectile ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const unsigned int BP_projectile_c = channel_c.get_BP_projectile ();

      const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);

      const class nlj_table<bool> &cluster_CM_S_matrix_poles_c = data_c.get_cluster_CM_S_matrix_poles ();

      const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c = data_c.get_Nmax_cluster_projectile_CM_tab ();	

      const int Nmax_cluster_LCM_J_projectile_c = Nmax_cluster_projectile_CM_tab_c(LCM_projectile_c , J_projectile_c);

      const string Tc_str = "Target[c] : Z:" + make_string<int> (Z_Tc) + " N:" + make_string<int> (N_Tc) + " " + J_Pi_vector_index_string (BP_Tc , J_Tc , vector_index_Tc);

      if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl << "ic:" << ic << " channel : " << channel_c << " Nmax : " << Nmax_cluster_LCM_J_projectile_c << endl;
      
      const class correlated_state_str PSI_projectile_qn_c(Z_projectile_c , N_projectile_c , BP_projectile_c , J_projectile_c , NADA , NADA , NADA , NADA , NADA , false);
	      
      const class correlated_state_str PSI_qn_Tc(Z_Tc , N_Tc , BP_Tc , J_Tc , vector_index_Tc , E_Tc , NADA , NADA , NADA , false);
      
      for (int NCM_c = 0 ; NCM_c <= Nmax_cluster_LCM_J_projectile_c ; NCM_c++) 
	{	
	  const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c(NCM_c , LCM_projectile_c , J_projectile_c);

	  const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

	  if (real_average_n_scat_c < CC_average_n_scat_target_projectile_max)
	    {
	      const string A_dagger_PSI_c_coupled_file_name = PSI_OUT_coupled_to_J_file_name_A_dagger_cluster_CM_relative_determine (false , "A_dagger_cluster" , projectile_c , NCM_c , LCM_projectile_c ,
																     PSI_projectile_qn_c , PSI_qn_Tc , J , M);
	      
	      V_in.read_disk (false , false , A_dagger_PSI_c_coupled_file_name);

	      bool is_it_forbidden_channel = false;

	      const complex<double> V_in_norm = sqrt (V_in*V_in);

	      if (inf_norm (V_in_norm) < CC_forbidden_channel_precision) is_it_forbidden_channel = true;

	      is_it_forbidden_channel_tab(ic , NCM_c) = is_it_forbidden_channel;

	      if (is_it_forbidden_channel) continue;
					    
	      for (unsigned int icp = 0 ; icp <= ic ; icp++)
		{
		  const class CC_channel_class &channel_cp = channels_tab(icp);

		  const complex<double> E_Tcp = channel_cp.get_E_Tc ();

		  const complex<double> average_n_scat_Tcp = channel_cp.get_average_n_scat_Tc ();

		  const enum particle_type projectile_cp = channel_cp.get_projectile ();

		  const int Z_Tcp = channel_cp.get_Z_Tc ();
		  const int N_Tcp = channel_cp.get_N_Tc ();

		  const unsigned int BP_Tcp = channel_cp.get_BP_Tc ();

		  const unsigned int vector_index_Tcp = channel_cp.get_vector_index_Tc ();

		  const double J_projectile_cp = channel_cp.get_J_projectile ();

		  const double J_Tcp = channel_cp.get_J_Tc ();

		  const double real_average_n_scat_Tcp = real (average_n_scat_Tcp);

		  const int Z_projectile_cp = channel_cp.get_Z_projectile ();
		  const int N_projectile_cp = channel_cp.get_N_projectile ();
		  const int A_projectile_cp = channel_cp.get_A_projectile ();

		  const int LCM_projectile_cp = channel_cp.get_LCM_projectile ();

		  const unsigned int BP_projectile_cp = channel_cp.get_BP_projectile ();

		  const class cluster_data &data_cp = get_cluster_projectile_data (projectile_cp , cluster_projectile_data_tab);
		  
		  const class nlj_table<bool> &cluster_CM_S_matrix_poles_cp = data_cp.get_cluster_CM_S_matrix_poles ();

		  const class lj_table<int> &Nmax_cluster_projectile_CM_tab_cp = data_cp.get_Nmax_cluster_projectile_CM_tab ();	

		  const int NCM_max_LCM_J_projectile_cp = Nmax_cluster_projectile_CM_tab_cp(LCM_projectile_cp , J_projectile_cp);

		  const int NCM_max_LCM_J_projectile_cp_NCM_c = (icp < ic) ? (NCM_max_LCM_J_projectile_cp) : (NCM_c - 1);
		  
		  const class correlated_state_str PSI_projectile_qn_cp(Z_projectile_cp , N_projectile_cp , BP_projectile_cp , J_projectile_cp , NADA , NADA , NADA , NADA , NADA , false);
			  
		  const class correlated_state_str PSI_qn_Tcp(Z_Tcp , N_Tcp , BP_Tcp , J_Tcp , vector_index_Tcp , E_Tcp , NADA , NADA , NADA , false);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
		  for (int NCM_cp = 0 ; NCM_cp <= NCM_max_LCM_J_projectile_cp_NCM_c ; NCM_cp++) 
		    {
		      const bool S_matrix_pole_NCM_cp = cluster_CM_S_matrix_poles_cp(NCM_cp , LCM_projectile_cp , J_projectile_cp);

		      const double real_average_n_scat_cp = (!S_matrix_pole_NCM_cp) ? (real_average_n_scat_Tcp + A_projectile_cp) : (real_average_n_scat_Tcp);

		      if (real_average_n_scat_cp < CC_average_n_scat_target_projectile_max)
			{
			  const string A_dagger_PSI_cp_coupled_file_name = PSI_OUT_coupled_to_J_file_name_A_dagger_cluster_CM_relative_determine (false , "A_dagger_cluster" , projectile_cp , NCM_cp , LCM_projectile_cp ,
																		  PSI_projectile_qn_cp , PSI_qn_Tcp , J , M);

			  const unsigned int this_thread = OpenMP_thread_number_determine ();

			  class GSM_vector &V_out = V_out_tab(this_thread);

			  V_out.read_disk (false , false , A_dagger_PSI_cp_coupled_file_name);

			  overlaps(ic , NCM_c  , icp , NCM_cp) = GSM_vector_node_overlap (V_in , V_out);
			}
		    }
		}
	    }
	}
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized) overlaps.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
#endif

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const int Z_Tc = channel_c.get_Z_Tc ();
      const int N_Tc = channel_c.get_N_Tc ();
      
      const unsigned int BP_Tc = channel_c.get_BP_Tc ();

      const unsigned int vector_index_Tc = channel_c.get_vector_index_Tc ();

      const double J_projectile_c = channel_c.get_J_projectile ();

      const double J_Tc = channel_c.get_J_Tc ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);

      const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c = data_c.get_Nmax_cluster_projectile_CM_tab ();	

      const int Nmax_cluster_LCM_J_projectile_c = Nmax_cluster_projectile_CM_tab_c(LCM_projectile_c , J_projectile_c);

      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "ic:" << ic << " channel : " << channel_c << " Nmax : " << Nmax_cluster_LCM_J_projectile_c << endl;
      
      const string Tc_str = "Target[c] : Z:" + make_string<int> (Z_Tc) + " N:" + make_string<int> (N_Tc) + " " + J_Pi_vector_index_string (BP_Tc , J_Tc , vector_index_Tc);

      for (int NCM_c = 0 ; NCM_c <= Nmax_cluster_LCM_J_projectile_c ; NCM_c++) 
	{
	  if (!is_it_forbidden_channel_tab(ic , NCM_c))
	    {	
	      for (unsigned int icp = 0 ; icp <= ic ; icp++)
		{
		  const class CC_channel_class &channel_cp = channels_tab(icp);
		  
		  const enum particle_type projectile_cp = channel_cp.get_projectile ();

		  const int LCM_projectile_cp = channel_cp.get_LCM_projectile ();

		  const double J_projectile_cp = channel_cp.get_J_projectile ();

		  const class cluster_data &data_cp = get_cluster_projectile_data (projectile_cp , cluster_projectile_data_tab);

		  const class lj_table<int> &Nmax_cluster_projectile_CM_tab_cp = data_cp.get_Nmax_cluster_projectile_CM_tab ();	

		  const int NCM_max_LCM_J_projectile_cp = Nmax_cluster_projectile_CM_tab_cp(LCM_projectile_cp , J_projectile_cp);

		  const int NCM_max_LCM_J_projectile_cp_NCM_c = (icp < ic) ? (NCM_max_LCM_J_projectile_cp) : (NCM_c - 1);

		  for (int NCM_cp = 0 ; NCM_cp <= NCM_max_LCM_J_projectile_cp_NCM_c ; NCM_cp++) 
		    {
		      const complex<double> &overlap = overlaps(ic , NCM_c , icp , NCM_cp);
		  
		      if (inf_norm (overlap - 1.0) < CC_forbidden_channel_precision) is_it_forbidden_channel_tab(ic , NCM_c) = true;
		    }
		}
	    }

	  if ((THIS_PROCESS == MASTER_PROCESS) && is_it_forbidden_channel_tab(ic , NCM_c))
	    {
	      const int A_projectile_c = channel_c.get_A_projectile ();
	      
	      const string space_for_two_body_cluster = (A_projectile_c == 2) ? (" ") : ("");

	      cout << endl << "[(" << projectile_c << " " << NCM_c << space_for_two_body_cluster << angular_state_cluster (projectile_c , LCM_projectile_c , J_projectile_c) << ") ";

	      cout << Tc_str << "]^(" << J_Pi_string (BP , J) << ") forbidden" << endl << endl;
	    }
	}
    }

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      const string is_it_forbidden_channel_tab_file_name = file_name_J_Pi_string ("CC_is_it_forbidden_channel_tab" , BP , J);		

      is_it_forbidden_channel_tab.copy_disk (is_it_forbidden_channel_tab_file_name);

      if (print_detailed_information)
	{
	  const double now = absolute_time_determine () , relative_time = now - reference_time; 

	  cout << endl << "forbidden_channel channels cluster time:" << relative_time << " s" << endl << endl;
	}
    }
}













void CC_H_A_dagger_cluster_forbidden_channels::H_A_dagger_calculations_and_copy_disk (
										      const bool print_detailed_information , 
										      const double CC_average_n_scat_target_projectile_max , 
										      const class array<class CC_channel_class> &channels_tab , 
										      const class array<class cluster_data> &cluster_projectile_data_tab , 
										      const class array<bool> &is_it_forbidden_channel_tab , 
										      const double J , 
										      const class J2_class &J2 , 
										      const class H_class &H , 
										      class GSM_vector &A_dagger_PSI_c_coupled , 
										      class GSM_vector &H_A_dagger_PSI_c_coupled) 
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "H[A+(projectile) |target>] cluster calculation" << endl;
      cout         << "----------------------------------------------" << endl << endl;
    }
  
  const class GSM_vector_helper_class &GSM_vector_helper = A_dagger_PSI_c_coupled.get_GSM_vector_helper ();

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const unsigned int N_channels = channels_tab.dimension (0);

  const double M = GSM_vector_helper.get_M ();

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const complex<double> E_Tc = channel_c.get_E_Tc ();

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const int Z_Tc = channel_c.get_Z_Tc ();
      const int N_Tc = channel_c.get_N_Tc ();

      const unsigned int BP_Tc = channel_c.get_BP_Tc ();

      const unsigned int vector_index_Tc = channel_c.get_vector_index_Tc ();

      const double J_projectile_c = channel_c.get_J_projectile ();

      const double J_Tc = channel_c.get_J_Tc ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const int Z_projectile_c = channel_c.get_Z_projectile ();
      const int N_projectile_c = channel_c.get_N_projectile ();
      const int A_projectile_c = channel_c.get_A_projectile ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const unsigned int BP_projectile_c = channel_c.get_BP_projectile ();

      const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);

      const class nlj_table<bool> &cluster_CM_S_matrix_poles_c = data_c.get_cluster_CM_S_matrix_poles ();

      const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c = data_c.get_Nmax_cluster_projectile_CM_tab ();	

      const int Nmax_cluster_LCM_J_projectile_c = Nmax_cluster_projectile_CM_tab_c(LCM_projectile_c , J_projectile_c);
      
      const string Tc_str = "Target[c] : Z:" + make_string<int> (Z_Tc) + " N:" + make_string<int> (N_Tc) + " " + J_Pi_vector_index_string (BP_Tc , J_Tc , vector_index_Tc);

      if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl << "ic:" << ic << " channel : "<< channel_c << " Nmax : " << Nmax_cluster_LCM_J_projectile_c << endl << endl;

      const class correlated_state_str PSI_projectile_qn_c(Z_projectile_c , N_projectile_c , BP_projectile_c , J_projectile_c , NADA , NADA , NADA , NADA , NADA , false);
	      
      const class correlated_state_str PSI_qn_Tc(Z_Tc , N_Tc , BP_Tc , J_Tc , vector_index_Tc , E_Tc , NADA , NADA , NADA , false);

      for (int NCM_c = 0 ; NCM_c <= Nmax_cluster_LCM_J_projectile_c ; NCM_c++) 
	{	
	  const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c(NCM_c , LCM_projectile_c , J_projectile_c);

	  const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_tab(ic , NCM_c) && (real_average_n_scat_c < CC_average_n_scat_target_projectile_max))
	    {	
	      const double reference_time = absolute_time_determine ();

	      const string A_dagger_PSI_c_coupled_file_name = PSI_OUT_coupled_to_J_file_name_A_dagger_cluster_CM_relative_determine (false , "A_dagger_cluster" , projectile_c , NCM_c , LCM_projectile_c ,
																     PSI_projectile_qn_c , PSI_qn_Tc , J , M);

	      A_dagger_PSI_c_coupled.read_disk (false , false , A_dagger_PSI_c_coupled_file_name);
  
	      H_A_dagger_PSI_c_coupled = H*A_dagger_PSI_c_coupled;

	      class GSM_vector &Vstore = A_dagger_PSI_c_coupled;

	      const double J_coupling_precision = J2.J_coupling_precision_calc (H_A_dagger_PSI_c_coupled , J , Vstore);

	      const double now = absolute_time_determine () , relative_time = now - reference_time; 

	      if (THIS_PROCESS == MASTER_PROCESS) 
		{
		  if (print_detailed_information || (J_coupling_precision > sqrt_precision))
		    {
		      const string space_for_two_body_cluster = (A_projectile_c == 2) ? (" ") : ("");

		      cout << "H[A+(" << projectile_c << " " << NCM_c << space_for_two_body_cluster << angular_state_cluster (projectile_c , LCM_projectile_c , J_projectile_c) << ") ";

		      cout << Tc_str << "]^(" << J_Pi_string (BP , J) << ") calculated , J^2 precision:" << J_coupling_precision << " , time:" << relative_time << " s" << endl;
		  
		      if (J_coupling_precision > sqrt_precision) error_message_print_abort ("The composite state is not coupled to J in CC_H_A_dagger_cluster_forbidden_channels::H_A_dagger_calculations_and_copy_disk");
		    }
		}
	      
	      const string H_A_dagger_PSI_c_coupled_file_name = PSI_OUT_coupled_to_J_file_name_A_dagger_cluster_CM_relative_determine (false , "H_A_dagger_cluster" , projectile_c , NCM_c , LCM_projectile_c ,
																       PSI_projectile_qn_c , PSI_qn_Tc , J , M);
	      
	      H_A_dagger_PSI_c_coupled.copy_disk (false , false , H_A_dagger_PSI_c_coupled_file_name);
	    }
	}
    }

  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl;
}


