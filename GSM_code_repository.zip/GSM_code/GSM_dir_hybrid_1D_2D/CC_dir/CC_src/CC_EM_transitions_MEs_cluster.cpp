#include "../CC_include/CC_include_def.h"



using namespace Wigner_signs;
using namespace angular_matrix_elements;
using namespace inputs_misc;
using namespace EM_transitions_common;
using namespace EM_transitions;

using namespace CC_EM_transitions_MEs::radial;



TYPE CC_EM_transitions_MEs::cluster::EM_suboperator_intrinsic_NBME_calc (
									 const enum EM_suboperator_type EM_suboperator , 
									 const TYPE &q , 
									 const int L , 
									 const bool is_it_longwavelength_approximation , 
									 const bool is_it_HO_expansion , 
									 const class interaction_class &inter_data_basis ,  
									 const class cluster_data &data_c , 
									 const class cluster_data &data_cp , 
									 const class GSM_vector &PSI_cluster_c ,
									 const class GSM_vector &PSI_cluster_cp ,
									 class GSM_vector &PSI_full)
{
  // if true , the L_min/max are put to the L value for the total cross section
  // the interferences between different L values disappear due to the orthogonality of the Wigner D-matrices

  const double Jc  = data_c.get_J_intrinsic ();
  const double Jcp = data_cp.get_J_intrinsic ();

  if (!is_it_triangle (Jc , L , Jcp)) return 0.0;
  
  const double b_HO = inter_data_basis.get_b_lab ();
	
  const TYPE EM_suboperator_NBME = EM_suboperator_B_amplitude_calc (EM_suboperator , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data_basis , PSI_full , Jc , PSI_cluster_c , Jcp , PSI_cluster_cp);      
			      
  const TYPE j0_ME = (!is_it_longwavelength_approximation) ? (HO_wave_functions::HO_3D::j0_ME_calc (b_HO , q)) : (1.0);
  
  const TYPE hat_j0_derivative_ME = (!is_it_longwavelength_approximation) ? (HO_wave_functions::HO_3D::hat_j0_derivative_ME_calc (b_HO , q)) : (1.0);

  const TYPE q_RCM_hat_j0_ME = (!is_it_longwavelength_approximation) ? (q*HO_wave_functions::HO_3D::r_hat_j0_ME_calc (b_HO , q)) : (0.0);

  switch (EM_suboperator)
    {
    case ELECTRIC_CHARGE:
      {
	const TYPE EM_suboperator_YL = EM_suboperator_B_amplitude_calc (ELECTRIC_CHARGE_YL , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data_basis , PSI_full , Jc , PSI_cluster_c , Jcp , PSI_cluster_cp);

	const TYPE EM_suboperator_intrinsic_YL = EM_suboperator_YL/j0_ME;
      
	const TYPE EM_suboperator_NBME_intrinsic = (EM_suboperator_NBME - EM_suboperator_intrinsic_YL*(hat_j0_derivative_ME - j0_ME + 0.5*q_RCM_hat_j0_ME))/j0_ME;

	return EM_suboperator_NBME_intrinsic;
      }

    case MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLP1_TENSOR_S_L:
      {
	const TYPE EM_suboperator_magnetic_spin_gradient_Bessel = EM_suboperator_B_amplitude_calc (MAGNETIC_SPIN_GRADIENT_BESSEL_YLP1_TENSOR_S_L , q , L , is_it_longwavelength_approximation , is_it_HO_expansion ,
												   inter_data_basis , PSI_full , Jc , PSI_cluster_c , Jcp , PSI_cluster_cp);

	const TYPE EM_suboperator_intrinsic_magnetic_spin_gradient_Bessel = EM_suboperator_magnetic_spin_gradient_Bessel/j0_ME;
      
	const TYPE EM_suboperator_NBME_intrinsic = (EM_suboperator_NBME - EM_suboperator_intrinsic_magnetic_spin_gradient_Bessel*(hat_j0_derivative_ME - j0_ME))/j0_ME;
      
	return EM_suboperator_NBME_intrinsic;
      }

    case MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLM1_TENSOR_S_L:
      {
	const TYPE EM_suboperator_magnetic_spin_gradient_Bessel = EM_suboperator_B_amplitude_calc (MAGNETIC_SPIN_GRADIENT_BESSEL_YLM1_TENSOR_S_L , q , L , is_it_longwavelength_approximation , is_it_HO_expansion ,
												   inter_data_basis , PSI_full , Jc , PSI_cluster_c , Jcp , PSI_cluster_cp);

	const TYPE EM_suboperator_intrinsic_magnetic_spin_gradient_Bessel = EM_suboperator_magnetic_spin_gradient_Bessel/j0_ME;
      
	const TYPE EM_suboperator_NBME_intrinsic = (EM_suboperator_NBME - EM_suboperator_intrinsic_magnetic_spin_gradient_Bessel*(hat_j0_derivative_ME - j0_ME))/j0_ME;
      
	return EM_suboperator_NBME_intrinsic;
      }

    default:
      {
	const TYPE EM_suboperator_NBME_intrinsic = EM_suboperator_NBME/j0_ME;
      
	return EM_suboperator_NBME_intrinsic;
      }
    }
}












void CC_EM_transitions_MEs::cluster::electric::intrinsic_NBMEs_store (
								      const class CC_target_projectile_composite_data &Tpc_data , 
								      const unsigned int iE , 
								      const unsigned int iJPi_A_out , 
								      const unsigned int ic ,  
								      const unsigned int icp , 
								      const int l_intrinsic , 
								      class array<TYPE> &ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab , 
								      class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab , 
								      class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab , 
								      class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab)
{
  const unsigned int ELECTRIC_CHARGE_YL_TENSOR_E_LM1_index = EM_suboperator_type_index_determine (ELECTRIC_CHARGE_YL_TENSOR_E_LM1);
  const unsigned int ELECTRIC_CHARGE_YL_TENSOR_E_L_index   = EM_suboperator_type_index_determine (ELECTRIC_CHARGE_YL_TENSOR_E_L);
  const unsigned int ELECTRIC_CHARGE_YL_TENSOR_E_LP1_index = EM_suboperator_type_index_determine (ELECTRIC_CHARGE_YL_TENSOR_E_LP1);
  
  const unsigned int ELECTRIC_CURRENT_YL_TENSOR_S_LM1_index = EM_suboperator_type_index_determine (ELECTRIC_CURRENT_YL_TENSOR_S_LM1);
  const unsigned int ELECTRIC_CURRENT_YL_TENSOR_S_L_index   = EM_suboperator_type_index_determine (ELECTRIC_CURRENT_YL_TENSOR_S_L);
  const unsigned int ELECTRIC_CURRENT_YL_TENSOR_S_LP1_index = EM_suboperator_type_index_determine (ELECTRIC_CURRENT_YL_TENSOR_S_LP1);

  const unsigned int ELECTRIC_CURRENT_YL_TENSOR_R_S_LM1_index = EM_suboperator_type_index_determine (ELECTRIC_CURRENT_YL_TENSOR_R_S_LM1);
  const unsigned int ELECTRIC_CURRENT_YL_TENSOR_R_S_L_index   = EM_suboperator_type_index_determine (ELECTRIC_CURRENT_YL_TENSOR_R_S_L);
  const unsigned int ELECTRIC_CURRENT_YL_TENSOR_R_S_LP1_index = EM_suboperator_type_index_determine (ELECTRIC_CURRENT_YL_TENSOR_R_S_LP1);

  const unsigned int ELECTRIC_CURRENT_YL_TENSOR_P_S_LM1_index = EM_suboperator_type_index_determine (ELECTRIC_CURRENT_YL_TENSOR_P_S_LM1);
  const unsigned int ELECTRIC_CURRENT_YL_TENSOR_P_S_L_index   = EM_suboperator_type_index_determine (ELECTRIC_CURRENT_YL_TENSOR_P_S_L);
  const unsigned int ELECTRIC_CURRENT_YL_TENSOR_P_S_LP1_index = EM_suboperator_type_index_determine (ELECTRIC_CURRENT_YL_TENSOR_P_S_LP1);
  
  const class array<TYPE> &EM_suboperator_intrinsic_NBMEs = Tpc_data.get_EM_suboperator_intrinsic_NBMEs ();
  
  const TYPE ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_LM1 = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ELECTRIC_CHARGE_YL_TENSOR_E_LM1_index);
  const TYPE ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_L   = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ELECTRIC_CHARGE_YL_TENSOR_E_L_index);
  const TYPE ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_LP1 = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ELECTRIC_CHARGE_YL_TENSOR_E_LP1_index);
	  
  const TYPE EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_LM1 = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ELECTRIC_CURRENT_YL_TENSOR_S_LM1_index);
  const TYPE EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_L   = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ELECTRIC_CURRENT_YL_TENSOR_S_L_index);
  const TYPE EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_LP1 = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ELECTRIC_CURRENT_YL_TENSOR_S_LP1_index);
  
  const TYPE EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_LM1 = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ELECTRIC_CURRENT_YL_TENSOR_R_S_LM1_index);
  const TYPE EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_L   = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ELECTRIC_CURRENT_YL_TENSOR_R_S_L_index);
  const TYPE EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_LP1 = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ELECTRIC_CURRENT_YL_TENSOR_R_S_LP1_index);
  
  const TYPE EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_LM1 = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ELECTRIC_CURRENT_YL_TENSOR_P_S_LM1_index);
  const TYPE EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_L   = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ELECTRIC_CURRENT_YL_TENSOR_P_S_L_index);
  const TYPE EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_LP1 = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ELECTRIC_CURRENT_YL_TENSOR_P_S_LP1_index);
        
  if (l_intrinsic == 0)
    {	  
      ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab(0) = ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_LP1;
      
      EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab(0) = EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_LP1;
      
      EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab(0) = EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_LP1;
      
      EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab(0) = EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_LP1;
    }
  else
    {
      ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab(0) = ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_LM1;
      ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab(1) = ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_L;
      ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab(2) = ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_LP1;
      
      EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab(0) = EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_LM1;
      EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab(1) = EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_L;
      EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab(2) = EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_LP1;
      
      EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab(0) = EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_LM1;
      EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab(1) = EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_L;
      EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab(2) = EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_LP1;
      
      EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab(0) = EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_LM1;
      EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab(1) = EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_L;
      EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab(2) = EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_LP1;
    }
}









TYPE CC_EM_transitions_MEs::cluster::electric::charge_ME_reduced_part_calc (
									    const bool is_it_longwavelength_approximation , 
									    const int l_intrinsic , 
									    const int LCM , 
									    const int L , 
									    const class CC_state_class &CC_state_in , 
									    const class CC_state_class &CC_state_out , 
									    const unsigned int ic_in , 
									    const unsigned int ic_out , 
									    const TYPE &ECH_all_intrinsic_NBME , 
									    const TYPE &ECH_intrinsic_NBME_jl_Yl , 
									    const TYPE &ECH_intrinsic_NBME_hat_jl_over_r_Yl ,
									    const class array<TYPE> &ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab)
{	
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();
  
  //--// calculations of the radial electric charge and current
  const TYPE ECH_CM_radial_ME_jl           = radial_integral_calc (BESSEL                    , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE ECH_CM_radial_ME_hat_jl       = radial_integral_calc (RICCATI_BESSEL            , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE ECH_CM_radial_ME_hat_jl_r     = radial_integral_calc (RICCATI_BESSEL_R          , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE ECH_CM_radial_ME_hat_jl_der   = radial_integral_calc (RICCATI_BESSEL_DERIVATIVE , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);

  const double Y_LCM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);
  
  const TYPE ECH_CM_ME_jl_Yl         = ECH_CM_radial_ME_jl        *Y_LCM_ME;
  const TYPE ECH_CM_ME_hat_jl_r_Yl   = ECH_CM_radial_ME_hat_jl_r  *Y_LCM_ME;
  const TYPE ECH_CM_ME_hat_jl_der_Yl = ECH_CM_radial_ME_hat_jl_der*Y_LCM_ME;

  const int LCM_p_min = abs (LCM - 1);
  const int LCM_p_max =      LCM + 1;

  const unsigned int LCM_p_number = make_uns_int (LCM_p_max - LCM_p_min) + 1;

  class array<TYPE> Yl_tensor_e_CM_OBMEs(LCM_p_number);

  for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
    {
      const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

      Yl_tensor_e_CM_OBMEs(i_LCM_p) = OBME_YL_tensor_e_reduced_in_l (LCM , LCM_p , LCM_projectile_in , LCM_projectile_out);
    }

  const class array<TYPE> ECH_CM_hat_jl_Yl_tensor_e_CM_OBMEs = ECH_CM_radial_ME_hat_jl*Yl_tensor_e_CM_OBMEs;

  const TYPE ECH_ME_jl_Yl_CM_all_Yl_intrinsic = Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
									      LCM_projectile_in  , J_intrinsic_in  , J_projectile_in  , 
									      LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
									      ECH_CM_ME_jl_Yl , ECH_all_intrinsic_NBME);

  const TYPE ECH_ME_hat_jl_der_Yl_CM_jl_Yl_intrinsic = Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
										     LCM_projectile_in  , J_intrinsic_in  , J_projectile_in  , 
										     LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
										     ECH_CM_ME_hat_jl_der_Yl , ECH_intrinsic_NBME_jl_Yl);

  const TYPE ECH_ME_jl_Yl_CM_jl_Yl_intrinsic = Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
									     LCM_projectile_in  , J_intrinsic_in  , J_projectile_in  , 
									     LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
									     ECH_CM_ME_jl_Yl , ECH_intrinsic_NBME_jl_Yl);
  
  const TYPE ECH_ME_hat_jl_r_Yl_CM_hat_jl_over_r_Yl_intrinsic = Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
											      LCM_projectile_in  , J_intrinsic_in  , J_projectile_in  , 
											      LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
											      ECH_CM_ME_hat_jl_r_Yl , ECH_intrinsic_NBME_hat_jl_over_r_Yl);

  const TYPE ECH_ME_hat_jl_Yl_e_CM_hat_jl_Yl_e_intrinsic = O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (LCM , l_intrinsic , L , 1 ,
													    LCM_projectile_in  , J_intrinsic_in  , J_projectile_in  , 
													    LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
													    ECH_CM_hat_jl_Yl_tensor_e_CM_OBMEs , ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab);
    
  const TYPE ECH_MEs_sum = ECH_ME_jl_Yl_CM_all_Yl_intrinsic + ECH_ME_hat_jl_der_Yl_CM_jl_Yl_intrinsic - ECH_ME_jl_Yl_CM_jl_Yl_intrinsic + 0.5*ECH_ME_hat_jl_r_Yl_CM_hat_jl_over_r_Yl_intrinsic + ECH_ME_hat_jl_Yl_e_CM_hat_jl_Yl_e_intrinsic;

  return ECH_MEs_sum;
}









TYPE CC_EM_transitions_MEs::cluster::electric::current_ME_reduced_part_calc (
									     const bool is_it_longwavelength_approximation , 
									     const int l_intrinsic , 
									     const int LCM , 
									     const int L , 
									     const class CC_state_class &CC_state_in , 
									     const class CC_state_class &CC_state_out , 
									     const unsigned int ic_in , 
									     const unsigned int ic_out , 
									     const TYPE &EC_all_intrinsic_NBME , 
									     const class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab , 
									     const class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab , 
									     const class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab)
{	
  if (is_it_longwavelength_approximation) return 0.0;
  
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  const int A_projectile = channel_c_in.get_A_projectile  ();
  
  //--// calculations of the radial electric charge and current
  
  const TYPE EC_CM_radial_ME_jl        = radial_integral_calc (BESSEL        , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE EC_CM_radial_ME_jl_r      = radial_integral_calc (BESSEL_R      , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE EC_CM_radial_ME_jl_over_r = radial_integral_calc (BESSEL_OVER_R , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);    
  const TYPE EC_CM_radial_ME_jl_r_der  = radial_integral_calc (BESSEL_DR     , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);

  const double Y_LCM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);
  
  const TYPE EC_CM_ME_jl_Yl = Y_LCM_ME*EC_CM_radial_ME_jl;

  const int LCM_p_min = abs (LCM - 1);
  const int LCM_p_max =      LCM + 1;

  const unsigned int LCM_p_number = make_uns_int (LCM_p_max - LCM_p_min) + 1;

  class array<TYPE> Yl_tensor_l_CM_ME_tab(LCM_p_number);
  class array<TYPE> Yl_tensor_e_CM_OBMEs(LCM_p_number);

  for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
    {
      const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

      Yl_tensor_l_CM_ME_tab(i_LCM_p) = OBME_YL_tensor_l_reduced_in_l (LCM , LCM_p , LCM_projectile_in , LCM_projectile_out);
      Yl_tensor_e_CM_OBMEs (i_LCM_p) = OBME_YL_tensor_e_reduced_in_l (LCM , LCM_p , LCM_projectile_in , LCM_projectile_out);
    }
  
  const class array<TYPE> EC_CM_jl_Yl_tensor_l_ME_tab = EC_CM_radial_ME_jl*Yl_tensor_l_CM_ME_tab;
  
  const class array<TYPE> EC_CM_jl_Yl_tensor_r_ME_tab = EC_CM_radial_ME_jl_r*Yl_tensor_e_CM_OBMEs;

  class array<TYPE> EC_CM_jl_Yl_tensor_p_ME_tab = EC_CM_radial_ME_jl_r_der*Yl_tensor_e_CM_OBMEs;

  for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
    {
      const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

      double EC_CM_jl_Yl_tensor_p_angular_part_ME = 0.0;
	
      for (int LCM_projectile_inter = (LCM_projectile_in == 0) ? (LCM_projectile_in + 1) : (LCM_projectile_in - 1) ; LCM_projectile_inter <= LCM_projectile_in + 1 ; LCM_projectile_inter += 2)
	{
	  const double YLCM_reduced = OBME_YL_reduced_in_l (LCM , LCM_projectile_inter , LCM_projectile_out);
	  
	  const double e_reduced = OBME_e_reduced_in_l (LCM_projectile_in , LCM_projectile_inter);
      
	  const double l_factor = 0.5*(LCM_projectile_in*(LCM_projectile_in + 1.0) - LCM_projectile_inter*(LCM_projectile_inter + 1.0));
      
	  const double Wig_6j = Wigner_6j (LCM , 1 , LCM_p , LCM_projectile_in , LCM_projectile_out , LCM_projectile_inter);
      
	  EC_CM_jl_Yl_tensor_p_angular_part_ME += YLCM_reduced*e_reduced*Wig_6j*l_factor;
	}

      EC_CM_jl_Yl_tensor_p_angular_part_ME *= minus_one_pow (LCM_projectile_in + LCM_p + LCM_projectile_out)*hat (LCM_p);
  
      EC_CM_jl_Yl_tensor_p_ME_tab(i_LCM_p) += EC_CM_jl_Yl_tensor_p_angular_part_ME*EC_CM_radial_ME_jl_over_r;
    }
  
  const TYPE EC_ME_jl_Yl_CM_all_intrinsic = Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
									  LCM_projectile_in  , J_intrinsic_in  , J_projectile_in , 
									  LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
									  EC_CM_ME_jl_Yl , EC_all_intrinsic_NBME);

  const TYPE EC_ME_jl_Yl_l_CM_hat_jl_over_r_Yl_s_intrinsic = O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (LCM , l_intrinsic , L , 1 ,
													      LCM_projectile_in  , J_intrinsic_in  , J_projectile_in , 
													      LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
													      EC_CM_jl_Yl_tensor_l_ME_tab , EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab);
  
  const TYPE EC_ME_jl_Yl_p_CM_hat_jl_over_r_Yl_r_s_intrinsic = O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (LCM , l_intrinsic , L , 1 ,
														LCM_projectile_in  , J_intrinsic_in  , J_projectile_in , 
														LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
														EC_CM_jl_Yl_tensor_p_ME_tab , EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab);
  
  const TYPE EC_ME_jl_Yl_r_CM_hat_jl_over_r_Yl_p_s_intrinsic = O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (LCM , l_intrinsic , L , 1 ,
														LCM_projectile_in  , J_intrinsic_in  , J_projectile_in , 
														LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
														EC_CM_jl_Yl_tensor_r_ME_tab , EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab);


  const TYPE EC_MEs_sum = EC_ME_jl_Yl_CM_all_intrinsic + EC_ME_jl_Yl_l_CM_hat_jl_over_r_Yl_s_intrinsic/A_projectile + M_SQRT2*(EC_ME_jl_Yl_p_CM_hat_jl_over_r_Yl_r_s_intrinsic/A_projectile - EC_ME_jl_Yl_r_CM_hat_jl_over_r_Yl_p_s_intrinsic);

  return EC_MEs_sum;
}







//--// return <uc_f lf jf || E_L || uc_i li ji>
TYPE CC_EM_transitions_MEs::cluster::electric::ME_reduced_calc (
								const int L , 
								const bool is_it_longwavelength_approximation ,
								const class CC_target_projectile_composite_data &Tpc_data , 
								const class array<class cluster_data> &cluster_projectile_data_tab , 
								const unsigned int iE , 
								const unsigned int iJPi_A_out , 
								const unsigned int ic ,  
								const unsigned int icp , 
								const class CC_state_class &CC_state_in , 
								const class CC_state_class &CC_state_out , 
								const unsigned int ic_in , 
								const unsigned int ic_out)
{
  const unsigned int BP_Op = BP_EM_determine (ELECTRIC , L);

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out) == BP_Op)
    {
      const complex<double> E_in_complex  = CC_state_in.get_E ();
      const complex<double> E_out_complex = CC_state_out.get_E ();
  
      const TYPE E_in  = generate_scalar<TYPE> (real (E_in_complex)  , imag (E_in_complex));
      const TYPE E_out = generate_scalar<TYPE> (real (E_out_complex) , imag (E_out_complex));
  
      const TYPE q = (E_in - E_out)/hbar_c;	    
	  
      const unsigned int ELECTRIC_CHARGE_YL_index = EM_suboperator_type_index_determine (ELECTRIC_CHARGE_YL);
      const unsigned int ELECTRIC_CHARGE_index    = EM_suboperator_type_index_determine (ELECTRIC_CHARGE);
      const unsigned int ELECTRIC_CURRENT_index   = EM_suboperator_type_index_determine (ELECTRIC_CURRENT);

      const class cluster_data &data_c  = cluster_projectile_data_tab(ic);
      const class cluster_data &data_cp = cluster_projectile_data_tab(icp);

      const double J_intrinsic_in  = data_c.get_J_intrinsic ();
      const double J_intrinsic_out = data_cp.get_J_intrinsic ();

      const int l_intrinsic_min = abs (make_int (J_intrinsic_in - J_intrinsic_out));
      const int l_intrinsic_max =      make_int (J_intrinsic_in + J_intrinsic_out);

      const class array<TYPE> &EM_suboperator_intrinsic_NBMEs = Tpc_data.get_EM_suboperator_intrinsic_NBMEs ();

      TYPE electric_ME = 0.0;
      
      for (int l_intrinsic = l_intrinsic_min ; l_intrinsic <= l_intrinsic_max ; l_intrinsic++)
	{
	  const TYPE ECH_intrinsic_NBME_jl_Yl = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ELECTRIC_CHARGE_YL_index);
	  
	  const TYPE ECH_all_intrinsic_NBME = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ELECTRIC_CHARGE_index);
	  
	  const TYPE EC_all_intrinsic_NBME = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ELECTRIC_CURRENT_index);

	  const TYPE ECH_intrinsic_NBME_hat_jl_over_r_Yl = (!is_it_longwavelength_approximation) ? (q*ECH_intrinsic_NBME_jl_Yl) : (0.0);
	  
	  const int lp_intrinsic_min = abs (l_intrinsic - 1);
	  const int lp_intrinsic_max =      l_intrinsic + 1;
	  
	  const unsigned int lp_intrinsic_number = make_uns_int (lp_intrinsic_max - lp_intrinsic_min) + 1;
	  
	  class array<TYPE> ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab(lp_intrinsic_number);

	  class array<TYPE> EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab  (lp_intrinsic_number);
	  class array<TYPE> EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab(lp_intrinsic_number);
	  class array<TYPE> EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab(lp_intrinsic_number);

	  electric::intrinsic_NBMEs_store (Tpc_data , iE , iJPi_A_out , ic , icp , l_intrinsic ,
					   ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab ,
					   EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab ,
					   EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab ,
					   EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab);
         
	  const int LCM_min_in_out = abs (LCM_projectile_in - LCM_projectile_out);	  
	  const int LCM_max_in_out =      LCM_projectile_in + LCM_projectile_out;

	  const int LCM_min_l_intrinsic_L = abs (L - l_intrinsic);	  
	  const int LCM_max_l_intrinsic_L =      L + l_intrinsic;

	  const int LCM_min_L = max (LCM_min_in_out , LCM_min_l_intrinsic_L);
	  const int LCM_max_L = min (LCM_max_in_out , LCM_max_l_intrinsic_L);

	  for (int LCM = LCM_min_L ; LCM <= LCM_max_L ; LCM++)
	    {
	      if ((l_intrinsic + LCM + L)%2 == 1) continue;

	      if (is_it_longwavelength_approximation && (l_intrinsic + LCM != L)) continue;
	      
	      const double coupling_term = coupling_term_l_intrinsic_LCM (l_intrinsic , LCM , L);
		  
	      const TYPE pow_q_l_intrinsic_plus_LCM_minus_L = (!is_it_longwavelength_approximation) ? (pow (q , l_intrinsic + LCM - L)) : (1.0);
	      
	      const TYPE factor = pow_q_l_intrinsic_plus_LCM_minus_L*(l_intrinsic + 1.0)*(LCM + 1.0)*double_factorial (2*L + 1)/((L + 1.0)*double_factorial (2*l_intrinsic + 1)*double_factorial (2*LCM + 1));
      		  
	      const TYPE ECH_ME_reduced_part = electric::charge_ME_reduced_part_calc (is_it_longwavelength_approximation , l_intrinsic , LCM , L ,
										      CC_state_in , CC_state_out , ic_in , ic_out , 
										      ECH_all_intrinsic_NBME ,
										      ECH_intrinsic_NBME_jl_Yl ,
										      ECH_intrinsic_NBME_hat_jl_over_r_Yl ,
										      ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab);
	      
	      const TYPE EC_ME_reduced_part = electric::current_ME_reduced_part_calc (is_it_longwavelength_approximation , l_intrinsic , LCM , L ,
										      CC_state_in , CC_state_out , ic_in , ic_out , 
										      EC_all_intrinsic_NBME ,
										      EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab ,
										      EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab ,
										      EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab);

	      electric_ME += factor*coupling_term*(ECH_ME_reduced_part + EC_ME_reduced_part);
	    }
	}
      
      return electric_ME;
    }
  else
    return 0.0;
}










void CC_EM_transitions_MEs::cluster::magnetic::intrinsic_NBMEs_store (
								      const class CC_target_projectile_composite_data &Tpc_data , 
								      const unsigned int iE , 
								      const unsigned int iJPi_A_out , 
								      const unsigned int ic ,  
								      const unsigned int icp , 
								      const int l_intrinsic ,
								      class array<TYPE> &MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab ,
								      class array<TYPE> &MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_tab ,
								      class array<TYPE> &MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_tab ,
								      class array<TYPE> &MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_tab ,
								      class array<TYPE> &MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab)
{
  const unsigned int ORBITAL_GRADIENT_BESSEL_YLP1_R_L_index   = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_R_L);
  const unsigned int ORBITAL_GRADIENT_BESSEL_YLP1_R_LP1_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_R_LP1);
  const unsigned int ORBITAL_GRADIENT_BESSEL_YLP1_R_LP2_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_R_LP2);
  
  const unsigned int ORBITAL_GRADIENT_BESSEL_YLP1_P_L_index   = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_P_L);
  const unsigned int ORBITAL_GRADIENT_BESSEL_YLP1_P_LP1_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_P_LP1);
  const unsigned int ORBITAL_GRADIENT_BESSEL_YLP1_P_LP2_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_P_LP2);

  const unsigned int ORBITAL_GRADIENT_BESSEL_YLM1_R_LM2_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_R_LM2);
  const unsigned int ORBITAL_GRADIENT_BESSEL_YLM1_R_LM1_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_R_LM1);
  const unsigned int ORBITAL_GRADIENT_BESSEL_YLM1_R_L_index   = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_R_L);
  
  const unsigned int ORBITAL_GRADIENT_BESSEL_YLM1_P_LM2_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_P_LM2);
  const unsigned int ORBITAL_GRADIENT_BESSEL_YLM1_P_LM1_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_P_LM1);
  const unsigned int ORBITAL_GRADIENT_BESSEL_YLM1_P_L_index   = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_P_L);
            
  const unsigned int SPIN_YL_TENSOR_S_LM1_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_YL_TENSOR_S_LM1);
  const unsigned int SPIN_YL_TENSOR_S_L_index   = EM_suboperator_type_index_determine (MAGNETIC_SPIN_YL_TENSOR_S_L);
  const unsigned int SPIN_YL_TENSOR_S_LP1_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_YL_TENSOR_S_LP1);

  const class array<TYPE> &EM_suboperator_intrinsic_NBMEs = Tpc_data.get_EM_suboperator_intrinsic_NBMEs ();
  
  const TYPE MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_L   = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLP1_R_L_index);
  const TYPE MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_LP1 = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLP1_R_LP1_index);
  const TYPE MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_LP2 = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLP1_R_LP2_index);
  
  const TYPE MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_LM2 = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLM1_R_LM2_index);
  const TYPE MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_LM1 = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLM1_R_LM1_index);
  const TYPE MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_L   = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLM1_R_L_index);
    
  const TYPE MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_L   = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLP1_P_L_index);
  const TYPE MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_LP1 = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLP1_P_LP1_index);
  const TYPE MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_LP2 = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLP1_P_LP2_index);

  
  const TYPE MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_LM2 = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLM1_P_LM2_index);
  const TYPE MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_LM1 = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLM1_P_LM1_index);
  const TYPE MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_L   = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLM1_P_L_index);
  
  const TYPE MSSCE_intrinsic_NBME_jl_Yl_tensor_s_LM1  = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , SPIN_YL_TENSOR_S_LM1_index);
  const TYPE MSSCE_intrinsic_NBME_jl_Yl_tensor_s_L    = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , SPIN_YL_TENSOR_S_L_index);
  const TYPE MSSCE_intrinsic_NBME_jl_Yl_tensor_s_LP1  = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , SPIN_YL_TENSOR_S_LP1_index);

  if (l_intrinsic == 0)
    {
      MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab(0) = MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_L;
      MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab(1) = MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_LP1;
      MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab(2) = MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_LP2;
      
      MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_tab(0) = MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_L;
      MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_tab(1) = MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_LP1;
      MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_tab(2) = MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_LP2;
      
      MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab(0) = MSSCE_intrinsic_NBME_jl_Yl_tensor_s_LP1;
    }
  else if (l_intrinsic == 1)
    {
      MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab(0) = MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_L;
      MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab(1) = MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_LP1;
      MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab(2) = MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_LP2;
      
      MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_tab(0) = MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_L;
      
      MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_tab(0) = MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_L;
      MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_tab(1) = MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_LP1;
      MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_tab(2) = MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_LP2;
      
      MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_tab(0) = MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_L;
      
      MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab(0) = MSSCE_intrinsic_NBME_jl_Yl_tensor_s_LM1;
      MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab(1) = MSSCE_intrinsic_NBME_jl_Yl_tensor_s_L;
      MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab(2) = MSSCE_intrinsic_NBME_jl_Yl_tensor_s_LP1;
    }
  else
    {
      MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab(0) = MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_L;
      MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab(1) = MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_LP1;
      MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab(2) = MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_LP2;
      
      MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_tab(0) = MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_LM2;
      MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_tab(1) = MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_LM1;
      MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_tab(2) = MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_L;
      
      MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_tab(0) = MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_L;
      MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_tab(1) = MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_LP1;
      MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_tab(2) = MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_LP2;
      
      MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_tab(0) = MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_LM2;
      MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_tab(1) = MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_LM1;
      MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_tab(2) = MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_L;
      
      MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab(0) = MSSCE_intrinsic_NBME_jl_Yl_tensor_s_LM1;
      MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab(1) = MSSCE_intrinsic_NBME_jl_Yl_tensor_s_L;
      MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab(2) = MSSCE_intrinsic_NBME_jl_Yl_tensor_s_LP1;
    }
}















TYPE CC_EM_transitions_MEs::cluster::magnetic::orbital_gradient_ME_reduced_part_calc (
										      const int pm,
										      const bool is_it_longwavelength_approximation , 
										      const int l_intrinsic , 
										      const int LCM , 
										      const int L , 
										      const class CC_state_class &CC_state_in , 
										      const class CC_state_class &CC_state_out , 
										      const unsigned int ic_in , 
										      const unsigned int ic_out ,
										      const TYPE &MO_all_intrinsic_NBME , 
										      const TYPE &MO_intrinsic_NBME_grad_jl_Yl , 
										      const class array<TYPE> &MO_intrinsic_NBME_grad_jl_Yl_r_tab , 
										      const class array<TYPE> &MO_intrinsic_NBME_grad_jl_Yl_p_tab)

{
  if (is_it_longwavelength_approximation && (pm == 1)) return 0.0;
  
  const int l_intrinsic_pm_one = l_intrinsic + pm;

  if (l_intrinsic_pm_one < 0) return 0.0;

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();
  
  const int A_projectile = channel_c_in.get_A_projectile  ();
  
  const TYPE MO_CM_radial_ME_jl        = radial_integral_calc (BESSEL        , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in  , ic_out);
  const TYPE MO_CM_radial_ME_jl_r      = radial_integral_calc (BESSEL_R      , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in  , ic_out);
  const TYPE MO_CM_radial_ME_jl_over_r = radial_integral_calc (BESSEL_OVER_R , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in  , ic_out);  
  const TYPE MO_CM_radial_ME_jl_r_der  = radial_integral_calc (BESSEL_DR     , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in  , ic_out);

  const double MO_Yl_CM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);
  
  const TYPE MO_jl_Yl_CM_ME = MO_Yl_CM_ME*MO_CM_radial_ME_jl;

  const int LCM_p_min = abs (LCM - 1);
  const int LCM_p_max =      LCM + 1;

  const unsigned int LCM_p_number = make_uns_int (LCM_p_max - LCM_p_min) + 1;

  class array<TYPE> l_tensor_Yl_CM_ME_tab(LCM_p_number);  
  class array<TYPE> Yl_tensor_e_CM_ME_tab(LCM_p_number);

  for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
    {
      const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

      l_tensor_Yl_CM_ME_tab(i_LCM_p) = OBME_YL_tensor_l_reduced_in_l (LCM , LCM_p , LCM_projectile_out , LCM_projectile_in )*minus_one_pow (LCM_projectile_out - LCM_projectile_in);
      Yl_tensor_e_CM_ME_tab(i_LCM_p) = OBME_YL_tensor_e_reduced_in_l (LCM , LCM_p , LCM_projectile_in  , LCM_projectile_out);
    }

  const class array<TYPE> MO_jl_l_tensor_Yl_CM_ME_tab = MO_CM_radial_ME_jl*l_tensor_Yl_CM_ME_tab;
  
  const class array<TYPE> MO_jl_Yl_tensor_r_CM_ME_tab = MO_CM_radial_ME_jl_r*Yl_tensor_e_CM_ME_tab;

  class array<TYPE> MO_jl_Yl_tensor_p_CM_ME_tab = MO_CM_radial_ME_jl_r_der*Yl_tensor_e_CM_ME_tab;

  for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
    {
      const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

      double MO_jl_Yl_tensor_p_CM_angular_part_ME = 0.0;
	
      for (int LCM_projectile_inter = (LCM_projectile_in == 0) ? (LCM_projectile_in + 1) : (LCM_projectile_in - 1) ; LCM_projectile_inter <= LCM_projectile_in + 1 ; LCM_projectile_inter += 2)
	{	  
	  const double e_reduced = OBME_e_reduced_in_l (LCM_projectile_inter , LCM_projectile_out);
	  
	  const double YLCM_reduced = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_inter);
      
	  const double l_factor = 0.5*(LCM_projectile_in*(LCM_projectile_in + 1.0) - LCM_projectile_inter*(LCM_projectile_inter + 1.0));
      
	  const double Wig_6j = Wigner_6j (LCM , 1 , LCM_p , LCM_projectile_in , LCM_projectile_out , LCM_projectile_inter);
      
	  MO_jl_Yl_tensor_p_CM_angular_part_ME += YLCM_reduced*e_reduced*Wig_6j*l_factor;
	}

      MO_jl_Yl_tensor_p_CM_angular_part_ME *= minus_one_pow (LCM_projectile_in + LCM_p + LCM_projectile_out)*hat (LCM_p);
      
      MO_jl_Yl_tensor_p_CM_ME_tab(i_LCM_p) += MO_jl_Yl_tensor_p_CM_angular_part_ME*MO_CM_radial_ME_jl_over_r;
    }
  
  const int phase_intrinsic_CM_swap = minus_one_pow (J_intrinsic_in + LCM_projectile_in - J_projectile_in + J_intrinsic_out + LCM_projectile_out - J_projectile_out);
      
  const TYPE MO_ME_jl_Yl_CM_all_intrinsic = Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
									  LCM_projectile_in  , J_intrinsic_in  , J_projectile_in  , 
									  LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
									  MO_jl_Yl_CM_ME , MO_all_intrinsic_NBME);

  const TYPE MO_l_jl_Yl_CM_grad_jl_Yl_intrinsic = O1a_tensor_O2b_k12_tensor_O3b_reduced_ME_calc (l_intrinsic_pm_one , 1 , l_intrinsic , LCM , L ,
												 J_intrinsic_in  , LCM_projectile_in  , J_projectile_in , 
												 J_intrinsic_out , LCM_projectile_out , J_projectile_out ,
												 MO_intrinsic_NBME_grad_jl_Yl , MO_jl_l_tensor_Yl_CM_ME_tab)*phase_intrinsic_CM_swap;
  
  const TYPE MO_p_jl_Yl_CM_grad_jl_Yl_r_intrinsic = O1b_tensor_O2a_tensor_O3a_tensor_O4b_k34_k234_reduced_ME_calc (LCM , l_intrinsic_pm_one , 1 , 1 , 1 , l_intrinsic , L ,
														   J_intrinsic_in  , LCM_projectile_in  , J_projectile_in  , 
														   J_intrinsic_out , LCM_projectile_out , J_projectile_out ,
														   MO_intrinsic_NBME_grad_jl_Yl_r_tab , MO_jl_Yl_tensor_p_CM_ME_tab)*phase_intrinsic_CM_swap;

  const TYPE MO_r_jl_Yl_CM_grad_jl_Yl_p_intrinsic = O1b_tensor_O2a_tensor_O3a_tensor_O4b_k34_k234_reduced_ME_calc (LCM , l_intrinsic_pm_one , 1 , 1 , 1 , l_intrinsic , L ,
														   J_intrinsic_in  , LCM_projectile_in  , J_projectile_in  , 
														   J_intrinsic_out , LCM_projectile_out , J_projectile_out ,
														   MO_intrinsic_NBME_grad_jl_Yl_p_tab , MO_jl_Yl_tensor_r_CM_ME_tab)*phase_intrinsic_CM_swap;
  
  const TYPE MO_sum = MO_ME_jl_Yl_CM_all_intrinsic + MO_l_jl_Yl_CM_grad_jl_Yl_intrinsic/A_projectile - M_SQRT2*(MO_p_jl_Yl_CM_grad_jl_Yl_r_intrinsic/A_projectile - MO_r_jl_Yl_CM_grad_jl_Yl_p_intrinsic);
  
  return MO_sum;
}







TYPE CC_EM_transitions_MEs::cluster::magnetic::spin_gradient_ME_reduced_calc (
									      const int pm,
									      const bool is_it_longwavelength_approximation , 
									      const int l_intrinsic , 
									      const int LCM , 
									      const int L , 
									      const class CC_state_class &CC_state_in , 
									      const class CC_state_class &CC_state_out , 
									      const unsigned int ic_in , 
									      const unsigned int ic_out , 
									      const TYPE &MS_all_intrinsic_NBME ,
									      const TYPE &MS_intrinsic_NBME_jl_Yl_tensor_s)
{
  if (is_it_longwavelength_approximation && (pm == 1)) return 0.0;
  
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  const TYPE MS_CM_radial_ME_jl         = radial_integral_calc (BESSEL                    , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE MS_CM_radial_ME_hat_jl_der = radial_integral_calc (RICCATI_BESSEL_DERIVATIVE , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  
  const double MS_Yl_CM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);

  const TYPE MS_jl_Yl_CM_ME = MS_Yl_CM_ME*MS_CM_radial_ME_jl;
  
  const TYPE MS_hat_jl_der_Yl_CM_ME = MS_Yl_CM_ME*MS_CM_radial_ME_hat_jl_der;

  const TYPE MS_hat_jl_der_minus_jl_Yl_CM_ME = MS_hat_jl_der_Yl_CM_ME - MS_jl_Yl_CM_ME;
  
  const TYPE MS_ME_jl_Yl_CM_all_intrinsic = Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
									  LCM_projectile_in  , J_intrinsic_in  , J_projectile_in  , 
									  LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
									  MS_jl_Yl_CM_ME , MS_all_intrinsic_NBME);

  const TYPE MS_hat_jl_der_minus_jl_Yl_CM_jl_Yl_intrinsic = Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
											  LCM_projectile_in  , J_intrinsic_in  , J_projectile_in  , 
											  LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
											  MS_hat_jl_der_minus_jl_Yl_CM_ME , MS_intrinsic_NBME_jl_Yl_tensor_s);
    
  const TYPE MS_MEs_sum = MS_ME_jl_Yl_CM_all_intrinsic + MS_hat_jl_der_minus_jl_Yl_CM_jl_Yl_intrinsic;

  return MS_MEs_sum;
}










TYPE CC_EM_transitions_MEs::cluster::magnetic::spin_s_scalar_e_ME_part_calc (
									     const bool is_it_longwavelength_approximation , 
									     const int l_intrinsic , 
									     const int LCM , 
									     const int L , 
									     const class CC_state_class &CC_state_in , 
									     const class CC_state_class &CC_state_out , 
									     const unsigned int ic_in , 
									     const unsigned int ic_out , 
									     const TYPE &MSSCE_all_intrinsic_NBME ,
									     const class array<TYPE> &MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab)
{	
  if (is_it_longwavelength_approximation) return 0.0;
  
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  const TYPE MSSCE_CM_radial_ME_jl     = radial_integral_calc (BESSEL         , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE MSSCE_CM_radial_ME_hat_jl = radial_integral_calc (RICCATI_BESSEL , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);

  const double MSSCE_Yl_CM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);

  const TYPE MSSCE_jl_Yl_CM_ME = MSSCE_Yl_CM_ME*MSSCE_CM_radial_ME_jl;

  const TYPE MSSCE_hat_jl_Yl_CM_ME = MSSCE_Yl_CM_ME*MSSCE_CM_radial_ME_hat_jl;

  const int LCM_p_min = abs (LCM - 1);
  const int LCM_p_max =      LCM + 1;

  const unsigned int LCM_p_number = make_uns_int (LCM_p_max - LCM_p_min) + 1;

  class array<TYPE> Yl_tensor_e_CM_OBMEs(LCM_p_number);

  for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
    {
      const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

      Yl_tensor_e_CM_OBMEs(i_LCM_p) = OBME_YL_tensor_e_reduced_in_l (LCM , LCM_p , LCM_projectile_in , LCM_projectile_out);
    }

  const class array<TYPE> MSSCE_CM_hat_jl_Yl_tensor_e_CM_OBMEs = MSSCE_hat_jl_Yl_CM_ME*Yl_tensor_e_CM_OBMEs;

  const TYPE MSSCE_ME_jl_Yl_CM_all_intrinsic = Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
									     LCM_projectile_in  , J_intrinsic_in  , J_projectile_in  , 
									     LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
									     MSSCE_jl_Yl_CM_ME , MSSCE_all_intrinsic_NBME);

  const TYPE MSSCE_CM_hat_jl_Yl_CM_hat_jl_over_r_Yl_intrinsic = O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (LCM , l_intrinsic , L , 1 ,
														 LCM_projectile_in  , J_intrinsic_in  , J_projectile_in  , 
														 LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
														 MSSCE_CM_hat_jl_Yl_tensor_e_CM_OBMEs , MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab);

  const TYPE MSSCE_sum = MSSCE_ME_jl_Yl_CM_all_intrinsic + MSSCE_CM_hat_jl_Yl_CM_hat_jl_over_r_Yl_intrinsic;

  return MSSCE_sum;
}







//--// return <uc_f lf jf || E_L || uc_i li ji>
TYPE CC_EM_transitions_MEs::cluster::magnetic::ME_reduced_calc (
								const int L , 
								const bool is_it_longwavelength_approximation ,
								const class CC_target_projectile_composite_data &Tpc_data , 
								const class array<class cluster_data> &cluster_projectile_data_tab , 
								const unsigned int iE , 
								const unsigned int iJPi_A_out , 
								const unsigned int ic , 
								const unsigned int icp , 
								const class CC_state_class &CC_state_in , 
								const class CC_state_class &CC_state_out , 
								const unsigned int ic_in , 
								const unsigned int ic_out)
{
  const unsigned int BP_Op = BP_EM_determine (MAGNETIC , L);
	  
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const class array<TYPE> &EM_suboperator_intrinsic_NBMEs = Tpc_data.get_EM_suboperator_intrinsic_NBMEs ();

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out) == BP_Op)
    {
      const complex<double> E_in_complex  = CC_state_in.get_E ();
      const complex<double> E_out_complex = CC_state_out.get_E ();
  
      const TYPE E_in  = generate_scalar<TYPE> (real (E_in_complex)  , imag (E_in_complex));
      const TYPE E_out = generate_scalar<TYPE> (real (E_out_complex) , imag (E_out_complex));
  
      const TYPE q = (E_in - E_out)/hbar_c;
  
      const unsigned int ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_L_L_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_L_L);
      const unsigned int ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_L_L_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_L_L);
            
      const unsigned int SPIN_GRADIENT_RICCATI_BESSEL_DER_YLP1_TENSOR_S_L_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLP1_TENSOR_S_L);
      const unsigned int SPIN_GRADIENT_RICCATI_BESSEL_DER_YLM1_TENSOR_S_L_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLM1_TENSOR_S_L);
      
      const unsigned int ORBITAL_GRADIENT_BESSEL_YLP1_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1);
      const unsigned int ORBITAL_GRADIENT_BESSEL_YLM1_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1);
      
      const unsigned int SPIN_GRADIENT_BESSEL_YLP1_TENSOR_S_L_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_GRADIENT_BESSEL_YLP1_TENSOR_S_L);
      const unsigned int SPIN_GRADIENT_BESSEL_YLM1_TENSOR_S_L_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_GRADIENT_BESSEL_YLM1_TENSOR_S_L);
      
      const unsigned int SPIN_S_SCALAR_E_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_S_SCALAR_E);
  
      const class cluster_data &data_c  = cluster_projectile_data_tab(ic);
      const class cluster_data &data_cp = cluster_projectile_data_tab(icp);

      const double J_intrinsic_in  = data_c.get_J_intrinsic ();
      const double J_intrinsic_out = data_cp.get_J_intrinsic ();

      const int l_intrinsic_min = abs (make_int (J_intrinsic_in - J_intrinsic_out));
      const int l_intrinsic_max =      make_int (J_intrinsic_in + J_intrinsic_out);

      TYPE magnetic_ME = 0.0;

      for (int l_intrinsic = l_intrinsic_min ; l_intrinsic <= l_intrinsic_max ; l_intrinsic++)
	{  
	  const int lp_lm1_intrinsic_min = abs (l_intrinsic - 2) , lp_lm1_intrinsic_max = l_intrinsic;	  
	  const int lp_l_intrinsic_min   = abs (l_intrinsic - 1) , lp_l_intrinsic_max   = l_intrinsic + 1;
	  const int lp_lp1_intrinsic_min =      l_intrinsic      , lp_lp1_intrinsic_max = l_intrinsic + 2;

	  const unsigned int lp_lm1_intrinsic_number = (l_intrinsic >= 1) ? (make_uns_int (lp_lm1_intrinsic_max - lp_lm1_intrinsic_min) + 1) : (0);
	  
	  const unsigned int lp_l_intrinsic_number   = make_uns_int (lp_l_intrinsic_max   - lp_l_intrinsic_min  ) + 1;
	  const unsigned int lp_lp1_intrinsic_number = make_uns_int (lp_lp1_intrinsic_max - lp_lp1_intrinsic_min) + 1;
	  
	  const TYPE MOLP1INT_all_intrinsic_NBME = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_L_L_index);
	  const TYPE MOLM1INT_all_intrinsic_NBME = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_L_L_index);
	  const TYPE MSLP1INT_all_intrinsic_NBME = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , SPIN_GRADIENT_RICCATI_BESSEL_DER_YLP1_TENSOR_S_L_index);
	  const TYPE MSLM1INT_all_intrinsic_NBME = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , SPIN_GRADIENT_RICCATI_BESSEL_DER_YLM1_TENSOR_S_L_index);
	  
	  const TYPE MSSCE_all_intrinsic_NBME = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , SPIN_S_SCALAR_E_index);
	  
	  const TYPE MOLP1INT_intrinsic_NBME_grad_jl_Yl          = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLP1_index);
	  const TYPE MOLM1INT_intrinsic_NBME_grad_jl_Yl          = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLM1_index);  
	  const TYPE MSLP1INT_intrinsic_NBME_grad_jl_Yl_tensor_s = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , SPIN_GRADIENT_BESSEL_YLP1_TENSOR_S_L_index);
	  const TYPE MSLM1INT_intrinsic_NBME_grad_jl_Yl_tensor_s = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , l_intrinsic , SPIN_GRADIENT_BESSEL_YLM1_TENSOR_S_L_index);
	  
	  class array<TYPE> MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab(lp_lp1_intrinsic_number) , MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_tab(lp_lp1_intrinsic_number);
	  class array<TYPE> MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_tab(lp_lm1_intrinsic_number) , MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_tab(lp_lm1_intrinsic_number);
	  
	  class array<TYPE> MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab(lp_l_intrinsic_number);
	  
	  magnetic::intrinsic_NBMEs_store (Tpc_data , iE , iJPi_A_out , ic , icp , l_intrinsic , 
					   MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab , MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_tab ,
					   MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_tab , MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_tab ,
					   MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab);

	  const int LCM_min_in_out = abs (LCM_projectile_in - LCM_projectile_out);	  
	  const int LCM_max_in_out =      LCM_projectile_in + LCM_projectile_out;

	  const int LCM_min_l_intrinsic_L = abs (L - l_intrinsic);	  
	  const int LCM_max_l_intrinsic_L =      L + l_intrinsic;

	  const int LCM_min_L = max (LCM_min_in_out , LCM_min_l_intrinsic_L);
	  const int LCM_max_L = min (LCM_max_in_out , LCM_max_l_intrinsic_L);
	  
	  for (int LCM = LCM_min_L ; LCM <= LCM_max_L ; LCM++)
	    {
	      if ((l_intrinsic + LCM + L)%2 == 1) continue;

	      if (is_it_longwavelength_approximation && (l_intrinsic + LCM != L)) continue;
		      		      
	      const double coupling_term = coupling_term_l_intrinsic_LCM (l_intrinsic , LCM , L);
		  
	      const TYPE pow_q_l_intrinsic_plus_LCM_minus_L = (!is_it_longwavelength_approximation) ? (pow (q , l_intrinsic + LCM - L)) : (1.0);
	      
	      const TYPE factor = pow_q_l_intrinsic_plus_LCM_minus_L*(l_intrinsic + 1.0)*(LCM + 1.0)*double_factorial (2*L + 1)/((L + 1.0)*double_factorial (2*l_intrinsic + 1)*double_factorial (2*LCM + 1));
	      
	      const TYPE MOLP1INT_part = magnetic::orbital_gradient_ME_reduced_part_calc (1 , is_it_longwavelength_approximation , l_intrinsic , LCM , L , CC_state_in , CC_state_out , ic_in , ic_out ,
											  MOLP1INT_all_intrinsic_NBME ,
											  MOLP1INT_intrinsic_NBME_grad_jl_Yl ,
											  MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab ,
											  MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_tab);

	      const TYPE MOLM1INT_part = magnetic::orbital_gradient_ME_reduced_part_calc (-1 , is_it_longwavelength_approximation , l_intrinsic , LCM , L , CC_state_in , CC_state_out , ic_in , ic_out ,
											  MOLM1INT_all_intrinsic_NBME ,
											  MOLM1INT_intrinsic_NBME_grad_jl_Yl ,
											  MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_tab ,
											  MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_tab);

	      const TYPE MSLP1INT_part = magnetic::spin_gradient_ME_reduced_calc (1 , is_it_longwavelength_approximation , l_intrinsic , LCM , L , CC_state_in , CC_state_out , ic_in , ic_out ,
										  MSLP1INT_all_intrinsic_NBME ,
										  MSLP1INT_intrinsic_NBME_grad_jl_Yl_tensor_s);

	      const TYPE MSLM1INT_part = magnetic::spin_gradient_ME_reduced_calc (-1 , is_it_longwavelength_approximation , l_intrinsic , LCM , L , CC_state_in , CC_state_out , ic_in , ic_out ,
										  MSLM1INT_all_intrinsic_NBME ,
										  MSLM1INT_intrinsic_NBME_grad_jl_Yl_tensor_s);

	      const TYPE MSSCE_ME_part = magnetic::spin_s_scalar_e_ME_part_calc (is_it_longwavelength_approximation , l_intrinsic , LCM , L , CC_state_in , CC_state_out , ic_in , ic_out ,
										 MSSCE_all_intrinsic_NBME ,
										 MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab);

	      magnetic_ME += factor*coupling_term*(MOLP1INT_part + MOLM1INT_part + MSLP1INT_part + MSLM1INT_part + MSSCE_ME_part);
	    }	
	}
      
      return magnetic_ME;
    }
  else
    return 0.0;
}











double CC_EM_transitions_MEs::cluster::coupling_term_l_intrinsic_LCM (const int l_intrinsic , const int LCM , const int L)
{
  const int phase = minus_one_pow ((l_intrinsic + LCM + L)/2);

  const double sqrt_four_Pi = 3.544907701811032;

  const double hats = hat (l_intrinsic)*hat (LCM);

  const double Wig_3j = Wigner_3j (LCM , l_intrinsic , L , 0 , 0 , 0);

  const double coupling_term = sqrt_four_Pi*phase*hats*Wig_3j;

  return coupling_term;
}








// return <uc_f lf jf || M/E_L || uc_i li ji>
TYPE CC_EM_transitions_MEs::cluster::ME_reduced_calc (
						      const enum EM_type EM , 
						      const int L , 
						      const bool is_it_longwavelength_approximation ,
						      const class CC_target_projectile_composite_data &Tpc_data , 
						      const class array<class cluster_data> &cluster_projectile_data_tab , 
						      const unsigned int iE , 
						      const unsigned int iJPi_A_out , 
						      const unsigned int ic ,  
						      const unsigned int icp ,  
						      const class CC_state_class &CC_state_in , 
						      const class CC_state_class &CC_state_out , 
						      const unsigned int ic_in , 
						      const unsigned int ic_out)
{
  switch (EM)
    {
    case ELECTRIC: return electric::ME_reduced_calc (L , is_it_longwavelength_approximation , Tpc_data , cluster_projectile_data_tab , iE , iJPi_A_out , ic , icp , CC_state_in , CC_state_out , ic_in , ic_out);
    case MAGNETIC: return magnetic::ME_reduced_calc (L , is_it_longwavelength_approximation , Tpc_data , cluster_projectile_data_tab , iE , iJPi_A_out , ic , icp , CC_state_in , CC_state_out , ic_in , ic_out);

    default: abort_all ();
    }

  return NADA;
}




