#include "../CC_include/CC_include_def.h"



using namespace Wigner_signs;
using namespace angular_matrix_elements;
using namespace inputs_misc;
using namespace EM_transitions_common;
using namespace EM_transitions;

using namespace CC_EM_transitions_MEs::radial;



TYPE CC_EM_transitions_MEs::cluster::EM_suboperator_intrinsic_NBME_calc (
									 const enum EM_suboperator_type EM_suboperator , 
									 const enum radial_operator_type radial_operator , 
									 const TYPE &q , 
									 const int L , 
									 const int Lc , 
									 const bool is_it_longwavelength_approximation , 
									 const bool is_it_HO_expansion , 
									 const class interaction_class &inter_data_basis ,  
									 const class cluster_data &data_c , 
									 const class cluster_data &data_cp , 
									 const class GSM_vector &PSI_cluster_c ,
									 const class GSM_vector &PSI_cluster_cp ,
									 class GSM_vector &PSI_full)
{
  // if true , the L_min/max are put to the L value for the total cross section
  // the interferences between different L values disappear due to the orthogonality of the Wigner D-matrices

  const unsigned int Z_cluster = data_c.get_Z_cluster ();
  const unsigned int N_cluster = data_c.get_N_cluster ();

  const enum space_type space = space_determine (Z_cluster , N_cluster);

  const double Jc  = data_c.get_J_intrinsic ();
  const double Jcp = data_cp.get_J_intrinsic ();

  const double b_HO = inter_data_basis.get_b_lab ();
	
  const TYPE EM_suboperator_NBME = EM_suboperator_B_amplitude_calc (EM_suboperator , radial_operator , q , L , Lc , is_it_longwavelength_approximation , is_it_HO_expansion ,
								    space , inter_data_basis , PSI_full , Jc , PSI_cluster_c , Jcp , PSI_cluster_cp);	

  const TYPE j0_ME = static_cast<TYPE> (HO_wave_functions::HO_3D::j0_ME_calc (b_HO , q));
  
  const TYPE hat_j0_derivative_ME = static_cast<TYPE> (HO_wave_functions::HO_3D::hat_j0_derivative_ME_calc (b_HO , q));

  const TYPE RCM_hat_j0_ME = static_cast<TYPE> (HO_wave_functions::HO_3D::r_hat_j0_ME_calc (b_HO , q));

  if ((EM_suboperator == ELECTRIC_CHARGE_YL_TENSOR_E) ||
      (EM_suboperator == ELECTRIC_CURRENT) ||
      (EM_suboperator == ELECTRIC_CURRENT_YL_TENSOR_S) ||
      (EM_suboperator == MAGNETIC_ORBITAL_GRADIENT_BESSEL_LP1) ||
      (EM_suboperator == MAGNETIC_ORBITAL_GRADIENT_BESSEL_LM1) ||
      (EM_suboperator == MAGNETIC_SPIN_GRADIENT_BESSEL_LP1) ||
      (EM_suboperator == MAGNETIC_SPIN_GRADIENT_BESSEL_LM1) ||
      (EM_suboperator == MAGNETIC_SPIN_S_SCALAR_E) ||
      (EM_suboperator == MAGNETIC_SPIN_YL_TENSOR_S))
    {
      const TYPE EM_suboperator_NBME_intrinsic = EM_suboperator_NBME/j0_ME;

      return EM_suboperator_NBME_intrinsic;
    }

  if (EM_suboperator == ELECTRIC_CHARGE_YL)
    {
      if (radial_operator == BESSEL)
	{
	  const TYPE EM_suboperator_NBME_intrinsic = EM_suboperator_NBME/j0_ME;

	  return EM_suboperator_NBME_intrinsic;
	}

      if (radial_operator == RICCATI_BESSEL_OVER_R)
	{
	  const TYPE EM_suboperator_Bessel = EM_suboperator_B_amplitude_calc (EM_suboperator , BESSEL , q , L , Lc , is_it_longwavelength_approximation , is_it_HO_expansion ,
									      space , inter_data_basis , PSI_full , Jc , PSI_cluster_c , Jcp , PSI_cluster_cp);

	  const TYPE EM_suboperator_intrinsic_Bessel = EM_suboperator_Bessel/j0_ME;

	  const TYPE EM_suboperator_Riccati_Bessel_over_r_intrinsic = (EM_suboperator_NBME - EM_suboperator_intrinsic_Bessel*RCM_hat_j0_ME)/j0_ME;

	  return EM_suboperator_Riccati_Bessel_over_r_intrinsic;
	}
    }

  if (EM_suboperator == ELECTRIC_CHARGE)
    {
      const TYPE EM_suboperator_Bessel = EM_suboperator_B_amplitude_calc (EM_suboperator , BESSEL , q , L , Lc , is_it_longwavelength_approximation , is_it_HO_expansion ,
									  space , inter_data_basis , PSI_full , Jc , PSI_cluster_c , Jcp , PSI_cluster_cp);

      const TYPE EM_suboperator_intrinsic_Bessel = EM_suboperator_Bessel/j0_ME;

      const TYPE EM_suboperator_NBME_intrinsic = (EM_suboperator_NBME - EM_suboperator_intrinsic_Bessel*(hat_j0_derivative_ME + RCM_hat_j0_ME))/j0_ME;

      return EM_suboperator_NBME_intrinsic;
    }

  if (EM_suboperator == MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_LP1)
    {
      const TYPE EM_suboperator_magnetic_spin_gradient_Bessel = EM_suboperator_B_amplitude_calc (EM_suboperator , GRADIENT_BESSEL_LP1 , q , L , Lc , is_it_longwavelength_approximation , is_it_HO_expansion ,
												 space , inter_data_basis , PSI_full , Jc , PSI_cluster_c , Jcp , PSI_cluster_cp);

      const TYPE EM_suboperator_intrinsic_magnetic_spin_gradient_Bessel = EM_suboperator_magnetic_spin_gradient_Bessel/j0_ME;

      const TYPE EM_suboperator_NBME_intrinsic = (EM_suboperator_NBME - EM_suboperator_intrinsic_magnetic_spin_gradient_Bessel*(hat_j0_derivative_ME - j0_ME))/j0_ME;

      return EM_suboperator_NBME_intrinsic;
    }

  if (EM_suboperator == MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_LM1)
    {
      const TYPE EM_suboperator_magnetic_spin_gradient_Bessel = EM_suboperator_B_amplitude_calc (EM_suboperator , GRADIENT_BESSEL_LM1 , q , L , Lc , is_it_longwavelength_approximation , is_it_HO_expansion ,
												 space , inter_data_basis , PSI_full , Jc , PSI_cluster_c , Jcp , PSI_cluster_cp);

      const TYPE EM_suboperator_intrinsic_magnetic_spin_gradient_Bessel = EM_suboperator_magnetic_spin_gradient_Bessel/j0_ME;

      const TYPE EM_suboperator_NBME_intrinsic = (EM_suboperator_NBME - EM_suboperator_intrinsic_magnetic_spin_gradient_Bessel*(hat_j0_derivative_ME - j0_ME))/j0_ME;

      return EM_suboperator_NBME_intrinsic;
    }

  error_message_print_abort ("No electromagnetic/radial operator type combination recognized in EM_suboperator_intrinsic_NBME_calc");

  return NADA;
}








void CC_EM_transitions_MEs::cluster::electric::intrinsic_NBMEs_store (
								      const class CC_target_projectile_composite_data &Tpc_data , 
								      const unsigned int iE , 
								      const unsigned int iJPi_A_out , 
								      const unsigned int ic ,  
								      const unsigned int icp , 
								      const int L ,
								      const int l_intrinsic ,
								      class array<TYPE> &ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab , 
								      class array<TYPE> &EC_intrinsic_NBME_jl_Yl_tensor_s_tab)
{
  const unsigned int ELECTRIC_CHARGE_YL_TENSOR_E_index  = EM_suboperator_type_index_determine (ELECTRIC_CHARGE_YL_TENSOR_E);
  const unsigned int ELECTRIC_CURRENT_YL_TENSOR_S_index = EM_suboperator_type_index_determine (ELECTRIC_CURRENT_YL_TENSOR_S);

  const unsigned int RICCATI_BESSEL_index = radial_operator_type_index_determine (RICCATI_BESSEL);

  const int lp_intrinsic_min = max (l_intrinsic - 1 , 0);

  const int lp_intrinsic_max = l_intrinsic + 1;

  const class array<TYPE> &EM_suboperator_intrinsic_NBMEs = Tpc_data.get_EM_suboperator_intrinsic_NBMEs ();

  for (int lp_intrinsic = lp_intrinsic_min ; lp_intrinsic <= lp_intrinsic_max ; lp_intrinsic++)
    {
      const unsigned int i_lp_int = make_uns_int (lp_intrinsic - lp_intrinsic_min);

      ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab(i_lp_int) = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , lp_intrinsic , ELECTRIC_CHARGE_YL_TENSOR_E_index , RICCATI_BESSEL_index);
      
      EC_intrinsic_NBME_jl_Yl_tensor_s_tab(i_lp_int) = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , lp_intrinsic , ELECTRIC_CURRENT_YL_TENSOR_S_index , RICCATI_BESSEL_index);
    }
}









TYPE CC_EM_transitions_MEs::cluster::electric::charge_ME_reduced_part_calc (
									    const bool is_it_longwavelength_approximation , 
									    const int l_intrinsic , 
									    const int LCM , 
									    const int L , 
									    const class CC_state_class &CC_state_in , 
									    const class CC_state_class &CC_state_out , 
									    const unsigned int ic_in , 
									    const unsigned int ic_out , 
									    const TYPE &ECH_all_intrinsic_NBME , 
									    const TYPE &ECH_intrinsic_NBME_jl_Yl , 
									    const TYPE &ECH_intrinsic_NBME_hat_jl_over_r_Yl , 
									    const class array<TYPE> &ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab)
{	
  const double sqrt_four_pi_over_three = 2.046653415892977;

  const double Y1_norm_factor = sqrt_four_pi_over_three;	

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  //--// calculations of the radial electric charge and current
  const TYPE ECH_CM_radial_ME_jl           = radial_integral_calc (BESSEL                    , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE ECH_CM_radial_ME_hat_jl_der   = radial_integral_calc (RICCATI_BESSEL_DERIVATIVE , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE ECH_CM_radial_ME_hat_jl       = radial_integral_calc (RICCATI_BESSEL            , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);

  const double Y_LCM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);
  
  const TYPE ECH_CM_ME_jl_Yl = ECH_CM_radial_ME_jl*Y_LCM_ME;

  const TYPE ECH_CM_ME_hat_jl_der_Yl = ECH_CM_radial_ME_hat_jl_der*Y_LCM_ME;

  const TYPE ECH_CM_ME_hat_jl_r_Yl = ECH_CM_radial_ME_hat_jl*Y_LCM_ME;

  const int LCM_p_min = max (LCM - 1 , 0);

  const int LCM_p_max = LCM + 1;

  const unsigned int LCM_p_number = make_uns_int (LCM_p_max - LCM_p_min) + 1;

  class array<TYPE> Yl_tensor_e_CM_ME_tab(LCM_p_number);

  for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
    {
      const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

      const double Yl_tensor_e_CM_ME = Y1_norm_factor*YL1_tensor_YL2_reduced_in_l (LCM , 1 , LCM_p , LCM_projectile_in , LCM_projectile_out);

      Yl_tensor_e_CM_ME_tab(i_LCM_p) = Yl_tensor_e_CM_ME;
    }

  const class array<TYPE> ECH_CM_hat_jl_Yl_tensor_e_CM_ME_tab = ECH_CM_radial_ME_hat_jl*Yl_tensor_e_CM_ME_tab;

  const TYPE ECH_ME_jl_Yl_CM_all_Yl_intrinsic = static_cast<TYPE> (Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
												 LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
												 LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
												 ECH_CM_ME_jl_Yl , ECH_all_intrinsic_NBME));


  const TYPE ECH_ME_hat_jl_der_Yl_CM_jl_Yl_intrinsic = static_cast<TYPE> (Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
													LCM_projectile_in , l_intrinsic , J_projectile_in , 
													LCM_projectile_out , l_intrinsic , J_projectile_out ,
													ECH_CM_ME_hat_jl_der_Yl , ECH_intrinsic_NBME_jl_Yl));

  const TYPE ECH_ME_hat_jl_r_Yl_CM_hat_jl_over_r_Yl_intrinsic = 0.5*static_cast<TYPE> (Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
														     LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
														     LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
														     ECH_CM_ME_hat_jl_r_Yl , ECH_intrinsic_NBME_hat_jl_over_r_Yl));

  const TYPE ECH_ME_hat_jl_Yl_e_CM_hat_jl_Yl_e_intrinsic = static_cast<TYPE> (O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (LCM , l_intrinsic , L , 1 ,
															       LCM_projectile_in , l_intrinsic , J_projectile_in , 
															       LCM_projectile_out , l_intrinsic , J_projectile_out ,
															       ECH_CM_hat_jl_Yl_tensor_e_CM_ME_tab , ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab));

  const TYPE ECH_MEs_sum = ECH_ME_jl_Yl_CM_all_Yl_intrinsic + ECH_ME_hat_jl_der_Yl_CM_jl_Yl_intrinsic + ECH_ME_hat_jl_r_Yl_CM_hat_jl_over_r_Yl_intrinsic + ECH_ME_hat_jl_Yl_e_CM_hat_jl_Yl_e_intrinsic;

  return ECH_MEs_sum;
}









TYPE CC_EM_transitions_MEs::cluster::electric::current_ME_reduced_part_calc (
									     const bool is_it_longwavelength_approximation , 
									     const int l_intrinsic , 
									     const int LCM , 
									     const int L , 
									     const class CC_state_class &CC_state_in , 
									     const class CC_state_class &CC_state_out , 
									     const unsigned int ic_in , 
									     const unsigned int ic_out , 
									     const TYPE &EC_all_intrinsic_NBME , 
									     const class array<TYPE> &EC_intrinsic_NBME_jl_Yl_tensor_s_tab)
{
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  //--// calculations of the radial electric charge and current
  const TYPE EC_CM_radial_ME_jl = radial_integral_calc (BESSEL , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  
  const TYPE EC_CM_radial_ME_hat_jl_over_r = radial_integral_calc (RICCATI_BESSEL_OVER_R , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);

  const double Y_LCM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);
  
  const TYPE EC_CM_ME_jl_Yl = Y_LCM_ME*EC_CM_radial_ME_jl;

  const int LCM_p_min = max (LCM - 1 , 0);

  const int LCM_p_max = LCM + 1;

  const unsigned int LCM_p_number = make_uns_int (LCM_p_max - LCM_p_min) + 1;

  class array<TYPE> Yl_tensor_l_CM_ME_tab(LCM_p_number);

  for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
    {
      const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

      const double Yl_tensor_l_CM_ME = OBME_YL_tensor_l_reduced_in_l (LCM_p , LCM , LCM_projectile_in , LCM_projectile_out);

      Yl_tensor_l_CM_ME_tab(i_LCM_p) = Yl_tensor_l_CM_ME;
    }

  const class array<TYPE> EC_CM_hat_jl_over_r_Yl_tensor_l_ME_tab = EC_CM_radial_ME_hat_jl_over_r*Yl_tensor_l_CM_ME_tab;

  const TYPE EC_ME_jl_Yl_CM_all_intrinsic = static_cast<TYPE> (Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
											     LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
											     LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
											     EC_CM_ME_jl_Yl , EC_all_intrinsic_NBME));

  const TYPE EC_ME_hat_jl_over_r_Yl_l_CM_jl_Yl_s_intrinsic = static_cast<TYPE> (O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (LCM , l_intrinsic , L , 1 ,
																 LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
																 LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
																 EC_CM_hat_jl_over_r_Yl_tensor_l_ME_tab , EC_intrinsic_NBME_jl_Yl_tensor_s_tab));

  const TYPE EC_MEs_sum = EC_ME_jl_Yl_CM_all_intrinsic + EC_ME_hat_jl_over_r_Yl_l_CM_jl_Yl_s_intrinsic;

  return EC_MEs_sum;
}







//--// return <uc_f lf jf || E_L || uc_i li ji>
TYPE CC_EM_transitions_MEs::cluster::electric::ME_reduced_calc (
								const int L , 
								const bool is_it_longwavelength_approximation ,
								const class CC_target_projectile_composite_data &Tpc_data , 
								const class array<class cluster_data> &cluster_data_tab , 
								const unsigned int iE , 
								const unsigned int iJPi_A_out , 
								const unsigned int ic ,  
								const unsigned int icp , 
								const class CC_state_class &CC_state_in , 
								const class CC_state_class &CC_state_out , 
								const unsigned int ic_in , 
								const unsigned int ic_out)
{
  const unsigned int BP_Op = BP_EM_determine (ELECTRIC , L);

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out) == BP_Op)
    {      
      const unsigned int ELECTRIC_CHARGE_YL_index = EM_suboperator_type_index_determine (ELECTRIC_CHARGE_YL);
      const unsigned int ELECTRIC_CHARGE_index    = EM_suboperator_type_index_determine (ELECTRIC_CHARGE);
      const unsigned int ELECTRIC_CURRENT_index   = EM_suboperator_type_index_determine (ELECTRIC_CURRENT);

      const unsigned int BESSEL_index                  = radial_operator_type_index_determine (BESSEL);
      const unsigned int RICCATI_BESSEL_OVER_R_index   = radial_operator_type_index_determine (RICCATI_BESSEL_OVER_R);
      const unsigned int ELECTRIC_CHARGE_RADIAL_index  = radial_operator_type_index_determine (ELECTRIC_CHARGE_RADIAL);
      const unsigned int ELECTRIC_CURRENT_RADIAL_index = radial_operator_type_index_determine (ELECTRIC_CURRENT_RADIAL);

      const class cluster_data &data_c  = cluster_data_tab(ic);
      const class cluster_data &data_cp = cluster_data_tab(icp);

      const double J_intrinsic_in  = data_c.get_J_intrinsic ();
      const double J_intrinsic_out = data_cp.get_J_intrinsic ();

      const int l_intrinsic_min = abs (make_int (J_intrinsic_in - J_intrinsic_out));

      const int l_intrinsic_max = make_int (J_intrinsic_in + J_intrinsic_out);

      const class array<TYPE> &EM_suboperator_intrinsic_NBMEs = Tpc_data.get_EM_suboperator_intrinsic_NBMEs ();

      TYPE electric_ME = 0.0;

      for (int l_intrinsic = l_intrinsic_min ; l_intrinsic <= l_intrinsic_max ; l_intrinsic++)
	{	
	  const TYPE ECH_intrinsic_NBME_jl_Yl            = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , l_intrinsic , ELECTRIC_CHARGE_YL_index , BESSEL_index);
	  const TYPE ECH_all_intrinsic_NBME              = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , l_intrinsic , ELECTRIC_CHARGE_index    , ELECTRIC_CHARGE_RADIAL_index);
	  const TYPE ECH_intrinsic_NBME_hat_jl_over_r_Yl = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , l_intrinsic , ELECTRIC_CHARGE_YL_index , RICCATI_BESSEL_OVER_R_index);

	  const TYPE EC_all_intrinsic_NBME = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , l_intrinsic , ELECTRIC_CURRENT_index , ELECTRIC_CURRENT_RADIAL_index);

	  const int lp_intrinsic_min = max (l_intrinsic - 1 , 0);

	  const int lp_intrinsic_max = l_intrinsic + 1;
	  
	  const unsigned int lp_intrinsic_number = make_uns_int (lp_intrinsic_max - lp_intrinsic_min) + 1;

	  class array<TYPE> ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab(lp_intrinsic_number);

	  class array<TYPE> EC_intrinsic_NBME_jl_Yl_tensor_s_tab(lp_intrinsic_number);

	  electric::intrinsic_NBMEs_store (Tpc_data , iE , iJPi_A_out , ic , icp , L , l_intrinsic , ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab , EC_intrinsic_NBME_jl_Yl_tensor_s_tab);

	  const int LCM_min_in_out = abs (LCM_projectile_in - LCM_projectile_out);
	  
	  const int LCM_max_in_out = LCM_projectile_in + LCM_projectile_out;

	  const int LCM_min_l_intrinsic_L = abs (L - l_intrinsic);
	  
	  const int LCM_max_l_intrinsic_L = L + l_intrinsic;

	  const int LCM_min = max (LCM_min_in_out , LCM_min_l_intrinsic_L);
	  const int LCM_max = min (LCM_max_in_out , LCM_max_l_intrinsic_L);

	  for (int LCM = LCM_min ; LCM <= LCM_max ; LCM++)
	    {
	      const double coupling_term = coupling_term_l_intrinsic_LCM (l_intrinsic , LCM , L);

	      const TYPE ECH_ME_reduced_part = electric::charge_ME_reduced_part_calc (is_it_longwavelength_approximation , l_intrinsic , LCM , L ,
										      CC_state_in , CC_state_out , ic_in , ic_out , 
										      ECH_all_intrinsic_NBME , ECH_intrinsic_NBME_jl_Yl , 
										      ECH_intrinsic_NBME_hat_jl_over_r_Yl , ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab);

	      const TYPE EC_ME_reduced_part = electric::current_ME_reduced_part_calc (is_it_longwavelength_approximation , l_intrinsic , LCM , L ,
										      CC_state_in , CC_state_out , ic_in , ic_out , 
										      EC_all_intrinsic_NBME , EC_intrinsic_NBME_jl_Yl_tensor_s_tab);

	      electric_ME += coupling_term*(ECH_ME_reduced_part + EC_ME_reduced_part);
	    }
	}

      return electric_ME;
    }
  else
    return 0.0;
}










void CC_EM_transitions_MEs::cluster::magnetic::intrinsic_NBMEs_store (
								      const class CC_target_projectile_composite_data &Tpc_data , 
								      const unsigned int iE , 
								      const unsigned int iJPi_A_out , 
								      const unsigned int ic ,  
								      const unsigned int icp , 
								      const int L , 
								      const int l_intrinsic ,  
								      class array<TYPE> &MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab)
{
  const unsigned int MAGNETIC_SPIN_YL_TENSOR_S_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_YL_TENSOR_S);

  const unsigned int RICCATI_BESSEL_OVER_R_index = radial_operator_type_index_determine (RICCATI_BESSEL_OVER_R);

  const int lp_intrinsic_min = max (l_intrinsic - 1 , 0);

  const int lp_intrinsic_max = l_intrinsic + 1;

  const class array<TYPE> &EM_suboperator_intrinsic_NBMEs = Tpc_data.get_EM_suboperator_intrinsic_NBMEs ();

  for (int lp_intrinsic = lp_intrinsic_min ; lp_intrinsic <= lp_intrinsic_max ; lp_intrinsic++)
    {
      const unsigned int i_lp_intrinsic = make_uns_int (lp_intrinsic - lp_intrinsic_min);

      MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab(i_lp_intrinsic) = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , lp_intrinsic , MAGNETIC_SPIN_YL_TENSOR_S_index , RICCATI_BESSEL_OVER_R_index);
    }
}




















TYPE CC_EM_transitions_MEs::cluster::magnetic::orbital_gradient_ME_reduced_part_calc (
										      const int pm,
										      const bool is_it_longwavelength_approximation , 
										      const int l_intrinsic , 
										      const int LCM , 
										      const int L , 
										      const class CC_state_class &CC_state_in , 
										      const class CC_state_class &CC_state_out , 
										      const unsigned int ic_in , 
										      const unsigned int ic_out ,
										      const TYPE &MO_all_intrinsic_NBME , 
										      const TYPE &MO_intrinsic_NBME_jl_Yl)

{
  const int l_intrinsic_pm_one = l_intrinsic + pm;
  if (l_intrinsic_pm_one < 0) return 0.0;

  const double sqrt_four_pi_over_three = 2.046653415892977 , Y1_norm_factor = sqrt_four_pi_over_three;	

  const class array<class CC_channel_class> &channels_tab_in = CC_state_in.get_channels_tab () , &channels_tab_out = CC_state_out.get_channels_tab ();
  const class CC_channel_class &channel_c_in = channels_tab_in(ic_in) , &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in = channel_c_in.get_LCM_projectile () , LCM_projectile_out = channel_c_out.get_LCM_projectile ();
  const double J_intrinsic_in = channel_c_in.get_J_intrinsic_projectile () , J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();
  const double J_projectile_in = channel_c_in.get_J_projectile () , J_projectile_out = channel_c_out.get_J_projectile ();

  const TYPE MO_CM_radial_ME_jl = radial_integral_calc (BESSEL , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);

  const double MO_Yl_CM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);
  const TYPE MO_jl_Yl_CM_ME = MO_Yl_CM_ME*MO_CM_radial_ME_jl;

  const int LCM_p_min = max (LCM - 1 , 0) , LCM_p_max = LCM + 1;
  const unsigned int LCM_p_number = make_uns_int (LCM_p_max - LCM_p_min) + 1;

  class array<TYPE> Yl_tensor_l_CM_ME_tab(LCM_p_number);

  for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
    {
      const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

      const double Yl_tensor_l_CM_ME = Y1_norm_factor*YL1_tensor_YL2_reduced_in_l (LCM , 1 , LCM_p , LCM_projectile_in , LCM_projectile_out);

      Yl_tensor_l_CM_ME_tab(i_LCM_p) = Yl_tensor_l_CM_ME;
    }

  const int phase = minus_one_pow (LCM_projectile_in + J_intrinsic_in - J_projectile_in + LCM_projectile_out + J_intrinsic_out - J_projectile_out);

  const class array<TYPE> MO_jl_Yl_tensor_l_CM_ME_tab = MO_CM_radial_ME_jl*Yl_tensor_l_CM_ME_tab;

  const TYPE MO_ME_jl_Yl_CM_all_intrinsic = static_cast<TYPE> (Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
											     LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
											     LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
											     MO_jl_Yl_CM_ME , MO_all_intrinsic_NBME));

  const TYPE MO_jl_Yl_l_CM_hat_jl_Yl_intrinsic = static_cast<TYPE> (O1a_tensor_O2b_k12_tensor_O3b_reduced_ME_calc (l_intrinsic_pm_one , 1 , l_intrinsic , LCM , L ,
														   J_intrinsic_in , LCM_projectile_in , J_projectile_in , 
														   J_intrinsic_out , LCM_projectile_out , J_projectile_out ,
														   MO_intrinsic_NBME_jl_Yl , MO_jl_Yl_tensor_l_CM_ME_tab));

  const TYPE MO_sum = MO_ME_jl_Yl_CM_all_intrinsic + phase*MO_jl_Yl_l_CM_hat_jl_Yl_intrinsic;

  return MO_sum;
}







TYPE CC_EM_transitions_MEs::cluster::magnetic::spin_gradient_ME_reduced_calc (
									      const bool is_it_longwavelength_approximation , 
									      const int l_intrinsic , 
									      const int LCM , 
									      const int L , 
									      const class CC_state_class &CC_state_in , 
									      const class CC_state_class &CC_state_out , 
									      const unsigned int ic_in , 
									      const unsigned int ic_out , 
									      const TYPE &MS_all_intrinsic_NBME ,
									      const TYPE &MS_intrinsic_NBME_jl_Yl_tensor_s)
{
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  const TYPE MS_CM_radial_ME_jl         = radial_integral_calc (BESSEL                    , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE MS_CM_radial_ME_hat_jl_der = radial_integral_calc (RICCATI_BESSEL_DERIVATIVE , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);

  const double MS_Yl_CM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);

  const TYPE MS_jl_Yl_CM_ME = MS_Yl_CM_ME*MS_CM_radial_ME_jl;
  
  const TYPE MS_hat_jl_der_Yl_CM_ME = MS_Yl_CM_ME*MS_CM_radial_ME_hat_jl_der;

  const TYPE MS_ME_jl_Yl_CM_all_intrinsic = static_cast<TYPE> (Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
											     LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
											     LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
											     MS_jl_Yl_CM_ME , MS_all_intrinsic_NBME));

  const TYPE MS_hat_jl_der_minus_jl_Yl_CM_jl_Yl_intrinsic = static_cast<TYPE> (Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic ,  L ,
													     LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
													     LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
													     MS_hat_jl_der_Yl_CM_ME - MS_jl_Yl_CM_ME , MS_intrinsic_NBME_jl_Yl_tensor_s));

  const TYPE MS_MEs_sum = MS_ME_jl_Yl_CM_all_intrinsic + MS_hat_jl_der_minus_jl_Yl_CM_jl_Yl_intrinsic;

  return MS_MEs_sum;
}










TYPE CC_EM_transitions_MEs::cluster::magnetic::spin_s_scalar_e_ME_part_calc (
									     const bool is_it_longwavelength_approximation , 
									     const int l_intrinsic , 
									     const int LCM , 
									     const int L , 
									     const class CC_state_class &CC_state_in , 
									     const class CC_state_class &CC_state_out , 
									     const unsigned int ic_in , 
									     const unsigned int ic_out , 
									     const TYPE &MSSCE_all_intrinsic_NBME ,
									     const class array<TYPE> &MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab)
{	
  const double sqrt_four_pi_over_three = 2.046653415892977;

  const double Y1_norm_factor = sqrt_four_pi_over_three;

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  const TYPE MSSCE_CM_radial_ME_jl   = radial_integral_calc (BESSEL   , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE MSSCE_CM_radial_ME_jl_r = radial_integral_calc (BESSEL_R , LCM , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);

  const double MSSCE_Yl_CM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);

  const TYPE MSSCE_jl_Yl_CM_ME = MSSCE_Yl_CM_ME*MSSCE_CM_radial_ME_jl;

  const TYPE MSSCE_jl_r_Yl_CM_ME = MSSCE_Yl_CM_ME*MSSCE_CM_radial_ME_jl_r;

  const int LCM_p_min = max (LCM - 1 , 0);

  const int LCM_p_max = LCM + 1;

  const unsigned int LCM_p_number = make_uns_int (LCM_p_max - LCM_p_min) + 1;

  class array<TYPE> e_tensor_Yl_CM_ME_tab(LCM_p_number);

  for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
    {
      const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

      const double e_tensor_Yl_CM_ME = Y1_norm_factor*YL1_tensor_YL2_reduced_in_l (LCM , 1 , LCM_p , LCM_projectile_in , LCM_projectile_out);

      e_tensor_Yl_CM_ME_tab(i_LCM_p) = e_tensor_Yl_CM_ME;
    }

  const class array<TYPE> MSSCE_CM_jl_r_e_tensor_Yl_CM_ME_tab =  MSSCE_jl_r_Yl_CM_ME*e_tensor_Yl_CM_ME_tab;

  const TYPE MSSCE_ME_jl_Yl_CM_all_intrinsic = static_cast<TYPE> (Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
												LCM_projectile_in , l_intrinsic , J_projectile_in , 
												LCM_projectile_out , l_intrinsic , J_projectile_out ,
												MSSCE_jl_Yl_CM_ME , MSSCE_all_intrinsic_NBME));

  const TYPE MSSCE_CM_hat_jl_Yl_CM_hat_jl_over_r_Yl_intrinsic = O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (LCM , l_intrinsic , L , 1 ,
														 LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
														 LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
														 MSSCE_CM_jl_r_e_tensor_Yl_CM_ME_tab , MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab);

  const TYPE MSSCE_sum = MSSCE_ME_jl_Yl_CM_all_intrinsic + MSSCE_CM_hat_jl_Yl_CM_hat_jl_over_r_Yl_intrinsic;

  return MSSCE_sum;
}







//--// return <uc_f lf jf || E_L || uc_i li ji>
TYPE CC_EM_transitions_MEs::cluster::magnetic::ME_reduced_calc (
								const int L , 
								const bool is_it_longwavelength_approximation ,
								const class CC_target_projectile_composite_data &Tpc_data , 
								const class array<class cluster_data> &cluster_data_tab , 
								const unsigned int iE , 
								const unsigned int iJPi_A_out , 
								const unsigned int ic , 
								const unsigned int icp , 
								const class CC_state_class &CC_state_in , 
								const class CC_state_class &CC_state_out , 
								const unsigned int ic_in , 
								const unsigned int ic_out)
{
  const unsigned int BP_Op = BP_EM_determine (MAGNETIC , L);

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const class array<TYPE> &EM_suboperator_intrinsic_NBMEs = Tpc_data.get_EM_suboperator_intrinsic_NBMEs ();

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out) == BP_Op)
    {
      const unsigned int SPIN_S_SCALAR_E_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_S_SCALAR_E);
      
      const unsigned int ORBITAL_GRADIENT_BESSEL_LP1_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_LP1);
      const unsigned int ORBITAL_GRADIENT_BESSEL_LM1_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_LM1);

      const unsigned int SPIN_GRADIENT_BESSEL_LP1_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_GRADIENT_BESSEL_LP1);
      const unsigned int SPIN_GRADIENT_BESSEL_LM1_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_GRADIENT_BESSEL_LM1);

      const unsigned int SPIN_GRADIENT_RICCATI_BESSEL_DER_LP1_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_LP1);
      const unsigned int SPIN_GRADIENT_RICCATI_BESSEL_DER_LM1_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_LM1);

      const unsigned int SPIN_S_SCALAR_E_RADIAL_index = radial_operator_type_index_determine (MAGNETIC_SPIN_S_SCALAR_E_RADIAL);

      const unsigned int GRADIENT_BESSEL_LP1_index = radial_operator_type_index_determine (GRADIENT_BESSEL_LP1);
      const unsigned int GRADIENT_BESSEL_LM1_index = radial_operator_type_index_determine (GRADIENT_BESSEL_LM1);

      const unsigned int GRADIENT_RICCATI_BESSEL_DER_LP1_index = radial_operator_type_index_determine (GRADIENT_RICCATI_BESSEL_DERIVATIVE_LP1);
      const unsigned int GRADIENT_RICCATI_BESSEL_DER_LM1_index = radial_operator_type_index_determine (GRADIENT_RICCATI_BESSEL_DERIVATIVE_LM1);

      const class cluster_data &data_c  = cluster_data_tab(ic);
      const class cluster_data &data_cp = cluster_data_tab(icp);

      const double J_intrinsic_in  = data_c.get_J_intrinsic ();
      const double J_intrinsic_out = data_cp.get_J_intrinsic ();

      const int l_intrinsic_min = abs (make_int (J_intrinsic_in - J_intrinsic_out));

      const int l_intrinsic_max = make_int (J_intrinsic_in + J_intrinsic_out);

      TYPE magnetic_ME = 0.0;

      for (int l_intrinsic = l_intrinsic_min ; l_intrinsic <= l_intrinsic_max ; l_intrinsic++)
	{	
	  const int lp_intrinsic_min = max (l_intrinsic - 1 , 0);

	  const int lp_intrinsic_max = l_intrinsic + 1;

	  const unsigned int lp_intrinsic_number   = make_uns_int (lp_intrinsic_max - lp_intrinsic_min) + 1;

	  const TYPE MOLP1INT_all_intrinsic_NBME = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_LP1_index          , GRADIENT_BESSEL_LP1_index);
	  const TYPE MOLM1INT_all_intrinsic_NBME = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_LM1_index          , GRADIENT_BESSEL_LM1_index);
	  const TYPE MSLP1INT_all_intrinsic_NBME = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , l_intrinsic , SPIN_GRADIENT_RICCATI_BESSEL_DER_LP1_index , GRADIENT_RICCATI_BESSEL_DER_LP1_index);
	  const TYPE MSLM1INT_all_intrinsic_NBME = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , l_intrinsic , SPIN_GRADIENT_RICCATI_BESSEL_DER_LM1_index , GRADIENT_RICCATI_BESSEL_DER_LM1_index);
	  const TYPE MSSCE_all_intrinsic_NBME    = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , l_intrinsic , SPIN_S_SCALAR_E_index                      , SPIN_S_SCALAR_E_RADIAL_index);

	  const TYPE MOLP1INT_intrinsic_NBME_jl_Yl           = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_LP1_index , GRADIENT_BESSEL_LP1_index);
	  const TYPE MOLM1INT_intrinsic_NBME_jl_Yl           = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_LM1_index , GRADIENT_BESSEL_LM1_index);
	  const TYPE MSLP1INT_intrinsic_NBME_jl_Yl_tensor_s  = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , l_intrinsic , SPIN_GRADIENT_BESSEL_LP1_index    , GRADIENT_BESSEL_LP1_index);
	  const TYPE MSLM1INT_intrinsic_NBME_jl_Yl_tensor_s  = EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , l_intrinsic , SPIN_GRADIENT_BESSEL_LM1_index    , GRADIENT_BESSEL_LM1_index);

	  class array<TYPE> MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab(lp_intrinsic_number);

	  magnetic::intrinsic_NBMEs_store (Tpc_data , iE , iJPi_A_out , ic , icp , L , l_intrinsic , MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab);

	  const int LCM_min_in_out = abs (LCM_projectile_in - LCM_projectile_out);

	  const int LCM_max_in_out = LCM_projectile_in + LCM_projectile_out;

	  const int LCM_min_l_intrinsic = abs (L - l_intrinsic);

	  const int LCM_max_l_intrinsic = L + l_intrinsic;

	  const int LCM_min_L = max (LCM_min_in_out , LCM_min_l_intrinsic);
	  const int LCM_max_L = min (LCM_max_in_out , LCM_max_l_intrinsic);

	  for (int LCM = LCM_min_L ; LCM <= LCM_max_L ; LCM++)
	    {
	      const double coupling_term = coupling_term_l_intrinsic_LCM (l_intrinsic , LCM , L);

	      const TYPE MOLP1INT_part = magnetic::orbital_gradient_ME_reduced_part_calc (is_it_longwavelength_approximation , 1 , l_intrinsic , LCM , L ,
											  CC_state_in , CC_state_out , ic_in , ic_out ,
											  MOLP1INT_all_intrinsic_NBME , MOLP1INT_intrinsic_NBME_jl_Yl);

	      const TYPE MOLM1INT_part = magnetic::orbital_gradient_ME_reduced_part_calc (is_it_longwavelength_approximation , -1 , l_intrinsic , LCM , L ,
											  CC_state_in , CC_state_out , ic_in , ic_out ,
											  MOLM1INT_all_intrinsic_NBME , MOLM1INT_intrinsic_NBME_jl_Yl);

	      const TYPE MSLP1INT_part = magnetic::spin_gradient_ME_reduced_calc (is_it_longwavelength_approximation , l_intrinsic , LCM , L ,
										  CC_state_in , CC_state_out , ic_in , ic_out ,
										  MSLP1INT_all_intrinsic_NBME , MSLP1INT_intrinsic_NBME_jl_Yl_tensor_s);

	      const TYPE MSLM1INT_part = magnetic::spin_gradient_ME_reduced_calc (is_it_longwavelength_approximation , l_intrinsic , LCM , L ,
										  CC_state_in , CC_state_out , ic_in , ic_out ,
										  MSLM1INT_all_intrinsic_NBME , MSLM1INT_intrinsic_NBME_jl_Yl_tensor_s);

	      const TYPE MSSCE_ME_part = magnetic::spin_s_scalar_e_ME_part_calc (is_it_longwavelength_approximation , l_intrinsic , LCM , L ,
										 CC_state_in , CC_state_out , ic_in , ic_out ,
										 MSSCE_all_intrinsic_NBME , MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab);

	      magnetic_ME += coupling_term*(MOLP1INT_part + MOLM1INT_part + MSLP1INT_part + MSLM1INT_part + MSSCE_ME_part);
	    }	
	}

      return magnetic_ME;
    }
  else
    return 0.0;
}











double CC_EM_transitions_MEs::cluster::coupling_term_l_intrinsic_LCM (const int l_intrinsic , const int LCM , const int L)
{
  const int phase = minus_one_pow ((l_intrinsic + LCM + L)/2);

  const double sqrt_four_Pi = 3.544907701811032;

  const double hats = hat (l_intrinsic)*hat (LCM);

  const double Wig_3j = Wigner_3j (LCM , l_intrinsic , L , 0 , 0 , 0);

  const double coupling_term = sqrt_four_Pi*phase*hats*Wig_3j;

  return coupling_term;
}








// return <uc_f lf jf || M/E_L || uc_i li ji>
TYPE CC_EM_transitions_MEs::cluster::ME_reduced_calc (
						      const enum EM_type EM , 
						      const int L , 
						      const bool is_it_longwavelength_approximation ,
						      const class CC_target_projectile_composite_data &Tpc_data , 
						      const class array<class cluster_data> &cluster_data_tab , 
						      const unsigned int iE , 
						      const unsigned int iJPi_A_out , 
						      const unsigned int ic ,  
						      const unsigned int icp ,  
						      const class CC_state_class &CC_state_in , 
						      const class CC_state_class &CC_state_out , 
						      const unsigned int ic_in , 
						      const unsigned int ic_out)
{
  switch (EM)
    {
    case ELECTRIC: return electric::ME_reduced_calc (L , is_it_longwavelength_approximation , Tpc_data , cluster_data_tab , iE , iJPi_A_out , ic , icp , CC_state_in , CC_state_out , ic_in , ic_out);

    case MAGNETIC: return magnetic::ME_reduced_calc (L , is_it_longwavelength_approximation , Tpc_data , cluster_data_tab , iE , iJPi_A_out , ic , icp , CC_state_in , CC_state_out , ic_in , ic_out);

    default: abort_all ();
    }

  return NADA;
}










