#include "../CC_include/CC_include_def.h"

using namespace string_routines;
using namespace correlated_state_routines;
using namespace inputs_misc;
using namespace Wigner_signs;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_scalar_strength_MEs;
using namespace CC_scalar_strength_MEs::radial_momentum;
using namespace CC_observables_common;

void CC_rms_radius_one_body_strength_poles::rms_radius_intrinsic_MEs_calc (
									   const class input_data_str &input_data , 
									   const enum operator_type rms_radius_op ,
									   const bool is_it_Gauss_Legendre , 
									   const class input_data_str &input_data_CC_Berggren ,  
									   const class array<double> &r_bef_R_tab , 
									   class array<class cluster_data> &cluster_projectile_data_tab , 
									   class CC_target_projectile_composite_data &Tpc_data ,
									   class GSM_vector &PSI_full)
{
  const enum interaction_type inter = input_data_CC_Berggren.get_inter ();
  
  const double mp = input_data_CC_Berggren.get_prot_mass_for_calc ();
  const double mn = input_data_CC_Berggren.get_neut_mass_for_calc ();
  
  const unsigned int cluster_number = cluster_projectile_data_tab.dimension (0);
  
  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();

  const int n_holes_max = Tpc_data.get_n_holes_max ();
  
  const int n_scat_max = Tpc_data.get_n_scat_max ();
      
  const int E_relative_max_hw = Tpc_data.get_E_relative_max_hw ();

  const class GSM_vector_helper_class dummy_helper;
  
  class array<TYPE> &rms_radius_intrinsic_NBMEs_strength = Tpc_data.get_scalar_intrinsic_NBMEs_strength ();

  rms_radius_intrinsic_NBMEs_strength = 0.0;

  const unsigned int N_bef_R_GL = input_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = input_data.get_N_bef_R_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
    
  class array<TYPE> strength_tab_fixed_channels(Nr);
  
  // cluster intrinsic state
  for (unsigned int icp = 0 ; icp < cluster_number ; icp++)
    {      
      class cluster_data &data_cp = cluster_projectile_data_tab(icp);
      
      class nucleons_data &cluster_prot_data_HO_cp = data_cp.get_cluster_prot_data_HO ();
      class nucleons_data &cluster_neut_data_HO_cp = data_cp.get_cluster_neut_data_HO ();

      const unsigned int BP_cp = data_cp.get_BP_intrinsic ();

      const double Jcp = data_cp.get_J_intrinsic ();

      const double Mcp = Jcp;
      
      const int Zcp_cluster = data_cp.get_Z_cluster ();
      const int Ncp_cluster = data_cp.get_N_cluster ();
      
      const int n_scat_max_p_cp = cluster_prot_data_HO_cp.get_n_scat_max ();
      const int n_scat_max_n_cp = cluster_neut_data_HO_cp.get_n_scat_max ();
      
      const int n_holes_max_p_cp = cluster_prot_data_HO_cp.get_n_holes_max ();
      const int n_holes_max_n_cp = cluster_neut_data_HO_cp.get_n_holes_max ();

      const int n_scat_max_cp = min (n_scat_max , n_scat_max_p_cp + n_scat_max_n_cp);
      
      const int Ep_max_hw_cp = cluster_prot_data_HO_cp.get_E_max_hw ();
      const int En_max_hw_cp = cluster_neut_data_HO_cp.get_E_max_hw ();
      
      const int E_min_hw_cp = cluster_prot_data_HO_cp.get_E_min_hw () + cluster_neut_data_HO_cp.get_E_min_hw ();
      const int E_max_hw_cp = E_relative_max_hw + E_min_hw_cp;

      const enum space_type space_cp = space_determine (Zcp_cluster , Ncp_cluster);

      const class correlated_state_str PSI_cluster_qn_cp (Zcp_cluster , Ncp_cluster , BP_cp , Jcp , 0 , NADA , NADA , NADA , NADA , false);

      class GSM_vector_helper_class PSI_cluster_helper_cp (false , space_cp , inter , false , truncation_hw , truncation_ph ,
							   n_holes_max      , n_scat_max_cp   , E_max_hw_cp , 
							   n_holes_max_p_cp , n_scat_max_p_cp , Ep_max_hw_cp ,
							   n_holes_max_n_cp , n_scat_max_n_cp , En_max_hw_cp , 
							   BP_cp , Mcp , true , cluster_prot_data_HO_cp , cluster_neut_data_HO_cp);

      class GSM_vector PSI_cluster_cp (PSI_cluster_helper_cp);

      PSI_cluster_cp.eigenvector_read_disk (true , true , PSI_cluster_qn_cp);

      for (unsigned int ic = 0 ; ic < cluster_number ; ic++)
	{
	  class cluster_data &data_c = cluster_projectile_data_tab(ic);
 
	  const int Zc_cluster = data_c.get_Z_cluster ();
	  const int Nc_cluster = data_c.get_N_cluster ();

	  if ((Zcp_cluster == Zc_cluster) && (Ncp_cluster == Nc_cluster))
	    {	      
	      const unsigned int BP_c = data_c.get_BP_intrinsic ();

	      const double Jc = data_c.get_J_intrinsic ();

	      const double Mc = Jc;

	      const double b_lab_cluster_c = data_c.get_b_lab_cluster ();
		  
	      if ((BP_c == BP_cp) && (make_int (Jc - Jcp) == 0))
		{
		  class nucleons_data &cluster_prot_data_HO_c = data_c.get_cluster_prot_data_HO ();
		  class nucleons_data &cluster_neut_data_HO_c = data_c.get_cluster_neut_data_HO ();		  
	
		  const int n_holes_max_p_c = cluster_prot_data_HO_c.get_n_holes_max ();
		  const int n_holes_max_n_c = cluster_neut_data_HO_c.get_n_holes_max ();
		  
		  const int n_scat_max_p_c = cluster_prot_data_HO_c.get_n_scat_max ();
		  const int n_scat_max_n_c = cluster_neut_data_HO_c.get_n_scat_max ();

		  const int n_scat_max_c = min (n_scat_max , n_scat_max_p_c + n_scat_max_n_c);
	  
		  const int Ep_max_hw_c = cluster_prot_data_HO_c.get_E_max_hw ();
		  const int En_max_hw_c = cluster_neut_data_HO_c.get_E_max_hw ();
		  
		  const int E_min_hw_c = cluster_prot_data_HO_c.get_E_min_hw () + cluster_neut_data_HO_c.get_E_min_hw ();
		  
		  const int E_max_hw_c = E_relative_max_hw + E_min_hw_c;

		  const enum space_type space_c = space_determine (Zc_cluster , Nc_cluster);

		  const enum particle_type cluster_c = data_c.get_cluster ();
		  
		  const class correlated_state_str PSI_cluster_qn_c (Zc_cluster , Nc_cluster , BP_c , Jc , 0 , NADA , NADA , NADA , NADA , false);

		  class GSM_vector_helper_class PSI_cluster_helper_c (false , space_c , inter , false , truncation_hw , truncation_ph ,
								      n_holes_max     , n_scat_max_c   , E_max_hw_c  , 
								      n_holes_max_p_c , n_scat_max_p_c , Ep_max_hw_c ,
								      n_holes_max_n_c , n_scat_max_n_c , En_max_hw_c , 
								      BP_c , Mc , true , cluster_prot_data_HO_c , cluster_neut_data_HO_c);

		  class GSM_vector PSI_cluster_c (PSI_cluster_helper_c);

		  PSI_cluster_c.eigenvector_read_disk (true , true , PSI_cluster_qn_c);
      
		  const double rms_radius_CM_factor = rms_radius_CM_factor_calc (rms_radius_op , cluster_c , mp , mn , Zc_cluster , Nc_cluster);
      
		  rms_radius_one_body_strength::calc_one_strength (rms_radius_op , is_it_Gauss_Legendre , PSI_full , PSI_cluster_c , PSI_cluster_cp ,
								   cluster_prot_data_HO_c , cluster_neut_data_HO_c , strength_tab_fixed_channels);

		  for (unsigned int i = 0 ; i < Nr ; i++)
		    {
		      const double r = r_bef_R_tab(i);

		      const double HO_0s_r = HO_wave_functions::HO_3D::u (b_lab_cluster_c , 0 , 0 , r);

		      const double HO_0s_r2_ME_r = HO_0s_r * HO_0s_r * r * r;

		      rms_radius_intrinsic_NBMEs_strength(ic , icp , i) = strength_tab_fixed_channels(i) - rms_radius_CM_factor*HO_0s_r2_ME_r;
		    }//loop Nr
		}//test BP J
	    }//test N Z clusters
	}//loop ic
    }//loop icp
  
#ifdef UseMPI
  if (is_it_MPI_parallelized) rms_radius_intrinsic_NBMEs_strength.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}










void CC_rms_radius_one_body_strength_poles::calc (
						  class GSM_vector &PSI_full, 
						  const enum operator_type rms_radius_op , 
						  const bool is_it_Gauss_Legendre , 
						  const bool is_it_nas_only ,
						  const class CC_target_projectile_composite_data &Tpc_data , 
						  const class input_data_str &input_data_CC_Berggren , 
						  const class interaction_class &inter_data_basis ,  
						  const class array<class cluster_data> &cluster_projectile_data_tab ,
						  const class CC_Hamiltonian_data &CC_H_data , 
						  const class CC_state_class &CC_state , 
						  class nucleons_data &prot_data , 
						  class nucleons_data &neut_data,
						  class array<TYPE> &strength_tab)
					 
{
  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();
  
  const bool full_common_vectors_used_in_file = input_data_CC_Berggren.get_full_common_vectors_used_in_file ();
 
  const bool is_it_one_nucleon_COSM_case = Tpc_data.get_is_it_one_nucleon_COSM_case ();

  const enum storage_type Hamiltonian_storage = input_data_CC_Berggren.get_Hamiltonian_storage ();

  const bool is_it_full_or_partial_storage = is_it_full_or_partial_storage_determine (Hamiltonian_storage);
  
  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();

  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();
  
  const unsigned int N_bef_R_GL = CC_state.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
  
  //=================== calculations of the beta matrix elts < J_i | Rrms^2 | J_f > ====================//

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const int Z_cluster_max = (!is_it_one_nucleon_COSM_case) ? (Z_cluster_max_determine (cluster_projectile_data_tab)) : (1);
  const int N_cluster_max = (!is_it_one_nucleon_COSM_case) ? (N_cluster_max_determine (cluster_projectile_data_tab)) : (1);

  const int Z_cluster_number = Z_cluster_max + 1;
  const int N_cluster_number = N_cluster_max + 1;

  class array<class nucleons_data> prot_data_one_projectile_less_tab(Z_cluster_number , N_cluster_number);
  class array<class nucleons_data> neut_data_one_projectile_less_tab(Z_cluster_number , N_cluster_number);
  
  data_one_projectile_less_alloc_calc (is_it_full_or_partial_storage , is_it_one_nucleon_COSM_case , TBME_inter , truncation_hw , truncation_ph , prot_data , neut_data ,
				       projectile_tab , cluster_projectile_data_tab , prot_data_one_projectile_less_tab , neut_data_one_projectile_less_tab);
  
  class array<TYPE> target_NBMEs(N_target_projectile_states , N_target_projectile_states , Nr);

  target_NBMEs = 0.0;
            
  composite::target_NBMEs_calc (PSI_full , TBME_inter , rms_radius_op , true , is_it_Gauss_Legendre , full_common_vectors_used_in_file , Tpc_data ,
				prot_data_one_projectile_less_tab , neut_data_one_projectile_less_tab , target_NBMEs);

  composite::CC_NBMEs_calc (PSI_full , rms_radius_op , true , is_it_Gauss_Legendre , Tpc_data , cluster_projectile_data_tab , is_it_nas_only , 
			    CC_H_data , CC_state , prot_data , neut_data , input_data_CC_Berggren , target_NBMEs , strength_tab);
}




void CC_rms_radius_one_body_strength_poles::calc_store (
							const class input_data_str &input_data , 
							const class input_data_str &input_data_CC_Berggren ,  
							const class interaction_class &inter_data_basis ,
							const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
							const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
							class nucleons_data &prot_data_CC_Berggren , 
							class nucleons_data &neut_data_CC_Berggren , 
							class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
							class nucleons_data &prot_data , 
							class nucleons_data &neut_data , 
							class array<class cluster_data> &cluster_projectile_data_tab , 
							class CC_target_projectile_composite_data &Tpc_data , 
							class TBMEs_class &TBMEs_pn)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "rms radius one-body strengths" << endl;
      cout <<         "-----------------------------" << endl << endl;
    }

  const int Z = input_data.get_Z ();
  const int N = input_data.get_N ();
  const int A = input_data.get_A ();

  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  //// if true , the L_min/max are put to the L value for the total cross section
  //// the interferences between different L values disappear due to the orthogonality of the Wigner D-matrices
  //const bool is_total_cross_section_calculated = input_data.get_CC_beta_is_total_cross_section_calculated;
  //const int L_for_total_cross_section = input_data.get_CC_beta_L_for_total_cross_section;

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_one_nucleon_COSM_case = Tpc_data.get_is_it_one_nucleon_COSM_case ();

  const unsigned int N_bef_R_uniform = input_data_CC_Berggren.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = input_data_CC_Berggren.get_N_aft_R_uniform ();

  const unsigned int N_bef_R_GL = input_data_CC_Berggren.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = input_data_CC_Berggren.get_N_aft_R_GL ();

  const unsigned int Nk_momentum_GL = input_data_CC_Berggren.get_Nk_momentum_GL ();
	
  const unsigned int Nk_momentum_uniform = input_data_CC_Berggren.get_Nk_momentum_uniform ();
  
  const double R_real_max = input_data_CC_Berggren.get_R_real_max ();

  const double R = input_data_CC_Berggren.get_R ();

  const double kmax_momentum = input_data_CC_Berggren.get_kmax_momentum ();

  const double R_Fermi_momentum = input_data_CC_Berggren.get_R_Fermi_momentum ();
  
  const double R0_inter = inter_data_basis.get_R0 ();

  const double R0 = 1.27*cbrt (A);

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);

  const class array<unsigned int> &N_channels_tab = Tpc_data.get_N_channels_tab ();

  const class array<unsigned int> &BP_A_tab = Tpc_data.get_BP_A_tab (); 

  const class array<double> &J_A_tab = Tpc_data.get_J_A_tab ();

  const class array<class CC_channel_class> &channels_tab = Tpc_data.get_channels_tab ();

  const unsigned int rms_radius_one_body_strength_number = input_data.get_rms_radius_one_body_strength_number ();

  const class array<unsigned int> &rms_radius_one_body_strength_BP_tab = input_data.get_rms_radius_one_body_strength_BP_tab ();

  const class array<double> &rms_radius_one_body_strength_J_tab = input_data.get_rms_radius_one_body_strength_J_tab ();

  const class array<unsigned int> &rms_radius_one_body_strength_vector_index_tab = input_data.get_rms_radius_one_body_strength_vector_index_tab ();

  const class array<enum particle_type> &rms_radius_one_body_strength_particle_tab = input_data.get_rms_radius_one_body_strength_particle_tab ();

  const class array<bool> &rms_radius_one_body_strength_is_it_Gauss_Legendre_tab = input_data.get_rms_radius_one_body_strength_is_it_Gauss_Legendre_tab ();
  
  const double step_bef_R_uniform = input_data_CC_Berggren.get_step_bef_R_uniform ();

  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);
  
  class array<double> r_bef_R_tab_uniform(N_bef_R_uniform);
  
  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;

  class GSM_vector PSI_full;
  
  for (unsigned int rms_radius_one_body_strength_index = 0 ; rms_radius_one_body_strength_index < rms_radius_one_body_strength_number ; rms_radius_one_body_strength_index++)
    {
      const enum particle_type particle = rms_radius_one_body_strength_particle_tab(rms_radius_one_body_strength_index);
 
      const bool is_it_Gauss_Legendre = rms_radius_one_body_strength_is_it_Gauss_Legendre_tab(rms_radius_one_body_strength_index);
      
      const unsigned int BP = rms_radius_one_body_strength_BP_tab(rms_radius_one_body_strength_index);

      const unsigned int vector_index = rms_radius_one_body_strength_vector_index_tab(rms_radius_one_body_strength_index);

      const double J = rms_radius_one_body_strength_J_tab(rms_radius_one_body_strength_index);

      const double M = J;
      
      class correlated_state_str PSI_qn(Z , N , BP , J , vector_index , NADA , NADA , NADA , NADA , false);

      const unsigned int iJPi = JPi_index_determine (BP_A_tab , J_A_tab , BP , J);
  
      const unsigned int N_channels_JPi = N_channels_tab(iJPi);
        
      // table of all channels for the given composite state

      class array<class CC_channel_class> channels_JPi_tab (N_channels_JPi);

      JPi_channels_tab_BP_J_vector_index_E_fill (channels_tab , BP , J , vector_index , NADA , channels_JPi_tab);
  
      class CC_state_class CC_state (is_it_one_nucleon_COSM_case , nmax_HO_lab_tab , cluster_projectile_data_tab , true , true , N_channels_JPi ,
				     NADA , channels_JPi_tab , N_bef_R_uniform , N_aft_R_uniform , N_bef_R_GL , N_aft_R_GL , Nk_momentum_uniform , Nk_momentum_GL ,
				     R , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , A , BP , J , M , vector_index , NADA);

      class CC_Hamiltonian_data CC_H_data(N_channels_JPi , input_data_CC_Berggren);
		
      CC_eigenstate_H_data_calc (Tpc_data , inter_data_basis , input_data_CC_Berggren , 
				 prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab , 
				 prot_data_CC_Berggren , neut_data_CC_Berggren , prot_data , neut_data , PSI_qn , TBMEs_pn , CC_H_data , CC_state);
       
      const enum operator_type rms_radius_op = rms_radius_operator_determine (particle);

      const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (r_bef_R_tab_GL) : (r_bef_R_tab_uniform);
 
      if (!is_it_one_nucleon_COSM_case)
	rms_radius_intrinsic_MEs_calc (input_data , rms_radius_op , is_it_Gauss_Legendre , input_data_CC_Berggren , r_bef_R_tab , cluster_projectile_data_tab , Tpc_data , PSI_full);

      const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
   
      class array<TYPE> rms_radius_one_body_strength_nas_tab(Nr);
      class array<TYPE> rms_radius_one_body_strength_as_tab(Nr);
      
      calc (PSI_full , rms_radius_op , is_it_Gauss_Legendre , true  , Tpc_data , input_data_CC_Berggren ,
	    inter_data_basis , cluster_projectile_data_tab , CC_H_data , CC_state , prot_data , neut_data , rms_radius_one_body_strength_nas_tab);
      
      calc (PSI_full , rms_radius_op , is_it_Gauss_Legendre , false , Tpc_data , input_data_CC_Berggren ,
	    inter_data_basis , cluster_projectile_data_tab , CC_H_data , CC_state , prot_data , neut_data , rms_radius_one_body_strength_as_tab);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  const string PSI_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_qn);

	  const string particle_str = (rms_radius_op == RMS_RADIUS_PROTON) ? ("proton") : ("neutron");
      
	  const string rms_radius_one_body_strength_string = "rms_radius_one_body_strength_" + particle_str + "_" + PSI_qn_string;

	  const string rms_radius_one_body_strength_nas_string = rms_radius_one_body_strength_string + "_non_antisymmetrized.dat";
	  const string rms_radius_one_body_strength_as_string  = rms_radius_one_body_strength_string + "_antisymmetrized.dat";

	  ofstream rms_radius_one_body_strength_nas_file(rms_radius_one_body_strength_nas_string.c_str() , ios::out);
	  ofstream rms_radius_one_body_strength_as_file (rms_radius_one_body_strength_as_string.c_str()  , ios::out);
	  	  
	  rms_radius_one_body_strength_nas_file.precision (15);
      	  rms_radius_one_body_strength_as_file.precision (15);
      
	  for (unsigned int i = 0 ; i < Nr ; i++)
	    {
	      const double r = r_bef_R_tab(i);

#ifdef TYPEisDOUBLECOMPLEX
	      rms_radius_one_body_strength_nas_file << r << " " << real (rms_radius_one_body_strength_nas_tab(i)) << " " << imag (rms_radius_one_body_strength_nas_tab(i)) << endl;
	      rms_radius_one_body_strength_as_file  << r << " " << real (rms_radius_one_body_strength_as_tab(i))  << " " << imag (rms_radius_one_body_strength_as_tab(i))  << endl;
#endif
	      
#ifdef TYPEisDOUBLE
	      rms_radius_one_body_strength_nas_file << r << " " << rms_radius_one_body_strength_nas_tab(i) << endl;
	      rms_radius_one_body_strength_as_file  << r << " " << rms_radius_one_body_strength_as_tab(i)  << endl;
#endif
	    }

	  rms_radius_one_body_strength_nas_file.close ();
	  rms_radius_one_body_strength_as_file.close ();
      
	  cout << "Non-antisymetrized and antisymmetrized rms radius one-body strength of " << J_Pi_vector_index_string (BP , J , vector_index) << " calculated and stored" << endl;
	}
    }
}


