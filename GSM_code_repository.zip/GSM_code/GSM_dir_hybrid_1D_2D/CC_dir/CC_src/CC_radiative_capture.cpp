#include "../CC_include/CC_include_def.h"


using namespace string_routines;
using namespace Wigner_signs;
using namespace EM_transitions;
using namespace inputs_misc;
using namespace EM_transitions;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_EM_transitions_MEs;
using namespace CC_EM_transitions_MEs::radial;
using namespace CC_observables_common;
using namespace CC_waves_HF_MSDHF_potentials_calculations;
using namespace configuration_SD_in_space_one_jump_out_to_in;














// TYPE is double or complex
// -------------------------





// EM is electromagnetic
// ---------------------

// E is for electric
// -----------------

// M is for magnetic
// -----------------









// Calculation and storage of the matrix elements <JT[f] || EM[target] || JT[i]>
// -----------------------------------------------------------------------------
// T is target.
// They enter the matrix elements <JT[f] c[f] || EM[target] || JT[i] c[i]> (see CC_EM_transitions_MEs_composite.cpp).
// They are calculated with shell model formulas as target states are GSM vectors.
//
// If one does not use long-wavelength approximation, matrix elements <JT[f] || EM[target] || JT[i]> depend on projectile energy.
// It is then too long to calculate them all. As they weakly depend on energy, they are calculated for 10 energies, and the rest comes from splines.

void CC_radiative_capture::target_reduced_NBMEs_calc (
						      class GSM_vector &PSI_full , 
						      const enum EM_type EM ,
						      const bool full_common_vectors_used_in_file ,
						      const class CC_target_projectile_composite_data &Tpc_data ,
						      const class interaction_class &inter_data_basis ,
						      class array<class baryons_data> &prot_Y_data_one_cluster_less_tab , 
						      class array<class baryons_data> &neut_Y_data_one_cluster_less_tab , 
						      const class array<TYPE> &CC_E_A_out_tab , 
						      class array<TYPE> &target_reduced_NBMEs)
{
  const enum interaction_type inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_longwavelength_approximation = Tpc_data.get_radiative_capture_is_it_longwavelength_approximation ();

  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();

  const int n_holes_max = Tpc_data.get_n_holes_max ();
  
  const int n_scat_max = Tpc_data.get_n_scat_max ();

  const int E_relative_max_hw = Tpc_data.get_E_relative_max_hw ();
  
  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();

  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();

  const class array<unsigned int> &BP_A_out_tab = Tpc_data.get_BP_A_out_tab ();
  
  const class array<double> &J_A_out_tab = Tpc_data.get_J_A_out_tab ();

  const unsigned int N_energies = Tpc_data.get_N_energies ();

  const unsigned int EM_index = EM_index_determine (EM);

  const class array<unsigned int> &BP_target_tab = Tpc_data.get_BP_target_tab ();

  const class array<double> &J_target_tab = Tpc_data.get_J_target_tab ();

  const class array<unsigned int> &vector_index_target_tab = Tpc_data.get_vector_index_target_tab ();

  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();

  const class array<TYPE> &E_target_tab =  Tpc_data.get_E_target_tab ();

  const class array<double> &E_total_tab = Tpc_data.get_E_total_tab ();

  const int L_for_radiative_capture_cross_section = Tpc_data.get_L_for_radiative_capture_cross_section ();

  const bool is_it_HO_expansion = Tpc_data.get_radiative_capture_is_it_HO_expansion ();
  
  const class GSM_vector_helper_class dummy_helper;
  
  target_reduced_NBMEs = 0.0;
  
  // "out" target state
  for (unsigned int iT_out = 0 ; iT_out < N_target_projectile_states ; iT_out++)
    {
      const unsigned int BP_target_out = BP_target_tab(iT_out);

      const unsigned int vector_index_target_out = vector_index_target_tab(iT_out);

      const double J_target_out = J_target_tab(iT_out);

      const double M_target_out = J_target_out;

      const TYPE E_target_out = E_target_tab(iT_out);

      const enum particle_type projectile_out = projectile_tab(iT_out);

      const int Z_projectile_out = Z_cluster_determine (projectile_out);
      const int N_projectile_out = N_cluster_determine (projectile_out);

      const int S_projectile_out = particle_strangeness_determine (projectile_out);
      
      const int Y_projectile_out = (S_projectile_out > 0) ? (1) : (0);
	  
      class baryons_data &prot_Y_data_target_out = prot_Y_data_one_cluster_less_tab(Z_projectile_out , N_projectile_out , Y_projectile_out);
      class baryons_data &neut_Y_data_target_out = neut_Y_data_one_cluster_less_tab(Z_projectile_out , N_projectile_out , Y_projectile_out);

      const int n_holes_max_p_target_out = prot_Y_data_target_out.get_n_holes_max ();
      const int n_holes_max_n_target_out = neut_Y_data_target_out.get_n_holes_max ();
            
      const int n_scat_max_p_target_out = prot_Y_data_target_out.get_n_scat_max ();
      const int n_scat_max_n_target_out = neut_Y_data_target_out.get_n_scat_max ();

      const int ZYval_target_out = prot_Y_data_target_out.get_N_valence_baryons ();
      const int NYval_target_out = neut_Y_data_target_out.get_N_valence_baryons ();

      if ((ZYval_target_out == 0) && (NYval_target_out == 0)) continue;
      
      const int n_scat_max_target_out_pn = n_scat_max_p_target_out + n_scat_max_n_target_out;
      
      const int n_scat_max_target_out = min (n_scat_max , n_scat_max_target_out_pn);

      const int Z_target_out = prot_Y_data_target_out.get_N_nucleons ();
      const int N_target_out = neut_Y_data_target_out.get_N_nucleons ();
      
      const int S_target_out = prot_Y_data_target_out.get_hypernucleus_strangeness ();

      const int Ep_max_hw_target_out = prot_Y_data_target_out.get_E_max_hw ();
      const int En_max_hw_target_out = neut_Y_data_target_out.get_E_max_hw ();
      
      const int Ep_min_hw_target_out = prot_Y_data_target_out.get_E_min_hw ();
      const int En_min_hw_target_out = neut_Y_data_target_out.get_E_min_hw ();

      const int E_min_hw_target_out = Ep_min_hw_target_out + En_min_hw_target_out;

      const int E_max_hw_target_out = E_relative_max_hw + E_min_hw_target_out;
      
      const enum space_type space_target_out = space_determine (ZYval_target_out , NYval_target_out);
      
      const class correlated_state_str PSI_target_out (Z_target_out , N_target_out , BP_target_out , S_target_out , J_target_out , vector_index_target_out , E_target_out , NADA , NADA , NADA , false);
        
      class GSM_vector_helper_class V_target_out_helper (is_it_MPI_parallelized , space_target_out , inter , false , truncation_hw , truncation_ph ,
							 n_holes_max              , n_scat_max_target_out   , E_max_hw_target_out  , 
							 n_holes_max_p_target_out , n_scat_max_p_target_out , Ep_max_hw_target_out ,
							 n_holes_max_n_target_out , n_scat_max_n_target_out , En_max_hw_target_out , 
							 BP_target_out , M_target_out , true , prot_Y_data_target_out , neut_Y_data_target_out);

      class GSM_vector V_target_out (V_target_out_helper);

      if (is_it_realistic_interaction (inter))
	V_target_out.eigenvector_read_disk (true , true , PSI_target_out);
      else
	V_target_out.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_target_out);
      	      
      // "in" target state
      for (unsigned int iT_in = 0 ; iT_in < N_target_projectile_states ; iT_in++)
	{
	  const unsigned int BP_target_in = BP_target_tab(iT_in);

	  const unsigned int vector_index_target_in = vector_index_target_tab(iT_in);

	  const double J_target_in = J_target_tab(iT_in);

	  const double M_target_in = J_target_in;

	  const TYPE E_target_in = E_target_tab(iT_in);

	  const enum particle_type projectile_in = projectile_tab(iT_in);
 
	  const int Z_projectile_in = Z_cluster_determine (projectile_in);
	  const int N_projectile_in = N_cluster_determine (projectile_in);

	  const int S_projectile_in = particle_strangeness_determine (projectile_in);
      
	  const int Y_projectile_in = (S_projectile_in > 0) ? (1) : (0);
	  
	  class baryons_data &prot_Y_data_target_in = prot_Y_data_one_cluster_less_tab(Z_projectile_in , N_projectile_in , Y_projectile_in);
	  class baryons_data &neut_Y_data_target_in = neut_Y_data_one_cluster_less_tab(Z_projectile_in , N_projectile_in , Y_projectile_in);

	  const int n_holes_max_p_target_in = prot_Y_data_target_in.get_n_holes_max ();
	  const int n_holes_max_n_target_in = neut_Y_data_target_in.get_n_holes_max ();
	  
	  const int n_scat_max_p_target_in = prot_Y_data_target_in.get_n_scat_max ();
	  const int n_scat_max_n_target_in = neut_Y_data_target_in.get_n_scat_max ();

	  const int ZYval_target_in = prot_Y_data_target_in.get_N_valence_baryons ();
	  const int NYval_target_in = neut_Y_data_target_in.get_N_valence_baryons ();

	  if ((ZYval_target_in == 0) && (NYval_target_in == 0)) continue;
	  
	  const int n_scat_max_target_in_pn = n_scat_max_p_target_in + n_scat_max_n_target_in;
      
	  const int n_scat_max_target_in = min (n_scat_max , n_scat_max_target_in_pn);
      
	  const int Z_target_in = prot_Y_data_target_in.get_N_nucleons ();
	  const int N_target_in = neut_Y_data_target_in.get_N_nucleons ();

	  const int S_target_in = prot_Y_data_target_in.get_hypernucleus_strangeness ();
	  
	  const int Ep_max_hw_target_in = prot_Y_data_target_in.get_E_max_hw ();
	  const int En_max_hw_target_in = neut_Y_data_target_in.get_E_max_hw ();
	  
	  const int Ep_min_hw_target_in = prot_Y_data_target_in.get_E_min_hw ();
	  const int En_min_hw_target_in = neut_Y_data_target_in.get_E_min_hw ();

	  const int E_min_hw_target_in = Ep_min_hw_target_in + En_min_hw_target_in;

	  const int E_max_hw_target_in = E_relative_max_hw + E_min_hw_target_in;

	  const enum space_type space_target_in = space_determine (ZYval_target_in , NYval_target_in);

	  const class correlated_state_str PSI_target_in (Z_target_in , N_target_in , BP_target_in , S_target_in , J_target_in , vector_index_target_in , E_target_in , NADA , NADA , NADA , false);

	  class GSM_vector_helper_class V_target_in_helper (is_it_MPI_parallelized , space_target_in , inter , false , truncation_hw , truncation_ph ,
							    n_holes_max             , n_scat_max_target_in   , E_max_hw_target_in  , 
							    n_holes_max_p_target_in , n_scat_max_p_target_in , Ep_max_hw_target_in ,
							    n_holes_max_n_target_in , n_scat_max_n_target_in , En_max_hw_target_in , 
							    BP_target_in , M_target_in , true , prot_Y_data_target_in , neut_Y_data_target_in);
	            
	  // deltas (is it the same projectile)
	  if ((space_target_in == space_target_out) && (projectile_in == projectile_out))
	    {
	      class GSM_vector V_target_in (V_target_in_helper);

	      if (is_it_realistic_interaction (inter))
		V_target_in.eigenvector_read_disk (true , true , PSI_target_in);
	      else
		V_target_in.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_target_in);

	      const int Lmin = abs (make_int (J_target_in - J_target_out));
	      const int Lmax =      make_int (J_target_in + J_target_out);

	      class baryons_data &prot_Y_data_target = prot_Y_data_target_in;
	      class baryons_data &neut_Y_data_target = neut_Y_data_target_in;

	      bool are_configuration_SD_in_space_one_jump_tables_calculated = false;
      
	      if (THIS_PROCESS == MASTER_PROCESS) cout << "Targets  : " << PSI_target_in << " -> " << PSI_target_out << endl;
	      
	      for (int L = Lmin ; L <= Lmax ; L++)
		{
		  if (L == L_for_radiative_capture_cross_section)
		    {
		      const unsigned int BP_EM = BP_EM_determine (EM , L);
		      
		      // delta (quantum numbers are conserved)
		      if ((binary_parity_product (BP_target_in , BP_EM) == BP_target_out))
			{
			  if (!are_configuration_SD_in_space_one_jump_tables_calculated)			    
			    {			      
			      class GSM_vector_helper_class V_target_in_full_helper;
			      
			      V_target_in_full_helper.allocate_fill_without_MPI_parallelization (V_target_in_helper);
			      
			      configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , true , false , false , false , V_target_in_full_helper , V_target_out_helper , dummy_helper ,
											   prot_Y_data_target , neut_Y_data_target);
			      
			      are_configuration_SD_in_space_one_jump_tables_calculated = true;			      
			    }
			  
			  if (is_it_longwavelength_approximation)
			    {
			      const TYPE target_reduced_NBME = B_amplitude_calc (EM , NADA , L , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data_basis , 
										 PSI_full , J_target_in , V_target_in , J_target_out , V_target_out);

			      if ((THIS_PROCESS == MASTER_PROCESS) && (target_reduced_NBME != 0.0))
				{
				  for (unsigned int iE = 0 ; iE < N_energies ; iE++)
				    for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
				      target_reduced_NBMEs(EM_index , iE , iJPi_A_out , iT_in , iT_out , L) = target_reduced_NBME;
				  
				  cout << "B(" << EM_letter_determine (EM) << L << ") amplitude calculated : " << target_reduced_NBME << endl;
				}
			    }//test is_it_longwavelength_approximation true
			  else
			    {
			      const unsigned int N_energies_splines = 10;
			      
			      const bool are_there_splines = (N_energies > N_energies_splines);

			      if (are_there_splines)
				{
				  class array<double> E_total_tab_for_splines(N_energies_splines);

				  class array<TYPE> target_reduced_NBMEs_for_splines   (N_energies_splines , N_JPi_A_out);				  
				  class array<TYPE> target_reduced_NBMEs_for_splines_1D(N_energies_splines);

				  target_reduced_NBMEs_for_splines = 0.0;

				  for (unsigned int iE = 0 ; iE < N_energies_splines ; iE++)
				    {
				      const double E_total_in_i_entrance = E_total_tab(iE);
				      
				      E_total_tab_for_splines(iE) = E_total_in_i_entrance;

				      for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
					{
					  const unsigned int BP_A_out = BP_A_out_tab(iJPi_A_out);

					  const double J_A_out = J_A_out_tab(iJPi_A_out);
      
					  const TYPE E_out = CC_E_A_out_tab(iJPi_A_out);

					  const TYPE q = (E_total_in_i_entrance - E_out) / hbar_c;

					  const TYPE target_reduced_NBME = B_amplitude_calc (EM , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data_basis , 
											     PSI_full , J_target_in , V_target_in , J_target_out , V_target_out);

					  if ((THIS_PROCESS == MASTER_PROCESS) && (target_reduced_NBME != 0.0))
					    {
					      target_reduced_NBMEs_for_splines(iE , iJPi_A_out) = target_reduced_NBME;

					      cout << "E[in entrance] : " << E_total_in_i_entrance << " Psi[out] : " << J_Pi_string (BP_A_out , J_A_out) << " E[out] : " << E_out
						   << "   B(" << EM_letter_determine (EM) << L << ") amplitude calculated for splines : " << target_reduced_NBME << endl;
					    }//test MASTER_PROCESS
					}//loop iJPi_A_out
				    }//loop iE

				  if (THIS_PROCESS == MASTER_PROCESS)
				    {
				      for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
					{
					  const unsigned int BP_A_out = BP_A_out_tab(iJPi_A_out);

					  const double J_A_out = J_A_out_tab(iJPi_A_out);
      
					  const TYPE E_out = CC_E_A_out_tab(iJPi_A_out);
					  
					  for (unsigned int iE = 0 ; iE < N_energies_splines ; iE++) target_reduced_NBMEs_for_splines_1D(iE) = target_reduced_NBMEs_for_splines(iE , iJPi_A_out);

					  if (target_reduced_NBMEs_for_splines_1D.infinite_norm () > 0)
					    {
					      const class splines_class<TYPE> target_reduced_NBMEs_splines(E_total_tab_for_splines , target_reduced_NBMEs_for_splines_1D); 

					      for (unsigned int iE = 0 ; iE < N_energies ; iE++)
						{
						  const double E_total_in_i_entrance = E_total_tab(iE);
					      
						  const TYPE target_reduced_NBME = target_reduced_NBMEs_splines(E_total_in_i_entrance);

						  target_reduced_NBMEs(EM_index , iE , iJPi_A_out , iT_in , iT_out , L) = target_reduced_NBME;
					      
						  cout << "E[in entrance] : " << E_total_in_i_entrance << " Psi[out] : " << J_Pi_string (BP_A_out , J_A_out) << " E[out] : " << E_out
						       << "   B(" << EM_letter_determine (EM) << L << ") amplitude calculated from splines : " << target_reduced_NBME << endl;
						}//loop iE
					    }//test target_reduced_NBMEs_for_splines_1D
					}//loop iJPi_A_out
				    }//test MASTER_PROCESS
				}//test are_there_splines
			      else
				{
				  for (unsigned int iE = 0 ; iE < N_energies ; iE++)
				    {
				      const double E_total_in_i_entrance = E_total_tab(iE);

				      for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
					{
					  const unsigned int BP_A_out = BP_A_out_tab(iJPi_A_out);

					  const double J_A_out = J_A_out_tab(iJPi_A_out);
      
					  const TYPE E_out = CC_E_A_out_tab(iJPi_A_out);

					  const TYPE q = (E_total_in_i_entrance - E_out) / hbar_c;

					  const TYPE target_reduced_NBME = B_amplitude_calc (EM , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data_basis , 
											     PSI_full , J_target_in , V_target_in , J_target_out , V_target_out);

					  if ((THIS_PROCESS == MASTER_PROCESS) && (target_reduced_NBME != 0.0))
					    { 
					      target_reduced_NBMEs(EM_index , iE , iJPi_A_out , iT_in , iT_out , L) = target_reduced_NBME;

					      cout << "E[in entrance] : " << E_total_in_i_entrance << " Psi[out] : " << J_Pi_string (BP_A_out , J_A_out) << " E[out] : " << E_out
						   << "   B(" << EM_letter_determine (EM) << L << ") amplitude amplitude calculated : " << target_reduced_NBME << endl;
					    }
					}//loop iJPi_A_out
				    }//loop iE
				}//test are_there_splines
			    }//test is_it_longwavelength_approximation false
			}//delta L
		    }//loop L total/diff cross section
		}//loop L
	      if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
	    }//deltas projectile
	}//loop iT_in
    }//loop iT_out

#ifdef UseMPI
  if (is_it_MPI_parallelized) target_reduced_NBMEs.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}





















// Calculation of the outgoing channel states of the considered radiative capture cross section
// --------------------------------------------------------------------------------------------
// They are pole states. They are usually bound, but can also be resonances (doorway states).
// In the latter case, outgoing resonances represent capture by many scattering states, which would be lengthy to compute.

void CC_radiative_capture::CC_state_out_tab_alloc_calc (
							const class CC_target_projectile_composite_data &Tpc_data , 
							const class interaction_class &inter_data_basis , 
							const class input_data_str &input_data_CC_Berggren , 
							const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
							const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
							const class array<class cluster_data> &cluster_projectile_data_tab , 
							class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
							class baryons_data &prot_Y_data_CC_Berggren , 
							class baryons_data &neut_Y_data_CC_Berggren , 
							class baryons_data &prot_Y_data , 
							class baryons_data &neut_Y_data , 
							class TBMEs_class &TBMEs_pn ,
							class TBMEs_class &TBMEs_cv ,
							class array<class CC_Hamiltonian_data> &CC_H_data_out_tab , 
							class array<class CC_state_class> &CC_state_out_tab , 
							class array<TYPE> &CC_E_A_out_tab)
{
  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  const enum interaction_type inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();

  const int A = prot_Y_data.get_A ();

  const int S = prot_Y_data.get_hypernucleus_strangeness ();

  const bool are_GSM_a_dagger_vectors_calculated = Tpc_data.get_are_GSM_a_dagger_vectors_calculated ();

  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();

  const unsigned int N_bef_R_uniform = input_data_CC_Berggren.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = input_data_CC_Berggren.get_N_aft_R_uniform ();

  const unsigned int N_bef_R_GL = input_data_CC_Berggren.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = input_data_CC_Berggren.get_N_aft_R_GL ();
  
  const unsigned int Nk_momentum_GL = input_data_CC_Berggren.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = input_data_CC_Berggren.get_Nk_momentum_uniform ();
  
  const double R_real_max = input_data_CC_Berggren.get_R_real_max ();

  const double R = input_data_CC_Berggren.get_R ();

  const double kmax_momentum = input_data_CC_Berggren.get_kmax_momentum ();

  const double R_Fermi_momentum = input_data_CC_Berggren.get_R_Fermi_momentum ();
  
  const double R0_inter = inter_data_basis.get_R0 ();

  const double R0 = 1.27*cbrt (A);
  
  const unsigned int iT_entrance = Tpc_data.get_entrance_target_index ();
  
  const class array<TYPE> &E_target_tab = Tpc_data.get_E_target_tab ();

  const TYPE E_total_out_start = E_target_tab(iT_entrance);
  
  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (inter);

  const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);
  
  const class array<unsigned int> &N_channels_out_tab = Tpc_data.get_N_channels_out_tab ();

  const class array<unsigned int> &BP_A_out_tab = Tpc_data.get_BP_A_out_tab ();

  const class array<double> &J_A_out_tab = Tpc_data.get_J_A_out_tab ();

  const class array<unsigned int> &vector_index_A_out_tab = Tpc_data.get_vector_index_A_out_tab ();

  const class array<class CC_channel_class> &channels_out_tab = Tpc_data.get_channels_out_tab ();

  for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
    {
      const unsigned int N_channels_JPi_A_out = N_channels_out_tab(iJPi_A_out);

      const unsigned int BP_A_out = BP_A_out_tab(iJPi_A_out);

      const double J_A_out = J_A_out_tab(iJPi_A_out);

      const double M_A_out = J_A_out;

      const int vector_index_A_out = vector_index_A_out_tab(iJPi_A_out);
      
      class array<class CC_channel_class> channels_JPi_A_out_tab (N_channels_JPi_A_out);

      JPi_channels_tab_BP_J_vector_index_E_fill (S , channels_out_tab , BP_A_out , J_A_out , vector_index_A_out , E_total_out_start , channels_JPi_A_out_tab);

      class HF_nucleons_data CC_prot_HF_data_out;
      class HF_nucleons_data CC_neut_HF_data_out;

      class baryons_data prot_Y_data_one_configuration_GSM_out;
      class baryons_data neut_Y_data_one_configuration_GSM_out;
      
      if (is_it_one_baryon_COSM_case)
	{
	  class baryons_data CC_prot_Y_data_out;
	  class baryons_data CC_neut_Y_data_out;
	  
	  baryons_data_initialization (true , input_data_CC_Berggren , CC_prot_Y_data_out , CC_neut_Y_data_out);
	  
	  const int lp_max_out = CC_prot_Y_data_out.get_lmax ();
	  const int ln_max_out = CC_neut_Y_data_out.get_lmax ();

	  class lj_table<bool> prot_OCM_valence_state_out_tab(0.5 , lp_max_out);
	  class lj_table<bool> neut_OCM_valence_state_out_tab(0.5 , ln_max_out);
	  
	  OCM_valence_state_tab_fill (CC_prot_Y_data_out , prot_OCM_valence_state_out_tab);
	  OCM_valence_state_tab_fill (CC_neut_Y_data_out , neut_OCM_valence_state_out_tab);

	  is_it_OCM_HO_core_determine (input_data_CC_Berggren , CC_prot_Y_data_out , CC_neut_Y_data_out);

	  const class lj_table<int> &prot_n_min_valence_out_tab = prot_HF_data_CC_Berggren.get_nmin_lj_valence_tab ();
	  const class lj_table<int> &neut_n_min_valence_out_tab = neut_HF_data_CC_Berggren.get_nmin_lj_valence_tab (); 

	  prepare_CC_prot_neut_Y_data (channels_JPi_A_out_tab , true , prot_n_min_valence_out_tab , neut_n_min_valence_out_tab , prot_OCM_valence_state_out_tab , neut_OCM_valence_state_out_tab , CC_prot_Y_data_out , CC_neut_Y_data_out);

	  CC_prot_HF_data_out.allocate (input_data_CC_Berggren , CC_prot_Y_data_out);
	  CC_neut_HF_data_out.allocate (input_data_CC_Berggren , CC_neut_Y_data_out);

	  CC_state_calc_preparation (
				     prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
				     prot_Y_data_one_configuration_GSM_out , neut_Y_data_one_configuration_GSM_out , CC_prot_HF_data_out , CC_neut_HF_data_out);
	}
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << endl;

      class array<complex<double> > Ueq_out_tab (N_channels_JPi_A_out , N_channels_JPi_A_out , N_bef_R_uniform);

      class array<complex<double> > source_out_tab (N_channels_JPi_A_out , N_bef_R_uniform);

      const unsigned int ic_entrance = 0;
      
      class CC_state_class &CC_state_out = CC_state_out_tab(iJPi_A_out);
      
      class CC_Hamiltonian_data &CC_H_data_out = CC_H_data_out_tab(iJPi_A_out);
      
      CC_state_out.allocate (is_it_one_baryon_COSM_case , nmax_HO_lab_tab , cluster_projectile_data_tab , true , true , N_channels_JPi_A_out ,
			     ic_entrance , channels_JPi_A_out_tab , N_bef_R_uniform , N_aft_R_uniform , N_bef_R_GL , N_aft_R_GL , Nk_momentum_uniform , Nk_momentum_GL ,  
			     R , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , A , BP_A_out , J_A_out , M_A_out , vector_index_A_out , E_total_out_start);

      CC_H_data_out.allocate (N_channels_JPi_A_out , input_data_CC_Berggren);
      
       
      CC_H_data_out.dimension_matrices_independent_data_realloc_init (is_it_one_baryon_COSM_case , input_data_CC_Berggren , inter_data_basis , channels_JPi_A_out_tab , 
								      prot_Y_data , neut_Y_data , cluster_projectile_data_tab , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , cluster_projectile_data_CC_Berggren_tab);	

      CC_H_data_out.corrective_factors_average_n_scat_target_projectile_max_read (input_data_CC_Berggren);

      CC_H_data_out.HO_wfs_Gaussian_tables_calc (R , R_real_max , channels_JPi_A_out_tab , inter_data_basis);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  cout << "Calculation of outgoing state " << J_Pi_vector_index_string (BP_A_out , J_A_out , vector_index_A_out) << endl;
	  cout << "---------------------------------------------------------------------------------------------------------------------" << endl;
	}

      CC_state_iterative_calc (Tpc_data , true , are_GSM_a_dagger_vectors_calculated , input_data_CC_Berggren , inter_data_basis , 
			       prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , prot_Y_data_one_configuration_GSM_out , neut_Y_data_one_configuration_GSM_out , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab , 
			       prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , prot_Y_data , neut_Y_data , TBMEs_pn , TBMEs_cv , CC_prot_HF_data_out , CC_neut_HF_data_out , CC_H_data_out , CC_state_out);

      const complex<double> CC_state_out_E = CC_state_out.get_E ();

      CC_E_A_out_tab(iJPi_A_out) = generate_scalar<TYPE> (real_dc (CC_state_out_E) , imag_dc (CC_state_out_E));

      if (is_it_one_baryon_COSM_case)
	{
	  HF_wave_function::waves_deallocate (CC_prot_HF_data_out);
	  HF_wave_function::waves_deallocate (CC_neut_HF_data_out);
	}
    }
}










// Calculation of the incoming channel states of the considered radiative capture cross section
// --------------------------------------------------------------------------------------------
// They are scattering states. Energy is fixed therein.

void CC_radiative_capture::CC_state_in_entrance_tab_alloc_calc ( 
								const class CC_target_projectile_composite_data &Tpc_data , 
								const class interaction_class &inter_data_basis , 
								const class input_data_str &input_data_CC_Berggren ,
								const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
								const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
								const class array<class cluster_data> &cluster_projectile_data_tab , 
								class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
								const unsigned int iE , 
								const TYPE &E , 
								class baryons_data &prot_Y_data_CC_Berggren , 
								class baryons_data &neut_Y_data_CC_Berggren , 
								class baryons_data &prot_Y_data , 
								class baryons_data &neut_Y_data , 
								class TBMEs_class &TBMEs_pn ,
								class TBMEs_class &TBMEs_cv ,
								class array<class CC_Hamiltonian_data> &CC_H_data_in_tab , 
								class array<class CC_state_class> &CC_state_in_entrance_tab)
{
  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  // All a+_(nc lc jc tau_c)|Tc> vectors have been calculated in CC_state_out_tab_alloc_calc , so are_GSM_a_dagger_vectors_calculated is put to false in this routine.

  const int S = prot_Y_data.get_hypernucleus_strangeness ();
  
  const enum interaction_type inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();
  
  const unsigned int N_JPi_A_in = Tpc_data.get_N_JPi_A_in ();

  const unsigned int N_bef_R_uniform = input_data_CC_Berggren.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = input_data_CC_Berggren.get_N_aft_R_uniform ();

  const unsigned int N_bef_R_GL = input_data_CC_Berggren.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = input_data_CC_Berggren.get_N_aft_R_GL ();
  
  const unsigned int Nk_momentum_GL = input_data_CC_Berggren.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = input_data_CC_Berggren.get_Nk_momentum_uniform ();
  
  const int A = input_data_CC_Berggren.get_A ();
  
  const double R_real_max = input_data_CC_Berggren.get_R_real_max ();

  const double R = input_data_CC_Berggren.get_R ();

  const double kmax_momentum = input_data_CC_Berggren.get_kmax_momentum ();

  const double R_Fermi_momentum = input_data_CC_Berggren.get_R_Fermi_momentum ();
  
  const double R0_inter = inter_data_basis.get_R0 ();

  const double R0 = 1.27*cbrt (A);
  
  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (inter);

  const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);

  const class array<unsigned int> &N_channels_in_tab = Tpc_data.get_N_channels_in_tab ();

  const class array<double> &J_A_in_tab = Tpc_data.get_J_A_in_tab ();

  const class array<unsigned int> &BP_A_in_tab = Tpc_data.get_BP_A_in_tab ();

  const class array<unsigned int> &N_entrance_channels_in_tab = Tpc_data.get_N_entrance_channels_tab ();

  const class array<unsigned int> &entrance_JPi_channels_indices = Tpc_data.get_entrance_JPi_channels_indices ();

  const class array<class CC_channel_class> &channels_in_tab = Tpc_data.get_channels_in_tab ();

  for (unsigned int iJPi_A_in = 0 ; iJPi_A_in < N_JPi_A_in ; iJPi_A_in++)
    {
      const unsigned int N_channels_JPi_A_in = N_channels_in_tab(iJPi_A_in);

      const unsigned int N_entrance_channels = N_entrance_channels_in_tab(iJPi_A_in);

      const unsigned int BP_A_in = BP_A_in_tab(iJPi_A_in);
      
      const double J_A_in = J_A_in_tab(iJPi_A_in);

      const double M_A_in = J_A_in;

      class array<class CC_channel_class> channels_JPi_A_in_tab (N_channels_JPi_A_in);

      JPi_channels_tab_BP_J_E_fill (S , channels_in_tab , BP_A_in , J_A_in , E , channels_JPi_A_in_tab);

      class HF_nucleons_data CC_prot_HF_data_in;
      class HF_nucleons_data CC_neut_HF_data_in;

      class baryons_data prot_Y_data_one_configuration_GSM_in;
      class baryons_data neut_Y_data_one_configuration_GSM_in;
 
      if (is_it_one_baryon_COSM_case)
	{
	  class baryons_data CC_prot_Y_data_in;
	  class baryons_data CC_neut_Y_data_in;

	  baryons_data_initialization (true , input_data_CC_Berggren , CC_prot_Y_data_in , CC_neut_Y_data_in);

	  const int lp_max_in = CC_prot_Y_data_in.get_lmax ();
	  const int ln_max_in = CC_neut_Y_data_in.get_lmax ();

	  class lj_table<bool> prot_OCM_valence_state_in_tab(0.5 , lp_max_in);
	  class lj_table<bool> neut_OCM_valence_state_in_tab(0.5 , ln_max_in);

	  OCM_valence_state_tab_fill (CC_prot_Y_data_in , prot_OCM_valence_state_in_tab);
	  OCM_valence_state_tab_fill (CC_neut_Y_data_in , neut_OCM_valence_state_in_tab);

	  is_it_OCM_HO_core_determine (input_data_CC_Berggren , CC_prot_Y_data_in , CC_neut_Y_data_in);

	  const class lj_table<int> &prot_n_min_valence_in_tab = prot_HF_data_CC_Berggren.get_nmin_lj_valence_tab ();
	  const class lj_table<int> &neut_n_min_valence_in_tab = neut_HF_data_CC_Berggren.get_nmin_lj_valence_tab (); 

	  prepare_CC_prot_neut_Y_data (channels_JPi_A_in_tab , false , prot_n_min_valence_in_tab , neut_n_min_valence_in_tab , prot_OCM_valence_state_in_tab , neut_OCM_valence_state_in_tab , CC_prot_Y_data_in , CC_neut_Y_data_in);
	  
	  CC_prot_HF_data_in.allocate (input_data_CC_Berggren , CC_prot_Y_data_in);
	  CC_neut_HF_data_in.allocate (input_data_CC_Berggren , CC_neut_Y_data_in);
	  
	  CC_state_calc_preparation (
				     prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
				     prot_Y_data_one_configuration_GSM_in , neut_Y_data_one_configuration_GSM_in , CC_prot_HF_data_in , CC_neut_HF_data_in);
	}
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << endl;

      class CC_Hamiltonian_data &CC_H_data_in = CC_H_data_in_tab(iJPi_A_in);
      
      CC_H_data_in.allocate (N_channels_JPi_A_in , input_data_CC_Berggren);
      
      CC_H_data_in.dimension_matrices_independent_data_realloc_init (is_it_one_baryon_COSM_case , input_data_CC_Berggren , inter_data_basis , channels_JPi_A_in_tab , 
								     prot_Y_data , neut_Y_data , cluster_projectile_data_tab , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , cluster_projectile_data_CC_Berggren_tab);	

      CC_H_data_in.corrective_factors_average_n_scat_target_projectile_max_read (input_data_CC_Berggren);

      CC_H_data_in.HO_wfs_Gaussian_tables_calc (R , R_real_max , channels_JPi_A_in_tab , inter_data_basis);

      for (unsigned int i_entrance = 0 ; i_entrance < N_entrance_channels ; i_entrance++)
	{
	  const bool are_GSM_a_dagger_vectors_calculated = ((iE == 0) && (i_entrance == 0)) ? (Tpc_data.get_are_GSM_a_dagger_vectors_calculated ()) : (false);
	  
	  const unsigned int ic_JPi_A_in_entrance = entrance_JPi_channels_indices(iJPi_A_in , i_entrance);
	  
	  const class CC_channel_class &entrance_channel = channels_JPi_A_in_tab(ic_JPi_A_in_entrance);

	  if (THIS_PROCESS == MASTER_PROCESS)
	    {
	      cout << endl;

	      cout << "Calculation of incoming state " << J_Pi_string (BP_A_in , J_A_in) << endl;
	      cout << "---------------------------------------------------------------------------------------------------------------------" << endl;

	      cout << "Energy index : " << iE << endl;

	      if (is_it_realistic_interaction (inter))
		cout << "E[CM] : " << E << " MeV" << endl;
	      else
		cout << "E[COSM] : " << E << " MeV" << endl;
	      
	      cout << "Entrance channel : " << entrance_channel << endl;
	    }

	  // incoming state
	  class CC_state_class &CC_state_in_entrance = CC_state_in_entrance_tab(iJPi_A_in , i_entrance);
	  	  
	  CC_state_in_entrance.allocate (is_it_one_baryon_COSM_case , nmax_HO_lab_tab , cluster_projectile_data_tab , false , true , N_channels_JPi_A_in ,
					 ic_JPi_A_in_entrance , channels_JPi_A_in_tab , N_bef_R_uniform , N_aft_R_uniform , N_bef_R_GL , N_aft_R_GL , Nk_momentum_uniform , Nk_momentum_GL ,
					 R , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , A , BP_A_in , J_A_in , M_A_in , NADA , E);
	    
	  CC_state_iterative_calc (Tpc_data , true , are_GSM_a_dagger_vectors_calculated , input_data_CC_Berggren , inter_data_basis , 
				   prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , prot_Y_data_one_configuration_GSM_in , neut_Y_data_one_configuration_GSM_in , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab , 
				   prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , prot_Y_data , neut_Y_data , TBMEs_pn , TBMEs_cv , CC_prot_HF_data_in , CC_neut_HF_data_in , CC_H_data_in , CC_state_in_entrance);
	}//loop i_entrance

      if (is_it_one_baryon_COSM_case)
	{
	  HF_wave_function::waves_deallocate (CC_prot_HF_data_in);
	  HF_wave_function::waves_deallocate (CC_neut_HF_data_in);
	}
    }//loop on iJPi_A_in (J_i and M_i)
}





// Calculation of the EM matrix elements between incoming and outgoing channel states of the considered radiative capture cross section
// ------------------------------------------------------------------------------------------------------------------------------------
// Energy is fixed here, as well as the entrance channel of the incoming scattering state and the outgoing resonant state.
// The entrance channel arises from the partial wave decomposition of the plane wave of the incoming projectile (or quasi-plane wave for charged projectiles) at large distance.
// as and nas are for antisymmetrized or non-antisymmetrized channels (see CC_EM_transitions_MEs_composite.cpp).

void CC_radiative_capture::CC_EM_NBMEs_calc_fixed_out_in_entrance (
								   class GSM_vector &PSI_full , 
								   const class CC_target_projectile_composite_data &Tpc_data , 
								   const class array<class cluster_data> &cluster_projectile_data_tab , 
								   const class input_data_str &input_data_CC_Berggren , 
								   const bool is_it_nas_only , 
								   const unsigned int iJPi_A_in , 
								   const unsigned int iJPi_A_out , 
								   const enum EM_type EM_for_radiative_capture_cross_section , 
								   const unsigned int i_entrance , 
								   const unsigned int iE , 
								   const class CC_Hamiltonian_data &CC_H_data_in , 
								   const class CC_state_class &CC_state_in_i_entrance , 
								   const class CC_Hamiltonian_data &CC_H_data_out ,  
								   const class CC_state_class &CC_state_out , 
								   class baryons_data &prot_Y_data , 
								   class baryons_data &neut_Y_data ,
								   const class interaction_class &inter_data_basis ,	 
								   const class array<TYPE> &target_reduced_NBMEs , 
								   class array<TYPE> &CC_EM_NBMEs)
{
  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();
  
  const class array<unsigned int> &BP_A_in_tab  = Tpc_data.get_BP_A_in_tab ();
  const class array<unsigned int> &BP_A_out_tab = Tpc_data.get_BP_A_out_tab ();
  
  const class array<double> &J_A_in_tab  = Tpc_data.get_J_A_in_tab ();
  const class array<double> &J_A_out_tab = Tpc_data.get_J_A_out_tab ();

  const class array<unsigned int> &vector_index_A_out_tab = Tpc_data.get_vector_index_A_out_tab ();

  const unsigned int BP_A_in  = BP_A_in_tab(iJPi_A_in);
  const unsigned int BP_A_out = BP_A_out_tab(iJPi_A_out);
  
  const double J_A_in  = J_A_in_tab(iJPi_A_in);
  const double J_A_out = J_A_out_tab(iJPi_A_out);

  const unsigned int vector_index_A_out = vector_index_A_out_tab(iJPi_A_out);
  
  const int L_for_radiative_capture_cross_section = Tpc_data.get_L_for_radiative_capture_cross_section ();

  const int Lmin = abs (make_int (J_A_in - J_A_out));
  const int Lmax =      make_int (J_A_in + J_A_out);

  const bool is_it_longwavelength_approximation = Tpc_data.get_radiative_capture_is_it_longwavelength_approximation ();

  const bool is_it_HO_expansion = Tpc_data.get_radiative_capture_is_it_HO_expansion ();
    
  const unsigned int as_index = (is_it_nas_only) ? (0) : (1);

  const unsigned int EM_for_radiative_capture_cross_section_index = EM_index_determine (EM_for_radiative_capture_cross_section);

  //entrance channel index

  const class array<class CC_channel_class> &channels_tab_JPi_A_in = CC_state_in_i_entrance.get_channels_tab ();

  const unsigned int ic_entrance = CC_state_in_i_entrance.get_ic_entrance ();

  class array<TYPE> target_reduced_NBMEs_EM_E_L_fixed(N_target_projectile_states , N_target_projectile_states);
        
  // Angular momentum conservation during EM transition included
  for (int L = Lmin ; L <= Lmax ; L++)
    {
      if (L == L_for_radiative_capture_cross_section)
	{
	  // E0 transition cannot occur
	  if (L != 0)
	    {
	      const unsigned int BP_EM = BP_EM_determine (EM_for_radiative_capture_cross_section , L);

	      if (binary_parity_product (BP_EM , BP_A_in) == BP_A_out)
		{
		  for (unsigned int iT_in = 0 ; iT_in < N_target_projectile_states ; iT_in++)
		    for (unsigned int iT_out = 0 ; iT_out < N_target_projectile_states ; iT_out++)
		      target_reduced_NBMEs_EM_E_L_fixed(iT_in , iT_out) = target_reduced_NBMEs(EM_for_radiative_capture_cross_section_index , iE , iJPi_A_out , iT_in , iT_out , L);			
		      
		  CC_EM_NBMEs(as_index , EM_for_radiative_capture_cross_section_index , iJPi_A_in , iJPi_A_out , i_entrance , L , iE) = 
		    composite::CC_NBME_calc (EM_for_radiative_capture_cross_section , L , is_it_longwavelength_approximation , is_it_HO_expansion , iE , iJPi_A_out , Tpc_data ,
					     cluster_projectile_data_tab , is_it_nas_only , CC_H_data_in , CC_state_in_i_entrance , CC_H_data_out , CC_state_out ,
					     prot_Y_data , neut_Y_data , inter_data_basis , input_data_CC_Berggren , target_reduced_NBMEs_EM_E_L_fixed , PSI_full);

		  if ((THIS_PROCESS == MASTER_PROCESS) && (binary_parity_product (BP_EM , BP_A_in) == BP_A_out)) 
		    cout << "out : " << J_Pi_string (BP_A_out , J_A_out) << " " << vector_index_A_out << " , in : " << J_Pi_string (BP_A_in , J_A_in) 
			 << " , entrance channel : " << channels_tab_JPi_A_in(ic_entrance) << " " << EM_for_radiative_capture_cross_section << L << " : "
			 << CC_EM_NBMEs(as_index , EM_for_radiative_capture_cross_section_index , iJPi_A_in , iJPi_A_out , i_entrance , L , iE) << endl;
		}//test parity
	    }//if L!=0
	}//condition on L
    }//loop L
}








// Calculation of the EM matrix elements between all incoming and outgoing channel states of the considered radiative capture cross section
// ----------------------------------------------------------------------------------------------------------------------------------------
// Energy is fixed here.
// as and nas are for antisymmetrized or non-antisymmetrized channels (see CC_EM_transitions_MEs_composite.cpp).

void CC_radiative_capture::CC_EM_NBMEs_calc (
					     class GSM_vector &PSI_full , 
					     const class CC_target_projectile_composite_data &Tpc_data , 
					     const class array<class cluster_data> &cluster_projectile_data_tab , 
					     const bool is_it_nas_only , 
					     const enum EM_type EM , 
					     const class array<TYPE> &target_reduced_NBMEs , 
					     const class input_data_str &input_data_CC_Berggren , 
					     const class interaction_class &inter_data_basis , 
					     class baryons_data &prot_Y_data , 
					     class baryons_data &neut_Y_data , 
					     const unsigned int iE , 
					     const double E_kinetic_total_system_CM ,
					     const class array<class CC_Hamiltonian_data> &CC_H_data_out_tab , 
					     const class array<class CC_state_class> &CC_state_out_tab ,
					     const class array<class CC_Hamiltonian_data> &CC_H_data_in_tab ,  
					     const class array<class CC_state_class> &CC_state_in_entrance_tab , 
					     class array<TYPE> &CC_EM_NBMEs)
{
  const unsigned int N_JPi_A_in  = Tpc_data.get_N_JPi_A_in ();
  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();
  
  const class array<unsigned int> &N_entrance_channels_in_tab = Tpc_data.get_N_entrance_channels_tab ();

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      if (is_it_nas_only)
	{
	  cout << endl << endl << "Non-antisymmetrized   E.kinetic.total.system[CM] : " << E_kinetic_total_system_CM << " MeV" << endl;
	  cout << "---------------------------------------------------------------------------------------------------------------------------------------------------"<< endl;
	}
      else
	{
	  cout << endl << endl << "Antisymmetrized   E.kinetic.total.system[CM] : " << E_kinetic_total_system_CM << " MeV" << endl;
	  cout << "---------------------------------------------------------------------------------------------------------------------------------------------------"<< endl;
	}
    }
      
  for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
    {	
      // final state

      const class CC_state_class &CC_state_out = CC_state_out_tab(iJPi_A_out);

      const class CC_Hamiltonian_data &CC_H_data_out = CC_H_data_out_tab(iJPi_A_out);
      
      for (unsigned int iJPi_A_in = 0 ; iJPi_A_in < N_JPi_A_in ; iJPi_A_in++)
	{
	  const unsigned int N_entrance_channels = N_entrance_channels_in_tab(iJPi_A_in);

	  const class CC_Hamiltonian_data &CC_H_data_in = CC_H_data_in_tab(iJPi_A_in);
      
	  for (unsigned int i_entrance = 0 ; i_entrance < N_entrance_channels ; i_entrance++)
	    {
	      // incoming state
	      const class CC_state_class &CC_state_in_entrance = CC_state_in_entrance_tab(iJPi_A_in , i_entrance);

	      //fill the CC_EM_NBMEs
	      CC_EM_NBMEs_calc_fixed_out_in_entrance (PSI_full , Tpc_data , cluster_projectile_data_tab , input_data_CC_Berggren , is_it_nas_only , iJPi_A_in , iJPi_A_out , EM , i_entrance , iE , 
						      CC_H_data_in , CC_state_in_entrance , CC_H_data_out ,  CC_state_out , prot_Y_data , neut_Y_data , inter_data_basis ,
						      target_reduced_NBMEs , CC_EM_NBMEs);

	    }//loop i_entrance
	}//loop on iJPi_A_in (J_i and M_i)
    }//loop on iJPi_A_out (J_f and M_f)
}































// Calculation of the reduced EM matrix elements for a given suboperator between the intrinsic parts of all clusters
// -----------------------------------------------------------------------------------------------------------------
// One calculates <PSI[intrinsic-cluster-c'] || EM[intrinsic] || PSI[intrinsic-cluster-c]>.
// |PSI[intrinsic-cluster-c or intrinsic-cluster-c']> is the intrinsic wave function of the considered cluster c or c' projectile.
// For example, one has |PSI[cluster-c]> = [|N[HO-CM] L[CM]> |PSI[intrinsic-cluster-c]>]^JM, where CM is the center of mass of the projectile.
//
// To calculate <PSI[intrinsic-cluster-c'] || EM[intrinsic] || PSI[intrinsic-cluster-c]>, one uses the decomposition EM = sum_{EM'} couplings_EM' EM'[CM].EM'[intrinsic] (see the book for formulas).
// Using HO shell model with the Lawson method, one has |PSI-HO[cluster-c]> = |0s CM> |PSI[intrinsic-cluster-c]>.
// Thus, <PSI-HO[cluster-c'] || EM' || PSI-HO[cluster-c]> = <PSI[intrinsic-cluster-c'] || EM'[intrinsic] || PSI[intrinsic-cluster-c]>.<0s CM | EM'[CM] | 0s CM>.<recoupling terms>
// <PSI-HO[cluster-c'] || EM || PSI-HO[cluster-c]> is given by shell model formulas and <0s CM | EM'[CM] | 0s CM> is analytical.
// <PSI[intrinsic-cluster-c'] || EM[intrinsic] || PSI[intrinsic-cluster-c]> can then be retrieved from previous values.
//
// If one does not use long-wavelength approximation, matrix elements <PSI[intrinsic-cluster-c'] || EM[intrinsic] || PSI[intrinsic-cluster-c]> depend on projectile energy.
// It is then too long to calculate them all. As they weakly depend on energy, they are calculated for 10 energies, and the rest comes from splines.

void CC_radiative_capture::EM_suboperators_intrinsic_MEs_calc (
							       const class interaction_class &inter_data_basis , 
							       class array<class cluster_data> &cluster_projectile_data_tab , 
							       const class array<TYPE> &CC_E_A_out_tab , 
							       class CC_target_projectile_composite_data &Tpc_data ,
							       class GSM_vector &PSI_full)
{
  const enum interaction_type inter = inter_data_basis.get_TBME_inter ();
    
  const unsigned int EM_suboperator_number = EM_suboperator_type_number_determine ();

  const unsigned int cluster_number = cluster_projectile_data_tab.dimension (0);

  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();

  const class array<double> &J_A_out_tab = Tpc_data.get_J_A_out_tab ();

  const class array<unsigned int> &BP_A_out_tab = Tpc_data.get_BP_A_out_tab ();
  
  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();

  const class array<double> &E_total_tab = Tpc_data.get_E_total_tab ();

  const int n_holes_max = Tpc_data.get_n_holes_max ();
  
  const int n_scat_max = Tpc_data.get_n_scat_max ();
      
  const int E_relative_max_hw = Tpc_data.get_E_relative_max_hw ();

  const unsigned int N_energies = Tpc_data.get_N_energies ();

  const bool is_it_HO_expansion = Tpc_data.get_radiative_capture_is_it_HO_expansion ();

  const bool is_it_longwavelength_approximation = Tpc_data.get_radiative_capture_is_it_longwavelength_approximation ();
     
  const class GSM_vector_helper_class dummy_helper;

  const double J_intrinsic_max = Jmax_intrinsic_cluster_determine ();

  const int l_intrinsic_max = make_int (2.0*J_intrinsic_max);
	    
  class array<TYPE> &EM_suboperator_intrinsic_NBMEs = Tpc_data.get_EM_suboperator_intrinsic_NBMEs ();
  
  EM_suboperator_intrinsic_NBMEs = 0.0;
  
  // cluster intrinsic state
  for (unsigned int icp = 0 ; icp < cluster_number ; icp++)
    {      
      class cluster_data &data_cp = cluster_projectile_data_tab(icp);

      class baryons_data &cluster_prot_Y_data_HO_cp = data_cp.get_cluster_prot_Y_data_HO ();
      class baryons_data &cluster_neut_Y_data_HO_cp = data_cp.get_cluster_neut_Y_data_HO ();

      const unsigned int BP_cp = data_cp.get_BP_intrinsic ();

      const int Scp = data_cp.get_S_intrinsic ();

      const double Jcp = data_cp.get_J_intrinsic ();

      const unsigned int vector_index_intrinsic_cp = data_cp.get_vector_index_intrinsic ();
      
      const double Mcp = Jcp;

      const int Zcp_cluster = data_cp.get_Z_cluster ();
      const int Ncp_cluster = data_cp.get_N_cluster ();

      const int n_holes_max_p_cp = cluster_prot_Y_data_HO_cp.get_n_holes_max ();
      const int n_holes_max_n_cp = cluster_neut_Y_data_HO_cp.get_n_holes_max ();
      
      const int n_scat_max_p_cp = cluster_prot_Y_data_HO_cp.get_n_scat_max ();
      const int n_scat_max_n_cp = cluster_neut_Y_data_HO_cp.get_n_scat_max ();

      const int n_scat_max_cp = min (n_scat_max , n_scat_max_p_cp + n_scat_max_n_cp);
      
      const int Ep_max_hw_cp = cluster_prot_Y_data_HO_cp.get_E_max_hw ();
      const int En_max_hw_cp = cluster_neut_Y_data_HO_cp.get_E_max_hw ();
      
      const int Ep_min_hw_cp = cluster_prot_Y_data_HO_cp.get_E_min_hw ();
      const int En_min_hw_cp = cluster_neut_Y_data_HO_cp.get_E_min_hw ();
      
      const int E_min_hw_cp = Ep_min_hw_cp + En_min_hw_cp;

      const int E_max_hw_cp = E_relative_max_hw + E_min_hw_cp;

      const enum space_type space_cp = space_determine (Zcp_cluster , Ncp_cluster);

      const class correlated_state_str PSI_cluster_qn_cp (Zcp_cluster , Ncp_cluster , BP_cp , Scp , Jcp , vector_index_intrinsic_cp , NADA , NADA , NADA , NADA , false);

      class GSM_vector_helper_class PSI_cluster_helper_cp (false , space_cp , inter , false , truncation_hw , truncation_ph ,
							   n_holes_max      , n_scat_max_cp   , E_max_hw_cp  , 
							   n_holes_max_p_cp , n_scat_max_p_cp , Ep_max_hw_cp ,
							   n_holes_max_n_cp , n_scat_max_n_cp , En_max_hw_cp , 
							   BP_cp , Mcp , true , cluster_prot_Y_data_HO_cp , cluster_neut_Y_data_HO_cp);

      class GSM_vector PSI_cluster_cp (PSI_cluster_helper_cp);

      PSI_cluster_cp.eigenvector_read_disk (true , true , PSI_cluster_qn_cp);
	    
      for (unsigned int ic = 0 ; ic < cluster_number ; ic++)
	{
	  class cluster_data &data_c = cluster_projectile_data_tab(ic);
 
	  const int Zc_cluster = data_c.get_Z_cluster ();
	  const int Nc_cluster = data_c.get_N_cluster ();

	  if ((Zcp_cluster == Zc_cluster) && (Ncp_cluster == Nc_cluster))
	    {
	      class baryons_data &cluster_prot_Y_data_HO_c = data_c.get_cluster_prot_Y_data_HO ();
	      class baryons_data &cluster_neut_Y_data_HO_c = data_c.get_cluster_neut_Y_data_HO ();
		  
	      const unsigned int BP_c = data_c.get_BP_intrinsic ();

	      const int Sc = data_c.get_S_intrinsic ();
	
	      const double Jc = data_c.get_J_intrinsic ();

	      const unsigned int vector_index_intrinsic_c = data_c.get_vector_index_intrinsic ();
	
	      const double Mc = Jc;
	      
	      const int n_holes_max_p_c = cluster_prot_Y_data_HO_c.get_n_holes_max ();
	      const int n_holes_max_n_c = cluster_neut_Y_data_HO_c.get_n_holes_max ();
		  
	      const int n_scat_max_p_c = cluster_prot_Y_data_HO_c.get_n_scat_max ();
	      const int n_scat_max_n_c = cluster_neut_Y_data_HO_c.get_n_scat_max ();

	      const int n_scat_max_c = min (n_scat_max , n_scat_max_p_c + n_scat_max_n_c);
	  
	      const int Ep_max_hw_c = cluster_prot_Y_data_HO_c.get_E_max_hw ();
	      const int En_max_hw_c = cluster_neut_Y_data_HO_c.get_E_max_hw ();
		  
	      const int Ep_min_hw_c = cluster_prot_Y_data_HO_c.get_E_min_hw ();
	      const int En_min_hw_c = cluster_neut_Y_data_HO_c.get_E_min_hw ();
		  
	      const int E_min_hw_c = Ep_min_hw_c + En_min_hw_c;

	      const int E_max_hw_c = E_relative_max_hw + E_min_hw_c;

	      const enum space_type space_c = space_determine (Zc_cluster , Nc_cluster);

	      const class correlated_state_str PSI_cluster_qn_c (Zc_cluster , Nc_cluster , BP_c , Sc , Jc , vector_index_intrinsic_c , NADA , NADA , NADA , NADA , false);

	      class GSM_vector_helper_class PSI_cluster_helper_c (false , space_c , inter , false , truncation_hw , truncation_ph ,
								  n_holes_max     , n_scat_max_c   , E_max_hw_c  , 
								  n_holes_max_p_c , n_scat_max_p_c , Ep_max_hw_c ,
								  n_holes_max_n_c , n_scat_max_n_c , En_max_hw_c , 
								  BP_c , Mc , true , cluster_prot_Y_data_HO_c , cluster_neut_Y_data_HO_c);

	      class GSM_vector PSI_cluster_c (PSI_cluster_helper_c);

	      PSI_cluster_c.eigenvector_read_disk (true , true , PSI_cluster_qn_c);
		  		  
	      bool are_configuration_SD_in_space_one_jump_tables_calculated = false;
	           
	      if (THIS_PROCESS == MASTER_PROCESS) cout << "Clusters  : " << PSI_cluster_qn_c << " -> " << PSI_cluster_qn_cp << endl;
	      
	      for (int L = 0 ; L <= l_intrinsic_max ; L++)
		{ 
		  for (unsigned int EM_suboperator_index = 0 ; EM_suboperator_index < EM_suboperator_number ; EM_suboperator_index++)
		    {
		      const enum EM_suboperator_type EM_suboperator = EM_suboperator_type_from_index (EM_suboperator_index);

		      if (is_EM_suboperator_identically_zero_determine (is_it_longwavelength_approximation , EM_suboperator)) continue;
		      
		      const unsigned int BP_EM = BP_EM_suboperator_determine (EM_suboperator , L);
		      
		      // delta (quantum numbers are conserved)
  
		      if (binary_parity_product (BP_c , BP_cp) == BP_EM)
			{
			  if (!are_configuration_SD_in_space_one_jump_tables_calculated)
			    {
			      class GSM_vector_helper_class PSI_cluster_helper_c_full;
			      
			      PSI_cluster_helper_c_full.allocate_fill_without_MPI_parallelization (PSI_cluster_helper_c);
			      
			      configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , true , false , false , false ,
											   PSI_cluster_helper_c_full , PSI_cluster_helper_cp , dummy_helper ,
											   cluster_prot_Y_data_HO_c , cluster_neut_Y_data_HO_c);
			      
			      are_configuration_SD_in_space_one_jump_tables_calculated = true;			      
			    }
			  			      
			  if (is_it_longwavelength_approximation)
			    {
			      const TYPE EM_suboperators_intrinsic_NBME = cluster::EM_suboperator_intrinsic_NBME_calc (EM_suboperator , NADA , L , 
														       is_it_longwavelength_approximation , is_it_HO_expansion , inter_data_basis ,
														       data_c , data_cp , PSI_cluster_c , PSI_cluster_cp ,
														       PSI_full);

			      if ((THIS_PROCESS == MASTER_PROCESS) && (EM_suboperators_intrinsic_NBME != 0.0))
				{
				  for (unsigned int iE = 0 ; iE < N_energies ; iE++)
				    for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
				      EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , EM_suboperator_index) = EM_suboperators_intrinsic_NBME;
				      
				  cout << EM_suboperator << " L:" << L << " "<< " intrinsic NBME calculated : " << EM_suboperators_intrinsic_NBME << endl;
				}
			    }//test is_it_longwavelength_approximation true
			  else
			    {
			      const unsigned int N_energies_splines = 10;
				      
			      const bool are_there_splines = (N_energies > N_energies_splines);

			      if (are_there_splines)
				{
				  class array<double> E_total_tab_for_splines(N_energies_splines);

				  class array<TYPE> EM_suboperator_intrinsic_NBMEs_for_splines   (N_energies_splines , N_JPi_A_out);
				  class array<TYPE> EM_suboperator_intrinsic_NBMEs_for_splines_1D(N_energies_splines);

				  EM_suboperator_intrinsic_NBMEs_for_splines = 0.0;

				  for (unsigned int iE = 0 ; iE < N_energies_splines ; iE++)
				    {
				      const double E_total_in_i_entrance = E_total_tab(iE);

				      for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
					{
					  const unsigned int BP_A_out = BP_A_out_tab(iJPi_A_out);
					      
					  const double J_A_out = J_A_out_tab(iJPi_A_out);
					      
					  const TYPE E_out = CC_E_A_out_tab(iJPi_A_out);
					      
					  const TYPE q = (E_total_in_i_entrance - E_out) / hbar_c;
					      
					  const TYPE EM_suboperators_intrinsic_NBME = cluster::EM_suboperator_intrinsic_NBME_calc (EM_suboperator , q , L , is_it_longwavelength_approximation , 
																   is_it_HO_expansion , inter_data_basis , data_c , data_cp , PSI_cluster_c , PSI_cluster_cp , PSI_full);

					  if ((THIS_PROCESS == MASTER_PROCESS) && (EM_suboperators_intrinsic_NBME != 0.0))
					    {
					      EM_suboperator_intrinsic_NBMEs_for_splines(iE , iJPi_A_out) = EM_suboperators_intrinsic_NBME;

					      cout << EM_suboperator << " L:" << L << " "<< " E[in entrance] : " << E_total_in_i_entrance
						   << " Psi[out] : " << J_Pi_string (BP_A_out , J_A_out) << " E[out] : " << E_out << "  intrinsic NBME calculated for splines : " << EM_suboperators_intrinsic_NBME << endl;
					    }
					}//loop iJPi_A_out
				    }//loop iE

				  if (THIS_PROCESS == MASTER_PROCESS)
				    {
				      for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
					{
					  const unsigned int BP_A_out = BP_A_out_tab(iJPi_A_out);

					  const double J_A_out = J_A_out_tab(iJPi_A_out);
					      
					  const TYPE E_out = CC_E_A_out_tab(iJPi_A_out);
      
					  for (unsigned int iE = 0 ; iE < N_energies_splines ; iE++) EM_suboperator_intrinsic_NBMEs_for_splines_1D(iE) = EM_suboperator_intrinsic_NBMEs_for_splines(iE , iJPi_A_out);

					  if (EM_suboperator_intrinsic_NBMEs_for_splines_1D.infinite_norm () > 0)
					    {
					      const class splines_class<TYPE> EM_suboperator_intrinsic_NBMEs_splines(E_total_tab_for_splines , EM_suboperator_intrinsic_NBMEs_for_splines_1D); 

					      for (unsigned int iE = 0 ; iE < N_energies ; iE++)
						{
						  const double E_total_in_i_entrance = E_total_tab(iE);

						  const TYPE EM_suboperators_intrinsic_NBME = EM_suboperator_intrinsic_NBMEs_splines(E_total_in_i_entrance);

						  EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , EM_suboperator_index) = EM_suboperators_intrinsic_NBME;
						  
						  cout << EM_suboperator << " L:" << L << " "<< " E[in entrance] : " << E_total_in_i_entrance << " Psi[out] : " << J_Pi_string (BP_A_out , J_A_out) << " E[out] : " << E_out
						       << "  intrinsic NBME calculated from splines : " << EM_suboperators_intrinsic_NBME << endl;
						}//loop iE
					    }//test EM_suboperator_intrinsic_NBMEs_for_splines_1D
					}//loop iJPi_A_out
				    }//test MASTER_PROCESS
				}//test are_there_splines
			      else
				{
				  for (unsigned int iE = 0 ; iE < N_energies ; iE++)
				    {
				      const double E_total_in_i_entrance = E_total_tab(iE);
					      
				      for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
					{
					  const unsigned int BP_A_out = BP_A_out_tab(iJPi_A_out);
					      
					  const double J_A_out = J_A_out_tab(iJPi_A_out);
					      
					  const TYPE E_out = CC_E_A_out_tab(iJPi_A_out);

					  const TYPE q = (E_total_in_i_entrance - E_out) / hbar_c;
						  
					  const TYPE EM_suboperators_intrinsic_NBME = cluster::EM_suboperator_intrinsic_NBME_calc (EM_suboperator , q , L , is_it_longwavelength_approximation ,
																   is_it_HO_expansion , inter_data_basis , data_c , data_cp , PSI_cluster_c , PSI_cluster_cp , PSI_full);
						  
					  if ((THIS_PROCESS == MASTER_PROCESS) && (EM_suboperators_intrinsic_NBME != 0.0))
					    { 
					      EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , EM_suboperator_index) = EM_suboperators_intrinsic_NBME;
						  
					      cout << EM_suboperator << " L:" << L << " "<< " E[in entrance] : " << E_total_in_i_entrance << " Psi[out] : " << J_Pi_string (BP_A_out , J_A_out) << " E[out] : " << E_out
						   << "  intrinsic NBME calculated : " << EM_suboperators_intrinsic_NBME << endl;
					    }
					}//loop iJPi_A_out
				    }//loop iE
				}//test are_there_splines
			    }//test is_it_longwavelength_approximation false
			}//loop test BP
		    }//loop EM_suboperator_index
		}//loop L
	      if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
	    }//test Z N cluster
	}//loop ic
    }//loop icp
    
#ifdef UseMPI
  if (is_it_MPI_parallelized) EM_suboperator_intrinsic_NBMEs.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}
  








// Calculation of the EM matrix elements between all incoming and outgoing channel states of the considered radiative capture cross section for all energies
// ---------------------------------------------------------------------------------------------------------------------------------------------------------

void CC_radiative_capture::iterative_calc (
					   const class CC_target_projectile_composite_data &Tpc_data , 
					   const class input_data_str &input_data_CC_Berggren , 
					   const class interaction_class &inter_data_basis , 
					   const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
					   const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
					   const class array<class cluster_data> &cluster_projectile_data_tab , 
					   class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
					   class baryons_data &prot_Y_data_CC_Berggren , 
					   class baryons_data &neut_Y_data_CC_Berggren , 		
					   class baryons_data &prot_Y_data , 
					   class baryons_data &neut_Y_data , 
					   class TBMEs_class &TBMEs_pn , 
					   class TBMEs_class &TBMEs_cv , 
					   class array<TYPE> &CC_E_A_out_tab , 
					   class array<TYPE> &CC_EM_NBMEs , 
					   class GSM_vector &PSI_full)
{
  cout.precision (15);
  
  const enum interaction_type inter = inter_data_basis.get_TBME_inter ();
  
  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();
  
  const unsigned int N_JPi_A_in  = Tpc_data.get_N_JPi_A_in ();
  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();

  const unsigned int N_entrance_channels_max = Tpc_data.get_N_entrance_channels_max ();

  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();

  const unsigned int N_energies = Tpc_data.get_N_energies ();
  
  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();

  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();

  const enum storage_type Hamiltonian_storage = input_data_CC_Berggren.get_Hamiltonian_storage ();

  const bool is_it_full_or_partial_storage = is_it_full_or_partial_storage_determine (Hamiltonian_storage);
  
  const enum EM_type EM_for_radiative_capture_cross_section = Tpc_data.get_EM_for_radiative_capture_cross_section ();
    
  const bool full_common_vectors_used_in_file = input_data_CC_Berggren.get_full_common_vectors_used_in_file ();

  const class array<double> &J_A_in_tab  = Tpc_data.get_J_A_in_tab ();
  const class array<double> &J_A_out_tab = Tpc_data.get_J_A_out_tab ();
  
  const double Jmax_all_in  = J_A_in_tab.max ();
  const double Jmax_all_out = J_A_out_tab.max ();
  
  const int Lmax_all = make_int (Jmax_all_in + Jmax_all_out);

  const int Lmax_all_plus_one = Lmax_all + 1;
  
  const class array<double> &E_total_tab = Tpc_data.get_E_total_tab ();

  const class array<double> &E_kinetic_total_system_CM_tab = Tpc_data.get_E_kinetic_total_system_CM_tab ();

  const int Z_cluster_max = (!is_it_one_baryon_COSM_case) ? (Z_cluster_max_determine (cluster_projectile_data_tab)) : (1);
  const int N_cluster_max = (!is_it_one_baryon_COSM_case) ? (N_cluster_max_determine (cluster_projectile_data_tab)) : (1);
      
  const int Z_cluster_number = Z_cluster_max + 1;
  const int N_cluster_number = N_cluster_max + 1;

  class array<class baryons_data> prot_Y_data_one_cluster_less_tab(Z_cluster_number , N_cluster_number , 2);
  class array<class baryons_data> neut_Y_data_one_cluster_less_tab(Z_cluster_number , N_cluster_number , 2);

  data_one_projectile_less_alloc_calc (is_it_full_or_partial_storage , is_it_one_baryon_COSM_case , inter , truncation_hw , truncation_ph , prot_Y_data , neut_Y_data , projectile_tab ,
				       cluster_projectile_data_tab , prot_Y_data_one_cluster_less_tab , neut_Y_data_one_cluster_less_tab);

  class array<class CC_state_class> CC_state_out_tab(N_JPi_A_out);
      
  class array<class CC_Hamiltonian_data> CC_H_data_in_tab (N_JPi_A_in);
  class array<class CC_Hamiltonian_data> CC_H_data_out_tab(N_JPi_A_out);
      
  CC_state_out_tab_alloc_calc (Tpc_data , inter_data_basis , input_data_CC_Berggren , 
			       prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab ,
			       prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , prot_Y_data , neut_Y_data , TBMEs_pn , TBMEs_cv , CC_H_data_out_tab , CC_state_out_tab , CC_E_A_out_tab);

  class array<TYPE> target_reduced_NBMEs(2 , N_energies , N_JPi_A_out , N_target_projectile_states , N_target_projectile_states , Lmax_all_plus_one);
  
  target_reduced_NBMEs = 0.0;
  
  target_reduced_NBMEs_calc (PSI_full , EM_for_radiative_capture_cross_section , full_common_vectors_used_in_file , Tpc_data , inter_data_basis ,
			     prot_Y_data_one_cluster_less_tab , neut_Y_data_one_cluster_less_tab , CC_E_A_out_tab , target_reduced_NBMEs);
    
  for (unsigned int iE = 0 ; iE < N_energies ; iE++)
    {
      const double E_total = E_total_tab(iE);

      const double E_kinetic_total_system_CM = E_kinetic_total_system_CM_tab(iE);

      class array<class CC_state_class> CC_state_in_entrance_tab(N_JPi_A_in , N_entrance_channels_max);
     
      CC_state_in_entrance_tab_alloc_calc (Tpc_data , inter_data_basis , input_data_CC_Berggren , 
					   prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab , iE , E_total ,
					   prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , prot_Y_data , neut_Y_data , TBMEs_pn , TBMEs_cv , CC_H_data_in_tab , CC_state_in_entrance_tab);

      CC_EM_NBMEs_calc (PSI_full , Tpc_data , cluster_projectile_data_tab , true , EM_for_radiative_capture_cross_section , target_reduced_NBMEs , input_data_CC_Berggren , inter_data_basis , prot_Y_data , neut_Y_data , 
			iE , E_kinetic_total_system_CM , CC_H_data_out_tab , CC_state_out_tab , CC_H_data_in_tab , CC_state_in_entrance_tab , CC_EM_NBMEs);
      
      CC_EM_NBMEs_calc (PSI_full , Tpc_data , cluster_projectile_data_tab , false , EM_for_radiative_capture_cross_section , target_reduced_NBMEs , input_data_CC_Berggren , inter_data_basis , prot_Y_data , neut_Y_data , 
			iE , E_kinetic_total_system_CM , CC_H_data_out_tab , CC_state_out_tab , CC_H_data_in_tab , CC_state_in_entrance_tab , CC_EM_NBMEs);
    }
}








// Angular matrix elements entering the radiative capture cross section
// --------------------------------------------------------------------
// See book for formulas.

complex<double> CC_radiative_capture::angular_factor_calc (
							   const int L , 
							   const double M_L , 
							   const int P , 
							   const double k_cross_section , 
							   const double k_gamma , 
							   const double theta_gamma , 
							   const double phi_gamma)
{
  const complex<double> I (0.0 , 1.0);

  const complex<double> I_pow_L = pow (I , L);

  const double sqrt_factor = sqrt (2.0 * M_PI * (2.0 * L + 1.0) * (L + 1.0) / L);

  const double k_factor = pow (k_gamma , L) / k_cross_section;

  const double factorial_factor = P / double_factorial (2.0 * L + 1);

  const complex<double> Wigner_D_matrix_elt = Wigner_D (L , M_L , P , phi_gamma , theta_gamma , 0.0);

  const complex<double> angular_factor = I_pow_L * sqrt_factor * k_factor * factorial_factor * Wigner_D_matrix_elt;

  return angular_factor;
}

void CC_radiative_capture::angular_factor_tabs_calc (
						     const double k_cross_section , 
						     const double E_i , 
						     const class array<TYPE> &CC_E_A_out_tab , 
						     const class array<double> &theta_gamma_tab , 
						     const class array<double> &phi_gamma_tab , 
						     class array<complex<double> > &angular_factor_plus_tab , 
						     class array<complex<double> > &angular_factor_minus_tab)
{
  const unsigned int N_JPi_A = angular_factor_plus_tab.dimension (0);

  const unsigned int N_theta_gamma = angular_factor_plus_tab.dimension (3);

  const unsigned int N_phi_gamma = angular_factor_plus_tab.dimension (4);

  const int Lmax_all = angular_factor_plus_tab.dimension (1) - 1;

  const int iM_Lmax_all = 2 * Lmax_all;

  for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A ; iJPi_A_out++)
    {
      const double E_A_out = real_dc (CC_E_A_out_tab(iJPi_A_out));

      // momentum of the emitted photon
      const double k_gamma = (E_i - E_A_out) / hbar_c;

      for (int L = 1 ; L <= Lmax_all ; L++) 
	{
	  for (int iM_L = 0 ; iM_L <= iM_Lmax_all ; iM_L++)
	    {
	      const int M_L = iM_L - Lmax_all;	
	      for (unsigned int theta_gamma_index = 0 ; theta_gamma_index < N_theta_gamma ; theta_gamma_index++)
		{
		  const double theta_gamma = theta_gamma_tab(theta_gamma_index);

		  for (unsigned int phi_gamma_index = 0 ; phi_gamma_index < N_phi_gamma ; phi_gamma_index++)
		    {
		      const double phi_gamma = phi_gamma_tab(phi_gamma_index);

		      angular_factor_plus_tab(iJPi_A_out , L , iM_L , theta_gamma_index , phi_gamma_index) = 
			angular_factor_calc (L , M_L , 1 , k_cross_section , k_gamma , theta_gamma , phi_gamma);

		      angular_factor_minus_tab(iJPi_A_out , L , iM_L , theta_gamma_index , phi_gamma_index) = 
			angular_factor_calc (L , M_L , -1 , k_cross_section , k_gamma , theta_gamma , phi_gamma);
		    }//loop phi_gamma
		}//loop theta_gamma
	    }//loop M_L
	}//loop L
    }//loop iJPi_A_out
}

void CC_radiative_capture::Wigner_Eckhart_factor_tab_calc (
							   const class CC_target_projectile_composite_data &Tpc_data , 
							   const enum EM_type EM , 
							   class array<double> &Wigner_Eckhart_factor_tab)
{
  const class array<unsigned int> &BP_A_in_tab  = Tpc_data.get_BP_A_in_tab ();
  const class array<unsigned int> &BP_A_out_tab = Tpc_data.get_BP_A_out_tab ();

  const class array<double> &J_A_in_tab  = Tpc_data.get_J_A_in_tab ();
  const class array<double> &J_A_out_tab = Tpc_data.get_J_A_out_tab ();

  const unsigned int N_JPi_A_in  = Tpc_data.get_N_JPi_A_in ();
  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();
  
  const int Lmax_all    = Wigner_Eckhart_factor_tab.dimension (4) - 1;
  const int iM_Lmax_all = Wigner_Eckhart_factor_tab.dimension (5) - 1;

  for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
    {
      // total final angular momentum , binary parity , energy and vector index

      const double J_A_out = J_A_out_tab(iJPi_A_out);

      const unsigned int BP_A_out = BP_A_out_tab(iJPi_A_out);

      const int iM_A_out_max = make_int (2.0*J_A_out);

      for (int iM_A_out = 0 ; iM_A_out <= iM_A_out_max ; iM_A_out++)
	{	
	  const double M_A_out = iM_A_out - J_A_out;

	  for (unsigned int iJPi_A_in = 0 ; iJPi_A_in < N_JPi_A_in ; iJPi_A_in++)
	    {
	      const double J_A_in = J_A_in_tab(iJPi_A_in);
	      
	      const unsigned int BP_A_in = BP_A_in_tab(iJPi_A_in);

	      const int iM_A_in_max = make_int (2.0*J_A_in);

	      for (int iM_A_in = 0 ; iM_A_in <= iM_A_in_max ; iM_A_in++)
		{	
		  const double M_A_in = iM_A_in - J_A_in;

		  for (int L = 0 ; L <= Lmax_all ; L++) 
		    {
		      for (int iM_L = 0 ; iM_L <= iM_Lmax_all ; iM_L++)
			{
			  const int M_L = iM_L - Lmax_all;	

			  const unsigned int BP_EM_L = BP_EM_determine (EM , L);

			  if ((binary_parity_product (BP_A_in , BP_EM_L) == BP_A_out) && (abs (M_L) <= L))
			    {
			      const double Wigner_Eckhart_factor = 
				Wigner_3j (J_A_out , L , J_A_in , -M_A_out , M_L , M_A_in) * minus_one_pow (J_A_out - M_A_out); 

			      Wigner_Eckhart_factor_tab(iJPi_A_in , iM_A_in , iJPi_A_out , iM_A_out , L , iM_L) = Wigner_Eckhart_factor;
			    }//tests ML , BP
			}//loop on iM_L
		    }//loop on L
		}//loop on M_A_in
	    }//loop on iJPi_A_in
	}//loop on M_A_out
    }//loop on iJPi_A_out
}

void CC_radiative_capture::product_CGs_l_terms_Coulomb_phase_shifts_tab_calc (	
									      const class CC_target_projectile_composite_data &Tpc_data , 
									      const double J_intrinsic_projectile , 
									      const double eta_cross_section , 
									      class array<complex<double> > &product_CGs_l_terms_Coulomb_phase_shifts_tab)
{
  const complex<double> I(0 , 1);

  const int S = Tpc_data.get_S ();
  
  const double sqrt_four_Pi = 3.544907701811032;

  const unsigned int iT_entrance = Tpc_data.get_entrance_target_index ();
  
  const unsigned int N_JPi_A_in = Tpc_data.get_N_JPi_A_in ();

  const int iM_intrinsic_projectile_number = make_int (2.0*J_intrinsic_projectile + 1.0);

  const class array<double> &J_target_tab = Tpc_data.get_J_target_tab ();
  
  const class array<unsigned int> &BP_A_in_tab = Tpc_data.get_BP_A_in_tab ();

  const class array<unsigned int> &N_channels_in_tab = Tpc_data.get_N_channels_in_tab ();

  const class array<double> &J_A_in_tab = Tpc_data.get_J_A_in_tab ();

  const class array<unsigned int> &N_entrance_channels_in_tab = Tpc_data.get_N_entrance_channels_tab ();

  const class array<class CC_channel_class> &channels_in_tab = Tpc_data.get_channels_in_tab ();

  const class array<unsigned int> &entrance_JPi_channels_indices = Tpc_data.get_entrance_JPi_channels_indices ();

  const double J_T = J_target_tab(iT_entrance);

  for (unsigned int iJPi_A_in = 0 ; iJPi_A_in < N_JPi_A_in ; iJPi_A_in++)
    {
      const unsigned int BP_A_in = BP_A_in_tab(iJPi_A_in);

      const double J_A_in = J_A_in_tab(iJPi_A_in);
      
      const unsigned int N_channels_JPi_A_in = N_channels_in_tab(iJPi_A_in);

      const unsigned int N_entrance_channels_in = N_entrance_channels_in_tab(iJPi_A_in);

      class array<class CC_channel_class> channels_JPi_A_in_tab (N_channels_JPi_A_in);

      JPi_channels_tab_BP_J_fill (S , channels_in_tab , BP_A_in , J_A_in , channels_JPi_A_in_tab);

      const int iM_A_in_max = make_int (2.0*J_A_in);

      for (int iM_A_in = 0 ; iM_A_in <= iM_A_in_max ; iM_A_in++)
	{
	  const double M_A_in = iM_A_in - J_A_in;

	  for (unsigned int i_entrance  = 0 ; i_entrance  < N_entrance_channels_in ; i_entrance++)
	    {
	      const unsigned int ic_entrance = entrance_JPi_channels_indices(iJPi_A_in , i_entrance);

	      const class CC_channel_class &channel_entrance = channels_JPi_A_in_tab(ic_entrance);
	      
	      const int lc_entrance = channel_entrance.get_LCM_projectile ();
	      
	      const double jc_entrance = channel_entrance.get_J_projectile ();

	      const double hat_lc_entrance = hat (lc_entrance);
	      
	      const complex<double> sigma_lc_entrance = sigma_l_calc (lc_entrance  , eta_cross_section);

	      const complex<double> exp_I_sigma_lc_entrance = exp (I * sigma_lc_entrance);

	      const complex<double> hat_Coulomb_phase_shift_pow_term = sqrt_four_Pi * pow (I , lc_entrance) * hat_lc_entrance  * exp_I_sigma_lc_entrance;

	      for (int iM_intrinsic_projectile = 0 ; iM_intrinsic_projectile < iM_intrinsic_projectile_number ; iM_intrinsic_projectile++)
		{
		  const double M_intrinsic_projectile = iM_intrinsic_projectile - J_intrinsic_projectile;

		  const double M_T = M_A_in - M_intrinsic_projectile;

		  const double CG_lc_s_jc_entrance_M_intrinsic_projectile = Clebsch_Gordan (lc_entrance  , 0 , J_intrinsic_projectile , M_intrinsic_projectile , jc_entrance  , M_intrinsic_projectile);

		  const double CG_J_Tc_jc_entrance_JM_in = Clebsch_Gordan (J_T , M_T , jc_entrance  , M_intrinsic_projectile , J_A_in , M_A_in);

		  product_CGs_l_terms_Coulomb_phase_shifts_tab(iM_intrinsic_projectile , iM_A_in , iJPi_A_in , i_entrance) = hat_Coulomb_phase_shift_pow_term * CG_lc_s_jc_entrance_M_intrinsic_projectile * CG_J_Tc_jc_entrance_JM_in;
		}//loop iM_intrinsic_proj
	    }//loop i_entrance
	}//loop on M_A_in
    }//loop on iJPi_A_in
}







// Calculation of the differential cross section of the considered radiative capture
// ---------------------------------------------------------------------------------
// See the book for formulas.
// 
// There is an implicit dependence in J_f because of k_gamma in the global factor.
//
// One uses the formula of S. B. Dubovichenko, A. V. Dzhazairov-Kakhramanov, Fiz. Elem. Chastits. At. Yadra 28, 1529 (1997) (see also T. Tombrello et al., Phys. Rev. 131, 2582 (1963)). 
// A factor 4 is added in the denominator from the formula above in order to have the same normalization as in Descouvemont P and Baye D 2010 Rep. Prog. Phys. 73 036301.
// The overall factor in Descouvemont P and Baye D 2010 Rep. Prog. Phys. 73 036301 is: Pi[from sigma].8 Pi[from U matrix]/(4 Pi)[from M[EL] matrix elements] = 2.Pi .
// One has to integrate over phi[gamma], theta[gamma] and sum over polarization to get the same result, which provides a factor 2.(4.Pi/(2L+1)) = 8.Pi/(2L+1) .
// The overall factor here is: 1/(8 Pi)[from sigma].2 Pi.(2L + 1)[from angular factor].8.Pi/(2L + 1)[from D matrices and polarization] = 2.Pi .
// This 2.Pi factor is also obtained in C. Angulo et al. Nucl. Phys. A 656 (1999) 3-183.

void CC_radiative_capture::differential_cross_section_calc (
							    const class CC_target_projectile_composite_data &Tpc_data , 
							    const class array<TYPE> &CC_EM_NBMEs , 
							    const class array<TYPE> &CC_E_A_out_tab , 
							    const class array<double> &theta_gamma_tab , 
							    const class array<double> &phi_gamma_tab , 
							    const unsigned int iE , 
							    const double E_kinetic_total_system_CM , 
							    const TYPE &E , 
							    const enum EM_type EM , 
							    class array<double> &differential_cross_section_tab)
{  
  const double CM_to_work_frame_kinetic_factor = Tpc_data.get_CM_to_work_frame_kinetic_factor ();
  
  const unsigned int iT_entrance = Tpc_data.get_entrance_target_index ();
  
  const unsigned int N_JPi_A_in  = Tpc_data.get_N_JPi_A_in ();
  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();
  
  const unsigned int N_theta_gamma = theta_gamma_tab.dimension (0);

  const unsigned int N_phi_gamma = phi_gamma_tab.dimension (0);
  
  const class array<double> &J_target_tab = Tpc_data.get_J_target_tab ();
  
  const class array<unsigned int> &BP_A_in_tab  = Tpc_data.get_BP_A_in_tab ();
  const class array<unsigned int> &BP_A_out_tab = Tpc_data.get_BP_A_out_tab ();
  
  const class array<double> &J_A_in_tab  = Tpc_data.get_J_A_in_tab ();
  const class array<double> &J_A_out_tab = Tpc_data.get_J_A_out_tab ();
  
  const int L_for_radiative_capture_cross_section = Tpc_data.get_L_for_radiative_capture_cross_section ();

  const enum particle_type projectile = Tpc_data.get_entrance_projectile ();	

  const int Z_target = Tpc_data.get_Z_target ();
  
  const double kinetic_factor_entrance_projectile_CM         = Tpc_data.get_kinetic_factor_entrance_projectile_CM ();
  const double kinetic_factor_entrance_projectile_work_frame = Tpc_data.get_kinetic_factor_entrance_projectile_work_frame ();
  
  const double J_T = J_target_tab(iT_entrance);

  const double E_i = real_dc (E);
  
  const double e_cross_section = E_kinetic_total_system_CM*CM_to_work_frame_kinetic_factor;

  const double k_cross_section = sqrt (kinetic_factor_entrance_projectile_work_frame * e_cross_section);
  
  const double eta_cross_section = real_dc (eta_calc (false , projectile , Z_target , kinetic_factor_entrance_projectile_work_frame , k_cross_section));
  
  const double J_intrinsic_projectile = J_intrinsic_cluster_determine (projectile);

  const int iM_intrinsic_projectile_number = make_int (2.0*J_intrinsic_projectile + 1.0);

  const class array<unsigned int> &N_entrance_channels_in_tab = Tpc_data.get_N_entrance_channels_tab ();
  
  const unsigned int N_entrance_channels_max = N_entrance_channels_in_tab.max ();
  
  const double Jmax_all_in  = J_A_in_tab.max ();
  const double Jmax_all_out = J_A_out_tab.max ();
  
  const int M_A_in_number_max  = make_int (2.0*Jmax_all_in + 1.0);
  const int M_A_out_number_max = make_int (2.0*Jmax_all_out + 1.0);
  
  const int Lmax_all = make_int (Jmax_all_in + Jmax_all_out);

  const int Lmax_all_plus_one = Lmax_all+  1;
  
  const int iM_Lmax_all = 2 * Lmax_all;

  const int iM_Lmax_all_plus_one = iM_Lmax_all+  1;
  
  const unsigned int EM_index = EM_index_determine (EM);

  class array<complex<double> > angular_factor_plus_tab (N_JPi_A_out , Lmax_all_plus_one , iM_Lmax_all_plus_one , N_theta_gamma , N_phi_gamma);
  class array<complex<double> > angular_factor_minus_tab(N_JPi_A_out , Lmax_all_plus_one , iM_Lmax_all_plus_one , N_theta_gamma , N_phi_gamma);

  angular_factor_plus_tab  = 0.0;
  angular_factor_minus_tab = 0.0;

  angular_factor_tabs_calc (k_cross_section , E_i , CC_E_A_out_tab , theta_gamma_tab , phi_gamma_tab , angular_factor_plus_tab , angular_factor_minus_tab);

  class array<double> Wigner_Eckhart_factor_tab(N_JPi_A_in , M_A_in_number_max , N_JPi_A_out , M_A_out_number_max , Lmax_all_plus_one , iM_Lmax_all_plus_one);
  
  Wigner_Eckhart_factor_tab = 0.0;

  Wigner_Eckhart_factor_tab_calc (Tpc_data , EM , Wigner_Eckhart_factor_tab);

  class array<complex<double> > product_CGs_l_terms_Coulomb_phase_shifts_tab(iM_intrinsic_projectile_number , M_A_in_number_max , N_JPi_A_in , N_entrance_channels_max);

  product_CGs_l_terms_Coulomb_phase_shifts_tab = 0.0;

  product_CGs_l_terms_Coulomb_phase_shifts_tab_calc (Tpc_data , J_intrinsic_projectile , eta_cross_section , product_CGs_l_terms_Coulomb_phase_shifts_tab);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int theta_gamma_index = 0 ; theta_gamma_index < N_theta_gamma ; theta_gamma_index++)
    {
      for (unsigned int phi_gamma_index = 0 ; phi_gamma_index < N_phi_gamma ; phi_gamma_index++)
	{
	  for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
	    {
	      const double J_A_out = J_A_out_tab(iJPi_A_out);

	      const unsigned int BP_A_out = BP_A_out_tab(iJPi_A_out);

	      const double E_A_out = real_dc (CC_E_A_out_tab(iJPi_A_out));

	      const double k_gamma = (E_i - E_A_out) / hbar_c;
	      
	      const double factor = 1.0 / (8.0 * M_PI) * (k_gamma / k_cross_section) * fine_struct_const * (kinetic_factor_entrance_projectile_CM * hbar_c / 2.0) * (1.0 / (2.0 * J_intrinsic_projectile + 1)) * (1.0 / (2.0 * J_T + 1));
	      
	      if (factor <= 0.0) continue;

	      const int iM_A_out_max = make_int (2.0*J_A_out);

	      double differential_cross_section_J_A_out_nas_only = 0.0;
	      double differential_cross_section_J_A_out_as = 0.0;

	      for (int iM_A_out = 0 ; iM_A_out <= iM_A_out_max ; iM_A_out++)
		{	
		  const double M_A_out = iM_A_out - J_A_out;

		  for (int iM_A_in = 0 ; iM_A_in < M_A_in_number_max ; iM_A_in++)
		    {
		      for (int iM_intrinsic_projectile = 0 ; iM_intrinsic_projectile < iM_intrinsic_projectile_number ; iM_intrinsic_projectile++)
			{
			  for (int P = -1 ; P <= 1 ; P += 2)
			    {
			      const class array<complex<double> > &angular_factor_tab = (P == -1) ? (angular_factor_minus_tab) : (angular_factor_plus_tab);

			      complex<double> differential_cross_section_amplitude_part_nas_only = 0.0;

			      complex<double> differential_cross_section_amplitude_part_as = 0.0;

			      for (int L = 0 ; L <= Lmax_all ; L++)
				{
				  if (L == L_for_radiative_capture_cross_section)
				    {
				      // E0 transition cannot occur
				      if (L != 0)
					{
					  const unsigned int BP_EM_L = BP_EM_determine (EM , L);

					  for (unsigned int iJPi_A_in = 0 ; iJPi_A_in < N_JPi_A_in ; iJPi_A_in++)
					    {
					      const double J_A_in = J_A_in_tab(iJPi_A_in);

					      const unsigned int BP_A_in = BP_A_in_tab(iJPi_A_in);

					      const int Lmin = abs (make_int (J_A_in - J_A_out));
					      const int Lmax =      make_int (J_A_in + J_A_out);

					      if ((binary_parity_product (BP_A_in , BP_EM_L) == BP_A_out) && (L >= Lmin) && (L <= Lmax)) 
						{
						  const double M_A_in = iM_A_in - J_A_in;	

						  const int M_L = make_int (M_A_out - M_A_in);

						  if ((rint (abs (M_A_in) - J_A_in) <= 0.0) && (abs (M_L) <= L))
						    {
						      const int iM_L = M_L + Lmax_all;

						      const complex<double> angular_factor = angular_factor_tab(iJPi_A_out , L , iM_L , theta_gamma_index , phi_gamma_index);
						      const unsigned int N_entrance_channels_in = N_entrance_channels_in_tab(iJPi_A_in);

						      const double Wigner_Eckhart_factor = Wigner_Eckhart_factor_tab(iJPi_A_in , iM_A_in , iJPi_A_out , iM_A_out , L , iM_L);

						      complex<double> differential_cross_section_amplitude_subpart_nas_only = 0.0;

						      complex<double> differential_cross_section_amplitude_subpart_as = 0.0;

						      for (unsigned int i_entrance = 0 ; i_entrance < N_entrance_channels_in ; i_entrance++)
							{
							  const complex<double> product_CGs_l_terms_Coulomb_phase_shift = product_CGs_l_terms_Coulomb_phase_shifts_tab(iM_intrinsic_projectile , iM_A_in , iJPi_A_in , i_entrance);
							  
							  const complex<double> CC_EM_matrix_nas_only = CC_EM_NBMEs(0 , EM_index , iJPi_A_in , iJPi_A_out , i_entrance , L , iE);
							  
							  const complex<double> CC_EM_matrix_as = CC_EM_NBMEs(1 , EM_index , iJPi_A_in , iJPi_A_out , i_entrance , L , iE); 

							  differential_cross_section_amplitude_subpart_nas_only += product_CGs_l_terms_Coulomb_phase_shift*CC_EM_matrix_nas_only;
							  
							  differential_cross_section_amplitude_subpart_as += product_CGs_l_terms_Coulomb_phase_shift*CC_EM_matrix_as;
							}//loop i_entrance

						      const complex<double> angular_product = angular_factor*Wigner_Eckhart_factor;

						      differential_cross_section_amplitude_subpart_nas_only *= angular_product;

						      differential_cross_section_amplitude_subpart_as *= angular_product;

						      differential_cross_section_amplitude_part_nas_only += differential_cross_section_amplitude_subpart_nas_only;
						      differential_cross_section_amplitude_part_as       += differential_cross_section_amplitude_subpart_as;

						    }//tests M_A_in , ML
						}//tests L , BP
					    }//loop on iJPi_A_in
					}//if L!=0
				    }//test L
				}//loop L
			      
			      differential_cross_section_J_A_out_nas_only += factor * norm (differential_cross_section_amplitude_part_nas_only);
			      differential_cross_section_J_A_out_as       += factor * norm (differential_cross_section_amplitude_part_as);

			    }//loop P
			}//loop iM_intrinsic_proj
		    }//loop on M_A_in
		}//loop M_A_out
	      
	      differential_cross_section_tab(0 , EM_index , iE , iJPi_A_out , theta_gamma_index , phi_gamma_index) = differential_cross_section_J_A_out_nas_only;
	      
	      differential_cross_section_tab(1 , EM_index , iE , iJPi_A_out , theta_gamma_index , phi_gamma_index) = differential_cross_section_J_A_out_as;
	      
	    }//loop iJPi_A_out
	}//loop phi_gamma
    }//loop theta_gamma
}









// Calculation of the differential and total cross sections of the considered radiative capture
// --------------------------------------------------------------------------------------------
// as and nas are for antisymmetrized or non-antisymmetrized channels (see CC_EM_transitions_MEs_composite.cpp).
// Differential cross sections integrated over phi[gamma] (hence depending only on theta[gamma]) and total cross sections are stored in files.
// Total cross sections are also printed on screen.

void CC_radiative_capture::all_cross_sections_calc_print (
							  const enum interaction_type inter ,
							  const class CC_target_projectile_composite_data &Tpc_data , 
							  const class array<TYPE> &CC_E_A_out_tab , 
							  const class array<TYPE> &CC_EM_NBMEs)
{
  const enum EM_type EM_for_radiative_capture_cross_section = Tpc_data.get_EM_for_radiative_capture_cross_section ();
    
  const unsigned int N_energies = Tpc_data.get_N_energies ();

  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();

  const class array<double> &E_total_tab = Tpc_data.get_E_total_tab ();

  const class array<double> &E_kinetic_total_system_CM_tab = Tpc_data.get_E_kinetic_total_system_CM_tab ();

  const unsigned int N_theta_gamma = Tpc_data.get_N_theta_gamma ();

  const unsigned int N_phi_gamma = Tpc_data.get_N_phi_gamma ();
  
  class array<double> theta_gamma_tab(N_theta_gamma);

  class array<double> weights_theta_gamma_tab(N_theta_gamma);
  
  class array<double> phi_gamma_tab(N_phi_gamma);

  class array<double> weights_phi_gamma_tab(N_phi_gamma);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , M_PI , theta_gamma_tab , weights_theta_gamma_tab);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , 2.0 * M_PI , phi_gamma_tab , weights_phi_gamma_tab);

  class array<double> differential_cross_section_tab(2 , 2 , N_energies , N_JPi_A_out , N_theta_gamma , N_phi_gamma);

  differential_cross_section_tab = 0.0;

  const unsigned int first_iE = basic_first_index_determine_for_MPI (N_energies , NUMBER_OF_PROCESSES , THIS_PROCESS); 
  const unsigned int last_iE = basic_last_index_determine_for_MPI (N_energies , NUMBER_OF_PROCESSES , THIS_PROCESS); 

  for (unsigned int iE = 0 ; iE < N_energies ; ++iE)
    {
      if ((iE >= first_iE) && (iE <= last_iE))
	{
	  const double E_total = E_total_tab(iE);

	  const double E_kinetic_total_system_CM = E_kinetic_total_system_CM_tab(iE);

	  differential_cross_section_calc (Tpc_data , CC_EM_NBMEs , CC_E_A_out_tab , theta_gamma_tab , phi_gamma_tab ,
					   iE , E_kinetic_total_system_CM , E_total , EM_for_radiative_capture_cross_section , differential_cross_section_tab);
	}
    }

#ifdef UseMPI
  if (is_it_MPI_parallelized) differential_cross_section_tab.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);	
#endif

  if (THIS_PROCESS == MASTER_PROCESS)
    cross_sections_calc_print (inter , Tpc_data , theta_gamma_tab , weights_theta_gamma_tab , phi_gamma_tab , weights_phi_gamma_tab , differential_cross_section_tab);
}

void CC_radiative_capture::cross_sections_calc_print (
						      const enum interaction_type inter ,
						      const class CC_target_projectile_composite_data &Tpc_data , 
						      const class array<double> &theta_gamma_tab , 
						      const class array<double> &weights_theta_gamma_tab , 
						      const class array<double> &phi_gamma_tab , 
						      const class array<double> &weights_phi_gamma_tab , 
						      const class array<double> &differential_cross_section_tab)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in CC_radiative_capture::cross_sections_calc_print");
  
  const enum EM_type EM_for_radiative_capture_cross_section = Tpc_data.get_EM_for_radiative_capture_cross_section ();

  const double CM_to_work_frame_kinetic_factor = Tpc_data.get_CM_to_work_frame_kinetic_factor ();

  const enum CC_reaction_calculation_type CC_reaction_calculation = Tpc_data.get_CC_reaction_calculation ();
  
  const bool is_differential_cross_section_calculated = (CC_reaction_calculation == DIFFERENTIAL_CROSS_SECTION);

  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();

  const unsigned int N_theta_gamma = theta_gamma_tab.dimension (0);

  const unsigned int N_phi_gamma = phi_gamma_tab.dimension (0);

  const unsigned int N_energies = Tpc_data.get_N_energies ();

  const class array<unsigned int> &BP_A_out_tab = Tpc_data.get_BP_A_out_tab ();

  const class array<double> &J_A_out_tab = Tpc_data.get_J_A_out_tab ();

  const class array<unsigned int> &vector_index_A_out_tab = Tpc_data.get_vector_index_A_out_tab ();

  const class array<double> &E_kinetic_total_system_CM_tab = Tpc_data.get_E_kinetic_total_system_CM_tab ();
  
  class array<complex<double> > cross_section_J_A_out_theta_nas_only_tab(N_theta_gamma);

  class array<complex<double> > cross_section_J_A_out_theta_as_tab(N_theta_gamma);

  cout << "---------------------------------------------------------------------------------------------------------------------" << endl << endl;
  
  for (unsigned int EM_index = 0 ; EM_index <= 1 ; EM_index++)
    {
      const enum EM_type EM_from_index = EM_determine_from_index (EM_index);

      const string EM_from_index_letter = EM_letter_determine (EM_from_index);

      if (EM_for_radiative_capture_cross_section == EM_from_index)
	{
	  if (EM_from_index_letter == "E") cout << endl << "Electric radiative capture" << endl;
	  if (EM_from_index_letter == "M") cout << endl << "Magnetic radiative capture" << endl;
	  cout << "--------------------------" << endl;

	  const string astrophysical_factor_nas_only_file_name = "astrophysical_factor_total_cross_section_" + EM_from_index_letter + "_non_antisymmetrized.dat";

	  const string astrophysical_factor_as_file_name = "astrophysical_factor_total_cross_section_" + EM_from_index_letter + "_antisymmetrized.dat";

	  ofstream astrophysical_factor_nas_only_file (astrophysical_factor_nas_only_file_name.c_str ());

	  ofstream astrophysical_factor_as_file (astrophysical_factor_as_file_name.c_str ());

	  for (unsigned int iE = 0 ; iE < N_energies ; iE++)
	    {
	      const double E_kinetic_total_system_CM = E_kinetic_total_system_CM_tab(iE);

	      double total_cross_section_nas_only = 0.0;
	      double total_cross_section_as       = 0.0;
	      
	      for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
		{
		  const double J_A_out = J_A_out_tab(iJPi_A_out);

		  const unsigned int BP_A_out = BP_A_out_tab(iJPi_A_out);

		  const unsigned int vector_index_A_out = vector_index_A_out_tab(iJPi_A_out);
		  
		  cross_section_J_A_out_theta_nas_only_tab = 0.0;
		  cross_section_J_A_out_theta_as_tab       = 0.0;

		  double total_cross_section_J_A_out_nas_only = 0.0;
		  double total_cross_section_J_A_out_as       = 0.0;

		  for (unsigned int theta_gamma_index = 0 ; theta_gamma_index < N_theta_gamma ; theta_gamma_index++)
		    {
		      const double theta_gamma = theta_gamma_tab(theta_gamma_index);

		      const double weight_theta_gamma = weights_theta_gamma_tab(theta_gamma_index);

		      double cross_section_J_A_out_theta_nas_only = 0.0;

		      double cross_section_J_A_out_theta_as = 0.0;

		      for (unsigned int phi_gamma_index = 0 ; phi_gamma_index < N_phi_gamma ; phi_gamma_index++)
			{
			  const double weight_phi_gamma = weights_phi_gamma_tab(phi_gamma_index);

			  cross_section_J_A_out_theta_nas_only += differential_cross_section_tab(0 , EM_index , iE , iJPi_A_out , theta_gamma_index , phi_gamma_index) * weight_phi_gamma;
			  cross_section_J_A_out_theta_as       += differential_cross_section_tab(1 , EM_index , iE , iJPi_A_out , theta_gamma_index , phi_gamma_index) * weight_phi_gamma;			  
			}//loop phi_gamma

		      cross_section_J_A_out_theta_nas_only_tab(theta_gamma_index) = cross_section_J_A_out_theta_nas_only;
		      cross_section_J_A_out_theta_as_tab      (theta_gamma_index) = cross_section_J_A_out_theta_as;

		      const double angular_weight = weight_theta_gamma * sin (theta_gamma);

		      total_cross_section_J_A_out_nas_only += cross_section_J_A_out_theta_nas_only * angular_weight;
		      total_cross_section_J_A_out_as       += cross_section_J_A_out_theta_as       * angular_weight;
		    }//loop theta_gamma

		  total_cross_section_nas_only += total_cross_section_J_A_out_nas_only;
		  total_cross_section_as       += total_cross_section_J_A_out_as;

		  if (is_differential_cross_section_calculated)
		    {
		      const string differential_cross_section_file_nas_only_J_f_name = "radiative_capture_differential_cross_section_nas_only_final_state_" + make_string<enum EM_type> (EM_from_index) 
			+ "_" + J_Pi_vector_index_string_for_file_name (BP_A_out , J_A_out , vector_index_A_out) + ".dat";

		      ofstream differential_cross_section_file_nas_only_J_f (differential_cross_section_file_nas_only_J_f_name.c_str ());

		      differential_cross_section_file_nas_only_J_f.precision (15);

		      for (unsigned int theta_gamma_index = 0 ; theta_gamma_index < N_theta_gamma ; theta_gamma_index++)
			differential_cross_section_file_nas_only_J_f << theta_gamma_tab(theta_gamma_index) << " " 
								     << real (cross_section_J_A_out_theta_nas_only_tab(theta_gamma_index)) << " " 
								     << imag (cross_section_J_A_out_theta_nas_only_tab(theta_gamma_index)) << endl;
		  
		      const string differential_cross_section_file_as_J_f_name = "radiative_capture_differential_cross_section_as_final_state_" + make_string<enum EM_type> (EM_from_index) 
			+ "_" + J_Pi_vector_index_string_for_file_name (BP_A_out , J_A_out , vector_index_A_out) + ".dat";

		      ofstream differential_cross_section_file_as_J_f (differential_cross_section_file_as_J_f_name.c_str ());

		      differential_cross_section_file_as_J_f.precision (15);

		      for (unsigned int theta_gamma_index = 0 ; theta_gamma_index < N_theta_gamma ; theta_gamma_index++)
			differential_cross_section_file_as_J_f << theta_gamma_tab(theta_gamma_index) << " " 
							       << real (cross_section_J_A_out_theta_as_tab(theta_gamma_index)) << " " 
							       << imag (cross_section_J_A_out_theta_as_tab(theta_gamma_index)) << endl;
		    }
		  
		  const double total_cross_section_J_A_out_nas_only_microbarn = total_cross_section_J_A_out_nas_only * 1E4;
		  const double total_cross_section_J_A_out_as_microbarn       = total_cross_section_J_A_out_as       * 1E4;
	      
		  cout << "Final state : " << J_Pi_vector_index_string (BP_A_out , J_A_out , vector_index_A_out) << endl;
		  cout << "Partial radiative capture cross section : non-antisymmetrized = " << total_cross_section_J_A_out_nas_only_microbarn << " microbarn" << endl;
		  cout << "Partial radiative capture cross section : antisymmetrized     = " << total_cross_section_J_A_out_as_microbarn << " microbarn" << endl << endl;
		}

	      // 1 microbarn = 0.0001 fm^2

	      const double total_cross_section_nas_only_microbarn = total_cross_section_nas_only * 1E4;
	      const double total_cross_section_as_microbarn       = total_cross_section_as       * 1E4;

	      // ================================== astrophysical factor ================================== //

	      const double kinetic_factor_entrance_projectile_work_frame = Tpc_data.get_kinetic_factor_entrance_projectile_work_frame ();

	      const enum particle_type entrance_projectile = Tpc_data.get_entrance_projectile ();

	      const int Z_target = Tpc_data.get_Z_target ();
	      
	      const double e_cross_section = E_kinetic_total_system_CM*CM_to_work_frame_kinetic_factor;

	      const double k_cross_section = sqrt (kinetic_factor_entrance_projectile_work_frame * e_cross_section);
	      
	      const double eta_cross_section = real_dc (eta_calc (false , entrance_projectile , Z_target , kinetic_factor_entrance_projectile_work_frame , k_cross_section));

	      const double energy_factor = e_cross_section * exp (2.0 * M_PI * eta_cross_section);

	      const double astrophysical_factor_nas_only_barn_eV = total_cross_section_nas_only_microbarn * energy_factor;

	      const double astrophysical_factor_as_barn_eV = total_cross_section_as_microbarn * energy_factor;

	      astrophysical_factor_nas_only_file << E_kinetic_total_system_CM << " " << e_cross_section << " " << astrophysical_factor_nas_only_barn_eV << " " << total_cross_section_nas_only_microbarn << endl;
	      astrophysical_factor_as_file       << E_kinetic_total_system_CM << " " << e_cross_section << " " << astrophysical_factor_as_barn_eV       << " " << total_cross_section_as_microbarn << endl;

	      if (is_it_realistic_interaction (inter))
		cout << "E[CM] = " << e_cross_section << " MeV" << endl << endl;
	      else
		cout << "E[COSM] = " << e_cross_section << " MeV" << endl << endl;
		
	      cout << "total radiative capture cross section : non-antisymmetrized = " << total_cross_section_nas_only_microbarn << " microbarn" << endl;
	      cout << "total radiative capture cross section : antisymmetrized     = " << total_cross_section_as_microbarn       << " microbarn" << endl << endl;

	      cout << "astrophysical factor : non-antisymmetrized = " << astrophysical_factor_nas_only_barn_eV << " barn eV" << endl;
	      cout << "astrophysical factor : antisymmetrized     = " << astrophysical_factor_as_barn_eV       << " barn eV" << endl << endl;
	    }
	}
    }
}













// General routine calling all methods described above
// ---------------------------------------------------

void CC_radiative_capture::calc_print (
				       const class input_data_str &input_data_CC_Berggren , 
				       const class interaction_class &inter_data_basis , 
				       const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
				       const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
				       class baryons_data &prot_Y_data_CC_Berggren , 
				       class baryons_data &neut_Y_data_CC_Berggren , 
				       class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
				       class baryons_data &prot_Y_data , 
				       class baryons_data &neut_Y_data , 
				       class array<class cluster_data> &cluster_projectile_data_tab , 
				       class CC_target_projectile_composite_data &Tpc_data , 
				       class TBMEs_class &TBMEs_pn , 
				       class TBMEs_class &TBMEs_cv)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Radiative capture cross sections" << endl;
      cout <<         "--------------------------------" << endl << endl;
    }
  
  const enum interaction_type inter = inter_data_basis.get_TBME_inter ();
  
  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();
  
  const unsigned int N_JPi_A_in = Tpc_data.get_N_JPi_A_in ();

  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();

  const unsigned int N_energies = Tpc_data.get_N_energies ();
  
  const class array<unsigned int> &N_entrance_channels_in_tab = Tpc_data.get_N_entrance_channels_tab ();

  const unsigned int i_entrance_max_all = N_entrance_channels_in_tab.max ();

  const class array<double> &J_A_in_tab  = Tpc_data.get_J_A_in_tab ();
  const class array<double> &J_A_out_tab = Tpc_data.get_J_A_out_tab ();
  
  const double Jmax_all_in  = J_A_in_tab.max ();
  const double Jmax_all_out = J_A_out_tab.max ();
  
  const int Lmax_all = make_int (Jmax_all_in + Jmax_all_out);

  const int Lmax_all_plus_one = Lmax_all + 1;
  
  class array<TYPE> CC_E_A_out_tab(N_JPi_A_out);

  class array<TYPE> CC_EM_NBMEs(2 , 2 , N_JPi_A_in , N_JPi_A_out , i_entrance_max_all , Lmax_all_plus_one , N_energies);

  CC_E_A_out_tab = 0.0;

  CC_EM_NBMEs = 0.0;

  class GSM_vector PSI_full;
  
  if (!is_it_one_baryon_COSM_case) EM_suboperators_intrinsic_MEs_calc (inter_data_basis , cluster_projectile_data_tab , CC_E_A_out_tab , Tpc_data , PSI_full);
  
  iterative_calc (Tpc_data , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
		  cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren ,
		  prot_Y_data , neut_Y_data , TBMEs_pn , TBMEs_cv , CC_E_A_out_tab , CC_EM_NBMEs , PSI_full);
  
  all_cross_sections_calc_print (inter , Tpc_data , CC_E_A_out_tab , CC_EM_NBMEs);
}




