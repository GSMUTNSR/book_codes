#include "../CC_include/CC_include_def.h"


using namespace string_routines;
using namespace Wigner_signs;
using namespace EM_transitions;
using namespace inputs_misc;
using namespace EM_transitions;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_EM_transitions_MEs;
using namespace CC_EM_transitions_MEs::radial;
using namespace CC_observables_common;
using namespace CC_waves_HF_MSDHF_potentials_calculations;
using namespace configuration_SD_in_space_one_jump_out_to_in;












// cf_<J_Tf || M/E_L (T) || J_Ti>_ci NBMEs stored
void CC_radiative_capture::target_reduced_NBMEs_calc (
						      class GSM_vector &PSI_full , 
						      const enum EM_type EM ,
						      const bool full_common_vectors_used_in_file ,
						      const class CC_target_projectile_composite_data &Tpc_data ,
						      const class interaction_class &inter_data_basis ,
						      class array<class nucleons_data> &prot_data_one_cluster_less_tab , 
						      class array<class nucleons_data> &neut_data_one_cluster_less_tab , 
						      const class array<TYPE> &CC_E_A_out_tab , 
						      class array<TYPE> &target_reduced_NBMEs)
{
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_longwavelength_approximation = Tpc_data.get_radiative_capture_is_it_longwavelength_approximation ();

  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();

  const int n_holes_max = Tpc_data.get_n_holes_max ();
  
  const int n_scat_max = Tpc_data.get_n_scat_max ();

  const int E_relative_max_hw = Tpc_data.get_E_relative_max_hw ();

  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();

  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();

  const unsigned int N_energies = Tpc_data.get_N_energies ();

  const unsigned int EM_index = EM_index_determine (EM);

  const class array<unsigned int> &BP_target_tab = Tpc_data.get_BP_target_tab ();

  const class array<double> &J_target_tab = Tpc_data.get_J_target_tab ();

  const class array<unsigned int> &vector_index_target_tab = Tpc_data.get_vector_index_target_tab ();

  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();

  const class array<TYPE> &E_target_tab =  Tpc_data.get_E_target_tab ();

  const class array<double> &E_total_tab = Tpc_data.get_E_total_tab ();

  // if true , the L_min/max are put to the L value for the total cross section
  // the interferences between different L values disappear due to the orthogonality of the Wigner D-matrices

  const enum CC_reaction_calculation_type CC_reaction_calculation = Tpc_data.get_CC_reaction_calculation ();
  
  const bool is_total_cross_section_calculated = (CC_reaction_calculation == TOTAL_CROSS_SECTION);

  const int L_for_total_cross_section = Tpc_data.get_L_for_total_cross_section ();

  const int L_limit = Tpc_data.get_radiative_capture_L_limit ();

  const bool is_it_HO_expansion = Tpc_data.get_radiative_capture_is_it_HO_expansion ();
  
  const class GSM_vector_helper_class dummy_helper;
  
  // "out" target state
  for (unsigned int iT_out = 0 ; iT_out < N_target_projectile_states ; iT_out++)
    {
      const unsigned int BP_target_out = BP_target_tab(iT_out);

      const unsigned int vector_index_target_out = vector_index_target_tab(iT_out);

      const double J_target_out = J_target_tab(iT_out);

      const double M_target_out = J_target_out;

      const TYPE E_target_out = E_target_tab(iT_out);

      const enum particle_type projectile_out = projectile_tab(iT_out);

      const int Z_projectile_out = Z_projectile_determine (projectile_out);
      const int N_projectile_out = N_projectile_determine (projectile_out);

      class nucleons_data &prot_data_target_out = prot_data_one_cluster_less_tab(Z_projectile_out , N_projectile_out);
      class nucleons_data &neut_data_target_out = neut_data_one_cluster_less_tab(Z_projectile_out , N_projectile_out);

      const int n_holes_max_p_target_out = prot_data_target_out.get_n_holes_max ();
      const int n_holes_max_n_target_out = neut_data_target_out.get_n_holes_max ();
      
      const int n_scat_max_p_target_out = prot_data_target_out.get_n_scat_max ();
      const int n_scat_max_n_target_out = neut_data_target_out.get_n_scat_max ();

      const int Zval_target_out = prot_data_target_out.get_N_valence_nucleons ();
      const int Nval_target_out = neut_data_target_out.get_N_valence_nucleons ();

      const int n_scat_max_target_out = min (n_scat_max , n_scat_max_p_target_out + n_scat_max_n_target_out);

      const int Z_target_out = prot_data_target_out.get_N_nucleons ();
      const int N_target_out = neut_data_target_out.get_N_nucleons ();

      const int Ep_max_hw_target_out = prot_data_target_out.get_E_max_hw ();
      const int En_max_hw_target_out = neut_data_target_out.get_E_max_hw ();

      const int E_min_hw_target_out = prot_data_target_out.get_E_min_hw () + neut_data_target_out.get_E_min_hw ();

      const int E_max_hw_target_out = E_relative_max_hw + E_min_hw_target_out;

      const enum space_type space_target_out = space_determine (Zval_target_out , Nval_target_out);

      const class correlated_state_str PSI_target_out (Z_target_out , N_target_out , BP_target_out , J_target_out , vector_index_target_out , E_target_out , NADA , NADA , NADA , false);
      
      class GSM_vector_helper_class V_target_out_helper (is_it_MPI_parallelized , space_target_out , TBME_inter , false , truncation_hw , truncation_ph ,
							 n_holes_max              , n_scat_max_target_out   , E_max_hw_target_out  , 
							 n_holes_max_p_target_out , n_scat_max_p_target_out , Ep_max_hw_target_out ,
							 n_holes_max_n_target_out , n_scat_max_n_target_out , En_max_hw_target_out , 
							 BP_target_out , M_target_out , true , prot_data_target_out , neut_data_target_out);

      class GSM_vector V_target_out (V_target_out_helper);

      V_target_out.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_target_out);
      	      
      // "in" target state
      for (unsigned int iT_in = 0 ; iT_in < N_target_projectile_states ; iT_in++)
	{
	  const unsigned int BP_target_in = BP_target_tab(iT_in);

	  const unsigned int vector_index_target_in = vector_index_target_tab(iT_in);

	  const double J_target_in = J_target_tab(iT_in);

	  const double M_target_in = J_target_in;

	  const TYPE E_target_in = E_target_tab(iT_in);

	  const enum particle_type projectile_in = projectile_tab(iT_in);
 
	  const int Z_projectile_in = Z_projectile_determine (projectile_in);
	  const int N_projectile_in = N_projectile_determine (projectile_in);

	  class nucleons_data &prot_data_target_in = prot_data_one_cluster_less_tab(Z_projectile_in , N_projectile_in);
	  class nucleons_data &neut_data_target_in = neut_data_one_cluster_less_tab(Z_projectile_in , N_projectile_in);

	  const int n_holes_max_p_target_in = prot_data_target_in.get_n_holes_max ();
	  const int n_holes_max_n_target_in = neut_data_target_in.get_n_holes_max ();
	  
	  const int n_scat_max_p_target_in = prot_data_target_in.get_n_scat_max ();
	  const int n_scat_max_n_target_in = neut_data_target_in.get_n_scat_max ();

	  const int Zval_target_in = prot_data_target_in.get_N_valence_nucleons ();
	  const int Nval_target_in = neut_data_target_in.get_N_valence_nucleons ();

	  const int n_scat_max_target_in = min (n_scat_max , n_scat_max_p_target_in + n_scat_max_n_target_in);

	  const int Z_target_in = prot_data_target_in.get_N_nucleons ();
	  const int N_target_in = neut_data_target_in.get_N_nucleons ();

	  const int Ep_max_hw_target_in = prot_data_target_in.get_E_max_hw ();
	  const int En_max_hw_target_in = neut_data_target_in.get_E_max_hw ();

	  const int E_min_hw_target_in = prot_data_target_in.get_E_min_hw () + neut_data_target_in.get_E_min_hw ();

	  const int E_max_hw_target_in = E_relative_max_hw + E_min_hw_target_in;

	  const enum space_type space_target_in = space_determine (Zval_target_in , Nval_target_in);

	  const class correlated_state_str PSI_target_in (Z_target_in , N_target_in , BP_target_in , J_target_in , vector_index_target_in , E_target_in , NADA , NADA , NADA , false);

	  class GSM_vector_helper_class V_target_in_helper (is_it_MPI_parallelized , space_target_in , TBME_inter , false , truncation_hw , truncation_ph ,
							    n_holes_max             , n_scat_max_target_in   , E_max_hw_target_in  , 
							    n_holes_max_p_target_in , n_scat_max_p_target_in , Ep_max_hw_target_in ,
							    n_holes_max_n_target_in , n_scat_max_n_target_in , En_max_hw_target_in , 
							    BP_target_in , M_target_in , true , prot_data_target_in , neut_data_target_in);
	      
	  // deltas (is it the same projectile)
	  if ((space_target_in == space_target_out) && (projectile_in == projectile_out))
	    {
	      class GSM_vector V_target_in (V_target_in_helper);

	      V_target_in.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_target_in);

	      const enum space_type space_target = space_target_in;

	      const int L_min = abs (make_int (J_target_in - J_target_out));

	      const int L_max_J = make_int (J_target_in + J_target_out);

	      const int L_max = min (L_max_J , L_limit);

	      class nucleons_data &prot_data_target = prot_data_target_in;
	      class nucleons_data &neut_data_target = neut_data_target_in;

	      bool are_configuration_SD_in_space_one_jump_tables_calculated = false;
	      
	      for (int L = L_min ; L <= L_max ; L++)
		{
		  if (!is_total_cross_section_calculated || (L == L_for_total_cross_section)) 
		    {
		      const unsigned int BP_EM = BP_EM_determine (EM , L);
		      // delta (quantum numbers are conserved)
		      if ((binary_parity_product (BP_target_in , BP_EM) == BP_target_out) && (!is_total_cross_section_calculated || (L == L_for_total_cross_section)))
			{			 
			  // calculates cf_<J_Tf || M/E_L (T) || J_Ti>_ci	

			  if (!are_configuration_SD_in_space_one_jump_tables_calculated)			    
			    {			      
			      class GSM_vector_helper_class V_target_in_full_helper;
			      
			      V_target_in_full_helper.allocate_fill_without_MPI_parallelization (V_target_in_helper);
			      
			      configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , true , false , false , false , V_target_in_full_helper , V_target_out_helper , dummy_helper ,
											   prot_data_target , neut_data_target);
			      
			      are_configuration_SD_in_space_one_jump_tables_calculated = true;			      
			    }
			  
			  if (is_it_longwavelength_approximation)
			    {
			      const TYPE target_reduced_NBME = B_amplitude_calc (EM , NADA , L , NADA , is_it_longwavelength_approximation , is_it_HO_expansion , space_target , inter_data_basis , 
										 PSI_full , J_target_in , V_target_in , J_target_out , V_target_out);

			      if (THIS_PROCESS == MASTER_PROCESS) 
				{
				  for (unsigned int iE = 0 ; iE < N_energies ; iE++)
				    for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
				      target_reduced_NBMEs(EM_index , iE , iJPi_A_out , iT_in , iT_out , L) = target_reduced_NBME;
				}
			    }//test is_it_longwavelength_approximation true
			  else
			    {
			      const unsigned int N_energies_splines = 10;
			      
			      const bool are_there_splines = (N_energies > N_energies_splines);

			      if (are_there_splines)
				{
				  class array<double> E_total_tab_for_splines(N_energies_splines);

				  class array<TYPE> target_reduced_NBMEs_for_splines(N_energies_splines , N_JPi_A_out);

				  class array<TYPE> target_reduced_NBMEs_for_splines_1D(N_energies_splines);

				  for (unsigned int iE = 0 ; iE < N_energies_splines ; iE++)
				    {
				      const double E_total_in_i_entrance = E_total_tab(iE);
				      
				      E_total_tab_for_splines(iE) = E_total_in_i_entrance;

				      for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
					{
					  const TYPE E_out = CC_E_A_out_tab(iJPi_A_out);

					  const TYPE q = (E_total_in_i_entrance - E_out) / hbar_c;

					  const TYPE target_reduced_NBME = B_amplitude_calc (EM , q , L , NADA , is_it_longwavelength_approximation , is_it_HO_expansion , space_target , inter_data_basis , 
											     PSI_full , J_target_in , V_target_in , J_target_out , V_target_out);

					  if (THIS_PROCESS == MASTER_PROCESS) target_reduced_NBMEs_for_splines(iE , iJPi_A_out) = target_reduced_NBME;
					  if (THIS_PROCESS == MASTER_PROCESS) cout << "E.out:" << E_out << " : target reduced NBME calculated for splines:" << target_reduced_NBME << endl;
					}//loop iJPi_A_out
				    }//loop iE

				  if (THIS_PROCESS == MASTER_PROCESS)
				    {
				      for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
					{
					  for (unsigned int iE = 0 ; iE < N_energies_splines ; iE++) target_reduced_NBMEs_for_splines_1D(iE) = target_reduced_NBMEs_for_splines(iE , iJPi_A_out);

					  const class splines_class<TYPE> target_reduced_NBMEs_splines(E_total_tab_for_splines , target_reduced_NBMEs_for_splines_1D); 

					  for (unsigned int iE = 0 ; iE < N_energies ; iE++)
					    {
					      const double E_total_in_i_entrance = E_total_tab(iE);
					      
					      const TYPE target_reduced_NBME = target_reduced_NBMEs_splines(E_total_in_i_entrance);

					      target_reduced_NBMEs(EM_index , iE , iJPi_A_out , iT_in , iT_out , L) = target_reduced_NBME;
					      
					      cout << "E.in[entrance]:" << E_total_in_i_entrance << " : target reduced NBME calculated from splines:" << target_reduced_NBME << endl;
					    }//loop iE
					}//loop iJPi_A_out
				      
				      cout << endl;

				    }//test MASTER_PROCESS
				}//test are_there_splines
			      else
				{
				  for (unsigned int iE = 0 ; iE < N_energies ; iE++)
				    {
				      const double E_total_in_i_entrance = E_total_tab(iE);

				      for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
					{
					  const TYPE E_out = CC_E_A_out_tab(iJPi_A_out);

					  const TYPE q = (E_total_in_i_entrance - E_out) / hbar_c;

					  const TYPE target_reduced_NBME = B_amplitude_calc (EM , q , L , NADA , is_it_longwavelength_approximation , is_it_HO_expansion , space_target , inter_data_basis , 
											     PSI_full , J_target_in , V_target_in , J_target_out , V_target_out);

					  if (THIS_PROCESS == MASTER_PROCESS)
					    { 
					      target_reduced_NBMEs(EM_index , iE , iJPi_A_out , iT_in , iT_out , L) = target_reduced_NBME;

					      cout << "E.out:" << E_out << " : target reduced NBME calculated:" << target_reduced_NBME << endl;
					    }
					}//loop iJPi_A_out
				    }//loop iE
				}//test are_there_splines
			    }//test is_it_longwavelength_approximation false
			}//delta L
		    }//loop L total/diff cross section
		}//loop L
	    }//deltas projectile
	}//loop iT_in
    }//loop iT_out

#ifdef UseMPI
  if (is_it_MPI_parallelized) target_reduced_NBMEs.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}






















void CC_radiative_capture::CC_state_out_tab_alloc_calc (
							const class CC_target_projectile_composite_data &Tpc_data , 
							const class interaction_class &inter_data_basis , 
							const class input_data_str &input_data_CC_Berggren , 
							const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
							const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
							const class array<class cluster_data> &cluster_data_tab , 
							class array<class cluster_data> &cluster_data_CC_Berggren_tab , 
							class nucleons_data &prot_data_CC_Berggren , 
							class nucleons_data &neut_data_CC_Berggren , 
							class nucleons_data &prot_data , 
							class nucleons_data &neut_data , 
							class TBMEs_class &TBMEs_pn ,
							class array<class CC_Hamiltonian_data> &CC_H_data_out_tab , 
							class array<class CC_state_class> &CC_state_out_tab , 
							class array<TYPE> &CC_E_A_out_tab)
{
  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  //// if true , the L_min/max are put to the L value for the total cross section
  //// the interferences between different L values disappear due to the orthogonality of the Wigner D-matrices
  //const bool is_total_cross_section_calculated = input_data.get_CC_is_total_cross_section_calculated;
  //const int L_for_total_cross_section = input_data.get_CC_EM_L_for_total_cross_section;

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_one_nucleon_case = Tpc_data.get_is_it_one_nucleon_case ();

  const int A = prot_data.get_A ();

  const bool are_GSM_a_dagger_vectors_calculated = Tpc_data.get_are_GSM_a_dagger_vectors_calculated ();

  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();

  const unsigned int N_bef_R_uniform = input_data_CC_Berggren.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = input_data_CC_Berggren.get_N_aft_R_uniform ();

  const unsigned int N_bef_R_GL = input_data_CC_Berggren.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = input_data_CC_Berggren.get_N_aft_R_GL ();
  
  const unsigned int Nk_momentum_GL = input_data_CC_Berggren.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = input_data_CC_Berggren.get_Nk_momentum_uniform ();
  
  const double R_real_max = input_data_CC_Berggren.get_R_real_max ();

  const double R = input_data_CC_Berggren.get_R ();

  const double kmax_momentum = input_data_CC_Berggren.get_kmax_momentum ();

  const double R_Fermi_momentum = input_data_CC_Berggren.get_R_Fermi_momentum ();
  
  const double R0_inter = inter_data_basis.get_R0 ();

  const double R0 = 1.27*cbrt (A);
  
  const unsigned int iT_entrance = Tpc_data.get_entrance_target_index ();
  
  const class array<TYPE> &E_target_tab = Tpc_data.get_E_target_tab ();

  const TYPE E_total_out_start = E_target_tab(iT_entrance);
  
  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);
  
  const class array<unsigned int> &N_channels_out_tab = Tpc_data.get_N_channels_out_tab ();

  const class array<double> &J_A_out_tab = Tpc_data.get_J_A_out_tab ();

  const class array<unsigned int> &BP_A_out_tab = Tpc_data.get_BP_A_out_tab ();

  const class array<unsigned int> &vector_index_A_out_tab = Tpc_data.get_vector_index_A_out_tab ();

  const class array<class CC_channel_class> &channels_out_tab = Tpc_data.get_channels_out_tab ();

  for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
    {
      const unsigned int N_channels_JPi_A_out = N_channels_out_tab(iJPi_A_out);

      const unsigned int BP_A_out = BP_A_out_tab(iJPi_A_out);

      const double J_A_out = J_A_out_tab(iJPi_A_out);

      const double M_A_out = J_A_out;

      const int vector_index_A_out = vector_index_A_out_tab(iJPi_A_out);

      // table of all channels for the given composite state
      
      class array<class CC_channel_class> channels_JPi_A_out_tab (N_channels_JPi_A_out);

      JPi_channels_tab_BP_J_vector_index_E_fill (channels_out_tab , BP_A_out , J_A_out , vector_index_A_out , E_total_out_start , channels_JPi_A_out_tab);

      class HF_nucleons_data CC_prot_HF_data_out;
      class HF_nucleons_data CC_neut_HF_data_out;

      class nucleons_data prot_data_one_configuration_GSM_out;
      class nucleons_data neut_data_one_configuration_GSM_out;
      
      if (is_it_one_nucleon_case)
	{
	  class nucleons_data CC_prot_data_out;
	  class nucleons_data CC_neut_data_out;
	  
	  nucleons_data_initialization (true , input_data_CC_Berggren , CC_prot_data_out , CC_neut_data_out);
	  
	  const int lp_max_out = CC_prot_data_out.get_lmax ();
	  const int ln_max_out = CC_neut_data_out.get_lmax ();

	  class lj_table<bool> prot_OCM_valence_state_out_tab(0.5 , lp_max_out);
	  class lj_table<bool> neut_OCM_valence_state_out_tab(0.5 , ln_max_out);
	  
	  OCM_valence_state_tab_fill (CC_prot_data_out , prot_OCM_valence_state_out_tab);
	  OCM_valence_state_tab_fill (CC_neut_data_out , neut_OCM_valence_state_out_tab);

	  is_it_OCM_HO_core_determine (input_data_CC_Berggren , CC_prot_data_out , CC_neut_data_out);

	  const class lj_table<int> &prot_n_min_valence_out_tab = prot_HF_data_CC_Berggren.get_nmin_lj_valence_tab ();
	  const class lj_table<int> &neut_n_min_valence_out_tab = neut_HF_data_CC_Berggren.get_nmin_lj_valence_tab (); 

	  prepare_CC_prot_neut_data (channels_JPi_A_out_tab , true , prot_n_min_valence_out_tab , neut_n_min_valence_out_tab , prot_OCM_valence_state_out_tab , neut_OCM_valence_state_out_tab , CC_prot_data_out , CC_neut_data_out);

	  CC_prot_HF_data_out.allocate (input_data_CC_Berggren , CC_prot_data_out);
	  CC_neut_HF_data_out.allocate (input_data_CC_Berggren , CC_neut_data_out);

	  CC_state_calc_preparation (
				     prot_data_CC_Berggren , neut_data_CC_Berggren , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
				     prot_data_one_configuration_GSM_out , neut_data_one_configuration_GSM_out , CC_prot_HF_data_out , CC_neut_HF_data_out);
	}
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl;

      // CC - calculations
      class array<complex<double> > Ueq_out_tab (N_channels_JPi_A_out , N_channels_JPi_A_out , N_bef_R_uniform);

      class array<complex<double> > source_out_tab (N_channels_JPi_A_out , N_bef_R_uniform);

      // always zero because after the radiative capture process , the final state is bounded

      const unsigned int ic_entrance = 0;
      
      class CC_state_class &CC_state_out = CC_state_out_tab(iJPi_A_out);
      
      class CC_Hamiltonian_data &CC_H_data_out = CC_H_data_out_tab(iJPi_A_out);
      
      // outgoing wave
      CC_state_out.allocate (is_it_one_nucleon_case , nmax_HO_lab_tab , cluster_data_tab , true , true , N_channels_JPi_A_out ,
			     ic_entrance , channels_JPi_A_out_tab , N_bef_R_uniform , N_aft_R_uniform , N_bef_R_GL , N_aft_R_GL , Nk_momentum_uniform , Nk_momentum_GL ,  
			     R , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , A , BP_A_out , J_A_out , M_A_out , vector_index_A_out , E_total_out_start);

      CC_H_data_out.allocate (N_channels_JPi_A_out , input_data_CC_Berggren);
      
       
      CC_H_data_out.dimension_matrices_independent_data_realloc_init (is_it_one_nucleon_case , input_data_CC_Berggren , inter_data_basis , channels_JPi_A_out_tab , 
								      prot_data , neut_data , cluster_data_tab , prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab);	

      CC_H_data_out.corrective_factors_read (input_data_CC_Berggren);

      CC_H_data_out.HO_wfs_Gaussian_tables_calc (R , R_real_max , channels_JPi_A_out_tab , inter_data_basis);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  cout << "Calculation of outgoing state " << J_Pi_vector_index_string (BP_A_out , J_A_out , vector_index_A_out) << endl;
	  cout << "---------------------------------------------------------------------------------------------------------------------" << endl;
	}

      // calculations of the u_c (r) for the outgoing wave
      CC_state_iterative_calc (Tpc_data , true , are_GSM_a_dagger_vectors_calculated , input_data_CC_Berggren , inter_data_basis , 
			       prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , prot_data_one_configuration_GSM_out , neut_data_one_configuration_GSM_out , cluster_data_tab , cluster_data_CC_Berggren_tab , 
			       prot_data_CC_Berggren , neut_data_CC_Berggren , prot_data , neut_data , TBMEs_pn , CC_prot_HF_data_out , CC_neut_HF_data_out , CC_H_data_out , CC_state_out);

      // get the final energy

#ifdef TYPEisDOUBLECOMPLEX
      CC_E_A_out_tab(iJPi_A_out) = CC_state_out.get_E ();
#endif
      
#ifdef TYPEisDOUBLE
      CC_E_A_out_tab(iJPi_A_out) = real (CC_state_out.get_E ());
#endif

      if (is_it_one_nucleon_case)
	{
	  HF_wave_function::waves_deallocate (CC_prot_HF_data_out);
	  HF_wave_function::waves_deallocate (CC_neut_HF_data_out);
	}
    }
}










void CC_radiative_capture::CC_state_in_entrance_tab_alloc_calc ( 
								const class CC_target_projectile_composite_data &Tpc_data , 
								const class interaction_class &inter_data_basis , 
								const class input_data_str &input_data_CC_Berggren ,
								const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
								const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
								const class array<class cluster_data> &cluster_data_tab , 
								class array<class cluster_data> &cluster_data_CC_Berggren_tab , 
								const unsigned int iE , 
								const TYPE &E , 
								class nucleons_data &prot_data_CC_Berggren , 
								class nucleons_data &neut_data_CC_Berggren , 
								class nucleons_data &prot_data , 
								class nucleons_data &neut_data , 
								class TBMEs_class &TBMEs_pn ,
								class array<class CC_Hamiltonian_data> &CC_H_data_in_tab , 
								class array<class CC_state_class> &CC_state_in_entrance_tab)
{
  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  //// if true , the L_min/max are put to the L value for the total cross section
  //// the interferences between different L values disappear due to the orthogonality of the Wigner D-matrices
  //const bool is_total_cross_section_calculated = input_data.get_CC_is_total_cross_section_calculated;
  //const int L_for_total_cross_section = input_data.get_CC_EM_L_for_total_cross_section;

  // All a+_(nc lc jc tau_c)|Tc> vectors have been calculated in CC_state_out_tab_alloc_calc , so are_GSM_a_dagger_vectors_calculated is put to false in this routine.get_

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_one_nucleon_case = Tpc_data.get_is_it_one_nucleon_case ();
  
  const unsigned int N_JPi_A_in = Tpc_data.get_N_JPi_A_in ();

  const unsigned int N_bef_R_uniform = input_data_CC_Berggren.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = input_data_CC_Berggren.get_N_aft_R_uniform ();

  const unsigned int N_bef_R_GL = input_data_CC_Berggren.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = input_data_CC_Berggren.get_N_aft_R_GL ();
  
  const unsigned int Nk_momentum_GL = input_data_CC_Berggren.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = input_data_CC_Berggren.get_Nk_momentum_uniform ();
  
  const int A = input_data_CC_Berggren.get_A ();
  
  const double R_real_max = input_data_CC_Berggren.get_R_real_max ();

  const double R = input_data_CC_Berggren.get_R ();

  const double kmax_momentum = input_data_CC_Berggren.get_kmax_momentum ();

  const double R_Fermi_momentum = input_data_CC_Berggren.get_R_Fermi_momentum ();
  
  const double R0_inter = inter_data_basis.get_R0 ();

  const double R0 = 1.27*cbrt (A);
  
  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);

  const class array<unsigned int> &N_channels_in_tab = Tpc_data.get_N_channels_in_tab ();

  const class array<double> &J_A_in_tab = Tpc_data.get_J_A_in_tab ();

  const class array<unsigned int> &BP_A_in_tab = Tpc_data.get_BP_A_in_tab ();

  const class array<unsigned int> &N_entrance_channels_in_tab = Tpc_data.get_N_entrance_channels_tab ();

  const class array<unsigned int> &entrance_JPi_channels_indices = Tpc_data.get_entrance_JPi_channels_indices ();

  const class array<class CC_channel_class> &channels_in_tab = Tpc_data.get_channels_in_tab ();

  for (unsigned int iJPi_A_in = 0 ; iJPi_A_in < N_JPi_A_in ; iJPi_A_in++)
    {
      const unsigned int N_channels_JPi_A_in = N_channels_in_tab(iJPi_A_in);

      const unsigned int N_entrance_channels = N_entrance_channels_in_tab(iJPi_A_in);

      const unsigned int BP_A_in = BP_A_in_tab(iJPi_A_in);
      
      const double J_A_in = J_A_in_tab(iJPi_A_in);

      const double M_A_in = J_A_in;

      class array<class CC_channel_class> channels_JPi_A_in_tab (N_channels_JPi_A_in);

      JPi_channels_tab_BP_J_E_fill (channels_in_tab , BP_A_in , J_A_in , E , channels_JPi_A_in_tab);

      class HF_nucleons_data CC_prot_HF_data_in;
      class HF_nucleons_data CC_neut_HF_data_in;

      class nucleons_data prot_data_one_configuration_GSM_in;
      class nucleons_data neut_data_one_configuration_GSM_in;
 
      if (is_it_one_nucleon_case)
	{
	  class nucleons_data CC_prot_data_in;
	  class nucleons_data CC_neut_data_in;

	  nucleons_data_initialization (true , input_data_CC_Berggren , CC_prot_data_in , CC_neut_data_in);

	  const int lp_max_in = CC_prot_data_in.get_lmax ();
	  const int ln_max_in = CC_neut_data_in.get_lmax ();

	  class lj_table<bool> prot_OCM_valence_state_in_tab(0.5 , lp_max_in);
	  class lj_table<bool> neut_OCM_valence_state_in_tab(0.5 , ln_max_in);

	  OCM_valence_state_tab_fill (CC_prot_data_in , prot_OCM_valence_state_in_tab);
	  OCM_valence_state_tab_fill (CC_neut_data_in , neut_OCM_valence_state_in_tab);

	  is_it_OCM_HO_core_determine (input_data_CC_Berggren , CC_prot_data_in , CC_neut_data_in);

	  const class lj_table<int> &prot_n_min_valence_in_tab = prot_HF_data_CC_Berggren.get_nmin_lj_valence_tab ();
	  const class lj_table<int> &neut_n_min_valence_in_tab = neut_HF_data_CC_Berggren.get_nmin_lj_valence_tab (); 

	  prepare_CC_prot_neut_data (channels_JPi_A_in_tab , false , prot_n_min_valence_in_tab , neut_n_min_valence_in_tab , prot_OCM_valence_state_in_tab , neut_OCM_valence_state_in_tab , CC_prot_data_in , CC_neut_data_in);
	  
	  CC_prot_HF_data_in.allocate (input_data_CC_Berggren , CC_prot_data_in);
	  CC_neut_HF_data_in.allocate (input_data_CC_Berggren , CC_neut_data_in);
	  
	  CC_state_calc_preparation (
				     prot_data_CC_Berggren , neut_data_CC_Berggren , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
				     prot_data_one_configuration_GSM_in , neut_data_one_configuration_GSM_in , CC_prot_HF_data_in , CC_neut_HF_data_in);
	}
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << endl;

      class CC_Hamiltonian_data &CC_H_data_in = CC_H_data_in_tab(iJPi_A_in);
      
      CC_H_data_in.allocate (N_channels_JPi_A_in , input_data_CC_Berggren);
      
      CC_H_data_in.dimension_matrices_independent_data_realloc_init (is_it_one_nucleon_case , input_data_CC_Berggren , inter_data_basis , channels_JPi_A_in_tab , 
								     prot_data , neut_data , cluster_data_tab , prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab);	

      CC_H_data_in.corrective_factors_read (input_data_CC_Berggren);

      CC_H_data_in.HO_wfs_Gaussian_tables_calc (R , R_real_max , channels_JPi_A_in_tab , inter_data_basis);

      for (unsigned int i_entrance = 0 ; i_entrance < N_entrance_channels ; i_entrance++)
	{
	  const bool are_GSM_a_dagger_vectors_calculated = ((iE == 0) && (i_entrance == 0)) ? (Tpc_data.get_are_GSM_a_dagger_vectors_calculated ()) : (false);
	  const unsigned int ic_JPi_A_in_entrance = entrance_JPi_channels_indices(iJPi_A_in , i_entrance);
	  
	  const class CC_channel_class &entrance_channel = channels_JPi_A_in_tab(ic_JPi_A_in_entrance);

	  if (THIS_PROCESS == MASTER_PROCESS)
	    {
	      cout << endl;
	      cout << "Calculation of incoming state " << J_Pi_string (BP_A_in , J_A_in) << endl;
	      cout << "---------------------------------------------------------------------------------------------------------------------" << endl;
	      cout << "Energy index : " << iE << endl;
	      cout << "E[COSM] : " << E << " MeV" << endl;
	      
	      cout << "Entrance channel : " << entrance_channel << endl;
	    }

	  // incoming state
	  class CC_state_class &CC_state_in_entrance = CC_state_in_entrance_tab(iJPi_A_in , i_entrance);
	  	  
	  CC_state_in_entrance.allocate (is_it_one_nucleon_case , nmax_HO_lab_tab , cluster_data_tab , false , true , N_channels_JPi_A_in ,
					 ic_JPi_A_in_entrance , channels_JPi_A_in_tab , N_bef_R_uniform , N_aft_R_uniform , N_bef_R_GL , N_aft_R_GL , Nk_momentum_uniform , Nk_momentum_GL ,
					 R , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , A , BP_A_in , J_A_in , M_A_in , NADA , E);
	    
	  CC_state_iterative_calc (Tpc_data , true , are_GSM_a_dagger_vectors_calculated , input_data_CC_Berggren , inter_data_basis , 
				   prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , prot_data_one_configuration_GSM_in , neut_data_one_configuration_GSM_in , cluster_data_tab , cluster_data_CC_Berggren_tab , 
				   prot_data_CC_Berggren , neut_data_CC_Berggren , prot_data , neut_data , TBMEs_pn , CC_prot_HF_data_in , CC_neut_HF_data_in , CC_H_data_in , CC_state_in_entrance);
	}//loop i_entrance

      if (is_it_one_nucleon_case)
	{
	  HF_wave_function::waves_deallocate (CC_prot_HF_data_in);
	  HF_wave_function::waves_deallocate (CC_neut_HF_data_in);
	}
    }//loop on iJPi_A_in (J_i and M_i)
}





void CC_radiative_capture::CC_EM_NBMEs_calc_fixed_out_in_entrance (
								   class GSM_vector &PSI_full , 
								   const class CC_target_projectile_composite_data &Tpc_data , 
								   const class array<class cluster_data> &cluster_data_tab , 
								   const class input_data_str &input_data_CC_Berggren , 
								   const bool is_it_nas_only , 
								   const unsigned int iJPi_A_in , 
								   const unsigned int iJPi_A_out , 
								   const enum EM_type EM_for_total_cross_section , 
								   const unsigned int i_entrance , 
								   const unsigned int iE , 
								   const class CC_Hamiltonian_data &CC_H_data_in , 
								   const class CC_state_class &CC_state_in_i_entrance , 
								   const class CC_Hamiltonian_data &CC_H_data_out ,  
								   const class CC_state_class &CC_state_out , 
								   class nucleons_data &prot_data , 
								   class nucleons_data &neut_data ,
								   const class interaction_class &inter_data_basis ,	 
								   const class array<TYPE> &target_reduced_NBMEs , 
								   class array<TYPE> &CC_EM_NBMEs)
{
  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();
  
  const class array<unsigned int> &BP_A_in_tab  = Tpc_data.get_BP_A_in_tab ();
  const class array<unsigned int> &BP_A_out_tab = Tpc_data.get_BP_A_out_tab ();
  
  const class array<double> &J_A_in_tab  = Tpc_data.get_J_A_in_tab ();
  const class array<double> &J_A_out_tab = Tpc_data.get_J_A_out_tab ();

  const class array<unsigned int> &vector_index_A_out_tab = Tpc_data.get_vector_index_A_out_tab ();

  const unsigned int BP_A_in  = BP_A_in_tab(iJPi_A_in);
  const unsigned int BP_A_out = BP_A_out_tab(iJPi_A_out);
  
  const double J_A_in  = J_A_in_tab(iJPi_A_in);
  const double J_A_out = J_A_out_tab(iJPi_A_out);

  const unsigned int vector_index_A_out = vector_index_A_out_tab(iJPi_A_out);

  // if true , the L_min/max are put to the L value for the total cross section
  // the interferences between different L values disappear due to the orthogonality of the Wigner D-matrices

  const enum CC_reaction_calculation_type CC_reaction_calculation = Tpc_data.get_CC_reaction_calculation ();
  
  const bool is_total_cross_section_calculated = (CC_reaction_calculation == TOTAL_CROSS_SECTION);

  const int L_for_total_cross_section = Tpc_data.get_L_for_total_cross_section ();

  const int L_limit = Tpc_data.get_radiative_capture_L_limit ();

  const int L_min = abs (make_int (J_A_in - J_A_out));

  const int L_max_J = make_int (J_A_in + J_A_out);

  const int L_max = min (L_max_J , L_limit);

  const bool is_it_longwavelength_approximation = Tpc_data.get_radiative_capture_is_it_longwavelength_approximation ();

  const bool is_it_HO_expansion = Tpc_data.get_radiative_capture_is_it_HO_expansion ();
    
  const unsigned int as_index = (is_it_nas_only) ? (0) : (1);

  const unsigned int EM_for_total_cross_section_index = EM_index_determine (EM_for_total_cross_section);

  //entrance channel index

  const class array<class CC_channel_class> &channels_tab_JPi_A_in = CC_state_in_i_entrance.get_channels_tab ();

  const unsigned int ic_entrance = CC_state_in_i_entrance.get_ic_entrance ();

  class array<TYPE> target_reduced_NBMEs_EM_E_L_fixed(N_target_projectile_states , N_target_projectile_states);
        
  // Angular momentum conservation during EM transition included
  for (int L = L_min ; L <= L_max ; L++)
    {
      if (!is_total_cross_section_calculated || (L == L_for_total_cross_section)) 
	{
	  if (!is_total_cross_section_calculated || (L == L_for_total_cross_section))
	    {
	      // an E0 transition cannot happen alone
	      if (L != 0)
		{
		  const unsigned int BP_EM = BP_EM_determine (EM_for_total_cross_section , L);

		  if (binary_parity_product (BP_EM , BP_A_in) == BP_A_out)
		    {
		      for (unsigned int iT_in = 0 ; iT_in < N_target_projectile_states ; iT_in++)
			for (unsigned int iT_out = 0 ; iT_out < N_target_projectile_states ; iT_out++)
			  target_reduced_NBMEs_EM_E_L_fixed(iT_in , iT_out) = target_reduced_NBMEs(EM_for_total_cross_section_index , iE , iJPi_A_out , iT_in , iT_out , L);			
		      
		      // Parity and angular momentum conservation during EM transition considered
		      // calculation and storage of the < (J_i)_i_entrance || MM_L || J_f >

		      CC_EM_NBMEs(as_index , EM_for_total_cross_section_index , iJPi_A_in , iJPi_A_out , i_entrance , L , iE) = 
			composite::CC_NBME_calc (EM_for_total_cross_section , L , is_it_longwavelength_approximation , is_it_HO_expansion , iE , iJPi_A_out , Tpc_data ,
						 cluster_data_tab , is_it_nas_only , CC_H_data_in , CC_state_in_i_entrance , CC_H_data_out , CC_state_out ,
						 prot_data , neut_data , inter_data_basis , input_data_CC_Berggren , target_reduced_NBMEs_EM_E_L_fixed , PSI_full);

		      if ((THIS_PROCESS == MASTER_PROCESS) && (binary_parity_product (BP_EM , BP_A_in) == BP_A_out)) 
			cout << "out : " << J_Pi_string (BP_A_out , J_A_out) << " " << vector_index_A_out << " , in : " << J_Pi_string (BP_A_in , J_A_in) 
			     << " , entrance channel : " << channels_tab_JPi_A_in(ic_entrance) << " " << EM_for_total_cross_section << L << " : " << CC_EM_NBMEs(as_index , EM_for_total_cross_section_index , iJPi_A_in , iJPi_A_out , i_entrance , L , iE) << endl;
		    }//if L!=0
		}//condition on L
	    }//loop L total/diff cross section
	}//loop L
    }
}








// calculations of the EM matrix elts < (J_i)_i_entrance || O_L || J_f >
void CC_radiative_capture::CC_EM_NBMEs_calc (
					     class GSM_vector &PSI_full , 
					     const class CC_target_projectile_composite_data &Tpc_data , 
					     const class array<class cluster_data> &cluster_data_tab , 
					     const bool is_it_nas_only , 
					     const enum EM_type EM , 
					     const class array<TYPE> &target_reduced_NBMEs , 
					     const class input_data_str &input_data_CC_Berggren , 
					     const class interaction_class &inter_data_basis , 
					     class nucleons_data &prot_data , 
					     class nucleons_data &neut_data , 
					     const unsigned int iE , 
					     const double E_total_CM , 
					     const TYPE &E , 
					     const class array<class CC_Hamiltonian_data> &CC_H_data_out_tab , 
					     const class array<class CC_state_class> &CC_state_out_tab ,
					     const class array<class CC_Hamiltonian_data> &CC_H_data_in_tab ,  
					     const class array<class CC_state_class> &CC_state_in_entrance_tab , 
					     class array<TYPE> &CC_EM_NBMEs)
{
  //// if true , the L_min/max are put to the L value for the total cross section
  //// the interferences between different L values disappear due to the orthogonality of the Wigner D-matrices
  //const bool is_total_cross_section_calculated = input_data.get_CC_is_total_cross_section_calculated;
  //const int L_for_total_cross_section = input_data.get_CC_EM_L_for_total_cross_section;

  const unsigned int N_JPi_A_in  = Tpc_data.get_N_JPi_A_in ();
  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();
  
  const class array<unsigned int> &N_entrance_channels_in_tab = Tpc_data.get_N_entrance_channels_tab ();

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      if (is_it_nas_only)
	{
	  cout << endl << endl << "Non-antisymmetrized   E[CM] : " << E_total_CM << " MeV" << " , E[COSM] : " << E << " MeV" << endl;
	  cout << "-------------------------------------------------------------------------------------------------------"<< endl;
	}
      else
	{
	  cout << endl << endl << "Antisymmetrized   E[CM] : " << E_total_CM << " MeV" << " , E[COSM] : " << E << " MeV" << endl;
	  cout << "--------------------------------------------------------------------------------------------------"<< endl;
	}
    }
  
  for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
    {	
      // final state

      const class CC_state_class &CC_state_out = CC_state_out_tab(iJPi_A_out);

      const class CC_Hamiltonian_data &CC_H_data_out = CC_H_data_out_tab(iJPi_A_out);
      
      for (unsigned int iJPi_A_in = 0 ; iJPi_A_in < N_JPi_A_in ; iJPi_A_in++)
	{
	  const unsigned int N_entrance_channels = N_entrance_channels_in_tab(iJPi_A_in);

	  const class CC_Hamiltonian_data &CC_H_data_in = CC_H_data_in_tab(iJPi_A_in);
      
	  for (unsigned int i_entrance = 0 ; i_entrance < N_entrance_channels ; i_entrance++)
	    {
	      // incoming state
	      const class CC_state_class &CC_state_in_entrance = CC_state_in_entrance_tab(iJPi_A_in , i_entrance);

	      //fill the CC_EM_NBMEs
	      CC_EM_NBMEs_calc_fixed_out_in_entrance (PSI_full , Tpc_data , cluster_data_tab , input_data_CC_Berggren , is_it_nas_only , iJPi_A_in , iJPi_A_out , EM , i_entrance , iE , 
						      CC_H_data_in , CC_state_in_entrance , CC_H_data_out ,  CC_state_out , prot_data , neut_data , inter_data_basis ,
						      target_reduced_NBMEs , CC_EM_NBMEs);

	    }//loop i_entrance
	}//loop on iJPi_A_in (J_i and M_i)
    }//loop on iJPi_A_out (J_f and M_f)
}































void CC_radiative_capture::EM_suboperators_intrinsic_MEs_calc (
							       const class interaction_class &inter_data_basis , 
							       class array<class cluster_data> &cluster_data_tab , 
							       const class array<TYPE> &CC_E_A_out_tab , 
							       class CC_target_projectile_composite_data &Tpc_data ,
							       class GSM_vector &PSI_full)
{
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
    
  const unsigned int EM_suboperator_number = EM_suboperator_type_number_determine ();

  const unsigned int cluster_number = cluster_data_tab.dimension (0);

  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();

  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();

  const class array<double> &E_total_tab = Tpc_data.get_E_total_tab ();

  const int n_holes_max = Tpc_data.get_n_holes_max ();
  
  const int n_scat_max = Tpc_data.get_n_scat_max ();
      
  const int E_relative_max_hw = Tpc_data.get_E_relative_max_hw ();

  const unsigned int N_energies = Tpc_data.get_N_energies ();

  // if true , the L_min/max are put to the L value for the total cross section
  // the interferences between different L values disappear due to the orthogonality of the Wigner D-matrices

  const enum CC_reaction_calculation_type CC_reaction_calculation = Tpc_data.get_CC_reaction_calculation ();
  
  const bool is_total_cross_section_calculated = (CC_reaction_calculation == TOTAL_CROSS_SECTION);

  const int L_for_total_cross_section = Tpc_data.get_L_for_total_cross_section ();

  const int L_limit = Tpc_data.get_radiative_capture_L_limit ();

  const bool is_it_HO_expansion = Tpc_data.get_radiative_capture_is_it_HO_expansion ();

  const bool is_it_longwavelength_approximation = Tpc_data.get_radiative_capture_is_it_longwavelength_approximation ();
     
  const class GSM_vector_helper_class dummy_helper;

  const double J_intrinsic_max = Jmax_intrinsic_projectile_determine ();

  const int l_intrinsic_max = make_int (2.0*J_intrinsic_max);
	  
  const int l_intrinsic_max_plus_one = l_intrinsic_max + 1;
  
  class array<TYPE> &EM_suboperator_intrinsic_NBMEs = Tpc_data.get_EM_suboperator_intrinsic_NBMEs ();
  
  // cluster intrinsic state
  for (unsigned int icp = 0 ; icp < cluster_number ; icp++)
    {      
      class cluster_data &data_cp = cluster_data_tab(icp);

      class nucleons_data &cluster_prot_data_HO_cp = data_cp.get_cluster_prot_data_HO ();
      class nucleons_data &cluster_neut_data_HO_cp = data_cp.get_cluster_neut_data_HO ();

      const unsigned int BP_cp = data_cp.get_BP_intrinsic ();

      const double Jcp = data_cp.get_J_intrinsic ();

      const double Mcp = Jcp;

      const int Zcp_cluster = data_cp.get_Z_cluster ();
      const int Ncp_cluster = data_cp.get_N_cluster ();

      const int n_holes_max_p_cp = cluster_prot_data_HO_cp.get_n_holes_max ();
      const int n_holes_max_n_cp = cluster_neut_data_HO_cp.get_n_holes_max ();
      
      const int n_scat_max_p_cp = cluster_prot_data_HO_cp.get_n_scat_max ();
      const int n_scat_max_n_cp = cluster_neut_data_HO_cp.get_n_scat_max ();

      const int n_scat_max_cp = min (n_scat_max , n_scat_max_p_cp + n_scat_max_n_cp);
      
      const int Ep_max_hw_cp = cluster_prot_data_HO_cp.get_E_max_hw ();
      const int En_max_hw_cp = cluster_neut_data_HO_cp.get_E_max_hw ();
      
      const int E_min_hw_cp = cluster_prot_data_HO_cp.get_E_min_hw () + cluster_neut_data_HO_cp.get_E_min_hw ();

      const int E_max_hw_cp = E_relative_max_hw + E_min_hw_cp;

      const enum space_type space_cp = space_determine (Zcp_cluster , Ncp_cluster);

      const class correlated_state_str PSI_cluster_qn_cp (Zcp_cluster , Ncp_cluster , BP_cp , Jcp , 0 , NADA , NADA , NADA , NADA , false);

      class GSM_vector_helper_class PSI_cluster_helper_cp (false , space_cp , TBME_inter , false , truncation_hw , truncation_ph ,
							   n_holes_max      , n_scat_max_cp   , E_max_hw_cp  , 
							   n_holes_max_p_cp , n_scat_max_p_cp , Ep_max_hw_cp ,
							   n_holes_max_n_cp , n_scat_max_n_cp , En_max_hw_cp , 
							   BP_cp , Mcp , true , cluster_prot_data_HO_cp , cluster_neut_data_HO_cp);

      class GSM_vector PSI_cluster_cp (PSI_cluster_helper_cp);

      PSI_cluster_cp.eigenvector_read_disk (true , true , PSI_cluster_qn_cp);
	    
      for (unsigned int ic = 0 ; ic < cluster_number ; ic++)
	{
	  class cluster_data &data_c = cluster_data_tab(ic);
 
	  const int Zc_cluster = data_c.get_Z_cluster ();
	  const int Nc_cluster = data_c.get_N_cluster ();

	  if ((Zcp_cluster == Zc_cluster) && (Ncp_cluster == Nc_cluster))
	    {
	      const double Jc = data_c.get_J_intrinsic ();

	      const double Mc = Jc;

	      const int Lmin = abs (make_int (Jc - Jcp));

	      const int Lmax_J = make_int (Jc + Jcp);

	      const int Lmax = min (Lmax_J , L_limit);
	      
	      for (int L = Lmin ; L <= Lmax ; L++)
		{
		  class nucleons_data &cluster_prot_data_HO_c = data_c.get_cluster_prot_data_HO ();
		  class nucleons_data &cluster_neut_data_HO_c = data_c.get_cluster_neut_data_HO ();
		  
		  const unsigned int BP_c = data_c.get_BP_intrinsic ();
	
		  const int n_holes_max_p_c = cluster_prot_data_HO_c.get_n_holes_max ();
		  const int n_holes_max_n_c = cluster_neut_data_HO_c.get_n_holes_max ();
		  
		  const int n_scat_max_p_c = cluster_prot_data_HO_c.get_n_scat_max ();
		  const int n_scat_max_n_c = cluster_neut_data_HO_c.get_n_scat_max ();

		  const int n_scat_max_c = min (n_scat_max , n_scat_max_p_c + n_scat_max_n_c);
	  
		  const int Ep_max_hw_c = cluster_prot_data_HO_c.get_E_max_hw ();
		  const int En_max_hw_c = cluster_neut_data_HO_c.get_E_max_hw ();
		  
		  const int E_min_hw_c = cluster_prot_data_HO_c.get_E_min_hw () + cluster_neut_data_HO_c.get_E_min_hw ();

		  const int E_max_hw_c = E_relative_max_hw + E_min_hw_c;

		  const enum space_type space_c = space_determine (Zc_cluster , Nc_cluster);

		  const class correlated_state_str PSI_cluster_qn_c (Zc_cluster , Nc_cluster , BP_c , Jc , 0 , NADA , NADA , NADA , NADA , false);

		  class GSM_vector_helper_class PSI_cluster_helper_c (false , space_c , TBME_inter , false , truncation_hw , truncation_ph ,
								      n_holes_max     , n_scat_max_c   , E_max_hw_c  , 
								      n_holes_max_p_c , n_scat_max_p_c , Ep_max_hw_c ,
								      n_holes_max_n_c , n_scat_max_n_c , En_max_hw_c , 
								      BP_c , Mc , true , cluster_prot_data_HO_c , cluster_neut_data_HO_c);

		  class GSM_vector PSI_cluster_c (PSI_cluster_helper_c);

		  PSI_cluster_c.eigenvector_read_disk (true , true , PSI_cluster_qn_c);
		  		  
		  bool are_configuration_SD_in_space_one_jump_tables_calculated = false;
	            
		  for (unsigned int EM_suboperator_index = 0 ; EM_suboperator_index < EM_suboperator_number ; EM_suboperator_index++)
		    {
		      const enum EM_suboperator_type EM_suboperator = EM_suboperator_type_from_index (EM_suboperator_index);

		      const unsigned int BP_EM = BP_EM_suboperator_determine (EM_suboperator , L);
		      // delta (quantum numbers are conserved)
  
		      if ((binary_parity_product (BP_c , BP_cp) == BP_EM) && (!is_total_cross_section_calculated || (L == L_for_total_cross_section)))
			{
			  if (!are_configuration_SD_in_space_one_jump_tables_calculated)
			    {
			      class GSM_vector_helper_class PSI_cluster_helper_c_full;
			      
			      PSI_cluster_helper_c_full.allocate_fill_without_MPI_parallelization (PSI_cluster_helper_c);
			      
			      configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , true , false , false , false ,
											   PSI_cluster_helper_c_full , PSI_cluster_helper_cp , dummy_helper ,
											   cluster_prot_data_HO_c , cluster_neut_data_HO_c);
			      
			      are_configuration_SD_in_space_one_jump_tables_calculated = true;			      
			    }
			  
			  for (int Lc = 0 ; Lc <= l_intrinsic_max_plus_one ; Lc++)
			    {	
			      if (is_it_longwavelength_approximation)
				{
				  const TYPE EM_suboperators_intrinsic_NBME = cluster::EM_suboperator_intrinsic_NBME_calc (EM_suboperator , NADA , L , Lc ,
															   is_it_longwavelength_approximation ,
															   is_it_HO_expansion , inter_data_basis ,
															   data_c , data_cp , PSI_cluster_c , PSI_cluster_cp ,
															   PSI_full);

				  if (THIS_PROCESS == MASTER_PROCESS) 
				    {
				      for (unsigned int iE = 0 ; iE < N_energies ; iE++)
					for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
					  EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , L , Lc , EM_suboperator_index) = EM_suboperators_intrinsic_NBME;
				    }
				}//test is_it_longwavelength_approximation true
			      else
				{
				  const unsigned int N_energies_splines = 10;
				      
				  const bool are_there_splines = (N_energies > N_energies_splines);

				  if (are_there_splines)
				    {
				      class array<double> E_total_tab_for_splines(N_energies_splines);

				      class array<TYPE> EM_suboperator_intrinsic_NBMEs_for_splines(N_energies_splines , N_JPi_A_out);

				      class array<TYPE> EM_suboperator_intrinsic_NBMEs_for_splines_1D(N_energies_splines);

				      for (unsigned int iE = 0 ; iE < N_energies_splines ; iE++)
					{
					  const double E_total_in_i_entrance = E_total_tab(iE);

					  for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
					    {
					      const TYPE E_out = CC_E_A_out_tab(iJPi_A_out);

					      const TYPE q = (E_total_in_i_entrance - E_out) / hbar_c;
					      
					      const TYPE EM_suboperators_intrinsic_NBME = cluster::EM_suboperator_intrinsic_NBME_calc (EM_suboperator , q , L , Lc ,
																       is_it_longwavelength_approximation ,
																       is_it_HO_expansion , inter_data_basis ,
																       data_c , data_cp ,
																       PSI_cluster_c , PSI_cluster_cp , PSI_full);

					      if (THIS_PROCESS == MASTER_PROCESS)
						{
						  EM_suboperator_intrinsic_NBMEs_for_splines(iE , iJPi_A_out) = EM_suboperators_intrinsic_NBME;

						  cout << "E.in[entrance]" << E_total_in_i_entrance << " : EM_suboperators intrinsic NBME calculated for splines:" << EM_suboperators_intrinsic_NBME << endl;
						}
					    }//loop iJPi_A_out
					}//loop iE

				      if (THIS_PROCESS == MASTER_PROCESS)
					{
					  for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
					    {
					      for (unsigned int iE = 0 ; iE < N_energies_splines ; iE++)
						EM_suboperator_intrinsic_NBMEs_for_splines_1D(iE) = EM_suboperator_intrinsic_NBMEs_for_splines(iE , iJPi_A_out);

					      const class splines_class<TYPE> EM_suboperator_intrinsic_NBMEs_splines(E_total_tab_for_splines , EM_suboperator_intrinsic_NBMEs_for_splines_1D); 

					      for (unsigned int iE = 0 ; iE < N_energies ; iE++)
						{
						  const double E_total_in_i_entrance = E_total_tab(iE);

						  const TYPE EM_suboperators_intrinsic_NBME = EM_suboperator_intrinsic_NBMEs_splines(E_total_in_i_entrance);

						  EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , L , Lc , EM_suboperator_index) = EM_suboperators_intrinsic_NBME;
						  cout << "E.in[entrance]" << E_total_in_i_entrance << " : EM_suboperators intrinsic NBME calculated from splines:" << EM_suboperators_intrinsic_NBME << endl;
						}//loop iE
					    }//loop iJPi_A_out
					}//test MASTER_PROCESS
				    }//test are_there_splines
				  else
				    {
				      for (unsigned int iE = 0 ; iE < N_energies ; iE++)
					{
					  const double E_total_in_i_entrance = E_total_tab(iE);
					      
					  for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
					    {
					      const TYPE &E_out = CC_E_A_out_tab(iJPi_A_out);

					      const TYPE q = (E_total_in_i_entrance - E_out) / hbar_c;
						  
					      const TYPE EM_suboperators_intrinsic_NBME = cluster::EM_suboperator_intrinsic_NBME_calc (EM_suboperator , q , L , L ,
																       is_it_longwavelength_approximation ,
																       is_it_HO_expansion , inter_data_basis ,
																       data_c , data_cp ,
																       PSI_cluster_c , PSI_cluster_cp , PSI_full);
						  
					      if (THIS_PROCESS == MASTER_PROCESS)
						{ 
						  EM_suboperator_intrinsic_NBMEs(iE , iJPi_A_out , ic , icp , L , Lc , EM_suboperator_index) = EM_suboperators_intrinsic_NBME;
						  cout << "iJPi_A_out=" << iJPi_A_out << " iE_is_" << iE << " : target reduced NBME calculated:" << EM_suboperators_intrinsic_NBME << endl;
						}
					    }//loop iJPi_A_out
					}//loop iE
				    }//test are_there_splines
				}//test is_it_longwavelength_approximation false
			    }//loop Lc
			}//loop test BP L
		    }//loop EM_suboperator_index
		}//loop L
	    }//test Z N cluster
	}//loop ic
    }//loop icp
    
#ifdef UseMPI
  if (is_it_MPI_parallelized) EM_suboperator_intrinsic_NBMEs.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}
  








void CC_radiative_capture::iterative_calc (
					   const class CC_target_projectile_composite_data &Tpc_data , 
					   const class input_data_str &input_data_CC_Berggren , 
					   const class interaction_class &inter_data_basis , 
					   const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
					   const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
					   const class array<class cluster_data> &cluster_data_tab , 
					   class array<class cluster_data> &cluster_data_CC_Berggren_tab , 
					   class nucleons_data &prot_data_CC_Berggren , 
					   class nucleons_data &neut_data_CC_Berggren , 		
					   class nucleons_data &prot_data , 
					   class nucleons_data &neut_data , 
					   class TBMEs_class &TBMEs_pn , 
					   class array<TYPE> &CC_E_A_out_tab , 
					   class array<TYPE> &CC_EM_NBMEs , 
					   class GSM_vector &PSI_full)
{
  cout.precision (15);
    
  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();
  
  const unsigned int N_JPi_A_in  = Tpc_data.get_N_JPi_A_in ();
  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();

  const unsigned int N_entrance_channels_max = Tpc_data.get_N_entrance_channels_max ();

  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();

  const unsigned int N_energies = Tpc_data.get_N_energies ();
  
  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();

  const bool is_it_one_nucleon_case = Tpc_data.get_is_it_one_nucleon_case ();

  const enum storage_type Hamiltonian_storage = input_data_CC_Berggren.get_Hamiltonian_storage ();

  const bool is_it_full_or_partial_storage = is_it_full_or_partial_storage_determine (Hamiltonian_storage);
  
  const enum EM_type EM_for_total_cross_section = Tpc_data.get_EM_for_total_cross_section ();

  const enum CC_reaction_calculation_type CC_reaction_calculation = Tpc_data.get_CC_reaction_calculation ();
  
  const bool is_total_cross_section_calculated = (CC_reaction_calculation == TOTAL_CROSS_SECTION);

  const int L_limit = Tpc_data.get_radiative_capture_L_limit ();
  
  const bool full_common_vectors_used_in_file = input_data_CC_Berggren.get_full_common_vectors_used_in_file ();
  
  //:::// for the moment there is a loop over all final states of the composite system
  //:::// to choose one in particular , one has to check if it exists in the table J_A_tab[]

  //================================== get the number of EM matrix elts ==================================//

  const class array<double> &J_A_in_tab  = Tpc_data.get_J_A_in_tab ();
  const class array<double> &J_A_out_tab = Tpc_data.get_J_A_out_tab ();
  
  const double J_max_all_in  = J_A_in_tab.max ();
  const double J_max_all_out = J_A_out_tab.max ();
  
  const int L_max_all_J = make_int (J_max_all_in + J_max_all_out);

  const int L_max_all = min (L_max_all_J , L_limit);

  const int L_max_all_plus_one = L_max_all + 1;
  
  const class array<double> &E_total_tab = Tpc_data.get_E_total_tab ();

  const class array<double> &E_total_CM_tab = Tpc_data.get_E_total_CM_tab ();

  //=================== calculations of the EM matrix elts < (J_i)_i_entrance || O_L || J_f > ====================//

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const unsigned int cluster_number = (!is_it_one_nucleon_case) ? (cluster_data_tab.dimension (0)) : (1);

  for (unsigned int ic = 0 ; ic < cluster_number ; ic++)
    {
      const int Z_cluster_max = (!is_it_one_nucleon_case) ? (Z_cluster_max_determine (cluster_data_tab)) : (1);
      const int N_cluster_max = (!is_it_one_nucleon_case) ? (N_cluster_max_determine (cluster_data_tab)) : (1);
      
      const int Z_cluster_number = Z_cluster_max + 1;
      const int N_cluster_number = N_cluster_max + 1;

      class array<class nucleons_data> prot_data_one_cluster_less_tab(Z_cluster_number , N_cluster_number);
      class array<class nucleons_data> neut_data_one_cluster_less_tab(Z_cluster_number , N_cluster_number);

      data_one_projectile_less_alloc_calc (is_it_full_or_partial_storage , is_it_one_nucleon_case , TBME_inter , truncation_hw , truncation_ph , prot_data , neut_data , projectile_tab ,
					   cluster_data_tab , prot_data_one_cluster_less_tab , neut_data_one_cluster_less_tab);

      class array<class CC_state_class> CC_state_out_tab(N_JPi_A_out);
      
      class array<class CC_Hamiltonian_data> CC_H_data_in_tab (N_JPi_A_in);
      class array<class CC_Hamiltonian_data> CC_H_data_out_tab(N_JPi_A_out);
      
      CC_state_out_tab_alloc_calc (Tpc_data , inter_data_basis , input_data_CC_Berggren , 
				   prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , cluster_data_tab , cluster_data_CC_Berggren_tab ,
				   prot_data_CC_Berggren , neut_data_CC_Berggren , prot_data , neut_data , TBMEs_pn , CC_H_data_out_tab , CC_state_out_tab , CC_E_A_out_tab);

      class array<TYPE> target_reduced_NBMEs(2 , N_energies , N_JPi_A_out , N_target_projectile_states , N_target_projectile_states , L_max_all_plus_one);

      target_reduced_NBMEs = 0.0;

      if (!is_total_cross_section_calculated || (EM_for_total_cross_section == ELECTRIC))
	target_reduced_NBMEs_calc (PSI_full , ELECTRIC , full_common_vectors_used_in_file , Tpc_data , inter_data_basis ,
				   prot_data_one_cluster_less_tab , neut_data_one_cluster_less_tab , CC_E_A_out_tab , target_reduced_NBMEs);

      if (!is_total_cross_section_calculated || (EM_for_total_cross_section == MAGNETIC))
	target_reduced_NBMEs_calc (PSI_full , MAGNETIC , full_common_vectors_used_in_file , Tpc_data , inter_data_basis ,
				   prot_data_one_cluster_less_tab , neut_data_one_cluster_less_tab , CC_E_A_out_tab , target_reduced_NBMEs);

      // loop on the composite energy in the lab frame
      for (unsigned int iE = 0 ; iE < N_energies ; iE++)
	{
	  // energy of the composite in the lab frame [MeV]

	  const double E_total = E_total_tab(iE);

	  const double E_total_CM = E_total_CM_tab(iE);

	  class array<class CC_state_class> CC_state_in_entrance_tab(N_JPi_A_in , N_entrance_channels_max);
     
	  CC_state_in_entrance_tab_alloc_calc (Tpc_data , inter_data_basis , input_data_CC_Berggren , 
					       prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , cluster_data_tab , cluster_data_CC_Berggren_tab , iE , E_total ,
					       prot_data_CC_Berggren , neut_data_CC_Berggren , prot_data , neut_data , TBMEs_pn , CC_H_data_in_tab , CC_state_in_entrance_tab);

	  if (!is_total_cross_section_calculated || (EM_for_total_cross_section == ELECTRIC))
	    {
	      CC_EM_NBMEs_calc (PSI_full , Tpc_data , cluster_data_tab , true , ELECTRIC , target_reduced_NBMEs , input_data_CC_Berggren , inter_data_basis , prot_data , neut_data , 
				iE , E_total_CM , E_total , CC_H_data_out_tab , CC_state_out_tab , CC_H_data_in_tab , CC_state_in_entrance_tab , CC_EM_NBMEs);

	      CC_EM_NBMEs_calc (PSI_full , Tpc_data , cluster_data_tab , false , ELECTRIC , target_reduced_NBMEs , input_data_CC_Berggren , inter_data_basis , prot_data , neut_data , 
				iE , E_total_CM , E_total , CC_H_data_out_tab , CC_state_out_tab , CC_H_data_in_tab , CC_state_in_entrance_tab , CC_EM_NBMEs);
	    }

	  if (!is_total_cross_section_calculated || (EM_for_total_cross_section == MAGNETIC))
	    {
	      CC_EM_NBMEs_calc (PSI_full , Tpc_data , cluster_data_tab , true , MAGNETIC , target_reduced_NBMEs , input_data_CC_Berggren , inter_data_basis , prot_data , neut_data , 
				iE , E_total_CM , E_total , CC_H_data_out_tab , CC_state_out_tab , CC_H_data_in_tab , CC_state_in_entrance_tab , CC_EM_NBMEs);

	      CC_EM_NBMEs_calc (PSI_full , Tpc_data , cluster_data_tab , false , MAGNETIC , target_reduced_NBMEs , input_data_CC_Berggren , inter_data_basis , prot_data , neut_data , 
				iE , E_total_CM , E_total , CC_H_data_out_tab , CC_state_out_tab , CC_H_data_in_tab , CC_state_in_entrance_tab , CC_EM_NBMEs);
	    }
	}
    }
}









complex<double> CC_radiative_capture::angular_factor_calc (
							   const int L , 
							   const double M_L , 
							   const int P , 
							   const double k_cross_section , 
							   const double k_gamma , 
							   const double theta_gamma , 
							   const double phi_gamma)
{
  const complex<double> I (0.0 , 1.0);

  const complex<double> I_pow_L = pow (I , L);

  const double sqrt_factor = sqrt (2.0 * M_PI * (2.0 * L + 1.0) * (L + 1.0) / L);

  const double k_factor = pow (k_gamma , L) / k_cross_section;

  const double factorial_factor = P / double_factorial (2.0 * L + 1);

  const complex<double> Wigner_D_matrix_elt = Wigner_D (L , M_L , P , phi_gamma , theta_gamma , 0.0);

  const complex<double> angular_factor = I_pow_L * sqrt_factor * k_factor * factorial_factor * Wigner_D_matrix_elt;

  return angular_factor;
}










void CC_radiative_capture::angular_factor_tabs_calc (
						     const double k_cross_section , 
						     const double E_i , 
						     const class array<TYPE> &CC_E_A_out_tab , 
						     const class array<double> &theta_gamma_tab , 
						     const class array<double> &phi_gamma_tab , 
						     class array<complex<double> > &angular_factor_plus_tab , 
						     class array<complex<double> > &angular_factor_minus_tab)
{
  const unsigned int N_JPi_A = angular_factor_plus_tab.dimension (0);

  const unsigned int N_theta_gamma = angular_factor_plus_tab.dimension (3);

  const unsigned int N_phi_gamma = angular_factor_plus_tab.dimension (4);

  const int L_max_all = angular_factor_plus_tab.dimension (1) - 1;

  const int iM_L_max_all = 2 * L_max_all;

  for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A ; iJPi_A_out++)
    {
      const double E_A_out = real_dc (CC_E_A_out_tab(iJPi_A_out));

      // momentum of the emitted photon
      const double k_gamma = (E_i - E_A_out) / hbar_c;

      for (int L = 1 ; L <= L_max_all ; L++) 
	{
	  for (int iM_L = 0 ; iM_L <= iM_L_max_all ; iM_L++)
	    {
	      const int M_L = iM_L - L_max_all;	
	      for (unsigned int theta_gamma_index = 0 ; theta_gamma_index < N_theta_gamma ; theta_gamma_index++)
		{
		  const double theta_gamma = theta_gamma_tab(theta_gamma_index);

		  for (unsigned int phi_gamma_index = 0 ; phi_gamma_index < N_phi_gamma ; phi_gamma_index++)
		    {
		      const double phi_gamma = phi_gamma_tab(phi_gamma_index);

		      angular_factor_plus_tab(iJPi_A_out , L , iM_L , theta_gamma_index , phi_gamma_index) = 
			angular_factor_calc (L , M_L , 1 , k_cross_section , k_gamma , theta_gamma , phi_gamma);

		      angular_factor_minus_tab(iJPi_A_out , L , iM_L , theta_gamma_index , phi_gamma_index) = 
			angular_factor_calc (L , M_L , -1 , k_cross_section , k_gamma , theta_gamma , phi_gamma);
		    }//loop phi_gamma
		}//loop theta_gamma
	    }//loop M_L
	}//loop L
    }//loop iJPi_A_out
}





void CC_radiative_capture::Wigner_Eckhart_factor_tab_calc (
							   const class CC_target_projectile_composite_data &Tpc_data , 
							   const enum EM_type EM , 
							   class array<double> &Wigner_Eckhart_factor_tab)
{
  const class array<unsigned int> &BP_A_in_tab  = Tpc_data.get_BP_A_in_tab ();
  const class array<unsigned int> &BP_A_out_tab = Tpc_data.get_BP_A_out_tab ();

  const class array<double> &J_A_in_tab  = Tpc_data.get_J_A_in_tab ();
  const class array<double> &J_A_out_tab = Tpc_data.get_J_A_out_tab ();

  const unsigned int N_JPi_A_in  = Tpc_data.get_N_JPi_A_in ();
  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();
  
  const int L_max_all    = Wigner_Eckhart_factor_tab.dimension (4) - 1;
  const int iM_L_max_all = Wigner_Eckhart_factor_tab.dimension (5) - 1;

  for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
    {
      // total final angular momentum , binary parity , energy and vector index

      const double J_A_out = J_A_out_tab(iJPi_A_out);

      const unsigned int BP_A_out = BP_A_out_tab(iJPi_A_out);

      const int iM_A_out_max = make_int (2.0*J_A_out);

      for (int iM_A_out = 0 ; iM_A_out <= iM_A_out_max ; iM_A_out++)
	{	
	  const double M_A_out = iM_A_out - J_A_out;

	  for (unsigned int iJPi_A_in = 0 ; iJPi_A_in < N_JPi_A_in ; iJPi_A_in++)
	    {
	      const double J_A_in = J_A_in_tab(iJPi_A_in);
	      
	      const unsigned int BP_A_in = BP_A_in_tab(iJPi_A_in);

	      const int iM_A_in_max = make_int (2.0*J_A_in);

	      for (int iM_A_in = 0 ; iM_A_in <= iM_A_in_max ; iM_A_in++)
		{	
		  const double M_A_in = iM_A_in - J_A_in;

		  for (int L = 0 ; L <= L_max_all ; L++) 
		    {
		      for (int iM_L = 0 ; iM_L <= iM_L_max_all ; iM_L++)
			{
			  const int M_L = iM_L - L_max_all;	

			  const unsigned int BP_EM_L = BP_EM_determine (EM , L);

			  if ((binary_parity_product (BP_A_in , BP_EM_L) == BP_A_out) && (abs (M_L) <= L))
			    {
			      const double Wigner_Eckhart_factor = 
				Wigner_3j (J_A_out , L , J_A_in , -M_A_out , M_L , M_A_in) * minus_one_pow (J_A_out - M_A_out); 

			      Wigner_Eckhart_factor_tab(iJPi_A_in , iM_A_in , iJPi_A_out , iM_A_out , L , iM_L) = Wigner_Eckhart_factor;
			    }//tests ML , BP
			}//loop on iM_L
		    }//loop on L
		}//loop on M_A_in
	    }//loop on iJPi_A_in
	}//loop on M_A_out
    }//loop on iJPi_A_out
}







void CC_radiative_capture::product_CGs_l_terms_Coulomb_phase_shifts_tab_calc (	
									      const class CC_target_projectile_composite_data &Tpc_data , 
									      const double J_intrinsic_projectile , 
									      const double eta_cross_section , 
									      class array<complex<double> > &product_CGs_l_terms_Coulomb_phase_shifts_tab)
{
  const complex<double> I(0 , 1);

  const double sqrt_four_Pi = 3.544907701811032;

  const unsigned int iT_entrance = Tpc_data.get_entrance_target_index ();
  
  const unsigned int N_JPi_A_in = Tpc_data.get_N_JPi_A_in ();

  const int iM_intrinsic_projectile_number = make_int (2.0*J_intrinsic_projectile + 1.0);

  const class array<double> &J_target_tab = Tpc_data.get_J_target_tab ();
  
  const class array<unsigned int> &BP_A_in_tab = Tpc_data.get_BP_A_in_tab ();

  const class array<unsigned int> &N_channels_in_tab = Tpc_data.get_N_channels_in_tab ();

  const class array<double> &J_A_in_tab = Tpc_data.get_J_A_in_tab ();

  const class array<unsigned int> &N_entrance_channels_in_tab = Tpc_data.get_N_entrance_channels_tab ();

  const class array<class CC_channel_class> &channels_in_tab = Tpc_data.get_channels_in_tab ();

  const class array<unsigned int> &entrance_JPi_channels_indices = Tpc_data.get_entrance_JPi_channels_indices ();

  // angular momentum and energy of the gs of the target (in lab frame)
  const double J_T = J_target_tab(iT_entrance);

  // in loop on: J_f , M_f
  for (unsigned int iJPi_A_in = 0 ; iJPi_A_in < N_JPi_A_in ; iJPi_A_in++)
    {
      const unsigned int BP_A_in = BP_A_in_tab(iJPi_A_in);

      const double J_A_in = J_A_in_tab(iJPi_A_in);
      
      const unsigned int N_channels_JPi_A_in = N_channels_in_tab(iJPi_A_in);

      const unsigned int N_entrance_channels_in = N_entrance_channels_in_tab(iJPi_A_in);

      // get the CC_channel_class for this J_i

      class array<class CC_channel_class> channels_JPi_A_in_tab (N_channels_JPi_A_in);

      JPi_channels_tab_BP_J_fill (channels_in_tab , BP_A_in , J_A_in , channels_JPi_A_in_tab);

      const int iM_A_in_max = make_int (2.0*J_A_in);

      // in loop on: J_f , M_f , J_i
      for (int iM_A_in = 0 ; iM_A_in <= iM_A_in_max ; iM_A_in++)
	{
	  const double M_A_in = iM_A_in - J_A_in;

	  // in loop on: J_f , M_f , J_i , M_i
	  for (unsigned int i_entrance  = 0 ; i_entrance  < N_entrance_channels_in ; i_entrance++)
	    {
	      const unsigned int ic_entrance = entrance_JPi_channels_indices(iJPi_A_in , i_entrance);

	      const class CC_channel_class &channel_entrance = channels_JPi_A_in_tab(ic_entrance);
	      
	      const int lc_entrance = channel_entrance.get_LCM_projectile ();
	      
	      const double jc_entrance = channel_entrance.get_J_projectile ();

	      const double hat_lc_entrance = hat (lc_entrance);
	      
	      const complex<double> sigma_lc_entrance = sigma_l_calc (lc_entrance  , eta_cross_section);

	      const complex<double> exp_I_sigma_lc_entrance = exp (I * sigma_lc_entrance);

	      const complex<double> hat_Coulomb_phase_shift_pow_term= sqrt_four_Pi * pow (I , lc_entrance) * hat_lc_entrance  * exp_I_sigma_lc_entrance;

	      for (int iM_intrinsic_projectile = 0 ; iM_intrinsic_projectile < iM_intrinsic_projectile_number ; iM_intrinsic_projectile++)
		{
		  const double M_intrinsic_projectile = iM_intrinsic_projectile - J_intrinsic_projectile;

		  const double M_T = M_A_in - M_intrinsic_projectile;

		  const double CG_lc_s_jc_entrance_M_intrinsic_projectile = Clebsch_Gordan (lc_entrance  , 0 , J_intrinsic_projectile , M_intrinsic_projectile , jc_entrance  , M_intrinsic_projectile);

		  const double CG_J_Tc_jc_entrance_JM_in = Clebsch_Gordan (J_T , M_T , jc_entrance  , M_intrinsic_projectile , J_A_in , M_A_in);

		  product_CGs_l_terms_Coulomb_phase_shifts_tab(iM_intrinsic_projectile , iM_A_in , iJPi_A_in , i_entrance) = hat_Coulomb_phase_shift_pow_term * CG_lc_s_jc_entrance_M_intrinsic_projectile * CG_J_Tc_jc_entrance_JM_in;
		}//loop iM_intrinsic_proj
	    }//loop i_entrance
	}//loop on M_A_in
    }//loop on iJPi_A_in
}








// differential cross section calc
void CC_radiative_capture::differential_cross_section_calc (
							    const class CC_target_projectile_composite_data &Tpc_data , 
							    const class array<TYPE> &CC_EM_NBMEs , 
							    const class array<TYPE> &CC_E_A_out_tab , 
							    const class array<double> &theta_gamma_tab , 
							    const class array<double> &phi_gamma_tab , 
							    const unsigned int iE , 
							    const double E_total_CM , 
							    const TYPE &E , 
							    const enum EM_type EM , 
							    class array<double> &differential_cross_section_tab)
{
  const double CM_to_COSM_kinetic_factor = Tpc_data.get_CM_to_COSM_kinetic_factor ();
  
  const unsigned int iT_entrance = Tpc_data.get_entrance_target_index ();
  
  const unsigned int N_JPi_A_in  = Tpc_data.get_N_JPi_A_in ();
  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();
  
  const unsigned int N_theta_gamma = theta_gamma_tab.dimension (0);

  const unsigned int N_phi_gamma = phi_gamma_tab.dimension (0);
  
  const class array<double> &J_target_tab = Tpc_data.get_J_target_tab ();
  
  const class array<unsigned int> &BP_A_in_tab  = Tpc_data.get_BP_A_in_tab ();
  const class array<unsigned int> &BP_A_out_tab = Tpc_data.get_BP_A_out_tab ();
  
  const class array<double> &J_A_in_tab  = Tpc_data.get_J_A_in_tab ();
  const class array<double> &J_A_out_tab = Tpc_data.get_J_A_out_tab ();

  // if true , the L_min/max are put to the L value for the total cross section
  // the interferences between different L values disappear due to the orthogonality of the Wigner D-matrices

  const enum CC_reaction_calculation_type CC_reaction_calculation = Tpc_data.get_CC_reaction_calculation ();
  
  const bool is_total_cross_section_calculated = (CC_reaction_calculation == TOTAL_CROSS_SECTION);

  const int L_for_total_cross_section = Tpc_data.get_L_for_total_cross_section ();

  // angular momentum and energy of the gs of the target (in lab frame)
  // momentum[fm^-1] of the projectile
  // total initial energy in the lab frame
  // kinematic factor projectile+target

  const enum particle_type projectile = Tpc_data.get_entrance_projectile ();	

  const int Z_target = Tpc_data.get_Z_target ();
  
  const double kinetic_factor_entrance_projectile_CM   = Tpc_data.get_kinetic_factor_entrance_projectile_CM ();
  const double kinetic_factor_entrance_projectile_COSM = Tpc_data.get_kinetic_factor_entrance_projectile_COSM ();
  
  const double J_T = J_target_tab(iT_entrance);

  const double E_i = real_dc (E);
  
  const double e_cross_section = E_total_CM*CM_to_COSM_kinetic_factor;

  const double k_cross_section = sqrt (kinetic_factor_entrance_projectile_COSM * e_cross_section);
  
  const double eta_cross_section = real_dc (eta_calc (false , projectile , Z_target , kinetic_factor_entrance_projectile_COSM , k_cross_section));
  
  const int L_limit = Tpc_data.get_radiative_capture_L_limit ();

  // J_intrinsic_projectile is the intrinsic spin of the projectile

  const double J_intrinsic_projectile = J_intrinsic_projectile_determine (projectile);

  const int iM_intrinsic_projectile_number = make_int (2.0*J_intrinsic_projectile + 1.0);

  const class array<unsigned int> &N_entrance_channels_in_tab = Tpc_data.get_N_entrance_channels_tab ();
  
  const unsigned int N_entrance_channels_max = N_entrance_channels_in_tab.max ();
  
  const double J_max_all_in  = J_A_in_tab.max ();
  const double J_max_all_out = J_A_out_tab.max ();
  
  const int M_A_in_number_max  = make_int (2.0*J_max_all_in + 1.0);
  const int M_A_out_number_max = make_int (2.0*J_max_all_out + 1.0);
  
  const int L_max_all_J = make_int (J_max_all_in + J_max_all_out);

  const int L_max_all = min (L_max_all_J , L_limit);

  const int L_max_all_plus_one = L_max_all+  1;
  
  const int iM_L_max_all = 2 * L_max_all;

  const int iM_L_max_all_plus_one = iM_L_max_all+  1;
  
  const unsigned int EM_index = EM_index_determine (EM);

  // ================================== angular factors ================================== //
  // depends on J_f , L , M_L , L' , theta , phi

  class array<complex<double> > angular_factor_plus_tab (N_JPi_A_out , L_max_all_plus_one , iM_L_max_all_plus_one , N_theta_gamma , N_phi_gamma);
  class array<complex<double> > angular_factor_minus_tab(N_JPi_A_out , L_max_all_plus_one , iM_L_max_all_plus_one , N_theta_gamma , N_phi_gamma);

  angular_factor_plus_tab  = 0.0;
  angular_factor_minus_tab = 0.0;

  angular_factor_tabs_calc (k_cross_section , E_i , CC_E_A_out_tab , theta_gamma_tab , phi_gamma_tab , angular_factor_plus_tab , angular_factor_minus_tab);

  // ================================== product of Wigner_3j ================================== //
  // depends on J_A_out , M_A_out , J_A_in , M_A_in , L , M_L , J_A_inp , Lp
  class array<double> Wigner_Eckhart_factor_tab(N_JPi_A_in , M_A_in_number_max , N_JPi_A_out , M_A_out_number_max , L_max_all_plus_one , iM_L_max_all_plus_one);
  
  Wigner_Eckhart_factor_tab = 0.0;

  Wigner_Eckhart_factor_tab_calc (Tpc_data , EM , Wigner_Eckhart_factor_tab);

  // ================================== product of CGs ================================== //
  class array<complex<double> > product_CGs_l_terms_Coulomb_phase_shifts_tab(iM_intrinsic_projectile_number , M_A_in_number_max , N_JPi_A_in , N_entrance_channels_max);

  product_CGs_l_terms_Coulomb_phase_shifts_tab = 0.0;

  product_CGs_l_terms_Coulomb_phase_shifts_tab_calc (Tpc_data , J_intrinsic_projectile , eta_cross_section , product_CGs_l_terms_Coulomb_phase_shifts_tab);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int theta_gamma_index = 0 ; theta_gamma_index < N_theta_gamma ; theta_gamma_index++)
    {
      for (unsigned int phi_gamma_index = 0 ; phi_gamma_index < N_phi_gamma ; phi_gamma_index++)
	{
	  for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
	    {
	      // total final angular momentum , disk parity , energy and vector index
	      const double J_A_out = J_A_out_tab(iJPi_A_out);

	      const unsigned int BP_A_out = BP_A_out_tab(iJPi_A_out);

	      const double E_A_out = real_dc (CC_E_A_out_tab(iJPi_A_out));

	      // momentum of the emitted photon
	      const double k_gamma = (E_i - E_A_out) / hbar_c;

	      // global factor , implicit dependence in J_f because of k_gamma
	      // One uses the formula of S. B. Dubovichenko, A. V. Dzhazairov-Kakhramanov, Fiz. Elem. Chastits. At. Yadra 28, 1529 (1997) (see also T. Tombrello et al., Phys. Rev. 131, 2582 (1963)). 
	      // A factor 4 is added in the denominator from the formula above in order to have the same normalization as in Descouvemont P and Baye D 2010 Rep. Prog. Phys. 73 036301.
	      // The overall factor in Descouvemont P and Baye D 2010 Rep. Prog. Phys. 73 036301 is: Pi[from sigma].8 Pi[from U matrix]/(4 Pi)[from M[EL] matrix elements] = 2.Pi .
	      // One has to integrate over phi[gamma], theta[gamma] and sum over polarization to get the same result, which provides a factor 2.(4.Pi/(2L+1)) = 8.Pi/(2L+1) .
	      // The overall factor here is: 1/(8 Pi)[from sigma].2 Pi.(2L + 1)[from angular factor].8.Pi/(2L + 1)[from D matrices and polarization] = 2.Pi .
	      // This 2.Pi factor is also obtained in C. Angulo et al. Nucl. Phys. A 656 (1999) 3-183.
	      
	      const double factor = 1.0 / (8.0 * M_PI) * (k_gamma / k_cross_section) * fine_struct_const * (kinetic_factor_entrance_projectile_CM * hbar_c / 2.0) * (1.0 / (2.0 * J_intrinsic_projectile + 1)) * (1.0 / (2.0 * J_T + 1));
	      
	      if (factor <= 0.0) continue;

	      const int iM_A_out_max = make_int (2.0*J_A_out);

	      double differential_cross_section_J_A_out_nas_only = 0.0;
	      double differential_cross_section_J_A_out_as = 0.0;

	      // in loop on: J_f
	      for (int iM_A_out = 0 ; iM_A_out <= iM_A_out_max ; iM_A_out++)
		{	
		  const double M_A_out = iM_A_out - J_A_out;

		  // in loop on: theta_gamma_index , phi_gamma_index , J_f , M_f
		  for (int iM_A_in = 0 ; iM_A_in < M_A_in_number_max ; iM_A_in++)
		    {
		      // in loop on: theta_gamma_index , phi_gamma_index , J_f , M_f , M_i
		      for (int iM_intrinsic_projectile = 0 ; iM_intrinsic_projectile < iM_intrinsic_projectile_number ; iM_intrinsic_projectile++)
			{
			  // in loop on: theta_gamma_index , phi_gamma_index , J_f , M_f , M_i , iM_intrinsic_proj
			  for (int P = -1 ; P <= 1 ; P += 2)
			    {
			      const class array<complex<double> > &angular_factor_tab = (P == -1) ? (angular_factor_minus_tab) : (angular_factor_plus_tab);

			      complex<double> differential_cross_section_amplitude_part_nas_only = 0.0;

			      complex<double> differential_cross_section_amplitude_part_as = 0.0;

			      // in loop on: theta_gamma_index , phi_gamma_index , J_f , M_f , J_i , M_i , iM_intrinsic_projectile , P
			      for (int L = 0 ; L <= L_max_all ; L++)
				{
				  if (!is_total_cross_section_calculated || (L == L_for_total_cross_section))
				    {
				      // an E0 transition cannot happen alone
				      if (L != 0)
					{
					  const unsigned int BP_EM_L = BP_EM_determine (EM , L);

					  // in loop on: theta_gamma_index , phi_gamma_index , J_f , M_f , M_i , iM_intrinsic_projectile , P , L
					  for (unsigned int iJPi_A_in = 0 ; iJPi_A_in < N_JPi_A_in ; iJPi_A_in++)
					    {
					      const double J_A_in = J_A_in_tab(iJPi_A_in);

					      const unsigned int BP_A_in = BP_A_in_tab(iJPi_A_in);

					      const int L_min = abs (make_int (J_A_in - J_A_out));

					      const int L_max = make_int (J_A_in + J_A_out);

					      if ((binary_parity_product (BP_A_in , BP_EM_L) == BP_A_out) && (L >= L_min) && (L <= L_max)) 
						{
						  const double M_A_in = iM_A_in - J_A_in;	

						  const int M_L = make_int (M_A_out - M_A_in);

						  if ((rint (abs (M_A_in) - J_A_in) <= 0.0) && (abs (M_L) <= L))
						    {
						      const int iM_L = M_L + L_max_all;

						      const complex<double> angular_factor = angular_factor_tab(iJPi_A_out , L , iM_L , theta_gamma_index , phi_gamma_index);
						      const unsigned int N_entrance_channels_in = N_entrance_channels_in_tab(iJPi_A_in);

						      const double Wigner_Eckhart_factor = Wigner_Eckhart_factor_tab(iJPi_A_in , iM_A_in , iJPi_A_out , iM_A_out , L , iM_L);

						      complex<double> differential_cross_section_amplitude_subpart_nas_only = 0.0;

						      complex<double> differential_cross_section_amplitude_subpart_as = 0.0;

						      // in loop on: theta_gamma_index , phi_gamma_index , J_f , M_f , M_i , iM_intrinsic_projectile , P , L , iJPi_A_in
						      for (unsigned int i_entrance = 0 ; i_entrance < N_entrance_channels_in ; i_entrance++)
							{
							  const complex<double> product_CGs_l_terms_Coulomb_phase_shift = product_CGs_l_terms_Coulomb_phase_shifts_tab(iM_intrinsic_projectile , iM_A_in , iJPi_A_in , i_entrance);
							  
							  const complex<double> CC_EM_matrix_nas_only = CC_EM_NBMEs(0 , EM_index , iJPi_A_in , iJPi_A_out , i_entrance , L , iE);
							  
							  const complex<double> CC_EM_matrix_as = CC_EM_NBMEs(1 , EM_index , iJPi_A_in , iJPi_A_out , i_entrance , L , iE); 

							  differential_cross_section_amplitude_subpart_nas_only += product_CGs_l_terms_Coulomb_phase_shift*CC_EM_matrix_nas_only;
							  
							  differential_cross_section_amplitude_subpart_as += product_CGs_l_terms_Coulomb_phase_shift*CC_EM_matrix_as;
							}//loop i_entrance

						      const complex<double> angular_product = angular_factor*Wigner_Eckhart_factor;

						      differential_cross_section_amplitude_subpart_nas_only *= angular_product;

						      differential_cross_section_amplitude_subpart_as *= angular_product;

						      differential_cross_section_amplitude_part_nas_only += differential_cross_section_amplitude_subpart_nas_only;
						      differential_cross_section_amplitude_part_as += differential_cross_section_amplitude_subpart_as;

						    }//tests M_A_in , ML
						}//tests L , BP
					    }//loop on iJPi_A_in
					}//if L!=0
				    }//test L
				}//loop L
			      
			      differential_cross_section_J_A_out_nas_only += factor * norm (differential_cross_section_amplitude_part_nas_only);

			      differential_cross_section_J_A_out_as += factor * norm (differential_cross_section_amplitude_part_as);

			    }//loop P
			}//loop iM_intrinsic_proj
		    }//loop on M_A_in
		}//loop M_A_out
	      
	      differential_cross_section_tab(0 , EM_index , iE , iJPi_A_out , theta_gamma_index , phi_gamma_index) = differential_cross_section_J_A_out_nas_only;
	      
	      differential_cross_section_tab(1 , EM_index , iE , iJPi_A_out , theta_gamma_index , phi_gamma_index) = differential_cross_section_J_A_out_as;
	      
	    }//loop iJPi_A_out
	}//loop phi_gamma
    }//loop theta_gamma
}









void CC_radiative_capture::all_cross_sections_calc_print (
							  const class CC_target_projectile_composite_data &Tpc_data , 
							  const class array<TYPE> &CC_E_A_out_tab , 
							  const class array<TYPE> &CC_EM_NBMEs)
{
  //================================ differential cross section calc =====================================//
  //
  const enum EM_type EM_for_total_cross_section = Tpc_data.get_EM_for_total_cross_section ();

  const enum CC_reaction_calculation_type CC_reaction_calculation = Tpc_data.get_CC_reaction_calculation ();
  
  const bool is_total_cross_section_calculated = (CC_reaction_calculation == TOTAL_CROSS_SECTION);
  
  const unsigned int N_energies = Tpc_data.get_N_energies ();

  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();

  const class array<double> &E_total_tab = Tpc_data.get_E_total_tab ();

  const class array<double> &E_total_CM_tab = Tpc_data.get_E_total_CM_tab ();

  const unsigned int N_theta_gamma = Tpc_data.get_N_theta_gamma ();

  const unsigned int N_phi_gamma = Tpc_data.get_N_phi_gamma ();
  
  class array<double> theta_gamma_tab(N_theta_gamma);

  class array<double> weights_theta_gamma_tab(N_theta_gamma);
  
  class array<double> phi_gamma_tab(N_phi_gamma);

  class array<double> weights_phi_gamma_tab(N_phi_gamma);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , M_PI , theta_gamma_tab , weights_theta_gamma_tab);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , 2.0 * M_PI , phi_gamma_tab , weights_phi_gamma_tab);

  class array<double> differential_cross_section_tab(2 , 2 , N_energies , N_JPi_A_out , N_theta_gamma , N_phi_gamma);

  differential_cross_section_tab = 0.0;

  const unsigned int first_iE = basic_first_index_determine_for_MPI (N_energies , NUMBER_OF_PROCESSES , THIS_PROCESS); 
  const unsigned int last_iE = basic_last_index_determine_for_MPI (N_energies , NUMBER_OF_PROCESSES , THIS_PROCESS); 

  for (unsigned int iE = 0 ; iE < N_energies ; ++iE)
    {
      if ((iE >= first_iE) && (iE <= last_iE))
	{
	  // energy of the composite in the lab frame [MeV]
	  const double E_total = E_total_tab(iE);

	  const double E_total_CM = E_total_CM_tab(iE);

	  if (!is_total_cross_section_calculated || (EM_for_total_cross_section == ELECTRIC))
	    differential_cross_section_calc (Tpc_data , CC_EM_NBMEs , CC_E_A_out_tab , theta_gamma_tab , phi_gamma_tab , iE , E_total_CM , E_total , ELECTRIC , differential_cross_section_tab);

	  if (!is_total_cross_section_calculated || (EM_for_total_cross_section == MAGNETIC))
	    differential_cross_section_calc (Tpc_data , CC_EM_NBMEs , CC_E_A_out_tab , theta_gamma_tab , phi_gamma_tab , iE , E_total_CM , E_total , MAGNETIC , differential_cross_section_tab);
	}
    }

#ifdef UseMPI
  if (is_it_MPI_parallelized) differential_cross_section_tab.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);	
#endif

  if (THIS_PROCESS == MASTER_PROCESS)
    cross_sections_calc_print (Tpc_data , theta_gamma_tab , weights_theta_gamma_tab , phi_gamma_tab , weights_phi_gamma_tab , differential_cross_section_tab);
}









void CC_radiative_capture::cross_sections_calc_print (
						      const class CC_target_projectile_composite_data &Tpc_data , 
						      const class array<double> &theta_gamma_tab , 
						      const class array<double> &weights_theta_gamma_tab , 
						      const class array<double> &phi_gamma_tab , 
						      const class array<double> &weights_phi_gamma_tab , 
						      const class array<double> &differential_cross_section_tab)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in CC_radiative_capture::cross_sections_calc_print");

  const enum EM_type EM_for_total_cross_section = Tpc_data.get_EM_for_total_cross_section ();

  const double CM_to_COSM_kinetic_factor = Tpc_data.get_CM_to_COSM_kinetic_factor ();

  const enum CC_reaction_calculation_type CC_reaction_calculation = Tpc_data.get_CC_reaction_calculation ();
  
  const bool is_total_cross_section_calculated = (CC_reaction_calculation == TOTAL_CROSS_SECTION);

  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();

  const unsigned int N_theta_gamma = theta_gamma_tab.dimension (0);

  const unsigned int N_phi_gamma = phi_gamma_tab.dimension (0);

  const unsigned int N_energies = Tpc_data.get_N_energies ();

  const class array<unsigned int> &BP_A_out_tab = Tpc_data.get_BP_A_out_tab ();

  const class array<double> &J_A_out_tab = Tpc_data.get_J_A_out_tab ();

  const class array<unsigned int> &vector_index_A_out_tab = Tpc_data.get_vector_index_A_out_tab ();

  const class array<double> &E_total_CM_tab = Tpc_data.get_E_total_CM_tab ();
  
  class array<complex<double> > cross_section_J_A_out_theta_nas_only_tab(N_theta_gamma);

  class array<complex<double> > cross_section_J_A_out_theta_as_tab(N_theta_gamma);
		  
  cout << "---------------------------------------------------------------------------------------------------------------------" << endl << endl;
  
  for (unsigned int EM_index = 0 ; EM_index <= 1 ; EM_index++)
    {
      const enum EM_type EM_from_index = EM_determine_from_index (EM_index);

      const string EM_from_index_letter = EM_letter_determine (EM_from_index);

      if (!is_total_cross_section_calculated || (EM_for_total_cross_section == EM_from_index)) 
	{
	  if (EM_from_index_letter == "E") cout << endl << "Electric radiative capture" << endl;
	  if (EM_from_index_letter == "M") cout << endl << "Magnetic radiative capture" << endl;
	  cout << "--------------------------" << endl;

	  const string astrophysical_factor_nas_only_file_name = "astrophysical_factor_total_cross_section_" + EM_from_index_letter + "_non_antisymmetrized.dat";

	  const string astrophysical_factor_as_file_name = "astrophysical_factor_total_cross_section_" + EM_from_index_letter + "_antisymmetrized.dat";

	  ofstream astrophysical_factor_nas_only_file (astrophysical_factor_nas_only_file_name.c_str ());

	  ofstream astrophysical_factor_as_file (astrophysical_factor_as_file_name.c_str ());

	  for (unsigned int iE = 0 ; iE < N_energies ; iE++)
	    {
	      const double E_total_CM = E_total_CM_tab(iE);

	      // sum_Jf sigma_Jf with sigma_Jf = int_Omega diff_sigma_J_f / diff_Omega

	      double total_cross_section_nas_only = 0.0;

	      double total_cross_section_as = 0.0;

	      // total final angular momentum , disk parity , energy and vector index
	      for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < N_JPi_A_out ; iJPi_A_out++)
		{
		  const double J_A_out = J_A_out_tab(iJPi_A_out);

		  const unsigned int BP_A_out = BP_A_out_tab(iJPi_A_out);

		  const unsigned int vector_index_A_out = vector_index_A_out_tab(iJPi_A_out);
		  
		  cross_section_J_A_out_theta_nas_only_tab = 0.0;

		  cross_section_J_A_out_theta_as_tab = 0.0;

		  // ================================== integration ================================== //
		  double total_cross_section_J_A_out_nas_only = 0.0 , total_cross_section_J_A_out_as = 0.0;

		  for (unsigned int theta_gamma_index = 0 ; theta_gamma_index < N_theta_gamma ; theta_gamma_index++)
		    {
		      const double theta_gamma = theta_gamma_tab(theta_gamma_index);

		      const double weight_theta_gamma = weights_theta_gamma_tab(theta_gamma_index);

		      double cross_section_J_A_out_theta_nas_only = 0.0;

		      double cross_section_J_A_out_theta_as = 0.0;

		      for (unsigned int phi_gamma_index = 0 ; phi_gamma_index < N_phi_gamma ; phi_gamma_index++)
			{
			  const double weight_phi_gamma = weights_phi_gamma_tab(phi_gamma_index);

			  cross_section_J_A_out_theta_nas_only += differential_cross_section_tab(0 , EM_index , iE , iJPi_A_out , theta_gamma_index , phi_gamma_index) * weight_phi_gamma;

			  cross_section_J_A_out_theta_as += differential_cross_section_tab(1 , EM_index , iE , iJPi_A_out , theta_gamma_index , phi_gamma_index) * weight_phi_gamma;
			}//loop phi_gamma

		      cross_section_J_A_out_theta_nas_only_tab(theta_gamma_index) = cross_section_J_A_out_theta_nas_only;

		      cross_section_J_A_out_theta_as_tab(theta_gamma_index) = cross_section_J_A_out_theta_as;

		      const double angular_weight = weight_theta_gamma * sin (theta_gamma);

		      total_cross_section_J_A_out_nas_only += cross_section_J_A_out_theta_nas_only * angular_weight;

		      total_cross_section_J_A_out_as += cross_section_J_A_out_theta_as * angular_weight;
		    }//loop theta_gamma

		  // ================================== sum over J_f ================================== //
		  total_cross_section_nas_only += total_cross_section_J_A_out_nas_only;

		  total_cross_section_as += total_cross_section_J_A_out_as;

		  if (!is_total_cross_section_calculated)
		    {
		      const string differential_cross_section_file_nas_only_J_f_name = "radiative_capture_differential_cross_section_nas_only_final_state_" + make_string<enum EM_type> (EM_from_index) 
			+ "_" + J_Pi_vector_index_string_for_file_name (BP_A_out , J_A_out , vector_index_A_out) + ".dat";

		      ofstream differential_cross_section_file_nas_only_J_f (differential_cross_section_file_nas_only_J_f_name.c_str ());

		      differential_cross_section_file_nas_only_J_f.precision (15);

		      for (unsigned int theta_gamma_index = 0 ; theta_gamma_index < N_theta_gamma ; theta_gamma_index++)
			differential_cross_section_file_nas_only_J_f << theta_gamma_tab(theta_gamma_index) << " " << real_dc (cross_section_J_A_out_theta_nas_only_tab(theta_gamma_index)) << " " 
								     << imag (cross_section_J_A_out_theta_nas_only_tab(theta_gamma_index)) << endl;
		  
		      const string differential_cross_section_file_as_J_f_name = "radiative_capture_differential_cross_section_as_final_state_" + make_string<enum EM_type> (EM_from_index) 
			+ "_" + J_Pi_vector_index_string_for_file_name (BP_A_out , J_A_out , vector_index_A_out) + ".dat";

		      ofstream differential_cross_section_file_as_J_f (differential_cross_section_file_as_J_f_name.c_str ());

		      differential_cross_section_file_as_J_f.precision (15);

		      for (unsigned int theta_gamma_index = 0 ; theta_gamma_index < N_theta_gamma ; theta_gamma_index++)
			differential_cross_section_file_as_J_f << theta_gamma_tab(theta_gamma_index) << " " << real_dc (cross_section_J_A_out_theta_as_tab(theta_gamma_index)) << " " 
							       << imag (cross_section_J_A_out_theta_as_tab(theta_gamma_index)) << endl;
		    }

		  const double total_cross_section_J_A_out_nas_only_microbarn = total_cross_section_J_A_out_nas_only * 1E4;

		  const double total_cross_section_J_A_out_as_microbarn = total_cross_section_J_A_out_as * 1E4;
	      
		  cout << "Final state : " << J_Pi_vector_index_string (BP_A_out , J_A_out , vector_index_A_out) << endl;
		  cout << "Partial radiative capture cross section : non-antisymmetrized = " << total_cross_section_J_A_out_nas_only_microbarn << " microbarn" << endl;
		  cout << "Partial radiative capture cross section : antisymmetrized     = " << total_cross_section_J_A_out_as_microbarn << " microbarn" << endl << endl;
		}

	      // 1 microbarn = 0.0001 fm^2

	      const double total_cross_section_nas_only_microbarn = total_cross_section_nas_only * 1E4;

	      const double total_cross_section_as_microbarn = total_cross_section_as * 1E4;

	      // ================================== astrophysical factor ================================== //

	      const double kinetic_factor_entrance_projectile_COSM = Tpc_data.get_kinetic_factor_entrance_projectile_COSM ();

	      const enum particle_type entrance_projectile = Tpc_data.get_entrance_projectile ();

	      const int Z_target = Tpc_data.get_Z_target ();
	      
	      const double e_cross_section = E_total_CM*CM_to_COSM_kinetic_factor;

	      const double k_cross_section = sqrt (kinetic_factor_entrance_projectile_COSM * e_cross_section);
	      
	      const double eta_cross_section = real_dc (eta_calc (false , entrance_projectile , Z_target , kinetic_factor_entrance_projectile_COSM , k_cross_section));

	      const double energy_factor = e_cross_section * exp (2.0 * M_PI * eta_cross_section);

	      const double astrophysical_factor_nas_only_barn_eV = total_cross_section_nas_only_microbarn * energy_factor;

	      const double astrophysical_factor_as_barn_eV = total_cross_section_as_microbarn * energy_factor;

	      astrophysical_factor_nas_only_file << E_total_CM << " " << e_cross_section << " " << astrophysical_factor_nas_only_barn_eV << " " << total_cross_section_nas_only_microbarn << endl;
	      astrophysical_factor_as_file       << E_total_CM << " " << e_cross_section << " " << astrophysical_factor_as_barn_eV       << " " << total_cross_section_as_microbarn << endl;
	      
	      cout << "E[COSM] = " << e_cross_section << " MeV" << endl << endl;
	      cout << "total radiative capture cross section : non-antisymmetrized = " << total_cross_section_nas_only_microbarn << " microbarn" << endl;
	      cout << "total radiative capture cross section : antisymmetrized     = " << total_cross_section_as_microbarn       << " microbarn" << endl << endl;

	      cout << "astrophysical factor : non-antisymmetrized = " << astrophysical_factor_nas_only_barn_eV << " microbarn eV" << endl; 
	      cout << "astrophysical factor : antisymmetrized     = " << astrophysical_factor_as_barn_eV       << " microbarn eV" << endl << endl; 
	    }
	}
    }
}















void CC_radiative_capture::calc_print (
				       const class input_data_str &input_data_CC_Berggren , 
				       const class interaction_class &inter_data_basis , 
				       const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
				       const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
				       class nucleons_data &prot_data_CC_Berggren , 
				       class nucleons_data &neut_data_CC_Berggren , 
				       class array<class cluster_data> &cluster_data_CC_Berggren_tab , 
				       class nucleons_data &prot_data , 
				       class nucleons_data &neut_data , 
				       class array<class cluster_data> &cluster_data_tab , 
				       class CC_target_projectile_composite_data &Tpc_data , 
				       class TBMEs_class &TBMEs_pn)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Radiative capture cross sections" << endl;
      cout <<         "--------------------------------" << endl << endl;
    }

  const unsigned int N_JPi_A_in = Tpc_data.get_N_JPi_A_in ();

  const unsigned int N_JPi_A_out = Tpc_data.get_N_JPi_A_out ();

  const unsigned int N_energies = Tpc_data.get_N_energies ();
  
  const int L_limit = Tpc_data.get_radiative_capture_L_limit ();

  const class array<unsigned int> &N_entrance_channels_in_tab = Tpc_data.get_N_entrance_channels_tab ();

  const unsigned int i_entrance_max_all = N_entrance_channels_in_tab.max ();

  const class array<double> &J_A_in_tab  = Tpc_data.get_J_A_in_tab ();
  const class array<double> &J_A_out_tab = Tpc_data.get_J_A_out_tab ();
  
  const double J_max_all_in  = J_A_in_tab.max ();
  const double J_max_all_out = J_A_out_tab.max ();
  
  const int L_max_all_J = make_int (J_max_all_in + J_max_all_out);

  const int L_max_all = min (L_max_all_J , L_limit);

  const int L_max_all_plus_one = L_max_all + 1;
  
  // table which contains the EM matrix elts given by <J_f || O_L || (J_i)_i_ent>

  class array<TYPE> CC_E_A_out_tab(N_JPi_A_out);

  class array<TYPE> CC_EM_NBMEs(2 , 2 , N_JPi_A_in , N_JPi_A_out , i_entrance_max_all , L_max_all_plus_one , N_energies);

  CC_E_A_out_tab = 0.0;

  CC_EM_NBMEs = 0.0;

  class GSM_vector PSI_full;
  
  EM_suboperators_intrinsic_MEs_calc (inter_data_basis , cluster_data_tab , CC_E_A_out_tab , Tpc_data , PSI_full);

  //================================== get the number of EM matrix elts ==================================//

  iterative_calc (Tpc_data , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
		  cluster_data_tab , cluster_data_CC_Berggren_tab , prot_data_CC_Berggren , neut_data_CC_Berggren ,
		  prot_data , neut_data , TBMEs_pn , CC_E_A_out_tab , CC_EM_NBMEs , PSI_full);

  all_cross_sections_calc_print (Tpc_data , CC_E_A_out_tab , CC_EM_NBMEs);
}




