#include "../CC_include/CC_include_def.h"


using namespace string_routines;
using namespace inputs_misc;
using namespace a_dagger_nucleon_helper;
using namespace A_dagger_cluster_helper;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_waves_HF_MSDHF_potentials_calculations;


void CC_observables_common::data_one_nucleon_less_alloc_calc (
							      const bool is_it_full_or_partial_storage ,
							      const enum interaction_type inter ,
							      const bool truncation_hw , 
							      const bool truncation_ph ,  
							      const class nucleons_data &prot_data , 
							      const class nucleons_data &neut_data , 
							      const class array<enum particle_type> &projectile_tab , 
							      class array<class nucleons_data> &prot_data_one_nucleon_less_tab , 
							      class array<class nucleons_data> &neut_data_one_nucleon_less_tab)
{
  const double nucleus_mass = prot_data.get_nucleus_mass ();

  const int Z = prot_data.get_N_nucleons ();
  const int N = neut_data.get_N_nucleons ();

  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  const unsigned int N_target_projectile_states = projectile_tab.dimension (0);

  class array<bool> are_projectile_data_stored(2 , 2);

  are_projectile_data_stored = false;

  for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
    {
      const enum particle_type projectile = projectile_tab(iT);

      const int Z_projectile = Z_projectile_determine (projectile);
      const int N_projectile = N_projectile_determine (projectile);

      if (!are_projectile_data_stored(Z_projectile , N_projectile))
	{
	  const int Z_one_nucleon_less = Z - Z_projectile;
	  const int N_one_nucleon_less = N - N_projectile;
	  
	  const int Zval_one_nucleon_less = Zval - Z_projectile;
	  const int Nval_one_nucleon_less = Nval - N_projectile;

	  const double prot_mass_for_calc = prot_data.get_effective_mass_for_calc ();
	  const double neut_mass_for_calc = neut_data.get_effective_mass_for_calc ();

	  const double nucleon_mass_for_calc = mass_projectile_determine (projectile , prot_mass_for_calc , neut_mass_for_calc);

	  const bool is_it_COSM = is_it_COSM_determine (inter);

	  const double nucleus_mass_one_nucleon_less = (!is_it_COSM) ? (nucleus_mass - nucleon_mass_for_calc) : (nucleus_mass);

	  class nucleons_data &prot_data_one_nucleon_less = prot_data_one_nucleon_less_tab(Z_projectile , N_projectile);
	  class nucleons_data &neut_data_one_nucleon_less = neut_data_one_nucleon_less_tab(Z_projectile , N_projectile);

	  prot_data_one_nucleon_less.initialize_constants_from_other_nucleus (false , Z_one_nucleon_less , N_one_nucleon_less , nucleus_mass_one_nucleon_less , prot_data);
	  neut_data_one_nucleon_less.initialize_constants_from_other_nucleus (false , Z_one_nucleon_less , N_one_nucleon_less , nucleus_mass_one_nucleon_less , neut_data);
	  
	  prot_data_one_nucleon_less.alloc_copy_one_body_data_tables_E_min_max_hw (prot_data);
	  neut_data_one_nucleon_less.alloc_copy_one_body_data_tables_E_min_max_hw (neut_data);

	  if (Zval_one_nucleon_less > 0)
	    {
	      configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , prot_data_one_nucleon_less);
	      
	      SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , prot_data_one_nucleon_less , false);
	      
	      prot_data_one_nucleon_less.configuration_SD_in_in_space_BPin_iMin_tables_init (true);

	      prot_data_one_nucleon_less.configuration_SD_inter_to_include_tables_init (true);

	      prot_data_one_nucleon_less.configuration_SD_out_in_space_BPout_iMout_tables_init (true);
      
	      if (is_it_full_or_partial_storage) configuration_SD_in_space_one_jump_in_to_out::one_jump_tables_alloc_calc_pp_nn (false , false , false , false , false , truncation_hw , truncation_ph , prot_data_one_nucleon_less);	  
			      
	      configuration_SD_in_space_one_jump_out_to_in::one_jump_tables_alloc_calc_pp_nn (false , false , false , false , false , truncation_hw , truncation_ph , prot_data_one_nucleon_less);	  
	    }

	  if (Nval_one_nucleon_less > 0)
	    {
	      configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , neut_data_one_nucleon_less);

	      SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , neut_data_one_nucleon_less , false);
	      
	      neut_data_one_nucleon_less.configuration_SD_in_in_space_BPin_iMin_tables_init (true);

	      neut_data_one_nucleon_less.configuration_SD_inter_to_include_tables_init (true);
      
	      neut_data_one_nucleon_less.configuration_SD_out_in_space_BPout_iMout_tables_init (true);
	      
	      if (is_it_full_or_partial_storage) configuration_SD_in_space_one_jump_in_to_out::one_jump_tables_alloc_calc_pp_nn (false , false , false , false , false , truncation_hw , truncation_ph , neut_data_one_nucleon_less);	  
			      
	      configuration_SD_in_space_one_jump_out_to_in::one_jump_tables_alloc_calc_pp_nn (false , false , false , false , false , truncation_hw , truncation_ph , neut_data_one_nucleon_less);
	    }

	  are_projectile_data_stored(Z_projectile , N_projectile) = true;
	}
    }
}







void CC_observables_common::target_projectile_PSI_HO_one_nucleon_calc (
								       const class input_data_str &input_data_CC_Berggren , 
								       const class CC_Hamiltonian_data &CC_H_data ,
								       const class CC_state_class &CC_state , 
								       const class array<class vector_class<complex<double> > > &CC_HO_overlaps ,
								       class nucleons_data &prot_data , 
								       class nucleons_data &neut_data , 
								       class GSM_vector &PSI_HO)
{
  const double CC_average_n_scat_target_projectile_max = input_data_CC_Berggren.get_CC_average_n_scat_target_projectile_max ();

  const class GSM_vector_helper_class &PSI_HO_helper = PSI_HO.get_GSM_vector_helper ();

  const unsigned int N_channels_JPi_A = CC_state.get_N_channels ();

  const double J = CC_state.get_J ();

  const double M = PSI_HO_helper.get_M ();

  const class array<class CC_channel_class> &channels_tab_JPi_A = CC_state.get_channels_tab ();

  const class array<bool> &is_it_forbidden_channel_tab = CC_H_data.get_is_it_forbidden_channel_tab ();

  PSI_HO = 0.0;

  // composite state (it has to be read in files)
  // it corresponds to the [a^+ Tc]_M^J
  
  class array<class GSM_vector> Vc_tab(NUMBER_OF_THREADS);

  for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++) Vc_tab(i_thread).allocate_fill (PSI_HO);

  for (unsigned int ic = 0 ; ic < N_channels_JPi_A ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab_JPi_A(ic);

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const class nucleons_data &data_tau_c = (projectile_c == PROTON) ? (prot_data) : (neut_data);	

      const int Z_Tc = channel_c.get_Z_Tc ();
      const int N_Tc = channel_c.get_N_Tc ();

      const class array<class vector_class<complex<double> > > &HO_overlaps_tau_c = data_tau_c.get_HO_overlaps ();

      const class nlj_table<unsigned int> &shells_indices_tau_c = data_tau_c.get_shells_indices ();

      const complex<double> E_Tc = channel_c.get_E_Tc ();

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const double jc = channel_c.get_J_projectile ();

      const double J_Tc = channel_c.get_J_Tc ();

      const class lj_table<int> &nmax_lj_c = data_tau_c.get_nmax_lj_tab ();

      const int lc = channel_c.get_LCM_projectile ();

      const int nmax_c = nmax_lj_c (lc , jc);

      const unsigned int BP_Tc = channel_c.get_BP_Tc ();

      const unsigned int vector_index_Tc = channel_c.get_vector_index_Tc ();

      const class nlj_table<bool> &is_it_valence_shell_tab_c = data_tau_c.get_is_it_valence_shell_tab ();

      const class nlj_table<unsigned int> &shells_indices_c = data_tau_c.get_shells_indices ();

      const class array<class nlj_struct> &shells_qn_c = data_tau_c.get_shells_quantum_numbers ();

      const class vector_class<complex<double> > &CC_HO_overlaps_c = CC_HO_overlaps(ic);

      class correlated_state_str PSI_qn_c (Z_Tc , N_Tc , BP_Tc , J_Tc , vector_index_Tc , E_Tc , NADA , NADA , NADA , false);

      // projection of the composite state in the HO basis

      // for each Berggren state
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
      for (int nc = 0 ; nc <= nmax_c ; nc++) 
	{
	  if (is_it_valence_shell_tab_c (nc , lc , jc))
	    {
	      const unsigned int shell_index_c = shells_indices_c(nc , lc , jc);

	      const class nlj_struct &shell_qn_c = shells_qn_c(shell_index_c);

	      const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	      const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	      if (!is_it_forbidden_channel_tab(ic , nc) && (real_average_n_scat_c < CC_average_n_scat_target_projectile_max))
		{
		  const unsigned int this_thread = OpenMP_thread_number_determine ();

		  const unsigned int sc = shells_indices_tau_c(nc , lc , jc);

		  const class vector_class<complex<double> > &HO_overlaps_sc = HO_overlaps_tau_c(sc);

#ifdef TYPEisDOUBLECOMPLEX
		  const TYPE uc_HO_nc_overlap = HO_overlaps_sc*CC_HO_overlaps_c;
#endif
		      
#ifdef TYPEisDOUBLE
		  const TYPE uc_HO_nc_overlap = real (HO_overlaps_sc*CC_HO_overlaps_c);
#endif

		  const string a_dagger_PSI_c_coupled_file_name = PSI_OUT_coupled_to_J_file_name_a_dagger_nucleon_determine (false , "a_dagger_nucleon" , nc , lc , jc , projectile_c , PSI_qn_c , J , M);
		  // build the composite state from a file

		  class GSM_vector &Vc = Vc_tab(this_thread);
		  Vc.read_disk (false , false , a_dagger_PSI_c_coupled_file_name);

#ifdef UseOpenMP
#pragma omp critical
#endif 			
		  PSI_HO += uc_HO_nc_overlap*Vc;
		}
	    }
	}
    }
}








void CC_observables_common::data_one_cluster_less_alloc_calc (
							      const bool is_it_full_or_partial_storage , 
							      const enum interaction_type inter , 
							      const bool truncation_hw , 
							      const bool truncation_ph ,  
							      const class nucleons_data &prot_data , 
							      const class nucleons_data &neut_data , 
							      const class array<class cluster_data> &cluster_data_tab , 
							      class array<class nucleons_data> &prot_data_one_cluster_less_tab , 
							      class array<class nucleons_data> &neut_data_one_cluster_less_tab)
{
  const double nucleus_mass = prot_data.get_nucleus_mass ();

  const int Z = prot_data.get_N_nucleons ();
  const int N = neut_data.get_N_nucleons ();

  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  const unsigned int cluster_number = cluster_data_tab.dimension (0);

  for (unsigned int ic = 0 ; ic < cluster_number ; ic++)
    {
      const class cluster_data &data_c = cluster_data_tab(ic);

      const int Z_cluster = data_c.get_Z_cluster ();
      const int N_cluster = data_c.get_N_cluster ();

      const int Z_one_cluster_less = Z - Z_cluster; 
      const int N_one_cluster_less = N - N_cluster; 

      const int Zval_one_cluster_less = Zval - Z_cluster;
      const int Nval_one_cluster_less = Nval - N_cluster;
      
      const double cluster_mass_for_calc = data_c.get_cluster_mass_for_calc ();

      const bool is_it_COSM = is_it_COSM_determine (inter);

      const double nucleus_mass_one_cluster_less = (!is_it_COSM) ? (nucleus_mass - cluster_mass_for_calc) : (nucleus_mass);

      class nucleons_data &prot_data_one_cluster_less = prot_data_one_cluster_less_tab(Z_cluster , N_cluster);
      class nucleons_data &neut_data_one_cluster_less = neut_data_one_cluster_less_tab(Z_cluster , N_cluster);

      prot_data_one_cluster_less.initialize_constants_from_other_nucleus (false , Z_one_cluster_less , N_one_cluster_less , nucleus_mass_one_cluster_less , prot_data);
      neut_data_one_cluster_less.initialize_constants_from_other_nucleus (false , Z_one_cluster_less , N_one_cluster_less , nucleus_mass_one_cluster_less , neut_data);

      prot_data_one_cluster_less.alloc_copy_one_body_data_tables_E_min_max_hw (prot_data);
      neut_data_one_cluster_less.alloc_copy_one_body_data_tables_E_min_max_hw (neut_data);

      if (Zval_one_cluster_less > 0)
	{
	  configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , prot_data_one_cluster_less);
	  
	  SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , prot_data_one_cluster_less , false);
	  
	  prot_data_one_cluster_less.configuration_SD_in_in_space_BPin_iMin_tables_init (true);

	  prot_data_one_cluster_less.configuration_SD_inter_to_include_tables_init (true);
      
	  prot_data_one_cluster_less.configuration_SD_out_in_space_BPout_iMout_tables_init (true);
	      
	  if (is_it_full_or_partial_storage) configuration_SD_in_space_one_jump_in_to_out::one_jump_tables_alloc_calc_pp_nn (false , false , false , false , false , truncation_hw , truncation_ph , prot_data_one_cluster_less);	  
	  
	  configuration_SD_in_space_one_jump_out_to_in::one_jump_tables_alloc_calc_pp_nn (false , false , false , false , false , truncation_hw , truncation_ph , prot_data_one_cluster_less);
	}

      if (Nval_one_cluster_less > 0)
	{
	  configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , neut_data_one_cluster_less);

	  SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , neut_data_one_cluster_less , false);
	  
	  neut_data_one_cluster_less.configuration_SD_in_in_space_BPin_iMin_tables_init (true);

	  neut_data_one_cluster_less.configuration_SD_inter_to_include_tables_init (true);
      
	  neut_data_one_cluster_less.configuration_SD_out_in_space_BPout_iMout_tables_init (true);
	  
	  if (is_it_full_or_partial_storage) configuration_SD_in_space_one_jump_in_to_out::one_jump_tables_alloc_calc_pp_nn (false , false , false , false , false , truncation_hw , truncation_ph , neut_data_one_cluster_less);	  
	  
	  configuration_SD_in_space_one_jump_out_to_in::one_jump_tables_alloc_calc_pp_nn (false , false , false , false , false , truncation_hw , truncation_ph , neut_data_one_cluster_less);
	}
    }	
}











void CC_observables_common::target_projectile_PSI_HO_cluster_calc (
								   const class input_data_str &input_data_CC_Berggren ,
								   const class array<class cluster_data> &cluster_data_tab ,  
								   const class CC_Hamiltonian_data &CC_H_data ,
								   const class CC_state_class &CC_state , 
								   const class array<class vector_class<complex<double> > > &CC_HO_overlaps , 
								   class GSM_vector &PSI_HO)
{
  const double CC_average_n_scat_target_projectile_max = input_data_CC_Berggren.get_CC_average_n_scat_target_projectile_max ();

  const class GSM_vector_helper_class &PSI_HO_helper = PSI_HO.get_GSM_vector_helper ();

  const unsigned int N_channels_JPi_A = CC_state.get_N_channels ();

  const double J = CC_state.get_J ();

  const double M = PSI_HO_helper.get_M ();

  const class array<class CC_channel_class> &channels_tab_JPi_A = CC_state.get_channels_tab ();
  
  const class array<bool> &is_it_forbidden_channel_tab = CC_H_data.get_is_it_forbidden_channel_tab ();

  PSI_HO = 0.0;

  // composite state (it has to be read in files)
  // it corresponds to the [a^+ Tc]_M^J

  class array<class GSM_vector> Vc_tab(NUMBER_OF_THREADS);

  for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++) Vc_tab(i_thread).allocate_fill (PSI_HO);

  for (unsigned int ic = 0 ; ic < N_channels_JPi_A ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab_JPi_A(ic);

      const enum particle_type projectile_c = channel_c.get_projectile ();

      const class cluster_data &data_c = get_cluster_data (projectile_c , cluster_data_tab);

      const int Z_Tc = channel_c.get_Z_Tc ();
      const int N_Tc = channel_c.get_N_Tc ();

      const class nlj_table<class vector_class<complex<double> > > &HO_overlaps_cluster_CM_c = data_c.get_HO_overlaps_cluster_CM ();

      const int Z_projectile_c = channel_c.get_Z_projectile ();
      const int N_projectile_c = channel_c.get_N_projectile ();
      const int A_projectile_c = channel_c.get_A_projectile ();

      const int LCM_projectile_c = channel_c.get_LCM_projectile ();

      const complex<double> E_Tc = channel_c.get_E_Tc ();

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const double J_projectile_c = channel_c.get_J_projectile ();

      const double J_Tc = channel_c.get_J_Tc ();

      const class nlj_table<bool> &cluster_CM_S_matrix_poles_c = data_c.get_cluster_CM_S_matrix_poles ();

      const class lj_table<int> &Nmax_cluster_CM_tab_c = data_c.get_Nmax_cluster_CM_tab ();

      const int NCM_max_LCM_projectile_c = Nmax_cluster_CM_tab_c(LCM_projectile_c , J_projectile_c);

      const class nlj_table<complex<double> > &cluster_CM_E_tab_c = data_c.get_cluster_CM_E_tab ();

      const unsigned int BP_projectile_c = channel_c.get_BP_projectile ();

      const unsigned int BP_Tc = channel_c.get_BP_Tc ();

      const unsigned int vector_index_Tc = channel_c.get_vector_index_Tc ();

      const class vector_class<complex<double> > &CC_HO_overlaps_c = CC_HO_overlaps(ic);

      class correlated_state_str PSI_qn_c (Z_Tc , N_Tc , BP_Tc , J_Tc , vector_index_Tc , E_Tc , NADA , NADA , NADA , false);

      // projection of the composite state in the HO basis

      // for each Berggren state
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (int NCM_c = 0 ; NCM_c <= NCM_max_LCM_projectile_c ; NCM_c++)
	{
	  const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c(NCM_c, LCM_projectile_c, J_projectile_c);

	  const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

	  if (!is_it_forbidden_channel_tab(ic , NCM_c) && (real_average_n_scat_c < CC_average_n_scat_target_projectile_max))
	    {
	      const unsigned int this_thread = OpenMP_thread_number_determine ();

	      const complex<double> E_CM_c = cluster_CM_E_tab_c(NCM_c , LCM_projectile_c , J_projectile_c);

	      const class correlated_state_str PSI_projectile_qn_c(Z_projectile_c , N_projectile_c , BP_projectile_c , J_projectile_c , NADA , E_CM_c , NADA , NADA , NADA , false);

	      const class vector_class<complex<double> > &HO_overlaps_NCM_c = HO_overlaps_cluster_CM_c(NCM_c , LCM_projectile_c , J_projectile_c);

#ifdef TYPEisDOUBLECOMPLEX
	      const TYPE uc_HO_NCM_overlap = HO_overlaps_NCM_c*CC_HO_overlaps_c;
#endif
		      
#ifdef TYPEisDOUBLE
	      const TYPE uc_HO_NCM_overlap = real (HO_overlaps_NCM_c*CC_HO_overlaps_c);
#endif
		  
	      const string A_dagger_PSI_c_coupled_file_name = PSI_OUT_coupled_to_J_file_name_A_dagger_cluster_CM_relative_determine (false , "A_dagger_cluster" , projectile_c , NCM_c , LCM_projectile_c , PSI_projectile_qn_c , PSI_qn_c , J , M);
 
	      // build the composite state from a file

	      class GSM_vector &Vc = Vc_tab(this_thread);

	      Vc.read_disk (false , false , A_dagger_PSI_c_coupled_file_name);

#ifdef UseOpenMP
#pragma omp critical
#endif 			
	      PSI_HO += uc_HO_NCM_overlap*Vc;
	    }
	}
    }
}


void CC_observables_common::data_one_projectile_less_alloc_calc (
								 const bool is_it_full_or_partial_storage , 
								 const bool is_it_one_nucleon_case , 
								 const enum interaction_type inter , 
								 const bool truncation_hw , 
								 const bool truncation_ph ,  
								 const class nucleons_data &prot_data , 
								 const class nucleons_data &neut_data , 
								 const class array<enum particle_type> &projectile_tab ,
								 const class array<class cluster_data> &cluster_data_tab , 
								 class array<class nucleons_data> &prot_data_one_projectile_less_tab , 
								 class array<class nucleons_data> &neut_data_one_projectile_less_tab)
{

  if (is_it_one_nucleon_case)
    data_one_nucleon_less_alloc_calc (is_it_full_or_partial_storage , inter , truncation_hw , truncation_ph , prot_data , neut_data , projectile_tab , prot_data_one_projectile_less_tab , neut_data_one_projectile_less_tab);
  else
    data_one_cluster_less_alloc_calc (is_it_full_or_partial_storage , inter , truncation_hw , truncation_ph , prot_data , neut_data , cluster_data_tab , prot_data_one_projectile_less_tab , neut_data_one_projectile_less_tab);
}



void CC_observables_common::target_projectile_PSI_HO_calc (
							   const bool is_it_one_nucleon_case , 
							   const class input_data_str &input_data_CC_Berggren , 
							   const class array<class cluster_data> &cluster_data_tab ,  
							   const class CC_Hamiltonian_data &CC_H_data ,
							   const class CC_state_class &CC_state , 
							   const class array<class vector_class<complex<double> > > &CC_HO_overlaps ,
							   class nucleons_data &prot_data , 
							   class nucleons_data &neut_data , 
							   class GSM_vector &PSI_HO)
{
  if (is_it_one_nucleon_case)
    target_projectile_PSI_HO_one_nucleon_calc (input_data_CC_Berggren , CC_H_data , CC_state , CC_HO_overlaps , prot_data , neut_data , PSI_HO);
  else
    target_projectile_PSI_HO_cluster_calc (input_data_CC_Berggren , cluster_data_tab ,  CC_H_data , CC_state , CC_HO_overlaps , PSI_HO);
}







void CC_observables_common::CC_eigenstate_H_data_calc (
						       const class CC_target_projectile_composite_data &Tpc_data , 
						       const class interaction_class &inter_data_basis,
						       const class input_data_str &input_data_CC_Berggren , 
						       const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
						       const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
						       const class array<class cluster_data> &cluster_data_tab , 
						       class array<class cluster_data> &cluster_data_CC_Berggren_tab , 
						       class nucleons_data &prot_data_CC_Berggren , 
						       class nucleons_data &neut_data_CC_Berggren ,  
						       class nucleons_data &prot_data , 
						       class nucleons_data &neut_data , 
						       class correlated_state_str &PSI_qn , 
						       class TBMEs_class &TBMEs_pn ,
						       class CC_Hamiltonian_data &CC_H_data ,
						       class CC_state_class &CC_state)
{
  const complex<double> I(0 , 1);

  //// if true , the L_min/max are put to the L value for the total cross section
  //// the interferences between different L values disappear due to the orthogonality of the Wigner D-matrices
  //const bool is_total_cross_section_calculated = input_data.get_CC_beta_is_total_cross_section_calculated;
  //const int L_for_total_cross_section = input_data.get_CC_beta_L_for_total_cross_section;

  const bool is_it_one_nucleon_case = Tpc_data.get_is_it_one_nucleon_case ();

  const bool are_GSM_a_dagger_vectors_calculated = Tpc_data.get_are_GSM_a_dagger_vectors_calculated ();

  const unsigned int N_bef_R_uniform = input_data_CC_Berggren.get_N_bef_R_uniform ();

  const double R = input_data_CC_Berggren.get_R ();

  const double R_real_max = input_data_CC_Berggren.get_R_real_max ();

  const class array<unsigned int> &N_channels_tab = Tpc_data.get_N_channels_tab ();

  const class array<class CC_channel_class> &channels_tab = Tpc_data.get_channels_tab ();

  const class array<unsigned int> &BP_A_tab = Tpc_data.get_BP_A_tab (); 

  const class array<double> &J_A_tab = Tpc_data.get_J_A_tab ();

  cout.precision (15);

  //:::// for the moment there is a loop over all final states of the composite system
  //:::// to choose one in particular , one has to check if it exists in the table J_A_tab[]

  const unsigned int BP_A = PSI_qn.get_BP ();

  const double J_A = PSI_qn.get_J ();

  const int vector_index_A = PSI_qn.get_vector_index ();

  const unsigned int iJPi_A = JPi_index_determine (BP_A_tab , J_A_tab , BP_A , J_A);

  const unsigned int N_channels_JPi_A = N_channels_tab(iJPi_A);

  if (THIS_PROCESS == MASTER_PROCESS) cout << "Calculation of outgoing state " << J_Pi_string (BP_A , J_A) << " " << vector_index_A << endl;

  // table of all channels for the given composite state

  class array<class CC_channel_class> channels_JPi_A_tab (N_channels_JPi_A);

  JPi_channels_tab_BP_J_vector_index_E_fill (channels_tab , BP_A , J_A , vector_index_A , NADA , channels_JPi_A_tab);

  class nucleons_data prot_data_one_configuration;
  class nucleons_data neut_data_one_configuration;

  class HF_nucleons_data CC_prot_HF_data;
  class HF_nucleons_data CC_neut_HF_data;

  if (is_it_one_nucleon_case)
    {
      class nucleons_data CC_prot_data;
      class nucleons_data CC_neut_data;

      nucleons_data_initialization (true , input_data_CC_Berggren , CC_prot_data , CC_neut_data);
      
      const int lp_max = CC_prot_data.get_lmax ();
      const int ln_max = CC_neut_data.get_lmax ();

      class lj_table<bool> prot_OCM_valence_state_tab(0.5 , lp_max);
      class lj_table<bool> neut_OCM_valence_state_tab(0.5 , ln_max);

      OCM_valence_state_tab_fill (CC_prot_data , prot_OCM_valence_state_tab);
      OCM_valence_state_tab_fill (CC_neut_data , neut_OCM_valence_state_tab);

      is_it_OCM_HO_core_determine (input_data_CC_Berggren , CC_prot_data , CC_neut_data);

      const class lj_table<int> &prot_nmin_lj_valence_tab = prot_HF_data_CC_Berggren.get_nmin_lj_valence_tab ();
      const class lj_table<int> &neut_nmin_lj_valence_tab = neut_HF_data_CC_Berggren.get_nmin_lj_valence_tab (); 

      prepare_CC_prot_neut_data (channels_JPi_A_tab , true , prot_nmin_lj_valence_tab , neut_nmin_lj_valence_tab , prot_OCM_valence_state_tab , neut_OCM_valence_state_tab , CC_prot_data , CC_neut_data);

      CC_prot_HF_data.allocate (input_data_CC_Berggren , CC_prot_data);
      CC_neut_HF_data.allocate (input_data_CC_Berggren , CC_neut_data);

      CC_state_calc_preparation (
				 prot_data_CC_Berggren , neut_data_CC_Berggren , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
				 prot_data_one_configuration , neut_data_one_configuration , CC_prot_HF_data , CC_neut_HF_data);
    }

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << endl;

  // CC - calculations

  class array<complex<double> > Ueq_tab (N_channels_JPi_A , N_channels_JPi_A , N_bef_R_uniform);

  class array<complex<double> > source_tab (N_channels_JPi_A , N_bef_R_uniform);

  CC_H_data.dimension_matrices_independent_data_realloc_init (is_it_one_nucleon_case , input_data_CC_Berggren , inter_data_basis , channels_JPi_A_tab , 
							      prot_data , neut_data , cluster_data_tab , prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab);	

  CC_H_data.corrective_factors_read (input_data_CC_Berggren);

  CC_H_data.HO_wfs_Gaussian_tables_calc (R , R_real_max , channels_JPi_A_tab , inter_data_basis);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << "---------------------------------------------------------------------------------------------------------------------" << endl;
      cout << "Calculation of state " << J_Pi_vector_index_string (BP_A , J_A , vector_index_A) << endl;
    }

  // calculations of the u_c (r) for the outgoing wave
  CC_state_iterative_calc (Tpc_data , true , are_GSM_a_dagger_vectors_calculated , input_data_CC_Berggren , inter_data_basis , 
			   prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , prot_data_one_configuration , neut_data_one_configuration , cluster_data_tab , cluster_data_CC_Berggren_tab , 
			   prot_data_CC_Berggren , neut_data_CC_Berggren , prot_data , neut_data , TBMEs_pn , CC_prot_HF_data , CC_neut_HF_data , CC_H_data , CC_state);

  if (THIS_PROCESS == MASTER_PROCESS) cout << "---------------------------------------------------------------------------------------------------------------------" << endl;

  // get the final energy
  const complex<double> E = CC_state.get_E ();

  PSI_qn.initialize (PSI_qn.get_Z () ,
		     PSI_qn.get_N () ,
		     PSI_qn.get_BP () ,
		     PSI_qn.get_J () ,
		     PSI_qn.get_vector_index () ,
		     E ,
		     PSI_qn.get_weight () ,
		     PSI_qn.get_experimental_energy () ,
		     PSI_qn.get_energy_error () ,
		     PSI_qn.get_is_it_optimization_reference_state ());

  if (is_it_one_nucleon_case)
    {
      HF_wave_function::waves_deallocate (CC_prot_HF_data);
      HF_wave_function::waves_deallocate (CC_neut_HF_data);
    }
}








void CC_observables_common::cross_sections_observables_calc_print_store (
									 const class input_data_str &input_data ,
									 const class input_data_str &input_data_CC_Berggren ,
									 const class interaction_class &inter_data_basis ,
									 const class HF_nucleons_data &prot_HF_data_CC_Berggren ,
									 const class HF_nucleons_data &neut_HF_data_CC_Berggren ,
									 class nucleons_data &prot_data ,
									 class nucleons_data &neut_data ,
									 class array<class cluster_data> &cluster_data_tab ,
									 class nucleons_data &prot_data_CC_Berggren ,
									 class nucleons_data &neut_data_CC_Berggren ,
									 class array<class cluster_data> &cluster_data_CC_Berggren_tab ,
									 class CC_target_projectile_composite_data &Tpc_data ,
									 class TBMEs_class &TBMEs_pn)
{
  const enum CC_reaction_type CC_reaction = input_data.get_CC_reaction ();
	
  const bool are_there_GSM_multipoles                = input_data.get_are_there_GSM_multipoles ();
  const bool are_there_EM_transitions                = input_data.get_are_there_EM_transitions ();
  const bool are_there_EM_transitions_strength       = input_data.get_are_there_EM_transitions_strength ();
  const bool are_there_beta_transitions              = input_data.get_are_there_beta_transitions ();
  const bool are_there_beta_transitions_strength     = input_data.get_are_there_beta_transitions_strength ();
  const bool are_there_densities                     = input_data.get_are_there_densities ();
  const bool are_there_spectroscopic_factors         = input_data.get_are_there_spectroscopic_factors ();
  const bool are_there_overlap_functions             = input_data.get_are_there_overlap_functions ();
  const bool are_there_rms_radii                     = input_data.get_are_there_rms_radii ();
  const bool are_there_rms_radius_one_body_strengths = input_data.get_are_there_rms_radius_one_body_strengths ();
  const bool are_there_CC_multipoles                 = input_data.get_are_there_GSM_multipoles ();

  if (CC_reaction == SCATTERING)
    CC_scattering_cross_section::calc_print (input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
					     prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , prot_data , neut_data , cluster_data_tab , Tpc_data , TBMEs_pn);
  
  if (CC_reaction == RADIATIVE_CAPTURE)
    CC_radiative_capture::calc_print (input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
				      prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , prot_data , neut_data , cluster_data_tab , Tpc_data , TBMEs_pn);
  
  if (are_there_GSM_multipoles)
    CC_multipoles_poles::calc_print (input_data , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
				     prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , prot_data , neut_data , cluster_data_tab , Tpc_data , TBMEs_pn);
  
  if (are_there_EM_transitions)
    CC_EM_transitions_poles::calc_print (input_data , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
					 prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , prot_data , neut_data , cluster_data_tab , Tpc_data , TBMEs_pn);

  if (are_there_EM_transitions_strength)
    CC_EM_transitions_strength_poles::calc_store (input_data , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
						  prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , prot_data , neut_data , cluster_data_tab , Tpc_data , TBMEs_pn);

  if (are_there_beta_transitions)
    CC_beta_transitions_poles::calc_print (input_data , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
					   prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , prot_data , neut_data , cluster_data_tab , Tpc_data , TBMEs_pn);

  if (are_there_beta_transitions_strength)
    CC_beta_transitions_strength_poles::calc_store (input_data , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
						    prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , prot_data , neut_data , cluster_data_tab , Tpc_data , TBMEs_pn);

  if (are_there_densities)
    CC_density_poles::calc_store (input_data , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
				  prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , prot_data , neut_data , cluster_data_tab , Tpc_data , TBMEs_pn);

  if (are_there_spectroscopic_factors)
    CC_spectroscopic_factor_poles::calc_print (input_data , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
					       prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , prot_data , neut_data , cluster_data_tab , Tpc_data , TBMEs_pn);

  if (are_there_overlap_functions)
    CC_overlap_function_poles::calc_store (input_data , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
					   prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , prot_data , neut_data , cluster_data_tab , Tpc_data , TBMEs_pn);

  if (are_there_rms_radii)
    CC_rms_radius_poles::calc_print (input_data , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
				     prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , prot_data , neut_data , cluster_data_tab , Tpc_data , TBMEs_pn);

  if (are_there_rms_radius_one_body_strengths)
    CC_rms_radius_one_body_strength_poles::calc_store (input_data , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
						       prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , prot_data , neut_data , cluster_data_tab , Tpc_data , TBMEs_pn);
  
  if (are_there_CC_multipoles)
    CC_multipoles_poles::calc_print (input_data , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
				     prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , prot_data , neut_data , cluster_data_tab , Tpc_data , TBMEs_pn);
}
