#include "../CC_include/CC_include_def.h"

using namespace string_routines;
using namespace inputs_misc;
using namespace Wigner_signs;


// preliminary calculations for CC states
void CC_waves_HF_MSDHF_potentials_calculations::CC_state_calc_preparation (
									   class nucleons_data &prot_data_CC_Berggren , 
									   class nucleons_data &neut_data_CC_Berggren , 
									   const class input_data_str &input_data_CC_Berggren , 
									   const class interaction_class &inter_data_basis , 
									   const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
									   const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
									   class nucleons_data &prot_data_one_configuration , 
									   class nucleons_data &neut_data_one_configuration , 
									   class HF_nucleons_data &CC_prot_HF_data , 
									   class HF_nucleons_data &CC_neut_HF_data)
{
  const enum potential_type basis_potential = input_data_CC_Berggren.get_basis_potential ();

  const bool is_it_OCM_basis = CC_prot_HF_data.get_is_it_OCM_basis ();

  // CC Hartree-Fock calculations
  if (basis_potential == MSDHF)
    {
      MPI_parallelization_disabled ();
      
      class TBMEs_class TBMEs_pn;
	
      MSDHF_potentials::one_configuration::data_alloc_calc (input_data_CC_Berggren , prot_data_CC_Berggren , neut_data_CC_Berggren , inter_data_basis ,
							    prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , prot_data_one_configuration , neut_data_one_configuration , TBMEs_pn);

      CC_prot_HF_data.copy_data_shells_alloc_calc (basis_potential , prot_HF_data_CC_Berggren);
      CC_neut_HF_data.copy_data_shells_alloc_calc (basis_potential , neut_HF_data_CC_Berggren);

      MSDHF_potentials::one_configuration::all_HF_many_body_data_alloc_calc (true , input_data_CC_Berggren , inter_data_basis , TBMEs_pn , prot_data_one_configuration , neut_data_one_configuration , CC_prot_HF_data , CC_neut_HF_data);

      MPI_parallelization_enabled ();
    }

  if ((basis_potential == HF) || is_it_OCM_basis)
    {
      CC_prot_HF_data.copy_data_shells_alloc_calc (basis_potential , prot_HF_data_CC_Berggren);
      CC_neut_HF_data.copy_data_shells_alloc_calc (basis_potential , neut_HF_data_CC_Berggren);
    }
}



void CC_waves_HF_MSDHF_potentials_calculations::CC_waves_no_scaled_tables_not_orthogonalized_calc (
												   const bool is_it_entrance_channel_only , 
												   const enum potential_type basis_potential , 
												   const class CC_Hamiltonian_data &CC_H_data , 
												   class HF_nucleons_data &CC_prot_HF_data , 
												   class HF_nucleons_data &CC_neut_HF_data , 
												   class CC_state_class &CC_state)
{
  const bool is_it_OCM_basis = CC_prot_HF_data.get_is_it_OCM_basis ();

  const unsigned int N_channels = CC_state.get_N_channels ();

  const unsigned int N_bef_R_uniform = CC_state.get_N_bef_R_uniform ();

  const unsigned int ic_entrance = CC_state.get_ic_entrance ();

  const double R = CC_state.get_R ();

  const class array<class CC_channel_class> &channels_tab = CC_state.get_channels_tab ();

  const class array<double> &r_bef_R_tab_uniform = CC_state.get_r_bef_R_tab_uniform ();

  const class array<complex<double> > &Ueq_tab = CC_H_data.get_Ueq_tab ();

  const class array<complex<double> > &source_tab = CC_H_data.get_source_tab ();

  const unsigned int first_icp = basic_first_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_icp = basic_last_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS); 

  /* Creation of the splines class for the equivalent potentials and sources */

  class potentials_effective_mass T;

  class array<splines_class<complex<double> > > &CC_trivially_equivalent_potential_tab = T.get_CC_trivially_equivalent_potential_tab ();

  class array<splines_class<complex<double> > > &CC_source_tab = T.get_CC_source_tab ();

  CC_trivially_equivalent_potential_tab.allocate (N_channels , N_channels);

  CC_source_tab.allocate (N_channels);

  class array<complex<double> > Uccp_tab (N_bef_R_uniform);

  class array<complex<double> > Sc_tab (N_bef_R_uniform);
		      
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned ic = 0 ; ic < N_channels ; ic++)
    {
      if (!is_it_entrance_channel_only || (ic == ic_entrance))
	{
	  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) Sc_tab(i) = source_tab(ic , i);

	  CC_source_tab(ic).allocate_calc (r_bef_R_tab_uniform , Sc_tab , 0.0 , 0.0);

	  for (unsigned icp = 0 ; icp < N_channels ; icp++)
	    {
	      if ((icp >= first_icp) && (icp <= last_icp))
		{
		  if (!is_it_entrance_channel_only || (icp == ic_entrance))
		    {
		      bool is_Uccp_zero = true;

		      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) 
			{
			  Uccp_tab(i) = Ueq_tab(ic , icp , i);
			
			  if (is_Uccp_zero && (Uccp_tab(i) != 0.0)) is_Uccp_zero = false;
			}

		      if (ic == icp)
			{
			  const class CC_channel_class &channel_c = channels_tab(ic);

			  const int Z_Tc_charge = channel_c.get_Z_Tc_charge ();

			  const enum particle_type particle_c = channel_c.get_projectile ();

			  const class Coulomb_potential_class Coulomb_potential(false , particle_c , Z_Tc_charge , NADA);

			  const double dV_R = (is_Uccp_zero) ? (0.0) : (Coulomb_potential.point_potential_derivative_calc (R));

			  CC_trivially_equivalent_potential_tab(ic , icp).allocate_calc (r_bef_R_tab_uniform , Uccp_tab , 0.0 , dV_R);
			}
		      else 
			CC_trivially_equivalent_potential_tab(ic , icp).allocate_calc (r_bef_R_tab_uniform , Uccp_tab , 0.0 , 0.0);
		    }
		}
	    }
	}
    }

#ifdef UseMPI

  if (is_it_MPI_parallelized)
    {
      for (unsigned ic = 0 ; ic < N_channels ; ic++)
	{
	  if (!is_it_entrance_channel_only || (ic == ic_entrance))
	    {
	      for (unsigned icp = 0 ; icp < N_channels ; icp++)
		{
		  if (!is_it_entrance_channel_only || (icp == ic_entrance))
		    {
		      const unsigned int Send_process = basic_active_process_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , icp);
		
		      CC_trivially_equivalent_potential_tab(ic , icp).allocate_MPI_Bcast (Send_process , MPI_COMM_WORLD); 
		    }
		}
	    }
	}
    }

#endif

  CC_state.wave_calculation_no_scaled_tables_no_channel_orthogonalization (is_it_entrance_channel_only , CC_H_data , CC_prot_HF_data , CC_neut_HF_data , T);

  if ((basis_potential == HF) || (basis_potential == MSDHF) || is_it_OCM_basis) CC_state.put_shells_HF (CC_prot_HF_data , CC_neut_HF_data);
}












void CC_waves_HF_MSDHF_potentials_calculations::potentials_calc (
								 const bool is_it_one_nucleon_case , 
								 const bool is_it_entrance_channel_only_iterative_init , 
								 const bool is_it_entrance_channel_only_iterative , 
								 const bool is_it_entrance_channel_only , 
								 const class interaction_class &inter_data_basis , 
								 const class nucleons_data &prot_data_one_configuration , 
								 const class nucleons_data &neut_data_one_configuration , 
								 const class nucleons_data &prot_data , 
								 const class nucleons_data &neut_data , 
								 const class array<class cluster_data> &cluster_data_tab , 
								 const bool is_it_symmetrized , 
								 const double new_potential_fraction , 
								 const enum potential_type basis_potential , 
								 class CC_state_class &CC_state , 
								 class CC_Hamiltonian_data &CC_H_data , 
								 class HF_nucleons_data &CC_prot_HF_data , 
								 class HF_nucleons_data &CC_neut_HF_data)
{
  if (is_it_one_nucleon_case)
    {
      if (!is_it_entrance_channel_only_iterative_init)
	{	  
	  const bool neutron_basis_potential = prot_data.get_neutron_basis_potential ();

	  const bool is_it_OCM_basis = CC_prot_HF_data.get_is_it_OCM_basis (); 

	  CC_state.HO_overlaps_calc (is_it_entrance_channel_only , CC_H_data);

	  // The suppression of MPI parallelization here is necessary.
	  // Indeed , HF/MSDHF routines are parallelized according to the s.p. states calculated.
	  // The calculation of scattering states is distributed over all nodes so that a node takes care of only a few scattering states.
	  // Bound and resonant s.p. states are calculated by all nodes , as they define the HF/MSDHF potentials.
	  // But here , HF/MSDHF potentials act on channels functions , which play the role of s.p. states in HF/MSDHF routines.
	  // Parallelization is here false then , as all nodes need the potentials for each channel function. 

	  MPI_parallelization_disabled ();

	  const class multipolar_expansion_str &multipolar_expansion = CC_H_data.get_multipolar_expansion ();

	  const class CG_str &CGs = CC_H_data.get_CGs ();

	  const class array<double> &Gaussian_table_GL = CC_H_data.get_Gaussian_table_GL ();

	  if (basis_potential == MSDHF)
	    MSDHF_potentials::potentials_calc (false , new_potential_fraction , CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion ,
					       prot_data_one_configuration , neut_data_one_configuration , CC_prot_HF_data , CC_neut_HF_data);

	  if ((basis_potential == HF) || is_it_OCM_basis)
	    HF_potentials_common::potentials_calc (false , new_potential_fraction , neutron_basis_potential , CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , CC_prot_HF_data , CC_neut_HF_data);

	  MPI_parallelization_enabled ();
	}

      CC_potentials_one_nucleon::Ueq_source_calc (is_it_entrance_channel_only_iterative , is_it_entrance_channel_only , is_it_symmetrized , new_potential_fraction , 
						  CC_state , inter_data_basis , prot_data , neut_data , CC_prot_HF_data , CC_neut_HF_data , CC_H_data);
    }
  else
    CC_potentials_cluster::Ueq_source_calc (is_it_entrance_channel_only_iterative , is_it_entrance_channel_only , is_it_symmetrized , new_potential_fraction , 
					    CC_state , cluster_data_tab , CC_H_data);
}









void CC_waves_HF_MSDHF_potentials_calculations::CC_state_iterative_calc (
									 const class CC_target_projectile_composite_data &Tpc_data , 
									 const bool compute_matrices , 
									 const bool are_GSM_a_dagger_vectors_calculated , 
									 const class input_data_str &input_data , 
									 const class interaction_class &inter_data_basis , 
									 const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
									 const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
									 const class nucleons_data &prot_data_one_configuration , 
									 const class nucleons_data &neut_data_one_configuration , 
									 const class array<class cluster_data> &cluster_data_tab , 
									 const class array<class cluster_data> &cluster_data_CC_Berggren_tab , 
									 const class nucleons_data &prot_data_CC_Berggren , 
									 const class nucleons_data &neut_data_CC_Berggren , 
									 class nucleons_data &prot_data , 
									 class nucleons_data &neut_data , 
									 class TBMEs_class &TBMEs_pn , 
									 class HF_nucleons_data &CC_prot_HF_data , 
									 class HF_nucleons_data &CC_neut_HF_data , 
									 class CC_Hamiltonian_data &CC_H_data , 
									 class CC_state_class &CC_state)
{
  const bool is_it_one_nucleon_case = Tpc_data.get_is_it_one_nucleon_case ();

  const class array<class CC_channel_class> &channels_tab = CC_state.get_channels_tab ();

  const enum potential_type basis_potential = input_data.get_basis_potential ();
  
  const bool S_matrix_pole = CC_state.get_S_matrix_pole ();

  const bool is_it_OCM_basis = CC_prot_HF_data.get_is_it_OCM_basis ();
  
  const unsigned int N_channels = CC_state.get_N_channels ();

  const unsigned int BP = CC_state.get_BP ();
  
  const double J = CC_state.get_J ();
  const double M = CC_state.get_M ();
  
  const int n = CC_state.get_n ();

  const complex<double> E = CC_state.get_E ();

  // Preliminaries 1 - Elements for Berggren and HO CC - matrices
  // Preliminaries 2 - HO - wave calculations (for Hartree-Fock and HO diagonalization)
  // Preliminaries 3 - MSGI table

  if (compute_matrices)
    {
      if (is_it_one_nucleon_case)
	CC_potentials_one_nucleon::potentials_overlaps_calc (input_data , are_GSM_a_dagger_vectors_calculated , channels_tab , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren ,
							     prot_data_one_configuration , neut_data_one_configuration , J , M , BP , 
							     prot_data_CC_Berggren , neut_data_CC_Berggren , prot_data , neut_data , TBMEs_pn , CC_H_data);
      else 
	CC_potentials_cluster::potentials_overlaps_calc (input_data , are_GSM_a_dagger_vectors_calculated , channels_tab , cluster_data_tab , cluster_data_CC_Berggren_tab , J , M , BP , 
							 prot_data , neut_data , TBMEs_pn , CC_H_data);

      if (!S_matrix_pole)
	{
	  if (are_GSM_a_dagger_vectors_calculated)
	    {
	      CC_H_data.orthogonalized_H_tridiagonalization_CC_Berggren ();
	      
	      if (THIS_PROCESS == MASTER_PROCESS) CC_H_data.H_tridiagonalized_copy_disk (BP , J);
	    }
	  else
	    {	      
	      if (THIS_PROCESS == MASTER_PROCESS) CC_H_data.H_tridiagonalized_read_from_file (BP , J);
	      
#ifdef UseMPI
	      CC_H_data.H_tridiagonalized_MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
	    }
	}
    }

  // Diagonalization (poles) / linear system (scattering states) in the Berggren basis
  // =================================================================================

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      if (S_matrix_pole)
	cout << J_Pi_string (BP , J) << " (" << n << ")" << " resonant state" << endl << endl;
      else
	cout << J_Pi_string (BP , J) << " scattering state E=" << E << " MeV " << endl << endl;

      cout << "Number of channels : " << N_channels << endl << endl;
    }

  //xyz symmetrization
  //Symmetrization removed. Not wrong , but sometimes unstable.
  const bool is_it_symmetrized = false;
  //const bool is_it_symmetrized = S_matrix_pole;

  const class array<complex<double> > &A0_tab = CC_state.get_A0_tab ();

  const class array<complex<double> > &Aplus_tab = CC_state.get_Aplus_tab ();
  
  class array<complex<double> > A0_bef_tab = A0_tab;

  class array<complex<double> > Aplus_bef_tab = Aplus_tab;

  if (S_matrix_pole)
    CC_state.Berggren_Green_function_CC_waves_no_scaled_tables_calc (Tpc_data , prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , CC_H_data);
  else
    {
      // Iterative calculations
      // ======================

      if (THIS_PROCESS == MASTER_PROCESS) cout << endl;

      unsigned int iter = 0;

      double test = INFINITE;

      potentials_calc (is_it_one_nucleon_case , true , true , true , inter_data_basis , prot_data_one_configuration , neut_data_one_configuration , 
		       prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , 
		       is_it_symmetrized , 1.0 , basis_potential , CC_state , CC_H_data , CC_prot_HF_data , CC_neut_HF_data);

      CC_waves_no_scaled_tables_not_orthogonalized_calc (true , basis_potential , CC_H_data , CC_prot_HF_data , CC_neut_HF_data , CC_state);

      const double precision_test = 1E-7 ;

      while ((test > precision_test) && (iter++ < 100))
	{
	  A0_bef_tab = A0_tab;

	  Aplus_bef_tab = Aplus_tab;

	  potentials_calc (is_it_one_nucleon_case , false , true , true , inter_data_basis , prot_data_one_configuration , neut_data_one_configuration , 
			   prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , 
			   is_it_symmetrized , 1.0 , basis_potential , CC_state , CC_H_data , CC_prot_HF_data , CC_neut_HF_data);

	  CC_waves_no_scaled_tables_not_orthogonalized_calc (true , basis_potential , CC_H_data , CC_prot_HF_data , CC_neut_HF_data , CC_state);

	  test = CC_state.test_calc (true , A0_bef_tab , Aplus_bef_tab);
	  
	  if (!finite (test)) error_message_print_abort ("The equivalent potential method (entrance channel only) has failed.");

	  if (finite (test) && (THIS_PROCESS == MASTER_PROCESS)) 
	    cout << "Direct integration (entrance channel only) - iteration : " << iter << " - C0/C+ test : " << test << endl;
	}


      // Some other tables
      // =================
      potentials_calc (is_it_one_nucleon_case , false , false , true , inter_data_basis , prot_data_one_configuration , neut_data_one_configuration ,
		       prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , 
		       is_it_symmetrized , 1.0 , basis_potential , CC_state , CC_H_data , CC_prot_HF_data , CC_neut_HF_data);

      CC_state.Berggren_Green_function_CC_waves_no_scaled_tables_calc (Tpc_data , prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , CC_H_data);

      A0_bef_tab = A0_tab;

      Aplus_bef_tab = Aplus_tab;

      if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
    }

  if ((basis_potential == HF) || (basis_potential == MSDHF) || is_it_OCM_basis) CC_state.put_shells_HF (CC_prot_HF_data , CC_neut_HF_data);

  // Iterative calculations
  // ======================

  potentials_calc (is_it_one_nucleon_case , false , false , false , inter_data_basis , prot_data_one_configuration , neut_data_one_configuration , 
		   prot_data_CC_Berggren , neut_data_CC_Berggren , cluster_data_CC_Berggren_tab , 
		   is_it_symmetrized , 1.0 , basis_potential , CC_state , CC_H_data , CC_prot_HF_data , CC_neut_HF_data);

  CC_state.wave_channel_orthogonalization (CC_H_data);
  
  //if (S_matrix_pole) CC_state.CC_uc_wfs_test_pole (Tpc_data , prot_data , neut_data , cluster_data_tab , CC_H_data);
  
  CC_state.scaled_tables_calc (); 
}
