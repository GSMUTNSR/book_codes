#include "../CC_include/CC_include_def.h"


using namespace string_routines;
using namespace correlated_state_routines;
using namespace inputs_misc;
using namespace Wigner_signs;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_scalar_strength_MEs;
using namespace CC_scalar_strength_MEs::radial_momentum;
using namespace CC_observables_common;




void CC_density_poles::calc_one_state ( 
				       class GSM_vector &PSI_full , 
				       const bool is_it_radial , 
				       const bool is_it_Gauss_Legendre , 
				       const bool is_it_nas_only , 
				       const class CC_target_projectile_composite_data &Tpc_data , 
				       const class input_data_str &input_data_CC_Berggren , 
				       const class interaction_class &inter_data_basis ,  
				       const class array<class cluster_data> &cluster_projectile_data_tab , 
				       const class CC_Hamiltonian_data &CC_H_data , 
				       const class CC_state_class &CC_state , 
				       class baryons_data &prot_Y_data , 
				       class baryons_data &neut_Y_data,
				       class array<TYPE> &strength_tab)
					 
{
  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();
  
  const bool full_common_vectors_used_in_file = input_data_CC_Berggren.get_full_common_vectors_used_in_file ();
    
  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();

  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();

  const enum storage_type Hamiltonian_storage = input_data_CC_Berggren.get_Hamiltonian_storage ();

  const bool is_it_full_or_partial_storage = is_it_full_or_partial_storage_determine (Hamiltonian_storage);
  
  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();
  
  const unsigned int N_bef_R_GL = CC_state.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state.get_N_bef_R_uniform ();
  
  const unsigned int Nk_momentum_GL = CC_state.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = CC_state.get_Nk_momentum_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL)     : (N_bef_R_uniform);
  const unsigned int Nk = (is_it_Gauss_Legendre) ? (Nk_momentum_GL) : (Nk_momentum_uniform);

  const unsigned int Nrk = (is_it_radial) ? (Nr) : (Nk);
  
  //=================== calculations of the beta matrix elts < J_i | Rrms^2 | J_f > ====================//

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const int Z_cluster_max = (!is_it_one_baryon_COSM_case) ? (Z_cluster_max_determine (cluster_projectile_data_tab)) : (1);
  const int N_cluster_max = (!is_it_one_baryon_COSM_case) ? (N_cluster_max_determine (cluster_projectile_data_tab)) : (1);
  
  const int Z_cluster_number = Z_cluster_max + 1;
  const int N_cluster_number = N_cluster_max + 1;

  class array<class baryons_data> prot_Y_data_one_projectile_less_tab(Z_cluster_number , N_cluster_number);
  class array<class baryons_data> neut_Y_data_one_projectile_less_tab(Z_cluster_number , N_cluster_number);
  
  data_one_projectile_less_alloc_calc (is_it_full_or_partial_storage , is_it_one_baryon_COSM_case , TBME_inter , truncation_hw , truncation_ph , prot_Y_data , neut_Y_data , projectile_tab ,
				       cluster_projectile_data_tab , prot_Y_data_one_projectile_less_tab , neut_Y_data_one_projectile_less_tab);
  
  class array<TYPE> target_NBMEs(N_target_projectile_states , N_target_projectile_states , Nrk);

  target_NBMEs = 0.0;
      
  composite::target_NBMEs_calc (PSI_full , TBME_inter , DENSITY , NO_PARTICLE , is_it_radial , is_it_Gauss_Legendre , full_common_vectors_used_in_file , Tpc_data , prot_Y_data_one_projectile_less_tab , neut_Y_data_one_projectile_less_tab , target_NBMEs);

  composite::CC_NBMEs_calc (PSI_full , DENSITY , NO_PARTICLE , NADA , is_it_radial , is_it_Gauss_Legendre , Tpc_data , cluster_projectile_data_tab , is_it_nas_only , 
			    CC_H_data , CC_state , prot_Y_data , neut_Y_data , input_data_CC_Berggren , target_NBMEs , strength_tab);
}













void CC_density_poles::calc_store (
				   const class input_data_str &input_data , 
				   const class input_data_str &input_data_CC_Berggren ,  
				   const class interaction_class &inter_data_basis ,
				   const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
				   const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
				   class baryons_data &prot_Y_data_CC_Berggren , 
				   class baryons_data &neut_Y_data_CC_Berggren , 
				   class array<class cluster_data> &cluster_data_CC_Berggren_tab , 
				   class baryons_data &prot_Y_data , 
				   class baryons_data &neut_Y_data , 
				   class array<class cluster_data> &cluster_projectile_data_tab , 
				   class CC_target_projectile_composite_data &Tpc_data , 
				   class TBMEs_class &TBMEs_pn , 
				   class TBMEs_class &TBMEs_cv)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Densities" << endl;
      cout <<         "---------" << endl << endl;
    }

  const int Z = input_data.get_Z ();
  const int N = input_data.get_N ();
  const int A = input_data.get_A ();
 
  const int S = input_data.get_hypernucleus_strangeness ();
  
  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  //// if true , the Lmin/max are put to the L value for the total cross section
  //// the interferences between different L values disappear due to the orthogonality of the Wigner D-matrices
  //const bool is_total_cross_section_calculated = input_data.get_CC_beta_is_total_cross_section_calculated;
  //const int L_for_total_cross_section = input_data.get_CC_beta_L_for_total_cross_section;

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
  
  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();

  const unsigned int N_bef_R_uniform = input_data_CC_Berggren.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = input_data_CC_Berggren.get_N_aft_R_uniform ();

  const unsigned int N_bef_R_GL = input_data_CC_Berggren.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = input_data_CC_Berggren.get_N_aft_R_GL ();

  const unsigned int Nk_momentum_GL = input_data_CC_Berggren.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = input_data_CC_Berggren.get_Nk_momentum_uniform ();
  
  const double R_real_max = input_data_CC_Berggren.get_R_real_max ();

  const double R = input_data_CC_Berggren.get_R ();

  const double kmax_momentum = input_data_CC_Berggren.get_kmax_momentum ();

  const double R_Fermi_momentum = input_data_CC_Berggren.get_R_Fermi_momentum ();
  
  const double R0_inter = inter_data_basis.get_R0 ();

  const double R0 = 1.27*cbrt (A);

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);

  const class array<unsigned int> &N_channels_tab = Tpc_data.get_N_channels_tab ();

  const class array<unsigned int> &BP_A_tab = Tpc_data.get_BP_A_tab (); 

  const class array<double> &J_A_tab = Tpc_data.get_J_A_tab ();

  const class array<class CC_channel_class> &channels_tab = Tpc_data.get_channels_tab ();

  const unsigned int density_number = input_data.get_density_number ();
  
  const class array<unsigned int> & density_BP_tab = input_data.get_density_BP_tab ();

  const class array<double> & density_J_tab = input_data.get_density_J_tab ();

  const class array<unsigned int> & density_vector_index_tab = input_data.get_density_vector_index_tab ();

  const class array<bool> & density_is_it_radial_tab = input_data.get_density_is_it_radial_tab ();
  
  const class array<bool> & density_is_it_Gauss_Legendre_tab = input_data.get_density_is_it_Gauss_Legendre_tab ();
    
  const double step_bef_R_uniform = input_data_CC_Berggren.get_step_bef_R_uniform ();
  
  const double step_momentum_uniform = input_data_CC_Berggren.get_step_momentum_uniform ();

  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);

  class array<double> r_bef_R_tab_uniform(N_bef_R_uniform);
  
  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;
  
  class array<double> k_tab_GL(Nk_momentum_GL);
  class array<double> wk_tab_GL(Nk_momentum_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , kmax_momentum , k_tab_GL , wk_tab_GL);

  class array<double> k_tab_uniform(Nk_momentum_uniform);
  
  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++) k_tab_uniform(i) = i*step_momentum_uniform;

  // Cluster approximation is used for non-antisymmetrized density matrix elements in the cluster case: rho(r-cluster) ~ rho(RCM-cluster) => rho-intrinsic(cluster) = 0

  if (!is_it_one_baryon_COSM_case)
    {
      class array<TYPE> &density_intrinsic_NBMEs = Tpc_data.get_scalar_intrinsic_NBMEs ();
      
      density_intrinsic_NBMEs = 0.0;
    }

  class GSM_vector PSI_full;
  
  for (unsigned int density_index = 0 ; density_index < density_number ; density_index++)
    {
      const unsigned int BP = density_BP_tab(density_index);

      const unsigned int vector_index = density_vector_index_tab(density_index);

      const double J = density_J_tab(density_index);

      const double M = J;

      const bool is_it_radial = density_is_it_radial_tab(density_index);
      
      const bool is_it_Gauss_Legendre = density_is_it_Gauss_Legendre_tab(density_index);
        
      class correlated_state_str PSI_qn(Z , N , BP , S , J , vector_index , NADA , NADA , NADA , NADA , false);
      
      const unsigned int iJPi = JPi_index_determine (S , BP_A_tab , J_A_tab , BP , J);
  
      const unsigned int N_channels_JPi = N_channels_tab(iJPi);
      
      // table of all channels for the given composite state

      class array<class CC_channel_class> channels_JPi_tab (N_channels_JPi);

      JPi_channels_tab_BP_J_vector_index_E_fill (S , channels_tab , BP , J , vector_index , NADA , channels_JPi_tab);
      
      class CC_state_class CC_state (is_it_one_baryon_COSM_case , nmax_HO_lab_tab , cluster_projectile_data_tab , true , true , N_channels_JPi ,
				     NADA , channels_JPi_tab , N_bef_R_uniform , N_aft_R_uniform , N_bef_R_GL , N_aft_R_GL , Nk_momentum_uniform , Nk_momentum_GL ,
				     R , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , A , BP , J , M , vector_index , NADA);

      class CC_Hamiltonian_data CC_H_data(N_channels_JPi , input_data_CC_Berggren);

      CC_eigenstate_H_data_calc (
				 Tpc_data , inter_data_basis , input_data_CC_Berggren , 
				 prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , cluster_projectile_data_tab , cluster_data_CC_Berggren_tab , 
				 prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , prot_Y_data , neut_Y_data , PSI_qn , TBMEs_pn , TBMEs_cv , CC_H_data , CC_state);
 
      const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
   
      const unsigned int Nk = (is_it_Gauss_Legendre) ? (Nk_momentum_GL) : (Nk_momentum_uniform);
    
      const unsigned int Nrk = (is_it_radial) ? (Nr) : (Nk);
  
      const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (r_bef_R_tab_GL) : (r_bef_R_tab_uniform);
 
      const class array<double> &k_tab = (is_it_Gauss_Legendre) ? (k_tab_GL) : (k_tab_uniform);
      
      const class array<double> &rk_tab = (is_it_radial) ? (r_bef_R_tab) : (k_tab);
   
      class array<TYPE> density_nas_tab(Nrk);

      class array<TYPE> density_as_tab(Nrk);
      
      calc_one_state (PSI_full , is_it_radial , is_it_Gauss_Legendre , true  , Tpc_data , input_data_CC_Berggren , inter_data_basis , cluster_projectile_data_tab , CC_H_data , CC_state , prot_Y_data , neut_Y_data , density_nas_tab);
      calc_one_state (PSI_full , is_it_radial , is_it_Gauss_Legendre , false , Tpc_data , input_data_CC_Berggren , inter_data_basis , cluster_projectile_data_tab , CC_H_data , CC_state , prot_Y_data , neut_Y_data , density_as_tab);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  const string PSI_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_qn);

	  const string density_string = (is_it_radial) ? ("radial_density_" + PSI_qn_string) : ("momentum_density_" + PSI_qn_string);

	  const string density_nas_string = density_string + "_non_antisymmetrized.dat";
	  const string density_as_string  = density_string + "_antisymmetrized.dat";

	  ofstream density_nas_file(density_nas_string.c_str () , ios::out);
	  ofstream density_as_file (density_as_string.c_str ()  , ios::out);
	  
	  density_nas_file.precision (15);
      	  density_as_file.precision (15);
      
	  for (unsigned int i = 0 ; i < Nrk ; i++)
	    {
	      const double rk = rk_tab(i);

	      const double rk2 = rk*rk;
	  	      
	      const TYPE density_nas_rk = density_nas_tab(i);
	      const TYPE density_as_rk  = density_as_tab(i);
	      
	      const TYPE density_nas_rk_rk2 = density_nas_rk*rk2;
	      const TYPE density_as_rk_rk2  = density_as_rk*rk2;

#ifdef TYPEisDOUBLECOMPLEX
	      density_nas_file << rk << " " << real (density_nas_rk) << " " << imag (density_nas_rk) << " " << real (density_nas_rk_rk2) << " " << imag (density_nas_rk_rk2) << endl;	      
	      density_as_file  << rk << " " << real (density_as_rk) << " "  << imag (density_as_rk)  << " " << real (density_as_rk_rk2)  << " " << imag (density_as_rk_rk2)  << endl;
#endif
	      
#ifdef TYPEisDOUBLE
	      density_nas_file << rk << " " << density_nas_rk << " " << density_nas_rk_rk2 << endl;	      
	      density_as_file  << rk << " " << density_as_rk  << " " << density_as_rk_rk2  << endl;
#endif
	    }

	  density_nas_file.close ();
	  density_as_file.close ();
      
	  const TYPE density_norm_nas_test = radial_momentum_density_norm_with_splines (rk_tab , density_nas_tab);
	  const TYPE density_norm_as_test  = radial_momentum_density_norm_with_splines (rk_tab , density_as_tab);
      
	  cout << "Density norm non-antisymmetrized (from splines) : " << density_norm_nas_test << endl;
	  cout << "Density norm     antisymmetrized (from splines) : " << density_norm_as_test  << endl;
	  
	  const string radial_momentum_str = (is_it_radial) ? ("radial") : ("momentum");
	  
	  cout << "Non-antisymetrized and antisymmetrized " << radial_momentum_str <<" densities of " << J_Pi_vector_index_string (BP , J , vector_index) << " calculated" << endl;
	}
    }
}










