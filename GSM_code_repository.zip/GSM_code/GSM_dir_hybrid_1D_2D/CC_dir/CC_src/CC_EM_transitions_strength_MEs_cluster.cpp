#include "../CC_include/CC_include_def.h"


using namespace Wigner_signs;
using namespace angular_matrix_elements;
using namespace inputs_misc;
using namespace EM_transitions_common;
using namespace EM_transitions_strength_NBMEs;

using namespace CC_EM_transitions_MEs::cluster;
using namespace CC_EM_transitions_strength_MEs::radial;



void CC_EM_transitions_strength_MEs::cluster::EM_suboperator_intrinsic_NBMEs_calc (
										   class GSM_vector &PSI_full , 
										   const enum EM_suboperator_type EM_suboperator , 
										   const TYPE &q , 
										   const int L ,
										   const int Lc , 
										   const bool is_it_longwavelength_approximation , 
										   const bool is_it_Gauss_Legendre , 
										   const class interaction_class &inter_data_basis , 
										   const class cluster_data &data_c , 
										   const class cluster_data &data_cp , 
										   const class GSM_vector &PSI_cluster_c ,
										   const class GSM_vector &PSI_cluster_cp , 
										   class array<TYPE> &EM_suboperator_intrinsic_NBMEs_strength_tab)
{
  const unsigned int N_bef_R_GL = data_c.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = data_c.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
  
  const double Jc  = data_c.get_J_intrinsic ();
  const double Jcp = data_cp.get_J_intrinsic ();

  const double b_HO = inter_data_basis.get_b_lab ();
 
  class array<TYPE> EM_suboperator_NBMEs_tab(Nr);
  
  EM_suboperator_B_amplitude_tab_calc (EM_suboperator , q , L , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre ,
				       PSI_full , Jc , PSI_cluster_c , Jcp , PSI_cluster_cp , EM_suboperator_NBMEs_tab);	

  const TYPE j0_ME = static_cast<TYPE> (HO_wave_functions::HO_3D::j0_ME_calc (b_HO , q));
  
  const TYPE hat_j0_derivative_ME = static_cast<TYPE> (HO_wave_functions::HO_3D::hat_j0_derivative_ME_calc (b_HO , q));
  
  const TYPE RCM_hat_j0_ME = static_cast<TYPE> (HO_wave_functions::HO_3D::r_hat_j0_ME_calc (b_HO , q));
  
  if ((EM_suboperator == ELECTRIC_CHARGE_YL_TENSOR_E) ||
      (EM_suboperator == ELECTRIC_CURRENT_YL_TENSOR_R_S) ||
      (EM_suboperator == ELECTRIC_CURRENT_YL_TENSOR_P_S) ||
      (EM_suboperator == MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_R_L) ||
      (EM_suboperator == MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_R_LP2) ||
      (EM_suboperator == MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_R_LM2) ||
      (EM_suboperator == MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_R_L) ||
      (EM_suboperator == MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_P_L) ||
      (EM_suboperator == MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_P_LP2) ||
      (EM_suboperator == MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_P_LM2) ||
      (EM_suboperator == MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_P_L))
    {
      EM_suboperator_intrinsic_NBMEs_strength_tab = 0.0;

      return;
    }
  
  if ((EM_suboperator == ELECTRIC_CHARGE_YL) ||
      (EM_suboperator == ELECTRIC_CURRENT) ||
      (EM_suboperator == ELECTRIC_CURRENT_YL_TENSOR_S) ||
      (EM_suboperator == MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1) ||
      (EM_suboperator == MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1) ||
      (EM_suboperator == MAGNETIC_SPIN_GRADIENT_BESSEL_YLP1) ||
      (EM_suboperator == MAGNETIC_SPIN_GRADIENT_BESSEL_YLM1) ||
      (EM_suboperator == MAGNETIC_SPIN_YL_TENSOR_S) ||
      (EM_suboperator == MAGNETIC_SPIN_S_SCALAR_E))
    {
      EM_suboperator_intrinsic_NBMEs_strength_tab = EM_suboperator_NBMEs_tab/j0_ME;

      return;
    }
   
  if (EM_suboperator == ELECTRIC_CHARGE)
    {
      class array<TYPE> EM_suboperator_YL_strength_tab(Nr);
      
      EM_suboperator_B_amplitude_tab_calc (ELECTRIC_CHARGE_YL , q , L , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , 
					   PSI_full , Jc , PSI_cluster_c , Jcp , PSI_cluster_cp , EM_suboperator_YL_strength_tab);
	  
      const class array<TYPE> EM_suboperator_intrinsic_YL_strength_tab = EM_suboperator_YL_strength_tab/j0_ME;
      
      EM_suboperator_intrinsic_NBMEs_strength_tab = (EM_suboperator_NBMEs_tab - EM_suboperator_intrinsic_YL_strength_tab*(hat_j0_derivative_ME - j0_ME + 0.5*q*RCM_hat_j0_ME))/j0_ME;
      
      return;
    }

  if (EM_suboperator == MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLP1)
    {	
      class array<TYPE> EM_suboperator_magnetic_spin_gradient_Bessel_strength_tab(Nr);
      
      EM_suboperator_B_amplitude_tab_calc (MAGNETIC_SPIN_GRADIENT_BESSEL_YLP1 , q , L , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , 
					   PSI_full , Jc , PSI_cluster_c , Jcp , PSI_cluster_cp , EM_suboperator_magnetic_spin_gradient_Bessel_strength_tab);
      
      const class array<TYPE> EM_suboperator_intrinsic_magnetic_spin_gradient_Bessel_strength_tab = EM_suboperator_magnetic_spin_gradient_Bessel_strength_tab/j0_ME;
      
      EM_suboperator_intrinsic_NBMEs_strength_tab = (EM_suboperator_NBMEs_tab - EM_suboperator_intrinsic_magnetic_spin_gradient_Bessel_strength_tab*(hat_j0_derivative_ME - j0_ME))/j0_ME;
      
      return;
    }
  
  if (EM_suboperator == MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLM1)
    {	
      class array<TYPE> EM_suboperator_magnetic_spin_gradient_Bessel_strength_tab(Nr);
      
      EM_suboperator_B_amplitude_tab_calc (MAGNETIC_SPIN_GRADIENT_BESSEL_YLM1 , q , L , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , 
					   PSI_full , Jc , PSI_cluster_c , Jcp , PSI_cluster_cp , EM_suboperator_magnetic_spin_gradient_Bessel_strength_tab);
      
      const class array<TYPE> EM_suboperator_intrinsic_magnetic_spin_gradient_Bessel_strength_tab = EM_suboperator_magnetic_spin_gradient_Bessel_strength_tab/j0_ME;
      
      EM_suboperator_intrinsic_NBMEs_strength_tab = (EM_suboperator_NBMEs_tab - EM_suboperator_intrinsic_magnetic_spin_gradient_Bessel_strength_tab*(hat_j0_derivative_ME - j0_ME))/j0_ME;
      
      return;
    }
  
  error_message_print_abort ("No electromagnetic/radial operator type combination recognized in EM_suboperator_intrinsic_NBMEs_calc");
}














void CC_EM_transitions_strength_MEs::cluster::electric::intrinsic_NBMEs_store (
									       const class CC_target_projectile_composite_data &Tpc_data , 
									       const unsigned int ic , 
									       const unsigned int icp , 
									       const int L , 
									       const int l_intrinsic , 
									       class array<TYPE> &ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab , 
									       class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab , 
									       class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab , 
									       class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab)
{
  const unsigned int ELECTRIC_CHARGE_YL_TENSOR_E_index = EM_suboperator_type_index_determine (ELECTRIC_CHARGE_YL_TENSOR_E);
  
  const unsigned int ELECTRIC_CURRENT_YL_TENSOR_S_index   = EM_suboperator_type_index_determine (ELECTRIC_CURRENT_YL_TENSOR_S);
  const unsigned int ELECTRIC_CURRENT_YL_TENSOR_R_S_index = EM_suboperator_type_index_determine (ELECTRIC_CURRENT_YL_TENSOR_R_S);
  const unsigned int ELECTRIC_CURRENT_YL_TENSOR_P_S_index = EM_suboperator_type_index_determine (ELECTRIC_CURRENT_YL_TENSOR_P_S);

  const unsigned int Nr = ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab.dimension (1);

  const int lp_intrinsic_min = max (l_intrinsic - 1 , 0);

  const int lp_intrinsic_max = l_intrinsic + 1;

  const class array<TYPE> &EM_suboperator_intrinsic_NBMEs_strength = Tpc_data.get_EM_suboperator_intrinsic_NBMEs_strength ();

  for (int lp_intrinsic = lp_intrinsic_min ; lp_intrinsic <= lp_intrinsic_max ; lp_intrinsic++)
    {
      const unsigned int i_lp_int = make_uns_int (lp_intrinsic - lp_intrinsic_min);

      for (unsigned int i = 0 ; i < Nr ; i++)
	{
	  ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab(i_lp_int , i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , lp_intrinsic , ELECTRIC_CHARGE_YL_TENSOR_E_index , i);
      
	  EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab  (i_lp_int , i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , lp_intrinsic , ELECTRIC_CURRENT_YL_TENSOR_S_index , i);
	  EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab(i_lp_int , i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , lp_intrinsic , ELECTRIC_CURRENT_YL_TENSOR_R_S_index , i);
	  EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab(i_lp_int , i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , lp_intrinsic , ELECTRIC_CURRENT_YL_TENSOR_P_S_index , i);
	}
    }
}





void CC_EM_transitions_strength_MEs::cluster::electric::charge_ME_reduced_part_calc (
										     const bool is_it_longwavelength_approximation ,
										     const bool is_it_Gauss_Legendre , 
										     const int l_intrinsic , 
										     const int LCM ,
										     const int L ,  
										     const class CC_state_class &CC_state_in , 
										     const class CC_state_class &CC_state_out , 
										     const unsigned int ic_in , 
										     const unsigned int ic_out , 
										     const class array<TYPE> &ECH_all_intrinsic_NBME_tab , 
										     const class array<TYPE> &ECH_intrinsic_NBME_jl_Yl_tab , 
										     const class array<TYPE> &ECH_intrinsic_NBME_hat_jl_over_r_Yl_tab , 
										     const class array<TYPE> &ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab , 
										     class array<TYPE> &ECH_ME_reduced_part_tab)
{
  const unsigned int Nr = ECH_all_intrinsic_NBME_tab.dimension (0);
  
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile  ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  //--// calculations of the radial electric charge and current
  
  class array<TYPE> ECH_CM_radial_ME_jl_tab(Nr);
  class array<TYPE> ECH_CM_radial_ME_hat_jl_tab(Nr);
  class array<TYPE> ECH_CM_radial_ME_hat_jl_r_tab(Nr);
  class array<TYPE> ECH_CM_radial_ME_hat_jl_der_tab(Nr);

  radial_OBMEs_calc (BESSEL                    , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , ECH_CM_radial_ME_jl_tab);
  radial_OBMEs_calc (RICCATI_BESSEL            , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , ECH_CM_radial_ME_hat_jl_tab);
  radial_OBMEs_calc (RICCATI_BESSEL_R          , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , ECH_CM_radial_ME_hat_jl_r_tab);
  radial_OBMEs_calc (RICCATI_BESSEL_DERIVATIVE , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , ECH_CM_radial_ME_hat_jl_der_tab);
  
  const TYPE Y_LCM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);
  
  const class array<TYPE> ECH_CM_ME_jl_Yl_tab         = ECH_CM_radial_ME_jl_tab        *Y_LCM_ME;
  const class array<TYPE> ECH_CM_ME_hat_jl_r_Yl_tab   = ECH_CM_radial_ME_hat_jl_r_tab  *Y_LCM_ME;
  const class array<TYPE> ECH_CM_ME_hat_jl_der_Yl_tab = ECH_CM_radial_ME_hat_jl_der_tab*Y_LCM_ME;

  const int LCM_p_min = max (LCM - 1 , 0);

  const int LCM_p_max = LCM + 1;

  const unsigned int LCM_p_number = make_uns_int (LCM_p_max - LCM_p_min) + 1;

  const unsigned int lp_intrinsic_number = ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab.dimension (0);
  
  class array<TYPE> Yl_tensor_e_CM_OBMEs(LCM_p_number);

  class array<TYPE> ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_r_tab(lp_intrinsic_number);

  class array<TYPE> ECH_CM_hat_jl_Yl_tensor_e_CM_OBMEs(LCM_p_number);
  
  for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
    {
      const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

      Yl_tensor_e_CM_OBMEs(i_LCM_p) = OBME_YL_tensor_e_reduced_in_l (LCM , LCM_p , LCM_projectile_in , LCM_projectile_out);
    }
  
  for (unsigned int i = 0 ; i < Nr ; i++)
    {    	
      const TYPE ECH_CM_ME_jl_Yl         = ECH_CM_ME_jl_Yl_tab(i);
      const TYPE ECH_CM_ME_hat_jl_r_Yl   = ECH_CM_ME_hat_jl_r_Yl_tab(i);
      const TYPE ECH_CM_ME_hat_jl_der_Yl = ECH_CM_ME_hat_jl_der_Yl_tab(i);
   
      const TYPE ECH_all_intrinsic_NBME              = ECH_all_intrinsic_NBME_tab(i);
      const TYPE ECH_intrinsic_NBME_jl_Yl            = ECH_intrinsic_NBME_jl_Yl_tab(i);
      const TYPE ECH_intrinsic_NBME_hat_jl_over_r_Yl = ECH_intrinsic_NBME_hat_jl_over_r_Yl_tab(i);

      const class array<TYPE> ECH_CM_hat_jl_Yl_tensor_e_CM_OBMEs = ECH_CM_radial_ME_hat_jl_tab(i)*Yl_tensor_e_CM_OBMEs;
      
      for (unsigned int i_lp = 0 ; i_lp < lp_intrinsic_number ; i_lp++) ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_r_tab(i_lp) = ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab(i_lp , i);
	
      const TYPE ECH_ME_jl_Yl_CM_all_Yl_intrinsic = Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
										  LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
										  LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
										  ECH_CM_ME_jl_Yl , ECH_all_intrinsic_NBME);

      const TYPE ECH_ME_hat_jl_der_Yl_CM_jl_Yl_intrinsic = Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
											 LCM_projectile_in , l_intrinsic , J_projectile_in , 
											 LCM_projectile_out , l_intrinsic , J_projectile_out ,
											 ECH_CM_ME_hat_jl_der_Yl , ECH_intrinsic_NBME_jl_Yl);
	
      const TYPE ECH_ME_jl_Yl_CM_jl_Yl_intrinsic = Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
										 LCM_projectile_in , l_intrinsic , J_projectile_in , 
										 LCM_projectile_out , l_intrinsic , J_projectile_out ,
										 ECH_CM_ME_jl_Yl , ECH_intrinsic_NBME_jl_Yl);
	
      const TYPE ECH_ME_hat_jl_r_Yl_CM_hat_jl_over_r_Yl_intrinsic = Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
												  LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
												  LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
												  ECH_CM_ME_hat_jl_r_Yl , ECH_intrinsic_NBME_hat_jl_over_r_Yl);
      
      const TYPE ECH_ME_hat_jl_Yl_e_CM_hat_jl_Yl_e_intrinsic = O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (LCM , l_intrinsic , L , 1 ,
														LCM_projectile_in , l_intrinsic , J_projectile_in , 
														LCM_projectile_out , l_intrinsic , J_projectile_out ,
														ECH_CM_hat_jl_Yl_tensor_e_CM_OBMEs , ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_r_tab);

      const TYPE ECH_MEs_sum = ECH_ME_jl_Yl_CM_all_Yl_intrinsic + ECH_ME_hat_jl_der_Yl_CM_jl_Yl_intrinsic - ECH_ME_jl_Yl_CM_jl_Yl_intrinsic + 0.5*ECH_ME_hat_jl_r_Yl_CM_hat_jl_over_r_Yl_intrinsic + ECH_ME_hat_jl_Yl_e_CM_hat_jl_Yl_e_intrinsic;
  
      ECH_ME_reduced_part_tab(i) = ECH_MEs_sum;
    }
}









void CC_EM_transitions_strength_MEs::cluster::electric::current_ME_reduced_part_calc (
										      const bool is_it_longwavelength_approximation ,
										      const bool is_it_Gauss_Legendre , 
										      const int l_intrinsic , 
										      const int LCM , 
										      const int L , 
										      const class CC_state_class &CC_state_in , 
										      const class CC_state_class &CC_state_out , 
										      const unsigned int ic_in , 
										      const unsigned int ic_out , 
										      const class array<TYPE> &EC_all_intrinsic_NBME_tab , 
										      const class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab , 
										      const class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab , 
										      const class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab ,
										      class array<TYPE> &EC_ME_reduced_part_tab)
{
  const unsigned int Nr = EC_all_intrinsic_NBME_tab.dimension (0);
  
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();
  
  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  const int A_projectile = channel_c_in.get_A_projectile  ();
  
  //--// calculations of the radial electric charge and current

  class array<TYPE> EC_CM_radial_ME_jl_tab       (Nr);
  class array<TYPE> EC_CM_radial_ME_jl_r_tab     (Nr);
  class array<TYPE> EC_CM_radial_ME_jl_over_r_tab(Nr);
  class array<TYPE> EC_CM_radial_ME_jl_r_der_tab (Nr);

  radial_OBMEs_calc (BESSEL        , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , EC_CM_radial_ME_jl_tab);
  radial_OBMEs_calc (BESSEL_R      , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , EC_CM_radial_ME_jl_r_tab);
  radial_OBMEs_calc (BESSEL_OVER_R , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , EC_CM_radial_ME_jl_over_r_tab);
  radial_OBMEs_calc (BESSEL_DR     , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , EC_CM_radial_ME_jl_r_der_tab);
 
  const TYPE Y_LCM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);
  
  const class array<TYPE> EC_CM_ME_jl_Yl_tab = Y_LCM_ME*EC_CM_radial_ME_jl_tab;

  const int LCM_p_min = max (LCM - 1 , 0);

  const int LCM_p_max = LCM + 1;

  const unsigned int LCM_p_number = make_uns_int (LCM_p_max - LCM_p_min) + 1;

  const unsigned int lp_intrinsic_number = EC_all_intrinsic_NBME_tab.dimension (0);

  class array<TYPE> Yl_tensor_l_CM_ME_tab(LCM_p_number);
  class array<TYPE> Yl_tensor_e_CM_OBMEs(LCM_p_number);

  for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
    {
      const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

      Yl_tensor_l_CM_ME_tab(i_LCM_p) = OBME_YL_tensor_l_reduced_in_l (LCM , LCM_p , LCM_projectile_in , LCM_projectile_out);
      Yl_tensor_e_CM_OBMEs(i_LCM_p) = OBME_YL_tensor_e_reduced_in_l (LCM , LCM_p , LCM_projectile_in , LCM_projectile_out);
    }
  
  class array<TYPE> EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_r_tab  (lp_intrinsic_number);
  class array<TYPE> EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_r_tab(lp_intrinsic_number);
  class array<TYPE> EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_r_tab(lp_intrinsic_number);
  
  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      for (unsigned int i_lp = 0 ; i_lp < lp_intrinsic_number ; i_lp++)
	{
	  EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_r_tab  (i_lp) = EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab  (i_lp , i);
	  EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_r_tab(i_lp) = EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab(i_lp , i);
	  EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_r_tab(i_lp) = EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab(i_lp , i);
	}
      
      const class array<TYPE> EC_CM_jl_Yl_tensor_l_ME_r_tab = EC_CM_radial_ME_jl_tab(i)*Yl_tensor_l_CM_ME_tab;

      const class array<TYPE> EC_CM_jl_Yl_tensor_r_ME_r_tab = EC_CM_radial_ME_jl_r_tab(i)*Yl_tensor_e_CM_OBMEs;
  
      class array<TYPE> EC_CM_jl_Yl_tensor_p_ME_r_tab = EC_CM_radial_ME_jl_r_der_tab(i)*Yl_tensor_e_CM_OBMEs;

      for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
	{
	  const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

	  double EC_CM_jl_Yl_tensor_p_angular_part_ME = 0.0;
	
	  for (int LCM_projectile_inter = (LCM_projectile_in == 0) ? (LCM_projectile_in + 1) : (LCM_projectile_in - 1) ; LCM_projectile_inter <= LCM_projectile_in + 1 ; LCM_projectile_inter += 2)
	    {
	      const double YLCM_reduced = OBME_YL_reduced_in_l (LCM , LCM_projectile_inter , LCM_projectile_out);
	  
	      const double e_reduced = OBME_e_reduced_in_l (LCM_projectile_in , LCM_projectile_inter);
      
	      const double l_factor = 0.5*(LCM_projectile_in*(LCM_projectile_in + 1.0) - LCM_projectile_inter*(LCM_projectile_inter + 1.0));
      
	      const double Wig_6j = Wigner_6j (LCM , 1 , LCM_p , LCM_projectile_in , LCM_projectile_out , LCM_projectile_inter);
      
	      EC_CM_jl_Yl_tensor_p_angular_part_ME += YLCM_reduced*e_reduced*Wig_6j*l_factor;
	    }

	  EC_CM_jl_Yl_tensor_p_angular_part_ME *= minus_one_pow (LCM_projectile_in + LCM_p + LCM_projectile_out)*hat (LCM_p);
  
	  EC_CM_jl_Yl_tensor_p_ME_r_tab(i_LCM_p) += EC_CM_jl_Yl_tensor_p_angular_part_ME*EC_CM_radial_ME_jl_over_r_tab(i);
	}
  
      const TYPE EC_CM_ME_jl_Yl = EC_CM_ME_jl_Yl_tab(i);
      
      const TYPE EC_all_intrinsic_NBME = EC_all_intrinsic_NBME_tab(i);

      const TYPE EC_ME_jl_Yl_CM_all_intrinsic = Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
									      LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
									      LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
									      EC_CM_ME_jl_Yl , EC_all_intrinsic_NBME);
      
      const TYPE EC_ME_hat_jl_over_r_Yl_l_CM_jl_Yl_s_intrinsic = O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (LCM , l_intrinsic , L , 1 ,
														  LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
														  LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
														  EC_CM_jl_Yl_tensor_l_ME_r_tab , EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_r_tab);
      
      const TYPE EC_ME_jl_Yl_p_CM_hat_jl_over_r_Yl_r_s_intrinsic = O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (LCM , l_intrinsic , L , 1 ,
														    LCM_projectile_in  , J_intrinsic_in  , J_projectile_in , 
														    LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
														    EC_CM_jl_Yl_tensor_p_ME_r_tab , EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_r_tab);
      
      const TYPE EC_ME_jl_Yl_r_CM_hat_jl_over_r_Yl_p_s_intrinsic = O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (LCM , l_intrinsic , L , 1 ,
														    LCM_projectile_in  , J_intrinsic_in  , J_projectile_in , 
														    LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
														    EC_CM_jl_Yl_tensor_r_ME_r_tab , EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_r_tab);
  
      const TYPE EC_MEs_sum = EC_ME_jl_Yl_CM_all_intrinsic + EC_ME_hat_jl_over_r_Yl_l_CM_jl_Yl_s_intrinsic/A_projectile + M_SQRT2*(EC_ME_jl_Yl_p_CM_hat_jl_over_r_Yl_r_s_intrinsic/A_projectile + EC_ME_jl_Yl_r_CM_hat_jl_over_r_Yl_p_s_intrinsic);
      
      EC_ME_reduced_part_tab(i) = EC_MEs_sum;
    }
}






//--// calculate <uc_f lf jf || E_L || uc_i li ji>
void CC_EM_transitions_strength_MEs::cluster::electric::calc (
							      const int L , 
							      const bool is_it_longwavelength_approximation ,
							      const bool is_it_Gauss_Legendre , 
							      const class CC_target_projectile_composite_data &Tpc_data , 
							      const class array<class cluster_data> &cluster_projectile_data_tab , 
							      const unsigned int ic ,
							      const unsigned int icp ,  
							      const class CC_state_class &CC_state_in , 
							      const class CC_state_class &CC_state_out , 
							      const unsigned int ic_in , 
							      const unsigned int ic_out , 
							      class array<TYPE> &electric_strength_tab)
{
  const unsigned int Nr = electric_strength_tab.dimension (0);

  const unsigned int BP_Op = BP_EM_determine (ELECTRIC , L);

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  electric_strength_tab = 0.0;
  
  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out + 1) == BP_Op)
    {
      const complex<double> E_in_complex  = CC_state_in.get_E ();
      const complex<double> E_out_complex = CC_state_out.get_E ();
  
      const TYPE E_in  = generate_scalar<TYPE> (real (E_in_complex)  , imag (E_in_complex));
      const TYPE E_out = generate_scalar<TYPE> (real (E_out_complex) , imag (E_out_complex));
  
      const TYPE q = (E_in - E_out)/hbar_c;
      
      const unsigned int ELECTRIC_CHARGE_YL_index = EM_suboperator_type_index_determine (ELECTRIC_CHARGE_YL);
      const unsigned int ELECTRIC_CHARGE_index    = EM_suboperator_type_index_determine (ELECTRIC_CHARGE);
      const unsigned int ELECTRIC_CURRENT_index   = EM_suboperator_type_index_determine (ELECTRIC_CURRENT);

      const class cluster_data &data_c  = cluster_projectile_data_tab(ic);
      const class cluster_data &data_cp = cluster_projectile_data_tab(icp);

      const double J_intrinsic_in  = data_c.get_J_intrinsic ();
      const double J_intrinsic_out = data_cp.get_J_intrinsic ();
      
      const int l_intrinsic_min = abs (make_int (J_intrinsic_in - J_intrinsic_out));

      const int l_intrinsic_max = make_int (J_intrinsic_in + J_intrinsic_out);

      const class array<TYPE> &EM_suboperator_intrinsic_NBMEs_strength = Tpc_data.get_EM_suboperator_intrinsic_NBMEs_strength ();

      class array<TYPE> ECH_intrinsic_NBME_jl_Yl_tab(Nr);
      
      class array<TYPE> ECH_all_intrinsic_NBME_tab(Nr);      
      class array<TYPE> EC_all_intrinsic_NBME_tab(Nr);

      class array<TYPE> ECH_ME_reduced_part_tab(Nr);
      class array<TYPE> EC_ME_reduced_part_tab(Nr);
	
      for (int l_intrinsic = l_intrinsic_min ; l_intrinsic <= l_intrinsic_max ; l_intrinsic++)
	{
	  for (unsigned int i = 0 ; i < Nr ; i++)
	    {	
	      ECH_intrinsic_NBME_jl_Yl_tab(i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ELECTRIC_CHARGE_YL_index);
	      
	      ECH_all_intrinsic_NBME_tab(i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ELECTRIC_CHARGE_index);

	      EC_all_intrinsic_NBME_tab(i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ELECTRIC_CURRENT_index);
	    }
  
	  class array<TYPE> ECH_intrinsic_NBME_hat_jl_over_r_Yl_tab = q*ECH_intrinsic_NBME_jl_Yl_tab;
      
	  const int lp_intrinsic_min = max (l_intrinsic - 1 , 0);

	  const int lp_intrinsic_max = l_intrinsic + 1;

	  const unsigned int lp_intrinsic_number = make_uns_int (lp_intrinsic_max - lp_intrinsic_min) + 1;

	  class array<TYPE> ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab(lp_intrinsic_number , Nr);

	  class array<TYPE> EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab  (lp_intrinsic_number , Nr);
	  class array<TYPE> EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab(lp_intrinsic_number , Nr);
	  class array<TYPE> EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab(lp_intrinsic_number , Nr);

	  electric::intrinsic_NBMEs_store (Tpc_data , ic , icp , L , l_intrinsic , ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab ,
					   EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab , EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab , EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab);

	  const int LCM_min_in_out = abs (LCM_projectile_in - LCM_projectile_out);

	  const int LCM_max_in_out = LCM_projectile_in + LCM_projectile_out;

	  const int LCM_min_l_intrinsic_L = abs (L - l_intrinsic);

	  const int LCM_max_l_intrinsic_L = L + l_intrinsic;

	  const int LCM_min = max (LCM_min_in_out , LCM_min_l_intrinsic_L);
	  const int LCM_max = min (LCM_max_in_out , LCM_max_l_intrinsic_L);

	  for (int LCM = LCM_min ; LCM <= LCM_max ; LCM++)
	    {
	      const TYPE coupling_term = coupling_term_l_intrinsic_LCM (l_intrinsic , LCM , L);

	      electric::charge_ME_reduced_part_calc (is_it_longwavelength_approximation , is_it_Gauss_Legendre , l_intrinsic , LCM , L ,
						     CC_state_in , CC_state_out , ic_in , ic_out , 
						     ECH_all_intrinsic_NBME_tab , ECH_intrinsic_NBME_jl_Yl_tab , ECH_intrinsic_NBME_hat_jl_over_r_Yl_tab , ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab ,
						     ECH_ME_reduced_part_tab);
 
	      electric::current_ME_reduced_part_calc (is_it_longwavelength_approximation , is_it_Gauss_Legendre , l_intrinsic , LCM , L ,
						      CC_state_in , CC_state_out , ic_in , ic_out , 
						      EC_all_intrinsic_NBME_tab , EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab , EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab , EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab ,
						      EC_ME_reduced_part_tab);
	      
	      electric_strength_tab += coupling_term*(ECH_ME_reduced_part_tab + EC_ME_reduced_part_tab);
	    }
	}
    }
}









void CC_EM_transitions_strength_MEs::cluster::magnetic::intrinsic_NBMEs_store (
									       const class CC_target_projectile_composite_data &Tpc_data , 
									       const unsigned int ic , 
									       const unsigned int icp , 
									       const int L , 
									       const int l_intrinsic , 
									       class array<TYPE> &MSSCE_Bessel_intrinsic_NBME_tab)
{
  const unsigned int MAGNETIC_SPIN_YL_TENSOR_S_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_YL_TENSOR_S);
    
  const int lp_intrinsic_min = max (l_intrinsic - 1 , 0);

  const int lp_intrinsic_max = l_intrinsic + 1;

  const class array<TYPE> &EM_suboperator_intrinsic_NBMEs_strength = Tpc_data.get_EM_suboperator_intrinsic_NBMEs_strength ();
  
  const unsigned int Nr = MSSCE_Bessel_intrinsic_NBME_tab.dimension (0);
  
  for (int lp_intrinsic = lp_intrinsic_min ; lp_intrinsic <= lp_intrinsic_max ; lp_intrinsic++)
    {
      const unsigned int i_lp_intrinsic = make_uns_int (lp_intrinsic - lp_intrinsic_min);

      for (unsigned int i = 0 ; i < Nr ; i++)
	MSSCE_Bessel_intrinsic_NBME_tab(i_lp_intrinsic , i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , lp_intrinsic , MAGNETIC_SPIN_YL_TENSOR_S_index , i);
    }
}


















void CC_EM_transitions_strength_MEs::cluster::magnetic::orbital_gradient_ME_reduced_part_calc (
											       const int pm,
											       const bool is_it_longwavelength_approximation ,
											       const bool is_it_Gauss_Legendre , 
											       const int l_intrinsic , 
											       const int LCM , 
											       const int L , 
											       const class CC_state_class &CC_state_in , 
											       const class CC_state_class &CC_state_out , 
											       const unsigned int ic_in , 
											       const unsigned int ic_out , 
											       const class array<TYPE> &MO_all_intrinsic_NBME_tab , 
											       const class array<TYPE> &MO_intrinsic_NBME_grad_jl_Yl_tab , 
											       const class array<TYPE> &MO_intrinsic_NBME_grad_jl_Yl_r_tab , 
											       const class array<TYPE> &MO_intrinsic_NBME_grad_jl_Yl_p_tab ,
											       class array<TYPE> &orbital_ME_reduced_part_tab)
{
  orbital_ME_reduced_part_tab = 0.0;
  
  const int l_intrinsic_pm_one = l_intrinsic + pm;
  
  if (l_intrinsic_pm_one < 0) return;
 
  const unsigned int Nr = MO_all_intrinsic_NBME_tab.dimension (0);
  
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  const int A_projectile = channel_c_in.get_A_projectile  ();
  
  class array<TYPE> MO_CM_radial_ME_jl_tab(Nr);
  class array<TYPE> MO_CM_radial_ME_jl_r_tab(Nr);
  class array<TYPE> MO_CM_radial_ME_jl_over_r_tab(Nr);
  class array<TYPE> MO_CM_radial_ME_jl_r_der_tab(Nr);
  
  radial_OBMEs_calc (BESSEL        , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , MO_CM_radial_ME_jl_tab);
  radial_OBMEs_calc (BESSEL_R      , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , MO_CM_radial_ME_jl_r_tab);
  radial_OBMEs_calc (BESSEL_OVER_R , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , MO_CM_radial_ME_jl_over_r_tab);
  radial_OBMEs_calc (BESSEL_DR     , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_out , CC_state_in , ic_out , ic_in , MO_CM_radial_ME_jl_r_der_tab);

  const TYPE MO_Yl_CM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);
  
  const class array<TYPE> MO_jl_Yl_CM_ME_tab = MO_Yl_CM_ME*MO_CM_radial_ME_jl_tab;

  const int LCM_p_min = max (LCM - 1 , 0);

  const int LCM_p_max = LCM + 1;

  const unsigned int LCM_p_number = make_uns_int (LCM_p_max - LCM_p_min) + 1;

  class array<TYPE> l_tensor_Yl_CM_ME_tab(LCM_p_number);  
  class array<TYPE> e_tensor_Yl_CM_ME_tab(LCM_p_number);

  for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
    {
      const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

      l_tensor_Yl_CM_ME_tab(i_LCM_p) = OBME_YL_tensor_l_reduced_in_l (LCM , LCM_p , LCM_projectile_out , LCM_projectile_in )*minus_one_pow (LCM_projectile_out - LCM_projectile_in);
      e_tensor_Yl_CM_ME_tab(i_LCM_p) = OBME_e_tensor_YL_reduced_in_l (LCM , LCM_p , LCM_projectile_in  , LCM_projectile_out);
    }
  
  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      const class TYPE MO_jl_Yl_CM_ME = MO_jl_Yl_CM_ME_tab(i);
  
      const TYPE MO_all_intrinsic_NBME = MO_all_intrinsic_NBME_tab(i);

      const TYPE MO_intrinsic_NBME_grad_jl_Yl = MO_intrinsic_NBME_grad_jl_Yl_tab(i);
      
      const class array<TYPE> MO_jl_l_tensor_Yl_CM_ME_r_tab = MO_CM_radial_ME_jl_tab(i)*l_tensor_Yl_CM_ME_tab;
  
      const class array<TYPE> MO_jl_r_tensor_Yl_CM_ME_r_tab = MO_CM_radial_ME_jl_r_tab(i)*e_tensor_Yl_CM_ME_tab;
      
      class array<TYPE> MO_jl_p_tensor_Yl_CM_ME_r_tab = MO_CM_radial_ME_jl_r_der_tab(i)*e_tensor_Yl_CM_ME_tab;

      for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
	{
	  const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

	  double MO_jl_p_tensor_Yl_CM_angular_part_ME = 0.0;
	
	  for (int LCM_projectile_inter = (LCM_projectile_out == 0) ? (LCM_projectile_out + 1) : (LCM_projectile_out - 1) ; LCM_projectile_inter <= LCM_projectile_out + 1 ; LCM_projectile_inter += 2)
	    {	  
	      const double e_reduced = OBME_e_reduced_in_l (LCM_projectile_inter , LCM_projectile_out);
	  
	      const double YLCM_reduced = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_inter);
      
	      const double l_factor = 0.5*(LCM_projectile_out*(LCM_projectile_out + 1.0) - LCM_projectile_inter*(LCM_projectile_inter + 1.0));
      
	      const double Wig_6j = Wigner_6j (LCM , 1 , LCM_p , LCM_projectile_in , LCM_projectile_out , LCM_projectile_inter);
      
	      MO_jl_p_tensor_Yl_CM_angular_part_ME += YLCM_reduced*e_reduced*Wig_6j*l_factor;
	    }

	  MO_jl_p_tensor_Yl_CM_angular_part_ME *= minus_one_pow (LCM_projectile_in + LCM_p + LCM_projectile_out)*hat (LCM_p);
      
	  MO_jl_p_tensor_Yl_CM_ME_r_tab(i_LCM_p) += MO_jl_p_tensor_Yl_CM_angular_part_ME*MO_CM_radial_ME_jl_over_r_tab(i);
	}
  
      MO_jl_p_tensor_Yl_CM_ME_r_tab *= -1;
  
      class array<TYPE> MO_intrinsic_NBME_grad_jl_Yl_r_r_tab(3);
      class array<TYPE> MO_intrinsic_NBME_grad_jl_Yl_p_r_tab(3);

      MO_intrinsic_NBME_grad_jl_Yl_r_r_tab(0) = MO_intrinsic_NBME_grad_jl_Yl_r_tab(0 , i) , MO_intrinsic_NBME_grad_jl_Yl_p_r_tab(0) = MO_intrinsic_NBME_grad_jl_Yl_p_tab(0 , i);
      MO_intrinsic_NBME_grad_jl_Yl_r_r_tab(1) = MO_intrinsic_NBME_grad_jl_Yl_r_tab(1 , i) , MO_intrinsic_NBME_grad_jl_Yl_p_r_tab(1) = MO_intrinsic_NBME_grad_jl_Yl_p_tab(1 , i);
      MO_intrinsic_NBME_grad_jl_Yl_r_r_tab(2) = MO_intrinsic_NBME_grad_jl_Yl_r_tab(2 , i) , MO_intrinsic_NBME_grad_jl_Yl_p_r_tab(2) = MO_intrinsic_NBME_grad_jl_Yl_p_tab(2 , i);
            
      const TYPE MO_ME_jl_Yl_CM_all_intrinsic = Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
									      LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
									      LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
									      MO_jl_Yl_CM_ME , MO_all_intrinsic_NBME);

      const TYPE MO_l_jl_Yl_CM_grad_jl_Yl_intrinsic = O1a_tensor_O2b_k12_tensor_O3b_reduced_ME_calc (l_intrinsic_pm_one , 1 , l_intrinsic , LCM , L ,
												     J_intrinsic_in , LCM_projectile_in , J_projectile_in , 
												     J_intrinsic_out , LCM_projectile_out , J_projectile_out ,
												     MO_intrinsic_NBME_grad_jl_Yl , MO_jl_l_tensor_Yl_CM_ME_r_tab);
  
      const TYPE MO_p_jl_Yl_CM_grad_jl_Yl_r_intrinsic = O1b_tensor_O2a_tensor_O3a_tensor_O4b_k34_k234_reduced_ME_calc (LCM , l_intrinsic_pm_one , 1 , 1 , 1 , l_intrinsic , L ,
														       LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
														       LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
														       MO_jl_p_tensor_Yl_CM_ME_r_tab , MO_intrinsic_NBME_grad_jl_Yl_r_r_tab);

      const TYPE MO_r_jl_Yl_CM_grad_jl_Yl_p_intrinsic = O1b_tensor_O2a_tensor_O3a_tensor_O4b_k34_k234_reduced_ME_calc (LCM , l_intrinsic_pm_one , 1 , 1 , 1 , l_intrinsic , L ,
														       LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
														       LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
														       MO_jl_r_tensor_Yl_CM_ME_r_tab , MO_intrinsic_NBME_grad_jl_Yl_p_r_tab);
      
      const TYPE MO_sum = MO_ME_jl_Yl_CM_all_intrinsic + MO_l_jl_Yl_CM_grad_jl_Yl_intrinsic/A_projectile - M_SQRT2*(MO_p_jl_Yl_CM_grad_jl_Yl_r_intrinsic/A_projectile - MO_r_jl_Yl_CM_grad_jl_Yl_p_intrinsic);
      
      orbital_ME_reduced_part_tab(i) = MO_sum;
    }
}









void CC_EM_transitions_strength_MEs::cluster::magnetic::spin_gradient_ME_reduced_calc (
										       const bool is_it_longwavelength_approximation ,
										       const bool is_it_Gauss_Legendre , 
										       const int l_intrinsic , 
										       const int LCM , 
										       const int L , 
										       const class CC_state_class &CC_state_in , 
										       const class CC_state_class &CC_state_out , 
										       const unsigned int ic_in , 
										       const unsigned int ic_out , 
										       const class array<TYPE> &MS_all_intrinsic_NBME_tab ,
										       const class array<TYPE> &MS_intrinsic_NBME_jl_Yl_tensor_s_tab ,
										       class array<TYPE> &spin_ME_reduced_part_tab)
{
  const unsigned int Nr = MS_all_intrinsic_NBME_tab.dimension (1);
  
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  class array<TYPE> MS_CM_radial_ME_jl_tab(Nr);
  class array<TYPE> MS_CM_radial_ME_hat_jl_der_tab(Nr);

  radial_OBMEs_calc (BESSEL                    , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , MS_CM_radial_ME_jl_tab);
  radial_OBMEs_calc (RICCATI_BESSEL_DERIVATIVE , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , MS_CM_radial_ME_hat_jl_der_tab);

  const TYPE MS_Yl_CM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);
  
  const class array<TYPE> MS_jl_Yl_CM_ME_tab         = MS_Yl_CM_ME*MS_CM_radial_ME_jl_tab;
  const class array<TYPE> MS_hat_jl_der_Yl_CM_ME_tab = MS_Yl_CM_ME*MS_CM_radial_ME_hat_jl_der_tab;
      
  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      const TYPE MS_all_intrinsic_NBME = MS_all_intrinsic_NBME_tab(i);

      const TYPE MS_intrinsic_NBME_jl_Yl_tensor_s = MS_intrinsic_NBME_jl_Yl_tensor_s_tab(i);

      const TYPE MS_jl_Yl_CM_ME = MS_jl_Yl_CM_ME_tab(i);

      const TYPE MS_hat_jl_der_Yl_CM_ME = MS_hat_jl_der_Yl_CM_ME_tab(i);
	
      const TYPE MS_jl_Yl_CM_all_intrinsic = Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
									   LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
									   LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
									   MS_jl_Yl_CM_ME , MS_all_intrinsic_NBME);
 
      const TYPE MS_hat_jl_der_minus_jl_Yl_CM_jl_Yl_intrinsic = Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic ,  L ,
											      LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
											      LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
											      MS_hat_jl_der_Yl_CM_ME - MS_jl_Yl_CM_ME , MS_intrinsic_NBME_jl_Yl_tensor_s);
      
      const TYPE MS_MEs_sum = MS_jl_Yl_CM_all_intrinsic + MS_hat_jl_der_minus_jl_Yl_CM_jl_Yl_intrinsic;

      spin_ME_reduced_part_tab(i) = MS_MEs_sum;
    }
}







void CC_EM_transitions_strength_MEs::cluster::magnetic::spin_s_scalar_e_ME_part_calc (
										      const bool is_it_longwavelength_approximation ,
										      const bool is_it_Gauss_Legendre , 
										      const int l_intrinsic , 
										      const int LCM , 
										      const int L , 
										      const class CC_state_class &CC_state_in , 
										      const class CC_state_class &CC_state_out , 
										      const unsigned int ic_in , 
										      const unsigned int ic_out , 
										      const class array<TYPE> &MSSCE_all_intrinsic_NBME_tab , 
										      const class array<TYPE> &MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab ,
										      class array<TYPE> &spin_ME_reduced_part_tab)
{
  const unsigned int Nr = MSSCE_all_intrinsic_NBME_tab.dimension (0);
  
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  class array<TYPE> MSSCE_CM_radial_ME_jl_tab(Nr);
  class array<TYPE> MSSCE_CM_radial_ME_jl_r_tab(Nr);

  radial_OBMEs_calc (BESSEL   , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , MSSCE_CM_radial_ME_jl_tab);
  radial_OBMEs_calc (BESSEL_R , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , MSSCE_CM_radial_ME_jl_r_tab);

  const TYPE MSSCE_Yl_CM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);
  
  const class array<TYPE> MSSCE_jl_Yl_CM_ME_tab = MSSCE_Yl_CM_ME*MSSCE_CM_radial_ME_jl_tab;

  const class array<TYPE> MSSCE_jl_r_Yl_CM_ME_tab = MSSCE_Yl_CM_ME*MSSCE_CM_radial_ME_jl_r_tab;

  const int LCM_p_min = max (LCM - 1 , 0);

  const int LCM_p_max = LCM + 1;

  const unsigned int LCM_p_number = make_uns_int (LCM_p_max - LCM_p_min) + 1;

  const unsigned int lp_intrinsic_number = MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab.dimension (0);
  
  class array<TYPE> Yl_tensor_e_CM_OBMEs(LCM_p_number);

  class array<TYPE> MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_r_tab(lp_intrinsic_number);

  for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
    {
      const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

      Yl_tensor_e_CM_OBMEs(i_LCM_p) = OBME_YL_tensor_e_reduced_in_l (LCM , LCM_p , LCM_projectile_in , LCM_projectile_out);
    }

  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      for (unsigned int i_lp = 0 ; i_lp < lp_intrinsic_number ; i_lp++)
	MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_r_tab(i_lp) = MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab(i_lp , i);

      const TYPE MSSCE_all_intrinsic_NBME = MSSCE_all_intrinsic_NBME_tab(i);

      const TYPE MSSCE_jl_Yl_CM_ME = MSSCE_jl_Yl_CM_ME_tab(i);

      const class array<TYPE> MSSCE_CM_jl_r_Yl_tensor_e_CM_OBMEs = MSSCE_jl_r_Yl_CM_ME_tab(i)*Yl_tensor_e_CM_OBMEs;
  
      const TYPE MSSCE_ME_jl_Yl_CM_all_intrinsic = Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
										 LCM_projectile_in , l_intrinsic , J_projectile_in , 
										 LCM_projectile_out , l_intrinsic , J_projectile_out ,
										 MSSCE_jl_Yl_CM_ME , MSSCE_all_intrinsic_NBME);
  
      const TYPE MSSCE_CM_hat_jl_Yl_CM_hat_jl_over_r_Yl_intrinsic = O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (LCM , l_intrinsic , L , 1 ,
														     LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
														     LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
														     MSSCE_CM_jl_r_Yl_tensor_e_CM_OBMEs ,
														     MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab);
      
      const TYPE MSSCE_sum = MSSCE_ME_jl_Yl_CM_all_intrinsic + MSSCE_CM_hat_jl_Yl_CM_hat_jl_over_r_Yl_intrinsic;
  
      spin_ME_reduced_part_tab(i) = MSSCE_sum;
    }
}









//--// calculate <uc_f lf jf || E_L || uc_i li ji>
void CC_EM_transitions_strength_MEs::cluster::magnetic::calc (
							      const int L , 
							      const bool is_it_longwavelength_approximation ,
							      const bool is_it_Gauss_Legendre , 
							      const class CC_target_projectile_composite_data &Tpc_data , 
							      const class array<class cluster_data> &cluster_projectile_data_tab , 
							      const unsigned int ic , 
							      const unsigned int icp , 
							      const class CC_state_class &CC_state_in , 
							      const class CC_state_class &CC_state_out , 
							      const unsigned int ic_in , 
							      const unsigned int ic_out , 
							      class array<TYPE> &magnetic_strength_tab)
{
  const unsigned int Nr = magnetic_strength_tab.dimension (0);

  const unsigned int BP_Op = BP_EM_determine (MAGNETIC , L);

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const class array<TYPE> &EM_suboperator_intrinsic_NBMEs_strength = Tpc_data.get_EM_suboperator_intrinsic_NBMEs_strength ();

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  magnetic_strength_tab = 0.0;
  
  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out + 1) == BP_Op)
    {
      const unsigned int SPIN_S_SCALAR_E_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_S_SCALAR_E);
      
      const unsigned int ORBITAL_GRADIENT_BESSEL_YLP1_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1);
      const unsigned int ORBITAL_GRADIENT_BESSEL_YLM1_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1);
      
      const unsigned int ORBITAL_GRADIENT_BESSEL_YLP1_R_L_index   = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_R_L);
      const unsigned int ORBITAL_GRADIENT_BESSEL_YLP1_R_LP2_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_R_LP2);      
      const unsigned int ORBITAL_GRADIENT_BESSEL_YLP1_P_L_index   = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_P_L);
      const unsigned int ORBITAL_GRADIENT_BESSEL_YLP1_P_LP2_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_P_LP2);

      const unsigned int ORBITAL_GRADIENT_BESSEL_YLM1_R_LM2_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_R_LM2);
      const unsigned int ORBITAL_GRADIENT_BESSEL_YLM1_R_L_index   = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_R_L);
      const unsigned int ORBITAL_GRADIENT_BESSEL_YLM1_P_LM2_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_P_LM2);
      const unsigned int ORBITAL_GRADIENT_BESSEL_YLM1_P_L_index   = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_P_L);
      
      const unsigned int SPIN_GRADIENT_BESSEL_YLP1_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_GRADIENT_BESSEL_YLP1);
      const unsigned int SPIN_GRADIENT_BESSEL_YLM1_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_GRADIENT_BESSEL_YLM1);

      const unsigned int SPIN_GRADIENT_RICCATI_BESSEL_DER_YLP1_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLP1);
      const unsigned int SPIN_GRADIENT_RICCATI_BESSEL_DER_YLM1_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLM1);

      const class cluster_data &data_c  = cluster_projectile_data_tab(ic);
      const class cluster_data &data_cp = cluster_projectile_data_tab(icp);

      const double J_intrinsic_in  = data_c.get_J_intrinsic ();
      const double J_intrinsic_out = data_cp.get_J_intrinsic ();

      const int l_intrinsic_min = abs (make_int (J_intrinsic_in - J_intrinsic_out));
      const int l_intrinsic_max = make_int (J_intrinsic_in + J_intrinsic_out);

      class array<TYPE> MOLP1INT_all_intrinsic_NBME_tab(Nr);
      class array<TYPE> MOLM1INT_all_intrinsic_NBME_tab(Nr);
      
      class array<TYPE> MSLP1INT_all_intrinsic_NBME_tab(Nr);
      class array<TYPE> MSLM1INT_all_intrinsic_NBME_tab(Nr);

      class array<TYPE> MSSCE_all_intrinsic_NBME_tab(Nr);

      class array<TYPE> MOLP1INT_intrinsic_NBME_grad_jl_Yl_tab(Nr);
      class array<TYPE> MOLM1INT_intrinsic_NBME_grad_jl_Yl_tab(Nr);

      class array<TYPE> MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab(3 , Nr);
      class array<TYPE> MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_tab(3 , Nr);
      class array<TYPE> MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_tab(3 , Nr);
      class array<TYPE> MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_tab(3 , Nr);
      
      class array<TYPE> MSLP1INT_intrinsic_NBME_grad_jl_Yl_tensor_s_tab(Nr);
      class array<TYPE> MSLM1INT_intrinsic_NBME_grad_jl_Yl_tensor_s_tab(Nr);

      class array<TYPE> MOLP1INT_part_tab(Nr);
      class array<TYPE> MOLM1INT_part_tab(Nr);

      class array<TYPE> MSLP1INT_part_tab(Nr);
      class array<TYPE> MSLM1INT_part_tab(Nr);
      
      class array<TYPE> MSSCE_ME_part_tab(Nr);
      
      for (int l_intrinsic = l_intrinsic_min ; l_intrinsic <= l_intrinsic_max ; l_intrinsic++)
	{
	  const int lp_intrinsic_min = max (l_intrinsic - 1 , 0) , lp_intrinsic_max = l_intrinsic + 1;

	  const unsigned int lp_intrinsic_number = make_uns_int (lp_intrinsic_max - lp_intrinsic_min) + 1;
      
	  for (unsigned int i = 0 ; i < Nr ; i++)
	    {
	      MOLP1INT_all_intrinsic_NBME_tab(i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLP1_index          , i);
	      MOLM1INT_all_intrinsic_NBME_tab(i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLM1_index          , i);
	      MSLP1INT_all_intrinsic_NBME_tab(i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , SPIN_GRADIENT_RICCATI_BESSEL_DER_YLP1_index , i);
	      MSLM1INT_all_intrinsic_NBME_tab(i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , SPIN_GRADIENT_RICCATI_BESSEL_DER_YLM1_index , i);
	      MSSCE_all_intrinsic_NBME_tab(i)    = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , SPIN_S_SCALAR_E_index                       , i);

	      MOLP1INT_intrinsic_NBME_grad_jl_Yl_tab(i)          = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLP1_index       , i);
	      MOLM1INT_intrinsic_NBME_grad_jl_Yl_tab(i)          = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLM1_index       , i);
	      MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab(0 , i)    = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLP1_R_L_index   , i);
	      MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab(2 , i)    = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLP1_R_LP2_index , i);
	      MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_tab(0 , i)    = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLM1_R_LM2_index , i);
	      MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_tab(2 , i)    = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLM1_R_L_index   , i);
	      MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_tab(0 , i)    = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLP1_P_L_index   , i);
	      MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_tab(2 , i)    = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLP1_P_LP2_index , i);
	      MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_tab(0 , i)    = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLM1_P_LM2_index , i);
	      MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_tab(2 , i)    = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_YLM1_P_L_index   , i);	      
	      MSLP1INT_intrinsic_NBME_grad_jl_Yl_tensor_s_tab(i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , SPIN_GRADIENT_BESSEL_YLP1_index          , i);
	      MSLM1INT_intrinsic_NBME_grad_jl_Yl_tensor_s_tab(i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , SPIN_GRADIENT_BESSEL_YLM1_index          , i);
	      
	      MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab(1 , i) = 0.0;
	      MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_tab(1 , i) = 0.0;
	      MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab(1 , i) = 0.0;
	      MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_tab(1 , i) = 0.0;
	    }
 
	  class array<TYPE> MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab(lp_intrinsic_number , Nr);

	  magnetic::intrinsic_NBMEs_store (Tpc_data , ic , icp ,  L , l_intrinsic , MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab);

	  const int LCM_min_in_out = abs (LCM_projectile_in - LCM_projectile_out);

	  const int LCM_max_in_out = LCM_projectile_in + LCM_projectile_out;

	  const int LCM_min_l_intrinsic = abs (L - l_intrinsic);

	  const int LCM_max_l_intrinsic = L + l_intrinsic;

	  const int LCM_min_L = max (LCM_min_in_out , LCM_min_l_intrinsic);
	  const int LCM_max_L = min (LCM_max_in_out , LCM_max_l_intrinsic);

	  for (int LCM = LCM_min_L ; LCM <= LCM_max_L ; LCM++)
	    {
	      const TYPE coupling_term = coupling_term_l_intrinsic_LCM (l_intrinsic , LCM , L);
	      
	      magnetic::orbital_gradient_ME_reduced_part_calc (1 , is_it_longwavelength_approximation , is_it_Gauss_Legendre , l_intrinsic , LCM , L , CC_state_in , CC_state_out , ic_in , ic_out ,
							       MOLP1INT_all_intrinsic_NBME_tab , MOLP1INT_intrinsic_NBME_grad_jl_Yl_tab , MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab , MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_tab , MOLP1INT_part_tab);
	      
	      magnetic::orbital_gradient_ME_reduced_part_calc (-1 , is_it_longwavelength_approximation , is_it_Gauss_Legendre , l_intrinsic , LCM , L , CC_state_in , CC_state_out , ic_in , ic_out ,
							       MOLM1INT_all_intrinsic_NBME_tab , MOLM1INT_intrinsic_NBME_grad_jl_Yl_tab , MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_tab , MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_tab , MOLM1INT_part_tab);
	      
	      magnetic::spin_gradient_ME_reduced_calc (is_it_longwavelength_approximation , is_it_Gauss_Legendre , l_intrinsic , LCM , L ,
						       CC_state_in , CC_state_out , ic_in , ic_out ,
						       MSLP1INT_all_intrinsic_NBME_tab , MSLP1INT_intrinsic_NBME_grad_jl_Yl_tensor_s_tab , MSLP1INT_part_tab);
	      
	      magnetic::spin_gradient_ME_reduced_calc (is_it_longwavelength_approximation , is_it_Gauss_Legendre , l_intrinsic , LCM , L ,
						       CC_state_in , CC_state_out , ic_in , ic_out ,
						       MSLM1INT_all_intrinsic_NBME_tab , MSLM1INT_intrinsic_NBME_grad_jl_Yl_tensor_s_tab , MSLM1INT_part_tab);
		
	      magnetic::spin_s_scalar_e_ME_part_calc (is_it_longwavelength_approximation , is_it_Gauss_Legendre , l_intrinsic , LCM , L ,
						      CC_state_in , CC_state_out , ic_in , ic_out ,
						      MSSCE_all_intrinsic_NBME_tab , MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab , MSSCE_ME_part_tab);

	      magnetic_strength_tab += coupling_term*(MOLP1INT_part_tab + MOLM1INT_part_tab + MSLP1INT_part_tab + MSLM1INT_part_tab + MSSCE_ME_part_tab);
	    }	
	}
    }
}








// calculate <uc_f lf jf || M/E_L || uc_i li ji>
void CC_EM_transitions_strength_MEs::cluster::calc (
						    const enum EM_type EM , 
						    const int L , 
						    const bool is_it_longwavelength_approximation ,
						    const bool is_it_Gauss_Legendre , 
						    const class CC_target_projectile_composite_data &Tpc_data , 
						    const class array<class cluster_data> &cluster_projectile_data_tab ,
						    const unsigned int ic , 
						    const unsigned int icp , 
						    const class CC_state_class &CC_state_in , 
						    const class CC_state_class &CC_state_out , 
						    const unsigned int ic_in , 
						    const unsigned int ic_out ,
						    class array<TYPE> &strength_tab)
{
  switch (EM)
    {
    case ELECTRIC: electric::calc (L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , Tpc_data , cluster_projectile_data_tab , ic , icp ,CC_state_in , CC_state_out , ic_in , ic_out , strength_tab); break;

    case MAGNETIC: magnetic::calc (L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , Tpc_data , cluster_projectile_data_tab , ic , icp ,CC_state_in , CC_state_out , ic_in , ic_out , strength_tab); break;

    default: abort_all ();
    }
}




