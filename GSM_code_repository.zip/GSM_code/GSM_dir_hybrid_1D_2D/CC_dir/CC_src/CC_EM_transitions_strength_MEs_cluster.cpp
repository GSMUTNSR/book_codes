#include "../CC_include/CC_include_def.h"


using namespace Wigner_signs;
using namespace angular_matrix_elements;
using namespace inputs_misc;
using namespace EM_transitions_common;
using namespace EM_transitions_strength_NBMEs;

using namespace CC_EM_transitions_MEs::cluster;
using namespace CC_EM_transitions_strength_MEs::radial;



void CC_EM_transitions_strength_MEs::cluster::EM_suboperator_intrinsic_NBMEs_calc (
										   class GSM_vector &PSI_full , 
										   const enum EM_suboperator_type EM_suboperator , 
										   const enum radial_operator_type radial_operator ,
										   const TYPE &q , 
										   const int L ,
										   const int Lc , 
										   const bool is_it_longwavelength_approximation , 
										   const bool is_it_Gauss_Legendre , 
										   const class interaction_class &inter_data_basis , 
										   const class cluster_data &data_c , 
										   const class cluster_data &data_cp , 
										   const class GSM_vector &PSI_cluster_c ,
										   const class GSM_vector &PSI_cluster_cp , 
										   class array<TYPE> &EM_suboperator_intrinsic_NBMEs_strength_tab)
{
  const unsigned int N_bef_R_GL = data_c.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = data_c.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
  
  const double Jc  = data_c.get_J_intrinsic ();
  const double Jcp = data_cp.get_J_intrinsic ();

  const double b_HO = inter_data_basis.get_b_lab ();
 
  class array<TYPE> EM_suboperator_NBMEs_tab(Nr);
  
  EM_suboperator_B_amplitude_tab_calc (EM_suboperator , radial_operator , q , L , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre ,
				       PSI_full , Jc , PSI_cluster_c , Jcp , PSI_cluster_cp , EM_suboperator_NBMEs_tab);	

  const TYPE j0_ME = static_cast<TYPE> (HO_wave_functions::HO_3D::j0_ME_calc (b_HO , q));
  
  const TYPE hat_j0_derivative_ME = static_cast<TYPE> (HO_wave_functions::HO_3D::hat_j0_derivative_ME_calc (b_HO , q));
  
  const TYPE RCM_hat_j0_ME = static_cast<TYPE> (HO_wave_functions::HO_3D::r_hat_j0_ME_calc (b_HO , q));
  
  if ((EM_suboperator == ELECTRIC_CHARGE_YL_TENSOR_E) ||
      (EM_suboperator == ELECTRIC_CURRENT) ||
      (EM_suboperator == ELECTRIC_CURRENT_YL_TENSOR_S) ||
      (EM_suboperator == MAGNETIC_ORBITAL_GRADIENT_BESSEL_LP1) ||
      (EM_suboperator == MAGNETIC_ORBITAL_GRADIENT_BESSEL_LM1) ||
      (EM_suboperator == MAGNETIC_SPIN_GRADIENT_BESSEL_LP1) ||
      (EM_suboperator == MAGNETIC_SPIN_GRADIENT_BESSEL_LM1) ||
      (EM_suboperator == MAGNETIC_SPIN_S_SCALAR_E) ||
      (EM_suboperator == MAGNETIC_SPIN_YL_TENSOR_S))
    {
      EM_suboperator_intrinsic_NBMEs_strength_tab = EM_suboperator_NBMEs_tab/j0_ME;

      return;
    }
 
  if (EM_suboperator == ELECTRIC_CHARGE_YL)
    {
      if (radial_operator == BESSEL)
	{
	  EM_suboperator_intrinsic_NBMEs_strength_tab = EM_suboperator_NBMEs_tab/j0_ME;

	  return;
	}
      
      if (radial_operator == RICCATI_BESSEL_OVER_R)
	{
	  class array<TYPE> EM_suboperator_Bessel_strength_tab(Nr);
	  
	  EM_suboperator_B_amplitude_tab_calc (EM_suboperator , BESSEL , q , L , Lc , 
					       is_it_longwavelength_approximation , is_it_Gauss_Legendre , 
					       PSI_full , Jc , PSI_cluster_c , Jcp , PSI_cluster_cp , EM_suboperator_Bessel_strength_tab);

	  const class array<TYPE> EM_suboperator_intrinsic_Bessel_strength_tab = EM_suboperator_Bessel_strength_tab/j0_ME;

	  EM_suboperator_intrinsic_NBMEs_strength_tab = (EM_suboperator_NBMEs_tab - EM_suboperator_intrinsic_Bessel_strength_tab*RCM_hat_j0_ME)/j0_ME;
	  return;
	}
    }
  
  if (EM_suboperator == ELECTRIC_CHARGE)
    {
      class array<TYPE> EM_suboperator_Bessel_strength_tab(Nr);
      
      EM_suboperator_B_amplitude_tab_calc (EM_suboperator , BESSEL , q , L , Lc , 
					   is_it_longwavelength_approximation , is_it_Gauss_Legendre , 
					   PSI_full , Jc , PSI_cluster_c , Jcp , PSI_cluster_cp , EM_suboperator_Bessel_strength_tab);
	  
      const class array<TYPE> EM_suboperator_intrinsic_Bessel_strength_tab = EM_suboperator_Bessel_strength_tab/j0_ME;
      
      EM_suboperator_intrinsic_NBMEs_strength_tab = (EM_suboperator_NBMEs_tab + EM_suboperator_intrinsic_Bessel_strength_tab*(hat_j0_derivative_ME + RCM_hat_j0_ME))/j0_ME;

      return;
    }

  if (EM_suboperator == MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_LP1)
    {	
      class array<TYPE> EM_suboperator_magnetic_spin_gradient_Bessel_strength_tab(Nr);
      
      EM_suboperator_B_amplitude_tab_calc (EM_suboperator , GRADIENT_BESSEL_LP1 , q , L , Lc , 
					   is_it_longwavelength_approximation , is_it_Gauss_Legendre , 
					   PSI_full , Jc , PSI_cluster_c , Jcp , PSI_cluster_cp , EM_suboperator_magnetic_spin_gradient_Bessel_strength_tab);
      
      const class array<TYPE> EM_suboperator_intrinsic_magnetic_spin_gradient_Bessel_strength_tab = EM_suboperator_magnetic_spin_gradient_Bessel_strength_tab/j0_ME;
      
      EM_suboperator_intrinsic_NBMEs_strength_tab = (EM_suboperator_NBMEs_tab - EM_suboperator_intrinsic_magnetic_spin_gradient_Bessel_strength_tab*(hat_j0_derivative_ME - j0_ME))/j0_ME;

      return;
    }
  
  if (EM_suboperator == MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_LM1)
    {	
      class array<TYPE> EM_suboperator_magnetic_spin_gradient_Bessel_strength_tab(Nr);
      
      EM_suboperator_B_amplitude_tab_calc (EM_suboperator , GRADIENT_BESSEL_LM1 , q , L , Lc ,  
					   is_it_longwavelength_approximation , is_it_Gauss_Legendre , 
					   PSI_full , Jc , PSI_cluster_c , Jcp , PSI_cluster_cp , EM_suboperator_magnetic_spin_gradient_Bessel_strength_tab);
      
      const class array<TYPE> EM_suboperator_intrinsic_magnetic_spin_gradient_Bessel_strength_tab = EM_suboperator_magnetic_spin_gradient_Bessel_strength_tab/j0_ME;
      
      EM_suboperator_intrinsic_NBMEs_strength_tab = (EM_suboperator_NBMEs_tab - EM_suboperator_intrinsic_magnetic_spin_gradient_Bessel_strength_tab*(hat_j0_derivative_ME - j0_ME))/j0_ME;

      return;
    }
  
  error_message_print_abort ("No electromagnetic/radial operator type combination recognized in EM_suboperator_intrinsic_NBMEs_calc");
}





void CC_EM_transitions_strength_MEs::cluster::electric::intrinsic_NBMEs_store (
									       const class CC_target_projectile_composite_data &Tpc_data , 
									       const unsigned int ic , 
									       const unsigned int icp , 
									       const int L , 
									       const int l_intrinsic , 
									       class array<TYPE> &ECH_intrinsic_NBME_hat_jl_tab , 
									       class array<TYPE> &EC_intrinsic_NBME_jl_tab)
{
  const unsigned int ELECTRIC_CHARGE_YL_TENSOR_E_index  = EM_suboperator_type_index_determine (ELECTRIC_CHARGE_YL_TENSOR_E);
  const unsigned int ELECTRIC_CURRENT_YL_TENSOR_S_index = EM_suboperator_type_index_determine (ELECTRIC_CURRENT_YL_TENSOR_S);

  const unsigned int RICCATI_BESSEL_index = radial_operator_type_index_determine (RICCATI_BESSEL);

  const unsigned int Nr = ECH_intrinsic_NBME_hat_jl_tab.dimension (1);

  const int lp_intrinsic_min = max (l_intrinsic - 1 , 0);

  const int lp_intrinsic_max = l_intrinsic + 1;

  const class array<TYPE> &EM_suboperator_intrinsic_NBMEs_strength = Tpc_data.get_EM_suboperator_intrinsic_NBMEs_strength ();

  for (int lp_intrinsic = lp_intrinsic_min ; lp_intrinsic <= lp_intrinsic_max ; lp_intrinsic++)
    {
      const unsigned int i_lp_intrinsic = make_uns_int (lp_intrinsic - lp_intrinsic_min);

      for (unsigned int i = 0 ; i < Nr ; i++)
	{
	  ECH_intrinsic_NBME_hat_jl_tab(i_lp_intrinsic , i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , lp_intrinsic , ELECTRIC_CHARGE_YL_TENSOR_E_index , RICCATI_BESSEL_index , i);
	  EC_intrinsic_NBME_jl_tab(i_lp_intrinsic , i)      = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , lp_intrinsic , ELECTRIC_CURRENT_YL_TENSOR_S_index , RICCATI_BESSEL_index , i);
	}
    }
}






void CC_EM_transitions_strength_MEs::cluster::electric::charge_ME_reduced_part_calc (
										     const bool is_it_longwavelength_approximation ,
										     const bool is_it_Gauss_Legendre , 
										     const int l_intrinsic , 
										     const int LCM ,
										     const int L ,  
										     const class CC_state_class &CC_state_in , 
										     const class CC_state_class &CC_state_out , 
										     const unsigned int ic_in , 
										     const unsigned int ic_out , 
										     const class array<TYPE> &ECH_all_intrinsic_NBME_tab , 
										     const class array<TYPE> &ECH_intrinsic_NBME_jl_Yl_tab , 
										     const class array<TYPE> &ECH_intrinsic_NBME_hat_jl_over_r_Yl_tab , 
										     const class array<TYPE> &ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab , 
										     class array<TYPE> &ECH_ME_reduced_part_tab)
{
  const unsigned int Nr = ECH_all_intrinsic_NBME_tab.dimension (0);
  
  const double sqrt_four_pi_over_three = 2.046653415892977;

  const double Y1_norm_factor = sqrt_four_pi_over_three;	

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile  ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  //--// calculations of the radial electric charge and current
  
  class array<TYPE> ECH_CM_radial_ME_jl_tab(Nr);
  class array<TYPE> ECH_CM_radial_ME_hat_jl_der_tab(Nr);
  class array<TYPE> ECH_CM_radial_ME_hat_jl_r_tab(Nr);
  class array<TYPE> ECH_CM_radial_ME_hat_jl_tab(Nr);

  radial_OBMEs_calc (BESSEL                    , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , ECH_CM_radial_ME_jl_tab);
  radial_OBMEs_calc (RICCATI_BESSEL_DERIVATIVE , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , ECH_CM_radial_ME_hat_jl_der_tab);
  radial_OBMEs_calc (RICCATI_BESSEL            , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , ECH_CM_radial_ME_hat_jl_tab);
  
  const TYPE Y_LCM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);
  
  const class array<TYPE> ECH_CM_ME_jl_Yl_tab         = ECH_CM_radial_ME_jl_tab*Y_LCM_ME;
  const class array<TYPE> ECH_CM_ME_hat_jl_der_Yl_tab = ECH_CM_radial_ME_hat_jl_der_tab*Y_LCM_ME;
  const class array<TYPE> ECH_CM_ME_hat_jl_r_Yl_tab   = ECH_CM_radial_ME_hat_jl_tab*Y_LCM_ME;

  const int LCM_p_min = max (LCM - 1 , 0);

  const int LCM_p_max = LCM + 1;

  const unsigned int LCM_p_number = make_uns_int (LCM_p_max - LCM_p_min) + 1;

  const unsigned int lp_intrinsic_number = ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab.dimension (0);
  
  class array<TYPE> Yl_tensor_e_CM_ME_tab(LCM_p_number);

  class array<TYPE> ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_r_tab(lp_intrinsic_number);

  for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
    {
      const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

      const double Yl_tensor_e_CM_ME = Y1_norm_factor*YL1_tensor_YL2_reduced_in_l (LCM , 1 , LCM_p , LCM_projectile_in , LCM_projectile_out);

      Yl_tensor_e_CM_ME_tab(i_LCM_p) = Yl_tensor_e_CM_ME;
    }
  
  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      for (unsigned int i_lp = 0 ; i_lp < lp_intrinsic_number ; i_lp++)
	ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_r_tab(i_lp) = ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab(i_lp , i);

      const TYPE ECH_CM_ME_jl_Yl         = ECH_CM_ME_jl_Yl_tab(i);
      const TYPE ECH_CM_ME_hat_jl_der_Yl = ECH_CM_ME_hat_jl_der_Yl_tab(i);
      const TYPE ECH_CM_ME_hat_jl_r_Yl   = ECH_CM_ME_hat_jl_r_Yl_tab(i);
   
      const TYPE ECH_all_intrinsic_NBME              = ECH_all_intrinsic_NBME_tab(i);
      const TYPE ECH_intrinsic_NBME_jl_Yl            = ECH_intrinsic_NBME_jl_Yl_tab(i);
      const TYPE ECH_intrinsic_NBME_hat_jl_over_r_Yl = ECH_intrinsic_NBME_hat_jl_over_r_Yl_tab(i);

      const class array<TYPE> ECH_CM_hat_jl_Yl_tensor_e_CM_ME_tab = ECH_CM_radial_ME_hat_jl_tab(i)*Yl_tensor_e_CM_ME_tab;
	
      const TYPE ECH_ME_jl_Yl_CM_all_Yl_intrinsic = static_cast<TYPE> (Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
												     LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
												     LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
												     ECH_CM_ME_jl_Yl , ECH_all_intrinsic_NBME));

      const TYPE ECH_ME_hat_jl_der_Yl_CM_jl_Yl_intrinsic = static_cast<TYPE> (Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
													    LCM_projectile_in , l_intrinsic , J_projectile_in , 
													    LCM_projectile_out , l_intrinsic , J_projectile_out ,
													    ECH_CM_ME_hat_jl_der_Yl , ECH_intrinsic_NBME_jl_Yl));
	
      const TYPE ECH_ME_hat_jl_r_Yl_CM_hat_jl_over_r_Yl_intrinsic = 0.5*static_cast<TYPE> (Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
															 LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
															 LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
															 ECH_CM_ME_hat_jl_r_Yl , ECH_intrinsic_NBME_hat_jl_over_r_Yl));

      const TYPE ECH_ME_hat_jl_Yl_e_CM_hat_jl_Yl_e_intrinsic = static_cast<TYPE> (O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (LCM , l_intrinsic , L , 1 ,
																   LCM_projectile_in , l_intrinsic , J_projectile_in , 
																   LCM_projectile_out , l_intrinsic , J_projectile_out ,
																   ECH_CM_hat_jl_Yl_tensor_e_CM_ME_tab , ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_r_tab));

      const TYPE ECH_MEs_sum = ECH_ME_jl_Yl_CM_all_Yl_intrinsic + ECH_ME_hat_jl_der_Yl_CM_jl_Yl_intrinsic + ECH_ME_hat_jl_r_Yl_CM_hat_jl_over_r_Yl_intrinsic + ECH_ME_hat_jl_Yl_e_CM_hat_jl_Yl_e_intrinsic;
  
      ECH_ME_reduced_part_tab(i) = ECH_MEs_sum;
    }
}









void CC_EM_transitions_strength_MEs::cluster::electric::current_ME_reduced_part_calc (
										      const bool is_it_longwavelength_approximation ,
										      const bool is_it_Gauss_Legendre , 
										      const int l_intrinsic , 
										      const int LCM , 
										      const int L , 
										      const class CC_state_class &CC_state_in , 
										      const class CC_state_class &CC_state_out , 
										      const unsigned int ic_in , 
										      const unsigned int ic_out , 
										      const class array<TYPE> &EC_all_intrinsic_NBME_tab , 
										      const class array<TYPE> &EC_intrinsic_NBME_jl_Yl_tensor_s_tab,
										      class array<TYPE> &EC_ME_reduced_part_tab)
{
  const unsigned int Nr = EC_all_intrinsic_NBME_tab.dimension (0);
  
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();
  
  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  //--// calculations of the radial electric charge and current

  class array<TYPE> EC_CM_radial_ME_jl_tab(Nr);

  class array<TYPE> EC_CM_radial_ME_hat_jl_over_r_tab(Nr);

  radial_OBMEs_calc (BESSEL                , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , EC_CM_radial_ME_jl_tab);
  radial_OBMEs_calc (RICCATI_BESSEL_OVER_R , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , EC_CM_radial_ME_hat_jl_over_r_tab);
 
  const TYPE Y_LCM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);
  
  const class array<TYPE> EC_CM_ME_jl_Yl_tab = Y_LCM_ME*EC_CM_radial_ME_jl_tab;
  
  const class array<TYPE> EC_CM_radial_ME_hat_jl_over_r_Yl_tab = Y_LCM_ME*EC_CM_radial_ME_hat_jl_over_r_tab;

  const int LCM_p_min = max (LCM - 1 , 0);

  const int LCM_p_max = LCM + 1;

  const unsigned int LCM_p_number = make_uns_int (LCM_p_max - LCM_p_min) + 1;

  const unsigned int lp_intrinsic_number = EC_all_intrinsic_NBME_tab.dimension (0);

  class array<TYPE> Yl_tensor_l_CM_ME_tab(LCM_p_number);

  class array<TYPE> EC_intrinsic_NBME_jl_Yl_tensor_s_r_tab(lp_intrinsic_number);

  for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
    {
      const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

      const double Yl_tensor_l_CM_ME = OBME_YL_tensor_l_reduced_in_l (LCM_p , LCM , LCM_projectile_in , LCM_projectile_out);

      Yl_tensor_l_CM_ME_tab(i_LCM_p) = Yl_tensor_l_CM_ME;
    }
  
  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      for (unsigned int i_lp = 0 ; i_lp < lp_intrinsic_number ; i_lp++)
	EC_intrinsic_NBME_jl_Yl_tensor_s_r_tab(i_lp) = EC_intrinsic_NBME_jl_Yl_tensor_s_tab(i_lp , i);

      const class array<TYPE> EC_CM_hat_jl_over_r_Yl_tensor_l_ME_r_tab = EC_CM_radial_ME_hat_jl_over_r_tab(i)*Yl_tensor_l_CM_ME_tab;

      const TYPE EC_CM_ME_jl_Yl = EC_CM_ME_jl_Yl_tab(i);
      
      const TYPE EC_all_intrinsic_NBME = EC_all_intrinsic_NBME_tab(i);

      const TYPE EC_ME_jl_Yl_CM_all_intrinsic = static_cast<TYPE> (Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
												 LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
												 LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
												 EC_CM_ME_jl_Yl , EC_all_intrinsic_NBME));
      
      const TYPE EC_ME_hat_jl_over_r_Yl_l_CM_jl_Yl_s_intrinsic = static_cast<TYPE> (O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (LCM , l_intrinsic , L , 1 ,
																     LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
																     LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
																     EC_CM_hat_jl_over_r_Yl_tensor_l_ME_r_tab , EC_intrinsic_NBME_jl_Yl_tensor_s_r_tab));
      
      const TYPE EC_MEs_sum = EC_ME_jl_Yl_CM_all_intrinsic + EC_ME_hat_jl_over_r_Yl_l_CM_jl_Yl_s_intrinsic;
      
      EC_ME_reduced_part_tab(i) = EC_MEs_sum;
    }
}






//--// calculate <uc_f lf jf || E_L || uc_i li ji>
void CC_EM_transitions_strength_MEs::cluster::electric::calc (
							      const int L , 
							      const bool is_it_longwavelength_approximation ,
							      const bool is_it_Gauss_Legendre , 
							      const class CC_target_projectile_composite_data &Tpc_data , 
							      const class array<class cluster_data> &cluster_data_tab , 
							      const unsigned int ic ,
							      const unsigned int icp ,  
							      const class CC_state_class &CC_state_in , 
							      const class CC_state_class &CC_state_out , 
							      const unsigned int ic_in , 
							      const unsigned int ic_out , 
							      class array<TYPE> &electric_strength_tab)
{
  const unsigned int Nr = electric_strength_tab.dimension (0);

  const unsigned int BP_Op = BP_EM_determine (ELECTRIC , L);

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  electric_strength_tab = 0.0;
  
  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out + 1) == BP_Op)
    {
      const unsigned int ELECTRIC_CHARGE_YL_index = EM_suboperator_type_index_determine (ELECTRIC_CHARGE_YL);
      const unsigned int ELECTRIC_CHARGE_index    = EM_suboperator_type_index_determine (ELECTRIC_CHARGE);
      const unsigned int ELECTRIC_CURRENT_index   = EM_suboperator_type_index_determine (ELECTRIC_CURRENT);

      const unsigned int BESSEL_index                  = radial_operator_type_index_determine (BESSEL);
      const unsigned int RICCATI_BESSEL_OVER_R_index   = radial_operator_type_index_determine (RICCATI_BESSEL_OVER_R);
      const unsigned int ELECTRIC_CHARGE_RADIAL_index  = radial_operator_type_index_determine (ELECTRIC_CHARGE_RADIAL);
      const unsigned int ELECTRIC_CURRENT_RADIAL_index = radial_operator_type_index_determine (ELECTRIC_CURRENT_RADIAL);

      const class cluster_data &data_c  = cluster_data_tab(ic);
      const class cluster_data &data_cp = cluster_data_tab(icp);

      const double J_intrinsic_in  = data_c.get_J_intrinsic ();
      const double J_intrinsic_out = data_cp.get_J_intrinsic ();
      
      const int l_intrinsic_min = abs (make_int (J_intrinsic_in - J_intrinsic_out));

      const int l_intrinsic_max = make_int (J_intrinsic_in + J_intrinsic_out);

      const class array<TYPE> &EM_suboperator_intrinsic_NBMEs_strength = Tpc_data.get_EM_suboperator_intrinsic_NBMEs_strength ();

      class array<TYPE> ECH_intrinsic_NBME_jl_Yl_tab(Nr);
      class array<TYPE> ECH_intrinsic_NBME_hat_jl_over_r_Yl_tab(Nr);
      
      class array<TYPE> ECH_all_intrinsic_NBME_tab(Nr);      
      class array<TYPE> EC_all_intrinsic_NBME_tab(Nr);

      class array<TYPE> ECH_ME_reduced_part_tab(Nr);
      class array<TYPE> EC_ME_reduced_part_tab(Nr);
	
      for (int l_intrinsic = l_intrinsic_min ; l_intrinsic <= l_intrinsic_max ; l_intrinsic++)
	{
	  for (unsigned int i = 0 ; i < Nr ; i++)
	    {	
	      ECH_intrinsic_NBME_jl_Yl_tab(i)            = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ELECTRIC_CHARGE_YL_index , BESSEL_index);
	      ECH_all_intrinsic_NBME_tab(i)              = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ELECTRIC_CHARGE_index    , ELECTRIC_CHARGE_RADIAL_index);
	      ECH_intrinsic_NBME_hat_jl_over_r_Yl_tab(i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ELECTRIC_CHARGE_YL_index , RICCATI_BESSEL_OVER_R_index);

	      EC_all_intrinsic_NBME_tab(i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ELECTRIC_CURRENT_index , ELECTRIC_CURRENT_RADIAL_index);
	    }
  
	  const int lp_intrinsic_min = max (l_intrinsic - 1 , 0);

	  const int lp_intrinsic_max = l_intrinsic + 1;

	  const unsigned int lp_intrinsic_number = make_uns_int (lp_intrinsic_max - lp_intrinsic_min) + 1;

	  class array<TYPE> ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab(lp_intrinsic_number , Nr);

	  class array<TYPE> EC_intrinsic_NBME_jl_Yl_tensor_s_tab(lp_intrinsic_number , Nr);

	  electric::intrinsic_NBMEs_store (Tpc_data , ic , icp , L , l_intrinsic , ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab , EC_intrinsic_NBME_jl_Yl_tensor_s_tab);

	  const int LCM_min_in_out = abs (LCM_projectile_in - LCM_projectile_out);

	  const int LCM_max_in_out = LCM_projectile_in + LCM_projectile_out;

	  const int LCM_min_l_intrinsic_L = abs (L - l_intrinsic);

	  const int LCM_max_l_intrinsic_L = L + l_intrinsic;

	  const int LCM_min = max (LCM_min_in_out , LCM_min_l_intrinsic_L);
	  const int LCM_max = min (LCM_max_in_out , LCM_max_l_intrinsic_L);

	  for (int LCM = LCM_min ; LCM <= LCM_max ; LCM++)
	    {
	      const TYPE coupling_term = coupling_term_l_intrinsic_LCM (l_intrinsic , LCM , L);

	      electric::charge_ME_reduced_part_calc (is_it_longwavelength_approximation , is_it_Gauss_Legendre , l_intrinsic , LCM , L ,
						     CC_state_in , CC_state_out , ic_in , ic_out , 
						     ECH_all_intrinsic_NBME_tab , ECH_intrinsic_NBME_jl_Yl_tab ,
						     ECH_intrinsic_NBME_hat_jl_over_r_Yl_tab , ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab ,
						     ECH_ME_reduced_part_tab);
 
	      electric::current_ME_reduced_part_calc (is_it_longwavelength_approximation , is_it_Gauss_Legendre , l_intrinsic , LCM , L ,
						      CC_state_in , CC_state_out , ic_in , ic_out , 
						      EC_all_intrinsic_NBME_tab , EC_intrinsic_NBME_jl_Yl_tensor_s_tab , EC_ME_reduced_part_tab);
	      
	      electric_strength_tab += coupling_term*(ECH_ME_reduced_part_tab + EC_ME_reduced_part_tab);
	    }
	}
    }
}









void CC_EM_transitions_strength_MEs::cluster::magnetic::intrinsic_NBMEs_store (
									       const class CC_target_projectile_composite_data &Tpc_data , 
									       const unsigned int ic , 
									       const unsigned int icp , 
									       const int L , 
									       const int l_intrinsic , 
									       class array<TYPE> &MSSCE_Bessel_intrinsic_NBME_tab)
{
  const unsigned int MAGNETIC_SPIN_YL_TENSOR_S_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_YL_TENSOR_S);
  
  const unsigned int RICCATI_BESSEL_OVER_R_index = radial_operator_type_index_determine (RICCATI_BESSEL_OVER_R);
  
  const int lp_intrinsic_min = max (l_intrinsic - 1 , 0);

  const int lp_intrinsic_max = l_intrinsic + 1;

  const class array<TYPE> &EM_suboperator_intrinsic_NBMEs_strength = Tpc_data.get_EM_suboperator_intrinsic_NBMEs_strength ();
  
  const unsigned int Nr = MSSCE_Bessel_intrinsic_NBME_tab.dimension (0);
  
  for (int lp_intrinsic = lp_intrinsic_min ; lp_intrinsic <= lp_intrinsic_max ; lp_intrinsic++)
    {
      const unsigned int i_lp_intrinsic = make_uns_int (lp_intrinsic - lp_intrinsic_min);

      for (unsigned int i = 0 ; i < Nr ; i++)
	MSSCE_Bessel_intrinsic_NBME_tab(i_lp_intrinsic , i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , lp_intrinsic , MAGNETIC_SPIN_YL_TENSOR_S_index , RICCATI_BESSEL_OVER_R_index , i);
    }
}


















void CC_EM_transitions_strength_MEs::cluster::magnetic::orbital_gradient_ME_reduced_part_calc (
											       const int pm,
											       const bool is_it_longwavelength_approximation ,
											       const bool is_it_Gauss_Legendre , 
											       const int l_intrinsic , 
											       const int LCM , 
											       const int L , 
											       const class CC_state_class &CC_state_in , 
											       const class CC_state_class &CC_state_out , 
											       const unsigned int ic_in , 
											       const unsigned int ic_out , 
											       const class array<TYPE> &MO_all_intrinsic_NBME_tab , 
											       const class array<TYPE> &MO_intrinsic_NBME_jl_Yl_tab , 
											       class array<TYPE> &orbital_ME_reduced_part_tab)
{
  orbital_ME_reduced_part_tab = 0.0;
  
  const int l_intrinsic_pm_one = l_intrinsic + pm;
  
  if (l_intrinsic_pm_one < 0) return;
 
  const unsigned int Nr = MO_all_intrinsic_NBME_tab.dimension (0);
  
  const double sqrt_four_pi_over_three = 2.046653415892977;

  const double Y1_norm_factor = sqrt_four_pi_over_three;	

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  class array<TYPE> MO_CM_radial_ME_jl_tab(Nr);
  
  radial_OBMEs_calc (BESSEL , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , MO_CM_radial_ME_jl_tab);

  const TYPE MO_Yl_CM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);
  
  const class array<TYPE> MO_jl_Yl_CM_ME_tab = MO_Yl_CM_ME*MO_CM_radial_ME_jl_tab;

  const int LCM_p_min = max (LCM - 1 , 0);

  const int LCM_p_max = LCM + 1;

  const unsigned int LCM_p_number = make_uns_int (LCM_p_max - LCM_p_min) + 1;

  class array<TYPE> Yl_tensor_l_CM_ME_tab(LCM_p_number);

  for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
    {
      const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

      const double Yl_tensor_l_CM_ME = Y1_norm_factor*YL1_tensor_YL2_reduced_in_l (LCM , 1 , LCM_p , LCM_projectile_in , LCM_projectile_out);

      Yl_tensor_l_CM_ME_tab(i_LCM_p) = Yl_tensor_l_CM_ME;
    }

  const int phase = minus_one_pow (LCM_projectile_in + J_intrinsic_in - J_projectile_in + LCM_projectile_out + J_intrinsic_out - J_projectile_out);
  
  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      const TYPE MO_CM_radial_ME_jl = MO_CM_radial_ME_jl_tab(i);

      const TYPE MO_jl_Yl_CM_ME = MO_jl_Yl_CM_ME_tab(i);

      const TYPE MO_all_intrinsic_NBME = MO_all_intrinsic_NBME_tab(i);

      const TYPE MO_intrinsic_NBME_jl_Yl = MO_intrinsic_NBME_jl_Yl_tab(i);
      
      const class array<TYPE> MO_jl_Yl_tensor_l_CM_ME_tab = MO_CM_radial_ME_jl*Yl_tensor_l_CM_ME_tab;
      
      const TYPE MO_ME_jl_Yl_CM_all_intrinsic = static_cast<TYPE> (Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
												 LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
												 LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
												 MO_jl_Yl_CM_ME , MO_all_intrinsic_NBME));
      
      const TYPE MO_jl_Yl_l_CM_hat_jl_Yl_intrinsic = static_cast<TYPE> (O1a_tensor_O2b_k12_tensor_O3b_reduced_ME_calc (l_intrinsic_pm_one , 1 , l_intrinsic , LCM , L ,
														       J_intrinsic_in , LCM_projectile_in , J_projectile_in , 
														       J_intrinsic_out , LCM_projectile_out , J_projectile_out ,
														       MO_intrinsic_NBME_jl_Yl , MO_jl_Yl_tensor_l_CM_ME_tab));
      
      const TYPE MO_sum = MO_ME_jl_Yl_CM_all_intrinsic + phase*MO_jl_Yl_l_CM_hat_jl_Yl_intrinsic;
      
      orbital_ME_reduced_part_tab(i) = MO_sum;
    }
}









void CC_EM_transitions_strength_MEs::cluster::magnetic::spin_gradient_ME_reduced_calc (
										       const bool is_it_longwavelength_approximation ,
										       const bool is_it_Gauss_Legendre , 
										       const int l_intrinsic , 
										       const int LCM , 
										       const int L , 
										       const class CC_state_class &CC_state_in , 
										       const class CC_state_class &CC_state_out , 
										       const unsigned int ic_in , 
										       const unsigned int ic_out , 
										       const class array<TYPE> &MS_all_intrinsic_NBME_tab ,
										       const class array<TYPE> &MS_intrinsic_NBME_jl_Yl_tensor_s_tab ,
										       class array<TYPE> &spin_ME_reduced_part_tab)
{
  const unsigned int Nr = MS_all_intrinsic_NBME_tab.dimension (1);
  
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  class array<TYPE> MS_CM_radial_ME_jl_tab(Nr);
  class array<TYPE> MS_CM_radial_ME_hat_jl_der_tab(Nr);

  radial_OBMEs_calc (BESSEL                    , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , MS_CM_radial_ME_jl_tab);
  radial_OBMEs_calc (RICCATI_BESSEL_DERIVATIVE , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , MS_CM_radial_ME_hat_jl_der_tab);

  const TYPE MS_Yl_CM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);
  
  const class array<TYPE> MS_jl_Yl_CM_ME_tab         = MS_Yl_CM_ME*MS_CM_radial_ME_jl_tab;
  const class array<TYPE> MS_hat_jl_der_Yl_CM_ME_tab = MS_Yl_CM_ME*MS_CM_radial_ME_hat_jl_der_tab;
      
  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      const TYPE MS_all_intrinsic_NBME = MS_all_intrinsic_NBME_tab(i);

      const TYPE MS_intrinsic_NBME_jl_Yl_tensor_s = MS_intrinsic_NBME_jl_Yl_tensor_s_tab(i);

      const TYPE MS_jl_Yl_CM_ME = MS_jl_Yl_CM_ME_tab(i);

      const TYPE MS_hat_jl_der_Yl_CM_ME = MS_hat_jl_der_Yl_CM_ME_tab(i);
	
      const TYPE MS_jl_Yl_CM_all_intrinsic = static_cast<TYPE> (Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
											      LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
											      LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
											      MS_jl_Yl_CM_ME , MS_all_intrinsic_NBME));
 
      const TYPE MS_hat_jl_der_minus_jl_Yl_CM_jl_Yl_intrinsic = static_cast<TYPE> (Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic ,  L ,
														 LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
														 LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
														 MS_hat_jl_der_Yl_CM_ME - MS_jl_Yl_CM_ME , MS_intrinsic_NBME_jl_Yl_tensor_s));
      
      const TYPE MS_MEs_sum = MS_jl_Yl_CM_all_intrinsic + MS_hat_jl_der_minus_jl_Yl_CM_jl_Yl_intrinsic;

      spin_ME_reduced_part_tab(i) = MS_MEs_sum;
    }
}







void CC_EM_transitions_strength_MEs::cluster::magnetic::spin_s_scalar_e_ME_part_calc (
										      const bool is_it_longwavelength_approximation ,
										      const bool is_it_Gauss_Legendre , 
										      const int l_intrinsic , 
										      const int LCM , 
										      const int L , 
										      const class CC_state_class &CC_state_in , 
										      const class CC_state_class &CC_state_out , 
										      const unsigned int ic_in , 
										      const unsigned int ic_out , 
										      const class array<TYPE> &MSSCE_all_intrinsic_NBME_tab , 
										      const class array<TYPE> &MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab ,
										      class array<TYPE> &spin_ME_reduced_part_tab)
{
  const unsigned int Nr = MSSCE_all_intrinsic_NBME_tab.dimension (0);
 	
  const double sqrt_four_pi_over_three = 2.046653415892977;

  const double Y1_norm_factor = sqrt_four_pi_over_three;

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  const double J_intrinsic_in  = channel_c_in.get_J_intrinsic_projectile ();
  const double J_intrinsic_out = channel_c_out.get_J_intrinsic_projectile ();

  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  class array<TYPE> MSSCE_CM_radial_ME_jl_tab(Nr);
  class array<TYPE> MSSCE_CM_radial_ME_jl_r_tab(Nr);

  radial_OBMEs_calc (BESSEL   , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , MSSCE_CM_radial_ME_jl_tab);
  radial_OBMEs_calc (BESSEL_R , LCM , is_it_longwavelength_approximation , is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , MSSCE_CM_radial_ME_jl_r_tab);

  const TYPE MSSCE_Yl_CM_ME = OBME_YL_reduced_in_l (LCM , LCM_projectile_in , LCM_projectile_out);
  
  const class array<TYPE> MSSCE_jl_Yl_CM_ME_tab = MSSCE_Yl_CM_ME*MSSCE_CM_radial_ME_jl_tab;

  const class array<TYPE> MSSCE_jl_r_Yl_CM_ME_tab = MSSCE_Yl_CM_ME*MSSCE_CM_radial_ME_jl_r_tab;

  const int LCM_p_min = max (LCM - 1 , 0);

  const int LCM_p_max = LCM + 1;

  const unsigned int LCM_p_number = make_uns_int (LCM_p_max - LCM_p_min) + 1;

  const unsigned int lp_intrinsic_number = MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab.dimension (0);
  
  class array<TYPE> e_tensor_Yl_CM_ME_tab(LCM_p_number);

  class array<TYPE> MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_r_tab(lp_intrinsic_number);

  for (int LCM_p = LCM_p_min ; LCM_p <= LCM_p_max ; LCM_p++)
    {
      const unsigned int i_LCM_p = make_uns_int (LCM_p - LCM_p_min);

      const double e_tensor_Yl_CM_ME = Y1_norm_factor*YL1_tensor_YL2_reduced_in_l (LCM , 1 , LCM_p , LCM_projectile_in , LCM_projectile_out);

      e_tensor_Yl_CM_ME_tab(i_LCM_p) = e_tensor_Yl_CM_ME;
    }

  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      for (unsigned int i_lp = 0 ; i_lp < lp_intrinsic_number ; i_lp++)
	MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_r_tab(i_lp) = MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab(i_lp , i);

      const TYPE MSSCE_all_intrinsic_NBME = MSSCE_all_intrinsic_NBME_tab(i);

      const TYPE MSSCE_jl_Yl_CM_ME = MSSCE_jl_Yl_CM_ME_tab(i);

      const class array<TYPE> MSSCE_CM_jl_r_e_tensor_Yl_CM_ME_tab = MSSCE_jl_r_Yl_CM_ME_tab(i)*e_tensor_Yl_CM_ME_tab;
  
      const TYPE MSSCE_ME_jl_Yl_CM_all_intrinsic = static_cast<TYPE> (Oa_tensor_Ob_reduced_ME_calc (LCM , l_intrinsic , L ,
												    LCM_projectile_in , l_intrinsic , J_projectile_in , 
												    LCM_projectile_out , l_intrinsic , J_projectile_out ,
												    MSSCE_jl_Yl_CM_ME , MSSCE_all_intrinsic_NBME));
  
      const TYPE MSSCE_CM_hat_jl_Yl_CM_hat_jl_over_r_Yl_intrinsic = O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (LCM , l_intrinsic , L , 1 ,
														     LCM_projectile_in , J_intrinsic_in , J_projectile_in , 
														     LCM_projectile_out , J_intrinsic_out , J_projectile_out ,
														     MSSCE_CM_jl_r_e_tensor_Yl_CM_ME_tab , MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab);
      
      const TYPE MSSCE_sum = MSSCE_ME_jl_Yl_CM_all_intrinsic + MSSCE_CM_hat_jl_Yl_CM_hat_jl_over_r_Yl_intrinsic;
  
      spin_ME_reduced_part_tab(i) = MSSCE_sum;
    }
}









//--// calculate <uc_f lf jf || E_L || uc_i li ji>
void CC_EM_transitions_strength_MEs::cluster::magnetic::calc (
							      const int L , 
							      const bool is_it_longwavelength_approximation ,
							      const bool is_it_Gauss_Legendre , 
							      const class CC_target_projectile_composite_data &Tpc_data , 
							      const class array<class cluster_data> &cluster_data_tab , 
							      const unsigned int ic , 
							      const unsigned int icp , 
							      const class CC_state_class &CC_state_in , 
							      const class CC_state_class &CC_state_out , 
							      const unsigned int ic_in , 
							      const unsigned int ic_out , 
							      class array<TYPE> &magnetic_strength_tab)
{
  const unsigned int Nr = magnetic_strength_tab.dimension (0);

  const unsigned int BP_Op = BP_EM_determine (MAGNETIC , L);

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const class array<TYPE> &EM_suboperator_intrinsic_NBMEs_strength = Tpc_data.get_EM_suboperator_intrinsic_NBMEs_strength ();

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  magnetic_strength_tab = 0.0;
  
  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out + 1) == BP_Op)
    {
      const unsigned int SPIN_S_SCALAR_E_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_S_SCALAR_E);
      
      const unsigned int ORBITAL_GRADIENT_BESSEL_LP1_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_LP1);
      const unsigned int ORBITAL_GRADIENT_BESSEL_LM1_index = EM_suboperator_type_index_determine (MAGNETIC_ORBITAL_GRADIENT_BESSEL_LM1);

      const unsigned int SPIN_GRADIENT_BESSEL_LP1_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_GRADIENT_BESSEL_LP1);
      const unsigned int SPIN_GRADIENT_BESSEL_LM1_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_GRADIENT_BESSEL_LM1);

      const unsigned int SPIN_GRADIENT_RICCATI_BESSEL_DER_LP1_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_LP1);
      const unsigned int SPIN_GRADIENT_RICCATI_BESSEL_DER_LM1_index = EM_suboperator_type_index_determine (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_LM1);

      const unsigned int SPIN_S_SCALAR_E_RADIAL_index = radial_operator_type_index_determine (MAGNETIC_SPIN_S_SCALAR_E_RADIAL);

      const unsigned int GRADIENT_BESSEL_LP1_index = radial_operator_type_index_determine (GRADIENT_BESSEL_LP1);
      const unsigned int GRADIENT_BESSEL_LM1_index = radial_operator_type_index_determine (GRADIENT_BESSEL_LM1);

      const unsigned int GRADIENT_RICCATI_BESSEL_DER_LP1_index = radial_operator_type_index_determine (GRADIENT_RICCATI_BESSEL_DERIVATIVE_LP1);
      const unsigned int GRADIENT_RICCATI_BESSEL_DER_LM1_index = radial_operator_type_index_determine (GRADIENT_RICCATI_BESSEL_DERIVATIVE_LM1);

      const class cluster_data &data_c  = cluster_data_tab(ic);
      const class cluster_data &data_cp = cluster_data_tab(icp);

      const double J_intrinsic_in  = data_c.get_J_intrinsic ();
      const double J_intrinsic_out = data_cp.get_J_intrinsic ();

      const int l_intrinsic_min = abs (make_int (J_intrinsic_in - J_intrinsic_out));
      const int l_intrinsic_max = make_int (J_intrinsic_in + J_intrinsic_out);

      class array<TYPE> MOLP1INT_all_intrinsic_NBME_tab(Nr);
      class array<TYPE> MOLM1INT_all_intrinsic_NBME_tab(Nr);
      
      class array<TYPE> MSLP1INT_all_intrinsic_NBME_tab(Nr);
      class array<TYPE> MSLM1INT_all_intrinsic_NBME_tab(Nr);

      class array<TYPE> MSSCE_all_intrinsic_NBME_tab(Nr);

      class array<TYPE> MOLP1INT_intrinsic_NBME_jl_Yl_tab(Nr);
      class array<TYPE> MOLM1INT_intrinsic_NBME_jl_Yl_tab(Nr);
      
      class array<TYPE> MSLP1INT_intrinsic_NBME_jl_Yl_tensor_s_tab(Nr);
      class array<TYPE> MSLM1INT_intrinsic_NBME_jl_Yl_tensor_s_tab(Nr);

      class array<TYPE> MOLP1INT_part_tab(Nr);
      class array<TYPE> MOLM1INT_part_tab(Nr);

      class array<TYPE> MSLP1INT_part_tab(Nr);
      class array<TYPE> MSLM1INT_part_tab(Nr);
      
      class array<TYPE> MSSCE_ME_part_tab(Nr);
      
      for (int l_intrinsic = l_intrinsic_min ; l_intrinsic <= l_intrinsic_max ; l_intrinsic++)
	{
	  const int lp_intrinsic_min = max (l_intrinsic - 1 , 0) , lp_intrinsic_max = l_intrinsic + 1;

	  const unsigned int lp_intrinsic_number = make_uns_int (lp_intrinsic_max - lp_intrinsic_min) + 1;
      
	  for (unsigned int i = 0 ; i < Nr ; i++)
	    {
	      MOLP1INT_all_intrinsic_NBME_tab(i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_LP1_index          , GRADIENT_BESSEL_LP1_index             , i);
	      MOLM1INT_all_intrinsic_NBME_tab(i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_LM1_index          , GRADIENT_BESSEL_LM1_index             , i);
	      MSLP1INT_all_intrinsic_NBME_tab(i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , SPIN_GRADIENT_RICCATI_BESSEL_DER_LP1_index , GRADIENT_RICCATI_BESSEL_DER_LP1_index , i);
	      MSLM1INT_all_intrinsic_NBME_tab(i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , SPIN_GRADIENT_RICCATI_BESSEL_DER_LM1_index , GRADIENT_RICCATI_BESSEL_DER_LM1_index , i);
	      MSSCE_all_intrinsic_NBME_tab(i)    = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , SPIN_S_SCALAR_E_index                      , SPIN_S_SCALAR_E_RADIAL_index          , i);

	      MOLP1INT_intrinsic_NBME_jl_Yl_tab(i)          = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_LP1_index , GRADIENT_BESSEL_LP1_index , i);
	      MOLM1INT_intrinsic_NBME_jl_Yl_tab(i)          = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , ORBITAL_GRADIENT_BESSEL_LM1_index , GRADIENT_BESSEL_LM1_index , i);
	      MSLP1INT_intrinsic_NBME_jl_Yl_tensor_s_tab(i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , SPIN_GRADIENT_BESSEL_LP1_index    , GRADIENT_BESSEL_LP1_index , i);
	      MSLM1INT_intrinsic_NBME_jl_Yl_tensor_s_tab(i) = EM_suboperator_intrinsic_NBMEs_strength(0 , 0 , ic , icp , L , l_intrinsic , SPIN_GRADIENT_BESSEL_LM1_index    , GRADIENT_BESSEL_LM1_index , i);
	    }
 
	  class array<TYPE> MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab(lp_intrinsic_number , Nr);

	  magnetic::intrinsic_NBMEs_store (Tpc_data , ic , icp , L , l_intrinsic , MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab);

	  const int LCM_min_in_out = abs (LCM_projectile_in - LCM_projectile_out);

	  const int LCM_max_in_out = LCM_projectile_in + LCM_projectile_out;

	  const int LCM_min_l_intrinsic = abs (L - l_intrinsic);

	  const int LCM_max_l_intrinsic = L + l_intrinsic;

	  const int LCM_min_L = max (LCM_min_in_out , LCM_min_l_intrinsic);
	  const int LCM_max_L = min (LCM_max_in_out , LCM_max_l_intrinsic);

	  for (int LCM = LCM_min_L ; LCM <= LCM_max_L ; LCM++)
	    {
	      const TYPE coupling_term = coupling_term_l_intrinsic_LCM (l_intrinsic , LCM , L);
	      
	      magnetic::orbital_gradient_ME_reduced_part_calc (is_it_longwavelength_approximation , is_it_Gauss_Legendre , 1 , l_intrinsic , LCM , L ,
							       CC_state_in , CC_state_out , ic_in , ic_out ,
							       MOLP1INT_all_intrinsic_NBME_tab , MOLP1INT_intrinsic_NBME_jl_Yl_tab , MOLP1INT_part_tab);
	      
	      magnetic::orbital_gradient_ME_reduced_part_calc (is_it_longwavelength_approximation , is_it_Gauss_Legendre , -1 , l_intrinsic , LCM , L ,
							       CC_state_in , CC_state_out , ic_in , ic_out ,
							       MOLM1INT_all_intrinsic_NBME_tab , MOLM1INT_intrinsic_NBME_jl_Yl_tab , MOLM1INT_part_tab);
	      
	      magnetic::spin_gradient_ME_reduced_calc (is_it_longwavelength_approximation , is_it_Gauss_Legendre , l_intrinsic , LCM , L ,
						       CC_state_in , CC_state_out , ic_in , ic_out ,
						       MSLP1INT_all_intrinsic_NBME_tab , MSLP1INT_intrinsic_NBME_jl_Yl_tensor_s_tab , MSLP1INT_part_tab);
	      
	      magnetic::spin_gradient_ME_reduced_calc (is_it_longwavelength_approximation , is_it_Gauss_Legendre , l_intrinsic , LCM , L ,
						       CC_state_in , CC_state_out , ic_in , ic_out ,
						       MSLM1INT_all_intrinsic_NBME_tab , MSLM1INT_intrinsic_NBME_jl_Yl_tensor_s_tab , MSLM1INT_part_tab);
		
	      magnetic::spin_s_scalar_e_ME_part_calc (is_it_longwavelength_approximation , is_it_Gauss_Legendre , l_intrinsic , LCM , L ,
						      CC_state_in , CC_state_out , ic_in , ic_out ,
						      MSSCE_all_intrinsic_NBME_tab , MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab , MSSCE_ME_part_tab);

	      magnetic_strength_tab += coupling_term*(MOLP1INT_part_tab + MOLM1INT_part_tab + MSLP1INT_part_tab + MSLM1INT_part_tab + MSSCE_ME_part_tab);
	    }	
	}
    }
}








// calculate <uc_f lf jf || M/E_L || uc_i li ji>
void CC_EM_transitions_strength_MEs::cluster::calc (
						    const enum EM_type EM , 
						    const int L , 
						    const bool is_it_longwavelength_approximation ,
						    const bool is_it_Gauss_Legendre , 
						    const class CC_target_projectile_composite_data &Tpc_data , 
						    const class array<class cluster_data> &cluster_data_tab ,
						    const unsigned int ic , 
						    const unsigned int icp , 
						    const class CC_state_class &CC_state_in , 
						    const class CC_state_class &CC_state_out , 
						    const unsigned int ic_in , 
						    const unsigned int ic_out ,
						    class array<TYPE> &strength_tab)
{
  switch (EM)
    {
    case ELECTRIC: electric::calc (L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , Tpc_data , cluster_data_tab , ic , icp ,CC_state_in , CC_state_out , ic_in , ic_out , strength_tab); break;

    case MAGNETIC: magnetic::calc (L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , Tpc_data , cluster_data_tab , ic , icp ,CC_state_in , CC_state_out , ic_in , ic_out , strength_tab); break;

    default: abort_all ();
    }
}




