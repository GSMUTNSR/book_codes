#include "../CC_include/CC_include_def.h"

using namespace inputs_misc;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_observables_common;
using namespace CC_EM_transitions_MEs;
using namespace CC_EM_transitions_MEs::radial;
using namespace configuration_SD_in_space_one_jump_out_to_in;
using namespace CC_EM_transitions_strength_MEs;
using namespace CC_EM_transitions_strength_MEs::radial;







// TYPE is double or complex
// -------------------------






// EM is for electromagnetic
// -------------------------

// E is for electric
// -----------------

// M is for magnetic
// -----------------




// Calculation of the strength function of the EM transition reduced matrix elements for a given suboperator between two channel wave functions
// --------------------------------------------------------------------------------------------------------------------------------------------
// One calculates <J[f] || EM || J[i]> for all r radii on [0:R], where the radial part reduces to one point (i.e. no integration over r).
// For this, one uses the decomposition <J[f] || EM || J[i]> = <J[f] || EM || J[i]> [nas] + (<J[f] || EM || J[i]> [as-HO] - <J[f] || EM || J[i]> [nas-HO]),
// where as means antisymmetrized channel functions and nas non-antisymmetrized channel functions.
// It is indeed impossible to calculate matrix elements with antisymmetrized channel functions directly because channel wave functions have two-body asymptotes, where target and projectile are not antisymmetrized.
//
// In nas, target and projectile arise from GSM and GSM-CC calculations but are not antisymmetrized with respect to each other in matrix elements formulas.
// One has EM = EM[projectile] + EM[target], so that one calculates separately the matrix elements of EM[projectile] and EM[target].
// nas matrix elements <J[f] || EM[target or projectile] || J[i]> = sum_{c[f], c[i]} <J[f] c[f] || EM[target or projectile] || J[i] c[i]>.
// <J[f] c[f] || EM[target or projectile] || J[i] c[i]> are then straightforward to calculate from <JT[f] c[f] || EM[target] or Id || JT[i] c[i]> and <Jp[f] || EM[projectile] or Id || Jp[i]>.
// <JT[f] c[f] || EM[target] || JT[i] c[i]> are given by shell model formulas and <Jp[f] || EM[projectile] || Jp[i]> are calculated in CC_EM_transitions_MEs::cluster or CC_EM_transitions_MEs::one_baryon.
// nas-HO is the same as nas except that channel wave functions and targets are all projected in the HO basis.
//
// In as, target and projectile are antisymmetrized in the HO basis : one projects all target and projectile states in the HO basis, so that antisymmetrization is handled with Slater determinants.
// Matrix elements of EM in as are then given by shell model formulas.
//
// As antisymmetrization effects between target and projectile only occur close to the target, it is sufficient to use the HO basis therein (as[HO]).
// The two-body asymptote is taken into account in the non-antisymmetrized calculation.
// It is clear that as, as-HO and nas, nas-HO matrix elements are equal at the limit of infinite HO basis.
// The previous decomposition is thus justified.

void CC_EM_transitions_strength_MEs::composite::target_projectile_as_HO_NBMEs_calc (
										    class GSM_vector &PSI_full , 
										    const bool is_it_one_baryon_COSM_case , 
										    const enum EM_type EM , 
										    const int L ,
										    const bool is_it_longwavelength_approximation , 
										    const bool is_it_Gauss_Legendre , 
										    const class CC_Hamiltonian_data &CC_H_data_in , 
										    const class CC_state_class &CC_state_in , 
										    const class CC_Hamiltonian_data &CC_H_data_out , 
										    const class CC_state_class &CC_state_out ,		
										    const class input_data_str &input_data_CC_Berggren , 
										    class baryons_data &prot_Y_data , 
										    class baryons_data &neut_Y_data , 
										    const class array<class cluster_data> &cluster_projectile_data_tab , 
										    class array<TYPE> &target_projectile_as_HO_strength_tab)
{
  target_projectile_as_HO_strength_tab = 0.0;

  const unsigned int BP_in  = CC_state_in.get_BP ();
  const unsigned int BP_out = CC_state_out.get_BP ();

  const double J_in  = CC_state_in.get_J ();
  const double J_out = CC_state_out.get_J ();
  
  const double M_in  = J_in;  
  const double M_out = J_out;

  const unsigned int BP_EM = BP_EM_determine (EM , L);

  if (binary_parity_product (BP_in , BP_EM) != BP_out) return;

  if ((abs (make_int (J_out - J_in)) > L) || (make_int (J_out + J_in) < L)) return;

  const enum space_type space = input_data_CC_Berggren.get_space ();
  
  const enum interaction_type inter = input_data_CC_Berggren.get_inter ();

  const bool truncation_hw = input_data_CC_Berggren.get_truncation_hw ();
  const bool truncation_ph = input_data_CC_Berggren.get_truncation_ph ();

  const int n_holes_max = input_data_CC_Berggren.get_n_holes_max ();

  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();
  
  const int n_scat_max = input_data_CC_Berggren.get_n_scat_max ();

  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int E_max_hw = input_data_CC_Berggren.get_E_max_hw ();

  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const complex<double> E_in_complex  = CC_state_in.get_E ();
  const complex<double> E_out_complex = CC_state_out.get_E ();
  
  const TYPE E_in  = generate_scalar<TYPE> (real (E_in_complex)  , imag (E_in_complex));
  const TYPE E_out = generate_scalar<TYPE> (real (E_out_complex) , imag (E_out_complex));
      
  const TYPE q = (E_in - E_out)/hbar_c;

  class GSM_vector_helper_class PSI_HO_in_helper (is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
						  n_holes_max   , n_scat_max   , E_max_hw ,
						  n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						  n_holes_max_n , n_scat_max_n , En_max_hw , BP_in , M_in , true , prot_Y_data , neut_Y_data);

  class GSM_vector PSI_HO_in (PSI_HO_in_helper);
	
  target_projectile_PSI_HO_calc (is_it_one_baryon_COSM_case , cluster_projectile_data_tab , CC_H_data_in , CC_state_in , prot_Y_data , neut_Y_data , PSI_HO_in);

  class GSM_vector_helper_class PSI_HO_out_helper (is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
						   n_holes_max   , n_scat_max   , E_max_hw ,
						   n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						   n_holes_max_n , n_scat_max_n , En_max_hw , BP_out , M_out , true , prot_Y_data , neut_Y_data);

  class GSM_vector PSI_HO_out (PSI_HO_out_helper);
  
  target_projectile_PSI_HO_calc (is_it_one_baryon_COSM_case , cluster_projectile_data_tab , CC_H_data_out , CC_state_out , prot_Y_data , neut_Y_data , PSI_HO_out);

  class GSM_vector_helper_class dummy_helper;
  
  class GSM_vector_helper_class PSI_HO_in_full_helper;
  
  PSI_HO_in_full_helper.allocate_fill_without_MPI_parallelization (PSI_HO_in_helper);

  configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , true , false , false , false , PSI_HO_in_full_helper , PSI_HO_out_helper , dummy_helper , prot_Y_data , neut_Y_data);
  
  EM_transitions_strength_NBMEs::B_amplitude_tab_calc (EM , q , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , PSI_full ,
						       J_in , PSI_HO_in , J_out , PSI_HO_out , target_projectile_as_HO_strength_tab);
		
#ifdef UseMPI
  if (is_it_MPI_parallelized) target_projectile_as_HO_strength_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}
















// Calculation of the strength function of the nas <J[f] || EM[target] || J[i]> matrix elements from <JT[f] c[f] || EM[target] || JT[i] c[i]> and <Jp[f] || Jp[i]> (see above)
// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

void CC_EM_transitions_strength_MEs::composite::target_nas_NBMEs_calc (
								       const enum EM_type EM , 
								       const int L , 
								       const bool is_it_longwavelength_approximation , 
								       const bool is_it_Gauss_Legendre , 
								       const class CC_target_projectile_composite_data &Tpc_data , 
								       const class CC_state_class &CC_state_in , 
								       const class CC_state_class &CC_state_out , 
								       const class array<TYPE> &target_reduced_NBMEs , 
								       class array<TYPE> &target_nas_strength_tab)
{
  const class array<unsigned int> &target_indices = Tpc_data.get_target_indices ();
  
  const int L_for_radiative_capture_cross_section = Tpc_data.get_L_for_radiative_capture_cross_section ();

  const unsigned int BP_EM = BP_EM_determine (EM , L);

  const class array<class CC_channel_class> &channels_tab_JPi_A_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_JPi_A_out = CC_state_out.get_channels_tab ();

  const double J_in  = CC_state_in.get_J ();
  const double J_out = CC_state_out.get_J ();

  const unsigned int N_channels_JPi_A_in  = CC_state_in.get_N_channels ();
  const unsigned int N_channels_JPi_A_out = CC_state_out.get_N_channels ();

  const unsigned int N_bef_R_GL = CC_state_in.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state_in.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  target_nas_strength_tab = 0.0;

  // "out" target state
  for (unsigned int ic_out = 0 ; ic_out < N_channels_JPi_A_out ; ic_out++)
    {
      const class CC_channel_class &channel_c_out = channels_tab_JPi_A_out(ic_out);

      const enum particle_type projectile_c_out = channel_c_out.get_projectile ();

      const unsigned int BP_Tc_out = channel_c_out.get_BP_Tc ();

      const unsigned int vector_index_Tc_out = channel_c_out.get_vector_index_Tc ();

      const double J_Tc_out = channel_c_out.get_J_Tc ();

      const double J_projectile_c_out = channel_c_out.get_J_projectile ();

      const int LCM_projectile_c_out = channel_c_out.get_LCM_projectile ();

      const int two_J_Tc_out = make_int (2.0*J_Tc_out);

      const unsigned int iTc_out = target_indices(BP_Tc_out , two_J_Tc_out , vector_index_Tc_out);

      // "in" target state
      for (unsigned int ic_in = 0 ; ic_in < N_channels_JPi_A_in ; ic_in++)
	{
	  const class CC_channel_class &channel_c_in = channels_tab_JPi_A_in(ic_in);

	  const enum particle_type projectile_c_in = channel_c_in.get_projectile ();

	  const unsigned int BP_Tc_in = channel_c_in.get_BP_Tc ();

	  const unsigned int vector_index_Tc_in = channel_c_in.get_vector_index_Tc ();

	  const double J_Tc_in = channel_c_in.get_J_Tc ();

	  const double J_projectile_c_in = channel_c_in.get_J_projectile ();

	  const int LCM_projectile_c_in = channel_c_in.get_LCM_projectile ();

	  const int two_J_Tc_in = make_int (2.0*J_Tc_in);

	  const unsigned int iTc_in = target_indices(BP_Tc_in , two_J_Tc_in , vector_index_Tc_in);

	  const bool BP_targets_condition = (binary_parity_product (BP_Tc_in , BP_EM) == BP_Tc_out);

	  const bool projectiles_condition = (projectile_c_in == projectile_c_out);

	  const bool LCM_projectiles_condition = (LCM_projectile_c_out == LCM_projectile_c_in);

	  const bool J_projectiles_condition = (rint (J_projectile_c_out - J_projectile_c_in) == 0.0);

	  const int Lmin = abs (make_int (J_Tc_in - J_Tc_out));
	  const int Lmax =      make_int (J_Tc_in + J_Tc_out);

	  const bool L_condition = ((L >= Lmin) && (L <= Lmax) && (L == L_for_radiative_capture_cross_section));

	  // deltas (is it the same projectile and quantum numbers are conserved)
	  if (BP_targets_condition && projectiles_condition && LCM_projectiles_condition && J_projectiles_condition && L_condition)
	    {
	      const double jc = J_projectile_c_out;

	      const TYPE factor_radial = radial_integral_calc (OVERLAP , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);

	      for (unsigned int i = 0 ; i < Nr ; i++)
		{
		  // get <JT[f] c[f] || EM[target] || JT[i] c[i]>
		  const TYPE target_reduced_NBME = target_reduced_NBMEs(iTc_in , iTc_out , i);

		  // calculation of sum_{cf , ci} <J[f] c[f] || EM[target] || J[i] c[i]>
		  const TYPE total_NBME_reduced = Oa_reduced_ME_calc (L , J_Tc_in , jc , J_in , J_Tc_out , jc , J_out , target_reduced_NBME) * factor_radial;

		  target_nas_strength_tab(i) += total_NBME_reduced;
		}
	    }//deltas
	}//loop ic_in
    }//loop ic_out
}











// Calculation of the strength function of the nas <J[f] || EM[projectile] || J[i]> matrix elements from <Jp[f] || EM[projectile] || Jp[i]> and <JT[f] c[f] || JT[i] c[i]> (see above)
// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

void CC_EM_transitions_strength_MEs::composite::projectile_nas_NBMEs_calc (
									   const enum EM_type EM , 
									   const int L , 
									   const bool is_it_longwavelength_approximation ,
									   const bool is_it_Gauss_Legendre , 
									   const class CC_target_projectile_composite_data &Tpc_data , 
									   const class CC_state_class &CC_state_in , 
									   const class CC_state_class &CC_state_out ,
									   const class array<class cluster_data> &cluster_projectile_data_tab , 
									   class array<TYPE> &projectile_nas_strength_tab)
{
  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();

  const class array<double> &effective_charges_p = Tpc_data.get_effective_charges_p ();
  const class array<double> &effective_charges_n = Tpc_data.get_effective_charges_n ();
  
  const int L_for_radiative_capture_cross_section = Tpc_data.get_L_for_radiative_capture_cross_section ();

  const unsigned int BP_EM = BP_EM_determine (EM , L);

  const class array<class CC_channel_class> &channels_tab_JPi_A_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_JPi_A_out = CC_state_out.get_channels_tab ();

  const double J_in  = CC_state_in.get_J ();
  const double J_out = CC_state_out.get_J ();

  const unsigned int N_channels_JPi_A_in  = CC_state_in.get_N_channels ();
  const unsigned int N_channels_JPi_A_out = CC_state_out.get_N_channels ();

  const unsigned int N_bef_R_GL = CC_state_in.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state_in.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  class array<TYPE> projectile_nas_strength_channels_fixed_tab(Nr);

  projectile_nas_strength_tab = 0.0;

  for (unsigned int ic_out = 0 ; ic_out < N_channels_JPi_A_out ; ic_out++)
    {
      const class CC_channel_class &channel_c_out = channels_tab_JPi_A_out(ic_out);

      const int LCM_projectile_c_out = channel_c_out.get_LCM_projectile ();

      const unsigned int BP_Tc_out = channel_c_out.get_BP_Tc ();

      const unsigned int bp_c_out = binary_parity_from_orbital_angular_momentum (LCM_projectile_c_out);

      const unsigned int vector_index_Tc_out = channel_c_out.get_vector_index_Tc ();

      const double J_projectile_c_out = channel_c_out.get_J_projectile ();

      const double J_Tc_out = channel_c_out.get_J_Tc ();

      const enum particle_type projectile_c_out = channel_c_out.get_projectile ();

      for (unsigned int ic_in = 0 ; ic_in < N_channels_JPi_A_in ; ic_in++)
	{
	  const class CC_channel_class &channel_c_in = channels_tab_JPi_A_in(ic_in);

	  const int LCM_projectile_c_in = channel_c_in.get_LCM_projectile ();

	  const unsigned int BP_Tc_in = channel_c_in.get_BP_Tc ();

	  const unsigned int bp_c_in = binary_parity_from_orbital_angular_momentum (LCM_projectile_c_in);

	  const unsigned int vector_index_Tc_in = channel_c_in.get_vector_index_Tc ();

	  const double J_projectile_c_in = channel_c_in.get_J_projectile ();

	  const double J_Tc_in = channel_c_in.get_J_Tc ();

	  const enum particle_type projectile_c_in = channel_c_in.get_projectile ();

	  const bool BP_targets_condition = (BP_Tc_in == BP_Tc_out);

	  const bool J_targets_condition = (rint (J_Tc_in - J_Tc_out) == 0.0);

	  const bool vector_index_targets_condition = (vector_index_Tc_in == vector_index_Tc_out);

	  const bool projectiles_condition = (projectile_c_in == projectile_c_out);

	  const bool bp_projectiles_condition = (binary_parity_product (bp_c_in , BP_EM) == bp_c_out);

	  const int Lmin = abs (make_int (J_projectile_c_in - J_projectile_c_out));
	  const int Lmax =      make_int (J_projectile_c_in + J_projectile_c_out);

	  const bool L_condition = ((L >= Lmin) && (L <= Lmax) && (L == L_for_radiative_capture_cross_section));

	  // delta (if it is the same target and quantum numbers are conserved)
	  if (BP_targets_condition && J_targets_condition && vector_index_targets_condition && projectiles_condition && bp_projectiles_condition && L_condition)
	    {
	      const unsigned int ic = (!is_it_one_baryon_COSM_case) ? (cluster_data_index_determine (projectile_c_in , cluster_projectile_data_tab)) : (NADA);

	      const double J_Tc = J_Tc_out;

	      // calculation of sum_{c[f] , c[i]} <J[f] c[f] || EM[projectile] || J[i] c[i]>
	      
	      if (is_it_one_baryon_COSM_case) 
		{
		  const unsigned int projectile_c_in_index = charge_baryon_index_determine (projectile_c_in);
	  
		  const int charge_projectile_c_in = particle_charge_determine (projectile_c_in);

		  const bool is_it_charged_projectile_c_in = (charge_projectile_c_in != 0);
	  
		  const double effective_charge = (is_it_charged_projectile_c_in) ? (effective_charges_p(projectile_c_in_index)) : (effective_charges_n(projectile_c_in_index));
		  
		  one_baryon::OBMEs_reduced_calc (EM , L , is_it_longwavelength_approximation , effective_charge ,  is_it_Gauss_Legendre , CC_state_in , CC_state_out , ic_in , ic_out , projectile_nas_strength_channels_fixed_tab);
		}
	      else
		cluster::calc (EM , L , is_it_longwavelength_approximation ,  is_it_Gauss_Legendre , 
			       Tpc_data , cluster_projectile_data_tab , ic , ic , CC_state_in , CC_state_out , ic_in , ic_out , projectile_nas_strength_channels_fixed_tab);

	      for (unsigned int i = 0 ; i < Nr ; i++)
		{
		  const TYPE projectile_nas_strength_channels_fixed = projectile_nas_strength_channels_fixed_tab(i);
		  
		  const TYPE NBME_reduced = Ob_reduced_ME_calc (L , J_Tc , J_projectile_c_in , J_in , J_Tc , J_projectile_c_out , J_out , projectile_nas_strength_channels_fixed);

		  projectile_nas_strength_tab(i) += NBME_reduced;
		}// loop Nr
	    }//delta
	}//loop ic_in
    }//loop_ic_out
}







// Calculation of the strength function of the <JT[f] c[f] || EM[target] || JT[i] c[i]> matrix elements entering nas matrix elements (see above)
// ---------------------------------------------------------------------------------------------------------------------------------------------

void CC_EM_transitions_strength_MEs::composite::target_reduced_NBMEs_calc (
									   class GSM_vector &PSI_full , 
									   const enum interaction_type inter ,
									   const enum EM_type EM ,
									   const TYPE &q , 
									   const int L ,  
									   const bool is_it_longwavelength_approximation , 
									   const bool is_it_Gauss_Legendre , 
									   const bool full_common_vectors_used_in_file , 
									   const class CC_target_projectile_composite_data &Tpc_data , 
									   class array<class baryons_data> &prot_Y_data_one_cluster_less_tab , 
									   class array<class baryons_data> &neut_Y_data_one_cluster_less_tab ,
									   class array<TYPE> &target_reduced_strength_tab)
{
  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();

  const int n_holes_max = Tpc_data.get_n_holes_max ();
  
  const int n_scat_max = Tpc_data.get_n_scat_max ();

  const int E_relative_max_hw = Tpc_data.get_E_relative_max_hw ();

  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();

  const unsigned int BP_EM = BP_EM_determine (EM , L);

  const class array<unsigned int> &BP_target_tab = Tpc_data.get_BP_target_tab ();

  const class array<double> &J_target_tab = Tpc_data.get_J_target_tab ();

  const class array<unsigned int> &vector_index_target_tab = Tpc_data.get_vector_index_target_tab ();

  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();

  const class array<TYPE> &E_target_tab =  Tpc_data.get_E_target_tab ();

  const class GSM_vector_helper_class dummy_helper;

  const unsigned int Nr = target_reduced_strength_tab.dimension (2);

  class array<TYPE> target_reduced_NBMEs_fixed_targets(Nr);

  // "out" target state
  for (unsigned int iT_out = 0 ; iT_out < N_target_projectile_states ; iT_out++)
    {
      const unsigned int BP_target_out = BP_target_tab(iT_out);

      const unsigned int vector_index_target_out = vector_index_target_tab(iT_out);

      const double J_target_out = J_target_tab(iT_out);

      const double M_target_out = J_target_out;

      const TYPE E_target_out = E_target_tab(iT_out);

      const enum particle_type projectile_out = projectile_tab(iT_out);

      const int Z_projectile_out = Z_cluster_determine (projectile_out);
      const int N_projectile_out = N_cluster_determine (projectile_out);
      
      const int S_projectile_out = particle_strangeness_determine (projectile_out);
      
      const int Y_projectile_out = (S_projectile_out > 0) ? (1) : (0);

      class baryons_data &prot_Y_data_target_out = prot_Y_data_one_cluster_less_tab(Z_projectile_out , N_projectile_out , Y_projectile_out);
      class baryons_data &neut_Y_data_target_out = neut_Y_data_one_cluster_less_tab(Z_projectile_out , N_projectile_out , Y_projectile_out);

      const int n_holes_max_p_target_out = prot_Y_data_target_out.get_n_holes_max ();
      const int n_holes_max_n_target_out = neut_Y_data_target_out.get_n_holes_max ();
      
      const int n_scat_max_p_target_out = prot_Y_data_target_out.get_n_scat_max ();
      const int n_scat_max_n_target_out = neut_Y_data_target_out.get_n_scat_max ();

      const int ZYval_target_out = prot_Y_data_target_out.get_N_valence_baryons ();
      const int NYval_target_out = neut_Y_data_target_out.get_N_valence_baryons ();

      if ((ZYval_target_out == 0) && (NYval_target_out == 0)) continue;
      
      const int n_scat_max_target_out = min (n_scat_max , n_scat_max_p_target_out + n_scat_max_n_target_out);
      
      const int Z_target_out = prot_Y_data_target_out.get_N_nucleons ();
      const int N_target_out = neut_Y_data_target_out.get_N_nucleons ();

      const int S_target_out = prot_Y_data_target_out.get_hypernucleus_strangeness ();
      
      const int Ep_max_hw_target_out = prot_Y_data_target_out.get_E_max_hw ();
      const int En_max_hw_target_out = neut_Y_data_target_out.get_E_max_hw ();
      
      const int Ep_min_hw_target_out = prot_Y_data_target_out.get_E_min_hw ();
      const int En_min_hw_target_out = neut_Y_data_target_out.get_E_min_hw ();

      const int E_min_hw_target_out = Ep_min_hw_target_out + En_min_hw_target_out;

      const int E_max_hw_target_out = E_relative_max_hw + E_min_hw_target_out;

      const enum space_type space_target_out = space_determine (ZYval_target_out , NYval_target_out);

      const class correlated_state_str PSI_target_out (Z_target_out , N_target_out , BP_target_out , S_target_out , J_target_out , vector_index_target_out , E_target_out , NADA , NADA , NADA , false);
 
      class GSM_vector_helper_class V_target_out_helper (is_it_MPI_parallelized , space_target_out , inter , false , truncation_hw , truncation_ph ,
							 n_holes_max              , n_scat_max_target_out   , E_max_hw_target_out , 
							 n_holes_max_p_target_out , n_scat_max_p_target_out , Ep_max_hw_target_out ,
							 n_holes_max_n_target_out , n_scat_max_n_target_out , En_max_hw_target_out , 
							 BP_target_out , M_target_out , true , prot_Y_data_target_out , neut_Y_data_target_out);

      class GSM_vector V_target_out (V_target_out_helper);
      
      if (is_it_realistic_interaction (inter))
	V_target_out.eigenvector_read_disk (true , true , PSI_target_out);
      else
	V_target_out.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_target_out);

      // "in" target state
      for (unsigned int iT_in = 0 ; iT_in < N_target_projectile_states ; iT_in++)
	{
	  const unsigned int BP_target_in = BP_target_tab(iT_in);

	  const unsigned int vector_index_target_in = vector_index_target_tab(iT_in);

	  const double J_target_in = J_target_tab(iT_in);

	  const double M_target_in = J_target_in;

	  const TYPE E_target_in = E_target_tab(iT_in);
	  
	  const enum particle_type projectile_in = projectile_tab(iT_in);

	  const int Z_projectile_in = Z_cluster_determine (projectile_in);
	  const int N_projectile_in = N_cluster_determine (projectile_in);
      
	  const int S_projectile_in = particle_strangeness_determine (projectile_in);
      
	  const int Y_projectile_in = (S_projectile_in > 0) ? (1) : (0);

	  class baryons_data &prot_Y_data_target_in = prot_Y_data_one_cluster_less_tab(Z_projectile_in , N_projectile_in , Y_projectile_in);
	  class baryons_data &neut_Y_data_target_in = neut_Y_data_one_cluster_less_tab(Z_projectile_in , N_projectile_in , Y_projectile_in);

	  const int n_holes_max_p_target_in = prot_Y_data_target_in.get_n_holes_max ();
	  const int n_holes_max_n_target_in = neut_Y_data_target_in.get_n_holes_max ();
	  
	  const int n_scat_max_p_target_in = prot_Y_data_target_in.get_n_scat_max ();
	  const int n_scat_max_n_target_in = neut_Y_data_target_in.get_n_scat_max ();

	  const int ZYval_target_in = prot_Y_data_target_in.get_N_valence_baryons ();
	  const int NYval_target_in = neut_Y_data_target_in.get_N_valence_baryons ();

	  if ((ZYval_target_in == 0) && (NYval_target_in == 0)) continue;
	  
	  const int n_scat_max_target_in = min (n_scat_max , n_scat_max_p_target_in + n_scat_max_n_target_in);
	  
	  const int Z_target_in = prot_Y_data_target_in.get_N_nucleons ();
	  const int N_target_in = neut_Y_data_target_in.get_N_nucleons ();
	  
	  const int S_target_in = prot_Y_data_target_in.get_hypernucleus_strangeness ();

	  const int Ep_max_hw_target_in = prot_Y_data_target_in.get_E_max_hw ();
	  const int En_max_hw_target_in = neut_Y_data_target_in.get_E_max_hw ();
	  
	  const int Ep_min_hw_target_in = prot_Y_data_target_in.get_E_min_hw ();
	  const int En_min_hw_target_in = neut_Y_data_target_in.get_E_min_hw ();

	  const int E_min_hw_target_in = Ep_min_hw_target_in + En_min_hw_target_in;

	  const int E_max_hw_target_in = E_relative_max_hw + E_min_hw_target_in;
	  
	  const enum space_type space_target_in = space_determine (ZYval_target_in , NYval_target_in);

	  const class correlated_state_str PSI_target_in (Z_target_in , N_target_in , BP_target_in , S_target_in , J_target_in , vector_index_target_in , E_target_in , NADA , NADA , NADA , false);

	  class GSM_vector_helper_class V_target_in_helper (is_it_MPI_parallelized , space_target_in , inter , false , truncation_hw , truncation_ph ,
							    n_holes_max             , n_scat_max_target_in   , E_max_hw_target_in , 
							    n_holes_max_p_target_in , n_scat_max_p_target_in , Ep_max_hw_target_in ,
							    n_holes_max_n_target_in , n_scat_max_n_target_in , En_max_hw_target_in , 
							    BP_target_in , M_target_in , true , prot_Y_data_target_in , neut_Y_data_target_in);

	  // deltas (is it the same projectile)
	  if ((space_target_in == space_target_out) && (projectile_in == projectile_out))
	    {
	      class GSM_vector V_target_in (V_target_in_helper);

	      if (is_it_realistic_interaction (inter))
		V_target_in.eigenvector_read_disk (true , true , PSI_target_in);
	      else
		V_target_in.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_target_in);

	      if (binary_parity_product (BP_target_in , BP_EM) == BP_target_out)
		{		 
		  // calculates <JT[f] c[f] || EM[target] || JT[i] c[i]>

		  EM_transitions_strength_NBMEs::B_amplitude_tab_calc (EM , q , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , 
								       PSI_full , J_target_in , V_target_in , J_target_out , V_target_out , target_reduced_NBMEs_fixed_targets);

		  if (THIS_PROCESS == MASTER_PROCESS) 
		    {
		      for (unsigned int i = 0 ; i < Nr ; i++) 
			target_reduced_strength_tab(iT_in , iT_out , i) = target_reduced_NBMEs_fixed_targets(i);
		    }
		}
	    }//deltas projectile
	}//loop iT_in
    }//loop iT_out

#ifdef UseMPI
  if (is_it_MPI_parallelized) target_reduced_strength_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}










// Calculation of the strength function of the EM transition matrix elements <J[f] || EM || J[i]> between two channel wave functions
// ---------------------------------------------------------------------------------------------------------------------------------
// The decomposition <J[f] || EM || J[i]> = <J[f] || EM || J[i]> [nas] + (<J[f] || EM || J[i]> [as-HO] - <J[f] || EM || J[i]> [nas-HO]) is used here (see above).

void CC_EM_transitions_strength_MEs::composite::calc (
						      class GSM_vector &PSI_full , 
						      const enum EM_type EM ,
						      const int L , 
						      const bool is_it_longwavelength_approximation ,
						      const bool is_it_Gauss_Legendre , 
						      const class CC_target_projectile_composite_data &Tpc_data , 
						      const class array<class cluster_data> &cluster_projectile_data_tab , 
						      const bool is_it_nas_only ,
						      const class CC_Hamiltonian_data &CC_H_data_in , 
						      const class CC_state_class &CC_state_in , 
						      const class CC_Hamiltonian_data &CC_H_data_out , 
						      const class CC_state_class &CC_state_out ,		
						      class baryons_data &prot_Y_data , 
						      class baryons_data &neut_Y_data , 
						      const class input_data_str &input_data_CC_Berggren , 
						      const class array<TYPE> &target_reduced_NBMEs ,
						      class array<TYPE> &strength_tab)
{	
  const unsigned int N_bef_R_GL = CC_state_in.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state_in.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();
  
  //================================== projectile ==================================//
  // for the non antisymmetrized (nas) the CC_state_out/in are used
  // for the non antisymmetrized + HO (nas-HO) the CC_state_out/in are projected in the HO basis

  // projection of the out and in states in the HO basis

  class CC_state_class CC_state_in_HO  (CC_state_in);
  class CC_state_class CC_state_out_HO (CC_state_out);

  CC_state_in_HO.CC_HO_wfs_projection ();
  CC_state_out_HO.CC_HO_wfs_projection ();

  class array<TYPE> projectile_nas_strength_tab(Nr);

  class array<TYPE> target_nas_strength_tab(Nr);

  //===================================non antisymmetrized (nas)==============================================================================

  // reduced matrix elements for the projectile
  projectile_nas_NBMEs_calc (EM , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , 
			     Tpc_data , CC_state_in , CC_state_out , cluster_projectile_data_tab , projectile_nas_strength_tab);

  // reduced matrix elements for the target
  target_nas_NBMEs_calc (EM , L , is_it_longwavelength_approximation ,is_it_Gauss_Legendre , 
			 Tpc_data , CC_state_in , CC_state_out , target_reduced_NBMEs , target_nas_strength_tab);

  // calculation of nas matrix elements <J[f] || EM || J[i]> = sum_{c[f] , c[i]} ( <J[f] c[f] || EM[projectile] || J[i] c[i]> + <J[f] c[f] || EM[target] || J[i] c[i]> )

  if (is_it_nas_only)
    {
      strength_tab = projectile_nas_strength_tab + target_nas_strength_tab;

      return;
    }

  class array<TYPE> projectile_nas_HO_strength_tab(Nr);

  class array<TYPE> target_nas_HO_strength_tab(Nr);

  class array<TYPE> total_reduced_as_HO_strength_tab(Nr);

  const class array<TYPE> total_reduced_nas_strength_tab = projectile_nas_strength_tab + target_nas_strength_tab;

  // nas reduced matrix elements for the projectile in the HO basis (nas-HO)
  projectile_nas_NBMEs_calc (EM , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , 
			     Tpc_data , CC_state_in_HO , CC_state_out_HO , cluster_projectile_data_tab , projectile_nas_HO_strength_tab);

  // nas reduced matrix elements for the target in the HO basis (nas-HO)
  target_nas_NBMEs_calc (EM , L , is_it_longwavelength_approximation ,is_it_Gauss_Legendre , 
			 Tpc_data , CC_state_in_HO , CC_state_out_HO , target_reduced_NBMEs , target_nas_HO_strength_tab);

  // calculation of nas matrix elements <J[f] || Op || J[i]> = sum_{c[f] , c[i]} ( <J[f] c[f] || Op[projectile] || J[i] c[i]> + <J[f] c[f] || Op[target] || J[i] c[i]> ) in the HO basis (nas-HO)
  const class array<TYPE> total_reduced_nas_HO_strength_tab = projectile_nas_HO_strength_tab + target_nas_HO_strength_tab;

  //================================== antisymmetrized and HO projection (as_HO) ===================================//
  //================================================================================================================//

  //================================== calculation of the antisymmetrized matrix element in the HO basis ==================================//

  // <Jf || EM || Ji> antisymmetrized in the HO basis
  target_projectile_as_HO_NBMEs_calc (PSI_full , is_it_one_baryon_COSM_case , EM , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , 
				      CC_H_data_in , CC_state_in , CC_H_data_out , CC_state_out , input_data_CC_Berggren , prot_Y_data , neut_Y_data , cluster_projectile_data_tab , 
				      total_reduced_as_HO_strength_tab);

  // final result of the decomposition of the operator matrix elements
  strength_tab = total_reduced_nas_strength_tab + (total_reduced_as_HO_strength_tab - total_reduced_nas_HO_strength_tab);
}
