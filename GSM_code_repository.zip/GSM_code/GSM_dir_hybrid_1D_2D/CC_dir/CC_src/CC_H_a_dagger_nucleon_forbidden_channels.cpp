#include "../CC_include/CC_include_def.h"

using namespace string_routines;
using namespace correlated_state_routines;
using namespace inputs_misc;
using namespace a_dagger_nucleon_helper;


void CC_H_a_dagger_nucleon_forbidden_channels::a_dagger_nucleon_calculations_and_copy_disk (
											    const bool print_detailed_information , 
											    const double CC_average_n_scat_target_projectile_max , 
											    const bool full_common_vectors_used_in_file , 
											    const class array<class CC_channel_class> &channels_tab , 
											    const class nucleons_data &prot_data , 
											    const class nucleons_data &neut_data , 
											    const double J , 
											    const class J2_class &J2 , 
											    class GSM_vector &Vstore , 
											    class GSM_vector &a_dagger_nucleon_PSI_c_coupled) 
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "a+(projectile) |target> one nucleon calculation" << endl;
      cout         << "-----------------------------------------------" << endl << endl;
    }

  const unsigned int N_channels = channels_tab.dimension (0);

  const class GSM_vector_helper_class &GSM_vector_helper = Vstore.get_GSM_vector_helper ();
  
  const double M = GSM_vector_helper.get_M ();
  
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const complex<double> E_Tc = channel_c.get_E_Tc ();

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const enum particle_type particle_c = channel_c.get_projectile ();

      const class nucleons_data &data_tau_c = (particle_c == PROTON) ? (prot_data) : (neut_data);	

      const int Z_Tc = channel_c.get_Z_Tc ();
      const int N_Tc = channel_c.get_N_Tc ();

      const class lj_table<int> &nmax_lj_c = data_tau_c.get_nmax_lj_tab ();

      const double jc = channel_c.get_J_projectile ();

      const double J_Tc = channel_c.get_J_Tc ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const int lc = channel_c.get_LCM_projectile ();

      const int nmax_c = nmax_lj_c(lc , jc);

      const unsigned int BP_Tc = channel_c.get_BP_Tc ();

      const unsigned int vector_index_Tc = channel_c.get_vector_index_Tc ();

      const unsigned int BP = channel_c.get_BP ();

      const class nlj_table<bool> &is_it_valence_shell_tab_c = data_tau_c.get_is_it_valence_shell_tab ();

      const class nlj_table<unsigned int> &shells_indices_c = data_tau_c.get_shells_indices ();

      const class array<class nlj_struct> &shells_qn_c = data_tau_c.get_shells_quantum_numbers ();

      const string Tc_str = "Target[c] : Z:" + make_string<int> (Z_Tc) + " N:" + make_string<int> (N_Tc) + " " + J_Pi_vector_index_string (BP_Tc , J_Tc , vector_index_Tc);

      if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl << "ic:" << ic << " channel : "<< channel_c << " nmax : " << nmax_c << endl << endl;

      const class correlated_state_str PSI_qn_Tc(Z_Tc , N_Tc , BP_Tc , J_Tc , vector_index_Tc , E_Tc , NADA , NADA , NADA , false);

      for (int nc = 0 ; nc <= nmax_c ; nc++) 
	{	
	  if (is_it_valence_shell_tab_c(nc , lc , jc))
	    {
	      const unsigned int shell_index_c = shells_indices_c(nc , lc , jc);
	      
	      const class nlj_struct &shell_qn_c = shells_qn_c(shell_index_c);

	      const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	      const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	      if (real_average_n_scat_c < CC_average_n_scat_target_projectile_max)
		{
		  const double reference_time = absolute_time_determine ();

		  a_dagger_nucleon_PSI_c_coupled = a_dagger_nucleon_coupled_to_J (full_common_vectors_used_in_file , shell_qn_c , particle_c , PSI_qn_Tc , J , M);

		  const double J_coupling_precision = J2.J_coupling_precision_calc (a_dagger_nucleon_PSI_c_coupled , J , Vstore);

		  const double now = absolute_time_determine () , relative_time = now - reference_time; 

		  if (THIS_PROCESS == MASTER_PROCESS) 
		    {
		      if (print_detailed_information || (J_coupling_precision > sqrt_precision))
			{
			  cout << "[a+(" << particle_c << " " << nc << angular_state (lc , jc) << ") ";
		      
			  cout << Tc_str << "]^(" << J_Pi_string (BP , J) << ") calculated , J^2 precision:" << J_coupling_precision << " time:" << relative_time << " s" << endl;
			  
			  if (J_coupling_precision > sqrt_precision) error_message_print_abort ("The composite state is not coupled to J in CC_H_a_dagger_nucleon_forbidden_channels::a_dagger_nucleon_calculations_and_copy_disk");
			}
		    }
		  
		  const string a_dagger_nucleon_PSI_c_coupled_file_name = PSI_OUT_coupled_to_J_file_name_a_dagger_nucleon_determine (false , "a_dagger_nucleon" , nc , lc , jc , particle_c , PSI_qn_Tc , J , M);
		  
		  a_dagger_nucleon_PSI_c_coupled.copy_disk (false , false , a_dagger_nucleon_PSI_c_coupled_file_name);
		}
	    }
	}
    }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl;
}










void CC_H_a_dagger_nucleon_forbidden_channels::is_it_forbidden_channel_tab_calc (
										 const bool print_detailed_information , 
										 const double CC_average_n_scat_target_projectile_max , 
										 const double CC_forbidden_channel_precision , 
										 const class array<class CC_channel_class> &channels_tab , 
										 const class nucleons_data &prot_data , 
										 const class nucleons_data &neut_data , 
										 const double J , 
										 class GSM_vector &V_in , 
										 class array<bool> &is_it_forbidden_channel_tab)
{
  const double reference_time = absolute_time_determine ();
  
  const class GSM_vector_helper_class &V_helper = V_in.get_GSM_vector_helper ();

  const unsigned int BP = V_helper.get_BP ();

  const unsigned int N_channels = channels_tab.dimension (0);

  const double M = V_helper.get_M ();

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Forbidden channels one nucleon determination" << endl << endl;
  
  const int nmax_all_plus_one = is_it_forbidden_channel_tab.dimension (1);

  class array<class GSM_vector> V_out_tab(NUMBER_OF_THREADS);

  for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++) V_out_tab(i_thread).allocate_fill (V_in);
  
  class array<complex<double> > overlaps(N_channels , nmax_all_plus_one , N_channels , nmax_all_plus_one);

  overlaps = 0.0;
  
  is_it_forbidden_channel_tab = false;
  
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type particle_c = channel_c.get_projectile ();
      
      const complex<double> E_Tc = channel_c.get_E_Tc ();

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const class nucleons_data &data_tau_c = (particle_c == PROTON) ? (prot_data) : (neut_data);	

      const int Z_Tc = channel_c.get_Z_Tc ();
      const int N_Tc = channel_c.get_N_Tc ();

      const double jc = channel_c.get_J_projectile ();

      const double J_Tc = channel_c.get_J_Tc ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const class lj_table<int> &nmax_lj_c = data_tau_c.get_nmax_lj_tab ();

      const int lc = channel_c.get_LCM_projectile ();

      const int nmax_c = nmax_lj_c(lc , jc);

      const unsigned int BP_Tc = channel_c.get_BP_Tc ();

      const unsigned int vector_index_Tc = channel_c.get_vector_index_Tc ();

      const class nlj_table<bool> &is_it_valence_shell_tab_c = data_tau_c.get_is_it_valence_shell_tab ();

      const class nlj_table<unsigned int> &shells_indices_c = data_tau_c.get_shells_indices ();

      const class array<class nlj_struct> &shells_qn_c = data_tau_c.get_shells_quantum_numbers ();

      class correlated_state_str PSI_qn_Tc(Z_Tc , N_Tc , BP_Tc , J_Tc , vector_index_Tc , E_Tc , NADA , NADA , NADA , false);

      const string Tc_str = "Target[c] : Z:" + make_string<int> (Z_Tc) + " N:" + make_string<int> (N_Tc) + " " + J_Pi_vector_index_string (BP_Tc , J_Tc , vector_index_Tc);

      for (int nc = 0 ; nc <= nmax_c ; nc++) 
	{	
	  if (is_it_valence_shell_tab_c(nc , lc , jc))
	    {
	      const unsigned int shell_index_c = shells_indices_c(nc , lc , jc);

	      const class nlj_struct &shell_qn_c = shells_qn_c(shell_index_c);

	      const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	      const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	      if (real_average_n_scat_c < CC_average_n_scat_target_projectile_max)
		{	
		  const string a_dagger_nucleon_PSI_c_coupled_file_name = PSI_OUT_coupled_to_J_file_name_a_dagger_nucleon_determine (false , "a_dagger_nucleon" , nc , lc , jc , particle_c , PSI_qn_Tc , J , M);

		  V_in.read_disk (false , false , a_dagger_nucleon_PSI_c_coupled_file_name);

		  bool is_it_forbidden_channel = false;

		  const complex<double> V_in_norm = sqrt (V_in*V_in);
					
		  if (inf_norm (V_in_norm) < CC_forbidden_channel_precision) is_it_forbidden_channel = true;

		  is_it_forbidden_channel_tab(ic , nc) = is_it_forbidden_channel;

		  if (is_it_forbidden_channel) continue;
		  
		  for (unsigned int icp = 0 ; icp <= ic ; icp++)
		    {
		      const class CC_channel_class &channel_cp = channels_tab(icp);

		      const enum particle_type particle_cp = channel_cp.get_projectile ();

		      const complex<double> E_Tcp = channel_cp.get_E_Tc ();

		      const complex<double> average_n_scat_Tcp = channel_cp.get_average_n_scat_Tc ();

		      const class nucleons_data &data_tau_cp = (particle_cp == PROTON) ? (prot_data) : (neut_data);

		      const int Z_Tcp = channel_cp.get_Z_Tc ();
		      const int N_Tcp = channel_cp.get_N_Tc ();

		      const class lj_table<int> &nmax_lj_cp = data_tau_cp.get_nmax_lj_tab ();

		      const double jcp = channel_cp.get_J_projectile ();

		      const double J_Tcp = channel_cp.get_J_Tc ();

		      const double real_average_n_scat_Tcp = real (average_n_scat_Tcp);

		      const int lcp = channel_cp.get_LCM_projectile ();

		      const int nmax_cp = nmax_lj_cp(lcp , jcp);

		      const int nmax_cp_nc = (icp < ic) ? (nmax_cp) : (nc - 1);

		      const unsigned int BP_Tcp = channel_cp.get_BP_Tc ();

		      const unsigned int vector_index_Tcp = channel_cp.get_vector_index_Tc ();

		      const class nlj_table<bool> &is_it_valence_shell_tab_cp = data_tau_cp.get_is_it_valence_shell_tab ();

		      const class nlj_table<unsigned int> &shells_indices_cp = data_tau_cp.get_shells_indices ();

		      const class array<class nlj_struct> &shells_qn_cp = data_tau_cp.get_shells_quantum_numbers ();

		      class correlated_state_str PSI_qn_Tcp (Z_Tcp , N_Tcp , BP_Tcp , J_Tcp , vector_index_Tcp , E_Tcp , NADA , NADA , NADA , false);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
		      for (int ncp = 0 ; ncp <= nmax_cp_nc ; ncp++) 
			{
			  if (is_it_valence_shell_tab_cp(ncp , lcp , jcp))
			    {
			      const unsigned int shell_index_cp = shells_indices_cp(ncp , lcp , jcp);

			      const class nlj_struct &shell_qn_cp = shells_qn_cp(shell_index_cp);

			      const bool S_matrix_pole_ncp = shell_qn_cp.get_S_matrix_pole ();

			      const double real_average_n_scat_cp = (!S_matrix_pole_ncp) ? (real_average_n_scat_Tcp + 1) : (real_average_n_scat_Tcp);

			      if (real_average_n_scat_cp < CC_average_n_scat_target_projectile_max)
				{	
				  const string a_dagger_nucleon_PSI_cp_coupled_file_name = PSI_OUT_coupled_to_J_file_name_a_dagger_nucleon_determine (false , "a_dagger_nucleon" , ncp , lcp , jcp , particle_cp , PSI_qn_Tcp , J , M);

				  const unsigned int this_thread = OpenMP_thread_number_determine ();

				  class GSM_vector &V_out = V_out_tab(this_thread);

				  V_out.read_disk (false , false , a_dagger_nucleon_PSI_cp_coupled_file_name);
				      
				  overlaps(ic , nc  , icp , ncp) = GSM_vector_node_overlap (V_in , V_out);
				}}}}}}}
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized) overlaps.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
#endif
    
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type particle_c = channel_c.get_projectile ();

      const class nucleons_data &data_tau_c = (particle_c == PROTON) ? (prot_data) : (neut_data);

      const int Z_Tc = channel_c.get_Z_Tc ();
      const int N_Tc = channel_c.get_N_Tc ();
      
      const double jc = channel_c.get_J_projectile ();

      const double J_Tc = channel_c.get_J_Tc ();

      const class lj_table<int> &nmax_lj_c = data_tau_c.get_nmax_lj_tab ();

      const int lc = channel_c.get_LCM_projectile ();

      const int nmax_c = nmax_lj_c(lc , jc);

      const unsigned int BP_Tc = channel_c.get_BP_Tc ();

      const unsigned int vector_index_Tc = channel_c.get_vector_index_Tc ();

      const string Tc_str = "Target[c] : Z:" + make_string<int> (Z_Tc) + " N:" + make_string<int> (N_Tc) + " " + J_Pi_vector_index_string (BP_Tc , J_Tc , vector_index_Tc);

      if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl << "ic:" << ic << " channel : "<< channel_c << " nmax : " << nmax_c << endl;
	  
      for (int nc = 0 ; nc <= nmax_c ; nc++)
	{
	  for (unsigned int icp = 0 ; icp <= ic ; icp++)
	    {
	      if (!is_it_forbidden_channel_tab(ic , nc))
		{
		  const class CC_channel_class &channel_cp = channels_tab(icp);

		  const enum particle_type particle_cp = channel_cp.get_projectile ();

		  const class nucleons_data &data_tau_cp = (particle_cp == PROTON) ? (prot_data) : (neut_data);

		  const class lj_table<int> &nmax_lj_cp = data_tau_cp.get_nmax_lj_tab ();

		  const double jcp = channel_cp.get_J_projectile ();

		  const int lcp = channel_cp.get_LCM_projectile ();

		  const int nmax_cp = nmax_lj_cp(lcp , jcp);

		  const int nmax_cp_nc = (icp < ic) ? (nmax_cp) : (nc - 1);

		  for (int ncp = 0 ; ncp <= nmax_cp_nc ; ncp++) 
		    {
		      const complex<double> &overlap = overlaps(ic , nc , icp , ncp);
		  
		      if (inf_norm (overlap - 1.0) < CC_forbidden_channel_precision) is_it_forbidden_channel_tab(ic , nc) = true;
		    }
		}
	    }
      
	  if ((THIS_PROCESS == MASTER_PROCESS) && is_it_forbidden_channel_tab(ic , nc)) cout << endl << "[a+(" << particle_c << " " << nc << angular_state (lc , jc) << ") " << Tc_str << "]^(" << J_Pi_string (BP , J) << ") forbidden" << endl << endl;
	}
    }

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      const string is_it_forbidden_channel_tab_file_name = file_name_J_Pi_string ("CC_is_it_forbidden_channel_tab" , BP , J);

      is_it_forbidden_channel_tab.copy_disk (is_it_forbidden_channel_tab_file_name);

      if (print_detailed_information)
	{
	  const double now = absolute_time_determine () , relative_time = now - reference_time; 

	  cout << endl << "forbidden channels one nucleon time:" << relative_time << " s" << endl << endl;
	}
    }
}











void CC_H_a_dagger_nucleon_forbidden_channels::H_a_dagger_nucleon_calculations_and_copy_disk (
											      const bool print_detailed_information ,
											      const double CC_average_n_scat_target_projectile_max , 
											      const class array<class CC_channel_class> &channels_tab , 
											      const class nucleons_data &prot_data , 
											      const class nucleons_data &neut_data , 
											      const class array<bool> &is_it_forbidden_channel_tab , 
											      const double J , 
											      const class J2_class &J2 , 
											      const class H_class &H , 
											      class GSM_vector &a_dagger_nucleon_PSI_c_coupled , 
											      class GSM_vector &H_a_dagger_nucleon_PSI_c_coupled) 
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "H[a+(projectile) |target>] one nucleon calculation" << endl;
      cout         << "--------------------------------------------------" << endl << endl;
    }

  const unsigned int N_channels = channels_tab.dimension (0);

  const class GSM_vector_helper_class &GSM_vector_helper = a_dagger_nucleon_PSI_c_coupled.get_GSM_vector_helper ();

  const double M = GSM_vector_helper.get_M ();

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const complex<double> E_Tc = channel_c.get_E_Tc ();

      const complex<double> average_n_scat_Tc = channel_c.get_average_n_scat_Tc ();

      const enum particle_type particle_c = channel_c.get_projectile ();

      const class nucleons_data &data_tau_c = (particle_c == PROTON) ? (prot_data) : (neut_data);

      const int Z_Tc = channel_c.get_Z_Tc ();
      const int N_Tc = channel_c.get_N_Tc ();

      const class lj_table<int> &nmax_lj_c = data_tau_c.get_nmax_lj_tab ();

      const double jc = channel_c.get_J_projectile ();

      const double J_Tc = channel_c.get_J_Tc ();

      const double real_average_n_scat_Tc = real (average_n_scat_Tc);

      const int lc = channel_c.get_LCM_projectile ();

      const int nmax_c = nmax_lj_c(lc , jc);

      const unsigned int BP_Tc = channel_c.get_BP_Tc ();

      const unsigned int vector_index_Tc = channel_c.get_vector_index_Tc () , BP = channel_c.get_BP ();

      const class nlj_table<bool> &is_it_valence_shell_tab_c = data_tau_c.get_is_it_valence_shell_tab ();

      const class nlj_table<unsigned int> &shells_indices_c = data_tau_c.get_shells_indices ();

      const class array<class nlj_struct> &shells_qn_c = data_tau_c.get_shells_quantum_numbers ();

      const string Tc_str = "Target[c] : Z:" + make_string<int> (Z_Tc) + " N:" + make_string<int> (N_Tc) + " " + J_Pi_vector_index_string (BP_Tc , J_Tc , vector_index_Tc);

      if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl << "ic:" << ic << " channel : "<< channel_c << " nmax : " << nmax_c << endl << endl;

      const class correlated_state_str PSI_qn_Tc(Z_Tc , N_Tc , BP_Tc , J_Tc , vector_index_Tc , E_Tc , NADA , NADA , NADA , false);

      for (int nc = 0 ; nc <= nmax_c ; nc++) 
	{
	  if (is_it_valence_shell_tab_c(nc , lc , jc))
	    {
	      const unsigned int shell_index_c = shells_indices_c(nc , lc , jc);
	      
	      const class nlj_struct &shell_qn_c = shells_qn_c(shell_index_c);

	      const bool S_matrix_pole_nc = shell_qn_c.get_S_matrix_pole ();

	      const double real_average_n_scat_c = (!S_matrix_pole_nc) ? (real_average_n_scat_Tc + 1) : (real_average_n_scat_Tc);

	      if (!is_it_forbidden_channel_tab(ic , nc) && (real_average_n_scat_c < CC_average_n_scat_target_projectile_max))
		{
		  const double reference_time = absolute_time_determine ();

		  const string a_dagger_nucleon_PSI_c_coupled_file_name = PSI_OUT_coupled_to_J_file_name_a_dagger_nucleon_determine (false , "a_dagger_nucleon" , nc , lc , jc , particle_c , PSI_qn_Tc , J , M);

		  a_dagger_nucleon_PSI_c_coupled.read_disk (false , false , a_dagger_nucleon_PSI_c_coupled_file_name);

		  H_a_dagger_nucleon_PSI_c_coupled = H*a_dagger_nucleon_PSI_c_coupled;

		  class GSM_vector &Vstore = a_dagger_nucleon_PSI_c_coupled;

		  const double J_coupling_precision = J2.J_coupling_precision_calc (H_a_dagger_nucleon_PSI_c_coupled , J , Vstore);

		  const double now = absolute_time_determine () , relative_time = now - reference_time; 

		  if (print_detailed_information || (J_coupling_precision > sqrt_precision))
		    {
		      cout << "H[a+(" << particle_c << " " << nc << angular_state (lc , jc) << ") ";
		      
		      cout << Tc_str << "]^(" << J_Pi_string (BP , J) << ") calculated , J^2 precision:" << J_coupling_precision << " time:" << relative_time << " s" << endl;
		      
		      if (J_coupling_precision > sqrt_precision) error_message_print_abort ("The composite state is not coupled to J in CC_H_a_dagger_nucleon_forbidden_channels::H_a_dagger_nucleon_calculations_and_copy_disk");
		    }
		  
		  const string H_a_dagger_nucleon_PSI_c_coupled_file_name = PSI_OUT_coupled_to_J_file_name_a_dagger_nucleon_determine (false , "H_a_dagger_nucleon" , nc , lc , jc , particle_c , PSI_qn_Tc , J , M);
		  
		  H_a_dagger_nucleon_PSI_c_coupled.copy_disk (false , false , H_a_dagger_nucleon_PSI_c_coupled_file_name);
		}
	    }
	}
    }

  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl;
}






