#include "../CC_include/CC_include_def.h"

using namespace string_routines;
using namespace inputs_misc;
using namespace Wigner_signs;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_multipoles_MEs;
using namespace CC_multipoles_MEs::radial;
using namespace CC_observables_common;



// TYPE is double or complex
// -------------------------




// Calculation of the GSM-multipole transition matrix elements between two channel wave functions
// ----------------------------------------------------------------------------------------------
// One calculates <J[f] | GSM-multipole |J[i]>, where GSM-multipole = \sum (Yl r^l).(Yl'.r'^l).

// For this, one uses the decomposition <J[f] | GSM-multipole |J[i]> = <J[f] | GSM-multipole |J[i]> [nas] + (<J[f] | GSM-multipole |J[i]> [as-HO] - <J[f] | GSM-multipole |J[i]> [nas-HO]),
// where as means antisymmetrized channel functions and nas non-antisymmetrized channel functions.
// It is indeed impossible to calculate matrix elements with antisymmetrized channel functions directly because channel wave functions have two-body asymptotes, where target and projectile are not antisymmetrized.
//
// In nas, target and projectile arise from GSM and GSM-CC calculations but are not antisymmetrized with respect to each other in matrix elements formulas.
// One has GSM-multipole = GSM-multipole[projectile] + GSM-multipole[target], so that one calculates separately the matrix elements of GSM-multipole[projectile] and GSM-multipole[target].
// nas matrix elements <J[f] | GSM-multipole[target or projectile] | J[i]> = sum_{c[f], c[i]} <J[f] c[f] | GSM-multipole[target or projectile] | J[i] c[i]>.
// <J[f] c[f] | GSM-multipole[target or projectile] | J[i] c[i]> are then straightforward to calculate from <JT[f] c[f] | GSM-multipole[target] or Id | JT[i] c[i]> and <Jp[f] | GSM-multipole[projectile] or Id | Jp[i]>.
// <JT[f] c[f] | GSM-multipole[target] | JT[i] c[i]> are given by shell model formulas and <Jp[f] | GSM-multipole[projectile] | Jp[i]> are calculated in CC_multipoles_MEs.
// nas-HO is the same as nas except that channel wave functions and targets are all projected in the HO basis.
//
// In as, target and projectile are antisymmetrized in the HO basis : one projects all target and projectile states in the HO basis, so that antisymmetrization is handled with Slater determinants.
// Matrix elements of GSM-multipole in as are then given by shell model formulas.
//
// As antisymmetrization effects between target and projectile only occur close to the target, it is sufficient to use the HO basis therein (as[HO]).
// The two-body asymptote is taken into account in the non-antisymmetrized calculation.
// It is clear that as, as-HO and nas, nas-HO matrix elements are equal at the limit of infinite HO basis.
// The previous decomposition is thus justified.

TYPE CC_multipoles_poles::calc (  
				const int L ,
				const bool is_it_HO_expansion , 
				const bool is_it_nas_only , 
				const class CC_target_projectile_composite_data &Tpc_data , 
				const class input_data_str &input_data_CC_Berggren , 
				const class interaction_class &inter_data_basis ,  
				const class array<class cluster_data> &cluster_projectile_data_tab , 
				const class CC_Hamiltonian_data &CC_H_data , 
				const class CC_state_class &CC_state , 
				class baryons_data &prot_Y_data , 
				class baryons_data &neut_Y_data ,
				class GSM_vector &PSI_full)
{
  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();
  
  const bool full_common_vectors_used_in_file = input_data_CC_Berggren.get_full_common_vectors_used_in_file ();

  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();

  const enum storage_type Hamiltonian_storage = input_data_CC_Berggren.get_Hamiltonian_storage ();

  const bool is_it_full_or_partial_storage = is_it_full_or_partial_storage_determine (Hamiltonian_storage);
  
  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();

  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const int Z_cluster_max = (!is_it_one_baryon_COSM_case) ? (Z_cluster_max_determine (cluster_projectile_data_tab)) : (1);
  const int N_cluster_max = (!is_it_one_baryon_COSM_case) ? (N_cluster_max_determine (cluster_projectile_data_tab)) : (1);

  const int Z_cluster_number = Z_cluster_max + 1;
  const int N_cluster_number = N_cluster_max + 1;

  class array<class baryons_data> prot_Y_data_one_projectile_less_tab(Z_cluster_number , N_cluster_number , 2);
  class array<class baryons_data> neut_Y_data_one_projectile_less_tab(Z_cluster_number , N_cluster_number , 2);

  data_one_projectile_less_alloc_calc (is_it_full_or_partial_storage , is_it_one_baryon_COSM_case , TBME_inter , truncation_hw , truncation_ph , prot_Y_data , neut_Y_data , projectile_tab , cluster_projectile_data_tab ,
				       prot_Y_data_one_projectile_less_tab , neut_Y_data_one_projectile_less_tab);

  class array<TYPE> target_NBMEs(N_target_projectile_states , N_target_projectile_states);
  
  target_NBMEs = 0.0;

  composite::target_NBMEs_calc (PSI_full , TBME_inter , L , is_it_HO_expansion , full_common_vectors_used_in_file ,
				Tpc_data , prot_Y_data_one_projectile_less_tab , neut_Y_data_one_projectile_less_tab , target_NBMEs);

  const TYPE CC_multipole_square_valence = composite::CC_NBME_calc (L , is_it_HO_expansion , is_it_nas_only , Tpc_data , cluster_projectile_data_tab , 
								    CC_H_data , CC_state , prot_Y_data , neut_Y_data , input_data_CC_Berggren , target_NBMEs , PSI_full);

  return CC_multipole_square_valence;
}



// Calculation and print of the beta transitions <J[f] | GSM-multipole | J[i]> for all the beta transitions listed in the input file
// ----------------------------------------------------------------------------------------------------------------------------------
// The decomposition <J[f] | GSM-multipole | J[i]> = <J[f] | GSM-multipole | J[i]> [nas] + (<J[f] | GSM-multipole | J[i]> [as-HO] - <J[f] | GSM-multipole | J[i]> [nas-HO]) is used here (see above).
// One also prints <J[f] | GSM-multipole | J[i]> = <J[f] | GSM-multipole | J[i]> [nas] only.

void CC_multipoles_poles::calc_print (
				      const class input_data_str &input_data , 
				      const class input_data_str &input_data_CC_Berggren ,  
				      const class interaction_class &inter_data_basis ,
				      const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
				      const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
				      class baryons_data &prot_Y_data_CC_Berggren , 
				      class baryons_data &neut_Y_data_CC_Berggren , 
				      class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
				      class baryons_data &prot_Y_data , 
				      class baryons_data &neut_Y_data , 
				      class array<class cluster_data> &cluster_projectile_data_tab , 
				      class CC_target_projectile_composite_data &Tpc_data , 
				      class TBMEs_class &TBMEs_pn , 
				      class TBMEs_class &TBMEs_cv)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "CC multipoles" << endl;
      cout <<         "-------------" << endl << endl;
    }

  const int Z = input_data.get_Z ();
  const int N = input_data.get_N ();
  const int A = input_data.get_A ();
 
  const int S = input_data.get_hypernucleus_strangeness ();
  
  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();

  const unsigned int N_bef_R_uniform = input_data_CC_Berggren.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = input_data_CC_Berggren.get_N_aft_R_uniform ();

  const unsigned int N_bef_R_GL = input_data_CC_Berggren.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = input_data_CC_Berggren.get_N_aft_R_GL ();

  const unsigned int Nk_momentum_GL = input_data_CC_Berggren.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = input_data_CC_Berggren.get_Nk_momentum_uniform ();
  
  const double R_real_max = input_data_CC_Berggren.get_R_real_max ();

  const double R = input_data_CC_Berggren.get_R ();

  const double kmax_momentum = input_data_CC_Berggren.get_kmax_momentum ();

  const double R_Fermi_momentum = input_data_CC_Berggren.get_R_Fermi_momentum ();
  
  const double R0_inter = inter_data_basis.get_R0 ();

  const double R0 = 1.27*cbrt (A);

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);

  const class array<unsigned int> &N_channels_tab = Tpc_data.get_N_channels_tab ();

  const class array<unsigned int> &BP_A_tab = Tpc_data.get_BP_A_tab (); 

  const class array<double> &J_A_tab = Tpc_data.get_J_A_tab ();

  const class array<class CC_channel_class> &channels_tab = Tpc_data.get_channels_tab ();

  const unsigned int CC_multipoles_number = input_data.get_GSM_multipoles_number ();
  
  const class array<int> &CC_multipoles_L_tab = input_data.get_GSM_multipoles_L_tab ();
  
  const class array<unsigned int> &CC_multipoles_BP_tab = input_data.get_GSM_multipoles_BP_tab ();

  const class array<double> &CC_multipoles_J_tab = input_data.get_GSM_multipoles_J_tab ();

  const class array<unsigned int> &CC_multipoles_vector_index_tab = input_data.get_GSM_multipoles_vector_index_tab (); 
  
  const class array<bool> &CC_multipoles_is_it_HO_expansion_tab = input_data.get_GSM_multipoles_is_it_HO_expansion_tab (); 

  class GSM_vector PSI_full;
  
  for (unsigned int CC_multipole_index = 0 ; CC_multipole_index < CC_multipoles_number ; CC_multipole_index++)
    {
      const int L = CC_multipoles_L_tab(CC_multipole_index);
      
      const bool is_it_HO_expansion = CC_multipoles_is_it_HO_expansion_tab(CC_multipole_index);

      const string HO_expansion_string = (is_it_HO_expansion) ? ("HO expansion") : ("R cut"); 

      const unsigned int BP = CC_multipoles_BP_tab(CC_multipole_index);

      const unsigned int vector_index = CC_multipoles_vector_index_tab(CC_multipole_index);

      const double J = CC_multipoles_J_tab(CC_multipole_index);

      const double M = J;
      
      class correlated_state_str PSI_qn(Z , N , BP , S , J , vector_index , NADA , NADA , NADA , NADA , false);

      const unsigned int iJPi = JPi_index_determine (S , BP_A_tab , J_A_tab , BP , J);

      const unsigned int N_channels_JPi = N_channels_tab(iJPi);

      class array<class CC_channel_class> channels_JPi_tab (N_channels_JPi);

      JPi_channels_tab_BP_J_vector_index_E_fill (S , channels_tab , BP , J , vector_index , NADA , channels_JPi_tab);

      class CC_state_class CC_state (is_it_one_baryon_COSM_case , nmax_HO_lab_tab , cluster_projectile_data_tab , true , true , N_channels_JPi ,
				     NADA , channels_JPi_tab , N_bef_R_uniform , N_aft_R_uniform , N_bef_R_GL , N_aft_R_GL , Nk_momentum_uniform , Nk_momentum_GL ,
				     R , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , A , BP , J , M , vector_index , NADA);

      class CC_Hamiltonian_data CC_H_data(N_channels_JPi , input_data_CC_Berggren);
	    
      CC_eigenstate_H_data_calc (Tpc_data , inter_data_basis , input_data_CC_Berggren , 
				 prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab , 
				 prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , prot_Y_data , neut_Y_data , PSI_qn , TBMEs_pn , TBMEs_cv , CC_H_data , CC_state);

      const complex<double> CC_multipole_nas = calc (L , is_it_HO_expansion , true , Tpc_data , input_data_CC_Berggren ,
						     inter_data_basis , cluster_projectile_data_tab , CC_H_data , CC_state , prot_Y_data , neut_Y_data , PSI_full);

      const complex<double> CC_multipole_as = calc (L , is_it_HO_expansion , false , Tpc_data , input_data_CC_Berggren ,
						    inter_data_basis , cluster_projectile_data_tab , CC_H_data , CC_state , prot_Y_data , neut_Y_data , PSI_full);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  cout << J_Pi_vector_index_string (BP , J , vector_index) << " : L=" << L << " non-antisymmetrized CC multipole with " << HO_expansion_string << " : ";
	  
	  cout << CC_multipole_nas << " antisymmetrized CC multipole with " << HO_expansion_string << " : " << CC_multipole_as << endl;
	}
    }
}


