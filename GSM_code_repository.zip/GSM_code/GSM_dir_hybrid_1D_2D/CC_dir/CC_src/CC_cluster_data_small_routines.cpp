#include "../CC_include/CC_include_def.h"


int CC_cluster_data_small_routines::Nmax_HO_clusters_calc (const class array<class cluster_data> &cluster_projectile_data_tab)
{
  const unsigned int cluster_projectile_number = cluster_projectile_data_tab.dimension (0);

  int Nmax_HO_clusters = 0;

  for (unsigned int cluster_index_c = 0 ; cluster_index_c < cluster_projectile_number ; cluster_index_c++)
    {
      const class cluster_data &data_c = cluster_projectile_data_tab(cluster_index_c);

      const class array<int> &Nmax_HO_tab = data_c.get_Nmax_HO_tab ();

      Nmax_HO_clusters = max (Nmax_HO_clusters , nmax_calc (Nmax_HO_tab));
    }

  return Nmax_HO_clusters;
}

unsigned int CC_cluster_data_small_routines::cluster_data_index_determine (
									   const enum particle_type cluster ,
									   const class array<class cluster_data> &cluster_projectile_data_tab)
{
  const unsigned int cluster_projectile_number = cluster_projectile_data_tab.dimension (0);

  for (unsigned int cluster_index_c = 0 ; cluster_index_c < cluster_projectile_number ; cluster_index_c++)
    {
      const class cluster_data &data_c = cluster_projectile_data_tab(cluster_index_c);

      if (!data_c.is_it_filled ()) error_message_print_abort ("cluster_projectile_data_tab structures have not all been allocated in CC_cluster_data_small_routines::cluster_data_index_determine");

      const enum particle_type cluster_c = data_c.get_cluster ();

      if (cluster_c == cluster) return cluster_index_c;
    }

  error_message_print_abort ("No cluster_data structure found for cluster " + make_string<enum particle_type> (cluster) + " in CC_cluster_data_small_routines::cluster_data_index_determine");

  return NADA;
}

unsigned int CC_cluster_data_small_routines::cluster_data_index_determine (
									   const enum particle_type cluster ,
									   const class array<enum particle_type> &CC_cluster_tab)
{
  const unsigned int cluster_projectile_number = CC_cluster_tab.dimension (0);

  for (unsigned int cluster_index_c = 0 ; cluster_index_c < cluster_projectile_number ; cluster_index_c++)
    {
      const enum particle_type cluster_c = CC_cluster_tab(cluster_index_c); 

      if (cluster_c == cluster) return cluster_index_c;
    }

  error_message_print_abort ("No cluster_data structure found for cluster " + make_string<enum particle_type> (cluster) + " in CC_cluster_data_small_routines::cluster_data_index_determine");

  return NADA;
}


unsigned int CC_cluster_data_small_routines::first_cluster_data_index_determine (
										 const enum particle_type cluster ,
										 const class array<enum particle_type> &CC_cluster_tab)
{
  const int Z_cluster = Z_cluster_determine (cluster);
  const int N_cluster = N_cluster_determine (cluster);

  const unsigned int BP_intrinsic = BP_intrinsic_cluster_determine (cluster);

  const double J_intrinsic = J_intrinsic_cluster_determine (cluster);
  
  const unsigned int cluster_projectile_number = CC_cluster_tab.dimension (0);

  for (unsigned int cluster_index_c = 0 ; cluster_index_c < cluster_projectile_number ; cluster_index_c++)
    {
      const enum particle_type cluster_c = CC_cluster_tab(cluster_index_c); 

      const int Z_cluster_c = Z_cluster_determine (cluster_c);
      const int N_cluster_c = N_cluster_determine (cluster_c);

      const unsigned int BP_intrinsic_c = BP_intrinsic_cluster_determine (cluster_c);
  
      const double J_intrinsic_c = J_intrinsic_cluster_determine (cluster_c);

      if ((Z_cluster == Z_cluster_c) && (N_cluster == N_cluster_c) && same_BP_J (BP_intrinsic , J_intrinsic , BP_intrinsic_c , J_intrinsic_c)) return cluster_index_c;
    }

  error_message_print_abort ("No cluster_data structure found for cluster " + make_string<enum particle_type> (cluster) + " in CC_cluster_data_small_routines::first_cluster_data_index_determine");

  return NADA; 
}



const class cluster_data & CC_cluster_data_small_routines::get_cluster_projectile_data (
									     const enum particle_type cluster ,
									     const class array<class cluster_data> &cluster_projectile_data_tab)
{
  const unsigned int cluster_projectile_number = cluster_projectile_data_tab.dimension (0);

  for (unsigned int cluster_index_c = 0 ; cluster_index_c < cluster_projectile_number ; cluster_index_c++)
    {
      const class cluster_data &data_c = cluster_projectile_data_tab(cluster_index_c);

      if (!data_c.is_it_filled ()) error_message_print_abort ("cluster_projectile_data_tab structures have not all been allocated in CC_cluster_data_small_routines::get_cluster_projectile_data (const)");

      const enum particle_type cluster_c = data_c.get_cluster ();

      if (cluster_c == cluster) return data_c;
    }

  error_message_print_abort ("No cluster_data structure found for cluster " + make_string<enum particle_type> (cluster) + " in CC_cluster_data_small_routines::get_cluster_projectile_data (const)");

  return cluster_projectile_data_tab(0);
}




class cluster_data & CC_cluster_data_small_routines::get_cluster_projectile_data (
								       const enum particle_type cluster ,
								       class array<class cluster_data> &cluster_projectile_data_tab)
{
  const unsigned int cluster_projectile_number = cluster_projectile_data_tab.dimension (0);

  for (unsigned int cluster_index_c = 0 ; cluster_index_c < cluster_projectile_number ; cluster_index_c++)
    {
      class cluster_data &data_c = cluster_projectile_data_tab(cluster_index_c);

      if (!data_c.is_it_filled ()) error_message_print_abort ("cluster_projectile_data_tab structures have not all been allocated in CC_cluster_data_small_routines::get_cluster_projectile_data (not const)");

      const enum particle_type cluster_c = data_c.get_cluster ();

      if (cluster_c == cluster) return data_c;
    }

  error_message_print_abort ("No cluster_data structure found for cluster " + make_string<enum particle_type> (cluster) + " in CC_cluster_data_small_routines::get_cluster_projectile_data (not const)");

  return cluster_projectile_data_tab(0);
}










const class cluster_data & CC_cluster_data_small_routines::get_first_cluster_data (
										   const enum particle_type cluster ,
										   const class array<class cluster_data> &cluster_projectile_data_tab)
{
  const int Z_cluster = Z_cluster_determine (cluster);
  const int N_cluster = N_cluster_determine (cluster);

  const unsigned int BP_intrinsic = BP_intrinsic_cluster_determine (cluster);

  const double J_intrinsic = J_intrinsic_cluster_determine (cluster);
  
  const unsigned int cluster_projectile_number = cluster_projectile_data_tab.dimension (0);

  for (unsigned int cluster_index_c = 0 ; cluster_index_c < cluster_projectile_number ; cluster_index_c++)
    {
      const class cluster_data &data_c = cluster_projectile_data_tab(cluster_index_c);

      if (!data_c.is_it_filled ()) error_message_print_abort ("cluster_projectile_data_tab structures have not all been allocated in CC_cluster_data_small_routines::get_first_cluster_data (const)");

      const enum particle_type cluster_c = data_c.get_cluster ();

      const int Z_cluster_c = Z_cluster_determine (cluster_c);
      const int N_cluster_c = N_cluster_determine (cluster_c);

      const unsigned int BP_intrinsic_c = BP_intrinsic_cluster_determine (cluster_c);
  
      const double J_intrinsic_c = J_intrinsic_cluster_determine (cluster_c);

      if ((Z_cluster == Z_cluster_c) && (N_cluster == N_cluster_c) && same_BP_J (BP_intrinsic , J_intrinsic , BP_intrinsic_c , J_intrinsic_c)) return data_c;
    }

  error_message_print_abort ("No cluster_data structure found for cluster " + make_string<enum particle_type> (cluster) + " in CC_cluster_data_small_routines::get_first_cluster_data (const)");

  return cluster_projectile_data_tab(0);
}




class cluster_data & CC_cluster_data_small_routines::get_first_cluster_data (
									     const enum particle_type cluster ,
									     class array<class cluster_data> &cluster_projectile_data_tab)
{
  const int Z_cluster = Z_cluster_determine (cluster);
  const int N_cluster = N_cluster_determine (cluster);

  const unsigned int BP_intrinsic = BP_intrinsic_cluster_determine (cluster);

  const double J_intrinsic = J_intrinsic_cluster_determine (cluster);
  
  const unsigned int cluster_projectile_number = cluster_projectile_data_tab.dimension (0);

  for (unsigned int cluster_index_c = 0 ; cluster_index_c < cluster_projectile_number ; cluster_index_c++)
    {
      class cluster_data &data_c = cluster_projectile_data_tab(cluster_index_c);

      if (!data_c.is_it_filled ()) error_message_print_abort ("cluster_projectile_data_tab structures have not all been allocated in CC_cluster_data_small_routines::get_first_cluster_data (not const)");

      const enum particle_type cluster_c = data_c.get_cluster ();

      const int Z_cluster_c = Z_cluster_determine (cluster_c);
      const int N_cluster_c = N_cluster_determine (cluster_c);

      const unsigned int BP_intrinsic_c = BP_intrinsic_cluster_determine (cluster_c);
  
      const double J_intrinsic_c = J_intrinsic_cluster_determine (cluster_c);

      if ((Z_cluster == Z_cluster_c) && (N_cluster == N_cluster_c) && same_BP_J (BP_intrinsic , J_intrinsic , BP_intrinsic_c , J_intrinsic_c)) return data_c;
    }

  error_message_print_abort ("No cluster_data structure found for cluster " + make_string<enum particle_type> (cluster) + " in CC_cluster_data_small_routines::get_first_cluster_data (not const)");

  return cluster_projectile_data_tab(0);
}


int CC_cluster_data_small_routines::Z_cluster_max_determine (const class array<class cluster_data> &cluster_projectile_data_tab)
{
  const unsigned int cluster_projectile_number = cluster_projectile_data_tab.dimension (0);

  int Z_cluster_max = 0;

  for (unsigned int cluster_index_c  = 0 ; cluster_index_c < cluster_projectile_number ; cluster_index_c++)
    {
      const class cluster_data &data = cluster_projectile_data_tab(cluster_index_c);

      const int Z_cluster = data.get_Z_cluster ();

      Z_cluster_max = max (Z_cluster , Z_cluster_max);
    }

  return Z_cluster_max;
}



int CC_cluster_data_small_routines::N_cluster_max_determine (const class array<class cluster_data> &cluster_projectile_data_tab)
{
  const unsigned int cluster_projectile_number = cluster_projectile_data_tab.dimension (0);

  int N_cluster_max = 0;

  for (unsigned int cluster_index_c  = 0 ; cluster_index_c < cluster_projectile_number ; cluster_index_c++)
    {
      const class cluster_data &data = cluster_projectile_data_tab(cluster_index_c);

      const int N_cluster = data.get_N_cluster ();

      N_cluster_max = max (N_cluster , N_cluster_max);
    }

  return N_cluster_max;
}





int CC_cluster_data_small_routines::nmax_all_determine (
							const bool is_it_one_nucleon_COSM_case , 
							const class array<class CC_channel_class> &channels_tab , 
							const class nucleons_data &prot_data , 
							const class nucleons_data &neut_data , 
							const class array<class cluster_data> &cluster_projectile_data_tab)
{
  if (is_it_one_nucleon_COSM_case)
    {
      const int nmax_p = prot_data.get_nmax ();
      const int nmax_n = neut_data.get_nmax ();

      const int nmax_all = max (nmax_p , nmax_n);

      return nmax_all;
    }
  else
    {
      const unsigned int N_channels = channels_tab.dimension (0);

      int nmax_all = 0;

      for (unsigned int cluster_index_c = 0 ; cluster_index_c < N_channels ; cluster_index_c++)
	{
	  const class CC_channel_class &channel_c = channels_tab(cluster_index_c);

	  const enum particle_type cluster_c = channel_c.get_projectile ();

	  const int LCM_projectile_c = channel_c.get_LCM_projectile ();

	  const double J_projectile_c = channel_c.get_J_projectile ();

	  const class cluster_data &data_c = get_cluster_projectile_data (cluster_c , cluster_projectile_data_tab);

	  const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c = data_c.get_Nmax_cluster_projectile_CM_tab ();

	  const int NCM_max_LCM_projectile_c = Nmax_cluster_projectile_CM_tab_c(LCM_projectile_c , J_projectile_c);

	  nmax_all = max (nmax_all , NCM_max_LCM_projectile_c);
	}

      return nmax_all;
    }
}



void CC_cluster_data_small_routines::cluster_projectile_data_tab_alloc_calc (
								  const bool is_it_GSM_basis , 
								  const bool is_it_CM_HO_basis , 
								  class input_data_str &input_data , 
								  const class nucleons_data &prot_data , 
								  const class nucleons_data &neut_data , 
								  const class interaction_class &inter_data_basis , 
								  class array<class cluster_data> &cluster_projectile_data_tab)
{
  const bool is_there_cout = true;

  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  const class array<enum particle_type> &CC_cluster_projectile_tab = input_data.get_CC_cluster_projectile_tab ();

  const unsigned int CC_cluster_projectile_number = input_data.get_CC_cluster_projectile_number ();

  for (unsigned int cluster_index_c = 0 ; cluster_index_c < CC_cluster_projectile_number ; cluster_index_c++)
    {
      const enum particle_type cluster_c = CC_cluster_projectile_tab(cluster_index_c); 

      const unsigned int cluster_index_c_first_cluster = first_cluster_data_index_determine (cluster_c , CC_cluster_projectile_tab);

      const bool are_cluster_first_cluster_CM_bases_identical = input_data.are_cluster_CM_bases_identical (cluster_index_c , cluster_index_c_first_cluster);

      const bool is_first_cluster_used = (are_cluster_first_cluster_CM_bases_identical && (cluster_index_c_first_cluster != cluster_index_c));
      
      const class cluster_data &first_cluster_data = cluster_projectile_data_tab(cluster_index_c_first_cluster);
	  
      class cluster_data &data_c = cluster_projectile_data_tab(cluster_index_c);
      
      if (is_first_cluster_used)
	data_c.allocate (is_it_CM_HO_basis , input_data , prot_data , neut_data , inter_data_basis , first_cluster_data , cluster_index_c);
      else
	data_c.allocate (is_there_cout , is_it_GSM_basis , is_it_CM_HO_basis , input_data , prot_data , neut_data , inter_data_basis , cluster_index_c);
	
      const int Z_cluster = data_c.get_Z_cluster ();
      const int N_cluster = data_c.get_N_cluster ();

      const enum space_type basis_space_init = input_data.get_basis_space ();

      const enum space_type basis_space_cluster = space_determine (Z_cluster , N_cluster);

      input_data.set_basis_space (basis_space_cluster);
      
      cluster_CM_Berggren_basis::radial_wfs_overlaps_print_HO_overlaps_alloc_calc (is_there_cout , is_first_cluster_used , inter_data_basis , first_cluster_data , data_c);

      if (is_it_GSM_basis) cluster_CM_intrinsic_basis_states::Berggren_basis_states_calc_store (is_there_cout , input_data , nmax_HO_lab_tab , data_c);
	  
      if (!is_it_CM_HO_basis) data_c.PCM_matrices_cluster_calc ();

      input_data.set_basis_space (basis_space_init);
    }
}






void CC_cluster_data_small_routines::cluster_projectile_data_tab_PCM_matrices_alloc_calc ( 
									       const class interaction_class &inter_data_basis , 
									       class input_data_str &input_data , 
									       const class nucleons_data &prot_data , 
									       const class nucleons_data &neut_data , 
									       class array<class cluster_data> &cluster_projectile_data_tab ,
									       class input_data_str &input_data_CC_Berggren , 
									       const class nucleons_data &prot_data_CC_Berggren , 
									       const class nucleons_data &neut_data_CC_Berggren , 
									       class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab)
{
  const unsigned int CC_cluster_projectile_number = input_data.get_CC_cluster_projectile_number ();

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl;

  cluster_projectile_data_tab_alloc_calc (true , true , input_data , prot_data , neut_data , inter_data_basis , cluster_projectile_data_tab);

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl;

  cluster_projectile_data_tab_alloc_calc (false , false , input_data_CC_Berggren , prot_data_CC_Berggren , neut_data_CC_Berggren , inter_data_basis , cluster_projectile_data_CC_Berggren_tab);

  for (unsigned int cluster_index_c = 0 ; cluster_index_c < CC_cluster_projectile_number ; cluster_index_c++)
    {
      const class cluster_data &data_CC_Berggren_c = cluster_projectile_data_CC_Berggren_tab(cluster_index_c);

      class cluster_data &data_c = cluster_projectile_data_tab(cluster_index_c);
      
      data_c.get_PCM_matrices_cluster (data_CC_Berggren_c);
    }
}
