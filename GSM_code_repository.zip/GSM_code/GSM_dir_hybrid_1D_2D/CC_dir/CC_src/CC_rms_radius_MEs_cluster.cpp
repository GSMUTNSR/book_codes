#include "../CC_include/CC_include_def.h"



using namespace Wigner_signs;
using namespace angular_matrix_elements;

using namespace CC_rms_radius_MEs::radial;






// TYPE is double or complex
// -------------------------






// Calculation of the squared rms radius matrix element between the intrinsic parts of two clusters
// ------------------------------------------------------------------------------------------------
// One calculates <PSI[intrinsic-cluster-c'] | Rrms^2 | PSI[intrinsic-cluster-c]>.
// |PSI[intrinsic-cluster-c or intrinsic-cluster-c']> is the intrinsic wave function of the considered cluster c or c' projectile.
// For example, one has |PSI[cluster-c]> = [|N[HO-CM] L[CM]> |PSI[intrinsic-cluster-c]>]^JM, where CM is the center of mass of the projectile.

void CC_rms_radius_MEs::cluster::rms_radius_intrinsic_MEs_calc (
								const enum operator_type rms_radius_op ,
								const class input_data_str &input_data_CC_Berggren ,  
								class array<class cluster_data> &cluster_projectile_data_tab , 
								class CC_target_projectile_composite_data &Tpc_data , 
								class GSM_vector &PSI_full)
{
  const enum interaction_type inter = input_data_CC_Berggren.get_inter ();
  
  const unsigned int cluster_number = cluster_projectile_data_tab.dimension (0);
  
  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();

  const int n_holes_max = Tpc_data.get_n_holes_max ();
  
  const int n_scat_max = Tpc_data.get_n_scat_max ();
  
  const int E_relative_max_hw = Tpc_data.get_E_relative_max_hw ();

  const class GSM_vector_helper_class dummy_helper;

  class array<TYPE> &rms_radius_intrinsic_NBMEs = Tpc_data.get_scalar_intrinsic_NBMEs ();
	  
  rms_radius_intrinsic_NBMEs = 0.0;

  // cluster intrinsic state
  for (unsigned int icp = 0 ; icp < cluster_number ; icp++)
    {
      class cluster_data &data_cp = cluster_projectile_data_tab(icp);
	  
      const int Acp_cluster = data_cp.get_A_cluster ();

      if (Acp_cluster == 1) continue;
	  
      class baryons_data &cluster_prot_Y_data_HO_cp = data_cp.get_cluster_prot_Y_data_HO ();
      class baryons_data &cluster_neut_Y_data_HO_cp = data_cp.get_cluster_neut_Y_data_HO ();

      const unsigned int BP_cp = data_cp.get_BP_intrinsic ();

      const int Scp = data_cp.get_S_intrinsic ();
      
      const double Jcp = data_cp.get_J_intrinsic ();
      
      const double Mcp = Jcp;

      const int Zcp_cluster = data_cp.get_Z_cluster ();
      const int Ncp_cluster = data_cp.get_N_cluster ();

      const int n_holes_max_p_cp = cluster_prot_Y_data_HO_cp.get_n_holes_max ();
      const int n_holes_max_n_cp = cluster_neut_Y_data_HO_cp.get_n_holes_max ();
      
      const int n_scat_max_p_cp = cluster_prot_Y_data_HO_cp.get_n_scat_max ();
      const int n_scat_max_n_cp = cluster_neut_Y_data_HO_cp.get_n_scat_max ();

      const int n_scat_max_cp = min (n_scat_max , n_scat_max_p_cp + n_scat_max_n_cp);
      
      const int Ep_max_hw_cp = cluster_prot_Y_data_HO_cp.get_E_max_hw ();
      const int En_max_hw_cp = cluster_neut_Y_data_HO_cp.get_E_max_hw ();
      
      const int Ep_min_hw_cp = cluster_prot_Y_data_HO_cp.get_E_min_hw ();
      const int En_min_hw_cp = cluster_neut_Y_data_HO_cp.get_E_min_hw ();

      const int E_min_hw_cp = Ep_min_hw_cp + En_min_hw_cp;

      const int E_max_hw_cp = E_relative_max_hw + E_min_hw_cp;

      const enum space_type space_cp = space_determine (Zcp_cluster , Ncp_cluster);

      const class correlated_state_str PSI_cluster_qn_cp (Zcp_cluster , Ncp_cluster , BP_cp , Scp , Jcp , 0 , NADA , NADA , NADA , NADA , false);

      class GSM_vector_helper_class PSI_cluster_helper_cp (false , space_cp , inter , false , truncation_hw , truncation_ph ,
							   n_holes_max      , n_scat_max_cp   , E_max_hw_cp  , 
							   n_holes_max_p_cp , n_scat_max_p_cp , Ep_max_hw_cp ,
							   n_holes_max_n_cp , n_scat_max_n_cp , En_max_hw_cp , 
							   BP_cp , Mcp , true , cluster_prot_Y_data_HO_cp , cluster_neut_Y_data_HO_cp);

      class GSM_vector PSI_cluster_cp (PSI_cluster_helper_cp);

      PSI_cluster_cp.eigenvector_read_disk (true , true , PSI_cluster_qn_cp);
		  
      for (unsigned int ic = 0 ; ic < cluster_number ; ic++)
	{
	  class cluster_data &data_c = cluster_projectile_data_tab(ic);

	  const int Zc_cluster = data_c.get_Z_cluster ();
	  const int Nc_cluster = data_c.get_N_cluster ();

	  if ((Zcp_cluster == Zc_cluster) && (Ncp_cluster == Nc_cluster))
	    {	      
	      const unsigned int BP_c = data_c.get_BP_intrinsic ();
	      
	      const int Sc = data_c.get_S_intrinsic ();
	      
	      const double Jc = data_c.get_J_intrinsic ();

	      const double Mc = Jc;

	      if ((BP_c == BP_cp) && (make_int (Jc - Jcp) == 0))
		{
		  class baryons_data &cluster_prot_Y_data_HO_c = data_c.get_cluster_prot_Y_data_HO ();
		  class baryons_data &cluster_neut_Y_data_HO_c = data_c.get_cluster_neut_Y_data_HO ();

		  const int n_holes_max_p_c = cluster_prot_Y_data_HO_c.get_n_holes_max ();
		  const int n_holes_max_n_c = cluster_neut_Y_data_HO_c.get_n_holes_max ();
		  
		  const int n_scat_max_p_c = cluster_prot_Y_data_HO_c.get_n_scat_max ();
		  const int n_scat_max_n_c = cluster_neut_Y_data_HO_c.get_n_scat_max ();

		  const int n_scat_max_c = min (n_scat_max , n_scat_max_p_c + n_scat_max_n_c);
		  
		  const int Ep_max_hw_c = cluster_prot_Y_data_HO_c.get_E_max_hw ();
		  const int En_max_hw_c = cluster_neut_Y_data_HO_c.get_E_max_hw ();
		  
		  const int Ep_min_hw_c = cluster_prot_Y_data_HO_c.get_E_min_hw ();
		  const int En_min_hw_c = cluster_neut_Y_data_HO_c.get_E_min_hw ();

		  const int E_min_hw_c = Ep_min_hw_c + En_min_hw_c;
		  
		  const int E_max_hw_c = E_relative_max_hw + E_min_hw_c;

		  const enum space_type space_c = space_determine (Zc_cluster , Nc_cluster);
		  
		  const class correlated_state_str PSI_cluster_qn_c (Zc_cluster , Nc_cluster , BP_c , Sc , Jc , 0 , NADA , NADA , NADA , NADA , false);

		  class GSM_vector_helper_class PSI_cluster_helper_c (false , space_c , inter , false , truncation_hw , truncation_ph ,
								      n_holes_max     , n_scat_max_c   , E_max_hw_c , 
								      n_holes_max_p_c , n_scat_max_p_c , Ep_max_hw_c ,
								      n_holes_max_n_c , n_scat_max_n_c , En_max_hw_c , 
								      BP_c , Mc , true , cluster_prot_Y_data_HO_c , cluster_neut_Y_data_HO_c);

		  class GSM_vector PSI_cluster_c (PSI_cluster_helper_c);

		  PSI_cluster_c.eigenvector_read_disk (true , true , PSI_cluster_qn_c);

		  const int N_particle = (rms_radius_op == RMS_RADIUS_PROTON) ? (Zc_cluster) : (Nc_cluster);
		  
		  class array<TYPE> OBMEs_CM_radius_init_p , reduced_r_rms_radius_same_table_init_p , reduced_r_rms_radius_diff_table_init_p;
		  class array<TYPE> OBMEs_CM_radius_init_n , reduced_r_rms_radius_same_table_init_n , reduced_r_rms_radius_diff_table_init_n;
  
		  if (space_c != NEUT_Y_ONLY)
		    {
		      class OBMEs_CM_set_str &OBMEs_CM_set_p = cluster_prot_Y_data_HO_c.get_OBMEs_CM_set_HO_expansion ();
	  
		      const class OBMEs_CM_set_str &reduced_r_set_p                 = cluster_prot_Y_data_HO_c.get_reduced_r_HO_expansion_set                                ();
		      const class OBMEs_CM_set_str &reduced_r_rms_radius_diff_set_p = cluster_prot_Y_data_HO_c.get_reduced_r_HO_expansion_rms_radius_different_particles_set ();

		      OBMEs_CM_radius_init_p.allocate_fill (OBMEs_CM_set_p(RMS_RADIUS));
	  
		      reduced_r_rms_radius_same_table_init_p.allocate_fill (reduced_r_set_p                (RMS_RADIUS));
		      reduced_r_rms_radius_diff_table_init_p.allocate_fill (reduced_r_rms_radius_diff_set_p(RMS_RADIUS));
		    }
      
		  if (space_c != PROT_Y_ONLY)
		    {  
		      class OBMEs_CM_set_str &OBMEs_CM_set_n = cluster_neut_Y_data_HO_c.get_OBMEs_CM_set_HO_expansion ();
	  
		      const class OBMEs_CM_set_str &reduced_r_set_n                 = cluster_neut_Y_data_HO_c.get_reduced_r_HO_expansion_set                                ();
		      const class OBMEs_CM_set_str &reduced_r_rms_radius_diff_set_n = cluster_neut_Y_data_HO_c.get_reduced_r_HO_expansion_rms_radius_different_particles_set ();

		      OBMEs_CM_radius_init_n.allocate_fill (OBMEs_CM_set_n(RMS_RADIUS));
	  
		      reduced_r_rms_radius_same_table_init_n.allocate_fill (reduced_r_set_n                (RMS_RADIUS));
		      reduced_r_rms_radius_diff_table_init_n.allocate_fill (reduced_r_rms_radius_diff_set_n(RMS_RADIUS));
		    }

		  if (space_c != NEUT_Y_ONLY) OBMEs_TBMEs::coupled_OBMEs_CM_rms_radius_calc (rms_radius_op , true , input_data_CC_Berggren , N_particle , cluster_prot_Y_data_HO_c);
		  if (space_c != PROT_Y_ONLY) OBMEs_TBMEs::coupled_OBMEs_CM_rms_radius_calc (rms_radius_op , true , input_data_CC_Berggren , N_particle , cluster_neut_Y_data_HO_c);

		  if (space_c != NEUT_Y_ONLY) OBMEs_TBMEs::reduced_r_rms_radius_tables_CM_set_calc (rms_radius_op , true , input_data_CC_Berggren , N_particle , cluster_prot_Y_data_HO_c);
		  if (space_c != PROT_Y_ONLY) OBMEs_TBMEs::reduced_r_rms_radius_tables_CM_set_calc (rms_radius_op , true , input_data_CC_Berggren , N_particle , cluster_neut_Y_data_HO_c);
	  
		  const class CM_operator_class rms_op(rms_radius_op , true , Jc , true , PSI_cluster_helper_c , PSI_cluster_helper_cp , PSI_full);
	  
		  const class GSM_vector CM_Op_PSI_cluster_c = rms_op*PSI_cluster_c;
		  		  
		  rms_radius_intrinsic_NBMEs(ic , icp) = PSI_cluster_cp*CM_Op_PSI_cluster_c;

		  if (space_c != NEUT_Y_ONLY)
		    {
		      class OBMEs_CM_set_str &OBMEs_CM_set_p = cluster_prot_Y_data_HO_c.get_OBMEs_CM_set_HO_expansion ();
	  
		      class OBMEs_CM_set_str &reduced_r_set_p                 = cluster_prot_Y_data_HO_c.get_reduced_r_HO_expansion_set                                ();
		      class OBMEs_CM_set_str &reduced_r_rms_radius_diff_set_p = cluster_prot_Y_data_HO_c.get_reduced_r_HO_expansion_rms_radius_different_particles_set ();

		      OBMEs_CM_set_p(RMS_RADIUS) = OBMEs_CM_radius_init_p;
	    
		      reduced_r_set_p                (RMS_RADIUS) = reduced_r_rms_radius_same_table_init_p;
		      reduced_r_rms_radius_diff_set_p(RMS_RADIUS) = reduced_r_rms_radius_diff_table_init_p;
		    }
	  
		  if (space_c != PROT_Y_ONLY)
		    {
		      class OBMEs_CM_set_str &OBMEs_CM_set_n = cluster_neut_Y_data_HO_c.get_OBMEs_CM_set_HO_expansion ();
	  
		      class OBMEs_CM_set_str &reduced_r_set_n                 = cluster_neut_Y_data_HO_c.get_reduced_r_HO_expansion_set                                ();
		      class OBMEs_CM_set_str &reduced_r_rms_radius_diff_set_n = cluster_neut_Y_data_HO_c.get_reduced_r_HO_expansion_rms_radius_different_particles_set ();

		      OBMEs_CM_set_n(RMS_RADIUS) = OBMEs_CM_radius_init_n;
	      
		      reduced_r_set_n                (RMS_RADIUS) = reduced_r_rms_radius_same_table_init_n;
		      reduced_r_rms_radius_diff_set_n(RMS_RADIUS) = reduced_r_rms_radius_diff_table_init_n;
		    }
		}//test BP J
	    }//test Z N cluster
	}//loop ic
    }//loop icp
}













// Calculation of the squared rms radius matrix element between two clusters
// -------------------------------------------------------------------------
// One calculates <PSI[cluster-c'] | Rrms^2 | PSI[cluster-c]>.
// One has |PSI[cluster-c]> = [|N[HO-CM] L[CM]> |PSI[intrinsic-cluster-c]>]^JM, where CM is the center of mass of the projectile.
// Intrinsic matrix elements have been calculated with rms_radius_intrinsic_MEs_calc and stored in scalar_intrinsic_NBMEs of Tpc_data.
// 
// To calculate <PSI[cluster-c'] | Rrms^2 | PSI[cluster-c]>, one uses the decomposition Rrms^2 ~ Rrms^2[intrinsic] + rms_radius_CM_factor.R[CM]^2, which arises from r = r[intrinsic] + R[CM] in vector form.
// This matrix element is used only with non-antisymmetrized target-projectile states.
// Couplings between intrinsic and CM parts are then neglected because they occur only close to the target.
// rms_radius_CM_factor is defined in observables_basic_functions.cpp.
//
// One then has <PSI[cluster-c'] | Rrms^2 | PSI[cluster-c]> = <PSI[intrinsic-cluster-c'] | Rrms^2[intrinsic] | PSI[intrinsic-cluster-c]>.<u[c'](R[CM]) |           u[c](R[CM])>
//                                                          + <PSI[intrinsic-cluster-c'] |                     PSI[intrinsic-cluster-c]>.<u[c'](R[CM]) | R[CM]^2 | u[c](R[CM])>.rms_radius_CM_factor .

TYPE CC_rms_radius_MEs::cluster::ME_calc (
					  const class CC_target_projectile_composite_data &Tpc_data , 
					  const double rms_radius_CM_factor ,
					  const unsigned int ic , 
					  const unsigned int icp , 
					  const class CC_state_class &CC_state , 
					  const unsigned int ic_in , 
					  const unsigned int ic_out)
{
  const class array<class CC_channel_class> &channels_tab = CC_state.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  if (LCM_projectile_in != LCM_projectile_out) return 0.0;
  
  const enum particle_type projectile_in  = channel_c_in.get_projectile ();
  const enum particle_type projectile_out = channel_c_out.get_projectile ();

  if (projectile_in != projectile_out) return 0.0;
  
  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  if (make_int (J_projectile_in - J_projectile_out) != 0) return 0.0;

  const class array<TYPE> &scalar_intrinsic_NBMEs = Tpc_data.get_scalar_intrinsic_NBMEs ();
  
  const TYPE radial_overlap_CM_ME = radial_integral_calc (OVERLAP , CC_state , ic_in , ic_out);
  
  const TYPE intrinsic_ME = scalar_intrinsic_NBMEs(ic , icp);
  
  const TYPE radial_R2_CM_ME = (ic == icp) ? (radial_integral_calc (R2_RADIAL , CC_state , ic_in , ic_out)) : (0.0);
  
  const TYPE rms_radius_CM_factor_R2_CM_ME = (ic == icp) ? (rms_radius_CM_factor*radial_R2_CM_ME) : (0.0);

  const TYPE ME = radial_overlap_CM_ME*intrinsic_ME + rms_radius_CM_factor_R2_CM_ME;
  
  return ME;
}
