#include "../CC_include/CC_include_def.h"

using namespace inputs_misc;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_observables_common;
using namespace CC_beta_transitions_MEs;

void CC_beta_transitions_poles::data_father_alloc_calc (
							const enum beta_pm_type beta_pm , 
							const bool truncation_hw , 
							const bool truncation_ph , 
							const enum interaction_type inter , 
							const class baryons_data &prot_Y_data_out , 
							const class baryons_data &neut_Y_data_out , 
							class baryons_data &prot_Y_data_in , 
							class baryons_data &neut_Y_data_in)
{
  const int Z_core = prot_Y_data_out.get_Z_core ();
  const int N_core = prot_Y_data_out.get_N_core ();

  const int Z_out = prot_Y_data_out.get_N_nucleons ();
  const int N_out = neut_Y_data_out.get_N_nucleons ();

  const int Z_in = Z_IN_beta_determine (beta_pm , Z_out);
  const int N_in = N_IN_beta_determine (beta_pm , N_out);

  const int prot_hole_states_number = prot_Y_data_out.get_hole_states_number ();
  const int neut_hole_states_number = neut_Y_data_out.get_hole_states_number ();
  
  const int ZYval_in = Z_in - Z_core + prot_hole_states_number;
  const int NYval_in = N_in - N_core + neut_hole_states_number;

  const unsigned int prot_index = charge_baryon_index_determine (PROTON);
  const unsigned int neut_index = charge_baryon_index_determine (NEUTRON);
      
  const class array<double> &effective_masses_for_calc_p = prot_Y_data_out.get_effective_masses_for_calc ();
  const class array<double> &effective_masses_for_calc_n = neut_Y_data_out.get_effective_masses_for_calc ();
      
  const double prot_mass_for_calc = effective_masses_for_calc_p(prot_index);  
  const double neut_mass_for_calc = effective_masses_for_calc_n(neut_index);

  const bool is_it_COSM = is_it_COSM_determine (inter);

  const double nucleus_mass_out = prot_Y_data_out.get_nucleus_mass ();

  const double nucleus_mass_in = (!is_it_COSM) ? (Z_in*prot_mass_for_calc + N_in*neut_mass_for_calc) : (nucleus_mass_out);

  prot_Y_data_in.initialize_constants_from_other_nucleus (false , Z_in , N_in , 0 , nucleus_mass_in , nucleus_mass_in , prot_Y_data_out);
  neut_Y_data_in.initialize_constants_from_other_nucleus (false , Z_in , N_in , 0 , nucleus_mass_in , nucleus_mass_in , neut_Y_data_out);
  
  prot_Y_data_in.alloc_copy_one_body_data_tables_E_min_max_hw (prot_Y_data_out);
  neut_Y_data_in.alloc_copy_one_body_data_tables_E_min_max_hw (neut_Y_data_out);  

  if (ZYval_in > 0)
    {
      configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , prot_Y_data_in);

      SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , prot_Y_data_in , false);
    }

  if (NYval_in > 0)
    {
      configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false, neut_Y_data_in);

      SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , neut_Y_data_in , false);
    }
}










void CC_beta_transitions_poles::beta_suboperator_intrinsic_MEs_calc (
								     const enum beta_type beta , 
								     const enum beta_pm_type beta_pm ,
								     const bool is_it_HO_expansion ,
								     const class interaction_class &inter_data_basis ,  
								     class array<class cluster_data> &cluster_projectile_data_tab , 
								     class CC_target_projectile_composite_data &Tpc_data)
{
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
  
  const unsigned int beta_suboperator_number = beta_suboperator_type_number_determine ();

  const unsigned int cluster_number = cluster_projectile_data_tab.dimension (0);

  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();

  const int n_holes_max = Tpc_data.get_n_holes_max ();
  
  const int n_scat_max = Tpc_data.get_n_scat_max ();
  
  const int E_relative_max_hw = Tpc_data.get_E_relative_max_hw ();
  
  const class GSM_vector_helper_class dummy_helper;
  
  class array<TYPE> &beta_suboperator_intrinsic_NBMEs_strength = Tpc_data.get_beta_suboperator_intrinsic_NBMEs_strength ();
  
  beta_suboperator_intrinsic_NBMEs_strength = 0.0;
  
  class array<TYPE> beta_suboperator_intrinsic_NBMEs_strength_cluster_fixed_tab(beta_suboperator_number);
  
  // cluster intrinsic state
  for (unsigned int icp = 0 ; icp < cluster_number ; icp++)
    {      
      class cluster_data &data_cp = cluster_projectile_data_tab(icp);

      class baryons_data &cluster_prot_Y_data_HO_cp = data_cp.get_cluster_prot_Y_data_HO ();
      class baryons_data &cluster_neut_Y_data_HO_cp = data_cp.get_cluster_neut_Y_data_HO ();

      const unsigned int BP_cp = data_cp.get_BP_intrinsic ();

      const double Jcp = data_cp.get_J_intrinsic ();

      const double Mcp = Jcp;

      const int Zcp_cluster = data_cp.get_Z_cluster ();
      const int Ncp_cluster = data_cp.get_N_cluster ();

      const int n_holes_max_p_cp = cluster_prot_Y_data_HO_cp.get_n_holes_max ();
      const int n_holes_max_n_cp = cluster_neut_Y_data_HO_cp.get_n_holes_max ();
      
      const int n_scat_max_p_cp = cluster_prot_Y_data_HO_cp.get_n_scat_max ();
      const int n_scat_max_n_cp = cluster_neut_Y_data_HO_cp.get_n_scat_max ();

      const int n_scat_max_cp = min (n_scat_max , n_scat_max_p_cp + n_scat_max_n_cp);
      
      const int Ep_max_hw_cp = cluster_prot_Y_data_HO_cp.get_E_max_hw ();
      const int En_max_hw_cp = cluster_neut_Y_data_HO_cp.get_E_max_hw ();
      
      const int Ep_min_hw_cp = cluster_prot_Y_data_HO_cp.get_E_min_hw ();
      const int En_min_hw_cp = cluster_neut_Y_data_HO_cp.get_E_min_hw ();

      const int E_min_hw_cp = Ep_min_hw_cp + En_min_hw_cp;

      const int E_max_hw_cp = E_relative_max_hw + E_min_hw_cp;

      const enum space_type space_cp = space_determine (Zcp_cluster , Ncp_cluster);

      const class correlated_state_str PSI_cluster_qn_cp (Zcp_cluster , Ncp_cluster , BP_cp , 0 , Jcp , 0 , NADA , NADA , NADA , NADA , false);

      class GSM_vector_helper_class PSI_cluster_helper_cp (false , space_cp , TBME_inter , false , truncation_hw , truncation_ph ,
							   n_holes_max      , n_scat_max_cp   , E_max_hw_cp , 
							   n_holes_max_p_cp , n_scat_max_p_cp , Ep_max_hw_cp ,
							   n_holes_max_n_cp , n_scat_max_n_cp , En_max_hw_cp , 
							   BP_cp , Mcp , true , cluster_prot_Y_data_HO_cp , cluster_neut_Y_data_HO_cp);

      class GSM_vector PSI_cluster_cp (PSI_cluster_helper_cp);

      PSI_cluster_cp.eigenvector_read_disk (true , true , PSI_cluster_qn_cp);
      
      for (unsigned int ic = 0 ; ic < cluster_number ; ic++)
	{
	  beta_suboperator_intrinsic_NBMEs_strength_cluster_fixed_tab = 0.0;

	  class cluster_data &data_c = cluster_projectile_data_tab(ic);
	  
	  class baryons_data &cluster_prot_Y_data_HO_c = data_c.get_cluster_prot_Y_data_HO ();
	  class baryons_data &cluster_neut_Y_data_HO_c = data_c.get_cluster_neut_Y_data_HO ();

	  const unsigned int BP_c = data_c.get_BP_intrinsic ();
	  
	  const double Jc = data_c.get_J_intrinsic ();

	  const double Mc = Jc;

	  const int Zc_cluster = data_c.get_Z_cluster ();
	  const int Nc_cluster = data_c.get_N_cluster ();

	  const int n_holes_max_p_c = cluster_prot_Y_data_HO_c.get_n_holes_max ();
	  const int n_holes_max_n_c = cluster_neut_Y_data_HO_c.get_n_holes_max ();
	  
	  const int n_scat_max_p_c = cluster_prot_Y_data_HO_c.get_n_scat_max ();
	  const int n_scat_max_n_c = cluster_neut_Y_data_HO_c.get_n_scat_max ();

	  const int n_scat_max_c = min (n_scat_max , n_scat_max_p_c + n_scat_max_n_c);
		  
	  const int Ep_max_hw_c = cluster_prot_Y_data_HO_c.get_E_max_hw ();
	  const int En_max_hw_c = cluster_neut_Y_data_HO_c.get_E_max_hw ();
	  
	  const int Ep_min_hw_c = cluster_prot_Y_data_HO_c.get_E_min_hw ();
	  const int En_min_hw_c = cluster_neut_Y_data_HO_c.get_E_min_hw ();

	  const int E_min_hw_c = Ep_min_hw_c + En_min_hw_c;

	  const int E_max_hw_c = E_relative_max_hw + E_min_hw_c;
	  
	  const enum space_type space_c = space_determine (Zc_cluster , Nc_cluster);

	  const class correlated_state_str PSI_cluster_qn_c (Zc_cluster , Nc_cluster , BP_c , 0 , Jc , 0 , NADA , NADA , NADA , NADA , false);

	  const class GSM_vector_helper_class PSI_cluster_helper_c (false , space_c , TBME_inter , false , truncation_hw , truncation_ph ,
								    n_holes_max     , n_scat_max_c   , E_max_hw_c , 
								    n_holes_max_p_c , n_scat_max_p_c , Ep_max_hw_c ,
								    n_holes_max_n_c , n_scat_max_n_c , En_max_hw_c , 
								    BP_c , Mc , true , cluster_prot_Y_data_HO_c , cluster_neut_Y_data_HO_c);
	  
	  cluster::beta_suboperators_intrinsic_NBMEs_calc (beta , beta_pm , is_it_HO_expansion , inter_data_basis ,
							   PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp , beta_suboperator_intrinsic_NBMEs_strength_cluster_fixed_tab);
	  
	  for (unsigned int beta_suboperator_index = 0 ; beta_suboperator_index < beta_suboperator_number ; beta_suboperator_index++)
	    beta_suboperator_intrinsic_NBMEs_strength(ic , icp , beta_suboperator_index) = beta_suboperator_intrinsic_NBMEs_strength_cluster_fixed_tab(beta_suboperator_index);
	}//loop ic
    }//loop ic
  
#ifdef UseMPI
  if (is_it_MPI_parallelized) beta_suboperator_intrinsic_NBMEs_strength.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}









void CC_beta_transitions_poles::beta_suboperators_NBMEs_calc (
							      const enum beta_type beta ,
							      const enum beta_pm_type beta_pm ,
							      const bool is_it_HO_expansion ,
							      const bool is_it_nas_only ,
							      const bool full_common_vectors_used_in_file ,
							      const class CC_target_projectile_composite_data &Tpc_data , 
							      const class input_data_str &input_data_CC_Berggren , 
							      const class interaction_class &inter_data_basis ,
							      const class array<class cluster_data> &cluster_projectile_data_tab ,
							      const class CC_Hamiltonian_data &CC_H_data_in , 
							      const class CC_state_class &CC_state_in ,
							      const class CC_Hamiltonian_data &CC_H_data_out ,  
							      const class CC_state_class &CC_state_out , 
							      class baryons_data &prot_Y_data_out , 
							      class baryons_data &neut_Y_data_out , 
							      const class correlated_state_str &PSI_in_qn ,
							      const class correlated_state_str &PSI_out_qn ,
							      class array<TYPE> &beta_suboperator_NBMEs)
{
  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph (); 

  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();

  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();
  
  const enum storage_type Hamiltonian_storage = input_data_CC_Berggren.get_Hamiltonian_storage ();

  const bool is_it_full_or_partial_storage = is_it_full_or_partial_storage_determine (Hamiltonian_storage);
  
  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();
  
  //=================== calculations of the beta matrix elts < (J_i) || O_L || J_f > ====================//

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const int Z_cluster_max = (!is_it_one_baryon_COSM_case) ? (Z_cluster_max_determine (cluster_projectile_data_tab)) : (1);
  const int N_cluster_max = (!is_it_one_baryon_COSM_case) ? (N_cluster_max_determine (cluster_projectile_data_tab)) : (1);

  const int Z_cluster_number = Z_cluster_max + 1;
  const int N_cluster_number = N_cluster_max + 1;

  const enum interaction_type inter = inter_data_basis.get_TBME_inter ();

  class baryons_data prot_Y_data_in;
  class baryons_data neut_Y_data_in;

  data_father_alloc_calc (beta_pm , truncation_hw , truncation_ph , inter , prot_Y_data_out , neut_Y_data_out , prot_Y_data_in , neut_Y_data_in);
  
  class array<class baryons_data> prot_Y_data_in_one_projectile_less_tab(Z_cluster_number , N_cluster_number , 1);
  class array<class baryons_data> neut_Y_data_in_one_projectile_less_tab(Z_cluster_number , N_cluster_number , 1);

  class array<class baryons_data> prot_Y_data_out_one_projectile_less_tab(Z_cluster_number , N_cluster_number , 1);
  class array<class baryons_data> neut_Y_data_out_one_projectile_less_tab(Z_cluster_number , N_cluster_number , 1);
  
  data_one_projectile_less_alloc_calc (is_it_full_or_partial_storage , is_it_one_baryon_COSM_case , TBME_inter , truncation_hw , truncation_ph , prot_Y_data_in , neut_Y_data_in  ,
				       projectile_tab , cluster_projectile_data_tab , prot_Y_data_in_one_projectile_less_tab  , neut_Y_data_in_one_projectile_less_tab);
  
  data_one_projectile_less_alloc_calc (is_it_full_or_partial_storage , is_it_one_baryon_COSM_case , TBME_inter , truncation_hw , truncation_ph , prot_Y_data_out , neut_Y_data_out ,
				       projectile_tab , cluster_projectile_data_tab , prot_Y_data_out_one_projectile_less_tab , neut_Y_data_out_one_projectile_less_tab);
  
  class array<TYPE> target_reduced_NBMEs(N_target_projectile_states , N_target_projectile_states);
  
  target_reduced_NBMEs = 0.0;

  composite::target_reduced_NBMEs_calc (beta , beta_pm , is_it_HO_expansion , full_common_vectors_used_in_file , Tpc_data , inter_data_basis , prot_Y_data_in_one_projectile_less_tab , neut_Y_data_in_one_projectile_less_tab ,
					prot_Y_data_out_one_projectile_less_tab , neut_Y_data_out_one_projectile_less_tab , PSI_in_qn , PSI_out_qn , target_reduced_NBMEs);

  composite::beta_suboperator_NBMEs_calc (beta , beta_pm , is_it_HO_expansion , full_common_vectors_used_in_file , Tpc_data , cluster_projectile_data_tab , is_it_nas_only , inter_data_basis , input_data_CC_Berggren ,
					  target_reduced_NBMEs , CC_H_data_in , CC_state_in , CC_H_data_out , CC_state_out ,
					  prot_Y_data_in , neut_Y_data_in , prot_Y_data_out , neut_Y_data_out , PSI_in_qn , PSI_out_qn , beta_suboperator_NBMEs);
}








void CC_beta_transitions_poles::calc_print (
					    const input_data_str &input_data , 
					    const input_data_str &input_data_CC_Berggren , 
					    const class interaction_class &inter_data_basis,
					    const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
					    const class HF_nucleons_data &neut_HF_data_CC_Berggren ,
					    class baryons_data &prot_Y_data_CC_Berggren , 
					    class baryons_data &neut_Y_data_CC_Berggren , 
					    class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
					    class baryons_data &prot_Y_data , 
					    class baryons_data &neut_Y_data , 
					    class array<class cluster_data> &cluster_projectile_data_tab , 
					    class CC_target_projectile_composite_data &Tpc_data , 
					    class TBMEs_class &TBMEs_pn)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "beta transitions" << endl;
      cout <<         "----------------" << endl << endl;
    }

  const int Z_OUT = prot_Y_data.get_N_nucleons ();
  const int N_OUT = neut_Y_data.get_N_nucleons ();

  const int A = prot_Y_data.get_A ();
  
  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  //// if true, the Lmin/max are put to the L value for the total cross section
  //// the interferences between different L values disappear due to the orthogonality of the Wigner D-matrices
  //const bool is_total_cross_section_calculated = input_data.CC_beta_is_total_cross_section_calculated;
  //const int L_for_total_cross_section = input_data.CC_beta_L_for_total_cross_section;

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
  
  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();

  const unsigned int N_bef_R_uniform = input_data_CC_Berggren.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = input_data_CC_Berggren.get_N_aft_R_uniform ();

  const unsigned int N_bef_R_GL = input_data_CC_Berggren.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = input_data_CC_Berggren.get_N_aft_R_GL ();

  const unsigned int Nk_momentum_GL = input_data_CC_Berggren.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = input_data_CC_Berggren.get_Nk_momentum_uniform ();
  
  const double R_real_max = input_data_CC_Berggren.get_R_real_max ();

  const double R = input_data_CC_Berggren.get_R  ();

  const double kmax_momentum = input_data_CC_Berggren.get_kmax_momentum ();

  const double R_Fermi_momentum = input_data_CC_Berggren.get_R_Fermi_momentum ();
  
  const double R0_inter = inter_data_basis.get_R0 ();

  const double R0 = 1.27*cbrt (A);

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);

  const class array<unsigned int> &N_channels_tab = Tpc_data.get_N_channels_tab ();

  const class array<unsigned int> &BP_A_tab = Tpc_data.get_BP_A_tab (); 

  const class array<double> &J_A_tab = Tpc_data.get_J_A_tab ();

  const class array<class CC_channel_class> &channels_tab = Tpc_data.get_channels_tab ();
  
  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();
  
  const unsigned int beta_transitions_number = input_data.get_beta_transitions_number ();

  const class array<enum beta_type> &beta_tab = input_data.get_beta_tab ();

  const class array<enum beta_pm_type> &beta_pm_tab = input_data.get_beta_pm_tab ();

  const class array<unsigned int> &beta_BP_IN_tab  = input_data.get_beta_BP_IN_tab ();
  const class array<unsigned int> &beta_BP_OUT_tab = input_data.get_beta_BP_OUT_tab ();

  const class array<double> &beta_J_IN_tab  = input_data.get_beta_J_IN_tab ();
  const class array<double> &beta_J_OUT_tab = input_data.get_beta_J_OUT_tab ();

  const class array<unsigned int> &beta_vector_index_IN_tab  = input_data.get_beta_vector_index_IN_tab ();
  const class array<unsigned int> &beta_vector_index_OUT_tab = input_data.get_beta_vector_index_OUT_tab (); 

  const class array<bool> &beta_is_it_HO_expansion_tab = input_data.get_beta_is_it_HO_expansion_tab (); 

  const class array<double> &beta_W0_tab = input_data.get_beta_W0_tab ();

  class TBMEs_class dummy_TBMEs_cv;
  
  for (unsigned int beta_index = 0 ; beta_index < beta_transitions_number ; beta_index++)
    {
      const enum beta_type beta = beta_tab(beta_index);
      
      const enum beta_pm_type beta_pm = beta_pm_tab(beta_index);

      const bool is_it_HO_expansion = beta_is_it_HO_expansion_tab(beta_index);

      const double W0 = beta_W0_tab(beta_index);

      const unsigned int BP_IN  = beta_BP_IN_tab(beta_index);
      const unsigned int BP_OUT = beta_BP_OUT_tab(beta_index);

      const unsigned int vector_index_IN  = beta_vector_index_IN_tab(beta_index);
      const unsigned int vector_index_OUT = beta_vector_index_OUT_tab(beta_index);

      const double J_IN  = beta_J_IN_tab(beta_index);
      const double J_OUT = beta_J_OUT_tab(beta_index);

      const double M_IN  = J_IN;
      const double M_OUT = J_OUT;

      const int Z_IN = Z_IN_beta_determine (beta_pm , Z_OUT);
      const int N_IN = N_IN_beta_determine (beta_pm , N_OUT);

      class correlated_state_str PSI_IN_qn (Z_IN  , N_IN  , BP_IN  , 0 , J_IN  , vector_index_IN  , NADA , NADA , NADA , NADA , false);
      class correlated_state_str PSI_OUT_qn(Z_OUT , N_OUT , BP_OUT , 0 , J_OUT , vector_index_OUT , NADA , NADA , NADA , NADA , false);

      const unsigned int iJPi_IN  = JPi_index_determine (0 , BP_A_tab , J_A_tab , BP_IN  , J_IN);
      const unsigned int iJPi_OUT = JPi_index_determine (0 , BP_A_tab , J_A_tab , BP_OUT , J_OUT);
  
      const unsigned int N_channels_JPi_IN  = N_channels_tab(iJPi_IN);
      const unsigned int N_channels_JPi_OUT = N_channels_tab(iJPi_OUT);
  
      // table of all channels for the given composite state
      class array<class CC_channel_class> channels_JPi_IN_tab  (N_channels_JPi_IN);
      class array<class CC_channel_class> channels_JPi_OUT_tab (N_channels_JPi_OUT);
      
      JPi_channels_tab_BP_J_vector_index_E_fill (0 , channels_tab , BP_IN  , J_IN  , vector_index_IN  , NADA , channels_JPi_IN_tab);
      JPi_channels_tab_BP_J_vector_index_E_fill (0 , channels_tab , BP_OUT , J_OUT , vector_index_OUT , NADA , channels_JPi_OUT_tab);

      class CC_state_class CC_state_IN (is_it_one_baryon_COSM_case , nmax_HO_lab_tab , cluster_projectile_data_tab , true , true , N_channels_JPi_IN ,
					NADA , channels_JPi_IN_tab , N_bef_R_uniform , N_aft_R_uniform , N_bef_R_GL , N_aft_R_GL , Nk_momentum_uniform , Nk_momentum_GL ,
					R , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , A , BP_IN , J_IN , M_IN , vector_index_IN , NADA); 

      class CC_Hamiltonian_data CC_H_data_IN(N_channels_JPi_IN , input_data_CC_Berggren);

      CC_eigenstate_H_data_calc (Tpc_data , inter_data_basis , input_data_CC_Berggren , 
				 prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab ,
				 prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , prot_Y_data , neut_Y_data , PSI_IN_qn , TBMEs_pn , dummy_TBMEs_cv , CC_H_data_IN , CC_state_IN);
 
      class CC_Hamiltonian_data CC_H_data_OUT(N_channels_JPi_OUT , input_data_CC_Berggren);
      
      class CC_state_class CC_state_OUT (is_it_one_baryon_COSM_case , nmax_HO_lab_tab , cluster_projectile_data_tab , true , true , N_channels_JPi_OUT ,
					 NADA , channels_JPi_OUT_tab , N_bef_R_uniform , N_aft_R_uniform , N_bef_R_GL , N_aft_R_GL , Nk_momentum_uniform , Nk_momentum_GL , 
					 R , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , A , BP_OUT , J_OUT , M_OUT , vector_index_OUT , NADA); 

      CC_eigenstate_H_data_calc (Tpc_data , inter_data_basis , input_data_CC_Berggren , 
				 prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab ,
				 prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , prot_Y_data , neut_Y_data , PSI_OUT_qn , TBMEs_pn , dummy_TBMEs_cv , CC_H_data_OUT , CC_state_OUT);
      
      const unsigned int beta_suboperator_type_number = beta_suboperator_type_number_determine ();
   
      class array<TYPE> beta_suboperator_NBMEs_nas(beta_suboperator_type_number);
      class array<TYPE> beta_suboperator_NBMEs_as(beta_suboperator_type_number);

      beta_suboperator_NBMEs_nas = 0.0;
      beta_suboperator_NBMEs_as = 0.0;

      if (!is_it_one_baryon_COSM_case) beta_suboperator_intrinsic_MEs_calc (beta , beta_pm , is_it_HO_expansion , inter_data_basis , cluster_projectile_data_tab , Tpc_data);
      
      beta_suboperators_NBMEs_calc (beta , beta_pm , is_it_HO_expansion , true  , full_common_vectors_used_in_file , Tpc_data , input_data_CC_Berggren , inter_data_basis ,
				    cluster_projectile_data_tab , CC_H_data_IN , CC_state_IN , CC_H_data_OUT , CC_state_OUT , prot_Y_data , neut_Y_data , PSI_IN_qn , PSI_OUT_qn , beta_suboperator_NBMEs_nas);
      
      beta_suboperators_NBMEs_calc (beta , beta_pm , is_it_HO_expansion , false , full_common_vectors_used_in_file , Tpc_data , input_data_CC_Berggren , inter_data_basis ,
				    cluster_projectile_data_tab , CC_H_data_IN , CC_state_IN , CC_H_data_OUT , CC_state_OUT , prot_Y_data , neut_Y_data , PSI_IN_qn , PSI_OUT_qn , beta_suboperator_NBMEs_as);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  cout << "Non antisymmetrized matrix elements " << endl;

	  beta_transitions_common::calc_print (beta , beta_pm , A , Z_OUT , W0 , J_IN , beta_suboperator_NBMEs_nas);

	  cout << endl << " Antisymmetrized matrix elements " << endl;

	  beta_transitions_common::calc_print (beta , beta_pm , A , Z_OUT , W0 , J_IN , beta_suboperator_NBMEs_as);
	}
    }
}


