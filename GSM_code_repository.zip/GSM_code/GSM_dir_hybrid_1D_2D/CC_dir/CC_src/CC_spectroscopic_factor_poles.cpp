#include "../CC_include/CC_include_def.h"

using namespace string_routines;
using namespace inputs_misc;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_observables_common;
using namespace CC_beta_transitions_strength_MEs;
using namespace CC_beta_transitions_poles;
using namespace beta_transitions_common;
using namespace CC_overlap_function_poles;


TYPE CC_spectroscopic_factor_poles::calc (
					  const enum spectroscopic_factor_type SF ,
					  const enum nucleus_type nucleus , 
					  const enum particle_type projectile , 
					  const double b_HO , 
					  const int NCM_HO_max_projectile ,
					  const int LCM_projectile ,
					  const class CC_target_projectile_composite_data &Tpc_data , 
					  const bool is_it_nas_only , 
					  const class CC_Hamiltonian_data &CC_H_data , 
					  const class CC_state_class &CC_state , 
					  class baryons_data &prot_Y_data_out , 
					  class baryons_data &neut_Y_data_out ,
					  class array<class cluster_data> &cluster_projectile_data_tab , 
					  const class input_data_str &input_data_CC_Berggren , 
					  const class correlated_state_str &PSI_in_qn , 
					  const class correlated_state_str &PSI_out_qn , 
					  const class correlated_state_str &PSI_projectile_qn , 
					  const class array<double> &r_bef_R_tab_GL,
					  const class array<double> &w_bef_R_tab_GL)
{
  const double J_projectile = PSI_projectile_qn.get_J ();
  
  const TYPE spectroscopic_factor_nas = CC_state.spectroscopic_factor_calc (PSI_in_qn , projectile , LCM_projectile , J_projectile);

  if (is_it_nas_only) return spectroscopic_factor_nas;
  
  const bool is_it_one_baryon_COSM_case  = Tpc_data.get_is_it_one_baryon_COSM_case ();
  
  //=================== calculations of the beta matrix elts < (J_i) || O_L || J_f > ====================//

  const unsigned int N_bef_R_GL = r_bef_R_tab_GL.dimension (0);

  class array<TYPE> overlap_function_nas_tab(N_bef_R_GL);
  class array<TYPE> overlap_function_as_tab (N_bef_R_GL);
  
  CC_overlap_function_composite::calc (is_it_one_baryon_COSM_case , SF , nucleus , projectile ,  b_HO , NCM_HO_max_projectile , LCM_projectile , true , true , CC_H_data , CC_state ,
				       prot_Y_data_out , neut_Y_data_out , cluster_projectile_data_tab , input_data_CC_Berggren ,
				       PSI_in_qn , PSI_out_qn , PSI_projectile_qn , r_bef_R_tab_GL , overlap_function_nas_tab);
  
  CC_overlap_function_composite::calc (is_it_one_baryon_COSM_case , SF , nucleus , projectile ,  b_HO , NCM_HO_max_projectile , LCM_projectile , true , false , CC_H_data , CC_state ,
				       prot_Y_data_out , neut_Y_data_out , cluster_projectile_data_tab , input_data_CC_Berggren ,
				       PSI_in_qn , PSI_out_qn , PSI_projectile_qn , r_bef_R_tab_GL , overlap_function_as_tab);

  TYPE spectroscopic_factor_bef_R_nas = 0.0;
  TYPE spectroscopic_factor_bef_R_as  = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double w = w_bef_R_tab_GL(i);
      
      const TYPE overlap_function_nas_r = overlap_function_nas_tab(i);
      const TYPE overlap_function_as_r  = overlap_function_as_tab(i);
    
      spectroscopic_factor_bef_R_nas += w * overlap_function_nas_r * overlap_function_nas_r;
      spectroscopic_factor_bef_R_as  += w * overlap_function_as_r  * overlap_function_as_r;
    }
  
  const TYPE spectroscopic_factor = spectroscopic_factor_nas + spectroscopic_factor_bef_R_as - spectroscopic_factor_bef_R_nas;
  
  return spectroscopic_factor;
}








void CC_spectroscopic_factor_poles::calc_print (
						const input_data_str &input_data , 
						const input_data_str &input_data_CC_Berggren , 
						const class interaction_class &inter_data_basis , 
						const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
						const class HF_nucleons_data &neut_HF_data_CC_Berggren ,
						class baryons_data &prot_Y_data_CC_Berggren , 
						class baryons_data &neut_Y_data_CC_Berggren , 
						class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
						class baryons_data &prot_Y_data , 
						class baryons_data &neut_Y_data , 
						class array<class cluster_data> &cluster_projectile_data_tab , 
						class CC_target_projectile_composite_data &Tpc_data , 
						class TBMEs_class &TBMEs_pn, 
						class TBMEs_class &TBMEs_cv)
{ 
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Spectroscopic factors" << endl;
      cout <<         "---------------------" << endl << endl;
    }

  const int Z_OUT = prot_Y_data.get_N_nucleons ();
  const int N_OUT = neut_Y_data.get_N_nucleons ();

  const int A = prot_Y_data.get_A ();

  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  //// if true, the Lmin/max are put to the L value for the total cross section
  //// the interferences between different L values disappear due to the orthogonality of the Wigner D-matrices
  //const bool is_total_cross_section_calculated = input_data.get_CC_beta_is_total_cross_section_calculated;
  //const int L_for_total_cross_section = input_data.get_CC_beta_L_for_total_cross_section;

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();

  const unsigned int N_bef_R_uniform = input_data_CC_Berggren.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = input_data_CC_Berggren.get_N_aft_R_uniform ();

  const unsigned int N_bef_R_GL = input_data_CC_Berggren.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = input_data_CC_Berggren.get_N_aft_R_GL ();

  const unsigned int Nk_momentum_GL = input_data_CC_Berggren.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = input_data_CC_Berggren.get_Nk_momentum_uniform ();
  
  const double R_real_max = input_data_CC_Berggren.get_R_real_max ();

  const double R = input_data_CC_Berggren.get_R ();

  const double kmax_momentum = input_data_CC_Berggren.get_kmax_momentum ();

  const double R_Fermi_momentum = input_data_CC_Berggren.get_R_Fermi_momentum ();
  
  const double R0_inter = inter_data_basis.get_R0 ();

  const double R0 = 1.27*cbrt (A);

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);

  const class array<unsigned int> &N_channels_tab = Tpc_data.get_N_channels_tab ();

  const class array<unsigned int> &BP_A_tab = Tpc_data.get_BP_A_tab (); 

  const class array<double> &J_A_tab = Tpc_data.get_J_A_tab ();

  const class array<class CC_channel_class> &channels_tab = Tpc_data.get_channels_tab ();
  
  const double b_HO = input_data.get_b_lab ();

  const unsigned int S_OUT = input_data.get_hypernucleus_strangeness ();
  
  const unsigned int spectroscopic_factor_number = input_data.get_spectroscopic_factor_number ();

  const class array<enum spectroscopic_factor_type> &spectroscopic_factor_type_tab = input_data.get_spectroscopic_factor_type_tab ();

  const class array<enum nucleus_type> &spectroscopic_factor_nucleus_projectile_tab = input_data.get_spectroscopic_factor_nucleus_projectile_tab ();

  const class array<enum particle_type> &spectroscopic_factor_cluster_projectile_tab = input_data.get_spectroscopic_factor_cluster_projectile_tab ();
  
  const class array<int> &spectroscopic_factor_Z_projectile_tab = input_data.get_spectroscopic_factor_Z_projectile_tab ();
  const class array<int> &spectroscopic_factor_N_projectile_tab = input_data.get_spectroscopic_factor_N_projectile_tab ();

  const class array<int> &spectroscopic_factor_LCM_projectile_tab = input_data.get_spectroscopic_factor_LCM_projectile_tab ();

  const class array<int> &spectroscopic_factor_NCM_HO_max_projectile_tab = input_data.get_spectroscopic_factor_NCM_HO_max_projectile_tab ();
  
  const class array<unsigned int> &spectroscopic_factor_BP_IN_tab  = input_data.get_spectroscopic_factor_BP_IN_tab ();
  const class array<unsigned int> &spectroscopic_factor_BP_OUT_tab = input_data.get_spectroscopic_factor_BP_OUT_tab ();

  const class array<unsigned int> &spectroscopic_factor_BP_projectile_tab = input_data.get_spectroscopic_factor_BP_projectile_tab ();
  
  const class array<double> &spectroscopic_factor_J_IN_tab  = input_data.get_spectroscopic_factor_J_IN_tab ();
  const class array<double> &spectroscopic_factor_J_OUT_tab = input_data.get_spectroscopic_factor_J_OUT_tab ();

  const class array<double> &spectroscopic_factor_J_projectile_tab = input_data.get_spectroscopic_factor_J_projectile_tab ();
  
  const class array<unsigned int> &spectroscopic_factor_vector_index_IN_tab  = input_data.get_spectroscopic_factor_vector_index_IN_tab ();
  const class array<unsigned int> &spectroscopic_factor_vector_index_OUT_tab = input_data.get_spectroscopic_factor_vector_index_OUT_tab (); 

  const class array<unsigned int> &spectroscopic_factor_vector_index_projectile_tab = input_data.get_spectroscopic_factor_vector_index_projectile_tab ();
  
  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);
  
  for (unsigned int SF_index = 0 ; SF_index < spectroscopic_factor_number ; SF_index++)
    {
      const enum spectroscopic_factor_type SF = spectroscopic_factor_type_tab(SF_index);

      const enum particle_type cluster = spectroscopic_factor_cluster_projectile_tab(SF_index);

      const enum nucleus_type nucleus = spectroscopic_factor_nucleus_projectile_tab(SF_index);
      
      const int Z_projectile = spectroscopic_factor_Z_projectile_tab(SF_index);
      const int N_projectile = spectroscopic_factor_N_projectile_tab(SF_index);

      const int LCM_projectile = spectroscopic_factor_LCM_projectile_tab(SF_index);

      const int NCM_HO_max_projectile = spectroscopic_factor_NCM_HO_max_projectile_tab(SF_index);
      
      const unsigned int BP_IN  = spectroscopic_factor_BP_IN_tab(SF_index);
      const unsigned int BP_OUT = spectroscopic_factor_BP_OUT_tab(SF_index);

      const unsigned int BP_projectile = spectroscopic_factor_BP_projectile_tab(SF_index);
      
      const int S_projectile = particle_strangeness_determine (cluster);

      const double J_projectile = spectroscopic_factor_J_projectile_tab(SF_index);
      
      const unsigned int vector_index_projectile = spectroscopic_factor_vector_index_projectile_tab(SF_index);
      
      const unsigned int S_IN = (SF == STRIPPING) ? (S_OUT - S_projectile) : (S_OUT + S_projectile);
      
      const unsigned int vector_index_IN  = spectroscopic_factor_vector_index_IN_tab(SF_index);
      const unsigned int vector_index_OUT = spectroscopic_factor_vector_index_OUT_tab(SF_index);
            
      const double J_IN  = spectroscopic_factor_J_IN_tab(SF_index);
      const double J_OUT = spectroscopic_factor_J_OUT_tab(SF_index);
      
      const double M_IN  = J_IN;
      const double M_OUT = J_OUT;

      const double M_projectile = spectroscopic_factor_cluster_m_projection_calc (SF , M_IN , M_OUT);
      
      const class ljm_struct LJM_projectile(cluster , LCM_projectile , J_projectile , M_projectile , NADA);
      
      const int Z_IN = N_baryons_IN_spectroscopic_factor_determine (Z_OUT , Z_projectile , SF);
      const int N_IN = N_baryons_IN_spectroscopic_factor_determine (N_OUT , N_projectile , SF);
      
      class correlated_state_str PSI_IN_qn (Z_IN  , N_IN  , BP_IN  ,  S_IN , J_IN  , vector_index_IN  , NADA , NADA , NADA , NADA , false);
      class correlated_state_str PSI_OUT_qn(Z_OUT , N_OUT , BP_OUT , S_OUT , J_OUT , vector_index_OUT , NADA , NADA , NADA , NADA , false);
      
       const class correlated_state_str PSI_projectile_qn(Z_projectile , N_projectile , BP_projectile , S_projectile , J_projectile , vector_index_projectile , NADA , NADA , NADA , NADA , false);
         
      const unsigned int iJPi_OUT = JPi_index_determine (S_OUT , BP_A_tab , J_A_tab , BP_OUT , J_OUT);
      
      const unsigned int N_channels_JPi_OUT = N_channels_tab(iJPi_OUT);
      
      class array<class CC_channel_class> channels_JPi_OUT_tab (N_channels_JPi_OUT);

      JPi_channels_tab_BP_J_vector_index_E_fill (S_OUT , channels_tab , BP_OUT , J_OUT , vector_index_OUT , NADA , channels_JPi_OUT_tab);
	    
      class CC_state_class CC_state_OUT (is_it_one_baryon_COSM_case , nmax_HO_lab_tab , cluster_projectile_data_tab , true , true , N_channels_JPi_OUT , NADA ,
					 channels_JPi_OUT_tab , N_bef_R_uniform , N_aft_R_uniform , N_bef_R_GL , N_aft_R_GL , Nk_momentum_uniform , Nk_momentum_GL , 
					 R , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , A , BP_OUT , J_OUT , M_OUT , vector_index_OUT , NADA);
 	    
      class CC_Hamiltonian_data CC_H_data_OUT(N_channels_JPi_OUT , input_data_CC_Berggren);
	    
      CC_eigenstate_H_data_calc (Tpc_data , inter_data_basis , input_data_CC_Berggren , 
				 prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab ,
				 prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , prot_Y_data , neut_Y_data , PSI_OUT_qn , TBMEs_pn , TBMEs_cv , CC_H_data_OUT , CC_state_OUT);

      const TYPE spectroscopic_factor_nas = calc (SF , nucleus , cluster , b_HO , NCM_HO_max_projectile , LCM_projectile , Tpc_data , true , CC_H_data_OUT , CC_state_OUT , prot_Y_data , neut_Y_data ,
						  cluster_projectile_data_tab , input_data_CC_Berggren , PSI_IN_qn , PSI_OUT_qn , PSI_projectile_qn , r_bef_R_tab_GL , w_bef_R_tab_GL);

      const TYPE spectroscopic_factor_as = calc (SF , nucleus , cluster , b_HO , NCM_HO_max_projectile , LCM_projectile , Tpc_data , false , CC_H_data_OUT , CC_state_OUT , prot_Y_data , neut_Y_data ,
						 cluster_projectile_data_tab , input_data_CC_Berggren , PSI_IN_qn , PSI_OUT_qn , PSI_projectile_qn , r_bef_R_tab_GL , w_bef_R_tab_GL);

      
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  cout << endl << "Spectroscopic factor " << J_Pi_vector_index_string (BP_IN , J_IN , vector_index_IN) << " + " << angular_state_cluster (cluster , LCM_projectile , J_projectile) << " " << cluster << " --> ";
	  
	  cout << J_Pi_vector_index_string (BP_OUT , J_OUT , vector_index_OUT) << " : Non-antisymmetrized " << spectroscopic_factor_nas << " , antisymmetrized " << spectroscopic_factor_as << endl << endl;
	}
    }
}
      
