#include "../CC_include/CC_include_def.h"

using namespace beta_transitions_common;
using namespace beta_transitions_radial_OBMEs;
using namespace Wigner_signs;




//--// return the radial part of <uc_f lf jf || beta || uc_i li ji> before R
void CC_beta_transitions_strength_MEs::radial::radial_OBMEs_calc (
								  const enum radial_operator_type radial_operator , 
								  const double R_charge , 
								  const bool is_it_Gauss_Legendre ,  
								  const class CC_state_class &CC_state_in , 
								  const class CC_state_class &CC_state_out , 
								  const unsigned int ic_in , 
								  const unsigned int ic_out , 
								  class array<TYPE> &radial_OBMEs)
{
  //--// positions and weights
  const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (CC_state_out.get_r_bef_R_tab_GL ()) : (CC_state_out.get_r_bef_R_tab_uniform ());
  
  //--// tables containing the wfs of all channels
  const class array<complex<double> > &CC_wf_bef_R_tab_in  = (is_it_Gauss_Legendre) ? (CC_state_in.get_CC_wf_bef_R_tab_GL ())  : (CC_state_in.get_CC_wf_bef_R_tab_uniform ());
  const class array<complex<double> > &CC_wf_bef_R_tab_out = (is_it_Gauss_Legendre) ? (CC_state_out.get_CC_wf_bef_R_tab_GL ()) : (CC_state_out.get_CC_wf_bef_R_tab_uniform ());

  //--// number of discretization points

  const unsigned int N_bef_R_GL = CC_state_out.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = CC_state_out.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
 
  radial_OBMEs = 0.0;

  if (radial_operator == REDUCED_GRADIENT)
    {
      const class array<complex<double> > &CC_dwf_bef_R_tab_in = (is_it_Gauss_Legendre) ? (CC_state_in.get_CC_dwf_bef_R_tab_GL ()) : (CC_state_in.get_CC_dwf_bef_R_tab_uniform ());

      const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
      const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

      const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
      const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

      const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
      const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

      const double LCM_factor = 0.5*(LCM_projectile_in*(LCM_projectile_in + 1) - LCM_projectile_out*(LCM_projectile_out + 1));
  
      if (Nr > 0)
	{
	  const double r0 = r_bef_R_tab(0);

	  const complex<double> CC_wf_bef_R_in_r0  = CC_wf_bef_R_tab_in  (ic_in , 0);
	  const complex<double> CC_dwf_bef_R_in_r0 = CC_dwf_bef_R_tab_in (ic_in , 0);
	  
	  const complex<double> CC_wf_bef_R_out_r0 = CC_wf_bef_R_tab_out (ic_out , 0);
	  
#ifdef TYPEisDOUBLECOMPLEX      
	  radial_OBMEs(0) = (r0 > 0.0)
	    ? (CC_wf_bef_R_out_r0*(CC_dwf_bef_R_in_r0 + LCM_factor*CC_wf_bef_R_in_r0/r0))
	    : (CC_wf_bef_R_out_r0*CC_dwf_bef_R_in_r0*(LCM_factor + 1.0));
#endif
      
#ifdef TYPEisDOUBLE
	  radial_OBMEs(0) = (r0 > 0.0)
	    ? (real (CC_wf_bef_R_out_r0)*(real (CC_dwf_bef_R_in_r0) + LCM_factor*real (CC_wf_bef_R_in_r0)/r0))
	    : (real (CC_wf_bef_R_out_r0)*real (CC_dwf_bef_R_in_r0)*(LCM_factor + 1.0));
#endif
	}
      
      for (unsigned int i = 1 ; i < Nr ; i++)
	{
	  const double r = r_bef_R_tab(i);
	  
	  const complex<double> CC_wf_bef_R_in_r  = CC_wf_bef_R_tab_in  (ic_in , i);
	  const complex<double> CC_dwf_bef_R_in_r = CC_dwf_bef_R_tab_in (ic_in , i);
	  
	  const complex<double> CC_wf_bef_R_out_r = CC_wf_bef_R_tab_out (ic_out , i);

#ifdef TYPEisDOUBLECOMPLEX 
	  radial_OBMEs(i) = CC_wf_bef_R_out_r*(CC_dwf_bef_R_in_r + LCM_factor*CC_wf_bef_R_in_r/r);	     
#endif
      
#ifdef TYPEisDOUBLE
	  radial_OBMEs(i) = real (CC_wf_bef_R_out_r)*(real (CC_dwf_bef_R_in_r) + LCM_factor*real (CC_wf_bef_R_in_r)/r);	
#endif
	}
    }
  else
    {
      for (unsigned int i = 0 ; i < Nr ; i++)
	{
	  const double r = r_bef_R_tab(i);

	  const complex<double> CC_wf_bef_R_in_r  = CC_wf_bef_R_tab_in  (ic_in  , i);  
	  const complex<double> CC_wf_bef_R_out_r = CC_wf_bef_R_tab_out (ic_out , i);
	  
	  const TYPE Or = static_cast<TYPE> (beta_transitions_radial_operator (radial_operator , R_charge , r));
	  
#ifdef TYPEisDOUBLECOMPLEX
	  radial_OBMEs(i) = CC_wf_bef_R_in_r*CC_wf_bef_R_out_r*Or;
#endif
      
#ifdef TYPEisDOUBLE
	  radial_OBMEs(i) = real (CC_wf_bef_R_in_r)*real (CC_wf_bef_R_out_r)*Or;
#endif
	}
    }
}













