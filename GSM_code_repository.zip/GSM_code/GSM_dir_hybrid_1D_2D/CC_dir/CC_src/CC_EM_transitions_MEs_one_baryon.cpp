#include "../CC_include/CC_include_def.h"

using namespace Wigner_signs;

using namespace EM_transitions_common;





// TYPE is double or complex
// -------------------------





// EM is for electromagnetic
// -------------------------

// E is for electric
// -----------------

// M is for magnetic
// -----------------



// Calculation of the reduced E transition matrix element between channel functions
// --------------------------------------------------------------------------------
// One calculates <u[c[out]] || E || u[c[in]]> by separating the radial and angular parts of E.
// One uses E = E[charge] + E[current].

TYPE CC_EM_transitions_MEs::one_baryon::electric::OBME_reduced_calc (
								      const int L , 
								      const bool is_it_longwavelength_approximation , 
								      const double effective_charge , 
								      const class CC_state_class &CC_state_in , 
								      const class CC_state_class &CC_state_out , 
								      const unsigned int ic_in , 
								      const unsigned int ic_out)
{
  const unsigned int BP_Op = BP_EM_determine (ELECTRIC , L);
  
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();
  
  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();
  
  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out) != BP_Op) return 0.0;
    
  const enum particle_type projectile_in  = channel_c_in.get_projectile ();
  const enum particle_type projectile_out = channel_c_out.get_projectile ();
  
  const int projectile_charge_in  = particle_charge_determine (projectile_in);	
  const int projectile_charge_out = particle_charge_determine (projectile_out);
  
  if (projectile_charge_in != projectile_charge_out) return 0.0;
  
  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();
  
  const int Lmin = abs (make_int (J_projectile_in - J_projectile_out));
  const int Lmax =      make_int (J_projectile_in + J_projectile_out);

  if ((L < Lmin) || (L > Lmax)) return 0.0;

  //--// calculations of the radial electric charge and current matrix elements
  const TYPE ECH_radial_ME = radial::radial_integral_calc (ELECTRIC_CHARGE_RADIAL  , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE EC_radial_ME  = radial::radial_integral_calc (ELECTRIC_CURRENT_RADIAL , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);

  //--// multiplication by the angular parts <l[f] j[f] || E[charge or current] || l[i] j[i]>

  const TYPE ECH_ME = EM_suboperator_OBME_reduced_calc (ELECTRIC_CHARGE  , L , projectile_in , projectile_out , effective_charge , NADA , ECH_radial_ME , LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out);  
  const TYPE EC_ME  = EM_suboperator_OBME_reduced_calc (ELECTRIC_CURRENT , L , projectile_in , projectile_out , effective_charge , NADA , EC_radial_ME  , LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out);

  const TYPE electric_ME = ECH_ME + EC_ME;

  return electric_ME;
}









// Calculation of the reduced M transition matrix element between channel functions
// --------------------------------------------------------------------------------
// One calculates <u[c[out]] || M || u[c[in]]> by separating the radial and angular parts of M.
// One uses M = M[orbital gradient L+/-1 ] + M[spin gradient L+/-1] + M[s.e].

TYPE CC_EM_transitions_MEs::one_baryon::magnetic::OBME_reduced_calc (
								      const int L , 
								      const bool is_it_longwavelength_approximation , 
								      const class CC_state_class &CC_state_in , 
								      const class CC_state_class &CC_state_out , 
								      const unsigned int ic_in , 
								      const unsigned int ic_out)
{	
  const unsigned int BP_Op = BP_EM_determine (MAGNETIC , L);

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out) != BP_Op) return 0.0;
  
  const enum particle_type projectile_in  = channel_c_in.get_projectile ();
  const enum particle_type projectile_out = channel_c_out.get_projectile ();

  const int projectile_charge_in  = particle_charge_determine (projectile_in);	
  const int projectile_charge_out = particle_charge_determine (projectile_out);
	
  if (projectile_charge_in != projectile_charge_out) return 0.0;
  
  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  const int Lmin = abs (make_int (J_projectile_in - J_projectile_out));
  const int Lmax =      make_int (J_projectile_in + J_projectile_out);

  if ((L < Lmin) || (L > Lmax)) return 0.0;
  
  // calculations of the radial magnetic orbital gradient, spin gradient with L +/- 1 or s.e matrix elements

  const TYPE MOLP1_radial_ME = radial::radial_integral_calc (GRADIENT_BESSEL_YLP1                    , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE MOLM1_radial_ME = radial::radial_integral_calc (GRADIENT_BESSEL_YLM1                    , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE MSLP1_radial_ME = radial::radial_integral_calc (GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLP1 , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE MSLM1_radial_ME = radial::radial_integral_calc (GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLM1 , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const TYPE MSSCE_radial_ME = radial::radial_integral_calc (MAGNETIC_SPIN_S_SCALAR_E_RADIAL         , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);

  //--// multiplication by the angular parts <l[f] j[f] || M[orbital gradient, spin gradient with L +/- 1 or s.e] || l[i] j[i]>

  const TYPE MOLP1_ME = EM_suboperator_OBME_reduced_calc (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_L_L , L , projectile_in , projectile_out , NADA , NADA , MOLP1_radial_ME ,
							  LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out);
  
  const TYPE MOLM1_ME = EM_suboperator_OBME_reduced_calc (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_L_L , L , projectile_in , projectile_out , NADA , NADA , MOLM1_radial_ME ,
							  LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out);
    
  const TYPE MSLP1_ME = EM_suboperator_OBME_reduced_calc (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLP1_TENSOR_S_L , L , projectile_in , projectile_out , NADA , NADA , MSLP1_radial_ME ,
							  LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out);

  const TYPE MSLM1_ME = EM_suboperator_OBME_reduced_calc (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLM1_TENSOR_S_L , L , projectile_in , projectile_out , NADA , NADA , MSLM1_radial_ME ,
							  LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out);
  
  const TYPE MSSCE_ME = EM_suboperator_OBME_reduced_calc (MAGNETIC_SPIN_S_SCALAR_E , L , projectile_in , projectile_out , NADA , NADA , MSSCE_radial_ME ,
							  LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out);
  
  const TYPE magnetic_ME = MOLP1_ME + MOLM1_ME + MSLP1_ME + MSLM1_ME + MSSCE_ME;

  return magnetic_ME;
}







// Calculation of the reduced EM transition matrix element between channel functions
// ---------------------------------------------------------------------------------

TYPE CC_EM_transitions_MEs::one_baryon::OBME_reduced_calc (
							    const enum EM_type EM , 
							    const int L , 
							    const bool is_it_longwavelength_approximation , 
							    const double effective_charge , 
							    const class CC_state_class &CC_state_in , 
							    const class CC_state_class &CC_state_out , 
							    const unsigned int ic_in , 
							    const unsigned int ic_out)
{
  switch (EM)
    {
    case ELECTRIC: return electric::OBME_reduced_calc (L , is_it_longwavelength_approximation , effective_charge , CC_state_in , CC_state_out , ic_in , ic_out);      
    case MAGNETIC: return magnetic::OBME_reduced_calc (L , is_it_longwavelength_approximation ,                    CC_state_in , CC_state_out , ic_in , ic_out);
      
    default: abort_all ();
    }

  return NADA;
}




