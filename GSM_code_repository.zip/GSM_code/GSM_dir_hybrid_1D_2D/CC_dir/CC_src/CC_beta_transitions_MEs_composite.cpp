#include "../CC_include/CC_include_def.h"

using namespace inputs_misc;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_observables_common;
using namespace CC_beta_transitions_MEs;
using namespace CC_beta_transitions_MEs::radial;


// calculation of the antisymetrized + HO ME
void CC_beta_transitions_MEs::composite::target_projectile_as_HO_NBMEs_calc (
									     const bool is_it_one_nucleon_case ,
									     const enum beta_type beta , 
									     const enum beta_pm_type beta_pm , 
									     const bool is_it_HO_expansion ,
									     const bool full_common_vectors_used_in_file ,
									     const class interaction_class &inter_data_basis , 
									     const class CC_Hamiltonian_data &CC_H_data_in , 
									     const class CC_state_class &CC_state_in , 
									     const class CC_Hamiltonian_data &CC_H_data_out , 
									     const class CC_state_class &CC_state_out , 
									     const class input_data_str &input_data_CC_Berggren , 
									     class nucleons_data &prot_data_in , 
									     class nucleons_data &neut_data_in , 
									     class nucleons_data &prot_data_out , 
									     class nucleons_data &neut_data_out ,
									     const class array<class cluster_data> &cluster_data_tab ,  
									     const class array<class vector_class<complex<double> > > &CC_HO_overlaps_in , 
									     const class array<class vector_class<complex<double> > > &CC_HO_overlaps_out , 
									     const class correlated_state_str &PSI_in_qn ,  
									     const class correlated_state_str &PSI_out_qn ,  
									     class array<TYPE> &beta_suboperator_NBMEs)
{
  beta_suboperator_NBMEs = 0.0;

  const unsigned int BP_in  = PSI_in_qn.get_BP ();
  const unsigned int BP_out = PSI_out_qn.get_BP ();

  const double J_in  = PSI_in_qn.get_J ();
  const double J_out = PSI_out_qn.get_J ();

  const double M_in  = J_in;
  const double M_out = J_out;
  
  const unsigned int BP_Op = BP_beta_determine (beta);

  if (binary_parity_product (BP_in , BP_Op) != BP_out) return;

  const int Z_in = PSI_in_qn.get_Z ();
  const int N_in = PSI_in_qn.get_N ();

  const int Z_out = PSI_out_qn.get_Z ();
  const int N_out = PSI_out_qn.get_N ();

  if (Z_in != Z_IN_beta_determine (beta_pm , Z_out)) return;
  if (N_in != N_IN_beta_determine (beta_pm , N_out)) return;
  
  const enum space_type space_out = input_data_CC_Berggren.get_space ();

  const enum interaction_type inter = input_data_CC_Berggren.get_inter ();

  const bool truncation_hw = input_data_CC_Berggren.get_truncation_hw ();
  const bool truncation_ph = input_data_CC_Berggren.get_truncation_ph ();

  const int n_holes_max = input_data_CC_Berggren.get_n_holes_max ();

  const int n_scat_max = input_data_CC_Berggren.get_n_scat_max ();

  const int E_max_hw = input_data_CC_Berggren.get_E_max_hw ();

  const int Zval_in = prot_data_in.get_N_valence_nucleons ();
  const int Nval_in = neut_data_in.get_N_valence_nucleons ();

  const enum space_type space_in = space_determine (Zval_in , Nval_in);
  
  const int n_holes_max_p_in = prot_data_in.get_n_holes_max ();
  const int n_holes_max_n_in = neut_data_in.get_n_holes_max ();
  
  const int n_scat_max_p_in = prot_data_in.get_n_scat_max ();
  const int n_scat_max_n_in = neut_data_in.get_n_scat_max ();

  const int Ep_max_hw_in = prot_data_in.get_E_max_hw ();
  const int En_max_hw_in = neut_data_in.get_E_max_hw ();

  const int n_holes_max_p_out = prot_data_out.get_n_holes_max ();
  const int n_holes_max_n_out = neut_data_out.get_n_holes_max ();
  
  const int n_scat_max_p_out = prot_data_out.get_n_scat_max ();
  const int n_scat_max_n_out = neut_data_out.get_n_scat_max ();

  const int Ep_max_hw_out = prot_data_out.get_E_max_hw ();
  const int En_max_hw_out = neut_data_out.get_E_max_hw ();
  
  // composite states (they have to be read in files)
  // they correspond to the [a^+ PSI_GSM]_M^J

  class GSM_vector_helper_class PSI_HO_in_helper (is_it_MPI_parallelized , space_in , inter , false , truncation_hw , truncation_ph ,
						  n_holes_max      , n_scat_max      , E_max_hw ,
						  n_holes_max_p_in , n_scat_max_p_in , Ep_max_hw_in ,
						  n_holes_max_n_in , n_scat_max_n_in , En_max_hw_in , BP_in , M_in , true , prot_data_in , neut_data_in);

  class GSM_vector PSI_HO_in (PSI_HO_in_helper);

  target_projectile_PSI_HO_calc (is_it_one_nucleon_case , input_data_CC_Berggren , cluster_data_tab , CC_H_data_in , CC_state_in , CC_HO_overlaps_in ,
				 prot_data_in , neut_data_in , PSI_HO_in);

  PSI_HO_in.space_dimension_SDs_components_eigenvector_copy_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_in_qn);
  
  class GSM_vector_helper_class PSI_HO_out_helper (is_it_MPI_parallelized , space_out , inter , false , truncation_hw , truncation_ph ,
						   n_holes_max       , n_scat_max       , E_max_hw ,
						   n_holes_max_p_out , n_scat_max_p_out , Ep_max_hw_out ,
						   n_holes_max_n_out , n_scat_max_n_out , En_max_hw_out , BP_out , M_out , true , prot_data_out , neut_data_out);

  class GSM_vector PSI_HO_out (PSI_HO_out_helper);
  
  target_projectile_PSI_HO_calc (is_it_one_nucleon_case , input_data_CC_Berggren , cluster_data_tab , CC_H_data_out , CC_state_out , CC_HO_overlaps_out , prot_data_out , neut_data_out , PSI_HO_out);

  beta_transitions::beta_suboperators_NBMEs_calc (beta , beta_pm , is_it_HO_expansion , full_common_vectors_used_in_file , inter_data_basis , PSI_in_qn ,  PSI_out_qn , PSI_HO_out , beta_suboperator_NBMEs);
  
#ifdef UseMPI
  if (is_it_MPI_parallelized) beta_suboperator_NBMEs.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}














// target nas
// common to the non antisymetrized (nas) and for the non antisymetrized + HO (nas_HO)
void CC_beta_transitions_MEs::composite::target_NBMEs_nas_calc (
								const enum beta_type beta ,
								const class CC_target_projectile_composite_data &Tpc_data , 
								const class CC_state_class &CC_state_in , 
								const class CC_state_class &CC_state_out , 
								const class array<TYPE> &target_reduced_NBMEs , 
								class array<TYPE> &beta_suboperator_target_reduced_nas_NBMEs)
{
  const class array<unsigned int> &target_indices = Tpc_data.get_target_indices ();

  const int A = CC_state_out.get_A ();
  
  const unsigned int BP_beta = BP_beta_determine (beta);

  const class array<class CC_channel_class> &channels_tab_JPi_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_JPi_out = CC_state_out.get_channels_tab ();

  const double J_in  = CC_state_in.get_J ();
  const double J_out = CC_state_out.get_J ();

  const double R_charge = R_charge_beta_calc (A);

  const unsigned int N_channels_JPi_in  = CC_state_in.get_N_channels ();
  const unsigned int N_channels_JPi_out = CC_state_out.get_N_channels ();

  const unsigned int beta_suboperator_number = beta_suboperator_target_reduced_nas_NBMEs.dimension (0);
  
  beta_suboperator_target_reduced_nas_NBMEs = 0.0;

  // "out" target state
  for (unsigned int ic_out = 0 ; ic_out < N_channels_JPi_out ; ic_out++)
    {
      const class CC_channel_class &channel_c_out = channels_tab_JPi_out(ic_out);

      const enum particle_type projectile_c_out = channel_c_out.get_projectile ();

      const unsigned int BP_Tc_out = channel_c_out.get_BP_Tc ();

      const unsigned int vector_index_Tc_out = channel_c_out.get_vector_index_Tc ();

      const double J_Tc_out = channel_c_out.get_J_Tc ();

      const double J_projectile_c_out = channel_c_out.get_J_projectile ();

      const int LCM_projectile_c_out = channel_c_out.get_LCM_projectile ();

      const int two_J_Tc_out = make_int (2.0*J_Tc_out);

      const unsigned int iTc_out = target_indices(BP_Tc_out , two_J_Tc_out , vector_index_Tc_out);

      // "in" target state
      for (unsigned int ic_in = 0 ; ic_in < N_channels_JPi_in ; ic_in++)
	{
	  const class CC_channel_class &channel_c_in = channels_tab_JPi_in(ic_in);

	  const enum particle_type projectile_c_in = channel_c_in.get_projectile ();

	  const unsigned int BP_Tc_in = channel_c_in.get_BP_Tc ();

	  const unsigned int vector_index_Tc_in = channel_c_in.get_vector_index_Tc ();

	  const double J_Tc_in = channel_c_in.get_J_Tc ();

	  const double J_projectile_c_in = channel_c_in.get_J_projectile ();

	  const int LCM_projectile_c_in = channel_c_in.get_LCM_projectile ();

	  const int two_J_Tc_in = make_int (2.0*J_Tc_in);

	  const unsigned int iTc_in = target_indices(BP_Tc_in , two_J_Tc_in , vector_index_Tc_in);

	  const bool BP_targets_condition = (binary_parity_product (BP_Tc_in , BP_beta) == BP_Tc_out);
	  
	  const bool projectiles_condition = (projectile_c_in == projectile_c_out);

	  const bool LCM_projectiles_condition = (LCM_projectile_c_out == LCM_projectile_c_in);

	  const bool J_projectiles_condition = (rint (J_projectile_c_out - J_projectile_c_in) == 0.0);

	  // deltas (is it the same projectile and quantum numbers are conserved)
	  if (BP_targets_condition && projectiles_condition && LCM_projectiles_condition && J_projectiles_condition)
	    {
	      const double jc = J_projectile_c_out;

	      // calculation of int_0^inf dr u_cf (r) * u_ci (r)
	      // radial factor
	      const TYPE factor_radial = radial_integral_calc (OVERLAP , R_charge , CC_state_in , CC_state_out , ic_in , ic_out);

	      for (unsigned int beta_suboperator_index = 0 ; beta_suboperator_index < beta_suboperator_number ; beta_suboperator_index++)
		{
		  const enum beta_suboperator_type beta_suboperator = beta_suboperator_type_from_index (beta_suboperator_index);

		  const int rank_beta_suboperator = rank_beta_suboperator_determine (beta_suboperator);
		  
		  //get cf_<Jf || O_beta (T) || Ji>_ci
		  const TYPE target_reduced_NBME = target_reduced_NBMEs(iTc_in , iTc_out , beta_suboperator_index);

		  // calculation of sum_{cf , ci} cf_<Jf || O_beta (T) || Ji>_ci
		  const TYPE total_NBME_reduced = static_cast<TYPE> (Oa_reduced_ME_calc (rank_beta_suboperator , J_Tc_in , jc , J_in , J_Tc_out , jc , J_out , target_reduced_NBME)) * factor_radial;
	      
		  beta_suboperator_target_reduced_nas_NBMEs(beta_suboperator_index) += total_NBME_reduced;
		}// loop beta_suboperator_index
	    }//deltas
	}//loop ic_in
    }//loop ic_out
}












// projectile
// for the non antisymmetrized (nas) NBME
// the CC_state_out/in are used
// common to nas and nas+HO
void CC_beta_transitions_MEs::composite::projectile_NBMEs_nas_calc (
								    const enum beta_type beta , 
								    const enum beta_pm_type beta_pm , 
								    const class CC_target_projectile_composite_data &Tpc_data ,
								    const class array<class cluster_data> &cluster_data_tab , 
								    const class CC_state_class &CC_state_in , 
								    const class CC_state_class &CC_state_out , 
								    class array<TYPE> &beta_suboperator_projectile_NBMEs_nas)
{
  const bool is_it_one_nucleon_case = Tpc_data.get_is_it_one_nucleon_case ();

  const int A = CC_state_out.get_A ();

  const double R_charge = R_charge_beta_calc (A);
  
  const unsigned int BP_beta = BP_beta_determine (beta);

  const class array<class CC_channel_class> &channels_tab_JPi_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_JPi_out = CC_state_out.get_channels_tab ();

  const double J_in  = CC_state_in.get_J ();
  const double J_out = CC_state_out.get_J ();

  const unsigned int N_channels_JPi_in  = CC_state_in.get_N_channels ();
  const unsigned int N_channels_JPi_out = CC_state_out.get_N_channels ();
  
  const unsigned int beta_suboperator_number = beta_suboperator_projectile_NBMEs_nas.dimension (0);
  
  class array<TYPE> beta_suboperator_projectile_NBMEs_nas_fixed_channels(beta_suboperator_number);
    
  beta_suboperator_projectile_NBMEs_nas = 0.0;

  for (unsigned int ic_out = 0 ; ic_out < N_channels_JPi_out ; ic_out++)
    {
      const class CC_channel_class &channel_c_out = channels_tab_JPi_out(ic_out);
      
      const int LCM_projectile_c_out = channel_c_out.get_LCM_projectile ();

      const unsigned int BP_Tc_out = channel_c_out.get_BP_Tc ();
      
      const unsigned int bp_c_out = binary_parity_from_orbital_angular_momentum (LCM_projectile_c_out);

      const unsigned int vector_index_Tc_out = channel_c_out.get_vector_index_Tc ();

      const double J_projectile_c_out = channel_c_out.get_J_projectile ();

      const double J_Tc_out = channel_c_out.get_J_Tc ();

      const enum particle_type projectile_c_out = channel_c_out.get_projectile ();

      const int Z_projectile_c_out = Z_projectile_determine (projectile_c_out);
      const int N_projectile_c_out = N_projectile_determine (projectile_c_out);

      const int Z_projectile_in_beta = Z_IN_beta_determine (beta_pm , Z_projectile_c_out);
      const int N_projectile_in_beta = N_IN_beta_determine (beta_pm , N_projectile_c_out);

      const unsigned int icp = (!is_it_one_nucleon_case) ? (cluster_data_index_determine (projectile_c_out , cluster_data_tab)) : (NADA);
      
      const class correlated_state_str PSI_cluster_qn_cp (Z_projectile_c_out , N_projectile_c_out , bp_c_out , J_projectile_c_out , 0 , NADA , NADA , NADA , NADA , false);
      
      for (unsigned int ic_in = 0 ; ic_in < N_channels_JPi_in ; ic_in++)
	{
	  const class CC_channel_class &channel_c_in = channels_tab_JPi_in(ic_in);

	  const int LCM_projectile_c_in = channel_c_in.get_LCM_projectile ();

	  const unsigned int BP_Tc_in = channel_c_in.get_BP_Tc ();

	  const unsigned int bp_c_in = binary_parity_from_orbital_angular_momentum (LCM_projectile_c_in);

	  const unsigned int vector_index_Tc_in = channel_c_in.get_vector_index_Tc ();

	  const double J_projectile_c_in = channel_c_in.get_J_projectile ();

	  const double J_Tc_in = channel_c_in.get_J_Tc ();

	  const enum particle_type projectile_c_in = channel_c_in.get_projectile ();

	  const bool BP_targets_condition = (BP_Tc_in == BP_Tc_out);

	  const bool J_targets_condition = (rint (J_Tc_in - J_Tc_out) == 0.0);

	  const bool vector_index_targets_condition = (vector_index_Tc_in == vector_index_Tc_out);
	  
	  const int Z_projectile_c_in = Z_projectile_determine (projectile_c_in);
	  const int N_projectile_c_in = N_projectile_determine (projectile_c_in);
	  
	  const bool projectiles_condition = ((Z_projectile_c_in == Z_projectile_in_beta) && (N_projectile_c_in != N_projectile_in_beta));
	  
	  const bool bp_projectiles_condition = (binary_parity_product (bp_c_in , bp_c_out) == BP_beta);

	  // delta (if it is the same target and quantum numbers are conserved)

	  if (BP_targets_condition && J_targets_condition && vector_index_targets_condition && projectiles_condition && bp_projectiles_condition)
	    {
	      const unsigned int ic = (!is_it_one_nucleon_case) ? (cluster_data_index_determine (projectile_c_in , cluster_data_tab)) : (NADA);

	      const class correlated_state_str PSI_cluster_qn_c (Z_projectile_c_in , N_projectile_c_in , bp_c_in , J_projectile_c_in , 0 , NADA , NADA , NADA , NADA , false);

	      const double J_Tc = J_Tc_out;
	      
	      beta_suboperator_projectile_NBMEs_nas_fixed_channels = 0.0;

	      //================================== nas ==================================//

	      if (is_it_one_nucleon_case) 
		one_nucleon::beta_suboperators_OBMEs_reduced_calc (beta , beta_pm , R_charge , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_projectile_NBMEs_nas_fixed_channels);
	      else
		cluster::beta_suboperators_NBMEs_calc (beta , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp ,
						       CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_projectile_NBMEs_nas_fixed_channels);

	      // calculation of sum_{cf , ci} cf_<Jf || O_beta (p) || Ji>_ci
	      for (unsigned int beta_suboperator_index = 0 ; beta_suboperator_index < beta_suboperator_number ; beta_suboperator_index++)
		{
		  const enum beta_suboperator_type beta_suboperator = beta_suboperator_type_from_index (beta_suboperator_index);

		  const int rank_beta_suboperator = rank_beta_suboperator_determine (beta_suboperator);
		  
		  const TYPE projectile_ME_reduced = beta_suboperator_projectile_NBMEs_nas_fixed_channels(beta_suboperator_index);

		  const TYPE NBME_reduced = static_cast<TYPE> (Ob_reduced_ME_calc (rank_beta_suboperator , J_Tc , J_projectile_c_in , J_in , J_Tc , J_projectile_c_out , J_out , projectile_ME_reduced));
		  
		  beta_suboperator_projectile_NBMEs_nas(beta_suboperator_index) += NBME_reduced;
		}// loop beta_suboperator_index
	    }//delta
	}//loop ic_in
    }//loop_ic_out
}






















// cf_<J_Tf || beta (T) || J_Ti>_ci NBMEs stored
void CC_beta_transitions_MEs::composite::target_reduced_NBMEs_calc (
								    const enum beta_type beta , 
								    const enum beta_pm_type beta_pm ,
								    const bool is_it_HO_expansion , 
								    const bool full_common_vectors_used_in_file ,
								    const class CC_target_projectile_composite_data &Tpc_data , 
								    const class interaction_class &inter_data_basis , 
								    class array<class nucleons_data> &prot_data_in_one_cluster_less_tab , 
								    class array<class nucleons_data> &neut_data_in_one_cluster_less_tab , 
								    class array<class nucleons_data> &prot_data_out_one_cluster_less_tab , 
								    class array<class nucleons_data> &neut_data_out_one_cluster_less_tab , 
								    const class correlated_state_str &PSI_in_qn ,  
								    const class correlated_state_str &PSI_out_qn ,  
								    class array<TYPE> &target_NBMEs_reduced)
{
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();

  const int n_holes_max = Tpc_data.get_n_holes_max ();
  
  const int n_scat_max = Tpc_data.get_n_scat_max ();
  
  const int E_relative_max_hw = Tpc_data.get_E_relative_max_hw ();

  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();

  const unsigned int BP_beta = BP_beta_determine (beta);
  
  const class array<unsigned int> &BP_target_tab = Tpc_data.get_BP_target_tab ();

  const class array<double> &J_target_tab = Tpc_data.get_J_target_tab ();

  const class array<unsigned int> &vector_index_target_tab = Tpc_data.get_vector_index_target_tab ();

  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();

  const class array<TYPE> &E_target_tab =  Tpc_data.get_E_target_tab ();
  
  const class GSM_vector_helper_class dummy_helper;
		  
  const unsigned int beta_suboperator_number = target_NBMEs_reduced.dimension (2);

  class array<TYPE> beta_suboperator_NBMEs_fixed_targets(beta_suboperator_number);
							 
  // "out" target state
  for (unsigned int iT_out = 0 ; iT_out < N_target_projectile_states ; iT_out++)
    {
      const unsigned int BP_target_out = BP_target_tab(iT_out);
      
      const unsigned int vector_index_target_out = vector_index_target_tab(iT_out);
      
      const double J_target_out = J_target_tab(iT_out);
      
      const double M_target_out = J_target_out;

      const complex<double> E_target_out = E_target_tab(iT_out);
      
      const enum particle_type projectile_out = projectile_tab(iT_out);

      const int Z_projectile_out = Z_projectile_determine (projectile_out);
      const int N_projectile_out = N_projectile_determine (projectile_out);

      class nucleons_data &prot_data_target_out = prot_data_out_one_cluster_less_tab(Z_projectile_out , N_projectile_out);
      class nucleons_data &neut_data_target_out = neut_data_out_one_cluster_less_tab(Z_projectile_out , N_projectile_out);

      const int n_holes_max_p_target_out = prot_data_target_out.get_n_holes_max ();
      const int n_holes_max_n_target_out = neut_data_target_out.get_n_holes_max ();
      
      const int n_scat_max_p_target_out = prot_data_target_out.get_n_scat_max ();
      const int n_scat_max_n_target_out = neut_data_target_out.get_n_scat_max ();

      const int Zval_target_out = prot_data_target_out.get_N_valence_nucleons ();
      const int Nval_target_out = neut_data_target_out.get_N_valence_nucleons ();

      const int n_scat_max_target_out = min (n_scat_max , n_scat_max_p_target_out + n_scat_max_n_target_out);
      
      const int Z_target_out = prot_data_target_out.get_N_nucleons ();
      const int N_target_out = neut_data_target_out.get_N_nucleons ();

      const int Ep_max_hw_target_out = prot_data_target_out.get_E_max_hw ();
      const int En_max_hw_target_out = neut_data_target_out.get_E_max_hw ();

      const int E_min_hw_target_out = prot_data_target_out.get_E_min_hw () + neut_data_target_out.get_E_min_hw ();

      const int E_max_hw_target_out = E_relative_max_hw + E_min_hw_target_out;

      const enum space_type space_target_out = space_determine (Zval_target_out , Nval_target_out);

      const class correlated_state_str PSI_target_out (Z_target_out , N_target_out , BP_target_out , J_target_out , vector_index_target_out , E_target_out , NADA , NADA , NADA , false);
      
      class GSM_vector_helper_class V_target_out_helper (is_it_MPI_parallelized , space_target_out , TBME_inter , false , truncation_hw , truncation_ph ,
							 n_holes_max              ,n_scat_max_target_out    ,  E_max_hw_target_out , 
							 n_holes_max_p_target_out , n_scat_max_p_target_out , Ep_max_hw_target_out ,
							 n_holes_max_n_target_out , n_scat_max_n_target_out , En_max_hw_target_out , 
							 BP_target_out , M_target_out , true , prot_data_target_out , neut_data_target_out);

      class GSM_vector V_target_out (V_target_out_helper);
      
      V_target_out.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_target_out);
      
      // "in" target state
      for (unsigned int iT_in = 0 ; iT_in < N_target_projectile_states ; iT_in++)
	{
	  const unsigned int BP_target_in = BP_target_tab(iT_in);

	  const unsigned int vector_index_target_in = vector_index_target_tab(iT_in);

	  const double J_target_in = J_target_tab(iT_in);

	  const double M_target_in = J_target_in;

	  const complex<double> E_target_in = E_target_tab(iT_in);

	  const enum particle_type projectile_in = projectile_tab(iT_in);

	  const int Z_projectile_in = Z_projectile_determine (projectile_in);
	  const int N_projectile_in = N_projectile_determine (projectile_in);

	  class nucleons_data &prot_data_target_in = prot_data_in_one_cluster_less_tab(Z_projectile_in , N_projectile_in);
	  class nucleons_data &neut_data_target_in = neut_data_in_one_cluster_less_tab(Z_projectile_in , N_projectile_in);

	  const int n_holes_max_p_target_in = prot_data_target_in.get_n_holes_max ();
	  const int n_holes_max_n_target_in = neut_data_target_in.get_n_holes_max ();
	  
	  const int n_scat_max_p_target_in = prot_data_target_in.get_n_scat_max ();
	  const int n_scat_max_n_target_in = neut_data_target_in.get_n_scat_max ();

	  const int Zval_target_in = prot_data_target_in.get_N_valence_nucleons ();
	  const int Nval_target_in = neut_data_target_in.get_N_valence_nucleons ();

	  const int n_scat_max_target_in = min (n_scat_max , n_scat_max_p_target_in + n_scat_max_n_target_in);

	  const int Z_target_in = prot_data_target_in.get_N_nucleons ();
	  const int N_target_in = neut_data_target_in.get_N_nucleons ();

	  const int Ep_max_hw_target_in = prot_data_target_in.get_E_max_hw ();
	  const int En_max_hw_target_in = neut_data_target_in.get_E_max_hw ();

	  const int E_min_hw_target_in = prot_data_target_in.get_E_min_hw () + neut_data_target_in.get_E_min_hw ();

	  const int E_max_hw_target_in = E_relative_max_hw + E_min_hw_target_in;

	  const enum space_type space_target_in = space_determine (Zval_target_in , Nval_target_in);
	  
	  const class correlated_state_str PSI_target_in (Z_target_in , N_target_in , BP_target_in , J_target_in , vector_index_target_in , E_target_in , NADA , NADA , NADA , false);

	  const class GSM_vector_helper_class V_target_in_helper (is_it_MPI_parallelized , space_target_in , TBME_inter , false , truncation_hw , truncation_ph ,
								  n_holes_max             , n_scat_max_target_in   ,  E_max_hw_target_in , 
								  n_holes_max_p_target_in , n_scat_max_p_target_in , Ep_max_hw_target_in ,
								  n_holes_max_n_target_in , n_scat_max_n_target_in , En_max_hw_target_in , 
								  BP_target_in , M_target_in , true , prot_data_target_in , neut_data_target_in);

	  // deltas (is it the same projectile and targets verify beta +/- condition)
	  if ((Z_target_in == Z_IN_beta_determine (beta_pm , Z_target_out)) && (N_target_in == N_IN_beta_determine (beta_pm , N_target_out)) && (projectile_in == projectile_out))
	    {
	      if (binary_parity_product (BP_target_in , BP_beta) == BP_target_out)
		{
		  // calculates cf_<J_Tf || beta (T) || J_Ti>_ci	

		  beta_suboperator_NBMEs_fixed_targets = 0.0;
		  
		  beta_transitions::beta_suboperators_NBMEs_calc (beta , beta_pm , is_it_HO_expansion , full_common_vectors_used_in_file , inter_data_basis ,
								  PSI_in_qn ,  PSI_out_qn , V_target_out , beta_suboperator_NBMEs_fixed_targets);
  
		  if (THIS_PROCESS == MASTER_PROCESS)
		    {
		      for (unsigned int beta_suboperator_index = 0 ; beta_suboperator_index < beta_suboperator_number ; beta_suboperator_index++)
			target_NBMEs_reduced(iT_in , iT_out , beta_suboperator_index) = beta_suboperator_NBMEs_fixed_targets(beta_suboperator_index);
		    }
		}
	    }//deltas projectile
	}//loop iT_in
    }//loop iT_out
  
#ifdef UseMPI
  if (is_it_MPI_parallelized) target_NBMEs_reduced.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}












void CC_beta_transitions_MEs::composite::beta_suboperator_NBMEs_calc (
								      const enum beta_type beta ,
								      const enum beta_pm_type beta_pm ,
								      const bool is_it_HO_expansion ,
								      const bool full_common_vectors_used_in_file ,
								      const class CC_target_projectile_composite_data &Tpc_data ,
								      const class array<class cluster_data> &cluster_data_tab , 
								      const bool is_it_nas_only ,
								      const class interaction_class &inter_data_basis , 
								      const class input_data_str &input_data_CC_Berggren , 
								      const class array<TYPE> &target_reduced_NBMEs , 
								      const class CC_Hamiltonian_data &CC_H_data_in , 
								      const class CC_state_class &CC_state_in , 
								      const class CC_Hamiltonian_data &CC_H_data_out , 
								      const class CC_state_class &CC_state_out , 
								      class nucleons_data &prot_data_in , 
								      class nucleons_data &neut_data_in , 
								      class nucleons_data &prot_data_out , 
								      class nucleons_data &neut_data_out , 
								      const class correlated_state_str &PSI_in_qn ,  
								      const class correlated_state_str &PSI_out_qn ,    
								      class array<TYPE> &beta_suboperator_NBMEs)
{	
  const bool is_it_one_nucleon_case = Tpc_data.get_is_it_one_nucleon_case ();
  
  //================================== projectile ==================================//
  // for the non antisymetrized (nas) the CC_state_out/in are used
  // for the non antisymetrized + HO (nas_HO) the CC_state_out/in are projected in the HO basis

  // projection of the out and in states in the HO basis

  class CC_state_class CC_state_in_HO  (CC_state_in);
  class CC_state_class CC_state_out_HO (CC_state_out);

  CC_state_in_HO.CC_HO_wfs_projection ();
  CC_state_out_HO.CC_HO_wfs_projection ();

  const unsigned int beta_suboperator_number = beta_suboperator_NBMEs.dimension (0);

  class array<TYPE> projectile_NBMEs_nas   (beta_suboperator_number);
  class array<TYPE> projectile_NBMEs_nas_HO(beta_suboperator_number);
  
  class array<TYPE> target_NBMEs_nas   (beta_suboperator_number);
  class array<TYPE> target_NBMEs_nas_HO(beta_suboperator_number);

  class array<TYPE> total_reduced_NBMEs_as_HO(beta_suboperator_number);
   
  //===================================non antisymetrized (nas)==============================================================================

  // sum of the reduced matrix elts for the projectile
  projectile_NBMEs_nas_calc (beta  , beta_pm , Tpc_data , cluster_data_tab , CC_state_in , CC_state_out , projectile_NBMEs_nas);

  // sum of the reduced matrix elts for the target
  target_NBMEs_nas_calc (beta , Tpc_data , CC_state_in , CC_state_out , target_reduced_NBMEs , target_NBMEs_nas);

  // calculation of <Jf || O_beta || Ji> = sum_{cf , ci} ( cf_<Jf || O_beta (p) || Ji>_ci + cf_<Jf || O_beta (T) || Ji>_ci )
  // nas

  if (is_it_nas_only)
    {
      beta_suboperator_NBMEs = projectile_NBMEs_nas + target_NBMEs_nas;

      return;
    }
  
  const class array<TYPE> total_reduced_NBMEs_nas = projectile_NBMEs_nas + target_NBMEs_nas;
  
  // sum of the reduced matrix elts for the projectile (HO)
  projectile_NBMEs_nas_calc (beta , beta_pm , Tpc_data , cluster_data_tab , CC_state_in_HO , CC_state_out_HO , projectile_NBMEs_nas_HO);

  // sum of the reduced matrix elts for the target (nas_HO)
  target_NBMEs_nas_calc (beta , Tpc_data , CC_state_in_HO , CC_state_out_HO , target_reduced_NBMEs , target_NBMEs_nas_HO);

  // calculation of <Jf || O_beta || Ji> = sum_{cf , ci} ( cf_<Jf || O_beta (p) || Ji>_ci + cf_<Jf || O_beta (T) || Ji>_ci )
  // nas and in HO basis
  const class array<TYPE> total_reduced_NBMEs_nas_HO = projectile_NBMEs_nas_HO + target_NBMEs_nas_HO;
  
  //================================== antisymetrized and HO projection (as_HO) ===================================//
  //===============================================================================================================//


  //================================== CC_HO overlaps (<u_c^{HO} | u_n>) ==================================//

  // for the "out" and "in" composite state
  const class array<class vector_class<complex<double> > > &CC_HO_overlaps_in  = CC_state_in.get_HO_overlaps ();
  const class array<class vector_class<complex<double> > > &CC_HO_overlaps_out = CC_state_out.get_HO_overlaps ();

  //================================== calculation of the antisymetrized + HO ME ==================================//

  // <Jf || O_beta || Ji>
  // antisymetrized andf in the HO basis
  target_projectile_as_HO_NBMEs_calc (is_it_one_nucleon_case , beta , beta_pm , is_it_HO_expansion , full_common_vectors_used_in_file , inter_data_basis , CC_H_data_in , CC_state_in , CC_H_data_out , CC_state_out ,
				      input_data_CC_Berggren , prot_data_in , neut_data_in ,  prot_data_out , neut_data_out , cluster_data_tab , 
				      CC_HO_overlaps_in , CC_HO_overlaps_out , PSI_in_qn , PSI_out_qn , total_reduced_NBMEs_as_HO);

  // final result
  beta_suboperator_NBMEs = total_reduced_NBMEs_nas + (total_reduced_NBMEs_as_HO - total_reduced_NBMEs_nas_HO);
}

