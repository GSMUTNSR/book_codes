#include "../CC_include/CC_include_def.h"

// TYPE is double or complex
// -------------------------





// Calculation of a cluster basis wave function of the Berggren basis for fixed n, l, j (or N[CM], L[CM] and J for clusters)
// -------------------------------------------------------------------------------------------------------------------------
// The state is calculated by the node if its shell index belongs to the interval [first_index : last_index] or if it is an S-matrix pole.
// It is a HO state, it is calculated analytically.
// Otherwise, i.e. if one uses an interpolated potential issued from the sum of WS potentials, one allocates the associated class.
// The integration constants such as C0 or C+ are taken from arrays.
// The class spherical_state is allocated here before being calculated.
// Otherwise, one looks for its linear momentum with k_search (see spherical_state.cpp) if it is a S-matrix pole, or one calculates it directly from its linear momentum with k.
// The nlj_struct shell_qn is then updated with the obtained values.
//
// Wave functions are calculated in momentum space for momentum density.
// One uses a Fermi function centered in R_Fermi as the Fermi-Bessel transform is not defined otherwise (see spherical_state.cpp).


void cluster_CM_Berggren_basis::wave_function_calculation (
							   const bool is_there_cout , 
							   const class interaction_class &inter_data , 
							   const int N , 
							   const int L , 
							   const double J , 
							   class cluster_data &data)
{  
  class nlj_table<class spherical_state> &cluster_CM_shells = data.get_cluster_CM_shells ();

  const class nlj_table<bool> &cluster_CM_S_matrix_poles = data.get_cluster_CM_S_matrix_poles ();

  class nlj_table<complex<double> > &cluster_CM_K_tab = data.get_cluster_CM_K_tab ();
  
  const class nlj_table<complex<double> > &cluster_CM_W_tab = data.get_cluster_CM_W_tab ();

  class nlj_table<complex<double> > &cluster_CM_E_tab = data.get_cluster_CM_E_tab ();

  class spherical_state &cluster_CM_shell = cluster_CM_shells(N , L , J);

  const enum potential_type basis_potential = data.get_basis_potential ();
  
  const bool S_matrix_pole = cluster_CM_S_matrix_poles(N , L , J);

  const complex<double> K = cluster_CM_K_tab(N , L , J);
  const complex<double> W = cluster_CM_W_tab(N , L , J);

  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = data.get_N_aft_R_GL ();
  
  const unsigned int N_bef_R_uniform = data.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = data.get_N_aft_R_uniform ();
  
  const unsigned int Nk_momentum_GL = data.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = data.get_Nk_momentum_uniform ();
  
  const double step_bef_R_uniform = data.get_step_bef_R_uniform  ();

  const double R = data.get_R ();

  const double R_real_max = data.get_R_real_max ();

  const double kmax_momentum = data.get_kmax_momentum ();

  const double R_Fermi_momentum = data.get_R_Fermi_momentum ();
  
  const double b_lab_cluster = data.get_b_lab_cluster ();

  const class array<double> &cluster_CM_R0_tab = data.get_cluster_CM_R0_tab ();
  
  const class nlj_table<complex<double> > &cluster_CM_C0_tab = data.get_cluster_CM_C0_tab ();

  const class nlj_table<complex<double> > &cluster_CM_Cplus_tab = data.get_cluster_CM_Cplus_tab ();

  const enum particle_type cluster = data.get_cluster ();

  const complex<double> sqrt_W = sqrt (W);

  const complex<double> C0 = cluster_CM_C0_tab(N , L , J);

  const complex<double> Cplus = cluster_CM_Cplus_tab(N , L , J);

  const int A_composite = data.get_A_composite ();

  const int Z_cluster_charge_potential = data.get_Z_cluster_charge_potential ();

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);
  
  const double R0_inter = inter_data.get_R0 ();

  const double R0 = cluster_CM_R0_tab(L);

  const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);  

  const double cluster_mass_for_calc = data.get_cluster_mass_for_calc ();

  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);

  const double nucleus_mass = data.get_nucleus_mass ();

  const double mass_modif = (!is_it_COSM) ? (-nucleus_mass) : (nucleus_mass);

  const double dV_R = data.get_potential_cluster_CM_derivative_R ();

  const class lj_table<double> &potential_cluster_CM_derivative_r0_tab = data.get_potential_cluster_CM_derivative_r0_tab ();

  const double dV_r0 = potential_cluster_CM_derivative_r0_tab(L , J);

  const class lj_table<double> &potential_cluster_CM_bef_R_tab_uniform = data.get_potential_cluster_CM_bef_R_tab_uniform ();
  
  cluster_CM_shell.allocate (false , true , basis_potential , A_composite , Z_cluster_charge_potential , mass_modif , NADA ,
			     N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , Nk_momentum_GL , Nk_momentum_uniform ,
			     R , NADA , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , S_matrix_pole , cluster , N , NADA , L , J , true , K , cluster_mass_for_calc , C0 , Cplus);

#ifdef UseMPI

  const unsigned int first_index = cluster_CM_shells.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_index = cluster_CM_shells.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);

  const unsigned int index = cluster_CM_shells.index_determine (N , L , J);

  if (S_matrix_pole || ((index >= first_index) && (index <= last_index)))
#endif
    {
      switch (basis_potential)
	{
	case HO_POTENTIAL:
	  {
	    cluster_CM_shell.HO_wave_function (b_lab_cluster);
	  } break;

	case INTERPOLATED_POTENTIAL:
	  {  	
	    class potentials_effective_mass T;

	    T.initialize_constants (
				    cluster_CM_shell.get_potential () , 
				    cluster_CM_shell.get_kinetic_factor () , 
				    cluster_CM_shell.get_jr () , 
				    cluster_CM_shell.get_l () ,
				    cluster_CM_shell.get_ZY_charge () , 
				    cluster_CM_shell.get_j () , 
				    cluster_CM_shell.get_k () , 
				    cluster_CM_shell.get_eta () , 
				    NADA);

	    class array<double> r_tab_uniform(N_bef_R_uniform);
  
	    class array<double> potential_tab_uniform(N_bef_R_uniform);

	    for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_tab_uniform(i) = i*step_bef_R_uniform;

	    for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) potential_tab_uniform(i) = potential_cluster_CM_bef_R_tab_uniform(L , J , i);

	    class splines_class<double> &V_interpolated = T.get_V_interpolated ();
  
	    V_interpolated.allocate_calc (r_tab_uniform , potential_tab_uniform , dV_r0 , dV_R);
	
	    if (S_matrix_pole) cluster_CM_shell.k_search (T , true , is_there_cout);
	  
	    if (S_matrix_pole && (THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << endl;

	    cluster_CM_shell.wave_calculation (is_there_cout , T , true);

	    if (S_matrix_pole && (THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << endl;

	    if (!S_matrix_pole) cluster_CM_shell.normalization (sqrt_W);

	  } break;
	  
	default:
	  error_message_print_abort ("basis_potential is HO_POTENTIAL or INTERPOLATED_POTENTIAL in cluster_CM_Berggren_basis::wave_function_calculation");
	}
      
      const complex<double> K_shell = cluster_CM_shell.get_k ();
      const complex<double> E_shell = cluster_CM_shell.get_E ();
      
      cluster_CM_K_tab(N , L , J) = K_shell;
      cluster_CM_E_tab(N , L , J) = E_shell;	
    }
}














// Print on screen of overlaps
// ---------------------------
// Master process only.
// All shells |n l j> (or |N[CM] L[CM] J> for clusters) of the valence space must be orthogonal to each other.
// The overlaps <n l j | n' l j > are then calculated here with complex scaling, along with <u_n(r) l j | u_n'(r) l j >, which must vanish as well.

void cluster_CM_Berggren_basis::print_overlaps_cluster (const class cluster_data &data)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in cluster_CM_Berggren_basis::print_overlaps.");

  const int Nmax = data.get_Nmax ();
  const int Lmax = data.get_Lmax ();

  const int Nmax_plus_one = Nmax + 1;
  
  const double J_intrinsic = data.get_J_intrinsic ();
  
  const class nlj_table<class spherical_state> &cluster_CM_shells = data.get_cluster_CM_shells ();

  const class nlj_table<bool> &cluster_CM_S_matrix_poles = data.get_cluster_CM_S_matrix_poles ();

  const class lj_table<int> &Nmax_cluster_projectile_CM_tab = data.get_Nmax_cluster_projectile_CM_tab ();

  class lj_table<double> infinite_norm_overlap_tab(J_intrinsic , Lmax , Nmax_plus_one , Nmax_plus_one);

  class lj_table<double> infinite_norm_overlap_der_tab(J_intrinsic , Lmax , Nmax_plus_one , Nmax_plus_one);
  
  infinite_norm_overlap_tab = 0.0;

  infinite_norm_overlap_der_tab = 0.0;

  for (int L = 0 ; L <= Lmax ; L++)
    {
      const double Jmin = abs (J_intrinsic - L);
      const double Jmax =      J_intrinsic + L;

      const int J_number = make_int (Jmax - Jmin) + 1;

      for (int J_index = 0 ; J_index < J_number ; J_index++)
	{
	  const double J = Jmin + J_index;

	  const int Nmax_LJ = Nmax_cluster_projectile_CM_tab(L , J);

	  for (int N_in = 0 ; N_in <= Nmax_LJ ; N_in++)
	    for (int N_out = 0 ; N_out <= N_in ; N_out++)
	      {
		const class spherical_state &cluster_CM_wf_in  = cluster_CM_shells(N_in  , L , J);
		const class spherical_state &cluster_CM_wf_out = cluster_CM_shells(N_out , L , J);
		
		const bool S_matrix_pole_in = cluster_CM_S_matrix_poles(N_in , L , J);

		infinite_norm_overlap_tab(L , J , N_in , N_out) = (N_in != N_out) ? (inf_norm (complex_scaling_radial_OBMEs::radial_integral_calc (OVERLAP , NADA , NADA , cluster_CM_wf_in , cluster_CM_wf_out))) : (NADA);

		infinite_norm_overlap_der_tab(L , J , N_in , N_out) = (S_matrix_pole_in || (N_in != N_out)) 
		  ? (inf_norm (complex_scaling_radial_OBMEs::radial_integral_calc (OVERLAP_WF_DWF , NADA , NADA , cluster_CM_wf_in , cluster_CM_wf_out)))
		  : (0.0);
	      }
	}
    }
  
  unsigned int N_states     = 0;
  unsigned int N_states_der = 0;

  double max_infinite_norm_overlap     = 0.0 , infinite_norm_overlap_sum     = 0.0 , infinite_norm_overlap_squares_sum     = 0.0;
  double max_infinite_norm_overlap_der = 0.0 , infinite_norm_overlap_sum_der = 0.0 , infinite_norm_overlap_squares_sum_der = 0.0;
  
  for (int L = 0 ; L <= Lmax ; L++)
    {
      const double Jmin = abs (J_intrinsic - L);
      const double Jmax =      J_intrinsic + L;

      const int J_number = make_int (Jmax - Jmin) + 1;

      for (int J_index = 0 ; J_index < J_number ; J_index++)
	{
	  const double J = Jmin + J_index;

	  const int Nmax_LJ = Nmax_cluster_projectile_CM_tab(L , J);

	  for (int N_in = 0 ; N_in <= Nmax_LJ ; N_in++)
	    for (int N_out = 0 ; N_out <= N_in ; N_out++)
	      {
		const double infinite_norm_overlap     = infinite_norm_overlap_tab    (L , J , N_in , N_out);
		const double infinite_norm_overlap_der = infinite_norm_overlap_der_tab(L , J , N_in , N_out);

		if (N_out != N_in)
		  {
		    if (infinite_norm_overlap > max_infinite_norm_overlap) max_infinite_norm_overlap = infinite_norm_overlap;
		
		    infinite_norm_overlap_sum += infinite_norm_overlap;
		    
		    infinite_norm_overlap_squares_sum += infinite_norm_overlap*infinite_norm_overlap;
		
		    N_states++;
		  }
		
		if (infinite_norm_overlap_der > max_infinite_norm_overlap_der) max_infinite_norm_overlap_der = infinite_norm_overlap_der;

		infinite_norm_overlap_sum_der += infinite_norm_overlap_der;
		
		infinite_norm_overlap_squares_sum_der += infinite_norm_overlap_der*infinite_norm_overlap_der;
		
		N_states_der++;
	      }
	}
    }

  if (N_states >= 1)
    {
      const double infinite_norm_overlap_average = infinite_norm_overlap_sum/N_states;
  
      const double infinite_norm_overlap_sigma = statistical_sigma_calc (N_states , infinite_norm_overlap_sum , infinite_norm_overlap_squares_sum);
  
      cout << "Maximal       |cluster overlap|oo : " << max_infinite_norm_overlap << endl;
      cout << "Average       |cluster overlap|oo : " << infinite_norm_overlap_average << endl; 
      cout << "Dispersion of |cluster overlap|oo : " << infinite_norm_overlap_sigma << endl << endl;
    }

  if (N_states_der >= 1)
    {
      const double infinite_norm_overlap_average_der = infinite_norm_overlap_sum_der/N_states_der;
  
      const double infinite_norm_overlap_sigma_der = statistical_sigma_calc (N_states_der , infinite_norm_overlap_sum_der , infinite_norm_overlap_squares_sum_der);

      cout << "Maximal       |cluster overlap(wf , wf')|oo : " << max_infinite_norm_overlap_der << endl; 
      cout << "Average       |cluster overlap(wf , wf')|oo : " << infinite_norm_overlap_average_der << endl;
      cout << "Dispersion of |cluster overlap(wf , wf')|oo : " << infinite_norm_overlap_sigma_der << endl;
    }
}








// Calculation and MPI distribution of cluster Berggren basis states
// -----------------------------------------------------------------
// All radial wave functions are allocated and calculated here, as well as their integration constants C0 and C+/- .
// One radial wave function and its integration constants C0 and C+/- are calculated in wave_function_calculation (see above).
// Radial wave functions are distributed to all nodes afterwards, as nodes do not calculate all wave functions for efficiency, but must have all of them for the calculation of matrix elements.
// Poles and scattering states linear momenta and overlaps are printed on screen if is_there_cout is true.
// The time needed to calculate wave functions is also written on screen if is_there_cout is true.
//
// The overlaps between one-body states are calculated and printed as they should very small, as it they are equal to zero theoretically.

void cluster_CM_Berggren_basis::radial_wfs_overlaps_print_HO_overlaps_alloc_calc (
										  const bool is_there_cout , 
										  const bool is_first_cluster_used , 
										  const class interaction_class &inter_data ,
										  const class cluster_data &data_first_cluster ,
										  class cluster_data &data)
{	      
  const double reference_time = absolute_time_determine ();

  const enum potential_type basis_potential = data.get_basis_potential ();

  const int Lmax = data.get_Lmax ();

  const enum particle_type cluster = data.get_cluster ();
  
  const double J_intrinsic = data.get_J_intrinsic ();

  const class lj_table<int> &Nmax_cluster_projectile_CM_tab = data.get_Nmax_cluster_projectile_CM_tab ();

  const class nlj_table<complex<double> > &cluster_CM_K_tab_first_cluster = data_first_cluster.get_cluster_CM_K_tab (); 
  const class nlj_table<complex<double> > &cluster_CM_E_tab_first_cluster = data_first_cluster.get_cluster_CM_E_tab ();

  class nlj_table<complex<double> > &cluster_CM_K_tab = data.get_cluster_CM_K_tab (); 
  class nlj_table<complex<double> > &cluster_CM_E_tab = data.get_cluster_CM_E_tab ();

  //--// calculation of the u_NL (r , ... , k)
  //--// it finds the Cplus and Cminus values
  for (int L = 0 ; L <= Lmax ; L++) 
    {
      const double Jmin = abs (J_intrinsic - L);
      const double Jmax =      J_intrinsic + L;

      const int J_number = make_int (Jmax - Jmin) + 1;

      for (int J_index = 0 ; J_index < J_number ; J_index++)
	{
	  const double J = Jmin + J_index;

	  const int Nmax_LJ = Nmax_cluster_projectile_CM_tab(L , J);

	  for (int N = 0 ; N <= Nmax_LJ ; N++)
	    {	      
	      if (is_first_cluster_used)
		{
		  const complex<double> K_first_cluster = cluster_CM_K_tab_first_cluster(N , L , J);
		  const complex<double> E_first_cluster = cluster_CM_E_tab_first_cluster(N , L , J);

		  cluster_CM_K_tab(N , L , J) = K_first_cluster;
		  cluster_CM_E_tab(N , L , J) = E_first_cluster;
		}
	      else
		wave_function_calculation (is_there_cout , inter_data , N , L , J , data);
	    }
	}
    }

  if (!is_first_cluster_used) 
    {
      class nlj_table<class spherical_state> &cluster_CM_shells = data.get_cluster_CM_shells ();

#ifdef UseMPI
      if (is_it_MPI_parallelized)
	{
	  class nlj_table<complex<double> > &cluster_CM_K_tab = data.get_cluster_CM_K_tab ();
	  class nlj_table<complex<double> > &cluster_CM_E_tab = data.get_cluster_CM_E_tab ();

	  for (int L = 0 ; L <= Lmax ; L++) 
	    {
	      const double Jmin = abs (J_intrinsic - L);
	      const double Jmax =      J_intrinsic + L;

	      const int J_number = make_int (Jmax - Jmin) + 1;

	      for (int J_index = 0 ; J_index < J_number ; J_index++)
		{
		  const double J = Jmin + J_index;

		  const int Nmax_LJ = Nmax_cluster_projectile_CM_tab(L , J);

		  for (int N = 0 ; N <= Nmax_LJ ; N++)
		    {
		      const unsigned int index = cluster_CM_shells.index_determine (N , L , J);

		      const unsigned int Send_process = cluster_CM_shells.active_process_determine_for_MPI (NUMBER_OF_PROCESSES , index);

		      class spherical_state &cluster_CM_shell = cluster_CM_shells(N , L , J);

		      cluster_CM_shell.MPI_Bcast (Send_process , MPI_COMM_WORLD);

		      complex<double> cluster_CM_K_E[2] = {cluster_CM_K_tab(N , L , J) , cluster_CM_E_tab(N , L , J)};

		      MPI_helper::Bcast<complex<double> > (2 , cluster_CM_K_E , Send_process , MPI_COMM_WORLD);

		      if (THIS_PROCESS != Send_process) 
			{
			  cluster_CM_K_tab(N , L , J) = cluster_CM_K_E[0];
			  cluster_CM_E_tab(N , L , J) = cluster_CM_K_E[1];
			}
		    }
		}
	    }
	}
#endif

      if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
	{
	  const class nlj_table<bool> &cluster_CM_S_matrix_poles = data.get_cluster_CM_S_matrix_poles ();

	  const class nlj_table<complex<double> > &cluster_CM_E_tab = data.get_cluster_CM_E_tab ();

	  for (int L = 0 ; L <= Lmax ; L++) 
	    {
	      const double Jmin = abs (J_intrinsic - L);
	      const double Jmax =      J_intrinsic + L;

	      const int J_number = make_int (Jmax - Jmin) + 1;

	      for (int J_index = 0 ; J_index < J_number ; J_index++)
		{
		  const double J = Jmin + J_index;

		  const int Nmax_LJ = Nmax_cluster_projectile_CM_tab(L , J);

		  bool is_there_print = false;
		  
		  for (int N = 0 ; N <= Nmax_LJ ; N++)
		    {
		      const class spherical_state &cluster_CM_shell = cluster_CM_shells(N , L , J);

		      const bool S_matrix_pole = cluster_CM_S_matrix_poles(N , L , J);

		      if ((basis_potential == HO_POTENTIAL) || !S_matrix_pole)
			{
			  const complex<double> K = cluster_CM_shell.get_k ();

			  const complex<double> E_tilde = cluster_CM_E_tab(N , L , J);

			  const double E = real (E_tilde);

			  const double Gamma = -2000.0*imag (E_tilde);

			  cout << cluster_CM_shell << " " << cluster << " K : " << K << " fm^(-1) E : " << E << " MeV" << " G : " << Gamma << " keV" << endl;

			  is_there_print = true;			  
			}
		    }

		  if (is_there_print) cout << endl;
		}
	    }
	}

      if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) 
	{	
	  cout << endl;

	  print_overlaps_cluster (data);

	  const double now = absolute_time_determine () , relative_time = now - reference_time; 

	  cout << endl << cluster << " CM basis states calculated. time:" << relative_time << " s" << endl << endl;
	}

      data.HO_overlaps_CM_calc ();
    }
  else
    {
      data.set_HO_overlaps_cluster_CM (data_first_cluster.get_HO_overlaps_cluster_CM ());

      data.set_HO_overlaps_Fermi_cluster_CM (data_first_cluster.get_HO_overlaps_Fermi_cluster_CM ());
    }
}


