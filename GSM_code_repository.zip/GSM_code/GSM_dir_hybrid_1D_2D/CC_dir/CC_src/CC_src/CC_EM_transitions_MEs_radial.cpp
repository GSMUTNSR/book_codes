#include "../CC_include/CC_include_def.h"

using namespace EM_transitions_common;
using namespace EM_transitions_radial_OBMEs;
using namespace Wigner_signs;




// TYPE is double or complex
// -------------------------



// EM is electromagnetic
// ---------------------

// E is for electric
// -----------------

// M is for magnetic
// -----------------



// Calculation of the radial EM transition matrix element for a given suboperator between channel functions
// --------------------------------------------------------------------------------------------------------
// One calculates the radial part of <u[c[out]] || EM || u[c[in]]>.
//
// For u[c](r) functions solutions of GSM-CC, one uses complex scaling.
// The integral on [0:R] is calculate directly.
// The integral on [R:+oo[ is calculated with a change of variable so that one integrates on ]0:R^{-1/4}].
// u[c](r) = u[c]^+(r) + u[c]^-(r) (outgoing and incoming parts), so that four integrals are calculated on [R:+oo[ with complex scaling.
// Rotation angle is chosen for convergence to be the fastest for each u[c[in]]^{+/-}(r) u[c[out]]^{+/-}(r) product.
//
// For u[c](r) functions projected on the HO basis, radial integrals are directly calculated on [0:R] and [R:R[max]] and summed. 


// Calculation of the integral on [0:R] (see above)
// ------------------------------------------------

complex<double> CC_EM_transitions_MEs::radial::radial_integral_bef_R_calc (
									   const enum radial_operator_type radial_operator , 
									   const int L , 
									   const bool is_it_longwavelength_approximation , 
									   const class CC_state_class &CC_state_in , 
									   const class CC_state_class &CC_state_out , 
									   const unsigned int ic_in , 
									   const unsigned int ic_out)
{
  const bool is_it_radial_operator_with_r_derivative = is_it_radial_operator_with_r_derivative_determine (radial_operator);
  
  //--// positions and weights
  const class array<double> &r_bef_R_tab_GL = CC_state_out.get_r_bef_R_tab_GL ();
  const class array<double> &w_bef_R_tab_GL = CC_state_out.get_w_bef_R_tab_GL ();

  //--// tables containing the wfs of all channels
  const class array<complex<double> > &CC_wf_bef_R_tab_GL_in  = CC_state_in.get_CC_wf_bef_R_tab_GL ();
  const class array<complex<double> > &CC_wf_bef_R_tab_GL_out = CC_state_out.get_CC_wf_bef_R_tab_GL ();
  
  const class array<complex<double> > &CC_dwf_bef_R_tab_GL_in  = CC_state_in.get_CC_dwf_bef_R_tab_GL ();

  const complex<double> E_in  = CC_state_in.get_E ();
  const complex<double> E_out = CC_state_out.get_E ();

  const complex<double> q = (E_in - E_out) / hbar_c;
  
  //--// number of discretization points, and a factor of renormalization involvng the Bessel function of EM transition operators
  const unsigned int N_bef_R_GL = CC_state_out.get_N_bef_R_GL ();

  const complex<double> factor = double_factorial (2*L + 1)/(L + 1.0)/pow (q , L);

  class Coulomb_wave_functions Bessel(true , L , 0);

  complex<double> radial_integral_bef_R = 0.0;
  
  if (is_it_radial_operator_with_r_derivative)
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  const double r = r_bef_R_tab_GL(i);
	  const double w = w_bef_R_tab_GL(i); 

	  const complex<double> CC_dwf_bef_R_in_r = CC_dwf_bef_R_tab_GL_in (ic_in  , i);
	  const complex<double> CC_wf_bef_R_out_r = CC_wf_bef_R_tab_GL_out (ic_out , i);
      
	  const complex<double> Or = EM_transitions_radial_operator (radial_operator , q , L , is_it_longwavelength_approximation , factor ,  Bessel , r);

	  radial_integral_bef_R += w * CC_dwf_bef_R_in_r * Or * CC_wf_bef_R_out_r;
	}
    }
  else
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  const double r = r_bef_R_tab_GL(i);
	  const double w = w_bef_R_tab_GL(i); 

	  const complex<double> CC_wf_bef_R_in_r  = CC_wf_bef_R_tab_GL_in  (ic_in  , i);
	  const complex<double> CC_wf_bef_R_out_r = CC_wf_bef_R_tab_GL_out (ic_out , i);
      
	  const complex<double> Or = EM_transitions_radial_operator (radial_operator , q , L , is_it_longwavelength_approximation , factor ,  Bessel , r);

	  radial_integral_bef_R += w * CC_wf_bef_R_in_r * CC_wf_bef_R_out_r * Or;
	}
    }
  
  return radial_integral_bef_R;
}






// Calculation of one of the four integrals on [R:+oo[, i.e. involving u[c[in]]^{+/-} and u[c[in]]^{+/-} (see above)
// -----------------------------------------------------------------------------------------------------------------
complex<double> CC_EM_transitions_MEs::radial::radial_integral_aft_R_part_of_four_calc (
											const enum radial_operator_type radial_operator , 
											const int L , 
											const bool is_it_longwavelength_approximation , 
											const unsigned int asy_in , 
											const unsigned int asy_out , 
											const class CC_state_class &CC_state_in , 
											const class CC_state_class &CC_state_out , 
											const unsigned int ic_in , 
											const unsigned int ic_out)
{
  const bool is_it_radial_operator_with_r_derivative = is_it_radial_operator_with_r_derivative_determine (radial_operator);
  
  const unsigned int N_aft_R_GL = CC_state_in.get_N_aft_R_GL ();
  
  const complex<double> E_in  = CC_state_in.get_E ();
  const complex<double> E_out = CC_state_out.get_E ();

  const complex<double> q = (E_in - E_out) / hbar_c;
  
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const class array<double> &um4_table = CC_state_in.get_um4_aft_R_tab_GL ();
  
  const class array<double> &w_aft_R_tab_GL = CC_state_in.get_w_aft_R_tab_GL ();

  const complex<double> k_projectile_in = channel_c_in.get_k_projectile ();
  const complex<double> k_projectile_out = channel_c_out.get_k_projectile ();

  const complex<double> eta_projectile_in = channel_c_in.get_eta_projectile ();
  const complex<double> eta_projectile_out = channel_c_out.get_eta_projectile ();

  const int omega_in  = minus_one_pow (asy_in);
  const int omega_out = minus_one_pow (asy_out);

  const complex<double> Sk_projectile = k_projectile_in*omega_in + k_projectile_out*omega_out;

  const complex<double> I_omega_in(0 , omega_in);
  const complex<double> I_omega_out(0 , omega_out);

  const unsigned int angle_index = optimal_angle_index (Sk_projectile);

  const complex<double> exp_Itheta(cos_theta_tab[angle_index] , sin_theta_tab[angle_index]);

  const class array<complex<double> > &CC_sc_wf_minus_in_aft_R_c_entrance_tab_GL  = CC_state_in.get_CC_scaled_wf_minus_aft_R_c_entrance_tab_GL ();
  const class array<complex<double> > &CC_sc_wf_minus_out_aft_R_c_entrance_tab_GL = CC_state_out.get_CC_scaled_wf_minus_aft_R_c_entrance_tab_GL ();
  
  const class array<complex<double> > &CC_sc_wf_plus_in_aft_R_tab_GL  = CC_state_in.get_CC_scaled_wf_plus_aft_R_tab_GL ();
  const class array<complex<double> > &CC_sc_wf_plus_out_aft_R_tab_GL = CC_state_out.get_CC_scaled_wf_plus_aft_R_tab_GL ();
  
  const class array<complex<double> > &CC_sc_dwf_minus_in_aft_R_c_entrance_tab_GL  = CC_state_in.get_CC_scaled_wf_minus_aft_R_c_entrance_tab_GL ();
  
  const class array<complex<double> > &CC_sc_dwf_plus_in_aft_R_tab_GL  = CC_state_in.get_CC_scaled_wf_plus_aft_R_tab_GL ();
  
  const double R = CC_state_in.get_R ();

  const complex<double> factor = double_factorial (2*L + 1)/(L + 1.0)/pow (q , L);

  class Coulomb_wave_functions Bessel(true , L , 0);

  complex<double> radial_integral_aft_R_part_of_four = 0.0;

  if (is_it_radial_operator_with_r_derivative)
    {
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{ 
	  const complex<double> z = R + (um4_table(i) - R)*exp_Itheta;

	  const complex<double> k_projectile_in_z  = k_projectile_in*z;
	  const complex<double> k_projectile_out_z = k_projectile_out*z;

	  const complex<double> log_unscale_in  = (k_projectile_in  != 0.0) ? (I_omega_in *(k_projectile_in_z  - eta_projectile_in *(M_LN2 + log (k_projectile_in_z))))  : (0.0);
	  const complex<double> log_unscale_out = (k_projectile_out != 0.0) ? (I_omega_out*(k_projectile_out_z - eta_projectile_out*(M_LN2 + log (k_projectile_out_z)))) : (0.0);
      
	  const complex<double> unscale_weight = exp (log_unscale_in + log_unscale_out)*w_aft_R_tab_GL(i);

	  const complex<double> Oz_maybe_not_finite = EM_transitions_radial_operator (radial_operator , q , L , is_it_longwavelength_approximation , factor , Bessel , z);
      
	  const complex<double> Oz = (finite (Oz_maybe_not_finite)) ? (Oz_maybe_not_finite) : (0.0);

	  const complex<double> CC_sc_dwf_in_z = (asy_in == 0)  ? (CC_sc_dwf_plus_in_aft_R_tab_GL(ic_in  , angle_index , i)) : (CC_sc_dwf_minus_in_aft_R_c_entrance_tab_GL(angle_index , i));
	  const complex<double> CC_sc_wf_out_z = (asy_out == 0) ? (CC_sc_wf_plus_out_aft_R_tab_GL(ic_out , angle_index , i)) : (CC_sc_wf_minus_out_aft_R_c_entrance_tab_GL(angle_index , i));
	  
	  radial_integral_aft_R_part_of_four += CC_sc_dwf_in_z * Oz * CC_sc_wf_out_z * unscale_weight;
	}      
    }
  else
    {
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{ 
	  const complex<double> z = R + (um4_table(i) - R)*exp_Itheta;

	  const complex<double> k_projectile_in_z  = k_projectile_in*z;
	  const complex<double> k_projectile_out_z = k_projectile_out*z;

	  const complex<double> log_unscale_in  = (k_projectile_in  != 0.0) ? (I_omega_in *(k_projectile_in_z  - eta_projectile_in *(M_LN2 + log (k_projectile_in_z))))  : (0.0);
	  const complex<double> log_unscale_out = (k_projectile_out != 0.0) ? (I_omega_out*(k_projectile_out_z - eta_projectile_out*(M_LN2 + log (k_projectile_out_z)))) : (0.0);
      
	  const complex<double> unscale_weight = exp (log_unscale_in + log_unscale_out)*w_aft_R_tab_GL(i);

	  const complex<double> Oz_maybe_not_finite = EM_transitions_radial_operator (radial_operator , q , L , is_it_longwavelength_approximation , factor , Bessel , z);
      
	  const complex<double> Oz = (finite (Oz_maybe_not_finite)) ? (Oz_maybe_not_finite) : (0.0);

	  const complex<double> CC_sc_wf_in_z  = (asy_in == 0)  ? (CC_sc_wf_plus_in_aft_R_tab_GL (ic_in  , angle_index , i)) : (CC_sc_wf_minus_in_aft_R_c_entrance_tab_GL (angle_index , i));
	  const complex<double> CC_sc_wf_out_z = (asy_out == 0) ? (CC_sc_wf_plus_out_aft_R_tab_GL(ic_out , angle_index , i)) : (CC_sc_wf_minus_out_aft_R_c_entrance_tab_GL(angle_index , i));

	  radial_integral_aft_R_part_of_four += CC_sc_wf_in_z *  Oz * CC_sc_wf_out_z *unscale_weight;
	}
    }
  
  radial_integral_aft_R_part_of_four *= 4.0*exp_Itheta;
  
  return radial_integral_aft_R_part_of_four;
}






// Calculation of the sum of four integrals on [R:+oo[, i.e. involving u[c[in]]^{+/-} and u[c[in]]^{+/-} (see above)
// -----------------------------------------------------------------------------------------------------------------
complex<double> CC_EM_transitions_MEs::radial::radial_integral_aft_R_calc (
									   const enum radial_operator_type radial_operator , 
									   const int L , 
									   const bool is_it_longwavelength_approximation , 
									   const class CC_state_class &CC_state_in , 
									   const class CC_state_class &CC_state_out , 
									   const unsigned int ic_in , 
									   const unsigned int ic_out)
{
  const bool S_matrix_pole_in  = CC_state_in.get_S_matrix_pole ();
  const bool S_matrix_pole_out = CC_state_out.get_S_matrix_pole ();
  
  const unsigned int ic_entrance_in  = CC_state_in.get_ic_entrance ();
  const unsigned int ic_entrance_out = CC_state_out.get_ic_entrance ();

  const bool outgoing_in_case  = (S_matrix_pole_in  || (ic_in  != ic_entrance_in));
  const bool outgoing_out_case = (S_matrix_pole_out || (ic_out != ic_entrance_out));

  complex<double> integral_aft_R = 0.0;

  for (unsigned int asy_in = 0 ; (outgoing_in_case) ? (asy_in <= 0) : (asy_in <= 1) ; asy_in++)
    for (unsigned int asy_out = 0 ; (outgoing_out_case) ? (asy_out <= 0) : (asy_out <= 1) ; asy_out++)
      integral_aft_R += radial_integral_aft_R_part_of_four_calc (radial_operator , L , is_it_longwavelength_approximation , asy_in , asy_out , CC_state_in , CC_state_out , ic_in , ic_out);

  return integral_aft_R;
}




// Calculation of the integrals on [R:R[max] of u[c](r) functions (in practice projected on the HO basis)
// ------------------------------------------------------------------------------------------------------
complex<double> CC_EM_transitions_MEs::radial::radial_integral_aft_R_real_calc (
										const enum radial_operator_type radial_operator , 
										const int L , 
										const bool is_it_longwavelength_approximation , 
										const class CC_state_class &CC_state_in , 
										const class CC_state_class &CC_state_out , 
										const unsigned int ic_in , 
										const unsigned int ic_out)
{
  //--// positions and weights
  const class array<double> &r_aft_R_tab_GL_real = CC_state_out.get_r_aft_R_tab_GL_real ();
  const class array<double> &w_aft_R_tab_GL_real = CC_state_out.get_w_aft_R_tab_GL_real ();

  //--// tables containing the wfs of all channels
  const class array<complex<double> > &CC_wf_aft_R_tab_GL_in  = CC_state_in.get_CC_wf_aft_R_tab_GL ();
  const class array<complex<double> > &CC_wf_aft_R_tab_GL_out = CC_state_out.get_CC_wf_aft_R_tab_GL ();

  //--// number of discretization points, and a factor of renormalization involvng the Bessel function of EM transition operators
  const unsigned int N_aft_R_GL = CC_state_out.get_N_aft_R_GL ();

  const complex<double> E_in  = CC_state_in.get_E ();
  const complex<double> E_out = CC_state_out.get_E ();

  const complex<double> q = (E_in - E_out) / hbar_c;
  
  const complex<double> factor = double_factorial (2*L + 1)/(L + 1.0)/pow (q , L);

  class Coulomb_wave_functions Bessel(true , L , 0);

  complex<double> radial_integral_aft_R = 0.0;

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      const double r = r_aft_R_tab_GL_real(i);
      const double w = w_aft_R_tab_GL_real(i); 

      const complex<double> CC_wf_aft_R_in_r  = CC_wf_aft_R_tab_GL_in  (ic_in  , i);
      const complex<double> CC_wf_aft_R_out_r = CC_wf_aft_R_tab_GL_out (ic_out , i);
      
      const complex<double> Or = EM_transitions_radial_operator (radial_operator , q , L , is_it_longwavelength_approximation , factor , Bessel , r);

      radial_integral_aft_R += w * CC_wf_aft_R_in_r * CC_wf_aft_R_out_r * Or;
    }

  return radial_integral_aft_R;
}




// Calculation of the radial EM transition matrix element between channel functions (see above)
// --------------------------------------------------------------------------------------------
TYPE CC_EM_transitions_MEs::radial::radial_integral_calc ( 
							  const enum radial_operator_type radial_operator , 
							  const int L , 
							  const bool is_it_longwavelength_approximation ,
							  const class CC_state_class &CC_state_in , 
							  const class CC_state_class &CC_state_out , 
							  const unsigned int ic_in , 
							  const unsigned int ic_out)
{
  const complex<double> radial_integral_bef_R = radial_integral_bef_R_calc (radial_operator , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  
  const bool is_it_HO_projected_in  = CC_state_in.get_is_it_HO_projected ();
  const bool is_it_HO_projected_out = CC_state_out.get_is_it_HO_projected ();

  if (is_it_HO_projected_in || is_it_HO_projected_out)
    {
      const complex<double> radial_integral_aft_R = radial_integral_aft_R_real_calc (radial_operator , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
      
      const complex<double> radial_integral = radial_integral_bef_R + radial_integral_aft_R;
      
#ifdef TYPEisDOUBLECOMPLEX
      return radial_integral;  
#endif
      
#ifdef TYPEisDOUBLE
      return real (radial_integral);  
#endif
    }

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const bool S_matrix_pole_in  = CC_state_in.get_S_matrix_pole ();
  const bool S_matrix_pole_out = CC_state_out.get_S_matrix_pole ();

  const complex<double> k_projectile_in  = channel_c_in.get_k_projectile ();
  const complex<double> k_projectile_out = channel_c_out.get_k_projectile ();

  const unsigned int ic_entrance_in  = CC_state_in.get_ic_entrance ();
  const unsigned int ic_entrance_out = CC_state_out.get_ic_entrance ();

  const bool outgoing_in_case  = (S_matrix_pole_in  || (ic_in  != ic_entrance_in));
  const bool outgoing_out_case = (S_matrix_pole_out || (ic_out != ic_entrance_out));

  for (unsigned int asy_in = 0 ; (outgoing_in_case) ? (asy_in <= 0) : (asy_in <= 1) ; asy_in++)
    for (unsigned int asy_out = 0 ; (outgoing_out_case) ? (asy_out <= 0) : (asy_out <= 1) ; asy_out++)
      { 
	const complex<double> Sk_projectile = k_projectile_in*minus_one_pow (asy_in) + k_projectile_out*minus_one_pow (asy_out);
	
	if ((inf_norm (Sk_projectile) < precision) && !S_matrix_pole_in && !S_matrix_pole_out) 
	  error_message_print_abort ("Complex scaling impossible in CC_EM_transitions_MEs::radial::radial_integral_calc");
      }

  const complex<double> radial_integral_aft_R = radial_integral_aft_R_calc (radial_operator , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  
  const complex<double> radial_integral = radial_integral_bef_R + radial_integral_aft_R;
  
#ifdef TYPEisDOUBLECOMPLEX
  return radial_integral;  
#endif
      
#ifdef TYPEisDOUBLE
  return real (radial_integral);  
#endif
}



