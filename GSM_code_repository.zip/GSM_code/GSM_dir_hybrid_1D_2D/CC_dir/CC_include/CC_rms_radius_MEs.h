#ifndef CC_RMS_RADIUS_MES_H
#define CC_RMS_RADIUS_MES_H

namespace CC_rms_radius_MEs
{ 	
  namespace radial
  {
    //--// return the radial part of <uc_f lf jf | Rrms^2 | uc_i li ji> before R
    complex<double> radial_integral_bef_R_calc (
						const enum radial_operator_type radial_operator ,
						const class CC_state_class &CC_state,
						const unsigned int ic_in,
						const unsigned int ic_out);

    //--// return the radial part of <uc_f^(+/-) lf jf | Rrms^2 | uc_i^(+/-) li ji> after R
    complex<double> radial_integral_aft_R_part_of_four_calc (
							     const enum radial_operator_type radial_operator ,
							     const unsigned int asy_in,
							     const unsigned int asy_out,
							     const class CC_state_class &CC_state,
							     const unsigned int ic_in,
							     const unsigned int ic_out);
    
    //--// return the radial part of <uc_f lf jf | Rrms^2 | uc_i li ji> after R
    complex<double> radial_integral_aft_R_calc (
						const enum radial_operator_type radial_operator ,
						const class CC_state_class &CC_state,
						const unsigned int ic_in,
						const unsigned int ic_out);

    //--// return the radial part of <uc_f lf jf | Rrms^2 | uc_i li ji> after R without complex scaling as wave functions are localized therein.
    complex<double> radial_integral_aft_R_real_calc (
						     const enum radial_operator_type radial_operator ,
						     const class CC_state_class &CC_state,
						     const unsigned int ic_in,
						     const unsigned int ic_out);

    //--// return the radial part of <uc_f lf jf | Rrms^2 | uc_i li ji>
    TYPE radial_integral_calc (
			       const enum radial_operator_type radial_operator ,
			       const class CC_state_class &CC_state,
			       const unsigned int ic_in,
			       const unsigned int ic_out);
  }

  namespace one_baryon
  {
    //--// return <uc_f lf jf | Rrms^2 | uc_i li ji>
    TYPE OBME_calc (
		    const double rms_radius_factor ,
		    const class CC_state_class &CC_state,
		    const unsigned int ic_in,
		    const unsigned int ic_out);
  }

  namespace cluster
  {
    // calculates <PSI[intrinsic-cluster-c'] | Rrms^2 | PSI[intrinsic-cluster-c]>.
    void rms_radius_intrinsic_MEs_calc (
					const enum operator_type rms_radius_op,
					const class input_data_str &input_data_CC_Berggren , 
					class array<class cluster_data> &cluster_projectile_data_tab,
					class CC_target_projectile_composite_data &Tpc_data , 
					class GSM_vector &PSI_full);
    
    //--// return <uc_f lf jf | Rrms^2 | uc_i li ji>
    TYPE ME_calc (
		  const class CC_target_projectile_composite_data &Tpc_data , 
		  const double rms_radius_CM_factor ,
		  const unsigned int ic , 
		  const unsigned int icp , 
		  const class CC_state_class &CC_state , 
		  const unsigned int ic_in , 
		  const unsigned int ic_out);
  }

  namespace composite
  {
    TYPE target_projectile_as_HO_NBME_calc (
					    class GSM_vector &PSI_full , 
					    const bool is_it_one_baryon_COSM_case , 
					    const enum operator_type rms_radius_op , 
					    const bool is_it_HO_expansion , 
					    const class CC_Hamiltonian_data &CC_H_data , 
					    const class CC_state_class &CC_state , 
					    const class input_data_str &input_data_CC_Berggren , 
					    class baryons_data &prot_Y_data , 
					    class baryons_data &neut_Y_data ,
					    const class array<class cluster_data> &cluster_projectile_data_tab); 
    
    TYPE target_nas_NBME_calc (
			       const class CC_target_projectile_composite_data &Tpc_data , 
			       const class CC_state_class &CC_state , 
			       const class array<TYPE> &target_NBMEs);

 
    TYPE projectile_nas_NBME_calc (
				   const enum operator_type rms_radius_op , 
				   const int N_particle ,
				   const class input_data_str &input_data_CC_Berggren , 
				   const class CC_target_projectile_composite_data &Tpc_data , 
				   const class CC_state_class &CC_state , 
				   const class array<class cluster_data> &cluster_projectile_data_tab);

    void target_NBMEs_calc (
			    class GSM_vector &PSI_full ,
			    const enum interaction_type inter ,
			    const enum operator_type rms_radius_op ,
			    const bool is_it_HO_expansion ,
			    const bool full_common_vectors_used_in_file ,
			    const class CC_target_projectile_composite_data &Tpc_data , 
			    class array<class baryons_data> &prot_Y_data_one_cluster_less_tab , 
			    class array<class baryons_data> &neut_Y_data_one_cluster_less_tab , 
			    class array<TYPE> &target_NBMEs);

    TYPE CC_NBME_calc (
		       const enum operator_type rms_radius_op ,
		       const int N_particle ,  
		       const bool is_it_HO_expansion , 
		       const bool is_it_nas_only , 
		       const class CC_target_projectile_composite_data &Tpc_data , 
		       const class array<class cluster_data> &cluster_projectile_data_tab , 
		       const class CC_Hamiltonian_data &CC_H_data , 
		       const class CC_state_class &CC_state , 
		       class baryons_data &prot_Y_data , 
		       class baryons_data &neut_Y_data , 
		       const class input_data_str &input_data_CC_Berggren , 
		       const class array<TYPE> &target_NBMEs ,
		       class GSM_vector &PSI_full);
  }
}

#endif


