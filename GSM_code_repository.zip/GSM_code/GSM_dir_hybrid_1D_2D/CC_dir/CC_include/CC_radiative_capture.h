#ifndef CC_RADIATIVECAPTURE_H
#define CC_RADIATIVECAPTURE_H

namespace CC_radiative_capture
{
  // cf_<J_Tf || M/E_L (T); || J_Ti>_ci NBMEs stored
  void target_reduced_NBMEs_calc (
				  class GSM_vector &PSI_full , 
				  const enum EM_type EM ,
				  const bool full_common_vectors_used_in_file ,
				  const class CC_target_projectile_composite_data &Tpc_data , 
				  const class interaction_class &inter_data_basis ,
				  class array<class nucleons_data> &prot_data_one_cluster_less_tab,
				  class array<class nucleons_data> &neut_data_one_cluster_less_tab,
				  const class array<TYPE> &CC_E_A_tab_out ,
				  class array<TYPE> &target_reduced_NBMEs);

  void CC_state_out_tab_alloc_calc (
				    const class CC_target_projectile_composite_data &Tpc_data , 
				    const class interaction_class &inter_data_basis , 
				    const class input_data_str &input_data_CC_Berggren ,
				    const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
				    const class HF_nucleons_data &neut_HF_data_CC_Berggren ,
				    const class array<class cluster_data> &cluster_projectile_data_tab, 
				    class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab, 
				    class nucleons_data &prot_data_CC_Berggren , 
				    class nucleons_data &neut_data_CC_Berggren ,  
				    class nucleons_data &prot_data , 
				    class nucleons_data &neut_data ,
				    class TBMEs_class &TBMEs_pn ,
				    class array<class CC_Hamiltonian_data> &CC_H_data_out_tab , 
				    class array<class CC_state_class> &CC_state_tab_out, 
				    class array<TYPE> &CC_E_A_tab_out);

  void CC_state_in_entrance_tab_alloc_calc ( 
					    const class CC_target_projectile_composite_data &Tpc_data , 
					    const class interaction_class &inter_data_basis , 
					    const class input_data_str &input_data_CC_Berggren ,
					    const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
					    const class HF_nucleons_data &neut_HF_data_CC_Berggren ,
					    const class array<class cluster_data> &cluster_projectile_data_tab, 
					    class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
					    const unsigned int iE,
					    const TYPE &E ,
					    class nucleons_data &prot_data_CC_Berggren , 
					    class nucleons_data &neut_data_CC_Berggren ,  
					    class nucleons_data &prot_data , 
					    class nucleons_data &neut_data ,
					    class TBMEs_class &TBMEs_pn,
					    class array<class CC_Hamiltonian_data> &CC_H_data_in_tab , 
					    class array<class CC_state_class> &CC_state_in_entrance_tab);


  void CC_EM_NBMEs_calc_fixed_out_in_entrance (
					       class GSM_vector &PSI_full , 
					       const class CC_target_projectile_composite_data &Tpc_data , 
					       const class array<class cluster_data> &cluster_projectile_data_tab,
					       const class input_data_str &input_data_CC_Berggren ,
					       const bool is_it_nas_only,
					       const unsigned int iJPi_A_in , 
					       const unsigned int iJPi_A_out , 
					       const enum EM_type EM_for_total_cross_section , 
					       const unsigned int i_ent , 
					       const unsigned int iE ,
					       const class CC_Hamiltonian_data &CC_H_data_in , 
					       const class CC_state_class &CC_state_in_i_ent , 
					       const class CC_Hamiltonian_data &CC_H_data_out ,  
					       const class CC_state_class &CC_state_out , 
					       class nucleons_data &prot_data , 
					       class nucleons_data &neut_data ,
					       const class interaction_class &inter_data_basis ,	
					       const class array<TYPE> &target_reduced_NBMEs ,
					       class array<TYPE> &CC_EM_NBMEs);

  // calculations of the EM matrix elts < (J_i);_i_ent || O_L || J_f >
  void CC_EM_NBMEs_calc (  
			 class GSM_vector &PSI_full , 
			 const class CC_target_projectile_composite_data &Tpc_data ,
			 const class array<class cluster_data> &cluster_projectile_data_tab,
			 const bool is_it_nas_only,
			 const enum EM_type EM ,
			 const class array<TYPE> &target_reduced_NBMEs ,
			 const class input_data_str &input_data_CC_Berggren ,
			 const class interaction_class &inter_data_basis , 
			 class nucleons_data &prot_data , 
			 class nucleons_data &neut_data ,
			 const unsigned int iE ,
			 const double E_kinetic_projectile_CM ,
			 const class array<class CC_Hamiltonian_data> &CC_H_data_out_tab , 
			 const class array<class CC_state_class> &CC_state_tab_out ,
			 const class array<class CC_Hamiltonian_data> &CC_H_data_in_tab ,  
			 const class array<class CC_state_class> &CC_state_in_entrance_tab ,
			 class array<TYPE> &CC_EM_NBMEs);
  
  void EM_suboperators_intrinsic_MEs_calc (
					   const class interaction_class &inter_data_basis ,
					   class array<class cluster_data> &cluster_projectile_data_tab,
					   const class array<TYPE> &CC_E_A_tab_out ,
					   class CC_target_projectile_composite_data &Tpc_data,
					   class GSM_vector &PSI_full);

  void iterative_calc (
		       const class CC_target_projectile_composite_data &Tpc_data , 
		       const class input_data_str &input_data_CC_Berggren , 
		       const class interaction_class &inter_data_basis , 
		       const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
		       const class HF_nucleons_data &neut_HF_data_CC_Berggren ,
		       const class array<class cluster_data> &cluster_projectile_data_tab , 
		       class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab ,
		       class nucleons_data &prot_data_CC_Berggren , 
		       class nucleons_data &neut_data_CC_Berggren ,
		       class nucleons_data &prot_data , 
		       class nucleons_data &neut_data ,  
		       class TBMEs_class &TBMEs_pn,
		       class array<TYPE> &CC_E_A_tab_out,
		       class array<TYPE> &CC_EM_NBMEs , 
		       class GSM_vector &PSI_full);

  complex<double> angular_factor_calc (
				       const int L , const double M_L , 
				       const int P , 
				       const double k_cross_section , 
				       const double k_gamma , 
				       const double theta_gamma , const double phi_gamma);

  void angular_factor_tabs_calc (
				 const double k_cross_section,
				 const double E_i,
				 const class array<TYPE> &CC_E_A_tab_out,
				 const class array<double> &theta_gamma_tab,
				 const class array<double> &phi_gamma_tab,
				 class array<complex<double> > &angular_factor_plus_tab,
				 class array<complex<double> > &angular_factor_minus_tab);

  void Wigner_Eckhart_factor_tab_calc (
				       const class CC_target_projectile_composite_data &Tpc_data , 
				       const enum EM_type EM ,
				       class array<double> &Wigner_Eckhart_factor_tab);

  void product_CGs_l_terms_Coulomb_phase_shifts_tab_calc (	
							  const class CC_target_projectile_composite_data &Tpc_data , 
							  const double J_intrinsic_projectile ,
							  const double eta_cross_section ,
							  class array<complex<double> > &product_CGs_l_terms_Coulomb_phase_shifts_tab);
  
  // differential cross section calc
  void differential_cross_section_calc (
					const class CC_target_projectile_composite_data &Tpc_data , 
					const class array<TYPE> &CC_EM_NBMEs , 
					const class array<TYPE> &CC_E_A_tab_out,
					const class array<double> &theta_gamma_tab , 
					const class array<double> &phi_gamma_tab ,
					const unsigned int iE , 
					const double E_kinetic_projectile_CM ,
					const TYPE &E ,
					const enum EM_type EM ,
					class array<double> &differential_cross_section_tab);

  void all_cross_sections_calc_print (
				      const enum interaction_type inter ,
				      const class CC_target_projectile_composite_data &Tpc_data , 
				      const class array<TYPE> &CC_E_A_tab_out,
				      const class array<TYPE> &CC_EM_NBMEs);

  void cross_sections_calc_print (
				  const enum interaction_type inter ,
				  const class CC_target_projectile_composite_data &Tpc_data , 
				  const class array<double> &theta_gamma_tab, 
				  const class array<double> &weights_theta_gamma_tab, 
				  const class array<double> &phi_gamma_tab,
				  const class array<double> &weights_phi_gamma_tab,
				  const class array<double> &differential_cross_section_tab);

  void calc_print (
		   const class input_data_str &input_data_CC_Berggren ,  
		   const class interaction_class &inter_data_basis , 
		   const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
		   const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
		   class nucleons_data &prot_data_CC_Berggren , 
		   class nucleons_data &neut_data_CC_Berggren , 
		   class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab ,
		   class nucleons_data &prot_data , 
		   class nucleons_data &neut_data ,
		   class array<class cluster_data> &cluster_projectile_data_tab ,
		   class CC_target_projectile_composite_data &Tpc_data ,
		   class TBMEs_class &TBMEs_pn);
}

#endif


