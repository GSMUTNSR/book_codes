#ifndef CC_MULTIPOLESPOLES_H
#define CC_MULTIPOLESPOLES_H

namespace CC_multipoles_poles
{
  TYPE calc (
	     const int L ,
	     const bool is_it_HO_expansion , 
	     const bool is_it_nas_only ,
	     const class CC_target_projectile_composite_data &Tpc_data , 
	     const class input_data_str &input_data_CC_Berggren , 
	     const class interaction_class &inter_data_basis ,  
	     const class array<class cluster_data> &cluster_data_tab ,  
	     const class CC_Hamiltonian_data &CC_H_data , 
	     const class CC_state_class &CC_state , 
	     class nucleons_data &prot_data , 
	     class nucleons_data &neut_data ,
	     class GSM_vector &PSI_full);

  void calc_print (
		   const class input_data_str &input_data ,
		   const class input_data_str &input_data_CC_Berggren ,  
		   const class interaction_class &inter_data_basis , 
		   const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
		   const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
		   class nucleons_data &prot_data_CC_Berggren , 
		   class nucleons_data &neut_data_CC_Berggren , 
		   class array<class cluster_data> &cluster_data_CC_Berggren_tab , 
		   class nucleons_data &prot_data , 
		   class nucleons_data &neut_data , 
		   class array<class cluster_data> &cluster_data_tab , 
		   class CC_target_projectile_composite_data &Tpc_data , 
		   class TBMEs_class &TBMEs_pn);
}

#endif


