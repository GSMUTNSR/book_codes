#ifndef CC_INCLUDE_DEF_H
#define CC_INCLUDE_DEF_H

#include "../../GSM_include/GSM_include_def.h"

#include "../../../GSM_dir_common/CC_dir/CC_include/CC_include_def_common.h"

#include "CC_cluster_data_small_routines.h"
#include "CC_cluster_CM_Berggren_basis.h"
#include "CC_H_CM_OBMEs.h"
#include "CC_state_class.h"
#include "CC_waves_HF_MSDHF_potentials_calculations.h"
#include "CC_potentials_one_nucleon.h"
#include "CC_EM_transitions_MEs.h"
#include "CC_potentials_cluster.h"
#include "CC_Hamiltonian_data.h"
#include "CC_radiative_capture.h"
#include "CC_H_a_dagger_nucleon_forbidden_channels.h"
#include "CC_scattering_cross_section.h"
#include "CC_H_A_dagger_cluster_forbidden_channels.h"
#include "CC_H_MEs_one_nucleon.h"
#include "CC_H_MEs_cluster.h"
#include "CC_rms_radius_MEs.h"
#include "CC_multipoles_MEs.h"
#include "CC_scalar_strength_MEs.h"
#include "CC_rms_radius_poles.h"
#include "CC_multipoles_poles.h"
#include "CC_rms_radius_one_body_strength_poles.h"
#include "CC_density_poles.h"
#include "CC_EM_transitions_MEs.h"
#include "CC_EM_transitions_poles.h"
#include "CC_EM_transitions_strength_MEs.h"
#include "CC_observables_common.h"
#include "CC_EM_transitions_strength_poles.h"
#include "CC_overlap_function_composite.h"
#include "CC_overlap_function_poles.h"
#include "CC_spectroscopic_factor_poles.h"
#include "CC_beta_transitions_MEs.h"
#include "CC_beta_transitions_poles.h"
#include "CC_beta_transitions_strength_MEs.h"
#include "CC_beta_transitions_strength_poles.h"
#endif


