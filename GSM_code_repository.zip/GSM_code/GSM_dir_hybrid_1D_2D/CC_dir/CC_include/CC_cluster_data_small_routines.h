#ifndef CCCLUSTERDATASMALLROUTINES_H
#define CCCLUSTERDATASMALLROUTINES_H

namespace CC_cluster_data_small_routines
{
  int Nmax_HO_clusters_calc (const class array<class cluster_data> &cluster_projectile_data_tab);

  unsigned int cluster_data_index_determine (
					     const enum particle_type cluster ,
					     const class array<class cluster_data> &cluster_projectile_data_tab);

  unsigned int cluster_data_index_determine (
					     const enum particle_type cluster ,
					     const class array<enum particle_type> &CC_cluster_tab);

  unsigned int first_cluster_data_index_determine (
						   const enum particle_type cluster ,
						   const class array<enum particle_type> &CC_cluster_tab);

  const class cluster_data & get_cluster_projectile_data (
					       const enum particle_type cluster ,
					       const class array<class cluster_data> &cluster_projectile_data_tab);

  class cluster_data & get_cluster_projectile_data (
					 const enum particle_type cluster ,
					 class array<class cluster_data> &cluster_projectile_data_tab);

  const class cluster_data & get_first_cluster_data (
						     const enum particle_type cluster ,
						     const class array<class cluster_data> &cluster_projectile_data_tab);

  class cluster_data & get_first_cluster_data (
					       const enum particle_type cluster ,
					       class array<class cluster_data> &cluster_projectile_data_tab);

  int Z_cluster_max_determine (const class array<class cluster_data> &cluster_projectile_data_tab);

  int N_cluster_max_determine (const class array<class cluster_data> &cluster_projectile_data_tab);

  int nmax_all_determine (
			  const bool is_it_one_nucleon_COSM_case , 
			  const class array<class CC_channel_class> &channels_tab , 
			  const class nucleons_data &prot_data , 
			  const class nucleons_data &neut_data ,
			  const class array<class cluster_data> &cluster_projectile_data_tab);

  void cluster_projectile_data_tab_alloc_calc (
				    const bool is_it_GSM_basis , 
				    const bool is_it_CM_HO_basis,
				    class input_data_str &input_data , 
				    const class nucleons_data &prot_data , 
				    const class nucleons_data &neut_data , 
				    const class interaction_class &inter_data_basis , 
				    class array<class cluster_data> &cluster_projectile_data_tab);

  void cluster_projectile_data_tab_PCM_matrices_alloc_calc ( 
						 const class interaction_class &inter_data_basis , 
						 class input_data_str &input_data , 
						 const class nucleons_data &prot_data , 
						 const class nucleons_data &neut_data , 
						 class array<class cluster_data> &cluster_projectile_data_tab ,
						 class input_data_str &input_data_CC_Berggren , 
						 const class nucleons_data &prot_data_CC_Berggren , 
						 const class nucleons_data &neut_data_CC_Berggren , 
						 class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab);
}

#endif


