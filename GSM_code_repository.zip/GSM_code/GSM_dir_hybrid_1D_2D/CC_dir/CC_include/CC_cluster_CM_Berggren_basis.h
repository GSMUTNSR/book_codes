#ifndef GSMCLUSTERCMBERGGRENBASIS_H
#define GSMCLUSTERCMBERGGRENBASIS_H

namespace cluster_CM_Berggren_basis
{
  void wave_function_calculation (
				  const bool is_there_cout , 
				  const class interaction_class &inter_data , 
				  const int N , 
				  const int L , 
				  const double J , 
				  class cluster_data &data);
  
  void print_overlaps_cluster (const class cluster_data &data);

  void radial_wfs_overlaps_print_HO_overlaps_alloc_calc (
							 const bool is_there_cout , 
							 const bool is_first_cluster_used ,
							 const class interaction_class &inter_data ,
							 const class cluster_data &data_first_cluster ,
							 class cluster_data &data);
}

#endif


