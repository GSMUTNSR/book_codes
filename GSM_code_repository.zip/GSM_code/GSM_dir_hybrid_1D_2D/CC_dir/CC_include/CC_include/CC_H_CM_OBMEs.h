#ifndef CCHCMOBMES_H
#define CCHCMOBMES_H

namespace CC_H_CM_OBMEs
{
  namespace one_baryon_CM
  {
    double OBME_h_basis_potential_calc (
					const enum particle_type particle ,
					const int l , 
					const double j , 
					const int n_HO_in , 
					const int n_HO_out , 
					const class CG_str &CGs , 
					const class interaction_class &inter_data_basis , 
					const class array<double> &Gaussian_table_GL , 
					const class multipolar_expansion_str &multipolar_expansion , 
					const class HF_nucleons_data &prot_HF_data , 
					const class HF_nucleons_data &neut_HF_data , 
					const class baryons_data &prot_Y_data_one_config_GSM , 
					const class baryons_data &neut_Y_data_one_config_GSM , 
					const class baryons_data &neut_Y_data_CC_Berggren , 
					const class baryons_data &data_CC_Berggren);

    double OBME_h_basis_calc (
			      const enum particle_type particle ,
			      const int l , 
			      const double j , 
			      const int n_HO_in , 
			      const int n_HO_out , 
			      const class CG_str &CGs , 
			      const class interaction_class &inter_data_basis , 
			      const class array<double> &Gaussian_table_GL , 
			      const class multipolar_expansion_str &multipolar_expansion , 
			      const class HF_nucleons_data &prot_HF_data , 
			      const class HF_nucleons_data &neut_HF_data , 
			      const class baryons_data &prot_Y_data_one_config_GSM , 
			      const class baryons_data &neut_Y_data_one_config_GSM , 
			      const class baryons_data &neut_Y_data_CC_Berggren , 
			      const class baryons_data &data_CC_Berggren);
  }

  namespace cluster_CM
  {
    double H_potential_CC_OBME_HO_basis_calc (
					      const int L , 
					      const double J , 
					      const int N_HO_in , 
					      const int N_HO_out , 
					      const class cluster_data &data);

    double H_OBME_calc (
			const int L , 
			const double J , 
			const int N_HO_in , 
			const int N_HO_out , 
			const class cluster_data &data);
  }
}

#endif


