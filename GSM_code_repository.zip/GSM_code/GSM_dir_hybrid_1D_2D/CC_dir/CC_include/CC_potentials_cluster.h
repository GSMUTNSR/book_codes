#ifndef CC_POTENTIALS_CLUSTER_H
#define CC_POTENTIALS_CLUSTER_H

namespace CC_potentials_cluster
{
  /* Calculation of the initial potentials (before rendering them local): see CC_potentials_init.cpp */
  void orthogonalized_H_matrix_CC_Berggren_calc (
						 const class array<class CC_channel_class> &channels_tab  ,  
						 const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab  ,  
						 class CC_Hamiltonian_data &CC_H_data);

  void overlaps_and_H_matrices_cell_calc ( 
					  const class GSM_vector &V_in , 
					  const class GSM_vector &HV_in , 
					  const enum particle_type particle_projectile_cp , 
					  const int NCM_HO_cp , 
					  const int LCM_projectile_cp , 
					  const class correlated_state_str &PSI_projectile_qn_cp , 
					  const class correlated_state_str &PSI_qn_Tcp  ,  
					  const unsigned int index_in ,  
					  const unsigned int index_out , 
					  const double J ,	
					  class array<class GSM_vector> &V_out_tab , 
					  class matrix<complex<double> > &overlaps_matrix , 
					  class matrix<complex<double> > &H_matrix);

  void overlaps_and_H_matrices_calc (
				     const bool print_detailed_information ,
				     const class array<class CC_channel_class> &channels_tab , 
				     const class array<class cluster_data> &cluster_projectile_data_tab ,  
				     const double J , 
				     class GSM_vector &V_in , 
				     class GSM_vector &HV_in , 
				     class CC_Hamiltonian_data &CC_H_data);

  void potentials_overlaps_calc (
				 const class input_data_str &input_data , 
				 const bool are_GSM_a_dagger_vectors_calculated , 
				 const class array<class CC_channel_class> &channels_tab ,  
				 const class array<class cluster_data> &cluster_projectile_data_tab , 
				 const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab  ,  
				 const double J ,  
				 const double M ,  
				 const unsigned int BP ,  
				 class nucleons_data &prot_data ,  
				 class nucleons_data &neut_data , 
				 class TBMEs_class &TBMEs_pn  ,  
				 class CC_Hamiltonian_data &CC_H_data);

  void potential_diagonal_init (
				const bool is_it_entrance_channel_only , 
				class array<complex<double> > &Ueq_tab ,  
				const class CC_state_class &CC_state ,  
				const class array<class cluster_data> &cluster_projectile_data_tab);

  void Ueq_source_calc (
			const bool is_it_entrance_channel_only_iterative , 
			const bool is_it_entrance_channel_only , 
			const bool is_it_symmetrized , 	
			const double new_potential_fraction , 
			const class CC_state_class &CC_state , 
			const class array<class cluster_data> &cluster_projectile_data_tab ,  
			class CC_Hamiltonian_data &CC_H_data);
}

#endif


