#ifndef CCHADAGGERNUCLEONFORBIDDENCHANNELSH
#define CCHADAGGERNUCLEONFORBIDDENCHANNELSH

namespace CC_H_a_dagger_baryon_forbidden_channels
{
  void a_dagger_baryon_calculations_and_copy_disk (
						    const bool print_detailed_information , 
						    const double CC_average_n_scat_target_projectile_max , 
						    const bool full_common_vectors_used_in_file , 
						    const class array<class CC_channel_class> &channels_tab ,  
						    const class baryons_data &prot_Y_data ,  
						    const class baryons_data &neut_Y_data , 
						    const double J ,  
						    const class J2_class &J2 , 
						    class GSM_vector &Vstore , 
						    class GSM_vector &a_dagger_PSI_c_coupled);

  void is_it_forbidden_channel_tab_calc (
					 const bool print_detailed_information , 
					 const double CC_average_n_scat_target_projectile_max , 
					 const double CC_forbidden_channel_precision , 
					 const class array<class CC_channel_class> &channels_tab , 
					 const class baryons_data &prot_Y_data ,  
					 const class baryons_data &neut_Y_data , 
					 const double J ,   
					 class GSM_vector &V_in , 
					 class array<bool> &is_it_forbidden_channel_tab);

  void H_a_dagger_baryon_calculations_and_copy_disk (
						      const bool print_detailed_information , 
						      const double CC_average_n_scat_target_projectile_max ,
						      const class array<class CC_channel_class> &channels_tab ,  
						      const class baryons_data &prot_Y_data ,  
						      const class baryons_data &neut_Y_data ,  
						      const class array<bool> &is_it_forbidden_channel_tab , 
						      const double J , 
						      const class J2_class &J2 , 
						      const class H_class &H ,  
						      class GSM_vector &a_dagger_PSI_c_coupled ,  
						      class GSM_vector &H_a_dagger_PSI_c_coupled);
}

#endif


