#ifndef CCWAVESHFMSDHFPOTENTIALSCALCULATIONS_H
#define CCWAVESHFMSDHFPOTENTIALSCALCULATIONS_H

namespace CC_waves_HF_MSDHF_potentials_calculations
{
  // preliminary calculations for CC states
  void CC_state_calc_preparation (
				  class nucleons_data &prot_data_CC_Berggren , 
				  class nucleons_data &neut_data_CC_Berggren ,
				  const class input_data_str &input_data_CC_Berggren ,
				  const class interaction_class &inter_data_basis , 
				  const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
				  const class HF_nucleons_data &neut_HF_data_CC_Berggren ,
				  class nucleons_data &prot_data_one_configuration_GSM ,
				  class nucleons_data &neut_data_one_configuration_GSM ,
				  class HF_nucleons_data &CC_prot_HF_data ,
				  class HF_nucleons_data &CC_neut_HF_data);

  void CC_waves_no_scaled_tables_not_orthogonalized_calc (
							  const bool is_it_entrance_channel_only ,
							  const enum potential_type basis_potential , 
							  const class CC_Hamiltonian_data &CC_H_data , 
							  class HF_nucleons_data &CC_prot_HF_data , 
							  class HF_nucleons_data &CC_neut_HF_data , 
							  class CC_state_class &CC_state);

  void potentials_calc (	
			const bool is_it_one_nucleon_case ,
			const bool is_it_entrance_channel_only_iterative_init ,
			const bool is_it_entrance_channel_only_iterative ,	
			const bool is_it_entrance_channel_only ,
			const class interaction_class &inter_data_basis , 
			const class nucleons_data &prot_data_one_configuration_GSM , 
			const class nucleons_data &neut_data_one_configuration_GSM , 
			const class nucleons_data &prot_data_CC_Berggren , 
			const class nucleons_data &neut_data_CC_Berggren , 
			const class array<class cluster_data> &cluster_data_CC_Berggren_tab ,  
			const bool is_it_symmetrized , 
			const double new_potential_fraction ,
			const enum potential_type basis_potential , 
			class CC_state_class &CC_state , 
			class CC_Hamiltonian_data &CC_H_data , 
			class HF_nucleons_data &CC_prot_HF_data , 
			class HF_nucleons_data &CC_neut_HF_data);

  void CC_state_iterative_calc (
				const class CC_target_projectile_composite_data &Tpc_data ,
				const bool compute_matrices , 
				const bool are_GSM_a_dagger_vectors_calculated , 
				const class input_data_str &input_data , 
				const class interaction_class &inter_data_basis , 
				const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
				const class HF_nucleons_data &neut_HF_data_CC_Berggren ,
				const class nucleons_data &prot_data_one_configuration_GSM , 
				const class nucleons_data &neut_data_one_configuration_GSM , 
				const class array<class cluster_data> &cluster_data_tab , 
				const class array<class cluster_data> &cluster_data_CC_Berggren_tab , 
				const class nucleons_data &prot_data_CC_Berggren , 
				const class nucleons_data &neut_data_CC_Berggren , 
				class nucleons_data &prot_data , 
				class nucleons_data &neut_data , 
				class TBMEs_class &TBMEs_pn , 
				class HF_nucleons_data &CC_prot_HF_data , 
				class HF_nucleons_data &CC_neut_HF_data , 
				class CC_Hamiltonian_data &CC_H_data , 
				class CC_state_class &CC_state);

}

#endif


