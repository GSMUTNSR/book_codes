#ifndef CC_EM_TRANSITIONS_MES_H
#define CC_EM_TRANSITIONS_MES_H

namespace CC_EM_transitions_MEs
{ 	
  namespace radial
  {
    //--// return the radial part of <uc_f lf jf || E_L || uc_i li ji> before R
    complex<double> radial_integral_bef_R_calc (
						const enum radial_operator_type radial_operator , 
						const int L , 
						const bool is_it_longwavelength_approximation , 
						const class CC_state_class &CC_state_in , 
						const class CC_state_class &CC_state_out , 
						const unsigned int ic_in , 
						const unsigned int ic_out);

    //--// return the radial part of <uc_f^(+/-) lf jf || E_L || uc_i^(+/-) li ji> after R
    complex<double> radial_integral_aft_R_part_of_four_calc (
							     const enum radial_operator_type radial_operator , 
							     const int L , 
							     const bool is_it_longwavelength_approximation , 
							     const unsigned int asy_in , 
							     const unsigned int asy_out , 
							     const class CC_state_class &CC_state_in , 
							     const class CC_state_class &CC_state_out , 
							     const unsigned int ic_in , 
							     const unsigned int ic_out);

    //--// return the radial part of <uc_f lf jf || E_L || uc_i li ji> after R
    complex<double> radial_integral_aft_R_calc (
						const enum radial_operator_type radial_operator , 
						const int L , 
						const bool is_it_longwavelength_approximation , 
						const class CC_state_class &CC_state_in , 
						const class CC_state_class &CC_state_out , 
						const unsigned int ic_in , 
						const unsigned int ic_out);

    //--// return the radial part of <uc_f lf jf || E_L || uc_i li ji> after R without complex scaling as wave functions are localized therein.
    complex<double> radial_integral_aft_R_real_calc (
						     const enum radial_operator_type radial_operator , 
						     const int L , 
						     const bool is_it_longwavelength_approximation , 
						     const class CC_state_class &CC_state_in , 
						     const class CC_state_class &CC_state_out , 
						     const unsigned int ic_in , 
						     const unsigned int ic_out);

    //--// return the radial part of <uc_f lf jf || E_L || uc_i li ji>
    TYPE radial_integral_calc (
			       const enum radial_operator_type radial_operator , 
			       const int L , 
			       const bool is_it_longwavelength_approximation , 
			       const class CC_state_class &CC_state_in , 
			       const class CC_state_class &CC_state_out , 
			       const unsigned int ic_in , 
			       const unsigned int ic_out);
  }

  namespace one_nucleon
  {
    namespace electric
    {
      //--// return <uc_f lf jf || E_L || uc_i li ji>
      TYPE OBME_reduced_calc (
			      const int L , 
			      const bool is_it_longwavelength_approximation , 
			      const double effective_charge , 
			      const class CC_state_class &CC_state_in , 
			      const class CC_state_class &CC_state_out , 
			      const unsigned int ic_in , 
			      const unsigned int ic_out);
    }

    namespace magnetic
    {
      //--// return <uc_f lf jf || M_L || uc_i li ji>
      TYPE OBME_reduced_calc (
			      const int L , 
			      const bool is_it_longwavelength_approximation , 
			      const class CC_state_class &CC_state_in , 
			      const class CC_state_class &CC_state_out , 
			      const unsigned int ic_in , 
			      const unsigned int ic_out);
    }

    //--// return <uc_f lf jf || M/E_L || uc_i li ji>
    TYPE OBME_reduced_calc (
			    const enum EM_type EM , 
			    const int L ,  
			    const bool is_it_longwavelength_approximation ,
			    const double effective_charge , 
			    const class CC_state_class &CC_state_in , 
			    const class CC_state_class &CC_state_out , 
			    const unsigned int ic_in , 
			    const unsigned int ic_out);
  }

  namespace cluster
  {	  
    TYPE EM_suboperator_intrinsic_NBME_calc (const enum EM_suboperator_type EM_suboperator , 
					     const TYPE &q , 
					     const int L , 
					     const int Lc , 
					     const bool is_it_longwavelength_approximation , 
					     const bool is_it_HO_expansion , 
					     const class interaction_class &inter_data_basis ,  
					     const class cluster_data &data_c , 
					     const class cluster_data &data_cp , 
					     const class GSM_vector &PSI_cluster_c ,
					     const class GSM_vector &PSI_cluster_cp,
					     class GSM_vector &PSI_full);
 

    namespace electric
    {
      void intrinsic_NBMEs_store (
				  const class CC_target_projectile_composite_data &Tpc_data , 
				  const unsigned int iE , 
				  const unsigned int iJPi_A_out , 
				  const unsigned int ic ,  
				  const unsigned int icp , 
				  const int L , 
				  const int l_intrinsic , 
				  class array<TYPE> &ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab , 
				  class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab , 
				  class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab , 
				  class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab);

      TYPE charge_ME_reduced_part_calc (
					const bool is_it_longwavelength_approximation , 
					const int l_intrinsic , 
					const int LCM , 
					const int L , 
					const class CC_state_class &CC_state_in , 
					const class CC_state_class &CC_state_out , 
					const unsigned int ic_in , 
					const unsigned int ic_out , 
					const TYPE &ECH_all_intrinsic_NBME , 
					const TYPE &ECH_intrinsic_NBME_jl_Yl , 
					const TYPE &ECH_intrinsic_NBME_hat_jl_over_r_Yl , 
					const class array<TYPE> &ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab);
 
      TYPE current_ME_reduced_part_calc (
					 const bool is_it_longwavelength_approximation , 
					 const int l_intrinsic , 
					 const int LCM , 
					 const int L , 
					 const class CC_state_class &CC_state_in , 
					 const class CC_state_class &CC_state_out , 
					 const unsigned int ic_in , 
					 const unsigned int ic_out , 
					 const TYPE &EC_all_intrinsic_NBME , 
					 const class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab , 
					 const class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab , 
					 const class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab);
 
      TYPE ME_reduced_calc (
			    const int L , 
			    const bool is_it_longwavelength_approximation ,
			    const class CC_target_projectile_composite_data &Tpc_data , 
			    const class array<class cluster_data> &cluster_projectile_data_tab , 
			    const unsigned int iE , 
			    const unsigned int iJPi_A_out , 
			    const unsigned int ic , 
			    const unsigned int icp , 
			    const class CC_state_class &CC_state_in , 
			    const class CC_state_class &CC_state_out , 
			    const unsigned int ic_in , 
			    const unsigned int ic_out);
    }

    namespace magnetic
    {
      void intrinsic_NBMEs_store (
				  const class CC_target_projectile_composite_data &Tpc_data , 
				  const unsigned int iE , 
				  const unsigned int iJPi_A_out , 
				  const unsigned int ic , 
				  const unsigned int icp , 
				  const int L , 
				  const int l_intrinsic , 
				  class array<TYPE> &MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab);
 
      TYPE orbital_gradient_ME_reduced_part_calc (						  
						  const int pm,
						  const bool is_it_longwavelength_approximation , 
						  const int l_intrinsic , 
						  const int LCM , 
						  const int L , 
						  const class CC_state_class &CC_state_in , 
						  const class CC_state_class &CC_state_out , 
						  const unsigned int ic_in , 
						  const unsigned int ic_out ,
						  const TYPE &MO_all_intrinsic_NBME , 
						  const TYPE &MO_intrinsic_NBME_grad_jl_Yl , 
						  const class array<TYPE> &MO_intrinsic_NBME_grad_jl_Yl_r_tab , 
						  const class array<TYPE> &MO_intrinsic_NBME_grad_jl_Yl_p_tab);
 
      TYPE spin_gradient_ME_reduced_calc (
					  const bool is_it_longwavelength_approximation , 
					  const int l_intrinsic , 
					  const int LCM , 
					  const int L , 
					  const class CC_state_class &CC_state_in , 
					  const class CC_state_class &CC_state_out , 
					  const unsigned int ic_in , 
					  const unsigned int ic_out , 
					  const TYPE &MS_all_intrinsic_NBME ,
					  const TYPE &MS_intrinsic_NBME_jl_Yl_tensor_s);
 
      TYPE spin_s_scalar_e_ME_part_calc (
					 const bool is_it_longwavelength_approximation , 
					 const int l_intrinsic , 
					 const int LCM , 
					 const int L , 
					 const class CC_state_class &CC_state_in , 
					 const class CC_state_class &CC_state_out , 
					 const unsigned int ic_in , 
					 const unsigned int ic_out , 
					 const TYPE &MSSCE_all_intrinsic_NBME ,
					 const class array<TYPE> &MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab);
 
      TYPE ME_reduced_calc (
			    const int L , 
			    const bool is_it_longwavelength_approximation ,
			    const class CC_target_projectile_composite_data &Tpc_data , 
			    const class array<class cluster_data> &cluster_projectile_data_tab , 
			    const unsigned int iE , 
			    const unsigned int iJPi_A_out , 
			    const unsigned int ic , 
			    const unsigned int icp , 
			    const class CC_state_class &CC_state_in , 
			    const class CC_state_class &CC_state_out , 
			    const unsigned int ic_in , 
			    const unsigned int ic_out);
    }
    
    double coupling_term_l_intrinsic_LCM (const int l_intrinsic , const int LCM , const int L);

    TYPE ME_reduced_calc (
			  const enum EM_type EM , 
			  const int L , 
			  const bool is_it_longwavelength_approximation ,
			  const class CC_target_projectile_composite_data &Tpc_data , 
			  const class array<class cluster_data> &cluster_projectile_data_tab , 
			  const unsigned int iE , 
			  const unsigned int iJPi_A_out , 
			  const unsigned int ic ,  
			  const unsigned int icp , 
			  const class CC_state_class &CC_state_in , 
			  const class CC_state_class &CC_state_out , 
			  const unsigned int ic_in , 
			  const unsigned int ic_out);
  }

  namespace composite
  {
    TYPE target_projectile_as_HO_NBME_calc (
					    class GSM_vector &PSI_full ,
					    const bool is_it_one_nucleon_COSM_case ,
					    const enum EM_type EM ,
					    const int L , 
					    const bool is_it_longwavelength_approximation , 
					    const bool is_it_HO_expansion ,  
					    const class interaction_class &inter_data_basis , 
					    const class CC_Hamiltonian_data &CC_H_data_in , 
					    const class CC_state_class &CC_state_in ,
					    const class CC_Hamiltonian_data &CC_H_data_out ,  
					    const class CC_state_class &CC_state_out , 
					    const class input_data_str &input_data_CC_Berggren , 
					    class nucleons_data &prot_data , 
					    class nucleons_data &neut_data , 
					    const class array<class cluster_data> &cluster_projectile_data_tab , 
					    const class array<class vector_class<complex<double> > > &CC_HO_overlaps_in , 
					    const class array<class vector_class<complex<double> > > &CC_HO_overlaps_out);

    TYPE target_nas_NBME_calc (
			       const enum EM_type EM ,
			       const int L ,  
			       const bool is_it_longwavelength_approximation , 
			       const class CC_target_projectile_composite_data &Tpc_data , 
			       const class CC_state_class &CC_state_in , 
			       const class CC_state_class &CC_state_out , 
			       const class array<TYPE> &target_reduced_NBMEs);

    TYPE projectile_nas_NBME_calc (
				   const enum EM_type EM , 
				   const int L , 
				   const bool is_it_longwavelength_approximation ,
				   const unsigned int iE,
				   const unsigned int iJPi_A_out, 
				   const class CC_target_projectile_composite_data &Tpc_data , 
				   const class CC_state_class &CC_state_in , 
				   const class CC_state_class &CC_state_out ,
				   const class array<class cluster_data> &cluster_projectile_data_tab);

    void target_reduced_NBMEs_calc (
				    class GSM_vector &PSI_full ,
				    const enum EM_type EM ,
				    const TYPE &q ,
				    const int L , 
				    const bool is_it_longwavelength_approximation , 
				    const bool is_it_HO_expansion , 
				    const bool full_common_vectors_used_in_file ,
				    const class CC_target_projectile_composite_data &Tpc_data , 
				    const class interaction_class &inter_data_basis ,  
				    class array<class nucleons_data> &prot_data_one_cluster_less_tab , 
				    class array<class nucleons_data> &neut_data_one_cluster_less_tab ,
				    class array<TYPE> &target_NBMEs_reduced);

    TYPE CC_NBME_calc (
		       const enum EM_type EM , 
		       const int L , 
		       const bool is_it_longwavelength_approximation , 
		       const bool is_it_HO_expansion ,
		       const unsigned int iE,
		       const unsigned int iJPi_A_out,
		       const class CC_target_projectile_composite_data &Tpc_data , 
		       const class array<class cluster_data> &cluster_projectile_data_tab , 
		       const bool is_it_nas_only , 
		       const class CC_Hamiltonian_data &CC_H_data_in , 
		       const class CC_state_class &CC_state_in ,
		       const class CC_Hamiltonian_data &CC_H_data_out ,  
		       const class CC_state_class &CC_state_out , 
		       class nucleons_data &prot_data , 
		       class nucleons_data &neut_data , 
		       const class interaction_class &inter_data_basis ,  
		       const class input_data_str &input_data_CC_Berggren , 
		       const class array<TYPE> &target_reduced_NBMEs ,
		       class GSM_vector &PSI_full);
  }
}

#endif


