#ifndef CC_STATE_CLASS_H
#define CC_STATE_CLASS_H


// Class containing data relative to the calculated GSM-CC resonant or scattering state in coordinate space.
// Parity and J are fixed in this class.
// The uc(r) functions are calculated and stored in this class, with orthogonalized or non-orthogonalized channels.
//
// The GSM-CC Hamiltonian is diagonalized with the Jacobi-Davidson method if one considers spectrum.
// The Lippmann-Schwinger equation issued from the GSM-CC Hamiltonian is expanded with the GSM-CC Berggren basis, with which a linear system must be solved,
// See the book for details.

class CC_state_class
{
public:
  
  CC_state_class ();
  
  CC_state_class (
		  const bool is_it_one_baryon_COSM_case , 
		  const class array<int> &nmax_HO_lab_tab , 
		  const class array<class cluster_data> &cluster_projectile_data_tab ,
		  const bool S_matrix_pole_c , 
		  const bool are_there_scaled_wfs_c,
		  const unsigned int N_channels_c , 
		  const unsigned int ic_entrance_c , 
		  const class array<class CC_channel_class> &channels_tab_c , 
		  const unsigned int N_bef_R_uniform_c ,
		  const unsigned int N_aft_R_uniform_c , 
		  const unsigned int N_bef_R_GL_c , 
		  const unsigned int N_aft_R_GL_c , 
		  const unsigned int Nk_momentum_uniform_c , 
		  const unsigned int Nk_momentum_GL_c , 
		  const double R_c , 
		  const double R0_c , 
		  const double R_real_max_c ,
		  const double kmax_momentum_c ,  
		  const double R_Fermi_momentum_c ,  
		  const int A_c , 
		  const unsigned int BP_c , 
		  const double J_c , 
		  const double M_c , 
		  const int n_c , 
		  const complex<double> &E_c);

  CC_state_class (const class CC_state_class &X);

  void allocate (
		 const bool is_it_one_baryon_COSM_case , 
		 const class array<int> &nmax_HO_lab_tab , 
		 const class array<class cluster_data> &cluster_projectile_data_tab ,
		 const bool S_matrix_pole_c , 
		 const bool are_there_scaled_wfs_c,
		 const unsigned int N_channels_c , 
		 const unsigned int ic_entrance_c , 
		 const class array<class CC_channel_class> &channels_tab_c , 
		 const unsigned int N_bef_R_uniform_c ,
		 const unsigned int N_aft_R_uniform_c , 
		 const unsigned int N_bef_R_GL_c , 
		 const unsigned int N_aft_R_GL_c , 
		 const unsigned int Nk_momentum_uniform_c , 
		 const unsigned int Nk_momentum_GL_c , 
		 const double R_c , 
		 const double R0_c , 
		 const double R_real_max_c , 
		 const double kmax_momentum_c , 
		 const double R_Fermi_momentum_c , 
		 const int A_c , 
		 const unsigned int BP_c , 
		 const double J_c , 
		 const double M_c , 
		 const int n_c , 
		 const complex<double> &E_c);

  void allocate_fill (const class CC_state_class &X);

  void deallocate ();

  bool is_it_filled () const
  {
    return (N_channels > 0);
  }
  
  bool get_are_there_scaled_wfs () const
  {
    return are_there_scaled_wfs;
  }
  
  unsigned int get_N_channels () const
  {
    return N_channels;
  }

  unsigned int get_ic_entrance () const
  {
    return ic_entrance;
  }

  double get_R () const
  {
    return R;
  }

  double get_matching_point () const
  {
    return matching_point;
  }

  double get_R0 () const
  {
    return R0;
  }

  double get_R_max () const
  {
    return R_max;
  }

  double get_kmax_momentum () const
  {
    return kmax_momentum;
  }

  double get_R_Fermi_momentum () const
  {
    return R_Fermi_momentum;
  }

  unsigned int get_N_bef_R_uniform () const
  {
    return N_bef_R_uniform;
  }

  unsigned int get_N_aft_R_uniform () const
  {
    return N_aft_R_uniform;
  }

  unsigned int get_N_bef_R_GL () const
  {
    return N_bef_R_GL;
  }

  unsigned int get_N_aft_R_GL () const
  {
    return N_aft_R_GL;
  }

  unsigned int get_Nk_momentum_uniform ()  const
  {
    return Nk_momentum_uniform;
  }

  unsigned int get_Nk_momentum_GL () const
  {
    return Nk_momentum_GL;
  }
		    
  double get_step_bef_R_uniform () const
  {
    return step_bef_R_uniform;
  }

  double get_step_aft_R_uniform () const
  {
    return step_aft_R_uniform;
  }

  double get_step_momentum_uniform () const
  {
    return step_momentum_uniform;
  }

  unsigned int get_N_bef_mp_uniform () const
  {
    return N_bef_mp_uniform;
  }

  unsigned int get_N_aft_mp_uniform () const
  {
    return N_aft_mp_uniform;
  }

  int get_A () const
  {
    return A;
  }

  int get_nmax_HO_local_plus_one () const
  {
    return nmax_HO_local_plus_one;
  }

  int get_Nmax_HO_potentials_plus_one () const
  {
    return Nmax_HO_potentials_plus_one;
  }

  double get_R_HO_end () const
  {
    return R_HO_end;
  }

  double get_J () const
  {
    return J;
  }

  double get_M () const
  {
    return M;
  }

  unsigned int get_BP () const
  {
    return BP;
  }

  int get_n () const
  {
    return n;
  }

  bool get_S_matrix_pole () const
  {
    return S_matrix_pole;
  }

  bool get_is_it_HO_projected () const
  {
    return is_it_HO_projected;
  }

  unsigned int get_N_bef_mp_GL () const
  {
    return N_bef_mp_GL;
  }

  unsigned int get_N_aft_mp_GL () const
  {
    return N_aft_mp_GL;
  }

  unsigned int get_N_bef_mp_GL_SGI_MSGI () const
  {
    return N_bef_mp_GL_SGI_MSGI;
  }

  unsigned int get_N_aft_mp_GL_SGI_MSGI () const
  {
    return N_aft_mp_GL_SGI_MSGI;
  }

  complex<double> get_E () const
  {
    return E;
  }

  complex<double> get_Cminus_entrance_channel () const
  {
    return Cminus_entrance_channel;
  }

  bool get_is_E_ok () const
  {
    return is_E_ok;
  }
  
  const class array<class CC_channel_class> & get_channels_tab () const
  {
    return channels_tab;
  }

  const class array<double> & get_r_bef_R_tab_uniform () const
  {
    return r_bef_R_tab_uniform;
  }

  const class array<double> & get_k_tab_uniform () const
  {
    return k_tab_uniform;
  }

  const class array<double> & get_r_bef_R_tab_GL () const
  {
    return r_bef_R_tab_GL;
  }
  
  const class array<double> & get_k_tab_GL () const
  {
    return k_tab_GL;
  }

  const class array<double> & get_r_bef_R_tab_GL_SGI_MSGI () const
  {
    return r_bef_R_tab_GL_SGI_MSGI;
  }

  const class array<double> & get_r_aft_R_tab_GL_real () const
  {
    return r_aft_R_tab_GL_real;
  }

  const class array<double> & get_um4_aft_R_tab_GL () const
  {
    return um4_aft_R_tab_GL;
  }

  const class array<double> & get_w_bef_R_tab_GL () const
  {
    return w_bef_R_tab_GL;
  }

  const class array<double> & get_wk_tab_GL () const
  {
    return wk_tab_GL;
  }

  const class array<double> & get_w_bef_R_tab_GL_SGI_MSGI () const
  {
    return w_bef_R_tab_GL_SGI_MSGI;
  }

  const class array<double> & get_w_aft_R_tab_GL_real () const
  {
    return w_aft_R_tab_GL_real;
  }

  const class array<double> & get_w_aft_R_tab_GL () const
  {
    return w_aft_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_wf_bef_R_tab_uniform () const
  {
    return CC_wf_bef_R_tab_uniform;
  }

  const class array<complex<double> > & get_CC_dwf_bef_R_tab_uniform () const
  {
    return CC_dwf_bef_R_tab_uniform;
  }

  const class array<complex<double> > & get_CC_d2wf_bef_R_tab_uniform () const
  {
    return CC_d2wf_bef_R_tab_uniform;
  }

  const class array<complex<double> > & get_CC_asymptotic_in_zero_wf_bef_R_tab_uniform () const
  {
    return CC_asymptotic_in_zero_wf_bef_R_tab_uniform;
  }

  const class array<complex<double> > & get_CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform () const
  {
    return CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform;
  }

  const class array<complex<double> > & get_CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform () const
  {
    return CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform;
  }

  const class array<complex<double> > & get_CC_scaled_wf_plus_aft_R_tab_uniform () const
  {
    return CC_scaled_wf_plus_aft_R_tab_uniform;
  }

  const class array<complex<double> > & get_CC_scaled_dwf_plus_aft_R_tab_uniform () const
  {
    return CC_scaled_dwf_plus_aft_R_tab_uniform;
  }

  const class array<complex<double> > & get_CC_wf_bef_R_tab_GL () const
  {
    return CC_wf_bef_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_dwf_bef_R_tab_GL () const
  {
    return CC_dwf_bef_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_d2wf_bef_R_tab_GL () const
  {
    return CC_d2wf_bef_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_wf_bef_R_tab_GL_SGI_MSGI () const
  {
    return CC_wf_bef_R_tab_GL_SGI_MSGI;
  }

  const class array<complex<double> > & get_CC_dwf_bef_R_tab_GL_SGI_MSGI () const
  {
    return CC_dwf_bef_R_tab_GL_SGI_MSGI;
  }

  const class array<complex<double> > & get_CC_wf_aft_R_tab_GL () const
  {
    return CC_wf_aft_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_dwf_aft_R_tab_GL () const
  {
    return CC_dwf_aft_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_d2wf_aft_R_tab_GL () const
  {
    return CC_d2wf_aft_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_scaled_wf_minus_aft_R_c_entrance_tab_GL () const
  {
    return CC_scaled_wf_minus_aft_R_c_entrance_tab_GL;
  }

  const class array<complex<double> > & get_CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL () const
  {
    return CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL;
  }

  const class array<complex<double> > & get_CC_scaled_wf_plus_aft_R_tab_GL () const
  {
    return CC_scaled_wf_plus_aft_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_scaled_dwf_plus_aft_R_tab_GL () const
  {
    return CC_scaled_dwf_plus_aft_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_wf_momentum_tab_uniform () const
  {
    return CC_wf_momentum_tab_uniform;
  }
  
  const class array<complex<double> > & get_CC_dwf_momentum_tab_uniform () const
  {
    return CC_dwf_momentum_tab_uniform;
  }
  
  const class array<complex<double> > & get_CC_wf_momentum_tab_GL () const
  {
    return CC_wf_momentum_tab_GL;
  }
  
  const class array<complex<double> > & get_CC_dwf_momentum_tab_GL () const
  {
    return CC_dwf_momentum_tab_GL;
  }
  
  const class array<complex<double> > & get_C0_tab () const
  {
    return C0_tab;
  }

  const class array<complex<double> > & get_Cplus_tab () const
  {
    return Cplus_tab;
  }

  const class array<complex<double> > & get_A0_tab () const
  {
    return A0_tab;
  }

  const class array<complex<double> > & get_Aplus_tab () const
  {
    return Aplus_tab;
  }

  const class array<class vector_class<complex<double> > > & get_HO_overlaps () const
  {
    return HO_overlaps;
  }

  const class array<class vector_class<complex<double> > > & get_HO_overlaps_Fermi () const
  {
    return HO_overlaps_Fermi;
  }

  const class array<class CC_fwd_basis_state> & get_fwd_basis () const
  {
    return fwd_basis;
  }

  const class array<class CC_bwd_basis_state> & get_bwd_basis () const
  {
    return bwd_basis;
  }

  const class CC_bwd_basis_state & get_bwd_U_minus () const
  {
    return bwd_U_minus;
  }

  void CC_wf_dwf_d2wf_zero ();

  void change_channels_energy (const complex<double> &E_change);

  void copy_to_file (const string &file_name) const;
  
  complex<double> Jost_determinant_calc (
					 const bool is_it_entrance_channel_only ,
					 const class potentials_effective_mass &T);

  void Berggren_Green_function_CC_waves_no_scaled_tables_calc (
							       const class CC_target_projectile_composite_data &Tpc_data ,
							       const class baryons_data &prot_Y_data , 
							       const class baryons_data &neut_Y_data , 
							       const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
							       const class CC_Hamiltonian_data &CC_H_data);

  void CC_HO_wfs_projection ();

  void wave_calculation_no_scaled_tables_no_channel_orthogonalization (
								       const bool is_it_entrance_channel_only ,
								       const class CC_Hamiltonian_data &CC_H_data , 
								       const class HF_nucleons_data &prot_HF_data,
								       const class HF_nucleons_data &neut_HF_data,
								       const class potentials_effective_mass &T);
  
  void scaled_tables_calc ();

  void wave_channel_orthogonalization (const class CC_Hamiltonian_data &CC_H_data);

  unsigned int HF_channel_index (
				 const unsigned int ic ,
				 const class HF_nucleons_data &CC_prot_HF_data,
				 const class HF_nucleons_data &CC_neut_HF_data) const;

  void put_shells_HF (
		      class HF_nucleons_data &CC_prot_HF_data , 
		      class HF_nucleons_data &CC_neut_HF_data) const;

  double test_calc (
		    const bool is_it_entrance_channel_only ,
		    const class array<complex<double> > &A0_bef_tab,
		    const class array<complex<double> > &Aplus_bef_tab) const;

  class CC_state_class & operator = (const class CC_state_class &X);

  void overlap_function_calc (
			      const bool is_it_Gauss_Legendre , 
			      const class correlated_state_str &PSI_in_qn ,  
			      const enum particle_type projectile , 
			      const int LCM_projectile ,
			      const double J_projectile , 
			      class array<TYPE> &overlap_function_tab) const;

  TYPE spectroscopic_factor_calc (
				  const class correlated_state_str &PSI_in_qn ,  
				  const enum particle_type projectile , 
				  const int LCM_projectile ,
				  const double J_projectile) const;
 
  void density_calc (
		     const bool is_it_radial , 
		     const bool is_it_Gauss_Legendre ,
		     class array<TYPE> &density_tab) const;

  void transition_density_calc (
				const bool is_it_radial , 
				const bool is_it_Gauss_Legendre ,
				const class CC_state_class &CC_state_in , 
				class array<TYPE> &density_tab) const;
  
  void HO_overlaps_calc (
			 const bool is_it_entrance_channel_only ,
			 const class CC_Hamiltonian_data &CC_H_data);

  void wfs_dwfs_momentum_calc (const bool is_it_entrance_channel_only);
  
  void wfs_dwfs_HO_projection_momentum_calc (const bool is_it_entrance_channel_only);
  
  complex<double> get_T_matrix_value (const unsigned int ic_entrance , const unsigned int ic) const;

  complex<double> get_phase_shift (const unsigned int ic) const;
  
  void partial_widths_current_formula_calc () const;
  
  void CC_uc_wfs_test_pole (
			    const class CC_target_projectile_composite_data &Tpc_data , 
			    const class baryons_data &prot_Y_data , 
			    const class baryons_data &neut_Y_data , 
			    const class array<class cluster_data> &cluster_projectile_data_tab , 
			    const class CC_Hamiltonian_data &CC_H_data) const;
  
  friend double used_memory_calc (const class CC_state_class &T);
  
private:
  
  bool are_there_scaled_wfs;  // scaled wave functions (i.e. C+/-[c].H+/-(kr).exp (-/+ i[kc.r - eta[c].log( kc r)]), which vary smoothly for large r) are calculated_only if are_there_scaled_wfs is true

  unsigned int N_channels;    // number of channels used in the GSM-CC Hamiltonian
  
  unsigned int ic_entrance;   // index of the entrance channel for scattering states. It is usually put to zero by convention for resonant states.
  
  double R;               // rotation point on the real r-axis for complex scaling
  double matching_point;  // matching point on the real r-axis between internal and external parts of uc(r). It is equal to R0.
  double R0;              // radius of the integrated potential
  double R_max;           // maximal radius for integration with HO states.
  
  double kmax_momentum; // maximal momentum in momentum space

  double R_Fermi_momentum; // radius of the Fermi function used to make the Fourier-Bessel transform of one-body states finite on the real axis 
  
  unsigned int N_bef_R_uniform; // number of points on [0:R]                                  using uniform (uniform) discretization
  unsigned int N_aft_R_uniform; // number of points on [R:R_real_max], ]0:R^{-1/4}[ (after R) using uniform (uniform) discretization
  
  unsigned int N_bef_R_GL; // number of points on [0:R]                                  using Gauss-Legendre (GL)discretization
  unsigned int N_aft_R_GL; // number of points on [R:R_real_max], ]0:R^{-1/4}[ (after R) using Gauss-Legendre (GL)discretization
  
  unsigned int Nk_momentum_uniform;  // number of points on [0:kmax_momentum] using uniform (uniform)   discretization
  unsigned int Nk_momentum_GL;       // number of points on [0:kmax_momentum] using Gauss-Legendre (GL) discretization

  double step_bef_R_uniform; // number of points on uniform grid on [0:R] (before R)
  double step_aft_R_uniform; // number of points on uniform grid on [R:R_real_max], ]0:R^{-1/4}[ (after R)
  
  double step_momentum_uniform; // number of points on uniform grid on [0:kmax_momentum]
  
  unsigned int N_bef_mp_uniform; // number of points on [0:matching-point] using uniform (uniform) discretization
  unsigned int N_aft_mp_uniform; // number of points on [matching-point:R] using uniform (uniform) discretization
  
  int A;                            // number of baryons of the GSM-CC state
  
  int nmax_HO_local_plus_one;       // n[max] of HO states used in the HO diagonalization occuring only (locally) in this class. It is fixed at 16.
  
  int Nmax_HO_potentials_plus_one;  // N[max] of HO states used in the HO diagonalization. It is the maximal values of nmax_HO_lab_tab(lc) for all lc values.

  double R_HO_end;                  // Maximal radius for radial integration of HO matrix elements. It is fixed at 50.
  
  double J;                         // Total angular momentum            of the GSM-CC state
  double M;                         // Total angular momentum projection of the GSM-CC state

  unsigned int BP;                  // Parity of the GSM-CC state

  int n; // Principal angular momentum of the GSM-CC resonant state. n=0,1,2,... for fixed J-Pi correspond to ground state, 1st, 2nd excited state ... It is not used with scattering states (0 or other arbitrary value is used).

  bool S_matrix_pole;               // true for bound and resonant states, false for scattering states
  
  bool is_it_HO_projected;          // true if one projects uc(r) functions on an HO basis, false if uc(r) are solutions of the GSM-CC equations in coordinate space (calculated with the Berggren basis expansion)

  unsigned int N_bef_mp_GL;          // number of points on [0:matching-point] using Gauss-Legendre (GL) discretization
  unsigned int N_aft_mp_GL;          // number of points on [0:matching-point] using Gauss-Legendre (GL) discretization
  
  unsigned int N_bef_mp_GL_SGI_MSGI; // number of points on [0:matching-point] using Gauss-Legendre (GL) discretization with the SGI or MSGI interaction (where on integrates on [0:2.R0])
  unsigned int N_aft_mp_GL_SGI_MSGI; // number of points on [0:matching-point] using Gauss-Legendre (GL) discretization with the SGI or MSGI interaction (where on integrates on [0:2.R0])
  
  complex<double> E;                                // Energy of the GSM-CC state
  
  complex<double> Cminus_entrance_channel;          // Value of C-[c[entrance]] in C-[c[entrance]].H-(k[c[entrance].r) in the entrance channel for scattering states. It is zero for resonant state.
  
  bool is_E_ok;                                     // true if the wave function is well defined (E non zero or eigenstate from H diagonalization), false if not
	
  class array<class CC_channel_class> channels_tab; // array of the channels used in the GSM-CC Hamiltonian

  class array<double> r_bef_R_tab_uniform;          // uniformly distributed abscissas before R : r = i.step_bef_R_uniform ,  i in [0:N_bef_R_uniform-1]

  class array<double> k_tab_uniform;                // uniformly distributed abscissas on [0:kmax_momentum]




  
  // Gaussian abscissas and weights before and after R
  // r in ]0:R[, k in [0:kmax_momentum], r in ]0:2.R0[ for SGI/MSGI integrals (before R), r in ]R:R_max[ and Gaussian abscissas to the power -4 and weights times u^{-5} : u in ]0:R^{-1/4}[ (after R)   

  class array<double> r_bef_R_tab_GL , k_tab_GL  , r_bef_R_tab_GL_SGI_MSGI , r_aft_R_tab_GL_real , um4_aft_R_tab_GL;
  class array<double> w_bef_R_tab_GL , wk_tab_GL , w_bef_R_tab_GL_SGI_MSGI , w_aft_R_tab_GL_real , w_aft_R_tab_GL;




  
  class array<complex<double> > CC_wf_bef_R_tab_uniform , CC_dwf_bef_R_tab_uniform , CC_d2wf_bef_R_tab_uniform;  // channel wave function uc(r), uc'(r) and uc''(r) on [0:R] on a uniform grid
  
  class array<complex<double> > CC_wf_bef_R_tab_GL  , CC_dwf_bef_R_tab_GL  , CC_d2wf_bef_R_tab_GL;               // channel wave functions uc(r), uc'(r) and uc''(r) on [0:R]     with Gaussian points.
  class array<complex<double> > CC_wf_aft_R_tab_GL  , CC_dwf_aft_R_tab_GL  , CC_d2wf_aft_R_tab_GL;               // channel wave functions uc(r), uc'(r) and uc''(r) on [R:R_max] with Gaussian points.
  
  class array<complex<double> > CC_wf_bef_R_tab_GL_SGI_MSGI , CC_dwf_bef_R_tab_GL_SGI_MSGI;                      // channel wave functions uc(r), uc'(r) on [0:2.R0] with Gaussian points.




  
  // scaled channel wave functions uc(r), uc'(r) : CC_scaled_wf_plus/minus_aft_R...(angle_index , i) = C+/-[c].H+/-(k[c].z).exp[-/+.i[k[c]z - eta[c].log[kz]]] on a uniform grid or with Gaussian points
  // same with derivatives.
  // z = R + (r-R).exp(I.theta) ,  r = u_bef_R_tab_GL(i)^{-4}
  // CC_scaled_wf/dwf_plus/minus_aft_R....(angle_index , i) : angle_index=0 , 1 , 2 , 3 => theta =  Pi/4 , 3Pi/4 , -3Pi/4 , -Pi/4.
  
  class array<complex<double> > CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform , CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform;
  class array<complex<double> > CC_scaled_wf_minus_aft_R_c_entrance_tab_GL      , CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL;
  
  class array<complex<double> > CC_scaled_wf_plus_aft_R_tab_uniform , CC_scaled_dwf_plus_aft_R_tab_uniform;
  class array<complex<double> > CC_scaled_wf_plus_aft_R_tab_GL      , CC_scaled_dwf_plus_aft_R_tab_GL;



  
  class array<complex<double> > CC_asymptotic_in_zero_wf_bef_R_tab_uniform;  // approximate channel wave functions of uc(r) in [0:r] asymptotically exact for r ~ 0 (C0[c].r^{l[c] + 1} for example) with N_bef_R_uniform points

  class array<complex<double> > CC_wf_momentum_tab_uniform , CC_dwf_momentum_tab_uniform; // channel wave function and derivative in momentum space on [0:kmax_momentum] using a uniform grid  
  class array<complex<double> > CC_wf_momentum_tab_GL      , CC_dwf_momentum_tab_GL;      // channel wave function and derivative in momentum space on [0:kmax_momentum] with Gaussian points
  
  class array<complex<double> > C0_tab , Cplus_tab;  // array of C0[c] and C+[c] values (uc(r) ~ C0[c].r^{l[c] + 1} for r ~ 0 and uc(r) = C+[c].H+(k[c].r) + C-[c].H-(k[c].r) for r > R).
  
  class array<complex<double> > A0_tab , Aplus_tab;  // array of integration constants used in the direct integration of uc(r) and arising from the continuity of uc(r) and uc'(r).
                                                     // A0[c] and A+[c] are normalized afterwards so that A0[c] = A+[c] = 1.

  class array<class vector_class<complex<double> > > HO_overlaps;        // HO overlaps <uc | n[HO]>
  
  class array<class vector_class<complex<double> > > HO_overlaps_Fermi;  // HO overlaps <uc | Fermi_like_function (R_cut_function , d_cut_function , r) | n[HO]>

  class array<class CC_fwd_basis_state> fwd_basis; // array of basis forward  functions used in the direct integration of uc(r) on [0:matching-point] : uc(r) = sum_b f[b,c] fwd_basis[b](r)
  class array<class CC_bwd_basis_state> bwd_basis; // array of basis backward functions used in the direct integration of uc(r) on [matching-point:R] : uc(r) = sum_b b[b,c] bwd_basis[b](r)

  class CC_bwd_basis_state bwd_U_minus; // basis backward functions used in the direct integration of scattering uc(r) on [matching-point:R] on the entrance channel with incoming behavior
  





  
  void CC_waves_bef_R_from_CC_Berggren_expansion_one_baryon_calc (
								   const class CC_Hamiltonian_data &CC_H_data ,
								   const class baryons_data &prot_Y_data_CC_Berggren , 
								   const class baryons_data &neut_Y_data_CC_Berggren ,
								   class vector_class<complex<double> > &Berggren_expansion_vector);

  void CC_waves_bef_R_from_CC_Berggren_expansion_cluster_calc (
							       const class CC_Hamiltonian_data &CC_H_data,
							       const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
							       class vector_class<complex<double> > &Berggren_expansion_vector);

  void CC_waves_momentum_from_CC_Berggren_expansion_one_baryon_calc (
								      const class CC_Hamiltonian_data &CC_H_data ,
								      const class baryons_data &prot_Y_data_CC_Berggren , 
								      const class baryons_data &neut_Y_data_CC_Berggren ,
								      class vector_class<complex<double> > &Berggren_expansion_vector);

  void CC_waves_momentum_from_CC_Berggren_expansion_cluster_calc (
								  const class CC_Hamiltonian_data &CC_H_data,
								  const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
								  class vector_class<complex<double> > &Berggren_expansion_vector);
  
  void pole_state_waves_from_CC_Berggren_expansion_calc (
							 const class CC_target_projectile_composite_data &Tpc_data ,
							 const class CC_Hamiltonian_data &CC_H_data ,
							 const class baryons_data &prot_Y_data_CC_Berggren , 
							 const class baryons_data &neut_Y_data_CC_Berggren , 
							 const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
							 const complex<double> &eigenvalue,
							 class vector_class<complex<double> > &Berggren_expansion_vector);

  void scat_state_waves_from_CC_Berggren_expansion_calc (
							 const class CC_target_projectile_composite_data &Tpc_data ,
							 const class CC_Hamiltonian_data &CC_H_data ,
							 const class baryons_data &prot_Y_data_CC_Berggren , 
							 const class baryons_data &neut_Y_data_CC_Berggren , 
							 const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
							 class vector_class<complex<double> > &orth_H_CC_Berggren_scat);

  void Berggren_expansion_pole_state_eigenvalue_calc (
						      const class CC_target_projectile_composite_data &Tpc_data ,
						      const class CC_Hamiltonian_data &CC_H_data ,
						      complex<double> &orth_H_eigenvalue,
						      class vector_class<complex<double> > &orth_H_CC_Berggren_eig_vec);

  class vector_class<complex<double> > Berggren_expansion_scat_source_one_baryon_calc (
											const class baryons_data &prot_Y_data_CC_Berggren , 
											const class baryons_data &neut_Y_data_CC_Berggren ,
											const class CC_Hamiltonian_data &CC_H_data);

  class vector_class<complex<double> > Berggren_expansion_scat_source_cluster_calc (
										    const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab ,
										    const class CC_Hamiltonian_data &CC_H_data);

  class vector_class<complex<double> > Berggren_expansion_scat_state_calc (
									   const class CC_target_projectile_composite_data &Tpc_data ,
									   const class baryons_data &prot_Y_data_CC_Berggren , 
									   const class baryons_data &neut_Y_data_CC_Berggren , 
									   const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
									   const class CC_Hamiltonian_data &CC_H_data);

  void Cplus_calc (const unsigned int ic);

  void entrance_Cplus_Cminus_calc ();

  class CC_channel_class& lowest_channel_determine () const;

  void CC_asymptotic_in_zero_wf_before_R_calc (const bool is_it_entrance_channel_only , const class potentials_effective_mass &T );

  void CC_wfs_dwfs_bef_R_calc (const bool is_it_entrance_channel_only);

  void CC_d2wfs_bef_R_calc (const bool is_it_entrance_channel_only , const class potentials_effective_mass &T );

  void CC_wfs_dwfs_d2wfs_aft_R_tab_GL_calc (const bool is_it_entrance_channel_only);

  void non_orthogonality_restoration (const class CC_Hamiltonian_data &CC_H_data) ;

  void branch_cut_correction (
			      const complex<double> &exp_two_Pi_eta_c,
			      const complex<double> &exp_two_Pi_eta_c_minus_one,
			      class Coulomb_wave_functions &cwf,
			      const class array<complex<double> > &z_tab,
			      const unsigned int ic,
			      const unsigned int angle_index,
			      const unsigned int wf_index,
			      bool &is_it_crossed,
			      class array<complex<double> > &scaled_wfs,
			      class array<complex<double> > &scaled_dwfs);

  void CC_out_ingoing_waves_after_R (const unsigned int angle_index);

  complex<double> overlap_OCM_core_shell_calc (
					       const class spherical_state &OCM_core_shell,
					       const unsigned int ic) const;

  void OCM_core_channel_orthogonalize (
				       const class spherical_state &OCM_core_shell,
				       const unsigned int ic);

  void OCM_orthogonalization (const class HF_nucleons_data &HF_data);

  void basis_states_calc (const bool is_it_entrance_channel_only , const class potentials_effective_mass &T);

  void constants_calc (const bool is_it_entrance_channel_only);

  complex<double> Gamow_partial_squared_norm_no_channel_orthogonalization (const unsigned int ic) const;
 
  complex<double> Gamow_norm_no_channel_orthogonalization () const;

  complex<double> finite_range_overlaps_square_norm (const class CC_Hamiltonian_data &CC_H_data) const;

  complex<double> Gamow_norm_with_channel_orthogonalization (const class CC_Hamiltonian_data &CC_H_data) const;

  void normalization (const complex<double> &factor);
};


ostream& operator << (ostream &os , const class CC_state_class &ps);

#endif


