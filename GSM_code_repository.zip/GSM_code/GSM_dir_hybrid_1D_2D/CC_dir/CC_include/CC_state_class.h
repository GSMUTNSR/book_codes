#ifndef CC_STATE_CLASS_H
#define CC_STATE_CLASS_H


// CC_state_class (class)

class CC_state_class
{
public:
  
  CC_state_class ();
  
  CC_state_class (
		  const bool is_it_one_baryon_COSM_case , 
		  const class array<int> &nmax_HO_lab_tab , 
		  const class array<class cluster_data> &cluster_projectile_data_tab ,
		  const bool S_matrix_pole_c , 
		  const bool are_there_scaled_wfs_c,
		  const unsigned int N_channels_c , 
		  const unsigned int ic_entrance_c , 
		  const class array<class CC_channel_class> &channels_tab_c , 
		  const unsigned int N_bef_R_uniform_c ,
		  const unsigned int N_aft_R_uniform_c , 
		  const unsigned int N_bef_R_GL_c , 
		  const unsigned int N_aft_R_GL_c , 
		  const unsigned int Nk_momentum_uniform_c , 
		  const unsigned int Nk_momentum_GL_c , 
		  const double R_c , 
		  const double R0_c , 
		  const double R_real_max_c ,
		  const double kmax_momentum_c ,  
		  const double R_Fermi_momentum_c ,  
		  const int A_c , 
		  const unsigned int BP_c , 
		  const double J_c , 
		  const double M_c , 
		  const int n_c , 
		  const complex<double> &E_c);

  CC_state_class (const class CC_state_class &X);

  void allocate (
		 const bool is_it_one_baryon_COSM_case , 
		 const class array<int> &nmax_HO_lab_tab , 
		 const class array<class cluster_data> &cluster_projectile_data_tab ,
		 const bool S_matrix_pole_c , 
		 const bool are_there_scaled_wfs_c,
		 const unsigned int N_channels_c , 
		 const unsigned int ic_entrance_c , 
		 const class array<class CC_channel_class> &channels_tab_c , 
		 const unsigned int N_bef_R_uniform_c ,
		 const unsigned int N_aft_R_uniform_c , 
		 const unsigned int N_bef_R_GL_c , 
		 const unsigned int N_aft_R_GL_c , 
		 const unsigned int Nk_momentum_uniform_c , 
		 const unsigned int Nk_momentum_GL_c , 
		 const double R_c , 
		 const double R0_c , 
		 const double R_real_max_c , 
		 const double kmax_momentum_c , 
		 const double R_Fermi_momentum_c , 
		 const int A_c , 
		 const unsigned int BP_c , 
		 const double J_c , 
		 const double M_c , 
		 const int n_c , 
		 const complex<double> &E_c);

  void allocate_fill (const class CC_state_class &X);

  void deallocate ();

  bool is_it_filled () const
  {
    return (N_channels > 0);
  }
  
  bool get_are_there_scaled_wfs () const
  {
    return are_there_scaled_wfs;
  }
  
  unsigned int get_N_channels () const
  {
    return N_channels;
  }

  unsigned int get_ic_entrance () const
  {
    return ic_entrance;
  }

  double get_R () const
  {
    return R;
  }

  double get_matching_point () const
  {
    return matching_point;
  }

  double get_R0 () const
  {
    return R0;
  }

  double get_R_max () const
  {
    return R_max;
  }

  double get_kmax_momentum () const
  {
    return kmax_momentum;
  }

  double get_R_Fermi_momentum () const
  {
    return R_Fermi_momentum;
  }

  unsigned int get_N_bef_R_uniform () const
  {
    return N_bef_R_uniform;
  }

  unsigned int get_N_aft_R_uniform () const
  {
    return N_aft_R_uniform;
  }

  unsigned int get_N_bef_R_GL () const
  {
    return N_bef_R_GL;
  }

  unsigned int get_N_aft_R_GL () const
  {
    return N_aft_R_GL;
  }

  unsigned int get_Nk_momentum_uniform ()  const
  {
    return Nk_momentum_uniform;
  }

  unsigned int get_Nk_momentum_GL () const
  {
    return Nk_momentum_GL;
  }
		    
  double get_step_bef_R_uniform () const
  {
    return step_bef_R_uniform;
  }

  double get_step_aft_R_uniform () const
  {
    return step_aft_R_uniform;
  }

  double get_step_momentum_uniform () const
  {
    return step_momentum_uniform;
  }

  unsigned int get_N_bef_mp_uniform () const
  {
    return N_bef_mp_uniform;
  }

  unsigned int get_N_aft_mp_uniform () const
  {
    return N_aft_mp_uniform;
  }

  int get_A () const
  {
    return A;
  }

  int get_nmax_HO_local_plus_one () const
  {
    return nmax_HO_local_plus_one;
  }

  int get_Nmax_HO_potentials_plus_one () const
  {
    return Nmax_HO_potentials_plus_one;
  }

  double get_R_HO_end () const
  {
    return R_HO_end;
  }

  double get_J () const
  {
    return J;
  }

  double get_M () const
  {
    return M;
  }

  unsigned int get_BP () const
  {
    return BP;
  }

  int get_n () const
  {
    return n;
  }

  bool get_S_matrix_pole () const
  {
    return S_matrix_pole;
  }

  bool get_is_it_HO_projected () const
  {
    return is_it_HO_projected;
  }

  unsigned int get_N_bef_mp_GL () const
  {
    return N_bef_mp_GL;
  }

  unsigned int get_N_aft_mp_GL () const
  {
    return N_aft_mp_GL;
  }

  unsigned int get_N_bef_mp_GL_SGI_MSGI () const
  {
    return N_bef_mp_GL_SGI_MSGI;
  }

  unsigned int get_N_aft_mp_GL_SGI_MSGI () const
  {
    return N_aft_mp_GL_SGI_MSGI;
  }

  complex<double> get_E () const
  {
    return E;
  }

  complex<double> get_Cminus_entrance_channel () const
  {
    return Cminus_entrance_channel;
  }

  bool get_is_E_ok () const
  {
    return is_E_ok;
  }
  
  const class array<class CC_channel_class> & get_channels_tab () const
  {
    return channels_tab;
  }

  const class array<double> & get_r_bef_R_tab_uniform () const
  {
    return r_bef_R_tab_uniform;
  }

  const class array<double> & get_k_tab_uniform () const
  {
    return k_tab_uniform;
  }

  const class array<double> & get_r_bef_R_tab_GL () const
  {
    return r_bef_R_tab_GL;
  }
  
  const class array<double> & get_k_tab_GL () const
  {
    return k_tab_GL;
  }

  const class array<double> & get_r_bef_R_tab_GL_SGI_MSGI () const
  {
    return r_bef_R_tab_GL_SGI_MSGI;
  }

  const class array<double> & get_r_aft_R_tab_GL_real () const
  {
    return r_aft_R_tab_GL_real;
  }

  const class array<double> & get_um4_aft_R_tab_GL () const
  {
    return um4_aft_R_tab_GL;
  }

  const class array<double> & get_w_bef_R_tab_GL () const
  {
    return w_bef_R_tab_GL;
  }

  const class array<double> & get_wk_tab_GL () const
  {
    return wk_tab_GL;
  }

  const class array<double> & get_w_bef_R_tab_GL_SGI_MSGI () const
  {
    return w_bef_R_tab_GL_SGI_MSGI;
  }

  const class array<double> & get_w_aft_R_tab_GL_real () const
  {
    return w_aft_R_tab_GL_real;
  }

  const class array<double> & get_w_aft_R_tab_GL () const
  {
    return w_aft_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_wf_bef_R_tab_uniform () const
  {
    return CC_wf_bef_R_tab_uniform;
  }

  const class array<complex<double> > & get_CC_dwf_bef_R_tab_uniform () const
  {
    return CC_dwf_bef_R_tab_uniform;
  }

  const class array<complex<double> > & get_CC_d2wf_bef_R_tab_uniform () const
  {
    return CC_d2wf_bef_R_tab_uniform;
  }

  const class array<complex<double> > & get_CC_asymptotic_in_zero_wf_bef_R_tab_uniform () const
  {
    return CC_asymptotic_in_zero_wf_bef_R_tab_uniform;
  }

  const class array<complex<double> > & get_CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform () const
  {
    return CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform;
  }

  const class array<complex<double> > & get_CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform () const
  {
    return CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform;
  }

  const class array<complex<double> > & get_CC_scaled_wf_plus_aft_R_tab_uniform () const
  {
    return CC_scaled_wf_plus_aft_R_tab_uniform;
  }

  const class array<complex<double> > & get_CC_scaled_dwf_plus_aft_R_tab_uniform () const
  {
    return CC_scaled_dwf_plus_aft_R_tab_uniform;
  }

  const class array<complex<double> > & get_CC_wf_bef_R_tab_GL () const
  {
    return CC_wf_bef_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_dwf_bef_R_tab_GL () const
  {
    return CC_dwf_bef_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_d2wf_bef_R_tab_GL () const
  {
    return CC_d2wf_bef_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_wf_bef_R_tab_GL_SGI_MSGI () const
  {
    return CC_wf_bef_R_tab_GL_SGI_MSGI;
  }

  const class array<complex<double> > & get_CC_dwf_bef_R_tab_GL_SGI_MSGI () const
  {
    return CC_dwf_bef_R_tab_GL_SGI_MSGI;
  }

  const class array<complex<double> > & get_CC_wf_aft_R_tab_GL () const
  {
    return CC_wf_aft_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_dwf_aft_R_tab_GL () const
  {
    return CC_dwf_aft_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_d2wf_aft_R_tab_GL () const
  {
    return CC_d2wf_aft_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_scaled_wf_minus_aft_R_c_entrance_tab_GL () const
  {
    return CC_scaled_wf_minus_aft_R_c_entrance_tab_GL;
  }

  const class array<complex<double> > & get_CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL () const
  {
    return CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL;
  }

  const class array<complex<double> > & get_CC_scaled_wf_plus_aft_R_tab_GL () const
  {
    return CC_scaled_wf_plus_aft_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_scaled_dwf_plus_aft_R_tab_GL () const
  {
    return CC_scaled_dwf_plus_aft_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_wf_momentum_tab_uniform () const
  {
    return CC_wf_momentum_tab_uniform;
  }
  
  const class array<complex<double> > & get_CC_dwf_momentum_tab_uniform () const
  {
    return CC_dwf_momentum_tab_uniform;
  }
  
  const class array<complex<double> > & get_CC_wf_momentum_tab_GL () const
  {
    return CC_wf_momentum_tab_GL;
  }
  
  const class array<complex<double> > & get_CC_dwf_momentum_tab_GL () const
  {
    return CC_dwf_momentum_tab_GL;
  }
  
  const class array<complex<double> > & get_C0_tab () const
  {
    return C0_tab;
  }

  const class array<complex<double> > & get_Cplus_tab () const
  {
    return Cplus_tab;
  }

  const class array<complex<double> > & get_A0_tab () const
  {
    return A0_tab;
  }

  const class array<complex<double> > & get_Aplus_tab () const
  {
    return Aplus_tab;
  }

  const class array<class vector_class<complex<double> > > & get_HO_overlaps () const
  {
    return HO_overlaps;
  }

  const class array<class vector_class<complex<double> > > & get_HO_overlaps_Fermi () const
  {
    return HO_overlaps_Fermi;
  }

  const class array<class CC_fwd_basis_state> & get_fwd_basis () const
  {
    return fwd_basis;
  }

  const class array<class CC_bwd_basis_state> & get_bwd_basis () const
  {
    return bwd_basis;
  }

  const class CC_bwd_basis_state & get_bwd_U_minus () const
  {
    return bwd_U_minus;
  }


  // Basic routines
  void CC_wf_dwf_d2wf_zero ();
  void change_channels_energy (const complex<double> &E_change);
  void copy_to_file (const string &file_name) const;

  // Jost determinant and determination of the energy
  
  complex<double> Jost_determinant_calc (
					 const bool is_it_entrance_channel_only ,
					 const class potentials_effective_mass &T);
  
  // CC - wave calculations 

  void Berggren_Green_function_CC_waves_no_scaled_tables_calc (
							       const class CC_target_projectile_composite_data &Tpc_data ,
							       const class baryons_data &prot_Y_data , 
							       const class baryons_data &neut_Y_data , 
							       const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
							       const class CC_Hamiltonian_data &CC_H_data);

  //--// change the u_c (r) by their projection in an HO basis
  void CC_HO_wfs_projection ();

  void wave_calculation_no_scaled_tables_no_channel_orthogonalization (
								       const bool is_it_entrance_channel_only ,
								       const class CC_Hamiltonian_data &CC_H_data , 
								       const class HF_nucleons_data &prot_HF_data,
								       const class HF_nucleons_data &neut_HF_data,
								       const class potentials_effective_mass &T);
  
  void scaled_tables_calc ();

  void wave_channel_orthogonalization (const class CC_Hamiltonian_data &CC_H_data);

  // For HF calculations

  unsigned int HF_channel_index (
				 const unsigned int ic ,
				 const class HF_nucleons_data &CC_prot_HF_data,
				 const class HF_nucleons_data &CC_neut_HF_data) const;

  void put_shells_HF (
		      class HF_nucleons_data &CC_prot_HF_data , 
		      class HF_nucleons_data &CC_neut_HF_data) const;

  double test_calc (
		    const bool is_it_entrance_channel_only ,
		    const class array<complex<double> > &A0_bef_tab,
		    const class array<complex<double> > &Aplus_bef_tab) const;

  class CC_state_class & operator = (const class CC_state_class &X);

  void overlap_function_calc (
			      const bool is_it_Gauss_Legendre , 
			      const class correlated_state_str &PSI_in_qn ,  
			      const enum particle_type projectile , 
			      const int LCM_projectile ,
			      const double J_projectile , 
			      class array<TYPE> &overlap_function_tab) const;

  TYPE spectroscopic_factor_calc (
				  const class correlated_state_str &PSI_in_qn ,  
				  const enum particle_type projectile , 
				  const int LCM_projectile ,
				  const double J_projectile) const;
 
  void density_calc (
		     const bool is_it_radial , 
		     const bool is_it_Gauss_Legendre ,
		     class array<TYPE> &density_tab) const;

  // HO overlaps

  void HO_overlaps_calc (
			 const bool is_it_entrance_channel_only ,
			 const class CC_Hamiltonian_data &CC_H_data);

  void wfs_dwfs_momentum_calc (const bool is_it_entrance_channel_only);
  
  void wfs_dwfs_HO_projection_momentum_calc (const bool is_it_entrance_channel_only);
  
  complex<double> get_T_matrix_value (const unsigned int ic_entrance , const unsigned int ic) const;

  complex<double> get_phase_shift (const unsigned int ic) const;
  
  void partial_widths_current_formula_calc () const;
  
  void CC_uc_wfs_test_pole (
			    const class CC_target_projectile_composite_data &Tpc_data , 
			    const class baryons_data &prot_Y_data , 
			    const class baryons_data &neut_Y_data , 
			    const class array<class cluster_data> &cluster_projectile_data_tab , 
			    const class CC_Hamiltonian_data &CC_H_data) const;
  
  friend double used_memory_calc (const class CC_state_class &T);
  
private:
  
  bool are_there_scaled_wfs;

  unsigned int N_channels;
  unsigned int ic_entrance;
  
  double R;
  double matching_point;
  double R0;
  double R_max;

  double kmax_momentum;

  double R_Fermi_momentum;
  
  unsigned int N_bef_R_uniform;
  unsigned int N_aft_R_uniform;
  
  unsigned int N_bef_R_GL;
  unsigned int N_aft_R_GL;
  
  unsigned int Nk_momentum_uniform; 
  unsigned int Nk_momentum_GL;

  double step_bef_R_uniform;
  double step_aft_R_uniform;
  
  double step_momentum_uniform;
  
  unsigned int N_bef_mp_uniform;
  unsigned int N_aft_mp_uniform;
  
  int A;
  
  int nmax_HO_local_plus_one;
  int Nmax_HO_potentials_plus_one;

  double R_HO_end;
  
  double J;
  double M;

  unsigned int BP;

  int n;

  bool S_matrix_pole;
  bool is_it_HO_projected;

  unsigned int N_bef_mp_GL;
  unsigned int N_aft_mp_GL;
  
  unsigned int N_bef_mp_GL_SGI_MSGI;
  unsigned int N_aft_mp_GL_SGI_MSGI;
  
  complex<double> E;
  complex<double> Cminus_entrance_channel;
  
  bool is_E_ok;
	
  // Channel tab 
  class array<class CC_channel_class> channels_tab;

  // Positions and weights 
  class array<double> r_bef_R_tab_uniform;
  class array<double> k_tab_uniform;
  
  class array<double> r_bef_R_tab_GL , k_tab_GL  , r_bef_R_tab_GL_SGI_MSGI , r_aft_R_tab_GL_real , um4_aft_R_tab_GL;
  class array<double> w_bef_R_tab_GL , wk_tab_GL , w_bef_R_tab_GL_SGI_MSGI , w_aft_R_tab_GL_real , w_aft_R_tab_GL;
  

  // CC - wave functions , scaled functions , and their C0 , Cplus 
  class array<complex<double> > CC_wf_bef_R_tab_uniform , CC_dwf_bef_R_tab_uniform , CC_d2wf_bef_R_tab_uniform;
  class array<complex<double> > CC_wf_bef_R_tab_GL  , CC_dwf_bef_R_tab_GL  , CC_d2wf_bef_R_tab_GL;
  class array<complex<double> > CC_wf_aft_R_tab_GL  , CC_dwf_aft_R_tab_GL  , CC_d2wf_aft_R_tab_GL;
  
  class array<complex<double> > CC_wf_bef_R_tab_GL_SGI_MSGI , CC_dwf_bef_R_tab_GL_SGI_MSGI;

  class array<complex<double> > CC_scaled_wf_minus_aft_R_c_entrance_tab_uniform , CC_scaled_dwf_minus_aft_R_c_entrance_tab_uniform;
  class array<complex<double> > CC_scaled_wf_minus_aft_R_c_entrance_tab_GL  , CC_scaled_dwf_minus_aft_R_c_entrance_tab_GL;
  
  class array<complex<double> > CC_scaled_wf_plus_aft_R_tab_uniform , CC_scaled_dwf_plus_aft_R_tab_uniform;
  class array<complex<double> > CC_scaled_wf_plus_aft_R_tab_GL  , CC_scaled_dwf_plus_aft_R_tab_GL;
  
  class array<complex<double> > CC_asymptotic_in_zero_wf_bef_R_tab_uniform;

  class array<complex<double> > CC_wf_momentum_tab_uniform , CC_dwf_momentum_tab_uniform;
  
  class array<complex<double> > CC_wf_momentum_tab_GL , CC_dwf_momentum_tab_GL;
  
  class array<complex<double> > C0_tab , Cplus_tab;
  class array<complex<double> > A0_tab , Aplus_tab;

  class array<class vector_class<complex<double> > > HO_overlaps;
  class array<class vector_class<complex<double> > > HO_overlaps_Fermi;

  class array<class CC_fwd_basis_state> fwd_basis;
  class array<class CC_bwd_basis_state> bwd_basis;

  class CC_bwd_basis_state bwd_U_minus;

  // Diagonalization (pole) and linear system solution (scat) in the Berggren basis 

  void CC_waves_bef_R_from_CC_Berggren_expansion_one_baryon_calc (
								   const class CC_Hamiltonian_data &CC_H_data ,
								   const class baryons_data &prot_Y_data_CC_Berggren , 
								   const class baryons_data &neut_Y_data_CC_Berggren ,
								   class vector_class<complex<double> > &Berggren_expansion_vector);

  void CC_waves_bef_R_from_CC_Berggren_expansion_cluster_calc (
							       const class CC_Hamiltonian_data &CC_H_data,
							       const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
							       class vector_class<complex<double> > &Berggren_expansion_vector);

  void CC_waves_momentum_from_CC_Berggren_expansion_one_baryon_calc (
								      const class CC_Hamiltonian_data &CC_H_data ,
								      const class baryons_data &prot_Y_data_CC_Berggren , 
								      const class baryons_data &neut_Y_data_CC_Berggren ,
								      class vector_class<complex<double> > &Berggren_expansion_vector);

  void CC_waves_momentum_from_CC_Berggren_expansion_cluster_calc (
								  const class CC_Hamiltonian_data &CC_H_data,
								  const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
								  class vector_class<complex<double> > &Berggren_expansion_vector);
  
  void pole_state_waves_from_CC_Berggren_expansion_calc (
							 const class CC_target_projectile_composite_data &Tpc_data ,
							 const class CC_Hamiltonian_data &CC_H_data ,
							 const class baryons_data &prot_Y_data_CC_Berggren , 
							 const class baryons_data &neut_Y_data_CC_Berggren , 
							 const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
							 const complex<double> &eigenvalue,
							 class vector_class<complex<double> > &Berggren_expansion_vector);

  void scat_state_waves_from_CC_Berggren_expansion_calc (
							 const class CC_target_projectile_composite_data &Tpc_data ,
							 const class CC_Hamiltonian_data &CC_H_data ,
							 const class baryons_data &prot_Y_data_CC_Berggren , 
							 const class baryons_data &neut_Y_data_CC_Berggren , 
							 const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
							 class vector_class<complex<double> > &orth_H_CC_Berggren_scat);

  void Berggren_expansion_pole_state_eigenvalue_calc (
						      const class CC_target_projectile_composite_data &Tpc_data ,
						      const class CC_Hamiltonian_data &CC_H_data ,
						      complex<double> &orth_H_eigenvalue,
						      class vector_class<complex<double> > &orth_H_CC_Berggren_eig_vec);

  class vector_class<complex<double> > Berggren_expansion_scat_source_one_baryon_calc (
											const class baryons_data &prot_Y_data_CC_Berggren , 
											const class baryons_data &neut_Y_data_CC_Berggren ,
											const class CC_Hamiltonian_data &CC_H_data);

  class vector_class<complex<double> > Berggren_expansion_scat_source_cluster_calc (
										    const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab ,
										    const class CC_Hamiltonian_data &CC_H_data);

  class vector_class<complex<double> > Berggren_expansion_scat_state_calc (
									   const class CC_target_projectile_composite_data &Tpc_data ,
									   const class baryons_data &prot_Y_data_CC_Berggren , 
									   const class baryons_data &neut_Y_data_CC_Berggren , 
									   const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
									   const class CC_Hamiltonian_data &CC_H_data);

  void Cplus_calc (const unsigned int ic);

  void entrance_Cplus_Cminus_calc ();

  class CC_channel_class& lowest_channel_determine () const;

  // CC-wave calculations
  void CC_asymptotic_in_zero_wf_before_R_calc (const bool is_it_entrance_channel_only , const class potentials_effective_mass &T );
  void CC_wfs_dwfs_bef_R_calc (const bool is_it_entrance_channel_only);
  void CC_d2wfs_bef_R_calc (const bool is_it_entrance_channel_only , const class potentials_effective_mass &T );
  void CC_wfs_dwfs_d2wfs_aft_R_tab_GL_calc (const bool is_it_entrance_channel_only);

  void non_orthogonality_restoration (const class CC_Hamiltonian_data &CC_H_data) ;

  void branch_cut_correction (
			      const complex<double> &exp_two_Pi_eta_c,
			      const complex<double> &exp_two_Pi_eta_c_minus_one,
			      class Coulomb_wave_functions &cwf,
			      const class array<complex<double> > &z_tab,
			      const unsigned int ic,
			      const unsigned int angle_index,
			      const unsigned int wf_index,
			      bool &is_it_crossed,
			      class array<complex<double> > &scaled_wfs,
			      class array<complex<double> > &scaled_dwfs);

  void CC_out_ingoing_waves_after_R (const unsigned int angle_index);

  complex<double> overlap_OCM_core_shell_calc (
					       const class spherical_state &OCM_core_shell,
					       const unsigned int ic) const;

  void OCM_core_channel_orthogonalize (
				       const class spherical_state &OCM_core_shell,
				       const unsigned int ic);

  void OCM_orthogonalization (const class HF_nucleons_data &HF_data);

  void basis_states_calc (const bool is_it_entrance_channel_only , const class potentials_effective_mass &T);

  void constants_calc (const bool is_it_entrance_channel_only);

  // Normalization

  complex<double> Gamow_partial_squared_norm_no_channel_orthogonalization (const unsigned int ic) const;
 
  complex<double> Gamow_norm_no_channel_orthogonalization () const;

  complex<double> finite_range_overlaps_square_norm (const class CC_Hamiltonian_data &CC_H_data) const;

  complex<double> Gamow_norm_with_channel_orthogonalization (const class CC_Hamiltonian_data &CC_H_data) const;

  void normalization (const complex<double> &factor);
};


ostream& operator << (ostream &os , const class CC_state_class &ps);

#endif


