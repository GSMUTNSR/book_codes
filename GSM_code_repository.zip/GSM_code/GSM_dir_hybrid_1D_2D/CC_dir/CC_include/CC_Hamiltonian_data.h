#ifndef CC_HAMILTONIAN_DATA_H
#define CC_HAMILTONIAN_DATA_H

// Class containing data relative to the GSM-CC Hamiltonian with HO, GSM (HO or Berggren) and GSM-CC Berggren basis
// Parity and J are fixed in this class.
// The GSM-CC Hamiltonian is diagonalized with the Jacobi-Davidson method if one considers spectrum.
// The Lippmann-Schwinger equation issued from the GSM-CC Hamiltonian is expanded with the GSM-CC Berggren basis, with which a linear system must be solved,
// See the book for details.
 
class CC_Hamiltonian_data
{
public:
  
  CC_Hamiltonian_data ();
  
  CC_Hamiltonian_data (const unsigned int N_channels_c , const class input_data_str &input_data_CC_Berggren);

  CC_Hamiltonian_data (const class CC_Hamiltonian_data &X);
  
  void allocate (const unsigned int N_channels_c , const class input_data_str &input_data_CC_Berggren);

  void allocate_fill (const class CC_Hamiltonian_data &X);

  void deallocate (); 

  unsigned int get_N_channels () const
  {
    return N_channels;
  }
  
  unsigned int get_N_restarts () const
  {
    return N_restarts;
  }

  unsigned int get_Davidson_max_dimension () const
  {
    return Davidson_max_dimension;
  }

  double get_Davidson_eigenvector_precision () const
  {
    return Davidson_eigenvector_precision;
  }

  double get_relative_SVD_precision () const
  {
    return relative_SVD_precision;
  }

  double get_R_cut_function () const
  {
    return R_cut_function;
  }

  double get_d_cut_function () const
  {
    return d_cut_function;
  }

  double get_Ueq_regularizor () const
  {
    return Ueq_regularizor;
  }
    
  void set_dimension_matrices_pole_approximation (const unsigned int dimension_matrices_pole_approximation_c)
  {
    dimension_matrices_pole_approximation = dimension_matrices_pole_approximation_c;
  }

  unsigned int get_dimension_matrices_pole_approximation () const
  {
    return dimension_matrices_pole_approximation;
  }

  void set_dimension_matrices (const unsigned int dimension_matrices_c)
  {
    dimension_matrices = dimension_matrices_c;
  }

  unsigned int get_dimension_matrices () const
  {
    return dimension_matrices;
  }

  void set_dimension_matrices_HO (const unsigned int dimension_matrices_HO_c)
  {
    dimension_matrices_HO = dimension_matrices_HO_c;
  }

  unsigned int get_dimension_matrices_HO () const
  {
    return dimension_matrices_HO;
  }

  void set_dimension_matrices_pole_approximation_CC_Berggren (const unsigned int dimension_matrices_pole_approximation_CC_Berggren_c)
  {
    dimension_matrices_pole_approximation_CC_Berggren = dimension_matrices_pole_approximation_CC_Berggren_c;
  }

  unsigned int get_dimension_matrices_pole_approximation_CC_Berggren () const
  {
    return dimension_matrices_pole_approximation_CC_Berggren;
  }

  void set_dimension_matrices_partial_pole_approximation_CC_Berggren (const unsigned int dimension_matrices_partial_pole_approximation_CC_Berggren_c)
  {
    dimension_matrices_partial_pole_approximation_CC_Berggren = dimension_matrices_partial_pole_approximation_CC_Berggren_c;
  }

  unsigned int get_dimension_matrices_partial_pole_approximation_CC_Berggren () const
  {
    return dimension_matrices_partial_pole_approximation_CC_Berggren;
  }

  void set_dimension_matrices_CC_Berggren (const unsigned int dimension_matrices_CC_Berggren_c)
  {
    dimension_matrices_CC_Berggren = dimension_matrices_CC_Berggren_c;
  }

  unsigned int get_dimension_matrices_CC_Berggren () const
  {
    return dimension_matrices_CC_Berggren;
  }
  
  class multipolar_expansion_str & get_multipolar_expansion () 
  {
    return multipolar_expansion;
  }

  const class multipolar_expansion_str & get_multipolar_expansion () const
  {
    return multipolar_expansion;
  }

  class CG_str & get_CGs () 
  {
    return CGs;
  }

  const class CG_str & get_CGs () const
  {
    return CGs;
  }
  
  class array<double> & get_HO_wfs_bef_R_tab_uniform () 
  {
    return HO_wfs_bef_R_tab_uniform;
  }

  const class array<double> & get_HO_wfs_bef_R_tab_uniform () const
  {
    return HO_wfs_bef_R_tab_uniform;
  }

  class array<double> & get_HO_wfs_bef_R_tab_GL () 
  {
    return HO_wfs_bef_R_tab_GL;
  }

  const class array<double> & get_HO_wfs_bef_R_tab_GL () const
  {
    return HO_wfs_bef_R_tab_GL;
  }

  class array<double> & get_HO_wfs_aft_R_tab_GL () 
  {
    return HO_wfs_aft_R_tab_GL;
  }

  const class array<double> & get_HO_wfs_aft_R_tab_GL () const
  {
    return HO_wfs_aft_R_tab_GL;
  }

  class array<double> & get_Gaussian_table_GL () 
  {
    return Gaussian_table_GL;
  }

  const class array<double> & get_Gaussian_table_GL () const
  {
    return Gaussian_table_GL;
  }

  class array<double> & get_CC_average_n_scat_target_projectile_max_tab () 
  {
    return CC_average_n_scat_target_projectile_max_tab;
  }

  const class array<double> & get_CC_average_n_scat_target_projectile_max_tab () const
  {
    return CC_average_n_scat_target_projectile_max_tab;
  }

  class array<TYPE> & get_CC_corrective_factors_TBMEs_tab () 
  {
    return CC_corrective_factors_TBMEs_tab;
  }

  const class array<TYPE> & get_CC_corrective_factors_TBMEs_tab () const
  {
    return CC_corrective_factors_TBMEs_tab;
  }

  class array<TYPE> & get_CC_corrective_factors_cluster_tab () 
  {
    return CC_corrective_factors_cluster_tab;
  }

  const class array<TYPE> & get_CC_corrective_factors_cluster_tab () const
  {
    return CC_corrective_factors_cluster_tab;
  }

  class array<class matrix<complex<double> > > & get_QCM_HO_submatrices () 
  {
    return QCM_HO_submatrices;
  }

  const class array<class matrix<complex<double> > > & get_QCM_HO_submatrices () const
  {
    return QCM_HO_submatrices;
  }
  
  class array<class matrix<complex<double> > > & get_QCM_HCM_basis_QCM_HO_submatrices () 
  {
    return QCM_HCM_basis_QCM_HO_submatrices;
  }

  const class array<class matrix<complex<double> > > & get_QCM_HCM_basis_QCM_HO_submatrices () const
  {
    return QCM_HCM_basis_QCM_HO_submatrices;
  }
  
  class array<class matrix<double> > & get_PCM_HCM_basis_PCM_HO_submatrices () 
  {
    return PCM_HCM_basis_PCM_HO_submatrices;
  }

  const class array<class matrix<double> > & get_PCM_HCM_basis_PCM_HO_submatrices () const
  {
    return PCM_HCM_basis_PCM_HO_submatrices;
  }
    
  class array<class matrix<complex<double> > > & get_finite_range_orthogonalized_potential_HO_submatrices () 
  {
    return finite_range_orthogonalized_potential_HO_submatrices;
  }

  const class array<class matrix<complex<double> > > & get_finite_range_orthogonalized_potential_HO_submatrices () const
  {
    return finite_range_orthogonalized_potential_HO_submatrices;
  }

  class array<class matrix<complex<double> > > & get_finite_range_overlaps_HO_submatrices () 
  {
    return finite_range_overlaps_HO_submatrices;
  }
  
  const class array<class matrix<complex<double> > > & get_finite_range_overlaps_HO_submatrices () const
  {
    return finite_range_overlaps_HO_submatrices;
  }

  class array<class matrix<complex<double> > > & get_Delta_HO_submatrices () 
  {
    return Delta_HO_submatrices;
  }

  const class array<class matrix<complex<double> > > & get_Delta_HO_submatrices () const
  {
    return Delta_HO_submatrices;
  }

  class array<bool> & get_is_it_forbidden_channel_tab () 
  {
    return is_it_forbidden_channel_tab;
  }

  const class array<bool> & get_is_it_forbidden_channel_tab () const
  {
    return is_it_forbidden_channel_tab;
  }

  class array<bool> & get_is_it_forbidden_channel_CC_Berggren_tab () 
  {
    return is_it_forbidden_channel_CC_Berggren_tab;
  }

  const class array<bool> & get_is_it_forbidden_channel_CC_Berggren_tab () const
  {
    return is_it_forbidden_channel_CC_Berggren_tab;
  }

  class array<unsigned int> & get_matrices_indices () 
  {
    return matrices_indices;
  }

  const class array<unsigned int> & get_matrices_indices () const
  {
    return matrices_indices;
  }

  class array<unsigned int> & get_matrices_indices_HO () 
  {
    return matrices_indices_HO;
  }

  const class array<unsigned int> & get_matrices_indices_HO () const
  {
    return matrices_indices_HO;
  }

  class array<unsigned int> & get_matrices_indices_CC_Berggren () 
  {
    return matrices_indices_CC_Berggren;
  }

  const class array<unsigned int> & get_matrices_indices_CC_Berggren () const
  {
    return matrices_indices_CC_Berggren;
  }

  class matrix<double> & get_finite_range_overlaps_HO_matrix () 
  {
    return finite_range_overlaps_HO_matrix;
  }

  const class matrix<double> & get_finite_range_overlaps_HO_matrix () const
  {
    return finite_range_overlaps_HO_matrix;
  }

  class matrix<double> & get_finite_range_potential_no_Im_H_HO_matrix () 
  {
    return finite_range_potential_no_Im_H_HO_matrix;
  }

  const class matrix<double> & get_finite_range_potential_no_Im_H_HO_matrix () const
  {
    return finite_range_potential_no_Im_H_HO_matrix;
  }

  class matrix<double> & get_Ho_HO_matrix () 
  {
    return Ho_HO_matrix;
  }

  const class matrix<double> & get_Ho_HO_matrix () const
  {
    return Ho_HO_matrix;
  }

  class matrix<double> & get_finite_range_orthogonalized_potential_no_Im_H_HO_matrix () 
  {
    return finite_range_orthogonalized_potential_no_Im_H_HO_matrix;
  }

  const class matrix<double> & get_finite_range_orthogonalized_potential_no_Im_H_HO_matrix () const
  {
    return finite_range_orthogonalized_potential_no_Im_H_HO_matrix;
  }

  class matrix<double> & get_finite_range_orthogonalized_Im_H_HO_matrix () 
  {
    return finite_range_orthogonalized_Im_H_HO_matrix;
  }

  const class matrix<double> & get_finite_range_orthogonalized_Im_H_HO_matrix () const
  {
    return finite_range_orthogonalized_Im_H_HO_matrix;
  }

  class matrix<double> & get_overlaps_HO_matrix () 
  {
    return overlaps_HO_matrix;
  }

  const class matrix<double> & get_overlaps_HO_matrix () const
  {
    return overlaps_HO_matrix;
  }

  class matrix<double> & get_sqrt_overlaps_HO_matrix () 
  {
    return sqrt_overlaps_HO_matrix;
  }

  const class matrix<double> & get_sqrt_overlaps_HO_matrix () const
  {
    return sqrt_overlaps_HO_matrix;
  }

  class matrix<double> & get_sqrt_inv_overlaps_HO_matrix () 
  {
    return sqrt_inv_overlaps_HO_matrix;
  }

  const class matrix<double> & get_sqrt_inv_overlaps_HO_matrix () const
  {
    return sqrt_inv_overlaps_HO_matrix;
  }

  class matrix<double> & get_Delta_HO_matrix () 
  {
    return Delta_HO_matrix;
  }

  const class matrix<double> & get_Delta_HO_matrix () const
  {
    return Delta_HO_matrix;
  }
  
  class matrix<double> & get_H_no_Im_H_HO_matrix () 
  {
    return H_no_Im_H_HO_matrix;
  }

  const class matrix<double> & get_H_no_Im_H_HO_matrix () const
  {
    return H_no_Im_H_HO_matrix;
  }

  class matrix<double> & get_H_Delta_plus_Delta_H_no_Im_H_HO_matrix () 
  {
    return H_Delta_plus_Delta_H_no_Im_H_HO_matrix;
  }

  const class matrix<double> & get_H_Delta_plus_Delta_H_no_Im_H_HO_matrix () const
  {
    return H_Delta_plus_Delta_H_no_Im_H_HO_matrix;
  }

  class matrix<double> & get_Delta_H_Delta_no_Im_H_HO_matrix () 
  {
    return Delta_H_Delta_no_Im_H_HO_matrix;
  }
  
  const class matrix<double> & get_Delta_H_Delta_no_Im_H_HO_matrix () const
  {
    return Delta_H_Delta_no_Im_H_HO_matrix;
  }

  class matrix<double> & get_Im_H_HO_matrix () 
  {
    return Im_H_HO_matrix;
  }

  const class matrix<double> & get_Im_H_HO_matrix () const
  {
    return Im_H_HO_matrix;
  }

  class matrix<double> & get_Im_H_Delta_plus_Delta_Im_H_HO_matrix () 
  {
    return Im_H_Delta_plus_Delta_Im_H_HO_matrix;
  }

  const class matrix<double> & get_Im_H_Delta_plus_Delta_Im_H_HO_matrix () const
  {
    return Im_H_Delta_plus_Delta_Im_H_HO_matrix;
  }

  class matrix<double> & get_Delta_Im_H_Delta_HO_matrix () 
  {
    return Delta_Im_H_Delta_HO_matrix;
  }
  
  const class matrix<double> & get_Delta_Im_H_Delta_HO_matrix () const
  {
    return Delta_Im_H_Delta_HO_matrix;
  }
  
  class matrix<complex<double> > & get_overlaps_matrix_pole_approximation () 
  {
    return overlaps_matrix_pole_approximation;
  }

  const class matrix<complex<double> > & get_overlaps_matrix_pole_approximation () const
  {
    return overlaps_matrix_pole_approximation;
  }

  class matrix<complex<double> > & get_H_matrix_pole_approximation () 
  {
    return H_matrix_pole_approximation;
  }

  const class matrix<complex<double> > & get_H_matrix_pole_approximation () const
  {
    return H_matrix_pole_approximation;
  }

  class matrix<complex<double> > & get_overlaps_matrix () 
  {
    return overlaps_matrix;
  }

  const class matrix<complex<double> > & get_overlaps_matrix () const
  {
    return overlaps_matrix;
  }

  class matrix<complex<double> > & get_H_matrix () 
  {
    return H_matrix;
  }

  const class matrix<complex<double> > & get_H_matrix () const
  {
    return H_matrix;
  }

  class matrix<complex<double> > & get_orthogonalized_H_matrix_CC_Berggren () 
  {
    return orthogonalized_H_matrix_CC_Berggren;
  }

  const class matrix<complex<double> > & get_orthogonalized_H_matrix_CC_Berggren () const
  {
    return orthogonalized_H_matrix_CC_Berggren;
  }

  class matrix<complex<double> > & get_orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren () 
  {
    return orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren;
  }

  const class matrix<complex<double> > & get_orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren () const
  {
    return orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren;
  }

  class matrix<complex<double> > & get_orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren () 
  {
    return orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren;
  }

  const class matrix<complex<double> > & get_orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren () const
  {
    return orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren;
  }

  class array<complex<double> > & get_orthogonalized_H_tridiagonalized_diagonal_CC_Berggren () 
  {
    return orthogonalized_H_tridiagonalized_diagonal_CC_Berggren;
  }

  const class array<complex<double> > & get_orthogonalized_H_tridiagonalized_diagonal_CC_Berggren () const
  {
    return orthogonalized_H_tridiagonalized_diagonal_CC_Berggren;
  }

  class array<complex<double> > & get_orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren () 
  {
    return orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren;
  }

  const class array<complex<double> > & get_orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren () const
  {
    return orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren;
  }

  class array<complex<double> > & get_Ueq_tab () 
  {
    return Ueq_tab;
  }

  const class array<complex<double> > & get_Ueq_tab () const
  {
    return Ueq_tab;
  }

  class array<complex<double> > & get_source_tab () 
  {
    return source_tab;
  }

  const class array<complex<double> > & get_source_tab () const
  {
    return source_tab;
  }

  void submatrices_realloc_one_baryon_init (
					    const class array<class CC_channel_class> &channels_tab , 
					    const class array<int> &nmax_HO_lab_tab);

  void submatrices_realloc_cluster_init (
					 const class array<class CC_channel_class> &channels_tab , 
					 const class array<class cluster_data> &cluster_projectile_data_tab); 

  void dimension_matrices_independent_data_realloc_init (
							 const bool is_it_one_baryon_COSM_case , 
							 const class input_data_str &input_data_CC_Berggren , 
							 const class interaction_class &inter_data_basis , 
							 const class array<class CC_channel_class> &channels_tab , 
							 const class baryons_data &prot_Y_data , 
							 const class baryons_data &neut_Y_data , 
							 const class array<class cluster_data> &cluster_projectile_data_tab , 
							 const class baryons_data &prot_Y_data_CC_Berggren , 
							 const class baryons_data &neut_Y_data_CC_Berggren , 
							 const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab);

  void dimensions_matrices_one_baryon_calc (
					    const class interaction_class &inter_data_basis , 
					    const class baryons_data &prot_Y_data , 
					    const class baryons_data &neut_Y_data , 
					    const class baryons_data &prot_Y_data_CC_Berggren , 
					    const class baryons_data &neut_Y_data_CC_Berggren , 
					    const class array<class CC_channel_class> &channels_tab);

  void dimensions_matrices_cluster_calc (
					 const class array<class CC_channel_class> &channels_tab , 
					 const class array<class cluster_data> &cluster_projectile_data_tab , 
					 const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab); 

  void dimension_matrices_dependent_data_realloc_init ();

  void all_matrices_indices_one_baryon_calc (
					     const class interaction_class &inter_data_basis , 
					     const class baryons_data &prot_Y_data , 
					     const class baryons_data &neut_Y_data , 
					     const class baryons_data &prot_Y_data_CC_Berggren , 
					     const class baryons_data &neut_Y_data_CC_Berggren ,  
					     const class array<class CC_channel_class> &channels_tab);

  void all_matrices_indices_cluster_calc (
					  const class array<class CC_channel_class> &channels_tab , 
					  const class array<class cluster_data> &cluster_projectile_data_tab , 
					  const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab);

  void is_it_forbidden_channel_CC_Berggren_tab_one_baryon_determine (
								     const class array<class CC_channel_class> &channels_tab , 
								     const class baryons_data &prot_Y_data , 
								     const class baryons_data &neut_Y_data );

  void is_it_forbidden_channel_CC_Berggren_tab_cluster_determine  (
								   const class array<class CC_channel_class> &channels_tab , 
								   const class array<class cluster_data> &cluster_projectile_data_tab);

  void HO_wfs_Gaussian_tables_calc (
				    const double R , 
				    const double R_max , 
				    const class array<class CC_channel_class> &channels_tab , 
				    const class interaction_class &inter_data_basis);
  
  void corrective_factors_average_n_scat_target_projectile_max_read (const class input_data_str &input_data_CC_Berggren);
			
  void cluster_corrective_factors_modification (
						const class array<class CC_channel_class> &channels_tab ,
						const class array<enum particle_type> &cluster_projectile_tab ,
						const class array<class cluster_data> &cluster_projectile_data_tab);
  
  void orthogonalized_H_matrix_CC_Berggren_cluster_calc (
							 const class array<class CC_channel_class> &channels_tab , 
							 const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab);
  
  void overlaps_H_HO_matrices_calc ();

  void orthogonalized_H_matrix_CC_Berggren_one_baryon_calc (
							    const class array<class CC_channel_class> &channels_tab , 
							    const class baryons_data &prot_Y_data_CC_Berggren , 
							    const class baryons_data &neut_Y_data_CC_Berggren);
  
  void H_overlaps_matrices_copy_disk (const unsigned int BP , const double J) const;

  void H_tridiagonalized_copy_disk (const unsigned int BP , const double J) const;

  void HO_submatrices_one_baryon_fill (
				       const class array<class CC_channel_class> &channels_tab , 
				       const class interaction_class &inter_data_basis);

  void HO_submatrices_cluster_fill (
				    const class array<class CC_channel_class> &channels_tab , 
				    const class array<class cluster_data> &cluster_projectile_data_tab);

  void H_overlaps_matrices_read_from_file (const unsigned int BP , const double J);

  void H_tridiagonalized_read_from_file (const unsigned int BP , const double J);

#ifdef UseMPI
  void H_overlaps_matrices_MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void H_overlaps_matrices_MPI_Allreduce (const MPI_Op op , const MPI_Comm MPI_C);

  void H_tridiagonalized_MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
#endif

  void overlaps_H_matrices_diagonalization_test (const unsigned int BP , const double J) const;
  
  void finite_range_overlaps_potential_Ho_HO_matrices_one_baryon_calc (
								       const class array<class CC_channel_class> &channels_tab , 
								       const class interaction_class &inter_data_basis , 
								       const class HF_nucleons_data &prot_HF_data , 
								       const class HF_nucleons_data &neut_HF_data , 
								       const class baryons_data &prot_Y_data_one_configuration_GSM , 
								       const class baryons_data &neut_Y_data_one_configuration_GSM , 
								       const class baryons_data &prot_Y_data , 
								       const class baryons_data &neut_Y_data , 
								       const class baryons_data &prot_Y_data_CC_Berggren , 
								       const class baryons_data &neut_Y_data_CC_Berggren);
  
  void finite_range_overlaps_potential_Ho_HO_matrices_cluster_calc (
								    const class array<class CC_channel_class> &channels_tab , 
								    const class array<class cluster_data> &cluster_projectile_data_tab);

  void Delta_H_HO_matrices_one_baryon_calc (
					    const class array<class CC_channel_class> &channels_tab , 
					    const class baryons_data &prot_Y_data , 
					    const class baryons_data &neut_Y_data , 
					    const class interaction_class &inter_data_basis);

  void Delta_H_HO_matrices_cluster_calc (
					 const class array<class CC_channel_class> &channels_tab , 
					 const class array<class cluster_data> &cluster_projectile_data_tab);

  void PCM_function_HO_matrices_cluster_calc (
					      const class array<class CC_channel_class> &channels_tab , 
					      const class array<class cluster_data> &cluster_projectile_data_tab);

  void orthogonalized_H_tridiagonalization_CC_Berggren ();

  friend double used_memory_calc (const class CC_Hamiltonian_data &T);
  
private:

  unsigned int N_channels;               // number of channels used in the GSM-CC Hamiltonian. Parity and J are fixed at this level.
  unsigned int N_restarts;               // Maximal number of restarts of Jacobi-Davidson method, i.e. with a new starting pivot vector. One restarts if all Jacobi-Davidson vectors have been used without having convergence.
  unsigned int Davidson_max_dimension;   // Maximal number of Jacobi-Davidson vectors used in Hamiltonian diagonalization

  enum potential_type H_potential;       // Potential type of the core potential present in the Hamiltonian (WS, WS-analytic, complex-WS, complex-WS-analytic, KKNN).
  
  double Davidson_eigenvector_precision; // Precision under which one considers that the Jacobi-Davidson method converges.
                                         // It is the infinite norm of the component of the last calculated Lanczos or Jacobi-Davidson vector

  double relative_SVD_precision;         // eigenvalues of the matrix of the overlap matrices to invert in the GSM-CC equations to orthogonalize channels are ignored in the solution 
                                         // if they are smaller in modulus than relative_SVD_precision when inverting the linear system with the Moore-Penrose pseudo-inverse

  double R_cut_function;                 // diffuseness of the Fermi cut function F(r) (see basic_maths.cpp) used in GSM-CC potentials for stability
  double d_cut_function;                 // radius      of the Fermi cut function F(r) (see basic_maths.cpp) used in GSM-CC potentials for stability
  
  double Ueq_regularizor;                // Regularization factor used in the GSM-CC potential (see above)

  unsigned int dimension_matrices_pole_approximation; // dimension of the GSM-CC Hamiltonian at pole approximation level when written in the GSM basis (HO or Berggren typically)
  unsigned int dimension_matrices;                    // dimension of the GSM-CC Hamiltonian when written in the GSM basis (HO or Berggren typically)
  unsigned int dimension_matrices_HO;                 // dimension of the GSM-CC Hamiltonian when written in the HO basis

  unsigned int dimension_matrices_pole_approximation_CC_Berggren;          // dimension of the GSM-CC Hamiltonian at pole approximation level when written in the GSM-CC Berggren basis
  unsigned int dimension_matrices_partial_pole_approximation_CC_Berggren;  // dimension of the GSM-CC Hamiltonian if target or projectile is a pole state when written in the GSM-CC Berggren basis
  unsigned int dimension_matrices_CC_Berggren;                             // dimension of the GSM-CC Hamiltonian when written in the GSM-CC Berggren basis
  
  class multipolar_expansion_str multipolar_expansion; // structure storing the angular two-body matrix elements (4 Pi)/(2l + 1) <c d | Yl(1).Yl(2) | a b>_J arising in a multipolar expansion (see GSM_small_classes.cpp)

  class CG_str CGs;                                    // structure storing Clebsch-Gordan coefficients (see GSM_small_classes.cpp)

  class array<double> HO_wfs_bef_R_tab_uniform;        // HO radial wave functions in [0:R] stored using uniform distribution
  
  class array<double> HO_wfs_bef_R_tab_GL;             // HO radial wave functions in [0:R] stored using Gauss-Legendre abscissa
  class array<double> HO_wfs_aft_R_tab_GL;             // HO radial wave functions in [0:R] stored using Gauss-Legendre abscissa

  class array<double> Gaussian_table_GL;               // arrays of the Gaussian terms entering the MSGI interaction in [0:R] (see GSM_HF_potentials_common_MSGI_part_common.cpp)

  class array<double> CC_average_n_scat_target_projectile_max_tab; // array of corrective factors of the CC state for which one considers truncation in terms of average n[scat]
                                                                   // Their structure is T(BP,2.J).

  class array<TYPE> CC_corrective_factors_TBMEs_tab;                // array of corrective factors of the CC state by which interaction TBMEs are multiplied
                                                                   // Their structure is T(BP,2.J).

  class array<TYPE> CC_corrective_factors_cluster_tab;             // array of corrective factors of the CC state by which nuclear potentials involving many-body clusters are multiplied
                                                                   // Their structure is T(BP,2.J).
  
  // The structure of ...CM_HO_submatrices afterwards is always of the form M(ic)(NCM[HO],NCM'[HO]).

  class array<class matrix<complex<double> > > QCM_HO_submatrices; // array of projectors matrices in the HO basis Q[CM] = \sum{NCM < Nmin} |NCM><NCM|, with |NCM>< a Berggren projectile CM wave function

  class array<class matrix<complex<double> > > QCM_HCM_basis_QCM_HO_submatrices; // array of matrices in the HO basis equal to Q[CM] H[basis][CM] Q[CM], with H[basis][CM] the Hamiltonian generating Berggren projectile CM wave functions  

  class array<class matrix<double> > PCM_HCM_basis_PCM_HO_submatrices; // array of matrices in the HO basis equal to P[CM] H[basis][CM] P[CM], with P[CM] = Id - Q[CM]. It is not complex as it is used only in Ho of Ho_HO_matrix.
    
  // The structure of ..._HO_submatrices afterwards is always of the form M(ic,ic')(nc[HO],nc'[HO]).
  
  class array<class matrix<complex<double> > > finite_range_orthogonalized_potential_HO_submatrices; // arrays of matrices of the finite range potential part of H (everything except kinetic and one-body Coulomb)
                                                                                                     // using orthogonalized channels in the HO basis as GSM-CC basis. Imaginary parts of WS potentials are included.

  class array<class matrix<complex<double> > > finite_range_overlaps_HO_submatrices;  // arrays of matrices of the finite range part of overlaps, i.e. overlaps - Id, between channels in the HO basis.
  
  class array<class matrix<complex<double> > > Delta_HO_submatrices; // arrays of matrices Delta = O^{-1/2} - Id in the HO basis, where O is the matrix of overlaps <c | c'>,
                                                                     // used for the calculation of H using orthogonalized channels (see the book for details).

  class array<bool> is_it_forbidden_channel_tab;             // booleans stating whether a channel is forbidden (i.e. redundant as a linear combination of others) or not using GSM    model space data
  class array<bool> is_it_forbidden_channel_CC_Berggren_tab; // booleans stating whether a channel is forbidden (i.e. redundant as a linear combination of others) or not using GSM-CC model space data

  class array<unsigned int> matrices_indices;                // Indices of basis channels with fixed n or NCM value in the GSM    one-body basis, denoted after as I(ic,nc).
  class array<unsigned int> matrices_indices_HO;             // Indices of basis channels with fixed n or NCM value in the HO     one-body basis, denoted after as I(ic,nc[HO]).
  class array<unsigned int> matrices_indices_CC_Berggren;    // Indices of basis channels with fixed n or NCM value in the GSM-CC one-body basis, denoted after as I(ic,nc).

  // The structure of ..._HO_matrix afterwards is always of the form M(I(ic,nc[HO]),I(ic',nc'[HO]))
  
  class matrix<double> finite_range_overlaps_HO_matrix;  // arrays of matrices of the finite range part of overlaps, i.e. overlaps - Id, in the HO basis.

  class matrix<double> finite_range_potential_no_Im_H_HO_matrix; // arrays of matrices of the finite range potential part of H (everything except kinetic and one-body Coulomb) between channels in the HO basis. WS imaginary parts are not considered.

  class matrix<double> Ho_HO_matrix; // Matrix of the basis-generating Hamiltonian (denoted as Ho, where Ho = H[target] + H[projectile], with H[projectile] = T[projectile] + U[basis][projectile] in the HO basis.
  
  class matrix<double> finite_range_orthogonalized_potential_no_Im_H_HO_matrix; // Matrix of the finite range potential part of H (everything except kinetic and one-body Coulomb) 
                                                                                 // using orthogonalized channels in the HO basis as GSM-CC basis. WS imaginary parts are not considered.
  
  class matrix<double> finite_range_orthogonalized_Im_H_HO_matrix;  // Matrix of the finite range potential part of Im[H] using orthogonalized channels in the HO basis as GSM-CC basis.
  
  class matrix<double> overlaps_HO_matrix;             // matrix of overlaps O = <c | c'> in the HO basis
  class matrix<double> sqrt_overlaps_HO_matrix;        // matrix O^{1/2} in the HO basis
  class matrix<double> sqrt_inv_overlaps_HO_matrix;    // matrix O^{-1/2} in the HO basis
  
  class matrix<double> Delta_HO_matrix;                // matrix of Delta in the HO basis, with Delta = O^{-1/2} - Id, used for the calculation of H using orthogonalized channels.
  
  class matrix<double> H_no_Im_H_HO_matrix;                    // matrix of the GSM-CC Hamiltonian H in the HO basis.                                                                                          WS imaginary parts are not considered.
  class matrix<double> H_Delta_plus_Delta_H_no_Im_H_HO_matrix; // matrix of H.Delta + Delta.H        in the HO basis, with Delta = O^{-1/2} - Id, used for the calculation of H using orthogonalized channels. WS imaginary parts are not considered.
  class matrix<double> Delta_H_Delta_no_Im_H_HO_matrix;        // matrix of Delta.H.Delta            in the HO basis, with Delta = O^{-1/2} - Id, used for the calculation of H using orthogonalized channels. WS imaginary parts are not considered.

  class matrix<double> Im_H_HO_matrix;                       // matrix of Im[H]                     in the HO basis.
  class matrix<double> Im_H_Delta_plus_Delta_Im_H_HO_matrix; // matrix of Im[H].Delta + Delta.Im[H] in the HO basis, with Delta = O^{-1/2} - Id, used for the calculation of H using orthogonalized channels. 
  class matrix<double> Delta_Im_H_Delta_HO_matrix;           // matrix of Delta.Im[H].Delta         in the HO basis, with Delta = O^{-1/2} - Id, used for the calculation of H using orthogonalized channels.
  


  
  // The structure of matrices afterwards is always of the form M(I(ic,nc[GSM]),I(ic',nc'[GSM]))
  
  class matrix<complex<double> > overlaps_matrix_pole_approximation; // matrix of overlaps O = <c | c'>    at pole approximation level in the GSM basis 
  class matrix<complex<double> > H_matrix_pole_approximation;        // matrix of the GSM-CC Hamiltonian H at pole approximation level in the GSM basis 
  
  class matrix<complex<double> > overlaps_matrix; // matrix of overlaps O = <c | c'>    in the GSM basis.
  class matrix<complex<double> > H_matrix;        // matrix of the GSM-CC Hamiltonian H in the GSM basis. WS imaginary parts are not considered.
  
  // The structure of orthogonalized_..._matrix_CC_Berggren afterwards is always of the form M(index,index'), with index, index' in [0:dimension_matrices_CC_Berggren - 1]
  
  class matrix<complex<double> > orthogonalized_H_matrix_CC_Berggren;                             // matrix of the GSM-CC Hamiltonian H in the GSM-CC basis using orthogonalized channels
  class matrix<complex<double> > orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren;           // matrix transfer of the GSM-CC Hamiltonian H in tridiagonal form in the GSM-CC basis using orthogonalized channels
  class matrix<complex<double> > orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren; // matrix transfer transpose of the GSM-CC Hamiltonian H in tridiagonal form in the GSM-CC basis using orthogonalized channels

  // The structure of orthogonalized_..._CC_Berggren afterwards is always of the form M(index), with index in [0:dimension_matrices_CC_Berggren - 1]
  
  class array<complex<double> > orthogonalized_H_tridiagonalized_diagonal_CC_Berggren;     //     diagonal part of the GSM-CC Hamiltonian H in tridiagonal form in the GSM-CC basis using orthogonalized channels
  class array<complex<double> > orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren; // off-diagonal part of the GSM-CC Hamiltonian H in tridiagonal form in the GSM-CC basis using orthogonalized channels

  class array<complex<double> > Ueq_tab;    // equivalent potentials of the GSM-CC Hamiltonian of the form Ueq_tab(ic , ic' , i[r]).
  class array<complex<double> > source_tab; // sources of the equivalent potentials of the GSM-CC Hamiltonian of the form source_tab(ic , ic' , i[r]).

  void matrices_indices_pole_approximation_one_baryon_calc (
							    const class baryons_data &prot_Y_data , 
							    const class baryons_data &neut_Y_data , 
							    const class baryons_data &prot_Y_data_CC_Berggren , 
							    const class baryons_data &neut_Y_data_CC_Berggren , 
							    const class array<class CC_channel_class> &channels_tab);

  void matrices_indices_partial_pole_approximation_CC_Berggren_one_baryon_calc (
										const class baryons_data &prot_Y_data_CC_Berggren , 
										const class baryons_data &neut_Y_data_CC_Berggren , 
										const class array<class CC_channel_class> &channels_tab);

  void matrices_indices_one_baryon_calc (
					 const class interaction_class &inter_data_basis , 
					 const class baryons_data &prot_Y_data , 
					 const class baryons_data &neut_Y_data , 
					 const class baryons_data &prot_Y_data_CC_Berggren , 
					 const class baryons_data &neut_Y_data_CC_Berggren , 
					 const class array<class CC_channel_class> &channels_tab);

  void matrices_indices_pole_approximation_cluster_calc (
							 const class array<class CC_channel_class> &channels_tab , 
							 const class array<class cluster_data> &cluster_projectile_data_tab , 
							 const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab);

  void matrices_indices_partial_pole_approximation_CC_Berggren_cluster_calc (
									     const class array<class CC_channel_class> &channels_tab , 
									     const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab);

  void matrices_indices_cluster_calc (
				      const class array<class CC_channel_class> &channels_tab , 
				      const class array<class cluster_data> &cluster_projectile_data_tab , 
				      const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab);

  void original_to_HO_matrix_one_baryon_calc (
					      const class array<class CC_channel_class> &channels_tab , 
					      const class baryons_data &prot_Y_data , 
					      const class baryons_data &neut_Y_data , 
					      const class interaction_class &inter_data_basis , 
					      const class matrix<complex<double> > &original_matrix , 
					      class matrix<double> &HO_matrix);		

  void original_to_HO_matrix_cluster_calc (
					   const class array<class CC_channel_class> &channels_tab , 
					   const class array<class cluster_data> &cluster_projectile_data_tab , 
					   const class matrix<complex<double> > &original_matrix , 
					   class matrix<double> &HO_matrix);
};



#endif


