#ifndef CC_OBSERVABLESCOMMON_H
#define CC_OBSERVABLESCOMMON_H




namespace CC_observables_common
{
  void data_one_baryon_less_alloc_calc (
					 const bool is_it_full_or_partial_storage , 
					 const enum interaction_type inter,
					 const bool truncation_hw , 
					 const bool truncation_ph ,  
					 const class baryons_data &prot_Y_data,
					 const class baryons_data &neut_Y_data,
					 const class array<enum particle_type> &projectile_tab,
					 class array<class baryons_data> &prot_Y_data_one_baryon_less_tab,
					 class array<class baryons_data> &neut_Y_data_one_baryon_less_tab);
 
  void target_projectile_PSI_HO_one_baryon_calc (
						  const class CC_Hamiltonian_data &CC_H_data ,
						  const class CC_state_class &CC_state , 
						  class baryons_data &prot_Y_data , 
						  class baryons_data &neut_Y_data ,
						  class GSM_vector &PSI_HO);

  void data_one_cluster_less_alloc_calc (
					 const bool is_it_full_or_partial_storage , 
					 const enum interaction_type inter,
					 const bool truncation_hw , 
					 const bool truncation_ph ,  
					 const class baryons_data &prot_Y_data,
					 const class baryons_data &neut_Y_data,
					 const class array<class cluster_data> &cluster_projectile_data_tab, 
					 class array<class baryons_data> &prot_Y_data_one_cluster_less_tab,
					 class array<class baryons_data> &neut_Y_data_one_cluster_less_tab);
    
  void target_projectile_PSI_HO_cluster_calc (
					      const class array<class cluster_data> &cluster_projectile_data_tab ,  
					      const class CC_Hamiltonian_data &CC_H_data ,
					      const class CC_state_class &CC_state , 
					      class GSM_vector &PSI_HO);
   
  void data_one_projectile_less_alloc_calc (
					    const bool is_it_full_or_partial_storage , 
					    const bool is_it_one_baryon_COSM_case , 
					    const enum interaction_type inter , 
					    const bool truncation_hw , 
					    const bool truncation_ph ,  
					    const class baryons_data &prot_Y_data , 
					    const class baryons_data &neut_Y_data , 
					    const class array<enum particle_type> &projectile_tab ,
					    const class array<class cluster_data> &cluster_projectile_data_tab, 
					    class array<class baryons_data> &prot_Y_data_one_projectile_less_tab , 
					    class array<class baryons_data> &neut_Y_data_one_projectile_less_tab);
  
  void target_projectile_PSI_HO_calc (
				      const bool is_it_one_baryon_COSM_case , 
				      const class array<class cluster_data> &cluster_projectile_data_tab ,  
				      const class CC_Hamiltonian_data &CC_H_data ,
				      const class CC_state_class &CC_state , 
				      class baryons_data &prot_Y_data , 
				      class baryons_data &neut_Y_data , 
				      class GSM_vector &PSI_HO);
 
  void CC_eigenstate_H_data_calc (
				  const class CC_target_projectile_composite_data &Tpc_data , 
				  const class interaction_class &inter_data_basis , 
				  const class input_data_str &input_data_CC_Berggren , 
				  const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
				  const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
				  const class array<class cluster_data> &cluster_projectile_data_tab , 
				  class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
				  class baryons_data &prot_Y_data_CC_Berggren , 
				  class baryons_data &neut_Y_data_CC_Berggren ,  
				  class baryons_data &prot_Y_data , 
				  class baryons_data &neut_Y_data , 
				  class correlated_state_str &PSI_qn , 
				  class TBMEs_class &TBMEs_pn ,
				  class TBMEs_class &TBMEs_cv ,
				  class CC_Hamiltonian_data &CC_H_data ,
				  class CC_state_class &CC_state);

  void cross_sections_observables_calc_print_store (
						    const class input_data_str &input_data ,
						    const class input_data_str &input_data_CC_Berggren ,
						    const class interaction_class &inter_data_basis ,
						    const class HF_nucleons_data &prot_HF_data_CC_Berggren ,
						    const class HF_nucleons_data &neut_HF_data_CC_Berggren ,
						    class baryons_data &prot_Y_data ,
						    class baryons_data &neut_Y_data ,
						    class array<class cluster_data> &cluster_projectile_data_tab ,
						    class baryons_data &prot_Y_data_CC_Berggren ,
						    class baryons_data &neut_Y_data_CC_Berggren ,
						    class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
						    class CC_target_projectile_composite_data &Tpc_data ,
						    class TBMEs_class &TBMEs_pn ,
						    class TBMEs_class &TBMEs_cv);
}

#endif


