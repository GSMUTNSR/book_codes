#ifndef CC_BETA_TRANSITIONS_STRENGTH_MES_H
#define CC_BETA_TRANSITIONS_STRENGTH_MES_H

namespace CC_beta_transitions_strength_MEs
{
  namespace radial
  {
    void radial_OBMEs_calc (
			    const enum radial_operator_type radial_operator , 
			    const double R_charge ,
			    const bool is_it_Gauss_Legendre ,  
			    const class CC_state_class &CC_state_in , 
			    const class CC_state_class &CC_state_out , 
			    const unsigned int ic_in , 
			    const unsigned int ic_out , 
			    class array<TYPE> &radial_OBMEs);
  }

  namespace one_nucleon
  {
    void beta_suboperator_OBMEs_reduced_calc (
					      const enum beta_pm_type beta_pm ,
					      const enum radial_operator_type radial_operator ,
					      const enum beta_suboperator_type beta_suboperator ,
					      const double R_charge ,
					      const bool is_it_Gauss_Legendre , 
					      const class CC_state_class &CC_state_in ,
					      const class CC_state_class &CC_state_out ,
					      const unsigned int ic_in ,
					      const unsigned int ic_out ,
					      class array<TYPE> &beta_suboperator_OBMEs_reduced);
    
    void beta_suboperators_OBMEs_reduced_calc (
					       const enum beta_type beta , 
					       const enum beta_pm_type beta_pm ,
					       const double R_charge ,
					       const bool is_it_Gauss_Legendre , 
					       const class CC_state_class &CC_state_in , 
					       const class CC_state_class &CC_state_out , 
					       const unsigned int ic_in , 
					       const unsigned int ic_out , 
					       class array<TYPE> &beta_suboperator_OBMEs_reduced);
    
  }

  namespace cluster
  {
    void beta_suboperator_intrinsic_NBMEs_calc (
						const enum beta_pm_type beta_pm ,
						const enum radial_operator_type radial_operator ,
						const enum beta_suboperator_type beta_suboperator ,
						const bool is_it_Gauss_Legendre ,
						const class correlated_state_str &PSI_cluster_qn_c ,  
						const class correlated_state_str &PSI_cluster_qn_cp ,
						const class GSM_vector &PSI_cluster_cp ,
						class array<TYPE> &beta_suboperator_intrinsic_NBMEs);
    
    void beta_suboperators_intrinsic_NBMEs_calc (
						 const enum beta_type beta , 
						 const enum beta_pm_type beta_pm ,
						 const bool is_it_Gauss_Legendre , 
						 const class correlated_state_str &PSI_cluster_qn_c ,  
						 const class correlated_state_str &PSI_cluster_qn_cp ,
						 const class GSM_vector &PSI_cluster_cp ,
						 class array<TYPE> &beta_suboperators_tab);
    
    void beta_suboperator_NBMEs_calc (
				      const enum beta_type beta ,
				      const enum radial_operator_type radial_operator ,
				      const enum beta_suboperator_type beta_suboperator , 
				      const bool is_it_Gauss_Legendre , 
				      const class CC_target_projectile_composite_data &Tpc_data,
				      const unsigned int ic ,
				      const unsigned int icp ,
				      const class correlated_state_str &PSI_cluster_qn_c ,  
				      const class correlated_state_str &PSI_cluster_qn_cp ,
				      const class CC_state_class &CC_state_in , 
				      const class CC_state_class &CC_state_out , 
				      const unsigned int ic_in , 
				      const unsigned int ic_out,
				      class array<TYPE> &beta_suboperators_tab);

    void beta_suboperators_NBMEs_calc (
				       const enum beta_type beta , 
				       const bool is_it_Gauss_Legendre , 
				       const class CC_target_projectile_composite_data &Tpc_data,
				       const unsigned int ic ,
				       const unsigned int icp ,
				       const class correlated_state_str &PSI_cluster_qn_c ,  
				       const class correlated_state_str &PSI_cluster_qn_cp ,
				       const class CC_state_class &CC_state_in , 
				       const class CC_state_class &CC_state_out , 
				       const unsigned int ic_in , 
				       const unsigned int ic_out , 
				       class array<TYPE> &beta_suboperators_tab);
  }

  
  namespace composite
  {
    // calculation of the antisymetrized + HO ME
    void target_projectile_as_HO_NBMEs_calc (
					     const bool is_it_one_nucleon_COSM_case ,
					     const enum beta_type beta , 
					     const enum beta_pm_type beta_pm , 
					     const bool is_it_Gauss_Legendre ,
					     const bool full_common_vectors_used_in_file ,
					     const class CC_Hamiltonian_data &CC_H_data_in , 
					     const class CC_state_class &CC_state_in , 
					     const class CC_Hamiltonian_data &CC_H_data_out , 
					     const class CC_state_class &CC_state_out , 
					     const class input_data_str &input_data_CC_Berggren , 
					     class nucleons_data &prot_data_in , 
					     class nucleons_data &neut_data_in , 
					     class nucleons_data &prot_data_out , 
					     class nucleons_data &neut_data_out ,
					     const class array<class cluster_data> &cluster_projectile_data_tab , 
					     const class array<class vector_class<complex<double> > > &CC_HO_overlaps_in , 
					     const class array<class vector_class<complex<double> > > &CC_HO_overlaps_out , 
					     const class correlated_state_str &PSI_in_qn ,  
					     const class correlated_state_str &PSI_out_qn ,  
					     class array<TYPE> &beta_suboperator_NBMEs);




    // target nas
    // common to the non antisymetrized (nas) and for the non antisymetrized + HO (nas_HO)
    void target_NBMEs_nas_calc (
				const enum beta_type beta ,
				const bool is_it_Gauss_Legendre , 
				const class CC_target_projectile_composite_data &Tpc_data , 
				const class CC_state_class &CC_state_in , 
				const class CC_state_class &CC_state_out , 
				const class array<TYPE> &target_reduced_NBMEs , 
				class array<TYPE> &beta_suboperator_target_reduced_nas_NBMEs);

    // projectile
    // for the non antisymmetrized (nas) NBME
    // the CC_state_out/in are used
    // common to nas and nas+HO
    void projectile_NBMEs_nas_calc (
				    const enum beta_type beta , 
				    const enum beta_pm_type beta_pm , 
				    const bool is_it_Gauss_Legendre , 
				    const class CC_target_projectile_composite_data &Tpc_data , 
				    const class array<class cluster_data> &cluster_projectile_data_tab , 
				    const class CC_state_class &CC_state_in , 
				    const class CC_state_class &CC_state_out , 
				    class array<TYPE> &beta_suboperator_projectile_NBMEs_nas);

    // cf_<J_Tf || beta (T) || J_Ti>_ci NBMEs stored
    void target_reduced_NBMEs_calc (
				    const enum interaction_type inter ,
				    const enum beta_type beta , 
				    const enum beta_pm_type beta_pm ,
				    const bool is_it_Gauss_Legendre ,
				    const bool full_common_vectors_used_in_file ,
				    const class CC_target_projectile_composite_data &Tpc_data , 
				    class array<class nucleons_data> &prot_data_in_one_cluster_less_tab , 
				    class array<class nucleons_data> &neut_data_in_one_cluster_less_tab , 
				    class array<class nucleons_data> &prot_data_out_one_cluster_less_tab , 
				    class array<class nucleons_data> &neut_data_out_one_cluster_less_tab , 
				    const class correlated_state_str &PSI_in_qn ,  
				    const class correlated_state_str &PSI_out_qn ,  
				    class array<TYPE> &target_NBMEs_reduced);

    void beta_suboperators_NBMEs_calc (
				       const enum beta_type beta ,
				       const enum beta_pm_type beta_pm ,
				       const bool is_it_Gauss_Legendre , 
				       const class CC_target_projectile_composite_data &Tpc_data ,
				       const class array<class cluster_data> &cluster_projectile_data_tab , 
				       const bool is_it_nas_only ,
				       const class input_data_str &input_data_CC_Berggren , 
				       const class array<TYPE> &target_reduced_NBMEs ,
				       const class CC_Hamiltonian_data &CC_H_data_in , 
				       const class CC_state_class &CC_state_in , 
				       const class CC_Hamiltonian_data &CC_H_data_out , 
				       const class CC_state_class &CC_state_out ,  
				       class nucleons_data &prot_data_in , 
				       class nucleons_data &neut_data_in , 
				       class nucleons_data &prot_data_out , 
				       class nucleons_data &neut_data_out , 
				       const class correlated_state_str &PSI_in_qn ,  
				       const class correlated_state_str &PSI_out_qn ,    
				       class array<TYPE> &beta_suboperator_NBMEs);
  }
}
#endif


