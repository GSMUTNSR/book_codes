#ifndef CC_SCALAR_STRENGTH_MES_H
#define CC_SCALAR_STRENGTH_MES_H

namespace CC_scalar_strength_MEs
{ 	
  namespace radial_momentum
  {
    void radial_OBMEs_calc (
			    const enum radial_operator_type radial_operator ,
			    const bool is_it_Gauss_Legendre ,  
			    const class CC_state_class &CC_state_in , 
			    const class CC_state_class &CC_state_out , 
			    const unsigned int ic_in , 
			    const unsigned int ic_out , 
			    class array<TYPE> &radial_OBMEs);
    
    void momentum_OBMEs_calc (
			      const bool is_it_Gauss_Legendre , 
			      const class CC_state_class &CC_state_in , 
			      const class CC_state_class &CC_state_out , 
			      const unsigned int ic_in , 
			      const unsigned int ic_out , 
			      class array<TYPE> &momentum_OBMEs);

    complex<double> radial_integral_bef_R_calc (
						const class CC_state_class &CC_state_in , 
						const class CC_state_class &CC_state_out , 
						const unsigned int ic_in , 
						const unsigned int ic_out);

    complex<double> radial_integral_aft_R_part_of_four_calc (
							     const unsigned int asy_in , 
							     const unsigned int asy_out , 
							     const class CC_state_class &CC_state_in , 
							     const class CC_state_class &CC_state_out , 
							     const unsigned int ic_in , 
							     const unsigned int ic_out);
    
    complex<double> radial_integral_aft_R_calc (
						const class CC_state_class &CC_state_in , 
						const class CC_state_class &CC_state_out , 
						const unsigned int ic_in , 
						const unsigned int ic_out);

    complex<double> radial_integral_aft_R_real_calc (
						     const class CC_state_class &CC_state_in , 
						     const class CC_state_class &CC_state_out , 
						     const unsigned int ic_in , 
						     const unsigned int ic_out);

    TYPE radial_integral_calc (
			       const class CC_state_class &CC_state_in , 
			       const class CC_state_class &CC_state_out ,
			       const unsigned int ic_in , 
			       const unsigned int ic_out);
  }

  namespace one_baryon
  {
    //--// calculates <uc_f lf jf || R_rms^2 || uc_i li ji>
    void OBMEs_calc (
		     const bool is_it_Gauss_Legendre , 
		     const double rms_radius_factor ,
		     const class CC_state_class &CC_state_in , 
		     const class CC_state_class &CC_state_out , 
		     const unsigned int ic_in ,
		     const unsigned int ic_out,
		     class array<TYPE> &OBMEs);
  }

  namespace cluster
  {
    //--// calculates <uc_f lf jf || R_rms^2 || uc_i li ji>
    void MEs_calc (
		   const bool is_it_Gauss_Legendre ,  
		   const class CC_target_projectile_composite_data &Tpc_data , 
		   const double rms_radius_CM_factor ,
		   const unsigned int ic , 
		   const unsigned int icp , 
		   const class CC_state_class &CC_state_in , 
		   const class CC_state_class &CC_state_out , 
		   const unsigned int ic_in , 
		   const unsigned int ic_out,
		   class array<TYPE> &MEs);
  }

  namespace composite
  {
    void target_projectile_as_HO_NBMEs_calc (
					     class GSM_vector &PSI_full , 
					     const bool is_it_one_baryon_COSM_case ,
					     const enum operator_type Op ,
					     const enum particle_type particle , 
					     const bool is_it_radial , 
					     const bool is_it_Gauss_Legendre ,
					     const class CC_Hamiltonian_data &CC_H_data , 
					     const class CC_state_class &CC_state_in , 
					     const class CC_state_class &CC_state_out , 
					     const class input_data_str &input_data_CC_Berggren , 
					     class baryons_data &prot_Y_data , 
					     class baryons_data &neut_Y_data ,
					     const class array<class cluster_data> &cluster_projectile_data_tab , 
					     class array<TYPE> &strength_tab);

    void target_nas_NBMEs_calc (
				const bool is_it_radial , 
				const bool is_it_Gauss_Legendre ,
				const class CC_target_projectile_composite_data &Tpc_data , 
				const class CC_state_class &CC_state_in , 
				const class CC_state_class &CC_state_out , 
				const class array<TYPE> &target_NBMEs , 
				class array<TYPE> &strength_tab);

    void projectile_nas_NBMEs_calc (
				    const enum operator_type Op ,
				    const int N_particle ,
				    const bool is_it_radial , 
				    const bool is_it_Gauss_Legendre ,
				    const class input_data_str &input_data_CC_Berggren , 
				    const class CC_target_projectile_composite_data &Tpc_data , 
				    const class CC_state_class &CC_state_in , 
				    const class CC_state_class &CC_state_out , 
				    const class array<class cluster_data> &cluster_projectile_data_tab , 
				    class array<TYPE> &strength_tab);

    void target_NBMEs_calc (
			    class GSM_vector &PSI_full , 
			    const enum interaction_type inter ,
			    const enum operator_type Op ,
			    const enum particle_type particle , 
			    const bool is_it_radial , 
			    const bool is_it_Gauss_Legendre ,
			    const bool full_common_vectors_used_in_file ,
			    const class CC_target_projectile_composite_data &Tpc_data , 
			    class array<class baryons_data> &prot_Y_data_one_cluster_less_tab , 
			    class array<class baryons_data> &neut_Y_data_one_cluster_less_tab , 
			    class array<TYPE> &target_NBMEs);

    void CC_NBMEs_calc (
			class GSM_vector &PSI_full , 
			const enum operator_type Op , 
			const enum particle_type particle , 
			const int N_particle ,
			const bool is_it_radial , 
			const bool is_it_Gauss_Legendre , 
			const class CC_target_projectile_composite_data &Tpc_data , 
			const class array<class cluster_data> &cluster_projectile_data_tab , 
			const bool is_it_nas_only , 
			const class CC_Hamiltonian_data &CC_H_data , 
			const class CC_state_class &CC_state_in , 
			const class CC_state_class &CC_state_out , 
			class baryons_data &prot_Y_data , 
			class baryons_data &neut_Y_data , 
			const class input_data_str &input_data_CC_Berggren , 
			const class array<TYPE> &target_NBMEs , 
			class array<TYPE> &strength_tab); 
  }
}

#endif


