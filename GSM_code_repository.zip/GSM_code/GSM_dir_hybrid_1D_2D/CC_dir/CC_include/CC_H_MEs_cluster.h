#ifndef CC_H_MES_CLUSTER_H
#define CC_H_MES_CLUSTER_H

namespace CC_H_MEs_cluster
{
  double HCM_basis_two_HO_calc (
			  const class array<class CC_channel_class> &channels_tab ,
			  const unsigned int ic ,  
			  const int NCM_HO_c ,  
			  const int NCM_HO_cp , 
			  const class array<class cluster_data> &cluster_projectile_data_tab);
    
  double Ho_two_HO_calc (
			 const class array<class CC_channel_class> &channels_tab , 
			 const unsigned int ic ,  
			 const int NCM_HO_c , 
			 const int NCM_HO_cp , 
			 const class array<class matrix<double> > &PCM_HCM_basis_PCM_HO_submatrices);

  double Berggren_to_HO_two_channels_two_HO_calc (
						  const double CC_average_n_scat_target_projectile_max_c , 
						  const double CC_average_n_scat_target_projectile_max_cp , 
						  const class array<class CC_channel_class> &channels_tab ,  
						  const class array<bool> &is_it_forbidden_channel_tab ,   
						  const unsigned int ic ,  
						  const unsigned int icp ,  
						  const int NCM_HO_c , 
						  const int NCM_HO_cp , 
						  const class array<class cluster_data> &cluster_projectile_data_tab , 
						  const class array<unsigned int> &matrices_indices ,  
						  const class matrix<complex<double> > &Berggren_matrix);
  
  double Im_UCM_core_two_HO_calc (
				  const class array<class CC_channel_class> &channels_tab , 
				  const unsigned int ic , 
				  const int NCM_HO_c , 
				  const int NCM_HO_cp ,
				  const class array<class cluster_data> &cluster_projectile_data_tab);
 
  complex<double> potential_two_channels_two_HO_calc (
						      const double CC_average_n_scat_target_projectile_max_c , 
						      const double CC_average_n_scat_target_projectile_max_cp , 
						      const class array<class CC_channel_class> &channels_tab ,   
						      const class array<bool> &is_it_forbidden_channel_tab , 
						      const unsigned int ic ,  
						      const unsigned int icp ,  
						      const int NCM_HO_c ,  
						      const int NCM_HO_cp , 
						      const class array<class cluster_data> &cluster_projectile_data_tab , 
						      const class array<unsigned int> &matrices_indices ,  
						      const class matrix<complex<double> > &H_matrix , 
						      const class array<class matrix<double> > &PCM_HCM_basis_PCM_HO_submatrices);
 
  double finite_range_overlap_matrix_two_channels_two_HO_calc (
							       const double CC_average_n_scat_target_projectile_max_c , 
							       const double CC_average_n_scat_target_projectile_max_cp , 
							       const class array<class CC_channel_class> &channels_tab , 
							       const class array<bool> &is_it_forbidden_channel_tab , 
							       const unsigned int ic ,  
							       const unsigned int icp ,  
							       const int NCM_HO_c ,  
							       const int NCM_HO_cp , 
							       const class array<class cluster_data> &cluster_projectile_data_tab , 
							       const class array<unsigned int> &matrices_indices ,  
							       const class matrix<complex<double> > &overlaps_matrix);

  complex<double> finite_range_orthogonalized_potential_two_channels_two_CC_Berggren_calc (
											   const class array<class CC_channel_class> &channels_tab , 
											   const unsigned int ic ,  
											   const unsigned int icp ,  
											   const unsigned int NCM_c ,  
											   const unsigned int NCM_cp , 
											   const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
											   const class array<class matrix<complex<double> > > &finite_range_orthogonalized_potential_HO_submatrices);

  complex<double> OCM_potential_part_two_channels_two_CC_Berggren_calc (
									const class array<class CC_channel_class> &channels_tab , 
									const unsigned int ic , 
									const unsigned int NCM_c , 
									const unsigned int NCM_cp ,
									const complex<double> &E_CM_c ,
									const complex<double> &E_CM_cp ,
									const class array<class cluster_data > &cluster_projectile_data_CC_Berggren_tab , 											
									const class array<class matrix<complex<double> > > &QCM_HO_submatrices ,											
									const class array<class matrix<complex<double> > > &QCM_HCM_basis_QCM_HO_submatrices);
}

#endif


