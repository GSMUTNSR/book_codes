#ifndef CC_SPECTROSCOPICFACTORPOLES_H
#define CC_SPECTROSCOPICFACTORPOLES_H

namespace CC_spectroscopic_factor_poles
{
  TYPE calc (
	     const enum spectroscopic_factor_type SF ,
	     const enum nucleus_type nucleus , 
	     const enum particle_type projectile , 
	     const double b_HO , 
	     const int NCM_HO_max_projectile ,
	     const int LCM_projectile ,
	     const class CC_target_projectile_composite_data &Tpc_data , 
	     const bool is_it_nas_only , 
	     const class CC_Hamiltonian_data &CC_H_data , 
	     const class CC_state_class &CC_state , 
	     class nucleons_data &prot_data_out , 
	     class nucleons_data &neut_data_out ,
	     class array<class cluster_data> &cluster_projectile_data_tab , 
	     const class input_data_str &input_data_CC_Berggren , 
	     const class correlated_state_str &PSI_in_qn , 
	     const class correlated_state_str &PSI_out_qn , 
	     const class correlated_state_str &PSI_projectile_qn , 
	     const class array<double> &r_bef_R_tab_GL,
	     const class array<double> &w_bef_R_tab_GL);

  void calc_print (
		   const input_data_str &input_data , 
		   const input_data_str &input_data_CC_Berggren , 
		   const class interaction_class &inter_data_basis , 
		   const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
		   const class HF_nucleons_data &neut_HF_data_CC_Berggren ,
		   class nucleons_data &prot_data_CC_Berggren , 
		   class nucleons_data &neut_data_CC_Berggren , 
		   class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
		   class nucleons_data &prot_data , 
		   class nucleons_data &neut_data , 
		   class array<class cluster_data> &cluster_projectile_data_tab , 
		   class CC_target_projectile_composite_data &Tpc_data , 
		   class TBMEs_class &TBMEs_pn);
}

#endif


