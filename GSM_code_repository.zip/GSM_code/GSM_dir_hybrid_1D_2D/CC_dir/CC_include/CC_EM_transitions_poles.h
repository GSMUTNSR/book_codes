#ifndef CC_EMTRANSITIONSPOLES_H
#define CC_EMTRANSITIONSPOLES_H

namespace CC_EM_transitions_poles
{
  void EM_suboperators_intrinsic_MEs_calc (
					   const TYPE &q,
					   const int L , 
					   const bool is_it_longwavelength_approximation ,
					   const bool is_it_HO_expansion ,
					   const class interaction_class &inter_data_basis ,  
					   class array<class cluster_data> &cluster_projectile_data_tab , 
					   class CC_target_projectile_composite_data &Tpc_data ,
					   class GSM_vector &PSI_full);

  TYPE B_calc (
	       const enum EM_type EM ,
	       const bool is_it_longwavelength_approximation ,
	       const bool is_it_HO_expansion ,
	       const bool is_it_nas_only ,
	       const int L,
	       const class CC_target_projectile_composite_data &Tpc_data , 
	       const class input_data_str &input_data_CC_Berggren , 
	       const class interaction_class &inter_data_basis ,  
	       const class array<class cluster_data> &cluster_projectile_data_tab , 
	       const class CC_Hamiltonian_data &CC_H_data_in , 
	       const class CC_state_class &CC_state_in ,
	       const class CC_Hamiltonian_data &CC_H_data_out ,  
	       const class CC_state_class &CC_state_out , 
	       class nucleons_data &prot_data , 
	       class nucleons_data &neut_data ,
	       class GSM_vector &PSI_full);
  
  void calc_print (
		   const class input_data_str &input_data ,
		   const class input_data_str &input_data_CC_Berggren ,  
		   const class interaction_class &inter_data_basis ,		 
		   const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
		   const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
		   class nucleons_data &prot_data_CC_Berggren , 
		   class nucleons_data &neut_data_CC_Berggren , 
		   class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
		   class nucleons_data &prot_data , 
		   class nucleons_data &neut_data , 
		   class array<class cluster_data> &cluster_projectile_data_tab , 
		   class CC_target_projectile_composite_data &Tpc_data , 
		   class TBMEs_class &TBMEs_pn);
}

#endif


