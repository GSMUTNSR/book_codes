#ifndef FIXED_NUCLEUS_H
#define FIXED_NUCLEUS_H

namespace fixed_nucleus
{
  void E_grad_components_calc (
			       const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
			       const class array<bool> &is_there_l_dependence_from_fit_index , 
			       const class array<int> &l_from_fit_index , 
			       const class input_data_str &input_data , 
			       const class array<class interaction_class> &inter_data_units , 
			       const class array<class correlated_state_str> &PSI_qn_tab , 
			       const double J , 
			       const unsigned int eigenset_index , 
			       const unsigned int eigenset_vectors_number , 
			       class interaction_class &inter_data , 
			       class TBMEs_class &TBMEs_pn , 
			       class TBMEs_class &TBMEs_cv , 
			       class baryons_data &prot_Y_data , 
			       class baryons_data &neut_Y_data , 
			       class GSM_vector &PSI_full ,
			       class array<class GSM_vector> &PSI_M_tab , 
			       class array<class GSM_vector> &GSM_work_vectors ,  
			       class array<class vector_class<TYPE> > &E_grad_all_states);

  void H_J2_find_eigenvector (
			      const class input_data_str &input_data , 
			      const class TBMEs_class &TBMEs_pn ,
			      const class TBMEs_class &TBMEs_cv ,  
			      const unsigned int J_number , 	
			      const class array<unsigned long int> &total_space_dimensions_good_J_pole_approximation , 
			      const class array<unsigned long int> &total_space_dimensions_good_J , 
			      const unsigned int eigenset_index , 
			      const class array<TYPE> &E_subspace_tab , 
			      const class array<class GSM_vector> &eigenvector_subspace_tab ,
			      class baryons_data &prot_Y_data , 
			      class baryons_data &neut_Y_data , 
			      class GSM_vector &V ,
			      class GSM_vector &Vstore , 
			      class GSM_vector &PSI_full ,
			      class array<class GSM_vector> &PSI_M_tab , 
			      class array<class GSM_vector> &PSI_Mp1_tab , 
			      class array<class GSM_vector> &V_tab ,
			      class array<class GSM_vector> &HV_tab , 
			      class array<class GSM_vector> &Vp_tab ,
			      class array<class GSM_vector> &GSM_work_vectors ,  
			      class array<class correlated_state_str> &PSI_qn_tab);

  void space_one_body_basis_data_alloc_calc (
					     const class input_data_str &input_data , 
					     const class interaction_class &inter_data_basis , 
					     class baryons_data &prot_Y_data , 				 
					     class baryons_data &neut_Y_data);

  void E_grad_E_all_states_alloc_calc (
				       const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
				       const class array<bool> &is_there_l_dependence_from_fit_index , 
				       const class array<int> &l_from_fit_index , 
				       const class array<class interaction_class> &inter_data_units , 
				       const class vector_class<double> &FHT_EFT_parameters ,
				       class interaction_class &inter_data_Coulomb ,  
				       class input_data_str &input_data , 
				       class interaction_class &inter_data_basis , 
				       class interaction_class &inter_data ,
				       class GSM_vector &PSI_full , 
				       class array<class correlated_state_str> &PSI_qn_tab , 
				       class array<class vector_class<TYPE> > &E_grad_all_states);

  void E_all_states_calc (
			  class input_data_str &input_data , 
			  class interaction_class &inter_data_basis , 
			  class interaction_class &inter_data , 
			  class GSM_vector &PSI_full ,
			  class array<class correlated_state_str> &PSI_qn_tab);

  void natural_orbitals_OBMEs_basis_store (
					   class input_data_str &input_data , 
					   const class interaction_class &inter_data_basis ,
					   const class interaction_class &inter_data , 
					   class GSM_vector &PSI_full);
}
#endif


