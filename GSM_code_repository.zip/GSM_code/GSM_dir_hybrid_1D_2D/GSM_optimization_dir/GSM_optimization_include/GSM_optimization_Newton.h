#ifndef OPTIMIZATION_NEWTON_H
#define OPTIMIZATION_NEWTON_H

namespace optimization_Newton
{
  void matrix_vector_calc (
			   const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
			   const class array<bool> &is_there_l_dependence_from_fit_index , 
			   const class array<int> &l_from_fit_index , 
			   const class vector_class<double> &FHT_EFT_parameters , 
			   const class array<unsigned int> &state_indices ,
			   const class array<class interaction_class> &inter_data_units ,  
			   class array<class input_data_str> &input_data_tab , 
			   class interaction_class &inter_data_Coulomb , 
			   class interaction_class &inter_data_basis , 
			   class interaction_class &inter_data , 
			   class GSM_vector &PSI_full ,
			   ofstream &fit_results_file , 
			   class vector_class<double> &delta_E_vector , 
			   class matrix<double> &G);

  void calc_print (
		   const class input_data_str &input_data_common ,
		   const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
		   const class array<bool> &is_there_l_dependence_from_fit_index , 
		   const class array<int> &l_from_fit_index , 
		   const class array<class interaction_class> &inter_data_units , 
		   class array<class input_data_str> &input_data_tab , 
		   class interaction_class &inter_data_Coulomb ,  
		   class interaction_class &inter_data_basis , 
		   class interaction_class &inter_data , 
		   class GSM_vector &PSI_full ,
		   class vector_class<double> &FHT_EFT_parameters , 
		   class matrix<double> &G , 
		   ofstream &fit_results_file);
}

#endif

