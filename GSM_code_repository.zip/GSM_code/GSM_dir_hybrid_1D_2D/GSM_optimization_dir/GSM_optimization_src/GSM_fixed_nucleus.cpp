#include "../GSM_optimization_include/GSM_optimization_include_def.h"

using namespace string_routines;
using namespace inputs_misc;
using namespace GSM_vector_dimensions;







// TYPE is double or complex
// ----------------------------


// All routines here deal with a nucleus with fixed number of protons and neutrons.
// One can deal with several eigenstates per nucleus in these routines.




// Calculation of the one-body matrix elements (OBMEs) of the interaction after modification of its parameters
// -----------------------------------------------------------------------------------------------------------

void fixed_nucleus::OBMEs_inter_calc (
				      const class interaction_class &inter_data ,
				      const class nucleons_data &neut_data ,
				      class nucleons_data &data)
{
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  const unsigned int N_nlj = data.get_N_nlj (); 

  class OBMEs_inter_set_str &OBMEs_inter_set = data.get_OBMEs_inter_set ();

  const class array<TYPE> OBMEs_nuclear_old = OBMEs_inter_set(ONE_BODY_NUCLEAR);
  
  class array<TYPE> OBMEs_nuclear_new(N_nlj , N_nlj);
    
  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
      OBMEs_nuclear_new(s_in , s_out) = H_CM_OBMEs::coupled_OBME_inter_calc (ONE_BODY_NUCLEAR , inter_data , 0.0 , s_in , s_out , neut_data , data);
  
  OBMEs_inter_set(ONE_BODY_NUCLEAR) = OBMEs_nuclear_new;

  OBMEs_inter_set(TBME_inter) -= OBMEs_nuclear_old;
  OBMEs_inter_set(TBME_inter) += OBMEs_nuclear_new;
}



// Removal of double-counting in OBMEs issued by the use of holes in the core
// --------------------------------------------------------------------------

void fixed_nucleus::OBMEs_hole_double_counting_calc_remove (
							    const class input_data_str &input_data , 
							    const class TBMEs_class &TBMEs_pn , 
							    const class interaction_class &inter_data ,
							    class nucleons_data &prot_data ,
							    class nucleons_data &neut_data)
{
  const bool is_hole_double_counting_suppressed = input_data.get_is_hole_double_counting_suppressed ();
  
  if (!is_hole_double_counting_suppressed) return;
  
  const enum space_type space = input_data.get_space ();
  
  const int n_scat_max = input_data.get_n_scat_max ();
  
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  const unsigned int Np_nlj = prot_data.get_N_nlj (); 
  const unsigned int Nn_nlj = neut_data.get_N_nlj (); 

  if (space != NEUTRONS_ONLY)
    {
      class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
  
      const class array<TYPE> prot_OBMEs_hole_double_counting_old = prot_OBMEs_inter_set(HOLE_DOUBLE_COUNTING);
  
      class array<TYPE> prot_OBMEs_hole_double_counting_new(Np_nlj , Np_nlj);
  
      for (unsigned int sp_in = 0 ; sp_in < Np_nlj ; sp_in++)
	for (unsigned int sp_out = 0 ; sp_out < Np_nlj ; sp_out++)
	  prot_OBMEs_hole_double_counting_new(sp_in , sp_out) = hole_double_counting::prot_OBME_calc (false , space , n_scat_max , TBMEs_pn , prot_data , neut_data , sp_in , sp_out);
  
      prot_OBMEs_inter_set(HOLE_DOUBLE_COUNTING) = prot_OBMEs_hole_double_counting_new;

      prot_OBMEs_inter_set(TBME_inter) += prot_OBMEs_hole_double_counting_old;  
      prot_OBMEs_inter_set(TBME_inter) -= prot_OBMEs_hole_double_counting_new;
    }
  
  if (space != PROTONS_ONLY)
    {
      class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();

      const class array<TYPE> neut_OBMEs_hole_double_counting_old = neut_OBMEs_inter_set(HOLE_DOUBLE_COUNTING);

      class array<TYPE> neut_OBMEs_hole_double_counting_new(Nn_nlj , Nn_nlj);
    
      for (unsigned int sn_in = 0 ; sn_in < Nn_nlj ; sn_in++)
	for (unsigned int sn_out = 0 ; sn_out < Nn_nlj ; sn_out++)
	  neut_OBMEs_hole_double_counting_new(sn_in , sn_out) = hole_double_counting::neut_OBME_calc (false , space , n_scat_max , TBMEs_pn , prot_data , neut_data , sn_in , sn_out);
  
      neut_OBMEs_inter_set(HOLE_DOUBLE_COUNTING) = neut_OBMEs_hole_double_counting_new;

      neut_OBMEs_inter_set(TBME_inter) += neut_OBMEs_hole_double_counting_old;
      neut_OBMEs_inter_set(TBME_inter) -= neut_OBMEs_hole_double_counting_new;
    }
}






// Calculation of the one-body matrix elements (OBMEs) and two-body matrix elements (TBMEs) of the interaction after modification of its parameters
// ------------------------------------------------------------------------------------------------------------------------------------------------

void fixed_nucleus::OBMEs_TBMEs_calc (
				      const class input_data_str &input_data , 
				      const class array<class interaction_class > &inter_data_units , 
				      const class interaction_class &inter_data_Coulomb , 
				      const class vector_class<double> &FHT_EFT_parameters , 
				      class interaction_class &inter_data , 
				      class TBMEs_class &TBMEs_pn , 
				      class nucleons_data &prot_data , 
				      class nucleons_data &neut_data)
{	
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const enum space_type space = input_data.get_space ();

  const bool are_there_basis_prot_natural_orbitals = prot_data.get_are_there_basis_natural_orbitals ();
  const bool are_there_basis_neut_natural_orbitals = neut_data.get_are_there_basis_natural_orbitals ();
  
  const string prot_debut_file_name = prot_data.get_debut_file_name ();
  const string neut_debut_file_name = neut_data.get_debut_file_name ();
  
  const enum interaction_type inter = input_data.get_inter ();

  const double frozen_core_mass = input_data.get_frozen_core_mass ();
  
  const int Zval = input_data.get_Zval ();
  const int Nval = input_data.get_Nval ();

  const bool print_detailed_information = input_data.get_print_detailed_information ();

  const double TBME_A_dependent_factor = TBME_A_dependent_factor_calc (input_data);
	    
  inter_data.calculate_from_units_Coulomb_kinetic (frozen_core_mass , FHT_EFT_parameters , TBME_A_dependent_factor , inter_data_units , inter_data_Coulomb);

  if (space != NEUTRONS_ONLY)
    {
      OBMEs_inter_calc (inter_data , neut_data , prot_data);

      if (Zval >= 2) coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (print_detailed_information , inter , input_data , true , inter_data , prot_data);
    }

  if (space != PROTONS_ONLY)
    {
      OBMEs_inter_calc (inter_data , neut_data , neut_data);

      if (Nval >= 2) coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (print_detailed_information , inter , input_data , true , inter_data , neut_data);
    }

  if (space == PROTONS_NEUTRONS) coupled_TBMEs::Berggren::TBMEs_pn_calc (print_detailed_information , false , inter , input_data , prot_data , neut_data , true , inter_data , TBMEs_pn);

  OBMEs_hole_double_counting_calc_remove (input_data , TBMEs_pn , inter_data , prot_data , neut_data);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_basis_prot_natural_orbitals)
    {
      const class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
      
      prot_OBMEs_inter_set.copy_disk (TBME_inter , prot_debut_file_name);
    }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_basis_neut_natural_orbitals)
    {
      const class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();
      
      neut_OBMEs_inter_set.copy_disk (TBME_inter , neut_debut_file_name);
    }
}





// Calculation of the gradients of one-body matrix elements (OBMEs) and two-body matrix elements (TBMEs) of the interaction after modification of its parameters with respect to Hamiltonian parameters
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

void fixed_nucleus::OBMEs_TBMEs_grad_calc (
					   const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
					   const class array<bool> &is_there_l_dependence_from_fit_index , 
					   const class array<int> &l_from_fit_index , 
					   const class input_data_str &input_data , 
					   const class array<class interaction_class> &inter_data_units , 
					   const unsigned int fit_index , 
					   class interaction_class &inter_data , 
					   class TBMEs_class &TBMEs_pn , 
					   class nucleons_data &prot_data , 
					   class nucleons_data &neut_data)
{	
  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();

  const bool print_detailed_information = input_data.get_print_detailed_information ();
  
  const enum FHT_EFT_parameter_type FHT_EFT_parameter = FHT_EFT_parameters_from_fit_index(fit_index);

  const bool is_there_l_dependence = is_there_l_dependence_from_fit_index(fit_index);
  
  const int Zval = input_data.get_Zval ();
  const int Nval = input_data.get_Nval ();
  
  const int l = l_from_fit_index(fit_index);

  const bool is_it_prot_grad = is_it_FHT_EFT_one_body_proton_determine  (FHT_EFT_parameter);
  const bool is_it_neut_grad = is_it_FHT_EFT_one_body_neutron_determine (FHT_EFT_parameter);

  const bool is_it_two_body_grad = (!is_it_prot_grad && !is_it_neut_grad);

  const bool is_prot_one_body_non_zero = (is_it_prot_grad && (space != NEUTRONS_ONLY));
  const bool is_neut_one_body_non_zero = (is_it_neut_grad && (space != PROTONS_ONLY));

  const bool is_it_FHT_EFT_parameter_pp_nn = is_it_FHT_EFT_parameter_pp_nn_determine (FHT_EFT_parameter);
  
  const bool is_pp_non_zero = ((Zval >= 2) && is_it_FHT_EFT_parameter_pp_nn);
  const bool is_nn_non_zero = ((Nval >= 2) && is_it_FHT_EFT_parameter_pp_nn);
  
  const bool is_pn_non_zero = ((space == PROTONS_NEUTRONS) && is_it_two_body_grad);

  if (is_prot_one_body_non_zero || is_neut_one_body_non_zero || is_pp_non_zero || is_nn_non_zero || is_pn_non_zero)
    {
      if (is_it_two_body_grad)
	{
	  const double TBME_A_dependent_factor = TBME_A_dependent_factor_calc (input_data);
	  
	  inter_data.calculate_grad_from_units (inter_data_units , TBME_A_dependent_factor , FHT_EFT_parameter);
	}
       
      if (space == PROTONS_NEUTRONS) TBMEs_pn.zero ();

      if (space != NEUTRONS_ONLY)
	{
	  class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();

	  prot_OBMEs_inter_set(inter) = 0.0;

	  class TBMEs_class &TBMEs_prot = prot_data.get_TBMEs ();

	  if (Zval >= 2) TBMEs_prot.zero ();
	  
	  if (is_prot_one_body_non_zero)
	    {
	      const double A_dependent_factor_core_potential = A_dependent_factor_core_potential_calc (PROTON , input_data);
	      
	      OBMEs_TBMEs::Berggren::calc_WS_derivative (FHT_EFT_parameter , is_there_l_dependence , l , A_dependent_factor_core_potential , prot_data);

	      prot_OBMEs_inter_set(inter) = prot_OBMEs_inter_set(WS_DERIVATIVE);
	    }
	  
	  if (is_pp_non_zero) coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (print_detailed_information , inter , input_data , false , inter_data , prot_data);
	}

      if (space != PROTONS_ONLY)
	{
	  class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();

	  neut_OBMEs_inter_set(inter) = 0.0;

	  class TBMEs_class &TBMEs_neut = neut_data.get_TBMEs ();

	  if (Nval >= 2) TBMEs_neut.zero ();
	  
	  if (is_neut_one_body_non_zero)
	    {
	      const double A_dependent_factor_core_potential = A_dependent_factor_core_potential_calc (NEUTRON , input_data);
	      
	      OBMEs_TBMEs::Berggren::calc_WS_derivative (FHT_EFT_parameter , is_there_l_dependence ,  l , A_dependent_factor_core_potential , neut_data);
	      
	      neut_OBMEs_inter_set(inter) = neut_OBMEs_inter_set(WS_DERIVATIVE);
	    }
	  
	  if (is_nn_non_zero) coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (print_detailed_information , inter , input_data , false , inter_data , neut_data);
	}

      if (is_pn_non_zero) coupled_TBMEs::Berggren::TBMEs_pn_calc (print_detailed_information , false , inter , input_data , prot_data , neut_data , false , inter_data , TBMEs_pn);

      hole_double_counting::prot_neut_OBMEs_calc_store_remove (true , input_data , prot_data , neut_data , TBMEs_pn);
    }
}














// Calculation of the gradients of many-body energies with respect to Hamiltonian parameters
// -----------------------------------------------------------------------------------------

void fixed_nucleus::E_grad_components_calc (
					    const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
					    const class array<bool> &is_there_l_dependence_from_fit_index , 
					    const class array<int> &l_from_fit_index , 
					    const class input_data_str &input_data , 
					    const class array<class interaction_class> &inter_data_units , 
					    const class array<class correlated_state_str> &PSI_qn_tab , 
					    const double J , 
					    const unsigned int eigenset_index , 
					    const unsigned int eigenset_vectors_number , 
					    class interaction_class &inter_data , 
					    class TBMEs_class &TBMEs_pn , 
					    class nucleons_data &prot_data , 
					    class nucleons_data &neut_data , 
					    class GSM_vector &PSI_full ,
					    class array<class GSM_vector> &PSI_M_tab , 
					    class array<class GSM_vector> &GSM_work_vectors , 
					    class array<class vector_class<TYPE> > &E_grad_all_states)
{  
  const unsigned int N_parameters_to_fit = FHT_EFT_parameters_from_fit_index.dimension (0);

  const bool print_detailed_information = input_data.get_print_detailed_information ();
    
  const bool full_common_vectors_used_in_file = input_data.get_full_common_vectors_used_in_file ();

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();
  
  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage ();
  
  const enum storage_type one_jumps_pn_storage = input_data.get_one_jumps_pn_storage ();
  
  const int Zval = input_data.get_Zval ();
  const int Nval = input_data.get_Nval ();
  
  class GSM_vector &PSI0_M = PSI_M_tab(0);
  class GSM_vector &PSI1_M = PSI_M_tab(1);

  class GSM_vector_helper_class &GSM_vector_helper_M = PSI0_M.get_GSM_vector_helper ();
    
  class GSM_vector PSI(GSM_vector_helper_M);

  class GSM_vector H_grad_PSI(GSM_vector_helper_M);
 
  class OBMEs_inter_set_str dummy_inter_set;

  class OBMEs_inter_set_str &prot_OBMEs_inter_set = (space != NEUTRONS_ONLY) ? (prot_data.get_OBMEs_inter_set ()) : (dummy_inter_set);
  class OBMEs_inter_set_str &neut_OBMEs_inter_set = (space != PROTONS_ONLY)  ? (neut_data.get_OBMEs_inter_set ()) : (dummy_inter_set);

  const class array<TYPE> dummy_array;

  const class array<TYPE> prot_OBMEs_inter = (space != NEUTRONS_ONLY) ? (prot_OBMEs_inter_set(inter)) : (dummy_array);
  const class array<TYPE> neut_OBMEs_inter = (space != PROTONS_ONLY)  ? (neut_OBMEs_inter_set(inter)) : (dummy_array);
     
  const class array<TYPE> prot_OBMEs_hole_double_counting = (space != NEUTRONS_ONLY) ? (prot_OBMEs_inter_set(HOLE_DOUBLE_COUNTING)) : (dummy_array);
  const class array<TYPE> neut_OBMEs_hole_double_counting = (space != PROTONS_ONLY)  ? (neut_OBMEs_inter_set(HOLE_DOUBLE_COUNTING)) : (dummy_array);
  
  const bool is_it_one_body_only = optimization_data_handling::is_it_one_body_only_determine (FHT_EFT_parameters_from_fit_index);
   
  const class GSM_vector_helper_class dummy_helper;
  
  switch (Hamiltonian_storage)
    {
    case FULL_STORAGE:
      {  
	configuration_SD_in_space_one_jump_in_to_out::configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (print_detailed_information , is_it_one_body_only , false , false , false ,
														   GSM_vector_helper_M , GSM_vector_helper_M , dummy_helper , prot_data , neut_data);
      } break;
      
    case PARTIAL_STORAGE:
      {  
	configuration_SD_in_space_one_jump_in_to_out::configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (print_detailed_information , is_it_one_body_only , false , false , false ,
														   GSM_vector_helper_M , GSM_vector_helper_M , dummy_helper , prot_data , neut_data);
      } break;

    case ON_THE_FLY: break;

    default: abort_all ();
    }
  
  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
    { 
      const enum FHT_EFT_parameter_type FHT_EFT_parameter = FHT_EFT_parameters_from_fit_index(fit_index);

      const bool is_it_prot_grad = is_it_FHT_EFT_one_body_proton_determine  (FHT_EFT_parameter);
      const bool is_it_neut_grad = is_it_FHT_EFT_one_body_neutron_determine (FHT_EFT_parameter);

      const bool is_it_two_body_grad = (!is_it_prot_grad && !is_it_neut_grad);

      const bool is_prot_one_body_non_zero = (is_it_prot_grad && (space != NEUTRONS_ONLY));
      const bool is_neut_one_body_non_zero = (is_it_neut_grad && (space != PROTONS_ONLY));

      const bool is_it_FHT_EFT_parameter_pp_nn = is_it_FHT_EFT_parameter_pp_nn_determine (FHT_EFT_parameter);
  
      const bool is_pp_non_zero = ((Zval >= 2) && is_it_FHT_EFT_parameter_pp_nn);
      const bool is_nn_non_zero = ((Nval >= 2) && is_it_FHT_EFT_parameter_pp_nn);
  
      const bool is_pn_non_zero = ((space == PROTONS_NEUTRONS) && is_it_two_body_grad);

      if (is_prot_one_body_non_zero || is_neut_one_body_non_zero || is_pp_non_zero || is_nn_non_zero || is_pn_non_zero)
	{
	  OBMEs_TBMEs_grad_calc (FHT_EFT_parameters_from_fit_index , is_there_l_dependence_from_fit_index , l_from_fit_index , 
				 input_data , inter_data_units , fit_index , inter_data , TBMEs_pn , prot_data , neut_data);
	  
	  const class H_class H_grad(print_detailed_information , print_detailed_information , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage , false , false , false ,
				     TBMEs_pn , is_prot_one_body_non_zero , is_neut_one_body_non_zero , is_pp_non_zero , is_nn_non_zero , is_pn_non_zero , J , GSM_vector_helper_M , PSI_full , PSI0_M  , PSI1_M , GSM_work_vectors);

  
	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {
	      const class correlated_state_str &PSI_qn = PSI_qn_tab(eigenset_index , i);

	      const double weight = PSI_qn.get_weight ();

	      const bool is_it_optimization_reference_state = PSI_qn.get_is_it_optimization_reference_state ();
      
	      if (!is_it_optimization_reference_state && (weight == 0.0)) continue;

	      PSI.eigenvector_read_disk (full_common_vectors_used_in_file , full_common_vectors_used_in_file , PSI_qn);

	      H_grad_PSI = H_grad*PSI;

	      class vector_class<TYPE> &E_grad = E_grad_all_states(eigenset_index , i);

	      E_grad(fit_index) = PSI*H_grad_PSI;
	    }

	  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl << FHT_EFT_parameter << " gradient component calculated" << endl << endl;
	}
    }

  if (space != NEUTRONS_ONLY) prot_OBMEs_inter_set(inter) = prot_OBMEs_inter , prot_OBMEs_inter_set(HOLE_DOUBLE_COUNTING) = prot_OBMEs_hole_double_counting;
  if (space != PROTONS_ONLY)  neut_OBMEs_inter_set(inter) = neut_OBMEs_inter , neut_OBMEs_inter_set(HOLE_DOUBLE_COUNTING) = neut_OBMEs_hole_double_counting;
  
  prot_data.one_jump_tables_in_to_out_deallocate ();
  neut_data.one_jump_tables_in_to_out_deallocate ();
  
  prot_data.one_jump_tables_out_to_in_deallocate ();
  neut_data.one_jump_tables_out_to_in_deallocate ();
}


















// Calculation of the one-body basis states
// ----------------------------------------

void fixed_nucleus::space_one_body_basis_data_alloc_calc (
							  const class input_data_str &input_data , 
							  const class interaction_class &inter_data_basis , 
							  class nucleons_data &prot_data , 				 
							  class nucleons_data &neut_data)
{
  //  COMMENT: the parameters to be fitted are: V0_ctr_ot , V0_ctr_et , V0_ctr_es , V0_ctr_os , V0_so_ot , V0_so_et , V0_t_ot , V0_t_et for FHT
  //                                            VS_const_LO_T0 , VS_const_LO_T1 , VT_sigma_product_LO_T0 , VT_sigma_product_LO_T1 ,
  //                                            V1_q2_NLO , V2_k2_NLO , V3_q2_sigma_product_NLO , V4_k2_sigma_product_NLO ,
  //                                            V5_k2_sigma_q_vector_k_NLO , V6_sigma_q_product_NLO , V7_sigma_k_product_NLO for EFT

  nucleons_data_initialization (true , input_data , prot_data , neut_data);

  class HF_nucleons_data prot_HF_data(input_data , prot_data);
  class HF_nucleons_data neut_HF_data(input_data , neut_data);
    
  const bool print_detailed_information = input_data.get_print_detailed_information ();
  
  const enum potential_type basis_potential = input_data.get_basis_potential ();
  
  //--// test if the optimized potential with hartree fock must be calculated
  if (basis_potential == MSDHF)
    MSDHF_potentials::potentials_shells_OBMEs_realloc_calc (print_detailed_information , input_data , inter_data_basis , prot_HF_data , neut_HF_data , prot_data , neut_data);
  else
    HF_potentials::potentials_shells_OBMEs_realloc_calc (print_detailed_information , input_data , inter_data_basis , prot_HF_data , neut_HF_data , prot_data , neut_data);
}









// Calculation of the many-body eigenstates by diagonalizing H and using J^2 projection
// ------------------------------------------------------------------------------------

void fixed_nucleus::H_J2_find_eigenvector (
					   const class input_data_str &input_data , 
					   const class TBMEs_class &TBMEs_pn ,
					   const unsigned int J_number , 
					   const class array<unsigned long int> &total_space_dimensions_good_J_pole_approximation , 
					   const class array<unsigned long int> &total_space_dimensions_good_J , 
					   const unsigned int eigenset_index , 
					   const class array<TYPE> &E_subspace_tab , 
					   const class array<class GSM_vector> &eigenvector_subspace_tab ,
					   class nucleons_data &prot_data , 
					   class nucleons_data &neut_data , 
					   class GSM_vector &V ,
					   class GSM_vector &Vstore ,
					   class GSM_vector &PSI_full ,
					   class array<class GSM_vector> &PSI_M_tab , 
					   class array<class GSM_vector> &PSI_Mp1_tab , 
					   class array<class GSM_vector> &V_tab ,
					   class array<class GSM_vector> &HV_tab , 
					   class array<class GSM_vector> &Vp_tab ,
					   class array<class GSM_vector> &GSM_work_vectors ,  
					   class array<class correlated_state_str> &PSI_qn_tab)
{
  const enum space_type space = input_data.get_space ();
  
  const bool print_detailed_information = input_data.get_print_detailed_information ();
  
  const bool all_states_calculated = input_data.get_all_states_calculated ();

  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();
  
  const enum storage_type M_TBMEs_storage = input_data.get_M_TBMEs_storage ();
  
  const enum storage_type one_jumps_pn_storage = input_data.get_one_jumps_pn_storage ();
   
  const int n_scat_max = input_data.get_n_scat_max ();
  
  const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

  const class array<unsigned int> &BP_eigenset_tab = input_data.get_BP_eigenset_tab ();
  
  const class array<double> &J_eigenset_tab = input_data.get_J_eigenset_tab ();

  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

  const unsigned int BP = BP_eigenset_tab(eigenset_index);
  
  const double J = J_eigenset_tab(eigenset_index);
  
  const int two_J = make_int (2.0*J);

  const int J_index = (two_J%2 == 0) ? (make_int (J)) : (make_int (J - 0.5));

  const unsigned long int total_space_dimension_good_J = total_space_dimensions_good_J(BP , n_scat_max , J_index);

  const unsigned int vectors_to_find_number = (all_states_calculated) ? (total_space_dimension_good_J) : (eigenset_vectors_number);
  
  const bool T2_CM_operators_calculated = input_data.get_T2_CM_operators_calculated ();
  
  const bool is_it_on_the_fly = (Hamiltonian_storage == ON_THE_FLY);
  
  const bool is_it_full_or_partial_storage = is_it_full_or_partial_storage_determine (Hamiltonian_storage);
    
  const bool configuration_SD_one_jump_tables_to_calculate_for_operators = (T2_CM_operators_calculated || is_it_on_the_fly);
  
  const bool configuration_SD_one_jump_tables_to_recalculate_for_matrices = is_it_full_or_partial_storage;
      
  const bool configuration_SD_one_jump_pn_tables_to_calculate = (!is_it_full_or_partial_storage && (space == PROTONS_NEUTRONS));

  class GSM_vector &PSI0_M = PSI_M_tab(0);
  class GSM_vector &PSI1_M = PSI_M_tab(1);
  
  class GSM_vector &PSI0_Mp1 = PSI_Mp1_tab(0);
  class GSM_vector &PSI1_Mp1 = PSI_Mp1_tab(1);
  class GSM_vector &PSI2_Mp1 = PSI_Mp1_tab(2);

  class GSM_vector_helper_class &GSM_vector_helper_M = PSI0_M.get_GSM_vector_helper ();

  class GSM_vector_helper_class &GSM_vector_helper_Mp1 = PSI0_Mp1.get_GSM_vector_helper ();
  
  if (configuration_SD_one_jump_pn_tables_to_calculate)
    {
      const class GSM_vector_helper_class dummy_helper;
      
      configuration_SD_in_space_one_jump_out_to_in::configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (print_detailed_information , false , true , false , false ,
														 GSM_vector_helper_M , GSM_vector_helper_M , GSM_vector_helper_Mp1 , prot_data , neut_data);;
    }
  	      
  const class H_class H(print_detailed_information , print_detailed_information , Hamiltonian_storage , M_TBMEs_storage , one_jumps_pn_storage , configuration_SD_one_jump_tables_to_recalculate_for_matrices , true , false , 
			TBMEs_pn , true , true , true , true , true , J , GSM_vector_helper_M , PSI_full , PSI0_M , PSI1_M , GSM_work_vectors);
  
  const class Jpm_class Jplus( print_detailed_information , print_detailed_information ,  1 , Hamiltonian_storage , configuration_SD_one_jump_tables_to_recalculate_for_matrices , GSM_vector_helper_M   , GSM_vector_helper_Mp1 , PSI_full , PSI0_Mp1 , PSI1_Mp1);
  const class Jpm_class Jminus(print_detailed_information , print_detailed_information , -1 , Hamiltonian_storage , configuration_SD_one_jump_tables_to_recalculate_for_matrices , GSM_vector_helper_Mp1 , GSM_vector_helper_M   , PSI_full , PSI0_M   , PSI1_M);
  
  const class J2_class J2(Jplus , Jminus , PSI2_Mp1);
  	      		  
  if (configuration_SD_one_jump_tables_to_calculate_for_operators)
    configuration_SD_in_space_one_jump_out_to_in::configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (print_detailed_information , false , false , true , true , 
													       GSM_vector_helper_M , GSM_vector_helper_M , GSM_vector_helper_Mp1 , prot_data , neut_data);
		
  eigenvector_functions::find_eigenvector (print_detailed_information , input_data , GSM_vector_helper_M , J_number , 
					   total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J , J , H , J2 , 
					   eigenset_index , vectors_to_find_number , E_subspace_tab , eigenvector_subspace_tab ,
					   PSI_full , V , Vstore , PSI_M_tab , PSI_Mp1_tab , V_tab , HV_tab , Vp_tab , GSM_work_vectors , PSI_qn_tab);

  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information)
    cout << "Eigenvectors calculated" << endl;
}





// Calculations of the energies and energy gradients with respect to Hamiltonian parameters of all many-body states
// ----------------------------------------------------------------------------------------------------------------

void fixed_nucleus::E_grad_E_all_states_alloc_calc (
						    const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
						    const class array<bool> &is_there_l_dependence_from_fit_index , 
						    const class array<int> &l_from_fit_index , 
						    const class array<class interaction_class> &inter_data_units ,
						    const class vector_class<double> &FHT_EFT_parameters , 
						    class interaction_class &inter_data_Coulomb ,  
						    class input_data_str &input_data , 
						    class interaction_class &inter_data_basis , 
						    class interaction_class &inter_data , 
						    class GSM_vector &PSI_full ,
						    class array<class correlated_state_str> &PSI_qn_tab , 
						    class array<class vector_class<TYPE> > &E_grad_all_states)
{
  const bool print_detailed_information = input_data.get_print_detailed_information ();
  
  const class array<class array<class JT_coupled_TBME> > dummy_array_JT_coupled_TBME;
    
  inter_data_Coulomb.V_Coulomb_HO_basis_calc (input_data);

  inter_data_basis.V_Coulomb_HO_basis_calc (input_data);

  inter_data.V_Coulomb_HO_basis_calc (input_data);
  
  class nucleons_data prot_data;
  class nucleons_data neut_data;
  
  space_one_body_basis_data_alloc_calc (input_data , inter_data_basis , prot_data , neut_data);
  
  Berggren_basis::single_particle_indices_radial_wfs_prot_neut_alloc_calc (print_detailed_information , input_data , prot_data , neut_data);
 
  space_truncation_data_best_hbar_omega_calc (print_detailed_information , input_data , prot_data , neut_data);
  
  all_HO_GHF_overlaps_prot_neut_alloc_calc (input_data , prot_data , neut_data);
    
  class TBMEs_class TBMEs_pn;
  
  OBMEs_TBMEs::all_OBMEs_TBMEs_alloc_calc (print_detailed_information , false , dummy_array_JT_coupled_TBME , inter_data_basis , inter_data , input_data , prot_data , neut_data , TBMEs_pn);
  
  hole_double_counting::prot_neut_OBMEs_no_natural_orbitals_calc_store_remove (false , input_data , prot_data , neut_data , TBMEs_pn);
     
  hole_double_counting::prot_neut_OBMEs_calc_store (false , input_data , prot_data , neut_data , TBMEs_pn);
  
  configuration_SD_sets::configuration_SD_tables_pp_nn_alloc_calc (print_detailed_information , false , false , input_data , prot_data , neut_data);

  const bool are_natural_orbitals_calculated_every_iteration = input_data.get_are_natural_orbitals_calculated_every_iteration ();
  
  const bool are_GSM_vectors_stored_on_disk = input_data.get_are_GSM_vectors_stored_on_disk ();

  const bool is_it_Lowdin = input_data.get_is_it_Lowdin ();
  
  const unsigned int N_parameters_to_fit = FHT_EFT_parameters_from_fit_index.dimension (0);
  
  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();

  const int n_holes_max_p = prot_data.get_n_holes_max ();
  const int n_holes_max_n = neut_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_data.get_n_scat_max ();
  const int n_scat_max_n = neut_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_data.get_E_max_hw ();
  const int En_max_hw = neut_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();

  const unsigned int eigensets_number = input_data.get_eigensets_number ();
  
  const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

  const class array<unsigned int> &BP_eigenset_tab = input_data.get_BP_eigenset_tab ();

  const class array<double> &J_eigenset_tab = input_data.get_J_eigenset_tab ();
  
  const bool are_there_basis_prot_natural_orbitals = prot_data.get_are_there_basis_natural_orbitals ();
  const bool are_there_basis_neut_natural_orbitals = neut_data.get_are_there_basis_natural_orbitals ();

  const unsigned int J_index_max = J_index_max_calc (space , prot_data , neut_data);

  const unsigned int n_scat_max_plus_one = n_scat_max + 1;

  const unsigned int J_index_max_plus_one = J_index_max + 1;
   
  const string prot_debut_file_name = prot_data.get_debut_file_name ();
  const string neut_debut_file_name = neut_data.get_debut_file_name ();
  
  class array<unsigned long int> total_space_dimensions_good_J_pole_approximation(2 , 1 , J_index_max_plus_one);

  class array<unsigned long int> total_space_dimensions_good_J(2 , n_scat_max_plus_one , J_index_max_plus_one);
  
  class array<double> M_table(eigensets_number);

  if (are_there_basis_prot_natural_orbitals) OBMEs_inter_calc (inter_data , neut_data , prot_data);
  if (are_there_basis_neut_natural_orbitals) OBMEs_inter_calc (inter_data , neut_data , neut_data);
    
  if (are_there_basis_prot_natural_orbitals || are_there_basis_neut_natural_orbitals) OBMEs_hole_double_counting_calc_remove (input_data , TBMEs_pn , inter_data , prot_data , neut_data);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_basis_prot_natural_orbitals)
    {
      const class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
      
      prot_OBMEs_inter_set.copy_disk (inter , prot_debut_file_name);
    }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_basis_neut_natural_orbitals)
    {
      const class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();
      
      neut_OBMEs_inter_set.copy_disk (inter , neut_debut_file_name);
    }
    
  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information)
    {
      const int Z = input_data.get_Z ();
      const int N = input_data.get_N ();
  
      cout << "Z:" << Z << " N:" << N << endl << endl;
    }
  
  all_J_total_space_dimensions_calc_print (print_detailed_information , input_data , prot_data , neut_data , total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J);
  
  M_table_calc (input_data , prot_data , neut_data , BP_eigenset_tab , J_eigenset_tab , M_table);

  const unsigned int eigenset_vectors_number_max = eigenset_vectors_number_tab.max ();

  input_data.PSI_quantum_numbers_tab_partial_fill (total_space_dimensions_good_J_pole_approximation , PSI_qn_tab);

  const unsigned int total_space_dimensions_good_J_pole_approximation_max = total_space_dimensions_good_J_pole_approximation.max ();

  const unsigned int vectors_to_find_number_max = max (eigenset_vectors_number_max , total_space_dimensions_good_J_pole_approximation_max);

  const unsigned long int dimension_good_J_max = total_space_dimensions_good_J.max ();
  
  const unsigned int workspace_max_dimension = input_data.get_workspace_max_dimension ();
  
  const unsigned int workspace_dimension_max = (dimension_good_J_max <= workspace_max_dimension) ? (dimension_good_J_max) : (workspace_max_dimension);
  
  const int J_number_max = J_number_max_calc (space , prot_data , neut_data , n_scat_max , total_space_dimensions_good_J);
      
  const int J_number_max_plus_one = J_number_max + 1;
      
  class array<unsigned int> eigenset_vectors_indices(eigensets_number , vectors_to_find_number_max);

  class array<bool> is_it_new_J_Pi_tab(eigensets_number);

  class array<bool> is_it_new_BP_M_tab(eigensets_number);

  eigensets_vectors_indices_calc (true , prot_data , neut_data , total_space_dimensions_good_J_pole_approximation , input_data , eigenset_vectors_indices);

  eigenvector_functions::changing_eigensets_bool_tables_calc (input_data , M_table , is_it_new_J_Pi_tab , is_it_new_BP_M_tab);

  const unsigned int subspace_max_dimension = total_space_dimensions_good_J_pole_approximation.max ();
      
  class array<TYPE> E_subspace_tab(2 , J_index_max_plus_one , subspace_max_dimension);  

  class array<class GSM_vector_helper_class> GSM_vector_helper_subspace_tab(2 , J_index_max_plus_one);
  
  class array<class GSM_vector> eigenvector_subspace_tab(2 , J_index_max_plus_one , subspace_max_dimension);
  
  E_subspace_tab = 0.0;

  eigenvector_functions::pole_approximation_eigenvectors_calc (print_detailed_information , total_space_dimensions_good_J_pole_approximation , M_table , TBMEs_pn , input_data ,
							       PSI_qn_tab , prot_data , neut_data , E_subspace_tab , GSM_vector_helper_subspace_tab , eigenvector_subspace_tab);
  
  bool OBMEs_TBMEs_to_recalculate = false;

  class array<class GSM_vector> PSI_M_tab(2);

  class array<class GSM_vector> PSI_Mp1_tab(3);

  class array<class GSM_vector>  V_tab(workspace_dimension_max);
  class array<class GSM_vector> HV_tab(workspace_dimension_max);
  
  class array<class GSM_vector> Vp_tab(J_number_max_plus_one);
  
  class array<class GSM_vector> GSM_work_vectors(NUMBER_OF_THREADS);
  
  class GSM_vector_helper_class GSM_vector_helper_M;

  class GSM_vector_helper_class GSM_vector_helper_Mp1;

  class GSM_vector V;
  
  class GSM_vector Vstore;
  
  for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)	
    {
      const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

      const unsigned int BP = BP_eigenset_tab(eigenset_index);

      const double J = J_eigenset_tab(eigenset_index);

      const double M = M_table(eigenset_index);

      const double Mp1 = M + 1.0;

      const unsigned int J_number = J_number_calc (space , prot_data , neut_data , BP , n_scat_max , M , total_space_dimensions_good_J);
      
      if (OBMEs_TBMEs_to_recalculate)
	OBMEs_TBMEs_calc (input_data , inter_data_units , inter_data_Coulomb , FHT_EFT_parameters , inter_data , TBMEs_pn , prot_data , neut_data);

      if (is_it_new_J_Pi_tab(eigenset_index) && is_it_new_BP_M_tab(eigenset_index))
	{
	  V.deallocate ();
		  
	  Vstore.deallocate ();
	  
	  V_tab.deallocate_object_elements ();

	  HV_tab.deallocate_object_elements ();
	      
	  Vp_tab.deallocate_object_elements ();
		  
	  GSM_work_vectors.deallocate_object_elements ();

	  PSI_M_tab.deallocate_object_elements ();

	  PSI_Mp1_tab.deallocate_object_elements ();
	  
	  GSM_vector_helper_M.deallocate ();

	  GSM_vector_helper_Mp1.deallocate ();
  
	  GSM_vector_helper_M.allocate (is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
					n_holes_max   , n_scat_max   , E_max_hw  ,
					n_holes_max_p , n_scat_max_p , Ep_max_hw ,
					n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , true , prot_data , neut_data);
	  
	  GSM_vector_helper_Mp1.allocate (is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
					  n_holes_max   , n_scat_max   , E_max_hw  ,
					  n_holes_max_p , n_scat_max_p , Ep_max_hw ,
					  n_holes_max_n , n_scat_max_n , En_max_hw , BP , Mp1 , true , prot_data , neut_data);

	  V.allocate (GSM_vector_helper_M);
	  
	  Vstore.allocate (GSM_vector_helper_M);
	  
	  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) GSM_work_vectors(i).allocate (GSM_vector_helper_M);
	  
	  if (!is_it_Lowdin && !are_GSM_vectors_stored_on_disk)
	    {
	      for (unsigned int i = 0 ; i < J_number ; i++) Vp_tab(i).allocate (GSM_vector_helper_M);
	    }
		  
	  for (unsigned int i = 0 ; i < 2 ; i++) PSI_M_tab(i).allocate (GSM_vector_helper_M);
	  for (unsigned int i = 0 ; i < 3 ; i++) PSI_Mp1_tab(i).allocate (GSM_vector_helper_Mp1);
	}
      
      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	{
	  const unsigned int eigenvector_index = eigenset_vectors_indices(eigenset_index , i);

	  class correlated_state_str &PSI_qn = PSI_qn_tab(eigenset_index , i);

	  PSI_qn.initialize (
			     PSI_qn.get_Z () ,
			     PSI_qn.get_N () ,
			     PSI_qn.get_BP () ,
			     PSI_qn.get_J () ,
			     eigenvector_index ,
			     PSI_qn.get_E () ,
			     PSI_qn.get_weight () ,
			     PSI_qn.get_experimental_energy () ,
			     PSI_qn.get_energy_error () ,
			     PSI_qn.get_is_it_optimization_reference_state ());
	}
  
      H_J2_find_eigenvector (input_data , TBMEs_pn , J_number , total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J ,
			     eigenset_index , E_subspace_tab , eigenvector_subspace_tab , prot_data , neut_data , V , Vstore , PSI_full , PSI_M_tab , PSI_Mp1_tab , V_tab , HV_tab , Vp_tab , GSM_work_vectors , PSI_qn_tab);

      const bool is_there_reference_state_fixed_eigenset = optimization_data_handling::is_there_reference_state_fixed_eigenset_determine (input_data , eigenset_index);
      
      const bool are_all_weights_zero_fixed_eigenset = optimization_data_handling::are_all_weights_zero_fixed_eigenset_determine (input_data , eigenset_index);
      
      if (!are_all_weights_zero_fixed_eigenset || is_there_reference_state_fixed_eigenset)
	{
	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {
	      class vector_class<TYPE> &E_grad = E_grad_all_states(eigenset_index , i);
	      
	      if (!E_grad.is_it_filled ()) E_grad.allocate (N_parameters_to_fit);
	      
	      E_grad = 0.0;
	    }
	  
	  E_grad_components_calc (FHT_EFT_parameters_from_fit_index , is_there_l_dependence_from_fit_index , l_from_fit_index , input_data , inter_data_units ,
				  PSI_qn_tab , J , eigenset_index , eigenset_vectors_number , inter_data ,
				  TBMEs_pn , prot_data , neut_data , PSI_full , PSI_M_tab , GSM_work_vectors , E_grad_all_states);
	}
      
      OBMEs_TBMEs_to_recalculate = true;	
    }

  V.deallocate ();
  
  Vstore.deallocate ();
	  
  V_tab.deallocate ();
  
  HV_tab.deallocate ();
	      
  Vp_tab.deallocate ();
  
  GSM_work_vectors.deallocate ();

  PSI_M_tab.deallocate ();

  PSI_Mp1_tab.deallocate ();
	  
  GSM_vector_helper_M.deallocate ();

  GSM_vector_helper_Mp1.deallocate ();
	  
  prot_data.one_jump_tables_Jpm_in_to_out_deallocate ();
  neut_data.one_jump_tables_Jpm_in_to_out_deallocate ();
       
  prot_data.one_jump_tables_in_to_out_deallocate ();
  neut_data.one_jump_tables_in_to_out_deallocate ();
      
  prot_data.one_jump_tables_Jpm_out_to_in_deallocate ();
  neut_data.one_jump_tables_Jpm_out_to_in_deallocate ();
       
  prot_data.one_jump_tables_out_to_in_deallocate ();
  neut_data.one_jump_tables_out_to_in_deallocate ();
  
  // Necessary for natural orbitals
  for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)	
    {
      const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);
      
      const unsigned int BP = BP_eigenset_tab(eigenset_index);
  
      const double M = M_table(eigenset_index);
  
      class GSM_vector_helper_class GSM_vector_helper_M(is_it_MPI_parallelized , space , inter , false , truncation_hw , truncation_ph ,
							n_holes_max   , n_scat_max   , E_max_hw  ,
							n_holes_max_p , n_scat_max_p , Ep_max_hw ,
							n_holes_max_n , n_scat_max_n , En_max_hw , BP , M , true , prot_data , neut_data);
      
      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	{
	  const class correlated_state_str &PSI_qn = PSI_qn_tab(eigenset_index , i);
	  
	  eigenvector_functions::eigenvector_stored_with_all_M_projections (false , print_detailed_information , input_data , total_space_dimensions_good_J , PSI_qn , GSM_vector_helper_M , PSI_full);
	}
    }
	  
#ifdef UseMPI
  
  for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)	
    {
      const bool is_there_reference_state_fixed_eigenset = optimization_data_handling::is_there_reference_state_fixed_eigenset_determine (input_data , eigenset_index);
      
      const bool are_all_weights_zero_fixed_eigenset = optimization_data_handling::are_all_weights_zero_fixed_eigenset_determine (input_data , eigenset_index);
      
      const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	{
	  class correlated_state_str &PSI_qn = PSI_qn_tab(eigenset_index , i);
	  
#ifdef TYPEisDOUBLECOMPLEX
	  TYPE E = PSI_qn.get_E ();
#endif
      
#ifdef TYPEisDOUBLE
	  TYPE E = real (PSI_qn.get_E ());
#endif
	  

	  MPI_helper::Bcast<TYPE> (E , MASTER_PROCESS , MPI_COMM_WORLD);

	  PSI_qn.initialize (
			     PSI_qn.get_Z () ,
			     PSI_qn.get_N () ,
			     PSI_qn.get_BP () ,
			     PSI_qn.get_J () ,
			     PSI_qn.get_vector_index () ,
			     E ,
			     PSI_qn.get_weight () ,
			     PSI_qn.get_experimental_energy () ,
			     PSI_qn.get_energy_error () ,
			     PSI_qn.get_is_it_optimization_reference_state ());
      
	  if (!are_all_weights_zero_fixed_eigenset || is_there_reference_state_fixed_eigenset)
	    {
	      class vector_class<TYPE> &E_grad = E_grad_all_states(eigenset_index , i);
	      
	      E_grad.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
	    }
	}
    }
  
#endif

  if (are_natural_orbitals_calculated_every_iteration)
    {
      const bool are_there_new_prot_natural_orbitals = input_data.get_are_there_new_prot_natural_orbitals ();
      const bool are_there_new_neut_natural_orbitals = input_data.get_are_there_new_neut_natural_orbitals ();

      if (are_there_new_prot_natural_orbitals || are_there_new_neut_natural_orbitals)
	{
	  natural_orbitals_ESPEs::calc_print (print_detailed_information , false , input_data , TBMEs_pn , prot_data , neut_data ,  PSI_full);

	  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_new_prot_natural_orbitals) prot_data.natural_orbitals_OBMEs_basis_store (inter_data);
	  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_new_neut_natural_orbitals) neut_data.natural_orbitals_OBMEs_basis_store (inter_data);
	}
    }
}











// Calculations of the energies of all many-body states
// ----------------------------------------------------

void fixed_nucleus::E_all_states_calc (
				       class input_data_str &input_data , 
				       class interaction_class &inter_data_basis , 
				       class interaction_class &inter_data , 
				       class GSM_vector &PSI_full ,
				       class array<class correlated_state_str> &PSI_qn_tab)
{	
  const bool print_detailed_information = input_data.get_print_detailed_information ();
  
  const class array<class array<class JT_coupled_TBME> > dummy_array_JT_coupled_TBME;
  
  inter_data_basis.V_Coulomb_HO_basis_calc (input_data);

  inter_data.V_Coulomb_HO_basis_calc (input_data);
  
  class nucleons_data prot_data;
  class nucleons_data neut_data;
  
  space_one_body_basis_data_alloc_calc (input_data , inter_data_basis , prot_data , neut_data);

  Berggren_basis::single_particle_indices_radial_wfs_prot_neut_alloc_calc (print_detailed_information , input_data , prot_data , neut_data);
  
  space_truncation_data_best_hbar_omega_calc (print_detailed_information , input_data , prot_data , neut_data);

  all_HO_GHF_overlaps_prot_neut_alloc_calc (input_data , prot_data , neut_data);
    
  class TBMEs_class TBMEs_pn;
  
  OBMEs_TBMEs::all_OBMEs_TBMEs_alloc_calc (print_detailed_information , false , dummy_array_JT_coupled_TBME , inter_data_basis , inter_data , input_data , prot_data , neut_data , TBMEs_pn);
      
  hole_double_counting::prot_neut_OBMEs_no_natural_orbitals_calc_store_remove (false , input_data , prot_data , neut_data , TBMEs_pn);
  
  hole_double_counting::prot_neut_OBMEs_calc_store (false , input_data , prot_data , neut_data , TBMEs_pn);
  
  configuration_SD_sets::configuration_SD_tables_pp_nn_alloc_calc (print_detailed_information , false , false , input_data , prot_data , neut_data);

  const bool are_natural_orbitals_calculated_every_iteration = input_data.get_are_natural_orbitals_calculated_every_iteration ();

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const int n_scat_max = input_data.get_n_scat_max ();
  
  const unsigned int eigensets_number = input_data.get_eigensets_number ();
   
  const bool are_there_basis_prot_natural_orbitals = prot_data.get_are_there_basis_natural_orbitals ();
  const bool are_there_basis_neut_natural_orbitals = neut_data.get_are_there_basis_natural_orbitals ();

  const unsigned int J_index_max = J_index_max_calc (space , prot_data , neut_data);

  const unsigned int n_scat_max_plus_one = n_scat_max + 1;
  
  const unsigned int J_index_max_plus_one = J_index_max + 1;
  
  const string prot_debut_file_name = prot_data.get_debut_file_name ();
  const string neut_debut_file_name = neut_data.get_debut_file_name ();
  
  class array<unsigned long int> total_space_dimensions_good_J_pole_approximation(2 , 1 , J_index_max_plus_one);

  class array<unsigned long int> total_space_dimensions_good_J(2 , n_scat_max_plus_one , J_index_max_plus_one);
  
  class array<double> M_table(eigensets_number);

  if (are_there_basis_prot_natural_orbitals) OBMEs_inter_calc (inter_data , neut_data , prot_data);
  if (are_there_basis_neut_natural_orbitals) OBMEs_inter_calc (inter_data , neut_data , neut_data);

  if (are_there_basis_prot_natural_orbitals || are_there_basis_neut_natural_orbitals) OBMEs_hole_double_counting_calc_remove (input_data , TBMEs_pn , inter_data , prot_data , neut_data);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_basis_prot_natural_orbitals)
    {
      const class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
      
      prot_OBMEs_inter_set.copy_disk (inter , prot_debut_file_name);
    }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_basis_neut_natural_orbitals)
    {
      const class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();
      
      neut_OBMEs_inter_set.copy_disk (inter , neut_debut_file_name);
    }
        
  const int Z = input_data.get_Z ();
  const int N = input_data.get_N ();
                 
  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information)
    {  
      cout << endl << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;
      cout << "Z:" << Z << " N:" << N << endl;
      cout << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl << endl;
    }
  
  all_J_total_space_dimensions_calc_print (print_detailed_information , input_data , prot_data , neut_data , total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J);
  
  input_data.PSI_quantum_numbers_tab_partial_fill (total_space_dimensions_good_J , PSI_qn_tab);
  
  eigenvector_functions::eigenvectors_pole_approximation_full_space_calc (print_detailed_information , false , input_data , total_space_dimensions_good_J_pole_approximation , 
									  total_space_dimensions_good_J , TBMEs_pn , prot_data , neut_data , PSI_qn_tab , PSI_full);

  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information)
    {
      cout << endl << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;
      cout << "Data for " << "Z:" << Z << " N:" << N << " calculated" << endl;
      cout << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl << endl;
    }
  
#ifdef UseMPI
  
  const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

  for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)	
    {
      const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	{
	  class correlated_state_str &PSI_qn = PSI_qn_tab(eigenset_index , i);

#ifdef TYPEisDOUBLECOMPLEX
	  TYPE E = PSI_qn.get_E ();
#endif
      
#ifdef TYPEisDOUBLE
	  TYPE E = real (PSI_qn.get_E ());
#endif
	  
	  MPI_helper::Bcast<TYPE> (E , MASTER_PROCESS , MPI_COMM_WORLD);

	  PSI_qn.initialize (PSI_qn.get_Z () ,
			     PSI_qn.get_N () ,
			     PSI_qn.get_BP () ,
			     PSI_qn.get_J () ,
			     PSI_qn.get_vector_index () ,
			     E ,
			     PSI_qn.get_weight () ,
			     PSI_qn.get_experimental_energy () ,
			     PSI_qn.get_energy_error () ,
			     PSI_qn.get_is_it_optimization_reference_state ());
	}
    }
  
#endif

  if (are_natural_orbitals_calculated_every_iteration)
    {
      const bool are_there_new_prot_natural_orbitals = input_data.get_are_there_new_prot_natural_orbitals ();
      const bool are_there_new_neut_natural_orbitals = input_data.get_are_there_new_neut_natural_orbitals ();

      if (are_there_new_prot_natural_orbitals || are_there_new_neut_natural_orbitals)
	{
	  natural_orbitals_ESPEs::calc_print (print_detailed_information , false , input_data , TBMEs_pn , prot_data , neut_data , PSI_full);

	  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_new_prot_natural_orbitals) prot_data.natural_orbitals_OBMEs_basis_store (inter_data);
	  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_new_neut_natural_orbitals) neut_data.natural_orbitals_OBMEs_basis_store (inter_data);
	}
    }
}









// Calculations of the natural orbitals associated to many-body states and of the OBMEs between natural orbitals
// -------------------------------------------------------------------------------------------------------------

void fixed_nucleus::natural_orbitals_OBMEs_basis_store (
							class input_data_str &input_data , 
							const class interaction_class &inter_data_basis ,
							const class interaction_class &inter_data ,
							class GSM_vector &PSI_full)
{	
  const bool print_detailed_information = input_data.get_print_detailed_information ();
    
  const class array<class array<class JT_coupled_TBME> > dummy_array_JT_coupled_TBME;

  const bool are_there_new_prot_natural_orbitals = input_data.get_are_there_new_prot_natural_orbitals ();
  const bool are_there_new_neut_natural_orbitals = input_data.get_are_there_new_neut_natural_orbitals ();

  const class array<unsigned int> eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

  class nucleons_data prot_data;
  class nucleons_data neut_data;
  
  class TBMEs_class TBMEs_pn;

  space_one_body_basis_data_alloc_calc (input_data , inter_data_basis , prot_data , neut_data);

  Berggren_basis::single_particle_indices_radial_wfs_prot_neut_alloc_calc (print_detailed_information , input_data , prot_data , neut_data);
  
  space_truncation_data_best_hbar_omega_calc (print_detailed_information , input_data , prot_data , neut_data);

  all_HO_GHF_overlaps_prot_neut_alloc_calc (input_data , prot_data , neut_data);
  
  OBMEs_TBMEs::all_OBMEs_TBMEs_alloc_calc (print_detailed_information , false , dummy_array_JT_coupled_TBME , inter_data_basis , inter_data , input_data , prot_data , neut_data , TBMEs_pn);
      
  hole_double_counting::prot_neut_OBMEs_no_natural_orbitals_calc_store_remove (false , input_data , prot_data , neut_data , TBMEs_pn);
    
  hole_double_counting::prot_neut_OBMEs_calc_store (false , input_data , prot_data , neut_data , TBMEs_pn);
  
  configuration_SD_sets::configuration_SD_tables_pp_nn_alloc_calc (print_detailed_information , false , false , input_data , prot_data , neut_data);

  natural_orbitals_ESPEs::calc_print (print_detailed_information , false , input_data , TBMEs_pn , prot_data , neut_data , PSI_full);

  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_new_prot_natural_orbitals) prot_data.natural_orbitals_OBMEs_basis_store (inter_data);
  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_new_neut_natural_orbitals) neut_data.natural_orbitals_OBMEs_basis_store (inter_data);
}



