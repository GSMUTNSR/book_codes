#include "../GSM_optimization_include/GSM_optimization_include_def.h"

using namespace string_routines;
using namespace optimization_data_handling;
using namespace inputs_misc;





// TYPE is double or complex
// ----------------------------


// Jacobian matrix times vector
// ----------------------------

void optimization_Newton::matrix_vector_calc (
					      const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
					      const class array<bool> &is_there_l_dependence_from_fit_index , 
					      const class array<int> &l_from_fit_index , 
					      const class vector_class<double> &FHT_EFT_parameters , 
					      const class array<unsigned int> &state_indices ,
					      const class array<class interaction_class> &inter_data_units ,  
					      class array<class input_data_str> &input_data_tab , 
					      class interaction_class &inter_data_Coulomb , 
					      class interaction_class &inter_data_basis , 
					      class interaction_class &inter_data , 
					      class GSM_vector &PSI_full ,
					      ofstream &fit_results_file , 
					      class vector_class<double> &delta_E_vector , 
					      class matrix<double> &G)
{
  const class input_data_str &input_data_zero = input_data_tab(0);

  const unsigned int N_nuclei_to_consider = input_data_zero.get_N_nuclei_to_consider ();

  const unsigned int eigensets_number_max = optimization_data_handling::eigensets_number_max_determine (input_data_tab);

  const unsigned int eigenset_vectors_number_max = optimization_data_handling::eigenset_vectors_number_max_determine (input_data_tab);

  class array<class correlated_state_str> PSI_qn_tab(N_nuclei_to_consider , eigensets_number_max , eigenset_vectors_number_max);

  class array<class vector_class<TYPE> > E_grad_all_states(N_nuclei_to_consider , eigensets_number_max , eigenset_vectors_number_max);

  energies_gradients_Hessian_natural_orbitals_all_nuclei::PSI_qn_tab_E_grad_all_states_calc (FHT_EFT_parameters_from_fit_index , is_there_l_dependence_from_fit_index , 
											     l_from_fit_index , FHT_EFT_parameters , input_data_tab , inter_data_units , inter_data_Coulomb , inter_data_basis , inter_data , 
											     PSI_full , fit_results_file , PSI_qn_tab , E_grad_all_states);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      fit_results_file << endl;
      cout << endl;
    }

  matrix_vector_calc_from_energies_gradients (input_data_tab , state_indices , PSI_qn_tab , E_grad_all_states , fit_results_file , delta_E_vector , G);
}







// Gauss-Newton optimization of the Hamiltonian parameters with parameters printed
// -------------------------------------------------------------------------------

void optimization_Newton::calc_print (
				      const class input_data_str &input_data_common ,
				      const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
				      const class array<bool> &is_there_l_dependence_from_fit_index , 
				      const class array<int> &l_from_fit_index , 
				      const class array<class interaction_class> &inter_data_units , 
				      class array<class input_data_str> &input_data_tab , 
				      class interaction_class &inter_data_Coulomb ,  
				      class interaction_class &inter_data_basis , 
				      class interaction_class &inter_data , 
				      class GSM_vector &PSI_full ,
				      class vector_class<double> &FHT_EFT_parameters , 
				      class matrix<double> &G , 
				      ofstream &fit_results_file)	
{
  const unsigned int N_nuclei_to_consider = input_data_tab.dimension (0);
  
  const unsigned int N_states_to_fit = optimization_data_handling::N_states_to_fit_calc (input_data_tab);

  const bool is_it_fixed_relative_SVD_precision = input_data_common.get_is_it_fixed_relative_SVD_precision ();

  const double relative_SVD_precision = input_data_common.get_relative_SVD_precision ();

  const unsigned int rejected_singular_values_number = input_data_common.get_rejected_singular_values_number ();

  const double Newton_precision = input_data_common.get_Newton_precision ();
    
  const int lmax_p_all_inputs = lmax_p_all_determine (input_data_tab);
  const int lmax_n_all_inputs = lmax_n_all_determine (input_data_tab);
  
  const int lmax_all_inputs = max (lmax_p_all_inputs , lmax_n_all_inputs);

  const unsigned int N_parameters = FHT_EFT_parameters.get_dimension (); 

  const unsigned int eigensets_number_max = optimization_data_handling::eigensets_number_max_determine (input_data_tab);

  const unsigned int eigenset_vectors_number_max = optimization_data_handling::eigenset_vectors_number_max_determine (input_data_tab);

  class array<unsigned int> state_indices(N_nuclei_to_consider , eigensets_number_max , eigenset_vectors_number_max);

  optimization_data_handling::state_indices_calc (input_data_tab , state_indices);

  unsigned int iter = 0;

  double test = Newton_precision + 1.0;

  class vector_class<double> delta_E_vector(N_states_to_fit);

  G = 0.0;
  
  while ((test > Newton_precision) && (iter++ < 20))
    {
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  fit_results_file << endl << "------------------------------" << endl;
	  fit_results_file << "Newton iteration : " << iter << endl;
	  fit_results_file << "------------------------------" << endl << endl;

	  cout << endl << "------------------------------" << endl;
	  cout << "Newton iteration : " << iter << endl;
	  cout << "------------------------------" << endl << endl;
	}

      const class vector_class<double> FHT_EFT_parameters_fit_indices = FHT_EFT_parameters_fit_indices_fill (lmax_all_inputs , FHT_EFT_parameters_from_fit_index ,
													     is_there_l_dependence_from_fit_index , l_from_fit_index , FHT_EFT_parameters);

      optimization_data_handling::FHT_EFT_parameters_information_print (is_it_fixed_relative_SVD_precision , relative_SVD_precision , rejected_singular_values_number ,
									N_states_to_fit , FHT_EFT_parameters_from_fit_index ,
									is_there_l_dependence_from_fit_index , l_from_fit_index , G , fit_results_file);

      optimization_data_handling::print_all_parameters (input_data_common , FHT_EFT_parameters , fit_results_file);

      matrix_vector_calc (FHT_EFT_parameters_from_fit_index , is_there_l_dependence_from_fit_index , l_from_fit_index , 
			  FHT_EFT_parameters , state_indices ,  inter_data_units , input_data_tab ,inter_data_Coulomb , inter_data_basis , inter_data , PSI_full , fit_results_file , delta_E_vector , G);

      const class vector_class<double> delta_FHT_EFT_parameters_fit_indices_scaled = delta_FHT_EFT_parameters_fit_indices_scaled_calc (is_it_fixed_relative_SVD_precision , relative_SVD_precision ,
																       rejected_singular_values_number , FHT_EFT_parameters_fit_indices , delta_E_vector , G);

      const class vector_class<double> delta_FHT_EFT_parameters_scaled = delta_FHT_EFT_parameters_original_indices_fill (N_parameters , lmax_all_inputs , FHT_EFT_parameters_from_fit_index , 
															 is_there_l_dependence_from_fit_index , l_from_fit_index , delta_FHT_EFT_parameters_fit_indices_scaled);

      const class vector_class<double> delta_FHT_EFT_parameters_fit_indices = delta_FHT_EFT_parameters_fit_indices_unscale (FHT_EFT_parameters_fit_indices , delta_FHT_EFT_parameters_fit_indices_scaled);

      const class vector_class<double> delta_FHT_EFT_parameters = delta_FHT_EFT_parameters_original_indices_fill (N_parameters , lmax_all_inputs , FHT_EFT_parameters_from_fit_index , 
														  is_there_l_dependence_from_fit_index , l_from_fit_index , delta_FHT_EFT_parameters_fit_indices);

      FHT_EFT_parameters -= delta_FHT_EFT_parameters;

      test = min (delta_E_vector.infinite_norm () , delta_FHT_EFT_parameters_scaled.infinite_norm ());

      if (THIS_PROCESS == MASTER_PROCESS)	
	{
	  fit_results_file << endl;

	  cout << endl;

	  deltas_print (FHT_EFT_parameters_from_fit_index , is_there_l_dependence_from_fit_index , l_from_fit_index , delta_FHT_EFT_parameters_fit_indices , fit_results_file);

	  delta_E_vector_deltas_norm_precision_print (delta_E_vector , delta_FHT_EFT_parameters , delta_FHT_EFT_parameters_scaled , fit_results_file);
	}
    }
}











