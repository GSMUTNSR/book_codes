#include "../GSM_optimization_include/GSM_optimization_include_def.h"



using namespace string_routines;
using namespace inputs_misc;






// TYPE is double or complex
// ----------------------------


// Calculations of the energies of all many-body states
// -----------------------------------------------------

void energies_gradients_Hessian_natural_orbitals_all_nuclei::PSI_qn_tab_E_all_states_calc ( 
											   const class vector_class<double> &FHT_EFT_parameters , 
											   const class array<class input_data_str> &input_data_tab , 
											   const class array<class interaction_class> &inter_data_units , 
											   class interaction_class &inter_data_Coulomb , 
											   class interaction_class &inter_data_basis , 
											   class interaction_class &inter_data ,
											   class GSM_vector &PSI_full , 
											   ofstream &fit_results_file , 
											   class array<class correlated_state_str> &PSI_qn_tab)
{
  const class input_data_str &input_data_zero = input_data_tab(0);
  
  const unsigned int N_nuclei_to_consider = input_data_zero.get_N_nuclei_to_consider ();

  const double frozen_core_mass = input_data_zero.get_frozen_core_mass ();
  
  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {    
      class input_data_str &input_data = input_data_tab(nucleus_index);

      input_data.set_FHT_EFT_parameters (false , input_data_tab , FHT_EFT_parameters);
      
      const double TBME_A_dependent_factor = TBME_A_dependent_factor_calc (input_data);
	    
      inter_data.calculate_from_units_Coulomb_kinetic (frozen_core_mass , FHT_EFT_parameters , TBME_A_dependent_factor , inter_data_units , inter_data_Coulomb);

      const unsigned int eigensets_number = input_data.get_eigensets_number ();

      const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

      const unsigned int eigenset_vectors_number_max = eigenset_vectors_number_tab.max ();

      class array<class correlated_state_str> &PSI_qn_from_file_fixed_nucleus_tab = input_data.get_PSI_qn_from_file_tab ();
      
      class array<class correlated_state_str> PSI_qn_fixed_nucleus_tab(eigensets_number , eigenset_vectors_number_max);

      fixed_nucleus::E_all_states_calc (input_data , inter_data_basis , inter_data , PSI_full , PSI_qn_fixed_nucleus_tab);

      const bool only_dimensions = input_data.get_only_dimensions ();
    
      const bool non_zero_NBMEs_proportion_only = input_data.get_non_zero_NBMEs_proportion_only ();

      if (only_dimensions || non_zero_NBMEs_proportion_only) continue;
      
      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {	
	      const class correlated_state_str &PSI_qn_fixed_nucleus = PSI_qn_fixed_nucleus_tab(eigenset_index , i);
	      	      
	      PSI_qn_from_file_fixed_nucleus_tab(eigenset_index , i) = PSI_qn_fixed_nucleus;
	      
	      PSI_qn_tab(nucleus_index , eigenset_index , i) = PSI_qn_fixed_nucleus;
	    }
	}
    }
  
  const TYPE E_reference_state = optimization_data_handling::reference_state_energy_determine (input_data_tab , PSI_qn_tab);
  
  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {    
      const class input_data_str &input_data = input_data_tab(nucleus_index);

      const int Z = input_data.get_Z ();
      const int N = input_data.get_N ();
      
      const unsigned int eigensets_number = input_data.get_eigensets_number ();

      const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();
      
      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {	
	      class correlated_state_str &PSI_qn = PSI_qn_tab(nucleus_index , eigenset_index , i);

	      const unsigned int BP = PSI_qn.get_BP ();
	      
	      const double J = PSI_qn.get_J ();
	      
	      const complex<double> E_init = PSI_qn.get_E ();
	      
	      const complex<double> E_complex = E_init - E_reference_state;
	      
	      const TYPE E = generate_scalar<TYPE> (real (E_complex) , imag (E_complex));
	      	      
	      PSI_qn.initialize (
				 PSI_qn.get_Z () ,
				 PSI_qn.get_N () ,
				 BP ,
				 J ,
				 PSI_qn.get_vector_index () ,
				 E ,
				 PSI_qn.get_weight () ,
				 PSI_qn.get_experimental_energy () ,
				 PSI_qn.get_energy_error () ,
				 PSI_qn.get_is_it_optimization_reference_state ());
	      
	      if (THIS_PROCESS == MASTER_PROCESS)
		{
		  
#ifdef TYPEisDOUBLECOMPLEX
		  fit_results_file << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " calculated. E=" << real (E) << " MeV Gamma=" << -2000.0*imag (E) << " keV" << endl;
		  cout             << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " calculated. E=" << real (E) << " MeV Gamma=" << -2000.0*imag (E) << " keV" << endl;
#endif
		  
#ifdef TYPEisDOUBLE
		  fit_results_file << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " calculated. E=" << E << endl;
		  cout             << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " calculated. E=" << E << endl;
#endif
		}
	    }
	}
    }
}









// Calculations of the energy gradients of all fitted many-body states with respect to Hamiltonian parameters
// ----------------------------------------------------------------------------------------------------------

void energies_gradients_Hessian_natural_orbitals_all_nuclei::PSI_qn_tab_E_grad_all_states_calc (
												const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
												const class array<bool> &is_there_l_dependence_from_fit_index , 
												const class array<int> &l_from_fit_index , 
												const class vector_class<double> &FHT_EFT_parameters , 
												const class array<class input_data_str> &input_data_tab , 
												const class array<class interaction_class> &inter_data_units , 
												class interaction_class &inter_data_Coulomb , 
												class interaction_class &inter_data_basis , 
												class interaction_class &inter_data , 
												class GSM_vector &PSI_full , 
												ofstream &fit_results_file , 
												class array<class correlated_state_str> &PSI_qn_tab , 
												class array<class vector_class<TYPE> > &E_grad_all_states)
{
  const class input_data_str &input_data_zero = input_data_tab(0);

  const unsigned int N_nuclei_to_consider = input_data_zero.get_N_nuclei_to_consider ();

  const unsigned int N_parameters_to_fit = FHT_EFT_parameters_from_fit_index.dimension (0);

  const double frozen_core_mass = input_data_zero.get_frozen_core_mass ();
  
  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {    
      class input_data_str &input_data = input_data_tab(nucleus_index);

      input_data.set_FHT_EFT_parameters (false , input_data_tab , FHT_EFT_parameters);
      
      const double TBME_A_dependent_factor = TBME_A_dependent_factor_calc (input_data);
	    
      inter_data.calculate_from_units_Coulomb_kinetic (frozen_core_mass , FHT_EFT_parameters , TBME_A_dependent_factor , inter_data_units , inter_data_Coulomb);
      
      const unsigned int eigensets_number = input_data.get_eigensets_number ();
      
      const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

      const unsigned int eigenset_vectors_number_max = eigenset_vectors_number_tab.max ();

      class array<class correlated_state_str> &PSI_qn_from_file_fixed_nucleus_tab = input_data.get_PSI_qn_from_file_tab ();
      
      class array<class correlated_state_str> PSI_qn_fixed_nucleus_tab(eigensets_number , eigenset_vectors_number_max);

      class array<class vector_class<TYPE> > E_grad_all_states_fixed_nucleus(eigensets_number , eigenset_vectors_number_max);

      fixed_nucleus::E_grad_E_all_states_alloc_calc (FHT_EFT_parameters_from_fit_index , is_there_l_dependence_from_fit_index , l_from_fit_index , 
						     inter_data_units , FHT_EFT_parameters , inter_data_Coulomb , input_data , inter_data_basis ,
						     inter_data , PSI_full , PSI_qn_fixed_nucleus_tab , E_grad_all_states_fixed_nucleus);
      
      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {
	      const class correlated_state_str &PSI_qn_fixed_nucleus = PSI_qn_fixed_nucleus_tab(eigenset_index , i);
	      	      
	      PSI_qn_from_file_fixed_nucleus_tab(eigenset_index , i) = PSI_qn_fixed_nucleus;
	      
	      PSI_qn_tab(nucleus_index , eigenset_index , i) = PSI_qn_fixed_nucleus;

	      const class correlated_state_str &PSI_qn = PSI_qn_tab(nucleus_index , eigenset_index , i);
	      
	      const bool is_it_optimization_reference_state = PSI_qn.get_is_it_optimization_reference_state ();
	      
	      const double weight = PSI_qn.get_weight ();
			 
	      const class vector_class<TYPE> &E_grad_fixed_nucleus = E_grad_all_states_fixed_nucleus(eigenset_index , i);

	      if (is_it_optimization_reference_state || (weight != 0.0))
		{
		  class vector_class<TYPE> &E_grad = E_grad_all_states(nucleus_index , eigenset_index , i);
	      
		  if (!E_grad.is_it_filled ()) E_grad.allocate (N_parameters_to_fit);

		  E_grad = E_grad_fixed_nucleus;
		}	  
	    }
	}
    }
  
  const TYPE E_reference_state = optimization_data_handling::reference_state_energy_determine (input_data_tab , PSI_qn_tab);

  const class vector_class<TYPE> E_grad_reference_state = optimization_data_handling::reference_state_E_grad_determine (N_parameters_to_fit , input_data_tab , PSI_qn_tab , E_grad_all_states);

  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {    
      const class input_data_str &input_data = input_data_tab(nucleus_index);

      const int Z = input_data.get_Z ();
      const int N = input_data.get_N ();
      
      const unsigned int eigensets_number = input_data.get_eigensets_number ();
      
      const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();
      
      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {
	      class correlated_state_str &PSI_qn = PSI_qn_tab(nucleus_index , eigenset_index , i);
	      
	      const unsigned int BP = PSI_qn.get_BP ();
	      
	      const double J = PSI_qn.get_J ();
	      
	      const double weight = PSI_qn.get_weight ();
	      
	      const complex<double> E_init = PSI_qn.get_E ();
	      
	      const complex<double> E_complex = E_init - E_reference_state;
	      
	      const TYPE E = generate_scalar<TYPE> (real (E_complex) , imag (E_complex));
	      
	      PSI_qn.initialize (
				 PSI_qn.get_Z () ,
				 PSI_qn.get_N () ,
				 BP ,
				 J ,
				 PSI_qn.get_vector_index () ,
				 E ,
				 weight ,
				 PSI_qn.get_experimental_energy () ,
				 PSI_qn.get_energy_error () ,
				 PSI_qn.get_is_it_optimization_reference_state ());
	      
	      if (weight != 0.0) E_grad_all_states(nucleus_index , eigenset_index , i) -= E_grad_reference_state;
	      
	      if (THIS_PROCESS == MASTER_PROCESS)
		{
		  
#ifdef TYPEisDOUBLECOMPLEX
		  fit_results_file << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " calculated. E=" << real (E) << " MeV Gamma=" << -2000.0*imag (E) << " keV" << endl;
		  cout             << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " calculated. E=" << real (E) << " MeV Gamma=" << -2000.0*imag (E) << " keV" << endl;
#endif
		  
#ifdef TYPEisDOUBLE
		  fit_results_file << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " calculated. E=" << E << endl;
		  cout             << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " calculated. E=" << E << endl;
#endif
		}
	    }
	}
    }  
}









// Calculations of the natural orbitals associated to many-body states
// -------------------------------------------------------------------

void energies_gradients_Hessian_natural_orbitals_all_nuclei::all_natural_orbitals_calc_store (
											      const unsigned int N_nuclei_to_consider,
											      const class interaction_class &inter_data_basis ,
											      const class interaction_class &inter_data ,
											      const class array<class input_data_str> &input_data_tab ,
											      class GSM_vector &PSI_full)
{  
  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {    
      class input_data_str &input_data = input_data_tab(nucleus_index);
      
      const bool are_there_new_prot_natural_orbitals = input_data.get_are_there_new_prot_natural_orbitals ();
      const bool are_there_new_neut_natural_orbitals = input_data.get_are_there_new_neut_natural_orbitals ();
      
      if (are_there_new_prot_natural_orbitals || are_there_new_neut_natural_orbitals)
	fixed_nucleus::natural_orbitals_OBMEs_basis_store (input_data , inter_data_basis , inter_data , PSI_full);
    }
}









// Calculation of the Hessian matrix associated to the cost function depending on energies and Hessian matrix print on screen
// --------------------------------------------------------------------------------------------------------------------------

void energies_gradients_Hessian_natural_orbitals_all_nuclei::cost_function_Hessian_matrix_calc_print (
												      const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
												      const class array<bool> &is_there_l_dependence_from_fit_index , 
												      const class array<int> &l_from_fit_index , 
												      const class vector_class<double> &FHT_EFT_parameters , 
												      const class array<class interaction_class> &inter_data_units ,  
												      class array<class input_data_str> &input_data_tab , 
												      class interaction_class &inter_data_Coulomb , 
												      class interaction_class &inter_data_basis , 
												      class interaction_class &inter_data ,
												      class GSM_vector &PSI_full ,
												      ofstream &fit_results_file)
{
  const class input_data_str &input_data_zero = input_data_tab(0);

  const unsigned int N_nuclei_to_consider = input_data_zero.get_N_nuclei_to_consider ();

  const unsigned int eigensets_number_max = optimization_data_handling::eigensets_number_max_determine (input_data_tab);

  const unsigned int eigenset_vectors_number_max = optimization_data_handling::eigenset_vectors_number_max_determine (input_data_tab);

  const int lmax_p_all_inputs = lmax_p_all_determine (input_data_tab);
  const int lmax_n_all_inputs = lmax_n_all_determine (input_data_tab);

  const int lmax_all_inputs = max (lmax_p_all_inputs , lmax_n_all_inputs);

  const unsigned int N_parameters_to_fit = FHT_EFT_parameters_from_fit_index.dimension (0);

  const double plus_shift  = 1.0 + sqrt_precision;
  const double minus_shift = 1.0 - sqrt_precision;

  class array<class correlated_state_str> PSI_qn_tab      (N_nuclei_to_consider , eigensets_number_max , eigenset_vectors_number_max);
  class array<class correlated_state_str> PSI_qn_tab_plus (N_nuclei_to_consider , eigensets_number_max , eigenset_vectors_number_max);
  class array<class correlated_state_str> PSI_qn_tab_minus(N_nuclei_to_consider , eigensets_number_max , eigenset_vectors_number_max);

  class array<class vector_class<TYPE> > E_grad_all_states      (N_nuclei_to_consider , eigensets_number_max , eigenset_vectors_number_max);
  class array<class vector_class<TYPE> > E_grad_all_states_plus (N_nuclei_to_consider , eigensets_number_max , eigenset_vectors_number_max);
  class array<class vector_class<TYPE> > E_grad_all_states_minus(N_nuclei_to_consider , eigensets_number_max , eigenset_vectors_number_max);

  class array<class matrix<TYPE> > E_Hessian_matrices_all_states(N_nuclei_to_consider , eigensets_number_max , eigenset_vectors_number_max);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      fit_results_file << endl << "--------------------------------" << endl;
      fit_results_file         << "Hessian matrix calculation " << endl;
      fit_results_file         << "--------------------------------" << endl << endl;
      
      cout << endl << "--------------------------------" << endl;
      cout         << "Hessian matrix calculation " << endl;
      cout         << "--------------------------------" << endl << endl;
    }

  energies_gradients_Hessian_natural_orbitals_all_nuclei::PSI_qn_tab_E_grad_all_states_calc (FHT_EFT_parameters_from_fit_index , is_there_l_dependence_from_fit_index , 
											     l_from_fit_index , FHT_EFT_parameters , input_data_tab , inter_data_units , inter_data_Coulomb , inter_data_basis , inter_data , PSI_full ,
											     fit_results_file , PSI_qn_tab , E_grad_all_states);

  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
    {
      const enum FHT_EFT_parameter_type FHT_EFT_parameter = FHT_EFT_parameters_from_fit_index(fit_index);

      const int lmin = ((FHT_EFT_parameter == CORE_VSO_PROTON) || (FHT_EFT_parameter == CORE_VSO_NEUTRON)) ? (1) : (0);

      const bool is_there_l_dependence = is_there_l_dependence_from_fit_index(fit_index);      

      const int l = (is_there_l_dependence) ? (l_from_fit_index(fit_index)) : (lmin);
     
      if (THIS_PROCESS == MASTER_PROCESS)
	{ 
	  if (is_there_l_dependence)
	    {
	      fit_results_file << endl << "--------------------------------------------------------------------------------" << endl;
	      fit_results_file         << "Varied FHT_EFT_parameter : " << FHT_EFT_parameter << " l=" << l << endl;
	      fit_results_file         << "--------------------------------------------------------------------------------" << endl << endl;

	      cout << endl << "--------------------------------------------------------------------------------" << endl;
	      cout         << "Varied FHT_EFT_parameter : " << FHT_EFT_parameter << " l=" << l << endl;
	      cout         << "--------------------------------------------------------------------------------" << endl << endl;
	    }
	  else
	    {
	      fit_results_file << endl << "--------------------------------------------------------------------------------" << endl;
	      fit_results_file         << "Varied FHT_EFT_parameter : " << FHT_EFT_parameter << endl;
	      fit_results_file         << "--------------------------------------------------------------------------------" << endl << endl;

	      cout << endl << "--------------------------------------------------------------------------------" << endl;
	      cout         << "Varied FHT_EFT_parameter : " << FHT_EFT_parameter << endl;
	      cout         << "--------------------------------------------------------------------------------" << endl << endl;
	    }
	}

      const unsigned int FHT_EFT_parameter_index = FHT_EFT_parameter_index_determine (FHT_EFT_parameter , lmax_all_inputs , l);

      const double FHT_EFT_parameter_value = FHT_EFT_parameters(FHT_EFT_parameter_index);
      
      const double FHT_EFT_parameter_value_plus  = (FHT_EFT_parameter_value != 0.0) ? (FHT_EFT_parameter_value*plus_shift)  : ( sqrt_precision);
      const double FHT_EFT_parameter_value_minus = (FHT_EFT_parameter_value != 0.0) ? (FHT_EFT_parameter_value*minus_shift) : (-sqrt_precision);

      const TYPE FHT_EFT_parameter_values_difference = FHT_EFT_parameter_value_plus - FHT_EFT_parameter_value_minus;

      class vector_class<double> FHT_EFT_parameters_plus  = FHT_EFT_parameters;
      class vector_class<double> FHT_EFT_parameters_minus = FHT_EFT_parameters;

      if (is_there_l_dependence || (FHT_EFT_parameter == CORE_R_CHARGE_PROTON))
	{
	  FHT_EFT_parameters_plus(FHT_EFT_parameter_index)  = FHT_EFT_parameter_value_plus;
	  FHT_EFT_parameters_minus(FHT_EFT_parameter_index) = FHT_EFT_parameter_value_minus;
	}
      else
	{
	  for (int l_prime = lmin ; l_prime <= lmax_all_inputs ; l_prime++)
	    {
	      const unsigned int FHT_EFT_parameter_index_prime = FHT_EFT_parameter_index_determine (FHT_EFT_parameter , lmax_all_inputs , l_prime);
	      
	      FHT_EFT_parameters_plus(FHT_EFT_parameter_index_prime)  = FHT_EFT_parameter_value_plus;
	      FHT_EFT_parameters_minus(FHT_EFT_parameter_index_prime) = FHT_EFT_parameter_value_minus;
	    }
	}

      energies_gradients_Hessian_natural_orbitals_all_nuclei::PSI_qn_tab_E_grad_all_states_calc (FHT_EFT_parameters_from_fit_index , is_there_l_dependence_from_fit_index , l_from_fit_index , 
												 FHT_EFT_parameters_plus , input_data_tab , inter_data_units , inter_data_Coulomb , inter_data_basis , inter_data , PSI_full , 
												 fit_results_file , PSI_qn_tab_plus , E_grad_all_states_plus);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  fit_results_file << endl;
	  
	  cout << endl;
	}

      energies_gradients_Hessian_natural_orbitals_all_nuclei::PSI_qn_tab_E_grad_all_states_calc (FHT_EFT_parameters_from_fit_index , is_there_l_dependence_from_fit_index , l_from_fit_index , 
												 FHT_EFT_parameters_minus , input_data_tab , inter_data_units , inter_data_Coulomb , inter_data_basis , inter_data , PSI_full ,
												 fit_results_file , PSI_qn_tab_minus , E_grad_all_states_minus);

      for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
	{
	  const class input_data_str &input_data = input_data_tab(nucleus_index);

	  const unsigned int eigensets_number = input_data.get_eigensets_number ();

	  const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

	  for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	    {
	      const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
		{
		  const class vector_class<TYPE> &E_grad_plus  = E_grad_all_states_plus (nucleus_index , eigenset_index , i);
		  const class vector_class<TYPE> &E_grad_minus = E_grad_all_states_minus(nucleus_index , eigenset_index , i);

		  class matrix<TYPE> &E_Hessian_matrix = E_Hessian_matrices_all_states(nucleus_index , eigenset_index , i);

		  if (!E_Hessian_matrix.is_it_filled ()) E_Hessian_matrix.allocate (N_parameters_to_fit);

		  E_Hessian_matrix.row_vector (fit_index) = (E_grad_plus - E_grad_minus) / FHT_EFT_parameter_values_difference;
		}
	    }
	}

      FHT_EFT_parameters_plus(FHT_EFT_parameter_index) = FHT_EFT_parameters_minus(FHT_EFT_parameter_index) = FHT_EFT_parameter_value;
    }

  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {
      const class input_data_str &input_data = input_data_tab(nucleus_index);

      const unsigned int eigensets_number = input_data.get_eigensets_number ();

      const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++) E_Hessian_matrices_all_states(nucleus_index , eigenset_index , i).symmetrize ();
	}
    }

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      fit_results_file << endl << "-------------------------------------" << endl;
      fit_results_file         << " Energies Hessian matrices calculated " << endl;
      fit_results_file         << "-------------------------------------" << endl << endl;
      
      cout << endl << "-------------------------------------" << endl;
      cout         << " Energies Hessian matrices calculated " << endl;
      cout         << "-------------------------------------" << endl << endl;

      optimization_data_handling::cost_function_Hessian_matrix_calc_print_from_all_states (input_data_tab , PSI_qn_tab , FHT_EFT_parameters_from_fit_index , is_there_l_dependence_from_fit_index , l_from_fit_index , 
											   E_grad_all_states , E_Hessian_matrices_all_states , fit_results_file);
    }
}





