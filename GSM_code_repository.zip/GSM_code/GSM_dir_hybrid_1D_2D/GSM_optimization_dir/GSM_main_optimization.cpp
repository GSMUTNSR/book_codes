#include "GSM_optimization_include/GSM_optimization_include_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

enum called_code_type called_code = OPTIMIZATION_CODE;

using namespace inputs_misc;




#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    print_array_vector_test_status<int> ();

    //--// dummy variables
    class array<double> dummy_array_double;
    class array<string> dummy_array_string;
    class input_data_str dummy_input_data;
    
    //================================== input data common and table  ==================================//
    
    //--// classes which contain all input values and some pointers on tables
    //
    class input_data_str input_data_common; 

    class array<class input_data_str> input_data_tab;
    
    //--// collecting of values from the input (not all)
    call_common_routines::input_data_read_MPI_transfer (dummy_array_double , dummy_array_double , dummy_array_string , input_data_common , dummy_input_data , input_data_tab);

    const unsigned int N_nuclei_to_consider = input_data_common.get_N_nuclei_to_consider ();

#ifdef UseMPI
    if (THIS_PROCESS != MASTER_PROCESS) input_data_tab.allocate (N_nuclei_to_consider);
#endif

    optimization_data_handling::copy_common_data_to_input_data_tab (input_data_common , input_data_tab);

    //weight normalization
    
    const double weights_sum = optimization_data_handling::weights_sum_calc (input_data_tab);
    
    if (weights_sum != 0.0) optimization_data_handling::weights_normalization (1.0/weights_sum , input_data_tab);

    //================================== FHT/EFT parameters from input tables, basis interaction, interaction units and Coulomb interaction ==================================//
    
    const int lmax_p_all_inputs = lmax_p_all_determine (input_data_tab);
    const int lmax_n_all_inputs = lmax_n_all_determine (input_data_tab);
    
    const int lmax_all_inputs = max (lmax_p_all_inputs , lmax_n_all_inputs);

    //defines optimization parameters
    const unsigned int N_parameters = FHT_EFT_parameter_number_determine (lmax_all_inputs);
    
    class vector_class<double> FHT_EFT_parameters(N_parameters);

    optimization_data_handling::FHT_EFT_parameters_from_input (input_data_common , FHT_EFT_parameters);
    
    const unsigned int dimension_inter_data_units = FHT_EFT_units_number_determine ();
    
    class array<class interaction_class> inter_data_units(dimension_inter_data_units);

    optimization_data_handling::unit_interactions_alloc_calc (input_data_common , inter_data_units);

    class interaction_class inter_data_Coulomb(false , false , true , input_data_common);
    
    inter_data_Coulomb.inter_data_calc (input_data_common);

    if (THIS_PROCESS == MASTER_PROCESS) cout << "Coulomb interaction calculated" << endl;
      
    //--// class which contains information on the interaction for the basis
    class interaction_class inter_data_basis (false , true , false , input_data_common);
    
    inter_data_basis.inter_data_calc (input_data_common);
        
    //================================== Multidimensional Newton method to optimize the GSM Hamiltonian ==================================//
    
    ofstream fit_results_file;
    optimization_data_handling::fit_results_file_init (fit_results_file);

    const unsigned int N_parameters_to_fit = input_data_common.N_parameters_to_fit_calc ();
    
    class array<enum FHT_EFT_parameter_type> FHT_EFT_parameters_from_fit_index(N_parameters_to_fit);
    class array<bool> is_there_l_dependence_from_fit_index(N_parameters_to_fit);
    class array<int> l_from_fit_index(N_parameters_to_fit);

    input_data_common.fit_indices_tables_calc (FHT_EFT_parameters_from_fit_index , is_there_l_dependence_from_fit_index , l_from_fit_index);

    class interaction_class inter_data(false , false , false , input_data_common);

    class GSM_vector PSI_full;
        
    bool are_all_weights_zero_all_eigensets = optimization_data_handling::are_all_weights_zero_all_eigensets_determine (input_data_tab);

    const bool is_cost_function_Hessian_matrix_calculated = input_data_common.get_is_cost_function_Hessian_matrix_calculated ();

    const unsigned int N_states_to_fit = optimization_data_handling::N_states_to_fit_calc (input_data_tab);
  
    const bool is_it_fixed_relative_SVD_precision = input_data_common.get_is_it_fixed_relative_SVD_precision ();

    const double relative_SVD_precision = input_data_common.get_relative_SVD_precision ();
    
    const unsigned int rejected_singular_values_number = input_data_common.get_rejected_singular_values_number ();
    
    class matrix<double> G(N_states_to_fit , N_parameters_to_fit);
    
    if (!are_all_weights_zero_all_eigensets)
      optimization_Newton::calc_print (input_data_common , FHT_EFT_parameters_from_fit_index , is_there_l_dependence_from_fit_index , l_from_fit_index , inter_data_units , 
				       input_data_tab , inter_data_Coulomb , inter_data_basis , inter_data , PSI_full , FHT_EFT_parameters , G , fit_results_file);
    
    //================================== Optimized interation parameters printed. ==================================//
    
    if (THIS_PROCESS == MASTER_PROCESS) 
      {
	fit_results_file << endl << "--------------------" << endl;
	fit_results_file         << "Results" << endl;
	fit_results_file         << "--------------------" << endl;

	cout << endl << "--------------------" << endl;
	cout         << "Results" << endl;
	cout         << "--------------------" << endl;
      }

    optimization_data_handling::print_all_parameters (input_data_common , FHT_EFT_parameters , fit_results_file);
  
    if (!are_all_weights_zero_all_eigensets)
      optimization_data_handling::FHT_EFT_parameters_information_print (is_it_fixed_relative_SVD_precision , relative_SVD_precision , rejected_singular_values_number ,
									N_states_to_fit , FHT_EFT_parameters_from_fit_index ,
									is_there_l_dependence_from_fit_index , l_from_fit_index , G , fit_results_file);
    
    cost_function::results_calc_print_Birge_factor_renormalization (FHT_EFT_parameters , inter_data_units , FHT_EFT_parameters_from_fit_index ,
								    inter_data_Coulomb , inter_data_basis , inter_data , PSI_full , input_data_tab , is_there_l_dependence_from_fit_index , l_from_fit_index , fit_results_file);
    
    //================================== Natural orbitals calculated and stored if not done before ==================================//
    
    const bool are_natural_orbitals_calculated_every_iteration = input_data_common.get_are_natural_orbitals_calculated_every_iteration ();
    
    if (!are_natural_orbitals_calculated_every_iteration)
      energies_gradients_Hessian_natural_orbitals_all_nuclei::all_natural_orbitals_calc_store (N_nuclei_to_consider , inter_data_basis , inter_data , input_data_tab , PSI_full);
      
    //================================== cost function Hessian matrix calculated from gradients ==================================//

    are_all_weights_zero_all_eigensets = optimization_data_handling::are_all_weights_zero_all_eigensets_determine (input_data_tab); //weights are put to zero if the Birge factor is equal to zero or undefined, so that the boolean must be reset.
    
    if (is_cost_function_Hessian_matrix_calculated)
      {
	if (!are_all_weights_zero_all_eigensets)
	  energies_gradients_Hessian_natural_orbitals_all_nuclei::cost_function_Hessian_matrix_calc_print (FHT_EFT_parameters_from_fit_index , is_there_l_dependence_from_fit_index , l_from_fit_index , FHT_EFT_parameters , 
													   inter_data_units , input_data_tab , inter_data_Coulomb , inter_data_basis , inter_data , PSI_full , fit_results_file);
	else if (THIS_PROCESS == MASTER_PROCESS)
	  {
	    fit_results_file << endl << "Hessian matrix is equal to zero" << endl;
	    cout             << endl << "Hessian matrix is equal to zero" << endl;
	  }
      }
    
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif

    return 0;
  }


