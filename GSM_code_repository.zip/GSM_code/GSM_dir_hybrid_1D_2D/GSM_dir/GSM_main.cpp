#include "../GSM_include/GSM_include_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

enum called_code_type called_code = GSM_CODE; 

using namespace inputs_misc;
using namespace GSM_vector_dimensions;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    print_array_vector_test_status<int> ();

    //--// dummy variables
    
    class array<class input_data_str> dummy_input_data_tab;

    class input_data_str dummy_input_data;
    
    //--// 
    
    class array<double> SPE_coefficients;

    class array<double> TBME_coefficients;

    class array<string> file_names;

    //================================== input data and nucleons data ==================================//
    
    //--// initialization of the class which contains all input values and some pointers on tables (not all initialized here)

    class input_data_str input_data;
    
    call_common_routines::input_data_read_MPI_transfer (SPE_coefficients , TBME_coefficients , file_names , input_data , dummy_input_data , dummy_input_data_tab);
    
    //--// initialization of the classes which contain information on protons and neutrons
    
    class nucleons_data prot_data;
    class nucleons_data neut_data;
		
    nucleons_data_initialization (true , input_data , prot_data , neut_data);

    const bool is_it_cluster_CM_HO_basis_calculation = input_data.get_is_it_cluster_CM_HO_basis_calculation ();
    
    const bool only_dimensions = input_data.get_only_dimensions ();

    const bool copy_J_OBMEs_TBMEs = input_data.get_copy_J_OBMEs_TBMEs ();
    
    const enum space_type space = input_data.get_space ();
    
    //================================== OBMEs and TBMEs read from files  ==================================//
    
    //--// initialization of the classes which contain the OBMEs and TBMEs (fitted interactions stored in files or SU(3) interaction only)

    const enum interaction_type inter = input_data.get_inter ();
  
    const bool is_it_fit_or_SU3 = ((inter == FIT) || (inter == SU3_INTERACTION));
    
    const unsigned int files_number = input_data.get_files_number ();
    
    class array<class array<class JT_coupled_TBME> > JT_TBMEs_tables(files_number);

    if (is_it_fit_or_SU3) OBMEs_TBMEs::standard_HO_SM::h_JT_TBMEs_alloc_fill (true , input_data , SPE_coefficients , TBME_coefficients , file_names , prot_data , neut_data , JT_TBMEs_tables);
    
    //================================== GSM basis interaction and HF potentials ==================================//
    
    //--// class which contains information on the interaction for the basis
    
    class interaction_class inter_data_basis (true , true , false , input_data);

    if (!is_it_fit_or_SU3) inter_data_basis.inter_data_calc (input_data);

    //--// classes which contain information on protons and neutrons in the HF potential
    
    class HF_nucleons_data prot_HF_data(input_data , prot_data);
    class HF_nucleons_data neut_HF_data(input_data , neut_data);

    const enum potential_type basis_potential = input_data.get_basis_potential ();

    if (basis_potential == MSDHF)
      MSDHF_potentials::potentials_shells_OBMEs_realloc_calc (true , input_data , inter_data_basis , prot_HF_data , neut_HF_data , prot_data , neut_data);
    else
      HF_potentials::potentials_shells_OBMEs_realloc_calc (true , input_data , inter_data_basis , prot_HF_data , neut_HF_data , prot_data , neut_data);
      
    prot_HF_data.deallocate ();
    neut_HF_data.deallocate ();
        
    //================================== GSM interaction  ==================================//

    //--// class which contains information on the interaction

    class interaction_class inter_data(true , false , false , input_data);

    if (!is_it_fit_or_SU3) inter_data.inter_data_calc (input_data);

    //================================== Berggren one-body basis and space truncation  ==================================//
    
    //--// initialization of the tables containing the one-body basis
    
    Berggren_basis::single_particle_indices_radial_wfs_prot_neut_alloc_calc (true , input_data , prot_data , neut_data);
	
    space_truncation_data_best_hbar_omega_calc (true , input_data , prot_data , neut_data);
    
    //================================== OBMEs, TBMEs  ==================================//
    
    if (!is_it_fit_or_SU3) all_HO_GHF_overlaps_prot_neut_alloc_calc (input_data , prot_data , neut_data);
    
    //--// initialization of the class which contains proton-neutron TBMEs
    class TBMEs_class TBMEs_pn;
    
    if (!only_dimensions) 
      {
	OBMEs_TBMEs::all_OBMEs_TBMEs_alloc_calc (true , false , JT_TBMEs_tables , inter_data_basis , inter_data , input_data , prot_data , neut_data , TBMEs_pn);
			
	hole_double_counting::prot_neut_OBMEs_no_natural_orbitals_calc_store_remove (false , input_data , prot_data , neut_data , TBMEs_pn);
      }

    if (copy_J_OBMEs_TBMEs)
      {
	if (THIS_PROCESS == MASTER_PROCESS) inter_data.copy_disk (STORAGE_DIR + "v2body_HO_lab.dat");

#ifdef UseMPI
	MPI_helper::Finalize ();
#endif
	
	return 0;
      }
    
    //================================== configurations, SDs  ==================================//
    
    configuration_SD_sets::configuration_SD_tables_pp_nn_alloc_calc (true , false , false , input_data , prot_data , neut_data);
    
    //================================== GSM space dimensions ==================================//
        
    const int n_scat_max = (!is_it_cluster_CM_HO_basis_calculation) ? (input_data.get_n_scat_max ()) : (0);

    const int n_scat_max_plus_one = n_scat_max + 1;

    const unsigned int J_index_max = J_index_max_calc (space , prot_data , neut_data);

    const unsigned int J_index_max_plus_one = J_index_max + 1;
    
    //--// initialization of the tables containing the GSM space dimensions at pole approximation and in full space

    class array<unsigned long int> total_space_dimensions_good_J_pole_approximation(2 , 1 , J_index_max_plus_one);

    class array<unsigned long int> total_space_dimensions_good_J(2 , n_scat_max_plus_one , J_index_max_plus_one);

    all_J_total_space_dimensions_calc_print (true , input_data , prot_data , neut_data , total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J);
 
    if (only_dimensions)
      {
#ifdef UseMPI
	MPI_helper::Finalize ();
#endif
	return 0;
      }
    
    //================================== Calculation of eigenvectors and energies: pole approximation with Lanczos, full space with Lanczos or Davidson. ==================================//
    
    class GSM_vector PSI_full;
  
    const bool non_zero_NBMEs_proportion_only = input_data.get_non_zero_NBMEs_proportion_only ();
    
    //--// initialization of the table of classes containing GSM eigenstates quantum numbers (qn)

    const unsigned int eigensets_number = input_data.get_eigensets_number ();

    const unsigned int vectors_to_find_number_max = vectors_to_find_number_max_determine (input_data , total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J);    
    
    //--// initialization of the table of classes containing GSM eigenstates quantum numbers (qn)

    class array<class correlated_state_str> PSI_qn_tab(eigensets_number , vectors_to_find_number_max);

    input_data.PSI_quantum_numbers_tab_partial_fill (total_space_dimensions_good_J , PSI_qn_tab);

    //--// Calculations of GSM eigenvalues and eigenvectors at pole approximation and full space level
    
    eigenvector_functions::eigenvectors_pole_approximation_full_space_calc (true , is_it_cluster_CM_HO_basis_calculation , input_data ,
									    total_space_dimensions_good_J_pole_approximation , total_space_dimensions_good_J ,
									    TBMEs_pn ,  prot_data , neut_data , PSI_qn_tab , PSI_full);

    if (is_it_cluster_CM_HO_basis_calculation)
      {
	const unsigned int eigensets_number = input_data.get_eigensets_number ();

	const class array<unsigned int> eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

	for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	  {
	    const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	    for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	      {
		class cluster_data data(true , input_data , prot_data , neut_data , inter_data_basis , eigenset_index , i);
		
		cluster_CM_intrinsic_basis_states::GSM_vector_NCM_HO_LCM_HO_basis_tab_calc_store (true , input_data , data);
	      }	
	  }
      }
    else
      {
  
	//================================== Calculations of SM observables ==================================//
    
	//--// Calculations of observables at full space level

	if (!non_zero_NBMEs_proportion_only) GSM_observables::calculation (input_data , PSI_qn_tab , inter_data , TBMEs_pn , prot_data , neut_data , PSI_full);
      }
    
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
    
    return 0;
  }


