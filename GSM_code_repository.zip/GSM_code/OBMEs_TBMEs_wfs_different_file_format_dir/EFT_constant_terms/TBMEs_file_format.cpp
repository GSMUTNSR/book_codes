
#include "../../numlib/numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace string_routines;

#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    const double four_Pi_inv = 0.25*M_1_PI;
  
    const string sp_states_input_file_name = "nnlo_EFT_merge_l3n6_cutoff300_T.sp";
  
    ifstream sp_states_input(sp_states_input_file_name.c_str ());

    file_existence_check (sp_states_input_file_name , sp_states_input);
  
    double b_lab = 0.0;
  
    sp_states_input >> b_lab;
  
    unsigned int N_sp = 0;
  
    sp_states_input >> N_sp;
  
    class array<int> n_tab(N_sp);
    class array<int> l_tab(N_sp);
  
    class array<double> j_tab(N_sp);
  
    for (unsigned int i = 0 ; i < N_sp ; i++)
      {
	string dummy;
      
	unsigned int index;
      
	int n;
	int l;

	int two_j;
	int two_tz;
      
	sp_states_input >> index >> n >> l >> two_j >> two_tz >> dummy >> dummy >> dummy >> dummy;
      
	index--;
      
	n_tab(index) = n;
	l_tab(index) = l;
      
	j_tab(index) = 0.5*two_j;
      }

    const unsigned int FHT_EFT_parameter_type_number_no_T = 9;
  
    const unsigned int FHT_EFT_parameter_type_number = FHT_EFT_parameter_type_number_no_T + 2;
  
    const string TBMEs_HO_lab_input_file_name = "nnlo_EFT_merge_l3n6_cutoff300_T.int";
  
    ifstream TBMEs_HO_lab_input(TBMEs_HO_lab_input_file_name.c_str ());

    file_existence_check (TBMEs_HO_lab_input_file_name , TBMEs_HO_lab_input);
    
    unsigned int TBMEs_HO_lab_number = 0;
  
    TBMEs_HO_lab_input >> TBMEs_HO_lab_number;
  
    class array<int> T_tab(TBMEs_HO_lab_number);
  
    class array<int> parity_tab(TBMEs_HO_lab_number);
  
    class array<int> J_tab(TBMEs_HO_lab_number);
  
    class array<int> index_sa_tab(TBMEs_HO_lab_number);
    class array<int> index_sb_tab(TBMEs_HO_lab_number);
    class array<int> index_sc_tab(TBMEs_HO_lab_number);
    class array<int> index_sd_tab(TBMEs_HO_lab_number);
  
    class array<double> TBMEs_HO_lab(TBMEs_HO_lab_number , FHT_EFT_parameter_type_number);  

    TBMEs_HO_lab = 0.0;
  
    for (unsigned int i = 0 ; i < TBMEs_HO_lab_number ; i++)
      {
	int T;
	int Parity;
	int J;
	int index_sa , index_sb , index_sc , index_sd;

	double TBMEs_HO_lab_abcd[FHT_EFT_parameter_type_number_no_T];

	double dummy_TBME;

	TBMEs_HO_lab_input >> J >> T >> Parity >> index_sa >> index_sb >> index_sc >> index_sd;      

	for (unsigned int ii = 0 ; ii < FHT_EFT_parameter_type_number_no_T ; ii++) TBMEs_HO_lab_input >> TBMEs_HO_lab_abcd[ii] >> dummy_TBME >> dummy_TBME;

	TBMEs_HO_lab_input >> dummy_TBME >> dummy_TBME >> dummy_TBME;

	for (unsigned int ii = 0 ; ii < FHT_EFT_parameter_type_number_no_T ; ii++) TBMEs_HO_lab_abcd[ii] *= 10.0;

	TBMEs_HO_lab_abcd[0] *= four_Pi_inv;
	TBMEs_HO_lab_abcd[1] *= four_Pi_inv;
  
	T_tab(i) = T;
	J_tab(i) = J;
      	  
	index_sa_tab(i) = index_sa - 1;
	index_sb_tab(i) = index_sb - 1;
	index_sc_tab(i) = index_sc - 1;
	index_sd_tab(i) = index_sd - 1;

	if (T == 0)
	  {
	    TBMEs_HO_lab(i , 0) = TBMEs_HO_lab_abcd[0];
	    TBMEs_HO_lab(i , 2) = TBMEs_HO_lab_abcd[1];
	  }
      
	if (T == 1)
	  {
	    TBMEs_HO_lab(i , 1) = TBMEs_HO_lab_abcd[0];
	    TBMEs_HO_lab(i , 3) = TBMEs_HO_lab_abcd[1];
	  }
      
	for (unsigned int ii = 2 ; ii < FHT_EFT_parameter_type_number_no_T ; ii++) TBMEs_HO_lab(i , ii + 2) = TBMEs_HO_lab_abcd[ii];
      }
	  
    const enum FHT_EFT_parameter_type FHT_EFT_parameter_types[] = {VS_LO_T0 , VS_LO_T1 , VT_SIGMA_PRODUCT_LO_T0 , VT_SIGMA_PRODUCT_LO_T1 ,
								   V1_Q2_NLO , V2_K2_NLO , V3_Q2_SIGMA_PRODUCT_NLO , V4_K2_SIGMA_PRODUCT_NLO ,
								   V5_SIGMA_Q_VECTOR_K_NLO , V6_SIGMA_Q_PRODUCT_NLO , V7_SIGMA_K_PRODUCT_NLO};

    for (unsigned int ii = 0 ; ii < FHT_EFT_parameter_type_number ; ii++)
      {
	const enum FHT_EFT_parameter_type FHT_EFT_parameter = FHT_EFT_parameter_types[ii];
      
	const string TBMEs_HO_lab_HO_lab_file_name = STORAGE_DIR + "v2body_HO_lab_" + make_string<enum FHT_EFT_parameter_type> (FHT_EFT_parameter) + ".dat";
      
	ofstream TBMEs_HO_lab_HO_lab_output(TBMEs_HO_lab_HO_lab_file_name.c_str ());
  
	TBMEs_HO_lab_HO_lab_output.precision (15);

	TBMEs_HO_lab_HO_lab_output << b_lab << endl;
    
	for (unsigned int i = 0 ; i < TBMEs_HO_lab_number ; i++)
	  {
	    const int T = T_tab(i);

	    if ((T == 0) && (FHT_EFT_parameter == VS_LO_T1)) continue;
	    if ((T == 1) && (FHT_EFT_parameter == VS_LO_T0)) continue;
	  
	    if ((T == 0) && (FHT_EFT_parameter == VT_SIGMA_PRODUCT_LO_T1)) continue;
	    if ((T == 1) && (FHT_EFT_parameter == VT_SIGMA_PRODUCT_LO_T0)) continue;
	  
	    const int J = J_tab(i);
	  
	    const int index_sa = index_sa_tab(i);
	    const int index_sb = index_sb_tab(i);
	    const int index_sc = index_sc_tab(i);
	    const int index_sd = index_sd_tab(i);

	    const double TBME_HO_lab = TBMEs_HO_lab(i , ii);
	  
	    const int na = n_tab(index_sa);
	    const int nb = n_tab(index_sb);
	    const int nc = n_tab(index_sc);
	    const int nd = n_tab(index_sd);
	
	    const int la = l_tab(index_sa);
	    const int lb = l_tab(index_sb);
	    const int lc = l_tab(index_sc);
	    const int ld = l_tab(index_sd);
	
	    const double ja = j_tab(index_sa);
	    const double jb = j_tab(index_sb);
	    const double jc = j_tab(index_sc);
	    const double jd = j_tab(index_sd);
	  
	    const string lj_sa = angular_state (la , ja);
	    const string lj_sb = angular_state (lb , jb);
	    const string lj_sc = angular_state (lc , jc);
	    const string lj_sd = angular_state (ld , jd);
      
	    TBMEs_HO_lab_HO_lab_output << na << lj_sa << " " << nb << lj_sb << " " << nc << lj_sc << " " << nd << lj_sd << " " << J << " " << T << " " << TBME_HO_lab << endl;
	  }
      }

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }



