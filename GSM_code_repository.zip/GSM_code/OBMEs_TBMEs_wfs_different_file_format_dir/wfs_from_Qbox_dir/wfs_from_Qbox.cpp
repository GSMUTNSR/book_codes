
#include "../../numlib/numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace string_routines;

#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    cout << boolalpha;

    const string wfs_file_input_file_name = "Ca48+n.wave";
  
    ifstream wfs_file_input(wfs_file_input_file_name.c_str ());

    file_existence_check (wfs_file_input_file_name , wfs_file_input);
  
    const enum particle_type particle = NEUTRON;
  
    const double R_max = 25;

    const double step = 0.1;

    const unsigned int N_points = make_uns_int (R_max/step) + 1;
    
    class array<double> r_tab(N_points);
  
    for (unsigned int ii = 0 ; ii < N_points ; ii++) r_tab(ii) = ii*step;
  
    unsigned int N_wfs = 0;
  
    wfs_file_input >> N_wfs;

    double kinetic_factor_inv = 0.0;
  
    wfs_file_input >> kinetic_factor_inv;

    const double kinetic_factor = 1.0/kinetic_factor_inv;
  
    class array<bool> S_matrix_pole_tab(N_wfs);
  
    class array<int> n_tab(N_wfs);

    class array<int> l_tab(N_wfs);

    class array<double> j_tab(N_wfs);
  
    class array<complex<double> > E_tab(N_wfs); 
 
    class array<complex<double> > k_tab(N_wfs);

    class array<class array<complex<double> > > wf_tabs(N_wfs);

    int nmax = 0;

    int lmax = 0;
  
    for (unsigned int i = 0 ; i < N_wfs ; i++)
      {
	int particle_int = 0;
      
	unsigned int index = 0;

	int n = 0;

	int l = 0;

	int two_j = 0;

	double Re_E = 0.0;
	double Im_E = 0.0;
            
	wfs_file_input >> particle_int >> index >> n >> l >> two_j >> Re_E >> Im_E;

	const bool S_matrix_pole = (particle_int != 1);
      
	const double j = 0.5*two_j;
      
	nmax = max (nmax , l);
	lmax = max (lmax , l);
      
	S_matrix_pole_tab(i) = S_matrix_pole;
      
	n_tab(i) = n;
	l_tab(i) = l;
      
	j_tab(i) = j;
      
	const complex<double> E(Re_E , Im_E);
      
	const complex<double> k = sqrt_mod (kinetic_factor*E);

	E_tab(i) = E;
	k_tab(i) = k;
	  
	class array<complex<double> > &wf_tab = wf_tabs(i);

	wf_tab.allocate (N_points);

	wf_tab(0) = 0.0;
      
	for (unsigned int ii = 1 ; ii < N_points ; ii++)
	  {
	    double Re_wf_r = 0.0;
	    double Im_wf_r = 0.0;

	    wfs_file_input >> Re_wf_r >> Im_wf_r;

	    const complex<double> wf_r(Re_wf_r , Im_wf_r);

	    wf_tab(ii) = wf_r;
	  }
      
	if (S_matrix_pole)
	  cout << particle << " " << n << angular_state (l , j) << " pole read" << endl;
	else
	  cout << particle << " " << n << angular_state (l , j) << " scattering read" << endl;
      }

    cout << endl;
  
    for (unsigned int i = 0 ; i < N_wfs ; i++)
      {
	const bool S_matrix_pole = S_matrix_pole_tab(i);
      
	const int n = n_tab(i);

	const int l = l_tab(i);
      
	const double j = j_tab(i);

	const complex<double> k = k_tab(i);
      
	const string wf_file_name = "Qbox_wf_" + make_string<enum particle_type> (particle) + "_" + make_string<int> (n) + angular_state_for_file_name (l , j) + ".dat";

	ofstream wf_file_output(wf_file_name.c_str ());

	wf_file_output << boolalpha;
  
	wf_file_output.precision (15);

	wf_file_output << R_max << " " << kinetic_factor << " " << S_matrix_pole << " " << k << endl;
    
	const class array<complex<double> > &wf_tab = wf_tabs(i);
            
	for (unsigned int ii = 0 ; ii < N_points ; ii++)
	  {
	    const double r = r_tab(ii);

	    const complex<double> wf_r = wf_tab(ii);
	  
	    const double Re_wf_r = real (wf_r);
	    const double Im_wf_r = imag (wf_r);
	  
	    wf_file_output << r << " " << Re_wf_r << " " << Im_wf_r << endl;
	  }

	cout << wf_file_name << " stored" << endl;
      }

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }



