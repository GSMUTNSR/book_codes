
#include "../../numlib/numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace string_routines;

#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);
  
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    //const string OBMEs_file_input_file_name = "ekk_2nd_-20_k-n-d3_pipj_n30_test2_n2lo-opt_N11_hw20_O22A22.sp";

    const string OBMEs_file_input_file_name = "Ca48_pfgd_H+B.sp";
  
    ifstream OBMEs_file_input(OBMEs_file_input_file_name.c_str ());
  
    file_existence_check (OBMEs_file_input_file_name , OBMEs_file_input);
  
    unsigned int N_sp = 0;
  
    OBMEs_file_input >> N_sp;
  
    class array<int> n_tab(N_sp);

    class array<int> l_tab(N_sp);
  
    class array<enum particle_type> particle_tab(N_sp);

    class array<double> j_tab(N_sp);

    class array<complex<double> > OBMEs(N_sp , N_sp);

    for (unsigned int i = 0 ; i < N_sp ; i++)
      {
	unsigned int dummy_uns_int = 0;

	unsigned int index = 0;
      
	int n = 0;

	int l = 0;

	int two_j = 0;

	int two_tz = 0;

	double dummy_double = 0;
      
	OBMEs_file_input >> index >> dummy_uns_int >> dummy_uns_int >> dummy_uns_int >> n >> l >> two_j >> two_tz >> dummy_double >> dummy_double;

	index--;
      
	n_tab(index) = n;
	l_tab(index) = l;
      
	j_tab(index) = 0.5*two_j;

	particle_tab(index) = (two_tz == -1) ? (PROTON) : (NEUTRON);
      }
  
    for (unsigned int i = 0 ; i < N_sp ; i++)
      for (unsigned int ii = i ; ii < N_sp ; ii++)
	{
	  unsigned int index_i  = 0;
	  unsigned int index_ii = 0;

	  double Re_OBME = 0.0;
	  double Im_OBME = 0.0;
      
	  OBMEs_file_input >> index_i >> index_ii >> Re_OBME >> Im_OBME;
	
	  index_i--;
	  index_ii--;

	  const complex<double> OBME(Re_OBME , Im_OBME);
	
	  OBMEs(index_i , index_ii) = OBMEs(index_ii , index_i) = OBME;	
	}

    ofstream OBMEs_prot_file_output("OBMEs_proton_fit.dat");
    ofstream OBMEs_neut_file_output("OBMEs_neutron_fit.dat");

    OBMEs_prot_file_output.precision (15);
    OBMEs_neut_file_output.precision (15);
  
    for (unsigned int i = 0 ; i < N_sp ; i++)
      for (unsigned int ii = 0 ; ii < N_sp ; ii++)
	{
	  const int n_i = n_tab(i);
	  const int l_i = l_tab(i);
	
	  const double j_i = j_tab(i);

	  const enum particle_type particle_i = particle_tab(i);
	
	  const int n_ii = n_tab(ii);
	  const int l_ii = l_tab(ii);
	
	  const double j_ii = j_tab(ii);
	
	  const enum particle_type particle_ii = particle_tab(ii);

	  const complex<double> OBME = OBMEs(i , ii);

	  const string lj_i  = angular_state (l_i  , j_i);	
	  const string lj_ii = angular_state (l_ii , j_ii);

	  if ((particle_i == PROTON ) && (particle_ii == PROTON )) OBMEs_prot_file_output << n_i << lj_i << " " << n_ii << lj_ii << " " << OBME << endl;
	  if ((particle_i == NEUTRON) && (particle_ii == NEUTRON)) OBMEs_neut_file_output << n_i << lj_i << " " << n_ii << lj_ii << " " << OBME << endl;
	}

    //const string TBMEs_file_input_file_name = "ekk_2nd_-20_k-n-d3_pipj_n30_test2_n2lo-opt_N11_hw20_O22A22.int";
      
    const string TBMEs_file_input_file_name = "Ca48_pfgd_H+B.int";
  
    ifstream TBMEs_file_input(TBMEs_file_input_file_name.c_str ());
  
    file_existence_check (TBMEs_file_input_file_name , TBMEs_file_input);

    ofstream TBMEs_pp_file_output("TBMEs_pp_fit");
    ofstream TBMEs_nn_file_output("TBMEs_nn_fit");
    ofstream TBMEs_pn_file_output("TBMEs_pn_fit");
  
    TBMEs_pp_file_output.precision (15);
    TBMEs_nn_file_output.precision (15);
    TBMEs_pn_file_output.precision (15);
  
    unsigned int N_TBMEs = 0;
    
    TBMEs_file_input >> N_TBMEs;
  
    class array<int> index_sa_tab(N_TBMEs) , index_sc_tab(N_TBMEs);
    class array<int> index_sb_tab(N_TBMEs) , index_sd_tab(N_TBMEs);
  
    class array<int> J_tab(N_TBMEs);

    class array<complex<double> > TBMEs(N_TBMEs);

    for (unsigned int i = 0 ; i < N_TBMEs ; i++)
      {
	unsigned int index_sa = 0 , index_sc = 0;
	unsigned int index_sb = 0 , index_sd = 0;

	int J = 0;

	double Re_TBME = 0.0;
	double Im_TBME = 0.0; 
      
	TBMEs_file_input >> index_sa >> index_sb >> index_sc >> index_sd >> J >> Re_TBME >> Im_TBME;

	index_sa--;
	index_sb--;
	index_sc--;
	index_sd--;
      
	const int na = n_tab(index_sa) , nc = n_tab(index_sc);
	const int nb = n_tab(index_sb) , nd = n_tab(index_sd);
	
	const int la = l_tab(index_sa) , lc = l_tab(index_sc);
	const int lb = l_tab(index_sb) , ld = l_tab(index_sd);
	
	const double ja = j_tab(index_sa) , jc = j_tab(index_sc);
	const double jb = j_tab(index_sb) , jd = j_tab(index_sd);

	const enum particle_type particle_a = particle_tab(index_sa) , particle_c = particle_tab(index_sc);
	const enum particle_type particle_b = particle_tab(index_sb) , particle_d = particle_tab(index_sd);

	const string lj_sa = angular_state (la , ja) , lj_sc = angular_state (lc , jc);
	const string lj_sb = angular_state (lb , jb) , lj_sd = angular_state (ld , jd);

	const complex<double> TBME(Re_TBME , Im_TBME);
	
	if ((particle_a == PROTON) && (particle_b == PROTON) && (particle_c == PROTON) && (particle_d == PROTON))
	  TBMEs_pp_file_output << J << " " << na << lj_sa << " " << nb << lj_sb << " " << nc << lj_sc << " " << nd << lj_sd << " " << TBME << endl;
      
	if ((particle_a == NEUTRON) && (particle_b == NEUTRON) && (particle_c == NEUTRON) && (particle_d == NEUTRON))
	  TBMEs_nn_file_output << J << " " << na << lj_sa << " " << nb << lj_sb << " " << nc << lj_sc << " " << nd << lj_sd << " " << TBME << endl;
      
	if ((particle_a == PROTON) && (particle_b == NEUTRON) && (particle_c == PROTON) && (particle_d == NEUTRON))
	  TBMEs_pn_file_output << J << " " << na << lj_sa << " " << nb << lj_sb << " " << nc << lj_sc << " " << nd << lj_sd << " " << TBME << endl;
      }

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }



