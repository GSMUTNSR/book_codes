
#include "../../numlib/numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace string_routines;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();
    
    const string TBMEs_file_input_file_name = "klo_n8hw20t00xpn.tbme";

    ifstream TBMEs_file_input(TBMEs_file_input_file_name.c_str ());
    
    TBMEs_file_input.precision (15);
    
    file_existence_check (TBMEs_file_input_file_name , TBMEs_file_input);
  
    ofstream TBMEs_file_output("v2body_HO_lab.dat");
  
    TBMEs_file_output.precision (15);
    
    const unsigned int N_TBMEs = (elements_number<double> (TBMEs_file_input_file_name) - 3)/14;
      
    int nmax = 0;

    TBMEs_file_input >> nmax;

    double hbar_omega = 0.0;

    TBMEs_file_input >> hbar_omega;

    const double m = 1.00797166422552;
    
    const double b_lab = 1.4399830;

    const double hbar_omega_test = HO_wave_functions::hbar_omega_calc (false , 0.0 , m , b_lab);

    if (abs (hbar_omega - hbar_omega_test) > precision) error_message_print_abort ("Either b_lab or m is wrong.");

    double theta_radians = 0.0;

    TBMEs_file_input >> theta_radians;

    TBMEs_file_output << b_lab << " " << theta_radians << endl;

    class array<unsigned short int> sa_tab(N_TBMEs) , sc_tab(N_TBMEs);
    class array<unsigned short int> sb_tab(N_TBMEs) , sd_tab(N_TBMEs);

    class array<unsigned short int> J_tab(N_TBMEs);
    
    class array<double> Re_TBMEs_nuclear(N_TBMEs) , Re_TBMEs_Coulomb(N_TBMEs);
    class array<double> Im_TBMEs_nuclear(N_TBMEs) , Im_TBMEs_Coulomb(N_TBMEs);
        
    double dummy = 0.0;
	
    for (unsigned int i = 0 ; i < N_TBMEs ; i++)
      TBMEs_file_input >> sa_tab(i) >> sb_tab(i) >> sc_tab(i) >> sd_tab(i) >> J_tab(i) >> dummy >> Re_TBMEs_Coulomb(i) >> Im_TBMEs_Coulomb(i) >> Re_TBMEs_nuclear(i) >> Im_TBMEs_nuclear(i) >> dummy >> dummy >> dummy >> dummy;

    sa_tab -= 1;
    sb_tab -= 1;
    sc_tab -= 1;
    sd_tab -= 1;
    
    const unsigned int sa_max = sa_tab.max () , sc_max = sc_tab.max ();
    const unsigned int sb_max = sb_tab.max () , sd_max = sd_tab.max ();

    const unsigned int index_ab_max = max (sa_max , sb_max);
    const unsigned int index_cd_max = max (sc_max , sd_max);

    const unsigned int index_max = max (index_ab_max , index_cd_max);

    const unsigned int index_number = index_max + 1;

    const unsigned int index_prot_number = index_number/2;
        
    const unsigned int index_prot_max = index_prot_number - 1;

    class array<int> n_tab(index_number);

    class array<int> l_tab(index_number);
    
    class array<int> charge_tab(index_number);

    class array<double> j_tab(index_number);

    int N = 0;
    
    unsigned int index_prot = 0;
    	
    while (index_prot <= index_prot_max)
      {
	const int binary_parity_N = N%2;
	
	for (int i = 0 ; (i <= N) && (index_prot <= index_prot_max) ; i++)
	  {
	    const unsigned int index_neut = index_prot + index_prot_number;

	    const double j = i + 0.5;
	    	    
	    const int l = (i%2 == binary_parity_N) ? (i) : (i + 1);

	    const int n = (N - l)/2;

	    n_tab(index_prot) = n_tab(index_neut) = n;
	    l_tab(index_prot) = l_tab(index_neut) = l;
	    j_tab(index_prot) = j_tab(index_neut) = j;

	    charge_tab(index_prot) = 1;
	    charge_tab(index_neut) = 0;

	    index_prot++;
	  }

	N++;
      }
      
    for (unsigned int i = 0 ; i < N_TBMEs ; i++)
      {
	const unsigned int sa = sa_tab(i) , sc = sc_tab(i);
	const unsigned int sb = sb_tab(i) , sd = sd_tab(i);
            
	const int na = n_tab(sa) , nc = n_tab(sc);
	const int nb = n_tab(sb) , nd = n_tab(sd);
	
	const int la = l_tab(sa) , lc = l_tab(sc);
	const int lb = l_tab(sb) , ld = l_tab(sd);
	
	const double ja = j_tab(sa) , jc = j_tab(sc);
	const double jb = j_tab(sb) , jd = j_tab(sd);
	      
	const string lj_sa = angular_state (la , ja) , lj_sc = angular_state (lc , jc);
	const string lj_sb = angular_state (lb , jb) , lj_sd = angular_state (ld , jd);
	      	
	const int J = J_tab(i);

	const bool is_it_pp = ((charge_tab(sa) == 1) && (charge_tab(sb) == 1) && (charge_tab(sc) == 1) && (charge_tab(sd) == 1));
	const bool is_it_nn = ((charge_tab(sa) == 0) && (charge_tab(sb) == 0) && (charge_tab(sc) == 0) && (charge_tab(sd) == 0));
	const bool is_it_pn = ((charge_tab(sa) == 1) && (charge_tab(sb) == 0) && (charge_tab(sc) == 1) && (charge_tab(sd) == 0));

	if (!is_it_pp && !is_it_nn && !is_it_pn) error_message_print_abort ("TBME must pp, nn or pn.");

	const double Re_TBME_nuclear = Re_TBMEs_nuclear(i) , Re_TBME_Coulomb = Re_TBMEs_Coulomb(i);
	const double Im_TBME_nuclear = Im_TBMEs_nuclear(i) , Im_TBME_Coulomb = Im_TBMEs_Coulomb(i);

	const complex<double> TBME_nuclear(Re_TBME_nuclear , Im_TBME_nuclear);

	const complex<double> TBME_Coulomb(Re_TBME_Coulomb , Im_TBME_Coulomb);

	const complex<double> TBME = (is_it_pp) ? (TBME_nuclear + TBME_Coulomb) : (TBME_nuclear);

	if (TBME != 0.0)
	  {
	    if (is_it_pp) TBMEs_file_output << na << lj_sa << " " << nb << lj_sb << " " << nc << lj_sc << " " << nd << lj_sd << " " << J << " " << -1 << " " << real (TBME) << " " << imag (TBME) << endl;
	    if (is_it_nn) TBMEs_file_output << na << lj_sa << " " << nb << lj_sb << " " << nc << lj_sc << " " << nd << lj_sd << " " << J << " " <<  1 << " " << real (TBME) << " " << imag (TBME) << endl;
	    if (is_it_pn) TBMEs_file_output << na << lj_sa << " " << nb << lj_sb << " " << nc << lj_sc << " " << nd << lj_sd << " " << J << " " <<  0 << " " << real (TBME) << " " << imag (TBME) << endl;
	  }
      }

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }



