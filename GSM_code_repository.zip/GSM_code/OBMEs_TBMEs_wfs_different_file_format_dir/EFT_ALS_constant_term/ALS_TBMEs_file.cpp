#include "../../numlib/numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace string_routines;

using namespace Wigner_signs;

using namespace angular_matrix_elements;

void V5_EFT_TBMEs_jj_JT_quantum_numbers_tabs_read (
						   const string V5_EFT_TBMEs_jj_JT_input_file_name ,
						   double &b_lab ,
						   class array<int> &na_tab , class array<int> &la_tab , class array<double> &ja_tab ,
						   class array<int> &nb_tab , class array<int> &lb_tab , class array<double> &jb_tab ,
						   class array<int> &nc_tab , class array<int> &lc_tab , class array<double> &jc_tab ,
						   class array<int> &nd_tab , class array<int> &ld_tab , class array<double> &jd_tab ,
						   class array<int> &J_tab ,
						   class array<int> &T_tab ,
						   class array<double> &V5_EFT_TBMEs_jj_JT_1D)
{    
  const unsigned int TBMEs_number = V5_EFT_TBMEs_jj_JT_1D.dimension (0);
    
  ifstream V5_EFT_TBMEs_jj_input(V5_EFT_TBMEs_jj_JT_input_file_name.c_str ());
  
  file_existence_check (V5_EFT_TBMEs_jj_JT_input_file_name , V5_EFT_TBMEs_jj_input);
  
  string sa , sb;
  string sc , sd;
  
  V5_EFT_TBMEs_jj_input >> b_lab;
    
  for (unsigned int i = 0 ; i < TBMEs_number ; i++)
    {
      V5_EFT_TBMEs_jj_input >> sa >> sb >> sc >> sd >> J_tab(i) >> T_tab(i) >> V5_EFT_TBMEs_jj_JT_1D(i);
      
      na_tab(i) = determine_n (sa) , la_tab(i) = determine_l (sa) , ja_tab(i) = determine_j (sa);
      nb_tab(i) = determine_n (sb) , lb_tab(i) = determine_l (sb) , jb_tab(i) = determine_j (sb);
      nc_tab(i) = determine_n (sc) , lc_tab(i) = determine_l (sc) , jc_tab(i) = determine_j (sc);
      nd_tab(i) = determine_n (sd) , ld_tab(i) = determine_l (sd) , jd_tab(i) = determine_j (sd);      

      check_partial_wave_nucleon (la_tab(i) , ja_tab(i));
      check_partial_wave_nucleon (lb_tab(i) , jb_tab(i));
      check_partial_wave_nucleon (lc_tab(i) , jc_tab(i));
      check_partial_wave_nucleon (ld_tab(i) , jd_tab(i));
    }
}




unsigned int N_nlj_calc (const int nmax , const int lmax)
{
  unsigned int N_nlj = 0;
  
  for (int n = 0 ; n <= nmax ; n++)
    for (int l = 0 ; l <= lmax ; l++)
      for (unsigned int ij = (l == 0) ? (1) : (0) ; ij <= 1 ; ij++)
	N_nlj++;

  return N_nlj;
}




void nl_nlj_indices_calc (
			  class array<unsigned int> &nl_indices ,
			  class array<unsigned int> &nlj_indices)
{
  const int nmax = nlj_indices.dimension (0) - 1;
  const int lmax = nlj_indices.dimension (1) - 1;

  unsigned int nl_index  = 0;    
  unsigned int nlj_index = 0;
    
  nl_indices  = OUT_OF_RANGE;    
  nlj_indices = OUT_OF_RANGE;
    
  for (int n = 0 ; n <= nmax ; n++)
    for (int l = 0 ; l <= lmax ; l++)
      {
	nl_indices(n , l) = nl_index++;
	  
	for (unsigned int ij = (l == 0) ? (1) : (0) ; ij <= 1 ; ij++) nlj_indices(n , l , ij) = nlj_index++;
      }    
}




void V5_EFT_TBMEs_jj_J_fill (
			     const class array<int> &na_tab , const class array<int> &la_tab , const class array<double> &ja_tab ,
			     const class array<int> &nb_tab , const class array<int> &lb_tab , const class array<double> &jb_tab ,
			     const class array<int> &nc_tab , const class array<int> &lc_tab , const class array<double> &jc_tab ,
			     const class array<int> &nd_tab , const class array<int> &ld_tab , const class array<double> &jd_tab ,
			     const class array<int> &J_tab ,
			     const class array<int> &T_tab ,
			     const class array<double> &V5_EFT_TBMEs_jj_JT_1D ,
			     const class array<unsigned int> &nlj_indices ,
			     class array<double> &V5_EFT_TBMEs_jj_J)
{
  // One has : S[ab] = S[cd] = 1 for V5_EFT TBMEs
  
  const unsigned int TBMEs_number = V5_EFT_TBMEs_jj_JT_1D.dimension (0);
    
  V5_EFT_TBMEs_jj_J = 0.0;
    
  for (unsigned int i = 0 ; i < TBMEs_number ; i++)
    {      
      const int na = na_tab(i) , nb = nb_tab(i) , la = la_tab(i) , lb = lb_tab(i);
      const int nc = nc_tab(i) , nd = nd_tab(i) , lc = lc_tab(i) , ld = ld_tab(i);
	  
      const double ja = ja_tab(i) , jb = jb_tab(i);
      const double jc = jc_tab(i) , jd = jd_tab(i);
      
      const int J = J_tab(i);
      const int T = T_tab(i);
      
      const int ija = (ja > la) ? (1) : (0) , ijb = (jb > lb) ? (1) : (0);
      const int ijc = (jc > lc) ? (1) : (0) , ijd = (jd > ld) ? (1) : (0);
  
      const unsigned int sa = nlj_indices(na , la , ija) , sb = nlj_indices(nb , lb , ijb);
      const unsigned int sc = nlj_indices(nc , lc , ijc) , sd = nlj_indices(nd , ld , ijd);
      
      const double V5_EFT_TBME_jj_JT = V5_EFT_TBMEs_jj_JT_1D(i);
      
      const int phase_ab_swap = minus_one_pow (ja + jb - J - T);
      const int phase_cd_swap = minus_one_pow (jc + jd - J - T);
      
      V5_EFT_TBMEs_jj_J(sa , sb , sc , sd , J , T) = V5_EFT_TBMEs_jj_J(sc , sd , sa , sb , J , T) = V5_EFT_TBME_jj_JT;
      V5_EFT_TBMEs_jj_J(sb , sa , sc , sd , J , T) = V5_EFT_TBMEs_jj_J(sc , sd , sb , sa , J , T) = V5_EFT_TBME_jj_JT*phase_ab_swap;
      V5_EFT_TBMEs_jj_J(sa , sb , sd , sc , J , T) = V5_EFT_TBMEs_jj_J(sd , sc , sa , sb , J , T) = V5_EFT_TBME_jj_JT*phase_cd_swap;
      V5_EFT_TBMEs_jj_J(sb , sa , sd , sc , J , T) = V5_EFT_TBMEs_jj_J(sd , sc , sb , sa , J , T) = V5_EFT_TBME_jj_JT*phase_ab_swap*phase_cd_swap;
    }
}

void V5_EFT_TBMEs_LSJ_calc (
			    const class array<unsigned int> &nl_indices ,
			    const class array<unsigned int> &nlj_indices ,
			    const class array<double> &four_js_recoupling_table ,
			    const class array<double> &V5_EFT_TBMEs_jj_J ,
			    class array<double> &V5_EFT_TBMEs_LSJ)
{
  const int nmax = nlj_indices.dimension (0) - 1;
  const int lmax = nlj_indices.dimension (1) - 1;
  		
  V5_EFT_TBMEs_LSJ = 0.0;

  for (int la = 0 ; la <= lmax ; la++)
    for (int lb = 0 ; lb <= lmax ; lb++)
      for (int lc = 0 ; lc <= lmax ; lc++)
	for (int ld = 0 ; ld <= lmax ; ld++)
	  {
	    if ((la + lb)%2 == (lc + ld)%2)
	      {			    
		const int Lmin_ab = abs (la - lb) , Lmax_ab = la + lb;
		const int Lmin_cd = abs (lc - ld) , Lmax_cd = lc + ld;

		for (int Lab = Lmin_ab ; Lab <= Lmax_ab ; Lab++)
		  for (int Lcd = Lmin_cd ; Lcd <= Lmax_cd ; Lcd++)
		    {
		      const int Jmin_LS_ab = abs (Lab - 1) , Jmax_LS_ab = Lab + 1;
		      const int Jmin_LS_cd = abs (Lcd - 1) , Jmax_LS_cd = Lcd + 1;

		      const int Jmin_LS = max (Jmin_LS_ab , Jmin_LS_cd);
		      const int Jmax_LS = min (Jmax_LS_ab , Jmax_LS_cd);
		      
		      for (int na = 0 ; na <= nmax ; na++)
			for (int nb = 0 ; nb <= nmax ; nb++)
			  for (int nc = 0 ; nc <= nmax ; nc++)
			    for (int nd = 0 ; nd <= nmax ; nd++)
			      {
				const unsigned int nl_index_a = nl_indices(na , la) , nl_index_b = nl_indices(nb , lb); 
				const unsigned int nl_index_c = nl_indices(nc , lc) , nl_index_d = nl_indices(nd , ld);
						
				for (int J = Jmin_LS ; J <= Jmax_LS ; J++)
				  {
				    if (J == Lcd)
				      {
					const int Lab_index = J - Lab + 1;
				    				    
					for (int T = 0 ; T <= 1 ; T++)
					  {
					    double V5_EFT_TBME_LSJ = 0.0;

					    for (unsigned int ija = (la == 0) ? (1) : (0) ; ija <= 1 ; ija++)
					      for (unsigned int ijb = (lb == 0) ? (1) : (0) ; ijb <= 1 ; ijb++)
						for (unsigned int ijc = (lc == 0) ? (1) : (0) ; ijc <= 1 ; ijc++)
						  for (unsigned int ijd = (ld == 0) ? (1) : (0) ; ijd <= 1 ; ijd++)
						    {
						      const int ja_minus_half = (ija == 1) ? (la) : (la - 1) , jb_minus_half = (ijb == 1) ? (lb) : (lb - 1);
						      const int jc_minus_half = (ijc == 1) ? (lc) : (lc - 1) , jd_minus_half = (ijd == 1) ? (ld) : (ld - 1);

						      const int Jmin_ab = abs (ja_minus_half - jb_minus_half) , Jmax_ab = ja_minus_half + jb_minus_half + 1;
						      const int Jmin_cd = abs (jc_minus_half - jd_minus_half) , Jmax_cd = jc_minus_half + jd_minus_half + 1;
					      
						      const int Jmin_jj = max (Jmin_ab , Jmin_cd);
						      const int Jmax_jj = min (Jmax_ab , Jmax_cd);

						      if ((J >= Jmin_jj) && (J <= Jmax_jj))
							{
							  const unsigned int sa = nlj_indices(na , la , ija) , sb = nlj_indices(nb , lb , ijb);
							  const unsigned int sc = nlj_indices(nc , lc , ijc) , sd = nlj_indices(nd , ld , ijd);
						
							  const double four_js_recoupling_ab = four_js_recoupling_table(la , ija , lb , ijb , Lab , 1 , J);
							  const double four_js_recoupling_cd = four_js_recoupling_table(lc , ijc , ld , ijd , Lcd , 1 , J);

							  const double V5_EFT_TBME_jj_J = V5_EFT_TBMEs_jj_J(sa , sb , sc , sd , J , T);
						
							  V5_EFT_TBME_LSJ += four_js_recoupling_ab*four_js_recoupling_cd*V5_EFT_TBME_jj_J;
							}
						    }
				    
					    V5_EFT_TBMEs_LSJ(nl_index_a , nl_index_b , nl_index_c , nl_index_d , Lab_index , Lcd , T) = V5_EFT_TBME_LSJ;
					  }
				      }
				  }
			      }    
		    }
	      }
	  }
}




void V8_EFT_TBMEs_LSJ_calc (
			    const class array<unsigned int> &nl_indices ,
			    const class array<double> &V5_EFT_TBMEs_LSJ ,
			    class array<double> &V8_EFT_TBMEs_LSJ)
{
  // One has : S[ab] = S[cd] = 1 for V5_EFT TBMEs and S[ab] = 1, S[cd] = 0 for V8_EFT TBMEs
  
  const int nmax = nl_indices.dimension (0) - 1;
  const int lmax = nl_indices.dimension (1) - 1;

  const int Lmax = V5_EFT_TBMEs_LSJ.dimension (5) - 1;
  
  const int Lmax_plus_one = Lmax + 1;  
    
  const double TBME_sigma_1_plus_sigma_2_reduced = 2.0*OBME_j_reduced (1);
  
  const double TBME_sigma_1_minus_sigma_2_reduced = TBME_sigma_1_minus_sigma_2_reduced_calc (0.5 , 0.5 , 1 , 0);
		
  const double TBMEs_sigma_1_sigma_2_reduced_ratio = TBME_sigma_1_minus_sigma_2_reduced/TBME_sigma_1_plus_sigma_2_reduced;

  class array<double> TBMEs_sigma_1_sigma_2_reduced_ratio_angular_factor_tab(3 , Lmax_plus_one);

  TBMEs_sigma_1_sigma_2_reduced_ratio_angular_factor_tab = 0.0;
  
  for (int Lab = 0 ; Lab <= Lmax ; Lab++)
    for (int Lcd = 0 ; Lcd <= Lmax ; Lcd++)
      {				    
	const int Jmin_LS_ab = abs (Lab - 1);
	const int Jmax_LS_ab =      Lab + 1;

	const int J = Lcd;
		      
	if ((J >= Jmin_LS_ab) && (J <= Jmax_LS_ab))
	  {
	    const int Lab_index = J - Lab + 1;
			    
	    const double recoupling_terms_spins_S_Sp_10 = Oa_scalar_Ob_ME_calc (1 , Lab , 1 , J , Lcd , 0 , J , 1.0 , 1.0);
	    const double recoupling_terms_spins_S_Sp_11 = Oa_scalar_Ob_ME_calc (1 , Lab , 1 , J , Lcd , 1 , J , 1.0 , 1.0);
			  
	    const double angular_factor = recoupling_terms_spins_S_Sp_10/recoupling_terms_spins_S_Sp_11;

	    TBMEs_sigma_1_sigma_2_reduced_ratio_angular_factor_tab(Lab_index , Lcd) = TBMEs_sigma_1_sigma_2_reduced_ratio*angular_factor;
	  }
      }
		
  V8_EFT_TBMEs_LSJ = 0.0;

  for (int la = 0 ; la <= lmax ; la++)
    for (int lb = 0 ; lb <= lmax ; lb++)
      for (int lc = 0 ; lc <= lmax ; lc++)
	for (int ld = 0 ; ld <= lmax ; ld++)
	  {
	    if ((la + lb)%2 == (lc + ld)%2)
	      {			 		    
		const int Lmin_ab = abs (la - lb) , Lmax_ab = la + lb;
		const int Lmin_cd = abs (lc - ld) , Lmax_cd = lc + ld;
  
		for (int Lab = Lmin_ab ; Lab <= Lmax_ab ; Lab++)
		  for (int Lcd = Lmin_cd ; Lcd <= Lmax_cd ; Lcd++)
		    {				
		      const int Jmin_LS_ab = abs (Lab - 1);
		      const int Jmax_LS_ab =      Lab + 1;

		      const int J = Lcd;
		      
		      if ((J >= Jmin_LS_ab) && (J <= Jmax_LS_ab))
			{
			  const int Lab_index = J - Lab + 1;

			  const double TBMEs_sigma_1_sigma_2_reduced_ratio_angular_factor = TBMEs_sigma_1_sigma_2_reduced_ratio_angular_factor_tab(Lab_index , Lcd);
			    
			  for (int na = 0 ; na <= nmax ; na++)
			    for (int nb = 0 ; nb <= nmax ; nb++)
			      for (int nc = 0 ; nc <= nmax ; nc++)
				for (int nd = 0 ; nd <= nmax ; nd++)
				  {
				    const unsigned int nl_index_a = nl_indices(na , la) , nl_index_b = nl_indices(nb , lb); 
				    const unsigned int nl_index_c = nl_indices(nc , lc) , nl_index_d = nl_indices(nd , ld);

				    for (int Tab = 0 ; Tab <= 1 ; Tab++)
				      {					
					const double V5_EFT_TBME_LSJ = V5_EFT_TBMEs_LSJ(nl_index_a , nl_index_b , nl_index_c , nl_index_d , Lab_index , Lcd , Tab);
					      
					const double V8_EFT_TBME_LSJ = TBMEs_sigma_1_sigma_2_reduced_ratio_angular_factor*V5_EFT_TBME_LSJ;
					      
					V8_EFT_TBMEs_LSJ(nl_index_a , nl_index_b , nl_index_c , nl_index_d , Lab_index , Lcd , Tab) = V8_EFT_TBME_LSJ;
				      }
				  }
			}
		    }
	      }
	  }
}





void V8_EFT_TBMEs_jj_J_calc (
			     const class array<unsigned int> &nl_indices ,
			     const class array<unsigned int> &nlj_indices ,
			     const class array<double> &four_js_recoupling_table ,
			     const class array<double> &V8_EFT_TBMEs_LSJ ,
			     class array<double> &V8_EFT_TBMEs_jj_J)
{
  const int nmax = nlj_indices.dimension (0) - 1;
  const int lmax = nlj_indices.dimension (1) - 1;
  		
  V8_EFT_TBMEs_jj_J = 0.0;

  for (int la = 0 ; la <= lmax ; la++)
    for (int lb = 0 ; lb <= lmax ; lb++)
      for (int lc = 0 ; lc <= lmax ; lc++)
	for (int ld = 0 ; ld <= lmax ; ld++)
	  {
	    if ((la + lb)%2 == (lc + ld)%2)
	      {
		const int Lmin_ab = abs (la - lb) , Lmax_ab = la + lb;
		const int Lmin_cd = abs (lc - ld) , Lmax_cd = lc + ld;
		
		for (unsigned int ija = (la == 0) ? (1) : (0) ; ija <= 1 ; ija++)
		  for (unsigned int ijb = (lb == 0) ? (1) : (0) ; ijb <= 1 ; ijb++)
		    for (unsigned int ijc = (lc == 0) ? (1) : (0) ; ijc <= 1 ; ijc++)
		      for (unsigned int ijd = (ld == 0) ? (1) : (0) ; ijd <= 1 ; ijd++)
			{
			  const int ja_minus_half = (ija == 1) ? (la) : (la - 1) , jb_minus_half = (ijb == 1) ? (lb) : (lb - 1);
			  const int jc_minus_half = (ijc == 1) ? (lc) : (lc - 1) , jd_minus_half = (ijd == 1) ? (ld) : (ld - 1);

			  const int Jmin_ab = abs (ja_minus_half - jb_minus_half) , Jmax_ab = ja_minus_half + jb_minus_half + 1;
			  const int Jmin_cd = abs (jc_minus_half - jd_minus_half) , Jmax_cd = jc_minus_half + jd_minus_half + 1;
					      
			  const int Jmin_jj = max (Jmin_ab , Jmin_cd);
			  const int Jmax_jj = min (Jmax_ab , Jmax_cd);

			  for (int na = 0 ; na <= nmax ; na++)
			    for (int nb = 0 ; nb <= nmax ; nb++)
			      for (int nc = 0 ; nc <= nmax ; nc++)
				for (int nd = 0 ; nd <= nmax ; nd++)
				  {				
				    const unsigned int nl_index_a = nl_indices(na , la) , nl_index_b = nl_indices(nb , lb); 
				    const unsigned int nl_index_c = nl_indices(nc , lc) , nl_index_d = nl_indices(nd , ld);
						    
				    const unsigned int sa = nlj_indices(na , la , ija) , sb = nlj_indices(nb , lb , ijb);
				    const unsigned int sc = nlj_indices(nc , lc , ijc) , sd = nlj_indices(nd , ld , ijd);
						
				    for (int Tab = 0 ; Tab <= 1 ; Tab++)
				      {
					const int Tcd = (Tab == 0) ? (1) : (0);
					
					for (int J = Jmin_jj ; J <= Jmax_jj ; J++)
					  {					    
					    double V8_EFT_TBME_jj = 0.0;
		
					    for (int Sab = 0 ; Sab <= 1 ; Sab++)
					      for (int Scd = 0 ; Scd <= 1 ; Scd++)
						{
						  if (Sab == Scd) continue;
						    
						  for (int Lab = Lmin_ab ; Lab <= Lmax_ab ; Lab++)
						    for (int Lcd = Lmin_cd ; Lcd <= Lmax_cd ; Lcd++)
						      {				
							const int Jmin_LS_ab = abs (Lab - Sab) , Jmax_LS_ab = Lab + Sab;
							const int Jmin_LS_cd = abs (Lcd - Scd) , Jmax_LS_cd = Lcd + Scd;
						    
							const int Jmin_LS = max (Jmin_LS_ab , Jmin_LS_cd);
							const int Jmax_LS = min (Jmax_LS_ab , Jmax_LS_cd);		      
						
							if ((J >= Jmin_LS) && (J <= Jmax_LS))
							  {				
							    const int Lab_index = J - Lab + 1;
							    const int Lcd_index = J - Lcd + 1;
						    
							    const double four_js_recoupling_ab = four_js_recoupling_table(la , ija , lb , ijb , Lab , Sab , J);
							    const double four_js_recoupling_cd = four_js_recoupling_table(lc , ijc , ld , ijd , Lcd , Scd , J);

							    const double V8_EFT_TBME_LSJ = (Sab == 1)
							      ? (V8_EFT_TBMEs_LSJ(nl_index_a , nl_index_b , nl_index_c , nl_index_d , Lab_index , Lcd , Tab))
							      : (V8_EFT_TBMEs_LSJ(nl_index_c , nl_index_d , nl_index_a , nl_index_b , Lcd_index , Lab , Tcd));
						
							    V8_EFT_TBME_jj += four_js_recoupling_ab*four_js_recoupling_cd*V8_EFT_TBME_LSJ;
							  }
						      }
						}

					    V8_EFT_TBMEs_jj_J(sa , sb , sc , sd , J , Tab) = V8_EFT_TBME_jj;
					  }
				      }
				  }    
			}
	      }
	  }
}




void V8_EFT_TBMEs_jj_J_copy (
			     const double b_lab ,
			     const class array<unsigned int> &nlj_indices ,
			     const class array<double> &V8_EFT_TBMEs_jj_J)
{    
  const int nmax = nlj_indices.dimension (0) - 1;
  const int lmax = nlj_indices.dimension (1) - 1;

  const string V8_EFT_TBMEs_jj_output_file_name = STORAGE_DIR + "v2body_HO_lab_" + make_string<enum FHT_EFT_parameter_type> (V8_SIGMA_Q_VECTOR_K_NLO) + ".dat";
    
  ofstream V8_EFT_TBMEs_jj_output(V8_EFT_TBMEs_jj_output_file_name.c_str ());
    
  V8_EFT_TBMEs_jj_output << b_lab << endl;
    
  for (int la = 0 ; la <= lmax ; la++)
    for (int lb = 0 ; lb <= lmax ; lb++)
      for (int lc = 0 ; lc <= lmax ; lc++)
	for (int ld = 0 ; ld <= lmax ; ld++)
	  {
	    if ((la + lb)%2 == (lc + ld)%2)
	      {
		for (unsigned int ija = (la == 0) ? (1) : (0) ; ija <= 1 ; ija++)
		  for (unsigned int ijb = (lb == 0) ? (1) : (0) ; ijb <= 1 ; ijb++)
		    for (unsigned int ijc = (lc == 0) ? (1) : (0) ; ijc <= 1 ; ijc++)
		      for (unsigned int ijd = (ld == 0) ? (1) : (0) ; ijd <= 1 ; ijd++)
			{
			  const int ja_minus_half = (ija == 1) ? (la) : (la - 1) , jb_minus_half = (ijb == 1) ? (lb) : (lb - 1);
			  const int jc_minus_half = (ijc == 1) ? (lc) : (lc - 1) , jd_minus_half = (ijd == 1) ? (ld) : (ld - 1);

			  const int Jmin_ab = abs (ja_minus_half - jb_minus_half) , Jmax_ab = ja_minus_half + jb_minus_half + 1;
			  const int Jmin_cd = abs (jc_minus_half - jd_minus_half) , Jmax_cd = jc_minus_half + jd_minus_half + 1;
					      
			  const int Jmin_jj = max (Jmin_ab , Jmin_cd);
			  const int Jmax_jj = min (Jmax_ab , Jmax_cd);

			  const double ja = ja_minus_half + 0.5 , jb = jb_minus_half + 0.5;
			  const double jc = jc_minus_half + 0.5 , jd = jd_minus_half + 0.5;
	  
			  const string lj_sa = angular_state (la , ja) , lj_sb = angular_state (lb , jb);
			  const string lj_sc = angular_state (lc , jc) , lj_sd = angular_state (ld , jd);
	    
			  for (int na = 0 ; na <= nmax ; na++)
			    for (int nb = 0 ; nb <= nmax ; nb++)
			      for (int nc = 0 ; nc <= nmax ; nc++)
				for (int nd = 0 ; nd <= nmax ; nd++)
				  {
				    const unsigned int sa = nlj_indices(na , la , ija) , sb = nlj_indices(nb , lb , ijb);
				    const unsigned int sc = nlj_indices(nc , lc , ijc) , sd = nlj_indices(nd , ld , ijd);
						
				    for (int J = Jmin_jj ; J <= Jmax_jj ; J++)
				      for (int Tab = 0 ; Tab <= 1 ; Tab++)
					{
					  const double V8_EFT_TBME_jj_Tab = V8_EFT_TBMEs_jj_J(sa , sb , sc , sd , J , Tab);
					  
					  if (V8_EFT_TBME_jj_Tab != 0.0) V8_EFT_TBMEs_jj_output << na << lj_sa << " " << nb << lj_sb << " " << nc << lj_sc << " " << nd << lj_sd << " " << J << " " << Tab << " " << V8_EFT_TBME_jj_Tab << endl;
					}
				  }
			}
	      }
	  }
}




#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();
          
    const string V5_EFT_TBMEs_jj_JT_input_file_name = STORAGE_DIR + "v2body_HO_lab_" + make_string<enum FHT_EFT_parameter_type> (V5_SIGMA_Q_VECTOR_K_NLO) + ".dat";
  
    const unsigned int V5_EFT_TBMEs_jj_JT_lines_number = lines_number<string> (V5_EFT_TBMEs_jj_JT_input_file_name);
      
    const unsigned int TBMEs_number = V5_EFT_TBMEs_jj_JT_lines_number - 1;

    double b_lab = 0.0;
    
    class array<int> na_tab(TBMEs_number) , la_tab(TBMEs_number) , nb_tab(TBMEs_number) , lb_tab(TBMEs_number);
    class array<int> nc_tab(TBMEs_number) , lc_tab(TBMEs_number) , nd_tab(TBMEs_number) , ld_tab(TBMEs_number);
        
    class array<double> ja_tab(TBMEs_number) , jb_tab(TBMEs_number);
    class array<double> jc_tab(TBMEs_number) , jd_tab(TBMEs_number);

    class array<int> J_tab(TBMEs_number);
    class array<int> T_tab(TBMEs_number);
    
    class array<double> V5_EFT_TBMEs_jj_JT_1D(TBMEs_number);
    
    V5_EFT_TBMEs_jj_JT_quantum_numbers_tabs_read (V5_EFT_TBMEs_jj_JT_input_file_name , b_lab , na_tab , la_tab , ja_tab , nb_tab , lb_tab , jb_tab , nc_tab , lc_tab , jc_tab , nd_tab , ld_tab , jd_tab , J_tab , T_tab , V5_EFT_TBMEs_jj_JT_1D);

    const int nmax = na_tab.max () , nmax_plus_one = nmax + 1;
    const int lmax = la_tab.max () , lmax_plus_one = lmax + 1;
    
    const int Jmin = J_tab.min ();
    const int Jmax = J_tab.max ();

    const int Lmax = 2*lmax;
    
    const int Lmax_plus_one = Lmax + 1;
    const int Jmax_plus_one = Jmax + 1;
    
    const unsigned int N_nl = nmax_plus_one*lmax_plus_one;
        
    const unsigned int N_nlj = N_nlj_calc (nmax , lmax);
    
    class array<unsigned int> nl_indices(nmax_plus_one , lmax_plus_one);
    
    class array<unsigned int> nlj_indices(nmax_plus_one , lmax_plus_one , 2);
    
    nl_nlj_indices_calc (nl_indices , nlj_indices);
        
    class array<double> four_js_recoupling_table(lmax_plus_one , 2 , lmax_plus_one , 2 , Lmax_plus_one , 2 , Jmax_plus_one);
  
    four_js_recoupling_table_calc (Jmin , Jmax , four_js_recoupling_table);
    
    class array<double> V5_EFT_TBMEs_jj_J(N_nlj , N_nlj , N_nlj , N_nlj , Jmax_plus_one , 2);
    class array<double> V8_EFT_TBMEs_jj_J(N_nlj , N_nlj , N_nlj , N_nlj , Jmax_plus_one , 2);
    
    class array<double> V5_EFT_TBMEs_LSJ(N_nl , N_nl , N_nl , N_nl , 3 , Lmax_plus_one , 2);    
    class array<double> V8_EFT_TBMEs_LSJ(N_nl , N_nl , N_nl , N_nl , 3 , Lmax_plus_one , 2);
    
    V5_EFT_TBMEs_jj_J_fill (na_tab , la_tab , ja_tab , nb_tab , lb_tab , jb_tab , nc_tab , lc_tab , jc_tab , nd_tab , ld_tab , jd_tab , J_tab , T_tab , V5_EFT_TBMEs_jj_JT_1D ,  nlj_indices , V5_EFT_TBMEs_jj_J);
    
    V5_EFT_TBMEs_LSJ_calc (nl_indices , nlj_indices , four_js_recoupling_table , V5_EFT_TBMEs_jj_J , V5_EFT_TBMEs_LSJ);
	
    V8_EFT_TBMEs_LSJ_calc (nl_indices , V5_EFT_TBMEs_LSJ , V8_EFT_TBMEs_LSJ);
	
    V8_EFT_TBMEs_jj_J_calc (nl_indices , nlj_indices , four_js_recoupling_table , V8_EFT_TBMEs_LSJ , V8_EFT_TBMEs_jj_J);
	
    V8_EFT_TBMEs_jj_J_copy (b_lab , nlj_indices , V8_EFT_TBMEs_jj_J);
	
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }



