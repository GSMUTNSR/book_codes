
#include "../../numlib/numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace string_routines;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();
    
    const string TBMEs_file_input_file_name = "V_Daejeon16_Jmax6_sq_10shl_hw20_vxx_r4_PNfmt";

    ifstream TBMEs_file_input(TBMEs_file_input_file_name.c_str ());
    
    TBMEs_file_input.precision (15);
    
    file_existence_check (TBMEs_file_input_file_name , TBMEs_file_input);
  
    ofstream TBMEs_file_output("v2body_HO_lab.dat");
  
    TBMEs_file_output.precision (15);
    
    unsigned int N_TBMEs = 0;

    TBMEs_file_input >> N_TBMEs;
    
    class array<unsigned short int> sa_tab(N_TBMEs) , sc_tab(N_TBMEs);
    class array<unsigned short int> sb_tab(N_TBMEs) , sd_tab(N_TBMEs);

    class array<unsigned short int> J_tab(N_TBMEs);
    class array<unsigned short int> T_tab(N_TBMEs);
    
    class array<double> TBMEs_pp_T(N_TBMEs);
    class array<double> TBMEs_nn_T(N_TBMEs);
    class array<double> TBMEs_pn_T(N_TBMEs);
        
    double dummy;	
    											  
    for (unsigned int i = 0 ; i < N_TBMEs ; i++) TBMEs_file_input >> sa_tab(i) >> sb_tab(i) >> sc_tab(i) >> sd_tab(i) >> J_tab(i) >> T_tab(i) >> dummy >> dummy >> dummy >> TBMEs_pn_T(i) >> TBMEs_pp_T(i) >> TBMEs_nn_T(i);

    sa_tab -= 1;
    sb_tab -= 1;
    sc_tab -= 1;
    sd_tab -= 1;
    
    const unsigned int sa_max = sa_tab.max () , sc_max = sc_tab.max ();
    const unsigned int sb_max = sb_tab.max () , sd_max = sd_tab.max ();

    const unsigned int index_ab_max = max (sa_max , sb_max);
    const unsigned int index_cd_max = max (sc_max , sd_max);

    const unsigned int index_max = max (index_ab_max , index_cd_max);
    
    const unsigned int index_number = index_max + 1;
    
    class array<int> n_tab(index_number);
    class array<int> l_tab(index_number);
    
    class array<double> j_tab(index_number);

    int N = 0;
    
    unsigned int index = 0;
    	
    while (index <= index_max)
      {
	const int binary_parity_N = N%2;
	
	for (int i = 0 ; (i <= N) && (index <= index_max) ; i++)
	  {
	    const double j = i + 0.5;
	    	    
	    const int l = (i%2 == binary_parity_N) ? (i) : (i + 1);

	    const int n = (N - l)/2;

	    n_tab(index) = n;
	    l_tab(index) = l;
	    j_tab(index) = j;
	    
	    index++;
	  }

	N++;
      }
      
    const int Jmax = J_tab.max ();
    
    const int Jmax_plus_one = Jmax + 1;
    
    class array<double> TBMEs_pn_T_normed(index_number , index_number , index_number , index_number , Jmax_plus_one , 2);

    TBMEs_pn_T_normed = 0.0;
  
    //const double b_lab = 1.72111;
    const double b_lab = 1.43998;

    TBMEs_file_output << b_lab << endl;
  
    for (unsigned int i = 0 ; i < N_TBMEs ; i++)
      {
	const unsigned int sa = sa_tab(i) , sc = sc_tab(i);
	const unsigned int sb = sb_tab(i) , sd = sd_tab(i);
			
	const double ja = j_tab(sa) , jc = j_tab(sc);
	const double jb = j_tab(sb) , jd = j_tab(sd);
	      	      	
	const int J = J_tab(i);
	const int T = T_tab(i);
	          	
	const int phase_ab = minus_one_pow (ja + jb - J - T);
	const int phase_cd = minus_one_pow (jc + jd - J - T);

	const bool ab_same_shells = (sa == sb);
	const bool cd_same_shells = (sc == sd);
	
	const int phase_abcd = phase_ab*phase_cd;
	    
	const double inv_antisymmetry_norm_ab = (ab_same_shells) ? (M_SQRT2) : (1.0);
	const double inv_antisymmetry_norm_cd = (cd_same_shells) ? (M_SQRT2) : (1.0);
	      
	const double half_inv_norm_antisymmetry_abcd = 0.5*inv_antisymmetry_norm_ab*inv_antisymmetry_norm_cd;

	const double TBME_pn = TBMEs_pn_T(i);
      
	const double TBME_pn_normed = TBME_pn*half_inv_norm_antisymmetry_abcd;
	
	TBMEs_pn_T_normed(sa , sb , sc , sd , J , T) = TBME_pn_normed;
	TBMEs_pn_T_normed(sb , sa , sc , sd , J , T) = TBME_pn_normed*phase_ab;
	TBMEs_pn_T_normed(sa , sb , sd , sc , J , T) = TBME_pn_normed*phase_cd;
	TBMEs_pn_T_normed(sb , sa , sd , sc , J , T) = TBME_pn_normed*phase_abcd;	
      }

    for (unsigned int i = 0 ; i < N_TBMEs ; i++)
      {
	const unsigned int sa = sa_tab(i) , sc = sc_tab(i);
	const unsigned int sb = sb_tab(i) , sd = sd_tab(i);

	const unsigned int ab_index = sb + index_number*sa , cd_index = sd + index_number*sc;
	const unsigned int ba_index = sa + index_number*sb , dc_index = sc + index_number*sd;
      
	const bool is_ab_equal_to_cd = (ab_index == cd_index) , is_ab_equal_to_dc = (ab_index == dc_index);
	const bool is_ba_equal_to_cd = (ba_index == cd_index) , is_ba_equal_to_dc = (ba_index == dc_index);
      
	const bool ab_same_shells = (sa == sb);
	const bool cd_same_shells = (sc == sd);
      
	const int na = n_tab(sa) , nc = n_tab(sc);
	const int nb = n_tab(sb) , nd = n_tab(sd);
	
	const int la = l_tab(sa) , lc = l_tab(sc);
	const int lb = l_tab(sb) , ld = l_tab(sd);
	
	const double ja = j_tab(sa) , jc = j_tab(sc);
	const double jb = j_tab(sb) , jd = j_tab(sd);
	      
	const string lj_sa = angular_state (la , ja) , lj_sc = angular_state (lc , jc);
	const string lj_sb = angular_state (lb , jb) , lj_sd = angular_state (ld , jd);
	      	
	const int J = J_tab(i);
	const int T = T_tab(i);

	const bool is_it_T1 = (T == 1);

	const bool is_J_plus_T_odd = ((J + T)%2 == 1);
	          	
	if (is_it_T1)
	  {
	    const double TBME_pp = TBMEs_pp_T(i);
	    const double TBME_nn = TBMEs_nn_T(i);	    
    	    
	    if (TBME_pp != 0.0) TBMEs_file_output << na << lj_sa << " " << nb << lj_sb << " " << nc << lj_sc << " " << nd << lj_sd << " " << J << " " << -1 << " " << TBME_pp << endl;
	    if (TBME_nn != 0.0) TBMEs_file_output << na << lj_sa << " " << nb << lj_sb << " " << nc << lj_sc << " " << nd << lj_sd << " " << J << " " <<  1 << " " << TBME_nn << endl;
	  }

	if ((!ab_same_shells && !cd_same_shells && is_it_T1) || ((ab_same_shells || cd_same_shells) && is_J_plus_T_odd))
	  {
	    const double TBME_pn_T0_normed_abcd = TBMEs_pn_T_normed(sa , sb , sc , sd , J , 0);
	    const double TBME_pn_T1_normed_abcd = TBMEs_pn_T_normed(sa , sb , sc , sd , J , 1);
		  
	    const double TBME_pn_normed_abcd = TBME_pn_T0_normed_abcd + TBME_pn_T1_normed_abcd;
		  
	    if (TBME_pn_normed_abcd != 0.0) TBMEs_file_output << na << lj_sa << " " << nb << lj_sb << " " << nc << lj_sc << " " << nd << lj_sd << " " << J << " " << 0 << " " << TBME_pn_normed_abcd << endl;
    		  
	    if (!ab_same_shells && (!is_ba_equal_to_cd || !is_ab_equal_to_cd))
	      {
		const double TBME_pn_T0_normed_bacd = TBMEs_pn_T_normed(sb , sa , sc , sd , J , 0);
		const double TBME_pn_T1_normed_bacd = TBMEs_pn_T_normed(sb , sa , sc , sd , J , 1);
	  
		const double TBME_pn_normed_bacd = TBME_pn_T0_normed_bacd + TBME_pn_T1_normed_bacd;
	  
		if (TBME_pn_normed_bacd != 0.0) TBMEs_file_output << nb << lj_sb << " " << na << lj_sa << " " << nc << lj_sc << " " << nd << lj_sd << " " << J << " " << 0 << " " << TBME_pn_normed_bacd << endl;
	      }
      
	    if (!cd_same_shells && (!is_ab_equal_to_cd || !is_ab_equal_to_dc) && (!is_ab_equal_to_cd || !is_ba_equal_to_dc))
	      {
		const double TBME_pn_T0_normed_abdc = TBMEs_pn_T_normed(sa , sb , sd , sc , J , 0);
		const double TBME_pn_T1_normed_abdc = TBMEs_pn_T_normed(sa , sb , sd , sc , J , 1);
		  
		const double TBME_pn_normed_abdc = TBME_pn_T0_normed_abdc + TBME_pn_T1_normed_abdc;
		  
		if (TBME_pn_normed_abdc != 0.0) TBMEs_file_output << na << lj_sa << " " << nb << lj_sb << " " << nd << lj_sd << " " << nc << lj_sc << " " << J << " " << 0 << " " << TBME_pn_normed_abdc << endl;
	      }
		  
	    if (!ab_same_shells && !cd_same_shells && (!is_ba_equal_to_cd || !is_ab_equal_to_dc) && (!is_ba_equal_to_cd || !is_ba_equal_to_dc) && (!is_ab_equal_to_dc || !is_ba_equal_to_dc))
	      {
		const double TBME_pn_T0_normed_badc = TBMEs_pn_T_normed(sb , sa , sd , sc , J , 0);
		const double TBME_pn_T1_normed_badc = TBMEs_pn_T_normed(sb , sa , sd , sc , J , 1);
		  
		const double TBME_pn_normed_badc = TBME_pn_T0_normed_badc + TBME_pn_T1_normed_badc;
		  
		if (TBME_pn_normed_badc != 0.0) TBMEs_file_output << nb << lj_sb << " " << na << lj_sa << " " << nd << lj_sd << " " << nc << lj_sc << " " << J << " " << 0 << " " << TBME_pn_normed_badc << endl;
	      }
	  }
      }
      
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }



