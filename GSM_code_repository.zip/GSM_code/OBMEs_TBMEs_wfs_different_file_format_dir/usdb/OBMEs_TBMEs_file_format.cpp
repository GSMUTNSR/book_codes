#include "../../numlib/numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace string_routines;

#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    const string OBMEs_file_input_file_name = "usdbpn.sp";
  
    ifstream OBMEs_file_input(OBMEs_file_input_file_name.c_str ());

    file_existence_check (OBMEs_file_input_file_name , OBMEs_file_input);
    
    unsigned int N_sp = 0;
  
    OBMEs_file_input >> N_sp;

    class array<int> n_tab(N_sp);

    class array<int> l_tab(N_sp);
  
    class array<enum particle_type> particle_tab(N_sp);

    class array<double> j_tab(N_sp);

    class array<double> OBMEs(N_sp);

    for (unsigned int i = 0 ; i < N_sp ; i++)
      {
	unsigned int dummy_uns_int = 0;

	unsigned int index = 0;
      
	int l = 0;

	int two_j = 0;

	int two_tz = 0;

	double Re_OBME = 0.0;
	double Im_OBME = 0.0;
      
	OBMEs_file_input >> index >> dummy_uns_int >> dummy_uns_int >> dummy_uns_int >> l >> two_j >> two_tz >> Re_OBME >> Im_OBME;
      
	index--;
      
	l_tab(index) = l;
	n_tab(index) = (l == 0) ? (1) : (0);
      
	j_tab(index) = 0.5*two_j;

	particle_tab(index) = (two_tz == -1) ? (PROTON) : (NEUTRON);

	OBMEs(index) = Re_OBME;
      }

    ofstream OBMEs_prot_file_output("OBMEs_proton_fit.dat");
    ofstream OBMEs_neut_file_output("OBMEs_neutron_fit.dat");
  
    for (unsigned int i = 0 ; i < N_sp ; i++)
      {
	const int n_i = n_tab(i);

	const int l_i = l_tab(i);
	
	const double j_i = j_tab(i);

	const enum particle_type particle_i = particle_tab(i);

	const double OBME = OBMEs(i);

	const string lj_i = angular_state (l_i  , j_i);	

	if (particle_i  == PROTON) OBMEs_prot_file_output << n_i << lj_i << " " << n_i << lj_i << " " << OBME << endl;
	if (particle_i == NEUTRON) OBMEs_neut_file_output << n_i << lj_i << " " << n_i << lj_i << " " << OBME << endl;
      }

    // In the interaction file, |ab> and |cd> must be ordered in <ab|V|cd>, i.e. one must have a <= b and c <= d. No test is made.
  
    const string TBMEs_file_input_file_name = "usdbpn.int";
  
    ifstream TBMEs_file_input(TBMEs_file_input_file_name.c_str ());

    file_existence_check (TBMEs_file_input_file_name , TBMEs_file_input);
    
    ofstream TBMEs_file_output("v2body_HO_lab.dat");

    const double b_lab = 2;

    TBMEs_file_output << b_lab << endl;
  
    unsigned int N_TBMEs = 0;
    
    TBMEs_file_input >> N_TBMEs;
  
    class array<int> index_sa_tab(N_TBMEs) , index_sc_tab(N_TBMEs);
    class array<int> index_sb_tab(N_TBMEs) , index_sd_tab(N_TBMEs);
  
    class array<int> J_tab(N_TBMEs);

    class array<double> TBMEs(N_TBMEs);

    for (unsigned int i = 0 ; i < N_TBMEs ; i++)
      {
	unsigned int index_sa = 0 , index_sc = 0;
	unsigned int index_sb = 0 , index_sd = 0;

	int J = 0;

	double Re_TBME = 0.0;
	double Im_TBME = 0.0; 
      
	TBMEs_file_input >> index_sa >> index_sb >> index_sc >> index_sd >> J >> Re_TBME >> Im_TBME;

	index_sa--;
	index_sb--;
	index_sc--;
	index_sd--;
      
	const int na = n_tab(index_sa) , nc = n_tab(index_sc);
	const int nb = n_tab(index_sb) , nd = n_tab(index_sd);
	
	const int la = l_tab(index_sa) , lc = l_tab(index_sc);
	const int lb = l_tab(index_sb) , ld = l_tab(index_sd);
	
	const double ja = j_tab(index_sa) , jc = j_tab(index_sc);
	const double jb = j_tab(index_sb) , jd = j_tab(index_sd);

	const enum particle_type particle_a = particle_tab(index_sa) , particle_c = particle_tab(index_sc);
	const enum particle_type particle_b = particle_tab(index_sb) , particle_d = particle_tab(index_sd);

	const string lj_sa = angular_state (la , ja) , lj_sc = angular_state (lc , jc);
	const string lj_sb = angular_state (lb , jb) , lj_sd = angular_state (ld , jd);

	const double TBME = Re_TBME;

	const int phase_ab = minus_one_pow (ja + jb - J);
	const int phase_cd = minus_one_pow (jc + jd - J);
      
	if ((particle_a == PROTON) && (particle_b == PROTON) && (particle_c == PROTON) && (particle_d == PROTON))
	  TBMEs_file_output << na << lj_sa << " " << nb << lj_sb << " " << nc << lj_sc << " " << nd << lj_sd << " " << J << " " << -1 << " " << TBME << endl;
      
	if ((particle_a == NEUTRON) && (particle_b == NEUTRON) && (particle_c == NEUTRON) && (particle_d == NEUTRON))
	  TBMEs_file_output << na << lj_sa << " " << nb << lj_sb << " " << nc << lj_sc << " " << nd << lj_sd << " " << J << " " << 1 << " " << TBME << endl;
      
	if ((particle_a == PROTON) && (particle_b == NEUTRON) && (particle_c == PROTON) && (particle_d == NEUTRON))
	  TBMEs_file_output << na << lj_sa << " " << nb << lj_sb << " " << nc << lj_sc << " " << nd << lj_sd << " " << J << " " << 0 << " " << TBME << endl;
      
	if ((particle_b == PROTON) && (particle_a == NEUTRON) && (particle_c == PROTON) && (particle_d == NEUTRON))
	  TBMEs_file_output << nb << lj_sb << " " << na << lj_sa << " " << nc << lj_sc << " " << nd << lj_sd << " " << J << " " << 0 << " " << TBME*phase_ab << endl;
      
	if ((particle_a == PROTON) && (particle_b == NEUTRON) && (particle_d == PROTON) && (particle_c == NEUTRON))
	  TBMEs_file_output << na << lj_sa << " " << nb << lj_sb << " " << nd << lj_sd << " " << nc << lj_sc << " " << J << " " << 0 << " " << TBME*phase_cd << endl;
      
	if ((particle_b == PROTON) && (particle_a == NEUTRON) && (particle_d == PROTON) && (particle_c == NEUTRON))
	  TBMEs_file_output << nb << lj_sb << " " << na << lj_sa << " " << nd << lj_sd << " " << nc << lj_sc << " " << J << " " << 0 << " " << TBME*phase_ab*phase_cd << endl;
      }


#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }



