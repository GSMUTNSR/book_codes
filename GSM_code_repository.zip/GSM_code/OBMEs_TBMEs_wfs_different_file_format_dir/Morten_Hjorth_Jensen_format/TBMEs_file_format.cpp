#include "../../numlib/numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace string_routines;

#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    //const string orbits_file_input_file_name = "12vorbits.dat";
    //const string orbits_file_input_file_name = "21vorbits.dat";

    const string orbits_file_input_file_name = "14vorbits.dat";

    ifstream orbits_file_input(orbits_file_input_file_name.c_str ());
  
    file_existence_check (orbits_file_input_file_name , orbits_file_input); 
  
    unsigned int N_sp = 0;
  
    orbits_file_input >> N_sp;
  
    class array<int> n_tab(N_sp);
    class array<int> l_tab(N_sp);
  
    class array<enum particle_type> particle_tab(N_sp);

    class array<double> j_tab(N_sp);

    for (unsigned int i = 0 ; i < N_sp ; i++)
      {
	unsigned int dummy_int = 0;

	unsigned int index = 0;
      
	int n = 0;

	int l = 0;

	int two_j = 0;

	int two_tz = 0;

	double dummy_double=  0;

	string dummy_string = "";
      
	orbits_file_input >> index >> n >> l >> two_j >> two_tz >> dummy_int >> dummy_double >> dummy_double >> dummy_string >> dummy_string;

	index--;
      
	n_tab(index) = n;
	l_tab(index) = l;
      
	j_tab(index) = 0.5*two_j;

	particle_tab(index) = (two_tz == -1) ? (PROTON) : (NEUTRON);
      }
  
    //const string TBMEs_file_input_file_name = "12v28.dat";
    //const string TBMEs_file_input_file_name = "21v14.dat";
  
    const string TBMEs_file_input_file_name = "14v20.dat";

    ifstream TBMEs_file_input(TBMEs_file_input_file_name.c_str ());
  
    file_existence_check (TBMEs_file_input_file_name , TBMEs_file_input);
  
    ofstream TBMEs_file_output("v2body_HO_lab.dat");
  
    unsigned int N_TBMEs = 0;
    
    TBMEs_file_input >> N_TBMEs;
  
    class array<int> index_sa_tab(N_TBMEs) , index_sc_tab(N_TBMEs);
    class array<int> index_sb_tab(N_TBMEs) , index_sd_tab(N_TBMEs);
  
    class array<int> J_tab(N_TBMEs);

    class array<complex<double> > TBMEs(N_TBMEs);

    //const double b_lab = 1.72111;
    const double b_lab = 1.43998;

    TBMEs_file_output << b_lab << endl;

    for (unsigned int i = 0 ; i < N_TBMEs ; i++)
      {
	unsigned int index_sa = 0 , index_sc = 0;
	unsigned int index_sb = 0 , index_sd = 0;

	int Tz = 0;

	int Parity = 0;

	int two_J = 0;

	double TBME = 0.0;

	double dummy_double = 0.0; 
      
	TBMEs_file_input >> Tz >> Parity >> two_J >> index_sa >> index_sb >> index_sc >> index_sd >> TBME >> dummy_double >> dummy_double >> dummy_double;

	index_sa--;
	index_sb--;
	index_sc--;
	index_sd--;
      
	const int na = n_tab(index_sa) , nc = n_tab(index_sc);
	const int nb = n_tab(index_sb) , nd = n_tab(index_sd);
	
	const int la = l_tab(index_sa) , lc = l_tab(index_sc);
	const int lb = l_tab(index_sb) , ld = l_tab(index_sd);
	
	const double ja = j_tab(index_sa) , jc = j_tab(index_sc);
	const double jb = j_tab(index_sb) , jd = j_tab(index_sd);

	const string lj_sa = angular_state (la , ja) , lj_sc = angular_state (lc , jc);
	const string lj_sb = angular_state (lb , jb) , lj_sd = angular_state (ld , jd);

	const int J = two_J/2;
      	
	TBMEs_file_output << na << lj_sa << " " << nb << lj_sb << " " << nc << lj_sc << " " << nd << lj_sd << " " << J << " " << Tz << " " << TBME << endl;
      }

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }



