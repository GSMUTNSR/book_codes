#include "../numlib/numlib_def/numlib_def.h"

#include "../GSM_dir_common/GSM_dir/GSM_include/GSM_include_def_common.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;



using namespace string_routines;


// Calculation of ANC (asymptotic normalization coefficient)
// ---------------------------------------------------------
// One fits the overlap function O(r) (see GSM_overlap_function.cpp) in the asymptotic region.
// As O(r) ~ ANC . F(r), with F(r) a Hankel, Whittaker or Coulomb wave function, one obtains directly the ANC.
// One must have r ~ 10 fm or more.

int main ()
{
  non_MPI_initialization ();
  OpenMP_initialization ();

  string overlap_file_name;
  cin >> overlap_file_name;
  word_check_print<string> ("(overlap.file.name)" , overlap_file_name);
 
  enum particle_type particle;
  cin >> particle;
  word_check_print<enum particle_type> ("(particle)" , particle);

  int l;
  cin >> l;
  word_check_print<int> ("(orbital.angular.momentum)" , l);

  int Z_charge; 
  cin >> Z_charge;
  word_check_print<int> ("(Z.charge)" , Z_charge);

  const double Z_cluster = Z_cluster_determine (particle);
  const double N_cluster = N_cluster_determine (particle);

  //Default values
  double prot_mass_for_calc = 1.0;
  double neut_mass_for_calc = 1.0;
  
  if (Z_cluster > 0)
    {
      cin >> prot_mass_for_calc;
      word_check_print<double> ("amu(proton.mass)" , prot_mass_for_calc);
    }
    
  if (N_cluster > 0)
    {
      cin >> neut_mass_for_calc;
      word_check_print<double> ("amu(neutron.mass)" , neut_mass_for_calc);
    }
  
  double amu_mass; 
  cin >> amu_mass;
  word_check_print<double> ("amu(target.mass)" , amu_mass);
  
  const double cluster_mass_for_calc = mass_cluster_determine (particle , prot_mass_for_calc , neut_mass_for_calc , NADA);
  
  double E_in;
  cin >> E_in;
  word_check_print<double> ("MeV(E.in)" , E_in);

  double Gamma_in;
  cin >> Gamma_in;
  word_check_print<double> ("keV(Gamma.in)" , Gamma_in);

  double E_out;
  cin >> E_out;
  word_check_print<double> ("MeV(E.out)" , E_out);

  double Gamma_out;
  cin >> Gamma_out;
  word_check_print<double> ("keV(Gamma.out)" , Gamma_out);

  string ANC_file_name;
  cin >> ANC_file_name;
  word_check_print<string> ("(ANC.file.name)" , ANC_file_name);

  double R_fit;
  cin >> R_fit;
  word_check_print<double> ("fm(R.fit)" , R_fit);
  
#ifdef TYPEisDOUBLECOMPLEX
  const unsigned int N = elements_number<double> (overlap_file_name)/3;
#endif
  
#ifdef TYPEisDOUBLE
  if ((Gamma_in != 0.0) || (Gamma_out != 0.0)) error_message_print_abort ("One cannot have widths if one uses the real-energy code");
  
  const unsigned int N = elements_number<double> (overlap_file_name)/2;
#endif
  
  class array<double> r_tab(N);

  class array<double> Re_O_tab(N);
  class array<double> Im_O_tab(N);

  ifstream overlap_file(overlap_file_name.c_str ());
  

#ifdef TYPEisDOUBLECOMPLEX
  for (unsigned int i = 0 ; i < N ; i++) overlap_file >> r_tab(i) >> Re_O_tab(i) >> Im_O_tab(i);
#endif
  
#ifdef TYPEisDOUBLE
  Im_O_tab = 0.0;
  
  for (unsigned int i = 0 ; i < N ; i++) overlap_file >> r_tab(i) >> Re_O_tab(i);
#endif
  
  const double kinetic_factor = kinetic_factor_calc (false , amu_mass , cluster_mass_for_calc);

  cout.precision (15);
  cout << "2mu/hbar^2 : " << kinetic_factor << endl;

  const complex<double> E_tilde_in (E_in  , -5E-4*Gamma_in);
  const complex<double> E_tilde_out(E_out , -5E-4*Gamma_out);
  
  const complex<double> Delta_E = E_tilde_out - E_tilde_in;

  const complex<double> k = sqrt (kinetic_factor*Delta_E);

  const complex<double> eta = eta_calc (false , particle , Z_charge , kinetic_factor , k);

  const bool is_it_Wm = (real (Delta_E) < 0.0);

  ofstream ANC_file(ANC_file_name.c_str ());

  ANC_file.precision (15);

  class Coulomb_wave_functions cwf(true , l , eta); 

  bool ANC_found = false;

  int sign_ANC = 1;

  complex<double> ANC = 0.0;

  for (unsigned int i = 1 ; (i < N) && (!ANC_found) ; i++)
    {
      const double r_bef = r_tab(i - 1);

      const double r = r_tab(i);

      const double r_aft = r_tab(i + 1);

      const double Re_O = Re_O_tab(i);
      const double Im_O = Im_O_tab(i);

      const complex<double> O(Re_O , Im_O);

      if (is_it_Wm && (Gamma_in == 0.0) && (Gamma_out == 0.0))
	{
	  complex<double> Wm , dWm;
	  cwf.Wm_kz_dWm_kz (k , r , Wm , dWm);

	  if (r_bef < R_fit && r_aft > R_fit) ANC = abs (Re_O)/abs (Wm) , sign_ANC = SIGN(Re_O) , ANC_found = true;
	}
      else if (is_it_Wm)
	{
	  complex<double> Wm , dWm;
	  cwf.Wm_kz_dWm_kz (k , r , Wm , dWm);

	  if (r_bef < R_fit && r_aft > R_fit) sign_ANC = SIGN(Re_O) , ANC = sign_ANC*O/Wm , ANC_found = true;
	}
      else
	{
	  complex<double> Hp , dHp;
	  cwf.H_kz_dH_kz (1 , k , r , Hp , dHp);

	  if (r_bef < R_fit && r_aft > R_fit) sign_ANC = SIGN(Re_O) , ANC = sign_ANC*O/Hp , ANC_found = true;
	}
    }

  cout.precision (15);
  cout << endl << "ANC : " << ANC << endl;
  cout << "E.out - E.in : " << Delta_E << " MeV" << endl;
  cout << "k[E.out - E.in] : " << k << " fm^(-1)" << endl;
  cout << "eta : " << eta << endl;

  for (unsigned int i = 1 ; i < N ; i++)
    {
      const double r = r_tab(i);

      const double Re_O = Re_O_tab(i);
      const double Im_O = Im_O_tab(i);
      
      if (is_it_Wm && (Gamma_in == 0.0) && (Gamma_out == 0.0))
	{
	  complex<double> Wm , dWm;
	  cwf.Wm_kz_dWm_kz (k , r , Wm , dWm);

	  ANC_file << r << " " << sign_ANC*Re_O_tab(i) << " " << abs (ANC*Wm) << endl; 
	}
      else if (is_it_Wm)
	{
	  complex<double> Wm , dWm;
	  cwf.Wm_kz_dWm_kz (k , r , Wm , dWm);

	  const complex<double> O(Re_O , Im_O);

	  ANC_file << r << " " << sign_ANC*Re_O_tab(i) << " " << real (ANC*Wm) << " " << sign_ANC*Im_O_tab(i) << " " << imag (ANC*Wm) << endl;
	}
      else
	{
	  complex<double> Hp , dHp;
	  cwf.H_kz_dH_kz (1 , k , r , Hp , dHp);

	  const complex<double> O(Re_O , Im_O);

	  ANC_file << r << " " << sign_ANC*Re_O_tab(i) << " " << real (ANC*Hp) << " " << sign_ANC*Im_O_tab(i) << " " << imag (ANC*Hp) << endl; 
	}
    }
}


