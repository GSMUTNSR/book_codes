#ifndef CCCHANNELCLASS_H
#define CCCHANNELCLASS_H


/* CC_channel_class (class):
   _ contains every information on a channel.
*/

class CC_channel_class
{
public:
  CC_channel_class ();

  CC_channel_class (
		    const enum interaction_type inter , 
		    const double prot_mass_for_calc , 
		    const double neut_mass_for_calc , 
		    const double nucleus_mass , 
		    const double b_lab , 
		    const int Z , 
		    const int N , 
		    const enum particle_type projectile_c , 
		    const unsigned int BP_Tc_c , 
		    const double J_Tc_c , 
		    const unsigned int vector_index_Tc_c , 
		    const bool S_matrix_pole_Tc_c ,  
		    const complex<double> &E_Tc_c , 
		    const complex<double> &E_intrinsic_projectile_c_c , 
		    const complex<double> &average_n_scat_Tc_c , 
		    const int LCM_projectile_c , 
		    const double J_projectile_c , 
		    const unsigned int vector_index_c , 
		    const double J_c , 
		    const double M_c , 
		    const complex<double> &E_c , 
		    const bool is_it_HO_channel_decomposition_c);
  
  CC_channel_class (const class CC_channel_class &X);
  
  void initialize (
		   const enum interaction_type inter , 
		   const double prot_mass_for_calc , 
		   const double neut_mass_for_calc , 
		   const double nucleus_mass , 
		   const double b_lab , 
		   const int Z , 
		   const int N , 
		   const enum particle_type projectile_c , 
		   const unsigned int BP_Tc_c , 
		   const double J_Tc_c , 
		   const unsigned int vector_index_Tc_c , 
		   const bool S_matrix_pole_Tc_c ,  
		   const complex<double> &E_Tc_c , 
		   const complex<double> &E_intrinsic_projectile_c_c , 
		   const complex<double> &average_n_scat_Tc_c , 
		   const int LCM_projectile_c , 
		   const double J_projectile_c , 
		   const unsigned int vector_index_c , 
		   const double J_c , 
		   const double M_c , 
		   const complex<double> &E_c , 
		   const bool is_it_HO_channel_decomposition_c);

  void initialize (const class CC_channel_class &X);

  void operator = (const class CC_channel_class &X);
  
  enum particle_type get_projectile () const
  {
    return projectile;
  }
  
  int get_Z_Tc () const
  {
    return Z_Tc;
  }

  int get_N_Tc () const
  {
    return N_Tc;
  }

  int get_A_Tc () const
  {
    return A_Tc;
  }

  unsigned int get_BP_Tc () const
  {
    return BP_Tc;
  }

  double get_J_Tc () const
  {
    return J_Tc;
  }

  unsigned int get_vector_index_Tc () const
  {
    return vector_index_Tc;
  }

  bool get_S_matrix_pole_Tc () const
  {
    return S_matrix_pole_Tc;
  }
 
  double get_mass_Tc () const
  {
    return mass_Tc;
  }

  complex<double> get_E_Tc () const
  {
    return E_Tc;
  }

  complex<double> get_E_intrinsic_projectile_c () const
  {
    return E_intrinsic_projectile_c;
  }

  complex<double> get_average_n_scat_Tc () const
  {
    return average_n_scat_Tc;
  }

  int get_Z_projectile () const
  {
    return Z_projectile;
  }

  int get_N_projectile () const
  {
    return N_projectile;
  }

  int get_A_projectile () const
  {
    return A_projectile;
  }

  bool get_S_matrix_pole_projectile () const
  {
    return S_matrix_pole_projectile;
  }

  double get_mass_projectile () const
  {
    return mass_projectile;
  }

  double get_b_HO_potentials_projectile () const
  {
    return b_HO_potentials_projectile;
  }

  int get_LCM_projectile () const
  {
    return LCM_projectile;
  }

  unsigned int get_BP_LCM_projectile () const
  {
    return BP_LCM_projectile;
  }

  double get_kinetic_factor_projectile () const
  {
    return kinetic_factor_projectile;
  }

  unsigned int get_BP_intrinsic_projectile () const
  {
    return BP_intrinsic_projectile;
  }

  double get_J_intrinsic_projectile () const
  {
    return J_intrinsic_projectile;
  }

  unsigned int get_BP_projectile () const
  {
    return BP_projectile;
  }

  double get_J_projectile () const
  {
    return J_projectile;
  }

  complex<double> get_e_projectile () const
  {
    return e_projectile;
  }

  complex<double> get_k_projectile () const
  {
    return k_projectile;
  }

  complex<double> get_eta_projectile () const
  {
    return eta_projectile;
  }

  int get_Z_Tc_charge () const
  {
    return Z_Tc_charge;
  }

  unsigned int get_BP () const
  {
    return BP;
  }

  unsigned int get_vector_index () const
  {
    return vector_index;
  }

  double get_J () const
  {
    return J;
  }

  double get_M () const
  {
    return M;
  }

  complex<double> Eget_ () const
  {
    return E;
  }

  bool get_is_it_HO_channel_decomposition () const
  {
    return is_it_HO_channel_decomposition;
  }
  
  void E_dependent_values_change (const complex<double> &E_c);

  string channel_string_for_file_name () const;

private:
  
  //Projectile type
  enum particle_type projectile;

  // Target variables
  int Z_Tc;
  int N_Tc;
  int A_Tc;
  
  unsigned int BP_Tc;

  double J_Tc;

  unsigned int vector_index_Tc;

  bool S_matrix_pole_Tc; 

  double mass_Tc;

  complex<double> E_Tc;
  complex<double> E_intrinsic_projectile_c;
  complex<double> average_n_scat_Tc;

  // Projectile variables
  int Z_projectile;
  int N_projectile;
  int A_projectile;
  
  bool S_matrix_pole_projectile;

  double mass_projectile;
  double b_HO_potentials_projectile;

  int LCM_projectile;

  unsigned int BP_LCM_projectile;

  double kinetic_factor_projectile;

  unsigned int BP_intrinsic_projectile;

  double J_intrinsic_projectile;

  unsigned int BP_projectile;

  double J_projectile;

  complex<double> e_projectile;
  complex<double> k_projectile;
  complex<double> eta_projectile;

  // Total charge felt by projectile
  int Z_Tc_charge;

  // Whole-system variables
  unsigned int BP;
  unsigned int vector_index;
  
  double J;
  double M;

  complex<double> E;

  bool is_it_HO_channel_decomposition;
};

ostream& operator << (ostream &os , const class CC_channel_class &channel_c);

double used_memory_calc (const class CC_channel_class &T);

#endif


