#ifndef JOSTMATRIX_H
#define JOSTMATRIX_H

void Jost_matrix_entrance_channel_only_calc (
					     const unsigned int ic_entrance , 
					     const class array<class CC_fwd_basis_state> &fwd_basis , 
					     const class array<class CC_bwd_basis_state> &bwd_basis , 
					     class matrix<complex<double> > &Jost_matrix);

void Jost_matrix_calc (
		       const class array<class CC_fwd_basis_state> &fwd_basis, 
		       const class array<class CC_bwd_basis_state> &bwd_basis,
		       class matrix<complex<double> > &Jost_matrix);

#endif
