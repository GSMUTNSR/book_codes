#ifndef CCBACKWARDBASISSTATE_H
#define CCBACKWARDBASISSTATE_H


class CC_bwd_basis_state 
{
public:

  CC_bwd_basis_state ();
  
  CC_bwd_basis_state (
		      const bool S_matrix_pole_c , 
		      const unsigned int N_channels_c ,
		      const unsigned int ic_entrance_c , 
		      const unsigned int ib_c , 
		      const class array<class CC_channel_class> &channels_tab_c  , 
		      const unsigned int N_bef_R_uniform_c , 
		      const unsigned int N_bef_R_GL_c , 
		      const double R_c , 
		      const double matching_point_c , 
		      const double R_real_max_c);

  CC_bwd_basis_state (const class CC_bwd_basis_state &X);
  
  void allocate (
		 const bool S_matrix_pole_c , 
		 const unsigned int N_channels_c ,
		 const unsigned int ic_entrance_c , 
		 const unsigned int ib_c , 
		 const class array<class CC_channel_class> &channels_tab_c  , 
		 const unsigned int N_bef_R_uniform_c , 
		 const unsigned int N_bef_R_GL_c , 
		 const double R_c , 
		 const double matching_point_c , 
		 const double R_real_max_c);

  void allocate_fill (const class CC_bwd_basis_state &X);

  void deallocate ();

  bool get_S_matrix_pole () const
  {
    return S_matrix_pole;
  }
  
  unsigned int get_N_channels () const
  {
    return N_channels;
  }

  unsigned int get_N_bef_R_uniform () const
  {
    return N_bef_R_uniform;
  }
  
  unsigned int get_N_bef_R_GL () const
  {
    return N_bef_R_GL;
  }

  unsigned int get_ic_entrance () const
  {
    return ic_entrance;
  }
  
  unsigned int get_ib () const
  {
    return ib;
  }

  double get_R () const
  {
    return R;
  }

  double get_matching_point () const
  {
    return matching_point;
  }

  double get_R_max () const
  {
    return R_max;
  }

  double get_step_bef_R_uniform () const
  {
    return step_bef_R_uniform;
  }

  unsigned int get_N_bef_mp_GL () const
  {
    return N_bef_mp_GL;
  }
  
  unsigned int get_N_aft_mp_GL () const
  {
    return N_aft_mp_GL;
  }

  unsigned int get_N_bef_mp_GL_SGI_MSGI () const
  {
    return N_bef_mp_GL_SGI_MSGI;
  }
  
  unsigned int get_N_aft_mp_GL_SGI_MSGI () const
  {
    return N_aft_mp_GL_SGI_MSGI;
  }

  const class array<class CC_channel_class> & get_channels_tab () const
  {
    return channels_tab;
  }

  const class array<double> & get_r_aft_mp_bef_R_tab_uniform () const
  {
    return r_aft_mp_bef_R_tab_uniform;
  }

  const class array<double> & get_r_aft_mp_bef_R_tab_GL () const
  {
    return r_aft_mp_bef_R_tab_GL;
  }

  const class array<double> & get_r_aft_mp_bef_R_tab_GL_SGI_MSGI () const
  {
    return r_aft_mp_bef_R_tab_GL_SGI_MSGI;
  }

  const class array<complex<double> > & get_CC_bwd_wf_tab_uniform () const
  {
    return CC_bwd_wf_tab_uniform;
  }

  const class array<complex<double> > & get_CC_bwd_dwf_tab_uniform () const
  {
    return CC_bwd_dwf_tab_uniform;
  }

  const class array<complex<double> > & get_CC_bwd_wf_tab_GL () const
  {
    return CC_bwd_wf_tab_GL;
  }

  const class array<complex<double> > & get_CC_bwd_dwf_tab_GL () const
  {
    return CC_bwd_dwf_tab_GL;
  }

  const class array<complex<double> > & get_CC_bwd_wf_tab_GL_SGI_MSGI () const
  {
    return CC_bwd_wf_tab_GL_SGI_MSGI;
  }

  const class array<complex<double> > & get_CC_bwd_dwf_tab_GL_SGI_MSGI () const
  {
    return CC_bwd_dwf_tab_GL_SGI_MSGI;
  }

  const class array<complex<double> > & get_CC_bwd_wf_mp_tab () const
  {
    return CC_bwd_wf_mp_tab;
  }

  const class array<complex<double> > & get_CC_bwd_dwf_mp_tab () const
  {
    return CC_bwd_dwf_mp_tab;
  }

  void zero ();

  void backward_integration_before_R (
				      const bool is_it_entrance_channel_only ,
				      const bool is_it_Uminus ,
				      const complex<double> &Cplus_b ,
				      class CC_system_integration &SI);

  void change_channels (const complex<double> &E);

  class CC_bwd_basis_state & operator= (const class CC_bwd_basis_state &X);

  bool is_it_filled () const;

  friend double used_memory_calc (const class CC_bwd_basis_state &T);
  
private:
  
  bool S_matrix_pole;

  unsigned int N_channels;
  unsigned int N_bef_R_uniform;
  unsigned int N_bef_R_GL;
  unsigned int ic_entrance;
  unsigned int ib;

  double R;
  double matching_point;
  double R_max;
  double step_bef_R_uniform;

  unsigned int N_bef_mp_uniform;
  unsigned int N_aft_mp_uniform;

  unsigned int N_bef_mp_GL;
  unsigned int N_aft_mp_GL;

  unsigned int N_bef_mp_GL_SGI_MSGI;
  unsigned int N_aft_mp_GL_SGI_MSGI;

  class array<class CC_channel_class> channels_tab;

  class array<double> r_aft_mp_bef_R_tab_uniform;
  class array<double> r_aft_mp_bef_R_tab_GL;

  class array<double> r_aft_mp_bef_R_tab_GL_SGI_MSGI;

  class array<complex<double> > CC_bwd_wf_tab_uniform;
  class array<complex<double> > CC_bwd_dwf_tab_uniform;

  class array<complex<double> > CC_bwd_wf_tab_GL;
  class array<complex<double> > CC_bwd_dwf_tab_GL;

  class array<complex<double> > CC_bwd_wf_tab_GL_SGI_MSGI;
  class array<complex<double> > CC_bwd_dwf_tab_GL_SGI_MSGI;

  class array<complex<double> > CC_bwd_wf_mp_tab;
  class array<complex<double> > CC_bwd_dwf_mp_tab;

  void Uplus_asymptotic_conditions_calc (
					 const complex<double> &Cplus_b ,
					 class vector_class <complex<double> > &UR ,
					 class vector_class <complex<double> > &dUR) const;

  void Uminus_asymptotic_conditions_calc (
					  class vector_class <complex<double> > &UR ,
					  class vector_class <complex<double> > &dUR) const;
};

#endif


