#ifndef CC_HO_WAVE_FUNCTIONS_H
#define CC_HO_WAVE_FUNCTIONS_H

namespace CC_HO_wave_functions
{
  void wfs_radial_calc (
			const class array<class CC_channel_class> &channels_tab,
			const class array<double> &r_tab,
			const class array<double> &HO_CC_wfs_tab);

  void wfs_dwfs_radial_calc (
			     const class array<class CC_channel_class> &channels_tab,
			     const class array<double> &r_tab,
			     const class array<double> &HO_CC_wfs_tab , 
			     const class array<double> &HO_CC_dwfs_tab);

  void wfs_dwfs_d2wfs_radial_calc (
				   const class array<class CC_channel_class> &channels_tab,
				   const class array<double> &r_tab,
				   const class array<double> &HO_CC_wfs_tab , 
				   const class array<double> &HO_CC_dwfs_tab , 
				   const class array<double> &HO_CC_d2wfs_tab);
  
  void wfs_momentum_calc (
			  const class array<class CC_channel_class> &channels_tab,
			  const class array<double> &k_tab,
			  const class array<double> &HO_CC_wfs_tab);

  void wfs_dwfs_momentum_calc (
			       const class array<class CC_channel_class> &channels_tab,
			       const class array<double> &k_tab,
			       const class array<double> &HO_CC_wfs_tab , 
			       const class array<double> &HO_CC_dwfs_tab);

  void wfs_dwfs_d2wfs_momentum_calc (
				     const class array<class CC_channel_class> &channels_tab,
				     const class array<double> &k_tab,
				     const class array<double> &HO_CC_wfs_tab , 
				     const class array<double> &HO_CC_dwfs_tab , 
				     const class array<double> &HO_CC_d2wfs_tab);
}

#endif

