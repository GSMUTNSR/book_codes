#ifndef CCBACKWARDBASISSTATE_H
#define CCBACKWARDBASISSTATE_H


// Class of basis channel state integrated backwards
// -------------------------------------------------
// One has uc(r) = sum_b b[b,c] bwd_basis[b](r) on [matching-point:R].
// One stores here the data associated to a given bwd_basis[b](r).
// One has bwd_basis[b](r) = C+/-[b].H+/-(k[b].r) for r > R.
// See book for formulas.

class CC_bwd_basis_state 
{
public:

  CC_bwd_basis_state ();
  
  CC_bwd_basis_state (
		      const bool S_matrix_pole_c , 
		      const unsigned int N_channels_c ,
		      const unsigned int ic_entrance_c , 
		      const unsigned int ib_c , 
		      const class array<class CC_channel_class> &channels_tab_c  , 
		      const unsigned int N_bef_R_uniform_c , 
		      const unsigned int N_bef_R_GL_c , 
		      const double R_c , 
		      const double matching_point_c , 
		      const double R_real_max_c);

  CC_bwd_basis_state (const class CC_bwd_basis_state &X);
  
  void allocate (
		 const bool S_matrix_pole_c , 
		 const unsigned int N_channels_c ,
		 const unsigned int ic_entrance_c , 
		 const unsigned int ib_c , 
		 const class array<class CC_channel_class> &channels_tab_c  , 
		 const unsigned int N_bef_R_uniform_c , 
		 const unsigned int N_bef_R_GL_c , 
		 const double R_c , 
		 const double matching_point_c , 
		 const double R_real_max_c);

  void allocate_fill (const class CC_bwd_basis_state &X);

  void deallocate ();

  bool get_S_matrix_pole () const
  {
    return S_matrix_pole;
  }
  
  unsigned int get_N_channels () const
  {
    return N_channels;
  }

  unsigned int get_N_bef_R_uniform () const
  {
    return N_bef_R_uniform;
  }
  
  unsigned int get_N_bef_R_GL () const
  {
    return N_bef_R_GL;
  }

  unsigned int get_ic_entrance () const
  {
    return ic_entrance;
  }
  
  unsigned int get_ib () const
  {
    return ib;
  }

  double get_R () const
  {
    return R;
  }

  double get_matching_point () const
  {
    return matching_point;
  }

  double get_R_max () const
  {
    return R_max;
  }

  double get_step_bef_R_uniform () const
  {
    return step_bef_R_uniform;
  }

  unsigned int get_N_bef_mp_GL () const
  {
    return N_bef_mp_GL;
  }
  
  unsigned int get_N_aft_mp_GL () const
  {
    return N_aft_mp_GL;
  }

  unsigned int get_N_bef_mp_GL_SGI_MSGI () const
  {
    return N_bef_mp_GL_SGI_MSGI;
  }
  
  unsigned int get_N_aft_mp_GL_SGI_MSGI () const
  {
    return N_aft_mp_GL_SGI_MSGI;
  }

  const class array<class CC_channel_class> & get_channels_tab () const
  {
    return channels_tab;
  }

  const class array<double> & get_r_aft_mp_bef_R_tab_uniform () const
  {
    return r_aft_mp_bef_R_tab_uniform;
  }

  const class array<double> & get_r_aft_mp_bef_R_tab_GL () const
  {
    return r_aft_mp_bef_R_tab_GL;
  }

  const class array<double> & get_r_aft_mp_bef_R_tab_GL_SGI_MSGI () const
  {
    return r_aft_mp_bef_R_tab_GL_SGI_MSGI;
  }

  const class array<complex<double> > & get_CC_bwd_wf_tab_uniform () const
  {
    return CC_bwd_wf_tab_uniform;
  }

  const class array<complex<double> > & get_CC_bwd_dwf_tab_uniform () const
  {
    return CC_bwd_dwf_tab_uniform;
  }

  const class array<complex<double> > & get_CC_bwd_wf_tab_GL () const
  {
    return CC_bwd_wf_tab_GL;
  }

  const class array<complex<double> > & get_CC_bwd_dwf_tab_GL () const
  {
    return CC_bwd_dwf_tab_GL;
  }

  const class array<complex<double> > & get_CC_bwd_wf_tab_GL_SGI_MSGI () const
  {
    return CC_bwd_wf_tab_GL_SGI_MSGI;
  }

  const class array<complex<double> > & get_CC_bwd_dwf_tab_GL_SGI_MSGI () const
  {
    return CC_bwd_dwf_tab_GL_SGI_MSGI;
  }

  const class array<complex<double> > & get_CC_bwd_wf_mp_tab () const
  {
    return CC_bwd_wf_mp_tab;
  }

  const class array<complex<double> > & get_CC_bwd_dwf_mp_tab () const
  {
    return CC_bwd_dwf_mp_tab;
  }

  void zero ();

  void backward_integration_before_R (
				      const bool is_it_entrance_channel_only ,
				      const bool is_it_Uminus ,
				      const complex<double> &Cplus_b ,
				      class CC_system_integration &SI);

  void change_channels (const complex<double> &E);

  class CC_bwd_basis_state & operator= (const class CC_bwd_basis_state &X);

  bool is_it_filled () const;

  friend double used_memory_calc (const class CC_bwd_basis_state &T);
  
private:
  
  bool S_matrix_pole;           // true for bound and resonant states, false for scattering states

  unsigned int N_channels;      // number of channels used in the GSM-CC Hamiltonian
  unsigned int N_bef_R_uniform; // number of points on [0:R] using uniform (uniform) discretization
  unsigned int N_bef_R_GL;      // number of points on [0:R] using Gauss-Legendre (GL) discretization
  unsigned int ic_entrance;     // index of the entrance channel for scattering states. It is usually put to zero by convention for resonant states.
  unsigned int ib;              // index of the basis channel

  double R;                  // rotation point on the real r-axis for complex scaling
  double matching_point;     // matching point on the real r-axis between internal and external parts of uc(r). It is equal to R0.
  double R_max;              // maximal radius for integration with HO states.
  double step_bef_R_uniform; // number of points on uniform grid on [0:R] (before R)

  unsigned int N_bef_mp_uniform; // number of points on [0:matching-point] using uniform (uniform) discretization
  unsigned int N_aft_mp_uniform; // number of points on [matching-point:R] using uniform (uniform) discretization

  unsigned int N_bef_mp_GL;          // number of points on [0:matching-point] using Gauss-Legendre (GL) discretization
  unsigned int N_aft_mp_GL;          // number of points on [matching-point:R] using Gauss-Legendre (GL) discretization

  unsigned int N_bef_mp_GL_SGI_MSGI; // number of points on [0:matching-point] using Gauss-Legendre (GL) discretization with the SGI or MSGI interaction (where on integrates on [0:2.R0])
  unsigned int N_aft_mp_GL_SGI_MSGI; // number of points on [matching-point:R] using Gauss-Legendre (GL) discretization with the SGI or MSGI interaction (where on integrates on [0:2.R0])

  class array<class CC_channel_class> channels_tab; // array of the channels used in the GSM-CC Hamiltonian

  class array<double> r_aft_mp_bef_R_tab_uniform;       // Uniformly distributed abscissas on [matching-point:R]  : r = i.step_bef_R_uniform , i in [0:N_bef_R_uniform-1]
  class array<double> r_aft_mp_bef_R_tab_GL;            // Part of the Gaussian abscissas before R in [matching-point:R]

  class array<double> r_aft_mp_bef_R_tab_GL_SGI_MSGI;   // Part of the Gaussian abscissas before R in [matching-point:R] with r in ]0:2.R0[ for SGI and MSGI integrals.

  class array<complex<double> > CC_bwd_wf_tab_uniform;   // channel basis wave function on [matching-point:R] on a uniform grid in all channels
  class array<complex<double> > CC_bwd_dwf_tab_uniform;  // channel basis wave function derivatives on [matching-point:R] on a uniform grid in all channels

  class array<complex<double> > CC_bwd_wf_tab_GL;   // channel basis wave function on [matching-point:R] with Gaussian points in all channels
  class array<complex<double> > CC_bwd_dwf_tab_GL;  // channel basis wave function derivative on [matching-point:R] with Gaussian points in all channels

  class array<complex<double> > CC_bwd_wf_tab_GL_SGI_MSGI;   // channel basis wave function on [matching-point:2.R0] with Gaussian points in all channels
  class array<complex<double> > CC_bwd_dwf_tab_GL_SGI_MSGI;  // channel basis wave function derivatives on [matching-point:2.R0] with Gaussian points in all channels

  class array<complex<double> > CC_bwd_wf_mp_tab;   // channel basis wave function in matching-point in all channels
  class array<complex<double> > CC_bwd_dwf_mp_tab;  // channel basis wave function derivative in matching-point in all channels

  void Uplus_asymptotic_conditions_calc (
					 const complex<double> &Cplus_b ,
					 class vector_class <complex<double> > &UR ,
					 class vector_class <complex<double> > &dUR) const;

  void Uminus_asymptotic_conditions_calc (
					  class vector_class <complex<double> > &UR ,
					  class vector_class <complex<double> > &dUR) const;
};

#endif


