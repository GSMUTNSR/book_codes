#ifndef CC_TARGET_PROJECTILE_COMPOSITE_DATA_H
#define CC_TARGET_PROJECTILE_COMPOSITE_DATA_H

// Class containing data associated to all the target-projectile composite states considered in the GSM-CC calculation
// -------------------------------------------------------------------------------------------------------------------



class CC_target_projectile_composite_data
{
public:

  CC_target_projectile_composite_data ();
    
  CC_target_projectile_composite_data (
				       const class input_data_str &input_data , 
				       const class baryons_data &prot_Y_data , 
				       const class baryons_data &neut_Y_data);

  CC_target_projectile_composite_data (const class CC_target_projectile_composite_data &X);

  ~CC_target_projectile_composite_data ();
  
  void allocate (
		 const class input_data_str &input_data , 
		 const class baryons_data &prot_Y_data , 
		 const class baryons_data &neut_Y_data);

  void allocate_fill (const class CC_target_projectile_composite_data &X);

  void deallocate ();

  bool is_it_filled () const
  {
    return (CC_reaction != NO_REACTION);
  }
  
  int get_Z () const
  {
    return Z;
  }
  
  int get_N () const
  {
    return N;
  }

  int get_A () const
  {
    return A;
  }
  
  int get_S () const
  {
    return S;
  }
  
  bool get_initial_pivot_from_file () const
  {
    return initial_pivot_from_file;
  }
  
  bool get_truncation_hw () const
  {
    return truncation_hw;
  }

  bool get_truncation_ph () const
  {
    return truncation_ph;
  }

  int get_n_holes_max () const
  {
    return n_holes_max;
  }
  
  int get_n_scat_max () const
  {
    return n_scat_max;
  }

  int get_E_relative_max_hw () const
  {
    return E_relative_max_hw;
  }

  enum CC_reaction_type get_CC_reaction () const
  {
    return CC_reaction;
  }

  enum CC_reaction_calculation_type get_CC_reaction_calculation () const
  {
    return CC_reaction_calculation;
  }

  enum particle_type get_entrance_projectile () const
  {
    return entrance_projectile;
  }

  double get_mass_entrance_projectile () const
  {
    return mass_entrance_projectile;
  }

  double get_CM_to_work_frame_kinetic_factor () const
  {
    return CM_to_work_frame_kinetic_factor;
  }

  double get_work_frame_to_lab_kinetic_factor () const
  {
    return work_frame_to_lab_kinetic_factor;
  }
  
  double get_CM_to_lab_kinetic_factor () const
  {
    return CM_to_lab_kinetic_factor;
  }
 
  double get_kinetic_factor_entrance_projectile_work_frame () const
  {
    return kinetic_factor_entrance_projectile_work_frame;
  }

  double get_kinetic_factor_entrance_projectile_CM () const
  {
    return kinetic_factor_entrance_projectile_CM;
  }

  int get_Z_target () const
  {
    return Z_target;
  }

  int get_N_target () const
  {
    return N_target;
  }

  int get_A_target () const
  {
    return A_target;
  }

  double get_mass_target () const
  {
    return mass_target;
  }
  
  bool get_are_GSM_a_dagger_vectors_calculated () const
  {
    return are_GSM_a_dagger_vectors_calculated;
  }

  unsigned int get_N_JPi_A () const
  {
    return N_JPi_A;
  }

  unsigned int get_N_JPi_A_in () const
  {
    return N_JPi_A_in;
  }

  unsigned int get_N_JPi_A_out () const
  {
    return N_JPi_A_out;
  }

  unsigned int get_N_target_projectile_states () const
  {
    return N_target_projectile_states;
  }

  unsigned int get_entrance_target_index () const
  {
    return entrance_target_index;
  }

  unsigned int get_N_entrance_channels_max () const
  {
    return N_entrance_channels_max;
  }

  double get_J_intrinsic_projectile_max () const
  {
    return J_intrinsic_projectile_max;
  }

  unsigned int get_N_energies () const
  {
    return N_energies;
  }

  unsigned int get_N_CM_angles () const
  {
    return N_CM_angles;
  }

  unsigned int get_cluster_projectile_number () const
  {
    return cluster_projectile_number;
  }

  bool get_is_it_one_baryon_COSM_case () const
  {
    return is_it_one_baryon_COSM_case;
  }

  enum EM_type get_EM_for_radiative_capture_cross_section () const
  {
    return EM_for_radiative_capture_cross_section;
  }

  int get_L_for_radiative_capture_cross_section () const
  {
    return L_for_radiative_capture_cross_section;
  }

  unsigned int get_N_theta_gamma () const
  {
    return N_theta_gamma;
  }

  unsigned int get_N_phi_gamma () const
  {
    return N_phi_gamma;
  }

  bool get_radiative_capture_is_it_longwavelength_approximation () const
  {
    return radiative_capture_is_it_longwavelength_approximation;
  }

  bool get_radiative_capture_is_it_HO_expansion () const
  {
    return radiative_capture_is_it_HO_expansion;
  }
  
  void set_N_channels (const unsigned int N_channels_c)
  {
    N_channels = N_channels_c;
  }
  
  unsigned int get_N_channels () const
  {
    return N_channels;
  }
  
  void set_N_channels_in (const unsigned int N_channels_in_c)
  {
    N_channels_in = N_channels_in_c;
  }
  
  unsigned int get_N_channels_in () const
  {
    return N_channels_in;
  }
  
  void set_N_channels_out (const unsigned int N_channels_out_c)
  {
    N_channels_out = N_channels_out_c;
  }
  
  unsigned int get_N_channels_out () const
  {
    return N_channels_out;
  }
   
  unsigned int get_N_restarts () const
  {
    return N_restarts;
  }

  unsigned int get_Davidson_max_dimension () const
  {
    return Davidson_max_dimension;
  }

  double get_Davidson_eigenvector_precision () const
  {
    return Davidson_eigenvector_precision;
  }

  double get_relative_SVD_precision () const
  {
    return relative_SVD_precision;
  }

  double get_R_cut_function () const
  {
    return R_cut_function;
  }

  double get_d_cut_function () const
  {
    return d_cut_function;
  }

  double get_Ueq_regularizor () const
  {
    return Ueq_regularizor;
  }

  const class array<enum particle_type> & get_projectile_tab () const
  {
    return projectile_tab;
  }
 
  class array<enum particle_type> & get_projectile_tab ()
  {
    return projectile_tab;
  }
  
  const class array<unsigned int> & get_BP_target_tab () const
  {
    return BP_target_tab;
  }

  class array<unsigned int> & get_BP_target_tab ()
  {
    return BP_target_tab;
  }

  const class array<double> & get_J_target_tab () const
  {
    return J_target_tab;
  }
  
  class array<double> & get_J_target_tab ()
  {
    return J_target_tab;
  }

  const class array<unsigned int> & get_vector_index_target_tab () const
  {
    return vector_index_target_tab;
  }	

  class array<unsigned int> & get_vector_index_target_tab ()
  {
    return vector_index_target_tab;
  }	

  const class array<bool> & get_is_it_pole_target_tab () const
  {
    return is_it_pole_target_tab;
  }

  class array<bool> & get_is_it_pole_target_tab ()
  {
    return is_it_pole_target_tab;
  }

  const class array<double> & get_real_E_target_tab () const
  {
    return real_E_target_tab;
  }

  class array<double> & get_real_E_target_tab ()
  {
    return real_E_target_tab;
  }

  const class array<double> & get_Gamma_target_tab () const
  {
    return Gamma_target_tab;
  }

  class array<double> & get_Gamma_target_tab ()
  {
    return Gamma_target_tab;
  }

  const class array<TYPE> & get_E_target_tab () const
  {
    return E_target_tab;
  }

  class array<TYPE> & get_E_target_tab ()
  {
    return E_target_tab;
  }

  const class array<double> & get_real_E_intrinsic_projectile_tab () const
  {
    return real_E_intrinsic_projectile_tab;
  }

  class array<double> & get_real_E_intrinsic_projectile_tab ()
  {
    return real_E_intrinsic_projectile_tab;
  }

  const class array<double> & get_Gamma_intrinsic_projectile_tab () const
  {
    return Gamma_intrinsic_projectile_tab;
  }

  class array<double> & get_Gamma_intrinsic_projectile_tab ()
  {
    return Gamma_intrinsic_projectile_tab;
  }

  const class array<TYPE> & get_E_intrinsic_projectile_tab () const
  {
    return E_intrinsic_projectile_tab;
  }

  class array<TYPE> & get_E_intrinsic_projectile_tab ()
  {
    return E_intrinsic_projectile_tab;
  }

  const class array<complex<double> > & get_average_n_scat_target_tab () const
  {
    return average_n_scat_target_tab;
  }

  class array<complex<double> > & get_average_n_scat_target_tab ()
  {
    return average_n_scat_target_tab;
  }

  const class array<unsigned int> & get_target_indices () const
  {
    return target_indices;
  }

  class array<unsigned int> & get_target_indices ()
  {
    return target_indices;
  }

  const class array<double> & get_E_total_tab () const
  {
    return E_total_tab;
  }

  const class array<double> & get_E_kinetic_total_system_CM_tab () const
  {
    return E_kinetic_total_system_CM_tab;
  }

  class array<double> & get_E_kinetic_total_system_CM_tab ()
  {
    return E_kinetic_total_system_CM_tab;
  }

  const class array<double> & get_E_kinetic_projectile_lab_tab () const
  {
    return E_kinetic_projectile_lab_tab;
  }

  class array<double> & get_E_kinetic_projectile_lab_tab ()
  {
    return E_kinetic_projectile_lab_tab;
  }

  const class array<double> & get_E_kinetic_target_lab_inverse_kinematics_tab () const
  {
    return E_kinetic_target_lab_inverse_kinematics_tab;
  }

  class array<double> & get_E_kinetic_target_lab_inverse_kinematics_tab ()
  {
    return E_kinetic_target_lab_inverse_kinematics_tab;
  }

  const class array<unsigned int> & get_N_channels_per_target_projectile_tab () const
  {
    return N_channels_per_target_projectile_tab;
  }

  class array<unsigned int> & get_N_channels_per_target_projectile_tab ()
  {
    return N_channels_per_target_projectile_tab;
  }

  const class array<unsigned int> & get_N_channels_per_target_projectile_in_tab () const
  {
    return N_channels_per_target_projectile_in_tab;
  }

  class array<unsigned int> & get_N_channels_per_target_projectile_in_tab ()
  {
    return N_channels_per_target_projectile_in_tab;
  }

  const class array<unsigned int> & get_N_channels_per_target_projectile_out_tab () const
  {
    return N_channels_per_target_projectile_out_tab;
  }

  class array<unsigned int> & get_N_channels_per_target_projectile_out_tab ()
  {
    return N_channels_per_target_projectile_out_tab;
  }

  const class array<unsigned int> & get_JPi_channels_indices_per_target_projectile () const
  {
    return JPi_channels_indices_per_target_projectile;
  }

  class array<unsigned int> & get_JPi_channels_indices_per_target_projectile ()
  {
    return JPi_channels_indices_per_target_projectile;
  }

  const class array<unsigned int> & get_JPi_channels_indices_per_target_projectile_in () const
  {
    return JPi_channels_indices_per_target_projectile_in;
  }

  class array<unsigned int> & get_JPi_channels_indices_per_target_projectile_in ()
  {
    return JPi_channels_indices_per_target_projectile_in;
  }

  const class array<unsigned int> & get_JPi_channels_indices_per_target_projectile_out () const
  {
    return JPi_channels_indices_per_target_projectile_out;
  }

  class array<unsigned int> & get_JPi_channels_indices_per_target_projectile_out ()
  {
    return JPi_channels_indices_per_target_projectile_out;
  }

  const class array<class CC_channel_class> & get_channels_tab () const
  {
    return channels_tab;
  }

  class array<class CC_channel_class> & get_channels_tab ()
  {
    return channels_tab;
  }

  const class array<class CC_channel_class> & get_channels_in_tab () const
  {
    return channels_in_tab;
  }

  class array<class CC_channel_class> & get_channels_in_tab ()
  {
    return channels_in_tab;
  }

  const class array<class CC_channel_class> & get_channels_out_tab () const
  {
    return channels_out_tab;
  }

  class array<class CC_channel_class> & get_channels_out_tab ()
  {
    return channels_out_tab;
  }

  const class array<complex<double> > & get_e_channels_tab () const
  {
    return e_channels_tab;
  }

  class array<complex<double> > & get_e_channels_tab ()
  {
    return e_channels_tab;
  }

  const class array<complex<double> > & get_k_channels_tab () const
  {
    return k_channels_tab;
  }

  class array<complex<double> > & get_k_channels_tab ()
  {
    return k_channels_tab;
  }

  const class array<complex<double> > & get_eta_channels_tab () const
  {
    return eta_channels_tab;
  }

  class array<complex<double> > & get_eta_channels_tab ()
  {
    return eta_channels_tab;
  }

  const class array<double> & get_CM_angles () const
  {
    return CM_angles;
  }

  class array<double> & get_CM_angles ()
  {
    return CM_angles;
  }

  const class array<double> & get_J_A_tab () const
  {
    return J_A_tab;
  }

  class array<double> & get_J_A_tab ()
  {
    return J_A_tab;
  }

  const class array<unsigned int> & get_BP_A_tab () const
  {
    return BP_A_tab;
  }

  class array<unsigned int> & get_BP_A_tab ()
  {
    return BP_A_tab;
  }

  const class array<unsigned int> & get_vector_index_A_tab () const
  {
    return vector_index_A_tab;
  }

  class array<unsigned int> & get_vector_index_A_tab ()
  {
    return vector_index_A_tab;
  }

  const class array<unsigned int> & get_vector_index_A_out_tab () const
  {
    return vector_index_A_out_tab;
  }

  class array<unsigned int> & get_vector_index_A_out_tab ()
  {
    return vector_index_A_out_tab;
  }

  const class array<unsigned int> & get_N_channels_tab () const
  {
    return N_channels_tab;
  }

  class array<unsigned int> & get_N_channels_tab ()
  {
    return N_channels_tab;
  }

  const class array<unsigned int> & get_N_entrance_channels_tab () const
  {
    return N_entrance_channels_tab;
  }

  class array<unsigned int> & get_N_entrance_channels_tab ()
  {
    return N_entrance_channels_tab;
  }

  const class array<unsigned int> & get_entrance_JPi_channels_indices () const
  {
    return entrance_JPi_channels_indices;
  }

  class array<unsigned int> & get_entrance_JPi_channels_indices ()
  {
    return entrance_JPi_channels_indices;
  }

  const class array<double> & get_J_A_in_tab () const
  {
    return J_A_in_tab;
  }

  class array<double> & get_J_A_in_tab ()
  {
    return J_A_in_tab;
  }

  const class array<double> & get_J_A_out_tab () const
  {
    return J_A_out_tab;
  }

  class array<double> & get_J_A_out_tab ()
  {
    return J_A_out_tab;
  }

  const class array<unsigned int> & get_BP_A_in_tab () const
  {
    return BP_A_in_tab;
  }

  class array<unsigned int> & get_BP_A_in_tab ()
  {
    return BP_A_in_tab;
  }

  const class array<unsigned int> & get_BP_A_out_tab () const
  {
    return BP_A_out_tab;
  }

  class array<unsigned int> & get_BP_A_out_tab ()
  {
    return BP_A_out_tab;
  }

  const class array<unsigned int> & get_N_channels_in_tab () const
  {
    return N_channels_in_tab;
  }

  class array<unsigned int> & get_N_channels_in_tab ()
  {
    return N_channels_in_tab;
  }

  const class array<unsigned int> & get_N_channels_out_tab () const
  {
    return N_channels_out_tab;
  }

  class array<unsigned int> & get_N_channels_out_tab ()
  {
    return N_channels_out_tab;
  }

  const class array<TYPE> & get_beta_suboperator_intrinsic_NBMEs () const
  {
    return beta_suboperator_intrinsic_NBMEs;
  }
  
  class array<TYPE> & get_beta_suboperator_intrinsic_NBMEs ()
  {
    return beta_suboperator_intrinsic_NBMEs;
  }

  const class array<TYPE> & get_beta_suboperator_intrinsic_NBMEs_strength () const
  {
    return beta_suboperator_intrinsic_NBMEs_strength;
  }

  class array<TYPE> & get_beta_suboperator_intrinsic_NBMEs_strength ()
  {
    return beta_suboperator_intrinsic_NBMEs_strength;
  }

  const class array<TYPE> & get_EM_suboperator_intrinsic_NBMEs () const
  {
    return EM_suboperator_intrinsic_NBMEs;
  }

  class array<TYPE> & get_EM_suboperator_intrinsic_NBMEs ()
  {
    return EM_suboperator_intrinsic_NBMEs;
  }

  const class array<TYPE> & get_EM_suboperator_intrinsic_NBMEs_strength () const
  {
    return EM_suboperator_intrinsic_NBMEs_strength;
  }

  class array<TYPE> & get_EM_suboperator_intrinsic_NBMEs_strength ()
  {
    return EM_suboperator_intrinsic_NBMEs_strength;
  }

  const class array<TYPE> & get_scalar_intrinsic_NBMEs () const
  {
    return scalar_intrinsic_NBMEs;
  }

  class array<TYPE> & get_scalar_intrinsic_NBMEs ()
  {
    return scalar_intrinsic_NBMEs;
  }

  const class array<TYPE> & get_scalar_intrinsic_NBMEs_strength () const
  {
    return scalar_intrinsic_NBMEs_strength;
  }

  class array<TYPE> & get_scalar_intrinsic_NBMEs_strength ()
  {
    return scalar_intrinsic_NBMEs_strength;
  }

  const class array<double> & get_effective_charges_p () const
  {
    return effective_charges_p;
  }

  const class array<double> & get_effective_charges_n () const
  {
    return effective_charges_n;
  }
  
  friend double used_memory_calc (const class CC_target_projectile_composite_data &T);
  
private:

  int Z; // Number of protons  of the target-projectile composite
  int N; // Number of neutrons of the target-projectile composite
  int A; // Number of nucleons of the target-projectile composite
  
  int S; // Strangeness of the target-projectile composite
  
  bool initial_pivot_from_file; // True if one uses a starting point from file to calculate GSM-CC eigenstates with the Jacobi-Davidson method, false if one uses pole approximation as starting point.
  
  bool truncation_hw; // true if one truncates in energy, given there in units of hbar omega (which can be used as arbitrary units as well), false if not
  bool truncation_ph; // true if one truncates with respect to particle number in the continuum, false if not
  
  int n_holes_max;        // maximal number of nucleon holes in core states at full space level
  int n_scat_max;         // maximal number of baryons in the continuum
  int E_relative_max_hw;  // maximal truncation energy of configurations at full space level with respect to the ground state configuration

  enum CC_reaction_type CC_reaction;                          // CC reaction type: scattering or radiative capture
  
  enum CC_reaction_calculation_type CC_reaction_calculation;  // CC calculation that is done: poles (i.e. CC Hamiltonian diagonalization), phase shifts, differential or total cross sections, excitation function
    
  enum particle_type entrance_projectile;   // particle type of the projectile in the entrance channel for scattering states.
  
  double mass_entrance_projectile;                       // mass of the  projectile in the entrance channel for scattering states.
  double CM_to_work_frame_kinetic_factor;                // Kinetic coefficient to transform a value in the CM frame to that of the work frame (COSM with a core, CM without a core)
  double work_frame_to_lab_kinetic_factor;               // Kinetic coefficient to transform a value in the work frame (COSM with a core, CM without a core) to that of the lab frame
  double CM_to_lab_kinetic_factor;                       // Kinetic coefficient to transform a value in the CM frame to that of the lab frame
  double kinetic_factor_entrance_projectile_work_frame;  // 2mu[projectile]/hbar^2 value in the entrance channel in the work frame (COSM with a core, CM without a core)
  double kinetic_factor_entrance_projectile_CM;          // 2mu[projectile]/hbar^2 value in the entrance channel in the CM frame
  
  int Z_target; // Number of protons  of the target in the entrance channel
  int N_target; // Number of neutrons of the target in the entrance channel
  int A_target; // Number of nucleons of the target in the entrance channel
  
  double mass_target; // Mass of the target in the entrance channel

  bool are_GSM_a_dagger_vectors_calculated; // true if one calculates all GSM vectors of the form A+(projectile)|target> to build CC equations, false if they are read from disk as they are already stored
  
  unsigned int N_JPi_A;      // Number of J-Pi states in GSM-CC for scattering reaction cross sections, pole and phase shifts calculations
  unsigned int N_JPi_A_in;   // Number of J-Pi states in GSM-CC in the  input composite states for radiative capture reactions
  unsigned int N_JPi_A_out;  // Number of J-Pi states in GSM-CC in the output composite states for radiative capture reactions
  
  unsigned int N_target_projectile_states; // Total number of target-projectile states in the GSM-CC calculation
  unsigned int entrance_target_index;      // Index of the entrance channel among all the target-projectile states in the GSM-CC calculation
  unsigned int N_entrance_channels_max;    // Maximal number of entrance channels
  
  double J_intrinsic_projectile_max;       // Maximal intrinsic total angular momentum in all projectiles
  
  unsigned int N_energies;                 // Number of projectile energies considered for the calculation of reaction observables
  unsigned int N_CM_angles;                // Number of angles of the center of mass angular part in its partial wave decomposition for the calculation of angular dependent cross sections
  unsigned int cluster_projectile_number;  // Number of different clusters used in the CC equations. For example, it is 2 for (d,p) reactions if one considers only deuteron and proton channels
  
  bool is_it_one_baryon_COSM_case;         // True if the projectile has only one particle (proton, neutron, ...) and that one works in the COSM frame, hence with a core, false for all other cases (deuteron, no core, ...)
  
  enum EM_type EM_for_radiative_capture_cross_section; // One can calculate radiative capture cross sections of only electric or magnetic type. This type is given here.
  
  int L_for_radiative_capture_cross_section;           // Maximal orbital angular momentum of the CM part of the projectile considered in total cross sections
  
  unsigned int N_theta_gamma;                          // Number of theta angles used in the calculation of differential cross sections of radiative capture (gamma is for photon)
  unsigned int N_phi_gamma;                            // Number of phi   angles used in the calculation of differential cross sections of radiative capture (gamma is for photon)
  
  bool radiative_capture_is_it_longwavelength_approximation; // true if one uses longwavelength approximation in radiative capture, false if not
  bool radiative_capture_is_it_HO_expansion;                 // true if one expands channels with HO states, false if not
    
  unsigned int N_channels;                // number of channels used in the GSM-CC Hamiltonian for scattering reaction cross sections, pole and phase shifts calculations
  unsigned int N_channels_in;             // number of channels used in the GSM-CC Hamiltonian in the  input composite states for radiative capture reactions
  unsigned int N_channels_out;            // number of channels used in the GSM-CC Hamiltonian in the output composite states for radiative capture reactions

  unsigned int N_restarts;                // Maximal number of restarts of Lanczos or Jacobi-Davidson method, i.e. with a new starting pivot vector. 
                                          // One restarts if all Lanzos or Jacobi-Davidson vectors have been used without having convergence

  unsigned int Davidson_max_dimension;    // Maximal number of Jacobi-Davidson vectors used in Hamiltonian diagonalization

  double Davidson_eigenvector_precision;  // Precision under which one considers that the Jacobi-Davidson method converges.

  double relative_SVD_precision;          // eigenvalues of the matrix of the overlap matrices to invert in the CC equations to orthogonalize channels are ignored in the solution 
                                          // if they are smaller in modulus than CC_relative_SVD_precision when inverting the linear system with the Moore-Penrose pseudo-inverse

  double R_cut_function;                  // diffuseness of the Fermi cut function F(r) (see basic_maths.cpp) used in HF/MSDHF/OCM potentials for stability
  double d_cut_function;                  // radius      of the Fermi cut function F(r) (see basic_maths.cpp) used in HF/MSDHF/OCM potentials for stability

  double Ueq_regularizor;                 // Regularization factor used in the equivalent HF/MSDHF/OCM potential (see above)

  class array<enum particle_type> projectile_tab; // array of type of projectile or ejectile in the considered reaction: proton, neutron, hyperon, deuteron, ....
  
  class array<unsigned int> BP_target_tab; // array of binary parities (see observables_basic_functions.cpp for definition) of the target states
  
  class array<double> J_target_tab; // array of total angular momenta of the target states
  
  class array<unsigned int> vector_index_target_tab; // array of vector indices of fixed J-Pi quantum numbers of the target states (e.g. 1 for the first 0+ excited state) 
  
  class array<bool> is_it_pole_target_tab; // array of booleans which are true if the target state is bound or resonant, and false if it is scattering
  
  class array<double> real_E_target_tab; // array of projectile or ejectile energies (MeV)
  class array<double> Gamma_target_tab;  // array of projectile or ejectile widths   (keV)
  
  class array<TYPE> E_target_tab; // array of projectile or ejectile complex energies (MeV)
  
  class array<double> real_E_intrinsic_projectile_tab; // array of projectile or ejectile intrinsic energies (MeV)
  class array<double> Gamma_intrinsic_projectile_tab;  // array of projectile or ejectile intrinsic widths   (keV)
  
  class array<TYPE> E_intrinsic_projectile_tab; // array of projectile or ejectile intrinsic complex energies (MeV)
  
  class array<complex<double> > average_n_scat_target_tab; // array of average number of one-body scattering states in the considered composite nuclear state for truncation
  
  class array<unsigned int> target_indices; // array of the target indices used in the code as a function of parity, J and vector index.
  
  class array<double> E_total_tab; // array of the used total target-projectile composite energies in cross sections or phase shifts in the work frame (COSM with a core, CM without a core)
  
  class array<double> E_kinetic_total_system_CM_tab;               // array of the used total kinetic target-projectile composite energies in cross sections or phase shifts in the CM frame
  class array<double> E_kinetic_projectile_lab_tab;                // array of the used projectile energies in cross sections or phase shifts in the lab frame
  class array<double> E_kinetic_target_lab_inverse_kinematics_tab; // array of the used target energies in cross sections calculated in inverse kinematics in the lab frame
  
  class array<unsigned int> N_channels_per_target_projectile_tab;           // number  of channels per fixed target and total J-Pi values for scattering reaction cross sections, pole and phase shifts calculations
  class array<unsigned int> N_channels_per_target_projectile_in_tab;        // number  of channels per fixed target and total J-Pi values in the  input composite states for radiative capture reactions
  class array<unsigned int> N_channels_per_target_projectile_out_tab;       // number  of channels per fixed target and total J-Pi values in the output composite states for radiative capture reactions
  class array<unsigned int> JPi_channels_indices_per_target_projectile;     // Indices of channels per fixed target and total J-Pi values for scattering reaction cross sections, pole and phase shifts calculations
  class array<unsigned int> JPi_channels_indices_per_target_projectile_in;  // Indices of channels per fixed target and total J-Pi values in the  input composite states for radiative capture reactions
  class array<unsigned int> JPi_channels_indices_per_target_projectile_out; // Indices of channels per fixed target and total J-Pi values in the output composite states for radiative capture reactions
  
  class array<class CC_channel_class> channels_tab;      // channels used in the GSM-CC Hamiltonian for scattering reaction cross sections, pole and phase shifts calculations
  class array<class CC_channel_class> channels_in_tab;   // channels used in the GSM-CC Hamiltonian in the  input composite states for radiative capture reactions
  class array<class CC_channel_class> channels_out_tab;  // channels used in the GSM-CC Hamiltonian in the output composite states for radiative capture reactions
  
  class array<complex<double> > e_channels_tab;   // array of projectile energies             as a function of composite and total energy. It is in COSM frame with a core and in the CM frame of the composite without a core.
  class array<complex<double> > k_channels_tab;   // array of projectile linear momenta       as a function of composite and total energy. It is in COSM frame with a core and in the CM frame of the composite without a core.
  class array<complex<double> > eta_channels_tab; // array of projectile Sommerfeld parameter as a function of composite and total energy. It is in COSM frame with a core and in the CM frame of the composite without a core.
  
  class array<double> CM_angles; // Values of the angles used in angular-dependent reaction observables. They are given in degrees in the input file and converted to radians afterwards.

  class array<double> J_A_tab;                  // array of total angular momenta of the composite (scattering only)  
  class array<unsigned int> BP_A_tab;           // array of binary parities (see observables_basic_functions.cpp for definition) of the composite (scattering only)
  class array<unsigned int> vector_index_A_tab; // array of vector indices of fixed J-Pi quantum numbers of the composite (e.g. 1 for the first 0+ excited state) (scattering only)
  
  
  class array<unsigned int> N_channels_tab;                // number of          channels per total J-Pi value for scattering reaction cross sections, pole and phase shifts calculations
  class array<unsigned int> N_entrance_channels_tab;       // number of entrance channels per total J-Pi value for scattering reaction cross sections, pole and phase shifts calculations
  class array<unsigned int> entrance_JPi_channels_indices; // entrance channel indices    per total J-Pi value for scattering reaction cross sections, pole and phase shifts calculations
  
  class array<double> J_A_in_tab;  // array of total angular momenta of the incoming composite (radiative capture only)
  class array<double> J_A_out_tab; // array of total angular momenta of the formed nucleus (radiative capture only)
  
  class array<unsigned int> BP_A_in_tab;            // array of binary parities (see observables_basic_functions.cpp for definition) of the incoming composite (radiative capture only)
  class array<unsigned int> BP_A_out_tab;           // array of binary parities (see observables_basic_functions.cpp for definition) of the formed nucleus (radiative capture only)
  class array<unsigned int> vector_index_A_out_tab; // array of vector indices of fixed J-Pi quantum numbers of the formed nucleus (e.g. 1 for the first 0+ excited state) (radiative capture only)
  class array<unsigned int> N_channels_in_tab;      // number of channels per total J-Pi value in the  input composite states for radiative capture reactions
  class array<unsigned int> N_channels_out_tab;     // number of channels per total J-Pi value in the output composite states for radiative capture reactions

  // The next arrays must recalculated for each observable listed in the input file
  
  class array<TYPE> beta_suboperator_intrinsic_NBMEs;          //                       reduced beta transition matrix elements for all suboperators between the intrinsic parts of two clusters
  class array<TYPE> beta_suboperator_intrinsic_NBMEs_strength; // strength functions of reduced beta transition matrix elements for all suboperators between the intrinsic parts of two clusters
  
  class array<TYPE> EM_suboperator_intrinsic_NBMEs;          //                       reduced EM matrix elements for all suboperators between the intrinsic parts of two clusters
  class array<TYPE> EM_suboperator_intrinsic_NBMEs_strength; // strength functions of reduced EM matrix elements for all suboperators between the intrinsic parts of two clusters
  
  class array<TYPE> scalar_intrinsic_NBMEs;          // matrix elements   of a scalar operator between the intrinsic parts of two clusters
  class array<TYPE> scalar_intrinsic_NBMEs_strength; // strength function of a scalar operator between the intrinsic parts of two clusters
  
  class array<double> effective_charges_p; // effective charges of   charged baryons used in electro-magnetic transitions
  class array<double> effective_charges_n; // effective charges of uncharged baryons used in electro-magnetic transitions
};



#endif


