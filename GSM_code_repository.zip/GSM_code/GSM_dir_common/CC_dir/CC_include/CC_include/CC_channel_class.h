#ifndef CCCHANNELCLASS_H
#define CCCHANNELCLASS_H



// Class containing information about a reaction channel
// -----------------------------------------------------
// A channel read |T[c] projectile[c],r>, where T[c] is the target and projectile[c] is the projectile.
// J[T[c]] and J[projectile[c]] are coupled to J.

class CC_channel_class
{
public:
  CC_channel_class ();

  CC_channel_class (
		    const enum interaction_type inter , 
		    const double prot_mass_for_calc , 
		    const double neut_mass_for_calc ,
		    const double    Y_mass_for_calc ,  
		    const double nucleus_mass , 
		    const double b_lab , 
		    const int Z , 
		    const int N , 
		    const int S , 
		    const enum particle_type projectile_c , 
		    const unsigned int BP_Tc_c , 
		    const double J_Tc_c , 
		    const unsigned int vector_index_Tc_c , 
		    const bool S_matrix_pole_Tc_c ,  
		    const complex<double> &E_Tc_c , 
		    const complex<double> &E_intrinsic_projectile_c_c , 
		    const complex<double> &average_n_scat_Tc_c , 
		    const int LCM_projectile_c , 
		    const double J_projectile_c , 
		    const unsigned int vector_index_c , 
		    const double J_c , 
		    const double M_c , 
		    const complex<double> &E_c , 
		    const bool is_it_HO_channel_decomposition_c);
  
  CC_channel_class (const class CC_channel_class &X);
  
  void initialize (
		   const enum interaction_type inter , 
		   const double prot_mass_for_calc , 
		   const double neut_mass_for_calc , 
		   const double    Y_mass_for_calc , 
		   const double nucleus_mass , 
		   const double b_lab , 
		   const int Z , 
		   const int N , 
		   const int S , 
		   const enum particle_type projectile_c , 
		   const unsigned int BP_Tc_c , 
		   const double J_Tc_c , 
		   const unsigned int vector_index_Tc_c , 
		   const bool S_matrix_pole_Tc_c ,  
		   const complex<double> &E_Tc_c , 
		   const complex<double> &E_intrinsic_projectile_c_c , 
		   const complex<double> &average_n_scat_Tc_c , 
		   const int LCM_projectile_c , 
		   const double J_projectile_c , 
		   const unsigned int vector_index_c , 
		   const double J_c , 
		   const double M_c , 
		   const complex<double> &E_c , 
		   const bool is_it_HO_channel_decomposition_c);

  void initialize (const class CC_channel_class &X);
  
  void allocate_fill (const class CC_channel_class &X);

  void operator = (const class CC_channel_class &X);
  
  enum particle_type get_projectile () const
  {
    return projectile;
  }
  
  enum particle_type get_Tc_no_core () const
  {
    return Tc_no_core;
  }
  
  int get_Z_Tc () const
  {
    return Z_Tc;
  }

  int get_N_Tc () const
  {
    return N_Tc;
  }

  int get_A_Tc () const
  {
    return A_Tc;
  }

  int get_S_Tc () const
  {
    return S_Tc;
  }
  
  unsigned int get_BP_Tc () const
  {
    return BP_Tc;
  }

  double get_J_Tc () const
  {
    return J_Tc;
  }

  unsigned int get_vector_index_Tc () const
  {
    return vector_index_Tc;
  }

  bool get_S_matrix_pole_Tc () const
  {
    return S_matrix_pole_Tc;
  }
 
  double get_mass_Tc () const
  {
    return mass_Tc;
  }

  complex<double> get_E_Tc () const
  {
    return E_Tc;
  }

  complex<double> get_E_intrinsic_projectile_c () const
  {
    return E_intrinsic_projectile_c;
  }

  complex<double> get_average_n_scat_Tc () const
  {
    return average_n_scat_Tc;
  }

  int get_Z_projectile () const
  {
    return Z_projectile;
  }

  int get_N_projectile () const
  {
    return N_projectile;
  }

  int get_A_projectile () const
  {
    return A_projectile;
  }

  int get_S_projectile () const
  {
    return S_projectile;
  }
  
  bool get_S_matrix_pole_projectile () const
  {
    return S_matrix_pole_projectile;
  }

  double get_mass_projectile () const
  {
    return mass_projectile;
  }

  double get_b_HO_potentials_projectile () const
  {
    return b_HO_potentials_projectile;
  }

  int get_LCM_projectile () const
  {
    return LCM_projectile;
  }

  unsigned int get_BP_LCM_projectile () const
  {
    return BP_LCM_projectile;
  }

  double get_kinetic_factor_projectile () const
  {
    return kinetic_factor_projectile;
  }

  unsigned int get_BP_intrinsic_projectile () const
  {
    return BP_intrinsic_projectile;
  }

  double get_J_intrinsic_projectile () const
  {
    return J_intrinsic_projectile;
  }

  unsigned int get_BP_projectile () const
  {
    return BP_projectile;
  }

  double get_J_projectile () const
  {
    return J_projectile;
  }

  complex<double> get_e_projectile () const
  {
    return e_projectile;
  }

  complex<double> get_k_projectile () const
  {
    return k_projectile;
  }

  complex<double> get_eta_projectile () const
  {
    return eta_projectile;
  }

  int get_Z_Tc_charge () const
  {
    return Z_Tc_charge;
  }

  unsigned int get_BP () const
  {
    return BP;
  }

  unsigned int get_vector_index () const
  {
    return vector_index;
  }

  double get_J () const
  {
    return J;
  }

  double get_M () const
  {
    return M;
  }

  complex<double> get_E () const
  {
    return E;
  }

  bool get_is_it_HO_channel_decomposition () const
  {
    return is_it_HO_channel_decomposition;
  }
  
  void E_dependent_values_change (const complex<double> &E_c);

  string channel_string_for_file_name () const;

private:
  
  enum particle_type projectile; // Projectile type

  enum particle_type Tc_no_core; // Target type (no-core calculations only)

  int Z_Tc; // Number of protons  of the target
  int N_Tc; // Number of neutrons of the target
  int A_Tc; // Number of nucleons of the target
  
  int S_Tc; // Strangeness of the target
  
  unsigned int BP_Tc; // Binary parity of the target (see observables_basic_functions.cpp)

  double J_Tc; // Total angular momentum of the target

  unsigned int vector_index_Tc; // Index of the target eigenstate (0,1,2,... if one has ground state , first, second, ... excited state)

  bool S_matrix_pole_Tc; // True if the target state is an S-matrix pole state, false if not

  double mass_Tc; // Mass of the target

  complex<double> E_Tc; // Energy of the target. It is in COSM frame with a core and in the intrinsic frame of the target without a core.

  complex<double> E_intrinsic_projectile_c; // Intrinsic energy of the projectile. It is always in the intrinsic frame of the projectile.

  complex<double> average_n_scat_Tc; // Average number of scattering states occupied in the target eigenstate

  int Z_projectile; // Number of protons  of the projectile
  int N_projectile; // Number of neutrons of the projectile
  int A_projectile; // Number of nucleons of the projectile
  
  int S_projectile; // Strangeness of the projectile
  
  bool S_matrix_pole_projectile; // True if the projectile state is an S-matrix pole state, false if not

  double mass_projectile; // Mass of the projectile
  
  double b_HO_potentials_projectile; // Used oscillator length for the projectile CM states

  int LCM_projectile; // Orbital angular momentum of the CM of the projectile

  unsigned int BP_LCM_projectile; // Binary parity of the CM of the projectile (see observables_basic_functions.cpp)

  double kinetic_factor_projectile;  // 2mu[projectile]/hbar^2

  unsigned int BP_intrinsic_projectile; // Binary parity of the intrinsic part of the projectile (see observables_basic_functions.cpp)

  double J_intrinsic_projectile; // Total angular momentum of the intrinsic part of the projectile

  unsigned int BP_projectile; // Binary parity of the projectile including both intrinsic and CM parts (see observables_basic_functions.cpp)

  double J_projectile; // Total angular momentum of the projectile including both intrinsic and CM parts

  complex<double> e_projectile; // Energy of the projectile. It is in COSM frame with a core and in the CM frame of the target-projectile composite without a core.
  
  complex<double> k_projectile; // Linear momentum of the projectile associated to its energy

  complex<double> eta_projectile; // Sommerfeld parameter of the projectile associated to its energy

  int Z_Tc_charge; // Charge of the nucleus creating the potential (charged particle only). It can contain the effect of hyperons.

  unsigned int BP; // Binary parity of the target-projectile composite (see observables_basic_functions.cpp)

  unsigned int vector_index; // Index of the target-projectile composite (0,1,2,... if one has ground state , first, second, ..., excited state). It is NADA for scattering states.
  
  double J; // Total angular momentum            of the target-projectile composite
  double M; // Total angular momentum projection of the target-projectile composite

  complex<double> E; // Energy of the target-projectile composite. It is in COSM frame with a core and in the CM frame of the target-projectile composite without a core.

  bool is_it_HO_channel_decomposition; // True if the channel wave functions (i.e. target and projectile states) are decomposed in an HO basis, false if not
};

ostream& operator << (ostream &os , const class CC_channel_class &channel_c);

double used_memory_calc (const class CC_channel_class &T);

#endif


