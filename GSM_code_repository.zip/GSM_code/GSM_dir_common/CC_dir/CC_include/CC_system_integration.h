#ifndef CCSYSTEMINTEGRATION_H
#define CCSYSTEMINTEGRATION_H


/* CC_system_integration (class):
   _ contains functions to integrate the ...

   One uses the Burlisch-Stoer-Henrici method , where one integrates on different meshes
   with the Henrici method , and then use the Richardson method to extrapolate the final result. 
*/


class CC_system_integration
{
public:

  CC_system_integration ();
  
  CC_system_integration (
			 const bool is_it_entrance_channel_only_c , 
			 const unsigned int ic_entrance_c , 
			 const unsigned int N_channels_c , 
			 const class potentials_effective_mass &T , 
			 const class array<class CC_channel_class> &channels_tab ,  
			 const complex<double> &source_basis_factor_c);

  CC_system_integration (const class CC_system_integration &X);
 
  ~CC_system_integration ();

  void allocate (
		 const bool is_it_entrance_channel_only_c , 
		 const unsigned int ic_entrance_c , 
		 const unsigned int N_channels_c , 
		 const class potentials_effective_mass &T , 
		 const class array<class CC_channel_class> &channels_tab ,  
		 const complex<double> &source_basis_factor_c);
 
  void allocate_fill (const class CC_system_integration &X);
  
  void deallocate ();
  
  void operator() (
		   const double r0 , 
		   const class vector_class<complex<double> > &U0 , 
		   const class vector_class<complex<double> > &dU0 , 
		   const double r , 
		   class vector_class<complex<double> > &U , 
		   class vector_class<complex<double> > &dU);

  friend double used_memory_calc (const class CC_system_integration &T);
  
private:

  const class potentials_effective_mass & get_T () const
  {
    return *T_ptr;
  }
  
  void extrapolation_in_zero (
			      const unsigned int n , 
			      const class vector_class<complex<double> > F[] , 
			      class vector_class<complex<double> > &F_in_zero);

  void F_r_U_tab_calc (
		       const double r , 
		       const class vector_class<complex<double> > &U , 
		       class vector_class<complex<double> > &F_r_U_tab);

  void integration_Henrici (
			    const unsigned int m , 
			    const double h , 
			    const double r0 , 
			    const class vector_class<complex<double> > &U0 , 
			    const class vector_class<complex<double> > &dU0 , 
			    const double r , 
			    class vector_class<complex<double> > &U , 
			    class vector_class<complex<double> > &dU);

  bool is_it_entrance_channel_only; 

  unsigned int ic_entrance;
  unsigned int N_channels;

  const class potentials_effective_mass *T_ptr;
  
  complex<double> source_basis_factor;

  unsigned int m_tab[7];                   // integers used in the extrapolation method.

  double one_over_m_tab[7];                // doubles used in the extrapolation method.

  double interpolation_term_tab[28];       // doubles used in the extrapolation method.

  mutable double H_over_m_tab[7];          // doubles storing H/m, when one integrates from r0 to r = r0 + m.H
  
  class array<int> LCM_projectile_LCM_projectile_plus_one_tab;
  
  class array<double> kinetic_factor_projectile_tab;

  class array<complex<double> > e_projectile_tab;

  class vector_class<complex<double> > h_square_F_r_U_tab;
  class vector_class<complex<double> > U_debut;
  class vector_class<complex<double> > dU_debut;
  class vector_class<complex<double> > U_end[7];
  class vector_class<complex<double> > dU_end[7];
  class vector_class<complex<double> > U_extrapolated;
  class vector_class<complex<double> > U_extrapolated_next;
  class vector_class<complex<double> > dU_extrapolated_next;
  class vector_class<complex<double> > Res;
  class vector_class<complex<double> > Delta;
};

#endif


