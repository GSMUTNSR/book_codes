#ifndef CC_TARGET_PROJECTILE_COMPOSITE_DATA_H
#define CC_TARGET_PROJECTILE_COMPOSITE_DATA_H


class CC_target_projectile_composite_data
{
public:

  CC_target_projectile_composite_data ();
    
  CC_target_projectile_composite_data (
				       const class input_data_str &input_data , 
				       const class nucleons_data &prot_data , 
				       const class nucleons_data &neut_data);

  CC_target_projectile_composite_data (const class CC_target_projectile_composite_data &X);

  ~CC_target_projectile_composite_data ();
  
  void allocate (
		 const class input_data_str &input_data , 
		 const class nucleons_data &prot_data , 
		 const class nucleons_data &neut_data);

  void allocate_fill (const class CC_target_projectile_composite_data &X);

  void deallocate ();

  bool is_it_filled () const
  {
    return (CC_reaction != NO_REACTION);
  }
  
  int get_Z () const
  {
    return Z;
  }
  
  int get_N () const
  {
    return N;
  }

  int get_A () const
  {
    return A;
  }

  bool get_truncation_hw () const
  {
    return truncation_hw;
  }

  bool get_truncation_ph () const
  {
    return truncation_ph;
  }

  int get_n_holes_max () const
  {
    return n_holes_max;
  }
  
  int get_n_scat_max () const
  {
    return n_scat_max;
  }

  int get_E_relative_max_hw () const
  {
    return E_relative_max_hw;
  }

  enum CC_reaction_type get_CC_reaction () const
  {
    return CC_reaction;
  }

  enum CC_reaction_calculation_type get_CC_reaction_calculation () const
  {
    return CC_reaction_calculation;
  }

  enum particle_type get_entrance_projectile () const
  {
    return entrance_projectile;
  }

  double get_mass_entrance_projectile () const
  {
    return mass_entrance_projectile;
  }

  double get_CM_to_work_frame_kinetic_factor () const
  {
    return CM_to_work_frame_kinetic_factor;
  }

  double get_work_frame_to_lab_kinetic_factor () const
  {
    return work_frame_to_lab_kinetic_factor;
  }
  
  double get_CM_to_lab_kinetic_factor () const
  {
    return CM_to_lab_kinetic_factor;
  }
 
  double get_kinetic_factor_entrance_projectile_work_frame () const
  {
    return kinetic_factor_entrance_projectile_work_frame;
  }

  double get_kinetic_factor_entrance_projectile_CM () const
  {
    return kinetic_factor_entrance_projectile_CM;
  }

  int get_Z_target () const
  {
    return Z_target;
  }

  int get_N_target () const
  {
    return N_target;
  }

  int get_A_target () const
  {
    return A_target;
  }

  double get_mass_target () const
  {
    return mass_target;
  }
  
  bool get_are_GSM_a_dagger_vectors_calculated () const
  {
    return are_GSM_a_dagger_vectors_calculated;
  }

  unsigned int get_N_JPi_A () const
  {
    return N_JPi_A;
  }

  unsigned int get_N_JPi_A_in () const
  {
    return N_JPi_A_in;
  }

  unsigned int get_N_JPi_A_out () const
  {
    return N_JPi_A_out;
  }

  unsigned int get_N_target_projectile_states () const
  {
    return N_target_projectile_states;
  }

  unsigned int get_entrance_target_index () const
  {
    return entrance_target_index;
  }

  unsigned int get_N_entrance_channels_max () const
  {
    return N_entrance_channels_max;
  }

  double get_J_intrinsic_projectile_max () const
  {
    return J_intrinsic_projectile_max;
  }

  unsigned int get_N_energies () const
  {
    return N_energies;
  }

  unsigned int get_N_CM_angles () const
  {
    return N_CM_angles;
  }

  unsigned int get_cluster_projectile_number () const
  {
    return cluster_projectile_number;
  }

  bool get_is_it_one_nucleon_COSM_case () const
  {
    return is_it_one_nucleon_COSM_case;
  }

  enum EM_type get_EM_for_total_cross_section () const
  {
    return EM_for_total_cross_section;
  }

  int get_L_for_total_cross_section () const
  {
    return L_for_total_cross_section;
  }

  int get_radiative_capture_L_limit () const
  {
    return radiative_capture_L_limit;
  }

  unsigned int get_N_theta_gamma () const
  {
    return N_theta_gamma;
  }

  unsigned int get_N_phi_gamma () const
  {
    return N_phi_gamma;
  }

  bool get_radiative_capture_is_it_longwavelength_approximation () const
  {
    return radiative_capture_is_it_longwavelength_approximation;
  }

  bool get_radiative_capture_is_it_HO_expansion () const
  {
    return radiative_capture_is_it_HO_expansion;
  }

  double get_prot_effective_charge () const
  {
    return prot_effective_charge;
  }

  double get_neut_effective_charge () const
  {
    return neut_effective_charge;
  }
  
  void set_N_channels (const unsigned int N_channels_c)
  {
    N_channels = N_channels_c;
  }
  
  unsigned int get_N_channels () const
  {
    return N_channels;
  }
  
  void set_N_channels_in (const unsigned int N_channels_in_c)
  {
    N_channels_in = N_channels_in_c;
  }
  
  unsigned int get_N_channels_in () const
  {
    return N_channels_in;
  }
  
  void set_N_channels_out (const unsigned int N_channels_out_c)
  {
    N_channels_out = N_channels_out_c;
  }
  
  unsigned int get_N_channels_out () const
  {
    return N_channels_out;
  }
   
  unsigned int get_N_restarts () const
  {
    return N_restarts;
  }

  unsigned int get_Davidson_max_dimension () const
  {
    return Davidson_max_dimension;
  }

  double get_Davidson_eigenvector_precision () const
  {
    return Davidson_eigenvector_precision;
  }

  double get_relative_SVD_precision () const
  {
    return relative_SVD_precision;
  }

  double get_R_cut_function () const
  {
    return R_cut_function;
  }

  double get_d_cut_function () const
  {
    return d_cut_function;
  }

  double get_Ueq_regularizor () const
  {
    return Ueq_regularizor;
  }

  double get_CC_average_n_scat_target_projectile_max () const
  {
    return CC_average_n_scat_target_projectile_max;
  }

  const class array<enum particle_type> & get_projectile_tab () const
  {
    return projectile_tab;
  }
 
  class array<enum particle_type> & get_projectile_tab ()
  {
    return projectile_tab;
  }
  
  const class array<unsigned int> & get_BP_target_tab () const
  {
    return BP_target_tab;
  }

  class array<unsigned int> & get_BP_target_tab ()
  {
    return BP_target_tab;
  }

  const class array<double> & get_J_target_tab () const
  {
    return J_target_tab;
  }

  class array<double> & get_J_target_tab ()
  {
    return J_target_tab;
  }

  const class array<unsigned int> & get_vector_index_target_tab () const
  {
    return vector_index_target_tab;
  }	

  class array<unsigned int> & get_vector_index_target_tab ()
  {
    return vector_index_target_tab;
  }	

  const class array<bool> & get_is_it_pole_target_tab () const
  {
    return is_it_pole_target_tab;
  }

  class array<bool> & get_is_it_pole_target_tab ()
  {
    return is_it_pole_target_tab;
  }

  const class array<double> & get_real_E_target_tab () const
  {
    return real_E_target_tab;
  }

  class array<double> & get_real_E_target_tab ()
  {
    return real_E_target_tab;
  }

  const class array<double> & get_Gamma_target_tab () const
  {
    return Gamma_target_tab;
  }

  class array<double> & get_Gamma_target_tab ()
  {
    return Gamma_target_tab;
  }

  const class array<TYPE> & get_E_target_tab () const
  {
    return E_target_tab;
  }

  class array<TYPE> & get_E_target_tab ()
  {
    return E_target_tab;
  }

  const class array<double> & get_real_E_intrinsic_projectile_tab () const
  {
    return real_E_intrinsic_projectile_tab;
  }

  class array<double> & get_real_E_intrinsic_projectile_tab ()
  {
    return real_E_intrinsic_projectile_tab;
  }

  const class array<double> & get_Gamma_intrinsic_projectile_tab () const
  {
    return Gamma_intrinsic_projectile_tab;
  }

  class array<double> & get_Gamma_intrinsic_projectile_tab ()
  {
    return Gamma_intrinsic_projectile_tab;
  }

  const class array<TYPE> & get_E_intrinsic_projectile_tab () const
  {
    return E_intrinsic_projectile_tab;
  }

  class array<TYPE> & get_E_intrinsic_projectile_tab ()
  {
    return E_intrinsic_projectile_tab;
  }

  const class array<complex<double> > & get_average_n_scat_target_tab () const
  {
    return average_n_scat_target_tab;
  }

  class array<complex<double> > & get_average_n_scat_target_tab ()
  {
    return average_n_scat_target_tab;
  }

  const class array<unsigned int> & get_target_indices () const
  {
    return target_indices;
  }

  class array<unsigned int> & get_target_indices ()
  {
    return target_indices;
  }

  const class array<double> & get_E_total_tab () const
  {
    return E_total_tab;
  }

  const class array<double> & get_E_kinetic_total_system_CM_tab () const
  {
    return E_kinetic_total_system_CM_tab;
  }

  class array<double> & get_E_kinetic_total_system_CM_tab ()
  {
    return E_kinetic_total_system_CM_tab;
  }

  const class array<double> & get_E_kinetic_projectile_lab_tab () const
  {
    return E_kinetic_projectile_lab_tab;
  }

  class array<double> & get_E_kinetic_projectile_lab_tab ()
  {
    return E_kinetic_projectile_lab_tab;
  }

  const class array<double> & get_E_kinetic_target_lab_inverse_kinematics_tab () const
  {
    return E_kinetic_target_lab_inverse_kinematics_tab;
  }

  class array<double> & get_E_kinetic_target_lab_inverse_kinematics_tab ()
  {
    return E_kinetic_target_lab_inverse_kinematics_tab;
  }

  const class array<unsigned int> & get_N_partial_waves () const
  {
    return N_partial_waves;
  }

  class array<unsigned int> & get_N_partial_waves ()
  {
    return N_partial_waves;
  }

  const class array<unsigned int> & get_N_channels_per_target_projectile_tab () const
  {
    return N_channels_per_target_projectile_tab;
  }

  class array<unsigned int> & get_N_channels_per_target_projectile_tab ()
  {
    return N_channels_per_target_projectile_tab;
  }

  const class array<unsigned int> & get_N_channels_per_target_projectile_in_tab () const
  {
    return N_channels_per_target_projectile_in_tab;
  }

  class array<unsigned int> & get_N_channels_per_target_projectile_in_tab ()
  {
    return N_channels_per_target_projectile_in_tab;
  }

  const class array<unsigned int> & get_N_channels_per_target_projectile_out_tab () const
  {
    return N_channels_per_target_projectile_out_tab;
  }

  class array<unsigned int> & get_N_channels_per_target_projectile_out_tab ()
  {
    return N_channels_per_target_projectile_out_tab;
  }

  const class array<unsigned int> & get_JPi_channels_indices_per_target_projectile () const
  {
    return JPi_channels_indices_per_target_projectile;
  }

  class array<unsigned int> & get_JPi_channels_indices_per_target_projectile ()
  {
    return JPi_channels_indices_per_target_projectile;
  }

  const class array<unsigned int> & get_JPi_channels_indices_per_target_projectile_in () const
  {
    return JPi_channels_indices_per_target_projectile_in;
  }

  class array<unsigned int> & get_JPi_channels_indices_per_target_projectile_in ()
  {
    return JPi_channels_indices_per_target_projectile_in;
  }

  const class array<unsigned int> & get_JPi_channels_indices_per_target_projectile_out () const
  {
    return JPi_channels_indices_per_target_projectile_out;
  }

  class array<unsigned int> & get_JPi_channels_indices_per_target_projectile_out ()
  {
    return JPi_channels_indices_per_target_projectile_out;
  }

  const class array<class CC_channel_class> & get_channels_tab () const
  {
    return channels_tab;
  }

  class array<class CC_channel_class> & get_channels_tab ()
  {
    return channels_tab;
  }

  const class array<class CC_channel_class> & get_channels_in_tab () const
  {
    return channels_in_tab;
  }

  class array<class CC_channel_class> & get_channels_in_tab ()
  {
    return channels_in_tab;
  }

  const class array<class CC_channel_class> & get_channels_out_tab () const
  {
    return channels_out_tab;
  }

  class array<class CC_channel_class> & get_channels_out_tab ()
  {
    return channels_out_tab;
  }

  const class array<complex<double> > & get_e_channels_tab () const
  {
    return e_channels_tab;
  }

  class array<complex<double> > & get_e_channels_tab ()
  {
    return e_channels_tab;
  }

  const class array<complex<double> > & get_k_channels_tab () const
  {
    return k_channels_tab;
  }

  class array<complex<double> > & get_k_channels_tab ()
  {
    return k_channels_tab;
  }

  const class array<complex<double> > & get_eta_channels_tab () const
  {
    return eta_channels_tab;
  }

  class array<complex<double> > & get_eta_channels_tab ()
  {
    return eta_channels_tab;
  }

  const class array<double> & get_CM_angles () const
  {
    return CM_angles;
  }

  class array<double> & get_CM_angles ()
  {
    return CM_angles;
  }

  const class array<double> & get_CM_angles_weights () const
  {
    return CM_angles_weights;
  }

  class array<double> & get_CM_angles_weights ()
  {
    return CM_angles_weights;
  }

  const class array<double> & get_J_A_tab () const
  {
    return J_A_tab;
  }

  class array<double> & get_J_A_tab ()
  {
    return J_A_tab;
  }

  const class array<unsigned int> & get_BP_A_tab () const
  {
    return BP_A_tab;
  }

  class array<unsigned int> & get_BP_A_tab ()
  {
    return BP_A_tab;
  }

  const class array<unsigned int> & get_vector_index_A_tab () const
  {
    return vector_index_A_tab;
  }

  class array<unsigned int> & get_vector_index_A_tab ()
  {
    return vector_index_A_tab;
  }

  const class array<unsigned int> & get_vector_index_A_out_tab () const
  {
    return vector_index_A_out_tab;
  }

  class array<unsigned int> & get_vector_index_A_out_tab ()
  {
    return vector_index_A_out_tab;
  }

  const class array<unsigned int> & get_N_channels_tab () const
  {
    return N_channels_tab;
  }

  class array<unsigned int> & get_N_channels_tab ()
  {
    return N_channels_tab;
  }

  const class array<unsigned int> & get_N_entrance_channels_tab () const
  {
    return N_entrance_channels_tab;
  }

  class array<unsigned int> & get_N_entrance_channels_tab ()
  {
    return N_entrance_channels_tab;
  }

  const class array<unsigned int> & get_entrance_JPi_channels_indices () const
  {
    return entrance_JPi_channels_indices;
  }

  class array<unsigned int> & get_entrance_JPi_channels_indices ()
  {
    return entrance_JPi_channels_indices;
  }

  const class array<double> & get_J_A_in_tab () const
  {
    return J_A_in_tab;
  }

  class array<double> & get_J_A_in_tab ()
  {
    return J_A_in_tab;
  }

  const class array<double> & get_J_A_out_tab () const
  {
    return J_A_out_tab;
  }

  class array<double> & get_J_A_out_tab ()
  {
    return J_A_out_tab;
  }

  const class array<unsigned int> & get_BP_A_in_tab () const
  {
    return BP_A_in_tab;
  }

  class array<unsigned int> & get_BP_A_in_tab ()
  {
    return BP_A_in_tab;
  }

  const class array<unsigned int> & get_BP_A_out_tab () const
  {
    return BP_A_out_tab;
  }

  class array<unsigned int> & get_BP_A_out_tab ()
  {
    return BP_A_out_tab;
  }

  const class array<unsigned int> & get_N_channels_in_tab () const
  {
    return N_channels_in_tab;
  }

  class array<unsigned int> & get_N_channels_in_tab ()
  {
    return N_channels_in_tab;
  }

  const class array<unsigned int> & get_N_channels_out_tab () const
  {
    return N_channels_out_tab;
  }

  class array<unsigned int> & get_N_channels_out_tab ()
  {
    return N_channels_out_tab;
  }

  const class array<TYPE> & get_beta_suboperator_intrinsic_NBMEs () const
  {
    return beta_suboperator_intrinsic_NBMEs;
  }
  
  class array<TYPE> & get_beta_suboperator_intrinsic_NBMEs ()
  {
    return beta_suboperator_intrinsic_NBMEs;
  }

  const class array<TYPE> & get_beta_suboperator_intrinsic_NBMEs_strength () const
  {
    return beta_suboperator_intrinsic_NBMEs_strength;
  }

  class array<TYPE> & get_beta_suboperator_intrinsic_NBMEs_strength ()
  {
    return beta_suboperator_intrinsic_NBMEs_strength;
  }

  const class array<TYPE> & get_EM_suboperator_intrinsic_NBMEs () const
  {
    return EM_suboperator_intrinsic_NBMEs;
  }

  class array<TYPE> & get_EM_suboperator_intrinsic_NBMEs ()
  {
    return EM_suboperator_intrinsic_NBMEs;
  }

  const class array<TYPE> & get_EM_suboperator_intrinsic_NBMEs_strength () const
  {
    return EM_suboperator_intrinsic_NBMEs_strength;
  }

  class array<TYPE> & get_EM_suboperator_intrinsic_NBMEs_strength ()
  {
    return EM_suboperator_intrinsic_NBMEs_strength;
  }

  const class array<TYPE> & get_scalar_intrinsic_NBMEs () const
  {
    return scalar_intrinsic_NBMEs;
  }

  class array<TYPE> & get_scalar_intrinsic_NBMEs ()
  {
    return scalar_intrinsic_NBMEs;
  }

  const class array<TYPE> & get_scalar_intrinsic_NBMEs_strength () const
  {
    return scalar_intrinsic_NBMEs_strength;
  }

  class array<TYPE> & get_scalar_intrinsic_NBMEs_strength ()
  {
    return scalar_intrinsic_NBMEs_strength;
  }

  friend double used_memory_calc (const class CC_target_projectile_composite_data &T);
  
private:

  int Z;
  int N;
  int A;
  
  bool truncation_hw;
  bool truncation_ph;
  
  int n_holes_max;
  int n_scat_max;
  int E_relative_max_hw;

  enum CC_reaction_type CC_reaction;
  
  enum CC_reaction_calculation_type CC_reaction_calculation;
    
  enum particle_type entrance_projectile;
  
  double mass_entrance_projectile;
  double CM_to_work_frame_kinetic_factor;
  double work_frame_to_lab_kinetic_factor; 
  double CM_to_lab_kinetic_factor; 
  double kinetic_factor_entrance_projectile_work_frame;
  double kinetic_factor_entrance_projectile_CM;
  
  int Z_target;
  int N_target;
  int A_target;
  
  double mass_target;

  bool are_GSM_a_dagger_vectors_calculated;
  
  unsigned int N_JPi_A;
  unsigned int N_JPi_A_in;
  unsigned int N_JPi_A_out;
  
  unsigned int N_target_projectile_states;
  unsigned int entrance_target_index;
  unsigned int N_entrance_channels_max;
  
  double J_intrinsic_projectile_max;
  
  unsigned int N_energies;
  unsigned int N_CM_angles;
  unsigned int cluster_projectile_number;
  
  bool is_it_one_nucleon_COSM_case;
  
  enum EM_type EM_for_total_cross_section;
  
  int L_for_total_cross_section;
  int radiative_capture_L_limit;
  
  unsigned int N_theta_gamma;
  unsigned int N_phi_gamma;
  
  bool radiative_capture_is_it_longwavelength_approximation;
  bool radiative_capture_is_it_HO_expansion;
  
  double prot_effective_charge;
  double neut_effective_charge;
  
  unsigned int N_channels;
  unsigned int N_channels_in;
  unsigned int N_channels_out;
  unsigned int N_restarts;
  unsigned int Davidson_max_dimension;

  double Davidson_eigenvector_precision;
  double relative_SVD_precision;
  double R_cut_function;
  double d_cut_function;
  double Ueq_regularizor;
  double CC_average_n_scat_target_projectile_max;

  class array<enum particle_type> projectile_tab;
  
  class array<unsigned int> BP_target_tab;
  
  class array<double> J_target_tab;
  
  class array<unsigned int> vector_index_target_tab;
  
  class array<bool> is_it_pole_target_tab;
  
  class array<double> real_E_target_tab;
  class array<double> Gamma_target_tab;
  
  class array<TYPE> E_target_tab;
  
  class array<double> real_E_intrinsic_projectile_tab;
  class array<double> Gamma_intrinsic_projectile_tab;
  
  class array<TYPE> E_intrinsic_projectile_tab;
  
  class array<complex<double> > average_n_scat_target_tab;
  
  class array<unsigned int> target_indices;
  
  class array<double> E_total_tab;
  
  class array<double> E_kinetic_total_system_CM_tab;
  class array<double> E_kinetic_projectile_lab_tab; 
  class array<double> E_kinetic_target_lab_inverse_kinematics_tab;
  
  class array<unsigned int> N_partial_waves;
  class array<unsigned int> N_channels_per_target_projectile_tab;
  class array<unsigned int> N_channels_per_target_projectile_in_tab;
  class array<unsigned int> N_channels_per_target_projectile_out_tab;
  class array<unsigned int> JPi_channels_indices_per_target_projectile;
  class array<unsigned int> JPi_channels_indices_per_target_projectile_in;
  class array<unsigned int> JPi_channels_indices_per_target_projectile_out;
  
  class array<class CC_channel_class> channels_tab;
  class array<class CC_channel_class> channels_in_tab;
  class array<class CC_channel_class> channels_out_tab;
  
  class array<complex<double> > e_channels_tab;
  class array<complex<double> > k_channels_tab;
  class array<complex<double> > eta_channels_tab;
  
  class array<double> CM_angles;
  class array<double> CM_angles_weights;
  class array<double> J_A_tab;
  
  class array<unsigned int> BP_A_tab;
  class array<unsigned int> vector_index_A_tab;
  class array<unsigned int> N_channels_tab;
  class array<unsigned int> N_entrance_channels_tab;
  class array<unsigned int> entrance_JPi_channels_indices;
  
  class array<double> J_A_in_tab;
  class array<double> J_A_out_tab;
  
  class array<unsigned int> BP_A_in_tab;
  class array<unsigned int> BP_A_out_tab;
  class array<unsigned int> vector_index_A_out_tab;
  class array<unsigned int> N_channels_in_tab;
  class array<unsigned int> N_channels_out_tab;
  
  class array<TYPE> beta_suboperator_intrinsic_NBMEs;
  class array<TYPE> beta_suboperator_intrinsic_NBMEs_strength;
  class array<TYPE> EM_suboperator_intrinsic_NBMEs;
  class array<TYPE> EM_suboperator_intrinsic_NBMEs_strength;
  class array<TYPE> scalar_intrinsic_NBMEs;
  class array<TYPE> scalar_intrinsic_NBMEs_strength;
};



#endif


