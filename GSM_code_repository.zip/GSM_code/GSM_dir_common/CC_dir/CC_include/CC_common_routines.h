#ifndef CCCOMMONROUTINES_H
#define CCCOMMONROUTINES_H

namespace CC_common_routines
{
  bool is_it_one_nucleon_case_determine (const class array<class CC_channel_class> &channels_tab);

  void print_composite_possible_couplings (
					   const unsigned int BP_T ,
					   const double J_T ,
					   const unsigned int BP_projectile , 
					   const double J_projectile ,
					   const unsigned int CC_N_JPi_A_composite ,
					   const class array<unsigned int> &CC_BP_A_tab ,
					   const class array<double> &CC_J_A_tab);

  void e_k_eta_channels_tabs_calc (
				   const class input_data_str &input_data , 
				   const class array<TYPE> &E_target_tab ,
				   const class array<enum particle_type> &projectile_tab ,
				   const class array<TYPE> &E_intrinsic_projectile_tab ,
				   const class array<double> &E_total_tab ,
				   class array<complex<double> > &e_channels_tab , 
				   class array<complex<double> > &k_channels_tab , 
				   class array<complex<double> > &eta_channels_tab);

  unsigned int JPi_index_determine (
				    const class array<unsigned int> &BP_A_tab , 
				    const class array<double> &J_A_tab , 
				    const unsigned int BP_A , 
				    const double J_A);
 
  void JPi_channels_tab_BP_J_fill (
				   const class array<class CC_channel_class> &channels_tab ,
				   const unsigned int BP_A , 
				   const double J_A , 
				   class array<class CC_channel_class> &JPi_channels_tab);

  void JPi_channels_tab_BP_J_E_fill (
				     const class array<class CC_channel_class> &channels_tab , 
				     const unsigned int BP_A , 
				     const double J_A , 
				     const complex<double> &E,
				     class array<class CC_channel_class> &JPi_channels_tab);

  void JPi_channels_tab_BP_J_vector_index_fill (
						const class array<class CC_channel_class> &channels_tab ,
						const unsigned int BP_A , 
						const double J_A , 
						const unsigned int vector_index_A ,
						class array<class CC_channel_class> &JPi_vector_index_channels_tab);

  void JPi_channels_tab_BP_J_vector_index_E_fill (
						  const class array<class CC_channel_class> &channels_tab , 
						  const unsigned int BP_A , 
						  const double J_A , 
						  const unsigned int vector_index_A ,
						  const complex<double> &E,
						  class array<class CC_channel_class> &JPi_channels_tab);

  double JT_max_determine (const class array<class CC_channel_class> &channels_tab);

  unsigned int CC_N_nlj_calc (
			      const enum particle_type particle , 
			      const class array<class CC_channel_class> &channels_tab);

  void CC_shells_qn_fill (
			  const bool S_matrix_pole , 
			  const enum particle_type particle , 
			  const class lj_table<int> &prot_n_min_valence_tab, 
			  const class lj_table<int> &neut_n_min_valence_tab, 
			  const class array<class CC_channel_class> &channels_tab , 
			  const class lj_table<bool> &OCM_valence_state_tab,
			  class array<class nlj_struct> &CC_shells_qn);

  unsigned int entrance_target_index_determine (const class input_data_str &input_data);

  double J_intrinsic_projectile_max_determine (const class input_data_str &input_data);

  void channels_tab_inputs (
			    const class input_data_str &input_data ,   
			    const bool is_it_in_states ,
			    const class array<unsigned int> &BP_A_tab,
			    const class array<double> &J_A_tab,
			    class array<unsigned int> &N_channels_tab , 
			    class array<unsigned int> &N_entrance_channels_tab,
			    class array<unsigned int> &N_channels_per_target_projectile_tab);

  bool is_it_HO_channel_decomposition_determine (
						 const enum particle_type particle_proj,
						 const int LCM_proj,
						 const double J_proj,
						 const class input_data_str &input_data);

  void channels_tab_construction (
				  const class input_data_str &input_data , 
				  const bool is_it_in_states ,
				  const bool is_it_out_states ,
				  const class nucleons_data &prot_data , 
				  const class nucleons_data &neut_data ,
				  const class array<unsigned int> &BP_A_tab ,
				  const class array<unsigned int> &vector_index_A_tab ,
				  const class array<double> &J_A_tab , 
				  class array<unsigned int> &entrance_channels_indices ,	
				  class array<unsigned int> &channels_indices_per_target_projectile ,
				  class array<class CC_channel_class> &channels_tab);
 
  void OCM_valence_state_tab_fill (	
				   const class nucleons_data &CC_particles_data ,
				   class lj_table<bool> &OCM_valence_state_tab);

  void prepare_CC_prot_neut_data (
				  const class array<class CC_channel_class> &channels_JPi_A_tab ,
				  const bool S_matrix_pole,
				  const class lj_table<int> &prot_n_min_valence_tab, 
				  const class lj_table<int> &neut_n_min_valence_tab, 
				  const class lj_table<bool> &prot_OCM_valence_state_tab,
				  const class lj_table<bool> &neut_OCM_valence_state_tab,
				  class nucleons_data &CC_prot_data ,
				  class nucleons_data &CC_neut_data);

  void Ueq_source_averaged_calc (
				 const double new_potential_fraction,
				 const class array<complex<double> > &Ueq_tab_new,
				 const class array<complex<double> > &source_tab_new, 
				 class array<complex<double> > &Ueq_tab_averaged,
				 class array<complex<double> > &source_tab_averaged);
	
  void allowed_JPi_channels_calc_print (const class input_data_str &input_data_CC_Berggren);
	
  void observable_allowed_JPi_channels_calc_print (
						   const unsigned int BP_Op,
						   const int rank_Op,
						   const class input_data_str &input_data_CC_Berggren);
	
  void observable_allowed_JPi_channels_calc_print (
						   const enum CC_reaction_type CC_reaction ,								  
						   const class input_data_str &input_data_CC_Berggren);
}

#endif


