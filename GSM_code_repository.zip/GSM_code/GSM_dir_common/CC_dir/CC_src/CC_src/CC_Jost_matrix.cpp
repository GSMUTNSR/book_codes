#include "../CC_include/CC_include_def_common.h"







// TYPE is double or complex
// -------------------------






// Calculation of the Jost function determinant associated to a channel wave function {uc(r)}
// ------------------------------------------------------------------------------------------
// One has uc(r) = sum_b f[b,c] fwd_basis[b](r) on [0:matching-point] and uc(r) = sum_b b[b,c] bwd_basis[b](r) on [matching-point:R].
// The Jost function matrix arises from matching forward and backward channel wave function decompositions in matching-point.
// See book for formulas.

void Jost_matrix_entrance_channel_only_calc (
					     const unsigned int ic_entrance , 
					     const class array<class CC_fwd_basis_state> &fwd_basis , 
					     const class array<class CC_bwd_basis_state> &bwd_basis , 
					     class matrix<complex<double> > &Jost_matrix)
{
  Jost_matrix = 0.0;

  const class CC_fwd_basis_state &fwd_basis_b = fwd_basis(ic_entrance);
  const class CC_bwd_basis_state &bwd_basis_b = bwd_basis(ic_entrance);

  const class array<complex<double> > &CC_fwd_wf_mp_tab = fwd_basis_b.get_CC_fwd_wf_mp_tab ();
  const class array<complex<double> > &CC_bwd_wf_mp_tab = bwd_basis_b.get_CC_bwd_wf_mp_tab ();
  
  const class array<complex<double> > &CC_fwd_dwf_mp_tab = fwd_basis_b.get_CC_fwd_dwf_mp_tab ();
  const class array<complex<double> > &CC_bwd_dwf_mp_tab = bwd_basis_b.get_CC_bwd_dwf_mp_tab ();

  const unsigned int N_channels = fwd_basis.dimension (0);

  const unsigned int first_ic = basic_first_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_ic = basic_last_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS); 
  
  if ((ic_entrance >= first_ic) && (ic_entrance <= last_ic))
    {
      Jost_matrix(0 , 0) =  CC_fwd_wf_mp_tab(ic_entrance);
      Jost_matrix(0 , 1) = -CC_bwd_wf_mp_tab(ic_entrance);

      Jost_matrix(1 , 0) =  CC_fwd_dwf_mp_tab(ic_entrance);
      Jost_matrix(1 , 1) = -CC_bwd_dwf_mp_tab(ic_entrance);
    }

#ifdef UseMPI
  if (is_it_MPI_parallelized) Jost_matrix.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
#endif 
}






void Jost_matrix_calc (
		       const class array<class CC_fwd_basis_state> &fwd_basis , 
		       const class array<class CC_bwd_basis_state> &bwd_basis , 
		       class matrix<complex<double> > &Jost_matrix)
{
  const unsigned int N_channels = fwd_basis.dimension (0);

  Jost_matrix = 0.0;

  const unsigned int first_ib = basic_first_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_ib = basic_last_index_determine_for_MPI (N_channels , NUMBER_OF_PROCESSES , THIS_PROCESS); 

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const unsigned int ic_derivative = ic + N_channels;

      for (unsigned int ib = 0 ; ib < N_channels ; ib++)
	{
	  if ((ib >= first_ib) && (ib <= last_ib))
	    {
	      const unsigned int ib_fwd = ib;
	      const unsigned int ib_bwd = ib + N_channels;

	      const class CC_fwd_basis_state &fwd_basis_b = fwd_basis(ib);
	      const class CC_bwd_basis_state &bwd_basis_b = bwd_basis(ib);

	      const class array<complex<double> > &CC_fwd_wf_mp_tab = fwd_basis_b.get_CC_fwd_wf_mp_tab ();
	      const class array<complex<double> > &CC_bwd_wf_mp_tab = bwd_basis_b.get_CC_bwd_wf_mp_tab ();
	      
	      const class array<complex<double> > &CC_fwd_dwf_mp_tab = fwd_basis_b.get_CC_fwd_dwf_mp_tab ();
	      const class array<complex<double> > &CC_bwd_dwf_mp_tab = bwd_basis_b.get_CC_bwd_dwf_mp_tab ();

	      Jost_matrix(ic , ib_fwd) =  CC_fwd_wf_mp_tab(ic);
	      Jost_matrix(ic , ib_bwd) = -CC_bwd_wf_mp_tab(ic);
	      
	      Jost_matrix(ic_derivative , ib_fwd) =  CC_fwd_dwf_mp_tab(ic);
	      Jost_matrix(ic_derivative , ib_bwd) = -CC_bwd_dwf_mp_tab(ic);
	    }
	}
    }

#ifdef UseMPI
  if (is_it_MPI_parallelized) Jost_matrix.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
#endif
}



