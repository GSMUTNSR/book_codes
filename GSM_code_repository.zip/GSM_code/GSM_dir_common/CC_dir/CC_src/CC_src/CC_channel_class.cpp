#include "../CC_include/CC_include_def_common.h"

using namespace string_routines;

// TYPE is double or complex
// -------------------------





// Class containing information about a reaction channel
// -----------------------------------------------------
// A channel read |T[c] projectile[c],r>, where T[c] is the target and projectile[c] is the projectile.
// J[T[c]] and J[projectile[c]] are coupled to J.
//
// All members are defined in CC_channel_class.h .

CC_channel_class::CC_channel_class () 
  : projectile (NO_PARTICLE) , 
    Tc_no_core (NO_PARTICLE) , 
    Z_Tc (0) , 
    N_Tc (0) , 
    A_Tc (0) , 
    S_Tc (0) , 
    BP_Tc (0) , 
    J_Tc (0.0) , 
    vector_index_Tc (0) ,
    S_matrix_pole_Tc (false), 
    mass_Tc (0.0) , 
    E_Tc (0.0) ,
    E_intrinsic_projectile_c (0.0) , 
    average_n_scat_Tc (0.0) , 
    Z_projectile (0) , 
    N_projectile (0) , 
    A_projectile (0) , 
    S_projectile (0) , 
    S_matrix_pole_projectile (false) , 
    mass_projectile (0) ,
    b_HO_potentials_projectile (0.0) , 
    LCM_projectile (0) , 
    BP_LCM_projectile (0) , 
    kinetic_factor_projectile (0.0) , 
    BP_intrinsic_projectile (0) , 
    J_intrinsic_projectile (0.0) , 
    BP_projectile (0) , 
    J_projectile (0.0) , 
    e_projectile (0.0) , 
    k_projectile (0.0) , 
    eta_projectile (0.0) , 
    Z_Tc_charge (0) , 
    BP (0) , 
    vector_index (NADA) , 
    J (0.0) , 
    M (0.0) , 
    E (0.0) ,
    is_it_HO_channel_decomposition (false)
{}

CC_channel_class::CC_channel_class (
				    const enum interaction_type inter , 
				    const double prot_mass_for_calc , 
				    const double neut_mass_for_calc ,
				    const double    Y_mass_for_calc ,  
				    const double nucleus_mass , 
				    const double b_lab , 
				    const int Z , 
				    const int N , 
				    const int S , 
				    const enum particle_type projectile_c , 
				    const unsigned int BP_Tc_c , 
				    const double J_Tc_c , 
				    const unsigned int vector_index_Tc_c ,
				    const bool S_matrix_pole_Tc_c ,  
				    const complex<double> &E_Tc_c ,
				    const complex<double> &E_intrinsic_projectile_c_c ,	
				    const complex<double> &average_n_scat_Tc_c , 
				    const int LCM_projectile_c , 
				    const double J_projectile_c , 
				    const unsigned int vector_index_c , 
				    const double J_c , 
				    const double M_c , 
				    const complex<double> &E_c ,
				    const bool is_it_HO_channel_decomposition_c)
{
  initialize (inter , prot_mass_for_calc , neut_mass_for_calc , Y_mass_for_calc , nucleus_mass , b_lab , Z , N , S , projectile_c , BP_Tc_c , J_Tc_c , vector_index_Tc_c ,
	      S_matrix_pole_Tc_c , E_Tc_c , E_intrinsic_projectile_c_c , average_n_scat_Tc_c , LCM_projectile_c , J_projectile_c , vector_index_c , J_c , M_c , E_c , is_it_HO_channel_decomposition_c);
}

CC_channel_class::CC_channel_class (const class CC_channel_class &X) 
{
  initialize (X);
}

void CC_channel_class::initialize (
				   const enum interaction_type inter , 
				   const double prot_mass_for_calc , 
				   const double neut_mass_for_calc , 
				   const double    Y_mass_for_calc , 
				   const double nucleus_mass , 
				   const double b_lab , 
				   const int Z , 
				   const int N , 
				   const int S , 
				   const enum particle_type projectile_c , 
				   const unsigned int BP_Tc_c , 
				   const double J_Tc_c , 
				   const unsigned int vector_index_Tc_c ,
				   const bool S_matrix_pole_Tc_c ,  
				   const complex<double> &E_Tc_c ,
				   const complex<double> &E_intrinsic_projectile_c_c ,	
				   const complex<double> &average_n_scat_Tc_c , 
				   const int LCM_projectile_c , 
				   const double J_projectile_c , 
				   const unsigned int vector_index_c , 
				   const double J_c , 
				   const double M_c , 
				   const complex<double> &E_c ,
				   const bool is_it_HO_channel_decomposition_c)
{
  projectile = projectile_c;
  
  Z_Tc = Z_target_determine (Z , projectile); 
  N_Tc = N_target_determine (N , projectile); 
  
  A_Tc = Z_Tc + N_Tc; 

  S_Tc = S - particle_strangeness_determine (projectile);
  
  if (inter == REALISTIC_INTERACTION) Tc_no_core = cluster_determine (Z_Tc , N_Tc);
  
  BP_Tc = BP_Tc_c; 

  J_Tc = J_Tc_c; 

  vector_index_Tc = vector_index_Tc_c; 

  S_matrix_pole_Tc = S_matrix_pole_Tc_c;

  mass_Tc = (!is_it_COSM_determine (inter)) ? (mass_target_determine (Z , N , projectile , prot_mass_for_calc , neut_mass_for_calc)) : (nucleus_mass);

  E_Tc = E_Tc_c;

  E_intrinsic_projectile_c = E_intrinsic_projectile_c_c;            

  average_n_scat_Tc = average_n_scat_Tc_c; 

  Z_projectile = Z_cluster_determine (projectile); 
  N_projectile = N_cluster_determine (projectile); 
  A_projectile = A_cluster_determine (projectile);

  S_projectile = particle_strangeness_determine (projectile);
  
  S_matrix_pole_projectile = S_matrix_pole_cluster_determine (projectile); 

  mass_projectile = mass_cluster_determine (projectile , prot_mass_for_calc , neut_mass_for_calc , Y_mass_for_calc); 

  b_HO_potentials_projectile = b_lab/sqrt (A_projectile); 

  LCM_projectile = LCM_projectile_c; 

  BP_LCM_projectile = binary_parity_from_orbital_angular_momentum (LCM_projectile); 

  kinetic_factor_projectile = kinetic_factor_calc (false , mass_Tc , mass_projectile); 

  BP_intrinsic_projectile = BP_intrinsic_cluster_determine (projectile); 

  J_intrinsic_projectile = J_intrinsic_cluster_determine (projectile); 

  BP_projectile = binary_parity_product (BP_intrinsic_projectile , BP_LCM_projectile); 

  J_projectile = J_projectile_c; 

  Z_Tc_charge = Z_projectile*Z_Tc; 

  BP = binary_parity_product (BP_Tc , BP_projectile); 

  vector_index = vector_index_c; 

  J = J_c; 
  M = M_c; 

  E = E_c;

  is_it_HO_channel_decomposition = is_it_HO_channel_decomposition_c;

  E_dependent_values_change (E_c);
}






void CC_channel_class::initialize (const class CC_channel_class &X) 
{
  projectile = X.projectile; 

  Z_Tc = X.Z_Tc; 
  N_Tc = X.N_Tc; 
  A_Tc = X.A_Tc; 

  Tc_no_core = X.Tc_no_core;
  
  BP_Tc = X.BP_Tc; 

  J_Tc = X.J_Tc; 

  vector_index_Tc = X.vector_index_Tc; 

  S_matrix_pole_Tc = X.S_matrix_pole_Tc;  

  mass_Tc = X.mass_Tc; 

  E_Tc = X.E_Tc;

  E_intrinsic_projectile_c = X.E_intrinsic_projectile_c;

  average_n_scat_Tc = X.average_n_scat_Tc; 

  Z_projectile = X.Z_projectile; 
  N_projectile = X.N_projectile; 
  A_projectile = X.A_projectile; 

  S_projectile = X.S_projectile;
  
  S_matrix_pole_projectile = X.S_matrix_pole_projectile;

  mass_projectile = X.mass_projectile; 

  b_HO_potentials_projectile = X.b_HO_potentials_projectile; 

  LCM_projectile = X.LCM_projectile; 

  BP_LCM_projectile = X.BP_LCM_projectile; 

  kinetic_factor_projectile = X.kinetic_factor_projectile; 

  BP_intrinsic_projectile = X.BP_intrinsic_projectile; 

  J_intrinsic_projectile = X.J_intrinsic_projectile; 

  BP_projectile = X.BP_projectile; 

  J_projectile = X.J_projectile; 

  e_projectile = X.e_projectile; 
  k_projectile = X.k_projectile; 

  eta_projectile = X.eta_projectile; 

  Z_Tc_charge = X.Z_Tc_charge; 

  BP = X.BP; 

  vector_index = X.vector_index; 

  J = X.J; 
  M = X.M; 

  E = X.E;

  is_it_HO_channel_decomposition = X.is_it_HO_channel_decomposition;
}




void CC_channel_class::allocate_fill (const class CC_channel_class &X) 
{
  initialize (X);
}


void CC_channel_class::operator = (const class CC_channel_class &X) 
{
  initialize (X);
}











// Change of energy dependence in channels
// ---------------------------------------
// When one calculates a pole state, for example, its initial energy is not defined as it arises from a diagonalization procedure.
// As channels depend on energy, the induced energy change is taken into account here.

void CC_channel_class::E_dependent_values_change (const complex<double> &E_c) 
{
  E = E_c;

  e_projectile = E - E_Tc - E_intrinsic_projectile_c;

  k_projectile = sqrt_mod (e_projectile*kinetic_factor_projectile);

  eta_projectile = (k_projectile != 0.0) ? (eta_calc (false , projectile , Z_Tc_charge , kinetic_factor_projectile , k_projectile)) : (INFINITE);
}







//  <<  overloading to print a channel under the form : [Target[c] : Z:8 N:8 0+(0) Projectile[c] : proton r p3/2]^(3/2-)
// ---------------------------------------------------------------------------------------------------------------------

ostream& operator << (ostream &os , const class CC_channel_class &channel)
{
  const int A_projectile = channel.get_A_projectile ();

  const int LCM_projectile = channel.get_LCM_projectile ();

  const double J_Tc = channel.get_J_Tc ();

  const double J_intrinsic_projectile = channel.get_J_intrinsic_projectile ();

  const double J_projectile = channel.get_J_projectile ();

  const double J = channel.get_J ();

  const unsigned int BP_Tc = channel.get_BP_Tc ();

  const unsigned int BP = channel.get_BP ();

  const unsigned int vector_index_Tc = channel.get_vector_index_Tc ();

  const int Z_Tc = channel.get_Z_Tc ();
  const int N_Tc = channel.get_N_Tc ();

  const enum particle_type projectile = channel.get_projectile ();
  
  const unsigned int vector_index = channel.get_vector_index ();
  
  os << "[Target[c] : Z:" << Z_Tc << " N:" << N_Tc << " " << J_Pi_vector_index_string (BP_Tc , J_Tc , vector_index_Tc) << " Projectile[c] : " << projectile;

  if (A_projectile == 1)
    os << " r " << angular_state (LCM_projectile , J_projectile);
  else if (A_projectile == 2)
    os << " R[CM] " << angular_state_two_body_cluster (J_intrinsic_projectile , LCM_projectile , J_projectile);
  else if (J_intrinsic_projectile == 0)
    os << " R[CM] " << angular_state_cluster_CM (LCM_projectile);
  else 
    os << " R[CM] " << angular_state_cluster_CM_intrinsic_spin (LCM_projectile , J_projectile);

  if (vector_index == NADA)
    os << "]^(" << J_Pi_string (BP , J) << ")";
  else
    os << "]^(" << J_Pi_vector_index_string (BP , J , vector_index) << ")";
    
  return os;
}



// String of characters specifying a channel as above which can be used in a file name
// -----------------------------------------------------------------------------------

string CC_channel_class::channel_string_for_file_name () const
{
  string channel_str = "Tc_Z" + make_string<int> (Z_Tc) + "_N" + make_string<int> (N_Tc) + "_" + J_Pi_vector_index_string_for_file_name (BP_Tc , J_Tc , vector_index_Tc) + "_" + cluster_string_for_file_name (projectile);

  if (A_projectile == 1)
    channel_str += "_" + angular_state_for_file_name (LCM_projectile , J_projectile);
  else if (A_projectile == 2)
    channel_str += "_" + angular_state_two_body_cluster_for_file_name (J_intrinsic_projectile , LCM_projectile , J_projectile);
  else if (J_intrinsic_projectile == 0)
    channel_str += "_" + angular_state_cluster_CM_for_file_name (LCM_projectile);
  else 
    channel_str += "_" + angular_state_cluster_CM_intrinsic_spin_for_file_name (LCM_projectile , J_projectile);

  if (vector_index == NADA)
    channel_str += "_coupled_to_" + J_Pi_string_for_file_name (BP , J);
  else
    channel_str += "_coupled_to_" + J_Pi_vector_index_string_for_file_name (BP , J , vector_index);
    
  return channel_str;
}





// Memory used by the class
// ------------------------

double used_memory_calc (const class CC_channel_class &T)
{
  return sizeof (T)/1000000.0;
}
