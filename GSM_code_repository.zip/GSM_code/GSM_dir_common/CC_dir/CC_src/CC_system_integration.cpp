#include "../CC_include/CC_include_def_common.h"


/* Constructors and Destructors
 */

CC_system_integration::CC_system_integration () :
  is_it_entrance_channel_only (false) , 
  ic_entrance (0) , 
  N_channels (0) , 
  T_ptr (NULL) , 
  source_basis_factor (0.0)
{
  for (int i = 0 ; i < 28 ; i++) interpolation_term_tab[i] = 0.0;

  for (unsigned int k = 0 ; k < 7 ; k++)
    {
      m_tab[k] = 0.0;

      one_over_m_tab[k] = 0.0;

      H_over_m_tab[k] = 0.0;
    }
}


CC_system_integration::CC_system_integration (
					      const bool is_it_entrance_channel_only_c , 
					      const unsigned int ic_entrance_c , 
					      const unsigned int N_channels_c , 
					      const class potentials_effective_mass &T , 
					      const class array<class CC_channel_class> &channels_tab ,  
					      const complex<double> &source_basis_factor_c) :
  is_it_entrance_channel_only (false) , 
  ic_entrance (0) , 
  N_channels (0) , 
  T_ptr (NULL) , 
  source_basis_factor (0.0)
{
  allocate (is_it_entrance_channel_only_c , ic_entrance_c , N_channels_c , T , channels_tab , source_basis_factor_c);
}

CC_system_integration::CC_system_integration (const class CC_system_integration &X) :
  is_it_entrance_channel_only (false) , 
  ic_entrance (0) , 
  N_channels (0) , 
  T_ptr (NULL) , 
  source_basis_factor (0.0)
{
  allocate_fill (X);
}
 
CC_system_integration::~CC_system_integration () {}

void CC_system_integration::allocate (
				      const bool is_it_entrance_channel_only_c , 
				      const unsigned int ic_entrance_c , 
				      const unsigned int N_channels_c , 
				      const class potentials_effective_mass &T , 
				      const class array<class CC_channel_class> &channels_tab ,  
				      const complex<double> &source_basis_factor_c)
{
  is_it_entrance_channel_only = is_it_entrance_channel_only_c;

  ic_entrance = ic_entrance_c; 

  N_channels = N_channels_c; 

  T_ptr = &T;

  source_basis_factor = source_basis_factor_c;

  LCM_projectile_LCM_projectile_plus_one_tab.allocate (N_channels);

  kinetic_factor_projectile_tab.allocate (N_channels);

  e_projectile_tab.allocate (N_channels);

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const int LCM_projectile = channel_c.get_LCM_projectile ();

      const double kinetic_factor_projectile = channel_c.get_kinetic_factor_projectile ();

      const complex<double> e_projectile = channel_c.get_e_projectile ();

      LCM_projectile_LCM_projectile_plus_one_tab(ic) = LCM_projectile*(LCM_projectile+1);

      kinetic_factor_projectile_tab(ic) = kinetic_factor_projectile;

      e_projectile_tab(ic) = e_projectile;
    }

  for (int n = 0 ; n < 8 ; n++) 
    for (int i = 0 ; i < n ; i++)
      {
	double interpolation_term = 1.0;

	for (int j = 0 ; j < n ; j++)
	  {
	    if (i != j) interpolation_term *= (i + 1.0)/static_cast<double> (i - j);
	  }

	interpolation_term_tab[Richardson_interpolation_index (n , i)] = interpolation_term;
      }

  for (unsigned int k = 0 ; k < 7 ; k++)
    {
      m_tab[k] = 2*(k + 1);
      
      one_over_m_tab[k] = 1.0/static_cast<double> (m_tab[k]);

      H_over_m_tab[k] = 0.0;
    }

  h_square_F_r_U_tab.allocate (N_channels);

  U_debut.allocate (N_channels);
  dU_debut.allocate (N_channels);

  U_extrapolated.allocate (N_channels);
  
  U_extrapolated_next.allocate (N_channels);
  dU_extrapolated_next.allocate (N_channels);

  Res.allocate (N_channels);

  Delta.allocate (N_channels);

  for (unsigned int k = 0 ; k < 7 ; k++)
    {
      U_end[k].allocate (N_channels);
      dU_end[k].allocate (N_channels);
    }
}






void CC_system_integration::allocate_fill (const class CC_system_integration &X) 
{
  is_it_entrance_channel_only = X.is_it_entrance_channel_only;

  ic_entrance = X.ic_entrance; 

  N_channels = X.N_channels; 

  T_ptr = X.T_ptr;

  source_basis_factor = X.source_basis_factor;

  LCM_projectile_LCM_projectile_plus_one_tab.allocate_fill (X.LCM_projectile_LCM_projectile_plus_one_tab);

  kinetic_factor_projectile_tab.allocate_fill (X.kinetic_factor_projectile_tab);

  e_projectile_tab.allocate_fill (X.e_projectile_tab);

  for (int i = 0 ; i < 28 ; i++) interpolation_term_tab[i] = X.interpolation_term_tab[i];

  for (unsigned int k = 0 ; k < 7 ; k++)
    {
      m_tab[k] = X.m_tab[k];
      
      one_over_m_tab[k] = X.one_over_m_tab[k];

      H_over_m_tab[k] = X.H_over_m_tab[k];
    }

  h_square_F_r_U_tab.allocate_fill (X.h_square_F_r_U_tab);

  U_debut.allocate_fill (X.U_debut);
  dU_debut.allocate_fill (X.dU_debut);

  U_extrapolated.allocate_fill (X.U_extrapolated);

  U_extrapolated_next.allocate_fill (X.U_extrapolated_next);
  dU_extrapolated_next.allocate_fill (X.dU_extrapolated_next);

  Res.allocate_fill (X.Res);

  Delta.allocate_fill (X.Delta);

  for (unsigned int k = 0 ; k < 7 ; k++)
    {
      U_end[k].allocate_fill (X.U_end[k]);
      dU_end[k].allocate_fill (X.dU_end[k]);
    }
}







void CC_system_integration::deallocate ()
{
  LCM_projectile_LCM_projectile_plus_one_tab.deallocate ();

  kinetic_factor_projectile_tab.deallocate ();

  e_projectile_tab.deallocate ();

  h_square_F_r_U_tab.deallocate ();

  U_debut.deallocate ();
  dU_debut.deallocate ();

  U_extrapolated.deallocate ();
  
  U_extrapolated_next.deallocate ();
  dU_extrapolated_next.deallocate ();

  Res.deallocate ();

  Delta.deallocate ();

  for (int i = 0 ; i < 28 ; i++) interpolation_term_tab[i] = 0.0;

  for (unsigned int k = 0 ; k < 7 ; k++)
    {
      U_end[k].deallocate ();

      dU_end[k].deallocate ();

      m_tab[k] = 0.0;

      one_over_m_tab[k] = 0.0;

      H_over_m_tab[k] = 0.0;
    }

  is_it_entrance_channel_only = false;

  ic_entrance = 0;

  N_channels = 0;

  T_ptr = NULL;

  source_basis_factor = 0.0;
}










/* extrapolation_in_zero:
   n : number of points of the function F[] near h={0}. It is smaller or equal to 8.
   F[] : table containing the points F_0[]...F_{n-1}[] close to h={0}.
   F_in_zero : extrapolated value of the vectors F_0[]...F_{n-1}[] in h={0}. 
*/

void CC_system_integration::extrapolation_in_zero (
						   const unsigned int n , 
						   const class vector_class<complex<double> > F[] , 
						   class vector_class<complex<double> > &F_in_zero)
{
  for (unsigned ic = 0 ; ic < N_channels ; ic++)
    {
      complex<double> F_in_zero_c = 0.0;

      for (unsigned int i = 0 ; i < n ; i++)
	{
	  const class vector_class<complex<double> > &Fi = F[i];

	  F_in_zero_c += interpolation_term_tab[Richardson_interpolation_index (n , i)] * Fi(ic);
	}

      F_in_zero(ic) = F_in_zero_c;
    }
}








/* F_r_U:
   _ calculates F(r , U(r)) in U''(r) = F(r , U(r));
   _ Fc(r , U) = (LCM_proj(LCM_proj+1)/r^2 - kinetic_factor_proj*e_proj)) u_c(r) + kinetic_factor_proj* \sum_c' [Vcc'(r)) u_c'(r)] + kinetic_factor_proj*S_c(r) , 
*/

void CC_system_integration::F_r_U_tab_calc (
					    const double r , 
					    const class vector_class<complex<double> > &U , 
					    class vector_class<complex<double> > &F_r_U_tab)
{
  const class potentials_effective_mass &T = get_T ();
  
  const class array<splines_class<complex<double> > > &Ueq_tab = T.get_CC_trivially_equivalent_potential_tab ();

  const class array<splines_class<complex<double> > > &source_tab = T.get_CC_source_tab ();  
 
  if (is_it_entrance_channel_only)
    {
      F_r_U_tab = 0.0;

      const class splines_class<complex<double> > &source_c_entrance = source_tab(ic_entrance);

      const int LCM_projectile_LCM_projectile_plus_one = LCM_projectile_LCM_projectile_plus_one_tab(ic_entrance);

      const double centrifugal_c_entrance = ((LCM_projectile_LCM_projectile_plus_one != 0) && (r > 0)) ? (LCM_projectile_LCM_projectile_plus_one/(r*r)) : (0.0);

      const double kinetic_factor_projectile = kinetic_factor_projectile_tab(ic_entrance);

      const complex<double> e_projectile = e_projectile_tab(ic_entrance);

      const class splines_class<complex<double> > &Ueq_c_entrance = Ueq_tab(ic_entrance , ic_entrance);
      
      complex<double> F_r_U_c_entrance = (centrifugal_c_entrance - kinetic_factor_projectile*e_projectile)*U(ic_entrance) + source_basis_factor*kinetic_factor_projectile*source_c_entrance (r); 

      F_r_U_c_entrance += kinetic_factor_projectile*Ueq_c_entrance(r)*U(ic_entrance);
      
      F_r_U_tab(ic_entrance) = F_r_U_c_entrance;      
    }
  else
    {
      for (unsigned ic = 0 ; ic < N_channels ; ic++)
	{
	  const class splines_class<complex<double> > &source_c = source_tab(ic);

	  const int LCM_projectile_LCM_projectile_plus_one = LCM_projectile_LCM_projectile_plus_one_tab(ic);

	  const double centrifugal_c = ((LCM_projectile_LCM_projectile_plus_one != 0) && (r > 0)) ? (LCM_projectile_LCM_projectile_plus_one/(r*r)) : (0.0);

	  const double kinetic_factor_projectile = kinetic_factor_projectile_tab(ic);

	  const complex<double> e_projectile = e_projectile_tab(ic);

	  complex<double> F_r_U_c = (centrifugal_c - kinetic_factor_projectile*e_projectile)*U(ic) + source_basis_factor*kinetic_factor_projectile*source_c (r); 

	  for (unsigned icp = 0 ; icp < N_channels ; icp++)
	    {
	      const class splines_class<complex<double> > &Ueq_ccp = Ueq_tab(ic , icp);

	      F_r_U_c += kinetic_factor_projectile*Ueq_ccp(r)*U(icp);
	    }

	  F_r_U_tab(ic) = F_r_U_c;
	}
    }
}






/* integration_Henrici:
   _ integration with discretization of U''(r)=F(r , U(r)) with the Henrici method;
   _ See Numerical Recipes for the method;
   _ Some variables:
   . m = number of intervals between r0 and r , 
   . h = inegration step = (r-r0)/m , 
   . delta = value used in the Henrici method. 
*/

void CC_system_integration::integration_Henrici (
						 const unsigned int m , 
						 const double h , 
						 const double r0 , 
						 const class vector_class<complex<double> > &U0 , 
						 const class vector_class<complex<double> > &dU0 , 
						 const double r , 
						 class vector_class<complex<double> > &U , 
						 class vector_class<complex<double> > &dU)
{
  const double h_square = h*h;

  const double half_h = 0.5*h;

  F_r_U_tab_calc (r0 , U0 , Delta);

  Delta *= half_h;

  Delta += dU0;

  Delta *= h;

  U = U0;

  U += Delta;

  for(unsigned int i = 1 ; i < m ; i++)
    {
      const double r0_plus_ih = r0 + i*h;
      
      F_r_U_tab_calc (r0_plus_ih , U , h_square_F_r_U_tab);

      h_square_F_r_U_tab *= h_square;

      Delta += h_square_F_r_U_tab;

      U += Delta;
    }

  F_r_U_tab_calc (r , U , dU);

  dU *= half_h;

  Delta /= h;

  dU += Delta;
}








/* operator():
   _ integration of U''(r)=F(r , U(r)) with the Burlisch-Stoer(-Henrici) method;
   _ See Numerical Recipes for the method;
   _ Some variables:
   . H = length of an integration interval. Equal to r-r0 at the beginning and is divided by 2 each time
   the extrapolation fails with 16 sub-intervals between r_debut and r_end. 
   If H = [r-r0]/N , with N=2 , 4 , 8 , 16 , ... , the integration intervals are 
   [r_debut = r0:r_end = r0+H] , ... , [r_debut = r0+(N-1).H , r_end = r].
   . test = test to know if the method worked , i.e. 
   |u_extrapolated/u_extrapolated_next - 1|oo < precision.
*/

void CC_system_integration::operator() (
					const double r0 , 
					const class vector_class<complex<double> > &U0 , 
					const class vector_class<complex<double> > &dU0 , 
					const double r , 
					class vector_class<complex<double> > &U , 
					class vector_class<complex<double> > &dU)
{
  if (r == r0)
    {
      U =  U0;
      dU = dU0;

      return;
    }

  double r_debut = r0;

  double H = r - r0;

  U_debut =  U0;
  dU_debut = dU0;
  
  double test = INFINITE;

  while (test > precision)
    {
      for (unsigned int k = 0 ; k < 7 ; k++) H_over_m_tab[k] = H*one_over_m_tab[k];

      const double inf_norm_half_H = inf_norm (H_over_m_tab[0]);

      while (inf_norm (r_debut - r) > inf_norm_half_H)
	{
	  const double r_debut_plus_H = r_debut + H;

	  const double r_end = (inf_norm (r - r_debut_plus_H) > inf_norm_half_H) ? (r_debut_plus_H) : (r);

	  integration_Henrici(2 , H_over_m_tab[0] , r_debut , U_debut , dU_debut , r_end , U_end[0] , dU_end[0]);
	  integration_Henrici(4 , H_over_m_tab[1] , r_debut , U_debut , dU_debut , r_end , U_end[1] , dU_end[1]);

	  extrapolation_in_zero(2 , U_end , U_extrapolated);
	  
	  Res = U_extrapolated;

	  unsigned int k = 2;

	  do
	    {
	      integration_Henrici(m_tab[k] , H_over_m_tab[k] , r_debut , U_debut , dU_debut , r_end , U_end[k] , dU_end[k]);

	      extrapolation_in_zero(++k , U_end , U_extrapolated_next);

	      Res -= U_extrapolated_next;

	      const double Res_inf_norm = Res.infinite_norm ();

	      const double U_extrapolated_next_inf_norm = U_extrapolated_next.infinite_norm ();

	      test = Res_inf_norm/U_extrapolated_next_inf_norm;

	      Res = U_extrapolated = U_extrapolated_next;
	    }
	  while ((test > precision) && (k < 7));

	  r_debut += H;

	  U_debut = U_extrapolated_next;

	  extrapolation_in_zero(k , dU_end , dU_extrapolated_next);

	  dU_debut = dU_extrapolated_next;
	}

      H *= 0.5;
      
      r_debut = r0;
      
      U_debut = U0;
      dU_debut = dU0;
    }
  
  U =  U_extrapolated_next;
  dU = dU_extrapolated_next;
}




double used_memory_calc (const class CC_system_integration &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.LCM_projectile_LCM_projectile_plus_one_tab) + used_memory_calc (T.kinetic_factor_projectile_tab) + used_memory_calc (T.e_projectile_tab) + used_memory_calc (T.h_square_F_r_U_tab) + used_memory_calc (T.U_debut) + used_memory_calc (T.dU_debut) + used_memory_calc (T.U_extrapolated) + used_memory_calc (T.U_extrapolated_next) + used_memory_calc (T.dU_extrapolated_next) + used_memory_calc (T.Res) + used_memory_calc (T.Delta) + used_memory_calc (T.U_end[0]) + used_memory_calc (T.dU_end[0]) + used_memory_calc (T.U_end[1]) + used_memory_calc (T.dU_end[1]) + used_memory_calc (T.U_end[2]) + used_memory_calc (T.dU_end[2]) + used_memory_calc (T.U_end[3]) + used_memory_calc (T.dU_end[3]) + used_memory_calc (T.U_end[4]) + used_memory_calc (T.dU_end[4]) + used_memory_calc (T.U_end[5]) + used_memory_calc (T.dU_end[5]) + used_memory_calc (T.U_end[6]) + used_memory_calc (T.dU_end[6]) - (sizeof (T.LCM_projectile_LCM_projectile_plus_one_tab) + sizeof (T.kinetic_factor_projectile_tab) + sizeof (T.e_projectile_tab) + sizeof (T.h_square_F_r_U_tab) + sizeof (T.U_debut) + sizeof (T.dU_debut) + sizeof (T.U_extrapolated) + sizeof (T.U_extrapolated_next) + sizeof (T.dU_extrapolated_next) + sizeof (T.Res) + sizeof (T.Delta) + sizeof (T.U_end[0]) + sizeof (T.dU_end[0]) + sizeof (T.U_end[1]) + sizeof (T.dU_end[1]) + sizeof (T.U_end[2]) + sizeof (T.dU_end[2]) + sizeof (T.U_end[3]) + sizeof (T.dU_end[3]) + sizeof (T.U_end[4]) + sizeof (T.dU_end[4]) + sizeof (T.U_end[5]) + sizeof (T.dU_end[5]) + sizeof (T.U_end[6]) + sizeof (T.dU_end[6]))/1000000.0;

  const double used_memory = used_memory_constants + used_memory_allocated_arrays; 

  return used_memory;
}
