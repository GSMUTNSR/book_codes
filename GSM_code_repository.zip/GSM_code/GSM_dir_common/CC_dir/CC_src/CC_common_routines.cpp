#include "../CC_include/CC_include_def_common.h"

using namespace string_routines;
using namespace inputs_misc;





bool CC_common_routines::is_it_one_nucleon_COSM_case_determine (const class array<class CC_channel_class> &channels_tab)
{
  const unsigned int N_channels = channels_tab.dimension (0);

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const int A_projectile_c = channel_c.get_A_projectile ();

      if (A_projectile_c >= 2) return false;
    }

  return true;
}





void CC_common_routines::print_composite_possible_couplings (
							     const unsigned int BP_T , 
							     const double J_T , 
							     const unsigned int BP_projectile , 
							     const double J_projectile , 
							     const unsigned int CC_N_JPi_A_composite , 
							     const class array<unsigned int> &CC_BP_A_tab , 
							     const class array<double> &CC_J_A_tab)
{	
  const unsigned int BP = binary_parity_product (BP_T , BP_projectile);

  const double Jmin = abs (J_T - J_projectile);

  const double Jmax = J_T + J_projectile;

  for (unsigned int iJPi_A = 0 ; iJPi_A < CC_N_JPi_A_composite ; iJPi_A++)
    {
      const unsigned int BP_A = CC_BP_A_tab(iJPi_A);
      
      const double J_A = CC_J_A_tab(iJPi_A);

      cout << "Target : " << J_Pi_string (BP_T , J_T) << " , composite : " << J_Pi_string (BP_A , J_A) << " => " ;

      if ((BP != BP_A) || (rint (J_A - Jmin) < 0.0) || (rint (J_A - Jmax) > 0.0))
	cout << "forbidden" << endl;
      else
	cout << "allowed" << endl;
    }
}






void CC_common_routines::e_k_eta_channels_tabs_calc (
						     const class input_data_str &input_data , 
						     const class array<TYPE> &E_target_tab , 
						     const class array<enum particle_type> &projectile_tab , 
						     const class array<TYPE> &E_intrinsic_projectile_tab , 
						     const class array<double> &E_total_tab , 
						     class array<complex<double> > &e_channels_tab , 
						     class array<complex<double> > &k_channels_tab , 
						     class array<complex<double> > &eta_channels_tab)
{	
  const enum interaction_type inter = input_data.get_inter ();

  const unsigned int N_energies = E_total_tab.dimension (0);

  const int Z = input_data.get_Z ();
  const int N = input_data.get_N ();

  const unsigned int N_target_projectile_states = e_channels_tab.dimension (0);

  const double prot_mass_for_calc = input_data.get_prot_mass_for_calc ();
  const double neut_mass_for_calc = input_data.get_neut_mass_for_calc ();

  const double nucleus_mass = input_data.get_nucleus_mass ();

  const bool is_it_COSM = is_it_COSM_determine (inter);

  for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
    {
      const enum particle_type projectile = projectile_tab(iT);

      const complex<double> E_target = E_target_tab(iT);

      const complex<double> E_intrinsic = E_intrinsic_projectile_tab(iT);

      const int Z_target = Z_target_determine (Z , projectile);
      const int N_target = N_target_determine (N , projectile);

      const double mass_target = (!is_it_COSM) ? (mass_target_determine (Z_target , N_target , projectile , prot_mass_for_calc , neut_mass_for_calc)) : (nucleus_mass);
      
      const double mass_projectile = mass_cluster_determine (projectile , prot_mass_for_calc , neut_mass_for_calc);

      const double kinetic_factor_projectile = kinetic_factor_calc (false , mass_target , mass_projectile);

      for (unsigned int iE = 0 ; iE < N_energies ; iE++)
	{
	  const double E_total = E_total_tab(iE);
	  
	  const complex<double> e_projectile = E_total - E_target - E_intrinsic;

	  const complex<double> k_projectile = sqrt_mod (e_projectile*kinetic_factor_projectile);

	  const complex<double> eta_projectile = (k_projectile != 0.0) ? (eta_calc (false , projectile , Z_target , kinetic_factor_projectile , k_projectile)) : (INFINITE);

	  e_channels_tab(iT , iE) = e_projectile;
	  k_channels_tab(iT , iE) = k_projectile;
	  
	  eta_channels_tab(iT , iE) = eta_projectile;
	}
    }
}






unsigned int CC_common_routines::JPi_index_determine (
						      const class array<unsigned int> &BP_A_tab , 
						      const class array<double> &J_A_tab , 
						      const unsigned int BP_A , 
						      const double J_A)
{
  const unsigned int N_JPi_A = BP_A_tab.dimension (0);

  for (unsigned int iJPi_A = 0 ; iJPi_A < N_JPi_A ; iJPi_A++)
    {
      const double J = J_A_tab(iJPi_A);

      const unsigned int BP = BP_A_tab(iJPi_A);

      if (same_BP_J (BP , J , BP_A , J_A)) return iJPi_A;
    }

  error_message_print_abort ("No index found in CC_common_routines::JPi_index_determine.");

  return NADA;
}






void CC_common_routines::JPi_channels_tab_BP_J_fill (
						     const class array<class CC_channel_class> &channels_tab , 
						     const unsigned int BP_A , 
						     const double J_A , 
						     class array<class CC_channel_class> &JPi_channels_tab)
{
  const unsigned int N_channels = channels_tab.dimension (0);

  const unsigned int JPi_channels_tab_dimension = JPi_channels_tab.dimension (0);
  
  unsigned int JPi_ic = 0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const double J = channel_c.get_J ();

      const unsigned int BP = channel_c.get_BP ();

      if (same_BP_J (BP , J , BP_A , J_A))
	{
	  if (JPi_ic == JPi_channels_tab_dimension) error_message_print_abort ("Index too large in CC_common_routines::JPi_channels_tab_BP_J_fill.");
      
	  class CC_channel_class &JPi_channel_c = JPi_channels_tab(JPi_ic++);
  
	  JPi_channel_c.initialize (channel_c);
	}
    }
}




void CC_common_routines::JPi_channels_tab_BP_J_E_fill (
						       const class array<class CC_channel_class> &channels_tab , 
						       const unsigned int BP_A , 
						       const double J_A , 
						       const complex<double> &E , 
						       class array<class CC_channel_class> &JPi_channels_tab)
{
  const unsigned int N_channels = channels_tab.dimension (0);

  const unsigned int JPi_channels_tab_dimension = JPi_channels_tab.dimension (0);
  
  unsigned int JPi_ic = 0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const double J = channel_c.get_J ();

      const unsigned int BP = channel_c.get_BP ();

      if (same_BP_J (BP , J , BP_A , J_A))
	{
	  if (JPi_ic == JPi_channels_tab_dimension) error_message_print_abort ("Index too large in CC_common_routines::JPi_channels_tab_BP_J_E_fill.");
	  
	  class CC_channel_class &JPi_channel_c = JPi_channels_tab(JPi_ic++);

	  JPi_channel_c.initialize (channel_c);

	  JPi_channel_c.E_dependent_values_change (E) ;
	}     
    }
}




void CC_common_routines::JPi_channels_tab_BP_J_vector_index_fill (
								  const class array<class CC_channel_class> &channels_tab , 
								  const unsigned int BP_A , 
								  const double J_A , 
								  const unsigned int vector_index_A , 
								  class array<class CC_channel_class> &JPi_channels_tab)
{
  const unsigned int N_channels = channels_tab.dimension (0);

  const unsigned int JPi_channels_tab_dimension = JPi_channels_tab.dimension (0);
  
  unsigned int JPi_ic = 0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const double J = channel_c.get_J ();

      const unsigned int BP = channel_c.get_BP ();

      const unsigned int vector_index = channel_c.get_vector_index ();
      
      if (same_BP_J_vector_index (BP , J , vector_index , BP_A , J_A , vector_index_A))
	{
	  if (JPi_ic == JPi_channels_tab_dimension) error_message_print_abort ("Index too ge in CC_common_routines::JPi_channels_tab_BP_J_vector_index_fill.");
	  
	  class CC_channel_class &JPi_channel_c = JPi_channels_tab(JPi_ic++);

	  JPi_channel_c.initialize (channel_c);
	}
    }
}






void CC_common_routines::JPi_channels_tab_BP_J_vector_index_E_fill (
								    const class array<class CC_channel_class> &channels_tab , 
								    const unsigned int BP_A , 
								    const double J_A , 
								    const unsigned int vector_index_A , 
								    const complex<double> &E , 
								    class array<class CC_channel_class> &JPi_channels_tab)
{
  const unsigned int N_channels = channels_tab.dimension (0);

  const unsigned int JPi_channels_tab_dimension = JPi_channels_tab.dimension (0);
  
  unsigned int JPi_ic = 0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const double J = channel_c.get_J ();

      const unsigned int BP = channel_c.get_BP ();

      const unsigned int vector_index = channel_c.get_vector_index ();
      
      if (same_BP_J_vector_index (BP , J , vector_index , BP_A , J_A , vector_index_A))
	{
	  if (JPi_ic == JPi_channels_tab_dimension) error_message_print_abort ("Index too large in CC_common_routines::JPi_channels_tab_BP_J_vector_index_E_fill.");
	  
	  class CC_channel_class &JPi_channel_c = JPi_channels_tab(JPi_ic++);

	  JPi_channel_c.initialize (channel_c);

	  JPi_channel_c.E_dependent_values_change (E) ;
	}      
    }
}




double CC_common_routines::JT_max_determine (const class array<class CC_channel_class> &channels_tab)
{
  const unsigned int N_channels = channels_tab.dimension (0);

  double JT_max = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      JT_max = max (channels_tab(ic).get_J_Tc () , JT_max);
    }

  return JT_max;
}






unsigned int CC_common_routines::CC_N_nlj_calc (
						const enum particle_type particle , 
						const class array<class CC_channel_class> &channels_tab)
{
  const unsigned int N_channels = channels_tab.dimension (0);

  unsigned int CC_N_nlj = 0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type particle_c = channel_c.get_projectile ();

      const int lc = channel_c.get_LCM_projectile ();

      const unsigned int BP_intrinsic = BP_intrinsic_cluster_determine (particle_c);

      const double J_intrinsic = J_intrinsic_cluster_determine (particle_c);

      const double two_J_intrinsic = make_int (2.0*J_intrinsic);

      if (is_particle_in_cluster (particle , particle_c))
	{
	  // jc is fixed if one has 1/2+ as intrinsic quantum numbers. Otherwise, one takes the two possible jc's for the considered lc by default.
	  
	  if ((BP_intrinsic == 0) && (two_J_intrinsic == 1))
	    CC_N_nlj++;
	  else
	    {
	      if (lc == 0)
		CC_N_nlj++;
	      else
		CC_N_nlj += 2;
	    }
	}
    }

  return CC_N_nlj;
}






void CC_common_routines::CC_shells_qn_fill (
					    const bool S_matrix_pole , 
					    const enum particle_type particle , 
					    const class lj_table<int> &prot_nmin_lj_valence_tab , 
					    const class lj_table<int> &neut_nmin_lj_valence_tab , 
					    const class array<class CC_channel_class> &channels_tab , 
					    const class lj_table<bool> &OCM_valence_state_tab , 
					    class array<class nlj_struct> &CC_shells_qn)
{
  const unsigned int N_channels = channels_tab.dimension (0);

  const int prot_nmin_lj_valence_all = (prot_nmin_lj_valence_tab.dimension_total () > 0) ? (prot_nmin_lj_valence_tab.max ()) : (0);
  const int neut_nmin_lj_valence_all = (neut_nmin_lj_valence_tab.dimension_total () > 0) ? (neut_nmin_lj_valence_tab.max ()) : (0);

  const int nmin_valence_all = max (prot_nmin_lj_valence_all , neut_nmin_lj_valence_all);

  unsigned int i = 0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const enum particle_type particle_c = channel_c.get_projectile ();

      const int lc = channel_c.get_LCM_projectile ();

      const complex<double> kc = channel_c.get_k_projectile ();

      const unsigned int BP_intrinsic = BP_intrinsic_cluster_determine (particle_c);

      const double J_intrinsic = J_intrinsic_cluster_determine (particle_c);

      const double two_J_intrinsic = make_int (2.0*J_intrinsic);

      const int nc = make_int (ic) + nmin_valence_all;

      if (is_particle_in_cluster (particle , particle_c))
	{
	  // jc is fixed if one has 1/2+ as intrinsic quantum numbers. Otherwise, one takes the two possible jc's for the considered lc by default.
	  
	  if ((BP_intrinsic == 0) && (two_J_intrinsic == 1))
	    {
	      const double jc = channel_c.get_J_projectile ();	      

	      const bool OCM_valence_state = OCM_valence_state_tab(lc , jc);

	      CC_shells_qn(i++).initialize (S_matrix_pole , false , false , false , OCM_valence_state , false , false , false , NADA , 
					    nc , lc , jc , NO_SEGMENT , kc , NADA , 1. , 1. , NADA , 1. , NADA , 1.);
	    }
	  else
	    {
	      for (double jc = (lc == 0) ? (0.5) : (lc - 0.5) ; rint (jc - lc - 0.5) <= 0.0 ; jc++)
		{
		  const bool OCM_valence_state = OCM_valence_state_tab(lc , jc);

		  CC_shells_qn(i++).initialize (S_matrix_pole , false , false , false , OCM_valence_state , false , false , false , NADA , 
						nc , lc , jc , NO_SEGMENT , kc , NADA , 1. , 1. , NADA , 1. , NADA , 1.);
		}
	    }
	}
    }
}







unsigned int CC_common_routines::entrance_target_index_determine (const class input_data_str &input_data)
{
  const enum CC_reaction_calculation_type CC_reaction_calculation = input_data.get_CC_reaction_calculation ();
  
  if (CC_reaction_calculation == POLES) return NADA;

  const unsigned int N_target_projectile_states = input_data.get_CC_N_target_projectile_states ();

  const class array<bool> &CC_is_it_entrance_tab = input_data.get_CC_is_it_entrance_tab ();

  for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
    {	
      // Entrance channel booleans

      const bool is_it_entrance_channel = CC_is_it_entrance_tab(iT);

      if (is_it_entrance_channel) return iT;
    }

  error_message_print_abort ("No entrance channel found in CC_common_routines::entrance_target_index_determine.");

  return NADA;
}







double CC_common_routines::J_intrinsic_projectile_max_determine (const class input_data_str &input_data)
{
  const unsigned int N_target_projectile_states = input_data.get_CC_N_target_projectile_states ();

  const class array<enum particle_type> &CC_projectile_tab = input_data.get_CC_projectile_tab ();

  double J_intrinsic_projectile_max = 0.0;

  for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
    {
      const enum particle_type projectile = CC_projectile_tab(iT);

      const double J_intrinsic_projectile = J_intrinsic_cluster_determine (projectile);

      J_intrinsic_projectile_max = max (J_intrinsic_projectile , J_intrinsic_projectile_max);
    }

  return J_intrinsic_projectile_max;
}
















void CC_common_routines::channels_tab_inputs (
					      const class input_data_str &input_data , 
					      const bool is_it_in_states , 
					      const class array<unsigned int> &BP_A_tab , 
					      const class array<double> &J_A_tab , 
					      class array<unsigned int> &N_channels_tab , 
					      class array<unsigned int> &N_entrance_channels_tab , 
					      class array<unsigned int> &N_channels_per_target_projectile_tab)
{	
  const unsigned int N_target_projectile_states = input_data.get_CC_N_target_projectile_states ();

  const enum CC_reaction_calculation_type CC_reaction_calculation = input_data.get_CC_reaction_calculation ();

  const bool is_it_in_states_for_scat = (is_it_in_states && (CC_reaction_calculation != POLES));

  const class array<bool> &CC_is_it_entrance_tab = input_data.get_CC_is_it_entrance_tab ();

  const class array<unsigned int> &CC_BP_target_tab = input_data.get_CC_BP_target_tab ();

  const class array<unsigned int> &CC_N_partial_waves_tab = input_data.get_CC_N_partial_waves_tab ();

  const class array<double> &CC_J_target_tab = input_data.get_CC_J_target_tab ();

  const class array<enum particle_type> &CC_projectile_tab = input_data.get_CC_projectile_tab ();

  const class array<int> &CC_partial_wave_L_cluster_projectile_tab = input_data.get_CC_partial_wave_L_cluster_projectile_tab ();

  const class array<double> &CC_partial_wave_J_cluster_projectile_tab = input_data.get_CC_partial_wave_J_cluster_projectile_tab ();

  const unsigned int N_JPi_A = BP_A_tab.dimension (0);

  N_channels_tab = 0;

  N_entrance_channels_tab = 0;

  N_channels_per_target_projectile_tab = 0;

  for (unsigned int iJPi_A = 0 ; iJPi_A < N_JPi_A ; iJPi_A++)
    {
      const double J_A = J_A_tab(iJPi_A);

      const unsigned int BP_A = BP_A_tab(iJPi_A);

      for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
	{
	  const bool is_it_entrance_channel = CC_is_it_entrance_tab(iT);

	  const double J_T = CC_J_target_tab(iT);

	  const unsigned int BP_T = CC_BP_target_tab(iT);

	  const enum particle_type projectile = CC_projectile_tab(iT);

	  const unsigned int BP_intrinsic_projectile = BP_intrinsic_cluster_determine (projectile);

	  const double J_intrinsic_projectile = J_intrinsic_cluster_determine (projectile);

	  // Properties of the partial waves
	  const unsigned int N_partial_waves = CC_N_partial_waves_tab(iT);

	  for (unsigned int i_projectile = 0 ; i_projectile < N_partial_waves ; i_projectile++)
	    {
	      const int LCM_projectile = CC_partial_wave_L_cluster_projectile_tab(iT , i_projectile);

	      const unsigned int BP_LCM_projectile = binary_parity_from_orbital_angular_momentum (LCM_projectile);

	      const double J_projectile = CC_partial_wave_J_cluster_projectile_tab(iT , i_projectile);

	      const unsigned int BP_projectile = binary_parity_product (BP_intrinsic_projectile , BP_LCM_projectile);

	      const bool is_J_projectile_ok = is_it_triangle (LCM_projectile , J_intrinsic_projectile , J_projectile);
	      
	      const bool is_BP_projectile_ok = (binary_parity_product (BP_LCM_projectile , BP_intrinsic_projectile) == BP_projectile);

	      if (is_J_projectile_ok && is_BP_projectile_ok)
		{
		  const bool is_J_A_ok = is_it_triangle (J_T , J_projectile , J_A);

		  const bool is_BP_A_ok = (binary_parity_product (BP_T , BP_projectile) == BP_A);

		  if (is_J_A_ok && is_BP_A_ok)
		    {
		      N_channels_per_target_projectile_tab(iT , iJPi_A)++;
		      
		      N_channels_tab(iJPi_A)++;

		      if (is_it_in_states_for_scat && is_it_entrance_channel) N_entrance_channels_tab(iJPi_A)++;
		    }
		}
	    }
	}
    }

  if (is_it_in_states_for_scat)
    {
      for (unsigned int iJPi_A = 0 ; iJPi_A < N_JPi_A ; iJPi_A++)
	{
	  if (N_entrance_channels_tab(iJPi_A) == 0)
	    {
	      const double J_A = J_A_tab(iJPi_A);

	      const unsigned int BP_A = BP_A_tab(iJPi_A);
      
	      error_message_print_abort ("There is no " + J_Pi_string (BP_A , J_A) + " entrance channel");
	    }
	}
    }
}







bool CC_common_routines::is_it_HO_channel_decomposition_determine (
								   const enum particle_type projectile , 
								   const int LCM_projectile , 
								   const double J_projectile , 
								   const class input_data_str &input_data)
{
  if ((projectile != PROTON) && (projectile != NEUTRON)) return true;

  const unsigned int N_nlj = (projectile == PROTON) ? (input_data.get_Np_nlj ()) : (input_data.get_Nn_nlj) ();

  const class array<class nlj_struct> &shells_qn = (projectile == PROTON) ? (input_data.get_prot_shells_quantum_numbers ()) : (input_data.get_neut_shells_quantum_numbers ());

  for (unsigned int i = 0 ; i < N_nlj ; i++)
    {
      const class nlj_struct &shell_qn = shells_qn(i);

      const bool frozen_state = shell_qn.get_frozen_state ();

      if (!frozen_state)
	{
	  const int l = shell_qn.get_l ();

	  const double j = shell_qn.get_j ();

	  if (same_lj (l , j , LCM_projectile , J_projectile))
	    {
	      const bool is_it_HO = shell_qn.get_is_it_HO ();

	      return is_it_HO;
	    }
	}
    }

  error_message_print_abort ("The " + make_string (projectile) + " " + angular_state (LCM_projectile , J_projectile) + " partial wave does not have any one-body states in the basis.");

  return false;
}






void CC_common_routines::channels_tab_construction (
						    const class input_data_str &input_data , 
						    const bool is_it_in_states , 
						    const bool is_it_out_states , 
						    const class nucleons_data &prot_data , 
						    const class nucleons_data &neut_data , 
						    const class array<unsigned int> &BP_A_tab , 
						    const class array<unsigned int> &vector_index_A_tab , 
						    const class array<double> &J_A_tab , 
						    class array<unsigned int> &entrance_JPi_channels_indices , 	
						    class array<unsigned int> &JPi_channels_indices_per_target_projectile , 
						    class array<class CC_channel_class> &channels_tab)
{	
  const enum interaction_type inter = input_data.get_inter ();

  const double nucleus_mass = input_data.get_nucleus_mass ();

  const double prot_mass_for_calc = input_data.get_prot_mass_for_calc ();
  const double neut_mass_for_calc = input_data.get_neut_mass_for_calc ();

  const double b_lab = input_data.get_b_lab ();

  const unsigned int N_target_projectile_states = input_data.get_CC_N_target_projectile_states ();

  const enum CC_reaction_calculation_type CC_reaction_calculation = input_data.get_CC_reaction_calculation ();

  const bool is_it_pole_calculation = (CC_reaction_calculation == POLES);
    
  const class array<unsigned int> &CC_BP_target_tab = input_data.get_CC_BP_target_tab ();

  const class array<unsigned int> &CC_vector_index_target_tab = input_data.get_CC_vector_index_target_tab ();

  const class array<bool> &CC_is_it_pole_target_tab = input_data.get_CC_is_it_pole_target_tab ();

  const class array<unsigned int> &CC_N_partial_waves_tab = input_data.get_CC_N_partial_waves_tab ();

  const class array<double> &CC_J_target_tab = input_data.get_CC_J_target_tab ();

  const class array<enum particle_type> &CC_projectile_tab = input_data.get_CC_projectile_tab ();

  const class array<double> &CC_real_E_target_tab = input_data.get_CC_real_E_target_tab ();

  const class array<double> &CC_Gamma_target_tab = input_data.get_CC_Gamma_target_tab ();

  const class array<double> &CC_real_E_intrinsic_projectile_tab = input_data.get_CC_real_E_intrinsic_projectile_tab ();

  const class array<double> &CC_Gamma_intrinsic_projectile_tab = input_data.get_CC_Gamma_intrinsic_projectile_tab ();

  const class array<int> &CC_partial_wave_L_cluster_projectile_tab = input_data.get_CC_partial_wave_L_cluster_projectile_tab ();

  const class array<double> &CC_partial_wave_J_cluster_projectile_tab = input_data.get_CC_partial_wave_J_cluster_projectile_tab ();

  const class array<bool> &CC_is_it_entrance_tab = input_data.get_CC_is_it_entrance_tab ();

  const class array<complex<double> > &CC_average_n_scat_target_tab = input_data.get_CC_average_n_scat_target_tab ();

  const unsigned int N_JPi_A = BP_A_tab.dimension (0);

  const int Z = prot_data.get_N_nucleons ();
  const int N = neut_data.get_N_nucleons ();

  entrance_JPi_channels_indices = NADA;

  unsigned int ic = 0;

  for (unsigned int iJPi_A = 0 ; iJPi_A < N_JPi_A ; iJPi_A++)
    {
      const unsigned int BP_A = BP_A_tab(iJPi_A);

      const unsigned int vector_index_A = (is_it_out_states) ? (vector_index_A_tab(iJPi_A)) : (NADA);

      const double J_A = J_A_tab(iJPi_A);

      const double M_A = J_A;

      unsigned int ic_iJPi_A = 0;

      for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
	{
	  const bool is_it_entrance_channel = CC_is_it_entrance_tab(iT);

	  const double J_T = CC_J_target_tab(iT);

	  const unsigned int BP_T = CC_BP_target_tab(iT);

	  const unsigned int vector_index_T = CC_vector_index_target_tab(iT);

	  const enum particle_type projectile = CC_projectile_tab(iT);

	  const bool S_matrix_pole_T = CC_is_it_pole_target_tab(iT);

	  const double real_E_T = CC_real_E_target_tab(iT);
	  
	  const double Gamma_T = CC_Gamma_target_tab(iT);

	  const complex<double> E_T(real_E_T , -5E-4*Gamma_T);

	  const complex<double> average_n_scat_T = CC_average_n_scat_target_tab(iT);

	  const double real_E_intrinsic_projectile = CC_real_E_intrinsic_projectile_tab(iT);

	  const double Gamma_intrinsic_projectile = CC_Gamma_intrinsic_projectile_tab(iT);

	  const complex<double> E_intrinsic_projectile(real_E_intrinsic_projectile , -5E-4*Gamma_intrinsic_projectile);

	  const unsigned int BP_intrinsic_projectile = BP_intrinsic_cluster_determine (projectile);
	  
	  const double J_intrinsic_projectile = J_intrinsic_cluster_determine (projectile);

	  // Properties of the partial waves
	  const unsigned int N_partial_waves = CC_N_partial_waves_tab(iT);

	  unsigned int ic_target_projectile = 0;

	  unsigned int i_entrance = 0;

	  for (unsigned int i_projectile = 0 ; i_projectile < N_partial_waves ; i_projectile++)
	    {	      
	      const int LCM_projectile = CC_partial_wave_L_cluster_projectile_tab(iT , i_projectile);

	      const unsigned int BP_LCM_projectile = binary_parity_from_orbital_angular_momentum (LCM_projectile);

	      const double J_projectile = CC_partial_wave_J_cluster_projectile_tab(iT , i_projectile);

	      const unsigned int BP_projectile = binary_parity_product (BP_intrinsic_projectile , BP_LCM_projectile);

	      const bool is_J_projectile_ok = is_it_triangle (LCM_projectile , J_intrinsic_projectile , J_projectile);
	      
	      const bool is_BP_projectile_ok = (binary_parity_product (BP_LCM_projectile , BP_intrinsic_projectile) == BP_projectile);

	      if (is_J_projectile_ok && is_BP_projectile_ok)
		{
		  const bool is_J_A_ok = is_it_triangle (J_T , J_projectile , J_A);

		  const bool is_BP_A_ok = (binary_parity_product (BP_T , BP_projectile) == BP_A);

		  if (is_J_A_ok && is_BP_A_ok)
		    {
		      const bool is_it_HO_channel_decomposition = is_it_HO_channel_decomposition_determine (projectile , LCM_projectile , J_projectile , input_data);

		      JPi_channels_indices_per_target_projectile(iT , iJPi_A , ic_target_projectile++) = ic_iJPi_A;

		      if (is_it_in_states && !is_it_pole_calculation && is_it_entrance_channel) entrance_JPi_channels_indices(iJPi_A , i_entrance++) = ic_iJPi_A;
		      
		      ic_iJPi_A ++;

		      channels_tab(ic++).initialize (inter , prot_mass_for_calc , neut_mass_for_calc , nucleus_mass , b_lab , Z , N , projectile , 
						     BP_T , J_T , vector_index_T , S_matrix_pole_T , E_T , E_intrinsic_projectile , average_n_scat_T , 
						     LCM_projectile , J_projectile , vector_index_A , J_A , M_A , 0.0 , is_it_HO_channel_decomposition);
		    }}}}}
}







void CC_common_routines::OCM_valence_state_tab_fill (	
						     const class nucleons_data &CC_particles_data , 
						     class lj_table<bool> &OCM_valence_state_tab)
{
  const unsigned int CC_N_nlj = CC_particles_data.get_N_nlj ();

  const int CC_lmax = CC_particles_data.get_lmax ();

  const class array<class nlj_struct> &CC_shells_qn = CC_particles_data.get_shells_quantum_numbers ();

  for (int l = 0 ; l <= CC_lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      for (unsigned int s = 0 ; s < CC_N_nlj ; s++)
	{
	  const class nlj_struct &shell_qn_s = CC_shells_qn(s);

	  const bool core_state_s = shell_qn_s.get_core_state ();

	  const int ls = shell_qn_s.get_l ();

	  const double js = shell_qn_s.get_j ();

	  if (core_state_s && same_lj (l , j , ls , js)) OCM_valence_state_tab(l , j) = true;
	}
}




void CC_common_routines::prepare_CC_prot_neut_data (
						    const class array<class CC_channel_class> &channels_JPi_A_tab , 
						    const bool S_matrix_pole , 
						    const class lj_table<int> &prot_nmin_lj_valence_tab , 
						    const class lj_table<int> &neut_nmin_lj_valence_tab , 
						    const class lj_table<bool> &prot_OCM_valence_state_tab , 
						    const class lj_table<bool> &neut_OCM_valence_state_tab , 
						    class nucleons_data &CC_prot_data , 
						    class nucleons_data &CC_neut_data)
{
  const unsigned int CC_Np_nlj = CC_N_nlj_calc (PROTON  , channels_JPi_A_tab);
  const unsigned int CC_Nn_nlj = CC_N_nlj_calc (NEUTRON , channels_JPi_A_tab);

  const unsigned int CC_Np_nlj_res = min (CC_Np_nlj , CC_prot_data.get_N_nlj_res ());
  const unsigned int CC_Nn_nlj_res = min (CC_Nn_nlj , CC_neut_data.get_N_nlj_res ());

  class array<class nlj_struct> CC_shells_qn_prot(CC_Np_nlj);
  class array<class nlj_struct> CC_shells_qn_neut(CC_Nn_nlj);

  CC_shells_qn_fill (S_matrix_pole , PROTON  , prot_nmin_lj_valence_tab , neut_nmin_lj_valence_tab , channels_JPi_A_tab , prot_OCM_valence_state_tab , CC_shells_qn_prot);
  CC_shells_qn_fill (S_matrix_pole , NEUTRON , prot_nmin_lj_valence_tab , neut_nmin_lj_valence_tab , channels_JPi_A_tab , neut_OCM_valence_state_tab , CC_shells_qn_neut);

  CC_prot_data.set_N_nlj_N_nlj_res_shells_quantum_numbers_realloc_fill (CC_Np_nlj_res , CC_Np_nlj , CC_shells_qn_prot);
  CC_neut_data.set_N_nlj_N_nlj_res_shells_quantum_numbers_realloc_fill (CC_Nn_nlj_res , CC_Nn_nlj , CC_shells_qn_neut);
}














void CC_common_routines::Ueq_source_averaged_calc (
						   const double new_potential_fraction , 
						   const class array<complex<double> > &Ueq_tab_new , 
						   const class array<complex<double> > &source_tab_new , 
						   class array<complex<double> > &Ueq_tab_averaged , 
						   class array<complex<double> > &source_tab_averaged) 
{
  const double one_minus_new_potential_fraction = 1.0 - new_potential_fraction;

  Ueq_tab_averaged *= one_minus_new_potential_fraction;
  
  source_tab_averaged *= one_minus_new_potential_fraction;

  Ueq_tab_averaged += Ueq_tab_new*complex<double> (new_potential_fraction);
  
  source_tab_averaged += source_tab_new*complex<double> (new_potential_fraction);
}










void CC_common_routines::allowed_JPi_channels_calc_print (const class input_data_str &input_data_CC_Berggren)
{	
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in CC_scattering_cross_section::allowed_JPi_channels_calc_print");

  const unsigned int N_target_projectile_states = input_data_CC_Berggren.get_CC_N_target_projectile_states ();

  const unsigned int CC_N_JPi_A_composite = input_data_CC_Berggren.get_CC_N_JPi_A_composite ();

  const class array<unsigned int> &CC_BP_A_tab = input_data_CC_Berggren.get_CC_BP_A_composite_tab ();

  const class array<double> &CC_J_A_tab = input_data_CC_Berggren.get_CC_J_A_composite_tab ();

  const class array<unsigned int> &CC_BP_target_tab = input_data_CC_Berggren.get_CC_BP_target_tab ();

  const class array<unsigned int> &CC_vector_index_target_tab = input_data_CC_Berggren.get_CC_vector_index_target_tab ();

  const class array<unsigned int> &CC_N_partial_waves_tab = input_data_CC_Berggren.get_CC_N_partial_waves_tab ();

  const class array<double> &CC_J_target_tab = input_data_CC_Berggren.get_CC_J_target_tab ();

  const class array<enum particle_type> &CC_projectile_tab = input_data_CC_Berggren.get_CC_projectile_tab ();

  const class array<int> &CC_partial_wave_L_cluster_projectile_tab = input_data_CC_Berggren.get_CC_partial_wave_L_cluster_projectile_tab ();

  const class array<double> &CC_partial_wave_J_cluster_projectile_tab = input_data_CC_Berggren.get_CC_partial_wave_J_cluster_projectile_tab ();

  unsigned int BP_T_bef = 2;

  unsigned int vector_index_T_bef = 1000;

  double J_T_bef = -1.0;

  for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
    {
      const double J_T = CC_J_target_tab(iT);

      const unsigned int BP_T = CC_BP_target_tab(iT);

      const unsigned int vector_index_T = CC_vector_index_target_tab(iT);

      const enum particle_type projectile = CC_projectile_tab(iT);

      const bool is_it_one_nucleon = ((projectile == PROTON) || (projectile == NEUTRON));

      const unsigned int BP_intrinsic_projectile = BP_intrinsic_cluster_determine (projectile);

      const double J_intrinsic_projectile = J_intrinsic_cluster_determine (projectile);

      // Properties of the partial waves
      const unsigned int N_partial_waves = CC_N_partial_waves_tab(iT);

      const bool is_it_vector_index_T_changing_only = ((iT > 0) && (BP_T_bef == BP_T) && (rint (J_T_bef - J_T) == 0.0) && (vector_index_T_bef != vector_index_T));

      if (!is_it_vector_index_T_changing_only)
	{
	  for (unsigned int i_projectile = 0 ; i_projectile < N_partial_waves ; i_projectile++)
	    {
	      const int LCM_projectile = CC_partial_wave_L_cluster_projectile_tab(iT , i_projectile);

	      const unsigned int BP_LCM_projectile = binary_parity_from_orbital_angular_momentum (LCM_projectile);

	      const double J_projectile = CC_partial_wave_J_cluster_projectile_tab(iT , i_projectile);

	      const unsigned int BP_projectile = binary_parity_product (BP_intrinsic_projectile , BP_LCM_projectile);

	      const double Jmin_projectile = abs (J_intrinsic_projectile - LCM_projectile);

	      const double Jmax_projectile = J_intrinsic_projectile + LCM_projectile;

	      if (is_it_one_nucleon)
		cout << projectile << " " << angular_state (LCM_projectile , J_projectile) << " ";
	      else
		{
		  cout << projectile << " intrinsic : " << J_Pi_string (BP_intrinsic_projectile , J_intrinsic_projectile);
		  
		  cout << " , CM : " << J_Pi_string (BP_LCM_projectile , LCM_projectile);

		  cout << " , total : " << J_Pi_string (BP_projectile , J_projectile) << " " ;
		}

	      if ((rint (J_projectile - Jmin_projectile) >= 0.0) && (rint (J_projectile - Jmax_projectile) <= 0.0))
		{	
		  if (!is_it_one_nucleon) 
		    cout << "=> allowed" << endl;
		  else
		    cout << endl;

		  print_composite_possible_couplings (BP_T , J_T , BP_projectile , J_projectile , CC_N_JPi_A_composite , CC_BP_A_tab , CC_J_A_tab);

		  cout << endl;
		}
	      else
		cout << "=> forbidden" << endl;
	    }
	}
      
      BP_T_bef = BP_T;

      J_T_bef = J_T;

      vector_index_T_bef = vector_index_T;
    }
}







void CC_common_routines::observable_allowed_JPi_channels_calc_print (
								     const unsigned int BP_Op , 
								     const int rank_Op , 
								     const class input_data_str &input_data_CC_Berggren)
{	
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in CC_common_routines::allowed_JPi_channels_calc_print (1)");

  const unsigned int CC_N_target_projectile_states = input_data_CC_Berggren.get_CC_N_target_projectile_states ();

  const unsigned int CC_N_JPi_A_in  = input_data_CC_Berggren.get_CC_N_JPi_A_in_composite ();
  const unsigned int CC_N_JPi_A_out = input_data_CC_Berggren.get_CC_N_JPi_A_out_composite ();

  const class array<unsigned int> &CC_BP_A_tab_in  = input_data_CC_Berggren.get_CC_BP_A_in_composite_tab ();
  const class array<unsigned int> &CC_BP_A_tab_out = input_data_CC_Berggren.get_CC_BP_A_out_composite_tab ();
  
  const class array<double> &CC_J_A_tab_in  = input_data_CC_Berggren.get_CC_J_A_in_composite_tab ();
  const class array<double> &CC_J_A_tab_out = input_data_CC_Berggren.get_CC_J_A_out_composite_tab ();
  
  const class array<unsigned int> &CC_BP_target_tab = input_data_CC_Berggren.get_CC_BP_target_tab ();

  const class array<unsigned int> &CC_vector_index_target_tab = input_data_CC_Berggren.get_CC_vector_index_target_tab ();

  const class array<unsigned int> &CC_N_partial_waves_tab = input_data_CC_Berggren.get_CC_N_partial_waves_tab ();

  const class array<double> &CC_J_target_tab = input_data_CC_Berggren.get_CC_J_target_tab ();

  const class array<enum particle_type> &CC_projectile_tab = input_data_CC_Berggren.get_CC_projectile_tab ();

  const class array<int> &CC_partial_wave_L_cluster_projectile_tab = input_data_CC_Berggren.get_CC_partial_wave_L_cluster_projectile_tab ();

  const class array<double> &CC_partial_wave_J_cluster_projectile_tab = input_data_CC_Berggren.get_CC_partial_wave_J_cluster_projectile_tab ();

  unsigned int BP_T_bef = 2;

  unsigned int vector_index_T_bef = 1000;

  double J_T_bef = -1.0;

  for (unsigned int iT = 0 ; iT < CC_N_target_projectile_states ; iT++)
    {
      const double J_T = CC_J_target_tab(iT);

      const unsigned int BP_T = CC_BP_target_tab(iT);

      const unsigned int vector_index_T = CC_vector_index_target_tab(iT);

      const enum particle_type projectile = CC_projectile_tab(iT);

      const bool is_it_one_nucleon = ((projectile == PROTON) || (projectile == NEUTRON));

      const unsigned int BP_intrinsic_projectile = BP_intrinsic_cluster_determine (projectile);

      const double J_intrinsic_projectile = J_intrinsic_cluster_determine (projectile);

      // Properties of the partial waves
      const unsigned int N_partial_waves = CC_N_partial_waves_tab(iT);

      const bool is_it_vector_index_T_changing_only = ((iT > 0) && (BP_T_bef == BP_T) && (rint (J_T_bef - J_T) == 0.0) && (vector_index_T_bef != vector_index_T));

      if (!is_it_vector_index_T_changing_only)
	{
	  for (unsigned int i_projectile = 0 ; i_projectile < N_partial_waves ; i_projectile++)
	    {
	      const int LCM_projectile = CC_partial_wave_L_cluster_projectile_tab(iT , i_projectile);

	      const unsigned int BP_LCM_projectile = binary_parity_from_orbital_angular_momentum (LCM_projectile);

	      const double J_projectile = CC_partial_wave_J_cluster_projectile_tab(iT , i_projectile);

	      const unsigned int BP_projectile = binary_parity_product (BP_intrinsic_projectile , BP_LCM_projectile);

	      const double Jmin_projectile = abs (J_intrinsic_projectile - LCM_projectile);

	      const double Jmax_projectile = J_intrinsic_projectile + LCM_projectile;

	      cout << endl;

	      if (is_it_one_nucleon)
		cout << projectile << " " << angular_state (LCM_projectile , J_projectile) << " ";
	      else
		{
		  cout << projectile << " intrinsic : " << J_Pi_string (BP_intrinsic_projectile , J_intrinsic_projectile); 

		  cout << " , CM : " << J_Pi_string (BP_LCM_projectile , LCM_projectile) << " , total : " << J_Pi_string (BP_projectile , J_projectile) << " " ;
		}

	      if ((rint (J_projectile - Jmin_projectile) <= 0.0) && (rint (J_projectile - Jmax_projectile) <= 0.0))
		{	
		  if (!is_it_one_nucleon) 
		    cout << "=> allowed" << endl;
		  else
		    cout << endl;

		  cout << endl << "In states " << endl;

		  print_composite_possible_couplings (BP_T , J_T , BP_projectile , J_projectile , CC_N_JPi_A_in , CC_BP_A_tab_in , CC_J_A_tab_in);

		  cout << endl;

		  cout << "Out states " << endl;

		  print_composite_possible_couplings (BP_T , J_T , BP_projectile , J_projectile , CC_N_JPi_A_out , CC_BP_A_tab_out , CC_J_A_tab_out);

		  cout << endl;

		  for (unsigned int iJPi_A_in = 0 ; iJPi_A_in < CC_N_JPi_A_in ; iJPi_A_in++)
		    {
		      const unsigned int BP_A_in = CC_BP_A_tab_in(iJPi_A_in);

		      const double J_A_in = CC_J_A_tab_in(iJPi_A_in);

		      for (unsigned int iJPi_A_out = 0 ; iJPi_A_out < CC_N_JPi_A_out ; iJPi_A_out++)
			{
			  const unsigned int BP_A_out = CC_BP_A_tab_out(iJPi_A_out);

			  const double J_A_out = CC_J_A_tab_out(iJPi_A_out);

			  const unsigned int BP_in_out = binary_parity_product (BP_A_in , BP_A_out);

			  const int rank_in_out_min = abs (make_int (J_A_in - J_A_out));

			  const int rank_in_out_max = make_int (J_A_in + J_A_out);

			  cout << "In " << J_Pi_string (BP_A_in , J_A_in) << " -> out "  << J_Pi_string (BP_A_out , J_A_out) << " ";

			  if ((BP_in_out == BP_Op) && (rank_Op >= rank_in_out_min) && (rank_Op <= rank_in_out_max))
			    cout << "=> allowed" << endl;
			  else
			    cout << "=> forbidden" << endl;
			}
		    }
		}
	      else
		cout << " => forbidden" << endl;
	    }
	  cout << endl;
	}

      BP_T_bef = BP_T;

      J_T_bef = J_T;

      vector_index_T_bef = vector_index_T;
    }
}




void CC_common_routines::observable_allowed_JPi_channels_calc_print (
								     const enum CC_reaction_type CC_reaction ,		  
								     const class input_data_str &input_data_CC_Berggren)
{	
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in CC_common_routines::observable_allowed_JPi_channels_calc_print (2)");
  
  if (CC_reaction == SCATTERING) allowed_JPi_channels_calc_print (input_data_CC_Berggren);

  if (CC_reaction == RADIATIVE_CAPTURE)
    {
      const enum CC_reaction_calculation_type CC_reaction_calculation = input_data_CC_Berggren.get_CC_reaction_calculation ();
  
      if (CC_reaction_calculation == TOTAL_CROSS_SECTION)
	{		
	  const int L = input_data_CC_Berggren.get_CC_L_for_total_cross_section ();

	  const enum EM_type EM = input_data_CC_Berggren.get_CC_EM_for_total_cross_section ();

	  const unsigned int BP_EM = BP_EM_determine (EM , L);

	  observable_allowed_JPi_channels_calc_print (BP_EM , L , input_data_CC_Berggren);
	}
    }
}



