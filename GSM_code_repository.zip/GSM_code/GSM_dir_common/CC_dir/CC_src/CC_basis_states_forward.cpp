#include "../CC_include/CC_include_def_common.h"



/* -------------------------------------------------------------------------------------------------------------------
   ELEMENTS FOR CLASS CC_fwd_basis_state
   ---------------------------------------------------------------------------------------------------------------------*/

CC_fwd_basis_state::CC_fwd_basis_state () :
  S_matrix_pole (false) ,
  N_channels (0) , 	
  N_bef_R_uniform (0) , 
  N_bef_R_GL (0) , 
  ic_entrance (0) ,
  ib (0) , 
  R (0.0) , 
  matching_point (0.0) ,
  R_max (0.0) , 
  step_bef_R_uniform (0.0) ,
  N_bef_mp_uniform (0) , 
  N_bef_mp_GL (0) ,
  N_bef_mp_GL_SGI_MSGI (0)
{}

  
CC_fwd_basis_state::CC_fwd_basis_state (
					const bool S_matrix_pole_c, 
					const unsigned int N_channels_c, 
					const unsigned int ic_entrance_c ,
					const unsigned int ib_c,
					const class array<class CC_channel_class> &channels_tab_c , 
					const unsigned int N_bef_R_uniform_c, 
					const unsigned int N_bef_R_GL_c, 
					const double R0,  
					const double R_c, 
					const double matching_point_c, 
					const double R_real_max_c)
{
  allocate (S_matrix_pole_c , N_channels_c , ic_entrance_c , ib_c , channels_tab_c , N_bef_R_uniform_c , N_bef_R_GL_c , R0 , R_c , matching_point_c , R_real_max_c);
}

CC_fwd_basis_state::CC_fwd_basis_state (const class CC_fwd_basis_state &X)
{
  allocate_fill (X);
}

void CC_fwd_basis_state::allocate (
				   const bool S_matrix_pole_c , 
				   const unsigned int N_channels_c ,
				   const unsigned int ic_entrance_c , 
				   const unsigned int ib_c , 
				   const class array<class CC_channel_class> &channels_tab_c , 
				   const unsigned int N_bef_R_uniform_c , 
				   const unsigned int N_bef_R_GL_c , 
				   const double R0 ,  
				   const double R_c , 
				   const double matching_point_c , 
				   const double R_real_max_c)
{
  S_matrix_pole = S_matrix_pole_c; 

  N_channels = N_channels_c; 

  N_bef_R_uniform = N_bef_R_uniform_c; 

  N_bef_R_GL = N_bef_R_GL_c; 

  ic_entrance = ic_entrance_c;

  ib = ib_c; 

  R = R_c; 

  matching_point = matching_point_c; 

  R_max = R_real_max_c; 

  step_bef_R_uniform = R/static_cast<double> (N_bef_R_uniform - 1); 

  N_bef_mp_uniform = make_uns_int (floor (matching_point/step_bef_R_uniform)) + 1;
	
  channels_tab.allocate_fill (channels_tab_c);

  r_bef_mp_tab_uniform.allocate (N_bef_mp_uniform);

  for(unsigned int i = 0 ; i < N_bef_mp_uniform ; i++) r_bef_mp_tab_uniform(i) = i*step_bef_R_uniform;

  class array<double> r_bef_R(N_bef_R_GL);
  class array<double> weights_bef_R(N_bef_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R , weights_bef_R);

  unsigned int iGL = 0;

  while ((iGL < N_bef_R_GL) && (r_bef_R(iGL) <= matching_point)) iGL++;

  N_bef_mp_GL = iGL;

  r_bef_mp_tab_GL.allocate (N_bef_mp_GL);

  for (unsigned int i = 0 ; i < N_bef_mp_GL ; i++) r_bef_mp_tab_GL(i) = r_bef_R(i);

  const double R_SGI_MSGI = 2.0*R0;

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R_SGI_MSGI , r_bef_R , weights_bef_R);

  unsigned int iGL_SGI_MSGI = 0;

  while ((iGL_SGI_MSGI < N_bef_R_GL) && (r_bef_R(iGL_SGI_MSGI) <= matching_point)) iGL_SGI_MSGI++;

  N_bef_mp_GL_SGI_MSGI = iGL_SGI_MSGI;

  r_bef_mp_tab_GL_SGI_MSGI.allocate (N_bef_mp_GL_SGI_MSGI);

  for (unsigned int i = 0 ; i < N_bef_mp_GL_SGI_MSGI ; i++) r_bef_mp_tab_GL_SGI_MSGI(i) = r_bef_R(i);

  CC_fwd_wf_tab_uniform.allocate  (N_channels , N_bef_mp_uniform);
  CC_fwd_dwf_tab_uniform.allocate (N_channels , N_bef_mp_uniform);

  CC_fwd_wf_tab_GL.allocate  (N_channels , N_bef_mp_GL);
  CC_fwd_dwf_tab_GL.allocate (N_channels , N_bef_mp_GL);

  CC_fwd_wf_tab_GL_SGI_MSGI.allocate  (N_channels , N_bef_mp_GL_SGI_MSGI);
  CC_fwd_dwf_tab_GL_SGI_MSGI.allocate (N_channels , N_bef_mp_GL_SGI_MSGI);

  CC_fwd_wf_tab_uniform  = INFINITE;
  CC_fwd_dwf_tab_uniform = INFINITE;

  CC_fwd_wf_tab_GL  = INFINITE;
  CC_fwd_dwf_tab_GL = INFINITE;

  CC_fwd_wf_tab_GL_SGI_MSGI  = INFINITE;
  CC_fwd_dwf_tab_GL_SGI_MSGI = INFINITE;

  CC_fwd_wf_mp_tab.allocate  (N_channels);
  CC_fwd_dwf_mp_tab.allocate (N_channels);

  CC_fwd_wf_mp_tab  = INFINITE;
  CC_fwd_dwf_mp_tab = INFINITE;
}








void CC_fwd_basis_state::allocate_fill (const class CC_fwd_basis_state &X)
{
  S_matrix_pole = X.S_matrix_pole; 

  N_channels = X.N_channels; 

  N_bef_R_uniform = X.N_bef_R_uniform; 

  N_bef_R_GL = X.N_bef_R_GL; 

  ib = X.ib; 

  R = X.R; 

  matching_point = X.matching_point; 

  R_max = X.R_max; 

  step_bef_R_uniform = X.step_bef_R_uniform; 

  N_bef_mp_uniform = X.N_bef_mp_uniform;

  N_bef_mp_GL = X.N_bef_mp_GL;

  N_bef_mp_GL_SGI_MSGI = X.N_bef_mp_GL_SGI_MSGI;

  channels_tab.allocate_fill(X.channels_tab);

  r_bef_mp_tab_uniform.allocate_fill (X.r_bef_mp_tab_uniform);

  r_bef_mp_tab_GL.allocate_fill (X.r_bef_mp_tab_GL);

  r_bef_mp_tab_GL_SGI_MSGI.allocate_fill (X.r_bef_mp_tab_GL_SGI_MSGI);

  CC_fwd_wf_tab_uniform.allocate_fill  (X.CC_fwd_wf_tab_uniform);
  CC_fwd_dwf_tab_uniform.allocate_fill (X.CC_fwd_dwf_tab_uniform);

  CC_fwd_wf_tab_GL.allocate_fill  (X.CC_fwd_wf_tab_GL);
  CC_fwd_dwf_tab_GL.allocate_fill (X.CC_fwd_dwf_tab_GL);

  CC_fwd_wf_tab_GL_SGI_MSGI.allocate_fill  (X.CC_fwd_wf_tab_GL_SGI_MSGI);
  CC_fwd_dwf_tab_GL_SGI_MSGI.allocate_fill (X.CC_fwd_dwf_tab_GL_SGI_MSGI);

  CC_fwd_wf_mp_tab.allocate_fill  (X.CC_fwd_wf_mp_tab);
  CC_fwd_dwf_mp_tab.allocate_fill (X.CC_fwd_dwf_mp_tab);
}



void CC_fwd_basis_state::deallocate ()
{
  channels_tab.deallocate ();

  r_bef_mp_tab_uniform.deallocate ();

  r_bef_mp_tab_GL.deallocate ();

  r_bef_mp_tab_GL_SGI_MSGI.deallocate ();

  CC_fwd_wf_tab_uniform.deallocate ();
  CC_fwd_dwf_tab_uniform.deallocate ();
  
  CC_fwd_wf_tab_GL.deallocate ();
  CC_fwd_dwf_tab_GL.deallocate ();

  CC_fwd_wf_tab_GL_SGI_MSGI.deallocate ();
  CC_fwd_dwf_tab_GL_SGI_MSGI.deallocate ();

  CC_fwd_wf_mp_tab.deallocate ();
  CC_fwd_dwf_mp_tab.deallocate ();

  S_matrix_pole = false;

  N_channels = 0; 	

  N_bef_R_uniform = 0; 

  N_bef_R_GL = 0; 

  ib = 0; 

  R = 0.0; 

  matching_point = 0.0;

  R_max = 0.0; 

  step_bef_R_uniform = 0.0;

  N_bef_mp_uniform = 0; 

  N_bef_mp_GL = 0;

  N_bef_mp_GL_SGI_MSGI = 0;
}









void CC_fwd_basis_state::zero ()
{
  CC_fwd_wf_tab_uniform  = 0.0;
  CC_fwd_dwf_tab_uniform = 0.0;

  CC_fwd_wf_tab_GL  = 0.0;
  CC_fwd_dwf_tab_GL = 0.0;

  CC_fwd_wf_tab_GL_SGI_MSGI  = 0.0;
  CC_fwd_dwf_tab_GL_SGI_MSGI = 0.0;

  CC_fwd_wf_mp_tab  = 0.0;
  CC_fwd_dwf_mp_tab = 0.0;
}





void CC_fwd_basis_state::initial_conditions_calc (
						  const bool is_it_entrance_channel_only ,
						  const complex<double> &C0 , 
						  const class potentials_effective_mass &T , 
						  const double r0 , 
						  class vector_class<complex<double> > &U0 , 
						  class vector_class<complex<double> > &dU0) const 
{
  const class CC_channel_class &channel_b = channels_tab(ib);

  const int LCM_projectile_b = channel_b.get_LCM_projectile ();

  const class array<class splines_class<complex<double> > > &Ueq_tab = T.get_CC_trivially_equivalent_potential_tab ();

  U0(ib) = C0*pow (r0 , LCM_projectile_b + 1);

  dU0(ib) = C0*(LCM_projectile_b + 1.0)*pow (r0 , LCM_projectile_b);

  for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
    {
      if ((ic != ib) && ((!is_it_entrance_channel_only || (ic == ic_entrance))))
	{
	  const class splines_class<complex<double> > &Ueq_cb = Ueq_tab(ic , ib);

	  const class CC_channel_class &channel_c = channels_tab(ic);

	  const int LCM_projectile_c = channel_c.get_LCM_projectile ();

	  const double kinetic_factor_projectile_c = channel_c.get_kinetic_factor_projectile ();

	  const complex<double> a_cb = kinetic_factor_projectile_c*Ueq_cb (0.0);

	  if (LCM_projectile_c != LCM_projectile_b + 2)
	    {
	      const complex<double> factor = a_cb / ((LCM_projectile_b + 2.)*(LCM_projectile_b + 3.) - LCM_projectile_c*(LCM_projectile_c + 1.)) , C0_factor = C0*factor;

	      U0(ic) = C0_factor*pow (r0 , LCM_projectile_b + 3);

	      dU0(ic) = C0_factor*(LCM_projectile_b + 3.)*pow (r0 , LCM_projectile_b + 2); 
	    }
	  else
	    {
	      const double factor1 = 1.0/(2.0*LCM_projectile_b + 5.0);

	      const double r0_log_r0 = z_log_z (r0);

	      const double r0_pow_LCM_projectile_b_p1 = pow (r0 , LCM_projectile_b + 1);

	      const double r0_pow_LCM_projectile_b_p2 = r0*r0_pow_LCM_projectile_b_p1;

	      const complex<double> factor2 = a_cb*factor1;

	      const complex<double> C0_factor2 = C0*factor2;

	      U0(ic) = C0_factor2*r0_pow_LCM_projectile_b_p2*r0_log_r0;

	      dU0(ic) = C0_factor2*((LCM_projectile_b + 3.0)*r0_log_r0*r0_pow_LCM_projectile_b_p1  +  r0_pow_LCM_projectile_b_p2);
	    }
	}
    }
}






void CC_fwd_basis_state::forward_integration_before_R (
						       const bool is_it_entrance_channel_only ,
						       const complex<double> &C0 , 
						       const class potentials_effective_mass &T , 
						       class CC_system_integration &SI)
{
  zero ();
  
  const class CC_channel_class &channel_b = channels_tab(ib);

  const int LCM_projectile_b = channel_b.get_LCM_projectile ();
  
  const double LCM_projectile_b_LCM_projectile_b_p1 = LCM_projectile_b*(LCM_projectile_b + 1.);

  const double r0 = 0.005*sqrt(LCM_projectile_b_LCM_projectile_b_p1);

  const double r_bef_mp = (N_bef_mp_uniform - 1)*step_bef_R_uniform;

  class vector_class<complex<double> >  U0(N_channels);
  class vector_class<complex<double> > dU0(N_channels);

  initial_conditions_calc (is_it_entrance_channel_only , C0 , T , r0 , U0 , dU0);

  for(unsigned int ic = 0; ic < N_channels; ic++)
    {
      if (!is_it_entrance_channel_only || (ic == ic_entrance))
	{
	  CC_fwd_wf_tab_uniform(ic , 0) = 0.0;
	  CC_fwd_dwf_tab_uniform(ic , 0) = ((LCM_projectile_b == 0) && (ic == ib)) ? (C0): (0.0);
	}
    }
  
  class vector_class<complex<double> > U_previous = U0 , dU_previous = dU0;
  class vector_class<complex<double> > U         = U0  , dU          = dU0;
  class vector_class<complex<double> > U_tab_GL  = U0  , dU_tab_GL   = dU0;

  unsigned int iGL = 0;
  
  unsigned int iGL_SGI_MSGI = 0;

  while (r_bef_mp_tab_GL(iGL) <= r0)
    {
      const double r_tab_GL = r_bef_mp_tab_GL(iGL);

      initial_conditions_calc (is_it_entrance_channel_only , C0 , T , r_tab_GL , U_tab_GL , dU_tab_GL);

      for (unsigned int ic = 0; ic < N_channels; ic++) 
	{
	  CC_fwd_wf_tab_GL (ic , iGL) =  U_tab_GL(ic);
	  CC_fwd_dwf_tab_GL(ic , iGL) = dU_tab_GL(ic);
	}

      iGL++;
    }

  while (r_bef_mp_tab_GL_SGI_MSGI(iGL_SGI_MSGI) <= r0)
    {
      const double r_tab_GL_SGI_MSGI = r_bef_mp_tab_GL_SGI_MSGI(iGL_SGI_MSGI);
      
      initial_conditions_calc (is_it_entrance_channel_only , C0 , T , r_tab_GL_SGI_MSGI , U_tab_GL , dU_tab_GL);

      for (unsigned int ic = 0; ic < N_channels; ic++) 
	{
	  CC_fwd_wf_tab_GL_SGI_MSGI(ic , iGL_SGI_MSGI) = U_tab_GL(ic);
	  
	  CC_fwd_dwf_tab_GL(ic , iGL) = dU_tab_GL(ic);
	}

      iGL_SGI_MSGI++;
    }

  for(unsigned int i = 1 ; i < N_bef_mp_uniform ; i++)
    {
      const double r_previous = r_bef_mp_tab_uniform(i - 1);

      const double r = r_bef_mp_tab_uniform(i);

      if (r <= r0)
	{
	  initial_conditions_calc (is_it_entrance_channel_only , C0 , T , r , U , dU);
	  
	  for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
	    {
	      CC_fwd_wf_tab_uniform (ic , i) =  U(ic);
	      CC_fwd_dwf_tab_uniform(ic , i) = dU(ic);
	    }
	}
      else
	{
	  (r_previous < r0) ? (SI(r0 , U0 , dU0 , r , U , dU)) : (SI(r_previous , U_previous , dU_previous , r , U , dU));
	  
	  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	    {
	      CC_fwd_wf_tab_uniform (ic , i) =  U(ic);
	      CC_fwd_dwf_tab_uniform(ic , i) = dU(ic);
	    }
	  
	  while((iGL < N_bef_mp_GL) && (r_bef_mp_tab_GL(iGL) >= r_previous) && (r_bef_mp_tab_GL(iGL) <= r))
	    {
	      const double r_tab_GL = r_bef_mp_tab_GL(iGL);
	      
	      (r_previous < r0) ? (SI(r0 , U0 , dU0 , r_tab_GL , U_tab_GL , dU_tab_GL)) : (SI(r_previous , U_previous , dU_previous , r_tab_GL , U_tab_GL , dU_tab_GL));
	      
	      for(unsigned int ic = 0; ic < N_channels; ic++) 
		{
		  CC_fwd_wf_tab_GL (ic , iGL) =  U_tab_GL(ic);
		  CC_fwd_dwf_tab_GL(ic , iGL) = dU_tab_GL(ic);
		}

	      iGL++;
	    } 

	  while((iGL_SGI_MSGI < N_bef_mp_GL_SGI_MSGI) && (r_bef_mp_tab_GL_SGI_MSGI(iGL_SGI_MSGI) >= r_previous) && (r_bef_mp_tab_GL_SGI_MSGI(iGL_SGI_MSGI) <= r))
	    {
	      const double r_tab_GL_SGI_MSGI = r_bef_mp_tab_GL_SGI_MSGI(iGL_SGI_MSGI);
	      
	      (r_previous < r0) ? (SI(r0 , U0 , dU0 , r_tab_GL_SGI_MSGI , U_tab_GL , dU_tab_GL)) : (SI(r_previous , U_previous , dU_previous , r_tab_GL_SGI_MSGI , U_tab_GL , dU_tab_GL));
	
	      for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
		{
		  CC_fwd_wf_tab_GL_SGI_MSGI (ic , iGL_SGI_MSGI) =  U_tab_GL(ic);
		  CC_fwd_dwf_tab_GL_SGI_MSGI(ic , iGL_SGI_MSGI) = dU_tab_GL(ic);
		}

	      iGL_SGI_MSGI++;
	    } 
	}

      U_previous =  U;
      dU_previous = dU;
    }

  SI(r_bef_mp , U_previous , dU_previous , matching_point , U , dU);

  for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
    {
      if (!is_it_entrance_channel_only || (ic == ic_entrance))
	{
	  CC_fwd_wf_mp_tab (ic) =  U(ic);
	  CC_fwd_dwf_mp_tab(ic) = dU(ic);
	}
    }
  
  while (iGL < N_bef_mp_GL)
    {
      const double r_tab_GL = r_bef_mp_tab_GL(iGL);
      
      SI(r_bef_mp , U_previous , dU_previous , r_tab_GL , U_tab_GL , dU_tab_GL);

      for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
	{
	  if (!is_it_entrance_channel_only || (ic == ic_entrance))
	    {
	      CC_fwd_wf_tab_GL (ic , iGL) =  U_tab_GL(ic);
	      CC_fwd_dwf_tab_GL(ic , iGL) = dU_tab_GL(ic);
	    }
	}
      
      iGL++;
    } 

  while (iGL_SGI_MSGI < N_bef_mp_GL_SGI_MSGI)
    {
      const double r_tab_GL_SGI_MSGI = r_bef_mp_tab_GL_SGI_MSGI(iGL_SGI_MSGI);
      
      SI(r_bef_mp , U_previous , dU_previous , r_tab_GL_SGI_MSGI , U_tab_GL , dU_tab_GL);

      for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
	{
	  if (!is_it_entrance_channel_only || (ic == ic_entrance))
	    {
	      CC_fwd_wf_tab_GL_SGI_MSGI (ic , iGL_SGI_MSGI) =  U_tab_GL(ic);
	      CC_fwd_dwf_tab_GL_SGI_MSGI(ic , iGL_SGI_MSGI) = dU_tab_GL(ic);
	    }
	}

      iGL_SGI_MSGI++;
    }
}









void CC_fwd_basis_state::change_channels (const complex<double> &E)
{
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    channels_tab(ic).E_dependent_values_change (E);
}





class CC_fwd_basis_state & CC_fwd_basis_state::operator= (const class CC_fwd_basis_state &X)
{
  S_matrix_pole = X.S_matrix_pole; 

  N_channels = X.N_channels; 

  N_bef_R_uniform = X.N_bef_R_uniform; 

  N_bef_R_GL = X.N_bef_R_GL; 

  ib = X.ib; 

  R = X.R; 

  matching_point = X.matching_point; 

  R_max = X.R_max; 

  step_bef_R_uniform = X.step_bef_R_uniform; 

  N_bef_mp_uniform = X.N_bef_mp_uniform;

  N_bef_mp_GL = X.N_bef_mp_GL;

  N_bef_mp_GL_SGI_MSGI = X.N_bef_mp_GL_SGI_MSGI;
  
  channels_tab = X.channels_tab;

  r_bef_mp_tab_uniform = X.r_bef_mp_tab_uniform;

  N_bef_mp_GL = X.N_bef_mp_GL;

  r_bef_mp_tab_GL = X.r_bef_mp_tab_GL;

  CC_fwd_wf_tab_uniform  = X.CC_fwd_wf_tab_uniform;
  CC_fwd_dwf_tab_uniform = X.CC_fwd_dwf_tab_uniform;

  CC_fwd_wf_tab_GL  = X.CC_fwd_wf_tab_GL;
  CC_fwd_dwf_tab_GL = X.CC_fwd_dwf_tab_GL;

  CC_fwd_wf_tab_GL_SGI_MSGI  = X.CC_fwd_wf_tab_GL_SGI_MSGI;
  CC_fwd_dwf_tab_GL_SGI_MSGI = X.CC_fwd_dwf_tab_GL_SGI_MSGI;

  CC_fwd_wf_mp_tab  = X.CC_fwd_wf_mp_tab;
  CC_fwd_dwf_mp_tab = X.CC_fwd_dwf_mp_tab;

  return *this;
}




bool CC_fwd_basis_state::is_it_filled () const
{
  return (N_bef_R_uniform > 0);
}




double used_memory_calc (const class CC_fwd_basis_state &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.channels_tab) + used_memory_calc (T.r_bef_mp_tab_uniform) + used_memory_calc (T.r_bef_mp_tab_GL) + used_memory_calc (T.r_bef_mp_tab_GL_SGI_MSGI) + used_memory_calc (T.CC_fwd_wf_tab_uniform) + used_memory_calc (T.CC_fwd_dwf_tab_uniform) + used_memory_calc (T.CC_fwd_wf_tab_GL) + used_memory_calc (T.CC_fwd_dwf_tab_GL) + used_memory_calc (T.CC_fwd_wf_tab_GL_SGI_MSGI) + used_memory_calc (T.CC_fwd_dwf_tab_GL_SGI_MSGI) + used_memory_calc (T.CC_fwd_wf_mp_tab) + used_memory_calc (T.CC_fwd_dwf_mp_tab) - (sizeof (T.channels_tab) + sizeof (T.r_bef_mp_tab_uniform) + sizeof (T.r_bef_mp_tab_GL) + sizeof (T.r_bef_mp_tab_GL_SGI_MSGI) + sizeof (T.CC_fwd_wf_tab_uniform) + sizeof (T.CC_fwd_dwf_tab_uniform) + sizeof (T.CC_fwd_wf_tab_GL) + sizeof (T.CC_fwd_dwf_tab_GL) + sizeof (T.CC_fwd_wf_tab_GL_SGI_MSGI) + sizeof (T.CC_fwd_dwf_tab_GL_SGI_MSGI) + sizeof (T.CC_fwd_wf_mp_tab) + sizeof (T.CC_fwd_dwf_mp_tab))/1000000.0;
  
  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;
}


