#include "../CC_include/CC_include_def_common.h"



void CC_HO_wave_functions::wfs_radial_calc (
					    const class array<class CC_channel_class> &channels_tab,
					    const class array<double> &r_tab,
					    const class array<double> &HO_CC_wfs_tab)
{
  const int nmax_HO_potentials_plus_one = HO_CC_wfs_tab.dimension (1);

  const unsigned int N = HO_CC_wfs_tab.dimension (2);

  const unsigned int N_channels = channels_tab.dimension (0);

  for (unsigned ic = 0 ; ic < N_channels ; ic++)
    {
      class array<double> HO_channel_wfs_tab(nmax_HO_potentials_plus_one , N);

      const class CC_channel_class &channel_c = channels_tab(ic);

      const int LCM_projectile = channel_c.get_LCM_projectile ();

      const double b_HO_potentials_projectile = channel_c.get_b_HO_potentials_projectile ();

      HO_wave_functions::HO_3D::u_r_tables_calc (b_HO_potentials_projectile , LCM_projectile , r_tab , HO_channel_wfs_tab);

      for (int nHO = 0 ; nHO < nmax_HO_potentials_plus_one ; nHO++)
	for (unsigned int i = 0 ; i < N ; i++)
	  HO_CC_wfs_tab(ic , nHO , i) = HO_channel_wfs_tab(nHO , i);
    }
}





void CC_HO_wave_functions::wfs_dwfs_radial_calc (
						 const class array<class CC_channel_class> &channels_tab,
						 const class array<double> &r_tab,
						 const class array<double> &HO_CC_wfs_tab , 
						 const class array<double> &HO_CC_dwfs_tab)
{
  const int nmax_HO_potentials_plus_one = HO_CC_wfs_tab.dimension (1);

  const unsigned int N = HO_CC_wfs_tab.dimension (2);

  const unsigned int N_channels = channels_tab.dimension (0);

  class array<double> HO_channel_wfs_tab (nmax_HO_potentials_plus_one , N);
  class array<double> HO_channel_dwfs_tab(nmax_HO_potentials_plus_one , N);

  for (unsigned ic = 0 ; ic < N_channels ; ic++)
    {    
      const class CC_channel_class &channel_c = channels_tab(ic);

      const int LCM_projectile = channel_c.get_LCM_projectile ();

      const double b_HO_potentials_projectile = channel_c.get_b_HO_potentials_projectile ();

      HO_wave_functions::HO_3D::u_du_r_tables_calc (b_HO_potentials_projectile , LCM_projectile , r_tab , HO_channel_wfs_tab , HO_channel_dwfs_tab);

      for (int nHO = 0 ; nHO < nmax_HO_potentials_plus_one ; nHO++)
	for (unsigned int i = 0 ; i < N ; i++)
	  {
	    HO_CC_wfs_tab (ic , nHO , i) = HO_channel_wfs_tab (nHO , i);
	    HO_CC_dwfs_tab(ic , nHO , i) = HO_channel_dwfs_tab(nHO , i);
	  }
    }
}








void CC_HO_wave_functions::wfs_dwfs_d2wfs_radial_calc (
						       const class array<class CC_channel_class> &channels_tab,
						       const class array<double> &r_tab,
						       const class array<double> &HO_CC_wfs_tab , 
						       const class array<double> &HO_CC_dwfs_tab , 
						       const class array<double> &HO_CC_d2wfs_tab)
{
  const int nmax_HO_potentials_plus_one = HO_CC_wfs_tab.dimension (1);

  const unsigned int N = HO_CC_wfs_tab.dimension (2);

  const unsigned int N_channels = channels_tab.dimension (0);

  class array<double> HO_channel_wfs_tab  (nmax_HO_potentials_plus_one , N);
  class array<double> HO_channel_dwfs_tab (nmax_HO_potentials_plus_one , N);
  class array<double> HO_channel_d2wfs_tab(nmax_HO_potentials_plus_one , N);

  for (unsigned ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const int LCM_projectile = channel_c.get_LCM_projectile ();

      const double b_HO_potentials_projectile = channel_c.get_b_HO_potentials_projectile ();

      HO_wave_functions::HO_3D::u_du_d2u_r_tables_calc (b_HO_potentials_projectile , LCM_projectile , r_tab , HO_channel_wfs_tab , HO_channel_dwfs_tab , HO_channel_d2wfs_tab);

      for (int nHO = 0 ; nHO < nmax_HO_potentials_plus_one ; nHO++)
	for (unsigned int i = 0 ; i < N ; i++)
	  {
	    HO_CC_wfs_tab  (ic , nHO , i) = HO_channel_wfs_tab  (nHO , i);
	    HO_CC_dwfs_tab (ic , nHO , i) = HO_channel_dwfs_tab (nHO , i);
	    HO_CC_d2wfs_tab(ic , nHO , i) = HO_channel_d2wfs_tab(nHO , i);
	  }
    }
}




void CC_HO_wave_functions::wfs_momentum_calc (
					      const class array<class CC_channel_class> &channels_tab,
					      const class array<double> &k_tab,
					      const class array<double> &HO_CC_wfs_tab)
{
  const int nmax_HO_potentials_plus_one = HO_CC_wfs_tab.dimension (1);

  const unsigned int N = HO_CC_wfs_tab.dimension (2);

  const unsigned int N_channels = channels_tab.dimension (0);

  for (unsigned ic = 0 ; ic < N_channels ; ic++)
    {
      class array<double> HO_channel_wfs_tab(nmax_HO_potentials_plus_one , N);

      const class CC_channel_class &channel_c = channels_tab(ic);

      const int LCM_projectile = channel_c.get_LCM_projectile ();

      const double bk_HO_potentials_projectile = 1.0/channel_c.get_b_HO_potentials_projectile ();

      HO_wave_functions::HO_3D::u_k_tables_calc (bk_HO_potentials_projectile , LCM_projectile , k_tab , HO_channel_wfs_tab);

      for (int nHO = 0 ; nHO < nmax_HO_potentials_plus_one ; nHO++)
	for (unsigned int i = 0 ; i < N ; i++)
	  HO_CC_wfs_tab(ic , nHO , i) = HO_channel_wfs_tab(nHO , i);
    }
}





void CC_HO_wave_functions::wfs_dwfs_momentum_calc (
						   const class array<class CC_channel_class> &channels_tab,
						   const class array<double> &k_tab,
						   const class array<double> &HO_CC_wfs_tab , 
						   const class array<double> &HO_CC_dwfs_tab)
{
  const int nmax_HO_potentials_plus_one = HO_CC_wfs_tab.dimension (1);

  const unsigned int N = HO_CC_wfs_tab.dimension (2);

  const unsigned int N_channels = channels_tab.dimension (0);

  class array<double> HO_channel_wfs_tab (nmax_HO_potentials_plus_one , N);
  class array<double> HO_channel_dwfs_tab(nmax_HO_potentials_plus_one , N);

  for (unsigned ic = 0 ; ic < N_channels ; ic++)
    {    
      const class CC_channel_class &channel_c = channels_tab(ic);

      const int LCM_projectile = channel_c.get_LCM_projectile ();

      const double bk_HO_potentials_projectile = 1.0/channel_c.get_b_HO_potentials_projectile ();

      HO_wave_functions::HO_3D::u_du_k_tables_calc (bk_HO_potentials_projectile , LCM_projectile , k_tab , HO_channel_wfs_tab , HO_channel_dwfs_tab);

      for (int nHO = 0 ; nHO < nmax_HO_potentials_plus_one ; nHO++)
	for (unsigned int i = 0 ; i < N ; i++)
	  {
	    HO_CC_wfs_tab (ic , nHO , i) = HO_channel_wfs_tab (nHO , i);
	    HO_CC_dwfs_tab(ic , nHO , i) = HO_channel_dwfs_tab(nHO , i);
	  }
    }
}








void CC_HO_wave_functions::wfs_dwfs_d2wfs_momentum_calc (
							 const class array<class CC_channel_class> &channels_tab,
							 const class array<double> &k_tab,
							 const class array<double> &HO_CC_wfs_tab , 
							 const class array<double> &HO_CC_dwfs_tab , 
							 const class array<double> &HO_CC_d2wfs_tab)
{
  const int nmax_HO_potentials_plus_one = HO_CC_wfs_tab.dimension (1);

  const unsigned int N = HO_CC_wfs_tab.dimension (2);

  const unsigned int N_channels = channels_tab.dimension (0);

  class array<double> HO_channel_wfs_tab  (nmax_HO_potentials_plus_one , N);
  class array<double> HO_channel_dwfs_tab (nmax_HO_potentials_plus_one , N);
  class array<double> HO_channel_d2wfs_tab(nmax_HO_potentials_plus_one , N);

  for (unsigned ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_channel_class &channel_c = channels_tab(ic);

      const int LCM_projectile = channel_c.get_LCM_projectile ();

      const double bk_HO_potentials_projectile = 1.0/channel_c.get_b_HO_potentials_projectile ();

      HO_wave_functions::HO_3D::u_du_d2u_k_tables_calc (bk_HO_potentials_projectile , LCM_projectile , k_tab , HO_channel_wfs_tab , HO_channel_dwfs_tab , HO_channel_d2wfs_tab);

      for (int nHO = 0 ; nHO < nmax_HO_potentials_plus_one ; nHO++)
	for (unsigned int i = 0 ; i < N ; i++)
	  {
	    HO_CC_wfs_tab  (ic , nHO , i) = HO_channel_wfs_tab  (nHO , i);
	    HO_CC_dwfs_tab (ic , nHO , i) = HO_channel_dwfs_tab (nHO , i);
	    HO_CC_d2wfs_tab(ic , nHO , i) = HO_channel_d2wfs_tab(nHO , i);
	  }
    }
}


