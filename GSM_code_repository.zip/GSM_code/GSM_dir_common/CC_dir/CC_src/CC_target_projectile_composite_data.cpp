#include "../CC_include/CC_include_def_common.h"

using namespace inputs_misc;
using namespace CC_common_routines;

// Class containing data associated to all the target-projectile composite states considered in the GSM-CC calculation
// -------------------------------------------------------------------------------------------------------------------
// Members are described in CC_target_projectile_composite_data.h .

CC_target_projectile_composite_data::CC_target_projectile_composite_data () :
  Z (0) ,
  N (0) ,
  A (0) ,
  initial_pivot_from_file (false) , 
  truncation_hw (false) , 
  truncation_ph (false) , 
  n_holes_max (0) , 
  n_scat_max (0) , 
  E_relative_max_hw (0) , 
  CC_reaction (NO_REACTION) , 
  CC_reaction_calculation (NO_REACTION_CALCULATION) ,
  entrance_projectile (NO_PARTICLE) ,
  mass_entrance_projectile (0.0) , 
  CM_to_work_frame_kinetic_factor (0.0) ,
  work_frame_to_lab_kinetic_factor (0.0) ,
  CM_to_lab_kinetic_factor (0.0) ,
  kinetic_factor_entrance_projectile_work_frame (0.0) , 
  kinetic_factor_entrance_projectile_CM (0.0) , 
  Z_target (0) ,
  N_target (0) , 
  A_target (0) , 
  mass_target (0.0) , 
  are_GSM_a_dagger_vectors_calculated (false) , 
  N_JPi_A (0) ,
  N_JPi_A_in (0) , 
  N_JPi_A_out (0) , 
  N_target_projectile_states (0) , 
  entrance_target_index (0) , 
  N_entrance_channels_max (0) , 
  J_intrinsic_projectile_max (0.0) ,
  N_energies (0) , 
  N_CM_angles (0) , 
  cluster_projectile_number (0) ,   
  is_it_one_baryon_COSM_case (false) , 
  EM_for_radiative_capture_cross_section (NO_EM) , 
  L_for_radiative_capture_cross_section (0) , 
  N_theta_gamma (0) , 
  N_phi_gamma (0) , 
  radiative_capture_is_it_longwavelength_approximation (false) , 
  radiative_capture_is_it_HO_expansion (false) , 
  N_channels (0) , 
  N_channels_in (0) , 
  N_channels_out (0) ,
  N_restarts (0) ,
  Davidson_max_dimension (0) , 
  Davidson_eigenvector_precision (0) ,
  relative_SVD_precision (0) ,
  R_cut_function (0.0) ,
  d_cut_function (0.0) ,
  Ueq_regularizor (0.0)
{}
    
CC_target_projectile_composite_data::CC_target_projectile_composite_data (
									  const class input_data_str &input_data , 
									  const class baryons_data &prot_Y_data , 
									  const class baryons_data &neut_Y_data) :
  Z (0) ,
  N (0) ,
  A (0) ,
  initial_pivot_from_file (false) , 
  truncation_hw (false) , 
  truncation_ph (false) , 
  n_holes_max (0) , 
  n_scat_max (0) , 
  E_relative_max_hw (0) , 
  CC_reaction (NO_REACTION) ,
  CC_reaction_calculation (NO_REACTION_CALCULATION) ,
  entrance_projectile (NO_PARTICLE) ,
  mass_entrance_projectile (0.0) , 
  CM_to_work_frame_kinetic_factor (0.0) ,
  work_frame_to_lab_kinetic_factor (0.0) ,
  CM_to_lab_kinetic_factor (0.0) ,
  kinetic_factor_entrance_projectile_work_frame (0.0) , 
  kinetic_factor_entrance_projectile_CM (0.0) , 
  Z_target (0) ,
  N_target (0) , 
  A_target (0) , 
  mass_target (0.0) , 
  are_GSM_a_dagger_vectors_calculated (false) , 
  N_JPi_A (0) ,
  N_JPi_A_in (0) , 
  N_JPi_A_out (0) , 
  N_target_projectile_states (0) , 
  entrance_target_index (0) , 
  N_entrance_channels_max (0) , 
  J_intrinsic_projectile_max (0.0) , 
  N_energies (0) , 
  N_CM_angles (0) , 
  cluster_projectile_number (0) , 
  is_it_one_baryon_COSM_case (false) , 
  EM_for_radiative_capture_cross_section (NO_EM) , 
  L_for_radiative_capture_cross_section (0) , 
  N_theta_gamma (0) , 
  N_phi_gamma (0) , 
  radiative_capture_is_it_longwavelength_approximation (false) , 
  radiative_capture_is_it_HO_expansion (false) , 
  N_channels (0) , 
  N_channels_in (0) , 
  N_channels_out (0) ,
  N_restarts (0) ,
  Davidson_max_dimension (0) , 
  Davidson_eigenvector_precision (0) ,
  relative_SVD_precision (0) ,
  R_cut_function (0.0) ,
  d_cut_function (0.0) ,
  Ueq_regularizor (0.0)
{
  allocate (input_data , prot_Y_data , neut_Y_data);
}

CC_target_projectile_composite_data::CC_target_projectile_composite_data (const class CC_target_projectile_composite_data &X) :
  Z (0) ,
  N (0) ,
  A (0) ,
  initial_pivot_from_file (false) , 
  truncation_hw (false) , 
  truncation_ph (false) , 
  n_holes_max (0) , 
  n_scat_max (0) , 
  E_relative_max_hw (0) , 
  CC_reaction (NO_REACTION) , 
  CC_reaction_calculation (NO_REACTION_CALCULATION) ,
  entrance_projectile (NO_PARTICLE) ,
  mass_entrance_projectile (0.0) , 
  CM_to_work_frame_kinetic_factor (0.0) ,
  work_frame_to_lab_kinetic_factor (0.0) ,
  CM_to_lab_kinetic_factor (0.0) ,
  kinetic_factor_entrance_projectile_work_frame (0.0) , 
  kinetic_factor_entrance_projectile_CM (0.0) , 
  Z_target (0) ,
  N_target (0) , 
  A_target (0) , 
  mass_target (0.0) , 
  are_GSM_a_dagger_vectors_calculated (false) , 
  N_JPi_A (0) ,
  N_JPi_A_in (0) , 
  N_JPi_A_out (0) , 
  N_target_projectile_states (0) , 
  entrance_target_index (0) , 
  N_entrance_channels_max (0) , 
  J_intrinsic_projectile_max (0.0) ,
  N_energies (0) , 
  N_CM_angles (0) , 
  cluster_projectile_number (0) ,   
  is_it_one_baryon_COSM_case (false) , 
  EM_for_radiative_capture_cross_section (NO_EM) , 
  L_for_radiative_capture_cross_section (0) , 
  N_theta_gamma (0) , 
  N_phi_gamma (0) , 
  radiative_capture_is_it_longwavelength_approximation (false) , 
  radiative_capture_is_it_HO_expansion (false) , 
  N_channels (0) , 
  N_channels_in (0) , 
  N_channels_out (0) ,
  N_restarts (0) ,
  Davidson_max_dimension (0) , 
  Davidson_eigenvector_precision (0) ,
  relative_SVD_precision (0) ,
  R_cut_function (0.0) ,
  d_cut_function (0.0) ,
  Ueq_regularizor (0.0)
{
  allocate_fill (X);
}

CC_target_projectile_composite_data::~CC_target_projectile_composite_data () {}

void CC_target_projectile_composite_data::allocate (
						    const class input_data_str &input_data , 
						    const class baryons_data &prot_Y_data , 
						    const class baryons_data &neut_Y_data)
{
  if (is_it_filled ()) error_message_print_abort ("CC_target_projectile_composite_data cannot be allocated twice in CC_target_projectile_composite_data::allocate");

  const enum interaction_type inter = input_data.get_inter ();
      
  const unsigned int prot_index = charge_baryon_index_determine (PROTON);
  const unsigned int neut_index = charge_baryon_index_determine (NEUTRON);
      
  const class array<double> &effective_masses_for_calc_p = input_data.get_effective_masses_for_calc_p ();
  const class array<double> &effective_masses_for_calc_n = input_data.get_effective_masses_for_calc_n ();
      
  const double prot_mass_for_calc = effective_masses_for_calc_p(prot_index);  
  const double neut_mass_for_calc = effective_masses_for_calc_n(neut_index);
  
  const double frozen_core_mass = input_data.get_frozen_core_mass ();
  
  const class array<unsigned int> &CC_N_partial_waves_tab = input_data.get_CC_N_partial_waves_tab ();

  const enum space_type space = input_data.get_space (); 

  
  Z = input_data.get_Z (); 
  N = input_data.get_N (); 
  A = input_data.get_A (); 

  initial_pivot_from_file = input_data.get_initial_pivot_from_file (); 
    
  truncation_hw = input_data.get_truncation_hw (); 
  truncation_ph = input_data.get_truncation_ph (); 

  n_holes_max = input_data.get_n_holes_max ();

  n_scat_max = n_scat_max_modification (space , truncation_ph , prot_Y_data , neut_Y_data , input_data.get_n_scat_max ());
  
  E_relative_max_hw = input_data.get_E_relative_max_hw (); 

  CC_reaction = input_data.get_CC_reaction ();
  
  CC_reaction_calculation = input_data.get_CC_reaction_calculation (); 

  entrance_projectile = input_data.entrance_projectile_determine (); 

  const int S_entrance_projectile = particle_strangeness_determine (entrance_projectile);
  
  const int Y_entrance_charge = (S_entrance_projectile > 0) ? (particle_charge_determine (entrance_projectile)) : (NADA);

  const bool is_Y_entrance_charged = (S_entrance_projectile > 0) ? (Y_entrance_charge != 0) : (false);
  
  const unsigned int Y_entrance_index = (S_entrance_projectile > 0) ? (charge_baryon_index_determine (entrance_projectile)) : (0);

  const double Y_entrance_mass_for_calc = (is_Y_entrance_charged) ? (effective_masses_for_calc_p(Y_entrance_index)) : (effective_masses_for_calc_n(Y_entrance_index));
  
  mass_entrance_projectile = mass_cluster_determine (entrance_projectile , prot_mass_for_calc , neut_mass_for_calc , Y_entrance_mass_for_calc); 

  Z_target = Z_target_determine (Z     , entrance_projectile);
  N_target = N_target_determine (N     , entrance_projectile);
  A_target = A_target_determine (Z , N , entrance_projectile);

  mass_target = mass_target_determine (Z , N , entrance_projectile , prot_mass_for_calc , neut_mass_for_calc);
  
  if (is_it_realistic_interaction (inter))
    {
      CM_to_work_frame_kinetic_factor = 1.0;
    
      work_frame_to_lab_kinetic_factor = CM_to_lab_kinetic_factor = CM_to_lab_kinetic_factor_calc (prot_mass_for_calc , neut_mass_for_calc , Y_entrance_mass_for_calc , Z , N , entrance_projectile);
      
      kinetic_factor_entrance_projectile_work_frame = kinetic_factor_entrance_projectile_CM = kinetic_factor_calc (false , mass_target , mass_entrance_projectile);
    }
  else
    {
      CM_to_work_frame_kinetic_factor = CM_to_COSM_kinetic_factor_calc (prot_mass_for_calc , neut_mass_for_calc , Y_entrance_mass_for_calc , frozen_core_mass , Z , N , entrance_projectile); 

      work_frame_to_lab_kinetic_factor = COSM_to_lab_kinetic_factor_calc (prot_mass_for_calc , neut_mass_for_calc , Y_entrance_mass_for_calc , frozen_core_mass , entrance_projectile);
  
      CM_to_lab_kinetic_factor = CM_to_lab_kinetic_factor_calc (prot_mass_for_calc , neut_mass_for_calc , Y_entrance_mass_for_calc , Z , N , entrance_projectile);
      
      kinetic_factor_entrance_projectile_work_frame = kinetic_factor_calc (false , frozen_core_mass , mass_entrance_projectile);
      
      kinetic_factor_entrance_projectile_CM = kinetic_factor_calc (false , mass_target , mass_entrance_projectile);
    }
    
  are_GSM_a_dagger_vectors_calculated = input_data.get_CC_are_GSM_a_dagger_vectors_calculated (); 

  N_JPi_A     = input_data.get_CC_N_JPi_A_composite ();
  N_JPi_A_in  = input_data.get_CC_N_JPi_A_in_composite (); 
  N_JPi_A_out = input_data.get_CC_N_JPi_A_out_composite ();  

  N_target_projectile_states = input_data.get_CC_N_target_projectile_states (); 

  entrance_target_index = entrance_target_index_determine (input_data); 

  N_entrance_channels_max = (CC_reaction_calculation != POLES) ? (CC_N_partial_waves_tab(entrance_target_index)) : (NADA); 

  J_intrinsic_projectile_max = J_intrinsic_projectile_max_determine (input_data); 

  N_energies = input_data.get_CC_N_energies (); 

  N_CM_angles = input_data.get_CC_N_CM_angles (); 

  cluster_projectile_number = input_data.get_CC_cluster_projectile_number (); 

  is_it_one_baryon_COSM_case = input_data.is_it_one_baryon_COSM_case_determine (); 

  EM_for_radiative_capture_cross_section = input_data.get_CC_EM_for_radiative_capture_cross_section (); 

  L_for_radiative_capture_cross_section = input_data.get_CC_L_for_radiative_capture_cross_section (); 

  N_theta_gamma = input_data.get_CC_N_theta_gamma (); 

  N_phi_gamma = input_data.get_CC_N_phi_gamma (); 

  radiative_capture_is_it_longwavelength_approximation = input_data.get_CC_is_it_longwavelength_approximation (); 

  radiative_capture_is_it_HO_expansion = input_data.get_CC_is_it_HO_expansion ();
  
  N_channels     = 0; 
  N_channels_in  = 0; 
  N_channels_out = 0;

  Davidson_max_dimension = input_data.get_CC_Davidson_max_dimension ();

  Davidson_eigenvector_precision = input_data.get_CC_Davidson_eigenvector_precision ();

  relative_SVD_precision = input_data.get_CC_relative_SVD_precision (); 

  R_cut_function = input_data.get_R_cut_function (); 
  d_cut_function = input_data.get_d_cut_function (); 

  Ueq_regularizor = input_data.get_Ueq_regularizor ();
   
  effective_charges_p.allocate_fill (input_data.get_effective_charges_p ()); 
  effective_charges_n.allocate_fill (input_data.get_effective_charges_n ());
  
  projectile_tab.allocate_fill (input_data.get_CC_projectile_tab ());

  BP_target_tab.allocate_fill (input_data.get_CC_BP_target_tab ());

  J_target_tab.allocate_fill (input_data.get_CC_J_target_tab ());

  vector_index_target_tab.allocate_fill (input_data.get_CC_vector_index_target_tab ());

  is_it_pole_target_tab.allocate_fill (input_data.get_CC_is_it_pole_target_tab ());

  real_E_target_tab.allocate_fill (input_data.get_CC_real_E_target_tab ());

  Gamma_target_tab.allocate_fill (input_data.get_CC_Gamma_target_tab ());

  real_E_intrinsic_projectile_tab.allocate_fill (input_data.get_CC_real_E_intrinsic_projectile_tab ());

  Gamma_intrinsic_projectile_tab.allocate_fill (input_data.get_CC_Gamma_intrinsic_projectile_tab ());

  average_n_scat_target_tab.allocate_fill (input_data.get_CC_average_n_scat_target_tab ());

  E_target_tab.allocate (N_target_projectile_states);

  E_intrinsic_projectile_tab.allocate (N_target_projectile_states);
					 
  for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
    {
      E_target_tab(iT) = generate_scalar<TYPE> (real_E_target_tab(iT) , -5E-4*Gamma_target_tab(iT));

      E_intrinsic_projectile_tab(iT) = generate_scalar<TYPE> (real_E_intrinsic_projectile_tab(iT) , -5E-4*Gamma_intrinsic_projectile_tab(iT));
    }

  const unsigned int vector_index_target_max = vector_index_target_tab.max ();

  const int two_J_target_max = make_int (2.0*J_target_tab.max ());
  
  const int two_J_target_max_plus_one = two_J_target_max + 1;

  target_indices.allocate (2 , two_J_target_max_plus_one , vector_index_target_max+1);

  for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
    {
      const unsigned int BP_target = BP_target_tab(iT);

      const unsigned int vector_index_target = vector_index_target_tab(iT);

      const double J_target = J_target_tab(iT);

      const int two_J_target = make_int (2.0*J_target);

      target_indices(BP_target , two_J_target , vector_index_target) = iT;
    }
  
  E_total_tab.allocate (N_energies);
  
  E_kinetic_total_system_CM_tab.allocate               (N_energies);
  E_kinetic_projectile_lab_tab.allocate                (N_energies);  
  E_kinetic_target_lab_inverse_kinematics_tab.allocate (N_energies);

  if (CC_reaction_calculation == POLES)
    {
      E_total_tab = NADA;
      
      E_kinetic_total_system_CM_tab               = NADA;
      E_kinetic_projectile_lab_tab                = NADA;      
      E_kinetic_target_lab_inverse_kinematics_tab = NADA;
    }
  else
    {
      const double mass_target_over_mass_entrance_projectile = mass_target/mass_entrance_projectile;
      
      const double E_kinetic_total_system_CM_start = input_data.get_CC_E_kinetic_total_system_CM_start (); 
      const double E_kinetic_total_system_CM_end   = input_data.get_CC_E_kinetic_total_system_CM_end (); 	

      const double E_kinetic_projectile_lab_start = E_kinetic_total_system_CM_start * CM_to_lab_kinetic_factor; 
      const double E_kinetic_projectile_lab_end   = E_kinetic_total_system_CM_end   * CM_to_lab_kinetic_factor;
  
      const double E_kinetic_target_lab_inverse_kinematics_start = E_kinetic_projectile_lab_start * mass_target_over_mass_entrance_projectile;
      const double E_kinetic_target_lab_inverse_kinematics_end   = E_kinetic_projectile_lab_end   * mass_target_over_mass_entrance_projectile;
  
      const double E_kinetic_projectile_work_frame_start = E_kinetic_total_system_CM_start * CM_to_work_frame_kinetic_factor;
      const double E_kinetic_projectile_work_frame_end   = E_kinetic_total_system_CM_end   * CM_to_work_frame_kinetic_factor;
  
      const class array<double> &real_E_target_tab = input_data.get_CC_real_E_target_tab ();

      const double real_E_target_entrance               = real_E_target_tab              (entrance_target_index);
      const double real_E_intrinsic_projectile_entrance = real_E_intrinsic_projectile_tab(entrance_target_index);

      const double real_E_target_E_intrinsic_projectile_entrance_sum = real_E_target_entrance + real_E_intrinsic_projectile_entrance;

      const double E_total_start = E_kinetic_projectile_work_frame_start + real_E_target_E_intrinsic_projectile_entrance_sum;
      const double E_total_end   = E_kinetic_projectile_work_frame_end   + real_E_target_E_intrinsic_projectile_entrance_sum;

      const double difference_of_energy_total                                 = E_total_end                                  - E_total_start; 
      const double difference_of_energy_kinetic_total_system_CM               = E_kinetic_total_system_CM_end                - E_kinetic_total_system_CM_start; 
      const double difference_of_energy_kinetic_projectile_lab                = E_kinetic_projectile_lab_end                 - E_kinetic_projectile_lab_start; 
      const double difference_of_energy_kinetic_target_lab_inverse_kinematics = E_kinetic_target_lab_inverse_kinematics_end  - E_kinetic_target_lab_inverse_kinematics_start; 

      const double step_energy_total                                 = (N_energies == 1) ? (0) : (difference_of_energy_total                                /(N_energies - 1.0)); 
      const double step_energy_kinetic_total_system_CM               = (N_energies == 1) ? (0) : (difference_of_energy_kinetic_total_system_CM              /(N_energies - 1.0)); 
      const double step_energy_kinetic_projectile_lab                = (N_energies == 1) ? (0) : (difference_of_energy_kinetic_projectile_lab               /(N_energies - 1.0)); 
      const double step_energy_kinetic_target_lab_inverse_kinematics = (N_energies == 1) ? (0) : (difference_of_energy_kinetic_target_lab_inverse_kinematics/(N_energies - 1.0)); 

      for (unsigned int iE = 0 ; iE < N_energies ; iE++)
	{
	  E_total_tab(iE) = step_energy_total*iE + E_total_start;

	  E_kinetic_total_system_CM_tab              (iE) = step_energy_kinetic_total_system_CM              *iE + E_kinetic_total_system_CM_start;
	  E_kinetic_projectile_lab_tab               (iE) = step_energy_kinetic_projectile_lab               *iE + E_kinetic_projectile_lab_start;
	  E_kinetic_target_lab_inverse_kinematics_tab(iE) = step_energy_kinetic_target_lab_inverse_kinematics*iE + E_kinetic_target_lab_inverse_kinematics_start;
	}
    }

  if ((CC_reaction_calculation == DIFFERENTIAL_CROSS_SECTION) || (CC_reaction_calculation == EXCITATION_FUNCTION))
    {
      CM_angles.allocate_fill (input_data.get_CC_CM_angles ());
    }	

  if ((CC_reaction_calculation != POLES) && (THIS_PROCESS == MASTER_PROCESS))
    {
      const TYPE E_entrance_target = E_target_tab(entrance_target_index);

      cout << "E[entrance target] : " << E_entrance_target << " MeV" << endl << endl << endl;
    }

  const double J_intrinsic_max = Jmax_intrinsic_cluster_determine ();

  const int l_intrinsic_max = make_int (2.0*J_intrinsic_max);
	  
  const int l_intrinsic_max_plus_one = l_intrinsic_max + 1;  
  
  if (CC_reaction == SCATTERING)
    {
      J_A_tab.allocate_fill (input_data.get_CC_J_A_composite_tab ());

      BP_A_tab.allocate_fill (input_data.get_CC_BP_A_composite_tab ());

      vector_index_A_tab.allocate_fill (input_data.get_CC_vector_index_A_composite_tab ());
      
      N_channels_tab.allocate (N_JPi_A);

      N_entrance_channels_tab.allocate (N_JPi_A);

      N_channels_per_target_projectile_tab.allocate (N_target_projectile_states , N_JPi_A);

      entrance_JPi_channels_indices.allocate (N_JPi_A , N_entrance_channels_max);

      e_channels_tab.allocate (N_target_projectile_states , N_energies);

      k_channels_tab.allocate (N_target_projectile_states , N_energies);

      eta_channels_tab.allocate (N_target_projectile_states , N_energies);

      N_channels = input_data.N_channels_calc (BP_A_tab , J_A_tab);

      channels_tab_inputs (input_data , true , BP_A_tab , J_A_tab , N_channels_tab , N_entrance_channels_tab , N_channels_per_target_projectile_tab);
      
      const unsigned int N_channels_per_target_projectile_max = N_channels_per_target_projectile_tab.max ();

      channels_tab.allocate (N_channels);

      JPi_channels_indices_per_target_projectile.allocate (N_target_projectile_states , N_JPi_A , N_channels_per_target_projectile_max);

      channels_tab_construction (input_data , true , true , prot_Y_data , neut_Y_data , BP_A_tab , vector_index_A_tab , J_A_tab , entrance_JPi_channels_indices , JPi_channels_indices_per_target_projectile , channels_tab);	

      e_k_eta_channels_tabs_calc (input_data , E_target_tab , projectile_tab , E_intrinsic_projectile_tab , E_total_tab , e_channels_tab , k_channels_tab , eta_channels_tab);
	
      if (!is_it_one_baryon_COSM_case)
	{
	  const unsigned int N_bef_R_GL = input_data.get_N_bef_R_GL ();
	  
	  const unsigned int N_bef_R_uniform = input_data.get_N_bef_R_uniform ();
	  
	  const unsigned int N_bef_R = max (N_bef_R_GL , N_bef_R_uniform);

	  const bool are_there_EM_transitions = input_data.get_are_there_EM_transitions ();

	  const bool are_there_EM_transitions_strength = input_data.get_are_there_EM_transitions_strength ();

	  const bool are_there_beta_transitions = input_data.get_are_there_beta_transitions ();

	  const bool are_there_beta_transitions_strength = input_data.get_are_there_beta_transitions_strength ();

	  const bool are_there_densities = input_data.get_are_there_densities ();

	  const bool are_there_rms_radii = input_data.get_are_there_rms_radii ();

	  const bool are_there_rms_radius_one_body_strengths = input_data.get_are_there_rms_radius_one_body_strengths ();
  
	  if (are_there_EM_transitions)
	    EM_suboperator_intrinsic_NBMEs.allocate (1 , 1 , cluster_projectile_number , cluster_projectile_number , l_intrinsic_max_plus_one , EM_suboperator_type_number_determine ());

	  if (are_there_EM_transitions_strength)
	    EM_suboperator_intrinsic_NBMEs_strength.allocate (cluster_projectile_number , cluster_projectile_number , l_intrinsic_max_plus_one , EM_suboperator_type_number_determine () , N_bef_R );

	  if (are_there_beta_transitions)
	    beta_suboperator_intrinsic_NBMEs.allocate (cluster_projectile_number , cluster_projectile_number , beta_suboperator_type_number_determine ());
	  
	  if (are_there_beta_transitions_strength)
	    beta_suboperator_intrinsic_NBMEs_strength.allocate (cluster_projectile_number , cluster_projectile_number , beta_suboperator_type_number_determine () , N_bef_R);

	  if (are_there_densities || are_there_rms_radii)
	    scalar_intrinsic_NBMEs.allocate (cluster_projectile_number , cluster_projectile_number);
	  
	  if (are_there_rms_radius_one_body_strengths)
	    scalar_intrinsic_NBMEs_strength.allocate (cluster_projectile_number , cluster_projectile_number , N_bef_R);
	}
    }
  
  if (CC_reaction == RADIATIVE_CAPTURE)
    {
      J_A_in_tab.allocate_fill  (input_data.get_CC_J_A_in_composite_tab ());
      J_A_out_tab.allocate_fill (input_data.get_CC_J_A_out_composite_tab ());

      BP_A_in_tab.allocate_fill  (input_data.get_CC_BP_A_in_composite_tab ());
      BP_A_out_tab.allocate_fill (input_data.get_CC_BP_A_out_composite_tab ()); 

      vector_index_A_out_tab.allocate_fill (input_data.get_CC_vector_index_A_out_composite_tab ());

      N_channels_in_tab.allocate  (N_JPi_A_in);
      N_channels_out_tab.allocate (N_JPi_A_out);

      N_entrance_channels_tab.allocate (N_JPi_A_in);

      N_channels_per_target_projectile_in_tab.allocate (N_target_projectile_states  , N_JPi_A_in);
      N_channels_per_target_projectile_out_tab.allocate (N_target_projectile_states , N_JPi_A_out);

      entrance_JPi_channels_indices.allocate (N_JPi_A_in , N_entrance_channels_max);

      N_channels_in = input_data.N_channels_calc  (BP_A_in_tab  , J_A_in_tab);
      N_channels_out = input_data.N_channels_calc (BP_A_out_tab , J_A_out_tab);

      class array<unsigned int> dummy_tab;

      channels_tab_inputs (input_data , true  , BP_A_in_tab  , J_A_in_tab  , N_channels_in_tab  , N_entrance_channels_tab , N_channels_per_target_projectile_in_tab);
      channels_tab_inputs (input_data , false , BP_A_out_tab , J_A_out_tab , N_channels_out_tab , dummy_tab               , N_channels_per_target_projectile_out_tab);

      channels_in_tab.allocate  (N_channels_in);
      channels_out_tab.allocate (N_channels_out);

      const unsigned int N_channels_per_target_projectile_in_max  = N_channels_per_target_projectile_in_tab.max ();
      const unsigned int N_channels_per_target_projectile_out_max = N_channels_per_target_projectile_out_tab.max ();

      JPi_channels_indices_per_target_projectile_in.allocate  (N_target_projectile_states , N_JPi_A_in  , N_channels_per_target_projectile_in_max);
      JPi_channels_indices_per_target_projectile_out.allocate (N_target_projectile_states , N_JPi_A_out , N_channels_per_target_projectile_out_max);

      channels_tab_construction (input_data , true  , false , prot_Y_data , neut_Y_data , BP_A_in_tab  , dummy_tab              , J_A_in_tab  , entrance_JPi_channels_indices , JPi_channels_indices_per_target_projectile_in  , channels_in_tab);
      channels_tab_construction (input_data , false , true  , prot_Y_data , neut_Y_data , BP_A_out_tab , vector_index_A_out_tab , J_A_out_tab , dummy_tab                     , JPi_channels_indices_per_target_projectile_out , channels_out_tab);

      if (!is_it_one_baryon_COSM_case)
	EM_suboperator_intrinsic_NBMEs.allocate (N_energies , N_JPi_A_out , cluster_projectile_number , cluster_projectile_number , l_intrinsic_max_plus_one , EM_suboperator_type_number_determine ());
    }
}






void CC_target_projectile_composite_data::allocate_fill (const class CC_target_projectile_composite_data &X)
{
  Z = X.Z; 
  N = X.N; 
  A = X.A; 

  initial_pivot_from_file = X.initial_pivot_from_file;
  
  truncation_hw = X.truncation_hw; 
  truncation_ph = X.truncation_ph; 

  n_holes_max = X.n_holes_max;
  
  n_scat_max = X.n_scat_max; 

  E_relative_max_hw = X.E_relative_max_hw; 

  CC_reaction = X.CC_reaction; 

  CC_reaction_calculation = X.CC_reaction_calculation;
  
  entrance_projectile = X.entrance_projectile; 

  mass_entrance_projectile = X.mass_entrance_projectile; 

  CM_to_work_frame_kinetic_factor = X.CM_to_work_frame_kinetic_factor; 

  work_frame_to_lab_kinetic_factor = X.work_frame_to_lab_kinetic_factor;
  
  CM_to_lab_kinetic_factor = X.CM_to_lab_kinetic_factor; 

  kinetic_factor_entrance_projectile_work_frame = X.kinetic_factor_entrance_projectile_work_frame; 

  kinetic_factor_entrance_projectile_CM = X.kinetic_factor_entrance_projectile_CM; 

  Z_target = X.Z_target; 
  N_target = X.N_target; 
  A_target = X.A_target; 

  mass_target = X.mass_target;

  are_GSM_a_dagger_vectors_calculated = X.are_GSM_a_dagger_vectors_calculated;

  N_JPi_A     = X.N_JPi_A; 
  N_JPi_A_in  = X.N_JPi_A_in; 
  N_JPi_A_out = X.N_JPi_A_out;  

  N_target_projectile_states = X.N_target_projectile_states; 

  entrance_target_index = X.entrance_target_index; 

  N_entrance_channels_max = X.N_entrance_channels_max; 

  J_intrinsic_projectile_max = X.J_intrinsic_projectile_max; 

  N_energies = X.N_energies; 

  N_CM_angles = X.N_CM_angles; 

  cluster_projectile_number = X.cluster_projectile_number; 

  is_it_one_baryon_COSM_case = X.is_it_one_baryon_COSM_case; 

  EM_for_radiative_capture_cross_section = X.EM_for_radiative_capture_cross_section;

  L_for_radiative_capture_cross_section = X.L_for_radiative_capture_cross_section; 

  N_theta_gamma = X.N_theta_gamma; 

  N_phi_gamma = X.N_phi_gamma; 

  radiative_capture_is_it_longwavelength_approximation = X.radiative_capture_is_it_longwavelength_approximation; 

  radiative_capture_is_it_HO_expansion = X.radiative_capture_is_it_HO_expansion; 

  N_channels     = X.N_channels; 
  N_channels_in  = X.N_channels_in; 
  N_channels_out = X.N_channels_out;

  N_restarts = X.N_restarts;
  
  Davidson_max_dimension  = X.Davidson_max_dimension;

  Davidson_eigenvector_precision = X.Davidson_eigenvector_precision;

  relative_SVD_precision = X.relative_SVD_precision;

  R_cut_function = X.R_cut_function;
  d_cut_function = X.d_cut_function;

  Ueq_regularizor = X.Ueq_regularizor;

  effective_charges_p.allocate_fill (X.effective_charges_p); 
  effective_charges_n.allocate_fill (X.effective_charges_n);
  
  projectile_tab.allocate_fill (X.projectile_tab);

  BP_target_tab.allocate_fill (X.BP_target_tab);

  J_target_tab.allocate_fill (X.J_target_tab);

  vector_index_target_tab.allocate_fill (X.vector_index_target_tab);

  is_it_pole_target_tab.allocate_fill (X.is_it_pole_target_tab);

  real_E_target_tab.allocate_fill (X.real_E_target_tab);

  Gamma_target_tab.allocate_fill (X.Gamma_target_tab);

  E_target_tab.allocate_fill (X.E_target_tab);

  real_E_intrinsic_projectile_tab.allocate_fill (X.real_E_intrinsic_projectile_tab);

  Gamma_intrinsic_projectile_tab.allocate_fill (X.Gamma_intrinsic_projectile_tab);

  E_intrinsic_projectile_tab.allocate_fill (X.E_intrinsic_projectile_tab);

  average_n_scat_target_tab.allocate_fill (X.average_n_scat_target_tab);

  target_indices.allocate_fill (X.target_indices);

  E_total_tab.allocate_fill (X.E_total_tab);

  E_kinetic_total_system_CM_tab.allocate_fill (X.E_kinetic_total_system_CM_tab);

  E_kinetic_projectile_lab_tab.allocate_fill (X.E_kinetic_projectile_lab_tab);

  N_channels_per_target_projectile_tab.allocate_fill(X.N_channels_per_target_projectile_tab);
  
  N_channels_per_target_projectile_in_tab.allocate_fill  (X.N_channels_per_target_projectile_in_tab);
  N_channels_per_target_projectile_out_tab.allocate_fill (X.N_channels_per_target_projectile_out_tab);

  JPi_channels_indices_per_target_projectile.allocate_fill (X.JPi_channels_indices_per_target_projectile);

  JPi_channels_indices_per_target_projectile_in.allocate_fill  (X.JPi_channels_indices_per_target_projectile_in);
  JPi_channels_indices_per_target_projectile_out.allocate_fill (X.JPi_channels_indices_per_target_projectile_out);

  channels_tab.allocate_fill (X.channels_tab);

  channels_in_tab.allocate_fill  (X.channels_in_tab);
  channels_out_tab.allocate_fill (X.channels_out_tab);

  e_channels_tab.allocate_fill (X.e_channels_tab);
  k_channels_tab.allocate_fill (X.k_channels_tab);
  
  eta_channels_tab.allocate_fill (X.eta_channels_tab);

  CM_angles.allocate_fill (X.CM_angles);

  J_A_tab.allocate_fill (X.J_A_tab);

  BP_A_tab.allocate_fill (X.BP_A_tab);

  vector_index_A_tab.allocate_fill (X.vector_index_A_tab);

  N_channels_tab.allocate_fill (X.N_channels_tab);

  N_entrance_channels_tab.allocate_fill (X.N_entrance_channels_tab);

  entrance_JPi_channels_indices.allocate_fill (X.entrance_JPi_channels_indices);

  J_A_in_tab.allocate_fill  (X.J_A_in_tab);
  J_A_out_tab.allocate_fill (X.J_A_out_tab);

  BP_A_in_tab.allocate_fill  (X.BP_A_in_tab);
  BP_A_out_tab.allocate_fill (X.BP_A_out_tab);
  
  N_channels_in_tab.allocate_fill  (X.N_channels_in_tab);
  N_channels_out_tab.allocate_fill (X.N_channels_out_tab);

  beta_suboperator_intrinsic_NBMEs.allocate_fill (X.beta_suboperator_intrinsic_NBMEs);

  beta_suboperator_intrinsic_NBMEs_strength.allocate_fill (X.beta_suboperator_intrinsic_NBMEs);

  EM_suboperator_intrinsic_NBMEs.allocate_fill (X.EM_suboperator_intrinsic_NBMEs);

  EM_suboperator_intrinsic_NBMEs_strength.allocate_fill (X.EM_suboperator_intrinsic_NBMEs);

  scalar_intrinsic_NBMEs.allocate_fill (X.scalar_intrinsic_NBMEs);

  scalar_intrinsic_NBMEs_strength.allocate_fill (X.scalar_intrinsic_NBMEs_strength);
}

















void CC_target_projectile_composite_data::deallocate ()
{
  effective_charges_p.deallocate ();
  effective_charges_n.deallocate ();
  
  projectile_tab.deallocate ();

  BP_target_tab.deallocate (); 

  J_target_tab.deallocate (); 

  vector_index_target_tab.deallocate ();

  is_it_pole_target_tab.deallocate (); 

  real_E_target_tab.deallocate (); 

  Gamma_target_tab.deallocate ();

  E_target_tab.deallocate (); 

  real_E_intrinsic_projectile_tab.deallocate ();

  Gamma_intrinsic_projectile_tab.deallocate (); 

  E_intrinsic_projectile_tab.deallocate (); 

  average_n_scat_target_tab.deallocate (); 

  target_indices.deallocate ();

  E_total_tab.deallocate (); 

  E_kinetic_total_system_CM_tab.deallocate ();

  E_kinetic_projectile_lab_tab.deallocate ();

  N_channels_per_target_projectile_tab.deallocate ();

  N_channels_per_target_projectile_in_tab.deallocate ();
  N_channels_per_target_projectile_out_tab.deallocate (); 

  JPi_channels_indices_per_target_projectile.deallocate (); 

  JPi_channels_indices_per_target_projectile_in.deallocate ();
  JPi_channels_indices_per_target_projectile_out.deallocate (); 

  channels_tab.deallocate ();  

  channels_in_tab.deallocate ();
  channels_out_tab.deallocate (); 

  e_channels_tab.deallocate (); 

  k_channels_tab.deallocate ();  

  eta_channels_tab.deallocate (); 

  CM_angles.deallocate ();

  J_A_tab.deallocate ();

  BP_A_tab.deallocate (); 

  vector_index_A_tab.deallocate ();

  N_channels_tab.deallocate ();

  N_entrance_channels_tab.deallocate ();

  entrance_JPi_channels_indices.deallocate (); 

  J_A_in_tab.deallocate ();
  J_A_out_tab.deallocate (); 

  BP_A_in_tab.deallocate ();
  BP_A_out_tab.deallocate (); 

  N_channels_in_tab.deallocate ();
  N_channels_out_tab.deallocate ();

  beta_suboperator_intrinsic_NBMEs.deallocate ();

  beta_suboperator_intrinsic_NBMEs_strength.deallocate ();

  EM_suboperator_intrinsic_NBMEs.deallocate ();

  EM_suboperator_intrinsic_NBMEs_strength.deallocate ();

  scalar_intrinsic_NBMEs.deallocate ();

  scalar_intrinsic_NBMEs_strength.deallocate ();
  
  Z = 0;
  N = 0;
  A = 0;

  initial_pivot_from_file = false;
  
  truncation_hw = false; 
  truncation_ph = false; 

  n_holes_max = 0;
  
  n_scat_max = 0; 

  E_relative_max_hw = 0; 

  CC_reaction = NO_REACTION;
  
  CC_reaction_calculation = NO_REACTION_CALCULATION; 

  entrance_projectile = NO_PARTICLE;

  mass_entrance_projectile = 0.0; 

  CM_to_work_frame_kinetic_factor = 0.0;

  work_frame_to_lab_kinetic_factor = 0.0;
  
  CM_to_lab_kinetic_factor = 0.0;

  kinetic_factor_entrance_projectile_work_frame = 0.0; 

  kinetic_factor_entrance_projectile_CM = 0.0; 

  Z_target = 0;
  N_target = 0; 
  A_target = 0; 

  mass_target = 0.0; 

  are_GSM_a_dagger_vectors_calculated = false; 

  N_JPi_A     = 0;
  N_JPi_A_in  = 0; 
  N_JPi_A_out = 0; 

  N_target_projectile_states = 0; 

  entrance_target_index = 0; 

  N_entrance_channels_max = 0; 

  J_intrinsic_projectile_max = 0.0; 

  N_energies = 0; 

  N_CM_angles = 0; 

  cluster_projectile_number = 0; 

  is_it_one_baryon_COSM_case = false; 

  EM_for_radiative_capture_cross_section = NO_EM; 

  L_for_radiative_capture_cross_section = 0; 

  N_theta_gamma = 0; 

  N_phi_gamma = 0; 

  radiative_capture_is_it_longwavelength_approximation = false; 

  radiative_capture_is_it_HO_expansion = false; 
  
  N_channels     = 0; 
  N_channels_in  = 0; 
  N_channels_out = 0;

  N_restarts = 0;

  Davidson_max_dimension = 0;

  Davidson_eigenvector_precision = 0.0;

  relative_SVD_precision = 0.0;

  R_cut_function = 0.0;
  d_cut_function = 0.0;

  Ueq_regularizor = 0.0;
}








// Memory used by the class
// ------------------------

double used_memory_calc (const class CC_target_projectile_composite_data &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.projectile_tab) +
    used_memory_calc (T.BP_target_tab) +
    used_memory_calc (T.J_target_tab) +
    used_memory_calc (T.vector_index_target_tab) +
    used_memory_calc (T.is_it_pole_target_tab) +
    used_memory_calc (T.real_E_target_tab) +
    used_memory_calc (T.Gamma_target_tab) +
    used_memory_calc (T.E_target_tab) +
    used_memory_calc (T.real_E_intrinsic_projectile_tab) +
    used_memory_calc (T.Gamma_intrinsic_projectile_tab) +
    used_memory_calc (T.E_intrinsic_projectile_tab) +
    used_memory_calc (T.average_n_scat_target_tab) +
    used_memory_calc (T.target_indices) +
    used_memory_calc (T.E_total_tab) +
    used_memory_calc (T.E_kinetic_total_system_CM_tab) +
    used_memory_calc (T.E_kinetic_projectile_lab_tab) +
    used_memory_calc (T.N_channels_per_target_projectile_tab) +
    used_memory_calc (T.N_channels_per_target_projectile_in_tab) +
    used_memory_calc (T.N_channels_per_target_projectile_out_tab) +
    used_memory_calc (T.JPi_channels_indices_per_target_projectile) +
    used_memory_calc (T.JPi_channels_indices_per_target_projectile_in) +
    used_memory_calc (T.JPi_channels_indices_per_target_projectile_out) +
    used_memory_calc (T.channels_tab) +
    used_memory_calc (T.channels_in_tab) +
    used_memory_calc (T.channels_out_tab) +
    used_memory_calc (T.e_channels_tab) +
    used_memory_calc (T.k_channels_tab) +
    used_memory_calc (T.eta_channels_tab) +
    used_memory_calc (T.CM_angles) +
    used_memory_calc (T.J_A_tab) +
    used_memory_calc (T.BP_A_tab) +
    used_memory_calc (T.vector_index_A_tab) +
    used_memory_calc (T.N_channels_tab) +
    used_memory_calc (T.N_entrance_channels_tab) +
    used_memory_calc (T.entrance_JPi_channels_indices) +
    used_memory_calc (T.J_A_in_tab) +
    used_memory_calc (T.J_A_out_tab) +
    used_memory_calc (T.BP_A_in_tab) +
    used_memory_calc (T.BP_A_out_tab) +
    used_memory_calc (T.vector_index_A_out_tab) +
    used_memory_calc (T.N_channels_in_tab) +
    used_memory_calc (T.N_channels_out_tab) +
    used_memory_calc (T.beta_suboperator_intrinsic_NBMEs) +
    used_memory_calc (T.beta_suboperator_intrinsic_NBMEs_strength) +
    used_memory_calc (T.EM_suboperator_intrinsic_NBMEs) +
    used_memory_calc (T.EM_suboperator_intrinsic_NBMEs_strength) +
    used_memory_calc (T.scalar_intrinsic_NBMEs) +
    used_memory_calc (T.scalar_intrinsic_NBMEs_strength) +
    used_memory_calc (T.effective_charges_p) +
    used_memory_calc (T.effective_charges_n)
    - (sizeof (T.projectile_tab) +
       sizeof (T.BP_target_tab) +
       sizeof (T.J_target_tab) +
       sizeof (T.vector_index_target_tab) +
       sizeof (T.is_it_pole_target_tab) +
       sizeof (T.real_E_target_tab) +
       sizeof (T.Gamma_target_tab) +
       sizeof (T.E_target_tab) +
       sizeof (T.real_E_intrinsic_projectile_tab) +
       sizeof (T.Gamma_intrinsic_projectile_tab) +
       sizeof (T.E_intrinsic_projectile_tab) +
       sizeof (T.average_n_scat_target_tab) +
       sizeof (T.target_indices) +
       sizeof (T.E_total_tab) +
       sizeof (T.E_kinetic_total_system_CM_tab) +
       sizeof (T.E_kinetic_projectile_lab_tab) +
       sizeof (T.N_channels_per_target_projectile_tab) +
       sizeof (T.N_channels_per_target_projectile_in_tab) +
       sizeof (T.N_channels_per_target_projectile_out_tab) +
       sizeof (T.JPi_channels_indices_per_target_projectile) +
       sizeof (T.JPi_channels_indices_per_target_projectile_in) +
       sizeof (T.JPi_channels_indices_per_target_projectile_out) +
       sizeof (T.channels_tab) +
       sizeof (T.channels_in_tab) +
       sizeof (T.channels_out_tab) +
       sizeof (T.e_channels_tab) +
       sizeof (T.k_channels_tab) +
       sizeof (T.eta_channels_tab) +
       sizeof (T.CM_angles) +
       sizeof (T.J_A_tab) +
       sizeof (T.BP_A_tab) +
       sizeof (T.vector_index_A_tab) +
       sizeof (T.N_channels_tab) +
       sizeof (T.N_entrance_channels_tab) +
       sizeof (T.entrance_JPi_channels_indices) +
       sizeof (T.J_A_in_tab) +
       sizeof (T.J_A_out_tab) +
       sizeof (T.BP_A_in_tab) +
       sizeof (T.BP_A_out_tab) +
       sizeof (T.vector_index_A_out_tab) +
       sizeof (T.N_channels_in_tab) +
       sizeof (T.N_channels_out_tab) +
       sizeof (T.beta_suboperator_intrinsic_NBMEs) +
       sizeof (T.beta_suboperator_intrinsic_NBMEs_strength) +
       sizeof (T.EM_suboperator_intrinsic_NBMEs) +
       sizeof (T.EM_suboperator_intrinsic_NBMEs_strength) +
       sizeof (T.scalar_intrinsic_NBMEs) +
       sizeof (T.scalar_intrinsic_NBMEs_strength) +
       sizeof (T.effective_charges_p) +
       sizeof (T.effective_charges_n))/1000000.0;

  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;
}



