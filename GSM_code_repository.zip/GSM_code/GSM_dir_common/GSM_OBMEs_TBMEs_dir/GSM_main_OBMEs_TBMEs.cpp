#include "../GSM_dir/GSM_include/GSM_include_def_common.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

enum called_code_type called_code = OBMES_TBMES_CODE;


using namespace inputs_misc;



#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    print_array_vector_test_status<int> ();

    //--// dummy variables
    class array<double> dummy_array_double;
    class array<string> dummy_array_string;
    class array<class input_data_str> dummy_input_data_tab;
    class input_data_str dummy_input_data;
    
    const class array <class array<class JT_coupled_TBME> > dummy_array_JT_coupled_TBME;

    //================================== input data and nucleons data ==================================//
    
    //--// initialization of the class which contains all input values and some pointers on tables (not all initialized here)

    class input_data_str input_data;
    
    call_common_routines::input_data_read_MPI_transfer (dummy_array_double , dummy_array_double , dummy_array_string , input_data , dummy_input_data , dummy_input_data_tab);
      
    //--// initialization of the classes which contain information on protons and neutrons

    class baryons_data prot_Y_data;
    class baryons_data neut_Y_data;

    baryons_data_initialization (true , input_data , prot_Y_data , neut_Y_data);
    
    const enum space_type space = input_data.get_space ();
    
    //================================== Berggren one-body basis and HF potentials in HO basis ==================================//

    radial_wfs_HF_data_HO_overlaps_basis_pn_alloc_read_disk (input_data , prot_Y_data , neut_Y_data);

    space_truncation_data_best_hbar_omega_calc (false , input_data , prot_Y_data , neut_Y_data);

    //================================== GSM interaction  ==================================//
    
    //--// class which contains information on the interaction

    class interaction_class inter_data_basis(true , true , false , input_data);

    inter_data_basis.inter_data_calc (input_data);
    
    class interaction_class inter_data(true , false , false , input_data);

    inter_data.inter_data_calc (input_data);
    
    //================================== OBMEs, TBMEs ==================================//

    HO_GHF_overlaps_pn_alloc_calc (false , input_data , prot_Y_data , neut_Y_data);
	
    //--// initialization of the class which contains proton-neutron TBMEs
    class TBMEs_class TBMEs_pn;
    class TBMEs_class TBMEs_cv;
    
    //--// initialization of the tables containing the OBMEs, TBMEs
    OBMEs_TBMEs::all_OBMEs_TBMEs_alloc_calc (true , false , dummy_array_JT_coupled_TBME , inter_data_basis , inter_data , input_data , prot_Y_data , neut_Y_data , TBMEs_pn , TBMEs_cv);
    
    hole_double_counting::prot_neut_OBMEs_no_natural_orbitals_calc_store_remove (false , input_data , prot_Y_data , neut_Y_data , TBMEs_pn);

    if (THIS_PROCESS == MASTER_PROCESS)
      {
	all_OBMEs_inter_HO_GHF_overlaps_copy_disk (input_data , prot_Y_data , neut_Y_data);

	all_OBMEs_CM_reduced_r_grad_sets_copy_disk (space , prot_Y_data , neut_Y_data);

	TBMEs_pp_nn_pn_copy_disk (input_data , prot_Y_data , neut_Y_data , TBMEs_pn , TBMEs_cv);
      }

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
    
    return 0;
  }


