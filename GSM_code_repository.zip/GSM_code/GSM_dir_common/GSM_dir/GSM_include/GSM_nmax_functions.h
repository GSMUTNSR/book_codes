#ifndef GSMNMAXFUNCTIONS_H
#define GSMNMAXFUNCTIONS_H

// TYPE is double or complex
// -------------------------

unsigned int N_nlj_calc (const class array<int> &nmax_tab);

int nmax_calc (const class array<int> &nmax_tab);

unsigned int N_nlj_calc (
			 const int lmax_all , 
			 const int nmax_tab[]);

int nmax_calc (
	       const int lmax_all , 
	       const int nmax_tab[]);

void NCM_HO_max_tab_calc (
			  const int E_CM_HO_max , 
			  class array<int> &NCM_HO_max_tab);

#endif


