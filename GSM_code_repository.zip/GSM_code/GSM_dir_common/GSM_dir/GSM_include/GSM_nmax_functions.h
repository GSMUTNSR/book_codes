#ifndef GSMNMAXFUNCTIONS_H
#define GSMNMAXFUNCTIONS_H

// TYPE is double or complex
// -------------------------

int nmax_l_calc (
		 const int l ,		 
		 const class lj_table<int> &nmax_tab);

void NCM_HO_max_tab_calc (
			  const int E_CM_HO_max , 
			  class array<int> &NCM_HO_max_tab);

#endif


