#ifndef GSMPAIRS_H
#define GSMPAIRS_H

// TYPE is double or complex
// -------------------------

class pair_str
{
public:
  
  pair_str ();
  
  pair_str (const unsigned short int left_c , const unsigned short int right_c);
  
  pair_str (const class pair_str &X);

  void initialize (const unsigned short int left_c , const unsigned short int right_c);
  
  void initialize (const class pair_str &X);

  bool are_there_core_states_determine (
					const class array<class nlj_struct> &shells_table_left , 
					const class array<class nlj_struct> &shells_table_right) const;

  bool are_there_frozen_states_determine (
					  const class array<class nlj_struct> &shells_table_left , 
					  const class array<class nlj_struct> &shells_table_right) const;

  bool are_there_hole_states_determine (
					const class array<class nlj_struct> &shells_table_left , 
					const class array<class nlj_struct> &shells_table_right) const;

  bool only_hole_states_determine (
				   const class array<class nlj_struct> &shells_table_left , 
				   const class array<class nlj_struct> &shells_table_right) const;

  unsigned int bp_determine (
			     const class array<class nljm_struct> &phi_table_left , 
			     const class array<class nljm_struct> &phi_table_right) const;

  unsigned int bp_determine (
			     const class array<class nlj_struct> &shells_table_left , 
			     const class array<class nlj_struct> &shells_table_right) const;

  int im_determine (
		    const class array<class nljm_struct> &phi_table_left , 
		    const class array<class nljm_struct> &phi_table_right) const;

  int M_determine (
		   const class array<class nljm_struct> &phi_table_left , 
		   const class array<class nljm_struct> &phi_table_right) const;
  
  int n_scat_determine (
			const class array<class nlj_struct> &shells_table_left , 
			const class array<class nlj_struct> &shells_table_right) const;

  int n_scat_determine (
			const class array<class nljm_struct> &phi_table_left , 
			const class array<class nljm_struct> &phi_table_right) const;
  
  int E_hw_determine (
		      const class array<class nlj_struct> &shells_table_left , 
		      const class array<class nlj_struct> &shells_table_right) const;

  int Jmin_determine (
		      const class array<class nlj_struct> &shells_table_left , 
		      const class array<class nlj_struct> &shells_table_right) const;

  int Jmax_determine (
		      const class array<class nlj_struct> &shells_table_left , 
		      const class array<class nlj_struct> &shells_table_right) const;


  int Jmin_determine (
		      const class array<class nljm_struct> &phi_table_left , 
		      const class array<class nljm_struct> &phi_table_right) const;
  
  int Jmax_determine (
		      const class array<class nljm_struct> &phi_table_left , 
		      const class array<class nljm_struct> &phi_table_right) const;
 
  class pair_str swap () const;

  bool is_it_in_new_space (
			   const class array<class nlj_struct> &old_shells_qn_left,
			   const class array<class nlj_struct> &old_shells_qn_right,
			   const class lj_table<int> &new_nmax_lj_tab_left ,
			   const class lj_table<int> &new_nmax_lj_tab_right ,
			   const class nlj_table<bool> &new_is_it_valence_shell_tab_left ,
			   const class nlj_table<bool> &new_is_it_valence_shell_tab_right) const;
 
  void reindexation_and_phase (
			       const enum space_type space , 
			       const class array<class nlj_struct> &old_shells_qn_left ,
			       const class array<class nlj_struct> &old_shells_qn_right ,
			       const class nlj_table<unsigned int> &new_shells_indices_left ,
			       const class nlj_table<unsigned int> &new_shells_indices_right ,
			       const int J ,
			       int &phase);
  
  bool ordered () const;

  const class pair_str & operator= (const class pair_str &pair);

  void print (
	      const class array<class nljm_struct> &phi_table_left , 
	      const class array<class nljm_struct> &phi_table_right) const;

  void print (
	      const class array<class nlj_struct> &shells_table_left , 
	      const class array<class nlj_struct> &shells_table_right) const;
  
  unsigned short int get_left () const
  {
    return left;
  }
  
  unsigned short int get_right () const
  {
    return right;
  }
    
private:
  
  unsigned short int left;
  unsigned short int right;
};

bool operator == (const class pair_str &a , const class pair_str &b);
bool operator != (const class pair_str &a , const class pair_str &b);

bool operator > (const class pair_str &a , const class pair_str &b);
bool operator < (const class pair_str &a , const class pair_str &b);

bool operator >= (const class pair_str &a , const class pair_str &b);
bool operator <= (const class pair_str &a , const class pair_str &b);

ostream & operator << (ostream &os , const class pair_str &pair);
istream & operator >> (istream &is ,       class pair_str &pair);

double used_memory_calc (const class pair_str &T);

#endif


