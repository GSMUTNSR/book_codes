#ifndef GSMUNCOUPLEDTBMESCLASS_H
#define GSMUNCOUPLEDTBMESCLASS_H

// TYPE is double or complex
// -------------------------

class uncoupled_TBMEs_class
{
public:

  uncoupled_TBMEs_class ();

  uncoupled_TBMEs_class (
			 const bool is_there_cout , 
			 const unsigned int N_nljm_baryon ,
			 const class array<class pair_str> &pairs_in_tab , 
			 const class array<class pair_str> &pairs_out_tab , 
			 const class array<class nljm_struct> &phi_table , 
			 const class TBMEs_class &TBMEs);

  uncoupled_TBMEs_class (
			 const bool is_there_cout , 
			 const unsigned int Np_nljm_baryon ,				      
			 const unsigned int Nn_nljm_baryon ,
			 const bool is_pp_calculated , 
			 const bool is_nn_calculated , 
			 const bool is_pn_non_zero ,  
			 const bool is_cv_non_zero , 
			 const class array<class pair_str> &pp_pairs_in_tab , 
			 const class array<class pair_str> &nn_pairs_in_tab , 
			 const class array<class pair_str> &pn_pairs_in_tab , 
			 const class array<class pair_str> &pp_pairs_out_tab , 
			 const class array<class pair_str> &nn_pairs_out_tab , 
			 const class array<class pair_str> &pn_pairs_out_tab , 
			 const class array<class nljm_struct> &phi_p_table , 
			 const class array<class nljm_struct> &phi_n_table , 
			 const class TBMEs_class &TBMEs_pp , 
			 const class TBMEs_class &TBMEs_nn , 
			 const class TBMEs_class &TBMEs_pn , 
			 const class TBMEs_class &TBMEs_cv);

  uncoupled_TBMEs_class (const class uncoupled_TBMEs_class &X);

  ~uncoupled_TBMEs_class ();
  
  void allocate (
		 const bool is_there_cout , 
		 const unsigned int N_nljm_baryon ,
		 const class array<class pair_str> &pairs_in_tab , 
		 const class array<class pair_str> &pairs_out_tab , 
		 const class array<class nljm_struct> &phi_table , 
		 const class TBMEs_class &TBMEs);

  void allocate (
		 const bool is_there_cout , 
		 const unsigned int Np_nljm_baryon ,				      
		 const unsigned int Nn_nljm_baryon ,
		 const bool is_pp_calculated , 
		 const bool is_nn_calculated , 
		 const bool is_pn_non_zero ,  
		 const bool is_cv_non_zero , 
		 const class array<class pair_str> &pp_pairs_in_tab , 
		 const class array<class pair_str> &nn_pairs_in_tab , 
		 const class array<class pair_str> &pn_pairs_in_tab , 
		 const class array<class pair_str> &pp_pairs_out_tab , 
		 const class array<class pair_str> &nn_pairs_out_tab , 
		 const class array<class pair_str> &pn_pairs_out_tab , 
		 const class array<class nljm_struct> &phi_p_table , 
		 const class array<class nljm_struct> &phi_n_table , 
		 const class TBMEs_class &TBMEs_pp , 
		 const class TBMEs_class &TBMEs_nn , 
		 const class TBMEs_class &TBMEs_pn , 
		 const class TBMEs_class &TBMEs_cv);

  void allocate_fill (const class uncoupled_TBMEs_class &X); 

  void deallocate (); 

  unsigned int index_determine (
				const enum space_type TBME_space , 
				const bool is_it_cv_pp_to_nn ,
				const unsigned int left_in ,
				const unsigned int right_in , 
				const unsigned int left_out ,
				const unsigned int right_out) const;

  TYPE & operator [] (const unsigned int index) const
  {
    return List[index];
  }
		
  TYPE & operator () (
		      const enum space_type TBME_space , 
		      const bool is_it_cv_pp_to_nn ,
		      const unsigned int left_in ,
		      const unsigned int right_in , 
		      const unsigned int left_out ,
		      const unsigned int right_out) const
  {
    const unsigned int index = index_determine (TBME_space , is_it_cv_pp_to_nn , left_in , right_in , left_out , right_out);
  
    if (index < dimension_List)
      return List[index];
    else
      return zero_TBME;
  }

  bool is_it_filled () const
  {
    return (List != NULL);
  }
  
  friend double used_memory_calc (const class uncoupled_TBMEs_class &T);
  
private:  

  void pp_constructor_part (
			    const unsigned int Np_nljm_baryon ,
			    const class array<class pair_str> &pp_pairs_in_tab , 
			    const class array<class pair_str> &pp_pairs_out_tab , 
			    const class array<class nljm_struct> &phi_p_table);

  void nn_constructor_part (				      
			    const unsigned int Nn_nljm_baryon ,
			    const class array<class pair_str> &nn_pairs_in_tab , 
			    const class array<class pair_str> &nn_pairs_out_tab , 
			    const class array<class nljm_struct> &phi_n_table);

  void pn_constructor_part (
			    const unsigned int Np_nljm_baryon ,				      
			    const unsigned int Nn_nljm_baryon ,
			    const class array<class pair_str> &pn_pairs_in_tab , 
			    const class array<class pair_str> &pn_pairs_out_tab , 
			    const class array<class nljm_struct> &phi_p_table , 
			    const class array<class nljm_struct> &phi_n_table);
  
  void cv_constructor_part ();
  
  unsigned int pp_index_determine (
				   const unsigned int p_in ,
				   const unsigned int pp_in , 
				   const unsigned int p_out ,
				   const unsigned int pp_out) const;

  unsigned int nn_index_determine (
				   const unsigned int n_in ,
				   const unsigned int nn_in , 
				   const unsigned int n_out ,
				   const unsigned int nn_out) const;

  unsigned int pn_index_determine (
				   const unsigned int p_in ,
				   const unsigned int n_in , 
				   const unsigned int p_out ,
				   const unsigned int n_out) const;
  
  unsigned int cv_pp_to_nn_index_determine (
					    const unsigned int p_in ,
					    const unsigned int pp_in , 
					    const unsigned int n_out ,
					    const unsigned int nn_out) const;
  
  unsigned int cv_nn_to_pp_index_determine (
					    const unsigned int n_in ,
					    const unsigned int nn_in , 
					    const unsigned int p_out ,
					    const unsigned int pp_out) const;

  unsigned int index_determine_pp_nn (
				      const unsigned int mu_in ,
				      const unsigned int mu_p_in , 
				      const unsigned int mu_out ,
				      const unsigned int mu_p_out) const;

  mutable TYPE zero_TBME; // matrix element equal to zero. It used to return a reference to a TBME equal to zero in case that it is not stored in the array List below because it is trivially equal to zero.
  
  bool is_it_pp_nn; // true if it is pp or nn TBMEs, false if it is pn or cv TBMEs

  // Number of pairs of pp,nn,pn,cv type (valence protons and neutrons (plus a few hyperons if any), first three lines, pp-nn conversions, last line) or of pp/nn type (valence protons or neutrons (plus a few hyperons if any), fourth line)
  // sum of dimensions are used to find indices in the middle of the List one-dimensional array as a function of the quantum numbers defining the TBME.
  // cv_pp_to_nn is for <nn | V | pp> and cv_nn_to_pp for <pp | V | nn>.
  
  class array<unsigned int> dimensions_pp_pairs_in , dimensions_pp_pairs_out , pp_sum_dimensions;
  class array<unsigned int> dimensions_nn_pairs_in , dimensions_nn_pairs_out , nn_sum_dimensions;
  class array<unsigned int> dimensions_pn_pairs_in , dimensions_pn_pairs_out , pn_sum_dimensions;
  
  class array<unsigned int> dimensions_pairs_in , dimensions_pairs_out , sum_dimensions;
  
  class array<unsigned int> cv_pp_to_nn_sum_dimensions;
  class array<unsigned int> cv_nn_to_pp_sum_dimensions;

  // arrays of binary parities (see observables_basic_functions.cpp for definition), strangeness, and im = m + m[max] indices
  // It is for pairs of pp,nn,pn type (valence protons and neutrons (plus a few hyperons if any), first three lines) or of pp/nn type (valence protons or neutrons (plus a few hyperons if any), last line)
  
  class array<unsigned int> bp_pp_table;
  class array<unsigned int> bp_nn_table;
  class array<unsigned int> bp_pn_table;
  
  class array<unsigned int> bp_table;

  class array<int> strangeness_pp_table;
  class array<int> strangeness_nn_table;
  class array<int> strangeness_pn_table;
  
  class array<int> strangeness_table;
  
  class array<int> im_pp_table;
  class array<int> im_nn_table;
  class array<int> im_pn_table;
  
  class array<int> im_table;
  
  // arrays of indices of in and out pairs (<out | V | in>) of pp,nn,pn type (valence protons and neutrons (plus a few hyperons if any), first three lines) or of pp/nn type (valence protons or neutrons (plus a few hyperons if any), last line)
  
  class array<unsigned int> pp_pairs_in_indices , pp_pairs_out_indices;
  class array<unsigned int> nn_pairs_in_indices , nn_pairs_out_indices;
  class array<unsigned int> pn_pairs_in_indices , pn_pairs_out_indices;
  
  class array<unsigned int> pairs_in_indices , pairs_out_indices;

  // Number of TBMEs of pp,nn,pn,cv type (valence protons and neutrons (plus a few hyperons if any), pp-nn conversions, first three lines) or of pp/nn type (valence protons or neutrons (plus a few hyperons if any), last line)
  
  unsigned int dimension_List_pp;
  unsigned int dimension_List_nn;
  unsigned int dimension_List_pn;
  
  unsigned int dimension_List_pp_nn;
  
  unsigned int dimension_List_cv_pp_to_nn;  
  unsigned int dimension_List_cv_nn_to_pp;  

  // Total number of TBMEs and array storing TBMEs
  
  unsigned int dimension_List;
  
  TYPE *List;
};

#endif


