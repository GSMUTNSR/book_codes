#ifndef GSMMULTIPOLEOBMESTBMES_H
#define GSMMULTIPOLEOBMESTBMES_H

// TYPE is double or complex
// -------------------------

namespace GSM_multipole_OBMEs_TBMEs
{
  const class OBMEs_multipole_square_str & OBMEs_multipole_square_determine (
									     const bool is_it_HO_expansion ,
									     const class nucleons_data &data);

  const class OBMEs_multipole_reduced_str & OBMEs_multipole_reduced_determine (
									       const bool is_it_HO_expansion ,
									       const class nucleons_data &data);

  TYPE uncoupled_OBME (
		       const int L ,
		       const bool is_it_HO_expansion ,
		       const class nucleons_data &data ,
		       const unsigned int s_in ,
		       const unsigned int s_out);
  
  TYPE coupled_OBME (
		     const int L ,
		     const bool is_it_HO_expansion ,
		     const class nucleons_data &data ,
		     const unsigned int s_in ,
		     const unsigned int s_out);

  bool is_uncoupled_TBME_pp_nn_trivial_zero_determine (
						       const int L ,
						       const class array<class nljm_struct> &phi_table ,
						       const unsigned int s0 , 
						       const unsigned int s1 , 
						       const unsigned int s2 , 
						       const unsigned int s3);

  bool is_uncoupled_TBME_pn_trivial_zero_determine_coupling_only (
								  const int L ,
								  const class array<class nljm_struct> &phi_table ,
								  const unsigned int s_in , 
								  const unsigned int s_out);
  bool is_coupled_TBME_pp_nn_trivial_zero_determine (
						     const int L ,
						     const class array<class nlj_struct> &shells_qn , 
						     const unsigned int s0 , 
						     const unsigned int s1 , 
						     const unsigned int s2 , 
						     const unsigned int s3);

  bool is_coupled_TBME_pn_trivial_zero_determine (
						  const int L ,
						  const class array<class nlj_struct> &shells_qn_prot , 
						  const class array<class nlj_struct> &shells_qn_neut ,
						  const unsigned int s0 , 
						  const unsigned int s1 , 
						  const unsigned int s2 , 
						  const unsigned int s3);
  
  TYPE TBME_pp_nn_calc (
			const int L ,
			const unsigned int s0 , 
			const unsigned int s1 , 
			const unsigned int s2 , 
			const unsigned int s3 , 
			const double angular_TBME_direct , 
			const double angular_TBME_exchange , 
			const class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced);

  TYPE TBME_pn_calc (
		     const int L ,
		     const unsigned int s0 , 
		     const unsigned int s1 , 
		     const unsigned int s2 , 
		     const unsigned int s3 , 
		     const double angular_TBME ,
		     const class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced_prot ,
		     const class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced_neut);

  TYPE uncoupled_TBME_pp_nn_calc (
				  const int L ,
				  const bool is_it_HO_expansion ,
				  const class nucleons_data &data ,
				  const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
				  const unsigned int s0 , 
				  const unsigned int s1 , 
				  const unsigned int s2 , 
				  const unsigned int s3);

  TYPE uncoupled_TBME_pn_calc (
			       const int L ,
			       const bool is_it_HO_expansion ,
			       const class nucleons_data &prot_data ,
			       const class nucleons_data &neut_data ,
			       const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
			       const unsigned int s0 , 
			       const unsigned int s1 , 
			       const unsigned int s2 , 
			       const unsigned int s3);

  TYPE coupled_TBME_pp_nn_calc (
				const int L ,
				const bool is_it_HO_expansion ,
				const class nucleons_data &data ,
				const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
				const unsigned int s0 , 
				const unsigned int s1 , 
				const unsigned int s2 , 
				const unsigned int s3);

  TYPE coupled_TBME_pn_calc (
			     const int L ,
			     const bool is_it_HO_expansion ,
			     const class nucleons_data &prot_data ,
			     const class nucleons_data &neut_data ,
			     const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
			     const unsigned int s0 , 
			     const unsigned int s1 , 
			     const unsigned int s2 , 
			     const unsigned int s3);
}


#endif
