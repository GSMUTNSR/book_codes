#ifndef GSMCONFIGURATION_H
#define GSMCONFIGURATION_H

class virtual_configuration;
class array_of_configuration;

// TYPE is double or complex
// -------------------------

class configuration 
{
public:

  configuration ();
  
  explicit configuration (const unsigned short int N_valence_baryons_c);
  
  configuration (const class configuration &C);
  
  configuration (const class virtual_configuration &C);

  ~configuration ();
  
  bool is_it_filled () const
  {
    return (shells != NULL);
  }
  
  void allocate (const unsigned short int N_valence_baryons_c);
  
  void allocate_fill (const class configuration &C);
  
  void allocate_fill (const class virtual_configuration &C);
  
  void deallocate ();

  unsigned short int get_N_valence_baryons () const
  {
    return N_valence_baryons;
  }

  void ground_state (
		     const unsigned int debut ,
		     const class array<class nlj_struct> &shells_qn);

  unsigned int N_baryon_fixed_type_determine (
					      const enum particle_type fixed_particle ,
					      const class array<class nlj_struct> &shells_qn) const;
  
  int strangeness_determine (const class array<class nlj_struct> &shells_qn) const;
  
  int charge_determine (const class array<class nlj_struct> &shells_qn) const;
  
  double Tz_determine (const class array<class nlj_struct> &shells_qn) const;
  
  int n_spec_determine (const class array<class nlj_struct> &shells_qn) const;
  
  bool is_spectator_occupation_OK_determine (const int strangeness_max , const class array<class nlj_struct> &shells_qn) const;
  
  int E_hw_determine (const class array<class nlj_struct> &shells_qn) const;

  TYPE E_determine (
		    const class nlj_table<TYPE> &h_basis ,
		    const class array<class nlj_struct> &shells_qn) const;

  int n_holes_determine (const class array<class nlj_struct> &shells_qn) const;
  
  int n_scat_determine (const class array<class nlj_struct> &shells_qn) const;

  unsigned int BP_determine (const class array<class nlj_struct> &shells_qn) const;

  unsigned int occupancy_determine (const unsigned int s) const;

  unsigned int shells_occupied_number_determine (const unsigned int N_nlj) const;

  int two_M_max_determine (const class array<class nlj_struct> &shells_qn) const;
  
  double M_max_determine (const class array<class nlj_struct> &shells_qn) const;

  void print (const class array<class nlj_struct> &shells_qn) const;

  void super_configuration_print (
				  const int lmax , 
				  const class array<class nlj_struct> &shells_qn) const;

  bool good_configuration (const class array<class nlj_struct> &shells_qn) const;

  bool all_frozen_states_occupied (const class array<class nlj_struct> &shells_qn) const;

  bool is_there_core_state (const class array<class nlj_struct> &shells_qn) const;
  
  const class configuration & operator = (const class configuration &X);
  
  const class configuration & operator = (const class virtual_configuration &X);

  unsigned short int & operator [] (const unsigned int i) const
  {
    return shells[i];
  }
 
  unsigned int index_search (
			     const unsigned int BP ,
			     const int S , 
			     const int n_spec , 
			     const int n_scat , 
			     const class array<unsigned int> &dimensions_configuration_set , 
			     const class array_of_configuration &configuration_set , 
			     class configuration &C_try) const;

  unsigned int index_search (
			     const unsigned int dimension , 
			     const unsigned int configuration_set_zero_index ,
			     const class array_of_configuration &configuration_set , 
			     class configuration &C_try) const;

  void excitation_1p (
		      const unsigned int shell_to_add , 
		      class configuration &C_result) const;
 
  void excitation_1h (
		      const unsigned int shell_to_remove , 
		      class configuration &C_result) const;
 
  void excitation_1p_1h (
			 const unsigned int shell_to_add , 
			 const unsigned int shell_to_remove , 
			 class configuration &C_result) const;

  void excitation_2p (
		      const unsigned int s0_to_add , 
		      const unsigned int s1_to_add , 
		      class configuration &C_result) const;

  void excitation_2h (
		      const unsigned int s0_to_remove , 
		      const unsigned int s1_to_remove , 
		      class configuration &C_result) const;

  void excitation_2p_1h (
			 const unsigned int s0_to_add , 
			 const unsigned int s1_to_add , 
			 const unsigned int s2_to_remove , 
			 class configuration &C_result) const;

  void excitation_1p_2h (
			 const unsigned int s0_to_add , 
			 const unsigned int s1_to_remove , 
			 const unsigned int s2_to_remove , 
			 class configuration &C_result) const;
 
  unsigned int shell_place_find (const unsigned int shell) const;

  unsigned int shell_to_add_place_find (const unsigned int shell) const;

  bool is_shell_occupied (const unsigned int shell) const;

  void get_SD_configuration (
			     const class array<class nljm_struct> &phi_table ,
			     const class Slater_determinant &SD);

  bool is_configuration_occupied (
				  const unsigned int N_nlj ,
				  const class configuration &C) const;
 
  bool is_it_in_new_space (
			   const class array<class nlj_struct> &old_shells_qn ,
			   const class array<class lj_table<int> > &new_nmax_lj_tabs ,
			   const class array<class nlj_table<bool> > &new_is_it_valence_shell_tabs) const;
  
  friend double used_memory_calc (const class configuration &T);
  
private:

  unsigned short int N_valence_baryons;
  
  unsigned short int *shells;
};

bool operator == (const class configuration &C1 , const class configuration &C2);
bool operator != (const class configuration &C1 , const class configuration &C2);

bool operator >  (const class configuration &C1 , const class configuration &C2);
bool operator >= (const class configuration &C1 , const class configuration &C2);

bool operator <  (const class configuration &C1 , const class configuration &C2);
bool operator <= (const class configuration &C1 , const class configuration &C2);




bool same_super_configuration (
			       const int lmax , 
			       const class array<class nlj_struct> &shells_qn , 
			       const class configuration &C1 , 
			       const class configuration &C2);

class configuration operator+ (
			       const class configuration &C1 ,
			       const class configuration &C2);

ostream & operator << (
		       ostream &os ,
		       const class configuration &C);

#endif


