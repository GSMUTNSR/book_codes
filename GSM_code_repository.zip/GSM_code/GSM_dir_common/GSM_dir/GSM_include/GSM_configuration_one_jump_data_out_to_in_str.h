#ifndef GSMCONFIGURATIONONEJUMPOUTTOINSTR_H
#define GSMCONFIGURATIONONEJUMPOUTTOINSTR_H


// TYPE is double or complex
// -------------------------

class configuration_one_jump_data_out_to_in_str
{
public:

  configuration_one_jump_data_out_to_in_str ();

  configuration_one_jump_data_out_to_in_str (
					     const unsigned int n_holes_in_c , 
					     const unsigned int n_scat_in_c , 
					     const unsigned int iC_in_c , 
					     const unsigned int C_eq_one_jump_index_c , 
					     const unsigned int C_in_shell_c , 
					     const unsigned int C_out_shell_c);

  void initialize (
		   const unsigned int n_holes_in_c ,
		   const unsigned int n_scat_in_c , 
		   const unsigned int iC_in_c , 
		   const unsigned int C_eq_one_jump_index_c , 
		   const unsigned int C_in_shell_c , 
		   const unsigned int C_out_shell_c);

  void initialize (const class configuration_one_jump_data_out_to_in_str &X);
  
  void allocate_fill (const class configuration_one_jump_data_out_to_in_str &X);
		   
  unsigned int get_n_holes_in () const
  {
    return n_holes_in;
  }
  
  unsigned int get_n_scat_in () const
  {
    return n_scat_in;
  }
  
  unsigned int get_C_eq_one_jump_index () const
  {
    return C_eq_one_jump_index;
  }
  
  unsigned int get_C_in_shell () const
  {
    return C_in_shell;
  }
  
  unsigned int get_C_out_shell () const
  {
    return C_out_shell;
  }  
  
  unsigned int get_iC_in () const
  {
    return iC_in;
  }
  
private:
  
  unsigned char n_holes_in; // number of holes of the in configuration
  
  unsigned char n_scat_in; // number of particles in the continuum of the in configuration

  unsigned int C_eq_one_jump_index; // equivalent configuration index for this jump (see GSM_configuration_one_jump_construction_set_out_to_in.cpp for the definition of the equivalent configuration for jumps)
  
  unsigned short int C_in_shell; // index of the in shell (alpha) in C[in]
  
  unsigned short int C_out_shell; // index of the out shell (beta) in C[out]
  
  unsigned int iC_in; // index of the C[in] configuration
};

double used_memory_calc (const class configuration_one_jump_data_out_to_in_str &T);

#endif


