#ifndef GSMSDONEJUMPJPMOUTTOIN_H
#define GSMSDONEJUMPJPMOUTTOIN_H

// TYPE is double or complex
// -------------------------

class SD_one_jump_data_Jpm_out_to_in_str
{
public:
  SD_one_jump_data_Jpm_out_to_in_str ();

  SD_one_jump_data_Jpm_out_to_in_str (
				      const unsigned int shell_index_c , 
				      const unsigned int im_in_c , 
				      const unsigned int Delta_iM_in_c , 
				      const unsigned int inSD_index_c , 
				      const unsigned int bin_phase_c);
  
  void initialize (
		   const unsigned int shell_index_c , 
		   const unsigned int im_in_c , 
		   const unsigned int Delta_iM_in_c , 
		   const unsigned int inSD_index_c , 
		   const unsigned int bin_phase_c);

  void initialize (const class SD_one_jump_data_Jpm_out_to_in_str &X);
  
  void allocate_fill (const class SD_one_jump_data_Jpm_out_to_in_str &X);
  
  unsigned int get_shell_index () const
  {
    return shell_index;
  }

  unsigned int get_im_in () const
  {
    return im_in;
  }

  unsigned int get_Delta_iM_in () const
  {
    return Delta_iM_in;
  }

  unsigned int get_inSD_index () const
  {
    return inSD_index;
  }

  unsigned int get_bin_phase () const
  {
    return bin_phase;
  }


private:
  
  unsigned short int shell_index; // shell associate to the alpha and beta states
  
  unsigned char im_in; // shifted m quantum number m[in] + m[max] of the alpha state
  
  unsigned char Delta_iM_in; // coded difference of M quantum numbers, equal to 0 for J+ and 1 for J-
  
  unsigned int inSD_index; // index of inSD for a fixed configuration
  
  unsigned char bin_phase; // binary phase arising from a+_{alpha} a_{beta}
};

double used_memory_calc (const class SD_one_jump_data_Jpm_out_to_in_str &T);

#endif
