#ifndef GSMSD1PHDATASTR_H
#define GSMSD1PHDATASTR_H

// TYPE is double or complex
// -------------------------


class SD_1ph_data_str
{ 
public:
  SD_1ph_data_str ();

  SD_1ph_data_str (
		   const unsigned int C_1ph_table_index_c , 
		   const unsigned int im_c , 
		   const unsigned int SD_index_c , 
		   const unsigned int bin_phase_c); 

  void initialize (
		   const unsigned int C_1ph_table_index_c , 
		   const unsigned int im_c , 
		   const unsigned int SD_index_c , 
		   const unsigned int bin_phase_c); 
  
  void initialize (const class SD_1ph_data_str &X);
		   
  unsigned int get_C_1ph_table_index () const
  {
    return C_1ph_table_index;
  }
  
  unsigned int get_im () const
  {
    return im;
  }

  unsigned int get_SD_index () const
  {
    return SD_index;
  }

  unsigned int get_bin_phase () const
  {
    return bin_phase;
  }

private:
  
  unsigned int C_1ph_table_index; // index of 1p-1h configuration jump
  
  unsigned char im; // m[alpha] + m[max] so that it is an integer
  
  unsigned int SD_index; // the index of SD after the jump
  
  unsigned char bin_phase; // binary phase induced by a+/a operators
};

double used_memory_calc (const class SD_1ph_data_str &T);


#endif
