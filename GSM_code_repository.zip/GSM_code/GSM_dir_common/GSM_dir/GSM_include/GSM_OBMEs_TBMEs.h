#ifndef GSMOBMESTBMES_H
#define GSMOBMESTBMES_H

// TYPE is double or complex
// -------------------------

namespace OBMEs_TBMEs
{
  namespace HO_wfs
  {
    void r2_tab_calc (
		      const class interaction_class &inter_data , 
		      class array<TYPE> &r2_HO_tab);

    void reduced_r_grad_tables_calc (
				     const class interaction_class &inter_data , 
				     class array<TYPE> &reduced_grad_HO_tab , 
				     class array<TYPE> &reduced_r_HO_tab);

    void reduced_r_grad_tables_calc (
				     const class baryons_data &particles_data ,
				     class array<TYPE> &reduced_grad_HO_tab , 
				     class array<TYPE> &reduced_r_HO_tab);

    void multipole_OBMEs_calc (
			       const class interaction_class &inter_data , 
			       class OBMEs_multipole_square_str &OBMEs_multipole_square ,
			       class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced);
    
    void multipole_OBMEs_alloc_calc (
				     const bool is_it_HO_expansion , 
				     class baryons_data &particles_data);
    
    void OBMEs_alloc_calc (
			   const class interaction_class &inter_data ,
			   const double lambda_Hcm , 
			   class baryons_data &particles_data);

    void reduced_r_grad_multipole_tables_alloc_calc (
						     const class interaction_class &inter_data , 
						     class baryons_data &particles_data);
    
    void OBMEs_alloc_calc (
			   const class input_data_str &input_data , 
			   const class interaction_class &inter_data , 
			   class baryons_data &particles_data);

    void OBMEs_prot_neut_alloc_calc (
				     const class input_data_str &input_data , 
				     const class interaction_class &inter_data ,
				     class baryons_data &prot_Y_data , 
				     class baryons_data &neut_Y_data);
  }
  
  namespace standard_HO_SM    
  {
    void hp_hn_read_calc (
			  const enum space_type space , 
			  const double SPE_coefficient , 
			  class baryons_data &particles_data , 
			  ifstream &fitted_interaction_file);

    void JT_TBME_tables_h_basis_calc (
				      const enum space_type space , 
				      const double SPE_coefficient , 
				      const double TBME_coefficient , 
				      const string file_name , 
				      class baryons_data &prot_Y_data , 
				      class baryons_data &neut_Y_data , 
				      class array<class JT_coupled_TBME> &JT_TBME_table);
    
    void hp_hn_JT_TBME_tables_MPI_transfer (
					    const enum space_type space , 
					    class baryons_data &prot_Y_data , 
					    class baryons_data &neut_Y_data , 
					    const class array<class array<JT_coupled_TBME> > &JT_TBME_tables);

    void h_basis_alloc_fill (class baryons_data &particles_data);

    void TBMEs_alloc_calc (
			   const bool is_there_cout_detailed , 
			   const class input_data_str &input_data , 
			   const class array<class array<class JT_coupled_TBME> > &JT_TBME_tables , 
			   class baryons_data &particles_data);
    
    void h_JT_TBMEs_alloc_fill (
				const bool is_there_cout , 
				const class input_data_str &input_data ,
				class array<double> &SPE_coefficients ,
				class array<double> &TBME_coefficients , 
				class array<string> &file_names , 
				class baryons_data &prot_Y_data ,
				class baryons_data &neut_Y_data , 
				class array<class array<class JT_coupled_TBME> > &JT_TBME_tables);
  }

  namespace Berggren
  {
    void h_basis_alloc_calc (
			     const class interaction_class &inter_data ,
			     const bool is_there_cout_detailed , 
			     const class baryons_data &neut_Y_data_like ,
			     class baryons_data &particles_data);
    
    void h_basis_prot_neut_alloc_calc (
				       const enum space_type basis_space ,
				       const class interaction_class &inter_data ,
				       const bool is_there_cout_detailed , 
				       class baryons_data &prot_Y_data , 
				       class baryons_data &neut_Y_data);
    void coupled_OBMEs_inter_calc ( 
				   const enum interaction_type Op_inter ,
				   const bool OBMEs_inter_read ,
				   const double lambda_Hcm ,
				   const bool copy_J_OBMEs_TBMEs , 
				   const class interaction_class &inter_data , 
				   const class baryons_data &neut_Y_data_like , 
				   const class baryons_data &particles_data ,
				   class array<TYPE> &coupled_OBMEs);
 
    void reduced_r_grad_multipole_tables_alloc_calc (
						     const bool is_it_only_basis ,
						     const class interaction_class &inter_data , 
						     class baryons_data &particles_data);

    void OBMEs_inter_alloc_calc (
				 const bool is_it_only_basis , 
				 const class input_data_str &input_data , 
				 const class interaction_class &inter_data , 
				 const class baryons_data &neut_Y_data_like , 
				 class baryons_data &particles_data);
    
    void OBMEs_CM_multipole_operators_alloc_calc (
						  const bool is_it_only_basis , 
						  const class interaction_class &inter_data , 
						  const class baryons_data &neut_Y_data_like , 
						  class baryons_data &particles_data);
    
    void TBMEs_alloc_calc (
			   const bool is_there_cout_detailed , 
			   const bool is_it_only_basis , 
			   const class input_data_str &input_data , 
			   const class interaction_class &inter_data , 
			   class baryons_data &particles_data);
    
    void coupled_OBMEs_CM_calc_rms_radius_init (
						const bool is_it_only_basis , 
						const enum operator_type Op , 
						const bool is_it_HO_expansion , 
						const bool copy_J_OBMEs_TBMEs , 
						const class interaction_class &inter_data , 
						const class baryons_data &neut_Y_data_like , 
						const class array<TYPE> &r2_HO_tab , 
						class baryons_data &particles_data);
 
    void reduced_r_grad_R_cut_set_calc (
					const class baryons_data &particles_data , 
					class array<TYPE> &reduced_grad_table , 
					class array<TYPE> &reduced_r_table);
    
    void multipole_OBMEs_R_cut_alloc_calc (class baryons_data &particles_data);
    
    void calc_WS_derivative (
			     const enum FHT_EFT_parameter_type FHT_EFT_parameter , 
			     const bool is_there_l_dependence , 
			     const int l_WS , 
			     const double A_dependent_factor_core_potential ,
			     class baryons_data &particles_data);

    void read_OBMEs_from_file (
			       const enum interaction_type Op_inter , 
			       const class baryons_data &particles_data , 
			       class array<TYPE> &coupled_OBMEs);
  }

  void coupled_OBMEs_CM_rms_radius_calc (
					 const enum operator_type rms_radius_operator ,
					 const bool is_it_HO_expansion , 
					 const class input_data_str &input_data , 
					 const int N_particle ,
					 class baryons_data &particles_data);
    
  void reduced_r_grad_tables_CM_set_alloc_calc_rms_radius_init (
								const bool is_it_HO_expansion , 
								const class interaction_class &inter_data , 
								const class array<TYPE> &reduced_grad_table , 		
								const class array<TYPE> &reduced_r_table ,
								class baryons_data &particles_data);

  void reduced_r_rms_radius_tables_CM_set_calc (
						const enum operator_type rms_radius_operator ,
						const bool is_it_HO_expansion , 
						const class input_data_str &input_data , 
						const int N_particle ,
						class baryons_data &particles_data);
 
  void reduced_r_grad_HO_expansion_calc (
					 const bool is_it_only_basis ,
					 const class interaction_class &inter_data , 
					 const class baryons_data &particles_data , 
					 class array<TYPE> &reduced_grad_table , 
					 class array<TYPE> &reduced_r_table);

  void multipole_OBMEs_HO_expansion_alloc_calc (
						const bool is_it_only_basis ,
						const class interaction_class &inter_data , 
						class baryons_data &particles_data);
 
  void OBMEs_alloc_calc (
			 const bool is_there_cout_detailed , 
			 const bool is_it_only_basis , 
			 const class input_data_str &input_data , 
			 const class interaction_class &inter_data , 
			 const class baryons_data &neut_Y_data_like ,  
			 class baryons_data &particles_data);
  
  void TBMEs_alloc_calc (
			 const bool is_there_cout_detailed , 
			 const bool is_it_only_basis , 
			 const class input_data_str &input_data , 
			 const class interaction_class &inter_data , 
			 const class array<class array<class JT_coupled_TBME> > &JT_TBME_tables ,
			 class baryons_data &particles_data);

  void TBMEs_pn_alloc_calc (
			    const bool is_there_cout , 
			    const bool is_it_only_basis , 
			    const class array<class array<class JT_coupled_TBME> > &JT_TBME_tables , 
			    const class interaction_class &inter_data , 
			    const class input_data_str &input_data , 
			    const class baryons_data &prot_Y_data , 
			    const class baryons_data &neut_Y_data , 
			    class TBMEs_class &TBMEs_pn);

  void OBMEs_TBMEs_alloc_calc (
			       const bool is_there_cout , 
			       const bool is_it_only_basis , 
			       const class input_data_str &input_data , 
			       const class interaction_class &inter_data_basis , 
			       const class interaction_class &inter_data , 
			       const class array<class array<class JT_coupled_TBME> > &JT_TBME_tables , 
			       const class baryons_data &neut_Y_data_like , 
			       class baryons_data &particles_data);
 
  void TBMEs_cv_alloc_calc (
			    const bool is_there_cout , 
			    const class interaction_class &inter_data , 
			    const class input_data_str &input_data , 
			    const class baryons_data &prot_Y_data , 
			    const class baryons_data &neut_Y_data , 
			    class TBMEs_class &TBMEs_cv);
 
  void all_OBMEs_TBMEs_alloc_calc (
				   const bool is_there_cout_detailed , 
				   const bool is_it_only_basis , 
				   const class array<class array<class JT_coupled_TBME> > &JT_TBME_tables ,
				   const class interaction_class &inter_data_basis , 
				   const class interaction_class &inter_data , 
				   const class input_data_str &input_data , 
				   class baryons_data &prot_Y_data , 
				   class baryons_data &neut_Y_data , 
				   class TBMEs_class &TBMEs_pn , 
				   class TBMEs_class &TBMEs_cv);
}

#endif


