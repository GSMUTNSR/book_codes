#ifndef GSMINTERACTIONCLASS_H
#define GSMINTERACTIONCLASS_H


// TYPE is double or complex
// -------------------------

// TBME means two-body matrix element
// ----------------------------------




// Class storing interaction parameters, simple function related to interaction and interaction TBMEs in HO basis or Gamow-Hartree Fock basis with the Qbox method
// ---------------------------------------------------------------------------------------------------------------------------------------------------------------

class interaction_class
{
public:
  
  // Constructors, destructors, allocation and deallocation
  // ------------------------------------------------------

  interaction_class ();
  
  interaction_class (	  
		     const bool is_there_cout_c , 
		     const bool is_it_only_basis_c ,
		     const bool is_it_Coulomb , 
		     const class input_data_str &input_data);

  interaction_class (const class interaction_class &X);

  ~interaction_class ();
 
  void allocate (
		 const bool is_there_cout_c , 
		 const bool is_it_only_basis_c , 
		 const bool is_it_Coulomb , 
		 const class input_data_str &input_data);

  void allocate_fill (const class interaction_class &X);

  void deallocate ();

  // Simple routines providing with the value of private variables
  // -------------------------------------------------------------
  
  enum interaction_type get_TBME_inter () const
  {
    return TBME_inter;
  }
  
  enum interaction_read_type get_inter_read () const
  {
    return inter_read;
  }
    
  double get_a () const
  {
    return a;
  }

  double get_b () const
  {
    return b;
  }

  double get_V_SDI () const
  {
    return V_SDI;
  }

  double get_R0 () const
  {
    return R0;
  }

  double get_mu () const
  {
    return mu;
  }

  double get_b_lab () const
  {
    return b_lab;
  }

  double get_b_relative () const
  {
    return b_relative;
  }

  int get_lmax_for_interaction () const
  {
    return lmax_for_interaction;
  }

  int get_lmax_multipole_expansion () const
  {
    return lmax_multipole_expansion;
  }

  unsigned int get_BPmin_global_pp () const
  {
    return BPmin_global_pp;
  }

  unsigned int get_BPmax_global_pp () const
  {
    return BPmax_global_pp;
  }

  int get_Jmin_global_pp () const
  {
    return Jmin_global_pp;
  }

  int get_Jmax_global_pp () const
  {
    return Jmax_global_pp;
  }

  unsigned int get_BPmin_global_nn () const
  {
    return BPmin_global_nn;
  }

  unsigned int get_BPmax_global_nn () const
  {
    return BPmax_global_nn;
  }

  int get_Jmin_global_nn () const
  {
    return Jmin_global_nn;
  }

  int get_Jmax_global_nn () const
  {
    return Jmax_global_nn;
  }

  unsigned int get_BPmin_global_pn () const
  {
    return BPmin_global_pn;
  }

  unsigned int get_BPmax_global_pn () const
  {
    return BPmax_global_pn;
  }

  int get_Jmin_global_pn () const
  {
    return Jmin_global_pn;
  }

  int get_Jmax_global_pn () const
  {
    return Jmax_global_pn;
  }

  unsigned int get_BPmin_global () const
  {
    return BPmin_global;
  }

  unsigned int get_BPmax_global () const
  {
    return BPmax_global;
  }

  int get_Jmin_global () const
  {
    return Jmin_global;
  }

  int get_Jmax_global () const
  {
    return Jmax_global;
  }
  
  unsigned int get_N_nlj_HO () const
  {
    return shells_HO_qn.dimension (0);
  }

  unsigned int get_N_nlj_inter () const
  {
    return shells_inter_qn.dimension (0);
  }
  
  const class array<int> & get_nmax_HO_lab_tab () const
  {
    return nmax_HO_lab_tab;
  }
    
  const class array<class nlj_struct> & get_shells_HO_qn () const
  {
    return shells_HO_qn;
  }

  const class nlj_table<unsigned int> & get_shells_HO_indices () const
  {
    return shells_HO_indices;
  }

  const class array<class nlj_table<unsigned int> > & get_shells_HO_indices_p_tab () const
  {
    return shells_HO_indices_p_tab;
  }
  
  const class array<class nlj_table<unsigned int> > & get_shells_HO_indices_n_tab () const
  {
    return shells_HO_indices_n_tab;
  }
  
  const array<class array<unsigned int> > & get_shells_HO_indices_from_nlj_indices_p_tab () const
  {
    return shells_HO_indices_from_nlj_indices_p_tab;
  }
  
  const array<class array<unsigned int> > & get_shells_HO_indices_from_nlj_indices_n_tab () const
  {
    return shells_HO_indices_from_nlj_indices_n_tab;
  }

  const class array<int> & get_nmax_inter_lab_tab () const
  {
    return nmax_inter_lab_tab;
  }
  
  const class array<class nlj_struct> & get_shells_inter_qn () const
  {
    return shells_inter_qn;
  }

  const class array<class nlj_table<unsigned int> > & get_shells_inter_indices_p_tab () const
  {
    return shells_inter_indices_p_tab;
  }
  
  const class array<class nlj_table<unsigned int> > & get_shells_inter_indices_n_tab () const
  {
    return shells_inter_indices_n_tab;
  }
  
  const class array<class array<unsigned int> > & get_shells_inter_indices_from_nlj_indices_p_tab () const
  {
    return shells_inter_indices_from_nlj_indices_p_tab;
  }
  
  const class array<class array<unsigned int> > & get_shells_inter_indices_from_nlj_indices_n_tab () const
  {
    return shells_inter_indices_from_nlj_indices_n_tab;
  }

  const class TBMEs_class & get_TBMEs_pp_inter_lab () const
  {
    return TBMEs_pp_inter_lab;
  }
  
  const class TBMEs_class & get_TBMEs_nn_inter_lab () const
  {
    return TBMEs_nn_inter_lab;
  }
  
  const class TBMEs_class & get_TBMEs_pn_inter_lab () const
  {
    return TBMEs_pn_inter_lab;
  }
  
  const class TBMEs_class & get_TBMEs_cv_inter_lab () const
  {
    return TBMEs_cv_inter_lab;
  }
  
  const class array<double> & get_Vl_SGI_tab_GL () const
  {
    return Vl_SGI_tab_GL;
  }
  
  const class array<double> & get_V_Gaussian_consts () const
  {
    return V_Gaussian_consts;
  }

  const class array<double> & get_r_bef_R_tab_GL () const
  {
    return r_bef_R_tab_GL;
  }

  const class array<double> & get_w_bef_R_tab_GL () const
  {
    return w_bef_R_tab_GL;
  }

  const class array<double> & get_HO_wfs_bef_R_tab_GL () const
  {
    return HO_wfs_bef_R_tab_GL;
  }

  const class array<double> & get_HO_dwfs_bef_R_tab_GL () const
  {
    return HO_dwfs_bef_R_tab_GL;
  }

  const class array<double> & get_r_aft_R_tab_GL () const
  {
    return r_aft_R_tab_GL;
  }

  const class array<double> & get_w_aft_R_tab_GL () const
  {
    return w_aft_R_tab_GL;
  }

  const class array<double> & get_HO_wfs_aft_R_tab_GL () const
  {
    return HO_wfs_aft_R_tab_GL;
  }

  const class array<double> & get_HO_dwfs_aft_R_tab_GL () const
  {
    return HO_dwfs_aft_R_tab_GL;
  }

  const class array<double> & get_r_bef_R_tab_GL_SGI_MSGI () const
  {
    return r_bef_R_tab_GL_SGI_MSGI;
  }

  const class array<double> & get_w_bef_R_tab_GL_SGI_MSGI () const
  {
    return w_bef_R_tab_GL_SGI_MSGI;
  }

  const class array<double> & get_HO_wfs_bef_R_tab_GL_SGI_MSGI () const
  {
    return HO_wfs_bef_R_tab_GL_SGI_MSGI;
  }

  const class array<double> & get_HO_dwfs_bef_R_tab_GL_SGI_MSGI () const
  {
    return HO_dwfs_bef_R_tab_GL_SGI_MSGI;
  }

  const class array<class vector_class<complex<double> > > & get_HO_overlaps_Fermi () const
  {
    return HO_overlaps_Fermi;
  }

  const class array<class lj_table<class matrix<complex<double> > > > & get_V_Coulomb_HO_basis_tab () const
  {
    return V_Coulomb_HO_basis_tab;
  }

  void zero ();

  double Gaussian_coupling_constant (
				     const unsigned int bp , 
				     const int J , 
				     const bool is_it_pn_direct , 
				     const bool is_it_pn_exchange) const;

  void TBMEs_HO_Coulomb_lab_add (const int Jc_relative_max);

  void TBMEs_HO_three_body_like_NN_add ();
  
  void TBMEs_HO_lab_no_added_kinetic_part (
					   const bool is_there_Coulomb , 
					   const int Jn_relative_max , 
					   const int Jc_relative_max ,
					   const double TBME_A_dependent_factor);
  
  void copy_disk (const string file_name) const;
  
  void add_weighted_TBMEs_NN (
			      const double V_parameter ,
			      const class interaction_class &unit_interaction);

  void add_weighted_TBMEs_NN_YN_YY_nuclear (
					    const double V_parameter ,
					    const class interaction_class &unit_interaction);
  
  void add_weighted_TBMEs_NN_YN_YY_Coulomb (const class interaction_class &inter_data_Coulomb);

  void calculate_from_units_Coulomb_kinetic (
					     const double frozen_core_mass , 
					     const class vector_class<double> &FHT_EFT_parameters , 
					     const double TBME_A_dependent_factor , 
					     const class array<class interaction_class> &inter_data_units , 
					     const class interaction_class &inter_data_Coulomb);

  void calculate_grad_from_units (
				  const class array<class interaction_class> &inter_data_units , 
				  const double TBME_A_dependent_factor , 
				  const enum FHT_EFT_parameter_type FHT_EFT_parameter);

  void calculate_unit (
		       const int Jn_relative_max , 
		       const enum FHT_EFT_parameter_type FHT_EFT_parameter);

  bool is_it_filled () const;

  unsigned int n_relative_max_determine () const;

  void inter_data_calc (const class input_data_str &input_data);

  void SGI_radial_tables_calc ();

  void TBMEs_real_inter_HO_relative_NN_calc (
					     class array<TYPE> &TBMEs_pp_HO_relative , 
					     class array<TYPE> &TBMEs_nn_HO_relative , 
					     class array<TYPE> &TBMEs_pn_HO_relative) const;

  void TBMEs_Coulomb_HO_relative_NN_calc (class array<TYPE> &TBMEs_pp_HO_relative_Coulomb) const;

  void V_Coulomb_HO_basis_tab_calc (const class input_data_str &input_data);
  
  friend double used_memory_calc (const class interaction_class &T);

private:
  
  class TBMEs_class & TBMEs_inter_lab_determine (
						 const bool is_pp_here ,
						 const bool is_nn_here ,
						 const bool is_pn_here ,
						 const bool is_cv_here);
  
  const class TBMEs_class & TBMEs_inter_lab_determine (
						       const bool is_pp_here ,
						       const bool is_nn_here ,
						       const bool is_pn_here ,
						       const bool is_cv_here) const;
  
  void HO_radial_tables_calc (
			      const double R , 
			      const double R_real_max);

  void local_potential_HO_basis_calc (
				      const enum potential_type H_potential , 
				      const int ZYval_charge_potential_pos , 
				      const int ZYval_charge_potential_neg , 
				      const double R_charge);

  void local_potential_HO_basis_complex_scaled_calc (
						     const enum potential_type H_potential , 
						     const int ZYval_charge_potential_pos , 
						     const int ZYval_charge_potential_neg , 
						     const double R_charge);
  
  void HO_overlaps_Fermi_calc (
			       const double R_cut_function ,
			       const double d_cut_function);  
  
  void TBMEs_HO_relative_NN_read (
				  class array<double> &TBMEs_pp_HO_relative ,
				  class array<double> &TBMEs_nn_HO_relative ,
				  class array<double> &TBMEs_pn_HO_relative) const;
  
  void TBMEs_HO_relative_NN_YN_YY_read (class array<class array<double> > &TBMEs_HO_relative_tab) const;
  
  void TBMEs_Bessel_NN_read (      
			     class array<double> &TBMEs_pp_k_relative ,
			     class array<double> &TBMEs_nn_k_relative ,
			     class array<double> &TBMEs_pn_k_relative) const;

  void TBMEs_Bessel_NN_YN_YY_read (class array<class array<double> > &TBMEs_k_relative_tab) const;
  
  void TBMEs_HO_relative_calc_from_Bessel_NN_read (
						   class array<double> &TBMEs_pp_HO_relative ,
						   class array<double> &TBMEs_nn_HO_relative ,
						   class array<double> &TBMEs_pn_HO_relative) const;

  void TBMEs_HO_relative_calc_from_Bessel_NN_YN_YY_read (class array<class array<double> > &TBMEs_HO_relative_tab) const;
    
  void HO_overlaps_relative_calc_H_complex_scaled (class array<TYPE> &HO_relative_overlaps_H_complex_scaled) const;

  void TBMEs_HO_relative_complex_scaled_NN_calc (
						 const class array<TYPE> &HO_relative_overlaps_H_complex_scaled ,
						 const class array<double> &TBMEs_HO_relative_double , 
						 class array<TYPE> &TBMEs_HO_relative) const;

  void TBMEs_ALS_HO_relative_complex_scaled_calc (
						  const class array<TYPE> &HO_relative_overlaps_H_complex_scaled ,
						  const class array<double> &TBMEs_ALS_HO_relative_double , 
						  class array<TYPE> &TBMEs_ALS_HO_relative) const;

  void TBMEs_HO_relative_complex_scaled_NN_YN_YY_calc (
						       const class array<TYPE> &HO_relative_overlaps_H_complex_scaled ,
						       const class array<class array<double> > &TBMEs_HO_relative_double_tab , 
						       class array<class array<TYPE> > &TBMEs_HO_relative_tab) const;
  
  void TBMEs_Minnesota_HO_relative_NN_calc(class array<TYPE> &TBMEs_HO_relative) const;

  void TBMEs_FHT_HO_relative_NN_calc (
				      class array<TYPE> &TBMEs_HO_relative ,
				      class array<TYPE> &TBMEs_ALS_HO_relative) const;
  
  void TBMEs_real_inter_HO_relative_NN_YN_YY_calc (class array<class array<TYPE> > &TBMEs_HO_relative_tab) const;
  
  bool is_there_baryonic_abcd_determine (
					 const bool is_there_baryonic ,
					 const unsigned int a ,
					 const unsigned int b , 
					 const unsigned int c ,
					 const unsigned int d ,
					 const unsigned int bp , 
					 const int J) const;
    
  void TBMEs_baryons_from_TBMEs_NN_SU3f_coupling_constants_add (
								const bool is_it_ALS , 
								const unsigned int a ,
								const unsigned int b , 
								const unsigned int c ,
								const unsigned int d ,
								const int Jmax_ab ,
								const int Jmax_cd ,
								const unsigned int bp , 
								const int J , 
								const bool is_lrel_S_ab_symmetric ,      
								const bool is_lrel_S_cd_symmetric ,
								const class array<double> &CGs_T_baryons ,
								const TYPE TBME_HO_lab);
  
  bool is_there_Coulomb_abcd_determine (
					const bool is_there_Coulomb ,
					const unsigned int a ,
					const unsigned int b , 
					const unsigned int c ,
					const unsigned int d ,
					const unsigned int bp , 
					const int J) const;

  void Coulomb_TBMEs_baryons_from_TBMEs_baryons_plus_charges_add (
								  const unsigned int a ,
								  const unsigned int b , 
								  const unsigned int c ,
								  const unsigned int d ,
								  const int Jmax_ab ,
								  const int Jmax_cd ,
								  const unsigned int bp , 
								  const int J , 
								  const TYPE TBME_same_baryons_plus_charges ,
								  const TYPE TBME_diff_baryons_plus_charges);
  
  TYPE TBME_abcd_Coulomb_lab_NN_calc (
				      const int Jc_relative_max , 
				      const int J , 
				      const unsigned int a , 
				      const unsigned int b , 
				      const unsigned int c , 
				      const unsigned int d , 
				      const class array<class Moshinsky_table> &Moshinsky_tables , 
				      const class array<double> &three_js_recoupling_table , 
				      const class array<double> &four_js_recoupling_table , 
				      const class array<TYPE> &TBMEs_pp_HO_relative_Coulomb) const;
  
  void TBMEs_abcd_Coulomb_lab_NN_YN_YY_calc (
					     const int Jc_relative_max , 
					     const int J ,
					     const unsigned int a ,
					     const unsigned int b , 
					     const unsigned int c ,
					     const unsigned int d , 
					     const class array<class Moshinsky_table> &Moshinsky_tables , 
					     const class array<double> &three_js_recoupling_table , 
					     const class array<double> &four_js_recoupling_table , 
					     const class array<TYPE> &TBMEs_pp_HO_relative_Coulomb ,
					     TYPE &TBME_same_baryons_plus_charges ,
					     TYPE &TBME_diff_baryons_plus_charges);
  
  void TBMEs_abcd_real_inter_NN_lab_calc (
					  const int Jn_relative_max , 
					  const int J , 
					  const unsigned int a , 
					  const unsigned int b , 
					  const unsigned int c , 
					  const unsigned int d , 
					  const class array<class Moshinsky_table> &Moshinsky_tables , 
					  const class array<double> &three_js_recoupling_table , 
					  const class array<double> &four_js_recoupling_table , 
					  const class array<TYPE> &TBMEs_pp_HO_relative , 
					  const class array<TYPE> &TBMEs_nn_HO_relative , 
					  const class array<TYPE> &TBMEs_pn_HO_relative ,
					  TYPE &TBME_pp ,
					  TYPE &TBME_nn ,
					  TYPE &TBME_pn) const;
  
  TYPE TBME_abcd_real_inter_NN_YN_YY_lab_calc (
					       const enum particle_type Ba ,
					       const enum particle_type Bb ,
					       const enum particle_type Bc ,
					       const enum particle_type Bd ,
					       const int Jn_relative_max , 
					       const int J , 
					       const unsigned int a ,
					       const unsigned int b , 
					       const unsigned int c ,
					       const unsigned int d , 
					       const class array<class Moshinsky_table> &Moshinsky_tables , 
					       const class array<double> &three_js_recoupling_table , 
					       const class array<double> &four_js_recoupling_table , 
					       const class array<TYPE> &TBMEs_HO_relative);
  
  void TBMEs_abcd_good_T_NN_lab_calc (
				      const int Jn_relative_max , 
				      const int J , 
				      const unsigned int a , 
				      const unsigned int b , 
				      const unsigned int c , 
				      const unsigned int d , 
				      const class array<class Moshinsky_table> &Moshinsky_tables , 
				      const class array<double> &three_js_recoupling_table , 
				      const class array<double> &four_js_recoupling_table , 
				      const class array<TYPE> &TBMEs_HO_relative , 
				      TYPE &TBME_T0 , 
				      TYPE &TBME_T1) const;

  void TBMEs_abcd_ALS_calc (
			    const int Jn_relative_max , 
			    const int J , 
			    const unsigned int a , 
			    const unsigned int b , 
			    const unsigned int c , 
			    const unsigned int d , 
			    const class array<class Moshinsky_table> &Moshinsky_tables , 
			    const class array<double> &three_js_recoupling_table , 
			    const class array<double> &four_js_recoupling_table ,
			    const class array<TYPE> &TBMEs_ALS_HO_relative ,
			    TYPE &TBME_ALS_lrel_S_ab_symmetric ,
			    TYPE &TBME_ALS_lrel_S_cd_symmetric) const;
  
  void TBMEs_HO_lab_no_added_kinetic_part_from_relative_TBMEs_NN (
								  const bool is_there_baryonic , 
								  const bool is_there_Coulomb , 
								  const int Jn_relative_max , 
								  const int Jc_relative_max , 
								  const class array<TYPE> &TBMEs_pp_HO_relative_Coulomb , 
								  const class array<TYPE> &TBMEs_pp_HO_relative_nuclear , 
								  const class array<TYPE> &TBMEs_nn_HO_relative , 
								  const class array<TYPE> &TBMEs_pn_HO_relative);
  
  void TBMEs_real_inter_HO_lab_no_added_kinetic_part_from_relative_TBMEs_NN_YN_YY (
										   const bool is_there_Coulomb , 
										   const int Jn_relative_max , 
										   const int Jc_relative_max , 
										   const class array<TYPE> &TBMEs_pp_HO_relative_Coulomb , 
										   const class array<class array<TYPE> > &TBMEs_HO_relative_tab);
  
  void TBMEs_HO_lab_no_added_kinetic_part_from_good_T_relative_TBMEs_NN_YN_YY (
									       const bool is_there_baryonic , 
									       const bool is_there_Coulomb , 
									       const int Jn_relative_max , 
									       const int Jc_relative_max ,
									       const class array<TYPE> &TBMEs_pp_HO_relative_Coulomb , 
									       const class array<TYPE> &TBMEs_HO_relative , 
									       const class array<TYPE> &TBMEs_ALS_HO_relative);

  void radial_three_body_like_HO_calc (class array<double> &radial_three_body_like) const;
  
  void reduced_grad_set_HO_calc (
				 const double nucleus_mass , 
				 class array<double> &reduced_grad_P2) const;
  
  void TBMEs_HO_lab_add_kinetic_part_NN (
					 const bool is_it_COSM , 
					 const double nucleus_mass);

  void TBMEs_HO_lab_remove_kinetic_part_NN (
					    const bool is_it_COSM , 
					    const double nucleus_mass);
  
  void TBMEs_HO_lab_add_kinetic_part_NN_YN_YY (
					       const bool is_it_COSM ,
					       const double nucleus_mass);
  
  void TBMEs_HO_lab_remove_kinetic_part_NN_YN_YY (
						  const bool is_it_COSM ,
						  const double nucleus_mass);
  
  void TBMEs_HO_lab_add_kinetic_part (
				      const bool is_it_COSM ,
				      const double nucleus_mass);
  
  void TBMEs_HO_lab_remove_kinetic_part (
					 const bool is_it_COSM ,
					 const double nucleus_mass);

  void kinetic_part_TBMEs_NN_YN_YY_from_recoil_TBMEs_add (
							  const bool is_it_COSM ,
							  const unsigned int a ,
							  const unsigned int b , 
							  const unsigned int c ,
							  const unsigned int d ,
							  const int Jmax_ab ,
							  const int Jmax_cd ,
							  const unsigned int bp , 
							  const int J , 
							  const TYPE recoil_TBME_same_baryons ,
							  const TYPE recoil_TBME_diff_baryons);
  
  void kinetic_part_TBMEs_NN_YN_YY_from_recoil_TBMEs_remove (
							     const bool is_it_COSM ,
							     const unsigned int a ,
							     const unsigned int b , 
							     const unsigned int c ,
							     const unsigned int d ,
							     const int Jmax_ab ,
							     const int Jmax_cd ,
							     const unsigned int bp , 
							     const int J , 
							     const TYPE recoil_TBME_same_baryons ,
							     const TYPE recoil_TBME_diff_baryons);
  
  void TBMEs_HO_lab_NN_read_add (const string TBMEs_HO_lab_file_name , const double V_parameter);
  
  void TBMEs_HO_lab_NN_YN_YY_read_add (const string TBMEs_HO_lab_file_name , const double V_parameter);
  
  void TBMEs_GHF_lab_NN_fixed_Tz_read_add (const int Tz , class TBMEs_class &TBMEs_GHF_lab);
  
  void TBMEs_GHF_lab_NN_YN_YY_read_add ();
  
  void TBMEs_HO_lab_T0_T1_NN_EFT_read_add (const string TBMEs_HO_lab_file_name , const double V_parameter);
  
  void TBMEs_HO_lab_T0_T1_NN_YN_YY_EFT_read_add (const bool is_it_ALS , const string TBMEs_HO_lab_file_name , const double V_parameter);
  
  void TBMEs_HO_lab_EFT_read_add ();
  
  void TBMEs_HO_lab_no_added_kinetic_part_from_good_T_relative_TBMEs_NN_YN_YY (
									       const bool is_there_baryonic , 
									       const bool is_there_Coulomb , 
									       const int Jn_relative_max , 
									       const int Jc_relative_max ,
									       const class array<TYPE> &TBMEs_pp_HO_relative_Coulomb , 
									       const class array<TYPE> &TBMEs_HO_relative ,
									       const class array<class array<TYPE> > &TBMEs_HO_relative_tab , 
									       const class array<TYPE> &TBMEs_ALS_HO_relative);
  
  void TBMEs_pn_diagonalization_test (const double lambda_Hcm) const;
  
  void copy_disk_NN (const string file_name) const;

  void copy_disk_NN_YN_YY (const string file_name) const;

  bool is_it_only_basis;                 // true if one uses the interaction for the calculation of basis-generating potentials such as HF/MSDHF, false if it is used for Hamiltonian diagonalization
  
  bool is_there_cout;                    // true if one wants a print on screen of information about the calculation, even minimal, false if not
  
  bool is_there_cout_detailed;           // true if one wants a print on screen of detailed information about the calculation, false if not
  
  enum interaction_type TBME_inter;      // type of the interaction used (FHT, realistic, ...)
  
  enum interaction_read_type inter_read; // true if one reads two-body matrix elements from a file, false if not
  
  bool are_there_pp_TBMEs;               // true if pp TBMEs are present in the class, false if not
  bool are_there_nn_TBMEs;               // true if nn TBMEs are present in the class, false if not 
  bool are_there_pn_TBMEs;               // true if pn TBMEs are present in the class, false if not
                                         // p is proton and n is neutron when only nucleons are considered.
                                         // One recalls that p is charged baryon and n is uncharged baryon when hyperons are also considered.
  
  double a , b , V_SDI;                  // parameters of the SDI interaction, equal to V_SDI.(a + b.Psigma).delta (r1 - r2).delta (r - R0)
  
  double R0;                             // radius of the SGI/MSGI/SDI interaction
          
  double mu;                             // range of the SGI/MSGI/SDI interaction, used for Hamiltonian diagonalization

  double b_lab;                          // HO length used for the calculation of interaction TBMEs in laboratory (or COSM) coordinates

  double b_relative;                     // HO length used for the calculation of interaction TBMEs in relative coordinates





  // The following parameters are interaction parameters of the Minnesota and FHT/EFT interactions
  // --------------------------------------------------------------------------------------------
  // W,B,H,M are standard notations for spin/isospin/coordinate exchanges.
  // ...three_body_like: In the Minnesota interaction, a two-body interaction mimicking the three-body interaction is sometimes added, which writes V(r1,r2) = V3 . exp (-nu r1^2) . exp (-nu r2^2).
  // For the FHT interaction, ctr is for central, so is for spin-orbit, and t is for tensor. alpha is the range of each term, which occur in Gaussian function exp (-alpha (r_relative)^2)
  // For the EFT interaction, one uses standard contact terms VS,VT,V1,V2,V3,V4,V5,V6,V7.
  // The "inter" suffix for FHT interaction allows to differentiate the constants of the class from the constants of another class (see calculate_from_units_Coulomb_kinetic, calculate_unit, calculate_grad_from_units of this class)

  double V0_Minnesota_tab[3]; 

  double rho_Minnesota_tab[3]; 

  double u_Minnesota;
  
  double nu_three_body_like; 

  double V_three_body_like;

  double V0_ctr_tab[3]; 

  double alpha_ctr_tab[3];
  
  double W_ctr_tab[3];
  double B_ctr_tab[3];
  double H_ctr_tab[3];
  double M_ctr_tab[3];
  
  double V0_so_tab[2];

  double alpha_so_tab[2];

  double W_so_tab[2];
  double H_so_tab[2];

  double V0_t_tab[3];

  double alpha_t_tab[3];

  double W_t_tab[3];
  double H_t_tab[3];

  double V0_ctr_ot_inter; 
  double V0_ctr_et_inter; 
  double V0_ctr_os_inter; 
  double V0_ctr_es_inter; 
  double V0_so_ot_inter; 
  double V0_so_et_inter; 
  double V0_t_ot_inter; 
  double V0_t_et_inter;
  double V0_ALS_inter;

  double VS_const_LO_T0_inter;
  double VS_const_LO_T1_inter;
  double VT_sigma_product_LO_T0_inter;
  double VT_sigma_product_LO_T1_inter;
  double V1_q2_NLO_inter;
  double V2_k2_NLO_inter;
  double V3_q2_sigma_product_NLO_inter;
  double V4_k2_sigma_product_NLO_inter;
  double V5_sigma_q_vector_k_NLO_inter;
  double V6_sigma_q_product_NLO_inter;
  double V7_sigma_k_product_NLO_inter;
  double V8_sigma_q_vector_k_NLO_inter;

  
  // The YN and YY coupling constants associated to SU(3)f invariants are considered here.
  // The NN coupling constants are V27 and V10*.
  // The YN/YY coupling constants are V8a, V8s, V10 and V1 (YY only for V1).
  // Notation is standard.
  //
  // One normalizes YN/YY coupling constants with respect to V27 and V10*.
  // This is possible as YN/YY coupling constants either only occur along with V27 (V8s, V1) or with V10* (V8a, V10).
  // This means that NN/YN/YY constants must be understood as: V27 -> 1, V10* -> 1, V8s -> V8s/V27, V1 -> V1/V27 and V8a -> V8a/V10*, V10 -> V10/V10*.
  // This also has the advantage to suppress partial wave dependence, as above ratios do not depend on used partial waves, contrary to the coupling constants themselves.
  //
  // The induced non-linearity with respect to coupling constants might apparently cause problems in the GSM optimization code.
  // Indeed, linearity with respect to coupling constants is required in the two-body interaction.
  // This problem is suppressed by forbidding optimization of all NN, YN and YY coupling constants.
  // In fact, one recovers linearity with respect to NN/YN/YY coupling constants if only NN constants or only YN/YY coupling constants are fitted.
  // This also physically justified to separate NN from YN/YY coupling constants, as YN/YY TBMEs play no role in nuclei (of zero strangeness).
  //
  // Even though this is not necessary, one fits the ALS coupling constant (V0_ALS_inter or V8_sigma_q_vector_k_NLO_inter) only with YN/YY SU(3)f coupling constants for consistency, as ALS occurs only with hyperons.
  
  double V8a_SU3f_inter;
  double V8s_SU3f_inter;
  double V10_SU3f_inter;
  double  V1_SU3f_inter;



  // Maximal orbital angular momenta used in the interaction class, for Hamiltonian diagonalization or for the calculation of basis-generating potentials such as HF/MSDHF
  // ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
  // If "basis" is in the variable names, variables are used only to calculate the basis generating potentials, as in the HF/MSDHF methods.
  // The interaction maximal orbital angular momentum can be different from the maximal orbital angular momentum used in the one-body basis if one considers Nhbar omega spaces to generate |NCM-HO LCM intrinsic> states for GSM-CC, 
  // for which large orbital angular momenta are needed but no interaction matrix elements for these orbital angular momenta are used.
  // Indeed, high-l configurations are just there to have an exact separation of intrinsic and CM parts. 
  // All matrix elements of states with l > lmax_for_interaction with the HO expansion are then put to zero.

  int lmax_for_interaction;
  
  int lmax_multipole_expansion;







  // Minimal and maximal binary parities (see observables_basic_functions.cpp for definition) and total angular momenta for all two-body states of the proton-proton, neutron-neutron and proton-neutron matrix elements
  // -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  
  unsigned int BPmin_global_pp; 
  unsigned int BPmax_global_pp;
  
  int Jmin_global_pp; 
  int Jmax_global_pp;

  unsigned int BPmin_global_nn; 
  unsigned int BPmax_global_nn;
  
  int Jmin_global_nn; 
  int Jmax_global_nn;

  unsigned int BPmin_global_pn; 
  unsigned int BPmax_global_pn;
  
  int Jmin_global_pn; 
  int Jmax_global_pn;

  unsigned int BPmin_global; 
  unsigned int BPmax_global;
  
  int Jmin_global; 
  int Jmax_global;
  
  int hypernucleus_strangeness;      // hypernucleus strangeness
  
  bool is_Hamiltonian_complex_scaled; // true if one uses complex-scaled Hamiltonian, false if not

  double theta_H_complex_scaled;                     // angle used in the complex scaling of Hamiltonian in radians. It is different in general from that used in radial integrals (the latter being chosen automatically).
  
  TYPE exp_I_theta_H_complex_scaled;                 // exp (I.theta_H_complex_scaled) value used in one-body radial complex-scaled matrix elements

  TYPE exp_minus_I_theta_H_complex_scaled;           // exp (-I.theta_H_complex_scaled) value used in one-body radial complex-scaled matrix elements
  
  TYPE exp_minus_two_I_theta_H_complex_scaled;       // exp (-2.I.theta_H_complex_scaled) value used in one-body radial complex-scaled matrix elements

  TYPE exp_minus_I_theta_H_complex_scaled_over_two;  // exp (-I.theta_H_complex_scaled/2) value used in one-body radial complex-scaled matrix elements

  class array<int> nmax_HO_lab_tab;  // maximal principal quantum numbers used in the HO expansion function of orbital angular momentum l

  class array<class nlj_struct> shells_HO_qn; // array of structures containing data about HO shells, in particular quantum_numbers, from which wave functions are excluded.
                                              // One uses the same HO shells for all baryons in order to conveniently apply SU(3)f symmetry.

  class nlj_table<unsigned int> shells_HO_indices; // indices of the HO shells given as a function of their (n,l,j) quantum numbers independently of their particle type.
  
  class array<class nlj_table<unsigned int> > shells_HO_indices_p_tab; //   charged particle table of indices of the HO shells given as a function of their (n,l,j) quantum numbers and particle type (p is a charged baryon).
  class array<class nlj_table<unsigned int> > shells_HO_indices_n_tab; // uncharged particle table of indices of the HO shells given as a function of their (n,l,j) quantum numbers and particle type (n is an uncharged baryon).
  
  class array<class array<unsigned int> > shells_HO_indices_from_nlj_indices_p_tab; //   charged particle table of indices of the HO shells given as a function of the (n,l,j) index of the shells_HO_qn array and particle type
  class array<class array<unsigned int> > shells_HO_indices_from_nlj_indices_n_tab; // uncharged particle table of indices of the HO shells given as a function of the (n,l,j) index of the shells_HO_qn array and particle type
  
  class array<int> nmax_inter_lab_tab; // maximal principal quantum numbers used in the HO or GHF expansion used for interaction function of orbital angular momentum l

  class array<class nlj_struct> shells_inter_qn; // array of structures containing data about HO or GHF shells, in particular quantum_numbers, from which wave functions are excluded.
                                                 // One uses the same HO or GHF shells for all baryons in order to conveniently apply SU(3)f symmetry.
  
  class array<class nlj_table<unsigned int> > shells_inter_indices_p_tab; //   charged particle table of indices of the Berggren basis interaction shells given as a function of their (n,l,j) quantum numbers and particle type (p is a charged baryon).
  class array<class nlj_table<unsigned int> > shells_inter_indices_n_tab; // uncharged particle table of indices of the Berggren basis interaction shells given as a function of their (n,l,j) quantum numbers and particle type (n is an uncharged baryon).
  
  class array<class array<unsigned int> > shells_inter_indices_from_nlj_indices_p_tab; //   charged particle table of indices of the Berggren basis interaction shells given as a function of the (n,l,j) index of the shells_inter_qn array and particle type
  class array<class array<unsigned int> > shells_inter_indices_from_nlj_indices_n_tab; // uncharged particle table of indices of the Berggren basis interaction shells given as a function of the (n,l,j) index of the shells_inter_qn array and particle type
  
  class TBMEs_class TBMEs_pp_inter_lab;  // class TBMEs_class storing J-coupled TBMEs in HO or GHF basis of the form <pp | V | pp>, where p is a    charged baryon.
  class TBMEs_class TBMEs_nn_inter_lab;  // class TBMEs_class storing J-coupled TBMEs in HO or GHF basis of the form <nn | V | nn>, where n is an uncharged baryon.
  class TBMEs_class TBMEs_pn_inter_lab;  // class TBMEs_class storing J-coupled TBMEs in HO or GHF basis of the form <pn | V | pn>, where p is a charged baryon and n is an uncharged baryon.
  class TBMEs_class TBMEs_cv_inter_lab;  // class TBMEs_class storing J-coupled TBMEs in HO or GHF basis of the form <nn | V | pp>, where p is a charged baryon and n is an uncharged baryon. cv means pp <-> nn [charged baryons <-> uncharged baryons] conversion.

  class array<double> Vl_SGI_tab_GL;     // multipolar expansion of the SGI interaction on the Gauss-Legendre radial grid [0:2.R0], with R0 the radius of the SGI interaction

  class array<double> V_Gaussian_consts; // array of coupling constants for interactions having Gaussian form factors, function of parity, J and T

  class array<double> r_bef_R_tab_GL , w_bef_R_tab_GL; // Gauss-Legendre radii and weights on the [0:R] radial grid, with R the rotation point
  class array<double> r_aft_R_tab_GL , w_aft_R_tab_GL; // Gauss-Legendre radii and weights on the [R:R_real_max] radial grid, with R the rotation point and R_real_max the largest considered radius on the real axis
    
  class array<double> HO_wfs_bef_R_tab_GL , HO_dwfs_bef_R_tab_GL; // array of HO one-body radial wave functions and derivatives on the Gauss-Legendre [0:R] radial grid, with R the rotation point
  class array<double> HO_wfs_aft_R_tab_GL , HO_dwfs_aft_R_tab_GL; // array of HO one-body radial wave functions and derivatives on the Gauss-Legendre [R:R_real_max] radial grid, with R_real_max the largest radius on the real axis
  
  class array<double> r_bef_R_tab_GL_SGI_MSGI , w_bef_R_tab_GL_SGI_MSGI;            // Gauss-Legendre radii and weights on the [0:2.R0] radial grid (before R)
  
  class array<double> HO_wfs_bef_R_tab_GL_SGI_MSGI , HO_dwfs_bef_R_tab_GL_SGI_MSGI; // array of HO one-body radial wave functions and derivatives on the Gauss-Legendre [0:2.R0] radial grid (before R)
                                                                                    // R0 is the radius of the SGI/MSGI interaction.
  
  class array<class vector_class<complex<double> > > HO_overlaps_Fermi; // arrays of vectors of Fermi function overlaps, between HF/OCM one-body basis states and HO states of the interaction class used for the HO expansion of operators

  class array<class lj_table<class matrix<complex<double> > > > V_Coulomb_HO_basis_tab; // particle table (charged baryons) of (l,j) array of the analytical Coulomb potential part expanded with the HO basis for all partial waves
};

#endif


