#ifndef GSMCOMPLEXSCALINGRADIALOBMES_H
#define GSMCOMPLEXSCALINGRADIALOBMES_H

// TYPE is double or complex
// -------------------------

namespace complex_scaling_radial_OBMEs
{
  complex<double> radial_integral_bef_R_calc (
					      const enum radial_operator_type radial_operator , 
					      const int ZY_charge , 
					      const double R_charge , 
					      const class spherical_state &wf_in , 
					      const class spherical_state &wf_out);

  complex<double> radial_integral_aft_R_part_of_four_calc (
							   const enum radial_operator_type radial_operator , 
							   const int ZY_charge , 
							   const unsigned int asy_in , 
							   const unsigned int asy_out , 
							   const class spherical_state &wf_in , 
							   const class spherical_state &wf_out);

  complex<double> radial_integral_aft_R_calc (
					      const enum radial_operator_type radial_operator , 
					      const int ZY_charge ,
					      const class spherical_state &wf_in , 
					      const class spherical_state &wf_out);

  TYPE radial_integral_calc (
			     const enum radial_operator_type radial_operator , 
			     const int ZY_charge , 
			     const double R_charge , 
			     const class spherical_state &wf_in , 
			     const class spherical_state &wf_out);
}

#endif


