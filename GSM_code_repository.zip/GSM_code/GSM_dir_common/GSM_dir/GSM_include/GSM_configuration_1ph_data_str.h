#ifndef GSCONFIGURATION1PHSTR_H
#define GSCONFIGURATION1PHSTR_H

// TYPE is double or complex
// -------------------------

class configuration_1ph_data_str
{
public:

  configuration_1ph_data_str ();

  configuration_1ph_data_str (
			      const unsigned int n_scat_c , 
			      const unsigned int iC_c , 
			      const unsigned int shell_index_c);

  void initialize (
		   const unsigned int n_scat_c , 
		   const unsigned int iC_c , 
		   const unsigned int shell_index_c);
  
  void initialize (const class configuration_1ph_data_str &X);
  
  void allocate_fill (const class configuration_1ph_data_str &X);
  
  unsigned int get_n_scat () const
  {
    return n_scat;
  }
  
  unsigned int get_iC () const
  {
    return iC;
  }
  
  unsigned int get_shell_index () const
  {
    return shell_index;
  }
    
private:
  
  unsigned char n_scat; // number of particles in the continuum

  unsigned int iC; // index of the configuration with fixed parity

  unsigned short int shell_index; // index of the alpha shell
};

double used_memory_calc (const class configuration_1ph_data_str &T);

#endif


