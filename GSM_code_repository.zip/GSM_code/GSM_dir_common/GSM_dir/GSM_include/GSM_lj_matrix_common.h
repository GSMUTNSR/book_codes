#ifndef GSMLJMATRIXCOMMON_H
#define GSMLJMATRIXCOMMON_H

// TYPE is double or complex
// -------------------------

namespace lj_matrix_common
{
  void lj_matrices_parts_tab_allocate_initialize (
						  const class baryons_data &data ,
						  class array<class lj_table<class matrix<TYPE> > > &lj_matrices_parts_tab);

  void lj_matrices_parts_tabs_allocate_initialize (
						   const class baryons_data &data ,
						   class array<class array<class lj_table<class matrix<TYPE> > > > &lj_matrices_parts_tabs);

  void lj_matrices_tab_initialize (class array<class lj_table<class matrix<TYPE> > > &lj_matrices_tab);

  void small_random_lj_matrices_tab (class array<class lj_table<class matrix<TYPE> > > &lj_matrices_tab);

  void lj_matrices_tab_core_states_handling (
					     const class baryons_data &data ,
					     class array<class lj_table<class matrix<TYPE> > > &lj_matrices_tab);

  void add_parts (
		  const class array<class lj_table<class matrix<TYPE> > > &lj_matrices_parts_tab ,
		  class array<class lj_table<class matrix<TYPE> > > &lj_matrices_tab);

  void add_parts (
		  const class array<class array<class lj_table<class matrix<TYPE> > > > &lj_matrices_parts_tabs ,
		  class array<class lj_table<class matrix<TYPE> > > &lj_matrices_tab);
 
  void fill_upper_part (class array<class lj_table<class matrix<TYPE> > > &lj_matrices_tab);

  void normalize (
		  const TYPE normalizing_term ,
		  class array<class lj_table<class matrix<TYPE> > > &lj_matrices_tab);
 
  void scalar_density_matrices_allocate_initialize (class baryons_data &data);
 
  void ESPEs_Hamiltonian_matrices_tab_allocate_initialize (class baryons_data &data);

#ifdef UseMPI

  void lj_matrices_tab_MPI_Reduce (
				   MPI_Op op ,
				   const unsigned int Recv_process ,
				   const unsigned int process , 
				   const MPI_Comm MPI_C,
				   class array<class lj_table<class matrix<TYPE> > > &lj_matrices_tab);

  void lj_matrices_tab_MPI_Bcast (
				  const MPI_Comm MPI_C,
				  const unsigned int Send_process ,
				  class array<class lj_table<class matrix<TYPE> > > &lj_matrices_tab);
#endif

}

#endif


