#ifndef GSMHFPOTENTIALSCOMMON_H
#define GSMHFPOTENTIALSCOMMON_H

// TYPE is double or complex
// -------------------------

namespace HF_potentials_common
{
  namespace HO_expansion_part_common
  {
    void HO_index_from_n_tab_determine (
					const int l , 
					const double j , 
					const class interaction_class &inter_data_basis , 
					class array<unsigned int> &HO_index_from_n_tab);

    void HO_index_from_n_tab_determine (
					const class nlj_struct &shell_lj , 
					const class interaction_class &inter_data_basis , 
					class array<unsigned int> &HO_index_from_n_tab);

    void HO_index_from_n_tab_determine (
					const class nljm_struct &phi_lj , 
					const class interaction_class &inter_data_basis , 
					class array<unsigned int> &HO_index_from_n_tab);

    void HO_overlaps_calc (
			   const class interaction_class &inter_data_basis , 
			   const class array<class spherical_state> &shells , 
			   const class HF_nucleons_data &HF_data , 
			   class array<class vector_class<complex<double> > > &HO_overlaps , 
			   class array<class vector_class<complex<double> > > &HO_overlaps_Fermi);

    void HO_overlaps_calc (
			   const class interaction_class &inter_data_basis , 
			   const bool is_it_res , 
			   class HF_nucleons_data &HF_data);

    void HO_overlaps_pm_calc (
			      const int pm , 
			      const class interaction_class &inter_data_basis , 
			      class HF_nucleons_data &HF_data);

    double Up_HF_abcd_pp_part_J (
				 const unsigned int sp_occ , 
				 const unsigned int a , 
				 const unsigned int b , 
				 const unsigned int c , 
				 const unsigned int d , 
				 const bool same_lj_all_protons , 
				 const complex<double> &weight , 
				 const int J , 
				 const int phase , 
				 const class array<class nlj_struct> &shells_HO_table , 
				 const class array<class vector_class<complex<double> > > &prot_HO_overlaps_occ , 
				 const class TBMEs_class &TBMEs_pp_HO_lab);

    double Up_HF_abcd_pn_part_J (
				 const unsigned int sn_occ , 
				 const unsigned int a , 
				 const unsigned int b , 
				 const unsigned int c , 
				 const unsigned int d , 
				 const complex<double> &weight , 
				 const int J , 
				 const class array<class nlj_struct> &shells_HO_table , 
				 const class array<class vector_class<complex<double> > > &neut_HO_overlaps_occ , 
				 const class TBMEs_class &TBMEs_pn_HO_lab);

    double Un_HF_abcd_nn_part_J (
				 const unsigned int sn_occ , 
				 const unsigned int a , 
				 const unsigned int b , 
				 const unsigned int c , 
				 const unsigned int d , 
				 const bool same_lj_all_neutrons , 
				 const complex<double> &weight , 
				 const int J , 
				 const int phase , 
				 const class array<class nlj_struct> &shells_HO_table , 
				 const class array<class vector_class<complex<double> > > &neut_HO_overlaps_occ , 
				 const class TBMEs_class &TBMEs_nn_HO_lab);

    double Un_HF_abcd_pn_part_J (
				 const unsigned int sp_occ , 
				 const unsigned int a , 
				 const unsigned int b , 
				 const unsigned int c , 
				 const unsigned int d , 
				 const complex<double> &weight , 
				 const int J , 
				 const class array<class nlj_struct> &shells_HO_table , 
				 const class array<class vector_class<complex<double> > > &prot_HO_overlaps_occ , 
				 const class TBMEs_class &TBMEs_pn_HO_lab);
    
    void Up_HF_pp_part_HO_basis_calc (
				      const class CG_str &CGs , 
				      const class interaction_class &inter_data_basis , 
				      class HF_nucleons_data &prot_HF_data);

    void Up_HF_pn_part_HO_basis_calc (
				      const class CG_str &CGs , 
				      const class interaction_class &inter_data_basis , 
				      const class HF_nucleons_data &neut_HF_data , 
				      class HF_nucleons_data &prot_HF_data);

    void Un_HF_nn_part_HO_basis_calc (
				      const class CG_str &CGs , 
				      const class interaction_class &inter_data_basis , 
				      class HF_nucleons_data &neut_HF_data);

    void Un_HF_pn_part_HO_basis_calc (
				      const class CG_str &CGs , 
				      const class interaction_class &inter_data_basis , 
				      const class HF_nucleons_data &prot_HF_data , 
				      class HF_nucleons_data &neut_HF_data);

    void prot_potentials_HO_basis_calc (
					const class CG_str &CGs , 
					const class interaction_class &inter_data_basis , 
					const class HF_nucleons_data &neut_HF_data , 
					class HF_nucleons_data &prot_HF_data);

    void neut_potentials_HO_basis_calc (
					const class CG_str &CGs , 
					const class interaction_class &inter_data_basis , 
					const class HF_nucleons_data &prot_HF_data , 
					class HF_nucleons_data &neut_HF_data);
    
    void Ueq_source_calc (
			  const class interaction_class &inter_data_basis , 
			  const bool is_it_res , 
			  const unsigned int s , 
			  const class spherical_state &shell , 
			  class HF_nucleons_data &HF_data);

    void Ueq_source_pm_calc (
			     const int pm , 
			     const class interaction_class &inter_data_basis , 
			     const unsigned int s , 
			     const class spherical_state &shell_pm , 
			     class HF_nucleons_data &HF_data);

    void Ueq_source_calc (
			  const class interaction_class &inter_data_basis , 
			  const class spherical_state &shell , 
			  const class vector_class<complex<double> > &U_HF_shell_HO_basis_Fermi , 
			  const class HF_nucleons_data &HF_data , 
			  class nlj_table<complex<double> > &Ueq_finite_range_tab_big , 
			  class nlj_table<complex<double> > &source_tab_big , 
			  class nlj_table<complex<double> > &Ueq_finite_range_tab_GL , 
			  class nlj_table<complex<double> > &source_tab_GL);
      
    void V_Coulomb_HO_basis_removal (
				     const class interaction_class &inter_data_basis , 
				     class HF_nucleons_data &prot_HF_data);

    void trivially_equivalent_potentials_calc (
					       const bool HO_diag , 
					       const class interaction_class &inter_data_basis , 
					       class HF_nucleons_data &HF_data);

    void trivially_equivalent_potentials_shells_pm_calc (
							 const int pm , 
							 const class interaction_class &inter_data_basis , 
							 class HF_nucleons_data &HF_data);
  }
  
  namespace OCM_part_common
  {
    void shells_OCM_core_states_overlaps_calc (class HF_nucleons_data &HF_data);

    void php_matrices_calc (class HF_nucleons_data &HF_data);
 
    complex<double> OBME_shell_h_OCM_core_state_calc (
						      const class spherical_state &shell , 
						      const class spherical_state &shell_OCM_core_state , 
						      const class HF_nucleons_data &HF_data);
    
    complex<double> OBME_OCM_s_core_state_h_OCM_sp_core_state_calc (
								    const class spherical_state &shell_OCM_core_state , 
								    const class spherical_state &shell_p_OCM_core_state , 
								    const class HF_nucleons_data &HF_data);

    void Ueq_source_calc (
			  const bool is_it_res , 
			  const class spherical_state &shell , 	
			  class HF_nucleons_data &HF_data);

    void Ueq_source_shells_pm_calc (
				    const int pm , 
				    const class spherical_state &shell_pm , 
				    class HF_nucleons_data &HF_data);

    void trivially_equivalent_potentials_calc (
					       const bool HO_diag , 
					       class HF_nucleons_data &HF_data);

    void trivially_equivalent_potentials_shells_pm_calc (
							 const int pm , 
							 class HF_nucleons_data &HF_data);
  }

  namespace SGI_MSGI_part_common
  {
    namespace SGI_part_common
    {     
      void radial_direct_exchange_tabs_calc (
					     const class HF_nucleons_data &HF_data , 
					     const class interaction_class &inter_data_basis , 
					     class SGI_radial_tabs_str &radial_tabs);

      void Up_direct_pp_part_calc (
				   const int J , 
				   const unsigned int sp_occ , 
				   const class spherical_state &p_shell , 
				   const class spherical_state &p_shell_occ , 
				   const class interaction_class &inter_data_basis , 
				   const complex<double> &weight , 
				   const class multipolar_expansion_str &multipolar_expansion , 
				   const class SGI_radial_tabs_str &prot_radial_tabs , 
				   class nlj_table<complex<double> > &Up_eq_SGI_tab_GL);

      void Up_direct_pn_part_calc (
				   const int J , 
				   const unsigned int sn_occ , 
				   const class spherical_state &p_shell , 
				   const class spherical_state &n_shell_occ , 
				   const class interaction_class &inter_data_basis , 
				   const complex<double> &weight , 
				   const class multipolar_expansion_str &multipolar_expansion , 
				   const class SGI_radial_tabs_str &neut_radial_tabs , 
				   class nlj_table<complex<double> > &Up_eq_SGI_tab_GL);

      void Un_direct_nn_part_calc (
				   const int J , 
				   const unsigned int sn_occ , 
				   const class spherical_state &n_shell , 
				   const class spherical_state &n_shell_occ , 
				   const class interaction_class &inter_data_basis , 
				   const complex<double> &weight , 
				   const class multipolar_expansion_str &multipolar_expansion , 
				   const class SGI_radial_tabs_str &neut_radial_tabs , 
				   class nlj_table<complex<double> > &Un_eq_SGI_tab_GL);

      void Un_direct_pn_part_calc (
				   const int J , 
				   const unsigned int sp_occ , 
				   const class spherical_state &n_shell , 
				   const class spherical_state &p_shell_occ , 
				   const class interaction_class &inter_data_basis , 
				   const complex<double> &weight , 
				   const class multipolar_expansion_str &multipolar_expansion , 
				   const class SGI_radial_tabs_str &prot_radial_tabs , 
				   class nlj_table<complex<double> > &Un_eq_SGI_tab_GL);

      void Up_exchange_pp_part_calc (
				     const int J , 
				     const unsigned int sp_occ , 
				     const class spherical_state &p_shell , 
				     const class spherical_state &p_shell_occ , 
				     const double Ueq_regularizor , 
				     const class interaction_class &inter_data_basis , 
				     const complex<double> &weight , 
				     const class multipolar_expansion_str &multipolar_expansion , 
				     const class SGI_radial_tabs_str &prot_radial_tabs , 
				     class nlj_table<complex<double> > &Up_eq_SGI_tab_GL , 
				     class nlj_table<complex<double> > &prot_source_SGI_tab_GL);

      void Up_exchange_pn_part_calc (
				     const int J , 
				     const unsigned int sn_occ , 
				     const class spherical_state &p_shell , 
				     const class spherical_state &n_shell_occ , 
				     const double Ueq_regularizor , 
				     const class interaction_class &inter_data_basis , 
				     const complex<double> &weight , 
				     const class multipolar_expansion_str &multipolar_expansion , 
				     const class SGI_radial_tabs_str &neut_radial_tabs , 
				     class nlj_table<complex<double> > &Up_eq_SGI_tab_GL , 
				     class nlj_table<complex<double> > &prot_source_SGI_tab_GL);

      void Un_exchange_nn_part_calc (
				     const int J , 
				     const unsigned int sn_occ , 
				     const class spherical_state &n_shell , 
				     const class spherical_state &n_shell_occ , 
				     const double Ueq_regularizor , 
				     const class interaction_class &inter_data_basis , 
				     const complex<double> &weight , 
				     const class multipolar_expansion_str &multipolar_expansion , 
				     const class SGI_radial_tabs_str &neut_radial_tabs , 
				     class nlj_table<complex<double> > &Un_eq_SGI_tab_GL , 
				     class nlj_table<complex<double> > &neut_source_SGI_tab_GL);

      void Un_exchange_pn_part_calc (
				     const int J , 
				     const unsigned int sp_occ , 
				     const class spherical_state &n_shell , 
				     const class spherical_state &p_shell_occ , 
				     const double Ueq_regularizor , 
				     const class interaction_class &inter_data_basis , 
				     const complex<double> &weight , 
				     const class multipolar_expansion_str &multipolar_expansion , 
				     const class SGI_radial_tabs_str &prot_radial_tabs , 
				     class nlj_table<complex<double> > &Un_eq_SGI_tab_GL , 
				     class nlj_table<complex<double> > &neut_source_SGI_tab_GL);

      void Up_pp_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const unsigned int sp_occ , 
			    const class spherical_state &shell_prot , 
			    const class spherical_state &shell_prot_occ , 
			    const class CG_str &CGs , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    const class SGI_radial_tabs_str &prot_radial_tabs , 
			    class HF_nucleons_data &prot_HF_data);

      void Up_pn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const unsigned int sn_occ , 
			    const class spherical_state &shell_prot , 
			    const class spherical_state &shell_neut_occ , 
			    const class CG_str &CGs , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    const class SGI_radial_tabs_str &neut_radial_tabs , 
			    const class HF_nucleons_data &neut_HF_data , 
			    class HF_nucleons_data &prot_HF_data);

      void Un_nn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const unsigned int sn_occ , 
			    const class spherical_state &shell_neut , 
			    const class spherical_state &shell_neut_occ , 
			    const class CG_str &CGs , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    const class SGI_radial_tabs_str &neut_radial_tabs , 
			    class HF_nucleons_data &neut_HF_data);

      void Un_pn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const unsigned int sp_occ , 
			    const class spherical_state &shell_neut , 
			    const class spherical_state &shell_prot_occ , 
			    const class CG_str &CGs , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    const class SGI_radial_tabs_str &prot_radial_tabs , 
			    const class HF_nucleons_data &prot_HF_data , 
			    class HF_nucleons_data &neut_HF_data);

      void Up_pp_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const unsigned int sp_occ , 
			    const class spherical_state &shell_prot , 
			    const class spherical_state &shell_prot_occ , 
			    const class CG_str &CGs , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    const class SGI_radial_tabs_str &prot_radial_tabs , 
			    class HF_nucleons_data &prot_HF_data);

      void Up_pn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const unsigned int sn_occ , 
			    const class spherical_state &shell_prot , 
			    const class spherical_state &shell_neut_occ , 
			    const class CG_str &CGs , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    const class SGI_radial_tabs_str &neut_radial_tabs , 
			    const class HF_nucleons_data &neut_HF_data , 
			    class HF_nucleons_data &prot_HF_data);

      void Un_nn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const unsigned int sn_occ , 
			    const class spherical_state &shell_neut , 
			    const class spherical_state &shell_neut_occ , 
			    const class CG_str &CGs , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    const class SGI_radial_tabs_str &neut_radial_tabs , 
			    class HF_nucleons_data &neut_HF_data);

      void Un_pn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const unsigned int sp_occ , 
			    const class spherical_state &shell_neut , 
			    const class spherical_state &shell_prot_occ , 
			    const class CG_str &CGs , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    const class SGI_radial_tabs_str &prot_radial_tabs , 
			    const class HF_nucleons_data &prot_HF_data , 
			    class HF_nucleons_data &neut_HF_data);
      
      complex<double> OBME_nas_fixed_multipole_calc (
						     const class interaction_class &inter_data_basis , 
						     const int ll , 
						     const bool is_it_direct , 
						     const complex<double> &angular_weight_part , 
						     const class spherical_state &wf_occ , 
						     const class spherical_state &wf_in , 
						     const class spherical_state &wf_out);

      namespace HO_basis
      {
	complex<double> OBME_nas_fixed_multipole_calc (
						       const class interaction_class &inter_data_basis , 
						       const int ll , 
						       const bool is_it_direct , 
						       const complex<double> &angular_weight_part , 
						       const class spherical_state &wf_occ , 
						       const int l , 
						       const int n_HO_in , 
						       const int n_HO_out);
      }
    }

    namespace MSGI_part_common
    {
      void Gaussian_table_GL_calc (
				   const class interaction_class &inter_data_basis , 
				   class array<double> &Gaussian_table_GL);

      void Up_direct_pp_part_calc (
				   const int J , 
				   const class spherical_state &p_shell , 
				   const class spherical_state &p_shell_occ , 
				   const class interaction_class &inter_data_basis , 
				   const complex<double> &weight , 
				   const class array<double> &Gaussian_table_GL , 
				   const class multipolar_expansion_str &multipolar_expansion , 
				   class nlj_table<complex<double> > &Up_eq_MSGI_tab_GL);

      void Up_direct_pn_part_calc (
				   const int J , 
				   const class spherical_state &p_shell , 
				   const class spherical_state &n_shell_occ , 
				   const class interaction_class &inter_data_basis , 
				   const complex<double> &weight , 
				   const class array<double> &Gaussian_table_GL , 
				   const class multipolar_expansion_str &multipolar_expansion , 
				   class nlj_table<complex<double> > &Up_eq_MSGI_tab_GL);

      void Un_direct_nn_part_calc (
				   const int J , 
				   const class spherical_state &n_shell , 
				   const class spherical_state &n_shell_occ , 
				   const class interaction_class &inter_data_basis , 
				   const complex<double> &weight , 
				   const class array<double> &Gaussian_table_GL , 
				   const class multipolar_expansion_str &multipolar_expansion , 
				   class nlj_table<complex<double> > &Un_eq_MSGI_tab_GL);

      void Un_direct_pn_part_calc (
				   const int J , 
				   const class spherical_state &n_shell , 
				   const class spherical_state &p_shell_occ , 
				   const class interaction_class &inter_data_basis , 
				   const complex<double> &weight , 
				   const class array<double> &Gaussian_table_GL , 
				   const class multipolar_expansion_str &multipolar_expansion , 
				   class nlj_table<complex<double> > &Un_eq_MSGI_tab_GL);

      void Up_exchange_pp_part_calc (
				     const int J , 
				     const class spherical_state &p_shell , 
				     const class spherical_state &p_shell_occ , 
				     const double Ueq_regularizor , 
				     const class interaction_class &inter_data_basis , 
				     const complex<double> &weight , 
				     const class array<double> &Gaussian_table_GL , 
				     const class multipolar_expansion_str &multipolar_expansion , 
				     class nlj_table<complex<double> > &Up_eq_MSGI_tab_GL , 
				     class nlj_table<complex<double> > &prot_source_tab_GL);

      void Up_exchange_pn_part_calc (
				     const int J , 
				     const class spherical_state &p_shell , 
				     const class spherical_state &n_shell_occ , 
				     const double Ueq_regularizor , 
				     const class interaction_class &inter_data_basis , 
				     const complex<double> &weight , 
				     const class array<double> &Gaussian_table_GL , 
				     const class multipolar_expansion_str &multipolar_expansion , 
				     class nlj_table<complex<double> > &Up_eq_MSGI_tab_GL , 
				     class nlj_table<complex<double> > &prot_source_tab_GL);

      void Un_exchange_nn_part_calc (
				     const int J , 
				     const class spherical_state &n_shell , 
				     const class spherical_state &n_shell_occ , 
				     const double Ueq_regularizor , 
				     const class interaction_class &inter_data_basis , 
				     const complex<double> &weight , 
				     const class array<double> &Gaussian_table_GL , 
				     const class multipolar_expansion_str &multipolar_expansion , 
				     class nlj_table<complex<double> > &Un_eq_MSGI_tab_GL , 
				     class nlj_table<complex<double> > &neut_source_tab_GL);

      void Un_exchange_pn_part_calc (
				     const int J , 
				     const class spherical_state &n_shell , 
				     const class spherical_state &p_shell_occ , 
				     const double Ueq_regularizor , 
				     const class interaction_class &inter_data_basis , 
				     const complex<double> &weight , 
				     const class array<double> &Gaussian_table_GL , 
				     const class multipolar_expansion_str &multipolar_expansion , 
				     class nlj_table<complex<double> > &Un_eq_MSGI_tab_GL , 
				     class nlj_table<complex<double> > &neut_source_tab_GL);

      void Up_pp_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const class spherical_state &shell_prot , 
			    const class spherical_state &shell_prot_occ , 
			    const class CG_str &CGs , 
			    const class array<double> &Gaussian_table_GL , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    class HF_nucleons_data &prot_HF_data);

      void Up_pn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const class spherical_state &shell_prot , 
			    const class spherical_state &shell_neut_occ , 
			    const class CG_str &CGs , 
			    const class array<double> &Gaussian_table_GL , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    const class HF_nucleons_data &neut_HF_data , 
			    class HF_nucleons_data &prot_HF_data);

      void Un_nn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const class spherical_state &shell_neut , 
			    const class spherical_state &shell_neut_occ , 
			    const class CG_str &CGs , 
			    const class array<double> &Gaussian_table_GL , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    class HF_nucleons_data &neut_HF_data);

      void Un_pn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const class spherical_state &shell_neut , 
			    const class spherical_state &shell_prot_occ , 
			    const class CG_str &CGs , 
			    const class array<double> &Gaussian_table_GL , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    const class HF_nucleons_data &prot_HF_data , 
			    class HF_nucleons_data &neut_HF_data);
	
      complex<double> radial_OBME_calc (
					const class array<double> &Gaussian_table_GL , 
					const class spherical_state &wf , 
					const class spherical_state &wf_occ , 
					const bool is_it_real_part);

      complex<double> radial_integral_calc (
					    const class array<double> &Gaussian_table_GL , 
					    const class spherical_state &wf_in , 
					    const class spherical_state &wf_out);

      complex<double> total_OBME_calc (
				       const class spherical_state &wf_in , 
				       const class spherical_state &wf_out , 
				       const class array<double> &Gaussian_table_GL , 			
				       const complex<double> &OBME_factor_dir , 
				       const complex<double> &OBME_factor_exc , 
				       const class spherical_state &wf_occ);

      namespace HO_basis
      {
	double radial_integral_calc (
				     const class array<double> &Gaussian_table_GL , 
				     const class interaction_class &inter_data_basis , 
				     const int l , 
				     const int n_HO_in , 
				     const int n_HO_out);

	double radial_OBME_calc (
				 const class array<double> &Gaussian_table_GL , 
				 const class interaction_class &inter_data_basis , 
				 const int l , 
				 const int n_HO , 
				 const class spherical_state &wf_occ , 
				 const bool is_it_real_part);

	double total_OBME_calc (
				const class interaction_class &inter_data_basis , 
				const int l , 
				const int n_HO_in , 
				const int n_HO_out , 
				const class array<double> &Gaussian_table_GL , 
				const complex<double> &OBME_factor_dir , 
				const complex<double> &OBME_factor_exc , 
				const class spherical_state &wf_occ);
      }
    }
    
    void prot_trivially_equivalent_potentials_pp_part_calc (
							    const bool HO_diag , 
							    const class CG_str &CGs , 
							    const class array<double> &Gaussian_table_GL , 
							    const class multipolar_expansion_str &multipolar_expansion , 
							    const class interaction_class &inter_data_basis , 
							    const class SGI_radial_tabs_str &prot_radial_tabs , 
							    class HF_nucleons_data &prot_HF_data);

    void prot_trivially_equivalent_potentials_pn_part_calc (
							    const bool HO_diag , 
							    const class CG_str &CGs , 
							    const class array<double> &Gaussian_table_GL , 
							    const class multipolar_expansion_str &multipolar_expansion , 
							    const class interaction_class &inter_data_basis , 
							    const class SGI_radial_tabs_str &neut_radial_tabs , 
							    const class HF_nucleons_data &neut_HF_data , 
							    class HF_nucleons_data &prot_HF_data);

    void neut_trivially_equivalent_potentials_nn_part_calc (
							    const bool HO_diag , 
							    const class CG_str &CGs , 
							    const class array<double> &Gaussian_table_GL , 
							    const class multipolar_expansion_str &multipolar_expansion , 
							    const class interaction_class &inter_data_basis , 
							    const class SGI_radial_tabs_str &neut_radial_tabs , 
							    class HF_nucleons_data &neut_HF_data);

    void neut_trivially_equivalent_potentials_pn_part_calc (
							    const bool HO_diag , 
							    const class CG_str &CGs , 
							    const class array<double> &Gaussian_table_GL , 
							    const class multipolar_expansion_str &multipolar_expansion , 
							    const class interaction_class &inter_data_basis , 
							    const class SGI_radial_tabs_str &prot_radial_tabs , 
							    const class HF_nucleons_data &prot_HF_data , 
							    class HF_nucleons_data &neut_HF_data);

    void prot_trivially_equivalent_potentials_pp_part_shells_pm_calc (
								      const int pm , 
								      const class CG_str &CGs , 
								      const class array<double> &Gaussian_table_GL , 
								      const class multipolar_expansion_str &multipolar_expansion , 
								      const class interaction_class &inter_data_basis , 
								      const class SGI_radial_tabs_str &prot_radial_tabs , 
								      class HF_nucleons_data &prot_HF_data);

    void prot_trivially_equivalent_potentials_pn_part_shells_pm_calc (
								      const int pm , 
								      const class CG_str &CGs , 
								      const class array<double> &Gaussian_table_GL , 
								      const class multipolar_expansion_str &multipolar_expansion , 
								      const class interaction_class &inter_data_basis , 
								      const class SGI_radial_tabs_str &neut_radial_tabs , 
								      const class HF_nucleons_data &neut_HF_data , 
								      class HF_nucleons_data &prot_HF_data);

    void neut_trivially_equivalent_potentials_nn_part_shells_pm_calc (
								      const int pm , 
								      const class CG_str &CGs , 
								      const class array<double> &Gaussian_table_GL , 
								      const class multipolar_expansion_str &multipolar_expansion , 
								      const class interaction_class &inter_data_basis , 
								      const class SGI_radial_tabs_str &neut_radial_tabs , 
								      class HF_nucleons_data &neut_HF_data);

    void neut_trivially_equivalent_potentials_pn_part_shells_pm_calc (
								      const int pm , 
								      const class CG_str &CGs , 
								      const class array<double> &Gaussian_table_GL , 
								      const class multipolar_expansion_str &multipolar_expansion , 
								      const class interaction_class &inter_data_basis , 
								      const class SGI_radial_tabs_str &prot_radial_tabs , 
								      const class HF_nucleons_data &prot_HF_data , 
								      class HF_nucleons_data &neut_HF_data);

    void prot_trivially_equivalent_potentials_calc (
						    const bool HO_diag , 
						    const class CG_str &CGs , 
						    const class array<double> &Gaussian_table_GL , 
						    const class multipolar_expansion_str &multipolar_expansion , 
						    const class interaction_class &inter_data_basis , 
						    const class SGI_radial_tabs_str &prot_radial_tabs , 
						    const class SGI_radial_tabs_str &neut_radial_tabs , 
						    const class HF_nucleons_data &neut_HF_data , 
						    class HF_nucleons_data &prot_HF_data);

    void neut_trivially_equivalent_potentials_calc (
						    const bool HO_diag , 
						    const class CG_str &CGs , 
						    const class array<double> &Gaussian_table_GL , 
						    const class multipolar_expansion_str &multipolar_expansion , 
						    const class interaction_class &inter_data_basis , 
						    const class SGI_radial_tabs_str &prot_radial_tabs , 
						    const class SGI_radial_tabs_str &neut_radial_tabs , 
						    const class HF_nucleons_data &prot_HF_data , 
						    class HF_nucleons_data &neut_HF_data);

    void prot_trivially_equivalent_potentials_shells_pm_calc (
							      const int pm , 
							      const class CG_str &CGs , 
							      const class array<double> &Gaussian_table_GL , 
							      const class multipolar_expansion_str &multipolar_expansion , 
							      const class interaction_class &inter_data_basis , 
							      const class SGI_radial_tabs_str &prot_radial_tabs , 
							      const class SGI_radial_tabs_str &neut_radial_tabs , 
							      const class HF_nucleons_data &neut_HF_data , 
							      class HF_nucleons_data &prot_HF_data);

    void neut_trivially_equivalent_potentials_shells_pm_calc (
							      const int pm , 
							      const class CG_str &CGs , 
							      const class array<double> &Gaussian_table_GL , 
							      const class multipolar_expansion_str &multipolar_expansion , 
							      const class interaction_class &inter_data_basis , 
							      const class SGI_radial_tabs_str &prot_radial_tabs , 
							      const class SGI_radial_tabs_str &neut_radial_tabs , 
							      const class HF_nucleons_data &prot_HF_data , 
							      class HF_nucleons_data &neut_HF_data);
		
    void trivially_equivalent_potential_splines_calc (
						      const class spherical_state &shell , 
						      const class nlj_table<complex<double> > &Ueq_SGI_MSGI_tab_GL , 
						      const class nlj_table<complex<double> > &source_SGI_MSGI_tab_GL , 
						      class nlj_table<complex<double> > &Ueq_finite_range_tab_big , 
						      class nlj_table<complex<double> > &source_tab_big , 
						      class nlj_table<complex<double> > &Ueq_finite_range_tab_GL , 
						      class nlj_table<complex<double> > &source_tab_GL);

    void trivially_equivalent_potentials_splines_calc (const bool HO_diag , class HF_nucleons_data &HF_data);

    void trivially_equivalent_potentials_splines_pm_calc (const int pm , class HF_nucleons_data &HF_data);
  }
  
  namespace SGI_MSGI_OBMEs
  { 
    complex<double> prot_OBME_HF_pp_subpart_calc (
						  const class spherical_state &p_shell_in , 
						  const class spherical_state &p_shell_out , 
						  const class spherical_state &p_shell_occ , 
						  const class CG_str &CGs , 
						  const class interaction_class &inter_data_basis , 
						  const class array<double> &Gaussian_table_GL , 
						  const class multipolar_expansion_str &multipolar_expansion , 
						  const class HF_nucleons_data &prot_HF_data);

    complex<double> prot_OBME_HF_pn_subpart_calc (
						  const class spherical_state &p_shell_in , 
						  const class spherical_state &p_shell_out , 
						  const class spherical_state &n_shell_occ , 
						  const class CG_str &CGs , 
						  const class interaction_class &inter_data_basis , 
						  const class array<double> &Gaussian_table_GL , 
						  const class multipolar_expansion_str &multipolar_expansion , 
						  const class HF_nucleons_data &prot_HF_data , 
						  const class HF_nucleons_data &neut_HF_data);

    complex<double> neut_OBME_HF_nn_subpart_calc (
						  const class spherical_state &n_shell_in , 
						  const class spherical_state &n_shell_out , 
						  const class spherical_state &n_shell_occ , 
						  const class CG_str &CGs , 
						  const class interaction_class &inter_data_basis , 
						  const class array<double> &Gaussian_table_GL , 
						  const class multipolar_expansion_str &multipolar_expansion , 
						  const class HF_nucleons_data &neut_HF_data);

    complex<double> neut_OBME_HF_pn_subpart_calc (
						  const class spherical_state &n_shell_in , 
						  const class spherical_state &n_shell_out , 
						  const class spherical_state &p_shell_occ , 
						  const class CG_str &CGs , 
						  const class interaction_class &inter_data_basis , 
						  const class array<double> &Gaussian_table_GL , 
						  const class multipolar_expansion_str &multipolar_expansion , 
						  const class HF_nucleons_data &prot_HF_data , 
						  const class HF_nucleons_data &neut_HF_data);

    complex<double> prot_OBME_HF_pp_part_calc (
					       const class spherical_state &p_shell_in , 
					       const class spherical_state &p_shell_out , 
					       const class CG_str &CGs , 
					       const class interaction_class &inter_data_basis , 
					       const class array<double> &Gaussian_table_GL , 
					       const class multipolar_expansion_str &multipolar_expansion , 
					       const class HF_nucleons_data &prot_HF_data);

    complex<double> prot_OBME_HF_pn_part_calc (
					       const class spherical_state &p_shell_in , 
					       const class spherical_state &p_shell_out , 
					       const class CG_str &CGs , 
					       const class interaction_class &inter_data_basis , 
					       const class array<double> &Gaussian_table_GL , 
					       const class multipolar_expansion_str &multipolar_expansion , 
					       const class HF_nucleons_data &prot_HF_data , 
					       const class HF_nucleons_data &neut_HF_data);

    complex<double> neut_OBME_HF_nn_part_calc (
					       const class spherical_state &n_shell_in , 
					       const class spherical_state &n_shell_out , 
					       const class CG_str &CGs , 
					       const class interaction_class &inter_data_basis , 
					       const class array<double> &Gaussian_table_GL , 
					       const class multipolar_expansion_str &multipolar_expansion , 
					       const class HF_nucleons_data &neut_HF_data);

    complex<double> neut_OBME_HF_pn_part_calc (
					       const class spherical_state &n_shell_in , 
					       const class spherical_state &n_shell_out , 
					       const class CG_str &CGs , 
					       const class interaction_class &inter_data_basis , 
					       const class array<double> &Gaussian_table_GL , 
					       const class multipolar_expansion_str &multipolar_expansion , 
					       const class HF_nucleons_data &prot_HF_data , 
					       const class HF_nucleons_data &neut_HF_data);

    complex<double> prot_OBME_HF_calc (
				       const class spherical_state &p_shell_in , 
				       const class spherical_state &p_shell_out , 
				       const class CG_str &CGs , 
				       const class interaction_class &inter_data_basis , 
				       const class array<double> &Gaussian_table_GL , 
				       const class multipolar_expansion_str &multipolar_expansion , 
				       const class HF_nucleons_data &prot_HF_data , 
				       const class HF_nucleons_data &neut_HF_data);


    complex<double> neut_OBME_HF_calc (
				       const class spherical_state &n_shell_in , 
				       const class spherical_state &n_shell_out , 
				       const class CG_str &CGs , 
				       const class interaction_class &inter_data_basis , 
				       const class array<double> &Gaussian_table_GL , 
				       const class multipolar_expansion_str &multipolar_expansion , 
				       const class HF_nucleons_data &prot_HF_data , 
				       const class HF_nucleons_data &neut_HF_data);

    void prot_OBMEs_HF_calc (
			     const class CG_str &CGs , 
			     const class interaction_class &inter_data_basis , 
			     const class array<double> &Gaussian_table_GL , 
			     const class multipolar_expansion_str &multipolar_expansion , 
			     const class HF_nucleons_data &neut_HF_data , 
			     class HF_nucleons_data &prot_HF_data);

    void neut_OBMEs_HF_calc (
			     const class CG_str &CGs , 
			     const class interaction_class &inter_data_basis , 
			     const class array<double> &Gaussian_table_GL , 
			     const class multipolar_expansion_str &multipolar_expansion , 
			     const class HF_nucleons_data &prot_HF_data , 
			     class HF_nucleons_data &neut_HF_data);
  
    namespace HO_basis
    {
      double prot_OBME_HF_pp_subpart_calc (
					   const int lp , 
					   const double jp , 
					   const int n_HO_in , 
					   const int n_HO_out , 
					   const class spherical_state &p_shell_occ , 
					   const class CG_str &CGs , 
					   const class interaction_class &inter_data_basis , 
					   const class array<double> &Gaussian_table_GL , 
					   const class multipolar_expansion_str &multipolar_expansion , 
					   const class HF_nucleons_data &prot_HF_data);

      double prot_OBME_HF_pn_subpart_calc (
					   const int lp , 
					   const double jp , 
					   const int n_HO_in , 
					   const int n_HO_out , 
					   const class spherical_state &n_shell_occ , 
					   const class CG_str &CGs , 
					   const class interaction_class &inter_data_basis , 
					   const class array<double> &Gaussian_table_GL , 
					   const class multipolar_expansion_str &multipolar_expansion , 
					   const class HF_nucleons_data &prot_HF_data , 
					   const class HF_nucleons_data &neut_HF_data);

      double neut_OBME_HF_nn_subpart_calc (
					   const int ln , 
					   const double jn , 
					   const int n_HO_in , 
					   const int n_HO_out , 	
					   const class spherical_state &n_shell_occ , 
					   const class CG_str &CGs , 
					   const class interaction_class &inter_data_basis , 
					   const class array<double> &Gaussian_table_GL , 
					   const class multipolar_expansion_str &multipolar_expansion , 
					   const class HF_nucleons_data &neut_HF_data);

      double neut_OBME_HF_pn_subpart_calc (
					   const int ln , 
					   const double jn , 
					   const int n_HO_in , 
					   const int n_HO_out , 	
					   const class spherical_state &p_shell_occ , 
					   const class CG_str &CGs , 
					   const class interaction_class &inter_data_basis , 
					   const class array<double> &Gaussian_table_GL , 
					   const class multipolar_expansion_str &multipolar_expansion , 
					   const class HF_nucleons_data &prot_HF_data , 
					   const class HF_nucleons_data &neut_HF_data);

      double prot_OBME_HF_pp_part_calc (
					const int lp , 
					const double jp , 
					const int n_HO_in , 
					const int n_HO_out , 
					const class CG_str &CGs , 
					const class interaction_class &inter_data_basis , 
					const class array<double> &Gaussian_table_GL , 
					const class multipolar_expansion_str &multipolar_expansion , 
					const class HF_nucleons_data &prot_HF_data);

      double prot_OBME_HF_pn_part_calc (
					const int lp , 
					const double jp , 
					const int n_HO_in , 
					const int n_HO_out , 
					const class CG_str &CGs , 
					const class interaction_class &inter_data_basis , 
					const class array<double> &Gaussian_table_GL , 
					const class multipolar_expansion_str &multipolar_expansion , 
					const class HF_nucleons_data &prot_HF_data , 
					const class HF_nucleons_data &neut_HF_data);

      double neut_OBME_HF_nn_part_calc (
					const int ln , 
					const double jn , 
					const int n_HO_in , 
					const int n_HO_out , 
					const class CG_str &CGs , 
					const class interaction_class &inter_data_basis , 
					const class array<double> &Gaussian_table_GL , 
					const class multipolar_expansion_str &multipolar_expansion , 
					const class HF_nucleons_data &neut_HF_data);

      double neut_OBME_HF_pn_part_calc (
					const int ln , 
					const double jn , 
					const int n_HO_in , 
					const int n_HO_out , 	
					const class CG_str &CGs , 
					const class interaction_class &inter_data_basis , 
					const class array<double> &Gaussian_table_GL , 
					const class multipolar_expansion_str &multipolar_expansion , 
					const class HF_nucleons_data &prot_HF_data , 
					const class HF_nucleons_data &neut_HF_data);

      double prot_OBME_HF_calc (
				const int lp , 
				const double jp , 
				const int n_HO_in , 
				const int n_HO_out , 
				const class CG_str &CGs , 
				const class interaction_class &inter_data_basis , 
				const class array<double> &Gaussian_table_GL , 
				const class multipolar_expansion_str &multipolar_expansion , 
				const class HF_nucleons_data &prot_HF_data , 
				const class HF_nucleons_data &neut_HF_data);


      double neut_OBME_HF_calc (
				const int ln , 
				const double jn , 
				const int n_HO_in , 
				const int n_HO_out , 	
				const class CG_str &CGs , 
				const class interaction_class &inter_data_basis , 
				const class array<double> &Gaussian_table_GL , 
				const class multipolar_expansion_str &multipolar_expansion , 
				const class HF_nucleons_data &prot_HF_data , 
				const class HF_nucleons_data &neut_HF_data);

      double OBME_HF_calc (
			   const enum particle_type particle , 
			   const int l , 
			   const double j , 
			   const int n_HO_in , 
			   const int n_HO_out , 	
			   const class CG_str &CGs , 
			   const class interaction_class &inter_data_basis , 
			   const class array<double> &Gaussian_table_GL , 
			   const class multipolar_expansion_str &multipolar_expansion , 
			   const class HF_nucleons_data &prot_HF_data , 
			   const class HF_nucleons_data &neut_HF_data);
    }
  }

  namespace uniform_filling_approximation
  {
    void closed_shells_information_determine (
					      const class HF_nucleons_data &HF_data ,
					      bool &is_it_one_mu_above_closed_shells_mu ,
					      bool &is_it_one_mu_hole_above_closed_shells_mu ,
					      bool &is_it_mu_closed);
    
    void is_it_uniform_filling_approximation_determine (
							const enum interaction_type TBME_inter , 
							class HF_nucleons_data &prot_HF_data , 
							class HF_nucleons_data &neut_HF_data);

    unsigned int N_in_lj_shell_largest_n_calc (
					       const int l , 
					       const double j , 
					       const class HF_nucleons_data &HF_data);

    double J_coefficient_calc (
			       const int l , 
			       const double j , 
			       const int l_occ , 
			       const double j_occ , 
			       const int J ,  
			       const class CG_str &CGs , 
			       const class HF_nucleons_data &HF_data , 
			       const class HF_nucleons_data &HF_data_occ);
  }

  void U_finite_range_HF_HO_basis_HO_expansion_part_realloc_init (const class array<int> &nmax_HO_lab_tab , class nucleons_data &data);

  void Ueq_source_OBMEs_HF_SGI_MSGI_pm_realloc_init (
						     const enum interaction_type inter ,  
						     class nucleons_data &data);

  void is_it_HO_removal (class nucleons_data &data);

  void init_restore (
		     const class array<class nlj_struct> &old_shells_qn , 
		     class array<class nlj_struct> &shells_qn);

  void Ueq_finite_range_no_core_init_calc (const class interaction_class &inter_data_basis , class HF_nucleons_data &HF_data);

  void one_body_nuclear_hamiltonian_part_calc_init (const bool is_it_SGI_MSGI , class HF_nucleons_data &HF_data);

  void one_body_nuclear_hamiltonian_part_shells_pm_calc_init (const int pm , const bool is_it_SGI_MSGI , class HF_nucleons_data &HF_data);

  void potentials_in_zero_calc (const bool HO_diag , class HF_nucleons_data &HF_data);

  void potentials_in_zero_shells_pm_calc (const int pm , class HF_nucleons_data &HF_data);

  void trivially_equivalent_potentials_averaged_calc (
						      const bool HO_diag , 
						      const double new_potential_fraction , 
						      class HF_nucleons_data &HF_data);

  void potential_source_put_to_zero (
				     const class spherical_state &shell , 
				     class nlj_table<complex<double> > &Ueq_finite_range_tab_av_big , 
				     class nlj_table<complex<double> > &source_tab_av_big);

  void potentials_MPI_transfer (
				const enum space_type basis_space , 
				class HF_nucleons_data &HF_data);

  bool is_there_HF_calc_determine (
				   const bool OCM_basis , 
				   const class nucleons_data &prot_data , 
				   const class nucleons_data &neut_data);
  
  void iterative_potential_HO_removal_calc (
					    const bool is_there_cout ,
					    const class input_data_str &input_data , 
					    const class interaction_class &inter_data_basis_basis , 
					    class HF_nucleons_data &prot_HF_data , 
					    class HF_nucleons_data &neut_HF_data , 
					    class nucleons_data &prot_data , 
					    class nucleons_data &neut_data);
  
  void potentials_calc (
			const bool HO_diag , 
			const double new_potential_fraction , 
			const bool neutron_basis_potential , 
			const class CG_str &CGs , 
			const class interaction_class &inter_data_basis , 
			const class array<double> &Gaussian_table_GL , 
			const class multipolar_expansion_str &multipolar_expansion , 
			class HF_nucleons_data &prot_HF_data , 
			class HF_nucleons_data &neut_HF_data);
} 
#endif


