#ifndef GSMSD2PHDATASTR_H
#define GSMSD2PHDATASTR_H

// TYPE is double or complex
// -------------------------


class SD_2ph_data_str
{ 
public:
  SD_2ph_data_str ();

  SD_2ph_data_str (
		   const unsigned int C_2ph_table_index_c , 
		   const unsigned int im_left_c , 
		   const unsigned int im_right_c , 
		   const unsigned int SD_index_c , 
		   const unsigned int bin_phase_c); 

  void initialize (
		   const unsigned int C_2ph_table_index_c , 
		   const unsigned int im_left_c , 
		   const unsigned int im_right_c , 
		   const unsigned int SD_index_c , 
		   const unsigned int bin_phase_c); 
  
  void initialize (const class SD_2ph_data_str &X);
		   
  unsigned int get_C_2ph_table_index () const
  {
    return C_2ph_table_index;
  }
  
  unsigned int get_im_left () const
  {
    return im_left;
  }
 
  unsigned int get_im_right () const
  {
    return im_right;
  }

  unsigned int get_SD_index () const
  {
    return SD_index;
  }

  unsigned int get_bin_phase () const
  {
    return bin_phase;
  }

  unsigned int iM_pair_determine () const
  {
    const unsigned int iM_pair = im_left + im_right;

    return iM_pair;
  }

private:
  
  unsigned int C_2ph_table_index; // index of 2p-2h configuration jump

  unsigned char im_left; // m[alpha] + m[max] so that it is an integer
  
  unsigned char im_right; // m[beta] + m[max] so that it is an integer
  
  unsigned int SD_index; // the index of SD after the jump
  
  unsigned char bin_phase; // binary phase induced by a+/a operators
};

double used_memory_calc (const class SD_2ph_data_str &T);



#endif
