#ifndef GSMCMOBMESTBMES_H
#define GSMCMOBMESTBMES_H

// TYPE is double or complex
// -------------------------

namespace CM_OBMEs_TBMEs
{
  const class OBMEs_CM_set_str & OBMEs_CM_set_determine (
							 const bool is_it_HO_expansion ,
							 const class nucleons_data &data);
   
  const class array<TYPE> & reduced_grad_tab_determine (
							const enum operator_type CM_operator_inter ,
							const bool is_it_HO_expansion ,
							const class nucleons_data &data);
  
  const class array<TYPE> & reduced_r_tab_determine (
						     const enum operator_type CM_operator_inter ,
						     const bool is_it_HO_expansion ,
						     const class nucleons_data &data);
    
  const class array<TYPE> & reduced_r_tab_rms_radius_pn_determine (
								   const enum operator_type CM_operator_inter ,
								   const bool is_it_HO_expansion ,
								   const class nucleons_data &data);

  TYPE uncoupled_OBME (
		       const operator_type CM_operator_inter ,
		       const bool is_it_HO_expansion ,
		       const class nucleons_data &data ,
		       const unsigned int s_in ,
		       const unsigned int s_out);
  
  TYPE coupled_OBME (
		     const operator_type CM_operator_inter ,
		     const bool is_it_HO_expansion ,
		     const class nucleons_data &data ,
		     const unsigned int s_in ,
		     const unsigned int s_out);

  bool is_uncoupled_TBME_pp_nn_trivial_zero_determine (
						       const class array<class nljm_struct> &phi_table ,
						       const unsigned int s0 , 
						       const unsigned int s1 , 
						       const unsigned int s2 , 
						       const unsigned int s3);

  bool is_uncoupled_TBME_pn_trivial_zero_determine_coupling_only (
								  const class array<class nljm_struct> &phi_table ,
								  const unsigned int s_in , 
								  const unsigned int s_out);
  
  bool is_coupled_TBME_pp_nn_trivial_zero_determine (
						     const class array<class nlj_struct> &shells_qn , 
						     const unsigned int s0 , 
						     const unsigned int s1 , 
						     const unsigned int s2 , 
						     const unsigned int s3);
 
  bool is_coupled_TBME_pn_trivial_zero_determine (
						  const class array<class nlj_struct> &shells_qn_prot , 
						  const class array<class nlj_struct> &shells_qn_neut ,
						  const unsigned int s0 , 
						  const unsigned int s1 , 
						  const unsigned int s2 , 
						  const unsigned int s3);
 
  TYPE TBME_pp_nn_calc (
			const enum operator_type CM_operator_inter ,
			const enum particle_type particle , 
			const unsigned int s0 , 
			const unsigned int s1 , 
			const unsigned int s2 , 
			const unsigned int s3 , 
			const double angular_TBME_direct , 
			const double angular_TBME_exchange , 
			const class array<TYPE> &reduced_grad_tab , 
			const class array<TYPE> &reduced_r_tab);

  TYPE TBME_pn_calc (
		     const enum operator_type CM_operator_inter ,
		     const unsigned int s0 , 
		     const unsigned int s1 , 
		     const unsigned int s2 , 
		     const unsigned int s3 , 
		     const double angular_TBME , 
		     const class array<TYPE> &reduced_grad_prot_tab , 
		     const class array<TYPE> &reduced_grad_neut_tab , 
		     const class array<TYPE> &reduced_r_prot_tab , 
		     const class array<TYPE> &reduced_r_neut_tab);

  TYPE uncoupled_TBME_pp_nn_calc (
				  const enum operator_type CM_operator_inter ,
				  const bool is_it_HO_expansion ,
				  const class nucleons_data &data ,
				  const class CM_TBMEs_angular_table_str &TBMEs_angular_table ,
				  const unsigned int s0 , 
				  const unsigned int s1 , 
				  const unsigned int s2 , 
				  const unsigned int s3);

  TYPE uncoupled_TBME_pn_calc (
			       const enum operator_type CM_operator_inter ,
			       const bool is_it_HO_expansion ,
			       const class nucleons_data &prot_data ,
			       const class nucleons_data &neut_data ,
			       const class CM_TBMEs_angular_table_str &TBMEs_angular_table ,
			       const unsigned int s0 , 
			       const unsigned int s1 , 
			       const unsigned int s2 , 
			       const unsigned int s3);
  
  TYPE coupled_TBME_pp_nn_calc (
				const enum operator_type CM_operator_inter ,
				const bool is_it_HO_expansion ,
				const class nucleons_data &data ,
				const class CM_TBMEs_angular_table_str &TBMEs_angular_table ,
				const unsigned int s0 , 
				const unsigned int s1 , 
				const unsigned int s2 , 
				const unsigned int s3);
 
  TYPE coupled_TBME_pn_calc (
			     const enum operator_type CM_operator_inter ,
			     const bool is_it_HO_expansion ,
			     const class nucleons_data &prot_data ,
			     const class nucleons_data &neut_data ,
			     const class CM_TBMEs_angular_table_str &TBMEs_angular_table ,
			     const unsigned int s0 , 
			     const unsigned int s1 , 
			     const unsigned int s2 , 
			     const unsigned int s3);
}

#endif
