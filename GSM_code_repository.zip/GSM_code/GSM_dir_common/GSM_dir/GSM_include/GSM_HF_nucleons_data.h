#ifndef GSMHFNUCLEONSDATA_H
#define GSMHFNUCLEONSDATA_H

// TYPE is double or complex
// -------------------------

// Class storing data about protons or neutrons for the calculation of HF/MSDHF potentials
// ---------------------------------------------------------------------------------------

class HF_nucleons_data
{
public:
  
  // Constructors, destructors, allocation and deallocation
  // ------------------------------------------------------

  HF_nucleons_data ();
  
  HF_nucleons_data (
		    const class input_data_str &input_data , 
		    const class baryons_data &particles_data);

  HF_nucleons_data (const class HF_nucleons_data &X);

  void allocate (
		 const class input_data_str &input_data , 
		 const class baryons_data &particles_data);

  void allocate_fill (const class HF_nucleons_data &X);

  void deallocate ();

  // Simple routines providing with the value of private variables or setting them to a fixed value
  // ----------------------------------------------------------------------------------------------

  enum particle_type get_particle () const
  {
    return particle;
  }
  
  enum potential_type get_H_potential () const
  {
    return H_potential;
  }

  bool get_is_it_OCM_basis () const
  {
    return is_it_OCM_basis;
  }
  
  bool get_is_it_OCM_HO_core () const
  {
    return is_it_OCM_HO_core;
  }

  double get_R_cut_function () const
  {
    return R_cut_function;
  }

  double get_d_cut_function () const
  {
    return d_cut_function;
  }

  double get_Ueq_regularizor () const
  {
    return Ueq_regularizor;
  }

  int get_nmax () const
  {
    return nmax;
  }

  int get_lmax () const
  {
    return lmax;
  }
 
  double get_nucleon_mass_for_calc () const
  {
    return nucleon_mass_for_calc;
  }

  unsigned int get_N_nlj_res () const
  {
    return N_nlj_res;
  }

  unsigned int get_N_nlj () const
  {
    return N_nlj;
  }

  unsigned int get_N_bef_R_GL () const
  {
    return N_bef_R_GL;
  }

  unsigned int get_N_aft_R_GL () const
  {
    return N_aft_R_GL;
  }

  unsigned int get_N_bef_R_uniform () const
  {
    return N_bef_R_uniform;
  }

  unsigned int get_N_aft_R_uniform () const
  {
    return N_aft_R_uniform;
  }

  double get_R () const
  {
    return R;
  }

  double get_step_bef_R_uniform () const
  {
    return step_bef_R_uniform;
  }

  double get_R_real_max () const
  {
    return R_real_max;
  }

  double get_R_charge () const
  {
    return R_charge;
  }

  double get_nucleus_mass_basis () const
  {
    return nucleus_mass_basis;
  }

  int get_A_basis () const
  {
    return A_basis;
  }

  int get_N_valence_nucleons_basis () const
  {
    return N_valence_nucleons_basis;
  }

  int get_Z_charge_basis_potential () const
  {
    return Z_charge_basis_potential;
  }
  const class array<double> & get_V0_KKNN_tab () const
  {
    return V0_KKNN_tab;
  }
  
  const class array<double> & get_rho_KKNN_tab () const
  {
    return rho_KKNN_tab;
  }

  const class array<double> & get_Vls_KKNN_tab () const
  {
    return Vls_KKNN_tab;
  }
  
  const class array<double> & get_rho_ls_KKNN_tab () const
  {
    return rho_ls_KKNN_tab;
  }

  const class array<double> & get_V0_KKNN_basis_core_potential_tab () const
  {
    return V0_KKNN_basis_core_potential_tab;
  }
  
  const class array<double> & get_rho_KKNN_basis_core_potential_tab () const
  {
    return rho_KKNN_basis_core_potential_tab;
  }

  const class array<double> & get_Vls_KKNN_basis_core_potential_tab () const
  {
    return Vls_KKNN_basis_core_potential_tab;
  }
  
  const class array<double> & get_rho_ls_KKNN_basis_core_potential_tab () const
  {
    return rho_ls_KKNN_basis_core_potential_tab;
  }

  void set_is_it_uniform_filling_approximation (const bool is_it_uniform_filling_approximation_c)
  {
    is_it_uniform_filling_approximation = is_it_uniform_filling_approximation_c;
  }

  bool get_is_it_uniform_filling_approximation () const
  {
    return is_it_uniform_filling_approximation;
  }

  void set_single_particle (const bool single_particle_c)
  {
    single_particle = single_particle_c;
  }

  bool get_single_particle () const
  {
    return single_particle;
  }
  
  void set_Nshells_occ (const unsigned int Nshells_occ_c)
  {
    Nshells_occ = Nshells_occ_c;
  }

  unsigned int get_Nshells_occ () const
  {
    return Nshells_occ;
  }

  class array<double> & get_d_tab ()
  {
    return d_tab;
  }

  const class array<double> & get_d_tab () const
  {
    return d_tab;
  }

  class array<double> & get_R0_tab ()
  {
    return R0_tab;
  }

  const class array<double> & get_R0_tab () const
  {
    return R0_tab;
  }

  class array<double> & get_Vo_tab ()
  {
    return Vo_tab;
  }

  const class array<double> & get_Vo_tab () const
  {
    return Vo_tab;
  }

  class array<double> & get_Vso_tab ()
  {
    return Vso_tab;
  }

  const class array<double> & get_Vso_tab () const
  {
    return Vso_tab;
  }
  
  class array<double> & get_HO_wfs_uniform ()
  {
    return HO_wfs_uniform;
  }

  const class array<double> & get_HO_wfs_uniform () const
  {
    return HO_wfs_uniform;
  }
  
  class array<double> & get_HO_wfs_GL ()
  {
    return HO_wfs_GL;
  }

  const class array<double> & get_HO_wfs_GL () const
  {
    return HO_wfs_GL;
  }
  
  class array<double> & get_d_basis_tab ()
  {
    return d_basis_tab;
  }

  const class array<double> & get_d_basis_tab () const
  {
    return d_basis_tab;
  }

  class array<double> & get_R0_basis_tab ()
  {
    return R0_basis_tab;
  }

  const class array<double> & get_R0_basis_tab () const
  {
    return R0_basis_tab;
  }

  class array<double> & get_Vo_basis_tab ()
  {
    return Vo_basis_tab;
  }

  const class array<double> & get_Vo_basis_tab () const
  {
    return Vo_basis_tab;
  }

  class array<double> & get_Vso_basis_tab ()
  {
    return Vso_basis_tab;
  }

  const class array<double> & get_Vso_basis_tab () const
  {
    return Vso_basis_tab;
  }

  class array<class nlj_struct> & get_shells_quantum_numbers ()
  {
    return shells_quantum_numbers;
  }

  const class array<class nlj_struct> & get_shells_quantum_numbers () const
  {
    return shells_quantum_numbers;
  }

  class array<class nlj_struct> & get_shells_quantum_numbers_res ()
  {
    return shells_quantum_numbers_res;
  }

  const class array<class nlj_struct> & get_shells_quantum_numbers_res () const
  {
    return shells_quantum_numbers_res;
  }

  class nlj_table<unsigned int> & get_N_valence_nucleons_in_shell_tab ()
  {
    return N_valence_nucleons_in_shell_tab;
  }

  const class nlj_table<unsigned int> & get_N_valence_nucleons_in_shell_tab () const
  {
    return N_valence_nucleons_in_shell_tab;
  }

  class nlj_table<complex<double> > & get_k_bef_tab ()
  {
    return k_bef_tab;
  }

  const class nlj_table<complex<double> > & get_k_bef_tab () const
  {
    return k_bef_tab;
  }

  class nlj_table<complex<double> > & get_Ueq_finite_range_tab_uniform ()
  {
    return Ueq_finite_range_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_tab_uniform () const
  {
    return Ueq_finite_range_tab_uniform;
  }

  class nlj_table<complex<double> > & get_Ueq_finite_range_averaged_tab_uniform ()
  {
    return Ueq_finite_range_averaged_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_averaged_tab_uniform () const
  {
    return Ueq_finite_range_averaged_tab_uniform;
  }
  
  class nlj_table<complex<double> > & get_source_tab_uniform ()
  {
    return source_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_source_tab_uniform () const
  {
    return source_tab_uniform;
  }

  class nlj_table<complex<double> > & get_source_averaged_tab_uniform ()
  {
    return source_averaged_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_source_averaged_tab_uniform () const
  {
    return source_averaged_tab_uniform;
  }
  
  class nlj_table<complex<double> > & get_Ueq_finite_range_res_tab_uniform ()
  {
    return Ueq_finite_range_res_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_res_tab_uniform () const
  {
    return Ueq_finite_range_res_tab_uniform;
  }

  class nlj_table<complex<double> > & get_Ueq_finite_range_res_averaged_tab_uniform ()
  {
    return Ueq_finite_range_res_averaged_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_res_averaged_tab_uniform () const
  {
    return Ueq_finite_range_res_averaged_tab_uniform;
  }
  
  class nlj_table<complex<double> > & get_source_res_tab_uniform ()
  {
    return source_res_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_source_res_tab_uniform () const
  {
    return source_res_tab_uniform;
  }

  class nlj_table<complex<double> > & get_source_res_averaged_tab_uniform ()
  {
    return source_res_averaged_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_source_res_averaged_tab_uniform () const
  {
    return source_res_averaged_tab_uniform;
  }
  
  class nlj_table<complex<double> > & get_Ueq_finite_range_plus_tab_uniform ()
  {
    return Ueq_finite_range_plus_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_plus_tab_uniform () const
  {
    return Ueq_finite_range_plus_tab_uniform;
  }

  class nlj_table<complex<double> > & get_Ueq_finite_range_plus_averaged_tab_uniform ()
  {
    return Ueq_finite_range_plus_averaged_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_plus_averaged_tab_uniform () const
  {
    return Ueq_finite_range_plus_averaged_tab_uniform;
  }
  
  class nlj_table<complex<double> > & get_source_plus_tab_uniform ()
  {
    return source_plus_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_source_plus_tab_uniform () const
  {
    return source_plus_tab_uniform;
  }

  class nlj_table<complex<double> > & get_source_plus_averaged_tab_uniform ()
  {
    return source_plus_averaged_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_source_plus_averaged_tab_uniform () const
  {
    return source_plus_averaged_tab_uniform;
  }

  class nlj_table<complex<double> > & get_Ueq_finite_range_minus_tab_uniform ()
  {
    return Ueq_finite_range_minus_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_minus_tab_uniform () const
  {
    return Ueq_finite_range_minus_tab_uniform;
  }

  class nlj_table<complex<double> > & get_Ueq_finite_range_minus_averaged_tab_uniform ()
  {
    return Ueq_finite_range_minus_averaged_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_minus_averaged_tab_uniform () const
  {
    return Ueq_finite_range_minus_averaged_tab_uniform;
  }
  
  class nlj_table<complex<double> > & get_source_minus_tab_uniform ()
  {
    return source_minus_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_source_minus_tab_uniform () const
  {
    return source_minus_tab_uniform;
  }

  class nlj_table<complex<double> > & get_source_minus_averaged_tab_uniform ()
  {
    return source_minus_averaged_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_source_minus_averaged_tab_uniform () const
  {
    return source_minus_averaged_tab_uniform;
  }
  
  class nlj_table<complex<double> > & get_Ueq_finite_range_tab_GL ()
  {
    return Ueq_finite_range_tab_GL;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_tab_GL () const
  {
    return Ueq_finite_range_tab_GL;
  }

  class nlj_table<complex<double> > & get_Ueq_finite_range_averaged_tab_GL ()
  {
    return Ueq_finite_range_averaged_tab_GL;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_averaged_tab_GL () const
  {
    return Ueq_finite_range_averaged_tab_GL;
  }
  
  class nlj_table<complex<double> > & get_source_tab_GL ()
  {
    return source_tab_GL;
  }

  const class nlj_table<complex<double> > & get_source_tab_GL () const
  {
    return source_tab_GL;
  }

  class nlj_table<complex<double> > & get_source_averaged_tab_GL ()
  {
    return source_averaged_tab_GL;
  }

  const class nlj_table<complex<double> > & get_source_averaged_tab_GL () const
  {
    return source_averaged_tab_GL;
  }
  
  class nlj_table<complex<double> > & get_Ueq_finite_range_res_tab_GL ()
  {
    return Ueq_finite_range_res_tab_GL;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_res_tab_GL () const
  {
    return Ueq_finite_range_res_tab_GL;
  }

  class nlj_table<complex<double> > & get_Ueq_finite_range_res_averaged_tab_GL ()
  {
    return Ueq_finite_range_res_averaged_tab_GL;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_res_averaged_tab_GL () const
  {
    return Ueq_finite_range_res_averaged_tab_GL;
  }
  
  class nlj_table<complex<double> > & get_source_res_tab_GL ()
  {
    return source_res_tab_GL;
  }

  const class nlj_table<complex<double> > & get_source_res_tab_GL () const
  {
    return source_res_tab_GL;
  }

  class nlj_table<complex<double> > & get_source_res_averaged_tab_GL ()
  {
    return source_res_averaged_tab_GL;
  }

  const class nlj_table<complex<double> > & get_source_res_averaged_tab_GL () const
  {
    return source_res_averaged_tab_GL;
  }
  
  class nlj_table<complex<double> > & get_Ueq_finite_range_plus_tab_GL ()
  {
    return Ueq_finite_range_plus_tab_GL;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_plus_tab_GL () const
  {
    return Ueq_finite_range_plus_tab_GL;
  }

  class nlj_table<complex<double> > & get_Ueq_finite_range_plus_averaged_tab_GL ()
  {
    return Ueq_finite_range_plus_averaged_tab_GL;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_plus_averaged_tab_GL () const
  {
    return Ueq_finite_range_plus_averaged_tab_GL;
  }
  
  class nlj_table<complex<double> > & get_source_plus_tab_GL ()
  {
    return source_plus_tab_GL;
  }

  const class nlj_table<complex<double> > & get_source_plus_tab_GL () const
  {
    return source_plus_tab_GL;
  }

  class nlj_table<complex<double> > & get_source_plus_averaged_tab_GL ()
  {
    return source_plus_averaged_tab_GL;
  }

  const class nlj_table<complex<double> > & get_source_plus_averaged_tab_GL () const
  {
    return source_plus_averaged_tab_GL;
  }

  class nlj_table<complex<double> > & get_Ueq_finite_range_minus_tab_GL ()
  {
    return Ueq_finite_range_minus_tab_GL;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_minus_tab_GL () const
  {
    return Ueq_finite_range_minus_tab_GL;
  }

  class nlj_table<complex<double> > & get_Ueq_finite_range_minus_averaged_tab_GL ()
  {
    return Ueq_finite_range_minus_averaged_tab_GL;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_minus_averaged_tab_GL () const
  {
    return Ueq_finite_range_minus_averaged_tab_GL;
  }
  
  class nlj_table<complex<double> > & get_source_minus_tab_GL ()
  {
    return source_minus_tab_GL;
  }

  const class nlj_table<complex<double> > & get_source_minus_tab_GL () const
  {
    return source_minus_tab_GL;
  }

  class nlj_table<complex<double> > & get_source_minus_averaged_tab_GL ()
  {
    return source_minus_averaged_tab_GL;
  }

  const class nlj_table<complex<double> > & get_source_minus_averaged_tab_GL () const
  {
    return source_minus_averaged_tab_GL;
  }

  class nlj_table<complex<double> > & get_Ueq_SGI_MSGI_tab_GL ()
  {
    return Ueq_SGI_MSGI_tab_GL;
  }

  const class nlj_table<complex<double> > & get_Ueq_SGI_MSGI_tab_GL () const
  {
    return Ueq_SGI_MSGI_tab_GL;
  }

  class nlj_table<complex<double> > & get_source_SGI_MSGI_tab_GL ()
  {
    return source_SGI_MSGI_tab_GL;
  }

  const class nlj_table<complex<double> > & get_source_SGI_MSGI_tab_GL () const
  {
    return source_SGI_MSGI_tab_GL;
  }

  class nlj_table<complex<double> > & get_Ueq_SGI_MSGI_res_tab_GL ()
  {
    return Ueq_SGI_MSGI_res_tab_GL;
  }

  const class nlj_table<complex<double> > & get_Ueq_SGI_MSGI_res_tab_GL () const
  {
    return Ueq_SGI_MSGI_res_tab_GL;
  }

  class nlj_table<complex<double> > & get_source_SGI_MSGI_res_tab_GL ()
  {
    return source_SGI_MSGI_res_tab_GL;
  }

  const class nlj_table<complex<double> > & get_source_SGI_MSGI_res_tab_GL () const
  {
    return source_SGI_MSGI_res_tab_GL;
  }
  
  class nlj_table<complex<double> > & get_Ueq_SGI_MSGI_plus_tab_GL ()
  {
    return Ueq_SGI_MSGI_plus_tab_GL;
  }

  const class nlj_table<complex<double> > & get_Ueq_SGI_MSGI_plus_tab_GL () const
  {
    return Ueq_SGI_MSGI_plus_tab_GL;
  }

  class nlj_table<complex<double> > & get_source_SGI_MSGI_plus_tab_GL ()
  {
    return source_SGI_MSGI_plus_tab_GL;
  }

  const class nlj_table<complex<double> > & get_source_SGI_MSGI_plus_tab_GL () const
  {
    return source_SGI_MSGI_plus_tab_GL;
  }

  class nlj_table<complex<double> > & get_Ueq_SGI_MSGI_minus_tab_GL ()
  {
    return Ueq_SGI_MSGI_minus_tab_GL;
  }

  const class nlj_table<complex<double> > & get_Ueq_SGI_MSGI_minus_tab_GL () const
  {
    return Ueq_SGI_MSGI_minus_tab_GL;
  }

  class nlj_table<complex<double> > & get_source_SGI_MSGI_minus_tab_GL ()
  {
    return source_SGI_MSGI_minus_tab_GL;
  }

  const class nlj_table<complex<double> > & get_source_SGI_MSGI_minus_tab_GL () const
  {
    return source_SGI_MSGI_minus_tab_GL;
  }

  class lj_table<class matrix<complex<double> > > & get_U_finite_range_HF_HO_basis_HO_expansion_part ()
  {
    return U_finite_range_HF_HO_basis_HO_expansion_part;
  }

  const class lj_table<class matrix<complex<double> > > & get_U_finite_range_HF_HO_basis_HO_expansion_part () const
  {
    return U_finite_range_HF_HO_basis_HO_expansion_part;
  }

  class array<class vector_class<complex<double> > > & get_HO_overlaps ()
  {
    return HO_overlaps;
  }

  const class array<class vector_class<complex<double> > > & get_HO_overlaps () const
  {
    return HO_overlaps;
  }

  class array<class vector_class<complex<double> > > & get_HO_overlaps_res ()
  {
    return HO_overlaps_res;
  }

  const class array<class vector_class<complex<double> > > & get_HO_overlaps_res () const
  {
    return HO_overlaps_res;
  }

  class array<class vector_class<complex<double> > > & get_HO_overlaps_plus ()
  {
    return HO_overlaps_plus;
  }

  const class array<class vector_class<complex<double> > > & get_HO_overlaps_plus () const
  {
    return HO_overlaps_plus;
  }

  class array<class vector_class<complex<double> > > & get_HO_overlaps_minus ()
  {
    return HO_overlaps_minus;
  }

  const class array<class vector_class<complex<double> > > & get_HO_overlaps_minus () const
  {
    return HO_overlaps_minus;
  }
  
  class array<class vector_class<complex<double> > > & get_HO_overlaps_Fermi ()
  {
    return HO_overlaps_Fermi;
  }

  const class array<class vector_class<complex<double> > > & get_HO_overlaps_Fermi () const
  {
    return HO_overlaps_Fermi;
  }

  class array<class vector_class<complex<double> > > & get_HO_overlaps_Fermi_res ()
  {
    return HO_overlaps_Fermi_res;
  }

  const class array<class vector_class<complex<double> > > & get_HO_overlaps_Fermi_res () const
  {
    return HO_overlaps_Fermi_res;
  }

  class array<class vector_class<complex<double> > > & get_HO_overlaps_Fermi_plus ()
  {
    return HO_overlaps_Fermi_plus;
  }

  const class array<class vector_class<complex<double> > > & get_HO_overlaps_Fermi_plus () const
  {
    return HO_overlaps_Fermi_plus;
  }

  class array<class vector_class<complex<double> > > & get_HO_overlaps_Fermi_minus ()
  {
    return HO_overlaps_Fermi_minus;
  }

  const class array<class vector_class<complex<double> > > & get_HO_overlaps_Fermi_minus () const
  {
    return HO_overlaps_Fermi_minus;
  }

  class array<class spherical_state > & get_shells ()
  {
    return shells;
  }

  const class array<class spherical_state > & get_shells () const
  {
    return shells;
  }
  
  class array<class spherical_state > & get_shells_res ()
  {
    return shells_res;
  }

  const class array<class spherical_state > & get_shells_res () const
  {
    return shells_res;
  }

  class array<class spherical_state > & get_shells_plus ()
  {
    return shells_plus;
  }

  const class array<class spherical_state > & get_shells_plus () const
  {
    return shells_plus;
  }

  class array<class spherical_state > & get_shells_minus ()
  {
    return shells_minus;
  }

  const class array<class spherical_state > & get_shells_minus () const
  {
    return shells_minus;
  }

  class lj_table<bool> & get_is_partial_wave_optimized_HF_MSDHF_tab ()
  {
    return is_partial_wave_optimized_HF_MSDHF_tab;
  }

  const class lj_table<bool> & get_is_partial_wave_optimized_HF_MSDHF_tab () const
  {
    return is_partial_wave_optimized_HF_MSDHF_tab;
  }

  class lj_table<int> & get_highest_occupied_n_tab ()
  {
    return highest_occupied_n_tab;
  }

  const class lj_table<int> & get_highest_occupied_n_tab () const
  {
    return highest_occupied_n_tab;
  }

  class lj_table<class pair_str> & get_occupied_pairs ()
  {
    return occupied_pairs;
  }

  const class lj_table<class pair_str> & get_occupied_pairs () const
  {
    return occupied_pairs;
  }
  
  class lj_table<class configuration> & get_configurations_to_diagonalize ()
  {
    return configurations_to_diagonalize;
  }

  const class lj_table<class configuration> & get_configurations_to_diagonalize () const
  {
    return configurations_to_diagonalize;
  }

  class lj_table<unsigned int> & get_dimensions_GS ()
  {
    return dimensions_GS;
  }

  const class lj_table<unsigned int> & get_dimensions_GS () const
  {
    return dimensions_GS;
  }

  class lj_table<class array<class Slater_determinant > > & get_SDp_tab_GS ()
  {
    return SDp_tab_GS;
  }

  const class lj_table<class array<class Slater_determinant > > & get_SDp_tab_GS () const
  {
    return SDp_tab_GS;
  }

  class lj_table<class array<class Slater_determinant > > & get_SDn_tab_GS ()
  {
    return SDn_tab_GS;
  }

  const class lj_table<class array<class Slater_determinant > > & get_SDn_tab_GS () const
  {
    return SDn_tab_GS;
  }

  class lj_table<class array<complex<double> > > & get_SDs_GS_coefficients ()
  {
    return SDs_GS_coefficients;
  }

  const class lj_table<class array<complex<double> > > & get_SDs_GS_coefficients () const
  {
    return SDs_GS_coefficients;
  }

  class lj_table<class array<class Slater_determinant > > & get_SDs_1h ()
  {
    return SDs_1h;
  }

  const class lj_table<class array<class Slater_determinant > > & get_SDs_1h () const
  {
    return SDs_1h;
  }

  class lj_table<class array<complex<double> > > & get_SDs_1h_coefficients ()
  {
    return SDs_1h_coefficients;
  }

  const class lj_table<class array<complex<double> > > & get_SDs_1h_coefficients () const
  {
    return SDs_1h_coefficients;
  }

  class lj_table<class array<bool> > & get_SDs_1h_existence_tab ()
  {
    return SDs_1h_existence_tab;
  }

  const class lj_table<class array<bool> > & get_SDs_1h_existence_tab () const
  {
    return SDs_1h_existence_tab;
  }

  class lj_table<complex<double> > & get_U_HF_normalizing_sums ()
  {
    return U_HF_normalizing_sums;
  }

  const class lj_table<complex<double> > & get_U_HF_normalizing_sums () const
  {
    return U_HF_normalizing_sums;
  }

  class lj_table<complex<double> > & get_OBMEs_HF_SGI_MSGI ()
  {
    return OBMEs_HF_SGI_MSGI;
  }

  const class lj_table<complex<double> > & get_OBMEs_HF_SGI_MSGI () const
  {
    return OBMEs_HF_SGI_MSGI;
  }

  class lj_table<double> & get_b_lab_partial_waves ()
  {
    return b_lab_partial_waves;
  }

  const class lj_table<double> & get_b_lab_partial_waves () const
  {
    return b_lab_partial_waves;
  }

  class lj_table<int> & get_nmin_lj_valence_tab ()
  {
    return nmin_lj_valence_tab;
  }

  const class lj_table<int> & get_nmin_lj_valence_tab () const
  {
    return nmin_lj_valence_tab;
  }
  
  class lj_table<complex<double> > & get_shells_OCM_core_states_overlaps ()
  {
    return shells_OCM_core_states_overlaps;
  }

  const class lj_table<complex<double> > & get_shells_OCM_core_states_overlaps () const
  {
    return shells_OCM_core_states_overlaps;
  }

  class lj_table<class matrix<complex<double> > > & get_php_matrices ()
  {
    return php_matrices;
  }

  const class lj_table<class matrix<complex<double> > > & get_php_matrices () const
  {
    return php_matrices;
  }

  bool is_it_filled () const
  {
    return (particle != NO_PARTICLE);
  }
  
  void copy_data_shells_alloc_calc (
				    const enum potential_type basis_potential , 
				    const class HF_nucleons_data &X);

  friend double used_memory_calc (const class HF_nucleons_data &T);
  
private:
  
  enum particle_type particle;      // proton or neutron

  enum potential_type H_potential;  // potential used in the Hamiltonian

  bool is_it_OCM_basis;             // true one uses the OCM potential, for example a WS basis potential to which a part is added for all basis wave functions to be orthogonal to core functions

  bool is_it_OCM_HO_core;           // true all occupied core states are HO states when one uses COSM, false if not

  double R_cut_function;            // radius and diffuseness of the Fermi cut function (see basic_maths.cpp) used to suppress potential at large distance for numerical stability
  double d_cut_function;

  double Ueq_regularizor;           // The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2))     
                                    // The non-local potential U(r,r') applied a wave function is written Ueq(r).u(r) + S(r), where Ueq(r) is the equivalent potential and S(r) the source.
                                    // Ueq(r) = [1 - F(r)] \int U(r,r') u(r') dr' / u(r) and S(r) = F(r) \int U(r,r') u(r') dr', 
                                    // with F(r) a regularizing factor preventing from Ueq(r) to diverge if u(r) = 0, which is numerically non-zero only close to the zeroes of u(r).
                                    // The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
                                    //                  Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, 
                                    // and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
                                    //                  The ratio |u(r)|^2/|u'(r)|^2 prevents F(r) to be non zero when r -> +oo.
                                    //                  Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
                                    // The equivalent potential and source calculated on the [0:2.R0] radial grid (before R), with R0 the radius of the SGI/MSGI interaction, 
                                    // are splined here to be calculated on the [0:R] radial grid with Gauss-Legendre and uniformly spaced radii.

  int nmax;                         // maximal principal quantum number and orbital angular momentum of protons or neutrons
  int lmax; 

  double nucleon_mass_for_calc;     // mass of the nucleon in the calculation of one-body wave functions. It does not have to be exactly equal to an experimental value.

  unsigned int N_nlj_res;           // number of shells, for all shells (N_nlj) or only bound and resonant (N_nlj_res) shells, for which n,l,j are fixed
  unsigned int N_nlj;

  unsigned int N_bef_R_GL;          // number of points on Gauss-Legendre (GL) and uniform grids on [0:R] and [R:R_real_max], with R the rotation point and R_real_max the largest considered radius on the real axis       
  unsigned int N_aft_R_GL;

  unsigned int N_bef_R_uniform;         // number of points on uniform grids on [0:R] (before R) and [R:R_real_max], [0:1/R^4] (after R) (see spherical_state.cpp).
  unsigned int N_aft_R_uniform;         // It is called uniform as its number of points is typically 10 times that of Gauss-Legendre.


  double R;                         // rotation point of complex scaling

  double step_bef_R_uniform;            // radial step on the uniform grid on [0:R], with R the rotation point

  double R_real_max;                // maximal radius considered on the real-axis. All HO states must be negligible therein.

  double R_charge;                  // charge radius used in the Coulomb potentia

  double nucleus_mass_basis;        // mass of nucleus with the basis interaction. It is the mass of the core if one has a core and that of the total nucleus if not.

  int A_basis;                      // number of nucleons of the total nucleus used for basis generation

  int N_valence_nucleons_basis;     // number of valence nucleons of the total nucleus used for basis generation

  int Z_charge_basis_potential;     // charge used in the basis-generating potential

  bool is_it_uniform_filling_approximation; // true if uniform filling approximation is used, false if not

  bool single_particle;                     // true if one is in the case of one particle above closed shells, false if not

  unsigned int Nshells_occ;                 // total number of occupied shells
  
  class array<double> V0_KKNN_tab;     // Central strength array of the set of KKNN parameters for each particle type
  class array<double> rho_KKNN_tab;    // Central length array of the set of KKNN parameters for each particle type
  class array<double> Vls_KKNN_tab;    // Spin-orbit strength array of the set of KKNN parameter for each particle type
  class array<double> rho_ls_KKNN_tab; // Spin-orbit length array of the set of KKNN parameters for each particle type
  
  class array<double> V0_KKNN_basis_core_potential_tab;     // Central strength array of the set of KKNN parameters for each particle type for basis core potential
  class array<double> rho_KKNN_basis_core_potential_tab;    // Central length array of the set of KKNN parameters for each particle type for basis core potential
  class array<double> Vls_KKNN_basis_core_potential_tab;    // Spin-orbit strength array of the set of KKNN parameter for each particle type for basis core potential
  class array<double> rho_ls_KKNN_basis_core_potential_tab; // Spin-orbit length array of the set of KKNN parameters for each particle type for basis core potential
    
  class array<double> HO_wfs_uniform;           // arrays of HO wave functions with uniform and Gauss-Legendre radii on the [0:R] radial grid, with R the rotation point, functions of n_HO, l and radius index
  class array<double> HO_wfs_GL;
  
  class array<double> d_tab;                // diffuseness array function of orbital angular momentum of the Hamiltonian core set of WS parameters
  class array<double> R0_tab;               // Radii array function of orbital angular momentum of the Hamiltonian core set of WS parameters
  class array<double> Vo_tab;               // Central strength array function of orbital angular momentum of the Hamiltonian core set of WS parameters 
  class array<double> Vso_tab;              // Spin-orbit strength array function of orbital angular momentum of the Hamiltonian core set of WS parameters
 
  class array<double> d_basis_tab;          // diffuseness array function of orbital angular momentum of the basis set of WS parameters
  class array<double> R0_basis_tab;         // Radii array function of orbital angular momentum of the basis set of WS parameters
  class array<double> Vo_basis_tab;         // Central strength array function of orbital angular momentum of the basis set of WS parameters 
  class array<double> Vso_basis_tab;        // Spin-orbit strength array function of orbital angular momentum of the basis set of WS parameters

  class array<class nlj_struct> shells_quantum_numbers;      // array of structures containing data about shells, in particular quantum_numbers, from which wave functions are excluded
  class array<class nlj_struct> shells_quantum_numbers_res;  // array of structures containing data about shells, for only bound and resonant (res) states, in particular quantum_numbers, from which wave functions are excluded

  class nlj_table<unsigned int> N_valence_nucleons_in_shell_tab; // (n,l,j) array of the number of valence nucleons occupied in a given shell at HF level
  
  class nlj_table<complex<double> > k_bef_tab;                   // (n,l,j) array of the linear momenta of the shells obtained during the previous iteraction

  class lj_table<class matrix<complex<double> > > U_finite_range_HF_HO_basis_HO_expansion_part; // arrays of the HO expansion of the finite-range part of the HF/MSDHF or OCM potential given in HO basis






  // Ueq_finite_range_tab_uniform, source_tab_uniform, Ueq_finite_range_tab_uniform, source_tab_uniform (res, plus, or minus also added)
  // -------------------------------------------------------------------------------------------------------------------
  // equivalent potential Ueq(r) and source S(r) function of n,l,j and on the uniform grid on [0:R], 
  // for all shells (name without res) or only bound and resonant (name with res) states, to multiply by the linear mixing constant
  //
  // Ueq_finite_range_tab_GL, source_tab_GL, Ueq_finite_range_tab_GL, source_tab_GL (res, plus, or minus also added)
  // ---------------------------------------------------------------------------------------------------------------
  // equivalent potential Ueq(r) and source S(r) function of n,l,j and on the Gauss-Legendre grid on [0:R],
  // for all shells (name without res) or only bound and resonant (name with res) states, to multiply by the linear mixing constant
  //
  // Ueq_finite_range_averaged_tab_uniform, source_averaged_tab_uniform, Ueq_finite_range_averaged_tab_uniform, source_averaged_tab_uniform (res, plus, or minus also added)
  // -------------------------------------------------------------------------------------------------------------------------------------------------------
  // averaged equivalent potential Ueq(r) and source S(r) function of n,l,j and on the uniform grid on [0:R], 
  // for all shells (name without res) or only bound and resonant (name with res) states, 
  // functions of the newly calculated equivalent potential Ueq(r) and source S(r) multiplied by the linear mixing constant 
  // and the previous equivalent potential Ueq(r) and source S(r) (stored in these arrays) multiplied by one minus the linear mixing constant
  //
  // Ueq_finite_range_averaged_tab_GL, source_averaged_tab_GL, Ueq_finite_range_averaged_tab_GL, source_averaged_tab_GL (res, plus, or minus also added)
  // ---------------------------------------------------------------------------------------------------------------------------------------------------
  // averaged equivalent potential Ueq(r) and source S(r) function of n,l,j and on the Gauss-Legendre grid on [0:R],
  // for all shells (name without res) or only bound and resonant (name with res) states,
  // functions of the newly calculated equivalent potential Ueq(r) and source S(r) multiplied by the linear mixing constant 
  // and the previous equivalent potential Ueq(r) and source S(r) (stored in these arrays) multiplied by one minus the linear mixing constant
  //
  // The former data with "plus/minus (i.e. +/- 1)" added in their names means that one considers the equivalent potentials of the states 
  // for which k +/- w/(4 Pi) with protons for Coulomb complex scaling (see H_CM_OBMEs.cpp).

  class nlj_table<complex<double> > Ueq_finite_range_tab_uniform; 
  class nlj_table<complex<double> > Ueq_finite_range_averaged_tab_uniform;

  class nlj_table<complex<double> > source_tab_uniform; 
  class nlj_table<complex<double> > source_averaged_tab_uniform;
  
  class nlj_table<complex<double> > Ueq_finite_range_res_tab_uniform; 
  class nlj_table<complex<double> > Ueq_finite_range_res_averaged_tab_uniform;

  class nlj_table<complex<double> > source_res_tab_uniform; 
  class nlj_table<complex<double> > source_res_averaged_tab_uniform;
  
  class nlj_table<complex<double> > Ueq_finite_range_plus_tab_uniform; 
  class nlj_table<complex<double> > Ueq_finite_range_plus_averaged_tab_uniform;

  class nlj_table<complex<double> > source_plus_tab_uniform; 
  class nlj_table<complex<double> > source_plus_averaged_tab_uniform;
  
  class nlj_table<complex<double> > Ueq_finite_range_minus_tab_uniform; 
  class nlj_table<complex<double> > Ueq_finite_range_minus_averaged_tab_uniform;

  class nlj_table<complex<double> > source_minus_tab_uniform; 
  class nlj_table<complex<double> > source_minus_averaged_tab_uniform;
  
  class nlj_table<complex<double> > Ueq_finite_range_tab_GL; 
  class nlj_table<complex<double> > Ueq_finite_range_averaged_tab_GL;

  class nlj_table<complex<double> > source_tab_GL; 
  class nlj_table<complex<double> > source_averaged_tab_GL;
  
  class nlj_table<complex<double> > Ueq_finite_range_res_tab_GL; 
  class nlj_table<complex<double> > Ueq_finite_range_res_averaged_tab_GL;

  class nlj_table<complex<double> > source_res_tab_GL; 
  class nlj_table<complex<double> > source_res_averaged_tab_GL;
  
  class nlj_table<complex<double> > Ueq_finite_range_plus_tab_GL; 
  class nlj_table<complex<double> > Ueq_finite_range_plus_averaged_tab_GL;

  class nlj_table<complex<double> > source_plus_tab_GL; 
  class nlj_table<complex<double> > source_plus_averaged_tab_GL;
  
  class nlj_table<complex<double> > Ueq_finite_range_minus_tab_GL; 
  class nlj_table<complex<double> > Ueq_finite_range_minus_averaged_tab_GL;

  class nlj_table<complex<double> > source_minus_tab_GL; 
  class nlj_table<complex<double> > source_minus_averaged_tab_GL;
  



  // Ueq_SGI_MSGI_tab_GL, source_SGI_MSGI_tab_GL, Ueq_SGI_MSGI_tab_uniform, source_SGI_MSGI_tab_uniform (res, plus, or minus also added)
  // ------------------------------------------------------------------------------------------------------------------------------------
  // equivalent HF potential and its associated source on Gauss-Legendre and uniform grids on [0:2.R0] with R0 the radius of the SGI/MSGI interaction
  // for all shells (name without res) or only bound and resonant (name with res) states
  //
  // The former data with "plus/minus (i.e. +/- 1)" added in their names means that one considers the equivalent potentials of the states 
  // for which k +/- w/(4 Pi) with protons for Coulomb complex scaling (see H_CM_OBMEs.cpp).

  class nlj_table<complex<double> > Ueq_SGI_MSGI_tab_GL; 
  class nlj_table<complex<double> > Ueq_SGI_MSGI_res_tab_GL; 

  class nlj_table<complex<double> > source_SGI_MSGI_tab_GL;
  class nlj_table<complex<double> > source_SGI_MSGI_res_tab_GL;
  
  class nlj_table<complex<double> > Ueq_SGI_MSGI_plus_tab_GL; 
  class nlj_table<complex<double> > Ueq_SGI_MSGI_minus_tab_GL; 

  class nlj_table<complex<double> > source_SGI_MSGI_plus_tab_GL;
  class nlj_table<complex<double> > source_SGI_MSGI_minus_tab_GL;
  




  // HO_overlaps, HO_overlaps_Fermi (res, plus, or minus also added)
  // --------------------------------------------------------------
  // arrays of vectors of overlaps and Fermi function, between HF/OCM one-body basis states and HO states of the interaction class used for the HO expansion of operators
  // for all shells (name without res) or only bound and resonant (name with res) states. 
  //
  // The former data with "plus/minus (i.e. +/- 1)" added in their names means that one considers the equivalent potentials of the states 
  // for which k +/- w/(4 Pi) with protons for Coulomb complex scaling (see H_CM_OBMEs.cpp).
  
  class array<class vector_class<complex<double> > > HO_overlaps; 
  class array<class vector_class<complex<double> > > HO_overlaps_res; 
  class array<class vector_class<complex<double> > > HO_overlaps_plus; 
  class array<class vector_class<complex<double> > > HO_overlaps_minus;
  
  class array<class vector_class<complex<double> > > HO_overlaps_Fermi; 
  class array<class vector_class<complex<double> > > HO_overlaps_Fermi_res; 
  class array<class vector_class<complex<double> > > HO_overlaps_Fermi_plus; 
  class array<class vector_class<complex<double> > > HO_overlaps_Fermi_minus;
  




  // shells (res, plus, or minus also added) 
  // ---------------------------------------
  // arrays of class spherical_state where all shells (name without res) or only bound and resonant (name with res) shells are stored
  //
  // The former data with "plus/minus (i.e. +/- 1)" added in their names means that one considers the equivalent potentials of the states 
  // for which k +/- w/(4 Pi) with protons for Coulomb complex scaling (see H_CM_OBMEs.cpp).
 
  class array<class spherical_state> shells; 
  class array<class spherical_state> shells_res; 
  class array<class spherical_state> shells_plus; 
  class array<class spherical_state> shells_minus;
  




  class lj_table<bool> is_partial_wave_optimized_HF_MSDHF_tab; // (l,j) array of booleans, which is true if the (l,j) partial wave is optimized with the HF/MSDHF procedure, false if not.
                                                               // One puts false for partial waves calculated from an OCM potential, as the OCM potential is fixed and does not arise from an optimization procedure of HF type.
  
  class lj_table<int> highest_occupied_n_tab;         // (l,j) array of the largest principal quantum numbers of occupied shells in the (l,j) partial wave for a ground state or 1p-1h configuration

  class lj_table<class pair_str> occupied_pairs;      // (l,j) array of occupied pairs, with one nucleon occupied in the (l,j) optimized partial wave, so that the (l,j) partial wave can be optimized using that pair as MSDHF state
                                                      // Two-particle code only.  

  class lj_table<class configuration> configurations_to_diagonalize; // (l,j) array of ground state or 1p-1h configurations which will be used in Hamiltonian diagonalization 
                                                                     // in the shell model part of the MSDHF method to optimize the (l,j) partial wave

  class lj_table<unsigned int> dimensions_GS;
  
  class lj_table<class array<class Slater_determinant > > SDp_tab_GS;
  class lj_table<class array<class Slater_determinant > > SDn_tab_GS;
  
  class lj_table<class array<complex<double> > > SDs_GS_coefficients;
  
  class lj_table<class array<class Slater_determinant > > SDs_1h;
  
  class lj_table<class array<complex<double> > > SDs_1h_coefficients;
  
  class lj_table<class array<bool> > SDs_1h_existence_tab;
  
  class lj_table<complex<double> > U_HF_normalizing_sums;
  
  class lj_table<complex<double> > OBMEs_HF_SGI_MSGI; // (l,j,nmax,nmax) array of the one-body matrix elements of the additional HF potential generated by the SGI or MSGI interactions, 
                                                      // given as OBMEs_HF_SGI_MSGI(l,j,n_in,n_out) for the in and out states
  
  class lj_table<double> b_lab_partial_waves;         // (l,j) array of HO lengths for all partial waves
  
  class lj_table<int> nmin_lj_valence_tab;





  // OCM potential calculation
  // -------------------------
  // OCM means orthogonalization condition model. This occurs with COSM, when one wants all valence states to be orthogonal to the occupied states in the core (not to be confused with HF occupied states).
  // Orthogonality is obtained by adding a non-local potential, called the OCM potential, to the initial WS, KKNN or HF/MSDHF potential, which makes all valence states orthogonal to the core occupied states.
  // As this potential is non-local, it is treated self-consistently using HF techniques and routines, even though it is no a HF potential per se.
  // 
  // The Hamiltonian with which all valence states are orthogonal to the core occupied states writes php, with h the original basis-generating Hamiltonian and p the valence space projector.
  // One has p = 1 - q, with q = \sum_{wf_core} |wf_core><wf_core|.

  class lj_table<complex<double> > shells_OCM_core_states_overlaps; // (l,j) array of <wf | wf_core> overlaps, given as a function of l,j,n,n_core, used in the calculation of the OCM potential
  
  class lj_table<class matrix<complex<double> > > php_matrices;     // (l,j) array of php Hamiltonian matrices
};





// Check if the core and basis potentials are equal
// ------------------------------------------------
// The WS potentials used for the core and basis potentials are checked if they are equal or not.
// If they are equal, one-body basis wave functions are orthogonal to core wave functions and the OCM potential is not needed.
// Otherwise, one must add the OCM potential to the basis-generating potential so that one-body basis wave functions are orthogonal to core wave functions.
// A boolean associated ot the check is returned.

bool are_core_basis_potentials_equal (
				      const int l , 
				      const class HF_nucleons_data &HF_data);

#endif


