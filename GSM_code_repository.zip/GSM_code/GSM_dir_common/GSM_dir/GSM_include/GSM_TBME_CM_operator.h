#ifndef GSMTBMECMOPERATOR_H
#define GSMTBMECMOPERATOR_H

// TYPE is double or complex
// -------------------------

namespace TBME_CM_operator
{
  namespace Hcm
  {    
    TYPE TBME_J (
		 const int J , 
		 const class array<TYPE> &reduced_grad_Hcm_tab_02 , 
		 const class array<TYPE> &reduced_grad_Hcm_tab_13 , 
		 const class array<TYPE> &reduced_r_Hcm_tab_02 , 
		 const class array<TYPE> &reduced_r_Hcm_tab_13 , 
		 const unsigned int s0 , 
		 const unsigned int s1 , 
		 const unsigned int s2 , 
		 const unsigned int s3 , 
		 const class array<class nlj_struct> &shells_qn_02 , 
		 const class array<class nlj_struct> &shells_qn_13);

    TYPE TBME_J_pp_nn_antisymmetrized (
				       const int J , 
				       const unsigned int s0 , 
				       const unsigned int s1 , 
				       const unsigned int s2 , 
				       const unsigned int s3 , 
				       const class array<class nlj_struct> &shells_qn , 
				       const class array<TYPE> &reduced_grad_Hcm_tab , 
				       const class array<TYPE> &reduced_r_Hcm_tab);
    
    TYPE TBME_J_pn (
		    const int J , 
		    const unsigned int s0 ,
		    const unsigned int s1 ,
		    const unsigned int s2 ,
		    const unsigned int s3 , 
		    const class array<class nlj_struct> &shells_qn_p , 
		    const class array<class nlj_struct> &shells_qn_n , 
		    const class array<TYPE> &reduced_grad_Hcm_tab_p , 
		    const class array<TYPE> &reduced_grad_Hcm_tab_n , 
		    const class array<TYPE> &reduced_r_Hcm_tab_p , 
		    const class array<TYPE> &reduced_r_Hcm_tab_n);
  }

  namespace P2_over_2M
  {
    double TBME_J (
		   const int J , 
		   const class array<double> &reduced_grad_P2_02_tab , 
		   const class array<double> &reduced_grad_P2_13_tab , 
		   const unsigned int s0 , 
		   const unsigned int s1 , 
		   const unsigned int s2 , 
		   const unsigned int s3 , 
		   const class array<class nlj_struct> &shells_qn_02 , 
		   const class array<class nlj_struct> &shells_qn_13);
    
    complex<double> TBME_J (
			    const int J , 
			    const class array<complex<double> > &reduced_grad_P2_02_tab , 
			    const class array<complex<double> > &reduced_grad_P2_13_tab , 
			    const unsigned int s0 , 
			    const unsigned int s1 , 
			    const unsigned int s2 , 
			    const unsigned int s3 , 
			    const class array<class nlj_struct> &shells_qn_02 , 
			    const class array<class nlj_struct> &shells_qn_13);
    
    complex<double> TBME_J_pp_nn_antisymmetrized (
						  const int J , 
						  const unsigned int s0 , 
						  const unsigned int s1 , 
						  const unsigned int s2 , 
						  const unsigned int s3 , 
						  const class array<class nlj_struct> &shells_qn , 
						  const class array<complex<double> > &reduced_grad_P2_tab);

    double TBME_J_pp_nn_antisymmetrized (
					 const int J , 
					 const unsigned int s0 , 
					 const unsigned int s1 , 
					 const unsigned int s2 , 
					 const unsigned int s3 , 
					 const class array<class nlj_struct> &shells_qn , 
					 const class array<double> &reduced_grad_P2_tab);
    
    double TBME_J_pn (
		      const int J , 
		      const unsigned int s0 , 
		      const unsigned int s1 , 
		      const unsigned int s2 , 
		      const unsigned int s3 , 
		      const class array<class nlj_struct> &shells_qn_p , 
		      const class array<class nlj_struct> &shells_qn_n , 
		      const class array<double> &reduced_grad_P2_p_tab , 
		      const class array<double> &reduced_grad_P2_n_tab); 

    
    complex<double> TBME_J_pn (
			       const int J , 
			       const unsigned int s0 , 
			       const unsigned int s1 , 
			       const unsigned int s2 , 
			       const unsigned int s3 , 
			       const class array<class nlj_struct> &shells_qn_p , 
			       const class array<class nlj_struct> &shells_qn_n , 
			       const class array<complex<double> > &reduced_grad_P2_p_tab , 
			       const class array<complex<double> > &reduced_grad_P2_n_tab);
  }
}

#endif


