#ifndef GSMARRAYOFSDONEJUMPINTOOUTDATA_H
#define GSMARRAYOFSDONEJUMPINTOOUTDATA_H
	     
// TYPE is double or complex
// -------------------------

class array_of_SD_one_jump_data_in_to_out
{
public:
  
  array_of_SD_one_jump_data_in_to_out ();
  
  array_of_SD_one_jump_data_in_to_out (
				       const unsigned int strangeness_max , 
				       const unsigned int n_spec_max ,  
				       const unsigned int n_scat_max , 
				       const class array<unsigned int> &dimensions_configuration_set , 
				       const unsigned int iM_max , 
				       const unsigned long int dimension_SD_total , 
				       const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set , 
				       const class array_BP_S_Nspec_Nscat_iC<unsigned long int> &sum_dimensions_SD_set , 
				       const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_one_jump_table);

  array_of_SD_one_jump_data_in_to_out (const class array_of_SD_one_jump_data_in_to_out &X);

  void allocate (
		 const unsigned int strangeness_max , 
		 const unsigned int n_spec_max ,  
		 const unsigned int n_scat_max , 
		 const class array<unsigned int> &dimensions_configuration_set , 
		 const unsigned int iM_max , 
		 const unsigned long int dimension_SD_total , 
		 const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set , 
		 const class array_BP_S_Nspec_Nscat_iC<unsigned long int> &sum_dimensions_SD_set , 
		 const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_one_jump_table);

  void allocate_fill (const class array_of_SD_one_jump_data_in_to_out &X);

  void deallocate ();
  
  bool is_it_filled () const;

  unsigned int index_determine (
				const unsigned int BP_in , 
				const unsigned int S_in , 
				const unsigned int n_spec_in , 
				const unsigned int n_scat_in , 
				const unsigned int iC_in , 
				const unsigned int iM_in , 
				const unsigned int inSD_index , 
				const unsigned int SD_one_jump_index) const;

  class SD_one_jump_data_in_to_out_str & operator () (
						      const unsigned int BP_in , 
						      const unsigned int S_in , 
						      const unsigned int n_spec_in , 
						      const unsigned int n_scat_in , 
						      const unsigned int iC_in , 
						      const unsigned int iM_in , 
						      const unsigned int inSD_index , 
						      const unsigned int SD_one_jump_index) const;  

  class SD_one_jump_data_in_to_out_str & operator [] (const unsigned int index) const;

  unsigned long int debut_index_good_iM_out_determine (
						       const int Delta_iM_out , 
						       const unsigned int dimension_SD_one_jump_subtable , 
						       const unsigned long int SD_one_jump_zero_index) const;

  unsigned long int end_index_good_iM_out_determine (
						     const int Delta_iM_out , 
						     const unsigned int dimension_SD_one_jump_subtable , 
						     const unsigned long int SD_one_jump_zero_index) const;

  friend double used_memory_calc (const class array_of_SD_one_jump_data_in_to_out &T);
  
private:
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> sum_dimensions_tab; // array of sums of numbers of SD_one_jump_data_in_to_out_str for fixed M, parity and number of particles in the continuum.
                                                                          // It is used to calculate the internal index of a given class SD_one_jump_data_in_to_out_str in the stored table (see GSM_array_BP_S_Nspec_Nscat_iC_iM_SD.hpp)
  
  class array<class SD_one_jump_data_in_to_out_str> table; // array of SD_one_jump_data_in_to_out_str
};




#endif
