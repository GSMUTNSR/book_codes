#ifndef GSMHCMOBMES_H
#define GSMHCMOBMES_H

// TYPE is double or complex
// -------------------------

namespace H_CM_OBMEs
{
  namespace HO_basis
  {
    double OBME_rms_radius_not_normed_calc (
					    const unsigned int s_in , 
					    const unsigned int s_out , 
					    const class baryons_data &data);

    double OBME_kinetic_calc (
			      const unsigned int s_in , 
			      const unsigned int s_out , 
			      const enum interaction_type TBME_inter , 
			      const class baryons_data &data);

    double OBME_CM_kinetic_calc (
				 const unsigned int s_in , 
				 const unsigned int s_out , 
				 const enum interaction_type TBME_inter , 
				 const class baryons_data &data);

    double OBME_Coulomb_potential_calc (
					const int ZY_charge_pos ,
					const int ZY_charge_neg ,
					const enum particle_type particle ,
					const int l , 
					const double j , 
					const int n_HO_in , 
					const int n_HO_out , 
					const class interaction_class &inter_data_basis , 
					const class baryons_data &data);
    
    double OBME_nuclear_potential_calc (
					const bool is_it_basis_potential , 
					const enum potential_type nuclear_potential , 
					const enum particle_type particle ,
					const int l , 
					const double j , 
					const int n_HO_in , 
					const int n_HO_out , 
					const class interaction_class &inter_data_basis , 
					const class baryons_data &data_for_potential);
  }
   
  TYPE OBME_H_Coulomb_part_calc (
				 const unsigned int s_in , 
				 const unsigned int s_out , 
				 const class array<class lj_table<class matrix<complex<double> > > > &V_Coulomb_HO_basis_tab ,
				 const class baryons_data &data);

  TYPE OBME_H_Coulomb_part_bound_calc (
				       const unsigned int s_in , 
				       const unsigned int s_out , 
				       const class array<class lj_table<class matrix<complex<double> > > > &V_Coulomb_HO_basis_tab ,
				       const class baryons_data &data); 

  TYPE OBME_Hcm_calc (
		      const unsigned int s_in , 
		      const unsigned int s_out , 
		      const class interaction_class &inter_data_basis , 
		      const class baryons_data &data);

  TYPE OBME_rms_radius_not_normed_calc (
					const bool is_it_only_basis ,
					const bool is_it_HO_expansion , 
					const unsigned int s_in , 
					const unsigned int s_out , 
					const class interaction_class &inter_data_basis , 
					const class array<TYPE> &r2_HO_tab , 
					const class baryons_data &data);

  TYPE reduced_OBME_L_CM_calc (
			       const unsigned int s_in , 
			       const unsigned int s_out , 
			       const class baryons_data &data);

  TYPE reduced_OBME_A_dagger_CM_HO_calc (
					 const unsigned int s_in , 
					 const unsigned int s_out , 
					 const class baryons_data &data);

  TYPE OBME_kinetic_calc (
			  const class interaction_class &inter_data_basis , 
			  const unsigned int s_in , 
			  const unsigned int s_out , 
			  const class baryons_data &neut_Y_data_like , 
			  const class baryons_data &data);

  TYPE OBME_kinetic_bound_calc (
				const class interaction_class &inter_data_basis , 
				const unsigned int s_in , 
				const unsigned int s_out , 
				const class baryons_data &neut_Y_data_like ,
				const class baryons_data &data);
 
  TYPE OBME_CM_kinetic_calc (
			     const class interaction_class &inter_data_basis , 
			     const unsigned int s_in , 
			     const unsigned int s_out , 
			     const class baryons_data &neut_Y_data_like , 
			     const class baryons_data &data);	

  TYPE OBME_CM_kinetic_bound_calc (
				   const class interaction_class &inter_data_basis , 
				   const unsigned int s_in , 
				   const unsigned int s_out , 
				   const class baryons_data &neut_Y_data_like ,
				   const class baryons_data &data);

  TYPE OBME_core_Hcm_calc (
			   const bool is_it_COSM , 
			   const class baryons_data &neut_Y_data_like , 
			   const double lambda_Hcm , 
			   const unsigned int s_in , 
			   const unsigned int s_out , 
			   const class interaction_class &inter_data_basis , 
			   const class baryons_data &data);

  TYPE OBME_core_Hcm_bound_calc (
				 const unsigned int s_in , 
				 const unsigned int s_out , 
				 const class interaction_class &inter_data_basis , 
				 const double lambda_Hcm , 
				 const class baryons_data &neut_Y_data_like ,
				 const class baryons_data &data);

  TYPE OBME_nuclear_potential_calc (
				    const bool is_it_basis_core_potential , 
				    const bool is_it_basis_potential , 
				    const enum potential_type nuclear_potential , 
				    const unsigned int s_in , 
				    const unsigned int s_out , 
				    const class baryons_data &data_for_pot , 
				    const class baryons_data &data); 

  TYPE OBME_WS_derivative_calc (
				const enum FHT_EFT_parameter_type FHT_EFT_parameter , 
				const bool is_there_l_dependence , 
				const int l_WS , 
				const double A_dependent_factor_core_potential ,
				const unsigned int s_in , 
				const unsigned int s_out , 
				const class baryons_data &data);

  TYPE coupled_OBME_inter_calc (
				const enum interaction_type Op_inter , 
				const class interaction_class &inter_data_basis , 
				const double lambda_Hcm , 
				const unsigned int s_in , 
				const unsigned int s_out , 
				const class baryons_data &neut_Y_data_like , 
				const class baryons_data &data);

  TYPE coupled_OBME_operator_calc (
				   const bool is_it_only_basis ,
				   const enum operator_type Op , 
				   const bool is_it_HO_expansion , 
				   const class interaction_class &inter_data_basis , 
				   const unsigned int s_in , 
				   const unsigned int s_out , 
				   const class baryons_data &neut_Y_data_like , 
				   const class array<TYPE> &r2_HO_tab , 
				   const class baryons_data &data);
}

#endif


