#ifndef GSMHCMOBMES_H
#define GSMHCMOBMES_H

// TYPE is double or complex
// -------------------------

namespace H_CM_OBMEs
{
  namespace HO_basis
  {
    double OBME_rms_radius_calc (
				 const class input_data_str &input_data , 
				 const unsigned int s_in , 
				 const unsigned int s_out , 
				 const enum operator_type rms_radius_op , 
				 const class nucleons_data &data);

    double OBME_kinetic_calc (
			      const unsigned int s_in , 
			      const unsigned int s_out , 
			      const enum interaction_type TBME_inter , 
			      const class nucleons_data &data);

    double OBME_CM_kinetic_calc (
				 const unsigned int s_in , 
				 const unsigned int s_out , 
				 const enum interaction_type TBME_inter , 
				 const class nucleons_data &data);

    double OBME_Coulomb_potential_calc (
					const int Z_charge , 
					const int l , 
					const double j , 
					const int n_HO_in , 
					const int n_HO_out , 
					const class interaction_class &inter_data_basis , 
					const class nucleons_data &data);
    
    double OBME_nuclear_potential_calc (
					const bool is_it_basis_potential , 
					const enum potential_type nuclear_potential , 
					const int l , 
					const double j , 
					const int n_HO_in , 
					const int n_HO_out , 
					const class interaction_class &inter_data_basis , 
					const class nucleons_data &data_for_potential);
  }
   
  TYPE OBME_H_Coulomb_part_calc (
				 const unsigned int s_in , 
				 const unsigned int s_out , 
				 const class lj_table<class matrix<complex<double> > > &V_Coulomb_HO_basis , 
				 const class nucleons_data &data);

  TYPE OBME_H_Coulomb_part_bound_calc (
				       const unsigned int s_in , 
				       const unsigned int s_out , 
				       const class lj_table<class matrix<complex<double> > > &V_Coulomb_HO_basis , 
				       const class nucleons_data &data); 

  TYPE OBME_Hcm_calc (
		      const unsigned int s_in , 
		      const unsigned int s_out , 
		      const class interaction_class &inter_data_basis , 
		      const class nucleons_data &data);

  TYPE OBME_rms_radius_calc (
			     const bool is_it_only_basis ,
			     const class input_data_str &input_data , 
			     const bool is_it_HO_expansion , 
			     const unsigned int s_in , 
			     const unsigned int s_out , 
			     const enum operator_type rms_radius_op , 
			     const class interaction_class &inter_data_basis , 
			     const class array<TYPE> &r2_HO_tab , 
			     const class nucleons_data &data);

  TYPE reduced_OBME_L_CM_calc (
			       const unsigned int s_in , 
			       const unsigned int s_out , 
			       const class nucleons_data &data);

  TYPE reduced_OBME_A_dagger_CM_HO_calc (
					 const unsigned int s_in , 
					 const unsigned int s_out , 
					 const class nucleons_data &data);

  TYPE OBME_kinetic_calc (
			  const class interaction_class &inter_data_basis , 
			  const unsigned int s_in , 
			  const unsigned int s_out , 
			  const class nucleons_data &neut_data , 
			  const class nucleons_data &data);

  TYPE OBME_kinetic_bound_calc (
				const class interaction_class &inter_data_basis , 
				const unsigned int s_in , 
				const unsigned int s_out , 
				const class nucleons_data &neut_data ,
				const class nucleons_data &data);
 
  TYPE OBME_CM_kinetic_calc (
			     const class interaction_class &inter_data_basis , 
			     const unsigned int s_in , 
			     const unsigned int s_out , 
			     const class nucleons_data &neut_data , 
			     const class nucleons_data &data);	

  TYPE OBME_CM_kinetic_bound_calc (
				   const class interaction_class &inter_data_basis , 
				   const unsigned int s_in , 
				   const unsigned int s_out , 
				   const class nucleons_data &neut_data ,
				   const class nucleons_data &data);

  TYPE OBME_core_Hcm_calc (
			   const bool is_it_COSM , 
			   const class nucleons_data &neut_data , 
			   const double lambda_Hcm , 
			   const unsigned int s_in , 
			   const unsigned int s_out , 
			   const class interaction_class &inter_data_basis , 
			   const class nucleons_data &data);

  TYPE OBME_core_Hcm_bound_calc (
				 const unsigned int s_in , 
				 const unsigned int s_out , 
				 const class interaction_class &inter_data_basis_basis , 
				 const double lambda_Hcm , 
				 const class nucleons_data &neut_data ,
				 const class nucleons_data &data);

  TYPE OBME_nuclear_potential_calc (
				    const bool is_it_basis_core_potential , 
				    const bool is_it_basis_potential , 
				    const enum potential_type nuclear_potential , 
				    const unsigned int s_in , 
				    const unsigned int s_out , 
				    const class nucleons_data &data_for_pot , 
				    const class nucleons_data &data); 

  TYPE OBME_WS_derivative_calc (
				const enum FHT_EFT_parameter_type FHT_EFT_parameter , 
				const bool is_there_l_dependence , 
				const int l_WS , 
				const double A_dependent_factor_core_potential ,
				const unsigned int s_in , 
				const unsigned int s_out , 
				const class nucleons_data &data);

  TYPE coupled_OBME_inter_calc (
				const enum interaction_type Op_inter , 
				const class interaction_class &inter_data_basis , 
				const double lambda_Hcm , 
				const unsigned int s_in , 
				const unsigned int s_out , 
				const class nucleons_data &neut_data , 
				const class nucleons_data &data);

  TYPE coupled_OBME_operator_calc (
				   const bool is_it_only_basis ,
				   const class input_data_str &input_data , 
				   const enum operator_type Op , 
				   const bool is_it_HO_expansion , 
				   const class interaction_class &inter_data_basis , 
				   const unsigned int s_in , 
				   const unsigned int s_out , 
				   const class nucleons_data &neut_data , 
				   const class array<TYPE> &r2_HO_tab , 
				   const class nucleons_data &data);
}

#endif


