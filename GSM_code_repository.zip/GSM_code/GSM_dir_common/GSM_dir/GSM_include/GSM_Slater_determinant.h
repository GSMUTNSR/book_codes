#ifndef GSMSLATERDETERMINANT_H
#define GSMSLATERDETERMINANT_H

// TYPE is double or complex
// -------------------------

class virtual_Slater_determinant;
class array_of_SD;

class Slater_determinant 
{
public:
  
  Slater_determinant ();
  
  explicit Slater_determinant (const unsigned int N_valence_nucleons_c);

  Slater_determinant (const class Slater_determinant &SD);

  Slater_determinant (const class virtual_Slater_determinant &SD);

  ~Slater_determinant ();

  bool is_it_filled () const
  {
    return (states != NULL);
  }
  
  unsigned short int get_N_valence_nucleons () const
  {
    return N_valence_nucleons; 
  }
  
  void allocate (const unsigned int N_valence_nucleons_c);

  void allocate_fill (const class Slater_determinant &X);

  void allocate_fill (const class virtual_Slater_determinant &X);

  void deallocate ();

  unsigned short int & operator [] (const unsigned int i) const
  {
    return states[i];
  }

  const class Slater_determinant & operator = (const class Slater_determinant &X);

  const class Slater_determinant & operator = (const class virtual_Slater_determinant &X);

  void ground_state (const unsigned short int debut);

  double M_determine (const class array<class nljm_struct> &phi_table) const;

  int iM_determine (const class array<class nljm_struct> &phi_table) const;

  TYPE E_determine (
		    const class nlj_table<TYPE> &h_basis ,
		    const class array<class nljm_struct> &phi_table) const;

  void print (const class array<class nljm_struct> &phi_table) const;

  unsigned int index_search (
			     const unsigned int BP , 
			     const int n_scat , 
			     const unsigned int iC , 
			     const unsigned int iM , 
			     const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set , 
			     const class array_of_SD &SD_set , 
			     class Slater_determinant &SD_try) const;

  unsigned int index_search (
			     const unsigned int dimension ,
			     const unsigned long int SD_set_zero_index , 
			     const class array_of_SD &SD_set , 
			     class Slater_determinant &SD_try) const;
 
  void different_states_determine (
				   const class Slater_determinant &SD_to_compare , 
				   unsigned int &different_states_number , 
				   class array<unsigned int> &different_states) const;

  unsigned int state_place_find (const unsigned int state) const;

  unsigned int state_to_add_place_find (const unsigned int state) const;
 
  void TRS_SD_bin_phases (
			  const class array<class nljm_struct> &phi_table , 
			  const class array<unsigned int> &TRS_nljm_indices , 
			  class Slater_determinant &SD_result , 
			  unsigned int &TRS_reordering_bin_phase , 
			  unsigned int &TRS_bin_phase) const;

  void excitation_1p_and_bin_phase (
				    const unsigned int state_to_add , 
				    class Slater_determinant &SD_result , 
				    unsigned int &bin_phase) const;

  void excitation_1h_and_bin_phase (
				    const unsigned int state_to_remove , 
				    class Slater_determinant &SD_result , 
				    unsigned int &bin_phase) const;

  void excitation_1p_1h_and_bin_phase (
				       const unsigned int state_to_add , 
				       const unsigned int state_to_remove , 
				       class Slater_determinant &SD_result , 
				       unsigned int &bin_phase) const;

  void excitation_2p_and_bin_phase (
				    const unsigned int s0_to_add , 
				    const unsigned int s1_to_add , 
				    class Slater_determinant &SD_result , 
				    unsigned int &bin_phase) const;

  void excitation_2h_and_bin_phase (
				    const unsigned int s0_to_remove , 
				    const unsigned int s1_to_remove , 
				    class Slater_determinant &SD_result , 
				    unsigned int &bin_phase) const;

  void excitation_2p_1h_and_bin_phase (
				       const unsigned int s0_to_add_init , 
				       const unsigned int s1_to_add_init , 
				       const unsigned int s2_to_remove , 
				       class Slater_determinant &SD_result , 
				       unsigned int &bin_phase) const;

  void excitation_1p_2h_and_bin_phase (
				       const unsigned int s0_to_add , 
				       const unsigned int s1_to_remove_init , 
				       const unsigned int s2_to_remove_init , 
				       class Slater_determinant &SD_result , 
				       unsigned int &bin_phase) const;

  void excitation_3p_and_bin_phase (
				    const unsigned int s0_to_add_init , 
				    const unsigned int s1_to_add_init ,  
				    const unsigned int s2_to_add_init , 
				    class Slater_determinant &SD_result , 
				    unsigned int &bin_phase) const;

  void excitation_3h_and_bin_phase (
				    const unsigned int s0_to_remove_init , 
				    const unsigned int s1_to_remove_init , 
				    const unsigned int s2_to_remove_init , 
				    class Slater_determinant &SD_result , 
				    unsigned int &bin_phase) const;  

  void excitation_4p_and_bin_phase (
				    const unsigned int s0_to_add_init , 
				    const unsigned int s1_to_add_init ,  
				    const unsigned int s2_to_add_init ,  
				    const unsigned int s3_to_add_init , 
				    class Slater_determinant &SD_result , 
				    unsigned int &bin_phase) const;
  
  void excitation_4h_and_bin_phase (
				    const unsigned int s0_to_remove_init , 
				    const unsigned int s1_to_remove_init , 
				    const unsigned int s2_to_remove_init , 
				    const unsigned int s3_to_remove_init , 
				    class Slater_determinant &SD_result , 
				    unsigned int &bin_phase) const;
  
  void excitation_3p_1h_and_bin_phase (
				       const unsigned int s0_to_add_init , 
				       const unsigned int s1_to_add_init ,  
				       const unsigned int s2_to_add_init , 
				       const unsigned int s3_to_remove ,
				       class Slater_determinant &SD_result , 
				       unsigned int &bin_phase) const;
  
  void excitation_2p_2h_and_bin_phase (
				       const unsigned int s0_to_add_init , 
				       const unsigned int s1_to_add_init ,
				       const unsigned int s2_to_remove_init , 
				       const unsigned int s3_to_remove_init ,
				       class Slater_determinant &SD_result , 
				       unsigned int &bin_phase) const;
  
  void excitation_1p_3h_and_bin_phase (
				       const unsigned int s0_to_add , 
				       const unsigned int s0_to_remove_init , 
				       const unsigned int s1_to_remove_init , 
				       const unsigned int s2_to_remove_init , 
				       class Slater_determinant &SD_result , 
				       unsigned int &bin_phase) const;
  
  void excitation_1h_1p_and_bin_phase (
				       const unsigned int s0_to_remove , 
				       const unsigned int s1_to_add , 
				       class Slater_determinant &SD_result , 
				       unsigned int &bin_phase) const;
 
  void excitation_2h_1p_and_bin_phase (
				       const unsigned int s0_to_remove , 
				       const unsigned int s1_to_remove ,
				       const unsigned int s2_to_add , 
				       class Slater_determinant &SD_result , 
				       unsigned int &bin_phase) const;
  
  void excitation_1h_2p_and_bin_phase (
				       const unsigned int s0_to_remove , 
				       const unsigned int s1_to_add ,
				       const unsigned int s2_to_add , 
				       class Slater_determinant &SD_result , 
				       unsigned int &bin_phase) const;
  
  void excitation_1p_1h_1p_and_bin_phase (
					  const unsigned int s0_to_add , 
					  const unsigned int s1_to_remove ,
					  const unsigned int s2_to_add , 
					  class Slater_determinant &SD_result , 
					  unsigned int &bin_phase) const;
  
  void excitation_1h_1p_1h_and_bin_phase (
					  const unsigned int s0_to_remove , 
					  const unsigned int s1_to_add ,
					  const unsigned int s2_to_remove , 
					  class Slater_determinant &SD_result , 
					  unsigned int &bin_phase) const;
  
  void excitation_2p_1h_1p_and_bin_phase (
					  const unsigned int s0_to_add , 
					  const unsigned int s1_to_add , 
					  const unsigned int s2_to_remove , 
					  const unsigned int s3_to_add ,
					  class Slater_determinant &SD_result , 
					  unsigned int &bin_phase) const;
  
  void excitation_1p_1h_2p_and_bin_phase (
					  const unsigned int s0_to_add , 
					  const unsigned int s1_to_remove ,
					  const unsigned int s2_to_add , 
					  const unsigned int s3_to_add ,
					  class Slater_determinant &SD_result , 
					  unsigned int &bin_phase) const;
  
  void excitation_1p_1h_1p_1h_and_bin_phase (
					     const unsigned int s0_to_add , 
					     const unsigned int s1_to_remove ,
					     const unsigned int s2_to_add , 
					     const unsigned int s3_to_remove ,
					     class Slater_determinant &SD_result , 
					     unsigned int &bin_phase) const;
  
  void excitation_1p_2h_1p_and_bin_phase (
					  const unsigned int s0_to_add , 
					  const unsigned int s1_to_remove ,
					  const unsigned int s2_to_remove , 
					  const unsigned int s3_to_add ,
					  class Slater_determinant &SD_result , 
					  unsigned int &bin_phase) const;
  
  void excitation_1h_3p_and_bin_phase (
				       const unsigned int s0_to_remove , 
				       const unsigned int s1_to_add ,
				       const unsigned int s2_to_add , 
				       const unsigned int s3_to_add ,
				       class Slater_determinant &SD_result , 
				       unsigned int &bin_phase) const;
  
  void excitation_1h_2p_1h_and_bin_phase (
					  const unsigned int s0_to_remove , 
					  const unsigned int s1_to_add ,
					  const unsigned int s2_to_add , 
					  const unsigned int s3_to_remove ,
					  class Slater_determinant &SD_result , 
					  unsigned int &bin_phase) const;
  
  void excitation_1h_1p_1h_1p_and_bin_phase (
					     const unsigned int s0_to_remove , 
					     const unsigned int s1_to_add ,
					     const unsigned int s2_to_remove , 
					     const unsigned int s3_to_add ,
					     class Slater_determinant &SD_result , 
					     unsigned int &bin_phase) const;
  
  void excitation_1h_1p_2h_and_bin_phase (
					  const unsigned int s0_to_remove , 
					  const unsigned int s1_to_add ,
					  const unsigned int s2_to_remove , 
					  const unsigned int s3_to_remove ,
					  class Slater_determinant &SD_result , 
					  unsigned int &bin_phase) const;
  
  void excitation_2h_2p_and_bin_phase (
				       const unsigned int s0_to_remove , 
				       const unsigned int s1_to_remove , 
				       const unsigned int s2_to_add , 
				       const unsigned int s3_to_add ,
				       class Slater_determinant &SD_result , 
				       unsigned int &bin_phase) const;
  
  void excitation_2h_1p_1h_and_bin_phase (
					  const unsigned int s0_to_remove , 
					  const unsigned int s1_to_remove , 
					  const unsigned int s2_to_add ,
					  const unsigned int s3_to_remove ,
					  class Slater_determinant &SD_result , 
					  unsigned int &bin_phase) const;
  
  void excitation_3h_1p_and_bin_phase (
				       const unsigned int s0_to_remove , 
				       const unsigned int s1_to_remove ,
				       const unsigned int s2_to_remove ,
				       const unsigned int s3_to_add ,
				       class Slater_determinant &SD_result , 
				       unsigned int &bin_phase) const;
  
  void excitation_SD_add_and_bin_phase (
					const class Slater_determinant &SD_add , 
					class Slater_determinant &SD_result , 
					unsigned int &bin_phase) const;

  void excitation_SD_remove_and_bin_phase (
					   const class Slater_determinant &SD_remove , 
					   class Slater_determinant &SD_result , 
					   unsigned int &bin_phase) const;
 
  void nljm_reordering_bin_phase (
				  const class array<unsigned int> &initial_to_nljm_ordered_states , 
				  const class array<unsigned int> &nljm_ordered_to_initial_states , 
				  class Slater_determinant &SD_ljm_reordered , 
				  unsigned int &nljm_reordering_bin_phase) const;

  unsigned int N_valence_nucleons_fixed_ljm_determine (
						       const class array<class nljm_struct> &phi_table ,
						       const class ljm_struct &ljm) const;

  unsigned int ljm_number_determine (const class array<class nljm_struct> &phi_table) const;

  void ljm_states_table_calc (
			      const class array<class nljm_struct> &phi_table ,
			      class array<class ljm_struct> &ljm_states) const;

  bool is_valence_state_occupied (const unsigned int state) const;
  
  bool is_SD_partially_occupied (const class Slater_determinant &SD) const;
  
  bool is_SD_occupied (const class Slater_determinant &SD) const;
  
  void get_antisymmetrized_product (
				    const class array<unsigned int> &N_valence_nucleons_per_sub_system , 
				    const class array<unsigned int> &sub_SDs_index_tab , 
				    const class array<class array<class Slater_determinant > > &sub_SDs_tab);

  bool is_it_in_new_space (
			   const class array<class nljm_struct> &old_phi_table ,
			   const class lj_table<int> &new_nmax_lj_tab ,
			   const class nlj_table<bool> &new_is_it_valence_shell_tab) const;
 
  void reindexation_and_bin_phase (
				   const class array<class nljm_struct> &old_phi_table ,
				   const class one_body_indices_str &new_one_body_indices ,
				   unsigned int &bin_phase);
   
  friend double used_memory_calc (const class Slater_determinant &T);
  
  friend void SD_reordering_bin_phase (
				       class Slater_determinant &SD , 
				       unsigned int &reordering_bin_phase);
  
private:
  
  unsigned short int N_valence_nucleons;
  
  unsigned short int *states;
};





TYPE sub_SD_Berggren_HO_overlap_calc (
				      const unsigned int same_ljm_states_number , 
				      const unsigned int same_ljm_shift , 
				      const class Slater_determinant &SD_nljm_reordered , 
				      const class Slater_determinant &SD_HO_nljm_reordered , 
				      const class array<class nljm_struct> &phi_table , 
				      const class array<class nljm_struct> &phi_table_HO , 
				      const class array<class vector_class<complex<double> > > &HO_overlaps);

TYPE overlap_SD_Berggren_HO_nljm_reordered_calc (
						 const class array<class nljm_struct> &phi_table , 
						 const class array<class nljm_struct> &phi_table_HO , 
						 const class array<class vector_class<complex<double> > > &HO_overlaps , 
						 const class array<class ljm_struct> &ljm_states , 
						 const class Slater_determinant &SD_nljm_reordered , 
						 const class Slater_determinant &SD_HO_nljm_reordered);

bool operator == (const class Slater_determinant &SD1 , const class Slater_determinant &SD2);
bool operator != (const class Slater_determinant &SD1 , const class Slater_determinant &SD2);

bool operator >  (const class Slater_determinant &SD1 , const class Slater_determinant &SD2);
bool operator >= (const class Slater_determinant &SD1 , const class Slater_determinant &SD2);

bool operator <  (const class Slater_determinant &SD1 , const class Slater_determinant &SD2);
bool operator <= (const class Slater_determinant &SD1 , const class Slater_determinant &SD2);

ostream & operator << (ostream &os , const class Slater_determinant &SD);

void SDs_is_it_in_new_space_reindexation_phases_determine (
							   const class lj_table<int> &nmax_lj_tab ,
							   const class nlj_table<bool> &is_it_valence_shell_tab ,
							   const class array<class nljm_struct> &phi_table ,
							   const class one_body_indices_str &one_body_indices ,
							   class array<unsigned int> &SD_tab ,
							   class array<bool> &is_SD_in_new_space_tab ,
							   class array<unsigned char> &reordering_bin_phases);

#endif


