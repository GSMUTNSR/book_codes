#ifndef GSMJUMPSDATAINSDSTR_H
#define GSMJUMPSDATAINSDSTR_H


// TYPE is double or complex
// -------------------------


class jumps_data_inSD_str
{
public:

  jumps_data_inSD_str ();

  jumps_data_inSD_str (
		       const unsigned char n_holes_c ,
		       const unsigned char n_scat_c , 
		       const unsigned int iC_c , 
		       const unsigned int inSD_index_c , 
		       const unsigned char total_bin_phase_c , 
		       const bool is_configuration_changing_c ,
		       const unsigned short int left_in_c , 
		       const unsigned short int right_in_c ,   
		       const unsigned short int left_out_c , 
		       const unsigned short int right_out_c ,
		       const unsigned short int E_hw_c);

  jumps_data_inSD_str (
		       const unsigned char n_holes_c ,
		       const unsigned char n_scat_c , 
		       const unsigned int iC_c , 
		       const unsigned int inSD_index_c , 
		       const unsigned char total_bin_phase_c , 
		       const bool is_configuration_changing_c , 
		       const unsigned short int mu_in_c ,  
		       const unsigned short int mu_out_c ,
		       const unsigned short int E_hw_c);

  jumps_data_inSD_str (
		       const unsigned int inSD_index_c , 
		       const unsigned char total_bin_phase_c , 
		       const bool is_configuration_changing_c ,
		       const unsigned short int mu_in_c , 
		       const unsigned short int mu_out_c);
  
  void initialize (
		   const unsigned char n_holes_c ,
		   const unsigned char n_scat_c , 
		   const unsigned int iC_c , 
		   const unsigned int inSD_index_c , 
		   const unsigned char total_bin_phase_c , 
		   const bool is_configuration_changing_c , 
		   const unsigned short int left_out_c , 
		   const unsigned short int right_out_c , 
		   const unsigned short int left_in_c , 
		   const unsigned short int right_in_c , 
		   const unsigned short int E_hw_c);
  
  void initialize (
		   const unsigned char n_holes_c ,
		   const unsigned char n_scat_c , 
		   const unsigned int iC_c , 
		   const unsigned int inSD_index_c , 
		   const unsigned char total_bin_phase_c , 
		   const bool is_configuration_changing_c , 
		   const unsigned short int mu_in_c , 
		   const unsigned short int mu_out_c ,
		   const unsigned short int E_hw_c);
  
  void initialize (
		   const unsigned int inSD_index_c , 
		   const unsigned char total_bin_phase_c , 
		   const bool is_configuration_changing_c ,
		   const unsigned short int mu_in_c , 
		   const unsigned short int mu_out_c);

  unsigned char get_n_holes () const
  {
    return n_holes;
  }
  
  unsigned char get_n_scat () const
  {
    return n_scat;
  }
  
  unsigned int get_iC () const
  {
    return iC;
  }

  unsigned int get_inSD_index () const
  {
    return inSD_index;
  }
  
  unsigned char get_total_bin_phase () const
  {
    return total_bin_phase;
  }
  
  bool get_is_configuration_changing () const
  {
    return is_configuration_changing;
  }

  unsigned short int get_mu_in () const
  {
    return right_in;
  }
  
  unsigned short int get_mu_out () const
  {
    return right_out;
  }
  
  unsigned short int get_left_in () const
  {
    return left_in;
  }
  
  unsigned short int get_right_in () const
  {
    return right_in;
  }
  
  unsigned short int get_left_out () const
  {
    return left_out;
  }
  
  unsigned short int get_right_out () const
  {
    return right_out;
  }
  
  unsigned short int get_E_hw () const
  {
    return E_hw;
  }
  
  void set_configuration_change ()
  {
    is_configuration_changing = true;
  }
  
  void unset_configuration_change ()
  {
    is_configuration_changing = false;
  }
    
private:
  unsigned char n_holes; // number of holes of inSD
  
  unsigned char n_scat; // number of particles in the continuum of inSD
  
  unsigned int iC; // configuration index of the configuration of inSD
  
  unsigned int inSD_index; // index of inSD
  
  unsigned char total_bin_phase; // binary phase induced by the creation/annihilation operators
  
  bool is_configuration_changing; // true if the configuration of inSD is changing compared to the previous element in the array, false if not



  
  // alpha is right_in for a one-body jump, (alpha,beta) are (left_in,right_in) for a two-body jump
  
  unsigned short int left_in;
  unsigned short int right_in;



  // beta is right_out for a one-body jump, (gamma,delta) are (left_out,right_out) for a two-body jump
  
  unsigned short int left_out;
  unsigned short int right_out;


  

  unsigned short int E_hw; // truncation energy of inSD
};

double used_memory_calc (const class jumps_data_inSD_str &T);

// One uses the lexicographic order. It allows to have a minimal change of configurations in the array, to minimize recalculation of indices.
// Order is considered with respect to configuration only.
// Hence, following operators only consider the equivalence classes defined by configuration.

bool operator == (
		  const class jumps_data_inSD_str &T1 , 
		  const class jumps_data_inSD_str &T2);

bool operator != (
		  const class jumps_data_inSD_str &T1 , 
		  const class jumps_data_inSD_str &T2);

bool operator > (
		 const class jumps_data_inSD_str &T1 , 
		 const class jumps_data_inSD_str &T2);

bool operator >= (
		  const class jumps_data_inSD_str &T1 , 
		  const class jumps_data_inSD_str &T2);

bool operator < (
		 const class jumps_data_inSD_str &T1 , 
		 const class jumps_data_inSD_str &T2);

bool operator <= (
		  const class jumps_data_inSD_str &T1 , 
		  const class jumps_data_inSD_str &T2);
#endif

