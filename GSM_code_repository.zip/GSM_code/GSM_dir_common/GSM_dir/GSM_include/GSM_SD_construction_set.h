#ifndef GSMSDCONSTRUCTIONSET_H
#define GSMSDCONSTRUCTIONSET_H

// TYPE is double or complex
// -------------------------

namespace SD_construction_set
{
  void fill_sets (
		  const enum operation_type operation , 
		  const unsigned int N_valence_baryons_local ,
		  const unsigned int BP ,
		  const int S ,
		  const int n_spec ,  
		  const int n_scat , 
		  const unsigned int iC , 
		  const int iM , 
		  const class Slater_determinant &SDc , 
		  class baryons_data &particles_data);

  void all_SDs_of_configuration (
				 const enum operation_type operation , 
				 const unsigned int N_valence_baryons_local ,
				 const unsigned int BP , 
				 const int S ,
				 const int n_spec , 
				 const int n_scat , 
				 const unsigned int iC , 
				 const class array<unsigned int> &N_valence_baryons_per_shell , 
				 const class array<unsigned int> &N_sub_SDs_per_shell , 
				 const class array<class array<class Slater_determinant> > &sub_SDs_tab , 
				 class baryons_data &particles_data);

  void all_sub_SDs_per_shell (
			      const class baryons_data &particles_data , 
			      const class nlj_struct &shell , 
			      const unsigned int N_valence_baryons_in_shell , 
			      class array<class Slater_determinant> &sub_SDs_tab_shell);

  void shells_indices_N_valence_baryons_per_shell_fill (
							const unsigned int N_nlj , 
							const class configuration &Cc , 
							class array<unsigned int> &shells_indices , 
							class array<unsigned int> &N_valence_baryons_per_shell);

  void N_sub_SDs_per_shell_fill (
				 const class array<class nlj_struct> &shells_qn , 
				 const class array<unsigned int> &shells_indices , 
				 const class array<unsigned int> &N_valence_baryons_per_shell , 
				 class array<unsigned int> &N_sub_SDs_per_shell);

  void tables_fill_dimensions_calc (
				    const enum operation_type operation , 					 
				    const bool is_it_pole_approximation ,
				    const unsigned int N_valence_baryons_local , 
				    class baryons_data &particles_data);

  void tables_ordering (
			const bool is_it_pole_approximation ,
			const unsigned int N_valence_baryons_local , 
			class baryons_data &particles_data);

  void TRS_tables_allocated_built (
				   const bool is_it_pole_approximation ,
				   const unsigned int N_valence_baryons_local ,  
				   class baryons_data &particles_data);
  
  void SD_quantum_numbers_table_allocated_built (
						 const bool is_it_pole_approximation , 
						 class baryons_data &particles_data);

  void dimensions_tables_alloc_calc_1D_hybrid_1D_2D_partitioning (
								  const bool is_there_cout , 
								  const bool is_it_only_basis , 
								  const bool only_dimensions , 
								  const bool is_it_pole_approximation , 
								  class baryons_data &particles_data);
 
  void tables_allocated_built_1D_hybrid_1D_2D_partitioning (
							    const bool is_there_cout , 
							    const bool print_detailed_information , 
							    const bool is_it_only_basis , 
							    const bool is_it_pole_approximation , 
							    class baryons_data &particles_data , 
							    const bool only_dimensions);
  
  void dimensions_tables_alloc_calc_2D_partitioning (
						     const bool is_there_cout , 
						     const bool is_it_only_basis , 
						     const bool only_dimensions , 
						     const bool is_it_pole_approximation , 
						     class baryons_data &particles_data);
 
  void tables_allocated_built_2D_partitioning (
					       const bool is_there_cout , 
					       const bool print_detailed_information , 
					       const bool is_it_only_basis , 
					       const bool is_it_pole_approximation , 
					       class baryons_data &particles_data , 
					       const bool only_dimensions);
}

#endif


