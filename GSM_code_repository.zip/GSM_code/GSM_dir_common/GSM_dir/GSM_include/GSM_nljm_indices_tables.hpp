#ifndef GSMNLJMINDICESTABLES_H
#define GSMNLJMINDICESTABLES_H


// Class arrays of the form T(l,j), T(n,l,j), T(n,l,ml), T(l,ml), T(l,j,m), T(n,l,j,m), with T(...,i), and T(...,i,i') as well
// ---------------------------------------------------------------------------------------------------------------------------
// These classes are defined as template of type C, so that C can be any type compatible with the class.
//
// As angular momenta can be integers or half-integers, and angular momenta projections can be negative as well, 
// it is convenient to have classes where the angular momenta and angular momenta projections are converted automatically to integer indices.
// These classes are supposed to be used for arrays whose elements are not accessed very often so that index recalculation is not an issue.
// Element access can be optimized, nevertheless, for T(...,i), T(...,i,i') and  T(n,...,i), T(n,...,i,i') arrays (see below).
// The number of angular momenta and angular momenta projections combinations should not exceed OUT_OF_RANGE (equal to 65535, see const.h).
//
// Available arrays are of the form shown above, where n,l,j,m are quantum numbers and i,i' are arbitrary indices, for which 0 <= i < N or 0 <= i < N0 and 0 <= i' < N1.
// n is the principal quantum number, with 0 <= n <= nmax, l is the orbital angular momentum, with 0 <= l <= lmax, ml is its projection, j is the total angular momentum and m its projection.
// One has either l,ml (lm_table and nlm_table), l,j (lj_table and nlj_table) or l,j,m (ljm_table and nljm_table) as defined angular quantum numbers.
//
// Arrays are stored in a class array called "table".
// Angular momentum indices IA are calculated and stored as: 
// lm_index = lm_indices (l , ml + l), lj_index = lj_indices (l , j - jmin), ljm_index = ljm_indices (l , j - jmin , m + j), by looping over all values allowed by angular momentum coupling and incrementing index.
// One-dimensional array indices are then equal to: table.index_determine (  lm_index),      table.index_determine (  lj_index),      table.index_determine (  ljm_index)      for T(  l,ml),      T(  l,j),      T(  l,j,m),
//                                                  table.index_determine (n,lm_index),      table.index_determine (n,lj_index),      table.index_determine (n,ljm_index)      for T(n,l,ml),      T(n,l,j),      T(n,l,j,m),
//                                                  table.index_determine (n,lm_index,i),    table.index_determine (n,lj_index,i),    table.index_determine (n,ljm_index,i)    for T(n,l,ml,i),    T(n,l,j,i),    T(n,l,j,m,i), 
//                                                  table.index_determine (n,lm_index,i,i'), table.index_determine (n,lj_index,i,i'), table.index_determine (n,ljm_index,i,i') for T(n,l,ml,i,i'), T(n,l,j,i,i'), T(n,l,j,m,i,i').
//
// Input angular momenta and dimensions are obtained through the dimensions of table.
//
// Otherwise, member routines are wrappers of class array routines (see array_vector_class.hpp), as one can use allocation/deallocation of arrays or elements only (if elements are allocated before, see array_vector_class.hpp),
// operator overloading, copy to stream, read/copy to disk and MPI distribution similarly.
//
// In case it takes too much time to recalculate indices, one can directly use the straight brackets operator with the proper one-dimensional index.
// This is possible for T(...,i) and  T(..,i,i'), as the one-dimensional index I is equal to T.index_determine (...,0) + i or T.index_determine (...,0,0) + N1.i + i', 
// and for T(n,...,i) and  T(n,..,i,i'), as the one-dimensional index I is equal to T.index_determine (0,...,0) + N.n + i or T.index_determine (0,...,0,0) + N1.(N0.n + i) + i'
// with which one can use T[I] instead of T(...,i), T(...,i,i'), T(n,...,i), T(n,...,i,i').                 
// If it becomes an issue in other cases, one should use class array directly, as the former trick cannot be used if only angular momenta and angular momenta projections are present.
//
// Variables
// ---------
// l,j,ml,m; orbital, total angular momentum and their projections
// s,jmin,jmax: intrinsic spin, so that jmin <= j <= jmax, with jmin = |l - s| and jmax = l + s
// lmax: maximal orbital angular momentum
// nmax: maximal principal quantum number
// table: array where elements are stored
// lm_indices, lj_indices, ljm_indices, lm_index, lj_index, ljm_index: indices used in table to index (l,ml), (l,j) and (l,j,m) angular momenta and angular momenta projections, these indices for fixed l,j,m values.
// i,ip: i,i' (see above)


template<class C>
class lj_table
{
public:

  explicit lj_table () {}

  explicit lj_table (
		     const double s , 
		     const int lmax)
  {
    allocate (s , lmax);
  }

  explicit lj_table (
		     const double s , 
		     const int lmax , 
		     const unsigned int N)
  {
    allocate (s , lmax , N);
  }

  explicit lj_table (
		     const double s , 
		     const int lmax , 
		     const unsigned int N0 , 
		     const unsigned int N1)
  {
    allocate (s , lmax , N0 , N1);
  }

  lj_table (const class lj_table<C> &X)
  {
    allocate_fill (X);
  }

  void allocate (
		 const double s , 
		 const int lmax)
  {
    const int two_s_plus_one = make_int (2.0*s + 1);

    const int lmax_plus_one = lmax + 1;

    lj_indices.allocate (lmax_plus_one , two_s_plus_one);

    lj_indices = OUT_OF_RANGE;

    unsigned short int dimension_lj = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	const double jmin = abs (l - s);
	const double jmax =      l + s;

	const unsigned int j_number = make_uns_int (jmax - jmin) + 1;

	for (unsigned int j_index = 0 ; j_index < j_number ; j_index++)
	  {
	    lj_indices(l , j_index) = dimension_lj++;

	    if (dimension_lj == OUT_OF_RANGE) error_message_print_abort ("Table too large in lj_table::allocate (1)");
	  }
      }

    table.allocate (dimension_lj);
  }

  void allocate (
		 const double s , 
		 const int lmax , 
		 const unsigned int N)
  {
    const int two_s_plus_one = make_int (2.0*s + 1);

    const int lmax_plus_one = lmax + 1;

    lj_indices.allocate (lmax_plus_one , two_s_plus_one);

    lj_indices = OUT_OF_RANGE;

    unsigned short int dimension_lj = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	const double jmin = abs (l - s);
	const double jmax =      l + s;

	const unsigned int j_number = make_uns_int (jmax - jmin) + 1;

	for (unsigned int j_index = 0 ; j_index < j_number ; j_index++)
	  {
	    lj_indices(l , j_index) = dimension_lj++;

	    if (dimension_lj == OUT_OF_RANGE) error_message_print_abort ("Table too large in lj_table::allocate (2)");
	  }
      }

    table.allocate (dimension_lj , N);
  }

  void allocate (
		 const double s , 
		 const int lmax , 
		 const unsigned int N0 , 
		 const unsigned int N1)
  {
    const int two_s_plus_one = make_int (2.0*s + 1);

    const int lmax_plus_one = lmax + 1;

    lj_indices.allocate (lmax_plus_one , two_s_plus_one);

    lj_indices = OUT_OF_RANGE;

    unsigned short int dimension_lj = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	const double jmin = abs (l - s);
	const double jmax =      l + s;

	const unsigned int j_number = make_uns_int (jmax - jmin) + 1;

	for (unsigned int j_index = 0 ; j_index < j_number ; j_index++)
	  {
	    lj_indices(l , j_index) = dimension_lj++;

	    if (dimension_lj == OUT_OF_RANGE) error_message_print_abort ("Table too large in lj_table::allocate (3)");
	  }
      }

    table.allocate (dimension_lj , N0 , N1);
  }

  void allocate_fill (const class lj_table<C> &X)
  {
    lj_indices.allocate_fill (X.lj_indices);

    table.allocate_fill (X.table);
  }
  
  void deallocate ()
  {
    lj_indices.deallocate ();

    table.deallocate ();
  }

  void deallocate_object_elements ()
  {
    table.deallocate_object_elements ();
  }

  void operator = (const class lj_table<C> &X)
  {
    table = X.table;
  }

  void operator = (const C &x)
  {
    table = x;
  }

  class lj_table<C> operator + () const
  {
    return *this;
  }

  class lj_table<C> operator - () const
  {
    class lj_table<C> M = *this;

    M.table = -M.table;

    return M;
  }

  void operator += (const C &x)
  {
    table += x;
  }

  void operator -= (const C &x)
  {
    table -= x;
  }

  void operator *= (const C &x)
  {
    table *= x;
  }

  void operator /= (const C &x)
  {
    table /= x;
  }

  void operator += (const class lj_table<C> &A)
  {
    table += A.table;
  }

  void operator -= (const class lj_table<C> &A)
  {
    table -= A.table;
  }

  C & operator [] (const unsigned int i) const
  {
    return table[i];
  }

  unsigned int index_determine (const int l , const double j) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int lj_index = lj_indices (l , j_index);

    return table.index_determine (lj_index);
  }

  unsigned int index_determine (const int l , const double j , const unsigned int i) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int lj_index = lj_indices (l , j_index);

    return table.index_determine (lj_index , i);
  }

  unsigned int index_determine (const int l , const double j , const unsigned int i , const unsigned int ip) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int lj_index = lj_indices (l , j_index);

    return table.index_determine (lj_index , i , ip);
  }

  C & operator () (const int l , const double j) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int lj_index = lj_indices (l , j_index);

    return table(lj_index);
  }

  C & operator () (const int l , const double j , const unsigned int i) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int lj_index = lj_indices (l , j_index);

    return table(lj_index , i);
  }

  C & operator () (const int l , const double j , const unsigned int i , const unsigned int ip) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int lj_index = lj_indices (l , j_index);

    return table(lj_index , i , ip);
  }

  double get_s () const
  {
    return (0.5*(lj_indices.dimension (1) - 1));
  }

  int get_lmax () const
  {
    return (lj_indices.dimension (0) - 1);
  }

  unsigned int dimension (const unsigned int index) const
  {
    switch (index)
      {
      case 0: return table.dimension (1);
      case 1: return table.dimension (2);
      default: return 0;
      }

    return NADA;
  }

  unsigned int dimension_total () const
  {
    return table.dimension_total ();
  }

  void read_disk (const string &file_name)
  {
    table.read_disk (file_name);
  }

  void copy_disk (const string &file_name) const
  {
    table.copy_disk (file_name);
  }

  C sum () const
  {
    return table.sum ();
  }

  C product () const
  {
    return table.product ();
  }

  C max () const
  {
    return table.max ();
  }

  C min () const
  {
    return table.min ();
  }

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.first_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.last_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
  {
    return table.active_process_determine_for_MPI (group_processes_number , index);
  }

#ifdef UseMPI
  void MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const MPI_Comm MPI_C);
  void MPI_Reduce (MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif

  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }

  template <class D>
  friend ostream & operator << (ostream &os , const class lj_table<D> &T);
  
  template <class D>
  friend double used_memory_calc (const class lj_table<D> &T);
  
private:

  class array<unsigned short int> lj_indices;

  class array<C> table;
};


//  print overload.
// ----------------
template <class C>
ostream & operator << (ostream &os , const class lj_table<C> &T)
{
  return os << T.table;
}

// Memory of the class
// -------------------
template <class C>
double used_memory_calc (const class lj_table<C> &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.lj_indices) + used_memory_calc (T.table) - (sizeof (T.lj_indices) + sizeof (T.table))/1000000.0);
}


// "+" overloading.
// ----------------
template <typename C>  
class lj_table<C> operator + (const class lj_table<C> &A , const class lj_table<C> &B) 
{
  class lj_table<C> M = A;

  M += B;

  return M;
}




// "-" overloading.
// ----------------  
template <typename C>
class lj_table<C> operator - (const class lj_table<C> &A , const class lj_table<C> &B) 
{
  class lj_table<C> M = A;

  M -= B;

  return M;
}


// "*" overloading: A times x
//----------------------------
template <typename C>  
class lj_table<C> operator * (const class lj_table<C> &A , const C &x)
{
  class lj_table<C> M = A;

  M *= x;

  return M;
}



// "*" overloading: x times A
// ---------------------------
template <typename C>
class lj_table<C> operator * (const C &x , const class lj_table<C> &A) 
{
  class lj_table<C> M = A;

  M *= x;

  return M;
}





// "/" overloading: A over x
// --------------------------
template <typename C>  
class lj_table<C> operator / (const class lj_table<C> &A , const C &x) 
{
  class lj_table<C> M = A;

  M /= x;

  return M;
}








#ifdef UseMPI

template <class C>
void lj_table<C>::MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Send (receiving_process , tag , MPI_C);
}

template <class C>
void lj_table<C>::MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Recv (sending_process , tag , MPI_C);
}

template <class C>
void lj_table<C>::MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  table.MPI_Sendrecv_replace (Send_process , Recv_process , Send_tag , Recv_tag ,  MPI_C);
}

template <class C>
void lj_table<C>::MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C)
{
  table.MPI_Bcast (sending_process , MPI_C);
}

template <class C>
void lj_table<C>::MPI_Allgatherv (const MPI_Comm MPI_C)
{
  table.MPI_Allgatherv (MPI_C);
}

template <class C>
void lj_table<C>::MPI_Reduce (MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C)
{
  table.MPI_Reduce (op , receiving_process , MPI_C);
}

template <class C>
void lj_table<C>::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  table.MPI_Allreduce (op , MPI_C);
}

#endif




template<class C>
class nlj_table
{
public:

  explicit nlj_table () {}

  explicit nlj_table (
		      const double s ,
		      const int nmax ,
		      const int lmax)
  {
    allocate (s , nmax , lmax);
  }

  explicit nlj_table (
		      const double s , 
		      const int nmax ,
		      const int lmax , 
		      const unsigned int N)
  {
    allocate (s , nmax , lmax , N);
  }

  explicit nlj_table (
		      const double s , 
		      const int nmax ,
		      const int lmax , 
		      const unsigned int N0 , 
		      const unsigned int N1)
  {
    allocate (s , nmax , lmax , N0 , N1);
  }

  nlj_table (const class nlj_table<C> &X)
  {
    allocate_fill (X);
  }

  void allocate (
		 const double s , 
		 const int nmax ,
		 const int lmax)
  {
    const int two_s_plus_one = make_int (2.0*s + 1);

    const int lmax_plus_one = lmax + 1;
    const int nmax_plus_one = nmax + 1;

    lj_indices.allocate (lmax_plus_one , two_s_plus_one);

    lj_indices = OUT_OF_RANGE;

    unsigned short int dimension_lj = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	const double jmin = abs (l - s);
	const double jmax =      l + s;

	const unsigned int j_number = make_uns_int (jmax - jmin) + 1;

	for (unsigned int j_index = 0 ; j_index < j_number ; j_index++)
	  {
	    lj_indices(l , j_index) = dimension_lj++;

	    if (dimension_lj == OUT_OF_RANGE) error_message_print_abort ("Table too large in nlj_table::allocate (1)");
	  }
      }

    table.allocate (dimension_lj , nmax_plus_one);
  }

  void allocate (
		 const double s , 
		 const int nmax ,
		 const int lmax , 
		 const unsigned int N)
  {
    const int two_s_plus_one = make_int (2.0*s + 1);

    const int lmax_plus_one = lmax + 1;
    const int nmax_plus_one = nmax + 1;

    lj_indices.allocate (lmax_plus_one , two_s_plus_one);

    lj_indices = OUT_OF_RANGE;

    unsigned short int dimension_lj = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	const double jmin = abs (l - s);
	const double jmax =      l + s;

	const unsigned int j_number = make_uns_int (jmax - jmin) + 1;

	for (unsigned int j_index = 0 ; j_index < j_number ; j_index++)
	  {
	    lj_indices(l , j_index) = dimension_lj++;

	    if (dimension_lj == OUT_OF_RANGE) error_message_print_abort ("Table too large in nlj_table::allocate (2)");
	  }
      }

    table.allocate (dimension_lj , nmax_plus_one , N);
  }

  void allocate (
		 const double s , 
		 const int nmax ,
		 const int lmax , 
		 const unsigned int N0 , 
		 const unsigned int N1)
  {
    const int two_s_plus_one = make_int (2.0*s + 1);

    const int lmax_plus_one = lmax + 1;
    const int nmax_plus_one = nmax + 1;

    lj_indices.allocate (lmax_plus_one , two_s_plus_one);

    lj_indices = OUT_OF_RANGE;

    unsigned short int dimension_lj = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	const double jmin = abs (l - s);
	const double jmax =      l + s;

	const unsigned int j_number = make_uns_int (jmax - jmin) + 1;

	for (unsigned int j_index = 0 ; j_index < j_number ; j_index++)
	  {
	    lj_indices(l , j_index) = dimension_lj++;

	    if (dimension_lj == OUT_OF_RANGE) error_message_print_abort ("Table too large in nlj_table::allocate (3)");
	  }
      }

    table.allocate (dimension_lj , nmax_plus_one , N0 , N1);
  }

  void allocate_fill (const class nlj_table<C> &X)
  {
    lj_indices.allocate_fill (X.lj_indices);

    table.allocate_fill (X.table);
  }
  
  void deallocate ()
  {
    lj_indices.deallocate ();

    table.deallocate ();
  }

  void deallocate_object_elements ()
  {
    table.deallocate_object_elements ();
  }

  void operator = (const class nlj_table<C> &X)
  {
    table = X.table;
  }

  void operator = (const C &x)
  {
    table = x;
  }

  class nlj_table<C> operator + () const
  {
    return *this;
  }

  class nlj_table<C> operator - () const
  {
    class nlj_table<C> M = *this;

    M.table = -M.table;

    return M;
  }

  void operator += (const C &x)
  {
    table += x;
  }

  void operator -= (const C &x)
  {
    table -= x;
  }

  void operator *= (const C &x)
  {
    table *= x;
  }

  void operator /= (const C &x)
  {
    table /= x;
  }

  void operator += (const class nlj_table<C> &A)
  {
    table += A.table;
  }

  void operator -= (const class nlj_table<C> &A)
  {
    table -= A.table;
  }

  C & operator [] (const unsigned int i) const
  {
    return table[i];
  }

  unsigned int index_determine (const int n , const int l , const double j) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int lj_index = lj_indices (l , j_index);

    return table.index_determine (lj_index , n);
  }

  unsigned int index_determine (const int n , const int l , const double j , const unsigned int i) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int lj_index = lj_indices (l , j_index);

    return table.index_determine (lj_index , n , i);
  }

  unsigned int index_determine (const int n , const int l , const double j , const unsigned int i , const unsigned int ip) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int lj_index = lj_indices (l , j_index);

    return table.index_determine (lj_index , n , i , ip);
  }

  C & operator () (const int n , const int l , const double j) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int lj_index = lj_indices (l , j_index);

    return table(lj_index , n);
  }

  C & operator () (const int n , const int l , const double j , const unsigned int i) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int lj_index = lj_indices (l , j_index);

    return table(lj_index , n , i);
  }

  C & operator () (const int n , const int l , const double j , const unsigned int i , const unsigned int ip) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int lj_index = lj_indices (l , j_index);

    return table(lj_index , n , i , ip);
  }

  double get_s () const
  {
    return (0.5*(lj_indices.dimension (1) - 1));
  }

  int get_nmax () const
  {
    return (table.dimension (1) - 1);
  }

  int get_lmax () const
  {
    return (lj_indices.dimension (0) - 1);
  }

  unsigned int dimension (const unsigned int index) const
  {
    switch (index)
      {
      case 0: return table.dimension (2);
      case 1: return table.dimension (3);
      default: return 0;
      }

    return NADA;
  }

  unsigned int dimension_total () const
  {
    return table.dimension_total ();
  }

  void read_disk (const string &file_name)
  {
    table.read_disk (file_name);
  }

  void copy_disk (const string &file_name) const
  {
    table.copy_disk (file_name);
  }

  C sum () const
  {
    return table.sum ();
  }

  C product () const
  {
    return table.product ();
  }

  C max () const
  {
    return table.max ();
  }

  C min () const
  {
    return table.min ();
  }

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.first_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.last_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
  {
    return table.active_process_determine_for_MPI (group_processes_number , index);
  }

#ifdef UseMPI
  void MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const MPI_Comm MPI_C);
  void MPI_Reduce (MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif

  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }

  template <class D>
  friend ostream & operator << (ostream &os , const class nlj_table<D> &T);
  
  template <class D>
  friend double used_memory_calc (const class nlj_table<D> &T);
  
private:

  class array<unsigned short int> lj_indices;

  class array<C> table;
};



//  print overload.
// ----------------
template <class C>
ostream & operator << (ostream &os , const class nlj_table<C> &T)
{
  return os << T.table;
}

// Memory of the class
// -------------------
template <class C>
double used_memory_calc (const class nlj_table<C> &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.lj_indices) + used_memory_calc (T.table) - (sizeof (T.lj_indices) + sizeof (T.table))/1000000.0);
}



// "+" overloading.
// ----------------
template <typename C>  
class nlj_table<C> operator + (const class nlj_table<C> &A , const class nlj_table<C> &B) 
{
  class nlj_table<C> M = A;

  M += B;

  return M;
}




// "-" overloading.
// ----------------  
template <typename C>
class nlj_table<C> operator - (const class nlj_table<C> &A , const class nlj_table<C> &B) 
{
  class nlj_table<C> M = A;

  M -= B;

  return M;
}


// "*" overloading: A times x
//----------------------------
template <typename C>  
class nlj_table<C> operator * (const class nlj_table<C> &A , const C &x)
{
  class nlj_table<C> M = A;

  M *= x;

  return M;
}



// "*" overloading: x times A
// ---------------------------
template <typename C>
class nlj_table<C> operator * (const C &x , const class nlj_table<C> &A) 
{
  class nlj_table<C> M = A;

  M *= x;

  return M;
}





// "/" overloading: A over x
// --------------------------
template <typename C>  
class nlj_table<C> operator / (const class nlj_table<C> &A , const C &x) 
{
  class nlj_table<C> M = A;

  M /= x;

  return M;
}








#ifdef UseMPI

template <class C>
void nlj_table<C>::MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Send (receiving_process , tag , MPI_C);
}

template <class C>
void nlj_table<C>::MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  table.MPI_Sendrecv_replace (Send_process , Recv_process , Send_tag , Recv_tag , MPI_C);
}

template <class C>
void nlj_table<C>::MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Recv (sending_process , tag , MPI_C);
}

template <class C>
void nlj_table<C>::MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C)
{
  table.MPI_Bcast (sending_process , MPI_C);
}

template <class C>
void nlj_table<C>::MPI_Allgatherv (const MPI_Comm MPI_C)
{
  table.MPI_Allgatherv (MPI_C);
}

template <class C>
void nlj_table<C>::MPI_Reduce (MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C)
{
  table.MPI_Reduce (op , receiving_process , MPI_C);
}

template <class C>
void nlj_table<C>::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  table.MPI_Allreduce (op , MPI_C);
}

#endif










template<class C>
class lm_table
{
public:

  explicit lm_table () {}

  explicit lm_table (const int lmax)
  {
    allocate (lmax);
  }

  explicit lm_table (
		     const int lmax , 
		     const unsigned int N)
  {
    allocate (lmax , N);
  }

  explicit lm_table (
		     const int lmax , 
		     const unsigned int N0 , 
		     const unsigned int N1)
  {
    allocate (lmax , N0 , N1);
  }

  lm_table (const class lm_table<C> &X)
  {
    allocate_fill (X);
  }

  void allocate (const int lmax)
  {
    const int lmax_plus_one = lmax + 1;

    const int two_lmax_plus_one = 2*lmax + 1;

    lm_indices.allocate (lmax_plus_one , two_lmax_plus_one);

    lm_indices = OUT_OF_RANGE;

    unsigned short int dimension_lm = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	const unsigned int ml_number = make_uns_int (2*l + 1);

	for (unsigned int ml_index = 0 ; ml_index < ml_number ; ml_index++)
	  {
	    lm_indices(l , ml_index) = dimension_lm++;

	    if (dimension_lm == OUT_OF_RANGE) error_message_print_abort ("Table too large in lm_table::allocate (1)");
	  }
      }

    table.allocate (dimension_lm);
  }

  void allocate (
		 const int lmax , 
		 const unsigned int N)
  {
    const int lmax_plus_one = lmax + 1;

    const int two_lmax_plus_one = 2*lmax + 1;

    lm_indices.allocate (lmax_plus_one , two_lmax_plus_one);

    lm_indices = OUT_OF_RANGE;

    unsigned short int dimension_lm = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	const unsigned int ml_number = make_uns_int (2*l + 1);

	for (unsigned int ml_index = 0 ; ml_index < ml_number ; ml_index++)
	  {
	    lm_indices(l , ml_index) = dimension_lm++;

	    if (dimension_lm == OUT_OF_RANGE) error_message_print_abort ("Table too large in lm_table::allocate (2)");
	  }
      }

    table.allocate (dimension_lm , N);
  }

  void allocate (
		 const int lmax , 
		 const unsigned int N0 , 
		 const unsigned int N1)
  {
    const int lmax_plus_one = lmax + 1;

    const int two_lmax_plus_one = 2*lmax + 1;

    lm_indices.allocate (lmax_plus_one , two_lmax_plus_one);

    lm_indices = OUT_OF_RANGE;

    unsigned short int dimension_lm = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	const unsigned int ml_number = make_uns_int (2*l + 1);

	for (unsigned int ml_index = 0 ; ml_index < ml_number ; ml_index++)
	  {
	    lm_indices(l , ml_index) = dimension_lm++;

	    if (dimension_lm == OUT_OF_RANGE) error_message_print_abort ("Table too large in lm_table::allocate (3)");
	  }
      }

    table.allocate (dimension_lm , N0 , N1);
  }

  void allocate_fill (const class lm_table<C> &X)
  {
    lm_indices.allocate_fill (X.lm_indices);

    table.allocate_fill (X.table);
  }
  
  void deallocate ()
  {
    lm_indices.deallocate ();

    table.deallocate ();
  }

  void deallocate_object_elements ()
  {
    table.deallocate_object_elements ();
  }

  void operator = (const class lm_table<C> &X)
  {
    table = X.table;
  }

  void operator = (const C &x)
  {
    table = x;
  }

  class lm_table<C> operator + () const
  {
    return *this;
  }

  class lm_table<C> operator - () const
  {
    class lm_table<C> M = *this;

    M.table = -M.table;

    return M;
  }

  void operator += (const C &x)
  {
    table += x;
  }

  void operator -= (const C &x)
  {
    table -= x;
  }

  void operator *= (const C &x)
  {
    table *= x;
  }

  void operator /= (const C &x)
  {
    table /= x;
  }

  void operator += (const class lm_table<C> &A)
  {
    table += A.table;
  }

  void operator -= (const class lm_table<C> &A)
  {
    table -= A.table;
  }

  C & operator [] (const unsigned int i) const
  {
    return table[i];
  }

  unsigned int index_determine (const int l , const int ml) const
  {
    const unsigned int ml_index = make_uns_int (ml + l);

    const unsigned int lm_index = lm_indices (l, ml_index);

    return table.index_determine (lm_index);
  }

  unsigned int index_determine (const int l , const int ml , const unsigned int i) const
  {
    const unsigned int ml_index = make_uns_int (ml + l);

    const unsigned int lm_index = lm_indices (l, ml_index);

    return table.index_determine (lm_index , i);
  }

  unsigned int index_determine (const int l , const int ml , const unsigned int i , const unsigned int ip) const
  {
    const unsigned int ml_index = make_uns_int (ml + l);

    const unsigned int lm_index = lm_indices (l, ml_index);

    return table.index_determine (lm_index , i , ip);
  }

  C & operator () (const int l , const int ml) const
  {
    const unsigned int ml_index = make_uns_int (ml + l);

    const unsigned int lm_index = lm_indices (l, ml_index);

    return table(lm_index);
  }

  C & operator () (const int l , const int ml , const unsigned int i) const
  {
    const unsigned int ml_index = make_uns_int (ml + l);

    const unsigned int lm_index = lm_indices (l, ml_index);

    return table(lm_index , i);
  }

  C & operator () (const int l , const int ml , const unsigned int i , const unsigned int ip) const
  {
    const unsigned int ml_index = make_uns_int (ml + l);

    const unsigned int lm_index = lm_indices (l, ml_index);

    return table(lm_index , i , ip);
  }

  int get_lmax () const
  {
    return (lm_indices.dimension (0) - 1);
  }

  unsigned int dimension (const unsigned int index) const
  {
    switch (index)
      {
      case 0: return table.dimension (1);
      case 1: return table.dimension (2);
      default: return 0;
      }

    return NADA;
  }

  unsigned int dimension_total () const
  {
    return table.dimension_total ();
  }

  void read_disk (const string &file_name)
  {
    table.read_disk (file_name);
  }

  void copy_disk (const string &file_name) const
  {
    table.copy_disk (file_name);
  }

  C sum () const
  {
    return table.sum ();
  }

  C product () const
  {
    return table.product ();
  }

  C max () const
  {
    return table.max ();
  }

  C min () const
  {
    return table.min ();
  }

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.first_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.last_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
  {
    return table.active_process_determine_for_MPI (group_processes_number , index);
  }

#ifdef UseMPI
  void MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const MPI_Comm MPI_C);
  void MPI_Reduce (MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif

  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }

  template <class D>
  friend ostream & operator << (ostream &os , const class lm_table<D> &T);
  
  template <class D>
  double used_memory_calc (const class lm_table<D> &T);
  
private:

  class array<unsigned short int> lm_indices;

  class array<C> table;
};




//  print overload.
// ----------------
template <class C>
ostream & operator << (ostream &os , const class lm_table<C> &T)
{
  return os << T.table;
}

// Memory of the class
// -------------------
template <class C>
double used_memory_calc (const class lm_table<C> &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.lm_indices) + used_memory_calc (T.table) - (sizeof (T.lm_indices) + sizeof (T.table))/1000000.0);
}





// "+" overloading.
// ----------------
template <typename C>  
class lm_table<C> operator + (const class lm_table<C> &A , const class lm_table<C> &B) 
{
  class lm_table<C> M = A;

  M += B;

  return M;
}




// "-" overloading.
// ----------------  
template <typename C>
class lm_table<C> operator - (const class lm_table<C> &A , const class lm_table<C> &B) 
{
  class lm_table<C> M = A;

  M -= B;

  return M;
}


// "*" overloading: A times x
//----------------------------
template <typename C>  
class lm_table<C> operator * (const class lm_table<C> &A , const C &x)
{
  class lm_table<C> M = A;

  M *= x;

  return M;
}



// "*" overloading: x times A
// ---------------------------
template <typename C>
class lm_table<C> operator * (const C &x , const class lm_table<C> &A) 
{
  class lm_table<C> M = A;

  M *= x;

  return M;
}





// "/" overloading: A over x
// --------------------------
template <typename C>  
class lm_table<C> operator / (const class lm_table<C> &A , const C &x) 
{
  class lm_table<C> M = A;

  M /= x;

  return M;
}







#ifdef UseMPI

template <class C>
void lm_table<C>::MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Send (receiving_process , tag , MPI_C);
}

template <class C>
void lm_table<C>::MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Recv (sending_process , tag , MPI_C);
}

template <class C>
void lm_table<C>::MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  table.MPI_Sendrecv_replace (Send_process , Recv_process , Send_tag , Recv_tag , MPI_C);
}

template <class C>
void lm_table<C>::MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C)
{
  table.MPI_Bcast (sending_process , MPI_C);
}

template <class C>
void lm_table<C>::MPI_Allgatherv (const MPI_Comm MPI_C)
{
  table.MPI_Allgatherv (MPI_C);
}

template <class C>
void lm_table<C>::MPI_Reduce (MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C)
{
  table.MPI_Reduce (op , receiving_process , MPI_C);
}

template <class C>
void lm_table<C>::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  table.MPI_Allreduce (op , MPI_C);
}

#endif







template<class C>
class nlm_table
{
public:

  explicit nlm_table () {}

  explicit nlm_table (
		      const int nmax ,
		      const int lmax)

  {
    allocate (nmax , lmax);
  }

  explicit nlm_table ( 
		      const int nmax ,
		      const int lmax ,
		      const unsigned int N)
  {
    allocate (nmax , lmax , N);
  }

  explicit nlm_table (
		      const int nmax ,
		      const int lmax ,  
		      const unsigned int N0 , 
		      const unsigned int N1)
  {
    allocate (nmax , lmax , N0 , N1);
  }

  nlm_table (const class nlm_table<C> &X)
  {
    allocate_fill (X);
  }

  void allocate (
		 const int nmax ,
		 const int lmax)
  {
    const int lmax_plus_one = lmax + 1;
    const int nmax_plus_one = nmax + 1;

    const int two_lmax_plus_one = 2*lmax + 1;

    lm_indices.allocate (lmax_plus_one , two_lmax_plus_one);

    lm_indices = OUT_OF_RANGE;

    unsigned short int dimension_lm = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	const unsigned int ml_number = make_uns_int (2*l + 1);

	for (unsigned int ml_index = 0 ; ml_index < ml_number ; ml_index++)
	  {
	    lm_indices(l , ml_index) = dimension_lm++;

	    if (dimension_lm == OUT_OF_RANGE) error_message_print_abort ("Table too large in nlm_table::allocate (1)");
	  }
      }

    table.allocate (dimension_lm , nmax_plus_one);
  }

  void allocate ( 
		 const int nmax ,
		 const int lmax , 
		 const unsigned int N)
  {
    const int lmax_plus_one = lmax + 1;
    const int nmax_plus_one = nmax + 1;

    const int two_lmax_plus_one = 2*lmax + 1;

    lm_indices.allocate (lmax_plus_one , two_lmax_plus_one);

    lm_indices = OUT_OF_RANGE;

    unsigned short int dimension_lm = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	const unsigned int ml_number = make_uns_int (2*l + 1);

	for (unsigned int ml_index = 0 ; ml_index < ml_number ; ml_index++)
	  {
	    lm_indices(l , ml_index) = dimension_lm++;

	    if (dimension_lm == OUT_OF_RANGE) error_message_print_abort ("Table too large in nlm_table::allocate (2)");
	  }
      }

    table.allocate (dimension_lm , nmax_plus_one , N);
  }

  void allocate (
		 const int nmax ,
		 const int lmax , 
		 const unsigned int N0 , 
		 const unsigned int N1)
  {
    const int lmax_plus_one = lmax + 1;
    const int nmax_plus_one = nmax + 1;

    const int two_lmax_plus_one = 2*lmax + 1;

    lm_indices.allocate (lmax_plus_one , two_lmax_plus_one);

    lm_indices = OUT_OF_RANGE;

    unsigned short int dimension_lm = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	const unsigned int ml_number = make_uns_int (2*l + 1);

	for (unsigned int ml_index = 0 ; ml_index < ml_number ; ml_index++)
	  {
	    lm_indices(l , ml_index) = dimension_lm++;

	    if (dimension_lm == OUT_OF_RANGE) error_message_print_abort ("Table too large in nlm_table::allocate (3)");
	  }
      }

    table.allocate (dimension_lm , nmax_plus_one , N0 , N1);
  }

  void allocate_fill (const class nlm_table<C> &X)
  {
    lm_indices.allocate_fill (X.lm_indices);

    table.allocate_fill (X.table);
  }
  
  void deallocate ()
  {
    lm_indices.deallocate ();

    table.deallocate ();
  }

  void deallocate_object_elements ()
  {
    table.deallocate_object_elements ();
  }

  void operator = (const class nlm_table<C> &X)
  {
    table = X.table;
  }

  void operator = (const C &x)
  {
    table = x;
  }

  class nlm_table<C> operator + () const
  {
    return *this;
  }

  class nlm_table<C> operator - () const
  {
    class nlm_table<C> M = *this;

    M.table = -M.table;

    return M;
  }

  void operator += (const C &x)
  {
    table += x;
  }

  void operator -= (const C &x)
  {
    table -= x;
  }

  void operator *= (const C &x)
  {
    table *= x;
  }

  void operator /= (const C &x)
  {
    table /= x;
  }

  void operator += (const class nlm_table<C> &A)
  {
    table += A.table;
  }

  void operator -= (const class nlm_table<C> &A)
  {
    table -= A.table;
  }

  C & operator [] (const unsigned int i) const
  {
    return table[i];
  }

  unsigned int index_determine (const int n , const int l , const int ml) const
  {
    const unsigned int ml_index = make_uns_int (ml + l);

    const unsigned int lm_index = lm_indices (l, ml_index);

    return table.index_determine (lm_index , n);
  }

  unsigned int index_determine (const int n , const int l , const int ml , const unsigned int i) const
  { 
    const unsigned int ml_index = make_uns_int (ml + l);

    const unsigned int lm_index = lm_indices (l, ml_index);

    return table.index_determine (lm_index , n , i);
  }

  unsigned int index_determine (const int n , const int l , const int ml , const unsigned int i , const unsigned int ip) const
  {
    const unsigned int ml_index = make_uns_int (ml + l);

    const unsigned int lm_index = lm_indices (l, ml_index);

    return table.index_determine (lm_index , n , i , ip);
  }

  C & operator () (const int n , const int l , const int ml) const
  {
    const unsigned int ml_index = make_uns_int (ml + l);

    const unsigned int lm_index = lm_indices (l, ml_index);

    return table(lm_index , n);
  }

  C & operator () (const int n , const int l , const int ml , const unsigned int i) const
  {
    const unsigned int ml_index = make_uns_int (ml + l);

    const unsigned int lm_index = lm_indices (l, ml_index);

    return table(lm_index , n , i);
  }

  C & operator () (const int n , const int l , const int ml , const unsigned int i , const unsigned int ip) const
  {
    const unsigned int ml_index = make_uns_int (ml + l);

    const unsigned int lm_index = lm_indices (l, ml_index);

    return table(lm_index , n , i , ip);
  }

  int get_nmax () const
  {
    return (table.dimension (1) - 1);
  }

  int get_lmax () const
  {
    return (lm_indices.dimension (0) - 1);
  }

  unsigned int dimension (const unsigned int index) const
  {
    switch (index)
      {
      case 0: return table.dimension (2);
      case 1: return table.dimension (3);
      default: return 0;
      }

    return NADA;
  }

  unsigned int dimension_total () const
  {
    return table.dimension_total ();
  }

  void read_disk (const string &file_name)
  {
    table.read_disk (file_name);
  }

  void copy_disk (const string &file_name) const
  {
    table.copy_disk (file_name);
  }

  C sum () const
  {
    return table.sum ();
  }

  C product () const
  {
    return table.product ();
  }

  C max () const
  {
    return table.max ();
  }

  C min () const
  {
    return table.min ();
  }

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.first_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.last_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
  {
    return table.active_process_determine_for_MPI (group_processes_number , index);
  }

#ifdef UseMPI
  void MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const MPI_Comm MPI_C);
  void MPI_Reduce (MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif

  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }

  
  template <class D>
  friend ostream & operator << (ostream &os , const class nlm_table<D> &T);
  
  template <class D>
  double used_memory_calc (const class nlm_table<D> &T);
  
private:

  class array<unsigned short int> lm_indices;

  class array<C> table;
};



//  print overload.
// ----------------
template <class C>
ostream & operator << (ostream &os , const class nlm_table<C> &T)
{
  return os << T.table;
}

// Memory of the class
// -------------------
template <class C>
double used_memory_calc (const class nlm_table<C> &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.lm_indices) + used_memory_calc (T.table) - (sizeof (T.lm_indices) + sizeof (T.table))/1000000.0);
}


// "+" overloading.
// ----------------
template <typename C>  
class nlm_table<C> operator + (const class nlm_table<C> &A , const class nlm_table<C> &B) 
{
  class nlm_table<C> M = A;

  M += B;

  return M;
}




// "-" overloading.
// ----------------  
template <typename C>
class nlm_table<C> operator - (const class nlm_table<C> &A , const class nlm_table<C> &B) 
{
  class nlm_table<C> M = A;

  M -= B;

  return M;
}


// "*" overloading: A times x
//----------------------------
template <typename C>  
class nlm_table<C> operator * (const class nlm_table<C> &A , const C &x)
{
  class nlm_table<C> M = A;

  M *= x;

  return M;
}



// "*" overloading: x times A
// ---------------------------
template <typename C>
class nlm_table<C> operator * (const C &x , const class nlm_table<C> &A) 
{
  class nlm_table<C> M = A;

  M *= x;

  return M;
}





// "/" overloading: A over x
// --------------------------
template <typename C>  
class nlm_table<C> operator / (const class nlm_table<C> &A , const C &x) 
{
  class nlm_table<C> M = A;

  M /= x;

  return M;
}








#ifdef UseMPI

template <class C>
void nlm_table<C>::MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Send (receiving_process , tag , MPI_C);
}

template <class C>
void nlm_table<C>::MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Recv (sending_process , tag , MPI_C);
}

template <class C>
void nlm_table<C>::MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  table.MPI_Sendrecv_replace (Send_process , Recv_process , Send_tag , Recv_tag , MPI_C);
}

template <class C>
void nlm_table<C>::MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C)
{
  table.MPI_Bcast (sending_process , MPI_C);
}

template <class C>
void nlm_table<C>::MPI_Allgatherv (const MPI_Comm MPI_C)
{
  table.MPI_Allgatherv (MPI_C);
}

template <class C>
void nlm_table<C>::MPI_Reduce (MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C)
{
  table.MPI_Reduce (op , receiving_process , MPI_C);
}

template <class C>
void nlm_table<C>::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  table.MPI_Allreduce (op , MPI_C);
}

#endif











template<class C>
class ljm_table
{
public:

  explicit ljm_table () {}

  explicit ljm_table (
		      const double s , 
		      const int lmax ,
		      const double m_max)

  {
    allocate (s , lmax , m_max);
  }

  explicit ljm_table (
		      const double s , 
		      const int lmax ,
		      const double m_max , 
		      const unsigned int N)
  {
    allocate (s , lmax , m_max , N);
  }

  explicit ljm_table (
		      const double s , 
		      const int lmax , 
		      const double m_max , 
		      const unsigned int N0 , 
		      const unsigned int N1)
  {
    allocate (s , lmax , m_max , N0 , N1);
  }

  ljm_table (const class ljm_table<C> &X)
  {
    allocate_fill (X);
  }

  void allocate (
		 const double s , 
		 const int lmax ,
		 const double m_max)
  {
    const int two_s_plus_one = make_int (2.0*s + 1);
    
    const int two_jmax_plus_one = 2*lmax + two_s_plus_one;

    const int lmax_plus_one = lmax + 1;

    ljm_indices.allocate (lmax_plus_one , two_s_plus_one , two_jmax_plus_one);

    ljm_indices = OUT_OF_RANGE;

    unsigned short int dimension_ljm = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	const double jmin = abs (l - s);
	
	const double jmax = l + s;

	const unsigned int j_number = make_uns_int (jmax - jmin) + 1;

	for (unsigned int j_index = 0 ; j_index < j_number ; j_index++)
	  {
	    const double j = jmin + j_index;

	    const unsigned int m_number = make_uns_int (2.0*j + 1);

	    for (unsigned int m_index = 0 ; m_index < m_number ; m_index++)
	      {
		const double m = static_cast<double> (m_index) - j;

		if (rint (abs (m) - m_max) <= 0.0)
		  {
		    ljm_indices(l , j_index , m_index) = dimension_ljm++;

		    if (dimension_ljm == OUT_OF_RANGE) error_message_print_abort ("Table too large in ljm_table::allocate (1)");
		  }
	      }
	  }
      }

    table.allocate (dimension_ljm);
  }

  void allocate (
		 const double s , 
		 const int lmax , 
		 const double m_max , 
		 const unsigned int N)
  {
    const int two_s_plus_one = make_int (2.0*s + 1);
    
    const int two_jmax_plus_one = 2*lmax + two_s_plus_one;

    const int lmax_plus_one = lmax + 1;

    ljm_indices.allocate (lmax_plus_one , two_s_plus_one , two_jmax_plus_one);

    ljm_indices = OUT_OF_RANGE;

    unsigned short int dimension_ljm = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	const double jmin = abs (l - s);
	
	const double jmax = l + s;

	const unsigned int j_number = make_uns_int (jmax - jmin) + 1;

	for (unsigned int j_index = 0 ; j_index < j_number ; j_index++)
	  {
	    const double j = jmin + j_index;

	    const unsigned int m_number = make_uns_int (2.0*j + 1);

	    for (unsigned int m_index = 0 ; m_index < m_number ; m_index++)
	      {
		const double m = static_cast<double> (m_index) - j;

		if (rint (abs (m) - m_max) <= 0.0)
		  {
		    ljm_indices(l , j_index , m_index) = dimension_ljm++;

		    if (dimension_ljm == OUT_OF_RANGE) error_message_print_abort ("Table too large in ljm_table::allocate (2)");
		  }
	      }
	  }
      }

    table.allocate (dimension_ljm , N);
  }

  void allocate (
		 const double s , 
		 const int lmax , 
		 const double m_max , 
		 const unsigned int N0 , 
		 const unsigned int N1)
  {
    const int two_s_plus_one = make_int (2.0*s + 1);
    
    const int two_jmax_plus_one = 2*lmax + two_s_plus_one;

    const int lmax_plus_one = lmax + 1;

    ljm_indices.allocate (lmax_plus_one , two_s_plus_one , two_jmax_plus_one);

    ljm_indices = OUT_OF_RANGE;

    unsigned short int dimension_ljm = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	const double jmin = abs (l - s);
	const double jmax =      l + s;

	const unsigned int j_number = make_uns_int (jmax - jmin) + 1;

	for (unsigned int j_index = 0 ; j_index < j_number ; j_index++)
	  {
	    const double j = jmin + j_index;

	    const unsigned int m_number = make_uns_int (2.0*j + 1);

	    for (unsigned int m_index = 0 ; m_index < m_number ; m_index++)
	      {
		const double m = static_cast<double> (m_index) - j;

		if (rint (abs (m) - m_max) <= 0.0)
		  {
		    ljm_indices(l , j_index , m_index) = dimension_ljm++;

		    if (dimension_ljm == OUT_OF_RANGE) error_message_print_abort ("Table too large in ljm_table::allocate (3)");
		  }
	      }
	  }
      }

    table.allocate (dimension_ljm , N0 , N1);
  }

  void allocate_fill (const class ljm_table<C> &X)
  {
    ljm_indices.allocate_fill (X.ljm_indices);

    table.allocate_fill (X.table);
  }
  
  void deallocate ()
  {
    ljm_indices.deallocate ();

    table.deallocate ();
  }

  void deallocate_object_elements ()
  {
    table.deallocate_object_elements ();
  }

  void operator = (const class ljm_table<C> &X)
  {
    table = X.table;
  }

  void operator = (const C &x)
  {
    table = x;
  }

  class ljm_table<C> operator + () const
  {
    return *this;
  }

  class ljm_table<C> operator - () const
  {
    class ljm_table<C> M = *this;

    M.table = -M.table;

    return M;
  }

  void operator += (const C &x)
  {
    table += x;
  }

  void operator -= (const C &x)
  {
    table -= x;
  }

  void operator *= (const C &x)
  {
    table *= x;
  }

  void operator /= (const C &x)
  {
    table /= x;
  }

  void operator += (const class ljm_table<C> &A)
  {
    table += A.table;
  }

  void operator -= (const class ljm_table<C> &A)
  {
    table -= A.table;
  }

  C & operator [] (const unsigned int i) const
  {
    return table[i];
  }

  unsigned int index_determine (const int l , const double j , const double m) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int m_index = make_uns_int (m + j);

    const unsigned int ljm_index = ljm_indices (l , j_index , m_index);

    return table.index_determine (ljm_index);
  }

  unsigned int index_determine (const int l , const double j , const double m , const unsigned int i) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);
		
		const unsigned int j_index = make_uns_int (j - jmin);
    
		const unsigned int m_index = make_uns_int (m + j);

    const unsigned int ljm_index = ljm_indices (l , j_index , m_index);

    return table.index_determine (ljm_index , i);
  }

  unsigned int index_determine (const int l , const double j , const double m , const unsigned int i , const unsigned int ip) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);
		
		const unsigned int j_index = make_uns_int (j - jmin);
    
		const unsigned int m_index = make_uns_int (m + j);

    const unsigned int ljm_index = ljm_indices (l , j_index , m_index);

    return table.index_determine (ljm_index , i , ip);
  }

  C & operator () (const int l , const double j , const double m) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);
		
		const unsigned int j_index = make_uns_int (j - jmin);
    
		const unsigned int m_index = make_uns_int (m + j);

    const unsigned int ljm_index = ljm_indices (l , j_index , m_index);

    return table(ljm_index);
  }

  C & operator () (const int l , const double j , const double m , const unsigned int i) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);
		
		const unsigned int j_index = make_uns_int (j - jmin);
    
		const unsigned int m_index = make_uns_int (m + j);

    const unsigned int ljm_index = ljm_indices (l , j_index , m_index);

    return table(ljm_index , i);
  }

  C & operator () (const int l , const double j , const double m , const unsigned int i , const unsigned int ip) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);
		
		const unsigned int j_index = make_uns_int (j - jmin);
    
		const unsigned int m_index = make_uns_int (m + j);

    const unsigned int ljm_index = ljm_indices (l , j_index , m_index);

    return table(ljm_index , i , ip);
  }

  double get_s () const
  {
    return (0.5*(ljm_indices.dimension (1) - 1));
  }

  int get_lmax () const
  {
    return (ljm_indices.dimension (0) - 1);
  }

  double get_m_max () const
  {
    return (0.5*(ljm_indices.dimension (2) - 1));
  }

  unsigned int dimension (const unsigned int index) const
  {
    switch (index)
      {
      case 0: return table.dimension (1);
      case 1: return table.dimension (2);
      default: return 0;
      }

    return NADA;
  }

  unsigned int dimension_total () const
  {
    return table.dimension_total ();
  }

  void read_disk (const string &file_name)
  {
    table.read_disk (file_name);
  }

  void copy_disk (const string &file_name) const
  {
    table.copy_disk (file_name);
  }

  C sum () const
  {
    return table.sum ();
  }

  C product () const
  {
    return table.product ();
  }

  C max () const
  {
    return table.max ();
  }

  C min () const
  {
    return table.min ();
  }

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.first_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.last_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
  {
    return table.active_process_determine_for_MPI (group_processes_number , index);
  }

#ifdef UseMPI
  void MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const MPI_Comm MPI_C);
  void MPI_Reduce (MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif

  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }

  
  template <class D>
  friend ostream & operator << (ostream &os , const class ljm_table<D> &T);
  
  template <class D>
  double used_memory_calc (const class ljm_table<D> &T);
  
private:

  class array<unsigned short int> ljm_indices;

  class array<C> table;
};


//  print overload.
// ----------------
template <class C>
ostream & operator << (ostream &os , const class ljm_table<C> &T)
{
  return os << T.table;
}

// Memory of the class
// -------------------
template <class C>
double used_memory_calc (const class ljm_table<C> &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.ljm_indices) + used_memory_calc (T.table) - (sizeof (T.ljm_indices) + sizeof (T.table))/1000000.0);
}



// "+" overloading.
// ----------------
template <typename C>  
class ljm_table<C> operator + (const class ljm_table<C> &A , const class ljm_table<C> &B) 
{
  class ljm_table<C> M = A;

  M += B;

  return M;
}




// "-" overloading.
// ----------------  
template <typename C>
class ljm_table<C> operator - (const class ljm_table<C> &A , const class ljm_table<C> &B) 
{
  class ljm_table<C> M = A;

  M -= B;

  return M;
}


// "*" overloading: A times x
//----------------------------
template <typename C>  
class ljm_table<C> operator * (const class ljm_table<C> &A , const C &x)
{
  class ljm_table<C> M = A;

  M *= x;

  return M;
}



// "*" overloading: x times A
// ---------------------------
template <typename C>
class ljm_table<C> operator * (const C &x , const class ljm_table<C> &A) 
{
  class ljm_table<C> M = A;

  M *= x;

  return M;
}





// "/" overloading: A over x
// --------------------------
template <typename C>  
class ljm_table<C> operator / (const class ljm_table<C> &A , const C &x) 
{
  class ljm_table<C> M = A;

  M /= x;

  return M;
}








#ifdef UseMPI

template <class C>
void ljm_table<C>::MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Send (receiving_process , tag , MPI_C);
}

template <class C>
void ljm_table<C>::MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Recv (sending_process , tag , MPI_C);
}


template <class C>
void ljm_table<C>::MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  table.MPI_Sendrecv_replace (Send_process , Recv_process , Send_tag , Recv_tag , MPI_C);
}

template <class C>
void ljm_table<C>::MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C)
{
  table.MPI_Bcast (sending_process , MPI_C);
}

template <class C>
void ljm_table<C>::MPI_Allgatherv (const MPI_Comm MPI_C)
{
  table.MPI_Allgatherv (MPI_C);
}

template <class C>
void ljm_table<C>::MPI_Reduce (MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C)
{
  table.MPI_Reduce (op , receiving_process , MPI_C);
}

template <class C>
void ljm_table<C>::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  table.MPI_Allreduce (op , MPI_C);
}

#endif









template<class C>
class nljm_table
{
public:

  explicit nljm_table () {}

  explicit nljm_table (
		       const double s , 
		       const int nmax ,
		       const int lmax ,
		       const double m_max)

  {
    allocate (s , nmax , lmax , m_max);
  }

  explicit nljm_table (
		       const double s , 
		       const int nmax ,
		       const int lmax ,
		       const double m_max , 
		       const unsigned int N)
  {
    allocate (s , nmax , lmax , m_max , N);
  }

  explicit nljm_table (
		       const double s , 
		       const int nmax ,
		       const int lmax , 
		       const double m_max , 
		       const unsigned int N0 , 
		       const unsigned int N1)
  {
    allocate (s , nmax , lmax , m_max , N0 , N1);
  }

  nljm_table (const class nljm_table<C> &X)
  {
    allocate_fill (X);
  }

  void allocate (
		 const double s , 
		 const int nmax ,
		 const int lmax ,
		 const double m_max)
  {
    const int two_s_plus_one = make_int (2.0*s + 1);
    
    const int two_jmax_plus_one = 2*lmax + two_s_plus_one;

    const int lmax_plus_one = lmax + 1;
    const int nmax_plus_one = nmax + 1;

    ljm_indices.allocate (lmax_plus_one , two_s_plus_one , two_jmax_plus_one);

    ljm_indices = OUT_OF_RANGE;

    unsigned short int dimension_ljm = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	const double jmin = abs (l - s);
	const double jmax =      l + s;

	const unsigned int j_number = make_uns_int (jmax - jmin) + 1;

	for (unsigned int j_index = 0 ; j_index < j_number ; j_index++)
	  {
	    const double j = jmin + j_index;
	    
	    const unsigned int m_number = make_uns_int (2.0*j + 1);

	    for (unsigned int m_index = 0 ; m_index < m_number ; m_index++)
	      {
		const double m = static_cast<double> (m_index) - j;

		if (rint (abs (m) - m_max) <= 0.0)
		  {
		    ljm_indices(l , j_index , m_index) = dimension_ljm++;

		    if (dimension_ljm == OUT_OF_RANGE) error_message_print_abort ("Table too large in nljm_table::allocate (1)");
		  }
	      }
	  }
      }

    table.allocate (dimension_ljm , nmax_plus_one);
  }

  void allocate (
		 const double s , 
		 const int nmax ,
		 const int lmax , 
		 const double m_max , 
		 const unsigned int N)
  {
    const int two_s_plus_one = make_int (2.0*s + 1);
    
    const int two_jmax_plus_one = 2*lmax + two_s_plus_one;

    const int lmax_plus_one = lmax + 1;
    const int nmax_plus_one = nmax + 1;

    ljm_indices.allocate (lmax_plus_one , two_s_plus_one , two_jmax_plus_one);

    ljm_indices = OUT_OF_RANGE;

    unsigned short int dimension_ljm = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	const double jmin = abs (l - s);
	const double jmax =      l + s;

	const unsigned int j_number = make_uns_int (jmax - jmin) + 1;

	for (unsigned int j_index = 0 ; j_index < j_number ; j_index++)
	  {
	    const double j = jmin + j_index;
	    
	    const unsigned int m_number = make_uns_int (2.0*j + 1);

	    for (unsigned int m_index = 0 ; m_index < m_number ; m_index++)
	      {
		const double m = static_cast<double> (m_index) - j;

		if (rint (abs (m) - m_max) <= 0.0)
		  {
		    ljm_indices(l , j_index , m_index) = dimension_ljm++;

		    if (dimension_ljm == OUT_OF_RANGE) error_message_print_abort ("Table too large in nljm_table::allocate (2)");
		  }
	      }
	  }
      }

    table.allocate (dimension_ljm , nmax_plus_one , N);
  }

  void allocate (
		 const double s , 
		 const int nmax ,
		 const int lmax , 
		 const double m_max , 
		 const unsigned int N0 , 
		 const unsigned int N1)
  {
    const int two_s_plus_one = make_int (2.0*s + 1);
    
    const int two_jmax_plus_one = 2*lmax + two_s_plus_one;

    const int lmax_plus_one = lmax + 1;
    const int nmax_plus_one = nmax + 1;

    ljm_indices.allocate (lmax_plus_one , two_s_plus_one , two_jmax_plus_one);

    ljm_indices = OUT_OF_RANGE;

    unsigned short int dimension_ljm = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	const double jmin = abs (l - s);
	const double jmax =      l + s;

	const unsigned int j_number = make_uns_int (jmax - jmin) + 1;

	for (unsigned int j_index = 0 ; j_index < j_number ; j_index++)
	  {
	    const double j = jmin + j_index;
	    
	    const unsigned int m_number = make_uns_int (2.0*j + 1);

	    for (unsigned int m_index = 0 ; m_index < m_number ; m_index++)
	      {
		const double m = static_cast<double> (m_index) - j;

		if (rint (abs (m) - m_max) <= 0.0)
		  {
		    ljm_indices(l , j_index , m_index) = dimension_ljm++;

		    if (dimension_ljm == OUT_OF_RANGE) error_message_print_abort ("Table too large in nljm_table::allocate (3)");
		  }
	      }
	  }
      }

    table.allocate (dimension_ljm , nmax_plus_one , N0 , N1);
  }

  void allocate_fill (const class nljm_table<C> &X)
  {
    ljm_indices.allocate_fill (X.ljm_indices);

    table.allocate_fill (X.table);
  }
  
  void deallocate ()
  {
    ljm_indices.deallocate ();

    table.deallocate ();
  }

  void deallocate_object_elements ()
  {
    table.deallocate_object_elements ();
  }

  void operator = (const class nljm_table<C> &X)
  {
    table = X.table;
  }

  void operator = (const C &x)
  {
    table = x;
  }

  class nljm_table<C> operator + () const
  {
    return *this;
  }

  class nljm_table<C> operator - () const
  {
    class nljm_table<C> M = *this;

    M.table = -M.table;

    return M;
  }

  void operator += (const C &x)
  {
    table += x;
  }

  void operator -= (const C &x)
  {
    table -= x;
  }

  void operator *= (const C &x)
  {
    table *= x;
  }

  void operator /= (const C &x)
  {
    table /= x;
  }

  void operator += (const class nljm_table<C> &A)
  {
    table += A.table;
  }

  void operator -= (const class nljm_table<C> &A)
  {
    table -= A.table;
  }

  C & operator [] (const unsigned int i) const
  {
    return table[i];
  }

  unsigned int index_determine (const int n , const int l , const double j , const double m) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int m_index = make_uns_int (m + j);

    const unsigned int ljm_index = ljm_indices (l , j_index , m_index);

    return table.index_determine (ljm_index , n);
  }

  unsigned int index_determine (const int n , const int l , const double j , const double m , const unsigned int i) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int m_index = make_uns_int (m + j);

    const unsigned int ljm_index = ljm_indices (l , j_index , m_index);

    return table.index_determine (ljm_index , n , i);
  }

  unsigned int index_determine (const int n , const int l , const double j , const double m , const unsigned int i , const unsigned int ip) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int m_index = make_uns_int (m + j);

    const unsigned int ljm_index = ljm_indices (l , j_index , m_index);

    return table.index_determine (ljm_index , n , i , ip);
  }

  C & operator () (const int n , const int l , const double j , const double m) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int m_index = make_uns_int (m + j);

    const unsigned int ljm_index = ljm_indices (l , j_index , m_index);

    return table(ljm_index , n);
  }

  C & operator () (const int n , const int l , const double j , const double m , const unsigned int i) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int m_index = make_uns_int (m + j);

    const unsigned int ljm_index = ljm_indices (l , j_index , m_index);

    return table(ljm_index , n , i);
  }

  C & operator () (const int n , const int l , const double j , const double m , const unsigned int i , const unsigned int ip) const
  {
    const double s = get_s ();
    
    const double jmin = abs (l - s);

    const unsigned int j_index = make_uns_int (j - jmin);

    const unsigned int m_index = make_uns_int (m + j);

    const unsigned int ljm_index = ljm_indices (l , j_index , m_index);

    return table(ljm_index , n , i , ip);
  }

  double get_s () const
  {
    return (0.5*(ljm_indices.dimension (1) - 1));
  }

  int get_nmax () const
  {
    return (table.dimension (1) - 1);
  }

  int get_lmax () const
  {
    return (ljm_indices.dimension (0) - 1);
  }

  double get_m_max () const
  {
    return (0.5*(ljm_indices.dimension (2) - 1));
  }

  unsigned int dimension (const unsigned int index) const
  {
    switch (index)
      {
      case 0: return table.dimension (2);
      case 1: return table.dimension (3);
      default: return 0;
      }

    return NADA;
  }

  unsigned int dimension_total () const
  {
    return table.dimension_total ();
  }

  void read_disk (const string &file_name)
  {
    table.read_disk (file_name);
  }

  void copy_disk (const string &file_name) const
  {
    table.copy_disk (file_name);
  }

  C sum () const
  {
    return table.sum ();
  }

  C product () const
  {
    return table.product ();
  }

  C max () const
  {
    return table.max ();
  }

  C min () const
  {
    return table.min ();
  }

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.first_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.last_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
  {
    return table.active_process_determine_for_MPI (group_processes_number , index);
  }

#ifdef UseMPI
  void MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const MPI_Comm MPI_C);
  void MPI_Reduce (MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif

  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }

  
  template <class D>
  friend ostream & operator << (ostream &os , const class nljm_table<D> &T);
  
  template <class D>
  friend double used_memory_calc (const class nljm_table<D> &T);
  
private:

  class array<unsigned short int> ljm_indices;

  class array<C> table;
};



//  print overload.
// ----------------
template <class C>
ostream & operator << (ostream &os , const class nljm_table<C> &T)
{
  return os << T.table;
}

// Memory of the class
// -------------------
template <class C>
double used_memory_calc (const class nljm_table<C> &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.ljm_indices) + used_memory_calc (T.table) - (sizeof (T.ljm_indices) + sizeof (T.table))/1000000.0);
}


// "+" overloading.
// ----------------
template <typename C>  
class nljm_table<C> operator + (const class nljm_table<C> &A , const class nljm_table<C> &B) 
{
  class nljm_table<C> M = A;

  M += B;

  return M;
}




// "-" overloading.
// ----------------  
template <typename C>
class nljm_table<C> operator - (const class nljm_table<C> &A , const class nljm_table<C> &B) 
{
  class nljm_table<C> M = A;

  M -= B;

  return M;
}


// "*" overloading: A times x
//----------------------------
template <typename C>  
class nljm_table<C> operator * (const class nljm_table<C> &A , const C &x)
{
  class nljm_table<C> M = A;

  M *= x;

  return M;
}



// "*" overloading: x times A
// ---------------------------
template <typename C>
class nljm_table<C> operator * (const C &x , const class nljm_table<C> &A) 
{
  class nljm_table<C> M = A;

  M *= x;

  return M;
}





// "/" overloading: A over x
// --------------------------
template <typename C>  
class nljm_table<C> operator / (const class nljm_table<C> &A , const C &x) 
{
  class nljm_table<C> M = A;

  M /= x;

  return M;
}








#ifdef UseMPI

template <class C>
void nljm_table<C>::MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Send (receiving_process , tag , MPI_C);
}

template <class C>
void nljm_table<C>::MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Recv (sending_process , tag , MPI_C);
}

template <class C>
void nljm_table<C>::MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  table.MPI_Sendrecv_replace (Send_process , Recv_process , Send_tag , Recv_tag , MPI_C);
}

template <class C>
void nljm_table<C>::MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C)
{
  table.MPI_Bcast (sending_process , MPI_C);
}

template <class C>
void nljm_table<C>::MPI_Allgatherv (const MPI_Comm MPI_C)
{
  table.MPI_Allgatherv (MPI_C);
}

template <class C>
void nljm_table<C>::MPI_Reduce (MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C)
{
  table.MPI_Reduce (op , receiving_process , MPI_C);
}

template <class C>
void nljm_table<C>::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  table.MPI_Allreduce (op , MPI_C);
}

#endif







#endif


