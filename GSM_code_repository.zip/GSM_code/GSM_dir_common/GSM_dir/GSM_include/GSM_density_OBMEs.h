#ifndef GSMDENSITYOBMES_H
#define GSMDENSITYOBMES_H 

// TYPE is double or complex
// -------------------------

namespace density_OBMEs
{
  void OBMEs_shells_calc (
			  const enum particle_type density_particle ,
			  const bool is_it_radial ,
			  const bool is_it_Gauss_Legendre , 
			  const class baryons_data &particles_data ,
			  class array<TYPE> &OBMEs);

  void OBMEs_calc (
		   const enum particle_type density_particle ,
		   const bool is_it_radial ,
		   const bool is_it_Gauss_Legendre , 
		   const class baryons_data &particles_data ,
		   class array<TYPE> &OBMEs);
}

#endif


