#ifndef GSMARRAYBPNSCATICIMSD_H
#define GSMARRAYBPNSCATICIMSD_H



// Class of array type to store data related to Slater determinants, of the form T(BP , n_scat , iC , iM , SD_index)
// -----------------------------------------------------------------------------------------------------------------
// This class is defined as template of type C, so that C can be any type compatible with the class.
//
// One considers only proton or neutron Slater determinants here.
// A Slater determinant is defined by its parity (here its binary parity BP, see observables_basic_functions.cpp for definition),
// its number of protons or neutrons in the continuum n_scat, its configuration index iC, its angular momentum projection index (see GSM_vector_dimensions.cpp for definition) and Slater determinant index.
// Hence, T(BP , n_scat , iC , iM , SD_index) is a quantity related to a fixed Slater determinant.
// 
// One created a class for this type of storage for as the number of Slater determinants differs according to their configuration and angular momentum projection.
// Hence, one would store too many unused values if one allocated a class array with T.allocate (2 , n_scat_max + 1 , configuration_dimension_max + 1 , iM_max + 1 , SD_dimension_max + 1),
// as dimensions increase very quickly with n_scat.
//
// Hence, one allocates a one-dimensional array, called table, storing the elements T(BP , n_scat , iC , iM , SD_index) of dimension dimension_table, 
// where dimension_table is the total number of Slater determinants.
//
// The index I associated to (BP , n_scat , iC , iM , SD_index) in T(BP , n_scat , iC , iM , SD_index) is obtained from the array sum_dimensions_SD_set:
// I = sum_dimensions_SD_set(BP , n_scat , iC , iM) and T(BP , n_scat , iC , iM , SD_index) = table[IT = I + SD_index], where the one-dimensional index of table, IT, has been defined.
// One has T[IT] = table[iT] = T(BP , n_scat , iC , iM , SD_index), this using straight and curly brackets member operators. Similarly, IT = T.index_determine (BP , n_scat , iC , iM , SD_index).
//
// sum_dimensions_SD_set is a class array_BP_Nscat_iC, where the same memory saving techniques used in this class with Slater determinants are used with configurations.
//
// For example, let us take n_scat_max = 2, 2 configurations for n_scat = 0, 10 configurations for n_scat = 1 and 100 configurations for n_scat = 2.
// One also takes the same numbers for BP=0,1 , corresponding to 1 and -1 parities (see observables_basic_functions.cpp for definition).
// Let us also assume that one  has for simplicity 10 angular momenta projection per configuration and 5 Slater determinants per configuration and angular momentum projection if BP=0
// and that afterwards one also has for simplicity 20 angular momenta projection per configuration and 2 Slater determinants per configuration and angular momentum projection if BP=1.
//
// The one-dimensional index I of T(BP , n_scat , iC , iM , SD_index) is then for:
// BP = 0, n_scat = 1, iC = 3  , iM = 7, SD_index = 3: I = 2*50 + 3*50 + 7*5 + 3 = 288
// BP = 0, n_scat = 2, iC = 55 , iM = 7, SD_index = 3: I = 2*50 + 10*50 + 55*50 + 7*5 + 3 = 3388
// BP = 1, n_scat = 1, iC = 3  , iM = 7, SD_index = 3: I = 2*50 + 10*50 + 100*50 + 2*40 + 3*40 + 7*2 + 3 = 5817
// BP = 1, n_scat = 2, iC = 55 , iM = 7, SD_index = 3: I = 2*50 + 10*50 + 100*50 + 2*40 + 10*40 + 55*40 + 7*4 + 3 = 8308
//
// The constructors, destructors, allocation and deallocation routines, and index calculation routines are very similar to that in class array.
// The used memory of the class (in Mb) can be calculated in used_memory_calc.
// Its content can be printed on a stream (such as cout << T << endl).
// It can be distributed with MPI as well as typical distribution routines are coded, which are simple wrappers to the MPI routines of class array (see below).
// closest_value_index_determine provides with the index whose value is closest to the element provided (order must be defined for the used type then).
// 
// Variables
// ---------
// dimension_table: number of Slater determinants in T(BP , n_scat , iC , iM , SD_index)
// sum_dimensions_SD_set, sum_dimensions_SD_set_ptr: array of sums of Slater determinants (see above). 
//                                                   Its pointer address is stored in the array_BP_Nscat_iC_iM_SD class, so that the latter array must exist when using the class. No test is made.
// table: one-dimensional array where the T(BP , n_scat , iC , iM , SD_index) elements are stored.



template <class C>
class array_BP_Nscat_iC_iM_SD
{
public:
  array_BP_Nscat_iC_iM_SD () :
    sum_dimensions_SD_set_ptr (NULL)
  {}
  
  array_BP_Nscat_iC_iM_SD (
			   const unsigned int dimension_table , 
			   const class array_BP_Nscat_iC<unsigned long int> &sum_dimensions_SD_set)
  {
    allocate (dimension_table , sum_dimensions_SD_set);
  }

  array_BP_Nscat_iC_iM_SD (const class array_BP_Nscat_iC_iM_SD<C> &X)
  {
    allocate_fill (X);
  }
  
  void allocate (
		 const unsigned int dimension_table , 
		 const class array_BP_Nscat_iC<unsigned long int> &sum_dimensions_SD_set)
  {
    sum_dimensions_SD_set_ptr = &sum_dimensions_SD_set;
    
    table.allocate (dimension_table);
  }

  void allocate_fill (const class array_BP_Nscat_iC_iM_SD<C> &X)
  {
    sum_dimensions_SD_set_ptr = X.sum_dimensions_SD_set_ptr;
    
    table.allocate_fill (X.table);
  }

  void deallocate ()
  {
    table.deallocate ();
    
    sum_dimensions_SD_set_ptr = NULL;
  }
  
  void deallocate_object_elements () 
  {
    table.deallocate_table_object_elements ();
  }
  
  unsigned long int index_determine (
				     const unsigned int BP , 
				     const int n_scat , 
				     const unsigned int iC , 
				     const int iM , 
				     const unsigned int SD_index) const
  {
    const class array_BP_Nscat_iC<unsigned long int> &sum_dimensions_SD_set = get_sum_dimensions_SD_set ();

    const unsigned long int index = SD_index + sum_dimensions_SD_set(BP , n_scat , iC , iM);
    
    return index;
  }

  void operator = (const C &x)
  {
    table = x;
  }

  C & operator [] (const unsigned int i) const
  {
    return table[i];	
  }

  C & operator () (
		   const unsigned int BP , 
		   const int n_scat , 
		   const unsigned int iC , 
		   const int iM , 
		   const unsigned int SD_index) const
  {
    const unsigned int index = index_determine (BP , n_scat , iC , iM , SD_index); 
    
    return table[index];
  }

  template <class D>
  friend double used_memory_calc (const class array_BP_Nscat_iC_iM_SD<D> &T);

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const;
  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const;
  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const;
  unsigned int closest_value_index_determine (const C &x) const;
  
#ifdef UseMPI
  void MPI_Send  (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv  (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif

  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }

  template <class D>
  friend ostream & operator << (ostream &os , const class array_BP_Nscat_iC_iM_SD<D> &T);
  
private:

  const class array_BP_Nscat_iC<unsigned long int> & get_sum_dimensions_SD_set () const
  {
    return *sum_dimensions_SD_set_ptr;
  }
 
  const class array_BP_Nscat_iC<unsigned long int> *sum_dimensions_SD_set_ptr;
  
  class array<C> table;
};



// The array of the sum_dimensions_SD_set_ptr pointer is not considered as part of the class as it not allocated inside the class definition.

template <class C>
double used_memory_calc (const class array_BP_Nscat_iC_iM_SD<C> &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.table) - sizeof (T.table)/1000000.0);
}


template <class C>
ostream & operator << (ostream &os , const class array_BP_Nscat_iC_iM_SD<C> &T)
{
  return os << T.table;
}


template <class C>
unsigned int array_BP_Nscat_iC_iM_SD<C>::first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
{
  return table.first_index_determine_for_MPI (group_processes_number , process);
}

template <class C>
unsigned int array_BP_Nscat_iC_iM_SD<C>::last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
{
  return table.last_index_determine_for_MPI (group_processes_number , process);
}

template <class C>
unsigned int array_BP_Nscat_iC_iM_SD<C>::active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
{
  return table.active_process_determine_for_MPI (group_processes_number , index);
}

template <class C>
unsigned int array_BP_Nscat_iC_iM_SD<C>::closest_value_index_determine (const C &x) const
{
  return table.get_closest_index_determine (x);
}






#ifdef UseMPI

template <class C>
void array_BP_Nscat_iC_iM_SD<C>::MPI_Send (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Send (Recv_process , tag , MPI_C);
}

template <class C>
void array_BP_Nscat_iC_iM_SD<C>::MPI_Recv (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Recv (Send_process , tag , MPI_C);
}

template <class C>
void array_BP_Nscat_iC_iM_SD<C>::MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  table.MPI_Sendrecv_replace (Send_process , Recv_process , Send_tag , Recv_tag ,  MPI_C);
}

template <class C>
void array_BP_Nscat_iC_iM_SD<C>::MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C)
{
  table.MPI_Allgatherv (group_processes_number , MPI_C);
}

template <class C>
void array_BP_Nscat_iC_iM_SD<C>::MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  table.MPI_Bcast (Send_process , MPI_C);
}

template <class C>
void array_BP_Nscat_iC_iM_SD<C>::MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  table.MPI_Reduce (op , Recv_process , process , MPI_C);
}

template <class C>
void array_BP_Nscat_iC_iM_SD<C>::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  table.MPI_Allreduce (op , MPI_C);
}

#endif

#endif

