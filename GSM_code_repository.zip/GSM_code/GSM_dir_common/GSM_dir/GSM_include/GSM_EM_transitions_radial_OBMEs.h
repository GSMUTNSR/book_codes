#ifndef GSMEMTRANSITIONSRADIALOBMES_H
#define GSMEMTRANSITIONSRADIALOBMES_H

// TYPE is double or complex
// -------------------------

namespace EM_transitions_radial_OBMEs
{   
  TYPE radial_integral_HO_calc (
				const enum radial_operator_type radial_operator , 
				const TYPE &q , 
				const int L , 
				const bool is_it_longwavelength_approximation , 
				const class interaction_class &inter_data , 
				const unsigned int a , 
				const unsigned int b);

  TYPE radial_integral_calc (
			     const enum radial_operator_type radial_operator , 
			     const TYPE &q , 
			     const int L , 
			     const bool is_it_longwavelength_approximation , 
			     const bool is_it_HO_expansion , 
			     const class spherical_state &wf_in , 
			     const class spherical_state &wf_out);
  
  void radial_OBMEs_calc (
			  const enum radial_operator_type radial_operator , 
			  const TYPE &q , 
			  const int L , 
			  const bool is_it_longwavelength_approximation , 
			  const bool is_it_HO_expansion , 	
			  const unsigned int BP_Op , 
			  const class interaction_class &inter_data , 
			  const class nucleons_data &data , 
			  class array<TYPE > &radial_OBME);
}

#endif


