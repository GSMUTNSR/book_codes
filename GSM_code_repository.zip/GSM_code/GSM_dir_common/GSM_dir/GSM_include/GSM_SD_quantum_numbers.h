#ifndef GSMSDQUANTUMNUMBERS_H
#define GSMSDQUANTUMNUMBERS_H

// TYPE is double or complex
// -------------------------

class SD_quantum_numbers
{
public:

  SD_quantum_numbers ();

  SD_quantum_numbers (
		      const unsigned char BP_c ,
		      const unsigned char S_c ,
		      const unsigned char n_spec_c ,
		      const unsigned char n_scat_c ,
		      const unsigned int iC_c , 
		      const unsigned short int iM_c , 
		      const unsigned int SD_index_c);

  void initialize (
		   const unsigned char BP_c ,
		   const unsigned char S_c ,
		   const unsigned char n_spec_c ,
		   const unsigned char n_scat_c ,
		   const unsigned int iC_c , 
		   const unsigned short int iM_c , 
		   const unsigned int SD_index_c);
  
  void initialize (const class SD_quantum_numbers &X);
  
  void allocate_fill (const class SD_quantum_numbers &X);
	
  unsigned char get_BP () const
  {
    return BP;
    
  }

  unsigned char get_S () const
  {
    return S;
    
  }
  
  unsigned char get_n_spec () const
  {
    return n_spec;
  }
  
  unsigned char get_n_scat () const
  {
    return n_scat;
  }
  
  unsigned int get_iC () const
  {
    return iC;
  }
  
  unsigned short int get_iM () const
  {
    return iM;
  }
  
  unsigned int get_SD_index () const
  {
    return SD_index;
  }
  
private:
  
  unsigned char BP; // binary parity of the SD
  
  unsigned char S; // strangeness of the SD

  unsigned char n_spec; // number of spectator pairs in the SD (see enum_struct_definitions.h) .
  
  unsigned char n_scat; // number of particles in the continuum of the SD

  unsigned int iC; // index of configuration of the SD
  
  unsigned short int iM; //  angular momentum projection of the SD + M[max], with M[max] = N_valence_baryons . m[max], so that it is an integer
  
  unsigned int SD_index; // the index of the SD
};

bool operator == (const class SD_quantum_numbers &A , const class SD_quantum_numbers &B);

bool operator != (const class SD_quantum_numbers &A , const class SD_quantum_numbers &B);

double used_memory_calc (const class SD_quantum_numbers &T);

#endif


