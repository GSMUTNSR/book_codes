#ifndef GSMBETATRANSITIONSSTRENGTHOBMES_H
#define GSMBETATRANSITIONSSTRENGTHOBMES_H

// TYPE is double or complex
// -------------------------

namespace beta_transitions_strength_OBMEs
{

  void radial_OBMEs_states_fixed_calc (
				       const enum radial_operator_type radial_operator , 
				       const double R_charge , 
				       const bool is_it_Gauss_Legendre , 
				       const bool is_Hamiltonian_complex_scaled ,
				       const TYPE exp_I_theta_H_complex_scaled ,
				       const TYPE exp_minus_I_theta_H_complex_scaled ,
				       const class spherical_state &wf_in , 
				       const class spherical_state &wf_out , 
				       class array<TYPE> &radial_OBMEs_states_fixed);

  void radial_OBMEs_calc (
			  const enum radial_operator_type radial_operator ,
			  const bool is_it_Gauss_Legendre ,  
			  const class baryons_data &data_in , 
			  const class baryons_data &data_out , 
			  class array<TYPE> &radial_OBMEs);
 
  void beta_suboperator_OBMEs_reduced_calc (
					    const enum radial_operator_type radial_operator , 
					    const enum beta_suboperator_type beta_suboperator , 
					    const bool is_it_Gauss_Legendre , 
					    const class baryons_data &data_in , 
					    const class baryons_data &data_out , 
					    class array<TYPE> &OBMEs);

  void beta_suboperator_OBMEs_calc (
				    const enum radial_operator_type radial_operator , 
				    const enum beta_suboperator_type beta_suboperator , 
				    const int rank_Op_projection ,
				    const bool is_it_Gauss_Legendre , 
				    const class baryons_data &data_in , 
				    const class baryons_data &data_out , 
				    class array<TYPE> &OBMEs);
 
}

#endif


