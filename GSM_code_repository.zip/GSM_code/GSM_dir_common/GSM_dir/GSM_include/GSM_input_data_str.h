#ifndef GSMINPUTDATASTR_H
#define GSMINPUTDATASTR_H

// TYPE is double or complex
// -------------------------

// TBME means two-body matrix element
// ----------------------------------

// CC means coupled-channels
// -------------------------

// CM means center of mass
// -----------------------




// Class storing input data of the input file or simple functions of them 
// ----------------------------------------------------------------------

class input_data_str
{
public:

  // Constructors, destructors, allocation and deallocation
  // ------------------------------------------------------
  // There are no direct allocations as input_data_str is created continuously when reading the input file.
  // The allocate_fill copy constructor is used only in GSM-CC, 
  // where the input_data_str class containing data for the Berggren basis representation of the coupled-channel equations
  // is not read from file but partially created from the initial input_data_str class.

  input_data_str (); 

  ~input_data_str ();     

  void allocate_fill (const class input_data_str &X);

  void deallocate ();

  // Simple routines providing with the value of private variables or setting them to a fixed value
  // ----------------------------------------------------------------------------------------------

  bool get_print_detailed_information () const
  {
    return print_detailed_information;
  }

  bool get_is_cost_function_Hessian_matrix_calculated () const
  {
    return is_cost_function_Hessian_matrix_calculated;
  }

  unsigned int get_number_of_MPI_processes () const
  {
    return number_of_MPI_processes;
  }

  unsigned int get_number_of_OpenMP_threads () const
  {
    return number_of_OpenMP_threads;
  }

  unsigned int get_BPmin_global_pp () const
  {
    return BPmin_global_pp;
  }

  unsigned int get_BPmax_global_pp () const
  {
    return BPmax_global_pp;
  }

  int get_Jmin_global_pp () const
  {
    return Jmin_global_pp;
  }

  int get_Jmax_global_pp () const
  {
    return Jmax_global_pp;
  }
  
  int get_Jmin_global_pp_opp () const
  {
    return Jmin_global_pp_opp;
  }

  int get_Jmax_global_pp_opp () const
  {
    return Jmax_global_pp_opp;
  }

  unsigned int get_BPmin_global_nn () const
  {
    return BPmin_global_nn;
  }

  unsigned int get_BPmax_global_nn () const
  {
    return BPmax_global_nn;
  }

  int get_Jmin_global_nn () const
  {
    return Jmin_global_nn;
  }

  int get_Jmax_global_nn () const
  {
    return Jmax_global_nn;
  }
  
  int get_Jmin_global_nn_opp () const
  {
    return Jmin_global_nn_opp;
  }

  int get_Jmax_global_nn_opp () const
  {
    return Jmax_global_nn_opp;
  }

  unsigned int get_BPmin_global_pn () const
  {
    return BPmin_global_pn ;
  }

  unsigned int get_BPmax_global_pn () const
  {
    return BPmax_global_pn;
  }

  int get_Jmin_global_pn () const
  {
    return Jmin_global_pn;
  }

  int get_Jmax_global_pn () const
  {
    return Jmax_global_pn;
  }

  int get_Jmin_global_pn_opp () const
  {
    return Jmin_global_pn_opp;
  }

  int get_Jmax_global_pn_opp () const
  {
    return Jmax_global_pn_opp;
  }

  unsigned int get_BPmin_global_pp_basis () const
  {
    return BPmin_global_pp_basis;
  }

  unsigned int get_BPmax_global_pp_basis () const
  {
    return BPmax_global_pp_basis;
  }

  int get_Jmin_global_pp_basis () const
  {
    return Jmin_global_pp_basis;
  }

  int get_Jmax_global_pp_basis () const
  {
    return Jmax_global_pp_basis;
  }
  
  int get_Jmin_global_pp_opp_basis () const
  {
    return Jmin_global_pp_opp_basis;
  }

  int get_Jmax_global_pp_opp_basis () const
  {
    return Jmax_global_pp_opp_basis;
  }

  unsigned int get_BPmin_global_nn_basis () const
  {
    return BPmin_global_nn_basis;
  }

  unsigned int get_BPmax_global_nn_basis () const
  {
    return BPmax_global_nn_basis;
  }

  int get_Jmin_global_nn_basis () const
  {
    return Jmin_global_nn_basis;
  }

  int get_Jmax_global_nn_basis () const
  {
    return Jmax_global_nn_basis;
  }

  int get_Jmin_global_nn_opp_basis () const
  {
    return Jmin_global_nn_opp_basis;
  }

  int get_Jmax_global_nn_opp_basis () const
  {
    return Jmax_global_nn_opp_basis;
  }

  unsigned int get_BPmin_global_pn_basis () const
  {
    return BPmin_global_pn_basis;
  }

  unsigned int get_BPmax_global_pn_basis () const
  {
    return BPmax_global_pn_basis;
  }

  int get_Jmin_global_pn_basis () const
  {
    return Jmin_global_pn_basis;
  }

  int get_Jmax_global_pn_basis () const
  {
    return Jmax_global_pn_basis;
  }

  int get_Jmin_global_pn_opp_basis () const
  {
    return Jmin_global_pn_opp_basis;
  }

  int get_Jmax_global_pn_opp_basis () const
  {
    return Jmax_global_pn_opp_basis;
  }

  bool get_only_dimensions () const
  {
    return only_dimensions;
  }

  bool get_non_zero_NBMEs_proportion_only () const
  {
    return non_zero_NBMEs_proportion_only;
  }

  bool get_copy_J_OBMEs_TBMEs () const
  {
    return copy_J_OBMEs_TBMEs;
  }

  bool get_initial_pivot_from_file () const
  {
    return initial_pivot_from_file;
  }

  bool get_full_common_vectors_used_in_file () const
  {
    return full_common_vectors_used_in_file;
  }

  bool get_is_Coulomb_Hamiltonian_here () const
  {
    return is_Coulomb_Hamiltonian_here;
  }

  bool get_is_Coulomb_to_be_added () const
  {
    return is_Coulomb_to_be_added;
  }

  bool get_J_projected () const
  {
    return J_projected;
  }
  
  bool get_T2_CM_operators_calculated () const
  {
    return T2_CM_operators_calculated;
  }
  
  bool get_are_two_body_projectiles_stored_in_J_scheme () const
  {
    return are_two_body_projectiles_stored_in_J_scheme;
  }
  
  bool get_is_hole_double_counting_suppressed () const
  {
    return is_hole_double_counting_suppressed;
  }
  
  enum storage_type get_Hamiltonian_storage () const
  {
    return Hamiltonian_storage;
  }

  enum storage_type get_M_TBMEs_storage () const
  {
    return M_TBMEs_storage;
  }

  enum storage_type get_one_jumps_pn_storage () const
  {
    return one_jumps_pn_storage;
  }

  void set_truncation_hw (const bool truncation_hw_c)
  {
    truncation_hw = truncation_hw_c;
  }
  
  void set_truncation_ph (const bool truncation_ph_c)
  {
    truncation_ph = truncation_ph_c;
  }
  
  void set_n_scat_max_p (const int n_scat_max_p_c)
  {
    n_scat_max_p = n_scat_max_p_c;
  }
  
  void set_n_scat_max_n (const int n_scat_max_n_c)
  {
    n_scat_max_n = n_scat_max_n_c;
  }
  
  void set_n_scat_max (const int n_scat_max_c)
  {
    n_scat_max = n_scat_max_c;
  }
  
  void set_basis_space (const enum space_type basis_space_c)
  {
    basis_space = basis_space_c;
  }
  
  enum space_type get_basis_space () const
  {
    return basis_space;
  }

  enum space_type get_space () const
  {
    return space;
  }

  enum interaction_type get_inter () const
  {
    return inter;
  }

  enum potential_type get_basis_potential () const
  {
    return basis_potential;
  }

  enum particle_type get_relative_cluster () const
  {
    return relative_cluster;
  }
	  
  double get_R () const
  {
    return R;
  }

  double get_step_bef_R_uniform () const
  {
    return step_bef_R_uniform;
  }

  double get_R_real_max () const
  {
    return R_real_max;
  }

  double get_step_momentum_uniform () const
  {
    return step_momentum_uniform;
  }
  
  double get_kmax_momentum () const
  {
    return kmax_momentum;
  }
  
  double get_R_Fermi_momentum () const
  {
    return R_Fermi_momentum;
  }
  
  double get_R_cut_function () const
  {
    return R_cut_function;
  }

  double get_d_cut_function () const
  {
    return d_cut_function;
  }

  double get_Ueq_regularizor () const
  {
    return Ueq_regularizor;
  }

  double get_lambda_Hcm () const
  {
    return lambda_Hcm;
  }

  unsigned int get_N_bef_R_GL () const
  {
    return N_bef_R_GL;
  }

  unsigned int get_N_aft_R_GL () const
  {
    return N_aft_R_GL;
  }

  unsigned int get_N_bef_R_uniform () const
  {
    return N_bef_R_uniform;
  }

  unsigned int get_N_aft_R_uniform () const
  {
    return N_aft_R_uniform;
  }

  unsigned int get_Nk_momentum_uniform () const
  {
    return Nk_momentum_uniform;
  }

  unsigned int get_Nk_momentum_GL () const
  {
    return Nk_momentum_GL;
  }

  bool get_neutron_basis_potential () const
  {
    return neutron_basis_potential;
  }

  bool get_all_states_calculated () const
  {
    return all_states_calculated;
  }

  double get_R_charge () const
  {
    return R_charge;
  }

  enum potential_type get_H_potential () const
  {
    return H_potential;
  }

  int get_A_core () const
  {
    return A_core;
  }

  int get_Z_core () const
  {
    return Z_core;
  }

  int get_N_core () const
  {
    return N_core;
  }

  int get_prot_hole_states_number () const
  {
    return prot_hole_states_number;
  }

  int get_neut_hole_states_number () const
  {
    return neut_hole_states_number;
  }

  double get_frozen_core_mass () const
  {
    return frozen_core_mass;
  }

  double get_nucleus_mass () const
  {
    return nucleus_mass;
  }

  double get_nucleus_mass_basis () const
  {
    return nucleus_mass_basis;
  }

  bool get_truncation_hw () const
  {
    return truncation_hw;
  }

  bool get_truncation_ph () const
  {
    return truncation_ph;
  }
  
  int get_E_relative_max_hw_pole_approximation () const
  {
    return E_relative_max_hw_pole_approximation;
  }

  int get_E_relative_max_hw () const
  {
    return E_relative_max_hw;
  }

  int get_E_max_hw_pole_approximation () const
  {
    return E_max_hw_pole_approximation;
  }
  
  int get_E_max_hw () const
  {
    return E_max_hw;
  }

  int get_n_scat_max () const
  {
    return n_scat_max;
  }

  int get_n_scat_max_p () const
  {
    return n_scat_max_p;
  }

  int get_n_scat_max_n () const
  {
    return n_scat_max_n;
  }

  int get_n_holes_max_pole_approximation () const
  {
    return n_holes_max_pole_approximation;
  }

  int get_n_holes_max_p_pole_approximation () const
  {
    return n_holes_max_p_pole_approximation;
  }

  int get_n_holes_max_n_pole_approximation () const
  {
    return n_holes_max_n_pole_approximation;
  }
  
  int get_n_holes_max () const
  {
    return n_holes_max;
  }

  int get_n_holes_max_p () const
  {
    return n_holes_max_p;
  }

  int get_n_holes_max_n () const
  {
    return n_holes_max_n;
  }

  bool get_is_it_Lanczos () const
  {
    return is_it_Lanczos;
  }
  
  bool get_is_it_Lowdin () const
  {
    return is_it_Lowdin;
  }

  bool get_is_it_cluster_CM_HO_basis_calculation () const
  {
    return is_it_cluster_CM_HO_basis_calculation;
  }

  bool get_OBMEs_inter_read () const
  {
    return OBMEs_inter_read;
  }

  bool get_are_there_basis_prot_natural_orbitals () const
  {
    return are_there_basis_prot_natural_orbitals;
  }

  bool get_are_there_basis_neut_natural_orbitals () const
  {
    return are_there_basis_neut_natural_orbitals;
  }

  bool get_are_there_new_prot_natural_orbitals () const
  {
    return are_there_new_prot_natural_orbitals;
  }

  bool get_are_there_new_neut_natural_orbitals () const
  {
    return are_there_new_neut_natural_orbitals;
  }

  bool get_binding_energies_fitted () const
  {
    return binding_energies_fitted;
  }

  bool get_are_natural_orbitals_calculated_every_iteration () const
  {
    return are_natural_orbitals_calculated_every_iteration;
  }

  double get_configuration_precision () const
  {
    return configuration_precision;
  }

  unsigned int get_workspace_max_dimension () const
  {
    return workspace_max_dimension;
  }

  unsigned int get_N_restarts () const
  {
    return N_restarts;
  }

  double get_test_vector_solution () const
  {
    return test_vector_solution;
  }

  int get_A () const
  {
    return A;
  }

  int get_Z () const
  {
    return Z;
  }

  int get_N () const
  {
    return N;
  }

  int get_A_basis () const
  {
    return A_basis;
  }

  int get_Z_basis () const
  {
    return Z_basis;
  }

  int get_N_basis () const
  {
    return N_basis;
  }

  int get_Z_charge () const
  {
    return Z_charge;
  }

  int get_Z_charge_basis_potential () const
  {
    return Z_charge_basis_potential;
  }

  double get_prot_mass_for_calc () const
  {
    return prot_mass_for_calc;
  }

  double get_neut_mass_for_calc () const
  {
    return neut_mass_for_calc;
  }

  int get_Zval () const
  {
    return Zval;
  }

  int get_Nval () const
  {
    return Nval;
  }

  int get_Zval_basis () const
  {
    return Zval_basis;
  }

  int get_Nval_basis () const
  {
    return Nval_basis;
  }

  unsigned int get_N_nuclei_to_consider () const
  {
    return N_nuclei_to_consider;
  }

  double get_Newton_precision () const
  {
    return Newton_precision;
  }

  enum interaction_read_type get_inter_read () const
  {
    return inter_read;
  }

  double get_V0_KKNN (const unsigned int index) const
  {
    return V0_KKNN[index];
  }

  double get_rho_KKNN (const unsigned int index) const
  {
    return rho_KKNN[index];
  }

  double get_Vls_KKNN (const unsigned int index) const
  {
    return Vls_KKNN[index];
  }

  double get_rho_ls_KKNN (const unsigned int index) const
  {
    return rho_ls_KKNN[index];
  }

  bool get_same_dp_all_lj () const
  {
    return same_dp_all_lj;
  }

  bool get_same_R0_p_all_lj () const
  {
    return same_R0_p_all_lj;
  }

  bool get_same_Vo_p_all_lj () const
  {
    return same_Vo_p_all_lj;
  }

  bool get_same_Vso_p_all_lj () const
  {
    return same_Vso_p_all_lj;
  }

  bool get_same_dn_all_lj () const
  {
    return same_dn_all_lj;
  }

  bool get_same_R0_n_all_lj () const
  {
    return same_R0_n_all_lj;
  }

  bool get_same_Vo_n_all_lj () const
  {
    return same_Vo_n_all_lj;
  }

  bool get_same_Vso_n_all_lj () const
  {
    return same_Vso_n_all_lj;
  }

  bool get_is_dp_fitted () const
  {
    return is_dp_fitted;
  }

  bool get_is_R0_p_fitted () const
  {
    return is_R0_p_fitted;
  }

  bool get_is_Vo_p_fitted () const
  {
    return is_Vo_p_fitted;
  }

  bool get_is_Vso_p_fitted () const
  {
    return is_Vso_p_fitted;
  }

  bool get_is_R_charge_fitted () const
  {
    return is_R_charge_fitted;
  }

  bool get_is_dn_fitted () const
  {
    return is_dn_fitted;
  }

  bool get_is_R0_n_fitted () const
  {
    return is_R0_n_fitted;
  }

  bool get_is_Vo_n_fitted () const
  {
    return is_Vo_n_fitted;
  }

  bool get_is_Vso_n_fitted () const
  {
    return is_Vso_n_fitted;
  }

  bool get_is_V0_ctr_ot_S1_T1_fitted () const
  {
    return is_V0_ctr_ot_S1_T1_fitted;
  }

  bool get_is_V0_ctr_et_S1_T0_fitted () const
  {
    return is_V0_ctr_et_S1_T0_fitted;
  }

  bool get_is_V0_ctr_os_S0_T0_fitted () const
  {
    return is_V0_ctr_os_S0_T0_fitted;
  }

  bool get_is_V0_ctr_es_S0_T1_fitted () const
  {
    return is_V0_ctr_es_S0_T1_fitted;
  }

  bool get_is_V0_so_ot_S1_T1_fitted () const
  {
    return is_V0_so_ot_S1_T1_fitted;
  }

  bool get_is_V0_so_et_S1_T0_fitted () const
  {
    return is_V0_so_et_S1_T0_fitted;
  }

  bool get_is_V0_t_ot_S1_T1_fitted () const
  {
    return is_V0_t_ot_S1_T1_fitted;
  }

  bool get_is_V0_t_et_S1_T0_fitted () const
  {
    return is_V0_t_et_S1_T0_fitted;
  }

  bool get_is_VS_const_LO_T0_fitted () const
  {
    return is_VS_const_LO_T0_fitted;
  }

  bool get_is_VS_const_LO_T1_fitted () const
  {
    return is_VS_const_LO_T1_fitted;
  }

  bool get_is_VT_sigma_product_LO_T0_fitted () const
  {
    return is_VT_sigma_product_LO_T0_fitted;
  }

  bool get_is_VT_sigma_product_LO_T1_fitted () const
  {
    return is_VT_sigma_product_LO_T1_fitted;
  }

  bool get_is_V1_q2_NLO_fitted () const
  {
    return is_V1_q2_NLO_fitted;
  }

  bool get_is_V2_k2_NLO_fitted () const
  {
    return is_V2_k2_NLO_fitted;
  }

  bool get_is_V3_q2_sigma_product_NLO_fitted () const
  {
    return is_V3_q2_sigma_product_NLO_fitted;
  }

  bool get_is_V4_k2_sigma_product_NLO_fitted () const
  {
    return is_V4_k2_sigma_product_NLO_fitted;
  }

  bool get_is_V5_sigma_q_vector_k_NLO_fitted () const
  {
    return is_V5_sigma_q_vector_k_NLO_fitted;
  }

  bool get_is_V6_sigma_q_product_NLO_fitted () const
  {
    return is_V6_sigma_q_product_NLO_fitted;
  }
  
  bool get_is_V7_sigma_k_product_NLO_fitted () const
  {
    return is_V7_sigma_k_product_NLO_fitted;
  }
  
  bool get_is_it_fixed_relative_SVD_precision () const
  {
    return is_it_fixed_relative_SVD_precision;
  }
  
  double get_relative_SVD_precision () const
  {
    return relative_SVD_precision;
  }

  unsigned int get_rejected_singular_values_number () const
  {
    return rejected_singular_values_number;
  }

  int get_Jn_relative_max_basis () const
  {
    return Jn_relative_max_basis;
  }

  int get_Jc_relative_max_basis () const
  {
    return Jc_relative_max_basis;
  }

  int get_Jn_relative_max () const
  {
    return Jn_relative_max;
  }

  int get_Jc_relative_max () const
  {
    return Jc_relative_max;
  }

  double get_R0_inter_basis () const
  {
    return R0_inter_basis;
  }

  double get_mu_basis () const
  {
    return mu_basis;
  }

  double get_a_basis () const
  {
    return a_basis;
  }

  double get_b_basis () const
  {
    return b_basis;
  }

  double get_V_SDI_basis () const
  {
    return V_SDI_basis;
  }

  double get_b_lab_basis () const
  {
    return b_lab_basis;
  }

  double get_R0_inter () const
  {
    return R0_inter;
  }

  double get_mu () const
  {
    return mu;
  }

  double get_a () const
  {
    return a;
  }

  double get_b () const
  {
    return b;
  }

  double get_V_SDI () const
  {
    return V_SDI;
  }

  double get_b_lab () const
  {
    return b_lab;
  }

  double get_A_dependence_alpha_core_potential () const
  {
    return A_dependence_alpha_core_potential;
  }

  double get_A_dependence_exponent () const
  {
    return A_dependence_exponent;
  }

  double get_V0_Minnesota_basis (const unsigned int index) const
  {
    return V0_Minnesota_basis[index];
  }

  double get_rho_Minnesota_basis (const unsigned int index) const
  {
    return rho_Minnesota_basis[index];
  }

  double get_u_Minnesota_basis () const
  {
    return u_Minnesota_basis;
  }

  double get_nu_three_body_like_basis () const
  {
    return nu_three_body_like_basis;
  }

  double get_V_three_body_like_basis () const
  {
    return V_three_body_like_basis;
  }

  double get_V0_ctr_basis (const unsigned int index) const
  {
    return V0_ctr_basis[index];
  }

  double get_alpha_ctr_basis (const unsigned int index) const
  {
    return alpha_ctr_basis[index];
  }

  double get_W_ctr_basis (const unsigned int index) const
  {
    return W_ctr_basis[index];
  }

  double get_B_ctr_basis (const unsigned int index) const
  {
    return B_ctr_basis[index];
  }

  double get_H_ctr_basis (const unsigned int index) const
  {
    return H_ctr_basis[index];
  }

  double get_M_ctr_basis (const unsigned int index) const
  {
    return M_ctr_basis[index];
  }

  double get_V0_so_basis (const unsigned int index) const
  {
    return V0_so_basis[index];
  }

  double get_alpha_so_basis (const unsigned int index) const
  {
    return alpha_so_basis[index];
  }

  double get_W_so_basis (const unsigned int index) const
  {
    return W_so_basis[index];
  }

  double get_H_so_basis (const unsigned int index) const
  {
    return H_so_basis[index];
  }

  double get_V0_t_basis (const unsigned int index) const
  {
    return V0_t_basis[index];
  }

  double get_alpha_t_basis (const unsigned int index) const
  {
    return alpha_t_basis[index];
  }

  double get_W_t_basis (const unsigned int index) const
  {
    return W_t_basis[index];
  }

  double get_H_t_basis (const unsigned int index) const
  {
    return H_t_basis[index];
  }

  double get_V0_ctr_ot_basis () const
  {
    return V0_ctr_ot_basis;
  }

  double get_V0_ctr_et_basis () const
  {
    return V0_ctr_et_basis;
  }

  double get_V0_ctr_os_basis () const
  {
    return V0_ctr_os_basis;
  }

  double get_V0_ctr_es_basis () const
  {
    return V0_ctr_es_basis;
  }

  double get_V0_so_ot_basis () const
  {
    return V0_so_ot_basis;
  }

  double get_V0_so_et_basis () const
  {
    return V0_so_et_basis;
  }

  double get_V0_t_ot_basis () const
  {
    return V0_t_ot_basis;
  }

  double get_V0_t_et_basis () const
  {
    return V0_t_et_basis;
  }

  double get_VS_const_LO_T0_basis () const
  {
    return VS_const_LO_T0_basis;
  }

  double get_VS_const_LO_T1_basis () const
  {
    return VS_const_LO_T1_basis;
  }

  double get_VT_sigma_product_LO_T0_basis () const
  {
    return VT_sigma_product_LO_T0_basis;
  }
  
  double get_VT_sigma_product_LO_T1_basis () const
  {
    return VT_sigma_product_LO_T1_basis;
  }

  double get_V1_q2_NLO_basis () const
  {
    return V1_q2_NLO_basis;
  }

  double get_V2_k2_NLO_basis () const
  {
    return V2_k2_NLO_basis;
  }

  double get_V3_q2_sigma_product_NLO_basis () const
  {
    return V3_q2_sigma_product_NLO_basis;
  }

  double get_V4_k2_sigma_product_NLO_basis () const
  {
    return V4_k2_sigma_product_NLO_basis;
  }

  double get_V5_sigma_q_vector_k_NLO_basis () const
  {
    return V5_sigma_q_vector_k_NLO_basis;
  }

  double get_V6_sigma_q_product_NLO_basis () const
  {
    return V6_sigma_q_product_NLO_basis;
  }
  
  double get_V7_sigma_k_product_NLO_basis () const
  {
    return V7_sigma_k_product_NLO_basis;
  }
  
  double get_V0_Minnesota (const unsigned int index) const
  {
    return V0_Minnesota[index];
  }

  double get_rho_Minnesota (const unsigned int index) const
  {
    return rho_Minnesota[index];
  }

  double get_u_Minnesota () const
  {
    return u_Minnesota;
  }

  double get_nu_three_body_like () const
  {
    return nu_three_body_like;
  }

  double get_V_three_body_like () const
  {
    return V_three_body_like;
  }

  double get_V0_ctr (const unsigned int index) const
  {
    return V0_ctr[index];
  }

  double get_alpha_ctr (const unsigned int index) const
  {
    return alpha_ctr[index];
  }

  double get_W_ctr (const unsigned int index) const
  {
    return W_ctr[index];
  }

  double get_B_ctr (const unsigned int index) const
  {
    return B_ctr[index];
  }

  double get_H_ctr (const unsigned int index) const
  {
    return H_ctr[index];
  }

  double get_M_ctr (const unsigned int index) const
  {
    return M_ctr[index];
  }

  double get_V0_so (const unsigned int index) const
  {
    return V0_so[index];
  }

  double get_alpha_so (const unsigned int index) const
  {
    return alpha_so[index];
  }

  double get_W_so (const unsigned int index) const
  {
    return W_so[index];
  }

  double get_H_so (const unsigned int index) const
  {
    return H_so[index];
  }

  double get_V0_t (const unsigned int index) const
  {
    return V0_t[index];
  }

  double get_alpha_t (const unsigned int index) const
  {
    return alpha_t[index];
  }

  double get_W_t (const unsigned int index) const
  {
    return W_t[index];
  }

  double get_H_t (const unsigned int index) const
  {
    return H_t[index];
  }

  double get_V0_ctr_ot () const
  {
    return V0_ctr_ot;
  }

  double get_V0_ctr_et () const
  {
    return V0_ctr_et;
  }

  double get_V0_ctr_os () const
  {
    return V0_ctr_os;
  }

  double get_V0_ctr_es () const
  {
    return V0_ctr_es;
  }

  double get_V0_so_ot () const
  {
    return V0_so_ot;
  }

  double get_V0_so_et () const
  {
    return V0_so_et;
  }

  double get_V0_t_ot () const
  {
    return V0_t_ot;
  }

  double get_V0_t_et () const
  {
    return V0_t_et;
  }

  double get_VS_const_LO_T0 () const
  {
    return VS_const_LO_T0;
  }
  
  double get_VS_const_LO_T1 () const
  {
    return VS_const_LO_T1;
  }

  double get_VT_sigma_product_LO_T0 () const
  {
    return VT_sigma_product_LO_T0;
  }

  double get_VT_sigma_product_LO_T1 () const
  {
    return VT_sigma_product_LO_T1;
  }

  double get_V1_q2_NLO () const
  {
    return V1_q2_NLO;
  }

  double get_V2_k2_NLO () const
  {
    return V2_k2_NLO;
  }

  double get_V3_q2_sigma_product_NLO () const
  {
    return V3_q2_sigma_product_NLO;
  }

  double get_V4_k2_sigma_product_NLO () const
  {
    return V4_k2_sigma_product_NLO;
  }

  double get_V5_sigma_q_vector_k_NLO () const
  {
    return V5_sigma_q_vector_k_NLO;
  }

  double get_V6_sigma_q_product_NLO () const
  {
    return V6_sigma_q_product_NLO;
  }
  
  double get_V7_sigma_k_product_NLO () const
  {
    return V7_sigma_k_product_NLO;
  }
  
  unsigned int get_eigenset_vectors_number_max () const
  {
    return eigenset_vectors_number_max;
  }

  unsigned int get_Np_nlj () const
  {
    return Np_nlj;
  }

  unsigned int get_Np_nlj_res () const
  {
    return Np_nlj_res;
  }

  unsigned int get_Nn_nlj () const
  {
    return Nn_nlj;
  }

  unsigned int get_Nn_nlj_res () const
  {
    return Nn_nlj_res;
  }

  unsigned int get_N_nlj_relative () const
  {
    return N_nlj_relative;
  }

  unsigned int get_N_nlj_res_relative () const
  {
    return N_nlj_res_relative;
  }

  unsigned int get_Np_nljm () const
  {
    return Np_nljm;
  }

  unsigned int get_Np_nljm_res () const
  {
    return Np_nljm_res;
  }

  unsigned int get_Nn_nljm () const
  {
    return Nn_nljm;
  }

  unsigned int get_Nn_nljm_res () const
  {
    return Nn_nljm_res;
  }

  int get_nmax_p () const
  {
    return nmax_p;
  }

  int get_nmax_n () const
  {
    return nmax_n;
  }

  int get_nmax_relative () const
  {
    return nmax_relative;
  }

  int get_lmax_p () const
  {
    return lmax_p;
  }

  int get_lmax_n () const
  {
    return lmax_n;
  }

  int get_lmax_relative () const
  {
    return lmax_relative;
  }

  int get_lmax_for_basis_interaction () const
  {
    return lmax_for_basis_interaction;
  }

  int get_lmax_for_interaction () const
  {
    return lmax_for_interaction;
  }

  double get_jp_max () const
  {
    return jp_max;
  }

  double get_jn_max () const
  {
    return jn_max;
  }
  
  int get_jmax_relative () const
  {
    return jmax_relative;
  }

  double get_mp_max () const
  {
    return mp_max;
  }

  double get_mn_max () const
  {
    return mn_max;
  }

  double get_mp_min () const
  {
    return mp_min;
  }

  double get_mn_min () const
  {
    return mn_min;
  }

  int get_mp_max_minus_half () const
  {
    return mp_max_minus_half;
  }

  int get_mn_max_minus_half () const
  {
    return mn_max_minus_half;
  }

  int get_two_mp_max () const
  {
    return two_mp_max;
  }

  int get_two_mn_max () const
  {
    return two_mn_max;
  }

  int get_four_mp_max () const
  {
    return four_mp_max;
  }

  int get_four_mn_max () const
  {
    return four_mn_max;
  }

  double get_mp_max_minus_mp_min () const
  {
    return mp_max_minus_mp_min;
  }

  double get_mn_max_minus_mn_min () const
  {
    return mn_max_minus_mn_min;
  }

  unsigned int get_natural_orbitals_reference_states_number () const
  {
    return natural_orbitals_reference_states_number;
  }

  unsigned int get_HF_max_iterations_number () const
  {
    return HF_max_iterations_number;
  }

  double get_HF_precision () const
  {
    return HF_precision;
  }

  void set_prot_mass_for_calc (const double prot_mass_for_calc_c)
  {
    prot_mass_for_calc = prot_mass_for_calc_c;
  }
  
  void set_neut_mass_for_calc (const double neut_mass_for_calc_c)
  {
    neut_mass_for_calc = neut_mass_for_calc_c;
  }

  void set_files_number (const unsigned int files_number_c)
  {
    files_number = files_number_c;
  }

  unsigned int get_files_number () const
  {
    return files_number;
  }

  unsigned int get_prot_N_paths () const
  {
    return prot_N_paths;
  }

  unsigned int get_neut_N_paths () const
  {
    return neut_N_paths;
  }

  unsigned int get_eigensets_number () const
  {
    return eigensets_number;
  }

  bool get_are_there_EM_transitions () const
  {
    return are_there_EM_transitions;
  }
  
  bool get_are_there_GSM_multipoles () const
  {
    return are_there_GSM_multipoles;
  }

  double get_prot_effective_charge () const
  {
    return prot_effective_charge;
  }

  double get_neut_effective_charge () const
  {
    return neut_effective_charge;
  }

  unsigned int get_EM_transitions_number () const
  {
    return EM_transitions_number;
  }

  unsigned int get_GSM_multipoles_number () const
  {
    return GSM_multipoles_number;
  }

  bool get_are_there_EM_transitions_strength () const
  {
    return are_there_EM_transitions_strength;
  }

  unsigned int get_EM_transitions_strength_number () const
  {
    return EM_transitions_strength_number;
  }

  bool get_are_there_beta_transitions () const
  {
    return are_there_beta_transitions;
  }

  unsigned int get_beta_transitions_number () const
  {
    return beta_transitions_number;
  }

  bool get_are_there_beta_transitions_strength () const
  {
    return are_there_beta_transitions_strength;
  }

  unsigned int get_beta_transitions_strength_number () const
  {
    return beta_transitions_strength_number;
  }

  bool get_are_there_densities () const
  {
    return are_there_densities;
  }

  unsigned int get_density_number () const
  {
    return density_number;
  }

  bool get_are_there_correlation_densities () const
  {
    return are_there_correlation_densities;
  }

  unsigned int get_correlation_density_number () const
  {
    return correlation_density_number;
  }

  unsigned int get_correlation_density_theta_number () const
  {
    return correlation_density_theta_number;
  }

  bool get_are_there_spectroscopic_factors () const
  {
    return are_there_spectroscopic_factors;
  }

  unsigned int get_spectroscopic_factor_number () const
  {
    return spectroscopic_factor_number;
  }

  bool get_are_there_overlap_functions () const
  {
    return are_there_overlap_functions;
  }

  unsigned int get_overlap_function_number () const
  {
    return overlap_function_number;
  }

  bool get_are_there_rms_radii () const
  {
    return are_there_rms_radii;
  }

  unsigned int get_rms_radius_number () const
  {
    return rms_radius_number;
  }

  bool get_are_there_rms_radius_one_body_strengths () const
  {
    return are_there_rms_radius_one_body_strengths;
  }

  unsigned int get_rms_radius_one_body_strength_number () const
  {
    return rms_radius_one_body_strength_number;
  }

  bool get_are_there_Hamiltonian_parts () const
  {
    return are_there_Hamiltonian_parts;
  }

  unsigned int get_Hamiltonian_parts_eigenstates_number () const
  {
    return Hamiltonian_parts_eigenstates_number;
  }

  bool get_are_there_Coulomb_isospin_mixtures () const
  {
    return are_there_Coulomb_isospin_mixtures;
  }

  unsigned int get_Coulomb_isospin_mixture_number () const
  {
    return Coulomb_isospin_mixture_number;
  }

  bool get_are_there_dagger_tilde_operators () const
  {
    return are_there_dagger_tilde_operators;
  }

  unsigned int get_dagger_tilde_operators_number () const
  {
    return dagger_tilde_operators_number;
  }
  
  enum RDM_matrix_constraint_type get_RDM_matrix_constraint () const
  {
    return RDM_matrix_constraint;
  }

  bool get_RDM_is_it_BiCG () const
  {
    return RDM_is_it_BiCG;
  }

  bool get_RDM_are_there_J_constraints () const
  {
    return RDM_are_there_J_constraints;
  }

  bool get_RDM_is_there_CM_correction () const
  {
    return RDM_is_there_CM_correction;
  }
  
  bool get_RDM_is_there_isospin_constraint () const
  {
    return RDM_is_there_isospin_constraint;
  }
  
  bool get_RDM_Gamma_init_from_file () const
  {
    return RDM_Gamma_init_from_file;
  }

  bool get_RDM_is_there_E_reference () const
  {
    return RDM_is_there_E_reference;
  }
  
  double get_RDM_E_minimization_precision () const
  {
    return RDM_E_minimization_precision;
  }

  double get_RDM_sigma_init () const
  {
    return RDM_sigma_init;
  }
		   
  double get_RDM_multiplicative_sigma_step () const
  {
    return RDM_multiplicative_sigma_step;
  }
		 
  double get_RDM_smallness_factor () const
  {
    return RDM_smallness_factor;
  }
						 
  double get_RDM_BP () const
  {
    return RDM_BP;
  }

  double get_RDM_vector_index () const
  {
    return RDM_vector_index;
  }
  
  double get_RDM_J () const
  {
    return RDM_J;
  }

  double get_RDM_E_reference () const
  {
    return RDM_E_reference;
  }  

  double get_RDM_Hamiltonian_renormalization_factor () const
  {
    return RDM_Hamiltonian_renormalization_factor;
  }
  
  bool get_is_correlation_density_theta_value_imposed () const
  {
    return is_correlation_density_theta_value_imposed;
  }
  
  double get_correlation_density_imposed_theta_value () const
  {
    return correlation_density_imposed_theta_value;
  }

  enum CC_reaction_type get_CC_reaction () const
  {
    return CC_reaction;
  }
  
  enum CC_reaction_calculation_type get_CC_reaction_calculation () const
  {
    return CC_reaction_calculation;
  }

  bool get_CC_are_GSM_a_dagger_vectors_calculated () const
  {
    return CC_are_GSM_a_dagger_vectors_calculated;
  }

  double get_CC_E_total_CM_start () const
  {
    return CC_E_total_CM_start;
  }

  double get_CC_E_total_CM_end () const
  {
    return CC_E_total_CM_end;
  }

  double get_CC_average_n_scat_target_projectile_max () const
  {
    return CC_average_n_scat_target_projectile_max;
  }

  unsigned int get_CC_corrective_factors_composite_number () const
  {
    return CC_corrective_factors_composite_number;
  }

  unsigned int get_CC_N_target_projectile_states () const
  {
    return CC_N_target_projectile_states;
  }

  unsigned int get_CC_N_partial_waves_max () const
  {
    return CC_N_partial_waves_max;
  }

  unsigned int get_CC_Davidson_N_restarts () const
  {
    return CC_Davidson_N_restarts;
  }

  unsigned int get_CC_Davidson_max_dimension () const
  {
    return CC_Davidson_max_dimension;
  }

  double get_CC_Davidson_eigenvector_precision () const
  {
    return CC_Davidson_eigenvector_precision ;
  }

  double get_CC_relative_SVD_precision () const
  {
    return CC_relative_SVD_precision;
  }

  double get_CC_forbidden_channel_precision () const
  {
    return CC_forbidden_channel_precision;
  }

  unsigned int get_CC_N_energies () const
  {
    return CC_N_energies;
  }

  unsigned int get_CC_N_CM_angles  () const
  {
    return CC_N_CM_angles;
  }

  enum EM_type get_CC_EM_for_total_cross_section () const
  {
    return CC_EM_for_total_cross_section;
  }

  int get_CC_L_limit_for_differential_cross_section () const
  {
    return CC_L_limit_for_differential_cross_section;
  }

  int get_CC_L_for_total_cross_section () const
  {
    return CC_L_for_total_cross_section;
  }

  unsigned int get_CC_N_theta_gamma () const
  {
    return CC_N_theta_gamma;
  }

  unsigned int get_CC_N_phi_gamma () const
  {
    return CC_N_phi_gamma;
  }

  bool get_CC_is_it_longwavelength_approximation () const
  {
    return CC_is_it_longwavelength_approximation;
  }

  bool get_CC_is_it_HO_expansion () const
  {
    return CC_is_it_HO_expansion;
  }

  int get_E_CM_HO_max () const
  {
    return E_CM_HO_max;
  }

  unsigned int get_CC_N_JPi_A_composite () const
  {
    return CC_N_JPi_A_composite;
  }

  unsigned int get_CC_N_JPi_A_in_composite () const
  {
    return CC_N_JPi_A_in_composite;
  }

  unsigned int get_CC_N_JPi_A_out_composite () const
  {
    return CC_N_JPi_A_out_composite;
  }

  unsigned int get_CC_cluster_number () const
  {
    return CC_cluster_number;
  }

  int get_CC_Lmax_all () const
  {
    return CC_Lmax_all;
  }

  unsigned int get_CC_J_number_max_all () const
  {
    return CC_J_number_max_all;
  }

  bool get_are_GSM_vectors_stored_on_disk () const
  {
    return are_GSM_vectors_stored_on_disk;
  }

  bool get_are_configuration_probabilities_printed () const
  {
    return are_configuration_probabilities_printed;
  }

  bool get_are_scattering_configuration_probabilities_printed () const
  {
    return are_scattering_configuration_probabilities_printed;
  }
  
  bool get_is_there_effective_range_expansion () const
  {
    return is_there_effective_range_expansion;
  }
  
  bool get_M_equal_J_imposed_in_GSM_vectors () const
  {
    return M_equal_J_imposed_in_GSM_vectors;
  }
  
  bool get_is_there_disk_storage_eigenvectors_all_M () const
  {
    return is_there_disk_storage_eigenvectors_all_M;
  }

  const class array<double> & get_CC_CM_angles () const
  {
    return CC_CM_angles;
  }

  const class array<double> & get_prot_d_core_potential_tab () const
  {
    return prot_d_core_potential_tab;
  }

  const class array<double> & get_prot_R0_core_potential_tab () const
  {
    return prot_R0_core_potential_tab;
  }

  const class array<double> & get_prot_Vo_core_potential_tab () const
  {
    return prot_Vo_core_potential_tab;
  }

  const class array<double> & get_prot_Vso_core_potential_tab () const
  {
    return prot_Vso_core_potential_tab;
  }

  const class array<double> & get_neut_d_core_potential_tab () const
  {
    return neut_d_core_potential_tab;
  }

  const class array<double> & get_neut_R0_core_potential_tab () const
  {
    return neut_R0_core_potential_tab;
  }

  const class array<double> & get_neut_Vo_core_potential_tab () const
  {
    return neut_Vo_core_potential_tab;
  }

  const class array<double> & get_neut_Vso_core_potential_tab () const
  {
    return neut_Vso_core_potential_tab;
  }

  const class array<double> & get_prot_d_basis_core_potential_tab () const
  {
    return prot_d_basis_core_potential_tab;
  }

  const class array<double> & get_prot_R0_basis_core_potential_tab () const
  {
    return prot_R0_basis_core_potential_tab;
  }

  const class array<double> & get_prot_Vo_basis_core_potential_tab () const
  {
    return prot_Vo_basis_core_potential_tab;
  }

  const class array<double> & get_prot_Vso_basis_core_potential_tab () const
  {
    return prot_Vso_basis_core_potential_tab;
  }

  const class array<double> & get_neut_d_basis_core_potential_tab () const
  {
    return neut_d_basis_core_potential_tab;
  }

  const class array<double> & get_neut_R0_basis_core_potential_tab () const
  {
    return neut_R0_basis_core_potential_tab;
  }

  const class array<double> & get_neut_Vo_basis_core_potential_tab () const
  {
    return neut_Vo_basis_core_potential_tab;
  }

  const class array<double> & get_neut_Vso_basis_core_potential_tab () const
  {
    return neut_Vso_basis_core_potential_tab;
  }

  const class array<double> & get_prot_d_basis_tab () const
  {
    return prot_d_basis_tab;
  }

  const class array<double> & get_prot_R0_basis_tab () const
  {
    return prot_R0_basis_tab;
  }

  const class array<double> & get_prot_Vo_basis_tab () const
  {
    return prot_Vo_basis_tab;
  }

  const class array<double> & get_prot_Vso_basis_tab () const
  {
    return prot_Vso_basis_tab;
  }

  const class array<double> & get_neut_d_basis_tab () const
  {
    return neut_d_basis_tab;
  }

  const class array<double> & get_neut_R0_basis_tab () const
  {
    return neut_R0_basis_tab;
  }

  const class array<double> & get_neut_Vo_basis_tab () const
  {
    return neut_Vo_basis_tab;
  }

  const class array<double> & get_neut_Vso_basis_tab () const
  {
    return neut_Vso_basis_tab;
  }

  const class array<double> & get_d_basis_relative_tab () const
  {
    return d_basis_relative_tab;
  }

  const class array<double> & get_R0_basis_relative_tab () const
  {
    return R0_basis_relative_tab;
  }

  const class array<double> & get_Vo_basis_relative_tab () const
  {
    return Vo_basis_relative_tab;
  }

  const class array<double> & get_Vso_basis_relative_tab () const
  {
    return Vso_basis_relative_tab;
  }

  const class array<double> & get_V_Gaussian_consts_basis () const
  {
    return V_Gaussian_consts_basis;
  }

  const class array<double> & get_V_Gaussian_consts () const
  {
    return V_Gaussian_consts;
  }

  const class array<int> & get_nmax_HO_lab_tab () const
  {
    return nmax_HO_lab_tab;
  }

  const class array<int> & get_nmax_HO_relative_tab () const
  {
    return nmax_HO_relative_tab;
  }

  const class array<int> & get_nmax_GHF_lab_tab () const
  {
    return nmax_GHF_lab_tab;
  }
  
  const class lj_table<double> & get_prot_b_lab_partial_waves () const
  {
    return prot_b_lab_partial_waves;
  }

  const class lj_table<double> & get_neut_b_lab_partial_waves () const
  {
    return neut_b_lab_partial_waves;
  }

  const class lj_table<enum potential_type> & get_prot_basis_potential_partial_waves () const
  {
    return prot_basis_potential_partial_waves;
  }

  const class lj_table<enum potential_type> & get_neut_basis_potential_partial_waves () const
  {
    return neut_basis_potential_partial_waves;
  }

  const class array<unsigned int> & get_natural_orbitals_reference_states_BP_tab () const
  {
    return natural_orbitals_reference_states_BP_tab;
  }

  const class array<unsigned int> & get_natural_orbitals_reference_states_vector_index_tab () const
  {
    return natural_orbitals_reference_states_vector_index_tab;
  }

  const class array<double> & get_natural_orbitals_reference_states_J_tab () const
  {
    return natural_orbitals_reference_states_J_tab;
  }

  const class array<class nlj_struct> & get_prot_shells_quantum_numbers () const
  {
    return prot_shells_quantum_numbers;
  }

  const class array<class nlj_struct> & get_neut_shells_quantum_numbers () const
  {
    return neut_shells_quantum_numbers;
  }

  const class array<class nlj_struct> & get_shells_quantum_numbers_relative () const
  {
    return shells_quantum_numbers_relative;
  }

  const class lj_table<unsigned int> & get_prot_basis_BP_tab () const
  {
    return prot_basis_BP_tab;
  }

  const class lj_table<unsigned int> & get_neut_basis_BP_tab () const
  {
    return neut_basis_BP_tab;
  }

  const class lj_table<double> & get_prot_basis_J_tab () const
  {
    return prot_basis_J_tab;
  }

  const class lj_table<double> & get_neut_basis_J_tab () const
  {
    return neut_basis_J_tab;
  }

  const class array<unsigned int> & get_BP_eigenset_tab () const
  {
    return BP_eigenset_tab;
  }

  const class array<unsigned int> & get_eigenset_vectors_number_tab () const
  {
    return eigenset_vectors_number_tab;
  }

  const class array<double> & get_J_eigenset_tab () const
  {
    return J_eigenset_tab;
  }

  const class array<class correlated_state_str> & get_PSI_qn_from_file_tab () const
  {
    return PSI_qn_from_file_tab;
  }

  class array<class correlated_state_str> & get_PSI_qn_from_file_tab ()
  {
    return PSI_qn_from_file_tab;
  }

  const class array<enum EM_type> & get_EM_tab () const
  {
    return EM_tab;
  }

  const class array<int> & get_EM_L_tab () const
  {
    return EM_L_tab;
  }

  const class array<unsigned int> & get_EM_BP_IN_tab () const
  {
    return EM_BP_IN_tab;
  }

  const class array<unsigned int> & get_EM_BP_OUT_tab () const
  {
    return EM_BP_OUT_tab;
  }

  const class array<double> & get_EM_J_IN_tab () const
  {
    return EM_J_IN_tab;
  }

  const class array<double> & get_EM_J_OUT_tab () const
  {
    return EM_J_OUT_tab;
  }

  const class array<unsigned int> & get_EM_vector_index_IN_tab () const
  {
    return EM_vector_index_IN_tab;
  }

  const class array<unsigned int> & get_EM_vector_index_OUT_tab () const
  {
    return EM_vector_index_OUT_tab;
  }

  const class array<bool> & get_EM_is_it_longwavelength_approximation_tab () const
  {
    return EM_is_it_longwavelength_approximation_tab;
  }

  const class array<bool> & get_EM_is_it_HO_expansion_tab () const
  {
    return EM_is_it_HO_expansion_tab;
  }

  const class array<int> & get_GSM_multipoles_L_tab () const
  {
    return GSM_multipoles_L_tab;
  }

  const class array<unsigned int> & get_GSM_multipoles_BP_tab () const
  {
    return GSM_multipoles_BP_tab;
  }

  const class array<double> & get_GSM_multipoles_J_tab () const
  {
    return GSM_multipoles_J_tab;
  }

  const class array<unsigned int> & get_GSM_multipoles_vector_index_tab () const
  {
    return GSM_multipoles_vector_index_tab;
  }

  const class array<bool> & get_GSM_multipoles_is_it_HO_expansion_tab () const
  {
    return GSM_multipoles_is_it_HO_expansion_tab;
  }
  
  const class array<enum EM_type> & get_EM_strength_tab () const
  {
    return EM_strength_tab;
  }

  const class array<int> & get_EM_strength_L_tab () const
  {
    return EM_strength_L_tab;
  }

  const class array<unsigned int> & get_EM_strength_BP_IN_tab () const
  {
    return EM_strength_BP_IN_tab;
  }

  const class array<unsigned int> & get_EM_strength_BP_OUT_tab () const
  {
    return EM_strength_BP_OUT_tab;
  }

  const class array<double> & get_EM_strength_J_IN_tab () const
  {
    return EM_strength_J_IN_tab;
  }

  const class array<double> & get_EM_strength_J_OUT_tab () const
  {
    return EM_strength_J_OUT_tab;
  }

  const class array<unsigned int> & get_EM_strength_vector_index_IN_tab () const
  {
    return EM_strength_vector_index_IN_tab;
  }

  const class array<unsigned int> & get_EM_strength_vector_index_OUT_tab () const
  {
    return EM_strength_vector_index_OUT_tab;
  }

  const class array<bool> & get_EM_strength_is_it_longwavelength_approximation_tab () const
  {
    return EM_strength_is_it_longwavelength_approximation_tab;
  }

  const class array<bool> & get_EM_strength_is_it_Gauss_Legendre_tab () const
  {
    return EM_strength_is_it_Gauss_Legendre_tab;
  }

  const class array<enum beta_type> & get_beta_tab () const
  {
    return beta_tab;
  }

  const class array<enum beta_pm_type> & get_beta_pm_tab () const
  {
    return beta_pm_tab;
  }

  const class array<unsigned int> & get_beta_BP_IN_tab () const
  {
    return beta_BP_IN_tab;
  }

  const class array<unsigned int> & get_beta_BP_OUT_tab () const
  {
    return beta_BP_OUT_tab;
  }

  const class array<double> & get_beta_J_IN_tab () const
  {
    return beta_J_IN_tab;
  }

  const class array<double> & get_beta_J_OUT_tab () const
  {
    return beta_J_OUT_tab;
  }

  const class array<unsigned int> & get_beta_vector_index_IN_tab () const
  {
    return beta_vector_index_IN_tab;
  }

  const class array<unsigned int> & get_beta_vector_index_OUT_tab () const
  {
    return beta_vector_index_OUT_tab;
  }

  const class array<bool> & get_beta_is_it_HO_expansion_tab () const
  {
    return beta_is_it_HO_expansion_tab;
  }

  const class array<double> & get_beta_W0_tab () const
  {
    return beta_W0_tab;
  }

  const class array<enum beta_type> & get_beta_strength_tab () const
  {
    return beta_strength_tab;
  }

  const class array<enum beta_pm_type> & get_beta_strength_pm_tab () const
  {
    return beta_strength_pm_tab;
  }

  const class array<unsigned int> & get_beta_strength_BP_IN_tab () const
  {
    return beta_strength_BP_IN_tab;
  }

  const class array<unsigned int> & get_beta_strength_BP_OUT_tab () const
  {
    return beta_strength_BP_OUT_tab;
  }

  const class array<double> & get_beta_strength_J_IN_tab () const
  {
    return beta_strength_J_IN_tab;
  }

  const class array<double> & get_beta_strength_J_OUT_tab () const
  {
    return beta_strength_J_OUT_tab;
  }

  const class array<unsigned int> & get_beta_strength_vector_index_IN_tab () const
  {
    return beta_strength_vector_index_IN_tab;
  }

  const class array<unsigned int> & get_beta_strength_vector_index_OUT_tab () const
  {
    return beta_strength_vector_index_OUT_tab;
  }

  const class array<bool> & get_beta_strength_is_it_Gauss_Legendre_tab () const
  {
    return beta_strength_is_it_Gauss_Legendre_tab;
  }

  const class array<unsigned int> & get_density_BP_tab () const
  {
    return density_BP_tab;
  }

  const class array<double> & get_density_J_tab () const
  {
    return density_J_tab;
  }

  const class array<unsigned int> & get_density_vector_index_tab () const
  {
    return density_vector_index_tab;
  }

  const class array<bool> & get_density_is_it_Gauss_Legendre_tab () const
  {
    return density_is_it_Gauss_Legendre_tab;
  }

  const class array<bool> & get_density_is_it_radial_tab () const
  {
    return density_is_it_radial_tab;
  }

  const class array<unsigned int> & get_correlation_density_BP_tab () const
  {
    return correlation_density_BP_tab;
  }

  const class array<double> & get_correlation_density_J_tab () const
  {
    return correlation_density_J_tab;
  }

  const class array<double> & get_correlation_density_RKmax_tab () const
  {
    return correlation_density_RKmax_tab;
  }

  const class array<unsigned int> & get_correlation_density_vector_index_tab () const
  {
    return correlation_density_vector_index_tab;
  }

  const class array<bool> & get_correlation_density_is_it_Gauss_Legendre_tab () const
  {
    return correlation_density_is_it_Gauss_Legendre_tab;
  }
  
  const class array<bool> & get_correlation_density_is_it_radial_tab () const
  {
    return correlation_density_is_it_radial_tab;
  }
  
  const class array<bool> & get_correlation_density_is_it_HO_expansion_tab () const
  {
    return correlation_density_is_it_HO_expansion_tab;
  }

  const class array<enum spectroscopic_factor_type> & get_spectroscopic_factor_type_tab () const
  {
    return spectroscopic_factor_type_tab;
  }

  const class array<enum nucleus_type> & get_spectroscopic_factor_nucleus_tab () const
  {
    return spectroscopic_factor_nucleus_tab;
  }

  const class array<enum particle_type> & get_spectroscopic_factor_cluster_tab () const
  {
    return spectroscopic_factor_cluster_tab;
  }

  const class array<int> & get_spectroscopic_factor_Z_projectile_tab () const
  {
    return spectroscopic_factor_Z_projectile_tab;
  }

  const class array<int> & get_spectroscopic_factor_N_projectile_tab () const
  {
    return spectroscopic_factor_N_projectile_tab;
  }

  const class array<int> & get_spectroscopic_factor_LCM_projectile_tab () const
  {
    return spectroscopic_factor_LCM_projectile_tab;
  }

  const class array<int> & get_spectroscopic_factor_NCM_HO_max_projectile_tab () const
  {
    return spectroscopic_factor_NCM_HO_max_projectile_tab;
  }

  const class array<unsigned int> & get_spectroscopic_factor_BP_IN_tab () const
  {
    return spectroscopic_factor_BP_IN_tab;
  }

  const class array<unsigned int> & get_spectroscopic_factor_BP_OUT_tab () const
  {
    return spectroscopic_factor_BP_OUT_tab;
  }

  const class array<unsigned int> & get_spectroscopic_factor_BP_projectile_tab () const
  {
    return spectroscopic_factor_BP_projectile_tab;
  }

  const class array<double> & get_spectroscopic_factor_J_IN_tab () const
  {
    return spectroscopic_factor_J_IN_tab;
  }

  const class array<double> & get_spectroscopic_factor_J_OUT_tab () const
  {
    return spectroscopic_factor_J_OUT_tab;
  }

  const class array<double> & get_spectroscopic_factor_J_projectile_tab () const
  {
    return spectroscopic_factor_J_projectile_tab;
  }

  const class array<unsigned int> & get_spectroscopic_factor_vector_index_IN_tab () const
  {
    return spectroscopic_factor_vector_index_IN_tab;
  }

  const class array<unsigned int> & get_spectroscopic_factor_vector_index_OUT_tab () const
  {
    return spectroscopic_factor_vector_index_OUT_tab;
  }

  const class array<unsigned int> & get_spectroscopic_factor_vector_index_projectile_tab () const
  {
    return spectroscopic_factor_vector_index_projectile_tab;
  }

  const class array<enum spectroscopic_factor_type> & get_overlap_function_type_tab () const
  {
    return overlap_function_type_tab;
  }

  const class array<enum nucleus_type> & get_overlap_function_nucleus_tab () const
  {
    return overlap_function_nucleus_tab;
  }

  const class array<enum particle_type> & get_overlap_function_cluster_tab () const
  {
    return overlap_function_cluster_tab;
  }

  const class array<int> & get_overlap_function_Z_projectile_tab () const
  {
    return overlap_function_Z_projectile_tab;
  }

  const class array<int> & get_overlap_function_N_projectile_tab () const
  {
    return overlap_function_N_projectile_tab;
  }

  const class array<int> & get_overlap_function_LCM_projectile_tab () const
  {
    return overlap_function_LCM_projectile_tab;
  }

  const class array<int> & get_overlap_function_NCM_HO_max_projectile_tab () const
  {
    return overlap_function_NCM_HO_max_projectile_tab;
  }

  const class array<unsigned int> & get_overlap_function_BP_IN_tab () const
  {
    return overlap_function_BP_IN_tab;
  }

  const class array<unsigned int> & get_overlap_function_BP_OUT_tab () const
  {
    return overlap_function_BP_OUT_tab;
  }

  const class array<unsigned int> & get_overlap_function_BP_projectile_tab () const
  {
    return overlap_function_BP_projectile_tab;
  }

  const class array<double> & get_overlap_function_J_IN_tab () const
  {
    return overlap_function_J_IN_tab;
  }

  const class array<double> & get_overlap_function_J_OUT_tab () const
  {
    return overlap_function_J_OUT_tab;
  }

  const class array<double> & get_overlap_function_J_projectile_tab () const
  {
    return overlap_function_J_projectile_tab;
  }

  const class array<unsigned int> & get_overlap_function_vector_index_IN_tab () const
  {
    return overlap_function_vector_index_IN_tab;
  }

  const class array<unsigned int> & get_overlap_function_vector_index_OUT_tab () const
  {
    return overlap_function_vector_index_OUT_tab;
  }

  const class array<unsigned int> & get_overlap_function_vector_index_projectile_tab () const
  {
    return overlap_function_vector_index_projectile_tab;
  }

  const class array<bool> & get_overlap_function_is_it_Gauss_Legendre_tab () const
  {
    return overlap_function_is_it_Gauss_Legendre_tab;
  }

  const class array<bool> & get_rms_radius_is_it_HO_expansion_tab () const
  {
    return rms_radius_is_it_HO_expansion_tab;
  }

  const class array<unsigned int> & get_rms_radius_BP_tab () const
  {
    return rms_radius_BP_tab;
  }

  const class array<double> & get_rms_radius_J_tab () const
  {
    return rms_radius_J_tab;
  }

  const class array<unsigned int> & get_rms_radius_vector_index_tab () const
  {
    return rms_radius_vector_index_tab;
  }

  const class array<enum particle_type> & get_rms_radius_particle_tab () const
  {
    return rms_radius_particle_tab;
  }

  const class array<double> & get_rms_radius_frozen_core_tab () const
  {
    return rms_radius_frozen_core_tab;
  }

  const class array<unsigned int> & get_rms_radius_one_body_strength_BP_tab () const
  {
    return rms_radius_one_body_strength_BP_tab;
  }

  const class array<double> & get_rms_radius_one_body_strength_J_tab () const
  {
    return rms_radius_one_body_strength_J_tab;
  }

  const class array<unsigned int> & get_rms_radius_one_body_strength_vector_index_tab () const
  {
    return rms_radius_one_body_strength_vector_index_tab;
  }

  const class array<enum particle_type> & get_rms_radius_one_body_strength_particle_tab () const
  {
    return rms_radius_one_body_strength_particle_tab;
  }

  const class array<bool> & get_rms_radius_one_body_strength_is_it_Gauss_Legendre_tab () const
  {
    return rms_radius_one_body_strength_is_it_Gauss_Legendre_tab;
  }

  const class array<unsigned int> & get_Hamiltonian_parts_BP_tab () const
  {
    return Hamiltonian_parts_BP_tab;
  }

  const class array<double> & get_Hamiltonian_parts_J_tab () const
  {
    return Hamiltonian_parts_J_tab;
  }

  const class array<unsigned int> & get_Hamiltonian_parts_vector_index_tab () const
  {
    return Hamiltonian_parts_vector_index_tab;
  }

  const class array<unsigned int> & get_Coulomb_isospin_mixture_BP_tab () const
  {
    return Coulomb_isospin_mixture_BP_tab;
  }

  const class array<double> & get_Coulomb_isospin_mixture_J_tab () const
  {
    return Coulomb_isospin_mixture_J_tab;
  }

  const class array<unsigned int> & get_Coulomb_isospin_mixture_vector_index_tab () const
  {
    return Coulomb_isospin_mixture_vector_index_tab;
  }
  
  const class array<enum dagger_tilde_operator_type> & get_dagger_tilde_operators_tab () const
  {
    return dagger_tilde_operators_tab;
  }

  const class array<unsigned int> & get_dagger_tilde_operators_BP_IN_tab () const
  {
    return dagger_tilde_operators_BP_IN_tab;
  }

  const class array<unsigned int> & get_dagger_tilde_operators_BP_OUT_tab () const
  {
    return dagger_tilde_operators_BP_OUT_tab;
  }

  const class array<double> & get_dagger_tilde_operators_J_IN_tab () const
  {
    return dagger_tilde_operators_J_IN_tab;
  }

  const class array<double> & get_dagger_tilde_operators_J_OUT_tab () const
  {
    return dagger_tilde_operators_J_OUT_tab;
  }

  const class array<unsigned int> & get_dagger_tilde_operators_vector_index_IN_tab () const
  {
    return dagger_tilde_operators_vector_index_IN_tab;
  }

  const class array<unsigned int> & get_dagger_tilde_operators_vector_index_OUT_tab () const
  {
    return dagger_tilde_operators_vector_index_OUT_tab;
  }

  const class array<unsigned int> & get_CC_corrective_factors_BP_A_composite_tab () const
  {
    return CC_corrective_factors_BP_A_composite_tab;
  }

  const class array<double> & get_CC_corrective_factors_J_A_composite_tab () const
  {
    return CC_corrective_factors_J_A_composite_tab;
  }

  const class array<double> & get_CC_corrective_factors_composite_tab () const
  {
    return CC_corrective_factors_composite_tab;
  }

  const class array<unsigned int> & get_CC_BP_target_tab () const
  {
    return CC_BP_target_tab;
  }

  const class array<double> & get_CC_J_target_tab () const
  {
    return CC_J_target_tab;
  }

  const class array<bool> & get_CC_is_it_pole_target_tab () const
  {
    return CC_is_it_pole_target_tab;
  }

  const class array<unsigned int> & get_CC_vector_index_target_tab () const
  {
    return CC_vector_index_target_tab;
  }

  const class array<enum particle_type> & get_CC_projectile_tab () const
  {
    return CC_projectile_tab;
  }

  const class array<unsigned int> & get_CC_N_partial_waves_tab () const
  {
    return CC_N_partial_waves_tab;
  }

  const class array<double> & get_CC_real_E_intrinsic_projectile_tab () const
  {
    return CC_real_E_intrinsic_projectile_tab;
  }

  const class array<double> & get_CC_Gamma_intrinsic_projectile_tab () const
  {
    return CC_Gamma_intrinsic_projectile_tab;
  }

  const class array<double> & get_CC_real_E_target_tab () const
  {
    return CC_real_E_target_tab;
  }

  const class array<double> & get_CC_Gamma_target_tab () const
  {
    return CC_Gamma_target_tab;
  }

  const class array<complex<double> > & get_CC_average_n_scat_target_tab () const
  {
    return CC_average_n_scat_target_tab;
  }

  const class array<bool> & get_CC_is_it_entrance_tab () const
  {
    return CC_is_it_entrance_tab;
  }

  const class array<int> & get_CC_partial_wave_L_cluster_tab () const
  {
    return CC_partial_wave_L_cluster_tab;
  }

  const class array<double> & get_CC_partial_wave_J_cluster_tab () const
  {
    return CC_partial_wave_J_cluster_tab;
  }

  const class array<unsigned int> & get_CC_BP_A_composite_tab () const
  {
    return CC_BP_A_composite_tab;
  }

  const class array<unsigned int> & get_CC_vector_index_A_composite_tab () const
  {
    return CC_vector_index_A_composite_tab;
  }

  const class array<double> & get_CC_J_A_composite_tab () const
  {
    return CC_J_A_composite_tab;
  }

  const class array<double> & get_CC_J_A_in_composite_tab () const
  {
    return CC_J_A_in_composite_tab;
  }

  const class array<unsigned int> & get_CC_BP_A_in_composite_tab () const
  {
    return CC_BP_A_in_composite_tab;
  }

  const class array<double> & get_CC_J_A_out_composite_tab () const
  {
    return CC_J_A_out_composite_tab;
  }

  const class array<unsigned int> & get_CC_BP_A_out_composite_tab () const
  {
    return CC_BP_A_out_composite_tab;
  }

  const class array<unsigned int> & get_CC_vector_index_A_out_composite_tab () const
  {
    return CC_vector_index_A_out_composite_tab;
  }

  const class array<enum particle_type> & get_CC_cluster_tab () const
  {
    return CC_cluster_tab;
  }

  const class array<int> & get_CC_Lmax_cluster_CM_tab () const
  {
    return CC_Lmax_cluster_CM_tab;
  }

  const class array<int> & get_CC_Nmin_PCM_cluster_tab () const
  {
    return CC_Nmin_PCM_cluster_tab;
  }

  const class array<unsigned int> & get_CC_N_poles_cluster_CM_tab () const
  {
    return CC_N_poles_cluster_CM_tab;
  }

  const class array<complex<double> > & get_CC_K_peak_cluster_CM_tab () const
  {
    return CC_K_peak_cluster_CM_tab;
  }

  const class array<complex<double> > & get_CC_K_middle_cluster_CM_tab () const
  {
    return CC_K_middle_cluster_CM_tab;
  }

  const class array<complex<double> > & get_CC_K_max_cluster_CM_tab () const
  {
    return CC_K_max_cluster_CM_tab;
  }

  const class array<unsigned int> & get_CC_N_K_peak_cluster_CM_tab () const
  {
    return CC_N_K_peak_cluster_CM_tab;
  }

  const class array<unsigned int> & get_CC_N_K_middle_cluster_CM_tab () const
  {
    return CC_N_K_middle_cluster_CM_tab;
  }

  const class array<unsigned int> & get_CC_N_K_max_cluster_CM_tab () const
  {
    return CC_N_K_max_cluster_CM_tab;
  }

  // Simple routines putting all data of same type in an array, whose dimension is in ...dimension.. routines, for MPI distribution afterwards
  // -----------------------------------------------------------------------------------------------------------------------------------------
  // The master process reads the input file first, and distributed everything to other nodes when input read is finished.

  unsigned int get_dimension_unsigned_int_constants () const;
  void get_unsigned_int_constants (class array<unsigned int> &T_unsigned_int) const;
  void put_unsigned_int_constants (class array<unsigned int> &T_unsigned_int);

  unsigned int get_dimension_int_constants () const;
  void get_int_constants (class array<int> &T_int) const;
  void put_int_constants (class array<int> &T_int);

  unsigned int get_dimension_bool_constants () const;
  void get_bool_constants (class array<bool> &T_bool) const;
  void put_bool_constants (class array<bool> &T_bool);

  unsigned int get_dimension_double_constants () const;
  void get_double_constants (class array<double> &T_double) const;
  void put_double_constants (class array<double> &T_double);

  unsigned int dimension_unsigned_int_tables_calc () const;
  void get_unsigned_int_tables (class array<unsigned int> &T_unsigned_int) const;
  void alloc_unsigned_int_tables ();
  void put_unsigned_int_tables (class array<unsigned int> &T_unsigned_int);

  unsigned int dimension_int_tables_calc () const;
  void get_int_tables (class array<int> &T_int) const;
  void alloc_int_tables ();
  void put_int_tables (class array<int> &T_int);

  unsigned int dimension_bool_tables_calc () const;
  void get_bool_tables (class array<bool> &T_bool) const;
  void alloc_bool_tables ();
  void put_bool_tables (class array<bool> &T_bool);

  unsigned int dimension_double_tables_calc () const;
  void get_double_tables (class array<double> &T_double) const;
  void alloc_double_tables ();
  void put_double_tables (class array<double> &T_double);

  unsigned int dimension_complex_tables_calc () const;
  void get_complex_tables (class array<complex<double> > &T_complex) const;
  void alloc_complex_tables ();
  void put_complex_tables (class array<complex<double> > &T_complex);

  void copy_unsigned_int_constants (const class input_data_str &X);
  void copy_int_constants (const class input_data_str &X);
  void copy_bool_constants (const class input_data_str &X);
  void copy_double_constants (const class input_data_str &X);

  void copy_alloc_unsigned_int_tables (const class input_data_str &X);
  void copy_alloc_int_tables (const class input_data_str &X);
  void copy_alloc_bool_tables (const class input_data_str &X);
  void copy_alloc_double_tables (const class input_data_str &X);
  void copy_alloc_complex_tables (const class input_data_str &X);

  void optimization_common_data_alloc_copy (const class input_data_str &input_data_common);

#ifdef UseMPI
  void MPI_Bcast_constants_alloc_tables ();
#endif



  // See input_data_str_constants_management.cpp for general comments about these routines
  // -------------------------------------------------------------------------------------

  bool are_R0_values_consistent (const bool is_it_only_basis) const;

  unsigned int BPmin_global_determine (const bool is_it_only_basis) const;
  unsigned int BPmax_global_determine (const bool is_it_only_basis) const;

  int Jmin_global_determine (const bool is_it_only_basis) const;
  int Jmax_global_determine (const bool is_it_only_basis) const;
  
  int Jmin_global_opp_determine (const bool is_it_only_basis) const;
  int Jmax_global_opp_determine (const bool is_it_only_basis) const;

  void min_max_one_body_quantum_numbers_N_nlj_nljm_res_update (
							       const enum particle_type particle ,
							       const class nlj_struct &shell_qn);

  void max_angular_momentum_projection_data_determine (const enum particle_type particle);

  unsigned int N_nlj_discrete_calc (
				    const unsigned N_nlj_pole ,
				    const class array<class array<class nlj_struct> > &shells_quantum_numbers_scattering_like_tab) const;

  bool are_there_OCM_valence_states_to_integrate_determine (const class array<class nlj_struct> &shells_quantum_numbers) const;

  void CC_partial_wave_presence_check (
				       const enum particle_type particle ,
				       const class array<class nlj_struct> &shells_quantum_numbers ,
				       const class array<class nlj_struct> &shells_quantum_numbers_CC_Berggren) const;
  
  bool is_it_one_nucleon_case_CC_determine () const;
  
  void basis_interaction_parameters_alloc_copy_from_Hamiltonian ();
  void core_potential_data_default_alloc_fill ();
  void basis_core_potential_data_default_alloc_fill ();
  void basis_potential_data_default_alloc_fill ();
  void b_lab_partial_waves_default_alloc_fill ();
  void b_lab_fill_optimization_code (const class input_data_str &input_data_common);
  void nmax_HO_lab_relative_GHF_tabs_potentials_default_alloc_fill ();
  void optimized_partial_waves_basis_potential_partial_waves_default_alloc_fill ();

  void BP_J_min_max_global_from_partial_waves ();

  void CC_remaining_scattering_target_projectile_data_fill (
							    const unsigned int vector_index_min ,
							    const unsigned int vector_index_max ,
							    class array<class array<int> > &CC_partial_wave_L_cluster_tab_local ,
							    class array<class array<double> > &CC_partial_wave_J_cluster_tab_local ,
							    unsigned int &iT);

  void contour_data_fill (
			  const enum particle_type particle , 
			  const bool OCM_valence_state , 
			  const int l , 
			  const double j , 
			  const complex<double> &k_peak , 
			  const unsigned int N_k_peak , 
			  const complex<double> &k_middle , 
			  const unsigned int N_k_middle , 
			  const complex<double> &k_max , 
			  const unsigned int N_k_max , 
			  const int scat_e_trunc , 
			  const class array<class nlj_struct> &shells_quantum_numbers_poles , 
			  class array<class nlj_struct> &shells_quantum_numbers_contour);

  class array<class nlj_struct> & shells_quantum_numbers_determine (const enum particle_type particle);
  
  const class array<class nlj_struct> & shells_quantum_numbers_determine (const enum particle_type particle) const;

  void shells_quantum_numbers_contours_data_fill (
						  const enum particle_type particle , 
						  const unsigned int first_index ,
						  const class array<class nlj_struct> &shells_quantum_numbers_discrete , 
						  const class array<int> &l_array , 
						  const class array<double> &j_array , 
						  const class array<complex<double> > &k_peak_tab , 
						  const class array<complex<double> > &k_middle_tab , 
						  const class array<complex<double> > &k_max_tab , 
						  const class array<unsigned int> &N_k_peak_tab , 
						  const class array<unsigned int> &N_k_middle_tab , 
						  const class array<unsigned int> &N_k_max_tab , 
						  const class array<int> &scat_e_trunc_tab); 

  void lmax_BP_J_min_max_global_from_input_data_tab (const class array<class input_data_str> &input_data_tab_for_optimization);

  void Zval_Nval_BP_J_min_max_basis_calc_from_input_data_tab (const class array<class input_data_str> &input_data_tab_for_optimization);

  bool is_it_one_nucleon_case_determine () const;

  enum particle_type entrance_projectile_determine () const;

  bool is_there_cluster_partial_wave_determine (
						const enum particle_type cluster , 
						const int L ,
						const double J) const;

  int Nmax_cluster_determine (const unsigned int ic) const;

  int Nmax_LJ_cluster_determine (const unsigned int ic , const int L , const double J) const;

  bool are_cluster_CM_bases_identical (const unsigned int ic , const unsigned int icp) const;

  complex<double> E_intrinsic_cluster_determine (const unsigned int ic) const;

  void PSI_quantum_numbers_tab_partial_fill (
					     const class array<unsigned long int> &dimensions_good_J , 
					     class array<class correlated_state_str> &PSI_quantum_numbers_tab) const;

  unsigned int N_channels_calc (
				const class array<unsigned int> &BP_A_tab , 
				const class array<double> &J_A_tab) const;

  unsigned int N_channels_max_calc () const;

  void all_n_scat_max_modification (
				    const enum space_type space , 
				    const bool truncation_ph , 
				    const class nucleons_data &prot_data , 
				    const class nucleons_data &neut_data);
  void all_E_max_hw_calc ();

  void set_FHT_EFT_interaction_parameters (const class vector_class<double> &FHT_parameters);
  
  void set_FHT_EFT_WS_parameters (
				  const bool is_it_only_basis ,
				  const class array<class input_data_str> &input_data_tab , 
				  const class vector_class<double> &FHT_parameters);

  void add_N_channels_max_to_nmax (const int N_channels_max);

  void set_all_n_holes_max_n_scat_max_E_max (const class input_data_str &input_data);

  void nmax_HO_relative_tab_alloc_calc ();

  void holes_consistency_tests () const;
  
  void shells_consistency_tests (
				 const enum particle_type particle , 
				 const int available_pole_states ,
				 const class array<class nlj_struct> &shells_quantum_numbers) const;
 
  void natural_orbitals_consistency_tests (const enum particle_type particle) const;
  
  void shells_consistency_tests_optimization_code () const;
  
  void GSM_optimization_are_natural_orbitals_calculated_every_iteration_determine (const class array<class input_data_str> &input_data_tab_for_optimization);

  void GSM_optimization_reference_state_check (const class array<class input_data_str> &input_data_tab_for_optimization) const;

  void GSM_optimization_largest_space_check (const bool is_it_basis , const class array<class input_data_str> &input_data_tab_for_optimization) const;
  
  // The data of the input file are read in these routines. As they are associated with explaining strings in the input file, no comments are written (see GSM_input_data_str_read_input.cpp)
  // ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  void core_data_read_calc ();
  void particles_number_charges_masses_read_calc ();
  void basis_interaction_parameters_alloc_read ();
  void interaction_parameters_alloc_read ();
  void HO_GHF_expansion_parameters_alloc_read ();
  void core_potential_data_alloc_read ();
  void basis_core_potential_data_alloc_read ();
  void basis_potential_data_alloc_read ();
  void BP_J_min_max_global_two_particles_read ();
  void eigenvectors_data_alloc_read ();
  void CC_corrective_factors_alloc_composite_read ();
  void CC_scattering_composite_data_alloc_read ();
  void CC_radiative_capture_in_composite_data_alloc_read ();
  void CC_radiative_capture_out_composite_data_alloc_read ();
  void get_CC_CM_angles ();

  void CC_target_projectile_data_alloc_read (
					     class array<class array<int> > &CC_partial_wave_L_cluster_tab_local ,
					     class array<class array<double> > &CC_partial_wave_J_cluster_tab_local);

  void CC_target_projectile_data_alloc_read ();

  void MPI_processes_OpenMP_threads_workspace_name_read ();
  void use_options_interaction_read ();
  void space_particles_number_data_read ();
  void interaction_format_read ();
  void radial_data_read_calc ();
  void momentum_data_read_calc ();

  void pole_shells_to_consider (
				const enum particle_type particle , 
				const bool is_it_CC_Berggren , 
				class array<class nlj_struct> &shells_quantum_numbers_pole);

  void scattering_like_shells_to_consider (
					   const enum particle_type particle , 
					   const class array<class nlj_struct> &shells_quantum_numbers_pole ,
					   class array<class array<class nlj_struct> > &shells_quantum_numbers_scattering_like_tab);

  void contours_tables_fill (
			     const enum particle_type particle ,
			     const bool is_it_CC_Berggren ,  
			     unsigned int &N_nlj_paths , 
			     class array<int> &l_array , 
			     class array<double> &j_array , 
			     class array<complex<double> > &k_peak_tab , 
			     class array<complex<double> > &k_middle_tab , 
			     class array<complex<double> > &k_max_tab , 
			     class array<unsigned int> &N_k_peak_tab , 
			     class array<unsigned int> &N_k_middle_tab , 
			     class array<unsigned int> &N_k_max_tab , 
			     class array<int> &scat_e_trunc_tab) const;
  
  void contours_tables_Qbox_fill (
				  const enum particle_type particle , 
				  unsigned int &N_nlj_paths , 
				  class array<int> &l_array , 
				  class array<double> &j_array , 
				  class array<unsigned int> &N_k_peak_tab , 
				  class array<unsigned int> &N_k_middle_tab , 
				  class array<unsigned int> &N_k_max_tab , 
				  class array<int> &scat_e_trunc_tab) const;

  void shells_to_consider (
			   const enum particle_type particle ,
			   const bool is_it_CC_Berggren);

  void b_lab_partial_waves_alloc_read ();
  void one_body_relative_basis_core_potential_data_alloc_read ();
  void natural_orbitals_data_alloc_read ();
  void truncation_data_read ();
  void storage_diagonalization_RDM_linear_system_data_read ();
  void A_dependence_read_calc ();

  void core_parameters_fit_choice_data_read ();
  void interaction_parameters_fit_choice_data_read ();
  void optimization_misc_parameters_read ();

  void interactions_parameters_alloc_read ();

  void optimized_partial_waves_basis_potentials_data_alloc_read ();
  void same_proton_neutron_partial_waves_check () const;
  void observables_data_read ();

  void eigensets_data_alloc_read_for_relative_calculation ();
  void cluster_data_read_for_CC_calculation ();

  void cluster_data_read_for_cluster_CM_HO_calculation ();
  void optimization_fixed_nucleus_alloc_read (const class input_data_str &input_data_common);

  void CC_reaction_Davidson_cross_section_diagonalization_starting_points_data_read ();
  void CC_data_composite_states_read ();
  void CC_radiative_capture_data_read ();
  void CC_cross_section_E_total_CM_angles_values_read ();

  void effective_charges_read ();

  void copy_input_data_CC_Berggren_basis_alloc_read (const class input_data_str &input_data);

  void RDM_data_read ();



  // Routines here are for the GSM optimization code only. They are rather straightforward so that no details are provided, only general explanations (see GSM_input_data_optimization_handling.cpp).
  // ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  void set_FHT_EFT_parameters (
			       const bool is_it_only_basis , 
			       const class array<class input_data_str> &input_data_tab ,
			       const class vector_class<double> &FHT_EFT_parameters);

  unsigned int N_parameters_to_fit_calc () const;

  void fit_indices_tables_calc (
				class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
				class array<bool> &is_there_l_dependence_from_fit_index , 
				class array<int> &l_from_fit_index) const;

  void same_partial_wave_values_check () const;

  friend double used_memory_calc (const class input_data_str &T);
  
private:

  // The data of the input file are read in these routines. As they are associated with explaining strings in the input file, no comments are written (see GSM_input_data_str_read_input.cpp)
  // ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  void beta_transitions_data_read ();
  void beta_transitions_strength_data_read ();
  void correlation_density_data_read ();
  void density_data_read ();
  void GSM_multipoles_data_read ();
  void EM_transitions_data_read ();
  void EM_transitions_strength_data_read ();
  void Hamiltonian_parts_data_read ();
  void overlap_function_data_read ();
  void rms_radius_data_read ();
  void rms_radius_one_body_strength_data_read ();
  void dagger_tilde_operators_data_read ();
  void Coulomb_isospin_mixture_data_read ();
  void spectroscopic_factor_data_read ();


#ifdef UseMPI

  // Simple routines distributing all data of a certain type stored in an array with MPI
  // -----------------------------------------------------------------------------------
  // The master process reads the input file first, and distributes everything to other nodes when input read is finished.

  void MPI_Bcast_bool_constants ();
  void MPI_Bcast_unsigned_int_constants ();
  void MPI_Bcast_int_constants ();
  void MPI_Bcast_double_constants ();

  void MPI_Bcast_alloc_bool_tables ();
  void MPI_Bcast_alloc_unsigned_int_tables ();
  void MPI_Bcast_alloc_int_tables ();
  void MPI_Bcast_alloc_double_tables ();
  void MPI_Bcast_alloc_complex_tables ();
#endif

  bool print_detailed_information;                 // true if if one prints all information about the running calculation on screen, false if minimal information is printed.

  bool is_cost_function_Hessian_matrix_calculated; // true if the Hessian matrix of the cost function (chi^2) is calculated, false if not (GSM_optimization code only)

  unsigned int number_of_MPI_processes;            // Number of MPI nodes used when MPI parallelization is used. It is put to one otherwise.
  unsigned int number_of_OpenMP_threads;           // Number of OpenMP thread used when OpenMP parallelization is used. It is put to one otherwise.




  // Minimal and maximal binary parities (see observables_basic_functions.cpp for definition) and total angular momenta for all two-body states of the proton-proton, neutron-neutron and proton-neutron matrix elements
  // -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  // If "basis" is in the variable names, variables are used only to calculate the basis generating potentials, as in the HF/MSDHF methods.
  // If "opp" is in the name, it means that one considers two particles of oppposite parities. 

  unsigned int BPmin_global_pp , BPmax_global_pp;
  unsigned int BPmin_global_nn , BPmax_global_nn;
  unsigned int BPmin_global_pn , BPmax_global_pn;

  int Jmin_global_pp , Jmax_global_pp , Jmin_global_pp_opp , Jmax_global_pp_opp;
  int Jmin_global_nn , Jmax_global_nn , Jmin_global_nn_opp , Jmax_global_nn_opp;
  int Jmin_global_pn , Jmax_global_pn , Jmin_global_pn_opp , Jmax_global_pn_opp;

  unsigned int BPmin_global_pp_basis , BPmax_global_pp_basis;
  unsigned int BPmin_global_nn_basis , BPmax_global_nn_basis;
  unsigned int BPmin_global_pn_basis , BPmax_global_pn_basis;

  int Jmin_global_pp_basis , Jmax_global_pp_basis , Jmin_global_pp_opp_basis , Jmax_global_pp_opp_basis;
  int Jmin_global_nn_basis , Jmax_global_nn_basis , Jmin_global_nn_opp_basis , Jmax_global_nn_opp_basis;
  int Jmin_global_pn_basis , Jmax_global_pn_basis , Jmin_global_pn_opp_basis , Jmax_global_pn_opp_basis;



  bool only_dimensions;                             // true if calculates only shell model space dimensions, false if not
  bool non_zero_NBMEs_proportion_only;              // true if one calculates only the proportion of non-zero N-body matrix elements (NBMEs) of the Hamiltonian, false if not
  bool copy_J_OBMEs_TBMEs;                          // true if one uses the code only to calculate and copy one-body and two-body matrix elements in the Berggren basis to files, false if not
  bool initial_pivot_from_file;                     // true if one uses a starting point for the GSM eigenvector in the Lanczos or Davidson method (called a pivot) from a file, hence generated by a previous calculation, false if not
  bool full_common_vectors_used_in_file;            // true if GSM vectors are fully stored on one file, false if they are stored in parts in several sub-files in case (MPI only)
  bool is_Coulomb_Hamiltonian_here;                 // true if one includes the Coulomb part of the Hamiltonian, false if not
  bool is_Coulomb_to_be_added;                      // true if one includes if Coulomb TBMEs must be added to Hamiltonian TBMEs , false if the Coulomb interaction is already included in the nuclear TBMEs read from a file
  bool T2_CM_operators_calculated;                  // true if isospin T^2 and CM operators are calculated on the obtained GSM eigenvector, false if not
  bool J_projected;                                 // true if one projects pivot and Lanczos vectors on J, false if not (available only with the Lanczos method in structure calculations if one does not calculate all states).
                                                    // Indeed, J-projection becomes unstable when one has pole shells with large j.
                                                    // J is then obtained only through from diagonalization at convergence.
                                                    // Hence, to get a fixed eigenstate of J angular momentum, all low-lying states before must be calculated as well.
  bool are_two_body_projectiles_stored_in_J_scheme; // true if one has calculated and stored all diproton/dineutron/deuteron projectiles with the two-body relative code, hence in J-scheme, 
                                                    // false if they were calculated with GSM in a HO basis, hence in M-scheme (GSM-CC only)

  bool is_hole_double_counting_suppressed;          // true if one has active holes and the double counting potential is added to the Hamiltonian, false if not
                                                    // Additionally, if it is true, diagonal TBMEs in core holes are put to zero. Otherwise, the Hamiltonian is used as it is. 
  
  enum storage_type Hamiltonian_storage;            // FULL_STORAGE if Hamiltonian is fully stored , 
                                                    // PARTIAL_STORAGE if Hamiltonian TBMEs indices are stored, not TBMEs themselves (leads to a factor 2.5 in memory gain, but is slightly slower) 
                                                    // ON_THE_FLY for on the fly calculation with or without recalculation of uncoupled TBMEs from coupled TBMEs or and with or without storage of 1p-1h jumps occurring in the pn part of the Hamiltonian

  enum storage_type M_TBMEs_storage;                // Storage option of uncoupled TBMEs with partial storage or "on the fly" for Hamiltonian.
                                                    // FULL_STORAGE if all uncoupled TBMEs are stored. It is always the case with Hamiltonian partial storage.
                                                    // PARTIAL_STORAGE if only pp/pn or nn/pn uncoupled TBMEs are stored. They are indeed in small number compared to nn or pp TBMEs in very asymmetric spaces.
                                                    // ON_THE_FLY if all uncoupled TBMEs are recalculated when applying Hamiltonian.
  
  enum storage_type one_jumps_pn_storage;           // Storage option of the <outSDp | a+ a | inSDp> and <outSDn | a+ a | inSDn> matrix elements, i.e. the pn one jumps occurring in the pn part of the Hamiltonian with "on the fly" for pn Hamiltonian.
                                                    // FULL_STORAGE if all pn one jumps are stored. It is faster with Hamiltonian "on the fly" calculations, but is possible only if one does have not many valence shells. 
                                                    // PARTIAL_STORAGE if only proton or neutron jumps are stored. Neutron one jumps are indeed in small number compared to proton one jumps in neutron-rich nuclei (same with proton <-> neutron).
                                                    // ON_THE_FLY if all pn one jumps are recalculated when applying Hamiltonian.

  enum space_type basis_space , space;              // type of space used: protons only, neutrons only or protons-neutrons, for basis-generating HF/MSDHF potentials calculations (basis_space) or Hamiltonian diagonalization (space)

  enum interaction_type inter;                      // type of the interaction used (FHT, realistic, ...)

  enum potential_type basis_potential;              // basis_potential: potential used for basis generation (WS, HF, ...)

  enum particle_type relative_cluster;              // diproton, dineutron or deuteron cluster occurring in the two-body relative code
  
  double R;                                         // rotation point of complex scaling
  double step_bef_R_uniform;                        // radial step on the uniform grid on [0:R], with R the rotation point. The number of points on the uniform grid is typically 10 times that of Gauss-Legendre
  double R_real_max;                                // maximal radius considered on the real-axis. All HO states must be negligible therein.

  double step_momentum_uniform;                     // momentum step on the uniform grid on [0:kmax_momentum]. The number of points on the uniform grid is typically 10 times that of Gauss-Legendre
 
  double kmax_momentum;                             // maximal momentum for the calculation of densities and correlation densities in momentum space
  
  double R_Fermi_momentum;                          // Radius of the Fermi function applied to one-body basis states for the calculation of their approximate Fourier-Bessel transform. The diffuseness can be fixed at a large value.


  // Non-local potentials treated with equivalent potentials
  // -------------------------------------------------------
  // The non-local potential U(r,r') applied a wave function is written Ueq(r).u(r) + S(r), where Ueq(r) is the equivalent potential and S(r) the source.
  // Ueq(r) = [1 - F(r)] \int U(r,r') u(r') dr' / u(r) and S(r) = F(r) \int U(r,r') u(r') dr', 
  // with F(r) a regularizing factor preventing from Ueq(r) to diverge if u(r) = 0, which is numerically non-zero only close to the zeroes of u(r).
  // The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
  //                  Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
  //                  The ratio |u(r)|^2/|u'(r)|^2 prevents F(r) to be non zero when r -> +oo.
  //                  Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
  
  double R_cut_function;                                 // diffuseness of the Fermi cut function F(r) (see basic_maths.cpp) used in HF/MSDHF/OCM potentials for stability
  double d_cut_function;                                 // radius      of the Fermi cut function F(r) (see basic_maths.cpp) used in HF/MSDHF/OCM potentials for stability

  double Ueq_regularizor;                                // Regularization factor used in the equivalent HD/MSDHF/OCM potential (see above)

  double lambda_Hcm;                                     // constant of the Lawson method H_total = H + lambda_Hcm.Hcm if it is used, zero otherwise 

  unsigned int N_bef_R_GL;                               // number of Gauss-Legendre points on [0:R] (before R) (see spherical_state.cpp)
  unsigned int N_aft_R_GL;                               // number of Gauss-Legendre points on [R:R_real_max], [0:1/R^4] (after R) (see spherical_state.cpp)
  
  unsigned int N_bef_R_uniform;                          // number of points on the uniform grid  [0:R] (before R) (see spherical_state.cpp)
  unsigned int N_aft_R_uniform;                          // number of points on the uniform grids [R:R_real_max], [0:1/R^4] (after R) (see spherical_state.cpp)
  
  unsigned int Nk_momentum_GL;                           // number of Gauss-Legendre points on [0:kmax_momentum] for wave functions in momentum space
  unsigned int Nk_momentum_uniform;                      // number of points on the uniform grid [0:kmax_momentum] for wave functions in momentum space
  
  bool neutron_basis_potential;                          // true if one uses the neutron potential for both protons and neutons, false if not

  bool all_states_calculated;                            // true is one does a full diagonalization of the Hamiltonian with Lanczos, false if one calculates a few eigenvectors with Lanczos or Jacobi-Davidson (standard case)

  double R_charge;                                       // charge radius used in the Coulomb potential

  enum potential_type H_potential;                       // potential used in the Hamiltonian: it is the potential of the core, which can be typically WS or KKNN

  int A_core;                                            // number of nucleons of the core
  int Z_core;                                            // number of protons  of the core 
  int N_core;                                            // number of neutrons of the core 

  int prot_hole_states_number;                           // number of proton  active holes in the core 
  int neut_hole_states_number;                           // number of neutron active holes in the core 

  double frozen_core_mass;                               // mass of the frozen core used in COSM. Indeed, if one has holes, holes are considered as valence states within COSM

  double nucleus_mass;                                   // mass of the core nucleus if COSM is used, mass of the considered nucleus if not, used for Hamiltonian diagonalization
  double nucleus_mass_basis;                             // mass of the core nucleus if COSM is used, mass of the considered nucleus if not, used for the calculation of basis-generating potentials such as HF/MSDHF
  
  bool truncation_hw;                                    // true if one truncates in energy, given there in units of hbar omega (which can be used as arbitrary units as well), false if not
  bool truncation_ph;                                    // true if one truncates with respect to particle number in the continuum, false if not

  int E_relative_max_hw_pole_approximation;              // maximal truncation energy of configurations at pole approximation level with respect to the ground state configuration
  int E_relative_max_hw;                                 // maximal truncation energy of configurations at full space         level with respect to the ground state configuration

  int E_max_hw_pole_approximation;                       // maximal truncation energy of configurations at pole approximation level: it is E_relative_max_hw_pole_approximation + E_hw(ground state configuration)
  int E_max_hw;                                          // maximal truncation energy of configurations at full space         level: it is E_relative_max_hw                    + E_hw(ground state configuration)

  int n_scat_max;                                        // maximal number of nucleons in the continuum
  int n_scat_max_p;                                      // maximal number of protons  in the continuum
  int n_scat_max_n;                                      // maximal number of neutrons in the continuum
  
  int n_holes_max_pole_approximation;                     // maximal number of nucleon holes in core states at pole approximation level
  int n_holes_max_p_pole_approximation;                   // maximal number of proton  holes in core states at pole approximation level
  int n_holes_max_n_pole_approximation;                   // maximal number of neutron holes in core states at pole approximation level
  
  int n_holes_max;                                        // maximal number of nucleon holes in core states at full space level
  int n_holes_max_p;                                      // maximal number of proton  holes in core states at full space level
  int n_holes_max_n;                                      // maximal number of neutron holes in core states at full space level
    
  bool is_it_Lanczos;                                    // true if one uses the Lanczos method for Hamiltonian diagonalization, false if one uses the Jacobi-Davidson method
  
  bool is_it_Lowdin;                                     // true if one uses the Lowdin method for J-projection, false if one uses the Lanczos method for that matter (this is independent of Hamiltonian diagonalization). 

  bool OBMEs_inter_read;                                 // true if all OBMEs are read from an input file, false if not

  bool is_it_cluster_CM_HO_basis_calculation;            // true if one calculates CM states of the form |NCM-HO LCM intrinsic> states for GSM-CC, false if not. 
                                                         // One puts n_scat_max to zero if it is true, as, by convention, the nuclear interaction only acts on the pole space, 
                                                         // the rest of the space being there only to have a separation of CM and intrinsic parts of the many_body wave function

  bool are_there_basis_prot_natural_orbitals;            // true if one has proton  natural orbitals in the one-body basis, false if not
  bool are_there_basis_neut_natural_orbitals;            // true if one has neutron natural orbitals in the one-body basis, false if not

  bool are_there_new_prot_natural_orbitals;              // true if one calculates proton  natural orbitals for the one-body basis of a future calculation, false if not
  bool are_there_new_neut_natural_orbitals;              // true if one calculates neutron natural orbitals for the one-body basis of a future calculation, false if not

  bool binding_energies_fitted;                          // true if one fits binding energies in the optimization code, false if one fits separation energies
  
  bool are_natural_orbitals_calculated_every_iteration;  // true if one recalculates all natural orbitals during an iteration of the GSM optimization method, i.e. when one calculates all nuclear states for a new set of parameters

  double configuration_precision;                        // When one prints configuration probabilities on screen, it is the maximal value of infinite norm of configuration probability which one allows to print

  unsigned int workspace_max_dimension;                  // Maximal number of Lanzos or Jacobi-Davidson vectors used in Hamiltonian diagonalization

  unsigned int N_restarts;                               // Maximal number of restarts of Lanczos or Jacobi-Davidson method, i.e. with a new starting pivot vector. 
                                                         // One restarts if all Lanzos or Jacobi-Davidson vectors have been used without having convergence

  double test_vector_solution;                           // Value under which one considers that the Lanczos or Jacobi-Davidson method has converged
                                                         // It is the infinite norm of the component of the last calculated Lanczos or Jacobi-Davidson vector

  int A;                                                 // number of nucleons of the nucleus used for Hamiltonian diagonalization
  int Z;                                                 // number of protons  of the nucleus used for Hamiltonian diagonalization
  int N;                                                 // number of neutrons of the nucleus used for Hamiltonian diagonalization
  
  int A_basis;                                           // number of nucleons of the nucleus used for the calculation of basis-generating potentials such as HF/MSDHF
  int Z_basis;                                           // number of protons  of the nucleus used for the calculation of basis-generating potentials such as HF/MSDHF
  int N_basis;                                           // number of neutrons of the nucleus used for the calculation of basis-generating potentials such as HF/MSDHF

  int Z_charge;                                          // charge of the Coulomb potential of the Hamiltonian.                It is Z_core + Z_val       - 1 if Zval       >= 1 and Z_core otherwise
  int Z_charge_basis_potential;                          // charge of the Coulomb potential of the basis-generating potential. It is Z_core + Z_val_basis - 1 if Zval_basis >= 1 and Z_core otherwise

  double prot_mass_for_calc;                             // mass of the proton  used in the calculation of one-body wave functions. It does not have to be its physical mass.
  double neut_mass_for_calc;                             // mass of the neutron used in the calculation of one-body wave functions. It does not have to be its physical mass.

  int Zval;                                              // number of valence protons  of the nucleus used for Hamiltonian diagonalization
  int Nval;                                              // number of valence neutrons of the nucleus used for Hamiltonian diagonalization

  int Zval_basis;                                        // number of valence protons  of the nucleus used for the calculation of basis-generating potentials such as HF/MSDHF
  int Nval_basis;                                        // number of valence neutrons of the nucleus used for the calculation of basis-generating potentials such as HF/MSDHF

  unsigned int N_nuclei_to_consider;                     // number of nuclei whose energies are either calculated (weight is zero) or fitted (weight is not zero) in the GSM optimization code

  double Newton_precision;                               // precision of the Newton method used in the GSM optimization code to find optimal interaction parameters under which one considers that it has converged

  enum interaction_read_type inter_read;                 // true if one reads two-body matrix elements from a file, false if not

  double V0_KKNN[5];                                     // Central strength array of the set of KKNN parameters
  double rho_KKNN[5];                                    // rho_KKNN: Central length array of the set of KKNN parameters
  double Vls_KKNN[3];                                    // Spin-orbit strength array of the set of KKNN parameter
  double rho_ls_KKNN[3];                                 // Spin-orbit length array of the set of KKNN parameters




  // The following booleans are used in the GSM optimization code 
  // ------------------------------------------------------------
  // same..._all_lj: true if one uses the same diffuseness, radius, central or spin-orbit strengths for all partial waves, for protons (p) and neutrons (n), false if not
  // is...fitted: true if the considered interaction parameter is fitted, false if not.
  //              T0 and T1 are indicate isospin dependence for T=0 and T=1 parameters.
  //              It can be diffuseness, radius, central or spin-orbit strengths for core WS potentials, for protons (p) and neutrons (n), 
  //              or an interaction strength (V0) of central (ctr), spin-orbit (so), or tensor (t) type for FHT
  //              or an interaction strength (VS,VT,V1,V2,V3,V4,V5,V6,V7) of the EFT interaction, where one uses only contact terms.
  
  bool same_dp_all_lj , same_R0_p_all_lj , same_Vo_p_all_lj , same_Vso_p_all_lj;
  bool same_dn_all_lj , same_R0_n_all_lj , same_Vo_n_all_lj , same_Vso_n_all_lj;

  bool is_dp_fitted , is_R0_p_fitted , is_Vo_p_fitted , is_Vso_p_fitted , is_R_charge_fitted;
  bool is_dn_fitted , is_R0_n_fitted , is_Vo_n_fitted , is_Vso_n_fitted;

  bool is_V0_ctr_ot_S1_T1_fitted , is_V0_ctr_et_S1_T0_fitted;
  bool is_V0_ctr_os_S0_T0_fitted , is_V0_ctr_es_S0_T1_fitted;

  bool is_V0_so_ot_S1_T1_fitted  , is_V0_so_et_S1_T0_fitted;

  bool is_V0_t_ot_S1_T1_fitted   , is_V0_t_et_S1_T0_fitted;

  bool is_VS_const_LO_T0_fitted , is_VS_const_LO_T1_fitted;

  bool is_VT_sigma_product_LO_T0_fitted , is_VT_sigma_product_LO_T1_fitted;

  bool is_V1_q2_NLO_fitted , is_V2_k2_NLO_fitted;

  bool is_V3_q2_sigma_product_NLO_fitted , is_V4_k2_sigma_product_NLO_fitted;

  bool is_V5_sigma_q_vector_k_NLO_fitted;

  bool is_V6_sigma_q_product_NLO_fitted , is_V7_sigma_k_product_NLO_fitted;

  bool is_it_fixed_relative_SVD_precision;             // eigenvalues of the matrix of the linear system to solve in the Newton method in the GSM optimization code are ignored in the solution 
                                                       // if they are smaller in modulus than relative_SVD_precision (true) or if their index is smaller than a given number (false)
                                                       // when inverting the linear system with the Moore-Penrose pseudo-inverse
  
  double relative_SVD_precision;                       // eigenvalues of the matrix of the linear system to solve in the Newton method in the GSM optimization code are ignored in the solution 
                                                       // if they are smaller in modulus than relative_SVD_precision when inverting the linear system with the Moore-Penrose pseudo-inverse

  unsigned int rejected_singular_values_number;        // The eigenvalues of the matrix of the linear system to solve in the Newton method in the GSM optimization code are ignored in the solution 
                                                       // if their index is smaller than rejected_singular_values_number when inverting the linear system with the Moore-Penrose pseudo-inverse

  int Jn_relative_max_basis , Jc_relative_max_basis;   // maximal relative total angular momentum in the nuclear (n) or Coulomb (c) interaction TBMEs used for the calculation of basis-generating potentials such as HF/MSDHF
  int Jn_relative_max       , Jc_relative_max;         // maximal relative total angular momentum in the nuclear (n) or Coulomb (c) interaction TBMEs used for Hamiltonian diagonalization

  double R0_inter_basis;                               // radius of the SGI/MSGI/SDI interaction, used for the calculation of basis-generating potentials such as HF/MSDHF
  
  double mu_basis;                                     // range of the SGI/MSGI/SDI interaction, used for the calculation of basis-generating potentials such as HF/MSDHF
  
  double a_basis , b_basis , V_SDI_basis;              // parameters of the SDI interaction, equal to V_SDI.(a + b.Psigma).delta (r1 - r2).delta (r - R0), used for the calculation of basis-generating potentials such as HF/MSDHF

  double b_lab_basis;                                  // HO length used for the calculation of interaction TBMEs and one-body HO states (default value), used for the calculation of basis-generating potentials such as HF/MSDHF

  double R0_inter;                                     // radius of the SGI/MSGI/SDI interaction, used for Hamiltonian diagonalization

  double mu;                                           // range of the SGI/MSGI/SDI interaction, used for Hamiltonian diagonalization
  
  double a , b , V_SDI;                                // parameters of the SDI interaction, equal to V_SDI.(a + b.Psigma).delta (r1 - r2).delta (r - R0), used for Hamiltonian diagonalization

  double b_lab;                                        // HO length used for the calculation of interaction TBMEs and one-body HO states (default value), used for Hamiltonian diagonalization

  double A_dependence_alpha_core_potential;            // if one uses A-dependence on OBMEs, one multiplies all core WS central depths by 1 + A_dependence_alpha_core_potential.(N-Z)/A
  
  double A_dependence_exponent;                        // if one uses A-dependence on TBMEs, one multiplies all TBMEs by ((A(core) + 2)/A)^A_dependence_exponent 







  // The following parameters are interaction parameters of the Minnesota, FHT and EFT interactions
  // ----------------------------------------------------------------------------------------------
  // If "basis" is in the variable names, variables are used only to calculate the basis generating potentials, as in the HF/MSDHF methods.
  // W,B,H,M are standard notations for spin/isospin/coordinate exchanges.
  // ...three_body_like: In the Minnesota interaction, a two-body interaction mimicking the three-body interaction is sometimes added, which writes V(r1,r2) = V3 . exp (-nu r1^2) . exp (-nu r2^2).
  // For the FHT interaction, ctr is for central, so is for spin-orbit, and t is for tensor. alpha is the range of each term, which occur in Gaussian function exp (-alpha (r_relative)^2)

  double V0_Minnesota_basis[5]; 
  double rho_Minnesota_basis[3]; 
  double u_Minnesota_basis; 
  double nu_three_body_like_basis; 
  double V_three_body_like_basis;		
  
  double V0_ctr_basis[3]; 
  double alpha_ctr_basis[3]; 
  double W_ctr_basis[3]; 
  double B_ctr_basis[3]; 
  double H_ctr_basis[3]; 
  double M_ctr_basis[3];

  double V0_so_basis[2]; 
  double alpha_so_basis[2]; 
  double W_so_basis[2]; 
  double H_so_basis[2]; 
  double V0_t_basis[3]; 
  double alpha_t_basis[3]; 
  double W_t_basis[3]; 
  double H_t_basis[3];

  double V0_ctr_ot_basis; 
  double V0_ctr_et_basis; 
  double V0_ctr_os_basis; 
  double V0_ctr_es_basis; 
  double V0_so_ot_basis; 
  double V0_so_et_basis; 
  double V0_t_ot_basis; 
  double V0_t_et_basis;

  double VS_const_LO_T0_basis;
  double VS_const_LO_T1_basis;
  double VT_sigma_product_LO_T0_basis;
  double VT_sigma_product_LO_T1_basis;
  double V1_q2_NLO_basis;
  double V2_k2_NLO_basis;
  double V3_q2_sigma_product_NLO_basis;
  double V4_k2_sigma_product_NLO_basis;
  double V5_sigma_q_vector_k_NLO_basis;
  double V6_sigma_q_product_NLO_basis;
  double V7_sigma_k_product_NLO_basis;
  
  double V0_Minnesota[5]; 
  double rho_Minnesota[3]; 
  double u_Minnesota; 
  double nu_three_body_like; 
  double V_three_body_like;

  double V0_ctr[3]; 
  double alpha_ctr[3]; 
  double W_ctr[3]; 
  double B_ctr[3]; 
  double H_ctr[3]; 
  double M_ctr[3];

  double V0_so[2]; 
  double alpha_so[2]; 
  double W_so[2]; 
  double H_so[2]; 
  double V0_t[3]; 
  double alpha_t[3]; 
  double W_t[3]; 
  double H_t[3];

  double V0_ctr_ot; 
  double V0_ctr_et; 
  double V0_ctr_os; 
  double V0_ctr_es; 
  double V0_so_ot; 
  double V0_so_et; 
  double V0_t_ot; 
  double V0_t_et;
  
  double VS_const_LO_T0;
  double VS_const_LO_T1;
  double VT_sigma_product_LO_T0;
  double VT_sigma_product_LO_T1;
  double V1_q2_NLO;
  double V2_k2_NLO;
  double V3_q2_sigma_product_NLO;
  double V4_k2_sigma_product_NLO;
  double V5_sigma_q_vector_k_NLO;
  double V6_sigma_q_product_NLO;
  double V7_sigma_k_product_NLO;

  unsigned int eigenset_vectors_number_max;                // maximal number of GSM eigensets (i.e. typically sets of J-Pi quantum numbers of GSM eigenvectors) considering all nuclei in the GSM optimization code. 
                                                           // They are used in arrays to fix dimensions.

  unsigned int Np_nlj , Np_nlj_res;                        // number of proton  shells, for which n,l,j are fixed, for full space or pole approximation space
  unsigned int Nn_nlj , Nn_nlj_res;                        // number of neutron shells, for which n,l,j are fixed, for full space or pole approximation space

  unsigned int N_nlj_relative , N_nlj_res_relative;        // number of diproton/dineutron/deuteron shells in relative coordinates, for which n,l,j relative are fixed, for full space or pole approximation space    
  
  unsigned int Np_nljm , Np_nljm_res;                      // number of proton  states, for which n,l,j,m are fixed, for full space or pole approximation space
  unsigned int Nn_nljm , Nn_nljm_res;                      // number of neutron states, for which n,l,j,m are fixed, for full space or pole approximation space

  int nmax_p , nmax_n , nmax_relative;                     // maximal principal quantum number of protons and neutrons, and of relative states for diproton/dineutron/deuteron states in relative coordinates
  int lmax_p , lmax_n , lmax_relative;                     // maximal orbital angular momentum of protons and neutrons, and of relative states for diproton/dineutron/deuteron states in relative coordinates 
  
  int lmax_common_p;                                       // maximal orbital angular momentum of protons for all considers nuclear states in the GSM optimization code
  int lmax_common_n;                                       // maximal orbital angular momentum of protons for all considers nuclear states in the GSM optimization code


  


  // Maximal orbital angular momenta used in the interaction class, for Hamiltonian diagonalization or for the calculation of basis-generating potentials such as HF/MSDHF
  // ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
  // If "basis" is in the variable names, variables are used only to calculate the basis generating potentials, as in the HF/MSDHF methods.
  // The interaction maximal orbital angular momentum can be different from the maximal orbital angular momentum used in the one-body basis if one considers Nhbar omega spaces to generate |NCM-HO LCM intrinsic> states for GSM-CC, 
  // for which large orbital angular momenta are needed but no interaction matrix elements for these orbital angular momenta are used.
  // Indeed, high-l configurations are just there to have an exact separation of intrinsic and CM parts. 
  // All matrix elements of states with l > lmax_for_interaction with the HO expansion are then put to zero.

  int lmax_for_basis_interaction;

  int lmax_for_interaction;








  // Maximal total angular momenta (j) and total angular momenta projections (m) of one-body states (proton (p), neutron (n) or diproton/dineutron/deuteron shells in relative coordinates), and simple values involving the latter
  // ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  // m..._max_minus_half is m_max-1/2, m..._max_minus_m...min is m_max - m_min, two_m..._max is 2.m_max and four_m..._max is 4.m_max. All the latter values are integers and hence faster to use in applications.

  double jp_max;
  double jn_max;

  int jmax_relative;
 
  double mp_max , mn_max; 
  double mp_min , mn_min;

  int mp_max_minus_half; 
  int mn_max_minus_half;
  
  int two_mp_max; 
  int two_mn_max;
  
  int four_mp_max; 
  int four_mn_max;
  
  int mp_max_minus_mp_min; 
  int mn_max_minus_mn_min;  






  unsigned int natural_orbitals_reference_states_number; // Number of GSM eigenvectors used to generate natural orbitals. 
                                                         // Indeed, even if it is usual to calculate natural orbitals from one GSM eigenvector using the scalar density matrix <Psi | a+(nlj) a(nlj) |Psi>,
                                                         // one can use \sum_i <Psi_i | a+(nlj) a(nlj) |Psi_i> with several GSM eigenvectors. 
                                                         // Natural orbitals are then optimized to have an overall reproduction of all used GSM eigenvectors. 

  unsigned int HF_max_iterations_number;                 // maximal number of HF iterations of the HF self-consistent procedure. It is also used for the calculation of OCM potentials.
  
  double HF_precision;                                   // maximal precision of the HF potential in the HF self-consistent procedure. It is also used for the calculation of OCM potentials.

  unsigned int files_number;                             // number of interaction files used in the HO code using fitted interaction TBMEs on file

  unsigned int prot_N_paths;                             // number of considered Berggren proton  basis contours (paths) 
  unsigned int neut_N_paths;                             // number of considered Berggren neutron basis contours (paths) 

  unsigned int eigensets_number;                         // number of GSM eigensets (i.e. typically sets of J-Pi quantum numbers of GSM eigenvectors)

  double prot_effective_charge;                          // effective charge of protons  used in electro-magnetic transitions
  double neut_effective_charge;                          // effective charge of neutrons used in electro-magnetic transitions
  





  // The following booleans are put to true if one calculate a given type of observable
  // ----------------------------------------------------------------------------------
  // It can be GSM multipole (r^L YL, ...) electromagnetic (EM), beta, density, correlation density, spectroscopic factors, overlap functions, rms radius, Hamiltonian parts (kinetic, nuclear for core and interaction, Coulomb for core and interaction, ...)
  // Coulomb isospin mixture, which is defined as <Psi(Hamiltonian without Coulomb)|Psi(Hamiltonian with Coulomb)>^2, operators functions of one-body a+ and a~ creation and annihilation operators.

  bool are_there_GSM_multipoles;
  bool are_there_EM_transitions;
  bool are_there_EM_transitions_strength;
  bool are_there_beta_transitions;
  bool are_there_beta_transitions_strength;
  bool are_there_densities;
  bool are_there_correlation_densities;
  bool are_there_spectroscopic_factors;
  bool are_there_overlap_functions;
  bool are_there_rms_radii;
  bool are_there_rms_radius_one_body_strengths;
  bool are_there_Hamiltonian_parts;
  bool are_there_Coulomb_isospin_mixtures;
  bool are_there_dagger_tilde_operators;

  




  // The following integers are the number of occurrences of calculations per considered observable
  // ----------------------------------------------------------------------------------------------
  // It can be GSM multipole (r^L YL, ...) electromagnetic (EM), beta, density, correlation density, spectroscopic factors, overlap functions, rms radius, Hamiltonian parts (kinetic, nuclear for core and interaction, Coulomb for core and interaction, ...)
  // T+/T- operators (two-particle code only) and operators functions of one-body a+ and a~ creation and annihilation operators.

  unsigned int GSM_multipoles_number;
  unsigned int EM_transitions_number;
  unsigned int EM_transitions_strength_number;
  unsigned int beta_transitions_number;
  unsigned int beta_transitions_strength_number;
  unsigned int density_number;
  unsigned int correlation_density_number;
  unsigned int correlation_density_theta_number;
  unsigned int spectroscopic_factor_number;
  unsigned int overlap_function_number;
  unsigned int rms_radius_number;
  unsigned int rms_radius_one_body_strength_number;
  unsigned int Hamiltonian_parts_eigenstates_number;
  unsigned int Coulomb_isospin_mixture_number;
  unsigned int dagger_tilde_operators_number;


  // Value used if one considers only one angle in correlation density. It is then in degrees.

  bool is_correlation_density_theta_value_imposed;
  
  double correlation_density_imposed_theta_value;

  

  // The data starting with RDM are used only in the RDM code.
  // ---------------------------------------------------------

  RDM_matrix_constraint_type RDM_matrix_constraint; // Enumeration stating what matrices of P,Q,G,T1,T2' are demanded to be positive definite. 

  bool RDM_is_it_BiCG; // true if one uses the biconjugate gradient method to solve the Hessian matrix linear system, false if one use LU/Cholkesky decomposition
  
  bool RDM_are_there_J_constraints; // true if one uses J constraints conditions of the form <Psi | [a+(a) a~(b)]^1 . J^(1) | Psi>, false if not.

  bool RDM_is_there_CM_correction; // true if one demands to have <Psi | Hcm | Psi> = 0, to have |Psi> = |Psi[intrinsic]> |Psi[CM]>, false if not.

  bool RDM_is_there_isospin_constraint; // true if one demands to have <Psi | T^2 | Psi> = |Tz|(|Tz|+1), false if not.
  
  bool RDM_Gamma_init_from_file; // true if initial <Psi | [ [a+(a) a+(b)]^J [a~(c) a~(d)]^J ]^0 | Psi> matrices are taken from a file, false if not.

  bool RDM_is_there_E_reference; // true if one uses a subspace constraint energy, which is the reference energy as <Psi[subspace] | H | Psi[subspace] >= E[reference], false if not.

  double RDM_E_minimization_precision; // precision of the RDM optimization for energy.

  double RDM_sigma_init; // constant of the quadratic term entering the augmented Lagrangian method.
		   
  double RDM_multiplicative_sigma_step; // factor by which sigma in multiplied/divided in the augmented Lagrangian method if the primal term is too large/small compared to the dual term. 
				
  double RDM_smallness_factor;  // factor by which the functional gradient sigma is multiplied so that the primal test if close to the dual test.
    
  double RDM_BP; // total binary parity (see observables_basic_functions.cpp for definition) of the considered |Psi> state.

  double RDM_vector_index; // vector index of the considered |Psi> state.
  
  double RDM_J; // total angular momentum of the considered |Psi> state.

  double RDM_E_reference; // energy of the eigenstate in a reduced model space P, so that <Psi | P H P | Psi> >= E_reference.

  double RDM_Hamiltonian_renormalization_factor; // Multiplicative coefficient of the TBMEs of the Hamiltonian used in the RDM procedure (denoted x in comments).
                                                 // If the considered Hamiltonian is H = h + V, with h and V its one-body and two-parts, it is replaced by H[RDM] = h + x.V in the RDM procedure.
                                                 // Indeed, one typically has overbinding in RDM, so that demanding 0 < x < 1 compensates for it.
  
  enum CC_reaction_type CC_reaction;                         // CC reaction type: scattering or radiative capture
  
  enum CC_reaction_calculation_type CC_reaction_calculation; // CC calculation that is done: poles (i.e. CC Hamiltonian diagonalization), phase shifts, differential or total cross sections, excitation function

  bool CC_are_GSM_a_dagger_vectors_calculated;               // true if one calculates all GSM vectors of the form A+(projectile)|target> to build CC equations, false if they are read from disk as they are already stored

  double CC_E_total_CM_start;                                // Starting CM energy of the composite in a nuclear reaction for the calculation of reaction observables
  double CC_E_total_CM_end;                                  // End      CM energy of the composite in a nuclear reaction for the calculation of reaction observables
  double CC_average_n_scat_target_projectile_max;            // Average number of one-body scattering states in composite nuclear states for truncation

  unsigned int CC_corrective_factors_composite_number;       // Number of corrective factors (one for each set of J-Pi quantum numbers) considered in CC equations, 
                                                             // as one multiplies all interaction TBMEs by a J-Pi corrective factor if one calculates a J-Pi eigenvector in GSM-CC.
                                                             // It corrects for missing channels typically

  unsigned int CC_N_target_projectile_states;                // Number of target-projectile composites used in CC equations
  unsigned int CC_N_partial_waves_max;                       // Maximal number of partial waves for the partial wave decomposition of the CM part of the projectile

  unsigned int CC_Davidson_N_restarts;                       // Maximal number of restarts with the Jacobi-Davidson method, i.e. with a new starting pivot vector, for the diagonalization of the CC Hamiltonian matrix
                                                             // One restarts if all Lanczos or Jacobi-Davidson vectors have been used without having convergence

  unsigned int CC_Davidson_max_dimension;                    // Maximal number of Jacobi-Davidson vectors for the diagonalization of the CC Hamiltonian matrix

  double CC_Davidson_eigenvector_precision;                  // Precision under which one considers that the Jacobi-Davidson method converges.
                                                             // It is the infinite norm of the component of the last calculated Lanczos or Jacobi-Davidson vector

  double CC_relative_SVD_precision;                          // eigenvalues of the matrix of the overlap matrices to invert in the CC equations to orthogonalize channels are ignored in the solution 
                                                             // if they are smaller in modulus than CC_relative_SVD_precision when inverting the linear system with the Moore-Penrose pseudo-inverse

  double CC_forbidden_channel_precision;                     // Precision under which one considers that a channel is a repetition of another or does not exist. It is |<c | c>|oo or |<c' | c> - 1|oo for c' != c

  unsigned int CC_N_energies;                                // Number of projectile energies considered for the calculation of reaction observables
  unsigned int CC_N_CM_angles;                               // Number of angles of the center of mass angular part in its partial wave decomposition for the calculation of angular dependent cross sections

  enum EM_type CC_EM_for_total_cross_section;                // One can calculate radiative capture cross sections of only electric or magnetic type. This type is given here.

  int CC_L_limit_for_differential_cross_section;             // Maximal orbital angular momentum of the CM part of the projectile considered in differential cross sections
  int CC_L_for_total_cross_section;                          // Maximal orbital angular momentum of the CM part of the projectile considered in total cross sections

  unsigned int CC_N_theta_gamma;                             // Number of theta angles used in the calculation of differential cross sections of radiative capture (gamma is for photon)
  unsigned int CC_N_phi_gamma;                               // Number of phi   angles used in the calculation of differential cross sections of radiative capture (gamma is for photon)

  bool CC_is_it_longwavelength_approximation;                // true if one uses longwavelength approximation in radiative capture, false if not
  bool CC_is_it_HO_expansion;                                // true if one expands channels with HO states, false if not

  unsigned int CC_N_JPi_A_composite;                         // Number of different J-Pi sets of quantum number for the composite (scattering only)
  unsigned int CC_N_JPi_A_in_composite;                      // Number of different J-Pi sets of quantum number for the incoming composite (radiative capture only)
  unsigned int CC_N_JPi_A_out_composite;                     // Number of different J-Pi sets of quantum number for the formed nucleus     (radiative capture only)
  
  unsigned int CC_cluster_number;                            // Number of different clusters used in the CC equations.
                                                             // For example, it is 2 for (d,p) reactions if one considers only deuteron and proton channels
  
  int CC_Lmax_all;                                           // Maximal orbital angular momentum of the CM part of projectiles
  
  unsigned int CC_J_number_max_all;                          // Maximal number of M-states of J total angular momentum for all J's
  
  bool are_GSM_vectors_stored_on_disk;                       // true if Lanczos, Davidson vectors and Hamiltonian times these vectors are stored on disk, false if not
  
  bool are_configuration_probabilities_printed;              // true if one prints configuration probabilities on screen, false if not

  bool are_scattering_configuration_probabilities_printed;   // true if one considers configuration probabilities of all types, pole or scattering, to be printed on screen, false is not
  
  bool is_there_effective_range_expansion;                   // true if one calculates the effective range expansion in the two-body relative code, false if not

  bool M_equal_J_imposed_in_GSM_vectors;                     // true if one demands M = J in all cases in GSM vectors, false if not.
                                                             // One cannot use TRS if M != 0 in this case, which is typically twice slower in matrix-vector Hamiltonian operation.
  // But one does not have to store eigenvectors with all M projections on disk if observables are calculated afterwards, which can be very long.
  
  bool is_there_disk_storage_eigenvectors_all_M;             // true if one stores eigenvectors with all their M projections on disk, false if not.
  // It is needed when calculating target states for future CC calculations or if does not impose M=J in GSM vectors and calculates associated observables afterwards.
  
  int E_CM_HO_max;                                           // Maximal CM energy of HO CM states in the expansion of projectiles in intrinsic/CM coordinates,
                                                             // hence equal to 2.NCM_max + LCM_max






  class array<double> CC_CM_angles; // Values of the angles used in angular-dependent reaction observables. They are given in degrees in the input file and converted to radians afterwards.






  // The following parameters are diffuseness (d), radius (R0), central strength (Vo) and spin-orbit strength (Vso) of WS potentials
  // -------------------------------------------------------------------------------------------------------------------------------
  // Arrays are function of orbital angular momentum l, so that one has different parameters for different partial waves.
  // "core" (without "basis") is for parameters used for the WS of the core for Hamiltonian diagonalization.
  // "basis_core" is for parameters used for the WS of the core for the calculation of basis-generating potentials such as HF/MSDHF.
  // "basis" (without "core") is the parameters used for the WS potential directly used to generate the one-body basis,
  // or two-body relative for diproton/dineutron/deuteron basis, without recurring to HF/MSDHF/OCM for example.

  class array<double> prot_d_core_potential_tab , prot_R0_core_potential_tab , prot_Vo_core_potential_tab , prot_Vso_core_potential_tab;
  class array<double> neut_d_core_potential_tab , neut_R0_core_potential_tab , neut_Vo_core_potential_tab , neut_Vso_core_potential_tab;

  class array<double> prot_d_basis_core_potential_tab , prot_R0_basis_core_potential_tab , prot_Vo_basis_core_potential_tab , prot_Vso_basis_core_potential_tab;
  class array<double> neut_d_basis_core_potential_tab , neut_R0_basis_core_potential_tab , neut_Vo_basis_core_potential_tab , neut_Vso_basis_core_potential_tab;

  class array<double> prot_d_basis_tab , prot_R0_basis_tab , prot_Vo_basis_tab , prot_Vso_basis_tab;
  class array<double> neut_d_basis_tab , neut_R0_basis_tab , neut_Vo_basis_tab , neut_Vso_basis_tab;

  class array<double> d_basis_relative_tab , R0_basis_relative_tab , Vo_basis_relative_tab , Vso_basis_relative_tab;






  class array<double> V_Gaussian_consts_basis; // array of coupling constants for interactions having Gaussian form factors, function of parity, J and T for the calculation of basis-generating potentials such as HF/MSDHF
  class array<double> V_Gaussian_consts;       // array of coupling constants for interactions having Gaussian form factors, function of parity, J and T for Hamiltonian diagonalization
  
  class array<int> nmax_HO_lab_tab; // maximal principal quantum numbers used in the HO expansion function of orbital angular momentum l for all operators expanded in a HO basis
  
  class array<int> nmax_HO_relative_tab;  // maximal principal quantum numbers used in the HO expansion function of orbital angular momentum l_relative for the Hamiltonian diagonalization with diproton/dineutron/deuteron

  class array<int> nmax_GHF_lab_tab; // maximal principal quantum numbers used in the Gamow-Hartree Fock (GHF) expansion function of orbital angular momentum l for Hamiltonian diagonalization.
                                     // It is for natural orbitals in the Qbox method, as they are typically expanded in GHF basis, not HO basis.
                                     // The GHF basis and the current Berggren basis are identical otherwise by convention for l <= lmax_for_interaction.
  
  class lj_table<double> prot_b_lab_partial_waves; // (l,j) array of HO lengths for all proton  partial waves for Hamiltonian diagonalization
  class lj_table<double> neut_b_lab_partial_waves; // (l,j) array of HO lengths for all neutron partial waves for Hamiltonian diagonalization

  class lj_table<enum potential_type> prot_basis_potential_partial_waves; // (l,j) array of HO lengths for all proton  partial waves for the calculation of basis-generating potentials such as HF/MSDHF
  class lj_table<enum potential_type> neut_basis_potential_partial_waves; // (l,j) array of HO lengths for all neutron partial waves for the calculation of basis-generating potentials such as HF/MSDHF

  class array<unsigned int> natural_orbitals_reference_states_BP_tab;           // binary parities (see observables_basic_functions.cpp for definition) of the GSM eigenvectors used to generate natural orbitals (see above)
  class array<unsigned int> natural_orbitals_reference_states_vector_index_tab; // vector indices of fixed J-Pi quantum numbers (e.g. 1 for the first 0+ excited state) 
                                                                                // of the GSM eigenvectors used to generate natural orbitals (see above)

  class array<double> natural_orbitals_reference_states_J_tab;                  // total angular momenta of the GSM eigenvectors used to generate natural orbitals (see above)
                                                                                // These arrays are functions of the reference state index.
                                                                                // If one has 0+(0), 2+(0) and 2+(1) as reference states, the reference state index is 0 for 0+(0), 1 for 2+(0) and 2 for 2+(1)

  class array<class nlj_struct> prot_shells_quantum_numbers; // array of structures containing data about proton  shells, in particular quantum_numbers, from which wave functions are excluded
  class array<class nlj_struct> neut_shells_quantum_numbers; // array of structures containing data about neutron shells, in particular quantum_numbers, from which wave functions are excluded

  class array<class nlj_struct> shells_quantum_numbers_relative; // array of structures containing data about diproton/dineutron/deuteron relative shells, in particular quantum_numbers, from which wave functions are excluded

  class lj_table<unsigned int> prot_basis_BP_tab; // (l,j) array of the binary parities (see observables_basic_functions.cpp for definition) of the optimized configurations in MSDHF, each for each optimized proton  partial wave
  class lj_table<unsigned int> neut_basis_BP_tab; // (l,j) array of the binary parities (see observables_basic_functions.cpp for definition) of the optimized configurations in MSDHF, each for each optimized neutron partial wave
  
  class lj_table<double> prot_basis_J_tab; // (l,j) array of the total angular momenta of the optimized configurations in MSDHF, each for each optimized proton  partial wave
  class lj_table<double> neut_basis_J_tab; // (l,j) array of the total angular momenta of the optimized configurations in MSDHF, each for each optimized neutron partial wave

  class array<unsigned int> BP_eigenset_tab; // array of binary parities of GSM eigenvectors (see observables_basic_functions.cpp for definition) as function of eigenset index (representing J, Pi)

  class array<unsigned int> eigenset_vectors_number_tab; // array of numbers of GSM eigenvectors of fixed quantum numbers as function of eigenset index (representing J, Pi)
  
  class array<double> J_eigenset_tab; // array of total angular momenta of GSM eigenvectors as function of eigenset index (representing J, Pi)
  
  class array<class correlated_state_str> PSI_qn_from_file_tab; // array of structures containing many-body quantum numbers (qn) such as Z,N,J,Pi,E, whose part is read from file, of GSM eigenvectors
                                                                // function of eigenset index (representing J, Pi) and eigenvector index of fixed J-Pi quantum numbers













  // The following arrays contain information about observables to calculate and in out GSM eigenvectors in <Psi_out | Op | Psi_in> 
  // ------------------------------------------------------------------------------------------------------------------------------
  // "Strength" means that the operator is calculated on a radial grid (strength function), whose integral provide with the value of the observable itself.
  // This is not true, however, for rms radius, as rms radius is a two-body operator, and the integration mentioned above works only for one-body operators.
  // Hence, the strength function of the rms radius is in fact the strength function of its one-body part.
  // This function is useful to know if one can truncate radial integrals in R afterwards, for example for loosely bound or unbound states, as strength functions must be negligible therein for it.
  //
  // All arrays are function of the occurrence index of calculations per considered observable. For example, if one considers 3 electromagnetic transitions, it is 0,1,2.
  //
  // Operator arrays are enumerations. For example: E,M (electric,magnetic), rms radius of proton/neutron type, kinetic/one-body or two-body nuclear/one-body or two-body Coulomb for Hamiltonian part 
  //                                                [a+ a~]^J for dagger_tilde (see enum_struct_definitions for all possible operators)
  // BP,J,vector_index are for binary parity (see observables_basic_functions.cpp for definition), total angular momentum and eigenvector index of fixed J-Pi quantum numbers.
  // IN, OUT indicate |Psi_in>  and |Psi_out>
  // is_it_longwavelength_approximatio: true if one uses longwavelength approximation in radiative capture, false if not
  // is_it_HO_expansion: true if one expands observable operators with HO states, false if not
  // L: orbital angular momentum of the operator. For example, it is 2 for E2 transitions.
  // pm is +/-, for beta plus or beta minus
  // W0 is the available phase space energy of beta transitions
  // is_it_Gauss_Legendre: true if one uses a radial grid of Gauss-Legendre points, false if one uses a grid of uniformly distributed points (density or strength functions only)
  // nucleus, cluster: nucleus or cluster considered in the spectroscopic factor/overlap calculation of <Psi_out | A+(nucleus/cluster) | Psi_in>.
  // Z,N,LCM,NCM_HO_max: number of protons and neutrons of the projectile, CM orbital angular momentum of the projectile, and maximal principal quantum number of the HO CM part of the projectile
  //                     Indeed, clusters wave functions read |NCM-HO LCM intrinsic>.
  // rms_radius_frozen_core_tab: to calculate rms radii, one need the experimental value of the rms radius of the core. It is stored in this array.

  class array<int> GSM_multipoles_L_tab;
  class array<unsigned int> GSM_multipoles_BP_tab;
  class array<double> GSM_multipoles_J_tab;
  class array<unsigned int> GSM_multipoles_vector_index_tab;
  class array<bool> GSM_multipoles_is_it_HO_expansion_tab;
  
  class array<enum EM_type> EM_tab;
  class array<int> EM_L_tab;
  class array<unsigned int> EM_BP_IN_tab;
  class array<unsigned int> EM_BP_OUT_tab;
  class array<double> EM_J_IN_tab;
  class array<double> EM_J_OUT_tab;
  class array<unsigned int> EM_vector_index_IN_tab;
  class array<unsigned int> EM_vector_index_OUT_tab;
  class array<bool> EM_is_it_longwavelength_approximation_tab;
  class array<bool> EM_is_it_HO_expansion_tab;

  class array<enum EM_type> EM_strength_tab;
  class array<int> EM_strength_L_tab;
  class array<unsigned int> EM_strength_BP_IN_tab;
  class array<unsigned int> EM_strength_BP_OUT_tab;
  class array<double> EM_strength_J_IN_tab;
  class array<double> EM_strength_J_OUT_tab;
  class array<unsigned int> EM_strength_vector_index_IN_tab;
  class array<unsigned int> EM_strength_vector_index_OUT_tab;
  class array<bool> EM_strength_is_it_longwavelength_approximation_tab;
  class array<bool> EM_strength_is_it_Gauss_Legendre_tab;

  class array<enum beta_type> beta_tab;
  class array<enum beta_pm_type> beta_pm_tab;
  class array<unsigned int> beta_BP_IN_tab;
  class array<unsigned int> beta_BP_OUT_tab;
  class array<double> beta_J_IN_tab;
  class array<double> beta_J_OUT_tab;
  class array<unsigned int> beta_vector_index_IN_tab;
  class array<unsigned int> beta_vector_index_OUT_tab;
  class array<bool> beta_is_it_HO_expansion_tab;
  class array<double> beta_W0_tab;

  class array<enum beta_type> beta_strength_tab;
  class array<enum beta_pm_type> beta_strength_pm_tab;
  class array<unsigned int> beta_strength_BP_IN_tab;
  class array<unsigned int> beta_strength_BP_OUT_tab;
  class array<double> beta_strength_J_IN_tab;
  class array<double> beta_strength_J_OUT_tab;
  class array<unsigned int> beta_strength_vector_index_IN_tab;
  class array<unsigned int> beta_strength_vector_index_OUT_tab;
  class array<bool> beta_strength_is_it_Gauss_Legendre_tab;

  class array<unsigned int> density_BP_tab;
  class array<double> density_J_tab;
  class array<unsigned int> density_vector_index_tab;
  class array<bool> density_is_it_radial_tab;
  class array<bool> density_is_it_Gauss_Legendre_tab;

  class array<unsigned int> correlation_density_BP_tab;
  class array<double> correlation_density_J_tab;
  class array<double> correlation_density_RKmax_tab;
  class array<unsigned int> correlation_density_vector_index_tab;
  class array<bool> correlation_density_is_it_radial_tab;
  class array<bool> correlation_density_is_it_Gauss_Legendre_tab;
  class array<bool> correlation_density_is_it_HO_expansion_tab;

  class array<enum spectroscopic_factor_type> spectroscopic_factor_type_tab;
  class array<enum nucleus_type> spectroscopic_factor_nucleus_tab;
  class array<enum particle_type> spectroscopic_factor_cluster_tab;
  class array<int> spectroscopic_factor_Z_projectile_tab;
  class array<int> spectroscopic_factor_N_projectile_tab;
  class array<int> spectroscopic_factor_LCM_projectile_tab;
  class array<int> spectroscopic_factor_NCM_HO_max_projectile_tab;
  class array<unsigned int> spectroscopic_factor_BP_IN_tab;
  class array<unsigned int> spectroscopic_factor_BP_OUT_tab;
  class array<unsigned int> spectroscopic_factor_BP_projectile_tab;
  class array<double> spectroscopic_factor_J_IN_tab;
  class array<double> spectroscopic_factor_J_OUT_tab;
  class array<double> spectroscopic_factor_J_projectile_tab;
  class array<unsigned int> spectroscopic_factor_vector_index_IN_tab;
  class array<unsigned int> spectroscopic_factor_vector_index_OUT_tab;
  class array<unsigned int> spectroscopic_factor_vector_index_projectile_tab;

  class array<enum spectroscopic_factor_type> overlap_function_type_tab;
  class array<enum nucleus_type> overlap_function_nucleus_tab;
  class array<enum particle_type> overlap_function_cluster_tab;
  class array<int> overlap_function_Z_projectile_tab;
  class array<int> overlap_function_N_projectile_tab;
  class array<int> overlap_function_LCM_projectile_tab;
  class array<int> overlap_function_NCM_HO_max_projectile_tab;
  class array<unsigned int> overlap_function_BP_IN_tab;
  class array<unsigned int> overlap_function_BP_OUT_tab;
  class array<unsigned int> overlap_function_BP_projectile_tab;
  class array<double> overlap_function_J_IN_tab;
  class array<double> overlap_function_J_OUT_tab;
  class array<double> overlap_function_J_projectile_tab;
  class array<unsigned int> overlap_function_vector_index_IN_tab;
  class array<unsigned int> overlap_function_vector_index_OUT_tab;
  class array<unsigned int> overlap_function_vector_index_projectile_tab;
  class array<bool> overlap_function_is_it_Gauss_Legendre_tab;

  class array<bool> rms_radius_is_it_HO_expansion_tab;
  class array<unsigned int> rms_radius_BP_tab;
  class array<double> rms_radius_J_tab;
  class array<unsigned int> rms_radius_vector_index_tab;
  class array<enum particle_type> rms_radius_particle_tab;
  class array<double> rms_radius_frozen_core_tab;

  class array<unsigned int> rms_radius_one_body_strength_BP_tab;
  class array<double> rms_radius_one_body_strength_J_tab;
  class array<unsigned int> rms_radius_one_body_strength_vector_index_tab;
  class array<enum particle_type> rms_radius_one_body_strength_particle_tab;
  class array<bool> rms_radius_one_body_strength_is_it_Gauss_Legendre_tab;

  class array<unsigned int> Hamiltonian_parts_BP_tab;
  class array<double> Hamiltonian_parts_J_tab;
  class array<unsigned int> Hamiltonian_parts_vector_index_tab;

  class array<unsigned int> Coulomb_isospin_mixture_BP_tab;
  class array<double> Coulomb_isospin_mixture_J_tab;
  class array<unsigned int> Coulomb_isospin_mixture_vector_index_tab;

  class array<enum dagger_tilde_operator_type> dagger_tilde_operators_tab;
  class array<unsigned int> dagger_tilde_operators_BP_IN_tab;
  class array<unsigned int> dagger_tilde_operators_BP_OUT_tab;
  class array<double> dagger_tilde_operators_J_IN_tab;
  class array<double> dagger_tilde_operators_J_OUT_tab;
  class array<unsigned int> dagger_tilde_operators_vector_index_IN_tab;
  class array<unsigned int> dagger_tilde_operators_vector_index_OUT_tab;
















  class array<unsigned int> CC_corrective_factors_BP_A_composite_tab; // array of binary parities (see observables_basic_functions.cpp for definition) of the CC state for which interaction TBMEs are multiplied by a corrective factor.
  class array<double> CC_corrective_factors_J_A_composite_tab;        // array of total angular momenta of the CC state for which interaction TBMEs are multiplied by a corrective factor.
  class array<double> CC_corrective_factors_composite_tab;            // array of corrective factors of the CC state by which interaction TBMEs are multiplied
                                                                      // These arrays are functions of the corrective factor index.
                                                                      // If one has corrective factors for 0+, 2+ and 1-, the corrective factor index is 0 for 0+, 1 for 2+ and 2 for 1-

  class array<unsigned int> CC_BP_target_tab;                 // array of binary parities (see observables_basic_functions.cpp for definition) of the target states
  class array<double> CC_J_target_tab;                        // array of total angular momenta of the target states
  class array<bool> CC_is_it_pole_target_tab;                 // array of booleans which are true if the target state is bound or resonant, and false if it is scattering
  class array<unsigned int> CC_vector_index_target_tab;       // array of vector indices of fixed J-Pi quantum numbers of the target states (e.g. 1 for the first 0+ excited state) 
  class array<enum particle_type> CC_projectile_tab;          // array of type of projectile or ejectile in the considered reaction: proton, neutron, deuteron, ....
  class array<unsigned int> CC_N_partial_waves_tab;           // array of numbers of partial waves for the partial wave decomposition of the CM part of the projectile
  class array<double> CC_real_E_intrinsic_projectile_tab;     // array of projectile or ejectile energies (MeV)
  class array<double> CC_Gamma_intrinsic_projectile_tab;      // array of projectile or ejectile widths   (keV)
  class array<double> CC_real_E_target_tab;                   // array of projectile or ejectile energies (MeV)
  class array<double> CC_Gamma_target_tab;                    // array of projectile or ejectile widths   (keV)
  class array<complex<double> > CC_average_n_scat_target_tab; // array of average number of one-body scattering states in the considered composite nuclear state for truncation
  class array<bool> CC_is_it_entrance_tab;                    // array of booleans equal to true if the composite is in an entrance channel, false if not 
                                                              // These arrays are functions of the composite index, which goes from 0 to CC_N_target_projectile_states - 1

  class array<int> CC_partial_wave_L_cluster_tab;    // array of orbital angular momenta of the CM part of the cluster projectile of the considered composite nuclear state
  class array<double> CC_partial_wave_J_cluster_tab; // array of total   angular momenta of the CM part of the cluster projectile of the considered composite nuclear state
                                                     // These arrays are functions of the composite index iT, which goes from 0 to CC_N_target_projectile_states - 1
                                                     // and of the cluster partial wave index, which goes from 0 to CC_N_partial_waves_tab(iT) - 1

  class array<unsigned int> CC_BP_A_composite_tab;           // array of binary parities (see observables_basic_functions.cpp for definition) of the composite (scattering only)
  class array<unsigned int> CC_vector_index_A_composite_tab; // array of vector indices of fixed J-Pi quantum numbers of the composite (e.g. 1 for the first 0+ excited state) (scattering only)
  class array<double> CC_J_A_composite_tab;                  // array of total angular momenta of the composite (scattering only)
                                                             // These arrays are functions of the composite J-Pi set index, which goes from 0 to CC_N_JPi_A_composite - 1

  class array<double> CC_J_A_in_composite_tab;        // array of total angular momenta of the incoming composite (radiative capture only)
  class array<unsigned int> CC_BP_A_in_composite_tab; // array of binary parities (see observables_basic_functions.cpp for definition) of the incoming composite (radiative capture only)
                                                      // These arrays are functions of the incoming composite J-Pi set index, which goes from 0 to CC_N_JPi_A_in_composite - 1

  class array<double> CC_J_A_out_composite_tab;                  // array of total angular momenta of the formed nucleus (radiative capture only)
  class array<unsigned int> CC_BP_A_out_composite_tab;           // array of binary parities (see observables_basic_functions.cpp for definition) of the formed nucleus (radiative capture only)
  class array<unsigned int> CC_vector_index_A_out_composite_tab; // array of vector indices of fixed J-Pi quantum numbers of the formed nucleus (e.g. 1 for the first 0+ excited state) (radiative capture only)
                                                                 // These arrays are functions of the formed nucleus J-Pi set index, which goes from 0 to CC_N_JPi_A_out_composite - 1

  class array<enum particle_type> CC_cluster_tab; // array of type of different clusters entering the considered reaction: proton, neutron, deuteron, ...
  class array<int> CC_Lmax_cluster_CM_tab;        // array of orbital angular momenta of the CM part of the considered cluster 
                                                  // These arrays are functions of cluster index, which goes from 0 to CC_cluster_number - 1

  class array<int> CC_Nmin_PCM_cluster_tab;                     // array of minimal principal quantum number of the CM part of the considered partial wave of the considered cluster,
                                                                // from which one considers that it is not almost fully occupied in the core, as otherwise projected out with PCM projector

  class array<unsigned int> CC_N_poles_cluster_CM_tab;          // array of the number of bound or resonant states of the considered partial wave of the considered cluster

  class array<complex<double> > CC_K_peak_cluster_CM_tab;       // array of k.peak   values on the Berggren basis contour of the considered partial wave of the considered cluster
  class array<complex<double> > CC_K_middle_cluster_CM_tab;     // array of k.middle values on the Berggren basis contour of the considered partial wave of the considered cluster
  class array<complex<double> > CC_K_max_cluster_CM_tab;        // array of k.max    values on the Berggren basis contour of the considered partial wave of the considered cluster

  class array<unsigned int> CC_N_K_peak_cluster_CM_tab;         // array of numbers of discretized CM scattering states on [0:k.peak]        on the Berggren basis contour of the considered partial wave of the considered cluster
  class array<unsigned int> CC_N_K_middle_cluster_CM_tab;       // array of numbers of discretized CM scattering states on [k.peak:k.middle] on the Berggren basis contour of the considered partial wave of the considered cluster
  class array<unsigned int> CC_N_K_max_cluster_CM_tab;          // array of numbers of discretized CM scattering states on [k.middle:k.max]  on the Berggren basis contour of the considered partial wave of the considered cluster

                                                                // These arrays are functions of cluster index ic, which goes from 0 to CC_cluster_number - 1,
                                                                // of L, which goes from 0 to CC_Lmax_cluster_CM_tab(ic) - 1,
                                                                // and of J_index, which goes from 0 to J_max - J_min + 1, with Jmin <= J <= Jmax, with Jmin = |J_intrinsic - L| and J_max = J_intrinsic + L
                                                                // with J_intrinsic the total angular momentum of the intrinsic part of the cluster
};

#endif


