#ifndef GSCONFIGURATION2PHSTR_H
#define GSCONFIGURATION2PHSTR_H

// TYPE is double or complex
// -------------------------

class configuration_2ph_data_str
{
public:

  configuration_2ph_data_str ();

  configuration_2ph_data_str (
			      const unsigned int n_scat_c , 
			      const unsigned int iC_c , 
			      const unsigned int shell_left_index_c ,
			      const unsigned int shell_right_index_c);

  void initialize (
		   const unsigned int n_scat_c ,
		   const unsigned int iC_c , 
		   const unsigned int shell_left_index_c ,
		   const unsigned int shell_right_index_c);
  
  void initialize (const class configuration_2ph_data_str &X);
  
  void allocate_fill (const class configuration_2ph_data_str &X);
  
  unsigned int get_n_scat () const
  {
    return n_scat;
  }
  
  unsigned int get_iC () const
  {
    return iC;
  }
 
  unsigned int get_shell_left_index () const
  {
    return shell_left_index;
  }
     
  unsigned int get_shell_right_index () const
  {
    return shell_right_index;
  }
    
private:
  
  unsigned char n_scat; // number of particles in the continuum

  unsigned int iC; // index of the configuration with fixed parity

  unsigned short int shell_left_index; // index of the alpha shell (left shell of (alpha, beta))

  unsigned short int shell_right_index; // index of the beta shell (right shell of (alpha, beta))
};

double used_memory_calc (const class configuration_2ph_data_str &T);

#endif


