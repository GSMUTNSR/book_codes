#ifndef GSMMULTIPOLETBMESANGULARTABLE_H
#define GSMMULTIPOLETBMESANGULARTABLE_H

// TYPE is double or complex
// -------------------------

class multipole_TBMEs_angular_table_str
{
public:
  
  multipole_TBMEs_angular_table_str ();
  
  multipole_TBMEs_angular_table_str (const int L_c , const double j_max , const int J_c);

  multipole_TBMEs_angular_table_str (const int L_c , const double m_max);
  
  multipole_TBMEs_angular_table_str (const multipole_TBMEs_angular_table_str &X);

  ~multipole_TBMEs_angular_table_str ();

  void allocate_calc_coupled (const int L_c , const double j_max , const int J_c);
  
  void allocate_calc_uncoupled (const int L_c , const double m_max);

  void allocate_fill (const class multipole_TBMEs_angular_table_str &X);

  void deallocate ();

  int get_J () const
  {
    if (!coupled_TBMEs_angular_table.is_it_filled ()) error_message_print_abort ("integer J is defined only when using the J-scheme two-body code in multipole_TBMEs_angular_table_str::get_J");
    
    return J;
  }
  
  bool is_it_filled () const
  {
    return (coupled_TBMEs_angular_table.is_it_filled () || CG_over_hat_L_table.is_it_filled ());
  }
  
  double operator () (
		      const int ij0 , const int im0 , 
		      const int ij1 , const int im1 , 
		      const int ij2 , const int im2 , 
		      const int ij3 , const int im3) const;
  
  double operator () (const int ij0 , const int ij1 , const int ij2 , const int ij3) const;
  
  friend double used_memory_calc (const class multipole_TBMEs_angular_table_str &T);

private:

  int L; // multipole integer value in r^L Y^L

  int J; // total angular momentum (coupled scheme only)
  
  int m_max_sum; // 2.m_max, with m_max the maximal total angular projection of one-body states (uncoupled scheme only). This value is used to obtain m[a] + m[b] from m indices equal to m + m_max (see GSM_small_classes.cpp).

  class array<double> coupled_TBMEs_angular_table; // products of phases and Wigner 6j signs (coupled scheme only)
  
  class array<double> CG_over_hat_L_table; // array of <j m j' -m' |L' -m''> Clebsch-Gordan coefficients divided by hat (L'), with j,j' <= m_max (= jmax) and all possible values for m,m',m''
                                           // stored as CG_over_hat_L_table(ij , im , ijp , imp), with ij=j-1/2, im = m-m_max, ijp=j'-1/2, imp = m'-m_max (uncoupled scheme only).
};

#endif




