#ifndef GSMBARYONSSDATA_H
#define GSMBARYONSSDATA_H

// SD is for Slater determinant
// ----------------------------

// TRS is for time-reversal symmetry
// ---------------------------------

// TYPE is double or complex
// -------------------------

// See files ...in_to_out.hpp, ...in_to_out.cpp, ...out_to_in.hpp, ...out_to_in.cpp for definitions of classes ending with ...in_to_out and ...out_to_in
// -----------------------------------------------------------------------------------------------------------------------------------------------------

// Classes
// -------
// Classes are typically defined in a file whose file name contains the class name.
//
// Otherwise :
// _ see GSM_nljm_indices_tables.hpp for arrays functions of n,l,j , such as lj_table and nlj_table
// _ see GSM_small_class.cpp, for example for the definitions of OBMEs classes, one_body_indices_str, nlj_struct, nljm_struct , ...


class baryons_data
{
public:
  
  baryons_data ();

  baryons_data (const class baryons_data &X);

  ~baryons_data ();

  void allocate ();

  void allocate_fill (const class baryons_data &X);

  void deallocate ();

  void one_jump_tables_in_to_out_deallocate ();
  
  void one_jump_tables_Jpm_in_to_out_deallocate ();
  
  void one_jump_tables_out_to_in_deallocate ();
  
  void one_jump_tables_Jpm_out_to_in_deallocate ();
  
  void tables_1ph_deallocate ();
  
  void tables_2ph_deallocate ();
  
  bool get_is_it_M_scheme () const
  {
    return is_it_M_scheme;
  }
  
  bool get_is_Coulomb_Hamiltonian_here () const
  {
    return is_Coulomb_Hamiltonian_here;
  }

  bool get_are_there_basis_natural_orbitals () const
  {
    return are_there_basis_natural_orbitals;
  }

  bool get_are_there_new_natural_orbitals () const
  {
    return are_there_new_natural_orbitals;
  }
  
  bool get_is_Hamiltonian_complex_scaled () const
  {
    return is_Hamiltonian_complex_scaled;
  }

  enum particle_type get_nucleonic_particle () const
  {
    return nucleonic_particle;
  }

  int get_hypernucleus_strangeness () const
  {
    return hypernucleus_strangeness;
  }

  int get_n_spec_max () const
  {
    return n_spec_max;
  }

  void set_nmax (const int nmax_c)
  {
    nmax = nmax_c;
  }
  
  int get_nmax () const
  {
    return nmax;
  }

  void set_lmax (const int lmax_c)
  {
    lmax = lmax_c;
  }
  
  int get_lmax () const
  {
    return lmax;
  }

  void set_n_holes_max (const int n_holes_max_c)
  {
    n_holes_max = n_holes_max_c;
  }
  
  int get_n_holes_max () const
  {
    return n_holes_max;
  }

  int get_n_holes_max_local (const unsigned int N_valence_baryons_local) const
  {
    if (N_valence_baryons_local == N_valence_baryons)    return  n_holes_max;
    if (N_valence_baryons_local == N_valence_baryons_1h) return (n_holes_max + 1);
    if (N_valence_baryons_local == N_valence_baryons_2h) return (n_holes_max + 2);

    abort_all ();
    
    return NADA;
  }
  
  void set_n_scat_max (const int n_scat_max_c)
  {
    n_scat_max = n_scat_max_c;
  }
  
  int get_n_scat_max () const
  {
    return n_scat_max;
  }

  void set_n_holes_max_pole_approximation (const int n_holes_max_pole_approximation_c)
  {
    n_holes_max_pole_approximation = n_holes_max_pole_approximation_c;
  }
  
  int get_n_holes_max_pole_approximation () const
  {
    return n_holes_max_pole_approximation;
  }

  int get_n_holes_max_pole_approximation_local (const unsigned int N_valence_baryons_local) const
  {
    if (N_valence_baryons_local == N_valence_baryons)    return  n_holes_max_pole_approximation;
    if (N_valence_baryons_local == N_valence_baryons_1h) return (n_holes_max_pole_approximation + 1);
    if (N_valence_baryons_local == N_valence_baryons_2h) return (n_holes_max_pole_approximation + 2);

    abort_all ();
    
    return NADA;
  }
  
  int get_E_min_hw () const
  {
    return E_min_hw;
  }
  
  int get_E_max_hw () const
  {
    return E_max_hw;
  }

  int get_E_max_hw_pole_approximation () const
  {
    return E_max_hw_pole_approximation;
  }

  int get_A () const
  {
    return A;
  }

  int get_A_basis () const
  {
    return A_basis;
  }

  int get_A_core () const
  {
    return A_core;
  }

  int get_Z_core () const
  {
    return Z_core;
  }

  int get_N_core () const
  {
    return N_core;
  }

  int get_Z () const
  {
    return Z;
  }

  int get_N () const
  {
    return N;
  }

  int get_Z_basis () const
  {
    return Z_basis;
  }

  int get_N_basis () const
  {
    return N_basis;
  }

  int get_hole_states_number () const
  {
    return hole_states_number;
  }

  unsigned int get_N_nucleons () const
  {
    return N_nucleons;
  }

  unsigned int get_N_valence_nucleons () const
  {
    return N_valence_nucleons;
  }
  
  unsigned int get_N_valence_nucleons_basis () const
  {
    return N_valence_nucleons_basis;
  }
  
  unsigned int get_N_valence_baryons () const
  {
    return N_valence_baryons;
  }

  unsigned int get_N_valence_baryons_1h () const
  {
    return N_valence_baryons_1h;
  }

  unsigned int get_N_valence_baryons_2h () const
  {
    return N_valence_baryons_2h;
  }

  int get_ZY_charge_pos () const
  {
    return ZY_charge_pos;
  }
  
  int get_ZY_charge_neg () const
  {
    return ZY_charge_neg;
  }

  void set_ZY_charge_basis_potential_pos (const int ZY_charge_basis_potential_pos_c)
  {
    ZY_charge_basis_potential_pos = ZY_charge_basis_potential_pos_c;
  }

  int get_ZY_charge_basis_potential_pos () const
  {
    return ZY_charge_basis_potential_pos;
  }

  void set_ZY_charge_basis_potential_neg (const int ZY_charge_basis_potential_neg_c)
  {
    ZY_charge_basis_potential_neg = ZY_charge_basis_potential_neg_c;
  }

  int get_ZY_charge_basis_potential_neg () const
  {
    return ZY_charge_basis_potential_neg;
  }

  double get_nucleus_mass () const
  {
    return nucleus_mass;
  }

  double get_nucleus_mass_basis () const
  {
    return nucleus_mass_basis;
  }

  double get_total_nucleus_mass () const
  {
    return total_nucleus_mass;
  }

  unsigned int get_N_nlj_baryon () const
  {
    return N_nlj_baryon;
  }

  unsigned int get_N_nljm_baryon () const
  {
    return N_nljm_baryon;
  }

  unsigned int get_N_nlj_res_baryon () const
  {
    return N_nlj_res_baryon;
  }

  unsigned int get_N_nljm_res_baryon () const
  {
    return N_nljm_res_baryon;
  }

  unsigned int get_natural_orbitals_reference_states_number () const
  {
    return natural_orbitals_reference_states_number;
  }

  double get_jmax () const
  {
    return jmax;
  }

  double get_m_min () const
  {
    return m_min;
  }

  double get_m_max () const
  {
    return m_max;
  }

  double get_m_max_minus_m_min () const
  {
    return m_max_minus_m_min;
  }

  double get_M_max () const
  {
    return M_max;
  }

  double get_M_max_1h () const
  {
    return M_max_1h;
  }

  double get_M_max_2h () const
  {
    return M_max_2h;
  }

  double get_M_max_local (const unsigned int N_valence_baryons_local) const
  {
    if (N_valence_baryons_local == N_valence_baryons)    return M_max;
    if (N_valence_baryons_local == N_valence_baryons_1h) return M_max_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return M_max_2h;

    abort_all ();
    
    return NADA;
  }
  
  int get_m_max_minus_half () const
  {
    return m_max_minus_half;
  }

  int get_two_m_max () const
  {
    return two_m_max;
  }

  int get_four_m_max () const
  {
    return four_m_max;
  }

  int get_iM_max () const
  {
    return iM_max;
  }

  int get_iM_max_1h () const
  {
    return iM_max_1h;
  }
  
  int get_iM_max_2h () const
  {
    return iM_max_2h;
  }
  
  int get_iM_max_local (const unsigned int N_valence_baryons_local) const
  {
    if (N_valence_baryons_local == N_valence_baryons)    return iM_max;
    if (N_valence_baryons_local == N_valence_baryons_1h) return iM_max_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return iM_max_2h;

    abort_all ();
    
    return NADA;
  }

  string get_debut_file_name () const
  {
    return debut_file_name;
  }

  double get_R_charge () const
  {
    return R_charge;
  }

  enum potential_type get_basis_potential () const
  {
    return basis_potential;
  }

  enum potential_type get_H_potential () const
  {
    return H_potential;
  }

  enum potential_type get_H_basis_core_potential () const
  {
    return H_basis_core_potential;
  }

  bool get_good_isospin_basis_potential () const
  {
    return good_isospin_basis_potential;
  }

  bool get_is_it_OCM_HO_core () const
  {
    return is_it_OCM_HO_core;
  }

  unsigned int get_N_bef_R_GL () const
  {
    return N_bef_R_GL;
  }

  unsigned int get_N_aft_R_GL () const
  {
    return N_aft_R_GL;
  }

  unsigned int get_N_bef_R_uniform () const
  {
    return N_bef_R_uniform;
  }

  unsigned int get_N_aft_R_uniform () const
  {
    return N_aft_R_uniform;
  }

  unsigned int get_Nk_momentum_uniform () const
  {
    return Nk_momentum_uniform;
  }

  unsigned int get_Nk_momentum_GL () const
  {
    return Nk_momentum_GL;
  }

  double get_R () const
  {
    return R;
  }

  double get_step_bef_R_uniform () const
  {
    return step_bef_R_uniform;
  }

  double get_R_real_max () const
  {
    return R_real_max;
  }

  double get_step_momentum_uniform () const
  {
    return step_momentum_uniform;
  }
  
  double get_kmax_momentum () const
  {
    return kmax_momentum;
  }
  
  double get_R_Fermi_momentum () const
  {
    return R_Fermi_momentum;
  }
  
  unsigned int get_BPmin_global () const
  {
    return BPmin_global;
  }

  unsigned int get_BPmax_global () const
  {
    return BPmax_global;
  }

  int get_Jmin_global () const
  {
    return Jmin_global;
  }

  int get_Jmax_global () const
  {
    return Jmax_global;
  }

  double get_R_cut_function () const
  {
    return R_cut_function;
  }

  double get_d_cut_function () const
  {
    return d_cut_function;
  }

  double get_theta_H_complex_scaled () const
  {
    return theta_H_complex_scaled;
  }
  
  TYPE get_exp_I_theta_H_complex_scaled () const
  {
    return exp_I_theta_H_complex_scaled;
  }

  TYPE get_exp_minus_I_theta_H_complex_scaled () const
  {
    return exp_minus_I_theta_H_complex_scaled;
  }
  
  TYPE get_exp_two_I_theta_H_complex_scaled () const
  {
    return exp_two_I_theta_H_complex_scaled;
  }
  
  TYPE get_exp_minus_two_I_theta_H_complex_scaled () const
  {
    return exp_minus_two_I_theta_H_complex_scaled;
  }
  
  unsigned int get_dimension_1p1h_space_BP_S_iM_fixed_max () const
  {    
    return dimension_1p1h_space_BP_S_iM_fixed_max;
  }

  unsigned int get_dimension_2p2h_space_BP_S_iM_fixed_max () const
  {
    return dimension_2p2h_space_BP_S_iM_fixed_max;
  }

  unsigned int get_BP_one_configuration () const
  {
    return BP_one_configuration;
  }

  unsigned int get_iC_one_configuration () const
  {
    return iC_one_configuration;
  }

  void set_dimension_configuration_total (const unsigned int dimension_configuration_total_c)
  {
    if (dimension_configuration_total_c == 0) error_message_print_abort ("dimension_configuration_total_c == 0 in baryons_data::set_dimension_configuration_total");

    if (dimension_configuration_total != 0) error_message_print_abort ("dimension_configuration_total cannot be set twice in baryons_data");

    dimension_configuration_total = dimension_configuration_total_c;
  }
  
  unsigned int get_dimension_configuration_total () const
  {
    return dimension_configuration_total;
  }
  
  void set_dimension_configuration_total_1h (const unsigned int dimension_configuration_total_1h_c)
  {
    if (dimension_configuration_total_1h_c == 0) error_message_print_abort ("dimension_configuration_total_1h_c == 0 in baryons_data::set_dimension_configuration_total_1h");

    if (dimension_configuration_total_1h != 0) error_message_print_abort ("dimension_configuration_total_1h cannot be set twice in baryons_data");

    dimension_configuration_total_1h = dimension_configuration_total_1h_c;
  }
  
  unsigned int get_dimension_configuration_total_1h () const
  {
    return dimension_configuration_total_1h;
  }
  
  void set_dimension_configuration_total_2h (const unsigned int dimension_configuration_total_2h_c)
  {
    if (dimension_configuration_total_2h_c == 0) error_message_print_abort ("dimension_configuration_total_2h_c == 0 in baryons_data::set_dimension_configuration_total_2h");

    if (dimension_configuration_total_2h != 0) error_message_print_abort ("dimension_configuration_total_2h cannot be set twice in baryons_data");

    dimension_configuration_total_2h = dimension_configuration_total_2h_c;
  }

  unsigned int get_dimension_configuration_total_2h () const
  {
    return dimension_configuration_total_2h;
  }
  
  unsigned int get_dimension_configuration_total_local (const unsigned int N_valence_baryons_local) const
  {
    if (N_valence_baryons_local == N_valence_baryons)    return dimension_configuration_total;
    if (N_valence_baryons_local == N_valence_baryons_1h) return dimension_configuration_total_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return dimension_configuration_total_2h;

    abort_all ();
    
    return NADA;
  }
  
  void set_dimension_configuration_total_local (
						const unsigned int N_valence_baryons_local ,
						const unsigned int dimension_configuration_total_local_c)
  {
    if      (N_valence_baryons_local == N_valence_baryons)    set_dimension_configuration_total    (dimension_configuration_total_local_c);
    else if (N_valence_baryons_local == N_valence_baryons_1h) set_dimension_configuration_total_1h (dimension_configuration_total_local_c);
    else if (N_valence_baryons_local == N_valence_baryons_2h) set_dimension_configuration_total_2h (dimension_configuration_total_local_c);
    else abort_all ();
  }
  
  void set_dimension_configuration_max (const unsigned int dimension_configuration_max_c)
  {
    if (dimension_configuration_max_c == 0) error_message_print_abort ("dimension_configuration_max_c == 0 in baryons_data::set_dimension_configuration_max");

    if (dimension_configuration_max != 0) error_message_print_abort ("dimension_configuration_max cannot be set twice in baryons_data");

    dimension_configuration_max = dimension_configuration_max_c;
  }  

  unsigned int get_dimension_configuration_max () const
  {
    return dimension_configuration_max;
  }
  
  void set_dimension_configuration_max_1h (const unsigned int dimension_configuration_max_1h_c)
  {
    if (dimension_configuration_max_1h_c == 0) error_message_print_abort ("dimension_configuration_max_1h_c == 0 in baryons_data::set_dimension_configuration_max_1h");

    if (dimension_configuration_max_1h != 0) error_message_print_abort ("dimension_configuration_max_1h cannot be set twice in baryons_data");

    dimension_configuration_max_1h = dimension_configuration_max_1h_c;
  }

  unsigned int get_dimension_configuration_max_1h () const
  {
    return dimension_configuration_max_1h;
  }
  
  void set_dimension_configuration_max_2h (const unsigned int dimension_configuration_max_2h_c)
  {
    if (dimension_configuration_max_2h_c == 0) error_message_print_abort ("dimension_configuration_max_2h_c == 0 in baryons_data::set_dimension_configuration_max_2h");

    if (dimension_configuration_max_2h != 0) error_message_print_abort ("dimension_configuration_max_2h cannot be set twice in baryons_data");

    dimension_configuration_max_2h = dimension_configuration_max_2h_c;
  }

  unsigned int get_dimension_configuration_max_2h () const
  {
    return dimension_configuration_max_2h;
  }
  
  unsigned int get_dimension_configuration_max_local (const unsigned int N_valence_baryons_local) const
  {
    if (N_valence_baryons_local == N_valence_baryons)    return dimension_configuration_max;
    if (N_valence_baryons_local == N_valence_baryons_1h) return dimension_configuration_max_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return dimension_configuration_max_2h;

    abort_all ();
    
    return NADA;
  }
  
  void set_dimension_configuration_max_local (
					      const unsigned int N_valence_baryons_local ,
					      const unsigned int dimension_configuration_max_local_c)
  {
    if (N_valence_baryons_local == N_valence_baryons)         set_dimension_configuration_max    (dimension_configuration_max_local_c);
    else if (N_valence_baryons_local == N_valence_baryons_1h) set_dimension_configuration_max_1h (dimension_configuration_max_local_c);
    else if (N_valence_baryons_local == N_valence_baryons_2h) set_dimension_configuration_max_2h (dimension_configuration_max_local_c);
    else abort_all ();
  }
  
  void set_dimension_SD_total (const unsigned long int dimension_SD_total_c)
  {
    if (dimension_SD_total_c == 0) error_message_print_abort ("dimension_SD_total_c == 0 in baryons_data::set_dimension_SD_total");

    if (dimension_SD_total != 0) error_message_print_abort ("dimension_SD_total cannot be set twice in baryons_data");

    dimension_SD_total = dimension_SD_total_c;
  }
  
  unsigned long int get_dimension_SD_total () const
  {
    return dimension_SD_total;
  }
  
  void set_dimension_SD_total_1h (const unsigned long int dimension_SD_total_1h_c)
  {
    if (dimension_SD_total_1h_c == 0) error_message_print_abort ("dimension_SD_total_1h_c == 0 in baryons_data::set_dimension_SD_total_1h");

    if (dimension_SD_total_1h != 0) error_message_print_abort ("dimension_SD_total_1h cannot be set twice in baryons_data");

    dimension_SD_total_1h = dimension_SD_total_1h_c;
  }
  
  unsigned long int get_dimension_SD_total_1h () const
  {
    return dimension_SD_total_1h;
  }
  
  void set_dimension_SD_total_2h (const unsigned long int dimension_SD_total_2h_c)
  {
    if (dimension_SD_total_2h_c == 0) error_message_print_abort ("dimension_SD_total_2h_c == 0 in baryons_data::set_dimension_SD_total_2h");

    if (dimension_SD_total_2h != 0) error_message_print_abort ("dimension_SD_total_2h cannot be set twice in baryons_data");

    dimension_SD_total_2h = dimension_SD_total_2h_c;
  }

  unsigned long int get_dimension_SD_total_2h () const
  {
    return dimension_SD_total_2h;
  }
  
  unsigned long int get_dimension_SD_total_local (const unsigned int N_valence_baryons_local) const
  {
    if (N_valence_baryons_local == N_valence_baryons)    return dimension_SD_total;
    if (N_valence_baryons_local == N_valence_baryons_1h) return dimension_SD_total_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return dimension_SD_total_2h;

    abort_all ();
    
    return NADA;
  }
  
  void set_dimension_SD_total_local (
				     const unsigned int N_valence_baryons_local ,
				     const unsigned long int dimension_SD_total_local_c)
  {
    if      (N_valence_baryons_local == N_valence_baryons)    set_dimension_SD_total    (dimension_SD_total_local_c);
    else if (N_valence_baryons_local == N_valence_baryons_1h) set_dimension_SD_total_1h (dimension_SD_total_local_c);
    else if (N_valence_baryons_local == N_valence_baryons_2h) set_dimension_SD_total_2h (dimension_SD_total_local_c);
    else abort_all ();
  }
  
  void set_dimension_SD_max (const unsigned int dimension_SD_max_c)
  {
    if (dimension_SD_max_c == 0) error_message_print_abort ("dimension_SD_max_c == 0 in baryons_data::set_dimension_SD_max");

    if (dimension_SD_max != 0) error_message_print_abort ("dimension_SD_max cannot be set twice in baryons_data");

    dimension_SD_max = dimension_SD_max_c;
  }  

  unsigned int get_dimension_SD_max () const
  {
    return dimension_SD_max;
  }
  
  void set_dimension_SD_max_1h (const unsigned int dimension_SD_max_1h_c)
  {
    if (dimension_SD_max_1h_c == 0) error_message_print_abort ("dimension_SD_max_1h_c == 0 in baryons_data::set_dimension_SD_max_1h");

    if (dimension_SD_max_1h != 0) error_message_print_abort ("dimension_SD_max_1h cannot be set twice in baryons_data");

    dimension_SD_max_1h = dimension_SD_max_1h_c;
  }

  unsigned int get_dimension_SD_max_1h () const
  {
    return dimension_SD_max_1h;
  }
  
  void set_dimension_SD_max_2h (const unsigned int dimension_SD_max_2h_c)
  {
    if (dimension_SD_max_2h_c == 0) error_message_print_abort ("dimension_SD_max_2h_c == 0 in baryons_data::set_dimension_SD_max_2h");

    if (dimension_SD_max_2h != 0) error_message_print_abort ("dimension_SD_max_2h cannot be set twice in baryons_data");

    dimension_SD_max_2h = dimension_SD_max_2h_c;
  }

  unsigned int get_dimension_SD_max_2h () const
  {
    return dimension_SD_max_2h;
  }
  
  unsigned int get_dimension_SD_max_local (const unsigned int N_valence_baryons_local) const
  {
    if (N_valence_baryons_local == N_valence_baryons)    return dimension_SD_max;
    if (N_valence_baryons_local == N_valence_baryons_1h) return dimension_SD_max_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return dimension_SD_max_2h;

    abort_all ();
    
    return NADA;
  }
    
  void set_dimension_SD_max_local (
				   const unsigned int N_valence_baryons_local ,
				   const unsigned int dimension_SD_max_local_c)
  {
    if      (N_valence_baryons_local == N_valence_baryons)    set_dimension_SD_max    (dimension_SD_max_local_c);
    else if (N_valence_baryons_local == N_valence_baryons_1h) set_dimension_SD_max_1h (dimension_SD_max_local_c);
    else if (N_valence_baryons_local == N_valence_baryons_2h) set_dimension_SD_max_2h (dimension_SD_max_local_c);
    else abort_all ();
  }
  
  void set_M_max_iM_max ()
  {
    M_max = m_max*N_valence_baryons;

    iM_max = make_int (2.0*M_max);

    M_max_1h = m_max*N_valence_baryons_1h;

    iM_max_1h = make_int (2.0*M_max_1h);
  
    M_max_2h = m_max*N_valence_baryons_2h;

    iM_max_2h = make_int (2.0*M_max_2h);
      
    // M_max is m_max*N_valence_baryons the maximal M for all configurations, as one wants iM[SD] = \sum_{i} im[i], with im = m + m_max.
  }
  
  class array<class lj_table<enum potential_type> > & get_basis_potential_partial_waves_tab ()
  {
    return basis_potential_partial_waves_tab;
  }

  const class array<class lj_table<enum potential_type> > & get_basis_potential_partial_waves_tab () const
  {
    return basis_potential_partial_waves_tab;
  }
  
  class array<enum particle_type> & get_baryon_types ()
  {
    return baryon_types;
  }

  const class array<enum particle_type> & get_baryon_types () const
  {
    return baryon_types;
  }

  const class array<double> & get_V0_KKNN_tab () const
  {
    return V0_KKNN_tab;
  }
  
  const class array<double> & get_rho_KKNN_tab () const
  {
    return rho_KKNN_tab;
  }

  const class array<double> & get_Vls_KKNN_tab () const
  {
    return Vls_KKNN_tab;
  }
  
  const class array<double> & get_rho_ls_KKNN_tab () const
  {
    return rho_ls_KKNN_tab;
  }

  const class array<double> & get_V0_KKNN_basis_core_potential_tab () const
  {
    return V0_KKNN_basis_core_potential_tab;
  }
  
  const class array<double> & get_rho_KKNN_basis_core_potential_tab () const
  {
    return rho_KKNN_basis_core_potential_tab;
  }

  const class array<double> & get_Vls_KKNN_basis_core_potential_tab () const
  {
    return Vls_KKNN_basis_core_potential_tab;
  }
  
  const class array<double> & get_rho_ls_KKNN_basis_core_potential_tab () const
  {
    return rho_ls_KKNN_basis_core_potential_tab;
  }

  class array<unsigned int> & get_TRS_nljm_indices ()
  {
    return TRS_nljm_indices;
  }

  const class array<unsigned int> & get_TRS_nljm_indices () const
  {
    return TRS_nljm_indices;
  }
  
  class array<unsigned int> & get_dimensions_configuration_set ()
  {
    return dimensions_configuration_set;
  }

  const class array<unsigned int> & get_dimensions_configuration_set () const
  {
    return dimensions_configuration_set;
  }

  const class array<unsigned int> & get_dimensions_configuration_set_local (const unsigned int N_valence_baryons_local) const
  {
    if (N_valence_baryons_local == N_valence_baryons)    return dimensions_configuration_set;
    if (N_valence_baryons_local == N_valence_baryons_1h) return dimensions_configuration_set_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return dimensions_configuration_set_2h;

    abort_all ();
 
    return dimensions_configuration_set;
  }
  
  class array<unsigned int> & get_dimensions_configuration_set_local (const unsigned int N_valence_baryons_local)
  {
    if (N_valence_baryons_local == N_valence_baryons)    return dimensions_configuration_set;
    if (N_valence_baryons_local == N_valence_baryons_1h) return dimensions_configuration_set_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return dimensions_configuration_set_2h;

    abort_all ();
    
    return dimensions_configuration_set;
  }

  class array<unsigned int> & get_sum_dimensions_configuration_set ()
  {
    return sum_dimensions_configuration_set;
  }

  const class array<unsigned int> & get_sum_dimensions_configuration_set () const
  {
    return sum_dimensions_configuration_set;
  }

  class array<unsigned int> & get_dimensions_configuration_set_1h ()
  {
    return dimensions_configuration_set_1h;
  }

  const class array<unsigned int> & get_dimensions_configuration_set_1h () const
  {
    return dimensions_configuration_set_1h;
  }

  class array<unsigned int> & get_sum_dimensions_configuration_set_1h ()
  {
    return sum_dimensions_configuration_set_1h;
  }

  const class array<unsigned int> & get_sum_dimensions_configuration_set_1h () const
  {
    return sum_dimensions_configuration_set_1h;
  }

  class array<unsigned int> & get_dimensions_configuration_set_2h ()
  {
    return dimensions_configuration_set_2h;
  }

  const class array<unsigned int> & get_dimensions_configuration_set_2h () const
  {
    return dimensions_configuration_set_2h;
  }

  class array<unsigned int> & get_sum_dimensions_configuration_set_2h ()
  {
    return sum_dimensions_configuration_set_2h;
  }

  const class array<unsigned int> & get_sum_dimensions_configuration_set_2h () const
  {
    return sum_dimensions_configuration_set_2h;
  }

  const class array<unsigned int> & get_sum_dimensions_configuration_set_local (const unsigned int N_valence_baryons_local) const
  {
    if (N_valence_baryons_local == N_valence_baryons)    return sum_dimensions_configuration_set;
    if (N_valence_baryons_local == N_valence_baryons_1h) return sum_dimensions_configuration_set_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return sum_dimensions_configuration_set_2h;

    abort_all ();
 
    return sum_dimensions_configuration_set;
  }

  class array<unsigned int> & get_sum_dimensions_configuration_set_local (const unsigned int N_valence_baryons_local)
  {
    if (N_valence_baryons_local == N_valence_baryons)    return sum_dimensions_configuration_set;
    if (N_valence_baryons_local == N_valence_baryons_1h) return sum_dimensions_configuration_set_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return sum_dimensions_configuration_set_2h;

    abort_all ();
    
    return sum_dimensions_configuration_set;
  }
  
  class array_of_configuration & get_configuration_set ()
  {
    return configuration_set;
  }

  const class array_of_configuration & get_configuration_set () const
  {
    return configuration_set;
  }

  class array_of_configuration & get_configuration_set_1h ()
  {
    return configuration_set_1h;
  }

  const class array_of_configuration & get_configuration_set_1h () const
  {
    return configuration_set_1h;
  }

  class array_of_configuration & get_configuration_set_2h ()
  {
    return configuration_set_2h;
  }

  const class array_of_configuration & get_configuration_set_2h () const
  {
    return configuration_set_2h;
  }

  const class array_of_configuration & get_configuration_set_local (const unsigned int N_valence_baryons_local) const
  {
    if (N_valence_baryons_local == N_valence_baryons)    return configuration_set;
    if (N_valence_baryons_local == N_valence_baryons_1h) return configuration_set_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return configuration_set_2h;

    abort_all ();
    
    return configuration_set;
  }

  class array_of_configuration & get_configuration_set_local (const unsigned int N_valence_baryons_local)
  {
    if (N_valence_baryons_local == N_valence_baryons)    return configuration_set;
    if (N_valence_baryons_local == N_valence_baryons_1h) return configuration_set_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return configuration_set_2h;

    abort_all ();
    
    return configuration_set;
  }
  
  class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_SD_set ()
  {
    return dimensions_SD_set;
  }

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_SD_set () const
  {
    return dimensions_SD_set;
  }

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_SD_set_local (const unsigned int N_valence_baryons_local) const
  {
    if (N_valence_baryons_local == N_valence_baryons)    return dimensions_SD_set;
    if (N_valence_baryons_local == N_valence_baryons_1h) return dimensions_SD_set_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return dimensions_SD_set_2h;

    abort_all ();
 
    return dimensions_SD_set;
  }

  class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_SD_set_local (const unsigned int N_valence_baryons_local)
  {
    if (N_valence_baryons_local == N_valence_baryons)    return dimensions_SD_set;
    if (N_valence_baryons_local == N_valence_baryons_1h) return dimensions_SD_set_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return dimensions_SD_set_2h;

    abort_all ();
    
    return dimensions_SD_set;
  }

  class array_BP_S_Nspec_Nscat_iC<unsigned long int> & get_sum_dimensions_SD_set ()
  {
    return sum_dimensions_SD_set;
  }

  const class array_BP_S_Nspec_Nscat_iC<unsigned long int> & get_sum_dimensions_SD_set () const
  {
    return sum_dimensions_SD_set;
  }

  class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_SD_set_1h ()
  {
    return dimensions_SD_set_1h;
  }

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_SD_set_1h () const
  {
    return dimensions_SD_set_1h;
  }

  class array_BP_S_Nspec_Nscat_iC<unsigned long int> & get_sum_dimensions_SD_set_1h ()
  {
    return sum_dimensions_SD_set_1h;
  }

  const class array_BP_S_Nspec_Nscat_iC<unsigned long int> & get_sum_dimensions_SD_set_1h () const
  {
    return sum_dimensions_SD_set_1h;
  }

  class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_SD_set_2h ()
  {
    return dimensions_SD_set_2h;
  }

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_SD_set_2h () const
  {
    return dimensions_SD_set_2h;
  }

  class array_BP_S_Nspec_Nscat_iC<unsigned long int> & get_sum_dimensions_SD_set_2h ()
  {
    return sum_dimensions_SD_set_2h;
  }

  const class array_BP_S_Nspec_Nscat_iC<unsigned long int> & get_sum_dimensions_SD_set_2h () const
  {
    return sum_dimensions_SD_set_2h;
  }

  const class array_BP_S_Nspec_Nscat_iC<unsigned long int> & get_sum_dimensions_SD_set_local (const unsigned int N_valence_baryons_local) const
  {
    if (N_valence_baryons_local == N_valence_baryons)    return sum_dimensions_SD_set;
    if (N_valence_baryons_local == N_valence_baryons_1h) return sum_dimensions_SD_set_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return sum_dimensions_SD_set_2h;

    abort_all ();
 
    return sum_dimensions_SD_set;
  }

  class array_BP_S_Nspec_Nscat_iC<unsigned long int> & get_sum_dimensions_SD_set_local (const unsigned int N_valence_baryons_local)
  {
    if (N_valence_baryons_local == N_valence_baryons)    return sum_dimensions_SD_set;
    if (N_valence_baryons_local == N_valence_baryons_1h) return sum_dimensions_SD_set_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return sum_dimensions_SD_set_2h;

    abort_all ();
    
    return sum_dimensions_SD_set;
  }

  class array_of_SD & get_SD_set ()
  {
    return SD_set;
  }

  const class array_of_SD & get_SD_set () const
  {
    return SD_set;
  }

  class array_of_SD & get_SD_set_1h ()
  {
    return SD_set_1h;
  }

  const class array_of_SD & get_SD_set_1h () const
  {
    return SD_set_1h;
  }

  class array_of_SD & get_SD_set_2h ()
  {
    return SD_set_2h;
  }

  const class array_of_SD & get_SD_set_2h () const
  {
    return SD_set_2h;
  }

  const class array_of_SD & get_SD_set_local (const unsigned int N_valence_baryons_local) const
  {
    if (N_valence_baryons_local == N_valence_baryons)    return SD_set;
    if (N_valence_baryons_local == N_valence_baryons_1h) return SD_set_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return SD_set_2h;

    abort_all ();
    
    return SD_set;
  }

  class array_of_SD & get_SD_set_local (const unsigned int N_valence_baryons_local)
  {
    if (N_valence_baryons_local == N_valence_baryons)    return SD_set;
    if (N_valence_baryons_local == N_valence_baryons_1h) return SD_set_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return SD_set_2h;

    abort_all ();
    
    return SD_set;
  }

  class array_BP_S_Nspec_Nscat_iC<int> & get_E_hw_table ()
  {
    return E_hw_table;
  }

  const class array_BP_S_Nspec_Nscat_iC<int> & get_E_hw_table () const
  {
    return E_hw_table;
  }

  class array_BP_S_Nspec_Nscat_iC<int> & get_n_holes_table ()
  {
    return n_holes_table;
  }

  const class array_BP_S_Nspec_Nscat_iC<int> & get_n_holes_table () const
  {
    return n_holes_table;
  }

  class OBMEs_CM_set_str & get_OBMEs_CM_set_HO_expansion ()
  {
    return OBMEs_CM_set_HO_expansion;
  }

  const class OBMEs_CM_set_str & get_OBMEs_CM_set_HO_expansion () const
  {
    return OBMEs_CM_set_HO_expansion;
  }

  class OBMEs_CM_set_str & get_OBMEs_CM_set_R_cut ()
  {
    return OBMEs_CM_set_R_cut;
  }

  const class OBMEs_CM_set_str & get_OBMEs_CM_set_R_cut () const
  {
    return OBMEs_CM_set_R_cut;
  }

  class OBMEs_CM_set_str & get_reduced_grad_HO_expansion_set ()
  {
    return reduced_grad_HO_expansion_set;
  }

  const class OBMEs_CM_set_str & get_reduced_grad_HO_expansion_set () const
  {
    return reduced_grad_HO_expansion_set;
  }

  class OBMEs_CM_set_str & get_reduced_r_HO_expansion_set ()
  {
    return reduced_r_HO_expansion_set;
  }

  const class OBMEs_CM_set_str & get_reduced_r_HO_expansion_set () const
  {
    return reduced_r_HO_expansion_set;
  }

  class OBMEs_CM_set_str & get_reduced_r_HO_expansion_rms_radius_different_particles_set ()
  {
    return reduced_r_HO_expansion_rms_radius_different_particles_set;
  }

  const class OBMEs_CM_set_str & get_reduced_r_HO_expansion_rms_radius_different_particles_set () const
  {
    return reduced_r_HO_expansion_rms_radius_different_particles_set;
  }

  class OBMEs_CM_set_str & get_reduced_grad_R_cut_set ()
  {
    return reduced_grad_R_cut_set;
  }

  const class OBMEs_CM_set_str & get_reduced_grad_R_cut_set () const
  {
    return reduced_grad_R_cut_set;
  }

  class OBMEs_CM_set_str & get_reduced_r_R_cut_set ()
  {
    return reduced_r_R_cut_set;
  }

  const class OBMEs_CM_set_str & get_reduced_r_R_cut_set () const
  {
    return reduced_r_R_cut_set;
  }

  class OBMEs_CM_set_str & get_reduced_r_R_cut_rms_radius_different_particles_set ()
  {
    return reduced_r_R_cut_rms_radius_different_particles_set;
  }

  const class OBMEs_CM_set_str & get_reduced_r_R_cut_rms_radius_different_particles_set () const
  {
    return reduced_r_R_cut_rms_radius_different_particles_set;
  }

  class OBMEs_multipole_square_str & get_OBMEs_multipole_square_HO_expansion ()
  {
    return OBMEs_multipole_square_HO_expansion;
  }

  const class OBMEs_multipole_square_str & get_OBMEs_multipole_square_HO_expansion () const
  {
    return OBMEs_multipole_square_HO_expansion;
  }

  class OBMEs_multipole_reduced_str & get_OBMEs_multipole_reduced_HO_expansion ()
  {
    return OBMEs_multipole_reduced_HO_expansion;
  }

  const class OBMEs_multipole_reduced_str & get_OBMEs_multipole_reduced_HO_expansion () const
  {
    return OBMEs_multipole_reduced_HO_expansion;
  }

  class OBMEs_multipole_square_str & get_OBMEs_multipole_square_R_cut ()
  {
    return OBMEs_multipole_square_R_cut;
  }

  const class OBMEs_multipole_square_str & get_OBMEs_multipole_square_R_cut () const
  {
    return OBMEs_multipole_square_R_cut;
  }


  class OBMEs_multipole_reduced_str & get_OBMEs_multipole_reduced_R_cut ()
  {
    return OBMEs_multipole_reduced_R_cut;
  }

  const class OBMEs_multipole_reduced_str & get_OBMEs_multipole_reduced_R_cut () const
  {
    return OBMEs_multipole_reduced_R_cut;
  }

  class OBMEs_inter_set_str & get_OBMEs_inter_set ()
  {
    return OBMEs_inter_set;
  }

  const class OBMEs_inter_set_str & get_OBMEs_inter_set () const
  {
    return OBMEs_inter_set;
  }
  
  class array<class lj_table<int> > & get_nmax_lj_tabs ()
  {
    return nmax_lj_tabs;
  }

  const class array<class lj_table<int> > & get_nmax_lj_tabs () const
  {
    return nmax_lj_tabs;
  }
  
  class array<class lj_table<int> > & get_nmin_lj_valence_tabs ()
  {
    return nmin_lj_valence_tabs;
  }

  const class array<class lj_table<int> > & get_nmin_lj_valence_tabs () const
  {
    return nmin_lj_valence_tabs;
  }
    
  class array<class nlj_table<unsigned int> > & get_shells_indices_tab ()
  {
    return shells_indices_tab;
  }

  const class array<class nlj_table<unsigned int> > & get_shells_indices_tab () const
  {
    return shells_indices_tab;
  }
  
  class array<class nlj_table<bool> > & get_is_it_valence_shell_tabs ()
  {
    return is_it_valence_shell_tabs;
  }

  const class array<class nlj_table<bool> > & get_is_it_valence_shell_tabs () const
  {
    return is_it_valence_shell_tabs;
  }

  class one_body_indices_str & get_one_body_indices ()
  {
    return one_body_indices;
  }

  const class one_body_indices_str & get_one_body_indices () const
  {
    return one_body_indices;
  }
 
  class array<class spherical_state > & get_shells ()
  {
    return shells;
  }

  const class array<class spherical_state > & get_shells () const
  {
    return shells;
  }

  class array<class spherical_state > & get_shells_plus ()
  {
    return shells_plus;
  }

  const class array<class spherical_state > & get_shells_plus () const
  {
    return shells_plus;
  }

  class array<class spherical_state > & get_shells_minus ()
  {
    return shells_minus;
  }

  const class array<class spherical_state > & get_shells_minus () const
  {
    return shells_minus;
  }

  class array<class nljm_struct> & get_phi_table ()
  {
    return phi_table;
  }

  const class array<class nljm_struct> & get_phi_table () const
  {
    return phi_table;
  }

  class nlj_table<complex<double> > & get_Ueq_finite_range_tab_uniform ()
  {
    return Ueq_finite_range_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_tab_uniform () const
  {
    return Ueq_finite_range_tab_uniform;
  }

  class nlj_table<complex<double> > & get_source_tab_uniform ()
  {
    return source_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_source_tab_uniform () const
  {
    return source_tab_uniform;
  }

  class nlj_table<complex<double> > & get_Ueq_finite_range_plus_tab_uniform ()
  {
    return Ueq_finite_range_plus_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_plus_tab_uniform () const
  {
    return Ueq_finite_range_plus_tab_uniform;
  }

  class nlj_table<complex<double> > & get_source_plus_tab_uniform ()
  {
    return source_plus_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_source_plus_tab_uniform () const
  {
    return source_plus_tab_uniform ;
  }

  class nlj_table<complex<double> > & get_Ueq_finite_range_minus_tab_uniform ()
  {
    return Ueq_finite_range_minus_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_Ueq_finite_range_minus_tab_uniform () const
  {
    return Ueq_finite_range_minus_tab_uniform;
  }

  class nlj_table<complex<double> > & get_source_minus_tab_uniform ()
  {
    return source_minus_tab_uniform;
  }

  const class nlj_table<complex<double> > & get_source_minus_tab_uniform () const
  {
    return source_minus_tab_uniform;
  }

  class lj_table<complex<double> > & get_OBMEs_HF_SGI_MSGI ()
  {
    return OBMEs_HF_SGI_MSGI;
  }

  const class lj_table<complex<double> > & get_OBMEs_HF_SGI_MSGI () const
  {
    return OBMEs_HF_SGI_MSGI;
  }

  class array<class nlj_table<TYPE> > & get_h_basis_tab ()
  {
    return h_basis_tab;
  }

  const class array<class nlj_table<TYPE> > & get_h_basis_tab () const
  {
    return h_basis_tab;
  }

  class TBMEs_class & get_TBMEs ()
  {
    return TBMEs;
  }

  const class TBMEs_class & get_TBMEs () const
  {
    return TBMEs;
  }

  class array<class nlj_struct> & get_shells_quantum_numbers ()
  {
    return shells_quantum_numbers;
  }

  const class array<class nlj_struct> & get_shells_quantum_numbers () const
  {
    return shells_quantum_numbers;
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_SD_TRS_indices ()
  {
    return SD_TRS_indices;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_SD_TRS_indices () const
  {
    return SD_TRS_indices;
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_SD_TRS_indices_1h ()
  {
    return SD_TRS_indices_1h;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_SD_TRS_indices_1h () const
  {
    return SD_TRS_indices_1h;
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_SD_TRS_indices_2h ()
  {
    return SD_TRS_indices_2h;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_SD_TRS_indices_2h () const
  {
    return SD_TRS_indices_2h;
  }
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_SD_TRS_indices_local (const unsigned int N_valence_baryons_local) const
  {
    if (N_valence_baryons_local == N_valence_baryons)    return SD_TRS_indices;
    if (N_valence_baryons_local == N_valence_baryons_1h) return SD_TRS_indices_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return SD_TRS_indices_2h;

    abort_all ();
 
    return SD_TRS_indices;
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_SD_TRS_indices_local (const unsigned int N_valence_baryons_local)
  {
    if (N_valence_baryons_local == N_valence_baryons)    return SD_TRS_indices;
    if (N_valence_baryons_local == N_valence_baryons_1h) return SD_TRS_indices_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return SD_TRS_indices_2h;

    abort_all ();
    
    return SD_TRS_indices;
  }
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> & get_SD_TRS_reordering_bin_phases ()
  {
    return SD_TRS_reordering_bin_phases;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> & get_SD_TRS_reordering_bin_phases () const
  {
    return SD_TRS_reordering_bin_phases;
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> & get_SD_TRS_reordering_bin_phases_1h ()
  {
    return SD_TRS_reordering_bin_phases_1h;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> & get_SD_TRS_reordering_bin_phases_1h () const
  {
    return SD_TRS_reordering_bin_phases_1h;
  }
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> & get_SD_TRS_reordering_bin_phases_2h ()
  {
    return SD_TRS_reordering_bin_phases_2h;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> & get_SD_TRS_reordering_bin_phases_2h () const
  {
    return SD_TRS_reordering_bin_phases_2h;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> & get_SD_TRS_reordering_bin_phases_local (const unsigned int N_valence_baryons_local) const
  {
    if (N_valence_baryons_local == N_valence_baryons)    return SD_TRS_reordering_bin_phases;
    if (N_valence_baryons_local == N_valence_baryons_1h) return SD_TRS_reordering_bin_phases_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return SD_TRS_reordering_bin_phases_2h;

    abort_all ();
 
    return SD_TRS_reordering_bin_phases;
  }
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> & get_SD_TRS_reordering_bin_phases_local (const unsigned int N_valence_baryons_local)
  {
    if (N_valence_baryons_local == N_valence_baryons)    return SD_TRS_reordering_bin_phases;
    if (N_valence_baryons_local == N_valence_baryons_1h) return SD_TRS_reordering_bin_phases_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return SD_TRS_reordering_bin_phases_2h;

    abort_all ();
    
    return SD_TRS_reordering_bin_phases;
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> & get_SD_TRS_bin_phases ()
  {
    return SD_TRS_bin_phases;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> & get_SD_TRS_bin_phases () const
  {
    return SD_TRS_bin_phases;
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> & get_SD_TRS_bin_phases_1h ()
  {
    return SD_TRS_bin_phases_1h;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> & get_SD_TRS_bin_phases_1h () const
  {
    return SD_TRS_bin_phases_1h;
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> & get_SD_TRS_bin_phases_2h ()
  {
    return SD_TRS_bin_phases_2h;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> & get_SD_TRS_bin_phases_2h () const
  {
    return SD_TRS_bin_phases_2h;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> & get_SD_TRS_bin_phases_local (const unsigned int N_valence_baryons_local) const
  {
    if (N_valence_baryons_local == N_valence_baryons)    return SD_TRS_bin_phases;
    if (N_valence_baryons_local == N_valence_baryons_1h) return SD_TRS_bin_phases_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return SD_TRS_bin_phases_2h;

    abort_all ();
 
    return SD_TRS_bin_phases;
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> & get_SD_TRS_bin_phases_local (const unsigned int N_valence_baryons_local)
  {
    if (N_valence_baryons_local == N_valence_baryons)    return SD_TRS_bin_phases;
    if (N_valence_baryons_local == N_valence_baryons_1h) return SD_TRS_bin_phases_1h;
    if (N_valence_baryons_local == N_valence_baryons_2h) return SD_TRS_bin_phases_2h;

    abort_all ();
    
    return SD_TRS_bin_phases;
  }
  
  class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_configuration_one_jump_table_in_to_out ()
  {
    return dimensions_configuration_one_jump_table_in_to_out;
  }

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_configuration_one_jump_table_in_to_out () const
  {
    return dimensions_configuration_one_jump_table_in_to_out;
  }
  
  class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_configuration_one_jump_table_out_to_in ()
  {
    return dimensions_configuration_one_jump_table_out_to_in;
  }

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_configuration_one_jump_table_out_to_in () const
  {
    return dimensions_configuration_one_jump_table_out_to_in;
  }

  class array_of_configuration_one_jump_data_in_to_out & get_configuration_one_jump_table_in_to_out ()
  {
    return configuration_one_jump_table_in_to_out;
  }

  const class array_of_configuration_one_jump_data_in_to_out & get_configuration_one_jump_table_in_to_out () const
  {
    return configuration_one_jump_table_in_to_out;
  }
  
  class array_of_configuration_one_jump_data_out_to_in & get_configuration_one_jump_table_out_to_in ()
  {
    return configuration_one_jump_table_out_to_in;
  }

  const class array_of_configuration_one_jump_data_out_to_in & get_configuration_one_jump_table_out_to_in () const
  {
    return configuration_one_jump_table_out_to_in;
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_dimensions_SD_one_jump_table_in_to_out ()
  {
    return dimensions_SD_one_jump_table_in_to_out;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_dimensions_SD_one_jump_table_in_to_out () const
  {
    return dimensions_SD_one_jump_table_in_to_out;
  }
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_dimensions_SD_one_jump_table_out_to_in ()
  {
    return dimensions_SD_one_jump_table_out_to_in;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_dimensions_SD_one_jump_table_out_to_in () const
  {
    return dimensions_SD_one_jump_table_out_to_in;
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_dimensions_SD_one_jump_table_Jpm_in_to_out ()
  {
    return dimensions_SD_one_jump_table_Jpm_in_to_out;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_dimensions_SD_one_jump_table_Jpm_in_to_out () const
  {
    return dimensions_SD_one_jump_table_Jpm_in_to_out;
  }
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_dimensions_SD_one_jump_table_Jpm_out_to_in ()
  {
    return dimensions_SD_one_jump_table_Jpm_out_to_in;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_dimensions_SD_one_jump_table_Jpm_out_to_in () const
  {
    return dimensions_SD_one_jump_table_Jpm_out_to_in;
  }

  class array_of_SD_one_jump_data_in_to_out & get_SD_one_jump_table_in_to_out ()
  {
    return SD_one_jump_table_in_to_out;
  }

  const class array_of_SD_one_jump_data_in_to_out & get_SD_one_jump_table_in_to_out () const
  {
    return SD_one_jump_table_in_to_out;
  }
  
  class array_of_SD_one_jump_data_out_to_in & get_SD_one_jump_table_out_to_in ()
  {
    return SD_one_jump_table_out_to_in;
  }

  const class array_of_SD_one_jump_data_out_to_in & get_SD_one_jump_table_out_to_in () const
  {
    return SD_one_jump_table_out_to_in;
  }

  class array_of_SD_one_jump_data_Jpm_in_to_out & get_SD_one_jump_table_Jpm_in_to_out ()
  {
    return SD_one_jump_table_Jpm_in_to_out;
  }

  const class array_of_SD_one_jump_data_Jpm_in_to_out & get_SD_one_jump_table_Jpm_in_to_out () const
  {
    return SD_one_jump_table_Jpm_in_to_out;
  }

  class array_of_SD_one_jump_data_Jpm_out_to_in & get_SD_one_jump_table_Jpm_out_to_in ()
  {
    return SD_one_jump_table_Jpm_out_to_in;
  }

  const class array_of_SD_one_jump_data_Jpm_out_to_in & get_SD_one_jump_table_Jpm_out_to_in () const
  {
    return SD_one_jump_table_Jpm_out_to_in;
  }

  class array_BP_S_Nspec_Nscat_iC<bool> & get_are_configurations_inter_occupied_in_space_1ph_tables (const unsigned int occupied_squares_index)
  {
    return are_configurations_inter_occupied_in_space_1ph_tables[occupied_squares_index];
  }

  const class array_BP_S_Nspec_Nscat_iC<bool> & get_are_configurations_inter_occupied_in_space_1ph_tables (const unsigned int occupied_squares_index) const
  {
    return are_configurations_inter_occupied_in_space_1ph_tables[occupied_squares_index];
  }

  class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_configuration_1p_table (const unsigned int occupied_squares_index)
  {
    return dimensions_configuration_1p_tables[occupied_squares_index];
  }

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_configuration_1p_table (const unsigned int occupied_squares_index) const
  {
    return dimensions_configuration_1p_tables[occupied_squares_index];
  }

  class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_configuration_1h_table (const unsigned int occupied_squares_index)
  {
    return dimensions_configuration_1h_tables[occupied_squares_index];
  }

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_configuration_1h_table (const unsigned int occupied_squares_index) const
  {
    return dimensions_configuration_1h_tables[occupied_squares_index];
  }

  class array_BP_S_Nspec_Nscat_iC<bool> & get_are_configurations_inter_occupied_in_space_2ph_tables (const unsigned int occupied_squares_index)
  {
    return are_configurations_inter_occupied_in_space_2ph_tables[occupied_squares_index];
  }

  const class array_BP_S_Nspec_Nscat_iC<bool> & get_are_configurations_inter_occupied_in_space_2ph_tables (const unsigned int occupied_squares_index) const
  {
    return are_configurations_inter_occupied_in_space_2ph_tables[occupied_squares_index];
  }

  class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_configuration_2p_table (const unsigned int occupied_squares_index)
  {
    return dimensions_configuration_2p_tables[occupied_squares_index];
  }

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_configuration_2p_table (const unsigned int occupied_squares_index) const
  {
    return dimensions_configuration_2p_tables[occupied_squares_index];
  }

  class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_configuration_2h_table (const unsigned int occupied_squares_index)
  {
    return dimensions_configuration_2h_tables[occupied_squares_index];
  }

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> & get_dimensions_configuration_2h_table (const unsigned int occupied_squares_index) const
  {
    return dimensions_configuration_2h_tables[occupied_squares_index];
  }
  
  class array_of_configuration_1ph_data & get_configuration_1p_table (const unsigned int occupied_squares_index)
  {
    return configuration_1p_tables[occupied_squares_index];
  }

  const class array_of_configuration_1ph_data & get_configuration_1p_table (const unsigned int occupied_squares_index) const
  {
    return configuration_1p_tables[occupied_squares_index];
  }

  class array_of_configuration_1ph_data & get_configuration_1h_table (const unsigned int occupied_squares_index)
  {
    return configuration_1h_tables[occupied_squares_index];
  }

  const class array_of_configuration_1ph_data & get_configuration_1h_table (const unsigned int occupied_squares_index) const
  {
    return configuration_1h_tables[occupied_squares_index];
  }

  class array_of_configuration_2ph_data & get_configuration_2p_table (const unsigned int occupied_squares_index)
  {
    return configuration_2p_tables[occupied_squares_index];
  }

  const class array_of_configuration_2ph_data & get_configuration_2p_table (const unsigned int occupied_squares_index) const
  {
    return configuration_2p_tables[occupied_squares_index];
  }

  class array_of_configuration_2ph_data & get_configuration_2h_table (const unsigned int occupied_squares_index)
  {
    return configuration_2h_tables[occupied_squares_index];
  }

  const class array_of_configuration_2ph_data & get_configuration_2h_table (const unsigned int occupied_squares_index) const
  {
    return configuration_2h_tables[occupied_squares_index];
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_dimensions_SD_1p_table (const unsigned int occupied_squares_index)
  {
    return dimensions_SD_1p_tables[occupied_squares_index];
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_dimensions_SD_1p_table (const unsigned int occupied_squares_index) const
  {
    return dimensions_SD_1p_tables[occupied_squares_index];
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_dimensions_SD_1h_table (const unsigned int occupied_squares_index)
  {
    return dimensions_SD_1h_tables[occupied_squares_index];
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_dimensions_SD_1h_table (const unsigned int occupied_squares_index) const
  {
    return dimensions_SD_1h_tables[occupied_squares_index];
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_dimensions_SD_2p_table (const unsigned int occupied_squares_index)
  {
    return dimensions_SD_2p_tables[occupied_squares_index];
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_dimensions_SD_2p_table (const unsigned int occupied_squares_index) const
  {
    return dimensions_SD_2p_tables[occupied_squares_index];
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_dimensions_SD_2h_table (const unsigned int occupied_squares_index)
  {
    return dimensions_SD_2h_tables[occupied_squares_index];
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_dimensions_SD_2h_table (const unsigned int occupied_squares_index) const
  {
    return dimensions_SD_2h_tables[occupied_squares_index];
  }
  
  class array_of_SD_1ph_data & get_SD_1p_table (const unsigned int occupied_squares_index)
  {
    return SD_1p_tables[occupied_squares_index];
  }

  const class array_of_SD_1ph_data & get_SD_1p_table (const unsigned int occupied_squares_index) const
  {
    return SD_1p_tables[occupied_squares_index];
  }

  class array_of_SD_1ph_data & get_SD_1h_table (const unsigned int occupied_squares_index)
  {
    return SD_1h_tables[occupied_squares_index];
  }

  const class array_of_SD_1ph_data & get_SD_1h_table (const unsigned int occupied_squares_index) const
  {
    return SD_1h_tables[occupied_squares_index];
  }

  class array_of_SD_2ph_data & get_SD_2p_table (const unsigned int occupied_squares_index)
  {
    return SD_2p_tables[occupied_squares_index];
  }

  const class array_of_SD_2ph_data & get_SD_2p_table (const unsigned int occupied_squares_index) const
  {
    return SD_2p_tables[occupied_squares_index];
  }

  class array_of_SD_2ph_data & get_SD_2h_table (const unsigned int occupied_squares_index)
  {
    return SD_2h_tables[occupied_squares_index];
  }

  const class array_of_SD_2ph_data & get_SD_2h_table (const unsigned int occupied_squares_index) const
  {
    return SD_2h_tables[occupied_squares_index];
  }

  class lj_table<class matrix<complex<double> > > & get_U_finite_range_HF_HO_basis_HO_expansion_part ()
  {
    return U_finite_range_HF_HO_basis_HO_expansion_part;
  }

  const class lj_table<class matrix<complex<double> > > & get_U_finite_range_HF_HO_basis_HO_expansion_part () const
  {
    return U_finite_range_HF_HO_basis_HO_expansion_part;
  }

  class array<class vector_class<complex<double> > > & get_HO_overlaps_basis ()
  {
    return HO_overlaps_basis;
  }

  const class array<class vector_class<complex<double> > > & get_HO_overlaps_basis () const
  {
    return HO_overlaps_basis;
  }

  class array<class vector_class<complex<double> > > & get_HO_overlaps_basis_Fermi ()
  {
    return HO_overlaps_basis_Fermi;
  }

  const class array<class vector_class<complex<double> > > & get_HO_overlaps_basis_Fermi () const
  {
    return HO_overlaps_basis_Fermi;
  }

  class array<class vector_class<complex<double> > > & get_HO_overlaps ()
  {
    return HO_overlaps;
  }

  const class array<class vector_class<complex<double> > > & get_HO_overlaps () const
  {
    return HO_overlaps;
  }

  class array<class vector_class<complex<double> > > & get_HO_overlaps_Fermi ()
  {
    return HO_overlaps_Fermi;
  }

  const class array<class vector_class<complex<double> > > & get_HO_overlaps_Fermi () const
  {
    return HO_overlaps_Fermi;
  }

  class array<class vector_class<complex<double> > > & get_GHF_overlaps ()
  {
    return GHF_overlaps;
  }

  const class array<class vector_class<complex<double> > > & get_GHF_overlaps () const
  {
    return GHF_overlaps;
  }

  class array<double> & get_d_core_potential_tab ()
  {
    return d_core_potential_tab;
  }

  const class array<double> & get_d_core_potential_tab () const
  {
    return d_core_potential_tab;
  }

  class array<double> & get_R0_core_potential_tab ()
  {
    return R0_core_potential_tab;
  }

  const class array<double> & get_R0_core_potential_tab () const
  {
    return R0_core_potential_tab;
  }

  class array<double> & get_Vo_core_potential_tab ()
  {
    return Vo_core_potential_tab;
  }

  const class array<double> & get_Vo_core_potential_tab () const
  {
    return Vo_core_potential_tab;
  }

  class array<double> & get_Vso_core_potential_tab ()
  {
    return Vso_core_potential_tab;
  }

  const class array<double> & get_Vso_core_potential_tab () const
  {
    return Vso_core_potential_tab;
  }

  class array<double> & get_d_basis_core_potential_tab ()
  {
    return d_basis_core_potential_tab;
  }

  const class array<double> & get_d_basis_core_potential_tab () const
  {
    return d_basis_core_potential_tab;
  }

  class array<double> & get_R0_basis_core_potential_tab ()
  {
    return R0_basis_core_potential_tab;
  }

  const class array<double> & get_R0_basis_core_potential_tab () const
  {
    return R0_basis_core_potential_tab;
  }

  class array<double> & get_Vo_basis_core_potential_tab ()
  {
    return Vo_basis_core_potential_tab;
  }

  const class array<double> & get_Vo_basis_core_potential_tab () const
  {
    return Vo_basis_core_potential_tab;
  }

  class array<double> & get_Vso_basis_core_potential_tab ()
  {
    return Vso_basis_core_potential_tab;
  }

  const class array<double> & get_Vso_basis_core_potential_tab () const
  {
    return Vso_basis_core_potential_tab;
  }

  class array<double> & get_d_basis_tab ()
  {
    return d_basis_tab;
  }

  const class array<double> & get_d_basis_tab () const
  {
    return d_basis_tab;
  }

  class array<double> & get_R0_basis_tab ()
  {
    return R0_basis_tab;
  }

  const class array<double> & get_R0_basis_tab () const
  {
    return R0_basis_tab;
  }

  class array<double> & get_Vo_basis_tab ()
  {
    return Vo_basis_tab;
  }

  const class array<double> & get_Vo_basis_tab () const
  {
    return Vo_basis_tab;
  }

  class array<double> & get_Vso_basis_tab ()
  {
    return Vso_basis_tab;
  }

  const class array<double> & get_Vso_basis_tab () const
  {
    return Vso_basis_tab;
  }

  const class array<double> & get_Im_Vo_core_potential_tab () const
  {
    return Im_Vo_core_potential_tab;
  }
  
  const class array<double> & get_Im_Vso_core_potential_tab () const
  {
    return Im_Vso_core_potential_tab;
  }
  
  const class array<double> & get_Im_Vsurf_core_potential_tab () const
  {
    return Im_Vsurf_core_potential_tab;
  }

  const class array<double> & get_Im_Vo_basis_core_potential_tab () const
  {
    return Im_Vo_basis_core_potential_tab;
  }
  
  const class array<double> & get_Im_Vso_basis_core_potential_tab () const
  {
    return Im_Vso_basis_core_potential_tab;
  }
  
  const class array<double> & get_Im_Vsurf_basis_core_potential_tab () const
  {
    return Im_Vsurf_basis_core_potential_tab;
  }

  const class array<double> & get_Im_Vo_basis_tab () const
  {
    return Im_Vo_basis_tab;
  }
  
  const class array<double> & get_Im_Vso_basis_tab () const
  {
    return Im_Vso_basis_tab;
  }
  
  const class array<double> & get_Im_Vsurf_basis_tab () const
  {
    return Im_Vsurf_basis_tab;
  }

  class array<class lj_table<double> > & get_b_partial_waves_tab ()
  {
    return b_partial_waves_tab;
  }

  const class array<class lj_table<double> > & get_b_partial_waves_tab () const
  {
    return b_partial_waves_tab;
  }

  class lj_table<class correlated_state_str> & get_basis_PSI_quantum_numbers_tab ()
  {
    return basis_PSI_quantum_numbers_tab;
  }

  const class lj_table<class correlated_state_str> & get_basis_PSI_quantum_numbers_tab () const
  {
    return basis_PSI_quantum_numbers_tab;
  }

  class array<bool> & get_BPin_Sin_Nspec_in_for_one_jump_tab ()
  {
    return BPin_Sin_Nspec_in_for_one_jump_tab;
  }

  const class array<bool> & get_BPin_Sin_Nspec_in_for_one_jump_tab () const
  {
    return BPin_Sin_Nspec_in_for_one_jump_tab;
  }
  
  class array<bool> & get_BPout_Sout_Nspec_out_for_one_jump_tab ()
  {
    return BPout_Sout_Nspec_out_for_one_jump_tab;
  }

  const class array<bool> & get_BPout_Sout_Nspec_out_for_one_jump_tab () const
  {
    return BPout_Sout_Nspec_out_for_one_jump_tab;
  }

  class array_BP_S_Nspec_Nscat_iC<bool> & get_is_configuration_in_in_space_tab (const unsigned int occupied_squares_index)
  {
    return is_configuration_in_in_space_tabs[occupied_squares_index];
  }

  const class array_BP_S_Nspec_Nscat_iC<bool> & get_is_configuration_in_in_space_tab (const unsigned int occupied_squares_index) const
  {
    return is_configuration_in_in_space_tabs[occupied_squares_index];
  }
  
  class array_BP_S_Nspec_Nscat_iC<bool> & get_is_configuration_out_in_space_tab ()
  {
    return is_configuration_out_in_space_tab;
  }

  const class array_BP_S_Nspec_Nscat_iC<bool> & get_is_configuration_out_in_space_tab () const
  {
    return is_configuration_out_in_space_tab;
  }

  class array_BP_S_Nspec_Nscat_iC<bool> & get_is_it_configuration_inter_to_include_tab ()
  {
    return is_it_configuration_inter_to_include_tab;
  }

  const class array_BP_S_Nspec_Nscat_iC<bool> & get_is_it_configuration_inter_to_include_tab () const
  {
    return is_it_configuration_inter_to_include_tab;
  }

  class array<bool> & get_BPin_Sin_Nspec_in_iMin_for_one_jump_tab ()
  {
    return BPin_Sin_Nspec_in_iMin_for_one_jump_tab;
  }

  const class array<bool> & get_BPin_Sin_Nspec_in_iMin_for_one_jump_tab () const
  {
    return BPin_Sin_Nspec_in_iMin_for_one_jump_tab;
  }

  class array<bool> & get_BPout_Sout_Nspec_out_iMout_for_one_jump_tab ()
  {
    return BPout_Sout_Nspec_out_iMout_for_one_jump_tab;
  }

  const class array<bool> & get_BPout_Sout_Nspec_out_iMout_for_one_jump_tab () const
  {
    return BPout_Sout_Nspec_out_iMout_for_one_jump_tab;
  }

  class array<unsigned int> & get_iC_in_min_tab (const unsigned int occupied_squares_index)
  {
    return iC_in_min_tab[occupied_squares_index];
  }

  const class array<unsigned int> & get_iC_in_min_tab (const unsigned int occupied_squares_index) const
  {
    return iC_in_min_tab[occupied_squares_index];
  }
  
  class array<unsigned int> & get_iC_in_max_tab (const unsigned int occupied_squares_index)
  {
    return iC_in_max_tab[occupied_squares_index];
  }

  const class array<unsigned int> & get_iC_in_max_tab (const unsigned int occupied_squares_index) const
  {
    return iC_in_max_tab[occupied_squares_index];
  }

  class array<unsigned int> & get_iC_out_min_tab ()
  {
    return iC_out_min_tab;
  }

  const class array<unsigned int> & get_iC_out_min_tab () const
  {
    return iC_out_min_tab;
  }

  class array<unsigned int> & get_iC_out_max_tab ()
  {
    return iC_out_max_tab;
  }

  const class array<unsigned int> & get_iC_out_max_tab () const
  {
    return iC_out_max_tab;
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> & get_is_inSD_in_space_tab_Jpm ()
  {
    return is_inSD_in_space_tab_Jpm;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> & get_is_inSD_in_space_tab_Jpm () const
  {
    return is_inSD_in_space_tab_Jpm;
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> & get_is_inSD_in_space_tab (const unsigned int occupied_squares_index)
  {
    return is_inSD_in_space_tabs[occupied_squares_index];
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> & get_is_inSD_in_space_tab (const unsigned int occupied_squares_index) const
  {
    return is_inSD_in_space_tabs[occupied_squares_index];
  }
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> & get_is_outSD_in_space_tab ()
  {
    return is_outSD_in_space_tab;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> & get_is_outSD_in_space_tab () const
  {
    return is_outSD_in_space_tab;
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> & get_is_it_SD_inter_to_include_tab ()
  {
    return is_it_SD_inter_to_include_tab;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> & get_is_it_SD_inter_to_include_tab () const
  {
    return is_it_SD_inter_to_include_tab;
  }
  
  class array<unsigned int> & get_initial_to_nljm_ordered_states ()
  {
    return initial_to_nljm_ordered_states;
  }

  const class array<unsigned int> & get_initial_to_nljm_ordered_states () const
  {
    return initial_to_nljm_ordered_states;
  }

  class array<unsigned int> & get_nljm_ordered_to_initial_states ()
  {
    return nljm_ordered_to_initial_states;
  }

  const class array<unsigned int> & get_nljm_ordered_to_initial_states () const
  {
    return nljm_ordered_to_initial_states;
  }

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_dimensions_SD_HO_Berggren_overlaps_table ()
  {
    return dimensions_SD_HO_Berggren_overlaps_table;
  }

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> & get_dimensions_SD_HO_Berggren_overlaps_table () const
  {
    return dimensions_SD_HO_Berggren_overlaps_table;
  }

  class array_of_SD_HO_Berggren_overlaps_data_str & get_SD_HO_Berggren_overlaps_table ()
  {
    return SD_HO_Berggren_overlaps_table;
  }

  const class array_of_SD_HO_Berggren_overlaps_data_str & get_SD_HO_Berggren_overlaps_table () const
  {
    return SD_HO_Berggren_overlaps_table;
  }

  class array<class lj_table<class matrix<TYPE> > > & get_scalar_density_matrices_tab ()
  {
    return scalar_density_matrices_tab;
  }

  const class array<class lj_table<class matrix<TYPE> > > & get_scalar_density_matrices_tab () const
  {
    return scalar_density_matrices_tab;
  }

  class array<class lj_table<class matrix<TYPE> > > & get_natural_orbitals_matrices_tab ()
  {
    return natural_orbitals_matrices_tab;
  }

  const class array<class lj_table<class matrix<TYPE> > > & get_natural_orbitals_matrices_tab () const
  {
    return natural_orbitals_matrices_tab;
  }

  class array<class lj_table<class matrix<TYPE> > > & get_ESPEs_Hamiltonian_matrices_tab ()
  {
    return ESPEs_Hamiltonian_matrices_tab;
  }

  const class array<class lj_table<class matrix<TYPE> > > & get_ESPEs_Hamiltonian_matrices_tab () const
  {
    return ESPEs_Hamiltonian_matrices_tab;
  }

  class array<class lj_table<class matrix<TYPE> > > & get_ESPEs_Hamiltonian_orbitals_matrices_tab ()
  {
    return ESPEs_Hamiltonian_orbitals_matrices_tab;
  }

  const class array<class lj_table<class matrix<TYPE> > > & get_ESPEs_Hamiltonian_orbitals_matrices_tab () const
  {
    return ESPEs_Hamiltonian_orbitals_matrices_tab;
  }

  class array<class correlated_state_str> & get_natural_orbitals_reference_states ()
  {
    return natural_orbitals_reference_states;
  }

  const class array<class correlated_state_str> & get_natural_orbitals_reference_states () const
  {
    return natural_orbitals_reference_states;
  }

  class array<class SD_quantum_numbers> & get_SD_quantum_numbers_tab ()
  {
    return SD_quantum_numbers_tab;
  }

  const class array<class SD_quantum_numbers> & get_SD_quantum_numbers_tab () const
  {
    return SD_quantum_numbers_tab;
  }

  class array<double> & get_effective_charges ()
  {
    return effective_charges;
  }
  
  const class array<double> & get_effective_charges () const
  {
    return effective_charges;
  }
  
  class array<double> & get_effective_masses_for_calc ()
  {
    return effective_masses_for_calc;
  }
  
  const class array<double> & get_effective_masses_for_calc () const
  {
    return effective_masses_for_calc;
  }
  
  const class array<bool> & get_are_there_basis_natural_orbitals_tab () const
  {
    return are_there_basis_natural_orbitals_tab;
  }
  
  const class array<bool> & get_are_there_new_natural_orbitals_tab () const
  {
    return are_there_new_natural_orbitals_tab;
  }

  bool is_it_filled () const
  {
    return (nucleonic_particle != NO_PARTICLE);
  }
  
  void initialize_constants (
			     const bool is_it_M_scheme_input , 
			     const enum particle_type nucleonic_particle_input , 
			     const class input_data_str &input_data);

  void alloc_fill_one_body_data_tables_E_min_max_hw (const class input_data_str &input_data);

  void dimensions_1p1h_2p2h_space_BP_S_iM_fixed_max_calc_print (const bool is_there_cout);

  void fill_nljm_nlj_one_body_indices_baryons_alloc_calc ();;

  void fill_nlj_one_body_indices_two_nucleon_ST_clusters_alloc_calc ();
    
  void HO_overlaps_alloc_calc (
			       const bool is_it_only_basis ,
			       const class input_data_str &input_data);
  
  void HO_overlaps_alloc_calc_H_complex_scaled (const class input_data_str &input_data);
  
  void all_HO_GHF_overlaps_alloc_calc (const class input_data_str &input_data);
 
  void GHF_overlaps_alloc_fill (const class input_data_str &input_data);
  
  void OBMEs_inter_set_alloc_read_disk (const enum interaction_type inter);
    
  void OBMEs_CM_set_alloc_read_disk (const bool is_it_HO_expansion);
        
  void natural_orbitals_OBMEs_basis_store (const class interaction_class &inter_data) const;

  void new_basis_calc_store (const class array<class lj_table<class matrix<TYPE> > > &new_basis_change_matrices) const;
    
  void OBMEs_inter_set_new_basis_calc_store (
					     const enum interaction_type inter ,
					     const class matrix<TYPE> &new_basis_change_matrix_all_lj) const;

  void OBMEs_CM_set_new_basis_calc_store (
					  const bool is_it_HO_expansion , 
					  const class matrix<TYPE> &new_basis_change_matrix_all_lj) const;
 
  void OBMEs_inter_CM_sets_new_basis_calc_store (
						 const enum interaction_type inter ,
						 const class array<class lj_table<class matrix<TYPE> > > &new_basis_change_matrices) const;
    
  void alloc_fill_one_body_data_tables_E_min_max_hw_HO_expansion (const class input_data_str &input_data);

  void shells_quantum_numbers_k_fill_from_h ();

  void initialize_constants_from_other_nucleus (
						const bool is_core_suppressed , 
						const int Z_new_nucleus , 
						const int N_new_nucleus , 
						const int Y_new_nucleus , 
						const double nucleus_mass_new_nucleus , 
						const double total_nucleus_mass_new_nucleus , 
						const class baryons_data &data_other_nucleus);

  void alloc_copy_one_body_data_tables_E_min_max_hw (const class baryons_data &data_other_nucleus);

  void optimized_partial_waves_data_alloc_fill (const class input_data_str &input_data);

  void HF_potentials_quantum_numbers_OBMEs_write (
						  const enum interaction_type TBME_inter , 
						  const class HF_nucleons_data &HF_data);
  
  void data_MSDHF_one_configuration_one_body_alloc_fill (
							 const class input_data_str &input_data , 
							 const class interaction_class &inter_data ,
							 const class baryons_data &data ,  
							 const class HF_nucleons_data &HF_data);

  void set_BP_iC_one_configuration (const unsigned int BP , const unsigned int iC);
  
  void is_it_OCM_HO_core_determine_test ();

  void is_it_OCM_HO_core_impose_pp_nn (
				       const class input_data_str &input_data ,
				       const class baryons_data &other_data);
  
  void set_N_nlj_baryon_N_nlj_res_baryon_shells_quantum_numbers_realloc_fill (
									      const unsigned int N_nlj_res_baryon_c ,
									      const unsigned int N_nlj_baryon_c ,
									      const class array<class nlj_struct> &shells_quantum_numbers_c);

  void inSD_in_space_tab_Jpm_init (const bool init_bool);
  
  void configuration_SD_in_in_space_BPin_Sin_Nspec_in_iMin_tables_init (const bool init_bool);
  
  void configuration_SD_in_in_space_iC_min_max_tables_init (
							    const unsigned int occupied_squares_index ,
							    const bool init_bool);

  void configuration_SD_inter_to_include_tables_init (const bool init_bool);
  
  void configuration_SD_out_in_space_BPout_Sout_Nspec_out_iMout_tables_init (const bool init_bool);
  
  void configuration_SD_out_in_space_iC_min_max_tables_init (const bool init_bool);

  void complex_Hamiltonian_to_real_Hamiltonian ();
  
  friend double used_memory_calc (const class baryons_data &T);
  
private:
  
  bool is_it_M_scheme;                                     // true if one considers a many-body code using M-scheme, false if if considers a two-body code, using J-scheme
  bool is_Coulomb_Hamiltonian_here;                        // true if one includes the Coulomb part of the Hamiltonian, false if not
  bool are_there_basis_natural_orbitals;                   // true if one has natural orbitals in the one-body basis, false if not
  bool are_there_new_natural_orbitals;                     // true if one calculates natural orbitals for the one-body basis of a future calculation, false if not

  bool is_Hamiltonian_complex_scaled;                      // true if one uses complex-scaled Hamiltonian, false if not
  
  enum particle_type nucleonic_particle;                   // proton, neutron, or diproton/dineutron/deuteron in the two-body relative code.
                                                           // It also serves as a label for hyperons (if any), as the data of charged/uncharged hyperons are stored in the proton/neutron class.

  int hypernucleus_strangeness;                            // strangeness of the considered hypernucleus                          
  int n_spec_max;                                          // maximal number of spectator pairs in the considered hypernucleus (see enum_struct_definitions.h)
  
  int nmax;                                                // maximal principal quantum number of protons, neutrons (plus a few hyperons if any), or of relative states for diproton/dineutron/deuteron states in relative coordinates
  int lmax;                                                // maximal orbital angular momentum of protons, neutrons (plus a few hyperons if any), or of relative states for diproton/dineutron/deuteron states in relative coordinates

  int n_scat_max;                                          // maximal number of charged/uncharged baryons in the continuum
  
  int n_holes_max;                                         // maximal number of proton or neutron holes in core states at full space level
  int n_holes_max_pole_approximation;                      // maximal number of proton or neutron holes in core states at pole approximation level

  int E_min_hw;                                            // minimal truncation energy of proton/neutron (plus a few hyperons if any) configurations                       : it is                                        E_hw(g.s. configuration)
  int E_max_hw;                                            // maximal truncation energy of proton/neutron (plus a few hyperons if any) configurations in full space         : it is E_relative_max_hw                    + E_hw(g.s. configuration)
  int E_max_hw_pole_approximation;                         // maximal truncation energy of proton/neutron (plus a few hyperons if any) configurations in pole approximation : it is E_relative_max_hw_pole_approximation + E_hw(g.s. configuration)
                                                           // g.s. configuration is the ground state configuration containing only charged/uncharged baryons
  
  int A_core;                                              // number of nucleons of the core
  int Z_core;                                              // number of protons  of the core 
  int N_core;                                              // number of neutrons of the core 
  
  int A;                                                   // number of baryons of the (hyper)nucleus used for Hamiltonian diagonalization
  int Z;                                                   // number of protons  of the (hyper)nucleus used for Hamiltonian diagonalization
  int N;                                                   // number of neutrons of the (hyper)nucleus used for Hamiltonian diagonalization
  
  int A_basis;                                             // number of baryons of the (hyper)nucleus used for the calculation of basis-generating potentials such as HF/MSDHF
  int Z_basis;                                             // number of protons  of the (hyper)nucleus used for the calculation of basis-generating potentials such as HF/MSDHF
  int N_basis;                                             // number of neutrons of the (hyper)nucleus used for the calculation of basis-generating potentials such as HF/MSDHF
  
  int hole_states_number;                                  // number of proton or neutron active holes in the core 

  unsigned int N_nucleons;                                 // number of protons/neutrons (no hyperons)
 
  unsigned int N_valence_nucleons;                         // number of valence protons/neutrons of the (hyper)nucleus (no hyperons)
  
  unsigned int N_valence_nucleons_basis;                   // number of valence protons/neutrons of the nucleus only considered to generate the basis potential (such as HF/MSDHF)
   
  unsigned int N_valence_baryons;                          // number of valence charged/uncharged baryons the nucleus
  unsigned int N_valence_baryons_1h;                       // number of valence charged/uncharged baryons minus one proton  or neutron  (or hyperon if any) (one hole)
  unsigned int N_valence_baryons_2h;                       // number of valence charged/uncharged baryons minus two charged/uncharged baryons (or hyperon if any) (two holes)
  
  int ZY_charge_pos;                                       // charge of the Coulomb potential of the Hamiltonian in absolute value felt by a positively charged baryon. It is  Z - 1.
  int ZY_charge_neg;                                       // charge of the Coulomb potential of the Hamiltonian in absolute value felt by a negatively charged baryon. It is  Z + 1.

  int ZY_charge_basis_potential_pos;                       // charge of the Coulomb potential of the basis-generating potential in absolute value felt by a positively charged baryon. It is Z[basis] - 1 or 0 if one uses good isospin basis potential.
  int ZY_charge_basis_potential_neg;                       // charge of the Coulomb potential of the basis-generating potential in absolute value felt by a negatively charged baryon. It is Z[basis] + 1 or 0 if one uses good isospin basis potential.
    
  double nucleus_mass;                                     // mass of the core nucleus if COSM is used, mass of the considered nucleus if not, used for Hamiltonian diagonalization
  double nucleus_mass_basis;                               // mass of the core nucleus if COSM is used, mass of the considered nucleus if not, used for the calculation of basis-generating potentials such as HF/MSDHF
  double total_nucleus_mass;                               // mass of the considered nucleu orr hypernucleus, used for rms radius for example. As a hypernucleus has no defined mass, it is a reference mass givne in the input files.
 
  unsigned int N_nlj_baryon;                               // number of proton or neutron (plus a few hyperons if any) shells, for which n,l,j   are fixed, for full space
  unsigned int N_nljm_baryon;                              // number of proton or neutron (plus a few hyperons if any) states, for which n,l,j,m are fixed, for full space
  unsigned int N_nlj_res_baryon;                           // number of proton or neutron (plus a few hyperons if any) shells, for which n,l,j   are fixed, for pole approximation space
  unsigned int N_nljm_res_baryon;                          // number of proton or neutron (plus a few hyperons if any) states, for which n,l,j,m are fixed, for pole approximation space

  unsigned int natural_orbitals_reference_states_number;   // Number of GSM eigenvectors used to generate natural orbitals. 
                                                           // Indeed, even if it is usual to calculate natural orbitals from one GSM eigenvector using the scalar density matrix <Psi | a+(nlj) a(nlj) |Psi>,
                                                           // one can use \sum_i <Psi_i | a+(nlj) a(nlj) |Psi_i> with several GSM eigenvectors. 
                                                           // Natural orbitals are then optimized to have an overall reproduction of all used GSM eigenvectors.
  
  double jmax;                                             // Maximal total angular momentum of one-body states (proton/charged hyperon, neutron/uncharged hyperon or diproton/dineutron/deuteron shells in relative coordinates)

  double m_min;                                            // Minimal total angular momentum projection of one-body states (proton/charged hyperon, neutron/uncharged hyperon or diproton/dineutron/deuteron shells in relative coordinates)
  double m_max;                                            // Maximal total angular momentum projection of one-body states (proton/charged hyperon, neutron/uncharged hyperon or diproton/dineutron/deuteron shells in relative coordinates)

  double M_max;                                            // Maximal total angular momentum of proton or neutron (plus a few hyperons if any) SDs of the (hyper)nucleus
  double M_max_1h;                                         // Maximal total angular momentum of proton or neutron (plus a few hyperons if any) SDs of the (hyper)nucleus minus one proton  or neutron  (one hole)
  double M_max_2h;                                         // Maximal total angular momentum of proton or neutron (plus a few hyperons if any) SDs of the (hyper)nucleus minus two charged/uncharged baryons (two holes)
  
  int m_max_minus_half;                                    // m_max - 1/2

  int two_m_max;                                           // 2.m_max

  int four_m_max;                                          // 4.m_max

  int m_max_minus_m_min;                                   // m_max - m_min

  int iM_max;                                              // Twice the maximal total angular momentum of proton or neutron (plus a few hyperons if any) SDs of the (hyper)nucleus
  int iM_max_1h;                                           // Twice the maximal total angular momentum of proton or neutron (plus a few hyperons if any) SDs of the (hyper)nucleus minus one proton/charged hyperon   or neutron/uncharged hyperon (one hole)
  int iM_max_2h;                                           // Twice the maximal total angular momentum of proton or neutron (plus a few hyperons if any) SDs of the (hyper)nucleus minus two protons/charged hyperons or neutrons/uncharged hyperons (two holes)

  string debut_file_name;                                  // Beginning of file name storing data related to natural orbitals wave functions, Hamiltonian OBMEs, center-of-mass OBMEs, ...
                                                           // It contains the numbers Z[basis] and N[basis] to identify the nucleus, and 0+(0) if one uses natural orbitals generated by the 0+ ground state, for example.

  double R_charge;                                         // charge radius used in the Coulomb potential of protons/charged hyperons. It is zero for neutrons.
      
  enum potential_type basis_potential;                     // basis_potential: potential used for basis generation (WS, HF, ...)

  enum potential_type H_potential;                         // potential used in the Hamiltonian: it is the potential of the core, which can be typically WS or KKNN
  
  enum potential_type H_basis_core_potential;              // potential used in the basis HF/MSDHF Hamiltonian: it is the potential of the core in the HF/MSDHF potential, which can be typically WS or KKNN

  bool good_isospin_basis_potential;                       // true if one uses the neutron potential for both protons/charged hyperons and neutrons/uncharged hyperons, false if not
  bool is_it_OCM_HO_core;                                  // true if the code is built from HO shells when using COSM coordinates, false if not

  unsigned int N_bef_R_GL;                                 // number of Gauss-Legendre points on [0:R] (before R) (see spherical_state.cpp)
  unsigned int N_aft_R_GL;                                 // number of Gauss-Legendre points on [R:R_real_max], [0:1/R^4] (after R) (see spherical_state.cpp)
  
  unsigned int N_bef_R_uniform;                            // number of points on the uniform grid  [0:R] (before R) (see spherical_state.cpp)
  unsigned int N_aft_R_uniform;                            // number of points on the uniform grids [R:R_real_max], [0:1/R^4] (after R) (see spherical_state.cpp)

  unsigned int Nk_momentum_GL;                             // number of Gauss-Legendre points on [0:kmax_momentum] for wave functions in momentum space
  unsigned int Nk_momentum_uniform;                        // number of points on the uniform grid [0:kmax_momentum] for wave functions in momentum space

  double R;                                                // rotation point of complex scaling
  double step_bef_R_uniform;                               // radial step on the uniform grid on [0:R], with R the rotation point. The number of points on the uniform grid is typically 10 times that of Gauss-Legendre
  double R_real_max;                                       // maximal radius considered on the real-axis. All HO states must be negligible therein.

  double step_momentum_uniform;                            // radial step on the uniform grid on [0:kmax_momentum]. The number of points on the uniform grid is typically 10 times that of Gauss-Legendre

  double kmax_momentum;                                    // maximal momentum for the calculation of densities and correlation densities in momentum space

  double R_Fermi_momentum;                                 // Radius of the Fermi function applied to one-body basis states for the calculation of their approximate Fourier-Bessel transform. The diffuseness can be fixed at a large value.
  
  unsigned int BPmin_global;                               // Minimal binary parity (see observables_basic_functions.cpp for definition) for all two-body states of the proton-proton or neutron-neutron matrix elements (plus a few hyperons if any)
  unsigned int BPmax_global;                               // Maximal binary parity (see observables_basic_functions.cpp for definition) for all two-body states of the proton-proton or neutron-neutron matrix elements (plus a few hyperons if any)

  int Jmin_global;                                         // Minimal total angular momenta for all two-body states of the proton-proton or neutron-neutron matrix elements (plus a few hyperons if any)
  int Jmax_global;                                         // Maximal total angular momenta for all two-body states of the proton-proton or neutron-neutron matrix elements (plus a few hyperons if any)
  
  double R_cut_function;                                   // diffuseness of the Fermi cut function F(r) (see basic_maths.cpp) used in HF/MSDHF/OCM potentials for stability
  double d_cut_function;                                   // radius      of the Fermi cut function F(r) (see basic_maths.cpp) used in HF/MSDHF/OCM potentials for stability
     
  double theta_H_complex_scaled;                          // angle used in the complex scaling of Hamiltonian in radians. It is different in general from that used in radial integrals (the latter being chosen automatically).
  
  TYPE exp_I_theta_H_complex_scaled;                      // exp (I.theta_H_complex_scaled) value used in one-body radial complex-scaled matrix elements

  TYPE exp_minus_I_theta_H_complex_scaled;                // exp (-I.theta_H_complex_scaled) value used in one-body radial complex-scaled matrix elements
  
  TYPE exp_two_I_theta_H_complex_scaled;                  // exp (2.I.theta_H_complex_scaled) value used in one-body radial complex-scaled matrix elements
  
  TYPE exp_minus_two_I_theta_H_complex_scaled;            // exp (-2.I.theta_H_complex_scaled) value used in one-body radial complex-scaled matrix elements
  
  unsigned int BP_one_configuration;                       // Binary parity (see observables_basic_functions.cpp for definition) of the configuration in which the MSDHF ground state is defined
  unsigned int iC_one_configuration;                       //                                                Configuration index of the configuration in which the MSDHF ground state is defined
  
  unsigned int dimension_configuration_total;              // Total number of proton or neutron configurations of the (hyper)nucleus (plus a few hyperons if any)
  unsigned int dimension_configuration_total_1h;           // Total number of proton or neutron configurations of the (hyper)nucleus (plus a few hyperons if any) minus one particle  (one hole)
  unsigned int dimension_configuration_total_2h;           // Total number of proton or neutron configurations of the (hyper)nucleus (plus a few hyperons if any) minus two particles (two holes)
  
  unsigned int dimension_configuration_max;                // Largest number of proton or neutron configurations at fixed parity and number of charged/uncharged baryons in the continuum of the (hyper)nucleus
  unsigned int dimension_configuration_max_1h;             // Largest number of proton or neutron configurations at fixed parity and number of charged/uncharged baryons in the continuum of the (hyper)nucleus minus one particle  (one hole)
  unsigned int dimension_configuration_max_2h;             // Largest number of proton or neutron configurations at fixed parity and number of charged/uncharged baryons in the continuum of the (hyper)nucleus minus two particles (two holes)
  
  unsigned long int dimension_SD_total;                    // Total number of proton or neutron (plus a few hyperons if any) SDs of the (hyper)nucleus
  unsigned long int dimension_SD_total_1h;                 // Total number of proton or neutron (plus a few hyperons if any) SDs of the (hyper)nucleus minus one particle  (one hole)
  unsigned long int dimension_SD_total_2h;                 // Total number of proton or neutron (plus a few hyperons if any) SDs of the (hyper)nucleus minus two particles (two holes)
  
  unsigned int dimension_SD_max;                           // Largest number of proton or neutron SDs at fixed M, parity and number of charged/uncharged baryons in the continuum of the (hyper)nucleus
  unsigned int dimension_SD_max_1h;                        // Largest number of proton or neutron SDs at fixed M, parity and number of charged/uncharged baryons in the continuum of the (hyper)nucleus minus one particle  (one hole)
  unsigned int dimension_SD_max_2h;                        // Largest number of proton or neutron SDs at fixed M, parity and number of charged/uncharged baryons in the continuum of the (hyper)nucleus minus two particles (two holes)

  unsigned int dimension_1p1h_space_BP_S_iM_fixed_max;    // largest possible number of charged/uncharged SDs of fixed parity, strangeness, and M accessible with [a+ a]      operators from a given charged/uncharged SD
  unsigned int dimension_2p2h_space_BP_S_iM_fixed_max;    // largest possible number of charged/uncharged SDs of fixed parity, strangeness, and M accessible with [a+ a+ a a] operators from a given charged/uncharged SD
                                                          // The number of spectator states is not considered as one necessarily has (N[valence baryons]*(N[valence baryons] - 1))/2 excitations involving spectators.
  
  
  // See GSM_nljm_indices_tables.hpp for (l,j), (n,l,j), (l,j,i), (n,l,j,i) ... arrays.

  class array<enum particle_type> baryon_types;  // Types of baryons : proton + charged hyperons or neutron + uncharged hyperons
  
  class array<class lj_table<enum potential_type> > basis_potential_partial_waves_tab;  // particle array of (l,j) array of HO lengths for all proton or neutron partial waves for the calculation of basis-generating potentials such as HF/MSDHF
  
  class array<double> V0_KKNN_tab;     // Central strength    array of the set of KKNN parameters for each particle type
  class array<double> rho_KKNN_tab;    // Central length      array of the set of KKNN parameters for each particle type
  class array<double> Vls_KKNN_tab;    // Spin-orbit strength array of the set of KKNN parameters for each particle type
  class array<double> rho_ls_KKNN_tab; // Spin-orbit length   array of the set of KKNN parameters for each particle type

  class array<double> V0_KKNN_basis_core_potential_tab;     // Central strength    array of the set of KKNN parameters for each particle type for basis core potential
  class array<double> rho_KKNN_basis_core_potential_tab;    // Central length      array of the set of KKNN parameters for each particle type for basis core potential
  class array<double> Vls_KKNN_basis_core_potential_tab;    // Spin-orbit strength array of the set of KKNN parameters for each particle type for basis core potential
  class array<double> rho_ls_KKNN_basis_core_potential_tab; // Spin-orbit length   array of the set of KKNN parameters for each particle type for basis core potential
  
  class array<unsigned int> TRS_nljm_indices;                         // Indices of the |n l j -m> TRS states of the indices of the |n l j m> states
    
  class array<unsigned int> dimensions_configuration_set;             // Numbers of proton or neutron configurations at fixed parity and number of charged/uncharged baryons in the continuum of the (hyper)nucleus
  class array<unsigned int> dimensions_configuration_set_1h;          // Numbers of proton or neutron configurations at fixed parity and number of charged/uncharged baryons in the continuum of the (hyper)nucleus minus one particle  (one hole)
  class array<unsigned int> dimensions_configuration_set_2h;          // Numbers of proton or neutron configurations at fixed parity and number of charged/uncharged baryons in the continuum of the (hyper)nucleus minus two particles (two holes)
  
  class array<unsigned int> sum_dimensions_configuration_set;         // Sums of dimensions of configurations at fixed parity and number of particles in the continuum of the (hyper)nucleus
  class array<unsigned int> sum_dimensions_configuration_set_1h;      // Sums of dimensions of configurations at fixed parity and number of particles minus one particle  (one hole)
  class array<unsigned int> sum_dimensions_configuration_set_2h;      // Sums of dimensions of configurations at fixed parity and number of particles minus two particles (two holes)
                                                                      // This is for configurations having only charged/uncharged baryons
  
                                                                      // (see GSM_configuration_construction_set.cpp for definition)

  class array_of_configuration configuration_set;                     // configurations at fixed parity and number of particles in the continuum of the (hyper)nucleus
  class array_of_configuration configuration_set_1h;                  // configurations at fixed parity and number of particles in the continuum of the (hyper)nucleus minus one particle  (one hole)
  class array_of_configuration configuration_set_2h;                  // configurations at fixed parity and number of particles in the continuum of the (hyper)nucleus minus two particles (two holes)
                                                                      // This is for configurations having only charged/uncharged baryons
  
  class array_BP_S_Nspec_Nscat_iC<unsigned int> dimensions_SD_set;             // Numbers of Slater determinants at fixed parity, M and number of particles in the continuum of the (hyper)nucleus
  class array_BP_S_Nspec_Nscat_iC<unsigned int> dimensions_SD_set_1h;          // Numbers of Slater determinants at fixed parity, M and number of particles in the continuum of the (hyper)nucleus minus one particle  (one hole)
  class array_BP_S_Nspec_Nscat_iC<unsigned int> dimensions_SD_set_2h;          // Numbers of Slater determinants at fixed parity, M and number of particles in the continuum of the (hyper)nucleus minus two particles (two holes)
  // This is for SDs having only charged/uncharged baryons
  
  class array_BP_S_Nspec_Nscat_iC<unsigned long int> sum_dimensions_SD_set;    // Sums of dimensions of Slater determinants at fixed parity, M and number of particles in the continuum of the (hyper)nucleus
  class array_BP_S_Nspec_Nscat_iC<unsigned long int> sum_dimensions_SD_set_1h; // Sums of dimensions of Slater determinants at fixed parity, M and number of particles in the continuum of the (hyper)nucleus minus one particle  (one hole)
  class array_BP_S_Nspec_Nscat_iC<unsigned long int> sum_dimensions_SD_set_2h; // Sums of dimensions of Slater determinants at fixed parity, M and number of particles in the continuum of the (hyper)nucleus minus two particles (two holes)
  // (see GSM_SD_construction_set.cpp for definition)

  class array_of_SD SD_set;                                            // Slater determinants at fixed parity, M and number of particles in the continuum of the (hyper)nucleus
  class array_of_SD SD_set_1h;                                         // Slater determinants at fixed parity, M and number of particles in the continuum of the (hyper)nucleus minus one particle  (one hole)
  class array_of_SD SD_set_2h;                                         // Slater determinants at fixed parity, M and number of particles in the continuum of the (hyper)nucleus minus two particles (two holes)
                                                                       // This is for SDs having only charged/uncharged baryons
  
  class array_BP_S_Nspec_Nscat_iC<int> E_hw_table;    // Truncation energies of proton or neutron configurations (plus a few hyperons if any)
  class array_BP_S_Nspec_Nscat_iC<int> n_holes_table; // Number of holes     of proton or neutron configurations (plus a few hyperons if any)

  class OBMEs_CM_set_str OBMEs_CM_set_HO_expansion; // Structure storing OBMEs of CM operators using HO expansion. If the Hamiltonian is complex-scaled, these OBMEs do not contain theta-dependence.
  class OBMEs_CM_set_str OBMEs_CM_set_R_cut;        // Structure storing OBMEs of CM operators using R-cut, i.e. integration on [0:R] only
  
  class OBMEs_CM_set_str reduced_grad_HO_expansion_set;                             // Structure storing OBMEs of reduced gradient of different CM operators, i.e. they are multiplied by different factors, using HO expansion.
  class OBMEs_CM_set_str reduced_r_HO_expansion_set;                                // Structure storing OBMEs of reduced \vec{r}  of different CM operators, i.e. they are multiplied by different factors, using HO expansion.
  class OBMEs_CM_set_str reduced_r_HO_expansion_rms_radius_different_particles_set; // Structure storing OBMEs of reduced \vec{r}  of different CM operators for rms radius, i.e. they are multiplied by other factors, using HO expansion.
  
  class OBMEs_CM_set_str reduced_grad_R_cut_set;                             // Structure storing OBMEs of reduced gradient of different CM operators, i.e. they are multiplied by different factors, using R-cut, i.e. integration on [0:R] only.
  class OBMEs_CM_set_str reduced_r_R_cut_set;                                // Structure storing OBMEs of reduced \vec{r}  of different CM operators, i.e. they are multiplied by different factors, using R-cut, i.e. integration on [0:R] only.
  class OBMEs_CM_set_str reduced_r_R_cut_rms_radius_different_particles_set; // Structure storing OBMEs of reduced \vec{r}  of different CM operators for rms radius, i.e. they are multiplied by other factors, using R-cut, i.e. integration on [0:R] only.
    
  class OBMEs_multipole_square_str OBMEs_multipole_square_HO_expansion;   // Structure storing (r^L.YL)^2 OBMEs using HO expansion
  
  class OBMEs_multipole_reduced_str OBMEs_multipole_reduced_HO_expansion; // Structure storing r^L.YL reduced OBMEs using HO expansion
  
  class OBMEs_multipole_square_str OBMEs_multipole_square_R_cut;          // Structure storing (r^L.YL)^2 OBMEs using R cut, i.e. integration on [0:R] only
  
  class OBMEs_multipole_reduced_str OBMEs_multipole_reduced_R_cut;        // Structure storing r^L.YL reduced OBMEs using R cut, i.e. integration on [0:R] only
  
  class OBMEs_inter_set_str OBMEs_inter_set;                              // Structure storing OBMEs of Hamiltonian
  
  class array<class lj_table<int> > nmax_lj_tabs;                         // array of particle array of (l,j) array of n[max] values of all baryon partial waves
    
  class array<class lj_table<int> > nmin_lj_valence_tabs;                 // particle array of (l,j) array of n[min] values of all baryon partial waves of the valence space (i.e. core states excluded)

  class array<class nlj_table<unsigned int> > shells_indices_tab;         // particle array of (n,l,j) array of the indices of basis shells of all baryon partial waves.
                                                                          // For example, with 0s1/2,0p3/2,0p1/2, one has:
                                                                          // shells_indices_tab(charge_baryon_index_determine(PROTON))(0,0,0.5) = 0,
                                                                          // shells_indices_tab(charge_baryon_index_determine(PROTON))(0,1,1.5) = 1,
                                                                          // shells_indices_tab(charge_baryon_index_determine(PROTON))(0,1,0.5) = 2.  
    
  class array<class nlj_table<bool> > is_it_valence_shell_tabs;           // particle array of (n,l,j) array of booleans which are true for valence shells and false for frozen shells.
                                                                          // It is only for nucleons as hyperons cannot be in the core and then are always valence particles.

  class one_body_indices_str one_body_indices;                            // Structure providing with the indices of basis states.
                                                                          // This is similar to shells_indices, except that the m-quantum number is also included.
                                                                          // one_body_indices(charge_baryon_index_determine(PROTON))(0,0,0.5,-0.5) = 0,
                                                                          // one_body_indices(charge_baryon_index_determine(PROTON))(0,1,1.5,-0.5) = 1,
                                                                          // one_body_indices(charge_baryon_index_determine(PROTON))(0,1,0.5,-0.5) = 2.  
    
  class array<class spherical_state> shells;                              // Array of one-body wave functions (see spherical_state.cpp)
  class array<class spherical_state> shells_plus;                         // Array of one-body wave functions, k replaced by k + w/[4 pi] to calculate Coulomb OBMEs (see spherical_state.cpp and GSM_H_CM_OBMEs.cpp)
  class array<class spherical_state> shells_minus;                        // Array of one-body wave functions, k replaced by k - w/[4 pi] to calculate Coulomb OBMEs (see spherical_state.cpp and GSM_H_CM_OBMEs.cpp)

  class array<class nljm_struct> phi_table;                               // Array of structures providing with the quantum numbers of basis states.

  class nlj_table<complex<double> > Ueq_finite_range_tab_uniform;         // (n,l,j) array of HF/MSDHF/OCM equivalent potentials for each basis state using a uniform grid (nucleon only)
  class nlj_table<complex<double> > Ueq_finite_range_plus_tab_uniform;    // (n,l,j) array of HF/MSDHF/OCM equivalent potentials for each basis state using a uniform grid, k replaced by k + w/[4 pi] to calculate Coulomb OBMEs (nucleon only)
  class nlj_table<complex<double> > Ueq_finite_range_minus_tab_uniform;   // (n,l,j) array of HF/MSDHF/OCM equivalent potentials for each basis state using a uniform grid, k replaced by k - w/[4 pi] to calculate Coulomb OBMEs (nucleon only)
  
  class nlj_table<complex<double> > source_tab_uniform;                   // (n,l,j) array of HF/MSDHF/OCM sources for each basis state using a uniform grid (nucleon only)
  class nlj_table<complex<double> > source_plus_tab_uniform;              // (n,l,j) array of HF/MSDHF/OCM sources for each basis state using a uniform grid, k replaced by k + w/[4 pi] to calculate Coulomb OBMEs (nucleon only)
  class nlj_table<complex<double> > source_minus_tab_uniform;             // (n,l,j) array of HF/MSDHF/OCM sources for each basis state using a uniform grid, k replaced by k + w/[4 pi] to calculate Coulomb OBMEs (nucleon only)
  
  class lj_table<complex<double> > OBMEs_HF_SGI_MSGI;       // (l,j) array of HF/MSDHF OBMEs of the SGI/MSGI interaction sources for each basis state using a uniform grid
                                                            // The format is OBMEs_HF_SGI_MSGI(l , j , n[in] , n[out])
                                                            // SGI/MSGI interactions are used only with nucleons to that particle type is not mentioned.

  class array<class nlj_table<TYPE> > h_basis_tab;          // particle array of (n,l,j) array of Hamiltonian OBMEs

  class TBMEs_class TBMEs;                                  // Class storing J-coupled proton/charged hyperon-proton/charged hyperon or neutron/uncharged hyperon-neutron/uncharged hyperon TBMEs (see GSM_TBMEs_class.cpp)

  class array<class nlj_struct> shells_quantum_numbers;     // Array of structures providing with the quantum numbers of basis shells.
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> SD_TRS_indices;             // Indices of the TRS states of charged/uncharged baryon SDs of the (hyper)nucleus
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> SD_TRS_indices_1h;          // Indices of the TRS states of charged/uncharged baryon SDs of the (hyper)nucleus minus one particle  (one hole)
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> SD_TRS_indices_2h;          // Indices of the TRS states of charged/uncharged baryon SDs of the (hyper)nucleus minus two particles (two holes)
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> SD_TRS_reordering_bin_phases;     // Binary reordering phases of the TRS states of charged/uncharged baryon SDs of the (hyper)nucleus
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> SD_TRS_reordering_bin_phases_1h;  // Binary reordering phases of the TRS states of charged/uncharged baryon SDs of the (hyper)nucleus minus one particle  (one hole)
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> SD_TRS_reordering_bin_phases_2h;  // Binary reordering phases of the TRS states of charged/uncharged baryon SDs of the (hyper)nucleus minus two particles (two holes)
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> SD_TRS_bin_phases;     // Binary phases without reordering of the TRS states of charged/uncharged baryon SDs of the (hyper)nucleus
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> SD_TRS_bin_phases_1h;  // Binary phases without reordering of the TRS states of charged/uncharged baryon SDs of the (hyper)nucleus minus one particle  (one hole)
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> SD_TRS_bin_phases_2h;  // Binary phases without reordering of the TRS states of charged/uncharged baryon SDs of the (hyper)nucleus minus two particles (two holes)
  
  class array_BP_S_Nspec_Nscat_iC<unsigned int> dimensions_configuration_one_jump_table_in_to_out; // Numbers of charged/uncharged baryon configuration one-jump data (i.e. the data associated to [a+ a] C[in] = C[out])
  class array_BP_S_Nspec_Nscat_iC<unsigned int> dimensions_configuration_one_jump_table_out_to_in; // Numbers of charged/uncharged baryon configuration one-jump data (i.e. the data associated to [a+ a] C[out] = C[in])
  
  class array_of_configuration_one_jump_data_in_to_out configuration_one_jump_table_in_to_out; // Charged/uncharged baryon configuration one-jump data (i.e. the data associated to [a+ a] C[in] = C[out])
  class array_of_configuration_one_jump_data_out_to_in configuration_one_jump_table_out_to_in; // Charged/uncharged baryon configuration one-jump data (i.e. the data associated to [a+ a] C[out] = C[in])
                                                                                                   
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> dimensions_SD_one_jump_table_in_to_out; // Numbers of charged/uncharged baryon SD one-jump data (i.e. the data associated to [a+ a] SD[in] = SD[out]) (J+/- operators excluded)
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> dimensions_SD_one_jump_table_out_to_in; // Numbers of charged/uncharged baryon SD one-jump data (i.e. the data associated to [a+ a] SD[out] = SD[in]) (J+/- operators excluded)
  // This is for SDs having only charged/uncharged baryons
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> dimensions_SD_one_jump_table_Jpm_in_to_out; // Numbers of charged/uncharged baryon SD one-jump data (i.e. the data associated to [a+ a] SD[in] = SD[out]) (J+/- operators only)
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> dimensions_SD_one_jump_table_Jpm_out_to_in; // Numbers of charged/uncharged baryon SD one-jump data (i.e. the data associated to [a+ a] SD[out] = SD[in]) (J+/- operators only)
  // This is for SDs having only charged/uncharged baryons
  
  class array_of_SD_one_jump_data_in_to_out SD_one_jump_table_in_to_out; // Charged/uncharged baryon SD one-jump data (i.e. the data associated to [a+ a] SD[in] = SD[out]) (J+/- operators excluded)
  class array_of_SD_one_jump_data_out_to_in SD_one_jump_table_out_to_in; // Charged/uncharged baryon SD one-jump data (i.e. the data associated to [a+ a] SD[out] = SD[in]) (J+/- operators excluded)
  
  class array_of_SD_one_jump_data_Jpm_in_to_out SD_one_jump_table_Jpm_in_to_out; // Charged/uncharged baryon SD one-jump data (i.e. the data associated to [a+ a] SD[out] = SD[in]) (J+/- operators only)
  class array_of_SD_one_jump_data_Jpm_out_to_in SD_one_jump_table_Jpm_out_to_in; // Charged/uncharged baryon SD one-jump data (i.e. the data associated to [a+ a] SD[out] = SD[in]) (J+/- operators only)

  // Classes below occur as two-dimension static arrays, of the form "class T_class<int> T[2]".
  // T[0] and T[1] are used in the occupied and unoccupied squares of the Hamiltonian in 2D partitioning, respectively.
  // T[0] is used by default when 2D partitioning is not applied.
  // T[1] parts are used neither with 1D nor with hybrid 1D/2D partitionings.
  
  class array_BP_S_Nspec_Nscat_iC<bool> are_configurations_inter_occupied_in_space_1ph_tables[2]; // Arrays of booleans equal to true if the intermediate (inter) configuration "a+ C" or "a C" (1p or 1h excitation) is in the model space, false if not
  class array_BP_S_Nspec_Nscat_iC<bool> are_configurations_inter_occupied_in_space_2ph_tables[2]; // Arrays of booleans equal to true if the intermediate (inter) configuration [a+ a+] C or [a a] C (2p or 2h excitation) is in the model space, false if not
  
  class array_BP_S_Nspec_Nscat_iC<unsigned int> dimensions_configuration_1p_tables[2]; // Numbers of configurations of the form "a+ C", with C a configuration of the (hyper)nucleus minus one particle
  class array_BP_S_Nspec_Nscat_iC<unsigned int> dimensions_configuration_1h_tables[2]; // Numbers of configurations of the form "a C" , with C a configuration of the (hyper)nucleus
  // This is for configurations having only charged/uncharged baryons
  
  class array_BP_S_Nspec_Nscat_iC<unsigned int> dimensions_configuration_2p_tables[2]; // Numbers of configurations of the form [a+ a+] C , with C a configuration of the (hyper)nucleus minus two particles
  class array_BP_S_Nspec_Nscat_iC<unsigned int> dimensions_configuration_2h_tables[2]; // Numbers of configurations of the form [a a]   C , with C a configuration of the (hyper)nucleus
  // This is for configurations having only charged/uncharged baryons
  
  class array_of_configuration_1ph_data configuration_1p_tables[2]; // Data related to configurations of the form "a+ C", with C a configuration of the (hyper)nucleus minus one particle
  class array_of_configuration_1ph_data configuration_1h_tables[2]; // Data related to configurations of the form "a C" , with C a configuration of the (hyper)nucleus
                                                                    // This is for configurations having only charged/uncharged baryons
  
  class array_of_configuration_2ph_data configuration_2p_tables[2]; // Data related to configurations of the form [a+ a+] C , with C a configuration of the (hyper)nucleus minus two particles
  class array_of_configuration_2ph_data configuration_2h_tables[2]; // Data related to configurations of the form [a a]   C , with C a configuration of the (hyper)nucleus
                                                                    // This is for configurations having only charged/uncharged baryons

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> dimensions_SD_1p_tables[2]; // Numbers of charged/uncharged baryon SDs of the form "a+ SD",with SD a Slater determinant of the (hyper)nucleus minus one particle
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> dimensions_SD_1h_tables[2]; // Numbers of charged/uncharged baryon SDs of the form "a SD", with SD a Slater determinant of the (hyper)nucleus
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> dimensions_SD_2p_tables[2]; // Numbers of charged/uncharged baryon SDs of the form [a+ a+] SD, with SD a Slater determinant of the (hyper)nucleus minus two particles
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> dimensions_SD_2h_tables[2]; // Numbers of charged/uncharged baryon SDs of the form [a a] SD, with SD a Slater determinant of the (hyper)nucleus
  
  class array_of_SD_1ph_data SD_1p_tables[2]; // Data related to charged/uncharged baryon SDs of the form "a+ SD", with SD a Slater determinant of the (hyper)nucleus minus one particle
  class array_of_SD_1ph_data SD_1h_tables[2]; // Data related to charged/uncharged baryon SDs of the form "a SD" , with SD a Slater determinant of the (hyper)nucleus
  
  class array_of_SD_2ph_data SD_2p_tables[2]; // Data related to charged/uncharged baryon SDs of the form [a+ a+] SD , with SD a Slater determinant of the (hyper)nucleus minus two particles
  class array_of_SD_2ph_data SD_2h_tables[2]; // Data related to charged/uncharged baryon SDs of the form [a a]   SD , with SD a Slater determinant of the (hyper)nucleus
      
  class lj_table<class matrix<complex<double> > > U_finite_range_HF_HO_basis_HO_expansion_part; // array of HF/MSDHF finite range parts (i.e. without Coulomb part) of the HF/MSDHF potential matrices in an HO basis (nucleon only)
  
  class array<class vector_class<complex<double> > > HO_overlaps_basis;       // Array of overlaps between basis shells and HO states used only to calculate one-body basis states with HF/MSDHF/OCM potentials
  class array<class vector_class<complex<double> > > HO_overlaps_basis_Fermi; // Array of overlaps between basis shells and HO states multiplied by a Fermi function used only to calculate one-body basis states with HF/MSDHF/OCM potentials
  class array<class vector_class<complex<double> > > HO_overlaps;             // Array of overlaps between basis shells and HO states
  class array<class vector_class<complex<double> > > HO_overlaps_Fermi;       // Array of overlaps between basis shells and HO states multiplied by a Fermi function
  
  class array<class vector_class<complex<double> > > GHF_overlaps;            // Array of overlaps between basis shells and GHF shells. This array is used for convenience only, as overlaps are equal to 0 or 1 as all states belong to the same basis.


  
  // The following parameters are diffuseness (d), radius (R0), central strength (Vo) and spin-orbit strength (Vso) of WS potentials
  // -------------------------------------------------------------------------------------------------------------------------------
  // Arrays are function of charged/uncharged particle type and orbital angular momentum l, so that one has different parameters for different partial waves.
  // "core" (without "basis") is for parameters used for the WS of the core for Hamiltonian diagonalization.
  // "basis_core" is for parameters used for the WS of the core for the calculation of basis-generating potentials such as HF/MSDHF.
  // "basis" (without "core") is the parameters used for the WS potential directly used to generate the one-body basis,
  // or two-body relative for diproton/dineutron/deuteron basis, without recurring to HF/MSDHF/OCM for example.
  //
  // Imaginary parts of the complex WS potential depths are also available if one demands WS core potentials to be complex. A surface potential is also added.
  
  class array<double> d_core_potential_tab;         
  class array<double> R0_core_potential_tab;
  class array<double> Vo_core_potential_tab;
  class array<double> Vso_core_potential_tab;
  class array<double> Im_Vo_core_potential_tab;
  class array<double> Im_Vso_core_potential_tab;
  class array<double> Im_Vsurf_core_potential_tab;
  
  class array<double> d_basis_core_potential_tab;
  class array<double> R0_basis_core_potential_tab;
  class array<double> Vo_basis_core_potential_tab;
  class array<double> Vso_basis_core_potential_tab;
  class array<double> Im_Vo_basis_core_potential_tab;
  class array<double> Im_Vso_basis_core_potential_tab;
  class array<double> Im_Vsurf_basis_core_potential_tab;
  
  class array<double> d_basis_tab;
  class array<double> R0_basis_tab;
  class array<double> Vo_basis_tab;
  class array<double> Vso_basis_tab;
  class array<double> Im_Vo_basis_tab;
  class array<double> Im_Vso_basis_tab;
  class array<double> Im_Vsurf_basis_tab;



  
  
  // See observables_basic_functions.cpp for definition of binary parity and enum_struct_definitions.h for definition of spectator states.
  
  class array<class lj_table<double> > b_partial_waves_tab; // particle array of (l,j) array of HO lengths for all proton or neutron partial waves for Hamiltonian diagonalization

  class lj_table<class correlated_state_str> basis_PSI_quantum_numbers_tab; // particle array of (l,j) array of structures containing the Z[basis], N[basis], J-Pi quantum numbers of the many-body (PSI) of the optimized configurations in MSDHF

  class array<bool> BPin_Sin_Nspec_in_for_one_jump_tab; // array of booleans function of binary parity, strangeness and number of spectator pairs of valence charged/uncharged baryons (pp/nn and pn cases)
                                                        // equal to true if parity and strangeness can be attained by the 1p-1h excitations of the considered many-body operator, false if not (out_to_in case).
  
  class array<bool> BPout_Sout_Nspec_out_for_one_jump_tab; // array of booleans function of binary parity, strangeness and number of spectator pairs of valence charged/uncharged baryons (pp/nn and pn cases)
                                                           // equal to true if parity and strangeness can be attained by the 1p-1h excitations of the considered many-body operator, false if not (in_to_out case).
  
  class array<bool> BPin_Sin_Nspec_in_iMin_for_one_jump_tab; // array of booleans function of binary parity, strangeness, number of spectator pairs and M of valence charged/uncharged baryons (pp/nn and pn cases)
                                                             // equal to true if M, strangeness or parity can be attained by the 1p-1h excitations of the considered many-body operator, false if not (out_to_in case).
  
  class array<bool> BPout_Sout_Nspec_out_iMout_for_one_jump_tab; // array of booleans function of binary parity, strangeness, number of spectator pairs and M of valence charged/uncharged baryons (pp/nn and pn cases)
                                                                 // equal to true if M, strangeness or parity can be attained by the 1p-1h excitations of the considered many-body operator, false if not (in_to_out case).

  class array<unsigned int> iC_in_min_tab[2]; // array of minimal configuration indices occurring in a given squares as a function of binary parity, strangeness, number of spectator pairs and number of particles in the continuum (out_to_in case)
  class array<unsigned int> iC_in_max_tab[2]; // array of maximal configuration indices occurring in a given squares as a function of binary parity, strangeness, number of spectator pairs and number of particles in the continuum (out_to_in case)
  
  class array<unsigned int> iC_out_min_tab; // array of minimal configuration indices occurring in a given squares as a function of binary parity, strangeness, number of spectator pairs and number of particles in the continuum (in_to_out case)
  class array<unsigned int> iC_out_max_tab; // array of maximal configuration indices occurring in a given squares as a function of binary parity, strangeness, number of spectator pairs and number of particles in the continuum (in_to_out case)
  
  class array_BP_S_Nspec_Nscat_iC<bool> is_configuration_in_in_space_tabs[2]; // array of booleans equal to true if a configuration C[in]  is part of the model space of a given Hamiltonian square or stripe, false if not
  class array_BP_S_Nspec_Nscat_iC<bool> is_configuration_out_in_space_tab;    // array of booleans equal to true if a configuration C[out] is part of the model space of a given Hamiltonian square or stripe, false if not
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> is_inSD_in_space_tab_Jpm; // array of booleans equal to true if a Slater determinant SD[in] is part of the model space of a given Hamiltonian square or stripe, false if not (J+/- operators only)
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> is_inSD_in_space_tabs[2];  // array of booleans equal to true if a Slater determinant SD[in]  is part of the model space of a given Hamiltonian square or stripe, false if not (J+/- operators excluded) 
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> is_outSD_in_space_tab;     // array of booleans equal to true if a Slater determinant SD[out] is part of the model space of a given Hamiltonian square or stripe, false if not (J+/- operators excluded)
  
  class array_BP_S_Nspec_Nscat_iC<bool> is_it_configuration_inter_to_include_tab; // array of booleans equal to true if an intermediate (inter) configuration [a+ a] C must be included in the calculation, as it plays a role in H|Psi>, or not
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> is_it_SD_inter_to_include_tab; // array of booleans equal to true if an intermediate (inter) Slater determinant [a+ a] SD must be included in the calculation, as it plays a role in H|Psi>, or not	

  class array<unsigned int> initial_to_nljm_ordered_states; // array of the one-body indices which are nljm-reordered (see GSM_Slater_determinant.cpp for definition). It is used with the SD expansion of clusters.
  
  class array<unsigned int> nljm_ordered_to_initial_states; // array of the initial one-body indices function of nljm-reordered indices (see GSM_Slater_determinant.cpp for definition).
                                                            // It is used with the SD expansion of clusters with both Berggren and HO basis in GSM-CC.

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> dimensions_SD_HO_Berggren_overlaps_table; // Number of overlaps of the form <SD[Berggren] | SD[HO]>, used with the SD expansion of clusters with both Berggren and HO basis in GSM-CC.
  
  class array_of_SD_HO_Berggren_overlaps_data_str SD_HO_Berggren_overlaps_table; // array of overlaps of the form <SD[Berggren] | SD[HO]>, used with the SD expansion of clusters with both Berggren and HO basis in GSM-CC.

  class array<class lj_table<class matrix<TYPE> > > scalar_density_matrices_tab; // particle array of (l,j) array of the scalar density matrices <Psi | [a+[alpha] a[beta]]^(00) | Psi>, where |alpha> and |beta> have (l,j) quantum numbers
  
  class array<class lj_table<class matrix<TYPE> > > natural_orbitals_matrices_tab; // particle array of (l,j) array of the matrices whose eigenvectors provide natural orbitals. Matrices are represented with Berggren or HO basis.
  
  class array<class lj_table<class matrix<TYPE> > > ESPEs_Hamiltonian_matrices_tab; // particle array of (l,j) array of matrices whose eigenvalues are the effective single-particle energies (ESPEs)

  class array<class lj_table<class matrix<TYPE> > > ESPEs_Hamiltonian_orbitals_matrices_tab; // particle array of (l,j) array of matrices containing the orbitals, i.e. the eigenvectors, of ESPEs_Hamiltonian_matrices
  
  class array<class correlated_state_str> natural_orbitals_reference_states; // array of the quantum numbers of the many-body state |Psi>, so that the eigenvectors of the matrix <Psi | [a+[alpha] a[beta]]^(00) | Psi> are the natural orbitals

  class array<class SD_quantum_numbers> SD_quantum_numbers_tab; // array of the quantum numbers of SDs. This is for SDs having only charged/uncharged baryons

  class array<double> effective_masses_for_calc; // particle array : mass of the proton/charged hyperon, neutron/uncharged hyperon or diproton/dineutron/deuteron used in the calculation of basis wave functions. They do not have to be their physical mass.
  
  class array<double> effective_charges;         // particle array : effective charge of baryons used in electro-magnetic transitions
  
  class array<bool> are_there_basis_natural_orbitals_tab; // particle table : true if one has natural orbitals of baryons in the one-body basis, false if not
  
  class array<bool> are_there_new_natural_orbitals_tab;   // particle table : true if one calculates natural orbitals of baryons for the one-body basis of a future calculation, false if not
};

bool are_core_basis_potentials_equal (const int l , const class baryons_data &data);

void baryons_data_initialization (
				  const bool is_it_M_scheme ,
				  const class input_data_str &input_data ,
				  class baryons_data &prot_Y_data ,
				  class baryons_data &neut_Y_data);

void relative_data_initialization (
				   const class input_data_str &input_data ,
				   class baryons_data &relative_data);

#endif


