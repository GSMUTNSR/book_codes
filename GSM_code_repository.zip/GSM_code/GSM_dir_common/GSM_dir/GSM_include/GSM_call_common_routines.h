#ifndef GSMCALLCOMMONROUTINES_H
#define GSMCALLCOMMONROUTINES_H

// TYPE is double or complex
// -------------------------

namespace call_common_routines
{
  void files_norm_coefficients_alloc_read ( 
					   class input_data_str &input_data , 
					   class array<double> &SPE_coefficients , 
					   class array<double> &TBME_coefficients , 
					   class array<string> &file_names);
	
  void radiative_capture_read (class input_data_str &input_data);

  void read_optimization (
			  const class input_data_str &input_data_common , 
			  class array<class input_data_str> &input_data_tab);

  void input_data_read_MPI_transfer (
				     class array<double> &SPE_coefficients , 
				     class array<double> &TBME_coefficients , 
				     class array<string> &file_names , 
				     class input_data_str &input_data , 
				     class input_data_str &input_data_CC_Berggren , 
				     class array<class input_data_str> &input_data_tab_for_optimization);
}

#endif

