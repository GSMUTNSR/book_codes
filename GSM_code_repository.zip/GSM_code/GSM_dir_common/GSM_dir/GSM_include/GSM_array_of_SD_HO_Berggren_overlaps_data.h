#ifndef GSMARRAYOFSDHOBERGGRENOVERLAPSDATA_H
#define GSMARRAYOFSDHOBERGGRENOVERLAPSDATA_H

// TYPE is double or complex
// -------------------------

class SD_HO_Berggren_overlaps_data_str
{ 
public:
  SD_HO_Berggren_overlaps_data_str ();

  SD_HO_Berggren_overlaps_data_str (
				    const unsigned int n_scat_HO_c , 
				    const unsigned int iC_HO_c , 
				    const unsigned int SD_HO_index_c , 
				    const TYPE &SD_HO_Berggren_overlap_c);
  
  void initialize (
		   const unsigned int n_scat_HO_c , 
		   const unsigned int iC_HO_c , 
		   const unsigned int SD_HO_index_c , 
		   const TYPE &SD_HO_Berggren_overlap_c);

  void initialize (const class SD_HO_Berggren_overlaps_data_str &X);
  
  void allocate_fill (const class SD_HO_Berggren_overlaps_data_str &X);
  
  unsigned char get_n_scat_HO () const
  {
    return n_scat_HO;
  }
  
  unsigned int get_iC_HO () const
  {
    return iC_HO;
  }
  
  unsigned int get_SD_HO_index () const
  {
    return SD_HO_index;
  }
  
  TYPE get_SD_HO_Berggren_overlap () const
  {
    return SD_HO_Berggren_overlap;
  }
  
private:
  
  unsigned char n_scat_HO; // number of scattering-like HO states in the C[HO] configuration
  
  unsigned int iC_HO; // index of the the C[HO] configuration

  unsigned int SD_HO_index; // index of the SD associated to C[HO]

  TYPE SD_HO_Berggren_overlap; // overlap <SD[Berggren] | SD[HO]>
};


double used_memory_calc (const class SD_HO_Berggren_overlaps_data_str &T);






class array_of_SD_HO_Berggren_overlaps_data_str
{
public:
  
  array_of_SD_HO_Berggren_overlaps_data_str ();
  
  array_of_SD_HO_Berggren_overlaps_data_str (
					     const unsigned int strangeness_max , 
					     const unsigned int n_spec_max , 
					     const unsigned int n_scat_max , 
					     const class array<unsigned int> &dimensions_config_set , 
					     const unsigned int iM_max , 
					     const unsigned long int dimension_SD_total , 
					     const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set , 
					     const class array_BP_S_Nspec_Nscat_iC<unsigned long int> &sum_dimensions_SD_set , 
					     const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_HO_Berggren_overlaps_table);

  array_of_SD_HO_Berggren_overlaps_data_str (const class array_of_SD_HO_Berggren_overlaps_data_str &X);
  
  void allocate (
		 const unsigned int strangeness_max ,
		 const unsigned int n_spec_max , 
		 const unsigned int n_scat_max , 
		 const class array<unsigned int> &dimensions_config_set , 
		 const unsigned int iM_max , 
		 const unsigned long int dimension_SD_total , 
		 const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set , 
		 const class array_BP_S_Nspec_Nscat_iC<unsigned long int> &sum_dimensions_SD_set , 
		 const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_HO_Berggren_overlaps_table);

  void allocate_fill (const class array_of_SD_HO_Berggren_overlaps_data_str &X);

  void deallocate ();

  bool is_it_filled () const;
  
  unsigned int index_determine (
				const unsigned int BP ,
				const unsigned int S , 
				const unsigned int n_spec , 
				const unsigned int n_scat , 
				const unsigned int iC , 
				const unsigned int iM , 
				const unsigned int SD_index , 
				const unsigned int SD_HO_Berggren_overlaps_index) const;

  class SD_HO_Berggren_overlaps_data_str & operator () (
							const unsigned int BP ,
							const unsigned int S , 
							const unsigned int n_spec , 
							const unsigned int n_scat , 
							const unsigned int iC , 
							const unsigned int iM , 
							const unsigned int SD_index , 
							const unsigned int SD_HO_Berggren_overlaps_index) const;  

  class SD_HO_Berggren_overlaps_data_str & operator [] (const unsigned int index) const;

  friend double used_memory_calc (const class array_of_SD_HO_Berggren_overlaps_data_str &T);

private:
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> sum_dimensions_tab; // array of sums of numbers of SD_HO_Berggren_overlaps_data_str for fixed M, parity and number of particles in the continuum.
                                                                          // It is used to calculate the internal index of a given class SD_HO_Berggren_overlaps_data_str in the stored table (see GSM_array_BP_S_Nspec_Nscat_iC_iM_SD.hpp)
  
  class array<class SD_HO_Berggren_overlaps_data_str> table; // array of SD_HO_Berggren_overlaps_data_str
};

#endif
