#ifndef GSMARRAYOFCONFIGURATION1PH_H
#define GSMARRAYOFCONFIGURATION1PH_H

// TYPE is double or complex
// -------------------------

class array_of_configuration_1ph_data
{
public:
  array_of_configuration_1ph_data ();
  
  array_of_configuration_1ph_data (
				   const int n_scat_max_c , 
				   const unsigned int dimension_configuration_total , 
				   const class array<unsigned int> &dimensions_configuration_set , 
				   const class array<unsigned int> &sum_dimensions_configuration_set , 
				   const class array_BP_Nscat_iC<unsigned int> &dimensions_configuration_1ph_table);

  array_of_configuration_1ph_data (const class array_of_configuration_1ph_data &X);

  void allocate (
		 const int n_scat_max_c , 
		 const unsigned int dimension_configuration_total , 
		 const class array<unsigned int> &dimensions_configuration_set , 
		 const class array<unsigned int> &sum_dimensions_configuration_set , 
		 const class array_BP_Nscat_iC<unsigned int> &dimensions_configuration_1ph_table);

  void allocate_fill (const class array_of_configuration_1ph_data &X);

  void deallocate ();

  bool is_it_filled () const;
  
  unsigned int index_determine (
				const unsigned int BP_out , 
				const int n_scat_out , 
				const unsigned int iC_out , 
				const unsigned int BP_in , 
				const unsigned int configuration_1ph_index) const;

  class configuration_1ph_data_str & operator () (
						  const unsigned int BP_out , 
						  const int n_scat_out , 
						  const unsigned int iC_out , 
						  const unsigned int BP_in , 
						  const unsigned int configuration_1ph_index) const;

  class configuration_1ph_data_str & operator [] (const unsigned int index) const;

  friend double used_memory_calc (const class array_of_configuration_1ph_data &T);
 
private:
  
  class array_BP_Nscat_iC<unsigned int> sum_dimensions_tab; // array of sums of numbers of configuration_1ph_data_str for fixed parity and number of particles in the continuum.
                                                            // It is used to calculate the internal index of a given class configuration_1ph_data_str in the stored table (see GSM_array_BP_Nscat_iC.hpp)
  
  class array<class configuration_1ph_data_str> table; // array of configuration_1ph_data_str
};


#endif


