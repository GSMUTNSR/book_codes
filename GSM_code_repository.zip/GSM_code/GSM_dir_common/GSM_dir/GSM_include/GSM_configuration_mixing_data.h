#ifndef GSMCONFIGURATIONMIXINGDATA_H
#define GSMCONFIGURATIONMIXINGDATA_H

// TYPE is double or complex
// -------------------------

class configuration_mixing_data
{
public:

  configuration_mixing_data ();

  configuration_mixing_data (const configuration_mixing_data &X);

  configuration_mixing_data (
			     const unsigned int BPp_c , 
			     const unsigned int iCp_c , 
			     const unsigned int iCn_c , 
			     const int n_scat_p_c , 
			     const int n_scat_n_c , 
			     const unsigned int iC_c , 
			     const int n_scat_c , 
			     const TYPE probability_c);

  void initialize (
		   const unsigned int BPp_c , 
		   const unsigned int iCp_c , 
		   const unsigned int iCn_c , 
		   const int n_scat_p_c , 
		   const int n_scat_n_c , 
		   const unsigned int iC_c , 
		   const int n_scat_c , 
		   const TYPE probability_c);
  
  void initialize (const configuration_mixing_data &X);
  
  void operator = (const configuration_mixing_data &X);

  unsigned int get_BPp () const
  {
    return BPp;
  }
  
  unsigned int get_iCp () const
  {
    return iCp;
  }

  unsigned int get_iCn () const
  {
    return iCn;
  }

  int get_n_scat_p () const
  {
    return n_scat_p;
  }

  int get_n_scat_n () const
  {
    return n_scat_n;
  }

  unsigned int get_iC () const
  {
    return iC;
  }

  int get_n_scat () const
  {
    return n_scat;
  }

  TYPE get_probability () const
  {
    return probability;
  }

private:
  
  unsigned int BPp; // binary parity of the proton configuration (proton-neutron space) (see observables_basic_functions.cpp for definition of binary parity). That of neutrons is obtained from the parity of the GSM vector by parity conservation.


  
  // configuration indices for fixed binary parity and proton/neutron number of scattering states in the continuum (proton-neutron space for iCp, iCn, proton or neutron space for iC)

  unsigned int iCp;
  unsigned int iCn;
  unsigned int iC;



  
  // proton/neutron number of scattering states in the continuum (proton-neutron space for n_scat_p, n_scat_n, proton or neutron space for n_scat)
  
  int n_scat_p;
  int n_scat_n;
  int n_scat;



  
  TYPE probability; // probability to be in a given configuration. It is calculated by summing the squares of the components of all the Slater determinants belonging to that configuration
};

#endif


