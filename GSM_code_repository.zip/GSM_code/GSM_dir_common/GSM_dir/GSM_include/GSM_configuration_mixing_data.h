#ifndef GSMCONFIGURATIONMIXINGDATA_H
#define GSMCONFIGURATIONMIXINGDATA_H

// TYPE is double or complex
// -------------------------

class configuration_mixing_data
{
public:

  configuration_mixing_data ();

  configuration_mixing_data (const configuration_mixing_data &X);

  configuration_mixing_data (
			     const unsigned int BPp_c ,
			     const int Sp_c ,
			     const int n_spec_p_c ,  
			     const unsigned int iCp_c , 
			     const unsigned int iCn_c , 
			     const int n_scat_p_c , 
			     const int n_scat_n_c , 
			     const unsigned int iC_c , 
			     const int n_scat_c , 
			     const TYPE probability_c);

  void initialize (
		   const unsigned int BPp_c ,
		   const int Sp_c ,  
		   const int n_spec_p_c ,  
		   const unsigned int iCp_c , 
		   const unsigned int iCn_c , 
		   const int n_scat_p_c , 
		   const int n_scat_n_c , 
		   const unsigned int iC_c , 
		   const int n_scat_c , 
		   const TYPE probability_c);
  
  void initialize (const configuration_mixing_data &X);
  
  void allocate_fill (const configuration_mixing_data &X);
  
  void operator = (const configuration_mixing_data &X);
  
  unsigned int get_BPp () const
  {
    return BPp;
  }
  
  int get_n_spec_p () const
  {
    return n_spec_p;
  }
  
  int get_Sp () const
  {
    return Sp;
  }
  
  unsigned int get_iCp () const
  {
    return iCp;
  }

  unsigned int get_iCn () const
  {
    return iCn;
  }

  int get_n_scat_p () const
  {
    return n_scat_p;
  }

  int get_n_scat_n () const
  {
    return n_scat_n;
  }

  unsigned int get_iC () const
  {
    return iC;
  }

  int get_n_scat () const
  {
    return n_scat;
  }

  TYPE get_probability () const
  {
    return probability;
  }

private:
  
  unsigned int BPp; // binary parity of the proton configuration (proton-neutron space) (see observables_basic_functions.cpp for definition of binary parity). That of neutrons is obtained from the parity of the GSM vector by parity conservation.

  int Sp; // strangeness of the proton configuration (proton-neutron space). That of neutrons is obtained by strangeness conservation.

  int n_spec_p; // number of spectator pairs of the proton configuration (proton-neutron space). That of neutrons is obtained directly because the total number of spectator pairs is conserved.



  
  // configuration indices for fixed binary parity and proton/neutron number of scattering states in the continuum (proton-neutron space for iCp, iCn, proton or neutron space for iC)

  unsigned int iCp;
  unsigned int iCn;
  unsigned int iC;



  
  // proton/neutron number of scattering states in the continuum (proton-neutron space for n_scat_p, n_scat_n, proton or neutron space for n_scat)
  
  int n_scat_p;
  int n_scat_n;
  int n_scat;



  
  TYPE probability; // probability to be in a given configuration. It is calculated by summing the squares of the components of all the Slater determinants belonging to that configuration
};



  

// Print of average number of protons/neutrons (plus a few hyperons if any) in all valence shells
// ----------------------------------------------------------------------------------------------

void shell_occupations_print_pp_nn (
				    const class baryons_data &particles_data ,
				    const unsigned int BP ,
				    const bool are_scattering_configuration_probabilities_printed ,
				    const class array<class configuration_mixing_data> &configuration_mixing_tab);

void shell_occupations_print_pn (
				 const class baryons_data &particles_data ,
				 const unsigned int BP ,
				 const bool are_scattering_configuration_probabilities_printed ,
				 const class array<class configuration_mixing_data> &configuration_mixing_tab);


// Print of average number of protons/neutrons (plus a few hyperons if any) in all partial waves
// ---------------------------------------------------------------------------------------------

void partial_wave_occupations_print_pp_nn (
					   const bool is_it_scat_only ,
					   const class baryons_data &particles_data ,
					   const unsigned int BP ,
					   const class array<class configuration_mixing_data> &configuration_mixing_tab);


void partial_wave_occupations_print_pn (
					const bool is_it_scat_only ,
					const class baryons_data &particles_data ,
					const unsigned int BP ,
					const class array<class configuration_mixing_data> &configuration_mixing_tab);



  
// Information about configuration mixing printed on screen
// --------------------------------------------------------
//
// maximal_probability_configuration_print
// ---------------------------------------
// print the configuration which has maximal occupation, and this occupation

void configuration_mixing_tab_sort (
				    const int low , 
				    const int high , 
				    class array<class configuration_mixing_data> &configuration_mixing_tab);

unsigned int configuration_mixing_tab_dimension_pp_nn_calc (
							    
							    const unsigned int BP ,
							    const double M ,
							    const enum space_type space ,  
							    const bool truncation_hw ,
							    const bool truncation_ph ,
							    const int n_holes_max ,
							    const int n_scat_max ,
							    const int E_max_hw ,
							    const class baryons_data &prot_Y_data ,
							    const class baryons_data &neut_Y_data);

unsigned int configuration_mixing_tab_dimension_pn_calc (
							 const unsigned int BP ,
							 const double M ,
							 const bool truncation_hw ,
							 const bool truncation_ph ,
							 const int n_holes_max_p ,
							 const int n_holes_max_n ,
							 const int n_holes_max ,
							 const int n_scat_max_p ,
							 const int n_scat_max_n ,
							 const int n_scat_max ,
							 const int Ep_max_hw ,
							 const int En_max_hw ,
							 const int E_max_hw ,
							 const class baryons_data &prot_Y_data ,
							 const class baryons_data &neut_Y_data);

void maximal_probability_configuration_print (
					      const unsigned int BP ,
					      const enum space_type space ,  
					      const class baryons_data &prot_Y_data ,
					      const class baryons_data &neut_Y_data ,  
					      const class array<class configuration_mixing_data> &configuration_mixing_tab);

void configuration_occupation_print_pp_nn (
					   const unsigned int BP ,
					   const enum space_type space , 
					   const int n_scat_max ,
					   const class baryons_data &prot_Y_data ,
					   const class baryons_data &neut_Y_data ,
					   const bool are_scattering_configuration_probabilities_printed ,
					   const class array<class configuration_mixing_data> &configuration_mixing_tab , 
					   const double configuration_precision);

void configuration_occupation_print_pn (
					const unsigned int BP ,
					const bool truncation_ph ,
					const int n_scat_max ,
					const int n_scat_max_p ,
					const int n_scat_max_n ,
					const class baryons_data &prot_Y_data ,
					const class baryons_data &neut_Y_data ,
					const bool are_scattering_configuration_probabilities_printed ,
					const class array<class configuration_mixing_data> &configuration_mixing_tab , 
					const double configuration_precision);

#endif


