#ifndef GSMSMALLCLASSES_H
#define GSMSMALLCLASSES_H

// TYPE is double or complex
// -------------------------


class lm_struct
{
public:
  lm_struct ();

  lm_struct (const int l_c , const int ml_c);
  
  void initialize (const int l_c , const int ml_c);

  int get_l () const
  {
    return l;
  }
  
  int get_ml () const
  {
    return ml;
  }

#ifdef UseMPI
  friend MPI_Datatype MPI_Datatype_lm_struct_create ();
#endif
    
private:
  
  int l;
  
  int ml;
};

bool operator == (const class lm_struct &a , const class lm_struct &b);

bool operator != (const class lm_struct &a , const class lm_struct &b);

ostream & operator << (ostream &os , const class lm_struct &s);

#ifdef UseMPI
MPI_Datatype MPI_Datatype_lm_struct_create ();
#endif

double used_memory_calc (const class lm_struct &T);




class ljm_struct
{
public:
  
  ljm_struct ();

  ljm_struct (const int l_c , const double j_c , const double m_c , const double m_max);

  void initialize (const int l_c , const double j_c , const double m_c , const double m_max);
  
  int get_l () const
  {
    return l;
  }
  
  double get_j () const
  {
    return j;
  }
  
  double get_m () const
  {
    return m;
  }
  
  int get_ij () const
  {
    return ij;
  }
  
  int get_im () const
  {
    return im;
  }
  
#ifdef UseMPI
  friend MPI_Datatype MPI_Datatype_ljm_struct_create ();
#endif
  
private:
    
  int l;

  double j;
  double m;

  int ij;
  int im;
};

#ifdef UseMPI
MPI_Datatype MPI_Datatype_ljm_struct_create ();
#endif

double used_memory_calc (const class ljm_struct &T);

bool operator == (const class ljm_struct &a , const class ljm_struct &b);

bool operator != (const class ljm_struct &a , const class ljm_struct &b);

ostream & operator << (ostream &os , const class ljm_struct &s);



class nlj_struct
{
public:
  nlj_struct ();
  
  nlj_struct (
	      const bool S_matrix_pole_c , 
	      const bool core_state_c , 
	      const bool frozen_state_c , 
	      const bool hole_state_c , 
	      const bool OCM_valence_state_c , 
	      const bool is_it_HO_c , 
	      const bool is_it_for_HF_gs_c , 
	      const bool is_it_natural_orbital_c , 
	      const int e_trunc_c , 
	      const int n_c , 
	      const int l_c , 
	      const double j_c , 
	      const enum segment_type segment , 
	      const complex<double> &k_c , 
	      const complex<double> &w_c , 
	      const complex<double> &C0_c , 
	      const complex<double> &Cplus_c , 
	      const complex<double> &k_plus_c , 
	      const complex<double> &C0_plus_c , 
	      const complex<double> &k_minus_c , 
	      const complex<double> &C0_minus_c);
 
  void initialize (
		   const bool S_matrix_pole_c , 
		   const bool core_state_c , 
		   const bool frozen_state_c , 
		   const bool hole_state_c , 
		   const bool OCM_valence_state_c , 
		   const bool is_it_HO_c , 
		   const bool is_it_for_HF_gs_c , 
		   const bool is_it_natural_orbital_c , 
		   const int e_trunc_c , 
		   const int n_c , 
		   const int l_c , 
		   const double j_c , 
		   const enum segment_type segment , 
		   const complex<double> &k_c , 
		   const complex<double> &w_c , 
		   const complex<double> &C0_c , 
		   const complex<double> &Cplus_c , 
		   const complex<double> &k_plus_c , 
		   const complex<double> &C0_plus_c , 
		   const complex<double> &k_minus_c , 
		   const complex<double> &C0_minus_c);
		   
  bool get_S_matrix_pole () const
  {
    return S_matrix_pole;
  }
  
  bool get_core_state () const
  {
    return core_state;
  }

  bool get_frozen_state () const
  {
    return frozen_state;
  }

  bool get_hole_state () const
  {
    return hole_state;
  }

  bool get_OCM_valence_state () const
  {
    return OCM_valence_state;
  }

  bool get_is_it_HO () const
  {
    return is_it_HO;
  }

  bool get_is_it_for_HF_gs () const
  {
    return is_it_for_HF_gs;
  }

  bool get_is_it_natural_orbital () const
  {
    return is_it_natural_orbital;
  }

  int get_e_trunc () const
  {
    return e_trunc;
  }

  int get_n () const
  {
    return n;
  }

  int get_l () const
  {
    return l;
  }

  double get_j () const
  {
    return j;
  }

  enum segment_type get_segment () const
  {
    return static_cast<enum segment_type> (segment_int);
  }

  complex<double> get_k () const
  {
    return complex<double> (Re_k , Im_k);
  }

  complex<double> get_w () const
  {
    return complex<double> (Re_w , Im_w);
  }

  complex<double> get_C0 () const
  {
    return complex<double> (Re_C0 , Im_C0);
  }

  complex<double> get_Cplus () const
  {
    return complex<double> (Re_Cplus , Im_Cplus);
  }

  complex<double> get_k_plus () const
  {
    return complex<double> (Re_k_plus , Im_k_plus);
  }

  complex<double> get_C0_plus () const
  {
    return complex<double> (Re_C0_plus , Im_C0_plus);
  }

  complex<double> get_k_minus () const
  {
    return complex<double> (Re_k_minus , Im_k_minus);
  }

  complex<double> get_C0_minus () const
  {
    return complex<double> (Re_C0_minus , Im_C0_minus);
  }

  int get_ij () const
  {
    return ij;
  }

  void set_is_it_for_HF_gs (const bool is_it_for_HF_gs_c)
  {
    is_it_for_HF_gs = is_it_for_HF_gs_c;
  }
  
  int m_number_determine () const;
 
#ifdef UseMPI
  friend MPI_Datatype MPI_Datatype_nlj_struct_create ();
#endif
    
private:
  
  bool S_matrix_pole;

  bool core_state;

  bool frozen_state;

  bool hole_state;

  bool OCM_valence_state;

  bool is_it_HO;

  bool is_it_for_HF_gs;

  bool is_it_natural_orbital;
  
  int e_trunc;
  
  int n;
  int l;

  int ij;

  int segment_int;

  double j;

  double Re_k , Re_w , Re_C0 , Re_Cplus , Re_k_plus , Re_C0_plus , Re_k_minus , Re_C0_minus;
  double Im_k , Im_w , Im_C0 , Im_Cplus , Im_k_plus , Im_C0_plus , Im_k_minus , Im_C0_minus;
};


#ifdef UseMPI
MPI_Datatype MPI_Datatype_nlj_struct_create ();
#endif

double used_memory_calc (const class nlj_struct &T);

bool operator == (const class nlj_struct &a , const class nlj_struct &b);
bool operator != (const class nlj_struct &a , const class nlj_struct &b);

bool operator >  (const class nlj_struct &a , const class nlj_struct &b);
bool operator >= (const class nlj_struct &a , const class nlj_struct &b);

bool operator <  (const class nlj_struct &a , const class nlj_struct &b);
bool operator <= (const class nlj_struct &a , const class nlj_struct &b);

ostream & operator << (ostream &os , const class nlj_struct &s);





class nljm_struct
{
public:
  nljm_struct ();

  nljm_struct (
	       const int n_c ,
	       const int l_c ,
	       const double j_c ,
	       const double m_c , 
	       const bool S_matrix_pole_c ,
	       const bool core_state_c , 
	       const bool frozen_state_c , 
	       const int e_trunc_c , 
	       const unsigned short int shell_index_c ,
	       const double m_max);
  
  void initialize (
		   const int n_c ,
		   const int l_c ,
		   const double j_c ,
		   const double m_c , 
		   const bool S_matrix_pole_c ,
		   const bool core_state_c , 
		   const bool frozen_state_c , 
		   const int e_trunc_c , 
		   const unsigned short int shell_index_c ,
		   const double m_max);
  
  class ljm_struct get_ljm_part () const
  {
    return ljm_part;
  }

  bool get_S_matrix_pole () const
  {
    return S_matrix_pole;
  }
  
  bool get_core_state () const
  {
    return core_state;
  }
  
  bool get_frozen_state () const
  {
    return frozen_state;
  }
  
  int get_n () const
  {
    return n;
  }

  int get_l () const
  {
    return ljm_part.get_l ();
  }

  double get_j () const
  {
    return ljm_part.get_j ();
  }

  double get_m () const
  {
    return ljm_part.get_m ();
  }
    
  unsigned short int get_shell_index () const
  {
    return shell_index;
  }
  
  unsigned short int get_bp () const
  {
    return bp;
  }
  
  unsigned short int get_bin_phase_jm () const
  {
    return bin_phase_jm;
  }

  int get_e_trunc () const
  {
    return e_trunc;
  }
  
  int get_ij () const
  {
    return ljm_part.get_ij ();
  }
  
  int get_im () const
  {
    return ljm_part.get_im ();
  }

#ifdef UseMPI
  friend MPI_Datatype MPI_Datatype_nljm_struct_create ();
#endif
  
private:

  class ljm_struct ljm_part;
  
  bool S_matrix_pole;
  
  bool core_state;
  
  bool frozen_state; 
  
  int n;
  
  int e_trunc;

  unsigned short int shell_index;

  unsigned short int bp;

  unsigned short int bin_phase_jm;
};




#ifdef UseMPI
MPI_Datatype MPI_Datatype_nljm_struct_create ();
#endif

double used_memory_calc (const class nljm_struct &T);


bool same_Yljm (const class nljm_struct &phi0 , const class nljm_struct &phi1);
bool same_Yljm (const class nljm_struct &phi0 , const class ljm_struct &phi1);
bool same_Yljm (const class ljm_struct &phi0 , const class nljm_struct &phi1);

bool same_nlj (const class nlj_struct &phi0 , const class nlj_struct &phi1);
bool same_lj  (const class nlj_struct &phi0 , const class nlj_struct &phi1);

bool same_lj   (const class nljm_struct &phi0 , const class nljm_struct &phi1);
bool same_nlj  (const class nljm_struct &phi0 , const class nljm_struct &phi1);
bool same_nljm (const class nljm_struct &phi0 , const class nljm_struct &phi1);

bool same_lj (const class nljm_struct &phi , const class nlj_struct &shell);
bool same_lj (const class nlj_struct &shell , const class nljm_struct &phi);

bool same_nlj (const class nljm_struct &phi , const class nlj_struct &shell);
bool same_nlj (const class nlj_struct &shell , const class nljm_struct &phi);



ostream & operator << (ostream &os , const class nljm_struct &phi);

bool operator == (const class nljm_struct &a , const class nljm_struct &b);
bool operator != (const class nljm_struct &a , const class nljm_struct &b);

bool operator >  (const class nljm_struct &a , const class nljm_struct &b);
bool operator >= (const class nljm_struct &a , const class nljm_struct &b);

bool operator <  (const class nljm_struct &a , const class nljm_struct &b);
bool operator <= (const class nljm_struct &a , const class nljm_struct &b);



class delta_force  // V=\delta (\vec{r1} - \vec{r2}).(a + b.P12\sigma) : zero range force with spin exchange
{
public:
  delta_force ();

  delta_force (
	       const double a_c ,
	       const double b_c ,
	       const double R0_c ,
	       const double Vo_c);

  void initialize (
		   const double a_c ,
		   const double b_c ,
		   const double R0_c ,
		   const double Vo_c);
  
  double get_a () const
  {
    return a;
  }
  
  double get_b () const
  {
    return b;
  }
  
  double get_R0 () const
  {
    return R0;
  }
  
  double get_Vo () const
  {
    return Vo;
  }
  
private:

  double a;
  double b;

  double R0;

  double Vo;
};

double used_memory_calc (const class delta_force &T);














class CG_str
{
public:

  CG_str ();
  
  explicit CG_str (const double m_max_c);

  CG_str (const class CG_str &X);
  
  void allocate_calc (const double m_max_c);

  void allocate_fill (const class CG_str &X);

  void deallocate ();

  double operator() (
		     const double j0 ,
		     const double m0 , 
		     const double j1 ,
		     const double m1 , 
		     const double J ,
		     const double M) const;

  friend double used_memory_calc (const class CG_str &T);
 
private:
  
  double m_max;
  
  class array<double> CG_table;
};




class one_body_indices_str
{
public:

  one_body_indices_str ();
  
  one_body_indices_str (
			const int nmax ,
			const int lmax ,
			const unsigned int N_nlj ,
			const double m_max);

  one_body_indices_str (const class one_body_indices_str &X);

  void allocate (
		 const int nmax ,
		 const int lmax ,
		 const unsigned int N_nlj_c ,
		 const double m_max);
  
  void allocate_fill (const class one_body_indices_str &X);

  void deallocate ();

  unsigned short int & operator () (const unsigned int n , const unsigned int l , const double j , const double m) const;

  unsigned short int & operator () (const unsigned int s , const int im) const;

  friend double used_memory_calc (const class one_body_indices_str &T);
 
private:

  class nljm_table<unsigned short int> states_indices_from_nljm;
  
  class array<unsigned short int> states_indices_from_shell;
};



class JT_coupled_TBME
{
public:

  JT_coupled_TBME ();

  JT_coupled_TBME (
		   const enum space_type TBME_space ,
		   const int J_c ,
		   const int T_c ,
		   const TYPE Vabcd_c ,
		   const int n_c[] ,
		   const int l_c[] ,
		   const double j_c[]);
  
  void initialize (
		   const enum space_type TBME_space ,
		   const int J_c ,
		   const int T_c ,
		   const TYPE Vabcd_c ,
		   const int n_c[] ,
		   const int l_c[] ,
		   const double j_c[]);	   
  
  enum space_type get_TBME_space () const
  {
    return static_cast<enum space_type> (TBME_space_int);
  }
  
  int get_J () const
  {
    return J;
  }
  
  int get_T () const
  {
    return T;
  }
  
  TYPE get_Vabcd () const
  {
    return generate_scalar<TYPE> (Re_Vabcd , Im_Vabcd);
  }
  
  int get_n (const unsigned int index) const
  {
    return n[index];
  }
  
  int get_l (const unsigned int index) const
  {
    return l[index];
  }
  
  double get_j (const unsigned int index) const
  {
    return j[index];
  }

#ifdef UseMPI
  friend MPI_Datatype MPI_Datatype_JT_coupled_TBME_create ();
#endif
  
private:
  
  int TBME_space_int;

  int J;
  int T;

  double Re_Vabcd;
  double Im_Vabcd;
  
  int n[4];
  int l[4];
  
  double j[4];
};


istream & operator >> (istream &is , class JT_coupled_TBME &c);


#ifdef UseMPI
MPI_Datatype MPI_Datatype_JT_coupled_TBME_create ();
#endif

double used_memory_calc (const class JT_coupled_TBME &T);


class OBMEs_inter_set_str
{
public:

  OBMEs_inter_set_str ();
  
  explicit OBMEs_inter_set_str (const unsigned int N_nlj);
  
  explicit OBMEs_inter_set_str (
				const unsigned int N_nlj ,
				const class array<class nljm_struct> &phi_table);

  OBMEs_inter_set_str (const class OBMEs_inter_set_str &X);

  void allocate (const unsigned int N_nlj);
  
  void allocate (
		 const unsigned int N_nlj ,
		 const class array<class nljm_struct> &phi_table);

  void allocate_fill (const class OBMEs_inter_set_str &X);

  void deallocate ();

  bool is_it_filled () const
  {
    return inter_tab.is_it_filled ();
  }
  
  class array<TYPE> & operator () (const enum interaction_type Op_inter);
  
  const class array<TYPE> & operator () (const enum interaction_type Op_inter) const;

  TYPE coupled_OBME (
		     const enum interaction_type Op_inter ,
		     const unsigned int s_in ,
		     const unsigned int s_out) const;
  
  TYPE uncoupled_OBME (
		       const enum interaction_type Op_inter ,
		       const unsigned int state_in ,
		       const unsigned int state_out) const;
 
  void read_disk (const enum interaction_type inter , const string &debut_file_name);

  void copy_disk (const enum interaction_type inter , const string &debut_file_name) const;
 
#ifdef UseMPI
  void MPI_Send  (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv  (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C);
  void MPI_Reduce    (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif
  
  friend double used_memory_calc (const class OBMEs_inter_set_str &T);

private:

  class array<int> im_table;

  class array<unsigned int> shells_indices;

  class array<TYPE> inter_tab;

  class array<TYPE> nuclear_tab;

  class array<TYPE> kinetic_tab;

  class array<TYPE> Coulomb_tab;

  class array<TYPE> WS_grad_tab;

  class array<TYPE> hole_dc_tab; // hole_dc_tab is for hole_double_counting OBMEs (see GSM_hole_double_counting.cpp)
};




class OBMEs_multipole_square_str
{
public:

  OBMEs_multipole_square_str ();
  
  explicit OBMEs_multipole_square_str (const int lmax , const unsigned int N_nlj);
  
  explicit OBMEs_multipole_square_str (
				       const int lmax , 
				       const unsigned int N_nlj ,
				       const class array<class nljm_struct> &phi_table);

  OBMEs_multipole_square_str (const class OBMEs_multipole_square_str &X);

  void allocate (const int lmax , const unsigned int N_nlj);
  
  void allocate (
		 const int lmax ,
		 const unsigned int N_nlj ,
		 const class array<class nljm_struct> &phi_table);

  void allocate_fill (const class OBMEs_multipole_square_str &X);

  void deallocate ();

  void zero ();

  bool is_it_filled () const
  {
    return rL_YL_square_tab.is_it_filled ();
  }

  void coupled_OBME_fill (
			  const int L ,
			  const unsigned int s_in ,
			  const unsigned int s_out ,
			  const TYPE coupled_OBME_value);
  
  TYPE coupled_OBME (
		     const int L ,
		     const unsigned int s_in ,
		     const unsigned int s_out) const;
  
  TYPE uncoupled_OBME (
		       const int L ,
		       const unsigned int state_in ,
		       const unsigned int state_out) const;
 
  void read_disk (const string &debut_file_name);

  void copy_disk (const string &debut_file_name) const;
 
#ifdef UseMPI
  void MPI_Send  (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv  (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C);
  void MPI_Reduce    (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif
  
  friend double used_memory_calc (const class OBMEs_multipole_square_str &T);

private:

  class array<int> im_table;

  class array<unsigned int> shells_indices;

  class array<TYPE> rL_YL_square_tab;
};




class OBMEs_CM_set_str
{
public:

  OBMEs_CM_set_str ();

  explicit OBMEs_CM_set_str (const unsigned int N_nlj);
			     
  explicit OBMEs_CM_set_str (
			     const unsigned int N_nlj ,
			     const class array<class nljm_struct> &phi_table);

  OBMEs_CM_set_str (const class OBMEs_CM_set_str &X);

  void allocate (const unsigned int N_nlj);
		 
  void allocate (
		 const unsigned int N_nlj ,
		 const class array<class nljm_struct> &phi_table);

  void allocate_fill (const class OBMEs_CM_set_str &X);

  void allocate ();
  
  void deallocate ();

  bool is_it_filled () const
  {
    return Hcm_tab.is_it_filled ();
  }

  class array<TYPE> & operator() (const enum operator_type CM_op_inter);
  
  const class array<TYPE> & operator() (const enum operator_type CM_op_inter) const;

  TYPE coupled_OBME (
		     const enum operator_type CM_op_inter ,
		     const unsigned int s_in ,
		     const unsigned int s_out) const;
  
  TYPE uncoupled_OBME (
		       const enum operator_type CM_op_inter ,
		       const unsigned int state_in ,
		       const unsigned int state_out) const;
  
  void read_disk (const bool is_it_HO_expansion , const string &debut_file_name);

  void copy_disk (const bool is_it_HO_expansion , const string &debut_file_name) const;

#ifdef UseMPI
  void MPI_Send  (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv  (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C);
  void MPI_Reduce    (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif
  
  friend double used_memory_calc (const class OBMEs_CM_set_str &T);
 
private:

  class array<int> im_table;
  class array<int> ij_table;

  class array<unsigned int> shells_indices;

  class array<double> ME_dereducing_factors;
  
  class array<TYPE> Hcm_tab;
  
  class array<TYPE> CM_kinetic_tab;
  
  class array<TYPE> L_reduced_tensor_tab;
  
  class array<TYPE> A_dagger_CM_HO_reduced_tensor_tab;
  
  class array<TYPE> rms_radius_prot_tab;

  class array<TYPE> rms_radius_neut_tab;
};








class OBMEs_multipole_reduced_str
{
public:

  OBMEs_multipole_reduced_str ();
  
  explicit OBMEs_multipole_reduced_str (const int lmax , const unsigned int N_nlj);

  OBMEs_multipole_reduced_str (const class OBMEs_multipole_reduced_str &X);

  void allocate (const int lmax , const unsigned int N_nlj);

  void allocate_fill (const class OBMEs_multipole_reduced_str &X);

  void deallocate ();

  bool is_it_filled () const
  {
    return rL_YL_reduced_tab.is_it_filled ();
  }

  void zero ();

  void reduced_OBME_fill (
			  const int L ,
			  const unsigned int s_in ,
			  const unsigned int s_out ,
			  const TYPE reduced_OBME_value);
  
  TYPE reduced_OBME (
		     const int L ,
		     const unsigned int s_in ,
		     const unsigned int s_out) const;
   
  void read_disk (const string &debut_file_name);

  void copy_disk (const string &debut_file_name) const;
 
#ifdef UseMPI
  void MPI_Send  (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv  (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C);
  void MPI_Reduce    (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif
  
  friend double used_memory_calc (const class OBMEs_multipole_reduced_str &T);

private:

  class array<TYPE> rL_YL_reduced_tab;
};





class multipolar_expansion_str
{
public:

  multipolar_expansion_str ();
  
  multipolar_expansion_str (const double jmax_c);

  multipolar_expansion_str (const class multipolar_expansion_str &X);

  void allocate_calc (const double jmax_c);

  void allocate_fill (const class multipolar_expansion_str &X);
  
  void deallocate ();

  double operator() (
		     const int l0 , const double j0 , 
		     const int l1 , const double j1 , 
		     const int l2 , const double j2 , 
		     const int l3 , const double j3 , 
		     const int ll ,
		     const int J) const;

  double angular_TBME_MSGI_J (
			      const int l0 , const double j0 , 
			      const int l1 , const double j1 , 
			      const int l2 , const double j2 , 
			      const int l3 , const double j3 , 
			      const int J) const;
  
  friend double used_memory_calc (const class multipolar_expansion_str &T);
 
private:

  double jmax;
  
  int two_jmax;
  
  class array<double> angular_table;
};








class Psigma_str
{
public:
  
  Psigma_str ();

  Psigma_str (const int lmax_c);

  Psigma_str (const class Psigma_str &X);
 
  void allocate_calc (const int lmax_c);

  void allocate_fill (const class Psigma_str &X);

  void deallocate ();

  double operator() (
		     const int l0 , const double j0 , 
		     const int l1 , const double j1 , 
		     const int l2 , const double j2 , 
		     const int l3 , const double j3 , 
		     const int J) const;
  
  friend double used_memory_calc (const class Psigma_str &T);
  
private:

  int lmax;
  
  double jmax;
  
  class array<double> angular_table;
};






class SGI_radial_tabs_str
{
public:

  SGI_radial_tabs_str ();
  
  SGI_radial_tabs_str (
		       const class interaction_class &inter_data , 
		       const unsigned int N_nlj_res , 
		       const unsigned int N_bef_R_GL);

  SGI_radial_tabs_str (const class SGI_radial_tabs_str &X);
   
  void allocate (
		 const class interaction_class &inter_data , 
		 const unsigned int N_nlj_res , 
		 const unsigned int N_bef_R_GL);

  void allocate_fill (const class SGI_radial_tabs_str &X);
  
  void deallocate ();

  class array<complex<double> > & get_direct_tab ()
  {
    return direct_tab;
  }
  
  const class array<complex<double> > & get_direct_tab () const
  {
    return direct_tab;
  }
  
  class array<complex<double> > & get_exchange_tab ()
  {
    return exchange_tab;
  }
  
  const class array<complex<double> > & get_exchange_tab () const
  {
    return exchange_tab;
  }

  friend double used_memory_calc (const class SGI_radial_tabs_str &T);
 
private:

  class array<complex<double> > direct_tab;

  class array<complex<double> > exchange_tab;
};


#endif


