#ifndef EMTRANSITIONSCOMMON_H
#define EMTRANSITIONSCOMMON_H

// TYPE is double or complex
// -------------------------

namespace EM_transitions_common
{	
  void EM_suboperator_OBMEs_reduced_calc (
					  const enum EM_suboperator_type EM_suboperator , 
					  const enum radial_operator_type radial_operator , 
					  const TYPE &q , 
					  const int L , 
					  const int Lc , 
					  const bool is_it_longwavelength_approximation , 
					  const bool is_it_HO_expansion , 
					  const class interaction_class &inter_data , 
					  const class nucleons_data &data , 
					  class array<TYPE> &OBMEs);
 
  void OBMEs_electric_reduced_calc (
				    const TYPE &q , 
				    const int L , 
				    const int Lc , 
				    const bool is_it_longwavelength_approximation , 
				    const bool is_it_HO_expansion , 
				    const class interaction_class &inter_data , 
				    const class nucleons_data &data , 
				    class array<TYPE> &electric_OBMEs);
  
  void OBMEs_magnetic_reduced_calc (
				    const TYPE &q , 
				    const int L , 
				    const int Lc , 
				    const bool is_it_longwavelength_approximation , 
				    const bool is_it_HO_expansion , 
				    const class interaction_class &inter_data , 
				    const class nucleons_data &data , 
				    class array<TYPE> &magnetic_OBMEs);
 
  void OBMEs_reduced_calc (
			   const enum EM_type EM , 
			   const TYPE &q , 
			   const int L , 
			   const int Lc , 
			   const bool is_it_longwavelength_approximation , 
			   const bool is_it_HO_expansion , 
			   const class interaction_class &inter_data , 
			   const class nucleons_data &data , 
			   class array<TYPE> &OBMEs);
}

#endif


