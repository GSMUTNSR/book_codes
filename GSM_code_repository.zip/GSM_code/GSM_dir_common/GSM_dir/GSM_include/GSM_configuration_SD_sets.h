#ifndef GSMCONFIGURATIONSDSETS_H
#define GSMCONFIGURATIONSDSETS_H

// TYPE is double or complex
// -------------------------

namespace configuration_SD_sets
{
  void configuration_SD_tables_alloc_calc (
					   const bool is_there_cout ,
					   const bool is_it_only_basis , 
					   const bool is_it_2D_partitioning , 
					   const class input_data_str &input_data , 
					   class nucleons_data &data);

  void configuration_SD_tables_pp_nn_alloc_calc (
						 const bool is_there_cout ,
						 const bool is_it_only_basis , 
						 const bool is_it_2D_partitioning , 
						 const class input_data_str &input_data ,
						 class nucleons_data &prot_data , 
						 class nucleons_data &neut_data);
}

#endif

