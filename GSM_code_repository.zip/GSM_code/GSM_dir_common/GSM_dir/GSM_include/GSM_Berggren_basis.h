#ifndef GSMBERGGRENBASIS_H
#define GSMBERGGRENBASIS_H

// TYPE is double or complex
// -------------------------

namespace Berggren_basis
{
  void HF_potentials_effective_mass_Ueq_source_tabs_alloc_calc (
								const double R , 
								const double step_bef_R_uniform ,
								const enum potential_type H_potential , 
								const enum particle_type particle , 
								const int ZY_charge_basis_potential_pos , 
								const int ZY_charge_basis_potential_neg , 
								const double R_charge , 
								const int n , 
								const int l , 
								const double j , 
								const class nlj_table<complex<double> > &Ueq_finite_range_tab_uniform , 
								const class nlj_table<complex<double> > &source_tab_uniform , 
								class potentials_effective_mass &T);

  void wave_function_calculation (
				  const bool is_there_cout , 
				  const class input_data_str &input_data ,
				  const class baryons_data &neut_Y_data_like , 
				  const unsigned int shell_index , 
				  class baryons_data &particles_data);

  void print_overlaps_OCM (const class baryons_data &particles_data);

  void print_overlaps (const class baryons_data &particles_data);

  void radial_wfs_overlaps_print_alloc_calc (
					     const bool is_there_cout , 
					     const class input_data_str &input_data ,
					     const class baryons_data &neut_Y_data_like , 
					     class baryons_data &particles_data);

  void single_particle_indices_radial_wfs_alloc_calc (
						      const bool is_there_cout , 
						      const class input_data_str &input_data ,
						      const class baryons_data &neut_Y_data_like , 
						      class baryons_data &particles_data);

  void single_particle_indices_radial_wfs_pn_alloc_calc (
								const bool is_there_cout , 
								const class input_data_str &input_data ,
								class baryons_data &prot_Y_data , 
								class baryons_data &neut_Y_data);
  
  void best_hbar_omega_b_lab_print (
				    const enum interaction_type inter ,
				    const class baryons_data &data);
}

#endif


