#ifndef GSMPAIRINGDENSITYTBMES_H
#define GSMPAIRINGDENSITYTBMES_H

// TYPE is double or complex
// -------------------------

namespace pair_density_TBMEs
{
  void radial_OBMEs_calc (
			  const bool is_it_radial ,
			  const bool is_it_Gauss_Legendre ,
			  const class nucleons_data &data ,
			  class array<TYPE> &OBMEs_shells);

  void coupled_TBMEs_pp_nn_calc (
				 const int J , 
				 const class nucleons_data &data , 
				 const class array<TYPE> &rk_OBMEs , 
				 const class pair_str &pair_in , 
				 const class pair_str &pair_out , 
				 class array<TYPE> &density_TBMEs);

  void coupled_TBMEs_pn_calc (
			      const class nucleons_data &prot_data , 
			      const class nucleons_data &neut_data , 
			      const class array<TYPE> &rk_OBMEs_prot , 
			      const class array<TYPE> &rk_OBMEs_neut , 
			      const class pair_str &pair_in , 
			      const class pair_str &pair_out , 
			      class array<TYPE> &density_TBMEs);

  void coupled_TBMEs_calc (
			   const enum space_type space , 
			   const int J , 
			   const class nucleons_data &prot_data , 
			   const class nucleons_data &neut_data , 
			   const class array<TYPE> &rk_OBMEs_prot , 
			   const class array<TYPE> &rk_OBMEs_neut , 
			   const class pair_str &pair_in , 
			   const class pair_str &pair_out , 
			   class array<TYPE> &density_TBMEs);

  void uncoupled_TBMEs_pp_nn_calc (
				   const class nucleons_data &data , 
				   const class array<TYPE> &rk_OBMEs , 
				   const unsigned int s0 , 
				   const unsigned int s1 , 
				   const unsigned int s2 , 
				   const unsigned int s3 , 
				   class array<TYPE> &density_TBMEs);

  void uncoupled_TBMEs_pn_calc (
				const class nucleons_data &prot_data , 
				const class nucleons_data &neut_data , 
				const class array<TYPE> &rk_OBMEs_prot , 
				const class array<TYPE> &rk_OBMEs_neut , 
				const unsigned int s0 , 
				const unsigned int s1 , 
				const unsigned int s2 , 
				const unsigned int s3 , 
				class array<TYPE> &density_TBMEs);
}

#endif


