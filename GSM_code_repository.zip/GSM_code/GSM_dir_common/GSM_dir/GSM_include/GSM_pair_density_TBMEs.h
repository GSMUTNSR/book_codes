#ifndef GSMPAIRDENSITYTBMES_H
#define GSMPAIRDENSITYTBMES_H

// TYPE is double or complex
// -------------------------

namespace pair_density_TBMEs
{
  void radial_OBMEs_calc (
			  const bool is_it_radial ,
			  const bool is_it_Gauss_Legendre ,
			  const class baryons_data &data ,
			  class array<TYPE> &OBMEs_shells);

  void coupled_TBMEs_pp_nn_calc (
				 const int J , 
				 const class baryons_data &data , 
				 const class array<TYPE> &rk_OBMEs , 
				 const class pair_str &pair_in , 
				 const class pair_str &pair_out , 
				 class array<TYPE> &density_TBMEs);

  void coupled_TBMEs_pn_calc (
			      const class baryons_data &prot_Y_data , 
			      const class baryons_data &neut_Y_data , 
			      const class array<TYPE> &rk_OBMEs_p , 
			      const class array<TYPE> &rk_OBMEs_n , 
			      const class pair_str &pair_in , 
			      const class pair_str &pair_out , 
			      class array<TYPE> &density_TBMEs);

  void coupled_TBMEs_calc (
			   const enum space_type space , 
			   const int J , 
			   const class baryons_data &prot_Y_data , 
			   const class baryons_data &neut_Y_data , 
			   const class array<TYPE> &rk_OBMEs_p , 
			   const class array<TYPE> &rk_OBMEs_n , 
			   const class pair_str &pair_in , 
			   const class pair_str &pair_out , 
			   class array<TYPE> &density_TBMEs);

  void uncoupled_TBMEs_pp_nn_calc (
				   const class baryons_data &data , 
				   const class array<TYPE> &rk_OBMEs , 
				   const unsigned int s0 , 
				   const unsigned int s1 , 
				   const unsigned int s2 , 
				   const unsigned int s3 , 
				   class array<TYPE> &density_TBMEs);

  void uncoupled_TBMEs_pn_calc (
				const class baryons_data &prot_Y_data , 
				const class baryons_data &neut_Y_data , 
				const class array<TYPE> &rk_OBMEs_p , 
				const class array<TYPE> &rk_OBMEs_n , 
				const unsigned int s0 , 
				const unsigned int s1 , 
				const unsigned int s2 , 
				const unsigned int s3 , 
				class array<TYPE> &density_TBMEs);
}

#endif


