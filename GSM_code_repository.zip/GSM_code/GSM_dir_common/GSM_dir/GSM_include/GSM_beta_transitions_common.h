#ifndef GSMBETATRANSITIONSCOMMON_H
#define GSMBETATRANSITIONSCOMMON_H

// TYPE is double or complex
// -------------------------

namespace beta_transitions_common
{
  void beta_suboperator_OBMEs_reduced_calc (
					    const bool is_it_HO_expansion , 
					    const enum radial_operator_type radial_operator , 
					    const enum beta_suboperator_type beta_suboperator , 
					    const class interaction_class &inter_data , 
					    const class baryons_data &data_in , 
					    const class baryons_data &data_out , 
					    class array<TYPE> &OBMEs);
  
  const class baryons_data & data_in_determine (
						 const enum beta_pm_type beta_pm , 
						 const class baryons_data &prot_Y_data , 
						 const class baryons_data &neut_Y_data);
  
  const class baryons_data & data_out_determine (
						  const enum beta_pm_type beta_pm , 
						  const class baryons_data &prot_Y_data , 
						  const class baryons_data &neut_Y_data);

  void allowed_calc_print (
			   const enum beta_pm_type beta_pm , 
			   const int A , 
			   const int Z_daughter ,  
			   const double W0 , 
			   const double J_IN , 
			   const class array<TYPE> &beta_suboperators_tab);

  void first_forbidden_calc_print (
				   const enum beta_pm_type beta_pm , 
				   const int A , 
				   const int Z_daughter ,  
				   const double W0 , 
				   const double J_IN , 
				   const class array<TYPE> &beta_suboperators_tab);
  
  void calc_print (
		   const enum beta_type beta , 
		   const enum beta_pm_type beta_pm , 
		   const int A , 
		   const int Z_daughter ,  
		   const double W0 , 
		   const double J_IN , 
		   const class array<TYPE> &beta_suboperators_tab);

  namespace strength
  {
    void allowed_calc_store (
			     const class array<double> &r_bef_R_tab , 
			     const string &beta_strength_string , 
			     const class array<TYPE> &beta_suboperators_tab);

    void first_forbidden_calc_store (
				     const class array<double> &r_bef_R_tab , 
				     const string &beta_strength_string , 
				     const class array<TYPE> &beta_suboperators_tab);
  
    void calc_store (
		     const enum beta_type beta ,
		     const class array<double> &r_bef_R_tab , 
		     const string &beta_strength_string , 
		     const class array<TYPE> &beta_suboperators_tab);

  }
}

#endif


