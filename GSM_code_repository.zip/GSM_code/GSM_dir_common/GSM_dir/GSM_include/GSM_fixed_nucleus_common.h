#ifndef FIXED_NUCLEUS_COMMON_H
#define FIXED_NUCLEUS_COMMON_H

namespace fixed_nucleus_common
{
  void OBMEs_inter_calc (
			 const class interaction_class &inter_data ,
			 const class baryons_data &neut_Y_data ,
			 class baryons_data &data);
  
  void OBMEs_hole_double_counting_calc_remove (
					       const class input_data_str &input_data , 
					       const class TBMEs_class &TBMEs_pn , 
					       const class interaction_class &inter_data ,
					       class baryons_data &prot_Y_data ,
					       class baryons_data &neut_Y_data);
  
  void OBMEs_TBMEs_calc (
			 const class input_data_str &input_data , 
			 const class array<class interaction_class > &inter_data_units , 
			 const class interaction_class &inter_data_Coulomb , 
			 const class vector_class<double> &FHT_EFT_parameters , 
			 class interaction_class &inter_data , 
			 class TBMEs_class &TBMEs_pn , 
			 class TBMEs_class &TBMEs_cv , 
			 class baryons_data &prot_Y_data , 
			 class baryons_data &neut_Y_data);

  void OBMEs_TBMEs_grad_calc (
			      const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
			      const class array<bool> &is_there_l_dependence_from_fit_index , 
			      const class array<int> &l_from_fit_index , 
			      const class input_data_str &input_data , 
			      const class array<class interaction_class > &inter_data_units , 
			      const unsigned int fit_index , 
			      class interaction_class &inter_data , 
			      class TBMEs_class &TBMEs_pn , 
			      class TBMEs_class &TBMEs_cv , 
			      class baryons_data &prot_Y_data , 
			      class baryons_data &neut_Y_data);
}
#endif


