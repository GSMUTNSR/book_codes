#ifndef GSMINPUTSMISC_HPP
#define GSMINPUTSMISC_HPP

class GSM_vector;
class H_class;
using namespace Wigner_signs;

// TYPE is double or complex
// -------------------------

namespace inputs_misc
{
  void is_it_OCM_HO_core_determine (
				    const class input_data_str &input_data , 
				    class nucleons_data &prot_data , 
				    class nucleons_data &neut_data);

  int Zval_max_all_determine (const class array<class input_data_str> &input_data_tab);
  int Nval_max_all_determine (const class array<class input_data_str> &input_data_tab);

  int lmax_p_all_determine (const class array<class input_data_str> &input_data_tab);
  int lmax_n_all_determine (const class array<class input_data_str> &input_data_tab);

  unsigned int BPmin_global_pp_all_determine (const class array<class input_data_str> &input_data_tab);
  unsigned int BPmax_global_pp_all_determine (const class array<class input_data_str> &input_data_tab);

  unsigned int BPmin_global_nn_all_determine (const class array<class input_data_str> &input_data_tab);
  unsigned int BPmax_global_nn_all_determine (const class array<class input_data_str> &input_data_tab);

  unsigned int BPmin_global_pn_all_determine (const class array<class input_data_str> &input_data_tab);
  unsigned int BPmax_global_pn_all_determine (const class array<class input_data_str> &input_data_tab);

  int Jmin_global_pp_all_determine (const class array<class input_data_str> &input_data_tab);
  int Jmax_global_pp_all_determine (const class array<class input_data_str> &input_data_tab);
  
  int Jmin_global_nn_all_determine (const class array<class input_data_str> &input_data_tab);
  int Jmax_global_nn_all_determine (const class array<class input_data_str> &input_data_tab);

  int Jmin_global_pn_all_determine (const class array<class input_data_str> &input_data_tab);
  int Jmax_global_pn_all_determine (const class array<class input_data_str> &input_data_tab);

  int Jmin_global_pp_opp_all_determine (const class array<class input_data_str> &input_data_tab);
  int Jmax_global_pp_opp_all_determine (const class array<class input_data_str> &input_data_tab);
  
  int Jmin_global_nn_opp_all_determine (const class array<class input_data_str> &input_data_tab);
  int Jmax_global_nn_opp_all_determine (const class array<class input_data_str> &input_data_tab);

  int Jmin_global_pn_opp_all_determine (const class array<class input_data_str> &input_data_tab);
  int Jmax_global_pn_opp_all_determine (const class array<class input_data_str> &input_data_tab);

  bool OCM_valence_state_determine (
				    const class array<class nlj_struct> &shells_qn , 
				    const bool is_it_COSM , 
				    const bool core_state , 
				    const int l , 
				    const double j);

  void valence_particle_number_read (
				     const bool is_it_basis_only , 
				     const enum space_type space , 
				     const enum potential_type H_potential , 
				     int &Zval , 
				     int &Nval);

  void SDI_data_read (
		      double &a , 
		      double &b , 
		      double &R0 , 
		      double &V_SDI);

  void V_Gaussian_consts_read (
			       const enum space_type space ,
			       const int Jmin , 
			       const int Jmax , 
			       const int Jmin_opp , 
			       const int Jmax_opp , 
			       class array<double> &V_Gaussian_consts);

  void SGI_MSGI_data_read  (
			    const enum space_type space ,
			    const int Jmin , 
			    const int Jmax , 
			    const int Jmin_opp , 
			    const int Jmax_opp , 
			    double &R0 , 
			    double &mu , 
			    class array<double> &V_Gaussian_consts);

  void Minnesota_data_read (
			    const enum space_type space ,
			    double V0_Minnesota[] , 
			    double rho_Minnesota[] , 
			    double &u_Minnesota , 
			    double &nu_three_body_like , 
			    double &V_three_body_like , 
			    const int Jmin , 
			    const int Jmax , 
			    const int Jmin_opp , 
			    const int Jmax_opp , 
			    class array<double> &V_Gaussian_consts);
  
  void FHT_read (
		 const enum space_type space ,
		 double &V0_ctr_ot , 
		 double &V0_ctr_et , 
		 double &V0_ctr_os , 
		 double &V0_ctr_es , 
		 double &V0_so_ot , 
		 double &V0_so_et , 
		 double &V0_t_ot , 
		 double &V0_t_et , 
		 const int Jmin , 
		 const int Jmax ,  
		 const int Jmin_opp , 
		 const int Jmax_opp , 
		 class array<double> &V_Gaussian_consts);

  void EFT_read (	
		 const enum space_type space ,	 
		 double &VS_const_LO_T0 ,
		 double &VS_const_LO_T1 ,
		 double &VT_sigma_product_LO_T0 ,
		 double &VT_sigma_product_LO_T1 ,
		 double &V1_q2_NLO ,
		 double &V2_k2_NLO ,
		 double &V3_q2_sigma_product_NLO ,
		 double &V4_k2_sigma_product_NLO ,
		 double &V5_k2_sigma_q_vector_k_NLO , 
		 double &V6_sigma_q_product_NLO ,
		 double &V7_sigma_k_product_NLO);

  void KKNN_potential_data_read (
				 double V0_KKNN[] , 
				 double rho_KKNN[] , 
				 double Vls_KKNN[] , 
				 double rho_ls_KKNN[]);

  void WS_nucleus_data_read (
			     const int lmax , 
			     class array<double> &d_tab , 
			     class array<double> &R0_tab , 
			     class array<double> &Vo_tab , 
			     class array<double> &Vso_tab);

  void WS_nucleus_data_prot_neut_read ( 
				       const enum space_type space , 
				       const int lmax_p , 
				       const int lmax_n , 
				       class array<double> &prot_d_tab , 
				       class array<double> &prot_R0_tab , 
				       class array<double> &prot_Vo_tab , 
				       class array<double> &prot_Vso_tab , 
				       class array<double> &neut_d_tab , 
				       class array<double> &neut_R0_tab , 
				       class array<double> &neut_Vo_tab , 
				       class array<double> &neut_Vso_tab);

  void all_n_holes_max_read (
			     const bool is_it_pole_approximation , 
			     const enum space_type space , 
			     int &n_holes_max , 
			     int &n_holes_max_p , 
			     int &n_holes_max_n);
  
  void all_n_scat_read (
			const enum space_type space , 
			int &n_scat_max , 
			int &n_scat_max_p , 
			int &n_scat_max_n);

  void CC_composite_data_read (
			       class array<unsigned int> &CC_BP_A_composite_tab , 
			       class array<unsigned int> &CC_vector_index_A_composite_tab , 
			       class array<double> &CC_J_A_composite_tab , 
			       const bool is_it_out_states , 
			       const bool is_it_GSM_pole_state);

  complex<double> CC_get_energy_from_file (const class correlated_state_str &T_qn);

  complex<double> CC_get_average_n_scat_from_file (const class correlated_state_str &T_qn);

  unsigned int n_scat_max_pp_nn_calc (
				      const bool truncation_ph ,
				      const int n_scat_max_init ,  
				      const class nucleons_data &particles_data);

  unsigned int n_scat_max_pn_calc (
				   const bool truncation_ph ,
				   const int n_scat_max_init ,  
				   const class nucleons_data &prot_data , 
				   const class nucleons_data &neut_data);

  unsigned int n_scat_max_modification (
					const enum space_type space , 
					const bool truncation_ph , 
					const class nucleons_data &prot_data , 
					const class nucleons_data &neut_data,
					const int n_scat_max_init);

  unsigned int BP_one_configuration_determine (
					       const enum space_type space , 
					       const class nucleons_data &prot_data , 
					       const class nucleons_data &neut_data);
  
  int E_min_hw_pp_nn (
		      const int N_valence_nucleons ,
		      const class array<class nlj_struct> &shells_qn);
  
  unsigned int N_nljm_calc (
			    const int lmax ,
			    const class array<int> &nmax_lab_tab);

  void Jminus_OBMEs_calc (
			  const class array<class nljm_struct> &phi_table , 
			  class array<double> &Jminus_tab);

  void Jplus_OBMEs_calc (
			 const class array<class nljm_struct> &phi_table , 
			 class array<double> &Jplus_tab);

  void Jpm_OBMEs_calc (
		       const int pm , 
		       const class array<class nljm_struct> &phi_table , 
		       class array<double> &Jpm_tab);

  void shells_sort (
		    const int low , const int high , 
		    class nucleons_data &particles_data);

  void shells_quantum_numbers_k_fill_from_h (class nucleons_data &particles_data);

  void initial_to_nljm_ordered_states_sort (const int low , const int high , const class array<class nljm_struct> &phi_table , class array<unsigned int> &initial_to_nljm_ordered_states);

  void eigensets_vectors_indices_calc (
				       const bool is_it_pole_approximation , 
				       const class nucleons_data &prot_data , 
				       const class nucleons_data &neut_data , 
				       const class array<unsigned long int> &dimensions_good_J , 
				       const class input_data_str &input_data , 
				       class array<unsigned int> &eigenset_vectors_indices);

  void space_truncation_data_best_hbar_omega_calc (
						   const bool is_there_cout , 
						   class input_data_str &input_data , 
						   class nucleons_data &prot_data , 
						   class nucleons_data &neut_data);
  
  unsigned int lm_number_calc (const int lmax_lm);

  void lm_quantum_numbers_indices_fill (class array<class lm_struct> &lm_qn_table , class lm_table<unsigned int> &lm_indices);

  unsigned int ljm_number_calc (const int lmax_ljm);

  void ljm_quantum_numbers_indices_fill (class array<class ljm_struct> &ljm_qn_table , class ljm_table<unsigned int> &ljm_indices);

  void CGs_lj_coupling_calc (
			     const class array<class lm_struct> &lm_qn_table , 
			     const class ljm_table<unsigned int> &ljm_indices , 
			     class array<double> &CGs);

  unsigned int Np_nljm_from_file_determine (
					    const string &file_name ,
					    const int Zval ,
					    const int Nval ,
					    const unsigned int Np_nljm);

  unsigned int Np_nljm_from_file_determine (
					    const bool full_common_vectors_used_in_file , 
					    const string &file_name ,
					    const int Zval ,
					    const int Nval ,
					    const unsigned int Np_nljm);

  unsigned int Nn_nljm_from_file_determine (
					    const string &file_name ,
					    const int Zval ,
					    const int Nval ,
					    const unsigned int Nn_nljm);

  unsigned int Nn_nljm_from_file_determine (
					    const bool full_common_vectors_used_in_file , 
					    const string &file_name ,
					    const int Zval ,
					    const int Nval ,
					    const unsigned int Nn_nljm);

  unsigned int N_nljm_from_file_determine (
					   const string &file_name ,
					   const int Nval_mu ,
					   const unsigned int N_nljm);

  unsigned int N_nljm_from_file_determine (
					   const bool full_common_vectors_used_in_file , 
					   const string &file_name ,
					   const int Nval_mu ,
					   const unsigned int N_nljm);

  void phi_p_table_from_file_determine (
					const string &file_name ,
					const int Zval ,
					const int Nval ,
					const class array<class nljm_struct> &phi_p_table ,
					class array<class nljm_struct> &phi_p_table_from_file);


  void phi_n_table_from_file_determine (
					const string &file_name ,
					const int Zval ,
					const int Nval ,
					const class array<class nljm_struct> &phi_n_table ,
					class array<class nljm_struct> &phi_n_table_from_file);


  void phi_table_from_file_determine (
				      const string &file_name ,
				      const int Nval_mu ,
				      const class array<class nljm_struct> &phi_mu_table ,
				      class array<class nljm_struct> &phi_mu_table_from_file);

  unsigned int N_nlj_fixed_parity_determine (
					     const unsigned int bp ,
					     const class array<class nlj_struct> &shells_qn);

  unsigned int process_dimension_determine (const unsigned long int total_dimension , const unsigned int processes_number , const unsigned int process);

  void set_all_n_holes_max_n_scat_max_CC_Berggren_classes (
							   const class input_data_str &input_data ,
							   class input_data_str &input_data_CC_Berggren , 
							   class nucleons_data &prot_data_CC_Berggren ,
							   class nucleons_data &neut_data_CC_Berggren);

  unsigned int vectors_to_find_number_max_determine (
						     const class input_data_str &input_data ,
						     const class array<unsigned long int> &total_space_dimensions_good_J_pole_approximation ,
						     const class array<unsigned long int> &total_space_dimensions_good_J);
  
  void all_HO_GHF_overlaps_prot_neut_alloc_calc (const class input_data_str &input_data ,
						 class nucleons_data &prot_data ,
						 class nucleons_data &neut_data);

  void HO_GHF_overlaps_prot_neut_alloc_calc (
					     const bool is_it_only_basis , 
					     const class input_data_str &input_data ,
					     class nucleons_data &prot_data ,
					     class nucleons_data &neut_data);
  
  void radial_wfs_HF_data_HO_overlaps_basis_copy_disk (
						       const class input_data_str &input_data ,
						       const class nucleons_data &particles_data);

  void radial_wfs_HF_data_HO_overlaps_basis_prot_neut_copy_disk (
								 const class input_data_str &input_data ,
								 const class nucleons_data &prot_data ,
								 const class nucleons_data &neut_data);
  
  void radial_wfs_HF_data_HO_overlaps_basis_alloc_read_disk (
							     const class input_data_str &input_data ,
							     const class nucleons_data &neut_data ,
							     class nucleons_data &particles_data);
  
  void radial_wfs_HF_data_HO_overlaps_basis_prot_neut_alloc_read_disk (
								       const class input_data_str &input_data ,
								       class nucleons_data &prot_data ,
								       class nucleons_data &neut_data);
  
  void coupled_one_body_tab_copy_disk (
				       const string debut_file_name , 
				       const enum interaction_type Op_inter , 
				       const class nucleons_data &particles_data ,
				       const class array<TYPE> &coupled_one_body_tab);
  
  void coupled_one_body_tab_copy_disk (
				       const string debut_file_name , 
				       const enum operator_type Op_inter , 
				       const class nucleons_data &particles_data ,
				       const class array<TYPE> &coupled_one_body_tab);

  void OBMEs_inter_HO_GHF_overlaps_copy_disk (					  
					      const class input_data_str &input_data ,
					      const class nucleons_data &particles_data);

  void all_OBMEs_inter_HO_GHF_overlaps_copy_disk (
						  const class input_data_str &input_data ,
						  const class nucleons_data &prot_data , 
						  const class nucleons_data &neut_data);

  void reduced_grad_set_copy_disk (const class nucleons_data &particles_data);

  void reduced_r_set_copy_disk (const class nucleons_data &particles_data);

  void reduced_r_rms_radius_pn_set_copy_disk (const class nucleons_data &particles_data);

  void OBMEs_CM_set_copy_disk (const class nucleons_data &particles_data);
  
  void all_OBMEs_CM_reduced_r_grad_sets_copy_disk (
						   const enum space_type space ,
						   const class nucleons_data &prot_data , 
						   const class nucleons_data &neut_data);

  void TBMEs_pp_nn_pn_copy_disk (
				 const class input_data_str &input_data , 
				 const class nucleons_data &prot_data ,
				 const class nucleons_data &neut_data ,
				 const class TBMEs_class &TBMEs_pn);
  
  void coupled_one_body_tab_read_disk (
				       const string debut_file_name , 
				       const enum interaction_type Op_inter , 
				       const class nucleons_data &particles_data ,
				       class array<TYPE> &coupled_one_body_tab);
 
  void coupled_one_body_tab_read_disk (
				       const string debut_file_name ,
				       const enum operator_type Op_inter , 
				       const class nucleons_data &particles_data ,
				       class array<TYPE> &coupled_one_body_tab);
  
  void OBMEs_inter_HO_GHF_overlaps_alloc_read_disk (						
						    const class input_data_str &input_data ,
						    class nucleons_data &particles_data);

  void all_OBMEs_inter_HO_GHF_overlaps_alloc_read_disk (						    
							const class input_data_str &input_data ,
							class nucleons_data &prot_data , 
							class nucleons_data &neut_data);

  void reduced_grad_set_alloc_read_disk (class nucleons_data &particles_data);

  void reduced_r_set_alloc_read_disk (class nucleons_data &particles_data);

  void reduced_r_rms_radius_pn_set_alloc_read_disk (class nucleons_data &particles_data);
  
  void OBMEs_CM_set_alloc_read_disk (class nucleons_data &particles_data);

  void all_OBMEs_CM_reduced_r_grad_sets_alloc_read_disk (const enum space_type space ,
							 class nucleons_data &prot_data , 
							 class nucleons_data &neut_data);
  
  void TBMEs_pp_nn_pn_alloc_read_disk (
				       const bool is_there_cout ,
				       const bool is_it_only_basis ,   
				       const class input_data_str &input_data , 
				       class nucleons_data &prot_data ,
				       class nucleons_data &neut_data ,
				       class TBMEs_class &TBMEs_pn);
  
  void natural_orbitals_occupancies_ESPEs_alloc_calc_print (
							    const bool is_there_cout , 
							    const bool are_there_ESPEs , 
							    class nucleons_data &particles_data);

  void Slater_determinants_PSI_components_read_from_file (
							  const string &eigenvector_file_name , 
							  class array<unsigned int> &SD_tab , 
							  class array<TYPE> &PSI_component_tab);

  void Slater_determinants_PSI_components_read_from_file (
							  const string &eigenvector_file_name , 
							  class array<unsigned int> &SDp_tab , 
							  class array<unsigned int> &SDn_tab , 
							  class array<TYPE> &PSI_component_tab);

  void files_IN_tables_read_pp_nn_one_nucleon (
					       const bool full_common_vectors_used_in_file , 
					       const class correlated_state_str &PSI_IN_qn ,
					       const double M_IN ,
					       const class nucleons_data &data ,
					       class array<unsigned int> &inSD_tab ,
					       class array<TYPE> &PSI_IN_component_tab ,
					       class array<bool> &is_inSD_in_new_space_tab ,
					       class array<unsigned char> &reordering_bin_phases);

  void files_IN_tables_read_pn_one_nucleon (
					    const bool full_common_vectors_used_in_file , 
					    const int Zval_IN , 
					    const int Nval_IN , 
					    const class correlated_state_str &PSI_IN_qn ,
					    const double M_IN , 
					    const class nucleons_data &prot_data ,
					    const class nucleons_data &neut_data ,
					    class array<unsigned int> &inSDp_tab ,
					    class array<unsigned int> &inSDn_tab ,
					    class array<TYPE> &PSI_IN_component_tab ,
					    class array<bool> &is_inSDp_in_new_space_tab ,
					    class array<bool> &is_inSDn_in_new_space_tab ,
					    class array<unsigned char> &reordering_bin_phases_p ,
					    class array<unsigned char> &reordering_bin_phases_n);


  void files_IN_tables_read_pp_nn_cluster (
					   const bool full_common_vectors_used_in_file ,
					   const bool is_it_CM_relative_cluster , 
					   const enum particle_type cluster , 
					   const int NCM_HO , 
					   const int LCM , 
					   const class correlated_state_str &PSI_cluster_qn ,
					   const double M_cluster ,  
					   const class correlated_state_str &PSI_IN_qn ,
					   const double M_IN ,
					   const class nucleons_data &data ,
					   class array<unsigned int> &SD_IN_tab ,
					   class array<unsigned int> &SD_cluster_tab ,
					   class array<TYPE> &PSI_IN_component_tab ,
					   class array<TYPE> &PSI_cluster_component_tab ,
					   class array<bool> &is_SD_IN_in_new_space_tab ,
					   class array<bool> &is_SD_cluster_in_new_space_tab ,
					   class array<unsigned char> &reordering_bin_phases_IN ,
					   class array<unsigned char> &reordering_bin_phases_cluster);

  void files_IN_tables_read_pn_cluster (
					const bool full_common_vectors_used_in_file , 
					const bool is_it_CM_relative_cluster , 
					const enum particle_type cluster , 
					const int NCM_HO , 
					const int LCM , 
					const class correlated_state_str &PSI_cluster_qn ,
					const double M_cluster ,  
					const class correlated_state_str &PSI_IN_qn ,
					const double M_IN ,
					const class nucleons_data &prot_data ,
					const class nucleons_data &neut_data ,
					class array<unsigned int> &SDp_IN_tab ,
					class array<unsigned int> &SDn_IN_tab ,
					class array<unsigned int> &SDp_cluster_tab ,
					class array<unsigned int> &SDn_cluster_tab ,
					class array<TYPE> &PSI_IN_component_tab ,
					class array<TYPE> &PSI_cluster_component_tab ,
					class array<bool> &is_SDp_IN_in_new_space_tab ,
					class array<bool> &is_SDn_IN_in_new_space_tab ,
					class array<bool> &is_SDp_cluster_in_new_space_tab ,
					class array<bool> &is_SDn_cluster_in_new_space_tab ,
					class array<unsigned char> &reordering_bin_phases_p_IN ,
					class array<unsigned char> &reordering_bin_phases_n_IN ,
					class array<unsigned char> &reordering_bin_phases_p_cluster ,
					class array<unsigned char> &reordering_bin_phases_n_cluster);

  
  bool and_Reduce (
		   const bool is_it_MPI_parallelized_local ,
		   const unsigned int Recv_process ,
		   const unsigned int process ,
		   const bool x);

  bool or_Reduce (
		  const bool is_it_MPI_parallelized_local ,
		  const unsigned int Recv_process ,
		  const unsigned int process ,
		  const bool x);

  bool and_Allreduce (
		      const bool is_it_MPI_parallelized_local ,
		      const bool x);

  bool or_Allreduce (
		     const bool is_it_MPI_parallelized_local ,
		     const bool x);
    
  double A_dependent_factor_core_potential_calc (const enum particle_type particle , const class input_data_str &input_data);
  
  double TBME_A_dependent_factor_calc (const class input_data_str &input_data);

  void Ylm_table_coupled_to_l_calc (
				    const class array<class lm_struct> &lm_qn_table ,
				    class array<double> &Ylm_table_coupled_to_l);

  void Ylm_table_coupled_to_j_calc (
				    const class array<class ljm_struct> &ljm_qn_table ,
				    class array<double> &Ylm_table_coupled_to_j);

  void correlation_density_files_store (
					const bool is_it_radial ,
					const string PSI_qn_string ,
					const string pn_string ,
					const class array<double> &rk_tab ,
					const class array<double> &theta_tab ,
					const class array<TYPE> &angular_densities_tab ,
					const class array<TYPE> &density_tab);
  
  // Routines reducing booleans with MPI routines
  // --------------------------------------------
  // The "min", "max", "sum" reduction on a process or on all processes of a general scalar x is done here.
  // One uses the same routine with both parallel and sequential compilation.
  // Nothing is done in the sequential code case except checking that input data are correct.
  //
  // is_it_MPI_parallelized_local can be set to false to remove MPI distribution even if the MPI parallel code is used.

  template <typename SCALAR_TYPE>
  SCALAR_TYPE min_Reduce (
			  const bool is_it_MPI_parallelized_local ,
			  const unsigned int Recv_process ,
			  const unsigned int process ,
			  const SCALAR_TYPE &x)
  {
    SCALAR_TYPE x_min = x;

#ifdef UseMPI
    
    if (is_it_MPI_parallelized_local) MPI_helper::Reduce<SCALAR_TYPE> (x_min , MPI_MIN , Recv_process , process , MPI_COMM_WORLD);
    
#else
    
    if (is_it_MPI_parallelized_local && (Recv_process != MASTER_PROCESS) && (process != MASTER_PROCESS))
      error_message_print_abort ("is_it_MPI_parallelized_local has to be false in a sequential calculation in min_Reduce and processes have to be MASTER_PROCESS");
    
#endif

    return x_min;
  }



  
  template <typename SCALAR_TYPE>
  SCALAR_TYPE max_Reduce (
			  const bool is_it_MPI_parallelized_local ,
			  const unsigned int Recv_process ,
			  const unsigned int process ,
			  const SCALAR_TYPE &x)
  {
    SCALAR_TYPE x_max = x;

#ifdef UseMPI
    
    if (is_it_MPI_parallelized_local) MPI_helper::Reduce<SCALAR_TYPE> (x_max , MPI_MAX , Recv_process , process , MPI_COMM_WORLD);
    
#else
    
    if (is_it_MPI_parallelized_local && (Recv_process != MASTER_PROCESS) && (process != MASTER_PROCESS))
      error_message_print_abort ("is_it_MPI_parallelized_local has to be false in a sequential calculation in max_Reduce and processes have to be MASTER_PROCESS");
    
#endif

    return x_max;
  }


  
  template <typename SCALAR_TYPE>
  SCALAR_TYPE sum_Reduce (
			  const bool is_it_MPI_parallelized_local ,
			  const unsigned int Recv_process ,
			  const unsigned int process ,
			  const SCALAR_TYPE &x)
  {
    SCALAR_TYPE x_min = x;

#ifdef UseMPI
    
    if (is_it_MPI_parallelized_local) MPI_helper::Reduce<SCALAR_TYPE> (x_min , MPI_SUM , Recv_process , process , MPI_COMM_WORLD);
    
#else
    
    if (is_it_MPI_parallelized_local && (Recv_process != MASTER_PROCESS) && (process != MASTER_PROCESS))
      error_message_print_abort ("is_it_MPI_parallelized_local has to be false in a sequential calculation in sum_Reduce and processes have to be MASTER_PROCESS");
    
#endif

    return x_min;
  }


  template <typename SCALAR_TYPE>
  SCALAR_TYPE min_Allreduce (
			     const bool is_it_MPI_parallelized_local ,
			     const SCALAR_TYPE &x)
  {
    SCALAR_TYPE x_min = x;

#ifdef UseMPI
    
    if (is_it_MPI_parallelized_local) MPI_helper::Allreduce<SCALAR_TYPE> (x_min , MPI_MIN , MPI_COMM_WORLD);
    
#else
    
    if (is_it_MPI_parallelized_local) error_message_print_abort ("is_it_MPI_parallelized_local has to be false in a sequential calculation in min_Allreduce");
    
#endif

    return x_min;
  }


  template <typename SCALAR_TYPE>
  SCALAR_TYPE max_Allreduce (
			     const bool is_it_MPI_parallelized_local ,
			     const SCALAR_TYPE &x)
  {
    SCALAR_TYPE x_max = x;

#ifdef UseMPI
    
    if (is_it_MPI_parallelized_local) MPI_helper::Allreduce<SCALAR_TYPE> (x_max , MPI_MAX , MPI_COMM_WORLD);
    
#else
    
    if (is_it_MPI_parallelized_local) error_message_print_abort ("is_it_MPI_parallelized_local has to be false in a sequential calculation in max_Allreduce");
    
#endif

    return x_max;
  }
  
  
  template <typename SCALAR_TYPE>
  SCALAR_TYPE sum_Allreduce (
			     const bool is_it_MPI_parallelized_local ,
			     const SCALAR_TYPE &x)
  {
    SCALAR_TYPE x_sum = x;		

#ifdef UseMPI
    
    if (is_it_MPI_parallelized_local) MPI_helper::Allreduce<SCALAR_TYPE> (x_sum , MPI_SUM , MPI_COMM_WORLD);
    
#else
    
    if (is_it_MPI_parallelized_local) error_message_print_abort ("is_it_MPI_parallelized_local has to be false in a sequential calculation in sum_Allreduce");
    
#endif

    return x_sum;
  }



  // Calculation of one-body matrix elements from reduced one-body matrix elements with Wigner signs
  // -----------------------------------------------------------------------------------------------
  // One-body matrix elements are of the form OBMEs(in,out), with in, out two one-body states, or OBMEs(in,out,i), with 0 <= i < Nr, which are typically radii indices (strength functions in coordinate space).
  // They are calculated from reduced one-body matrix elements OBMEs_reduced(s_in,s_out) or OBMEs_reduced(s_in,s_out,i), where s_in,s_out are the shells associated to the in, out one-body states.
  // One-body matrix elements are equal to <j_out m_out | O^L_ML | j_in m_in> and reduced one-body matrix elements are equal to <j_out || O^L || j_in>
  // 
  // Variables
  // ---------
  // L, ML: rank and spherical coordinate and of the operator
  // data_in, data_out: classes containing data related to protons or neutrons
  // OBMEs_reduced: array of reduced one-body matrix elements
  // OBMEs: array of one-body matrix elements to calculate
  // N_nljm_in, N_nljm_out: number of states, for which n,l,j,m are fixed, for the in and out spaces
  // phi_table_in, phi_table_out: array of proton or neutron |n l j m> states, for the in and out spaces
  // phi_in, phi_out: structures containing n,l,j,m quantum numbers, for the in and out states
  // s_in, s_out: shell indices of the states phi_in, phi_out
  // j_in, m_in, j_out, m_out: total angular momenta and their projections for the in and out states
  // OBME_reduced: reduced one-body matrix element <j_out || O^L || j_in>

  template <typename SCALAR_TYPE>
  void OBMEs_dereduced_calc (
			     const int L , 
			     const int ML , 
			     const class nucleons_data &data_in , 
			     const class nucleons_data &data_out , 
			     const class array<SCALAR_TYPE> &OBMEs_reduced , 
			     class array<SCALAR_TYPE> &OBMEs)
  {
    const unsigned int N_nljm_in  = data_in.get_N_nljm ();
    const unsigned int N_nljm_out = data_out.get_N_nljm ();
    
    const class array<class nljm_struct> &phi_table_in  = data_in.get_phi_table ();
    const class array<class nljm_struct> &phi_table_out = data_out.get_phi_table ();

    for (unsigned int in = 0 ; in < N_nljm_in ; in++)
      for (unsigned int out = 0 ; out < N_nljm_out ; out++)
	{
	  const class nljm_struct &phi_in  = phi_table_in(in);
	  const class nljm_struct &phi_out = phi_table_out(out);
	  
	  const unsigned int s_in  = phi_in.get_shell_index ();
	  const unsigned int s_out = phi_out.get_shell_index (); 

	  const double j_in = phi_in.get_j () , j_out = phi_out.get_j ();
	  const double m_in = phi_in.get_m () , m_out = phi_out.get_m ();

	  const SCALAR_TYPE OBME_reduced = OBMEs_reduced (s_in , s_out);

	  OBMEs(in , out) = ME_dereduced (OBME_reduced , L , ML , j_in , m_in , j_out , m_out);
	}
  }

  template <typename SCALAR_TYPE>
  void OBMEs_dereduced_strength_calc (
				      const int L , 
				      const int ML , 
				      const class nucleons_data &data_in , 
				      const class nucleons_data &data_out , 
				      const class array<SCALAR_TYPE> &OBMEs_reduced , 
				      class array<SCALAR_TYPE> &OBMEs)
  {
    const unsigned int N_nljm_in  = data_in.get_N_nljm ();
    const unsigned int N_nljm_out = data_out.get_N_nljm ();
    
    const unsigned int Nr = OBMEs.dimension (2);
    
    const class array<class nljm_struct> &phi_table_in  = data_in.get_phi_table ();
    const class array<class nljm_struct> &phi_table_out = data_out.get_phi_table ();
    
    for (unsigned int in = 0 ; in < N_nljm_in ; in++)
      for (unsigned int out = 0 ; out < N_nljm_out ; out++)
	{
	  const class nljm_struct &phi_in  = phi_table_in(in);
	  const class nljm_struct &phi_out = phi_table_out(out);

	  const unsigned int s_in  = phi_in.get_shell_index ();
	  const unsigned int s_out = phi_out.get_shell_index (); 

	  const double j_in = phi_in.get_j () , j_out = phi_out.get_j ();
	  const double m_in = phi_in.get_m () , m_out = phi_out.get_m ();

	  for (unsigned int i = 0 ; i < Nr ; i++)
	    {
	      const SCALAR_TYPE OBME_reduced = OBMEs_reduced (s_in , s_out , i);

	      OBMEs(in , out , i) = ME_dereduced (OBME_reduced , L , ML , j_in , m_in , j_out , m_out);
	    }
	}
  }
}

#endif


