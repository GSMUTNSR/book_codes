#ifndef GSMTBMEMSGI_H
#define GSMTBMEMSGI_H

// TYPE is double or complex
// -------------------------

namespace TBME_MSGI_set
{
  TYPE radial_integral_calc (
			     const class array<double> &Gaussian_tab_weight_GL , 
			     const class spherical_state &wf_in , 
			     const class spherical_state &wf_out);
  
  void pp_nn_radial_integral_calc (
				   const class nucleons_data &particles_data , 
				   const class interaction_class &inter_data , 
				   class array<TYPE> &radial_OBMEs);

  void pn_radial_integral_calc (
				const class nucleons_data &prot_data , 
				const class nucleons_data &neut_data , 
				const class interaction_class &inter_data , 
				class array<TYPE> &radial_OBMEs);

  TYPE TBME_pi_pj_J (
		     const int J , 
		     const class array<TYPE> &reduced_grad_02_tab , 
		     const class array<TYPE> &reduced_grad_13_tab , 
		     const unsigned int s0 ,
		     const unsigned int s1 ,
		     const unsigned int s2 ,
		     const unsigned int s3 , 
		     const class spherical_state &wf0 , 
		     const class spherical_state &wf1 , 
		     const class spherical_state &wf2 , 
		     const class spherical_state &wf3);

  TYPE TBME_J (
	       const bool is_there_recoil ,
	       const int J , 
	       const unsigned int s0 ,
	       const unsigned int s1 ,
	       const unsigned int s2 ,
	       const unsigned int s3 , 
	       const class spherical_state &wf0 , 
	       const class spherical_state &wf1 , 
	       const class spherical_state &wf2 , 
	       const class spherical_state &wf3 , 
	       const class array<TYPE> &radial_OBMEs_02_tab , 
	       const class array<TYPE> &radial_OBMEs_13_tab , 
	       const class array<TYPE> &reduced_grad_02_tab , 
	       const class array<TYPE> &reduced_grad_13_tab , 
	       const class interaction_class &inter_data , 
	       const class multipolar_expansion_str &multipolar_expansion);

  TYPE TBME_J_pp_nn_antisymmetrized (
				     const bool is_there_recoil ,
				     const int J , 
				     const unsigned int s0 ,
				     const unsigned int s1 ,
				     const unsigned int s2 ,
				     const unsigned int s3 , 
				     const class array<class spherical_state> &shells , 
				     const class array<TYPE> &radial_OBMEs , 
				     const class array<TYPE> &reduced_grad_tab , 
				     const class interaction_class &inter_data , 
				     const class multipolar_expansion_str &multipolar_expansion);
  TYPE TBME_J_pn (
		  const bool is_there_recoil ,
		  const int J , 
		  const unsigned int s0 ,
		  const unsigned int s1 ,
		  const unsigned int s2 ,
		  const unsigned int s3 , 
		  const class array<class spherical_state> &shells_prot , 
		  const class array<class spherical_state> &shells_neut , 
		  const class array<TYPE> &radial_OBMEs_pp , 
		  const class array<TYPE> &radial_OBMEs_nn , 
		  const class array<TYPE> &radial_OBMEs_pn , 
		  const class array<TYPE> &reduced_grad_p_tab , 
		  const class array<TYPE> &reduced_grad_n_tab , 
		  const class interaction_class &inter_data , 
		  const class multipolar_expansion_str &multipolar_expansion);
}
#endif


