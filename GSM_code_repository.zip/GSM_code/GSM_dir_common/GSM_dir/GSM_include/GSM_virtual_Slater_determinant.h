#ifndef GSMVIRTUALSLATERDETERMINANT_H
#define GSMVIRTUALSLATERDETERMINANT_H

// TYPE is double or complex
// -------------------------

class Slater_determinant;

class virtual_Slater_determinant 
{
public:
  virtual_Slater_determinant (
			      const class array<unsigned short int> &table_c ,
			      const unsigned int index_c);

  ~virtual_Slater_determinant ();

  unsigned int get_N_valence_baryons () const
  {
    return table.dimension (1);
  }
  
  unsigned short int & operator [] (const unsigned int i) const
  {
    return table(index , i);
  }
  
  const class virtual_Slater_determinant & operator = (const class Slater_determinant &X);

private:
  
  const class array<unsigned short int> &table;
  
  const unsigned int index;
};

#endif


