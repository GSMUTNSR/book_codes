#ifndef GSMCORRELATIONDENSITYTBMES_H
#define GSMCORRELATIONDENSITYTBMES_H

// TYPE is double or complex
// -------------------------

namespace correlation_density_TBMEs
{
  void radial_OBMEs_calc (
			  const bool is_it_radial ,
			  const bool is_it_Gauss_Legendre ,
			  const class nucleons_data &data ,
			  class array<TYPE> &OBMEs_shells);
    
  void theta12_Dirac_multipolar_calc (
				      const class array<double> &theta_tab ,
				      class array<double> &theta12_Dirac_multipolar_tab);

  double rk_overlap_HO_states_calc (
				    const class interaction_class &inter_data , 
				    const unsigned int a , 
				    const unsigned int b);

  double rk_overlap_HO_states_calc (
				    const class spherical_state &wf_in , 
				    const class spherical_state &wf_out);

  TYPE rk_overlap_HO_expansion_calc (
				     const class interaction_class &inter_data , 
				     const class nucleons_data &data , 
				     const unsigned int s_in , 
				     const unsigned int s_out);
  
  TYPE rk_overlap_R_cut_calc (
			      const class nucleons_data &data ,
			      const unsigned int s_in ,
			      const unsigned int s_out);

  TYPE rk_overlap_calc (
			const bool is_it_HO_expansion , 
			const class interaction_class &inter_data , 
			const class nucleons_data &data ,
			const unsigned int s_in ,
			const unsigned int s_out);
  
  double angular_delta_PS_ME_calc (
				   const class array<double> &theta12_Dirac_multipolar_tab , 
				   const int lmin_parity , 
				   const int lmax_parity , 
				   const class array<double> &Yl1_Yl2_PS_MEs , 
				   const int S , 
				   const unsigned int it);

  double multipolar_expansion_Psigma_ME_calc (
					      const class multipolar_expansion_str &multipolar_expansion , 
					      const class Psigma_str &Psigma_MEs , 
					      const int la , const double ja , const int lb , const double jb , 
					      const int lc , const double jc , const int ld , const double jd , 
					      const int l , const int J);

  double uncoupled_Yl1_Yl2_ME_calc (
				    const class nljm_struct &phi0 , 
				    const class nljm_struct &phi1 , 
				    const class nljm_struct &phi2 , 
				    const class nljm_struct &phi3 , 
				    const int l , 
				    const class ljm_table<unsigned int> &ljm_indices , 
				    const class array<double> &Ylm_table_coupled_to_j);

  double uncoupled_Yl1_Yl2_Psigma_ME_calc (
					   const class nljm_struct &phi0 , 
					   const class nljm_struct &phi1 , 
					   const class nljm_struct &phi2 , 
					   const class nljm_struct &phi3 , 
					   const int l , 
					   const class lm_table<unsigned int> &lm_indices , 
					   const class ljm_table<unsigned int> &ljm_indices , 
					   const class array<double> &Ylm_table_coupled_to_l , 
					   const class array<double> &CGs);

  void coupled_TBMEs_pp_nn_calc (
				 const bool is_it_HO_expansion , 
				 const int J , 
				 const class interaction_class &inter_data , 
				 const class nucleons_data &data , 
				 const class array<TYPE> &radial_OBMEs , 
				 const class pair_str &pair_in , 
				 const class pair_str &pair_out , 
				 const class array<double> &theta12_Dirac_multipolar_tab , 
				 const class multipolar_expansion_str &multipolar_expansion , 
				 const class Psigma_str &Psigma_MEs , 
				 class array<TYPE> &ang_densities_TBMEs , 
				 class array<TYPE> &density_TBMEs);

  void coupled_TBMEs_pn_calc (
			      const bool is_it_HO_expansion , 
			      const int J , 
			      const class interaction_class &inter_data , 
			      const class nucleons_data &prot_data , 
			      const class nucleons_data &neut_data , 
			      const class array<TYPE> &radial_OBMEs_prot , 
			      const class array<TYPE> &radial_OBMEs_neut , 
			      const class pair_str &pair_in , 
			      const class pair_str &pair_out , 
			      const class array<double> &theta12_Dirac_multipolar_tab , 
			      const class multipolar_expansion_str &multipolar_expansion , 
			      const class Psigma_str &Psigma_MEs , 
			      class array<TYPE> &ang_densities_TBMEs , 
			      class array<TYPE> &density_TBMEs);

  void coupled_TBMEs_calc (
			   const bool is_it_HO_expansion , 
			   const enum space_type space , 
			   const int J , 
			   const class interaction_class &inter_data , 
			   const class nucleons_data &prot_data , 
			   const class nucleons_data &neut_data , 
			   const class array<TYPE> &radial_OBMEs_prot , 
			   const class array<TYPE> &radial_OBMEs_neut , 
			   const class pair_str &pair_in , 
			   const class pair_str &pair_out , 
			   const class array<double> &theta12_Dirac_multipolar_tab , 
			   const class multipolar_expansion_str &multipolar_expansion , 
			   const class Psigma_str &Psigma_MEs , 
			   class array<TYPE> &ang_densities_TBMEs , 
			   class array<TYPE> &density_TBMEs);

  void uncoupled_TBMEs_pp_nn_calc (
				   const bool is_it_HO_expansion , 
				   const class interaction_class &inter_data , 
				   const class nucleons_data &data , 
				   const class array<TYPE> &radial_OBMEs , 
				   const unsigned int s0 , 
				   const unsigned int s1 , 
				   const unsigned int s2 , 
				   const unsigned int s3 , 
				   const class array<double> &theta12_Dirac_multipolar_tab , 
				   const class lm_table<unsigned int> &lm_indices , 
				   const class ljm_table<unsigned int> &ljm_indices , 
				   const class array<double> &Ylm_table_coupled_to_l , 
				   const class array<double> &Ylm_table_coupled_to_j , 
				   const class array<double> &CGs , 
				   class array<TYPE> &ang_densities_TBMEs , 
				   class array<TYPE> &density_TBMEs);

  void uncoupled_TBMEs_pn_calc (
				const bool is_it_HO_expansion , 
				const class interaction_class &inter_data , 
				const class nucleons_data &prot_data , 
				const class nucleons_data &neut_data , 
				const class array<TYPE> &radial_OBMEs_prot , 
				const class array<TYPE> &radial_OBMEs_neut , 
				const unsigned int s0 , 
				const unsigned int s1 , 
				const unsigned int s2 , 
				const unsigned int s3 , 
				const class array<double> &theta12_Dirac_multipolar_tab , 
				const class lm_table<unsigned int> &lm_indices , 
				const class ljm_table<unsigned int> &ljm_indices , 
				const class array<double> &Ylm_table_coupled_to_l , 
				const class array<double> &Ylm_table_coupled_to_j , 
				const class array<double> &CGs , 
				class array<TYPE> &ang_densities_TBMEs , 
				class array<TYPE> &density_TBMEs);
}

#endif


