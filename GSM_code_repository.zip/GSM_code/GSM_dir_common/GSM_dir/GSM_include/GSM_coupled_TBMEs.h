#ifndef GSMCOUPLEDTBMES_H
#define GSMCOUPLEDTBMES_H

// TYPE is double or complex
// -------------------------

namespace coupled_TBMEs
{
  namespace standard_HO_SM
  {
    TYPE JT_TBME_calc (
		       const int J , 
		       const int T , 
		       const enum space_type TBME_space , 
		       const class array<class array<class JT_coupled_TBME> > &JT_TBME_tables ,
		       const class nlj_struct four_shells[]);

    class JT_coupled_TBME swap_nlj_Vabcd_phase_multiplication (
							       const class JT_coupled_TBME &JT_TBME , 
							       const unsigned int s0 , 
							       const unsigned int s1 , 
							       const unsigned int s2 , 
							       const unsigned int s3 , 
							       const int phase);

    void JT_TBME_tables_realloc_all_combinations_fill (class array<class JT_coupled_TBME> &JT_TBME_table);

    void TBMEs_pp_nn_calc (
			   const class input_data_str &input_data , 
			   const bool is_there_Hcm , 
			   const class array <class array<class JT_coupled_TBME> > &JT_TBME_tables , 
			   class baryons_data &particles_data);
 
    void TBMEs_pn_calc (
			const class input_data_str &input_data , 
			const class baryons_data &prot_Y_data , 
			const class baryons_data &neut_Y_data , 
			const bool is_there_Hcm , 
			const class array <class array<class JT_coupled_TBME> > &JT_TBME_tables , 
			class TBMEs_class &TBMEs);
  }

  namespace Berggren
  {
    TYPE TBME_pp_nn (
		     const bool is_Coulomb_to_be_added ,
		     const int J ,
		     const enum interaction_type TBME_inter , 
		     const enum interaction_read_type inter_read ,
		     const class array<TYPE> &radial_SGI_TBMEs_dir , 
		     const class array<TYPE> &radial_SGI_TBMEs_exc , 
		     const class array<TYPE> &radial_MSGI_OBMEs , 
		     const class baryons_data &particles_data , 
		     const class TBMEs_class &J_TBMEs_mixed_inter , 
		     const class interaction_class &inter_data , 
		     const class multipolar_expansion_str &multipolar_expansion , 
		     const unsigned int s0 , 
		     const unsigned int s1 , 
		     const unsigned int s2 , 
		     const unsigned int s3 , 
		     const double lambda_Hcm);

    void TBMEs_pp_nn_calc (
			   const bool is_there_cout , 
			   const bool is_it_only_basis , 
			   const enum interaction_type TBME_inter , 
			   const class input_data_str &input_data , 
			   const bool is_there_Hcm , 
			   const class interaction_class &inter_data , 
			   class baryons_data &particles_data);

    void TBMEs_pp_nn_add_kinetic_part (
				       const class input_data_str &input_data ,
				       class baryons_data &particles_data);
    
    void TBMEs_pp_nn_remove_kinetic_part (
					  const class input_data_str &input_data ,
					  class baryons_data &particles_data);

    TYPE TBME_pn (
		  const int J , 
		  const enum interaction_type TBME_inter , 
		  const enum interaction_read_type inter_read ,
		  const class array<TYPE> &radial_SGI_TBMEs_dir , 
		  const class array<TYPE> &radial_SGI_TBMEs_exc , 
		  const class array<TYPE> &radial_MSGI_OBMEs_pp , 
		  const class array<TYPE> &radial_MSGI_OBMEs_nn , 
		  const class array<TYPE> &radial_MSGI_OBMEs_pn , 
		  const class baryons_data &prot_Y_data , 
		  const class baryons_data &neut_Y_data , 
		  const class TBMEs_class &J_TBMEs_mixed_inter , 
		  const class interaction_class &inter_data , 
		  const class multipolar_expansion_str &multipolar_expansion , 
		  const unsigned int s0 ,
		  const unsigned int s1 ,
		  const unsigned int s2 ,
		  const unsigned int s3 , 
		  const double lambda_Hcm);
    
    void TBMEs_pn_calc (
			const bool is_there_cout , 
			const bool is_it_only_basis , 
			const enum interaction_type TBME_inter , 
			const class input_data_str &input_data , 
			const class baryons_data &prot_Y_data , 
			const class baryons_data &neut_Y_data , 
			const bool is_there_Hcm , 
			const class interaction_class &inter_data , 
			class TBMEs_class &TBMEs);
    
    void TBMEs_pn_add_kinetic_part (
				    const class input_data_str &input_data , 
				    const class baryons_data &prot_Y_data , 
				    const class baryons_data &neut_Y_data , 
				    class TBMEs_class &TBMEs_pn);
    
    void TBMEs_pn_remove_kinetic_part (
				       const class input_data_str &input_data , 
				       const class baryons_data &prot_Y_data , 
				       const class baryons_data &neut_Y_data , 
				       class TBMEs_class &TBMEs_pn);
    
    void TBMEs_cv_calc (
			const bool is_there_cout , 
			const enum interaction_type TBME_inter , 
			const class input_data_str &input_data , 
			const class baryons_data &prot_Y_data , 
			const class baryons_data &neut_Y_data , 
			const class interaction_class &inter_data , 
			class TBMEs_class &TBMEs);
  }
}

#endif


