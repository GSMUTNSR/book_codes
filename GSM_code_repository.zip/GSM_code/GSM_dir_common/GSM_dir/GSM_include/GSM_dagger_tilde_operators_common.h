#ifndef GSMDAGGERTILDEOPERATORSCOMMON_H
#define GSMDAGGERTILDEOPERATORSCOMMON_H

// TYPE is double or complex
// -------------------------

namespace dagger_tilde_operators_common
{
  int Z_IN_calc (const enum dagger_tilde_operator_type dagger_tilde_operator , const int Z);
  int N_IN_calc (const enum dagger_tilde_operator_type dagger_tilde_operator , const int N);

  int Z_OUT_calc (const enum dagger_tilde_operator_type dagger_tilde_operator , const int Z);  
  int N_OUT_calc (const enum dagger_tilde_operator_type dagger_tilde_operator , const int N);
  
  const class nucleons_data & data_find (const enum dagger_tilde_operator_type dagger_tilde_operator , const unsigned int place_index , const class nucleons_data &prot_data , const class nucleons_data &neut_data); 

  const class Slater_determinant & SD_find (const enum dagger_tilde_operator_type dagger_tilde_operator , const unsigned int place_index , const class Slater_determinant &SDp , const class Slater_determinant &SDn);
  
  void K_reducing_terms_calc (
			      const double J_IN , 
			      const double J_OUT , 
			      const double M_IN , 
			      const double M_OUT ,
			      class array<double> &K_reducing_terms);
  
  void two_body_K_table_from_MK_table_calc (
					    const double J_IN , 
					    const double J_OUT , 
					    const double M_IN , 
					    const double M_OUT , 
					    const class CG_str &CGs ,
					    const class array<double> &K_reducing_terms ,
					    const class uncoupled_dagger_tilde_table<TYPE> &two_body_MK_table , 
					    class coupled_dagger_tilde_table<TYPE> &two_body_K_table);
 
  void three_body_L_K_table_from_MK_table_calc (
						const double J_IN , 
						const double J_OUT , 
						const double M_IN , 
						const double M_OUT , 
						const class CG_str &CGs ,
						const class array<double> &K_reducing_terms ,
						const class uncoupled_dagger_tilde_table<TYPE> &three_body_MK_table , 
						class coupled_dagger_tilde_table<TYPE> &three_body_L_K_table);
 
  void PQG_CG_table_calc ( 
			  const class array<class nljm_struct> &phi_table_a ,
			  const class array<class nljm_struct> &phi_table_b , 
			  const class CG_str &CGs , 
			  class array<double> &CG_table);
 
  void PQG_partially_coupled_MEs_table_calc (
					     const enum dagger_tilde_operator_type dagger_tilde_operator ,
					     const class nucleons_data &prot_data ,
					     const class nucleons_data &neut_data ,
					     const class array<TYPE> &PQG_uncoupled_MEs_table ,
					     class array<TYPE> &PQG_partially_coupled_table);
  
  void PQG_test_dimensions_indices_calc (
					 const enum dagger_tilde_operator_type dagger_tilde_operator ,
					 const class nucleons_data &prot_data ,
					 const class nucleons_data &neut_data ,
					 class array<unsigned int> &PQG_test_dimensions ,
					 class array<unsigned int> &PQG_test_indices);
 
  void PQG_coupled_MEs_table_calc (
				   const enum dagger_tilde_operator_type dagger_tilde_operator ,
				   const class nucleons_data &prot_data ,
				   const class nucleons_data &neut_data ,
				   const class array<TYPE> &PQG_partially_coupled_MEs_table ,
				   class array<TYPE> &PQG_coupled_MEs_table);
 
  void T1_T2_CGs_table_calc (
			     const bool are_ab_coupled_first ,
			     const class array<class nljm_struct> &phi_table_p ,
			     const class array<class nljm_struct> &phi_table_q ,
			     const class array<class nljm_struct> &phi_table_r ,
			     const class CG_str &CGs , 
			     class array<double> &CG_L_table , 
			     class array<double> &CG_K_table);
  
  void T1_J_states_components_ppp_nnn_same_shell_calc (
						       const class nucleons_data &particles_data ,
						       class array<unsigned int> &alpha_number_same_shell_tab ,
						       class array<double> &J_states_components_same_shell);
 
  double Kmin_calc (const double Kmin_abc , const double j , const int Lmin_p , const int Lmax_p);
  double Kmax_calc (const double Kmax_abc , const double j , const int Lmin_p , const int Lmax_p);
	  
  void T1_T2_partially_coupled_MEs_table_calc (
					       const enum dagger_tilde_operator_type dagger_tilde_operator ,
					       const class nucleons_data &prot_data ,
					       const class nucleons_data &neut_data ,
					       const class array<TYPE> &T1_T2_uncoupled_MEs_table ,
					       class array<TYPE> &T1_T2_partially_coupled_MEs_table);
 
  void T1_T2_test_dimensions_indices_calc (
					   const enum dagger_tilde_operator_type dagger_tilde_operator ,
					   const class nucleons_data &prot_data ,
					   const class nucleons_data &neut_data ,
					   const class array<unsigned int> &alpha_number_same_shell_tab ,   
					   class array<unsigned int> &T1_T2_test_dimensions ,
					   class array<unsigned int> &T1_T2_test_indices);
  
  void T1_T2_coupled_MEs_table_calc (
				     const enum dagger_tilde_operator_type dagger_tilde_operator ,
				     const class nucleons_data &prot_data ,
				     const class nucleons_data &neut_data ,
				     const class array<TYPE> &T1_T2_partially_coupled_MEs_table ,
				     class array<TYPE> &T1_T2_coupled_MEs_table);
}

#endif
