#ifndef GSMCMTBMESANGULARTABLE_H
#define GSMCMTBMESANGULARTABLE_H

// TYPE is double or complex
// -------------------------

class CM_TBMEs_angular_table_str
{
public:
  
  CM_TBMEs_angular_table_str ();
  
  CM_TBMEs_angular_table_str (const enum operator_type CM_operator_inter , const double j_max , const int J);
  
  CM_TBMEs_angular_table_str (const enum operator_type CM_operator_inter , const double m_max);
  
  CM_TBMEs_angular_table_str (const CM_TBMEs_angular_table_str &X);

  ~CM_TBMEs_angular_table_str ();

  void allocate_calc_coupled (const enum operator_type CM_operator_inter , const double j_max , const int J);

  void allocate_calc_uncoupled (const enum operator_type CM_operator_inter , const double m_max);
  
  void allocate_fill (const class CM_TBMEs_angular_table_str &X);

  void deallocate ();

  int get_J () const
  {
    if (!coupled_TBMEs_angular_table.is_it_filled ()) error_message_print_abort ("integer J is defined only when using the J-scheme two-body code in CM_TBMEs_angular_table_str::get_J");
    
    return J;
  }
  
  bool is_it_filled () const
  {
    return (coupled_TBMEs_angular_table.is_it_filled () || CM_operator_factor_rank_CG_table.is_it_filled ());
  }
  
  double operator () (
		      const int ij0 , const int im0 , 
		      const int ij1 , const int im1 , 
		      const int ij2 , const int im2 , 
		      const int ij3 , const int im3) const;
  
  double operator () (const int ij0 , const int ij1 , const int ij2 , const int ij3) const;
  
  friend double used_memory_calc (const class CM_TBMEs_angular_table_str &T);

private:

  int CM_operator_mu; // rank projection, written as mu above (uncoupled scheme only)

  int J; // total angular momentum (coupled scheme only)

  int m_max_sum; // 2.m[max], with m[max] the maximal total angular projection of one-body states (uncoupled scheme only). This value is used to obtain ma + mb from m indices equal to m + m[max] (see GSM_small_classes.cpp).

  class array<double> coupled_TBMEs_angular_table; // products of phases and Wigner signs entering coupled TBMEs.
  
  class array<double> CM_operator_factor_rank_CG_table; // array of (1/3) . (-sqrt(3) for rank zero) . (-/+ sqrt(2) for L+/- operators) . <1 mi 1 mj | rank mu> values, 
                                                        // are stored in CM_operator_factor_rank_CG_table(i_mu,j_mu), with i_mu = mi + 1 and j_mu = mj + 1, so that the latter can be used as array indices (uncoupled scheme only).

  class array<double> CG_table; // array of <j m j' -m' |1 -m''> Clebsch-Gordan coefficients, with j,j' <= m_max (= jmax) and all possible values for m,m',m''
                                // stored as CG_table(ij , im , ijp , imp), with ij=j-1/2, im = m-m_max, ijp=j'-1/2, imp = m'-m_max (uncoupled scheme only).
};

#endif




