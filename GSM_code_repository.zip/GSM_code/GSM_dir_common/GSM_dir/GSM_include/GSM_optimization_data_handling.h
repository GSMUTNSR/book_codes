#ifndef OPTIMIZATION_DATA_HANDLING_H
#define OPTIMIZATION_DATA_HANDLING_H

// TYPE is double or complex
// -------------------------

namespace optimization_data_handling
{
  bool are_all_weights_zero_fixed_eigenset_determine (
						      const class input_data_str &input_data , 
						      const unsigned int eigenset_index);
    
  bool are_all_weights_zero_all_eigensets_determine (
						     const class array<class input_data_str> &input_data_tab);
  
  unsigned int N_states_to_fit_calc (const class array<class input_data_str> &input_data_tab);

  void state_indices_calc (
			   const class array<class input_data_str> &input_data_tab , 
			   class array<unsigned int> &state_indices);

  double weights_sum_calc (const class array<class input_data_str> &input_data_tab);
  
  void weights_normalization (const double factor , class array<class input_data_str> &input_data_tab);

  unsigned int eigensets_number_max_determine (const class array<class input_data_str> &input_data_tab);

  unsigned int eigenset_vectors_number_max_determine (const class array<class input_data_str> &input_data_tab);

  void FHT_EFT_parameters_from_input (
				      const class input_data_str &input_data_common , 
				      class vector_class<double> &FHT_EFT_parameters);

  void print_all_parameters (
			     const class input_data_str &input_data_common ,
			     const class vector_class<double> &FHT_EFT_parameters , 
			     ofstream &fit_results_file);

  bool is_there_reference_state_fixed_eigenset_determine (
							  const class input_data_str &input_data , 
							  const unsigned int eigenset_index);
 
  TYPE reference_state_energy_determine (
					 const class array<class input_data_str> &input_data_tab , 
					 const class array<class correlated_state_str> &PSI_qn_tab);
  
  class vector_class<TYPE> reference_state_E_grad_determine (
							     const unsigned int N_parameters_to_fit ,
							     const class array<class input_data_str> &input_data_tab , 
							     const class array<class correlated_state_str> &PSI_qn_tab , 
							     const class array<class vector_class<TYPE> > &E_grad_all_states);
 
  bool is_it_one_body_only_determine (const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index);
  
  string interaction_parameter_str (
				    const int global_lmax ,
				    const enum FHT_EFT_parameter_type FHT_EFT_parameter);

  void copy_common_data_to_input_data_tab (
					   const class input_data_str &input_data_common , 
					   class array<class input_data_str> &input_data_tab);

  class matrix<double> scaled_G_calc (
				      const class vector_class<double> &FHT_EFT_parameters_fit_indices , 
				      const class matrix<double> &G);
 
  void FHT_EFT_parameters_information_print (
					     const bool is_it_fixed_relative_SVD_precision ,
					     const double fixed_relative_SVD_precision ,
					     const unsigned int rejected_singular_values_number ,
					     const unsigned int N_states_to_fit , 
					     const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
					     const class array<bool> &is_there_l_dependence_from_fit_index , 
					     const class array<int> &l_from_fit_index ,
					     const class matrix<double> &G ,  
					     ofstream &fit_results_file);
    
  void fit_results_file_init (ofstream &fit_results_file);
  
  void results_calc_print (
			   const unsigned int N_states_to_fit ,
			   const class vector_class<double> &FHT_EFT_parameters ,
			   const class array<class interaction_class> &inter_data_units ,
			   const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index ,
			   class interaction_class &inter_data_Coulomb ,
			   class interaction_class &inter_data_basis ,
			   class interaction_class &inter_data ,
			   class GSM_vector &PSI_full , 
			   class array<class input_data_str> &input_data_tab ,
			   class array<bool> &is_there_l_dependence_from_fit_index ,
			   class array<int> &l_from_fit_index , 
			   ofstream &fit_results_file);

  void all_natural_orbitals_calc_store (
					const unsigned int N_nuclei_to_fit,
					const class interaction_class &inter_data_basis ,
					const class interaction_class &inter_data ,
					const class array<class input_data_str> &input_data_tab ,
					class GSM_vector &PSI_full);
  
  void unit_interactions_alloc_calc (
				     const class input_data_str &input_data_common ,
				     class array<class interaction_class> &inter_data_units);
  
  class vector_class<double> FHT_EFT_parameters_fit_indices_fill (
								  const int global_lmax , 
								  const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
								  const class array<bool> &is_there_l_dependence_from_fit_index , 
								  const class array<int> &l_from_fit_index , 
								  const class vector_class<double> &FHT_EFT_parameters);
  
  class vector_class<double> delta_FHT_EFT_parameters_fit_indices_scaled_calc (
									       const bool is_it_fixed_relative_SVD_precision ,
									       const double fixed_relative_SVD_precision ,
									       const unsigned int rejected_singular_values_number ,
									       const class vector_class<double> &FHT_EFT_parameters_fit_indices , 
									       const class vector_class<double> &delta_E_vector , 
									       const class matrix<double> &G);

  class vector_class<double> delta_FHT_EFT_parameters_fit_indices_unscale (
									   const class vector_class<double> &FHT_EFT_parameters_fit_indices , 
									   const class vector_class<double> &delta_FHT_EFT_parameters_fit_indices_scaled);

  class vector_class<double> delta_FHT_EFT_parameters_original_indices_fill (
									     const unsigned int N_parameters , 
									     const int global_lmax , 
									     const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
									     const class array<bool> &is_there_l_dependence_from_fit_index , 
									     const class array<int> &l_from_fit_index , 
									     const class vector_class<double> &delta_FHT_EFT_parameters_fit_indices);

  
  void matrix_vector_calc_from_energies_gradients (
						   const class array<class input_data_str> &input_data_tab , 
						   const class array<unsigned int> &state_indices , 
						   const class array<class correlated_state_str> &PSI_qn_tab , 
						   const class array<class vector_class<TYPE> > &E_grad_all_states , 
						   ofstream &fit_results_file , 
						   class vector_class<double> &delta_E_vector , 
						   class matrix<double> &G);

  void delta_E_vector_deltas_norm_precision_print (
						   const class vector_class<double> &delta_E_vector , 
						   const class vector_class<double> &delta_FHT_EFT_parameters , 
						   const class vector_class<double> &delta_FHT_EFT_parameters_scaled , 
						   ofstream &fit_results_file);

  void deltas_print (
		     const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
		     const class array<bool> &is_there_l_dependence_from_fit_index , 
		     const class array<int> &l_from_fit_index , 
		     const class vector_class<double> &delta_FHT_EFT_parameters_fit_indices , 
		     ofstream &fit_results_file);

  double relative_SVD_precision_calc (
				      const bool is_it_fixed_relative_SVD_precision ,
				      const double fixed_relative_SVD_precision ,
				      const unsigned int rejected_singular_values_number ,
				      const class matrix<double> &SVD_matrix);

  double cost_function_calc_from_energies_gradients (
						     const class array<class input_data_str> &input_data_tab , 
						     const class array<class correlated_state_str> &PSI_qn_tab , 
						     ofstream &fit_results_file);

  void cost_function_grad_calc_from_energies_gradients (
							const class array<class input_data_str> &input_data_tab , 
							const class array<class correlated_state_str> &PSI_qn_tab , 		
							const class array<class vector_class<TYPE> > &E_grad_all_states , 
							double &cost_function , 
							class vector_class<double> &cost_function_grad , 
							ofstream &fit_results_file);

  double cost_function_Hessian_matrix_element_calc (
						    const class array<class input_data_str> &input_data_tab ,
						    const class array<class correlated_state_str> &PSI_qn_tab , 
						    const class array<class vector_class<TYPE> > &E_grad_all_states ,
						    const class array<class matrix<TYPE> > &E_Hessian_matrices_all_states ,
						    const unsigned int fit_index , 
						    const unsigned int fit_index_prime);

  double cost_function_Hessian_matrix_element_linear_regression_calc (
								      const class array<class input_data_str> &input_data_tab ,
								      const class array<class correlated_state_str> &PSI_qn_tab , 
								      const class array<class vector_class<TYPE> > &E_grad_all_states ,
								      const unsigned int fit_index , 
								      const unsigned int fit_index_prime);

  void cost_function_Hessian_matrix_calc_print_from_all_states (
								const class array<class input_data_str> &input_data_tab , 
								const class array<class correlated_state_str> &PSI_qn_tab , 
								const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
								const class array<bool> &is_there_l_dependence_from_fit_index , 
								const class array<int> &l_from_fit_index , 
								const class array<class vector_class<TYPE> > &E_grad_all_states ,
								const class array<class matrix<TYPE> > &E_Hessian_matrices_all_states ,
								ofstream &fit_results_file);  
}

#endif

