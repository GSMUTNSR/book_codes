#ifndef GSMDAGGERTILDETABLES_H
#define GSMDAGGERTILDETABLES_H

template<typename C>
class uncoupled_dagger_tilde_table
{
public:
    
  explicit uncoupled_dagger_tilde_table () :
    ja (0.0) ,
    jb (0.0) ,
    jc (0.0) ,
    jd (0.0)
  {}
    
  explicit uncoupled_dagger_tilde_table (const double ja_c) :
    ja (0.0) ,
    jb (0.0) ,
    jc (0.0) ,
    jd (0.0)
  {
    allocate (ja_c);
  }

  explicit uncoupled_dagger_tilde_table (
					 const double ja_c , 
					 const double jb_c) :
    ja (0.0) ,
    jb (0.0) ,
    jc (0.0) ,
    jd (0.0)
  {
    allocate (ja_c , jb_c);
  }

  explicit uncoupled_dagger_tilde_table (
					 const double ja_c , 
					 const double jb_c , 
					 const double jc_c) :
    ja (0.0) ,
    jb (0.0) ,
    jc (0.0) ,
    jd (0.0)
  {
    allocate (ja_c , jb_c , jc_c);
  }
    
  explicit uncoupled_dagger_tilde_table (
					 const double ja_c , 
					 const double jb_c , 
					 const double jc_c, 
					 const double jd_c) :
    ja (0.0) ,
    jb (0.0) ,
    jc (0.0) ,
    jd (0.0)
  {
    allocate (ja_c , jb_c , jc_c , jd_c);
  }
    
  explicit uncoupled_dagger_tilde_table (const class uncoupled_dagger_tilde_table &X) :
    ja (0.0) ,
    jb (0.0) ,
    jc (0.0) ,
    jd (0.0)
  {
    allocate_fill (X);
  }
    
  ~uncoupled_dagger_tilde_table () {}
  
  void allocate (const double ja_c)
  {
    if (is_it_filled ()) error_message_print_abort ("uncoupled_dagger_tilde_table cannot be allocated twice (allocate (1))");
    
    ja = ja_c;
    
    jb = NADA;	
    jc = NADA;	
    jd = NADA;
	
    const unsigned int ja_number = make_uns_int (2.0*ja) + 1;
      
    table.allocate (ja_number);
  }

  
  void allocate (
		 const double ja_c , 
		 const double jb_c)
  {
    if (is_it_filled ()) error_message_print_abort ("uncoupled_dagger_tilde_table cannot be allocated twice (allocate (1))");
    
    ja = ja_c;
    jb = jb_c;
    
    jc = NADA;
    jd = NADA;
	
    const unsigned int ja_number = make_uns_int (2.0*ja) + 1;
    const unsigned int jb_number = make_uns_int (2.0*jb) + 1;
      
    table.allocate (ja_number , jb_number);
  }


  void allocate (
		 const double ja_c , 
		 const double jb_c , 
		 const double jc_c)
  { 
    if (is_it_filled ()) error_message_print_abort ("uncoupled_dagger_tilde_table cannot be allocated twice (allocate (2))");
    
    ja = ja_c;
    jb = jb_c; 
    jc = jc_c;
    
    jd = NADA;
      
    const unsigned int ja_number = make_uns_int (2.0*ja) + 1;
    const unsigned int jb_number = make_uns_int (2.0*jb) + 1;
    const unsigned int jc_number = make_uns_int (2.0*jc) + 1;

    table.allocate (ja_number , jb_number , jc_number);
  }

  void allocate (
		 const double ja_c , 
		 const double jb_c , 
		 const double jc_c , 
		 const double jd_c)
  { 
    if (is_it_filled ()) error_message_print_abort ("uncoupled_dagger_tilde_table cannot be allocated twice (allocate (2))");
    
    ja = ja_c;
    jb = jb_c; 
    jc = jc_c;
    jd = jd_c;
      
    const unsigned int ja_number = make_uns_int (2.0*ja) + 1;
    const unsigned int jb_number = make_uns_int (2.0*jb) + 1;
    const unsigned int jc_number = make_uns_int (2.0*jc) + 1;
    const unsigned int jd_number = make_uns_int (2.0*jd) + 1;

    table.allocate (ja_number , jb_number , jc_number , jd_number);
  }

  void allocate_fill (const class uncoupled_dagger_tilde_table &X)
  {
    if (is_it_filled ()) error_message_print_abort ("uncoupled_dagger_tilde_table cannot be allocated twice (allocate fill)");
    
    ja = X.ja;
    jb = X.jb; 
    jc = X.jc;
    jd = X.jd;
    
    table.allocate_fill (X.table);
  }
  
  void deallocate ()
  {
    table.deallocate ();
  }
    
  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }
    
  void operator = (const class uncoupled_dagger_tilde_table &X)
  {
    table = X.table;
  }

  void operator += (const class uncoupled_dagger_tilde_table &X)
  {
    table += X.table;
  }

  void operator -= (const class uncoupled_dagger_tilde_table &X)
  {
    table -= X.table;
  }

  void operator = (const C &x)
  {
    table = x;
  }

  void operator += (const C &x)
  {
    table += x;
  }

  void operator -= (const C &x)
  {
    table -= x;
  }
  
  C & operator () (const double ma) const
  {
    const unsigned int ma_index = make_uns_int (ma + ja);

    return table(ma_index);
  }

  C & operator () (
		   const double ma ,
		   const double mb) const
  {
    const unsigned int ma_index = make_uns_int (ma + ja);
    const unsigned int mb_index = make_uns_int (mb + jb);

    return table(ma_index , mb_index);
  }

  C & operator () (
		   const double ma ,
		   const double mb ,
		   const double mc) const
  {    
    const unsigned int ma_index = make_uns_int (ma + ja);
    const unsigned int mb_index = make_uns_int (mb + jb);
    const unsigned int mc_index = make_uns_int (mc + jc);
    
    return table(ma_index , mb_index , mc_index);
  }

  C & operator () (
		   const double ma ,
		   const double mb ,
		   const double mc ,
		   const double md) const
  {    
    const unsigned int ma_index = make_uns_int (ma + ja);
    const unsigned int mb_index = make_uns_int (mb + jb);
    const unsigned int mc_index = make_uns_int (mc + jc);
    const unsigned int md_index = make_uns_int (md + jd);

    return table(ma_index , mb_index , mc_index , md_index);
  }

  double get_ja () const
  {
    return ja;
  }

  double get_jb () const
  {
    return jb;
  }

  double get_jc () const
  {
    return jc;
  }
  
  double get_jd () const
  {
    return jd;
  }

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.first_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.last_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
  {
    return table.active_process_determine_for_MPI (group_processes_number , index);
  }
  
#ifdef UseMPI
  void MPI_Send (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif

private:
    
  double ja;
  double jb;
  double jc;
  double jd;
    
  class array<C> table;
};


#ifdef UseMPI

template <typename C>
void uncoupled_dagger_tilde_table<C>::MPI_Send (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Send ( Recv_process , tag , MPI_C);
}

template <typename C>
void uncoupled_dagger_tilde_table<C>::MPI_Recv (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Recv (Send_process , tag , MPI_C);
}

template <typename C>
void uncoupled_dagger_tilde_table<C>::MPI_Allgatherv (const MPI_Comm MPI_C)
{
  table.MPI_Allgatherv (MPI_C);
}

template <typename C>
void uncoupled_dagger_tilde_table<C>::MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  table.MPI_Bcast (Send_process , MPI_C);
}

template <typename C>
void uncoupled_dagger_tilde_table<C>::MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  table.MPI_Reduce (op , Recv_process , process , MPI_C);
}

template <typename C>
void uncoupled_dagger_tilde_table<C>::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  table.MPI_Allreduce (op , MPI_C);
}

#endif






template<typename C>
class coupled_dagger_tilde_table
{
public:

  explicit coupled_dagger_tilde_table () :
    dagger_tilde_operator (NO_DAGGER_TILDE_OPERATOR) ,
    L1_min (0) ,
    L1_max (0) ,
    L2_min (0) ,
    L2_max (0) ,
    Kmin (0.0) ,
    Kmax (0.0)
  {}
    
  explicit coupled_dagger_tilde_table (
				       const enum dagger_tilde_operator_type dagger_tilde_operator_c , 
				       const double ja) :
    dagger_tilde_operator (NO_DAGGER_TILDE_OPERATOR) ,
    L1_min (0) ,
    L1_max (0) ,
    L2_min (0) ,
    L2_max (0) ,
    Kmin (0.0) ,
    Kmax (0.0)
  {
    allocate (dagger_tilde_operator_c , ja);
  }

  explicit coupled_dagger_tilde_table (
				       const enum dagger_tilde_operator_type dagger_tilde_operator_c , 
				       const double ja , 
				       const double jb) :
    dagger_tilde_operator (NO_DAGGER_TILDE_OPERATOR) ,
    L1_min (0) ,
    L1_max (0) ,
    L2_min (0) ,
    L2_max (0) ,
    Kmin (0.0) ,
    Kmax (0.0)
  {
    allocate (dagger_tilde_operator_c , ja , jb);
  }

  explicit coupled_dagger_tilde_table (
				       const enum dagger_tilde_operator_type dagger_tilde_operator_c , 
				       const double ja , 
				       const double jb ,
				       const double jc) :
    dagger_tilde_operator (NO_DAGGER_TILDE_OPERATOR) ,
    L1_min (0) ,
    L1_max (0) ,
    L2_min (0) ,
    L2_max (0) ,
    Kmin (0.0) ,
    Kmax (0.0)
  { 
    allocate (dagger_tilde_operator_c , ja , jb , jc);
  }

  explicit coupled_dagger_tilde_table (
				       const enum dagger_tilde_operator_type dagger_tilde_operator_c , 
				       const double ja , 
				       const double jb ,
				       const double jc ,
				       const double jd) :
    dagger_tilde_operator (NO_DAGGER_TILDE_OPERATOR) ,
    L1_min (0) ,
    L1_max (0) ,
    L2_min (0) ,
    L2_max (0) ,
    Kmin (0.0) ,
    Kmax (0.0)
  { 
    allocate (dagger_tilde_operator_c , ja , jb , jc , jd);
  }

  explicit coupled_dagger_tilde_table (const class coupled_dagger_tilde_table &X) :
    dagger_tilde_operator (NO_DAGGER_TILDE_OPERATOR) ,
    L1_min (0) ,
    L1_max (0) ,
    L2_min (0) ,
    L2_max (0) ,
    Kmin (0.0) ,
    Kmax (0.0)
  {
    allocate_fill (X);
  }

  ~coupled_dagger_tilde_table () {}
  
  void allocate (
		 const enum dagger_tilde_operator_type dagger_tilde_operator_c , 
		 const double ja)
  {
    if (is_it_filled ()) error_message_print_abort ("coupled_dagger_tilde_table cannot be allocated twice (allocate (1))");
    
    dagger_tilde_operator = dagger_tilde_operator_c;

    if (!is_it_one_body_determine (dagger_tilde_operator)) error_message_print_abort ("one-body coupled a+ a~ operators only in this coupled_dagger_tilde_table constructor (allocate (1))");
      
    L1_min = NADA;
    L1_max = NADA;
    
    L2_min = NADA;
    L2_max = NADA;
    
    Kmin = Kmax = ja;
      
    table.allocate (1);
  }

  void allocate (
		 const enum dagger_tilde_operator_type dagger_tilde_operator_c , 
		 const double ja , 
		 const double jb)
  {
    if (is_it_filled ()) error_message_print_abort ("coupled_dagger_tilde_table cannot be allocated twice (allocate (2))");
    
    dagger_tilde_operator = dagger_tilde_operator_c;
      
    if (!is_it_two_body_determine (dagger_tilde_operator)) error_message_print_abort ("two-body coupled a+ a~ operators only in this coupled_dagger_tilde_table constructor (allocate (2))");
 
    L1_min = NADA;
    L1_max = NADA;
    
    L2_min = NADA;
    L2_max = NADA;
    
    Kmin = abs (ja - jb);
    
    Kmax = ja + jb;
	
    const unsigned int K_number = make_uns_int (Kmax - Kmin) + 1;
      
    table.allocate (K_number);
  }

  void allocate (
		 const enum dagger_tilde_operator_type dagger_tilde_operator_c , 
		 const double ja , 
		 const double jb ,
		 const double jc) 
  {
    if (is_it_filled ()) error_message_print_abort ("coupled_dagger_tilde_table cannot be allocated twice (allocate (3))");
  
    dagger_tilde_operator = dagger_tilde_operator_c;
    
    if (!is_it_three_body_determine (dagger_tilde_operator)) error_message_print_abort ("three-body coupled a+ a~ operators only in this coupled_dagger_tilde_table constructor (allocate (3))");
    
    const bool is_it_dagger_a = is_it_dagger_determine (dagger_tilde_operator , 0);
    const bool is_it_dagger_b = is_it_dagger_determine (dagger_tilde_operator , 1);
    const bool is_it_dagger_c = is_it_dagger_determine (dagger_tilde_operator , 2);
    
    const bool is_it_a_dagger_a_dagger_a_tilde  = (is_it_dagger_a && is_it_dagger_b && !is_it_dagger_c);
    const bool is_it_a_dagger_a_dagger_a_dagger = (is_it_dagger_a && is_it_dagger_b &&  is_it_dagger_c);
  
    const bool are_ab_coupled_first = (is_it_a_dagger_a_dagger_a_tilde || is_it_a_dagger_a_dagger_a_dagger);
  
    L2_min = NADA;
    L2_max = NADA;
    
    Kmax = ja + jb + jc;
    
    Kmin = Kmax;
    
    if (are_ab_coupled_first)
      {
	L1_min = abs (make_int (ja - jb));
	
	L1_max = make_int (ja + jb);
	
	for (int L1 = L1_min ; L1 <= L1_max ; L1++) Kmin = min (Kmin , abs (jc - L1));	
      }    
    else
      {
	L1_min = abs (make_int (jb - jc));
	
	L1_max = make_int (jb + jc);

	for (int L1 = L1_min ; L1 <= L1_max ; L1++) Kmin = min (Kmin , abs (ja - L1));	  
      }
      
    const unsigned int L1_number = make_uns_int (L1_max - L1_min) + 1;
    
    const unsigned int K_number = make_uns_int (Kmax - Kmin) + 1;

    table.allocate (L1_number , K_number);
  }



  void allocate (
		 const enum dagger_tilde_operator_type dagger_tilde_operator_c , 
		 const double ja , 
		 const double jb ,
		 const double jc ,
		 const double jd) 
  {
    if (is_it_filled ()) error_message_print_abort ("coupled_dagger_tilde_table cannot be allocated twice (allocate (4))");
  
    dagger_tilde_operator = dagger_tilde_operator_c;
    
    if (!is_it_four_body_determine (dagger_tilde_operator)) error_message_print_abort ("four-body coupled a+ a~ operators only in this coupled_dagger_tilde_table constructor (allocate (4))");
    
    Kmax = ja + jb + jc + jd;
    
    Kmin = Kmax;
    
    L1_min = abs (make_int (ja - jb));
    L2_min = abs (make_int (jc - jd));
    
    L1_max = make_int (ja + jb);	
    L2_max = make_int (jc + jd);
	
    for (int L1 = L1_min ; L1 <= L1_max ; L1++)
      for (int L2 = L2_min ; L2 <= L2_max ; L2++)	
	Kmin = min (make_int (Kmin) , abs (L1 - L2));
	
    const unsigned int L1_number = make_uns_int (L1_max - L1_min) + 1;
    const unsigned int L2_number = make_uns_int (L2_max - L2_min) + 1;
    
    const unsigned int K_number = make_uns_int (Kmax - Kmin) + 1;

    table.allocate (L1_number , L2_number , K_number);
  }



  
  void allocate_fill (const class coupled_dagger_tilde_table &X)
  {
    if (is_it_filled ()) error_message_print_abort ("coupled_dagger_tilde_table cannot be allocated twice (allocate fill)");
    
    dagger_tilde_operator = X.dagger_tilde_operator;
    
    L1_min = X.L1_min;
    L1_max = X.L1_max;
    
    L2_min = X.L2_min;
    L2_max = X.L2_max;
    
    Kmin = X.Kmin;
    Kmax = X.Kmax;
    
    table.allocate_fill (X.table);
  }

  void deallocate ()
  {
    table.deallocate ();

    dagger_tilde_operator = NO_DAGGER_TILDE_OPERATOR;
    
    L1_min = 0;
    L1_max = 0;
    
    L2_min = 0;
    L2_max = 0;
    
    Kmin = 0;
    Kmax = 0;
  }

  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }
    
  enum dagger_tilde_operator_type get_dagger_tilde_operator () const
  {
    return dagger_tilde_operator;
  }
    
  int get_Lmin () const
  {
    if (!is_it_three_body_determine (dagger_tilde_operator)) error_message_print_abort ("Three-body coupled a+ a~ operators only in get_Lmin");
    
    return L1_min;
  }

  int get_Lmax () const
  {
    if (!is_it_three_body_determine (dagger_tilde_operator)) error_message_print_abort ("Three-body coupled a+ a~ operators only in get_Lmax");
    
    return L1_max;
  }
    
  int get_L1_min () const
  {
    if (!is_it_four_body_determine (dagger_tilde_operator)) error_message_print_abort ("Four-body coupled a+ a~ operators only in get_L1_min");
    
    return L1_min;
  }

  int get_L1_max () const
  {
    if (!is_it_four_body_determine (dagger_tilde_operator)) error_message_print_abort ("Four-body coupled a+ a~ operators only in get_L1_max");
    
    return L1_max;
  }
    
  int get_L2_min () const
  {
    if (!is_it_four_body_determine (dagger_tilde_operator)) error_message_print_abort ("Four-body coupled a+ a~ operators only in get_L2_min");
    
    return L2_min;
  }

  int get_L2_max () const
  {
    if (!is_it_four_body_determine (dagger_tilde_operator)) error_message_print_abort ("Four-body coupled a+ a~ operators only in get_L2_max");
    
    return L2_max;
  }
    
  double get_Kmin () const
  {
    return Kmin;
  }

  double get_Kmax () const
  {
    return Kmax;
  }

  void operator = (const class coupled_dagger_tilde_table &X)
  {
    table = X.table;
  }

  void operator += (const class coupled_dagger_tilde_table &X)
  {
    table += X.table;
  }

  void operator -= (const class coupled_dagger_tilde_table &X)
  {
    table -= X.table;
  }

  void operator = (const C &x)
  {
    table = x;
  }

  void operator += (const C &x)
  {
    table += x;
  }

  void operator -= (const C &x)
  {
    table -= x;
  }
  
  C & operator () (const double K) const
  {
    const unsigned int iK = make_uns_int (K - Kmin);

    return table(iK);
  }

  C & operator () (
		   const double L1 ,
		   const double K) const
  {
    const unsigned int iL1 = make_uns_int (L1 - L1_min);
    
    const unsigned int iK = make_uns_int (K - Kmin);

    return table(iL1 , iK);
  }
    
  C & operator () (
		   const double L1 ,
		   const double L2 ,
		   const double K) const
  {
    const unsigned int iL1 = make_uns_int (L1 - L1_min);
    const unsigned int iL2 = make_uns_int (L2 - L2_min);
    
    const unsigned int iK = make_uns_int (K - Kmin);

    return table(iL1 , iL2 , iK);
  }
    
  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.first_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.last_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
  {
    return table.active_process_determine_for_MPI (group_processes_number , index);
  }
  
#ifdef UseMPI
  void MPI_Send (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif

private:

  enum dagger_tilde_operator_type dagger_tilde_operator;
  
  int L1_min;
  int L1_max;
  
  int L2_min;
  int L2_max;
  
  double Kmin;
  double Kmax;
    
  class array<C> table;
};







#ifdef UseMPI

template <typename C>
void coupled_dagger_tilde_table<C>::MPI_Send (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Send ( Recv_process , tag , MPI_C);
}

template <typename C>
void coupled_dagger_tilde_table<C>::MPI_Recv (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Recv (Send_process , tag , MPI_C);
}

template <typename C>
void coupled_dagger_tilde_table<C>::MPI_Allgatherv (const MPI_Comm MPI_C)
{
  table.MPI_Allgatherv (MPI_C);
}

template <typename C>
void coupled_dagger_tilde_table<C>::MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  table.MPI_Bcast (Send_process , MPI_C);
}

template <typename C>
void coupled_dagger_tilde_table<C>::MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  table.MPI_Reduce (op , Recv_process , MPI_C);
}

template <typename C>
void coupled_dagger_tilde_table<C>::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  table.MPI_Allreduce (op , MPI_C);
}

#endif






#endif
