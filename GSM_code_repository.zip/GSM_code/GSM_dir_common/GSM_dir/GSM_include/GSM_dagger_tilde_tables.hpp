#ifndef GSMDAGGERTILDETABLES_H
#define GSMDAGGERTILDETABLES_H

template<typename C>
class uncoupled_dagger_tilde_table
{
public:
    
  uncoupled_dagger_tilde_table () :
    ja (0.0) ,
    jb (0.0) ,
    jc (0.0)
  {}
    
  uncoupled_dagger_tilde_table (
				const double ja_c , 
				const double jb_c) :
    ja (0.0) ,
    jb (0.0) ,
    jc (0.0)
  {
    allocate (ja_c , jb_c);
  }


  uncoupled_dagger_tilde_table (
				const double ja_c , 
				const double jb_c , 
				const double jc_c) :
    ja (0.0) ,
    jb (0.0) ,
    jc (0.0)
  {
    allocate (ja_c , jb_c , jc_c);
  }
    
  uncoupled_dagger_tilde_table (const class uncoupled_dagger_tilde_table &X) :
    ja (0.0) ,
    jb (0.0) ,
    jc (0.0)
  {
    allocate_fill (X);
  }
    
  ~uncoupled_dagger_tilde_table () {}
  
  void allocate (
		 const double ja_c , 
		 const double jb_c)
  {
    if (is_it_filled ()) error_message_print_abort ("uncoupled_dagger_tilde_table cannot be allocated twice (allocate (1))");
    
    ja = ja_c;
    jb = jb_c;
    
    jc = NADA;
	
    const unsigned int ja_number = make_uns_int (2.0*ja) + 1;
    const unsigned int jb_number = make_uns_int (2.0*jb) + 1;
      
    table.allocate (ja_number , jb_number);
  }


  void allocate (
		 const double ja_c , 
		 const double jb_c , 
		 const double jc_c)
  { 
    if (is_it_filled ()) error_message_print_abort ("uncoupled_dagger_tilde_table cannot be allocated twice (allocate (2))");
    
    ja = ja_c;
    jb = jb_c; 
    jc = jc_c;
      
    const unsigned int ja_number = make_uns_int (2.0*ja) + 1;
    const unsigned int jb_number = make_uns_int (2.0*jb) + 1;
    const unsigned int jc_number = make_uns_int (2.0*jc) + 1;

    table.allocate (ja_number , jb_number , jc_number);
  }

  void allocate_fill (const class uncoupled_dagger_tilde_table &X)
  {
    if (is_it_filled ()) error_message_print_abort ("uncoupled_dagger_tilde_table cannot be allocated twice (allocate fill)");
    
    ja = X.ja;
    jb = X.jb; 
    jc = X.jc;
    
    table.allocate_fill (X.table);
  }
  
  void deallocate ()
  {
    table.deallocate ();
  }
    
  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }
    
  void operator = (const class uncoupled_dagger_tilde_table &X)
  {
    table = X.table;
  }

  void operator += (const class uncoupled_dagger_tilde_table &X)
  {
    table += X.table;
  }

  void operator -= (const class uncoupled_dagger_tilde_table &X)
  {
    table -= X.table;
  }

  void operator = (const C &x)
  {
    table = x;
  }

  void operator += (const C &x)
  {
    table += x;
  }

  void operator -= (const C &x)
  {
    table -= x;
  }

  C & operator () (
		   const double m1 ,
		   const double m2) const
  {
    const unsigned int m1_index = make_uns_int (m1 + ja);
    const unsigned int m2_index = make_uns_int (m2 + jb);

    return table(m1_index , m2_index);
  }

  C & operator () (
		   const double m1 ,
		   const double m2 ,
		   const double m3) const
  {    
    const unsigned int m1_index = make_uns_int (m1 + ja);
    const unsigned int m2_index = make_uns_int (m2 + jb);
    const unsigned int m3_index = make_uns_int (m3 + jc);

    return table(m1_index , m2_index , m3_index);
  }

  double get_ja () const
  {
    return ja;
  }

  double get_jb () const
  {
    return jb;
  }

  double get_jc () const
  {
    return jc;
  }

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.first_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.last_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
  {
    return table.active_process_determine_for_MPI (group_processes_number , index);
  }
  
#ifdef UseMPI
  void MPI_Send (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif

private:
    
  double ja;
  double jb;
  double jc;
    
  class array<C> table;
};


#ifdef UseMPI

template <typename C>
void uncoupled_dagger_tilde_table<C>::MPI_Send (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Send ( Recv_process , tag , MPI_C);
}

template <typename C>
void uncoupled_dagger_tilde_table<C>::MPI_Recv (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Recv (Send_process , tag , MPI_C);
}

template <typename C>
void uncoupled_dagger_tilde_table<C>::MPI_Allgatherv (const MPI_Comm MPI_C)
{
  table.MPI_Allgatherv (MPI_C);
}

template <typename C>
void uncoupled_dagger_tilde_table<C>::MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  table.MPI_Bcast (Send_process , MPI_C);
}

template <typename C>
void uncoupled_dagger_tilde_table<C>::MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  table.MPI_Reduce (op , Recv_process , process , MPI_C);
}

template <typename C>
void uncoupled_dagger_tilde_table<C>::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  table.MPI_Allreduce (op , MPI_C);
}

#endif






template<typename C>
class coupled_dagger_tilde_table
{
public:

  coupled_dagger_tilde_table () :
    dagger_tilde_operator (NO_DAGGER_TILDE_OPERATOR) ,
    Lmin (0) ,
    Lmax (0) ,
    Kmin (0.0) ,
    Kmax (0.0)
  {}
    
  coupled_dagger_tilde_table (
			      const enum dagger_tilde_operator_type dagger_tilde_operator_c , 
			      const double ja , 
			      const double jb) :
    dagger_tilde_operator (NO_DAGGER_TILDE_OPERATOR) ,
    Lmin (0) ,
    Lmax (0) ,
    Kmin (0.0) ,
    Kmax (0.0)
  {
    allocate (dagger_tilde_operator_c , ja , jb);
  }


  coupled_dagger_tilde_table (
			      const enum dagger_tilde_operator_type dagger_tilde_operator_c , 
			      const double ja , 
			      const double jb ,
			      const double jc) :
    dagger_tilde_operator (NO_DAGGER_TILDE_OPERATOR) ,
    Lmin (0) ,
    Lmax (0) ,
    Kmin (0.0) ,
    Kmax (0.0)
  { 
    allocate (dagger_tilde_operator_c , ja , jb , jc);
  }

  coupled_dagger_tilde_table (const class coupled_dagger_tilde_table &X) :
    dagger_tilde_operator (NO_DAGGER_TILDE_OPERATOR) ,
    Lmin (0) ,
    Lmax (0) ,
    Kmin (0.0) ,
    Kmax (0.0)
  {
    allocate_fill (X);
  }

  ~coupled_dagger_tilde_table () {}
  
  void allocate (
		 const enum dagger_tilde_operator_type dagger_tilde_operator_c , 
		 const double ja , 
		 const double jb)
  {
    dagger_tilde_operator = dagger_tilde_operator_c;
      
    Lmin = NADA;
    Lmax = NADA;
    
    Kmin = abs (ja - jb);
    
    Kmax = ja + jb;
	
    const unsigned int K_number = make_uns_int (Kmax - Kmin) + 1;
      
    table.allocate (K_number);
  }


  

  void allocate (
		 const enum dagger_tilde_operator_type dagger_tilde_operator_c , 
		 const double ja , 
		 const double jb ,
		 const double jc) 
  {
    if (dagger_tilde_operator != NO_DAGGER_TILDE_OPERATOR) error_message_print_abort ("coupled_dagger_tilde_table cannot be allocated twice (allocate)");
  
    dagger_tilde_operator = dagger_tilde_operator_c;
    
    const bool is_it_dagger_a = is_it_dagger_determine (dagger_tilde_operator , 0);
    const bool is_it_dagger_b = is_it_dagger_determine (dagger_tilde_operator , 1);
    const bool is_it_dagger_c = is_it_dagger_determine (dagger_tilde_operator , 2);
    
    const bool is_it_a_dagger_a_dagger_a_tilde  = (is_it_dagger_a && is_it_dagger_b && !is_it_dagger_c);
    const bool is_it_a_dagger_a_dagger_a_dagger = (is_it_dagger_a && is_it_dagger_b &&  is_it_dagger_c);
  
    const bool are_ab_coupled_first = (is_it_a_dagger_a_dagger_a_tilde || is_it_a_dagger_a_dagger_a_dagger);
  
    Kmax = ja + jb + jc;
    
    Kmin = Kmax;
    
    if (are_ab_coupled_first)
      {
	Lmin = abs (make_int (ja - jb));
	
	Lmax = make_int (ja + jb);
	
	for (int L = Lmin ; L <= Lmax ; L++) Kmin = min (Kmin , abs (jc - L));	
      }    
    else
      {
	Lmin = abs (make_int (jb - jc));
	
	Lmax = make_int (jb + jc);

	for (int L = Lmin ; L <= Lmax ; L++) Kmin = min (Kmin , abs (ja - L));	  
      }
      
    const unsigned int L_number = make_uns_int (Lmax - Lmin) + 1;
    const unsigned int K_number = make_uns_int (Kmax - Kmin) + 1;

    table.allocate (L_number , K_number);
  }



  
  void allocate_fill (const class coupled_dagger_tilde_table &X)
  {
    if (dagger_tilde_operator != NO_DAGGER_TILDE_OPERATOR) error_message_print_abort ("coupled_dagger_tilde_table cannot be allocated twice (allocate fill)");
    
    dagger_tilde_operator = X.dagger_tilde_operator;
    
    Lmin = X.Lmin;
    Lmax = X.Lmax;
    
    Kmin = X.Kmin;
    Kmax = X.Kmax;
    
    table.allocate_fill (X.table);
  }

  void deallocate ()
  {
    table.deallocate ();

    dagger_tilde_operator = NO_DAGGER_TILDE_OPERATOR;
    
    Lmin = 0;
    Lmax = 0;
    
    Kmin = 0;
    Kmax = 0;
  }

  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }
    
  enum dagger_tilde_operator_type get_dagger_tilde_operator () const
  {
    return dagger_tilde_operator;
  }
    
  int get_Lmin () const
  {
    return Lmin;
  }

  int get_Lmax () const
  {
    return Lmax;
  }
    
  double get_Kmin () const
  {
    return Kmin;
  }

  double get_Kmax () const
  {
    return Kmax;
  }

  void operator = (const class coupled_dagger_tilde_table &X)
  {
    table = X.table;
  }

  void operator += (const class coupled_dagger_tilde_table &X)
  {
    table += X.table;
  }

  void operator -= (const class coupled_dagger_tilde_table &X)
  {
    table -= X.table;
  }

  void operator = (const C &x)
  {
    table = x;
  }

  void operator += (const C &x)
  {
    table += x;
  }

  void operator -= (const C &x)
  {
    table -= x;
  }
  
  C & operator () (const double K) const
  {
    const unsigned int iK = make_uns_int (K - Kmin);

    return table(iK);
  }

  C & operator () (
		   const double L ,
		   const double K) const
  {
    const unsigned int iL = make_uns_int (L - Lmin);
    const unsigned int iK = make_uns_int (K - Kmin);

    return table(iL , iK);
  }
    
  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.first_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.last_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
  {
    return table.active_process_determine_for_MPI (group_processes_number , index);
  }
  
#ifdef UseMPI
  void MPI_Send (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif

private:

  enum dagger_tilde_operator_type dagger_tilde_operator;
  
  int Lmin;
  int Lmax;
  
  double Kmin;
  double Kmax;
    
  class array<C> table;
};







#ifdef UseMPI

template <typename C>
void coupled_dagger_tilde_table<C>::MPI_Send (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Send ( Recv_process , tag , MPI_C);
}

template <typename C>
void coupled_dagger_tilde_table<C>::MPI_Recv (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Recv (Send_process , tag , MPI_C);
}

template <typename C>
void coupled_dagger_tilde_table<C>::MPI_Allgatherv (const MPI_Comm MPI_C)
{
  table.MPI_Allgatherv (MPI_C);
}

template <typename C>
void coupled_dagger_tilde_table<C>::MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  table.MPI_Bcast (Send_process , MPI_C);
}

template <typename C>
void coupled_dagger_tilde_table<C>::MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  table.MPI_Reduce (op , Recv_process , MPI_C);
}

template <typename C>
void coupled_dagger_tilde_table<C>::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  table.MPI_Allreduce (op , MPI_C);
}

#endif






#endif
