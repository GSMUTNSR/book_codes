#ifndef GSMBETATRANSITIONSRADIALOBMES_H
#define GSMBETATRANSITIONSRADIALOBMES_H

// TYPE is double or complex
// -------------------------

namespace beta_transitions_radial_OBMEs
{
  TYPE radial_integral_HO_calc (
				const enum radial_operator_type radial_operator , 
				const class interaction_class &inter_data , 
				const double R_charge , 
				const unsigned int a , 
				const unsigned int b);

  TYPE radial_integral_calc (
			     const bool is_it_HO_expansion , 
			     const enum radial_operator_type radial_operator , 
			     const double R_charge , 
			     const class spherical_state &wf_in , 
			     const class spherical_state &wf_out);

  void radial_OBMEs_calc (
			  const bool is_it_HO_expansion , 
			  const enum radial_operator_type radial_operator , 
			  const class interaction_class &inter_data , 
			  const class nucleons_data &data_in , 
			  const class nucleons_data &data_out , 
			  class array<TYPE> &radial_OBMEs);
	
  void beta_suboperator_radial_OBMEs_reduced_calc (
						   const int A , 
						   const bool is_it_HO_expansion , 
						   const enum radial_operator_type radial_operator , 
						   const enum beta_suboperator_type beta_suboperator , 
						   const class nucleons_data &data_in , 
						   const class nucleons_data &data_out , 
						   class array<TYPE> &radial_OBMEs);
 
  void radial_OBMEs_reduced_calc (
				  const bool is_it_HO_expansion , 
				  const int A , 
				  const enum radial_operator_type radial_operator , 
				  const enum beta_suboperator_type beta_suboperator , 
				  const class interaction_class &inter_data , 
				  const class nucleons_data &data_in , 
				  const class nucleons_data &data_out , 
				  class array<TYPE> &radial_OBMEs);

  void beta_suboperator_radial_OBMEs_calc (
					   const int A , 
					   const bool is_it_HO_expansion , 
					   const enum radial_operator_type radial_operator , 
					   const enum beta_suboperator_type beta_suboperator , 
					   const int M_Op , 
					   const class nucleons_data &data_in , 
					   const class nucleons_data &data_out , 
					   class array<TYPE> &radial_OBMEs);
}

#endif


