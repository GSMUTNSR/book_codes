#ifndef GSMVECTORDIMENSIONS_H
#define GSMVECTORDIMENSIONS_H

// TYPE is double or complex
// -------------------------

class input_data_str;

namespace GSM_vector_dimensions
{  
  double optimal_M_calc (
			 const class input_data_str &input_data ,
			 const class nucleons_data &prot_data , 
			 const class nucleons_data &neut_data , 
			 const unsigned int BP , 
			 const double J);

  double optimal_M_calc_one_configuration (
					   const enum space_type space , 
					   const class nucleons_data &prot_data , 
					   const class nucleons_data &neut_data , 
					   const double J);

  void M_table_calc (
		     const class input_data_str &input_data ,
		     const class nucleons_data &prot_data , 
		     const class nucleons_data &neut_data , 
		     const class array<unsigned int> &BP_eigenset_tab , 
		     const class array<double> &J_eigenset_tab , 
		     class array<double> &M_table);

  bool is_basis_state_in_space_pp_nn (
				      const bool truncation_hw , 
				      const bool truncation_ph , 
				      const int n_holes , 
				      const int n_scat , 
				      const int E_hw , 
				      const int n_holes_max , 
				      const int n_scat_max , 
				      const int E_max_hw);

  bool is_basis_state_in_space_pn (
				   const bool truncation_hw , 
				   const bool truncation_ph , 
				   const int n_holes_p , 
				   const int n_scat_p , 
				   const int Ep_hw , 
				   const int n_holes_n , 
				   const int n_scat_n , 
				   const int En_hw , 
				   const int n_holes_max , 
				   const int n_scat_max , 
				   const int E_max_hw);

  unsigned long int total_space_dimension_M_calc_pp_nn (
							const bool truncation_hw , 
							const bool truncation_ph ,
							const int n_holes_max , 
							const int n_scat_max , 
							const int E_max_hw , 
							const class nucleons_data &particles_data , 
							const unsigned int BP , 
							const double M);

  unsigned long int total_space_dimension_M_calc_pn (
						     const bool truncation_hw , 
						     const bool truncation_ph ,
						     const int n_holes_max_p , 
						     const int n_scat_max_p ,
						     const int n_holes_max_n , 
						     const int n_scat_max_n , 
						     const int Ep_max_hw ,
						     const int En_max_hw ,
						     const int n_holes_max ,  
						     const int n_scat_max , 
						     const int E_max_hw , 
						     const class nucleons_data &prot_data , 
						     const class nucleons_data &neut_data , 
						     const unsigned int BP , 
						     const double M);
  
  unsigned long int total_space_dimension_M_calc (
						  const enum space_type space , 
						  const bool truncation_hw , 
						  const bool truncation_ph ,
						  const int n_holes_max_p ,  
						  const int n_scat_max_p , 
						  const int Ep_max_hw , 
						  const int n_holes_max_n , 
						  const int n_scat_max_n , 
						  const int En_max_hw , 
						  const int n_holes_max , 
						  const int n_scat_max , 
						  const int E_max_hw , 
						  const class nucleons_data &prot_data , 
						  const class nucleons_data &neut_data , 
						  const unsigned int BP , 
						  const double M);

  unsigned int total_space_dimension_M_calc_pp_nn_one_configuration (
								     const class nucleons_data &particles_data , 
								     const double M);

  unsigned int total_space_dimension_M_calc_pn_one_configuration (
								  const class nucleons_data &prot_data , 
								  const class nucleons_data &neut_data , 
								  const double M);

  unsigned int total_space_dimension_M_calc_one_configuration (
							       const enum space_type space , 
							       const class nucleons_data &prot_data , 
							       const class nucleons_data &neut_data , 
							       const double M);

  double M_max_calc (
		     const enum space_type space , 
		     const class nucleons_data &prot_data , 
		     const class nucleons_data &neut_data);

  double M_max_dimension_non_zero_calc (
					const unsigned int BP , 
					const enum space_type space , 
					const bool truncation_hw , 
					const bool truncation_ph ,
					const int n_holes_max_p ,   
					const int n_scat_max_p , 
					const int Ep_max_hw , 
					const int n_holes_max_n , 
					const int n_scat_max_n , 
					const int En_max_hw , 
					const int n_holes_max , 
					const int n_scat_max , 
					const int E_max_hw , 
					const class nucleons_data &prot_data , 
					const class nucleons_data &neut_data);

  double M_max_dimension_non_zero_calc_one_configuration (
							  const enum space_type space , 
							  const class nucleons_data &prot_data , 
							  const class nucleons_data &neut_data);

  void J_total_space_dimensions_calc_print (
					    const bool is_there_cout , 
					    const bool is_it_pole_approximation ,
					    const class input_data_str &input_data , 
					    const class nucleons_data &prot_data , 
					    const class nucleons_data &neut_data , 
					    class array<unsigned long int> &total_space_dimensions_good_J);

  unsigned int BP_J_dimension_calc_print_one_configuration (
							    const enum space_type space , 
							    const class nucleons_data &prot_data , 
							    const class nucleons_data &neut_data , 
							    const unsigned int BP ,
							    const double J);

  void all_J_total_space_dimensions_calc_print (
						const bool is_there_cout , 
						const class input_data_str &input_data , 
						const class nucleons_data &prot_data , 
						const class nucleons_data &neut_data , 
						class array<unsigned long int> &dimensions_good_J_pole_approximation ,
						class array<unsigned long int> &dimensions_good_J);

  unsigned int J_index_max_calc (
				 const enum space_type space , 
				 const class nucleons_data &prot_data , 
				 const class nucleons_data &neut_data);
  
  unsigned int J_number_calc (
			      const enum space_type space ,
			      const class nucleons_data &prot_data , 
			      const class nucleons_data &neut_data , 
			      const unsigned int BP ,
			      const unsigned int n_scat_max ,
			      const double M , 
			      const class array<unsigned long int> &total_space_dimensions_good_J);
  
  unsigned int J_number_max_calc (
				  const enum space_type space ,
				  const class nucleons_data &prot_data , 
				  const class nucleons_data &neut_data ,
				  const unsigned int n_scat_max ,
				  const class array<unsigned long int> &total_space_dimensions_good_J);
}






  
class sum_GSM_vector_dimensions_class
{
public:
  sum_GSM_vector_dimensions_class ();

  sum_GSM_vector_dimensions_class (
				   const enum space_type space_c , 
				   const bool truncation_hw , 
				   const bool truncation_ph ,
				   const int n_holes_max_p_c ,  
				   const int n_scat_max_p_c ,
				   const int Ep_max_hw_c , 
				   const int n_holes_max_n_c , 
				   const int n_scat_max_n_c , 
				   const int En_max_hw_c , 
				   const int n_holes_max_c ,
				   const int n_scat_max_c ,
				   const int E_max_hw_c , 
				   const class nucleons_data &prot_data , 
				   const class nucleons_data &neut_data , 
				   const unsigned int BP , 
				   const int iM , 
				   const int iMp_min_M , 
				   const int iMp_max_M ,
				   const int iMn_min_M , 
				   const int iMn_max_M);

  sum_GSM_vector_dimensions_class (const class sum_GSM_vector_dimensions_class &X);

  void allocate (
		 const enum space_type space_c , 
		 const bool truncation_hw , 
		 const bool truncation_ph ,
		 const int n_holes_max_p_c ,  
		 const int n_scat_max_p_c ,
		 const int Ep_max_hw_c , 
		 const int n_holes_max_n_c , 
		 const int n_scat_max_n_c , 
		 const int En_max_hw_c , 
		 const int n_holes_max_c ,
		 const int n_scat_max_c ,
		 const int E_max_hw_c , 
		 const class nucleons_data &prot_data , 
		 const class nucleons_data &neut_data , 
		 const unsigned int BP , 
		 const int iM , 
		 const int iMp_min_M , 
		 const int iMp_max_M ,
		 const int iMn_min_M , 
		 const int iMn_max_M);

  void allocate_fill (const class sum_GSM_vector_dimensions_class &X);
    
  void deallocate ();

  bool is_it_filled () const
  {
    return (space != NO_SPACE);
  }
  
  unsigned long int & operator () (
				   const unsigned int BPp , 
				   const int n_scat_p , 
				   const int n_scat_n , 
				   const int iCp , 
				   const int iCn , 
				   const int iMp) const
  {
    if (BPp == 0)
      {
	const class array<unsigned long int> &table_pn_0 = tables_pn_0(n_scat_p , n_scat_n);

	return table_pn_0(iCp , iCn , iMp);
      }
    else
      {
	const class array<unsigned long int> &table_pn_1 = tables_pn_1(n_scat_p , n_scat_n);

	return table_pn_1(iCp , iCn , iMp);
      }
  }

  unsigned long int & operator () (const int n_scat , const unsigned int iC) const
  {
    const class array<unsigned long int> &table_pp_nn = tables_pp_nn(n_scat);
      
    return table_pp_nn(iC);
  }

  friend double used_memory_calc (const class sum_GSM_vector_dimensions_class &T);

private:

  void calc_pp_nn (
		   const class nucleons_data &particle_data , 
		   const bool truncation_hw , 
		   const bool truncation_ph , 
		   const unsigned int BP , 
		   const int iM);

  void calc_pn_N_valence_larger (
				 const bool truncation_hw , 
				 const bool truncation_ph , 
				 const class nucleons_data &prot_data , 
				 const class nucleons_data &neut_data , 
				 const unsigned int BP , 
				 const int iM , 
				 const int iMp_min_M , 
				 const int iMp_max_M);
    
  void calc_pn_Z_valence_larger (
				 const bool truncation_hw , 
				 const bool truncation_ph , 
				 const class nucleons_data &prot_data , 
				 const class nucleons_data &neut_data , 
				 const unsigned int BP , 
				 const int iM , 
				 const int iMn_min_M , 
				 const int iMn_max_M);

  enum space_type space;
    
  int n_holes_max_p;
  int n_holes_max_n;
  
  int Ep_max_hw;
  int En_max_hw;
  
  int n_scat_max_p;
  int n_scat_max_n;
  
  int n_holes_max;
  
  int E_max_hw;
  
  int n_scat_max;

  class array<class array<unsigned long int> > tables_pp_nn;
  
  class array<class array<unsigned long int> > tables_pn_0;
  class array<class array<unsigned long int> > tables_pn_1;
};







  
class sum_GSM_vector_dimensions_one_configuration_class
{
public:
  sum_GSM_vector_dimensions_one_configuration_class ();

  sum_GSM_vector_dimensions_one_configuration_class (
						     const enum space_type space , 
						     const class nucleons_data &prot_data , 
						     const class nucleons_data &neut_data , 
						     const int iM , 
						     const int iMp_min_M , 
						     const int iMp_max_M);

  sum_GSM_vector_dimensions_one_configuration_class (const class sum_GSM_vector_dimensions_one_configuration_class &X);


  void allocate (
		 const enum space_type space , 
		 const class nucleons_data &prot_data , 
		 const class nucleons_data &neut_data , 
		 const int iM , 
		 const int iMp_min_M , 
		 const int iMp_max_M);

  void allocate_fill (const class sum_GSM_vector_dimensions_one_configuration_class &X);
  
  void deallocate ();
  
  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }
  
  unsigned int & operator () (const int iMp) const
  {  
    return table(iMp);
  }

  friend double used_memory_calc (const class sum_GSM_vector_dimensions_one_configuration_class &T);
     
private:

  void calc_pn (
		const class nucleons_data &prot_data , 
		const class nucleons_data &neut_data , 
		const int iM , 
		const int iMp_min_M , 
		const int iMp_max_M);

  class array<unsigned int> table;
};


#endif


