#ifndef GSMARRAYOFCONFIGURATION_H
#define GSMARRAYOFCONFIGURATION_H

// TYPE is double or complex
// -------------------------

class array_of_configuration
{
public:

  array_of_configuration ();
			  
  array_of_configuration (
			  const bool is_there_cout , 
			  const enum particle_type particle , 
			  const unsigned int dimension_configuration_total , 
			  const class array<unsigned int> &sum_dimensions_configuration_set , 
			  const unsigned int N_valence_nucleons);
  
  array_of_configuration (const class array_of_configuration &X);
  
  void allocate (
		 const bool is_there_cout , 
		 const enum particle_type particle , 
		 const unsigned int dimension_configuration_total , 
		 const class array<unsigned int> &sum_dimensions_configuration_set , 
		 const unsigned int N_valence_nucleons);

  void allocate_fill (const class array_of_configuration &X);
	       
  void deallocate ();

  bool is_it_filled () const;
  
  unsigned int index_determine (const unsigned int BP , const unsigned int n_scat , const unsigned int iC) const;

  class virtual_configuration operator () (const unsigned int BP , const unsigned int n_scat , const unsigned int iC) const;

  class virtual_configuration operator [] (const unsigned int index) const
  {
    return virtual_configuration (table , index);
  }
  
  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const;
  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const;
  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const;

#ifdef UseMPI
  void MPI_Allreduce_min (const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
#endif

  friend double used_memory_calc (const class array_of_configuration &T);
  
private:
  
  unsigned long int get_dimension_configuration_total () const
  {
    return table.dimension (0);
  }
  
  unsigned int get_N_valence_nucleons () const
  {
    return table.dimension (1);
  }
  
  const class array<unsigned int> & get_sum_dimensions_configuration_set () const
  {
    return *sum_dimensions_configuration_set_ptr;
  }

  const class array<unsigned int> *sum_dimensions_configuration_set_ptr;

  class array<unsigned short int> table;
};


#endif


