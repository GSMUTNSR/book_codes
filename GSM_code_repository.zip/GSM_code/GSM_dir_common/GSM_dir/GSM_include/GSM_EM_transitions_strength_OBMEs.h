#ifndef GSMEMTRANSITIONSSTRENGTHOBMES_H
#define GSMEMTRANSITIONSSTRENGTHOBMES_H

// TYPE is double or complex
// -------------------------

namespace EM_transitions_strength_OBMEs
{ 
  void radial_OBMEs_states_fixed_calc (
				       const enum radial_operator_type radial_operator ,
				       const TYPE &q , 
				       const int L , 
				       const bool is_it_longwavelength_approximation ,
				       const bool is_it_Gauss_Legendre , 
				       const class spherical_state &wf_in , 
				       const class spherical_state &wf_out , 
				       class array<TYPE> &radial_OBMEs_states_fixed);

  void radial_OBMEs_calc (
			  const enum radial_operator_type radial_operator ,
			  const TYPE &q , 
			  const int L , 
			  const bool is_it_longwavelength_approximation , 
			  const bool is_it_Gauss_Legendre , 	
			  const unsigned int BP_Op , 
			  const class baryons_data &data , 
			  class array<TYPE> &radial_OBMEs);
 
  namespace electric
  {
    void OBMEs_reduced_calc (
			     const TYPE &q , 
			     const int L ,
			     const bool is_it_longwavelength_approximation , 
			     const bool is_it_Gauss_Legendre , 
			     const class baryons_data &data , 
			     class array<TYPE> &electric_OBMEs);
  }

  namespace magnetic
  {
    void OBMEs_reduced_calc (
			     const TYPE &q , 
			     const int L ,
			     const bool is_it_longwavelength_approximation , 
			     const bool is_it_Gauss_Legendre , 
			     const class baryons_data &data , 
			     class array<TYPE> &magnetic_OBMEs);
  }

  void EM_suboperator_OBMEs_reduced_calc (
					  const enum EM_suboperator_type EM_suboperator , 
					  const TYPE &q , 
					  const int L ,
					  const bool is_it_longwavelength_approximation , 
					  const bool is_it_Gauss_Legendre , 
					  const class baryons_data &data , 
					  class array<TYPE> &OBMEs);
  void OBMEs_reduced_calc (
			   const enum EM_type EM , 
			   const TYPE &q , 
			   const int L ,
			   const bool is_it_longwavelength_approximation , 
			   const bool is_it_Gauss_Legendre , 
			   const class baryons_data &data , 
			   class array<TYPE> &OBMEs);
  
  void OBMEs_calc (
		   const enum EM_type EM , 
		   const TYPE &q , 
		   const int L ,
		   const int ML ,
		   const bool is_it_longwavelength_approximation , 
		   const bool is_it_Gauss_Legendre , 
		   const class baryons_data &data , 
		   class array<TYPE> &OBMEs);
  

  void EM_suboperator_OBMEs_calc (
				  const enum EM_suboperator_type EM_suboperator , 
				  const TYPE &q , 
				  const int L ,
				  const int ML ,
				  const bool is_it_longwavelength_approximation , 
				  const bool is_it_Gauss_Legendre , 
				  const class baryons_data &data , 
				  class array<TYPE> &OBMEs);
}

#endif


