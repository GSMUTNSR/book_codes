#ifndef GSMTBMESDI_H
#define GSMTBMESDI_H

// TYPE is double or complex
// -------------------------

namespace TBME_SDI_set
{
  TYPE SDI_radial_TBME (
			const double R0 , 
			const class spherical_state &wf0 , 
			const class spherical_state &wf1 , 
			const class spherical_state &wf2 , 
			const class spherical_state &wf3);

  double TBME_JT_angular_antisymmetrized (
					  const int J , 
					  const int T , 
					  const class interaction_class &inter_data , 
					  const class spherical_state &wf0 , 
					  const class spherical_state &wf1 , 
					  const class spherical_state &wf2 , 
					  const class spherical_state &wf3);

  TYPE TBME_pi_pj_J (
		     const int J , 
		     const class array<TYPE> &reduced_grad_02_tab , 
		     const class array<TYPE> &reduced_grad_13_tab , 
		     const unsigned int s0 , 
		     const unsigned int s1 , 
		     const unsigned int s2 , 
		     const unsigned int s3 , 
		     const class spherical_state &wf0 , 
		     const class spherical_state &wf1 , 
		     const class spherical_state &wf2 , 
		     const class spherical_state &wf3);
 
  TYPE TBME_J_pp_nn_antisymmetrized (
				     const bool is_there_recoil , 
				     const int J , 
				     const class interaction_class &inter_data , 
				     const unsigned int s0 , 
				     const unsigned int s1 , 
				     const unsigned int s2 , 
				     const unsigned int s3 , 
				     const class array<TYPE> &reduced_grad_tab , 
				     const class array<class spherical_state> &shells);

  TYPE TBME_J_pn (
		  const bool is_there_recoil , 
		  const int J , 
		  const class interaction_class &inter_data , 
		  const unsigned int s0 , 
		  const unsigned int s1 , 
		  const unsigned int s2 , 
		  const unsigned int s3 , 
		  const class array<TYPE> &reduced_grad_prot_tab , 
		  const class array<TYPE> &reduced_grad_neut_tab , 
		  const class array<class spherical_state> &shells_prot , 
		  const class array<class spherical_state> &shells_neut);
}

#endif


