#ifndef GSMHFPOTENTIALS_H
#define GSMHFPOTENTIALS_H

// TYPE is double or complex
// -------------------------

namespace HF_potentials
{
  void potentials_shells_iteration_calc (
					 const bool is_there_cout , 
					 const class interaction_class &inter_data_basis , 
					 const class baryons_data &prot_data , 
					 const class baryons_data &neut_data , 
					 const unsigned int iter , 
					 const bool HO_diag ,
					 const double test ,
					 const class CG_str &CGs , 
					 const class array<double> &Gaussian_table_GL , 
					 const class multipolar_expansion_str &multipolar_expansion , 
					 const class array<double> &V_Coul_tab_big , 
					 class HF_nucleons_data &prot_HF_data , 
					 class HF_nucleons_data &neut_HF_data);

  void iterative_potentials_shells_OBMEs_calc (
					       const bool is_there_cout , 
					       const class input_data_str &input_data , 
					       const class interaction_class &inter_data_basis , 
					       class HF_nucleons_data &prot_HF_data , 
					       class HF_nucleons_data &neut_HF_data , 
					       class baryons_data &prot_data , 
					       class baryons_data &neut_data);

  void iterative_potentials_shells_OBMEs_calc_HO_removal (
							  const bool is_there_cout ,
							  const class input_data_str &input_data , 
							  const class interaction_class &inter_data_basis , 
							  class HF_nucleons_data &prot_HF_data , 
							  class HF_nucleons_data &neut_HF_data , 
							  class baryons_data &prot_data , 
							  class baryons_data &neut_data);
  
  void potentials_shells_OBMEs_realloc_calc (
					     const bool is_there_cout , 
					     const class input_data_str &input_data , 
					     const class interaction_class &inter_data_basis , 
					     class HF_nucleons_data &prot_HF_data , 
					     class HF_nucleons_data &neut_HF_data , 
					     class baryons_data &prot_data , 
					     class baryons_data &neut_data);		
}

#endif


