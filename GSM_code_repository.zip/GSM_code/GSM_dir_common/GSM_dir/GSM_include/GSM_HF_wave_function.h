#ifndef GSMHFWAVEFUNCTION_H
#define GSMHFWAVEFUNCTION_H

// TYPE is double or complex
// -------------------------

namespace HF_wave_function
{
  complex<double> OBME_nuclear_potential_HO_core_state_calc (
							     const class HF_nucleons_data &HF_data , 
							     const potential_type nuclear_potential , 
							     const class spherical_state &shell_HO_core);

  double OBME_H_Coulomb_potential_HO_core_state_calc (
						      const int Z_core , 
						      const class HF_nucleons_data &HF_data , 
						      const class spherical_state &shell_HO_core);

  complex<double> E_HO_core_state_calc (
					const int Z_core , 
					const class HF_nucleons_data &HF_data , 
					const class spherical_state &shell_HO_core);

  void OCM_core_states_realloc_calc (
				     const bool is_there_cout , 
				     const bool is_it_res , 
				     const bool is_it_OCM_HO_core , 
				     const int Z_core , 
				     const class interaction_class &inter_data , 
				     class HF_nucleons_data &HF_data);

  void OCM_orthogonalization (
			      const class array<class nlj_struct> &shells_qn , 
			      const class array<class spherical_state> &shells , 
			      const complex<double> &w , 
			      class spherical_state &shell);

  double Re_k2_for_energy_sort (const class nlj_struct &shell_qn);

  void energy_sort (
		    const int low , 
		    const int high , 
		    class array<class spherical_state> &shells , 
		    class array<class nlj_struct> &shells_qn);

  void e_trunc_modify (
		       const unsigned int N_valence_nucleons_basis , 
		       class array<class nlj_struct> &shells_qn);

  void occupied_pairs_determine (
				 const enum space_type basis_space , 
				 const class HF_nucleons_data &other_HF_data , 
				 class HF_nucleons_data &HF_data);

  void occupied_poles_configurations_to_diagonalize_determine (class HF_nucleons_data &HF_data);

  void shells_occupied_number_calc (class HF_nucleons_data &HF_data);

  void state_rejection_test (
			     const class array<class nlj_struct> &shells_qn , 
			     const unsigned int s_ref , 
			     class array<spherical_state> &shells);

  void all_shells_orthogonalize (const bool is_it_res , class HF_nucleons_data &HF_data);

  void all_shells_pm_orthogonalize (
				    const int pm , 
				    class HF_nucleons_data &HF_data);

  void all_shells_alloc_calc_inter_init (
					 const bool is_there_cout , 
					 const bool is_it_res , 
					 const class interaction_class &inter_data , 
					 class HF_nucleons_data &HF_data);

  void all_shells_alloc_calc_from_php_matrices_diagonalization (
								const bool is_there_cout ,
								const class interaction_class &inter_data , 
								const class baryons_data &particles_data ,
								class HF_nucleons_data &HF_data);
 
  void trivially_equivalent_potential_splines_realloc_calc (
							    const bool is_it_real , 
							    const double R , 
							    const int Z_charge_basis_potential , 
							    const enum particle_type particle , 
							    const class nlj_table<complex<double> > &Veq_finite_range_averaged_tab , 
							    const class nlj_table<complex<double> > &source_averaged_tab , 
							    const class array<double> &V_Coul_tab_big , 
							    const int n , 
							    const int l , 
							    const double j , 
							    class potentials_effective_mass &T);

  void shell_calc (
		   const bool is_there_cout , 
		   const bool is_it_res , 
		   const bool HO_diag , 
		   const double b_lab , 
		   const class array<double> &V_Coul_tab_big , 
		   const unsigned int shell_index , 
		   class HF_nucleons_data &HF_data , 
		   class potentials_effective_mass &T , 
		   class array<class nlj_struct> &shells_qn , 
		   class array<class spherical_state> &shells);

  void all_shells_alloc_calc (
			      const class interaction_class &inter_data , 
			      const bool is_there_cout , 
			      const bool is_it_res , 
			      const bool HO_diag , 
			      const double test , 
			      const class array<double> &V_Coul_tab_big , 
			      class HF_nucleons_data &HF_data);

  void all_shells_pm_alloc_calc (
				 const int pm , const class interaction_class &inter_data , 
				 const class array<double> &V_Coul_tab_big , 
				 class HF_nucleons_data &HF_data);

  void res_waves_deallocate (class HF_nucleons_data &HF_data);

  void waves_deallocate (class HF_nucleons_data &HF_data);

  void wave_functions_calc (
			    const bool is_there_cout , 
			    const class interaction_class &inter_data , 
			    const class baryons_data &prot_data , 
			    const class baryons_data &neut_data , 
			    const unsigned int iteration , 
			    const bool HO_diag ,
			    const double test ,
			    const class array<double> &V_Coul_tab_big , 
			    class HF_nucleons_data &prot_HF_data , 
			    class HF_nucleons_data &neut_HF_data);
 
  double test_HF_MSDHF_k_update_part_calc (class HF_nucleons_data &HF_data);

  double test_OCM_part_calc (const class HF_nucleons_data &HF_data);

  double test_HF_MSDHF_k_update_calc (
				      class HF_nucleons_data &prot_HF_data , 
				      class HF_nucleons_data &neut_HF_data);

  double test_OCM_calc (
			const class HF_nucleons_data &prot_HF_data , 
			const class HF_nucleons_data &neut_HF_data);

  double test_calc_k_update (
			     const bool is_there_cout , 
			     const bool print_detailed_information ,
			     const bool is_it_HO ,
			     const unsigned int iteration ,
			     class HF_nucleons_data &prot_HF_data , 
			     class HF_nucleons_data &neut_HF_data);

#ifdef UseMPI
  void shells_MPI_transfer (class HF_nucleons_data &HF_data , const MPI_Comm MPI_C);
#endif
}

#endif


