#ifndef GSMSDONEJUMPINTOOUTSTR_H
#define GSMSDONEJUMPINTOOUTSTR_H

// TYPE is double or complex
// -------------------------

class SD_one_jump_data_in_to_out_str
{ 
public:
  SD_one_jump_data_in_to_out_str ();

  SD_one_jump_data_in_to_out_str (
				  const unsigned int C_eq_one_jump_index_c , 
				  const unsigned int Delta_iM_out_c , 
				  const unsigned int outSD_index_c , 
				  const unsigned int im_out_c , 
				  const unsigned int bin_phase_c);

  void initialize (
		   const unsigned int C_eq_one_jump_index_c , 
		   const unsigned int Delta_iM_out_c , 
		   const unsigned int outSD_index_c , 
		   const unsigned int im_out_c , 
		   const unsigned int bin_phase_c);
  
  void initialize (const class SD_one_jump_data_in_to_out_str &X);
  
  void allocate_fill (const class SD_one_jump_data_in_to_out_str &X);
		   
  unsigned int get_C_eq_one_jump_index () const
  {
    return C_eq_one_jump_index;
  }
  
  unsigned int get_Delta_iM_out () const
  {
    return Delta_iM_out;
  }

  unsigned int get_outSD_index () const
  {
    return outSD_index;
  }

  unsigned int get_im_out () const
  {
    return im_out;
  }

  unsigned int get_bin_phase () const
  {
    return bin_phase;
  }


private:
  
  unsigned int C_eq_one_jump_index; // equivalent configuration index for this jump (see GSM_configuration_one_jump_construction_set_in_to_out.cpp for the definition of the equivalent configuration for jumps)
  
  unsigned short int Delta_iM_out; // shifted difference of M quantum numbers M_out - M_in + 2 m_max
  
  unsigned int outSD_index; // index of outSD for a fixed configuration
  
  unsigned char im_out; // shifted m quantum number m[out] + m[max] of the alpha state
  
  unsigned char bin_phase; // binary phase arising from a+_{alpha} a_{beta}
};


double used_memory_calc (const class SD_one_jump_data_in_to_out_str &T);


#endif
