#ifndef GSMLESPESHAMILTONIAN_H
#define GSMLESPESHAMILTONIAN_H

// TYPE is double or complex
// -------------------------

namespace ESPEs_Hamiltonian
{
  void OBMEs_TBMEs_pp_part_p_calc ( 
				   const class input_data_str &input_data ,
				   class baryons_data &prot_Y_data);
  
  void TBMEs_pn_part_p_calc (
			     const class input_data_str &input_data ,
			     const class TBMEs_class &TBMEs_pn ,  
			     const class baryons_data &neut_Y_data , 
			     class baryons_data &prot_Y_data);
  
  void OBMEs_TBMEs_nn_part_n_calc ( 
				   const class input_data_str &input_data ,
				   class baryons_data &neut_Y_data);
  
  void TBMEs_pn_part_n_calc (
			     const class input_data_str &input_data ,
			     const class TBMEs_class &TBMEs_pn ,  
			     const class baryons_data &prot_Y_data , 
			     class baryons_data &neut_Y_data);
  
  void pn_alloc_calc (
		      const class input_data_str &input_data ,
		      const class TBMEs_class &TBMEs_pn ,  
		      class baryons_data &prot_Y_data , 
		      class baryons_data &neut_Y_data);
}

#endif
