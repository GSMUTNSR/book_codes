#ifndef GSMLESPESHAMILTONIAN_H
#define GSMLESPESHAMILTONIAN_H

// TYPE is double or complex
// -------------------------

namespace ESPEs_Hamiltonian
{
  void OBMEs_TBMEs_pp_part_prot_calc ( 
				      const class input_data_str &input_data ,
				      class nucleons_data &prot_data);
  
  void TBMEs_pn_part_prot_calc (
				const class input_data_str &input_data ,
				const class TBMEs_class &TBMEs_pn ,  
				const class nucleons_data &neut_data , 
				class nucleons_data &prot_data);
  
  void OBMEs_TBMEs_nn_part_neut_calc ( 
				      const class input_data_str &input_data ,
				      class nucleons_data &neut_data);
  
  void TBMEs_pn_part_neut_calc (
				const class input_data_str &input_data ,
				const class TBMEs_class &TBMEs_pn ,  
				const class nucleons_data &prot_data , 
				class nucleons_data &neut_data);
  
  void prot_neut_alloc_calc (
			     const class input_data_str &input_data ,
			     const class TBMEs_class &TBMEs_pn ,  
			     class nucleons_data &prot_data , 
			     class nucleons_data &neut_data);
}

#endif
