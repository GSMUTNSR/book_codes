#ifndef GSMRMSRADIUSONEBODYSTRENGTHOBMES_H
#define GSMRMSRADIUSONEBODYSTRENGTHOBMES_H

// TYPE is double or complex
// -------------------------

namespace rms_radius_one_body_strength_OBMEs
{
  void OBMEs_shells_calc (
			  const double factor , 
			  const bool is_it_Gauss_Legendre ,
			  const class nucleons_data &data , 
			  class array<TYPE> &OBMEs);

  void OBMEs_calc (
		   const double factor , 
		   const bool is_it_Gauss_Legendre ,
		   const class nucleons_data &data , 
		   class array<TYPE> &OBMEs);
}

#endif


