#ifndef GSMHOLEDOUBLECOUNTINGOBMES_H
#define GSMHOLEDOUBLECOUNTINGOBMES_H

// TYPE is double or complex
// -------------------------

namespace hole_double_counting
{
  TYPE prot_OBME_calc (
		       const bool is_it_gradient , 
		       const enum space_type space , 
		       const int n_scat_max , 
		       const class TBMEs_class &TBMEs_pn , 
		       const class nucleons_data &prot_data , 
		       const class nucleons_data &neut_data , 
		       const unsigned int sp_in ,
		       const unsigned int sp_out);

  TYPE neut_OBME_calc (
		       const bool is_it_gradient , 
		       const enum space_type space , 
		       const int n_scat_max , 
		       const class TBMEs_class &TBMEs_pn , 
		       const class nucleons_data &prot_data , 
		       const class nucleons_data &neut_data , 
		       const unsigned int sn_in ,
		       const unsigned int sn_out);

  void neut_OBMEs_no_natural_orbitals_calc_store (
						  const bool is_hole_double_counting_suppressed ,
						  const bool is_it_gradient , 
						  const enum space_type space , 
						  const int n_scat_max , 
						  const class TBMEs_class &TBMEs_pn , 
						  const class nucleons_data &prot_data , 
						  class nucleons_data &neut_data);
  
  void prot_OBMEs_no_natural_orbitals_calc_store (
						  const bool is_hole_double_counting_suppressed ,
						  const bool is_it_gradient , 
						  const enum space_type space , 
						  const int n_scat_max , 
						  const class TBMEs_class &TBMEs_pn , 
						  const class nucleons_data &neut_data , 
						  class nucleons_data &prot_data);
  
  void prot_OBMEs_calc_store (
			      const bool is_hole_double_counting_suppressed ,
			      const bool is_it_gradient , 
			      const enum space_type space , 
			      const int n_scat_max , 
			      const class TBMEs_class &TBMEs_pn , 
			      const class nucleons_data &neut_data , 
			      class nucleons_data &prot_data);
  
  void neut_OBMEs_calc_store (
			      const bool is_hole_double_counting_suppressed ,
			      const bool is_it_gradient , 
			      const enum space_type space , 
			      const int n_scat_max , 
			      const class TBMEs_class &TBMEs_pn , 
			      const class nucleons_data &prot_data , 
			      class nucleons_data &neut_data);
  
  void prot_neut_OBMEs_no_natural_orbitals_calc_store (
						       const bool is_it_gradient , 
						       const class input_data_str &input_data , 
						       class nucleons_data &prot_data , 
						       class nucleons_data &neut_data , 
						       class TBMEs_class &TBMEs_pn);

  void prot_neut_OBMEs_calc_store (
				   const bool is_it_gradient , 
				   const class input_data_str &input_data , 
				   class nucleons_data &prot_data , 
				   class nucleons_data &neut_data , 
				   class TBMEs_class &TBMEs_pn);
 
  void prot_neut_OBMEs_no_natural_orbitals_calc_store_remove (
							      const bool is_it_gradient , 
							      const class input_data_str &input_data , 
							      class nucleons_data &prot_data , 
							      class nucleons_data &neut_data , 
							      class TBMEs_class &TBMEs_pn);
  
  void prot_neut_OBMEs_calc_store_remove (
					  const bool is_it_gradient , 
					  const class input_data_str &input_data , 
					  class nucleons_data &prot_data , 
					  class nucleons_data &neut_data , 
					  class TBMEs_class &TBMEs_pn);
}

#endif


