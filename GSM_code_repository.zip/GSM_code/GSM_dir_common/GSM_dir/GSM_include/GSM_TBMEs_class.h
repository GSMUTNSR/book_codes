#ifndef GSMTBMESCLASS_H
#define GSMTBMESCLASS_H

// TYPE is double or complex
// -------------------------

class TBMEs_class
{
public:
  
  TBMEs_class ();

  TBMEs_class (
	       const bool is_there_cout , 
	       const bool is_it_only_basis , 
	       const class input_data_str &input_data , 
	       const class nucleons_data &data);

  TBMEs_class (
	       const bool is_there_cout , 
	       const bool is_it_only_basis , 
	       const class input_data_str &input_data , 
	       const class nucleons_data &prot_data , 
	       const class nucleons_data &neut_data);

  TBMEs_class (
	       const bool is_there_cout , 
	       const enum space_type TBME_space_c , 
	       const class input_data_str &input_data , 
	       const class array<class nlj_struct> &shells_table);

  TBMEs_class (
	       const bool is_there_cout , 
	       const bool is_it_only_basis , 
	       const class input_data_str &input_data , 
	       const class array<class nlj_struct> &shells_table_prot , 
	       const class array<class nlj_struct> &shells_table_neut);

  TBMEs_class (
	       const bool is_there_cout , 
	       const class input_data_str &input_data , 
	       const class nucleons_data &data , 
	       const enum interaction_type TBME_inter , 
	       const class array<class nlj_struct> &shells_HO_table);

  TBMEs_class (
	       const bool is_there_cout , 
	       const bool is_it_only_basis , 
	       const class input_data_str &input_data , 
	       const class nucleons_data &prot_data , 
	       const class nucleons_data &neut_data , 
	       const enum interaction_type TBME_inter , 
	       const class array<class nlj_struct> &shells_HO_table);

  TBMEs_class (const class TBMEs_class &X); 

  void allocate (
		 const bool is_there_cout , 
		 const bool is_it_only_basis , 
		 const class input_data_str &input_data , 
		 const class nucleons_data &data);

  void allocate (
		 const bool is_there_cout , 
		 const bool is_it_only_basis , 
		 const class input_data_str &input_data , 
		 const class nucleons_data &prot_data , 
		 const class nucleons_data &neut_data);

  void allocate (
		 const bool is_there_cout , 
		 const enum space_type TBME_space_c , 
		 const class input_data_str &input_data , 
		 const class array<class nlj_struct> &shells_table);

  void allocate (
		 const bool is_there_cout , 
		 const bool is_it_only_basis , 
		 const class input_data_str &input_data , 
		 const class array<class nlj_struct> &shells_table_prot , 
		 const class array<class nlj_struct> &shells_table_neut);

  void allocate (
		 const bool is_there_cout , 
		 const class input_data_str &input_data , 
		 const class nucleons_data &data , 
		 const enum interaction_type TBME_inter , 
		 const class array<class nlj_struct> &shells_HO_table);

  void allocate (
		 const bool is_there_cout , 
		 const bool is_it_only_basis , 
		 const class input_data_str &input_data , 
		 const class nucleons_data &prot_data , 
		 const class nucleons_data &neut_data , 
		 const enum interaction_type TBME_inter , 
		 const class array<class nlj_struct> &shells_HO_table);

  void allocate_fill (const class TBMEs_class &X); 

  void deallocate (); 

  enum space_type get_TBME_space () const
  {
    return TBME_space;
  }
  
  unsigned int get_BPmin_global () const
  {
    return BPmin_global;
  }

  unsigned int get_BPmax_global () const
  {
    return BPmax_global;
  }

  int get_Jmin_global () const
  {
    return Jmin_global;
  }

  int get_Jmax_global () const
  {
    return Jmax_global;
  }

  bool get_is_it_mixed () const
  {
    return is_it_mixed;
  }

  void zero ();

  void corrective_factor_multiplication (const TYPE &corrective_factor);

  unsigned int index_determine (
				const int J , 
				const unsigned int left_in , 
				const unsigned int right_in , 
				const unsigned int left_out , 
				const unsigned int right_out) const;

  TYPE & operator () (
		      const int J , 
		      const unsigned int left_in , 
		      const unsigned int right_in , 
		      const unsigned int left_out , 
		      const unsigned int right_out) const;
  
  TYPE M_TBME (
	       const unsigned int left_in , 
	       const unsigned int right_in , 
	       const unsigned int left_out , 
	       const unsigned int right_out) const;

  void copy_TBMEs_to_file (
			   const bool is_there_cout , 
			   const int n_scat_max , 
			   const enum interaction_type TBME_inter , 
			   const class nucleons_data &particles_data_left , 
			   const class nucleons_data &particles_data_right) const;

  void read_TBMEs_from_file (
			     const bool is_there_cout , 
			     const int n_scat_max ,
			     const class nucleons_data &particles_data_left , 
			     const class nucleons_data &particles_data_right , 
			     const enum interaction_type TBME_inter);

  void copy_disk (const string &file_name) const;
  
  void read_disk (const string &file_name);
  
  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const;
  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const;

#ifdef UseMPI
  void MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm C);
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm C);
#endif

  bool is_it_filled () const
  {
    return (TBME_space != NO_SPACE);
  }

  friend double used_memory_calc (const class TBMEs_class &T);
  
private:  

  unsigned int coupled_TBME_mixed_index_determine (
						   const int J , 
						   const unsigned int left_HO_in , 
						   const unsigned int right_HO_in , 
						   const unsigned int left_out , 
						   const unsigned int right_out) const;

  unsigned int coupled_TBME_index_determine (
					     const int J , 
					     const unsigned int left_in , 
					     const unsigned int right_in , 
					     const unsigned int left_out , 
					     const unsigned int right_out) const;

  enum space_type TBME_space; // PROTONS_ONLY or NEUTRONS_ONLY if one has only pp or nn TBMEs, PROTONS_NEUTRONS if one has pn TBMEs



  
  // minimal and maximal binary parities (see observables_basic_functions.cpp for definition) and total angular momenta for all two-body states

  unsigned int BPmin_global;
  unsigned int BPmax_global;
  
  int Jmin_global;
  int Jmax_global;


  
  bool is_it_mixed; // true if one uses mixed two-body matrix elements of the form <gamma delta | V | alpha_inter beta_inter>_J, where alpha_inter, beta_inter are HO or GHF states and gamma, delta are Berggren basis states
    
  class array<double> CG_antisymmetry_table; // Clebsch-Gordan coefficients <ja ma jb mb | J M> multiplied by sqrt (1 + delta_ab) to calculate uncoupled TBMEs from coupled TBMEs.


  
  // arrays of minimal and maximal total angular momenta for all two-body states. They are used in the Clebsch-Gordan coefficient formula to calculate uncoupled TBMEs from coupled TBMEs.
  
  class array<int> Jmin_table;
  class array<int> Jmax_table;


  
  // arrays providing with the one-dimensional indices of proton and neutron shells function of one-dimensional state indices
  
  class array<unsigned int> shells_indices_prot;
  class array<unsigned int> shells_indices_neut;


  
  class array<unsigned int> dimensions_coupled; // array of numbers of Berggren two-body states of fixed parity and J function of (bp,J)


  
  // sums of dimensions of arrays of numbers of TBMEs of binary parity equal to 0,1 and J function of J to calculate one-dimensional indices of TBMEs arrays
    
  class array<unsigned int> sum_dimensions_coupled_bp_0_tab;
  class array<unsigned int> sum_dimensions_coupled_bp_1_tab;


  
  class array<unsigned int> bp_table; // array of binary parities (see observables_basic_functions.cpp for definition). It is used for the calculation of one-dimensional indices of TBMEs arrays

  class array<unsigned int> pairs_indices; // indices of Berggren basis pairs of two-body states of fixed parity and J functions of (bp,J)

  class array<unsigned int> pairs_HO_indices;// indices of HO pairs of two-body states of fixed parity and J functions of (bp,J)
  
  class array<TYPE> table; // arrays of J-coupled TBMEs 
};

void corrective_factor_TBMEs_modification (
					   const enum space_type space , 
					   const TYPE &corrective_factor , 
					   class nucleons_data &prot_data , 
					   class nucleons_data &neut_data , 
					   class TBMEs_class &TBMEs_pn);

#endif


