#ifndef GSMTBMESCLASS_H
#define GSMTBMESCLASS_H

// TYPE is double or complex
// -------------------------

class TBMEs_class
{
public:
  
  TBMEs_class ();

  TBMEs_class (
	       const bool is_there_cout , 
	       const bool is_it_only_basis , 
	       const class input_data_str &input_data , 
	       const class baryons_data &data);

  TBMEs_class (
	       const bool is_there_cout , 
	       const bool is_it_only_basis , 
	       const class input_data_str &input_data , 
	       const class baryons_data &prot_Y_data , 
	       const class baryons_data &neut_Y_data);
  
  TBMEs_class (
	       const bool is_there_cout , 
	       const class input_data_str &input_data , 
	       const class baryons_data &prot_Y_data , 
	       const class baryons_data &neut_Y_data);

  TBMEs_class (
	       const bool is_there_cout , 
	       const enum space_type TBME_space_c , 
	       const class input_data_str &input_data , 
	       const class array<class nlj_struct> &shells_qn,
	       const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_tab);

  TBMEs_class (
	       const bool is_there_cout , 
	       const bool is_it_only_basis , 
	       const class input_data_str &input_data , 
	       const class array<class nlj_struct> &shells_qn_p , 
	       const class array<class nlj_struct> &shells_qn_n ,
	       const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_p_tab ,
	       const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_n_tab);

  TBMEs_class (
	        const bool is_there_cout ,
		const bool is_it_cv ,
		const class input_data_str &input_data , 
		const class baryons_data &data , 
		const enum interaction_type TBME_inter , 
		const class array<class nlj_struct> &shells_inter_qn ,
		const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_tab);
  
  TBMEs_class (
	       const bool is_there_cout , 
	       const bool is_it_only_basis , 
	       const class input_data_str &input_data , 
	       const class baryons_data &prot_Y_data , 
	       const class baryons_data &neut_Y_data , 
	       const enum interaction_type TBME_inter , 
	       const class array<class nlj_struct> &shells_inter_qn_p ,
	       const class array<class nlj_struct> &shells_inter_qn_n ,
	       const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_p_tab ,
	       const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_n_tab);

  TBMEs_class (const class TBMEs_class &X); 

  void allocate (
		 const bool is_there_cout , 
		 const bool is_it_only_basis , 
		 const class input_data_str &input_data , 
		 const class baryons_data &data);

  void allocate (
		 const bool is_there_cout , 
		 const bool is_it_only_basis , 
		 const class input_data_str &input_data , 
		 const class baryons_data &prot_Y_data , 
		 const class baryons_data &neut_Y_data);
  
  void allocate (
		 const bool is_there_cout , 
		 const class input_data_str &input_data , 
		 const class baryons_data &prot_Y_data , 
		 const class baryons_data &neut_Y_data);

  void allocate (
		 const bool is_there_cout , 
		 const enum space_type TBME_space_c , 
		 const class input_data_str &input_data , 
		 const class array<class nlj_struct> &shells_qn ,
		 const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_tab);

  void allocate (
		 const bool is_there_cout , 
		 const bool is_it_only_basis , 
		 const class input_data_str &input_data , 
		 const class array<class nlj_struct> &shells_qn_p , 
		 const class array<class nlj_struct> &shells_qn_n ,
		 const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_p_tab ,
		 const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_n_tab);

  void allocate (
		 const bool is_there_cout , 
		 const class input_data_str &input_data , 
		 const class array<class nlj_struct> &shells_qn_p , 
		 const class array<class nlj_struct> &shells_qn_n ,
		 const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_p_tab ,
		 const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_n_tab);
  
  void allocate (
		 const bool is_there_cout ,
		 const bool is_it_cv ,
		 const class input_data_str &input_data , 
		 const class baryons_data &data , 
		 const enum interaction_type TBME_inter , 
		 const class array<class nlj_struct> &shells_inter_qn ,
		 const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_tab);
  
  void allocate (
		 const bool is_there_cout , 
		 const bool is_it_only_basis , 
		 const class input_data_str &input_data , 
		 const class baryons_data &prot_Y_data , 
		 const class baryons_data &neut_Y_data , 
		 const enum interaction_type TBME_inter , 
		 const class array<class nlj_struct> &shells_inter_qn_p ,
		 const class array<class nlj_struct> &shells_inter_qn_n ,
		 const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_p_tab ,
		 const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_n_tab);
  
  void allocate_fill (const class TBMEs_class &X); 

  void deallocate (); 

  enum space_type get_TBME_space () const
  {
    return TBME_space;
  }
  
  unsigned int get_BPmin_global () const
  {
    return BPmin_global;
  }

  unsigned int get_BPmax_global () const
  {
    return BPmax_global;
  }

  int get_strangeness_min_global () const
  {
    return strangeness_min_global;
  }

  int get_strangeness_max_global () const
  {
    return strangeness_max_global;
  }

  unsigned int get_i_charge_min_global () const
  {
    return i_charge_min_global;
  }

  unsigned int get_i_charge_max_global () const
  {
    return i_charge_max_global;
  }
  
  int get_Jmin_global () const
  {
    return Jmin_global;
  }

  int get_Jmax_global () const
  {
    return Jmax_global;
  }

  bool get_is_it_mixed () const
  {
    return is_it_mixed;
  }

  void zero ();

  void corrective_factor_multiplication (const TYPE &corrective_factor);

  unsigned int index_determine (
				const int J , 
				const unsigned int left_in , 
				const unsigned int right_in , 
				const unsigned int left_out , 
				const unsigned int right_out) const;

  TYPE & operator () (
		      const int J , 
		      const unsigned int left_in , 
		      const unsigned int right_in , 
		      const unsigned int left_out , 
		      const unsigned int right_out) const;
  
  TYPE & operator [] (const unsigned int index) const;
  
  TYPE M_TBME (
	       const bool is_it_cv_pp_to_nn ,
	       const unsigned int left_in , 
	       const unsigned int right_in , 
	       const unsigned int left_out , 
	       const unsigned int right_out) const;

  void copy_TBMEs_to_file (
			   const bool is_there_cout , 
			   const int n_scat_max , 
			   const enum interaction_type TBME_inter , 
			   const class baryons_data &particles_data_left , 
			   const class baryons_data &particles_data_right) const;

  void read_TBMEs_from_file (
			     const bool is_there_cout , 
			     const int n_scat_max ,
			     const enum interaction_type TBME_inter ,
			     const class baryons_data &particles_data_left , 
			     const class baryons_data &particles_data_right); 

  void copy_disk (const string &file_name) const;
  
  void read_disk (const string &file_name);
  
  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const;
  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const;

#ifdef UseMPI
  
  void MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm C);

  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm C);
  
#endif

  bool is_it_filled () const
  {
    return (TBME_space != NO_SPACE);
  }

  friend double used_memory_calc (const class TBMEs_class &T);
  
  private:  
  
  unsigned int Nmu_shells_from_shells_indices_from_nlj_indices_tab_calc (const class array<class array<unsigned int> > &shells_indices_from_nlj_indices_mu_tab) const;
  
  void BP_J_i_charge_strangeness_min_max_from_shells_quantum_numbers_shells_indices_from_nlj_indices_calc (
													       const bool is_left_charged , 
													       const bool is_right_charged , 
													       const double jmax_left , 
													       const double jmax_right , 
													       const class array<class nlj_struct> &shells_qn_left ,
													       const class array<class nlj_struct> &shells_qn_right ,
													       const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_left_tab ,
													       const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_right_tab ,
													       unsigned int &BPmin_global_left_right ,
													       unsigned int &BPmax_global_left_right ,
													       int &Jmin_global_left_right ,
													       int &Jmax_global_left_right ,
													       int &strangeness_min_global_left_right ,
													       int &strangeness_max_global_left_right ,
													       unsigned int &i_charge_min_global_left_right ,
													       unsigned int &i_charge_max_global_left_right) const;
  
  void bp_i_charge_strangeness_tables_from_shells_quantum_numbers_alloc_calc (
									      const class array<class nlj_struct> &shells_qn_left ,
									      const class array<class nlj_struct> &shells_qn_right);
  
  void dimensions_coupled_pairs_indices_from_shells_quantum_numbers_alloc_calc (
										const int n_scat_max , 
										const bool is_left_charged , 
										const bool is_right_charged , 
										const class array<class nlj_struct> &shells_qn_left ,
										const class array<class nlj_struct> &shells_qn_right ,
										class array<unsigned int> &dimensions_coupled ,
										class array<unsigned int> &pairs_indices);

  void bp_i_charge_strangeness_tables_from_shells_quantum_numbers_shells_indices_from_nlj_indices_tab_alloc_calc (
														  const bool is_left_charged , 
														  const bool is_right_charged , 
														  const class array<class nlj_struct> &shells_qn_left ,
														  const class array<class nlj_struct> &shells_qn_right ,
														  const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_left_tab ,
														  const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_right_tab);
  
  void dimensions_coupled_pairs_indices_from_shells_quantum_numbers_shells_indices_from_nlj_indices_tab_alloc_calc (
														    const int n_scat_max , 
														    const bool is_left_charged , 
														    const bool is_right_charged , 
														    const class array<class nlj_struct> &shells_qn_left ,
														    const class array<class nlj_struct> &shells_qn_right ,
														    const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_left_tab ,
														    const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_right_tab ,
														    class array<unsigned int> &dimensions_coupled ,
														    class array<unsigned int> &pairs_indices);
  
  void dimensions_sum_dimensions_table_symmetric_space_alloc_calc_init ();
  
  void dimensions_sum_dimensions_table_asymmetric_space_alloc_calc_init (const class array<unsigned int> &dimensions_coupled_in);
  
  unsigned int coupled_TBME_mixed_index_determine (
						   const int J , 
						   const unsigned int left_in , 
						   const unsigned int right_in , 
						   const unsigned int left_out , 
						   const unsigned int right_out) const;

  unsigned int coupled_TBME_index_determine (
					     const int J , 
					     const unsigned int left_in , 
					     const unsigned int right_in , 
					     const unsigned int left_out , 
					     const unsigned int right_out) const;

  enum space_type TBME_space; // PROT_Y_ONLY or NEUT_Y_ONLY if one has only pp or nn TBMEs, PROT_NEUT_Y if one has pn TBMEs



  
  // minimal and maximal binary parities, total angular momenta, strangeness and charge indices (see observables_basic_functions.cpp for definition) for all two-body states

  unsigned int BPmin_global;
  unsigned int BPmax_global;
    
  int Jmin_global;
  int Jmax_global;
  
  int strangeness_min_global;
  int strangeness_max_global;
  
  unsigned int i_charge_min_global;
  unsigned int i_charge_max_global;


  
  bool is_it_mixed; // true if one uses mixed two-body matrix elements of the form <gamma delta | V | alpha_inter beta_inter>_J, where alpha_inter, beta_inter are HO or GHF states and gamma, delta are Berggren basis states
    
  class array<double> CG_antisymmetry_table; // Clebsch-Gordan coefficients <ja ma jb mb | J M> multiplied by sqrt (1 + delta_ab) to calculate uncoupled TBMEs from coupled TBMEs.


  
  // arrays of minimal and maximal total angular momenta for all two-body states. They are used in the Clebsch-Gordan coefficient formula to calculate uncoupled TBMEs from coupled TBMEs.
  
  class array<int> Jmin_table;
  class array<int> Jmax_table;


  
  // arrays providing with the one-dimensional indices of proton and neutron (charged and uncharged baryons if one has hyperons) shells function of one-dimensional state indices
  
  class array<unsigned int> shells_indices_p;
  class array<unsigned int> shells_indices_n;


  
  class array<unsigned int> dimensions_coupled_out; // array of numbers of Berggren out two-body states of fixed parity and J function of (bp,J)


  
  // sums of dimensions of arrays of numbers of TBMEs of binary parity equal to 0,1 and J function of J to calculate one-dimensional indices of TBMEs arrays
    
  class array<class array<unsigned int> > sum_dimensions_coupled_tabs;
  
  class array<unsigned int> bp_table_out; // array of binary parities (see observables_basic_functions.cpp for definition). It is used for the calculation of one-dimensional indices of TBMEs arrays.
  
  class array<int> strangeness_table_out; // array of strangenesses. It is used for the calculation of one-dimensional indices of TBMEs arrays.
  
  class array<unsigned int> i_charge_table_out; // array of charge indices (see observables_basic_functions.cpp for definition). It is used for the calculation of one-dimensional indices of TBMEs arrays.

  class array<unsigned int> pairs_indices_in;  // indices of HO or Berggren in two-body states of fixed parity, strangeness, charge and J functions of (bp , s , i[charge] , J)

  class array<unsigned int> pairs_indices_out; // indices of HO or Berggren out two-body states of fixed parity, strangeness, charge and J functions of ((bp , s , i[charge] , J)
  
  class array<TYPE> table; // arrays of J-coupled TBMEs 
};

void corrective_factor_TBMEs_modification (
					   const class input_data_str &input_data ,
					   const TYPE &corrective_factor , 
					   class baryons_data &prot_Y_data , 
					   class baryons_data &neut_Y_data , 
					   class TBMEs_class &TBMEs_pn, 
					   class TBMEs_class &TBMEs_cv);

#endif


