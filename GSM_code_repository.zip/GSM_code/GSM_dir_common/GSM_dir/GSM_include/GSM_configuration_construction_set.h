#ifndef GSMCONFIGURATIONCONSTRUCTIONSET_H
#define GSMCONFIGURATIONCONSTRUCTIONSET_H

// TYPE is double or complex
// -------------------------

namespace configuration_construction_set
{
  void fill_sets (
		  const enum operation_type operation , 
		  const unsigned int N_valence_baryons_local ,
		  const class configuration &C , 
		  const int n_scat , 
		  class baryons_data &particles_data);

  void tables_no_truncation (
			     const enum operation_type operation ,
			     const unsigned int N_valence_baryons_local ,
			     class baryons_data &particles_data);

  void configuration_part_built (
				 const unsigned int N_valence_baryons_part , 
				 const unsigned short int N_nlj_part , 
				 const unsigned short int debut , 
				 const class baryons_data &particles_data , 
				 class configuration &configuration_part ,
				 bool &is_configuration_part_initialized ,  
				 bool &does_configuration_part_exist);

  unsigned int N_valence_baryons_local_scat_min_calc (
						       const unsigned int N_valence_baryons_local ,
						       const class baryons_data &particles_data);

  void tables_truncation (
			  const enum operation_type operation , 
			  const bool truncation_hw , 
			  const bool truncation_ph , 
			  const bool is_it_pole_approximation , 
			  const unsigned int N_valence_baryons_local ,
			  class baryons_data &particles_data);

  void tables_fill_dimensions_calc (
				    const enum operation_type operation , 
				    const bool truncation_hw , 
				    const bool truncation_ph , 
				    const bool is_it_pole_approximation , 
				    const unsigned int N_valence_baryons_local ,
				    class baryons_data &particles_data);

  void tables_ordering (
			const bool is_it_pole_approximation , 
			const unsigned int N_valence_baryons_local ,
			class baryons_data &particles_data);

  void E_hw_n_holes_tables_M_max_calc (
				       const bool is_it_pole_approximation , 
				       class baryons_data &particles_data);

  void dimensions_tables_alloc_calc_1D_hybrid_1D_2D_partitioning (
								  const bool is_there_cout ,
								  const bool is_it_pole_approximation , 
								  class baryons_data &particles_data);
 
  void tables_allocated_built_1D_hybrid_1D_2D_partitioning (
							    const bool is_there_cout , 
							    const bool print_detailed_information ,
							    const bool truncation_hw , 
							    const bool truncation_ph , 
							    const bool is_it_pole_approximation , 
							    class baryons_data &particles_data);
  
  void dimensions_tables_alloc_calc_2D_partitioning (
						     const bool is_there_cout ,
						     const bool is_it_pole_approximation , 
						     class baryons_data &particles_data);
 
  void tables_allocated_built_2D_partitioning (
					       const bool is_there_cout , 
					       const bool print_detailed_information ,
					       const bool truncation_hw , 
					       const bool truncation_ph , 
					       const bool is_it_pole_approximation , 
					       class baryons_data &particles_data);
}

#endif



