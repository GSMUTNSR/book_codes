#ifndef GSMCONFIGURATIONONEJUMPINTOOUTSTR_H
#define GSMCONFIGURATIONONEJUMPINTOOUTSTR_H


// TYPE is double or complex
// -------------------------

class configuration_one_jump_data_in_to_out_str
{
public:

  configuration_one_jump_data_in_to_out_str ();

  configuration_one_jump_data_in_to_out_str (
					     const unsigned int n_holes_out_c ,
					     const unsigned int n_scat_out_c , 
					     const unsigned int iC_out_c , 
					     const unsigned int C_eq_one_jump_index_c , 
					     const unsigned int C_in_shell_c ,
					     const unsigned int C_out_shell_c); 

  void initialize (
		   const unsigned int n_holes_out_c ,
		   const unsigned int n_scat_out_c , 
		   const unsigned int iC_out_c , 
		   const unsigned int C_eq_one_jump_index_c , 
		   const unsigned int C_in_shell_c ,
		   const unsigned int C_out_shell_c);

  void initialize (const class configuration_one_jump_data_in_to_out_str &X);
		   
  unsigned int get_n_holes_out () const
  {
    return n_holes_out;
  }
  
  unsigned int get_n_scat_out () const
  {
    return n_scat_out;
  }
  
  unsigned int get_C_eq_one_jump_index () const
  {
    return C_eq_one_jump_index;
  }

  unsigned int get_C_in_shell () const
  {
    return C_in_shell;
  }  
  
  unsigned int get_C_out_shell () const
  {
    return C_out_shell;
  }
  
  unsigned int get_iC_out () const
  {
    return iC_out;
  }
  
private:
  
  unsigned char n_holes_out; // number of holes of C[out]
  
  unsigned char n_scat_out; // number of particles in the continuum of C[out]
  
  unsigned int C_eq_one_jump_index; // equivalent configuration index for this jump (see GSM_configuration_one_jump_construction_set_in_to_out.cpp for the definition of the equivalent configuration for jumps)
  
  unsigned short int C_in_shell; // index of the in shell (beta) of C[in]
  
  unsigned short int C_out_shell; // index of the out shell (alpha) of C[out]
  
  unsigned int iC_out; // index of C[out]
};

double used_memory_calc (const class configuration_one_jump_data_in_to_out_str &T);



#endif


