#ifndef GSMARRAYBPSNSPECNSCATIC_H
#define GSMARRAYBPSNSPECNSCATIC_H


// Class of array type to store data related to configurations, of the form T(BP , S , n_spec , n_spec , n_scat , iC) and T(BP , S , n_spec , n_spec , n_scat , iC , i, ...)
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// This class is defined as template of type C, so that C can be any type compatible with the class.
//
// One considers only proton or neutron (plus a few hyperons if any) Slater determinants here.
// A Slater determinant is defined by its parity (here its binary parity BP, see observables_basic_functions.cpp for definition),
// its strangeness S, its number of spectator pairs n_spec (see enum_struct_definitions.h),  
// its number of protons or neutrons (plus a few hyperons if any) in the continuum n_scat and its configuration index iC.
// T(BP , S , n_spec , n_scat , iC , i, ...), for 0 <= i < N, a set of N quantities of a fixed configuration.
// 
// One created a class for this type of storage for as the number of configurations differs according to parities and number of protons or neutrons (plus a few hyperons if any) in the continuum.
// Hence, one would store too many unused values if one allocated a class array with T.allocate (2 , n_scat_max + 1 , configuration_dimension_max + 1),
// as configuration_dimension_max increases very quickly with n_scat.
//
// Hence, one allocates a one-dimensional or two-dimensional array, called table, storing the elements T(BP , S , n_spec , n_scat , iC) or T(BP , S , n_spec , n_scat , iC , i, ...), of dimension dimension_table or (dimension_table,N),
// where dimension_table is the total number of configurations.
//
// The index I associated to (BP , S , n_spec , n_scat , iC) in T(BP , S , n_spec , n_scat , iC) or T(BP , S , n_spec , n_scat , iC , i, ...) is obtained from the array sum_dimensions_configuration_set:
// I = sum_dimensions_configuration_set(BP , S , n_spec , n_scat , iC) and T(BP , S , n_spec , n_scat , iC) = table[I]
// I = sum_dimensions_configuration_set(BP , S , n_spec , n_scat , iC) and T(BP , S , n_spec , n_scat , iC , i, ...) = table(I , i, ...)
// As table is itself stored as a one-dimensional array, one has table(I , i, ...) = table[IT], with IT = table.index_determine (I , i, ...) (see array_vector_class.hpp).
// The IT index is also used here: one has T[IT] = table[iT] = T(BP , S , n_spec , n_scat , iC) or T[iT] = table[iT] = T(BP , S , n_spec , n_scat , iC , i, ...) according to the case, this using straight and curly brackets member operators.
// Similarly, IT = T.index_determine (BP , S , n_spec , n_scat , iC) or IT = T.index_determine (BP , S , n_spec , n_scat , iC , i, ...).
//
// sum_dimensions_configuration_set is a standard array of integers, allocated from a standard allocation of the form: allocate(2 , n_scat_max + 1 , configuration_dimension_max + 1), hence with many zeroes.
// One does not use the same memory saving routine for sum_dimensions_configuration_set as for array_BP_S_Nspec_Nscat_iC, which might seem strange.
// In fact, the fundamental advantage of the class array_BP_S_Nspec_Nscat_iC is that one has only one array of this type, as all array_BP_S_Nspec_Nscat_iC arrays use the same sum_dimensions_configuration_set array in practice.
//
// For example, let us take n_scat_max = 2, 2 configurations for n_scat = 0, 10 configurations for n_scat = 1 and 100 configurations for n_scat = 2.
// Strangeness is fixed at zero, so that it has no effect,
// One takes the same numbers for BP=0,1 , corresponding to 1 and -1 parities (see observables_basic_functions.cpp for definition).
//
// The one-dimensional index I of T(BP , S , n_spec , n_scat , iC) and T(BP , S , n_spec , n_scat , iC , i) is then for:
// BP = 0 , S = 0 , n_scat = 1 , iC = 3 : I = 2 + 3 = 5
// BP = 0 , S = 0 , n_scat = 2 , iC = 55: I = 2 + 10 + 55 = 67
// BP = 1 , S = 0 , n_scat = 1 , iC = 3 : I = 2 + 10 + 100 + 2 + 3 = 117
// BP = 1 , S = 0 , n_scat = 2 , iC = 55: I = 2 + 10 + 100 + 2 + 10 + 55 = 179
//
// The constructors, destructors, allocation and deallocation routines, and index calculation routines are very similar to that in class array.
// The used memory of the class (in Mb) can be calculated in used_memory_calc.
// Its content can be printed on a stream (such as cout << T << endl).
// It can be distributed with MPI as well as typical distribution routines are coded, which are simple wrappers to the MPI routines of class array (see below).
// closest_value_index_determine provides with the index whose value is closest to the element provided (order must be defined for the used type then).
// 
// Variables
// ---------
// dimension_table, N: number of configurations in T(BP , S , n_spec , n_scat , iC) or T(BP , S , n_spec , n_scat , iC , i, ...).
// sum_dimensions_configuration_set, sum_dimensions_configuration_set_ptr: array of sums of configurations (see above). 
//                                                                         Its pointer address is stored in the array_BP_S_Nspec_Nscat_iC class, so that the latter array must exist when using the class. No test is made.
// table: array where T(BP , S , n_spec , n_scat , iC) or T(BP , S , n_spec , n_scat , iC , i, ...) are stored. It is one-dimensional for  T(BP , S , n_spec , n_scat , iC) and two-dimensional for T(BP , S , n_spec , n_scat , iC , i, ...),
//        of dimensions being either dimension_table or (dimension_table , N, ...) (class member).
// 


template <class C>
class array_BP_S_Nspec_Nscat_iC
{
public:

  array_BP_S_Nspec_Nscat_iC () :
    sum_dimensions_configuration_set_ptr (NULL)
  {}
  
  array_BP_S_Nspec_Nscat_iC (
			     const unsigned int dimension_table , 
			     const class array<unsigned int> &sum_dimensions_configuration_set)
  {
    allocate (dimension_table , sum_dimensions_configuration_set);
  }

  array_BP_S_Nspec_Nscat_iC (
			     const unsigned int dimension_table , 
			     const class array<unsigned int> &sum_dimensions_configuration_set , 
			     const unsigned int N)
  {
    allocate (dimension_table , sum_dimensions_configuration_set , N);
  }

  array_BP_S_Nspec_Nscat_iC (const class array_BP_S_Nspec_Nscat_iC<C> &X)
  {
    allocate_fill (X);
  }
  
  void allocate (
		 const unsigned int dimension_table , 
		 const class array<unsigned int> &sum_dimensions_configuration_set)
  {
    sum_dimensions_configuration_set_ptr = &sum_dimensions_configuration_set;
    
    table.allocate (dimension_table);
  }

  void allocate (
		 const unsigned int dimension , 
		 const class array<unsigned int> &sum_dimensions_configuration_set , 
		 const unsigned int N)
  {
    sum_dimensions_configuration_set_ptr = &sum_dimensions_configuration_set;
    
    table.allocate (dimension , N);
  }

  void allocate (
		 const unsigned int dimension , 
		 const class array<unsigned int> &sum_dimensions_configuration_set , 
		 const unsigned int N1 , 
		 const unsigned int N2)
  {
    sum_dimensions_configuration_set_ptr = &sum_dimensions_configuration_set;
    
    table.allocate (dimension , N1 , N2);
  }

  void allocate (
		 const unsigned int dimension , 
		 const class array<unsigned int> &sum_dimensions_configuration_set , 
		 const unsigned int N1 , 
		 const unsigned int N2 , 
		 const unsigned int N3)
  {
    sum_dimensions_configuration_set_ptr = &sum_dimensions_configuration_set;
    
    table.allocate (dimension , N1 , N2 , N3);
  }

  void allocate_fill (const class array_BP_S_Nspec_Nscat_iC<C> &X)
  {
    sum_dimensions_configuration_set_ptr = X.sum_dimensions_configuration_set_ptr;
 
    table.allocate_fill (X.table);
  }

  void deallocate ()
  {
    table.deallocate ();

    sum_dimensions_configuration_set_ptr = NULL;
  }

  void deallocate_object_elements () 
  {
    table.deallocate_table_object_elements ();
  }

  unsigned int index_determine (
				const unsigned int BP , 
				const int S , 
				const int n_spec , 
				const int n_scat , 
				const unsigned int iC) const
  {
    const class array<unsigned int> &sum_dimensions_configuration_set = get_sum_dimensions_configuration_set ();
    
    const unsigned int index = iC + sum_dimensions_configuration_set(BP , S , n_spec , n_scat);
    
    return index;
  }

  unsigned int index_determine (
				const unsigned int BP , 
				const int S , 
				const int n_spec , 
				const int n_scat , 
				const unsigned int iC , 
				const unsigned int i1) const
  {
    const unsigned int i0 = index_determine (BP , S , n_spec , n_scat , iC);
    
    const unsigned int index = table.index_determine (i0 , i1);
    
    return index;
  }

  unsigned int index_determine (
				const unsigned int BP , 
				const int S , 
				const int n_spec , 
				const int n_scat , 
				const unsigned int iC , 
				const unsigned int i1 , 
				const unsigned int i2) const
  {
    const unsigned int i0 = index_determine (BP , S , n_spec , n_scat , iC);
    
    const unsigned int index = table.index_determine (i0 , i1 , i2);
    
    return index;
  }

  unsigned int index_determine (
				const unsigned int BP , 
				const int S , 
				const int n_spec , 
				const int n_scat , 
				const unsigned int iC , 
				const unsigned int i1 , 
				const unsigned int i2 , 
				const unsigned int i3) const
  {
    const unsigned int i0 = index_determine (BP , S , n_spec , n_scat , iC);
    
    const unsigned int index = table.index_determine (i0 , i1 , i2 , i3);
    
    return index;
  }

  void operator = (const C &x)
  {
    table = x;
  }

  C & operator [] (const unsigned int i) const
  {
    return table[i];	
  }

  C & operator () (
		   const unsigned int BP , 
		   const int S , 
		   const int n_spec , 
		   const int n_scat , 
		   const unsigned int iC) const
  {
    const unsigned int index = index_determine (BP , S , n_spec , n_scat , iC);
    
    return table[index];
  }

  C & operator () (
		   const unsigned int BP , 
		   const int S , 
		   const int n_spec , 
		   const int n_scat , 
		   const unsigned int iC , 
		   const unsigned int i1) const
  {
    const unsigned int index = index_determine (BP , S , n_spec , n_scat , iC , i1);
    
    return table[index];
  }

  C & operator () (
		   const unsigned int BP , 
		   const int S , 
		   const int n_spec , 
		   const int n_scat , 
		   const unsigned int iC , 
		   const unsigned int i1 , 
		   const unsigned int i2) const
  {
    const unsigned int index = index_determine (BP , S , n_spec , n_scat , iC , i1 , i2);
    
    return table[index];
  }

  C & operator () (
		   const unsigned int BP , 
		   const int S , 
		   const int n_spec , 
		   const int n_scat , 
		   const unsigned int iC , 
		   const unsigned int i1 , 
		   const unsigned int i2 , 
		   const unsigned int i3) const
  {
    const unsigned int index = index_determine (BP , S , n_spec , n_scat , iC , i1 , i2 , i3);
    
    return table[index];
  }

  template <class D>
  friend double used_memory_calc (const class array_BP_S_Nspec_Nscat_iC<D> &T);

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const;
  
  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const;

  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const;

  unsigned int closest_value_index_determine (const C &x) const;
  
#ifdef UseMPI
  void MPI_Send  (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv  (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C);
  
  void MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);

  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);

  void MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C);

  void MPI_Reduce    (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);

  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif

  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }

  template <class D>
  friend ostream & operator << (ostream &os , const class array_BP_S_Nspec_Nscat_iC<D> &T);
  
private:

  const class array<unsigned int> & get_sum_dimensions_configuration_set () const
  {
    return *sum_dimensions_configuration_set_ptr;
  }
  
  const class array<unsigned int> *sum_dimensions_configuration_set_ptr;
  
  class array<C> table;
};



// The array of the sum_dimensions_configuration_set_ptr pointer is not considered as part of the class as it not allocated inside the class definition.

template <class C>
double used_memory_calc (const class array_BP_S_Nspec_Nscat_iC<C> &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.table) - sizeof (T.table)/1000000.0);
}



template <class C>
ostream & operator << (ostream &os , const class array_BP_S_Nspec_Nscat_iC<C> &T)
{
  return os << T.table;
}



template <class C>
unsigned int array_BP_S_Nspec_Nscat_iC<C>::first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
{
  return table.first_index_determine_for_MPI (group_processes_number , process);
}

template <class C>
unsigned int array_BP_S_Nspec_Nscat_iC<C>::last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
{
  return table.last_index_determine_for_MPI (group_processes_number , process);
}

template <class C>
unsigned int array_BP_S_Nspec_Nscat_iC<C>::active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
{
  return table.active_process_determine_for_MPI (group_processes_number , index);
}

template <class C>
unsigned int array_BP_S_Nspec_Nscat_iC<C>::closest_value_index_determine (const C &x) const
{
  return table.get_closest_index_determine (x);
}






#ifdef UseMPI

template <class C>
void array_BP_S_Nspec_Nscat_iC<C>::MPI_Send (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Send (Recv_process , tag , MPI_C);
}

template <class C>
void array_BP_S_Nspec_Nscat_iC<C>::MPI_Recv (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Recv (Send_process , tag , MPI_C);
}

template <class C>
void array_BP_S_Nspec_Nscat_iC<C>::MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  table.MPI_Sendrecv_replace (Send_process , Recv_process , Send_tag , Recv_tag ,  MPI_C);
}

template <class C>
void array_BP_S_Nspec_Nscat_iC<C>::MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C)
{
  table.MPI_Allgatherv (group_processes_number , MPI_C);
}

template <class C>
void array_BP_S_Nspec_Nscat_iC<C>::MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  table.MPI_Bcast (Send_process , MPI_C);
}

template <class C>
void array_BP_S_Nspec_Nscat_iC<C>::MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  table.MPI_Reduce (op , Recv_process , process , MPI_C);
}

template <class C>
void array_BP_S_Nspec_Nscat_iC<C>::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  table.MPI_Allreduce (op , MPI_C);
}

#endif

#endif

