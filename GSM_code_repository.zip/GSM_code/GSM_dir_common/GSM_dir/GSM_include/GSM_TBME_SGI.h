#ifndef GSMTBMESGI_H
#define GSMTBMESGI_H

// TYPE is double or complex
// -------------------------

namespace TBME_SGI_set
{
  TYPE radial_integral_calc (
			     const class interaction_class &inter_data , 
			     const int ll , 
			     const class spherical_state &wf0 , 
			     const class spherical_state &wf1 , 
			     const class spherical_state &wf2 , 
			     const class spherical_state &wf3);

  void pp_nn_radial_integrals_calc (
				    const class nucleons_data &particles_data , 
				    const class interaction_class &inter_data , 
				    const unsigned int s0 , 
				    const unsigned int s1 , 
				    const unsigned int s2 , 
				    const unsigned int s3 , 
				    class array<TYPE> &radial_direct_tab , 
				    class array<TYPE> &radial_exchange_tab);

  void pn_radial_integrals_calc (
				 const class nucleons_data &prot_data , 
				 const class nucleons_data &neut_data , 
				 const class interaction_class &inter_data , 
				 const unsigned int s0 , 
				 const unsigned int s1 , 
				 const unsigned int s2 , 
				 const unsigned int s3 , 
				 class array<TYPE> &radial_direct_tab , 
				 class array<TYPE> &radial_exchange_tab);

  TYPE TBME_pi_pj_J (
		     const int J , 
		     const class array<TYPE> &reduced_grad_HO_expansion_02_tab , 
		     const class array<TYPE> &reduced_grad_HO_expansion_13_tab , 
		     const unsigned int s0 , 
		     const unsigned int s1 , 
		     const unsigned int s2 , 
		     const unsigned int s3 , 
		     const class spherical_state &wf0 , 
		     const class spherical_state &wf1 , 
		     const class spherical_state &wf2 , 
		     const class spherical_state &wf3);

  TYPE TBME_J (
	       const bool is_there_recoil , 
	       const int J , 
	       const class interaction_class &inter_data , 
	       const class multipolar_expansion_str &multipolar_expansion , 
	       const class array<TYPE> &radial_TBMEs , 
	       const class array<TYPE> &reduced_grad_HO_expansion_02_tab , 
	       const class array<TYPE> &reduced_grad_HO_expansion_13_tab , 
	       const unsigned int s0 , 
	       const unsigned int s1 , 
	       const unsigned int s2 , 
	       const unsigned int s3 , 
	       const class spherical_state &wf0 , 
	       const class spherical_state &wf1 , 
	       const class spherical_state &wf2 , 
	       const class spherical_state &wf3);

  TYPE TBME_J_pp_nn_antisymmetrized (
				     const bool is_there_recoil , 
				     const int J , 
				     const unsigned int s0 , 
				     const unsigned int s1 , 
				     const unsigned int s2 , 
				     const unsigned int s3 , 
				     const class array<class spherical_state> &shells , 
				     const class array<TYPE> &radial_TBMEs_direct , 
				     const class array<TYPE> &radial_TBMEs_exchange , 
				     const class array<TYPE> &reduced_grad_HO_expansion_tab , 
				     const class interaction_class &inter_data , 
				     const class multipolar_expansion_str &multipolar_expansion);

  TYPE TBME_J_pn (
		  const bool is_there_recoil , 
		  const int J , 
		  const unsigned int s0 , 
		  const unsigned int s1 , 
		  const unsigned int s2 , 
		  const unsigned int s3 , 
		  const class array<class spherical_state> &shells_prot , 
		  const class array<class spherical_state> &shells_neut , 
		  const class array<TYPE> &radial_TBMEs_direct , 
		  const class array<TYPE> &radial_TBMEs_exchange , 
		  const class array<TYPE> &reduced_grad_HO_expansion_p_tab , 
		  const class array<TYPE> &reduced_grad_HO_expansion_n_tab , 
		  const class interaction_class &inter_data , 
		  const class multipolar_expansion_str &multipolar_expansion);

}

#endif


