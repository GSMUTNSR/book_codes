#ifndef GSMCOULOMBPOTENTIAL_H
#define GSMCOULOMBPOTENTIAL_H

// TYPE is double or complex
// -------------------------

namespace Coulomb_potential
{
  void local_potential_calc (
			     const bool is_it_relative , 
			     const enum potential_type H_potential , 
			     const enum particle_type particle , 
			     const int ZY_charge_pos , 
			     const int ZY_charge_neg , 
			     const double R_charge , 
			     const class array<double> &r_table , 
			     class array<double> &V_Coulomb_table);

  void local_potential_calc (
			     const bool is_it_relative , 
			     const enum potential_type H_potential , 
			     const enum particle_type particle , 
			     const int ZY_charge_pos , 
			     const int ZY_charge_neg , 
			     const double R_charge , 
			     const class array<complex<double> > &r_table , 
			     class array<complex<double> > &V_Coulomb_table);
}

#endif



