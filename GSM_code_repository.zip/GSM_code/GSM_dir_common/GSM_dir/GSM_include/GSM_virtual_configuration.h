#ifndef GSMVIRTUALCONFIGURATION_H
#define GSMVIRTUALCONFIGURATION_H

// TYPE is double or complex
// -------------------------

class virtual_configuration 
{
public:
  virtual_configuration (
			 const class array<unsigned short int> &table_c ,
			 const unsigned int index_c);

  ~virtual_configuration ();

  unsigned int get_N_valence_baryons () const
  {
    return table.dimension (1);
  }
  
  unsigned short int & operator [] (const unsigned int i) const
  {
    return table(index , i);
  }

  const class virtual_configuration & operator = (const class configuration &X);
  
private:
  
  const class array<unsigned short int> &table;
  
  const unsigned int index;
};


#endif


