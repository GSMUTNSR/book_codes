#include "../GSM_include/GSM_include_def_common.h"
			       
// TYPE is double or complex
// -------------------------

// Array class type to store an array of class SD_one_jump_data_Jpm_in_to_out_str
// -------------------------------------------------------------------------------------
// class SD_one_jump_data_Jpm_in_to_out_str stores information related to the SD outSD obtained after the action of a+_{alpha} a_{beta} on a Slater determinant inSD to generate outSD for the action of J+/J- only.
// It contains the shell index for this jump, as the shell is fixed during a jump when J+/J- only is considered,
// the coded difference of M quantum numbers, equal to 1 for J+ and 0 for J-, from which M_out = M_in +/- 1 can be recovered as M_in is fixed, 
// the index of outSD in a fixed configuration, and the binary phase related to a+_{alpha} a_{beta}.
// M_out and m_out can be recovered from shifted M-values as M_in is fixed.

SD_one_jump_data_Jpm_in_to_out_str::SD_one_jump_data_Jpm_in_to_out_str () :
  shell_index (0) ,
  im_out (0) ,
  Delta_iM_out (0) ,
  outSD_index (0) ,
  bin_phase (0)
{}

SD_one_jump_data_Jpm_in_to_out_str::SD_one_jump_data_Jpm_in_to_out_str (
									const unsigned int shell_index_c , 
									const unsigned int im_out_c , 
									const unsigned int Delta_iM_out_c , 
									const unsigned int outSD_index_c , 
									const unsigned int bin_phase_c)
{
  initialize (shell_index_c , im_out_c , Delta_iM_out_c , outSD_index_c , bin_phase_c);
}

void SD_one_jump_data_Jpm_in_to_out_str::initialize (
						     const unsigned int shell_index_c , 
						     const unsigned int im_out_c , 
						     const unsigned int Delta_iM_out_c , 
						     const unsigned int outSD_index_c , 
						     const unsigned int bin_phase_c)
{
  shell_index = shell_index_c;  

  im_out = im_out_c;  

  Delta_iM_out = Delta_iM_out_c; 

  outSD_index = outSD_index_c; 

  bin_phase = bin_phase_c;
}

void SD_one_jump_data_Jpm_in_to_out_str::initialize (const class SD_one_jump_data_Jpm_in_to_out_str &X)
{
  shell_index = X.shell_index;  

  im_out = X.im_out;  

  Delta_iM_out = X.Delta_iM_out; 

  outSD_index = X.outSD_index;  

  bin_phase = X.bin_phase; 
}


double used_memory_calc (const class SD_one_jump_data_Jpm_in_to_out_str &T)
{
  return sizeof (T)/1000000.0;
}

