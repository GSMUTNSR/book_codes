#include "../GSM_include/GSM_include_def_common.h"

using namespace string_routines;
using namespace inputs_misc;
using namespace correlated_state_routines;



// TYPE is double or complex
// -------------------------


// Allocation, calculation and MPI distribution (Slater determinants only) of configurations and Slater determinants
// -----------------------------------------------------------------------------------------------------------------
// Routines to allocate, calculate and distribute configurations and Slater determinants are called here in the proton or the neutron cases, and for 1D and hybrid 1D/2D partitioning, or for 2D partitioning.

void configuration_SD_sets::configuration_SD_tables_alloc_calc (
								const bool is_there_cout , 
								const bool is_it_only_basis , 
								const bool is_it_2D_partitioning , 
								const class input_data_str &input_data , 
								class nucleons_data &data)
{
  const bool print_detailed_information = input_data.get_print_detailed_information ();

  const bool only_dimensions = input_data.get_only_dimensions ();

  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const bool is_it_cluster_CM_HO_basis_calculation = input_data.get_is_it_cluster_CM_HO_basis_calculation ();

  if (is_it_2D_partitioning)
    {
      configuration_construction_set::tables_allocated_built_2D_partitioning (is_there_cout , print_detailed_information , truncation_hw , truncation_ph , is_it_cluster_CM_HO_basis_calculation , data);
  
      SD_construction_set::tables_allocated_built_2D_partitioning (is_there_cout , print_detailed_information , is_it_only_basis , is_it_cluster_CM_HO_basis_calculation , data , only_dimensions);
    }
  else
    {
      configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (is_there_cout , print_detailed_information , truncation_hw , truncation_ph , is_it_cluster_CM_HO_basis_calculation , data);
  
      SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (is_there_cout , print_detailed_information , is_it_only_basis , is_it_cluster_CM_HO_basis_calculation , data , only_dimensions);
    }
}





// Allocation, calculation and MPI distribution (Slater determinants only) of configurations and Slater determinants for proton and neutron cases
// ----------------------------------------------------------------------------------------------------------------------------------------------
// Routines to allocate, calculate and distribute configurations and Slater determinants are called here for both proton and neutron cases.
// The total time spent to configurations and Slater determinants is printed in this routine as well.

void configuration_SD_sets::configuration_SD_tables_pp_nn_alloc_calc (
								      const bool is_there_cout ,
								      const bool is_it_only_basis ,
								      const bool is_it_2D_partitioning , 
								      const class input_data_str &input_data ,
								      class nucleons_data &prot_data , 
								      class nucleons_data &neut_data)
{
  const bool is_time_considered = ((THIS_PROCESS == MASTER_PROCESS) && !is_it_only_basis && is_there_cout);
  
  const double reference_time = (is_time_considered) ? (absolute_time_determine ()) : (NADA);
  
  const enum space_type space = (is_it_only_basis) ? (input_data.get_basis_space ()) : (input_data.get_space ());

  if (space != NEUTRONS_ONLY) configuration_SD_tables_alloc_calc (is_there_cout , is_it_only_basis , is_it_2D_partitioning , input_data , prot_data);
  if (space != PROTONS_ONLY)  configuration_SD_tables_alloc_calc (is_there_cout , is_it_only_basis , is_it_2D_partitioning , input_data , neut_data);
  
  if (is_time_considered)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time;
      
      cout << endl << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;
      cout << "Configurations and Slater determinants built. time:" << relative_time << " s" << endl;
      cout << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl << endl;
    }
}



