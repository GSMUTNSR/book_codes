#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// CM means center of mass
// -----------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------


// Routines are straightforward so that they are not detailed. Only general explanations are given.
// ------------------------------------------------------------------------------------------------



// get functions to obtain the array of OBMEs and reduced r's and gradients of the considered CM operator
// ------------------------------------------------------------------------------------------------------
// OBMEs and reduced r's and gradients are either used with HO expansion or R cut. 
//
// With HO expansion <a | Op | b> = \sum_{HO_a , HO_b} <HO_a | Op | HO_b>  <a|HO_a> <b|HO_b>, with a,b Berggren basis states and HO_a,HO_b HO states.
// With R cut, the radial integral in <a | Op | b> is calculated on [0:R] only. 
// The proper array is obtained here.
// 
// The difference between the reduced r's and gradients arrays with and without rms_radius_pn is that they are multiplied by different constants (see GSM_OBMEs_TBMEs.cpp)

const class OBMEs_CM_set_str & CM_OBMEs_TBMEs::OBMEs_CM_set_determine (
								       const bool is_it_HO_expansion ,
								       const class baryons_data &data)
{
  const class OBMEs_CM_set_str &OBMEs_CM_set_HO_expansion = data.get_OBMEs_CM_set_HO_expansion ();

  const class OBMEs_CM_set_str &OBMEs_CM_set_R_cut = data.get_OBMEs_CM_set_R_cut ();

  const class OBMEs_CM_set_str &OBMEs_CM_set = (is_it_HO_expansion) ? (OBMEs_CM_set_HO_expansion) : (OBMEs_CM_set_R_cut);
  
  return OBMEs_CM_set;
}
   
const class array<TYPE> & CM_OBMEs_TBMEs::reduced_grad_tab_determine (
								      const enum operator_type CM_operator_inter ,
								      const bool is_it_HO_expansion ,
								      const class baryons_data &data)
{
  const class OBMEs_CM_set_str &reduced_grad_HO_expansion_set = data.get_reduced_grad_HO_expansion_set ();

  const class OBMEs_CM_set_str &reduced_grad_R_cut_set = data.get_reduced_grad_R_cut_set ();

  const class OBMEs_CM_set_str &reduced_grad_set = (is_it_HO_expansion) ? (reduced_grad_HO_expansion_set) : (reduced_grad_R_cut_set);

  return reduced_grad_set(CM_operator_inter);
}
  
const class array<TYPE> & CM_OBMEs_TBMEs::reduced_r_tab_determine (
								   const enum operator_type CM_operator_inter ,
								   const bool is_it_HO_expansion ,
								   const class baryons_data &data)
{
  const class OBMEs_CM_set_str &reduced_r_HO_expansion_set = data.get_reduced_r_HO_expansion_set ();

  const class OBMEs_CM_set_str &reduced_r_R_cut_set = data.get_reduced_r_R_cut_set ();

  const class OBMEs_CM_set_str &reduced_r_set = (is_it_HO_expansion) ? (reduced_r_HO_expansion_set) : (reduced_r_R_cut_set);

  return reduced_r_set(CM_operator_inter);
}
    
const class array<TYPE> & CM_OBMEs_TBMEs::reduced_r_tab_rms_radius_pn_determine (
										 const enum operator_type CM_operator_inter ,
										 const bool is_it_HO_expansion ,
										 const class baryons_data &data)
{
  const class OBMEs_CM_set_str &reduced_r_HO_expansion_rms_radius_different_particles_set = data.get_reduced_r_HO_expansion_rms_radius_different_particles_set ();

  const class OBMEs_CM_set_str &reduced_r_R_cut_rms_radius_different_particles_set = data.get_reduced_r_R_cut_rms_radius_different_particles_set ();

  const class OBMEs_CM_set_str &reduced_r_rms_radius_different_particles_set = (is_it_HO_expansion) ? (reduced_r_HO_expansion_rms_radius_different_particles_set) : (reduced_r_R_cut_rms_radius_different_particles_set);

  return reduced_r_rms_radius_different_particles_set(CM_operator_inter);
}

TYPE CM_OBMEs_TBMEs::uncoupled_OBME (
				     const operator_type CM_operator_inter ,
				     const bool is_it_HO_expansion ,
				     const class baryons_data &data ,
				     const unsigned int s_in ,
				     const unsigned int s_out)
{
  const class OBMEs_CM_set_str &OBMEs_CM_set = OBMEs_CM_set_determine (is_it_HO_expansion , data);

  const TYPE OBME = OBMEs_CM_set.uncoupled_OBME (CM_operator_inter , s_in , s_out);

  return OBME;
}
  
TYPE CM_OBMEs_TBMEs::coupled_OBME (
				   const operator_type CM_operator_inter ,
				   const bool is_it_HO_expansion ,
				   const class baryons_data &data ,
				   const unsigned int s_in ,
				   const unsigned int s_out)
{
  const class OBMEs_CM_set_str &OBMEs_CM_set = OBMEs_CM_set_determine (is_it_HO_expansion , data);

  const TYPE OBME = OBMEs_CM_set.coupled_OBME (CM_operator_inter , s_in , s_out);

  return OBME;
}
  


// Check if TBMEs are trivial zeros
// --------------------------------
// TBMEs are of the form <ab | ri x rj | cd>, <ab | pi x pj | cd>, <ab | ri x pj | cd>.
// a,b,c,d are denoted as s0,s1,s2,s3 in the routine.
//
// pp, nn TBMEs
// ------------
// TBMEs are equal to zero if (a,c) and (a,d) have same parities (direct and exchange parts), as r and p do not conserve parity. 
// It is also the case if |ma - mc| > 1 and |ma - md| > 1 (direct and exchange parts), or if |ja - jc| > 1 or |jb - jd| > 1 (direct part) and |ja - jd| > 1 or |jb - jc| > 1 (exchange part), as r and p are of rank 1.
//
// pn TBMEs
// --------
// The situation here is simpler as there is no antisymmetry. 
// Conditions on parity and m are already taken into account (see two_jumps_pn_part_pn_N_valence_larger_calc and two_jumps_pn_part_pn_Z_valence_larger_calc).
// Hence, the TBME is trivially zero if |ja - jc| > 1 or |jb - jd| > 1.
//
// Coupled and uncoupled TBMEs are considered.

bool CM_OBMEs_TBMEs::is_uncoupled_TBME_pp_nn_trivial_zero_determine (
								     const class array<class nljm_struct> &phi_table ,
								     const unsigned int s0 , 
								     const unsigned int s1 , 
								     const unsigned int s2 , 
								     const unsigned int s3)
{
  const class nljm_struct &phi0 = phi_table(s0) , &phi1 = phi_table(s1);
  const class nljm_struct &phi2 = phi_table(s2) , &phi3 = phi_table(s3);

  const enum particle_type B0 = phi0.get_particle () , B1 = phi1.get_particle ();
  const enum particle_type B2 = phi2.get_particle () , B3 = phi3.get_particle ();

  const bool dir_particles_condition = ((B0 == B2) && (B1 == B3));
  const bool exc_particles_condition = ((B1 == B2) && (B0 == B3));

  if (!dir_particles_condition && !exc_particles_condition) return true;
	    
  const int l0 = phi0.get_l ();
  const int l2 = phi2.get_l ();
  const int l3 = phi3.get_l ();

  const bool dir_parity_condition = ((l0 + l2)%2 == 1);
  const bool exc_parity_condition = ((l0 + l3)%2 == 1);

  if (!dir_parity_condition && !exc_parity_condition) return true;

  const int im0 = phi0.get_im ();
  const int im2 = phi2.get_im ();
  const int im3 = phi3.get_im ();

  const bool dir_projection_condition = (abs (im0 - im2) <= 1);
  const bool exc_projection_condition = (abs (im0 - im3) <= 1);

  if (!dir_projection_condition && !exc_projection_condition) return true;
  
  const int ij0 = phi0.get_ij () ,  ij1 = phi1.get_ij ();
  const int ij2 = phi2.get_ij () ,  ij3 = phi3.get_ij ();

  const bool phi0_phi2_coupling_condition = (abs (ij0 - ij2) <= 1) ,  phi1_phi3_coupling_condition = (abs (ij1 - ij3) <= 1);
  const bool phi0_phi3_coupling_condition = (abs (ij0 - ij3) <= 1) ,  phi1_phi2_coupling_condition = (abs (ij1 - ij2) <= 1);

  const bool dir_coupling_condition = (phi0_phi2_coupling_condition && phi1_phi3_coupling_condition);
  const bool exc_coupling_condition = (phi0_phi3_coupling_condition && phi1_phi2_coupling_condition);

  if (!dir_coupling_condition && !exc_coupling_condition) return true;

  return false;
}

bool CM_OBMEs_TBMEs::is_uncoupled_TBME_pn_trivial_zero_determine_coupling_only (
										const class array<class nljm_struct> &phi_table ,
										const unsigned int s_in , 
										const unsigned int s_out)
{
  const class nljm_struct &phi_in  = phi_table(s_in);
  const class nljm_struct &phi_out = phi_table(s_out);

  const int ij_in  = phi_in.get_ij ();
  const int ij_out = phi_out.get_ij ();

  const bool coupling_condition = (abs (ij_in - ij_out) <= 1);

  if (!coupling_condition) return true;

  return false;
}

bool CM_OBMEs_TBMEs::is_coupled_TBME_pp_nn_trivial_zero_determine (
								   const class array<class nlj_struct> &shells_qn , 
								   const unsigned int s0 , 
								   const unsigned int s1 , 
								   const unsigned int s2 , 
								   const unsigned int s3)
{
  const class nlj_struct &wf0 = shells_qn(s0) , &wf1 = shells_qn(s1);
  const class nlj_struct &wf2 = shells_qn(s2) , &wf3 = shells_qn(s3);

  const enum particle_type B0 = wf0.get_particle () , B1 = wf1.get_particle ();
  const enum particle_type B2 = wf2.get_particle () , B3 = wf3.get_particle ();
  
  const bool dir_particles_condition = ((B0 == B2) && (B1 == B3));
  const bool exc_particles_condition = ((B1 == B2) && (B0 == B3));

  if (!dir_particles_condition && !exc_particles_condition) return true;
  
  const int l0 = wf0.get_l ();
  const int l2 = wf2.get_l ();
  const int l3 = wf3.get_l ();
  
  const bool dir_parity_condition = ((l0 + l2)%2 == 1);
  const bool exc_parity_condition = ((l0 + l3)%2 == 1);
  
  if (!dir_parity_condition && !exc_parity_condition) return true;

  const int ij0 = wf0.get_ij () , ij1 = wf1.get_ij ();
  const int ij2 = wf2.get_ij () , ij3 = wf3.get_ij ();

  const bool wf0_wf2_coupling_condition = (abs (ij0 - ij2) <= 1) ,  wf1_wf3_coupling_condition = (abs (ij1 - ij3) <= 1);
  const bool wf0_wf3_coupling_condition = (abs (ij0 - ij3) <= 1) ,  wf1_wf2_coupling_condition = (abs (ij1 - ij2) <= 1);

  const bool dir_coupling_condition = (wf0_wf2_coupling_condition && wf1_wf3_coupling_condition);
  const bool exc_coupling_condition = (wf0_wf3_coupling_condition && wf1_wf2_coupling_condition);

  if (!dir_coupling_condition && !exc_coupling_condition) return true;

  return false;
}

bool CM_OBMEs_TBMEs::is_coupled_TBME_pn_trivial_zero_determine (
								const class array<class nlj_struct> &shells_qn_p , 
								const class array<class nlj_struct> &shells_qn_n ,
								const unsigned int s0 , 
								const unsigned int s1 , 
								const unsigned int s2 , 
								const unsigned int s3)
{
  const class nlj_struct &wf0 = shells_qn_p(s0) , &wf1 = shells_qn_n(s1);
  const class nlj_struct &wf2 = shells_qn_p(s2) , &wf3 = shells_qn_n(s3);

  const enum particle_type B0 = wf0.get_particle () , B1 = wf1.get_particle ();
  const enum particle_type B2 = wf2.get_particle () , B3 = wf3.get_particle ();
  
  const bool particles_condition = ((B0 == B2) && (B1 == B3));

  if (!particles_condition) return true;

  const int l0 = wf0.get_l ();
  const int l2 = wf2.get_l ();

  const bool parity_condition = ((l0 + l2)%2 == 1);

  if (!parity_condition) return true; 

  const int ij0 = wf0.get_ij () ,  ij1 = wf1.get_ij ();
  const int ij2 = wf2.get_ij () ,  ij3 = wf3.get_ij ();

  const bool wf0_wf2_coupling_condition = (abs (ij0 - ij2) <= 1);
  const bool wf1_wf3_coupling_condition = (abs (ij1 - ij3) <= 1);

  const bool coupling_condition = (wf0_wf2_coupling_condition && wf1_wf3_coupling_condition);

  if (!coupling_condition) return true;

  return false;
}








// Calculation of TBMEs according to the considered CM operator
// ------------------------------------------------------------
// a,b,c,d are denoted as s0,s1,s2,s3 in the routines.
// They are shell indices (n,l,j) in the next two routines and state indices (n,l,j,m) in the following routines.
//
// Angular TBMEs are calculated in a CM_TBMEs_angular_table_str class using stored Clebsch-Gordan coefficients (see GSM_CM_TBMEs_angular_table_str.cpp).
// Non-antisymmetrized <ab | ri x rj | cd>, <ab | pi x pj | cd>, <ab | ri x pj | cd> are products of stored const.<a || r or grad || c>, const.<b || r or grad || d>, TBME_angular(a,b,c,d), and a +/- sign (see below).
// One obtains the full pp or nn TBME by considering both direct and exchange parts anf antisymmetry norms.
// They are considered to be equal to zero if their infinite norms are smaller than 10^(-13).
//
// <a || r or grad || c> calculated with proton or neutron wave functions and with the proper factor has to be used according to the considered TBME, which is done afterwards.
//
// Here are considered CM operators:
//
// CM_KINETIC: it is P^2/2M (realistic interactions) or pi.pj/M_core (COSM), so that TBMEs are <ab | const.pi.pj | cd>, where <a || grad || c> has been already multiplied by the proper factor up to a minus sign.
//             The minus sign comes from p = -i hbar grad. 
//
// HCM: it is P^2/2M + (1/2) M omega^2 R^2, so that TBMEs are  <ab | const(p).pi.pj + const(r).ri.rj | cd>, where <a || r or grad || c> has been already multiplied by that factor.
//
// LPLUS, LMINUS, LZ: L = R x P, and L+,L-,Lz are its spherical tensor components. Hence, TBMEs are  <ab | const.(pi x rj) + const (ri x pj) | cd>, where <a || r or grad || c> has been already multiplied by the proper factor.
//
// RMS_RADIUS_PROTON, RMS_RADIUS_NEUTRON: it is \sum const_i ri^2 + \sum_(i<j) const_ij ri.rj. Hence, TBMEs are <ab | const.ri.rj | cd>, where <a || r || c> has been already multiplied by the proper factor up to a +/- sign.
//                                        The phase occurs as <a || r || c> has been multiplied in TBMEs by sqrt (|const|), and const can be positive or negative.
//                                        The sign depends only on the proton or neutron character of states in pp and nn TBMEs and is always negative for pn TBMEs.
//                                        See rms_radius_two_body_sqrt_factor_pp_nn_calc and rms_radius_two_body_sqrt_factor_pn_calc in observables_basic_functions.cpp.
//
// Coupled and uncoupled TBMEs are considered.

TYPE CM_OBMEs_TBMEs::TBME_pp_nn_calc (
				      const enum operator_type CM_operator_inter , 
				      const enum particle_type particle , 
				      const unsigned int s0 , 
				      const unsigned int s1 , 
				      const unsigned int s2 , 
				      const unsigned int s3 , 
				      const double angular_TBME_dir , 
				      const double angular_TBME_exc , 
				      const class array<TYPE> &reduced_grad_tab , 
				      const class array<TYPE> &reduced_r_tab)
{ 
  switch (CM_operator_inter)
    {
    case CM_KINETIC: 
      {
	const TYPE OBMEs_product_dir = -reduced_grad_tab(s0 , s2)*reduced_grad_tab(s1 , s3);
	const TYPE OBMEs_product_exc = -reduced_grad_tab(s1 , s2)*reduced_grad_tab(s0 , s3);
	
	const TYPE TBME_numerical = angular_TBME_dir*OBMEs_product_dir - angular_TBME_exc*OBMEs_product_exc;

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));
	
	return TBME;
      }

    case HCM: 
      {
	const TYPE OBMEs_grad_product_dir = -reduced_grad_tab(s0 , s2)*reduced_grad_tab(s1 , s3);
	const TYPE OBMEs_grad_product_exc = -reduced_grad_tab(s1 , s2)*reduced_grad_tab(s0 , s3);
	
	const TYPE OBMEs_r_product_dir = reduced_r_tab(s0 , s2)*reduced_r_tab(s1 , s3);
	const TYPE OBMEs_r_product_exc = reduced_r_tab(s1 , s2)*reduced_r_tab(s0 , s3);
	
	const TYPE OBMEs_product_sum_dir = OBMEs_grad_product_dir + OBMEs_r_product_dir;
	const TYPE OBMEs_product_sum_exc = OBMEs_grad_product_exc + OBMEs_r_product_exc;

	const TYPE TBME_numerical = angular_TBME_dir*OBMEs_product_sum_dir - angular_TBME_exc*OBMEs_product_sum_exc;
	
	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));
	
	return TBME;
      }

    case LPLUS:
      { 
	const TYPE OBMEs_product_r_grad_dir = reduced_r_tab(s0 , s2)*reduced_grad_tab(s1 , s3);
	const TYPE OBMEs_product_r_grad_exc = reduced_r_tab(s1 , s2)*reduced_grad_tab(s0 , s3);

	const TYPE OBMEs_product_grad_r_dir = reduced_grad_tab(s0 , s2)*reduced_r_tab(s1 , s3);
	const TYPE OBMEs_product_grad_r_exc = reduced_grad_tab(s1 , s2)*reduced_r_tab(s0 , s3);
	
	const TYPE OBMEs_product_sum_dir = OBMEs_product_r_grad_dir - OBMEs_product_grad_r_dir;
	const TYPE OBMEs_product_sum_exc = OBMEs_product_r_grad_exc - OBMEs_product_grad_r_exc;

	const TYPE TBME_numerical = angular_TBME_dir*OBMEs_product_sum_dir - angular_TBME_exc*OBMEs_product_sum_exc;
	
	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));
	
	return TBME;
      }

    case LMINUS:
      { 
	const TYPE OBMEs_product_r_grad_dir = reduced_r_tab(s0 , s2)*reduced_grad_tab(s1 , s3);
	const TYPE OBMEs_product_r_grad_exc = reduced_r_tab(s1 , s2)*reduced_grad_tab(s0 , s3);
	
	const TYPE OBMEs_product_grad_r_dir = reduced_grad_tab(s0 , s2)*reduced_r_tab(s1 , s3);
	const TYPE OBMEs_product_grad_r_exc = reduced_grad_tab(s1 , s2)*reduced_r_tab(s0 , s3);
	
	const TYPE OBMEs_product_sum_dir = OBMEs_product_r_grad_dir - OBMEs_product_grad_r_dir;
	const TYPE OBMEs_product_sum_exc = OBMEs_product_r_grad_exc - OBMEs_product_grad_r_exc;

	const TYPE TBME_numerical = angular_TBME_dir*OBMEs_product_sum_dir - angular_TBME_exc*OBMEs_product_sum_exc;
	
	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));
	
	return TBME;
      }

    case LZ:
      { 
	const TYPE OBMEs_product_r_grad_dir = reduced_r_tab(s0 , s2)*reduced_grad_tab(s1 , s3);
	const TYPE OBMEs_product_r_grad_exc = reduced_r_tab(s1 , s2)*reduced_grad_tab(s0 , s3);

	const TYPE OBMEs_product_grad_r_dir = reduced_grad_tab(s0 , s2)*reduced_r_tab(s1 , s3);
	const TYPE OBMEs_product_grad_r_exc = reduced_grad_tab(s1 , s2)*reduced_r_tab(s0 , s3);
	
	const TYPE OBMEs_product_sum_dir = OBMEs_product_r_grad_dir - OBMEs_product_grad_r_dir;
	const TYPE OBMEs_product_sum_exc = OBMEs_product_r_grad_exc - OBMEs_product_grad_r_exc;

	const TYPE TBME_numerical = angular_TBME_dir*OBMEs_product_sum_dir - angular_TBME_exc*OBMEs_product_sum_exc;
	
	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));
	
	return TBME;
      }

    case RMS_RADIUS_PROTON: 
      {
	const TYPE OBMEs_product_dir = reduced_r_tab(s0 , s2)*reduced_r_tab(s1 , s3);
	const TYPE OBMEs_product_exc = reduced_r_tab(s1 , s2)*reduced_r_tab(s0 , s3);
	
	const int sign = (particle == PROTON) ? (-1) : (1);

	const TYPE TBME_numerical = sign*(angular_TBME_dir*OBMEs_product_dir - angular_TBME_exc*OBMEs_product_exc);

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));
	
	return TBME;
      }

    case RMS_RADIUS_NEUTRON:
      {
	const TYPE OBMEs_product_dir = reduced_r_tab(s0 , s2)*reduced_r_tab(s1 , s3);
	const TYPE OBMEs_product_exc = reduced_r_tab(s1 , s2)*reduced_r_tab(s0 , s3);
	
	const int sign = (particle == NEUTRON) ? (-1) : (1);

	const TYPE TBME_numerical = sign*(angular_TBME_dir*OBMEs_product_dir - angular_TBME_exc*OBMEs_product_exc);

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));
	
	return TBME;
      }

    case RMS_RADIUS_LAMBDA:
      {
	const TYPE OBMEs_product_dir = reduced_r_tab(s0 , s2)*reduced_r_tab(s1 , s3);
	const TYPE OBMEs_product_exc = reduced_r_tab(s1 , s2)*reduced_r_tab(s0 , s3);
	
	const int sign = (particle == LAMBDA) ? (-1) : (1);

	const TYPE TBME_numerical = sign*(angular_TBME_dir*OBMEs_product_dir - angular_TBME_exc*OBMEs_product_exc);

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));
	
	return TBME;
      }

    case RMS_RADIUS_SIGMA_PLUS:
      {
	const TYPE OBMEs_product_dir = reduced_r_tab(s0 , s2)*reduced_r_tab(s1 , s3);
	const TYPE OBMEs_product_exc = reduced_r_tab(s1 , s2)*reduced_r_tab(s0 , s3);
	
	const int sign = (particle == SIGMA_PLUS) ? (-1) : (1);

	const TYPE TBME_numerical = sign*(angular_TBME_dir*OBMEs_product_dir - angular_TBME_exc*OBMEs_product_exc);

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));
	
	return TBME;
      }

    case RMS_RADIUS_SIGMA_ZERO:
      {
	const TYPE OBMEs_product_dir = reduced_r_tab(s0 , s2)*reduced_r_tab(s1 , s3);
	const TYPE OBMEs_product_exc = reduced_r_tab(s1 , s2)*reduced_r_tab(s0 , s3);
	
	const int sign = (particle == SIGMA_ZERO) ? (-1) : (1);

	const TYPE TBME_numerical = sign*(angular_TBME_dir*OBMEs_product_dir - angular_TBME_exc*OBMEs_product_exc);

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));
	
	return TBME;
      }

    case RMS_RADIUS_SIGMA_MINUS:
      {
	const TYPE OBMEs_product_dir = reduced_r_tab(s0 , s2)*reduced_r_tab(s1 , s3);
	const TYPE OBMEs_product_exc = reduced_r_tab(s1 , s2)*reduced_r_tab(s0 , s3);
	
	const int sign = (particle == SIGMA_MINUS) ? (-1) : (1);

	const TYPE TBME_numerical = sign*(angular_TBME_dir*OBMEs_product_dir - angular_TBME_exc*OBMEs_product_exc);

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));
	
	return TBME;
      }

    case RMS_RADIUS_XI_ZERO:
      {
	const TYPE OBMEs_product_dir = reduced_r_tab(s0 , s2)*reduced_r_tab(s1 , s3);
	const TYPE OBMEs_product_exc = reduced_r_tab(s1 , s2)*reduced_r_tab(s0 , s3);
	
	const int sign = (particle == XI_ZERO) ? (-1) : (1);

	const TYPE TBME_numerical = sign*(angular_TBME_dir*OBMEs_product_dir - angular_TBME_exc*OBMEs_product_exc);

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));
	
	return TBME;
      }

    case RMS_RADIUS_XI_MINUS:
      {
	const TYPE OBMEs_product_dir = reduced_r_tab(s0 , s2)*reduced_r_tab(s1 , s3);
	const TYPE OBMEs_product_exc = reduced_r_tab(s1 , s2)*reduced_r_tab(s0 , s3);
	
	const int sign = (particle == XI_MINUS) ? (-1) : (1);

	const TYPE TBME_numerical = sign*(angular_TBME_dir*OBMEs_product_dir - angular_TBME_exc*OBMEs_product_exc);

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));
	
	return TBME;
      }

    default: return NADA;
    } 
}

TYPE CM_OBMEs_TBMEs::TBME_pn_calc (
				   const enum operator_type CM_operator_inter ,
				   const unsigned int s0 , 
				   const unsigned int s1 , 
				   const unsigned int s2 , 
				   const unsigned int s3 , 
				   const double angular_TBME , 
				   const class array<TYPE> &reduced_grad_p_tab , 
				   const class array<TYPE> &reduced_grad_n_tab , 
				   const class array<TYPE> &reduced_r_p_tab , 
				   const class array<TYPE> &reduced_r_n_tab)
{ 
  switch (CM_operator_inter)
    {
    case CM_KINETIC: 
      {
	const TYPE OBMEs_product = -reduced_grad_p_tab(s0 , s2)*reduced_grad_n_tab(s1 , s3);

	const TYPE TBME_numerical = angular_TBME*OBMEs_product;

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));
	
	return TBME;
      }

    case HCM: 
      {
	const TYPE OBMEs_grad_product = -reduced_grad_p_tab(s0 , s2)*reduced_grad_n_tab(s1 , s3);

	const TYPE OBMEs_r_product = reduced_r_p_tab(s0 , s2)*reduced_r_n_tab(s1 , s3);

	const TYPE OBMEs_product_sum = OBMEs_grad_product + OBMEs_r_product;	

	const TYPE TBME_numerical = angular_TBME*OBMEs_product_sum;

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));

	return TBME;
      }

    case LPLUS:
      { 
	const TYPE OBMEs_product_r_grad = reduced_r_p_tab(s0 , s2)*reduced_grad_n_tab(s1 , s3);

	const TYPE OBMEs_product_grad_r = reduced_grad_p_tab(s0 , s2)*reduced_r_n_tab(s1 , s3);

	const TYPE OBMEs_product_sum = OBMEs_product_r_grad - OBMEs_product_grad_r;

	const TYPE TBME_numerical = angular_TBME*OBMEs_product_sum;

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));

	return TBME;
      }

    case LMINUS:
      { 

	const TYPE OBMEs_product_r_grad = reduced_r_p_tab(s0 , s2)*reduced_grad_n_tab(s1 , s3);

	const TYPE OBMEs_product_grad_r = reduced_grad_p_tab(s0 , s2)*reduced_r_n_tab(s1 , s3);

	const TYPE OBMEs_product_sum = OBMEs_product_r_grad - OBMEs_product_grad_r;

	const TYPE TBME_numerical = angular_TBME*OBMEs_product_sum;

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));

	return TBME;
      }

    case LZ:
      { 
	const TYPE OBMEs_product_r_grad = reduced_r_p_tab(s0 , s2)*reduced_grad_n_tab(s1 , s3);

	const TYPE OBMEs_product_grad_r = reduced_grad_p_tab(s0 , s2)*reduced_r_n_tab(s1 , s3);

	const TYPE OBMEs_product_sum = OBMEs_product_r_grad - OBMEs_product_grad_r;

	const TYPE TBME_numerical = angular_TBME*OBMEs_product_sum;

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));

	return TBME;
      }

    case RMS_RADIUS_PROTON: 
      {
	const TYPE OBMEs_product = reduced_r_p_tab(s0 , s2)*reduced_r_n_tab(s1 , s3);

	const TYPE TBME_numerical = angular_TBME*OBMEs_product;

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));

	return TBME;
      }

    case RMS_RADIUS_NEUTRON:
      {	
	const TYPE OBMEs_product = reduced_r_p_tab(s0 , s2)*reduced_r_n_tab(s1 , s3);

	const TYPE TBME_numerical = angular_TBME*OBMEs_product;

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));

	return TBME;
      }
      
    case RMS_RADIUS_LAMBDA:
      {	
	const TYPE OBMEs_product = reduced_r_p_tab(s0 , s2)*reduced_r_n_tab(s1 , s3);

	const TYPE TBME_numerical = angular_TBME*OBMEs_product;

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));

	return TBME;
      }
      
    case RMS_RADIUS_SIGMA_PLUS:
      {	
	const TYPE OBMEs_product = reduced_r_p_tab(s0 , s2)*reduced_r_n_tab(s1 , s3);

	const TYPE TBME_numerical = angular_TBME*OBMEs_product;

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));

	return TBME;
      }

    case RMS_RADIUS_SIGMA_ZERO:
      {	
	const TYPE OBMEs_product = reduced_r_p_tab(s0 , s2)*reduced_r_n_tab(s1 , s3);

	const TYPE TBME_numerical = angular_TBME*OBMEs_product;

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));

	return TBME;
      }

    case RMS_RADIUS_SIGMA_MINUS:
      {	
	const TYPE OBMEs_product = reduced_r_p_tab(s0 , s2)*reduced_r_n_tab(s1 , s3);

	const TYPE TBME_numerical = angular_TBME*OBMEs_product;

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));

	return TBME;
      }

    case RMS_RADIUS_XI_ZERO:
      {	
	const TYPE OBMEs_product = reduced_r_p_tab(s0 , s2)*reduced_r_n_tab(s1 , s3);

	const TYPE TBME_numerical = angular_TBME*OBMEs_product;

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));

	return TBME;
      }

    case RMS_RADIUS_XI_MINUS:
      {	
	const TYPE OBMEs_product = reduced_r_p_tab(s0 , s2)*reduced_r_n_tab(s1 , s3);

	const TYPE TBME_numerical = angular_TBME*OBMEs_product;

	const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));

	return TBME;
      }

    default: return NADA;
    } 
}

TYPE CM_OBMEs_TBMEs::uncoupled_TBME_pp_nn_calc (
						const enum operator_type CM_operator_inter ,
						const bool is_it_HO_expansion ,
						const class baryons_data &data ,
						const class CM_TBMEs_angular_table_str &TBMEs_angular_table ,
						const unsigned int s0 , 
						const unsigned int s1 , 
						const unsigned int s2 , 
						const unsigned int s3)
{     
  const class array<class nljm_struct> &phi_table = data.get_phi_table ();
  
  const class nljm_struct &phi0 = phi_table(s0) , &phi1 = phi_table(s1);
  const class nljm_struct &phi2 = phi_table(s2) , &phi3 = phi_table(s3);

  const enum particle_type particle = phi0.get_particle ();
  
  const int ij0 = phi0.get_ij () , ij1 = phi1.get_ij ();
  const int ij2 = phi2.get_ij () , ij3 = phi3.get_ij ();
  
  const int im0 = phi0.get_im () , im1 = phi1.get_im ();
  const int im2 = phi2.get_im () , im3 = phi3.get_im ();
  
  const double angular_TBME_dir = TBMEs_angular_table(ij0 , im0 , ij1 , im1 , ij2 , im2 , ij3 , im3);
  const double angular_TBME_exc = TBMEs_angular_table(ij1 , im1 , ij0 , im0 , ij2 , im2 , ij3 , im3);
     
  const unsigned int shell_s0_index = phi0.get_shell_index () , shell_s1_index = phi1.get_shell_index ();
  const unsigned int shell_s2_index = phi2.get_shell_index () , shell_s3_index = phi3.get_shell_index ();

  const class array<TYPE> &reduced_grad_tab = reduced_grad_tab_determine (CM_operator_inter , is_it_HO_expansion , data);
  
  const class array<TYPE> &reduced_r_tab = reduced_r_tab_determine (CM_operator_inter , is_it_HO_expansion , data);
      
  const TYPE TBME_pp_nn = TBME_pp_nn_calc (CM_operator_inter , particle , shell_s0_index , shell_s1_index , shell_s2_index , shell_s3_index , angular_TBME_dir , angular_TBME_exc , reduced_grad_tab , reduced_r_tab);

  return TBME_pp_nn;
}

TYPE CM_OBMEs_TBMEs::uncoupled_TBME_pn_calc (
					     const enum operator_type CM_operator_inter ,
					     const bool is_it_HO_expansion ,
					     const class baryons_data &prot_Y_data ,
					     const class baryons_data &neut_Y_data ,
					     const class CM_TBMEs_angular_table_str &TBMEs_angular_table ,
					     const unsigned int s0 , 
					     const unsigned int s1 , 
					     const unsigned int s2 , 
					     const unsigned int s3)
{
  const class array<class nljm_struct> &phi_table_p = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_table_n = neut_Y_data.get_phi_table ();

  const class nljm_struct &phi0 = phi_table_p(s0) , &phi1 = phi_table_n(s1);
  const class nljm_struct &phi2 = phi_table_p(s2) , &phi3 = phi_table_n(s3);

  const int ij0 = phi0.get_ij () , ij1 = phi1.get_ij ();
  const int ij2 = phi2.get_ij () , ij3 = phi3.get_ij ();
  
  const int im0 = phi0.get_im () , im1 = phi1.get_im ();
  const int im2 = phi2.get_im () , im3 = phi3.get_im ();

  const double angular_TBME = TBMEs_angular_table(ij0 , im0 , ij1 , im1 , ij2 , im2 , ij3 , im3);

  const bool is_it_rms_radius = is_it_rms_radius_determine (CM_operator_inter);
  
  const unsigned int shell_s0_index = phi0.get_shell_index () , shell_s1_index = phi1.get_shell_index ();
  const unsigned int shell_s2_index = phi2.get_shell_index () , shell_s3_index = phi3.get_shell_index ();

  const class array<TYPE> &reduced_grad_tab_p = reduced_grad_tab_determine (CM_operator_inter , is_it_HO_expansion , prot_Y_data);
  const class array<TYPE> &reduced_grad_tab_n = reduced_grad_tab_determine (CM_operator_inter , is_it_HO_expansion , neut_Y_data);

  const class array<TYPE> &reduced_r_tab_p = (is_it_rms_radius) ? (reduced_r_tab_rms_radius_pn_determine (CM_operator_inter , is_it_HO_expansion , prot_Y_data)) : (reduced_r_tab_determine (CM_operator_inter , is_it_HO_expansion , prot_Y_data));
  const class array<TYPE> &reduced_r_tab_n = (is_it_rms_radius) ? (reduced_r_tab_rms_radius_pn_determine (CM_operator_inter , is_it_HO_expansion , neut_Y_data)) : (reduced_r_tab_determine (CM_operator_inter , is_it_HO_expansion , neut_Y_data));

  const TYPE TBME_pn = TBME_pn_calc (CM_operator_inter , shell_s0_index , shell_s1_index , shell_s2_index , shell_s3_index , angular_TBME , reduced_grad_tab_p , reduced_grad_tab_n , reduced_r_tab_p , reduced_r_tab_n);

  return TBME_pn;
}

TYPE CM_OBMEs_TBMEs::coupled_TBME_pp_nn_calc (
					      const enum operator_type CM_operator_inter ,
					      const bool is_it_HO_expansion ,
					      const class baryons_data &data ,
					      const class CM_TBMEs_angular_table_str &TBMEs_angular_table ,
					      const unsigned int s0 , 
					      const unsigned int s1 , 
					      const unsigned int s2 , 
					      const unsigned int s3)
{  
  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
    
  const int J = TBMEs_angular_table.get_J ();
		      
  const class nlj_struct &wf0 = shells_qn(s0) , &wf1 = shells_qn(s1);
  const class nlj_struct &wf2 = shells_qn(s2) , &wf3 = shells_qn(s3);
  
  const enum particle_type particle = wf0.get_particle ();
  
  const int ij0 = wf0.get_ij () , ij1 = wf1.get_ij ();
  const int ij2 = wf2.get_ij () , ij3 = wf3.get_ij ();
  
  const double phase = minus_one_pow (ij0 + ij1 + 1 - J);

  const double antisymmetry_inv_norm_in  = (s0 == s1) ? (M_SQRT1_2) : (1.0);
  const double antisymmetry_inv_norm_out = (s2 == s3) ? (M_SQRT1_2) : (1.0);

  const double antisymmetry_inv_norm = antisymmetry_inv_norm_in*antisymmetry_inv_norm_out;

  const double angular_TBME_dir = TBMEs_angular_table(ij0 , ij1 , ij2 , ij3);

  const double angular_TBME_exc = (phase == 1) ? (TBMEs_angular_table(ij1 , ij0 , ij2 , ij3)) : (-TBMEs_angular_table(ij1 , ij0 , ij2 , ij3));
     
  const class array<TYPE> &reduced_grad_tab = reduced_grad_tab_determine (CM_operator_inter , is_it_HO_expansion , data);
  
  const class array<TYPE> &reduced_r_tab = reduced_r_tab_determine (CM_operator_inter , is_it_HO_expansion , data);

  const TYPE TBME_pp_nn_not_normalized = TBME_pp_nn_calc (CM_operator_inter , particle , s0 , s1 , s2 , s3 , angular_TBME_dir , angular_TBME_exc , reduced_grad_tab , reduced_r_tab);

  const TYPE TBME_pp_nn = antisymmetry_inv_norm*TBME_pp_nn_not_normalized;
      
  return TBME_pp_nn;
}

TYPE CM_OBMEs_TBMEs::coupled_TBME_pn_calc (
					   const enum operator_type CM_operator_inter ,
					   const bool is_it_HO_expansion ,
					   const class baryons_data &prot_Y_data ,
					   const class baryons_data &neut_Y_data ,
					   const class CM_TBMEs_angular_table_str &TBMEs_angular_table ,
					   const unsigned int s0 , 
					   const unsigned int s1 , 
					   const unsigned int s2 , 
					   const unsigned int s3)
{
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();
    
  const class nlj_struct &wf0 = shells_qn_p(s0) , &wf1 = shells_qn_n(s1);
  const class nlj_struct &wf2 = shells_qn_p(s2) , &wf3 = shells_qn_n(s3);

  const int ij0 = wf0.get_ij () , ij1 = wf1.get_ij ();
  const int ij2 = wf2.get_ij () , ij3 = wf3.get_ij ();

  const double angular_TBME = TBMEs_angular_table(ij0 , ij1 , ij2 , ij3);

  const bool is_it_rms_radius = is_it_rms_radius_determine (CM_operator_inter);
  
  const class array<TYPE> &reduced_grad_tab_p = reduced_grad_tab_determine (CM_operator_inter , is_it_HO_expansion , prot_Y_data);
  const class array<TYPE> &reduced_grad_tab_n = reduced_grad_tab_determine (CM_operator_inter , is_it_HO_expansion , neut_Y_data);

  const class array<TYPE> &reduced_r_tab_p = (is_it_rms_radius) ? (reduced_r_tab_rms_radius_pn_determine (CM_operator_inter , is_it_HO_expansion , prot_Y_data)) : (reduced_r_tab_determine (CM_operator_inter , is_it_HO_expansion , prot_Y_data));
  const class array<TYPE> &reduced_r_tab_n = (is_it_rms_radius) ? (reduced_r_tab_rms_radius_pn_determine (CM_operator_inter , is_it_HO_expansion , neut_Y_data)) : (reduced_r_tab_determine (CM_operator_inter , is_it_HO_expansion , neut_Y_data));

  const TYPE TBME_pn = TBME_pn_calc (CM_operator_inter , s0 , s1 , s2 , s3 , angular_TBME , reduced_grad_tab_p , reduced_grad_tab_n , reduced_r_tab_p , reduced_r_tab_n);

  return TBME_pn;
}


