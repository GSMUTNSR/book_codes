#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Array class type to store an array of class SD_HO_Berggren_overlaps_data_str
// ----------------------------------------------------------------------------
// One stores in SD_HO_Berggren_overlaps_data_str the overlap <SD | SD_HO> of Slater determinants in Berggren and HO basis, where the Slater determinant in Berggren basis is known, which fixed M and parity of SD_HO,
// and one stores the number of particle in the scattering-like continuum, index of configuration and Slater determinant in HO basis.
// This class only contains a few data so that one can store an array of it without problems.
//
// In this array class type, one uniquely stores the existing class SD_HO_Berggren_overlaps_data_str by knowing their number for each SD_HO_Berggren_overlaps_data_str and summing dimensions.
// One adds "_c" to input variables in constructors and allocators if they copied to class members afterwards.
//
// The sum of dimensions is taken as a pointer to the same table stored in baryons_data, which is fixed.
// Hence, this class cannot be used without baryons_data, which is impossible in practice.
// Hence, using a pointer to another table is a sound procedure here.
//
// The internal index of the table storing all classes SD_HO_Berggren_overlaps_data_str is a one-dimensional index ,
// calculated from the local index SD_index, where SD_HO_Berggren_overlaps_data_str quantum numbers are fixed, to which a sum of dimensions is added.
// This is done in index_determine.
//
// One can access the table with operator (), where one puts all configuration quantum numbers and the local index SD_index,
// or with operator [], where one puts directly the internal one-dimensional index of the stored array.
//
// The used memory of the class (in Mb) can be calculated in used_memory_calc.



SD_HO_Berggren_overlaps_data_str::SD_HO_Berggren_overlaps_data_str () :
  n_scat_HO (0) , 
  iC_HO (0) , 
  SD_HO_index (0) ,  
  SD_HO_Berggren_overlap (0.0)
{} 



SD_HO_Berggren_overlaps_data_str::SD_HO_Berggren_overlaps_data_str (
								    const unsigned int n_scat_HO_c , 
								    const unsigned int iC_HO_c , 
								    const unsigned int SD_HO_index_c , 
								    const TYPE &SD_HO_Berggren_overlap_c)
{
  initialize (n_scat_HO_c , iC_HO_c , SD_HO_index_c , SD_HO_Berggren_overlap_c);
}

void SD_HO_Berggren_overlaps_data_str::initialize (
						   const unsigned int n_scat_HO_c , 
						   const unsigned int iC_HO_c , 
						   const unsigned int SD_HO_index_c , 
						   const TYPE &SD_HO_Berggren_overlap_c)
{
  n_scat_HO = n_scat_HO_c;  

  iC_HO = iC_HO_c; 

  SD_HO_index = SD_HO_index_c;  

  SD_HO_Berggren_overlap = SD_HO_Berggren_overlap_c;
}

void SD_HO_Berggren_overlaps_data_str::initialize (const class SD_HO_Berggren_overlaps_data_str &X)
{
  n_scat_HO = X.n_scat_HO;  

  iC_HO = X.iC_HO; 

  SD_HO_index = X.SD_HO_index;  

  SD_HO_Berggren_overlap = X.SD_HO_Berggren_overlap;
}

void SD_HO_Berggren_overlaps_data_str::allocate_fill (const class SD_HO_Berggren_overlaps_data_str &X)
{
  initialize (X);
}
    
double used_memory_calc (const class SD_HO_Berggren_overlaps_data_str &T)
{
  return (sizeof (T)/1000000.0); 
}


array_of_SD_HO_Berggren_overlaps_data_str::array_of_SD_HO_Berggren_overlaps_data_str () {}
  
array_of_SD_HO_Berggren_overlaps_data_str::array_of_SD_HO_Berggren_overlaps_data_str (
										      const unsigned int strangeness_max , 
										      const unsigned int n_spec_max , 
										      const unsigned int n_scat_max , 
										      const class array<unsigned int> &dimensions_configuration_set , 
										      const unsigned int iM_max , 
										      const unsigned long int dimension_SD_total , 
										      const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set , 
										      const class array_BP_S_Nspec_Nscat_iC<unsigned long int> &sum_dimensions_SD_set , 
										      const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_HO_Berggren_overlaps_table)
{
  allocate (strangeness_max , n_spec_max , n_scat_max , dimensions_configuration_set , iM_max , dimension_SD_total , dimensions_SD_set , sum_dimensions_SD_set , dimensions_SD_HO_Berggren_overlaps_table);
}

array_of_SD_HO_Berggren_overlaps_data_str::array_of_SD_HO_Berggren_overlaps_data_str (const class array_of_SD_HO_Berggren_overlaps_data_str &X)
{
  allocate_fill (X);
}

void array_of_SD_HO_Berggren_overlaps_data_str::allocate (
							  const unsigned int strangeness_max , 
							  const unsigned int n_spec_max , 
							  const unsigned int n_scat_max , 
							  const class array<unsigned int> &dimensions_configuration_set , 
							  const unsigned int iM_max , 
							  const unsigned long int dimension_SD_total , 
							  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set , 
							  const class array_BP_S_Nspec_Nscat_iC<unsigned long int> &sum_dimensions_SD_set , 
							  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_HO_Berggren_overlaps_table)
{
  sum_dimensions_tab.allocate (dimension_SD_total , sum_dimensions_SD_set);

  unsigned int dimension_table = 0;

  unsigned int sum_dimensions_bef = 0;

  unsigned int dimension_bef = 0;

  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (unsigned int S = 0 ; S <= strangeness_max ; S++)
      for (unsigned int n_spec = 0 ; n_spec <= n_spec_max ; n_spec++)
	for (unsigned int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
	  {
	    const unsigned int dimensions_configuration_set_BP_S_n_scat = dimensions_configuration_set(BP , S , n_spec , n_scat);

	    for (unsigned int iC = 0 ; iC < dimensions_configuration_set_BP_S_n_scat ; iC++)
	      {	
		const unsigned int dimension_SD_set_zero_index = dimensions_SD_set.index_determine (BP , S , n_spec , n_scat , iC , 0);

		for (unsigned int iM = 0 ; iM <= iM_max ; iM++)
		  {
		    const unsigned int dimension_SD_set_index = dimension_SD_set_zero_index + iM;

		    const unsigned int dimension_SD_set_BP_S_n_scat_iC_iM = dimensions_SD_set[dimension_SD_set_index];

		    const unsigned int dimensions_SD_HO_Berggren_overlap_debut_index = dimensions_SD_HO_Berggren_overlaps_table.index_determine (BP , S , n_spec , n_scat , iC , iM , 0);

		    const unsigned int sum_dimensions_debut_index = sum_dimensions_tab.index_determine (BP , S , n_spec , n_scat , iC , iM , 0);

		    for (unsigned int iSD = 0 ; iSD < dimension_SD_set_BP_S_n_scat_iC_iM ; iSD++)
		      {
			const unsigned int dimensions_SD_HO_Berggren_overlap_index = dimensions_SD_HO_Berggren_overlap_debut_index + iSD ;

			const unsigned int sum_dimensions_index = sum_dimensions_debut_index + iSD;

			const unsigned int dimension = dimensions_SD_HO_Berggren_overlaps_table[dimensions_SD_HO_Berggren_overlap_index];

			unsigned int &sum_dimensions = sum_dimensions_tab[sum_dimensions_index];

			dimension_table += dimension;

			sum_dimensions= sum_dimensions_bef + dimension_bef;

			dimension_bef = dimension;

			sum_dimensions_bef = sum_dimensions;
		      }
		  }
	      }
	  }

  table.allocate (dimension_table);
}






void array_of_SD_HO_Berggren_overlaps_data_str::allocate_fill (const class array_of_SD_HO_Berggren_overlaps_data_str &X)
{
  sum_dimensions_tab.allocate_fill (X.sum_dimensions_tab);

  table.allocate_fill (X.table);
}





void array_of_SD_HO_Berggren_overlaps_data_str::deallocate ()
{
  sum_dimensions_tab.deallocate ();

  table.deallocate ();
}

bool array_of_SD_HO_Berggren_overlaps_data_str::is_it_filled () const
{
  return table.is_it_filled ();
}


unsigned int array_of_SD_HO_Berggren_overlaps_data_str::index_determine (
									 const unsigned int BP , 
									 const unsigned int S , 
									 const unsigned int n_spec , 
									 const unsigned int n_scat , 
									 const unsigned int iC , 
									 const unsigned int iM , 
									 const unsigned int SD_index , 
									 const unsigned int SD_HO_Berggren_overlap_index) const
{
  const unsigned int index = SD_HO_Berggren_overlap_index + sum_dimensions_tab(BP , S , n_spec , n_scat , iC , iM , SD_index);

  return index;
}





class SD_HO_Berggren_overlaps_data_str & array_of_SD_HO_Berggren_overlaps_data_str::operator () (
												 const unsigned int BP , 
												 const unsigned int S , 	
												 const unsigned int n_spec ,
												 const unsigned int n_scat , 
												 const unsigned int iC , 
												 const unsigned int iM , 
												 const unsigned int SD_index , 
												 const unsigned int SD_HO_Berggren_overlap_index) const
{							 
  const unsigned int index = index_determine (BP , S , n_spec , n_scat , iC , iM , SD_index , SD_HO_Berggren_overlap_index);

  return table(index);
}



class SD_HO_Berggren_overlaps_data_str & array_of_SD_HO_Berggren_overlaps_data_str::operator [] (const unsigned int index) const
{
  return table(index);
}

double used_memory_calc (const class array_of_SD_HO_Berggren_overlaps_data_str &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.sum_dimensions_tab) + used_memory_calc (T.table) - (sizeof (T.sum_dimensions_tab) + sizeof (T.table))/1000000.0);
}



