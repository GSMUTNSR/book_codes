#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Class jumps_data_outSD_str storing quantum numbers and phases issued from a one-body jump a+_{alpha} a_{beta} or two-body jump a+_{alpha} a+_{beta} a_{delta} a_{gamma} on a Slater determinant inSD to generate outSD.
// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Class jumps_data_outSD_str stores information related to the SD outSD obtained after the action of a one-body jump a+_{alpha} a_{beta} or two-body jump a+_{alpha} a+_{beta} a_{alpha} a_{beta} on a Slater determinant inSD.
// It contains the number of particles in the continuum of outSD, its configuration index iC depending, its SD index, outSD_index
// the binary phase induced by the creation/annihilation operators, a boolean to check if the configuration of outSD is changing compared to the previous element in the array,
// the changing one-body states indices: alpha is right_out and beta is right_in for a one-body jump, (alpha,beta) are (left_out,right_out) and (gamma,delta) are (left_in,right_in) for a two-body jump,
// and the truncation energy of outSD.

jumps_data_outSD_str::jumps_data_outSD_str () :
  n_holes (0) , 
  n_scat (0) , 
  iC (0) , 
  outSD_index (0) , 
  total_bin_phase (0) , 
  is_configuration_changing (false) ,
  left_in (0) ,
  right_in (0) ,
  left_out (0) ,
  right_out (0) ,
  E_hw (0) 
{}

jumps_data_outSD_str::jumps_data_outSD_str (
					    const unsigned char n_holes_c , 
					    const unsigned char n_scat_c , 
					    const unsigned int iC_c , 
					    const unsigned int outSD_index_c , 
					    const unsigned char total_bin_phase_c , 
					    const bool is_configuration_changing_c ,
					    const unsigned short int left_in_c , 
					    const unsigned short int right_in_c ,
					    const unsigned short int left_out_c , 
					    const unsigned short int right_out_c ,  
					    const unsigned short int E_hw_c)
{
  initialize (n_holes_c , n_scat_c , iC_c , outSD_index_c , total_bin_phase_c , is_configuration_changing_c , left_in_c , right_in_c , left_out_c , right_out_c , E_hw_c);
}

jumps_data_outSD_str::jumps_data_outSD_str (
					    const unsigned char n_holes_c , 
					    const unsigned char n_scat_c , 
					    const unsigned int iC_c , 
					    const unsigned int outSD_index_c , 
					    const unsigned char total_bin_phase_c , 
					    const bool is_configuration_changing_c , 
					    const unsigned short int mu_in_c , 
					    const unsigned short int mu_out_c , 
					    const unsigned short int E_hw_c)
{
  initialize (n_holes_c , n_scat_c , iC_c , outSD_index_c , total_bin_phase_c , is_configuration_changing_c , mu_in_c , mu_out_c , E_hw_c);
}

jumps_data_outSD_str::jumps_data_outSD_str (
					    const unsigned int outSD_index_c , 
					    const unsigned char total_bin_phase_c , 
					    const bool is_configuration_changing_c , 
					    const unsigned short int mu_in_c , 
					    const unsigned short int mu_out_c)
{
  initialize (outSD_index_c , total_bin_phase_c , is_configuration_changing_c , mu_in_c , mu_out_c);
}

void jumps_data_outSD_str::initialize (
				       const unsigned char n_holes_c , 
				       const unsigned char n_scat_c , 
				       const unsigned int iC_c , 
				       const unsigned int outSD_index_c , 
				       const unsigned char total_bin_phase_c , 
				       const bool is_configuration_changing_c , 
				       const unsigned short int left_in_c , 
				       const unsigned short int right_in_c , 
				       const unsigned short int left_out_c , 
				       const unsigned short int right_out_c , 
				       const unsigned short int E_hw_c)
{
  n_holes = n_holes_c;
  
  n_scat = n_scat_c; 

  iC = iC_c; 

  outSD_index = outSD_index_c; 

  total_bin_phase = total_bin_phase_c; 

  is_configuration_changing = is_configuration_changing_c; 

  left_in = left_in_c; 

  right_in = right_in_c;

  left_out = left_out_c; 


  right_out = right_out_c;  

  E_hw = E_hw_c;
}


void jumps_data_outSD_str::initialize (
				       const unsigned char n_holes_c , 
				       const unsigned char n_scat_c , 
				       const unsigned int iC_c , 
				       const unsigned int outSD_index_c , 
				       const unsigned char total_bin_phase_c , 
				       const bool is_configuration_changing_c , 
				       const unsigned short int mu_in_c , 
				       const unsigned short int mu_out_c , 
				       const unsigned short int E_hw_c)
{
  n_holes = n_holes_c;
  
  n_scat = n_scat_c; 

  iC = iC_c; 

  outSD_index = outSD_index_c; 

  total_bin_phase = total_bin_phase_c; 

  is_configuration_changing = is_configuration_changing_c; 

  right_in = mu_in_c;

  right_out = mu_out_c;  

  E_hw = E_hw_c;
}


void jumps_data_outSD_str::initialize (
				       const unsigned int outSD_index_c , 
				       const unsigned char total_bin_phase_c , 
				       const bool is_configuration_changing_c , 
				       const unsigned short int mu_in_c , 
				       const unsigned short int mu_out_c)
{
  outSD_index = outSD_index_c; 

  total_bin_phase = total_bin_phase_c; 

  is_configuration_changing = is_configuration_changing_c; 

  right_in = mu_in_c;

  right_out = mu_out_c;  
}



double used_memory_calc (const class jumps_data_outSD_str &T)
{
  return (sizeof (T)/1000000.0);
}

bool operator == (
		  const class jumps_data_outSD_str &T1 , 
		  const class jumps_data_outSD_str &T2)
{
  if ((T1.get_n_holes () != T2.get_n_holes ()) || (T1.get_n_scat () != T2.get_n_scat ()) || (T1.get_iC () != T2.get_iC ())) return false;

  return true;  
}

bool operator != (
		  const class jumps_data_outSD_str &T1 , 
		  const class jumps_data_outSD_str &T2)
{
  return (!(T1 == T2));
}

bool operator > (
		 const class jumps_data_outSD_str &T1 , 
		 const class jumps_data_outSD_str &T2)
{
  if (T1.get_n_holes () > T2.get_n_holes ()) return true;

  if ((T1.get_n_holes () == T2.get_n_holes ()) && (T1.get_n_scat () > T2.get_n_scat ())) return true;

  if ((T1.get_n_holes () == T2.get_n_holes ()) && (T1.get_n_scat () == T2.get_n_scat ()) && (T1.get_iC () > T2.get_iC ())) return true;
  
  return false;
}

bool operator >= (
		  const class jumps_data_outSD_str &T1 , 
		  const class jumps_data_outSD_str &T2)
{
  return ((T1 > T2) || (T1 == T2));
}

bool operator < (
		 const class jumps_data_outSD_str &T1 , 
		 const class jumps_data_outSD_str &T2)
{
  return (T2 > T1);
}

bool operator <= (
		  const class jumps_data_outSD_str &T1 , 
		  const class jumps_data_outSD_str &T2)
{
  return ((T2 > T1) || (T1 == T2));
}
