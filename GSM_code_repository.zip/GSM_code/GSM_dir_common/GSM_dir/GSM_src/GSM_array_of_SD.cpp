#include "../GSM_include/GSM_include_def_common.h"


// TYPE is double or complex
// -------------------------

// Array class type to store an array of class Slater_determinant
// ---------------------------------------------------------
// In this array class type, one uniquely stores the existing class Slater_determinant by knowing their number for each Slater_determinant and summing dimensions.
// One adds "_c" to input variables in constructors and allocators if they copied to class members afterwards.
//
// One allocates a table of integers "table", containing the occupied states in each Slater_determinant.
// Its dimension is the product of the total number of Slater_determinants times the number of valence particles
//
// The sum of dimensions is taken as a pointer to the same table stored in nucleons_data, which is fixed ("sum_dimensions_SD_set_ptr" in the class).
// This class cannot be used without nucleons_data, as it is impossible in practice.
// Hence, using a pointer to another table is a sound procedure here.
//
// The internal index of the table storing all classes Slater_determinant is a one-dimensional index ,
// calculated from the local index SD_index, where Slater_determinant quantum numbers are fixed, to which a sum of dimensions is added.
// This is done in index_determine.
//
// One can access the table with operator (), where one puts all configuration quantum numbers and the local index SD_index,
// or with operator [], where one puts directly the internal one-dimensional index of the stored array.
//
// The stored table an array of integers, which are the occupied states in each Slater determinant.
// In order to obtain a class Slater_determinant, one returns a virtual Slater determinant (see virtual_Slater_determinant.cpp) with operator (), containing the array of integers and the index associated to this Slater_determinant.
// Obtaining a class Slater_determinant from a virtual Slater determinant in done in Slater_determinant.cpp .




array_of_SD::array_of_SD () :
  sum_dimensions_SD_set_ptr (NULL)
{}




array_of_SD::array_of_SD (
			  const bool is_it_one_configuration_calc , 
			  const enum particle_type particle , 
			  const unsigned long int dimension_SD_total_c , 
			  const class array_BP_Nscat_iC<unsigned long int> &sum_dimensions_SD_set , 
			  const unsigned int N_valence_nucleons_c)
{
  allocate (is_it_one_configuration_calc , particle , dimension_SD_total_c , sum_dimensions_SD_set , N_valence_nucleons_c);
}




array_of_SD::array_of_SD (const class array_of_SD &X)
{
  allocate_fill (X);
}

array_of_SD::~array_of_SD () {}


void array_of_SD::allocate (
			    const bool is_there_cout , 
			    const enum particle_type particle , 
			    const unsigned long int dimension_SD_total , 
			    const class array_BP_Nscat_iC<unsigned long int> &sum_dimensions_SD_set , 
			    const unsigned int N_valence_nucleons)
{ 
  sum_dimensions_SD_set_ptr = &sum_dimensions_SD_set;

  table.allocate (dimension_SD_total , N_valence_nucleons);

  table = OUT_OF_RANGE;
    
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << particle << " array of SD: " << used_memory_calc (*this) << " Mb" << endl << endl;
}



void array_of_SD::allocate_fill (const class array_of_SD &X)
{ 
  sum_dimensions_SD_set_ptr = X.sum_dimensions_SD_set_ptr;

  table.allocate_fill (X.table);
}




void array_of_SD::deallocate ()
{
  table.deallocate ();

  sum_dimensions_SD_set_ptr = NULL;
}

bool array_of_SD::is_it_filled () const
{
  return table.is_it_filled ();
}

unsigned long int array_of_SD::index_determine (
						const unsigned int BP , 
						const unsigned int n_scat , 
						const unsigned int iC , 
						const unsigned int iM , 
						const unsigned int SD_index) const
{
  const class array_BP_Nscat_iC<unsigned long int> &sum_dimensions_SD_set = get_sum_dimensions_SD_set ();

  const unsigned long int index = SD_index + sum_dimensions_SD_set(BP , n_scat , iC , iM);
				      
  return index;
}




class virtual_Slater_determinant array_of_SD::operator () (
							   const unsigned int BP , 
							   const unsigned int n_scat , 
							   const unsigned int iC , 
							   const unsigned int iM , 
							   const unsigned int SD_index) const
{
  const unsigned long int index = index_determine(BP , n_scat , iC , iM , SD_index);

  return virtual_Slater_determinant (table , index);
}











unsigned int array_of_SD::first_index_determine_for_MPI (
							 const unsigned int group_processes_number ,
							 const unsigned int process) const
{
  return basic_first_index_determine_for_MPI (get_dimension_SD_total () , group_processes_number , process);
}


unsigned int array_of_SD::last_index_determine_for_MPI (
							const unsigned int group_processes_number ,
							const unsigned int process) const
{
  return basic_last_index_determine_for_MPI (get_dimension_SD_total () , group_processes_number , process);
}


unsigned int array_of_SD::active_process_determine_for_MPI (
							    const unsigned int group_processes_number ,
							    const unsigned int index) const
{
  return basic_active_process_determine_for_MPI (get_dimension_SD_total () , group_processes_number , index);
}


#ifdef UseMPI

void array_of_SD::MPI_Allreduce_min (const MPI_Comm MPI_C)
{
  if (get_dimension_SD_total () == 0) return;
  if (get_N_valence_nucleons () == 0) return;
  
  table.MPI_Allreduce (MPI_MIN , MPI_C);
}


void array_of_SD::MPI_Bcast (
			     const unsigned int Send_process ,
			     const MPI_Comm MPI_C)
{
  if (get_dimension_SD_total () == 0) return;
  if (get_N_valence_nucleons () == 0) return;

  table.MPI_Bcast (Send_process , MPI_C);
}

#endif



// The pointer sum_dimensions_SD_set_ptr is not considered as it is not allocated in the class definition

double used_memory_calc (const class array_of_SD &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.table) - sizeof (T.table)/1000000.0);
}

