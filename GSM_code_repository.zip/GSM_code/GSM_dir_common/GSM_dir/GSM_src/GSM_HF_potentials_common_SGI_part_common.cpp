#include "../GSM_include/GSM_include_def_common.h"


// TYPE is double or complex
// -------------------------

// Calculation of the radial form factors entering the SGI interaction
// ---------------------------------------------------------------------
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) writes, along with its source:
//
// U_HF(dir)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . Vl'_SGI(r , 2R0-r) . u_occ^2(2R0-r)
// U_HF(exc)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ, l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) . F(r)
//
// weight is function of Clebsch-Gordan coefficients and angular momenta and come from the use of uniform filling approximation.
// coupling_constant(Pi,J) is the Pi-J-dependent coupling constant of the SGI interaction.
// Vl'_SGI(r) is the multipolar expansion of the SGI interaction (see GSM_interaction_class.cpp).
// R0 is the radius of the SGI interaction.
// 
// The radial tables Vl'_SGI(r , 2R0-r) . u_occ^2(2R0-r) for the direct part and Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) for the exchange part are calculated and stored here.

void HF_potentials_common::SGI_MSGI_part_common::SGI_part_common::radial_dir_exc_tabs_calc (
											    const class HF_nucleons_data &HF_data , 
											    const class interaction_class &inter_data_basis , 
											    class SGI_radial_tabs_str &radial_tabs)
{
  const unsigned int N_nlj_res = HF_data.get_N_nlj_res ();
  
  if (N_nlj_res == 0) return;

  const class array<class spherical_state> &shells_res = HF_data.get_shells_res ();

  const class array<double> &Vl_SGI_tab_GL = inter_data_basis.get_Vl_SGI_tab_GL ();

  const int lmax_multipole_expansion = inter_data_basis.get_lmax_multipole_expansion ();

  class array<complex<double> > &radial_dir_tab = radial_tabs.get_dir_tab ();
  class array<complex<double> > &radial_exc_tab = radial_tabs.get_exc_tab ();

  for (unsigned int s = 0 ; s < N_nlj_res ; s++)
    {
      const class spherical_state &shell_res = shells_res(s);
      
      const unsigned int N_bef_R_GL = shell_res.get_N_bef_R_GL ();

      const unsigned int N_bef_R_GL_minus_one = N_bef_R_GL - 1;

      const class array<complex<double> > &wf_bef_R_tab_GL = shell_res.get_wf_bef_R_tab_GL_SGI_MSGI ();

      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  const unsigned int i_opp = N_bef_R_GL_minus_one - i;
	  
	  const complex<double> wf_r     = wf_bef_R_tab_GL(i);
	  const complex<double> wf_r_opp = wf_bef_R_tab_GL(i_opp);

	  const complex<double> wf_r_opp_square = wf_r_opp*wf_r_opp;
	  
	  const complex<double> wf_r_wf_r_opp = wf_r*wf_r_opp;

	  for (int ll = 0 ; ll <= lmax_multipole_expansion ; ll++)
	    {
	      radial_dir_tab(ll , s , i) = wf_r_opp_square*Vl_SGI_tab_GL(ll , i);
	      radial_exc_tab(ll , s , i) = wf_r_wf_r_opp  *Vl_SGI_tab_GL(ll , i);
	    }
	}  
    }
}









// Calculation of the direct and exchange parts of the HF potential taking into account one occupied state for the proton-proton, neutron-neutron and proton-neutron parts of the interaction
// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) writes, along with its source:
//
// U_HF(dir)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . Vl'_SGI(r , 2R0-r) . u_occ^2(2R0-r)
// U_HF(exc)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ, l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) . F(r)
//
// weight is function of Clebsch-Gordan coefficients and angular momenta and come from the use of uniform filling approximation.
// coupling_constant(Pi,J) is the Pi-J-dependent coupling constant of the MSGI interaction.
// Vl'_SGI(r) is the multipolar expansion of the SGI interaction (see GSM_interaction_class.cpp).
// R0 is the radius of the SGI interaction.
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
// Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
// The ratio |u(r)|^2/|u'(r)|^2) prevents F(r) to be non zero when r -> +oo.
// Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// The real part of the equivalent HF potential is considered for the HF potential when it is complex.
// 
// Real and imaginary parts of intermediate products entering the HF potential are separated to simplify calculations.

void HF_potentials_common::SGI_MSGI_part_common::SGI_part_common::Up_dir_pp_part_calc (
										       const int J , 
										       const unsigned int sp_occ , 
										       const class spherical_state &shell_p , 
										       const class spherical_state &shell_p_occ , 
										       const class interaction_class &inter_data_basis , 
										       const complex<double> &weight , 
										       const class multipolar_expansion_str &multipolar_expansion , 
										       const class SGI_radial_tabs_str &prot_radial_tabs , 
										       class nlj_table<complex<double> > &Up_eq_SGI_tab_GL)
{
  const double jp = shell_p.get_j ();

  const double jp_occ = shell_p_occ.get_j ();

  const int np = shell_p.get_n ();
  const int lp = shell_p.get_l ();

  const int lp_occ = shell_p_occ.get_l ();

  const int lmax_multipole_expansion = min (2*lp , 2*lp_occ);

  const unsigned int N_bef_R_GL = shell_p.get_N_bef_R_GL ();
  
  class array<double> SGI_dir_table(N_bef_R_GL);

  SGI_dir_table = 0.0;

  const class array<complex<double> > &prot_radial_dir_tab = prot_radial_tabs.get_dir_tab ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (lp + lp_occ);

  const double coupling_constant = inter_data_basis.Gaussian_coupling_constant (bp , J , false , false);

  for (int ll = 0 ; ll <= lmax_multipole_expansion ; ll++)
    {
      if (ll % 2 == 0) 
	{
	  const double angular_part = multipolar_expansion(lp , jp , lp_occ , jp_occ , lp , jp , lp_occ , jp_occ , ll , J);
	  
	  const complex<double> angular_part_weight = angular_part*weight;

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) SGI_dir_table(i) += coupling_constant*real (angular_part_weight*prot_radial_dir_tab(ll , sp_occ , i));
	}
    }
  
  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) Up_eq_SGI_tab_GL(np , lp , jp , i) += SGI_dir_table(i);
}

void HF_potentials_common::SGI_MSGI_part_common::SGI_part_common::Up_dir_pn_part_calc (
										       const int J , 
										       const unsigned int sn_occ , 
										       const class spherical_state &shell_p , 
										       const class spherical_state &shell_n_occ , 
										       const class interaction_class &inter_data_basis , 
										       const complex<double> &weight , 
										       const class multipolar_expansion_str &multipolar_expansion , 
										       const class SGI_radial_tabs_str &neut_radial_tabs , 
										       class nlj_table<complex<double> > &Up_eq_SGI_tab_GL)
{
  const double jp = shell_p.get_j ();

  const double jn_occ = shell_n_occ.get_j ();

  const int np = shell_p.get_n ();
  const int lp = shell_p.get_l ();

  const int ln_occ = shell_n_occ.get_l ();

  const int lmax_multipole_expansion = min (2*lp , 2*ln_occ);

  const unsigned int N_bef_R_GL = shell_p.get_N_bef_R_GL ();
  
  class array<double> SGI_dir_table(N_bef_R_GL);

  SGI_dir_table = 0.0;

  const class array<complex<double> > &neut_radial_dir_tab = neut_radial_tabs.get_dir_tab ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (lp + ln_occ);
  
  const double coupling_constant = inter_data_basis.Gaussian_coupling_constant (bp , J , true , false);

  for (int ll = 0 ; ll <= lmax_multipole_expansion ; ll++)
    {
      if (ll % 2 == 0) 
	{
	  const double angular_part = multipolar_expansion(lp , jp , ln_occ , jn_occ , lp , jp , ln_occ , jn_occ , ll , J);
	  
	  const complex<double> angular_part_weight = angular_part*weight;

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) SGI_dir_table(i) += coupling_constant*real (angular_part_weight*neut_radial_dir_tab(ll , sn_occ , i));
	}
    }
  
  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) Up_eq_SGI_tab_GL(np , lp , jp , i) += SGI_dir_table(i);
}

void HF_potentials_common::SGI_MSGI_part_common::SGI_part_common::Un_dir_nn_part_calc (
										       const int J , 
										       const unsigned int sn_occ , 
										       const class spherical_state &shell_n , 
										       const class spherical_state &shell_n_occ , 
										       const class interaction_class &inter_data_basis , 
										       const complex<double> &weight , 
										       const class multipolar_expansion_str &multipolar_expansion , 
										       const class SGI_radial_tabs_str &neut_radial_tabs , 
										       class nlj_table<complex<double> > &Un_eq_SGI_tab_GL)
{
  const double jn = shell_n.get_j ();

  const double jn_occ = shell_n_occ.get_j ();

  const int nn = shell_n.get_n ();
  const int ln = shell_n.get_l ();

  const int ln_occ = shell_n_occ.get_l ();

  const int lmax_multipole_expansion = min (2*ln , 2*ln_occ);

  const unsigned int N_bef_R_GL = shell_n.get_N_bef_R_GL ();
  
  class array<double> SGI_dir_table(N_bef_R_GL);

  SGI_dir_table = 0.0;

  const class array<complex<double> > &neut_radial_dir_tab = neut_radial_tabs.get_dir_tab ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (ln + ln_occ);
  
  const double coupling_constant = inter_data_basis.Gaussian_coupling_constant (bp , J , false , false);

  for (int ll = 0 ; ll <= lmax_multipole_expansion ; ll++)
    {
      if (ll % 2 == 0) 
	{
	  const double angular_part = multipolar_expansion(ln , jn , ln_occ , jn_occ , ln , jn , ln_occ , jn_occ , ll , J);
	  
	  const complex<double> angular_part_weight = angular_part*weight;

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) SGI_dir_table(i) += coupling_constant*real (angular_part_weight*neut_radial_dir_tab(ll , sn_occ , i));
	}
    }
  
  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) Un_eq_SGI_tab_GL(nn , ln , jn , i) += SGI_dir_table(i);
}

void HF_potentials_common::SGI_MSGI_part_common::SGI_part_common::Un_dir_pn_part_calc (
										       const int J , 
										       const unsigned int sp_occ , 
										       const class spherical_state &shell_n , 
										       const class spherical_state &shell_p_occ , 
										       const class interaction_class &inter_data_basis , 
										       const complex<double> &weight , 
										       const class multipolar_expansion_str &multipolar_expansion , 
										       const class SGI_radial_tabs_str &prot_radial_tabs , 
										       class nlj_table<complex<double> > &Un_eq_SGI_tab_GL)
{
  const double jn = shell_n.get_j ();

  const double jp_occ = shell_p_occ.get_j ();

  const int nn = shell_n.get_n ();
  const int ln = shell_n.get_l ();

  const int lp_occ = shell_p_occ.get_l ();

  const int lmax_multipole_expansion = min (2*ln , 2*lp_occ);

  const unsigned int N_bef_R_GL = shell_n.get_N_bef_R_GL ();
  
  class array<double> SGI_dir_table(N_bef_R_GL);

  SGI_dir_table = 0.0;

  const class array<complex<double> > &prot_radial_dir_tab = prot_radial_tabs.get_dir_tab ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (ln + lp_occ);
  
  const double coupling_constant = inter_data_basis.Gaussian_coupling_constant (bp , J , true , false);

  for (int ll = 0 ; ll <= lmax_multipole_expansion ; ll++)
    {
      if (ll % 2 == 0) 
	{
	  const double angular_part = multipolar_expansion(ln , jn , lp_occ , jp_occ , ln , jn , lp_occ , jp_occ , ll , J);
	  
	  const complex<double> angular_part_weight = angular_part*weight;

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) SGI_dir_table(i) += coupling_constant*real (angular_part_weight*prot_radial_dir_tab(ll , sp_occ , i));
	}
    }  

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) Un_eq_SGI_tab_GL(nn , ln , jn , i) += SGI_dir_table(i);
}

void HF_potentials_common::SGI_MSGI_part_common::SGI_part_common::Up_exc_pp_part_calc (
										       const int J , 
										       const unsigned int sp_occ , 
										       const class spherical_state &shell_p , 
										       const class spherical_state &shell_p_occ , 
										       const double Ueq_regularizor , 
										       const class interaction_class &inter_data_basis , 
										       const complex<double> &weight , 
										       const class multipolar_expansion_str &multipolar_expansion , 
										       const class SGI_radial_tabs_str &prot_radial_tabs , 
										       class nlj_table<complex<double> > &Up_eq_SGI_tab_GL , 
										       class nlj_table<complex<double> > &source_p_SGI_tab_GL)
{
  const unsigned int N_bef_R_GL = shell_p.get_N_bef_R_GL ();

  const unsigned int N_bef_R_GL_minus_one = N_bef_R_GL - 1;

  class array<double> SGI_exc_table(N_bef_R_GL);

  SGI_exc_table = 0.0;

  const class array<complex<double> > &prot_radial_exc_tab = prot_radial_tabs.get_exc_tab ();
  
  const double jp = shell_p.get_j ();

  const double jp_occ = shell_p_occ.get_j ();

  const int np = shell_p.get_n ();
  const int lp = shell_p.get_l ();
  
  const int lp_plus_one = lp + 1;

  const int lp_occ = shell_p_occ.get_l ();

  const int lmin_multipole_expansion = abs (lp - lp_occ);
  const int lmax_multipole_expansion = lp_occ + lp;

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (lp+lp_occ);
  
  const double coupling_constant = inter_data_basis.Gaussian_coupling_constant (bp , J , false , false);

  for (int ll = lmin_multipole_expansion ; ll <= lmax_multipole_expansion ; ll++)
    {
      if ((lp + ll + lp_occ) % 2 == 0) 
	{
	  const double angular_part = multipolar_expansion(lp , jp , lp_occ , jp_occ , lp_occ , jp_occ , lp , jp , ll , J);
	  
	  const complex<double> angular_part_weight = angular_part*weight;

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) SGI_exc_table(i) += coupling_constant*real (angular_part_weight*prot_radial_exc_tab(ll , sp_occ , i));
	}
    }
  
  const class array<double> &r_bef_R_tab_GL = shell_p.get_r_bef_R_tab_GL_SGI_MSGI ();
  
  const class array<complex<double> > &wfp_bef_R_tab_GL  = shell_p.get_wf_bef_R_tab_GL_SGI_MSGI ();
  const class array<complex<double> > &dwfp_bef_R_tab_GL = shell_p.get_dwf_bef_R_tab_GL_SGI_MSGI ();

  const complex<double> C0_p = shell_p.get_C0 ();

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const unsigned int i_opp = N_bef_R_GL_minus_one - i;
      
      const complex<double> I_exc_r = SGI_exc_table(i)*wfp_bef_R_tab_GL(i_opp);

      const double r = r_bef_R_tab_GL(i);

      const complex<double> C0_p_pow_r_lp_plus_one = C0_p*pow (r , lp_plus_one);

      const complex<double> wfp_r  = wfp_bef_R_tab_GL(i);
      const complex<double> dwfp_r = dwfp_bef_R_tab_GL(i);

      const double pole_removal_factor = exp (-Ueq_regularizor*(norm (wfp_r)/norm (dwfp_r)))*(1.0 - exp (-Ueq_regularizor*(norm (C0_p_pow_r_lp_plus_one/wfp_r - 1.0))));

      const complex<double> I_exc_r_pole_removal_factor = I_exc_r*pole_removal_factor;

      Up_eq_SGI_tab_GL(np , lp , jp , i) -= (I_exc_r - I_exc_r_pole_removal_factor)/wfp_r;

      source_p_SGI_tab_GL(np , lp , jp , i) -= I_exc_r_pole_removal_factor;
    }
}

void HF_potentials_common::SGI_MSGI_part_common::SGI_part_common::Up_exc_pn_part_calc (
										       const int J , 
										       const unsigned int sn_occ , 
										       const class spherical_state &shell_p , 
										       const class spherical_state &shell_n_occ , 
										       const double Ueq_regularizor , 
										       const class interaction_class &inter_data_basis , 
										       const complex<double> &weight , 
										       const class multipolar_expansion_str &multipolar_expansion , 
										       const class SGI_radial_tabs_str &neut_radial_tabs , 
										       class nlj_table<complex<double> > &Up_eq_SGI_tab_GL , 
										       class nlj_table<complex<double> > &source_p_SGI_tab_GL)
{
  const unsigned int N_bef_R_GL = shell_p.get_N_bef_R_GL ();

  const unsigned int N_bef_R_GL_minus_one = N_bef_R_GL - 1;
  
  class array<double> SGI_exc_table(N_bef_R_GL);

  SGI_exc_table = 0.0;

  const class array<complex<double> > &neut_radial_exc_tab = neut_radial_tabs.get_exc_tab ();
  
  const double jp = shell_p.get_j ();
  
  const double jn_occ = shell_n_occ.get_j ();

  const int np = shell_p.get_n ();
  const int lp = shell_p.get_l ();

  const int lp_plus_one = lp + 1;
  
  const int ln_occ = shell_n_occ.get_l ();

  const int lmin_multipole_expansion = abs (lp - ln_occ);
  const int lmax_multipole_expansion = ln_occ + lp;

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (lp + ln_occ);
  
  const double coupling_constant = inter_data_basis.Gaussian_coupling_constant (bp , J , false , true);

  for (int ll = lmin_multipole_expansion ; ll <= lmax_multipole_expansion ; ll++)
    {
      if ((lp + ll + ln_occ) % 2 == 0) 
	{
	  const double angular_part = multipolar_expansion(lp , jp , ln_occ , jn_occ , ln_occ , jn_occ , lp , jp , ll , J);
	  
	  const complex<double> angular_part_weight = angular_part*weight;

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) SGI_exc_table(i) += coupling_constant*real (angular_part_weight*neut_radial_exc_tab(ll , sn_occ , i));
	}
    }
  
  const class array<double> &r_bef_R_tab_GL = shell_p.get_r_bef_R_tab_GL_SGI_MSGI ();

  const class array<complex<double> > &wfp_bef_R_tab_GL  = shell_p.get_wf_bef_R_tab_GL_SGI_MSGI ();
  const class array<complex<double> > &dwfp_bef_R_tab_GL = shell_p.get_dwf_bef_R_tab_GL_SGI_MSGI ();
  
  const complex<double> C0_p = shell_p.get_C0 ();

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const unsigned int i_opp = N_bef_R_GL_minus_one - i;
      
      const complex<double> I_exc_r = SGI_exc_table(i)*wfp_bef_R_tab_GL(i_opp);

      const double r = r_bef_R_tab_GL(i);

      const complex<double> C0_p_pow_r_lp_plus_one = C0_p*pow (r , lp_plus_one);

      const complex<double> wfp_r  = wfp_bef_R_tab_GL(i);
      const complex<double> dwfp_r = dwfp_bef_R_tab_GL(i);

      const double pole_removal_factor = exp (-Ueq_regularizor*(norm (wfp_r)/norm (dwfp_r)))*(1.0 - exp (-Ueq_regularizor*(norm (C0_p_pow_r_lp_plus_one/wfp_r - 1.0))));

      const complex<double> I_exc_r_pole_removal_factor = I_exc_r*pole_removal_factor;

      Up_eq_SGI_tab_GL(np , lp , jp , i) -= (I_exc_r - I_exc_r_pole_removal_factor)/wfp_r;
      
      source_p_SGI_tab_GL(np , lp , jp , i) -= I_exc_r_pole_removal_factor;
    }
}

void HF_potentials_common::SGI_MSGI_part_common::SGI_part_common::Un_exc_nn_part_calc (
										       const int J , 
										       const unsigned int sn_occ , 
										       const class spherical_state &shell_n , 
										       const class spherical_state &shell_n_occ , 
										       const double Ueq_regularizor , 
										       const class interaction_class &inter_data_basis , 
										       const complex<double> &weight , 
										       const class multipolar_expansion_str &multipolar_expansion , 
										       const class SGI_radial_tabs_str &neut_radial_tabs , 
										       class nlj_table<complex<double> > &Un_eq_SGI_tab_GL , 
										       class nlj_table<complex<double> > &source_n_SGI_tab_GL)
{
  const unsigned int N_bef_R_GL = shell_n.get_N_bef_R_GL ();

  const unsigned int N_bef_R_GL_minus_one = N_bef_R_GL - 1;

  class array<double> SGI_exc_table(N_bef_R_GL);

  SGI_exc_table = 0.0;

  const class array<complex<double> > &neut_radial_exc_tab = neut_radial_tabs.get_exc_tab ();
  
  const double jn = shell_n.get_j ();

  const double jn_occ = shell_n_occ.get_j ();

  const int nn = shell_n.get_n ();
  const int ln = shell_n.get_l ();

  const int ln_plus_one = ln + 1;
  
  const int ln_occ = shell_n_occ.get_l ();

  const int lmin_multipole_expansion = abs (ln - ln_occ);
  const int lmax_multipole_expansion = ln_occ + ln;

  const unsigned int bp = binary_parity_from_orbital_angular_momentum(ln + ln_occ);

  const double coupling_constant = inter_data_basis.Gaussian_coupling_constant (bp , J , false , false);

  for (int ll = lmin_multipole_expansion ; ll <= lmax_multipole_expansion ; ll++)
    {
      if ((ln + ll + ln_occ) % 2 == 0) 
	{
	  const double angular_part = multipolar_expansion(ln , jn , ln_occ , jn_occ , ln_occ , jn_occ , ln , jn , ll , J);
	  
	  const complex<double> angular_part_weight = angular_part*weight;

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) SGI_exc_table(i) += coupling_constant*real (angular_part_weight*neut_radial_exc_tab(ll , sn_occ , i));
	}
    }
  
  const class array<double> &r_bef_R_tab_GL = shell_n.get_r_bef_R_tab_GL_SGI_MSGI ();

  const class array<complex<double> > &wfn_bef_R_tab_GL  = shell_n.get_wf_bef_R_tab_GL_SGI_MSGI ();
  const class array<complex<double> > &dwfn_bef_R_tab_GL = shell_n.get_dwf_bef_R_tab_GL_SGI_MSGI ();
  
  const complex<double> C0_n = shell_n.get_C0 ();

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const unsigned int i_opp = N_bef_R_GL_minus_one - i;
      
      const complex<double> I_exc_r = SGI_exc_table(i)*wfn_bef_R_tab_GL(i_opp);

      const double r = r_bef_R_tab_GL(i);

      const complex<double> C0_n_pow_r_ln_plus_one = C0_n*pow (r , ln_plus_one);

      const complex<double> wfn_r  = wfn_bef_R_tab_GL(i);
      const complex<double> dwfn_r = dwfn_bef_R_tab_GL(i);

      const double pole_removal_factor = exp (-Ueq_regularizor*(norm (wfn_r)/norm (dwfn_r)))*(1.0 - exp (-Ueq_regularizor*(norm (C0_n_pow_r_ln_plus_one/wfn_r - 1.0))));

      const complex<double> I_exc_r_pole_removal_factor = I_exc_r*pole_removal_factor;

      Un_eq_SGI_tab_GL(nn , ln , jn , i) -= (I_exc_r - I_exc_r_pole_removal_factor)/wfn_r;
      
      source_n_SGI_tab_GL(nn , ln , jn , i) -= I_exc_r_pole_removal_factor;
    }
}

void HF_potentials_common::SGI_MSGI_part_common::SGI_part_common::Un_exc_pn_part_calc (
										       const int J , 
										       const unsigned int sp_occ , 
										       const class spherical_state &shell_n , 
										       const class spherical_state &shell_p_occ , 
										       const double Ueq_regularizor , 
										       const class interaction_class &inter_data_basis , 
										       const complex<double> &weight , 
										       const class multipolar_expansion_str &multipolar_expansion , 
										       const class SGI_radial_tabs_str &prot_radial_tabs , 
										       class nlj_table<complex<double> > &Un_eq_SGI_tab_GL , 
										       class nlj_table<complex<double> > &source_n_SGI_tab_GL)
{
  const unsigned int N_bef_R_GL = shell_n.get_N_bef_R_GL ();

  const unsigned int N_bef_R_GL_minus_one = N_bef_R_GL - 1;

  class array<double> SGI_exc_table(N_bef_R_GL);

  SGI_exc_table = 0.0;

  const class array<complex<double> > &prot_radial_exc_tab = prot_radial_tabs.get_exc_tab ();
  
  const double jn = shell_n.get_j ();

  const double jp_occ = shell_p_occ.get_j ();

  const int nn = shell_n.get_n ();
  const int ln = shell_n.get_l ();

  const int ln_plus_one = ln + 1;
  
  const int lp_occ = shell_p_occ.get_l ();

  const int lmin_multipole_expansion = abs (ln - lp_occ);
  const int lmax_multipole_expansion = lp_occ + ln;

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (ln + lp_occ);

  const double coupling_constant = inter_data_basis.Gaussian_coupling_constant (bp , J , false , true);

  for (int ll = lmin_multipole_expansion ; ll <= lmax_multipole_expansion ; ll++)
    {
      if ((ln + ll + lp_occ) % 2 == 0) 
	{
	  const double angular_part = multipolar_expansion(ln , jn , lp_occ , jp_occ , lp_occ , jp_occ , ln , jn , ll , J);
	  
	  const complex<double> angular_part_weight = angular_part*weight;

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) SGI_exc_table(i) += coupling_constant*real (angular_part_weight*prot_radial_exc_tab(ll , sp_occ , i));
	}
    }
  
  const class array<double> &r_bef_R_tab_GL = shell_n.get_r_bef_R_tab_GL_SGI_MSGI ();
  
  const class array<complex<double> > &wfn_bef_R_tab_GL  = shell_n.get_wf_bef_R_tab_GL_SGI_MSGI ();
  const class array<complex<double> > &dwfn_bef_R_tab_GL = shell_n.get_dwf_bef_R_tab_GL_SGI_MSGI ();

  const complex<double> C0_n = shell_n.get_C0 ();

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const unsigned int i_opp = N_bef_R_GL_minus_one - i;
      
      const complex<double> I_exc_r = SGI_exc_table(i)*wfn_bef_R_tab_GL(i_opp);

      const double r = r_bef_R_tab_GL(i);

      const complex<double> C0_n_pow_r_ln_plus_one = C0_n*pow (r , ln_plus_one);

      const complex<double> wfn_r  = wfn_bef_R_tab_GL(i);
      const complex<double> dwfn_r = dwfn_bef_R_tab_GL(i);

      const double pole_removal_factor = exp (-Ueq_regularizor*(norm (wfn_r)/norm (dwfn_r)))*(1.0 - exp (-Ueq_regularizor*(norm (C0_n_pow_r_ln_plus_one/wfn_r - 1.0))));

      const complex<double> I_exc_r_pole_removal_factor = I_exc_r*pole_removal_factor;

      Un_eq_SGI_tab_GL(nn , ln , jn , i) -= (I_exc_r - I_exc_r_pole_removal_factor)/wfn_r;
      
      source_n_SGI_tab_GL(nn , ln , jn , i) -= I_exc_r_pole_removal_factor;
    }
}












// Calculation of the non-antisymmetrized (nas) HF potential one-body matrix element of the SGI interaction taking into account one occupied state for one multipole for the direct or exchange part
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates here \int wf_in(r) wf_out(r) wf_occ(r)^2 Vl_SGI(r) dr for the direct part or  \int wf_in(r) wf_out(2.R0 - r) wf_occ(r) wf_occ(2.R0 - r) Vl_SGI(r) dr for the exchange part.
// This matrix element is used to calculate the full HF potential one-body matrix element of the SGI interaction between in and an out states.

complex<double> HF_potentials_common::SGI_MSGI_part_common::SGI_part_common::OBME_nas_fixed_multipole_calc (
													    const class interaction_class &inter_data_basis , 
													    const int ll , 
													    const bool is_it_direct , 
													    const complex<double> &angular_part_weight , 
													    const class spherical_state &wf_occ , 
													    const class spherical_state &wf_in , 
													    const class spherical_state &wf_out)
{
  const class array<double> &w_bef_R_tab_GL = wf_in.get_w_bef_R_tab_GL_SGI_MSGI ();

  const unsigned int N_bef_R_GL = wf_in.get_N_bef_R_GL ();

  const unsigned int N_bef_R_GL_minus_one = N_bef_R_GL - 1;

  const class array<complex<double> > &wf_in_bef_R_tab_GL  = wf_in.get_wf_bef_R_tab_GL_SGI_MSGI ();
  const class array<complex<double> > &wf_out_bef_R_tab_GL = wf_out.get_wf_bef_R_tab_GL_SGI_MSGI ();
  const class array<complex<double> > &wf_occ_bef_R_tab_GL = wf_occ.get_wf_bef_R_tab_GL_SGI_MSGI ();

  const class array<double> &Vl_SGI_tab_GL = inter_data_basis.get_Vl_SGI_tab_GL ();

  complex<double> OBME = 0.0;

  if (is_it_direct)
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  const unsigned int i_opp = N_bef_R_GL_minus_one - i;

	  OBME += wf_in_bef_R_tab_GL(i)*wf_out_bef_R_tab_GL(i)*(real (wf_occ_bef_R_tab_GL(i_opp)*wf_occ_bef_R_tab_GL(i_opp))*Vl_SGI_tab_GL(ll , i)*w_bef_R_tab_GL(i));
	}
    }
  else
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  const unsigned int i_opp = N_bef_R_GL_minus_one - i;

	  OBME += wf_in_bef_R_tab_GL(i_opp)*wf_out_bef_R_tab_GL(i)*(real (wf_occ_bef_R_tab_GL(i)*wf_occ_bef_R_tab_GL(i_opp))*Vl_SGI_tab_GL(ll , i)*w_bef_R_tab_GL(i));
	}
    }

  OBME *= angular_part_weight;

  return OBME;
}








// Calculation of the direct and exchange parts of the HF potential taking into account one occupied state for the proton-proton, neutron-neutron and proton-neutron parts of the SGI interaction
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) writes, along with its source:
//
// U_HF(dir)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . Vl'_SGI(r , 2R0-r) . u_occ^2(2R0-r)
// U_HF(exc)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ, l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) . F(r)
//
// weight is function of Clebsch-Gordan coefficients and angular momenta and come from the use of uniform filling approximation.
// coupling_constant(Pi,J) is the Pi-J-dependent coupling constant of the MSGI interaction.
// Vl'_SGI(r) is the multipolar expansion of the SGI interaction (see GSM_interaction_class.cpp).
// R0 is the radius of the SGI interaction.
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
// Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
// The ratio |u(r)|^2/|u'(r)|^2) prevents F(r) to be non zero when r -> +oo.
// Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// The real part of the equivalent HF potential is considered for the HF potential when it is complex.
//
// These routines call previous routines if the considered state is general, or only bound or resonant (res), or if it a proton scattering state for which k +/- w/(4 Pi) for Coulomb complex scaling (see H_CM_OBMEs.cpp).

void  HF_potentials_common::SGI_MSGI_part_common::SGI_part_common::Up_pp_part_calc (
										    const bool is_it_res , 
										    const bool is_it_pm , 
										    const int pm , 
										    const unsigned int sp_occ , 
										    const class spherical_state &shell_p , 
										    const class spherical_state &shell_p_occ , 
										    const class CG_str &CGs , 
										    const class multipolar_expansion_str &multipolar_expansion , 
										    const class interaction_class &inter_data_basis , 
										    const class SGI_radial_tabs_str &prot_radial_tabs , 
										    class HF_nucleons_data &prot_HF_data)
{
  const int lp  = shell_p.get_l ();

  const int lp_occ = shell_p_occ.get_l ();

  const double jp = shell_p.get_j ();
  
  const double jp_occ = shell_p_occ.get_j ();

  const double Ueq_regularizor = prot_HF_data.get_Ueq_regularizor ();

  const int Jmin_global_pp = inter_data_basis.get_Jmin_global_pp ();
  const int Jmax_global_pp = inter_data_basis.get_Jmax_global_pp ();

  const int Jmin_sp_sp_occ = abs (make_int (jp - jp_occ));
  const int Jmax_sp_sp_occ = make_int (jp + jp_occ);

  const int Jmin = max (Jmin_sp_sp_occ , Jmin_global_pp);
  const int Jmax = min (Jmax_sp_sp_occ , Jmax_global_pp);

  if (is_it_pm)
    {	
      class nlj_table<complex<double> > &Up_eq_SGI_pm_tab_GL = (pm == 1) ? (prot_HF_data.get_Ueq_SGI_MSGI_plus_tab_GL ()) : (prot_HF_data.get_Ueq_SGI_MSGI_minus_tab_GL ());
      
      class nlj_table<complex<double> > &source_p_SGI_pm_tab_GL = (pm == 1) ? (prot_HF_data.get_source_SGI_MSGI_plus_tab_GL ()) : (prot_HF_data.get_source_SGI_MSGI_minus_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (lp , jp , lp_occ , jp_occ , J , CGs , prot_HF_data , prot_HF_data);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jp_occ + jp - J);
			
	  Up_dir_pp_part_calc (J , sp_occ , shell_p , shell_p_occ , inter_data_basis , J_coefficient_direct , multipolar_expansion , prot_radial_tabs , Up_eq_SGI_pm_tab_GL);
	  
	  Up_exc_pp_part_calc (J , sp_occ , shell_p , shell_p_occ , Ueq_regularizor , inter_data_basis , J_coefficient_exchange , multipolar_expansion , prot_radial_tabs , Up_eq_SGI_pm_tab_GL , source_p_SGI_pm_tab_GL);
	}
    }
  else
    {
      class nlj_table<complex<double> > &Up_eq_SGI_tab_GL = (is_it_res) ? (prot_HF_data.get_Ueq_SGI_MSGI_res_tab_GL ()) : (prot_HF_data.get_Ueq_SGI_MSGI_tab_GL ());
      
      class nlj_table<complex<double> > &source_p_SGI_tab_GL = (is_it_res) ? (prot_HF_data.get_source_SGI_MSGI_res_tab_GL ()) : (prot_HF_data.get_source_SGI_MSGI_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (lp , jp , lp_occ , jp_occ , J , CGs , prot_HF_data , prot_HF_data);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jp_occ + jp - J);

	  Up_dir_pp_part_calc (J , sp_occ , shell_p , shell_p_occ , inter_data_basis , J_coefficient_direct , multipolar_expansion , prot_radial_tabs , Up_eq_SGI_tab_GL);

	  Up_exc_pp_part_calc (J , sp_occ , shell_p , shell_p_occ , Ueq_regularizor , inter_data_basis , J_coefficient_exchange , multipolar_expansion , prot_radial_tabs , Up_eq_SGI_tab_GL , source_p_SGI_tab_GL);
	}
    }
}

void  HF_potentials_common::SGI_MSGI_part_common::SGI_part_common::Up_pn_part_calc (
										    const bool is_it_res , 
										    const bool is_it_pm , 
										    const int pm , 
										    const unsigned int sn_occ , 
										    const class spherical_state &shell_p , 
										    const class spherical_state &shell_n_occ , 
										    const class CG_str &CGs , 
										    const class multipolar_expansion_str &multipolar_expansion , 
										    const class interaction_class &inter_data_basis , 
										    const class SGI_radial_tabs_str &neut_radial_tabs , 
										    const class HF_nucleons_data &neut_HF_data , 
										    class HF_nucleons_data &prot_HF_data)
{
  const int lp = shell_p.get_l ();

  const int ln_occ = shell_n_occ.get_l ();

  const double jp = shell_p.get_j ();

  const double jn_occ = shell_n_occ.get_j ();

  const double Ueq_regularizor = prot_HF_data.get_Ueq_regularizor ();
  
  const int Jmin_global_pn = inter_data_basis.get_Jmin_global_pn ();
  const int Jmax_global_pn = inter_data_basis.get_Jmax_global_pn ();

  const int Jmin_sp_sn_occ = abs (make_int (jp - jn_occ));
  const int Jmax_sp_sn_occ = make_int (jp + jn_occ);

  const int Jmin = max (Jmin_sp_sn_occ , Jmin_global_pn);
  const int Jmax = min (Jmax_sp_sn_occ , Jmax_global_pn);

  if (is_it_pm)
    {
      class nlj_table<complex<double> > &Up_eq_SGI_pm_tab_GL = (pm == 1) ? (prot_HF_data.get_Ueq_SGI_MSGI_plus_tab_GL ()) : (prot_HF_data.get_Ueq_SGI_MSGI_minus_tab_GL ());
      
      class nlj_table<complex<double> > &source_p_SGI_pm_tab_GL = (pm == 1) ? (prot_HF_data.get_source_SGI_MSGI_plus_tab_GL ()) : (prot_HF_data.get_source_SGI_MSGI_minus_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (lp , jp , ln_occ , jn_occ , J , CGs , prot_HF_data , neut_HF_data);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jn_occ + jp - J);

	  Up_dir_pn_part_calc (J , sn_occ , shell_p , shell_n_occ , inter_data_basis , J_coefficient_direct , multipolar_expansion , neut_radial_tabs , Up_eq_SGI_pm_tab_GL);
	  
	  Up_exc_pn_part_calc (J , sn_occ , shell_p , shell_n_occ , Ueq_regularizor , inter_data_basis , J_coefficient_exchange , multipolar_expansion , neut_radial_tabs , Up_eq_SGI_pm_tab_GL , source_p_SGI_pm_tab_GL);
	}	
    }
  else
    {
      class nlj_table<complex<double> > &Up_eq_SGI_tab_GL = (is_it_res) ? (prot_HF_data.get_Ueq_SGI_MSGI_res_tab_GL ()) : (prot_HF_data.get_Ueq_SGI_MSGI_tab_GL ());
      
      class nlj_table<complex<double> > &source_p_SGI_tab_GL = (is_it_res) ? (prot_HF_data.get_source_SGI_MSGI_res_tab_GL ()) : (prot_HF_data.get_source_SGI_MSGI_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (lp , jp , ln_occ , jn_occ , J , CGs , prot_HF_data , neut_HF_data);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jn_occ + jp - J);

	  Up_dir_pn_part_calc (J , sn_occ , shell_p , shell_n_occ , inter_data_basis , J_coefficient_direct , multipolar_expansion , neut_radial_tabs , Up_eq_SGI_tab_GL);
	  
	  Up_exc_pn_part_calc (J , sn_occ , shell_p , shell_n_occ , Ueq_regularizor , inter_data_basis , J_coefficient_exchange , multipolar_expansion , neut_radial_tabs , Up_eq_SGI_tab_GL , source_p_SGI_tab_GL);
	}
    }
}

void  HF_potentials_common::SGI_MSGI_part_common::SGI_part_common::Un_nn_part_calc (
										    const bool is_it_res , 
										    const bool is_it_pm , 
										    const int pm , 
										    const unsigned int sn_occ , 
										    const class spherical_state &shell_n , 
										    const class spherical_state &shell_n_occ , 
										    const class CG_str &CGs , 
										    const class multipolar_expansion_str &multipolar_expansion , 
										    const class interaction_class &inter_data_basis , 
										    const class SGI_radial_tabs_str &neut_radial_tabs , 
										    class HF_nucleons_data &neut_HF_data)
{
  const int ln = shell_n.get_l ();

  const int ln_occ = shell_n_occ.get_l ();

  const double jn = shell_n.get_j ();

  const double jn_occ = shell_n_occ.get_j ();

  const double Ueq_regularizor = neut_HF_data.get_Ueq_regularizor ();

  const int Jmin_global_nn = inter_data_basis.get_Jmin_global_nn ();
  const int Jmax_global_nn = inter_data_basis.get_Jmax_global_nn ();

  const int Jmin_sn_sn_occ = abs (make_int (jn - jn_occ));
  const int Jmax_sn_sn_occ = make_int (jn + jn_occ);

  const int Jmin = max (Jmin_sn_sn_occ , Jmin_global_nn);
  const int Jmax = min (Jmax_sn_sn_occ , Jmax_global_nn);

  if (is_it_pm)
    {
      class nlj_table<complex<double> > &Un_eq_SGI_pm_tab_GL = (pm == 1) ? (neut_HF_data.get_Ueq_SGI_MSGI_plus_tab_GL ()) : (neut_HF_data.get_Ueq_SGI_MSGI_minus_tab_GL ());
      
      class nlj_table<complex<double> > &source_n_SGI_pm_tab_GL = (pm == 1) ? (neut_HF_data.get_source_SGI_MSGI_plus_tab_GL ()) : (neut_HF_data.get_source_SGI_MSGI_minus_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (ln , jn , ln_occ , jn_occ , J , CGs , neut_HF_data , neut_HF_data);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jn_occ + jn - J);
			
	  Un_dir_nn_part_calc (J , sn_occ , shell_n , shell_n_occ , inter_data_basis , J_coefficient_direct , multipolar_expansion , neut_radial_tabs , Un_eq_SGI_pm_tab_GL);
	  
	  Un_exc_nn_part_calc (J , sn_occ , shell_n , shell_n_occ , Ueq_regularizor , inter_data_basis , J_coefficient_exchange , multipolar_expansion , neut_radial_tabs , Un_eq_SGI_pm_tab_GL , source_n_SGI_pm_tab_GL);
	}
    }
  else
    {
      class nlj_table<complex<double> > &Un_eq_SGI_tab_GL = (is_it_res) ? (neut_HF_data.get_Ueq_SGI_MSGI_res_tab_GL ()) : (neut_HF_data.get_Ueq_SGI_MSGI_tab_GL ());
      
      class nlj_table<complex<double> > &source_n_SGI_tab_GL = (is_it_res) ? (neut_HF_data.get_source_SGI_MSGI_res_tab_GL ()) : (neut_HF_data.get_source_SGI_MSGI_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (ln , jn , ln_occ , jn_occ , J , CGs , neut_HF_data , neut_HF_data);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jn_occ + jn - J);

	  Un_dir_nn_part_calc (J , sn_occ , shell_n , shell_n_occ , inter_data_basis , J_coefficient_direct , multipolar_expansion , neut_radial_tabs , Un_eq_SGI_tab_GL);
	  Un_exc_nn_part_calc (J , sn_occ , shell_n , shell_n_occ , Ueq_regularizor , inter_data_basis , J_coefficient_exchange , multipolar_expansion , neut_radial_tabs , Un_eq_SGI_tab_GL , source_n_SGI_tab_GL);
	}
    }
}

void HF_potentials_common::SGI_MSGI_part_common::SGI_part_common::Un_pn_part_calc (
										   const bool is_it_res , 
										   const bool is_it_pm , 
										   const int pm , 
										   const unsigned int sp_occ , 
										   const class spherical_state &shell_n , 
										   const class spherical_state &shell_p_occ , 
										   const class CG_str &CGs , 
										   const class multipolar_expansion_str &multipolar_expansion , 
										   const class interaction_class &inter_data_basis , 
										   const class SGI_radial_tabs_str &prot_radial_tabs , 
										   const class HF_nucleons_data &prot_HF_data , 
										   class HF_nucleons_data &neut_HF_data)
{
  const int ln = shell_n.get_l ();

  const int lp_occ = shell_p_occ.get_l ();

  const double jn = shell_n.get_j ();

  const double jp_occ = shell_p_occ.get_j ();

  const double Ueq_regularizor = neut_HF_data.get_Ueq_regularizor ();

  const int Jmin_global_pn = inter_data_basis.get_Jmin_global_pn ();
  const int Jmax_global_pn = inter_data_basis.get_Jmax_global_pn ();

  const int Jmin_sn_sp_occ = abs (make_int (jn - jp_occ));
  const int Jmax_sn_sp_occ = make_int (jn + jp_occ);

  const int Jmin = max (Jmin_sn_sp_occ , Jmin_global_pn);
  const int Jmax = min (Jmax_sn_sp_occ , Jmax_global_pn);

  if (is_it_pm)
    {	
      class nlj_table<complex<double> > &Un_eq_SGI_pm_tab_GL = (pm == 1) ? (neut_HF_data.get_Ueq_SGI_MSGI_plus_tab_GL ()) : (neut_HF_data.get_Ueq_SGI_MSGI_minus_tab_GL ());
      
      class nlj_table<complex<double> > &source_n_SGI_pm_tab_GL = (pm == 1) ? (neut_HF_data.get_source_SGI_MSGI_plus_tab_GL ()) : (neut_HF_data.get_source_SGI_MSGI_minus_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (ln , jn , lp_occ , jp_occ , J , CGs , neut_HF_data , prot_HF_data);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jp_occ + jn - J);

	  Un_dir_pn_part_calc (J , sp_occ , shell_n , shell_p_occ , inter_data_basis , J_coefficient_direct , multipolar_expansion , prot_radial_tabs , Un_eq_SGI_pm_tab_GL);
	  
	  Un_exc_pn_part_calc (J , sp_occ , shell_n , shell_p_occ , Ueq_regularizor , inter_data_basis , J_coefficient_exchange , multipolar_expansion , prot_radial_tabs , Un_eq_SGI_pm_tab_GL , source_n_SGI_pm_tab_GL);
	}
    }
  else
    {
      class nlj_table<complex<double> > &Un_eq_SGI_tab_GL = (is_it_res) ? (neut_HF_data.get_Ueq_SGI_MSGI_res_tab_GL ()) : (neut_HF_data.get_Ueq_SGI_MSGI_tab_GL ());
      
      class nlj_table<complex<double> > &source_n_SGI_tab_GL = (is_it_res) ? (neut_HF_data.get_source_SGI_MSGI_res_tab_GL ()) : (neut_HF_data.get_source_SGI_MSGI_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (ln , jn , lp_occ , jp_occ , J , CGs , neut_HF_data , prot_HF_data);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jp_occ + jn - J);

	  Un_dir_pn_part_calc (J , sp_occ , shell_n , shell_p_occ , inter_data_basis , J_coefficient_direct , multipolar_expansion , prot_radial_tabs , Un_eq_SGI_tab_GL);

	  Un_exc_pn_part_calc (J , sp_occ , shell_n , shell_p_occ , Ueq_regularizor , inter_data_basis , J_coefficient_exchange , multipolar_expansion , prot_radial_tabs , Un_eq_SGI_tab_GL , source_n_SGI_tab_GL);
	}
    }
}





