#include "../GSM_include/GSM_include_def_common.h"

using namespace string_routines;
using namespace inputs_misc;

extern enum called_code_type called_code;
 
// TYPE is double or complex
// -------------------------

// Multiplicative coefficients of single particle energies and two-body matrix elements
// ------------------------------------------------------------------------------------
// In standard shell model, one sometimes multiply a set of fitted one-body and two-body matrix elements by a constant and matrix elements can be added from different files.
// These constants are read from the input file here after allocation of arrays.
// One has as many multiplicative coefficients for one-body and two-body matrix elements as one has interaction files.
// SPE is for single-particle energies and TBME is for two-body matrix elements.

void call_common_routines::files_norm_coefficients_alloc_read (
							       class input_data_str &input_data , 
							       class array<double> &SPE_coefficients , 
							       class array<double> &TBME_coefficients , 
							       class array<string> &file_names)
{ 
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in call_common_routines::files_norm_coefficients_alloc_read.");

  unsigned int files_number = 0;

  cin >> files_number;

  word_check_print<unsigned int> ("file(s)" , files_number);

  input_data.set_files_number (files_number);
      
  SPE_coefficients.allocate (files_number);
	
  TBME_coefficients.allocate (files_number);
	
  file_names.allocate (files_number);
      
  for (unsigned int i = 0 ; i < files_number ; i++) 
    {
      cin >> file_names(i);

      cout << "File " << i+1 << " : " << file_names(i) << endl;

      cin >> SPE_coefficients(i);

      word_check_print<double> ("(SPE.normalization.coefficient)" , SPE_coefficients(i));

      cin >> TBME_coefficients(i);

      word_check_print<double> ("(TBME.normalization.coefficient)" , TBME_coefficients(i));

      file_names(i) = STORAGE_DIR + file_names(i);
    }
}






// Read of the input file, storage of data in input_data_str classes and MPI distribution to all nodes
// ---------------------------------------------------------------------------------------------------
// Input parameters in the input file are read here and stored in input_data, input_data_CC_Berggren (GSM-CC only) and input_data_tab_for_optimization (GSM optimization only) by the master process.
// They are distributed to all nodes afterwards.
// The number of threads read in the input file is set so that it is not the default value for the number of threads which is used for OpenMP distribution.
// All different codes are considered here: two-particle relative and GSM, complex GSM, GSM-CC, GSM optimization, standard shell model with the HO basis.
// The number of active nodes in 2D partitioning is also written, as one has to have n(n+1)/2 nodes in 2D partitioning, with n integer, so that they are all used for Hamiltonian times vector multiplications.
// This is written even for the 1D and hybrid 1D/2D codes for comparison.
// SPE is for single-particle energies and TBME is for two-body matrix elements.

void call_common_routines::input_data_read_MPI_transfer (
							 class array<double> &SPE_coefficients , 
							 class array<double> &TBME_coefficients , 
							 class array<string> &file_names , 
							 class input_data_str &input_data , 
							 class input_data_str &input_data_CC_Berggren , 
							 class array<class input_data_str> &input_data_tab_for_optimization)
{
  //--// collecting of values from the input (not all)
  //
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      input_data.MPI_processes_OpenMP_threads_workspace_name_read ();
      input_data.use_options_interaction_read ();

      if (!input_data.get_only_dimensions () && !input_data.get_non_zero_NBMEs_proportion_only ())
      {
	input_data.interaction_format_read ();
      
	if ((input_data.get_basis_potential () == HO_POTENTIAL) && (input_data.get_inter () == FIT))
	  files_norm_coefficients_alloc_read (input_data , SPE_coefficients , TBME_coefficients , file_names);
      }
      
      input_data.core_data_read_calc ();
      input_data.space_particles_number_data_read ();
      input_data.radial_data_read_calc ();
      input_data.momentum_data_read_calc ();

      //--// collect several parameters for the core (A , Z , ...)
      input_data.one_body_relative_basis_core_potential_data_alloc_read ();

      if (called_code != TWO_PARTICLE_RELATIVE_CODE) 
	{
	  if (called_code != OPTIMIZATION_CODE) input_data.BP_J_min_max_global_from_partial_waves ();
	  if (called_code == TWO_PARTICLE_CODE) input_data.BP_J_min_max_global_two_particles_read ();
	}

      input_data.truncation_data_read ();

      if (!input_data.get_only_dimensions ())
	{
	  if (called_code != TWO_PARTICLE_RELATIVE_CODE) 
	    {	      
	      input_data.storage_diagonalization_RDM_linear_system_data_read ();

	      if ((called_code != CC_CODE) && (called_code != OPTIMIZATION_CODE) && (called_code != RDM_CODE)) input_data.eigenvectors_data_alloc_read ();
	    }

	  if (called_code == RDM_CODE) input_data.RDM_data_read ();
	}
      
      if (called_code == OPTIMIZATION_CODE)
	{	  
	  input_data.core_parameters_fit_choice_data_read ();
	  
	  input_data.interaction_parameters_fit_choice_data_read ();
	  
	  input_data.optimization_misc_parameters_read ();
	  
	  input_data.set_prot_mass_for_calc (1.0);	  
	  input_data.set_neut_mass_for_calc (1.0);

	  const unsigned int N_nuclei_to_consider = input_data.get_N_nuclei_to_consider ();

	  input_data_tab_for_optimization.allocate (N_nuclei_to_consider);
	  
	  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
	    {
	      class input_data_str &input_data_for_optimization = input_data_tab_for_optimization(nucleus_index);

	      word_check ("Nucleus");
	      word_check (make_string<int> (nucleus_index + 1));

	      cout << "Nucleus " << nucleus_index + 1 << endl << endl;
	      
	      input_data_for_optimization.optimization_fixed_nucleus_alloc_read (input_data);
	      
	      input_data_for_optimization.BP_J_min_max_global_from_partial_waves (); 
	    }

	  const bool binding_energies_fitted = input_data.get_binding_energies_fitted ();
	  
	  unsigned int reference_states_number = 0;
  
	  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
	    {
	      const class input_data_str &input_data_for_optimization = input_data_tab_for_optimization(nucleus_index);

	      const unsigned int eigensets_number = input_data_for_optimization.get_eigensets_number ();

	      const class array<unsigned int> &eigenset_vectors_number_tab = input_data_for_optimization.get_eigenset_vectors_number_tab ();

	      const class array<class correlated_state_str> &PSI_qn_tab = input_data_for_optimization.get_PSI_qn_from_file_tab ();
	      
	      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
		{
		  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

		  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
		    {
		      const class correlated_state_str &PSI_qn =  PSI_qn_tab(eigenset_index , i);
	  
		      if (PSI_qn.get_is_it_optimization_reference_state ())
			{
			  reference_states_number++;
	      
			  if (binding_energies_fitted) error_message_print_abort ("There is no reference state if one fits binding energies");
      
			  if (PSI_qn.get_weight () != 0) error_message_print_abort ("Reference state must have zero weight");
		
			  if (reference_states_number != 1) error_message_print_abort ("There is one reference state only if one fits separation energies");	     
			}
		    }
		}
	    }
	  
	  input_data.GSM_optimization_largest_space_check (true  , input_data_tab_for_optimization);
	  input_data.GSM_optimization_largest_space_check (false , input_data_tab_for_optimization);
	  	  
	  if (!binding_energies_fitted && (reference_states_number == 0)) error_message_print_abort ("No reference state provided for the fit of separation energies");	    
  	  	  
	  input_data.lmax_BP_J_min_max_global_from_input_data_tab (input_data_tab_for_optimization);
	  
	  input_data.Zval_Nval_BP_J_min_max_basis_calc_from_input_data_tab (input_data_tab_for_optimization);
	  
	  input_data.core_potential_data_alloc_read ();

	  input_data.basis_core_potential_data_alloc_read ();

	  input_data.basis_potential_data_default_alloc_fill ();
	}

      input_data.interactions_parameters_alloc_read ();
      	  
      if (!input_data.get_only_dimensions () && !input_data.get_non_zero_NBMEs_proportion_only () &&
	  (input_data.get_inter () != FIT) && (input_data.get_inter () != SU3_INTERACTION) && (called_code != OPTIMIZATION_CODE) && (called_code != TWO_PARTICLE_RELATIVE_CODE))
	{
	  input_data.optimized_partial_waves_basis_potentials_data_alloc_read ();
	  input_data.b_lab_partial_waves_alloc_read ();
	  input_data.natural_orbitals_data_alloc_read ();	  
	}
      else
	{
	  input_data.b_lab_partial_waves_default_alloc_fill ();
	  input_data.optimized_partial_waves_basis_potential_partial_waves_default_alloc_fill ();
	}

      if ((called_code == GSM_CODE) && (input_data.get_Z () == input_data.get_Zval ()) && (input_data.get_N () == input_data.get_Nval ())) 
	input_data.cluster_data_read_for_cluster_CM_HO_calculation ();
      
      if (!input_data.get_is_it_cluster_CM_HO_basis_calculation () && !input_data.get_only_dimensions () && !input_data.get_non_zero_NBMEs_proportion_only () &&
	  ((called_code == TWO_PARTICLE_CODE) || (called_code == GSM_CODE) || (called_code == CC_CODE) || (called_code == OBSERVABLES_CODE) || (called_code == RDM_CODE)))
	input_data.observables_data_read ();
      
      if (called_code == CC_CODE)
	{
	  input_data.CC_reaction_Davidson_cross_section_diagonalization_starting_points_data_read ();
	  input_data.CC_corrective_factors_TBMEs_alloc_composite_read ();
	  input_data.CC_data_composite_states_read ();

	  input_data.CC_target_projectile_data_alloc_read ();

	  if (!input_data.is_it_one_nucleon_COSM_case_determine ()) input_data.cluster_data_read_for_CC_calculation ();

	  input_data.CC_radiative_capture_data_read ();
	  input_data.CC_cross_section_E_kinetic_total_system_CM_angles_values_read ();
	}

      if (called_code == TWO_PARTICLE_RELATIVE_CODE) input_data.eigensets_data_alloc_read_for_relative_calculation ();

      if (!input_data.get_is_it_cluster_CM_HO_basis_calculation () && (called_code != RDM_CODE)) input_data.effective_charges_read ();
 
      input_data.nmax_HO_relative_tab_alloc_calc ();

      if (called_code == CC_CODE) input_data_CC_Berggren.copy_input_data_CC_Berggren_basis_alloc_read (input_data);

      if (called_code == OPTIMIZATION_CODE)
	{	  
	  input_data.GSM_optimization_are_natural_orbitals_calculated_every_iteration_determine (input_data_tab_for_optimization);
	  
	  input_data.GSM_optimization_reference_state_check (input_data_tab_for_optimization);
	  
	  const unsigned int N_nuclei_to_consider = input_data.get_N_nuclei_to_consider ();

	  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
	    {
	      class input_data_str &input_data_for_optimization = input_data_tab_for_optimization(nucleus_index);

	      input_data_for_optimization.b_lab_fill_optimization_code (input_data);
	      
	      input_data_for_optimization.shells_consistency_tests_optimization_code ();

	      input_data_for_optimization.holes_consistency_tests ();
	    }
	}
      
      if ((input_data.get_inter () != FIT) && (input_data.get_inter () != SU3_INTERACTION) && (called_code != OPTIMIZATION_CODE) && (called_code != TWO_PARTICLE_RELATIVE_CODE)) input_data.same_proton_neutron_partial_waves_check ();
    }
  
  //--// distribute read data to all nodes
#ifdef UseMPI

  MPI_helper::string_Bcast (STORAGE_DIR , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

  input_data.MPI_Bcast_constants_alloc_tables ();	

  if (called_code == CC_CODE) input_data_CC_Berggren.MPI_Bcast_constants_alloc_tables ();

  if (THIS_PROCESS == MASTER_PROCESS) cout << "Common input_data transfer done" << endl << endl;
  
#endif
  
  //--// set the number of threads
#ifdef UseOpenMP
  
  OpenMP_set_threads_number (input_data.get_number_of_OpenMP_threads ());
  
#endif
 
  if ((THIS_PROCESS == MASTER_PROCESS) && !input_data.get_only_dimensions () && !input_data.get_non_zero_NBMEs_proportion_only ())
    {
      const double m = input_data.get_neut_mass_for_calc ();

      const double b_lab = input_data.get_b_lab ();

      const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , m , b_lab);
	      	
      cout << endl << "hw:" << hbar_omega << " MeV. 3/4 hw:" << 0.75*hbar_omega << " MeV" << endl << endl;
    }

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;
      cout << "Input file data read and transfered" << endl; 
      cout << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl << endl;
    }
}









