#include "../GSM_include/GSM_include_def_common.h"


// TYPE is double or complex
// -------------------------

// TBME means two-body matrix element
// ----------------------------------


// Class storing coupled TBMEs with used one-body bases
// ----------------------------------------------------
// J-coupled TBMEs of the Berggren basis are stored in this class.
// One can can also store HO mixed TBMEs, i.e. of the form <gamma delta | V | alpha_HO beta_HO>_J, where alpha_HO, beta_HO are HO states and gamma, delta are Berggren basis states, as in the HO expansion method.
// Arrays of Clebsch-Gordan coefficients and antisymmetry normalization factors are also stored to calculate uncoupled TBMEs from coupled TBMEs.
// Simple member functions coded, such as putting all TBMEs to zero, multiplying all TBMEs by a corrective factor, calculating one-dimensional indices for arrays, 
// calculating the indices for the TBMEs that MPI nodes must distribute, MPI transfer routines of arrays and read/copy of TBMEs on formatted files.
//
// One has eight different constructors: 
// the default and copy constructors, 
// constructors for pp/nn/pn/pp-nn conversion TBMEs using the Berggren basis with shells taken from the arrays of class nlj_struct of input class baryons_data,  
// constructors for pp/nn/pn/pp-nn conversion TBMEs using the Berggren basis with shells taken from input arrays of class nlj_struct, 
// constructors for pp/nn/pn/pp-nn conversion TBMEs using the HO mixed basis.
//
// The memory taken by all TBMEs can be printed on screen, as it is not negligible.

using namespace string_routines;

class baryons_data;

TBMEs_class::TBMEs_class () : 
  TBME_space (NO_SPACE) , 
  BPmin_global (0) , 
  BPmax_global (0) ,
  Jmin_global (0) , 
  Jmax_global (0) ,
  strangeness_min_global (0) ,
  strangeness_max_global (0) ,
  i_charge_min_global (0) ,
  i_charge_max_global (0) ,
  is_it_mixed (false)
{}

TBMEs_class::TBMEs_class (
			  const bool is_there_cout , 
			  const bool is_it_only_basis , 
			  const class input_data_str &input_data , 
			  const class baryons_data &data) :
  TBME_space (NO_SPACE) , 
  BPmin_global (0) , 
  BPmax_global (0) , 
  Jmin_global (0) , 
  Jmax_global (0) ,
  strangeness_min_global (0) ,
  strangeness_max_global (0) ,
  i_charge_min_global (0) ,
  i_charge_max_global (0) , 
  is_it_mixed (false)
{
  allocate (is_there_cout , is_it_only_basis , input_data , data);
}

TBMEs_class::TBMEs_class (
			  const bool is_there_cout , 
			  const bool is_it_only_basis , 
			  const class input_data_str &input_data , 
			  const class baryons_data &prot_Y_data , 
			  const class baryons_data &neut_Y_data) :
  TBME_space (NO_SPACE) , 
  BPmin_global (0) , 
  BPmax_global (0) , 
  Jmin_global (0) , 
  Jmax_global (0) , 
  strangeness_min_global (0) ,
  strangeness_max_global (0) ,
  i_charge_min_global (0) ,
  i_charge_max_global (0) ,
  is_it_mixed (false)
{
  allocate (is_there_cout , is_it_only_basis , input_data , prot_Y_data , neut_Y_data);
}

TBMEs_class::TBMEs_class (
			  const bool is_there_cout , 
			  const class input_data_str &input_data , 
			  const class baryons_data &prot_Y_data , 
			  const class baryons_data &neut_Y_data) :
  TBME_space (NO_SPACE) , 
  BPmin_global (0) , 
  BPmax_global (0) , 
  Jmin_global (0) , 
  Jmax_global (0) , 
  strangeness_min_global (0) ,
  strangeness_max_global (0) ,
  i_charge_min_global (0) ,
  i_charge_max_global (0) ,
  is_it_mixed (false)
{
  allocate (is_there_cout , input_data , prot_Y_data , neut_Y_data);
}

TBMEs_class::TBMEs_class (
			  const bool is_there_cout , 
			  const enum space_type TBME_space_c , 
			  const class input_data_str &input_data , 
			  const class array<class nlj_struct> &shells_qn ,
			  const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_tab) :
  TBME_space (NO_SPACE) , 
  BPmin_global (0) , 
  BPmax_global (0) , 
  Jmin_global (0) , 
  Jmax_global (0) ,
  strangeness_min_global (0) ,
  strangeness_max_global (0) ,
  i_charge_min_global (0) ,
  i_charge_max_global (0) , 
  is_it_mixed (false)
{
  allocate (is_there_cout , TBME_space_c , input_data , shells_qn , shells_inter_indices_from_nlj_indices_tab);
}

TBMEs_class::TBMEs_class (
			  const bool is_there_cout , 
			  const bool is_it_only_basis , 
			  const class input_data_str &input_data , 
			  const class array<class nlj_struct> &shells_qn_p , 
			  const class array<class nlj_struct> &shells_qn_n ,
			  const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_p_tab ,
			  const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_n_tab) :
  TBME_space (NO_SPACE) , 
  BPmin_global (0) , 
  BPmax_global (0) ,
  Jmin_global (0) , 
  Jmax_global (0) , 
  strangeness_min_global (0) ,
  strangeness_max_global (0) ,
  i_charge_min_global (0) ,
  i_charge_max_global (0) ,  
  is_it_mixed (false)
{
  allocate (is_there_cout , is_it_only_basis , input_data , shells_qn_p , shells_qn_n , shells_inter_indices_from_nlj_indices_p_tab , shells_inter_indices_from_nlj_indices_n_tab);
}

TBMEs_class::TBMEs_class (
			  const bool is_there_cout ,
			  const bool is_it_cv ,
			  const class input_data_str &input_data , 
			  const class baryons_data &data , 
			  const enum interaction_type TBME_inter , 
			  const class array<class nlj_struct> &shells_inter_qn ,
			  const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_tab) :
  TBME_space (NO_SPACE) , 
  BPmin_global (0) , 
  BPmax_global (0) , 
  Jmin_global (0) , 
  Jmax_global (0) , 
  strangeness_min_global (0) ,
  strangeness_max_global (0) ,
  i_charge_min_global (0) ,
  i_charge_max_global (0) , 
  is_it_mixed (false)
{
  allocate (is_there_cout , is_it_cv , input_data , data , TBME_inter , shells_inter_qn , shells_inter_indices_from_nlj_indices_tab);
}

TBMEs_class::TBMEs_class (
			  const bool is_there_cout , 
			  const bool is_it_only_basis , 
			  const class input_data_str &input_data , 
			  const class baryons_data &prot_Y_data , 
			  const class baryons_data &neut_Y_data , 
			  const enum interaction_type TBME_inter , 
			  const class array<class nlj_struct> &shells_inter_qn_p ,
			  const class array<class nlj_struct> &shells_inter_qn_n ,
			  const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_p_tab ,
			  const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_n_tab) :
  TBME_space (NO_SPACE) , 
  BPmin_global (0) , 
  BPmax_global (0) , 
  Jmin_global (0) , 
  Jmax_global (0) , 
  strangeness_min_global (0) ,
  strangeness_max_global (0) ,
  i_charge_min_global (0) ,
  i_charge_max_global (0) , 
  is_it_mixed (false)
{
  allocate (is_there_cout , is_it_only_basis , input_data , prot_Y_data , neut_Y_data , TBME_inter , shells_inter_qn_p , shells_inter_qn_n , shells_inter_indices_from_nlj_indices_p_tab , shells_inter_indices_from_nlj_indices_n_tab);
}

TBMEs_class::TBMEs_class (const class TBMEs_class &X) :
  TBME_space (NO_SPACE) , 
  BPmin_global (0) , 
  BPmax_global (0) , 
  Jmin_global (0) , 
  Jmax_global (0) , 
  strangeness_min_global (0) ,
  strangeness_max_global (0) ,
  i_charge_min_global (0) ,
  i_charge_max_global (0) , 
  is_it_mixed (false)
{
  allocate_fill (X);
}

// The two next routines do not use any class members, but are meaningless outside the class. So I keep them in the class.

unsigned int TBMEs_class::Nmu_shells_from_shells_indices_from_nlj_indices_tab_calc (const class array<class array<unsigned int> > &shells_indices_from_nlj_indices_mu_tab) const
{
  const unsigned int Nmu_baryon_type = shells_indices_from_nlj_indices_mu_tab.dimension (0);
 
  unsigned int Nmu_shells = 0;

  for (unsigned int i_mu = 0 ; i_mu < Nmu_baryon_type ; i_mu++)
    {
      const class array<unsigned int> &shells_indices_from_nlj_indices_i_mu = shells_indices_from_nlj_indices_mu_tab(i_mu);

      Nmu_shells += shells_indices_from_nlj_indices_i_mu.dimension (0);
    }

  return Nmu_shells;
}

void TBMEs_class::BP_J_i_charge_strangeness_min_max_from_shells_quantum_numbers_shells_indices_from_nlj_indices_calc (
														      const bool is_left_charged , 
														      const bool is_right_charged , 
														      const double jmax_left , 
														      const double jmax_right , 
														      const class array<class nlj_struct> &shells_qn_left ,
														      const class array<class nlj_struct> &shells_qn_right ,
														      const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_left_tab ,
														      const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_right_tab ,
														      unsigned int &BPmin_global_left_right ,
														      unsigned int &BPmax_global_left_right ,
														      int &Jmin_global_left_right ,
														      int &Jmax_global_left_right ,
														      int &strangeness_min_global_left_right ,
														      int &strangeness_max_global_left_right ,
														      unsigned int &i_charge_min_global_left_right ,
														      unsigned int &i_charge_max_global_left_right) const
{
  const unsigned int N_nlj_left = shells_qn_left.dimension (0);
  
  const unsigned int N_nlj_right = shells_qn_right.dimension (0);
  
  const unsigned int N_baryon_type_left = shells_inter_indices_from_nlj_indices_left_tab.dimension (0);

  const unsigned int N_baryon_type_right = shells_inter_indices_from_nlj_indices_right_tab.dimension (0);
  
  const bool is_it_to_be_ordered = (is_left_charged == is_right_charged);
  
  BPmin_global_left_right = 1 , Jmin_global_left_right = make_int (jmax_left + jmax_right);
  BPmax_global_left_right = 0 , Jmax_global_left_right = 0;
  
  strangeness_min_global_left_right = two_baryon_state_strangeness_max_determine () , i_charge_min_global_left_right = two_baryon_state_charge_index_max_determine ();
  strangeness_max_global_left_right = 0                                             , i_charge_max_global_left_right = 0;
  
  for (unsigned int s_right = 0 ; s_right < N_nlj_right ; s_right++)
    for (unsigned int s_left = 0 ; (is_it_to_be_ordered) ? (s_left <= s_right) : (s_left < N_nlj_left) ; s_left++)
      {
	const class nlj_struct &shell_qn_left  = shells_qn_left (s_left);
	const class nlj_struct &shell_qn_right = shells_qn_right(s_right);
			      
	const enum particle_type particle_left  = shell_qn_left.get_particle ();
	const enum particle_type particle_right = shell_qn_right.get_particle ();
	  
	const class pair_str pair(particle_left , s_left , particle_right , s_right);

	const unsigned int bp = pair.bp_determine (shells_qn_left , shells_qn_right);

	const int Jmin_local = pair.Jmin_determine (shells_qn_left , shells_qn_right);
	const int Jmax_local = pair.Jmax_determine (shells_qn_left , shells_qn_right);

	BPmin_global_left_right = min (bp , BPmin_global_left_right) , Jmin_global_left_right = min (Jmin_local , Jmin_global_left_right);
	BPmax_global_left_right = max (bp , BPmax_global_left_right) , Jmax_global_left_right = max (Jmax_local , Jmax_global_left_right);	
      }
  
  for (unsigned int iB_right = 0 ; iB_right < N_baryon_type_right ; iB_right++)
    for (unsigned int iB_left = 0 ; (is_it_to_be_ordered) ? (iB_left <= iB_right) : (iB_left < N_baryon_type_left) ; iB_left++)
      {
	const class array<unsigned int> &shells_inter_indices_from_nlj_indices_B_left = shells_inter_indices_from_nlj_indices_left_tab(iB_left);
	 
	const class array<unsigned int> &shells_inter_indices_from_nlj_indices_B_right = shells_inter_indices_from_nlj_indices_right_tab(iB_right);

	const unsigned int N_shells_B_left = shells_inter_indices_from_nlj_indices_B_left.dimension (0);
	 
	const unsigned int N_shells_B_right = shells_inter_indices_from_nlj_indices_B_right.dimension (0);

	if ((N_shells_B_left > 0) && (N_shells_B_right > 0))
	  {
	    const enum particle_type B_left = baryon_from_charge_index_determine (is_left_charged , iB_left);
	 
	    const enum particle_type B_right = baryon_from_charge_index_determine (is_right_charged , iB_right);
	    
	    const int strangeness = two_baryon_state_strangeness_determine (B_left , B_right);
	      
	    const unsigned int i_charge = two_baryon_state_charge_index_determine (B_left , B_right);	    	    
	
	    strangeness_min_global_left_right = min (strangeness , strangeness_min_global_left_right) , i_charge_min_global_left_right = min (i_charge , i_charge_min_global_left_right);
	    strangeness_max_global_left_right = max (strangeness , strangeness_min_global_left_right) , i_charge_max_global_left_right = max (i_charge , i_charge_max_global_left_right);
	  }
      }
}

void TBMEs_class::bp_i_charge_strangeness_tables_from_shells_quantum_numbers_alloc_calc (
											 const class array<class nlj_struct> &shells_qn_left ,
											 const class array<class nlj_struct> &shells_qn_right)
{
  const unsigned int N_nlj_baryon_left = shells_qn_left.dimension (0);
  
  const unsigned int N_nlj_baryon_right = shells_qn_right.dimension (0);
    
  bp_table_out.allocate (N_nlj_baryon_left , N_nlj_baryon_right);
  
  strangeness_table_out.allocate (N_nlj_baryon_left , N_nlj_baryon_right);

  i_charge_table_out.allocate (N_nlj_baryon_left , N_nlj_baryon_right);
  
  for (unsigned int mu_left = 0 ; mu_left < N_nlj_baryon_left ; mu_left++)
    for (unsigned int mu_right = 0 ; mu_right < N_nlj_baryon_right ; mu_right++)
      {
	const class nlj_struct &shell_qn_left  = shells_qn_left (mu_left);
	const class nlj_struct &shell_qn_right = shells_qn_right(mu_right);
			      
	const enum particle_type particle_left  = shell_qn_left.get_particle ();
	const enum particle_type particle_right = shell_qn_right.get_particle ();
	
	const class pair_str pair(particle_left , mu_left , particle_right , mu_right);

	bp_table_out(mu_left , mu_right) = pair.bp_determine (shells_qn_left , shells_qn_right);
	
	i_charge_table_out(mu_left , mu_right) = pair.charge_index_determine ();
	
	strangeness_table_out(mu_left , mu_right) = pair.strangeness_determine ();
      }
}

void TBMEs_class::dimensions_coupled_pairs_indices_from_shells_quantum_numbers_alloc_calc (
											   const int n_scat_max ,
											   const bool is_left_charged , 
											   const bool is_right_charged , 
											   const class array<class nlj_struct> &shells_qn_left ,
											   const class array<class nlj_struct> &shells_qn_right ,
											   class array<unsigned int> &dimensions_coupled ,
											   class array<unsigned int> &pairs_indices)
{

  const unsigned int N_nlj_baryon_left = shells_qn_left.dimension (0);
  
  const unsigned int N_nlj_baryon_right = shells_qn_right.dimension (0);
  
  const bool is_it_to_be_ordered = (is_left_charged == is_right_charged);
  
  const int Jmax_global_plus_one = Jmax_global + 1;
  
  const int strangeness_max_global_plus_one = strangeness_max_global + 1;

  const unsigned int i_charge_max_global_plus_one = i_charge_max_global + 1;
  
  dimensions_coupled.allocate (2 , strangeness_max_global_plus_one , i_charge_max_global_plus_one , Jmax_global_plus_one);

  dimensions_coupled = 0;

  pairs_indices.allocate (Jmax_global_plus_one , N_nlj_baryon_left , N_nlj_baryon_right);

  pairs_indices = INFINITE_PAIR_INDEX;

  for (unsigned int right = 0 ; right < N_nlj_baryon_right ; right++)
    for (unsigned int left = 0 ; (is_it_to_be_ordered) ? (left <= right) : (left < N_nlj_baryon_left) ; left++)
      {
	const class nlj_struct &shell_qn_left  = shells_qn_left (left);
	const class nlj_struct &shell_qn_right = shells_qn_right(right);
			      
	const enum particle_type particle_left  = shell_qn_left.get_particle ();
	const enum particle_type particle_right = shell_qn_right.get_particle ();
	  
	const class pair_str pair(particle_left , left , particle_right , right);
	
	const bool are_there_frozen_states = pair.are_there_frozen_states_determine (shells_qn_left , shells_qn_right);
					  
	const bool are_there_spectator_states = pair.are_there_spectator_states_determine ();

	if (!are_there_frozen_states && !are_there_spectator_states)
	  {
	    const unsigned int bp = pair.bp_determine (shells_qn_left , shells_qn_right);
	
	    const int strangeness = pair.strangeness_determine ();
	
	    const unsigned int i_charge = pair.charge_index_determine ();
		    
	    if ((bp >= BPmin_global) && (bp <= BPmax_global) && (i_charge >= i_charge_min_global) && (i_charge <= i_charge_max_global) && (strangeness >= strangeness_min_global) && (strangeness <= strangeness_max_global))
	      {
		const int n_scat = pair.n_scat_determine (shells_qn_left , shells_qn_right);
	
		if (n_scat <= n_scat_max)
		  {
		    const int Jmin_local = pair.Jmin_determine (shells_qn_left , shells_qn_right) , Jmin = max (Jmin_local , Jmin_global);
		    const int Jmax_local = pair.Jmax_determine (shells_qn_left , shells_qn_right) , Jmax = min (Jmax_local , Jmax_global);
		    
		    for (int J = Jmin ; J <= Jmax ; J++) pairs_indices(J , left , right) = dimensions_coupled(bp , strangeness , i_charge , J)++;
		  }
	      }
	  }
      }
}

void TBMEs_class::bp_i_charge_strangeness_tables_from_shells_quantum_numbers_shells_indices_from_nlj_indices_tab_alloc_calc (
															     const bool is_left_charged , 
															     const bool is_right_charged , 
															     const class array<class nlj_struct> &shells_qn_left ,
															     const class array<class nlj_struct> &shells_qn_right ,
															     const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_left_tab ,
															     const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_right_tab)
{
  const unsigned int N_baryon_type_left = shells_inter_indices_from_nlj_indices_left_tab.dimension (0);

  const unsigned int N_baryon_type_right = shells_inter_indices_from_nlj_indices_right_tab.dimension (0);
  
  const unsigned int N_shells_left = Nmu_shells_from_shells_indices_from_nlj_indices_tab_calc (shells_inter_indices_from_nlj_indices_left_tab);

  const unsigned int N_shells_right = Nmu_shells_from_shells_indices_from_nlj_indices_tab_calc (shells_inter_indices_from_nlj_indices_right_tab);
    
  bp_table_out.allocate (N_shells_left , N_shells_right);
  
  strangeness_table_out.allocate (N_shells_left , N_shells_right);

  i_charge_table_out.allocate (N_shells_left , N_shells_right);
  
  for (unsigned int iB_left = 0 ; iB_left < N_baryon_type_left ; iB_left++)
    for (unsigned int iB_right = 0 ; iB_right < N_baryon_type_right ; iB_right++)
      {
	const enum particle_type B_left = baryon_from_charge_index_determine (is_left_charged , iB_left);
	 
	const enum particle_type B_right = baryon_from_charge_index_determine (is_right_charged , iB_right);
	      
	const int strangeness = two_baryon_state_strangeness_determine (B_left , B_right);
	 	    
	const unsigned int i_charge = two_baryon_state_charge_index_determine (B_left , B_right);
												   
	const class array<unsigned int> &shells_inter_indices_from_nlj_indices_B_left = shells_inter_indices_from_nlj_indices_left_tab(iB_left);
	 
	const class array<unsigned int> &shells_inter_indices_from_nlj_indices_B_right = shells_inter_indices_from_nlj_indices_right_tab(iB_right);

	const unsigned int N_shells_B_left = shells_inter_indices_from_nlj_indices_B_left.dimension (0);
	 
	const unsigned int N_shells_B_right = shells_inter_indices_from_nlj_indices_B_right.dimension (0);

	for (unsigned int s_left = 0 ; s_left < N_shells_B_left ; s_left++)
	  for (unsigned int s_right = 0 ; s_right < N_shells_B_right ; s_right++)
	    {	      
	      const unsigned int left = shells_inter_indices_from_nlj_indices_B_left(s_left);
	      
	      const unsigned int right = shells_inter_indices_from_nlj_indices_B_right(s_right);
	      
	      const class pair_str pair(B_left , left , B_right , right);
		  
	      const unsigned int bp = pair.bp_determine (shells_qn_left , shells_qn_right);
	      
	      bp_table_out(left , right) = bp;
	      
	      strangeness_table_out(left , right) = strangeness;
		  
	      i_charge_table_out(left , right) = i_charge;
	    }
      }
}

void TBMEs_class::dimensions_coupled_pairs_indices_from_shells_quantum_numbers_shells_indices_from_nlj_indices_tab_alloc_calc (
															       const int n_scat_max , 
															       const bool is_left_charged , 
															       const bool is_right_charged , 
															       const class array<class nlj_struct> &shells_qn_left ,
															       const class array<class nlj_struct> &shells_qn_right ,
															       const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_left_tab ,
															       const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_right_tab ,
															       class array<unsigned int> &dimensions_coupled ,
															       class array<unsigned int> &pairs_indices)
{
  const unsigned int N_nlj_baryon_left = shells_qn_left.dimension (0);
  
  const unsigned int N_nlj_baryon_right = shells_qn_right.dimension (0);
  
  const unsigned int N_baryon_type_left = shells_inter_indices_from_nlj_indices_left_tab.dimension (0);

  const unsigned int N_baryon_type_right = shells_inter_indices_from_nlj_indices_right_tab.dimension (0);

  const bool is_it_to_be_ordered = (is_left_charged == is_right_charged);
      
  const int Jmax_global_plus_one = Jmax_global + 1;
  
  const int strangeness_max_global_plus_one = strangeness_max_global + 1;

  const unsigned int i_charge_max_global_plus_one = i_charge_max_global + 1;

  dimensions_coupled.allocate (2 , strangeness_max_global_plus_one , i_charge_max_global_plus_one , Jmax_global_plus_one);

  dimensions_coupled = 0;

  pairs_indices.allocate (Jmax_global_plus_one , N_nlj_baryon_left , N_nlj_baryon_right);

  pairs_indices = INFINITE_PAIR_INDEX;
    
  for (unsigned int iB_left = 0 ; iB_left < N_baryon_type_left ; iB_left++)
    for (unsigned int iB_right = 0 ; iB_right < N_baryon_type_right ; iB_right++)
      {
	const enum particle_type B_left = baryon_from_charge_index_determine (is_left_charged , iB_left);
	 
	const enum particle_type B_right = baryon_from_charge_index_determine (is_right_charged , iB_right);

	const int strangeness = two_baryon_state_strangeness_determine (B_left , B_right);
	 	    	
	const unsigned int i_charge = two_baryon_state_charge_index_determine (B_left , B_right);
	    
	if ((i_charge >= i_charge_min_global) && (i_charge <= i_charge_max_global) && (strangeness >= strangeness_min_global) && (strangeness <= strangeness_max_global))
	  {
	    const class array<unsigned int> &shells_inter_indices_from_nlj_indices_B_left = shells_inter_indices_from_nlj_indices_left_tab(iB_left);
	    
	    const class array<unsigned int> &shells_inter_indices_from_nlj_indices_B_right  = shells_inter_indices_from_nlj_indices_right_tab(iB_right);
	    
	    const unsigned int N_shells_B_left = shells_inter_indices_from_nlj_indices_B_left.dimension (0);

	    const unsigned int N_shells_B_right  = shells_inter_indices_from_nlj_indices_B_right.dimension (0);
 
	    for (unsigned int s_left = 0 ; s_left < N_shells_B_left ; s_left++)
	      for (unsigned int s_right = 0 ; s_right < N_shells_B_right ; s_right++)
		{
		  const unsigned int left = shells_inter_indices_from_nlj_indices_B_left(s_left);
	      
		  const unsigned int right = shells_inter_indices_from_nlj_indices_B_right(s_right);
	      
		  const class pair_str pair(B_left , left , B_right , right);
	
		  const bool are_there_frozen_states = pair.are_there_frozen_states_determine (shells_qn_left , shells_qn_right);
					  
		  const bool are_there_spectator_states = pair.are_there_spectator_states_determine ();

		  if (!are_there_frozen_states && !are_there_spectator_states)
		    {
		      const unsigned int bp = pair.bp_determine (shells_qn_left , shells_qn_right);
	      
		      const int n_scat = pair.n_scat_determine (shells_qn_left , shells_qn_right);

		      if ((n_scat <= n_scat_max) && (bp >= BPmin_global) && (bp <= BPmax_global))
			{
			  const int Jmin_local = pair.Jmin_determine (shells_qn_left , shells_qn_right) , Jmin = max (Jmin_local , Jmin_global);
			  const int Jmax_local = pair.Jmax_determine (shells_qn_left , shells_qn_right) , Jmax = min (Jmax_local , Jmax_global);
		    
			  if (!is_it_to_be_ordered || (left <= right))
			    {
			      for (int J = Jmin ; J <= Jmax ; J++) pairs_indices(J , left , right) = dimensions_coupled(bp , strangeness , i_charge , J)++;
			    }}}}}}
}

void TBMEs_class::dimensions_sum_dimensions_table_symmetric_space_alloc_calc_init ()
{
  const int Jmax_global_plus_one = Jmax_global + 1;
  
  const int strangeness_max_global_plus_one = strangeness_max_global + 1;

  const unsigned int i_charge_max_global_plus_one = i_charge_max_global + 1;
  
  class array<unsigned int> dimension_coupled_max_tab(2 , strangeness_max_global_plus_one , i_charge_max_global_plus_one);
			  
  dimension_coupled_max_tab = 0;

  for (unsigned int bp = BPmin_global ; bp <= BPmax_global ; bp++)
    for (int s = strangeness_min_global ; s <= strangeness_max_global ; s++)
      for (unsigned int ic = i_charge_min_global ; ic <= i_charge_max_global ; ic++)
	for (int J = Jmin_global ; J <= Jmax_global ; J++)
	  {
	    const unsigned int dimension_coupled = dimensions_coupled_out(bp , s , ic , J);
  
	    unsigned int &dimension_coupled_max = dimension_coupled_max_tab(bp , s , ic);
		  
	    dimension_coupled_max = max (dimension_coupled , dimension_coupled_max);
	  }
  
  unsigned int sum_dimensions_bef = 0;
	  
  unsigned int dimension_table = 0;
	  
  sum_dimensions_coupled_tabs.allocate (2 , strangeness_max_global_plus_one , i_charge_max_global_plus_one);
	  
  for (unsigned int bp = BPmin_global ; bp <= BPmax_global ; bp++)
    for (int s = strangeness_min_global ; s <= strangeness_max_global ; s++)
      for (unsigned int ic = i_charge_min_global ; ic <= i_charge_max_global ; ic++)
	{
	  const unsigned int dimension_coupled_max = dimension_coupled_max_tab(bp , s , ic);

	  class array<unsigned int> &sum_dimensions_coupled_tab = sum_dimensions_coupled_tabs(bp , s , ic);
	  
	  sum_dimensions_coupled_tab.allocate (Jmax_global_plus_one , dimension_coupled_max);
    
	  sum_dimensions_coupled_tab = 0;
	  
	  for (int J = Jmin_global ; J <= Jmax_global ; J++)
	    {
	      const unsigned int dimension_coupled_J = dimensions_coupled_out(bp , s , ic , J);
	  
	      for (unsigned int pair_index_in = 0 ; pair_index_in < dimension_coupled_J ; pair_index_in++)
		{
		  const unsigned int shift = dimension_coupled_J - pair_index_in;

		  unsigned int &sum_dimensions_coupled = sum_dimensions_coupled_tab(J , pair_index_in);
		
		  sum_dimensions_coupled = (pair_index_in == 0) ? (dimension_table) : (sum_dimensions_bef + shift);
		
		  dimension_table += shift;
		
		  sum_dimensions_bef = sum_dimensions_coupled;
		}
	    }
	}
  
  table.allocate (dimension_table);

  table = 0.0;
}




void TBMEs_class::dimensions_sum_dimensions_table_asymmetric_space_alloc_calc_init (const class array<unsigned int> &dimensions_coupled_in)
{
  const int Jmax_global_plus_one = Jmax_global + 1;
  
  const int strangeness_max_global_plus_one = strangeness_max_global + 1;

  const unsigned int i_charge_max_global_plus_one = i_charge_max_global + 1;
  
  unsigned int dimension_bef = 0;
  
  unsigned int sum_dimensions_bef = 0;
	  
  unsigned int dimension_table = 0;
	  
  sum_dimensions_coupled_tabs.allocate (2 , strangeness_max_global_plus_one , i_charge_max_global_plus_one);

  for (unsigned int bp = BPmin_global ; bp <= BPmax_global ; bp++)
    for (int s = strangeness_min_global ; s <= strangeness_max_global ; s++)
      for (unsigned int ic = i_charge_min_global ; ic <= i_charge_max_global ; ic++)
	{
	  class array<unsigned int> &sum_dimensions_coupled_tab = sum_dimensions_coupled_tabs(bp , s , ic);

	  sum_dimensions_coupled_tab.allocate (Jmax_global_plus_one);

	  sum_dimensions_coupled_tab = 0;
	  
	  for (int J = Jmin_global ; J <= Jmax_global ; J++)
	    {	      
	      const unsigned int dimension_coupled_in  = dimensions_coupled_in (bp , s , ic , J);
	      const unsigned int dimension_coupled_out = dimensions_coupled_out(bp , s , ic , J);
	  
	      const unsigned int dimension = dimension_coupled_in*dimension_coupled_out;
	    
	      unsigned int &sum_dimensions_coupled = sum_dimensions_coupled_tab(J);
	  
	      sum_dimensions_coupled = sum_dimensions_bef + dimension_bef;

	      dimension_table += dimension;

	      dimension_bef = dimension;

	      sum_dimensions_bef = sum_dimensions_coupled;
	    }
	}
  
  table.allocate (dimension_table);
  
  table = 0.0;
}

void TBMEs_class::allocate (
			    const bool is_there_cout , 
			    const bool is_it_only_basis , 
			    const class input_data_str &input_data , 
			    const class baryons_data &data)

{
  if (is_it_filled ()) error_message_print_abort ("TBMEs_class cannot be allocated twice in TBMEs_class::allocate (1)");

  const enum particle_type nucleonic_particle = data.get_nucleonic_particle ();

  const bool is_it_charged = (nucleonic_particle == PROTON);

  TBME_space = (nucleonic_particle == PROTON) ? (PROT_Y_ONLY) : (NEUT_Y_ONLY);

  BPmin_global = (is_it_charged) ? ((is_it_only_basis) ? (input_data.get_BPmin_global_pp_basis ()) : (input_data.get_BPmin_global_pp ())) : ((is_it_only_basis) ? (input_data.get_BPmin_global_nn_basis ()) : (input_data.get_BPmin_global_nn ()));  
  BPmax_global = (is_it_charged) ? ((is_it_only_basis) ? (input_data.get_BPmax_global_pp_basis ()) : (input_data.get_BPmax_global_pp ())) : ((is_it_only_basis) ? (input_data.get_BPmax_global_nn_basis ()) : (input_data.get_BPmax_global_nn ()));
  
  Jmin_global = (is_it_charged) ? ((is_it_only_basis) ? (input_data.get_Jmin_global_pp_basis ()) : (input_data.get_Jmin_global_pp ())) : ((is_it_only_basis) ? (input_data.get_Jmin_global_nn_basis ()) : (input_data.get_Jmin_global_nn ()));  
  Jmax_global = (is_it_charged) ? ((is_it_only_basis) ? (input_data.get_Jmax_global_pp_basis ()) : (input_data.get_Jmax_global_pp ())) : ((is_it_only_basis) ? (input_data.get_Jmax_global_nn_basis ()) : (input_data.get_Jmax_global_nn ()));
  
  strangeness_min_global = (is_it_charged) ? (input_data.get_strangeness_min_global_pp ()) : (input_data.get_strangeness_min_global_nn ());
  strangeness_max_global = (is_it_charged) ? (input_data.get_strangeness_max_global_pp ()) : (input_data.get_strangeness_max_global_nn ());
  
  i_charge_min_global = (is_it_charged) ? (input_data.get_i_charge_min_global_pp ()) : (input_data.get_i_charge_min_global_nn ());
  i_charge_max_global = (is_it_charged) ? (input_data.get_i_charge_max_global_pp ()) : (input_data.get_i_charge_max_global_nn ());
  
  is_it_mixed = false;
  
  const bool is_it_cluster_CM_HO_basis_calculation = input_data.get_is_it_cluster_CM_HO_basis_calculation ();

  const unsigned int N_nlj_baryon = (!is_it_cluster_CM_HO_basis_calculation) ? (data.get_N_nlj_baryon ()) : (data.get_N_nlj_res_baryon ());

  if (N_nlj_baryon == 0) return;

  const unsigned int N_valence_baryons = data.get_N_valence_baryons ();

  if (N_valence_baryons <= 1) return;
    
  const bool is_it_M_scheme = data.get_is_it_M_scheme ();

  const int n_scat_max = (!is_it_cluster_CM_HO_basis_calculation) ? (data.get_n_scat_max ()) : (0);

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
  
  if (is_it_M_scheme)
    {
      const class array<class nljm_struct> &phi_table = data.get_phi_table ();

      const unsigned int N_nljm_baryon = (!is_it_cluster_CM_HO_basis_calculation) ? (data.get_N_nljm_baryon ()) : (data.get_N_nljm_res_baryon ());

      const double m_max = data.get_m_max ();
      
      const double jmax = data.get_jmax ();

      const int Jmax_total = make_int (2.0*jmax);

      const int Jmax_total_plus_one = Jmax_total + 1;

      const class CG_str CGs(m_max);

      CG_antisymmetry_table.allocate (Jmax_total_plus_one , N_nljm_baryon , N_nljm_baryon);

      CG_antisymmetry_table = 0.0;
      
      Jmin_table.allocate (N_nljm_baryon , N_nljm_baryon);
      Jmax_table.allocate (N_nljm_baryon , N_nljm_baryon);

      class array<unsigned int> shells_indices(N_nljm_baryon);

      for (unsigned int index = 0 ; index < N_nljm_baryon ; index++) 
	{
	  const class nljm_struct &phi = phi_table(index);

	  const unsigned int shell_index = phi.get_shell_index ();

	  shells_indices(index) = shell_index;
	}

      for (unsigned int mu = 0 ; mu < N_nljm_baryon ; mu++)
	for (unsigned int mu_p = 0 ; mu_p < N_nljm_baryon ; mu_p++)
	  {
	    const class nljm_struct &phi   = phi_table(mu);
	    const class nljm_struct &phi_p = phi_table(mu_p);
	    
	    const double j = phi.get_j () , jp = phi_p.get_j ();
	    const double m = phi.get_m () , mp = phi_p.get_m ();
	    	    
	    const int M = make_int (m + mp);

	    const int abs_M = abs (M);

	    const int Jmin = abs (make_int (j - jp));
	    const int Jmax =      make_int (j + jp);

	    const bool is_there_antisymmetry_norm = same_nlj_particle (phi , phi_p);

	    Jmin_table(mu , mu_p) = Jmin;
	    Jmax_table(mu , mu_p) = Jmax; 

	    for (int J = Jmin ; J <= Jmax ; J++)
	      {
		if (abs_M <= J)
		  {
		    const double CG = CGs(j , m , jp , mp , J , M);
		    
		    CG_antisymmetry_table(J , mu , mu_p) = (is_there_antisymmetry_norm) ? (CG*M_SQRT2) : (CG);
		  }
	      }
	  }

      if (TBME_space == PROT_Y_ONLY) shells_indices_p.allocate_fill (shells_indices);
      if (TBME_space == NEUT_Y_ONLY) shells_indices_n.allocate_fill (shells_indices);
    }

  bp_i_charge_strangeness_tables_from_shells_quantum_numbers_alloc_calc (shells_qn , shells_qn);

  dimensions_coupled_pairs_indices_from_shells_quantum_numbers_alloc_calc (n_scat_max , is_it_charged , is_it_charged , shells_qn , shells_qn , dimensions_coupled_out , pairs_indices_out);

  pairs_indices_in.allocate_fill (pairs_indices_out);
  
  dimensions_sum_dimensions_table_symmetric_space_alloc_calc_init ();

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << "Coupled TBMEs " << physical_space_determine (TBME_space , strangeness_max_global) << ": " << used_memory_calc (*this) << " Mb" << endl << endl;
}






void TBMEs_class::allocate (
			    const bool is_there_cout , 
			    const bool is_it_only_basis , 
			    const class input_data_str &input_data , 
			    const class baryons_data &prot_Y_data , 
			    const class baryons_data &neut_Y_data)
{
  if (is_it_filled ()) error_message_print_abort ("TBMEs_class cannot be allocated twice in TBMEs_class::allocate (2)");

  TBME_space = PROT_NEUT_Y;

  BPmin_global = (is_it_only_basis) ? (input_data.get_BPmin_global_pn_basis ()) : (input_data.get_BPmin_global_pn ()); 
  BPmax_global = (is_it_only_basis) ? (input_data.get_BPmax_global_pn_basis ()) : (input_data.get_BPmax_global_pn ()); 

  Jmin_global = (is_it_only_basis) ? (input_data.get_Jmin_global_pn_basis ()) : (input_data.get_Jmin_global_pn ()); 
  Jmax_global = (is_it_only_basis) ? (input_data.get_Jmax_global_pn_basis ()) : (input_data.get_Jmax_global_pn ());

  strangeness_min_global = input_data.get_strangeness_min_global_pn ();
  strangeness_max_global = input_data.get_strangeness_max_global_pn ();
  
  i_charge_min_global = input_data.get_i_charge_min_global_pn ();
  i_charge_max_global = input_data.get_i_charge_max_global_pn ();
  
  is_it_mixed = false;
    
  const enum space_type space = (is_it_only_basis) ? (input_data.get_basis_space ()) : (input_data.get_space ());
      
  if (space != PROT_NEUT_Y) return;

  const bool is_it_cluster_CM_HO_basis_calculation = input_data.get_is_it_cluster_CM_HO_basis_calculation ();
  
  const unsigned int Np_nlj_baryon = (!is_it_cluster_CM_HO_basis_calculation) ? (prot_Y_data.get_N_nlj_baryon ()) : (prot_Y_data.get_N_nlj_res_baryon ());
  const unsigned int Nn_nlj_baryon = (!is_it_cluster_CM_HO_basis_calculation) ? (neut_Y_data.get_N_nlj_baryon ()) : (neut_Y_data.get_N_nlj_res_baryon ());
      
  if ((Np_nlj_baryon == 0) || (Nn_nlj_baryon == 0)) return;

  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();
    
  const bool is_it_M_scheme = prot_Y_data.get_is_it_M_scheme ();

  const int n_scat_max = (!is_it_cluster_CM_HO_basis_calculation) ? (input_data.get_n_scat_max ()) : (0);
  
  if (is_it_M_scheme)
    {
      const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
      const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

      const unsigned int Np_nljm_baryon = (!is_it_cluster_CM_HO_basis_calculation) ? (prot_Y_data.get_N_nljm_baryon ()) : (prot_Y_data.get_N_nljm_res_baryon ());
      const unsigned int Nn_nljm_baryon = (!is_it_cluster_CM_HO_basis_calculation) ? (neut_Y_data.get_N_nljm_baryon ()) : (neut_Y_data.get_N_nljm_res_baryon ());
  
      const double jp_max = prot_Y_data.get_jmax () , mp_max = prot_Y_data.get_m_max ();
      const double jn_max = neut_Y_data.get_jmax () , mn_max = neut_Y_data.get_m_max ();

      const double m_max = max (mp_max , mn_max);
      
      const int Jmax_total = make_int (jp_max + jn_max);

      const int Jmax_total_plus_one = Jmax_total + 1;

      const class CG_str CGs(m_max);

      CG_antisymmetry_table.allocate (Jmax_total_plus_one , Np_nljm_baryon , Nn_nljm_baryon);

      CG_antisymmetry_table = 0.0;
      
      Jmin_table.allocate (Np_nljm_baryon , Nn_nljm_baryon);
      Jmax_table.allocate (Np_nljm_baryon , Nn_nljm_baryon);

      shells_indices_p.allocate (Np_nljm_baryon);
      shells_indices_n.allocate (Nn_nljm_baryon);

      for (unsigned int p = 0 ; p < Np_nljm_baryon ; p++) 
	{
	  const class nljm_struct &phi_p = phi_p_table(p);

	  const unsigned int shell_index_prot = phi_p.get_shell_index ();

	  shells_indices_p(p) = shell_index_prot;
	}

      for (unsigned int n = 0 ; n < Nn_nljm_baryon ; n++) 
	{
	  const class nljm_struct &phi_n = phi_n_table(n);

	  const unsigned int shell_index_neut = phi_n.get_shell_index ();

	  shells_indices_n(n) = shell_index_neut;
	}

      for (unsigned int p = 0 ; p < Np_nljm_baryon ; p++)
	for (unsigned int n = 0 ; n < Nn_nljm_baryon ; n++)
	  {
	    const class nljm_struct &phi_p = phi_p_table(p);
	    const class nljm_struct &phi_n = phi_n_table(n);
	    
	    const double jp = phi_p.get_j () , mp = phi_p.get_m ();	    
	    const double jn = phi_n.get_j () , mn = phi_n.get_m ();

	    const int M = make_int (mp + mn);

	    const int abs_M = abs (M);
	    
	    const int Jmin = abs (make_int (jp - jn));
	    const int Jmax =      make_int (jp + jn);

	    Jmin_table(p , n) = Jmin;
	    Jmax_table(p , n) = Jmax; 

	    for (int J = Jmin ; J <= Jmax ; J++)
	      {
		if (abs_M <= J) CG_antisymmetry_table(J , p , n) = CGs(jp , mp , jn , mn , J , M);
	      }
	  }
    }

  bp_i_charge_strangeness_tables_from_shells_quantum_numbers_alloc_calc (shells_qn_p , shells_qn_n);
  
  dimensions_coupled_pairs_indices_from_shells_quantum_numbers_alloc_calc (n_scat_max , true , false , shells_qn_p , shells_qn_n , dimensions_coupled_out , pairs_indices_out);
      
  pairs_indices_in.allocate_fill (pairs_indices_out);
  
  dimensions_sum_dimensions_table_symmetric_space_alloc_calc_init ();
    
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << "Coupled TBMEs " << physical_space_determine (PROT_NEUT_Y , strangeness_max_global) << ":" << used_memory_calc (*this) << " Mb" << endl << endl;
}



void TBMEs_class::allocate (
			    const bool is_there_cout , 
			    const class input_data_str &input_data , 
			    const class baryons_data &prot_Y_data , 
			    const class baryons_data &neut_Y_data)
{
  if (is_it_filled ()) error_message_print_abort ("TBMEs_class cannot be allocated twice in TBMEs_class::allocate (3)");

  TBME_space = PROT_NEUT_UNMIXED_Y;
  
  is_it_mixed = false;

  BPmin_global = max (input_data.get_BPmin_global_pp () , input_data.get_BPmin_global_nn ());
  BPmax_global = min (input_data.get_BPmax_global_pp () , input_data.get_BPmax_global_nn ());

  Jmin_global = max (input_data.get_Jmin_global_pp () , input_data.get_Jmin_global_nn ());
  Jmax_global = min (input_data.get_Jmax_global_pp () , input_data.get_Jmax_global_nn ());
  
  strangeness_min_global = max (input_data.get_strangeness_min_global_pp () , input_data.get_strangeness_min_global_nn ());
  strangeness_max_global = min (input_data.get_strangeness_max_global_pp () , input_data.get_strangeness_max_global_nn ());
  
  i_charge_min_global = max (input_data.get_i_charge_min_global_pp () , input_data.get_i_charge_min_global_nn ());
  i_charge_max_global = min (input_data.get_i_charge_max_global_pp () , input_data.get_i_charge_max_global_nn ());

  if (strangeness_max_global == 0) return;
  
  const enum space_type space = input_data.get_space ();
  
  if (space != PROT_NEUT_Y) return;
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();
  
  const unsigned int Np_nlj = shells_qn_p.dimension (0);
  const unsigned int Nn_nlj = shells_qn_n.dimension (0);
  
  if ((Np_nlj == 0) || (Nn_nlj == 0)) return;  
      
  const int n_scat_max_p = input_data.get_n_scat_max_p ();
  const int n_scat_max_n = input_data.get_n_scat_max_n ();
          
  class array<unsigned int> dimensions_coupled_in;
  
  bp_i_charge_strangeness_tables_from_shells_quantum_numbers_alloc_calc (shells_qn_n , shells_qn_n);
  
  dimensions_coupled_pairs_indices_from_shells_quantum_numbers_alloc_calc (n_scat_max_p , true  , true  , shells_qn_p , shells_qn_p , dimensions_coupled_in  , pairs_indices_in);
  dimensions_coupled_pairs_indices_from_shells_quantum_numbers_alloc_calc (n_scat_max_n , false , false , shells_qn_n , shells_qn_n , dimensions_coupled_out , pairs_indices_out);
  
  dimensions_sum_dimensions_table_asymmetric_space_alloc_calc_init (dimensions_coupled_in);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << "Coupled TBMEs pp-nn conversion: " << used_memory_calc (*this) << " Mb" << endl << endl;
}





void TBMEs_class::allocate (
			    const bool is_there_cout , 
			    const enum space_type TBME_space_c , 
			    const class input_data_str &input_data , 
			    const class array<class nlj_struct> &shells_qn ,
			    const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_tab)
{
  if (is_it_filled ()) error_message_print_abort ("TBMEs_class cannot be allocated twice in TBMEs_class::allocate (4)");

  TBME_space = TBME_space_c;
  
  if ((TBME_space != PROT_Y_ONLY) && (TBME_space != NEUT_Y_ONLY)) error_message_print_abort ("TBME space must be pp or nn in TBMEs_class::allocate (4)");

  is_it_mixed = false;

  const unsigned int N_nlj = shells_qn.dimension (0);
  
  if (N_nlj == 0) return;

  const bool is_it_charged = (TBME_space == PROT_Y_ONLY);
	  
  const double jp_max = input_data.get_jp_max ();
  const double jn_max = input_data.get_jn_max ();

  const double jmax = (is_it_charged) ? (jp_max) : (jn_max);
  
  BP_J_i_charge_strangeness_min_max_from_shells_quantum_numbers_shells_indices_from_nlj_indices_calc (is_it_charged , is_it_charged , jmax , jmax ,
												      shells_qn , shells_qn , shells_inter_indices_from_nlj_indices_tab , shells_inter_indices_from_nlj_indices_tab ,
												      BPmin_global , BPmax_global , Jmin_global , Jmax_global ,
												      strangeness_min_global , strangeness_max_global , i_charge_min_global , i_charge_max_global);
    
  const bool is_it_cluster_CM_HO_basis_calculation = input_data.get_is_it_cluster_CM_HO_basis_calculation ();
  
  const int n_scat_max_p = (!is_it_cluster_CM_HO_basis_calculation) ? (input_data.get_n_scat_max_p ()) : (0);
  const int n_scat_max_n = (!is_it_cluster_CM_HO_basis_calculation) ? (input_data.get_n_scat_max_n ()) : (0);
  
  const int n_scat_max = (is_it_charged) ? (n_scat_max_p) : (n_scat_max_n);
  
  bp_i_charge_strangeness_tables_from_shells_quantum_numbers_shells_indices_from_nlj_indices_tab_alloc_calc (is_it_charged , is_it_charged , shells_qn , shells_qn ,
													     shells_inter_indices_from_nlj_indices_tab , shells_inter_indices_from_nlj_indices_tab);

  dimensions_coupled_pairs_indices_from_shells_quantum_numbers_shells_indices_from_nlj_indices_tab_alloc_calc (n_scat_max , is_it_charged , is_it_charged ,
													       shells_qn , shells_qn , shells_inter_indices_from_nlj_indices_tab , shells_inter_indices_from_nlj_indices_tab ,
													       dimensions_coupled_out , pairs_indices_out);
  
  pairs_indices_in.allocate_fill (pairs_indices_out);
  
  dimensions_sum_dimensions_table_symmetric_space_alloc_calc_init ();
  
    if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << "Coupled TBMEs " << physical_space_determine (TBME_space , strangeness_max_global) << ": " << used_memory_calc (*this) << " Mb" << endl << endl;
}




void TBMEs_class::allocate (
			    const bool is_there_cout , 
			    const bool is_it_only_basis , 
			    const class input_data_str &input_data , 
			    const class array<class nlj_struct> &shells_qn_p , 
			    const class array<class nlj_struct> &shells_qn_n ,
			    const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_p_tab ,
			    const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_n_tab)
{
  if (is_it_filled ()) error_message_print_abort ("TBMEs_class cannot be allocated twice in TBMEs_class::allocate (5)");

  TBME_space = PROT_NEUT_Y;
  
  is_it_mixed = false;
  
  const enum space_type space = (is_it_only_basis) ? (input_data.get_basis_space ()) : (input_data.get_space ());
  
  if (space != PROT_NEUT_Y) return;

  const bool is_it_cluster_CM_HO_basis_calculation = input_data.get_is_it_cluster_CM_HO_basis_calculation ();
  
  const unsigned int Np_nlj = shells_qn_p.dimension (0);
  const unsigned int Nn_nlj = shells_qn_n.dimension (0);
  
  if ((Np_nlj == 0) || (Nn_nlj == 0)) return;
  
  const double jp_max = input_data.get_jp_max ();
  const double jn_max = input_data.get_jn_max ();
    
  BP_J_i_charge_strangeness_min_max_from_shells_quantum_numbers_shells_indices_from_nlj_indices_calc (true , false , jp_max , jn_max , shells_qn_p , shells_qn_n ,
												      shells_inter_indices_from_nlj_indices_p_tab , shells_inter_indices_from_nlj_indices_n_tab ,
												      BPmin_global , BPmax_global , Jmin_global , Jmax_global ,
												      strangeness_min_global , strangeness_max_global , i_charge_min_global , i_charge_max_global);
  
  const int n_scat_max = (!is_it_cluster_CM_HO_basis_calculation) ? (input_data.get_n_scat_max ()) : (0);
      
  bp_i_charge_strangeness_tables_from_shells_quantum_numbers_shells_indices_from_nlj_indices_tab_alloc_calc (true , false , shells_qn_p , shells_qn_n , shells_inter_indices_from_nlj_indices_p_tab , shells_inter_indices_from_nlj_indices_n_tab);

  dimensions_coupled_pairs_indices_from_shells_quantum_numbers_shells_indices_from_nlj_indices_tab_alloc_calc (n_scat_max , true , false , shells_qn_p , shells_qn_n ,
													       shells_inter_indices_from_nlj_indices_p_tab , shells_inter_indices_from_nlj_indices_n_tab ,
													       dimensions_coupled_out , pairs_indices_out);
    
  pairs_indices_in.allocate_fill (pairs_indices_out);
  
  dimensions_sum_dimensions_table_symmetric_space_alloc_calc_init ();
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << "Coupled TBMEs " << physical_space_determine (PROT_NEUT_Y , strangeness_max_global) << ":" << used_memory_calc (*this) << " Mb" << endl << endl;
}



void TBMEs_class::allocate (
			    const bool is_there_cout , 
			    const class input_data_str &input_data , 
			    const class array<class nlj_struct> &shells_qn_p , 
			    const class array<class nlj_struct> &shells_qn_n ,
			    const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_p_tab ,
			    const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_n_tab)
{
  if (is_it_filled ()) error_message_print_abort ("TBMEs_class cannot be allocated twice in TBMEs_class::allocate (6)");

  TBME_space = PROT_NEUT_UNMIXED_Y;
  
  is_it_mixed = false;
  
  const enum space_type space = input_data.get_space ();
  
  if (space != PROT_NEUT_Y) return;
  
  const unsigned int Np_nlj = shells_qn_p.dimension (0);
  const unsigned int Nn_nlj = shells_qn_n.dimension (0);
  
  if ((Np_nlj == 0) || (Nn_nlj == 0)) return;  
      
  const int n_scat_max_p = input_data.get_n_scat_max_p ();
  const int n_scat_max_n = input_data.get_n_scat_max_n ();
      
  const double jp_max = input_data.get_jp_max ();
  const double jn_max = input_data.get_jn_max ();
  
  unsigned int BPmin_global_pp , BPmax_global_pp , i_charge_min_global_pp , i_charge_max_global_pp;
  unsigned int BPmin_global_nn , BPmax_global_nn , i_charge_min_global_nn , i_charge_max_global_nn;
  
  int strangeness_min_global_pp , strangeness_max_global_pp , Jmin_global_pp , Jmax_global_pp;
  int strangeness_min_global_nn , strangeness_max_global_nn , Jmin_global_nn , Jmax_global_nn;
    
  BP_J_i_charge_strangeness_min_max_from_shells_quantum_numbers_shells_indices_from_nlj_indices_calc (true , true , jp_max , jp_max , shells_qn_p , shells_qn_p ,
												      shells_inter_indices_from_nlj_indices_p_tab , shells_inter_indices_from_nlj_indices_p_tab ,
												      BPmin_global_pp , BPmax_global_pp , Jmin_global_pp , Jmax_global_pp ,
												      strangeness_min_global_pp , strangeness_max_global_pp , i_charge_min_global_pp , i_charge_max_global_pp);
  
  BP_J_i_charge_strangeness_min_max_from_shells_quantum_numbers_shells_indices_from_nlj_indices_calc (false , false , jn_max , jn_max , shells_qn_n , shells_qn_n ,
												      shells_inter_indices_from_nlj_indices_n_tab , shells_inter_indices_from_nlj_indices_n_tab ,
												      BPmin_global_nn , BPmax_global_nn , Jmin_global_nn , Jmax_global_nn ,
												      strangeness_min_global_nn , strangeness_max_global_nn , i_charge_min_global_nn , i_charge_max_global_nn);
  
  strangeness_min_global = max (strangeness_min_global_pp , strangeness_min_global_nn) , i_charge_min_global = max (i_charge_min_global_pp , i_charge_min_global_nn);
  strangeness_max_global = min (strangeness_max_global_pp , strangeness_max_global_nn) , i_charge_max_global = min (i_charge_max_global_pp , i_charge_max_global_nn);
  
  if (strangeness_max_global == 0) return;
  
  BPmin_global = max (BPmin_global_pp , BPmin_global_nn) , Jmin_global = max (Jmin_global_pp , Jmin_global_nn);
  BPmax_global = min (BPmax_global_pp , BPmax_global_nn) , Jmax_global = min (Jmax_global_pp , Jmax_global_nn);
        
  class array<unsigned int> dimensions_coupled_in;
  
  bp_i_charge_strangeness_tables_from_shells_quantum_numbers_shells_indices_from_nlj_indices_tab_alloc_calc (false , false , shells_qn_n , shells_qn_n , shells_inter_indices_from_nlj_indices_n_tab , shells_inter_indices_from_nlj_indices_n_tab);

  dimensions_coupled_pairs_indices_from_shells_quantum_numbers_shells_indices_from_nlj_indices_tab_alloc_calc (n_scat_max_p , true , true , shells_qn_p , shells_qn_p ,
													       shells_inter_indices_from_nlj_indices_p_tab , shells_inter_indices_from_nlj_indices_p_tab ,
													       dimensions_coupled_in , pairs_indices_in);
  
  dimensions_coupled_pairs_indices_from_shells_quantum_numbers_shells_indices_from_nlj_indices_tab_alloc_calc (n_scat_max_n , false , false , shells_qn_n , shells_qn_n ,
													       shells_inter_indices_from_nlj_indices_n_tab , shells_inter_indices_from_nlj_indices_n_tab ,
													       dimensions_coupled_out , pairs_indices_out);
  
  dimensions_sum_dimensions_table_asymmetric_space_alloc_calc_init (dimensions_coupled_in);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << "Coupled TBMEs pp-nn conversion: " << used_memory_calc (*this) << " Mb" << endl << endl;
}



void TBMEs_class::allocate (
			    const bool is_there_cout ,
			    const bool is_it_cv ,
			    const class input_data_str &input_data , 
			    const class baryons_data &data , 
			    const enum interaction_type TBME_inter , 
			    const class array<class nlj_struct> &shells_inter_qn ,
			    const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_tab)
{
  if (is_it_filled ()) error_message_print_abort ("TBMEs_class cannot be allocated twice in TBMEs_class::allocate (7)");
  
  const bool is_it_cluster_CM_HO_basis_calculation = input_data.get_is_it_cluster_CM_HO_basis_calculation ();
    
  const unsigned int N_nlj_baryon = (!is_it_cluster_CM_HO_basis_calculation) ? (data.get_N_nlj_baryon ()) : (data.get_N_nlj_res_baryon ());
  
  const unsigned int N_nlj_inter = shells_inter_qn.dimension (0);
  
  if ((N_nlj_baryon == 0) || (N_nlj_inter == 0)) return;
  
  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();    

  const enum particle_type nucleonic_particle = data.get_nucleonic_particle ();
  
  const bool is_it_charged = (nucleonic_particle == PROTON);   
  
  const bool is_TBME_inter_mixed = is_it_mixed_determine (is_it_charged , TBME_inter);
      
  is_it_mixed = true;
  
  if (!is_TBME_inter_mixed) return;
  
  class array<unsigned int> dimensions_coupled_in;
      
  if (is_it_cv)
    {
      if (is_it_charged) error_message_print_abort ("Out two-body space must be nn with pp-nn conversion in TBMEs_class::allocate (7)");
          
      const int n_scat_max_p = (!is_it_cluster_CM_HO_basis_calculation) ? (input_data.get_n_scat_max_p ()) : (0);
      const int n_scat_max_n = (!is_it_cluster_CM_HO_basis_calculation) ? (input_data.get_n_scat_max_n ()) : (0);
      
      const class array<class nlj_struct> &shells_inter_qn_p = shells_inter_qn;
  
      const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_p_tab = shells_inter_indices_from_nlj_indices_tab;
          
      const class array<class array<unsigned int> > dummy_shells_inter_indices_from_nlj_indices_n_tab;
      
      const class array<class nlj_struct> &shells_qn_n = shells_qn;
      
      const double jp_max = input_data.get_jp_max ();
      const double jn_max = input_data.get_jn_max ();

      unsigned int BPmin_global_pp , BPmax_global_pp , i_charge_min_global_pp , i_charge_max_global_pp;
      unsigned int BPmin_global_nn , BPmax_global_nn , i_charge_min_global_nn , i_charge_max_global_nn;
  
      int strangeness_min_global_pp , strangeness_max_global_pp , Jmin_global_pp , Jmax_global_pp;
      int strangeness_min_global_nn , strangeness_max_global_nn , Jmin_global_nn , Jmax_global_nn;
          
      BP_J_i_charge_strangeness_min_max_from_shells_quantum_numbers_shells_indices_from_nlj_indices_calc (true , true , jp_max , jp_max , shells_inter_qn_p , shells_inter_qn_p ,
													  shells_inter_indices_from_nlj_indices_p_tab , shells_inter_indices_from_nlj_indices_p_tab ,
													  BPmin_global_pp , BPmax_global_pp , Jmin_global_pp , Jmax_global_pp ,
													  strangeness_min_global_pp , strangeness_max_global_pp , i_charge_min_global_pp , i_charge_max_global_pp);
      
      BP_J_i_charge_strangeness_min_max_from_shells_quantum_numbers_shells_indices_from_nlj_indices_calc (false , false , jn_max , jn_max , shells_qn_n , shells_qn_n ,
													  dummy_shells_inter_indices_from_nlj_indices_n_tab , dummy_shells_inter_indices_from_nlj_indices_n_tab ,
													  BPmin_global_nn , BPmax_global_nn , Jmin_global_nn , Jmax_global_nn ,
													  strangeness_min_global_nn , strangeness_max_global_nn , i_charge_min_global_nn , i_charge_max_global_nn);
  
      TBME_space = PROT_NEUT_UNMIXED_Y;
      
      strangeness_min_global = max (strangeness_min_global_pp , strangeness_min_global_nn) , i_charge_min_global = max (i_charge_min_global_pp , i_charge_min_global_nn);
      strangeness_max_global = min (strangeness_max_global_pp , strangeness_max_global_nn) , i_charge_max_global = min (i_charge_max_global_pp , i_charge_max_global_nn);
      
      BPmin_global = max (BPmin_global_pp , BPmin_global_nn) , Jmin_global = max (Jmin_global_pp , Jmin_global_nn);
      BPmax_global = min (BPmax_global_pp , BPmax_global_nn) , Jmax_global = min (Jmax_global_pp , Jmax_global_nn);
          
      if (strangeness_max_global == 0) return;
  
      bp_i_charge_strangeness_tables_from_shells_quantum_numbers_alloc_calc (shells_qn_n , shells_qn_n);

      dimensions_coupled_pairs_indices_from_shells_quantum_numbers_shells_indices_from_nlj_indices_tab_alloc_calc (n_scat_max_p , true , true , shells_inter_qn_p , shells_inter_qn_p ,
														   shells_inter_indices_from_nlj_indices_p_tab , shells_inter_indices_from_nlj_indices_p_tab ,
														   dimensions_coupled_in , pairs_indices_in);
      
      dimensions_coupled_pairs_indices_from_shells_quantum_numbers_alloc_calc (n_scat_max_n , false , false , shells_qn_n , shells_qn_n , dimensions_coupled_out , pairs_indices_out);
    }
  else
    {
      const int n_scat_max = (!is_it_cluster_CM_HO_basis_calculation) ? (data.get_n_scat_max ()) : (0);
  
      const double jmax = data.get_jmax ();
    
      TBME_space = (is_it_charged) ? (PROT_Y_ONLY) : (NEUT_Y_ONLY);
      
      BP_J_i_charge_strangeness_min_max_from_shells_quantum_numbers_shells_indices_from_nlj_indices_calc (is_it_charged , is_it_charged , jmax , jmax , shells_qn , shells_qn ,
													  shells_inter_indices_from_nlj_indices_tab , shells_inter_indices_from_nlj_indices_tab ,
													  BPmin_global , BPmax_global , Jmin_global , Jmax_global ,
													  strangeness_min_global , strangeness_max_global , i_charge_min_global , i_charge_max_global);
        
      bp_i_charge_strangeness_tables_from_shells_quantum_numbers_alloc_calc (shells_qn , shells_qn);
      
      dimensions_coupled_pairs_indices_from_shells_quantum_numbers_shells_indices_from_nlj_indices_tab_alloc_calc (n_scat_max , is_it_charged , is_it_charged , shells_inter_qn , shells_inter_qn ,
														   shells_inter_indices_from_nlj_indices_tab , shells_inter_indices_from_nlj_indices_tab ,
														   dimensions_coupled_in , pairs_indices_in);
      
      dimensions_coupled_pairs_indices_from_shells_quantum_numbers_alloc_calc (n_scat_max , is_it_charged , is_it_charged , shells_qn , shells_qn , dimensions_coupled_out , pairs_indices_out);
    }
      
  dimensions_sum_dimensions_table_asymmetric_space_alloc_calc_init (dimensions_coupled_in);
    
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      if (is_it_cv)
	cout << "Coupled TBMEs mixed pp-nn conversion: " << used_memory_calc (*this) << " Mb" << endl << endl;
      else
	cout << "Coupled TBMEs mixed " << physical_space_determine (TBME_space , strangeness_max_global) << ": " << used_memory_calc (*this) << " Mb" << endl << endl;
    }
}






void TBMEs_class::allocate (
			    const bool is_there_cout , 
			    const bool is_it_only_basis , 
			    const class input_data_str &input_data , 
			    const class baryons_data &prot_Y_data , 
			    const class baryons_data &neut_Y_data , 
			    const enum interaction_type TBME_inter , 
			    const class array<class nlj_struct> &shells_inter_qn_p ,
			    const class array<class nlj_struct> &shells_inter_qn_n ,
			    const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_p_tab ,
			    const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_n_tab)
{
  if (is_it_filled ()) error_message_print_abort ("TBMEs_class cannot be allocated twice in TBMEs_class::allocate (8)");

  TBME_space = PROT_NEUT_Y;

  BPmin_global = (is_it_only_basis) ? (input_data.get_BPmin_global_pn_basis ()) : (input_data.get_BPmin_global_pn ()); 
  BPmax_global = (is_it_only_basis) ? (input_data.get_BPmax_global_pn_basis ()) : (input_data.get_BPmax_global_pn ()); 

  Jmin_global = (is_it_only_basis) ? (input_data.get_Jmin_global_pn_basis ()) : (input_data.get_Jmin_global_pn ()); 
  Jmax_global = (is_it_only_basis) ? (input_data.get_Jmax_global_pn_basis ()) : (input_data.get_Jmax_global_pn ());

  strangeness_min_global = input_data.get_strangeness_min_global_pn ();
  strangeness_max_global = input_data.get_strangeness_max_global_pn ();
  
  i_charge_min_global = input_data.get_i_charge_min_global_pn ();
  i_charge_max_global = input_data.get_i_charge_max_global_pn ();
  
  is_it_mixed = true;

  const enum space_type space = (is_it_only_basis) ? (input_data.get_basis_space ()) : (input_data.get_space ());

  if (space != PROT_NEUT_Y) return;

  const bool is_it_baryonic_mixed = is_it_baryonic_mixed_determine (TBME_inter);

  if (!is_it_baryonic_mixed) return;

  const bool is_it_cluster_CM_HO_basis_calculation = input_data.get_is_it_cluster_CM_HO_basis_calculation ();

  const unsigned int Np_nlj_baryon = (!is_it_cluster_CM_HO_basis_calculation) ? (prot_Y_data.get_N_nlj_baryon ()) : (prot_Y_data.get_N_nlj_res_baryon ());
  const unsigned int Nn_nlj_baryon = (!is_it_cluster_CM_HO_basis_calculation) ? (neut_Y_data.get_N_nlj_baryon ()) : (neut_Y_data.get_N_nlj_res_baryon ());

  const unsigned int Np_nlj_inter = shells_inter_qn_p.dimension (0);
  const unsigned int Nn_nlj_inter = shells_inter_qn_n.dimension (0);
  
  if ((Np_nlj_baryon == 0) || (Nn_nlj_baryon == 0) || (Np_nlj_inter == 0) || (Nn_nlj_inter == 0)) return;

  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();
  
  const double jp_max = input_data.get_jp_max ();
  const double jn_max = input_data.get_jn_max ();
    
  BP_J_i_charge_strangeness_min_max_from_shells_quantum_numbers_shells_indices_from_nlj_indices_calc (true , false , jp_max , jn_max , shells_inter_qn_p , shells_inter_qn_n ,
												      shells_inter_indices_from_nlj_indices_p_tab , shells_inter_indices_from_nlj_indices_n_tab ,
												      BPmin_global , BPmax_global , Jmin_global , Jmax_global ,
												      strangeness_min_global , strangeness_max_global , i_charge_min_global , i_charge_max_global);
  
  const int n_scat_max = (!is_it_cluster_CM_HO_basis_calculation) ? (input_data.get_n_scat_max ()) : (0);
    
  bp_i_charge_strangeness_tables_from_shells_quantum_numbers_alloc_calc (shells_qn_p , shells_qn_n);

  class array<unsigned int> dimensions_coupled_in;

  dimensions_coupled_pairs_indices_from_shells_quantum_numbers_shells_indices_from_nlj_indices_tab_alloc_calc (n_scat_max , true , false , shells_inter_qn_p , shells_inter_qn_n ,
													       shells_inter_indices_from_nlj_indices_p_tab , shells_inter_indices_from_nlj_indices_n_tab ,
													       dimensions_coupled_in , pairs_indices_in);
      
  dimensions_coupled_pairs_indices_from_shells_quantum_numbers_alloc_calc (n_scat_max , true , false , shells_qn_p , shells_qn_n , dimensions_coupled_out , pairs_indices_out);

  dimensions_sum_dimensions_table_asymmetric_space_alloc_calc_init (dimensions_coupled_in);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << "Coupled TBMEs mixed " << physical_space_determine (TBME_space , strangeness_max_global) << ": " << used_memory_calc (*this) << " Mb" << endl << endl;
}






void TBMEs_class::allocate_fill (const class TBMEs_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("TBMEs_class cannot be allocated twice in TBMEs_class::allocate_fill");

  TBME_space = X.TBME_space; 

  BPmin_global = X.BPmin_global; 
  BPmax_global = X.BPmax_global; 

  Jmin_global = X.Jmin_global; 
  Jmax_global = X.Jmax_global; 

  strangeness_min_global = X.strangeness_min_global;
  strangeness_max_global = X.strangeness_max_global;
  
  i_charge_min_global = X.i_charge_min_global;
  i_charge_max_global = X.i_charge_max_global;
  
  is_it_mixed = X.is_it_mixed; 

  CG_antisymmetry_table.allocate_fill (X.CG_antisymmetry_table);

  Jmin_table.allocate_fill (X.Jmin_table);
  Jmax_table.allocate_fill (X.Jmax_table);

  shells_indices_p.allocate_fill (X.shells_indices_p);
  shells_indices_n.allocate_fill (X.shells_indices_n);
  
  dimensions_coupled_out.allocate_fill (X.dimensions_coupled_out);

  sum_dimensions_coupled_tabs.allocate_fill (X.sum_dimensions_coupled_tabs);

  bp_table_out.allocate_fill (X.bp_table_out);
  
  strangeness_table_out.allocate_fill (X.strangeness_table_out);

  i_charge_table_out.allocate_fill (X.i_charge_table_out);
  
  pairs_indices_in.allocate_fill (X.pairs_indices_in);
  
  pairs_indices_out.allocate_fill (X.pairs_indices_out);

  table.allocate_fill (X.table);
}




void TBMEs_class::deallocate ()
{ 
  CG_antisymmetry_table.deallocate ();

  Jmin_table.deallocate ();
  Jmax_table.deallocate ();

  shells_indices_p.deallocate ();
  shells_indices_n.deallocate ();

  dimensions_coupled_out.deallocate ();

  sum_dimensions_coupled_tabs.deallocate ();

  bp_table_out.deallocate ();
  
  strangeness_table_out.deallocate ();

  i_charge_table_out.deallocate ();
  
  pairs_indices_in.deallocate ();
  
  pairs_indices_out.deallocate ();

  table.deallocate ();
  
  TBME_space = NO_SPACE;

  BPmin_global = 0;
  BPmax_global = 0;

  Jmin_global = 0;
  Jmax_global = 0;

  strangeness_min_global = 0;
  strangeness_max_global = 0;
  
  i_charge_min_global = 0;
  i_charge_max_global = 0;
  
  is_it_mixed = false;
}


void TBMEs_class::zero ()
{
  table = 0.0;
}  



void TBMEs_class::corrective_factor_multiplication (const TYPE &corrective_factor)
{
  table *= corrective_factor;
}







// Calculation of one-dimensional indices for mixed TBME arrays
// ------------------------------------------------------------
// The first index of a (bp,s,c,J) TBME is sum_dimensions_coupled_tabs(bp , s , ic)(J), which sums all previous dimensions of previous Js.
// Then, as a TBME writes <out | V | in>, where |in> and |out> belong to different spaces, its local index in the (bp,s,c,J) subsection of the TBME array is pair_index_out + dimensions_coupled_out(bp , s , ic , J) . pair_index_in .
// The full index is then sum of the sum of dimensions and of the local index

unsigned int TBMEs_class::coupled_TBME_mixed_index_determine (
							      const int J , 
							      const unsigned int left_in , 
							      const unsigned int right_in , 
							      const unsigned int left_out , 
							      const unsigned int right_out) const
{
  const unsigned int bp = bp_table_out(left_out , right_out);

  const int s = strangeness_table_out(left_out , right_out);
  
  const unsigned int ic = i_charge_table_out(left_out , right_out);
	
  const class array<unsigned int> &sum_dimensions_coupled_tab = sum_dimensions_coupled_tabs(bp , s , ic);
  
  const unsigned int pair_index_in  = pairs_indices_in (J , left_in  , right_in);
  const unsigned int pair_index_out = pairs_indices_out(J , left_out , right_out);

  const unsigned int index = pair_index_out + dimensions_coupled_out(bp , s , ic , J)*pair_index_in + sum_dimensions_coupled_tab(J);
  
  return index;
}


// Calculation of one-dimensional indices for Berggren basis TBME arrays
// ---------------------------------------------------------------------
// Here |in> and |out> belong to the same space.
// As <out | V | in> TBMEs are symmetric and as one takes symmetry into account, one always demands pair_index_in <= pair_index_out. Pairs are exchanged otherwise.
//
// One considers the sum of dimensions which sums all previous dimensions of previous Js and all the pairs_indices_out with angular momentum J up to pair_index_in excluded.
// One has to include all the pairs_indices_out with angular momentum J up to pair_index_in excluded as symmetry is included.
// The full index is then sum of the sum of dimensions and of pair_index_out.

unsigned int TBMEs_class::coupled_TBME_index_determine (
							const int J , 
							const unsigned int left_in , 
							const unsigned int right_in , 
							const unsigned int left_out , 
							const unsigned int right_out) const
{
  const unsigned int bp = bp_table_out(left_out , right_out);
	
  const int s = strangeness_table_out(left_out , right_out);

  const unsigned int ic = i_charge_table_out(left_out , right_out);
  
  const class array<unsigned int> &sum_dimensions_coupled_tab = sum_dimensions_coupled_tabs(bp , s , ic);
	  
  const unsigned int pair_index_in  = pairs_indices_in (J , left_in  , right_in);
  const unsigned int pair_index_out = pairs_indices_out(J , left_out , right_out);
  
  const unsigned int index = (pair_index_in <= pair_index_out) ? (pair_index_out + sum_dimensions_coupled_tab(J , pair_index_in)) : (pair_index_in + sum_dimensions_coupled_tab(J , pair_index_out));

  return index;
}


unsigned int TBMEs_class::index_determine (
					   const int J , 
					   const unsigned int left_in , 
					   const unsigned int right_in , 
					   const unsigned int left_out , 
					   const unsigned int right_out) const
{
  if (is_it_mixed)
    return coupled_TBME_mixed_index_determine (J , left_in , right_in , left_out , right_out);
  else
    return coupled_TBME_index_determine (J , left_in , right_in , left_out , right_out);
}

TYPE & TBMEs_class::operator () (
				 const int J , 
				 const unsigned int left_in , 
				 const unsigned int right_in , 
				 const unsigned int left_out , 
				 const unsigned int right_out) const
{
  const unsigned int index = index_determine (J , left_in , right_in , left_out , right_out);

  return table(index);
}

TYPE & TBMEs_class::operator [] (const unsigned int index) const
{
  return table(index);
}


// Uncoupled TBME calculated from coupled TBMEs
// --------------------------------------------
// One uses the standard formula <out | V | in>_M = \sum_J <out | V | in>_J <jc jd | J M> <ja jb | J M> sqrt(1 + delta_ab) sqrt(1 + delta_cd)
// (a,b,d,c) are denoted as (left_in,right_in,left_out_right_out).
// All Jmin, Jmax, Clebsch-Gordan coefficients and antisymmetry normalization factors and stored.
// The time taken to recalculate the TBME is fact comparable to that spent looking for values in large arrays, so that using this routine in "on the fly" calculations is rather efficient.

TYPE TBMEs_class::M_TBME (
			  const bool is_it_cv_pp_to_nn ,
			  const unsigned int left_in , 
			  const unsigned int right_in , 
			  const unsigned int left_out , 
			  const unsigned int right_out) const

{
  const class TBMEs_class &J_TBMEs_class = *this;
   
  const int Jmin_in  = Jmin_table(left_in  , right_in) , Jmin_out = Jmin_table(left_out , right_out) , Jmin = max (Jmin_in , Jmin_out);
  const int Jmax_in  = Jmax_table(left_in  , right_in) , Jmax_out = Jmax_table(left_out , right_out) , Jmax = min (Jmax_in , Jmax_out);

  TYPE M_TBME_value = 0.0;

  switch (TBME_space)
    {
    case PROT_Y_ONLY:
      {
	const unsigned int shell_left_in  = shells_indices_p(left_in)  , shell_right_in  = shells_indices_p(right_in);
	const unsigned int shell_left_out = shells_indices_p(left_out) , shell_right_out = shells_indices_p(right_out);

	for (int J = Jmin ; J <= Jmax ; J++)
	  {
	    const TYPE J_TBME_value = J_TBMEs_class(J , shell_left_in , shell_right_in , shell_left_out , shell_right_out);
      
	    const double CG_antisymmetry_in  = CG_antisymmetry_table(J , left_in  , right_in);
	    const double CG_antisymmetry_out = CG_antisymmetry_table(J , left_out , right_out);

	    M_TBME_value += CG_antisymmetry_in*CG_antisymmetry_out*J_TBME_value;
	  }
      } break;
      
    case NEUT_Y_ONLY:
      {  
	const unsigned int shell_left_in  = shells_indices_n(left_in)  , shell_right_in  = shells_indices_n(right_in);
	const unsigned int shell_left_out = shells_indices_n(left_out) , shell_right_out = shells_indices_n(right_out);

	for (int J = Jmin ; J <= Jmax ; J++)
	  {
	    const TYPE J_TBME_value = J_TBMEs_class(J , shell_left_in , shell_right_in , shell_left_out , shell_right_out);
      
	    const double CG_antisymmetry_in  = CG_antisymmetry_table(J , left_in  , right_in);
	    const double CG_antisymmetry_out = CG_antisymmetry_table(J , left_out , right_out);

	    M_TBME_value += CG_antisymmetry_in*CG_antisymmetry_out*J_TBME_value;
	  }
      } break;
      
    case PROT_NEUT_Y:
      {  
	const unsigned int shell_left_in  = shells_indices_p(left_in)  , shell_right_in  = shells_indices_n(right_in);
	const unsigned int shell_left_out = shells_indices_p(left_out) , shell_right_out = shells_indices_n(right_out);

	for (int J = Jmin ; J <= Jmax ; J++)
	  {
	    const TYPE J_TBME_value = J_TBMEs_class(J , shell_left_in , shell_right_in , shell_left_out , shell_right_out);

	    const double CG_antisymmetry_in  = CG_antisymmetry_table(J , left_in  , right_in);
	    const double CG_antisymmetry_out = CG_antisymmetry_table(J , left_out , right_out);

	    M_TBME_value += CG_antisymmetry_in*CG_antisymmetry_out*J_TBME_value;
	  }
      } break;
      
    case PROT_NEUT_UNMIXED_Y:
      {
	if (is_it_cv_pp_to_nn)
	  {
	    const unsigned int shell_left_in  = shells_indices_p(left_in)  , shell_right_in  = shells_indices_p(right_in);
	    const unsigned int shell_left_out = shells_indices_n(left_out) , shell_right_out = shells_indices_n(right_out);

	    for (int J = Jmin ; J <= Jmax ; J++)
	      {
		const TYPE J_TBME_value = J_TBMEs_class(J , shell_left_in , shell_right_in , shell_left_out , shell_right_out);

		const double CG_antisymmetry_in  = CG_antisymmetry_table(J , left_in  , right_in);
		const double CG_antisymmetry_out = CG_antisymmetry_table(J , left_out , right_out);

		M_TBME_value += CG_antisymmetry_in*CG_antisymmetry_out*J_TBME_value;
	      }
	  }
	else
	  {
	    const unsigned int shell_left_in  = shells_indices_n(left_in)  , shell_right_in  = shells_indices_n(right_in);
	    const unsigned int shell_left_out = shells_indices_p(left_out) , shell_right_out = shells_indices_p(right_out);

	    for (int J = Jmin ; J <= Jmax ; J++)
	      {
		const TYPE J_TBME_value = J_TBMEs_class(J , shell_left_out , shell_right_out , shell_left_in , shell_right_in);

		const double CG_antisymmetry_in  = CG_antisymmetry_table(J , left_in  , right_in);
		const double CG_antisymmetry_out = CG_antisymmetry_table(J , left_out , right_out);

		M_TBME_value += CG_antisymmetry_in*CG_antisymmetry_out*J_TBME_value;
	      }    
	  }
      } break;
      
    default: abort_all ();
    }
	
  return M_TBME_value;
}


unsigned int TBMEs_class::first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
{
  return table.first_index_determine_for_MPI (group_processes_number , process);
}


unsigned int TBMEs_class::last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
{	
  return table.last_index_determine_for_MPI (group_processes_number , process);
}


#ifdef UseMPI

void TBMEs_class::MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm C)
{  
  table.MPI_Allgatherv (group_processes_number , C);
}


void TBMEs_class::MPI_Bcast (const unsigned int Send_process , const MPI_Comm C)
{  
  table.MPI_Bcast (Send_process , C);
}

#endif









void corrective_factor_TBMEs_modification (
					   const enum space_type space , 
					   const TYPE &corrective_factor , 
					   class baryons_data &prot_Y_data , 
					   class baryons_data &neut_Y_data , 
					   class TBMEs_class &TBMEs_pn ,
					   class TBMEs_class &TBMEs_cv)
{
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  if ((space != NEUT_Y_ONLY) && (ZYval >= 2))
    {
      class TBMEs_class &TBMEs_pp = prot_Y_data.get_TBMEs ();
      
      TBMEs_pp.corrective_factor_multiplication (corrective_factor);
    }

  if ((space != PROT_Y_ONLY) && (NYval >= 2))
    {
      class TBMEs_class &TBMEs_nn = neut_Y_data.get_TBMEs ();
      
      TBMEs_nn.corrective_factor_multiplication (corrective_factor);
    }

  if (space == PROT_NEUT_Y)
    {
      TBMEs_pn.corrective_factor_multiplication (corrective_factor);  
      TBMEs_cv.corrective_factor_multiplication (corrective_factor);
    }
}



// Read/copy of TBMEs on file
// --------------------------
// File is not formatted and reads for example on each line:
// "1  0p3/2 1s1/2  0p1/2 0s1/2  0.123456", with J = 1 here (proton-proton, neutron-neutron or proton-neutron case)
// "1  Lambda Lambda  Xi0 neutron 0p3/2 1s1/2 0p1/2 0s1/2  0.123456", with J = 1 here (pp, nn-nn, pn or pp-nn conversion case, with p a charged baryon and n an uncharged baryon)
// Two files are considered, one for the Hamiltonian interaction and one for the HO center of mass Hamiltonian Hcm.
// Trivial zeroes in terms of parity conservation and total angular momentum coulings are not written.
// (a,b,d,c) are denoted as (left_in,right_in,left_out_right_out) in <cd | V |ab>_J.
// <cd | Hcm |ab>_J are recalculated each time before being copied.
//
// When reading a file, one pays attention if a TBME stored on file belongs the current model space.
// If it does not, the code would crash if one tries to store it.
// Hence, all TBME values so that n > nmax and l > lmax for a one-body state are rejected.
// It is the same if their one-dimensional index is OUT_OF_RANGE (see const.h), which means that the one-body state is not part of the model space even though n <= nmax and l <= lmax.
// The TBME value is also rejected if the number of particles in the continuum of the two-body states is larger than that accepted.
// Moreover, as shell ordering can be different in the input file and in the model space, one checks for shell ordering and multiply by a (-1)^(ja + jb - J - 1) and/or (-1)^(jc + jd - J - 1) if a > b and/or c > d from the file.
// Note that all charged baryons and all uncharged baryons are antisymmetrized and generate an additional phase +/- 1 with reordering, as for identical baryons.
// This does not change results as this phase only generate a +/-1 overall phase in lines and columns of the Hamiltonian, or, equivalently, to a +/-1 overall phase in basis Slater determinants.
//
// These routines are defined with the GSM one-body Berggren basis.
// It is not to be used to read the TBMEs of interaction_class, using HO or GHF basis.


void TBMEs_class::copy_TBMEs_to_file (
				      const bool is_there_cout , 
				      const int n_scat_max , 
				      const enum interaction_type TBME_inter , 
				      const class baryons_data &particles_data_left , 
				      const class baryons_data &particles_data_right) const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in coupled_TBMEs::copy_TBMEs_to_file.");

  const class TBMEs_class &J_TBMEs_class = *this;
  
  const unsigned int N_nlj_baryon_left = particles_data_left.get_N_nlj_baryon ();
  const unsigned int N_nlj_baryon_right = particles_data_right.get_N_nlj_baryon ();

  const class array<class nlj_struct> &shells_qn_left = particles_data_left.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_right = particles_data_right.get_shells_quantum_numbers ();

  const class OBMEs_CM_set_str &reduced_grad_HO_expansion_left_set = particles_data_left.get_reduced_grad_HO_expansion_set ();
  const class OBMEs_CM_set_str &reduced_grad_HO_expansion_right_set = particles_data_right.get_reduced_grad_HO_expansion_set ();
  
  const class OBMEs_CM_set_str &reduced_r_HO_expansion_left_set = particles_data_left.get_reduced_r_HO_expansion_set ();
  const class OBMEs_CM_set_str &reduced_r_HO_expansion_right_set = particles_data_right.get_reduced_r_HO_expansion_set ();

  const string inter_file_string = STORAGE_DIR + "TBMEs_" + make_string<enum space_type> (physical_space_determine (TBME_space , strangeness_max_global)) + "_" + make_string<enum interaction_type> (TBME_inter);

  if (is_there_cout)
    {
      cout << endl << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;
      cout << inter_file_string << " are being copied on disk" << endl;
      cout << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl << endl;
    }
  
  const string Hcm_file_string = (TBME_inter == REALISTIC_INTERACTION)
    ? (STORAGE_DIR + make_string<enum space_type> (physical_space_determine (TBME_space , strangeness_max_global)) + "_" + make_string<enum interaction_type> (HCM_INTERACTION))
    : ("");

  ofstream munu_inter(inter_file_string.c_str ());

  ofstream munu_Hcm;
  
  munu_inter.precision(15);

  munu_inter.setf (ios::scientific);

  if (TBME_inter == REALISTIC_INTERACTION)
    {
      munu_Hcm.open (Hcm_file_string.c_str ());

      munu_Hcm.precision(15);

      munu_Hcm.setf (ios::scientific);
    }
  
  for (unsigned int s3 = 0 ; s3 < N_nlj_baryon_right ; s3++)
    for (unsigned int s2 = 0 ; (TBME_space == PROT_NEUT_Y) ? (s2 < N_nlj_baryon_left) : (s2 <= s3) ; s2++)
      {
	const class nlj_struct &shell_qn_s2 = shells_qn_left(s2);
	const class nlj_struct &shell_qn_s3 = shells_qn_right(s3);

	const enum particle_type B_s2 = shell_qn_s2.get_particle ();	
	const enum particle_type B_s3 = shell_qn_s3.get_particle ();
	
	const class pair_str pair_out(B_s2 , s2 , B_s3 , s3);
	      
	const int n_scat_out = pair_out.n_scat_determine (shells_qn_left , shells_qn_right);
	
	const unsigned int bp = pair_out.bp_determine (shells_qn_left , shells_qn_right);
	
	const int strangeness = pair_out.strangeness_determine ();
	
	const unsigned int i_charge = pair_out.charge_index_determine ();
	
	const int Jmin_out = pair_out.Jmin_determine (shells_qn_left , shells_qn_right);
	const int Jmax_out = pair_out.Jmax_determine (shells_qn_left , shells_qn_right);

	if (n_scat_out <= n_scat_max)
	  {
	    for (unsigned int s1 = 0 ; s1 < N_nlj_baryon_right ; s1++)
	      for (unsigned int s0 = 0 ; (TBME_space == PROT_NEUT_Y) ? (s0 < N_nlj_baryon_left) : (s0 <= s1) ; s0++)
		{
		  const class nlj_struct &shell_qn_s0 = shells_qn_left(s0);
		  const class nlj_struct &shell_qn_s1 = shells_qn_right(s1);

		  const enum particle_type B_s0 = shell_qn_s0.get_particle ();	
		  const enum particle_type B_s1 = shell_qn_s1.get_particle ();
				  
		  const class pair_str pair_in(B_s0 , s0 , B_s1 , s1);
		  
		  const int n_scat_in = pair_in.n_scat_determine (shells_qn_left , shells_qn_right);
		  if (n_scat_in <= n_scat_max)
		    { 
		      if (pair_in <= pair_out)
			{
			  const unsigned int bp_in = pair_in.bp_determine (shells_qn_left , shells_qn_right);
	
			  const int strangeness_in = pair_in.strangeness_determine ();
		
			  const unsigned int i_charge_in = pair_in.charge_index_determine ();
	
			  if ((bp >= BPmin_global) && (bp <= BPmax_global) && (i_charge >= i_charge_min_global) && (i_charge <= i_charge_max_global) && (strangeness >= strangeness_min_global) && (strangeness <= strangeness_max_global))
			    {
			      if ((bp_in == bp) && (strangeness_in == strangeness) && (i_charge_in == i_charge))
				{
	
				  const int Jmin_in = pair_in.Jmin_determine (shells_qn_left , shells_qn_right);
				  const int Jmax_in = pair_in.Jmax_determine (shells_qn_left , shells_qn_right);

				  const int Jmin_local = max (Jmin_in , Jmin_out) , Jmin = max (Jmin_local , Jmin_global);
				  const int Jmax_local = min (Jmax_in , Jmax_out) , Jmax = min (Jmax_local , Jmax_global);

				  if (Jmin <= Jmax)
				    {
				      for (int J = Jmin ; J <= Jmax ; J++)
					{
					  const TYPE TBME = J_TBMEs_class(J , s0 , s1 , s2 , s3);

					  if (TBME != 0.0)
					    {
					      if (strangeness_max_global == 0)
						munu_inter << J << " " << shell_qn_s0 << " " << shell_qn_s1 << " " << shell_qn_s2 << " " << shell_qn_s3 << " " << TBME << endl;
					      else
						munu_inter << J << " "
							   <<        B_s0 << " " <<        B_s1 << " " <<        B_s2 << " " <<        B_s3 << " "
							   << shell_qn_s0 << " " << shell_qn_s1 << " " << shell_qn_s2 << " " << shell_qn_s3 << " " << TBME << endl;
						
					    }
					  if (TBME_inter == REALISTIC_INTERACTION)
					    {
					      const TYPE TBME_Hcm = (TBME_space != PROT_NEUT_Y)
						? (TBME_CM_operator::Hcm::TBME_J_pp_nn_antisymmetrized (J , s0 , s1 , s2 , s3 , shells_qn_left , reduced_grad_HO_expansion_left_set(HCM) , reduced_r_HO_expansion_left_set(HCM)))
						: (TBME_CM_operator::Hcm::TBME_J_pn (J , s0 , s1 , s2 , s3 , shells_qn_left , shells_qn_right , 
										     reduced_grad_HO_expansion_left_set(HCM) , reduced_grad_HO_expansion_right_set(HCM) ,
										     reduced_r_HO_expansion_left_set(HCM) , reduced_r_HO_expansion_right_set(HCM)));

					      if (TBME_Hcm != 0.0)
						{
						  if (strangeness_max_global == 0)
						    munu_Hcm << J << " " << shell_qn_s0 << " " << shell_qn_s1 << " " << shell_qn_s2 << " " << shell_qn_s3 << " " << TBME_Hcm << endl;
						  else
						    munu_Hcm << J << " "
							     <<        B_s0 << " " <<        B_s1 << " " <<        B_s2 << " " <<        B_s3 << " "
							     << shell_qn_s0 << " " << shell_qn_s1 << " " << shell_qn_s2 << " " << shell_qn_s3 << " " << TBME_Hcm << endl;
						}}}}}}}}}}}
}


void TBMEs_class::read_TBMEs_from_file (
					const bool is_there_cout ,
					const int n_scat_max ,
					const class baryons_data &particles_data_left , 
					const class baryons_data &particles_data_right , 
					const enum interaction_type TBME_inter)
{
  if ((strangeness_max_global == 0) && (TBME_space == PROT_NEUT_UNMIXED_Y)) return;
	
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      zero ();
      
      const int nmax_left  = particles_data_left.get_nmax ();
      const int lmax_left  = particles_data_left.get_lmax ();

      const int nmax_right = particles_data_right.get_nmax ();
      const int lmax_right = particles_data_right.get_lmax ();

      const class array<class nlj_table<unsigned int> > &shells_indices_tab_left = particles_data_left.get_shells_indices_tab ();
      const class array<class nlj_table<unsigned int> > &shells_indices_tab_right = particles_data_right.get_shells_indices_tab ();
      
      const class array<class nlj_struct> &shells_quantum_numbers_left = particles_data_left.get_shells_quantum_numbers ();
      const class array<class nlj_struct> &shells_quantum_numbers_right = particles_data_right.get_shells_quantum_numbers ();
      
      const string inter_file_string = STORAGE_DIR + "TBMEs_" + make_string<enum space_type> (physical_space_determine (TBME_space , strangeness_max_global)) + "_" + make_string<enum interaction_type> (TBME_inter);
      
      class TBMEs_class &J_TBMEs_class = *this;
      
      if (is_there_cout)
	{
	  cout << endl << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;
	  cout << inter_file_string << " are being read from disk" << endl;
	  cout << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl << endl;
	}
  
      ifstream munu_inter(inter_file_string.c_str ());
      
      file_existence_check (inter_file_string , munu_inter);

      int J;
      
      enum particle_type Ba = (TBME_space == NEUT_Y_ONLY) ? (NEUTRON) : (PROTON) , Bb = (TBME_space == PROT_Y_ONLY) ? (PROTON) : (NEUTRON);
      enum particle_type Bc = (TBME_space == NEUT_Y_ONLY) ? (NEUTRON) : (PROTON) , Bd = (TBME_space == PROT_Y_ONLY) ? (PROTON) : (NEUTRON);
  
      string sa , sb;
      string sc , sd;
      
      TYPE TBME;
      
      while (!munu_inter.eof ())
	{
	  munu_inter >> J;
	  
	  if (munu_inter.eof ()) break;

	  if (strangeness_max_global == 0)
	    munu_inter >> sa >> sb >> sc >> sd >> TBME;
	  else
	    munu_inter >> Ba >> Bb >> Bc >> Bd >> sa >> sb >> sc >> sd >> TBME;
	    
	  const bool is_a_charged = (particle_charge_determine (Ba) != 0) , is_b_charged = (particle_charge_determine (Bb) != 0);
	  const bool is_c_charged = (particle_charge_determine (Bc) != 0) , is_d_charged = (particle_charge_determine (Bd) != 0);
	  
	  const bool is_pp_here = ( is_a_charged &&  is_b_charged &&  is_c_charged &&  is_d_charged);
	  const bool is_nn_here = (!is_a_charged && !is_b_charged && !is_c_charged && !is_d_charged);
	  const bool is_pn_here = ( is_a_charged && !is_b_charged &&  is_c_charged && !is_d_charged);				
	  const bool is_cv_here = ( is_a_charged &&  is_b_charged && !is_c_charged && !is_d_charged);

	  if ((is_pp_here && (TBME_space != PROT_Y_ONLY)) || (is_nn_here && (TBME_space != NEUT_Y_ONLY)) || (is_pn_here && (TBME_space != PROT_NEUT_Y)) || (is_cv_here && (TBME_space != PROT_NEUT_UNMIXED_Y)))
	    error_message_print_abort ("TBMEs have particles with wrong charges in file " + inter_file_string);
	  
	  const int na = determine_n (sa) , nb = determine_n (sb) , la = determine_l (sa) , lb = determine_l (sb);
	  const int nc = determine_n (sc) , nd = determine_n (sd) , lc = determine_l (sc) , ld = determine_l (sd);
	  	  
	  if ((na > nmax_left) || (nb > nmax_right) || (nc > nmax_left) || (nd > nmax_right)) continue;
	  if ((la > lmax_left) || (lb > lmax_right) || (lc > lmax_left) || (ld > lmax_right)) continue;
	  
	  const double ja = determine_j (sa) , jb = determine_j (sb);
	  const double jc = determine_j (sc) , jd = determine_j (sd);

	  const unsigned int ia_charge = charge_baryon_index_determine (Ba) , ib_charge = charge_baryon_index_determine (Bb);
	  const unsigned int ic_charge = charge_baryon_index_determine (Bc) , id_charge = charge_baryon_index_determine (Bd);

	  const class nlj_table<unsigned int> &shells_indices_a = shells_indices_tab_left(ia_charge) , &shells_indices_b = shells_indices_tab_right(ib_charge);
	  const class nlj_table<unsigned int> &shells_indices_c = shells_indices_tab_left(ic_charge) , &shells_indices_d = shells_indices_tab_right(id_charge);
	        
	  const unsigned int a = shells_indices_a(na , la , ja) , b = shells_indices_b(nb , lb , jb);	  
	  const unsigned int c = shells_indices_c(nc , lc , jc) , d = shells_indices_d(nd , ld , jd);

	  if ((a == OUT_OF_RANGE) || (b == OUT_OF_RANGE)) continue;
	  if ((c == OUT_OF_RANGE) || (d == OUT_OF_RANGE)) continue;
	  
	  const class nlj_struct &shell_qn_sa = shells_quantum_numbers_left(a) , &shell_qn_sb = shells_quantum_numbers_right(b);	  
	  const class nlj_struct &shell_qn_sc = shells_quantum_numbers_left(c) , &shell_qn_sd = shells_quantum_numbers_right(d);
	  
	  const bool S_matrix_pole_a = shell_qn_sa.get_S_matrix_pole () , S_matrix_pole_b = shell_qn_sb.get_S_matrix_pole ();	  
	  const bool S_matrix_pole_c = shell_qn_sc.get_S_matrix_pole () , S_matrix_pole_d = shell_qn_sd.get_S_matrix_pole ();

	  const int n_scat_a = (S_matrix_pole_a) ? (0) : (1) , n_scat_b = (S_matrix_pole_b) ? (0) : (1);
	  const int n_scat_c = (S_matrix_pole_c) ? (0) : (1) , n_scat_d = (S_matrix_pole_d) ? (0) : (1);
	  
	  if (n_scat_a + n_scat_b > n_scat_max) continue;
	  if (n_scat_c + n_scat_d > n_scat_max) continue;
	  
	  if (TBME_space == PROT_NEUT_Y)
	    J_TBMEs_class(J , a , b , c , d) = TBME;
	  else
	    {	  
	      if      ((a <= b) && (c <= d)) J_TBMEs_class(J , a , b , c , d) = TBME;
	      else if ((a >  b) && (c <= d)) J_TBMEs_class(J , b , a , c , d) = TBME*minus_one_pow (ja + jb - J - 1);
	      else if ((a <= b) && (c >  d)) J_TBMEs_class(J , a , b , d , c) = TBME*minus_one_pow (jc + jd - J - 1);
	      else if ((a >  b) && (c >  d)) J_TBMEs_class(J , b , a , d , c) = TBME*minus_one_pow (ja + jb + jc + jd);
	    }
	}
    }

#ifdef UseMPI
  MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}





void TBMEs_class::copy_disk (const string &file_name) const
{  
  table.copy_disk (file_name);
}







void TBMEs_class::read_disk (const string &file_name)
{
  if (THIS_PROCESS == MASTER_PROCESS) table.read_disk (file_name);
  
#ifdef UseMPI
  MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}



double used_memory_calc (const class TBMEs_class &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.CG_antisymmetry_table) +
    used_memory_calc (T.Jmin_table) +
    used_memory_calc (T.Jmax_table) +
    used_memory_calc (T.shells_indices_p) +
    used_memory_calc (T.shells_indices_n) +
    used_memory_calc (T.dimensions_coupled_out) +
    used_memory_calc (T.sum_dimensions_coupled_tabs) +
    used_memory_calc (T.bp_table_out) +
    used_memory_calc (T.strangeness_table_out) +
    used_memory_calc (T.i_charge_table_out) +
    used_memory_calc (T.pairs_indices_in) +
    used_memory_calc (T.pairs_indices_out) +
    used_memory_calc (T.table)
    - (sizeof (T.CG_antisymmetry_table) +
       sizeof (T.Jmin_table) +
       sizeof (T.Jmax_table) +
       sizeof (T.shells_indices_p) +
       sizeof (T.shells_indices_n) +
       sizeof (T.dimensions_coupled_out) +
       sizeof (T.sum_dimensions_coupled_tabs) +
       sizeof (T.bp_table_out) +
       sizeof (T.i_charge_table_out) +
       sizeof (T.strangeness_table_out) +
       sizeof (T.pairs_indices_in) +
       sizeof (T.pairs_indices_out) +
       sizeof (T.table))/1000000.0;

  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory; 
}
