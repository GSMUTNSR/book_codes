#include "../GSM_include/GSM_include_def_common.h"


// TYPE is double or complex
// -------------------------

// This file allows to use interaction_class with the HO-SM code. 

interaction_class::interaction_class () :
  is_it_only_basis (false) ,
  is_there_cout (false) ,
  is_there_cout_detailed (false) ,
  TBME_inter (NO_INTERACTION) , 
  are_there_pp_TBMEs (false) ,
  are_there_nn_TBMEs (false) ,
  are_there_pn_TBMEs (false) ,
  a (0.0) , 
  b (0.0) ,  
  V_SDI (0.0) ,
  R0 (0.0) ,
  mu (0.0) , 
  b_lab (0.0) , 
  b_relative (0.0) ,
  u_Minnesota (0.0) ,
  nu_three_body_like (0.0) ,
  V_three_body_like (0.0) ,
  lmax_for_interaction (0) ,
  lmax_multipole_expansion (0) ,
  BPmin_global_pp (2) ,
  BPmax_global_pp (2) ,
  Jmin_global_pp (0.0) , 
  Jmax_global_pp (0.0) , 
  BPmin_global_nn (2) ,
  BPmax_global_nn (2) ,
  Jmin_global_nn (0.0) , 
  Jmax_global_nn (0.0) , 
  BPmin_global_pn (2) ,
  BPmax_global_pn (2) ,
  Jmin_global_pn (0.0) ,
  Jmax_global_pn (0.0) ,
  BPmin_global (2) ,
  BPmax_global (2) ,
  Jmin_global (0.0) ,
  Jmax_global (0.0)
{
  for (unsigned int i = 0 ; i < 2 ; i++) 
    {
      V0_so_tab[i] = 0.0;

      alpha_so_tab[i] = 0.0;

      W_so_tab[i] = 0.0;
      H_so_tab[i] = 0.0;
    } 

  for (unsigned int i = 0 ; i < 3 ; i++) 
    {
      V0_Minnesota_tab[i] = 0.0;
      rho_Minnesota_tab[i] = 0.0;

      V0_ctr_tab[i] = 0.0; 
      
      alpha_ctr_tab[i] = 0.0;
      
      W_ctr_tab[i] = 0.0;
      B_ctr_tab[i] = 0.0;
      H_ctr_tab[i] = 0.0;
      M_ctr_tab[i] = 0.0;

      V0_t_tab[i] = 0.0;

      alpha_t_tab[i] = 0.0;

      W_t_tab[i] = 0.0;
      H_t_tab[i] = 0.0;
    }
}

interaction_class::interaction_class (
				      const bool is_there_cout_c , 
				      const bool is_it_only_basis_c , 
				      const bool is_it_Coulomb , 
				      const class input_data_str &input_data) :
  is_it_only_basis (false) ,
  is_there_cout (false) ,
  is_there_cout_detailed (false) ,
  TBME_inter (NO_INTERACTION) , 
  inter_read (NO_ME_READ) , 
  are_there_pp_TBMEs (false) ,
  are_there_nn_TBMEs (false) ,
  are_there_pn_TBMEs (false) ,
  a (0.0), 
  b (0.0) ,
  V_SDI (0.0) ,
  R0 (0.0) ,
  mu (0.0) , 
  b_lab (0.0) , 
  b_relative (0.0) ,
  u_Minnesota (0.0) ,
  nu_three_body_like (0.0) ,
  V_three_body_like (0.0) ,
  lmax_for_interaction (0) ,
  lmax_multipole_expansion (0) ,
  BPmin_global_pp (2) ,
  BPmax_global_pp (2) ,
  Jmin_global_pp (0.0) , 
  Jmax_global_pp (0.0) , 
  BPmin_global_nn (2) ,
  BPmax_global_nn (2) ,
  Jmin_global_nn (0.0) , 
  Jmax_global_nn (0.0) , 
  BPmin_global_pn (2) ,
  BPmax_global_pn (2) ,
  Jmin_global_pn (0.0) ,
  Jmax_global_pn (0.0) ,
  BPmin_global (2) ,
  BPmax_global (2) ,
  Jmin_global (0.0) ,
  Jmax_global (0.0)
{ 
  for (unsigned int i = 0 ; i < 2 ; i++) 
    {
      V0_so_tab[i] = 0.0;

      alpha_so_tab[i] = 0.0;

      W_so_tab[i] = 0.0;
      H_so_tab[i] = 0.0;
    } 

  for (unsigned int i = 0 ; i < 3 ; i++) 
    {
      V0_Minnesota_tab[i] = 0.0;
      rho_Minnesota_tab[i] = 0.0;

      V0_ctr_tab[i] = 0.0; 
      
      alpha_ctr_tab[i] = 0.0;
      
      W_ctr_tab[i] = 0.0;
      B_ctr_tab[i] = 0.0;
      H_ctr_tab[i] = 0.0;
      M_ctr_tab[i] = 0.0;

      V0_t_tab[i] = 0.0;

      alpha_t_tab[i] = 0.0;

      W_t_tab[i] = 0.0;
      H_t_tab[i] = 0.0;
    }

  allocate (is_there_cout_c , is_it_only_basis_c , is_it_Coulomb , input_data);
}

interaction_class::interaction_class (const class interaction_class &X) :
  is_it_only_basis (false) ,
  is_there_cout (false) ,
  is_there_cout_detailed (false) ,
  TBME_inter (NO_INTERACTION) , 
  are_there_pp_TBMEs (false) ,
  are_there_nn_TBMEs (false) ,
  are_there_pn_TBMEs (false) ,
  a (0.0) , 
  b (0.0) ,  
  V_SDI (0.0) ,
  R0 (0.0) ,
  mu (0.0) , 
  b_lab (0.0) , 
  b_relative (0.0) ,
  u_Minnesota (0.0) ,
  nu_three_body_like (0.0) ,
  V_three_body_like (0.0) ,
  lmax_for_interaction (0) ,
  lmax_multipole_expansion (0) ,
  BPmin_global_pp (2) ,
  BPmax_global_pp (2) ,
  Jmin_global_pp (0.0) , 
  Jmax_global_pp (0.0) , 
  BPmin_global_nn (2) ,
  BPmax_global_nn (2) ,
  Jmin_global_nn (0.0) , 
  Jmax_global_nn (0.0) , 
  BPmin_global_pn (2) ,
  BPmax_global_pn (2) ,
  Jmin_global_pn (0.0) ,
  Jmax_global_pn (0.0) ,
  BPmin_global (2) ,
  BPmax_global (2) ,
  Jmin_global (0.0) ,
  Jmax_global (0.0)
{  
  allocate_fill (X);
}



interaction_class::~interaction_class () {}

void interaction_class::allocate (				  
				  const bool is_there_cout_c , 
				  const bool is_it_only_basis_c ,
				  const bool is_it_Coulomb , 
				  const class input_data_str &input_data)
{
  if (is_it_filled ()) error_message_print_abort ("interaction_class cannot be allocated twice in interaction_class::allocate (1)");

  const bool print_detailed_information = input_data.get_print_detailed_information ();
    
  is_it_only_basis = is_it_only_basis_c;
  
  is_there_cout = is_there_cout_c;
  
  is_there_cout_detailed = (is_there_cout && print_detailed_information);

  TBME_inter = (!is_it_Coulomb) ? (input_data.get_inter ()) : (COULOMB_INTERACTION);
  
  inter_read = (!is_it_Coulomb) ? (input_data.get_inter_read ()) : (NO_ME_READ);
  
  are_there_pp_TBMEs = (is_it_only_basis) ? (input_data.get_Zval_basis () >= 2) : (input_data.get_Zval () >= 2);

  R0 = (is_it_only_basis) ? (input_data.get_R0_inter_basis ()) : (input_data.get_R0_inter ());

  b_lab = (is_it_only_basis) ? (input_data.get_b_lab_basis ()) : (input_data.get_b_lab ());

  b_relative = b_lab*M_SQRT2;
  
  lmax_for_interaction = (is_it_only_basis) ? (input_data.get_lmax_for_basis_interaction ()) : (input_data.get_lmax_for_interaction ());
  
  lmax_multipole_expansion = 2*lmax_for_interaction;

  const bool are_MEs_Berggren_read = (inter_read == LAB_BERGGREN_ME_READ);

  nmax_HO_lab_tab.allocate (lmax_for_interaction + 1);

  nmax_HO_lab_tab.assign (input_data.get_nmax_HO_lab_tab ());
    
  const unsigned int N_nlj_HO = N_nlj_calc (input_data.get_nmax_HO_lab_tab ());
  
  const unsigned int N_nlj_inter = (are_MEs_Berggren_read) ? (N_nlj_calc (input_data.get_nmax_GHF_lab_tab ())) : (N_nlj_HO);
    
  if (are_MEs_Berggren_read)
    nmax_inter_lab_tab.allocate_fill (input_data.get_nmax_GHF_lab_tab ());
  else
    nmax_inter_lab_tab.allocate_fill (nmax_HO_lab_tab);
  
  const int nmax_HO_lab = nmax_calc (nmax_HO_lab_tab);
  
  const int nmax_inter_lab = nmax_calc (nmax_inter_lab_tab);

  shells_HO_table.allocate (N_nlj_HO);

  shells_HO_indices.allocate (0.5 , nmax_HO_lab , lmax_for_interaction);
  
  unsigned int index_HO = 0;

  for (int l = 0 ; l <= lmax_for_interaction ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	const int n_max_l = nmax_HO_lab_tab(l);

	for (int n = 0 ; n <= n_max_l ; n++)
	  {
	    shells_HO_table(index_HO).initialize (true , false , false , false , false , true , false , false , NADA , n , l , j , NO_SEGMENT , NADA , NADA , NADA , NADA , NADA , NADA , NADA , NADA);
	    
	    shells_HO_indices(n , l , j) = index_HO++;
	  }
      }
  
  if (index_HO != N_nlj_HO) error_message_print_abort ("Problem with shells_HO_table in GSM_interaction_class constructor.");

  if (are_MEs_Berggren_read)
    {
      // GHF states are all considered scattering for interaction basis expansion
      
      shells_inter_table.allocate (N_nlj_inter);
  
      shells_inter_indices.allocate (0.5 , nmax_inter_lab , lmax_for_interaction);

      unsigned int index_inter = 0;

      for (int l = 0 ; l <= lmax_for_interaction ; l++)
	for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	  {
	    const int n_max_l = nmax_inter_lab_tab(l);

	    for (int n = 0 ; n <= n_max_l ; n++)
	      {
		shells_inter_table(index_inter).initialize (false , false , false , false , false , false , false , false , NADA , n , l , j , NO_SEGMENT , NADA , NADA , NADA , NADA , NADA , NADA , NADA , NADA);
	    
		shells_inter_indices(n , l , j) = index_inter++;
	      }
	  }
  
      if (index_inter != N_nlj_inter) error_message_print_abort ("Problem with shells_inter_table in GSM_interaction_class constructor.");
    }
  else
    {
      shells_inter_table.allocate_fill (shells_HO_table);
  
      shells_inter_indices.allocate_fill (shells_HO_indices);
    }

  are_there_nn_TBMEs = (is_it_only_basis) ? (input_data.get_Nval_basis () >= 2) : (input_data.get_Nval () >= 2); 
  are_there_pn_TBMEs = (is_it_only_basis) ? (input_data.get_basis_space () == PROTONS_NEUTRONS) : (input_data.get_space () == PROTONS_NEUTRONS);

  a = (is_it_only_basis) ? (input_data.get_a_basis ()) : (input_data.get_a ()); 
  b = (is_it_only_basis) ? (input_data.get_b_basis ()) : (input_data.get_b ());

  V_SDI = (is_it_only_basis) ? (input_data.get_V_SDI_basis ()) : (input_data.get_V_SDI ()); 

  mu = (is_it_only_basis) ? (input_data.get_mu_basis ()) : (input_data.get_mu ());

  V0_Minnesota_tab[0] = (is_it_only_basis) ? (input_data.get_V0_Minnesota_basis(0)) : (input_data.get_V0_Minnesota(0)); 
  V0_Minnesota_tab[1] = (is_it_only_basis) ? (input_data.get_V0_Minnesota_basis(1)) : (input_data.get_V0_Minnesota(1)); 
  V0_Minnesota_tab[2] = (is_it_only_basis) ? (input_data.get_V0_Minnesota_basis(2)) : (input_data.get_V0_Minnesota(2));

  rho_Minnesota_tab[0] = (is_it_only_basis) ? (input_data.get_rho_Minnesota_basis(0)) : (input_data.get_rho_Minnesota(0)); 
  rho_Minnesota_tab[1] = (is_it_only_basis) ? (input_data.get_rho_Minnesota_basis(1)) : (input_data.get_rho_Minnesota(1)); 
  rho_Minnesota_tab[2] = (is_it_only_basis) ? (input_data.get_rho_Minnesota_basis(2)) : (input_data.get_rho_Minnesota(2));

  u_Minnesota = (is_it_only_basis) ? (input_data.get_u_Minnesota_basis ()) : (input_data.get_u_Minnesota ());

  nu_three_body_like = (is_it_only_basis) ? (input_data.get_nu_three_body_like_basis ()) : (input_data.get_nu_three_body_like ()); 

  V_three_body_like = (is_it_only_basis) ? (input_data.get_V_three_body_like_basis ()) : (input_data.get_V_three_body_like ());

  V0_ctr_tab[0] = (is_it_only_basis) ? (input_data.get_V0_ctr_basis(0)) : (input_data.get_V0_ctr(0)); 
  V0_ctr_tab[1] = (is_it_only_basis) ? (input_data.get_V0_ctr_basis(1)) : (input_data.get_V0_ctr(1)); 
  V0_ctr_tab[2] = (is_it_only_basis) ? (input_data.get_V0_ctr_basis(2)) : (input_data.get_V0_ctr(2));

  alpha_ctr_tab[0] = (is_it_only_basis) ? (input_data.get_alpha_ctr_basis(0)) : (input_data.get_alpha_ctr(0)); 
  alpha_ctr_tab[1] = (is_it_only_basis) ? (input_data.get_alpha_ctr_basis(1)) : (input_data.get_alpha_ctr(1)); 
  alpha_ctr_tab[2] = (is_it_only_basis) ? (input_data.get_alpha_ctr_basis(2)) : (input_data.get_alpha_ctr(2));

  W_ctr_tab[0] = (is_it_only_basis) ? (input_data.get_W_ctr_basis(0)) : (input_data.get_W_ctr(0)); 
  W_ctr_tab[1] = (is_it_only_basis) ? (input_data.get_W_ctr_basis(1)) : (input_data.get_W_ctr(1)); 
  W_ctr_tab[2] = (is_it_only_basis) ? (input_data.get_W_ctr_basis(2)) : (input_data.get_W_ctr(2));

  B_ctr_tab[0] = (is_it_only_basis) ? (input_data.get_B_ctr_basis(0)) : (input_data.get_B_ctr(0)); 
  B_ctr_tab[1] = (is_it_only_basis) ? (input_data.get_B_ctr_basis(1)) : (input_data.get_B_ctr(1)); 
  B_ctr_tab[2] = (is_it_only_basis) ? (input_data.get_B_ctr_basis(2)) : (input_data.get_B_ctr(2));

  H_ctr_tab[0] = (is_it_only_basis) ? (input_data.get_H_ctr_basis(0)) : (input_data.get_H_ctr(0)); 
  H_ctr_tab[1] = (is_it_only_basis) ? (input_data.get_H_ctr_basis(1)) : (input_data.get_H_ctr(1)); 
  H_ctr_tab[2] = (is_it_only_basis) ? (input_data.get_H_ctr_basis(2)) : (input_data.get_H_ctr(2));

  M_ctr_tab[0] = (is_it_only_basis) ? (input_data.get_M_ctr_basis(0)) : (input_data.get_M_ctr(0)); 
  M_ctr_tab[1] = (is_it_only_basis) ? (input_data.get_M_ctr_basis(1)) : (input_data.get_M_ctr(1)); 
  M_ctr_tab[2] = (is_it_only_basis) ? (input_data.get_M_ctr_basis(2)) : (input_data.get_M_ctr(2));

  V0_so_tab[0] = (is_it_only_basis) ? (input_data.get_V0_so_basis(0)) : (input_data.get_V0_so(0)); 
  V0_so_tab[1] = (is_it_only_basis) ? (input_data.get_V0_so_basis(1)) : (input_data.get_V0_so(1));

  alpha_so_tab[0] = (is_it_only_basis) ? (input_data.get_alpha_so_basis(0)) : (input_data.get_alpha_so(0)); 
  alpha_so_tab[1] = (is_it_only_basis) ? (input_data.get_alpha_so_basis(1)) : (input_data.get_alpha_so(1));

  W_so_tab[0] = (is_it_only_basis) ? (input_data.get_W_so_basis(0)) : (input_data.get_W_so(0)); 
  W_so_tab[1] = (is_it_only_basis) ? (input_data.get_W_so_basis(1)) : (input_data.get_W_so(1)); 

  H_so_tab[0] = (is_it_only_basis) ? (input_data.get_H_so_basis(0)) : (input_data.get_H_so(0)); 
  H_so_tab[1] = (is_it_only_basis) ? (input_data.get_H_so_basis(1)) : (input_data.get_H_so(1));

  V0_t_tab[0] = (is_it_only_basis) ? (input_data.get_V0_t_basis(0)) : (input_data.get_V0_t(0)); 
  V0_t_tab[1] = (is_it_only_basis) ? (input_data.get_V0_t_basis(1)) : (input_data.get_V0_t(1)); 
  V0_t_tab[2] = (is_it_only_basis) ? (input_data.get_V0_t_basis(2)) : (input_data.get_V0_t(2));

  alpha_t_tab[0] = (is_it_only_basis) ? (input_data.get_alpha_t_basis(0)) : (input_data.get_alpha_t(0)); 
  alpha_t_tab[1] = (is_it_only_basis) ? (input_data.get_alpha_t_basis(1)) : (input_data.get_alpha_t(1)); 
  alpha_t_tab[2] = (is_it_only_basis) ? (input_data.get_alpha_t_basis(2)) : (input_data.get_alpha_t(2));

  W_t_tab[0] = (is_it_only_basis) ? (input_data.get_W_t_basis(0)) : (input_data.get_W_t(0)); 
  W_t_tab[1] = (is_it_only_basis) ? (input_data.get_W_t_basis(1)) : (input_data.get_W_t(1));    
  W_t_tab[2] = (is_it_only_basis) ? (input_data.get_W_t_basis(2)) : (input_data.get_W_t(2)); 

  H_t_tab[0] = (is_it_only_basis) ? (input_data.get_H_t_basis(0)) : (input_data.get_H_t(0)); 
  H_t_tab[1] = (is_it_only_basis) ? (input_data.get_H_t_basis(1)) : (input_data.get_H_t(1)); 
  H_t_tab[2] = (is_it_only_basis) ? (input_data.get_H_t_basis(2)) : (input_data.get_H_t(2));

  BPmin_global_pp = input_data.get_BPmin_global_pp ();
  BPmax_global_pp = input_data.get_BPmax_global_pp ();

  Jmin_global_pp = input_data.get_Jmin_global_pp ();
  Jmax_global_pp = input_data.get_Jmax_global_pp ();

  BPmin_global_nn = input_data.get_BPmin_global_nn ();
  BPmax_global_nn = input_data.get_BPmax_global_nn ();

  Jmin_global_nn = input_data.get_Jmin_global_nn ();
  Jmax_global_nn = input_data.get_Jmax_global_nn ();

  BPmin_global_pn = input_data.get_BPmin_global_pn ();
  BPmax_global_pn = input_data.get_BPmax_global_pn ();

  Jmin_global_pn = input_data.get_Jmin_global_pn ();
  Jmax_global_pn = input_data.get_Jmax_global_pn ();

  BPmin_global = input_data.BPmin_global_determine (is_it_only_basis);
  BPmax_global = input_data.BPmax_global_determine (is_it_only_basis);

  Jmin_global = input_data.Jmin_global_determine (is_it_only_basis);
  Jmax_global = input_data.Jmax_global_determine (is_it_only_basis);

  if (is_it_only_basis)
    V_Gaussian_consts.allocate_fill (input_data.get_V_Gaussian_consts_basis ());
  else
    V_Gaussian_consts.allocate_fill (input_data.get_V_Gaussian_consts ());
}






void interaction_class::allocate_fill (const class interaction_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("interaction_class cannot be allocated twice in interaction_class::allocate_fill");

  is_it_only_basis = X.is_it_only_basis;
  
  is_there_cout = X.is_there_cout;
  
  is_there_cout_detailed = X.is_there_cout_detailed;
  
  TBME_inter = X.TBME_inter;
  
  inter_read = X.inter_read;
  
  are_there_pp_TBMEs = X.are_there_pp_TBMEs; 
  are_there_nn_TBMEs = X.are_there_nn_TBMEs; 
  are_there_pn_TBMEs = X.are_there_pn_TBMEs;

  a = X.a; 
  b = X.b; 
  V_SDI = X.V_SDI;

  R0 = X.R0;

  mu = X.mu;

  b_lab = X.b_lab; 
  b_relative = X.b_relative;

  V0_Minnesota_tab[0] = X.V0_Minnesota_tab[0]; 
  V0_Minnesota_tab[1] = X.V0_Minnesota_tab[1]; 
  V0_Minnesota_tab[2] = X.V0_Minnesota_tab[2];

  rho_Minnesota_tab[0] = X.rho_Minnesota_tab[0]; 
  rho_Minnesota_tab[1] = X.rho_Minnesota_tab[1]; 
  rho_Minnesota_tab[2] = X.rho_Minnesota_tab[2];

  u_Minnesota = X.u_Minnesota; 

  nu_three_body_like = X.nu_three_body_like;

  V_three_body_like = X.V_three_body_like;

  V0_ctr_tab[0] = X.V0_ctr_tab[0]; 
  V0_ctr_tab[1] = X.V0_ctr_tab[1]; 
  V0_ctr_tab[2] = X.V0_ctr_tab[2];

  alpha_ctr_tab[0] = X.alpha_ctr_tab[0]; 
  alpha_ctr_tab[1] = X.alpha_ctr_tab[1]; 
  alpha_ctr_tab[2] = X.alpha_ctr_tab[2];

  W_ctr_tab[0] = X.W_ctr_tab[0]; 
  W_ctr_tab[1] = X.W_ctr_tab[1]; 
  W_ctr_tab[2] = X.W_ctr_tab[2];

  B_ctr_tab[0] = X.B_ctr_tab[0]; 
  B_ctr_tab[1] = X.B_ctr_tab[1]; 
  B_ctr_tab[2] = X.B_ctr_tab[2];

  H_ctr_tab[0] = X.H_ctr_tab[0]; 
  H_ctr_tab[1] = X.H_ctr_tab[1]; 
  H_ctr_tab[2] = X.H_ctr_tab[2];

  M_ctr_tab[0] = X.M_ctr_tab[0]; 
  M_ctr_tab[1] = X.M_ctr_tab[1]; 
  M_ctr_tab[2] = X.M_ctr_tab[2];

  V0_so_tab[0] = X.V0_so_tab[0]; 
  V0_so_tab[1] = X.V0_so_tab[1];

  alpha_so_tab[0] = X.alpha_so_tab[0]; 
  alpha_so_tab[1] = X.alpha_so_tab[1];

  W_so_tab[0] = X.W_so_tab[0]; 
  W_so_tab[1] = X.W_so_tab[1];

  H_so_tab[0] = X.H_so_tab[0]; 
  H_so_tab[1] = X.H_so_tab[1];

  V0_t_tab[0] = X.V0_t_tab[0]; 
  V0_t_tab[1] = X.V0_t_tab[1]; 
  V0_t_tab[2] = X.V0_t_tab[2];

  alpha_t_tab[0] = X.alpha_t_tab[0]; 
  alpha_t_tab[1] = X.alpha_t_tab[1]; 
  alpha_t_tab[2] = X.alpha_t_tab[2];

  W_t_tab[0] = X.W_t_tab[0]; 
  W_t_tab[1] = X.W_t_tab[1]; 
  W_t_tab[2] = X.W_t_tab[2];

  H_t_tab[0] = X.H_t_tab[0]; 
  H_t_tab[1] = X.H_t_tab[1]; 
  H_t_tab[2] = X.H_t_tab[2];

  lmax_for_interaction = X.lmax_for_interaction; 
  lmax_multipole_expansion = X.lmax_multipole_expansion;

  BPmin_global_pp = X.BPmin_global_pp; 
  BPmax_global_pp = X.BPmax_global_pp;

  Jmin_global_pp = X.Jmin_global_pp; 
  Jmax_global_pp = X.Jmax_global_pp;

  BPmin_global_nn = X.BPmin_global_nn; 
  BPmax_global_nn = X.BPmax_global_nn;

  Jmin_global_nn = X.Jmin_global_nn; 
  Jmax_global_nn = X.Jmax_global_nn;

  BPmin_global_pn = X.BPmin_global_pn; 
  BPmax_global_pn = X.BPmax_global_pn;

  Jmin_global_pn = X.Jmin_global_pn; 
  Jmax_global_pn = X.Jmax_global_pn; 

  BPmin_global = X.BPmin_global; 
  BPmax_global = X.BPmax_global;

  Jmin_global = X.Jmin_global; 
  Jmax_global = X.Jmax_global;

  V_Gaussian_consts.allocate_fill (X.V_Gaussian_consts);

  nmax_HO_lab_tab.allocate_fill (X.nmax_HO_lab_tab);

  shells_HO_table.allocate_fill (X.shells_HO_table);
  shells_HO_indices.allocate_fill (X.shells_HO_indices);
  
  nmax_inter_lab_tab.allocate_fill (X.nmax_inter_lab_tab);

  shells_inter_table.allocate_fill (X.shells_inter_table);
  shells_inter_indices.allocate_fill (X.shells_inter_indices);

  r_bef_R_tab_GL.allocate_fill (X.r_bef_R_tab_GL);
  w_bef_R_tab_GL.allocate_fill (X.w_bef_R_tab_GL);

  HO_wfs_bef_R_tab_GL.allocate_fill (X.HO_wfs_bef_R_tab_GL);
  HO_dwfs_bef_R_tab_GL.allocate_fill (X.HO_dwfs_bef_R_tab_GL);

  r_aft_R_tab_GL.allocate_fill (X.r_aft_R_tab_GL);
  w_aft_R_tab_GL.allocate_fill (X.w_aft_R_tab_GL);

  HO_wfs_aft_R_tab_GL.allocate_fill (X.HO_wfs_aft_R_tab_GL);
  HO_dwfs_aft_R_tab_GL.allocate_fill (X.HO_dwfs_aft_R_tab_GL);

  r_bef_R_tab_GL_SGI_MSGI.allocate_fill (X.r_bef_R_tab_GL_SGI_MSGI);
  w_bef_R_tab_GL_SGI_MSGI.allocate_fill (X.w_bef_R_tab_GL_SGI_MSGI);
  
  HO_wfs_bef_R_tab_GL_SGI_MSGI.allocate_fill (X.HO_wfs_bef_R_tab_GL_SGI_MSGI);
  HO_dwfs_bef_R_tab_GL_SGI_MSGI.allocate_fill (X.HO_dwfs_bef_R_tab_GL_SGI_MSGI);

  HO_overlaps_Fermi.allocate_fill (X.HO_overlaps_Fermi);
  
  Vl_SGI_tab_GL.allocate_fill (X.Vl_SGI_tab_GL);

  TBMEs_pp_inter_lab.allocate_fill (X.TBMEs_pp_inter_lab);
  TBMEs_nn_inter_lab.allocate_fill (X.TBMEs_nn_inter_lab);
  TBMEs_pn_inter_lab.allocate_fill (X.TBMEs_pn_inter_lab);
  
  V_Coulomb_HO_basis.allocate_fill (X.V_Coulomb_HO_basis);
}






void interaction_class::deallocate ()
{
  V_Gaussian_consts.deallocate ();

  nmax_HO_lab_tab.deallocate ();

  shells_HO_table.deallocate ();
  shells_HO_indices.deallocate ();
  
  nmax_inter_lab_tab.deallocate ();

  shells_inter_table.deallocate ();
  shells_inter_indices.deallocate ();

  r_bef_R_tab_GL.deallocate ();
  w_bef_R_tab_GL.deallocate ();
  
  HO_wfs_bef_R_tab_GL.deallocate ();
  HO_dwfs_bef_R_tab_GL.deallocate ();

  r_aft_R_tab_GL.deallocate ();
  w_aft_R_tab_GL.deallocate ();
  
  HO_wfs_aft_R_tab_GL.deallocate ();
  HO_dwfs_aft_R_tab_GL.deallocate ();

  r_bef_R_tab_GL_SGI_MSGI.deallocate ();
  w_bef_R_tab_GL_SGI_MSGI.deallocate ();
  
  HO_wfs_bef_R_tab_GL_SGI_MSGI.deallocate ();
  HO_dwfs_bef_R_tab_GL_SGI_MSGI.deallocate ();

  HO_overlaps_Fermi.deallocate ();
  
  Vl_SGI_tab_GL.deallocate ();

  TBMEs_pp_inter_lab.deallocate ();
  TBMEs_nn_inter_lab.deallocate ();
  TBMEs_pn_inter_lab.deallocate ();

  is_it_only_basis = false;

  is_there_cout = false;

  is_there_cout_detailed = false;

  TBME_inter = NO_INTERACTION; 

  inter_read = NO_ME_READ;
  
  are_there_pp_TBMEs = false;
  are_there_nn_TBMEs = false;
  are_there_pn_TBMEs = false;

  a = 0.0;
  b = 0.0;

  V_SDI = 0.0;

  R0 = 0.0;

  mu = 0.0; 

  b_lab = 0.0; 

  b_relative = 0.0; 

  V0_Minnesota_tab[0] = 0.0;
  V0_Minnesota_tab[1] = 0.0;
  V0_Minnesota_tab[2] = 0.0; 

  rho_Minnesota_tab[0] = 0.0; 
  rho_Minnesota_tab[1] = 0.0;
  rho_Minnesota_tab[2] = 0.0; 

  u_Minnesota = 0.0;

  nu_three_body_like = 0.0;

  V_three_body_like = 0.0; 

  V0_ctr_tab[0] = 0.0; 
  V0_ctr_tab[1] = 0.0; 
  V0_ctr_tab[2] = 0.0; 

  alpha_ctr_tab[0] = 0.0; 
  alpha_ctr_tab[1] = 0.0; 
  alpha_ctr_tab[2] = 0.0; 

  W_ctr_tab[0] = 0.0; 
  W_ctr_tab[1] = 0.0; 
  W_ctr_tab[2] = 0.0; 

  B_ctr_tab[0] = 0.0; 
  B_ctr_tab[1] = 0.0; 
  B_ctr_tab[2] = 0.0; 

  H_ctr_tab[0] = 0.0; 
  H_ctr_tab[1] = 0.0; 
  H_ctr_tab[2] = 0.0; 

  M_ctr_tab[0] = 0.0; 
  M_ctr_tab[1] = 0.0; 
  M_ctr_tab[2] = 0.0; 

  V0_so_tab[0] = 0.0; 
  V0_so_tab[1] = 0.0; 

  alpha_so_tab[0] = 0.0; 
  alpha_so_tab[1] = 0.0; 

  W_so_tab[0] = 0.0; 
  W_so_tab[1] = 0.0; 

  H_so_tab[0] = 0.0; 
  H_so_tab[1] = 0.0; 

  V0_t_tab[0] = 0.0; 
  V0_t_tab[1] = 0.0; 
  V0_t_tab[2] = 0.0; 

  alpha_t_tab[0] = 0.0; 
  alpha_t_tab[1] = 0.0; 
  alpha_t_tab[2] = 0.0; 

  W_t_tab[0] = 0.0; 
  W_t_tab[1] = 0.0; 
  W_t_tab[2] = 0.0; 

  H_t_tab[0] = 0.0; 
  H_t_tab[1] = 0.0; 
  H_t_tab[2] = 0.0; 

  lmax_for_interaction = 0;

  lmax_multipole_expansion = 0;

  BPmin_global_pp = 2;
  BPmax_global_pp = 2;

  Jmin_global_pp = 0.0; 
  Jmax_global_pp = 0.0; 

  BPmin_global_nn = 2;
  BPmax_global_nn = 2;

  Jmin_global_nn = 0.0; 
  Jmax_global_nn = 0.0; 

  BPmin_global_pn = 2;
  BPmax_global_pn = 2;

  Jmin_global_pn = 0.0;
  Jmax_global_pn = 0.0;

  BPmin_global = 2;
  BPmax_global = 2;

  Jmin_global = 0.0;
  Jmax_global = 0.0;
}



bool interaction_class::is_it_filled () const
{
  return (TBME_inter != NO_INTERACTION);
}



