#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Array class type to store an array of class configuration
// ---------------------------------------------------------
// In this array class type, one uniquely stores the existing class configuration by knowing their number for each configuration and summing dimensions.
// One adds "_c" to input variables in constructors and allocators if they copied to class members afterwards.
//
// One allocates a table of integers "table", containing the occupied shells in each configuration.
// Its dimension is the product of the total number of configurations times the number of valence particles
//
// The sum of dimensions is taken as a pointer to the same table stored in nucleons_data, which is fixed ("sum_dimensions_configuration_set_ptr" in the class).
// Hence, this class cannot be used without nucleons_data, which is impossible in practice.
// Hence, using a pointer to another table is a sound procedure here.
//
// The internal index of the table storing all classes configuration is a one-dimensional index ,
// calculated from the local index iC, where configuration quantum numbers are fixed, to which a sum of dimensions is added.
// This is done in index_determine.
//
// One can access the table with operator (), where one puts all configuration quantum numbers and the local index iC,
// or with operator [], where one puts directly the internal one-dimensional index of the stored array.
//
// The stored table an array of integers, which are the occupied shells in each configuration.
// In order to obtain a class configuration, one returns a virtual configuration with operator (), containing the array of integers and the index associated to this configuration.
// Obtaining a class configuration from a virtual configuration in done in configuration.cpp .


array_of_configuration::array_of_configuration () :
  sum_dimensions_configuration_set_ptr (NULL)
{}
  
array_of_configuration::array_of_configuration (
						const bool is_there_cout ,
						const enum particle_type particle ,
						const unsigned int dimension_configuration_total ,
						const class array<unsigned int> &sum_dimensions_configuration_set ,
						const unsigned int N_valence_nucleons)
{ 
  allocate (is_there_cout , particle , dimension_configuration_total , sum_dimensions_configuration_set , N_valence_nucleons);
}
  
array_of_configuration::array_of_configuration (const class array_of_configuration &X)
{ 
  allocate_fill (X);
}
  
void array_of_configuration::allocate (
				       const bool is_there_cout ,
				       const enum particle_type particle ,
				       const unsigned int dimension_configuration_total ,
				       const class array<unsigned int> &sum_dimensions_configuration_set ,
				       const unsigned int N_valence_nucleons)
{ 
  sum_dimensions_configuration_set_ptr = &sum_dimensions_configuration_set;
    
  table.allocate (dimension_configuration_total , N_valence_nucleons);
    
  table = OUT_OF_CONFIGURATION;
    
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << particle << " array of configuration: " << used_memory_calc (*this) << " Mb" << endl << endl;
}
  
void array_of_configuration::allocate_fill (const class array_of_configuration &X)
{
  sum_dimensions_configuration_set_ptr = X.sum_dimensions_configuration_set_ptr;
  
  table.allocate_fill (X.table);
}

void array_of_configuration::deallocate ()
{
  table.deallocate ();

  sum_dimensions_configuration_set_ptr = NULL;
}

bool array_of_configuration::is_it_filled () const
{
  return table.is_it_filled ();
}

unsigned int array_of_configuration::index_determine (
						      const unsigned int BP ,
						      const unsigned int n_scat ,
						      const unsigned int iC) const
{
  const class array<unsigned int> & sum_dimensions_configuration_set = get_sum_dimensions_configuration_set ();
 
  const unsigned int index = iC + sum_dimensions_configuration_set(BP , n_scat);
 
  return index;
}
 
class virtual_configuration array_of_configuration::operator () (
								 const unsigned int BP ,
								 const unsigned int n_scat ,
								 const unsigned int iC) const
{
  const unsigned int index = index_determine (BP , n_scat , iC);
 
  return virtual_configuration (table , index);
}

unsigned int array_of_configuration::first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
{
  return basic_first_index_determine_for_MPI (get_dimension_configuration_total () , group_processes_number , process);
}

unsigned int array_of_configuration::last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
{
  return basic_last_index_determine_for_MPI (get_dimension_configuration_total () , group_processes_number , process);
}

unsigned int array_of_configuration::active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
{
  return basic_active_process_determine_for_MPI (get_dimension_configuration_total () , group_processes_number , index);
}


#ifdef UseMPI

void array_of_configuration::MPI_Allreduce_min (const MPI_Comm MPI_C)
{
  if (get_dimension_configuration_total () == 0) return;
  if (get_N_valence_nucleons () == 0) return;

  table.MPI_Allreduce (MPI_MIN , MPI_C);
}

void array_of_configuration::MPI_Bcast (
					const unsigned int Send_process ,
					const MPI_Comm MPI_C)
{
  if (get_dimension_configuration_total () == 0) return;
  if (get_N_valence_nucleons () == 0) return;

  table.MPI_Bcast (Send_process , MPI_C);
}

#endif



// The pointer sum_dimensions_configuration_set_ptr is not considered as it is not allocated in the class definition

double used_memory_calc (const class array_of_configuration &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.table) - sizeof (T.table)/1000000.0);
}




