#include "../GSM_include/GSM_include_def_common.h"

using namespace string_routines;
using namespace inputs_misc;

extern enum called_code_type called_code;

// TYPE is double or complex
// -------------------------

// See input_data_str.h for information about its data. Routines here are rather straightforward so that no details are provided, only general explanations
// --------------------------------------------------------------------------------------------------------------------------------------------------------






// Check if the R0 values used in input_data_str are consistent
// ------------------------------------------------------------
// In case one uses a WS potential with uniformly charged sphere (WS , not WS_ANALYTIC) , 
// all R0 values of WS potentials and SDI/SGI/MSGI interactions must be the same.
// Indeed , the matching point of wave functions is the same as the R0 of SDI/SGI/MSGI interaction in the spherical_state.cpp file.
// But this test is important only to check back old calculations where the uniformly charged sphere Coulomb potential or the SDI interaction was used.
// Indeed , in all calculations after the latter, the analytic Coulomb potential is used, and the SDI interaction not used.

bool input_data_str::are_R0_values_consistent (const bool is_it_only_basis) const
{
  if (H_potential != WS) return true;

  if (!is_it_SGI_MSGI_determine (inter) && !is_it_SDI_determine (inter)) return true;
  
  if (is_it_only_basis)
    {
      for (int lp = 0 ; lp <= lmax_p ; lp++)
	{
	  if (abs (prot_R0_basis_tab(lp) - R0_inter_basis) > precision) return false;
	}

      for (int ln = 0 ; ln <= lmax_n ; ln++)
	{
	  if (abs (neut_R0_basis_tab(ln) - R0_inter_basis) > precision) return false;
	}

      return true;
    }
  else
    {
      for (int lp = 0 ; lp <= lmax_common_p ; lp++)
	{
	  if (abs (prot_R0_core_potential_tab(lp) - R0_inter) > precision) return false;
	}

      for (int ln = 0 ; ln <= lmax_common_n ; ln++)
	{
	  if (abs (neut_R0_core_potential_tab(ln) - R0_inter) > precision) return false;
	}

      return true;
    }
}








// Some arrays of input_data_str are here allocated and initialized to a default value. 
// This is necessary even if they are not used in GSM calculations as they are read and transferred with MPI.

void input_data_str::basis_potential_data_default_alloc_fill ()
{
  const int lmax_p_plus_one = lmax_p + 1;
  const int lmax_n_plus_one = lmax_n + 1;

  const int lmax_relative_plus_one = lmax_relative + 1;
  
  prot_d_basis_tab.allocate   (lmax_p_plus_one);
  prot_R0_basis_tab.allocate  (lmax_p_plus_one);
  prot_Vo_basis_tab.allocate  (lmax_p_plus_one);
  prot_Vso_basis_tab.allocate (lmax_p_plus_one);

  neut_d_basis_tab.allocate   (lmax_n_plus_one);
  neut_R0_basis_tab.allocate  (lmax_n_plus_one);
  neut_Vo_basis_tab.allocate  (lmax_n_plus_one);
  neut_Vso_basis_tab.allocate (lmax_n_plus_one);

  d_basis_relative_tab.allocate   (lmax_relative_plus_one);
  R0_basis_relative_tab.allocate  (lmax_relative_plus_one);
  Vo_basis_relative_tab.allocate  (lmax_relative_plus_one);
  Vso_basis_relative_tab.allocate (lmax_relative_plus_one);

  prot_d_basis_tab = 0.0;
  neut_d_basis_tab = 0.0;

  prot_R0_basis_tab = 0.0;
  neut_R0_basis_tab = 0.0;

  prot_Vo_basis_tab = 0.0;
  neut_Vo_basis_tab = 0.0;

  prot_Vso_basis_tab = 0.0;
  neut_Vso_basis_tab = 0.0;
 
  d_basis_relative_tab   = 0.0;
  R0_basis_relative_tab  = 0.0;
  Vo_basis_relative_tab  = 0.0;
  Vso_basis_relative_tab = 0.0;
}

void input_data_str::core_potential_data_default_alloc_fill ()
{
  const int lmax_common_p_plus_one = lmax_common_p + 1;
  const int lmax_common_n_plus_one = lmax_common_n + 1;
  
  prot_d_core_potential_tab.allocate   (lmax_common_p_plus_one);
  prot_R0_core_potential_tab.allocate  (lmax_common_p_plus_one);
  prot_Vo_core_potential_tab.allocate  (lmax_common_p_plus_one);
  prot_Vso_core_potential_tab.allocate (lmax_common_p_plus_one);

  neut_d_core_potential_tab.allocate   (lmax_common_n_plus_one);
  neut_R0_core_potential_tab.allocate  (lmax_common_n_plus_one);
  neut_Vo_core_potential_tab.allocate  (lmax_common_n_plus_one);
  neut_Vso_core_potential_tab.allocate (lmax_common_n_plus_one);

  prot_d_core_potential_tab = 0.0;
  neut_d_core_potential_tab = 0.0;
  
  prot_R0_core_potential_tab = 0.0;
  neut_R0_core_potential_tab = 0.0;

  prot_Vo_core_potential_tab = 0.0;
  neut_Vo_core_potential_tab = 0.0;
  
  prot_Vso_core_potential_tab = 0.0;
  neut_Vso_core_potential_tab = 0.0;
}

void input_data_str::basis_core_potential_data_default_alloc_fill ()
{
  const int lmax_common_p_plus_one = lmax_common_p + 1;
  const int lmax_common_n_plus_one = lmax_common_n + 1;
  
  prot_d_basis_core_potential_tab.allocate   (lmax_common_p_plus_one);
  prot_R0_basis_core_potential_tab.allocate  (lmax_common_p_plus_one);
  prot_Vo_basis_core_potential_tab.allocate  (lmax_common_p_plus_one);
  prot_Vso_basis_core_potential_tab.allocate (lmax_common_p_plus_one);

  neut_d_basis_core_potential_tab.allocate   (lmax_common_n_plus_one);
  neut_R0_basis_core_potential_tab.allocate  (lmax_common_n_plus_one);
  neut_Vo_basis_core_potential_tab.allocate  (lmax_common_n_plus_one);
  neut_Vso_basis_core_potential_tab.allocate (lmax_common_n_plus_one);

  prot_d_basis_core_potential_tab = 0.0;
  neut_d_basis_core_potential_tab = 0.0;

  prot_R0_basis_core_potential_tab = 0.0;
  neut_R0_basis_core_potential_tab = 0.0;

  prot_Vo_basis_core_potential_tab = 0.0;
  neut_Vo_basis_core_potential_tab = 0.0;

  prot_Vso_basis_core_potential_tab = 0.0;
  neut_Vso_basis_core_potential_tab = 0.0;
}

void input_data_str::b_lab_partial_waves_default_alloc_fill ()
{
  const bool is_it_HO_fit_or_SU3 = ((basis_potential == HO_POTENTIAL) && ((inter == FIT) || (inter == SU3_INTERACTION)));
  
  prot_b_lab_partial_waves.allocate (0.5 , lmax_p);
  neut_b_lab_partial_waves.allocate (0.5 , lmax_n);

  prot_b_lab_partial_waves = (is_it_HO_fit_or_SU3) ? (b_lab) : (0.0);
  neut_b_lab_partial_waves = (is_it_HO_fit_or_SU3) ? (b_lab) : (0.0);
}

void input_data_str::b_lab_fill_optimization_code (const class input_data_str &input_data_common)
{
  b_lab_basis = input_data_common.b_lab_basis;

  b_lab = input_data_common.b_lab;
}

void input_data_str::optimized_partial_waves_basis_potential_partial_waves_default_alloc_fill ()
{
  prot_basis_BP_tab.allocate (0.5 , lmax_p);
  neut_basis_BP_tab.allocate (0.5 , lmax_n);

  prot_basis_J_tab.allocate (0.5 , lmax_p);
  neut_basis_J_tab.allocate (0.5 , lmax_n);

  prot_basis_potential_partial_waves.allocate (0.5 , lmax_p);
  neut_basis_potential_partial_waves.allocate (0.5 , lmax_n);

  prot_basis_BP_tab = 0;
  neut_basis_BP_tab = 0;

  prot_basis_J_tab = 0.0;
  neut_basis_J_tab = 0.0;

  prot_basis_potential_partial_waves = basis_potential;
  neut_basis_potential_partial_waves = basis_potential;
}










// Calculation of the number of discrete shells. It is the number of bound and resonant shells, to which is added the number of scattering-like shells, as thay are HO states or natural orbitals, which are discrete.

unsigned int input_data_str::N_nlj_discrete_calc (
						  const unsigned N_nlj_pole_like ,
						  const class array<class array<class nlj_struct> > &shells_quantum_numbers_scattering_like_tab) const
{
  const unsigned int N_partial_waves_scattering_like = shells_quantum_numbers_scattering_like_tab.dimension (0);
      
  unsigned int N_nlj_discrete = N_nlj_pole_like;

  for (unsigned int i = 0 ; i < N_partial_waves_scattering_like ; i++)
    {
      const class array<class nlj_struct> &shells_quantum_numbers_partial_wave_scattering_like = shells_quantum_numbers_scattering_like_tab(i);
      
      const unsigned int N_scattering_like_states_partial_wave = shells_quantum_numbers_partial_wave_scattering_like.dimension (0);
      
      N_nlj_discrete += N_scattering_like_states_partial_wave;
    }

  return N_nlj_discrete;
}





// Check if one has OCM states to calculate in COSM (see GSM_HF_potentials_common_OCM_part_common.cpp). 
// It is the case if one state is an OCM valence state (see GSM_inputs_misc.cpp), which is neither a HO state nor a natural orbital.

bool input_data_str::are_there_OCM_valence_states_to_integrate_determine (const class array<class nlj_struct> &shells_quantum_numbers) const
{
  const bool is_it_COSM = is_it_COSM_determine (inter);
  
  if (!is_it_COSM) return false;
  
  const unsigned int N_nlj = shells_quantum_numbers.dimension (0);

  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(s);

      const bool core_state = shell_qn.get_core_state ();

      const bool is_it_HO = shell_qn.get_is_it_HO ();

      const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ();

      const int l = shell_qn.get_l ();

      const double j = shell_qn.get_j ();

      const bool OCM_valence_state = OCM_valence_state_determine (shells_quantum_numbers , is_it_COSM , core_state , l , j);

      if (OCM_valence_state && !is_it_HO && !is_it_natural_orbital) return true;      
    }

  return false;
}





// Check also if the partial waves of nucleon projectiles and GSM-CC basis states are part of the GSM model space.
// Indeed, the GSM-CC Hamiltonian is made of coupled channels and diagonalization (poles) or Lippmann-Schwinger equation (scattering states) is solved only with the Berggren basis.

void input_data_str::CC_partial_wave_presence_check (
						     const enum particle_type particle ,
						     const class array<class nlj_struct> &shells_quantum_numbers ,
						     const class array<class nlj_struct> &shells_quantum_numbers_CC_Berggren) const
{  
  const unsigned int N_nlj = shells_quantum_numbers.dimension (0);
  
  const unsigned int N_nlj_CC_Berggren = shells_quantum_numbers_CC_Berggren.dimension (0);
  
  for (unsigned int iT = 0 ; iT < CC_N_target_projectile_states ; iT++)
    {      
      const enum particle_type projectile = CC_projectile_tab(iT);

      if (projectile == particle)
	{
	  const unsigned int N_partial_waves = CC_N_partial_waves_tab(iT);
      
	  for (unsigned int ilj_T = 0 ; ilj_T < N_partial_waves ; ilj_T++)
	    {
	      const int l_channel = CC_partial_wave_L_cluster_tab(iT , ilj_T);
      
	      const double j_channel = CC_partial_wave_J_cluster_tab(iT , ilj_T);

	      bool is_there_projectile_partial_wave_in_GSM_space = false;
      
	      for (unsigned int s = 0 ; !is_there_projectile_partial_wave_in_GSM_space && (s < N_nlj) ; s++)
		{
		  const class nlj_struct &shell_qn = shells_quantum_numbers(s);

		  const int l = shell_qn.get_l ();
      
		  const double j = shell_qn.get_j ();
      
		  if (same_lj (l_channel , j_channel , l , j)) is_there_projectile_partial_wave_in_GSM_space = true; 
		}
      
	      if (!is_there_projectile_partial_wave_in_GSM_space)
		error_message_print_abort (make_string<enum particle_type> (particle) + " " + angular_state (l_channel , j_channel) + " partial wave is demanded in projectile partial waves but is absent from GSM space");
	    }
	}
    }
  
  for (unsigned int s_CC_Berggren = 0 ; s_CC_Berggren < N_nlj_CC_Berggren ; s_CC_Berggren++)
    {
      const class nlj_struct &shell_qn_CC_Berggren = shells_quantum_numbers_CC_Berggren(s_CC_Berggren);

      const int l_CC_Berggren = shell_qn_CC_Berggren.get_l ();
      
      const double j_CC_Berggren = shell_qn_CC_Berggren.get_j ();
      
      bool is_there_shell_qn_CC_Berggren_partial_wave_in_GSM_space = false;
      
      for (unsigned int s = 0 ; !is_there_shell_qn_CC_Berggren_partial_wave_in_GSM_space && (s < N_nlj) ; s++)
	{
	  const class nlj_struct &shell_qn = shells_quantum_numbers(s);

	  if (same_lj (shell_qn_CC_Berggren , shell_qn)) is_there_shell_qn_CC_Berggren_partial_wave_in_GSM_space = true; 
	}
      
      if (!is_there_shell_qn_CC_Berggren_partial_wave_in_GSM_space)
	error_message_print_abort (make_string<enum particle_type> (particle) + " " + angular_state (l_CC_Berggren , j_CC_Berggren) + " partial wave is demanded in the CC Berggren basis but is absent from GSM space");
    }
}


// Check if a cluster projectile is one nucleon or not in GSM-CC.

bool input_data_str::is_it_one_nucleon_case_CC_determine () const
{
  for (unsigned int ic = 0 ; ic < CC_cluster_number ; ic++)
    {
      const enum particle_type cluster = CC_cluster_tab(ic);
      
      const int A_cluster = A_projectile_determine (cluster);
   
      if (A_cluster >= 2) return false;
    }
   
  return true;
}
   


// Default values for basis interaction parameters, i.e. interaction parameters used only to calculate basis HF/MSDHF potentials and wave functions, are those of the Hamiltonian interaction parameters.
// They are initialized here.

void input_data_str::basis_interaction_parameters_alloc_copy_from_Hamiltonian ()
{  
  if (V_Gaussian_consts.is_it_filled ()) V_Gaussian_consts_basis.allocate_fill (V_Gaussian_consts);

  a_basis = a;
  b_basis = b;

  V_SDI_basis = V_SDI;

  R0_inter_basis = R0_inter , mu_basis = mu;

  for (unsigned int i = 0 ; i < 5 ; i++) V0_Minnesota_basis[i] = V0_Minnesota[i];

  for (unsigned int i = 0 ; i < 3 ; i++) rho_Minnesota_basis[i] = rho_Minnesota[i];

  for (unsigned int i = 0 ; i < 3 ; i++)
    {
      V0_ctr_basis[i] = V0_ctr[i];

      alpha_ctr_basis[i] = alpha_ctr[i];

      W_ctr_basis[i] = W_ctr[i];
      B_ctr_basis[i] = B_ctr[i];
      H_ctr_basis[i] = H_ctr[i];
      M_ctr_basis[i] = M_ctr[i];
    }

  for (unsigned int i = 0 ; i < 2 ; i++)
    {
      V0_so_basis[i] = V0_so[i];

      alpha_so_basis[i] = alpha_so[i];

      W_so_basis[i] = W_so[i];
      H_so_basis[i] = H_so[i];
    }

  for (unsigned int i = 0 ; i < 3 ; i++) 
    {
      V0_t_basis[i] = V0_t[i];

      alpha_t_basis[i] = alpha_t[i];

      W_t_basis[i] = W_t[i];
      H_t_basis[i] = H_t[i];
    }

  u_Minnesota_basis = u_Minnesota;

  nu_three_body_like_basis = nu_three_body_like;

  V_three_body_like_basis = V_three_body_like;

  V0_ctr_ot_basis = V0_ctr_ot;
  V0_ctr_et_basis = V0_ctr_et;
  V0_ctr_os_basis = V0_ctr_os;
  V0_ctr_es_basis = V0_ctr_es;

  V0_so_ot_basis = V0_so_ot;
  V0_so_et_basis = V0_so_et;
  V0_t_ot_basis = V0_t_ot;
  V0_t_et_basis = V0_t_et;
  
  VS_const_LO_T0_basis          = VS_const_LO_T0;
  VS_const_LO_T1_basis          = VS_const_LO_T1;
  VT_sigma_product_LO_T0_basis  = VT_sigma_product_LO_T0;
  VT_sigma_product_LO_T1_basis  = VT_sigma_product_LO_T1;
  V1_q2_NLO_basis               = V1_q2_NLO;
  V2_k2_NLO_basis               = V2_k2_NLO;
  V3_q2_sigma_product_NLO_basis = V3_q2_sigma_product_NLO;
  V4_k2_sigma_product_NLO_basis = V4_k2_sigma_product_NLO;
  V5_sigma_q_vector_k_NLO_basis = V5_sigma_q_vector_k_NLO;
  V6_sigma_q_product_NLO_basis  = V6_sigma_q_product_NLO;
  V7_sigma_k_product_NLO_basis  = V7_sigma_k_product_NLO;

  Jn_relative_max_basis = Jn_relative_max;

  Jc_relative_max_basis = Jc_relative_max;

  b_lab_basis = b_lab;

  lmax_for_basis_interaction = lmax_for_interaction;
}











// Global maximal and minimal binary parities (see observables_basic_functions.cpp for definition) and total angular momenta of proton-proton, neutron-neutron and proton-neutron two-particle states are calculated here.
// Then, full space global maximal and minimal binary parities and total angular momenta of two-particle states are determined from their proton-proton, proton-neutron and neutron-neutron values.
// is_it_only_basis and ..._basis values means that one considers values which will be used only in the context of HF potentials. Otherwise, constants are related to Hamiltonian parameters.

void input_data_str::BP_J_min_max_global_from_partial_waves ()
{
  bool is_there_positive_parity_p = false , is_there_negative_parity_p = false;
  bool is_there_positive_parity_n = false , is_there_negative_parity_n = false;

  for (unsigned int i = 0 ; i < Np_nlj ; i++)
    {
      const class nlj_struct &shell_qn = prot_shells_quantum_numbers(i);

      const bool frozen_state_p = shell_qn.get_frozen_state ();

      if (frozen_state_p) continue;
      
      const int lp = shell_qn.get_l ();
      
      const unsigned int bp_p = binary_parity_from_orbital_angular_momentum (lp);

      if (bp_p == 0) is_there_positive_parity_p = true;
      if (bp_p == 1) is_there_negative_parity_p = true;
    } 

  for (unsigned int i = 0 ; i < Nn_nlj ; i++)
    {
      const class nlj_struct &shell_qn = neut_shells_quantum_numbers(i);

      const bool frozen_state_n = shell_qn.get_frozen_state ();

      if (frozen_state_n) continue;
      
      const int ln = shell_qn.get_l ();
      
      const unsigned int bp_n = binary_parity_from_orbital_angular_momentum (ln);

      if (bp_n == 0) is_there_positive_parity_n = true;
      if (bp_n == 1) is_there_negative_parity_n = true;
    }

  if (is_there_positive_parity_p && is_there_negative_parity_p)
    {
      BPmin_global_pp = 0;
      BPmax_global_pp = 1;
    }
  else
    {
      BPmin_global_pp = 0;
      BPmax_global_pp = 0;
    }
  
  if (is_there_positive_parity_n && is_there_negative_parity_n)
    {
      BPmin_global_nn = 0;
      BPmax_global_nn = 1;
    }
  else
    {
      BPmin_global_nn = 0;
      BPmax_global_nn = 0;
    }
  
  if ((is_there_positive_parity_p && is_there_negative_parity_n) || (is_there_positive_parity_n && is_there_negative_parity_p))
    {
      BPmin_global_pn = 0;
      BPmax_global_pn = 1;
    }
  else
    {
      BPmin_global_pn = 0;
      BPmax_global_pn = 0;
    }
  
  BPmin_global_pp_basis = BPmin_global_pp , BPmax_global_pp_basis = BPmax_global_pp;
  BPmin_global_nn_basis = BPmin_global_nn , BPmax_global_nn_basis = BPmax_global_nn;
  BPmin_global_pn_basis = BPmin_global_pn , BPmax_global_pn_basis = BPmax_global_pn;
          
  Jmin_global_pp_basis = Jmin_global_pp_opp_basis = INFINITE_J , Jmax_global_pp_basis = Jmax_global_pp_opp_basis = 0;
  Jmin_global_nn_basis = Jmin_global_nn_opp_basis = INFINITE_J , Jmax_global_nn_basis = Jmax_global_nn_opp_basis = 0;
  Jmin_global_pn_basis = Jmin_global_pn_opp_basis = INFINITE_J , Jmax_global_pn_basis = Jmax_global_pn_opp_basis = 0;
    
  for (unsigned int ip = 0 ; ip < Np_nlj ; ip++)
    for (unsigned int ipp = 0 ; ipp < Np_nlj ; ipp++)
      {
	const class nlj_struct &shell_qn_p  = prot_shells_quantum_numbers(ip);
	const class nlj_struct &shell_qn_pp = prot_shells_quantum_numbers(ipp);

	const bool frozen_state_p  = shell_qn_p.get_frozen_state ();
	const bool frozen_state_pp = shell_qn_pp.get_frozen_state ();

	if (frozen_state_p || frozen_state_pp) continue;
	
	const int lp  = shell_qn_p.get_l ();
	const int lpp = shell_qn_pp.get_l ();
	
	const double jp  = shell_qn_p.get_j ();
	const double jpp = shell_qn_pp.get_j ();
	    
	const int Jmin_pp = abs (make_int (jp - jpp));
	
	const int Jmax_pp = make_int (jp + jpp);
	
	Jmin_global_pp_basis = min (Jmin_global_pp_basis , Jmin_pp);
	Jmax_global_pp_basis = max (Jmax_global_pp_basis , Jmax_pp);
	    
	if ((lp + lpp)%2 == 1)
	  {
	    Jmin_global_pp_opp_basis = min (Jmin_global_pp_opp_basis , Jmin_pp);
	    Jmax_global_pp_opp_basis = max (Jmax_global_pp_opp_basis , Jmax_pp);
	  }
      }
  
  for (unsigned int in = 0 ; in < Nn_nlj ; in++)
    for (unsigned int inn = 0 ; inn < Nn_nlj ; inn++)
      {
	const class nlj_struct &shell_qn_n  = neut_shells_quantum_numbers(in);
	const class nlj_struct &shell_qn_nn = neut_shells_quantum_numbers(inn);

	const bool frozen_state_n  = shell_qn_n.get_frozen_state ();
	const bool frozen_state_nn = shell_qn_nn.get_frozen_state ();

	if (frozen_state_n || frozen_state_nn) continue;
	
	const int ln  = shell_qn_n.get_l ();
	const int lnn = shell_qn_nn.get_l ();

	const double jn  = shell_qn_n.get_j ();
	const double jnn = shell_qn_nn.get_j ();

	const int Jmin_nn = abs (make_int (jn - jnn));
	
	const int Jmax_nn = make_int (jn + jnn);
	   
	Jmin_global_nn_basis = min (Jmin_global_nn_basis , Jmin_nn);
	Jmax_global_nn_basis = max (Jmax_global_nn_basis , Jmax_nn);
	
	if ((ln + lnn)%2 == 1)
	  {
	    Jmin_global_nn_opp_basis = min (Jmin_global_nn_opp_basis , Jmin_nn);
	    Jmax_global_nn_opp_basis = max (Jmax_global_nn_opp_basis , Jmax_nn);
	  }
      }
  
  for (unsigned int ip = 0 ; ip < Np_nlj ; ip++)
    for (unsigned int in = 0 ; in < Nn_nlj ; in++)
      {
	const class nlj_struct &prot_shell_qn = prot_shells_quantum_numbers(ip);
	const class nlj_struct &neut_shell_qn = neut_shells_quantum_numbers(in);

	const bool frozen_state_p = prot_shell_qn.get_frozen_state ();
	const bool frozen_state_n = neut_shell_qn.get_frozen_state ();

	if (frozen_state_p || frozen_state_n) continue;
	
	const int lp = prot_shell_qn.get_l ();
	const int ln = neut_shell_qn.get_l ();
      
	const double jp = prot_shell_qn.get_j ();
	const double jn = neut_shell_qn.get_j ();

	const int Jmin_pn = abs (make_int (jp - jn));
      
	const int Jmax_pn = make_int (jp + jn);
  
	Jmin_global_pn_basis = min (Jmin_global_pn_basis , Jmin_pn);
	Jmax_global_pn_basis = max (Jmax_global_pn_basis , Jmax_pn);
	    
	if ((lp + ln)%2 == 1)
	  {
	    Jmin_global_pn_opp_basis = min (Jmin_global_pn_opp_basis , Jmin_pn);
	    Jmax_global_pn_opp_basis = max (Jmax_global_pn_opp_basis , Jmax_pn);
	  }
      }
  
  Jmin_global_pp = (space != NEUTRONS_ONLY) ? (Jmin_global_pp_basis) : (INFINITE_J);
  Jmax_global_pp = (space != NEUTRONS_ONLY) ? (Jmax_global_pp_basis) : (0);
  
  Jmin_global_nn = (space != PROTONS_ONLY) ? (Jmin_global_nn_basis) : (INFINITE_J);
  Jmax_global_nn = (space != PROTONS_ONLY) ? (Jmax_global_nn_basis) : (0);
  
  Jmin_global_pn = (space == PROTONS_NEUTRONS) ? (Jmin_global_pn_basis) : (INFINITE_J);
  Jmax_global_pn = (space == PROTONS_NEUTRONS) ? (Jmax_global_pn_basis) : (0);
  
  Jmin_global_pp_opp = (space != NEUTRONS_ONLY) ? (Jmin_global_pp_opp_basis) : (INFINITE_J);
  Jmax_global_pp_opp = (space != NEUTRONS_ONLY) ? (Jmax_global_pp_opp_basis) : (0);
  
  Jmin_global_nn_opp = (space != PROTONS_ONLY) ? (Jmin_global_nn_opp_basis) : (INFINITE_J);
  Jmax_global_nn_opp = (space != PROTONS_ONLY) ? (Jmax_global_nn_opp_basis) : (0);
  
  Jmin_global_pn_opp = (space == PROTONS_NEUTRONS) ? (Jmin_global_pn_opp_basis) : (INFINITE_J);
  Jmax_global_pn_opp = (space == PROTONS_NEUTRONS) ? (Jmax_global_pn_opp_basis) : (0);
}





unsigned int input_data_str::BPmin_global_determine (const bool is_it_only_basis) const
{
  const enum space_type space_here = (is_it_only_basis) ? (basis_space) : (space);

  const unsigned int BPmin_global_pp_here = (is_it_only_basis) ? (BPmin_global_pp_basis) : (BPmin_global_pp);
  const unsigned int BPmin_global_nn_here = (is_it_only_basis) ? (BPmin_global_nn_basis) : (BPmin_global_nn);
  const unsigned int BPmin_global_pn_here = (is_it_only_basis) ? (BPmin_global_pn_basis) : (BPmin_global_pn);

  switch (space_here)
    {
    case PROTONS_ONLY:     return BPmin_global_pp_here;
    case NEUTRONS_ONLY:    return BPmin_global_nn_here;

    case PROTONS_NEUTRONS: 
      {
	const int Zval_here = (is_it_only_basis) ? (Zval_basis) : (Zval);
	const int Nval_here = (is_it_only_basis) ? (Nval_basis) : (Nval);

	if ( (Zval_here == 1) && (Nval_here == 1)) return BPmin_global_pn_here;
	
	if ( (Zval_here >= 2) && (Nval_here == 1)) return min (BPmin_global_pp_here , BPmin_global_pn_here);
	if ( (Zval_here == 1) && (Nval_here >= 2)) return min (BPmin_global_nn_here , BPmin_global_pn_here);

	const unsigned int BPmin_global_same_here = min (BPmin_global_pp_here , BPmin_global_nn_here);
	
	const unsigned int BPmin_global_here = min (BPmin_global_same_here , BPmin_global_pn_here);

	return BPmin_global_here;
      }

    default: abort_all ();
    }

  return NADA;
}

unsigned int input_data_str::BPmax_global_determine (const bool is_it_only_basis) const
{
  const enum space_type space_here = (is_it_only_basis) ? (basis_space) : (space);

  const unsigned int BPmax_global_pp_here = (is_it_only_basis) ? (BPmax_global_pp_basis) : (BPmax_global_pp);
  const unsigned int BPmax_global_nn_here = (is_it_only_basis) ? (BPmax_global_nn_basis) : (BPmax_global_nn);
  const unsigned int BPmax_global_pn_here = (is_it_only_basis) ? (BPmax_global_pn_basis) : (BPmax_global_pn);

  switch (space_here)
    {
    case PROTONS_ONLY:     return BPmax_global_pp_here;
    case NEUTRONS_ONLY:    return BPmax_global_nn_here;

    case PROTONS_NEUTRONS: 
      {
	const int Zval_here = (is_it_only_basis) ? (Zval_basis) : (Zval);
	const int Nval_here = (is_it_only_basis) ? (Nval_basis) : (Nval);

	if ( (Zval_here == 1) && (Nval_here == 1)) return BPmax_global_pn_here;
	
	if ( (Zval_here >= 2) && (Nval_here == 1)) return max (BPmax_global_pp_here , BPmax_global_pn_here);
	if ( (Zval_here == 1) && (Nval_here >= 2)) return max (BPmax_global_nn_here , BPmax_global_pn_here);

	const unsigned int BPmax_global_same_here = max (BPmax_global_pp_here , BPmax_global_nn_here);

	const unsigned int BPmax_global_here = max (BPmax_global_same_here , BPmax_global_pn_here);

	return BPmax_global_here;
      }

    default: abort_all ();
    }

  return NADA;
}

int input_data_str::Jmin_global_determine (const bool is_it_only_basis) const
{
  const enum space_type space_here = (is_it_only_basis) ? (basis_space) : (space);

  const int Jmin_global_pp_here = (is_it_only_basis) ? (Jmin_global_pp_basis) : (Jmin_global_pp);
  const int Jmin_global_nn_here = (is_it_only_basis) ? (Jmin_global_nn_basis) : (Jmin_global_nn);
  const int Jmin_global_pn_here = (is_it_only_basis) ? (Jmin_global_pn_basis) : (Jmin_global_pn);

  switch (space_here)
    {
    case PROTONS_ONLY:    return Jmin_global_pp_here;
    case NEUTRONS_ONLY:   return Jmin_global_nn_here;

    case PROTONS_NEUTRONS: 
      {
	const int Zval_here = (is_it_only_basis) ? (Zval_basis) : (Zval);
	const int Nval_here = (is_it_only_basis) ? (Nval_basis) : (Nval);

	if ((Zval_here == 1) && (Nval_here == 1)) return Jmin_global_pn_here;
	
	if ((Zval_here >= 2) && (Nval_here == 1)) return min (Jmin_global_pp_here , Jmin_global_pn_here);
	if ((Zval_here == 1) && (Nval_here >= 2)) return min (Jmin_global_nn_here , Jmin_global_pn_here);

	const int Jmin_global_same_here = min (Jmin_global_pp_here , Jmin_global_nn_here);

	const int Jmin_global_here = min (Jmin_global_same_here , Jmin_global_pn_here);

	return Jmin_global_here;
      }

    default: abort_all ();
    }

  return NADA;
}

int input_data_str::Jmax_global_determine (const bool is_it_only_basis) const
{
  const enum space_type space_here = (is_it_only_basis) ? (basis_space) : (space);

  const int Jmax_global_pp_here = (is_it_only_basis) ? (Jmax_global_pp_basis) : (Jmax_global_pp);
  const int Jmax_global_nn_here = (is_it_only_basis) ? (Jmax_global_nn_basis) : (Jmax_global_nn);
  const int Jmax_global_pn_here = (is_it_only_basis) ? (Jmax_global_pn_basis) : (Jmax_global_pn);

  switch (space_here)
    {
    case PROTONS_ONLY:     return Jmax_global_pp_here;
    case NEUTRONS_ONLY:    return Jmax_global_nn_here;

    case PROTONS_NEUTRONS: 
      {
	const int Zval_here = (is_it_only_basis) ? (Zval_basis) : (Zval);
	const int Nval_here = (is_it_only_basis) ? (Nval_basis) : (Nval);

	if ( (Zval_here == 1) && (Nval_here == 1)) return Jmax_global_pn_here;
	
	if ( (Zval_here >= 2) && (Nval_here == 1)) return max (Jmax_global_pp_here , Jmax_global_pn_here);
	if ( (Zval_here == 1) && (Nval_here >= 2)) return max (Jmax_global_nn_here , Jmax_global_pn_here);

	const int Jmax_global_same_here = max (Jmax_global_pp_here , Jmax_global_nn_here);

	const int Jmax_global_here = max (Jmax_global_same_here , Jmax_global_pn_here);

	return Jmax_global_here;
      }

    default: abort_all ();
    }

  return NADA;
}

int input_data_str::Jmin_global_opp_determine (const bool is_it_only_basis) const
{
  const enum space_type space_here = (is_it_only_basis) ? (basis_space) : (space);

  const int Jmin_global_pp_opp_here = (is_it_only_basis) ? (Jmin_global_pp_opp_basis) : (Jmin_global_pp_opp);
  const int Jmin_global_nn_opp_here = (is_it_only_basis) ? (Jmin_global_nn_opp_basis) : (Jmin_global_nn_opp);
  const int Jmin_global_pn_opp_here = (is_it_only_basis) ? (Jmin_global_pn_opp_basis) : (Jmin_global_pn_opp);

  switch (space_here)
    {
    case PROTONS_ONLY:    return Jmin_global_pp_opp_here;
    case NEUTRONS_ONLY:   return Jmin_global_nn_opp_here;

    case PROTONS_NEUTRONS: 
      {
	const int Zval_here = (is_it_only_basis) ? (Zval_basis) : (Zval);
	const int Nval_here = (is_it_only_basis) ? (Nval_basis) : (Nval);

	if ( (Zval_here == 1) && (Nval_here == 1)) return Jmin_global_pn_opp_here;
	
	if ( (Zval_here >= 2) && (Nval_here == 1)) return min (Jmin_global_pp_opp_here , Jmin_global_pn_opp_here);
	if ( (Zval_here == 1) && (Nval_here >= 2)) return min (Jmin_global_nn_opp_here , Jmin_global_pn_opp_here);

	const int Jmin_global_same_opp_here = min (Jmin_global_pp_opp_here , Jmin_global_nn_opp_here);

	const int Jmin_global_opp_here = min (Jmin_global_same_opp_here , Jmin_global_pn_opp_here);

	return Jmin_global_opp_here;
      }

    default: abort_all ();
    }

  return NADA;
}

int input_data_str::Jmax_global_opp_determine (const bool is_it_only_basis) const
{
  const enum space_type space_here = (is_it_only_basis) ? (basis_space) : (space);

  const int Jmax_global_pp_opp_here = (is_it_only_basis) ? (Jmax_global_pp_opp_basis) : (Jmax_global_pp_opp);
  const int Jmax_global_nn_opp_here = (is_it_only_basis) ? (Jmax_global_nn_opp_basis) : (Jmax_global_nn_opp);
  const int Jmax_global_pn_opp_here = (is_it_only_basis) ? (Jmax_global_pn_opp_basis) : (Jmax_global_pn_opp);

  switch (space_here)
    {
    case PROTONS_ONLY:     return Jmax_global_pp_opp_here;
    case NEUTRONS_ONLY:    return Jmax_global_nn_opp_here;

    case PROTONS_NEUTRONS: 
      {
	const int Zval_here = (is_it_only_basis) ? (Zval_basis) : (Zval);
	const int Nval_here = (is_it_only_basis) ? (Nval_basis) : (Nval);

	if ( (Zval_here == 1) && (Nval_here == 1)) return Jmax_global_pn_opp_here;
	
	if ( (Zval_here >= 2) && (Nval_here == 1)) return max (Jmax_global_pp_opp_here , Jmax_global_pn_opp_here);
	if ( (Zval_here == 1) && (Nval_here >= 2)) return max (Jmax_global_nn_opp_here , Jmax_global_pn_opp_here);

	const int Jmax_global_same_opp_here = max (Jmax_global_pp_opp_here , Jmax_global_nn_opp_here);

	const int Jmax_global_opp_here = max (Jmax_global_same_opp_here , Jmax_global_pn_opp_here);

	return Jmax_global_opp_here;
      }

    default: abort_all ();
    }

  return NADA;
}




// One updates here the number of shells for protons and neutrons, for all shells or bound and resonant shells only, as well as total maximal angular momenta, by adding one shell one after the other as input.
// Booleans about the presence of natural orbitals are also updated.

void input_data_str::min_max_one_body_quantum_numbers_N_nlj_nljm_res_update (
									     const enum particle_type particle ,
									     const class nlj_struct &shell_qn)
{
  const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();
  
  const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ();
  
  const int n = shell_qn.get_n ();
  const int l = shell_qn.get_l ();

  const double j = shell_qn.get_j ();

  const unsigned int m_states_number = shell_qn.m_number_determine ();
      
  if (particle == PROTON)
    {
      Np_nljm += m_states_number;
      
      if (S_matrix_pole)
	{
	  Np_nlj_res++;
	  
	  Np_nljm_res += m_states_number;
	}
      
      if (is_it_natural_orbital) are_there_basis_prot_natural_orbitals = true;
      
      nmax_p = max (nmax_p , n);
      lmax_p = max (lmax_p , l);
      
      jp_max = max (jp_max , j);
    }

  if (particle == NEUTRON)
    {
      Nn_nljm += m_states_number;
      
      if (S_matrix_pole)
	{
	  Nn_nlj_res++;
	  
	  Nn_nljm_res += m_states_number;
	}
	  
      if (is_it_natural_orbital) are_there_basis_neut_natural_orbitals = true;
      
      nmax_n = max (nmax_n , n);
      lmax_n = max (lmax_n , l);
      
      jn_max = max (jn_max , j);
    }

  if (is_it_two_nucleon_ST_projectile_determine (particle))
    {      
      if (S_matrix_pole) N_nlj_res_relative++;
      nmax_relative = max (nmax_relative , n);
      lmax_relative = max (lmax_relative , l);
      
      jmax_relative = max (jmax_relative , make_int (j));
    }
}


// One updates here the total maximal angular momenta projection for protons or neutrons from the total maximal angular momenta, as well as simple functions of them.

void input_data_str::max_angular_momentum_projection_data_determine (const enum particle_type particle)
{     
  if (particle == PROTON)
    {
      mp_max = jp_max;
      
      mp_min = -mp_max;
      
      mp_max_minus_half = make_int (mp_max - 0.5);
      
      two_mp_max = 2*mp_max_minus_half + 1;
      
      four_mp_max = 2*two_mp_max;
      
      mp_max_minus_mp_min = make_int (mp_max - mp_min);
    }

  if (particle == NEUTRON)
    {
      mn_max = jn_max;
      
      mn_min = -mn_max;
      
      mn_max_minus_half = make_int (mn_max - 0.5);
      
      two_mn_max = 2*mn_max_minus_half + 1;
      
      four_mn_max = 2*two_mn_max;
      
      mn_max_minus_mn_min = make_int (mn_max - mn_min);	  
    }
}





// Data related to a channel in GSM-CC are added here

void input_data_str::CC_remaining_scattering_target_projectile_data_fill (
									  const unsigned int vector_index_min ,
									  const unsigned int vector_index_max ,
									  class array<class array<int> > &CC_partial_wave_L_cluster_tab_local ,
									  class array<class array<double> > &CC_partial_wave_J_cluster_tab_local ,
									  unsigned int &iT)
{    
  const double J_T = CC_J_target_tab(iT);
  
  const unsigned int BP_T = CC_BP_target_tab(iT);

  const enum particle_type projectile = CC_projectile_tab(iT);

  const double E_intrinsic_projectile = CC_real_E_intrinsic_projectile_tab(iT);

  const double Gamma_intrinsic_projectile = CC_Gamma_intrinsic_projectile_tab(iT);

  const int ZT = Z_target_determine (Z , projectile);
  const int NT = N_target_determine (N , projectile);

  const int ZT_val = ZT - Z_core + prot_hole_states_number;
  const int NT_val = NT - N_core + neut_hole_states_number;

  const bool has_target_valence_nucleons = ((ZT_val > 0) || (NT_val > 0));

  const unsigned int N_partial_waves = CC_N_partial_waves_tab(iT);

  const class array<int> &partial_wave_L_cluster = CC_partial_wave_L_cluster_tab_local(iT);

  const class array<double> &partial_wave_J_cluster = CC_partial_wave_J_cluster_tab_local(iT);

  const int vector_index_min_plus_one = vector_index_min + 1;

  for (unsigned int vector_index_T = vector_index_min_plus_one ; vector_index_T <= vector_index_max ; vector_index_T++)
    {
      iT++;

      CC_J_target_tab(iT) = J_T;

      CC_BP_target_tab(iT) = BP_T;

      CC_vector_index_target_tab(iT) = vector_index_T;

      CC_projectile_tab(iT) = projectile;

      CC_real_E_intrinsic_projectile_tab(iT) = E_intrinsic_projectile;

      CC_Gamma_intrinsic_projectile_tab(iT) = Gamma_intrinsic_projectile;

      CC_is_it_entrance_tab(iT) = false;

      CC_is_it_pole_target_tab(iT) = false;

      CC_N_partial_waves_tab(iT) = N_partial_waves;

      const class correlated_state_str T_qn(ZT , NT , BP_T , J_T , vector_index_T , NADA , NADA , NADA , NADA , false);

      const complex<double> ET_tilde = (has_target_valence_nucleons) ? (CC_get_energy_from_file (T_qn)) : (0.0);

      const complex<double> average_n_scat_T = (has_target_valence_nucleons) ? (CC_get_average_n_scat_from_file (T_qn)) : (0.0);

      const double ET = real_dc (ET_tilde) , Gamma_T = 0.0;//-2000.0*imag (ET_tilde);

      CC_real_E_target_tab(iT) = ET;

      CC_Gamma_target_tab(iT) = Gamma_T;

      CC_average_n_scat_target_tab(iT) = average_n_scat_T;

      class array<int> &CC_partial_wave_L_cluster_T_tab = CC_partial_wave_L_cluster_tab_local(iT);

      class array<double> &CC_partial_wave_J_cluster_T_tab = CC_partial_wave_J_cluster_tab_local(iT);

      CC_partial_wave_L_cluster_T_tab.allocate_fill (partial_wave_L_cluster);

      CC_partial_wave_J_cluster_T_tab.allocate_fill (partial_wave_J_cluster);
    }
}








// This routine send the proper shells_quantum_numbers array, according the use of proton, neutron, or diproton, dineutron, deuteron for the relative case

class array<class nlj_struct> & input_data_str::shells_quantum_numbers_determine (const enum particle_type particle)
{
  switch (particle)
    {
    case PROTON:  return prot_shells_quantum_numbers;
    case NEUTRON: return neut_shells_quantum_numbers;
      
    default: return shells_quantum_numbers_relative;
    }
}



const class array<class nlj_struct> & input_data_str::shells_quantum_numbers_determine (const enum particle_type particle) const
{
  switch (particle)
    {
    case PROTON:  return prot_shells_quantum_numbers;
    case NEUTRON: return neut_shells_quantum_numbers;
      
    default: return shells_quantum_numbers_relative;
    }
}









//--// calculate the contour shells (discretization of the complex contour , ...)

void input_data_str::contour_data_fill (
					const enum particle_type particle , 
					const bool OCM_valence_state , 
					const int l , 
					const double j , 
					const complex<double> &k_peak , 
					const unsigned int N_k_peak , 
					const complex<double> &k_middle , 
					const unsigned int N_k_middle , 
					const complex<double> &k_max , 
					const unsigned int N_k_max , 
					const int scat_e_trunc , 
					const class array<class nlj_struct> &shells_quantum_numbers_discrete , 
					class array<class nlj_struct> &shells_quantum_numbers_contour)
{ 
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::contour_data_fill");

  const unsigned int N_nlj_discrete = shells_quantum_numbers_discrete.dimension (0);
  
  const unsigned int N_scat = shells_quantum_numbers_contour.dimension (0);

  int shift_discrete_lj = 0;

  //--// for each shell
  for (unsigned int s = 0 ; s < N_nlj_discrete ; s ++ )
    {
      //--// alias of the shell "shells_quantum_numbers_discrete(s)" of type nlj_struct
      const class nlj_struct &shell_qn = shells_quantum_numbers_discrete(s);

      //--// some temporary constants from the shell
      const int ns = shell_qn.get_n () , ls = shell_qn.get_l ();
      const double js = shell_qn.get_j ();

      //--// One determines the shift which fixes the first n quantum number of contour scattering shells.
      //--// n = 0 if one has no poles of (l , j) quantum numbers , n = 1 if one has one , n = 2 if one has two , ...
      if (same_lj (l , j , ls , js)) shift_discrete_lj = max (shift_discrete_lj , ns + 1);
    }

  //--// some temporary constants from "input_data"
  const complex<double> k_start = k_start_calc (false , particle , l , Z_charge_basis_potential , R); 

  //--// temporary tab to store the positions and associated weights and contour index of the complex contour points (contour shells)
  class array<complex<double> > k_tab (N_scat);
  class array<complex<double> > w_tab (N_scat);
  
  class array<enum segment_type> segment_tab (N_scat);

  for (unsigned int i = 0 ; i < N_k_peak ; i++) segment_tab (i) = ZERO_KPEAK;
  
  for (unsigned int i = 0 ; i < N_k_middle ; i++) segment_tab (i + N_k_peak) = KPEAK_KMIDDLE;

  for (unsigned int i = 0 ; i < N_k_max ; i++) segment_tab (i + N_k_peak + N_k_middle) = KMIDDLE_KMAX;

  //--// for each part of the complex contour
  //--// discretizes the part of the contour with Gauss-Legendre
      
  // three segment (debut)
  if (N_k_peak > 0)   Gauss_Legendre::k_w_tab_segment_part_calc (0 , N_k_peak , k_start , k_peak , k_tab , w_tab);
      
  if (N_k_middle > 0) Gauss_Legendre::k_w_tab_segment_part_calc (N_k_peak , N_k_middle , k_peak , k_middle , k_tab , w_tab);
      
  if (N_k_max > 0)    Gauss_Legendre::k_w_tab_segment_part_calc (N_k_peak + N_k_middle , N_k_max , k_middle , k_max , k_tab , w_tab);
  // three segments (end)
  
  const double factor = 0.25 * M_1_PI;

  //--// for each contour shell (scat states)
  for (unsigned int t = 0 ; t < N_scat ; t ++ ) 
    {
      //--// some temporary constants
      const int n = shift_discrete_lj + static_cast<int> (t);

      const enum segment_type segment = segment_tab (t);
      
      const complex<double> k = k_tab (t);
      const complex<double> w = w_tab (t);
      
      const complex<double> k_plus  = k + factor * w;
      const complex<double> k_minus = k - factor * w;

      class nlj_struct &shell_qn = shells_quantum_numbers_contour (t);
      
      //--// update the empty input tab (contour shells) with the Gauss-Legendre weights
      shell_qn.initialize (false , false , false , false , OCM_valence_state , false , false , false , scat_e_trunc , n , l , j , segment , k , w , 1.0 , 1.0 , k_plus , 1.0 , k_minus , 1.0);

      min_max_one_body_quantum_numbers_N_nlj_nljm_res_update (particle , shell_qn);
    }
}

void input_data_str::shells_quantum_numbers_contours_data_fill (
								const enum particle_type particle , 
								const unsigned int first_index ,
								const class array<class nlj_struct> &shells_quantum_numbers_discrete ,
								const class array<int> &l_array , 
								const class array<double> &j_array , 
								const class array<complex<double> > &k_peak_tab , 
								const class array<complex<double> > &k_middle_tab , 
								const class array<complex<double> > &k_max_tab , 
								const class array<unsigned int> &N_k_peak_tab , 
								const class array<unsigned int> &N_k_middle_tab , 
								const class array<unsigned int> &N_k_max_tab , 
								const class array<int> &scat_e_trunc_tab) 
{	
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::shells_quantum_numbers_contours_data_fill.");

  const bool is_it_COSM = is_it_COSM_determine (inter);

  const unsigned int N_paths = k_peak_tab.dimension (0);

  class array<class nlj_struct> &shells_quantum_numbers = shells_quantum_numbers_determine (particle);

  //--// temporary constant
  unsigned int index = first_index;

  //--// for each complex contour
  for (unsigned int p = 0 ; p < N_paths ; p ++ )
    {
      //--// some temporary constants
      const int l = l_array (p);

      const double j = j_array (p);

      const complex<double> k_peak   = k_peak_tab   (p);
      const complex<double> k_middle = k_middle_tab (p);
      const complex<double> k_max    = k_max_tab    (p);
      
      const unsigned int N_k_peak   = N_k_peak_tab   (p);
      const unsigned int N_k_middle = N_k_middle_tab (p);
      const unsigned int N_k_max    = N_k_max_tab    (p);
      
      const unsigned int N_scat = N_k_peak + N_k_middle + N_k_max;

      const int scat_e_trunc = scat_e_trunc_tab (p);

      const bool OCM_valence_state = OCM_valence_state_determine (shells_quantum_numbers_discrete , is_it_COSM , false , l , j);

      //--// tab to store temporary the contour shells
      class array<class nlj_struct> shells_quantum_numbers_contour(N_scat);

      //--// calculate the contour shells (discretization of the complex contour , ...)
      contour_data_fill (particle , OCM_valence_state , l , j , k_peak , N_k_peak , k_middle , N_k_middle , k_max , N_k_max , scat_e_trunc , shells_quantum_numbers_discrete , shells_quantum_numbers_contour);

      //--// copy the contour shells (scat states) at the end of the temporary tab "shells_quantum_numbers"
      for (unsigned int i = 0 ; i < N_scat ; i ++ ) shells_quantum_numbers(index++) = shells_quantum_numbers_contour(i);
    }
}











// This routine is used in the GSM optimization code. The common input_data structure, which contains data common to all fitted nuclei, is updated here from the knowledge of particular input_data structures for each nucleus.
// Modified values must indeed be the minimal or maximal values present in the particular input_data structures for each nucleus.

void input_data_str::lmax_BP_J_min_max_global_from_input_data_tab (const class array<class input_data_str> &input_data_tab_for_optimization)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::lmax_BP_J_min_max_global_from_input_data_tab");

  const int lmax_p_all_input_data_tab_for_optimization = lmax_p_all_determine (input_data_tab_for_optimization);
  const int lmax_n_all_input_data_tab_for_optimization = lmax_n_all_determine (input_data_tab_for_optimization);

  lmax_p = lmax_common_p = lmax_p_all_input_data_tab_for_optimization;
  lmax_n = lmax_common_n = lmax_n_all_input_data_tab_for_optimization;

  if (space != NEUTRONS_ONLY)
    {
      if ((lmax_p_all_input_data_tab_for_optimization == 0) && is_Vso_p_fitted) error_message_print_abort ("One cannot fit the proton core spin-orbit potential strength with s1/2 partial waves only.");
    }

  if (space != PROTONS_ONLY)
    {
      if ((lmax_n_all_input_data_tab_for_optimization == 0) && is_Vso_n_fitted)	error_message_print_abort ("One cannot fit the neutron core spin-orbit potential strength with s1/2 partial waves only.");
    }

  const int Zval_max_all = Zval_max_all_determine (input_data_tab_for_optimization);
  const int Nval_max_all = Nval_max_all_determine (input_data_tab_for_optimization);

  const unsigned int BPmin_global_pp_all = BPmin_global_pp_all_determine (input_data_tab_for_optimization);
  const unsigned int BPmax_global_pp_all = BPmax_global_pp_all_determine (input_data_tab_for_optimization);

  const unsigned int BPmin_global_nn_all = BPmin_global_nn_all_determine (input_data_tab_for_optimization);
  const unsigned int BPmax_global_nn_all = BPmax_global_nn_all_determine (input_data_tab_for_optimization);

  const unsigned int BPmin_global_pn_all = BPmin_global_pn_all_determine (input_data_tab_for_optimization);
  const unsigned int BPmax_global_pn_all = BPmax_global_pn_all_determine (input_data_tab_for_optimization);
  
  const int Jmin_global_pp_all = Jmin_global_pp_all_determine (input_data_tab_for_optimization);
  const int Jmax_global_pp_all = Jmax_global_pp_all_determine (input_data_tab_for_optimization);
  
  const int Jmin_global_nn_all = Jmin_global_nn_all_determine (input_data_tab_for_optimization);
  const int Jmax_global_nn_all = Jmax_global_nn_all_determine (input_data_tab_for_optimization);

  const int Jmin_global_pn_all = Jmin_global_pn_all_determine (input_data_tab_for_optimization);
  const int Jmax_global_pn_all = Jmax_global_pn_all_determine (input_data_tab_for_optimization);

  const int Jmin_global_pp_opp_all = Jmin_global_pp_opp_all_determine (input_data_tab_for_optimization);
  const int Jmax_global_pp_opp_all = Jmax_global_pp_opp_all_determine (input_data_tab_for_optimization);
  
  const int Jmin_global_nn_opp_all = Jmin_global_nn_opp_all_determine (input_data_tab_for_optimization);
  const int Jmax_global_nn_opp_all = Jmax_global_nn_opp_all_determine (input_data_tab_for_optimization);

  const int Jmin_global_pn_opp_all = Jmin_global_pn_opp_all_determine (input_data_tab_for_optimization);
  const int Jmax_global_pn_opp_all = Jmax_global_pn_opp_all_determine (input_data_tab_for_optimization);

  Zval = Zval_max_all;
  Nval = Nval_max_all;

  BPmin_global_pp = BPmin_global_pp_all;
  BPmax_global_pp = BPmax_global_pp_all;

  BPmin_global_nn = BPmin_global_nn_all;
  BPmax_global_nn = BPmax_global_nn_all;
  
  BPmin_global_pn = BPmin_global_pn_all;
  BPmax_global_pn = BPmax_global_pn_all;
  
  Jmin_global_pp = Jmin_global_pp_all;
  Jmax_global_pp = Jmax_global_pp_all;

  Jmin_global_nn = Jmin_global_nn_all;
  Jmax_global_nn = Jmax_global_nn_all;

  Jmin_global_pn = Jmin_global_pn_all;
  Jmax_global_pn = Jmax_global_pn_all;
  
  Jmin_global_pp_opp = Jmin_global_pp_opp_all;
  Jmax_global_pp_opp = Jmax_global_pp_opp_all;

  Jmin_global_nn_opp = Jmin_global_nn_opp_all;
  Jmax_global_nn_opp = Jmax_global_nn_opp_all;

  Jmin_global_pn_opp = Jmin_global_pn_opp_all;
  Jmax_global_pn_opp = Jmax_global_pn_opp_all;
}	

void input_data_str::Zval_Nval_BP_J_min_max_basis_calc_from_input_data_tab (const class array<class input_data_str> &input_data_tab_for_optimization)
{
  Zval_basis = Nval_basis = 0;

  BPmin_global_pp_basis = BPmin_global_nn_basis = BPmin_global_pn_basis = 1;
  BPmax_global_pp_basis = BPmax_global_nn_basis = BPmax_global_pn_basis = 0;

  Jmin_global_pp_basis = Jmin_global_nn_basis = Jmin_global_pn_basis = 1000000;
  Jmax_global_pp_basis = Jmax_global_nn_basis = Jmax_global_pn_basis = 0;
  
  Jmin_global_pp_opp_basis = Jmin_global_nn_opp_basis = Jmin_global_pn_opp_basis = 1000000;
  Jmax_global_pp_opp_basis = Jmax_global_nn_opp_basis = Jmax_global_pn_opp_basis = 0;

  for (unsigned int i = 0 ; i < N_nuclei_to_consider ; i++)
    {
      const class input_data_str &input_data = input_data_tab_for_optimization(i);

      const enum potential_type basis_potential_input_data = input_data.basis_potential;

      if ((basis_potential_input_data == HF) || (basis_potential_input_data == MSDHF)) basis_potential = HF;

      Zval_basis = max (Zval_basis , input_data.Zval_basis);
      Nval_basis = max (Nval_basis , input_data.Nval_basis);

      BPmin_global_pp_basis = min (BPmin_global_pp_basis , input_data.BPmin_global_pp_basis);
      BPmax_global_pp_basis = max (BPmax_global_pp_basis , input_data.BPmax_global_pp_basis);

      BPmin_global_nn_basis = min (BPmin_global_nn_basis , input_data.BPmin_global_nn_basis);
      BPmax_global_nn_basis = max (BPmax_global_nn_basis , input_data.BPmax_global_nn_basis);
      
      BPmin_global_pn_basis = min (BPmin_global_pn_basis , input_data.BPmin_global_pn_basis);
      BPmax_global_pn_basis = max (BPmax_global_pn_basis , input_data.BPmax_global_pn_basis);
      
      Jmin_global_pp_basis = min (Jmin_global_pp_basis , input_data.Jmin_global_pp_basis);
      Jmax_global_pp_basis = max (Jmax_global_pp_basis , input_data.Jmax_global_pp_basis);

      Jmin_global_nn_basis = min (Jmin_global_nn_basis , input_data.Jmin_global_nn_basis);
      Jmax_global_nn_basis = max (Jmax_global_nn_basis , input_data.Jmax_global_nn_basis);

      Jmin_global_pn_basis = min (Jmin_global_pn_basis , input_data.Jmin_global_pn_basis);
      Jmax_global_pn_basis = max (Jmax_global_pn_basis , input_data.Jmax_global_pn_basis);
      
      Jmin_global_pp_opp_basis = min (Jmin_global_pp_opp_basis , input_data.Jmin_global_pp_opp_basis);
      Jmax_global_pp_opp_basis = max (Jmax_global_pp_opp_basis , input_data.Jmax_global_pp_opp_basis);

      Jmin_global_nn_opp_basis = min (Jmin_global_nn_opp_basis , input_data.Jmin_global_nn_opp_basis);
      Jmax_global_nn_opp_basis = max (Jmax_global_nn_opp_basis , input_data.Jmax_global_nn_opp_basis);

      Jmin_global_pn_opp_basis = min (Jmin_global_pn_opp_basis , input_data.Jmin_global_pn_opp_basis);
      Jmax_global_pn_opp_basis = max (Jmax_global_pn_opp_basis , input_data.Jmax_global_pn_opp_basis);
    }
}



// This routine is used in case one uses the same potential for protons and neutrons. Indeed, proton structures are replaces by neutron structures in calculations, so that proton and neutron spaces must be symmetric.
// This is consistent with the fact that this routine is used to check isospin properties of the many-body nucleus, where proton and neutron spaces must be symmetric to properly check for isospin mixing.

void input_data_str::same_proton_neutron_partial_waves_check () const
{
  if ((space == PROTONS_NEUTRONS) && neutron_basis_potential)
    {  
      if (nmax_p != nmax_n) error_message_print_abort ("nmax must be the same for protons and neutrons.");
      if (lmax_p != lmax_n) error_message_print_abort ("lmax must be the same for protons and neutrons.");

      if (Np_nlj != Nn_nlj) error_message_print_abort ("N_nlj must be the same for protons and neutrons.");

      for (int l = 0 ; l <= lmax_p ; l++)
	for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	  {
	    if (abs (prot_b_lab_partial_waves(l , j) - neut_b_lab_partial_waves(l , j)) > precision)
	      error_message_print_abort ("b[HO] must be the same for protons and neutrons in the partial wave " + angular_state (l,j));
	  }
      
      for (unsigned int i = 0 ; i < Np_nlj ; i++)
	{
	  const class nlj_struct &shell_qn_p = prot_shells_quantum_numbers (i);
	  const class nlj_struct &shell_qn_n = neut_shells_quantum_numbers (i);

	  if (shell_qn_p != shell_qn_n)
	    { 
	      const string same_str = "Proton and neutron shells must be the same";

	      error_message_print_abort (same_str + " : i=" + make_string<unsigned int> (i) + " , proton " + make_string<class nlj_struct> (shell_qn_p) + " different from neutron " + make_string<class nlj_struct> (shell_qn_n));
	    }
	} 
    }
}



// Check if the projectile is made of only one nucleon 

bool input_data_str::is_it_one_nucleon_case_determine () const
{
  for (unsigned int iT = 0 ; iT < CC_N_target_projectile_states ; iT++)
    {
      const enum particle_type projectile = CC_projectile_tab(iT);

      if ((projectile != PROTON) && (projectile != NEUTRON)) return false;
    }

  return true;
}






// find the projectile type of the entrance channel

enum particle_type input_data_str::entrance_projectile_determine () const
{
  for (unsigned int iT = 0 ; iT < CC_N_target_projectile_states ; iT++)
    {
      const bool is_it_entrance_channel = CC_is_it_entrance_tab(iT);

      if (is_it_entrance_channel)
	{
	  const enum particle_type projectile = CC_projectile_tab(iT);

	  return projectile;
	}
    }

  return CC_projectile_tab(0);
}






// find if there exists a cluster partial wave of (L,J) quantum nmubers

bool input_data_str::is_there_cluster_partial_wave_determine (
							      const enum particle_type cluster , 
							      const int L ,
							      const double J) const
{
  for (unsigned int iT = 0 ; iT < CC_N_target_projectile_states ; iT++)
    {
      const enum particle_type projectile_T = CC_projectile_tab(iT);

      if (projectile_T == cluster)
	{
	  const unsigned int N_partial_waves_T = CC_N_partial_waves_tab(iT);

	  for (unsigned int ilj_T = 0 ; ilj_T < N_partial_waves_T ; ilj_T++)
	    {
	      const int LT = CC_partial_wave_L_cluster_tab(iT , ilj_T);

	      const double JT = CC_partial_wave_J_cluster_tab(iT , ilj_T);

	      if (same_lj (L , J , LT , JT)) return true;
	    }
	}
    }

  return false;
}






// Calculates the maximal principal quantum number for a given channel of index ic and (L,J) quantum nmubers

int input_data_str::Nmax_LJ_cluster_determine (const unsigned int ic , const int L , const double J) const
{
  const enum particle_type cluster = CC_cluster_tab(ic);
  
  const double J_intrinsic = J_intrinsic_projectile_determine (cluster);

  const double J_min = abs (J_intrinsic - L);

  const int J_index = make_int (J - J_min);

  const unsigned int CC_Nres_LJ = CC_N_poles_cluster_CM_tab(ic , L , J_index);

  const unsigned int CC_Nscat_LJ = CC_N_K_peak_cluster_CM_tab(ic , L , J_index) + CC_N_K_middle_cluster_CM_tab(ic , L , J_index) + CC_N_K_max_cluster_CM_tab(ic , L , J_index);

  const int CC_Nmax_LJ = make_int (CC_Nres_LJ + CC_Nscat_LJ) - 1;

  return CC_Nmax_LJ;
}









// Check if the cluster channels of index ic and icp are identical. If it is the case, one can use the same radial wave function basis arrays for both.

bool input_data_str::are_cluster_CM_bases_identical (const unsigned int ic , const unsigned int icp) const
{
  if (ic == icp) return true;

  const enum particle_type cluster_c  = CC_cluster_tab(ic);
  const enum particle_type cluster_cp = CC_cluster_tab(icp);
    
  const int Z_cluster_c  = Z_projectile_determine (cluster_c);
  const int Z_cluster_cp = Z_projectile_determine (cluster_cp);

  if (Z_cluster_c != Z_cluster_cp) return false;

  const int N_cluster_c  = N_projectile_determine (cluster_c);
  const int N_cluster_cp = N_projectile_determine (cluster_cp);

  if (N_cluster_c != N_cluster_cp) return false;

  const unsigned int BP_intrinsic_c  = BP_intrinsic_projectile_determine (cluster_c);
  const unsigned int BP_intrinsic_cp = BP_intrinsic_projectile_determine (cluster_cp);

  if (BP_intrinsic_c != BP_intrinsic_cp) return false;

  const double J_intrinsic_c  = J_intrinsic_projectile_determine (cluster_c);
  const double J_intrinsic_cp = J_intrinsic_projectile_determine (cluster_cp);

  if (rint (J_intrinsic_c - J_intrinsic_cp) != 0.0) return false;

  const int CC_Lmax_c  = CC_Lmax_cluster_CM_tab(ic);
  const int CC_Lmax_cp = CC_Lmax_cluster_CM_tab(icp);

  if (CC_Lmax_c != CC_Lmax_cp) return false;

  for (int L = 0 ; L <= CC_Lmax_c ; L++)
    {
      const double J_min = abs (J_intrinsic_c - L);
      
      const double J_max = J_intrinsic_c + L;

      const int J_number = make_int (J_max - J_min) + 1;

      for (int J_index = 0 ; J_index < J_number ; J_index++)
	{
	  const int CC_N_poles_LJ_c  = make_int (CC_N_poles_cluster_CM_tab(ic  , L , J_index));
	  const int CC_N_poles_LJ_cp = make_int (CC_N_poles_cluster_CM_tab(icp , L , J_index));

	  if (CC_N_poles_LJ_c != CC_N_poles_LJ_cp) return false;

	  const unsigned int CC_N_K_peak_c  = CC_N_K_peak_cluster_CM_tab(ic  , L , J_index);
	  const unsigned int CC_N_K_peak_cp = CC_N_K_peak_cluster_CM_tab(icp , L , J_index);

	  if (CC_N_K_peak_c != CC_N_K_peak_cp) return false;

	  const unsigned int CC_N_K_middle_c  = CC_N_K_middle_cluster_CM_tab(ic  , L , J_index);
	  const unsigned int CC_N_K_middle_cp = CC_N_K_middle_cluster_CM_tab(icp , L , J_index);

	  if (CC_N_K_middle_c != CC_N_K_middle_cp) return false;

	  const unsigned int CC_N_K_max_c  = CC_N_K_max_cluster_CM_tab(ic  , L , J_index);
	  const unsigned int CC_N_K_max_cp = CC_N_K_max_cluster_CM_tab(icp , L , J_index);

	  if (CC_N_K_max_c != CC_N_K_max_cp) return false;

	  const complex<double> CC_K_peak_c   = CC_K_peak_cluster_CM_tab(ic  , L , J_index);
	  const complex<double> CC_K_peak_cp  = CC_K_peak_cluster_CM_tab(icp , L , J_index);

	  if (inf_norm (CC_K_peak_c - CC_K_peak_cp) > precision) return false;

	  const complex<double> CC_K_middle_c  = CC_K_middle_cluster_CM_tab(ic  , L , J_index);
	  const complex<double> CC_K_middle_cp = CC_K_middle_cluster_CM_tab(icp , L , J_index);

	  if (inf_norm (CC_K_middle_c - CC_K_middle_cp) > precision) return false;

	  const complex<double> CC_K_max_c  = CC_K_max_cluster_CM_tab(ic  , L , J_index);
	  const complex<double> CC_K_max_cp = CC_K_max_cluster_CM_tab(icp , L , J_index);

	  if (inf_norm (CC_K_max_c - CC_K_max_cp) > precision) return false;
	}
    }
  
  return true;
}






// Calculates the maximal principal quantum number for a given channel of index ic for all possible (L,J) quantum nmubers

int input_data_str::Nmax_cluster_determine (const unsigned int ic) const
{	
  const enum particle_type cluster = CC_cluster_tab(ic);
  
  const double J_intrinsic = J_intrinsic_projectile_determine (cluster);

  const int CC_Lmax = CC_Lmax_cluster_CM_tab(ic);

  int Nmax = 0;

  for (int L = 0 ; L <= CC_Lmax ; L++)
    {
      const double J_min = abs (J_intrinsic - L);

      const double J_max = J_intrinsic + L;
      
      const unsigned int J_number = make_uns_int (J_max - J_min) + 1;

      for (unsigned int J_index = 0 ; J_index < J_number ; J_index++)
	{
	  const double J = J_min + J_index;

	  const int Nmax_LJ = Nmax_LJ_cluster_determine (ic , L , J);
	      
	  Nmax = max (Nmax_LJ , Nmax);
	}
    }

  return Nmax;
}







// Determines the energy of the intrinsic state a given cluster channel of index ic

complex<double> input_data_str::E_intrinsic_cluster_determine (const unsigned int ic) const
{	
  const enum particle_type cluster = CC_cluster_tab(ic);

  for (unsigned int iT = 0 ; iT < CC_N_target_projectile_states ; iT++)
    {
      const enum particle_type projectile_T = CC_projectile_tab(iT); 

      if (projectile_T == cluster)
	{
	  const double real_E_intrinsic_projectile_T = CC_real_E_intrinsic_projectile_tab(iT);
	  
	  const double Gamma_intrinsic_projectile_T = CC_Gamma_intrinsic_projectile_tab(iT);
	  
	  const complex<double> E_intrinsic_projectile_T(real_E_intrinsic_projectile_T , -5E-4*Gamma_intrinsic_projectile_T);

	  return E_intrinsic_projectile_T;
	}
    }

  return 0.0;
}








// Initializes the Z,N,J, vector index i and binary parity (see observables_basic_functions.cpp for definition) quantum numbers for the many-body states to calculate

void input_data_str::PSI_quantum_numbers_tab_partial_fill (
							   const class array<unsigned long int> &dimensions_good_J , 
							   class array<class correlated_state_str> &PSI_quantum_numbers_tab) const
{
  const int n_scat_max_here = dimensions_good_J.dimension (1) - 1;

  for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
    {
      if (all_states_calculated)
	{
	  const unsigned int BP = BP_eigenset_tab(eigenset_index);
	  
	  const double J = J_eigenset_tab(eigenset_index);

	  const int two_J = make_int (2.0*J);

	  const int J_index = (two_J%2 == 0) ? (make_int (J)) : (make_int (J - 0.5));

	  const unsigned int dimension_good_J = dimensions_good_J (BP , n_scat_max_here , J_index);

	  for (unsigned int i = 0 ; i < dimension_good_J ; i++)
	    PSI_quantum_numbers_tab(eigenset_index , i).initialize (Z , N , BP , J , i , 0.0 , NADA , NADA , NADA , false);
	}
      else
	{ 
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    PSI_quantum_numbers_tab(eigenset_index , i) = PSI_qn_from_file_tab(eigenset_index , i);
	}
    }
}






// Calculates the number of channels  of a given composite in GSM-CC 
// A channel is made of intrinsic + center of mass parts (of orbital angular momentum LCM) for the projectile and target part (of total angular momentum J_T and binary parity BP_T from Parity_T). 
// Then, by looping over all binary parities (see observables_basic_functions.cpp for definition) and total angular momenta of the composite BP_A and J_A,
// one must have J_projectile = J_intrinsic + LCM and J_A = J_projectile + J_T, and Parity_projectile = Parity_intrinsic . (1)^LCM, and Parity_A = Parity_projectile . Parity_T.
// If these relations are fulfilled, one adds another channel.
// The number of channels is then returned.

unsigned int input_data_str::N_channels_calc (
					      const class array<unsigned int> &BP_A_tab , 
					      const class array<double> &J_A_tab) const
{	
  const unsigned int N_JPi_A = BP_A_tab.dimension (0);

  unsigned int N_channels = 0;

  for (unsigned int iJPi_A = 0 ; iJPi_A < N_JPi_A ; iJPi_A++)
    {
      const double J_A = J_A_tab(iJPi_A);

      const unsigned int BP_A = BP_A_tab(iJPi_A);

      for (unsigned int iT = 0 ; iT < CC_N_target_projectile_states ; iT++)
	{
	  const double J_T = CC_J_target_tab(iT);

	  const unsigned int BP_T = CC_BP_target_tab(iT);
	  
	  const enum particle_type projectile = CC_projectile_tab(iT);

	  const unsigned int BP_intrinsic_projectile = BP_intrinsic_projectile_determine (projectile);

	  const double J_intrinsic_projectile = J_intrinsic_projectile_determine (projectile);

	  // Properties of the partial waves
	  const unsigned int N_partial_waves = CC_N_partial_waves_tab(iT);

	  for (unsigned int i_projectile = 0 ; i_projectile < N_partial_waves ; i_projectile++)
	    {
	      const int LCM_projectile = CC_partial_wave_L_cluster_tab(iT , i_projectile);

	      const unsigned int BP_LCM_projectile = binary_parity_from_orbital_angular_momentum (LCM_projectile);

	      const double J_projectile = CC_partial_wave_J_cluster_tab(iT , i_projectile);

	      const unsigned int BP_projectile = binary_parity_product (BP_intrinsic_projectile , BP_LCM_projectile);

	      const bool is_J_projectile_ok = is_it_triangle (LCM_projectile , J_intrinsic_projectile , J_projectile);

	      const bool is_BP_projectile_ok = (binary_parity_product (BP_LCM_projectile , BP_intrinsic_projectile) == BP_projectile);

	      if (is_J_projectile_ok && is_BP_projectile_ok)
		{
		  const bool is_J_A_ok = is_it_triangle (J_T , J_projectile , J_A);

		  const bool is_BP_A_ok = (binary_parity_product (BP_T , BP_projectile) == BP_A);

		  //xyz radiative capture
		  //remove channels generating Pauli forbidden states for 17F(p , gamma)18Ne with a 16O core
		  // No 5/2+ J_Tc target for 1/2+ physical entrance target
		  //if (!((rint (J_Tc - 2.5) == 0.0) && (lc == 0) && (rint (jc - 0.5) == 0.0)))
		  // No 1/2+ J_Tc target for 5/2+ physical entrance target
		  //if (!((rint (J_Tc - 0.5) == 0.0) && (lc == 2) && (rint (jc - 2.5) == 0.0)))

		  if (is_J_A_ok && is_BP_A_ok) N_channels++;
		}
	    }
	}
    }

  return N_channels;
}









// The maximal number of channels for a reaction is returned. It is the number of channels for scattering and the maximal of in and out number of channels for radiative capture.

unsigned int input_data_str::N_channels_max_calc () const 
{

  if (CC_reaction == SCATTERING)
    {
      const unsigned int N_channels = N_channels_calc (CC_BP_A_composite_tab , CC_J_A_composite_tab);

      return N_channels;
    }

  if (CC_reaction == RADIATIVE_CAPTURE)
    {
      const unsigned int N_channels_in = N_channels_calc (CC_BP_A_in_composite_tab , CC_J_A_in_composite_tab);

      const unsigned int N_channels_out = N_channels_calc (CC_BP_A_out_composite_tab , CC_J_A_out_composite_tab);

      const unsigned int N_channels_max = max (N_channels_in , N_channels_out);

      return N_channels_max;
    }

  error_message_print_abort ("No reaction type recognized in input_data_str::N_channels_max_calc");

  return NADA;
}





// According to the number of valence protons/neutrons, valence proton/neutron states and demanded maximal number of protons and neutrons in the continuum,
// the actual maximal number of protons and neutrons in the continuum must be modified accordingly.

void input_data_str::all_n_scat_max_modification (
						  const enum space_type space , 
						  const bool truncation_ph , 
						  const class nucleons_data &prot_data , 
						  const class nucleons_data &neut_data)
{
  switch (space)
    {
    case PROTONS_ONLY:
      {
	n_scat_max_p = n_scat_max_pp_nn_calc (truncation_ph , n_scat_max_p , prot_data);
	
	n_scat_max_n = 0;

	n_scat_max = n_scat_max_p;
      } break;

    case NEUTRONS_ONLY:
      {
	n_scat_max_p = 0;
	
	n_scat_max_n = n_scat_max_pp_nn_calc (truncation_ph , n_scat_max_n , neut_data);

	n_scat_max = n_scat_max_n;
      } break;

    case PROTONS_NEUTRONS: 
      {
	n_scat_max_p = n_scat_max_pp_nn_calc (truncation_ph , n_scat_max_p , prot_data);
	n_scat_max_n = n_scat_max_pp_nn_calc (truncation_ph , n_scat_max_n , neut_data);

	n_scat_max = n_scat_max_pn_calc (truncation_ph , n_scat_max , prot_data , neut_data);
      } break;

    default: abort_all ();
    }
}




// The maximal truncation energy at pole approximation level and full GSM space are calculated here.

void input_data_str::all_E_max_hw_calc ()
{
  const int Ep_min_hw = E_min_hw_pp_nn (Zval , prot_shells_quantum_numbers);

  const int En_min_hw = E_min_hw_pp_nn (Nval , neut_shells_quantum_numbers);

  const int E_min_hw = Ep_min_hw + En_min_hw;

  E_max_hw = E_relative_max_hw + E_min_hw;
  
  E_max_hw_pole_approximation = E_relative_max_hw_pole_approximation + E_min_hw;
}




// WS and FHT/EFT parameters of input arrays are copied to input_data_str here when using the GSM optimization code.

void input_data_str::set_FHT_EFT_interaction_parameters (const class vector_class<double> &FHT_EFT_parameters)
{
  if (is_it_FHT_determine (inter))
    {
      const unsigned int V0_ctr_ot_index = FHT_EFT_parameter_index_determine (V0_CTR_OT_S1_T1 , NADA , NADA);
      const unsigned int V0_ctr_et_index = FHT_EFT_parameter_index_determine (V0_CTR_ET_S1_T0 , NADA , NADA);
      const unsigned int V0_ctr_os_index = FHT_EFT_parameter_index_determine (V0_CTR_OS_S0_T0 , NADA , NADA);
      const unsigned int V0_ctr_es_index = FHT_EFT_parameter_index_determine (V0_CTR_ES_S0_T1 , NADA , NADA);
      const unsigned int V0_so_ot_index  = FHT_EFT_parameter_index_determine (V0_SO_OT_S1_T1  , NADA , NADA);
      const unsigned int V0_so_et_index  = FHT_EFT_parameter_index_determine (V0_SO_ET_S1_T0  , NADA , NADA);
      const unsigned int V0_t_ot_index   = FHT_EFT_parameter_index_determine (V0_T_OT_S1_T1   , NADA , NADA);
      const unsigned int V0_t_et_index   = FHT_EFT_parameter_index_determine (V0_T_ET_S1_T0   , NADA , NADA);

      V0_ctr_ot = FHT_EFT_parameters(V0_ctr_ot_index);
      V0_ctr_et = FHT_EFT_parameters(V0_ctr_et_index);
      V0_ctr_os = FHT_EFT_parameters(V0_ctr_os_index);
      V0_ctr_es = FHT_EFT_parameters(V0_ctr_es_index);
      V0_so_ot  = FHT_EFT_parameters(V0_so_ot_index);
      V0_so_et  = FHT_EFT_parameters(V0_so_et_index);
      V0_t_ot   = FHT_EFT_parameters(V0_t_ot_index);
      V0_t_et   = FHT_EFT_parameters(V0_t_et_index);
    }
  
  if (is_it_EFT_determine (inter))
    {
      const unsigned int VS_const_LO_T0_index          = FHT_EFT_parameter_index_determine (VS_LO_T0                , NADA , NADA);
      const unsigned int VS_const_LO_T1_index          = FHT_EFT_parameter_index_determine (VS_LO_T1                , NADA , NADA);
      const unsigned int VT_sigma_product_LO_T0_index  = FHT_EFT_parameter_index_determine (VT_SIGMA_PRODUCT_LO_T0  , NADA , NADA);
      const unsigned int VT_sigma_product_LO_T1_index  = FHT_EFT_parameter_index_determine (VT_SIGMA_PRODUCT_LO_T1  , NADA , NADA);
      const unsigned int V1_q2_NLO_index               = FHT_EFT_parameter_index_determine (V1_Q2_NLO               , NADA , NADA);
      const unsigned int V2_k2_NLO_index               = FHT_EFT_parameter_index_determine (V2_K2_NLO               , NADA , NADA);  
      const unsigned int V3_q2_sigma_product_NLO_index = FHT_EFT_parameter_index_determine (V3_Q2_SIGMA_PRODUCT_NLO , NADA , NADA);
      const unsigned int V4_k2_sigma_product_NLO_index = FHT_EFT_parameter_index_determine (V4_K2_SIGMA_PRODUCT_NLO , NADA , NADA);
      const unsigned int V5_sigma_q_vector_k_NLO_index = FHT_EFT_parameter_index_determine (V5_SIGMA_Q_VECTOR_K_NLO , NADA , NADA);  
      const unsigned int V6_sigma_q_product_NLO_index  = FHT_EFT_parameter_index_determine (V6_SIGMA_Q_PRODUCT_NLO  , NADA , NADA);
      const unsigned int V7_sigma_k_product_NLO_index  = FHT_EFT_parameter_index_determine (V7_SIGMA_K_PRODUCT_NLO  , NADA , NADA);
      
      VS_const_LO_T0          = FHT_EFT_parameters(VS_const_LO_T0_index);
      VS_const_LO_T1          = FHT_EFT_parameters(VS_const_LO_T1_index);
      VT_sigma_product_LO_T0  = FHT_EFT_parameters(VT_sigma_product_LO_T0_index);  
      VT_sigma_product_LO_T1  = FHT_EFT_parameters(VT_sigma_product_LO_T1_index);      
      V1_q2_NLO               = FHT_EFT_parameters(V1_q2_NLO_index);
      V2_k2_NLO               = FHT_EFT_parameters(V2_k2_NLO_index);
      V3_q2_sigma_product_NLO = FHT_EFT_parameters(V3_q2_sigma_product_NLO_index);
      V4_k2_sigma_product_NLO = FHT_EFT_parameters(V4_k2_sigma_product_NLO_index);
      V5_sigma_q_vector_k_NLO = FHT_EFT_parameters(V5_sigma_q_vector_k_NLO_index);  
      V6_sigma_q_product_NLO  = FHT_EFT_parameters(V6_sigma_q_product_NLO_index);
      V7_sigma_k_product_NLO  = FHT_EFT_parameters(V7_sigma_k_product_NLO_index);
    }
  
  const unsigned int R_charge_index = FHT_EFT_parameter_index_determine (CORE_R_CHARGE_PROTON , NADA , NADA);

  R_charge = FHT_EFT_parameters(R_charge_index);
}

void input_data_str::set_FHT_EFT_WS_parameters (
						const bool is_it_only_basis ,
						const class array<class input_data_str> &input_data_tab , 
						const class vector_class<double> &FHT_EFT_parameters)
{
  const int lmax_p_all_inputs = lmax_p_all_determine (input_data_tab);
  const int lmax_n_all_inputs = lmax_n_all_determine (input_data_tab);
  
  const int lmax_all_inputs = max (lmax_p_all_inputs , lmax_n_all_inputs);

  for (int l = 0 ; l <= lmax_p ; l++)
    {
      const unsigned int prot_index_from_WS_d   = FHT_EFT_parameter_index_determine (CORE_D_PROTON   , lmax_all_inputs , l);
      const unsigned int prot_index_from_WS_R0  = FHT_EFT_parameter_index_determine (CORE_R0_PROTON  , lmax_all_inputs , l);
      const unsigned int prot_index_from_WS_Vo  = FHT_EFT_parameter_index_determine (CORE_VO_PROTON  , lmax_all_inputs , l);
      const unsigned int prot_index_from_WS_Vso = FHT_EFT_parameter_index_determine (CORE_VSO_PROTON , lmax_all_inputs , l);

      if (is_it_only_basis)
	{
	  prot_d_basis_tab(l)   = FHT_EFT_parameters(prot_index_from_WS_d); 
	  prot_R0_basis_tab(l)  = FHT_EFT_parameters(prot_index_from_WS_R0);
	  prot_Vo_basis_tab(l)  = FHT_EFT_parameters(prot_index_from_WS_Vo); 
	  prot_Vso_basis_tab(l) = FHT_EFT_parameters(prot_index_from_WS_Vso);
	}
      else
	{
	  prot_d_core_potential_tab(l)   = FHT_EFT_parameters(prot_index_from_WS_d); 
	  prot_R0_core_potential_tab(l)  = FHT_EFT_parameters(prot_index_from_WS_R0);
	  prot_Vo_core_potential_tab(l)  = FHT_EFT_parameters(prot_index_from_WS_Vo); 
	  prot_Vso_core_potential_tab(l) = FHT_EFT_parameters(prot_index_from_WS_Vso);
	}
    }

  for (int l = 0 ; l <= lmax_n ; l++)
    {
      const unsigned int neut_index_from_WS_d   = FHT_EFT_parameter_index_determine (CORE_D_NEUTRON   , lmax_all_inputs , l);
      const unsigned int neut_index_from_WS_R0  = FHT_EFT_parameter_index_determine (CORE_R0_NEUTRON  , lmax_all_inputs , l);
      const unsigned int neut_index_from_WS_Vo  = FHT_EFT_parameter_index_determine (CORE_VO_NEUTRON  , lmax_all_inputs , l);
      const unsigned int neut_index_from_WS_Vso = FHT_EFT_parameter_index_determine (CORE_VSO_NEUTRON , lmax_all_inputs , l);

      if (is_it_only_basis)
	{
	  neut_d_basis_tab(l)   = FHT_EFT_parameters(neut_index_from_WS_d); 
	  neut_R0_basis_tab(l)  = FHT_EFT_parameters(neut_index_from_WS_R0);
	  neut_Vo_basis_tab(l)  = FHT_EFT_parameters(neut_index_from_WS_Vo); 
	  neut_Vso_basis_tab(l) = FHT_EFT_parameters(neut_index_from_WS_Vso);
	}
      else
	{
	  neut_d_core_potential_tab(l)   = FHT_EFT_parameters(neut_index_from_WS_d); 
	  neut_R0_core_potential_tab(l)  = FHT_EFT_parameters(neut_index_from_WS_R0);
	  neut_Vo_core_potential_tab(l)  = FHT_EFT_parameters(neut_index_from_WS_Vo); 
	  neut_Vso_core_potential_tab(l) = FHT_EFT_parameters(neut_index_from_WS_Vso);
	}
    }
}






// Maximal principal quantum numbers of protons and neutrons must be added N_channels_max, as one uses channel index as principal quantum number in GSM_CC in the HF/MSDHF procedure.

void input_data_str::add_N_channels_max_to_nmax (const int N_channels_max)
{
  if (Zval != 0) nmax_p += N_channels_max;
  if (Nval != 0) nmax_n += N_channels_max;
}



// Member data are changed here

void input_data_str::set_all_n_holes_max_n_scat_max_E_max (const class input_data_str &input_data)
{
  n_holes_max_pole_approximation = input_data.n_holes_max_pole_approximation;
  
  n_holes_max = input_data.n_holes_max;

  n_scat_max = input_data.n_scat_max;
  
  E_max_hw = input_data.E_max_hw;
  
  E_max_hw_pole_approximation = input_data.E_max_hw_pole_approximation;

  n_holes_max_p_pole_approximation = input_data.n_holes_max_p_pole_approximation;  
  n_holes_max_n_pole_approximation = input_data.n_holes_max_n_pole_approximation;
  
  n_holes_max_p = input_data.n_holes_max_p;
  n_holes_max_n = input_data.n_holes_max_n;

  n_scat_max_p = input_data.n_scat_max_p;
  n_scat_max_n = input_data.n_scat_max_n;
}




// Maximal principal quantum numbers of the HO relative basis for intrinsic diproton, dineutron or deuteron wave function calculation in relative coordinates are allocated and calculated here.

void input_data_str::nmax_HO_relative_tab_alloc_calc ()
{
  const int lmax_relative_plus_one = lmax_relative + 1;

  nmax_HO_relative_tab.allocate (lmax_relative_plus_one);

  for (int l_relative = 0 ; l_relative <= lmax_relative ; l_relative++)
    {
      const int nmax_HO_relative = E_CM_HO_max - l_relative/2;

      if (nmax_HO_relative < 0) error_message_print_abort ("nmax.HO.relative is negative for l.relative=" + make_string<int> (l_relative) + " : nmax.HO.relative=" + make_string<int> (nmax_HO_relative) + ". Increase E.CM.HO.max.");

      nmax_HO_relative_tab(l_relative) = nmax_HO_relative;
    }
}


void input_data_str::holes_consistency_tests () const
{
  if (truncation_ph && ((prot_hole_states_number > 0) || (neut_hole_states_number > 0)))
    {
      if (space != NEUTRONS_ONLY)
	{
	  if (Zval_basis < prot_hole_states_number)
	    {
	      const int Zval_basis_minimum_holes_number = abs (Zval_basis - prot_hole_states_number);
	      
	      if (Zval_basis_minimum_holes_number > n_holes_max_p_pole_approximation)
		error_message_print_abort ("Not enough allowed proton hole states to have the demanded number of valence protons at pole approximation level at basis level");
      
	      if (Zval_basis_minimum_holes_number > n_holes_max_p)
		error_message_print_abort ("Not enough allowed proton hole states to have the demanded number of valence protons in full space at basis level");
	      
	      if (Zval_basis_minimum_holes_number > n_holes_max)
		error_message_print_abort ("Not enough allowed total hole states to have the demanded number of valence protons in full space at basis level");
	    }
	  
	  if (Zval < prot_hole_states_number)
	    {
	      const int Zval_minimum_holes_number = abs (Zval - prot_hole_states_number);
	      
	      if (Zval_minimum_holes_number > n_holes_max_p_pole_approximation)
		error_message_print_abort ("Not enough allowed proton hole states to have the demanded number of valence protons at pole approximation level");
	      
	      if (Zval_minimum_holes_number > n_holes_max_p)
		error_message_print_abort ("Not enough allowed proton hole states to have the demanded number of valence protons in full space");
	      
	      if (Zval_minimum_holes_number > n_holes_max)
		error_message_print_abort ("Not enough allowed proton total hole states to have the demanded number of valence protons in full space");
	    }
	}
      
      if (space != PROTONS_ONLY)
	{
	  if (Nval_basis < neut_hole_states_number)
	    {
	      const int Nval_basis_minimum_holes_number = abs (Nval_basis - neut_hole_states_number);
	      
	      if (Nval_basis_minimum_holes_number > n_holes_max_n_pole_approximation)
		error_message_print_abort ("Not enough allowed neutron hole states to have the demanded number of valence neutrons at pole approximation level at basis level");
	  
	      if (Nval_basis_minimum_holes_number > n_holes_max_n)
		error_message_print_abort ("Not enough allowed neutron hole states to have the demanded number of valence neutrons in full space at basis_level");
	      
	      if (Nval_basis_minimum_holes_number > n_holes_max)
		error_message_print_abort ("Not enough allowed total hole states to have the demanded number of valence neutrons in full space at basis_level");
	    }

	  if (Nval < neut_hole_states_number)
	    {
	      const int Nval_minimum_holes_number = abs (Nval - neut_hole_states_number);
	      
	      if (Nval_minimum_holes_number > n_holes_max_n_pole_approximation)
		error_message_print_abort ("Not enough allowed neutron hole states to have the demanded number of valence neutrons at pole approximation level");
	      
	      if (Nval_minimum_holes_number > n_holes_max_n)
		error_message_print_abort ("Not enough allowed neutron hole states to have the demanded number of valence neutrons in full space");
	      
	      if (Nval_minimum_holes_number > n_holes_max)
		error_message_print_abort ("Not enough allowed total hole states to have the demanded number of valence neutrons in full space");
	    }
	}

      if (space == PROTONS_NEUTRONS)
	{
	  if ((Zval_basis < prot_hole_states_number) && (Nval_basis < neut_hole_states_number))
	    {	      
	      const int valence_basis_minimum_holes_number = abs (Zval_basis - prot_hole_states_number) + abs (Nval_basis - neut_hole_states_number);
	      
	      if (valence_basis_minimum_holes_number > n_holes_max_pole_approximation)
		error_message_print_abort ("Not enough allowed total hole states to have the demanded number of valence protons and neutrons at pole approximation level at basis level");
	  
	      if (valence_basis_minimum_holes_number > n_holes_max)
		error_message_print_abort ("Not enough allowed total hole states to have the demanded number of valence protons and neutrons in full space at basis_level");
	    }

	  if ((Zval < prot_hole_states_number) && (Nval < neut_hole_states_number))
	    {	      
	      const int valence_minimum_holes_number = abs (Zval - prot_hole_states_number) + abs (Nval - neut_hole_states_number);

	      if (valence_minimum_holes_number > n_holes_max_pole_approximation)
		error_message_print_abort ("Not enough allowed total hole states to have the demanded number of valence protons and neutrons at pole approximation level");
	  
	      if (valence_minimum_holes_number > n_holes_max)
		error_message_print_abort ("Not enough allowed total hole states to have the demanded number of valence protons and neutrons in full space");
	    }	  
	}
    }
}


void input_data_str::shells_consistency_tests (
					       const enum particle_type particle , 
					       const int available_pole_states ,
					       const class array<class nlj_struct> &shells_quantum_numbers) const
{
  if (called_code != TWO_PARTICLE_RELATIVE_CODE) 
    {      
      if ((particle == PROTON)  && (available_pole_states < Zval)) error_message_print_abort ("Not enough pole states to contain all valence protons");
      if ((particle == NEUTRON) && (available_pole_states < Nval)) error_message_print_abort ("Not enough pole states to contain all valence neutrons");
      
      if ((particle == PROTON)  && (available_pole_states < Zval_basis)) error_message_print_abort ("Not enough pole states to contain all basis valence protons");
      if ((particle == NEUTRON) && (available_pole_states < Nval_basis)) error_message_print_abort ("Not enough pole states to contain all basis valence neutrons");      
    }

  if (space == PROTONS_NEUTRONS)
    {  
      if ((particle == PROTON)  && (Zval == 0)) error_message_print_abort ("One has no active protons and space is protons-neutrons. Use neutrons and not protons-neutrons if one only has neutrons.");
      if ((particle == NEUTRON) && (Nval == 0)) error_message_print_abort ("One has no active neutrons and space is protons-neutrons. Use protons and not protons-neutrons if one only has protons.");
    }
  
  if (basis_space == PROTONS_NEUTRONS)
    {
      if ((particle == PROTON)  && (Zval_basis == 0)) error_message_print_abort ("One has no active protons and basis space is protons-neutrons. Use neutrons[basis] and not protons-neutrons[basis] if one only has neutrons.");
      if ((particle == NEUTRON) && (Nval_basis == 0)) error_message_print_abort ("One has no active neutrons and basis space is protons-neutrons. Use protons[basis] and not protons-neutrons[basis] if one only has protons.");
    }
  
  if ((basis_space != PROTONS_NEUTRONS) && (space == PROTONS_NEUTRONS)) error_message_print_abort ("One cannot have a basis space of protons only or neutrons only with a space with both protons and neutrons");
  
  const unsigned int N_nlj = shells_quantum_numbers.dimension (0);
  
  const string particle_string = make_string<enum particle_type> (particle);
  
  const bool is_it_HF_MSDHF = ((basis_potential == HF) || (basis_potential == MSDHF));

  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(s);
        
      const int e_trunc = shell_qn.get_e_trunc ();
      
      const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ();
	        
      const string shell_string = particle_string + " " + make_string<class nlj_struct> (shell_qn);
	  
      if (e_trunc < 0) error_message_print_abort (shell_string + " has a negative truncation energy");
	      
      if (is_it_HF_MSDHF && is_it_natural_orbital) error_message_print_abort ("No natural orbitals allowed when using HF/MSDHF");
    } 
  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    for (unsigned int sp = 0 ; sp < s ; sp++)
      {
	const class nlj_struct &shell_qn = shells_quantum_numbers(s);
	const class nlj_struct &shell_p_qn = shells_quantum_numbers(sp);

	if (same_nlj (shell_qn , shell_p_qn)) error_message_print_abort ("Two " + particle_string + " states have same nlj quantum numbers");
	    
	if (same_lj (shell_qn , shell_p_qn))
	  {
	    const int l = shell_qn.get_l ();
	    
	    const double j = shell_qn.get_j ();

	    const string lj_string = angular_state (l , j);
	    
	    const string particle_lj_string = particle_string + " " + lj_string;
	    
	    const bool core_state = shell_qn.get_core_state ()     , frozen_state = shell_qn.get_frozen_state ();
	    const bool core_state_p = shell_p_qn.get_core_state () , frozen_state_p = shell_p_qn.get_frozen_state ();

	    if (core_state   && frozen_state)   continue;
	    if (core_state_p && frozen_state_p) continue;
	    	    
	    const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ()     , is_it_HO = shell_qn.get_is_it_HO ();
	    const bool is_it_natural_orbital_p = shell_p_qn.get_is_it_natural_orbital () , is_it_HO_p = shell_p_qn.get_is_it_HO ();
	    
	    if (is_it_natural_orbital != is_it_natural_orbital_p) error_message_print_abort ("Two " + particle_lj_string + " hole or valence states must be both natural orbitals or none of them can be");	    
	    
	    if (core_state || core_state_p) continue;
	    
	    if (is_it_HO != is_it_HO_p) error_message_print_abort ("Two " + particle_lj_string + " valence states must be both HO or none of them can be");
	  }
      }
      
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    for (unsigned int sp = 0 ; sp < N_nlj ; sp++)
      {	
	const class nlj_struct &shell_qn   = shells_quantum_numbers(s);
	const class nlj_struct &shell_p_qn = shells_quantum_numbers(sp);
	
	const bool core_state = shell_qn.get_core_state ();
	
	const bool hole_state_p = shell_p_qn.get_hole_state ();
	
	if (!core_state && hole_state_p)
	  {
	    const int e_trunc = shell_qn.get_e_trunc ();
	    
	    const int e_trunc_p = shell_p_qn.get_e_trunc ();
	
	    if (e_trunc < e_trunc_p)
	      {
		const string shell_string   = particle_string + " " + make_string<class nlj_struct> (shell_qn);
		const string shell_p_string = particle_string + " " + make_string<class nlj_struct> (shell_p_qn);
		
		error_message_print_abort ("Valence " + shell_string + " has a truncation energy smaller than hole " + shell_p_string);
	      }
	  }
      }
}







void input_data_str::shells_consistency_tests_GSM_CC () const
{
  if (called_code != CC_CODE) error_message_print_abort ("GSM-CC only in input_data_str::shells_consistency_tests_GSM_CC");

  bool are_there_many_body_CC_projectiles = false;

  unsigned int iT = 0;
  
  while ((iT < CC_N_target_projectile_states) && !are_there_many_body_CC_projectiles)
    {
      if (A_projectile_determine (CC_projectile_tab(iT++)) >= 2) are_there_many_body_CC_projectiles = true;
    }

  if (!are_there_many_body_CC_projectiles) return;
  
  for (unsigned int sp = 0 ; sp < Np_nlj ; sp++)
    {
      const class nlj_struct &shell_qn = prot_shells_quantum_numbers(sp);
        	  
      const bool is_it_HO = shell_qn.get_is_it_HO ();
      
      if (!is_it_HO) error_message_print_abort ("One-body proton states must be HO if one has projectiles with more than one nucleon");
    }
  
  for (unsigned int sn = 0 ; sn < Nn_nlj ; sn++)
    {
      const class nlj_struct &shell_qn = neut_shells_quantum_numbers(sn);
        	  
      const bool is_it_HO = shell_qn.get_is_it_HO ();
      
      if (!is_it_HO) error_message_print_abort ("One-body neutron states must be HO if one has projectiles with more than one nucleon");
    }   
}







void input_data_str::natural_orbitals_consistency_tests (const enum particle_type particle) const
{
  const class array<class nlj_struct> &shells_quantum_numbers = shells_quantum_numbers_determine (particle);
  
  const int lmax = (particle == PROTON) ? (lmax_p) : (lmax_n);
  
  const unsigned int N_nlj = shells_quantum_numbers.dimension (0);
  
  const string particle_string = make_string<enum particle_type> (particle);
  
  class lj_table<bool> is_there_lj_partial_wave_tab(0.5 , lmax);
  
  class lj_table<int> nmax_tab(0.5 , lmax);

  is_there_lj_partial_wave_tab = false;

  nmax_tab = 0;
    
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(s);

      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();
	    
      const double j = shell_qn.get_j ();

      is_there_lj_partial_wave_tab(l , j) = true;
      
      nmax_tab(l , j) = max (nmax_tab(l , j) , n);
    } 

  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	if (is_there_lj_partial_wave_tab(l , j))
	  {
	    const int nmax_lj = nmax_tab(l , j);
		
	    for (int nn = 0 ; nn < nmax_lj ; nn++)
	      {
		bool is_nn_found = false;
		    
		for (unsigned int s = 0 ; (s < N_nlj) && !is_nn_found ; s++)
		  {
		    const class nlj_struct &shell_qn = shells_quantum_numbers(s);
			
		    const int ns = shell_qn.get_n ();
		    const int ls = shell_qn.get_l ();
			
		    const double js = shell_qn.get_j ();

		    if (same_nlj (nn , l , j , ns , ls , js)) is_nn_found = true;
		  }

		if (!is_nn_found)
		  {			
		    const string string_details = "Principal quantum number n=" + make_string<int> (nn) + " is missing in " + particle_string + " " + angular_state (l , j);

		    const string string_explanation = " and is necessary for natural orbital calculations";
		    
		    error_message_print_abort (string_details + string_explanation);
		  }
	      }
	  }
      }
}




void input_data_str::shells_consistency_tests_optimization_code () const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::shells_consistency_test_optimization_code");
    
  if (space != NEUTRONS_ONLY)
    {
      const bool is_one_body_prot_part_fitted = (is_dp_fitted || is_R0_p_fitted || is_Vo_p_fitted || is_Vso_p_fitted || is_R_charge_fitted);

      if (is_one_body_prot_part_fitted)
	{
	  for (unsigned int sp = 0 ; sp < Np_nlj ; sp++)
	    {
	      const class nlj_struct &prot_shell_qn = prot_shells_quantum_numbers(sp);
	  
	      const bool core_state = prot_shell_qn.get_core_state ();
	  
	      const bool is_it_HO = prot_shell_qn.get_is_it_HO ();

	      if (core_state && !is_it_HO) error_message_print_abort ("Proton core states have to be HO if the one-body part is fitted");
	    }
	}
    }
  
  if (space != PROTONS_ONLY)
    {
      const bool is_one_body_neut_part_fitted = (is_dn_fitted || is_R0_n_fitted || is_Vo_n_fitted || is_Vso_n_fitted);

      if (is_one_body_neut_part_fitted)
	{
	  for (unsigned int sn = 0 ; sn < Nn_nlj ; sn++)
	    {
	      const class nlj_struct &neut_shell_qn = neut_shells_quantum_numbers(sn);
	  
	      const bool core_state = neut_shell_qn.get_core_state ();
	  
	      const bool is_it_HO = neut_shell_qn.get_is_it_HO ();

	      if (core_state && !is_it_HO) error_message_print_abort ("Neutron core states have to be HO if the one-body part is fitted");
	    }
	}
    }
}



// One checks if the reference state has zero experimental energy, energy error and weight.

void input_data_str::GSM_optimization_reference_state_check (const class array<class input_data_str> &input_data_tab_for_optimization) const
{
  if (binding_energies_fitted) return;

  bool is_it_optimization_reference_state_found = false;
  
  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {    
      const class input_data_str &input_data_for_optimization = input_data_tab_for_optimization(nucleus_index);

      const unsigned int eigensets_number = input_data_for_optimization.get_eigensets_number ();

      const class array<unsigned int> &eigenset_vectors_number_tab = input_data_for_optimization.get_eigenset_vectors_number_tab ();
      
      const class array<class correlated_state_str> &PSI_qn_from_file_fixed_nucleus_tab = input_data_for_optimization.get_PSI_qn_from_file_tab ();
      
      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {	
	      const class correlated_state_str &PSI_qn = PSI_qn_from_file_fixed_nucleus_tab(eigenset_index , i);

	      const bool is_it_optimization_reference_state = PSI_qn.get_is_it_optimization_reference_state ();

	      if (is_it_optimization_reference_state)
		{
		  if (is_it_optimization_reference_state_found) error_message_print_abort ("One can have only one reference state in GSM optimization");
		  
		  const double weight_reference_state = PSI_qn.get_weight ();
		  
		  const double experimental_energy_reference_state = PSI_qn.get_experimental_energy ();
		  
		  const double energy_error_reference_state = PSI_qn.get_energy_error ();

		  if ((abs (weight_reference_state) > 1E-13) || (abs (experimental_energy_reference_state) > 1E-13) || (abs (energy_error_reference_state) > 1E-13))
		    error_message_print_abort ("The weight, experimental energy and energy error of the reference state of GSM optimization must be equal to zero");
		  
		  
		  is_it_optimization_reference_state_found = true;
		}
	    }
	}
    }

  if (!is_it_optimization_reference_state_found) error_message_print_abort ("No reference state found in GSM optimization");
}






// One checks if the largest space provided in the input file is consistent with the space used in the different nuclei of GSM optimization.

void input_data_str::GSM_optimization_largest_space_check (const bool is_it_basis , const class array<class input_data_str> &input_data_tab_for_optimization) const
{  
  bool are_there_pp_spaces = false;
  bool are_there_nn_spaces = false;
  bool are_there_pn_spaces = false;
	
  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {
      const class input_data_str &input_data_for_optimization = input_data_tab_for_optimization(nucleus_index);

      const enum space_type input_data_for_optimization_space_local = (is_it_basis) ? (input_data_for_optimization.get_basis_space ()) : (input_data_for_optimization.get_space ());

      if (input_data_for_optimization_space_local == PROTONS_ONLY)     are_there_pp_spaces = true;
      if (input_data_for_optimization_space_local == NEUTRONS_ONLY)    are_there_nn_spaces = true;
      if (input_data_for_optimization_space_local == PROTONS_NEUTRONS) are_there_pn_spaces = true;
    }

  const enum space_type space_local = (is_it_basis) ? (basis_space) : (space);

  if (are_there_pn_spaces && (space_local == PROTONS_NEUTRONS)) return;
  
  if (are_there_pp_spaces && !are_there_nn_spaces && (space_local == PROTONS_ONLY )) return;      
  if (are_there_nn_spaces && !are_there_pp_spaces && (space_local == NEUTRONS_ONLY)) return;      
  
  if (are_there_nn_spaces && are_there_pp_spaces && (space_local == PROTONS_NEUTRONS_UNMIXED)) return;
      
  if (is_it_basis)
    {
      if (are_there_pn_spaces && (basis_space != PROTONS_NEUTRONS)) error_message_print_abort ("Largest basis space should be protons-neutrons");
      
      if (are_there_pp_spaces && !are_there_nn_spaces && (basis_space != PROTONS_ONLY))  error_message_print_abort ("Largest basis space should be protons only");
      if (are_there_nn_spaces && !are_there_pp_spaces && (basis_space != NEUTRONS_ONLY)) error_message_print_abort ("Largest basis space should be neutrons only");

      if (are_there_nn_spaces && are_there_pp_spaces && (basis_space != PROTONS_NEUTRONS_UNMIXED)) error_message_print_abort ("Largest basis space should be protons-neutrons-unmixed (i.e. basis spaces with either protons or neutrons only)");
    }
  else
    {      
      if (are_there_pn_spaces && (space != PROTONS_NEUTRONS)) error_message_print_abort ("Largest space should be protons-neutrons");
      
      if (are_there_pp_spaces && !are_there_nn_spaces && (space != PROTONS_ONLY))  error_message_print_abort ("Largest space should be protons only");
      if (are_there_nn_spaces && !are_there_pp_spaces && (space != NEUTRONS_ONLY)) error_message_print_abort ("Largest space should be neutrons only");

      if (are_there_nn_spaces && are_there_pp_spaces && (space != PROTONS_NEUTRONS_UNMIXED)) error_message_print_abort ("Largest space should be protons-neutrons-unmixed (i.e. spaces with either protons or neutrons only)");
    }
}











double used_memory_calc (const class input_data_str &T)
{
  const double used_memory_unsigned_int = (T.get_dimension_unsigned_int_constants () + T.dimension_unsigned_int_tables_calc ())*sizeof (unsigned int)/1000000.0;
  
  const double used_memory_int = (T.get_dimension_int_constants () + T.dimension_int_tables_calc ())*sizeof (int)/1000000.0;
  
  const double used_memory_bool = (T.get_dimension_bool_constants () + T.dimension_bool_tables_calc ())*sizeof (bool)/1000000.0;
  
  const double used_memory_double = (T.get_dimension_double_constants () + T.dimension_double_tables_calc ())*sizeof (double)/1000000.0;
  
  const double used_memory_complex = T.dimension_complex_tables_calc ()*sizeof (complex<double>)/1000000.0;

  const double used_memory = used_memory_unsigned_int + used_memory_int + used_memory_bool + used_memory_double + used_memory_complex;

  return used_memory;
}
