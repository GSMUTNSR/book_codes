#include "../GSM_include/GSM_include_def_common.h"

using namespace HF_potentials_common::SGI_MSGI_part_common;


// TYPE is double or complex
// -------------------------



// Calculation of the HF potential one-body matrix elements taking into account one occupied state for the proton-proton, neutron-neutron and proton-neutron parts using the HO basis
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) one-body matrix elements write for MSGI:
//
// <b | U_HF(dir) |a> = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ |\sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . \int u_a(r)   u_b(r) F_Gaussian(r) dr \int u_occ(r')^2         F_Gaussian(r') dr'
// <b | U_HF(exc) |a> = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ |\sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . \int u_occ(r) u_b(r) F_Gaussian(r) dr \int u_a(r') u_occ^2(r') F_Gaussian(r') dr'
//
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) one-body matrix elements write for SGI:
//
// <b | U_HF(dir) |a> = \sum_{J, s_occ , l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . \int u_a(r) u_b(r) u_occ^2(2R0-r) Vl'_SGI(r) dr
// <b | U_HF(exc) |a> = \sum_{J, s_occ , l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . \int u_a(r) u_b(2R0-r) u_occ(r) u_occ(2R0-r) Vl'_SGI(r) dr
//
//
// where weight is function of Clebsch-Gordan coefficients and angular momenta and come from the use of uniform filling approximation,
// coupling_constant(Pi,J) is the Pi-J-dependent coupling constant of the SGI/MSGI interaction and
// F_Gaussian(r) is the Gaussian form factor entering the MSGI interaction (see GSM_TBME_MSGI.cpp) and
// Vl'_SGI(r) is the multipolar expansion of the SGI interaction (see GSM_interaction_class.cpp) and R0 is the radius of the SGI/MSGI interaction.
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) one-body matrix elements write:
//
// The real part of the equivalent HF potential is considered for the HF potential when it is complex.
//
// The occupied state is fixed in the subpart of the one-body matrix element of the HF potential.

double HF_potentials_common::SGI_MSGI_OBMEs::HO_basis::prot_OBME_HF_pp_subpart_calc (
										     const int lp , 
										     const double jp , 
										     const int n_HO_in , 
										     const int n_HO_out , 
										     const class spherical_state &shell_prot_occ , 
										     const class CG_str &CGs , 
										     const class interaction_class &inter_data_basis , 
										     const class array<double> &Gaussian_table_GL , 
										     const class multipolar_expansion_str &multipolar_expansion , 
										     const class HF_nucleons_data &prot_HF_data)
{
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
  
  const bool is_it_SGI  = is_it_SGI_determine  (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);
  
  const int Jmin_global_pp = inter_data_basis.get_Jmin_global_pp ();
  const int Jmax_global_pp = inter_data_basis.get_Jmax_global_pp ();

  const int lp_occ = shell_prot_occ.get_l ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (lp + lp_occ);

  const double jp_occ = shell_prot_occ.get_j ();

  const int Jmin_sp_sp_occ = abs (make_int (jp - jp_occ));
  const int Jmax_sp_sp_occ = make_int (jp + jp_occ);

  const int Jmin = max (Jmin_sp_sp_occ , Jmin_global_pp);
  const int Jmax = min (Jmax_sp_sp_occ , Jmax_global_pp);

  double OBME_direct   = 0.0;
  double OBME_exchange = 0.0;

  for (int J = Jmin ; J <= Jmax ; J++)
    {
      const int lmax_multipole_expansion_direct = min (2*lp , 2*lp_occ);

      const int lmin_multipole_expansion_exchange = abs (lp - lp_occ);
      const int lmax_multipole_expansion_exchange = lp_occ + lp;

      const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (lp , jp , lp_occ , jp_occ , J , CGs , prot_HF_data , prot_HF_data);

      const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jp_occ + jp - J);

      double OBME_J_direct   = 0.0;
      double OBME_J_exchange = 0.0;

      for (int ll = 0 ; ll <= lmax_multipole_expansion_direct ; ll++)
	{
	  if (ll % 2 == 0)
	    {
	      const double angular_part_multipolar_direct = multipolar_expansion(lp , jp , lp_occ , jp_occ , lp , jp , lp_occ , jp_occ , ll , J);
	      
	      const double angular_part_direct = angular_part_multipolar_direct*J_coefficient_direct;

	      if (is_it_SGI)  OBME_J_direct += real (SGI_part_common::HO_basis::OBME_nas_fixed_multipole_calc (inter_data_basis , ll , true , angular_part_direct , shell_prot_occ , lp , n_HO_in , n_HO_out));
	      if (is_it_MSGI) OBME_J_direct += angular_part_direct;
	    }
	}

      for (int ll = lmin_multipole_expansion_exchange ; ll <= lmax_multipole_expansion_exchange ; ll++)
	{
	  if ((lp + ll + lp_occ) % 2 == 0)
	    {
	      const double angular_part_multipolar_exchange = multipolar_expansion(lp , jp , lp_occ , jp_occ , lp_occ , jp_occ , lp , jp , ll , J);
	      
	      const double angular_part_exchange = angular_part_multipolar_exchange*J_coefficient_exchange;

	      if (is_it_SGI)  OBME_J_exchange += real (SGI_part_common::HO_basis::OBME_nas_fixed_multipole_calc (inter_data_basis , ll , false , angular_part_exchange , shell_prot_occ , lp , n_HO_in , n_HO_out));
	      if (is_it_MSGI) OBME_J_exchange += angular_part_exchange;
	    }
	}

      const double coupling_constant = inter_data_basis.Gaussian_coupling_constant (bp , J , false , false);

      OBME_J_direct   *= coupling_constant , OBME_direct   += OBME_J_direct;
      OBME_J_exchange *= coupling_constant , OBME_exchange += OBME_J_exchange;
    }

  if (is_it_SGI) 
    {
      const double OBME = OBME_direct - OBME_exchange;
      
      return OBME;
    }

  if (is_it_MSGI)
    {
      const double OBME = MSGI_part_common::HO_basis::total_OBME_calc ( inter_data_basis , lp , n_HO_in , n_HO_out , Gaussian_table_GL , OBME_direct , OBME_exchange , shell_prot_occ);
      
      return OBME;
    }

  return NADA;
}

double HF_potentials_common::SGI_MSGI_OBMEs::HO_basis::prot_OBME_HF_pn_subpart_calc (
										     const int lp , 
										     const double jp , 
										     const int n_HO_in , 
										     const int n_HO_out , 
										     const class spherical_state &shell_neut_occ , 
										     const class CG_str &CGs , 
										     const class interaction_class &inter_data_basis , 
										     const class array<double> &Gaussian_table_GL , 
										     const class multipolar_expansion_str &multipolar_expansion , 
										     const class HF_nucleons_data &prot_HF_data , 
										     const class HF_nucleons_data &neut_HF_data)
{
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
  
  const bool is_it_SGI  = is_it_SGI_determine  (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);
  
  const int Jmin_global_pn = inter_data_basis.get_Jmin_global_pn ();
  const int Jmax_global_pn = inter_data_basis.get_Jmax_global_pn ();

  const int ln_occ = shell_neut_occ.get_l ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (lp + ln_occ);

  const double jn_occ = shell_neut_occ.get_j ();

  const int Jmin_sp_sn_occ = abs (make_int (jp - jn_occ));
  const int Jmax_sp_sn_occ = make_int (jp + jn_occ);

  const int Jmin = max (Jmin_sp_sn_occ , Jmin_global_pn);
  const int Jmax = min (Jmax_sp_sn_occ , Jmax_global_pn);

  double OBME_direct   = 0.0;
  double OBME_exchange = 0.0;

  for (int J = Jmin ; J <= Jmax ; J++)
    {
      const int lmax_multipole_expansion_direct = min (2*lp , 2*ln_occ);

      const int lmin_multipole_expansion_exchange = abs (lp - ln_occ);
      const int lmax_multipole_expansion_exchange = lp + ln_occ;

      const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (lp , jp , ln_occ , jn_occ , J , CGs , prot_HF_data , neut_HF_data);

      const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jn_occ + jp - J);

      double OBME_J_direct = 0.0;

      double OBME_J_exchange = 0.0;

      for (int ll = 0 ; ll <= lmax_multipole_expansion_direct ; ll++)
	{
	  if (ll % 2 == 0)
	    {
	      const double angular_part_multipolar_direct = multipolar_expansion(lp , jp , ln_occ , jn_occ , lp , jp , ln_occ , jn_occ , ll , J);
	      
	      const double angular_part_direct = angular_part_multipolar_direct*J_coefficient_direct;

	      if (is_it_SGI)  OBME_J_direct += real (SGI_part_common::HO_basis::OBME_nas_fixed_multipole_calc (inter_data_basis , ll , true , angular_part_direct , shell_neut_occ , lp , n_HO_in , n_HO_out));
	      if (is_it_MSGI) OBME_J_direct += angular_part_direct;
	    }
	}

      for (int ll = lmin_multipole_expansion_exchange ; ll <= lmax_multipole_expansion_exchange ; ll++)
	{
	  if ((lp + ll + ln_occ) % 2 == 0)
	    {
	      const double angular_part_multipolar_exchange = multipolar_expansion(lp , jp , ln_occ , jn_occ , ln_occ , jn_occ , lp , jp , ll , J);
	      
	      const double angular_part_exchange = angular_part_multipolar_exchange*J_coefficient_exchange;

	      if (is_it_SGI)  OBME_J_exchange += real (SGI_part_common::HO_basis::OBME_nas_fixed_multipole_calc (inter_data_basis , ll , false , angular_part_exchange , shell_neut_occ , lp , n_HO_in , n_HO_out));
	      if (is_it_MSGI) OBME_J_exchange += angular_part_exchange;
	    }
	}

      const double coupling_constant_direct   = inter_data_basis.Gaussian_coupling_constant (bp , J , true  , false);
      const double coupling_constant_exchange = inter_data_basis.Gaussian_coupling_constant (bp , J , false , true);

      OBME_J_direct   *= coupling_constant_direct   , OBME_direct += OBME_J_direct;
      OBME_J_exchange *= coupling_constant_exchange , OBME_exchange += OBME_J_exchange;
    }

  if (is_it_SGI) 
    {
      const double OBME = OBME_direct - OBME_exchange;
      
      return OBME;
    }

  if (is_it_MSGI)
    {
      const double OBME = MSGI_part_common::HO_basis::total_OBME_calc (inter_data_basis , lp , n_HO_in , n_HO_out , Gaussian_table_GL , OBME_direct , OBME_exchange , shell_neut_occ);
      
      return OBME;
    }

  return NADA;
}

double HF_potentials_common::SGI_MSGI_OBMEs::HO_basis::neut_OBME_HF_nn_subpart_calc (
										     const int ln , 
										     const double jn , 
										     const int n_HO_in , 
										     const int n_HO_out , 	
										     const class spherical_state &shell_neut_occ , 
										     const class CG_str &CGs , 
										     const class interaction_class &inter_data_basis , 
										     const class array<double> &Gaussian_table_GL , 
										     const class multipolar_expansion_str &multipolar_expansion , 
										     const class HF_nucleons_data &neut_HF_data)
{
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
  
  const bool is_it_SGI  = is_it_SGI_determine  (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);
  
  const int Jmin_global_nn = inter_data_basis.get_Jmin_global_nn ();
  const int Jmax_global_nn = inter_data_basis.get_Jmax_global_nn ();

  const int ln_occ = shell_neut_occ.get_l ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (ln + ln_occ);

  const double jn_occ = shell_neut_occ.get_j ();

  const int Jmin_sn_sn_occ = abs (make_int (jn - jn_occ));
  const int Jmax_sn_sn_occ = make_int (jn + jn_occ);

  const int Jmin = max (Jmin_sn_sn_occ , Jmin_global_nn);
  const int Jmax = min (Jmax_sn_sn_occ , Jmax_global_nn);
	
  double OBME_direct = 0.0 , OBME_exchange = 0.0;

  for (int J = Jmin ; J <= Jmax ; J++)
    {
      const int lmax_multipole_expansion_direct = min (2*ln , 2*ln_occ);

      const int lmin_multipole_expansion_exchange = abs (ln - ln_occ);
      const int lmax_multipole_expansion_exchange = ln_occ + ln;

      const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (ln , jn , ln_occ , jn_occ , J , CGs , neut_HF_data , neut_HF_data);

      const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jn_occ + jn - J);

      double OBME_J_direct   = 0.0;
      double OBME_J_exchange = 0.0;

      for (int ll = 0 ; ll <= lmax_multipole_expansion_direct ; ll++)
	{
	  if (ll % 2 == 0)
	    {
	      const double angular_part_multipolar_direct = multipolar_expansion(ln , jn , ln_occ , jn_occ , ln , jn , ln_occ , jn_occ , ll , J);
	      
	      const double angular_part_direct = angular_part_multipolar_direct*J_coefficient_direct;

	      if (is_it_SGI)  OBME_J_direct += real (SGI_part_common::HO_basis::OBME_nas_fixed_multipole_calc (inter_data_basis , ll , true , angular_part_direct , shell_neut_occ , ln , n_HO_in , n_HO_out));
	      if (is_it_MSGI) OBME_J_direct += angular_part_direct;
	    }
	}

      for (int ll = lmin_multipole_expansion_exchange ; ll <= lmax_multipole_expansion_exchange ; ll++)
	{
	  if ((ln + ll + ln_occ) % 2 == 0)
	    {
	      const double angular_part_multipolar_exchange = multipolar_expansion(ln , jn , ln_occ , jn_occ , ln_occ , jn_occ , ln , jn , ll , J);

	      const double angular_part_exchange = angular_part_multipolar_exchange*J_coefficient_exchange;

	      if (is_it_SGI)  OBME_J_exchange += real (SGI_part_common::HO_basis::OBME_nas_fixed_multipole_calc (inter_data_basis , ll , false , angular_part_exchange , shell_neut_occ , ln , n_HO_in , n_HO_out));
	      if (is_it_MSGI) OBME_J_exchange += angular_part_exchange;
	    }
	}

      const double coupling_constant = inter_data_basis.Gaussian_coupling_constant (bp , J , false , false);

      OBME_J_direct   *= coupling_constant , OBME_direct   += OBME_J_direct;
      OBME_J_exchange *= coupling_constant , OBME_exchange += OBME_J_exchange;
    }

  if (is_it_SGI) 
    {
      const double OBME = OBME_direct - OBME_exchange;
      
      return OBME;
    }

  if (is_it_MSGI)
    {
      const double OBME = MSGI_part_common::HO_basis::total_OBME_calc (inter_data_basis , ln , n_HO_in , n_HO_out , Gaussian_table_GL , OBME_direct , OBME_exchange , shell_neut_occ);
      
      return OBME;
    }

  return NADA;
}

double HF_potentials_common::SGI_MSGI_OBMEs::HO_basis::neut_OBME_HF_pn_subpart_calc (
										     const int ln , 
										     const double jn , 
										     const int n_HO_in , 
										     const int n_HO_out , 	
										     const class spherical_state &shell_prot_occ , 
										     const class CG_str &CGs , 
										     const class interaction_class &inter_data_basis , 
										     const class array<double> &Gaussian_table_GL , 
										     const class multipolar_expansion_str &multipolar_expansion , 
										     const class HF_nucleons_data &prot_HF_data , 
										     const class HF_nucleons_data &neut_HF_data)
{
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
  
  const bool is_it_SGI  = is_it_SGI_determine  (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);
  
  const int Jmin_global_pn = inter_data_basis.get_Jmin_global_pn ();
  const int Jmax_global_pn = inter_data_basis.get_Jmax_global_pn ();

  const int lp_occ = shell_prot_occ.get_l ();

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (ln + lp_occ);

  const double jp_occ = shell_prot_occ.get_j ();

  const int Jmin_sn_sp_occ = abs (make_int (jn - jp_occ));
  const int Jmax_sn_sp_occ = make_int (jn + jp_occ);

  const int Jmin = max (Jmin_sn_sp_occ , Jmin_global_pn);
  const int Jmax = min (Jmax_sn_sp_occ , Jmax_global_pn);
	
  double OBME_direct   = 0.0;
  double OBME_exchange = 0.0;

  for (int J = Jmin ; J <= Jmax ; J++)
    {
      const int lmax_multipole_expansion_direct = min (2*ln , 2*lp_occ);

      const int lmin_multipole_expansion_exchange = abs (ln - lp_occ);
      const int lmax_multipole_expansion_exchange = lp_occ + ln;

      const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (ln , jn , lp_occ , jp_occ , J , CGs , neut_HF_data , prot_HF_data);

      const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jp_occ + jn - J);

      double OBME_J_direct   = 0.0;
      double OBME_J_exchange = 0.0;

      for (int ll = 0 ; ll <= lmax_multipole_expansion_direct ; ll++)
	{
	  if (ll % 2 == 0)
	    {
	      const double angular_part_multipolar_direct = multipolar_expansion(ln , jn , lp_occ , jp_occ , ln , jn , lp_occ , jp_occ , ll , J);
	      
	      const double angular_part_direct = angular_part_multipolar_direct*J_coefficient_direct;

	      if (is_it_SGI)  OBME_J_direct += real (SGI_part_common::HO_basis::OBME_nas_fixed_multipole_calc (inter_data_basis , ll , true , angular_part_direct , shell_prot_occ , ln , n_HO_in , n_HO_out));
	      if (is_it_MSGI) OBME_J_direct += angular_part_direct;
	    }
	}

      for (int ll = lmin_multipole_expansion_exchange ; ll <= lmax_multipole_expansion_exchange ; ll++)
	{
	  if ((ln + ll + lp_occ) % 2 == 0)
	    {
	      const double angular_part_multipolar_exchange = multipolar_expansion(ln , jn , lp_occ , jp_occ , lp_occ , jp_occ , ln , jn , ll , J);
	      
	      const double angular_part_exchange = angular_part_multipolar_exchange*J_coefficient_exchange;

	      if (is_it_SGI)  OBME_J_exchange += real (SGI_part_common::HO_basis::OBME_nas_fixed_multipole_calc (inter_data_basis , ll , false , angular_part_exchange , shell_prot_occ , ln , n_HO_in , n_HO_out));
	      if (is_it_MSGI) OBME_J_exchange += angular_part_exchange;
	    }
	}

      const double coupling_constant_direct   = inter_data_basis.Gaussian_coupling_constant (bp , J , true  , false);
      const double coupling_constant_exchange = inter_data_basis.Gaussian_coupling_constant (bp , J , false , true);

      OBME_J_direct   *= coupling_constant_direct   , OBME_direct   += OBME_J_direct;
      OBME_J_exchange *= coupling_constant_exchange , OBME_exchange += OBME_J_exchange;
    }

  if (is_it_SGI) 
    {
      const double OBME = OBME_direct - OBME_exchange;
      
      return OBME;
    }

  if (is_it_MSGI)
    {
      const double OBME = MSGI_part_common::HO_basis::total_OBME_calc (inter_data_basis , ln , n_HO_in , n_HO_out , Gaussian_table_GL , OBME_direct , OBME_exchange , shell_prot_occ);
      
      return OBME;
    }

  return NADA;
}











// Calculation of the HF potential one-body matrix elements for the proton-proton, neutron-neutron and proton-neutron parts using the HO basis
// -------------------------------------------------------------------------------------------------------------------------------------------
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) one-body matrix elements write for MSGI:
//
// <b | U_HF(dir) |a> = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ |\sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . \int u_a(r)   u_b(r) F_Gaussian(r) dr \int u_occ(r')^2         F_Gaussian(r') dr'
// <b | U_HF(exc) |a> = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ |\sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . \int u_occ(r) u_b(r) F_Gaussian(r) dr \int u_a(r') u_occ^2(r') F_Gaussian(r') dr'
//
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) one-body matrix elements write for SGI:
//
// <b | U_HF(dir) |a> = \sum_{J, s_occ , l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . \int u_a(r) u_b(r) u_occ^2(2R0-r) Vl'_SGI(r) dr
// <b | U_HF(exc) |a> = \sum_{J, s_occ , l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . \int u_a(r) u_b(2R0-r) u_occ(r) u_occ(2R0-r) Vl'_SGI(r) dr
//
//
// where weight is function of Clebsch-Gordan coefficients and angular momenta and come from the use of uniform filling approximation,
// coupling_constant(Pi,J) is the Pi-J-dependent coupling constant of the SGI/MSGI interaction and
// F_Gaussian(r) is the Gaussian form factor entering the MSGI interaction (see GSM_TBME_MSGI.cpp) and
// Vl'_SGI(r) is the multipolar expansion of the SGI interaction (see GSM_interaction_class.cpp) and R0 is the radius of the SGI/MSGI interaction.
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) one-body matrix elements write:
//
// The real part of the equivalent HF potential is considered for the HF potential when it is complex.

double HF_potentials_common::SGI_MSGI_OBMEs::HO_basis::prot_OBME_HF_pp_part_calc (
										  const int lp , 
										  const double jp , 
										  const int n_HO_in , 
										  const int n_HO_out , 
										  const class CG_str &CGs , 
										  const class interaction_class &inter_data_basis , 
										  const class array<double> &Gaussian_table_GL , 
										  const class multipolar_expansion_str &multipolar_expansion , 
										  const class HF_nucleons_data &prot_HF_data)
{
  const int Zval = prot_HF_data.get_N_valence_nucleons_basis ();
  
  if (Zval <= 1) return 0.0;

  const bool single_particle = prot_HF_data.get_single_particle ();

  const unsigned int Np_shells_occ = prot_HF_data.get_Nshells_occ ();
  
  const class array<class spherical_state> &shells_prot = prot_HF_data.get_shells ();

  const class array<class nlj_struct> &shells_qn_prot = prot_HF_data.get_shells_quantum_numbers ();

  const class nlj_table<unsigned int> &Zval_nucleons_in_shell_tab = prot_HF_data.get_N_valence_nucleons_in_shell_tab ();

  double prot_OBME_HF_pp_part = 0.0; 

  for (unsigned int sp_occ = 0 ; sp_occ < Np_shells_occ ; sp_occ++)
    {
      const class nlj_struct &shell_qn_prot_occ = shells_qn_prot(sp_occ);
      
      const bool core_state_p_occ = shell_qn_prot_occ.get_core_state ();
      const bool hole_state_p_occ = shell_qn_prot_occ.get_hole_state ();

      if (core_state_p_occ || hole_state_p_occ) continue;

      const class spherical_state &shell_prot_occ = shells_prot(sp_occ);
      
      const int np_occ = shell_prot_occ.get_n ();
      const int lp_occ = shell_prot_occ.get_l ();

      const double jp_occ = shell_prot_occ.get_j ();

      const bool same_lj_all_protons = same_lj (lp , jp , lp_occ , jp_occ);

      const unsigned int Zval_nucleons_in_shell_occ = Zval_nucleons_in_shell_tab(np_occ , lp_occ , jp_occ);
      
      if (single_particle && same_lj_all_protons && (Zval_nucleons_in_shell_occ == 1)) continue;

      prot_OBME_HF_pp_part += prot_OBME_HF_pp_subpart_calc (lp , jp , n_HO_in , n_HO_out , shell_prot_occ , CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , prot_HF_data);
    }

  return prot_OBME_HF_pp_part;
}

double HF_potentials_common::SGI_MSGI_OBMEs::HO_basis::prot_OBME_HF_pn_part_calc (
										  const int lp , 
										  const double jp , 
										  const int n_HO_in , 
										  const int n_HO_out , 
										  const class CG_str &CGs , 
										  const class interaction_class &inter_data_basis , 
										  const class array<double> &Gaussian_table_GL , 
										  const class multipolar_expansion_str &multipolar_expansion , 
										  const class HF_nucleons_data &prot_HF_data , 
										  const class HF_nucleons_data &neut_HF_data)
{
  const int Zval = prot_HF_data.get_N_valence_nucleons_basis ();
  const int Nval = neut_HF_data.get_N_valence_nucleons_basis ();

  if ((Zval == 0) || (Nval == 0)) return 0.0;

  const unsigned int Nn_shells_occ = neut_HF_data.get_Nshells_occ ();
  
  const class array<class spherical_state> &shells_neut = neut_HF_data.get_shells ();

  const class array<class nlj_struct> &shells_qn_neut = neut_HF_data.get_shells_quantum_numbers ();

  double prot_OBME_HF_pn_part = 0.0; 

  for (unsigned int sn_occ = 0 ; sn_occ < Nn_shells_occ ; sn_occ++)
    {
      const class nlj_struct &shell_qn_neut_occ = shells_qn_neut(sn_occ);

      const bool core_state_n_occ = shell_qn_neut_occ.get_core_state ();
      const bool hole_state_n_occ = shell_qn_neut_occ.get_hole_state ();

      if (core_state_n_occ || hole_state_n_occ) continue;

      const class spherical_state &shell_neut_occ = shells_neut(sn_occ);

      prot_OBME_HF_pn_part += prot_OBME_HF_pn_subpart_calc (lp , jp , n_HO_in , n_HO_out , shell_neut_occ , CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , prot_HF_data , neut_HF_data);
    }

  return prot_OBME_HF_pn_part;
}

double HF_potentials_common::SGI_MSGI_OBMEs::HO_basis::neut_OBME_HF_nn_part_calc (
										  const int ln , 
										  const double jn , 
										  const int n_HO_in , 
										  const int n_HO_out , 
										  const class CG_str &CGs , 
										  const class interaction_class &inter_data_basis , 
										  const class array<double> &Gaussian_table_GL , 
										  const class multipolar_expansion_str &multipolar_expansion , 
										  const class HF_nucleons_data &neut_HF_data)
{
  const int Nval = neut_HF_data.get_N_valence_nucleons_basis ();
  
  if (Nval <= 1) return 0.0;

  const bool single_particle = neut_HF_data.get_single_particle ();

  const unsigned int Nn_shells_occ = neut_HF_data.get_Nshells_occ ();

  const class array<class spherical_state> &shells_neut = neut_HF_data.get_shells ();

  const class array<class nlj_struct> &shells_qn_neut = neut_HF_data.get_shells_quantum_numbers ();

  const class nlj_table<unsigned int> &Nval_nucleons_in_shell_tab = neut_HF_data.get_N_valence_nucleons_in_shell_tab ();

  double neut_OBME_HF_nn_part = 0.0; 

  for (unsigned int sn_occ = 0 ; sn_occ < Nn_shells_occ ; sn_occ++)
    {
      const class nlj_struct &shell_qn_neut_occ = shells_qn_neut(sn_occ);

      const bool core_state_n_occ = shell_qn_neut_occ.get_core_state ();
      const bool hole_state_n_occ = shell_qn_neut_occ.get_hole_state ();

      if (core_state_n_occ || hole_state_n_occ) continue;

      const class spherical_state &shell_neut_occ = shells_neut(sn_occ);

      const int nn_occ = shell_neut_occ.get_n ();
      const int ln_occ = shell_neut_occ.get_l ();

      const double jn_occ = shell_neut_occ.get_j ();

      const bool same_lj_all_neutrons = same_lj (ln , jn , ln_occ , jn_occ);

      const unsigned int Nval_nucleons_in_shell_occ = Nval_nucleons_in_shell_tab(nn_occ , ln_occ , jn_occ);
      
      if (single_particle && same_lj_all_neutrons && (Nval_nucleons_in_shell_occ == 1)) continue;

      neut_OBME_HF_nn_part += neut_OBME_HF_nn_subpart_calc (ln , jn , n_HO_in , n_HO_out , shell_neut_occ , CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , neut_HF_data);
    }	

  return neut_OBME_HF_nn_part;
}

double HF_potentials_common::SGI_MSGI_OBMEs::HO_basis::neut_OBME_HF_pn_part_calc (
										  const int ln , 
										  const double jn , 
										  const int n_HO_in , 
										  const int n_HO_out , 	
										  const class CG_str &CGs , 
										  const class interaction_class &inter_data_basis , 
										  const class array<double> &Gaussian_table_GL , 
										  const class multipolar_expansion_str &multipolar_expansion , 
										  const class HF_nucleons_data &prot_HF_data , 
										  const class HF_nucleons_data &neut_HF_data)
{
  const int Zval = prot_HF_data.get_N_valence_nucleons_basis ();
  const int Nval = neut_HF_data.get_N_valence_nucleons_basis ();

  if ((Zval == 0) || (Nval == 0)) return 0.0;

  const unsigned int Np_shells_occ = prot_HF_data.get_Nshells_occ ();
  
  const class array<class spherical_state> &shells_prot = prot_HF_data.get_shells ();

  const class array<class nlj_struct> &shells_qn_prot = prot_HF_data.get_shells_quantum_numbers ();

  double neut_OBME_HF_pn_part = 0.0; 

  for (unsigned int sp_occ = 0 ; sp_occ < Np_shells_occ ; sp_occ++)
    {
      const class nlj_struct &shell_qn_prot_occ = shells_qn_prot(sp_occ);
      
      const bool core_state_p_occ = shell_qn_prot_occ.get_core_state ();
      const bool hole_state_p_occ = shell_qn_prot_occ.get_hole_state ();

      if (core_state_p_occ || hole_state_p_occ) continue;

      const class spherical_state &shell_prot_occ = shells_prot(sp_occ);

      neut_OBME_HF_pn_part += neut_OBME_HF_pn_subpart_calc (ln , jn , n_HO_in , n_HO_out , shell_prot_occ , CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , prot_HF_data , neut_HF_data);
    }	

  return neut_OBME_HF_pn_part;
}





// Calculation of the HF potential one-body matrix elements for the proton or neutron case using the HO basis
// ----------------------------------------------------------------------------------------------------------
// Proton-proton, neutron-neutron and proton-neutron parts are summed here.

double HF_potentials_common::SGI_MSGI_OBMEs::HO_basis::prot_OBME_HF_calc (
									  const int lp , 
									  const double jp , 
									  const int n_HO_in , 
									  const int n_HO_out , 
									  const class CG_str &CGs , 
									  const class interaction_class &inter_data_basis , 
									  const class array<double> &Gaussian_table_GL , 
									  const class multipolar_expansion_str &multipolar_expansion , 
									  const class HF_nucleons_data &prot_HF_data , 
									  const class HF_nucleons_data &neut_HF_data)
{
  const double prot_OBME_pp_HF = prot_OBME_HF_pp_part_calc (lp , jp , n_HO_in , n_HO_out , CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , prot_HF_data); 
  const double prot_OBME_pn_HF = prot_OBME_HF_pn_part_calc (lp , jp , n_HO_in , n_HO_out , CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , prot_HF_data , neut_HF_data);
  
  const double prot_OBME_HF = prot_OBME_pp_HF + prot_OBME_pn_HF;

  return prot_OBME_HF;
}

double HF_potentials_common::SGI_MSGI_OBMEs::HO_basis::neut_OBME_HF_calc (
									  const int ln , 
									  const double jn , 
									  const int n_HO_in , 
									  const int n_HO_out , 	
									  const class CG_str &CGs , 
									  const class interaction_class &inter_data_basis , 
									  const class array<double> &Gaussian_table_GL , 
									  const class multipolar_expansion_str &multipolar_expansion , 
									  const class HF_nucleons_data &prot_HF_data , 
									  const class HF_nucleons_data &neut_HF_data)
{
  const double neut_OBME_nn_HF = neut_OBME_HF_nn_part_calc (ln , jn , n_HO_in , n_HO_out , CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , neut_HF_data); 
  const double neut_OBME_pn_HF = neut_OBME_HF_pn_part_calc (ln , jn , n_HO_in , n_HO_out , CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , prot_HF_data , neut_HF_data);
  
  const double neut_OBME_HF = neut_OBME_nn_HF + neut_OBME_pn_HF;

  return neut_OBME_HF;
}

double HF_potentials_common::SGI_MSGI_OBMEs::HO_basis::OBME_HF_calc (
								     const enum particle_type particle , 
								     const int l , 
								     const double j , 
								     const int n_HO_in , 
								     const int n_HO_out , 	
								     const class CG_str &CGs , 
								     const class interaction_class &inter_data_basis , 
								     const class array<double> &Gaussian_table_GL , 
								     const class multipolar_expansion_str &multipolar_expansion , 
								     const class HF_nucleons_data &prot_HF_data , 
								     const class HF_nucleons_data &neut_HF_data)
{
  switch (particle)
    {
    case PROTON:  return prot_OBME_HF_calc (l , j , n_HO_in , n_HO_out , CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , prot_HF_data , neut_HF_data);
    case NEUTRON: return neut_OBME_HF_calc (l , j , n_HO_in , n_HO_out , CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , prot_HF_data , neut_HF_data);
      
    default: abort_all ();
    }

  return NADA;
}


