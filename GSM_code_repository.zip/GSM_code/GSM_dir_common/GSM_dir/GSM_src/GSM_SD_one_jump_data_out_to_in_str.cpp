#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Class SD_one_jump_data_out_to_in_str storing data about a+_{alpha} a_{beta} jumps on a Slater determinant outSD to generate inSD.
// --------------------------------------------------------------------------------------------------------------------------------
// class SD_one_jump_data_out_to_in_str stores information related to the SD outSD obtained after the action of a+_{alpha} a_{beta} on a Slater determinant inSD to generate outSD.
// Indeed, one needs to go from outSD to inSD with creation/annihilation operators in some matrix-vector operations.
// It contains the equivalent configuration index for this jump, containing information on configurations and shells only 
// (see GSM_configuration_one_jump_construction_set_out_to_in.cpp for the definition of the equivalent configuration for jumps),
// the shifted difference of M quantum numbers M_in - M_out + 2 m_max, from which M_in can be recovered as M_out is fixed, 
// the index of outSD in a fixed configuration, the shifted index of m quantum m_in + 2 m_max and the binary phase related to a+_{alpha} a_{beta}.
// M_in and m_in can be recovered from shifted M-values as M_out is fixed.



SD_one_jump_data_out_to_in_str::SD_one_jump_data_out_to_in_str ()
  : C_eq_one_jump_index (0) ,
    Delta_iM_in (0) , 
    inSD_index (0) ,  
    im_in (0) ,  
    bin_phase (0)
{}

SD_one_jump_data_out_to_in_str::SD_one_jump_data_out_to_in_str (
								const unsigned int C_eq_one_jump_index_c , 
								const unsigned int Delta_iM_in_c , 
								const unsigned int inSD_index_c , 
								const unsigned int im_in_c , 
								const unsigned int bin_phase_c)
{  
  initialize (C_eq_one_jump_index_c , Delta_iM_in_c , inSD_index_c , im_in_c , bin_phase_c);
}

void SD_one_jump_data_out_to_in_str::initialize (
						 const unsigned int C_eq_one_jump_index_c , 
						 const unsigned int Delta_iM_in_c , 
						 const unsigned int inSD_index_c , 
						 const unsigned int im_in_c , 
						 const unsigned int bin_phase_c)
{
  C_eq_one_jump_index = C_eq_one_jump_index_c;
  
  Delta_iM_in = Delta_iM_in_c; 

  inSD_index = inSD_index_c;  

  im_in = im_in_c;

  bin_phase = bin_phase_c;
}

void SD_one_jump_data_out_to_in_str::initialize (const class SD_one_jump_data_out_to_in_str &X)
{
  C_eq_one_jump_index = X.C_eq_one_jump_index;

  Delta_iM_in = X.Delta_iM_in; 

  inSD_index = X.inSD_index;  

  im_in = X.im_in;

  bin_phase = X.bin_phase; 
}


double used_memory_calc (const class SD_one_jump_data_out_to_in_str &T)
{
  return sizeof (T)/1000000.0;
}
