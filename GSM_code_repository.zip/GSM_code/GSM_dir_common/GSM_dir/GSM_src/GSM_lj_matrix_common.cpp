#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// One often uses matrices in (l,j) arrays, for example scalar density matrices to calculate natural orbitals, as they depend on partial waves.
// In order not ot write many repeated simple loops, thay have been written here.
//
// They allow to allocate, initialize, fill upper parts of symmetric matrices when only one half was calculated, create random matrices,
// add matrices, normalize matrices with respect to a parameter and make MPI reductions or cast of matrices.
//
// The only non-immediate routine is lj_matrices_core_states_handling. This one is used in the context of scalar density matrices to calculate natural orbitals.
// One can see there that one puts a very large number in a diagonal matrix element and that one removes couplings between core states and valence states (it can occur with hole states).
// One does this for all indices below nmin_lj_valence, which is the first principal quantum number of valence states. 
// Hence, very large numbers are put in the diagonal matrix element corresponding to core states.
// This allows to decouple the core part of a scalar density matrix from its valence part. 
// Indeed, one has no coupling in the core part, but it should not mix with the valence part through degeneracy if diagonal matrix elements are equal to zero.
// As natural orbitals will never have that large an occupancy,
// one can safely diagonalize the scalar density matrix to obtain natural orbitals, and those with very large occupancies have to be core states.

void lj_matrix_common::lj_matrices_parts_allocate_initialize (
							      const class nucleons_data &data ,
							      class lj_table<class matrix<TYPE> > &lj_matrices_parts)
{
  const int lmax = data.get_lmax ();
  
  const class lj_table<int> &nmax_lj_tab = data.get_nmax_lj_tab ();
      
  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	const int nmax_lj = nmax_lj_tab(l , j);

	if (nmax_lj >= 0)
	  {
	    class matrix<TYPE> &lj_matrix_part = lj_matrices_parts(l , j);

	    lj_matrix_part.allocate (nmax_lj + 1);

	    lj_matrix_part = 0.0;
	  }
      }
}



void lj_matrix_common::lj_matrices_parts_tab_allocate_initialize (
								  const class nucleons_data &data ,
								  class array<class lj_table<class matrix<TYPE> > > &lj_matrices_parts_tab)
{
  const int lmax = data.get_lmax ();
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      class lj_table<class matrix<TYPE> > &lj_matrices_parts = lj_matrices_parts_tab(i);

      lj_matrices_parts.allocate (0.5 , lmax);
	
      lj_matrices_parts_allocate_initialize (data , lj_matrices_parts);
    }
}



void lj_matrix_common::lj_matrices_initialize (class lj_table<class matrix<TYPE> > &lj_matrices)
{
  const int lmax = lj_matrices.get_lmax ();

  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	class matrix<TYPE> &lj_matrix = lj_matrices(l , j);

	if (lj_matrix.is_it_filled ()) lj_matrix = 0.0;
      }
}


void lj_matrix_common::small_random_lj_matrices (class lj_table<class matrix<TYPE> > &lj_matrices)
{
  const int lmax = lj_matrices.get_lmax ();

  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	class matrix<TYPE> &lj_matrix = lj_matrices(l , j);

	if (lj_matrix.is_it_filled ())
	  {
	    lj_matrix.symmetric_random_matrix ();

	    lj_matrix *= precision;
	  }
      }
}





void lj_matrix_common::lj_matrices_core_states_handling (
							 const class nucleons_data &data ,
							 class lj_table<class matrix<TYPE> > &lj_matrices)
{
  const int lmax = lj_matrices.get_lmax ();

  const class lj_table<int> &nmin_lj_valence_tab = data.get_nmin_lj_valence_tab ();

  const class lj_table<int> &nmax_lj_tab = data.get_nmax_lj_tab ();
  
  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	class matrix<TYPE> &lj_matrix = lj_matrices(l , j);

	if (lj_matrix.is_it_filled ())
	  {
	    const int nmin_lj_valence = nmin_lj_valence_tab(l , j);
	    
	    const int nmax_lj = nmax_lj_tab(l , j);
	    
	    for (int n = 0 ; n < nmin_lj_valence ; n++)
	      {		
		for (int np = 0 ; np < nmax_lj ; np++) lj_matrix(n , np) = lj_matrix(np , n) = 0.0;
		
		lj_matrix(n , n) = 10000.0*(n + 1);
	      }
	  }
      }
}





void lj_matrix_common::add_parts (
				  const class lj_table<class matrix<TYPE> > &lj_matrices_parts ,
				  class lj_table<class matrix<TYPE> > &lj_matrices)
{
  const int lmax = lj_matrices_parts.get_lmax ();
      
  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	const class matrix<TYPE> &lj_matrix_part = lj_matrices_parts(l , j);
	
	class matrix<TYPE> &lj_matrix = lj_matrices(l , j);
	  
	if (lj_matrix_part.is_it_filled () && lj_matrix.is_it_filled ()) lj_matrix += lj_matrix_part;
      }
}




void lj_matrix_common::add_parts (
				  const class array<class lj_table<class matrix<TYPE> > > &lj_matrices_parts_tab ,
				  class lj_table<class matrix<TYPE> > &lj_matrices)
{
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      class lj_table<class matrix<TYPE> > &lj_matrices_parts = lj_matrices_parts_tab(i);

      add_parts (lj_matrices_parts , lj_matrices);
    }
}




void lj_matrix_common::fill_upper_part (class lj_table<class matrix<TYPE> > &lj_matrices)
{
  const int lmax = lj_matrices.get_lmax ();

  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	class matrix<TYPE> &lj_matrix = lj_matrices(l , j);

	if (lj_matrix.is_it_filled ())
	  {
	    const int nmax_lj = lj_matrix.get_dimension () - 1;

	    for (int na = 0 ; na <= nmax_lj ; na++)
	      for (int nb = 0 ; nb < na ; nb++)
		lj_matrix(nb , na) = lj_matrix(na , nb);
	  }	
      }
}





void lj_matrix_common::normalize (
				  const TYPE normalizing_term ,
				  class lj_table<class matrix<TYPE> > &lj_matrices)
{
  const int lmax = lj_matrices.get_lmax ();

  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	class matrix<TYPE> &lj_matrix = lj_matrices(l , j);

	if (lj_matrix.is_it_filled ()) lj_matrix /= normalizing_term;
      }
}






void lj_matrix_common::scalar_density_matrices_allocate_initialize (class nucleons_data &data)
{
  const int lmax = data.get_lmax ();

  class lj_table<class matrix<TYPE> > &scalar_density_matrices = data.get_scalar_density_matrices ();

  scalar_density_matrices.allocate (0.5 , lmax);

  lj_matrices_parts_allocate_initialize (data , scalar_density_matrices);

  small_random_lj_matrices (scalar_density_matrices);
}






void lj_matrix_common::ESPEs_Hamiltonian_matrices_allocate_initialize (class nucleons_data &data)
{
  const int lmax = data.get_lmax ();

  class lj_table<class matrix<TYPE> > &ESPEs_Hamiltonian_matrices = data.get_ESPEs_Hamiltonian_matrices ();

  ESPEs_Hamiltonian_matrices.allocate (0.5 , lmax);

  lj_matrices_parts_allocate_initialize (data , ESPEs_Hamiltonian_matrices);

  small_random_lj_matrices (ESPEs_Hamiltonian_matrices);
}





#ifdef UseMPI

void lj_matrix_common::lj_matrices_MPI_Reduce (
					       MPI_Op op ,
					       const unsigned int Recv_process ,
					       const unsigned int process , 
					       const MPI_Comm MPI_C,
					       class lj_table<class matrix<TYPE> > &lj_matrices)
{
  const int lmax = lj_matrices.get_lmax ();

  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	class matrix<TYPE> &lj_matrix = lj_matrices(l , j);

	if (lj_matrix.is_it_filled ()) lj_matrix.MPI_Reduce (op , Recv_process , process , MPI_C);
      }
}

void lj_matrix_common::lj_matrices_MPI_Bcast (
					      const MPI_Comm MPI_C,
					      const unsigned int Send_process ,
					      class lj_table<class matrix<TYPE> > &lj_matrices)
{
  const int lmax = lj_matrices.get_lmax ();

  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	class matrix<TYPE> &lj_matrix = lj_matrices(l , j);

	if (lj_matrix.is_it_filled ()) lj_matrix.MPI_Bcast (Send_process , MPI_C);
      }
}

#endif
