#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Routines defined only so that the HO codes compile with routines meant to be used only with Berggren basis codes
// ----------------------------------------------------------------------------------------------------------------

double k_start_calc (
		     const bool ,
		     const enum particle_type ,
		     const int ,
		     const int ,
		     const double)
{
  return NADA;
}

bool spherical_state::is_it_filled () const
{
  return false;
}

void spherical_state::wave_calculation_from_vector (const bool , const double , const class vector_class<double> & , const class array<unsigned int> & , const class array<class spherical_state> &) {}

void spherical_state::wave_calculation_from_vector (const bool , const complex<double> & , const class vector_class<complex<double> > & , const class array<unsigned int> & , const class array<class spherical_state> &) {}

TYPE H_CM_OBMEs::OBME_core_Hcm_bound_calc (
					   const unsigned int ,
					   const unsigned int ,
					   const class interaction_class & ,
					   const double ,
					   const class nucleons_data & ,
					   const class nucleons_data &)
{
  return NADA;
}

TYPE H_CM_OBMEs::coupled_OBME_inter_calc (
					  const enum interaction_type ,
					  const class interaction_class & ,
					  const double ,
					  const unsigned int ,
					  const unsigned int ,
					  const class nucleons_data & ,
					  const class nucleons_data &)
{
  return NADA;
}

TYPE H_CM_OBMEs::coupled_OBME_operator_calc (
					     const bool ,
					     const class input_data_str & ,
					     const enum operator_type ,
					     const bool ,
					     const class interaction_class & ,
					     const unsigned int ,
					     const unsigned int ,
					     const class nucleons_data & ,
					     const class array<TYPE> & ,
					     const class nucleons_data &)
{
  return NADA;
}

TYPE H_CM_OBMEs::OBME_WS_derivative_calc (
					  const enum FHT_EFT_parameter_type ,
					  const bool ,
					  const int ,
					  const double ,
					  const unsigned int ,
					  const unsigned int ,
					  const class nucleons_data &)
{
  return NADA;
}

complex<double> TBME_inter_expansion_set::two_body_overlap_pp_nn_calc (
								       const unsigned int ,
								       const bool ,
								       const bool ,
								       const complex<double> & ,
								       const complex<double> & ,
								       const complex<double> & ,
								       const complex<double> & ,
								       const unsigned int ,
								       const unsigned int)
{
  return NADA;
}

void TBME_inter_expansion_set::J_TBMEs_mixed_inter_pp_nn_calc (const bool , const enum interaction_read_type , const enum space_type , const bool , const class nucleons_data & , const class interaction_class & , class TBMEs_class &) {}

TYPE TBME_inter_expansion_set::TBME_J_pp_nn_antisymmetrized (
							     const int , 
							     const unsigned int ,
							     const unsigned int ,
							     const unsigned int ,
							     const unsigned int , 
							     const class array<class vector_class<complex<double> > > & , 
							     const class array<class nlj_struct> & , 
							     const class interaction_class & , 
							     const class TBMEs_class &)
{
  return NADA;
}

void TBME_inter_expansion_set::J_TBMEs_mixed_inter_pn_calc (const bool , const enum interaction_read_type , const class nucleons_data & , const class nucleons_data & , const int , const class interaction_class & , class TBMEs_class &) {}

TYPE TBME_inter_expansion_set::TBME_J_pn (
					  const int , 
					  const unsigned int ,
					  const unsigned int ,
					  const unsigned int ,
					  const unsigned int , 
					  const class array<class vector_class<complex<double> > > & ,
					  const class array<class vector_class<complex<double>  > > & ,
					  const class array<class nlj_struct> & , 
					  const class array<class nlj_struct> & , 
					  const class interaction_class & , 
					  const class TBMEs_class &)
{
  return NADA;
}



TYPE TBME_MSGI_set::radial_integral_calc (
					  const class array<double> & ,
					  const class spherical_state & , 
					  const class spherical_state &)
{
  return NADA;
}

void TBME_MSGI_set::pp_nn_radial_integral_calc (const class nucleons_data & , const class interaction_class & , class array<TYPE> &) {}

void TBME_MSGI_set::pn_radial_integral_calc (const class nucleons_data & , const class nucleons_data & , const class interaction_class & , class array<TYPE> &) {}

TYPE TBME_MSGI_set::TBME_pi_pj_J (
				  const int , 
				  const class array<TYPE> & ,
				  const class array<TYPE> & ,
				  const unsigned int ,
				  const unsigned int ,
				  const unsigned int ,
				  const unsigned int , 
				  const class spherical_state & , 
				  const class spherical_state & , 
				  const class spherical_state & , 
				  const class spherical_state &)
{
  return NADA;
}

TYPE TBME_MSGI_set::TBME_J (
			    const bool ,
			    const int , 
			    const unsigned int ,
			    const unsigned int ,
			    const unsigned int ,
			    const unsigned int , 
			    const class spherical_state & , 
			    const class spherical_state & , 
			    const class spherical_state & , 
			    const class spherical_state & , 
			    const class array<TYPE> & ,
			    const class array<TYPE> & ,
			    const class array<TYPE> & ,
			    const class array<TYPE> & ,
			    const class interaction_class & ,
			    const class multipolar_expansion_str &)
{
  return NADA;
}

TYPE TBME_MSGI_set::TBME_J_pp_nn_antisymmetrized (
						  const bool ,
						  const int , 
						  const unsigned int ,
						  const unsigned int ,
						  const unsigned int ,
						  const unsigned int , 
						  const class array<class spherical_state> & , 
						  const class array<TYPE> & , 
						  const class array<TYPE> & , 
						  const class interaction_class & ,
						  const class multipolar_expansion_str &)
{
  return NADA;
}

TYPE TBME_MSGI_set::TBME_J_pn (
			       const bool ,
			       const int , 
			       const unsigned int ,
			       const unsigned int ,
			       const unsigned int ,
			       const unsigned int , 
			       const class array<class spherical_state> & , 
			       const class array<class spherical_state> & , 
			       const class array<TYPE> & , 
			       const class array<TYPE> & , 
			       const class array<TYPE> & , 
			       const class array<TYPE> & ,
			       const class array<TYPE> & ,
			       const class interaction_class & ,
			       const class multipolar_expansion_str &)
{
  return NADA;
}



TYPE TBME_SDI_set::SDI_radial_TBME (
				    const double , 
				    const class spherical_state & , 
				    const class spherical_state & , 
				    const class spherical_state & , 
				    const class spherical_state &)
{
  return NADA;
}

double TBME_SDI_set::TBME_JT_angular_antisymmetrized (
						      const int ,
						      const int ,
						      const class interaction_class & ,
						      const class spherical_state & , 
						      const class spherical_state & , 
						      const class spherical_state & , 
						      const class spherical_state &)
{
  return NADA;
}


TYPE TBME_SDI_set::TBME_J_pp_nn_antisymmetrized (
						 const bool , 
						 const int ,
						 const class interaction_class & ,
						 const unsigned int ,
						 const unsigned int ,
						 const unsigned int ,
						 const unsigned int , 
						 const class array<TYPE> & , 
						 const class array<class spherical_state> &)
{
  return NADA;
}

TYPE TBME_SDI_set::TBME_J_pn (
			      const bool , 
			      const int ,
			      const class interaction_class & ,
			      const unsigned int ,
			      const unsigned int ,
			      const unsigned int ,
			      const unsigned int , 
			      const class array<TYPE> & , 
			      const class array<TYPE> & ,
			      const class array<class spherical_state> & , 
			      const class array<class spherical_state> &)
{
  return NADA;
}

TYPE TBME_SGI_set::radial_integral_calc (
					 const class interaction_class & ,
					 const int , 
					 const class spherical_state & , 
					 const class spherical_state & , 
					 const class spherical_state & , 
					 const class spherical_state &)
{
  return NADA;
}

void TBME_SGI_set::pp_nn_radial_integrals_calc (const class nucleons_data & , const class interaction_class & , const unsigned int , const unsigned int , const unsigned int , const unsigned int , class array<TYPE> & , class array<TYPE> &) {}

void TBME_SGI_set::pn_radial_integrals_calc (
					     const class nucleons_data & ,  
					     const class nucleons_data & , 
					     const class interaction_class & ,
					     const unsigned int ,
					     const unsigned int ,
					     const unsigned int ,
					     const unsigned int , 
					     class array<TYPE> & , 
					     class array<TYPE> &) {}

TYPE TBME_SGI_set::TBME_pi_pj_J (
				 const int , 
				 const class array<TYPE> & ,
				 const class array<TYPE> & ,
				 const unsigned int ,
				 const unsigned int ,
				 const unsigned int ,
				 const unsigned int , 
				 const class spherical_state & , 
				 const class spherical_state & , 
				 const class spherical_state & , 
				 const class spherical_state &)
{
  return NADA;
}

TYPE TBME_SGI_set::TBME_J (
			   const bool ,
			   const int , 
			   const class interaction_class & ,
			   const class multipolar_expansion_str & , 
			   const class array<TYPE> & ,
			   const class array<TYPE> & ,
			   const class array<TYPE> & ,
			   const unsigned int ,
			   const unsigned int ,
			   const unsigned int ,
			   const unsigned int , 
			   const class spherical_state & , 
			   const class spherical_state & , 
			   const class spherical_state & , 
			   const class spherical_state &)
{
  return NADA;
}

TYPE TBME_SGI_set::TBME_J_pp_nn_antisymmetrized (
						 const bool ,
						 const int , 
						 const unsigned int ,
						 const unsigned int ,
						 const unsigned int ,
						 const unsigned int , 
						 const class array<class spherical_state> & , 
						 const class array<TYPE> & ,
						 const class array<TYPE> & ,
						 const class array<TYPE> & , 
						 const class interaction_class & ,
						 const class multipolar_expansion_str &)
{
  return NADA;
}

TYPE TBME_SGI_set::TBME_J_pn (
			      const bool ,
			      const int , 
			      const unsigned int ,
			      const unsigned int ,
			      const unsigned int ,
			      const unsigned int , 
			      const class array<class spherical_state> & , 
			      const class array<class spherical_state> & , 
			      const class array<TYPE> & ,
			      const class array<TYPE> & ,
			      const class array<TYPE> & ,
			      const class array<TYPE> & ,
			      const class interaction_class & ,
			      const class multipolar_expansion_str &)
{
  return NADA;
}

void Berggren_basis::single_particle_indices_radial_wfs_alloc_calc (const bool , const class input_data_str & , const class nucleons_data & , class nucleons_data &) {}

void Berggren_basis::single_particle_indices_radial_wfs_prot_neut_alloc_calc (const bool , const class input_data_str & , class nucleons_data & , class nucleons_data &) {}

void Berggren_basis::best_hbar_omega_b_lab_print (const enum interaction_type , const class nucleons_data &) {}

void shells_to_consider (ifstream & , const enum particle_type , const bool , class input_data_str &) {}



