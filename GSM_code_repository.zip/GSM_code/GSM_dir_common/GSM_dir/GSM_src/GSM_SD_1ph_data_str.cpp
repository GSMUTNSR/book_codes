#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Class SD_1ph_data_str
// ---------------------
// Class SD_1ph_data_str stores information related to the obtained SD after the action of a+_{alpha} (1p) or a_{alpha} (1h) on a Slater determinant for fixed in and out configurations.
// It contains the index of 1p-1h configuration jump, i.e. the index of an array providing with information about the shells and configurations involved (no angular momentum projection)
// angular momentum projection of alpha + m_max so that it is an integer, the index of SD after the jump and binary phase induced by a+/a operators.

SD_1ph_data_str::SD_1ph_data_str ()
  : C_1ph_table_index (0) ,
    im (0) ,  
    SD_index (0) ,
    bin_phase (0)
{}

SD_1ph_data_str::SD_1ph_data_str (
				  const unsigned int C_1ph_table_index_c , 
				  const unsigned int im_c , 
				  const unsigned int SD_index_c , 
				  const unsigned int bin_phase_c)
{
  initialize (C_1ph_table_index_c , im_c , SD_index_c , bin_phase_c);
}

void SD_1ph_data_str::initialize (
				  const unsigned int C_1ph_table_index_c , 
				  const unsigned int im_c , 
				  const unsigned int SD_index_c , 
				  const unsigned int bin_phase_c)
{
  C_1ph_table_index = C_1ph_table_index_c;

  im = im_c;

  SD_index = SD_index_c;  

  bin_phase = bin_phase_c;
}

void SD_1ph_data_str::initialize (const class SD_1ph_data_str &X)
{
  C_1ph_table_index = X.C_1ph_table_index;

  im = X.im;

  SD_index = X.SD_index;  

  bin_phase = X.bin_phase; 
}

void SD_1ph_data_str::allocate_fill (const class SD_1ph_data_str &X)
{
  initialize (X);
}


double used_memory_calc (const class SD_1ph_data_str &T)
{
  return sizeof (T)/1000000.0;
}
