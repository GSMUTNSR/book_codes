#include "../GSM_include/GSM_include_def_common.h"

using namespace angular_matrix_elements;
using namespace beta_transitions_common;
using namespace inputs_misc;

// TYPE is double or complex
// -------------------------



// Calculation of the radial array of the beta transition strength
// ---------------------------------------------------------------
// One uses the radial operator issued from beta_transitions_common::radial_operator_r if it has no derivative, or its direct expression if it does, in the case of reduced gradient.

void beta_transitions_strength_OBMEs::radial_OBMEs_states_fixed_calc (
								      const enum radial_operator_type radial_operator , 
								      const double R_charge , 
								      const bool is_it_Gauss_Legendre , 
								      const bool is_Hamiltonian_complex_scaled ,
								      const TYPE exp_I_theta_H_complex_scaled ,
								      const TYPE exp_minus_I_theta_H_complex_scaled ,
								      const class spherical_state &wf_in , 
								      const class spherical_state &wf_out , 
								      class array<TYPE> &radial_OBMEs_states_fixed)
{
  const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (wf_in.get_r_bef_R_tab_GL ()) : (wf_in.get_r_bef_R_tab_uniform ());

  const class array<complex<double> > &wf_in_bef_R_tab  = (is_it_Gauss_Legendre) ? (wf_in.get_wf_bef_R_tab_GL  ()) : (wf_in.get_wf_bef_R_tab_uniform  ());
  const class array<complex<double> > &wf_out_bef_R_tab = (is_it_Gauss_Legendre) ? (wf_out.get_wf_bef_R_tab_GL ()) : (wf_out.get_wf_bef_R_tab_uniform ());

  const unsigned int N_bef_R_GL  = wf_in.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = wf_in.get_N_bef_R_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  if (radial_operator == REDUCED_GRADIENT)
    {
      const class array<complex<double> > &dwf_in_bef_R_tab = wf_in.get_dwf_bef_R_tab_GL ();    

      const int l_in = wf_in.get_l ();
      
      const int l_out = wf_out.get_l ();
      
      const double l_factor = 0.5*(l_in*(l_in + 1) - l_out*(l_out + 1));

      if (Nr > 0)
	{
	  const double r0 = r_bef_R_tab(0);

	  const complex<double> wf_in_r0 = wf_in_bef_R_tab(0);
	  
	  const complex<double> dwf_in_r0 = dwf_in_bef_R_tab(0);
	  
	  const complex<double> wf_out_r0 = wf_out_bef_R_tab(0);
	  
#ifdef TYPEisDOUBLECOMPLEX
	  radial_OBMEs_states_fixed(0) = (r0 > 0) ? (wf_out_r0*(dwf_in_r0 + l_factor*wf_in_r0/r0)) : (wf_out_r0*dwf_in_r0*(l_factor + 1));
#endif
      
#ifdef TYPEisDOUBLE
	  radial_OBMEs_states_fixed(0) = (r0 > 0) ? (real (wf_out_r0)*(real (dwf_in_r0) + l_factor*real (wf_in_r0)/r0)) : (real (wf_out_r0)*real (dwf_in_r0)*(l_factor + 1));
#endif	 
	}
      
      for (unsigned int i = 1 ; i < Nr ; i++)
	{
	  const double r = r_bef_R_tab(i);

	  const complex<double> wf_in_r  = wf_in_bef_R_tab(i);
	  const complex<double> dwf_in_r = dwf_in_bef_R_tab(i);
	  
	  const complex<double> wf_out_r = wf_out_bef_R_tab(i);
	  
#ifdef TYPEisDOUBLECOMPLEX
	  radial_OBMEs_states_fixed(i) = wf_out_r*(dwf_in_r + l_factor*wf_in_r/r);
#endif
      
#ifdef TYPEisDOUBLE
	  radial_OBMEs_states_fixed(i) = real (wf_out_r)*(real (dwf_in_r) + l_factor*real (wf_in_r)/r);
#endif

	}

      if (is_Hamiltonian_complex_scaled) radial_OBMEs_states_fixed *= exp_minus_I_theta_H_complex_scaled;
    }
  else
    {
      for (unsigned int i = 0 ; i < Nr ; i++)
	{
	  const double r = r_bef_R_tab(i);
	  
	  const TYPE z = (is_Hamiltonian_complex_scaled) ? (r*exp_I_theta_H_complex_scaled) : (r);

	  const TYPE Oz = beta_transitions_radial_operator (radial_operator , R_charge , z);

	  const complex<double> wf_in_r  = wf_in_bef_R_tab(i);	  
	  const complex<double> wf_out_r = wf_out_bef_R_tab(i);

#ifdef TYPEisDOUBLECOMPLEX
	  radial_OBMEs_states_fixed(i) = wf_in_r*wf_out_r*Oz;
#endif
      
#ifdef TYPEisDOUBLE
	  radial_OBMEs_states_fixed(i) = real (wf_in_r)*real (wf_out_r)*Oz;
#endif

	}
    }
}





// Calculation of the radial array of the beta transition strength for a given radial operator for all one-body basis states
// -------------------------------------------------------------------------------------------------------------------
// The radial operator can be overlap, I.r, I.r times Coulomb correction or reduced gradient for allowed and first-forbidden beta transitions.
// OpenMP distribution is used therein.
//
// If Hamiltonian is complex-scaled, theta-dependence is included explicitly in OBMEs.

void beta_transitions_strength_OBMEs::radial_OBMEs_calc (
							 const enum radial_operator_type radial_operator ,
							 const bool is_it_Gauss_Legendre , 
							 const class baryons_data &data_in , 
							 const class baryons_data &data_out , 
							 class array<TYPE> &radial_OBMEs)
{
  const unsigned int N_nlj_in = data_in.get_N_nlj_baryon ();
  const unsigned int N_nlj_out = data_out.get_N_nlj_baryon ();
  
  const unsigned int N_bef_R_GL = data_in.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = data_in.get_N_bef_R_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const int A = data_in.get_A ();

  const double R_charge = R_charge_beta_calc (A);
  
  const bool is_Hamiltonian_complex_scaled = data_in.get_is_Hamiltonian_complex_scaled ();

  const TYPE exp_I_theta_H_complex_scaled = data_in.get_exp_I_theta_H_complex_scaled ();

  const TYPE exp_minus_I_theta_H_complex_scaled = data_in.get_exp_minus_I_theta_H_complex_scaled ();

  const class array<class spherical_state> &shells_in  = data_in.get_shells ();
  const class array<class spherical_state> &shells_out = data_out.get_shells ();

  class array<class array<TYPE> > radial_OBMEs_states_fixed_work(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) radial_OBMEs_states_fixed_work(i).allocate (Nr);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s_in = 0 ; s_in < N_nlj_in ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj_out ; s_out++)
      {
	const class spherical_state &wf_in  = shells_in(s_in);
	const class spherical_state &wf_out = shells_out(s_out);
	
	const unsigned int i_thread = OpenMP_thread_number_determine ();
	    
	class array<TYPE> &radial_OBMEs_states_fixed = radial_OBMEs_states_fixed_work(i_thread);

	radial_OBMEs_states_fixed_calc (radial_operator , R_charge , is_it_Gauss_Legendre , 
					is_Hamiltonian_complex_scaled , exp_I_theta_H_complex_scaled , exp_minus_I_theta_H_complex_scaled ,
					wf_in , wf_out , radial_OBMEs_states_fixed);

	for (unsigned int i = 0 ; i < Nr ; i++) radial_OBMEs(s_in , s_out , i) = radial_OBMEs_states_fixed(i);
      }
}






// Calculation of the array of reduced matrix elements of the beta transition strength for a given suboperator and radial operator for all one-body basis states
// -------------------------------------------------------------------------------------------------------------------------------------------------------------
// The radial operator can be overlap, I.r, I.r times Coulomb correction or reduced gradient for allowed and first-forbidden beta transitions.
// One consider a single operator here, such as Fermi or Gamow-Teller for allowed beta decay,
// or x, w, u, z, xi, xi'y and xi'v, with or without Coulomb correction for first-forbidden beta decay.
// Matrix elements are reduced here.

void beta_transitions_strength_OBMEs::beta_suboperator_OBMEs_reduced_calc (
									   const enum radial_operator_type radial_operator , 
									   const enum beta_suboperator_type beta_suboperator , 
									   const bool is_it_Gauss_Legendre , 
									   const class baryons_data &data_in , 
									   const class baryons_data &data_out , 
									   class array<TYPE> &OBMEs)
{
  const unsigned int N_nlj_in = data_in.get_N_nlj_baryon ();
  const unsigned int N_nlj_out = data_out.get_N_nlj_baryon ();

  const unsigned int N_bef_R_GL = data_in.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = data_in.get_N_bef_R_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const class array<class nlj_struct> &shells_qn_in = data_in.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_out = data_out.get_shells_quantum_numbers ();

  class array<TYPE> radial_OBMEs(N_nlj_in , N_nlj_out , Nr);

  radial_OBMEs_calc (radial_operator , is_it_Gauss_Legendre , data_in , data_out , radial_OBMEs);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s_in = 0 ; s_in < N_nlj_in ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj_out ; s_out++)
      for (unsigned int i = 0 ; i < Nr ; i++)
	{
	  const class nlj_struct &shell_qn_in  = shells_qn_in(s_in);
	  const class nlj_struct &shell_qn_out = shells_qn_out(s_out);

	  const int l_in  = shell_qn_in.get_l ();
	  const int l_out = shell_qn_out.get_l ();
	  
	  const double j_in  = shell_qn_in.get_j ();
	  const double j_out = shell_qn_out.get_j ();

	  const TYPE radial_OBME = radial_OBMEs(s_in , s_out , i);

	  OBMEs(s_in , s_out , i) = beta_suboperator_OBME_reduced_calc (beta_suboperator , radial_OBME , l_in , j_in , l_out , j_out);
	}
}










// Calculation of the array of matrix elements of the beta transition strength for a given suboperator and radial operator for all one-body basis states
// -----------------------------------------------------------------------------------------------------------------------------------------------------
// The radial operator can be overlap, I.r, I.r times Coulomb correction or reduced gradient for allowed and first-forbidden beta transitions.
// One consider a single operator here, such as Fermi or Gamow-Teller for allowed beta decay,
// or x, w, u, z, xi, xi'y and xi'v, with or without Coulomb correction for first-forbidden beta decay.
// Matrix elements are not reduced here. Reduced matrix elements are calculated first and reduced afterwards.

void beta_transitions_strength_OBMEs::beta_suboperator_OBMEs_calc (
								   const enum radial_operator_type radial_operator , 
								   const enum beta_suboperator_type beta_suboperator , 
								   const int rank_Op_projection ,
								   const bool is_it_Gauss_Legendre , 
								   const class baryons_data &data_in , 
								   const class baryons_data &data_out , 
								   class array<TYPE> &OBMEs)
{
  const unsigned int N_nlj_in = data_in.get_N_nlj_baryon ();
  const unsigned int N_nlj_out = data_out.get_N_nlj_baryon ();
  
  const unsigned int N_bef_R_GL  = data_in.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = data_in.get_N_bef_R_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  class array<TYPE> OBMEs_reduced(N_nlj_in , N_nlj_out , Nr);

  beta_suboperator_OBMEs_reduced_calc (radial_operator , beta_suboperator , is_it_Gauss_Legendre , data_in , data_out , OBMEs_reduced);

  const int rank_Op = rank_beta_suboperator_determine (beta_suboperator);

  OBMEs_dereduced_strength_calc<TYPE> (rank_Op , rank_Op_projection , data_in , data_out , OBMEs_reduced , OBMEs);
}




