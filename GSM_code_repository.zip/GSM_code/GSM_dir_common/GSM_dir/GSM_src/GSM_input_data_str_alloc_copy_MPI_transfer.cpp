#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Constructors, destructors and MPI distribution of the data contained in input_data_str.h (see input_data_str.h for information about its data)
// ----------------------------------------------------------------------------------------------------------------------------------------------
// All data are initialized to default values, except arrays related to the FHT interaction (see input_data_str.h), which are initialized to physical values coming from a fit.
//
// MPI routines are straightforward as they consist in putting data of same type in an array, distributing the array to all nodes, allocating arrays and putting the distributed data in the allocated arrays.
// They are all called in the MPI_Bcast_constants_alloc_tables routines.

using namespace string_routines;
using namespace inputs_misc;

input_data_str::input_data_str () :
  //--// Monte Carlo
  print_detailed_information (false) , 
  is_cost_function_Hessian_matrix_calculated (false) ,
  are_there_hyperons (false),
  is_cv_possible (false),
  //--// ...
  hypernucleus_strangeness (0) ,  
  number_of_MPI_processes (1) , 
  number_of_OpenMP_threads (1) , 
  BPmin_global_pp (0) , 
  BPmax_global_pp (0) , 
  BPmin_global_nn (0) , 
  BPmax_global_nn (0) , 
  BPmin_global_pn (0) , 
  BPmax_global_pn (0) , 
  Jmin_global_pp (0) , 
  Jmax_global_pp (0) ,
  Jmin_global_pp_opp (0) ,
  Jmax_global_pp_opp (0) , 
  Jmin_global_nn (0) , 
  Jmax_global_nn (0) , 
  Jmin_global_nn_opp (0) ,
  Jmax_global_nn_opp (0) ,
  Jmin_global_pn (0) , 
  Jmax_global_pn (0) , 
  Jmin_global_pn_opp (0) ,
  Jmax_global_pn_opp (0) ,
  BPmin_global_pp_basis (0) , 
  BPmax_global_pp_basis (0) , 
  BPmin_global_nn_basis (0) , 
  BPmax_global_nn_basis (0) , 
  BPmin_global_pn_basis (0) , 
  BPmax_global_pn_basis (0) , 
  Jmin_global_pp_basis (0) , 
  Jmax_global_pp_basis (0) ,
  Jmin_global_pp_opp_basis (0) ,
  Jmax_global_pp_opp_basis (0) , 
  Jmin_global_nn_basis (0) , 
  Jmax_global_nn_basis (0) ,
  Jmin_global_nn_opp_basis (0) ,
  Jmax_global_nn_opp_basis (0) , 
  Jmin_global_pn_basis (0) , 
  Jmax_global_pn_basis (0) , 
  Jmin_global_pn_opp_basis (0) ,
  Jmax_global_pn_opp_basis (0) ,
  i_charge_min_global_pp (0) , 
  i_charge_max_global_pp (0) , 
  i_charge_min_global_nn (0) , 
  i_charge_max_global_nn (0) , 
  i_charge_min_global_pn (0) , 
  i_charge_max_global_pn (0) , 
  strangeness_min_global_pp (0) , 
  strangeness_max_global_pp (0) , 
  strangeness_min_global_nn (0) , 
  strangeness_max_global_nn (0) , 
  strangeness_min_global_pn (0) , 
  strangeness_max_global_pn (0) , 
  only_dimensions (false) , 
  non_zero_NBMEs_proportion_only (false) , 
  copy_J_OBMEs_TBMEs (false) , 
  initial_pivot_from_file (false) , 
  full_common_vectors_used_in_file (false) , 
  is_Coulomb_Hamiltonian_here (false) , 
  is_Coulomb_to_be_added (false) ,
  T2_CM_operators_calculated (false) , 
  J_projected (false) , 
  are_two_body_clusters_stored_in_J_scheme (false) ,
  is_hole_double_counting_suppressed (false) ,
  Hamiltonian_storage (NO_STORAGE) , 
  M_TBMEs_storage (NO_STORAGE) , 
  one_jumps_pn_two_jumps_cv_storage (NO_STORAGE) , 
  basis_space (NO_SPACE) , 
  space (NO_SPACE) , 
  inter (NO_INTERACTION) , 
  basis_potential (NO_POTENTIAL) , 
  relative_cluster (NO_PARTICLE) , 
  R (0) , 
  step_bef_R_uniform (0) , 
  R_real_max (0) , 
  step_momentum_uniform (0) ,
  kmax_momentum (0) ,
  R_Fermi_momentum (0) ,
  R_cut_function (0) , 
  d_cut_function (0) , 
  Ueq_regularizor (0) , 
  lambda_Hcm (0) , 
  N_bef_R_GL (0) , 
  N_aft_R_GL (0) , 
  N_bef_R_uniform (0) , 
  N_aft_R_uniform (0) , 
  Nk_momentum_GL (0) ,
  Nk_momentum_uniform (0) ,
  N_hyperon_types (0) ,
  good_isospin_basis_potential (false) , 
  all_states_calculated (false) , 
  R_charge (2.0) , 
  H_potential (NO_POTENTIAL) , 
  H_basis_core_potential (NO_POTENTIAL) , 
  A_core (0) , 
  Z_core (0) , 
  N_core (0) ,
  prot_hole_states_number (0) ,
  neut_hole_states_number (0) ,
  frozen_core_mass (0) , 
  nucleus_mass (0) , 
  nucleus_mass_basis (0) ,
  total_nucleus_mass (0) ,
  truncation_hw (false) , 
  truncation_ph (false) , 
  E_relative_max_hw_pole_approximation (0) , 
  E_relative_max_hw (0) , 
  E_max_hw_pole_approximation (0) , 
  E_max_hw (0) , 
  n_scat_max (0) , 
  n_scat_max_p (0) , 
  n_scat_max_n (0) , 
  n_holes_max_pole_approximation (0) , 
  n_holes_max_p_pole_approximation (0) , 
  n_holes_max_n_pole_approximation (0) ,  
  n_holes_max (0) , 
  n_holes_max_p (0) , 
  n_holes_max_n (0) , 
  is_it_Lanczos (false) , 
  is_it_Lowdin (false) , 
  OBMEs_inter_read (false) ,
  is_it_cluster_CM_HO_basis_calculation (false) , 
  binding_energies_fitted (false) ,
  are_natural_orbitals_calculated_every_iteration (false) ,
  configuration_precision (0) , 
  workspace_max_dimension (0) , 
  N_restarts (0) , 
  test_vector_solution (0) , 
  A (0) , 
  Z (0) , 
  N (0) , 
  A_basis (0) , 
  Z_basis (0) , 
  N_basis (0) , 
  ZY_charge_pos (0) ,
  ZY_charge_neg (0) ,  
  ZY_charge_basis_potential_pos (0) , 
  ZY_charge_basis_potential_neg (0) , 
  Zval (0) , 
  Nval (0) ,  
  Zval_basis (0) , 
  Nval_basis (0) , 
  ZYval (0) , 
  NYval (0) ,
  N_nuclei_to_consider (0) , 
  Newton_precision (0) , 
  inter_read (NO_TBMES_READ) , 
  is_R_charge_fitted (false) , 
  is_V0_ctr_ot_S1_T1_fitted (false) , 
  is_V0_ctr_et_S1_T0_fitted (false) , 
  is_V0_ctr_os_S0_T0_fitted (false) , 
  is_V0_ctr_es_S0_T1_fitted (false) , 
  is_V0_so_ot_S1_T1_fitted (false) , 
  is_V0_so_et_S1_T0_fitted (false) , 
  is_V0_t_ot_S1_T1_fitted (false) , 
  is_V0_t_et_S1_T0_fitted (false) , 
  is_V0_ALS_fitted (false) ,
  is_VS_const_LO_T0_fitted (false) ,
  is_VS_const_LO_T1_fitted (false) ,
  is_VT_sigma_product_LO_T0_fitted (false) ,
  is_VT_sigma_product_LO_T1_fitted (false) ,
  is_V1_q2_NLO_fitted (false) ,
  is_V2_k2_NLO_fitted (false) ,
  is_V3_q2_sigma_product_NLO_fitted (false) ,
  is_V4_k2_sigma_product_NLO_fitted (false) ,
  is_V5_sigma_q_vector_k_NLO_fitted (false) ,
  is_V6_sigma_q_product_NLO_fitted (false) ,
  is_V7_sigma_k_product_NLO_fitted (false) ,
  is_V8a_SU3f_fitted (false) ,
  is_V8s_SU3f_fitted  (false) ,
  is_V10_SU3f_fitted (false) ,
  is_V1_SU3f_fitted (false) ,
  is_it_fixed_relative_SVD_precision (false) ,
  relative_SVD_precision (0) , 
  rejected_singular_values_number (0) , 
  Jn_relative_max_basis (0) , 
  Jc_relative_max_basis (0) , 
  Jn_relative_max (0) , 
  Jc_relative_max (0) , 
  R0_inter_basis (5) , 
  mu_basis (0) , 
  a_basis (0) , 
  b_basis (0) , 
  V_SDI_basis (0) , 
  b_lab_basis (0) , 
  R0_inter (5) , 
  mu (0) , 
  a (0) , 
  b (0) , 
  V_SDI (0) , 
  b_lab (0) , 
  A_dependence_alpha_core_potential (0) , 
  A_dependence_exponent (0) , 
  u_Minnesota_basis (0) , 
  nu_three_body_like_basis (0) , 
  V_three_body_like_basis (0) , 
  V0_ctr_ot_basis (0) , 
  V0_ctr_et_basis (0) , 
  V0_ctr_os_basis (0) , 
  V0_ctr_es_basis (0) , 
  V0_so_ot_basis (0) , 
  V0_so_et_basis (0) , 
  V0_t_ot_basis (0) , 
  V0_t_et_basis (0) ,
  V0_ALS_basis (0) ,
  VS_const_LO_T0_basis (0) ,
  VS_const_LO_T1_basis (0) ,
  VT_sigma_product_LO_T0_basis (0) ,
  VT_sigma_product_LO_T1_basis (0) ,
  V1_q2_NLO_basis (0) ,
  V2_k2_NLO_basis (0) ,
  V3_q2_sigma_product_NLO_basis (0) ,
  V4_k2_sigma_product_NLO_basis (0) ,
  V5_sigma_q_vector_k_NLO_basis (0) ,
  V6_sigma_q_product_NLO_basis (0) ,
  V7_sigma_k_product_NLO_basis (0) , 
  u_Minnesota (0) , 
  nu_three_body_like (0) , 
  V_three_body_like (0) , 
  V0_ctr_ot (0) , 
  V0_ctr_et (0) , 
  V0_ctr_os (0) , 
  V0_ctr_es (0) , 
  V0_so_ot (0) , 
  V0_so_et (0) , 
  V0_t_ot (0) , 
  V0_t_et (0) , 
  V0_ALS (0) ,   
  VS_const_LO_T0 (0) ,
  VS_const_LO_T1 (0) ,
  VT_sigma_product_LO_T0 (0) ,
  VT_sigma_product_LO_T1 (0) ,
  V1_q2_NLO (0) ,
  V2_k2_NLO (0) ,
  V3_q2_sigma_product_NLO (0) ,
  V4_k2_sigma_product_NLO (0) ,
  V5_sigma_q_vector_k_NLO (0) ,
  V6_sigma_q_product_NLO (0) ,
  V7_sigma_k_product_NLO (0) , 
  V8_sigma_q_vector_k_NLO (0) ,
  V8a_SU3f (0) , 
  V8s_SU3f (0) , 
  V10_SU3f (0) , 
  V1_SU3f (0) , 
  eigenset_vectors_number_max (0) ,
  N_nlj_relative (0) , 
  N_nlj_res_relative (0) ,
  nmax_p (0) , 
  nmax_n (0) , 
  nmax_relative (0) , 
  lmax_p (0) , 
  lmax_n (0) , 
  lmax_relative (0) , 
  lmax_for_basis_interaction (0) , 
  lmax_for_interaction (0) , 
  jp_max (0) , 
  jn_max (0) ,  
  jmax_relative (0) , 
  mp_max (0) , 
  mn_max (0) , 
  mp_min (0) , 
  mn_min (0) , 
  mp_max_minus_half (0) , 
  mn_max_minus_half (0) , 
  two_mp_max (0) , 
  two_mn_max (0) , 
  four_mp_max (0) , 
  four_mn_max (0) , 
  mp_max_minus_mp_min (0) , 
  mn_max_minus_mn_min (0) , 
  natural_orbitals_reference_states_number (0) ,
  HF_max_iterations_number (0) , 
  HF_precision (0.0) , 
  files_number (0) , 
  prot_Y_N_paths (0) , 
  neut_Y_N_paths (0) , 
  eigensets_number (0) ,
  are_there_GSM_multipoles (false) , 
  are_there_EM_transitions (false) , 
  are_there_EM_transitions_strength (false) ,
  are_there_beta_transitions (false) , 
  are_there_beta_transitions_strength (false) , 
  are_there_densities (false) ,  
  are_there_correlation_densities (false) ,
  are_there_pair_densities (false) ,
  are_there_spectroscopic_factors (false) , 
  are_there_overlap_functions (false) ,  
  are_there_rms_radii (false) , 
  are_there_rms_radius_one_body_strengths (false) ,
  are_there_Hamiltonian_parts (false) ,  
  are_there_Coulomb_isospin_mixtures (false) , 
  are_there_dagger_tilde_operators (false) , 
  GSM_multipoles_number (0) ,  
  EM_transitions_number (0) , 
  EM_transitions_strength_number (0) , 
  beta_transitions_number (0) , 
  beta_transitions_strength_number (0) , 
  density_number (0) , 
  correlation_density_number (0) , 
  correlation_density_theta_number (0) , 
  pair_density_number (0) , 
  spectroscopic_factor_number (0) , 
  overlap_function_number (0) , 
  rms_radius_number (0) , 
  rms_radius_one_body_strength_number (0) , 
  Hamiltonian_parts_eigenstates_number (0) , 
  Coulomb_isospin_mixture_number (0) , 
  dagger_tilde_operators_number (0) ,
  is_correlation_density_theta_value_imposed (false) ,  
  correlation_density_imposed_theta_value (0.0) ,
  RDM_matrix_constraint (NO_RDM_CONSTRAINT) ,
  RDM_is_it_BiCG (false) ,
  RDM_are_there_J_constraints (false) ,
  RDM_is_there_CM_correction (false) ,
  RDM_is_there_isospin_constraint (false) ,
  RDM_Gamma_init_from_file (false) ,
  RDM_is_there_E_reference (false) ,
  RDM_E_minimization_precision (0) ,
  RDM_sigma_init (0) ,
  RDM_multiplicative_sigma_step (0) ,
  RDM_smallness_factor (0) ,					 
  RDM_BP (0) ,
  RDM_vector_index (0) ,
  RDM_J (0) ,
  RDM_E_reference (0) ,
  RDM_Hamiltonian_renormalization_factor (0) ,
  CC_reaction (NO_REACTION) , 
  CC_reaction_calculation (NO_REACTION_CALCULATION) , 
  CC_are_GSM_a_dagger_vectors_calculated (false) , 
  CC_E_kinetic_total_system_CM_start (0) , 
  CC_E_kinetic_total_system_CM_end (0) , 
  CC_average_n_scat_target_projectile_max_composite_number (0) , 
  CC_corrective_factors_TBMEs_composite_number (0) ,
  CC_N_target_projectile_states (0) ,
  CC_N_partial_waves_max (0) ,
  CC_Davidson_N_restarts (0) , 
  CC_Davidson_max_dimension (0) , 
  CC_Davidson_eigenvector_precision (sqrt_precision) , 
  CC_relative_SVD_precision (sqrt_precision) , 
  CC_forbidden_channel_precision (sqrt_precision) , 
  CC_N_energies (0) , 
  CC_N_CM_angles (0) , 
  CC_EM_for_radiative_capture_cross_section (NO_EM) , 
  CC_L_for_radiative_capture_cross_section (0) , 
  CC_N_theta_gamma (1) , 
  CC_N_phi_gamma (1) , 
  CC_is_it_longwavelength_approximation (false) , 
  CC_is_it_HO_expansion (true) ,
  CC_N_JPi_A_composite (0) , 
  CC_N_JPi_A_in_composite (0) , 
  CC_N_JPi_A_out_composite (0) , 
  //--// CC cluster
  CC_cluster_projectile_number (0) ,
  CC_Lmax_all (0) ,
  CC_J_number_max_all (0) ,
  are_GSM_vectors_stored_on_disk (false) , 
  are_configuration_probabilities_printed (false) , 
  are_scattering_configuration_probabilities_printed (false) ,
  is_there_effective_range_expansion (false) , 
  M_equal_J_imposed_in_GSM_vectors (false) , 
  is_there_disk_storage_eigenvectors_all_M (false) , 
  E_CM_HO_max (0) ,
  CC_corrective_factors_cluster_composite_numbers_max (0) ,
  are_there_basis_natural_orbitals_p (false) ,
  are_there_basis_natural_orbitals_n (false) ,
  are_there_new_natural_orbitals_p (false) ,
  are_there_new_natural_orbitals_n (false)
{
  V0_ctr_basis[0] = -6.0, V0_ctr_basis[1] = -546.0, V0_ctr_basis[2] = 1655.0;
  
  alpha_ctr_basis[0] = 0.160, alpha_ctr_basis[1] = 1.127, alpha_ctr_basis[2] = 3.400;
  
  W_ctr_basis[0] = -0.2363, W_ctr_basis[1] = 0.4242, W_ctr_basis[2] = 0.4474;
  B_ctr_basis[0] =  0.5972, B_ctr_basis[1] = 0.1404, B_ctr_basis[2] = 0.1015;

  H_ctr_basis[0] = -0.5139, H_ctr_basis[1] = 0.030,  H_ctr_basis[2] = 0.0526;
  M_ctr_basis[0] =  1.1530, M_ctr_basis[1] = 0.4055, M_ctr_basis[2] = 0.3985;

  V0_so_basis[0] = 1918.0 , V0_so_basis[1] = -1519.0; 
  alpha_so_basis[0] = 5.0 , alpha_so_basis[1] = 3.0;

  //Initial values of W[so] and H[so] of the basis FHT interaction (for HF/MSDHF only). The even-triplet part of the spin-orbit interaction is always equal to zero with it.
  //W_so_basis[0] =  0.50, W_so_basis[1] =  0.50;
  //H_so_basis[0] = -0.50, H_so_basis[1] = -0.50;

  //Modified values of W[so] and H[so] of the basis FHT interaction (for HF/MSDHF only). The even-triplet part of the spin-orbit interaction is now non zero in general.
  //I took the same values as for the tensor part up to a minus sign, as then the result is the same for the even-odd part of the spin-orbit interaction as with the initial values above.
  W_so_basis[0] =  0.3277, W_so_basis[1] =  0.4102;
  H_so_basis[0] = -0.6723, H_so_basis[1] = -0.5898;  

  V0_t_basis[0] = -16.96, V0_t_basis[1] = -369.5, V0_t_basis[2] = 1688.0;

  alpha_t_basis[0] = 0.53, alpha_t_basis[1] = 1.92, alpha_t_basis[2] = 8.95;
  
  W_t_basis[0] = 0.3277, W_t_basis[1] = 0.4102, W_t_basis[2] = 0.50;
  H_t_basis[0] = 0.6723, H_t_basis[1] = 0.5898, H_t_basis[2] = 0.50;
  
  V0_ctr[0] = -6.0, V0_ctr[1] = -546.0, V0_ctr[2] = 1655.0;
  
  alpha_ctr[0] = 0.160, alpha_ctr[1] = 1.127, alpha_ctr[2] = 3.400;
  
  W_ctr[0] = -0.2363, W_ctr[1] = 0.4242, W_ctr[2] = 0.4474;
  B_ctr[0] =  0.5972, B_ctr[1] = 0.1404, B_ctr[2] = 0.1015;

  H_ctr[0] = -0.5139, H_ctr[1] = 0.030,  H_ctr[2] = 0.0526;
  M_ctr[0] =  1.1530, M_ctr[1] = 0.4055, M_ctr[2] = 0.3985;

  V0_so[0] = 1918.0 , V0_so[1] = -1519.0; 
  alpha_so[0] = 5.0 , alpha_so[1] = 3.0;

  //Initial values of W[so] and H[so] of the FHT interaction. The even-triplet part of the spin-orbit interaction is always equal to zero with it.
  //W_so[0] =  0.50, W_so[1] =  0.50;
  //H_so[0] = -0.50, H_so[1] = -0.50;

  //Modified values of W[so] and H[so] of the FHT interaction. The even-triplet part of the spin-orbit interaction is now non zero in general.
  //I took the same values as for the tensor part up to a minus sign, as then the result is the same for the even-odd part of the spin-orbit interaction as with the initial values above.
  W_so[0] =  0.3277, W_so[1] =  0.4102;
  H_so[0] = -0.6723, H_so[1] = -0.5898;  

  V0_t[0] = -16.96, V0_t[1] = -369.5, V0_t[2] = 1688.0;

  alpha_t[0] = 0.53, alpha_t[1] = 1.92, alpha_t[2] = 8.95;
  
  W_t[0] = 0.3277, W_t[1] = 0.4102, W_t[2] = 0.50;
  H_t[0] = 0.6723, H_t[1] = 0.5898, H_t[2] = 0.50;
}


input_data_str::~input_data_str () {}

void input_data_str::allocate_fill (const class input_data_str &X)
{	
  copy_unsigned_int_constants (X);
  copy_int_constants (X);
  copy_bool_constants (X); 
  copy_double_constants (X);  
  copy_alloc_unsigned_int_tables (X);
  copy_alloc_int_tables (X);
  copy_alloc_bool_tables (X); 
  copy_alloc_double_tables (X);
  copy_alloc_complex_tables (X);

  shells_quantum_numbers_p_tab.allocate_fill (X.shells_quantum_numbers_p_tab);
  shells_quantum_numbers_n_tab.allocate_fill (X.shells_quantum_numbers_n_tab);

  PSI_qn_from_file_tab.allocate_fill (X.PSI_qn_from_file_tab);
}



void input_data_str::deallocate ()
{
  natural_orbitals_reference_states_BP_tab.deallocate ();
  natural_orbitals_reference_states_vector_index_tab.deallocate ();
  prot_basis_BP_tab.deallocate ();
  neut_basis_BP_tab.deallocate ();
  BP_eigenset_tab.deallocate ();
  eigenset_vectors_number_tab.deallocate ();
  GSM_multipoles_BP_tab.deallocate ();
  GSM_multipoles_vector_index_tab.deallocate ();
  EM_BP_IN_tab.deallocate ();
  EM_BP_OUT_tab.deallocate ();
  EM_vector_index_IN_tab.deallocate ();
  EM_vector_index_OUT_tab.deallocate ();
  EM_strength_BP_IN_tab.deallocate ();
  EM_strength_BP_OUT_tab.deallocate ();
  EM_strength_vector_index_IN_tab.deallocate ();
  EM_strength_vector_index_OUT_tab.deallocate ();
  beta_BP_IN_tab.deallocate ();
  beta_BP_OUT_tab.deallocate ();
  beta_vector_index_IN_tab.deallocate ();
  beta_vector_index_OUT_tab.deallocate ();
  beta_strength_BP_IN_tab.deallocate ();
  beta_strength_BP_OUT_tab.deallocate ();
  beta_strength_vector_index_IN_tab.deallocate ();
  beta_strength_vector_index_OUT_tab .deallocate ();
  density_BP_tab.deallocate ();
  density_vector_index_tab.deallocate ();
  correlation_density_BP_tab.deallocate ();
  correlation_density_vector_index_tab.deallocate ();
  pair_density_BP_tab.deallocate ();
  pair_density_vector_index_tab.deallocate ();
  spectroscopic_factor_BP_IN_tab.deallocate ();
  spectroscopic_factor_BP_OUT_tab.deallocate ();
  spectroscopic_factor_vector_index_IN_tab.deallocate ();
  spectroscopic_factor_vector_index_OUT_tab.deallocate ();
  spectroscopic_factor_BP_projectile_tab.deallocate ();
  spectroscopic_factor_vector_index_projectile_tab.deallocate ();
  overlap_function_BP_IN_tab.deallocate ();
  overlap_function_BP_OUT_tab.deallocate ();
  overlap_function_vector_index_IN_tab.deallocate ();
  overlap_function_vector_index_OUT_tab.deallocate ();
  overlap_function_BP_projectile_tab.deallocate ();
  overlap_function_vector_index_projectile_tab.deallocate ();
  rms_radius_BP_tab.deallocate ();
  rms_radius_vector_index_tab.deallocate ();
  rms_radius_one_body_strength_BP_tab.deallocate ();
  rms_radius_one_body_strength_vector_index_tab.deallocate ();
  Hamiltonian_parts_BP_tab.deallocate ();
  Hamiltonian_parts_vector_index_tab.deallocate ();
  Coulomb_isospin_mixture_BP_tab.deallocate ();
  Coulomb_isospin_mixture_vector_index_tab.deallocate ();
  dagger_tilde_operators_BP_IN_tab.deallocate ();
  dagger_tilde_operators_BP_OUT_tab.deallocate ();
  dagger_tilde_operators_vector_index_IN_tab.deallocate ();
  dagger_tilde_operators_vector_index_OUT_tab.deallocate ();
  dagger_tilde_operators_S_IN_tab.deallocate ();
  CC_BP_target_tab.deallocate ();
  CC_vector_index_target_tab.deallocate ();
  CC_N_partial_waves_tab.deallocate ();
  CC_BP_A_composite_tab.deallocate ();
  CC_vector_index_A_composite_tab.deallocate ();
  CC_BP_A_in_composite_tab.deallocate ();
  CC_BP_A_out_composite_tab.deallocate ();
  CC_vector_index_A_out_composite_tab.deallocate ();
  CC_average_n_scat_target_projectile_max_BP_A_composite_tab.deallocate ();
  CC_corrective_factors_TBMEs_BP_A_composite_tab.deallocate ();
  CC_corrective_factors_cluster_composite_numbers.deallocate ();
  CC_corrective_factors_cluster_BP_A_composite_tab.deallocate ();
  CC_N_poles_cluster_projectile_CM_tab.deallocate ();
  CC_N_K_peak_cluster_projectile_CM_tab.deallocate ();
  CC_N_K_middle_cluster_projectile_CM_tab.deallocate ();
  CC_N_K_max_cluster_projectile_CM_tab.deallocate ();
  Np_nlj_baryon_tab.deallocate ();
  Np_nlj_res_baryon_tab.deallocate ();
  Np_nljm_baryon_tab.deallocate ();
  Np_nljm_res_baryon_tab.deallocate ();
  Nn_nlj_baryon_tab.deallocate ();
  Nn_nlj_res_baryon_tab.deallocate ();
  Nn_nljm_baryon_tab.deallocate ();
  Nn_nljm_res_baryon_tab.deallocate ();
  nmax_HO_lab_tab.deallocate ();
  nmax_GHF_lab_tab.deallocate ();
  nmax_HO_relative_tab.deallocate ();
  basis_potential_partial_waves_p_tab.deallocate ();
  basis_potential_partial_waves_n_tab.deallocate ();
  GSM_multipoles_L_tab.deallocate ();
  EM_L_tab.deallocate ();
  EM_tab.deallocate ();
  EM_strength_L_tab.deallocate ();
  EM_strength_tab.deallocate ();
  beta_tab.deallocate ();
  beta_pm_tab.deallocate ();
  beta_strength_tab.deallocate ();
  beta_strength_pm_tab.deallocate ();
  spectroscopic_factor_LCM_projectile_tab.deallocate ();
  spectroscopic_factor_NCM_HO_max_projectile_tab.deallocate ();
  spectroscopic_factor_type_tab.deallocate ();
  spectroscopic_factor_nucleus_projectile_tab.deallocate ();
  spectroscopic_factor_cluster_projectile_tab.deallocate ();
  spectroscopic_factor_Z_projectile_tab.deallocate ();
  spectroscopic_factor_N_projectile_tab.deallocate ();
  overlap_function_LCM_projectile_tab.deallocate ();
  overlap_function_NCM_HO_max_projectile_tab.deallocate ();
  overlap_function_type_tab.deallocate ();
  overlap_function_nucleus_projectile_tab.deallocate ();
  overlap_function_cluster_projectile_tab.deallocate ();
  overlap_function_Z_projectile_tab.deallocate ();
  overlap_function_N_projectile_tab.deallocate ();
  rms_radius_particle_tab.deallocate ();
  rms_radius_one_body_strength_particle_tab.deallocate ();
  dagger_tilde_operators_tab.deallocate ();
  CC_Lmax_cluster_projectile_CM_tab.deallocate ();
  CC_cluster_projectile_tab.deallocate ();
  CC_Nmin_PCM_cluster_projectile_tab.deallocate ();
  CC_projectile_tab.deallocate ();
  CC_partial_wave_L_cluster_projectile_tab.deallocate ();
  hyperon_types.deallocate ();
  lmax_baryon_p_tab.deallocate ();
  lmax_common_baryon_p_tab.deallocate ();
  lmax_baryon_n_tab.deallocate ();
  lmax_common_baryon_n_tab.deallocate ();
  GSM_multipoles_is_it_HO_expansion_tab.deallocate ();
  EM_is_it_longwavelength_approximation_tab.deallocate ();
  EM_is_it_HO_expansion_tab.deallocate ();
  EM_strength_is_it_longwavelength_approximation_tab.deallocate ();
  beta_is_it_HO_expansion_tab.deallocate ();
  rms_radius_is_it_HO_expansion_tab.deallocate ();
  CC_is_it_entrance_tab.deallocate ();
  CC_is_it_pole_target_tab.deallocate ();
  EM_strength_is_it_Gauss_Legendre_tab.deallocate ();
  beta_strength_is_it_Gauss_Legendre_tab.deallocate ();
  correlation_density_is_it_radial_tab.deallocate ();
  correlation_density_is_it_Gauss_Legendre_tab.deallocate ();
  correlation_density_is_it_HO_expansion_tab.deallocate ();
  pair_density_is_it_radial_tab.deallocate ();
  pair_density_is_it_Gauss_Legendre_tab.deallocate ();
  density_is_it_radial_tab.deallocate ();
  density_is_it_Gauss_Legendre_tab.deallocate ();
  overlap_function_is_it_Gauss_Legendre_tab.deallocate ();
  rms_radius_one_body_strength_is_it_Gauss_Legendre_tab.deallocate ();
  are_there_new_natural_orbitals_p_tab.deallocate ();
  are_there_basis_natural_orbitals_p_tab.deallocate ();
  same_dp_all_lj_tab.deallocate ();
  same_R0_p_all_lj_tab.deallocate ();
  same_Vo_p_all_lj_tab.deallocate ();
  is_dp_fitted_tab.deallocate ();
  is_R0_p_fitted_tab.deallocate ();
  is_Vo_p_fitted_tab.deallocate ();
  is_Vso_p_fitted_tab.deallocate ();
  are_there_new_natural_orbitals_n_tab.deallocate ();
  are_there_basis_natural_orbitals_n_tab.deallocate ();
  same_dn_all_lj_tab.deallocate ();
  same_R0_n_all_lj_tab.deallocate ();
  same_Vo_n_all_lj_tab.deallocate ();
  same_Vso_n_all_lj_tab.deallocate ();
  is_dn_fitted_tab.deallocate ();
  is_R0_n_fitted_tab.deallocate ();
  is_Vo_n_fitted_tab.deallocate ();
  is_Vso_n_fitted_tab.deallocate ();
  natural_orbitals_reference_states_J_tab.deallocate ();
  J_eigenset_tab.deallocate ();
  dp_core_potential_tab.deallocate ();
  R0_p_core_potential_tab.deallocate ();
  Vo_p_core_potential_tab.deallocate ();
  Vso_p_core_potential_tab.deallocate ();
  dn_core_potential_tab.deallocate ();
  R0_n_core_potential_tab.deallocate ();
  Vo_n_core_potential_tab.deallocate ();
  Vso_n_core_potential_tab.deallocate ();
  dp_basis_core_potential_tab.deallocate ();
  R0_p_basis_core_potential_tab.deallocate ();
  Vo_p_basis_core_potential_tab.deallocate ();
  Vso_p_basis_core_potential_tab.deallocate ();
  dn_basis_core_potential_tab.deallocate ();
  R0_n_basis_core_potential_tab.deallocate ();
  Vo_n_basis_core_potential_tab.deallocate ();
  Vso_n_basis_core_potential_tab.deallocate ();
  dp_basis_tab.deallocate ();
  R0_p_basis_tab.deallocate ();
  Vo_p_basis_tab.deallocate ();
  Vso_p_basis_tab.deallocate ();
  dn_basis_tab.deallocate ();
  R0_n_basis_tab.deallocate ();
  Vo_n_basis_tab.deallocate ();
  Vso_n_basis_tab.deallocate ();
  d_basis_relative_tab.deallocate ();
  R0_basis_relative_tab.deallocate ();
  Vo_basis_relative_tab.deallocate ();
  Vso_basis_relative_tab.deallocate ();
  V_Gaussian_consts_basis.deallocate ();
  V_Gaussian_consts.deallocate ();
  b_lab_partial_waves_p_tab.deallocate ();
  b_lab_partial_waves_n_tab.deallocate ();
  prot_basis_J_tab.deallocate ();
  neut_basis_J_tab.deallocate ();
  GSM_multipoles_J_tab.deallocate ();
  EM_J_IN_tab.deallocate ();
  EM_J_OUT_tab.deallocate ();
  EM_strength_J_IN_tab.deallocate ();
  EM_strength_J_OUT_tab.deallocate ();
  beta_J_IN_tab.deallocate ();
  beta_J_OUT_tab.deallocate ();
  beta_W0_tab.deallocate ();
  beta_strength_J_IN_tab.deallocate ();
  beta_strength_J_OUT_tab.deallocate ();
  density_J_tab.deallocate ();
  correlation_density_J_tab.deallocate ();
  correlation_density_RKmax_tab.deallocate ();
  pair_density_J_tab.deallocate ();
  pair_density_RKmax_tab.deallocate ();
  spectroscopic_factor_J_IN_tab.deallocate ();
  spectroscopic_factor_J_OUT_tab.deallocate ();
  spectroscopic_factor_J_projectile_tab.deallocate ();
  overlap_function_J_IN_tab.deallocate ();
  overlap_function_J_OUT_tab.deallocate ();
  overlap_function_J_projectile_tab.deallocate ();
  rms_radius_J_tab.deallocate ();
  rms_radius_frozen_core_tab.deallocate ();
  rms_radius_one_body_strength_J_tab.deallocate ();
  Hamiltonian_parts_J_tab.deallocate ();
  Coulomb_isospin_mixture_J_tab.deallocate ();
  dagger_tilde_operators_J_IN_tab.deallocate ();
  dagger_tilde_operators_J_OUT_tab.deallocate ();
  CC_J_target_tab.deallocate ();
  CC_real_E_intrinsic_projectile_tab.deallocate ();
  CC_Gamma_intrinsic_projectile_tab.deallocate ();
  CC_real_E_target_tab.deallocate ();
  CC_Gamma_target_tab.deallocate ();
  CC_partial_wave_J_cluster_projectile_tab.deallocate ();
  CC_J_A_composite_tab.deallocate ();
  CC_CM_angles.deallocate ();
  CC_J_A_in_composite_tab.deallocate ();
  CC_J_A_out_composite_tab.deallocate ();
  CC_average_n_scat_target_projectile_max_J_A_composite_tab.deallocate ();
  CC_average_n_scat_target_projectile_max_composite_tab.deallocate ();
  CC_corrective_factors_TBMEs_J_A_composite_tab.deallocate ();
  CC_corrective_factors_TBMEs_composite_tab.deallocate ();
  CC_corrective_factors_cluster_J_A_composite_tab.deallocate ();
  CC_corrective_factors_cluster_composite_tab.deallocate ();
  V0_KKNN_p_tab.deallocate ();
  rho_KKNN_p_tab.deallocate ();
  V0_KKNN_n_tab.deallocate ();
  rho_KKNN_n_tab.deallocate ();
  V0_KKNN_basis_core_potential_p_tab.deallocate ();
  rho_KKNN_basis_core_potential_p_tab.deallocate ();
  V0_KKNN_basis_core_potential_n_tab.deallocate ();
  rho_KKNN_basis_core_potential_n_tab.deallocate ();
  Vls_KKNN_p_tab.deallocate ();
  rho_ls_KKNN_p_tab.deallocate ();
  Vls_KKNN_n_tab.deallocate ();
  rho_ls_KKNN_n_tab.deallocate ();
  Vls_KKNN_basis_core_potential_p_tab.deallocate ();
  rho_ls_KKNN_basis_core_potential_p_tab.deallocate ();
  Vls_KKNN_basis_core_potential_n_tab.deallocate ();
  rho_ls_KKNN_basis_core_potential_n_tab.deallocate ();
  CC_average_n_scat_target_tab.deallocate ();
  CC_K_peak_cluster_projectile_CM_tab.deallocate ();
  CC_K_middle_cluster_projectile_CM_tab.deallocate ();
  CC_K_max_cluster_projectile_CM_tab.deallocate ();
  shells_quantum_numbers_p_tab.deallocate ();
  shells_quantum_numbers_n_tab.deallocate ();
  PSI_qn_from_file_tab.deallocate ();
  shells_quantum_numbers_relative.deallocate ();
      
  print_detailed_information = false; 
  is_cost_function_Hessian_matrix_calculated = false;
  are_there_hyperons = false;
  is_cv_possible = false;
  //--// ...
  hypernucleus_strangeness = 0;  
  number_of_MPI_processes = 1; 
  number_of_OpenMP_threads = 1; 
  BPmin_global_pp = 0; 
  BPmax_global_pp = 0; 
  BPmin_global_nn = 0; 
  BPmax_global_nn = 0;
  BPmin_global_pn = 0; 
  BPmax_global_pn = 0;  
  Jmin_global_pp = 0; 
  Jmax_global_pp = 0; 
  Jmin_global_pp_opp = 0;
  Jmax_global_pp_opp = 0;
  Jmin_global_nn = 0; 
  Jmax_global_nn = 0; 
  Jmin_global_nn_opp = 0;
  Jmax_global_nn_opp = 0;
  Jmin_global_pn = 0; 
  Jmax_global_pn = 0; 
  Jmin_global_pn_opp = 0;
  Jmax_global_pn_opp = 0;
  BPmin_global_pp_basis = 0; 
  BPmax_global_pp_basis = 0;
  BPmin_global_nn_basis = 0; 
  BPmax_global_nn_basis = 0; 
  BPmin_global_pn_basis = 0; 
  BPmax_global_pn_basis = 0;  
  Jmin_global_pp_basis = 0; 
  Jmax_global_pp_basis = 0;
  Jmin_global_pp_opp_basis = 0;
  Jmax_global_pp_opp_basis = 0; 
  Jmin_global_nn_basis = 0; 
  Jmax_global_nn_basis = 0;
  Jmin_global_nn_opp_basis = 0;
  Jmax_global_nn_opp_basis = 0; 
  Jmin_global_pn_basis = 0; 
  Jmax_global_pn_basis = 0; 
  Jmin_global_pn_opp_basis = 0;
  Jmax_global_pn_opp_basis = 0;
  i_charge_min_global_pp = 0; 
  i_charge_max_global_pp = 0; 
  i_charge_min_global_nn = 0; 
  i_charge_max_global_nn = 0; 
  i_charge_min_global_pn = 0; 
  i_charge_max_global_pn = 0; 
  strangeness_min_global_pp = 0; 
  strangeness_max_global_pp = 0; 
  strangeness_min_global_nn = 0; 
  strangeness_max_global_nn = 0; 
  strangeness_min_global_pn = 0; 
  strangeness_max_global_pn = 0; 
  only_dimensions = false; 
  non_zero_NBMEs_proportion_only = false; 
  copy_J_OBMEs_TBMEs = false; 
  initial_pivot_from_file = false; 
  full_common_vectors_used_in_file = false; 
  is_Coulomb_Hamiltonian_here = false; 
  is_Coulomb_to_be_added = false; 
  T2_CM_operators_calculated = false; 
  J_projected = false; 
  are_two_body_clusters_stored_in_J_scheme = false;
  is_hole_double_counting_suppressed = false;
  Hamiltonian_storage = NO_STORAGE; 
  M_TBMEs_storage = NO_STORAGE; 
  one_jumps_pn_two_jumps_cv_storage = NO_STORAGE;
  basis_space = NO_SPACE; 
  space = NO_SPACE; 
  inter = NO_INTERACTION; 
  basis_potential = NO_POTENTIAL;  
  relative_cluster = NO_PARTICLE; 
  R = 0; 
  step_bef_R_uniform = 0;
  R_real_max = 0; 
  R_cut_function = 0; 
  d_cut_function = 0; 
  Ueq_regularizor = 0; 
  lambda_Hcm = 0; 
  N_bef_R_GL = 0; 
  N_aft_R_GL = 0; 
  N_bef_R_uniform = 0; 
  N_aft_R_uniform = 0;
  good_isospin_basis_potential = false; 
  all_states_calculated = false; 
  R_charge = 2.0; 
  H_potential = NO_POTENTIAL; 
  H_basis_core_potential = NO_POTENTIAL; 
  A_core = 0; 
  Z_core = 0; 
  N_core = 0; 
  prot_hole_states_number = 0;
  neut_hole_states_number = 0;
  frozen_core_mass = 0; 
  nucleus_mass = 0; 
  nucleus_mass_basis = 0;
  total_nucleus_mass = 0;
  truncation_hw = false; 
  truncation_ph = false; 
  E_relative_max_hw_pole_approximation = 0; 
  E_relative_max_hw = 0; 
  E_max_hw_pole_approximation = 0; 
  E_max_hw = 0; 
  n_scat_max = 0; 
  n_scat_max_p = 0; 
  n_scat_max_n = 0;  
  n_holes_max_pole_approximation = 0;
  n_holes_max_p_pole_approximation = 0;
  n_holes_max_n_pole_approximation = 0; 
  n_holes_max = 0;
  n_holes_max_p = 0;
  n_holes_max_n = 0;
  is_it_Lanczos = false; 
  is_it_Lowdin = false; 
  OBMEs_inter_read = false;
  is_it_cluster_CM_HO_basis_calculation = false;
  binding_energies_fitted = false;
  are_natural_orbitals_calculated_every_iteration = false;

  configuration_precision = 0; 
  workspace_max_dimension = 0; 
  N_restarts = 0; 
  test_vector_solution = 0; 
  A = 0; 
  Z = 0; 
  N = 0; 
  A_basis = 0; 
  Z_basis = 0; 
  N_basis = 0; 
  ZY_charge_pos = 0; 
  ZY_charge_neg = 0; 
  ZY_charge_basis_potential_pos = 0; 
  ZY_charge_basis_potential_neg = 0; 
  Zval = 0; 
  Nval = 0; 
  Zval_basis = 0; 
  Nval_basis = 0;  
  ZYval = 0; 
  NYval = 0;
  N_nuclei_to_consider = 0; 
  Newton_precision = 0; 
  inter_read = NO_TBMES_READ; 
  is_R_charge_fitted = false; 
  is_V0_ctr_ot_S1_T1_fitted = false; 
  is_V0_ctr_et_S1_T0_fitted = false; 
  is_V0_ctr_os_S0_T0_fitted = false; 
  is_V0_ctr_es_S0_T1_fitted = false; 
  is_V0_so_ot_S1_T1_fitted = false; 
  is_V0_so_et_S1_T0_fitted = false; 
  is_V0_t_ot_S1_T1_fitted = false; 
  is_V0_t_et_S1_T0_fitted = false; 
  is_V0_ALS_fitted = false; 
  is_VS_const_LO_T0_fitted = false;
  is_VS_const_LO_T1_fitted = false;
  is_VT_sigma_product_LO_T0_fitted = false;
  is_VT_sigma_product_LO_T1_fitted = false;
  is_V1_q2_NLO_fitted = false;
  is_V2_k2_NLO_fitted = false;
  is_V3_q2_sigma_product_NLO_fitted = false;
  is_V4_k2_sigma_product_NLO_fitted = false;
  is_V5_sigma_q_vector_k_NLO_fitted = false;
  is_V6_sigma_q_product_NLO_fitted = false;
  is_V7_sigma_k_product_NLO_fitted = false;
  is_V8_sigma_q_vector_k_NLO_fitted = false;
  is_V8a_SU3f_fitted = false;
  is_V8s_SU3f_fitted  = false;
  is_V10_SU3f_fitted = false;
  is_V1_SU3f_fitted = false;
  is_it_fixed_relative_SVD_precision = false;
  relative_SVD_precision = 0; 
  rejected_singular_values_number = 0; 
  Jn_relative_max_basis = 0; 
  Jc_relative_max_basis = 0; 
  Jn_relative_max = 0; 
  Jc_relative_max = 0; 
  R0_inter_basis = 5; 
  mu_basis = 0; 
  a_basis = 0; 
  b_basis = 0; 
  V_SDI_basis = 0; 
  b_lab_basis = 0; 
  R0_inter = 5; 
  mu = 0; 
  a = 0; 
  b = 0; 
  V_SDI = 0; 
  A_dependence_alpha_core_potential = 0; 
  A_dependence_exponent = 0; 
  b_lab = 0; 
  u_Minnesota_basis = 0; 
  nu_three_body_like_basis = 0; 
  V_three_body_like_basis = 0; 
  V0_ctr_ot_basis = 0; 
  V0_ctr_et_basis = 0; 
  V0_ctr_os_basis = 0; 
  V0_ctr_es_basis = 0; 
  V0_so_ot_basis = 0; 
  V0_so_et_basis = 0; 
  V0_t_ot_basis = 0; 
  V0_t_et_basis = 0; 
  V0_ALS_basis = 0; 
  VS_const_LO_T0_basis = 0;
  VS_const_LO_T1_basis = 0;
  VT_sigma_product_LO_T0_basis = 0;
  VT_sigma_product_LO_T1_basis = 0;
  V1_q2_NLO_basis = 0;
  V2_k2_NLO_basis = 0;
  V3_q2_sigma_product_NLO_basis = 0;
  V4_k2_sigma_product_NLO_basis = 0;
  V5_sigma_q_vector_k_NLO_basis = 0;
  V6_sigma_q_product_NLO_basis = 0;
  V7_sigma_k_product_NLO_basis = 0; 
  V8_sigma_q_vector_k_NLO_basis = 0;
  V8a_SU3f_basis = 0;
  V8s_SU3f_basis = 0;
  V10_SU3f_basis = 0;
  V1_SU3f_basis = 0;
  u_Minnesota = 0; 
  nu_three_body_like = 0; 
  V_three_body_like = 0; 
  V0_ctr_ot = 0; 
  V0_ctr_et = 0; 
  V0_ctr_os = 0; 
  V0_ctr_es = 0; 
  V0_so_ot = 0; 
  V0_so_et = 0; 
  V0_t_ot = 0; 
  V0_t_et = 0;
  V0_ALS = 0;  
  VS_const_LO_T0 = 0;
  VS_const_LO_T1 = 0;
  VT_sigma_product_LO_T0 = 0;
  VT_sigma_product_LO_T1 = 0;
  V1_q2_NLO = 0;
  V2_k2_NLO = 0;
  V3_q2_sigma_product_NLO = 0;
  V4_k2_sigma_product_NLO = 0;
  V5_sigma_q_vector_k_NLO = 0;
  V6_sigma_q_product_NLO = 0;
  V7_sigma_k_product_NLO = 0; 
  eigenset_vectors_number_max = 0;
  N_nlj_relative = 0;
  N_nlj_res_relative = 0;
  nmax_p = 0; 
  nmax_n = 0; 
  nmax_relative = 0; 
  lmax_p = 0; 
  lmax_n = 0; 
  lmax_relative = 0; 
  lmax_for_basis_interaction = 0; 
  lmax_for_interaction = 0; 
  jp_max = 0; 
  jn_max = 0; 
  jmax_relative = 0; 
  mp_max = 0; 
  mn_max = 0; 
  mp_min = 0; 
  mn_min = 0; 
  mp_max_minus_half = 0; 
  mn_max_minus_half = 0; 
  two_mp_max = 0; 
  two_mn_max = 0; 
  four_mp_max = 0; 
  four_mn_max = 0; 
  mp_max_minus_mp_min = 0; 
  mn_max_minus_mn_min = 0; 
  natural_orbitals_reference_states_number = 0;
  HF_max_iterations_number = 0; 
  HF_precision = 0.0; 
  files_number = 0; 
  prot_Y_N_paths = 0; 
  neut_Y_N_paths = 0; 
  eigensets_number = 0; 
  are_there_GSM_multipoles = false; 
  are_there_EM_transitions = false; 
  GSM_multipoles_number = 0; 
  EM_transitions_number = 0; 
  are_there_EM_transitions_strength = false; 
  are_there_beta_transitions = false; 
  are_there_beta_transitions_strength = false;
  are_there_densities = false;  
  are_there_correlation_densities = false;
  are_there_pair_densities = false;
  are_there_spectroscopic_factors = false;
  are_there_overlap_functions = false; 
  are_there_rms_radii = false; 
  are_there_rms_radius_one_body_strengths = false; 
  are_there_Hamiltonian_parts = false;
  are_there_Coulomb_isospin_mixtures = false; 
  are_there_dagger_tilde_operators = false;    
  EM_transitions_strength_number = 0; 
  beta_transitions_number = 0; 
  beta_transitions_strength_number = 0; 
  density_number = 0; 
  correlation_density_number = 0; 
  correlation_density_theta_number = 0; 
  pair_density_number = 0; 
  spectroscopic_factor_number = 0; 
  overlap_function_number = 0; 
  rms_radius_number = 0; 
  rms_radius_one_body_strength_number = 0; 
  Hamiltonian_parts_eigenstates_number = 0; 
  Coulomb_isospin_mixture_number = 0; 
  dagger_tilde_operators_number = 0;
  is_correlation_density_theta_value_imposed = false; 
  correlation_density_imposed_theta_value = 0.0;
  RDM_matrix_constraint = NO_RDM_CONSTRAINT;
  RDM_is_it_BiCG = false;
  RDM_are_there_J_constraints = false;
  RDM_is_there_CM_correction = false;
  RDM_is_there_isospin_constraint = false;
  RDM_Gamma_init_from_file = false;
  RDM_is_there_E_reference = false;
  RDM_E_minimization_precision = 0;
  RDM_sigma_init = 0;
  RDM_multiplicative_sigma_step = 0;
  RDM_smallness_factor = 0;					 
  RDM_BP = 0;
  RDM_vector_index = 0;
  RDM_J = 0;
  RDM_E_reference = 0;
  RDM_Hamiltonian_renormalization_factor = 0;
  CC_reaction = NO_REACTION; 
  CC_reaction_calculation = NO_REACTION_CALCULATION; 
  CC_are_GSM_a_dagger_vectors_calculated = false; 
  CC_E_kinetic_total_system_CM_start = 0; 
  CC_E_kinetic_total_system_CM_end = 0; 
  CC_average_n_scat_target_projectile_max_composite_number = 0; 
  CC_corrective_factors_TBMEs_composite_number = 0; 
  CC_N_target_projectile_states = 0;
  CC_N_partial_waves_max = 0;
  CC_Davidson_N_restarts = 0; 
  CC_Davidson_max_dimension = 0; 
  CC_Davidson_eigenvector_precision = sqrt_precision; 
  CC_relative_SVD_precision = sqrt_precision; 
  CC_forbidden_channel_precision = sqrt_precision; 
  CC_N_energies = 0; 
  CC_N_CM_angles = 0; 
  CC_EM_for_radiative_capture_cross_section = NO_EM; 
  CC_L_for_radiative_capture_cross_section = 0; 
  CC_N_theta_gamma = 1; 
  CC_N_phi_gamma = 1; 
  CC_is_it_longwavelength_approximation = false; 
  CC_is_it_HO_expansion = true; 
  CC_N_JPi_A_composite = 0; 
  CC_N_JPi_A_in_composite = 0; 
  CC_N_JPi_A_out_composite = 0; 
  //--// CC cluster
  CC_cluster_projectile_number = 0;
  CC_Lmax_all = 0;
  CC_J_number_max_all = 0;
  are_GSM_vectors_stored_on_disk = false;
  are_configuration_probabilities_printed = false;
  are_scattering_configuration_probabilities_printed = false;
  is_there_effective_range_expansion = false;
  M_equal_J_imposed_in_GSM_vectors = false;
  is_there_disk_storage_eigenvectors_all_M = false;
  E_CM_HO_max = 0; 
  CC_corrective_factors_cluster_composite_numbers_max = 0;
  are_there_basis_natural_orbitals_p = false;
  are_there_basis_natural_orbitals_n = false;
  are_there_new_natural_orbitals_p = false;
  are_there_new_natural_orbitals_n = false;
  Nk_momentum_GL = 0;
  Nk_momentum_uniform = 0;
  N_hyperon_types = 0;
  kmax_momentum = 0;
  R_Fermi_momentum = 0;
  step_momentum_uniform = 0;
}





unsigned int input_data_str::get_dimension_unsigned_int_constants () const
{
  return 75;
}

void input_data_str::get_unsigned_int_constants (class array<unsigned int> &T_unsigned_int) const
{
  const unsigned int dimension_unsigned_int = T_unsigned_int.dimension (0);

  unsigned int i_unsigned_int = 0;

  T_unsigned_int(i_unsigned_int++) = number_of_MPI_processes;
  T_unsigned_int(i_unsigned_int++) = number_of_OpenMP_threads;
  T_unsigned_int(i_unsigned_int++) = BPmin_global_pp;
  T_unsigned_int(i_unsigned_int++) = BPmax_global_pp;
  T_unsigned_int(i_unsigned_int++) = BPmin_global_nn;
  T_unsigned_int(i_unsigned_int++) = BPmax_global_nn;
  T_unsigned_int(i_unsigned_int++) = BPmin_global_pn;
  T_unsigned_int(i_unsigned_int++) = BPmax_global_pn;
  T_unsigned_int(i_unsigned_int++) = BPmin_global_pp_basis;
  T_unsigned_int(i_unsigned_int++) = BPmax_global_pp_basis;
  //10
  T_unsigned_int(i_unsigned_int++) = BPmin_global_nn_basis;
  T_unsigned_int(i_unsigned_int++) = BPmax_global_nn_basis;
  T_unsigned_int(i_unsigned_int++) = BPmin_global_pn_basis;
  T_unsigned_int(i_unsigned_int++) = BPmax_global_pn_basis;
  T_unsigned_int(i_unsigned_int++) = i_charge_min_global_pp;
  T_unsigned_int(i_unsigned_int++) = i_charge_max_global_pp;
  T_unsigned_int(i_unsigned_int++) = i_charge_min_global_nn;
  T_unsigned_int(i_unsigned_int++) = i_charge_max_global_nn;
  T_unsigned_int(i_unsigned_int++) = i_charge_min_global_pn;
  T_unsigned_int(i_unsigned_int++) = i_charge_max_global_pn;
  //20
  T_unsigned_int(i_unsigned_int++) = N_bef_R_GL;
  T_unsigned_int(i_unsigned_int++) = N_aft_R_GL;
  T_unsigned_int(i_unsigned_int++) = N_bef_R_uniform;
  T_unsigned_int(i_unsigned_int++) = N_aft_R_uniform;  
  T_unsigned_int(i_unsigned_int++) = workspace_max_dimension;
  T_unsigned_int(i_unsigned_int++) = N_restarts;
  T_unsigned_int(i_unsigned_int++) = N_nuclei_to_consider;
  T_unsigned_int(i_unsigned_int++) = N_nlj_relative;
  T_unsigned_int(i_unsigned_int++) = N_nlj_res_relative;
  T_unsigned_int(i_unsigned_int++) = natural_orbitals_reference_states_number;
  //30
  T_unsigned_int(i_unsigned_int++) = HF_max_iterations_number;
  T_unsigned_int(i_unsigned_int++) = files_number;
  T_unsigned_int(i_unsigned_int++) = prot_Y_N_paths;
  T_unsigned_int(i_unsigned_int++) = neut_Y_N_paths;
  T_unsigned_int(i_unsigned_int++) = eigensets_number;
  T_unsigned_int(i_unsigned_int++) = eigenset_vectors_number_max;
  T_unsigned_int(i_unsigned_int++) = EM_transitions_number;
  T_unsigned_int(i_unsigned_int++) = EM_transitions_strength_number;
  T_unsigned_int(i_unsigned_int++) = beta_transitions_number;
  T_unsigned_int(i_unsigned_int++) = beta_transitions_strength_number;
  //40
  T_unsigned_int(i_unsigned_int++) = density_number;
  T_unsigned_int(i_unsigned_int++) = correlation_density_number;
  T_unsigned_int(i_unsigned_int++) = correlation_density_theta_number;  
  T_unsigned_int(i_unsigned_int++) = spectroscopic_factor_number;
  T_unsigned_int(i_unsigned_int++) = overlap_function_number;
  T_unsigned_int(i_unsigned_int++) = rms_radius_number;
  T_unsigned_int(i_unsigned_int++) = rms_radius_one_body_strength_number;
  T_unsigned_int(i_unsigned_int++) = Hamiltonian_parts_eigenstates_number;
  T_unsigned_int(i_unsigned_int++) = Coulomb_isospin_mixture_number; 
  T_unsigned_int(i_unsigned_int++) = dagger_tilde_operators_number;
  //50
  T_unsigned_int(i_unsigned_int++) = CC_N_JPi_A_composite;
  T_unsigned_int(i_unsigned_int++) = CC_N_target_projectile_states;
  T_unsigned_int(i_unsigned_int++) = CC_Davidson_N_restarts;
  T_unsigned_int(i_unsigned_int++) = CC_Davidson_max_dimension;
  T_unsigned_int(i_unsigned_int++) = CC_N_energies;
  T_unsigned_int(i_unsigned_int++) = CC_N_CM_angles;
  T_unsigned_int(i_unsigned_int++) = CC_N_theta_gamma;
  T_unsigned_int(i_unsigned_int++) = CC_N_phi_gamma;
  T_unsigned_int(i_unsigned_int++) = CC_N_JPi_A_in_composite;
  T_unsigned_int(i_unsigned_int++) = CC_N_JPi_A_out_composite;
  //60
  T_unsigned_int(i_unsigned_int++) = CC_cluster_projectile_number;
  T_unsigned_int(i_unsigned_int++) = CC_corrective_factors_TBMEs_composite_number;
  T_unsigned_int(i_unsigned_int++) = CC_Lmax_all;
  T_unsigned_int(i_unsigned_int++) = CC_J_number_max_all;
  T_unsigned_int(i_unsigned_int++) = CC_N_partial_waves_max;
  T_unsigned_int(i_unsigned_int++) = Nk_momentum_GL;
  T_unsigned_int(i_unsigned_int++) = Nk_momentum_uniform;
  T_unsigned_int(i_unsigned_int++) = N_hyperon_types;
  T_unsigned_int(i_unsigned_int++) = rejected_singular_values_number;
  T_unsigned_int(i_unsigned_int++) = GSM_multipoles_number;
  //70
  T_unsigned_int(i_unsigned_int++) = RDM_BP;
  T_unsigned_int(i_unsigned_int++) = RDM_vector_index;
  T_unsigned_int(i_unsigned_int++) = pair_density_number;
  T_unsigned_int(i_unsigned_int++) = CC_corrective_factors_cluster_composite_numbers_max;
  T_unsigned_int(i_unsigned_int++) = CC_average_n_scat_target_projectile_max_composite_number;
  //75

  if (i_unsigned_int != dimension_unsigned_int)
    error_message_print_abort ("i_unsigned_int=" + make_string<unsigned int> (i_unsigned_int) + "!= dimension_unsigned_int=" + make_string<unsigned int> (dimension_unsigned_int) + " in input_data_str::get_unsigned_int_constants.");
}







void input_data_str::put_unsigned_int_constants (class array<unsigned int> &T_unsigned_int)
{	
  const unsigned int dimension_unsigned_int = T_unsigned_int.dimension (0);

  unsigned int i_unsigned_int = 0;
  
  number_of_MPI_processes = T_unsigned_int(i_unsigned_int++);
  number_of_OpenMP_threads = T_unsigned_int(i_unsigned_int++);
  BPmin_global_pp = T_unsigned_int(i_unsigned_int++);
  BPmax_global_pp = T_unsigned_int(i_unsigned_int++);
  BPmin_global_nn = T_unsigned_int(i_unsigned_int++);
  BPmax_global_nn = T_unsigned_int(i_unsigned_int++);
  BPmin_global_pn = T_unsigned_int(i_unsigned_int++);
  BPmax_global_pn = T_unsigned_int(i_unsigned_int++);
  BPmin_global_pp_basis = T_unsigned_int(i_unsigned_int++);
  BPmax_global_pp_basis = T_unsigned_int(i_unsigned_int++);
  //10
  BPmin_global_nn_basis = T_unsigned_int(i_unsigned_int++);
  BPmax_global_nn_basis = T_unsigned_int(i_unsigned_int++);
  BPmin_global_pn_basis = T_unsigned_int(i_unsigned_int++);
  BPmax_global_pn_basis = T_unsigned_int(i_unsigned_int++);
  i_charge_min_global_pp = T_unsigned_int(i_unsigned_int++);
  i_charge_max_global_pp = T_unsigned_int(i_unsigned_int++);
  i_charge_min_global_nn = T_unsigned_int(i_unsigned_int++);
  i_charge_max_global_nn = T_unsigned_int(i_unsigned_int++);
  i_charge_min_global_pn = T_unsigned_int(i_unsigned_int++);
  i_charge_max_global_pn = T_unsigned_int(i_unsigned_int++);
  //20
  N_bef_R_GL = T_unsigned_int(i_unsigned_int++);
  N_aft_R_GL = T_unsigned_int(i_unsigned_int++);
  N_bef_R_uniform = T_unsigned_int(i_unsigned_int++);
  N_aft_R_uniform = T_unsigned_int(i_unsigned_int++);  
  workspace_max_dimension = T_unsigned_int(i_unsigned_int++);
  N_restarts = T_unsigned_int(i_unsigned_int++);
  N_nuclei_to_consider = T_unsigned_int(i_unsigned_int++);
  N_nlj_relative = T_unsigned_int(i_unsigned_int++);
  N_nlj_res_relative = T_unsigned_int(i_unsigned_int++);
  natural_orbitals_reference_states_number = T_unsigned_int(i_unsigned_int++);
  //30
  HF_max_iterations_number = T_unsigned_int(i_unsigned_int++);
  files_number = T_unsigned_int(i_unsigned_int++);
  prot_Y_N_paths = T_unsigned_int(i_unsigned_int++);
  neut_Y_N_paths = T_unsigned_int(i_unsigned_int++);
  eigensets_number = T_unsigned_int(i_unsigned_int++);
  eigenset_vectors_number_max = T_unsigned_int(i_unsigned_int++);
  EM_transitions_number = T_unsigned_int(i_unsigned_int++);
  EM_transitions_strength_number = T_unsigned_int(i_unsigned_int++);
  beta_transitions_number = T_unsigned_int(i_unsigned_int++);
  beta_transitions_strength_number = T_unsigned_int(i_unsigned_int++);
  //40
  density_number = T_unsigned_int(i_unsigned_int++);
  correlation_density_number = T_unsigned_int(i_unsigned_int++);
  correlation_density_theta_number = T_unsigned_int(i_unsigned_int++);  
  spectroscopic_factor_number = T_unsigned_int(i_unsigned_int++);
  overlap_function_number = T_unsigned_int(i_unsigned_int++);
  rms_radius_number = T_unsigned_int(i_unsigned_int++);
  rms_radius_one_body_strength_number = T_unsigned_int(i_unsigned_int++);
  Hamiltonian_parts_eigenstates_number = T_unsigned_int(i_unsigned_int++);
  Coulomb_isospin_mixture_number = T_unsigned_int(i_unsigned_int++); 
  dagger_tilde_operators_number = T_unsigned_int(i_unsigned_int++);
  //50
  CC_N_JPi_A_composite = T_unsigned_int(i_unsigned_int++);
  CC_N_target_projectile_states = T_unsigned_int(i_unsigned_int++);
  CC_Davidson_N_restarts = T_unsigned_int(i_unsigned_int++);
  CC_Davidson_max_dimension = T_unsigned_int(i_unsigned_int++);
  CC_N_energies = T_unsigned_int(i_unsigned_int++);
  CC_N_CM_angles = T_unsigned_int(i_unsigned_int++);
  CC_N_theta_gamma = T_unsigned_int(i_unsigned_int++);
  CC_N_phi_gamma = T_unsigned_int(i_unsigned_int++);
  CC_N_JPi_A_in_composite = T_unsigned_int(i_unsigned_int++);
  CC_N_JPi_A_out_composite = T_unsigned_int(i_unsigned_int++);
  //60
  CC_cluster_projectile_number = T_unsigned_int(i_unsigned_int++);
  CC_corrective_factors_TBMEs_composite_number = T_unsigned_int(i_unsigned_int++);
  CC_Lmax_all = T_unsigned_int(i_unsigned_int++);
  CC_J_number_max_all = T_unsigned_int(i_unsigned_int++);
  CC_N_partial_waves_max = T_unsigned_int(i_unsigned_int++);
  Nk_momentum_GL = T_unsigned_int(i_unsigned_int++);
  Nk_momentum_uniform = T_unsigned_int(i_unsigned_int++);
  N_hyperon_types = T_unsigned_int(i_unsigned_int++);
  rejected_singular_values_number = T_unsigned_int(i_unsigned_int++);
  GSM_multipoles_number = T_unsigned_int(i_unsigned_int++);
  //70
  RDM_BP = T_unsigned_int(i_unsigned_int++);
  RDM_vector_index = T_unsigned_int(i_unsigned_int++);
  pair_density_number = T_unsigned_int(i_unsigned_int++);
  CC_corrective_factors_cluster_composite_numbers_max = T_unsigned_int(i_unsigned_int++);
  CC_average_n_scat_target_projectile_max_composite_number = T_unsigned_int(i_unsigned_int++);
  //75

  if (i_unsigned_int != dimension_unsigned_int)
    error_message_print_abort ("i_unsigned_int=" + make_string<unsigned int> (i_unsigned_int) + " != dimension_unsigned_int=" + make_string<unsigned int> (dimension_unsigned_int) + " in input_data_str::put_unsigned_int_constants.");
}











unsigned int input_data_str::get_dimension_int_constants () const
{
  return 105;
}

void input_data_str::get_int_constants (class array<int> &T_int) const
{
  const unsigned int dimension_int = T_int.dimension (0);

  unsigned int i_int = 0;

  T_int(i_int++) = Jmin_global_pp;
  T_int(i_int++) = Jmax_global_pp;
  T_int(i_int++) = Jmin_global_nn;
  T_int(i_int++) = Jmax_global_nn;
  T_int(i_int++) = Jmin_global_pn;
  T_int(i_int++) = Jmax_global_pn;
  T_int(i_int++) = Jmin_global_pp_basis;
  T_int(i_int++) = Jmax_global_pp_basis;
  T_int(i_int++) = Jmin_global_nn_basis;
  T_int(i_int++) = Jmax_global_nn_basis;
  //10
  T_int(i_int++) = Jmin_global_pn_basis;
  T_int(i_int++) = Jmax_global_pn_basis;
  T_int(i_int++) = basis_space;
  T_int(i_int++) = space;
  T_int(i_int++) = inter;
  T_int(i_int++) = basis_potential;
  T_int(i_int++) = H_potential;
  T_int(i_int++) = H_basis_core_potential;
  T_int(i_int++) = A_core;
  T_int(i_int++) = Z_core;
  //20
  T_int(i_int++) = N_core;
  T_int(i_int++) = prot_hole_states_number;
  T_int(i_int++) = neut_hole_states_number;
  T_int(i_int++) = E_relative_max_hw;
  T_int(i_int++) = E_max_hw;
  T_int(i_int++) = n_scat_max;
  T_int(i_int++) = n_scat_max_p;
  T_int(i_int++) = n_scat_max_n;
  T_int(i_int++) = n_holes_max_pole_approximation;
  T_int(i_int++) = n_holes_max_p_pole_approximation;
  //30
  T_int(i_int++) = n_holes_max_n_pole_approximation;
  T_int(i_int++) = n_holes_max;
  T_int(i_int++) = n_holes_max_p; 
  T_int(i_int++) = n_holes_max_n;
  T_int(i_int++) = A;
  T_int(i_int++) = Z;
  T_int(i_int++) = N;
  T_int(i_int++) = A_basis;
  T_int(i_int++) = Z_basis;
  T_int(i_int++) = N_basis;
  //40 
  T_int(i_int++) = ZY_charge_pos; 
  T_int(i_int++) = ZY_charge_neg;  
  T_int(i_int++) = ZY_charge_basis_potential_pos;
  T_int(i_int++) = ZY_charge_basis_potential_neg;
  T_int(i_int++) = Zval;
  T_int(i_int++) = Nval;
  T_int(i_int++) = Zval_basis;
  T_int(i_int++) = Nval_basis;
  T_int(i_int++) = ZYval;
  T_int(i_int++) = NYval;
  //50
  T_int(i_int++) = inter_read;
  T_int(i_int++) = Jn_relative_max_basis;
  T_int(i_int++) = Jc_relative_max_basis;
  T_int(i_int++) = Jn_relative_max;
  T_int(i_int++) = Jc_relative_max;
  T_int(i_int++) = nmax_p;
  T_int(i_int++) = nmax_n;
  T_int(i_int++) = nmax_relative;
  T_int(i_int++) = lmax_p;
  T_int(i_int++) = lmax_n;
  //60
  T_int(i_int++) = lmax_relative;
  T_int(i_int++) = jmax_relative;
  T_int(i_int++) = lmax_for_basis_interaction;
  T_int(i_int++) = lmax_for_interaction; 
  T_int(i_int++) = mp_max_minus_half;
  T_int(i_int++) = mn_max_minus_half;
  T_int(i_int++) = two_mp_max;
  T_int(i_int++) = two_mn_max;
  T_int(i_int++) = four_mp_max;
  T_int(i_int++) = four_mn_max;
  //70
  T_int(i_int++) = mp_max_minus_mp_min;
  T_int(i_int++) = mn_max_minus_mn_min;
  T_int(i_int++) = CC_reaction;
  T_int(i_int++) = CC_reaction_calculation;
  T_int(i_int++) = CC_L_for_radiative_capture_cross_section;
  T_int(i_int++) = E_relative_max_hw_pole_approximation;
  T_int(i_int++) = E_max_hw_pole_approximation;
  T_int(i_int++) = Hamiltonian_storage;
  T_int(i_int++) = M_TBMEs_storage;
  T_int(i_int++) = one_jumps_pn_two_jumps_cv_storage;
  //80
  T_int(i_int++) = CC_EM_for_radiative_capture_cross_section;
  T_int(i_int++) = E_CM_HO_max;
  T_int(i_int++) = RDM_matrix_constraint;  
  T_int(i_int++) = Jmin_global_pp_opp;
  T_int(i_int++) = Jmax_global_pp_opp;
  T_int(i_int++) = Jmin_global_nn_opp;
  T_int(i_int++) = Jmax_global_nn_opp;
  T_int(i_int++) = Jmin_global_pn_opp;
  T_int(i_int++) = Jmax_global_pn_opp;
  T_int(i_int++) = Jmin_global_pp_opp_basis;
  //90
  T_int(i_int++) = Jmax_global_pp_opp_basis;
  T_int(i_int++) = Jmin_global_nn_opp_basis;
  T_int(i_int++) = Jmax_global_nn_opp_basis;
  T_int(i_int++) = Jmin_global_pn_opp_basis;
  T_int(i_int++) = Jmax_global_pn_opp_basis;
  T_int(i_int++) = relative_cluster;
  T_int(i_int++) = strangeness_min_global_pp; 
  T_int(i_int++) = strangeness_max_global_pp; 
  T_int(i_int++) = strangeness_min_global_nn; 
  T_int(i_int++) = strangeness_max_global_nn;
  //100
  T_int(i_int++) = strangeness_min_global_pn; 
  T_int(i_int++) = strangeness_max_global_pn;
  T_int(i_int++) = hypernucleus_strangeness;
  T_int(i_int++) = lmax_common_p;
  T_int(i_int++) = lmax_common_n;
  //105
  
  if (i_int != dimension_int)
    error_message_print_abort ("i_int=" + make_string<unsigned int> (i_int) + " != dimension_int=" + make_string<unsigned int> (dimension_int) + " in input_data_str::get_int_constants.");
}









void input_data_str::put_int_constants (class array<int> &T_int)
{	
  const unsigned int dimension_int = T_int.dimension (0);

  unsigned int i_int = 0;
  
  Jmin_global_pp = T_int(i_int++);
  Jmax_global_pp = T_int(i_int++);
  Jmin_global_nn = T_int(i_int++);
  Jmax_global_nn = T_int(i_int++);
  Jmin_global_pn = T_int(i_int++);
  Jmax_global_pn = T_int(i_int++);
  Jmin_global_pp_basis = T_int(i_int++);
  Jmax_global_pp_basis = T_int(i_int++);
  Jmin_global_nn_basis = T_int(i_int++);
  Jmax_global_nn_basis = T_int(i_int++);
  //10
  Jmin_global_pn_basis = T_int(i_int++);
  Jmax_global_pn_basis = T_int(i_int++);
  basis_space = static_cast<enum space_type> (T_int(i_int++));
  space = static_cast<enum space_type> (T_int(i_int++));
  inter = static_cast<enum interaction_type> (T_int(i_int++));
  basis_potential = static_cast<enum potential_type> (T_int(i_int++)); 
  H_potential = static_cast<enum potential_type> (T_int(i_int++));
  H_basis_core_potential = static_cast<enum potential_type>   (T_int(i_int++));
  A_core = T_int(i_int++);
  Z_core = T_int(i_int++);
  //20
  N_core = T_int(i_int++);
  prot_hole_states_number = T_int(i_int++);
  neut_hole_states_number = T_int(i_int++);
  E_relative_max_hw = T_int(i_int++);
  E_max_hw = T_int(i_int++);
  n_scat_max = T_int(i_int++);
  n_scat_max_p = T_int(i_int++);
  n_scat_max_n = T_int(i_int++);
  n_holes_max_pole_approximation = T_int(i_int++);
  n_holes_max_p_pole_approximation = T_int(i_int++);
  //30
  n_holes_max_n_pole_approximation = T_int(i_int++);
  n_holes_max = T_int(i_int++);
  n_holes_max_p = T_int(i_int++); 
  n_holes_max_n = T_int(i_int++);
  A = T_int(i_int++);
  Z = T_int(i_int++);
  N = T_int(i_int++);
  A_basis = T_int(i_int++);
  Z_basis = T_int(i_int++);
  N_basis = T_int(i_int++);
  //40 
  ZY_charge_pos = T_int(i_int++); 
  ZY_charge_neg = T_int(i_int++);  
  ZY_charge_basis_potential_pos = T_int(i_int++);
  ZY_charge_basis_potential_neg = T_int(i_int++);
  Zval = T_int(i_int++);
  Nval = T_int(i_int++);
  Zval_basis = T_int(i_int++);
  Nval_basis = T_int(i_int++);
  ZYval = T_int(i_int++);
  NYval = T_int(i_int++);
  //50
  inter_read = static_cast<enum interaction_read_type> (T_int(i_int++));
  Jn_relative_max_basis = T_int(i_int++);
  Jc_relative_max_basis = T_int(i_int++);
  Jn_relative_max = T_int(i_int++);
  Jc_relative_max = T_int(i_int++);
  nmax_p = T_int(i_int++);
  nmax_n = T_int(i_int++);
  nmax_relative = T_int(i_int++);
  lmax_p = T_int(i_int++);
  lmax_n = T_int(i_int++);
  //60
  lmax_relative = T_int(i_int++);
  jmax_relative = T_int(i_int++);
  lmax_for_basis_interaction = T_int(i_int++);
  lmax_for_interaction = T_int(i_int++); 
  mp_max_minus_half = T_int(i_int++);
  mn_max_minus_half = T_int(i_int++);
  two_mp_max = T_int(i_int++);
  two_mn_max = T_int(i_int++);
  four_mp_max = T_int(i_int++);
  four_mn_max = T_int(i_int++);
  //70
  mp_max_minus_mp_min = T_int(i_int++);
  mn_max_minus_mn_min = T_int(i_int++);
  CC_reaction = static_cast<enum CC_reaction_type> (T_int(i_int++));
  CC_reaction_calculation = static_cast<enum CC_reaction_calculation_type> (T_int(i_int++));
  CC_L_for_radiative_capture_cross_section = T_int(i_int++);
  E_relative_max_hw_pole_approximation = T_int(i_int++);
  E_max_hw_pole_approximation = T_int(i_int++);
  Hamiltonian_storage = static_cast<enum storage_type> (T_int(i_int++));
  M_TBMEs_storage = static_cast<enum storage_type> (T_int(i_int++));
  one_jumps_pn_two_jumps_cv_storage = static_cast<enum storage_type> (T_int(i_int++));
  //80
  CC_EM_for_radiative_capture_cross_section = static_cast<enum EM_type> (T_int(i_int++));
  E_CM_HO_max = T_int(i_int++);
  RDM_matrix_constraint = static_cast<enum RDM_matrix_constraint_type> (T_int(i_int++));
  Jmin_global_pp_opp = T_int(i_int++);
  Jmax_global_pp_opp = T_int(i_int++);
  Jmin_global_nn_opp = T_int(i_int++);
  Jmax_global_nn_opp = T_int(i_int++);
  Jmin_global_pn_opp = T_int(i_int++);
  Jmax_global_pn_opp = T_int(i_int++);
  Jmin_global_pp_opp_basis = T_int(i_int++);
  //90
  Jmax_global_pp_opp_basis = T_int(i_int++);
  Jmin_global_nn_opp_basis = T_int(i_int++);
  Jmax_global_nn_opp_basis = T_int(i_int++);
  Jmin_global_pn_opp_basis = T_int(i_int++);
  Jmax_global_pn_opp_basis = T_int(i_int++);
  relative_cluster = static_cast<enum particle_type> (T_int(i_int++)); 
  strangeness_min_global_pp = T_int(i_int++); 
  strangeness_max_global_pp = T_int(i_int++); 
  strangeness_min_global_nn = T_int(i_int++); 
  strangeness_max_global_nn = T_int(i_int++);
  //100
  strangeness_min_global_pn = T_int(i_int++); 
  strangeness_max_global_pn = T_int(i_int++);
  hypernucleus_strangeness = T_int(i_int++);
  lmax_common_p = T_int(i_int++);
  lmax_common_n = T_int(i_int++);
  //105

  if (i_int != dimension_int)
    error_message_print_abort ("i_int=" + make_string<unsigned int> (i_int) + " != dimension_int=" + make_string<unsigned int> (dimension_int) + " in input_data_str::put_int_constants.");
}









unsigned int input_data_str::get_dimension_bool_constants () const
{
  return 88;
}

void input_data_str::get_bool_constants (class array<bool> &T_bool) const
{
  const unsigned int dimension_bool = T_bool.dimension (0);

  unsigned int i_bool = 0;

  T_bool(i_bool++) = only_dimensions;
  T_bool(i_bool++) = non_zero_NBMEs_proportion_only;
  T_bool(i_bool++) = copy_J_OBMEs_TBMEs;
  T_bool(i_bool++) = initial_pivot_from_file;
  T_bool(i_bool++) = full_common_vectors_used_in_file;
  T_bool(i_bool++) = is_Coulomb_Hamiltonian_here;
  T_bool(i_bool++) = is_Coulomb_to_be_added;
  T_bool(i_bool++) = good_isospin_basis_potential;
  T_bool(i_bool++) = all_states_calculated;
  T_bool(i_bool++) = is_correlation_density_theta_value_imposed;
  //10  
  T_bool(i_bool++) = truncation_hw;
  T_bool(i_bool++) = truncation_ph;
  T_bool(i_bool++) = is_it_Lanczos;
  T_bool(i_bool++) = is_it_Lowdin;
  T_bool(i_bool++) = OBMEs_inter_read;
  T_bool(i_bool++) = is_it_cluster_CM_HO_basis_calculation;
  T_bool(i_bool++) = are_natural_orbitals_calculated_every_iteration;		
  T_bool(i_bool++) = are_there_EM_transitions;
  T_bool(i_bool++) = are_there_EM_transitions_strength;
  T_bool(i_bool++) = are_there_beta_transitions;
  //20
  T_bool(i_bool++) = are_there_beta_transitions_strength;
  T_bool(i_bool++) = are_there_densities;
  T_bool(i_bool++) = are_there_correlation_densities;
  T_bool(i_bool++) = are_there_spectroscopic_factors;
  T_bool(i_bool++) = are_there_overlap_functions;
  T_bool(i_bool++) = are_there_rms_radii;
  T_bool(i_bool++) = are_there_rms_radius_one_body_strengths;
  T_bool(i_bool++) = are_there_Hamiltonian_parts;
  T_bool(i_bool++) = are_there_Coulomb_isospin_mixtures;
  T_bool(i_bool++) = are_there_dagger_tilde_operators;
  //30  
  T_bool(i_bool++) = CC_are_GSM_a_dagger_vectors_calculated;
  T_bool(i_bool++) = print_detailed_information;
  T_bool(i_bool++) = is_cost_function_Hessian_matrix_calculated;
  T_bool(i_bool++) = are_there_hyperons;
  T_bool(i_bool++) = is_cv_possible;
  T_bool(i_bool++) = CC_is_it_longwavelength_approximation;
  T_bool(i_bool++) = CC_is_it_HO_expansion;
  T_bool(i_bool++) = is_R_charge_fitted;
  T_bool(i_bool++) = is_V0_ctr_ot_S1_T1_fitted;
  T_bool(i_bool++) = is_V0_ctr_et_S1_T0_fitted;
  //40
  T_bool(i_bool++) = is_V0_ctr_os_S0_T0_fitted;
  T_bool(i_bool++) = is_V0_ctr_es_S0_T1_fitted;
  T_bool(i_bool++) = is_V0_so_ot_S1_T1_fitted; 
  T_bool(i_bool++) = is_V0_so_et_S1_T0_fitted;
  T_bool(i_bool++) = is_V0_t_ot_S1_T1_fitted;
  T_bool(i_bool++) = is_V0_t_et_S1_T0_fitted;
  T_bool(i_bool++) = is_V0_ALS_fitted;
  T_bool(i_bool++) = is_VS_const_LO_T0_fitted;
  T_bool(i_bool++) = is_VS_const_LO_T1_fitted;
  T_bool(i_bool++) = is_VT_sigma_product_LO_T0_fitted;
  //50
  T_bool(i_bool++) = is_VT_sigma_product_LO_T1_fitted;
  T_bool(i_bool++) = is_V1_q2_NLO_fitted;
  T_bool(i_bool++) = is_V2_k2_NLO_fitted;
  T_bool(i_bool++) = is_V3_q2_sigma_product_NLO_fitted;  
  T_bool(i_bool++) = is_V4_k2_sigma_product_NLO_fitted;
  T_bool(i_bool++) = is_V5_sigma_q_vector_k_NLO_fitted;
  T_bool(i_bool++) = is_V6_sigma_q_product_NLO_fitted;
  T_bool(i_bool++) = is_V7_sigma_k_product_NLO_fitted; 
  T_bool(i_bool++) = is_V8_sigma_q_vector_k_NLO_fitted;
  T_bool(i_bool++) = is_V8a_SU3f_fitted;
  //60
  T_bool(i_bool++) = is_V8s_SU3f_fitted;
  T_bool(i_bool++) = is_V10_SU3f_fitted;
  T_bool(i_bool++) = is_V1_SU3f_fitted;
  T_bool(i_bool++) = T2_CM_operators_calculated; 
  T_bool(i_bool++) = J_projected;
  T_bool(i_bool++) = are_two_body_clusters_stored_in_J_scheme;
  T_bool(i_bool++) = is_hole_double_counting_suppressed;
  T_bool(i_bool++) = are_GSM_vectors_stored_on_disk;
  T_bool(i_bool++) = are_configuration_probabilities_printed; 
  T_bool(i_bool++) = are_scattering_configuration_probabilities_printed;
  //70
  T_bool(i_bool++) = is_there_effective_range_expansion;
  T_bool(i_bool++) = M_equal_J_imposed_in_GSM_vectors;
  T_bool(i_bool++) = is_there_disk_storage_eigenvectors_all_M;
  T_bool(i_bool++) = is_it_fixed_relative_SVD_precision;	
  T_bool(i_bool++) = are_there_GSM_multipoles;	
  T_bool(i_bool++) = are_there_EM_transitions;
  T_bool(i_bool++) = RDM_is_it_BiCG;
  T_bool(i_bool++) = RDM_are_there_J_constraints;
  T_bool(i_bool++) = RDM_is_there_E_reference;
  T_bool(i_bool++) = RDM_is_there_CM_correction;
  //80
  T_bool(i_bool++) = RDM_is_there_isospin_constraint;
  T_bool(i_bool++) = RDM_Gamma_init_from_file;
  T_bool(i_bool++) = binding_energies_fitted;
  T_bool(i_bool++) = are_there_pair_densities;
  T_bool(i_bool++) = are_there_basis_natural_orbitals_p;
  T_bool(i_bool++) = are_there_basis_natural_orbitals_n;
  T_bool(i_bool++) = are_there_new_natural_orbitals_p;
  T_bool(i_bool++) = are_there_new_natural_orbitals_n;
  //88
  
  if (i_bool != dimension_bool)
    error_message_print_abort ("i_bool=" + make_string<unsigned int> (i_bool) + " != dimension_bool=" + make_string<unsigned int> (dimension_bool) + " in input_data_str::get_bool_constants.");
}





void input_data_str::put_bool_constants (class array<bool> &T_bool)
{	
  const unsigned int dimension_bool = T_bool.dimension (0);

  unsigned int i_bool = 0;
  
  only_dimensions = T_bool(i_bool++);
  non_zero_NBMEs_proportion_only = T_bool(i_bool++);
  copy_J_OBMEs_TBMEs = T_bool(i_bool++);
  initial_pivot_from_file = T_bool(i_bool++);
  full_common_vectors_used_in_file = T_bool(i_bool++);
  is_Coulomb_Hamiltonian_here = T_bool(i_bool++);
  is_Coulomb_to_be_added = T_bool(i_bool++);
  good_isospin_basis_potential = T_bool(i_bool++);
  all_states_calculated = T_bool(i_bool++);
  is_correlation_density_theta_value_imposed = T_bool(i_bool++);
  //10  
  truncation_hw = T_bool(i_bool++);
  truncation_ph = T_bool(i_bool++);
  is_it_Lanczos = T_bool(i_bool++);
  is_it_Lowdin = T_bool(i_bool++);
  OBMEs_inter_read = T_bool(i_bool++);
  is_it_cluster_CM_HO_basis_calculation = T_bool(i_bool++);
  are_natural_orbitals_calculated_every_iteration = T_bool(i_bool++);		
  are_there_EM_transitions = T_bool(i_bool++);
  are_there_EM_transitions_strength = T_bool(i_bool++);
  are_there_beta_transitions = T_bool(i_bool++);
  //20
  are_there_beta_transitions_strength = T_bool(i_bool++);
  are_there_densities = T_bool(i_bool++);
  are_there_correlation_densities = T_bool(i_bool++);
  are_there_spectroscopic_factors = T_bool(i_bool++);
  are_there_overlap_functions = T_bool(i_bool++);
  are_there_rms_radii = T_bool(i_bool++);
  are_there_rms_radius_one_body_strengths = T_bool(i_bool++);
  are_there_Hamiltonian_parts = T_bool(i_bool++);
  are_there_Coulomb_isospin_mixtures = T_bool(i_bool++);
  are_there_dagger_tilde_operators = T_bool(i_bool++);
  //30  
  CC_are_GSM_a_dagger_vectors_calculated = T_bool(i_bool++);
  print_detailed_information = T_bool(i_bool++);
  is_cost_function_Hessian_matrix_calculated = T_bool(i_bool++);
  are_there_hyperons = T_bool(i_bool++);
  is_cv_possible = T_bool(i_bool++);
  CC_is_it_longwavelength_approximation = T_bool(i_bool++);
  CC_is_it_HO_expansion = T_bool(i_bool++);
  is_R_charge_fitted = T_bool(i_bool++);
  is_V0_ctr_ot_S1_T1_fitted = T_bool(i_bool++);
  is_V0_ctr_et_S1_T0_fitted = T_bool(i_bool++);
  //40
  is_V0_ctr_os_S0_T0_fitted = T_bool(i_bool++);
  is_V0_ctr_es_S0_T1_fitted = T_bool(i_bool++);
  is_V0_so_ot_S1_T1_fitted = T_bool(i_bool++); 
  is_V0_so_et_S1_T0_fitted = T_bool(i_bool++);
  is_V0_t_ot_S1_T1_fitted = T_bool(i_bool++);
  is_V0_t_et_S1_T0_fitted = T_bool(i_bool++);
  is_V0_ALS_fitted = T_bool(i_bool++);
  is_VS_const_LO_T0_fitted = T_bool(i_bool++);
  is_VS_const_LO_T1_fitted = T_bool(i_bool++);
  is_VT_sigma_product_LO_T0_fitted = T_bool(i_bool++);
  //50
  is_VT_sigma_product_LO_T1_fitted = T_bool(i_bool++);
  is_V1_q2_NLO_fitted = T_bool(i_bool++);
  is_V2_k2_NLO_fitted = T_bool(i_bool++);
  is_V3_q2_sigma_product_NLO_fitted = T_bool(i_bool++);  
  is_V4_k2_sigma_product_NLO_fitted = T_bool(i_bool++);
  is_V5_sigma_q_vector_k_NLO_fitted = T_bool(i_bool++);
  is_V6_sigma_q_product_NLO_fitted = T_bool(i_bool++);
  is_V7_sigma_k_product_NLO_fitted = T_bool(i_bool++); 
  is_V8_sigma_q_vector_k_NLO_fitted = T_bool(i_bool++);
  is_V8a_SU3f_fitted = T_bool(i_bool++);
  //60
  is_V8s_SU3f_fitted = T_bool(i_bool++);
  is_V10_SU3f_fitted = T_bool(i_bool++);
  is_V1_SU3f_fitted = T_bool(i_bool++);
  T2_CM_operators_calculated = T_bool(i_bool++); 
  J_projected = T_bool(i_bool++);
  are_two_body_clusters_stored_in_J_scheme = T_bool(i_bool++);
  is_hole_double_counting_suppressed = T_bool(i_bool++);
  are_GSM_vectors_stored_on_disk = T_bool(i_bool++);
  are_configuration_probabilities_printed = T_bool(i_bool++); 
  are_scattering_configuration_probabilities_printed = T_bool(i_bool++);
  //70
  is_there_effective_range_expansion = T_bool(i_bool++);
  M_equal_J_imposed_in_GSM_vectors = T_bool(i_bool++);
  is_there_disk_storage_eigenvectors_all_M = T_bool(i_bool++);
  is_it_fixed_relative_SVD_precision = T_bool(i_bool++);	
  are_there_GSM_multipoles = T_bool(i_bool++);	
  are_there_EM_transitions = T_bool(i_bool++);
  RDM_is_it_BiCG = T_bool(i_bool++);
  RDM_are_there_J_constraints = T_bool(i_bool++);
  RDM_is_there_E_reference = T_bool(i_bool++);
  RDM_is_there_CM_correction = T_bool(i_bool++);
  //80
  RDM_is_there_isospin_constraint = T_bool(i_bool++);
  RDM_Gamma_init_from_file = T_bool(i_bool++);
  binding_energies_fitted = T_bool(i_bool++);
  are_there_pair_densities = T_bool(i_bool++);  
  are_there_basis_natural_orbitals_p = T_bool(i_bool++);  
  are_there_basis_natural_orbitals_n = T_bool(i_bool++);  
  are_there_new_natural_orbitals_p = T_bool(i_bool++);  
  are_there_new_natural_orbitals_n = T_bool(i_bool++);  
  //88
  
  if (i_bool != dimension_bool)
    error_message_print_abort ("i_bool=" + make_string<unsigned int> (i_bool) + " != dimension_bool=" + make_string<unsigned int> (dimension_bool) + " in input_data_str::put_bool_constants.");
}




unsigned int input_data_str::get_dimension_double_constants () const
{
  return 109;
}




void input_data_str::get_double_constants (class array<double> &T_double) const
{
  const unsigned int dimension_double = T_double.dimension (0);

  unsigned int i_double = 0;

  T_double(i_double++) = R;
  T_double(i_double++) = step_bef_R_uniform;
  T_double(i_double++) = R_real_max;
  T_double(i_double++) = R_cut_function;
  T_double(i_double++) = d_cut_function;
  T_double(i_double++) = Ueq_regularizor;
  T_double(i_double++) = lambda_Hcm;
  T_double(i_double++) = R_charge;  
  T_double(i_double++) = frozen_core_mass;
  T_double(i_double++) = correlation_density_imposed_theta_value;
  //10
  T_double(i_double++) = nucleus_mass;
  T_double(i_double++) = nucleus_mass_basis;
  T_double(i_double++) = configuration_precision;
  T_double(i_double++) = test_vector_solution;
  T_double(i_double++) = Newton_precision;
  T_double(i_double++) = relative_SVD_precision;
  T_double(i_double++) = R0_inter_basis;
  T_double(i_double++) = mu_basis;
  T_double(i_double++) = a_basis;
  T_double(i_double++) = b_basis;
  //20
  T_double(i_double++) = V_SDI_basis;
  T_double(i_double++) = b_lab_basis;
  T_double(i_double++) = R0_inter;
  T_double(i_double++) = mu;
  T_double(i_double++) = a;
  T_double(i_double++) = b;
  T_double(i_double++) = V_SDI;
  T_double(i_double++) = b_lab;
  T_double(i_double++) = A_dependence_alpha_core_potential;
  T_double(i_double++) = A_dependence_exponent;
  //30
  T_double(i_double++) = u_Minnesota_basis;
  T_double(i_double++) = nu_three_body_like_basis;
  T_double(i_double++) = V_three_body_like_basis;
  T_double(i_double++) = V0_ctr_ot_basis;
  T_double(i_double++) = V0_ctr_et_basis;
  T_double(i_double++) = V0_ctr_os_basis;
  T_double(i_double++) = V0_ctr_es_basis;
  T_double(i_double++) = V0_so_ot_basis;
  T_double(i_double++) = V0_so_et_basis;
  T_double(i_double++) = V0_t_ot_basis;
  //40
  T_double(i_double++) = V0_t_et_basis;
  T_double(i_double++) = V0_ALS_basis;
  T_double(i_double++) = VS_const_LO_T0_basis;
  T_double(i_double++) = VS_const_LO_T1_basis;
  T_double(i_double++) = VT_sigma_product_LO_T0_basis;
  T_double(i_double++) = VT_sigma_product_LO_T1_basis;
  T_double(i_double++) = V1_q2_NLO_basis;
  T_double(i_double++) = V2_k2_NLO_basis;
  T_double(i_double++) = V3_q2_sigma_product_NLO_basis;
  T_double(i_double++) = V4_k2_sigma_product_NLO_basis;
  //50
  T_double(i_double++) = V5_sigma_q_vector_k_NLO_basis;
  T_double(i_double++) = V6_sigma_q_product_NLO_basis;
  T_double(i_double++) = V7_sigma_k_product_NLO_basis;
  T_double(i_double++) = V8_sigma_q_vector_k_NLO_basis;
  T_double(i_double++) = V8a_SU3f_basis;
  T_double(i_double++) = V8s_SU3f_basis;
  T_double(i_double++) = V10_SU3f_basis;
  T_double(i_double++) = V1_SU3f_basis;
  T_double(i_double++) = u_Minnesota;
  T_double(i_double++) = nu_three_body_like;
  //60
  T_double(i_double++) = V_three_body_like;
  T_double(i_double++) = V0_ctr_ot;
  T_double(i_double++) = V0_ctr_et;
  T_double(i_double++) = V0_ctr_os;
  T_double(i_double++) = V0_ctr_es;
  T_double(i_double++) = V0_so_ot;
  T_double(i_double++) = V0_so_et;
  T_double(i_double++) = V0_t_ot;
  T_double(i_double++) = V0_t_et;
  T_double(i_double++) = V0_ALS;
  //70
  T_double(i_double++) = VS_const_LO_T0;
  T_double(i_double++) = VS_const_LO_T1;
  T_double(i_double++) = VT_sigma_product_LO_T0;
  T_double(i_double++) = VT_sigma_product_LO_T1;
  T_double(i_double++) = V1_q2_NLO;
  T_double(i_double++) = V2_k2_NLO;
  T_double(i_double++) = V3_q2_sigma_product_NLO;
  T_double(i_double++) = V4_k2_sigma_product_NLO;
  T_double(i_double++) = V5_sigma_q_vector_k_NLO;
  T_double(i_double++) = V6_sigma_q_product_NLO;
  //80
  T_double(i_double++) = V7_sigma_k_product_NLO;
  T_double(i_double++) = V8_sigma_q_vector_k_NLO;
  T_double(i_double++) = V8a_SU3f;
  T_double(i_double++) = V8s_SU3f;
  T_double(i_double++) = V10_SU3f;
  T_double(i_double++) = V1_SU3f;
  T_double(i_double++) = jp_max;
  T_double(i_double++) = jn_max;
  T_double(i_double++) = mp_max;
  T_double(i_double++) = mn_max;
  //90  
  T_double(i_double++) = mp_min;
  T_double(i_double++) = mn_min;
  T_double(i_double++) = HF_precision; 
  T_double(i_double++) = CC_E_kinetic_total_system_CM_start;
  T_double(i_double++) = CC_E_kinetic_total_system_CM_end;
  T_double(i_double++) = CC_Davidson_eigenvector_precision;
  T_double(i_double++) = CC_relative_SVD_precision;
  T_double(i_double++) = CC_forbidden_channel_precision;
  T_double(i_double++) = kmax_momentum;
  T_double(i_double++) = R_Fermi_momentum;
  //100
  T_double(i_double++) = step_momentum_uniform;
  T_double(i_double++) = RDM_E_minimization_precision;
  T_double(i_double++) = RDM_sigma_init;
  T_double(i_double++) = RDM_multiplicative_sigma_step;	
  T_double(i_double++) = RDM_smallness_factor;
  T_double(i_double++) = RDM_J;
  T_double(i_double++) = RDM_E_reference;
  T_double(i_double++) = RDM_Hamiltonian_renormalization_factor;
  T_double(i_double++) = total_nucleus_mass;
  //109

  if (i_double != dimension_double)
    error_message_print_abort ("i_double=" + make_string<unsigned int> (i_double) + " != dimension_double=" + make_string<unsigned int> (dimension_double) + " in input_data_str::get_double_constants.");
}





void input_data_str::put_double_constants (class array<double> &T_double)
{
  const unsigned int dimension_double = T_double.dimension (0);

  unsigned int i_double = 0;
  
  R = T_double(i_double++);
  step_bef_R_uniform = T_double(i_double++);
  R_real_max = T_double(i_double++);
  R_cut_function = T_double(i_double++);
  d_cut_function = T_double(i_double++);
  Ueq_regularizor = T_double(i_double++);
  lambda_Hcm = T_double(i_double++);
  R_charge = T_double(i_double++);  
  frozen_core_mass = T_double(i_double++);
  correlation_density_imposed_theta_value = T_double(i_double++);
  //10
  nucleus_mass = T_double(i_double++);
  nucleus_mass_basis = T_double(i_double++);
  configuration_precision = T_double(i_double++);
  test_vector_solution = T_double(i_double++);
  Newton_precision = T_double(i_double++);
  relative_SVD_precision = T_double(i_double++);
  R0_inter_basis = T_double(i_double++);
  mu_basis = T_double(i_double++);
  a_basis = T_double(i_double++);
  b_basis = T_double(i_double++);
  //20
  V_SDI_basis = T_double(i_double++);
  b_lab_basis = T_double(i_double++);
  R0_inter = T_double(i_double++);
  mu = T_double(i_double++);
  a = T_double(i_double++);
  b = T_double(i_double++);
  V_SDI = T_double(i_double++);
  b_lab = T_double(i_double++);
  A_dependence_alpha_core_potential = T_double(i_double++);
  A_dependence_exponent = T_double(i_double++);
  //30
  u_Minnesota_basis = T_double(i_double++);
  nu_three_body_like_basis = T_double(i_double++);
  V_three_body_like_basis = T_double(i_double++);
  V0_ctr_ot_basis = T_double(i_double++);
  V0_ctr_et_basis = T_double(i_double++);
  V0_ctr_os_basis = T_double(i_double++);
  V0_ctr_es_basis = T_double(i_double++);
  V0_so_ot_basis = T_double(i_double++);
  V0_so_et_basis = T_double(i_double++);
  V0_t_ot_basis = T_double(i_double++);
  //40
  V0_t_et_basis = T_double(i_double++);
  V0_ALS_basis = T_double(i_double++);
  VS_const_LO_T0_basis = T_double(i_double++);
  VS_const_LO_T1_basis = T_double(i_double++);
  VT_sigma_product_LO_T0_basis = T_double(i_double++);
  VT_sigma_product_LO_T1_basis = T_double(i_double++);
  V1_q2_NLO_basis = T_double(i_double++);
  V2_k2_NLO_basis = T_double(i_double++);
  V3_q2_sigma_product_NLO_basis = T_double(i_double++);
  V4_k2_sigma_product_NLO_basis = T_double(i_double++);
  //50
  V5_sigma_q_vector_k_NLO_basis = T_double(i_double++);
  V6_sigma_q_product_NLO_basis = T_double(i_double++);
  V7_sigma_k_product_NLO_basis = T_double(i_double++);
  V8_sigma_q_vector_k_NLO_basis = T_double(i_double++);
  V8a_SU3f_basis = T_double(i_double++);
  V8s_SU3f_basis = T_double(i_double++);
  V10_SU3f_basis = T_double(i_double++);
  V1_SU3f_basis = T_double(i_double++);
  u_Minnesota = T_double(i_double++);
  nu_three_body_like = T_double(i_double++);
  //60
  V_three_body_like = T_double(i_double++);
  V0_ctr_ot = T_double(i_double++);
  V0_ctr_et = T_double(i_double++);
  V0_ctr_os = T_double(i_double++);
  V0_ctr_es = T_double(i_double++);
  V0_so_ot = T_double(i_double++);
  V0_so_et = T_double(i_double++);
  V0_t_ot = T_double(i_double++);
  V0_t_et = T_double(i_double++);
  V0_ALS = T_double(i_double++);
  //70
  VS_const_LO_T0 = T_double(i_double++);
  VS_const_LO_T1 = T_double(i_double++);
  VT_sigma_product_LO_T0 = T_double(i_double++);
  VT_sigma_product_LO_T1 = T_double(i_double++);
  V1_q2_NLO = T_double(i_double++);
  V2_k2_NLO = T_double(i_double++);
  V3_q2_sigma_product_NLO = T_double(i_double++);
  V4_k2_sigma_product_NLO = T_double(i_double++);
  V5_sigma_q_vector_k_NLO = T_double(i_double++);
  V6_sigma_q_product_NLO = T_double(i_double++);
  //80
  V7_sigma_k_product_NLO = T_double(i_double++);
  V8_sigma_q_vector_k_NLO = T_double(i_double++);
  V8a_SU3f = T_double(i_double++);
  V8s_SU3f = T_double(i_double++);
  V10_SU3f = T_double(i_double++);
  V1_SU3f = T_double(i_double++);
  jp_max = T_double(i_double++);
  jn_max = T_double(i_double++);
  mp_max = T_double(i_double++);
  mn_max = T_double(i_double++);
  //90  
  mp_min = T_double(i_double++);
  mn_min = T_double(i_double++);
  HF_precision = T_double(i_double++); 
  CC_E_kinetic_total_system_CM_start = T_double(i_double++);
  CC_E_kinetic_total_system_CM_end = T_double(i_double++);
  CC_Davidson_eigenvector_precision = T_double(i_double++);
  CC_relative_SVD_precision = T_double(i_double++);
  CC_forbidden_channel_precision = T_double(i_double++);
  kmax_momentum = T_double(i_double++);
  R_Fermi_momentum = T_double(i_double++);
  //100
  step_momentum_uniform = T_double(i_double++);
  RDM_E_minimization_precision = T_double(i_double++);
  RDM_sigma_init = T_double(i_double++);
  RDM_multiplicative_sigma_step = T_double(i_double++);	
  RDM_smallness_factor = T_double(i_double++);
  RDM_J = T_double(i_double++);
  RDM_E_reference = T_double(i_double++);
  RDM_Hamiltonian_renormalization_factor = T_double(i_double++);
  total_nucleus_mass = T_double(i_double++);
  //109

  if (i_double != dimension_double)
    error_message_print_abort ("i_double=" + make_string<unsigned int> (i_double) + " != dimension_double=" + make_string<unsigned int> (dimension_double) + " in input_data_str::put_double_constants.");
}









unsigned int input_data_str::dimension_unsigned_int_tabs_calc () const
{
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);
      
  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
  
  const unsigned int CC_Lmax_all_plus_one = CC_Lmax_all + 1;
  
  const unsigned int dimension_unsigned_int = 2*natural_orbitals_reference_states_number
    + 2*lmax_p + 1
    + 2*lmax_n + 1
    + 2*eigensets_number
    + 2*GSM_multipoles_number
    + 4*EM_transitions_number
    + 4*EM_transitions_strength_number 
    + 4*beta_transitions_number
    + 4*beta_transitions_strength_number
    + 2*density_number
    + 2*correlation_density_number
    + 2*pair_density_number
    + 6*spectroscopic_factor_number
    + 6*overlap_function_number
    + 2*rms_radius_number
    + 2*rms_radius_one_body_strength_number
    + 2*Hamiltonian_parts_eigenstates_number
    + 2*Coulomb_isospin_mixture_number
    + 4*dagger_tilde_operators_number
    + 3*CC_N_target_projectile_states
    + 2*CC_N_JPi_A_composite
    + CC_N_JPi_A_in_composite
    + 2*CC_N_JPi_A_out_composite 
    + CC_average_n_scat_target_projectile_max_composite_number
    + CC_corrective_factors_TBMEs_composite_number
    + CC_cluster_projectile_number*(CC_corrective_factors_cluster_composite_numbers_max + 1 + 4*CC_Lmax_all_plus_one*CC_J_number_max_all)
    + 4*Np_baryon_type
    + 4*Nn_baryon_type;

  return dimension_unsigned_int;
}






void input_data_str::get_unsigned_int_tables (class array<unsigned int> &T_unsigned_int) const
{    
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);
      
  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
  
  const unsigned int dimension_unsigned_int = T_unsigned_int.dimension (0);

  unsigned int i_unsigned_int = 0;

  for (unsigned int i = 0 ; i < natural_orbitals_reference_states_number ; i++)
    {
      T_unsigned_int(i_unsigned_int++) = natural_orbitals_reference_states_BP_tab(i); 
      T_unsigned_int(i_unsigned_int++) = natural_orbitals_reference_states_vector_index_tab(i);
    }

  for (int l = 0 ; l <= lmax_p ; l++)
    for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      T_unsigned_int(i_unsigned_int++) = prot_basis_BP_tab(l , j); 

  for (int l = 0 ; l <= lmax_n ; l++)
    for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      T_unsigned_int(i_unsigned_int++) = neut_basis_BP_tab(l , j); 
  
  for (unsigned int i = 0 ; i < eigensets_number ; i++)
    {
      T_unsigned_int(i_unsigned_int++) = BP_eigenset_tab(i);
      T_unsigned_int(i_unsigned_int++) = eigenset_vectors_number_tab(i);
    }

  for (unsigned int i = 0 ; i < GSM_multipoles_number ; i++) 
    {
      T_unsigned_int(i_unsigned_int++) = GSM_multipoles_BP_tab(i);
      T_unsigned_int(i_unsigned_int++) = GSM_multipoles_vector_index_tab(i);
    }

  for (unsigned int i = 0 ; i < EM_transitions_number ; i++) 
    {
      T_unsigned_int(i_unsigned_int++) = EM_BP_IN_tab(i); 
      T_unsigned_int(i_unsigned_int++) = EM_BP_OUT_tab(i);
      T_unsigned_int(i_unsigned_int++) = EM_vector_index_IN_tab(i); 
      T_unsigned_int(i_unsigned_int++) = EM_vector_index_OUT_tab(i);
    }

  for (unsigned int i = 0 ; i < EM_transitions_strength_number ; i++) 
    {
      T_unsigned_int(i_unsigned_int++) = EM_strength_BP_IN_tab(i); 
      T_unsigned_int(i_unsigned_int++) = EM_strength_BP_OUT_tab(i);
      T_unsigned_int(i_unsigned_int++) = EM_strength_vector_index_IN_tab(i); 
      T_unsigned_int(i_unsigned_int++) = EM_strength_vector_index_OUT_tab(i);
    }

  for (unsigned int i = 0 ; i < beta_transitions_number ; i++) 
    {
      T_unsigned_int(i_unsigned_int++) = beta_BP_IN_tab(i); 
      T_unsigned_int(i_unsigned_int++) = beta_BP_OUT_tab(i);
      T_unsigned_int(i_unsigned_int++) = beta_vector_index_IN_tab(i); 
      T_unsigned_int(i_unsigned_int++) = beta_vector_index_OUT_tab(i);
    }

  for (unsigned int i = 0 ; i < beta_transitions_strength_number ; i++) 
    {
      T_unsigned_int(i_unsigned_int++) = beta_strength_BP_IN_tab(i); 
      T_unsigned_int(i_unsigned_int++) = beta_strength_BP_OUT_tab(i);
      T_unsigned_int(i_unsigned_int++) = beta_strength_vector_index_IN_tab(i); 
      T_unsigned_int(i_unsigned_int++) = beta_strength_vector_index_OUT_tab(i);
    }

  for (unsigned int i = 0 ; i < density_number ; i++) 
    {
      T_unsigned_int(i_unsigned_int++) = density_BP_tab(i); 
      T_unsigned_int(i_unsigned_int++) = density_vector_index_tab(i);
    }

  for (unsigned int i = 0 ; i < correlation_density_number ; i++) 
    {
      T_unsigned_int(i_unsigned_int++) = correlation_density_BP_tab(i); 
      T_unsigned_int(i_unsigned_int++) = correlation_density_vector_index_tab(i);
    }

  for (unsigned int i = 0 ; i < pair_density_number ; i++) 
    {
      T_unsigned_int(i_unsigned_int++) = pair_density_BP_tab(i); 
      T_unsigned_int(i_unsigned_int++) = pair_density_vector_index_tab(i);
    }
  
  for (unsigned int i = 0 ; i < spectroscopic_factor_number ; i++) 
    {
      T_unsigned_int(i_unsigned_int++) = spectroscopic_factor_BP_IN_tab(i); 
      T_unsigned_int(i_unsigned_int++) = spectroscopic_factor_BP_OUT_tab(i);
      T_unsigned_int(i_unsigned_int++) = spectroscopic_factor_vector_index_IN_tab(i); 
      T_unsigned_int(i_unsigned_int++) = spectroscopic_factor_vector_index_OUT_tab(i);
      T_unsigned_int(i_unsigned_int++) = spectroscopic_factor_BP_projectile_tab(i);
      T_unsigned_int(i_unsigned_int++) = spectroscopic_factor_vector_index_projectile_tab(i);
    }

  for (unsigned int i = 0 ; i < overlap_function_number ; i++) 
    {
      T_unsigned_int(i_unsigned_int++) = overlap_function_BP_IN_tab(i); 
      T_unsigned_int(i_unsigned_int++) = overlap_function_BP_OUT_tab(i);
      T_unsigned_int(i_unsigned_int++) = overlap_function_vector_index_IN_tab(i); 
      T_unsigned_int(i_unsigned_int++) = overlap_function_vector_index_OUT_tab(i);
      T_unsigned_int(i_unsigned_int++) = overlap_function_BP_projectile_tab(i);
      T_unsigned_int(i_unsigned_int++) = overlap_function_vector_index_projectile_tab(i);
    }

  for (unsigned int i = 0 ; i < rms_radius_number ; i++) 
    {
      T_unsigned_int(i_unsigned_int++) = rms_radius_BP_tab(i); 
      T_unsigned_int(i_unsigned_int++) = rms_radius_vector_index_tab(i);
    }

  for (unsigned int i = 0 ; i < rms_radius_one_body_strength_number ; i++) 
    {
      T_unsigned_int(i_unsigned_int++) = rms_radius_one_body_strength_BP_tab(i); 
      T_unsigned_int(i_unsigned_int++) = rms_radius_one_body_strength_vector_index_tab(i);
    }

  for (unsigned int i = 0 ; i < Hamiltonian_parts_eigenstates_number ; i++) 
    {
      T_unsigned_int(i_unsigned_int++) = Hamiltonian_parts_BP_tab(i); 
      T_unsigned_int(i_unsigned_int++) = Hamiltonian_parts_vector_index_tab(i);
    }

  for (unsigned int i = 0 ; i < Coulomb_isospin_mixture_number ; i++) 
    {
      T_unsigned_int(i_unsigned_int++) = Coulomb_isospin_mixture_BP_tab(i); 
      T_unsigned_int(i_unsigned_int++) = Coulomb_isospin_mixture_vector_index_tab(i); 
    }

  for (unsigned int i = 0 ; i < dagger_tilde_operators_number ; i++) 
    {
      T_unsigned_int(i_unsigned_int++) = dagger_tilde_operators_BP_IN_tab(i); 
      T_unsigned_int(i_unsigned_int++) = dagger_tilde_operators_BP_OUT_tab(i);
      T_unsigned_int(i_unsigned_int++) = dagger_tilde_operators_vector_index_IN_tab(i); 
      T_unsigned_int(i_unsigned_int++) = dagger_tilde_operators_vector_index_OUT_tab(i);
    }

  for (unsigned int i = 0 ; i < CC_N_target_projectile_states ; i++)
    {
      T_unsigned_int(i_unsigned_int++) = CC_BP_target_tab(i); 
      T_unsigned_int(i_unsigned_int++) = CC_vector_index_target_tab(i); 
      T_unsigned_int(i_unsigned_int++) = CC_N_partial_waves_tab(i);
    }

  for (unsigned int i = 0 ; i < CC_N_JPi_A_composite ; i++)
    {
      T_unsigned_int(i_unsigned_int++) = CC_BP_A_composite_tab(i);
      T_unsigned_int(i_unsigned_int++) = CC_vector_index_A_composite_tab(i);
    }

  for (unsigned int i = 0 ; i < CC_N_JPi_A_in_composite ; i++)
    T_unsigned_int(i_unsigned_int++) = CC_BP_A_in_composite_tab(i);

  for (unsigned int i = 0 ; i < CC_N_JPi_A_out_composite ; i++)
    {
      T_unsigned_int(i_unsigned_int++) = CC_BP_A_out_composite_tab(i);
      T_unsigned_int(i_unsigned_int++) = CC_vector_index_A_out_composite_tab(i);
    }

  for (unsigned int i = 0 ; i < CC_average_n_scat_target_projectile_max_composite_number ; i++)
    T_unsigned_int(i_unsigned_int++) = CC_average_n_scat_target_projectile_max_BP_A_composite_tab(i);
  
  for (unsigned int i = 0 ; i < CC_corrective_factors_TBMEs_composite_number ; i++)
    T_unsigned_int(i_unsigned_int++) = CC_corrective_factors_TBMEs_BP_A_composite_tab(i);
    
  for (unsigned int ic = 0 ; ic < CC_cluster_projectile_number ; ic++)
    {
      T_unsigned_int(i_unsigned_int++) = CC_corrective_factors_cluster_composite_numbers(ic);
      
      for (unsigned int i = 0 ; i < CC_corrective_factors_cluster_composite_numbers_max ; i++)
	T_unsigned_int(i_unsigned_int++) = CC_corrective_factors_cluster_BP_A_composite_tab(ic , i);
      
      for (int L = 0 ; L <= CC_Lmax_all ; L++)
	for (unsigned int J_index = 0 ; J_index < CC_J_number_max_all ; J_index++)
	  {
	    T_unsigned_int(i_unsigned_int++) = CC_N_poles_cluster_projectile_CM_tab    (ic , L , J_index); 
	    T_unsigned_int(i_unsigned_int++) = CC_N_K_peak_cluster_projectile_CM_tab   (ic , L , J_index);
	    T_unsigned_int(i_unsigned_int++) = CC_N_K_middle_cluster_projectile_CM_tab (ic , L , J_index); 
	    T_unsigned_int(i_unsigned_int++) = CC_N_K_max_cluster_projectile_CM_tab    (ic , L , J_index);
	  }
    }

  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    {
      T_unsigned_int(i_unsigned_int++) = Np_nlj_baryon_tab(i);
      T_unsigned_int(i_unsigned_int++) = Np_nlj_res_baryon_tab(i);
      T_unsigned_int(i_unsigned_int++) = Np_nljm_baryon_tab(i);
      T_unsigned_int(i_unsigned_int++) = Np_nljm_res_baryon_tab(i);
    }  

  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    {
      T_unsigned_int(i_unsigned_int++) = Nn_nlj_baryon_tab(i);
      T_unsigned_int(i_unsigned_int++) = Nn_nlj_res_baryon_tab(i);
      T_unsigned_int(i_unsigned_int++) = Nn_nljm_baryon_tab(i);
      T_unsigned_int(i_unsigned_int++) = Nn_nljm_res_baryon_tab(i);
    }  
	
  if (i_unsigned_int != dimension_unsigned_int)
    error_message_print_abort ("i_unsigned_int=" + make_string<unsigned int> (i_unsigned_int) + " != dimension_unsigned_int=" + make_string<unsigned int> (dimension_unsigned_int) + " in input_data_str::get_unsigned_int_tables.");
}






void input_data_str::alloc_unsigned_int_tables ()
{	
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);
      
  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
  
  const unsigned int CC_Lmax_all_plus_one = CC_Lmax_all + 1;
  
  natural_orbitals_reference_states_BP_tab.allocate (natural_orbitals_reference_states_number);
  natural_orbitals_reference_states_vector_index_tab.allocate (natural_orbitals_reference_states_number); 
  prot_basis_BP_tab.allocate (0.5 , lmax_p);
  neut_basis_BP_tab.allocate (0.5 , lmax_n);
  BP_eigenset_tab.allocate (eigensets_number);
  eigenset_vectors_number_tab.allocate (eigensets_number);  
  GSM_multipoles_BP_tab.allocate (GSM_multipoles_number);
  GSM_multipoles_vector_index_tab.allocate (GSM_multipoles_number);  
  EM_BP_IN_tab.allocate (EM_transitions_number);
  EM_BP_OUT_tab.allocate (EM_transitions_number);
  EM_vector_index_IN_tab.allocate (EM_transitions_number);
  EM_vector_index_OUT_tab.allocate (EM_transitions_number);  
  EM_strength_BP_IN_tab.allocate (EM_transitions_strength_number);
  EM_strength_BP_OUT_tab.allocate (EM_transitions_strength_number);
  EM_strength_vector_index_IN_tab.allocate (EM_transitions_strength_number);
  EM_strength_vector_index_OUT_tab.allocate (EM_transitions_strength_number);
  beta_BP_IN_tab.allocate (beta_transitions_number);
  beta_BP_OUT_tab.allocate (beta_transitions_number);
  beta_vector_index_IN_tab.allocate (beta_transitions_number);
  beta_vector_index_OUT_tab.allocate (beta_transitions_number);
  beta_strength_BP_IN_tab.allocate (beta_transitions_strength_number);
  beta_strength_BP_OUT_tab.allocate (beta_transitions_strength_number);
  beta_strength_vector_index_IN_tab.allocate (beta_transitions_strength_number);
  beta_strength_vector_index_OUT_tab .allocate (beta_transitions_strength_number);
  density_BP_tab.allocate (density_number);
  density_vector_index_tab.allocate (density_number);
  correlation_density_BP_tab.allocate (correlation_density_number);
  correlation_density_vector_index_tab.allocate (correlation_density_number);
  pair_density_BP_tab.allocate (pair_density_number);
  pair_density_vector_index_tab.allocate (pair_density_number);
  spectroscopic_factor_BP_IN_tab.allocate (spectroscopic_factor_number);
  spectroscopic_factor_BP_OUT_tab.allocate (spectroscopic_factor_number);
  spectroscopic_factor_vector_index_IN_tab.allocate (spectroscopic_factor_number);
  spectroscopic_factor_vector_index_OUT_tab.allocate (spectroscopic_factor_number);
  spectroscopic_factor_BP_projectile_tab.allocate (spectroscopic_factor_number);
  spectroscopic_factor_vector_index_projectile_tab.allocate (spectroscopic_factor_number);
  overlap_function_BP_IN_tab.allocate (overlap_function_number);
  overlap_function_BP_OUT_tab.allocate (overlap_function_number);
  overlap_function_vector_index_IN_tab.allocate (overlap_function_number);
  overlap_function_vector_index_OUT_tab.allocate (overlap_function_number);
  overlap_function_BP_projectile_tab.allocate (overlap_function_number);
  overlap_function_vector_index_projectile_tab.allocate (overlap_function_number);
  rms_radius_BP_tab.allocate (rms_radius_number);
  rms_radius_vector_index_tab.allocate (rms_radius_number);
  rms_radius_one_body_strength_BP_tab.allocate (rms_radius_one_body_strength_number);
  rms_radius_one_body_strength_vector_index_tab.allocate (rms_radius_one_body_strength_number);
  Hamiltonian_parts_BP_tab.allocate (Hamiltonian_parts_eigenstates_number);
  Hamiltonian_parts_vector_index_tab.allocate (Hamiltonian_parts_eigenstates_number);
  Coulomb_isospin_mixture_BP_tab.allocate (Coulomb_isospin_mixture_number);
  Coulomb_isospin_mixture_vector_index_tab.allocate (Coulomb_isospin_mixture_number);
  dagger_tilde_operators_BP_IN_tab.allocate (dagger_tilde_operators_number);
  dagger_tilde_operators_BP_OUT_tab.allocate (dagger_tilde_operators_number);
  dagger_tilde_operators_vector_index_IN_tab.allocate (dagger_tilde_operators_number);
  dagger_tilde_operators_vector_index_OUT_tab.allocate (dagger_tilde_operators_number);
  CC_BP_target_tab.allocate (CC_N_target_projectile_states); 
  CC_vector_index_target_tab.allocate (CC_N_target_projectile_states);
  CC_N_partial_waves_tab.allocate (CC_N_target_projectile_states);
  CC_BP_A_composite_tab.allocate (CC_N_JPi_A_composite);
  CC_vector_index_A_composite_tab.allocate (CC_N_JPi_A_composite);
  CC_BP_A_in_composite_tab.allocate (CC_N_JPi_A_in_composite);
  CC_BP_A_out_composite_tab.allocate (CC_N_JPi_A_out_composite);
  CC_vector_index_A_out_composite_tab.allocate (CC_N_JPi_A_out_composite);
  CC_average_n_scat_target_projectile_max_BP_A_composite_tab.allocate (CC_average_n_scat_target_projectile_max_composite_number); 
  CC_corrective_factors_TBMEs_BP_A_composite_tab.allocate (CC_corrective_factors_TBMEs_composite_number); 
  CC_corrective_factors_cluster_composite_numbers.allocate (CC_cluster_projectile_number); 
  CC_corrective_factors_cluster_BP_A_composite_tab.allocate (CC_cluster_projectile_number , CC_corrective_factors_cluster_composite_numbers_max); 
  CC_N_poles_cluster_projectile_CM_tab.allocate (CC_cluster_projectile_number , CC_Lmax_all_plus_one , CC_J_number_max_all);
  CC_N_K_peak_cluster_projectile_CM_tab.allocate (CC_cluster_projectile_number , CC_Lmax_all_plus_one , CC_J_number_max_all);
  CC_N_K_middle_cluster_projectile_CM_tab.allocate (CC_cluster_projectile_number , CC_Lmax_all_plus_one , CC_J_number_max_all);
  CC_N_K_max_cluster_projectile_CM_tab.allocate (CC_cluster_projectile_number , CC_Lmax_all_plus_one , CC_J_number_max_all);
  Np_nlj_baryon_tab.allocate (Np_baryon_type);
  Np_nlj_res_baryon_tab.allocate (Np_baryon_type);
  Np_nljm_baryon_tab.allocate (Np_baryon_type);
  Np_nljm_res_baryon_tab.allocate (Np_baryon_type);
  Nn_nlj_baryon_tab.allocate (Nn_baryon_type);
  Nn_nlj_res_baryon_tab.allocate (Nn_baryon_type);
  Nn_nljm_baryon_tab.allocate (Nn_baryon_type);
  Nn_nljm_res_baryon_tab.allocate (Nn_baryon_type);
}



void input_data_str::put_unsigned_int_tables (class array<unsigned int> &T_unsigned_int)
{
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);
      
  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
  
  const unsigned int dimension_unsigned_int = T_unsigned_int.dimension (0);

  unsigned int i_unsigned_int = 0;

  for (unsigned int i = 0 ; i < natural_orbitals_reference_states_number ; i++)
    {
      natural_orbitals_reference_states_BP_tab(i) = T_unsigned_int(i_unsigned_int++); 
      natural_orbitals_reference_states_vector_index_tab(i) = T_unsigned_int(i_unsigned_int++);
    }

  for (int l = 0 ; l <= lmax_p ; l++)
    for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      prot_basis_BP_tab(l , j) = T_unsigned_int(i_unsigned_int++);  

  for (int l = 0 ; l <= lmax_n ; l++)
    for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      neut_basis_BP_tab(l , j) = T_unsigned_int(i_unsigned_int++);  

  for (unsigned int i = 0 ; i < eigensets_number ; i++)
    {
      BP_eigenset_tab(i) = T_unsigned_int(i_unsigned_int++);
      eigenset_vectors_number_tab(i) = T_unsigned_int(i_unsigned_int++);
    }

  for (unsigned int i = 0 ; i < GSM_multipoles_number ; i++) 
    {
      GSM_multipoles_BP_tab(i) = T_unsigned_int(i_unsigned_int++);
      GSM_multipoles_vector_index_tab(i) = T_unsigned_int(i_unsigned_int++);
    }

  for (unsigned int i = 0 ; i < EM_transitions_number ; i++) 
    {
      EM_BP_IN_tab(i) = T_unsigned_int(i_unsigned_int++); 
      EM_BP_OUT_tab(i) = T_unsigned_int(i_unsigned_int++);
      EM_vector_index_IN_tab(i) = T_unsigned_int(i_unsigned_int++); 
      EM_vector_index_OUT_tab(i) = T_unsigned_int(i_unsigned_int++);
    }

  for (unsigned int i = 0 ; i < EM_transitions_strength_number ; i++) 
    {
      EM_strength_BP_IN_tab(i) = T_unsigned_int(i_unsigned_int++); 
      EM_strength_BP_OUT_tab(i) = T_unsigned_int(i_unsigned_int++);
      EM_strength_vector_index_IN_tab(i) = T_unsigned_int(i_unsigned_int++); 
      EM_strength_vector_index_OUT_tab(i) = T_unsigned_int(i_unsigned_int++);
    }

  for (unsigned int i = 0 ; i < beta_transitions_number ; i++) 
    {
      beta_BP_IN_tab(i) = T_unsigned_int(i_unsigned_int++); 
      beta_BP_OUT_tab(i) = T_unsigned_int(i_unsigned_int++);
      beta_vector_index_IN_tab(i) = T_unsigned_int(i_unsigned_int++); 
      beta_vector_index_OUT_tab(i) = T_unsigned_int(i_unsigned_int++);
    }

  for (unsigned int i = 0 ; i < beta_transitions_strength_number ; i++) 
    {
      beta_strength_BP_IN_tab(i) = T_unsigned_int(i_unsigned_int++); 
      beta_strength_BP_OUT_tab(i) = T_unsigned_int(i_unsigned_int++);
      beta_strength_vector_index_IN_tab(i) = T_unsigned_int(i_unsigned_int++); 
      beta_strength_vector_index_OUT_tab(i) = T_unsigned_int(i_unsigned_int++);
    }

  for (unsigned int i = 0 ; i < density_number ; i++) 
    {
      density_BP_tab(i) = T_unsigned_int(i_unsigned_int++); 
      density_vector_index_tab(i) = T_unsigned_int(i_unsigned_int++);
    }

  for (unsigned int i = 0 ; i < correlation_density_number ; i++) 
    {
      correlation_density_BP_tab(i) = T_unsigned_int(i_unsigned_int++); 
      correlation_density_vector_index_tab(i) = T_unsigned_int(i_unsigned_int++);
    }
  
  for (unsigned int i = 0 ; i < pair_density_number ; i++) 
    {
      pair_density_BP_tab(i) = T_unsigned_int(i_unsigned_int++); 
      pair_density_vector_index_tab(i) = T_unsigned_int(i_unsigned_int++);
    }

  for (unsigned int i = 0 ; i < spectroscopic_factor_number ; i++) 
    {
      spectroscopic_factor_BP_IN_tab(i) = T_unsigned_int(i_unsigned_int++); 
      spectroscopic_factor_BP_OUT_tab(i) = T_unsigned_int(i_unsigned_int++);
      spectroscopic_factor_vector_index_IN_tab(i) = T_unsigned_int(i_unsigned_int++); 
      spectroscopic_factor_vector_index_OUT_tab(i) = T_unsigned_int(i_unsigned_int++);
      spectroscopic_factor_BP_projectile_tab(i) = T_unsigned_int(i_unsigned_int++);
      spectroscopic_factor_vector_index_projectile_tab(i) = T_unsigned_int(i_unsigned_int++);
    }

  for (unsigned int i = 0 ; i < overlap_function_number ; i++) 
    {
      overlap_function_BP_IN_tab(i) = T_unsigned_int(i_unsigned_int++); 
      overlap_function_BP_OUT_tab(i) = T_unsigned_int(i_unsigned_int++);
      overlap_function_vector_index_IN_tab(i) = T_unsigned_int(i_unsigned_int++); 
      overlap_function_vector_index_OUT_tab(i) = T_unsigned_int(i_unsigned_int++);
      overlap_function_BP_projectile_tab(i) = T_unsigned_int(i_unsigned_int++);
      overlap_function_vector_index_projectile_tab(i) = T_unsigned_int(i_unsigned_int++);
    }

  for (unsigned int i = 0 ; i < rms_radius_number ; i++) 
    {
      rms_radius_BP_tab(i) = T_unsigned_int(i_unsigned_int++); 
      rms_radius_vector_index_tab(i) = T_unsigned_int(i_unsigned_int++);
    }

  for (unsigned int i = 0 ; i < rms_radius_one_body_strength_number ; i++) 
    {
      rms_radius_one_body_strength_BP_tab(i) = T_unsigned_int(i_unsigned_int++); 
      rms_radius_one_body_strength_vector_index_tab(i) = T_unsigned_int(i_unsigned_int++);
    }

  for (unsigned int i = 0 ; i < Hamiltonian_parts_eigenstates_number ; i++) 
    {
      Hamiltonian_parts_BP_tab(i) = T_unsigned_int(i_unsigned_int++); 
      Hamiltonian_parts_vector_index_tab(i) = T_unsigned_int(i_unsigned_int++);
    }

  for (unsigned int i = 0 ; i < Coulomb_isospin_mixture_number ; i++) 
    {
      Coulomb_isospin_mixture_BP_tab(i) = T_unsigned_int(i_unsigned_int++); 
      Coulomb_isospin_mixture_vector_index_tab(i) = T_unsigned_int(i_unsigned_int++); 
    }

  for (unsigned int i = 0 ; i < dagger_tilde_operators_number ; i++) 
    {
      dagger_tilde_operators_BP_IN_tab(i) = T_unsigned_int(i_unsigned_int++); 
      dagger_tilde_operators_BP_OUT_tab(i) = T_unsigned_int(i_unsigned_int++);
      dagger_tilde_operators_vector_index_IN_tab(i) = T_unsigned_int(i_unsigned_int++); 
      dagger_tilde_operators_vector_index_OUT_tab(i) = T_unsigned_int(i_unsigned_int++);
    }

  for (unsigned int i = 0 ; i < CC_N_target_projectile_states ; i++)
    {
      CC_BP_target_tab(i) = T_unsigned_int(i_unsigned_int++); 
      CC_vector_index_target_tab(i) = T_unsigned_int(i_unsigned_int++); 
      CC_N_partial_waves_tab(i) = T_unsigned_int(i_unsigned_int++);
    }

  for (unsigned int i = 0 ; i < CC_N_JPi_A_composite ; i++) 
    {
      CC_BP_A_composite_tab(i) = T_unsigned_int(i_unsigned_int++); 
      CC_vector_index_A_composite_tab(i) = T_unsigned_int(i_unsigned_int++);
    }

  for (unsigned int i = 0 ; i < CC_N_JPi_A_in_composite ; i++)
    CC_BP_A_in_composite_tab(i) = T_unsigned_int(i_unsigned_int++);

  for (unsigned int i = 0 ; i < CC_N_JPi_A_out_composite ; i++)
    {
      CC_BP_A_out_composite_tab(i) = T_unsigned_int(i_unsigned_int++);      
      CC_vector_index_A_out_composite_tab(i) = T_unsigned_int(i_unsigned_int++);
    }

  for (unsigned int i = 0 ; i < CC_average_n_scat_target_projectile_max_composite_number ; i++)
    CC_average_n_scat_target_projectile_max_BP_A_composite_tab(i) = T_unsigned_int(i_unsigned_int++);
  
  for (unsigned int i = 0 ; i < CC_corrective_factors_TBMEs_composite_number ; i++)
    CC_corrective_factors_TBMEs_BP_A_composite_tab(i) = T_unsigned_int(i_unsigned_int++);
    
  for (unsigned int ic = 0 ; ic < CC_cluster_projectile_number ; ic++)
    {
      CC_corrective_factors_cluster_composite_numbers(ic) = T_unsigned_int(i_unsigned_int++);
    
      for (unsigned int i = 0 ; i < CC_corrective_factors_cluster_composite_numbers_max ; i++)
	CC_corrective_factors_cluster_BP_A_composite_tab(ic , i) = T_unsigned_int(i_unsigned_int++);
      
      for (int L = 0 ; L <= CC_Lmax_all ; L++)
	for (unsigned int J_index = 0 ; J_index < CC_J_number_max_all ; J_index++)
	  {
	    CC_N_poles_cluster_projectile_CM_tab(ic , L , J_index) = T_unsigned_int(i_unsigned_int++); 
	    CC_N_K_peak_cluster_projectile_CM_tab(ic , L , J_index) = T_unsigned_int(i_unsigned_int++);
	    CC_N_K_middle_cluster_projectile_CM_tab(ic , L , J_index) = T_unsigned_int(i_unsigned_int++); 
	    CC_N_K_max_cluster_projectile_CM_tab(ic , L , J_index) = T_unsigned_int(i_unsigned_int++);
	  }
    }
  
  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    {
      Np_nlj_baryon_tab(i) = T_unsigned_int(i_unsigned_int++); 
      Np_nlj_res_baryon_tab(i) = T_unsigned_int(i_unsigned_int++); 
      Np_nljm_baryon_tab(i) = T_unsigned_int(i_unsigned_int++); 
      Np_nljm_res_baryon_tab(i) = T_unsigned_int(i_unsigned_int++); 
    }  
	
  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    {
      Nn_nlj_baryon_tab(i) = T_unsigned_int(i_unsigned_int++); 
      Nn_nlj_res_baryon_tab(i) = T_unsigned_int(i_unsigned_int++); 
      Nn_nljm_baryon_tab(i) = T_unsigned_int(i_unsigned_int++); 
      Nn_nljm_res_baryon_tab(i) = T_unsigned_int(i_unsigned_int++); 
    }  
	
  if (i_unsigned_int != dimension_unsigned_int) 
    error_message_print_abort ("i_unsigned_int=" + make_string<unsigned int> (i_unsigned_int) + " != dimension_unsigned_int=" + make_string<unsigned int> (dimension_unsigned_int) + " in input_data_str::put_unsigned_int_tables.");
}








unsigned int input_data_str::dimension_int_tabs_calc () const
{
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);
      
  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
  
  const int lmax_all = max (lmax_p , lmax_n);
  
  const int CC_Lmax_all_plus_one = CC_Lmax_all + 1;

  const unsigned int dimension_int = 2*(lmax_all + 1)
    + lmax_relative + 1
    + GSM_multipoles_number
    + 2*EM_transitions_number
    + 2*EM_transitions_strength_number
    + 2*beta_transitions_number
    + 2*beta_transitions_strength_number
    + 7*spectroscopic_factor_number
    + 7*overlap_function_number
    + rms_radius_number
    + rms_radius_one_body_strength_number
    + dagger_tilde_operators_number 
    + CC_N_target_projectile_states
    + CC_cluster_projectile_number*(2 + CC_Lmax_all_plus_one*CC_J_number_max_all)
    + CC_N_target_projectile_states*CC_N_partial_waves_max
    + 2*Np_baryon_type
    + 2*Nn_baryon_type
    + Np_baryon_type*(2*lmax_p + 1)
    + Nn_baryon_type*(2*lmax_n + 1)
    + dagger_tilde_operators_number;
      
  return dimension_int;
}






void input_data_str::get_int_tables (class array<int> &T_int) const
{  
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);
      
  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
  
  const int lmax_all = max (lmax_p , lmax_n);
  
  const unsigned int dimension_int = T_int.dimension (0);

  unsigned int i_int = 0;
  
  for (int l = 0 ; l <= lmax_all ; l++)
    {
      T_int(i_int++) = nmax_HO_lab_tab(l);
      T_int(i_int++) = nmax_GHF_lab_tab(l);
    }

  for (int l = 0 ; l <= lmax_relative ; l++) 
    T_int(i_int++) = nmax_HO_relative_tab(l);

  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_p ; l++)
      for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	T_int(i_int++) = basis_potential_partial_waves_p_tab(i)(l , j); 

  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_n ; l++)
      for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	T_int(i_int++) = basis_potential_partial_waves_n_tab(i)(l , j);
  
  for (unsigned int i = 0 ; i < GSM_multipoles_number ; i++)
    T_int(i_int++) = GSM_multipoles_L_tab(i); 
  
  for (unsigned int i = 0 ; i < EM_transitions_number ; i++)
    {
      T_int(i_int++) = EM_L_tab(i); 
      T_int(i_int++) = EM_tab(i);
    }

  for (unsigned int i = 0 ; i < EM_transitions_strength_number ; i++) 
    {
      T_int(i_int++) = EM_strength_L_tab(i); 
      T_int(i_int++) = EM_strength_tab(i);
    }

  for (unsigned int i = 0 ; i < beta_transitions_number ; i++) 
    {
      T_int(i_int++) = beta_tab(i); 
      T_int(i_int++) = beta_pm_tab(i);
    }

  for (unsigned int i = 0 ; i < beta_transitions_strength_number ; i++)
    {
      T_int(i_int++) = beta_strength_tab(i); 
      T_int(i_int++) = beta_strength_pm_tab(i);
    }

  for (unsigned int i = 0 ; i < spectroscopic_factor_number ; i++) 
    {
      T_int(i_int++) = spectroscopic_factor_LCM_projectile_tab(i); 
      T_int(i_int++) = spectroscopic_factor_NCM_HO_max_projectile_tab(i); 
      T_int(i_int++) = spectroscopic_factor_type_tab(i);
      T_int(i_int++) = spectroscopic_factor_nucleus_projectile_tab(i); 
      T_int(i_int++) = spectroscopic_factor_cluster_projectile_tab(i);   
      T_int(i_int++) = spectroscopic_factor_Z_projectile_tab(i);
      T_int(i_int++) = spectroscopic_factor_N_projectile_tab(i);
    }

  for (unsigned int i = 0 ; i < overlap_function_number ; i++) 
    {
      T_int(i_int++) = overlap_function_LCM_projectile_tab(i); 
      T_int(i_int++) = overlap_function_NCM_HO_max_projectile_tab(i); 
      T_int(i_int++) = overlap_function_type_tab(i);
      T_int(i_int++) = overlap_function_nucleus_projectile_tab(i);
      T_int(i_int++) = overlap_function_cluster_projectile_tab(i);
      T_int(i_int++) = overlap_function_Z_projectile_tab(i);
      T_int(i_int++) = overlap_function_N_projectile_tab(i);
    }

  for (unsigned int i = 0 ; i < rms_radius_number ; i++) 
    T_int(i_int++) = rms_radius_particle_tab(i);

  for (unsigned int i = 0 ; i < rms_radius_one_body_strength_number ; i++) 
    T_int(i_int++) = rms_radius_one_body_strength_particle_tab(i);

  for (unsigned int i = 0 ; i < dagger_tilde_operators_number ; i++) 
    T_int(i_int++) = dagger_tilde_operators_tab(i);

  for (unsigned int ic = 0 ; ic < CC_cluster_projectile_number ; ic++)
    {
      T_int(i_int++) = CC_Lmax_cluster_projectile_CM_tab(ic);
      T_int(i_int++) = CC_cluster_projectile_tab(ic);

      for (int L = 0 ; L <= CC_Lmax_all ; L++)
	for (unsigned int J_index = 0 ; J_index < CC_J_number_max_all ; J_index++)
	  T_int(i_int++) = CC_Nmin_PCM_cluster_projectile_tab(ic , L , J_index); 
    }
  
  for (unsigned int iT = 0 ; iT < CC_N_target_projectile_states ; iT++)
    {
      T_int(i_int++) = CC_projectile_tab(iT);

      for (unsigned int i = 0 ; i < CC_N_partial_waves_max ; i++)
	T_int(i_int++) = CC_partial_wave_L_cluster_projectile_tab(iT , i);
    }
      
  for (unsigned int i = 0 ; i < N_hyperon_types ; i++) T_int(i_int++) = hyperon_types(i);
	
  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    {
      T_int(i_int++) = lmax_baryon_p_tab(i);
      
      T_int(i_int++) = lmax_common_baryon_p_tab(i);
    }
  
  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    {
      T_int(i_int++) = lmax_baryon_n_tab(i);
      
      T_int(i_int++) = lmax_common_baryon_n_tab(i);
    }
  
  for (unsigned int i = 0 ; i < dagger_tilde_operators_number ; i++) 
    T_int(i_int++) = dagger_tilde_operators_S_IN_tab(i);
      
  if (i_int != dimension_int)
    error_message_print_abort ("i_int=" + make_string<unsigned int> (i_int) + " != dimension_int=" + make_string<unsigned int> (dimension_int) + " in input_data_str::get_int_tables.");
}






void input_data_str::alloc_int_tables ()
{
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);
      
  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
  
  const int CC_Lmax_all_plus_one = CC_Lmax_all + 1;

  const int lmax_relative_plus_one = lmax_relative + 1;

  const int lmax_all = max (lmax_p , lmax_n);
  
  const int lmax_all_plus_one = lmax_all + 1;
  
  nmax_HO_lab_tab.allocate (lmax_all_plus_one);
  nmax_GHF_lab_tab.allocate (lmax_all_plus_one);
  nmax_HO_relative_tab.allocate (lmax_relative_plus_one);

  basis_potential_partial_waves_p_tab.allocate (Np_baryon_type);
  basis_potential_partial_waves_n_tab.allocate (Nn_baryon_type);
  
  for (unsigned int i = 0 ; i < Np_baryon_type ; i++) basis_potential_partial_waves_p_tab(i).allocate (0.5 , lmax_p);  
  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++) basis_potential_partial_waves_n_tab(i).allocate (0.5 , lmax_n);
    
  GSM_multipoles_L_tab.allocate (GSM_multipoles_number);
  EM_L_tab.allocate (EM_transitions_number);
  EM_tab.allocate (EM_transitions_number);
  EM_strength_L_tab.allocate (EM_transitions_strength_number);
  EM_strength_tab.allocate (EM_transitions_strength_number);
  beta_tab.allocate (beta_transitions_number);
  beta_pm_tab.allocate (beta_transitions_number);
  beta_strength_tab.allocate (beta_transitions_strength_number); 
  beta_strength_pm_tab.allocate (beta_transitions_strength_number);
  spectroscopic_factor_LCM_projectile_tab.allocate (spectroscopic_factor_number);
  spectroscopic_factor_NCM_HO_max_projectile_tab.allocate (spectroscopic_factor_number);
  spectroscopic_factor_type_tab.allocate (spectroscopic_factor_number);
  spectroscopic_factor_nucleus_projectile_tab.allocate (spectroscopic_factor_number);
  spectroscopic_factor_cluster_projectile_tab.allocate (spectroscopic_factor_number);
  spectroscopic_factor_Z_projectile_tab.allocate (spectroscopic_factor_number);
  spectroscopic_factor_N_projectile_tab.allocate (spectroscopic_factor_number);
  overlap_function_LCM_projectile_tab.allocate (overlap_function_number);
  overlap_function_NCM_HO_max_projectile_tab.allocate (overlap_function_number);
  overlap_function_type_tab.allocate (overlap_function_number);
  overlap_function_nucleus_projectile_tab.allocate (overlap_function_number);
  overlap_function_cluster_projectile_tab.allocate (overlap_function_number);
  overlap_function_Z_projectile_tab.allocate (overlap_function_number);
  overlap_function_N_projectile_tab.allocate (overlap_function_number);
  rms_radius_particle_tab.allocate (rms_radius_number);
  rms_radius_one_body_strength_particle_tab.allocate (rms_radius_one_body_strength_number);
  dagger_tilde_operators_tab.allocate (dagger_tilde_operators_number);
  CC_Lmax_cluster_projectile_CM_tab.allocate (CC_cluster_projectile_number);
  CC_cluster_projectile_tab.allocate (CC_cluster_projectile_number);
  CC_Nmin_PCM_cluster_projectile_tab.allocate (CC_cluster_projectile_number , CC_Lmax_all_plus_one , CC_J_number_max_all);
  CC_projectile_tab.allocate (CC_N_target_projectile_states);
  CC_partial_wave_L_cluster_projectile_tab.allocate (CC_N_target_projectile_states , CC_N_partial_waves_max);
  hyperon_types.allocate (N_hyperon_types);
  lmax_baryon_p_tab.allocate (Np_baryon_type);
  lmax_common_baryon_p_tab.allocate (Np_baryon_type);
  lmax_baryon_n_tab.allocate (Nn_baryon_type);
  lmax_common_baryon_n_tab.allocate (Nn_baryon_type);
  dagger_tilde_operators_S_IN_tab.allocate (dagger_tilde_operators_number);
}







void input_data_str::put_int_tables (class array<int> &T_int)
{  
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);
      
  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);

  const int lmax_all = max (lmax_p , lmax_n);
  
  const unsigned int dimension_int = T_int.dimension (0);
  
  unsigned int i_int = 0;

  for (int l = 0 ; l <= lmax_all ; l++)
    {
      nmax_HO_lab_tab(l) = T_int(i_int++);
      nmax_GHF_lab_tab(l) = T_int(i_int++);
    }
  
  for (int l = 0 ; l <= lmax_relative ; l++) 
    nmax_HO_relative_tab(l) = T_int(i_int++);

  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_p ; l++)
      for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	basis_potential_partial_waves_p_tab(i)(l , j) = static_cast<enum potential_type> (T_int(i_int++)); 

  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_n ; l++)
      for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	basis_potential_partial_waves_n_tab(i)(l , j) = static_cast<enum potential_type> (T_int(i_int++)); 

  for (unsigned int i = 0 ; i < GSM_multipoles_number ; i++)
    GSM_multipoles_L_tab(i) = T_int(i_int++); 
  
  for (unsigned int i = 0 ; i < EM_transitions_number ; i++)
    {
      EM_L_tab(i) = T_int(i_int++); 
      EM_tab(i) = static_cast<enum EM_type> (T_int(i_int++));
    }

  for (unsigned int i = 0 ; i < EM_transitions_strength_number ; i++) 
    {
      EM_strength_L_tab(i) = T_int(i_int++); 
      EM_strength_tab(i) = static_cast<enum EM_type> (T_int(i_int++));
    }

  for (unsigned int i = 0 ; i < beta_transitions_number ; i++) 
    {
      beta_tab(i) = static_cast<enum beta_type> (T_int(i_int++)); 
      beta_pm_tab(i) = static_cast<enum beta_pm_type> (T_int(i_int++));
    }

  for (unsigned int i = 0 ; i < beta_transitions_strength_number ; i++)
    {
      beta_strength_tab(i) = static_cast<enum beta_type> (T_int(i_int++)); 
      beta_strength_pm_tab(i) = static_cast<enum beta_pm_type> (T_int(i_int++));
    }

  for (unsigned int i = 0 ; i < spectroscopic_factor_number ; i++) 
    {
      spectroscopic_factor_LCM_projectile_tab(i) = T_int(i_int++);
      spectroscopic_factor_NCM_HO_max_projectile_tab(i) = T_int(i_int++);
      spectroscopic_factor_type_tab(i) = static_cast<enum spectroscopic_factor_type> (T_int(i_int++));
      spectroscopic_factor_nucleus_projectile_tab(i) = static_cast<enum nucleus_type> (T_int(i_int++));
      spectroscopic_factor_cluster_projectile_tab(i) = static_cast<enum particle_type> (T_int(i_int++));
      spectroscopic_factor_Z_projectile_tab(i) = T_int(i_int++);
      spectroscopic_factor_N_projectile_tab(i) = T_int(i_int++);
    }

  for (unsigned int i = 0 ; i < overlap_function_number ; i++) 
    {
      overlap_function_LCM_projectile_tab(i) = T_int(i_int++);
      overlap_function_NCM_HO_max_projectile_tab(i) = T_int(i_int++);
      overlap_function_type_tab(i) = static_cast<enum spectroscopic_factor_type> (T_int(i_int++));
      overlap_function_nucleus_projectile_tab(i) = static_cast<enum nucleus_type> (T_int(i_int++));
      overlap_function_cluster_projectile_tab(i) = static_cast<enum particle_type> (T_int(i_int++));
      overlap_function_Z_projectile_tab(i) = T_int(i_int++);
      overlap_function_N_projectile_tab(i) = T_int(i_int++);
    }

  for (unsigned int i = 0 ; i < rms_radius_number ; i++) 
    rms_radius_particle_tab(i) = static_cast<enum particle_type> (T_int(i_int++));

  for (unsigned int i = 0 ; i < rms_radius_one_body_strength_number ; i++) 
    rms_radius_one_body_strength_particle_tab(i) = static_cast<enum particle_type> (T_int(i_int++));

  for (unsigned int i = 0 ; i < dagger_tilde_operators_number ; i++) 
    dagger_tilde_operators_tab(i) = static_cast<enum dagger_tilde_operator_type> (T_int(i_int++));

  for (unsigned int ic = 0 ; ic < CC_cluster_projectile_number ; ic++)
    {
      CC_Lmax_cluster_projectile_CM_tab(ic) = T_int(i_int++);
      CC_cluster_projectile_tab(ic) = static_cast<enum particle_type> (T_int(i_int++));

      for (int L = 0 ; L <= CC_Lmax_all ; L++)
	for (unsigned int J_index = 0 ; J_index < CC_J_number_max_all ; J_index++)
	  CC_Nmin_PCM_cluster_projectile_tab(ic , L , J_index) = T_int(i_int++);
    }

  for (unsigned int iT = 0 ; iT < CC_N_target_projectile_states ; iT++)
    {
      CC_projectile_tab(iT) = static_cast<enum particle_type> (T_int(i_int++));

      for (unsigned int i = 0 ; i < CC_N_partial_waves_max ; i++)
	CC_partial_wave_L_cluster_projectile_tab(iT , i) = T_int(i_int++);
    }
  
  for (unsigned int i = 0 ; i < N_hyperon_types ; i++) hyperon_types(i) = static_cast<enum particle_type> (T_int(i_int++));
	
  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    {
      lmax_baryon_p_tab(i) = T_int(i_int++);
      
      lmax_common_baryon_p_tab(i) = T_int(i_int++);
    }
  
  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    {
      lmax_baryon_n_tab(i) = T_int(i_int++);
      
      lmax_common_baryon_n_tab(i) = T_int(i_int++);
    }

  for (unsigned int i = 0 ; i < dagger_tilde_operators_number ; i++) 
    dagger_tilde_operators_S_IN_tab(i) = T_int(i_int++);
  
  if (i_int != dimension_int)    
    error_message_print_abort ("i_int=" + make_string<unsigned int> (i_int) + " != dimension_int=" + make_string<unsigned int> (dimension_int) + " in input_data_str::put_int_tables.");
}











unsigned int input_data_str::dimension_bool_tabs_calc () const
{
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);
      
  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
  
  const unsigned int dimension_bool = GSM_multipoles_number
    + 2*EM_transitions_number 
    + 2*EM_transitions_strength_number 
    + beta_transitions_number 
    + rms_radius_number 
    + 2*CC_N_target_projectile_states
    + beta_transitions_strength_number 
    + 3*correlation_density_number 
    + 2*pair_density_number 
    + 2*density_number 
    + overlap_function_number 
    + rms_radius_one_body_strength_number
    + 10*Np_baryon_type
    + 10*Nn_baryon_type;
    
  return dimension_bool;
}







void input_data_str::get_bool_tables (class array<bool> &T_bool) const
{
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);

  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
  
  const unsigned int dimension_bool = T_bool.dimension (0);

  unsigned int i_bool = 0;

  for (unsigned int i = 0 ; i < GSM_multipoles_number ; i++) 
    T_bool(i_bool++) = GSM_multipoles_is_it_HO_expansion_tab(i);
  
  for (unsigned int i = 0 ; i < EM_transitions_number ; i++) 
    {
      T_bool(i_bool++) = EM_is_it_longwavelength_approximation_tab(i);
      T_bool(i_bool++) = EM_is_it_HO_expansion_tab(i);
    }

  for (unsigned int i = 0 ; i < EM_transitions_strength_number ; i++)
    {
      T_bool(i_bool++) = EM_strength_is_it_longwavelength_approximation_tab(i);
      T_bool(i_bool++) = EM_strength_is_it_Gauss_Legendre_tab(i);
    }

  for (unsigned int i = 0 ; i < beta_transitions_number ; i++) 
    T_bool(i_bool++) = beta_is_it_HO_expansion_tab(i);

  for (unsigned int i = 0 ; i < rms_radius_number ; i++) 
    T_bool(i_bool++) = rms_radius_is_it_HO_expansion_tab(i);
  
  for (unsigned int i = 0 ; i < CC_N_target_projectile_states ; i++) 
    {
      T_bool(i_bool++) = CC_is_it_entrance_tab(i);
      T_bool(i_bool++) = CC_is_it_pole_target_tab(i);
    }
  
  for (unsigned int i = 0 ; i < beta_transitions_strength_number ; i++)
    T_bool(i_bool++) = beta_strength_is_it_Gauss_Legendre_tab(i);

  for (unsigned int i = 0 ; i < correlation_density_number ; i++)
    {
      T_bool(i_bool++) = correlation_density_is_it_radial_tab(i);
      T_bool(i_bool++) = correlation_density_is_it_Gauss_Legendre_tab(i);
      T_bool(i_bool++) = correlation_density_is_it_HO_expansion_tab(i);
    }
  
  for (unsigned int i = 0 ; i < pair_density_number ; i++)
    {
      T_bool(i_bool++) = pair_density_is_it_radial_tab(i);
      T_bool(i_bool++) = pair_density_is_it_Gauss_Legendre_tab(i);
    }
    
  for (unsigned int i = 0 ; i < density_number ; i++)
    {
      T_bool(i_bool++) = density_is_it_radial_tab(i);
      T_bool(i_bool++) = density_is_it_Gauss_Legendre_tab(i);
    }
  
  for (unsigned int i = 0 ; i < overlap_function_number ; i++)
    T_bool(i_bool++) = overlap_function_is_it_Gauss_Legendre_tab(i);

  for (unsigned int i = 0 ; i < rms_radius_one_body_strength_number ; i++)
    T_bool(i_bool++) = rms_radius_one_body_strength_is_it_Gauss_Legendre_tab(i);
     
  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    {
      T_bool(i_bool++) = are_there_new_natural_orbitals_p_tab(i);
      T_bool(i_bool++) = are_there_basis_natural_orbitals_p_tab(i);
      
      T_bool(i_bool++) = same_dp_all_lj_tab(i);
      T_bool(i_bool++) = same_R0_p_all_lj_tab(i);
      T_bool(i_bool++) = same_Vo_p_all_lj_tab(i);
      T_bool(i_bool++) = same_Vso_p_all_lj_tab(i);
      
      T_bool(i_bool++) = is_dp_fitted_tab(i);
      T_bool(i_bool++) = is_R0_p_fitted_tab(i);
      T_bool(i_bool++) = is_Vo_p_fitted_tab(i);
      T_bool(i_bool++) = is_Vso_p_fitted_tab(i);
    }
    
  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    {
      T_bool(i_bool++) = are_there_new_natural_orbitals_n_tab(i);
      T_bool(i_bool++) = are_there_basis_natural_orbitals_n_tab(i);
      
      T_bool(i_bool++) = same_dn_all_lj_tab(i);
      T_bool(i_bool++) = same_R0_n_all_lj_tab(i);
      T_bool(i_bool++) = same_Vo_n_all_lj_tab(i);
      T_bool(i_bool++) = same_Vso_n_all_lj_tab(i);
      
      T_bool(i_bool++) = is_dn_fitted_tab(i);
      T_bool(i_bool++) = is_R0_n_fitted_tab(i);
      T_bool(i_bool++) = is_Vo_n_fitted_tab(i);
      T_bool(i_bool++) = is_Vso_n_fitted_tab(i);
    }
  
  if (i_bool != dimension_bool)
    error_message_print_abort ("i_bool=" + make_string<unsigned int> (i_bool) + " != dimension_bool=" + make_string<unsigned int> (dimension_bool) + " in input_data_str::get_bool_tables.");
}



void input_data_str::alloc_bool_tables ()
{
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);

  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
  
  GSM_multipoles_is_it_HO_expansion_tab.allocate (GSM_multipoles_number);
  EM_is_it_longwavelength_approximation_tab.allocate (EM_transitions_number);
  EM_is_it_HO_expansion_tab.allocate (EM_transitions_number);
  EM_strength_is_it_longwavelength_approximation_tab.allocate (EM_transitions_strength_number);
  beta_is_it_HO_expansion_tab.allocate (beta_transitions_number);
  rms_radius_is_it_HO_expansion_tab.allocate (rms_radius_number);
  CC_is_it_entrance_tab.allocate (CC_N_target_projectile_states);
  CC_is_it_pole_target_tab.allocate (CC_N_target_projectile_states);
  EM_strength_is_it_Gauss_Legendre_tab.allocate (EM_transitions_strength_number);
  beta_strength_is_it_Gauss_Legendre_tab.allocate (beta_transitions_strength_number);
  correlation_density_is_it_radial_tab.allocate (correlation_density_number);
  correlation_density_is_it_Gauss_Legendre_tab.allocate (correlation_density_number);
  correlation_density_is_it_HO_expansion_tab.allocate (correlation_density_number);
  pair_density_is_it_radial_tab.allocate (pair_density_number);
  pair_density_is_it_Gauss_Legendre_tab.allocate (pair_density_number);
  density_is_it_radial_tab.allocate (density_number);
  density_is_it_Gauss_Legendre_tab.allocate (density_number);
  overlap_function_is_it_Gauss_Legendre_tab.allocate (overlap_function_number);
  rms_radius_one_body_strength_is_it_Gauss_Legendre_tab.allocate (rms_radius_one_body_strength_number);
  are_there_new_natural_orbitals_p_tab.allocate (Np_baryon_type);
  are_there_basis_natural_orbitals_p_tab.allocate (Np_baryon_type);
  same_dp_all_lj_tab.allocate (Np_baryon_type);
  same_R0_p_all_lj_tab.allocate (Np_baryon_type);
  same_Vo_p_all_lj_tab.allocate (Np_baryon_type);
  same_Vso_p_all_lj_tab.allocate (Np_baryon_type);
  is_dp_fitted_tab.allocate (Np_baryon_type);
  is_R0_p_fitted_tab.allocate (Np_baryon_type);
  is_Vo_p_fitted_tab.allocate (Np_baryon_type);
  is_Vso_p_fitted_tab.allocate (Np_baryon_type);
  are_there_new_natural_orbitals_n_tab.allocate (Nn_baryon_type);
  are_there_basis_natural_orbitals_n_tab.allocate (Nn_baryon_type);      
  same_dn_all_lj_tab.allocate (Nn_baryon_type);
  same_R0_n_all_lj_tab.allocate (Nn_baryon_type);
  same_Vo_n_all_lj_tab.allocate (Nn_baryon_type);
  same_Vso_n_all_lj_tab.allocate (Nn_baryon_type);
  is_dn_fitted_tab.allocate (Nn_baryon_type);
  is_R0_n_fitted_tab.allocate (Nn_baryon_type);
  is_Vo_n_fitted_tab.allocate (Nn_baryon_type);
  is_Vso_n_fitted_tab.allocate (Nn_baryon_type);
}







void input_data_str::put_bool_tables (class array<bool> &T_bool)
{
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);

  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
  
  const unsigned int dimension_bool = T_bool.dimension (0); 

  unsigned int i_bool = 0;

  for (unsigned int i = 0 ; i < GSM_multipoles_number ; i++)
    GSM_multipoles_is_it_HO_expansion_tab(i) = T_bool(i_bool++);
    
  for (unsigned int i = 0 ; i < EM_transitions_number ; i++)
    { 
      EM_is_it_longwavelength_approximation_tab(i) = T_bool(i_bool++);
      EM_is_it_HO_expansion_tab(i) = T_bool(i_bool++);
    }

  for (unsigned int i = 0 ; i < EM_transitions_strength_number ; i++)
    {
      EM_strength_is_it_longwavelength_approximation_tab(i) = T_bool(i_bool++);
      EM_strength_is_it_Gauss_Legendre_tab(i) = T_bool(i_bool++);
    }

  for (unsigned int i = 0 ; i < beta_transitions_number ; i++) 
    beta_is_it_HO_expansion_tab(i) = T_bool(i_bool++);

  for (unsigned int i = 0 ; i < rms_radius_number ; i++) 
    rms_radius_is_it_HO_expansion_tab(i) = T_bool(i_bool++);

  for (unsigned int i = 0 ; i < CC_N_target_projectile_states ; i++)
    { 
      CC_is_it_entrance_tab(i) = T_bool(i_bool++);
      CC_is_it_pole_target_tab(i) = T_bool(i_bool++); 
    }

  for (unsigned int i = 0 ; i < beta_transitions_strength_number ; i++)
    beta_strength_is_it_Gauss_Legendre_tab(i) = T_bool(i_bool++);

  for (unsigned int i = 0 ; i < correlation_density_number ; i++)
    {
      correlation_density_is_it_radial_tab(i) = T_bool(i_bool++);
      correlation_density_is_it_Gauss_Legendre_tab(i) = T_bool(i_bool++);
      correlation_density_is_it_HO_expansion_tab(i) = T_bool(i_bool++);
    }
  
  for (unsigned int i = 0 ; i < pair_density_number ; i++)
    {
      pair_density_is_it_radial_tab(i) = T_bool(i_bool++);
      pair_density_is_it_Gauss_Legendre_tab(i) = T_bool(i_bool++);
    }
    
  for (unsigned int i = 0 ; i < density_number ; i++)
    {
      density_is_it_radial_tab(i) = T_bool(i_bool++);
      density_is_it_Gauss_Legendre_tab(i) = T_bool(i_bool++);
    }
  
  for (unsigned int i = 0 ; i < overlap_function_number ; i++)
    overlap_function_is_it_Gauss_Legendre_tab(i) = T_bool(i_bool++);

  for (unsigned int i = 0 ; i < rms_radius_one_body_strength_number ; i++)
    rms_radius_one_body_strength_is_it_Gauss_Legendre_tab(i) = T_bool(i_bool++);
  
  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    {
      are_there_new_natural_orbitals_p_tab(i) = T_bool(i_bool++);
      are_there_basis_natural_orbitals_p_tab(i) = T_bool(i_bool++);
      
      same_dp_all_lj_tab(i) = T_bool(i_bool++);
      same_R0_p_all_lj_tab(i) = T_bool(i_bool++);
      same_Vo_p_all_lj_tab(i) = T_bool(i_bool++);
      same_Vso_p_all_lj_tab(i) = T_bool(i_bool++);
      
      is_dp_fitted_tab(i) = T_bool(i_bool++);
      is_R0_p_fitted_tab(i) = T_bool(i_bool++);
      is_Vo_p_fitted_tab(i) = T_bool(i_bool++);
      is_Vso_p_fitted_tab(i) = T_bool(i_bool++);
    }
  
  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    {
      are_there_new_natural_orbitals_n_tab(i) = T_bool(i_bool++);
      are_there_basis_natural_orbitals_n_tab(i) = T_bool(i_bool++);
      
      same_dn_all_lj_tab(i) = T_bool(i_bool++);
      same_R0_n_all_lj_tab(i) = T_bool(i_bool++);
      same_Vo_n_all_lj_tab(i) = T_bool(i_bool++);
      same_Vso_n_all_lj_tab(i) = T_bool(i_bool++);
      
      is_dn_fitted_tab(i) = T_bool(i_bool++);
      is_R0_n_fitted_tab(i) = T_bool(i_bool++);
      is_Vo_n_fitted_tab(i) = T_bool(i_bool++);
      is_Vso_n_fitted_tab(i) = T_bool(i_bool++);
    }
  
  if (i_bool != dimension_bool) 
    error_message_print_abort ("i_bool=" + make_string<bool> (i_bool) + " != dimension_bool=" + make_string<unsigned int> (dimension_bool) + " in input_data_str::put_bool_tables.");
}














unsigned int input_data_str::dimension_double_tabs_calc () const
{
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);

  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
      
  const unsigned int Jmax_basis = Jmax_global_determine (true);

  const unsigned int Jmax = Jmax_global_determine (false);

  const unsigned int V_Gaussian_dimension_basis = 4*(Jmax_basis + 1);

  const unsigned int V_Gaussian_dimension = 4*(Jmax + 1);
    
  const unsigned int dimension_double = natural_orbitals_reference_states_number
    + 8*Np_baryon_type*(lmax_common_p + 1)
    + 8*Nn_baryon_type*(lmax_common_n + 1)
    + 4*Np_baryon_type*(lmax_p + 1)
    + 4*Nn_baryon_type*(lmax_n + 1)
    + 4*(lmax_relative + 1)
    + eigensets_number
    + V_Gaussian_dimension_basis
    + V_Gaussian_dimension
    + GSM_multipoles_number
    + 2*EM_transitions_number
    + 2*EM_transitions_strength_number
    + 3*beta_transitions_number
    + 2*beta_transitions_strength_number
    + density_number
    + 2*correlation_density_number
    + 2*pair_density_number
    + 3*spectroscopic_factor_number
    + 3*overlap_function_number
    + 2*rms_radius_number
    + rms_radius_one_body_strength_number
    + Hamiltonian_parts_eigenstates_number
    + Coulomb_isospin_mixture_number
    + 2*dagger_tilde_operators_number
    + CC_N_target_projectile_states*(5 + CC_N_partial_waves_max)
    + CC_N_JPi_A_composite
    + CC_N_CM_angles
    + CC_N_JPi_A_in_composite
    + CC_N_JPi_A_out_composite
    + 2*CC_average_n_scat_target_projectile_max_composite_number
    + 2*CC_corrective_factors_TBMEs_composite_number
    + 2*CC_cluster_projectile_number*CC_corrective_factors_cluster_composite_numbers_max
    + 34*Np_baryon_type
    + 34*Nn_baryon_type
    + 2*lmax_p + 1
    + 2*lmax_n + 1
    + Np_baryon_type*(2*lmax_p + 1)
    + Nn_baryon_type*(2*lmax_n + 1);
  
  return dimension_double;
}


void input_data_str::get_double_tables (class array<double> &T_double) const
{
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);

  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
        
  const unsigned int Jmax_basis = Jmax_global_determine (true);

  const unsigned int Jmax = Jmax_global_determine (false);
  
  const unsigned int dimension_double = T_double.dimension (0);

  unsigned int i_double = 0;

  for (unsigned int i = 0 ; i < natural_orbitals_reference_states_number ; i++)
    T_double(i_double++) = natural_orbitals_reference_states_J_tab(i);

  for (unsigned int i = 0 ; i < eigensets_number ; i++)
    T_double(i_double++) = J_eigenset_tab(i);
  
  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_common_p ; l++)
      {
	T_double(i_double++) = dp_core_potential_tab(i , l); 
	T_double(i_double++) = R0_p_core_potential_tab(i , l); 
	T_double(i_double++) = Vo_p_core_potential_tab(i , l); 
	T_double(i_double++) = Vso_p_core_potential_tab(i , l);
      }

  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_common_n ; l++)
      {
	T_double(i_double++) = dn_core_potential_tab(i , l); 
	T_double(i_double++) = R0_n_core_potential_tab(i , l); 
	T_double(i_double++) = Vo_n_core_potential_tab(i , l); 
	T_double(i_double++) = Vso_n_core_potential_tab(i , l);
      }

  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_common_p ; l++)
      {
	T_double(i_double++) = dp_basis_core_potential_tab(i , l); 
	T_double(i_double++) = R0_p_basis_core_potential_tab(i , l); 
	T_double(i_double++) = Vo_p_basis_core_potential_tab(i , l); 
	T_double(i_double++) = Vso_p_basis_core_potential_tab(i , l);
      }

  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_common_n ; l++)
      {
	T_double(i_double++) = dn_basis_core_potential_tab(i , l); 
	T_double(i_double++) = R0_n_basis_core_potential_tab(i , l); 
	T_double(i_double++) = Vo_n_basis_core_potential_tab(i , l); 
	T_double(i_double++) = Vso_n_basis_core_potential_tab(i , l);
      }

  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_p ; l++)
      {
	T_double(i_double++) = dp_basis_tab(i , l); 
	T_double(i_double++) = R0_p_basis_tab(i , l); 
	T_double(i_double++) = Vo_p_basis_tab(i , l); 
	T_double(i_double++) = Vso_p_basis_tab(i , l);
      }

  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_n ; l++)
      {
	T_double(i_double++) = dn_basis_tab(i , l); 
	T_double(i_double++) = R0_n_basis_tab(i , l); 
	T_double(i_double++) = Vo_n_basis_tab(i , l); 
	T_double(i_double++) = Vso_n_basis_tab(i , l);
      }
    
  for (int l = 0 ; l <= lmax_relative ; l++)
    {
      T_double(i_double++) = d_basis_relative_tab(l); 
      T_double(i_double++) = R0_basis_relative_tab(l); 
      T_double(i_double++) = Vo_basis_relative_tab(l); 
      T_double(i_double++) = Vso_basis_relative_tab(l);
    }

  for (unsigned int BP = 0 ; BP <= 1 ; BP++) 
    for (unsigned int J = 0 ; J <= Jmax_basis ; J++) 
      for (unsigned int T = 0 ; T <= 1 ; T++) 
	T_double(i_double++) = V_Gaussian_consts_basis(BP , J , T);

  for (unsigned int BP = 0 ; BP <= 1 ; BP++) 
    for (unsigned int J = 0 ; J <= Jmax ; J++) 
      for (unsigned int T = 0 ; T <= 1 ; T++)
	T_double(i_double++) = V_Gaussian_consts(BP , J , T);
  
  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_p ; l++)
      for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	T_double(i_double++) = b_lab_partial_waves_p_tab(i)(l , j);

  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_n ; l++)
      for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	T_double(i_double++) = b_lab_partial_waves_n_tab(i)(l , j); 
  
  for (int l = 0 ; l <= lmax_p ; l++)
    for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	T_double(i_double++) = prot_basis_J_tab(l , j); 

  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_n ; l++)
      for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	T_double(i_double++) = neut_basis_J_tab(l , j);
  
  for (unsigned int i = 0 ; i < GSM_multipoles_number ; i++) 
    T_double(i_double++) = GSM_multipoles_J_tab(i);
  
  for (unsigned int i = 0 ; i < EM_transitions_number ; i++) 
    {
      T_double(i_double++) = EM_J_IN_tab(i); 
      T_double(i_double++) = EM_J_OUT_tab(i);
    }

  for (unsigned int i = 0 ; i < EM_transitions_strength_number ; i++) 
    {
      T_double(i_double++) = EM_strength_J_IN_tab(i); 
      T_double(i_double++) = EM_strength_J_OUT_tab(i);
    }

  for (unsigned int i = 0 ; i < beta_transitions_number ; i++) 
    {
      T_double(i_double++) = beta_J_IN_tab(i); 
      T_double(i_double++) = beta_J_OUT_tab(i); 
      T_double(i_double++) = beta_W0_tab(i);
    }

  for (unsigned int i = 0 ; i < beta_transitions_strength_number ; i++)
    {
      T_double(i_double++) = beta_strength_J_IN_tab(i); 
      T_double(i_double++) = beta_strength_J_OUT_tab(i);
    }

  for (unsigned int i = 0 ; i < density_number ; i++) 
    T_double(i_double++) = density_J_tab(i);

  for (unsigned int i = 0 ; i < correlation_density_number ; i++)
    {
      T_double(i_double++) = correlation_density_J_tab(i);
      T_double(i_double++) = correlation_density_RKmax_tab(i);
    }
  
  for (unsigned int i = 0 ; i < pair_density_number ; i++)
    {
      T_double(i_double++) = pair_density_J_tab(i);
      T_double(i_double++) = pair_density_RKmax_tab(i);
    }
    
  for (unsigned int i = 0 ; i < spectroscopic_factor_number ; i++) 
    {
      T_double(i_double++) = spectroscopic_factor_J_IN_tab(i); 
      T_double(i_double++) = spectroscopic_factor_J_OUT_tab(i); 
      T_double(i_double++) = spectroscopic_factor_J_projectile_tab(i);
    }

  for (unsigned int i = 0 ; i < overlap_function_number ; i++) 
    {
      T_double(i_double++) = overlap_function_J_IN_tab(i); 
      T_double(i_double++) = overlap_function_J_OUT_tab(i); 
      T_double(i_double++) = overlap_function_J_projectile_tab(i);
    }

  for (unsigned int i = 0 ; i < rms_radius_number ; i++) 
    {
      T_double(i_double++) = rms_radius_J_tab(i); 
      T_double(i_double++) = rms_radius_frozen_core_tab(i);
    }

  for (unsigned int i = 0 ; i < rms_radius_one_body_strength_number ; i++) 
    T_double(i_double++) = rms_radius_one_body_strength_J_tab(i);

  for (unsigned int i = 0 ; i < Hamiltonian_parts_eigenstates_number ; i++) 
    T_double(i_double++) = Hamiltonian_parts_J_tab(i);

  for (unsigned int i = 0 ; i < Coulomb_isospin_mixture_number ; i++) 
    T_double(i_double++) = Coulomb_isospin_mixture_J_tab(i); 

  for (unsigned int i = 0 ; i < dagger_tilde_operators_number ; i++) 
    {
      T_double(i_double++) = dagger_tilde_operators_J_IN_tab(i); 
      T_double(i_double++) = dagger_tilde_operators_J_OUT_tab(i);
    }

  for (unsigned int iT = 0 ; iT < CC_N_target_projectile_states ; iT++)
    {
      T_double(i_double++) = CC_J_target_tab(iT);
      T_double(i_double++) = CC_real_E_intrinsic_projectile_tab(iT); 
      T_double(i_double++) = CC_Gamma_intrinsic_projectile_tab(iT); 
      T_double(i_double++) = CC_real_E_target_tab(iT); 
      T_double(i_double++) = CC_Gamma_target_tab(iT);

      for (unsigned int i = 0 ; i < CC_N_partial_waves_max ; i++)
	T_double(i_double++) = CC_partial_wave_J_cluster_projectile_tab(iT , i);
    }
  
  for (unsigned int i = 0 ; i < CC_N_JPi_A_composite ; i++)
    T_double(i_double++) = CC_J_A_composite_tab(i) ;

  for (unsigned int i = 0 ; i < CC_N_CM_angles ; i++)
    T_double(i_double++) = CC_CM_angles(i);

  for (unsigned int i = 0 ; i < CC_N_JPi_A_in_composite ; i++)
    T_double(i_double++) = CC_J_A_in_composite_tab(i);

  for (unsigned int i = 0 ; i < CC_N_JPi_A_out_composite ; i++)
    T_double(i_double++) = CC_J_A_out_composite_tab(i);
  
  for (unsigned int i = 0 ; i < CC_average_n_scat_target_projectile_max_composite_number ; i++)
    {
      T_double(i_double++) = CC_average_n_scat_target_projectile_max_J_A_composite_tab(i); 
      T_double(i_double++) = CC_average_n_scat_target_projectile_max_composite_tab(i); 
    }
  for (unsigned int i = 0 ; i < CC_corrective_factors_TBMEs_composite_number ; i++)
    {
      T_double(i_double++) = CC_corrective_factors_TBMEs_J_A_composite_tab(i); 
      T_double(i_double++) = CC_corrective_factors_TBMEs_composite_tab(i); 
    }  
  
  for (unsigned int ic = 0 ; ic < CC_cluster_projectile_number ; ic++)
    for (unsigned int i = 0 ; i < CC_corrective_factors_cluster_composite_numbers_max ; i++)
      {
	T_double(i_double++) = CC_corrective_factors_cluster_J_A_composite_tab(ic , i); 
	T_double(i_double++) = CC_corrective_factors_cluster_composite_tab(ic , i); 
      }
  
  for (unsigned int ii = 0 ; ii < 5 ; ii++)
    {
      for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
	{
	  T_double(i_double++) = V0_KKNN_p_tab(i , ii);
	  T_double(i_double++) = rho_KKNN_p_tab(i , ii);
	  
	  T_double(i_double++) = V0_KKNN_basis_core_potential_p_tab(i , ii);
	  T_double(i_double++) = rho_KKNN_basis_core_potential_p_tab(i , ii);
	}
	  
      for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
	{
	  T_double(i_double++) = V0_KKNN_n_tab(i , ii);
	  T_double(i_double++) = rho_KKNN_n_tab(i , ii);	  
	  
	  T_double(i_double++) = V0_KKNN_basis_core_potential_n_tab(i , ii);
	  T_double(i_double++) = rho_KKNN_basis_core_potential_n_tab(i , ii);
	}
    }
  
  for (unsigned int ii = 0 ; ii < 3 ; ii++)
    { 
      for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
	{
	  T_double(i_double++) = Vls_KKNN_p_tab(i , ii);
	  T_double(i_double++) = rho_ls_KKNN_p_tab(i , ii);
	  
	  T_double(i_double++) = Vls_KKNN_basis_core_potential_p_tab(i , ii);
	  T_double(i_double++) = rho_ls_KKNN_basis_core_potential_p_tab(i , ii);
	}
      
      for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
	{
	  T_double(i_double++) = Vls_KKNN_n_tab(i , ii);
	  T_double(i_double++) = rho_ls_KKNN_n_tab(i , ii);	  
	  
	  T_double(i_double++) = Vls_KKNN_basis_core_potential_n_tab(i , ii);
	  T_double(i_double++) = rho_ls_KKNN_basis_core_potential_n_tab(i , ii);
	}
    }

  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    {
      T_double(i_double++) = effective_charges_p(i);
      T_double(i_double++) = effective_masses_for_calc_p(i);
    }
  
  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    {
      T_double(i_double++) = effective_charges_n(i);
      T_double(i_double++) = effective_masses_for_calc_n(i);
    }
  
  if (i_double != dimension_double)
    error_message_print_abort ("i_double=" + make_string<unsigned int> (i_double) + " != dimension_double=" + make_string<unsigned int> (dimension_double) + " in input_data_str::get_double_tables.");
}






void input_data_str::alloc_double_tables ()
{
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);

  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
    
  const unsigned int Jmax_basis = Jmax_global_determine (true);

  const unsigned int Jmax = Jmax_global_determine (false);

  const unsigned int Jmax_basis_plus_one = Jmax_basis + 1;

  const unsigned int Jmax_plus_one = Jmax + 1;

  const int lmax_p_plus_one = lmax_p + 1;
  const int lmax_n_plus_one = lmax_n + 1;
  
  const int lmax_relative_plus_one = lmax_relative + 1;

  const int lmax_common_p_plus_one = lmax_common_p + 1;
  const int lmax_common_n_plus_one = lmax_common_n + 1;
    
  natural_orbitals_reference_states_J_tab.allocate (natural_orbitals_reference_states_number);
  J_eigenset_tab.allocate (eigensets_number);
  dp_core_potential_tab.allocate (Np_baryon_type , lmax_common_p_plus_one);
  R0_p_core_potential_tab.allocate (Np_baryon_type , lmax_common_p_plus_one);
  Vo_p_core_potential_tab.allocate (Np_baryon_type , lmax_common_p_plus_one);
  Vso_p_core_potential_tab.allocate (Np_baryon_type , lmax_common_p_plus_one);
  dn_core_potential_tab.allocate (Nn_baryon_type , lmax_common_n_plus_one);
  R0_n_core_potential_tab.allocate (Nn_baryon_type , lmax_common_n_plus_one);
  Vo_n_core_potential_tab.allocate (Nn_baryon_type , lmax_common_n_plus_one);
  Vso_n_core_potential_tab.allocate (Nn_baryon_type , lmax_common_n_plus_one);
  dp_basis_core_potential_tab.allocate (Np_baryon_type , lmax_common_p_plus_one);
  R0_p_basis_core_potential_tab.allocate (Np_baryon_type , lmax_common_p_plus_one);
  Vo_p_basis_core_potential_tab.allocate (Np_baryon_type , lmax_common_p_plus_one);
  Vso_p_basis_core_potential_tab.allocate (Np_baryon_type , lmax_common_p_plus_one);
  dn_basis_core_potential_tab.allocate (Nn_baryon_type , lmax_common_n_plus_one);
  R0_n_basis_core_potential_tab.allocate (Nn_baryon_type , lmax_common_n_plus_one);
  Vo_n_basis_core_potential_tab.allocate (Nn_baryon_type , lmax_common_n_plus_one);
  Vso_n_basis_core_potential_tab.allocate (Nn_baryon_type , lmax_common_n_plus_one);
  dp_basis_tab.allocate (Np_baryon_type , lmax_p_plus_one);
  R0_p_basis_tab.allocate (Np_baryon_type , lmax_p_plus_one);
  Vo_p_basis_tab.allocate (Np_baryon_type , lmax_p_plus_one);
  Vso_p_basis_tab.allocate (Np_baryon_type , lmax_p_plus_one);
  dn_basis_tab.allocate (Nn_baryon_type , lmax_n_plus_one);
  R0_n_basis_tab.allocate (Nn_baryon_type , lmax_n_plus_one);
  Vo_n_basis_tab.allocate (Nn_baryon_type , lmax_n_plus_one);
  Vso_n_basis_tab.allocate (Nn_baryon_type , lmax_n_plus_one);
  d_basis_relative_tab.allocate (lmax_relative_plus_one);
  R0_basis_relative_tab.allocate (lmax_relative_plus_one);
  Vo_basis_relative_tab.allocate (lmax_relative_plus_one);
  Vso_basis_relative_tab.allocate (lmax_relative_plus_one);
  V_Gaussian_consts_basis.allocate (2 , Jmax_basis_plus_one , 2);
  V_Gaussian_consts.allocate (2 , Jmax_plus_one , 2);

  b_lab_partial_waves_p_tab.allocate (Np_baryon_type);
  b_lab_partial_waves_n_tab.allocate (Nn_baryon_type);
  
  for (unsigned int i = 0 ; i < Np_baryon_type ; i++) b_lab_partial_waves_p_tab(i).allocate (0.5 , lmax_p);
  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++) b_lab_partial_waves_n_tab(i).allocate (0.5 , lmax_n);

  prot_basis_J_tab.allocate (0.5 , lmax_p);
  neut_basis_J_tab.allocate (0.5 , lmax_n);
  GSM_multipoles_J_tab.allocate (GSM_multipoles_number);
  EM_J_IN_tab.allocate (EM_transitions_number);
  EM_J_OUT_tab.allocate (EM_transitions_number);
  EM_strength_J_IN_tab.allocate (EM_transitions_strength_number);
  EM_strength_J_OUT_tab.allocate (EM_transitions_strength_number);
  beta_J_IN_tab.allocate (beta_transitions_number);
  beta_J_OUT_tab.allocate (beta_transitions_number);
  beta_W0_tab.allocate (beta_transitions_number);
  beta_strength_J_IN_tab.allocate (beta_transitions_strength_number);
  beta_strength_J_OUT_tab.allocate (beta_transitions_strength_number);
  density_J_tab.allocate (density_number);
  correlation_density_J_tab.allocate (correlation_density_number);
  correlation_density_RKmax_tab.allocate (correlation_density_number);
  pair_density_J_tab.allocate (pair_density_number);
  pair_density_RKmax_tab.allocate (pair_density_number);
  spectroscopic_factor_J_IN_tab.allocate (spectroscopic_factor_number);
  spectroscopic_factor_J_OUT_tab.allocate (spectroscopic_factor_number);
  spectroscopic_factor_J_projectile_tab.allocate (spectroscopic_factor_number);
  overlap_function_J_IN_tab.allocate (overlap_function_number);
  overlap_function_J_OUT_tab.allocate (overlap_function_number);
  overlap_function_J_projectile_tab.allocate (overlap_function_number);
  rms_radius_J_tab.allocate (rms_radius_number);
  rms_radius_frozen_core_tab.allocate (rms_radius_number);
  rms_radius_one_body_strength_J_tab.allocate (rms_radius_one_body_strength_number);
  Hamiltonian_parts_J_tab.allocate (Hamiltonian_parts_eigenstates_number);
  Coulomb_isospin_mixture_J_tab.allocate (Coulomb_isospin_mixture_number);
  dagger_tilde_operators_J_IN_tab.allocate (dagger_tilde_operators_number);
  dagger_tilde_operators_J_OUT_tab.allocate (dagger_tilde_operators_number);
  CC_J_target_tab.allocate (CC_N_target_projectile_states);
  CC_real_E_intrinsic_projectile_tab.allocate (CC_N_target_projectile_states);
  CC_Gamma_intrinsic_projectile_tab.allocate (CC_N_target_projectile_states);
  CC_real_E_target_tab.allocate (CC_N_target_projectile_states);
  CC_Gamma_target_tab.allocate (CC_N_target_projectile_states);
  CC_partial_wave_J_cluster_projectile_tab.allocate (CC_N_target_projectile_states , CC_N_partial_waves_max);
  CC_J_A_composite_tab.allocate (CC_N_JPi_A_composite);
  CC_CM_angles.allocate (CC_N_CM_angles) ;
  CC_J_A_in_composite_tab.allocate (CC_N_JPi_A_in_composite);
  CC_J_A_out_composite_tab.allocate (CC_N_JPi_A_out_composite);
  CC_average_n_scat_target_projectile_max_J_A_composite_tab.allocate (CC_average_n_scat_target_projectile_max_composite_number);
  CC_average_n_scat_target_projectile_max_composite_tab.allocate (CC_average_n_scat_target_projectile_max_composite_number);
  CC_corrective_factors_TBMEs_J_A_composite_tab.allocate (CC_corrective_factors_TBMEs_composite_number);
  CC_corrective_factors_TBMEs_composite_tab.allocate (CC_corrective_factors_TBMEs_composite_number);
  CC_corrective_factors_cluster_J_A_composite_tab.allocate (CC_cluster_projectile_number , CC_corrective_factors_cluster_composite_numbers_max);
  CC_corrective_factors_cluster_composite_tab.allocate (CC_cluster_projectile_number , CC_corrective_factors_cluster_composite_numbers_max);
  V0_KKNN_p_tab.allocate (Np_baryon_type , 5);
  rho_KKNN_p_tab.allocate (Np_baryon_type , 5);
  V0_KKNN_basis_core_potential_p_tab.allocate (Np_baryon_type , 5);
  rho_KKNN_basis_core_potential_p_tab.allocate (Np_baryon_type , 5);
  V0_KKNN_n_tab.allocate (Nn_baryon_type , 5);
  rho_KKNN_n_tab.allocate (Nn_baryon_type , 5);
  V0_KKNN_basis_core_potential_n_tab.allocate (Nn_baryon_type , 5);
  rho_KKNN_basis_core_potential_n_tab.allocate (Nn_baryon_type , 5);
  Vls_KKNN_p_tab.allocate (Np_baryon_type , 3);
  rho_ls_KKNN_p_tab.allocate (Np_baryon_type , 3);
  Vls_KKNN_basis_core_potential_p_tab.allocate (Np_baryon_type , 3);
  rho_ls_KKNN_basis_core_potential_p_tab.allocate (Np_baryon_type , 3);
  Vls_KKNN_n_tab.allocate (Nn_baryon_type , 3);
  rho_ls_KKNN_n_tab.allocate (Nn_baryon_type , 3);
  Vls_KKNN_basis_core_potential_n_tab.allocate (Nn_baryon_type , 3);
  rho_ls_KKNN_basis_core_potential_n_tab.allocate (Nn_baryon_type , 3); 
  effective_charges_p.allocate (Np_baryon_type);
  effective_masses_for_calc_p.allocate (Np_baryon_type);
  effective_charges_n.allocate (Nn_baryon_type);
  effective_masses_for_calc_n.allocate (Nn_baryon_type);
}









void input_data_str::put_double_tables (class array<double> &T_double)
{
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);

  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
    
  const unsigned int Jmax_basis = Jmax_global_determine (true);

  const unsigned int Jmax = Jmax_global_determine (false);
  
  const unsigned int dimension_double = T_double.dimension (0); 

  unsigned int i_double = 0;

  for (unsigned int i = 0 ; i < natural_orbitals_reference_states_number ; i++)
    natural_orbitals_reference_states_J_tab(i) = T_double(i_double++);

  for (unsigned int i = 0 ; i < eigensets_number ; i++)
    J_eigenset_tab(i) = T_double(i_double++);

  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_common_p ; l++)
      {
	dp_core_potential_tab(i , l) = T_double(i_double++); 
	R0_p_core_potential_tab(i , l) = T_double(i_double++); 
	Vo_p_core_potential_tab(i , l) = T_double(i_double++); 
	Vso_p_core_potential_tab(i , l) = T_double(i_double++);
      }

  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_common_n ; l++)
      {
	dn_core_potential_tab(i , l) = T_double(i_double++); 
	R0_n_core_potential_tab(i , l) = T_double(i_double++); 
	Vo_n_core_potential_tab(i , l) = T_double(i_double++); 
	Vso_n_core_potential_tab(i , l) = T_double(i_double++);
      }

  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_common_p ; l++)
      {
	dp_basis_core_potential_tab(i , l) = T_double(i_double++); 
	R0_p_basis_core_potential_tab(i , l) = T_double(i_double++); 
	Vo_p_basis_core_potential_tab(i , l) = T_double(i_double++); 
	Vso_p_basis_core_potential_tab(i , l) = T_double(i_double++);
      }

  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_common_n ; l++)
      {
	dn_basis_core_potential_tab(i , l) = T_double(i_double++); 
	R0_n_basis_core_potential_tab(i , l) = T_double(i_double++); 
	Vo_n_basis_core_potential_tab(i , l) = T_double(i_double++); 
	Vso_n_basis_core_potential_tab(i , l) = T_double(i_double++);
      }


  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_p ; l++)
      {
	dp_basis_tab(i , l) = T_double(i_double++); 
	R0_p_basis_tab(i , l) = T_double(i_double++); 
	Vo_p_basis_tab(i , l) = T_double(i_double++); 
	Vso_p_basis_tab(i , l) = T_double(i_double++);
      }

  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_n ; l++)
      {
	dn_basis_tab(i , l) = T_double(i_double++); 
	R0_n_basis_tab(i , l) = T_double(i_double++); 
	Vo_n_basis_tab(i , l) = T_double(i_double++); 
	Vso_n_basis_tab(i , l) = T_double(i_double++);
      }
  
  for (int l = 0 ; l <= lmax_relative ; l++)
    {
      d_basis_relative_tab(l) = T_double(i_double++); 
      R0_basis_relative_tab(l) = T_double(i_double++); 
      Vo_basis_relative_tab(l) = T_double(i_double++); 
      Vso_basis_relative_tab(l) = T_double(i_double++);
    }

  for (unsigned int BP = 0 ; BP <= 1 ; BP++) 
    for (unsigned int J = 0 ; J <= Jmax_basis ; J++) 
      for (unsigned int T = 0 ; T <= 1 ; T++) 
	V_Gaussian_consts_basis(BP , J , T) = T_double(i_double++);

  for (unsigned int BP = 0 ; BP <= 1 ; BP++) 
    for (unsigned int J = 0 ; J <= Jmax ; J++) 
      for (unsigned int T = 0 ; T <= 1 ; T++)
	V_Gaussian_consts(BP , J , T) = T_double(i_double++);

  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_p ; l++)
      for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	b_lab_partial_waves_p_tab(i)(l , j) = T_double(i_double++); 
  
  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    for (int l = 0 ; l <= lmax_n ; l++)
      for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	b_lab_partial_waves_n_tab(i)(l , j) = T_double(i_double++);
 
  for (int l = 0 ; l <= lmax_p ; l++)
    for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      prot_basis_J_tab(l , j) = T_double(i_double++); 

  for (int l = 0 ; l <= lmax_n ; l++)
    for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      neut_basis_J_tab(l , j) = T_double(i_double++);

  for (unsigned int i = 0 ; i < GSM_multipoles_number ; i++) 
    GSM_multipoles_J_tab(i) = T_double(i_double++);

  for (unsigned int i = 0 ; i < EM_transitions_number ; i++) 
    {
      EM_J_IN_tab(i) = T_double(i_double++); 
      EM_J_OUT_tab(i) = T_double(i_double++);
    }

  for (unsigned int i = 0 ; i < EM_transitions_strength_number ; i++) 
    {
      EM_strength_J_IN_tab(i) = T_double(i_double++); 
      EM_strength_J_OUT_tab(i) = T_double(i_double++);
    }

  for (unsigned int i = 0 ; i < beta_transitions_number ; i++) 
    {
      beta_J_IN_tab(i) = T_double(i_double++); 
      beta_J_OUT_tab(i) = T_double(i_double++); 
      beta_W0_tab(i) = T_double(i_double++);
    }

  for (unsigned int i = 0 ; i < beta_transitions_strength_number ; i++)
    {
      beta_strength_J_IN_tab(i) = T_double(i_double++); 
      beta_strength_J_OUT_tab(i) = T_double(i_double++);
    }

  for (unsigned int i = 0 ; i < density_number ; i++) 
    density_J_tab(i) = T_double(i_double++);

  for (unsigned int i = 0 ; i < correlation_density_number ; i++)
    {
      correlation_density_J_tab(i) = T_double(i_double++);
      correlation_density_RKmax_tab(i) = T_double(i_double++);
    }
  
  for (unsigned int i = 0 ; i < pair_density_number ; i++)
    {
      pair_density_J_tab(i) = T_double(i_double++);
      pair_density_RKmax_tab(i) = T_double(i_double++);
    }
    
  for (unsigned int i = 0 ; i < spectroscopic_factor_number ; i++) 
    {
      spectroscopic_factor_J_IN_tab(i) = T_double(i_double++); 
      spectroscopic_factor_J_OUT_tab(i) = T_double(i_double++); 
      spectroscopic_factor_J_projectile_tab(i) = T_double(i_double++);
    }

  for (unsigned int i = 0 ; i < overlap_function_number ; i++) 
    {
      overlap_function_J_IN_tab(i) = T_double(i_double++); 
      overlap_function_J_OUT_tab(i) = T_double(i_double++); 
      overlap_function_J_projectile_tab(i) = T_double(i_double++);
    }

  for (unsigned int i = 0 ; i < rms_radius_number ; i++) 
    {
      rms_radius_J_tab(i) = T_double(i_double++); 
      rms_radius_frozen_core_tab(i) = T_double(i_double++);
    }

  for (unsigned int i = 0 ; i < rms_radius_one_body_strength_number ; i++) 
    rms_radius_one_body_strength_J_tab(i) = T_double(i_double++);

  for (unsigned int i = 0 ; i < Hamiltonian_parts_eigenstates_number ; i++) 
    Hamiltonian_parts_J_tab(i) = T_double(i_double++);

  for (unsigned int i = 0 ; i < Coulomb_isospin_mixture_number ; i++) 
    Coulomb_isospin_mixture_J_tab(i) = T_double(i_double++); 

  for (unsigned int i = 0 ; i < dagger_tilde_operators_number ; i++) 
    {
      dagger_tilde_operators_J_IN_tab(i) = T_double(i_double++); 
      dagger_tilde_operators_J_OUT_tab(i) = T_double(i_double++);
    }

  for (unsigned int iT = 0 ; iT < CC_N_target_projectile_states ; iT++)
    {
      CC_J_target_tab(iT) = T_double(i_double++); 
      CC_real_E_intrinsic_projectile_tab(iT) = T_double(i_double++); 
      CC_Gamma_intrinsic_projectile_tab(iT) = T_double(i_double++); 
      CC_real_E_target_tab(iT) = T_double(i_double++); 
      CC_Gamma_target_tab(iT) = T_double(i_double++);

      for (unsigned int i = 0 ; i < CC_N_partial_waves_max ; i++)
	CC_partial_wave_J_cluster_projectile_tab(iT , i) = T_double(i_double++);
    }

  for (unsigned int i = 0 ; i < CC_N_JPi_A_composite ; i++)
    CC_J_A_composite_tab(i) = T_double(i_double++);

  for (unsigned int i = 0 ; i < CC_N_CM_angles ; i++)
    CC_CM_angles(i) = T_double(i_double++);

  for (unsigned int i = 0 ; i < CC_N_JPi_A_in_composite ; i++)
    CC_J_A_in_composite_tab(i) = T_double(i_double++);

  for (unsigned int i = 0 ; i < CC_N_JPi_A_out_composite ; i++)
    CC_J_A_out_composite_tab(i) = T_double(i_double++);

  for (unsigned int i = 0 ; i < CC_average_n_scat_target_projectile_max_composite_number ; i++)
    {
      CC_average_n_scat_target_projectile_max_J_A_composite_tab(i) = T_double(i_double++);
      CC_average_n_scat_target_projectile_max_composite_tab(i) = T_double(i_double++);
    }
  
  for (unsigned int i = 0 ; i < CC_corrective_factors_TBMEs_composite_number ; i++)
    {
      CC_corrective_factors_TBMEs_J_A_composite_tab(i) = T_double(i_double++);
      CC_corrective_factors_TBMEs_composite_tab(i) = T_double(i_double++);
    }
  
  for (unsigned int i = 0 ; i < CC_cluster_projectile_number ; i++)
    for (unsigned int ii = 0 ; ii < CC_corrective_factors_cluster_composite_numbers_max ; ii++)
      {
	CC_corrective_factors_cluster_J_A_composite_tab(i , ii) = T_double(i_double++); 
	CC_corrective_factors_cluster_composite_tab(i , ii) = T_double(i_double++);
      }
    
  for (unsigned int ii = 0 ; ii < 5 ; ii++)
    {
      for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
	{
	  V0_KKNN_p_tab(i , ii) = T_double(i_double++);
	  rho_KKNN_p_tab(i , ii) = T_double(i_double++);
	  
	  V0_KKNN_basis_core_potential_p_tab(i , ii) = T_double(i_double++);
	  rho_KKNN_basis_core_potential_p_tab(i , ii) = T_double(i_double++);
	}
	  
      for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
	{
	  V0_KKNN_n_tab(i , ii) = T_double(i_double++);
	  rho_KKNN_n_tab(i , ii) = T_double(i_double++);	  
	  
	  V0_KKNN_basis_core_potential_n_tab(i , ii) = T_double(i_double++);
	  rho_KKNN_basis_core_potential_n_tab(i , ii) = T_double(i_double++);
	}
    }
	    
  for (unsigned int ii = 0 ; ii < 3 ; ii++)
    { 
      for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
	{
	  Vls_KKNN_p_tab(i , ii) = T_double(i_double++);
	  rho_ls_KKNN_p_tab(i , ii) = T_double(i_double++);
	  
	  Vls_KKNN_basis_core_potential_p_tab(i , ii) = T_double(i_double++);
	  rho_ls_KKNN_basis_core_potential_p_tab(i , ii) = T_double(i_double++);
	}
      
      for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
	{
	  Vls_KKNN_n_tab(i , ii) = T_double(i_double++);
	  rho_ls_KKNN_n_tab(i , ii) = T_double(i_double++);	  
	  
	  Vls_KKNN_basis_core_potential_n_tab(i , ii) = T_double(i_double++);
	  rho_ls_KKNN_basis_core_potential_n_tab(i , ii) = T_double(i_double++);
	}
    }
  
  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    {
      effective_charges_p(i) = T_double(i_double++);
      effective_masses_for_calc_p(i) = T_double(i_double++);
    }
  
  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    {
      effective_charges_n(i) = T_double(i_double++);
      effective_masses_for_calc_n(i) = T_double(i_double++);
    }
  
  if (i_double != dimension_double)    
    error_message_print_abort ("i_double=" + make_string<unsigned int> (i_double) + " != dimension_double=" + make_string<unsigned int> (dimension_double) + " in input_data_str::put_double_tables.");
}
















// always complex<double>
unsigned int input_data_str::dimension_complex_tabs_calc () const
{
  const unsigned int CC_Lmax_all_plus_one = CC_Lmax_all + 1;

  const unsigned int dimension_complex = CC_N_target_projectile_states + 3*CC_cluster_projectile_number*CC_Lmax_all_plus_one*CC_J_number_max_all;

  return dimension_complex;
}




void input_data_str::get_complex_tables (class array<complex<double> > &T_complex) const
{
  const unsigned int dimension_complex = T_complex.dimension (0); 

  unsigned int i_complex = 0;

  for (unsigned int ic = 0 ; ic < CC_cluster_projectile_number ; ic++)
    for (int L = 0 ; L <= CC_Lmax_all ; L++)
      for (unsigned int J_index = 0 ; J_index < CC_J_number_max_all ; J_index++)
	{
	  T_complex(i_complex++) = CC_K_peak_cluster_projectile_CM_tab(ic , L , J_index);
	  T_complex(i_complex++) = CC_K_middle_cluster_projectile_CM_tab(ic , L , J_index);
	  T_complex(i_complex++) = CC_K_max_cluster_projectile_CM_tab(ic , L , J_index);
	}

  for (unsigned int iT = 0 ; iT < CC_N_target_projectile_states ; iT++)
    T_complex(i_complex++) = CC_average_n_scat_target_tab(iT);
  
  if (i_complex != dimension_complex)
    error_message_print_abort ("i_complex=" + make_string<unsigned int> (i_complex) + " != dimension_complex=" + make_string<unsigned int> (dimension_complex) + " in input_data_str::get_complex_tables.");
}





void input_data_str::alloc_complex_tables ()
{
  const unsigned int CC_Lmax_all_plus_one = CC_Lmax_all + 1;

  CC_average_n_scat_target_tab.allocate (CC_N_target_projectile_states);
  CC_K_peak_cluster_projectile_CM_tab.allocate (CC_cluster_projectile_number , CC_Lmax_all_plus_one , CC_J_number_max_all);
  CC_K_middle_cluster_projectile_CM_tab.allocate (CC_cluster_projectile_number , CC_Lmax_all_plus_one , CC_J_number_max_all);
  CC_K_max_cluster_projectile_CM_tab.allocate (CC_cluster_projectile_number , CC_Lmax_all_plus_one , CC_J_number_max_all);
}






void input_data_str::put_complex_tables (class array<complex<double> > &T_complex)
{	
  const unsigned int dimension_complex = T_complex.dimension (0); 

  unsigned int i_complex = 0;

  for (unsigned int ic = 0 ; ic < CC_cluster_projectile_number ; ic++)
    for (int L = 0 ; L <= CC_Lmax_all ; L++)
      for (unsigned int J_index = 0 ; J_index < CC_J_number_max_all ; J_index++)
	{
	  CC_K_peak_cluster_projectile_CM_tab(ic , L , J_index) = T_complex(i_complex++);
	  CC_K_middle_cluster_projectile_CM_tab(ic , L , J_index) = T_complex(i_complex++);
	  CC_K_max_cluster_projectile_CM_tab(ic , L , J_index) = T_complex(i_complex++);
	}

  for (unsigned int iT = 0 ; iT < CC_N_target_projectile_states ; iT++)
    CC_average_n_scat_target_tab(iT) = T_complex(i_complex++);
      
  if (i_complex != dimension_complex) 
    error_message_print_abort ("i_complex=" + make_string<unsigned int> (i_complex) + " != dimension_complex=" + make_string<unsigned int> (dimension_complex) + " in input_data_str::put_complex_tables.");
}





void input_data_str::copy_unsigned_int_constants (const class input_data_str &X)
{
  const unsigned int dimension_unsigned_int = get_dimension_unsigned_int_constants ();

  class array<unsigned int> T_unsigned_int(dimension_unsigned_int);

  X.get_unsigned_int_constants (T_unsigned_int);

  put_unsigned_int_constants (T_unsigned_int);
}

void input_data_str::copy_int_constants (const class input_data_str &X)
{
  const unsigned int dimension_int = get_dimension_int_constants ();

  class array<int> T_int(dimension_int);

  X.get_int_constants (T_int);

  put_int_constants (T_int);
}

void input_data_str::copy_bool_constants (const class input_data_str &X)
{
  const unsigned int dimension_bool = get_dimension_bool_constants ();

  class array<bool> T_bool(dimension_bool);

  X.get_bool_constants (T_bool);

  put_bool_constants (T_bool);
}

void input_data_str::copy_double_constants (const class input_data_str &X)
{
  const unsigned int dimension_double = get_dimension_double_constants ();

  class array<double> T_double(dimension_double);

  X.get_double_constants (T_double);

  put_double_constants (T_double);
}






void input_data_str::copy_alloc_unsigned_int_tables (const class input_data_str &X)
{
  const unsigned int dimension_unsigned_int = X.dimension_unsigned_int_tabs_calc ();

  if (dimension_unsigned_int == 0) return;

  class array<unsigned int> T_unsigned_int(dimension_unsigned_int);

  X.get_unsigned_int_tables (T_unsigned_int);

  alloc_unsigned_int_tables ();

  put_unsigned_int_tables (T_unsigned_int);
}

void input_data_str::copy_alloc_int_tables (const class input_data_str &X)
{
  const unsigned int dimension_int = X.dimension_int_tabs_calc ();

  if (dimension_int == 0) return;

  class array<int> T_int(dimension_int);
  
  X.get_int_tables (T_int);

  alloc_int_tables ();

  put_int_tables (T_int);
}

void input_data_str::copy_alloc_bool_tables (const class input_data_str &X)
{
  const unsigned int dimension_bool = X.dimension_bool_tabs_calc ();

  if (dimension_bool == 0) return;

  class array<bool> T_bool(dimension_bool);

  X.get_bool_tables (T_bool);

  alloc_bool_tables ();

  put_bool_tables (T_bool);
}

void input_data_str::copy_alloc_double_tables (const class input_data_str &X)
{
  const unsigned int dimension_double = X.dimension_double_tabs_calc ();

  if (dimension_double == 0) return;

  class array<double> T_double(dimension_double);

  X.get_double_tables (T_double);

  alloc_double_tables ();

  put_double_tables (T_double);
}

// always complex<double>
void input_data_str::copy_alloc_complex_tables (const class input_data_str &X)
{
  const unsigned int dimension_complex = X.dimension_complex_tabs_calc ();

  if (dimension_complex == 0) return;

  class array<complex<double> > T_complex(dimension_complex);

  X.get_complex_tables (T_complex);

  alloc_complex_tables ();

  put_complex_tables (T_complex);
}




void input_data_str::optimization_common_data_alloc_copy (const class input_data_str &input_data_common)
{
  const bool is_it_HF_basis = (basis_potential == HF);
  
  const bool is_it_MSDHF_basis = (basis_potential == MSDHF);

  const bool is_it_HF_MSDHF_basis = (is_it_HF_basis || is_it_MSDHF_basis);
  
  const class array<double> &dp_core_potential_tab_common    = input_data_common.dp_core_potential_tab;
  const class array<double> &R0_p_core_potential_tab_common  = input_data_common.R0_p_core_potential_tab;
  const class array<double> &Vo_p_core_potential_tab_common  = input_data_common.Vo_p_core_potential_tab;
  const class array<double> &Vso_p_core_potential_tab_common = input_data_common.Vso_p_core_potential_tab;

  const class array<double> &dn_core_potential_tab_common    = input_data_common.dn_core_potential_tab;
  const class array<double> &R0_n_core_potential_tab_common  = input_data_common.R0_n_core_potential_tab;
  const class array<double> &Vo_n_core_potential_tab_common  = input_data_common.Vo_n_core_potential_tab;
  const class array<double> &Vso_n_core_potential_tab_common = input_data_common.Vso_n_core_potential_tab;
  
  const class array<double> &dp_basis_core_potential_tab_common    = input_data_common.dp_basis_core_potential_tab;
  const class array<double> &R0_p_basis_core_potential_tab_common  = input_data_common.R0_p_basis_core_potential_tab;
  const class array<double> &Vo_p_basis_core_potential_tab_common  = input_data_common.Vo_p_basis_core_potential_tab;
  const class array<double> &Vso_p_basis_core_potential_tab_common = input_data_common.Vso_p_basis_core_potential_tab;

  const class array<double> &dn_basis_core_potential_tab_common    = input_data_common.dn_basis_core_potential_tab;
  const class array<double> &R0_n_basis_core_potential_tab_common  = input_data_common.R0_n_basis_core_potential_tab;
  const class array<double> &Vo_n_basis_core_potential_tab_common  = input_data_common.Vo_n_basis_core_potential_tab;
  const class array<double> &Vso_n_basis_core_potential_tab_common = input_data_common.Vso_n_basis_core_potential_tab;
     
  const enum potential_type H_potential_common = input_data_common.H_potential;

  const class array<int> &nmax_HO_lab_tab_common = input_data_common.nmax_HO_lab_tab;
  
  const class array<int> &nmax_GHF_lab_tab_common = input_data_common.nmax_GHF_lab_tab;

  const class array<int> &nmax_HO_relative_tab_common = input_data_common.nmax_HO_relative_tab;

  const class array<double> &V_Gaussian_consts_common = input_data_common.V_Gaussian_consts;

  if (is_it_HF_MSDHF_basis)
    {
      const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);

      const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
      
      for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
	{	  
	  class lj_table<enum potential_type> &basis_potential_partial_waves_p = basis_potential_partial_waves_p_tab(i);
	  
	  for (int l = 0 ; l <= lmax_p ; l++)
	    for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	      {
		if (basis_potential_partial_waves_p(l , j) == NO_POTENTIAL) basis_potential_partial_waves_p(l , j) = H_potential_common;
	      }		
	}
      
      for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
	{
	  class lj_table<enum potential_type> &basis_potential_partial_waves_n = basis_potential_partial_waves_n_tab(i);
	  
	  for (int l = 0 ; l <= lmax_n ; l++)
	    for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	      {
		if (basis_potential_partial_waves_n(l , j) == NO_POTENTIAL) basis_potential_partial_waves_n(l , j) = H_potential_common;
	      }		
	}    
    }

  dp_core_potential_tab.allocate_fill    (dp_core_potential_tab_common);
  R0_p_core_potential_tab.allocate_fill  (R0_p_core_potential_tab_common);
  Vo_p_core_potential_tab.allocate_fill  (Vo_p_core_potential_tab_common);
  Vso_p_core_potential_tab.allocate_fill (Vso_p_core_potential_tab_common);

  dn_core_potential_tab.allocate_fill    (dn_core_potential_tab_common);
  R0_n_core_potential_tab.allocate_fill  (R0_n_core_potential_tab_common);
  Vo_n_core_potential_tab.allocate_fill  (Vo_n_core_potential_tab_common);
  Vso_n_core_potential_tab.allocate_fill (Vso_n_core_potential_tab_common);
  
  dp_basis_core_potential_tab.allocate_fill    (dp_basis_core_potential_tab_common);
  R0_p_basis_core_potential_tab.allocate_fill  (R0_p_basis_core_potential_tab_common);
  Vo_p_basis_core_potential_tab.allocate_fill  (Vo_p_basis_core_potential_tab_common);
  Vso_p_basis_core_potential_tab.allocate_fill (Vso_p_basis_core_potential_tab_common);

  dn_basis_core_potential_tab.allocate_fill    (dn_basis_core_potential_tab_common);
  R0_n_basis_core_potential_tab.allocate_fill  (R0_n_basis_core_potential_tab_common);
  Vo_n_basis_core_potential_tab.allocate_fill  (Vo_n_basis_core_potential_tab_common);
  Vso_n_basis_core_potential_tab.allocate_fill (Vso_n_basis_core_potential_tab_common);
   
  V0_KKNN_p_tab.allocate_fill     (input_data_common.V0_KKNN_p_tab);      
  rho_KKNN_p_tab.allocate_fill    (input_data_common.rho_KKNN_p_tab);
  Vls_KKNN_p_tab.allocate_fill    (input_data_common.Vls_KKNN_p_tab);
  rho_ls_KKNN_p_tab.allocate_fill (input_data_common.rho_ls_KKNN_p_tab);
  
  V0_KKNN_n_tab.allocate_fill     (input_data_common.V0_KKNN_n_tab);      
  rho_KKNN_n_tab.allocate_fill    (input_data_common.rho_KKNN_n_tab);
  Vls_KKNN_n_tab.allocate_fill    (input_data_common.Vls_KKNN_n_tab);
  rho_ls_KKNN_n_tab.allocate_fill (input_data_common.rho_ls_KKNN_n_tab);

  V0_KKNN_basis_core_potential_p_tab.allocate_fill     (input_data_common.V0_KKNN_basis_core_potential_p_tab);      
  rho_KKNN_basis_core_potential_p_tab.allocate_fill    (input_data_common.rho_KKNN_basis_core_potential_p_tab);
  Vls_KKNN_basis_core_potential_p_tab.allocate_fill    (input_data_common.Vls_KKNN_basis_core_potential_p_tab);
  rho_ls_KKNN_basis_core_potential_p_tab.allocate_fill (input_data_common.rho_ls_KKNN_basis_core_potential_p_tab);
  
  V0_KKNN_basis_core_potential_n_tab.allocate_fill     (input_data_common.V0_KKNN_basis_core_potential_n_tab);      
  rho_KKNN_basis_core_potential_n_tab.allocate_fill    (input_data_common.rho_KKNN_basis_core_potential_n_tab);
  Vls_KKNN_basis_core_potential_n_tab.allocate_fill    (input_data_common.Vls_KKNN_basis_core_potential_n_tab);
  rho_ls_KKNN_basis_core_potential_n_tab.allocate_fill (input_data_common.rho_ls_KKNN_basis_core_potential_n_tab);
 
  effective_charges_p.allocate_fill (input_data_common.effective_charges_p);
  effective_charges_n.allocate_fill (input_data_common.effective_charges_n);
  
  V0_ctr_ot = input_data_common.V0_ctr_ot;
  V0_ctr_et = input_data_common.V0_ctr_et;
  V0_ctr_os = input_data_common.V0_ctr_os;
  V0_ctr_es = input_data_common.V0_ctr_es;
  V0_so_ot  = input_data_common.V0_so_ot;
  V0_so_et  = input_data_common.V0_so_et;
  V0_t_ot   = input_data_common.V0_t_ot;
  V0_t_et   = input_data_common.V0_t_et;

  V_Gaussian_consts.allocate_fill (V_Gaussian_consts_common);
  
  nmax_HO_lab_tab.allocate_fill (nmax_HO_lab_tab_common);
  
  nmax_GHF_lab_tab.allocate_fill (nmax_GHF_lab_tab_common);

  nmax_HO_relative_tab.allocate_fill (nmax_HO_relative_tab_common);

  b_lab_basis = input_data_common.b_lab_basis;

  b_lab = input_data_common.b_lab;
    
  only_dimensions = input_data_common.only_dimensions;
  
  non_zero_NBMEs_proportion_only = input_data_common.non_zero_NBMEs_proportion_only;
  
  H_potential = H_potential_common;

  lmax_for_basis_interaction = input_data_common.lmax_for_basis_interaction;

  lmax_for_interaction = input_data_common.lmax_for_interaction;
  
  lmax_common_p = input_data_common.lmax_p;
  lmax_common_n = input_data_common.lmax_n;

  basis_interaction_parameters_alloc_copy_from_Hamiltonian ();
}








// enums are considered as int for transfer.

#ifdef UseMPI

void input_data_str::MPI_Bcast_unsigned_int_constants ()
{
  const unsigned int dimension_unsigned_int = get_dimension_unsigned_int_constants ();

  class array<unsigned int> T_unsigned_int(dimension_unsigned_int);

  if (THIS_PROCESS == MASTER_PROCESS) get_unsigned_int_constants (T_unsigned_int);

  T_unsigned_int.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

  if (THIS_PROCESS != MASTER_PROCESS) put_unsigned_int_constants (T_unsigned_int);
}

void input_data_str::MPI_Bcast_int_constants ()
{
  const unsigned int dimension_int = get_dimension_int_constants ();

  class array<int> T_int(dimension_int);

  if (THIS_PROCESS == MASTER_PROCESS) get_int_constants (T_int);

  T_int.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

  if (THIS_PROCESS != MASTER_PROCESS) put_int_constants (T_int);
}

void input_data_str::MPI_Bcast_bool_constants ()
{
  const unsigned int dimension_bool = get_dimension_bool_constants ();

  class array<bool> T_bool(dimension_bool);

  if (THIS_PROCESS == MASTER_PROCESS) get_bool_constants (T_bool);

  T_bool.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

  if (THIS_PROCESS != MASTER_PROCESS) put_bool_constants (T_bool);
}

void input_data_str::MPI_Bcast_double_constants ()
{
  const unsigned int dimension_double = get_dimension_double_constants ();

  class array<double> T_double(dimension_double);

  if (THIS_PROCESS == MASTER_PROCESS) get_double_constants (T_double);

  T_double.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

  if (THIS_PROCESS != MASTER_PROCESS) put_double_constants (T_double);
}





void input_data_str::MPI_Bcast_alloc_unsigned_int_tables ()
{
  const unsigned int dimension_unsigned_int = dimension_unsigned_int_tabs_calc ();

  if (dimension_unsigned_int == 0) return;

  class array<unsigned int> T_unsigned_int(dimension_unsigned_int);

  if (THIS_PROCESS == MASTER_PROCESS) get_unsigned_int_tables (T_unsigned_int);
  
  T_unsigned_int.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
  
  if (THIS_PROCESS != MASTER_PROCESS)
    {	
      alloc_unsigned_int_tables ();

      put_unsigned_int_tables (T_unsigned_int);
    }
}




void input_data_str::MPI_Bcast_alloc_int_tables ()
{				
  const unsigned int dimension_int = dimension_int_tabs_calc ();

  if (dimension_int == 0) return;

  class array<int> T_int(dimension_int);

  if (THIS_PROCESS == MASTER_PROCESS) get_int_tables (T_int);

  T_int.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
  
  if (THIS_PROCESS != MASTER_PROCESS)
    {
      alloc_int_tables ();

      put_int_tables (T_int);
    }
}




void input_data_str::MPI_Bcast_alloc_bool_tables ()
{
  const unsigned int dimension_bool = dimension_bool_tabs_calc ();

  if (dimension_bool == 0) return;

  class array<bool> T_bool(dimension_bool);

  if (THIS_PROCESS == MASTER_PROCESS) get_bool_tables (T_bool);

  T_bool.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

  if (THIS_PROCESS != MASTER_PROCESS)
    {
      alloc_bool_tables ();

      put_bool_tables (T_bool);
    }
}

void input_data_str::MPI_Bcast_alloc_double_tables ()
{
  const unsigned int dimension_double = dimension_double_tabs_calc ();

  if (dimension_double == 0) return;
  
  class array<double> T_double(dimension_double);   

  if (THIS_PROCESS == MASTER_PROCESS) get_double_tables (T_double);
  
  T_double.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

  if (THIS_PROCESS != MASTER_PROCESS)
    {
      alloc_double_tables ();

      put_double_tables (T_double);
    }
}

// always complex<double>
void input_data_str::MPI_Bcast_alloc_complex_tables ()
{ 
  const unsigned int dimension_complex = dimension_complex_tabs_calc ();

  if (dimension_complex == 0) return;

  class array<complex<double> > T_complex(dimension_complex);

  if (THIS_PROCESS == MASTER_PROCESS) get_complex_tables (T_complex);

  T_complex.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

  if (THIS_PROCESS != MASTER_PROCESS)
    {
      alloc_complex_tables ();

      put_complex_tables (T_complex);
    }
}





void input_data_str::MPI_Bcast_constants_alloc_tables ()
{
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);
      
  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
	  
  MPI_Bcast_unsigned_int_constants ();
  if (THIS_PROCESS == MASTER_PROCESS) cout << "unsigned int constants transferred" << endl;
    
  MPI_Bcast_int_constants ();
  if (THIS_PROCESS == MASTER_PROCESS) cout << "int constants transferred" << endl;
  
  MPI_Bcast_bool_constants (); 
  if (THIS_PROCESS == MASTER_PROCESS) cout << "bool constants transferred" << endl;

  MPI_Bcast_double_constants ();
  if (THIS_PROCESS == MASTER_PROCESS) cout << "double constants transferred" << endl;
  
  MPI_Bcast_alloc_unsigned_int_tables ();
  if (THIS_PROCESS == MASTER_PROCESS) cout << "unsigned int tables transferred" << endl;
  
  MPI_Bcast_alloc_int_tables ();
  if (THIS_PROCESS == MASTER_PROCESS) cout << "int tables transferred" << endl;
  
  MPI_Bcast_alloc_bool_tables (); 
  if (THIS_PROCESS == MASTER_PROCESS) cout << "bool tables transferred" << endl;
  
  MPI_Bcast_alloc_double_tables ();
  if (THIS_PROCESS == MASTER_PROCESS) cout << "double tables transferred" << endl;
      
  MPI_Bcast_alloc_complex_tables ();
  if (THIS_PROCESS == MASTER_PROCESS) cout << "complex tables transferred" << endl;

  //shells_quantum_numbers and PSI_qn_from_file_tab tables are transferred separately as one needs to commit an MPI structure for it
	  
  if (THIS_PROCESS != MASTER_PROCESS)
    {
      if (basis_space != NEUT_Y_ONLY)
	{
	  shells_quantum_numbers_p_tab.allocate (Np_baryon_type);
	  
	  for (unsigned int i = 0 ; i < Np_baryon_type ; i++) shells_quantum_numbers_p_tab(i).allocate (Np_nlj_baryon_tab(i));
	}
      
      if (basis_space != PROT_Y_ONLY)
	{	  
	  shells_quantum_numbers_n_tab.allocate (Nn_baryon_type);
	  
	  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++) shells_quantum_numbers_n_tab(i).allocate (Nn_nlj_baryon_tab(i));
	}
      
      PSI_qn_from_file_tab.allocate (eigensets_number , eigenset_vectors_number_max);

      shells_quantum_numbers_relative.allocate (N_nlj_relative);
    }
    
  MPI_Datatype MPI_nlj_struct = MPI_Datatype_nlj_struct_create ();

  MPI_Datatype MPI_correlated_state_str = MPI_Datatype_correlated_state_str_create ();

  MPI_helper::Type_commit (MPI_nlj_struct);

  MPI_helper::Type_commit (MPI_correlated_state_str);
  
  if (basis_space != NEUT_Y_ONLY)
    {	
      for (unsigned int i = 0 ; i < Np_baryon_type ; i++) shells_quantum_numbers_p_tab(i).MPI_Bcast (MASTER_PROCESS , MPI_nlj_struct , MPI_COMM_WORLD);
    }
  
  if (basis_space != PROT_Y_ONLY)
    {            
      for (unsigned int i = 0 ; i < Nn_baryon_type ; i++) shells_quantum_numbers_n_tab(i).MPI_Bcast (MASTER_PROCESS , MPI_nlj_struct , MPI_COMM_WORLD);
    }
  
  PSI_qn_from_file_tab.MPI_Bcast (MASTER_PROCESS , MPI_correlated_state_str , MPI_COMM_WORLD);
    
  shells_quantum_numbers_relative.MPI_Bcast (MASTER_PROCESS , MPI_nlj_struct , MPI_COMM_WORLD);

  MPI_helper::Type_free (MPI_nlj_struct);

  MPI_helper::Type_free (MPI_correlated_state_str);
      
  if (THIS_PROCESS == MASTER_PROCESS) cout << "shells/PSI quantum numbers tables transferred" << endl << endl;  
}

#endif


