#include "../GSM_include/GSM_include_def_common.h"

using namespace string_routines;
using namespace inputs_misc;

// TYPE is double or complex
// -------------------------

// See baryons_data.h for definitions of its members

// Constructors of the class baryons_data
// ---------------------------------------
// baryons : proton, neutron, or hyperon (Lambda, Sigma +/0/-, Xi 0/-, Omega-).
// This class can then be used for nuclei or hypernuclei.
// One uses the standard notations N for nucleon and Y for hyperon.
// Fo example one writes NN/YN/YY two-body interactions.
//
// As one typically has one or two hyperons in hypernuclei, they are added to the proton or neutron part.
// This way, no additional Slater determinant is created as the hyperons are put in the proton or neutron Slater determinant similarly to isospin formalism.
// Particle type is used as an additional quantum number (as isospin in isospin formalism) and allows to take into account antisymmetry exactly.
// As the number of particles in the class baryons_data remains small, this scheme is numerically efficient.
// Thus, when it is written p, pp, n, nn, it can mean proton/hyperon, proton/hyperon-proton/hyperon, neutron/hyperon, neutron/hyperon-neutron/hyperon, respectively.
// However, prot/neut always means proton/neutron in variables names.
// As hyperons can be considered in the proton or neutron class, one writes prot_Y/neut_Y.
// Nevertheless, one uses p,n and pp/nn/pn for proton neutron and proton-proton, neutron-neutron, proton-neutron, respectively, in routines explicitly dealing with nucleons (routines whose name read ...NN... for example)
// 
// A class member is typically denoted as particles_data (only protons plus a few hyperons if any, or only neutrons plus a few hyperons if any),
// prot_data (only protons), neut_data (only_neutrons), prot_Y_data (protons plus a few hyperons if any), neut_Y_data (neutrons plus a few hyperons if any).
// By convention, one puts charged/uncharged hyperons in the prot_Y_data/neut_Y_data classes.
//
// Nucleon conversion is allowed, i.e. Lambda-proton/Sigma 0 - neutron, Lambda-neutron/Sigma- - proton, Lambda-Lambda/Xi-nucleon, etc, interactions can be included.
// Strangeness and charge only must be conserved.
// However, the number of baryons in the proton and neutron parts must be conserved.
// To verify the last requirements in all cases, one occupies additional spectator proton or neutron states.
// As one uses two-body interactions, his generates equivalent 4p-4h ppnn excitations involving spectator proton and/or neutron states which take care of two-body conversions.
// Particle conversion is not considered at HF level.
//
// This class is used as a bag class, where all data related to either protons, neutrons, Lambda, Sigma, Xi, Omega particles or two-body systems such as dineutron, diproton and deuteron, are stored.
// Hence, arrays are not allocated at the beginning and they are allocated somewhere else in the code.

baryons_data::baryons_data () :
  is_it_M_scheme (false) , 
  is_Coulomb_Hamiltonian_here (false) ,
  are_there_basis_natural_orbitals (false) , 
  are_there_new_natural_orbitals (false) ,  
  nucleonic_particle (NO_PARTICLE) ,
  hypernucleus_strangeness (0) , 
  n_spec_max (0) , 
  nmax (0) , 
  lmax (0) , 
  n_scat_max (0) , 
  n_holes_max (0) , 
  n_holes_max_pole_approximation (0) , 
  E_min_hw (0) , 
  E_max_hw (0) , 
  E_max_hw_pole_approximation (0) , 
  A_core (0) , 
  Z_core (0) , 
  N_core (0) , 
  A (0) , 
  Z (0) , 
  N (0) , 
  A_basis (0) , 
  Z_basis (0) , 
  N_basis (0) , 
  hole_states_number (0) ,
  N_nucleons (0) ,  
  N_valence_nucleons (0) , 
  N_valence_nucleons_basis (0) , 
  N_valence_baryons (0) , 
  N_valence_baryons_1h (0) , 
  N_valence_baryons_2h (0) , 
  ZY_charge_pos (0) ,
  ZY_charge_neg (0) ,  
  ZY_charge_basis_potential_pos (0) , 
  ZY_charge_basis_potential_neg (0) , 
  nucleus_mass (0) , 
  nucleus_mass_basis (0) , 
  total_nucleus_mass (0) , 
  N_nlj_baryon (0) , 
  N_nljm_baryon (0) , 
  N_nlj_res_baryon (0) , 
  N_nljm_res_baryon (0) , 
  natural_orbitals_reference_states_number (0) , 
  jmax (0) , 
  m_min (0) , 
  m_max (0) , 
  M_max (0) , 
  M_max_1h (0) , 
  M_max_2h (0) , 
  m_max_minus_half (0) , 
  two_m_max (0) , 
  four_m_max (0) , 
  m_max_minus_m_min (0) , 
  iM_max (0) , 
  iM_max_1h (0) , 
  iM_max_2h (0) , 
  debut_file_name (""),
  R_charge (0) , 
  basis_potential (NO_POTENTIAL) , 
  H_potential (NO_POTENTIAL) , 
  good_isospin_basis_potential (false) ,
  is_it_OCM_HO_core (false) ,
  N_bef_R_GL (0) , 
  N_aft_R_GL (0) , 
  N_bef_R_uniform (0) , 
  N_aft_R_uniform (0) , 
  R (0) , 
  step_bef_R_uniform (0) ,
  R_real_max (0) , 
  step_momentum_uniform (0) ,
  kmax_momentum (0) ,
  R_Fermi_momentum (0) ,
  BPmin_global (0) , 
  BPmax_global (0) , 
  Jmin_global (0) , 
  Jmax_global (0) , 
  R_cut_function (0) , 
  d_cut_function (0) , 
  BP_one_configuration (0) , 
  iC_one_configuration (0) , 
  dimension_configuration_total (0) , 
  dimension_configuration_total_1h (0) , 
  dimension_configuration_total_2h (0) , 
  dimension_configuration_max (0) , 
  dimension_configuration_max_1h (0) , 
  dimension_configuration_max_2h (0) , 
  dimension_SD_total (0) , 
  dimension_SD_total_1h (0) , 
  dimension_SD_total_2h (0) , 
  dimension_SD_max (0) , 
  dimension_SD_max_1h (0) , 
  dimension_SD_max_2h (0) ,
  dimension_1p1h_space_BP_S_iM_fixed_max (0) , 
  dimension_2p2h_space_BP_S_iM_fixed_max (0)  {}





baryons_data::baryons_data (const class baryons_data &X) :
  is_it_M_scheme (false) , 
  is_Coulomb_Hamiltonian_here (false) ,
  are_there_basis_natural_orbitals (false) , 
  are_there_new_natural_orbitals (false) ,
  nucleonic_particle (NO_PARTICLE) , 
  hypernucleus_strangeness (0) , 
  n_spec_max (0) , 
  nmax (0) , 
  lmax (0) , 
  n_scat_max (0) , 
  n_holes_max (0) , 
  n_holes_max_pole_approximation (0) , 
  E_min_hw (0) , 
  E_max_hw (0) , 
  E_max_hw_pole_approximation (0) , 
  A_core (0) , 
  Z_core (0) , 
  N_core (0) , 
  A (0) , 
  Z (0) , 
  N (0) , 
  A_basis (0) , 
  Z_basis (0) , 
  N_basis (0) , 
  hole_states_number (0) , 
  N_nucleons (0) , 
  N_valence_nucleons (0) , 
  N_valence_nucleons_basis (0) , 
  N_valence_baryons (0) , 
  N_valence_baryons_1h (0) , 
  N_valence_baryons_2h (0) , 
  ZY_charge_pos (0) ,
  ZY_charge_neg (0) ,  
  ZY_charge_basis_potential_pos (0) , 
  ZY_charge_basis_potential_neg (0) , 
  nucleus_mass (0) , 
  nucleus_mass_basis (0) , 
  total_nucleus_mass (0) , 
  N_nlj_baryon (0) , 
  N_nljm_baryon (0) , 
  N_nlj_res_baryon (0) , 
  N_nljm_res_baryon (0) , 
  natural_orbitals_reference_states_number (0) , 
  jmax (0) , 
  m_min (0) , 
  m_max (0) , 
  M_max (0) , 
  M_max_1h (0) , 
  M_max_2h (0) , 
  m_max_minus_half (0) , 
  two_m_max (0) , 
  four_m_max (0) , 
  m_max_minus_m_min (0) , 
  iM_max (0) , 
  iM_max_1h (0) , 
  iM_max_2h (0) , 
  debut_file_name (""),
  R_charge (0) , 
  basis_potential (NO_POTENTIAL) , 
  H_potential (NO_POTENTIAL) , 
  good_isospin_basis_potential (false) ,
  is_it_OCM_HO_core (false) ,
  N_bef_R_GL (0) , 
  N_aft_R_GL (0) , 
  N_bef_R_uniform (0) , 
  N_aft_R_uniform (0) , 
  R (0) , 
  step_bef_R_uniform (0) ,
  R_real_max (0) , 
  step_momentum_uniform (0) ,
  kmax_momentum (0) ,
  R_Fermi_momentum (0) ,
  BPmin_global (0) , 
  BPmax_global (0) , 
  Jmin_global (0) , 
  Jmax_global (0) , 
  R_cut_function (0) , 
  d_cut_function (0) , 
  BP_one_configuration (0) , 
  iC_one_configuration (0) , 
  dimension_configuration_total (0) , 
  dimension_configuration_total_1h (0) , 
  dimension_configuration_total_2h (0) , 
  dimension_configuration_max (0) , 
  dimension_configuration_max_1h (0) , 
  dimension_configuration_max_2h (0) , 
  dimension_SD_total (0) , 
  dimension_SD_total_1h (0) , 
  dimension_SD_total_2h (0) , 
  dimension_SD_max (0) , 
  dimension_SD_max_1h (0) , 
  dimension_SD_max_2h (0) , 
  dimension_1p1h_space_BP_S_iM_fixed_max (0) , 
  dimension_2p2h_space_BP_S_iM_fixed_max (0)
{
  allocate_fill (X);
}


baryons_data::~baryons_data () {}

void baryons_data::allocate_fill (const class baryons_data &X)
{
  if (is_it_filled ()) error_message_print_abort ("baryons_data cannot be allocated twice in baryons_data::allocate_fill");

  is_it_M_scheme = X.is_it_M_scheme;
  
  is_Coulomb_Hamiltonian_here = X.is_Coulomb_Hamiltonian_here;
  
  are_there_basis_natural_orbitals = X.are_there_basis_natural_orbitals;
  
  are_there_new_natural_orbitals = X.are_there_new_natural_orbitals;
  
  nucleonic_particle = X.nucleonic_particle;
    
  hypernucleus_strangeness = X.hypernucleus_strangeness;
  
  n_spec_max = X.n_spec_max;
    
  nmax = X.nmax;
  lmax = X.lmax;
  
  n_scat_max = X.n_scat_max;

  n_holes_max = X.n_holes_max;
  
  n_holes_max_pole_approximation = X.n_holes_max_pole_approximation;
  
  E_min_hw = X.E_min_hw;
  E_max_hw = X.E_max_hw;
  
  E_max_hw_pole_approximation = X.E_max_hw_pole_approximation;
  
  A_core = X.A_core;
  Z_core = X.Z_core;
  N_core = X.N_core;
  
  A = X.A;
  Z = X.Z;
  N = X.N;
  
  A_basis = X.A_basis;
  Z_basis = X.Z_basis;
  N_basis = X.N_basis;
  
  hole_states_number = X.hole_states_number;
    
  N_nucleons = X.N_nucleons;
  
  N_valence_nucleons = X.N_valence_nucleons;
  
  N_valence_baryons    = X.N_valence_baryons;
  N_valence_baryons_1h = X.N_valence_baryons_1h;
  N_valence_baryons_2h = X.N_valence_baryons_2h;
  
  N_valence_nucleons_basis = X.N_valence_nucleons_basis;
    
  ZY_charge_pos = X.ZY_charge_pos;
  ZY_charge_neg = X.ZY_charge_neg;
  
  ZY_charge_basis_potential_pos = X.ZY_charge_basis_potential_pos;
  ZY_charge_basis_potential_neg = X.ZY_charge_basis_potential_neg;
    
  nucleus_mass = X.nucleus_mass;
  
  nucleus_mass_basis = X.nucleus_mass_basis;
  
  total_nucleus_mass = X.total_nucleus_mass;
  
  N_nlj_baryon  = X.N_nlj_baryon;
  N_nljm_baryon = X.N_nljm_baryon;
  
  N_nlj_res_baryon  = X.N_nlj_res_baryon;
  N_nljm_res_baryon = X.N_nljm_res_baryon;
  
  natural_orbitals_reference_states_number = X.natural_orbitals_reference_states_number;

  jmax = X.jmax;

  m_min = X.m_min;
  m_max = X.m_max;
  
  M_max    = X.M_max;
  M_max_1h = X.M_max_1h;
  M_max_2h = X.M_max_2h;
  
  m_max_minus_half = X.m_max_minus_half;
  
  two_m_max = X.two_m_max;
  
  four_m_max = X.four_m_max;
  
  m_max_minus_m_min = X.m_max_minus_m_min;
  
  iM_max    = X.iM_max;  
  iM_max_1h = X.iM_max_1h;
  iM_max_2h = X.iM_max_2h;
  
  debut_file_name = X.debut_file_name;
  
  R_charge = X.R_charge;
    
  basis_potential = X.basis_potential;
  
  H_potential = X.H_potential;
  
  good_isospin_basis_potential = X.good_isospin_basis_potential;
  
  is_it_OCM_HO_core = X.is_it_OCM_HO_core;
  
  N_bef_R_GL = X.N_bef_R_GL;
  N_aft_R_GL = X.N_aft_R_GL;
  
  N_bef_R_uniform = X.N_bef_R_uniform;
  N_aft_R_uniform = X.N_aft_R_uniform;
  
  Nk_momentum_uniform = X.Nk_momentum_uniform;
  Nk_momentum_GL  = X.Nk_momentum_GL;
  
  R = X.R;

  step_bef_R_uniform = X.step_bef_R_uniform;
  
  R_real_max = X.R_real_max;
  
  step_momentum_uniform = X.step_momentum_uniform;

  kmax_momentum = X.kmax_momentum;

  R_Fermi_momentum = X.R_Fermi_momentum;
  
  BPmin_global = X.BPmin_global;
  BPmax_global = X.BPmax_global;
  
  Jmin_global = X.Jmin_global;
  Jmax_global = X.Jmax_global;
  
  R_cut_function = X.R_cut_function;
  d_cut_function = X.d_cut_function;
  
  BP_one_configuration = X.BP_one_configuration;
  iC_one_configuration = X.iC_one_configuration;
  
  dimension_configuration_total    = X.dimension_configuration_total;
  dimension_configuration_total_1h = X.dimension_configuration_total_1h;
  dimension_configuration_total_2h = X.dimension_configuration_total_2h;
  
  dimension_configuration_max    = X.dimension_configuration_max;
  dimension_configuration_max_1h = X.dimension_configuration_max_1h;
  dimension_configuration_max_1h = X.dimension_configuration_max_2h;
  
  dimension_SD_total    = X.dimension_SD_total;
  dimension_SD_total_1h = X.dimension_SD_total_1h;
  dimension_SD_total_2h = X.dimension_SD_total_2h;
  
  dimension_SD_max    = X.dimension_SD_max;
  dimension_SD_max_1h = X.dimension_SD_max_1h;
  dimension_SD_max_2h = X.dimension_SD_max_2h;
  
  dimension_1p1h_space_BP_S_iM_fixed_max = X.dimension_1p1h_space_BP_S_iM_fixed_max;
  dimension_2p2h_space_BP_S_iM_fixed_max = X.dimension_2p2h_space_BP_S_iM_fixed_max;
  
  
  baryon_types.allocate_fill (X.baryon_types);  
  effective_masses_for_calc.allocate_fill (X.effective_masses_for_calc);  
  basis_potential_partial_waves_tab.allocate_fill (X.basis_potential_partial_waves_tab);  
  V0_KKNN_tab.allocate_fill (X.V0_KKNN_tab);
  rho_KKNN_tab.allocate_fill (X.rho_KKNN_tab);
  Vls_KKNN_tab.allocate_fill (X.Vls_KKNN_tab);
  rho_ls_KKNN_tab.allocate_fill (X.rho_ls_KKNN_tab);
  V0_KKNN_basis_core_potential_tab.allocate_fill (X.V0_KKNN_basis_core_potential_tab);
  rho_KKNN_basis_core_potential_tab.allocate_fill (X.rho_KKNN_basis_core_potential_tab);
  Vls_KKNN_basis_core_potential_tab.allocate_fill (X.Vls_KKNN_basis_core_potential_tab);
  rho_ls_KKNN_basis_core_potential_tab.allocate_fill (X.rho_ls_KKNN_basis_core_potential_tab);  
  TRS_nljm_indices.allocate_fill (X.TRS_nljm_indices);    
  dimensions_configuration_set.allocate_fill (X.dimensions_configuration_set);
  dimensions_configuration_set_1h.allocate_fill (X.dimensions_configuration_set_1h);
  dimensions_configuration_set_2h.allocate_fill (X.dimensions_configuration_set_2h);  
  sum_dimensions_configuration_set.allocate_fill (X.sum_dimensions_configuration_set);
  sum_dimensions_configuration_set_1h.allocate_fill (X.sum_dimensions_configuration_set_1h);
  sum_dimensions_configuration_set_2h.allocate_fill (X.sum_dimensions_configuration_set_2h);
  configuration_set.allocate_fill (X.configuration_set);
  configuration_set_1h.allocate_fill (X.configuration_set_1h);
  configuration_set_2h.allocate_fill (X.configuration_set_2h);  
  dimensions_SD_set.allocate_fill (X.dimensions_SD_set);
  dimensions_SD_set_1h.allocate_fill (X.dimensions_SD_set_1h);
  dimensions_SD_set_2h.allocate_fill (X.dimensions_SD_set_2h);  
  sum_dimensions_SD_set.allocate_fill (X.sum_dimensions_SD_set);
  sum_dimensions_SD_set_1h.allocate_fill (X.sum_dimensions_SD_set_1h);
  sum_dimensions_SD_set_2h.allocate_fill (X.sum_dimensions_SD_set_2h);
  SD_set.allocate_fill (X.SD_set);
  SD_set_1h.allocate_fill (X.SD_set_1h);
  SD_set_2h.allocate_fill (X.SD_set_2h);
  E_hw_table.allocate_fill (X.E_hw_table);
  n_holes_table.allocate_fill (X.n_holes_table);
  OBMEs_CM_set_HO_expansion.allocate_fill (X.OBMEs_CM_set_HO_expansion);
  OBMEs_CM_set_R_cut.allocate_fill (X.OBMEs_CM_set_R_cut);  
  reduced_grad_HO_expansion_set.allocate_fill (X.reduced_grad_HO_expansion_set);
  reduced_r_HO_expansion_set.allocate_fill (X.reduced_r_HO_expansion_set);
  reduced_r_HO_expansion_rms_radius_different_particles_set.allocate_fill (X.reduced_r_HO_expansion_rms_radius_different_particles_set);  
  reduced_grad_R_cut_set.allocate_fill (X.reduced_grad_R_cut_set);
  reduced_r_R_cut_set.allocate_fill (X.reduced_r_R_cut_set);
  reduced_r_R_cut_rms_radius_different_particles_set.allocate_fill (X.reduced_r_R_cut_rms_radius_different_particles_set);    
  OBMEs_multipole_square_HO_expansion.allocate_fill (X.OBMEs_multipole_square_HO_expansion);  
  OBMEs_multipole_reduced_HO_expansion.allocate_fill (X.OBMEs_multipole_reduced_HO_expansion);  
  OBMEs_multipole_square_R_cut.allocate_fill (X.OBMEs_multipole_square_R_cut);  
  OBMEs_multipole_reduced_R_cut.allocate_fill (X.OBMEs_multipole_reduced_R_cut);  
  OBMEs_inter_set.allocate_fill (X.OBMEs_inter_set);  
  nmax_lj_tabs.allocate_fill (X.nmax_lj_tabs);    
  nmin_lj_valence_tabs.allocate_fill (X.nmin_lj_valence_tabs);
  shells_indices_tab.allocate_fill (X.shells_indices_tab);    
  is_it_valence_shell_tabs.allocate_fill (X.is_it_valence_shell_tabs);
  one_body_indices.allocate_fill (X.one_body_indices);    
  shells.allocate_fill (X.shells);
  shells_plus.allocate_fill (X.shells_plus);
  shells_minus.allocate_fill (X.shells_minus);
  phi_table.allocate_fill (X.phi_table);
  Ueq_finite_range_tab_uniform.allocate_fill (X.Ueq_finite_range_tab_uniform);
  Ueq_finite_range_plus_tab_uniform.allocate_fill (X.Ueq_finite_range_plus_tab_uniform);
  Ueq_finite_range_minus_tab_uniform.allocate_fill (X.Ueq_finite_range_minus_tab_uniform);  
  source_tab_uniform.allocate_fill (X.source_tab_uniform);
  source_plus_tab_uniform.allocate_fill (X.source_plus_tab_uniform);
  source_minus_tab_uniform.allocate_fill (X.source_minus_tab_uniform);  
  OBMEs_HF_SGI_MSGI.allocate_fill (X.OBMEs_HF_SGI_MSGI);
  h_basis_tab.allocate_fill (X.h_basis_tab);
  TBMEs.allocate_fill (X.TBMEs);
  shells_quantum_numbers.allocate_fill (X.shells_quantum_numbers);  
  SD_TRS_indices.allocate_fill (X.SD_TRS_indices);
  SD_TRS_indices_1h.allocate_fill (X.SD_TRS_indices_1h);
  SD_TRS_indices_2h.allocate_fill (X.SD_TRS_indices_2h);  
  SD_TRS_reordering_bin_phases.allocate_fill (X.SD_TRS_reordering_bin_phases);
  SD_TRS_reordering_bin_phases_1h.allocate_fill (X.SD_TRS_reordering_bin_phases_1h);
  SD_TRS_reordering_bin_phases_2h.allocate_fill (X.SD_TRS_reordering_bin_phases_2h);  
  SD_TRS_bin_phases.allocate_fill (X.SD_TRS_bin_phases);
  SD_TRS_bin_phases_1h.allocate_fill (X.SD_TRS_bin_phases_1h);
  SD_TRS_bin_phases_2h.allocate_fill (X.SD_TRS_bin_phases_2h);  
  dimensions_configuration_one_jump_table_in_to_out.allocate_fill (X.dimensions_configuration_one_jump_table_in_to_out);
  dimensions_configuration_one_jump_table_out_to_in.allocate_fill (X.dimensions_configuration_one_jump_table_out_to_in);  
  configuration_one_jump_table_in_to_out.allocate_fill (X.configuration_one_jump_table_in_to_out);
  configuration_one_jump_table_out_to_in.allocate_fill (X.configuration_one_jump_table_out_to_in);    
  dimensions_SD_one_jump_table_in_to_out.allocate_fill (X.dimensions_SD_one_jump_table_in_to_out);
  dimensions_SD_one_jump_table_out_to_in.allocate_fill (X.dimensions_SD_one_jump_table_out_to_in);  
  dimensions_SD_one_jump_table_Jpm_in_to_out.allocate_fill (X.dimensions_SD_one_jump_table_Jpm_in_to_out);
  dimensions_SD_one_jump_table_Jpm_out_to_in.allocate_fill (X.dimensions_SD_one_jump_table_Jpm_out_to_in);  
  SD_one_jump_table_in_to_out.allocate_fill (X.SD_one_jump_table_in_to_out);
  SD_one_jump_table_out_to_in.allocate_fill (X.SD_one_jump_table_out_to_in);  
  SD_one_jump_table_Jpm_in_to_out.allocate_fill (X.SD_one_jump_table_Jpm_in_to_out);
  SD_one_jump_table_Jpm_out_to_in.allocate_fill (X.SD_one_jump_table_Jpm_out_to_in);  
  U_finite_range_HF_HO_basis_HO_expansion_part.allocate_fill (X.U_finite_range_HF_HO_basis_HO_expansion_part);
  HO_overlaps_basis.allocate_fill (X.HO_overlaps_basis);
  HO_overlaps_basis_Fermi.allocate_fill (X.HO_overlaps_basis_Fermi);
  HO_overlaps.allocate_fill (X.HO_overlaps);
  HO_overlaps_Fermi.allocate_fill (X.HO_overlaps_Fermi);  
  GHF_overlaps.allocate_fill (X.GHF_overlaps);  
  d_core_potential_tab.allocate_fill (X.d_core_potential_tab);   
  R0_core_potential_tab.allocate_fill (X.R0_core_potential_tab);
  Vo_core_potential_tab.allocate_fill (X.Vo_core_potential_tab);
  Vso_core_potential_tab.allocate_fill (X.Vso_core_potential_tab);  
  d_basis_core_potential_tab.allocate_fill (X.d_basis_core_potential_tab);
  R0_basis_core_potential_tab.allocate_fill (X.R0_basis_core_potential_tab);
  Vo_basis_core_potential_tab.allocate_fill (X.Vo_basis_core_potential_tab);
  Vso_basis_core_potential_tab.allocate_fill (X.Vso_basis_core_potential_tab);  
  d_basis_tab.allocate_fill (X.d_basis_tab);
  R0_basis_tab.allocate_fill (X.R0_basis_tab);
  Vo_basis_tab.allocate_fill (X.Vo_basis_tab);
  Vso_basis_tab.allocate_fill (X.Vso_basis_tab);
  b_partial_waves_tab.allocate_fill (X.b_partial_waves_tab);
  basis_PSI_quantum_numbers_tab.allocate_fill (X.basis_PSI_quantum_numbers_tab);
  BPin_Sin_Nspec_in_for_one_jump_tab.allocate_fill (X.BPin_Sin_Nspec_in_for_one_jump_tab);  
  BPout_Sout_Nspec_out_for_one_jump_tab.allocate_fill (X.BPout_Sout_Nspec_out_for_one_jump_tab);  
  BPin_Sin_Nspec_in_iMin_for_one_jump_tab.allocate_fill (X.BPin_Sin_Nspec_in_iMin_for_one_jump_tab);  
  BPout_Sout_Nspec_out_iMout_for_one_jump_tab.allocate_fill (X.BPout_Sout_Nspec_out_iMout_for_one_jump_tab);
  iC_out_min_tab.allocate_fill (X.iC_out_min_tab);
  iC_out_max_tab.allocate_fill (X.iC_out_max_tab);  
  is_configuration_out_in_space_tab.allocate_fill (X.is_configuration_out_in_space_tab);  
  is_inSD_in_space_tab_Jpm.allocate_fill (X.is_inSD_in_space_tab_Jpm);  
  is_outSD_in_space_tab.allocate_fill (X.is_outSD_in_space_tab);  
  is_it_configuration_inter_to_include_tab.allocate_fill (X.is_it_configuration_inter_to_include_tab);  
  is_it_SD_inter_to_include_tab.allocate_fill (X.is_it_SD_inter_to_include_tab);
  initial_to_nljm_ordered_states.allocate_fill (X.initial_to_nljm_ordered_states);  
  nljm_ordered_to_initial_states.allocate_fill (X.nljm_ordered_to_initial_states);
  dimensions_SD_HO_Berggren_overlaps_table.allocate_fill (X.dimensions_SD_HO_Berggren_overlaps_table);  
  SD_HO_Berggren_overlaps_table.allocate_fill (X.SD_HO_Berggren_overlaps_table);
  scalar_density_matrices_tab.allocate_fill (X.scalar_density_matrices_tab);  
  natural_orbitals_matrices_tab.allocate_fill (X.natural_orbitals_matrices_tab);  
  ESPEs_Hamiltonian_matrices_tab.allocate_fill (X.ESPEs_Hamiltonian_matrices_tab);
  ESPEs_Hamiltonian_orbitals_matrices_tab.allocate_fill (X.ESPEs_Hamiltonian_orbitals_matrices_tab);  
  natural_orbitals_reference_states.allocate_fill (X.natural_orbitals_reference_states);
  SD_quantum_numbers_tab.allocate_fill (X.SD_quantum_numbers_tab);
  effective_charges.allocate_fill (X.effective_charges);
  are_there_basis_natural_orbitals_tab.allocate_fill (X.are_there_basis_natural_orbitals_tab);
  are_there_new_natural_orbitals_tab.allocate_fill (X.are_there_new_natural_orbitals_tab);
      
  for (unsigned int occupied_squares_index = 0 ; occupied_squares_index <= 1 ; occupied_squares_index++)
    {
      are_configurations_inter_occupied_in_space_1ph_tables[occupied_squares_index].allocate_fill (X.are_configurations_inter_occupied_in_space_1ph_tables[occupied_squares_index]);
  
      are_configurations_inter_occupied_in_space_2ph_tables[occupied_squares_index].allocate_fill (X.are_configurations_inter_occupied_in_space_2ph_tables[occupied_squares_index]);
  
      dimensions_configuration_1p_tables[occupied_squares_index].allocate_fill (X.dimensions_configuration_1p_tables[occupied_squares_index]);
      dimensions_configuration_1h_tables[occupied_squares_index].allocate_fill (X.dimensions_configuration_1h_tables[occupied_squares_index]);
  
      dimensions_configuration_2p_tables[occupied_squares_index].allocate_fill (X.dimensions_configuration_2p_tables[occupied_squares_index]);
      dimensions_configuration_2h_tables[occupied_squares_index].allocate_fill (X.dimensions_configuration_2h_tables[occupied_squares_index]);
  
      configuration_1p_tables[occupied_squares_index].allocate_fill (X.configuration_1p_tables[occupied_squares_index]);
      configuration_1h_tables[occupied_squares_index].allocate_fill (X.configuration_1h_tables[occupied_squares_index]);
  
      configuration_2p_tables[occupied_squares_index].allocate_fill (X.configuration_2p_tables[occupied_squares_index]);
      configuration_2h_tables[occupied_squares_index].allocate_fill (X.configuration_2h_tables[occupied_squares_index]);

      dimensions_SD_1p_tables[occupied_squares_index].allocate_fill (X.dimensions_SD_1p_tables[occupied_squares_index]);
      dimensions_SD_1h_tables[occupied_squares_index].allocate_fill (X.dimensions_SD_1h_tables[occupied_squares_index]);
  
      dimensions_SD_2p_tables[occupied_squares_index].allocate_fill (X.dimensions_SD_2p_tables[occupied_squares_index]);
      dimensions_SD_2h_tables[occupied_squares_index].allocate_fill (X.dimensions_SD_2h_tables[occupied_squares_index]);
    
      SD_1p_tables[occupied_squares_index].allocate_fill (X.SD_1p_tables[occupied_squares_index]);
      SD_1h_tables[occupied_squares_index].allocate_fill (X.SD_1h_tables[occupied_squares_index]);
  
      SD_2p_tables[occupied_squares_index].allocate_fill (X.SD_2p_tables[occupied_squares_index]);
      SD_2h_tables[occupied_squares_index].allocate_fill (X.SD_2h_tables[occupied_squares_index]);

      iC_in_min_tab[occupied_squares_index].allocate_fill (X.iC_in_min_tab[occupied_squares_index]);
  
      iC_in_max_tab[occupied_squares_index].allocate_fill (X.iC_in_max_tab[occupied_squares_index]);
      
      is_configuration_in_in_space_tabs[occupied_squares_index].allocate_fill (X.is_configuration_in_in_space_tabs[occupied_squares_index]);
    
      is_inSD_in_space_tabs[occupied_squares_index].allocate_fill (X.is_inSD_in_space_tabs[occupied_squares_index]);
    }
}




void baryons_data::deallocate ()
{
  baryon_types.deallocate ();  
  effective_masses_for_calc.deallocate ();
  basis_potential_partial_waves_tab.deallocate ();  
  V0_KKNN_tab.deallocate ();
  rho_KKNN_tab.deallocate ();
  Vls_KKNN_tab.deallocate ();
  rho_ls_KKNN_tab.deallocate ();
  V0_KKNN_basis_core_potential_tab.deallocate ();
  rho_KKNN_basis_core_potential_tab.deallocate ();
  Vls_KKNN_basis_core_potential_tab.deallocate ();
  rho_ls_KKNN_basis_core_potential_tab.deallocate ();  
  TRS_nljm_indices.deallocate ();    
  dimensions_configuration_set.deallocate ();
  dimensions_configuration_set_1h.deallocate ();
  dimensions_configuration_set_2h.deallocate ();  
  sum_dimensions_configuration_set.deallocate ();
  sum_dimensions_configuration_set_1h.deallocate ();
  sum_dimensions_configuration_set_2h.deallocate ();
  configuration_set.deallocate ();
  configuration_set_1h.deallocate ();
  configuration_set_2h.deallocate ();  
  dimensions_SD_set.deallocate ();
  dimensions_SD_set_1h.deallocate ();
  dimensions_SD_set_2h.deallocate ();  
  sum_dimensions_SD_set.deallocate ();
  sum_dimensions_SD_set_1h.deallocate ();
  sum_dimensions_SD_set_2h.deallocate ();
  SD_set.deallocate ();
  SD_set_1h.deallocate ();
  SD_set_2h.deallocate ();
  E_hw_table.deallocate ();
  n_holes_table.deallocate ();
  OBMEs_CM_set_HO_expansion.deallocate ();
  OBMEs_CM_set_R_cut.deallocate ();  
  reduced_grad_HO_expansion_set.deallocate ();
  reduced_r_HO_expansion_set.deallocate ();
  reduced_r_HO_expansion_rms_radius_different_particles_set.deallocate ();  
  reduced_grad_R_cut_set.deallocate ();
  reduced_r_R_cut_set.deallocate ();
  reduced_r_R_cut_rms_radius_different_particles_set.deallocate ();    
  OBMEs_multipole_square_HO_expansion.deallocate ();  
  OBMEs_multipole_reduced_HO_expansion.deallocate ();  
  OBMEs_multipole_square_R_cut.deallocate ();  
  OBMEs_multipole_reduced_R_cut.deallocate ();  
  OBMEs_inter_set.deallocate ();  
  nmax_lj_tabs.deallocate ();    
  nmin_lj_valence_tabs.deallocate ();
  shells_indices_tab.deallocate ();    
  is_it_valence_shell_tabs.deallocate ();
  one_body_indices.deallocate ();    
  shells.deallocate ();
  shells_plus.deallocate ();
  shells_minus.deallocate ();
  phi_table.deallocate ();
  Ueq_finite_range_tab_uniform.deallocate ();
  Ueq_finite_range_plus_tab_uniform.deallocate ();
  Ueq_finite_range_minus_tab_uniform.deallocate ();  
  source_tab_uniform.deallocate ();
  source_plus_tab_uniform.deallocate ();
  source_minus_tab_uniform.deallocate ();  
  OBMEs_HF_SGI_MSGI.deallocate ();
  h_basis_tab.deallocate ();
  TBMEs.deallocate ();
  shells_quantum_numbers.deallocate ();  
  SD_TRS_indices.deallocate ();
  SD_TRS_indices_1h.deallocate ();
  SD_TRS_indices_2h.deallocate ();  
  SD_TRS_reordering_bin_phases.deallocate ();
  SD_TRS_reordering_bin_phases_1h.deallocate ();
  SD_TRS_reordering_bin_phases_2h.deallocate ();  
  SD_TRS_bin_phases.deallocate ();
  SD_TRS_bin_phases_1h.deallocate ();
  SD_TRS_bin_phases_2h.deallocate ();  
  dimensions_configuration_one_jump_table_in_to_out.deallocate ();
  dimensions_configuration_one_jump_table_out_to_in.deallocate ();  
  configuration_one_jump_table_in_to_out.deallocate ();
  configuration_one_jump_table_out_to_in.deallocate ();    
  dimensions_SD_one_jump_table_in_to_out.deallocate ();
  dimensions_SD_one_jump_table_out_to_in.deallocate ();  
  dimensions_SD_one_jump_table_Jpm_in_to_out.deallocate ();
  dimensions_SD_one_jump_table_Jpm_out_to_in.deallocate ();  
  SD_one_jump_table_in_to_out.deallocate ();
  SD_one_jump_table_out_to_in.deallocate ();  
  SD_one_jump_table_Jpm_in_to_out.deallocate ();
  SD_one_jump_table_Jpm_out_to_in.deallocate ();  
  U_finite_range_HF_HO_basis_HO_expansion_part.deallocate ();
  HO_overlaps_basis.deallocate ();
  HO_overlaps_basis_Fermi.deallocate ();
  HO_overlaps.deallocate ();
  HO_overlaps_Fermi.deallocate ();  
  GHF_overlaps.deallocate ();  
  d_core_potential_tab.deallocate ();   
  R0_core_potential_tab.deallocate ();
  Vo_core_potential_tab.deallocate ();
  Vso_core_potential_tab.deallocate ();  
  d_basis_core_potential_tab.deallocate ();
  R0_basis_core_potential_tab.deallocate ();
  Vo_basis_core_potential_tab.deallocate ();
  Vso_basis_core_potential_tab.deallocate ();  
  d_basis_tab.deallocate ();
  R0_basis_tab.deallocate ();
  Vo_basis_tab.deallocate ();
  Vso_basis_tab.deallocate ();
  b_partial_waves_tab.deallocate ();
  basis_PSI_quantum_numbers_tab.deallocate ();
  BPin_Sin_Nspec_in_for_one_jump_tab.deallocate ();  
  BPout_Sout_Nspec_out_for_one_jump_tab.deallocate ();  
  BPin_Sin_Nspec_in_iMin_for_one_jump_tab.deallocate ();  
  BPout_Sout_Nspec_out_iMout_for_one_jump_tab.deallocate ();
  iC_out_min_tab.deallocate ();
  iC_out_max_tab.deallocate ();  
  is_configuration_out_in_space_tab.deallocate ();  
  is_inSD_in_space_tab_Jpm.deallocate ();
  is_outSD_in_space_tab.deallocate ();  
  is_it_configuration_inter_to_include_tab.deallocate ();  
  is_it_SD_inter_to_include_tab.deallocate ();
  initial_to_nljm_ordered_states.deallocate ();  
  nljm_ordered_to_initial_states.deallocate ();
  dimensions_SD_HO_Berggren_overlaps_table.deallocate ();  
  SD_HO_Berggren_overlaps_table.deallocate ();
  scalar_density_matrices_tab.deallocate ();  
  natural_orbitals_matrices_tab.deallocate ();  
  ESPEs_Hamiltonian_matrices_tab.deallocate ();
  ESPEs_Hamiltonian_orbitals_matrices_tab.deallocate ();  
  natural_orbitals_reference_states.deallocate ();
  SD_quantum_numbers_tab.deallocate ();
  effective_charges.deallocate ();
  are_there_basis_natural_orbitals_tab.deallocate ();
  are_there_new_natural_orbitals_tab.deallocate ();

  for (unsigned int occupied_squares_index = 0 ; occupied_squares_index <= 1 ; occupied_squares_index++)
    {
      are_configurations_inter_occupied_in_space_1ph_tables[occupied_squares_index].deallocate ();  
      are_configurations_inter_occupied_in_space_2ph_tables[occupied_squares_index].deallocate ();
  
      dimensions_configuration_1p_tables[occupied_squares_index].deallocate ();
      dimensions_configuration_1h_tables[occupied_squares_index].deallocate ();
  
      dimensions_configuration_2p_tables[occupied_squares_index].deallocate ();
      dimensions_configuration_2h_tables[occupied_squares_index].deallocate ();
  
      configuration_1p_tables[occupied_squares_index].deallocate ();
      configuration_1h_tables[occupied_squares_index].deallocate ();
  
      configuration_2p_tables[occupied_squares_index].deallocate ();
      configuration_2h_tables[occupied_squares_index].deallocate ();

      dimensions_SD_1p_tables[occupied_squares_index].deallocate ();
      dimensions_SD_1h_tables[occupied_squares_index].deallocate ();
  
      dimensions_SD_2p_tables[occupied_squares_index].deallocate ();
      dimensions_SD_2h_tables[occupied_squares_index].deallocate ();
    
      SD_1p_tables[occupied_squares_index].deallocate ();
      SD_1h_tables[occupied_squares_index].deallocate ();
  
      SD_2p_tables[occupied_squares_index].deallocate ();
      SD_2h_tables[occupied_squares_index].deallocate ();
 
      iC_in_min_tab[occupied_squares_index].deallocate ();
 
      iC_in_max_tab[occupied_squares_index].deallocate ();
 
      is_configuration_in_in_space_tabs[occupied_squares_index].deallocate ();
 
      is_inSD_in_space_tabs[occupied_squares_index].deallocate ();
    }
  
  is_it_M_scheme = false;

  is_Coulomb_Hamiltonian_here = false;

  are_there_basis_natural_orbitals = false;
  
  are_there_new_natural_orbitals = false;

  nucleonic_particle = NO_PARTICLE;
  
  hypernucleus_strangeness = 0;
  
  n_spec_max = 0;
    
  nmax = 0;
  lmax = 0;

  n_scat_max = 0;

  n_holes_max = 0;
  n_holes_max_pole_approximation = 0;
  
  E_min_hw = 0;
  E_max_hw = 0;
  E_max_hw_pole_approximation = 0;

  A_core = 0;
  Z_core = 0;
  N_core = 0;

  A = 0;
  Z = 0;
  N = 0;

  A_basis = 0;
  Z_basis = 0;
  N_basis = 0;

  hole_states_number = 0;
  
  N_nucleons = 0;

  N_valence_nucleons = 0;
  
  N_valence_baryons    = 0;
  N_valence_baryons_1h = 0;
  N_valence_baryons_2h = 0;

  N_valence_nucleons_basis = 0;

  ZY_charge_pos = 0;
  ZY_charge_neg = 0;
  
  ZY_charge_basis_potential_pos = 0;
  ZY_charge_basis_potential_neg = 0;

  nucleus_mass = 0;

  nucleus_mass_basis = 0;
  
  total_nucleus_mass = 0;

  N_nlj_baryon  = 0;
  N_nljm_baryon = 0;

  N_nlj_res_baryon  = 0;
  N_nljm_res_baryon = 0;
  
  natural_orbitals_reference_states_number = 0;

  jmax = 0;

  m_min = 0;
  m_max = 0;

  M_max    = 0;
  M_max_1h = 0;
  M_max_2h = 0;

  m_max_minus_half = 0;

  two_m_max = 0;

  four_m_max = 0;

  m_max_minus_m_min = 0;

  iM_max    = 0;
  iM_max_1h = 0;
  iM_max_2h = 0;

  debut_file_name = "";

  R_charge = 0;

  basis_potential = NO_POTENTIAL; 
  H_potential     = NO_POTENTIAL; 

  good_isospin_basis_potential = false;
  
  is_it_OCM_HO_core = false;

  N_bef_R_GL = 0;
  N_aft_R_GL = 0;

  N_bef_R_uniform = 0;
  N_aft_R_uniform = 0;

  Nk_momentum_uniform = 0;
  Nk_momentum_GL  = 0;
  
  R = 0;

  step_bef_R_uniform = 0;
  
  R_real_max = 0;

  step_momentum_uniform = 0;
  
  kmax_momentum = 0;

  R_Fermi_momentum = 0;
  
  BPmin_global = 0;
  BPmax_global = 0;

  Jmin_global = 0;
  Jmax_global = 0;

  R_cut_function = 0;
  d_cut_function = 0;

  BP_one_configuration = 0;
  iC_one_configuration = 0;

  dimension_configuration_total    = 0;
  dimension_configuration_total_1h = 0;
  dimension_configuration_total_2h = 0;

  dimension_configuration_max    = 0;
  dimension_configuration_max_1h = 0;
  dimension_configuration_max_2h = 0;

  dimension_SD_total    = 0;
  dimension_SD_total_1h = 0;
  dimension_SD_total_2h = 0;

  dimension_SD_max    = 0;
  dimension_SD_max_1h = 0;
  dimension_SD_max_2h = 0;

  dimension_1p1h_space_BP_S_iM_fixed_max = 0;
  dimension_2p2h_space_BP_S_iM_fixed_max = 0;
}



// Routines deallocating specific arrays of baryons_data
// ------------------------------------------------------

void baryons_data::one_jump_tables_in_to_out_deallocate ()
{
  dimensions_configuration_one_jump_table_in_to_out.deallocate ();
  
  configuration_one_jump_table_in_to_out.deallocate ();
  
  dimensions_SD_one_jump_table_in_to_out.deallocate ();

  SD_one_jump_table_in_to_out.deallocate ();
}

void baryons_data::one_jump_tables_Jpm_in_to_out_deallocate ()
{
  dimensions_SD_one_jump_table_Jpm_in_to_out.deallocate ();
  
  SD_one_jump_table_Jpm_in_to_out.deallocate ();
}

void baryons_data::one_jump_tables_out_to_in_deallocate ()
{
  dimensions_configuration_one_jump_table_out_to_in.deallocate ();
  
  configuration_one_jump_table_out_to_in.deallocate ();
  
  dimensions_SD_one_jump_table_out_to_in.deallocate ();

  SD_one_jump_table_out_to_in.deallocate ();
}

void baryons_data::one_jump_tables_Jpm_out_to_in_deallocate ()
{
  dimensions_SD_one_jump_table_Jpm_out_to_in.deallocate ();
  
  SD_one_jump_table_Jpm_out_to_in.deallocate ();
}

void baryons_data::tables_1ph_deallocate ()
{
  for (unsigned int occupied_squares_index = 0 ; occupied_squares_index <= 1 ; occupied_squares_index++)
    {
      are_configurations_inter_occupied_in_space_1ph_tables[occupied_squares_index].deallocate ();

      dimensions_configuration_1p_tables[occupied_squares_index].deallocate ();
      dimensions_configuration_1h_tables[occupied_squares_index].deallocate ();
      
      configuration_1p_tables[occupied_squares_index].deallocate ();
      configuration_1h_tables[occupied_squares_index].deallocate ();
  
      dimensions_SD_1p_tables[occupied_squares_index].deallocate ();
      dimensions_SD_1h_tables[occupied_squares_index].deallocate ();
      
      SD_1p_tables[occupied_squares_index].deallocate ();
      SD_1h_tables[occupied_squares_index].deallocate ();
    }
}

void baryons_data::tables_2ph_deallocate ()
{
  for (unsigned int occupied_squares_index = 0 ; occupied_squares_index <= 1 ; occupied_squares_index++)
    {
      are_configurations_inter_occupied_in_space_2ph_tables[occupied_squares_index].deallocate ();

      dimensions_configuration_2p_tables[occupied_squares_index].deallocate ();
      dimensions_configuration_2h_tables[occupied_squares_index].deallocate ();
      
      configuration_2p_tables[occupied_squares_index].deallocate ();
      configuration_2h_tables[occupied_squares_index].deallocate ();
  
      dimensions_SD_2p_tables[occupied_squares_index].deallocate ();
      dimensions_SD_2h_tables[occupied_squares_index].deallocate ();
      
      SD_2p_tables[occupied_squares_index].deallocate ();  
      SD_2h_tables[occupied_squares_index].deallocate ();
    }
}




// Constants of baryons_data are initialized here from input_data
// ---------------------------------------------------------------
// M-scheme is used everywhere except in two-particle codes, where one uses J-scheme.

void baryons_data::initialize_constants (
					  const bool is_it_M_scheme_input , 
					  const enum particle_type nucleonic_particle_input , 
					  const class input_data_str &input_data)
{
  if (is_it_filled ()) error_message_print_abort ("constants cannot be initialized twice in baryons_data::initialize_constants");

  is_it_M_scheme = is_it_M_scheme_input;
  
  nucleonic_particle = nucleonic_particle_input;

  const bool is_cv_possible = input_data.get_is_cv_possible ();
    
  hypernucleus_strangeness = input_data.get_hypernucleus_strangeness ();
    
  is_Coulomb_Hamiltonian_here = input_data.get_is_Coulomb_Hamiltonian_here ();
  
  basis_potential = input_data.get_basis_potential ();

  H_potential = input_data.get_H_potential ();
  
  good_isospin_basis_potential = input_data.get_good_isospin_basis_potential ();
  
  nucleus_mass = input_data.get_nucleus_mass ();
  
  nucleus_mass_basis = input_data.get_nucleus_mass_basis ();
  
  total_nucleus_mass = input_data.get_total_nucleus_mass ();
  
  R = input_data.get_R ();

  step_bef_R_uniform = input_data.get_step_bef_R_uniform ();
  
  R_real_max = input_data.get_R_real_max ();
  
  kmax_momentum = input_data.get_kmax_momentum ();

  R_Fermi_momentum = input_data.get_R_Fermi_momentum ();
  
  step_momentum_uniform = input_data.get_step_momentum_uniform ();
    
  N_bef_R_GL = input_data.get_N_bef_R_GL ();
  N_aft_R_GL = input_data.get_N_aft_R_GL ();
  
  N_bef_R_uniform = input_data.get_N_bef_R_uniform ();
  N_aft_R_uniform = input_data.get_N_aft_R_uniform ();

  Nk_momentum_uniform = input_data.get_Nk_momentum_uniform ();
  
  Nk_momentum_GL  = input_data.get_Nk_momentum_GL ();
  
  R_charge = input_data.get_R_charge ();
  
  R_cut_function = input_data.get_R_cut_function ();
  d_cut_function = input_data.get_d_cut_function ();
  
  A_core = input_data.get_A_core ();
  Z_core = input_data.get_Z_core ();
  N_core = input_data.get_N_core ();
  
  A = input_data.get_A ();
  Z = input_data.get_Z ();
  N = input_data.get_N ();
  
  A_basis = input_data.get_A_basis ();
  Z_basis = input_data.get_Z_basis ();
  N_basis = input_data.get_N_basis ();
  
  natural_orbitals_reference_states_number = input_data.get_natural_orbitals_reference_states_number ();

  const int strangeness_max = hypernucleus_strangeness;
  
  if (nucleonic_particle == PROTON)
    {      
      const class array<unsigned int> &Np_nlj_baryon_tab  = input_data.get_Np_nlj_baryon_tab ();
      const class array<unsigned int> &Np_nljm_baryon_tab = input_data.get_Np_nljm_baryon_tab ();
    
      const class array<unsigned int> &Np_nlj_res_baryon_tab  = input_data.get_Np_nlj_res_baryon_tab ();
      const class array<unsigned int> &Np_nljm_res_baryon_tab = input_data.get_Np_nljm_res_baryon_tab ();
      
      are_there_basis_natural_orbitals = input_data.get_are_there_basis_natural_orbitals_p ();

      are_there_new_natural_orbitals = input_data.get_are_there_new_natural_orbitals_p ();
      
      N_nucleons = input_data.get_Z ();
      
      N_valence_nucleons = input_data.get_Zval ();
  
      N_valence_baryons = input_data.get_ZYval ();      

      N_valence_nucleons_basis = input_data.get_Zval_basis ();
      
      hole_states_number = input_data.get_prot_hole_states_number ();
        
      ZY_charge_pos = input_data.get_ZY_charge_pos ();
      ZY_charge_neg = input_data.get_ZY_charge_neg ();
      
      ZY_charge_basis_potential_pos = input_data.get_ZY_charge_basis_potential_pos ();
      ZY_charge_basis_potential_neg = input_data.get_ZY_charge_basis_potential_neg ();
          
      nmax = input_data.get_nmax_p ();
      lmax = input_data.get_lmax_p ();

      jmax = input_data.get_jp_max ();
      
      m_max = input_data.get_mp_max ();      
      m_min = input_data.get_mp_min ();
      
      m_max_minus_half = input_data.get_mp_max_minus_half ();
      
      two_m_max = input_data.get_two_mp_max ();

      four_m_max = input_data.get_four_mp_max ();
      
      m_max_minus_m_min = input_data.get_mp_max_minus_mp_min ();
      
      BPmin_global = input_data.get_BPmin_global_pp ();
      BPmax_global = input_data.get_BPmax_global_pp ();
      
      Jmin_global = input_data.get_Jmin_global_pp ();
      Jmax_global = input_data.get_Jmax_global_pp ();
      
      n_scat_max = input_data.get_n_scat_max_p ();
      
      n_holes_max = input_data.get_n_holes_max_p ();

      n_holes_max_pole_approximation = input_data.get_n_holes_max_p_pole_approximation ();
        
      N_nljm_baryon = Np_nljm_baryon_tab.sum ();

      N_nlj_baryon = Np_nlj_baryon_tab.sum ();
      
      N_nljm_res_baryon = Np_nljm_res_baryon_tab.sum ();
      
      N_nlj_res_baryon = Np_nlj_res_baryon_tab.sum ();
      
      if (is_cv_possible)
	{
	  const unsigned int N_spec_shells = strangeness_max;
	  
	  n_spec_max = 2*strangeness_max;
  
	  N_valence_baryons        += n_spec_max , N_nlj_baryon     += N_spec_shells , N_nljm_baryon     += n_spec_max;
	  N_valence_nucleons_basis += n_spec_max , N_nlj_res_baryon += N_spec_shells , N_nljm_res_baryon += n_spec_max;	  
	}
      else
	n_spec_max = 0;
    }

  if (nucleonic_particle == NEUTRON)
    {      
      const class array<unsigned int> &Nn_nlj_baryon_tab  = input_data.get_Nn_nlj_baryon_tab ();
      const class array<unsigned int> &Nn_nljm_baryon_tab = input_data.get_Nn_nljm_baryon_tab ();
    
      const class array<unsigned int> &Nn_nlj_res_baryon_tab  = input_data.get_Nn_nlj_res_baryon_tab ();
      const class array<unsigned int> &Nn_nljm_res_baryon_tab = input_data.get_Nn_nljm_res_baryon_tab ();
      
      are_there_basis_natural_orbitals = input_data.get_are_there_basis_natural_orbitals_n ();

      are_there_new_natural_orbitals = input_data.get_are_there_new_natural_orbitals_n ();
      
      N_nucleons = input_data.get_N ();
      
      N_valence_nucleons = input_data.get_Nval ();
      
      N_valence_baryons = input_data.get_NYval ();

      N_valence_nucleons_basis = input_data.get_Nval_basis ();
      
      hole_states_number = input_data.get_neut_hole_states_number ();
      
      ZY_charge_pos = 0;
      ZY_charge_neg = 0;
      
      ZY_charge_basis_potential_pos = 0;
      ZY_charge_basis_potential_neg = 0;
      
      N_nljm_baryon = Nn_nljm_baryon_tab.sum ();

      N_nlj_baryon = Nn_nlj_baryon_tab.sum ();
      
      N_nlj_res_baryon = Nn_nlj_res_baryon_tab.sum ();

      N_nljm_res_baryon = Nn_nljm_res_baryon_tab.sum ();
      
      nmax = input_data.get_nmax_n ();
      lmax = input_data.get_lmax_n ();
      
      jmax = input_data.get_jn_max ();

      m_max = input_data.get_mn_max ();
      m_min = input_data.get_mn_min ();
      
      m_max_minus_half = input_data.get_mn_max_minus_half ();
      
      two_m_max = input_data.get_two_mn_max ();

      four_m_max = input_data.get_four_mn_max ();
      
      m_max_minus_m_min = input_data.get_mn_max_minus_mn_min ();
      
      BPmin_global = input_data.get_BPmin_global_nn ();
      BPmax_global = input_data.get_BPmax_global_nn ();
      
      Jmin_global = input_data.get_Jmin_global_nn ();
      Jmax_global = input_data.get_Jmax_global_nn ();
      
      n_scat_max = input_data.get_n_scat_max_n ();
      
      n_holes_max = input_data.get_n_holes_max_n ();
      
      n_holes_max_pole_approximation = input_data.get_n_holes_max_n_pole_approximation ();
            
      N_nljm_baryon = Nn_nljm_baryon_tab.sum ();

      N_nlj_baryon = Nn_nlj_baryon_tab.sum ();
      
      N_nljm_res_baryon = Nn_nljm_res_baryon_tab.sum ();
      
      N_nlj_res_baryon = Nn_nlj_res_baryon_tab.sum ();
      
      if (is_cv_possible)
	{
	  const unsigned int N_spec_shells = strangeness_max;
	  
	  n_spec_max = 2*strangeness_max;
	  
	  N_nlj_baryon     += N_spec_shells , N_nljm_baryon     += n_spec_max;
	  N_nlj_res_baryon += N_spec_shells , N_nljm_res_baryon += n_spec_max;
	}
      else
	n_spec_max = 0;
    }
  
  if (is_it_two_nucleon_ST_cluster_determine (nucleonic_particle))
    {
      if (is_it_M_scheme) error_message_print_abort ("J-scheme only for two-body systems");
      
      N_nucleons = N_valence_nucleons = N_valence_baryons = N_valence_nucleons_basis = 2;
      
      hole_states_number = 0;
      
      ZY_charge_pos = input_data.get_ZY_charge_pos ();
      ZY_charge_neg = input_data.get_ZY_charge_neg ();
      
      ZY_charge_basis_potential_pos = input_data.get_ZY_charge_basis_potential_pos ();
      ZY_charge_basis_potential_neg = input_data.get_ZY_charge_basis_potential_neg ();
      
      N_nlj_baryon = input_data.get_N_nlj_relative ();
      
      N_nlj_res_baryon = input_data.get_N_nlj_res_relative ();
      
      nmax = input_data.get_nmax_relative ();
      lmax = input_data.get_lmax_relative ();
      jmax = input_data.get_jmax_relative ();

      const int spin = make_int (S_cluster_determine (nucleonic_particle));

      BPmin_global = 0;
      
      BPmax_global = (lmax == 0) ? (0) : (1);
      
      Jmin_global = abs (lmax - spin);
      Jmax_global =      lmax + spin;
    }
  
  N_valence_baryons_1h = (N_valence_baryons >= 1) ? (N_valence_baryons - 1) : (NO_VALENCE_NUCLEONS);
  N_valence_baryons_2h = (N_valence_baryons >= 2) ? (N_valence_baryons - 2) : (NO_VALENCE_NUCLEONS);
}








// One-body arrays and energy truncation values copied from input_data
// -------------------------------------------------------------------
// Arrays of potential parameters, basis wave function quantum numbers, natural orbital reference states and energy truncation arrays are allocated and filled here.

void baryons_data::alloc_fill_one_body_data_tables_E_min_max_hw (const class input_data_str &input_data)
{  
  const int S = hypernucleus_strangeness;

  const bool is_cv_possible = input_data.get_is_cv_possible ();

  const class array<enum particle_type> &hyperon_types = input_data.get_hyperon_types ();

  const unsigned int N_hyperon_types = hyperon_types.dimension (0);
    
  if (nucleonic_particle == PROTON)
    {      
      const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);
	  
      effective_masses_for_calc.allocate_fill (input_data.get_effective_masses_for_calc_p ());
      
      V0_KKNN_tab.allocate_fill     (input_data.get_V0_KKNN_p_tab ());  
      rho_KKNN_tab.allocate_fill    (input_data.get_rho_KKNN_p_tab ());			      
      Vls_KKNN_tab.allocate_fill    (input_data.get_Vls_KKNN_p_tab ());			      
      rho_ls_KKNN_tab.allocate_fill (input_data.get_rho_ls_KKNN_p_tab ());
      
      V0_KKNN_basis_core_potential_tab.allocate_fill     (input_data.get_V0_KKNN_basis_core_potential_p_tab ());  
      rho_KKNN_basis_core_potential_tab.allocate_fill    (input_data.get_rho_KKNN_basis_core_potential_p_tab ());			      
      Vls_KKNN_basis_core_potential_tab.allocate_fill    (input_data.get_Vls_KKNN_basis_core_potential_p_tab ());			      
      rho_ls_KKNN_basis_core_potential_tab.allocate_fill (input_data.get_rho_ls_KKNN_basis_core_potential_p_tab ());
  
      d_core_potential_tab.allocate_fill   (input_data.get_dp_core_potential_tab    ());
      R0_core_potential_tab.allocate_fill  (input_data.get_R0_p_core_potential_tab  ());
      Vo_core_potential_tab.allocate_fill  (input_data.get_Vo_p_core_potential_tab  ());
      Vso_core_potential_tab.allocate_fill (input_data.get_Vso_p_core_potential_tab ());

      d_basis_core_potential_tab.allocate_fill   (input_data.get_dp_basis_core_potential_tab    ());
      R0_basis_core_potential_tab.allocate_fill  (input_data.get_R0_p_basis_core_potential_tab  ());
      Vo_basis_core_potential_tab.allocate_fill  (input_data.get_Vo_p_basis_core_potential_tab  ());
      Vso_basis_core_potential_tab.allocate_fill (input_data.get_Vso_p_basis_core_potential_tab ());

      d_basis_tab.allocate_fill   (input_data.get_dp_basis_tab    ());
      R0_basis_tab.allocate_fill  (input_data.get_R0_p_basis_tab  ());
      Vo_basis_tab.allocate_fill  (input_data.get_Vo_p_basis_tab  ());
      Vso_basis_tab.allocate_fill (input_data.get_Vso_p_basis_tab ());
  
      if (N_nlj_baryon > 0)
	{	        
	  const class array<unsigned int> &Np_nlj_baryon_tab = input_data.get_Np_nlj_baryon_tab ();
      
	  const class array<class array<class nlj_struct> > &shells_quantum_numbers_p_tab = input_data.get_shells_quantum_numbers_p_tab ();

	  shells_quantum_numbers.allocate (N_nlj_baryon);

	  unsigned int ip = 0;

	  for (unsigned int p = 0 ; p < Np_baryon_type ; p++)
	    {      
	      const unsigned int Np_nlj = Np_nlj_baryon_tab(p);
      
	      const class array<class nlj_struct> &shells_quantum_numbers_p = shells_quantum_numbers_p_tab(p);
      
	      for (unsigned int i = 0 ; i < Np_nlj ; i++) shells_quantum_numbers(ip++) = shells_quantum_numbers_p(i);
	    }
	  
	  if (is_cv_possible)
	    {
	      const unsigned int N_spec_shells = S;
	  
	      for (unsigned int i = 0 ; i < N_spec_shells ; i++)
		shells_quantum_numbers(ip++).initialize (true , false , false , false , false , false , false , false , SPECTATOR , 0 , i , 0 , 0.5 , NO_SEGMENT , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0);   
	    }

	  shells_quantum_numbers.quick_sort (0 , N_nlj_baryon - 1);
	  
	  b_partial_waves_tab.allocate_fill (input_data.get_b_lab_partial_waves_p_tab ());

	  basis_potential_partial_waves_tab.allocate_fill (input_data.get_basis_potential_partial_waves_p_tab ());

	  optimized_partial_waves_data_alloc_fill (input_data);
	}
      
      baryon_types.allocate (Np_baryon_type);

      baryon_types = NO_PARTICLE;
      
      if (N_valence_nucleons > 0)
	{
	  const unsigned int prot_index = charge_baryon_index_determine (PROTON);

	  baryon_types(prot_index) = PROTON;
	}
        
      for (unsigned int i = 0 ; i < N_hyperon_types ; i++)
	{
	  const enum particle_type hyperon = hyperon_types(i);

	  const int Y_charge = particle_charge_determine (hyperon);

	  if (Y_charge != 0)
	    {
	      const unsigned int charge_baryon_index = charge_baryon_index_determine (hyperon);

	      baryon_types(charge_baryon_index) = hyperon;
	    }
	}
      
      effective_charges.allocate_fill (input_data.get_effective_charges_p ());
      
      are_there_basis_natural_orbitals_tab.allocate_fill (input_data.get_are_there_basis_natural_orbitals_p_tab ());

      are_there_new_natural_orbitals_tab.allocate_fill (input_data.get_are_there_new_natural_orbitals_p_tab ());
    }

  if (nucleonic_particle == NEUTRON)
    {
      const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
	  
      effective_masses_for_calc.allocate_fill (input_data.get_effective_masses_for_calc_n ());
      
      V0_KKNN_tab.allocate_fill     (input_data.get_V0_KKNN_n_tab ());  
      rho_KKNN_tab.allocate_fill    (input_data.get_rho_KKNN_n_tab ());			      
      Vls_KKNN_tab.allocate_fill    (input_data.get_Vls_KKNN_n_tab ());			      
      rho_ls_KKNN_tab.allocate_fill (input_data.get_rho_ls_KKNN_n_tab ());
      
      V0_KKNN_basis_core_potential_tab.allocate_fill     (input_data.get_V0_KKNN_basis_core_potential_n_tab ());  
      rho_KKNN_basis_core_potential_tab.allocate_fill    (input_data.get_rho_KKNN_basis_core_potential_n_tab ());			      
      Vls_KKNN_basis_core_potential_tab.allocate_fill    (input_data.get_Vls_KKNN_basis_core_potential_n_tab ());			      
      rho_ls_KKNN_basis_core_potential_tab.allocate_fill (input_data.get_rho_ls_KKNN_basis_core_potential_n_tab ());
      
      d_core_potential_tab.allocate_fill   (input_data.get_dn_core_potential_tab    ());
      R0_core_potential_tab.allocate_fill  (input_data.get_R0_n_core_potential_tab  ());
      Vo_core_potential_tab.allocate_fill  (input_data.get_Vo_n_core_potential_tab  ());
      Vso_core_potential_tab.allocate_fill (input_data.get_Vso_n_core_potential_tab ());

      d_basis_core_potential_tab.allocate_fill   (input_data.get_dn_basis_core_potential_tab    ());
      R0_basis_core_potential_tab.allocate_fill  (input_data.get_R0_n_basis_core_potential_tab  ());
      Vo_basis_core_potential_tab.allocate_fill  (input_data.get_Vo_n_basis_core_potential_tab  ());
      Vso_basis_core_potential_tab.allocate_fill (input_data.get_Vso_n_basis_core_potential_tab ());

      d_basis_tab.allocate_fill   (input_data.get_dn_basis_tab    ());
      R0_basis_tab.allocate_fill  (input_data.get_R0_n_basis_tab  ());
      Vo_basis_tab.allocate_fill  (input_data.get_Vo_n_basis_tab  ());
      Vso_basis_tab.allocate_fill (input_data.get_Vso_n_basis_tab ());

      if (N_nlj_baryon > 0)
	{      
	  const class array<unsigned int> &Nn_nlj_baryon_tab = input_data.get_Nn_nlj_baryon_tab ();
      
	  const class array<class array<class nlj_struct> > &shells_quantum_numbers_n_tab = input_data.get_shells_quantum_numbers_n_tab ();

	  shells_quantum_numbers.allocate (N_nlj_baryon);

	  unsigned int in = 0;
	  
	  for (unsigned int n = 0 ; n < Nn_baryon_type ; n++)
	    {      
	      const unsigned int Nn_nlj = Nn_nlj_baryon_tab(n);
      
	      const class array<class nlj_struct> &shells_quantum_numbers_n = shells_quantum_numbers_n_tab(n);
      
	      for (unsigned int i = 0 ; i < Nn_nlj ; i++) shells_quantum_numbers(in++) = shells_quantum_numbers_n(i);
	    }
	  
	  if (is_cv_possible)
	    {
	      const unsigned int N_spec_shells = S;
	      
	      for (unsigned int i = 0 ; i < N_spec_shells ; i++)
		shells_quantum_numbers(in++).initialize (true , false , false , false , false , false , false , false , SPECTATOR , 0 , i , 0 , 0.5 , NO_SEGMENT , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0);   
	    }
	  
	  shells_quantum_numbers.quick_sort (0 , N_nlj_baryon - 1);

	  b_partial_waves_tab.allocate_fill (input_data.get_b_lab_partial_waves_n_tab ());

	  basis_potential_partial_waves_tab.allocate_fill (input_data.get_basis_potential_partial_waves_n_tab ());
	  
	  optimized_partial_waves_data_alloc_fill (input_data);
	}      
      
      baryon_types.allocate (Nn_baryon_type);

      baryon_types = NO_PARTICLE;
      
      if (N_valence_nucleons > 0)
	{
	  const unsigned int neut_index = charge_baryon_index_determine (NEUTRON);

	  baryon_types(neut_index) = NEUTRON;
	}
        
      for (unsigned int i = 0 ; i < N_hyperon_types ; i++)
	{
	  const enum particle_type hyperon = hyperon_types(i);

	  const int Y_charge = particle_charge_determine (hyperon);

	  if (Y_charge == 0)
	    {
	      const unsigned int charge_baryon_index = charge_baryon_index_determine (hyperon);

	      baryon_types(charge_baryon_index) = hyperon;
	    }
	}
      
      effective_charges.allocate_fill (input_data.get_effective_charges_n ());
      
      are_there_basis_natural_orbitals_tab.allocate_fill (input_data.get_are_there_basis_natural_orbitals_n_tab ());

      are_there_new_natural_orbitals_tab.allocate_fill (input_data.get_are_there_new_natural_orbitals_n_tab ());
    }
  
  const double A_dependent_factor_core_potential = A_dependent_factor_core_potential_calc (nucleonic_particle , input_data);
  
  Vo_core_potential_tab *= A_dependent_factor_core_potential;
  
  Vo_basis_core_potential_tab *= A_dependent_factor_core_potential;
      
  if (is_it_two_nucleon_ST_cluster_determine (nucleonic_particle))
    {
      // All particle arrays have a dimension equal for the two-nucleon case.
      // The sole index is then that of the two-nucleon system and is not that of baryons.

      const double spin = S_cluster_determine (nucleonic_particle);
	
      const unsigned int prot_index = charge_baryon_index_determine (PROTON);
      const unsigned int neut_index = charge_baryon_index_determine (NEUTRON);
  
      const class array<double> &charged_baryon_masses_for_calc = input_data.get_effective_masses_for_calc_p ();
      
      const class array<double> &uncharged_baryon_masses_for_calc = input_data.get_effective_masses_for_calc_n ();
      
      const double prot_mass_for_calc =   charged_baryon_masses_for_calc(prot_index);
      const double neut_mass_for_calc = uncharged_baryon_masses_for_calc(neut_index);

      effective_masses_for_calc.allocate (1);
      
      effective_masses_for_calc(0) = two_nucleon_reduced_mass_calc (nucleonic_particle , prot_mass_for_calc , neut_mass_for_calc);
      
      d_basis_tab.allocate_fill   (input_data.get_d_basis_relative_tab   ());
      R0_basis_tab.allocate_fill  (input_data.get_R0_basis_relative_tab  ());
      Vo_basis_tab.allocate_fill  (input_data.get_Vo_basis_relative_tab  ());
      Vso_basis_tab.allocate_fill (input_data.get_Vso_basis_relative_tab ());

      if (N_nlj_baryon > 0)
	{
	  const double b_lab = input_data.get_b_lab ();

	  const double b_relative = b_lab*M_SQRT2;
	  
	  shells_quantum_numbers.allocate_fill (input_data.get_shells_quantum_numbers_relative ());
	  
	  shells_quantum_numbers.quick_sort (0 , N_nlj_baryon - 1);
	  
	  b_partial_waves_tab.allocate (1);
  	  
	  b_partial_waves_tab(0).allocate (spin , lmax);
	    
	  b_partial_waves_tab(0) = b_relative;

	  basis_potential_partial_waves_tab.allocate (1);
	  
	  basis_potential_partial_waves_tab(0).allocate (spin , lmax);

	  basis_potential_partial_waves_tab(0) = basis_potential;
	}
    }

  if (is_it_one_baryon_determine (nucleonic_particle))
    {
      const int E_relative_max_hw = input_data.get_E_relative_max_hw ();
  
      const int E_relative_max_hw_pole_approximation = input_data.get_E_relative_max_hw_pole_approximation ();
  
      E_min_hw = E_min_hw_pp_nn (N_valence_baryons , shells_quantum_numbers);
  
      E_max_hw = E_relative_max_hw + E_min_hw;

      E_max_hw_pole_approximation = E_relative_max_hw_pole_approximation + E_min_hw;
    }

  if (N_nlj_baryon > 0)
    {
      if (is_it_two_nucleon_ST_cluster_determine (nucleonic_particle))
	fill_nlj_one_body_indices_two_nucleon_ST_clusters_alloc_calc ();
      else
	fill_nljm_nlj_one_body_indices_baryons_alloc_calc ();    
    }
  
  debut_file_name = STORAGE_DIR + "Z" + make_string<int> (Z_basis) + "_N" + make_string<int> (N_basis);

  if (natural_orbitals_reference_states_number > 0)
    {     
      const int A_basis = Z_basis + N_basis;
	  
      natural_orbitals_reference_states.allocate (natural_orbitals_reference_states_number);

      const class array<unsigned int> &natural_orbitals_reference_states_BP_tab = input_data.get_natural_orbitals_reference_states_BP_tab ();

      const class array<unsigned int> &natural_orbitals_reference_states_vector_index_tab = input_data.get_natural_orbitals_reference_states_vector_index_tab ();

      const class array<double> &natural_orbitals_reference_states_J_tab = input_data.get_natural_orbitals_reference_states_J_tab ();

      for (unsigned int i = 0 ; i < natural_orbitals_reference_states_number ; i++)
	{
	  const unsigned int BP = natural_orbitals_reference_states_BP_tab(i);

	  const unsigned int vector_index = natural_orbitals_reference_states_vector_index_tab(i);

	  const double J = natural_orbitals_reference_states_J_tab(i);

	  const int two_J = make_int (2.0*J);	  

	  if (A_basis%2 != two_J%2) error_message_print_abort ("J is integer for A[basis] even and half-integer for A[basis] odd for J.Pi=" + J_Pi_string (BP , J) + " (natural orbital reference states)");

	  class correlated_state_str &natural_orbitals_reference_state = natural_orbitals_reference_states(i);

	  natural_orbitals_reference_state.initialize (Z , N , BP , S , J , vector_index , NADA , NADA , NADA , NADA , false);
	  
	  debut_file_name += "_" + J_Pi_vector_index_string_for_file_name (BP , J , vector_index);
	}
    }
}





// Arrays of indices, n[min] values, n[max] values and valence character of one-body shells and states are allocated and filled here.
// ----------------------------------------------------------------------------------------------------------------------------------

void baryons_data::fill_nljm_nlj_one_body_indices_baryons_alloc_calc ()
{
  const unsigned int N_baryon_type = baryon_types.dimension (0);

  nmax_lj_tabs.allocate (N_baryon_type);
  
  nmin_lj_valence_tabs.allocate (N_baryon_type);

  shells_indices_tab.allocate (N_baryon_type);
  	       
  is_it_valence_shell_tabs.allocate (N_baryon_type);
  
  for (unsigned int i = 0 ; i < N_baryon_type ; i++)
    {
      class lj_table<int> &nmax_lj_tab = nmax_lj_tabs(i);
      
      class lj_table<int> &nmin_lj_valence_tab = nmin_lj_valence_tabs(i);
      
      class nlj_table<unsigned int> &shells_indices = shells_indices_tab(i);
      
      class nlj_table<bool> &is_it_valence_shell_tab = is_it_valence_shell_tabs(i);
      
      nmax_lj_tab.allocate (0.5 , lmax);
      
      nmin_lj_valence_tab.allocate (0.5 , lmax);      
      
      shells_indices.allocate (0.5 , nmax , lmax);
      
      is_it_valence_shell_tab.allocate (0.5 , nmax , lmax);

      nmax_lj_tab = -1;
      
      nmin_lj_valence_tab = N_nlj_baryon;
            
      shells_indices = OUT_OF_RANGE;
      
      is_it_valence_shell_tab = false;
    }
  
  if (is_it_M_scheme)
    {
      phi_table.allocate (N_nljm_baryon);
      
      one_body_indices.allocate (baryon_types , nmax , lmax , N_nlj_baryon , m_max);
  
      TRS_nljm_indices.allocate (N_nljm_baryon);

      initial_to_nljm_ordered_states.allocate (N_nljm_baryon);

      nljm_ordered_to_initial_states.allocate (N_nljm_baryon);
    }
  
  unsigned int state = 0;
  
  for (unsigned int s = 0 ; s < N_nlj_baryon ; s++)
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(s);
      
      const enum particle_type particle = shell_qn.get_particle ();
  
      const double j = shell_qn.get_j ();

      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();

      const int e_trunc = shell_qn.get_e_trunc ();

      const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

      const bool core_state = shell_qn.get_core_state ();
      
      const bool frozen_state = shell_qn.get_frozen_state ();

      const bool hole_state = shell_qn.get_hole_state ();
            
      const unsigned int particle_index = charge_baryon_index_determine (particle);

      class lj_table<int> &nmax_lj_tab = nmax_lj_tabs(particle_index);
      
      class lj_table<int> &nmin_lj_valence_tab = nmin_lj_valence_tabs(particle_index);
      
      class nlj_table<unsigned int> &shells_indices = shells_indices_tab(particle_index);
        
      class nlj_table<bool> &is_it_valence_shell_tab = is_it_valence_shell_tabs(particle_index);
      
      shells_indices(n , l , j) = s;
      
      is_it_valence_shell_tab(n , l , j) = !frozen_state;

      int &nmax_lj = nmax_lj_tab(l , j);
 
      nmax_lj = max (nmax_lj , n);
      
      if (!core_state && !frozen_state)
	{
	  int &nmin_lj_valence = nmin_lj_valence_tab(l , j);

	  nmin_lj_valence = min (nmin_lj_valence , n);
	}

      if (is_it_M_scheme)
	{
	  const int two_j = make_int (2*j);

	  for (int m_index = 0 ; m_index <= two_j ; m_index++)
	    { 
	      const double m = m_index - j;

	      const int im = make_int (m + m_max);

	      phi_table(state).initialize (n , l , j , m , S_matrix_pole , core_state , frozen_state , hole_state , particle , e_trunc , s , m_max);

	      one_body_indices(particle , n , l , j , m) = one_body_indices(s , im) = state;

	      state++;
	    }
	}
    }

  for (unsigned int i = 0 ; i < N_baryon_type ; i++)
    {
      const class lj_table<int> &nmax_lj_tab = nmax_lj_tabs(i);
      
      class lj_table<int> &nmin_lj_valence_tab = nmin_lj_valence_tabs(i);
      
      for (int l = 0 ; l <= lmax ; l++)
	for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	  {
	    const int nmax_lj = nmax_lj_tab(l , j);
      
	    int &nmin_lj_valence = nmin_lj_valence_tab(l , j);
	  
	    if (nmin_lj_valence == make_int (N_nlj_baryon)) nmin_lj_valence = nmax_lj + 1;	
	  }
    }

  if (is_it_M_scheme)
    {
      TRS_nljm_indices = OUT_OF_RANGE;
      
      initial_to_nljm_ordered_states = OUT_OF_RANGE;

      nljm_ordered_to_initial_states = OUT_OF_RANGE;

      for (unsigned int s = 0 ; s < N_nljm_baryon ; s++)
	{
	  const class nljm_struct &phi = phi_table(s);
	  
	  const enum particle_type particle = phi.get_particle ();
      
	  const int n = phi.get_n ();
	  const int l = phi.get_l ();

	  const double j = phi.get_j ();
	  const double m = phi.get_m ();

	  TRS_nljm_indices(s) = one_body_indices(particle , n , l , j , -m);
	}

      for (unsigned int s = 0 ; s < N_nljm_baryon ; s++) initial_to_nljm_ordered_states (s) = s;

      initial_to_nljm_ordered_states_sort (0 , N_nljm_baryon - 1 , phi_table , initial_to_nljm_ordered_states);

      for (unsigned int s = 0 ; s < N_nljm_baryon ; s++) nljm_ordered_to_initial_states (initial_to_nljm_ordered_states(s)) = s;
    }
}








void baryons_data::fill_nlj_one_body_indices_two_nucleon_ST_clusters_alloc_calc ()
{
  const double spin = S_cluster_determine (nucleonic_particle);
  
  nmax_lj_tabs.allocate (1);
  
  shells_indices_tab.allocate (1);
  
  class lj_table<int> &nmax_lj_tab = nmax_lj_tabs(0);
            
  class nlj_table<unsigned int> &shells_indices = shells_indices_tab(0);
            
  nmax_lj_tab.allocate (spin , lmax);
            
  shells_indices.allocate (spin , nmax , lmax);
      
  nmax_lj_tab = -1;
                  
  shells_indices = OUT_OF_RANGE;
    
  for (unsigned int s = 0 ; s < N_nlj_baryon ; s++)
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(s);
        
      const double j = shell_qn.get_j ();

      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();
              
      shells_indices(n , l , j) = s;
      
      int &nmax_lj = nmax_lj_tab(l , j);
 
      nmax_lj = max (nmax_lj , n);
    }
}










// Overlaps between HO states (multiplied by a Fermi function or not) and basis states are allocated and calculated here.
// ----------------------------------------------------------------------------------------------------------------------

void baryons_data::HO_overlaps_alloc_calc (
					    const bool is_it_only_basis ,
					    const class input_data_str &input_data)
{
  const bool is_it_one_baryon_COSM_case = is_it_one_baryon_determine (nucleonic_particle);

  const class array<int> &nmax_HO_tab = (is_it_one_baryon_COSM_case) ? (input_data.get_nmax_HO_lab_tab ()) : (input_data.get_nmax_HO_relative_tab ());
  
  const int nmax_HO = nmax_HO_tab.max ();

  const int nmax_HO_plus_one = nmax_HO + 1;

  const int lmax_for_interaction_one_baryon_case = (is_it_only_basis) ? (input_data.get_lmax_for_basis_interaction ()) : (input_data.get_lmax_for_interaction ());

  const int lmax_for_interaction = (is_it_one_baryon_COSM_case) ? (lmax_for_interaction_one_baryon_case) : (lmax);

  const int lmax_for_interaction_plus_one = lmax_for_interaction + 1;

  class array<double> r_bef_R_tab_GL (N_bef_R_GL);
  class array<double> w_bef_R_tab_GL (N_bef_R_GL);

  class array<double> r_aft_R_tab_GL (N_aft_R_GL);
  class array<double> w_aft_R_tab_GL (N_aft_R_GL);
  
  class array<double> HO_wfs_bef_R_tab_GL(nmax_HO_plus_one , lmax_for_interaction_plus_one , N_bef_R_GL);
  class array<double> HO_wfs_aft_R_tab_GL(nmax_HO_plus_one , lmax_for_interaction_plus_one , N_aft_R_GL);

  const double b_lab = input_data.get_b_lab ();

  const double b_relative = b_lab*M_SQRT2;

  const double b_inter = (is_it_one_baryon_COSM_case) ? (b_lab) : (b_relative);

  if (is_it_only_basis)
    {
      HO_overlaps_basis.allocate (N_nlj_baryon);
      
      HO_overlaps_basis_Fermi.allocate (N_nlj_baryon);
    }
  else
    {
      HO_overlaps.allocate (N_nlj_baryon);
      
      HO_overlaps_Fermi.allocate (N_nlj_baryon);
    }

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R          , r_bef_R_tab_GL , w_bef_R_tab_GL);  
  Gauss_Legendre::abscissas_weights_tables_calc (R   , R_real_max , r_aft_R_tab_GL , w_aft_R_tab_GL);
  
  HO_wave_functions::HO_3D::u_r_tables_calc (b_inter , r_bef_R_tab_GL , HO_wfs_bef_R_tab_GL);
  HO_wave_functions::HO_3D::u_r_tables_calc (b_inter , r_aft_R_tab_GL , HO_wfs_aft_R_tab_GL);

  for (unsigned int s = 0 ; s < N_nlj_baryon ; s++)
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(s);

      const enum particle_type particle = shell_qn.get_particle ();
      
      const unsigned int particle_index = (!is_it_two_nucleon_ST_cluster_determine (particle)) ? (charge_baryon_index_determine (particle)) : (0);
     
      const class lj_table<double> &b_partial_waves = b_partial_waves_tab(particle_index);
      
      const int l = shell_qn.get_l ();

      const int nmax_HO_l = (l <= lmax_for_interaction) ? (nmax_HO_tab(l)) : (0);

      const int nmax_HO_l_plus_one = nmax_HO_l + 1;
      
      class vector_class<complex<double> > &HO_overlaps_shell       = (is_it_only_basis) ? (HO_overlaps_basis(s))       : (HO_overlaps(s));
      class vector_class<complex<double> > &HO_overlaps_Fermi_shell = (is_it_only_basis) ? (HO_overlaps_basis_Fermi(s)) : (HO_overlaps_Fermi(s));
      
      HO_overlaps_shell.allocate (nmax_HO_l_plus_one);
      
      HO_overlaps_Fermi_shell.allocate (nmax_HO_l_plus_one);

      HO_overlaps_shell = 0.0;

      HO_overlaps_Fermi_shell = 0.0;

      if (l > lmax_for_interaction) continue;

      const class spherical_state &shell = shells(s);
      
      const int n = shell_qn.get_n ();
      
      const double j = shell_qn.get_j ();
      
      const double b_shell = b_partial_waves(l , j);
      
      const bool is_it_HO = shell_qn.get_is_it_HO ();
      
      const class array<complex<double> > &wf_bef_R_tab_GL = shell.get_wf_bef_R_tab_GL ();
      const class array<complex<double> > &wf_aft_R_tab_GL = shell.get_wf_aft_R_tab_GL_real ();
      
      for (int n_HO = 0 ; n_HO <= nmax_HO_l ; n_HO++)
	{
	  if (is_it_HO && (abs (b_shell - b_inter) < precision)) 
	    {
	      HO_overlaps_shell(n_HO) = (n_HO == n) ? (1.0) : (0.0);

	      complex<double> HO_overlaps_Fermi_shell_n_HO = 0.0;

	      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
		HO_overlaps_Fermi_shell_n_HO += w_bef_R_tab_GL(i)*wf_bef_R_tab_GL(i)*HO_wfs_bef_R_tab_GL(n_HO , l , i)*Fermi_like_function (R_cut_function , d_cut_function , r_bef_R_tab_GL(i));

	      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
		HO_overlaps_Fermi_shell_n_HO += w_aft_R_tab_GL(i)*wf_aft_R_tab_GL(i)*HO_wfs_aft_R_tab_GL(n_HO , l , i)*Fermi_like_function (R_cut_function , d_cut_function , r_aft_R_tab_GL(i));

	      HO_overlaps_Fermi_shell(n_HO) = HO_overlaps_Fermi_shell_n_HO;
	    }
	  else
	    {
	      complex<double> HO_overlaps_shell_n_HO = 0.0;

	      complex<double> HO_overlaps_Fermi_shell_n_HO = 0.0;

	      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
		{
		  const double r = r_bef_R_tab_GL(i);

		  const double Fermi_r = Fermi_like_function (R_cut_function , d_cut_function , r);

		  const complex<double> wfs_w_product = w_bef_R_tab_GL(i)*wf_bef_R_tab_GL(i)*HO_wfs_bef_R_tab_GL(n_HO , l , i);
		  
		  HO_overlaps_shell_n_HO += wfs_w_product;
		  
		  HO_overlaps_Fermi_shell_n_HO += wfs_w_product*Fermi_r;
		}

	      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
		{	
		  const double r = r_aft_R_tab_GL(i);

		  const double Fermi_r = Fermi_like_function (R_cut_function , d_cut_function , r);

		  const complex<double> wfs_w_product = w_aft_R_tab_GL(i)*wf_aft_R_tab_GL(i)*HO_wfs_aft_R_tab_GL(n_HO , l , i);
		  
		  HO_overlaps_shell_n_HO += wfs_w_product;
		  
		  HO_overlaps_Fermi_shell_n_HO += wfs_w_product*Fermi_r;
		}

	      HO_overlaps_shell(n_HO) = HO_overlaps_shell_n_HO;

	      HO_overlaps_Fermi_shell(n_HO) = HO_overlaps_Fermi_shell_n_HO;
				
	    }
	}
      //HO_overlaps_Fermi_shell = HO_overlaps_shell;
    }
}














// Overlaps between GHF states and basis states are allocated and filled here.
// ---------------------------------------------------------------------------
// As one-body basis states are GHF states, overlaps are 0 or 1.

void baryons_data::GHF_overlaps_alloc_fill (const class input_data_str &input_data)
{
  const string debut_file_name_basis_state = debut_file_name + "_basis_state_";
    
  GHF_overlaps.allocate (N_nlj_baryon);

  if (basis_potential == QBOX_POTENTIAL)
    {
      const class array<int> &nmax_GHF_lab_tab = input_data.get_nmax_GHF_lab_tab ();
  
      for (unsigned int s = 0 ; s < N_nlj_baryon ; s++)
	{
	  const class nlj_struct &shell_qn = shells_quantum_numbers(s);
      
	  const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ();
	        
	  const enum particle_type particle = shell_qn.get_particle ();
	  
	  const unsigned int particle_index = charge_baryon_index_determine (particle);

	  const class lj_table<int> &nmax_lj_tab = nmax_lj_tabs(particle_index);
      
	  const string debut_file_name_basis_state_particle = debut_file_name_basis_state + "_" + make_string<enum particle_type> (particle);
  
	  const int n = shell_qn.get_n ();
	  const int l = shell_qn.get_l ();

	  const double j = shell_qn.get_j ();
	      		
	  const int nmax_GHF_l = nmax_GHF_lab_tab(l);
	  
	  const int nmax_lj = nmax_lj_tab(l , j);

	  if (nmax_GHF_l < nmax_lj) error_message_print_abort ("nmax.GHF[l=" + make_string<int> (l) +"] must be larger than one-body nmax of " + angular_state (l,j) + " for " + make_string<enum particle_type> (particle));
	  
	  const int nmax_GHF_l_plus_one = nmax_GHF_l + 1;
	  
	  class vector_class<complex<double> > &GHF_overlaps_shell = GHF_overlaps(s);
	  
	  GHF_overlaps_shell.allocate (nmax_GHF_l_plus_one);
            
	  if (is_it_natural_orbital)
	    {	
	      const string shell_qn_file_name_part = make_string<int> (n) + angular_state_for_file_name (l , j) + "_Berggren_basis_components.dat";
	      
	      GHF_overlaps_shell.read_disk (debut_file_name_basis_state_particle + shell_qn_file_name_part);
	    }
	  else
	    {
	      GHF_overlaps_shell = 0.0;
	      
	      GHF_overlaps_shell(n) = 1.0;
	    }
	}
    }
  else
    {
      for (unsigned int s = 0 ; s < N_nlj_baryon ; s++)
	{
	  const class nlj_struct &shell_qn = shells_quantum_numbers(s);
	      
	  const int n = shell_qn.get_n ();
	  const int l = shell_qn.get_l ();
	      
	  const double j = shell_qn.get_j ();

	  const enum particle_type particle = shell_qn.get_particle ();
	  
	  const unsigned int particle_index = charge_baryon_index_determine (particle);

	  const class lj_table<int> &nmax_lj_tab = nmax_lj_tabs(particle_index);
	  	  
	  const int nmax_lj = nmax_lj_tab(l , j);
	  
	  const int nmax_lj_plus_one = nmax_lj + 1;
      	
	  class vector_class<complex<double> > &GHF_overlaps_shell = GHF_overlaps(s);
	      
	  GHF_overlaps_shell.allocate (nmax_lj_plus_one);
	      
	  GHF_overlaps_shell = 0.0;
	      
	  GHF_overlaps_shell(n) = 1.0;
	}
    }
}

void baryons_data::all_HO_GHF_overlaps_alloc_calc (const class input_data_str &input_data)
{
  HO_overlaps_alloc_calc (true  , input_data);
  HO_overlaps_alloc_calc (false , input_data);
  
  GHF_overlaps_alloc_fill (input_data);
}






// OBMEs of different interaction one-body operators (H, nuclear part, kinetic part, Coulomb part) allocated and read from disk files.
// -----------------------------------------------------------------------------------------------------------------------------------

void baryons_data::OBMEs_inter_set_alloc_read_disk (const enum interaction_type inter)
{
  if ((nucleonic_particle != PROTON) && (nucleonic_particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in baryons_data::OBMEs_inter_set_alloc_read_disk");

  const string debut_file_name_OBMEs_inter_set = debut_file_name + "_" + make_string<enum particle_type> (nucleonic_particle) + "_coupled_OBMEs_";
  
  if (!OBMEs_inter_set.is_it_filled ())
    {
      if (is_it_M_scheme)
	OBMEs_inter_set.allocate (N_nlj_baryon , phi_table);
      else
	OBMEs_inter_set.allocate (N_nlj_baryon);
    }

  if (THIS_PROCESS == MASTER_PROCESS)
    {  
      const string file_name_N_nlj_baryon = debut_file_name + "_" + make_string<enum particle_type> (nucleonic_particle) + "_N_nlj_baryon.dat";
      
      const unsigned int N_nlj_baryon_from_file = dimension_read_disk (file_name_N_nlj_baryon);

      const string file_name_N_nljm_baryon = (is_it_M_scheme) ? (debut_file_name + "_" + make_string<enum particle_type> (nucleonic_particle) + "_N_nljm_baryon.dat") : ("");

      const unsigned int N_nljm_baryon_from_file = (is_it_M_scheme) ? (dimension_read_disk (file_name_N_nljm_baryon)) : (0);

      class array<class nlj_struct> shells_qn_from_file(N_nlj_baryon_from_file);

      const string file_name_shells_qn = debut_file_name + "_" + make_string<enum particle_type> (nucleonic_particle) + "_shells_quantum_numbers.dat";

      shells_qn_from_file.read_disk (file_name_shells_qn);

      class array<class nljm_struct> phi_table_from_file(N_nljm_baryon_from_file);

      const string file_name_phi_table = (is_it_M_scheme) ? (debut_file_name + "_" + make_string<enum particle_type> (nucleonic_particle) + "_phi_table.dat") : ("");

      if (is_it_M_scheme) phi_table_from_file.read_disk (file_name_phi_table);

      class OBMEs_inter_set_str OBMEs_inter_set_from_file;

      if (is_it_M_scheme)
	OBMEs_inter_set_from_file.allocate (N_nlj_baryon_from_file , phi_table_from_file);
      else
	OBMEs_inter_set_from_file.allocate (N_nlj_baryon_from_file);
 
      OBMEs_inter_set_from_file.read_disk (inter , debut_file_name_OBMEs_inter_set);

      const class array<TYPE> &OBMEs_H_from_file       = OBMEs_inter_set_from_file (inter);
      const class array<TYPE> &OBMEs_nuclear_from_file = OBMEs_inter_set_from_file (ONE_BODY_NUCLEAR);
      const class array<TYPE> &OBMEs_kinetic_from_file = OBMEs_inter_set_from_file (ONE_BODY_KINETIC);
      const class array<TYPE> &OBMEs_Coulomb_from_file = OBMEs_inter_set_from_file (ONE_BODY_COULOMB);

      class array<TYPE> &OBMEs_H       = OBMEs_inter_set (inter);
      class array<TYPE> &OBMEs_nuclear = OBMEs_inter_set (ONE_BODY_NUCLEAR);
      class array<TYPE> &OBMEs_kinetic = OBMEs_inter_set (ONE_BODY_KINETIC);
      class array<TYPE> &OBMEs_Coulomb = OBMEs_inter_set (ONE_BODY_COULOMB);

      OBMEs_H       = 0.0;
      OBMEs_nuclear = 0.0;
      OBMEs_kinetic = 0.0;
      OBMEs_Coulomb = 0.0;
  
      for (unsigned int s_from_file = 0 ; s_from_file < N_nlj_baryon_from_file ; s_from_file++)
	{
	  const class nlj_struct &shell_from_file = shells_qn_from_file(s_from_file);
	  
	  const int l = shell_from_file.get_l ();

	  if (l <= lmax)
	    {
	      const enum particle_type particle = shell_from_file.get_particle (); 
	      
	      const unsigned int particle_index = charge_baryon_index_determine (particle);
      
	      const class lj_table<int> &nmax_lj_tab = nmax_lj_tabs(particle_index);
      
	      const class nlj_table<unsigned int> &shells_indices = shells_indices_tab(particle_index);
      	  
	      const class nlj_table<bool> &is_it_valence_shell_tab = is_it_valence_shell_tabs(particle_index);
      
	      const double j = shell_from_file.get_j ();
	      
	      const int n = shell_from_file.get_n ();
	      
	      const int nmax_lj = nmax_lj_tab (l , j);

	      if (n <= nmax_lj)
		{
		  const bool is_it_valence_shell = is_it_valence_shell_tab(n , l , j);
	      
		  if (is_it_valence_shell)
		    {
		      const unsigned int s = shells_indices(n , l , j);
		  
		      for (unsigned int sp_from_file = 0 ; sp_from_file < N_nlj_baryon_from_file ; sp_from_file++)
			{
			  const class nlj_struct &shell_p_from_file = shells_qn_from_file(sp_from_file);
		      	      
			  const int lp = shell_p_from_file.get_l ();
		      
			  if (lp <= lmax)
			    {			      
			      const enum particle_type particle_p = shell_p_from_file.get_particle (); 
			      
			      const unsigned int particle_index_p = charge_baryon_index_determine (particle_p);
      
			      const class lj_table<int> &nmax_lj_p_tab = nmax_lj_tabs(particle_index_p);
      
			      const class nlj_table<unsigned int> &shells_indices_p = shells_indices_tab(particle_index_p);
	      
			      const class nlj_table<bool> &is_it_valence_shell_p_tab = is_it_valence_shell_tabs(particle_index_p);
			      
			      const double jp = shell_p_from_file.get_j ();
			      
			      const int np = shell_p_from_file.get_n ();
			      
			      const int np_max_lp_jp = nmax_lj_p_tab(lp , jp);
			      
			      if (np <= np_max_lp_jp)
				{
				  const bool is_it_valence_shell_p = is_it_valence_shell_p_tab(np , lp , jp);
				  
				  if (is_it_valence_shell_p)
				    {
				      const unsigned int sp = shells_indices_p(np , lp , jp);
				      
				      OBMEs_H      (s , sp) = OBMEs_H_from_file      (s_from_file , sp_from_file);
				      OBMEs_nuclear(s , sp) = OBMEs_nuclear_from_file(s_from_file , sp_from_file);
				      OBMEs_kinetic(s , sp) = OBMEs_kinetic_from_file(s_from_file , sp_from_file);
				      OBMEs_Coulomb(s , sp) = OBMEs_Coulomb_from_file(s_from_file , sp_from_file);
				    }}}}}}}}
    }

#ifdef UseMPI
  
  OBMEs_inter_set.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

#endif
}




// OBMEs of different one-body center-of-mass operators (Hcm, P^2/2M, L^(1), A+[CM-HO], rms radii) allocated and read from disk files.
// -----------------------------------------------------------------------------------------------------------------------------------

void baryons_data::OBMEs_CM_set_alloc_read_disk (const bool is_it_HO_expansion)
{
  if ((nucleonic_particle != PROTON) && (nucleonic_particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in baryons_data::OBMEs_CM_set_alloc_read_disk");
		
  const string debut_file_name_OBMEs_CM_set = debut_file_name + "_" + make_string<enum particle_type> (nucleonic_particle) + "_coupled_OBMEs_";

  if (is_it_HO_expansion)
    {
      if (!OBMEs_CM_set_HO_expansion.is_it_filled ())
	{
	  if (is_it_M_scheme)
	    OBMEs_CM_set_HO_expansion.allocate (N_nlj_baryon , phi_table);
	  else
	    OBMEs_CM_set_HO_expansion.allocate (N_nlj_baryon);
	}
    }
  else
    {
      if (!OBMEs_CM_set_R_cut.is_it_filled ())
	{
	  if (is_it_M_scheme)
	    OBMEs_CM_set_R_cut.allocate (N_nlj_baryon , phi_table);
	  else
	    OBMEs_CM_set_R_cut.allocate (N_nlj_baryon);
	}
    }

  class OBMEs_CM_set_str &OBMEs_CM_set = (is_it_HO_expansion) ? (OBMEs_CM_set_HO_expansion) : (OBMEs_CM_set_R_cut);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      const string file_name_N_nlj_baryon = debut_file_name + "_" + make_string<enum particle_type> (nucleonic_particle) + "_N_nlj_baryon.dat";
      
      const unsigned int N_nlj_baryon_from_file = dimension_read_disk (file_name_N_nlj_baryon);

      const string file_name_N_nljm_baryon = (is_it_M_scheme) ? (debut_file_name + "_" + make_string<enum particle_type> (nucleonic_particle) + "_N_nljm_baryon.dat") : ("");

      const unsigned int N_nljm_baryon_from_file = (is_it_M_scheme) ? (dimension_read_disk (file_name_N_nljm_baryon)) : (0);

      class array<class nlj_struct> shells_qn_from_file(N_nlj_baryon_from_file);

      const string file_name_shells_qn = debut_file_name + "_" + make_string<enum particle_type> (nucleonic_particle) + "_shells_quantum_numbers.dat";

      shells_qn_from_file.read_disk (file_name_shells_qn);

      class array<class nljm_struct> phi_table_from_file(N_nljm_baryon_from_file);

      const string file_name_phi_table = (is_it_M_scheme) ? (debut_file_name + "_" + make_string<enum particle_type> (nucleonic_particle) + "_phi_table.dat") : ("");

      if (is_it_M_scheme) phi_table_from_file.read_disk (file_name_phi_table);

      class OBMEs_CM_set_str OBMEs_CM_set_from_file;

      if (is_it_M_scheme)
	OBMEs_CM_set_from_file.allocate (N_nlj_baryon_from_file , phi_table_from_file);
      else
	OBMEs_CM_set_from_file.allocate (N_nlj_baryon_from_file);
 
      OBMEs_CM_set_from_file.read_disk (is_it_HO_expansion , debut_file_name_OBMEs_CM_set);
      
      const class array<TYPE> &OBMEs_Hcm_from_file                            = OBMEs_CM_set_from_file(HCM);
      const class array<TYPE> &OBMEs_CM_kinetic_from_file                     = OBMEs_CM_set_from_file(CM_KINETIC);
      const class array<TYPE> &OBMEs_L_reduced_tensor_from_file               = OBMEs_CM_set_from_file(L_REDUCED_TENSOR);
      const class array<TYPE> &OBMEs_A_dagger_CM_HO_reduced_tensor_from_file  = OBMEs_CM_set_from_file(A_DAGGER_CM_HO_REDUCED_TENSOR);
      const class array<TYPE> &OBMEs_rms_radius_from_file                     = OBMEs_CM_set_from_file(RMS_RADIUS);

      class array<TYPE> &OBMEs_Hcm                           = OBMEs_CM_set(HCM);
      class array<TYPE> &OBMEs_CM_kinetic                    = OBMEs_CM_set(CM_KINETIC);
      class array<TYPE> &OBMEs_L_reduced_tensor              = OBMEs_CM_set(L_REDUCED_TENSOR);
      class array<TYPE> &OBMEs_A_dagger_CM_HO_reduced_tensor = OBMEs_CM_set(A_DAGGER_CM_HO_REDUCED_TENSOR);
      class array<TYPE> &OBMEs_rms_radius                    = OBMEs_CM_set(RMS_RADIUS);

      OBMEs_Hcm                           = 0.0;
      OBMEs_CM_kinetic                    = 0.0;
      OBMEs_L_reduced_tensor              = 0.0;
      OBMEs_A_dagger_CM_HO_reduced_tensor = 0.0;
      OBMEs_rms_radius                    = 0.0;

      for (unsigned int s_from_file = 0 ; s_from_file < N_nlj_baryon_from_file ; s_from_file++)
	{
	  const class nlj_struct &shell_from_file = shells_qn_from_file(s_from_file);

	  const int l = shell_from_file.get_l ();

	  if (l <= lmax)
	    {
	      const enum particle_type particle = shell_from_file.get_particle (); 
	      
	      const unsigned int particle_index = charge_baryon_index_determine (particle);
	      	      
	      const class lj_table<int> &nmax_lj_tab = nmax_lj_tabs(particle_index);
      
	      const class nlj_table<unsigned int> &shells_indices = shells_indices_tab(particle_index);
	      
	      const class nlj_table<bool> &is_it_valence_shell_tab = is_it_valence_shell_tabs(particle_index);
	      
	      const double j = shell_from_file.get_j ();
	      
	      const int n = shell_from_file.get_n ();

	      const int nmax_lj = nmax_lj_tab (l , j);

	      if (n <= nmax_lj)
		{
		  const bool is_it_valence_shell = is_it_valence_shell_tab(n , l , j);
	      
		  if (is_it_valence_shell)
		    {
		      const unsigned int s = shells_indices(n , l , j);

		      for (unsigned int sp_from_file = 0 ; sp_from_file < N_nlj_baryon_from_file ; sp_from_file++)
			{
			  const class nlj_struct &shell_p_from_file = shells_qn_from_file(sp_from_file);

			  const int lp = shell_p_from_file.get_l ();

			  if (lp <= lmax)
			    {
			      const enum particle_type particle_p = shell_p_from_file.get_particle (); 
			      	      
			      const unsigned int particle_index_p = charge_baryon_index_determine (particle_p);
      	      	      
			      const class lj_table<int> &nmax_lj_p_tab = nmax_lj_tabs(particle_index_p);
      
			      const class nlj_table<unsigned int> &shells_indices_p = shells_indices_tab(particle_index_p);
			      
			      const class nlj_table<bool> &is_it_valence_shell_p_tab = is_it_valence_shell_tabs(particle_index_p);
			      
			      const double jp = shell_p_from_file.get_j ();

			      const int np = shell_p_from_file.get_n ();

			      const int np_max_lp_jp = nmax_lj_p_tab(lp , jp);
	      	      
			      if (np <= np_max_lp_jp)
				{
				  const bool is_it_valence_shell_p = is_it_valence_shell_p_tab(np , lp , jp);
			      
				  if (is_it_valence_shell_p)
				    {
				      const unsigned int sp = shells_indices_p(np , lp , jp);;
				      
				      OBMEs_Hcm                           (s , sp) = OBMEs_Hcm_from_file                          (s_from_file , sp_from_file);
				      OBMEs_CM_kinetic                    (s , sp) = OBMEs_CM_kinetic_from_file                   (s_from_file , sp_from_file);
				      OBMEs_L_reduced_tensor              (s , sp) = OBMEs_L_reduced_tensor_from_file             (s_from_file , sp_from_file);
				      OBMEs_A_dagger_CM_HO_reduced_tensor (s , sp) = OBMEs_A_dagger_CM_HO_reduced_tensor_from_file(s_from_file , sp_from_file);
				      OBMEs_rms_radius                    (s , sp) = OBMEs_rms_radius_from_file                   (s_from_file , sp_from_file);
				    }}}}}}}}
    }
  
#ifdef UseMPI
  
  OBMEs_CM_set.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

#endif
}



















// OBMEs of different operators (interaction and center-of-mass) involving natural orbitals stored in files here.
// --------------------------------------------------------------------------------------------------------------

void baryons_data::natural_orbitals_OBMEs_basis_store (const class interaction_class &inter_data) const
{  
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in baryons_data::natural_orbitals_OBMEs_basis_store.");

  if ((nucleonic_particle != PROTON) && (nucleonic_particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in baryons_data::natural_orbitals_OBMEs_basis_store");

  if (N_nlj_baryon == 0) return;
  
  const unsigned int N_baryon_type = baryon_types.dimension (0);
  
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  class array<class lj_table<class matrix<TYPE> > > new_basis_change_matrices_tab(N_baryon_type);

  for (unsigned int i = 0 ; i < N_baryon_type ; i++)
    {
      const enum particle_type particle = baryon_types(i);

      if (particle == NO_PARTICLE) continue;

      const unsigned int particle_index = charge_baryon_index_determine (particle);
            
      const class lj_table<int> &nmax_lj_tab = nmax_lj_tabs(particle_index);
      
      const class lj_table<class matrix<TYPE> > &natural_orbitals_matrices = natural_orbitals_matrices_tab(particle_index);
      
      class lj_table<class matrix<TYPE> > &new_basis_change_matrices = new_basis_change_matrices_tab(particle_index);
  
      new_basis_change_matrices.allocate (0.5 , lmax);      
      
      for (int l = 0 ; l <= lmax ; l++)
	for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	  {
	    const int nmax_lj = nmax_lj_tab(l , j);
	    
	    if (nmax_lj >= 0)
	      {
		const class matrix<TYPE> &natural_orbitals_matrix = natural_orbitals_matrices(l , j);
		
		new_basis_change_matrices(l , j).allocate_fill (natural_orbitals_matrix);
	      }
	  }
    }

  new_basis_calc_store (new_basis_change_matrices_tab);
    
  const string file_name_N_nlj_baryon = debut_file_name + "_" + make_string<enum particle_type> (nucleonic_particle) + "_N_nlj_baryon.dat";

  dimension_copy_disk (file_name_N_nlj_baryon , N_nlj_baryon);

  const string file_name_shells_quantum_numbers = debut_file_name + "_" + make_string<enum particle_type> (nucleonic_particle) + "_shells_quantum_numbers.dat";

  shells_quantum_numbers.copy_disk (file_name_shells_quantum_numbers);

  if (is_it_M_scheme)
    {
      const string file_name_N_nljm_baryon = debut_file_name + "_" + make_string<enum particle_type> (nucleonic_particle) + "_N_nljm_baryon.dat";
      
      dimension_copy_disk (file_name_N_nljm_baryon , N_nljm_baryon);
  
      const string file_name_phi_table = debut_file_name + "_" + make_string<enum particle_type> (nucleonic_particle) + "_phi_table.dat";

      phi_table.copy_disk (file_name_phi_table);
    }
      
  OBMEs_inter_CM_sets_new_basis_calc_store (TBME_inter , new_basis_change_matrices_tab);
}










// New one-body basis states expanded with the initial one-body basis states stored on files as vectors
// ----------------------------------------------------------------------------------------------------

void baryons_data::new_basis_calc_store (const class array<class lj_table<class matrix<TYPE> > > &new_basis_change_matrices_tab) const
{
  if ((nucleonic_particle != PROTON) && (nucleonic_particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in baryons_data::new_basis_calc_store");
  
  const string debut_file_name_basis_state = debut_file_name + "_basis_state_";
    
  for (unsigned int s = 0 ; s < N_nlj_baryon ; s++)
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(s);
      
      const enum particle_type particle = shell_qn.get_particle ();
      
      const unsigned int particle_index = charge_baryon_index_determine (particle);
	      
      const class lj_table<int> &nmax_lj_tab = nmax_lj_tabs(particle_index);
      
      const class nlj_table<unsigned int> &shells_indices = shells_indices_tab(particle_index);
      
      const double j = shell_qn.get_j ();
      
      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();
      
      const int nmax_lj = nmax_lj_tab(l , j);

      if (nmax_lj >= 0)
	{
	  const bool core_state = shell_qn.get_core_state ();
	  
	  const bool frozen_state = shell_qn.get_frozen_state ();

	  if (core_state && frozen_state) continue;

	  const int nmax_lj_plus_one = nmax_lj + 1;
	  
	  class array<unsigned int> basis_shells_lj_indices(nmax_lj_plus_one);
	  
	  for (int nn = 0 ; nn <= nmax_lj ; nn++)
	    {
	      const unsigned int s = shells_indices(nn , l , j);
	      
	      basis_shells_lj_indices(nn) = s;
	    }

	  const class lj_table<class matrix<TYPE> > &new_basis_change_matrices = new_basis_change_matrices_tab(particle_index);
	
	  const class matrix<TYPE> &new_basis_change_matrix = new_basis_change_matrices(l , j);
	  
	  const class vector_class<TYPE> &Vn = new_basis_change_matrix.eigenvector (n);
	  
	  const unsigned int basis_shell_index = basis_shells_lj_indices(n);
	  
	  const class spherical_state &basis_shell = shells(basis_shell_index);
	  
	  class spherical_state new_shell(basis_shell);
	  
	  new_shell.wave_calculation_from_vector (false , NADA , Vn , basis_shells_lj_indices , shells);
	  
	  if (THIS_PROCESS == MASTER_PROCESS)
	    {
	      const string debut_file_name_basis_state_particle = debut_file_name_basis_state + "_" + make_string<enum particle_type> (particle);
  
	      new_shell.copy_to_file_no_scaled_wfs (debut_file_name_basis_state);
	      
	      const string shell_qn_file_name_part = make_string<int> (n) + angular_state_for_file_name (l , j) + "_Berggren_basis_components.dat";
	      
	      Vn.copy_disk (debut_file_name_basis_state_particle + shell_qn_file_name_part);
	    }
	}
    }
}




// OBMEs of different interaction one-body operators (H, nuclear part, kinetic part, Coulomb part) involving the new one-body basis above stored on disk here.
// -----------------------------------------------------------------------------------------------------------------------------------------------------------

void baryons_data::OBMEs_inter_set_new_basis_calc_store (
							 const enum interaction_type inter ,
							 const class matrix<TYPE> &new_basis_change_matrix_all_lj) const
{
  if ((nucleonic_particle != PROTON) && (nucleonic_particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in baryons_data::OBMEs_inter_set_new_basis_calc_store");

  const class array<TYPE> &OBMEs_H       = OBMEs_inter_set (inter);
  const class array<TYPE> &OBMEs_nuclear = OBMEs_inter_set (ONE_BODY_NUCLEAR);
  const class array<TYPE> &OBMEs_kinetic = OBMEs_inter_set (ONE_BODY_KINETIC);
  const class array<TYPE> &OBMEs_Coulomb = OBMEs_inter_set (ONE_BODY_COULOMB);

  class OBMEs_inter_set_str OBMEs_inter_set_new_basis;

  if (is_it_M_scheme)
    OBMEs_inter_set_new_basis.allocate (N_nlj_baryon , phi_table);
  else
    OBMEs_inter_set_new_basis.allocate (N_nlj_baryon);
    
  class array<TYPE> &OBMEs_H_new_basis       = OBMEs_inter_set_new_basis (inter);
  class array<TYPE> &OBMEs_nuclear_new_basis = OBMEs_inter_set_new_basis (ONE_BODY_NUCLEAR);
  class array<TYPE> &OBMEs_kinetic_new_basis = OBMEs_inter_set_new_basis (ONE_BODY_KINETIC);
  class array<TYPE> &OBMEs_Coulomb_new_basis = OBMEs_inter_set_new_basis (ONE_BODY_COULOMB);
  
  similarity_transformation_with_arrays (OBMEs_H       , new_basis_change_matrix_all_lj , OBMEs_H_new_basis);
  similarity_transformation_with_arrays (OBMEs_nuclear , new_basis_change_matrix_all_lj , OBMEs_nuclear_new_basis);
  similarity_transformation_with_arrays (OBMEs_kinetic , new_basis_change_matrix_all_lj , OBMEs_kinetic_new_basis);
  similarity_transformation_with_arrays (OBMEs_Coulomb , new_basis_change_matrix_all_lj , OBMEs_Coulomb_new_basis);
  
  const string debut_file_name_coupled_OBMEs = debut_file_name + "_" + make_string<enum particle_type> (nucleonic_particle) + "_coupled_OBMEs_";

  OBMEs_inter_set_new_basis.copy_disk (inter , debut_file_name_coupled_OBMEs);
}






// OBMEs of different one-body center-of-mass operators (Hcm, P^2/2M, L^(1), A+[CM-HO], rms radii) involving the new one-body basis above stored on disk here.
// -----------------------------------------------------------------------------------------------------------------------------------------------------------

void baryons_data::OBMEs_CM_set_new_basis_calc_store (
						      const bool is_it_HO_expansion , 
						      const class matrix<TYPE> &new_basis_change_matrix_all_lj) const
{
  if ((nucleonic_particle != PROTON) && (nucleonic_particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in baryons_data::OBMEs_CM_set_new_basis_calc_store");

  const class OBMEs_CM_set_str &OBMEs_CM_set = (is_it_HO_expansion) ? (OBMEs_CM_set_HO_expansion) : (OBMEs_CM_set_R_cut);

  const class array<TYPE> &OBMEs_Hcm                           = OBMEs_CM_set (HCM);
  const class array<TYPE> &OBMEs_CM_kinetic                    = OBMEs_CM_set (CM_KINETIC);
  const class array<TYPE> &OBMEs_L_reduced_tensor              = OBMEs_CM_set (L_REDUCED_TENSOR);
  const class array<TYPE> &OBMEs_A_dagger_CM_HO_reduced_tensor = OBMEs_CM_set (A_DAGGER_CM_HO_REDUCED_TENSOR);
  const class array<TYPE> &OBMEs_rms_radius                    = OBMEs_CM_set (RMS_RADIUS);

  class OBMEs_CM_set_str OBMEs_CM_set_new_basis;

  if (is_it_M_scheme)
    OBMEs_CM_set_new_basis.allocate (N_nlj_baryon , phi_table);
  else
    OBMEs_CM_set_new_basis.allocate (N_nlj_baryon);

  class array<TYPE> &OBMEs_Hcm_new_basis                           = OBMEs_CM_set_new_basis (HCM);
  class array<TYPE> &OBMEs_CM_kinetic_new_basis                    = OBMEs_CM_set_new_basis (CM_KINETIC);
  class array<TYPE> &OBMEs_L_reduced_tensor_new_basis              = OBMEs_CM_set_new_basis (L_REDUCED_TENSOR);
  class array<TYPE> &OBMEs_A_dagger_CM_HO_reduced_tensor_new_basis = OBMEs_CM_set_new_basis (A_DAGGER_CM_HO_REDUCED_TENSOR);
  class array<TYPE> &OBMEs_rms_radius_new_basis                    = OBMEs_CM_set_new_basis (RMS_RADIUS);

  similarity_transformation_with_arrays (OBMEs_Hcm                           , new_basis_change_matrix_all_lj , OBMEs_Hcm_new_basis);
  similarity_transformation_with_arrays (OBMEs_CM_kinetic                    , new_basis_change_matrix_all_lj , OBMEs_CM_kinetic_new_basis);
  similarity_transformation_with_arrays (OBMEs_L_reduced_tensor              , new_basis_change_matrix_all_lj , OBMEs_L_reduced_tensor_new_basis);
  similarity_transformation_with_arrays (OBMEs_A_dagger_CM_HO_reduced_tensor , new_basis_change_matrix_all_lj , OBMEs_A_dagger_CM_HO_reduced_tensor_new_basis);
  similarity_transformation_with_arrays (OBMEs_rms_radius                    , new_basis_change_matrix_all_lj , OBMEs_rms_radius_new_basis);

  const string debut_file_name_coupled_OBMEs = debut_file_name + "_" + make_string<enum particle_type> (nucleonic_particle) + "_coupled_OBMEs_";

  OBMEs_CM_set_new_basis.copy_disk (is_it_HO_expansion , debut_file_name_coupled_OBMEs);
}







// OBMEs of different interaction one-body operators (H, nuclear part, kinetic part, Coulomb part) and one-body center-of-mass operators (Hcm, P^2/2M, L^(1), A+[CM-HO], rms radii) involving the new one-body basis above stored on disk here.
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


void baryons_data::OBMEs_inter_CM_sets_new_basis_calc_store (
							     const enum interaction_type inter ,
							     const class array<class lj_table<class matrix<TYPE> > > &new_basis_change_matrices_tab) const
{
  if (N_nlj_baryon == 0) return;
  
  class matrix<TYPE> new_basis_change_matrix_all_lj(N_nlj_baryon);

  new_basis_change_matrix_all_lj = 0.0;

  for (unsigned int s = 0 ; s < N_nlj_baryon ; s++)
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(s);

      const enum particle_type particle = shell_qn.get_particle ();
      
      const unsigned int particle_index = charge_baryon_index_determine (particle);
      
      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();

      const double j = shell_qn.get_j ();
      
      for (unsigned int sp = 0 ; sp < N_nlj_baryon ; sp++)
	{
	  const class nlj_struct &shell_p_qn = shells_quantum_numbers(sp);
	            
	  if (same_lj_particle (shell_qn , shell_p_qn))
	    {
	      const class lj_table<class matrix<TYPE> > &new_basis_change_matrices = new_basis_change_matrices_tab(particle_index);
	      
	      const class matrix<TYPE> &new_basis_change_matrix_lj = new_basis_change_matrices(l , j);

	      const int np = shell_p_qn.get_n ();

	      new_basis_change_matrix_all_lj(s , sp) = new_basis_change_matrix_lj(n , np);
	    }
	}
    }  
  
  OBMEs_inter_set_new_basis_calc_store (inter , new_basis_change_matrix_all_lj);

  OBMEs_CM_set_new_basis_calc_store (true  , new_basis_change_matrix_all_lj);
  OBMEs_CM_set_new_basis_calc_store (false , new_basis_change_matrix_all_lj);
}






















// Calculations of the largest possible number of Slater determinants of fixed quantum numbers accessible with [a+ a] or [a+ a+ a a] operators from a given Slater determinant
// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

void baryons_data::dimensions_1p1h_2p2h_space_BP_S_iM_fixed_max_calc_print (const bool is_there_cout_detailed)
{
  if ((nucleonic_particle != PROTON) && (nucleonic_particle != NEUTRON)) error_message_print_abort ("One-body basis space only in baryons_data::dimensions_1p1h_2p2h_space_BP_S_iM_fixed_max_calc_print");
  
  const unsigned int N_strangeness = hypernucleus_strangeness + 1;
    
  class array<unsigned int> N_nlj_baryon_bp_s_tab(2 , N_strangeness);

  N_nlj_baryon_bp_s_tab = 0;
  
  for (unsigned int bp = 0 ; bp <= 1 ; bp++)
    for (int s = 0 ; s <= hypernucleus_strangeness ; s++)
      N_nlj_baryon_bp_s_tab(bp , s) = N_nlj_baryon_bp_s_fixed_determine (bp , s , shells_quantum_numbers);
  
  const unsigned int N_nlj_baryon_bp_s_fixed_max = N_nlj_baryon_bp_s_tab.max ();
  
  const unsigned int N_valence_pairs_number = (N_valence_baryons*(N_valence_baryons - 1))/2;
  
  const unsigned int N_pairs_number_BP_S_iM_fixed_max = (N_nljm_baryon*N_nlj_baryon_bp_s_fixed_max)/2;

  dimension_1p1h_space_BP_S_iM_fixed_max = N_nlj_baryon_bp_s_fixed_max*N_valence_baryons;

  dimension_2p2h_space_BP_S_iM_fixed_max = (N_valence_baryons >= 2) ? (N_valence_pairs_number*N_pairs_number_BP_S_iM_fixed_max + 1) : (0);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_it_M_scheme && is_there_cout_detailed)
    {
      const string charged_str = (nucleonic_particle == PROTON) ? ("a charged") : ("an uncharged");
      
      cout << endl;
      cout << "Maximal number of 1p-1h excitations from " << charged_str << " SD with parity, strangeness and M fixed for inSD and outSD : " << dimension_1p1h_space_BP_S_iM_fixed_max << endl;
      cout << "Maximal number of 2p-2h excitations from " << charged_str << " SD with parity, strangeness and M fixed for inSD and outSD : " << dimension_2p2h_space_BP_S_iM_fixed_max << endl << endl;
    }
}






// Potential one-body arrays, values assoiated to the HO wave functions of the HO expansion of operators and energy truncation values copied from input_data or calculated
// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Arrays of potential parameters are copied from input_data.
// Quantum numbers of HO shells entering the HO expansion of operators, associated indices, as well as the number of HO shells and states are evaluated.
// HO wave functions are calculated as well and stored as one-body basis.
// Energy truncation values are calculated.

void baryons_data::alloc_fill_one_body_data_tables_E_min_max_hw_HO_expansion (const class input_data_str &input_data)
{  
  if ((nucleonic_particle != PROTON) && (nucleonic_particle != NEUTRON)) error_message_print_abort ("Proton or neutron nucleonic particle only in baryons_data::alloc_fill_one_body_data_tables_E_min_max_hw_HO_expansion");     
      
  const class array<enum particle_type> &hyperon_types = input_data.get_hyperon_types ();

  const unsigned int N_hyperon_types = hyperon_types.dimension (0);
  
  if (nucleonic_particle == PROTON)
    {	
      const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);
      
      effective_masses_for_calc.allocate_fill (input_data.get_effective_masses_for_calc_p ());
  
      V0_KKNN_tab.allocate_fill     (input_data.get_V0_KKNN_p_tab ());  
      rho_KKNN_tab.allocate_fill    (input_data.get_rho_KKNN_p_tab ());			      
      Vls_KKNN_tab.allocate_fill    (input_data.get_Vls_KKNN_p_tab ());			      
      rho_ls_KKNN_tab.allocate_fill (input_data.get_rho_ls_KKNN_p_tab ());
      
      V0_KKNN_basis_core_potential_tab.allocate_fill     (input_data.get_V0_KKNN_basis_core_potential_p_tab ());  
      rho_KKNN_basis_core_potential_tab.allocate_fill    (input_data.get_rho_KKNN_basis_core_potential_p_tab ());			      
      Vls_KKNN_basis_core_potential_tab.allocate_fill    (input_data.get_Vls_KKNN_basis_core_potential_p_tab ());			      
      rho_ls_KKNN_basis_core_potential_tab.allocate_fill (input_data.get_rho_ls_KKNN_basis_core_potential_p_tab ());
      
      d_core_potential_tab.allocate_fill   (input_data.get_dp_core_potential_tab ());
      R0_core_potential_tab.allocate_fill  (input_data.get_R0_p_core_potential_tab ());
      Vo_core_potential_tab.allocate_fill  (input_data.get_Vo_p_core_potential_tab ());
      Vso_core_potential_tab.allocate_fill (input_data.get_Vso_p_core_potential_tab ());

      d_basis_core_potential_tab.allocate_fill   (input_data.get_dp_basis_core_potential_tab ());
      R0_basis_core_potential_tab.allocate_fill  (input_data.get_R0_p_basis_core_potential_tab ());
      Vo_basis_core_potential_tab.allocate_fill  (input_data.get_Vo_p_basis_core_potential_tab ());
      Vso_basis_core_potential_tab.allocate_fill (input_data.get_Vso_p_basis_core_potential_tab ());

      d_basis_tab.allocate_fill   (input_data.get_dp_basis_tab ());
      R0_basis_tab.allocate_fill  (input_data.get_R0_p_basis_tab ());
      Vo_basis_tab.allocate_fill  (input_data.get_Vo_p_basis_tab ());
      Vso_basis_tab.allocate_fill (input_data.get_Vso_p_basis_tab ());

      b_partial_waves_tab.allocate_fill (input_data.get_b_lab_partial_waves_p_tab ());
        
      basis_potential_partial_waves_tab.allocate_fill (input_data.get_basis_potential_partial_waves_p_tab ());
      
      baryon_types.allocate (Np_baryon_type);

      baryon_types = NO_PARTICLE;
      
      if (N_valence_nucleons > 0)
	{
	  const unsigned int prot_index = charge_baryon_index_determine (PROTON);

	  baryon_types(prot_index) = PROTON;
	}
        
      for (unsigned int i = 0 ; i < N_hyperon_types ; i++)
	{
	  const enum particle_type hyperon = hyperon_types(i);

	  const int Y_charge = particle_charge_determine (hyperon);

	  if (Y_charge != 0)
	    {
	      const unsigned int charge_baryon_index = charge_baryon_index_determine (hyperon);

	      baryon_types(charge_baryon_index) = hyperon;
	    }
	}
      
      effective_charges.allocate_fill (input_data.get_effective_charges_p ());
      
      are_there_basis_natural_orbitals_tab.allocate (Np_baryon_type);
      
      are_there_basis_natural_orbitals_tab = false;
    }

  if (nucleonic_particle == NEUTRON)
    {	
      const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
      
      effective_masses_for_calc.allocate_fill (input_data.get_effective_masses_for_calc_n ());
      
      V0_KKNN_tab.allocate_fill     (input_data.get_V0_KKNN_n_tab ());  
      rho_KKNN_tab.allocate_fill    (input_data.get_rho_KKNN_n_tab ());			      
      Vls_KKNN_tab.allocate_fill    (input_data.get_Vls_KKNN_n_tab ());			      
      rho_ls_KKNN_tab.allocate_fill (input_data.get_rho_ls_KKNN_n_tab ());
      
      V0_KKNN_basis_core_potential_tab.allocate_fill     (input_data.get_V0_KKNN_basis_core_potential_n_tab ());  
      rho_KKNN_basis_core_potential_tab.allocate_fill    (input_data.get_rho_KKNN_basis_core_potential_n_tab ());			      
      Vls_KKNN_basis_core_potential_tab.allocate_fill    (input_data.get_Vls_KKNN_basis_core_potential_n_tab ());			      
      rho_ls_KKNN_basis_core_potential_tab.allocate_fill (input_data.get_rho_ls_KKNN_basis_core_potential_n_tab ());
      
      d_core_potential_tab.allocate_fill   (input_data.get_dn_core_potential_tab ());
      R0_core_potential_tab.allocate_fill  (input_data.get_R0_n_core_potential_tab ());
      Vo_core_potential_tab.allocate_fill  (input_data.get_Vo_n_core_potential_tab ());
      Vso_core_potential_tab.allocate_fill (input_data.get_Vso_n_core_potential_tab ());

      d_basis_core_potential_tab.allocate_fill   (input_data.get_dn_basis_core_potential_tab ());
      R0_basis_core_potential_tab.allocate_fill  (input_data.get_R0_n_basis_core_potential_tab ());
      Vo_basis_core_potential_tab.allocate_fill  (input_data.get_Vo_n_basis_core_potential_tab ());
      Vso_basis_core_potential_tab.allocate_fill (input_data.get_Vso_n_basis_core_potential_tab ());

      d_basis_tab.allocate_fill   (input_data.get_dn_basis_tab ());
      R0_basis_tab.allocate_fill  (input_data.get_R0_n_basis_tab ());
      Vo_basis_tab.allocate_fill  (input_data.get_Vo_n_basis_tab ());
      Vso_basis_tab.allocate_fill (input_data.get_Vso_n_basis_tab ());

      b_partial_waves_tab.allocate_fill (input_data.get_b_lab_partial_waves_n_tab ());
        
      basis_potential_partial_waves_tab.allocate_fill (input_data.get_basis_potential_partial_waves_n_tab ());
      
      baryon_types.allocate (Nn_baryon_type);

      baryon_types = NO_PARTICLE;
      
      if (N_valence_nucleons > 0)
	{
	  const unsigned int neut_index = charge_baryon_index_determine (NEUTRON);

	  baryon_types(neut_index) = NEUTRON;
	}
        
      for (unsigned int i = 0 ; i < N_hyperon_types ; i++)
	{
	  const enum particle_type hyperon = hyperon_types(i);

	  const int Y_charge = particle_charge_determine (hyperon);

	  if (Y_charge == 0)
	    {
	      const unsigned int charge_baryon_index = charge_baryon_index_determine (hyperon);

	      baryon_types(charge_baryon_index) = hyperon;
	    }
	}
  
      effective_charges.allocate_fill (input_data.get_effective_charges_n ());
      
      are_there_basis_natural_orbitals_tab.allocate (Nn_baryon_type);
      
      are_there_basis_natural_orbitals_tab = false;
    }
  
  const enum interaction_type inter = input_data.get_inter ();
  
  const bool is_it_COSM = is_it_COSM_determine (inter);

  const bool is_it_cluster_CM_HO_basis_calculation = input_data.get_is_it_cluster_CM_HO_basis_calculation ();

  const double mass_modif = (!is_it_COSM) ? (-nucleus_mass_basis) : (nucleus_mass_basis);

  const bool is_it_charged = (nucleonic_particle == PROTON);
      
  const unsigned int N_baryon_type = (is_it_charged) ? (N_charged_baryon_type_determine (hypernucleus_strangeness)) : (N_uncharged_baryon_type_determine (hypernucleus_strangeness));
      
  if (is_it_cluster_CM_HO_basis_calculation)
    {      
      n_scat_max = (is_it_charged) ? (input_data.get_n_scat_max_p ()) : (input_data.get_n_scat_max_n ());

      n_holes_max = n_holes_max_pole_approximation = 0;

      const class array<class array<class nlj_struct> > &shells_quantum_numbers_tab_input = (is_it_charged) ? (input_data.get_shells_quantum_numbers_p_tab ()) : (input_data.get_shells_quantum_numbers_n_tab ());

      const class array<unsigned int> &N_nlj_res_baryon_tab  = (is_it_charged) ? (input_data.get_Np_nlj_res_baryon_tab ())  : (input_data.get_Nn_nlj_res_baryon_tab ());
      const class array<unsigned int> &N_nljm_res_baryon_tab = (is_it_charged) ? (input_data.get_Np_nljm_res_baryon_tab ()) : (input_data.get_Nn_nljm_res_baryon_tab ());

      const class array<unsigned int> &N_nlj_baryon_tab  = (is_it_charged) ? (input_data.get_Np_nlj_baryon_tab ())  : (input_data.get_Nn_nlj_baryon_tab ());
      const class array<unsigned int> &N_nljm_baryon_tab = (is_it_charged) ? (input_data.get_Np_nljm_baryon_tab ()) : (input_data.get_Nn_nljm_baryon_tab ());

      N_nlj_res_baryon  = N_nlj_res_baryon_tab.sum ();
      N_nljm_res_baryon = N_nljm_res_baryon_tab.sum ();

      N_nlj_baryon  = N_nlj_baryon_tab.sum ();
      N_nljm_baryon = N_nljm_baryon_tab.sum ();
	  
      shells_quantum_numbers.allocate (N_nlj_baryon);

      unsigned int index = 0;

      for (unsigned int i = 0 ; i < N_baryon_type ; i++)
	{      
	  const unsigned int N_nlj = N_nlj_baryon_tab(i);
      
	  const class array<class nlj_struct> &shells_quantum_numbers_input = shells_quantum_numbers_tab_input(i);
      	  
	  for (unsigned int i = 0 ; i < N_nlj ; i++) shells_quantum_numbers(index++) = shells_quantum_numbers_input(i);
	}
    }
  else
    {
      const int lmax_plus_one = lmax + 1;
      
      const class array<int> &nmax_HO_lab_tab_input = input_data.get_nmax_HO_lab_tab ();

      class array<int> nmax_HO_lab_tab(lmax_plus_one);

      n_scat_max = n_holes_max = n_holes_max_pole_approximation = 0;
      
      nmax_HO_lab_tab = 0;

      for (int l = 0 ; l <= lmax ; l++) nmax_HO_lab_tab(l) = nmax_HO_lab_tab_input(l);

      const unsigned int N_nlj_baryon_HO = N_nlj_calc (nmax_HO_lab_tab);

      N_nlj_baryon = N_nlj_res_baryon = N_nlj_baryon_HO;

      shells_quantum_numbers.allocate (N_nlj_baryon_HO);

      unsigned int index_nlj = 0;

      for (unsigned int i = 0 ; i < N_baryon_type ; i++)
	{
	  const enum particle_type particle = baryon_from_charge_index_determine (is_it_charged , i);
	  
	  for (int l = 0 ; l <= lmax ; l++)
	    for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	      {
		const int n_max_l = nmax_HO_lab_tab (l);

		for (int n = 0 ; n <= n_max_l ; n++)
		  {
		    const int e_trunc = 2*n + l;

		    shells_quantum_numbers(index_nlj++).initialize (true , false , false , false , false , true , false , false , particle , e_trunc ,
								    n , l , j , NO_SEGMENT , NADA , NADA , NADA , NADA , NADA , NADA , NADA , NADA);
		  }
	      }
	}
      
      N_nljm_baryon = N_nljm_res_baryon = N_nljm_calc (nmax_HO_lab_tab);
    }

  if (N_nlj_baryon > 0) shells_quantum_numbers.quick_sort (0 , N_nlj_baryon - 1);

  shells.allocate (N_nlj_baryon);

  for (unsigned int i = 0 ; i < N_nlj_baryon ; i++)
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(i);

      const enum particle_type particle = shell_qn.get_particle ();
      
      const unsigned int particle_index = charge_baryon_index_determine (particle);
	  
      const double effective_mass_for_calc = effective_masses_for_calc (particle_index);
      
      const class lj_table<double> &b_partial_waves = b_partial_waves_tab(particle_index);

      const int particle_charge = particle_charge_determine (particle);
      
      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();

      const double j = shell_qn.get_j ();

      const double b = b_partial_waves(l , j);

      const int ZY_charge_basis_potential = (particle_charge > 0) ? (ZY_charge_basis_potential_pos) : (ZY_charge_basis_potential_neg);
      
      class spherical_state &shell_HO = shells(i);

      shell_HO.allocate (false , true , HO_POTENTIAL , A_basis , ZY_charge_basis_potential , mass_modif , NADA ,
			 N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , Nk_momentum_GL , Nk_momentum_uniform ,
			 R , NADA , NADA , R_real_max , kmax_momentum , R_Fermi_momentum , true , particle , n , NADA , l , j , false , NADA , effective_mass_for_calc , 1.0 , 1.0);

      shell_HO.HO_wave_function (b);
    }

  fill_nljm_nlj_one_body_indices_baryons_alloc_calc ();

  dimensions_1p1h_2p2h_space_BP_S_iM_fixed_max_calc_print (false);

  const int E_relative_max_hw = input_data.get_E_relative_max_hw ();
  
  const int E_relative_max_hw_pole_approximation = input_data.get_E_relative_max_hw_pole_approximation ();
  
  E_min_hw = E_min_hw_pp_nn (N_valence_baryons , shells_quantum_numbers);
  
  E_max_hw = E_relative_max_hw + E_min_hw;

  E_max_hw_pole_approximation = E_relative_max_hw_pole_approximation + E_min_hw;
}





// Linear momenta are calculated and stored form their associated energy
// ---------------------------------------------------------------------
// This arises for example with standard HO-SM, where energy is given first.

void baryons_data::shells_quantum_numbers_k_fill_from_h ()
{
  for (unsigned int s = 0 ; s < N_nlj_baryon ; s++)
    {
      class nlj_struct &shell_qn = shells_quantum_numbers(s);

      const enum particle_type particle = shell_qn.get_particle ();
      
      const unsigned int particle_index = charge_baryon_index_determine (particle);

      const double effective_mass_for_calc = effective_masses_for_calc (particle_index);
      
      const double kinetic_factor = kinetic_factor_calc (false , nucleus_mass , effective_mass_for_calc);
  
      const class nlj_table<TYPE> &h_basis = h_basis_tab(particle_index);
      
      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();
      
      const double j = shell_qn.get_j ();

      const TYPE e = h_basis(n , l , j);

      const complex<double> k = sqrt_mod (kinetic_factor*e);

      shell_qn.initialize (
			   shell_qn.get_S_matrix_pole () ,
			   shell_qn.get_core_state () ,
			   shell_qn.get_frozen_state () ,
			   shell_qn.get_hole_state () ,
			   shell_qn.get_OCM_valence_state () ,
			   shell_qn.get_is_it_HO () ,
			   shell_qn.get_is_it_for_HF_gs () ,
			   shell_qn.get_is_it_natural_orbital () ,
			   shell_qn.get_particle () ,
			   shell_qn.get_e_trunc () ,
			   n , l , j ,
			   shell_qn.get_segment () ,
			   k ,
			   shell_qn.get_w () ,
			   shell_qn.get_C0 () ,
			   shell_qn.get_Cplus () ,
			   shell_qn.get_k_plus () ,
			   shell_qn.get_C0_plus () ,
			   shell_qn.get_k_minus () ,
			   shell_qn.get_C0_minus ());
    }
}





// Constants of baryons_data are initialized here from the class baryons_data of another nucleus
// -----------------------------------------------------------------------------------------------

void baryons_data::initialize_constants_from_other_nucleus (
							     const bool is_core_suppressed , 
							     const int Z_new_nucleus , 
							     const int N_new_nucleus , 
							     const int Y_new_nucleus , 
							     const double nucleus_mass_new_nucleus , 
							     const double total_nucleus_mass_new_nucleus , 
							     const class baryons_data &data_other_nucleus)
{
  is_it_M_scheme = data_other_nucleus.is_it_M_scheme;
  
  nucleonic_particle = data_other_nucleus.nucleonic_particle;
    
  A_core = (is_core_suppressed) ? (0) : (data_other_nucleus.A_core);
  Z_core = (is_core_suppressed) ? (0) : (data_other_nucleus.Z_core);
  N_core = (is_core_suppressed) ? (0) : (data_other_nucleus.N_core);
  
  Z = Z_new_nucleus;
  N = N_new_nucleus;
  
  A = Z + N + Y_new_nucleus;
  
  Z_basis = data_other_nucleus.Z_basis;
  N_basis = data_other_nucleus.N_basis;
  
  A_basis = Z_basis + N_basis;

  hole_states_number = data_other_nucleus.hole_states_number;

  N_nucleons = (nucleonic_particle == PROTON) ? (Z) : (N);

  nucleus_mass = nucleus_mass_new_nucleus;
  
  total_nucleus_mass = total_nucleus_mass_new_nucleus;

  R_charge = data_other_nucleus.R_charge;
  
  basis_potential = data_other_nucleus.basis_potential;
  
  H_potential = data_other_nucleus.H_potential;
  
  good_isospin_basis_potential = data_other_nucleus.good_isospin_basis_potential;
  
  N_bef_R_GL = data_other_nucleus.N_bef_R_GL;
  N_aft_R_GL = data_other_nucleus.N_aft_R_GL;
  
  N_bef_R_uniform = data_other_nucleus.N_bef_R_uniform;
  N_aft_R_uniform = data_other_nucleus.N_aft_R_uniform;
  
  Nk_momentum_uniform = data_other_nucleus.Nk_momentum_uniform;
  Nk_momentum_GL  = data_other_nucleus.Nk_momentum_GL;
  
  is_it_OCM_HO_core = data_other_nucleus.is_it_OCM_HO_core;
  
  R_cut_function = data_other_nucleus.R_cut_function;
  d_cut_function = data_other_nucleus.d_cut_function;
  
  R = data_other_nucleus.R;

  step_bef_R_uniform = data_other_nucleus.step_bef_R_uniform;
  
  R_real_max = data_other_nucleus.R_real_max;
  
  step_momentum_uniform = data_other_nucleus.step_momentum_uniform;
  
  kmax_momentum = data_other_nucleus.kmax_momentum;

  R_Fermi_momentum = data_other_nucleus.R_Fermi_momentum;
  
  const unsigned int N_nucleons_core = (nucleonic_particle == PROTON) ? (Z_core) : (N_core);
  
  if (N_nucleons + hole_states_number < N_nucleons_core) return;

  if (N_nucleons == 0) return;

  is_Coulomb_Hamiltonian_here = data_other_nucleus.is_Coulomb_Hamiltonian_here;
  
  are_there_basis_natural_orbitals = data_other_nucleus.are_there_basis_natural_orbitals;

  are_there_new_natural_orbitals = data_other_nucleus.are_there_new_natural_orbitals;
  
  natural_orbitals_reference_states_number = data_other_nucleus.natural_orbitals_reference_states_number;
  
  N_valence_nucleons = N_nucleons - N_nucleons_core + hole_states_number;

  N_valence_baryons = N_valence_nucleons + Y_new_nucleus;
  
  N_valence_baryons_1h = (N_valence_baryons >= 1) ? (N_valence_baryons - 1) : (NO_VALENCE_NUCLEONS);
  N_valence_baryons_2h = (N_valence_baryons >= 2) ? (N_valence_baryons - 2) : (NO_VALENCE_NUCLEONS);
  
  n_scat_max = min (data_other_nucleus.n_scat_max , make_int (N_valence_baryons));
  
  n_holes_max = data_other_nucleus.n_holes_max;
  
  n_holes_max_pole_approximation = data_other_nucleus.n_holes_max_pole_approximation;  
  
  if ((nucleonic_particle == PROTON) && is_Coulomb_Hamiltonian_here) ZY_charge_pos = (N_valence_baryons > 0) ? (Z_core + N_valence_baryons - 1) : (Z_core);
  if ((nucleonic_particle == PROTON) && is_Coulomb_Hamiltonian_here) ZY_charge_neg = (N_valence_baryons > 0) ? (Z_core + N_valence_baryons + 1) : (Z_core);
  
  ZY_charge_basis_potential_pos = data_other_nucleus.ZY_charge_basis_potential_pos;
  ZY_charge_basis_potential_neg = data_other_nucleus.ZY_charge_basis_potential_neg;

  N_valence_nucleons_basis = data_other_nucleus.N_valence_nucleons_basis;
  
  N_nljm_baryon = data_other_nucleus.N_nljm_baryon;
  
  N_nlj_baryon = data_other_nucleus.N_nlj_baryon;
  
  N_nlj_res_baryon = data_other_nucleus.N_nlj_res_baryon;

  N_nljm_res_baryon = data_other_nucleus.N_nljm_res_baryon;

  BPmin_global = data_other_nucleus.BPmin_global;
  BPmax_global = data_other_nucleus.BPmax_global;
  
  Jmin_global = data_other_nucleus.Jmin_global;
  Jmax_global = data_other_nucleus.Jmax_global;
  
  nmax = data_other_nucleus.nmax;
  lmax = data_other_nucleus.lmax;

  jmax = data_other_nucleus.jmax;

  m_min = data_other_nucleus.m_min;
  m_max = data_other_nucleus.m_max;
  
  m_max_minus_half = data_other_nucleus.m_max_minus_half;
  
  two_m_max = data_other_nucleus.two_m_max;

  four_m_max = data_other_nucleus.four_m_max;
  
  m_max_minus_m_min = data_other_nucleus.m_max_minus_m_min;
}



// One-body arrays and energy truncation arrays copied from the class baryons_data of another nucleus
// ----------------------------------------------------------------------------------------------------
// One considers here also wave functions, HF and HO overlaps arrays, but not natural orbital arrays.

void baryons_data::alloc_copy_one_body_data_tables_E_min_max_hw (const class baryons_data &data_other_nucleus)
{
  const unsigned int N_nucleons_core = (nucleonic_particle == PROTON) ? (Z_core) : (N_core); 
  
  if (N_nucleons + hole_states_number < N_nucleons_core) return;
  
  baryon_types.allocate_fill (data_other_nucleus.baryon_types);
  
  effective_masses_for_calc.allocate_fill (data_other_nucleus.effective_masses_for_calc);
      
  V0_KKNN_tab.allocate_fill     (data_other_nucleus.V0_KKNN_tab);  
  rho_KKNN_tab.allocate_fill    (data_other_nucleus.rho_KKNN_tab);
  Vls_KKNN_tab.allocate_fill    (data_other_nucleus.Vls_KKNN_tab);			      
  rho_ls_KKNN_tab.allocate_fill (data_other_nucleus.rho_ls_KKNN_tab);
  
  V0_KKNN_basis_core_potential_tab.allocate_fill     (data_other_nucleus.V0_KKNN_basis_core_potential_tab);  
  rho_KKNN_basis_core_potential_tab.allocate_fill    (data_other_nucleus.rho_KKNN_basis_core_potential_tab);
  Vls_KKNN_basis_core_potential_tab.allocate_fill    (data_other_nucleus.Vls_KKNN_basis_core_potential_tab);  
  rho_ls_KKNN_basis_core_potential_tab.allocate_fill (data_other_nucleus.rho_ls_KKNN_basis_core_potential_tab);
				 
  d_core_potential_tab.allocate_fill   (data_other_nucleus.d_core_potential_tab);
  R0_core_potential_tab.allocate_fill  (data_other_nucleus.R0_core_potential_tab);
  Vo_core_potential_tab.allocate_fill  (data_other_nucleus.Vo_core_potential_tab);
  Vso_core_potential_tab.allocate_fill (data_other_nucleus.Vso_core_potential_tab);

  d_basis_core_potential_tab.allocate_fill   (data_other_nucleus.d_basis_core_potential_tab);
  R0_basis_core_potential_tab.allocate_fill  (data_other_nucleus.R0_basis_core_potential_tab);
  Vo_basis_core_potential_tab.allocate_fill  (data_other_nucleus.Vo_basis_core_potential_tab);
  Vso_basis_core_potential_tab.allocate_fill (data_other_nucleus.Vso_basis_core_potential_tab);

  d_basis_tab.allocate_fill   (data_other_nucleus.d_basis_tab);
  R0_basis_tab.allocate_fill  (data_other_nucleus.R0_basis_tab);
  Vo_basis_tab.allocate_fill  (data_other_nucleus.Vo_basis_tab);
  Vso_basis_tab.allocate_fill (data_other_nucleus.Vso_basis_tab);

  OBMEs_CM_set_HO_expansion.allocate_fill (data_other_nucleus.OBMEs_CM_set_HO_expansion);

  OBMEs_CM_set_R_cut.allocate_fill (data_other_nucleus.OBMEs_CM_set_R_cut);
  
  reduced_grad_HO_expansion_set.allocate_fill (data_other_nucleus.reduced_grad_HO_expansion_set);
  
  reduced_r_HO_expansion_set.allocate_fill (data_other_nucleus.reduced_r_HO_expansion_set);

  reduced_r_HO_expansion_rms_radius_different_particles_set.allocate_fill (data_other_nucleus.reduced_r_HO_expansion_rms_radius_different_particles_set);
  
  reduced_grad_R_cut_set.allocate_fill (data_other_nucleus.reduced_grad_R_cut_set);
  
  reduced_r_R_cut_set.allocate_fill (data_other_nucleus.reduced_r_R_cut_set);

  reduced_r_R_cut_rms_radius_different_particles_set.allocate_fill (data_other_nucleus.reduced_r_R_cut_rms_radius_different_particles_set);

  OBMEs_multipole_square_HO_expansion.allocate_fill (data_other_nucleus.OBMEs_multipole_square_HO_expansion);
  
  OBMEs_multipole_square_R_cut.allocate_fill (data_other_nucleus.OBMEs_multipole_square_R_cut);
				 
  OBMEs_multipole_reduced_HO_expansion.allocate_fill (data_other_nucleus.OBMEs_multipole_reduced_HO_expansion);
  
  OBMEs_multipole_reduced_R_cut.allocate_fill (data_other_nucleus.OBMEs_multipole_reduced_R_cut);
  
  OBMEs_inter_set.allocate_fill (data_other_nucleus.OBMEs_inter_set);

  nmax_lj_tabs.allocate_fill (data_other_nucleus.nmax_lj_tabs);

  nmin_lj_valence_tabs.allocate_fill (data_other_nucleus.nmin_lj_valence_tabs);
  
  is_it_valence_shell_tabs.allocate_fill (data_other_nucleus.is_it_valence_shell_tabs);
  
  Ueq_finite_range_tab_uniform.allocate_fill (data_other_nucleus.Ueq_finite_range_tab_uniform);
  
  source_tab_uniform.allocate_fill (data_other_nucleus.source_tab_uniform);
  
  OBMEs_HF_SGI_MSGI.allocate_fill (data_other_nucleus.OBMEs_HF_SGI_MSGI);

  shells_indices_tab.allocate_fill (data_other_nucleus.shells_indices_tab);

  one_body_indices.allocate_fill (data_other_nucleus.one_body_indices);

  if (nucleonic_particle == PROTON)
    {
      Ueq_finite_range_plus_tab_uniform.allocate_fill  (data_other_nucleus.Ueq_finite_range_plus_tab_uniform);
      Ueq_finite_range_minus_tab_uniform.allocate_fill (data_other_nucleus.Ueq_finite_range_minus_tab_uniform);
      
      source_plus_tab_uniform.allocate_fill  (data_other_nucleus.source_plus_tab_uniform);
      source_minus_tab_uniform.allocate_fill (data_other_nucleus.source_minus_tab_uniform);
    }

  b_partial_waves_tab.allocate_fill (data_other_nucleus.b_partial_waves_tab);
  
  basis_potential_partial_waves_tab.allocate_fill (data_other_nucleus.basis_potential_partial_waves_tab);
  
  h_basis_tab.allocate_fill (data_other_nucleus.h_basis_tab);

  TRS_nljm_indices.allocate_fill (data_other_nucleus.TRS_nljm_indices);

  phi_table.allocate_fill (data_other_nucleus.phi_table);
  
  initial_to_nljm_ordered_states.allocate_fill (data_other_nucleus.initial_to_nljm_ordered_states);
  
  nljm_ordered_to_initial_states.allocate_fill (data_other_nucleus.nljm_ordered_to_initial_states);

  shells_quantum_numbers.allocate_fill (data_other_nucleus.shells_quantum_numbers);

  shells.allocate_fill (data_other_nucleus.shells);
  
  shells_plus.allocate_fill (data_other_nucleus.shells_plus);
  shells_minus.allocate_fill (data_other_nucleus.shells_minus);

  U_finite_range_HF_HO_basis_HO_expansion_part.allocate_fill (data_other_nucleus.U_finite_range_HF_HO_basis_HO_expansion_part);

  HO_overlaps.allocate_fill (data_other_nucleus.HO_overlaps);

  HO_overlaps_Fermi.allocate_fill (data_other_nucleus.HO_overlaps_Fermi);
  
  GHF_overlaps.allocate_fill (data_other_nucleus.GHF_overlaps);
  
  basis_PSI_quantum_numbers_tab.allocate_fill (data_other_nucleus.basis_PSI_quantum_numbers_tab);

  dimensions_1p1h_2p2h_space_BP_S_iM_fixed_max_calc_print (false);

  const unsigned int N_valence_baryons_other_nucleus = data_other_nucleus.N_valence_baryons;
  
  E_min_hw = E_min_hw_pp_nn (N_valence_baryons , shells_quantum_numbers);
  
  const int E_min_hw_other_nucleus = E_min_hw_pp_nn (N_valence_baryons_other_nucleus , shells_quantum_numbers);
  
  const int E_max_hw_other_nucleus = data_other_nucleus.E_max_hw;
  
  E_max_hw = E_max_hw_other_nucleus + E_min_hw - E_min_hw_other_nucleus;
  
  effective_charges.allocate_fill (data_other_nucleus.effective_charges);
  
  are_there_basis_natural_orbitals_tab.allocate_fill (data_other_nucleus.are_there_basis_natural_orbitals_tab);

  are_there_new_natural_orbitals_tab.allocate_fill (data_other_nucleus.are_there_new_natural_orbitals_tab);
}







// Arrays of quantum numbers of one-body states and many-body states at HF/MSDHF level allocated and filled here from input_data
// -----------------------------------------------------------------------------------------------------------------------------

void baryons_data::optimized_partial_waves_data_alloc_fill (const class input_data_str &input_data)
{
  if ((nucleonic_particle != PROTON) && (nucleonic_particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in baryons_data::optimized_partial_waves_data_alloc_fill");

  const int Z_basis = input_data.get_Z_basis ();
  const int N_basis = input_data.get_N_basis ();

  basis_PSI_quantum_numbers_tab.allocate (0.5 , lmax);

  const class lj_table<unsigned int> &prot_basis_BP_tab = input_data.get_prot_basis_BP_tab ();
  const class lj_table<unsigned int> &neut_basis_BP_tab = input_data.get_neut_basis_BP_tab ();

  const class lj_table<unsigned int> &basis_BP_tab = (nucleonic_particle == PROTON) ? (prot_basis_BP_tab) : (neut_basis_BP_tab);

  if (!basis_BP_tab.is_it_filled ()) return;

  const class lj_table<double> &prot_basis_J_tab = input_data.get_prot_basis_J_tab ();
  const class lj_table<double> &neut_basis_J_tab = input_data.get_neut_basis_J_tab ();

  const class lj_table<double> &basis_J_tab = (nucleonic_particle == PROTON) ? (prot_basis_J_tab) : (neut_basis_J_tab);

  if (!basis_J_tab.is_it_filled ()) return;

  for (int l = 0 ; l <= lmax ; l++)
    {
      const double jminus = (l > 0) ? (l - 0.5) : (NADA);

      const double jplus = l + 0.5;

      if (l > 0)
	{
	  const unsigned int BP_l_jminus = basis_BP_tab(l , jminus);

	  const double J_l_jminus = basis_J_tab(l , jminus);

	  if ((BP_l_jminus != 2) && (J_l_jminus > -0.1))
	    basis_PSI_quantum_numbers_tab (l , jminus).initialize (Z_basis , N_basis , BP_l_jminus , 0 , J_l_jminus , 0 , NADA , NADA , NADA , NADA , false);
	}

      const unsigned int BP_l_jplus = basis_BP_tab(l , jplus);

      const double J_l_jplus = basis_J_tab(l , jplus);

      if ((BP_l_jplus != 2) && (J_l_jplus > -0.1))
	basis_PSI_quantum_numbers_tab (l , jplus).initialize (Z_basis , N_basis , BP_l_jplus , 0 , J_l_jplus , 0 , NADA , NADA , NADA , NADA , false);
    }
}






// Arrays of HF/MSDHF potentials and OBMEs allocated and filled here from a class HF_nucleons_data 
// -----------------------------------------------------------------------------------------------
// One cannot use operator = , one has to use loops , as dimensions of tables in HF_data and particles_data are different in general.

void baryons_data::HF_potentials_quantum_numbers_OBMEs_write (
							       const enum interaction_type TBME_inter , 
							       const class HF_nucleons_data &HF_data)
{  
  if ((nucleonic_particle != PROTON) && (nucleonic_particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in baryons_data::HF_potentials_quantum_numbers_OBMEs_write");
  
  const unsigned int N_nlj_baryon_HF = HF_data.get_N_nlj ();
    
  if ((N_nlj_baryon_HF == 0) || (N_nlj_baryon == 0)) return;

  const unsigned int N_baryon_type = baryon_types.dimension (0);
  
  const int nmax_HF = HF_data.get_nmax ();
  const int lmax_HF = HF_data.get_lmax ();
  
  const int nmax_small = min (nmax_HF , nmax);
  const int lmax_small = min (lmax_HF , lmax);
  
  const class nlj_table<complex<double> > &HF_Ueq_finite_range_averaged_tab_uniform = HF_data.get_Ueq_finite_range_averaged_tab_uniform ();

  const class nlj_table<complex<double> > &HF_source_averaged_tab_uniform = HF_data.get_source_averaged_tab_uniform ();

  const class lj_table<class matrix<complex<double> > > &U_finite_range_HF_HO_basis_HO_expansion_part_copy = HF_data.get_U_finite_range_HF_HO_basis_HO_expansion_part ();  

  const class array<class nlj_struct> &HF_shells_quantum_numbers = HF_data.get_shells_quantum_numbers ();
  
  const bool is_it_SGI  = is_it_SGI_determine  (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  if (is_it_SGI || is_it_MSGI)
    {
      const class lj_table<complex<double> > &OBMEs_HF_SGI_MSGI_copy = HF_data.get_OBMEs_HF_SGI_MSGI ();

      for (int l = 0 ; l <= lmax_small ; l++)
	for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	  for (int n = 0 ; n <= nmax_small ; n++)
	    for (int np = 0 ; np <= nmax_small ; np++)
	      OBMEs_HF_SGI_MSGI(l , j , n , np) = OBMEs_HF_SGI_MSGI_copy(l , j , n , np);
    }

  class array<class nlj_table<int> > e_trunc_tabs(N_baryon_type);
  
  for (unsigned int i = 0 ; i < N_baryon_type ; i++) e_trunc_tabs(i).allocate (0.5 , nmax_small , lmax_small);
  
  for (unsigned int s = 0 ; s < N_nlj_baryon ; s++) 
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(s);

      const enum particle_type particle = shell_qn.get_particle ();
      
      const unsigned int particle_index = charge_baryon_index_determine (particle);
      
      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();

      const double j = shell_qn.get_j ();

      const int e_trunc = shell_qn.get_e_trunc ();

      class nlj_table<int> &e_trunc_tab = e_trunc_tabs(particle_index);
  
      e_trunc_tab(n , l , j) = e_trunc;
    }
  
  for (unsigned int s_HF = 0 ; s_HF < N_nlj_baryon_HF ; s_HF++) 
    {
      const class nlj_struct &HF_shell_qn = HF_shells_quantum_numbers(s_HF);
      
      const enum particle_type particle_HF = HF_shell_qn.get_particle ();

      const int strangeness_HF = particle_strangeness_determine (particle_HF);

      if (strangeness_HF != 0) continue;
      
      const int n_HF = HF_shell_qn.get_n ();
      const int l_HF = HF_shell_qn.get_l ();

      const double j_HF = HF_shell_qn.get_j ();

      for (unsigned int s = 0 ; s < N_nlj_baryon ; s++) 
	{
	  class nlj_struct &shell_qn = shells_quantum_numbers(s);

	  const enum particle_type particle = shell_qn.get_particle ();
      
	  const unsigned int particle_index = charge_baryon_index_determine (particle);
      
	  const class nlj_table<int> &e_trunc_tab = e_trunc_tabs(particle_index);
      
	  const int n = shell_qn.get_n ();
	  const int l = shell_qn.get_l ();

	  const double j = shell_qn.get_j ();

	  if (same_nlj_particle (particle_HF , n_HF , l_HF , j_HF , particle , n , l , j))
	    {
	      const int e_trunc = e_trunc_tab(n , l , j);

	      shell_qn.initialize (
				   HF_shell_qn.get_S_matrix_pole () ,
				   HF_shell_qn.get_core_state () ,
				   HF_shell_qn.get_frozen_state () ,
				   HF_shell_qn.get_hole_state () ,
				   HF_shell_qn.get_OCM_valence_state () ,
				   HF_shell_qn.get_is_it_HO () ,
				   HF_shell_qn.get_is_it_for_HF_gs () ,
				   HF_shell_qn.get_is_it_natural_orbital () ,
				   HF_shell_qn.get_particle () ,
				   e_trunc ,
				   HF_shell_qn.get_n () ,
				   HF_shell_qn.get_l () ,
				   HF_shell_qn.get_j () ,
				   HF_shell_qn.get_segment () ,
				   HF_shell_qn.get_k () ,
				   HF_shell_qn.get_w () ,
				   HF_shell_qn.get_C0 () ,
				   HF_shell_qn.get_Cplus () ,
				   HF_shell_qn.get_k_plus () ,
				   HF_shell_qn.get_C0_plus () ,
				   HF_shell_qn.get_k_minus () ,
				   HF_shell_qn.get_C0_minus ());
	    }
	}
    }
  
  for (int n = 0 ; n <= nmax_small ; n++)
    for (int l = 0 ; l <= lmax_small ; l++)
      for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	  {
	    Ueq_finite_range_tab_uniform(n , l , j , i) = HF_Ueq_finite_range_averaged_tab_uniform(n , l , j , i);
	    
	    source_tab_uniform(n , l , j , i) = HF_source_averaged_tab_uniform(n , l , j , i);
	  }
          
  for (int l = 0 ; l <= lmax_small ; l++)
    for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	const class matrix<complex<double> > &U_finite_range_HF_HO_basis_HO_expansion_part_lj_copy = U_finite_range_HF_HO_basis_HO_expansion_part_copy(l , j);
	
	class matrix<complex<double> > &U_finite_range_HF_HO_basis_HO_expansion_part_lj = U_finite_range_HF_HO_basis_HO_expansion_part(l , j);
	
	U_finite_range_HF_HO_basis_HO_expansion_part_lj = U_finite_range_HF_HO_basis_HO_expansion_part_lj_copy;	    
      }
  
  if (nucleonic_particle == PROTON)
    { 
      const class nlj_table<complex<double> > &HF_Ueq_finite_range_plus_averaged_tab_uniform  = HF_data.get_Ueq_finite_range_plus_averaged_tab_uniform ();
      const class nlj_table<complex<double> > &HF_Ueq_finite_range_minus_averaged_tab_uniform = HF_data.get_Ueq_finite_range_minus_averaged_tab_uniform ();
      
      const class nlj_table<complex<double> > &HF_source_plus_averaged_tab_uniform  = HF_data.get_source_plus_averaged_tab_uniform ();
      const class nlj_table<complex<double> > &HF_source_minus_averaged_tab_uniform = HF_data.get_source_minus_averaged_tab_uniform ();
	  
      for (int n = 0 ; n <= nmax_small ; n++)
	for (int l = 0 ; l <= lmax_small ; l++)
	  for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	    for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	      {
		Ueq_finite_range_plus_tab_uniform (n , l , j , i) = HF_Ueq_finite_range_plus_averaged_tab_uniform (n , l , j , i);
		Ueq_finite_range_minus_tab_uniform(n , l , j , i) = HF_Ueq_finite_range_minus_averaged_tab_uniform(n , l , j , i);

		source_plus_tab_uniform (n , l , j , i) = HF_source_plus_averaged_tab_uniform (n , l , j , i);
		source_minus_tab_uniform(n , l , j , i) = HF_source_minus_averaged_tab_uniform(n , l , j , i);
	      }
    }
}




// Constants and arrays calculated in HF_data or found in input_data, inter_data or another class baryons_data are copied here to constants and arrays after allocation
// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

void baryons_data::data_MSDHF_one_configuration_one_body_alloc_fill (
								     const class input_data_str &input_data , 
								     const class interaction_class &inter_data ,
								     const class baryons_data &data ,  
								     const class HF_nucleons_data &HF_data)
{
  if (is_it_filled ()) error_message_print_abort ("baryons_data cannot be allocated twice in baryons_data::data_MSDHF_one_configuration_one_body_alloc_fill");

  is_it_M_scheme = data.is_it_M_scheme;
  
  nucleonic_particle = data.nucleonic_particle;
    
  if ((nucleonic_particle != PROTON) && (nucleonic_particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in baryons_data::data_MSDHF_one_configuration_one_body_alloc_fill");

  hypernucleus_strangeness = data.hypernucleus_strangeness;
  
  n_spec_max = data.n_spec_max;
  
  n_scat_max = 0;
  
  n_holes_max = data.n_holes_max;
  
  n_holes_max_pole_approximation = data.n_holes_max_pole_approximation;
  
  A = data.A_basis;
  
  A_basis = data.A_basis;
  
  A_core = data.A_core;
  Z_core = data.Z_core;
  
  Z = data.Z;
  N = data.N;
  
  hole_states_number = data.hole_states_number;

  N_nucleons = data.N_nucleons;
  
  N_valence_nucleons = data.N_valence_nucleons_basis;
    
  N_valence_baryons = data.N_valence_nucleons_basis;
  
  N_valence_baryons_1h = (N_valence_baryons >= 1) ? (N_valence_baryons - 1) : (NO_VALENCE_NUCLEONS);
  N_valence_baryons_2h = (N_valence_baryons >= 2) ? (N_valence_baryons - 2) : (NO_VALENCE_NUCLEONS);
 
  N_valence_nucleons_basis = data.N_valence_nucleons_basis;
  
  nucleus_mass = data.nucleus_mass;
  
  nucleus_mass_basis = data.nucleus_mass_basis;
  
  total_nucleus_mass = data.total_nucleus_mass;
  
  ZY_charge_pos = data.ZY_charge_pos;
  ZY_charge_neg = data.ZY_charge_neg;
  
  ZY_charge_basis_potential_pos = data.ZY_charge_basis_potential_pos;
  ZY_charge_basis_potential_neg = data.ZY_charge_basis_potential_neg;
  
  N_nljm_baryon = data.N_nljm_res_baryon;

  N_nlj_baryon = data.N_nlj_res_baryon;

  N_nljm_res_baryon = data.N_nljm_res_baryon;

  N_nlj_res_baryon = data.N_nlj_res_baryon;

  R_charge = data.R_charge;
  
  basis_potential = data.basis_potential;
  
  H_potential = data.H_potential;
  
  good_isospin_basis_potential = data.good_isospin_basis_potential;
  
  N_bef_R_GL = data.N_bef_R_GL;
  N_aft_R_GL = data.N_aft_R_GL;
  
  N_bef_R_uniform = data.N_bef_R_uniform;
  N_aft_R_uniform = data.N_aft_R_uniform;
  
  Nk_momentum_uniform = data.Nk_momentum_uniform;
  Nk_momentum_GL  = data.Nk_momentum_GL;
  
  R = data.R;

  step_bef_R_uniform = data.step_bef_R_uniform;

  R_real_max = data.R_real_max;

  step_momentum_uniform = data.step_momentum_uniform;
  
  kmax_momentum = data.kmax_momentum; 

  R_Fermi_momentum = data.R_Fermi_momentum; 
  
  BPmin_global = data.BPmin_global;
  BPmax_global = data.BPmax_global;
  
  Jmin_global = data.Jmin_global;
  Jmax_global = data.Jmax_global;
  
  is_it_OCM_HO_core = data.is_it_OCM_HO_core;
  
  R_cut_function = data.R_cut_function;
  d_cut_function = data.d_cut_function;
  
  baryon_types.allocate_fill (data.baryon_types);
  
  effective_masses_for_calc.allocate_fill (data.effective_masses_for_calc);
  
  V0_KKNN_tab.allocate_fill     (data.V0_KKNN_tab);
  rho_KKNN_tab.allocate_fill    (data.rho_KKNN_tab);
  Vls_KKNN_tab.allocate_fill    (data.Vls_KKNN_tab);
  rho_ls_KKNN_tab.allocate_fill (data.rho_ls_KKNN_tab);
  
  V0_KKNN_basis_core_potential_tab.allocate_fill     (data.V0_KKNN_basis_core_potential_tab);
  rho_KKNN_basis_core_potential_tab.allocate_fill    (data.rho_KKNN_basis_core_potential_tab);
  Vls_KKNN_basis_core_potential_tab.allocate_fill    (data.Vls_KKNN_basis_core_potential_tab);
  rho_ls_KKNN_basis_core_potential_tab.allocate_fill (data.rho_ls_KKNN_basis_core_potential_tab);
  
  d_core_potential_tab.allocate_fill   (data.d_basis_core_potential_tab);
  R0_core_potential_tab.allocate_fill  (data.R0_basis_core_potential_tab);
  Vo_core_potential_tab.allocate_fill  (data.Vo_basis_core_potential_tab);
  Vso_core_potential_tab.allocate_fill (data.Vso_basis_core_potential_tab);

  d_basis_core_potential_tab.allocate_fill   (data.d_basis_core_potential_tab);
  R0_basis_core_potential_tab.allocate_fill  (data.R0_basis_core_potential_tab);
  Vo_basis_core_potential_tab.allocate_fill  (data.Vo_basis_core_potential_tab);
  Vso_basis_core_potential_tab.allocate_fill (data.Vso_basis_core_potential_tab);

  d_basis_tab.allocate_fill   (data.d_basis_tab);
  R0_basis_tab.allocate_fill  (data.R0_basis_tab);
  Vo_basis_tab.allocate_fill  (data.Vo_basis_tab);
  Vso_basis_tab.allocate_fill (data.Vso_basis_tab);

  b_partial_waves_tab.allocate_fill (data.b_partial_waves_tab);

  basis_PSI_quantum_numbers_tab.allocate_fill (data.basis_PSI_quantum_numbers_tab);

  basis_potential_partial_waves_tab.allocate_fill (data.basis_potential_partial_waves_tab);

  if (N_valence_baryons == 0) return;
  
  const class array<int> &nmax_HO_lab_tab = inter_data.get_nmax_HO_lab_tab ();

  const class array<class spherical_state> &HF_shells_res = HF_data.get_shells_res ();

  shells.allocate (N_nlj_res_baryon);

  nmax = 0;
  lmax = 0;
  jmax = 0;

  m_max = 0;

  for (unsigned int s = 0 ; s < N_nlj_res_baryon ; s++)    
    {
      const class spherical_state &HF_shell_res = HF_shells_res(s);

      if (HF_shell_res.is_it_filled ())
	{
	  const int n = HF_shell_res.get_n ();
	  const int l = HF_shell_res.get_l ();

	  const double j = HF_shell_res.get_j ();

	  nmax = max (nmax , n);
	  lmax = max (lmax , l);
	  jmax = max (jmax , j);

	  m_max = max (m_max , j);

	  shells(s).allocate_fill (HF_shell_res);
	}
    }

  m_min = -m_max;

  m_max_minus_half = make_int (m_max - 0.5);
  
  two_m_max = make_int (2.0*m_max);
  
  four_m_max = make_int (4.0*m_max);

  m_max_minus_m_min = make_int (m_max - m_min);

  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const int nmax_plus_one = nmax + 1;

  shells_quantum_numbers.allocate (N_nlj_res_baryon);
			      
  const class array<class nlj_struct> &HF_shells_res_qn = HF_data.get_shells_quantum_numbers_res ();
			      
  for (unsigned int s = 0 ; s < N_nlj_res_baryon ; s++) shells_quantum_numbers(s) = HF_shells_res_qn(s); 
			      
  const int lmax_for_interaction = inter_data.get_lmax_for_interaction ();
			      
  if (is_it_SGI_MSGI) OBMEs_HF_SGI_MSGI.allocate (0.5 , lmax , nmax_plus_one , nmax_plus_one);
      
  U_finite_range_HF_HO_basis_HO_expansion_part.allocate (0.5 , lmax);
  
  for (int l = 0 ; l <= lmax ; l++)
    {
      const int nmax_HO_l = (l <= lmax_for_interaction) ? (nmax_HO_lab_tab(l)) : (0);
      
      const int nmax_HO_l_plus_one = nmax_HO_l + 1;
      
      for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)  U_finite_range_HF_HO_basis_HO_expansion_part(l , j).allocate (nmax_HO_l_plus_one);
    }
      
  Ueq_finite_range_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);

  source_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);
	
  if (nucleonic_particle == PROTON)
    {      
      Ueq_finite_range_plus_tab_uniform.allocate  (0.5 , nmax , lmax , N_bef_R_uniform);
      Ueq_finite_range_minus_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);
      
      source_plus_tab_uniform.allocate  (0.5 , nmax , lmax , N_bef_R_uniform);
      source_minus_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);
    }

  dimensions_1p1h_2p2h_space_BP_S_iM_fixed_max_calc_print (false);

  HF_potentials_quantum_numbers_OBMEs_write (TBME_inter , HF_data);

  fill_nljm_nlj_one_body_indices_baryons_alloc_calc ();

  all_HO_GHF_overlaps_alloc_calc (input_data);
  
  E_min_hw = E_min_hw_pp_nn (N_valence_baryons , shells_quantum_numbers);
    
  E_max_hw = E_max_hw_pole_approximation = E_min_hw + 1;

  effective_charges.allocate_fill (data.get_effective_charges ());
  
  are_there_basis_natural_orbitals_tab.allocate_fill (data.get_are_there_basis_natural_orbitals_tab ());

  are_there_new_natural_orbitals_tab.allocate_fill (data.get_are_there_new_natural_orbitals_tab ());
}






// Initialization and/or reallocation and reinitialization of given data to fixed values
// -------------------------------------------------------------------------------------

void baryons_data::set_BP_iC_one_configuration (const unsigned int BP , const unsigned int iC)
{
  BP_one_configuration = BP;
  iC_one_configuration = iC;
}

void baryons_data::is_it_OCM_HO_core_determine_test ()
{
  is_it_OCM_HO_core = true;

  for (unsigned int s = 0 ; s < N_nlj_baryon ; s++) 
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(s);

      const bool core_state = shell_qn.get_core_state ();

      const bool is_it_HO = shell_qn.get_is_it_HO ();

      if (core_state && !is_it_HO) is_it_OCM_HO_core = false;

      if (!is_it_OCM_HO_core && core_state && is_it_HO)
	error_message_print_abort ("All " + make_string<enum particle_type> (nucleonic_particle) + " core states must be HO, or none of them can be.");
    }
}

void baryons_data::is_it_OCM_HO_core_impose_pp_nn (
						   const class input_data_str &input_data ,
						   const class baryons_data &other_data)
{
  const enum space_type basis_space = input_data.get_basis_space ();

  if (((basis_space == PROT_Y_ONLY) && (nucleonic_particle == NEUTRON)) || ((basis_space == NEUT_Y_ONLY) && (nucleonic_particle == PROTON)))
    is_it_OCM_HO_core = other_data.is_it_OCM_HO_core;
}

void baryons_data::set_N_nlj_baryon_N_nlj_res_baryon_shells_quantum_numbers_realloc_fill (
											  const unsigned int N_nlj_res_baryon_c ,
											  const unsigned int N_nlj_baryon_c ,
											  const class array<class nlj_struct> &shells_quantum_numbers_c)
{
  N_nlj_res_baryon = N_nlj_res_baryon_c;

  N_nlj_baryon = N_nlj_baryon_c;

  shells_quantum_numbers.deallocate ();
  
  shells_quantum_numbers.allocate_fill (shells_quantum_numbers_c);
}






// Initialization to fixed or simple values of boolean and indices arrays associated to configurations and/or Slater determinants
// ------------------------------------------------------------------------------------------------------------------------------

void baryons_data::inSD_in_space_tab_Jpm_init (const bool init_bool)
{
  is_inSD_in_space_tab_Jpm = init_bool;
}

void baryons_data::configuration_SD_in_in_space_BPin_Sin_Nspec_in_iMin_tables_init (const bool init_bool)
{
  BPin_Sin_Nspec_in_for_one_jump_tab = init_bool;
  
  BPin_Sin_Nspec_in_iMin_for_one_jump_tab = init_bool;

  is_configuration_in_in_space_tabs[0] = init_bool;
  is_configuration_in_in_space_tabs[1] = init_bool;
  
  is_inSD_in_space_tabs[0] = init_bool;
  is_inSD_in_space_tabs[1] = init_bool;
}

void baryons_data::configuration_SD_in_in_space_iC_min_max_tables_init (
									 const unsigned int occupied_squares_index ,
									 const bool init_bool)
{  
  const int strangeness_max = hypernucleus_strangeness;
  
  class array<unsigned int> &iC_in_min_tab_squares = iC_in_min_tab[occupied_squares_index];
  class array<unsigned int> &iC_in_max_tab_squares = iC_in_max_tab[occupied_squares_index];
      
  is_configuration_in_in_space_tabs[occupied_squares_index] = init_bool;
  
  is_inSD_in_space_tabs[occupied_squares_index] = init_bool;

  iC_in_min_tab_squares = dimension_configuration_max;
  
  iC_in_max_tab_squares = 0;
      
  if (init_bool)
    {  
      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
	for (int S = 0 ; S <= strangeness_max ; S++)
	  for (int n_spec = 0 ; n_spec <= n_spec_max ; n_spec++)
	    for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
	      {
		const unsigned int dimension_C = dimensions_configuration_set(BP , S , n_spec , n_scat);

		if (dimension_C > 0)
		  {
		    iC_in_min_tab_squares(BP , S , n_spec , n_scat) = 0;
		  
		    iC_in_max_tab_squares(BP , S , n_spec , n_scat) = dimension_C - 1;
		  }
	      }
    }
}

void baryons_data::configuration_SD_inter_to_include_tables_init (const bool init_bool)
{
  is_it_configuration_inter_to_include_tab = init_bool;
  
  is_it_SD_inter_to_include_tab = init_bool;
}


void baryons_data::configuration_SD_out_in_space_BPout_Sout_Nspec_out_iMout_tables_init (const bool init_bool)
{
  BPout_Sout_Nspec_out_for_one_jump_tab = init_bool;
  
  BPout_Sout_Nspec_out_iMout_for_one_jump_tab = init_bool;

  is_configuration_out_in_space_tab = init_bool;
  
  is_outSD_in_space_tab = init_bool;
}

void baryons_data::configuration_SD_out_in_space_iC_min_max_tables_init (const bool init_bool)
{
  const int strangeness_max = hypernucleus_strangeness;
  
  is_configuration_out_in_space_tab = init_bool;
  
  is_outSD_in_space_tab = init_bool;
  
  iC_out_min_tab = dimension_configuration_max;
  
  iC_out_max_tab = 0;
  
  if (init_bool)
    {
      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
	for (int S = 0 ; S <= strangeness_max ; S++)
	  for (int n_spec = 0 ; n_spec <= n_spec_max ; n_spec++)
	    for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
	      {
		const unsigned int dimension_C = dimensions_configuration_set(BP , S , n_spec , n_scat);

		if (dimension_C > 0)
		  {
		    iC_out_min_tab(BP , S , n_spec , n_scat) = 0;
		  
		    iC_out_max_tab(BP , S , n_spec , n_scat) = dimension_C - 1;
		  }
	      }
    }
}













// One checks whether basis and core potentials are the same or not
// ----------------------------------------------------------------

bool are_core_basis_potentials_equal (
				      const int l ,
				      const class baryons_data &data)
{
  const bool is_it_OCM_HO_core = data.get_is_it_OCM_HO_core ();

  if (is_it_OCM_HO_core) return false;

  const class array<enum particle_type> &baryon_types = data.get_baryon_types ();
  
  const unsigned int N_baryon_type = baryon_types.dimension (0);
  
  for (unsigned int i = 0 ; i < N_baryon_type ; i++)
    {
      const enum particle_type particle = baryon_types(i);

      if (particle == NO_PARTICLE) continue;
      
      const unsigned int particle_index = charge_baryon_index_determine (particle);

      const class array<double> &d_tab   = data.get_d_core_potential_tab   ();
      const class array<double> &R0_tab  = data.get_R0_core_potential_tab  ();
      const class array<double> &Vo_tab  = data.get_Vo_core_potential_tab  ();
      const class array<double> &Vso_tab = data.get_Vso_core_potential_tab ();

      const class array<double> &d_basis_tab   = data.get_d_basis_tab   ();
      const class array<double> &R0_basis_tab  = data.get_R0_basis_tab  ();
      const class array<double> &Vo_basis_tab  = data.get_Vo_basis_tab  ();
      const class array<double> &Vso_basis_tab = data.get_Vso_basis_tab ();

      const double d   = d_tab   (particle_index , l);
      const double R0  = R0_tab  (particle_index , l);
      const double Vo  = Vo_tab  (particle_index , l);
      const double Vso = Vso_tab (particle_index , l);

      const double d_basis   = d_basis_tab   (particle_index , l);
      const double R0_basis  = R0_basis_tab  (particle_index , l);
      const double Vo_basis  = Vo_basis_tab  (particle_index , l);
      const double Vso_basis = Vso_basis_tab (particle_index , l);

      if (abs (d   -   d_basis) > precision) return false;
      if (abs (R0  -  R0_basis) > precision) return false;
      if (abs (Vo  -  Vo_basis) > precision) return false;
      if (abs (Vso - Vso_basis) > precision) return false;
    }

  return true;  
}






// Constants and arrays of proton and/or neutron types allocated and filled here, as well as the HO character or not of core shells with COSM
// ------------------------------------------------------------------------------------------------------------------------------------------

void baryons_data_initialization (
				   const bool is_it_M_scheme ,
				   const class input_data_str &input_data ,
				   class baryons_data &prot_Y_data ,
				   class baryons_data &neut_Y_data)
{
  prot_Y_data.initialize_constants (is_it_M_scheme , PROTON  , input_data);
  neut_Y_data.initialize_constants (is_it_M_scheme , NEUTRON , input_data);
  
  prot_Y_data.alloc_fill_one_body_data_tables_E_min_max_hw (input_data);
  neut_Y_data.alloc_fill_one_body_data_tables_E_min_max_hw (input_data);
  
  is_it_OCM_HO_core_determine (input_data , prot_Y_data , neut_Y_data);
}



// Constants and arrays of two-body systems defined with relative coordinates allocated and filled here
// ----------------------------------------------------------------------------------------------------

void relative_data_initialization (
				   const class input_data_str &input_data ,
				   class baryons_data &relative_data)
{
  const enum particle_type relative_cluster = input_data.get_relative_cluster ();

  if (!is_it_two_nucleon_ST_cluster_determine (relative_cluster)) error_message_print_abort ("Two-nucleon ST clusters only in relative_data_initialization");

  relative_data.initialize_constants (false , relative_cluster , input_data);
  
  relative_data.alloc_fill_one_body_data_tables_E_min_max_hw (input_data);
}



double used_memory_calc (const class baryons_data &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.baryon_types)
    + used_memory_calc (T.effective_masses_for_calc)  
    + used_memory_calc (T.basis_potential_partial_waves_tab)  
    + used_memory_calc (T.V0_KKNN_tab)
    + used_memory_calc (T.rho_KKNN_tab)
    + used_memory_calc (T.Vls_KKNN_tab)
    + used_memory_calc (T.rho_ls_KKNN_tab)
    + used_memory_calc (T.V0_KKNN_basis_core_potential_tab)
    + used_memory_calc (T.rho_KKNN_basis_core_potential_tab)
    + used_memory_calc (T.Vls_KKNN_basis_core_potential_tab)
    + used_memory_calc (T.rho_ls_KKNN_basis_core_potential_tab)  
    + used_memory_calc (T.TRS_nljm_indices)    
    + used_memory_calc (T.dimensions_configuration_set)
    + used_memory_calc (T.dimensions_configuration_set_1h)
    + used_memory_calc (T.dimensions_configuration_set_2h)  
    + used_memory_calc (T.sum_dimensions_configuration_set)
    + used_memory_calc (T.sum_dimensions_configuration_set_1h)
    + used_memory_calc (T.sum_dimensions_configuration_set_2h)
    + used_memory_calc (T.configuration_set)
    + used_memory_calc (T.configuration_set_1h)
    + used_memory_calc (T.configuration_set_2h)  
    + used_memory_calc (T.dimensions_SD_set)
    + used_memory_calc (T.dimensions_SD_set_1h)
    + used_memory_calc (T.dimensions_SD_set_2h)  
    + used_memory_calc (T.sum_dimensions_SD_set)
    + used_memory_calc (T.sum_dimensions_SD_set_1h)
    + used_memory_calc (T.sum_dimensions_SD_set_2h)
    + used_memory_calc (T.SD_set)
    + used_memory_calc (T.SD_set_1h)
    + used_memory_calc (T.SD_set_2h)
    + used_memory_calc (T.E_hw_table)
    + used_memory_calc (T.n_holes_table)
    + used_memory_calc (T.OBMEs_CM_set_HO_expansion)
    + used_memory_calc (T.OBMEs_CM_set_R_cut)  
    + used_memory_calc (T.reduced_grad_HO_expansion_set)
    + used_memory_calc (T.reduced_r_HO_expansion_set)
    + used_memory_calc (T.reduced_r_HO_expansion_rms_radius_different_particles_set)  
    + used_memory_calc (T.reduced_grad_R_cut_set)
    + used_memory_calc (T.reduced_r_R_cut_set)
    + used_memory_calc (T.reduced_r_R_cut_rms_radius_different_particles_set)    
    + used_memory_calc (T.OBMEs_multipole_square_HO_expansion)  
    + used_memory_calc (T.OBMEs_multipole_reduced_HO_expansion)  
    + used_memory_calc (T.OBMEs_multipole_square_R_cut)  
    + used_memory_calc (T.OBMEs_multipole_reduced_R_cut)  
    + used_memory_calc (T.OBMEs_inter_set)  
    + used_memory_calc (T.nmax_lj_tabs)    
    + used_memory_calc (T.nmin_lj_valence_tabs)
    + used_memory_calc (T.shells_indices_tab)    
    + used_memory_calc (T.is_it_valence_shell_tabs)
    + used_memory_calc (T.one_body_indices)    
    + used_memory_calc (T.shells)
    + used_memory_calc (T.shells_plus)
    + used_memory_calc (T.shells_minus)
    + used_memory_calc (T.phi_table)
    + used_memory_calc (T.Ueq_finite_range_tab_uniform)
    + used_memory_calc (T.Ueq_finite_range_plus_tab_uniform)
    + used_memory_calc (T.Ueq_finite_range_minus_tab_uniform)  
    + used_memory_calc (T.source_tab_uniform)
    + used_memory_calc (T.source_plus_tab_uniform)
    + used_memory_calc (T.source_minus_tab_uniform)  
    + used_memory_calc (T.OBMEs_HF_SGI_MSGI)
    + used_memory_calc (T.h_basis_tab)
    + used_memory_calc (T.TBMEs)
    + used_memory_calc (T.shells_quantum_numbers)  
    + used_memory_calc (T.SD_TRS_indices)
    + used_memory_calc (T.SD_TRS_indices_1h)
    + used_memory_calc (T.SD_TRS_indices_2h)  
    + used_memory_calc (T.SD_TRS_reordering_bin_phases)
    + used_memory_calc (T.SD_TRS_reordering_bin_phases_1h)
    + used_memory_calc (T.SD_TRS_reordering_bin_phases_2h)  
    + used_memory_calc (T.SD_TRS_bin_phases)
    + used_memory_calc (T.SD_TRS_bin_phases_1h)
    + used_memory_calc (T.SD_TRS_bin_phases_2h)  
    + used_memory_calc (T.dimensions_configuration_one_jump_table_in_to_out)
    + used_memory_calc (T.dimensions_configuration_one_jump_table_out_to_in)  
    + used_memory_calc (T.configuration_one_jump_table_in_to_out)
    + used_memory_calc (T.configuration_one_jump_table_out_to_in)    
    + used_memory_calc (T.dimensions_SD_one_jump_table_in_to_out)
    + used_memory_calc (T.dimensions_SD_one_jump_table_out_to_in)  
    + used_memory_calc (T.dimensions_SD_one_jump_table_Jpm_in_to_out)
    + used_memory_calc (T.dimensions_SD_one_jump_table_Jpm_out_to_in)  
    + used_memory_calc (T.SD_one_jump_table_in_to_out)
    + used_memory_calc (T.SD_one_jump_table_out_to_in)  
    + used_memory_calc (T.SD_one_jump_table_Jpm_in_to_out)
    + used_memory_calc (T.SD_one_jump_table_Jpm_out_to_in)  
    + used_memory_calc (T.are_configurations_inter_occupied_in_space_1ph_tables[0])
    + used_memory_calc (T.are_configurations_inter_occupied_in_space_1ph_tables[1])
    + used_memory_calc (T.are_configurations_inter_occupied_in_space_2ph_tables[0])  
    + used_memory_calc (T.are_configurations_inter_occupied_in_space_2ph_tables[1])
    + used_memory_calc (T.dimensions_configuration_1p_tables[0])
    + used_memory_calc (T.dimensions_configuration_1p_tables[1])
    + used_memory_calc (T.dimensions_configuration_1h_tables[0])
    + used_memory_calc (T.dimensions_configuration_1h_tables[1])  
    + used_memory_calc (T.dimensions_configuration_2p_tables[0])
    + used_memory_calc (T.dimensions_configuration_2p_tables[1])
    + used_memory_calc (T.dimensions_configuration_2h_tables[0])
    + used_memory_calc (T.dimensions_configuration_2h_tables[1])  
    + used_memory_calc (T.configuration_1p_tables[0])
    + used_memory_calc (T.configuration_1p_tables[1])
    + used_memory_calc (T.configuration_1h_tables[0]) 
    + used_memory_calc (T.configuration_1h_tables[1])  
    + used_memory_calc (T.configuration_2p_tables[0])
    + used_memory_calc (T.configuration_2p_tables[1])
    + used_memory_calc (T.configuration_2h_tables[0])
    + used_memory_calc (T.configuration_2h_tables[1])
    + used_memory_calc (T.dimensions_SD_1p_tables[0])
    + used_memory_calc (T.dimensions_SD_1p_tables[1])
    + used_memory_calc (T.dimensions_SD_1h_tables[0])
    + used_memory_calc (T.dimensions_SD_1h_tables[1])  
    + used_memory_calc (T.dimensions_SD_2p_tables[0])
    + used_memory_calc (T.dimensions_SD_2p_tables[1])  
    + used_memory_calc (T.dimensions_SD_2h_tables[0]) 
    + used_memory_calc (T.dimensions_SD_2h_tables[1])  
    + used_memory_calc (T.SD_1p_tables[0]) 
    + used_memory_calc (T.SD_1p_tables[1])
    + used_memory_calc (T.SD_1h_tables[0]) 
    + used_memory_calc (T.SD_1h_tables[1])  
    + used_memory_calc (T.SD_2p_tables[0]) 
    + used_memory_calc (T.SD_2p_tables[1])
    + used_memory_calc (T.SD_2h_tables[0])  
    + used_memory_calc (T.SD_2h_tables[1])     
    + used_memory_calc (T.U_finite_range_HF_HO_basis_HO_expansion_part)
    + used_memory_calc (T.HO_overlaps_basis)
    + used_memory_calc (T.HO_overlaps_basis_Fermi)
    + used_memory_calc (T.HO_overlaps)
    + used_memory_calc (T.HO_overlaps_Fermi)  
    + used_memory_calc (T.GHF_overlaps)  
    + used_memory_calc (T.d_core_potential_tab)   
    + used_memory_calc (T.R0_core_potential_tab)
    + used_memory_calc (T.Vo_core_potential_tab)
    + used_memory_calc (T.Vso_core_potential_tab)  
    + used_memory_calc (T.d_basis_core_potential_tab)
    + used_memory_calc (T.R0_basis_core_potential_tab)
    + used_memory_calc (T.Vo_basis_core_potential_tab)
    + used_memory_calc (T.Vso_basis_core_potential_tab)  
    + used_memory_calc (T.d_basis_tab)
    + used_memory_calc (T.R0_basis_tab)
    + used_memory_calc (T.Vo_basis_tab)
    + used_memory_calc (T.Vso_basis_tab)
    + used_memory_calc (T.b_partial_waves_tab)
    + used_memory_calc (T.basis_PSI_quantum_numbers_tab)
    + used_memory_calc (T.BPin_Sin_Nspec_in_for_one_jump_tab)  
    + used_memory_calc (T.BPout_Sout_Nspec_out_for_one_jump_tab)  
    + used_memory_calc (T.BPin_Sin_Nspec_in_iMin_for_one_jump_tab)  
    + used_memory_calc (T.BPout_Sout_Nspec_out_iMout_for_one_jump_tab)
    + used_memory_calc (T.iC_in_min_tab[0])
    + used_memory_calc (T.iC_in_min_tab[1])    
    + used_memory_calc (T.iC_in_max_tab[0])
    + used_memory_calc (T.iC_in_max_tab[1])  
    + used_memory_calc (T.iC_out_min_tab)
    + used_memory_calc (T.iC_out_max_tab)  
    + used_memory_calc (T.is_configuration_in_in_space_tabs[0])
    + used_memory_calc (T.is_configuration_in_in_space_tabs[1])
    + used_memory_calc (T.is_configuration_out_in_space_tab)  
    + used_memory_calc (T.is_inSD_in_space_tab_Jpm)  
    + used_memory_calc (T.is_inSD_in_space_tabs[0])
    + used_memory_calc (T.is_inSD_in_space_tabs[1]) 
    + used_memory_calc (T.is_outSD_in_space_tab)  
    + used_memory_calc (T.is_it_configuration_inter_to_include_tab)  
    + used_memory_calc (T.is_it_SD_inter_to_include_tab)
    + used_memory_calc (T.initial_to_nljm_ordered_states)  
    + used_memory_calc (T.nljm_ordered_to_initial_states)
    + used_memory_calc (T.dimensions_SD_HO_Berggren_overlaps_table)  
    + used_memory_calc (T.SD_HO_Berggren_overlaps_table)
    + used_memory_calc (T.scalar_density_matrices_tab)  
    + used_memory_calc (T.natural_orbitals_matrices_tab)  
    + used_memory_calc (T.ESPEs_Hamiltonian_matrices_tab)
    + used_memory_calc (T.ESPEs_Hamiltonian_orbitals_matrices_tab)  
    + used_memory_calc (T.natural_orbitals_reference_states)
    + used_memory_calc (T.SD_quantum_numbers_tab)
    + used_memory_calc (T.effective_charges)
    + used_memory_calc (T.are_there_basis_natural_orbitals_tab)
    + used_memory_calc (T.are_there_new_natural_orbitals_tab)
    - (sizeof (T.baryon_types)  
    + sizeof (T.effective_masses_for_calc)  
    + sizeof (T.basis_potential_partial_waves_tab)  
    + sizeof (T.V0_KKNN_tab)
    + sizeof (T.rho_KKNN_tab)
    + sizeof (T.Vls_KKNN_tab)
    + sizeof (T.rho_ls_KKNN_tab)
    + sizeof (T.V0_KKNN_basis_core_potential_tab)
    + sizeof (T.rho_KKNN_basis_core_potential_tab)
    + sizeof (T.Vls_KKNN_basis_core_potential_tab)
    + sizeof (T.rho_ls_KKNN_basis_core_potential_tab)  
    + sizeof (T.TRS_nljm_indices)    
    + sizeof (T.dimensions_configuration_set)
    + sizeof (T.dimensions_configuration_set_1h)
    + sizeof (T.dimensions_configuration_set_2h)  
    + sizeof (T.sum_dimensions_configuration_set)
    + sizeof (T.sum_dimensions_configuration_set_1h)
    + sizeof (T.sum_dimensions_configuration_set_2h)
    + sizeof (T.configuration_set)
    + sizeof (T.configuration_set_1h)
    + sizeof (T.configuration_set_2h)  
    + sizeof (T.dimensions_SD_set)
    + sizeof (T.dimensions_SD_set_1h)
    + sizeof (T.dimensions_SD_set_2h)  
    + sizeof (T.sum_dimensions_SD_set)
    + sizeof (T.sum_dimensions_SD_set_1h)
    + sizeof (T.sum_dimensions_SD_set_2h)
    + sizeof (T.SD_set)
    + sizeof (T.SD_set_1h)
    + sizeof (T.SD_set_2h)
    + sizeof (T.E_hw_table)
    + sizeof (T.n_holes_table)
    + sizeof (T.OBMEs_CM_set_HO_expansion)
    + sizeof (T.OBMEs_CM_set_R_cut)  
    + sizeof (T.reduced_grad_HO_expansion_set)
    + sizeof (T.reduced_r_HO_expansion_set)
    + sizeof (T.reduced_r_HO_expansion_rms_radius_different_particles_set)  
    + sizeof (T.reduced_grad_R_cut_set)
    + sizeof (T.reduced_r_R_cut_set)
    + sizeof (T.reduced_r_R_cut_rms_radius_different_particles_set)    
    + sizeof (T.OBMEs_multipole_square_HO_expansion)  
    + sizeof (T.OBMEs_multipole_reduced_HO_expansion)  
    + sizeof (T.OBMEs_multipole_square_R_cut)  
    + sizeof (T.OBMEs_multipole_reduced_R_cut)  
    + sizeof (T.OBMEs_inter_set)  
    + sizeof (T.nmax_lj_tabs)    
    + sizeof (T.nmin_lj_valence_tabs)
    + sizeof (T.shells_indices_tab)    
    + sizeof (T.is_it_valence_shell_tabs)
    + sizeof (T.one_body_indices)    
    + sizeof (T.shells)
    + sizeof (T.shells_plus)
    + sizeof (T.shells_minus)
    + sizeof (T.phi_table)
    + sizeof (T.Ueq_finite_range_tab_uniform)
    + sizeof (T.Ueq_finite_range_plus_tab_uniform)
    + sizeof (T.Ueq_finite_range_minus_tab_uniform)  
    + sizeof (T.source_tab_uniform)
    + sizeof (T.source_plus_tab_uniform)
    + sizeof (T.source_minus_tab_uniform)  
    + sizeof (T.OBMEs_HF_SGI_MSGI)
    + sizeof (T.h_basis_tab)
    + sizeof (T.TBMEs)
    + sizeof (T.shells_quantum_numbers)  
    + sizeof (T.SD_TRS_indices)
    + sizeof (T.SD_TRS_indices_1h)
    + sizeof (T.SD_TRS_indices_2h)  
    + sizeof (T.SD_TRS_reordering_bin_phases)
    + sizeof (T.SD_TRS_reordering_bin_phases_1h)
    + sizeof (T.SD_TRS_reordering_bin_phases_2h)  
    + sizeof (T.SD_TRS_bin_phases)
    + sizeof (T.SD_TRS_bin_phases_1h)
    + sizeof (T.SD_TRS_bin_phases_2h)  
    + sizeof (T.dimensions_configuration_one_jump_table_in_to_out)
    + sizeof (T.dimensions_configuration_one_jump_table_out_to_in)  
    + sizeof (T.configuration_one_jump_table_in_to_out)
    + sizeof (T.configuration_one_jump_table_out_to_in)    
    + sizeof (T.dimensions_SD_one_jump_table_in_to_out)
    + sizeof (T.dimensions_SD_one_jump_table_out_to_in)  
    + sizeof (T.dimensions_SD_one_jump_table_Jpm_in_to_out)
    + sizeof (T.dimensions_SD_one_jump_table_Jpm_out_to_in)  
    + sizeof (T.SD_one_jump_table_in_to_out)
    + sizeof (T.SD_one_jump_table_out_to_in)  
    + sizeof (T.SD_one_jump_table_Jpm_in_to_out)
    + sizeof (T.SD_one_jump_table_Jpm_out_to_in)  
    + sizeof (T.are_configurations_inter_occupied_in_space_1ph_tables[0])
    + sizeof (T.are_configurations_inter_occupied_in_space_1ph_tables[1])
    + sizeof (T.are_configurations_inter_occupied_in_space_2ph_tables[0])  
    + sizeof (T.are_configurations_inter_occupied_in_space_2ph_tables[1])
    + sizeof (T.dimensions_configuration_1p_tables[0])
    + sizeof (T.dimensions_configuration_1p_tables[1])
    + sizeof (T.dimensions_configuration_1h_tables[0])
    + sizeof (T.dimensions_configuration_1h_tables[1])  
    + sizeof (T.dimensions_configuration_2p_tables[0])
    + sizeof (T.dimensions_configuration_2p_tables[1])
    + sizeof (T.dimensions_configuration_2h_tables[0])
    + sizeof (T.dimensions_configuration_2h_tables[1])  
    + sizeof (T.configuration_1p_tables[0])
    + sizeof (T.configuration_1p_tables[1])
    + sizeof (T.configuration_1h_tables[0]) 
    + sizeof (T.configuration_1h_tables[1])  
    + sizeof (T.configuration_2p_tables[0])
    + sizeof (T.configuration_2p_tables[1])
    + sizeof (T.configuration_2h_tables[0])
    + sizeof (T.configuration_2h_tables[1])
    + sizeof (T.dimensions_SD_1p_tables[0])
    + sizeof (T.dimensions_SD_1p_tables[1])
    + sizeof (T.dimensions_SD_1h_tables[0])
    + sizeof (T.dimensions_SD_1h_tables[1])  
    + sizeof (T.dimensions_SD_2p_tables[0])
    + sizeof (T.dimensions_SD_2p_tables[1])  
    + sizeof (T.dimensions_SD_2h_tables[0]) 
    + sizeof (T.dimensions_SD_2h_tables[1])  
    + sizeof (T.SD_1p_tables[0]) 
    + sizeof (T.SD_1p_tables[1])
    + sizeof (T.SD_1h_tables[0]) 
    + sizeof (T.SD_1h_tables[1])  
    + sizeof (T.SD_2p_tables[0]) 
    + sizeof (T.SD_2p_tables[1])
    + sizeof (T.SD_2h_tables[0])  
    + sizeof (T.SD_2h_tables[1])     
    + sizeof (T.U_finite_range_HF_HO_basis_HO_expansion_part)
    + sizeof (T.HO_overlaps_basis)
    + sizeof (T.HO_overlaps_basis_Fermi)
    + sizeof (T.HO_overlaps)
    + sizeof (T.HO_overlaps_Fermi)  
    + sizeof (T.GHF_overlaps)  
    + sizeof (T.d_core_potential_tab)   
    + sizeof (T.R0_core_potential_tab)
    + sizeof (T.Vo_core_potential_tab)
    + sizeof (T.Vso_core_potential_tab)  
    + sizeof (T.d_basis_core_potential_tab)
    + sizeof (T.R0_basis_core_potential_tab)
    + sizeof (T.Vo_basis_core_potential_tab)
    + sizeof (T.Vso_basis_core_potential_tab)  
    + sizeof (T.d_basis_tab)
    + sizeof (T.R0_basis_tab)
    + sizeof (T.Vo_basis_tab)
    + sizeof (T.Vso_basis_tab)
    + sizeof (T.b_partial_waves_tab)
    + sizeof (T.basis_PSI_quantum_numbers_tab)
    + sizeof (T.BPin_Sin_Nspec_in_for_one_jump_tab)  
    + sizeof (T.BPout_Sout_Nspec_out_for_one_jump_tab)  
    + sizeof (T.BPin_Sin_Nspec_in_iMin_for_one_jump_tab)  
    + sizeof (T.BPout_Sout_Nspec_out_iMout_for_one_jump_tab)
    + sizeof (T.iC_in_min_tab[0])
    + sizeof (T.iC_in_min_tab[1])    
    + sizeof (T.iC_in_max_tab[0])
    + sizeof (T.iC_in_max_tab[1])  
    + sizeof (T.iC_out_min_tab)
    + sizeof (T.iC_out_max_tab)  
    + sizeof (T.is_configuration_in_in_space_tabs[0])
    + sizeof (T.is_configuration_in_in_space_tabs[1])
    + sizeof (T.is_configuration_out_in_space_tab)  
    + sizeof (T.is_inSD_in_space_tab_Jpm)  
    + sizeof (T.is_inSD_in_space_tabs[0])
    + sizeof (T.is_inSD_in_space_tabs[1]) 
    + sizeof (T.is_outSD_in_space_tab)  
    + sizeof (T.is_it_configuration_inter_to_include_tab)  
    + sizeof (T.is_it_SD_inter_to_include_tab)
    + sizeof (T.initial_to_nljm_ordered_states)  
    + sizeof (T.nljm_ordered_to_initial_states)
    + sizeof (T.dimensions_SD_HO_Berggren_overlaps_table)  
    + sizeof (T.SD_HO_Berggren_overlaps_table)
    + sizeof (T.scalar_density_matrices_tab)  
    + sizeof (T.natural_orbitals_matrices_tab)  
    + sizeof (T.ESPEs_Hamiltonian_matrices_tab)
    + sizeof (T.ESPEs_Hamiltonian_orbitals_matrices_tab)  
    + sizeof (T.natural_orbitals_reference_states)
    + sizeof (T.SD_quantum_numbers_tab)
    + sizeof (T.effective_charges)
    + sizeof (T.are_there_basis_natural_orbitals_tab)
       + sizeof (T.are_there_new_natural_orbitals_tab))/1000000.0;
  
  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;    
}
