#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Class pair_str
// --------------
// Class representing a pair of the form (left,right). It consists of only two integers and represent a coupled or uncoupled two-body state. 
// No boolean states whether it is coupled or uncoupled, as it is decided by the context of the routines where it is used.
// Basic operations are to print the two integers, to check if its ordered,
// and to compare it to other pairs, to see if it is larger, equal or smaller with respect to the lexicographic order (right comes first).
//
// From the the arrays of quantum numbers class array<class nlj_struct> for coupled pairs and class array<class nljm_struct> for uncoupled pairs,
// one can calculate their binary parity bp (see observables_basic_functions.cpp for definition), number of particles in the continuum n_scat, truncation energy E_hw,
// minimal and maximal possible total angular momentum Jmin and Jmax, and if they contain core states, core frozen or core hole states.
// One can also print the pair under the format "1p3/2 0d5/2" for a coupled pair or "1p3/2(-1/2) 0d5/2(3/2)" for an uncoupled pair.
//
// OUT_OF_RANGE is a large integer which can never occur in practice.
//
//
//
// Two non-immediate routines are is_it_in_new_space and reindexation_and_phase.
//
// In is_it_in_new_space, one assumes that one has read a vector of pairs from disk, whose one-body states can be different from the current one-body states of the run code.
// One considers in this example that what is called "new" comes from disk and what is called "old" come the current code.
//
// One checks in is_it_in_new_space if the considered pair belongs to the new space. All conditions must be verified otherwise false is returned.
// For this, one first checks if orbital angular quantum numbers and principal quantum numbers of the left and right shells are not larger than lmax or nmax of the new space.
// If it is not the case, one checks if the left and right shells are occupied in the list of shells. It could not be done before as the list of shells depends on l and n, which cannot be larger than lmax and nmax.
// 
// In reindexation_and_phase, the considered pair can have different indices in the old and new sets of one-body states, so that it might have to be reordered.
// The pair is considered to be coupled to J here.
// For this, one takes the pair with old indices and one converts them to new indices. If the pair is ordered, one just one puts the phase to 1. 
// If it is not ordered, one reverses the pair and one puts phase to (-1)^(j_left + j_right - J).

pair_str::pair_str () :
  left  (OUT_OF_RANGE) ,
  right (OUT_OF_RANGE)
{}

pair_str::pair_str (
		    const unsigned short int left_c ,
		    const unsigned short int right_c)
{
  initialize (left_c , right_c);
}

pair_str::pair_str (const class pair_str &X)
{
  initialize (X);
}

void pair_str::initialize (
			   const unsigned short int left_c ,
			   const unsigned short int right_c)
{
  left  = left_c;
  right = right_c;
}

void pair_str::initialize (const class pair_str &X)
{
  left  = X.left;
  right = X.right;
}

bool pair_str::are_there_core_states_determine  (
						 const class array<class nlj_struct> &shells_table_left , 
						 const class array<class nlj_struct> &shells_table_right) const
{
  const class nlj_struct &shell_left  = shells_table_left(left);
  const class nlj_struct &shell_right = shells_table_right(right);
  
  const bool core_state_left  = shell_left.get_core_state ();
  const bool core_state_right = shell_right.get_core_state ();
  
  const bool are_there_core_states = (core_state_left || core_state_right);

  return are_there_core_states;
}

bool pair_str::are_there_frozen_states_determine  (
						   const class array<class nlj_struct> &shells_table_left , 
						   const class array<class nlj_struct> &shells_table_right) const
{
  const class nlj_struct &shell_left  = shells_table_left(left);
  const class nlj_struct &shell_right = shells_table_right(right);
  
  const bool frozen_state_left  = shell_left.get_frozen_state ();
  const bool frozen_state_right = shell_right.get_frozen_state ();

  const bool are_there_frozen_states = (frozen_state_left || frozen_state_right);

  return are_there_frozen_states;
}

bool pair_str::are_there_hole_states_determine  (
						 const class array<class nlj_struct> &shells_table_left , 
						 const class array<class nlj_struct> &shells_table_right) const
{
  const class nlj_struct &shell_left  = shells_table_left(left);
  const class nlj_struct &shell_right = shells_table_right(right);
  
  const bool hole_state_left  = shell_left.get_hole_state ();
  const bool hole_state_right = shell_right.get_hole_state ();
  
  const bool are_there_hole_states = (hole_state_left || hole_state_right);

  return are_there_hole_states;
}

bool pair_str::only_hole_states_determine  (
					    const class array<class nlj_struct> &shells_table_left , 
					    const class array<class nlj_struct> &shells_table_right) const
{
  const class nlj_struct &shell_left  = shells_table_left(left);
  const class nlj_struct &shell_right = shells_table_right(right);
  
  const bool hole_state_left  = shell_left.get_hole_state ();
  const bool hole_state_right = shell_right.get_hole_state ();
  
  const bool only_hole_states = (hole_state_left && hole_state_right);

  return only_hole_states;
}

unsigned int pair_str::bp_determine (
				     const class array<class nljm_struct> &phi_table_left , 
				     const class array<class nljm_struct> &phi_table_right) const
{
  const class nljm_struct &phi_left  = phi_table_left(left);
  const class nljm_struct &phi_right = phi_table_right(right);
  
  const unsigned int bp_left  = phi_left.get_bp ();
  const unsigned int bp_right = phi_right.get_bp ();
  
  const unsigned int bp = binary_parity_product (bp_left , bp_right);

  return bp;
}

unsigned int pair_str::bp_determine (
				     const class array<class nlj_struct> &shells_table_left , 
				     const class array<class nlj_struct> &shells_table_right) const
{
  const class nlj_struct &shell_left  = shells_table_left(left);
  const class nlj_struct &shell_right = shells_table_right(right);
  
  const int l_left  = shell_left.get_l ();
  const int l_right = shell_right.get_l ();

  const unsigned int bp_left  = binary_parity_from_orbital_angular_momentum (l_left);
  const unsigned int bp_right = binary_parity_from_orbital_angular_momentum (l_right);
  
  const unsigned int bp = binary_parity_product (bp_left , bp_right);

  return bp;
}

int pair_str::im_determine (
			    const class array<class nljm_struct> &phi_table_left , 
			    const class array<class nljm_struct> &phi_table_right) const
{
  const class nljm_struct &phi_left  = phi_table_left(left);
  const class nljm_struct &phi_right = phi_table_right(right);
  
  const int im_left  = phi_left.get_im ();
  const int im_right = phi_right.get_im ();

  const int im = im_left + im_right;

  return im;
}

int pair_str::M_determine (
			   const class array<class nljm_struct> &phi_table_left , 
			   const class array<class nljm_struct> &phi_table_right) const
{
  const class nljm_struct &phi_left  = phi_table_left(left);
  const class nljm_struct &phi_right = phi_table_right(right);
  
  const double m_left  = phi_left.get_m ();
  const double m_right = phi_right.get_m ();

  const int M = make_int (m_left + m_right);

  return M;
}

int pair_str::n_scat_determine (
				const class array<class nlj_struct> &shells_table_left , 
				const class array<class nlj_struct> &shells_table_right) const
{
  const class nlj_struct &shell_left  = shells_table_left(left);
  const class nlj_struct &shell_right = shells_table_right(right);

  const bool S_matrix_pole_left  = shell_left.get_S_matrix_pole ();
  const bool S_matrix_pole_right = shell_right.get_S_matrix_pole ();
  
  const int n_scat_left  = (S_matrix_pole_left)  ? (0) : (1);
  const int n_scat_right = (S_matrix_pole_right) ? (0) : (1);
  
  const int n_scat = n_scat_left + n_scat_right;

  return n_scat;
}

int pair_str::n_scat_determine (
				const class array<class nljm_struct> &phi_table_left , 
				const class array<class nljm_struct> &phi_table_right) const
{
  const class nljm_struct &phi_left  = phi_table_left(left);
  const class nljm_struct &phi_right = phi_table_right(right);
  
  const bool S_matrix_pole_left  = phi_left.get_S_matrix_pole ();
  const bool S_matrix_pole_right = phi_right.get_S_matrix_pole ();

  const int n_scat_left  = (S_matrix_pole_left)  ? (0) : (1);
  const int n_scat_right = (S_matrix_pole_right) ? (0) : (1);
  
  const int n_scat = n_scat_left + n_scat_right;

  return n_scat;
}

int pair_str::E_hw_determine (
			      const class array<class nlj_struct> &shells_table_left , 
			      const class array<class nlj_struct> &shells_table_right) const
{
  const class nlj_struct &shell_left  = shells_table_left(left);
  const class nlj_struct &shell_right = shells_table_right(right);
  
  const int e_trunc_left  = shell_left.get_e_trunc ();
  const int e_trunc_right = shell_right.get_e_trunc ();
  
  const int E_hw = e_trunc_left + e_trunc_right;

  return E_hw;
}

int pair_str::Jmin_determine (
			      const class array<class nlj_struct> &shells_table_left , 
			      const class array<class nlj_struct> &shells_table_right) const
{
  const class nlj_struct &shell_left  = shells_table_left(left);
  const class nlj_struct &shell_right = shells_table_right(right);
  
  const int ij_left  = shell_left.get_ij ();
  const int ij_right = shell_right.get_ij ();
  
  const int Jmin = abs (ij_left - ij_right);

  return Jmin;
}

int pair_str::Jmax_determine (
			      const class array<class nlj_struct> &shells_table_left , 
			      const class array<class nlj_struct> &shells_table_right) const
{
  const class nlj_struct &shell_left  = shells_table_left(left);
  const class nlj_struct &shell_right = shells_table_right(right);
  
  const int ij_left  = shell_left.get_ij ();
  const int ij_right = shell_right.get_ij ();
  
  const int Jmax = ij_left + ij_right + 1;

  return Jmax;
}

class pair_str pair_str::swap () const
{
  return pair_str (right , left);
}


int pair_str::Jmin_determine (
			      const class array<class nljm_struct> &phi_table_left , 
			      const class array<class nljm_struct> &phi_table_right) const
{
  const class nljm_struct &phi_left  = phi_table_left(left);
  const class nljm_struct &phi_right = phi_table_right(right);
  
  const int ij_left  = phi_left.get_ij ();
  const int ij_right = phi_right.get_ij ();
  
  const int Jmin = abs (ij_left - ij_right);

  return Jmin;
}

int pair_str::Jmax_determine (
			      const class array<class nljm_struct> &phi_table_left , 
			      const class array<class nljm_struct> &phi_table_right) const
{
  const class nljm_struct &phi_left  = phi_table_left(left);
  const class nljm_struct &phi_right = phi_table_right(right);
  
  const int ij_left  = phi_left.get_ij ();
  const int ij_right = phi_right.get_ij ();
  
  const int Jmax = ij_left + ij_right + 1;

  return Jmax;
}


bool pair_str::is_it_in_new_space (
				   const class array<class nlj_struct> &old_shells_qn_left,
				   const class array<class nlj_struct> &old_shells_qn_right,
				   const class lj_table<int> &new_nmax_lj_tab_left ,
				   const class lj_table<int> &new_nmax_lj_tab_right ,
				   const class nlj_table<bool> &new_is_it_valence_shell_tab_left ,
				   const class nlj_table<bool> &new_is_it_valence_shell_tab_right) const
{
  const class nlj_struct &shell_left = old_shells_qn_left(left);
  
  const int new_lmax_left = new_nmax_lj_tab_left.get_lmax ();
  
  const int l_left = shell_left.get_l ();
  
  if (l_left > new_lmax_left) return false;

  const int n_left = shell_left.get_n ();

  const double j_left = shell_left.get_j ();
  
  if (n_left > new_nmax_lj_tab_left(l_left , j_left)) return false;

  if (!new_is_it_valence_shell_tab_left(n_left , l_left , j_left)) return false;
  
  const class nlj_struct &shell_right = old_shells_qn_right(right);
  
  const int new_lmax_right = new_nmax_lj_tab_right.get_lmax ();

  const int l_right = shell_right.get_l ();
  
  if (l_right > new_lmax_right) return false;

  const int n_right = shell_right.get_n ();

  const double j_right = shell_right.get_j ();
  
  if (n_right > new_nmax_lj_tab_right(l_right , j_right)) return false;

  if (!new_is_it_valence_shell_tab_right(n_right , l_right , j_right)) return false;

  return true;
}


void pair_str::reindexation_and_phase (
				       const enum space_type space , 
				       const class array<class nlj_struct> &old_shells_qn_left,
				       const class array<class nlj_struct> &old_shells_qn_right,
				       const class nlj_table<unsigned int> &new_shells_indices_left ,
				       const class nlj_table<unsigned int> &new_shells_indices_right ,
				       const int J ,
				       int &phase)
{
  const class nlj_struct &shell_left  = old_shells_qn_left(left);
  const class nlj_struct &shell_right = old_shells_qn_right(right);

  const int n_left = shell_left.get_n () , n_right = shell_right.get_n ();
  const int l_left = shell_left.get_l () , l_right = shell_right.get_l ();
  
  const double j_left  = shell_left.get_j ();
  const double j_right = shell_right.get_j ();

  const unsigned int new_left  = new_shells_indices_left(n_left   , l_left  , j_left);
  const unsigned int new_right = new_shells_indices_right(n_right , l_right , j_right);

  if ((space == PROTONS_NEUTRONS) || (new_left <= new_right))
    {
      left = new_left;
      
      right = new_right;

      phase = 1;
    }
  else
    {
      left = new_right;

      right = new_left;

      phase = minus_one_pow (j_left + j_right - J);
    }
}



bool pair_str::ordered () const
{
  return (left <= right);
}

const class pair_str & pair_str::operator= (const class pair_str &pair)
{
  left = pair.left;
  
  right = pair.right;

  return *this;
}

void pair_str::print (
		      const class array<class nljm_struct> &phi_table_left , 
		      const class array<class nljm_struct> &phi_table_right) const
{
  cout << phi_table_left(left) << "  " << phi_table_right(right) << endl;
}

void pair_str::print (
		      const class array<class nlj_struct> &shells_table_left , 
		      const class array<class nlj_struct> &shells_table_right) const
{
  cout << shells_table_left(left) << "  " << shells_table_right(right) << endl;
}



bool operator == (const class pair_str &a , const class pair_str &b) 
{
  return (a.get_left () == b.get_left ()) && (a.get_right () == b.get_right ());
}


bool operator != (const class pair_str &a , const class pair_str &b) 
{
  return (a.get_left () != b.get_left ()) || (a.get_right () != b.get_right ());
}



bool operator > (const class pair_str &a , const class pair_str &b) 
{
  return (a.get_right () > b.get_right ()) || ((a.get_right () == b.get_right ()) && (a.get_left () > b.get_left ()));
}


bool operator < (const class pair_str &a , const class pair_str &b) 
{
  return (a.get_right () < b.get_right ()) || ((a.get_right () == b.get_right ()) && (a.get_left () < b.get_left ()));
}




bool operator >= (const class pair_str &a , const class pair_str &b) 
{
  return (a.get_right () > b.get_right ()) || ((a.get_right () == b.get_right ()) && (a.get_left () >= b.get_left ()));
}

bool operator <= (const class pair_str &a , const class pair_str &b) 
{
  return (a.get_right () < b.get_right ()) || ((a.get_right () == b.get_right ()) && (a.get_left () <= b.get_left ()));
}




ostream & operator << (ostream &os , const class pair_str &pair)
{
  return os << pair.get_left () << " " << pair.get_right ();
}

istream & operator >>  (istream &is , class pair_str &pair)
{
  unsigned int left = 0 , right = 0;
  
  is >> left >> right;

  pair.initialize (left , right);

  return is;
}



double used_memory_calc (const class pair_str &T)
{
  return sizeof (T)/1000000.0;
}

