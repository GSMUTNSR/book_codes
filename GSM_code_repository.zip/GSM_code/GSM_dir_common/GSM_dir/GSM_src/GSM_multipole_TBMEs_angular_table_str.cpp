#include "../GSM_include/GSM_include_def_common.h"

using namespace Wigner_signs;


// TBME is two-body matrix element
// -------------------------------





// Class storing the Clebsch-Gordan coefficients needed to calculate the TBMEs of a many-body multipole operator
// -------------------------------------------------------------------------------------------------------------
//
// L is the multipole integer value.
//
// Coupled scheme
// --------------
// One has: < c d | Oi . Oj | a b > = (-1)^(ja + jd + J) . Wigner_6j (jc , jd , J , jb , ja , L) . < c || Oi || a > . < d || Oj || b >.
// One then stores the products of phases and Wigner signs entering coupled TBMEs.
// 
// Uncoupled scheme
// ----------------
// The TBMEs used in many-body multipole operators in M-scheme are of the form < c d | Oi . Oj | a b >, where Oi=f(ri) YL'(i) or f(ri) [YL(i) x si/li]^L'], Oj=f(rj) YL'(j) or f(rj) [YL(j) x sj/lj]^L'] and (a,b) and (c,d) are uncoupled two-body states.
// TBMEs are not antisymmetrized in this class. They will be antisymmetrized afterwards in the many-body multipole operator class.
//
// As one uses M-scheme and as the Oi . Oj operator is separable, it is convenient to decouple Oi . Oj to calculate < c d | Oi . Oj | a b >:
// < c d | Oi . Oj | a b > = \sum_(mu) (-1)^mu < c d | Oi_mu x Oj_-mu | a b > = \sum_(mu) (-1)^mu < c | Oi_mu | a > < d | Oj_-mu | b >
//                                      = (-1)^(ja + jb - ma - mb + mu)/(2L' + 1) <ja ma jc -mc |L' -mu> <jb mb jd -md |L' mu> < c || Oi || a > < d || Oj || b >.
// where mi,mj are fixed from mc = ma + mu and md = mb - mu, and the 1/(2L' + 1) factor comes from the 1/hat (L')^2 (L' is the rank of Oi and Oj) factor arising from the use of reduced matrix elements.
//
// Consequently, as < c || Oi || a >, < d || Oj || b > are independent of m projections, it is sufficient to store <j m j' -m' |L' -m''> Clebsch-Gordan coefficients divided by hat(L').
// The phase will be recalculated for each calculation of < c d | Oi . Oj | a b >.

multipole_TBMEs_angular_table_str::multipole_TBMEs_angular_table_str () : L (0) , J (0) , m_max_sum (0) {}


multipole_TBMEs_angular_table_str::multipole_TBMEs_angular_table_str (const int L_c , const double j_max , const int J_c) : L (0) , J (0) , m_max_sum (0)
{
  allocate_calc_coupled (L_c , j_max , J_c);
}



multipole_TBMEs_angular_table_str::multipole_TBMEs_angular_table_str (const int L_c , const double m_max) : L (0) , J (0) , m_max_sum (0)
{
  allocate_calc_uncoupled (L_c , m_max);
}


multipole_TBMEs_angular_table_str::multipole_TBMEs_angular_table_str (const multipole_TBMEs_angular_table_str &X) : L (0) , J (0) , m_max_sum (0)
{
  allocate_fill (X);
}



multipole_TBMEs_angular_table_str::~multipole_TBMEs_angular_table_str () {}




void multipole_TBMEs_angular_table_str::allocate_calc_coupled (const int L_c , const double j_max , const int J_c)
{
  if (coupled_TBMEs_angular_table.is_it_filled ()) error_message_print_abort ("CM_TBMEs_angular_table_str cannot be allocated twice in CM_TBMEs_angular_table_str::allocate_calc_coupled");

  L = L_c;
  
  J = J_c;
        
  const int j_number = make_int (j_max + 0.5);
        
  coupled_TBMEs_angular_table.allocate (j_number , j_number , j_number , j_number);
      
  for (int ij0 = 0 ; ij0 < j_number ; ij0++)
    {
      const double j0 = ij0 + 0.5;

      for (int ij1 = 0 ; ij1 < j_number ; ij1++)
	{
	  const double j1 = ij1 + 0.5;

	  for (int ij2 = 0 ; ij2 < j_number ; ij2++)
	    {
	      const double j2 = ij2 + 0.5;

	      for (int ij3 = 0 ; ij3 < j_number ; ij3++)
		{
		  const double j3 = ij3 + 0.5;

		  const int Jmin_in  = abs (ij0 - ij1);
		  const int Jmin_out = abs (ij2 - ij3);

		  const int Jmax_in  = ij0 + ij1 + 1;
		  const int Jmax_out = ij2 + ij3 + 1;
			
		  const int Jmin = max (Jmin_in , Jmin_out);
		  const int Jmax = min (Jmax_in , Jmax_out);

		  coupled_TBMEs_angular_table(ij0 , ij1 , ij2 , ij3) = ((J >= Jmin) && (J <= Jmax)) ? (minus_one_pow (j0 + j3 + J)*Wigner_6j (j2 , j3 , J , j1 , j0 , L)) : (0.0);
		}
	    }
	}
    }
}








void multipole_TBMEs_angular_table_str::allocate_calc_uncoupled (const int L_c , const double m_max)
{
  if (CG_over_hat_L_table.is_it_filled ()) error_message_print_abort ("multipole_TBMEs_angular_table_str cannot be allocated twice in multipole_TBMEs_angular_table_str::allocate_calc_uncoupled");

  L = L_c;

  m_max_sum = make_int (2.0*m_max);

  const int j_number = make_int (m_max + 0.5);

  const int m_number = 2*j_number;
  
  CG_over_hat_L_table.allocate (j_number , m_number , j_number , m_number);

  CG_over_hat_L_table = 0.0;
  
  for (int ij = 0 ; ij < j_number ; ij++)
    {
      const double j = ij + 0.5;

      const int im_min = make_int (-j + m_max);
      const int im_max = make_int ( j + m_max);

      for (int im = im_min ; im <= im_max ; im++)
	{
	  const double m = im - m_max;
		      
	  for (int ijp = 0 ; ijp < j_number ; ijp++)
	    {
	      const int Jmin = abs (ijp - ij);
	      
	      const int Jmax = ijp + ij + 1;
	      	      
	      if (Jmin > L) continue;
	      if (Jmax < L) continue;
	      
	      const double jp = ijp + 0.5;

	      const int imp_min = make_int (-jp + m_max);
	      const int imp_max = make_int ( jp + m_max);
	  
	      for (int imp = imp_min ; imp <= imp_max ; imp++)
		{	      
		  const int ML = imp - im;

		  if (abs (ML) > L) continue;
		  
		  const double mp = imp - m_max;

		  CG_over_hat_L_table(ij , im , ijp , imp) = Clebsch_Gordan (j , m , jp , -mp , L , -ML);
		}
	    }
	}
    }

  CG_over_hat_L_table /= hat (L);
}






void multipole_TBMEs_angular_table_str::allocate_fill (const class multipole_TBMEs_angular_table_str &X)
{
  if (CG_over_hat_L_table.is_it_filled ()) error_message_print_abort ("multipole_TBMEs_angular_table_str cannot be allocated twice in multipole_TBMEs_angular_table_str::allocate_fill");

  L = X.L;

  J = X.J;
  
  m_max_sum = X.m_max_sum;
  
  coupled_TBMEs_angular_table.allocate_fill (X.coupled_TBMEs_angular_table);

  CG_over_hat_L_table.allocate_fill (X.CG_over_hat_L_table);
}





void multipole_TBMEs_angular_table_str::deallocate ()
{
  coupled_TBMEs_angular_table.deallocate ();
  
  CG_over_hat_L_table.deallocate ();
  
  L = 0;
  
  J = 0;
  
  m_max_sum = 0;
}



// Calculation of the m-dependent part of < c d | Oi . Oj | a b > from stored arrays
// ---------------------------------------------------------------------------------
// ij and im indices are defined above, as well as class members. The states of indices 0,1,2,3 are a,b,c,d. 
// Other variables are either obvious or similar to those used and explained above.
// One first checks if ma + mb + mu = mc + md, as otherwise the TBME is equal to zero.
// Similarly, one checks if mi = ma - mc and mj = md - mb are equal to -L' , ... , L', as otherwise the TBME is equal to zero.
// ja,jc and jb,jd must be coupled to L' (the rank of Oi and Oj), as otherwise the TBME is equal to zero.
// One calculates the phase equal to (-1)^(ja + jb - ma - mb), which will be used to fix the sign of the TBME.
// The angular TBME is then calculated from <j m j' -m' |1 -m''>/(2L' + 1) stored in a member array.

double multipole_TBMEs_angular_table_str::operator () (
						       const int ij0 , const int im0 , 
						       const int ij1 , const int im1 , 
						       const int ij2 , const int im2 , 
						       const int ij3 , const int im3) const
{
  const int im0_plus_im1 = im0 + im1;
  
  if (im0_plus_im1 != im2 + im3) return 0.0;

  const int Jmin_02 = abs (ij0 - ij2);
  const int Jmin_13 = abs (ij1 - ij3);
  
  if (Jmin_02 > L) return 0.0;
  if (Jmin_13 > L) return 0.0;
  
  const int Jmax_02 = ij0 + ij2 + 1;
  const int Jmax_13 = ij1 + ij3 + 1;
  
  if (Jmax_02 < L) return 0.0;
  if (Jmax_13 < L) return 0.0;
  
  const int Delta_im2 = im2 - im0;
  
  if (abs (Delta_im2) > L) return 0.0;
  
  const int m0_plus_m1 = im0_plus_im1 - m_max_sum;
  
  const double CG_over_hat_L_02 = CG_over_hat_L_table(ij0 , im0 , ij2 , im2);
  const double CG_over_hat_L_13 = CG_over_hat_L_table(ij1 , im1 , ij3 , im3);
  
  const double TBME_angular_term_no_phase = CG_over_hat_L_02*CG_over_hat_L_13;

  const int j0_plus_j1 = ij0 + ij1 + 1;
  
  const int phase = minus_one_pow (j0_plus_j1 - m0_plus_m1 + Delta_im2);
  
  const double TBME_angular_term = (phase == 1) ? (TBME_angular_term_no_phase) : (-TBME_angular_term_no_phase);

  return TBME_angular_term;
}





double multipole_TBMEs_angular_table_str::operator () (const int ij0 , const int ij1 , const int ij2 , const int ij3) const
{
  return coupled_TBMEs_angular_table(ij0 , ij1 , ij2 , ij3);
}




double used_memory_calc (const class multipole_TBMEs_angular_table_str &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.coupled_TBMEs_angular_table) + used_memory_calc (T.CG_over_hat_L_table) - (sizeof (T.coupled_TBMEs_angular_table) + sizeof (T.CG_over_hat_L_table))/1000000.0);
}

