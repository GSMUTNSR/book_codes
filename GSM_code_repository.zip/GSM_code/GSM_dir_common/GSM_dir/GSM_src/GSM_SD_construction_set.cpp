#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Nucleons here are protons or neutrons (plus a few hyperons if any) only.


// Storage of dimensions and Slater determinants in arrays
// -------------------------------------------------------
// The Slater determinant has been generated and belongs to the proton or neutron model space.
// In the 2D partitioning method, one needs to generate Slater determinants with the number of valence protons or neutrons (plus a few hyperons if any) of the nucleus minus one or two as well.
// Hence, the Slater determinant can bear the number of valence protons or neutrons (plus a few hyperons if any) of the nucleus, or this value minus one or two as well. 
// If arrays dimensions are calculated only, the dimension of fixed parity and number of particles in the continuum is increased. 
// If Slater determinant arrays are constructed, the considered Slater determinant is also stored in the array containing Slater determinants.

void SD_construction_set::fill_sets (
				     const enum operation_type operation , 
				     const unsigned int N_valence_baryons_local ,
				     const unsigned int BP , 
				     const int S ,
				     const int n_spec , 
				     const int n_scat , 
				     const unsigned int iC , 
				     const int iM , 
				     const class Slater_determinant &SDc , 
				     class baryons_data &particles_data)
{
  class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set_local = particles_data.get_dimensions_SD_set_local (N_valence_baryons_local);
  
  switch (operation)
    {
    case DIMENSIONS_TABLES_CALC:
      {
	dimensions_SD_set_local(BP , S , n_spec , n_scat , iC , iM)++;
      } break;

    case TABLES_FILL:
      {
	const unsigned int SDc_index = dimensions_SD_set_local(BP , S , n_spec , n_scat , iC , iM)++;
	
	class array_of_SD &SD_set_local = particles_data.get_SD_set_local (N_valence_baryons_local);
	  
	SD_set_local(BP , S , n_spec , n_scat , iC , iM , SDc_index) = SDc;
	
      } break;

    default: abort_all ();
    } 
}




// Generation of all the Slater determinants of a fixed configuration
// ------------------------------------------------------------------
// The sub-Slater determinants |s0 s1 s2>, |s3>, |s4 s5> of a given configuration, each one belonging to a single shell, have been generated.
//
// For example, if one has a configuration with three nucleons on 0p3/2, one nucleon on 0p1/2 and one nucleon in 1s1/2, the sub-Slater determinants are:
// 0p3/2: |0p3/2(-3/2) 0p3/2(-1/2) 0p3/2(1/2)> , |0p3/2(-3/2) 0p3/2(-1/2) 0p3/2(3/2)> , |0p3/2(-3/2) 0p3/2(1/2) 0p3/2(3/2)> , |0p3/2(-1/2) 0p3/2(1/2) 0p3/2(3/2)>, written as A[0], A[1], A[2], A[3]
// 0p1/2: |0p1/2(-1/2)> , |0p1/2(1/2)>, written as B[0], B[1]
// 1s1/2: |1s1/2(-1/2)> , |1s1/2(1/2)>, written as C[0], C[1]
//
// Hence, one has 16 possible Slater determinants in this configuration.
// The Slater determinants are then constructed this way:
// 
// A[0] B[0] C[0]  (This Slater determinant always exists)
// A[1] B[0] C[0]  (A index is increased: sub-indices are correct => accepted)
// A[2] B[0] C[0]  (A index is increased: sub-indices are correct => accepted)
// A[3] B[0] C[0]  (A index is increased: sub-indices are correct => accepted)
// A[0] B[1] C[0]  (A index is increased: A[4] does not exist => A index is put to zero and B index is increased)
// A[1] B[1] C[0]  (A index is increased: sub-indices are correct => accepted)
// A[2] B[1] C[0]  (A index is increased: sub-indices are correct => accepted)
// A[3] B[1] C[0]  (A index is increased: sub-indices are correct => accepted)
// A[0] B[0] C[1]  (A index is increased: A[4] does not exist => A index is put to zero)
//                 (B index is increased: B[2] does not exist => A,B indices are put to zero and C index is increased)
// A[1] B[0] C[1]  (A index is increased: sub-indices are correct => accepted)
// A[2] B[0] C[1]  (A index is increased: sub-indices are correct => accepted)
// A[3] B[0] C[1]  (A index is increased: sub-indices are correct => accepted)
// A[0] B[1] C[1]  (A index is increased: A[4] does not exist => A index is put to zero and B index is increased)
// A[1] B[1] C[1]  (A index is increased: sub-indices are correct => accepted)
// A[2] B[1] C[1]  (A index is increased: sub-indices are correct => accepted)
// A[3] B[1] C[1]  (A index is increased: sub-indices are correct => accepted)
//
// Stop  (A index is increased: A[4] does not exist => A index is put to zero)
//       (B index is increased: B[2] does not exist => A,B indices are put to zero)
//       (C index is increased: C[2] does not exist: no other shell to consider => the routine stops)
//
// For each accepted Slater determinant, one calculates its angular momentum projection as it stored in an M-dependent array.

void SD_construction_set::all_SDs_of_configuration (
						    const enum operation_type operation , 
						    const unsigned int N_valence_baryons_local ,
						    const unsigned int BP , 
						    const int S ,
						    const int n_spec , 
						    const int n_scat , 
						    const unsigned int iC , 
						    const class array<unsigned int> &N_valence_baryons_per_shell , 
						    const class array<unsigned int> &N_sub_SDs_per_shell , 
						    const class array<class array<class Slater_determinant> > &sub_SDs_tab , 
						    class baryons_data &particles_data)
{
  const unsigned int Nshells_occupied = N_sub_SDs_per_shell.dimension (0);

  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();

  class array<unsigned int> sub_SDs_index_tab(Nshells_occupied);
  
  sub_SDs_index_tab = 0;

  class Slater_determinant SDc(N_valence_baryons_local);

  while (true)
    {
      SDc.get_antisymmetrized_product (N_valence_baryons_per_shell , sub_SDs_index_tab , sub_SDs_tab);

      const int iM = SDc.iM_determine (phi_table);
		
      fill_sets (operation , N_valence_baryons_local , BP , S , n_spec , n_scat , iC , iM , SDc , particles_data);

      bool good_sub_SDs_indices = false;

      for (unsigned int is = 0  ; (!good_sub_SDs_indices) && (is < Nshells_occupied) ; is++)
	{
	  sub_SDs_index_tab(is)++;

	  if (sub_SDs_index_tab(is) == N_sub_SDs_per_shell(is))
	    {
	      for (unsigned int iis = 0  ; iis <= is ; iis++) sub_SDs_index_tab(iis) = 0;
	    }
	  else
	    good_sub_SDs_indices = true;
	}

      if (!good_sub_SDs_indices) return;
    }
}



// Calculation of all the sub-Slater determinants of a shell
// ---------------------------------------------------------
// One calculates all the sub-Slater determinants of a shell having a fixed number of nucleons.
// Its number of nucleons does not have that of the full Slater determinant, but has to be smaller or equal.
// 
// For example, one considers three nucleons on 0p3/2. The sub-Slater determinants are:
// |0p3/2(-3/2) 0p3/2(-1/2) 0p3/2(1/2)> , |0p3/2(-3/2) 0p3/2(-1/2) 0p3/2(3/2)> , |0p3/2(-3/2) 0p3/2(1/2) 0p3/2(3/2)> , |0p3/2(-1/2) 0p3/2(1/2) 0p3/2(3/2)>
// written as {0,1,2}, {0,1,3}, {0,2,3}, {1,2,3}
//
// They are generated the following way:
// {0,1,2} (it is the ground state of considered sub-Slater determinants and always exists)
// {0,1,3} (the third state index is increased: state indices are correct => accepted)
// {0,2,3} (the third state index is increased: there is no third state of index 4)
//         (the second state index is increased and the third state index is second state+1: state indices are correct => accepted)
// {1,2,3} (the third state index is increased: there is no third state of index 4)
//         (the second state index is increased and the third state index is second state+1: there is no third state of index 4)
//         (the first state index is increased, the second state is first state+1 and the third state index is second state+1: state indices are correct => accepted)
//
// Stop (the third state index is increased: there is no third state of index 4)
//      (the second state index is increased and the third state index is second state+1: there is no third state of index 4)
//      (the first state index is increased, the second state is first state+1 and the third state index is second state+1: there is no third state of index 4)
//      (As all nucleons have been tried unsuccessfully to generate a new sub-Slater determinant, this means that all sub-Slater determinants have been generated as the algorithm is lexicographic, and the routine stops.)

void SD_construction_set::all_sub_SDs_per_shell (
						 const class baryons_data &particles_data , 
						 const class nlj_struct &shell_qn , 
						 const unsigned int N_valence_baryons_in_shell , 
						 class array<class Slater_determinant> &sub_SDs_tab_shell)
{
  const enum particle_type particle = shell_qn.get_particle ();
      
  const int n = shell_qn.get_n ();
  const int l = shell_qn.get_l ();
  
  const double j = shell_qn.get_j ();

  const class one_body_indices_str &one_body_indices = particles_data.get_one_body_indices ();
  
  const unsigned int first_state = one_body_indices(particle , n , l , j , -j);
  const unsigned int last_state  = one_body_indices(particle , n , l , j ,  j);

  unsigned int sub_SD_index = 0;

  class Slater_determinant sub_SD(N_valence_baryons_in_shell);

  sub_SD.ground_state (first_state);

  sub_SDs_tab_shell(sub_SD_index++) = sub_SD;

  while (true)
    {
      unsigned int i = N_valence_baryons_in_shell - 1;

      sub_SD[i]++;

      while (sub_SD[N_valence_baryons_in_shell - 1] > last_state)
	{
	  if (--i >= N_valence_baryons_in_shell) return; 

	  unsigned short int state = ++sub_SD[i];

	  const unsigned int i_plus_one = i + 1;

	  for (unsigned int ii = i_plus_one ; ii < N_valence_baryons_in_shell ; ii++) sub_SD[ii] = ++state;
	}

      sub_SDs_tab_shell(sub_SD_index++) = sub_SD;
    }
}



// Determination and storage of the shells indices and number of nucleons on each shell (occupancy) for a given configuration
// --------------------------------------------------------------------------------------------------------------------------
// One has a fixed configuration in which Slater determinants will be built.
// One determines here the shells indices and number of nucleons on each shell (occupancy).
// If the shell is not empty, one stores the index of the shell and its number of nucleons in corresponding arrays.

void SD_construction_set::shells_indices_N_valence_baryons_per_shell_fill (
									   const unsigned int N_nlj , 
									   const class configuration &C , 
									   class array<unsigned int> &shells_indices , 
									   class array<unsigned int> &N_valence_baryons_per_shell)
{
  unsigned int is = 0;

  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const unsigned int occupancy_s = C.occupancy_determine (s);

      if (occupancy_s > 0)
	{
	  shells_indices(is) = s;

	  N_valence_baryons_per_shell(is) = occupancy_s;

	  is++;
	}
    }
}




// Calculation of the number of sub-Slater determinants in occupied shells
// -----------------------------------------------------------------------
// One loops over all the occupied shells of the configuration and one calculated the number of sub-Slater determinants on each occupied shell.
// For a given shell having Nv valence protons or neutrons (plus a few hyperons if any) and Ns states, it is Ns! / (Nv! (Ns-Nv)!) as baryons are indistinguishable (generalized isospin formalism with hyperons) and Nv <= Ns.
//
// In order not to have to consider large factorials, one uses the formula: Ns! / (Nv! (Ns-Nv)!) = (Ns-Nv+1) ... Ns / (Ns-Nv)!.
//
// One starts with Ns-Nv+1, and one divides by i=1,2,... entering (Ns-Nv)! only if it is a multiple of it. 
// One stops once i is no longer a multiple of Ns-Nv+1 or it is equal to Nv.
//
// One multiplies by Ns-Nv+2, and one divides by i,i+1,... entering (Ns-Nv)! only if it is a multiple of it.
// One stops once i is no longer a multiple of Ns-Nv+1 or it is equal to Nv.
// 
// One continues until one reaches Ns in the numerator.

void SD_construction_set::N_sub_SDs_per_shell_fill (
						    const class array<class nlj_struct> &shells_qn , 
						    const class array<unsigned int> &shells_indices , 
						    const class array<unsigned int> &N_valence_baryons_per_shell , 
						    class array<unsigned int> &N_sub_SDs_per_shell)
{
  const unsigned int Nshells_occupied = N_sub_SDs_per_shell.dimension (0);

  for (unsigned int is = 0 ; is < Nshells_occupied ; is++)
    {
      const unsigned int s = shells_indices(is);

      const class nlj_struct &shell_qn = shells_qn(s);

      const unsigned int N_states = shell_qn.m_number_determine ();
      
      const unsigned int N_valence_baryons_per_shell_s = N_valence_baryons_per_shell(is);

      const unsigned int N_valence_baryons_per_shell_s_minus_one = N_valence_baryons_per_shell_s - 1;

      unsigned int N_sub_SDs_per_shell_is = 1;

      unsigned int i_denominator = 1;

      for (unsigned int i = N_states - N_valence_baryons_per_shell_s_minus_one ; i <= N_states ; i++)
	{
	  N_sub_SDs_per_shell_is *= i;	

	  while ((N_sub_SDs_per_shell_is%i_denominator == 0) && (i_denominator <= N_valence_baryons_per_shell_s)) N_sub_SDs_per_shell_is /= i_denominator++;
	}

      N_sub_SDs_per_shell(is) = N_sub_SDs_per_shell_is;
    }
}








// Calculation of the dimensions of arrays and generation of their Slater determinants and ordering of Slater determinants arrays
// ------------------------------------------------------------------------------------------------------------------------------
// Arrays of Slater determinants and/or their dimensions are generated here.
// Dimensions are put to zero first and increased afterwards. 
// If one has no valence protons or neutrons (plus a few hyperons if any), as can be the case with 2D partitioning with two valence particles, 
// as one needs to generate Slater determinants with the number of valence protons or neutrons (plus a few hyperons if any) of the nucleus minus one or two,
// only the vaccum Slater determinant exists, so that one just puts its dimension to 1.
// Otherwise, one runs over all configurations, one identifies its occupied shells, one builds associated sub-Slater determinants (see above), and then one builds Slater determinants of the configuration from the latter.
// As Slater determinants of different configurations are independently built, the loop over configurations is parallelized with OpenMP and MPI.
// The array of dimensions of Slater determinants arrays is reduced and distributed to all nodes have to have the proper dimensions.
// The array of Slater determinants arrays is not reduced in tables_fill_dimensions_calc. 
// It is done after ordering Slater determinants on each configuration in tables_ordering, where nodes order the Slater determinants of their assigned confgurations only.
// Ordering is done only if one has more than one Slater determinant in one configuration.
// Quicksort is used for the ordering of Slater determinants on each configuration using the lexicographic order.

void SD_construction_set::tables_fill_dimensions_calc (
						       const enum operation_type operation , 
						       const bool is_it_pole_approximation , 
						       const unsigned int N_valence_baryons_local ,
						       class baryons_data &particles_data)
{
  const int strangeness_max = particles_data.get_hypernucleus_strangeness ();
  
  const int n_spec_max = particles_data.get_n_spec_max ();
  
  const int n_scat_max = (!is_it_pole_approximation) ? (particles_data.get_n_scat_max ()) : (0);
  
  const int iM_max_local = particles_data.get_iM_max_local (N_valence_baryons_local);

  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  const unsigned short int N_nlj = particles_data.get_N_nlj_baryon ();

  const class array<unsigned int> &dimensions_configuration_set_local = particles_data.get_dimensions_configuration_set_local (N_valence_baryons_local);
  
  const class array_of_configuration &configuration_set_local = particles_data.get_configuration_set_local (N_valence_baryons_local);

  class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set_local = particles_data.get_dimensions_SD_set_local (N_valence_baryons_local);

  if (operation == DIMENSIONS_TABLES_CALC) dimensions_SD_set_local = 0;

  if (N_valence_baryons_local == 0)
    {
      dimensions_SD_set_local(0 , 0 , 0 , 0 , 0 , 0) = 1;
    }
  else
    {
      const unsigned int first_C_index = configuration_set_local.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
      
      const unsigned int last_C_index = configuration_set_local.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  
      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
	for (int S = 0 ; S <= strangeness_max ; S++)
	  for (int n_spec = 0 ; n_spec <= n_spec_max ; n_spec++)
	    for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
	      {
		const unsigned int dimension_C = dimensions_configuration_set_local(BP , S , n_spec , n_scat);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
		for (unsigned int iC = 0 ; iC < dimension_C ; iC++)
		  {
		    const unsigned int C_index = configuration_set_local.index_determine (BP , S , n_spec , n_scat , iC);

		    if ((C_index >= first_C_index) && (C_index <= last_C_index))
		      {
			const class configuration &C = configuration_set_local(BP , S , n_spec , n_scat , iC);
	    
			const unsigned int Nshells_occupied = C.shells_occupied_number_determine (N_nlj);

			class array<unsigned int> shells_indices(Nshells_occupied);
		    
			class array<unsigned int> N_valence_baryons_per_shell(Nshells_occupied);

			shells_indices_N_valence_baryons_per_shell_fill (N_nlj , C , shells_indices , N_valence_baryons_per_shell);

			class array<unsigned int> N_sub_SDs_per_shell(Nshells_occupied);
		    
			N_sub_SDs_per_shell_fill (shells_qn , shells_indices , N_valence_baryons_per_shell , N_sub_SDs_per_shell);

			class array<class array<class Slater_determinant> > sub_SDs_tab(Nshells_occupied);

			for (unsigned int is = 0 ; is < Nshells_occupied ; is++)
			  {
			    sub_SDs_tab(is).allocate (N_sub_SDs_per_shell(is));

			    class array<class Slater_determinant> &sub_SDs_tab_shell = sub_SDs_tab(is);

			    for (unsigned int iis = 0 ; iis < N_sub_SDs_per_shell(is) ; iis++) sub_SDs_tab_shell(iis).allocate (N_valence_baryons_per_shell(is));

			    const unsigned int s = shells_indices(is);

			    const class nlj_struct &shell_qn = shells_qn(s);
		    
			    const unsigned int N_valence_baryons_in_shell = N_valence_baryons_per_shell(is);
		    
			    all_sub_SDs_per_shell (particles_data , shell_qn , N_valence_baryons_in_shell , sub_SDs_tab_shell);
			  }

			const unsigned int dimension_SD_local_zero_index = dimensions_SD_set_local.index_determine (BP , S , n_spec , n_scat , iC , 0);
		
			for (int iM = 0 ; iM <= iM_max_local ; iM++) dimensions_SD_set_local[dimension_SD_local_zero_index + iM] = 0; 

			all_SDs_of_configuration (operation , N_valence_baryons_local , BP , S , n_spec , n_scat , iC , N_valence_baryons_per_shell , N_sub_SDs_per_shell , sub_SDs_tab , particles_data);
		      }
		  }		
	      }
      
#ifdef UseMPI
      
      if (is_it_MPI_parallelized && (operation == DIMENSIONS_TABLES_CALC)) dimensions_SD_set_local.MPI_Allreduce (MPI_MAX , MPI_COMM_WORLD);

#endif

    }
}

void SD_construction_set::tables_ordering (
					   const bool is_it_pole_approximation , 
					   const unsigned int N_valence_baryons_local ,
					   class baryons_data &particles_data)
{
  const int strangeness_max = particles_data.get_hypernucleus_strangeness ();
  
  const int n_spec_max = particles_data.get_n_spec_max ();
  
  const int n_scat_max = (!is_it_pole_approximation) ? (particles_data.get_n_scat_max ()) : (0); 

  const int iM_max_local = particles_data.get_iM_max_local (N_valence_baryons_local);
  
  const class array<unsigned int> &dimensions_configuration_set_local = particles_data.get_dimensions_configuration_set_local (N_valence_baryons_local);
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set_local = particles_data.get_dimensions_SD_set_local (N_valence_baryons_local);
  
  const unsigned int dimension_SD_max_local = particles_data.get_dimension_SD_max_local (N_valence_baryons_local);

  const class array_of_configuration &configuration_set_local = particles_data.get_configuration_set_local (N_valence_baryons_local);

  const unsigned int first_C_index = configuration_set_local.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_C_index = configuration_set_local.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);

  class array_of_SD &SD_set_local = particles_data.get_SD_set_local (N_valence_baryons_local);

  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int S = 0 ; S <= strangeness_max ; S++)
      for (int n_spec = 0 ; n_spec <= n_spec_max ; n_spec++)
	for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
	  {
	    const unsigned int dimension_C = dimensions_configuration_set_local(BP , S , n_spec , n_scat);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
	    for (unsigned int iC = 0 ; iC < dimension_C ; iC++)
	      {
		const unsigned int C_index = configuration_set_local.index_determine (BP , S , n_spec , n_scat , iC);

		if ((C_index >= first_C_index) && (C_index <= last_C_index))
		  {
		    class array<class Slater_determinant> SD_table_temp(dimension_SD_max_local);
		
		    for (unsigned int i = 0 ; i < dimension_SD_max_local ; i++) SD_table_temp(i).allocate (N_valence_baryons_local);

		    for (int iM = 0 ; iM <= iM_max_local ; iM++)
		      {
			const unsigned int dimension = dimensions_SD_set_local(BP , S , n_spec , n_scat , iC , iM);

			const unsigned long int SD_zero_index = SD_set_local.index_determine (BP , S , n_spec , n_scat , iC , iM , 0);

			if (dimension > 1) 
			  {
			    const unsigned int dimension_minus_one = dimension - 1;
			  
			    for (unsigned int i = 0 ; i < dimension ; i++)
			      {
				const unsigned long int SD_index = SD_zero_index + i;

				class Slater_determinant &SDi = SD_table_temp(i);
			    
				SDi = SD_set_local[SD_index];
			      }

			    SD_table_temp.quick_sort (0 , dimension_minus_one);

			    for (unsigned int i = 0 ; i < dimension ; i++)
			      {
				const unsigned long int SD_index = SD_zero_index + i;

				const class Slater_determinant &SDi = SD_table_temp(i);
			    
				SD_set_local[SD_index] = SDi;
			      }
			  }
		      }
		  }
	      }
	  }

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) SD_set_local.MPI_Allreduce_min (MPI_COMM_WORLD);
  
#endif
}






// Determination of arrays related to the time-reversal symmetry (TRS) of Slater determinants
// ------------------------------------------------------------------------------------------
// Time-reversal symmetry of a one-body state writes TRS|n l j m> = (-1)^(j - m) |n l j -m>.
// Its extension to Slater determinants is obvious: TRS |a b c> = |TRS(a) TRS(b) TRS(c)>.
// Time-reversed Slater determinants are used to save memory in phases arrays, in <SD_out | a+_alpha a_beta | SD_in> for example.
// Indeed, <SD_out | a+_alpha a_beta | SD_in> can be obtained from <SD_out | TRS a+_TRS(alpha) a_TRS(beta) TRS | SD_in> up to a phase simple to calculate.
// Thid allows to consider |SD_in> with M_in > 0 only for example. 
// Hence, one determines here the indices of TRS |SD>, as its configuration is unchanged and M projection becomes -M, and related phases.
// These indices are dependent of configuration and M projection: 
// the SD time-reversed of SD_set(BP , S , n_spec , n_scat , iC , iM , SD_index) is SD_set(BP , S , n_spec , n_scat , iC , TRS_iM , SD_TRS_index), with iM and TRS_iM the indices corresponding to M and -M,
// and BP,n_scat,iC the binary parity (see observables_basic_functions.cpp for definition), number of particles in the continuum and configuration index of the configuration.
// One calculates the TRS reordering binary phase and the TRS binary phase (see observables_basic_functions.cpp for definition of binary phase).
// The TRS reordering binary phase is only the phase of TRS |SD> after reordering its occupied states. Indeed, one can have TRS | 1 4 8 > = |3 2 7 > = -|2 3 7>, so that its reordering generates a phase.
// The TRS binary phase includes the (-1)^(j - m) one-body phases shown above, so that the TRS binary phase is the product of the TRS reordering binary phase and of all the  (-1)^(j - m) phases of present one-body states.

void SD_construction_set::TRS_tables_allocated_built (
						      const bool is_it_pole_approximation , 
						      const unsigned int N_valence_baryons_local ,
						      class baryons_data &particles_data)
{
  const unsigned long int dimension_SD_total_local = particles_data.get_dimension_SD_total_local (N_valence_baryons_local);
  
  const int strangeness_max = particles_data.get_hypernucleus_strangeness ();
  
  const int n_spec_max = particles_data.get_n_spec_max ();
  
  const int n_scat_max = (!is_it_pole_approximation) ? (particles_data.get_n_scat_max ()) : (0); 

  const int iM_max_local = particles_data.get_iM_max_local (N_valence_baryons_local);

  const class array<unsigned int> &dimensions_configuration_set_local = particles_data.get_dimensions_configuration_set_local (N_valence_baryons_local);
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set_local = particles_data.get_dimensions_SD_set_local (N_valence_baryons_local);
  
  class array_BP_S_Nspec_Nscat_iC<unsigned long int> &sum_dimensions_SD_set_local = particles_data.get_sum_dimensions_SD_set_local (N_valence_baryons_local);

  class array_of_SD &SD_set_local = particles_data.get_SD_set_local (N_valence_baryons_local);

  const class array<unsigned int> &TRS_nljm_indices = particles_data.get_TRS_nljm_indices ();

  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices_local = particles_data.get_SD_TRS_indices_local (N_valence_baryons_local);

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> &SD_TRS_reordering_bin_phases_local = particles_data.get_SD_TRS_reordering_bin_phases_local (N_valence_baryons_local);

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> &SD_TRS_bin_phases_local = particles_data.get_SD_TRS_bin_phases_local (N_valence_baryons_local);

  SD_TRS_indices_local.allocate (dimension_SD_total_local , sum_dimensions_SD_set_local);
  
  SD_TRS_reordering_bin_phases_local.allocate (dimension_SD_total_local , sum_dimensions_SD_set_local);

  SD_TRS_bin_phases_local.allocate (dimension_SD_total_local , sum_dimensions_SD_set_local);
  
  class array<Slater_determinant> TRS_SD_tab(NUMBER_OF_THREADS);
  class array<Slater_determinant> SD_work_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      TRS_SD_tab(i).allocate (N_valence_baryons_local);
      
      SD_work_tab(i).allocate (N_valence_baryons_local);
    }
  
  for (unsigned int BP = 0  ; BP <= 1 ; BP++)
    for (int S = 0 ; S <= strangeness_max ; S++)
      for (int n_spec = 0 ; n_spec <= n_spec_max ; n_spec++)
	for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
	  {
	    const unsigned int dimension_C = dimensions_configuration_set_local(BP , S , n_spec , n_scat);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
	    for (unsigned int iC = 0 ; iC < dimension_C ; iC++)
	      {
		const unsigned int dimensions_SD_set_zero_index = dimensions_SD_set_local.index_determine (BP , S , n_spec , n_scat , iC , 0);

		const unsigned int i_thread = OpenMP_thread_number_determine ();
 
		class Slater_determinant &SD_work = SD_work_tab(i_thread);
	    
		class Slater_determinant &TRS_SD = TRS_SD_tab(i_thread);

		for (int iM = 0 ; iM <= iM_max_local ; iM++)
		  {
		    const unsigned int dimensions_SD_set_index = dimensions_SD_set_zero_index + iM ;

		    const unsigned int dimension_SD_set = dimensions_SD_set_local[dimensions_SD_set_index];
		
		    const unsigned long int total_SD_zero_index = SD_set_local.index_determine (BP , S , n_spec , n_scat , iC , iM , 0);

		    const unsigned long int SD_TRS_indices_zero_index = SD_TRS_indices_local.index_determine (BP , S , n_spec , n_scat , iC , iM , 0);

		    const unsigned long int SD_TRS_reordering_bin_phases_zero_index = SD_TRS_reordering_bin_phases_local.index_determine (BP , S , n_spec , n_scat , iC , iM , 0);

		    const unsigned long int SD_TRS_bin_phases_zero_index = SD_TRS_bin_phases_local.index_determine (BP , S , n_spec , n_scat , iC , iM , 0);

		    for (unsigned int SD_index = 0 ; SD_index < dimension_SD_set ; SD_index++)
		      {
			const unsigned long int total_SD_index = total_SD_zero_index + SD_index;

			const class Slater_determinant &SD = SD_set_local[total_SD_index];

			unsigned int TRS_reordering_bin_phase = 0;

			unsigned int TRS_bin_phase = 0;

			SD.TRS_SD_bin_phases (phi_table , TRS_nljm_indices , TRS_SD , TRS_reordering_bin_phase , TRS_bin_phase);

			const unsigned int TRS_iM = iM_max_local - iM;
		    
			const unsigned int TRS_SD_index = TRS_SD.index_search (BP , S , n_spec , n_scat , iC , TRS_iM , dimensions_SD_set_local , SD_set_local , SD_work);

			const unsigned long int SD_TRS_indices_index = SD_TRS_indices_zero_index + SD_index;

			const unsigned long int SD_TRS_reordering_bin_phase_index = SD_TRS_reordering_bin_phases_zero_index + SD_index;

			const unsigned long int SD_TRS_bin_phases_index = SD_TRS_bin_phases_zero_index + SD_index;

			SD_TRS_indices_local[SD_TRS_indices_index] = TRS_SD_index;

			SD_TRS_reordering_bin_phases_local[SD_TRS_reordering_bin_phase_index] = TRS_reordering_bin_phase;

			SD_TRS_bin_phases_local[SD_TRS_bin_phases_index] = TRS_bin_phase;
		      }
		  }
	      }
	  }
}





// Storage of Slater determinants quantum numbers
// ----------------------------------------------
// The binary parity of the Slater determinant (see observables_basic_functions.cpp for definition), number of particle in the continuum, configuration index, M projection index and SD index are stored in an array.

void SD_construction_set::SD_quantum_numbers_table_allocated_built (
								    const bool is_it_pole_approximation , 
								    class baryons_data &particles_data)
{
  const unsigned long int dimension_SD_total = particles_data.get_dimension_SD_total ();
  
  const int strangeness_max = particles_data.get_hypernucleus_strangeness ();
  
  const int n_spec_max = particles_data.get_n_spec_max ();
  
  const int n_scat_max = (!is_it_pole_approximation) ? (particles_data.get_n_scat_max ()) : (0);
  
  const int iM_max = particles_data.get_iM_max ();

  const class array<unsigned int> &dimensions_configuration_set = particles_data.get_dimensions_configuration_set ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = particles_data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = particles_data.get_SD_set ();
  
  class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = particles_data.get_SD_quantum_numbers_tab ();

  SD_quantum_numbers_tab.allocate (dimension_SD_total);
    
  for (unsigned int BP = 0  ; BP <= 1 ; BP++)
    for (int S = 0 ; S <= strangeness_max ; S++)
      for (int n_spec = 0 ; n_spec <= n_spec_max ; n_spec++)
	for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
	  {
	    const unsigned int dimension_C = dimensions_configuration_set(BP , S , n_spec , n_scat);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
	    for (unsigned int iC = 0 ; iC < dimension_C ; iC++)
	      {
		const unsigned int dimensions_SD_set_zero_index = dimensions_SD_set.index_determine (BP , S , n_spec , n_scat , iC , 0);

		for (int iM = 0 ; iM <= iM_max ; iM++)
		  {
		    const unsigned int dimensions_SD_set_index = dimensions_SD_set_zero_index + iM ;
		
		    const unsigned int dimension_SD_set = dimensions_SD_set[dimensions_SD_set_index];

		    const unsigned long int total_SD_zero_index = SD_set.index_determine (BP , S , n_spec , n_scat , iC , iM , 0);

		    for (unsigned int SD_index = 0 ; SD_index < dimension_SD_set ; SD_index++)
		      {
			const unsigned long int total_SD_index = total_SD_zero_index + SD_index;

			SD_quantum_numbers_tab(total_SD_index).initialize (BP , S , n_spec , n_scat , iC , iM , SD_index);
		      }
		  }
	      }
	  }
}







// Calculation of sum of dimensions related to Slater determinants and allocation of arrays from these dimensions for 1D and hybrid 1D/2D partitioning
// ---------------------------------------------------------------------------------------------------------------------------------------
// The dimensions for fixed binary parity BP (see observables_basic_functions.cpp for definition), number of particles in the continuum n_scat and M projection index iM are not equal in general.
// Consequently, arrays function of indices BP, n_scat, iC, iM, SD_index, with iC the index of a configuration of fixed binary parity and number of particles in the continuum,
// and SD_index with the index of a Slater determinant with fixed configuration and M projection index iM.
// cannot be stored as standard three dimensional arrays without having unused elements.
// To avoid this situation, one allocates arrays function of indices BP, n_scat, iC, iM, SD_index as one-dimensional arrays 
// and one calculateds the total index related to BP, n_scat, iC, iM, SD_index from the sum of dimensions with fixed configuration and M projection.
// This is done in this routine in sum_dimensions_SD_set(BP , S , n_spec , n_scat, n_scat, iC, iM, SD_index) (see below).
// The total number of Slater determinants and maximal dimension with fixed configuration and M projection is also calculated.
// The array of Slater determinants and arrays of booleans related to space truncation used afterwards are allocated here as well.
// This routine is used in the 1D and hybrid 1D/2D partitioning, but not in the 2D partitioning. dimensions_tables_alloc_calc_2D is used in the 2D partitioning.

void SD_construction_set::dimensions_tables_alloc_calc_1D_hybrid_1D_2D_partitioning (
										     const bool is_there_cout ,
										     const bool is_it_only_basis , 
										     const bool only_dimensions , 
										     const bool is_it_pole_approximation , 
										     class baryons_data &particles_data)
{
  const enum particle_type nucleonic_particle = particles_data.get_nucleonic_particle ();

  const int strangeness_max = particles_data.get_hypernucleus_strangeness ();

  const int strangeness_max_plus_one = strangeness_max + 1;
  
  const int n_spec_max = particles_data.get_n_spec_max ();
  
  const int n_spec_max_plus_one = n_spec_max + 1;
  
  const int n_scat_max = (!is_it_pole_approximation) ? (particles_data.get_n_scat_max ()) : (0); 

  const unsigned int N_valence_baryons = particles_data.get_N_valence_baryons ();
  
  const int iM_max = particles_data.get_iM_max ();

  const int iM_max_plus_one = iM_max + 1;
  
  const unsigned int dimension_configuration_total = particles_data.get_dimension_configuration_total ();
  
  const class array<unsigned int> &sum_dimensions_configuration_set = particles_data.get_sum_dimensions_configuration_set ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = particles_data.get_dimensions_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = particles_data.get_dimensions_configuration_set ();

  class array_BP_S_Nspec_Nscat_iC<unsigned long int> &sum_dimensions_SD_set = particles_data.get_sum_dimensions_SD_set ();
  
  sum_dimensions_SD_set.allocate (dimension_configuration_total , sum_dimensions_configuration_set , iM_max_plus_one);
  
  unsigned int dimension_bef = 0;

  unsigned long int sum_dimensions_bef = 0;

  unsigned long int dimension_SD_total = 0;

  unsigned int dimension_SD_max = 0;

  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int S = 0 ; S <= strangeness_max ; S++)
      for (int n_spec = 0 ; n_spec <= n_spec_max ; n_spec++)
	for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
	  {
	    const unsigned int dimension_C = dimensions_configuration_set(BP , S , n_spec , n_scat);

	    for (unsigned int iC = 0 ; iC < dimension_C ; iC++)
	      {
		const unsigned int dimensions_SD_set_zero_index = dimensions_SD_set.index_determine (BP , S , n_spec , n_scat , iC , 0);
	    
		const unsigned long int sum_dimensions_SD_set_zero_index = sum_dimensions_SD_set.index_determine (BP , S , n_spec , n_scat , iC , 0);

		for (int iM = 0 ; iM <= iM_max ; iM++)
		  {
		    const unsigned int dimensions_SD_set_index = dimensions_SD_set_zero_index + iM;

		    const unsigned int dimension = dimensions_SD_set[dimensions_SD_set_index];

		    const unsigned long int sum_dimensions_SD_set_index = sum_dimensions_SD_set_zero_index + iM;

		    unsigned long int &sum_dimensions_SD_set_BP_S_n_scat_iC_iM = sum_dimensions_SD_set[sum_dimensions_SD_set_index];

		    dimension_SD_total += dimension;

		    sum_dimensions_SD_set_BP_S_n_scat_iC_iM = sum_dimensions_bef + dimension_bef;

		    dimension_bef = dimension;

		    sum_dimensions_bef = sum_dimensions_SD_set_BP_S_n_scat_iC_iM;

		    dimension_SD_max = max (dimension , dimension_SD_max);
		  }
	      }
	  }

  particles_data.set_dimension_SD_total (dimension_SD_total);
  
  particles_data.set_dimension_SD_max (dimension_SD_max);
  
  if (!is_it_only_basis && only_dimensions) return;
	  
  class array_of_SD &SD_set = particles_data.get_SD_set ();
	  
  SD_set.allocate (is_there_cout , nucleonic_particle , dimension_SD_total , sum_dimensions_SD_set , N_valence_baryons); 
    
  class array<bool> &BPin_Sin_Nspec_in_iMin_for_one_jump_tab = particles_data.get_BPin_Sin_Nspec_in_iMin_for_one_jump_tab ();

  class array<bool> &BPout_Sout_Nspec_out_iMout_for_one_jump_tab = particles_data.get_BPout_Sout_Nspec_out_iMout_for_one_jump_tab ();
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_inSD_in_space_tab = particles_data.get_is_inSD_in_space_tab (0);

  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_outSD_in_space_tab = particles_data.get_is_outSD_in_space_tab ();

  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_it_SD_inter_to_include = particles_data.get_is_it_SD_inter_to_include_tab ();

  BPin_Sin_Nspec_in_iMin_for_one_jump_tab.allocate (2 , strangeness_max_plus_one , n_spec_max_plus_one , iM_max_plus_one);

  BPout_Sout_Nspec_out_iMout_for_one_jump_tab.allocate (2 , strangeness_max_plus_one , n_spec_max_plus_one , iM_max_plus_one);
  
  is_inSD_in_space_tab.allocate (dimension_SD_total , sum_dimensions_SD_set);

  is_outSD_in_space_tab.allocate (dimension_SD_total , sum_dimensions_SD_set);
  
  is_it_SD_inter_to_include.allocate (dimension_SD_total , sum_dimensions_SD_set); 
}









// Allocation and generation of all arrays related to Slater determinants for 1D and hybrid 1D/2D partitioning
// ------------------------------------------------------------------------------------------------------
// Arrays related to Slater determinants, hence those storing Slater determinants and the dimensions of arrays, as well as arrays used afterwards in matrix-GSM vector operations, are allocated here.
// One firstly calculates the dimensions of arrays of Slater determinants, one allocates them and then one generates arrays of Slater determinants.
// Other arrays related to Slater determinants are then allocated and calculated for some of them.
// The dimensions of arrays of Slater determinants can be printed as well as the time taken to generate all arrays.
// This routine is used with 1D and hybrid 1D/2D partitioning, but not with 2D partitioning. tables_allocated_built_2D is used with 2D partitioning.

void SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (
									       const bool is_there_cout , 
									       const bool print_detailed_information ,
									       const bool is_it_only_basis , 
									       const bool is_it_pole_approximation , 
									       class baryons_data &particles_data , 
									       const bool only_dimensions)
{
  const enum particle_type nucleonic_particle = particles_data.get_nucleonic_particle ();

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      cout << endl << "Slater determinants " << nucleonic_particle << " space" << endl;
      cout <<         "---------------------------------" << endl << endl;
    }

  const bool are_time_details_considered = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout && print_detailed_information);
  
  const double reference_time = (are_time_details_considered) ? (absolute_time_determine ()) : (NADA);
 
  const unsigned int N_valence_baryons = particles_data.get_N_valence_baryons ();

  const int iM_max = particles_data.get_iM_max ();

  const int iM_max_plus_one = iM_max + 1; 

  const unsigned int dimension_configuration_total = particles_data.get_dimension_configuration_total ();
  
  const class array<unsigned int> &sum_dimensions_configuration_set = particles_data.get_sum_dimensions_configuration_set ();

  class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = particles_data.get_dimensions_SD_set ();

  dimensions_SD_set.deallocate ();

  dimensions_SD_set.allocate (dimension_configuration_total , sum_dimensions_configuration_set , iM_max_plus_one);
  
  tables_fill_dimensions_calc (DIMENSIONS_TABLES_CALC , is_it_pole_approximation , N_valence_baryons , particles_data);

  dimensions_tables_alloc_calc_1D_hybrid_1D_2D_partitioning (is_there_cout , is_it_only_basis , only_dimensions , is_it_pole_approximation , particles_data);

  if (!is_it_only_basis && only_dimensions) return;
  
  tables_fill_dimensions_calc (TABLES_FILL , is_it_pole_approximation , N_valence_baryons , particles_data);

  tables_ordering (is_it_pole_approximation , N_valence_baryons , particles_data);
  
  TRS_tables_allocated_built (is_it_pole_approximation , N_valence_baryons , particles_data);
  
  SD_quantum_numbers_table_allocated_built (is_it_pole_approximation , particles_data);

  if (are_time_details_considered)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time; 
      
      cout << nucleonic_particle << " space Slater determinants built (1D - hybrid 1D/2D partitioning) time:" << relative_time << " s" << endl << endl;
    }
}










// Calculation of sum of dimensions related to Slater determinants and allocation of arrays from these dimensions for the 2D partitioning
// ---------------------------------------------------------------------------------------------------------------------------------------
// The dimensions for fixed binary parity BP (see observables_basic_functions.cpp for definition), number of particles in the continuum n_scat and M projection index iM are not equal in general.
// Consequently, arrays function of indices BP, n_scat, iC, iM, SD_index, with iC the index of a configuration of fixed binary parity and number of particles in the continuum,
// and SD_index with the index of a Slater determinant with fixed configuration and M projection index iM.
// cannot be stored as standard three dimensional arrays without having unused elements.
// To avoid this situation, one allocates arrays function of indices BP, n_scat, iC, iM, SD_index as one-dimensional arrays 
// and one calculateds the total index related to BP, n_scat, iC, iM, SD_index from the sum of dimensions with fixed configuration and M projection.
// This is done in this routine in sum_dimensions_SD_set(BP , S , n_spec , n_scat, n_scat, iC, iM, SD_index) (see below).
// The total number of Slater determinants and maximal dimension with fixed configuration and M projection is also calculated.
// As one needs to generate Slater determinants with the number of valence protons or neutrons (plus a few hyperons if any) of the nucleus minus one or two as well with 2D partitioning,
// a loop on these numbers of valence protons or neutrons (plus a few hyperons if any) is done here.
// One has to check if the number of valence protons or neutrons (plus a few hyperons if any) of the nucleus minus one or two is positive or zero, which is not the case if one has only one valence nucleon for example.
// This case is handled by replacing negative numbers of nucleons by the NO_VALENCE_NUCLEONS dummy value (see const.h), which is used here to check if one is in that case or not.
// The array of Slater determinants and arrays of booleans related to space truncation used afterwards are allocated here as well.
// This routine is used with 2D partitioning, but not with 1D and hybrid 1D/2D partitioning. dimensions_tables_alloc_calc_1D_hybrid_1D_2D is used with 1D and hybrid 1D/2D partitioning.

void SD_construction_set::dimensions_tables_alloc_calc_2D_partitioning (
									const bool is_there_cout ,
									const bool is_it_only_basis , 
									const bool only_dimensions , 
									const bool is_it_pole_approximation , 
									class baryons_data &particles_data)
{
  const enum particle_type nucleonic_particle = particles_data.get_nucleonic_particle ();

  const int strangeness_max = particles_data.get_hypernucleus_strangeness ();
  
  const int n_spec_max = particles_data.get_n_spec_max ();
  
  const int n_scat_max = (!is_it_pole_approximation) ? (particles_data.get_n_scat_max ()) : (0); 

  const unsigned int N_valence_baryons    = particles_data.get_N_valence_baryons ();
  const unsigned int N_valence_baryons_1h = particles_data.get_N_valence_baryons_1h ();
  const unsigned int N_valence_baryons_2h = particles_data.get_N_valence_baryons_2h ();
  
  const unsigned int N_valence_baryons_local_table[] = {N_valence_baryons_2h , N_valence_baryons_1h , N_valence_baryons};
    
  for (unsigned int N_valence_baryons_index = 0 ; N_valence_baryons_index <= 2 ; N_valence_baryons_index++)
    {
      const unsigned int N_valence_baryons_local = N_valence_baryons_local_table[N_valence_baryons_index];

      if (N_valence_baryons_local != NO_VALENCE_NUCLEONS)
	{
	  const int iM_max_local = particles_data.get_iM_max_local (N_valence_baryons_local);

	  const int iM_max_local_plus_one = iM_max_local + 1;

	  const unsigned int dimension_configuration_total_local = particles_data.get_dimension_configuration_total_local (N_valence_baryons_local);
	  
	  const class array<unsigned int> &sum_dimensions_configuration_set_local = particles_data.get_sum_dimensions_configuration_set_local (N_valence_baryons_local);

	  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set_local = particles_data.get_dimensions_SD_set_local (N_valence_baryons_local);

	  const class array<unsigned int> &dimensions_configuration_set_local = particles_data.get_dimensions_configuration_set_local (N_valence_baryons_local);

	  class array_BP_S_Nspec_Nscat_iC<unsigned long int> &sum_dimensions_SD_set_local = particles_data.get_sum_dimensions_SD_set_local (N_valence_baryons_local);

	  sum_dimensions_SD_set_local.allocate (dimension_configuration_total_local , sum_dimensions_configuration_set_local , iM_max_local_plus_one);

	  unsigned int dimension_bef = 0;

	  unsigned long int sum_dimensions_bef = 0;

	  unsigned long int dimension_SD_total_local = 0;

	  unsigned int dimension_SD_max_local = 0;

	  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
	    for (int S = 0 ; S <= strangeness_max ; S++)
	      for (int n_spec = 0 ; n_spec <= n_spec_max ; n_spec++)
		for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
		  {
		    const unsigned int dimension_C = dimensions_configuration_set_local(BP , S , n_spec , n_scat);

		    for (unsigned int iC = 0 ; iC < dimension_C ; iC++)
		      {
			const unsigned int dimensions_SD_set_local_zero_index = dimensions_SD_set_local.index_determine (BP , S , n_spec , n_scat , iC , 0);
		    
			const unsigned long int sum_dimensions_SD_set_local_zero_index = sum_dimensions_SD_set_local.index_determine (BP , S , n_spec , n_scat , iC , 0);

			for (int iM = 0 ; iM <= iM_max_local ; iM++)
			  {
			    const unsigned int dimensions_SD_set_local_index = dimensions_SD_set_local_zero_index + iM;

			    const unsigned int dimension = dimensions_SD_set_local[dimensions_SD_set_local_index];

			    const unsigned long int sum_dimensions_SD_set_local_index = sum_dimensions_SD_set_local_zero_index + iM;

			    unsigned long int &sum_dimensions_SD_set_local_BP_S_n_scat_iC_iM = sum_dimensions_SD_set_local[sum_dimensions_SD_set_local_index];

			    dimension_SD_total_local += dimension;
			
			    sum_dimensions_SD_set_local_BP_S_n_scat_iC_iM = sum_dimensions_bef + dimension_bef;

			    dimension_bef = dimension;

			    sum_dimensions_bef = sum_dimensions_SD_set_local_BP_S_n_scat_iC_iM;

			    dimension_SD_max_local = max (dimension , dimension_SD_max_local);
			  }
		      }
		  }

	  particles_data.set_dimension_SD_total_local (N_valence_baryons_local , dimension_SD_total_local);
	  
	  particles_data.set_dimension_SD_max_local (N_valence_baryons_local , dimension_SD_max_local);
	}
    }

  if (!is_it_only_basis && only_dimensions) return;

  for (unsigned int N_valence_baryons_index = 0 ; N_valence_baryons_index <= 2 ; N_valence_baryons_index++)
    {
      const unsigned int N_valence_baryons_local = N_valence_baryons_local_table[N_valence_baryons_index];

      if (N_valence_baryons_local != NO_VALENCE_NUCLEONS)
	{
	  const unsigned long int dimension_SD_total_local = particles_data.get_dimension_SD_total_local (N_valence_baryons_local);

	  const class array_BP_S_Nspec_Nscat_iC<unsigned long int> &sum_dimensions_SD_set_local = particles_data.get_sum_dimensions_SD_set_local (N_valence_baryons_local);

	  class array_of_SD &SD_set_local = particles_data.get_SD_set_local (N_valence_baryons_local);

	  SD_set_local.allocate (is_there_cout , nucleonic_particle , dimension_SD_total_local , sum_dimensions_SD_set_local , N_valence_baryons_local); 
	}
    }

  const unsigned long int dimension_SD_total = particles_data.get_dimension_SD_total ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned long int> &sum_dimensions_SD_set = particles_data.get_sum_dimensions_SD_set ();
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_inSD_in_space_tab_occupied = particles_data.get_is_inSD_in_space_tab (0);
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_inSD_in_space_tab_unoccupied = particles_data.get_is_inSD_in_space_tab (1);

  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_inSD_in_space_tab_Jpm = particles_data.get_is_inSD_in_space_tab_Jpm ();

  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_outSD_in_space_tab = particles_data.get_is_outSD_in_space_tab ();
  
  is_inSD_in_space_tab_occupied.allocate (dimension_SD_total , sum_dimensions_SD_set);

  is_inSD_in_space_tab_unoccupied.allocate (dimension_SD_total , sum_dimensions_SD_set);

  is_inSD_in_space_tab_Jpm.allocate (dimension_SD_total , sum_dimensions_SD_set);

  is_outSD_in_space_tab.allocate (dimension_SD_total , sum_dimensions_SD_set);
}











// Allocation and generation of all arrays related to Slater determinants for the 2D partitioning
// ----------------------------------------------------------------------------------------------
// Arrays related to Slater determinants, hence those storing Slater determinants and the dimensions of arrays, as well as arrays used afterwards in matrix-GSM vector operations, are allocated here.
// One firstly calculates the dimensions of arrays of Slater determinants, one allocates them and then one generates arrays of Slater determinants.
// Other arrays related to Slater determinants are then allocated and calculated for some of them.
// As one needs to generate Slater determinants with the number of valence protons or neutrons (plus a few hyperons if any) of the nucleus minus one or two as well with 2D partitioning,
// a loop on these numbers of valence protons or neutrons (plus a few hyperons if any) is done here.
// One has to check if the number of valence protons or neutrons (plus a few hyperons if any) of the nucleus minus one or two is positive or zero, which is not the case if one has only one valence nucleon for example.
// This case is handled by replacing negative numbers of nucleons by the NO_VALENCE_NUCLEONS dummy value (see const.h), which is used here to check if one is in that case or not.
// The dimensions of arrays of Slater determinants can be printed as well as the time taken to generate all arrays.
// This routine is used with 2D partitioning, but not in the 1D and hybrid 1D/2D partitioning. tables_allocated_built_1D_hybrid_1D_2D is used with 1D and hybrid 1D/2D partitioning.

void SD_construction_set::tables_allocated_built_2D_partitioning (
								  const bool is_there_cout , 
								  const bool print_detailed_information ,
								  const bool is_it_only_basis , 
								  const bool is_it_pole_approximation , 
								  class baryons_data &particles_data , 
								  const bool only_dimensions)
{
  const enum particle_type nucleonic_particle = particles_data.get_nucleonic_particle ();

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      cout << endl << "Slater determinants " << nucleonic_particle << " space" << endl;
      cout <<         "---------------------------------" << endl << endl;
    }

  const bool are_time_details_considered = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout && print_detailed_information);
 
  const double reference_time = (are_time_details_considered) ? (absolute_time_determine ()) : (NADA);

  const unsigned int N_valence_baryons    = particles_data.get_N_valence_baryons    ();
  const unsigned int N_valence_baryons_1h = particles_data.get_N_valence_baryons_1h ();
  const unsigned int N_valence_baryons_2h = particles_data.get_N_valence_baryons_2h ();
  
  const unsigned int N_valence_baryons_local_table[] = {N_valence_baryons_2h , N_valence_baryons_1h , N_valence_baryons};
    
  for (unsigned int N_valence_baryons_index = 0 ; N_valence_baryons_index <= 2 ; N_valence_baryons_index++)
    {
      const unsigned int N_valence_baryons_local = N_valence_baryons_local_table[N_valence_baryons_index];

      if (N_valence_baryons_local != NO_VALENCE_NUCLEONS)
	{
	  const int iM_max_local = particles_data.get_iM_max_local (N_valence_baryons_local);
	  
	  const int iM_max_local_plus_one = iM_max_local + 1; 

	  const unsigned int dimension_configuration_total_local = particles_data.get_dimension_configuration_total_local (N_valence_baryons_local);

	  const class array<unsigned int> &sum_dimensions_configuration_set_local = particles_data.get_sum_dimensions_configuration_set_local (N_valence_baryons_local);

	  class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set_local = particles_data.get_dimensions_SD_set_local (N_valence_baryons_local);

	  dimensions_SD_set_local.deallocate ();	  

	  dimensions_SD_set_local.allocate (dimension_configuration_total_local , sum_dimensions_configuration_set_local , iM_max_local_plus_one);      
	  
	  tables_fill_dimensions_calc (DIMENSIONS_TABLES_CALC , is_it_pole_approximation , N_valence_baryons_local , particles_data);
	}
    }

  dimensions_tables_alloc_calc_2D_partitioning (is_there_cout , is_it_only_basis , only_dimensions , is_it_pole_approximation , particles_data);

  if (!is_it_only_basis && only_dimensions) return;
  
  for (unsigned int N_valence_baryons_index = 0 ; N_valence_baryons_index <= 2 ; N_valence_baryons_index++)
    {
      const unsigned int N_valence_baryons_local = N_valence_baryons_local_table[N_valence_baryons_index];
      
      if ((N_valence_baryons_local > 0) && (N_valence_baryons_local != NO_VALENCE_NUCLEONS))
	{
	  tables_fill_dimensions_calc (TABLES_FILL , is_it_pole_approximation , N_valence_baryons_local , particles_data);

	  tables_ordering (is_it_pole_approximation , N_valence_baryons_local , particles_data);
	  
	  TRS_tables_allocated_built (is_it_pole_approximation , N_valence_baryons_local , particles_data);
	}
    }
    
  SD_quantum_numbers_table_allocated_built (is_it_pole_approximation , particles_data);

  if (are_time_details_considered)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time; 
      
      cout << nucleonic_particle << " space Slater determinants built (2D partitioning) time:" << relative_time << " s" << endl << endl;
    }
}

