#include "../GSM_include/GSM_include_def_common.h"

using namespace Wigner_signs;

// TYPE is double or complex
// -------------------------

// CM is center of mass
// --------------------

// TBME is two-body matrix element
// -------------------------------





// Class storing the Clebsch-Gordan coefficients needed to calculate the TBMEs of a many-body center of mass (CM) operator
// -----------------------------------------------------------------------------------------------------------------------
//
// TBMEs are not antisymmetrized in this class. They will be antisymmetrized afterwards in the many-body CM operator class.
//
// Coupled scheme
// --------------
// One considers only scalar CM operators.
// Indeed, non-scalar operators are used for building projectiles for the reaction code.
// Consequently, they are ignored in the two-body code.
// Non-scalar CM operators consist of L-, Lz, L+ (so that L-.L+ + Lz.(Lz + Id) = L^2[CM]), and A-[CM-HO], A0[CM-HO], A+[CM-HO] (HO ladder operators of the form const[P].P_{-1,0,1} - i.const[R].R_{-1,0,1}).
// Moreover, the reduced-density matrix code, where the coupled scheme is used, can only deal with scalar operators.
// Thus: < c d | Oi . Oj | a b > = (-1)^(ja + jd + J) . Wigner_6j (jc , jd , J , jb , ja , 1) . < c || Oi || a > . < d || Oj || b >.
// One then stores the products of phases and Wigner signs entering coupled TBMEs.
// 
// Uncoupled scheme
// ----------------
// The TBMEs used in many-body CM operators in M-scheme are of the form < c d | [Oi x Oj]^rank_mu | a b >, where Oi=pi,ri, Oj=pj,rj and (a,b) and (c,d) are uncoupled two-body states.
// Rank is 0,1. mu is its projection, so that |mu| <= 1.
//
// As one uses M-scheme and as the [Oi x Oj]^rank_mu operator is separable, it is convenient to decouple [Oi x Oj]^rank_mu to calculate < c d | [Oi x Oj]^rank_mu | a b >:
//
// < c d | [Oi x Oj]^rank_mu | a b > = \sum_(mi mj) <1 mi 1 mj | rank mu>  < c d | Oi_mi x Oj_mj | a b > = \sum_(mi mj) <1 mi 1 mj | rank mu>  < c | Oi_mi | a > < d | Oj_mj | b >
//                                   = (-1)^(ja + jb - ma - mb)/3 <ja ma jc -mc |1 -mi> <jb mb jd -md |1 -mj> <1 mi 1 mj | rank mu>  < c || Oi || a > < d || Oj || b >.
//
// where mi,mj are fixed from mc = ma + mi and md = mb + mj, and the 1/3 factor comes from the 1/hat (k)^2 (k=1 is the rank of Oi and Oj) factor arising from the use of reduced matrix elements.
//
// Consequently, as < c || Oi || a >, < d || Oj || b > are independent of m projections, it is sufficient to store <j m j' -m' |1 -m''> and <1 mi 1 mj | rank mu> Clebsch-Gordan coefficients.
// The phase will be recalculated for each calculation of < c d | [Oi x Oj]^rank_mu | a b >.
// 
// The operator considered in the CM operator is in fact Oi . Oj (scalar product) for rank zero and Oi x Oj (cross product) for rank one. 
// 
// Hence, one has the multiply the TBME of rank zero by -sqrt(3) to go from tensor product to scalar product (it is (-1)^k . hat (k), with k=1 the rank of Oi and Oj).
//
// When the CM operator is L+/-, one has to note that L+/- = Lx +/- i.Ly is not the +1/-1 spherical tensor component of L^(1), it is only proportional to it.
// Consequently, as tensor products [Oi x Oj]^rank_mu arises from the use of the +1/-1 spherical tensors component of L^(1), whereas cross products Oi x Oj arise the use of L+/- = Lx +/- i.Ly,
// one needs to multiply the TBME by -/+ sqrt(2) in this case.
//
// One stores then <1 mi 1 mj | rank mu> multiplied by this coefficient in array, along with the array of <j m j' -m' |1 -m''> Clebsch-Gordan coefficients.

CM_TBMEs_angular_table_str::CM_TBMEs_angular_table_str () : CM_operator_mu (0) , J (0) , m_max_sum (0) {}

CM_TBMEs_angular_table_str::CM_TBMEs_angular_table_str (const enum operator_type CM_operator_inter , const double j_max , const int J_c) : CM_operator_mu (0) , J (0) , m_max_sum (0)
{
  allocate_calc_coupled (CM_operator_inter , j_max , J_c);
}

CM_TBMEs_angular_table_str::CM_TBMEs_angular_table_str (const enum operator_type CM_operator_inter , const double m_max) : CM_operator_mu (0) , J (0) , m_max_sum (0)
{
  allocate_calc_uncoupled (CM_operator_inter , m_max);
}

CM_TBMEs_angular_table_str::CM_TBMEs_angular_table_str (const CM_TBMEs_angular_table_str &X) : CM_operator_mu (0) , J (0) , m_max_sum (0)
{
  allocate_fill (X);
}

CM_TBMEs_angular_table_str::~CM_TBMEs_angular_table_str () {}

void CM_TBMEs_angular_table_str::allocate_calc_coupled (const enum operator_type CM_operator_inter , const double j_max , const int J_c)
{
  if (coupled_TBMEs_angular_table.is_it_filled ()) error_message_print_abort ("CM_TBMEs_angular_table_str cannot be allocated twice in CM_TBMEs_angular_table_str::allocate_calc_coupled");

  J = J_c;
  
  const int CM_operator_rank = Op_rank_determine (CM_operator_inter);

  if (CM_operator_rank != 0) error_message_print_abort ("Scalar operators only when using the J-scheme two-body code in CM_TBMEs_angular_table_str::allocate_calc_coupled");
      
  const int j_number = make_int (j_max + 0.5);
        
  coupled_TBMEs_angular_table.allocate (j_number , j_number , j_number , j_number);
      
  for (int ij0 = 0 ; ij0 < j_number ; ij0++)
    {
      const double j0 = ij0 + 0.5;

      for (int ij1 = 0 ; ij1 < j_number ; ij1++)
	{
	  const double j1 = ij1 + 0.5;

	  for (int ij2 = 0 ; ij2 < j_number ; ij2++)
	    {
	      const double j2 = ij2 + 0.5;

	      for (int ij3 = 0 ; ij3 < j_number ; ij3++)
		{
		  const double j3 = ij3 + 0.5;

		  const int Jmin_in  = abs (ij0 - ij1);
		  const int Jmin_out = abs (ij2 - ij3);

		  const int Jmax_in  = ij0 + ij1 + 1;
		  const int Jmax_out = ij2 + ij3 + 1;
			
		  const int Jmin = max (Jmin_in , Jmin_out);
		  const int Jmax = min (Jmax_in , Jmax_out);

		  coupled_TBMEs_angular_table(ij0 , ij1 , ij2 , ij3) = ((J >= Jmin) && (J <= Jmax)) ? (minus_one_pow (j0 + j3 + J)*Wigner_6j (j2 , j3 , J , j1 , j0 , 1)) : (0.0);
		}
	    }
	}
    }
}

void CM_TBMEs_angular_table_str::allocate_calc_uncoupled (const enum operator_type CM_operator_inter , const double m_max)
{
  if (CM_operator_factor_rank_CG_table.is_it_filled ()) error_message_print_abort ("CM_TBMEs_angular_table_str cannot be allocated twice in CM_TBMEs_angular_table_str::allocate_calc_uncoupled");

  CM_operator_mu = Op_standard_coordinate_determine (CM_operator_inter);
  
  if (is_it_A_dagger_CM_HO_determine (CM_operator_inter)) return;
 
  const int CM_operator_rank = Op_rank_determine (CM_operator_inter);

  const int j_number = make_int (m_max + 0.5);
  
  m_max_sum = make_int (2.0*m_max);
  
  const int m_number = 2*j_number;

  const double tensor_to_scalar_product_constant = (CM_operator_rank == 0) ? (tensor_to_scalar_product_constant_determine (1.0)) : (NADA);
  
  const double spherical_tensor_constant_over_three = 0.3333333333333333*Op_spherical_tensor_constant_determine (CM_operator_inter);

  const double CM_operator_factor = (CM_operator_rank == 0) ? (tensor_to_scalar_product_constant*spherical_tensor_constant_over_three) : (spherical_tensor_constant_over_three);

  CM_operator_factor_rank_CG_table.allocate (3 , 3);
  
  CM_operator_factor_rank_CG_table = 0.0;
  
  CG_table.allocate (j_number , m_number , j_number , m_number);

  CG_table = 0.0;
  
  for (int i_mu = 0 ; i_mu <= 2 ; i_mu++)
    {
      const int mi = i_mu - 1;

      const int mj = CM_operator_mu - mi;

      const int j_mu = mj + 1;

      if ((abs (mi) <= 1) && (abs (mj) <= 1)) CM_operator_factor_rank_CG_table(i_mu , j_mu) = Clebsch_Gordan (1 , mi , 1 , mj , CM_operator_rank , CM_operator_mu);
    }

  CM_operator_factor_rank_CG_table *= CM_operator_factor;

  for (int ij = 0 ; ij < j_number ; ij++)
    {
      const double j = ij + 0.5;

      const int im_min = make_int (-j + m_max);
      const int im_max = make_int ( j + m_max);

      for (int im = im_min ; im <= im_max ; im++)
	{
	  const double m = im - m_max;
		      
	  for (int ijp = 0 ; ijp < j_number ; ijp++)
	    {
	      const int Jmin = abs (ijp - ij);
	      
	      const int Jmax = ijp + ij + 1;
	      	      
	      if (Jmin > 1) continue;
	      if (Jmax < 1) continue;

	      const double jp = ijp + 0.5;

	      const int imp_min = make_int (-jp + m_max);
	      const int imp_max = make_int ( jp + m_max);
	  
	      for (int imp = imp_min ; imp <= imp_max ; imp++)
		{	  
		  const int m_op = imp - im;

		  if (abs (m_op) > 1) continue;
		  
		  const double mp = imp - m_max; 
	  
		  CG_table(ij , im , ijp , imp) = Clebsch_Gordan (j , m , jp , -mp , 1 , -m_op);
		}
	    }
	}
    }
}

void CM_TBMEs_angular_table_str::allocate_fill (const class CM_TBMEs_angular_table_str &X)
{
  if (coupled_TBMEs_angular_table.is_it_filled () || CM_operator_factor_rank_CG_table.is_it_filled ()) error_message_print_abort ("CM_TBMEs_angular_table_str cannot be allocated twice in CM_TBMEs_angular_table_str::allocate_fill");

  CM_operator_mu = X.CM_operator_mu;

  J = X.J;
  
  m_max_sum = X.m_max_sum;

  coupled_TBMEs_angular_table.allocate_fill (X.coupled_TBMEs_angular_table);
    
  CM_operator_factor_rank_CG_table.allocate_fill (X.CM_operator_factor_rank_CG_table);
  
  CG_table.allocate_fill (X.CG_table);
}

void CM_TBMEs_angular_table_str::deallocate ()
{
  coupled_TBMEs_angular_table.deallocate ();
  
  CM_operator_factor_rank_CG_table.deallocate ();
  
  CG_table.deallocate ();
  
  CM_operator_mu = 0;

  J = 0;
  
  m_max_sum = 0;
}






// Calculation of the m-dependent part of < c d | Oi . Oj | a b > or < c d | Oi x Oj | a b > TBME (see above) from stored arrays
// -----------------------------------------------------------------------------------------------------------------------------
// ij and im indices are defined above, as well as class members. The states of indices 0,1,2,3 are a,b,c,d. 
// Other variables are either obvious or similar to those used and explained above.
// One first checks if ma + mb + mu = mc + md, as otherwise the TBME is equal to zero.
// Similarly, one checks if mi = ma - mc and mj = md - mb are equal to -1, 0, 1, as otherwise the TBME is equal to zero.
// ja,jc and jb,jd must be coupled to one (the rank of Oi and Oj), as otherwise the TBME is equal to zero.
// One calculates the phase equal to (-1)^(ja + jb - ma - mb), which will be used to fix the sign of the TBME.
// The angular TBME is then calculated from <1 mi 1 mj | rank mu> multiplied by the tensor coefficient (see above) from a member array, along with <j m j' -m' |1 -m''> from a member array.

double CM_TBMEs_angular_table_str::operator () (
						const int ij0 , const int im0 , 
						const int ij1 , const int im1 , 
						const int ij2 , const int im2 , 
						const int ij3 , const int im3) const
{
  const int im0_plus_im1 = im0 + im1;
  
  if (im0_plus_im1 + CM_operator_mu != im2 + im3) return 0.0;

  const int Jmin_02 = abs (ij0 - ij2);
  const int Jmin_13 = abs (ij1 - ij3);
  
  if (Jmin_02 > 1) return 0.0;
  if (Jmin_13 > 1) return 0.0;
  
  const int Jmax_02 = ij0 + ij2 + 1;
  const int Jmax_13 = ij1 + ij3 + 1;
  
  if (Jmax_02 < 1) return 0.0;
  if (Jmax_13 < 1) return 0.0;
  
  const int Delta_im2 = im2 - im0;
  const int Delta_im3 = im3 - im1;
  
  if (abs (Delta_im2) > 1) return 0.0;
  if (abs (Delta_im3) > 1) return 0.0;
  
  const int m0_plus_m1 = im0_plus_im1 - m_max_sum;

  const int i_mu = Delta_im2 + 1;
  const int j_mu = Delta_im3 + 1;
  
  const double CM_operator_factor_rank_CG = CM_operator_factor_rank_CG_table(i_mu , j_mu);
  
  const double CG_02 = CG_table(ij0 , im0 , ij2 , im2);
  const double CG_13 = CG_table(ij1 , im1 , ij3 , im3);
  
  const double TBME_angular_term_no_phase = CG_02*CG_13*CM_operator_factor_rank_CG;

  const int j0_plus_j1 = ij0 + ij1 + 1;
  
  const int phase = minus_one_pow (j0_plus_j1 - m0_plus_m1);
  
  const double TBME_angular_term = (phase == 1) ? (TBME_angular_term_no_phase) : (-TBME_angular_term_no_phase);

  return TBME_angular_term;
}

double CM_TBMEs_angular_table_str::operator () (const int ij0 , const int ij1 , const int ij2 , const int ij3) const
{
  return coupled_TBMEs_angular_table(ij0 , ij1 , ij2 , ij3);
}





double used_memory_calc (const class CM_TBMEs_angular_table_str &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.coupled_TBMEs_angular_table) + used_memory_calc (T.CM_operator_factor_rank_CG_table) + used_memory_calc (T.CG_table) - (sizeof (T.coupled_TBMEs_angular_table) + sizeof (T.CM_operator_factor_rank_CG_table) + sizeof (T.CG_table))/1000000.0);
}

