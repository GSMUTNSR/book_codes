#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Calculation of the radial array of wave function products times r^2 times a constant factor entering rms radius one-body strength for all one-body states
// ---------------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates here the radial functions <b | \delta (r - r_1) . rms.radius.one.body.factor . r^2 | a > = u_a(r) u_b(r) . r^2 . rms.radius.one.body.factor .

void rms_radius_one_body_strength_OBMEs::OBMEs_shells_calc (
							    const enum operator_type rms_radius_operator ,
							    const double M ,
							    const int N_particle , 
							    const bool is_it_Gauss_Legendre ,
							    const class baryons_data &data , 
							    class array<TYPE> &OBMEs_shells)
{
  const class array<class spherical_state> &shells = data.get_shells ();

  const unsigned int N_nlj = data.get_N_nlj_baryon ();

  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = data.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const class array<double> &effective_masses_for_calc = data.get_effective_masses_for_calc ();

  OBMEs_shells = 0.0;

  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
      {
	const class spherical_state &shell_in = shells(s_in);
	const class spherical_state &shell_out = shells(s_out);

	const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (shell_in.get_r_bef_R_tab_GL ()) : (shell_in.get_r_bef_R_tab_uniform ());

	const class array<complex<double> > &wf_in_bef_R_tab  = (is_it_Gauss_Legendre) ? (shell_in.get_wf_bef_R_tab_GL ())  : (shell_in.get_wf_bef_R_tab_uniform ());
	const class array<complex<double> > &wf_out_bef_R_tab = (is_it_Gauss_Legendre) ? (shell_out.get_wf_bef_R_tab_GL ()) : (shell_out.get_wf_bef_R_tab_uniform ());

	if (same_lj_particle (shell_in , shell_out))
	  {
	    const enum particle_type particle = shell_in.get_particle ();

	    const unsigned int particle_index = charge_baryon_index_determine (particle);
	    
	    const double m = effective_masses_for_calc (particle_index);
  
	    const double factor = rms_radius_one_body_factor_calc (rms_radius_operator , particle , m , M , N_particle);
      
	    for (unsigned int i = 0 ; i < Nr ; i++)
	      {
		const double r = r_bef_R_tab(i);
		
#ifdef TYPEisDOUBLECOMPLEX
		OBMEs_shells(s_in , s_out , i) = factor*wf_in_bef_R_tab(i)*wf_out_bef_R_tab(i)*r*r;
#endif
		
#ifdef TYPEisDOUBLE
		OBMEs_shells(s_in , s_out , i) = factor*real (wf_in_bef_R_tab(i))*real (wf_out_bef_R_tab(i))*r*r;
#endif
	      }
	  }
      }
}








// Calculation of the array of one-body matrix elements of rms radius one-body strength for all one-body states
// ---------------------------------------------------------------------------------------------------
// One calculates here the radial functions <b | \delta (r - r_1) . factor . r^2 | a > = u_a(r) u_b(r) . r^2 . factor entering rms radius one-body strength matrix elements including its angular part.

void rms_radius_one_body_strength_OBMEs::OBMEs_calc (
						     const enum operator_type rms_radius_operator ,
						     const double M , 
						     const int N_particle , 
						     const bool is_it_Gauss_Legendre ,
						     const class baryons_data &data , 
						     class array<TYPE> &OBMEs)
{
  const class array<class nljm_struct> &phi_table = data.get_phi_table ();
  
  const unsigned int N_nlj  = data.get_N_nlj_baryon ();
  const unsigned int N_nljm = data.get_N_nljm_baryon ();

  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = data.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  class array<TYPE> OBMEs_shells(N_nlj , N_nlj , Nr);
  
  OBMEs_shells_calc (rms_radius_operator , M , N_particle , is_it_Gauss_Legendre , data , OBMEs_shells);

  OBMEs = 0.0;
  
  for (unsigned int in = 0 ; in < N_nljm ; in++)
    for (unsigned int out = 0 ; out < N_nljm ; out++)
      {
	const class nljm_struct &phi_in  = phi_table(in);
	const class nljm_struct &phi_out = phi_table(out);

	if (same_Yljm_particle (phi_in , phi_out))
	  {
	    const unsigned int s_in  = phi_in.get_shell_index ();
	    const unsigned int s_out = phi_out.get_shell_index ();
	
	    for (unsigned int i = 0 ; i < Nr ; i++) OBMEs(in , out , i) = OBMEs_shells(s_in , s_out , i);
	  }
      }
}
