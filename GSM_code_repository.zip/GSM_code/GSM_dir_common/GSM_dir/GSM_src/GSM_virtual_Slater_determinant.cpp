#include "../GSM_include/GSM_include_def_common.h"


// TYPE is double or complex
// -------------------------

// class virtual Slater determinant containing information about the occupied shells in a Slater determinant for protons or neutrons
// ---------------------------------------------------------------------------------------------------------------------------------
// A virtual Slater determinant only contains the table of integers T where all Slater determinant states are listed and a start index i, so that T(i) ... T(i+5) = 0 1 3 4 5 7 if the Slater determinant has 6 nucleons and 0 1 3 4 5 7 for state indices.
// T is the only object containing stored Slater determinants in the SD_set structure of nucleons_data (see GSM_nucleons_data.h and GSM_array_of_SD.h).
// The interest of a virtual class is that it is automatically copied to a Slater determinant class with a constructor or operator = (see GSM_Slater_determinant.cpp).
// The virtual Slater determinant of the table of integers T can be modified with a statement of the type SD_set(BP, n_scat, iC, iM, SD_index) = SD, with SD a class Slater_determinant.
// See GSM_Slater_determinant.cpp for details about the Slater determinant class.
// T is table and i is index in the class.

virtual_Slater_determinant::virtual_Slater_determinant (
							const class array<unsigned short int> &table_c ,
							const unsigned int index_c) :
  table (table_c) ,
  index (index_c)
{}


virtual_Slater_determinant::~virtual_Slater_determinant () {}


const class virtual_Slater_determinant & virtual_Slater_determinant::operator = (const class Slater_determinant &X) 
{
  const unsigned int N_valence_nucleons = get_N_valence_nucleons ();  

  class virtual_Slater_determinant &SD = *this;

  for (unsigned int i = 0 ; i < N_valence_nucleons ; i++) SD[i] = X[i];

  return *this;
}


