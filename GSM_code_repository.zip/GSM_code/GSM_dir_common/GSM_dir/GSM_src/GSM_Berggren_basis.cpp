#include "../GSM_include/GSM_include_def_common.h"


using namespace string_routines;
using namespace inputs_misc;

extern enum called_code_type called_code;

// TYPE is double or complex
// -------------------------

// Equivalent potentials as splines
// --------------------------------
// One has the equivalent potential without the infinite range Coulomb part Ueq_finite_range_tab_uniform(n , l , j , i[radial]) and the source term source_tab_uniform(n , l , j , i[radial]).
// The non-local potential U(r,r') applied a wave function is written Ueq(r).u(r) + S(r), where Ueq(r) is the equivalent potential and S(r) the source.
// Ueq(r) = [1 - F(r)] \int U(r,r') u(r') dr' / u(r) and S(r) = F(r) \int U(r,r') u(r') dr', with F(r) a regularizing factor preventing from Ueq(r) to diverge if u(r) = 0, which is numerically non-zero only close to the zeroes of u(r).
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
//                  Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
//                  The ratio |u(r)|^2/|u'(r)|^2 prevents F(r) to be non zero when r -> +oo.
//                  Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
// The equivalent potential and source are then allocated, calculated and stored as splines in the class potentials_effective_mass.

void Berggren_basis::HF_potentials_effective_mass_Ueq_source_tabs_alloc_calc (
									      const double R , 
									      const double step_bef_R_uniform ,
									      const enum potential_type H_potential , 
									      const enum particle_type particle , 
									      const int Z_charge_basis_potential , 
									      const double R_charge , 
									      const int n , 
									      const int l , 
									      const double j , 
									      const class nlj_table<complex<double> > &Ueq_finite_range_tab_uniform , 
									      const class nlj_table<complex<double> > &source_tab_uniform , 
									      class potentials_effective_mass &T)
{
  const unsigned int N_bef_R_uniform = Ueq_finite_range_tab_uniform.dimension (0);
  
  class array<complex<double> > potential_tab(N_bef_R_uniform);
  
  class array<complex<double> > source_potential_tab(N_bef_R_uniform);

  const class Coulomb_potential_class Coulomb_potential(false , particle , Z_charge_basis_potential , NADA);
  
  const double dV_R = Coulomb_potential.point_potential_derivative_calc (R);

  const unsigned int zero_index_uniform = Ueq_finite_range_tab_uniform.index_determine (n , l , j , 0);

  class array<double> r_tab(N_bef_R_uniform);

  class array<double> V_Coulomb_tab(N_bef_R_uniform);

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_tab(i) = i*step_bef_R_uniform ;

  Coulomb_potential::local_potential_calc (false , H_potential , particle , Z_charge_basis_potential , R_charge , r_tab , V_Coulomb_tab);

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
    {
      const unsigned int i_total_uniform = zero_index_uniform + i;

      potential_tab(i) = Ueq_finite_range_tab_uniform[i_total_uniform] + V_Coulomb_tab(i);
      
      source_potential_tab(i) = source_tab_uniform[i_total_uniform];
    }

  class splines_class<complex<double> > &trivially_equivalent_potential = T.get_trivially_equivalent_potential ();
  
  class splines_class<complex<double> > &source = T.get_source ();

  trivially_equivalent_potential.deallocate ();
  source.deallocate ();

  trivially_equivalent_potential.allocate_calc (r_tab , potential_tab , 0.0 , dV_R);
  source.allocate_calc (r_tab , source_potential_tab , 0.0 , 0.0);
}






// Calculation of a one-body wave function of the Berggren basis for proton or neutron and fixed n, l, j
// -----------------------------------------------------------------------------------------------------
// The state is calculated by the node if its shell index belongs to the interval [first_index : last_index] or if it is an S-matrix pole.
// It is a HO state, it is calculated analytically.
// With the Qbox potential or if one considers a natural orbital, the wave function is read from a file. 
// Otherwise, according the basis potential one uses (KKNN, WS, WS-analytic, HF/MSDHF, where WS+OCM is included),
// one allocates the associated class or one splines the HF/MSDHF potential (see above).
// The integration constants such as C0 or C+ are taken from the nlj_struct shell_qn for non-local Hamiltonians or put to 1 to be recalculated afterwards for local Hamiltonians.
// The class spherical_state is allocated here before being calculated.
// Otherwise, one looks for its linear momentum with k_search (see spherical_state.cpp) if it is a S-matrix pole, or one calculates it directly from its linear momentum with k.
// If one has a scattering proton, in the latter case, the shells with k +/- w/(4 Pi), with w the Gauss-Legendre weight of the considered shell,
// are calculated to be able to use the off-diagonal method for matrix elements of the Coulomb infinite range.
// The nlj_struct shell_qn is then updated with the obtained values.
//
// Berggren basis states are tested if they are real for the real energy code and the code stops if they are not.
// Natural orbitals are supposed calculated from real states if the real energy code is used. No test is made.
//
// Wave functions are calculated in momentum space for momentum density.
// One uses a Fermi function centered in R_Fermi as the Fermi-Bessel transform is not defined otherwise (see spherical_state.cpp).

void Berggren_basis::wave_function_calculation (
						const bool is_there_cout , 
						const class input_data_str &input_data ,
						const class nucleons_data &neut_data_like , 
						const unsigned int shell_index , 
						class nucleons_data &particles_data)
{
  const bool only_dimensions = input_data.get_only_dimensions ();

  const bool non_zero_NBMEs_proportion_only = input_data.get_non_zero_NBMEs_proportion_only ();
  
  const enum space_type basis_space = input_data.get_basis_space ();
    
  const enum potential_type H_potential = particles_data.get_H_potential ();

  const bool neutron_basis_potential = particles_data.get_neutron_basis_potential ();
    
  const enum interaction_type TBME_inter = input_data.get_inter ();

  const class lj_table<double> &b_lab_partial_waves = particles_data.get_b_partial_waves ();

  const unsigned int N_bef_R_GL = particles_data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = particles_data.get_N_aft_R_GL ();
  
  const unsigned int N_bef_R_uniform = particles_data.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = particles_data.get_N_aft_R_uniform ();
  
  const unsigned int Nk_momentum_GL  = particles_data.get_Nk_momentum_GL ();
  const unsigned int Nk_momentum_uniform = particles_data.get_Nk_momentum_uniform ();
  
  const double R = particles_data.get_R ();

  const double step_bef_R_uniform = particles_data.get_step_bef_R_uniform ();
  
  const double R_real_max = particles_data.get_R_real_max ();
  
  const double kmax_momentum = particles_data.get_kmax_momentum ();

  const double R_Fermi_momentum = particles_data.get_R_Fermi_momentum ();
  
  const double R_charge = particles_data.get_R_charge ();

  class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  class nlj_struct &shell_qn = shells_qn(shell_index);

  const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

  const bool is_it_HO = shell_qn.get_is_it_HO ();

  const bool core_state = shell_qn.get_core_state ();

  const bool frozen_state = shell_qn.get_frozen_state ();

  const bool hole_state = shell_qn.get_hole_state ();

  const bool is_it_for_HF_gs = shell_qn.get_is_it_for_HF_gs ();

  const bool OCM_valence_state = shell_qn.get_OCM_valence_state ();

  const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ();

  const int n = shell_qn.get_n ();
  const int l = shell_qn.get_l ();

  const double j = shell_qn.get_j ();
  
  const int e_trunc = shell_qn.get_e_trunc ();

  const double b_lab_expansion = input_data.get_b_lab ();
  
  const double b_lab_shell = b_lab_partial_waves(l , j);

  const enum particle_type particle = particles_data.get_particle ();

  const int A_basis = particles_data.get_A_basis ();
  
  const int Z_charge_basis_potential = particles_data.get_Z_charge_basis_potential ();
  
  const class nucleons_data &data_for_potential = (neutron_basis_potential && (basis_space != PROTONS_ONLY)) ? (neut_data_like) : (particles_data);

  const class array<double> &d_core_potential_tab   = particles_data.get_d_core_potential_tab ();
  const class array<double> &R0_core_potential_tab  = particles_data.get_R0_core_potential_tab ();
  const class array<double> &Vo_core_potential_tab  = particles_data.get_Vo_core_potential_tab ();
  const class array<double> &Vso_core_potential_tab = particles_data.get_Vso_core_potential_tab ();

  const class array<double> &d_basis_tab   = particles_data.get_d_basis_tab ();
  const class array<double> &R0_basis_tab  = particles_data.get_R0_basis_tab ();
  const class array<double> &Vo_basis_tab  = particles_data.get_Vo_basis_tab ();
  const class array<double> &Vso_basis_tab = particles_data.get_Vso_basis_tab ();

  const double d   = (core_state) ? (d_core_potential_tab(l))   : (d_basis_tab(l));
  const double R0  = (core_state) ? (R0_core_potential_tab(l))  : (R0_basis_tab(l));
  const double Vo  = (core_state) ? (Vo_core_potential_tab(l))  : (Vo_basis_tab(l));
  const double Vso = (core_state) ? (Vso_core_potential_tab(l)) : (Vso_basis_tab(l));

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);
  
  const double R0_inter = input_data.get_R0_inter_basis ();
  
  const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);

  const double V0_KKNN[5] = {data_for_potential.get_V0_KKNN(0) , data_for_potential.get_V0_KKNN(1) , data_for_potential.get_V0_KKNN(2) , data_for_potential.get_V0_KKNN(3) , data_for_potential.get_V0_KKNN(4)};

  const double rho_KKNN[5] = {data_for_potential.get_rho_KKNN(0) , data_for_potential.get_rho_KKNN(1) , data_for_potential.get_rho_KKNN(2) , data_for_potential.get_rho_KKNN(3) , data_for_potential.get_rho_KKNN(4)};

  const double Vls_KKNN[3] = {data_for_potential.get_Vls_KKNN(0) , data_for_potential.get_Vls_KKNN(1) , data_for_potential.get_Vls_KKNN(2)};

  const double rho_ls_KKNN[3] = {data_for_potential.get_rho_ls_KKNN(0) , data_for_potential.get_rho_ls_KKNN(1) , data_for_potential.get_rho_ls_KKNN(2)};

  const double nucleon_mass_for_calc = data_for_potential.get_effective_mass_for_calc ();
  
  const double nucleus_mass_basis = particles_data.get_nucleus_mass_basis ();

  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);
  
  const double mass_modif_for_recoil = (!is_it_COSM) ? (-nucleus_mass_basis) : (nucleus_mass_basis);

  const double mass_modif = (A_basis >= 2) ? (mass_modif_for_recoil) : (0.0);

  const class lj_table<enum potential_type> &basis_potential_partial_waves = particles_data.get_basis_potential_partial_waves ();
  
  const enum potential_type basis_potential_if_it_exists = (is_it_natural_orbital) ? (NO_POTENTIAL) : (basis_potential_partial_waves(l , j));
  
  const enum potential_type basis_potential_init_no_HO = (core_state) ? (H_potential) : (basis_potential_if_it_exists);

  const enum potential_type basis_potential_init = (is_it_HO) ? (HO_POTENTIAL) : (basis_potential_init_no_HO);

  const complex<double> k = shell_qn.get_k ();
  const complex<double> k_plus = shell_qn.get_k_plus ();
  const complex<double> k_minus = shell_qn.get_k_minus ();

  const bool are_core_basis_potentials_equal_wf = are_core_basis_potentials_equal (l , particles_data);
  
  const enum potential_type basis_potential = (OCM_valence_state && !are_core_basis_potentials_equal_wf && !is_it_HO) ? (HF) : (basis_potential_init);
  
  const bool are_shells_plus_minus_calculated = (!S_matrix_pole && !is_it_HO && !is_it_natural_orbital && (basis_potential != QBOX_POTENTIAL) && (particle == PROTON));

  const string debut_file_name = particles_data.get_debut_file_name () + "_basis_state_";

  class array<spherical_state> &shells       = particles_data.get_shells ();
  class array<spherical_state> &shells_plus  = particles_data.get_shells_plus ();
  class array<spherical_state> &shells_minus = particles_data.get_shells_minus ();

  const bool is_basis_potential_local = ((basis_potential != HF) && (basis_potential != MSDHF));
  
  const bool is_there_starting_point = (S_matrix_pole && !is_it_natural_orbital && (core_state || is_basis_potential_local));

  const bool are_there_scaled_wfs = !is_it_natural_orbital;

  const complex<double> w = shell_qn.get_w ();
  
  const complex<double> sqrt_w = sqrt (w);
  
  const complex<double> C0       = (!is_basis_potential_local) ? (shell_qn.get_C0 ())       : (1.0);
  const complex<double> C0_plus  = (!is_basis_potential_local) ? (shell_qn.get_C0_plus ())  : (1.0);
  const complex<double> C0_minus = (!is_basis_potential_local) ? (shell_qn.get_C0_minus ()) : (1.0);
  const complex<double> Cplus    = (!is_basis_potential_local) ? (shell_qn.get_Cplus ())    : (1.0);

  const enum segment_type segment = shell_qn.get_segment ();

  class spherical_state &shell       = shells(shell_index);
  class spherical_state &shell_plus  = shells_plus(shell_index);
  class spherical_state &shell_minus = shells_minus(shell_index);

  shell.allocate (false , are_there_scaled_wfs , basis_potential , A_basis , Z_charge_basis_potential , mass_modif , NADA ,
		  N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , Nk_momentum_GL , Nk_momentum_uniform , R , NADA , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum ,
		  S_matrix_pole , particle , n , NADA , l , j , is_there_starting_point , k , nucleon_mass_for_calc , C0 , Cplus); 

  if (are_shells_plus_minus_calculated)
    {
      shell_plus.allocate (false , are_there_scaled_wfs , basis_potential , A_basis , Z_charge_basis_potential , mass_modif , NADA ,
			   N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , Nk_momentum_GL , Nk_momentum_uniform , R , NADA , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum ,
			   S_matrix_pole , particle , n , NADA , l , j , false , k_plus , nucleon_mass_for_calc , C0_plus , NADA); 

      shell_minus.allocate (false , are_there_scaled_wfs , basis_potential , A_basis , Z_charge_basis_potential , mass_modif , NADA ,
			    N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , Nk_momentum_GL , Nk_momentum_uniform , R , NADA , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum ,
			    S_matrix_pole , particle , n , NADA , l , j , false , k_minus , nucleon_mass_for_calc , C0_minus , NADA); 
    }

  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const unsigned int first_index = basic_first_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_index  = basic_last_index_determine_for_MPI  (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  if ((S_matrix_pole && !is_it_natural_orbital) || ((shell_index >= first_index) && (shell_index <= last_index)))
    {
      if (!only_dimensions && !non_zero_NBMEs_proportion_only)
	{
	  if (basis_potential == HO_POTENTIAL)
	    shell.HO_wave_function (b_lab_shell);
	  else if (is_it_natural_orbital)
	    shell.get_from_file_no_scaled_wfs (debut_file_name);
	  else if (basis_potential == QBOX_POTENTIAL)
	    {
	      shell.Qbox_wf_calc_from_file (STORAGE_DIR);

	      if (kmax_momentum > 0) shell.wave_calculation_momentum (b_lab_expansion);
	  
	      const complex<double> new_C0 = shell.get_C0 ();
      
	      const complex<double> new_Cplus = shell.get_Cplus ();
	
	      const complex<double> new_k = shell.get_k ();
	
	      shell_qn.initialize (S_matrix_pole , core_state , frozen_state , hole_state , OCM_valence_state , is_it_HO , is_it_for_HF_gs , is_it_natural_orbital ,
				   e_trunc , n , l , j , segment , new_k , NADA , new_C0 , new_Cplus , NADA , C0_plus , NADA , C0_minus);
	    }     
	  else
	    {
	      class potentials_effective_mass T;
	  
	      T.initialize_constants (
				      shell.get_potential () ,
				      shell.get_kinetic_factor () ,
				      shell.get_jr () ,
				      shell.get_l () ,
				      shell.get_Z_charge () ,
				      shell.get_j () ,
				      shell.get_k () ,
				      shell.get_eta () ,
				      NADA);

	      switch (basis_potential)
		{
		case KKNN:
		  {
		    class KKNN_class &KKNN_potential = T.get_KKNN_potential ();

		    KKNN_potential.initialize (false , V0_KKNN , rho_KKNN , Vls_KKNN , rho_ls_KKNN , particle , Z_charge_basis_potential , R_charge , l , j);
		  } break;

		case WS:
		  {
		    class WS_class &WS_potential = T.get_WS_potential ();

		    WS_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge_basis_potential , R_charge , l , j);
		  } break;

		case WS_ANALYTIC:
		  {
		    class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();

		    WS_analytic_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge_basis_potential , R_charge , l , j);
		  } break;

		default: 
		  {
		    const class nlj_table<complex<double> > &Ueq_finite_range_tab_uniform = particles_data.get_Ueq_finite_range_tab_uniform ();
		
		    const class nlj_table<complex<double> > &source_tab_uniform = particles_data.get_source_tab_uniform ();

		    HF_potentials_effective_mass_Ueq_source_tabs_alloc_calc (R , step_bef_R_uniform , H_potential , particle , Z_charge_basis_potential ,
									     R_charge , n , l , j , Ueq_finite_range_tab_uniform , source_tab_uniform , T);
		  } break;
		}

	      if (S_matrix_pole) 
		{	      
		  shell.k_search (T , true , is_there_cout);

		  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << endl;
		}

	      shell.wave_calculation (is_there_cout , T , true);
	  
	      if (S_matrix_pole && (THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << endl;

	      if (kmax_momentum > 0) shell.wave_calculation_momentum (b_lab_expansion);
	  
	      if (!S_matrix_pole) shell.normalization (sqrt_w);
	  
	      if (are_shells_plus_minus_calculated) 
		{
		  if (!is_basis_potential_local)
		    {
		      const class nlj_table<complex<double> > &Ueq_finite_range_plus_tab_uniform  = particles_data.get_Ueq_finite_range_plus_tab_uniform ();
		      const class nlj_table<complex<double> > &Ueq_finite_range_minus_tab_uniform = particles_data.get_Ueq_finite_range_minus_tab_uniform ();

		      const class nlj_table<complex<double> > &source_plus_tab_uniform  = particles_data.get_source_plus_tab_uniform ();		  
		      const class nlj_table<complex<double> > &source_minus_tab_uniform = particles_data.get_source_minus_tab_uniform ();

		      HF_potentials_effective_mass_Ueq_source_tabs_alloc_calc (R , step_bef_R_uniform , H_potential , particle , Z_charge_basis_potential ,
									       R_charge , n , l , j , Ueq_finite_range_plus_tab_uniform  , source_plus_tab_uniform , T);
		  
		      HF_potentials_effective_mass_Ueq_source_tabs_alloc_calc (R , step_bef_R_uniform , H_potential , particle , Z_charge_basis_potential ,
									       R_charge , n , l , j , Ueq_finite_range_minus_tab_uniform , source_minus_tab_uniform , T);
		    }

		  shell_plus.wave_calculation (is_there_cout , T , true);

		  if (kmax_momentum > 0) shell_plus.wave_calculation_momentum (b_lab_expansion);

		  shell_plus.normalization (sqrt_w);

		  shell_minus.wave_calculation (is_there_cout , T , true);

		  if (kmax_momentum > 0) shell_minus.wave_calculation_momentum (b_lab_expansion);

		  shell_minus.normalization (sqrt_w);
		}
	    }

	  const complex<double> new_C0 = shell.get_C0 ();
      
	  const complex<double> new_Cplus = shell.get_Cplus ();

	  const complex<double> new_k = shell.get_k ();
      
#ifdef TYPEisDOUBLE 

	  // Complex-energy states are forbidden in the real-energy code. This is tested here, as TYPE is double in this case.
      
	  if (!frozen_state && !is_it_natural_orbital && !is_it_HO)
	    {
	      const string shell_string = make_string<enum particle_type> (particle) + " " + make_string<class nlj_struct> (shell_qn);
      
	      if (S_matrix_pole && (real (new_k) != 0.0))
		error_message_print_abort (shell_string + " is an unbound resonant state: k=" + make_string<complex<double> > (new_k) + ". Forbidden with the real energy code.");
	  
	      if (!S_matrix_pole && (imag (new_k) != 0.0))
		error_message_print_abort (shell_string + " is a complex scattering state: k=" + make_string<complex<double> > (new_k) + ". Forbidden using the real energy code.");
	    }
      
#endif
	  
	  shell_qn.initialize (S_matrix_pole , core_state , frozen_state , hole_state , OCM_valence_state , is_it_HO , is_it_for_HF_gs , is_it_natural_orbital ,
			       e_trunc , n , l , j , segment , new_k , w , new_C0 , new_Cplus , k_plus , C0_plus , k_minus , C0_minus);
	}
      else
	shell_qn.initialize (S_matrix_pole , core_state , frozen_state , hole_state , OCM_valence_state , is_it_HO , is_it_for_HF_gs , is_it_natural_orbital ,
			     e_trunc , n , l , j , segment , k , w , C0 , Cplus , k_plus , C0_plus , k_minus , C0_minus);

    }
}







// Print on screen of OCM overlaps
// -------------------------------
// Master process only.
// If an |n0 l j> belongs to the core, all shells |n l j> of the valence space must be orthogonal to it.
// The overlaps <n0 l j | n l j > are then calculated here with complex scaling.
// Their maximal value, average, and dispersion are printed on screen.

void Berggren_basis::print_overlaps_OCM (const class nucleons_data &particles_data)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in Berggren_basis::print_overlaps_OCM.");

  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  const class array<class spherical_state> &shells = particles_data.get_shells ();

  double max_infinite_norm_overlap = 0.0;

  double infinite_norm_overlap_sum = 0.0;
  
  double infinite_norm_overlap_squares_sum = 0.0;
  
  unsigned int N = 0;
  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_qn(s);

      const bool core_state = shell_qn.get_core_state ();

      if (core_state)
	{
	  const class spherical_state &wf_core = shells(s);

	  const int n_core = wf_core.get_n ();

	  for (unsigned int t = 0 ; t < N_nlj ; t++)
	    {
	      const class spherical_state &wfp = shells(t);

	      const class nlj_struct &shell_qn_p = shells_qn(t);

	      const bool core_state_p = shell_qn_p.get_core_state ();
	      
	      const bool is_it_natural_orbital_p = shell_qn_p.get_is_it_natural_orbital ();

	      const int np = wfp.get_n ();
	      
	      if (same_lj (wfp , wf_core) && (np != n_core) && !core_state_p && !is_it_natural_orbital_p)
		{
		  const double infinite_norm_overlap = inf_norm (complex_scaling_radial_OBMEs::radial_integral_calc (OVERLAP , NADA , NADA , wf_core , wfp));
		  
		  max_infinite_norm_overlap = max (infinite_norm_overlap , max_infinite_norm_overlap);
		  
		  infinite_norm_overlap_sum += infinite_norm_overlap;

		  infinite_norm_overlap_squares_sum += infinite_norm_overlap*infinite_norm_overlap;

		  N++;
		}
	    }
	}
    }

  if (N >= 1)
    {
      const double infinite_norm_overlap_average = infinite_norm_overlap_sum/N;

      const double infinite_norm_overlap_sigma = statistical_sigma_calc (N , infinite_norm_overlap_sum , infinite_norm_overlap_squares_sum);

      cout << endl << endl;

      cout << "Maximal       |OCM overlap|oo:" << max_infinite_norm_overlap << endl;
      cout << "Average       |OCM overlap|oo:" << infinite_norm_overlap_average << endl; 
      cout << "Dispersion of |OCM overlap|oo:" << infinite_norm_overlap_sigma << endl << endl; 
    }
}









// Print on screen of overlaps
// ---------------------------
// Master process only.
// All shells |n l j> of the valence space must be orthogonal to each other.
// The overlaps <n l j | n' l j > are then calculated here with complex scaling, along with <u_n(r) l j | u_n'(r) l j >, which must vanish as well.
// Their maximal value, average, and dispersion are printed on screen.

void Berggren_basis::print_overlaps (const class nucleons_data &particles_data)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in Berggren_basis::print_overlaps.");

  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class array<class spherical_state> &shells = particles_data.get_shells ();

  unsigned int N = 0;
  unsigned int N_der = 0;

  double max_infinite_norm_overlap     = 0.0 , infinite_norm_overlap_sum     = 0.0 , infinite_norm_overlap_squares_sum     = 0.0;
  double max_infinite_norm_overlap_der = 0.0 , infinite_norm_overlap_sum_der = 0.0 , infinite_norm_overlap_squares_sum_der = 0.0;

  for (unsigned int in = 0 ; in < N_nlj ; in++)
    for (unsigned int out = 0 ; out <= in ; out++)
      {
	const class nlj_struct &shell_qn_in = shells_qn(in);
	const class nlj_struct &shell_qn_out = shells_qn(out);

	const bool is_it_HO_in = shell_qn_in.get_is_it_HO ();
	const bool is_it_HO_out = shell_qn_out.get_is_it_HO ();

	const bool core_state_in = shell_qn_in.get_core_state ();
	const bool core_state_out = shell_qn_out.get_core_state ();
	
	const bool is_it_natural_orbital_in = shell_qn_in.get_is_it_natural_orbital ();
	const bool is_it_natural_orbital_out = shell_qn_out.get_is_it_natural_orbital ();

	if (!is_it_HO_in && !is_it_HO_out && !core_state_in && !core_state_out && !is_it_natural_orbital_in && !is_it_natural_orbital_out && same_lj (shell_qn_in , shell_qn_out))
	  {
	    const bool S_matrix_pole_in = shell_qn_in.get_S_matrix_pole ();
	    
	    const int n_in = shell_qn_in.get_n ();
	    const int n_out = shell_qn_out.get_n ();

	    const class spherical_state &wf_in = shells(in);
	    const class spherical_state &wf_out = shells(out);

	    const double infinite_norm_overlap = (out != in) ? (inf_norm (complex_scaling_radial_OBMEs::radial_integral_calc (OVERLAP , NADA , NADA , wf_in , wf_out))) : (NADA);
	    
	    const double infinite_norm_overlap_der = (S_matrix_pole_in || (n_in != n_out)) ? (inf_norm (complex_scaling_radial_OBMEs::radial_integral_calc (OVERLAP_WF_DWF , NADA , NADA , wf_in , wf_out))) : (0.0);

	    if (out != in)
	      {
		max_infinite_norm_overlap = max (infinite_norm_overlap , max_infinite_norm_overlap);

		infinite_norm_overlap_sum += infinite_norm_overlap;

		infinite_norm_overlap_squares_sum += infinite_norm_overlap*infinite_norm_overlap;
		
		N++;
	      }
		
	    max_infinite_norm_overlap_der = max (infinite_norm_overlap_der , max_infinite_norm_overlap_der);

	    infinite_norm_overlap_sum_der += infinite_norm_overlap_der;

	    infinite_norm_overlap_squares_sum_der += infinite_norm_overlap_der*infinite_norm_overlap_der;
	    
	    N_der++;
	  }
      }

  if (N >= 1)
    {
      const double infinite_norm_overlap_average = infinite_norm_overlap_sum/N;

      const double infinite_norm_overlap_sigma = statistical_sigma_calc (N , infinite_norm_overlap_sum , infinite_norm_overlap_squares_sum);  

      cout << endl << endl;
      
      cout << "Maximal       |overlap|oo:" << max_infinite_norm_overlap << endl;
      cout << "Average       |overlap|oo:" << infinite_norm_overlap_average << endl; 
      cout << "Dispersion of |overlap|oo:" << infinite_norm_overlap_sigma << endl << endl;
    }

  if (N_der >= 1)
    {
      const double infinite_norm_overlap_average_der = infinite_norm_overlap_sum_der/N_der;

      const double infinite_norm_overlap_sigma_der = statistical_sigma_calc (N_der , infinite_norm_overlap_sum_der , infinite_norm_overlap_squares_sum_der);
      
      if (N == 0) cout << endl << endl;
      
      cout << "Maximal       |overlap(wf , wf')|oo:" << max_infinite_norm_overlap_der << endl; 
      cout << "Average       |overlap(wf , wf')|oo:" << infinite_norm_overlap_average_der << endl;
      cout << "Dispersion of |overlap(wf , wf')|oo:" << infinite_norm_overlap_sigma_der << endl;
    }
}








// Calculation and MPI distribution of one-body Berggren basis states
// ------------------------------------------------------------------
// All radial wave functions are allocated and calculated here, as well as their integration constants C0 and C+/- .
// One radial wave function and its integration constants C0 and C+/- are calculated in wave_function_calculation (see above).
// Radial wave functions are distributed to all nodes afterwards, as nodes do not calculate all wave functions for efficiency, but must have all of them for the calculation of matrix elements.
// Poles and scattering states linear momenta and overlaps are printed on screen if is_there_cout is true.
// The time needed to calculate wave functions is also written on screen if is_there_cout is true.
//
// The overlaps between one-body states are calculated and printed as they should very small, as it they are equal to zero theoretically.
// They are not written when the Qbox potential is used as complex scaling cannot be used therein.
// As they arise fro a calculation bases on orthogonal transformations, they are orthogonal in practice.

void Berggren_basis::radial_wfs_overlaps_print_alloc_calc (
							   const bool is_there_cout , 
							   const class input_data_str &input_data ,
							   const class nucleons_data &neut_data_like , 
							   class nucleons_data &particles_data)
{
  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);

  const bool only_dimensions = input_data.get_only_dimensions ();

  const bool non_zero_NBMEs_proportion_only = input_data.get_non_zero_NBMEs_proportion_only ();
  
  const enum interaction_type TBME_inter = input_data.get_inter ();

  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);

  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const unsigned int N_nlj_minus_one = N_nlj - 1;
  
  for (unsigned int s = 0 ; s < N_nlj ; s++) wave_function_calculation (is_there_cout , input_data , neut_data_like , s , particles_data);

  class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  class array<spherical_state> &shells = particles_data.get_shells ();
  
#ifdef UseMPI

  if (is_it_MPI_parallelized)
    {
      const class lj_table<enum potential_type> &basis_potential_partial_waves = particles_data.get_basis_potential_partial_waves ();

      const enum particle_type particle = particles_data.get_particle ();
      
      class array<class spherical_state> &shells_plus = particles_data.get_shells_plus ();
      class array<class spherical_state> &shells_minus = particles_data.get_shells_minus ();

      for (unsigned int s = 0 ; s < N_nlj ; s++)
	{	  
	  class nlj_struct &shell_qn = shells_qn(s);

	  const int l = shell_qn.get_l ();

	  const double j = shell_qn.get_j ();

	  const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

	  const bool is_it_HO = shell_qn.get_is_it_HO ();
	  
	  const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ();

	  const enum potential_type basis_potential = basis_potential_partial_waves(l , j);
  
	  const bool are_shells_plus_minus_calculated = (!S_matrix_pole && !is_it_HO && !is_it_natural_orbital && (basis_potential != QBOX_POTENTIAL) && (particle == PROTON));

	  if (!S_matrix_pole || is_it_natural_orbital) 
	    {
	      const unsigned int sending_process = basic_active_process_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , s);

	      class spherical_state &shell = shells(s);
	      shell.MPI_Bcast (sending_process , MPI_COMM_WORLD);

	      if (are_shells_plus_minus_calculated)
		{
		  class spherical_state &shell_plus = shells_plus(s);
		  class spherical_state &shell_minus = shells_minus(s);

		  shell_plus.MPI_Bcast (sending_process , MPI_COMM_WORLD);
		  shell_minus.MPI_Bcast (sending_process , MPI_COMM_WORLD);
		}

	      complex<double> new_k = shell_qn.get_k ();

	      MPI_helper::Bcast<complex<double> > (new_k , sending_process , MPI_COMM_WORLD);

	      shell_qn.initialize (shell_qn.get_S_matrix_pole () , 
				   shell_qn.get_core_state () , 
				   shell_qn.get_frozen_state () , 
				   shell_qn.get_hole_state () , 
				   shell_qn.get_OCM_valence_state () ,		   
				   shell_qn.get_is_it_HO () , 
				   shell_qn.get_is_it_for_HF_gs () , 
				   shell_qn.get_is_it_natural_orbital () ,
				   shell_qn.get_e_trunc () , 
				   shell_qn.get_n () , 
				   shell_qn.get_l () , 
				   shell_qn.get_j () , 
				   shell_qn.get_segment () , 
				   new_k , 
				   shell_qn.get_w () ,
				   shell_qn.get_C0 () , 
				   shell_qn.get_Cplus () , 
				   shell_qn.get_k_plus () , 
				   shell_qn.get_C0_plus () , 
				   shell_qn.get_k_minus () , 
				   shell_qn.get_C0_minus ());
	    }
	}
    }
#endif
	  	  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    { 
      for (unsigned int s = 0 ; s < N_nlj ; s++) 
	{
	  const class spherical_state &shell = shells(s);

	  const class nlj_struct &shell_qn = shells_qn(s);
	  
	  const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

	  const bool is_it_HO = shell_qn.get_is_it_HO ();

	  const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ();
	  
	  if (!S_matrix_pole && !is_it_HO && !is_it_natural_orbital)
	    {
	      const complex<double> k = shell.get_k ();

	      const complex<double> E_tilde = shell.get_E ();

	      const double E = real (E_tilde);

	      const double Gamma = -2000.0*imag (E_tilde);

	      cout << shell << " k:" << k << " fm^{-1} E:" << E << " MeV" << " G:" << Gamma << " keV" << endl;

	      if (s < N_nlj_minus_one)
		{
		  const class spherical_state &shell_after = shells(s + 1);

		  if (!same_lj (shell , shell_after)) cout << endl;
		}	      
	    }
	}
    }
  
  const enum potential_type basis_potential = particles_data.get_basis_potential ();

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout && !only_dimensions && !non_zero_NBMEs_proportion_only && (basis_potential != QBOX_POTENTIAL))
    {
      const enum particle_type particle = particles_data.get_particle ();

      print_overlaps (particles_data);

      if (is_it_COSM) print_overlaps_OCM (particles_data);

      const double now = absolute_time_determine () , relative_time = now - reference_time; 

      cout << endl << particle << " basis states read/calculated. time:" << relative_time << " s" << endl << endl;
    }
}









// Allocation, calculation and MPI distribution of one-body Berggren basis states
// ------------------------------------------------------------------------------
// Arrays of class spherical_states are allocated here and their content allocated, calculated and distributed to all nodes in radial_wfs_overlaps_print_alloc_calc.

void Berggren_basis::single_particle_indices_radial_wfs_alloc_calc (
								    const bool is_there_cout , 
								    const class input_data_str &input_data ,
								    const class nucleons_data &neut_data_like ,
								    class nucleons_data &particles_data)
{
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const enum particle_type particle = particles_data.get_particle ();

      cout << endl << "Berggren basis " << particle << endl;
      cout <<         "----------------------" << endl << endl;
    }  

  const unsigned int N_nlj = particles_data.get_N_nlj ();

  class array<class spherical_state> &shells       = particles_data.get_shells ();
  class array<class spherical_state> &shells_plus  = particles_data.get_shells_plus ();
  class array<class spherical_state> &shells_minus = particles_data.get_shells_minus ();

  shells.allocate (N_nlj);
  shells_plus.allocate (N_nlj);
  shells_minus.allocate (N_nlj);

  //--// the u_nlj (r , ... , k) are calculated here
  //--// give the Cplus and Cminus

  radial_wfs_overlaps_print_alloc_calc (is_there_cout , input_data , neut_data_like , particles_data);
}







// Allocation, calculation and MPI distribution of one-body Berggren basis states for proton and neutron cases
// -----------------------------------------------------------------------------------------------------------
// Routines to allocate, calculate and distribute wave function arrays and wave functions are called here for both proton and neutron cases.
// The total time spent to calculate all wave functions is printed in this routine as well.

void Berggren_basis::single_particle_indices_radial_wfs_prot_neut_alloc_calc (
									      const bool is_there_cout , 
									      const class input_data_str &input_data ,
									      class nucleons_data &prot_data , 
									      class nucleons_data &neut_data)
{
  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);

  const enum space_type basis_space = input_data.get_basis_space ();

  const enum space_type space = input_data.get_space ();

  const class nucleons_data &neut_data_like = (basis_space == PROTONS_ONLY) ? (prot_data) : (neut_data);

  if (space != NEUTRONS_ONLY) Berggren_basis::single_particle_indices_radial_wfs_alloc_calc (is_there_cout , input_data , neut_data_like , prot_data);
  if (space != PROTONS_ONLY)  Berggren_basis::single_particle_indices_radial_wfs_alloc_calc (is_there_cout , input_data , neut_data_like , neut_data);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time;
      
      cout << endl << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;
      cout         << "Berggren basis calculated and built. time:" << relative_time << " s" << endl;
      cout         << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl << endl;
    }
}











// Best HO length for all S-matrix poles
// -------------------------------------
// Master process only.
// One finds the best HO length b for which the HO state |n_HO l j> has the largest overlap with the S-matrix pole |n l j> for all poles.
// One only considers the real part of resonant states as HO states are always real. This will be omitted in the comments for simplicity.
// No HO length is considered if the S-matrix pole |n l j> is already a HO state.
// One starts with b = 0.9 fm, an unphysical value, and it is increased by 0.1 fm step by step to go in the region of physical values.
// Once a maximum of |<n_HO l j|n l j>| has been localized with these b's, i.e. one knows its value up to 0.1 fm from the sequential search,
// the Newton method is used on F(b) = d/db (<n_HO(b) l j|n l j>) with the b found previously as a starting point.
// As |n_HO l j> is analytical, its derivatives with respect to b are straightforward to calculate using u_n_HO(1 fm , r/b) instead of u_n_HO(b,r).
// |<n_HO l j|n l j>|, the best b and its hbar omega value are printed on screen.

void Berggren_basis::best_hbar_omega_b_lab_print (
						  const enum interaction_type inter ,
						  const class nucleons_data &data)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in Berggren_basis::best_hbar_omega_b_lab_print.");

  const unsigned int N_nlj_res = data.get_N_nlj_res ();
  
  if (N_nlj_res == 0) return;

  const enum particle_type particle = data.get_particle ();

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  const class array<class spherical_state> &shells = data.get_shells ();

  const double b_step = 0.1;

  for (unsigned int s = 0 ; s < N_nlj_res ; s++)
    {
      const class nlj_struct &shell_qn = shells_qn(s);
      
      const bool is_it_HO = shell_qn.get_is_it_HO ();

      if (!is_it_HO)
	{
	  const class spherical_state &wf = shells(s);

	  const unsigned int N_bef_R_GL = wf.get_N_bef_R_GL ();
	  const unsigned int N_aft_R_GL = wf.get_N_aft_R_GL ();

	  const int n = wf.get_n ();
	  const int l = wf.get_l ();
	  
	  const class array<double> &r_bef_R_tab_GL = wf.get_r_bef_R_tab_GL ();
	  const class array<double> &w_bef_R_tab_GL = wf.get_w_bef_R_tab_GL ();

	  const class array<double> &r_aft_R_tab_GL = wf.get_r_aft_R_tab_GL_real ();
	  const class array<double> &w_aft_R_tab_GL = wf.get_w_aft_R_tab_GL_real ();
	  
	  const class array<complex<double> > &wf_bef_R_tab_GL = wf.get_wf_bef_R_tab_GL ();
	  const class array<complex<double> > &wf_aft_R_tab_GL = wf.get_wf_aft_R_tab_GL_real ();

	  class array<double> wf_w_bef_R_tab(N_bef_R_GL);
	  class array<double> wf_w_aft_R_tab(N_bef_R_GL);

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) wf_w_bef_R_tab(i) = real (wf_bef_R_tab_GL(i))*w_bef_R_tab_GL(i);
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) wf_w_aft_R_tab(i) = real (wf_aft_R_tab_GL(i))*w_aft_R_tab_GL(i);

	  double b_bef = 0.8 , b = b_bef + b_step , b_aft = b;

	  double overlap_bef = 0.0 , overlap = 0.0 , overlap_aft = 0.0;
  
	  double test = 1.0;
	  
	  bool is_b_localized = false;
	  
	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	    {
	      const double wf_w = wf_w_bef_R_tab(i);
	      
	      overlap_bef += wf_w*HO_wave_functions::HO_3D::u (b_bef , n , l , r_bef_R_tab_GL(i));
	      overlap     += wf_w*HO_wave_functions::HO_3D::u (b     , n , l , r_bef_R_tab_GL(i));
      
	      overlap_bef = abs (overlap_bef);
	      overlap     = abs (overlap);  
	    }

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	    {
	      const double wf_w = wf_w_aft_R_tab(i);
	      
	      overlap_bef += wf_w*HO_wave_functions::HO_3D::u (b_bef , n , l , r_aft_R_tab_GL(i));
	      overlap     += wf_w*HO_wave_functions::HO_3D::u (b     , n , l , r_aft_R_tab_GL(i));
      
	      overlap_bef = abs (overlap_bef);
	      overlap     = abs (overlap);  
	    }

	  while (!is_b_localized)
	    {
	      b_aft += b_step;
      
	      overlap_aft = 0.0;
      
	      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) overlap_aft += wf_w_bef_R_tab(i)*HO_wave_functions::HO_3D::u (b_aft , n , l , r_bef_R_tab_GL(i));
	      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) overlap_aft += wf_w_aft_R_tab(i)*HO_wave_functions::HO_3D::u (b_aft , n , l , r_aft_R_tab_GL(i));
      
	      overlap_aft = abs (overlap_aft);
      
	      is_b_localized = ((overlap > overlap_bef) && (overlap > overlap_aft));
      
	      if (!is_b_localized)
		{
		  overlap_bef = overlap;
		  overlap     = overlap_aft;
	  
		  b_bef = b;		  
		  b     = b_aft;
		}
	    }
  
	  while (test > precision)
	    {	
	      double overlap_der = 0.0;
	      double overlap_2der = 0.0;

	      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
		{
		  const double r = r_bef_R_tab_GL(i);
	  
		  const double r_over_b = r/b;
	  
		  const double wf_w = wf_w_bef_R_tab(i);
	  
		  const double u_HO_r_over_b   = HO_wave_functions::HO_3D::u   (1.0 , n , l , r_over_b);
		  const double du_HO_r_over_b  = HO_wave_functions::HO_3D::du  (1.0 , n , l , r_over_b);
		  const double d2u_HO_r_over_b = HO_wave_functions::HO_3D::d2u (1.0 , n , l , r_over_b);
	  
		  overlap_der -= wf_w*(0.5*u_HO_r_over_b + du_HO_r_over_b*r_over_b)*pow (b , -1.5);
		  
		  overlap_2der += wf_w*(0.75*u_HO_r_over_b + (3.0*du_HO_r_over_b + d2u_HO_r_over_b*r_over_b)*r_over_b)*pow (b , -2.5);
		}

	      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
		{
		  const double r = r_aft_R_tab_GL(i);
	  
		  const double r_over_b = r/b;
	  
		  const double wf_w = wf_w_aft_R_tab(i);
	  
		  const double u_HO_r_over_b   = HO_wave_functions::HO_3D::u   (1.0 , n , l , r_over_b);
		  const double du_HO_r_over_b  = HO_wave_functions::HO_3D::du  (1.0 , n , l , r_over_b);
		  const double d2u_HO_r_over_b = HO_wave_functions::HO_3D::d2u (1.0 , n , l , r_over_b);
	  
		  overlap_der -= wf_w*(0.5*u_HO_r_over_b + du_HO_r_over_b*r_over_b)*pow (b , -1.5);
		  
		  overlap_2der += wf_w*(0.75*u_HO_r_over_b + (3.0*du_HO_r_over_b + d2u_HO_r_over_b*r_over_b)*r_over_b)*pow (b , -2.5);
		}

	      const double db = overlap_der/overlap_2der;
      
	      b -= db;
	      
	      test = abs (db);
	    }

	  overlap = 0.0;
  
	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) overlap += wf_w_bef_R_tab(i)*HO_wave_functions::HO_3D::u (b , n , l , r_bef_R_tab_GL(i));
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) overlap += wf_w_aft_R_tab(i)*HO_wave_functions::HO_3D::u (b , n , l , r_aft_R_tab_GL(i));
	  
	  overlap = abs (overlap);  

	  const int A = data.get_A ();
  
	  const bool is_it_COSM = is_it_COSM_determine (inter);
	  
	  const double nucleon_mass_for_calc = data.get_effective_mass_for_calc ();
	  const double nucleus_mass = data.get_nucleus_mass ();
	  
	  const double mass_modif_for_recoil = (!is_it_COSM) ? (-nucleus_mass) : (nucleus_mass);

	  const double mass_modif = (A >= 2) ? (mass_modif_for_recoil) : (0.0);

	  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , mass_modif , nucleon_mass_for_calc , b);
	  
	  cout << particle << " " << wf << " best hw: " << hbar_omega << " MeV , best b: " << b << " fm overlap:" << overlap << endl;
	}
    }
}



