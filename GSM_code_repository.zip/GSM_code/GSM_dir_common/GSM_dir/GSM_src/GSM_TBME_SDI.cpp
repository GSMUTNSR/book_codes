#include "../GSM_include/GSM_include_def_common.h"

using namespace Wigner_signs;



// TYPE is double or complex
// -------------------------

// TBME is for two-body matrix element
// -----------------------------------

// SDI is for Surface Delta Interaction
// ------------------------------------




// Calculation of the radial one-body matrix element of the SDI interaction
// ------------------------------------------------------------------------
// It is <wf0 wf1 | SDI(radial) | wf2 wf3> = wf0(R0) wf1(R0) wf2(R0) wf3(R0)/R0^2, with R0 the radius of the SDI interaction.

TYPE TBME_SDI_set::SDI_radial_TBME (
				    const double R0 , 
				    const class spherical_state &wf0 , 
				    const class spherical_state &wf1 , 
				    const class spherical_state &wf2 , 
				    const class spherical_state &wf3)
{
  const complex<double> radial_integral = wf0.get_wf_R0 ()*wf1.get_wf_R0 ()*wf2.get_wf_R0 ()*wf3.get_wf_R0 ()/(R0*R0);
  
#ifdef TYPEisDOUBLECOMPLEX  
  return radial_integral;
#endif
  
#ifdef TYPEisDOUBLE
  return real (radial_integral);
#endif
}








// Calculation of the antisymmetrized SDI TBME coupled to J and T, and coupled to J only for protons only, neutrons only and protons neutrons 
// ------------------------------------------------------------------------------------------------------------------------------------------
// One has:< s2 s3 | SDI | s0 s1 >_JT = hat (ja) . hat (jb) . hat (jc) . hat (jc) 
//                                . (a + b . (-1)^T) . 
//                                . ((-1)^(jd + jb + ld + lb) . (1 - (-1)^(J + T + lc + ld))/2 . 3j(ja,jb,1/2,-1/2,0) . 3j(jc,jd,1/2,-1/2,0) - (1 + (-1)^T)/2 . 3j(ja,jb,1/2,1/2,-1) . 3j(jc,jd,1/2,1/2,-1))
//                                . 1/sqrt (1 + delta_s0_s1) . 1/sqrt (1 + delta_s2_s3) . 1/4Pi
//                                . <wf0 wf1 | SDI(radial) | wf2 wf3>
//
// The angular part of < s2 s3 | SDI | s0 s1 >_JT is calculated in TBME_JT_angular_antisymmetrized.
// The TBME < s2 s3 | SDI | s0 s1 >_J coupled to J only for protons only, neutrons only and protons neutrons is calculated in TBME_J_pp_nn and TBME_J_pn.

double TBME_SDI_set::TBME_JT_angular_antisymmetrized (
						      const int J , 
						      const int T , 
						      const class interaction_class &inter_data , 
						      const class spherical_state &wf0 , 
						      const class spherical_state &wf1 , 
						      const class spherical_state &wf2 , 
						      const class spherical_state &wf3)
{ 
  const int l1 = wf1.get_l (); 
  const int l2 = wf2.get_l (); 
  const int l3 = wf3.get_l (); 
 
  const double j0 = wf0.get_j (); 
  const double j1 = wf1.get_j (); 
  const double j2 = wf2.get_j (); 
  const double j3 = wf3.get_j ();

  const int phase_jl = minus_one_pow (j3 + j1 + l3 + l1);
  
  const int JT_term = (1 - minus_one_pow (J + T + l2 + l3))/2;
  
  const int T_term = (1 + minus_one_pow (T))/2;
  
  const double antisymmetry_norm_in  = (same_nlj (wf0 , wf1)) ? (M_SQRT1_2) : (1.0);
  const double antisymmetry_norm_out = (same_nlj (wf2 , wf3)) ? (M_SQRT1_2) : (1.0);
  
  const double antisymmetry_norm = antisymmetry_norm_in*antisymmetry_norm_out;

  const double hats = hat (j0)*hat (j1)*hat (j2)*hat (j3);
  
  const double a = inter_data.get_a ();
  const double b = inter_data.get_b ();

  const double a_bPsigma = a + b*minus_one_pow (T);
  
  const double Wig_3j_product_0 = Wigner_3j (j0 , j1 , J , 0.5 , -0.5 ,  0.0)*Wigner_3j (j2 , j3 , J , 0.5 , -0.5 ,  0.0);
  const double Wig_3j_product_1 = Wigner_3j (j0 , j1 , J , 0.5 ,  0.5 , -1.0)*Wigner_3j (j2 , j3 , J , 0.5 ,  0.5 , -1.0);

  const double one_over_four_Pi = 0.07957747154594766788;
  
  const double coupled_angular_TBME_factor = phase_jl*JT_term*Wig_3j_product_0 - T_term*Wig_3j_product_1;

  const double coupled_angular_TBME = hats*a_bPsigma*coupled_angular_TBME_factor*antisymmetry_norm*one_over_four_Pi;

  return coupled_angular_TBME;
}

// Calculation of the non-antisymmetrized HO TBME coupled to J of recoil
// ---------------------------------------------------------------------
// The TBME < s2 s3 | pi.pj (hbar^2 / M) | s0 s1 >_J is that of the kinetic Hamiltonian coming from recoil in COSM, i.e. \sum_{i<j} pi.pj/M_core .
// It is coupled to J but not antisymmetrized.
// It is equal to zero if s0 and s2 have same parity, so that one first checks this case and zero is returned then.
// One uses the Wigner Eckhart theorem for scalar operators (see Wigner_signs.cpp) to calculate pi.pj TBMEs.
// There is a minus sign in the returned value as p = -i.hbar.grad .

TYPE TBME_SDI_set::TBME_pi_pj_J (
				 const int J , 
				 const class array<TYPE> &reduced_grad_02_tab , 
				 const class array<TYPE> &reduced_grad_13_tab , 
				 const unsigned int s0 , 
				 const unsigned int s1 , 
				 const unsigned int s2 , 
				 const unsigned int s3 , 
				 const class spherical_state &wf0 , 
				 const class spherical_state &wf1 , 
				 const class spherical_state &wf2 , 
				 const class spherical_state &wf3)
{
  const int l0 = wf0.get_l ();
  const int l2 = wf2.get_l ();
  
  if ((l0 + l2)%2 == 0) return 0.0;

  const TYPE reduced_grad_02 = reduced_grad_02_tab(s0 , s2);
  const TYPE reduced_grad_13 = reduced_grad_13_tab(s1 , s3);

  const double j0 = wf0.get_j ();
  const double j1 = wf1.get_j ();
  const double j2 = wf2.get_j ();
  const double j3 = wf3.get_j ();
  
  const TYPE TBME = -Oa_scalar_Ob_ME_calc (1 , j0 , j1 , J , j2 , j3 , J , reduced_grad_02 , reduced_grad_13);

  return TBME;
}



TYPE TBME_SDI_set::TBME_J_pp_nn_antisymmetrized (
						 const bool is_there_recoil , 
						 const int J , 
						 const class interaction_class &inter_data , 
						 const unsigned int s0 , 
						 const unsigned int s1 , 
						 const unsigned int s2 , 
						 const unsigned int s3 , 
						 const class array<TYPE> &reduced_grad_tab , 
						 const class array<class spherical_state> &shells)
{
  const class spherical_state &wf0 = shells(s0);
  const class spherical_state &wf1 = shells(s1);
  const class spherical_state &wf2 = shells(s2);
  const class spherical_state &wf3 = shells(s3);

  const int T = 1;

  if ((same_nlj (wf2 , wf3)) && ((J + T)%2 == 0)) return 0.0;
  if ((same_nlj (wf0 , wf1)) && ((J + T)%2 == 0)) return 0.0;

  const double R0 = inter_data.get_R0 ();

  const double V_SDI = inter_data.get_V_SDI ();

  const double angular_part = TBME_JT_angular_antisymmetrized (J , T , inter_data , wf0 , wf1 , wf2 , wf3);
  
  const TYPE radial_part = SDI_radial_TBME (R0 , wf0 , wf1 , wf2 , wf3);
  
  TYPE TBME = angular_part*radial_part*V_SDI;

  if (is_there_recoil)
    {
      const double j0 = wf0.get_j (); 
      const double j1 = wf1.get_j ();
  
      TBME += TBME_pi_pj_J (J , reduced_grad_tab , reduced_grad_tab , s0 , s1 , s2 , s3 , wf0 , wf1 , wf2 , wf3);
      
      TBME -= minus_one_pow (j0 + j1 - J)*TBME_pi_pj_J (J , reduced_grad_tab , reduced_grad_tab , s1 , s0 , s2 , s3 , wf1 , wf0 , wf2 , wf3);
    }
  
  return TBME;
}

TYPE TBME_SDI_set::TBME_J_pn (
			      const bool is_there_recoil , 
			      const int J , 
			      const class interaction_class &inter_data , 
			      const unsigned int s0 , 
			      const unsigned int s1 , 
			      const unsigned int s2 , 
			      const unsigned int s3 , 
			      const class array<TYPE> &reduced_grad_prot_tab , 
			      const class array<TYPE> &reduced_grad_neut_tab , 
			      const class array<class spherical_state> &shells_prot , 
			      const class array<class spherical_state> &shells_neut)
{
  const class spherical_state &wf0 = shells_prot(s0);
  const class spherical_state &wf1 = shells_neut(s1);
  const class spherical_state &wf2 = shells_prot(s2);
  const class spherical_state &wf3 = shells_neut(s3);

  const double antisymmetrized_norm_in  = (same_nlj (wf0 , wf1)) ? (M_SQRT2) : (1.0);
  const double antisymmetrized_norm_out = (same_nlj (wf2 , wf3)) ? (M_SQRT2) : (1.0);

  const double antisymmetrized_product = antisymmetrized_norm_in*antisymmetrized_norm_out;

  const double angular_part_T0 = TBME_JT_angular_antisymmetrized (J , 0 , inter_data , wf0 , wf1 , wf2 , wf3);
  const double angular_part_T1 = TBME_JT_angular_antisymmetrized (J , 1 , inter_data , wf0 , wf1 , wf2 , wf3);
  
  const double R0 = inter_data.get_R0 ();

  const double V_SDI = inter_data.get_V_SDI ();

  const double angular_part = 0.5*(angular_part_T0 + angular_part_T1)*antisymmetrized_product;
  
  const TYPE radial_part = SDI_radial_TBME (R0 , wf0 , wf1 , wf2 , wf3);

  TYPE TBME = angular_part*radial_part*V_SDI;

  if (is_there_recoil) TBME += TBME_pi_pj_J (J , reduced_grad_prot_tab , reduced_grad_neut_tab , s0 , s1 , s2 , s3 , wf0 , wf1 , wf2 , wf3);

  return TBME;
}


