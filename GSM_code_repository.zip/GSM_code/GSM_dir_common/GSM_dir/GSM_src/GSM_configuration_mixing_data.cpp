#include "../GSM_include/GSM_include_def_common.h"

using namespace GSM_vector_dimensions;
using namespace inputs_misc;

// TYPE is double or complex
// -------------------------

// Structure containing data related to the calculation of the amount of configuration mixing of a GSM vector
// ----------------------------------------------------------------------------------------------------------
// A GSM vector has many basis configurations, whose probabilities differ. The quantum numbers defining a fixed configuration and its probability in the GSM vector are stored here.
// This routine is used to order configurations with respect to their probability. They are printed on screen afterwards.

configuration_mixing_data::configuration_mixing_data () : 
  BPp (0) ,
  iCp (0) , 
  iCn (0) ,
  iC (0) ,
  n_scat_p (0) ,
  n_scat_n (0) ,
  n_scat (0) ,
  probability (0.0)
{}

configuration_mixing_data::configuration_mixing_data (
						      const unsigned int BPp_c , 
						      const unsigned int iCp_c , 
						      const unsigned int iCn_c , 
						      const int n_scat_p_c , 
						      const int n_scat_n_c , 
						      const unsigned int iC_c , 
						      const int n_scat_c , 
						      const TYPE probability_c)
{
  initialize (BPp_c , iCp_c , iCn_c , n_scat_p_c , n_scat_n_c , iC_c , n_scat_c , probability_c);
}

configuration_mixing_data::configuration_mixing_data (const configuration_mixing_data &X)
{
  initialize (X);
}

void configuration_mixing_data::initialize (
					    const unsigned int BPp_c , 
					    const unsigned int iCp_c , 
					    const unsigned int iCn_c , 
					    const int n_scat_p_c , 
					    const int n_scat_n_c , 
					    const unsigned int iC_c , 
					    const int n_scat_c , 
					    const TYPE probability_c)
{
  BPp = BPp_c; 

  iCp = iCp_c; 
  iCn = iCn_c; 

  n_scat_p = n_scat_p_c; 
  n_scat_n = n_scat_n_c; 

  iC = iC_c; 

  n_scat = n_scat_c; 

  probability = probability_c;
}

void configuration_mixing_data::initialize (const configuration_mixing_data &X)
{
  BPp = X.BPp; 

  iCp = X.iCp; 
  iCn = X.iCn; 

  n_scat_p = X.n_scat_p; 
  n_scat_n = X.n_scat_n; 

  iC = X.iC; 

  n_scat = X.n_scat; 

  probability = X.probability;
}

void configuration_mixing_data::operator = (const configuration_mixing_data &X)
{
  BPp = X.BPp; 

  iCp = X.iCp; 
  iCn = X.iCn; 

  n_scat_p = X.n_scat_p; 
  n_scat_n = X.n_scat_n; 

  iC = X.iC; 

  n_scat = X.n_scat; 

  probability = X.probability;
}





// Print of average number of protons/neutrons in all valence shells
// -----------------------------------------------------------------

void shell_occupations_print_pp_nn (
				    const class nucleons_data &particles_data ,
				    const unsigned int BP , 
				    const bool are_scattering_configuration_probabilities_printed ,
				    const class array<class configuration_mixing_data> &configuration_mixing_tab)
{  
  const enum particle_type particle = particles_data.get_particle ();
  
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const unsigned int dimension = configuration_mixing_tab.dimension (0); 

  const unsigned int dimension_minus_one = dimension - 1;

  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class array_of_configuration &configuration_set = particles_data.get_configuration_set ();

  class configuration C(N_valence_nucleons);

  cout << endl << particle << " shell occupations" << endl;
  
  cout << "------------------------------" << endl << endl;
  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {  
      const class nlj_struct &shell_qn = shells_qn(s);

      const bool frozen_state = shell_qn.get_frozen_state ();

      if (frozen_state) continue;
      
      const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

      if (!are_scattering_configuration_probabilities_printed && !S_matrix_pole) continue;
      
      TYPE s_occupation = 0;
      
      for (unsigned int i = dimension_minus_one ; i < dimension ; i--)
	{
	  const class configuration_mixing_data &configuration_mixing = configuration_mixing_tab(i);
      	  
	  const int n_scat = configuration_mixing.get_n_scat ();
      
	  const unsigned int iC = configuration_mixing.get_iC ();
      
	  C = configuration_set(BP , n_scat , iC);
	  
	  const TYPE probability = configuration_mixing.get_probability ();

	  const int s_occupancy = C.occupancy_determine (s);
	
	  if (s_occupancy > 0) s_occupation += s_occupancy*probability;
	}
      
      if (inf_norm (s_occupation) > precision) cout << particle << " " << shell_qn << " occupation : " << s_occupation << endl;
    }
}



void shell_occupations_print_pn (
				 const class nucleons_data &particles_data ,
				 const unsigned int BP ,
				 const bool are_scattering_configuration_probabilities_printed ,
				 const class array<class configuration_mixing_data> &configuration_mixing_tab)
{  
  const enum particle_type particle = particles_data.get_particle ();
  
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const unsigned int dimension = configuration_mixing_tab.dimension (0); 

  const unsigned int dimension_minus_one = dimension - 1;

  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class array_of_configuration &configuration_set = particles_data.get_configuration_set ();

  class configuration C(N_valence_nucleons);

  cout << endl << particle << " shell occupations" << endl;
  
  cout << "------------------------------" << endl << endl;
  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {  
      const class nlj_struct &shell_qn = shells_qn(s);

      const bool frozen_state = shell_qn.get_frozen_state ();

      if (frozen_state) continue;
      
      const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

      if (!are_scattering_configuration_probabilities_printed && !S_matrix_pole) continue;
      
      TYPE s_occupation = 0;
      
      for (unsigned int i = dimension_minus_one ; i < dimension ; i--)
	{
	  const class configuration_mixing_data &configuration_mixing = configuration_mixing_tab(i);
      
	  const unsigned int BPp = configuration_mixing.get_BPp ();

	  const unsigned int BP_pp_nn = (particle == PROTON) ? (BPp) : (binary_parity_product (BPp , BP));
	  
	  const int n_scat_pp_nn = (particle == PROTON) ? (configuration_mixing.get_n_scat_p ()) : (configuration_mixing.get_n_scat_n ());
      
	  const unsigned int iC_pp_nn = (particle == PROTON) ? (configuration_mixing.get_iCp ()) : (configuration_mixing.get_iCn ());
      
	  C = configuration_set(BP_pp_nn , n_scat_pp_nn , iC_pp_nn);
	  
	  const TYPE probability = configuration_mixing.get_probability ();

	  const int s_occupancy = C.occupancy_determine (s);
	
	  if (s_occupancy > 0) s_occupation += s_occupancy*probability;
	}
      
      if (inf_norm (s_occupation) > precision) cout << particle << " " << shell_qn << " occupation : " << s_occupation << endl;
    }
}




// Print of average number of protons/neutrons in all partial waves
// -----------------------------------------------------------------

void partial_wave_occupations_print_pp_nn (
					   const bool is_it_scat_only ,
					   const class nucleons_data &particles_data ,
					   const unsigned int BP , 
					   const class array<class configuration_mixing_data> &configuration_mixing_tab)
{  
  const enum particle_type particle = particles_data.get_particle ();
  
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const unsigned int dimension = configuration_mixing_tab.dimension (0); 

  const unsigned int dimension_minus_one = dimension - 1;
  
  const int lmax = particles_data.get_lmax ();

  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class array_of_configuration &configuration_set = particles_data.get_configuration_set ();
	
  class configuration C(N_valence_nucleons);

  if (is_it_scat_only)
    {
      if (!is_there_scat_determine (particles_data)) return;
      
      cout << endl << particle << " partial wave scattering occupations" << endl;
    }
  else
    cout << endl << particle << " partial wave occupations" << endl;

  cout <<         "------------------------------------------------" << endl << endl;

  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	TYPE partial_wave_occupation = 0;
	    
	for (unsigned int s = 0 ; s < N_nlj ; s++)
	  {  
	    const class nlj_struct &shell_qn = shells_qn(s);

	    const bool frozen_state_s = shell_qn.get_frozen_state ();

	    if (frozen_state_s) continue;
      
	    const bool S_matrix_pole_s = shell_qn.get_S_matrix_pole ();

	    if (is_it_scat_only && S_matrix_pole_s) continue;
	    
	    const int ls = shell_qn.get_l ();
	          
	    if (ls != l) continue;
	    
	    const double js = shell_qn.get_j ();
	    
	    if (rint (js - j) != 0.0) continue;
      
	    for (unsigned int i = dimension_minus_one ; i < dimension ; i--)
	      {
		const class configuration_mixing_data &configuration_mixing = configuration_mixing_tab(i);
      	  
		const int n_scat = configuration_mixing.get_n_scat ();
      
		const unsigned int iC = configuration_mixing.get_iC ();
      
		C = configuration_set(BP , n_scat , iC);
	  
		const TYPE probability = configuration_mixing.get_probability ();

		const int s_occupancy = C.occupancy_determine (s);
	  
		if (s_occupancy > 0) partial_wave_occupation += s_occupancy*probability;
	      }
	  }
	
	if (inf_norm (partial_wave_occupation) > precision)
	  {
	    if (is_it_scat_only)
	      cout << "Scattering " << particle << " " << angular_state (l , j) << " occupation : " << partial_wave_occupation << endl;
	    else
	      cout << particle << " " << angular_state (l , j) << " occupation : " << partial_wave_occupation << endl;
	  }
      }
}




void partial_wave_occupations_print_pn (
					const bool is_it_scat_only ,
					const class nucleons_data &particles_data ,
					const unsigned int BP ,
					const class array<class configuration_mixing_data> &configuration_mixing_tab)
{  
  const enum particle_type particle = particles_data.get_particle ();
  
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const unsigned int dimension = configuration_mixing_tab.dimension (0); 

  const unsigned int dimension_minus_one = dimension - 1;
  
  const int lmax = particles_data.get_lmax ();

  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class array_of_configuration &configuration_set = particles_data.get_configuration_set ();

  class configuration C(N_valence_nucleons);

  if (is_it_scat_only)
    {
      if (!is_there_scat_determine (particles_data)) return;
      
      cout << endl << particle << " partial wave scattering occupations" << endl;
    }
  else
    cout << endl << particle << " partial wave occupations" << endl;

  cout <<         "------------------------------------------------" << endl << endl;

  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	TYPE partial_wave_occupation = 0;
	    
	for (unsigned int s = 0 ; s < N_nlj ; s++)
	  {  
	    const class nlj_struct &shell_qn = shells_qn(s);

	    const bool frozen_state_s = shell_qn.get_frozen_state ();

	    if (frozen_state_s) continue;
      
	    const bool S_matrix_pole_s = shell_qn.get_S_matrix_pole ();

	    if (is_it_scat_only && S_matrix_pole_s) continue;
	    
	    const int ls = shell_qn.get_l ();
	          
	    if (ls != l) continue;
	    
	    const double js = shell_qn.get_j ();
	    
	    if (rint (js - j) != 0.0) continue;
      
	    for (unsigned int i = dimension_minus_one ; i < dimension ; i--)
	      {
		const class configuration_mixing_data &configuration_mixing = configuration_mixing_tab(i);
      
		const unsigned int BPp = configuration_mixing.get_BPp ();

		const unsigned int BP_pp_nn = (particle == PROTON) ? (BPp) : (binary_parity_product (BPp , BP));
	  
		const int n_scat_pp_nn = (particle == PROTON) ? (configuration_mixing.get_n_scat_p ()) : (configuration_mixing.get_n_scat_n ());
      
		const unsigned int iC_pp_nn = (particle == PROTON) ? (configuration_mixing.get_iCp ()) : (configuration_mixing.get_iCn ());
      
		C = configuration_set(BP_pp_nn , n_scat_pp_nn , iC_pp_nn);
	  
		const TYPE probability = configuration_mixing.get_probability ();

		const int s_occupancy = C.occupancy_determine (s);
	  
		if (s_occupancy > 0) partial_wave_occupation += s_occupancy*probability;
	      }
	  }
	
	if (inf_norm (partial_wave_occupation) > precision)
	  {
	    if (is_it_scat_only)
	      cout << "Scattering " << particle << " " << angular_state (l , j) << " occupation : " << partial_wave_occupation << endl;
	    else
	      cout << particle << " " << angular_state (l , j) << " occupation : " << partial_wave_occupation << endl;
	  }
      }
}











void configuration_mixing_tab_sort (
				    const int low , 
				    const int high , 
				    class array<class configuration_mixing_data> &configuration_mixing_tab)
{
  const int pivot_index = low + (high - low)/2;

  const double pivot_inf_norm_probability = inf_norm (configuration_mixing_tab(pivot_index).get_probability ());

  int i_sort = low;
  int j_sort = high;

  do
    {
      double inf_norm_probability_i_sort = inf_norm (configuration_mixing_tab(i_sort).get_probability ());
      
      while ((inf_norm_probability_i_sort < pivot_inf_norm_probability) && (inf_norm (inf_norm_probability_i_sort - pivot_inf_norm_probability) > precision))
	inf_norm_probability_i_sort = inf_norm (configuration_mixing_tab(++i_sort).get_probability ());

      double inf_norm_probability_j_sort = inf_norm (configuration_mixing_tab(j_sort).get_probability ());

      while ((inf_norm_probability_j_sort > pivot_inf_norm_probability) && (inf_norm (inf_norm_probability_j_sort - pivot_inf_norm_probability) > precision))
	inf_norm_probability_j_sort = inf_norm (configuration_mixing_tab(--j_sort).get_probability ());

      if (i_sort <= j_sort)
	{
	  swap (configuration_mixing_tab(i_sort) , configuration_mixing_tab(j_sort));

	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort)  configuration_mixing_tab_sort (low    , j_sort , configuration_mixing_tab);
  if (i_sort < high) configuration_mixing_tab_sort (i_sort , high   , configuration_mixing_tab); 
}

unsigned int configuration_mixing_tab_dimension_pp_nn_calc (
							    const unsigned int BP ,
							    const double M ,
							    const enum space_type space ,  
							    const bool truncation_hw ,
							    const bool truncation_ph ,
							    const int n_holes_max ,
							    const int n_scat_max ,
							    const int E_max_hw ,
							    const class nucleons_data &prot_data ,
							    const class nucleons_data &neut_data)
{


  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);

  const int N_valence_nucleons = data.get_N_valence_nucleons ();
  
  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_BP_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
 
  const class array_BP_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  class configuration C(N_valence_nucleons);
  
  unsigned int dimension = 0;  

  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int dimension_configuration_set_BP_n_scat = dimensions_configuration_set(BP , n_scat);

      unsigned int sub_dimension = 0;

      for (unsigned int iC = 0 ; iC < dimension_configuration_set_BP_n_scat ; iC++)
	{
	  const int n_holes = n_holes_table(BP , n_scat , iC);
	  
	  const int E_hw = E_hw_table(BP , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  C = configuration_set(BP , n_scat , iC);
	  
	  const double M_max_C = C.M_max_determine (shells_qn);

	  if (M <= M_max_C) sub_dimension++;
	}

      dimension += sub_dimension;
    }

  return dimension;
}



unsigned int configuration_mixing_tab_dimension_pn_calc (
							 const unsigned int BP ,
							 const double M ,
							 const bool truncation_hw ,
							 const bool truncation_ph ,
							 const int n_holes_max_p ,
							 const int n_holes_max_n ,
							 const int n_holes_max ,
							 const int n_scat_max_p ,
							 const int n_scat_max_n ,
							 const int n_scat_max ,
							 const int Ep_max_hw ,
							 const int En_max_hw ,
							 const int E_max_hw ,
							 const class nucleons_data &prot_data ,
							 const class nucleons_data &neut_data)
{
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();
  
  const class array<unsigned int> &dimensions_configuration_set_p = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_set_n = neut_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_set_p = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_set_n = neut_data.get_configuration_set ();
  
  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();

  class configuration Cp(Zval);
  class configuration Cn(Nval);
  
  unsigned int dimension = 0;

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP);
      
      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int dimension_configuration_set_BP_n_scat_p = dimensions_configuration_set_p(BPp , n_scat_p);

	  unsigned int sub_dimension = 0;

	  for (unsigned int iCp = 0 ; iCp < dimension_configuration_set_BP_n_scat_p ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);
	      
	      const int Ep_hw = Ep_hw_table(BPp , n_scat_p , iCp);

	      Cp = configuration_set_p(BPp , n_scat_p , iCp);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	  
	      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
		{
		  const unsigned int dimension_configuration_set_BP_n_scat_n = dimensions_configuration_set_n(BPn , n_scat_n);

		  for (unsigned int iCn = 0 ; iCn < dimension_configuration_set_BP_n_scat_n ; iCn++)
		    {
		      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
		      const int En_hw = En_hw_table(BPn , n_scat_n , iCn);

		      Cn = configuration_set_n(BPn , n_scat_n , iCn);

		      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
		      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

		      const double M_max_Cp = Cp.M_max_determine (shells_qn_prot);
		      const double M_max_Cn = Cn.M_max_determine (shells_qn_neut);

		      const double M_max_C = M_max_Cp + M_max_Cn;

		      if (M <= M_max_C) sub_dimension++;
		    }
		}
	    }

	  dimension += sub_dimension;
	}
    }

  return dimension;
}






void maximal_probability_configuration_print (
					      const unsigned int BP ,
					      const enum space_type space ,  
					      const class nucleons_data &prot_data ,
					      const class nucleons_data &neut_data ,  
					      const class array<class configuration_mixing_data> &configuration_mixing_tab)
{
  const unsigned int dimension = configuration_mixing_tab.dimension (0);

  const unsigned int dimension_minus_one = dimension - 1;

  cout << endl << "Configuration of maximal probability" << endl;
  cout <<         "------------------------------------" << endl << endl;

  if (space == PROTONS_NEUTRONS)
    {
      const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
      const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();

      const class array_of_configuration &configuration_set_p = prot_data.get_configuration_set ();
      const class array_of_configuration &configuration_set_n = neut_data.get_configuration_set ();

      const class configuration_mixing_data &configuration_mixing = configuration_mixing_tab(dimension_minus_one);

      const int n_scat_p = configuration_mixing.get_n_scat_p ();
      const int n_scat_n = configuration_mixing.get_n_scat_n ();

      const unsigned int BPp = configuration_mixing.get_BPp ();

      const unsigned int BPn = binary_parity_product (BPp , BP);
      
      const unsigned int iCp = configuration_mixing.get_iCp ();
      const unsigned int iCn = configuration_mixing.get_iCn ();

      const class configuration Cp = configuration_set_p(BPp , n_scat_p , iCp);
      const class configuration Cn = configuration_set_n(BPn , n_scat_n , iCn);

      const TYPE probability = configuration_mixing.get_probability ();

      cout << "P:" , Cp.print (shells_qn_prot);
      cout << "N:" , Cn.print (shells_qn_neut);

      cout << probability << endl << endl;
    }
  else
    {
      const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);

      const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
      
      const class array_of_configuration &configuration_set = data.get_configuration_set ();

      const class configuration_mixing_data &configuration_mixing = configuration_mixing_tab(dimension_minus_one);

      const int n_scat = configuration_mixing.get_n_scat ();
      
      const unsigned int iC = configuration_mixing.get_iC ();
      
      const class configuration C = configuration_set(BP , n_scat , iC);
      
      const TYPE probability = configuration_mixing.get_probability ();

      C.print (shells_qn);

      cout << probability << endl << endl;
    }
} 


void configuration_occupation_print_pp_nn ( 
					   const unsigned int BP ,
					   const enum space_type space , 
					   const int n_scat_max ,
					   const class nucleons_data &prot_data ,
					   const class nucleons_data &neut_data ,  
					   const bool are_scattering_configuration_probabilities_printed , 
					   const class array<class configuration_mixing_data> &configuration_mixing_tab , 
					   const double configuration_precision)
{
  const int n_scat_max_plus_one = n_scat_max + 1;
  
  const unsigned int dimension = configuration_mixing_tab.dimension (0);

  const unsigned int dimension_minus_one = dimension - 1;

  const class nucleons_data &data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);
  
  const int N_valence_nucleons = data.get_N_valence_nucleons ();
  
  const int lmax = data.get_lmax ();
  
  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  class configuration C(N_valence_nucleons);
  
  class configuration C_prime(N_valence_nucleons);
  
  class array<TYPE> scat_probability_tab(n_scat_max_plus_one);

  scat_probability_tab = 0.0;

  class array<bool> super_configuration_considered_tab(dimension);

  super_configuration_considered_tab = false;

  shell_occupations_print_pp_nn (data , BP , are_scattering_configuration_probabilities_printed , configuration_mixing_tab);

  cout << endl;
  
  partial_wave_occupations_print_pp_nn (true , data , BP , configuration_mixing_tab);
  
  cout << endl;
  
  partial_wave_occupations_print_pp_nn (false , data , BP , configuration_mixing_tab);
  
  cout << endl;
        
  if (are_scattering_configuration_probabilities_printed)
    {
      cout << endl << "All configuration probabilities" << endl;
      cout <<         "-------------------------------" << endl << endl;
      
      for (unsigned int i = dimension_minus_one ; i < dimension ; i--)
	{
	  const class configuration_mixing_data &configuration_mixing = configuration_mixing_tab(i);

	  const int n_scat = configuration_mixing.get_n_scat ();

	  const unsigned int iC = configuration_mixing.get_iC ();

	  C = configuration_set(BP , n_scat , iC);

	  const TYPE probability = configuration_mixing.get_probability ();

	  if (inf_norm (probability) > configuration_precision)
	    {
	      C.print (shells_qn);

	      cout << probability << endl << endl; 
	    }
	}

      cout << endl;
    }
  
  cout << endl << "Partially summed configuration probabilities" << endl;
  cout <<         "--------------------------------------------" << endl << endl;
  
  for (unsigned int i = dimension_minus_one ; i < dimension ; i--)
    {
      const class configuration_mixing_data &configuration_mixing = configuration_mixing_tab(i);

      const int n_scat = configuration_mixing.get_n_scat ();

      const unsigned int iC = configuration_mixing.get_iC ();

      C = configuration_set(BP , n_scat , iC);

      const TYPE probability = configuration_mixing.get_probability ();

      if (n_scat == 0)
	{
	  if (inf_norm (probability) > configuration_precision)
	    {
	      C.print (shells_qn);

	      cout << probability << endl << endl; 
	    }
	}
      else 
	{
	  scat_probability_tab(n_scat) += configuration_mixing.get_probability ();

	  if (!super_configuration_considered_tab(i))
	    {
	      TYPE super_probability = 0.0;

	      for (unsigned int ii = 0 ; ii < dimension ; ii++)
		{
		  const class configuration_mixing_data &configuration_mixing_prime = configuration_mixing_tab(ii);

		  if (!super_configuration_considered_tab(ii))
		    {
		      const int n_scat_prime = configuration_mixing_prime.get_n_scat ();

		      if (n_scat_prime == n_scat)
			{
			  const unsigned int iC_prime = configuration_mixing_prime.get_iC ();

			  C_prime = configuration_set(BP , n_scat_prime , iC_prime);

			  if (same_super_configuration (lmax , shells_qn , C , C_prime))
			    {
			      const TYPE probability_prime = configuration_mixing_prime.get_probability ();

			      super_probability += probability_prime;

			      super_configuration_considered_tab(ii) = true;
			    }
			}
		    }
		}

	      if (inf_norm (super_probability) > configuration_precision)
		{
		  C.super_configuration_print (lmax , shells_qn);

		  cout << super_probability << endl << endl; 
		} 

	      super_configuration_considered_tab(i) = true;
	    }
	}
    }

  for (int n_scat = 1 ; n_scat <= n_scat_max ; n_scat++) cout << "scat:" << n_scat << "   " << scat_probability_tab(n_scat) << endl;

  if (n_scat_max >= 1) cout << endl;
}


void configuration_occupation_print_pn (
					const unsigned int BP ,
					const bool truncation_ph ,
					const int n_scat_max ,
					const int n_scat_max_p ,
					const int n_scat_max_n ,
					const class nucleons_data &prot_data ,
					const class nucleons_data &neut_data ,
					const bool are_scattering_configuration_probabilities_printed ,
					const class array<class configuration_mixing_data> &configuration_mixing_tab , 
					const double configuration_precision)
{  
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  const int n_scat_max_p_plus_one = n_scat_max_p + 1;
  const int n_scat_max_n_plus_one = n_scat_max_n + 1;
  
  const unsigned int dimension = configuration_mixing_tab.dimension (0); 

  const unsigned int dimension_minus_one = dimension - 1;
  
  const int lmax_p = prot_data.get_lmax ();
  const int lmax_n = neut_data.get_lmax ();

  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();
  
  const class array_of_configuration &configuration_set_p = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_set_n = neut_data.get_configuration_set ();

  class configuration Cp(Zval);
  class configuration Cn(Nval);
  
  class configuration Cp_prime(Zval);
  class configuration Cn_prime(Nval);
  
  class array<TYPE> scat_probability_tab(n_scat_max_p_plus_one , n_scat_max_n_plus_one);
  
  scat_probability_tab = 0.0;

  class array<bool> super_configuration_considered_tab(dimension);

  super_configuration_considered_tab = false;

  shell_occupations_print_pn (prot_data , BP , are_scattering_configuration_probabilities_printed , configuration_mixing_tab);
  shell_occupations_print_pn (neut_data , BP , are_scattering_configuration_probabilities_printed , configuration_mixing_tab);

  cout << endl;
  
  partial_wave_occupations_print_pn (true , prot_data , BP , configuration_mixing_tab);
  partial_wave_occupations_print_pn (true , neut_data , BP , configuration_mixing_tab);
  
  cout << endl;
  
  partial_wave_occupations_print_pn (false , prot_data , BP , configuration_mixing_tab);
  partial_wave_occupations_print_pn (false , neut_data , BP , configuration_mixing_tab);
  
  cout << endl;
  
  if (are_scattering_configuration_probabilities_printed)
    {
      cout << endl << "All configuration probabilities" << endl;
      cout <<         "-------------------------------" << endl << endl;
      
      for (unsigned int i = dimension_minus_one ; i < dimension ; i--)
	{
	  const class configuration_mixing_data &configuration_mixing = configuration_mixing_tab(i);
      
	  const unsigned int BPp = configuration_mixing.get_BPp ();

	  const unsigned int BPn = binary_parity_product (BPp , BP);
      
	  const int n_scat_p = configuration_mixing.get_n_scat_p ();
	  const int n_scat_n = configuration_mixing.get_n_scat_n ();
      
	  const unsigned int iCp = configuration_mixing.get_iCp ();
	  const unsigned int iCn = configuration_mixing.get_iCn ();

	  const TYPE probability = configuration_mixing.get_probability ();
      
	  Cp = configuration_set_p(BPp , n_scat_p , iCp);
	  Cn = configuration_set_n(BPn , n_scat_n , iCn);
      
	  if (inf_norm (probability) > configuration_precision)
	    {     
	      cout << "P:" , Cp.print (shells_qn_prot); 
	      cout << "N:" , Cn.print (shells_qn_neut);
	  
	      cout << probability << endl << endl;
	    }
	}

      cout << endl;    
    }
  
  cout << endl << "Partially summed configuration probabilities" << endl;
  cout <<         "--------------------------------------------" << endl << endl;
      
  for (unsigned int i = dimension_minus_one ; i < dimension ; i--)
    {
      const class configuration_mixing_data &configuration_mixing = configuration_mixing_tab(i);
      
      const unsigned int BPp = configuration_mixing.get_BPp ();

      const unsigned int BPn = binary_parity_product (BPp , BP);
      
      const int n_scat_p = configuration_mixing.get_n_scat_p ();
      const int n_scat_n = configuration_mixing.get_n_scat_n ();
      
      const unsigned int iCp = configuration_mixing.get_iCp ();
      const unsigned int iCn = configuration_mixing.get_iCn ();

      const TYPE probability = configuration_mixing.get_probability ();
      
      Cp = configuration_set_p(BPp , n_scat_p , iCp);
      Cn = configuration_set_n(BPn , n_scat_n , iCn);
      
      if ((n_scat_p == 0) && (n_scat_n == 0))
	{	    
	  if (inf_norm (probability) > configuration_precision)
	    {     
	      cout << "P:" , Cp.print (shells_qn_prot); 
	      cout << "N:" , Cn.print (shells_qn_neut);

	      cout << probability << endl << endl;
	    }
	}
      else
	{ 
	  scat_probability_tab(n_scat_p , n_scat_n) += probability;

	  if (!super_configuration_considered_tab(i))
	    {
	      TYPE super_probability = 0.0;

	      for (unsigned int ii = 0 ; ii < dimension ; ii++)
		{
		  if (!super_configuration_considered_tab(ii))
		    {
		      const class configuration_mixing_data &configuration_mixing_prime = configuration_mixing_tab(ii);

		      const unsigned int BPp_prime = configuration_mixing_prime.get_BPp ();
		      const unsigned int BPn_prime = binary_parity_product (BPp_prime , BP);
		      
		      const int n_scat_p_prime = configuration_mixing_prime.get_n_scat_p ();
		      const int n_scat_n_prime = configuration_mixing_prime.get_n_scat_n ();

		      if ((BPp_prime == BPp) && (BPn_prime == BPn) && (n_scat_p_prime == n_scat_p) && (n_scat_n_prime == n_scat_n))
			{
			  const unsigned int iCp_prime = configuration_mixing_prime.get_iCp ();
			  const unsigned int iCn_prime = configuration_mixing_prime.get_iCn ();

			  Cp_prime = configuration_set_p(BPp_prime , n_scat_p_prime , iCp_prime);
			  Cn_prime = configuration_set_n(BPn_prime , n_scat_n_prime , iCn_prime);

			  if (same_super_configuration (lmax_p , shells_qn_prot , Cp , Cp_prime) && same_super_configuration (lmax_n , shells_qn_neut , Cn , Cn_prime)) 
			    {
			      const TYPE probability = configuration_mixing_prime.get_probability ();

			      super_probability += probability;
			      
			      super_configuration_considered_tab(ii) = true;
			    }
			}
		    }
		}

	      if (inf_norm (super_probability) > configuration_precision)
		{
		  cout << "P:" , Cp.super_configuration_print (lmax_p , shells_qn_prot); 
		  cout << "N:" , Cn.super_configuration_print (lmax_n , shells_qn_neut);

		  cout << super_probability << endl << endl;
		} 

	      super_configuration_considered_tab(i) = true;
	    }
	}
    }

  for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
    for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
      {
	if ((n_scat_p + n_scat_n > 0) && (!truncation_ph || (n_scat_p + n_scat_n <= n_scat_max)))
	  cout << "scat[p]:" << n_scat_p << " scat[n]:" << n_scat_n << "     " << scat_probability_tab(n_scat_p , n_scat_n) << endl;
      }
  
  if (n_scat_max >= 1) cout << endl;
}



