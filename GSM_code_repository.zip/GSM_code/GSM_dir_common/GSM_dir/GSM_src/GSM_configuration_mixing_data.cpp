#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Structure containing data related to the calculation of the amount of configuration mixing of a GSM vector
// ----------------------------------------------------------------------------------------------------------
// A GSM vector has many basis configurations, whose probabilities differ. The quantum numbers defining a fixed configuration and its probability in the GSM vector are stored here.
// This routine is used to order configurations with respect to their probability. They are printed on screen afterwards.

configuration_mixing_data::configuration_mixing_data () : 
  BPp (0) ,
  iCp (0) , 
  iCn (0) ,
  iC (0) ,
  n_scat_p (0) ,
  n_scat_n (0) ,
  n_scat (0) ,
  probability (0.0)
{}

configuration_mixing_data::configuration_mixing_data (
						      const unsigned int BPp_c , 
						      const unsigned int iCp_c , 
						      const unsigned int iCn_c , 
						      const int n_scat_p_c , 
						      const int n_scat_n_c , 
						      const unsigned int iC_c , 
						      const int n_scat_c , 
						      const TYPE probability_c)
{
  initialize (BPp_c , iCp_c , iCn_c , n_scat_p_c , n_scat_n_c , iC_c , n_scat_c , probability_c);
}

configuration_mixing_data::configuration_mixing_data (const configuration_mixing_data &X)
{
  initialize (X);
}

void configuration_mixing_data::initialize (
					    const unsigned int BPp_c , 
					    const unsigned int iCp_c , 
					    const unsigned int iCn_c , 
					    const int n_scat_p_c , 
					    const int n_scat_n_c , 
					    const unsigned int iC_c , 
					    const int n_scat_c , 
					    const TYPE probability_c)
{
  BPp = BPp_c; 

  iCp = iCp_c; 
  iCn = iCn_c; 

  n_scat_p = n_scat_p_c; 
  n_scat_n = n_scat_n_c; 

  iC = iC_c; 

  n_scat = n_scat_c; 

  probability = probability_c;
}

void configuration_mixing_data::initialize (const configuration_mixing_data &X)
{
  BPp = X.BPp; 

  iCp = X.iCp; 
  iCn = X.iCn; 

  n_scat_p = X.n_scat_p; 
  n_scat_n = X.n_scat_n; 

  iC = X.iC; 

  n_scat = X.n_scat; 

  probability = X.probability;
}

void configuration_mixing_data::operator = (const configuration_mixing_data &X)
{
  BPp = X.BPp; 

  iCp = X.iCp; 
  iCn = X.iCn; 

  n_scat_p = X.n_scat_p; 
  n_scat_n = X.n_scat_n; 

  iC = X.iC; 

  n_scat = X.n_scat; 

  probability = X.probability;
}





