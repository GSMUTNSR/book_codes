#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Array class type to store an array of class configuration_2ph_data_str
// ----------------------------------------------------------------------
// class configuration_2ph_data_str stores information related to the obtained configuration after the action of a+_{alpha} a+_{beta} (2p) or a_{alpha} a_{beta} (2h) on a Slater determinant.
// It contains its number of particles in the continuum, its index with fixed parity, and the indices of the shells borne by a+_{alpha} a+_{beta} or a_{alpha} a_{beta}. One must have alpha <= beta.
//
// In this array class type, one uniquely stores the existing class configuration_2ph_data_str by knowing their number for each configuration and summing dimensions.
// The method is the following to allocate the array of class configuration_2ph_data_str:
// _ one loops over all configurations
// _ one loops over the intermediate parity BP_inter of the class configuration_2ph_data_str
// _ one adds the number of class configuration_2ph_data_str to the total number of configuration_2ph_data_str
// _ one does the same for the array of sums of dimensions
// _ one allocates the array of class configuration_2ph_data_str with its calculated dimension
//
// The internal index of the table storing all classes configuration_2ph_data_str is a one-dimensional index ,
// calculated from the local index configuration_2ph_index, where configuration quantum numbers are fixed, to which a sum of dimensions is added.
// This is done in index_determine.
//
// One can access the table with operator (), where one puts all configuration quantum numbers and the local index configuration_2ph_index,
// or with operator [], where one puts directly the internal one-dimensional index of the stored array.

array_of_configuration_2ph_data::array_of_configuration_2ph_data () {}
  
array_of_configuration_2ph_data::array_of_configuration_2ph_data (
								  const unsigned int strangeness_max ,
								  const unsigned int n_spec_max , 
								  const unsigned int n_scat_max , 
								  const unsigned int dimension_configuration_total , 
								  const class array<unsigned int> &dimensions_configuration_set , 
								  const class array<unsigned int> &sum_dimensions_configuration_set , 
								  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_configuration_2ph_table)
{
  allocate (strangeness_max , n_spec_max , n_scat_max , dimension_configuration_total , dimensions_configuration_set , sum_dimensions_configuration_set , dimensions_configuration_2ph_table);
}

array_of_configuration_2ph_data::array_of_configuration_2ph_data (const class array_of_configuration_2ph_data &X)
{
  allocate_fill (X);
}


void array_of_configuration_2ph_data::allocate (
						const unsigned int strangeness_max ,
						const unsigned int n_spec_max , 
						const unsigned int n_scat_max , 
						const unsigned int dimension_configuration_total , 
						const class array<unsigned int> &dimensions_configuration_set , 
						const class array<unsigned int> &sum_dimensions_configuration_set , 
						const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_configuration_2ph_table) 
{
  const unsigned int strangeness_max_plus_one = strangeness_max + 1;
  
  const unsigned int n_spec_max_plus_one = n_spec_max + 1;
  
  sum_dimensions_tab.allocate (dimension_configuration_total , sum_dimensions_configuration_set , 2 , strangeness_max_plus_one , n_spec_max_plus_one);

  unsigned int dimension_table = 0;

  unsigned int sum_dimensions_bef = 0;
  
  unsigned int dimension_bef = 0;

  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (unsigned int S = 0 ; S <= strangeness_max ; S++)
      for (unsigned int n_spec = 0 ; n_spec <= n_spec_max ; n_spec++)
	for (unsigned int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
	  {
	    const unsigned int dimension_C = dimensions_configuration_set(BP , S , n_spec , n_scat);

	    for (unsigned int iC = 0 ; iC < dimension_C ; iC++)
	      for (unsigned int BP_inter = 0 ; BP_inter <= 1 ; BP_inter++)
		for (unsigned int S_inter = 0 ; S_inter <= strangeness_max ; S_inter++)
		  for (unsigned int n_spec_inter = 0 ; n_spec_inter <= n_spec_max ; n_spec_inter++)
		    {
		      const unsigned int dimension = dimensions_configuration_2ph_table(BP , S , n_spec , n_scat , iC , BP_inter , S_inter , n_spec_inter);

		      unsigned int &sum_dimensions = sum_dimensions_tab(BP , S , n_spec , n_scat , iC , BP_inter , S_inter , n_spec_inter);

		      dimension_table += dimension;

		      sum_dimensions = sum_dimensions_bef + dimension_bef;

		      dimension_bef = dimension;

		      sum_dimensions_bef = sum_dimensions;	
		    }
	  }

  table.allocate (dimension_table);
}

void array_of_configuration_2ph_data::allocate_fill (const class array_of_configuration_2ph_data &X)
{
  sum_dimensions_tab.allocate_fill (X.sum_dimensions_tab);

  table.allocate_fill (X.table);
}

void array_of_configuration_2ph_data::deallocate ()
{
  sum_dimensions_tab.deallocate ();

  table.deallocate ();
}

bool array_of_configuration_2ph_data::is_it_filled () const
{
  return table.is_it_filled ();
}

unsigned int array_of_configuration_2ph_data::index_determine (
							       const unsigned int BP_out , 
							       const unsigned int S_out , 
							       const unsigned int n_spec_out , 
							       const unsigned int n_scat_out , 
							       const unsigned int iC_out , 
							       const unsigned int BP_in , 
							       const unsigned int S_in , 
							       const unsigned int n_spec_in , 
							       const unsigned int configuration_2ph_index) const
{
  const unsigned int index = configuration_2ph_index + sum_dimensions_tab(BP_out , S_out , n_spec_out , n_scat_out , iC_out , BP_in , S_in , n_spec_in);

  return index;
}

class configuration_2ph_data_str & array_of_configuration_2ph_data::operator () (
										 const unsigned int BP_out , 
										 const unsigned int S_out , 
										 const unsigned int n_spec_out , 
										 const unsigned int n_scat_out , 
										 const unsigned int iC_out , 
										 const unsigned int BP_in , 
										 const unsigned int S_in , 
										 const unsigned int n_spec_in , 
										 const unsigned int configuration_2ph_index) const
{ 
  const unsigned int index = index_determine(BP_out , S_out , n_spec_out , n_scat_out , iC_out , BP_in , S_in , n_spec_in , configuration_2ph_index);

  return table(index);
}


class configuration_2ph_data_str & array_of_configuration_2ph_data::operator [] (const unsigned int index) const
{
  return table(index);
}


double used_memory_calc (const class array_of_configuration_2ph_data &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.sum_dimensions_tab) + used_memory_calc (T.table) - (sizeof (T.sum_dimensions_tab) + sizeof (T.table))/1000000.0);
}


