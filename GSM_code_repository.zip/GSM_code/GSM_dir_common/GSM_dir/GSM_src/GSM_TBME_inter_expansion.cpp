#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// TBME is for two-body matrix element
// -----------------------------------




// Interation basis/Berggren basis two-body overlaps between interaction and Berggren two-body pp and nn states
// ---------------------------------------------------------------------------------------------------
// <s0 s1| a b> = [<s0 s1| a b>[nas] - (-1)^(j0 + j1 - J) <s0 s1| b a>[nas]]/sqrt (1 + delta(s0 , s1))/sqrt (1 + delta(a , b))
// <s0 s1| b a> = [<s0 s1| b a>[nas] - (-1)^(j0 + j1 - J) <s0 s1| a b>[nas]]/sqrt (1 + delta(s0 , s1))/sqrt (1 + delta(a , b))
//
// nas means non-antisymmetrized.
// bin_phase is the binary phase (see observables_basic_functions.cpp for definition) and is 0 (or 1) if (-1)^(j0+j1-J) is even (or odd)
// One always has s0 <= s1 , (l0 , j0) = (la , ja) and (l1 , j1) = (lb , jb)
// But a and b are not necessarily ordered.
//
// (l0,j0) = (l1,j1)
// -----------------
// <s0 s1| a b> = [<s0|a> <s1|b> - (-1)^(j0 + j1 - J) <s0|b> <s1|a>]/sqrt (1 + delta(s0 , s1))/sqrt (1 + delta(a , b))
// Here one must have s0 <= s1 and a <= b.
//
// (l0,j0) != (l1,j1)
// ------------------
// <s0 s1| a b> = <s0|a> <s1|b> if a <= b
//
// Here , one can have a > b: it can indeed occur as (l0 , j0) = (la , ja) and (l1 , j1) = (lb , jb). 
// Hence , the interaction state occuring in basis expansion is |b a>.
// <s0 s1| b a> = -(-1)^(j0 + j1 - J) <s0|a><s1|b> if a > b

complex<double> TBME_inter_expansion_set::two_body_overlap_pp_nn_calc (
								       const unsigned int bin_phase ,
								       const bool same_lj_s0_s1 ,
								       const bool same_s0_s1 , 
								       const complex<double> &overlap_s0_a ,
								       const complex<double> &overlap_s1_a , 
								       const complex<double> &overlap_s0_b ,
								       const complex<double> &overlap_s1_b , 
								       const unsigned int a ,
								       const unsigned int b)
{
  const int phase = parity_from_binary_parity (bin_phase);
  
  if (!same_lj_s0_s1)
    {
      const complex<double> overlap_direct = overlap_s0_a*overlap_s1_b;

      if (a <= b)
	return overlap_direct;
      else
	return ((phase == 1) ? (-overlap_direct) : (overlap_direct));
    }
  else
    {
      const bool same_ab = (a == b);

      const complex<double> overlap_direct   = overlap_s0_a*overlap_s1_b;
      const complex<double> overlap_exchange = overlap_s1_a*overlap_s0_b;
      
      const complex<double> two_body_overlap_not_normed = (phase == 1) ? (overlap_direct - overlap_exchange) : (overlap_direct + overlap_exchange);

      if (!same_s0_s1 && !same_ab)
	return two_body_overlap_not_normed;
      else if (same_s0_s1 && same_ab) 
	return (0.5*two_body_overlap_not_normed);
      else
	return (M_SQRT1_2*two_body_overlap_not_normed);
    }
}













// Calculation of the mixed TBMEs <s2 s3 | V | a b>, where (a,b) are interaction states and (s2,s3) are Berggren basis states, and of the <s2 s3 | V | s0 s1> TBME with only Berggren basis states
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//
// One considers case for protons or neutrons only and proton-neutron TBMEs. they differ through antisymmetry, as protons and neutrons pairs are antisymmetrized but proton-neutron pairs are not?
//
// J_TBMEs_mixed_inter_pp_nn_calc, J_TBMEs_mixed_inter_pn_calc
// -----------------------------------------------------------
// One calculates here  <s2 s3 | V | a b>, for all (a,b) interaction states and (s2,s3) Berggren basis states.
// They are called mixed as the bra and ket states belong to different kinds of basis sets.
//
// One uses the formula:  <s2 s3 | V | a b> = \sum_{c d}  <s2 s3 | c d > <c d | V | a b> , where (c,d) are interaction basis states.
// TBMEs and overlaps are antisymmetrized if one considers TBMEs with protons only or neutrons only.
// One uses the antisymmetrized two-body overlap <s2 s3 | c d > from the routine interaction_two_body_overlap_pp_nn_calc for protons only or neutrons only and the product <s2|c> <s3|d> for proton-neutron TBMEs.
//
// HO expansion only
// -----------------
// The HO expansion in the interaction class is used up to lmax_for_interaction, which can be smaller than the maximal orbital angular momentum used in the one-body basis.
// They can be different if one considers N hbar omega spaces to generate |NCM-HO LCM intrinsic> states for GSM-CC, 
// for which large orbital angular momenta are needed but no interaction matrix elements for these orbital angular momenta are used.
// Indeed, high-l configurations are just there to have an exact separation of intrinsic and center of mass parts. 
// All interaction overlaps involving states with l > lmax_for_interaction with the HO expansion are then ignored.

// TBME_J_pp_nn_antisymmetrized, TBME_J_pn
// ---------------------------------------
// The <s2 s3 | V | s0 s1> TBME with only Berggren basis states is obtained through a similar formula: <s2 s3 | V | s0 s1> = \sum_{a b} <s2 s3 | V | a b > <a b | s0 s1>, where (a,b) are HO basis states.
// One uses the antisymmetrized two-body overlap <s0 s1 | a b > from the routine interaction_two_body_overlap_pp_nn_calc for protons only or neutrons only and the product <s0|a> <s1|b> for proton-neutron TBMEs.



void TBME_inter_expansion_set::J_TBMEs_mixed_inter_pp_nn_calc (
							       const bool is_there_cout ,
							       const enum interaction_read_type inter_read , 
							       const enum space_type TBME_space ,
							       const bool is_it_cluster_CM_HO_basis_calculation , 
							       const class nucleons_data &particles_data , 
							       const class interaction_class &inter_data , 
							       class TBMEs_class &J_TBMEs_mixed_inter)
{
  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class array<class nlj_struct> &shells_inter_table = inter_data.get_shells_inter_table ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const unsigned int N_nlj_inter = inter_data.get_N_nlj_inter ();
  
  const unsigned int BPmin_global = J_TBMEs_mixed_inter.get_BPmin_global ();
  const unsigned int BPmax_global = J_TBMEs_mixed_inter.get_BPmax_global ();
  
  const int Jmin_global = J_TBMEs_mixed_inter.get_Jmin_global ();
  const int Jmax_global = J_TBMEs_mixed_inter.get_Jmax_global ();
  
  const int lmax_for_interaction = inter_data.get_lmax_for_interaction ();

  const int n_scat_max = (!is_it_cluster_CM_HO_basis_calculation) ? (particles_data.get_n_scat_max ()) : (0);
  
  const class array<int> &nmax_inter_lab_tab = inter_data.get_nmax_inter_lab_tab ();
  
  const class nlj_table<unsigned int> &shells_inter_indices = inter_data.get_shells_inter_indices ();
  
  const class TBMEs_class &J_TBMEs_inter = (TBME_space == PROTONS_ONLY) ? (inter_data.get_TBMEs_pp_inter_lab ()) : (inter_data.get_TBMEs_nn_inter_lab ());
  
  const class array<class vector_class<complex<double> > > &overlaps = (inter_read != LAB_BERGGREN_TBMES_READ) ? (particles_data.get_HO_overlaps ()) : (particles_data.get_GHF_overlaps ());
  
  const unsigned int first_index = J_TBMEs_mixed_inter.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);

  const unsigned int last_index = J_TBMEs_mixed_inter.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s3 = 0 ; s3 < N_nlj ; s3++)
    {  
      for (unsigned int s2 = 0 ; s2 <= s3 ; s2++)
	{
	  const class pair_str pair_out(s2 , s3);
	  
	  const int n_scat_out = pair_out.n_scat_determine (shells_qn , shells_qn);

	  if (n_scat_out <= n_scat_max)
	    {
	      const unsigned int bp_out = pair_out.bp_determine (shells_qn , shells_qn);

	      if ((bp_out >= BPmin_global) && (bp_out <= BPmax_global))
		{
		  const int Jmin_out = pair_out.Jmin_determine (shells_qn , shells_qn);
		  const int Jmax_out = pair_out.Jmax_determine (shells_qn , shells_qn);

		  const class nlj_struct &shell_qn_s2 = shells_qn(s2);
		  const class nlj_struct &shell_qn_s3 = shells_qn(s3);
		  
		  const int l2 = shell_qn_s2.get_l ();
		  const int l3 = shell_qn_s3.get_l ();

		  const double j2 = shell_qn_s2.get_j ();
		  const double j3 = shell_qn_s3.get_j ();

		  const bool same_lj_s2_s3 = same_lj (shell_qn_s2 , shell_qn_s3);

		  const bool same_s2_s3 = (s2 == s3);
		  
		  if (l2 > lmax_for_interaction) continue;
		  if (l3 > lmax_for_interaction) continue;

		  const int nmax_inter_l2 = nmax_inter_lab_tab(l2);
		  const int nmax_inter_l3 = nmax_inter_lab_tab(l3);

		  const class vector_class<complex<double> > &overlaps_s2 = overlaps(s2);
		  const class vector_class<complex<double> > &overlaps_s3 = overlaps(s3);

		  for (unsigned int b = 0 ; b < N_nlj_inter ; b++)
		    for (unsigned int a = 0 ; a <= b ; a++)
		      { 
			const class pair_str pair_inter_in(a , b);
			
			const unsigned int bp_in = pair_inter_in.bp_determine (shells_inter_table , shells_inter_table);

			if (bp_in == bp_out)
			  {
			    const int Jmin_in = pair_inter_in.Jmin_determine (shells_inter_table , shells_inter_table);
			    const int Jmax_in = pair_inter_in.Jmax_determine (shells_inter_table , shells_inter_table);

			    const int Jmin_local = max (Jmin_in , Jmin_out);
			    const int Jmax_local = min (Jmax_in , Jmax_out);

			    const int Jmin = max (Jmin_local , Jmin_global);
			    const int Jmax = min (Jmax_local , Jmax_global);

			    for (int J = Jmin ; J <= Jmax ; J++)
			      {
				const unsigned int index = J_TBMEs_mixed_inter.index_determine (J , a , b , s2 , s3);

				if ((index >= first_index) && (index <= last_index))
				  {
				    const unsigned int bin_phase = binary_parity_from_orbital_angular_momentum (make_int (j2 + j3 - J));

				    complex<double> J_TBME = 0.0;

				    for (int nc = 0 ; nc <= nmax_inter_l2 ; nc++)
				      {
					const unsigned int c = shells_inter_indices(nc , l2 , j2);

					const complex<double> overlap_s2_c = overlaps_s2(nc);

					const complex<double> overlap_s3_c = (same_lj_s2_s3) ? (overlaps_s3(nc)) : (0.0);
				    
					if ((overlap_s2_c == 0.0) && (overlap_s3_c == 0.0)) continue;

					for (int nd = 0 ; nd <= nmax_inter_l3 ; nd++)
					  { 
					    const unsigned int d = shells_inter_indices(nd , l3 , j3);					   
  
					    const complex<double> overlap_s3_d = overlaps_s3(nd);

					    if ((overlap_s3_c == 0.0) && (overlap_s3_d == 0.0)) continue;
					    
					    const complex<double> overlap_s2_d = (same_lj_s2_s3) ? (overlaps_s2(nd)) : (0.0);

					    if ((overlap_s2_c == 0.0) && (overlap_s2_d == 0.0)) continue;
					    if ((overlap_s3_d == 0.0) && (overlap_s2_d == 0.0)) continue;
					
					    if (!same_lj_s2_s3 || (c <= d))
					      {
						const complex<double> J_TBME_inter = (c <= d) ? (J_TBMEs_inter(J , a , b , c , d)) : (J_TBMEs_inter(J , a , b , d , c));
						
						const complex<double> two_body_overlap = two_body_overlap_pp_nn_calc (bin_phase , same_lj_s2_s3 , same_s2_s3 , overlap_s2_c , overlap_s3_c , overlap_s2_d , overlap_s3_d , c , d);

						const complex<double> J_TBME_part = two_body_overlap*J_TBME_inter;
				    
						J_TBME += J_TBME_part;
					      }
					  }
				      }
				    
#ifdef TYPEisDOUBLECOMPLEX
				    J_TBMEs_mixed_inter(J , a , b , s2 , s3) = J_TBME;
#endif
				    
#ifdef TYPEisDOUBLE
				    J_TBMEs_mixed_inter(J , a , b , s2 , s3) = real (J_TBME);
#endif
				  }}}}}}}}
      
#ifdef UseMPI  
  if (is_it_MPI_parallelized) J_TBMEs_mixed_inter.MPI_Allgatherv (NUMBER_OF_PROCESSES , MPI_COMM_WORLD);
#endif
  
  const double now = absolute_time_determine () , relative_time = now - reference_time; 
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << "Coupled mixed TBMEs " << TBME_space << " calculated. time:" << relative_time << " s" << endl << endl;
}










TYPE TBME_inter_expansion_set::TBME_J_pp_nn_antisymmetrized (
							     const int J , 
							     const unsigned int s0 ,
							     const unsigned int s1 ,
							     const unsigned int s2 ,
							     const unsigned int s3 , 
							     const class array<class vector_class<complex<double> > > &overlaps , 
							     const class array<class nlj_struct> &shells_qn , 
							     const class interaction_class &inter_data , 
							     const class TBMEs_class &J_TBMEs_mixed_inter)
{
  const class array<int> &nmax_inter_lab_tab = inter_data.get_nmax_inter_lab_tab ();
  
  const class nlj_table<unsigned int> &shells_inter_indices = inter_data.get_shells_inter_indices ();
  	
  const class nlj_struct &shell_qn_s0 = shells_qn(s0);
  const class nlj_struct &shell_qn_s1 = shells_qn(s1);

  const int lmax_for_interaction = inter_data.get_lmax_for_interaction ();

  const int l0 = shell_qn_s0.get_l ();
  const int l1 = shell_qn_s1.get_l ();

  if (l0 > lmax_for_interaction) return 0.0;
  if (l1 > lmax_for_interaction) return 0.0;

  const double j0 = shell_qn_s0.get_j ();
  const double j1 = shell_qn_s1.get_j ();

  const bool same_lj_s0_s1 = same_lj (shell_qn_s0 , shell_qn_s1);

  const bool same_s0_s1 = (s0 == s1);

  const unsigned int bin_phase = binary_parity_from_orbital_angular_momentum (make_int (j0 + j1 - J));  

  const int nmax_inter_l0 = nmax_inter_lab_tab(l0);
  const int nmax_inter_l1 = nmax_inter_lab_tab(l1);

  const class vector_class<complex<double> > &overlaps_s0 = overlaps(s0);
  const class vector_class<complex<double> > &overlaps_s1 = overlaps(s1);

  complex<double> J_TBME = 0.0;

  for (int na = 0 ; na <= nmax_inter_l0 ; na++)
    {
      const unsigned int a = shells_inter_indices(na , l0 , j0);
      
      const complex<double> overlap_s0_a = overlaps_s0(na);

      const complex<double> overlap_s1_a = (same_lj_s0_s1) ? (overlaps_s1(na)) : (0.0);

      if ((overlap_s0_a == 0.0) && (overlap_s1_a == 0.0)) continue;

      for (int nb = 0 ; nb <= nmax_inter_l1 ; nb++)
	{ 
	  const unsigned int b = shells_inter_indices(nb , l1 , j1);

	  const complex<double> overlap_s1_b = overlaps_s1(nb);

	  if ((overlap_s1_a == 0.0) && (overlap_s1_b == 0.0)) continue;
	  
	  const complex<double> overlap_s0_b = (same_lj_s0_s1) ? (overlaps_s0(nb)) : (0.0);
	  
	  if ((overlap_s0_a == 0.0) && (overlap_s0_b == 0.0)) continue;
	  if ((overlap_s1_b == 0.0) && (overlap_s0_b == 0.0)) continue;
	  
	  if (!same_lj_s0_s1 || (a <= b))
	    {
	      const complex<double> J_TBME_mixed_inter = (a <= b) ? (J_TBMEs_mixed_inter(J , a , b , s2 , s3)) : (J_TBMEs_mixed_inter(J , b , a , s2 , s3));
	      
	      const complex<double> two_body_overlap = two_body_overlap_pp_nn_calc (bin_phase , same_lj_s0_s1 , same_s0_s1 , overlap_s0_a , overlap_s1_a , overlap_s0_b , overlap_s1_b , a , b);
	      
	      const complex<double> J_TBME_part = two_body_overlap*J_TBME_mixed_inter;
	      
	      J_TBME += J_TBME_part;
	    }
	}
    }
  
#ifdef TYPEisDOUBLECOMPLEX
  return J_TBME;
#endif
  
#ifdef TYPEisDOUBLE
  return real (J_TBME);
#endif
}








void TBME_inter_expansion_set::J_TBMEs_mixed_inter_pn_calc (
							    const bool is_there_cout ,
							    const enum interaction_read_type inter_read , 
							    const class nucleons_data &prot_data , 
							    const class nucleons_data &neut_data , 
							    const int n_scat_max , 
							    const class interaction_class &inter_data , 
							    class TBMEs_class &J_TBMEs_mixed_inter)
{
  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);
  
  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();
  
  const class array<class nlj_struct> &shells_inter_qn = inter_data.get_shells_inter_table ();

  const unsigned int N_nlj_p = prot_data.get_N_nlj ();
  const unsigned int N_nlj_n = neut_data.get_N_nlj ();

  const unsigned int N_nlj_inter = inter_data.get_N_nlj_inter ();
  
  const unsigned int BPmin_global = J_TBMEs_mixed_inter.get_BPmin_global ();
  const unsigned int BPmax_global = J_TBMEs_mixed_inter.get_BPmax_global ();
  
  const int Jmin_global = J_TBMEs_mixed_inter.get_Jmin_global ();
  const int Jmax_global = J_TBMEs_mixed_inter.get_Jmax_global ();

  const int lmax_for_interaction = inter_data.get_lmax_for_interaction ();
  
  const class array<int> &nmax_inter_lab_tab = inter_data.get_nmax_inter_lab_tab ();
  
  const class nlj_table<unsigned int> &shells_inter_indices = inter_data.get_shells_inter_indices ();
  
  const class TBMEs_class &J_TBMEs_inter = inter_data.get_TBMEs_pn_inter_lab ();
  
  const class array<class vector_class<complex<double> > > &overlaps_prot = (inter_read != LAB_BERGGREN_TBMES_READ) ? (prot_data.get_HO_overlaps ()) : (prot_data.get_GHF_overlaps ());
  const class array<class vector_class<complex<double> > > &overlaps_neut = (inter_read != LAB_BERGGREN_TBMES_READ) ? (neut_data.get_HO_overlaps ()) : (neut_data.get_GHF_overlaps ());

  const unsigned int first_index = J_TBMEs_mixed_inter.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_index = J_TBMEs_mixed_inter.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s2 = 0 ; s2 < N_nlj_p ; s2++)
    {
      for (unsigned int s3 = 0 ; s3 < N_nlj_n ; s3++)
	{
	  const class pair_str pair_out(s2 , s3);

	  const int n_scat_out = pair_out.n_scat_determine (shells_qn_prot , shells_qn_neut);

	  if (n_scat_out <= n_scat_max)
	    {
	      const unsigned int bp_out = pair_out.bp_determine (shells_qn_prot , shells_qn_neut);

	      if ((bp_out >= BPmin_global) && (bp_out <= BPmax_global))
		{
		  const int Jmin_out = pair_out.Jmin_determine (shells_qn_prot , shells_qn_neut);
		  const int Jmax_out = pair_out.Jmax_determine (shells_qn_prot , shells_qn_neut);

		  const class nlj_struct &shell_qn_s2 = shells_qn_prot(s2);
		  const class nlj_struct &shell_qn_s3 = shells_qn_neut(s3);

		  const int l2 = shell_qn_s2.get_l ();
		  const int l3 = shell_qn_s3.get_l ();

		  const double j2 = shell_qn_s2.get_j ();
		  const double j3 = shell_qn_s3.get_j ();

		  if (l2 > lmax_for_interaction) continue;
		  if (l3 > lmax_for_interaction) continue;

		  const int nmax_inter_l2 = nmax_inter_lab_tab(l2);
		  const int nmax_inter_l3 = nmax_inter_lab_tab(l3);

		  const class vector_class<complex<double> > &overlaps_s2 = overlaps_prot(s2);
		  const class vector_class<complex<double> > &overlaps_s3 = overlaps_neut(s3);

		  for (unsigned int a = 0 ; a < N_nlj_inter ; a++)
		    for (unsigned int b = 0 ; b < N_nlj_inter ; b++)
		      {
			const class pair_str pair_inter_in(a , b);
			
			const unsigned int bp_in = pair_inter_in.bp_determine (shells_inter_qn , shells_inter_qn);

			if (bp_in == bp_out)
			  {
			    const int Jmin_in = pair_inter_in.Jmin_determine (shells_inter_qn , shells_inter_qn);
			    const int Jmax_in = pair_inter_in.Jmax_determine (shells_inter_qn , shells_inter_qn);

			    const int Jmin_local = max (Jmin_in , Jmin_out);
			    const int Jmax_local = min (Jmax_in , Jmax_out);

			    const int Jmin = max (Jmin_local , Jmin_global);
			    const int Jmax = min (Jmax_local , Jmax_global);

			    for (int J = Jmin ; J <= Jmax ; J++)
			      {
				const unsigned int index = J_TBMEs_mixed_inter.index_determine (J , a , b , s2 , s3);
				
				if ((index >= first_index) && (index <= last_index))
				  {
				    complex<double> J_TBME = 0.0;

				    for (int nc = 0 ; nc <= nmax_inter_l2 ; nc++)
				      {
					const unsigned int c = shells_inter_indices(nc , l2 , j2);
					
					const complex<double> overlap_s2_c = overlaps_s2(nc);

					if (overlap_s2_c == 0.0) continue;

					for (int nd = 0 ; nd <= nmax_inter_l3 ; nd++)
					  {
					    const unsigned int d = shells_inter_indices(nd , l3 , j3);

					    const complex<double> overlap_s3_d = overlaps_s3(nd);

					    if (overlap_s3_d == 0.0) continue;
					
					    const complex<double> J_TBME_part = overlap_s2_c*overlap_s3_d*J_TBMEs_inter(J , a , b , c , d);

					    J_TBME += J_TBME_part;
					  }
				      }

#ifdef TYPEisDOUBLECOMPLEX
				    J_TBMEs_mixed_inter(J , a , b , s2 , s3) = J_TBME;
#endif
				    
#ifdef TYPEisDOUBLE
				    J_TBMEs_mixed_inter(J , a , b , s2 , s3) = real (J_TBME);
#endif
				    
				  }}}}}}}}

#ifdef UseMPI  
  if (is_it_MPI_parallelized) J_TBMEs_mixed_inter.MPI_Allgatherv (NUMBER_OF_PROCESSES , MPI_COMM_WORLD);
#endif

  const double now = absolute_time_determine () , relative_time = now - reference_time; 

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << "Coupled mixed pn TBMEs calculated. time:" << relative_time << " s" << endl << endl;
}





				    
TYPE TBME_inter_expansion_set::TBME_J_pn (
					  const int J , 
					  const unsigned int s0 ,
					  const unsigned int s1 ,
					  const unsigned int s2 ,
					  const unsigned int s3 , 
					  const class array<class vector_class<complex<double> > > &overlaps_prot , 
					  const class array<class vector_class<complex<double> > > &overlaps_neut , 
					  const class array<class nlj_struct> &shells_qn_prot , 
					  const class array<class nlj_struct> &shells_qn_neut , 
					  const class interaction_class &inter_data , 
					  const class TBMEs_class &J_TBMEs_mixed_inter)
{
  const class array<int> &nmax_inter_lab_tab = inter_data.get_nmax_inter_lab_tab ();
  
  const class nlj_table<unsigned int> &shells_inter_indices = inter_data.get_shells_inter_indices ();

  const class nlj_struct &shell_qn_s0 = shells_qn_prot(s0);
  const class nlj_struct &shell_qn_s1 = shells_qn_neut(s1);

  const int lmax_for_interaction = inter_data.get_lmax_for_interaction ();

  const int l0 = shell_qn_s0.get_l ();
  const int l1 = shell_qn_s1.get_l ();
  
  if (l0 > lmax_for_interaction) return 0.0;
  if (l1 > lmax_for_interaction) return 0.0;

  const double j0 = shell_qn_s0.get_j ();
  const double j1 = shell_qn_s1.get_j ();

  const int nmax_inter_l0 = nmax_inter_lab_tab(l0);
  const int nmax_inter_l1 = nmax_inter_lab_tab(l1);

  const class vector_class<complex<double> > &overlaps_s0 = overlaps_prot(s0);
  const class vector_class<complex<double> > &overlaps_s1 = overlaps_neut(s1);

  complex<double> J_TBME = 0.0;

  for (int na = 0 ; na <= nmax_inter_l0 ; na++)
    {    
      const unsigned int a = shells_inter_indices(na , l0 , j0);
      
      const complex<double> overlap_s0_a = overlaps_s0(na);

      if (overlap_s0_a == 0.0) continue;

      for (int nb = 0 ; nb <= nmax_inter_l1 ; nb++)
	{ 
	  const unsigned int b = shells_inter_indices(nb , l1 , j1);

	  const complex<double> overlap_s1_b = overlaps_s1(nb);

	  if (overlap_s1_b == 0.0) continue;
      
	  const complex<double> J_TBME_part = overlap_s0_a*overlap_s1_b*J_TBMEs_mixed_inter(J , a , b , s2 , s3);
	  
	  J_TBME += J_TBME_part;
	}
    }
  
#ifdef TYPEisDOUBLECOMPLEX
  return J_TBME;
#endif
  
#ifdef TYPEisDOUBLE
  return real (J_TBME);
#endif
}

