#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Determination of the form of the HF state according to occupied states
// ----------------------------------------------------------------------
// The spherical HF potential is usually calculated with uniform filling approximation.
// However, one can have an exact or better spherical HF potential if one has closed shells, one particle or one hole above closed shells.
// Associated booleans are determined here.
// mu is proton or neutron.
// One considers only the proton or neutron part, i.e. one considers that one has proton closed shells independently of neutrons, not proton and neutron closed shells.

void HF_potentials_common::uniform_filling_approximation::closed_shells_information_determine (
											       const class HF_nucleons_data &HF_data ,
											       bool &is_it_one_mu_above_closed_shells_mu ,
											       bool &is_it_one_mu_hole_inside_closed_shells_mu ,
											       bool &is_it_mu_closed)
{
  const unsigned int Nshells_occ_mu = HF_data.get_Nshells_occ ();

  if (Nshells_occ_mu != 0)
    {
      const class array<class nlj_struct> &shells_qn_mu = HF_data.get_shells_quantum_numbers ();
      
      const class nlj_struct &shell_qn_mu_last_occ = shells_qn_mu(Nshells_occ_mu - 1);

      const int n_last_occ_mu = shell_qn_mu_last_occ.get_n ();
      const int l_last_occ_mu = shell_qn_mu_last_occ.get_l ();

      const double j_last_occ_mu = shell_qn_mu_last_occ.get_j ();

      const class nlj_table<unsigned int> &Nval_nucleons_in_shell_mu_tab = HF_data.get_N_valence_nucleons_in_shell_tab ();
      
      const unsigned int m_number_last_occ_mu = shell_qn_mu_last_occ.m_number_determine ();

      const unsigned int Nval_nucleons_in_last_occ_shell_mu = Nval_nucleons_in_shell_mu_tab(n_last_occ_mu , l_last_occ_mu , j_last_occ_mu);

      is_it_one_mu_above_closed_shells_mu = (Nval_nucleons_in_last_occ_shell_mu == 1) ? (true) : (false);
      
      is_it_one_mu_hole_inside_closed_shells_mu = (Nval_nucleons_in_last_occ_shell_mu == m_number_last_occ_mu - 1) ? (true) : (false);
      
      is_it_mu_closed = (Nval_nucleons_in_last_occ_shell_mu == m_number_last_occ_mu) ? (true) : (false);
    }
}




// Check if one has uniform filling approximation for the spherical HF potential
// -----------------------------------------------------------------------------
// The spherical HF potential is usually calculated with uniform filling approximation.
// However, one can have an exact or better spherical HF potential if one has closed shells, one particle or one hole above closed shells.
// Hence, the boolean associated to uniform filling approximation and single particle character of the spherical HF potential is determined here and stored in prot_HF_data and neut_HF_data.
// Uniform filling approximation is used unless one has a proton/neutron particle or hole with closed shells.
// One is in the proton/neutron single particle case if one hase a proton/neutron particle above proton/neutron closed shells.

void HF_potentials_common::uniform_filling_approximation::is_it_uniform_filling_approximation_determine (
													 const enum interaction_type TBME_inter , 
													 class HF_nucleons_data &prot_HF_data , 
													 class HF_nucleons_data &neut_HF_data)
{
  const int Zval_basis = prot_HF_data.get_N_valence_nucleons_basis ();
  const int Nval_basis = neut_HF_data.get_N_valence_nucleons_basis ();

  if ((TBME_inter == REALISTIC_INTERACTION) && (Zval_basis == 1) && (Nval_basis == 1))
    {
      prot_HF_data.set_is_it_uniform_filling_approximation (false);
      neut_HF_data.set_is_it_uniform_filling_approximation (false);
      
      prot_HF_data.set_single_particle (true);
      neut_HF_data.set_single_particle (true);
      
      return;
    }

  bool is_it_prot_closed = true;
  bool is_it_neut_closed = true;

  bool is_it_one_prot_above_closed_prot_shells = false;
  bool is_it_one_neut_above_closed_neut_shells = false;
  
  bool is_it_one_prot_hole_inside_closed_prot_shells = false;
  bool is_it_one_neut_hole_inside_closed_neut_shells = false;

  closed_shells_information_determine (prot_HF_data , is_it_one_prot_above_closed_prot_shells , is_it_one_prot_hole_inside_closed_prot_shells , is_it_prot_closed);
  closed_shells_information_determine (neut_HF_data , is_it_one_neut_above_closed_neut_shells , is_it_one_neut_hole_inside_closed_neut_shells , is_it_neut_closed);

  if (is_it_prot_closed && is_it_one_neut_above_closed_neut_shells)
    {
      prot_HF_data.set_is_it_uniform_filling_approximation (false);
      neut_HF_data.set_is_it_uniform_filling_approximation (false);
    }
  else if (is_it_neut_closed && is_it_one_prot_above_closed_prot_shells)
    {
      prot_HF_data.set_is_it_uniform_filling_approximation (false);
      neut_HF_data.set_is_it_uniform_filling_approximation (false);
    }
  else if (is_it_prot_closed && is_it_one_neut_hole_inside_closed_neut_shells)
    {
      prot_HF_data.set_is_it_uniform_filling_approximation (false);
      neut_HF_data.set_is_it_uniform_filling_approximation (false);
    }
  else if (is_it_neut_closed && is_it_one_prot_hole_inside_closed_prot_shells)
    {
      prot_HF_data.set_is_it_uniform_filling_approximation (false);
      neut_HF_data.set_is_it_uniform_filling_approximation (false);
    }
  else
    {
      prot_HF_data.set_is_it_uniform_filling_approximation (true);
      neut_HF_data.set_is_it_uniform_filling_approximation (true);
    }
  
  if (is_it_prot_closed && is_it_one_neut_above_closed_neut_shells)
    {
      prot_HF_data.set_single_particle (false);
      neut_HF_data.set_single_particle (true);
    }
  else if (is_it_neut_closed && is_it_one_prot_above_closed_prot_shells)
    {
      prot_HF_data.set_single_particle (true);
      neut_HF_data.set_single_particle (false);
    }
  else
    {
      prot_HF_data.set_single_particle (false);
      neut_HF_data.set_single_particle (false);
    }
}






// Determination of the number of nucleons occupied in the last occupied (l,j) shell
// ---------------------------------------------------------------------------------
// In order to calculate averaging coefficients in uniform filling approximation, one has to know the number of nucleons in the last occupied shell.
// It is done here by looping over nmax, nmax-1, ... (l,j) shells and sending its number of occupied nucleons if it is not zero.
// 1 is send by default.

unsigned int HF_potentials_common::uniform_filling_approximation::N_in_lj_shell_largest_n_calc (
												const int l , 
												const double j , 
												const class HF_nucleons_data &HF_data)
{
  const int nmax = HF_data.get_nmax ();

  const class nlj_table<unsigned int> &Nval_nucleons_in_shell_tab = HF_data.get_N_valence_nucleons_in_shell_tab ();

  for (int n = nmax ; n >= 0 ; n--)
    {
      const unsigned int N = Nval_nucleons_in_shell_tab(n , l , j);
      
      if (N > 0) return N;
    }

  return 1;
}


// Calculation of the coefficient entering uniform filling approximation or single-particle/hole in the HF potential for a fixed occupied shell
// --------------------------------------------------------------------------------------------------------------------------------------------
// The m-dependent HF potential generated by the interaction writes <b | U_HF | a > = \sum_{lambda} <b lambda | V | a lambda> where a,b and lambda (the occupied state) have fixed n,l,j,m values.
// This potential cannot be used to generate a shell model basis, as the radial parts of (n,l,j) basis states with different m quantum numbers must be the same.
//
// If one uses uniform filling approximation, i.e. if one does not have a single-particle/hole with closed shells, one averages over the m quantum numbers of a,b, and lambda.
// The HF potential then reads <b | U_HF | a > = \sum_{lambda} <b lambda | V | a lambda>_J N_occ(n_largest,l_lambda,j_lambda) (2J+1)/(2j_occ+1)/(2j+1) 
// where a,b and lambda have fixed n,l,j values only and where N_occ(n_largest,l_lambda,j_lambda) is the number of nucleons occupied in the highest occupied lambda shell of quantum numbers l_lambda,j_lambda.
//
// 
// If one has a single-particle/hole with closed shells, one occupies the lambda states of largest m quantum numbers with available nucleons.
//
// One then obtains:
// <b | U_HF | a > = \sum_{lambda,m,m_lambda} <b lambda | V | a lambda>_J <j m j_occ m_occ | J M>^2, where a,b and lambda have fixed n,l,j values only.
//
// This leads to a physical potential as the SD effectively considered for the HF potential has J[SD] = j, which is that of the single-particle or single-hole ground state.
//
// If one has a single-particle above closed-shells, all 1p-1h excitations from the last occupied (l,j) shell to other shells vanish, so that this spherical potential is very close to the exact HF potential.
// If one has a single hole inside closed shells, 1p-1h excitations do not vanish but this HF potential is also closer to the exact HF potential as one does not average over m quantum numbers.

double HF_potentials_common::uniform_filling_approximation::J_coefficient_calc (
										const int l , 
										const double j , 
										const int l_occ , 
										const double j_occ , 
										const int J ,  
										const class CG_str &CGs , 
										const class HF_nucleons_data &HF_data , 
										const class HF_nucleons_data &HF_data_occ)
{
  const bool is_it_uniform_filling_approximation = HF_data.get_is_it_uniform_filling_approximation ();

  const unsigned int N_occ_largest_n = N_in_lj_shell_largest_n_calc (l_occ , j_occ , HF_data_occ); 
  
  if (is_it_uniform_filling_approximation)
    {
      const double J_coefficient = (N_occ_largest_n/(2.0*j_occ + 1.0))*((2.0*J + 1.0)/(2.0*j + 1.0));
      
      return J_coefficient;
    }
  else
    {
      const unsigned int N_largest_n = N_in_lj_shell_largest_n_calc (l , j , HF_data); 

      double J_coefficient = 0.0;

      for (unsigned int m_index = 0 ; m_index < N_largest_n ; m_index++)
	for (unsigned int m_occ_index = 0 ; m_occ_index < N_occ_largest_n ; m_occ_index++)
	  {
	    const double m = j - m_index;

	    const double m_occ = j_occ - m_occ_index;

	    const double M = m + m_occ;

	    const double CG = CGs(j , m , j_occ , m_occ , J , M);
	    
	    J_coefficient += CG*CG;
	  }

      J_coefficient /= N_largest_n;

      return J_coefficient;
    } 
}




