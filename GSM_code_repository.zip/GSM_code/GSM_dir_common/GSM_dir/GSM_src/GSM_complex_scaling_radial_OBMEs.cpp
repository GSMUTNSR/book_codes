#include "../GSM_include/GSM_include_def_common.h"

using namespace Wigner_signs;


// TYPE is double or complex
// -------------------------


// Calculation of the radial integral before R with complex scaling
// ----------------------------------------------------------------
// The calculation of a radial integral with complex scaling writes:
// \int_0^R u_i(r) O(r) u_f(r) dr + \sum_{si = +/-, sf = +/-} \int u_i^(si)(R + (x-R) e^{i theta}) O(R + (x-R) e^{i theta}) u_f^(sf)(R + (x-R) e^{i theta}) e^{i theta} dx
// where R is the rotation point, O(r) is the radial operator, u_i(r) and u_f(r) are the in and out states, u_i^(+/-) and u_f^(+/-) are the incoming/outgoing parts of u_i(r) and u_f(r).
// One calculates \int_0^R u_i(r) O(r) u_f(r) dr in this routine.
// One uses Gauss-Legendre integration.
// u_i(r) and u_f(r) can be replaced by their derivatives for overlap of function and derivative.

complex<double> complex_scaling_radial_OBMEs::radial_integral_bef_R_calc (
									  const enum radial_operator_type radial_operator , 
									  const int Z_charge , 
									  const double R_charge , 
									  const class spherical_state &wf_in , 
									  const class spherical_state &wf_out)
{
  const unsigned int N_bef_R_GL = wf_in.get_N_bef_R_GL ();
  
  const enum particle_type particle = wf_in.get_particle ();

  const class array<double> &r_bef_R_tab_GL = wf_in.get_r_bef_R_tab_GL ();
  const class array<double> &w_bef_R_tab_GL = wf_in.get_w_bef_R_tab_GL ();
  
  const class array<complex<double> > &wf_in_bef_R_tab_GL = wf_in.get_wf_bef_R_tab_GL ();
  
  const class array<complex<double> > &wf_out_bef_R_tab_GL = wf_out.get_wf_bef_R_tab_GL ();
  
  const class array<complex<double> > &dwf_in_bef_R_tab_GL = wf_in.get_dwf_bef_R_tab_GL ();
  
  const class array<complex<double> > &dwf_out_bef_R_tab_GL = wf_out.get_dwf_bef_R_tab_GL ();

  const class Coulomb_potential_class Coulomb_potential(false , particle , Z_charge , R_charge);

  complex<double> radial_integral_bef_R = 0.0;

  switch (radial_operator)
    {
    case OVERLAP:
      {
	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	  {
	    const double w = w_bef_R_tab_GL(i);

	    const complex<double> wf_in_r  = wf_in_bef_R_tab_GL(i);
	    const complex<double> wf_out_r = wf_out_bef_R_tab_GL(i);
	  	  
	    radial_integral_bef_R += w*wf_out_r*wf_in_r;
	  }
	
      } break;

    case OVERLAP_WF_DWF:
      {
	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	  {
	    const double w = w_bef_R_tab_GL(i);
	  
	    const complex<double> wf_in_r  = wf_in_bef_R_tab_GL(i);
	    const complex<double> wf_out_r = wf_out_bef_R_tab_GL(i);
	  
	    const complex<double> dwf_in_r  = dwf_in_bef_R_tab_GL(i);	  
	    const complex<double> dwf_out_r = dwf_out_bef_R_tab_GL(i);
	  
	    radial_integral_bef_R += w*(wf_out_r*dwf_in_r + dwf_out_r*wf_in_r);
	  }
	
      } break;
	 
    case ONE_BODY_COULOMB_RADIAL:
      {
	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	  {
	    const double r = r_bef_R_tab_GL(i);
	    const double w = w_bef_R_tab_GL(i);

	    const double Coulomb_potential_r = Coulomb_potential.analytic_potential_calc (r);

	    const complex<double> wf_in_r  = wf_in_bef_R_tab_GL(i);
	    const complex<double> wf_out_r = wf_out_bef_R_tab_GL(i);
	  
	    radial_integral_bef_R += w*wf_out_r*wf_in_r*Coulomb_potential_r;

	  }
	
      } break;
	
    default: abort_all ();
    }

  return radial_integral_bef_R;
}








// Calculation of one radial integral out of the four integrals after R with complex scaling
// -----------------------------------------------------------------------------------------
// The calculation of a radial integral with complex scaling writes:
// \int_0^R u_i(r) O(r) u_f(r) dr + \sum_{si = +/-, sf = +/-} \int u_i^(si)(R + (x-R) e^{i theta}) O(R + (x-R) e^{i theta}) u_f^(sf)(R + (x-R) e^{i theta}) e^{i theta} dx
// where R is the rotation point, O(r) is the radial operator, u_i(r) and u_f(r) are the in and out states, u_i^(+/-) and u_f^(+/-) are the incoming/outgoing parts of u_i(r) and u_f(r).
// One calculates  \int_0^R u_i^(si)(R + (x-R) e^{i theta}) O(R + (x-R) e^{i theta}) u_f^(sf)(R + (x-R) e^{i theta}) dx for fixed values of si and sf in this routine.
// One has four integrals in \sum_{si = +/-, sf = +/-} if u_i(r) and u_f(r) are scattering, which justifies the term part_of_four of the routine 
// theta is equal to +/- Pi/4 or +/- 3.Pi/4 and is determined from ki and kf values of u_i(r) and u_f(r).
// One uses Gauss-Legendre integration with the x -> x^(-4) change of variable so that the [R:+oo[ interval is replaced by the [0:R^(-1/4)] interval, which is the most stable change of variable to calculate improper integrals. 
// Scaled wave functions are used for u_i(r) and u_f(r) with exterior complex scaling for stability, 
// so that u_i^(si)(r) = u_i^(si, scaled)(r) exp (i.si.(ki.r - eta_i.log (2.ki.r) and u_f^(sf)(r) = u_f^(sf, scaled)(r) exp (i.sf.(kf.r - eta_f.log (2.kf.r).
// Indeed, u_i(r) and u_f(r) can overflow due to their exponential factor, while their product remains finite.
// u_i(r) and u_f(r) can be replaced by their derivatives for overlap of function and derivative
// The additional factor 4 at the end of the calculation comes from the x -> x^(-4) change of variable.

complex<double> complex_scaling_radial_OBMEs::radial_integral_aft_R_part_of_four_calc (
										       const enum radial_operator_type radial_operator , 
										       const int Z_charge , 
										       const unsigned int asy_in , 
										       const unsigned int asy_out , 
										       const class spherical_state &wf_in , 
										       const class spherical_state &wf_out)
{
  const unsigned int N_aft_R_GL = wf_in.get_N_aft_R_GL ();
  
  const class array<double> &um4_table = wf_in.get_um4_aft_R_tab_GL ();
  
  const class array<double> &w_aft_R_tab_GL = wf_in.get_w_aft_R_tab_GL ();

  const enum particle_type particle = wf_in.get_particle ();
  
  const complex<double> k_in = wf_in.get_k ();
  
  const complex<double> k_out = wf_out.get_k ();

  const complex<double> eta_in = wf_in.get_eta ();
  
  const complex<double> eta_out = wf_out.get_eta ();
  
  const int omega_in = minus_one_pow (asy_in);
  
  const int omega_out = minus_one_pow (asy_out);
  
  const complex<double> Sk = k_in*omega_in + k_out*omega_out;

  const complex<double> I_omega_in(0 , omega_in);
  
  const complex<double> I_omega_out(0 , omega_out);
  
  const unsigned int angle_index = optimal_angle_index (Sk);
  
  const complex<double> exp_Itheta(cos_theta_tab[angle_index] , sin_theta_tab[angle_index]);
  
  const class array<complex<double> > &sc_wf_in_aft_R_tab_GL  = wf_in.get_scaled_wf_aft_R_tab_GL ();
  
  const class array<complex<double> > &sc_dwf_in_aft_R_tab_GL = wf_in.get_scaled_dwf_aft_R_tab_GL ();
  
  const class array<complex<double> > &sc_wf_out_aft_R_tab_GL  = wf_out.get_scaled_wf_aft_R_tab_GL ();
  
  const class array<complex<double> > &sc_dwf_out_aft_R_tab_GL = wf_out.get_scaled_dwf_aft_R_tab_GL ();
  
  const double R = wf_in.get_R ();

  const class Coulomb_potential_class Coulomb_potential(false , particle , Z_charge , NADA);

  complex<double> radial_integral_aft_R_part_of_four = 0.0;

  switch (radial_operator)
    {
    case OVERLAP: 
      {
	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	  { 
	    const complex<double> z = R + (um4_table(i) - R)*exp_Itheta;
            
	    const complex<double> k_in_z  = k_in*z;
	    const complex<double> k_out_z = k_out*z;
      
	    const complex<double> log_unscale_in  = (k_in != 0.0)  ? (I_omega_in *(k_in_z  - eta_in *(M_LN2 + log (k_in_z))))  : (0.0);
	    const complex<double> log_unscale_out = (k_out != 0.0) ? (I_omega_out*(k_out_z - eta_out*(M_LN2 + log (k_out_z)))) : (0.0);

	    const complex<double> unscale_weight = exp (log_unscale_in + log_unscale_out)*w_aft_R_tab_GL(i);

	    const complex<double> sc_wf_in_r = sc_wf_in_aft_R_tab_GL (asy_in , angle_index , i);
	    
	    const complex<double> sc_wf_out_r = sc_wf_out_aft_R_tab_GL(asy_out , angle_index , i);
      
	    radial_integral_aft_R_part_of_four += sc_wf_out_r*sc_wf_in_r*unscale_weight;
	  }

      } break;


    case OVERLAP_WF_DWF:
      {
	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	  { 
	    const complex<double> z = R + (um4_table(i) - R)*exp_Itheta;
      
	    const complex<double> k_in_z  = k_in*z;
	    const complex<double> k_out_z = k_out*z;
      
	    const complex<double> log_unscale_in  = (k_in != 0.0)  ? (I_omega_in *(k_in_z  - eta_in *(M_LN2 + log (k_in_z))))  : (0.0);
	    const complex<double> log_unscale_out = (k_out != 0.0) ? (I_omega_out*(k_out_z - eta_out*(M_LN2 + log (k_out_z)))) : (0.0);

	    const complex<double> unscale_weight = exp (log_unscale_in + log_unscale_out)*w_aft_R_tab_GL(i);

	    const complex<double> sc_wf_in_r  = sc_wf_in_aft_R_tab_GL (asy_in , angle_index , i);
	    const complex<double> sc_dwf_in_r = sc_dwf_in_aft_R_tab_GL(asy_in , angle_index , i);
      
	    const complex<double> sc_wf_out_r =  sc_wf_out_aft_R_tab_GL (asy_out , angle_index , i);
	    const complex<double> sc_dwf_out_r = sc_dwf_out_aft_R_tab_GL(asy_out , angle_index , i);

	    radial_integral_aft_R_part_of_four += (sc_wf_out_r*sc_dwf_in_r + sc_dwf_out_r*sc_wf_in_r)*unscale_weight;
	  }

      } break;

    case ONE_BODY_COULOMB_RADIAL:
      {
	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	  { 
	    const complex<double> z = R + (um4_table(i) - R)*exp_Itheta;
      
	    const complex<double> Coulomb_potential_z = Coulomb_potential.point_potential_calc (z);
      
	    const complex<double> k_in_z  = k_in*z;
	    const complex<double> k_out_z = k_out*z;
      
	    const complex<double> log_unscale_in  = (k_in != 0.0)  ? (I_omega_in *(k_in_z  - eta_in *(M_LN2 + log (k_in_z))))  : (0.0);
	    const complex<double> log_unscale_out = (k_out != 0.0) ? (I_omega_out*(k_out_z - eta_out*(M_LN2 + log (k_out_z)))) : (0.0);

	    const complex<double> unscale_weight = exp (log_unscale_in + log_unscale_out)*w_aft_R_tab_GL(i);

	    const complex<double> sc_wf_in_r  = sc_wf_in_aft_R_tab_GL (asy_in  , angle_index , i);
	    const complex<double> sc_wf_out_r = sc_wf_out_aft_R_tab_GL(asy_out , angle_index , i);
	    
	    radial_integral_aft_R_part_of_four += sc_wf_out_r*sc_wf_in_r*Coulomb_potential_z*unscale_weight;
	  }
      } break;

    default: abort_all ();      
    }
  
  radial_integral_aft_R_part_of_four *= 4.0*exp_Itheta;
  
  return radial_integral_aft_R_part_of_four;
}




// Calculation of the radial integral sum of the four integrals after R with complex scaling
// -----------------------------------------------------------------------------------------
// The calculation of a radial integral with complex scaling writes:
// \int_0^R u_i(r) O(r) u_f(r) dr + \sum_{si = +/-, sf = +/-} \int u_i^(si)(R + (x-R) e^{i theta}) O(R + (x-R) e^{i theta}) u_f^(sf)(R + (x-R) e^{i theta}) e^{i theta} dx
// where R is the rotation point, O(r) is the radial operator, u_i(r) and u_f(r) are the in and out states, u_i^(+/-) and u_f^(+/-) are the incoming/outgoing parts of u_i(r) and u_f(r).
// The four integrals (in fact less than four if u_i(r) or u_f(r) are pole states) in \sum_{si = +/-, sf = +/-} are called, summed and retuned here.

complex<double> complex_scaling_radial_OBMEs::radial_integral_aft_R_calc (
									  const enum radial_operator_type radial_operator , 
									  const int Z_charge , 
									  const class spherical_state &wf_in , 
									  const class spherical_state &wf_out)
{
  const bool S_matrix_pole_in = wf_in.get_S_matrix_pole ();
  
  const bool S_matrix_pole_out = wf_out.get_S_matrix_pole ();

  complex<double> integral_aft_R = 0.0;

  for (unsigned int asy_in = 0 ; (S_matrix_pole_in) ? (asy_in <= 0) : (asy_in <= 1) ; asy_in++)
    for (unsigned int asy_out = 0 ; (S_matrix_pole_out) ? (asy_out <= 0) : (asy_out <= 1) ; asy_out++)
      integral_aft_R += radial_integral_aft_R_part_of_four_calc (radial_operator , Z_charge , asy_in , asy_out , wf_in , wf_out);

  return integral_aft_R;
}








// Calculation of the radial integral before R with complex scaling
// ----------------------------------------------------------------
// The calculation of a radial integral with complex scaling writes:
// \int_0^R u_i(r) O(r) u_f(r) dr + \sum_{si = +/-, sf = +/-} \int u_i^(si)(R + (x-R) e^{i theta}) O(R + (x-R) e^{i theta}) u_f^(sf)(R + (x-R) e^{i theta}) e^{i theta} dx
// where R is the rotation point, O(r) is the radial operator, u_i(r) and u_f(r) are the in and out states, u_i^(+/-) and u_f^(+/-) are the incoming/outgoing parts of u_i(r) and u_f(r).
// The parts before and after R are called and summed hereand returned.
// One checks if complex scaling is possible, which is not the case if has scattering in and out states with equal linear momenta, 
// as then \int u_i^(+)(z) O(z) u_f^(-)(z) dz cannot converge with any rotation angle (Dirac delta case when O(z) = 1).
// The code stops in this latter case.
// 0 is returned if Z_charge is 0 as there is no calculation to do in this case.

TYPE complex_scaling_radial_OBMEs::radial_integral_calc (
							 const enum radial_operator_type radial_operator , 
							 const int Z_charge , 
							 const double R_charge , 
							 const class spherical_state &wf_in , 
							 const class spherical_state &wf_out)
{
  if ((radial_operator == ONE_BODY_COULOMB_RADIAL) && (Z_charge == 0)) return 0.0;

  const bool S_matrix_pole_in = wf_in.get_S_matrix_pole ();
  
  const bool S_matrix_pole_out = wf_out.get_S_matrix_pole ();
  
  const complex<double> k_in = wf_in.get_k ();
  
  const complex<double> k_out = wf_out.get_k ();

  for (unsigned int asy_in = 0 ; (S_matrix_pole_in) ? (asy_in <= 0) : (asy_in <= 1) ; asy_in++)
    for (unsigned int asy_out = 0 ; (S_matrix_pole_out) ? (asy_out <= 0) : (asy_out <= 1) ; asy_out++)
      { 
	const complex<double> Sk = k_in*minus_one_pow (asy_in) + k_out*minus_one_pow (asy_out);
	
	if ((inf_norm (Sk) < precision) && !S_matrix_pole_in && !S_matrix_pole_out) error_message_print_abort ("Complex scaling impossible in complex_scaling_radial_OBMEs::radial_integral_calc.");
      }

  const complex<double> OBME_bef_R = radial_integral_bef_R_calc (radial_operator , Z_charge , R_charge , wf_in , wf_out);
  const complex<double> OBME_aft_R = radial_integral_aft_R_calc (radial_operator , Z_charge            , wf_in , wf_out);

  const complex<double> OBME = OBME_bef_R + OBME_aft_R;
  
#ifdef TYPEisDOUBLECOMPLEX
  return OBME;
#endif
  
#ifdef TYPEisDOUBLE
  return real (OBME);
#endif
}


