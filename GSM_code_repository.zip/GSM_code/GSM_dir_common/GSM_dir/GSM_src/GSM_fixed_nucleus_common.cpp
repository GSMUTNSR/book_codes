#include "../GSM_include/GSM_include_def_common.h"  

using namespace inputs_misc;
using namespace string_routines;


// TYPE is double or complex
// ----------------------------


// All routines here deal with a nucleus with fixed number of protons and neutrons.
// One can deal with several eigenstates per nucleus in these routines.



// Calculation of the one-body matrix elements (OBMEs) of the interaction after modification of its parameters
// -----------------------------------------------------------------------------------------------------------

void fixed_nucleus_common::OBMEs_inter_calc (
				      const class interaction_class &inter_data ,
				      const class baryons_data &neut_Y_data ,
				      class baryons_data &data)
{
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  const unsigned int N_nlj = data.get_N_nlj_baryon (); 

  class OBMEs_inter_set_str &OBMEs_inter_set = data.get_OBMEs_inter_set ();

  const class array<TYPE> OBMEs_nuclear_old = OBMEs_inter_set(ONE_BODY_NUCLEAR);
  
  class array<TYPE> OBMEs_nuclear_new(N_nlj , N_nlj);
    
  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
      OBMEs_nuclear_new(s_in , s_out) = H_CM_OBMEs::coupled_OBME_inter_calc (ONE_BODY_NUCLEAR , inter_data , 0.0 , s_in , s_out , neut_Y_data , data);
  
  OBMEs_inter_set(ONE_BODY_NUCLEAR) = OBMEs_nuclear_new;

  OBMEs_inter_set(TBME_inter) -= OBMEs_nuclear_old;
  OBMEs_inter_set(TBME_inter) += OBMEs_nuclear_new;
}


// Removal of double-counting in OBMEs issued by the use of holes in the core
// --------------------------------------------------------------------------

void fixed_nucleus_common::OBMEs_hole_double_counting_calc_remove (
							    const class input_data_str &input_data , 
							    const class TBMEs_class &TBMEs_pn , 
							    const class interaction_class &inter_data ,
							    class baryons_data &prot_Y_data ,
							    class baryons_data &neut_Y_data)
{
  const bool is_hole_double_counting_suppressed = input_data.get_is_hole_double_counting_suppressed ();
  
  if (!is_hole_double_counting_suppressed) return;
  
  const enum space_type space = input_data.get_space ();
  
  const int n_scat_max = input_data.get_n_scat_max ();
  
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  const unsigned int Np_nlj = prot_Y_data.get_N_nlj_baryon (); 
  const unsigned int Nn_nlj = neut_Y_data.get_N_nlj_baryon (); 

  if (space != NEUT_Y_ONLY)
    {
      class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
  
      const class array<TYPE> OBMEs_p_hole_double_counting_old = OBMEs_p_inter_set(HOLE_DOUBLE_COUNTING);
  
      class array<TYPE> OBMEs_p_hole_double_counting_new(Np_nlj , Np_nlj);
  
      for (unsigned int sp_in = 0 ; sp_in < Np_nlj ; sp_in++)
	for (unsigned int sp_out = 0 ; sp_out < Np_nlj ; sp_out++)
	  OBMEs_p_hole_double_counting_new(sp_in , sp_out) = hole_double_counting::prot_OBME_calc (false , space , n_scat_max , TBMEs_pn , prot_Y_data , neut_Y_data , sp_in , sp_out);
  
      OBMEs_p_inter_set(HOLE_DOUBLE_COUNTING) = OBMEs_p_hole_double_counting_new;
      
      OBMEs_p_inter_set(TBME_inter) += OBMEs_p_hole_double_counting_old;  
      OBMEs_p_inter_set(TBME_inter) -= OBMEs_p_hole_double_counting_new;
    }
  
  if (space != PROT_Y_ONLY)
    {
      class OBMEs_inter_set_str &OBMEs_n_inter_set = neut_Y_data.get_OBMEs_inter_set ();

      const class array<TYPE> OBMEs_n_hole_double_counting_old = OBMEs_n_inter_set(HOLE_DOUBLE_COUNTING);

      class array<TYPE> OBMEs_n_hole_double_counting_new(Nn_nlj , Nn_nlj);
    
      for (unsigned int sn_in = 0 ; sn_in < Nn_nlj ; sn_in++)
	for (unsigned int sn_out = 0 ; sn_out < Nn_nlj ; sn_out++)
	  OBMEs_n_hole_double_counting_new(sn_in , sn_out) = hole_double_counting::neut_OBME_calc (false , space , n_scat_max , TBMEs_pn , prot_Y_data , neut_Y_data , sn_in , sn_out);
  
      OBMEs_n_inter_set(HOLE_DOUBLE_COUNTING) = OBMEs_n_hole_double_counting_new;

      OBMEs_n_inter_set(TBME_inter) += OBMEs_n_hole_double_counting_old;
      OBMEs_n_inter_set(TBME_inter) -= OBMEs_n_hole_double_counting_new;
    }
}






// Calculation of the one-body matrix elements (OBMEs) and two-body matrix elements (TBMEs) of the interaction after modification of its parameters
// ------------------------------------------------------------------------------------------------------------------------------------------------

void fixed_nucleus_common::OBMEs_TBMEs_calc (
				      const class input_data_str &input_data , 
				      const class array<class interaction_class > &inter_data_units , 
				      const class interaction_class &inter_data_Coulomb , 
				      const class vector_class<double> &FHT_EFT_parameters , 
				      class interaction_class &inter_data , 
				      class TBMEs_class &TBMEs_pn ,  
				      class TBMEs_class &TBMEs_cv , 
				      class baryons_data &prot_Y_data , 
				      class baryons_data &neut_Y_data)
{
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const enum space_type space = input_data.get_space ();

  const bool are_there_basis_p_natural_orbitals = prot_Y_data.get_are_there_basis_natural_orbitals ();
  const bool are_there_basis_n_natural_orbitals = neut_Y_data.get_are_there_basis_natural_orbitals ();
  
  const string debut_file_name_p = prot_Y_data.get_debut_file_name ();
  const string debut_file_name_n = neut_Y_data.get_debut_file_name ();
  
  const enum interaction_type inter = input_data.get_inter ();

  const double frozen_core_mass = input_data.get_frozen_core_mass ();
  
  const int ZYval = input_data.get_ZYval ();
  const int NYval = input_data.get_NYval ();

  const bool print_detailed_information = input_data.get_print_detailed_information ();
  
  const double TBME_A_dependent_factor = TBME_A_dependent_factor_calc (input_data);
	    
  inter_data.calculate_from_units_Coulomb_kinetic (frozen_core_mass , FHT_EFT_parameters , TBME_A_dependent_factor , inter_data_units , inter_data_Coulomb);
  
  if (space != NEUT_Y_ONLY)
    {
      OBMEs_inter_calc (inter_data , neut_Y_data , prot_Y_data);

      if (ZYval >= 2) coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (print_detailed_information , inter , input_data , true , inter_data , prot_Y_data);
    }

  if (space != PROT_Y_ONLY)
    {
      OBMEs_inter_calc (inter_data , neut_Y_data , neut_Y_data);

      if (NYval >= 2) coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (print_detailed_information , inter , input_data , true , inter_data , neut_Y_data);
    }

  if (space == PROT_NEUT_Y)
    {
      coupled_TBMEs::Berggren::TBMEs_pn_calc (print_detailed_information , false , inter , input_data , prot_Y_data , neut_Y_data , true , inter_data , TBMEs_pn);
      coupled_TBMEs::Berggren::TBMEs_cv_calc (print_detailed_information         , inter , input_data , prot_Y_data , neut_Y_data        , inter_data , TBMEs_cv);
    }
  
  OBMEs_hole_double_counting_calc_remove (input_data , TBMEs_pn , inter_data , prot_Y_data , neut_Y_data);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_basis_p_natural_orbitals)
    {
      const class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();
      
      OBMEs_p_inter_set.copy_disk (TBME_inter , debut_file_name_p);
    }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && are_there_basis_n_natural_orbitals)
    {
      const class OBMEs_inter_set_str &OBMEs_n_inter_set = neut_Y_data.get_OBMEs_inter_set ();
      
      OBMEs_n_inter_set.copy_disk (TBME_inter , debut_file_name_n);
    }
}





// Calculation of the gradients of one-body matrix elements (OBMEs) and two-body matrix elements (TBMEs) of the interaction after modification of its parameters with respect to Hamiltonian parameters
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

void fixed_nucleus_common::OBMEs_TBMEs_grad_calc (
					   const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
					   const class array<bool> &is_there_l_dependence_from_fit_index , 
					   const class array<int> &l_from_fit_index , 
					   const class input_data_str &input_data , 
					   const class array<class interaction_class> &inter_data_units , 
					   const unsigned int fit_index , 
					   class interaction_class &inter_data , 
					   class TBMEs_class &TBMEs_pn , 
					   class TBMEs_class &TBMEs_cv , 
					   class baryons_data &prot_Y_data , 
					   class baryons_data &neut_Y_data)
{	      
  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();

  const bool print_detailed_information = input_data.get_print_detailed_information ();
  
  const enum FHT_EFT_parameter_type FHT_EFT_parameter = FHT_EFT_parameters_from_fit_index(fit_index);

  const bool is_there_l_dependence = is_there_l_dependence_from_fit_index(fit_index);
  
  const bool is_cv_possible = input_data.get_is_cv_possible ();
  
  const int ZYval = input_data.get_ZYval ();
  const int NYval = input_data.get_NYval ();
  
  const int l = l_from_fit_index(fit_index);

  const bool is_it_p_grad = is_it_FHT_EFT_one_body_charged_baryon_determine   (FHT_EFT_parameter);
  const bool is_it_n_grad = is_it_FHT_EFT_one_body_uncharged_baryon_determine (FHT_EFT_parameter);

  const bool is_it_two_body_grad = (!is_it_p_grad && !is_it_n_grad);

  const bool is_one_body_p_non_zero = (is_it_p_grad && (space != NEUT_Y_ONLY));
  const bool is_one_body_n_non_zero = (is_it_n_grad && (space != PROT_Y_ONLY));

  const bool is_it_FHT_EFT_parameter_pp_nn = is_it_FHT_EFT_parameter_pp_nn_determine (FHT_EFT_parameter);
  
  const bool is_pp_non_zero = ((ZYval >= 2) && is_it_FHT_EFT_parameter_pp_nn);
  const bool is_nn_non_zero = ((NYval >= 2) && is_it_FHT_EFT_parameter_pp_nn);
  
  const bool is_pn_non_zero = ((space == PROT_NEUT_Y) && is_it_two_body_grad);
  
  const bool is_cv_non_zero = (is_cv_possible && is_it_two_body_grad);
    
  if (is_one_body_p_non_zero || is_one_body_n_non_zero || is_pp_non_zero || is_nn_non_zero || is_pn_non_zero || is_cv_non_zero)
    {      
      if (is_it_two_body_grad)
	{
	  const double TBME_A_dependent_factor = TBME_A_dependent_factor_calc (input_data);
      
	  inter_data.calculate_grad_from_units (inter_data_units , TBME_A_dependent_factor , FHT_EFT_parameter);
	}

      if (space == PROT_NEUT_Y) TBMEs_pn.zero ();

      if (space != NEUT_Y_ONLY)
	{
	  class OBMEs_inter_set_str &OBMEs_p_inter_set = prot_Y_data.get_OBMEs_inter_set ();

	  OBMEs_p_inter_set(inter) = 0.0;

	  class TBMEs_class &TBMEs_p = prot_Y_data.get_TBMEs ();

	  if (ZYval >= 2) TBMEs_p.zero ();
	  
	  if (is_one_body_p_non_zero)
	    {
	      const double A_dependent_factor_core_potential = A_dependent_factor_core_potential_calc (PROTON , input_data);
      
	      OBMEs_TBMEs::Berggren::calc_WS_derivative (FHT_EFT_parameter , is_there_l_dependence , l , A_dependent_factor_core_potential , prot_Y_data);
  
	      OBMEs_p_inter_set(inter) = OBMEs_p_inter_set(WS_DERIVATIVE);
	    }
	  
	  if (is_pp_non_zero) coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (print_detailed_information , inter , input_data , false , inter_data , prot_Y_data);
	}

      if (space != PROT_Y_ONLY)
	{
	  class OBMEs_inter_set_str &OBMEs_n_inter_set = neut_Y_data.get_OBMEs_inter_set ();

	  OBMEs_n_inter_set(inter) = 0.0;

	  class TBMEs_class &TBMEs_n = neut_Y_data.get_TBMEs ();

	  if (NYval >= 2) TBMEs_n.zero ();
	  
	  if (is_one_body_n_non_zero)
	    {
	      const double A_dependent_factor_core_potential = A_dependent_factor_core_potential_calc (NEUTRON , input_data);
	      
	      OBMEs_TBMEs::Berggren::calc_WS_derivative (FHT_EFT_parameter , is_there_l_dependence ,  l , A_dependent_factor_core_potential , neut_Y_data);
	      
	      OBMEs_n_inter_set(inter) = OBMEs_n_inter_set(WS_DERIVATIVE);
	    }
	  
	  if (is_nn_non_zero) coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (print_detailed_information , inter , input_data , false , inter_data , neut_Y_data);
	}

      if (is_pn_non_zero) coupled_TBMEs::Berggren::TBMEs_pn_calc (print_detailed_information , false , inter , input_data , prot_Y_data , neut_Y_data , false , inter_data , TBMEs_pn);

      if (is_cv_non_zero) coupled_TBMEs::Berggren::TBMEs_cv_calc (print_detailed_information , inter , input_data , prot_Y_data , neut_Y_data , inter_data , TBMEs_cv);

      hole_double_counting::prot_neut_OBMEs_calc_store_remove (true , input_data , prot_Y_data , neut_Y_data , TBMEs_pn);
    }
}


