#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------


// Determination of the shell indices of HO states from their quantum numbers
// --------------------------------------------------------------------------
// One stores the shell indices of HO states (those of the one-dimensional array shell_HO_table of interaction_class) from their n,l,j indices in an integer array for convenience and efficiency.
// One has HO_index_from_n_tab(n) = s, with s the shell index of the (n,l,j) shell.
// The (l,j) quantum numbers are given directly, or from an nlj_struct or nljm_struct.
// This is done sequentially by looping over all the shells of shell_HO_table.

void HF_potentials_common::HO_expansion_part_common::HO_index_from_n_tab_determine (
										    const int l , 
										    const double j , 
										    const class interaction_class &inter_data_basis , 
										    class array<unsigned int> &HO_index_from_n_tab)
{
  const unsigned int N_nlj_HO = inter_data_basis.get_N_nlj_HO ();
  
  const class array<class nlj_struct> &shells_HO_table = inter_data_basis.get_shells_HO_table ();

  for (unsigned int s = 0 ; s < N_nlj_HO ; s++)
    {
      const class nlj_struct &shell = shells_HO_table(s);

      const int ns = shell.get_n ();
      
      const int ls = shell.get_l ();

      const double js = shell.get_j ();

      if (same_lj (l , j , ls , js)) HO_index_from_n_tab(ns) = s;
    }
}

void HF_potentials_common::HO_expansion_part_common::HO_index_from_n_tab_determine (
										    const class nlj_struct &shell_lj , 
										    const class interaction_class &inter_data_basis , 
										    class array<unsigned int> &HO_index_from_n_tab)
{
  const unsigned int N_nlj_HO = inter_data_basis.get_N_nlj_HO ();
  
  const class array<class nlj_struct> &shells_HO_table = inter_data_basis.get_shells_HO_table ();

  for (unsigned int s = 0 ; s < N_nlj_HO ; s++)
    {
      const class nlj_struct &shell = shells_HO_table(s);
      
      const int ns = shell.get_n ();
      
      if (same_lj (shell_lj , shell)) HO_index_from_n_tab(ns) = s;
    }
}

void HF_potentials_common::HO_expansion_part_common::HO_index_from_n_tab_determine (
										    const class nljm_struct &phi_lj , 
										    const class interaction_class &inter_data_basis , 
										    class array<unsigned int> &HO_index_from_n_tab)
{
  const unsigned int N_nlj_HO = inter_data_basis.get_N_nlj_HO ();
  
  const class array<class nlj_struct> &shells_HO_table = inter_data_basis.get_shells_HO_table ();

  for (unsigned int s = 0 ; s < N_nlj_HO ; s++)
    {
      const class nlj_struct &shell = shells_HO_table(s);
      
      const int ns = shell.get_n ();
      
      if (same_lj (phi_lj , shell)) HO_index_from_n_tab(ns) = s;
    }
}










// Calculation of the overlaps between HF/OCM wave functions with HO states for the HO expansion of the interaction
// ----------------------------------------------------------------------------------------------------------------
// One calculates <n l j | n[HO] l j> and <n l j | F(r) | n[HO] l j> where F(r) is a Fermi function used for stability, as potentials do not necessarily vanish at large distance.
// In HO_overlaps_calc, one selects either arrays containing all HF/OCM wave functions, or those with only bound and resonant (res) states, as only poles can be occupied at HF level.
// In HO_overlaps_pm_calc, one considers proton states with k +/- w/(4 Pi), used for Coulomb complex scaling (see H_CM_OBMEs.cpp) (pm is +/-).

void HF_potentials_common::HO_expansion_part_common::HO_overlaps_calc (
								       const class interaction_class &inter_data_basis , 
								       const class array<class spherical_state > &shells , 
								       const class HF_nucleons_data &HF_data , 
								       class array<class vector_class<complex<double> > > &HO_overlaps , 
								       class array<class vector_class<complex<double> > > &HO_overlaps_Fermi)
{
  const unsigned int N_nlj = shells.dimension (0);

  const double R_cut_function = HF_data.get_R_cut_function ();
  const double d_cut_function = HF_data.get_d_cut_function ();

  const int lmax_for_interaction = inter_data_basis.get_lmax_for_interaction();
  
  const class array<double> &r_bef_R_tab_GL = inter_data_basis.get_r_bef_R_tab_GL () , &w_bef_R_tab_GL = inter_data_basis.get_w_bef_R_tab_GL ();
  const class array<double> &r_aft_R_tab_GL = inter_data_basis.get_r_aft_R_tab_GL () , &w_aft_R_tab_GL = inter_data_basis.get_w_aft_R_tab_GL ();

  const class array<double> &HO_wfs_bef_R_tab_GL = inter_data_basis.get_HO_wfs_bef_R_tab_GL ();
  const class array<double> &HO_wfs_aft_R_tab_GL = inter_data_basis.get_HO_wfs_aft_R_tab_GL ();

  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();
  
  const unsigned int N_bef_R_GL = r_bef_R_tab_GL.dimension (0);
  const unsigned int N_aft_R_GL = r_aft_R_tab_GL.dimension (0);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class spherical_state &shell = shells(s);

      if (shell.is_it_filled ())
	{
	  const int l = shell.get_l ();

	  const int nmax_HO_l = (l <= lmax_for_interaction) ? (nmax_HO_lab_tab(l)) : (0);

	  const int nmax_HO_l_plus_one = nmax_HO_l + 1;
      
	  class vector_class<complex<double> > &HO_overlaps_shell = HO_overlaps(s);
	  
	  class vector_class<complex<double> > &HO_overlaps_Fermi_shell = HO_overlaps_Fermi(s);

	  HO_overlaps_shell.deallocate ();
	  HO_overlaps_shell.allocate (nmax_HO_l_plus_one);

	  HO_overlaps_Fermi_shell.deallocate ();
	  HO_overlaps_Fermi_shell.allocate (nmax_HO_l_plus_one);

	  HO_overlaps_shell = 0.0;
	  HO_overlaps_Fermi_shell = 0.0;
	  
	  if (l > lmax_for_interaction) continue;
      
	  const class array<complex<double> > &wf_bef_R_tab_GL = shell.get_wf_bef_R_tab_GL ();
	  const class array<complex<double> > &wf_aft_R_tab_GL = shell.get_wf_aft_R_tab_GL_real ();

	  for (int n_HO = 0 ; n_HO <= nmax_HO_l ; n_HO++)
	    {
	      complex<double> HO_overlap_shell = 0.0;
	      complex<double> HO_overlap_Fermi_shell = 0.0;

	      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
		{
		  const complex<double> product = w_bef_R_tab_GL(i)*wf_bef_R_tab_GL(i)*HO_wfs_bef_R_tab_GL(n_HO , l , i);
		  
		  HO_overlap_shell += product;
		  
		  HO_overlap_Fermi_shell += product*Fermi_like_function (R_cut_function , d_cut_function , r_bef_R_tab_GL(i));
		}

	      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
		{	
		  const complex<double> product = w_aft_R_tab_GL(i)*wf_aft_R_tab_GL(i)*HO_wfs_aft_R_tab_GL(n_HO , l , i);
		  
		  HO_overlap_shell += product;
		  
		  HO_overlap_Fermi_shell += product*Fermi_like_function (R_cut_function , d_cut_function , r_aft_R_tab_GL(i));
		}

	      HO_overlaps_shell(n_HO) = HO_overlap_shell;
	      
	      HO_overlaps_Fermi_shell(n_HO) = HO_overlap_Fermi_shell;
	    }
	  //HO_overlaps_Fermi_shell = HO_overlap_shell;
	}
    }
}

void HF_potentials_common::HO_expansion_part_common::HO_overlaps_calc (
								       const class interaction_class &inter_data_basis , 
								       const bool is_it_res , 
								       class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj = (is_it_res) ? (HF_data.get_N_nlj_res ()) : (HF_data.get_N_nlj ());

  if (N_nlj == 0) return;

  const class array<class spherical_state > &shells = (is_it_res) ? (HF_data.get_shells_res ()) : (HF_data.get_shells ());

  class array<class vector_class<complex<double> > > &HO_overlaps       = (is_it_res) ? (HF_data.get_HO_overlaps_res ())       : (HF_data.get_HO_overlaps ());
  class array<class vector_class<complex<double> > > &HO_overlaps_Fermi = (is_it_res) ? (HF_data.get_HO_overlaps_Fermi_res ()) : (HF_data.get_HO_overlaps_Fermi ());

  HO_overlaps_calc (inter_data_basis , shells , HF_data , HO_overlaps , HO_overlaps_Fermi);
}

void HF_potentials_common::HO_expansion_part_common::HO_overlaps_pm_calc (
									  const int pm , 
									  const class interaction_class &inter_data_basis , 
									  class HF_nucleons_data &HF_data)
{ 
  const unsigned int N_nlj = HF_data.get_N_nlj ();

  if (N_nlj == 0) return;

  const class array<class spherical_state > &shells_pm = (pm == 1) ? (HF_data.get_shells_plus ()) : (HF_data.get_shells_minus ());

  class array<class vector_class<complex<double> > > &HO_overlaps_pm       = (pm == 1) ? (HF_data.get_HO_overlaps_plus ())       : (HF_data.get_HO_overlaps_minus ());
  class array<class vector_class<complex<double> > > &HO_overlaps_Fermi_pm = (pm == 1) ? (HF_data.get_HO_overlaps_Fermi_plus ()) : (HF_data.get_HO_overlaps_Fermi_minus ());

  HO_overlaps_calc (inter_data_basis , shells_pm , HF_data , HO_overlaps_pm , HO_overlaps_Fermi_pm);
}

















// Calculation of the part of the HF potential taking into one two-body matrix element
// -----------------------------------------------------------------------------------
// The HF potential writes <a | U_HF | b> = phase . sqrt (1 + delta_ab) sqrt (1 + delta_cd) . \sum_(s,c,d) <ab | V | cd>_J . weight . <s|c> . <s|d>
// where phase is a reordering phase, weight is function of Clebsch-Gordan coefficients and angular momenta and come from the use of uniform filling approximation,
// a,b,c,d are HO states, with (a,b) and (c,d) coupled to J, and s is the occupied state, expanded in HO states through the use of c and d. 
// V can be Vpp, Vnn or Vpn and U_HF can be that of protons or neutrons.
// The real part of <a | U_HF | b> is considered for the HF potential when it is complex.

double HF_potentials_common::HO_expansion_part_common::Up_HF_abcd_pp_part_J (
									     const unsigned int sp_occ , 
									     const unsigned int a , 
									     const unsigned int b , 
									     const unsigned int c , 
									     const unsigned int d , 
									     const bool same_lj_all_protons , 
									     const complex<double> &weight , 
									     const int J , 
									     const int phase , 
									     const class array<class nlj_struct> &shells_HO_table , 
									     const class array<class vector_class<complex<double> > > &prot_HO_overlaps_occ , 
									     const class TBMEs_class &TBMEs_pp_HO_lab)
{
  const class nlj_struct &sa = shells_HO_table(a);
  const class nlj_struct &sb = shells_HO_table(b);
  const class nlj_struct &sc = shells_HO_table(c);
  const class nlj_struct &sd = shells_HO_table(d);
  
  const int na = sa.get_n ();
  const int nb = sb.get_n ();
  const int nc = sc.get_n ();
  const int nd = sd.get_n ();

  const class vector_class<complex<double> > &prot_HO_overlaps_sp_occ = prot_HO_overlaps_occ(sp_occ);

  const bool is_ac_ordered = (a <= c);
  const bool is_bd_ordered = (b <= d);

  const complex<double> prot_HO_overlaps_product = prot_HO_overlaps_sp_occ(nc)*prot_HO_overlaps_sp_occ(nd);

  const double prot_HO_overlaps_weight_product = real (prot_HO_overlaps_product*weight);

  TYPE TBME_pp = 0.0;
  
  if (is_ac_ordered && is_bd_ordered)
    {
      TBME_pp += TBMEs_pp_HO_lab(J , a , c , b , d);
    }
  else if (!is_ac_ordered && !is_bd_ordered)
    {
      TBME_pp += TBMEs_pp_HO_lab(J , c , a , d , b);
    }
  else if (!is_ac_ordered && is_bd_ordered)
    {
      (phase == 1) ? (TBME_pp -= TBMEs_pp_HO_lab(J , c , a , b , d)) : (TBME_pp += TBMEs_pp_HO_lab(J , c , a , b , d));
    }
  else if (is_ac_ordered && !is_bd_ordered)
    {
      (phase == 1) ? (TBME_pp -= TBMEs_pp_HO_lab(J , a , c , d , b)) : (TBME_pp += TBMEs_pp_HO_lab(J , a , c , d , b));
    }
  
  const double Up_ab_pp_part_J_unnormed = prot_HO_overlaps_weight_product*real_dc (TBME_pp);

  if (!same_lj_all_protons)
    {
      return Up_ab_pp_part_J_unnormed;
    }
  else if (na == nc)
    {
      return ((nb == nd) ? (2.0*Up_ab_pp_part_J_unnormed) : (M_SQRT2*Up_ab_pp_part_J_unnormed));
    }
  else if (nb == nd)
    {
      return (M_SQRT2*Up_ab_pp_part_J_unnormed);
    }
  else
    {
      return Up_ab_pp_part_J_unnormed;
    }
}

double HF_potentials_common::HO_expansion_part_common::Up_HF_abcd_pn_part_J (
									     const unsigned int sn_occ , 
									     const unsigned int a , 
									     const unsigned int b , 
									     const unsigned int c , 
									     const unsigned int d , 
									     const complex<double> &weight , 
									     const int J , 
									     const class array<class nlj_struct> &shells_HO_table , 
									     const class array<class vector_class<complex<double> > > &neut_HO_overlaps_occ , 
									     const class TBMEs_class &TBMEs_pn_HO_lab)
{
  const class nlj_struct &sc = shells_HO_table(c);
  const class nlj_struct &sd = shells_HO_table(d);

  const int nc = sc.get_n ();
  const int nd = sd.get_n ();

  const class vector_class<complex<double> > &neut_HO_overlaps_sn_occ = neut_HO_overlaps_occ(sn_occ);
  
  const complex<double> neut_HO_overlaps_product = neut_HO_overlaps_sn_occ(nc)*neut_HO_overlaps_sn_occ(nd);

  const double neut_HO_overlaps_weight_product = real (weight*neut_HO_overlaps_product);

  const double Up_ab_pn_part_J = neut_HO_overlaps_weight_product*real_dc (TBMEs_pn_HO_lab(J , a , c , b , d)); 

  return Up_ab_pn_part_J;
}

double HF_potentials_common::HO_expansion_part_common::Un_HF_abcd_nn_part_J (
									     const unsigned int sn_occ , 
									     const unsigned int a , 
									     const unsigned int b , 
									     const unsigned int c , 
									     const unsigned int d , 
									     const bool same_lj_all_neutrons , 
									     const complex<double> &weight , 
									     const int J , 
									     const int phase , 
									     const class array<class nlj_struct> &shells_HO_table , 
									     const class array<class vector_class<complex<double> > > &neut_HO_overlaps_occ , 
									     const class TBMEs_class &TBMEs_nn_HO_lab)
{
  const class nlj_struct &sa = shells_HO_table(a);
  const class nlj_struct &sb = shells_HO_table(b);
  const class nlj_struct &sc = shells_HO_table(c);
  const class nlj_struct &sd = shells_HO_table(d);
  
  const int na = sa.get_n ();
  const int nb = sb.get_n ();
  const int nc = sc.get_n ();
  const int nd = sd.get_n ();
  
  const class vector_class<complex<double> > &neut_HO_overlaps_sn_occ = neut_HO_overlaps_occ(sn_occ);

  const bool is_ac_ordered = (a <= c);
  const bool is_bd_ordered = (b <= d);
  
  const complex<double> neut_HO_overlaps_product = neut_HO_overlaps_sn_occ(nc)*neut_HO_overlaps_sn_occ(nd);

  const double neut_HO_overlaps_weight_product = real (neut_HO_overlaps_product*weight);
  
  TYPE TBME_nn = 0.0;

  if (is_ac_ordered && is_bd_ordered)
    {
      TBME_nn += TBMEs_nn_HO_lab(J , a , c , b , d);
    }
  else if (!is_ac_ordered && !is_bd_ordered)
    {
      TBME_nn += TBMEs_nn_HO_lab(J , c , a , d , b);
    }
  else if (!is_ac_ordered && is_bd_ordered)
    {
      (phase == 1) ? (TBME_nn -= TBMEs_nn_HO_lab(J , c , a , b , d)) : (TBME_nn += TBMEs_nn_HO_lab(J , c , a , b , d));
    }
  else if (is_ac_ordered && !is_bd_ordered)
    {
      (phase == 1) ? (TBME_nn -= TBMEs_nn_HO_lab(J , a , c , d , b)) : (TBME_nn += TBMEs_nn_HO_lab(J , a , c , d , b));
    }
  
  const double Un_ab_nn_part_J_unnormed = neut_HO_overlaps_weight_product*real_dc (TBME_nn);

  if (!same_lj_all_neutrons)
    {
      return Un_ab_nn_part_J_unnormed;
    }
  else if (na == nc)
    {
      return ((nb == nd) ? (2.0*Un_ab_nn_part_J_unnormed) : (M_SQRT2*Un_ab_nn_part_J_unnormed));
    }
  else if (nb == nd)
    {
      return (M_SQRT2*Un_ab_nn_part_J_unnormed);
    }
  else
    {
      return Un_ab_nn_part_J_unnormed;
    }
}

double HF_potentials_common::HO_expansion_part_common::Un_HF_abcd_pn_part_J (
									     const unsigned int sp_occ , 
									     const unsigned int a , 
									     const unsigned int b , 
									     const unsigned int c , 
									     const unsigned int d , 
									     const complex<double> &weight , 
									     const int J , 
									     const class array<class nlj_struct> &shells_HO_table , 
									     const class array<class vector_class<complex<double> > > &prot_HO_overlaps_occ , 
									     const class TBMEs_class &TBMEs_pn_HO_lab)
{
  const class nlj_struct &sc = shells_HO_table(c);
  const class nlj_struct &sd = shells_HO_table(d);

  const int nc = sc.get_n ();
  const int nd = sd.get_n ();

  const class vector_class<complex<double> > &prot_HO_overlaps_sp_occ = prot_HO_overlaps_occ(sp_occ);
  
  const complex<double> prot_HO_overlaps_product = prot_HO_overlaps_sp_occ(nc)*prot_HO_overlaps_sp_occ(nd);

  const double prot_HO_overlaps_weight_product = real (weight*prot_HO_overlaps_product);

  const double Un_ab_pn_part_J = prot_HO_overlaps_weight_product*real_dc (TBMEs_pn_HO_lab(J , c , a , d , b)); 

  return Un_ab_pn_part_J;
}














// Calculation of the equivalent potential and souce of the HF potential for a given state, including states for which k +/- w/(4 Pi) with protons for Coulomb complex scaling (see H_CM_OBMEs.cpp) (pm is +/-)
// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// The equivalent potentials and source are calculated here for one given state.
//
// The non-local potential U(r,r') applied a wave function is written Ueq(r).u(r) + S(r), where Ueq(r) is the equivalent potential and S(r) the source.
//
// Ueq(r) = [1 - F(r)] \int U(r,r') u(r') dr' / u(r) and S(r) = F(r) \int U(r,r') u(r') dr', with F(r) a regularizing factor preventing from Ueq(r) to diverge if u(r) = 0, which is numerically non-zero only close to the zeroes of u(r).
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
//                  Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
//                  The ratio |u(r)|^2/|u'(r)|^2 prevents F(r) to be non zero when r -> +oo.
//                  Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// They are calculated on Gauss-Legendre and uniform grids on [0:R], with R the rotation point of complex scaling.
//
// In the second Ueq_source_calc function, one selects either arrays containing all HF/OCM wave functions, or those with only bound and resonant (res) states, as only poles can be occupied at HF level.
//
// The routine with "pm (i.e. +/- 1)" added in its name means that one considers the equivalent potentials of the states for which k +/- w/(4 Pi) with protons for Coulomb complex scaling (see H_CM_OBMEs.cpp).

void HF_potentials_common::HO_expansion_part_common::Ueq_source_calc (
								      const class interaction_class &inter_data_basis , 
								      const class spherical_state &shell , 
								      const class vector_class<complex<double> > &U_HF_shell_HO_basis_Fermi , 
								      const class HF_nucleons_data &HF_data , 
								      class nlj_table<complex<double> > &Ueq_finite_range_tab_uniform , 
								      class nlj_table<complex<double> > &source_tab_uniform , 
								      class nlj_table<complex<double> > &Ueq_finite_range_tab_GL , 
								      class nlj_table<complex<double> > &source_tab_GL)
{
  const unsigned int N_nlj = HF_data.get_N_nlj ();
  
  if (N_nlj == 0) return;

  const int lmax_for_basis_interaction = inter_data_basis.get_lmax_for_interaction();
  
  const int n = shell.get_n ();
  const int l = shell.get_l ();

  const int l_plus_one = l + 1;

  const double j = shell.get_j ();
  
  const double R_cut_function = HF_data.get_R_cut_function ();
  const double d_cut_function = HF_data.get_d_cut_function ();

  const double Ueq_regularizor = HF_data.get_Ueq_regularizor ();

  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();
  
  const int nmax_HO_l = (l <= lmax_for_basis_interaction) ? (nmax_HO_lab_tab(l)) : (0);

  const unsigned int N_bef_R_uniform = shell.get_N_bef_R_uniform ();
  const unsigned int N_bef_R_GL = shell.get_N_bef_R_GL ();
  
  const class array<double> &r_bef_R_tab_uniform = shell.get_r_bef_R_tab_uniform ();
  const class array<double> &r_bef_R_tab_GL = shell.get_r_bef_R_tab_GL ();
  
  const class array<complex<double> > &wf_bef_R_tab_uniform = shell.get_wf_bef_R_tab_uniform () , &dwf_bef_R_tab_uniform = shell.get_dwf_bef_R_tab_uniform ();
  const class array<complex<double> > &wf_bef_R_tab_GL  = shell.get_wf_bef_R_tab_GL ()  , &dwf_bef_R_tab_GL  = shell.get_dwf_bef_R_tab_GL ();
  
  const complex<double> C0 = shell.get_C0 ();

  const class array<double> &HO_wfs_uniform = HF_data.get_HO_wfs_uniform ();
  const class array<double> &HO_wfs_GL  = HF_data.get_HO_wfs_GL ();

  const unsigned int zero_index_uniform = Ueq_finite_range_tab_uniform.index_determine (n , l , j , 0);
  const unsigned int zero_index_GL  = Ueq_finite_range_tab_GL.index_determine  (n , l , j , 0);

  for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
    {
      const double r = r_bef_R_tab_uniform(i);
      
      const unsigned int index_uniform = zero_index_uniform + i;

      complex<double> U_HF_shell_r = 0.0;

      for (int n_HO = 0 ; n_HO <= nmax_HO_l ; n_HO++) U_HF_shell_r += U_HF_shell_HO_basis_Fermi(n_HO)*HO_wfs_uniform(n_HO , l , i);
      
      U_HF_shell_r *= Fermi_like_function (R_cut_function , d_cut_function , r);

      const complex<double> C0_pow_r_l_plus_one = C0*pow (r , l_plus_one);
      
      const complex<double> wf_r  = wf_bef_R_tab_uniform(i)  + precision;
      const complex<double> dwf_r = dwf_bef_R_tab_uniform(i) + precision;

      const double pole_removal_factor = exp (-Ueq_regularizor*(norm (wf_r)/norm (dwf_r)))*(1.0 - exp (-Ueq_regularizor*(norm (C0_pow_r_l_plus_one/wf_r - 1.0))));

      const complex<double> U_HF_shell_r_pole_removal_factor = U_HF_shell_r*pole_removal_factor;

      Ueq_finite_range_tab_uniform[index_uniform] += (U_HF_shell_r - U_HF_shell_r_pole_removal_factor)/wf_r;
      
      source_tab_uniform[index_uniform] += U_HF_shell_r_pole_removal_factor;
    } 

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double r = r_bef_R_tab_GL(i);
      
      const unsigned int index_GL = zero_index_GL + i;

      complex<double> U_HF_shell_r = 0.0;

      for (int n_HO = 0 ; n_HO <= nmax_HO_l ; n_HO++) U_HF_shell_r += U_HF_shell_HO_basis_Fermi(n_HO)*HO_wfs_GL(n_HO , l , i);

      U_HF_shell_r *= Fermi_like_function (R_cut_function , d_cut_function , r);
      
      const complex<double> C0_pow_r_l_plus_one = C0*pow (r , l_plus_one);

      const complex<double> wf_r  = wf_bef_R_tab_GL(i)  + precision;
      const complex<double> dwf_r = dwf_bef_R_tab_GL(i) + precision;

      const double pole_removal_factor = exp (-Ueq_regularizor*(norm (wf_r)/norm (dwf_r)))*(1.0 - exp (-Ueq_regularizor*(norm (C0_pow_r_l_plus_one/wf_r - 1.0))));
      
      const complex<double> U_HF_shell_r_pole_removal_factor = U_HF_shell_r*pole_removal_factor;
      
      Ueq_finite_range_tab_GL[index_GL] += (U_HF_shell_r - U_HF_shell_r_pole_removal_factor)/wf_r;
      
      source_tab_GL[index_GL] += U_HF_shell_r_pole_removal_factor;
    }	
}

void HF_potentials_common::HO_expansion_part_common::Ueq_source_calc (
								      const class interaction_class &inter_data_basis , 
								      const bool is_it_res , 
								      const unsigned int s , 
								      const class spherical_state &shell , 
								      class HF_nucleons_data &HF_data)
{
 
  const unsigned int N_nlj = (is_it_res) ? (HF_data.get_N_nlj_res ()) : (HF_data.get_N_nlj ());

  if (N_nlj == 0) return;

  const class lj_table<class matrix<complex<double> > > &U_finite_range_HF_HO_basis_HO_expansion_part = HF_data.get_U_finite_range_HF_HO_basis_HO_expansion_part ();  

  const int l = shell.get_l ();

  const double j = shell.get_j ();
  
  const class matrix<complex<double> > &U_finite_range_HF_HO_basis_HO_expansion_part_lj = U_finite_range_HF_HO_basis_HO_expansion_part(l , j);
  
  const class array<class vector_class<complex<double> > > &HO_overlaps_Fermi = (is_it_res) ? (HF_data.get_HO_overlaps_Fermi_res ()) : (HF_data.get_HO_overlaps_Fermi ());

  const class vector_class<complex<double> > &HO_overlaps_Fermi_shell = HO_overlaps_Fermi(s);

  const class vector_class<complex<double> > U_HF_shell_HO_basis_Fermi = U_finite_range_HF_HO_basis_HO_expansion_part_lj*HO_overlaps_Fermi_shell;
    
  class nlj_table<complex<double> > &Ueq_finite_range_tab_uniform = (is_it_res) ? (HF_data.get_Ueq_finite_range_res_tab_uniform ()) : (HF_data.get_Ueq_finite_range_tab_uniform ());
  class nlj_table<complex<double> > &Ueq_finite_range_tab_GL  = (is_it_res) ? (HF_data.get_Ueq_finite_range_res_tab_GL ())  : (HF_data.get_Ueq_finite_range_tab_GL ());
  
  class nlj_table<complex<double> > &source_tab_uniform = (is_it_res) ? (HF_data.get_source_res_tab_uniform ()) : (HF_data.get_source_tab_uniform ());
  class nlj_table<complex<double> > &source_tab_GL  = (is_it_res) ? (HF_data.get_source_res_tab_GL ())  : (HF_data.get_source_tab_GL ());

  Ueq_source_calc (inter_data_basis , shell , U_HF_shell_HO_basis_Fermi , HF_data , Ueq_finite_range_tab_uniform , source_tab_uniform , Ueq_finite_range_tab_GL , source_tab_GL);
}

void HF_potentials_common::HO_expansion_part_common::Ueq_source_pm_calc (
									 const int pm , 
									 const class interaction_class &inter_data_basis , 
									 const unsigned int s , 
									 const class spherical_state &shell_pm , 
									 class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj = HF_data.get_N_nlj ();

  if (N_nlj == 0) return;

  const class lj_table<class matrix<complex<double> > > &U_finite_range_HF_HO_basis_HO_expansion_part = HF_data.get_U_finite_range_HF_HO_basis_HO_expansion_part ();  

  const int l = shell_pm.get_l ();
  
  const double j = shell_pm.get_j ();

  const class matrix<complex<double> > &U_finite_range_HF_HO_basis_HO_expansion_part_lj = U_finite_range_HF_HO_basis_HO_expansion_part(l , j);

  const class array<class vector_class<complex<double> > > &HO_overlaps_Fermi_pm = (pm == 1) ? (HF_data.get_HO_overlaps_Fermi_plus ()) : (HF_data.get_HO_overlaps_Fermi_minus ());
  
  const class vector_class<complex<double> > &HO_overlaps_Fermi_shell_pm = HO_overlaps_Fermi_pm(s);

  const class vector_class<complex<double> > U_HF_shell_HO_basis_Fermi_pm = U_finite_range_HF_HO_basis_HO_expansion_part_lj*HO_overlaps_Fermi_shell_pm;

  class nlj_table<complex<double> > &Ueq_finite_range_pm_tab_uniform = (pm == 1) ? (HF_data.get_Ueq_finite_range_plus_tab_uniform ()) : (HF_data.get_Ueq_finite_range_minus_tab_uniform ());
  class nlj_table<complex<double> > &Ueq_finite_range_pm_tab_GL  = (pm == 1) ? (HF_data.get_Ueq_finite_range_plus_tab_GL ())  : (HF_data.get_Ueq_finite_range_minus_tab_GL ());
  
  class nlj_table<complex<double> > &source_pm_tab_uniform = (pm == 1) ? (HF_data.get_source_plus_tab_uniform ()) : (HF_data.get_source_minus_tab_uniform ());
  class nlj_table<complex<double> > &source_pm_tab_GL  = (pm == 1) ? (HF_data.get_source_plus_tab_GL ())  : (HF_data.get_source_minus_tab_GL ());

  Ueq_source_calc (inter_data_basis , shell_pm , U_HF_shell_HO_basis_Fermi_pm , HF_data , Ueq_finite_range_pm_tab_uniform , source_pm_tab_uniform , Ueq_finite_range_pm_tab_GL , source_pm_tab_GL);
}














// Removal of the Coulomb analytic potential in HO basis
// -----------------------------------------------------
// In HF_data, one considers the HF potential expanded in a HO basis. Consequently, it cannot take care of the 1/r asymptotic character of the Coulomb potential.
// Thus, a Coulomb analytic potential, with the proper asymptote, is removed here from the HF potential, so that considers only a finite-range part of the HF potential with the HO basis.
// The removed Coulomb potential is put back during direct integration of basis states and in the calculation of Coulomb potential matrix elements with complex scaling.

void HF_potentials_common::HO_expansion_part_common::V_Coulomb_HO_basis_removal (
										 const class interaction_class &inter_data_basis , 
										 class HF_nucleons_data &prot_HF_data)
{
  const enum particle_type particle = prot_HF_data.get_particle ();
  
  if (particle != PROTON) abort_all ();

  const unsigned int Np_nlj = prot_HF_data.get_N_nlj ();

  if (Np_nlj == 0) return;

  const class lj_table<class matrix<complex<double> > > &V_Coulomb_HO_basis = inter_data_basis.get_V_Coulomb_HO_basis ();
    
  const int lp_max = prot_HF_data.get_lmax ();
  
  const class lj_table<class matrix<complex<double> > > &Up_finite_range_HF_HO_basis_HO_expansion_part = prot_HF_data.get_U_finite_range_HF_HO_basis_HO_expansion_part ();

  const class lj_table<bool> &is_prot_partial_wave_optimized_tab = prot_HF_data.get_is_partial_wave_optimized_tab ();

  for (int lp = 0 ; lp <= lp_max ; lp++)
    for (double jp = (lp == 0) ? (0.5) : (lp-0.5) ; rint (jp - lp - 0.5) <= 0.0 ; jp++)
      {
	if (is_prot_partial_wave_optimized_tab(lp , jp))
	  {
	    const class matrix<complex<double> > &V_Coulomb_HO_basis_lj = V_Coulomb_HO_basis(lp , jp);
	    
	    class matrix<complex<double> > &Up_finite_range_HF_HO_basis_HO_expansion_part_lj = Up_finite_range_HF_HO_basis_HO_expansion_part(lp , jp);

	    Up_finite_range_HF_HO_basis_HO_expansion_part_lj -= V_Coulomb_HO_basis_lj;
	  }
      }
}












// Calculation of equivalent potentials, including states for which k +/- w/(4 Pi) with protons for Coulomb complex scaling (see H_CM_OBMEs.cpp) (pm is +/-)
// ---------------------------------------------------------------------------------------------------------------------------------------------------------
// The non-local potential U(r,r') applied a wave function is written Ueq(r).u(r) + S(r), where Ueq(r) is the trivially equivalent potential and S(r) the source.
//
// Ueq(r) = [1 - F(r)] \int U(r,r') u(r') dr' / u(r) and S(r) = F(r) \int U(r,r') u(r') dr', with F(r) a regularizing factor preventing from Ueq(r) to diverge if u(r) = 0, which is numerically non-zero only close to the zeroes of u(r).
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
//                  Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
//                  The ratio |u(r)|^2/|u'(r)|^2 prevents F(r) to be non zero when r -> +oo.
//                  Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// OpenMP parallelization is done here.

void HF_potentials_common::HO_expansion_part_common::trivially_equivalent_potentials_calc (
											   const bool HO_diag , 
											   const class interaction_class &inter_data_basis , 
											   class HF_nucleons_data &HF_data)
{  
  const unsigned int N_nlj = HF_data.get_N_nlj ();

  if (N_nlj == 0) return;

  const unsigned int N_nlj_res = HF_data.get_N_nlj_res ();
  
  const class array<class spherical_state > &shells     = HF_data.get_shells ();
  const class array<class spherical_state > &shells_res = HF_data.get_shells_res ();
  
  const class array<class nlj_struct> &shells_qn = HF_data.get_shells_quantum_numbers ();
  
  const class lj_table<bool> &is_partial_wave_optimized = HF_data.get_is_partial_wave_optimized_tab ();

  const unsigned int first_state = basic_first_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_state = basic_last_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  for (unsigned int s = 0 ; s < N_nlj_res ; s++)
    {
      const class spherical_state &shell_res = shells_res(s);

      if (shell_res.is_it_filled ())
	{
	  const int l = shell_res.get_l ();
	  
	  const double j = shell_res.get_j ();

	  const bool is_lj_optimized = is_partial_wave_optimized(l , j);

	  if (is_lj_optimized) Ueq_source_calc (inter_data_basis , true , s , shell_res , HF_data);
	}
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class spherical_state &shell = shells(s);
  
      if (shell.is_it_filled ())
	{
	  const class nlj_struct &shell_qn = shells_qn(s);
	  
	  const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

	  if (S_matrix_pole || ((s >= first_state) && (s <= last_state)))
	    {
	      const bool is_it_HO = shell_qn.get_is_it_HO ();

	      const bool no_HO = (!is_it_HO) && (!HO_diag);

	      const int l = shell.get_l ();

	      const double j = shell.get_j ();

	      const bool is_lj_optimized = is_partial_wave_optimized(l , j);
	      
	      if ((S_matrix_pole || no_HO) && is_lj_optimized) Ueq_source_calc (inter_data_basis , false , s , shell , HF_data);
	    }
	}
    }
}

void HF_potentials_common::HO_expansion_part_common::trivially_equivalent_potentials_shells_pm_calc (
												     const int pm , 
												     const class interaction_class &inter_data_basis , 
												     class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj = HF_data.get_N_nlj ();

  if (N_nlj == 0) return;

  const class array<class spherical_state > &shells_pm = (pm == 1) ? (HF_data.get_shells_plus ()) : (HF_data.get_shells_minus ());
  
  const class lj_table<bool> &is_partial_wave_optimized = HF_data.get_is_partial_wave_optimized_tab ();

  const unsigned int first_state = basic_first_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_state = basic_last_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class spherical_state &shell_pm = shells_pm(s);

      if (shell_pm.is_it_filled ())
	{
	  if (((s >= first_state) && (s <= last_state)))
	    {
	      const int l = shell_pm.get_l ();
	      
	      const double j = shell_pm.get_j ();

	      const bool is_lj_optimized = is_partial_wave_optimized(l , j);

	      if (is_lj_optimized) Ueq_source_pm_calc (pm , inter_data_basis , s , shell_pm , HF_data);
	    }
	}
    }
}















// Calculation of the HF potentials matrices using a HO basis
// ----------------------------------------------------------
// One calculates the matrices <a | U_HF | b> using a HO basis. One sums over all Vpp, Vnn or Vpn interaction two-body matrix elements.
// One calculates <a | U_HF | b> for na <= nb and then one fills the rest from symmetry.

void HF_potentials_common::HO_expansion_part_common::Up_HF_pp_part_HO_basis_calc (
										  const class CG_str &CGs , 
										  const class interaction_class &inter_data_basis , 
										  class HF_nucleons_data &prot_HF_data)
{
  const bool single_particle = prot_HF_data.get_single_particle ();
  
  const unsigned int Np_shells_occ = prot_HF_data.get_Nshells_occ ();

  const int lp_max = prot_HF_data.get_lmax ();
  
  const int Jmin_global_pp = inter_data_basis.get_Jmin_global_pp ();
  const int Jmax_global_pp = inter_data_basis.get_Jmax_global_pp ();

  const int lmax_for_basis_interaction = inter_data_basis.get_lmax_for_interaction();
  
  const class array<class nlj_struct> &shells_HO_table = inter_data_basis.get_shells_HO_table ();
  
  const class array<class nlj_struct> &shells_prot_qn_res = prot_HF_data.get_shells_quantum_numbers_res ();

  const class TBMEs_class &TBMEs_pp_HO_lab = inter_data_basis.get_TBMEs_pp_inter_lab ();

  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  const class nlj_table<unsigned int> &Zval_nucleons_in_shell_tab = prot_HF_data.get_N_valence_nucleons_in_shell_tab ();

  const class array<class vector_class<complex<double> > > &prot_HO_overlaps_occ = prot_HF_data.get_HO_overlaps_res ();

  const class lj_table<bool> &is_prot_partial_wave_optimized_tab = prot_HF_data.get_is_partial_wave_optimized_tab ();

  class lj_table<class matrix<complex<double> > > &Up_finite_range_HF_HO_basis_HO_expansion_part = prot_HF_data.get_U_finite_range_HF_HO_basis_HO_expansion_part ();

  for (int lp = 0 ; lp <= lp_max ; lp++)
    {
      const int nmax_HO_p = (lp <= lmax_for_basis_interaction) ? (nmax_HO_lab_tab(lp)) : (0);
      
      const int nmax_HO_p_plus_one = nmax_HO_p + 1;
      
      class array<unsigned int> HO_index_from_n_tab(nmax_HO_p_plus_one); 

      for (double jp = (lp == 0) ? (0.5) : (lp-0.5) ; rint (jp - lp - 0.5) <= 0.0 ; jp++)
	{
	  if (is_prot_partial_wave_optimized_tab(lp , jp))
	    { 
	      HO_index_from_n_tab_determine (lp , jp , inter_data_basis , HO_index_from_n_tab);

	      class matrix<complex<double> > Up_finite_range_HF_HO_basis_HO_expansion_part_lj(nmax_HO_p_plus_one);
	      
	      Up_finite_range_HF_HO_basis_HO_expansion_part_lj = 0.0;

	      for (unsigned int sp_occ = 0 ; sp_occ < Np_shells_occ ; sp_occ++)
		{
		  const class nlj_struct &shell_qn_prot_occ = shells_prot_qn_res(sp_occ);
		  
		  const bool core_state_p_occ = shell_qn_prot_occ.get_core_state ();
		  const bool hole_state_p_occ = shell_qn_prot_occ.get_hole_state ();
		  
		  if (core_state_p_occ || hole_state_p_occ) continue;

		  const int np_occ = shell_qn_prot_occ.get_n ();
		  const int lp_occ = shell_qn_prot_occ.get_l ();

		  const double jp_occ = shell_qn_prot_occ.get_j ();

		  const bool same_lj_all_protons = same_lj (lp , jp , lp_occ , jp_occ);

		  const unsigned int Zval_nucleons_in_shell_occ = Zval_nucleons_in_shell_tab(np_occ , lp_occ , jp_occ);
		  
		  if (single_particle && same_lj_all_protons && (Zval_nucleons_in_shell_occ == 1)) continue;

		  const int Jmin_sp_sp_occ = abs (make_int (jp - jp_occ));
		  const int Jmax_sp_sp_occ = make_int (jp + jp_occ);

		  const int Jmin = max (Jmin_sp_sp_occ , Jmin_global_pp);
		  const int Jmax = min (Jmax_sp_sp_occ , Jmax_global_pp);

		  const int nmax_HO_p_occ = (lp_occ <= lmax_for_basis_interaction) ? (nmax_HO_lab_tab(lp_occ)) : (0);

		  const int nmax_HO_p_plus_one_occ = nmax_HO_p_occ + 1;
		  
		  class array<unsigned int> HO_index_from_n_occ_tab(nmax_HO_p_plus_one_occ);

		  HO_index_from_n_tab_determine (shell_qn_prot_occ , inter_data_basis , HO_index_from_n_occ_tab);			

		  for (int J = Jmin ; J <= Jmax ; J++)
		    {
		      const double J_coefficient = uniform_filling_approximation::J_coefficient_calc (lp , jp , lp_occ , jp_occ , J , CGs , prot_HF_data , prot_HF_data);
		      
		      const int phase = minus_one_pow (jp + jp_occ - J);

		      for (int na = 0 ; na <= nmax_HO_p ; na++)
			{
			  const unsigned int a = HO_index_from_n_tab(na);

			  for (int nb = 0 ; nb <= na ; nb++)
			    {
			      const unsigned int b = HO_index_from_n_tab(nb);

			      double Up_pp_ab_J = 0.0;

			      for (int nc = 0 ; nc <= nmax_HO_p_occ ; nc++)
				{
				  const unsigned int c = HO_index_from_n_occ_tab(nc);

				  for (int nd = 0 ; nd <= nmax_HO_p_occ ; nd++)
				    {
				      const unsigned int d = HO_index_from_n_occ_tab(nd);

				      Up_pp_ab_J += Up_HF_abcd_pp_part_J (sp_occ , a , b , c , d , same_lj_all_protons , J_coefficient , J , phase , shells_HO_table , prot_HO_overlaps_occ , TBMEs_pp_HO_lab);
				    }
				}

			      Up_finite_range_HF_HO_basis_HO_expansion_part_lj(na , nb) += Up_pp_ab_J;
			    }}}}

	      for (int na = 0 ; na <= nmax_HO_p ; na++)
		for (int nb = 0 ; nb < na ; nb++)
		  Up_finite_range_HF_HO_basis_HO_expansion_part_lj(nb , na) = Up_finite_range_HF_HO_basis_HO_expansion_part_lj(na , nb);

	      Up_finite_range_HF_HO_basis_HO_expansion_part(lp , jp) += Up_finite_range_HF_HO_basis_HO_expansion_part_lj;
	    }
	}
    }
}

void HF_potentials_common::HO_expansion_part_common::Up_HF_pn_part_HO_basis_calc (
										  const class CG_str &CGs , const class interaction_class &inter_data_basis , 
										  const class HF_nucleons_data &neut_HF_data , 
										  class HF_nucleons_data &prot_HF_data)
{
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
  
  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  if (is_it_SGI_MSGI) return;

  const int lp_max = prot_HF_data.get_lmax ();

  const int Jmin_global_pn = inter_data_basis.get_Jmin_global_pn ();
  const int Jmax_global_pn = inter_data_basis.get_Jmax_global_pn ();

  const unsigned int Nn_shells_occ = neut_HF_data.get_Nshells_occ ();

  const int lmax_for_basis_interaction = inter_data_basis.get_lmax_for_interaction();
  
  const class array<class nlj_struct> &shells_HO_table = inter_data_basis.get_shells_HO_table ();

  const class array<class nlj_struct> &shells_neut_qn_res = neut_HF_data.get_shells_quantum_numbers_res ();
  
  const class TBMEs_class &TBMEs_pn_HO_lab = inter_data_basis.get_TBMEs_pn_inter_lab ();

  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  const class array<class vector_class<complex<double> > > &neut_HO_overlaps_occ = neut_HF_data.get_HO_overlaps_res ();

  const class lj_table<bool> &is_prot_partial_wave_optimized_tab = prot_HF_data.get_is_partial_wave_optimized_tab ();

  class lj_table<class matrix<complex<double> > > &Up_finite_range_HF_HO_basis_HO_expansion_part = prot_HF_data.get_U_finite_range_HF_HO_basis_HO_expansion_part ();

  for (int lp = 0 ; lp <= lp_max ; lp++)
    {
      const int nmax_HO_p = (lp <= lmax_for_basis_interaction) ? (nmax_HO_lab_tab(lp)) : (0);
      
      const int nmax_HO_p_plus_one = nmax_HO_p + 1;

      class array<unsigned int> HO_index_from_n_tab(nmax_HO_p_plus_one); 

      for (double jp = (lp == 0) ? (0.5) : (lp-0.5) ; rint (jp - lp - 0.5) <= 0.0 ; jp++)
	{  
	  if (is_prot_partial_wave_optimized_tab(lp , jp))
	    {
	      HO_index_from_n_tab_determine (lp , jp , inter_data_basis , HO_index_from_n_tab);

	      class matrix<complex<double> > Up_finite_range_HF_HO_basis_HO_expansion_part_lj(nmax_HO_p_plus_one);
	      
	      Up_finite_range_HF_HO_basis_HO_expansion_part_lj = 0.0;

	      for (unsigned int sn_occ = 0 ; sn_occ < Nn_shells_occ ; sn_occ++)
		{
		  const class nlj_struct &shell_qn_neut_occ = shells_neut_qn_res(sn_occ);
		  
		  const bool core_state_n_occ = shell_qn_neut_occ.get_core_state ();
		  const bool hole_state_n_occ = shell_qn_neut_occ.get_hole_state ();
		  
		  if (core_state_n_occ || hole_state_n_occ) continue;

		  const int ln_occ = shell_qn_neut_occ.get_l ();
		  const double jn_occ = shell_qn_neut_occ.get_j ();

		  const int Jmin_sp_sn_occ = abs (make_int (jp - jn_occ));
		  const int Jmax_sp_sn_occ = make_int (jp + jn_occ);

		  const int Jmin = max (Jmin_sp_sn_occ , Jmin_global_pn);
		  const int Jmax = min (Jmax_sp_sn_occ , Jmax_global_pn);

		  const int nmax_HO_n_occ = (ln_occ <= lmax_for_basis_interaction) ? (nmax_HO_lab_tab(ln_occ)) : (0);
		  const int nmax_HO_n_plus_one_occ = nmax_HO_n_occ + 1;
		  
		  class array<unsigned int> HO_index_from_n_occ_tab(nmax_HO_n_plus_one_occ);

		  HO_index_from_n_tab_determine (shell_qn_neut_occ , inter_data_basis , HO_index_from_n_occ_tab);			

		  for (int J = Jmin ; J <= Jmax ; J++)
		    {
		      const double J_coefficient = uniform_filling_approximation::J_coefficient_calc (lp , jp , ln_occ , jn_occ , J , CGs , prot_HF_data , neut_HF_data);

		      for (int na = 0 ; na <= nmax_HO_p ; na++)
			{
			  const unsigned int a = HO_index_from_n_tab(na);

			  for (int nb = 0 ; nb <= na ; nb++)
			    {
			      const unsigned int b = HO_index_from_n_tab(nb);

			      double Up_pn_ab_J = 0.0;

			      for (int nc = 0 ; nc <= nmax_HO_n_occ ; nc++)
				{
				  const unsigned int c = HO_index_from_n_occ_tab(nc);

				  for (int nd = 0 ; nd <= nmax_HO_n_occ ; nd++)
				    {
				      const unsigned int d = HO_index_from_n_occ_tab(nd);
				      Up_pn_ab_J += Up_HF_abcd_pn_part_J (sn_occ , a , b , c , d , J_coefficient , J , shells_HO_table , neut_HO_overlaps_occ , TBMEs_pn_HO_lab);
				    }
				}

			      Up_finite_range_HF_HO_basis_HO_expansion_part_lj(na , nb) += Up_pn_ab_J;
			    }}}}

	      for (int na = 0 ; na <= nmax_HO_p ; na++)
		for (int nb = 0 ; nb < na ; nb++)
		  Up_finite_range_HF_HO_basis_HO_expansion_part_lj(nb , na) = Up_finite_range_HF_HO_basis_HO_expansion_part_lj(na , nb);

	      Up_finite_range_HF_HO_basis_HO_expansion_part(lp , jp) += Up_finite_range_HF_HO_basis_HO_expansion_part_lj;
	    }
	}
    }
}

void HF_potentials_common::HO_expansion_part_common::Un_HF_nn_part_HO_basis_calc (
										  const class CG_str &CGs , 
										  const class interaction_class &inter_data_basis , 
										  class HF_nucleons_data &neut_HF_data)
{
  const bool single_particle = neut_HF_data.get_single_particle ();
  
  const unsigned int Nn_shells_occ = neut_HF_data.get_Nshells_occ ();

  const int ln_max = neut_HF_data.get_lmax ();

  const int Jmin_global_nn = inter_data_basis.get_Jmin_global_nn ();
  const int Jmax_global_nn = inter_data_basis.get_Jmax_global_nn ();

  const int lmax_for_basis_interaction = inter_data_basis.get_lmax_for_interaction();
  
  const class array<class nlj_struct> &shells_HO_table = inter_data_basis.get_shells_HO_table ();

  const class array<class nlj_struct> &shells_neut_qn_res = neut_HF_data.get_shells_quantum_numbers_res ();

  const class TBMEs_class &TBMEs_nn_HO_lab = inter_data_basis.get_TBMEs_nn_inter_lab ();

  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  const class nlj_table<unsigned int> &Nval_nucleons_in_shell_tab = neut_HF_data.get_N_valence_nucleons_in_shell_tab ();

  const class array<class vector_class<complex<double> > > &neut_HO_overlaps_occ = neut_HF_data.get_HO_overlaps_res ();
  
  const class lj_table<bool> &is_neut_partial_wave_optimized_tab = neut_HF_data.get_is_partial_wave_optimized_tab ();

  class lj_table<class matrix<complex<double> > > &Un_finite_range_HF_HO_basis_HO_expansion_part = neut_HF_data.get_U_finite_range_HF_HO_basis_HO_expansion_part ();

  for (int ln = 0 ; ln <= ln_max ; ln++)
    {
      const int nmax_HO_n = (ln <= lmax_for_basis_interaction) ? (nmax_HO_lab_tab(ln)) : (0);
      
      const int nmax_HO_n_plus_one = nmax_HO_n + 1;

      class array<unsigned int> HO_index_from_n_tab(nmax_HO_n_plus_one); 

      for (double jn = (ln == 0) ? (0.5) : (ln-0.5) ; rint (jn - ln - 0.5) <= 0.0 ; jn++)
	{ 
	  if (is_neut_partial_wave_optimized_tab(ln , jn))
	    {
	      HO_index_from_n_tab_determine (ln , jn , inter_data_basis , HO_index_from_n_tab);

	      class matrix<complex<double> > Un_finite_range_HF_HO_basis_HO_expansion_part_lj(nmax_HO_n_plus_one);
	      
	      Un_finite_range_HF_HO_basis_HO_expansion_part_lj = 0.0;

	      for (unsigned int sn_occ = 0 ; sn_occ < Nn_shells_occ ; sn_occ++)
		{
		  const class nlj_struct &shell_qn_neut_occ = shells_neut_qn_res(sn_occ);
		  
		  const bool core_state_n_occ = shell_qn_neut_occ.get_core_state ();
		  const bool hole_state_n_occ = shell_qn_neut_occ.get_hole_state ();

		  if (core_state_n_occ || hole_state_n_occ) continue;

		  const int nn_occ = shell_qn_neut_occ.get_n ();
		  const int ln_occ = shell_qn_neut_occ.get_l ();
		  
		  const double jn_occ = shell_qn_neut_occ.get_j ();

		  const bool same_lj_all_neutrons = same_lj (ln , jn , ln_occ , jn_occ);

		  const unsigned int Nval_nucleons_in_shell_occ = Nval_nucleons_in_shell_tab(nn_occ , ln_occ , jn_occ);
		  
		  if (single_particle && same_lj_all_neutrons && (Nval_nucleons_in_shell_occ == 1)) continue;

		  const int Jmin_sn_sn_occ = abs (make_int (jn - jn_occ));
		  const int Jmax_sn_sn_occ = make_int (jn + jn_occ);
		  
		  const int Jmin = max (Jmin_sn_sn_occ , Jmin_global_nn);
		  const int Jmax = min (Jmax_sn_sn_occ , Jmax_global_nn);

		  const int nmax_HO_n_occ = (ln_occ <= lmax_for_basis_interaction) ? (nmax_HO_lab_tab(ln_occ)) : (0);
		  
		  const int nmax_HO_n_plus_one_occ = nmax_HO_n_occ + 1;
		  
		  class array<unsigned int> HO_index_from_n_occ_tab(nmax_HO_n_plus_one_occ);

		  HO_index_from_n_tab_determine (shell_qn_neut_occ , inter_data_basis , HO_index_from_n_occ_tab);

		  for (int J = Jmin ; J <= Jmax ; J++)
		    {
		      const double J_coefficient = uniform_filling_approximation::J_coefficient_calc (ln , jn , ln_occ , jn_occ , J , CGs , neut_HF_data , neut_HF_data);
		      
		      const int phase = minus_one_pow (jn + jn_occ - J);

		      for (int na = 0 ; na <= nmax_HO_n ; na++)
			{
			  const unsigned int a = HO_index_from_n_tab(na);

			  for (int nb = 0 ; nb <= na ; nb++)
			    {
			      const unsigned int b = HO_index_from_n_tab(nb);

			      double Un_nn_ab_J = 0.0;

			      for (int nc = 0 ; nc <= nmax_HO_n_occ ; nc++)
				{
				  const unsigned int c = HO_index_from_n_occ_tab(nc);

				  for (int nd = 0 ; nd <= nmax_HO_n_occ ; nd++)
				    {
				      const unsigned int d = HO_index_from_n_occ_tab(nd);
				      
				      Un_nn_ab_J += Un_HF_abcd_nn_part_J (sn_occ , a , b , c , d , same_lj_all_neutrons , J_coefficient , J , phase , shells_HO_table , neut_HO_overlaps_occ , TBMEs_nn_HO_lab);
				    }
				}

			      Un_finite_range_HF_HO_basis_HO_expansion_part_lj(na , nb) += Un_nn_ab_J;
			    }}}}

	      for (int na = 0 ; na <= nmax_HO_n ; na++)
		for (int nb = 0 ; nb < na ; nb++)
		  Un_finite_range_HF_HO_basis_HO_expansion_part_lj(nb , na) = Un_finite_range_HF_HO_basis_HO_expansion_part_lj(na , nb);

	      Un_finite_range_HF_HO_basis_HO_expansion_part(ln , jn) += Un_finite_range_HF_HO_basis_HO_expansion_part_lj;
	    }
	}
    }
}

void HF_potentials_common::HO_expansion_part_common::Un_HF_pn_part_HO_basis_calc (
										  const class CG_str &CGs , const class interaction_class &inter_data_basis , 
										  const class HF_nucleons_data &prot_HF_data , 
										  class HF_nucleons_data &neut_HF_data)
{
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  if (is_it_SGI_MSGI) return;
  
  const int ln_max = neut_HF_data.get_lmax ();

  const int Jmin_global_pn = inter_data_basis.get_Jmin_global_pn ();
  const int Jmax_global_pn = inter_data_basis.get_Jmax_global_pn ();

  const unsigned int Np_shells_occ = prot_HF_data.get_Nshells_occ ();

  const int lmax_for_basis_interaction = inter_data_basis.get_lmax_for_interaction();
  
  const class array<class nlj_struct> &shells_HO_table = inter_data_basis.get_shells_HO_table ();
  const class array<class nlj_struct> &shells_prot_qn_res = prot_HF_data.get_shells_quantum_numbers_res ();

  const class TBMEs_class &TBMEs_pn_HO_lab = inter_data_basis.get_TBMEs_pn_inter_lab ();

  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  const class array<class vector_class<complex<double> > > &prot_HO_overlaps_occ = prot_HF_data.get_HO_overlaps_res ();

  const class lj_table<bool> &is_neut_partial_wave_optimized_tab = neut_HF_data.get_is_partial_wave_optimized_tab ();

  class lj_table<class matrix<complex<double> > > &Un_finite_range_HF_HO_basis_HO_expansion_part = neut_HF_data.get_U_finite_range_HF_HO_basis_HO_expansion_part ();

  for (int ln = 0 ; ln <= ln_max ; ln++)
    {
      const int nmax_HO_n = (ln <= lmax_for_basis_interaction) ? (nmax_HO_lab_tab(ln)) : (0);
      
      const int nmax_HO_n_plus_one = nmax_HO_n + 1;

      class array<unsigned int> HO_index_from_n_tab(nmax_HO_n_plus_one);

      for (double jn = (ln == 0) ? (0.5) : (ln-0.5) ; rint (jn - ln - 0.5) <= 0.0 ; jn++)
	{       
	  if (is_neut_partial_wave_optimized_tab(ln , jn))
	    {
	      HO_index_from_n_tab_determine (ln , jn , inter_data_basis , HO_index_from_n_tab);

	      class matrix<complex<double> > Un_finite_range_HF_HO_basis_HO_expansion_part_lj(nmax_HO_n_plus_one);
	      
	      Un_finite_range_HF_HO_basis_HO_expansion_part_lj = 0.0;

	      for (unsigned int sp_occ = 0 ; sp_occ < Np_shells_occ ; sp_occ++)
		{
		  const class nlj_struct &shell_qn_prot_occ = shells_prot_qn_res(sp_occ);
		  
		  const bool core_state_p_occ = shell_qn_prot_occ.get_core_state ();
		  const bool hole_state_p_occ = shell_qn_prot_occ.get_hole_state ();

		  if (core_state_p_occ || hole_state_p_occ) continue;

		  const int lp_occ = shell_qn_prot_occ.get_l ();

		  const double jp_occ = shell_qn_prot_occ.get_j ();

		  const int Jmin_sn_sp_occ = abs (make_int (jn - jp_occ));
		  const int Jmax_sn_sp_occ = make_int (jn + jp_occ);
		  
		  const int Jmin = max (Jmin_sn_sp_occ , Jmin_global_pn);
		  const int Jmax = min (Jmax_sn_sp_occ , Jmax_global_pn);

		  const int nmax_HO_p_occ = (lp_occ <= lmax_for_basis_interaction) ? (nmax_HO_lab_tab(lp_occ)) : (0);
		  
		  const int nmax_HO_p_plus_one_occ = nmax_HO_p_occ + 1;

		  class array<unsigned int> HO_index_from_n_occ_tab(nmax_HO_p_plus_one_occ);

		  HO_index_from_n_tab_determine (shell_qn_prot_occ , inter_data_basis , HO_index_from_n_occ_tab);

		  for (int J = Jmin ; J <= Jmax ; J++)
		    {
		      const double J_coefficient = uniform_filling_approximation::J_coefficient_calc (ln , jn , lp_occ , jp_occ , J , CGs , neut_HF_data , prot_HF_data);

		      for (int na = 0 ; na <= nmax_HO_n ; na++)
			{
			  const unsigned int a = HO_index_from_n_tab(na);

			  for (int nb = 0 ; nb <= na ; nb++)
			    {
			      const unsigned int b = HO_index_from_n_tab(nb);

			      double Un_pn_ab_J = 0.0;

			      for (int nc = 0 ; nc <= nmax_HO_p_occ ; nc++)
				{
				  const unsigned int c = HO_index_from_n_occ_tab(nc);

				  for (int nd = 0 ; nd <= nmax_HO_p_occ ; nd++)
				    {
				      const unsigned int d = HO_index_from_n_occ_tab(nd);
				      Un_pn_ab_J += Un_HF_abcd_pn_part_J (sp_occ , a , b , c , d , J_coefficient , J , shells_HO_table , prot_HO_overlaps_occ , TBMEs_pn_HO_lab);
				    }
				}

			      Un_finite_range_HF_HO_basis_HO_expansion_part_lj(na , nb) += Un_pn_ab_J;
			    }}}}

	      for (int na = 0 ; na <= nmax_HO_n ; na++)
		for (int nb = 0 ; nb < na ; nb++)
		  Un_finite_range_HF_HO_basis_HO_expansion_part_lj(nb , na) = Un_finite_range_HF_HO_basis_HO_expansion_part_lj(na , nb);

	      Un_finite_range_HF_HO_basis_HO_expansion_part(ln , jn) += Un_finite_range_HF_HO_basis_HO_expansion_part_lj;
	    }
	}
    }
}











// Calculation of the all HF potentials matrices using a HO basis
// --------------------------------------------------------------
// One calculates the matrices <a | U_HF | b> using a HO basis. 
// One sums over all Vpp, Vnn or Vpn interaction two-body matrix elements, according to the number of valence protons and neutrons. 
// The removal of the Coulomb analytic potential in HO basis is done here as well (see V_Coulomb_HO_basis_removal).

void HF_potentials_common::HO_expansion_part_common::prot_potentials_HO_basis_calc (
										    const class CG_str &CGs , 
										    const class interaction_class &inter_data_basis , 
										    const class HF_nucleons_data &neut_HF_data , 
										    class HF_nucleons_data &prot_HF_data)
{ 
  const enum particle_type particle = prot_HF_data.get_particle ();

  if (particle != PROTON) abort_all ();

  const unsigned int Np_nlj = prot_HF_data.get_N_nlj ();

  if (Np_nlj == 0) return;

  const bool is_it_OCM_basis = prot_HF_data.get_is_it_OCM_basis ();

  if (!is_it_OCM_basis)
    {
      const int Zval = prot_HF_data.get_N_valence_nucleons_basis ();
      const int Nval = neut_HF_data.get_N_valence_nucleons_basis ();

      if (Zval >= 2) Up_HF_pp_part_HO_basis_calc (CGs , inter_data_basis , prot_HF_data);
      
      if ((Zval >= 1) && (Nval >= 1)) Up_HF_pn_part_HO_basis_calc (CGs , inter_data_basis , neut_HF_data , prot_HF_data);

      if (Zval >= 2) V_Coulomb_HO_basis_removal (inter_data_basis , prot_HF_data);
    }
}

void HF_potentials_common::HO_expansion_part_common::neut_potentials_HO_basis_calc (
										    const class CG_str &CGs , 
										    const class interaction_class &inter_data_basis , 
										    const class HF_nucleons_data &prot_HF_data , 
										    class HF_nucleons_data &neut_HF_data)
{ 
  const enum particle_type particle = neut_HF_data.get_particle ();

  if (particle != NEUTRON) abort_all ();

  const unsigned int Nn_nlj = neut_HF_data.get_N_nlj ();

  if (Nn_nlj == 0) return;

  const bool is_it_OCM_basis = neut_HF_data.get_is_it_OCM_basis ();

  if (!is_it_OCM_basis)
    {
      const int Zval = prot_HF_data.get_N_valence_nucleons_basis ();
      const int Nval = neut_HF_data.get_N_valence_nucleons_basis ();
      
      if (Nval >= 2) Un_HF_nn_part_HO_basis_calc (CGs , inter_data_basis , neut_HF_data);

      if ((Zval >= 1) && (Nval >= 1)) Un_HF_pn_part_HO_basis_calc (CGs , inter_data_basis , prot_HF_data , neut_HF_data);
    }
}


