#include "../GSM_include/GSM_include_def_common.h"

using namespace inputs_misc;

class baryons_data;


// TYPE is double or complex
// -------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------


// Calculation and storage of uncoupled TBMEs for Hamiltonian times vector
// -----------------------------------------------------------------------
// As one uses M-scheme, TBMEs must be uncoupled to calculate the Hamiltonian NBMEs.
// As J-coupled TBMEs as always stored, uncoupled TBMEs can be directly calculated from J-coupled TBMEs with Clebsch-Gordan coefficients.
//
// One needs in general to consider uncoupled TBMEs using the following Hamiltonian storage options:
// PARTIAL_STORAGE: uncoupled TBMEs indices are stored along with reordering phases, and NBMEs, so that one needs the present array of uncoupled TBMEs to reobtain NBMEs.
// ON_THE_FLY: Hamiltonian is recalculated on the fly for H.Psi operation and can use the present array of uncoupled TBMEs to obtain NBMEs.
//
// pp, nn and pn uncoupled TBMEs are all stored in a single standard array. Their indices read, for fixed parity and M[pair]:
// pair_index[in] + dimension_pairs_in.pair_index[out] + sum.dimensions,
// where pair_index[in], pair_index[out] and dimension_pairs_in have fixed parity and M[pair],
// and sum.dimensions is the sum of all TBMEs space dimensions of binary parity (see observables_basic_functions.cpp for definition)
// and M[pair] index (see GSM_vector_dimensions.cpp) smaller than the current one.
// If a pair is not considered in one node, its index is put to INFINITE_PAIR_INDEX (4294967295 in const.h), and to dimension_List afterwards.
//
// One does not use symmetry as, using MPI, the pairs entering the in and out GSM vectors can be different, so that symmetry is broken at this level.
// One does not use time-reveral symmetry either for the same reason.
//
// One first stores pp TBMEs (if any), then nn TBMEs (if any), pn TBMEs (if any), and finally cv TBMEs (pp to nn conversion with hyperons, if any) in the array of TBMEs.
//
// There are constructors when one considers pp/nn TBMEs only, for example if one has valence protons only or valence neutrons only, or pp, nn, pn, and/or cv TBMEs if one has both valence protons and neutrons (plus a few hyperons if any).
//
// MPI distribution is implicit therein as the pairs of the in and out spaces, which are input of constructors, have been selected so as to be used in the current MPI node.
// OpenMP distribution is used for the calculation of TBMEs, by distributing over the pairs indices of the in space for pp, nn and pn TBMEs.




uncoupled_TBMEs_class::uncoupled_TBMEs_class ()
  : zero_TBME (0.0) ,
    is_it_pp_nn (false) ,
    dimension_List_pp (0) ,
    dimension_List_nn (0), 
    dimension_List_pn (0) , 
    dimension_List_pp_nn (0) , 
    dimension_List_cv_pp_to_nn (0) ,
    dimension_List_cv_nn_to_pp (0) ,
    dimension_List (0) , 
    List (NULL)
{}

uncoupled_TBMEs_class::uncoupled_TBMEs_class (					      
					      const bool is_there_cout , 
					      const unsigned int N_nljm_baryon ,
					      const class array<class pair_str> &pairs_in_tab , 
					      const class array<class pair_str> &pairs_out_tab , 
					      const class array<class nljm_struct> &phi_table , 
					      const class TBMEs_class &TBMEs)
  : zero_TBME (0.0) ,
    is_it_pp_nn (false) ,
    dimension_List_pp (0) ,
    dimension_List_nn (0) , 
    dimension_List_pn (0) ,
    dimension_List_pp_nn (0) , 
    dimension_List_cv_pp_to_nn (0) ,
    dimension_List_cv_nn_to_pp (0) ,
    dimension_List (0) , 
    List (NULL)
{
  allocate (is_there_cout , N_nljm_baryon , pairs_in_tab , pairs_out_tab , phi_table , TBMEs);
}

uncoupled_TBMEs_class::uncoupled_TBMEs_class (
					      const bool is_there_cout , 
					      const unsigned int Np_nljm_baryon ,  
					      const unsigned int Nn_nljm_baryon ,
					      const bool is_pp_calculated , 
					      const bool is_nn_calculated , 
					      const bool is_pn_non_zero ,  
					      const bool is_cv_non_zero , 
					      const class array<class pair_str> &pp_pairs_in_tab , 
					      const class array<class pair_str> &nn_pairs_in_tab , 
					      const class array<class pair_str> &pn_pairs_in_tab , 
					      const class array<class pair_str> &pp_pairs_out_tab , 
					      const class array<class pair_str> &nn_pairs_out_tab , 
					      const class array<class pair_str> &pn_pairs_out_tab , 
					      const class array<class nljm_struct> &phi_p_table , 
					      const class array<class nljm_struct> &phi_n_table , 
					      const class TBMEs_class &TBMEs_pp , 
					      const class TBMEs_class &TBMEs_nn , 
					      const class TBMEs_class &TBMEs_pn , 
					      const class TBMEs_class &TBMEs_cv)
: zero_TBME (0.0) ,
  is_it_pp_nn (false) ,
  dimension_List_pp (0) ,
  dimension_List_nn (0) , 
  dimension_List_pn (0) ,
  dimension_List_pp_nn (0) , 
  dimension_List_cv_pp_to_nn (0) ,
  dimension_List_cv_nn_to_pp (0) ,
  dimension_List (0) , 
  List (NULL)
{
  allocate (is_there_cout , Np_nljm_baryon , Nn_nljm_baryon , is_pp_calculated , is_nn_calculated , is_pn_non_zero , is_cv_non_zero , pp_pairs_in_tab , nn_pairs_in_tab , pn_pairs_in_tab ,
	    pp_pairs_out_tab , nn_pairs_out_tab , pn_pairs_out_tab , phi_p_table , phi_n_table , TBMEs_pp , TBMEs_nn , TBMEs_pn , TBMEs_cv);
}

uncoupled_TBMEs_class::uncoupled_TBMEs_class (const class uncoupled_TBMEs_class &X)
  : zero_TBME (0.0) ,
    is_it_pp_nn (false) ,
    dimension_List_pp (0) ,
    dimension_List_nn (0) , 
    dimension_List_pn (0) ,
    dimension_List_pp_nn (0) , 
    dimension_List_cv_pp_to_nn (0) ,
    dimension_List_cv_nn_to_pp (0) ,
    dimension_List (0) , 
    List (NULL)
{
  allocate_fill (X);
}
	
uncoupled_TBMEs_class::~uncoupled_TBMEs_class ()
{
  delete [] List;
}
				      
void uncoupled_TBMEs_class::allocate (
				      const bool is_there_cout ,
				      const unsigned int N_nljm_baryon ,
				      const class array<class pair_str> &pairs_in_tab , 
				      const class array<class pair_str> &pairs_out_tab , 
				      const class array<class nljm_struct> &phi_table , 
				      const class TBMEs_class &TBMEs)
{
  is_it_pp_nn = true;

  dimension_List_pp = dimension_List_nn = dimension_List_pn = dimension_List_pp_nn = dimension_List = 0;

  List = NULL;

  if (N_nljm_baryon == 0) return;

  bp_table.allocate (N_nljm_baryon , N_nljm_baryon);

  strangeness_table.allocate (N_nljm_baryon , N_nljm_baryon);
	  
  im_table.allocate (N_nljm_baryon , N_nljm_baryon);

  class array<bool> are_there_frozen_states_spectators_table(N_nljm_baryon , N_nljm_baryon);
  
  int strangeness_max = 0;
  
  int im_max = 0;

  for (unsigned int mu = 0 ; mu < N_nljm_baryon ; mu++)
    for (unsigned int mu_p = 0 ; mu_p < N_nljm_baryon ; mu_p++)
      {
	const class nljm_struct &phi   = phi_table(mu);
	const class nljm_struct &phi_p = phi_table(mu_p);
			      
	const enum particle_type particle   = phi.get_particle ();
	const enum particle_type particle_p = phi_p.get_particle ();
	
	const class pair_str pair(particle , mu , particle_p , mu_p);

	const bool are_there_frozen_states = pair.are_there_frozen_states_determine (phi_table , phi_table);

	const bool are_there_spectator_states = pair.are_there_spectator_states_determine ();

	const unsigned int bp = pair.bp_determine (phi_table , phi_table);

	const int s = pair.strangeness_determine ();
	
	const int im = pair.im_determine (phi_table , phi_table);
	
	are_there_frozen_states_spectators_table(mu , mu_p) = (are_there_frozen_states || are_there_spectator_states);
  
	bp_table(mu , mu_p) = bp;
	
	strangeness_table(mu , mu_p) = s;

	im_table(mu , mu_p) = im;

	strangeness_max = max (strangeness_max , s);
	
	im_max = max (im_max , im);
      }

  const int strangeness_max_plus_one = strangeness_max + 1;
  
  const int im_max_plus_one = im_max + 1;

  dimensions_pairs_in.allocate  (2 , strangeness_max_plus_one , im_max_plus_one);
  dimensions_pairs_out.allocate (2 , strangeness_max_plus_one , im_max_plus_one);

  dimensions_pairs_in  = 0;
  dimensions_pairs_out = 0;

  pairs_in_indices.allocate  (N_nljm_baryon , N_nljm_baryon);
  pairs_out_indices.allocate (N_nljm_baryon , N_nljm_baryon);

  pairs_in_indices  = INFINITE_PAIR_INDEX;
  pairs_out_indices = INFINITE_PAIR_INDEX; 

  const unsigned int dimension_pairs_in  = pairs_in_tab.dimension (0);
  const unsigned int dimension_pairs_out = pairs_out_tab.dimension (0);

  for (unsigned int i_pair_in = 0 ; i_pair_in < dimension_pairs_in ; i_pair_in++)
    {
      const class pair_str &pair = pairs_in_tab(i_pair_in);

      const unsigned int mu   = pair.get_left ();
      const unsigned int mu_p = pair.get_right ();

      const bool are_there_frozen_spectator_states = are_there_frozen_states_spectators_table(mu , mu_p);

      if (are_there_frozen_spectator_states) continue;
	
      const unsigned int bp = bp_table(mu , mu_p);

      const int s = strangeness_table(mu , mu_p);
	
      const int im = im_table(mu , mu_p);

      pairs_in_indices(mu , mu_p) = dimensions_pairs_in(bp , s , im)++;
    }
  
  for (unsigned int i_pair_out = 0 ; i_pair_out < dimension_pairs_out ; i_pair_out++)
    {
      const class pair_str &pair = pairs_out_tab(i_pair_out);

      const unsigned int mu   = pair.get_left ();
      const unsigned int mu_p = pair.get_right ();

      const bool are_there_frozen_spectator_states = are_there_frozen_states_spectators_table(mu , mu_p);

      if (are_there_frozen_spectator_states) continue;
      
      const unsigned int bp = bp_table(mu , mu_p);

      const int s = strangeness_table(mu , mu_p);
      
      const int im = im_table(mu , mu_p);

      pairs_out_indices(mu , mu_p) = dimensions_pairs_out(bp , s , im)++;
    }

  unsigned int sum_dimensions_bef = 0;
  
  unsigned int dimension_bef = 0;

  sum_dimensions.allocate (2 , strangeness_max_plus_one , im_max_plus_one);

  for (unsigned int bp = 0 ; bp <= 1 ; bp++)
    for (int s = 0 ; s <= strangeness_max ; s++)
      for (int im = 0 ; im <= im_max ; im++)
	{
	  const unsigned int dimension_in  = dimensions_pairs_in (bp , s , im);
	  const unsigned int dimension_out = dimensions_pairs_out(bp , s , im);
	  
	  const unsigned int dimension = dimension_in*dimension_out;

	  unsigned int &sum_dimensions_bp_s_m = sum_dimensions(bp , s , im);
	  
	  sum_dimensions_bp_s_m = sum_dimensions_bef + dimension_bef;

	  dimension_List += dimension;

	  dimension_bef = dimension;

	  sum_dimensions_bef = sum_dimensions_bp_s_m;
	}
  
  if (dimension_List == 0) return;
  
  List = new TYPE [dimension_List];

  for (unsigned int i = 0 ; i < dimension_List ; i++) List[i] = 0.0;

  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif  
  for (unsigned int i_pair_in = 0 ; i_pair_in < dimension_pairs_in ; i_pair_in++)
    {
      const class pair_str &pair_in = pairs_in_tab(i_pair_in);

      const unsigned int mu_in   = pair_in.get_left ();
      const unsigned int mu_p_in = pair_in.get_right ();

      const bool are_there_frozen_spectator_states_in = are_there_frozen_states_spectators_table(mu_in , mu_p_in);

      if (are_there_frozen_spectator_states_in) continue;
      
      const unsigned int bp_in = bp_table(mu_in , mu_p_in);
      
      const int s_in = strangeness_table(mu_in , mu_p_in);
	
      const int im_in = im_table(mu_in , mu_p_in);
      
      for (unsigned int i_pair_out = 0 ; i_pair_out < dimension_pairs_out ; i_pair_out++)
	{
	  const class pair_str &pair_out = pairs_out_tab(i_pair_out);

	  const unsigned int mu_out   = pair_out.get_left ();
	  const unsigned int mu_p_out = pair_out.get_right ();

	  const bool are_there_frozen_spectator_states_out = are_there_frozen_states_spectators_table(mu_out , mu_p_out);
      
	  if (are_there_frozen_spectator_states_out) continue;
      
	  const unsigned int bp_out = bp_table(mu_out , mu_p_out);
	  
	  const int s_out = strangeness_table(mu_out , mu_p_out);
      
	  const int im_out = im_table(mu_out , mu_p_out);
	  
	  if ((bp_in == bp_out) && (s_in == s_out) && (im_in == im_out))
	    {
	      const unsigned int index = index_determine_pp_nn (mu_in , mu_p_in , mu_out , mu_p_out);
	      
	      List[index] = TBMEs.M_TBME (false , mu_in , mu_p_in , mu_out , mu_p_out);
	    }
	}
    }

  for (unsigned int mu = 0 ; mu < N_nljm_baryon ; mu++)
    for (unsigned int mu_p = 0 ; mu_p < N_nljm_baryon ; mu_p++)
      {
	pairs_in_indices (mu , mu_p) = min (pairs_in_indices (mu , mu_p) , dimension_List);
	pairs_out_indices(mu , mu_p) = min (pairs_out_indices(mu , mu_p) , dimension_List);
      }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time;
      
      cout << endl << "Uncoupled TBMEs calculated. time:" << relative_time << " s" << endl << endl;
    }
}


void uncoupled_TBMEs_class::allocate (
				      const bool is_there_cout , 
				      const unsigned int Np_nljm_baryon ,				      
				      const unsigned int Nn_nljm_baryon ,
				      const bool is_pp_calculated , 
				      const bool is_nn_calculated , 
				      const bool is_pn_non_zero ,  
				      const bool is_cv_non_zero , 
				      const class array<class pair_str> &pp_pairs_in_tab , 
				      const class array<class pair_str> &nn_pairs_in_tab , 
				      const class array<class pair_str> &pn_pairs_in_tab , 
				      const class array<class pair_str> &pp_pairs_out_tab , 
				      const class array<class pair_str> &nn_pairs_out_tab , 
				      const class array<class pair_str> &pn_pairs_out_tab , 
				      const class array<class nljm_struct> &phi_p_table , 
				      const class array<class nljm_struct> &phi_n_table , 
				      const class TBMEs_class &TBMEs_pp , 
				      const class TBMEs_class &TBMEs_nn , 
				      const class TBMEs_class &TBMEs_pn , 
				      const class TBMEs_class &TBMEs_cv)
{
  if (is_cv_non_zero && (!is_pp_calculated || !is_nn_calculated)) error_message_print_abort ("pp and nn spaces must be present if one has pp-nn conversions in uncoupled_TBMEs_class::allocate (2)");
  
  is_it_pp_nn = false;

  dimension_List_pp = dimension_List_nn = dimension_List_pn = dimension_List_cv_pp_to_nn = dimension_List_cv_nn_to_pp = dimension_List_pp_nn = dimension_List = 0;

  List = NULL;
  
  if (is_pp_calculated && (Np_nljm_baryon > 0)) pp_constructor_part (Np_nljm_baryon , pp_pairs_in_tab , pp_pairs_out_tab , phi_p_table);
  if (is_nn_calculated && (Nn_nljm_baryon > 0)) nn_constructor_part (Nn_nljm_baryon , nn_pairs_in_tab , nn_pairs_out_tab , phi_n_table);
  
  if (is_pn_non_zero && (Np_nljm_baryon > 0) && (Nn_nljm_baryon > 0)) pn_constructor_part (Np_nljm_baryon , Nn_nljm_baryon , pn_pairs_in_tab , pn_pairs_out_tab , phi_p_table , phi_n_table);
  if (is_cv_non_zero && (Np_nljm_baryon > 0) && (Nn_nljm_baryon > 0)) cv_constructor_part ();
  
  dimension_List_pp_nn = dimension_List_pp + dimension_List_nn;
  
  const unsigned int dimension_List_pp_nn_pn = dimension_List_pp_nn + dimension_List_pn;
  
  const unsigned int dimension_List_pp_nn_pn_cv_pp_to_nn = dimension_List_pp_nn_pn + dimension_List_cv_pp_to_nn;
  
  dimension_List = dimension_List_pp_nn_pn_cv_pp_to_nn + dimension_List_cv_nn_to_pp;
  
  nn_sum_dimensions += dimension_List_pp;
 
  pn_sum_dimensions += dimension_List_pp_nn;

  cv_pp_to_nn_sum_dimensions += dimension_List_pp_nn_pn;
  
  cv_nn_to_pp_sum_dimensions += dimension_List_pp_nn_pn_cv_pp_to_nn;
  
  if (dimension_List == 0)
    {
      pp_pairs_in_indices = 0 , pp_pairs_out_indices = 0;
      nn_pairs_in_indices = 0 , nn_pairs_out_indices = 0;
      pn_pairs_in_indices = 0 , pn_pairs_out_indices = 0;
    
      pairs_in_indices  = 0;
      pairs_out_indices = 0;
    
      return;
    }
  
  List = new TYPE [dimension_List];

  for (unsigned int i = 0 ; i < dimension_List ; i++) List[i] = 0.0;
	
  const unsigned int dimension_pp_pairs_in = pp_pairs_in_tab.dimension (0) , dimension_pp_pairs_out = pp_pairs_out_tab.dimension (0);
  const unsigned int dimension_nn_pairs_in = nn_pairs_in_tab.dimension (0) , dimension_nn_pairs_out = nn_pairs_out_tab.dimension (0);
  const unsigned int dimension_pn_pairs_in = pn_pairs_in_tab.dimension (0) , dimension_pn_pairs_out = pn_pairs_out_tab.dimension (0);

  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);

  if (is_pp_calculated)
    {
      for (unsigned int p = 0 ; p < Np_nljm_baryon ; p++)
	for (unsigned int pp = 0 ; pp < Np_nljm_baryon ; pp++)
	  {
	    pp_pairs_in_indices (p , pp) = min (pp_pairs_in_indices (p , pp) , dimension_List);
	    pp_pairs_out_indices(p , pp) = min (pp_pairs_out_indices(p , pp) , dimension_List);
	  }
      
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif  
      for (unsigned int i_pair_in = 0 ; i_pair_in < dimension_pp_pairs_in ; i_pair_in++)
	{
	  const class pair_str &pair_in = pp_pairs_in_tab(i_pair_in);
      
	  const unsigned int p_in  = pair_in.get_left ();
	  const unsigned int pp_in = pair_in.get_right ();

	  const unsigned int bp_in = bp_pp_table(p_in , pp_in);
      
	  const int s_in = strangeness_pp_table(p_in , pp_in);
      
	  const int im_in = im_pp_table(p_in , pp_in);

	  for (unsigned int i_pair_out = 0 ; i_pair_out < dimension_pp_pairs_out ; i_pair_out++)
	    {
	      const class pair_str &pair_out = pp_pairs_out_tab(i_pair_out);

	      const unsigned int p_out  = pair_out.get_left ();
	      const unsigned int pp_out = pair_out.get_right ();

	      const unsigned int bp_out = bp_pp_table(p_out , pp_out);
	  
	      const int s_out = strangeness_pp_table(p_out , pp_out);
      
	      const int im_out = im_pp_table(p_out , pp_out);

	      if ((bp_in == bp_out) && (s_in == s_out) && (im_in == im_out))
		{
		  const unsigned int index = pp_index_determine (p_in , pp_in , p_out , pp_out);
  
		  List[index] = TBMEs_pp.M_TBME (false , p_in , pp_in , p_out , pp_out);
		}
	    }

	  if (is_cv_non_zero)
	    {
	      for (unsigned int i_pair_out = 0 ; i_pair_out < dimension_nn_pairs_out ; i_pair_out++)
		{
		  const class pair_str &pair_out = nn_pairs_out_tab(i_pair_out);
	  
		  const unsigned int n_out  = pair_out.get_left ();
		  const unsigned int nn_out = pair_out.get_right ();

		  const unsigned int bp_out = bp_nn_table(n_out , nn_out);
	  
		  const int s_out = strangeness_nn_table(n_out , nn_out);
      
		  const int im_out = im_nn_table(n_out , nn_out);

		  if ((bp_in == bp_out) && (s_in == s_out) && (im_in == im_out))
		    {
		      const unsigned int index = cv_pp_to_nn_index_determine (p_in , pp_in , n_out , nn_out);

		      List[index] = TBMEs_cv.M_TBME (true , p_in , pp_in , n_out , nn_out);
		    }
		}
	    }	  
	}
    }

  if (is_nn_calculated)
    {
      for (unsigned int n = 0 ; n < Nn_nljm_baryon ; n++)
	for (unsigned int nn = 0 ; nn < Nn_nljm_baryon ; nn++)
	  {
	    nn_pairs_in_indices (n , nn) = min (nn_pairs_in_indices (n , nn) , dimension_List);
	    nn_pairs_out_indices(n , nn) = min (nn_pairs_out_indices(n , nn) , dimension_List);
	  }
      
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif  
      for (unsigned int i_pair_in = 0 ; i_pair_in < dimension_nn_pairs_in ; i_pair_in++)
	{
	  const class pair_str &pair_in = nn_pairs_in_tab(i_pair_in);
      
	  const unsigned int n_in  = pair_in.get_left ();
	  const unsigned int nn_in = pair_in.get_right ();

	  const unsigned int bp_in = bp_nn_table(n_in , nn_in);
      
	  const int s_in = strangeness_nn_table(n_in , nn_in);
      
	  const int im_in = im_nn_table(n_in , nn_in);

	  for (unsigned int i_pair_out = 0 ; i_pair_out < dimension_nn_pairs_out ; i_pair_out++)
	    {
	      const class pair_str &pair_out = nn_pairs_out_tab(i_pair_out);

	      const unsigned int n_out  = pair_out.get_left ();
	      const unsigned int nn_out = pair_out.get_right ();

	      const unsigned int bp_out = bp_nn_table(n_out , nn_out);
	  
	      const int s_out = strangeness_nn_table(n_out , nn_out);
      
	      const int im_out = im_nn_table(n_out , nn_out);

	      if ((bp_in == bp_out) && (s_in == s_out) && (im_in == im_out))
		{
		  const unsigned int index = nn_index_determine (n_in , nn_in , n_out , nn_out);

		  List[index] = TBMEs_nn.M_TBME (false , n_in , nn_in , n_out , nn_out);
		}
	    }
	  
	  if (is_cv_non_zero)
	    {
	      for (unsigned int i_pair_out = 0 ; i_pair_out < dimension_nn_pairs_out ; i_pair_out++)
		{
		  const class pair_str &pair_out = pp_pairs_out_tab(i_pair_out);

		  const unsigned int p_out  = pair_out.get_left ();
		  const unsigned int pp_out = pair_out.get_right ();

		  const unsigned int bp_out = bp_pp_table(p_out , pp_out);
	  
		  const int s_out = strangeness_pp_table(p_out , pp_out);
      
		  const int im_out = im_pp_table(p_out , pp_out);

		  if ((bp_in == bp_out) && (s_in == s_out) && (im_in == im_out))
		    {
		      const unsigned int index = cv_nn_to_pp_index_determine (n_in , nn_in , p_out , pp_out);

		      List[index] = TBMEs_cv.M_TBME (false , n_in , nn_in , p_out , pp_out);
		    }
		}
	    }
	}
    }
  
  if (is_pn_non_zero)
    {
      for (unsigned int p = 0 ; p < Np_nljm_baryon ; p++)
	for (unsigned int n = 0 ; n < Nn_nljm_baryon ; n++)
	  {
	    pn_pairs_in_indices (p , n) = min (pn_pairs_in_indices (p , n) , dimension_List);
	    pn_pairs_out_indices(p , n) = min (pn_pairs_out_indices(p , n) , dimension_List);
	  }
      
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif  
      for (unsigned int i_pair_in = 0 ; i_pair_in < dimension_pn_pairs_in ; i_pair_in++)
	{
	  const class pair_str &pair_in = pn_pairs_in_tab(i_pair_in);
      
	  const unsigned int p_in = pair_in.get_left ();
	  const unsigned int n_in = pair_in.get_right ();

	  const unsigned int bp_in = bp_pn_table(p_in , n_in);
      
	  const int s_in = strangeness_pn_table(p_in , n_in);
      
	  const int im_in = im_pn_table(p_in , n_in);

	  for (unsigned int i_pair_out = 0 ; i_pair_out < dimension_pn_pairs_out ; i_pair_out++)
	    {
	      const class pair_str &pair_out = pn_pairs_out_tab(i_pair_out);
	  
	      const unsigned int p_out = pair_out.get_left ();
	      const unsigned int n_out = pair_out.get_right ();

	      const unsigned int bp_out = bp_pn_table(p_out , n_out);
	  
	      const int s_out = strangeness_pn_table(p_out , n_out);
      
	      const int im_out = im_pn_table(p_out , n_out);

	      if ((bp_in == bp_out) && (s_in == s_out) && (im_in == im_out))
		{
		  const unsigned int index = pn_index_determine (p_in , n_in , p_out , n_out);

		  List[index] = TBMEs_pn.M_TBME (false , p_in , n_in , p_out , n_out);
		}
	    }
	}
    }  
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time;
      
      cout << endl << "Uncoupled TBMEs calculated. time:" << relative_time << " s" << endl << endl;
    }
}







void uncoupled_TBMEs_class::pp_constructor_part (
						 const unsigned int Np_nljm_baryon ,
						 const class array<class pair_str> &pp_pairs_in_tab , 
						 const class array<class pair_str> &pp_pairs_out_tab , 
						 const class array<class nljm_struct> &phi_p_table)
 
{ 
  bp_pp_table.allocate (Np_nljm_baryon , Np_nljm_baryon);

  strangeness_pp_table.allocate (Np_nljm_baryon , Np_nljm_baryon);
  
  im_pp_table.allocate (Np_nljm_baryon , Np_nljm_baryon);

  class array<bool> are_there_frozen_states_spectators_pp_table(Np_nljm_baryon , Np_nljm_baryon);
  
  int strangeness_pp_max = 0;
  
  int im_pp_max = 0;

  for (unsigned int p = 0 ; p < Np_nljm_baryon ; p++)
    for (unsigned int pp = 0 ; pp < Np_nljm_baryon ; pp++)
      {
	const class nljm_struct &phi_p  = phi_p_table(p);
	const class nljm_struct &phi_pp = phi_p_table(pp);
			      
	const enum particle_type particle_p  = phi_p.get_particle ();
	const enum particle_type particle_pp = phi_pp.get_particle ();
	
	const class pair_str pair(particle_p , p , particle_pp , pp);

	const bool are_there_frozen_states = pair.are_there_frozen_states_determine (phi_p_table , phi_p_table);

	const bool are_there_spectator_states = pair.are_there_spectator_states_determine ();
	
	const unsigned int bp = pair.bp_determine (phi_p_table , phi_p_table);

	const int s = pair.strangeness_determine ();
      
	const int im = pair.im_determine (phi_p_table , phi_p_table);
	
	are_there_frozen_states_spectators_pp_table(p , pp) = (are_there_frozen_states || are_there_spectator_states);
	
	bp_pp_table(p , pp) = bp;

	strangeness_pp_table(p , pp) = s;

	im_pp_table(p , pp) = im;

	strangeness_pp_max = max (strangeness_pp_max , s);
	
	im_pp_max = max (im_pp_max , im);
      }

  const int strangeness_pp_max_plus_one = strangeness_pp_max + 1;
  
  const int im_pp_max_plus_one = im_pp_max + 1;

  dimensions_pp_pairs_in.allocate  (2 , strangeness_pp_max_plus_one , im_pp_max_plus_one);  
  dimensions_pp_pairs_out.allocate (2 , strangeness_pp_max_plus_one , im_pp_max_plus_one);

  dimensions_pp_pairs_in  = 0;
  dimensions_pp_pairs_out = 0;

  pp_pairs_in_indices.allocate  (Np_nljm_baryon , Np_nljm_baryon);
  pp_pairs_out_indices.allocate (Np_nljm_baryon , Np_nljm_baryon);

  pp_pairs_in_indices  = INFINITE_PAIR_INDEX;
  pp_pairs_out_indices = INFINITE_PAIR_INDEX;

  const unsigned int dimension_pp_pairs_in = pp_pairs_in_tab.dimension (0);
  
  const unsigned int dimension_pp_pairs_out = pp_pairs_out_tab.dimension (0);

  for (unsigned int i_pair_in = 0 ; i_pair_in < dimension_pp_pairs_in ;  i_pair_in++)
    {
      const class pair_str &pair = pp_pairs_in_tab(i_pair_in);
      	
      const unsigned int p  = pair.get_left ();
      const unsigned int pp = pair.get_right ();

      const bool are_there_frozen_spectator_states = are_there_frozen_states_spectators_pp_table(p , pp);

      if (are_there_frozen_spectator_states) continue;
      
      const unsigned int bp = bp_pp_table(p , pp);
      
      const int s = strangeness_pp_table(p , pp);
      
      const int im = im_pp_table(p , pp);
      
      pp_pairs_in_indices(p , pp) = dimensions_pp_pairs_in(bp , s , im)++;
    }

  for (unsigned int i_pair_out = 0 ; i_pair_out < dimension_pp_pairs_out ; i_pair_out++)
    {
      const class pair_str &pair = pp_pairs_out_tab(i_pair_out);
      
      const unsigned int p  = pair.get_left ();
      const unsigned int pp = pair.get_right ();

      const bool are_there_frozen_spectator_states = are_there_frozen_states_spectators_pp_table(p , pp);

      if (are_there_frozen_spectator_states) continue;
      
      const unsigned int bp = bp_pp_table(p , pp);

      const int s = strangeness_pp_table(p , pp);
      
      const int im = im_pp_table(p , pp);

      pp_pairs_out_indices(p , pp) = dimensions_pp_pairs_out(bp , s , im)++;
    }

  unsigned int pp_sum_dimensions_bef = 0;

  unsigned int pp_dimension_bef = 0;

  pp_sum_dimensions.allocate (2 , strangeness_pp_max_plus_one , im_pp_max_plus_one);

  for (unsigned int bp = 0 ; bp <= 1 ; bp++)
    for (int s = 0 ; s <= strangeness_pp_max ; s++)
      for (int im = 0 ; im <= im_pp_max ; im++)
	{
	  const unsigned int pp_dimension_in  = dimensions_pp_pairs_in (bp , s , im);
	  const unsigned int pp_dimension_out = dimensions_pp_pairs_out(bp , s , im);
	  
	  const unsigned int pp_dimension = pp_dimension_in*pp_dimension_out;
	
	  unsigned int &pp_sum_dimensions_bp_s_m = pp_sum_dimensions(bp , s , im);
	  
	  pp_sum_dimensions_bp_s_m = pp_sum_dimensions_bef + pp_dimension_bef;
	
	  dimension_List_pp += pp_dimension;

	  pp_dimension_bef = pp_dimension;

	  pp_sum_dimensions_bef = pp_sum_dimensions_bp_s_m;
	}
}



void uncoupled_TBMEs_class::nn_constructor_part (
						 const unsigned int Nn_nljm_baryon ,
						 const class array<class pair_str> &nn_pairs_in_tab , 
						 const class array<class pair_str> &nn_pairs_out_tab , 
						 const class array<class nljm_struct> &phi_n_table)
{ 
  bp_nn_table.allocate (Nn_nljm_baryon , Nn_nljm_baryon);

  strangeness_nn_table.allocate (Nn_nljm_baryon , Nn_nljm_baryon);
  
  im_nn_table.allocate (Nn_nljm_baryon , Nn_nljm_baryon);

  class array<bool> are_there_frozen_states_spectators_nn_table(Nn_nljm_baryon , Nn_nljm_baryon);
  
  int strangeness_nn_max = 0;
  
  int im_nn_max = 0;

  for (unsigned int n = 0 ; n < Nn_nljm_baryon ; n++)
    for (unsigned int nn = 0 ; nn < Nn_nljm_baryon ; nn++)
      {
	const class nljm_struct &phi_n  = phi_n_table(n);
	const class nljm_struct &phi_nn = phi_n_table(nn);
			      
	const enum particle_type particle_n  = phi_n.get_particle ();
	const enum particle_type particle_nn = phi_nn.get_particle ();
	
	const class pair_str pair(particle_n , n , particle_nn , nn);

	const bool are_there_frozen_states = pair.are_there_frozen_states_determine (phi_n_table , phi_n_table);

	const bool are_there_spectator_states = pair.are_there_spectator_states_determine ();
	
	const unsigned int bp = pair.bp_determine (phi_n_table , phi_n_table);
	
	const int s = pair.strangeness_determine ();
	
	const int im = pair.im_determine (phi_n_table , phi_n_table);
	
	are_there_frozen_states_spectators_nn_table(n , nn) = (are_there_frozen_states || are_there_spectator_states);
	
	bp_nn_table(n , nn) = bp;

	strangeness_nn_table(n , nn) = s;

	im_nn_table(n , nn) = im;

	strangeness_nn_max = max (strangeness_nn_max , s);
	
	im_nn_max = max (im_nn_max , im);
      }

  const int strangeness_nn_max_plus_one = strangeness_nn_max + 1;
  
  const int im_nn_max_plus_one = im_nn_max + 1;

  dimensions_nn_pairs_in.allocate  (2 , strangeness_nn_max_plus_one , im_nn_max_plus_one);  
  dimensions_nn_pairs_out.allocate (2 , strangeness_nn_max_plus_one , im_nn_max_plus_one);

  dimensions_nn_pairs_in  = 0;
  dimensions_nn_pairs_out = 0;

  nn_pairs_in_indices.allocate  (Nn_nljm_baryon , Nn_nljm_baryon);
  nn_pairs_out_indices.allocate (Nn_nljm_baryon , Nn_nljm_baryon);

  nn_pairs_in_indices  = INFINITE_PAIR_INDEX ;
  nn_pairs_out_indices = INFINITE_PAIR_INDEX;
  
  const unsigned int dimension_nn_pairs_in = nn_pairs_in_tab.dimension (0);
  
  const unsigned int dimension_nn_pairs_out = nn_pairs_out_tab.dimension (0);
      
  for (unsigned int i_pair_in = 0 ; i_pair_in < dimension_nn_pairs_in ; i_pair_in++)
    {
      const class pair_str &pair = nn_pairs_in_tab(i_pair_in);

      const unsigned int n  = pair.get_left ();
      const unsigned int nn = pair.get_right ();

      const bool are_there_frozen_spectator_states = are_there_frozen_states_spectators_nn_table(n , nn);
      
      if (are_there_frozen_spectator_states) continue;
      
      const unsigned int bp = bp_nn_table(n , nn);

      const int s = strangeness_nn_table(n , nn);
      
      const int im = im_nn_table(n , nn);
  
      nn_pairs_in_indices(n , nn) = dimensions_nn_pairs_in(bp , s , im)++;      
    }  

  for (unsigned int i_pair_out = 0 ; i_pair_out < dimension_nn_pairs_out ; i_pair_out++)
    {
      const class pair_str &pair = nn_pairs_out_tab(i_pair_out);
      
      const unsigned int n  = pair.get_left ();
      const unsigned int nn = pair.get_right ();

      const bool are_there_frozen_spectator_states = are_there_frozen_states_spectators_nn_table(n , nn);
      
      if (are_there_frozen_spectator_states) continue;
      
      const unsigned int bp = bp_nn_table(n , nn);

      const int s = strangeness_nn_table(n , nn);
      
      const int im = im_nn_table(n , nn);
            
      nn_pairs_out_indices(n , nn) = dimensions_nn_pairs_out(bp , s , im)++;
    }
      
  unsigned int nn_sum_dimensions_bef = 0;

  unsigned int nn_dimension_bef = 0;

  nn_sum_dimensions.allocate (2 , strangeness_nn_max_plus_one , im_nn_max_plus_one);
      
  for (unsigned int bp = 0 ; bp <= 1 ; bp++)
    for (int s = 0 ; s <= strangeness_nn_max ; s++)
      for (int im = 0 ; im <= im_nn_max ; im++)
	{
	  const unsigned int nn_dimension_in  = dimensions_nn_pairs_in (bp , s , im);
	  const unsigned int nn_dimension_out = dimensions_nn_pairs_out(bp , s , im);
	  
	  const unsigned int nn_dimension = nn_dimension_in*nn_dimension_out;

	  unsigned int &nn_sum_dimensions_bp_s_m = nn_sum_dimensions(bp , s , im);
	  
	  nn_sum_dimensions_bp_s_m = nn_sum_dimensions_bef + nn_dimension_bef;

	  dimension_List_nn += nn_dimension;

	  nn_dimension_bef = nn_dimension;

	  nn_sum_dimensions_bef = nn_sum_dimensions_bp_s_m;
	}
}



void uncoupled_TBMEs_class::pn_constructor_part (
						 const unsigned int Np_nljm_baryon ,
						 const unsigned int Nn_nljm_baryon ,
						 const class array<class pair_str> &pn_pairs_in_tab , 
						 const class array<class pair_str> &pn_pairs_out_tab , 
						 const class array<class nljm_struct> &phi_p_table , 
						 const class array<class nljm_struct> &phi_n_table)
{
  bp_pn_table.allocate (Np_nljm_baryon , Nn_nljm_baryon);

  strangeness_pn_table.allocate (Np_nljm_baryon , Nn_nljm_baryon);
  
  im_pn_table.allocate (Np_nljm_baryon , Nn_nljm_baryon);

  class array<bool> are_there_frozen_states_spectators_pn_table(Np_nljm_baryon , Nn_nljm_baryon);
  
  int strangeness_pn_max = 0;
  
  int im_pn_max = 0;

  for (unsigned int p = 0 ; p < Np_nljm_baryon ; p++)
    for (unsigned int n = 0 ; n < Nn_nljm_baryon ; n++)
      {
	const class nljm_struct &phi_p = phi_p_table(p);
	const class nljm_struct &phi_n = phi_n_table(n);
			      
	const enum particle_type particle_p = phi_p.get_particle ();
	const enum particle_type particle_n = phi_n.get_particle ();
	
	const class pair_str pair(particle_p , p , particle_n , n);

	const bool are_there_frozen_states = pair.are_there_frozen_states_determine (phi_p_table , phi_n_table);

	const bool are_there_spectator_states = pair.are_there_spectator_states_determine ();
	
	const unsigned int bp = pair.bp_determine (phi_p_table , phi_n_table);

	const int s = pair.strangeness_determine ();
	
	const int im = pair.im_determine (phi_p_table , phi_n_table);
	
	are_there_frozen_states_spectators_pn_table(p , n) = (are_there_frozen_states || are_there_spectator_states);
	
	bp_pn_table(p , n) = bp;

	strangeness_pn_table(p , n) = s;

	im_pn_table(p , n) = im;

	im_pn_max = max (im_pn_max , im);
      }

  const int strangeness_pn_max_plus_one = strangeness_pn_max + 1;
  
  const int im_pn_max_plus_one = im_pn_max + 1;

  dimensions_pn_pairs_in.allocate  (2 , strangeness_pn_max_plus_one , im_pn_max_plus_one);
  dimensions_pn_pairs_out.allocate (2 , strangeness_pn_max_plus_one , im_pn_max_plus_one);

  dimensions_pn_pairs_in  = 0;
  dimensions_pn_pairs_out = 0;
  
  pn_pairs_in_indices.allocate  (Np_nljm_baryon , Nn_nljm_baryon);
  pn_pairs_out_indices.allocate (Np_nljm_baryon , Nn_nljm_baryon);

  pn_pairs_in_indices  = INFINITE_PAIR_INDEX;
  pn_pairs_out_indices = INFINITE_PAIR_INDEX;

  const unsigned int dimension_pn_pairs_in = pn_pairs_in_tab.dimension (0);
  
  const unsigned int dimension_pn_pairs_out = pn_pairs_out_tab.dimension (0);

  for (unsigned int i_pair_in = 0 ; i_pair_in < dimension_pn_pairs_in ; i_pair_in++)
    {
      const class pair_str &pair = pn_pairs_in_tab(i_pair_in);

      const unsigned int p = pair.get_left ();
      const unsigned int n = pair.get_right ();

      const bool are_there_frozen_spectator_states = are_there_frozen_states_spectators_pn_table(p , n);

      if (are_there_frozen_spectator_states) continue;
      
      const unsigned int bp = bp_pn_table(p , n);

      const int s = strangeness_pn_table(p , n);
      
      const int im = im_pn_table(p , n);

      pn_pairs_in_indices(p , n) = dimensions_pn_pairs_in(bp , s , im)++;
    }
  
  for (unsigned int i_pair_out = 0 ; i_pair_out < dimension_pn_pairs_out ; i_pair_out++)
    {
      const class pair_str &pair = pn_pairs_out_tab(i_pair_out);

      const unsigned int p = pair.get_left ();
      const unsigned int n = pair.get_right ();

      const bool are_there_frozen_spectator_states = are_there_frozen_states_spectators_pn_table(p , n);

      if (are_there_frozen_spectator_states) continue;
      
      const unsigned int bp = bp_pn_table(p , n);

      const int s = strangeness_pn_table(p , n);
      
      const int im = im_pn_table(p , n);

      pn_pairs_out_indices(p , n) = dimensions_pn_pairs_out(bp , s , im)++;
    }

  unsigned int pn_sum_dimensions_bef = 0;

  unsigned int pn_dimension_bef = 0;

  pn_sum_dimensions.allocate (2 , strangeness_pn_max_plus_one , im_pn_max_plus_one);

  for (unsigned int bp = 0 ; bp <= 1 ; bp++)
    for (int s = 0 ; s <= strangeness_pn_max ; s++)
      for (int im = 0 ; im <= im_pn_max ; im++)
	{
	  const unsigned int pn_dimension_in  = dimensions_pn_pairs_in (bp , s , im);
	  const unsigned int pn_dimension_out = dimensions_pn_pairs_out(bp , s , im);
	  
	  const unsigned int pn_dimension = pn_dimension_in*pn_dimension_out;

	  unsigned int &pn_sum_dimensions_bp_s_m = pn_sum_dimensions(bp , s , im);
	  
	  pn_sum_dimensions_bp_s_m = pn_sum_dimensions_bef + pn_dimension_bef;

	  dimension_List_pn += pn_dimension;

	  pn_dimension_bef = pn_dimension;

	  pn_sum_dimensions_bef = pn_sum_dimensions_bp_s_m;
	}
}


void uncoupled_TBMEs_class::cv_constructor_part ()
{
  const int strangeness_pp_max = pp_sum_dimensions.dimension (1) - 1 , im_pp_max = pp_sum_dimensions.dimension (2) - 1;
  const int strangeness_nn_max = nn_sum_dimensions.dimension (1) - 1 , im_nn_max = nn_sum_dimensions.dimension (2) - 1;

  const int strangeness_cv_max = min (strangeness_pp_max , strangeness_nn_max);
      
  const int im_cv_max = min (im_pp_max , im_nn_max);
      
  const int strangeness_cv_max_plus_one = strangeness_cv_max + 1;
  
  const int im_cv_max_plus_one = im_cv_max + 1;
  
  unsigned int cv_pp_to_nn_sum_dimensions_bef = 0;
  unsigned int cv_nn_to_pp_sum_dimensions_bef = 0;

  unsigned int cv_pp_to_nn_dimension_bef = 0;
  unsigned int cv_nn_to_pp_dimension_bef = 0;

  cv_pp_to_nn_sum_dimensions.allocate (2 , strangeness_cv_max_plus_one , im_cv_max_plus_one);
  cv_nn_to_pp_sum_dimensions.allocate (2 , strangeness_cv_max_plus_one , im_cv_max_plus_one);
  
  for (unsigned int bp = 0 ; bp <= 1 ; bp++)
    for (int s = 0 ; s <= strangeness_cv_max ; s++)
      for (int im = 0 ; im <= im_cv_max ; im++)
	{
	  const unsigned int pp_dimension_in  = dimensions_pp_pairs_in (bp , s , im);
	  const unsigned int nn_dimension_out = dimensions_nn_pairs_out(bp , s , im);
	  
	  const unsigned int cv_pp_to_nn_dimension = pp_dimension_in*nn_dimension_out;

	  unsigned int &cv_pp_to_nn_sum_dimensions_bp_s_m = cv_pp_to_nn_sum_dimensions(bp , s , im);
	  
	  cv_pp_to_nn_sum_dimensions_bp_s_m = cv_pp_to_nn_sum_dimensions_bef + cv_pp_to_nn_dimension_bef;

	  dimension_List_cv_pp_to_nn += cv_pp_to_nn_dimension;

	  cv_pp_to_nn_dimension_bef = cv_pp_to_nn_dimension;

	  cv_pp_to_nn_sum_dimensions_bef = cv_pp_to_nn_sum_dimensions_bp_s_m;
	}
      
  for (unsigned int bp = 0 ; bp <= 1 ; bp++)
    for (int s = 0 ; s <= strangeness_cv_max ; s++)
      for (int im = 0 ; im <= im_cv_max ; im++)
	{
	  const unsigned int nn_dimension_in  = dimensions_nn_pairs_in (bp , s , im);
	  const unsigned int pp_dimension_out = dimensions_pp_pairs_out(bp , s , im);
	  
	  const unsigned int cv_nn_to_pp_dimension = nn_dimension_in*pp_dimension_out;

	  unsigned int &cv_nn_to_pp_sum_dimensions_bp_s_m = cv_nn_to_pp_sum_dimensions(bp , s , im);
	  
	  cv_nn_to_pp_sum_dimensions_bp_s_m = cv_nn_to_pp_sum_dimensions_bef + cv_nn_to_pp_dimension_bef;

	  dimension_List_cv_nn_to_pp += cv_nn_to_pp_dimension;

	  cv_nn_to_pp_dimension_bef = cv_nn_to_pp_dimension;

	  cv_nn_to_pp_sum_dimensions_bef = cv_nn_to_pp_sum_dimensions_bp_s_m;
	}
}


void uncoupled_TBMEs_class::allocate_fill (const class uncoupled_TBMEs_class &X)
{
  zero_TBME = X.zero_TBME;
  
  is_it_pp_nn = X.is_it_pp_nn;
  
  dimension_List_pp = X.dimension_List_pp;
  dimension_List_nn = X.dimension_List_nn;
  dimension_List_pn = X.dimension_List_pn;
  
  dimension_List_cv_pp_to_nn = X.dimension_List_cv_pp_to_nn;
  dimension_List_cv_nn_to_pp = X.dimension_List_cv_nn_to_pp;
  
  dimension_List_pp_nn = X.dimension_List_pp_nn;
  
  dimension_List = X.dimension_List;
    
  dimensions_pp_pairs_in.allocate_fill (X.dimensions_pp_pairs_in);
  dimensions_nn_pairs_in.allocate_fill (X.dimensions_nn_pairs_in);
  dimensions_pn_pairs_in.allocate_fill (X.dimensions_pn_pairs_in);
  
  dimensions_pp_pairs_out.allocate_fill (X.dimensions_pp_pairs_out);
  dimensions_nn_pairs_out.allocate_fill (X.dimensions_nn_pairs_out);
  dimensions_pn_pairs_out.allocate_fill (X.dimensions_pn_pairs_out);

  pp_sum_dimensions.allocate_fill (X.pp_sum_dimensions);
  nn_sum_dimensions.allocate_fill (X.nn_sum_dimensions);
  pn_sum_dimensions.allocate_fill (X.pn_sum_dimensions);
  
  cv_pp_to_nn_sum_dimensions.allocate_fill (X.cv_pp_to_nn_sum_dimensions);
  cv_nn_to_pp_sum_dimensions.allocate_fill (X.cv_nn_to_pp_sum_dimensions);

  dimensions_pairs_in.allocate_fill (X.dimensions_pairs_in);
  
  dimensions_pairs_out.allocate_fill (X.dimensions_pairs_out);

  sum_dimensions.allocate_fill (X.sum_dimensions);

  bp_pp_table.allocate_fill (X.bp_pp_table);
  bp_nn_table.allocate_fill (X.bp_nn_table);
  bp_pn_table.allocate_fill (X.bp_pn_table);
  
  strangeness_pp_table.allocate_fill (X.strangeness_pp_table);
  strangeness_nn_table.allocate_fill (X.strangeness_nn_table);
  strangeness_pn_table.allocate_fill (X.strangeness_pn_table);
  
  im_pp_table.allocate_fill (X.im_pp_table);
  im_nn_table.allocate_fill (X.im_nn_table);
  im_pn_table.allocate_fill (X.im_pn_table);
  
  pp_pairs_in_indices.allocate_fill (X.pp_pairs_in_indices);
  nn_pairs_in_indices.allocate_fill (X.nn_pairs_in_indices);
  pn_pairs_in_indices.allocate_fill (X.pn_pairs_in_indices);
  
  pp_pairs_out_indices.allocate_fill (X.pp_pairs_out_indices);
  nn_pairs_out_indices.allocate_fill (X.nn_pairs_out_indices);
  pn_pairs_out_indices.allocate_fill (X.pn_pairs_out_indices);

  bp_table.allocate_fill (X.bp_table);
  
  strangeness_table.allocate_fill (X.strangeness_table);

  im_table.allocate_fill (X.im_table);
  
  pairs_in_indices.allocate_fill (X.pairs_in_indices);

  pairs_out_indices.allocate_fill (X.pairs_out_indices);	

  List = (dimension_List > 0) ? (new TYPE [dimension_List]) : (NULL);

  for (unsigned int i = 0 ; i < dimension_List ; i++) List[i] = X.List[i]; 
}










void uncoupled_TBMEs_class::deallocate ()
{
  dimensions_pp_pairs_in.deallocate ();
  dimensions_nn_pairs_in.deallocate ();
  dimensions_pn_pairs_in.deallocate ();
  
  dimensions_pp_pairs_out.deallocate ();
  dimensions_nn_pairs_out.deallocate ();
  dimensions_pn_pairs_out.deallocate ();
  
  pp_sum_dimensions.deallocate ();
  nn_sum_dimensions.deallocate ();
  pn_sum_dimensions.deallocate ();
  
  cv_pp_to_nn_sum_dimensions.deallocate ();
  cv_nn_to_pp_sum_dimensions.deallocate ();
  
  dimensions_pairs_in.deallocate ();
  
  dimensions_pairs_out.deallocate ();
  
  sum_dimensions.deallocate ();

  bp_pp_table.deallocate ();
  bp_nn_table.deallocate ();
  bp_pn_table.deallocate ();
  
  strangeness_pp_table.deallocate ();
  strangeness_nn_table.deallocate ();
  strangeness_pn_table.deallocate ();
  
  im_pp_table.deallocate ();
  im_nn_table.deallocate ();
  im_pn_table.deallocate ();
  
  pp_pairs_in_indices.deallocate ();
  nn_pairs_in_indices.deallocate ();
  pn_pairs_in_indices.deallocate ();
  
  pp_pairs_out_indices.deallocate ();
  nn_pairs_out_indices.deallocate ();
  pn_pairs_out_indices.deallocate ();

  bp_table.deallocate ();
  
  strangeness_table.deallocate ();
  
  im_table.deallocate ();
  
  pairs_in_indices.deallocate ();

  pairs_out_indices.deallocate ();

  dimension_List_pp = 0;
  dimension_List_nn = 0;
  dimension_List_pn = 0;
    
  dimension_List_cv_pp_to_nn = 0;
  dimension_List_cv_nn_to_pp = 0;
  
  dimension_List_pp_nn = 0;
  
  dimension_List = 0;
    
  delete [] List;

  List = NULL;
  
  zero_TBME = 0.0;
}







unsigned int uncoupled_TBMEs_class::pp_index_determine (
							const unsigned int p_in ,
							const unsigned int pp_in , 
							const unsigned int p_out ,
							const unsigned int pp_out) const
{
  const unsigned int pp_pair_index_out = pp_pairs_out_indices(p_out , pp_out);

  const unsigned int p_pp_in_index = pp_pairs_in_indices.index_determine (p_in , pp_in);
  
  const unsigned int pp_pair_index_in = pp_pairs_in_indices[p_pp_in_index];
    
  const unsigned int bp = bp_pp_table[p_pp_in_index];
  
  const int s = strangeness_pp_table[p_pp_in_index];
  
  const int im = im_pp_table[p_pp_in_index];

  const unsigned int bp_s_im_index = dimensions_pp_pairs_in.index_determine (bp , s , im);
  
  const unsigned int dimension_pp_pairs_in_bp_s_im = dimensions_pp_pairs_in[bp_s_im_index];

  const unsigned int pp_sum_dimensions_bp_s_im = pp_sum_dimensions[bp_s_im_index];
  
  const unsigned int index = pp_pair_index_in + dimension_pp_pairs_in_bp_s_im*pp_pair_index_out + pp_sum_dimensions_bp_s_im;
	      
  return index;
}



unsigned int uncoupled_TBMEs_class::nn_index_determine (
							const unsigned int n_in ,
							const unsigned int nn_in , 
							const unsigned int n_out ,
							const unsigned int nn_out) const
{
  const unsigned int nn_pair_index_out = nn_pairs_out_indices(n_out , nn_out);
  
  const unsigned int n_nn_in_index = nn_pairs_in_indices.index_determine (n_in , nn_in);
  
  const unsigned int nn_pair_index_in = nn_pairs_in_indices[n_nn_in_index];
    
  const unsigned int bp = bp_nn_table[n_nn_in_index];
  
  const int s = strangeness_nn_table[n_nn_in_index];
  
  const int im = im_nn_table[n_nn_in_index];
  
  const unsigned int bp_s_im_index = dimensions_nn_pairs_in.index_determine (bp , s , im);
  
  const unsigned int dimension_nn_pairs_in_bp_s_im = dimensions_nn_pairs_in[bp_s_im_index];

  const unsigned int nn_sum_dimensions_bp_s_im = nn_sum_dimensions[bp_s_im_index];
  
  const unsigned int index = nn_pair_index_in + dimension_nn_pairs_in_bp_s_im*nn_pair_index_out + nn_sum_dimensions_bp_s_im;

  return index;
}



unsigned int uncoupled_TBMEs_class::pn_index_determine (
							const unsigned int p_in ,
							const unsigned int n_in , 
							const unsigned int p_out ,
							const unsigned int n_out) const
{
  const unsigned int pn_pair_index_out = pn_pairs_out_indices(p_out , n_out);

  const unsigned int pn_in_index = pn_pairs_in_indices.index_determine (p_in , n_in);
  
  const unsigned int pn_pair_index_in = pn_pairs_in_indices[pn_in_index];
    
  const unsigned int bp = bp_pn_table[pn_in_index];

  const int s = strangeness_pn_table[pn_in_index];
  
  const int im = im_pn_table[pn_in_index];
  
  const unsigned int bp_s_im_index = dimensions_pn_pairs_in.index_determine (bp , s , im);
  
  const unsigned int dimension_pn_pairs_in_bp_s_im = dimensions_pn_pairs_in[bp_s_im_index];

  const unsigned int pn_sum_dimensions_bp_s_im = pn_sum_dimensions[bp_s_im_index];
  
  const unsigned int index = pn_pair_index_in + dimension_pn_pairs_in_bp_s_im*pn_pair_index_out + pn_sum_dimensions_bp_s_im;

  return index;
}


unsigned int uncoupled_TBMEs_class::cv_pp_to_nn_index_determine (
								 const unsigned int p_in ,
								 const unsigned int pp_in , 
								 const unsigned int n_out ,
								 const unsigned int nn_out) const
{
  const unsigned int nn_pair_index_out = nn_pairs_out_indices(n_out , nn_out);

  const unsigned int p_pp_in_index = pp_pairs_in_indices.index_determine (p_in , pp_in);
  
  const unsigned int pp_pair_index_in = pp_pairs_in_indices[p_pp_in_index];
    
  const unsigned int bp = bp_pp_table[p_pp_in_index];
  
  const int s = strangeness_pp_table[p_pp_in_index];
    
  const int im = im_pp_table[p_pp_in_index];
  
  const unsigned int bp_s_im_index = dimensions_pp_pairs_in.index_determine (bp , s , im);
  
  const unsigned int dimension_pp_pairs_in_bp_s_im = dimensions_pp_pairs_in[bp_s_im_index];

  const unsigned int cv_pp_to_nn_sum_dimensions_bp_s_im = cv_pp_to_nn_sum_dimensions[bp_s_im_index];
  
  const unsigned int index = pp_pair_index_in + dimension_pp_pairs_in_bp_s_im*nn_pair_index_out + cv_pp_to_nn_sum_dimensions_bp_s_im;

  return index;
}



unsigned int uncoupled_TBMEs_class::cv_nn_to_pp_index_determine (
								 const unsigned int n_in ,
								 const unsigned int nn_in , 
								 const unsigned int p_out ,
								 const unsigned int pp_out) const
{
  const unsigned int pp_pair_index_out = pp_pairs_out_indices(p_out , pp_out);

  const unsigned int n_nn_in_index = nn_pairs_in_indices.index_determine (n_in , nn_in);
  
  const unsigned int nn_pair_index_in = nn_pairs_in_indices[n_nn_in_index];
    
  const unsigned int bp = bp_nn_table[n_nn_in_index];
  
  const int s = strangeness_nn_table[n_nn_in_index];
  
  const int im = im_nn_table[n_nn_in_index];
  
  const unsigned int bp_s_im_index = dimensions_nn_pairs_in.index_determine (bp , s , im);
  
  const unsigned int dimension_nn_pairs_in_bp_s_im = dimensions_nn_pairs_in[bp_s_im_index];

  const unsigned int cv_nn_to_pp_sum_dimensions_bp_s_im = cv_nn_to_pp_sum_dimensions[bp_s_im_index];
  
  const unsigned int index = nn_pair_index_in + dimension_nn_pairs_in_bp_s_im*pp_pair_index_out + cv_nn_to_pp_sum_dimensions_bp_s_im;

  return index;
}



unsigned int uncoupled_TBMEs_class::index_determine_pp_nn (
							   const unsigned int mu_in ,
							   const unsigned int mu_p_in , 
							   const unsigned int mu_out ,
							   const unsigned int mu_p_out) const
{
  const unsigned int pair_index_out = pairs_out_indices(mu_out , mu_p_out);

  const unsigned int mu_mu_p_in_index = pairs_in_indices.index_determine (mu_in , mu_p_in);
  
  const unsigned int pair_index_in = pairs_in_indices[mu_mu_p_in_index];
    
  const unsigned int bp = bp_table[mu_mu_p_in_index];
  
  const int s = strangeness_table[mu_mu_p_in_index];
  
  const int im = im_table[mu_mu_p_in_index];
  
  const unsigned int bp_s_im_index = dimensions_pairs_in.index_determine (bp , s , im);
  
  const unsigned int dimension_pairs_in_bp_s_im = dimensions_pairs_in[bp_s_im_index];

  const unsigned int sum_dimensions_bp_s_im = sum_dimensions[bp_s_im_index];
  
  const unsigned int index = pair_index_in + dimension_pairs_in_bp_s_im*pair_index_out + sum_dimensions_bp_s_im;
	      
  return index;
}



unsigned int uncoupled_TBMEs_class::index_determine (
						     const enum space_type TBME_space ,
						     const bool is_it_cv_pp_to_nn ,
						     const unsigned int left_in , 
						     const unsigned int right_in ,
						     const unsigned int left_out ,
						     const unsigned int right_out) const
{  
  switch (TBME_space)
    {
    case PROT_Y_ONLY:
      {
	const unsigned int index = (is_it_pp_nn) ? (index_determine_pp_nn (left_in , right_in , left_out , right_out)) : (pp_index_determine (left_in , right_in , left_out , right_out));

	return index;
      }

    case NEUT_Y_ONLY:
      {
	const unsigned int index = (is_it_pp_nn) ? (index_determine_pp_nn (left_in , right_in , left_out , right_out)) : (nn_index_determine (left_in , right_in , left_out , right_out));

	return index;
      }

    case PROT_NEUT_Y:
      {
	const unsigned int index = pn_index_determine (left_in , right_in , left_out , right_out);

	return index;
      }  

    case PROT_NEUT_UNMIXED_Y:
      {
	const unsigned int index = (is_it_cv_pp_to_nn) ? (cv_pp_to_nn_index_determine (left_in , right_in , left_out , right_out)) : (cv_nn_to_pp_index_determine (left_in , right_in , left_out , right_out));

	return index;
      }  

    default:
      {
	abort_all ();

	return NADA;
      }  
    }
}


double used_memory_calc (const class uncoupled_TBMEs_class &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = T.dimension_List*sizeof (TYPE)/1000000.0 +
    used_memory_calc (T.dimensions_pp_pairs_in) +
    used_memory_calc (T.dimensions_pp_pairs_out) +
    used_memory_calc (T.pp_sum_dimensions) +
    used_memory_calc (T.dimensions_nn_pairs_in) +
    used_memory_calc (T.dimensions_nn_pairs_out) +
    used_memory_calc (T.nn_sum_dimensions) +
    used_memory_calc (T.dimensions_pn_pairs_in) +
    used_memory_calc (T.dimensions_pn_pairs_out) +
    used_memory_calc (T.pn_sum_dimensions) +
    used_memory_calc (T.cv_pp_to_nn_sum_dimensions) +
    used_memory_calc (T.cv_nn_to_pp_sum_dimensions) +
    used_memory_calc (T.dimensions_pairs_in) +
    used_memory_calc (T.dimensions_pairs_out) +
    used_memory_calc (T.sum_dimensions) +
    used_memory_calc (T.bp_pp_table) +
    used_memory_calc (T.bp_nn_table) +
    used_memory_calc (T.bp_pn_table) +
    used_memory_calc (T.bp_table) +
    used_memory_calc (T.im_pp_table) +
    used_memory_calc (T.im_nn_table) +
    used_memory_calc (T.im_pn_table) +
    used_memory_calc (T.im_table) +
    used_memory_calc (T.strangeness_pp_table) +
    used_memory_calc (T.strangeness_nn_table) +
    used_memory_calc (T.strangeness_pn_table) +
    used_memory_calc (T.strangeness_table) +
    used_memory_calc (T.pp_pairs_in_indices) +
    used_memory_calc (T.pp_pairs_out_indices) +
    used_memory_calc (T.nn_pairs_in_indices) +
    used_memory_calc (T.nn_pairs_out_indices) +
    used_memory_calc (T.pn_pairs_in_indices) +
    used_memory_calc (T.pn_pairs_out_indices) +
    used_memory_calc (T.pairs_in_indices) +
    used_memory_calc (T.pairs_out_indices)
    - (sizeof (T.dimensions_pp_pairs_in) +
       sizeof (T.dimensions_pp_pairs_out) +
       sizeof (T.pp_sum_dimensions) +
       sizeof (T.dimensions_nn_pairs_in) +
       sizeof (T.dimensions_nn_pairs_out) +
       sizeof (T.nn_sum_dimensions) +
       sizeof (T.dimensions_pn_pairs_in) +
       sizeof (T.dimensions_pn_pairs_out) +
       sizeof (T.pn_sum_dimensions) +
       sizeof (T.cv_pp_to_nn_sum_dimensions) +
       sizeof (T.cv_nn_to_pp_sum_dimensions) +
       sizeof (T.dimensions_pairs_in) +
       sizeof (T.dimensions_pairs_out) +
       sizeof (T.sum_dimensions) +
       sizeof (T.bp_pp_table) +
       sizeof (T.bp_nn_table) +
       sizeof (T.bp_pn_table) +
       sizeof (T.bp_table) +
       sizeof (T.im_pp_table) +
       sizeof (T.im_nn_table) +
       sizeof (T.im_pn_table) +
       sizeof (T.im_table) +
       sizeof (T.strangeness_pp_table) +
       sizeof (T.strangeness_nn_table) +
       sizeof (T.strangeness_pn_table) +
       sizeof (T.strangeness_table) +
       sizeof (T.pp_pairs_in_indices) +
       sizeof (T.pp_pairs_out_indices) +
       sizeof (T.nn_pairs_in_indices) +
       sizeof (T.nn_pairs_out_indices) +
       sizeof (T.pn_pairs_in_indices) +
       sizeof (T.pn_pairs_out_indices) +
       sizeof (T.pairs_in_indices) +
       sizeof (T.pairs_out_indices))/1000000.0;
  
  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;
}
