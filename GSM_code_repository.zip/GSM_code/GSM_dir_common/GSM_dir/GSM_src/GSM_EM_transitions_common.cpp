#include "../GSM_include/GSM_include_def_common.h"

using namespace string_routines;
using namespace angular_matrix_elements;
using namespace Wigner_signs;
using namespace EM_transitions_radial_OBMEs;

extern enum called_code_type called_code;


// TYPE is double or complex
// -------------------------

// EM means electromagnetic
// ------------------------




// Radial one-body matrix elements are calculated the double version of electric and magnetic radial one-body matrix elements for standard shell model
// and with the complex version of electric and magnetic radial one-body matrix elements for GSM








// Calculation of the electromagnetic transition matrix elements for a given suboperator for all one-body basis states
// -------------------------------------------------------------------------------------------------------------------
// Electromagnetic transitions are functions of several operators.
// One consider a single operator here, such as electric charge, current, or magnetic orbital or spin part with [Y(L +/- 1) x l or s]^L .
// One loops over all one-body basis states and one calculates all associated one-body matrix elements of the considered suboperator.
// Radial integrals are calculated first. Angular parts are considered afterwards.
// Radial integrals can be calculated from a direct radial integration of one-body basis states or using a HO expansion of the considered suboperator, 
// in which case radial overlaps of HO states and one-body basis states enter radial integrals along with a projection of one-body basis states on a HO basis.
// The matrix element is directly put to zero if parity is not conserved.

void EM_transitions_common::EM_suboperator_OBMEs_reduced_calc (
							       const enum EM_suboperator_type EM_suboperator , 
							       const TYPE &q , 
							       const int L ,
							       const bool is_it_longwavelength_approximation , 
							       const bool is_it_HO_expansion , 
							       const class interaction_class &inter_data , 
							       const class baryons_data &data , 
							       class array<TYPE> &OBMEs)
{
  const bool is_it_EM_suboperator_with_r_derivative = is_it_EM_suboperator_with_r_derivative_determine (EM_suboperator);
    
  const unsigned int BP_Op = BP_EM_suboperator_determine (EM_suboperator , L);
    
  const unsigned int N_nlj = data.get_N_nlj_baryon ();
  
  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
					       
  const class array<double> &effective_charges = data.get_effective_charges ();
  
  class array<TYPE> radial_OBMEs_Op_r(N_nlj , N_nlj);
    
  const enum radial_operator_type radial_operator_Op_r = radial_operator_determine_for_EM (false , EM_suboperator);
      
  radial_OBMEs_calc (radial_operator_Op_r , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , BP_Op , inter_data , data , radial_OBMEs_Op_r);
      
  class array<TYPE> radial_OBMEs_Op_r_der;
    
  if (is_it_EM_suboperator_with_r_derivative)
    {
      const enum radial_operator_type radial_operator_Op_r_der = radial_operator_determine_for_EM (true , EM_suboperator);
      
      radial_OBMEs_Op_r_der.allocate (N_nlj , N_nlj);
  
      radial_OBMEs_calc (radial_operator_Op_r_der , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , BP_Op , inter_data , data , radial_OBMEs_Op_r_der);
    }
  
  
  OBMEs = 0.0;

  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
      {
	const class nlj_struct &shell_qn_in = shells_qn(s_in);
	
	const class nlj_struct &shell_qn_out = shells_qn(s_out);

	const enum particle_type particle_in = shell_qn_in.get_particle ();

	const enum particle_type particle_out = shell_qn_out.get_particle ();
	
	const int charge_particle_in = particle_charge_determine (particle_in);
	
	const int charge_particle_out = particle_charge_determine (particle_out);
  
	const int l_in = shell_qn_in.get_l ();
	
	const int l_out = shell_qn_out.get_l ();
	
	if ((charge_particle_in == charge_particle_out) && (binary_parity_from_orbital_angular_momentum (l_in + l_out) == BP_Op))
	  {
	    const unsigned int particle_index = charge_baryon_index_determine (particle_in);
	    
	    const double effective_charge = effective_charges (particle_index);
  
	    const double j_in = shell_qn_in.get_j ();
	    
	    const double j_out = shell_qn_out.get_j ();

	    const TYPE radial_OBME_Op_r_der = (is_it_EM_suboperator_with_r_derivative) ? (radial_OBMEs_Op_r_der(s_in , s_out)) : (NADA);

	    const TYPE radial_OBME_Op_r = radial_OBMEs_Op_r(s_in , s_out);

	    const TYPE OBME = EM_suboperator_OBME_reduced_calc (EM_suboperator , L , particle_in , particle_out , effective_charge , radial_OBME_Op_r_der , radial_OBME_Op_r , l_in , j_in , l_out , j_out);

	    if (inf_norm (OBME) > 1E-13) OBMEs(s_in , s_out) = OBME;
	  }
      }
}

















// Calculation of the electric transition reduced matrix elements for all one-body basis states
// --------------------------------------------------------------------------------------------
// Electric transitions are considered here, with electric charge and current parts.
// One loops over all one-body basis states and one calculates all associated one-body matrix elements.
// Radial integrals are calculated first. Angular parts are considered afterwards.
// Radial integrals can be calculated from a direct radial integration of one-body basis states or using a HO expansion of the considered suboperator, 
// in which case radial overlaps of HO states and one-body basis states enter radial integrals along with a projection of one-body basis states on a HO basis.
// The matrix element is directly put to zero if parity is not conserved.

void EM_transitions_common::OBMEs_electric_reduced_calc (
							 const TYPE &q , 
							 const int L ,
							 const bool is_it_longwavelength_approximation , 
							 const bool is_it_HO_expansion , 
							 const class interaction_class &inter_data , 
							 const class baryons_data &data , 
							 class array<TYPE> &electric_OBMEs)
{
  const unsigned int BP_Op = BP_EM_determine (ELECTRIC , L);

  const class array<double> &effective_charges = data.get_effective_charges ();
  
  const unsigned int N_nlj = data.get_N_nlj_baryon ();

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
		
  class array<TYPE> ECH_radial_OBMEs(N_nlj , N_nlj);
  class array<TYPE> EC_radial_OBMEs (N_nlj , N_nlj);

  radial_OBMEs_calc (ELECTRIC_CHARGE_RADIAL  , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , BP_Op , inter_data , data , ECH_radial_OBMEs);
  radial_OBMEs_calc (ELECTRIC_CURRENT_RADIAL , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , BP_Op , inter_data , data , EC_radial_OBMEs);
  
  electric_OBMEs = 0.0;

  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
      {
	const class nlj_struct &shell_qn_in = shells_qn(s_in);
	
	const class nlj_struct &shell_qn_out = shells_qn(s_out);

	const enum particle_type particle_in = shell_qn_in.get_particle ();

	const enum particle_type particle_out = shell_qn_out.get_particle ();
	
	const int charge_particle_in = particle_charge_determine (particle_in);
	
	const int charge_particle_out = particle_charge_determine (particle_out);
	
	const int l_in = shell_qn_in.get_l ();
	
	const int l_out = shell_qn_out.get_l ();
	
	if ((charge_particle_in == charge_particle_out) && (binary_parity_from_orbital_angular_momentum (l_in + l_out) == BP_Op))
	  {
	    const unsigned int particle_index = charge_baryon_index_determine (particle_in);
	    
	    const double effective_charge = effective_charges (particle_index);
	    
	    const double j_in = shell_qn_in.get_j ();
	    
	    const double j_out = shell_qn_out.get_j ();

	    const TYPE ECH_radial_OBME = ECH_radial_OBMEs(s_in , s_out);
	    const TYPE EC_radial_OBME  = EC_radial_OBMEs (s_in , s_out);

	    const TYPE ECH_OBME = EM_suboperator_OBME_reduced_calc (ELECTRIC_CHARGE  , L , particle_in , particle_out , effective_charge , NADA , ECH_radial_OBME , l_in , j_in , l_out , j_out);
	    const TYPE EC_OBME  = EM_suboperator_OBME_reduced_calc (ELECTRIC_CURRENT , L , particle_in , particle_out , effective_charge , NADA ,  EC_radial_OBME , l_in , j_in , l_out , j_out);

	    const TYPE electric_OBME = ECH_OBME + EC_OBME;

	    if (inf_norm (electric_OBME) > 1E-13) electric_OBMEs(s_in , s_out) = electric_OBME;
	  }
      }
}










// Calculation of the magnetic transition reduced matrix elements for all one-body basis states
// --------------------------------------------------------------------------------------------
// Magnetic transitions are considered here, with magnetic orbital and spin parts.
// One loops over all one-body basis states and one calculates all associated one-body matrix elements.
// Radial integrals are calculated first. Angular parts are considered afterwards.
// Radial integrals can be calculated from a direct radial integration of one-body basis states or using a HO expansion of the considered suboperator, 
// in which case radial overlaps of HO states and one-body basis states enter radial integrals along with a projection of one-body basis states on a HO basis.
// The matrix element is directly put to zero if parity is not conserved.

void EM_transitions_common::OBMEs_magnetic_reduced_calc (
							 const TYPE &q , 
							 const int L ,
							 const bool is_it_longwavelength_approximation , 
							 const bool is_it_HO_expansion , 
							 const class interaction_class &inter_data , 
							 const class baryons_data &data , 
							 class array<TYPE> &magnetic_OBMEs)
{
  const unsigned int BP_Op = BP_EM_determine (MAGNETIC , L);
  
  const unsigned int N_nlj = data.get_N_nlj_baryon ();

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  class array<TYPE> MOLP1_radial_OBMEs(N_nlj , N_nlj);
  class array<TYPE> MOLM1_radial_OBMEs(N_nlj , N_nlj);
  class array<TYPE> MSLP1_radial_OBMEs(N_nlj , N_nlj);
  class array<TYPE> MSLM1_radial_OBMEs(N_nlj , N_nlj);
  class array<TYPE> MSSCE_radial_OBMEs(N_nlj , N_nlj);

  radial_OBMEs_calc (GRADIENT_BESSEL_YLP1                    , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , BP_Op , inter_data , data , MOLP1_radial_OBMEs);
  radial_OBMEs_calc (GRADIENT_BESSEL_YLM1                    , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , BP_Op , inter_data , data , MOLM1_radial_OBMEs);
  radial_OBMEs_calc (GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLP1 , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , BP_Op , inter_data , data , MSLP1_radial_OBMEs);
  radial_OBMEs_calc (GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLM1 , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , BP_Op , inter_data , data , MSLM1_radial_OBMEs);
  radial_OBMEs_calc (MAGNETIC_SPIN_S_SCALAR_E_RADIAL         , q , L , is_it_longwavelength_approximation , is_it_HO_expansion , BP_Op , inter_data , data , MSSCE_radial_OBMEs);
  
  magnetic_OBMEs = 0.0;

  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
      {
	const class nlj_struct &shell_qn_in = shells_qn(s_in);
	
	const class nlj_struct &shell_qn_out = shells_qn(s_out);

	const enum particle_type particle_in = shell_qn_in.get_particle ();

	const enum particle_type particle_out = shell_qn_out.get_particle ();
	
	const int charge_particle_in = particle_charge_determine (particle_in);
	
	const int charge_particle_out = particle_charge_determine (particle_out);
	
	const int l_in = shell_qn_in.get_l ();
	
	const int l_out = shell_qn_out.get_l ();
	
	if ((charge_particle_in == charge_particle_out) && (binary_parity_from_orbital_angular_momentum (l_in + l_out) == BP_Op))
	  {
	    const double j_in = shell_qn_in.get_j ();
	    
	    const double j_out = shell_qn_out.get_j ();

	    const TYPE MOLP1_radial_OBME = MOLP1_radial_OBMEs(s_in , s_out);
	    const TYPE MOLM1_radial_OBME = MOLM1_radial_OBMEs(s_in , s_out);
	    const TYPE MSLP1_radial_OBME = MSLP1_radial_OBMEs(s_in , s_out);
	    const TYPE MSLM1_radial_OBME = MSLM1_radial_OBMEs(s_in , s_out);
	    const TYPE MSSCE_radial_OBME = MSSCE_radial_OBMEs(s_in , s_out);

	    const TYPE MOLP1_OBME = EM_suboperator_OBME_reduced_calc (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_L_L                 , L , particle_in , particle_out , NADA , NADA , MOLP1_radial_OBME , l_in , j_in , l_out , j_out);
	    const TYPE MOLM1_OBME = EM_suboperator_OBME_reduced_calc (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_L_L                 , L , particle_in , particle_out , NADA , NADA , MOLM1_radial_OBME , l_in , j_in , l_out , j_out);
	    const TYPE MSLP1_OBME = EM_suboperator_OBME_reduced_calc (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLP1_TENSOR_S_L , L , particle_in , particle_out , NADA , NADA , MSLP1_radial_OBME , l_in , j_in , l_out , j_out);
	    const TYPE MSLM1_OBME = EM_suboperator_OBME_reduced_calc (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLM1_TENSOR_S_L , L , particle_in , particle_out , NADA , NADA , MSLM1_radial_OBME , l_in , j_in , l_out , j_out);
	    const TYPE MSSCE_OBME = EM_suboperator_OBME_reduced_calc (MAGNETIC_SPIN_S_SCALAR_E                                         , L , particle_in , particle_out , NADA , NADA , MSSCE_radial_OBME , l_in , j_in , l_out , j_out);

	    const TYPE magnetic_OBME = MOLP1_OBME + MOLM1_OBME + MSLP1_OBME + MSLM1_OBME + MSSCE_OBME;

	    if (inf_norm (magnetic_OBME) > 1E-13) magnetic_OBMEs(s_in , s_out) = magnetic_OBME;
	  }
      }
}











// Calculation of electric or magnetic transition reduced matrix elements for all one-body basis states
// ----------------------------------------------------------------------------------------------------
// The routine for electric or magnetic transition reduced matrix elements is called.

void EM_transitions_common::OBMEs_reduced_calc (
						const enum EM_type EM ,
						const TYPE &q , 
						const int L ,
						const bool is_it_longwavelength_approximation , 
						const bool is_it_HO_expansion , 
						const class interaction_class &inter_data , 
						const class baryons_data &data , 
						class array<TYPE> &OBMEs)
{
  switch (EM)
    {
    case ELECTRIC: OBMEs_electric_reduced_calc (q , L , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data , data , OBMEs); break;
    case MAGNETIC: OBMEs_magnetic_reduced_calc (q , L , is_it_longwavelength_approximation , is_it_HO_expansion , inter_data , data , OBMEs); break;

    default: abort_all ();
    }
}



