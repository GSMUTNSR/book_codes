#include "../GSM_include/GSM_include_def_common.h"  

extern enum called_code_type called_code;

// TYPE is double or complex
// -------------------------

// MPI transfer is sometimes done here even if is_it_MPI_parallelized is false as disk access cannot be done by many processes at the same time

using namespace string_routines;
using namespace angular_matrix_elements;
using namespace Wigner_signs;


// Calculation with HO basis states of matrix elements of r^2, reduced r and gradient, and multipole operators
// -----------------------------------------------------------------------------------------------------------
// r^2 matrix elements are used for rms radius calculation.
// reduced r and gradient matrix elements are used in center of mass operators in general, when one calculates matrix elements of ri.rj and pi.pj for example.
//
// Formulas for r^2, reduced r, gradient and multipole matrix elements are:
// <b | r^2 | a> = \int ua_HO(r) r^2 ub_HO(r) dr ((a,b) in the same partial wave)
// <b || r || a> = \int ua_HO(r) r ub_HO(r) dr . sqrt (4Pi/3) <b || Y1 || a>
// <b || grad || a> = \int ub_HO(r) [ua_HO'(r) + (la(la+1) - lb(lb+1))/(2r) ua_HO(r)] dr . sqrt (4Pi/3) <b || Y1 || a>
//
// For multipole operators, one has:
// <b | (r^L YL)^2 | a> = \int ua_HO(r) (r^L)^2 ub_HO(r) dr <lb jb | YL^2 | la ja>
// <b || r^L YL || a> = \int ua_HO(r) r^L ub_HO(r) dr <lb jb || YL || la ja>
//
// In r2_tab_calc, reduced_r_grad_tables_calc and multipole_OBMEs_calc, multipole_OBMEs_alloc_calc, they are calculated using the basis of HO states of the interaction class, which is used for the HO expansion of matrix elements.
//
// In reduced_r_grad_tables_calc, one uses HO wave functions as basis one-body states, not the HO expansion, and they are recalculated as well as Gauss-Legendre points. One considers <b || r || a> and <b || grad || a> only.
// This routine is used in the dineutron, diproton, deuteron relative code only.
//
// One uses direct integration.
//
// One does not impose symmetry explicitly to calculate <b || grad || a>, even though derivatives occur and the formula seems not to be numerically symmetric.
// However, on the one hand, symmetry is almost exact as one uses HO states, and, on the other hand, matrix elements in the GSM one-body basis, calculated afterwards, are explicitly symmetrized.
//
// All arrays HO matrix elements are of type TYPE (complex or double) even though they are always real.
// It is the case as they can be assigned to complex arrays afterwards, which can be done with overloaded operators only if arrays are of the same type.
// The induced factor two in memory is always negligible.
// 
// In multipole operators, minus, zero, plus respectively correspond to L' = L-1, L , L+1.
// Reduced multipole arrays are multiplied by sqrt (2) to account for the factor 2 in \sum_i Oi^2 + 2 \sum_{i < j} Oi.Oj .

void OBMEs_TBMEs::HO_wfs::r2_tab_calc (
				       const class interaction_class &inter_data , 
				       class array<TYPE> &r2_HO_tab)
{
  const class array<double> &r_bef_R_tab_GL = inter_data.get_r_bef_R_tab_GL () , w_bef_R_tab_GL = inter_data.get_w_bef_R_tab_GL ();
  const class array<double> &r_aft_R_tab_GL = inter_data.get_r_aft_R_tab_GL () , w_aft_R_tab_GL = inter_data.get_w_aft_R_tab_GL ();
  
  const class array<double> &HO_wfs_bef_R_tab_GL = inter_data.get_HO_wfs_bef_R_tab_GL ();
  const class array<double> &HO_wfs_aft_R_tab_GL = inter_data.get_HO_wfs_aft_R_tab_GL ();

  const unsigned int N_nlj_HO = inter_data.get_N_nlj_HO ();

  const unsigned int N_bef_R_GL = r_bef_R_tab_GL.dimension (0);
  const unsigned int N_aft_R_GL = r_aft_R_tab_GL.dimension (0);
  
  const class array<class nlj_struct> &shells_HO_table = inter_data.get_shells_HO_table ();

  r2_HO_tab = 0.0;

  for (unsigned int a = 0 ; a < N_nlj_HO ; a++)
    for (unsigned int b = 0 ; b < N_nlj_HO ; b++)
      {
	const class nlj_struct &sa = shells_HO_table(a);
	const class nlj_struct &sb = shells_HO_table(b);

	if (same_lj (sa , sb))
	  {
	    const int na = sa.get_n ();
	    const int nb = sb.get_n ();

	    const int l = sa.get_l ();

	    double radial_integral_r2 = 0.0;

	    for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	      {
		const double r = r_bef_R_tab_GL(i);

		const double r2 = r*r;

		const double w = w_bef_R_tab_GL(i);

		const double ua_r = HO_wfs_bef_R_tab_GL(na , l , i);
		const double ub_r = HO_wfs_bef_R_tab_GL(nb , l , i);

		radial_integral_r2 += ua_r*r2*ub_r*w;
	      }

	    for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	      {
		const double r = r_aft_R_tab_GL(i);

		const double r2 = r*r;

		const double w = w_aft_R_tab_GL(i);

		const double ua_r = HO_wfs_aft_R_tab_GL(na , l , i);
		const double ub_r = HO_wfs_aft_R_tab_GL(nb , l , i);

		radial_integral_r2 += ua_r*r2*ub_r*w;
	      }
	    
	    r2_HO_tab(a , b) = radial_integral_r2;
	  }
      }
}

void OBMEs_TBMEs::HO_wfs::reduced_r_grad_tables_calc (
						      const class interaction_class &inter_data , 
						      class array<TYPE> &reduced_grad_HO_tab , 
						      class array<TYPE> &reduced_r_HO_tab)
{
  const class array<double> &r_bef_R_tab_GL = inter_data.get_r_bef_R_tab_GL () , w_bef_R_tab_GL = inter_data.get_w_bef_R_tab_GL ();  
  const class array<double> &r_aft_R_tab_GL = inter_data.get_r_aft_R_tab_GL () , w_aft_R_tab_GL = inter_data.get_w_aft_R_tab_GL ();
 
  const class array<double> &HO_wfs_bef_R_tab_GL = inter_data.get_HO_wfs_bef_R_tab_GL () , &HO_dwfs_bef_R_tab_GL = inter_data.get_HO_dwfs_bef_R_tab_GL ();
  const class array<double> &HO_wfs_aft_R_tab_GL = inter_data.get_HO_wfs_aft_R_tab_GL () , &HO_dwfs_aft_R_tab_GL = inter_data.get_HO_dwfs_aft_R_tab_GL ();
  
  const unsigned int N_nlj_HO = inter_data.get_N_nlj_HO ();

  const unsigned int N_bef_R_GL = r_bef_R_tab_GL.dimension (0);
  const unsigned int N_aft_R_GL = r_aft_R_tab_GL.dimension (0);

  const double sqrt_four_pi_over_three = 2.04665341589297697695;

  const class array<class nlj_struct> &shells_HO_table = inter_data.get_shells_HO_table ();

  reduced_grad_HO_tab = 0.0;

  reduced_r_HO_tab = 0.0;

  for (unsigned int a = 0 ; a < N_nlj_HO ; a++)
    for (unsigned int b = 0 ; b < N_nlj_HO ; b++)
      {
	const class nlj_struct &sa = shells_HO_table(a);
	const class nlj_struct &sb = shells_HO_table(b);

	const int na = sa.get_n ();
	const int nb = sb.get_n ();

	const int la = sa.get_l ();
	const int lb = sb.get_l ();

	const double ja = sa.get_j ();
	const double jb = sb.get_j ();

	const double l_factor = 0.5*(la*(la + 1.0) - lb*(lb + 1.0));

	const double angular_part_r_grad = sqrt_four_pi_over_three*OBME_YL_reduced_in_j (1 , la , ja , lb , jb);
  
	if (angular_part_r_grad != 0.0)
	  {
	    double radial_integral_grad = 0.0;
	    double radial_integral_r    = 0.0;

	    for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	      {
		const double r = r_bef_R_tab_GL(i);
		const double w = w_bef_R_tab_GL(i);

		const double ua_r = HO_wfs_bef_R_tab_GL(na , la , i);
		const double ub_r = HO_wfs_bef_R_tab_GL(nb , lb , i);

		const double ua_der_r = HO_dwfs_bef_R_tab_GL(na , la , i);

		radial_integral_grad += w*ub_r*(ua_der_r + l_factor*ua_r/r);
		
		radial_integral_r += w*ub_r*r*ua_r;
	      }
	    
	    for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	      {
		const double r = r_aft_R_tab_GL(i);
		const double w = w_aft_R_tab_GL(i);

		const double ua_r = HO_wfs_aft_R_tab_GL(na , la , i);
		const double ub_r = HO_wfs_aft_R_tab_GL(nb , lb , i);

		const double ua_der_r = HO_dwfs_aft_R_tab_GL(na , la , i);

		radial_integral_grad += w*ub_r*(ua_der_r + l_factor*ua_r/r);
		
		radial_integral_r += w*ub_r*r*ua_r;
	      }

	    reduced_grad_HO_tab(a , b) = angular_part_r_grad*radial_integral_grad;
	    reduced_r_HO_tab(a , b)    = angular_part_r_grad*radial_integral_r;
	  }
      }
}

void OBMEs_TBMEs::HO_wfs::reduced_r_grad_tables_calc (
						      const class nucleons_data &particles_data , 
						      class array<TYPE> &reduced_grad_HO_tab , 
						      class array<TYPE> &reduced_r_HO_tab)
{
  const class lj_table<double> &b_lab_partial_waves = particles_data.get_b_partial_waves ();

  const double sqrt_four_pi_over_three = 2.04665341589297697695;
  
  const double R = particles_data.get_R ();

  const double R_real_max = particles_data.get_R_real_max ();

  const int lmax = particles_data.get_lmax ();

  const unsigned int N_bef_R_GL = particles_data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = particles_data.get_N_aft_R_GL ();

  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  const class lj_table<int> &nmax_lj_tab = particles_data.get_nmax_lj_tab ();
  
  class array<double> r_bef_R_tab_GL(N_bef_R_GL) , r_aft_R_tab_GL(N_aft_R_GL) , HO_wfs_bef_R_tab_GL(N_nlj , N_bef_R_GL) , HO_dwfs_bef_R_tab_GL(N_nlj , N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL) , w_aft_R_tab_GL(N_aft_R_GL) , HO_wfs_aft_R_tab_GL(N_nlj , N_aft_R_GL) , HO_dwfs_aft_R_tab_GL(N_nlj , N_aft_R_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R          , r_bef_R_tab_GL , w_bef_R_tab_GL);
  Gauss_Legendre::abscissas_weights_tables_calc (R   , R_real_max , r_aft_R_tab_GL , w_aft_R_tab_GL);
  
  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {	
	const int nmax_lj = nmax_lj_tab(l , j);

	if (nmax_lj == -1) continue;

	const int nmax_lj_plus_one = nmax_lj + 1;
  
	class array<double> HO_wfs_bef_R_tab_GL_lj_fixed(nmax_lj_plus_one , N_bef_R_GL) , HO_dwfs_bef_R_tab_GL_lj_fixed(nmax_lj_plus_one , N_bef_R_GL);
	class array<double> HO_wfs_aft_R_tab_GL_lj_fixed(nmax_lj_plus_one , N_aft_R_GL) , HO_dwfs_aft_R_tab_GL_lj_fixed(nmax_lj_plus_one , N_aft_R_GL);
  
	const double b = b_lab_partial_waves(l , j);

	HO_wave_functions::HO_3D::u_du_r_tables_calc (b , l , r_bef_R_tab_GL , HO_wfs_bef_R_tab_GL_lj_fixed , HO_dwfs_bef_R_tab_GL_lj_fixed);
	HO_wave_functions::HO_3D::u_du_r_tables_calc (b , l , r_aft_R_tab_GL , HO_wfs_aft_R_tab_GL_lj_fixed , HO_dwfs_aft_R_tab_GL_lj_fixed);

	for (unsigned int s = 0 ; s < N_nlj ; s++)
	  {
	    const class nlj_struct &shell = shells_qn(s);

	    const int ls = shell.get_l ();
	    
	    const double js = shell.get_j ();

	    if (same_lj (l , j , ls , js))
	      {
		const int ns = shell.get_n ();

		for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
		  {
		    HO_wfs_bef_R_tab_GL(s , i) = HO_wfs_bef_R_tab_GL_lj_fixed(ns , i);
		    HO_dwfs_bef_R_tab_GL(s , i) = HO_dwfs_bef_R_tab_GL_lj_fixed(ns , i);
		  }

		for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
		  {
		    HO_wfs_aft_R_tab_GL(s , i) = HO_wfs_aft_R_tab_GL_lj_fixed(ns , i);
		    HO_dwfs_aft_R_tab_GL(s , i) = HO_dwfs_aft_R_tab_GL_lj_fixed(ns , i);
		  }
	      }
	  }
      }

  reduced_grad_HO_tab = 0.0;
  
  reduced_r_HO_tab = 0.0;
  
  for (unsigned int a = 0 ; a < N_nlj ; a++)
    for (unsigned int b = 0 ; b < N_nlj ; b++)
      {
	const class nlj_struct &sa = shells_qn(a);
	const class nlj_struct &sb = shells_qn(b);

	const int la = sa.get_l ();
	const int lb = sb.get_l ();

	const double ja = sa.get_j ();
	const double jb = sb.get_j ();
	
	const double l_factor = 0.5*(la*(la + 1.0) - lb*(lb + 1.0));

	const double angular_part_r_grad = sqrt_four_pi_over_three*OBME_YL_reduced_in_j (1 , la , ja , lb , jb);
	
	if (angular_part_r_grad != 0.0)
	  {
	    double radial_integral_grad = 0.0;
	    double radial_integral_r    = 0.0;

	    for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	      {
		const double r_bef = r_bef_R_tab_GL(i);
		const double w_bef = w_bef_R_tab_GL(i);

		const double ua_r_bef = HO_wfs_bef_R_tab_GL(a , i);
		const double ub_r_bef = HO_wfs_bef_R_tab_GL(b , i);

		const double ua_der_r_bef = HO_dwfs_bef_R_tab_GL(a , i);

		radial_integral_grad += w_bef*ub_r_bef*(ua_der_r_bef + l_factor*ua_r_bef/r_bef);

		radial_integral_r += w_bef*ua_r_bef*ub_r_bef*r_bef;
	      }

	    for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	      {
		const double r_aft = r_aft_R_tab_GL(i);
		const double w_aft = w_aft_R_tab_GL(i);

		const double ua_r_aft = HO_wfs_aft_R_tab_GL(a , i);
		const double ub_r_aft = HO_wfs_aft_R_tab_GL(b , i);

		const double ua_der_r_aft = HO_dwfs_aft_R_tab_GL(a , i);

		radial_integral_grad += w_aft*ub_r_aft*(ua_der_r_aft + l_factor*ua_r_aft/r_aft);

		radial_integral_r += w_aft*ua_r_aft*ub_r_aft*r_aft;
	      }

	    reduced_grad_HO_tab(a , b) = angular_part_r_grad*radial_integral_grad;
	    reduced_r_HO_tab(a , b)    = angular_part_r_grad*radial_integral_r;
	  }
      }
}





void OBMEs_TBMEs::HO_wfs::multipole_OBMEs_calc (
						const class interaction_class &inter_data ,
						class OBMEs_multipole_square_str &OBMEs_multipole_square ,
						class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced)
{
  const class array<double> &r_bef_R_tab_GL = inter_data.get_r_bef_R_tab_GL () , &w_bef_R_tab_GL = inter_data.get_w_bef_R_tab_GL ();  
  const class array<double> &r_aft_R_tab_GL = inter_data.get_r_aft_R_tab_GL () , &w_aft_R_tab_GL = inter_data.get_w_aft_R_tab_GL ();
   
  const unsigned int N_nlj_HO = inter_data.get_N_nlj_HO ();
  
  const unsigned int N_bef_R_GL = r_bef_R_tab_GL.dimension (0);
  const unsigned int N_aft_R_GL = r_aft_R_tab_GL.dimension (0);
  
  const class array<class nlj_struct> &shells_HO_table = inter_data.get_shells_HO_table ();

  const class array<double> &HO_wfs_bef_R_tab_GL = inter_data.get_HO_wfs_bef_R_tab_GL ();
  const class array<double> &HO_wfs_aft_R_tab_GL = inter_data.get_HO_wfs_aft_R_tab_GL ();
  
  OBMEs_multipole_square.zero ();

  OBMEs_multipole_reduced.zero ();
  
  for (unsigned int a = 0 ; a < N_nlj_HO ; a++)
    for (unsigned int b = 0 ; b < N_nlj_HO ; b++)
      {
	const class nlj_struct &sa = shells_HO_table(a);
	const class nlj_struct &sb = shells_HO_table(b);

	const int na = sa.get_n ();
	const int nb = sb.get_n ();

	const int la = sa.get_l ();
	const int lb = sb.get_l ();

	const double ja = sa.get_j ();
	const double jb = sb.get_j ();

	const bool same_lj_ab = same_lj (sa , sb);
	
	const int Lmin = abs (la - lb);
	
	const int Lmax = la + lb;
			
	for (int L = Lmin ; L <= Lmax ; L++)
	  {
	    double radial_integral_rL = 0.0;
	    double radial_integral_r2L = 0.0;
	    
	    for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	      {
		const double r = r_bef_R_tab_GL(i);

		const double w = w_bef_R_tab_GL(i);

		const double ua_r = HO_wfs_bef_R_tab_GL(na , la , i);
		const double ub_r = HO_wfs_bef_R_tab_GL(nb , lb , i);

		const double ua_ub_w = ua_r*ub_r*w;
		
		const double rL = pow (r , L);
				    
		radial_integral_rL += ua_ub_w*rL;
	    
		if (same_lj_ab) radial_integral_r2L += ua_ub_w*rL*rL;
	      }
	    
	    for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	      {
		const double r = r_aft_R_tab_GL(i);

		const double w = w_aft_R_tab_GL(i);

		const double ua_r = HO_wfs_aft_R_tab_GL(na , la , i);
		const double ub_r = HO_wfs_aft_R_tab_GL(nb , lb , i);

		const double ua_ub_w = ua_r*ub_r*w;
		
		const double rL = pow (r , L);
		    
		radial_integral_rL += ua_ub_w*rL;
	    
		if (same_lj_ab) radial_integral_r2L += ua_ub_w*rL*rL;
	      }
		      
	    radial_integral_rL *= M_SQRT2;
	    
	    if (same_lj_ab)
	      {
		const double OBMEs_multipole_square_coupled_OBME = radial_integral_r2L*OBME_YL_square (L , la);
		
		OBMEs_multipole_square.coupled_OBME_fill (L , a , b , OBMEs_multipole_square_coupled_OBME);
	      }
	    
	    const double OBMEs_multipole_reduced_OBME = radial_integral_rL*OBME_YL_reduced_in_j (L , la , ja , lb , jb);
	    
	    OBMEs_multipole_reduced.reduced_OBME_fill (L , a , b , OBMEs_multipole_reduced_OBME);
	  }
      }
}





										
void OBMEs_TBMEs::HO_wfs::multipole_OBMEs_alloc_calc (
						      const bool is_it_HO_expansion , 
						      class nucleons_data &particles_data)
{
  const class lj_table<double> &b_lab_partial_waves = particles_data.get_b_partial_waves ();
  
  const double R = particles_data.get_R ();

  const double R_real_max = particles_data.get_R_real_max ();

  const int lmax = particles_data.get_lmax ();

  const unsigned int N_bef_R_GL = particles_data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = particles_data.get_N_aft_R_GL ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  const class lj_table<int> &nmax_lj_tab = particles_data.get_nmax_lj_tab ();

  class array<double> r_bef_R_tab_GL(N_bef_R_GL) , r_aft_R_tab_GL(N_aft_R_GL) , HO_wfs_bef_R_tab_GL(N_nlj , N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL) , w_aft_R_tab_GL(N_aft_R_GL) , HO_wfs_aft_R_tab_GL(N_nlj , N_aft_R_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R          , r_bef_R_tab_GL , w_bef_R_tab_GL);
  Gauss_Legendre::abscissas_weights_tables_calc (R   , R_real_max , r_aft_R_tab_GL , w_aft_R_tab_GL);
  					
  class OBMEs_multipole_square_str &OBMEs_multipole_square  = (is_it_HO_expansion) ? (particles_data.get_OBMEs_multipole_square_HO_expansion  ()) : (particles_data.get_OBMEs_multipole_square_R_cut  ());

  class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced  = (is_it_HO_expansion) ? (particles_data.get_OBMEs_multipole_reduced_HO_expansion  ()) : (particles_data.get_OBMEs_multipole_reduced_R_cut  ());

  OBMEs_multipole_square.allocate  (lmax , N_nlj , phi_table);
  
  OBMEs_multipole_reduced.allocate  (lmax , N_nlj);

  OBMEs_multipole_square.zero ();
  
  OBMEs_multipole_reduced.zero ();
    
  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {	
	const int nmax_lj = nmax_lj_tab(l , j);

	if (nmax_lj == -1) continue;
	
	const int nmax_lj_plus_one = nmax_lj + 1;

	class array<double> HO_wfs_bef_R_tab_GL_lj_fixed(nmax_lj_plus_one , N_bef_R_GL);
	class array<double> HO_wfs_aft_R_tab_GL_lj_fixed(nmax_lj_plus_one , N_aft_R_GL);
  
	const double b = b_lab_partial_waves(l , j);

	HO_wave_functions::HO_3D::u_r_tables_calc (b , l , r_bef_R_tab_GL , HO_wfs_bef_R_tab_GL_lj_fixed);
	HO_wave_functions::HO_3D::u_r_tables_calc (b , l , r_aft_R_tab_GL , HO_wfs_aft_R_tab_GL_lj_fixed);

	for (unsigned int s = 0 ; s < N_nlj ; s++)
	  {
	    const class nlj_struct &shell = shells_qn(s);

	    const int ls = shell.get_l ();
	    
	    const double js = shell.get_j ();

	    if (same_lj (l , j , ls , js))
	      {
		const int ns = shell.get_n ();

		for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) HO_wfs_bef_R_tab_GL(s , i) = HO_wfs_bef_R_tab_GL_lj_fixed(ns , i);
		for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) HO_wfs_aft_R_tab_GL(s , i) = HO_wfs_aft_R_tab_GL_lj_fixed(ns , i);
	      }
	  }
      }
  
  for (unsigned int a = 0 ; a < N_nlj ; a++)
    for (unsigned int b = 0 ; b < N_nlj ; b++)
      {
	const class nlj_struct &sa = shells_qn(a);
	const class nlj_struct &sb = shells_qn(b);

	const int la = sa.get_l ();
	const int lb = sb.get_l ();

	const double ja = sa.get_j ();
	const double jb = sb.get_j ();

	const bool same_lj_ab = same_lj (sa , sb);
	
	const int Lmin = abs (la - lb);
	
	const int Lmax = la + lb;
			
	for (int L = Lmin ; L <= Lmax ; L++)
	  {
	    double radial_integral_rL = 0.0;
	    double radial_integral_r2L = 0.0;
	    
	    for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	      {
		const double r = r_bef_R_tab_GL(i);

		const double w = w_bef_R_tab_GL(i);

		const double ua_r = HO_wfs_bef_R_tab_GL(a , i);
		const double ub_r = HO_wfs_bef_R_tab_GL(b , i);

		const double ua_ub_w = ua_r*ub_r*w;
		
		const double rL = pow (r , L);
				    
		radial_integral_rL += ua_ub_w*rL;
	    
		if (same_lj_ab) radial_integral_r2L += ua_ub_w*rL*rL;
	      }
	    
	    for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	      {
		const double r = r_aft_R_tab_GL(i);

		const double w = w_aft_R_tab_GL(i);

		const double ua_r = HO_wfs_aft_R_tab_GL(a , i);
		const double ub_r = HO_wfs_aft_R_tab_GL(b , i);

		const double ua_ub_w = ua_r*ub_r*w;
		
		const double rL = pow (r , L);
		    
		radial_integral_rL += ua_ub_w*rL;
	    
		if (same_lj_ab) radial_integral_r2L += ua_ub_w*rL*rL;
	      }
	    
	    radial_integral_rL *= M_SQRT2;

	    if (same_lj_ab)
	      {				
		const double OBMEs_multipole_square_coupled_OBME = radial_integral_r2L*OBME_YL_square (L , la);
		
		OBMEs_multipole_square.coupled_OBME_fill (L , a , b , OBMEs_multipole_square_coupled_OBME);
					
		//OBMEs_multipole_square.coupled_OBME_fill (L , a , b , HO_wave_functions::HO_3D::OBME_q2_HO_calc (sa.get_n () , la)/(3.2*M_PI)*b_lab_partial_waves(la , ja)*b_lab_partial_waves(la , ja));//xyz
		//if (L == 2) cout << sa << " " << sb << " " << (HO_wave_functions::HO_3D::OBME_q2_HO_calc (sa.get_n () , la)) << " " << (radial_integral_r2L*OBME_YL_square (L , la)*3.2*M_PI) << endl;//xyz
	      }
	    
	    const double OBMEs_multipole_reduced_OBME = radial_integral_rL*OBME_YL_reduced_in_j (L , la , ja , lb , jb);

	    OBMEs_multipole_reduced.reduced_OBME_fill (L , a , b , OBMEs_multipole_reduced_OBME);
	  }
      }
}







// Calculation of one-body matrix elements (OBMEs) for Hamiltonian interaction, nuclear, kinetic, Coulomb operators and for kinetic, Hamiltonian, reduced L tensor and A+ center of mass (CM) operators
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates here all the proton or neutron OBMEs (only non-zero OBMEs are mentioned) for:
//
// Hamiltonian interaction: OBMEs are single-energies with fitted interactions or are those of p^2/2m with realistic interactions (m is the mass of the nucleon)
// nuclear: by definition, the OBMEs are those of the nuclear potential of the Hamiltonian basis, hence here the HO potential
// kinetic: OBMEs are those of p^2/2m (m is the mass of the nucleon)
// Coulomb: by definition, the OBMEs are those of the analytic Coulomb potential of charge Z_charge (typically Z-1 for protons and 0 for neutrons)
//
// All matrix elements besides CM matrix elements
//
// (a,b) belong to the same partial wave in <b || Op || a> of previous operators.
// 
// CM kinetic: OBMEs are those of p^2/2M (M is the mass of the nucleus)
// CM Hamiltonian (Hcm): OBMEs are those of Hcm = P^2/2M + 1/2 M omega^2 R^2 (M is the mass of the nucleus)
// reduced center of mass L tensor: OBMEs are those of the reduced tensor L^(1), with L = R x P (center of mass), equal to <b || l^(1) || a> . (m/M) (M is the mass of the nucleus)
// A+: OBMEs are those of the reduced tensor A+ = sqrt (M omega/(2 hbar)) (R - i.P/(M omega)). 
//     OBMEs are then 1/sqrt (2) . (<b || r || a>/(b/sqrt (m/M)) - <b || grad || a> . (b/sqrt (m/M))) . (m,M are the masses of the nucleon and nucleus)
//
// One must have na = nb, la = lb and ja = jb in <b || Hcm || a>.
// One must have na = nb, la = lb and |ja - jb| <= 1 in <b || l^(1) || a>.
// One must have |2.na + la - (2.nb + lb)| = 1 and |ja - jb| <= 1 in 1/sqrt (2) . (<b || r || a>/(b/sqrt (m/M)) - <b || grad || a> . (b/sqrt (m/M))) .
//
// The single-particle energies of core states is zero by definition. But they can contribute to Hcm and to the Lawson method.

void OBMEs_TBMEs::HO_wfs::OBMEs_alloc_calc (
					    const class interaction_class &inter_data ,
					    const double lambda_Hcm , 
					    class nucleons_data &particles_data)
{
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  const int A = particles_data.get_A ();
  
  const int Z_charge = particles_data.get_Z_charge ();
    
  const enum potential_type H_potential = particles_data.get_H_potential ();

  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const double nucleus_mass          = particles_data.get_nucleus_mass ();
  const double nucleon_mass_for_calc = particles_data.get_effective_mass_for_calc ();
  
  const double mass_ratio = nucleon_mass_for_calc/nucleus_mass;
  
  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();
  
  const class lj_table<double> &b_lab_partial_waves = particles_data.get_b_partial_waves ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class OBMEs_CM_set_str &reduced_grad_set = particles_data.get_reduced_grad_HO_expansion_set ();

  const class OBMEs_CM_set_str &reduced_r_set = particles_data.get_reduced_r_HO_expansion_set ();
  
  const class array<TYPE> &reduced_grad_A_dagger_CM_HO = reduced_grad_set(A_DAGGER_CM_HO_REDUCED_TENSOR);

  const class array<TYPE> &reduced_r_A_dagger_CM_HO = reduced_r_set(A_DAGGER_CM_HO_REDUCED_TENSOR);
  
  const class nlj_table<TYPE> &h_basis = particles_data.get_h_basis ();
  
  class OBMEs_inter_set_str &OBMEs_inter_set = particles_data.get_OBMEs_inter_set ();

  class OBMEs_CM_set_str &OBMEs_CM_set = particles_data.get_OBMEs_CM_set_HO_expansion ();

  OBMEs_inter_set.allocate (N_nlj , phi_table);

  OBMEs_CM_set.allocate (N_nlj , phi_table);
  
  class array<TYPE> &OBMEs_H       = OBMEs_inter_set (TBME_inter);
  class array<TYPE> &OBMEs_nuclear = OBMEs_inter_set (ONE_BODY_NUCLEAR);
  class array<TYPE> &OBMEs_kinetic = OBMEs_inter_set (ONE_BODY_KINETIC);
  class array<TYPE> &OBMEs_Coulomb = OBMEs_inter_set (ONE_BODY_COULOMB);
  
  class array<TYPE> &OBMEs_CM_kinetic                    = OBMEs_CM_set(CM_KINETIC);
  class array<TYPE> &OBMEs_Hcm                           = OBMEs_CM_set(HCM);
  class array<TYPE> &OBMEs_L_reduced_tensor              = OBMEs_CM_set(L_REDUCED_TENSOR);
  class array<TYPE> &OBMEs_A_dagger_CM_HO_reduced_tensor = OBMEs_CM_set(A_DAGGER_CM_HO_REDUCED_TENSOR);

  OBMEs_H       = 0.0;
  OBMEs_nuclear = 0.0;
  OBMEs_kinetic = 0.0;
  OBMEs_Coulomb = 0.0;

  OBMEs_Hcm                           = 0.0;
  OBMEs_CM_kinetic                    = 0.0;
  OBMEs_L_reduced_tensor              = 0.0;
  OBMEs_A_dagger_CM_HO_reduced_tensor = 0.0;

  if (TBME_inter == SU3_INTERACTION)
    {
      const class nlj_struct &shell_qn_zero = shells_qn(0);
      
      const int n0 = shell_qn_zero.get_n ();
      const int l0 = shell_qn_zero.get_l ();

      const int N0 = 2*n0 + l0;
     
      for (unsigned int s = 1 ; s < N_nlj ; s++)
	{
	  const class nlj_struct &shell_qn = shells_qn(s);

	  const int n = shell_qn.get_n ();
	  const int l = shell_qn.get_l ();

	  const int N = 2*n + l;

	  if (N != N0) error_message_print_abort ("One can only use one-body states of the same major shell with the SU(3) interaction");
	}
      
      if (N_nlj != make_uns_int (N0) + 1) error_message_print_abort ("One has to have a full major shell with the SU(3) interaction");
    }
  
  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
      {
	const class nlj_struct &shell_qn_in = shells_qn(s_in);
	const class nlj_struct &shell_qn_out = shells_qn(s_out);
	
	const int n_in = shell_qn_in.get_n ();
	const int l_in = shell_qn_in.get_l ();
	
	const int n_out = shell_qn_out.get_n ();
	const int l_out = shell_qn_out.get_l ();
      
	const double j_in = shell_qn_in.get_j ();
	const double j_out = shell_qn_out.get_j ();

	const double b = b_lab_partial_waves(l_in , j_in);
	
	const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , nucleon_mass_for_calc , b);
	
	const double hbar_omega_m_over_M = hbar_omega*nucleon_mass_for_calc/nucleus_mass;
	
	const double hbar_omega_nucleus_mass = HO_wave_functions::hbar_omega_calc (false , 0.0 , nucleus_mass , b);

	const double hbar_omega_particle_CM_correction = (A >= 2) ? (HO_wave_functions::hbar_omega_calc (false , -nucleus_mass , nucleon_mass_for_calc , b)) : (hbar_omega);
	
	const bool core_state_in = shell_qn_in.get_core_state ();

	const int delta_n = n_out - n_in;
	const int delta_l = l_out - l_in;

	const int delta_j = make_int (j_out - j_in);

	const int delta_E_hw = 2.0*delta_n + delta_l;

	const int abs_delta_E_hw = abs (delta_E_hw);

	const int abs_delta_j = abs (delta_j);

	if ((delta_l == 0) && (delta_j == 0))
	  {
	    OBMEs_Hcm(s_in , s_out) = (delta_n == 0) ? ((2*n_in + l_in)*hbar_omega_m_over_M) : (0.0);
	    
	    OBMEs_CM_kinetic(s_in , s_out) = HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l_in , n_in , n_out , hbar_omega_nucleus_mass);

	    OBMEs_kinetic(s_in , s_out) = HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l_in , n_in , n_out , hbar_omega_particle_CM_correction);
		
	    OBMEs_nuclear(s_in , s_out) = H_CM_OBMEs::HO_basis::OBME_nuclear_potential_calc (false , H_potential , l_in , j_in , n_in , n_out , inter_data , particles_data);

	    OBMEs_Coulomb(s_in , s_out) = H_CM_OBMEs::HO_basis::OBME_Coulomb_potential_calc (Z_charge , l_in , j_in , n_in , n_out , inter_data , particles_data);
		
	    if (TBME_inter == REALISTIC_INTERACTION)
	      OBMEs_H(s_in , s_out) = HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l_in , n_in , n_out , hbar_omega_particle_CM_correction) + lambda_Hcm*OBMEs_Hcm(s_in , s_out);
	    else if (TBME_inter == FIT)
	      OBMEs_H(s_in , s_out) = (!core_state_in) ? (h_basis(n_in , l_in , j_in) + lambda_Hcm*OBMEs_Hcm(s_in , s_out)) : (lambda_Hcm*OBMEs_Hcm(s_in , s_out));
	    else if (TBME_inter == SU3_INTERACTION)
	      OBMEs_H(s_in , s_out) = (s_in == s_out) ? (-HO_wave_functions::HO_3D::OBME_q2_HO_calc (n_in , l_in)) : (0.0);
	  }

	if ((delta_n == 0) && (delta_l == 0) && (abs_delta_j <= 1))
	  { 
	    const double l_reduced_ME_mass_ratio = OBME_l_reduced_in_j (l_in , j_in , l_out , j_out)*mass_ratio;

	    OBMEs_L_reduced_tensor(s_in , s_out) = l_reduced_ME_mass_ratio;
	  }

	if ((abs_delta_E_hw == 1) && (abs_delta_j <= 1))
	  { 
	    const TYPE reduced_grad_A_dagger_CM_HO_ME = reduced_grad_A_dagger_CM_HO(s_in , s_out);
	    
	    const TYPE reduced_r_A_dagger_CM_HO_ME = reduced_r_A_dagger_CM_HO(s_in , s_out);

	    const TYPE A_dagger_CM_HO_reduced_ME = M_SQRT1_2*(reduced_r_A_dagger_CM_HO_ME - reduced_grad_A_dagger_CM_HO_ME);

	    OBMEs_A_dagger_CM_HO_reduced_tensor(s_in , s_out) = A_dagger_CM_HO_reduced_ME;
	  }	
      }
}





// Allocation and calculation of all reduced r, gradient and multipole OBMEs, single-particle energies and TBMEs arrays
// --------------------------------------------------------------------------------------------------------------------
// One allocates and calculates all reduced r, gradient and multipole OBMEs, single-particle energies arrays for protons or neutrons, as well as pp and nn TBMEs arrays if one has at least two valence protons or two valence neutrons.
// See called routines.

void OBMEs_TBMEs::HO_wfs::reduced_r_grad_multipole_tables_alloc_calc (
								      const class input_data_str &input_data , 
								      const class interaction_class &inter_data , 
								      class nucleons_data &particles_data)
{
  const unsigned int N_nlj = particles_data.get_N_nlj ();

  class array<TYPE> reduced_grad_table(N_nlj , N_nlj);

  class array<TYPE> reduced_r_table(N_nlj , N_nlj);
  
  reduced_r_grad_tables_calc (particles_data , reduced_grad_table , reduced_r_table);
  
  reduced_r_grad_tables_CM_set_alloc_calc (true  , input_data , inter_data , reduced_grad_table , reduced_r_table , particles_data);
  reduced_r_grad_tables_CM_set_alloc_calc (false , input_data , inter_data , reduced_grad_table , reduced_r_table , particles_data);
    
  multipole_OBMEs_alloc_calc (true  , particles_data);
  multipole_OBMEs_alloc_calc (false , particles_data);
}

void OBMEs_TBMEs::HO_wfs::OBMEs_alloc_calc (
					    const class input_data_str &input_data , 
					    const class interaction_class &inter_data , 
					    class nucleons_data &particles_data)
{
  const double lambda_Hcm = input_data.get_lambda_Hcm ();

  reduced_r_grad_multipole_tables_alloc_calc (input_data , inter_data , particles_data);
  
  OBMEs_alloc_calc (inter_data , lambda_Hcm , particles_data);
}

void OBMEs_TBMEs::HO_wfs::OBMEs_prot_neut_alloc_calc (
						      const class input_data_str &input_data , 
						      const class interaction_class &inter_data ,
						      class nucleons_data &prot_data , 
						      class nucleons_data &neut_data)
{
  const enum space_type basis_space = input_data.get_basis_space ();

  if (basis_space != NEUTRONS_ONLY) OBMEs_alloc_calc (input_data , inter_data , prot_data);
  if (basis_space != PROTONS_ONLY)  OBMEs_alloc_calc (input_data , inter_data , neut_data);
}


// Single-particle energies (SPE) and two-body matrix elements coupled to J and T (JT TBMEs) read and multiplied by a coefficient in the HO code using fitted interactions
// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------
// In standard shell model, one sometimes multiply a set of fitted energies and TBMEs by a constant and matrix elements can be added from different files.
// Single-particle energies and JT coupled TBMEs are here read from an input file and multiplied by a given coefficient.
// hp, hn are the arrays of proton and neutron energies of the basis Hamiltonian. h_basis means either hp or hn.
//
// 
// Arrays are read the master process and distributed to all nodes afterwards. 
// A user-defined MPI structure for JT_coupled_TBME (see GSM_small_classes.cpp) and a temporary one-dimensional array of JT_coupled_TBME type are used to transfer the array of JT_coupled_TBME structures.
// One checks if all TBMEs are well transfered by seeing if the last index plus one for all TBMEs is that of the dimension of the one-dimensional array.

void OBMEs_TBMEs::standard_HO_SM::hp_hn_read_calc (
						   const enum space_type space , 
						   const double SPE_coefficient , 
						   class nucleons_data &particles_data , 
						   ifstream &fitted_interaction_file)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in hp_hn_read_calc.");

  const int nmax = particles_data.get_nmax ();
  const int lmax = particles_data.get_lmax ();
  
  const enum particle_type particle = particles_data.get_particle ();
    
  string nlj_string;

  fitted_interaction_file >> nlj_string;

  const int n = determine_n (nlj_string);  
  const int l = determine_l (nlj_string);
  const double j = determine_j (nlj_string);

  double SPE = 0.0;

  fitted_interaction_file >> SPE;

  if ((n > nmax) || (l > lmax)) return;

  if ((particle == PROTON)  && (space == NEUTRONS_ONLY)) return;
  if ((particle == NEUTRON) && (space == PROTONS_ONLY))  return;

  class nlj_table<TYPE> &h = particles_data.get_h_basis ();
      
  h(n , l , j) += SPE*SPE_coefficient;  
}
  
void OBMEs_TBMEs::standard_HO_SM::JT_TBME_tables_h_basis_calc (
							       const enum space_type space , 
							       const double SPE_coefficient , 
							       const double TBME_coefficient , 
							       const string file_name , 
							       class nucleons_data &prot_data , 
							       class nucleons_data &neut_data , 
							       class array<class JT_coupled_TBME> &JT_TBME_table)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in JT_TBME_tables_h_basis_calc");

  ifstream fitted_interaction_file(file_name.c_str ());
  
  file_existence_check (file_name , fitted_interaction_file);

  unsigned int TBMEs_number = 0;

  fitted_interaction_file >> TBMEs_number;

  word_check (fitted_interaction_file , "TBMEs");

  JT_TBME_table.allocate (TBMEs_number); 

  unsigned int Np_nlj;

  fitted_interaction_file >> Np_nlj;

  word_check (fitted_interaction_file , "proton.shell(s)");

  for (unsigned int state = 0 ; state < Np_nlj ; state++) hp_hn_read_calc (space , SPE_coefficient , prot_data , fitted_interaction_file);

  unsigned int Nn_nlj;

  fitted_interaction_file >> Nn_nlj;

  word_check (fitted_interaction_file , "neutron.shell(s)");

  for (unsigned int state = 0 ; state < Nn_nlj ; state++) hp_hn_read_calc (space , SPE_coefficient , neut_data , fitted_interaction_file);

  int n[4];
  int l[4];

  double j[4];

  for (unsigned int index = 0 ; index < TBMEs_number ; index++)
    {
      class JT_coupled_TBME &JT_TBME = JT_TBME_table[index];

      fitted_interaction_file >> JT_TBME;

      const enum space_type TBME_space = JT_TBME.get_TBME_space ();

      const int J = JT_TBME.get_J ();
      const int T = JT_TBME.get_T ();

      for (unsigned int i = 0 ; i < 4 ; i++)
	{
	  n[i] = JT_TBME.get_n (i);
	  l[i] = JT_TBME.get_l (i);
	  j[i] = JT_TBME.get_j (i);
	}

      const TYPE Vabcd = JT_TBME.get_Vabcd ();

      const TYPE Vabcd_new = Vabcd*TBME_coefficient;

      JT_TBME.initialize (TBME_space , J , T , Vabcd_new , n , l , j);	  
    }
}

#ifdef UseMPI

void OBMEs_TBMEs::standard_HO_SM::hp_hn_JT_TBME_tables_MPI_transfer (
								     const enum space_type space , 
								     class nucleons_data &prot_data , 
								     class nucleons_data &neut_data , 
								     const class array<class array<class JT_coupled_TBME> > &JT_TBME_tables)
{
  if (space != NEUTRONS_ONLY)
    {
      if (THIS_PROCESS != MASTER_PROCESS) h_basis_alloc_fill (prot_data);

      class nlj_table<TYPE> &hp = prot_data.get_h_basis ();

      hp.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
    }

  if (space != PROTONS_ONLY)
    {
      if (THIS_PROCESS != MASTER_PROCESS) h_basis_alloc_fill (neut_data);

      class nlj_table<TYPE> &hn = neut_data.get_h_basis ();

      hn.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
    }

  const unsigned int files_number = JT_TBME_tables.dimension (0);

  unsigned int total_dimension = 0;

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      for (unsigned int i = 0 ; i < files_number ; i++)
	{
	  const class array<class JT_coupled_TBME> &JT_TBME_table = JT_TBME_tables(i);

	  total_dimension += JT_TBME_table.dimension (0);
	}
    }

  MPI_helper::Bcast<unsigned int> (total_dimension , MASTER_PROCESS , MPI_COMM_WORLD);

  class array<unsigned int> TBMEs_number_tab(files_number);
  
  class array<class JT_coupled_TBME> all_JT_TBMEs_tab(total_dimension);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      unsigned int index = 0;
	  
      for (unsigned int i = 0 ; i < files_number ; i++)
	{
	  const class array<class JT_coupled_TBME> &JT_TBME_table = JT_TBME_tables(i);
  
	  const unsigned int TBMEs_number = JT_TBME_table.dimension (0);
	  
	  TBMEs_number_tab(i) = TBMEs_number;

	  for (unsigned int ii = 0 ; ii < TBMEs_number ; ii++) all_JT_TBMEs_tab(index++) = JT_TBME_table(ii);
	}

      if (index != total_dimension)
	error_message_print_abort ("index=" + make_string<unsigned int> (index) + " != total_dimension=" + make_string<unsigned int> (total_dimension) + " in OBMEs_TBMEs::standard_HO_SM::hp_hn_JT_TBME_tables_MPI_transfer (1)");
    }

  TBMEs_number_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
  	  
  MPI_Datatype MPI_JT_coupled_TBME = MPI_Datatype_JT_coupled_TBME_create ();

  MPI_helper::Type_commit (MPI_JT_coupled_TBME);

  all_JT_TBMEs_tab.MPI_Bcast (MASTER_PROCESS , MPI_JT_coupled_TBME , MPI_COMM_WORLD);

  MPI_helper::Type_free (MPI_JT_coupled_TBME);
  
  if (THIS_PROCESS != MASTER_PROCESS)
    {
      unsigned int index = 0;

      for (unsigned int i = 0 ; i < files_number ; i++)
	{
	  const unsigned int TBMEs_number = TBMEs_number_tab(i);

	  class array<class JT_coupled_TBME> &JT_TBME_table = JT_TBME_tables(i);
	  
	  JT_TBME_table.allocate (TBMEs_number);

	  for (unsigned int ii = 0 ; ii < TBMEs_number ; ii++) JT_TBME_table(ii) = all_JT_TBMEs_tab(index++);
	}

      if (index != total_dimension)
	error_message_print_abort ("index=" + make_string<unsigned int> (index) + " != total_dimension=" + make_string<unsigned int> (total_dimension) + " in OBMEs_TBMEs::standard_HO_SM::hp_hn_JT_TBME_tables_MPI_transfer (2)");
    }
}

#endif







// Initialization of single-particle energies
// ------------------------------------------
// The single-particle energies are initialized to either zero or to the standard value (2n + l + 3/2) hbar omega

void OBMEs_TBMEs::standard_HO_SM::h_basis_alloc_fill (class nucleons_data &particles_data)
{
  const int nmax = particles_data.get_nmax ();
  const int lmax = particles_data.get_lmax ();

  class nlj_table<TYPE> &h_basis = particles_data.get_h_basis ();
  
  h_basis.allocate (0.5 , nmax , lmax);

  h_basis = 0.0;
}

void OBMEs_TBMEs::standard_HO_SM::TBMEs_alloc_calc (
						    const bool is_there_cout , 
						    const class input_data_str &input_data , 
						    const class array<class array<class JT_coupled_TBME> > &JT_TBME_tables , 
						    class nucleons_data &particles_data)
{
  const unsigned int N_valence_nucleons = particles_data.get_N_valence_nucleons ();

  if (N_valence_nucleons >= 2)
    {
      class TBMEs_class &TBMEs = particles_data.get_TBMEs ();

      TBMEs.allocate (is_there_cout , false , input_data , particles_data);

      coupled_TBMEs::standard_HO_SM::TBMEs_pp_nn_calc (input_data , true , JT_TBME_tables , particles_data);
    }
}

void OBMEs_TBMEs::standard_HO_SM::h_JT_TBMEs_alloc_fill (
							 const bool is_there_cout , 
							 const class input_data_str &input_data ,
							 class array<double> &SPE_coefficients ,
							 class array<double> &TBME_coefficients , 
							 class array<string> &file_names , 
							 class nucleons_data &prot_data ,
							 class nucleons_data &neut_data , 
							 class array<class array<class JT_coupled_TBME> > &JT_TBME_tables)
{
  const unsigned int files_number = input_data.get_files_number ();

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  if (inter == SU3_INTERACTION)
    {  
      if (space != NEUTRONS_ONLY) h_basis_alloc_fill (prot_data);
      
      if (space != PROTONS_ONLY) h_basis_alloc_fill (neut_data);
    }
  else if (inter == FIT)
    {
      if (THIS_PROCESS == MASTER_PROCESS)
	{	
	  if (space != NEUTRONS_ONLY) h_basis_alloc_fill (prot_data);

	  if (space != PROTONS_ONLY) h_basis_alloc_fill (neut_data);

	  for (unsigned int i = 0 ; i < files_number ; i++) 
	    {
	      const double SPE_coefficient = SPE_coefficients(i);

	      const double TBME_coefficient = TBME_coefficients(i);

	      const string file_name = file_names(i);

	      class array<class JT_coupled_TBME> &JT_TBME_table = JT_TBME_tables(i);

	      JT_TBME_tables_h_basis_calc (space , SPE_coefficient , TBME_coefficient , file_name , prot_data , neut_data , JT_TBME_table);
	  
	      coupled_TBMEs::standard_HO_SM::JT_TBME_tables_realloc_all_combinations_fill (JT_TBME_table);
	    }
	}

#ifdef UseMPI
  
      hp_hn_JT_TBME_tables_MPI_transfer (space , prot_data , neut_data , JT_TBME_tables);

#endif
    }
  else
    error_message_print_abort ("Fitted interactions stored on files or SU(3) interaction only in OBMEs_TBMEs::standard_HO_SM::h_JT_TBMEs_alloc_fill");
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      if (space != NEUTRONS_ONLY)
	{
	  const unsigned int Np_nlj = prot_data.get_N_nlj ();
	  
	  const class nlj_table<TYPE> &hp_basis = prot_data.get_h_basis ();
      
	  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  
	  cout << endl << "Basis energies " << PROTON << endl;
	  cout <<         "----------------------" << endl << endl;
      
	  for (unsigned int s = 0 ; s < Np_nlj ; s++)
	    {
	      const class nlj_struct &shell_qn = prot_shells_qn(s);
      
	      const int n = shell_qn.get_n ();

	      const int l = shell_qn.get_l ();

	      const double j = shell_qn.get_j ();
      
	      cout << "HO.shell " << shell_qn << " " << PROTON << " E:" << hp_basis(n , l , j) << " MeV" << endl;
	    }
      
	  cout << endl << endl;
	}
      
      if (space != PROTONS_ONLY)
	{
	  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
	  
	  const class nlj_table<TYPE> &hn_basis = neut_data.get_h_basis ();
      
	  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
	  
	  cout << endl << "Basis energies " << NEUTRON << endl;
	  cout <<         "----------------------" << endl << endl;
      
	  for (unsigned int s = 0 ; s < Nn_nlj ; s++)
	    {
	      const class nlj_struct &shell_qn = neut_shells_qn(s);
      
	      const int n = shell_qn.get_n ();

	      const int l = shell_qn.get_l ();

	      const double j = shell_qn.get_j ();
      
	      cout << "HO.shell " << shell_qn << " " << NEUTRON << " E:" << hn_basis(n , l , j) << " MeV" << endl;
	    }
      
	  cout << endl << endl;
	}
    }
}








// Allocation and storage of proton or neutron single-particle energies using the Berggren basis
// ---------------------------------------------------------------------------------------------
// The array containing single-particle energies is allocated. 
// 
// If one considers a HO state of orbital quantum number included in the interaction model space (l <= lmax_for_interaction, see GSM_interaction_class.h), 
// one calculates its average energy using the one-body part of the Hamiltonian.
// Otherwise, it is put to zero.
// 
// If one considers a Berggren basis state, its energy calculated by direct integration is stored in the array.

void OBMEs_TBMEs::Berggren::h_basis_alloc_calc (
						const class interaction_class &inter_data ,
						const bool is_there_cout , 
						const class nucleons_data &neut_data_like ,
						class nucleons_data &particles_data)
{
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const enum particle_type particle = particles_data.get_particle ();

      cout << endl << "Basis energies " << particle << endl;
      cout <<         "----------------------" << endl << endl;
    }  

  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const unsigned int N_nlj_minus_one = N_nlj - 1;
  
  const int lmax_for_interaction = inter_data.get_lmax_for_interaction ();

  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class array<class spherical_state> &shells = particles_data.get_shells ();
  
  const int nmax = particles_data.get_nmax ();
  const int lmax = particles_data.get_lmax ();
 
  class nlj_table<TYPE> &h_basis = particles_data.get_h_basis ();
  
  h_basis.allocate (0.5 , nmax , lmax);
  
  h_basis = 0.0;

  bool is_there_print = false;
	    
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {  
      const class nlj_struct &shell_qn = shells_qn(s);

      const class spherical_state &shell = shells(s);
      
      const bool is_it_HO = shell_qn.get_is_it_HO ();

      const int n = shell_qn.get_n ();

      const int l = shell_qn.get_l ();

      const double j = shell_qn.get_j ();
      
      const enum particle_type particle = shell.get_particle ();
      
      const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ();
      
      bool is_there_print_shell = false;
      
      if (is_it_HO)
	{
	  const double E = (l <= lmax_for_interaction) ? (real_dc (H_CM_OBMEs::OBME_core_Hcm_bound_calc (s , s , inter_data , 0.0 , neut_data_like , particles_data))) : (0.0);
	  
	  h_basis(n , l , j) = E;
	}
      else
	{      
	  const complex<double> E = shell.get_E ();
	  
#ifdef TYPEisDOUBLECOMPLEX
	  h_basis(n , l , j) = E;
#endif
	  
#ifdef TYPEisDOUBLE
	  h_basis(n , l , j) = real (E);
#endif
	}
      
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  if (is_it_HO)
	    {
	      const double E = real_dc (h_basis(n , l , j));

	      if (is_there_cout && (l <= lmax_for_interaction))
		{
		  cout << "HO.shell " << shell << " " << particle << " E:" << E << " MeV" << endl;

		  is_there_print_shell = true;
		}
	    }
	  else
	    {      
	      const complex<double> E = shell.get_E ();
	  
	      if (is_there_cout && !is_it_natural_orbital)
		{
#ifdef TYPEisDOUBLECOMPLEX
		  cout << "Berggren " << shell << " " << particle << " E:" << real (E) << " MeV  Gamma:" << -2000.0*imag (E) << " keV" << endl;
#endif
	  
#ifdef TYPEisDOUBLE
		  cout << "Berggren " << shell << " " << particle << " E:" << real (E) << " MeV" << endl;
#endif
		  is_there_print_shell = true;
		}	      
	    }
      
	  if (s < N_nlj_minus_one)
	    {
	      const class spherical_state &shell_after = shells(s + 1);

	      if (is_there_print_shell && !is_it_natural_orbital && !same_lj (shell , shell_after)) cout << endl;
	    }

	  if (is_there_print_shell) is_there_print = true;	
	}
    }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_print) cout << endl << endl;
}

void OBMEs_TBMEs::Berggren::h_basis_prot_neut_alloc_calc (
							  const enum space_type basis_space ,
							  const class interaction_class &inter_data ,
							  const bool is_there_cout , 
							  class nucleons_data &prot_data , 
							  class nucleons_data &neut_data)
{
  const class nucleons_data &neut_data_like = (basis_space == PROTONS_ONLY) ? (prot_data) : (neut_data);

  if (basis_space != NEUTRONS_ONLY) h_basis_alloc_calc (inter_data , is_there_cout , neut_data_like , prot_data);
  if (basis_space != PROTONS_ONLY)  h_basis_alloc_calc (inter_data , is_there_cout , neut_data_like , neut_data);
}






// Read or calculation of one-body matrix elements (OBMEs) in the Berggren basis for a given Hamiltonian interaction, and copy to file if demanded
// -----------------------------------------------------------------------------------------------------------------------------------------------
// If OBMEs are read from an input file (OBMEs_inter_read is true), the master process reads them and distributes them to all nodes
//
// If OBMEs are not read from an input file (OBMEs_inter_read is false), they are calculated directly using the routines of the H_CM_OBMEs namespace.
// Natural orbitals are not considered here, as their OBMEs have been read from another file in another routine, even though OBMEs_inter_read is false.
// Indeed, they had to be calculated in the previous run, when natural orbitals were calculated, so that their OBMEs had to be stored in a file.
//
// If OBMEs are copied to file, it is done by the master process in a file whose name looks like "OBMEs_proton_FHT.dat", where one writes for example "0p3/2 0p3/2 0.123456".

void OBMEs_TBMEs::Berggren::coupled_OBMEs_inter_calc (
						      const enum interaction_type Op_inter , 
						      const bool OBMEs_inter_read ,
						      const double lambda_Hcm ,
						      const bool copy_J_OBMEs_TBMEs , 
						      const class interaction_class &inter_data , 
						      const class nucleons_data &neut_data_like , 
						      const class nucleons_data &particles_data ,
						      class array<TYPE> &coupled_OBMEs)
{
  const unsigned int N_nlj = coupled_OBMEs.dimension (0);
  
  if (OBMEs_inter_read)	
    read_OBMEs_from_file (Op_inter , particles_data , coupled_OBMEs);
  else
    {
      const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

      for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
	{
	  const class nlj_struct &shell_qn_in = shells_qn(s_in);
	  
	  const bool is_it_natural_orbital_in = shell_qn_in.get_is_it_natural_orbital ();

	  if (!is_it_natural_orbital_in)
	    {
	      for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
		{
		  const class nlj_struct &shell_qn_out = shells_qn(s_out);
		  
		  const bool is_it_natural_orbital_out = shell_qn_out.get_is_it_natural_orbital ();

		  if (!is_it_natural_orbital_out) coupled_OBMEs(s_in , s_out) = H_CM_OBMEs::coupled_OBME_inter_calc (Op_inter , inter_data , lambda_Hcm , s_in , s_out , neut_data_like , particles_data);		  		  
		}
	    }
	}
    }

  if ((THIS_PROCESS == MASTER_PROCESS) && copy_J_OBMEs_TBMEs)	
    {
      const enum particle_type particle = particles_data.get_particle ();
      
      const class array<class spherical_state> &shells = particles_data.get_shells ();

      const string file_name = STORAGE_DIR + "OBMEs_" + make_string<enum particle_type> (particle) + "_" + make_string<enum interaction_type> (Op_inter) + ".dat";

      ofstream out_file(file_name.c_str ());

      out_file.precision(15);
      
      out_file.setf (ios::scientific);

      for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)			
	for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)		
	  {				
	    const class spherical_state &wf_in = shells(s_in);
	    const class spherical_state &wf_out = shells(s_out);
	    
	    out_file << wf_in << " " << wf_out << " " << coupled_OBMEs(s_in , s_out) << endl;
	  }

      out_file.close ();
    }
}










// Allocation and calculation of all reduced r, gradient and multipole OBMEs, single-particle energies and TBMEs arrays
// --------------------------------------------------------------------------------------------------------------------
// One allocates and calculates all reduced r, gradient OBMEs, single-particle energies arrays for protons or neutrons, as well as pp and nn TBMEs arrays if one has at least two valence protons or two valence neutrons.
// See called routines.

void OBMEs_TBMEs::Berggren::reduced_r_grad_multipole_tables_alloc_calc (
									const bool is_it_only_basis , 
									const class input_data_str &input_data , 
									const class interaction_class &inter_data , 
									class nucleons_data &particles_data)
{
  const unsigned int N_nlj = particles_data.get_N_nlj ();

  class array<TYPE> reduced_grad_table(N_nlj , N_nlj);

  class array<TYPE> reduced_r_table(N_nlj , N_nlj);

  reduced_r_grad_HO_expansion_calc (is_it_only_basis , inter_data , particles_data , reduced_grad_table , reduced_r_table);
  
  reduced_r_grad_tables_CM_set_alloc_calc (true , input_data , inter_data , reduced_grad_table , reduced_r_table , particles_data);

  reduced_r_grad_R_cut_set_calc (particles_data , reduced_grad_table , reduced_r_table);

  reduced_r_grad_tables_CM_set_alloc_calc (false , input_data , inter_data , reduced_grad_table , reduced_r_table , particles_data);
  
  multipole_OBMEs_HO_expansion_alloc_calc (is_it_only_basis , inter_data , particles_data);

  multipole_OBMEs_R_cut_alloc_calc (particles_data);
}







void OBMEs_TBMEs::Berggren::OBMEs_inter_alloc_calc (
						    const bool is_it_only_basis , 
						    const class input_data_str &input_data , 
						    const class interaction_class &inter_data , 
						    const class nucleons_data &neut_data_like , 
						    class nucleons_data &particles_data)
{
  const bool copy_J_OBMEs_TBMEs = input_data.get_copy_J_OBMEs_TBMEs ();
  
  const bool OBMEs_inter_read = input_data.get_OBMEs_inter_read ();

  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const double lambda_Hcm = (is_it_only_basis) ? (0.0) : (input_data.get_lambda_Hcm ());

  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();

  class OBMEs_inter_set_str &OBMEs_inter_set = particles_data.get_OBMEs_inter_set ();

  if (!OBMEs_inter_set.is_it_filled ()) OBMEs_inter_set.allocate (N_nlj , phi_table);

  coupled_OBMEs_inter_calc (TBME_inter , OBMEs_inter_read , lambda_Hcm , copy_J_OBMEs_TBMEs , inter_data , neut_data_like , particles_data , OBMEs_inter_set(TBME_inter));

  coupled_OBMEs_inter_calc (ONE_BODY_NUCLEAR , false , 0.0 , copy_J_OBMEs_TBMEs , inter_data , neut_data_like , particles_data , OBMEs_inter_set(ONE_BODY_NUCLEAR));
  coupled_OBMEs_inter_calc (ONE_BODY_KINETIC , false , 0.0 , copy_J_OBMEs_TBMEs , inter_data , neut_data_like , particles_data , OBMEs_inter_set(ONE_BODY_KINETIC));
  coupled_OBMEs_inter_calc (ONE_BODY_COULOMB , false , 0.0 , copy_J_OBMEs_TBMEs , inter_data , neut_data_like , particles_data , OBMEs_inter_set(ONE_BODY_COULOMB));
}

void OBMEs_TBMEs::Berggren::OBMEs_CM_multipole_operators_alloc_calc (
								     const bool is_it_only_basis , 
								     const class input_data_str &input_data , 
								     const class interaction_class &inter_data , 
								     const class nucleons_data &neut_data_like , 
								     class nucleons_data &particles_data)
{
  const unsigned int N_nlj_HO = inter_data.get_N_nlj_HO ();

  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();

  reduced_r_grad_multipole_tables_alloc_calc (is_it_only_basis , input_data , inter_data , particles_data);

  class array<TYPE> r2_HO_tab(N_nlj_HO , N_nlj_HO);
  
  HO_wfs::r2_tab_calc (inter_data , r2_HO_tab);

  class OBMEs_CM_set_str &OBMEs_CM_set_HO_expansion = particles_data.get_OBMEs_CM_set_HO_expansion ();

  if (!OBMEs_CM_set_HO_expansion.is_it_filled ())
    {
      OBMEs_CM_set_HO_expansion.allocate (N_nlj , phi_table);

      OBMEs_CM_set_HO_expansion(CM_KINETIC)                    = 0.0;
      OBMEs_CM_set_HO_expansion(HCM)                           = 0.0;
      OBMEs_CM_set_HO_expansion(RMS_RADIUS_PROTON)             = 0.0;
      OBMEs_CM_set_HO_expansion(RMS_RADIUS_NEUTRON)            = 0.0;
      OBMEs_CM_set_HO_expansion(L_REDUCED_TENSOR)              = 0.0;
      OBMEs_CM_set_HO_expansion(A_DAGGER_CM_HO_REDUCED_TENSOR) = 0.0;
    }
  
  coupled_OBMEs_CM_calc (is_it_only_basis , input_data , CM_KINETIC                    , true , false , inter_data , neut_data_like , r2_HO_tab , particles_data);
  coupled_OBMEs_CM_calc (is_it_only_basis , input_data , HCM                           , true , false , inter_data , neut_data_like , r2_HO_tab , particles_data);
  coupled_OBMEs_CM_calc (is_it_only_basis , input_data , RMS_RADIUS_PROTON             , true , false , inter_data , neut_data_like , r2_HO_tab , particles_data);
  coupled_OBMEs_CM_calc (is_it_only_basis , input_data , RMS_RADIUS_NEUTRON            , true , false , inter_data , neut_data_like , r2_HO_tab , particles_data);
  coupled_OBMEs_CM_calc (is_it_only_basis , input_data , L_REDUCED_TENSOR              , true , false , inter_data , neut_data_like , r2_HO_tab , particles_data);
  coupled_OBMEs_CM_calc (is_it_only_basis , input_data , A_DAGGER_CM_HO_REDUCED_TENSOR , true , false , inter_data , neut_data_like , r2_HO_tab , particles_data);

  class OBMEs_CM_set_str &OBMEs_CM_set_R_cut = particles_data.get_OBMEs_CM_set_R_cut ();

  if (!OBMEs_CM_set_R_cut.is_it_filled ())
    {
      OBMEs_CM_set_R_cut.allocate (N_nlj , phi_table);

      OBMEs_CM_set_R_cut(CM_KINETIC)                    = 0.0;
      OBMEs_CM_set_R_cut(HCM)                           = 0.0;
      OBMEs_CM_set_R_cut(RMS_RADIUS_PROTON)             = 0.0;
      OBMEs_CM_set_R_cut(RMS_RADIUS_NEUTRON)            = 0.0;
      OBMEs_CM_set_R_cut(L_REDUCED_TENSOR)              = 0.0;
      OBMEs_CM_set_R_cut(A_DAGGER_CM_HO_REDUCED_TENSOR) = 0.0;
    }
  
  coupled_OBMEs_CM_calc (is_it_only_basis , input_data , CM_KINETIC                    , false , false , inter_data , neut_data_like , r2_HO_tab , particles_data);
  coupled_OBMEs_CM_calc (is_it_only_basis , input_data , HCM                           , false , false , inter_data , neut_data_like , r2_HO_tab , particles_data);
  coupled_OBMEs_CM_calc (is_it_only_basis , input_data , RMS_RADIUS_PROTON             , false , false , inter_data , neut_data_like , r2_HO_tab , particles_data);
  coupled_OBMEs_CM_calc (is_it_only_basis , input_data , RMS_RADIUS_NEUTRON            , false , false , inter_data , neut_data_like , r2_HO_tab , particles_data); 
  coupled_OBMEs_CM_calc (is_it_only_basis , input_data , L_REDUCED_TENSOR              , false , false , inter_data , neut_data_like , r2_HO_tab , particles_data);
  coupled_OBMEs_CM_calc (is_it_only_basis , input_data , A_DAGGER_CM_HO_REDUCED_TENSOR , false , false , inter_data , neut_data_like , r2_HO_tab , particles_data);
}







void OBMEs_TBMEs::Berggren::TBMEs_alloc_calc (
					      const bool is_there_cout , 
					      const bool is_it_only_basis , 
					      const class input_data_str &input_data , 
					      const class interaction_class &inter_data , 
					      class nucleons_data &particles_data)
{
  const unsigned int N_valence_nucleons = particles_data.get_N_valence_nucleons ();

  if (N_valence_nucleons >= 2)	
    {
      const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
        
      class TBMEs_class &TBMEs = particles_data.get_TBMEs ();

      TBMEs.allocate (is_there_cout , is_it_only_basis , input_data , particles_data);
      
      coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (is_there_cout , TBME_inter , input_data , !is_it_only_basis , inter_data , particles_data);
    }
}















// Read or calculation of one-body matrix elements (OBMEs) in the Berggren basis for a given center of mass (CM) operator, and copy to file if demanded
// -----------------------------------------------------------------------------------------------------------------------------------------------
// The center of mass can be L[CM], L+, L-, Lz, Hcm, P^2/2M, rms radii for protons and neutrons and A+[CM-HO]
// P^2/2M and rms radii for protons and neutrons only can be calculated without HO expansion, as they do not mix partial waves, so that a direct calculation with Berggren basis states is meaningful.
//
// Natural orbitals are not considered here, as their OBMEs have been read from another file in another routine, even though OBMEs_inter_read is false.
// Indeed, they had to be calculated in the previous run, when natural orbitals were calculated, so that their OBMEs had to be stored in a file.
//
// If OBMEs are copied to file, it is done by the master process in a file whose name looks like "OBMEs_proton_Hcm.dat", where one writes for example "0p3/2 0p3/2 0.123456".

void OBMEs_TBMEs::Berggren::coupled_OBMEs_CM_calc (
						   const bool is_it_only_basis ,
						   const class input_data_str &input_data , 
						   const enum operator_type Op , 
						   const bool is_it_HO_expansion , 
						   const bool copy_J_OBMEs_TBMEs , 
						   const class interaction_class &inter_data , 
						   const class nucleons_data &neut_data_like , 
						   const class array<TYPE> &r2_HO_tab , 
						   class nucleons_data &particles_data)
{
  if (!is_it_HO_expansion && (Op != CM_KINETIC) && (Op != RMS_RADIUS_PROTON) && (Op != RMS_RADIUS_NEUTRON)) return;

  const bool is_it_CM_operator = is_it_CM_operator_determine (Op);
  
  if (!is_it_CM_operator) return;

  class OBMEs_CM_set_str &OBMEs_CM_set = (is_it_HO_expansion) ? (particles_data.get_OBMEs_CM_set_HO_expansion ()) : (particles_data.get_OBMEs_CM_set_R_cut ());
  
  class array<TYPE> &coupled_OBMEs = OBMEs_CM_set(Op);

  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    {
      const class nlj_struct &shell_qn_in = shells_qn(s_in);

      const bool is_it_natural_orbital_in = shell_qn_in.get_is_it_natural_orbital ();

      if (!is_it_natural_orbital_in)
	{
	  for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
	    {
	      const class nlj_struct &shell_qn_out = shells_qn(s_out);

	      const bool is_it_natural_orbital_out = shell_qn_out.get_is_it_natural_orbital ();

	      if (!is_it_natural_orbital_out) coupled_OBMEs(s_in , s_out) = H_CM_OBMEs::coupled_OBME_operator_calc (is_it_only_basis , input_data , Op , is_it_HO_expansion , inter_data , s_in , s_out , neut_data_like , r2_HO_tab , particles_data);
	    }
	}
    }

  if ((THIS_PROCESS == MASTER_PROCESS) && copy_J_OBMEs_TBMEs)	
    {
      const enum particle_type particle = particles_data.get_particle ();

      const class array<class spherical_state> &shells = particles_data.get_shells ();

      const string file_name = STORAGE_DIR + "OBMEs_" + make_string<enum particle_type> (particle) + "_" + make_string<enum operator_type> (Op) + ".dat";

      ofstream out_file(file_name.c_str ());

      out_file.precision(15);

      out_file.setf (ios::scientific);

      for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)			
	for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)		
	  {				
	    const class spherical_state &wf_in  = shells(s_in);
	    const class spherical_state &wf_out = shells(s_out);

	    out_file << wf_in << " " << wf_out << " " << coupled_OBMEs(s_in , s_out) << endl;
	  }

      out_file.close ();
    }
}







// Calculation of reduced r, gradient and r^L YL, (r^L YL)^2 matrix elements with Berggren basis states using the R cut method
// ---------------------------------------------------------------------------------------------------------------------------
// Reduced r and gradient matrix elements are used in center of mass operators in general, when one calculates matrix elements of ri.rj and pi.pj for example.
//
// Formulas reduced r and gradient matrix elements are:
// <out || r || in> = \int u_in(r) r u_out(r) dr . sqrt (4Pi/3) <out || Y1 || in>
// <out || grad || in> = \int u_out(r) [u_in'(r) + (l_in(l_in+1) - l_out(l_out+1))/(2r) u_in(r)] dr . sqrt (4Pi/3) <out || Y1 || in>
// <out | (r^L / exp (-(r - R0)^2) YL)^2 | in> = \int wf_in_HO(r) (r^L / exp (-(r - R0)^2))^2 wf_out_HO(r) dr <l_out j_out | YL^2 | l_in j_in>
// <out || r^L / exp (-(r - R0)^2) YL || in> = \int wf_in_HO(r) r^L / exp (-(r - R0)^2) wf_out_HO(r) dr <l_out j_out || YL || l_in j_in>
// where the integral is restricted to [0:R], with R the rotation point (R cut method).
//
// One imposes symmetry explicitly to calculate <out || grad || in>, as derivatives occur and the formula is not symmetric, as one uses unbound states in general which are not equal to zero in R.


void OBMEs_TBMEs::Berggren::reduced_r_grad_R_cut_set_calc (
							   const class nucleons_data &particles_data , 
							   class array<TYPE> &reduced_grad_table , 
							   class array<TYPE> &reduced_r_table)
{
  const double sqrt_four_pi_over_three = 2.04665341589297697695;

  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const unsigned int N_bef_R_GL = particles_data.get_N_bef_R_GL ();

  const class array<class spherical_state> &shells = particles_data.get_shells ();

  reduced_grad_table = 0.0;

  reduced_r_table = 0.0;

  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)	
      {
	const class spherical_state &wf_in = shells(s_in);
	const class spherical_state &wf_out = shells(s_out);

	const int l_in = wf_in.get_l ();
	const int l_out = wf_out.get_l ();

	const double j_in = wf_in.get_j ();
	const double j_out = wf_out.get_j ();

	const double angular_part = sqrt_four_pi_over_three*OBME_YL_reduced_in_j (1 , l_in , j_in , l_out , j_out);

	if (angular_part != 0.0)			
	  {
	    const double l_factor = 0.5*(l_in*(l_in + 1.0) - l_out*(l_out + 1.0));

	    const class array<double> &r_bef_R_tab_GL = wf_in.get_r_bef_R_tab_GL ();
	    const class array<double> &w_bef_R_tab_GL = wf_in.get_w_bef_R_tab_GL ();
	    
	    const class array<complex<double> >  &wf_in_bef_R_tab_GL = wf_in.get_wf_bef_R_tab_GL (); 
	    const class array<complex<double> > &dwf_in_bef_R_tab_GL = wf_in.get_dwf_bef_R_tab_GL (); 

	    const class array<complex<double> > &wf_out_bef_R_tab_GL = wf_out.get_wf_bef_R_tab_GL ();

	    complex<double> radial_integral_r = 0.0;
	    complex<double> radial_integral_grad = 0.0;

	    for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	      {
		const double r = r_bef_R_tab_GL(i);
		const double w = w_bef_R_tab_GL(i);

		const complex<double>  wf_in_r  = wf_in_bef_R_tab_GL(i);
		const complex<double> dwf_in_r = dwf_in_bef_R_tab_GL(i);

		const complex<double> wf_out_r = wf_out_bef_R_tab_GL(i);

		radial_integral_grad += w*wf_out_r*(dwf_in_r + l_factor*wf_in_r/r);

		radial_integral_r += w*wf_out_r*r*wf_in_r;
	      }
	    
#ifdef TYPEisDOUBLECOMPLEX
	    reduced_r_table(s_in , s_out) = radial_integral_r*angular_part;

	    reduced_grad_table(s_in , s_out) = radial_integral_grad*angular_part;
#endif
      
#ifdef TYPEisDOUBLE
	    reduced_r_table(s_in , s_out) = real (radial_integral_r)*angular_part;

	    reduced_grad_table(s_in , s_out) = real (radial_integral_grad)*angular_part;
#endif
	  }
      }

  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < s_in ; s_out++)
      {
	const class spherical_state &wf_in  = shells(s_in);
	const class spherical_state &wf_out = shells(s_out);

	const double j_in  = wf_in.get_j ();
	const double j_out = wf_out.get_j ();

	const int phase = minus_one_pow (j_out - j_in + 1);

	reduced_grad_table(s_in , s_out) = 0.5*(reduced_grad_table(s_in , s_out) + phase*reduced_grad_table(s_out , s_in));
	
	reduced_grad_table(s_out , s_in) = phase*reduced_grad_table(s_in , s_out);
      }
}









void OBMEs_TBMEs::Berggren::multipole_OBMEs_R_cut_alloc_calc (class nucleons_data &particles_data)
{  
  const unsigned int N_bef_R_GL = particles_data.get_N_bef_R_GL ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const int lmax = particles_data.get_lmax ();

  const class array<class spherical_state> &shells = particles_data.get_shells ();
  
  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();
  
  class OBMEs_multipole_square_str &OBMEs_multipole_square  = particles_data.get_OBMEs_multipole_square_R_cut ();
  
  class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced  = particles_data.get_OBMEs_multipole_reduced_R_cut ();
  
  OBMEs_multipole_square.allocate  (lmax , N_nlj , phi_table);
  
  OBMEs_multipole_reduced.allocate  (lmax , N_nlj);

  OBMEs_multipole_square.zero ();

  OBMEs_multipole_reduced.zero ();
 
  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)	
      {
	const class spherical_state &wf_in = shells(s_in);
	const class spherical_state &wf_out = shells(s_out);

	const class array<double> &r_bef_R_tab_GL = wf_in.get_r_bef_R_tab_GL ();
	const class array<double> &w_bef_R_tab_GL = wf_in.get_w_bef_R_tab_GL ();
	    
	const class array<complex<double> > &wf_in_bef_R_tab_GL = wf_in.get_wf_bef_R_tab_GL (); 
	const class array<complex<double> > &wf_out_bef_R_tab_GL = wf_out.get_wf_bef_R_tab_GL ();
	    
	const int l_in = wf_in.get_l ();
	const int l_out = wf_out.get_l ();

	const double j_in = wf_in.get_j ();
	const double j_out = wf_out.get_j ();

	const bool same_lj_in_out = same_lj (wf_in , wf_out);
	
	const int Lmin = abs (l_in - l_out);
	
	const int Lmax = l_in + l_out;
			
	for (int L = Lmin ; L <= Lmax ; L++)
	  {
	    complex<double> radial_integral_rL = 0.0;
	    complex<double> radial_integral_r2L = 0.0;
	    
	    for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	      {
		const double r = r_bef_R_tab_GL(i);
		const double w = w_bef_R_tab_GL(i);

		const complex<double> wf_in_r = wf_in_bef_R_tab_GL(i);
		const complex<double> wf_out_r = wf_out_bef_R_tab_GL(i);

		const complex<double> wf_in_wf_out_w = wf_in_r*wf_out_r*w;
		
		const double rL = pow (r , L);
		    
		radial_integral_rL += wf_in_wf_out_w*rL;
	    
		if (same_lj_in_out) radial_integral_r2L += wf_in_wf_out_w*rL*rL;
	      }

	    radial_integral_rL *= M_SQRT2;
	
	    if (same_lj_in_out)
	      {		    
		const complex<double> OBMEs_multipole_square_coupled_OBME = radial_integral_r2L*OBME_YL_square (L , l_in);
		
#ifdef TYPEisDOUBLECOMPLEX
		OBMEs_multipole_square.coupled_OBME_fill (L , s_in , s_out , OBMEs_multipole_square_coupled_OBME);
#endif
      
#ifdef TYPEisDOUBLE
		OBMEs_multipole_square.coupled_OBME_fill (L , s_in , s_out , real (OBMEs_multipole_square_coupled_OBME));
#endif
	      }
   
	    const complex<double> OBMEs_multipole_reduced_OBME = radial_integral_rL*OBME_YL_reduced_in_j (L , l_in , j_in , l_out , j_out);
	    
#ifdef TYPEisDOUBLECOMPLEX
	    OBMEs_multipole_reduced.reduced_OBME_fill (L , s_in , s_out , OBMEs_multipole_reduced_OBME);
#endif
      
#ifdef TYPEisDOUBLE
	    OBMEs_multipole_reduced.reduced_OBME_fill (L , s_in , s_out , real (OBMEs_multipole_reduced_OBME));
#endif
	  }
      }
}









// Calculation of one-body matrix elements of the partial derivative of a WS potential with respect to d, R0, Vo, Vso or R_charge
// ---------------------------------------------------------------------------------------------------------------------------------
// One calculates the one-body matrix elements <out | dWS/dx | in>, with x = d, R0, Vo, Vso or R_charge.
// See called routines.

void OBMEs_TBMEs::Berggren::calc_WS_derivative (
						const enum FHT_EFT_parameter_type FHT_EFT_parameter , 
						const bool is_there_l_dependence , 
						const int l_WS , 
						const double A_dependent_factor_core_potential ,
						class nucleons_data &particles_data)

{
  const unsigned int N_nlj = particles_data.get_N_nlj ();

  class OBMEs_inter_set_str &OBMEs_inter_set = particles_data.get_OBMEs_inter_set ();

  class array<TYPE> &OBMEs = OBMEs_inter_set (WS_DERIVATIVE);
  
  OBMEs = 0.0;

  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
      OBMEs(s_in , s_out) = H_CM_OBMEs::OBME_WS_derivative_calc (FHT_EFT_parameter , is_there_l_dependence , l_WS , A_dependent_factor_core_potential , s_in , s_out , particles_data);  
}








// Read of one-body matrix elements (OBMEs) from file
// --------------------------------------------------
// The master process reads OBMEs and distributes them to all nodes.
// One also checks if the in and out states belong to the one-body basis.
// Indeed, truncations can be different in the input file and in the current code, so that the in and out states might be out of the one-body model space.
// For this, one first checks if orbital angular quantum numbers and principal quantum numbers of shells are not larger than lmax or nmax of the new space.
// If it is not the case, one checks is the shells are occupied in the list of shells. It could not be done before as the list of shells depends on l and n, which cannot be larger than lmax and nmax.
// OBMEs outside the model space are ignored.

void OBMEs_TBMEs::Berggren::read_OBMEs_from_file (
						  const enum interaction_type Op_inter , 
						  const class nucleons_data &particles_data , 
						  class array<TYPE> &coupled_OBMEs)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      coupled_OBMEs = 0.0;

      const enum particle_type particle = particles_data.get_particle ();

      const int nmax = particles_data.get_nmax ();
      const int lmax = particles_data.get_lmax ();
      
      const class nlj_table<unsigned int> &shells_indices = particles_data.get_shells_indices ();
      
      const string file_name = STORAGE_DIR + "OBMEs_" + make_string<enum particle_type> (particle) + "_" + make_string<enum interaction_type> (Op_inter) + ".dat";

      ifstream OBMEs_file(file_name.c_str ());

      file_existence_check (file_name , OBMEs_file);

      string wf_in;
      string wf_out;

      TYPE OBME_file;

      while (!OBMEs_file.eof ())
	{
	  OBMEs_file >> wf_in;

	  if (OBMEs_file.eof ()) break;
	  
	  OBMEs_file >> wf_out >> OBME_file;

	  const int n_in = determine_n (wf_in);
	  const int l_in = determine_l (wf_in);
	  
	  if (n_in > nmax) continue;
	  if (l_in > lmax) continue;
	  
	  const int n_out = determine_n (wf_out);
	  const int l_out = determine_l (wf_out);

	  if (n_out > nmax) continue;
	  if (l_out > lmax) continue;
	  
	  const double j_in  = determine_j (wf_in);
	  const double j_out = determine_j (wf_out);		

	  const unsigned int s_in  = shells_indices(n_in  , l_in  , j_in);
	  const unsigned int s_out = shells_indices(n_out , l_out , j_out);		

	  if (s_in  == OUT_OF_RANGE) continue;
	  if (s_out == OUT_OF_RANGE) continue;
	  
	  coupled_OBMEs(s_in , s_out) = OBME_file;
	}

      OBMEs_file.close ();
    }
 
#ifdef UseMPI
  
  coupled_OBMEs.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

#endif 
}




// Calculation of reduced r and gradient matrix elements for protons or neutrons multiplied by different constants to take into account all center of mass (CM) operators
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Reduced r and gradient matrix elements have been calculated in other routines, will be used in two-body matrix elements (TBMEs) and are given as input.
// They must be multiplied by different constants in the different center of mass (CM) operators.
// Hence, one multiplies them by these constants here and they are stored afterwards.
// This allows to have a general many-body CM operator afterwards.
//
// Here are formulas, where M is the mass of the nucleus, mp,mn are the masses of proton and neutron, and m = mp,mn:
// P^2/2M: reduced gradient OBMEs multiplied by sqrt (hbar^2 / M)
// pp TBMEs of rms radius: reduced r OBMEs multiplied by rms_radius_two_body_sqrt_factor_pp_nn_calc (RMS_RADIUS_PROTON/NEUTRON , proton  , mp , mn , Z , N) (see observables_basic_functions.cpp)
// nn TBMEs of rms radius: reduced r OBMEs multiplied by rms_radius_two_body_sqrt_factor_pp_nn_calc (RMS_RADIUS_PROTON/NEUTRON , neutron , mp , mn , Z , N) (see observables_basic_functions.cpp)
// pn TBMEs of rms radius: reduced r OBMEs multiplied by rms_radius_two_body_sqrt_factor_pn_calc    (RMS_RADIUS_PROTON/NEUTRON           , mp , mn , Z , N) (see observables_basic_functions.cpp)
// Hcm: reduced gradient OBMEs multiplied by sqrt (hbar^2 / M), reduced r OBMEs multiplied by sqrt (hbar^2 / M)/b^2
// L = R x P: no multiplication for reduced gradient OBMEs, reduced r OBMEs multiplied by -sqrt (2) . (m/M)
// A+ = sqrt (M omega/(2 hbar)) (R - i.P/(M omega)): reduced gradient OBMEs multiplied by b . sqrt (m/M), reduced r OBMEs multiplied by b/sqrt (m/M)
//
// A few values are of type TYPE (complex for GSM, double for HO codes) even though they are always real.
// It is the case as they are multiplied by complex arrays afterwards for TYPE complex, which can be done with overloaded operators only if arrays and constants are of the same type.

void OBMEs_TBMEs::reduced_r_grad_tables_CM_set_alloc_calc (
							   const bool is_it_HO_expansion , 
							   const class input_data_str &input_data , 
							   const class interaction_class &inter_data , 
							   const class array<TYPE> &reduced_grad_table , 		
							   const class array<TYPE> &reduced_r_table ,
							   class nucleons_data &particles_data)
{
  const int Z = input_data.get_Z ();
  const int N = input_data.get_N ();
  
  const double mp = input_data.get_prot_mass_for_calc ();
  const double mn = input_data.get_neut_mass_for_calc ();

  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const enum particle_type particle = particles_data.get_particle ();

  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();

  const double nucleus_mass = particles_data.get_nucleus_mass ();

  const double nucleon_mass_for_calc = particles_data.get_effective_mass_for_calc ();
  
  const double b = inter_data.get_b_lab ();

  const double b_square = b*b;

  const TYPE sqrt_two_over_kinetic_factor_M = sqrt (2.0/two_amu_over_hbar_square/nucleus_mass);
  
  const TYPE sqrt_two_over_kinetic_factor_M_over_b_square = sqrt_two_over_kinetic_factor_M/b_square;
  
  const double mass_ratio = nucleon_mass_for_calc/nucleus_mass;

  const double sqrt_mass_ratio = sqrt (mass_ratio);

  const TYPE b_times_sqrt_mass_ratio = b*sqrt_mass_ratio;

  const TYPE b_over_sqrt_mass_ratio = b/sqrt_mass_ratio;

  const TYPE minus_sqrt2_mass_ratio = -M_SQRT2*mass_ratio;
 
  const TYPE sqrt_factor_rms_radius_prot = rms_radius_two_body_sqrt_factor_pp_nn_calc (RMS_RADIUS_PROTON  , particle , mp , mn , Z , N);
  const TYPE sqrt_factor_rms_radius_neut = rms_radius_two_body_sqrt_factor_pp_nn_calc (RMS_RADIUS_NEUTRON , particle , mp , mn , Z , N);

  const TYPE sqrt_factor_rms_radius_pn_prot = rms_radius_two_body_sqrt_factor_pn_calc (RMS_RADIUS_PROTON  , mp , mn , Z , N);
  const TYPE sqrt_factor_rms_radius_pn_neut = rms_radius_two_body_sqrt_factor_pn_calc (RMS_RADIUS_NEUTRON , mp , mn , Z , N);
  
  class OBMEs_CM_set_str &reduced_grad_set = (is_it_HO_expansion) ? (particles_data.get_reduced_grad_HO_expansion_set ()) : (particles_data.get_reduced_grad_R_cut_set ());
  
  class OBMEs_CM_set_str &reduced_r_set = (is_it_HO_expansion) ? (particles_data.get_reduced_r_HO_expansion_set ()) : (particles_data.get_reduced_r_R_cut_set ());

  class OBMEs_CM_set_str &reduced_r_rms_radius_pn_set = (is_it_HO_expansion) ? (particles_data.get_reduced_r_HO_expansion_rms_radius_pn_set ()) : (particles_data.get_reduced_r_R_cut_rms_radius_pn_set ());

  reduced_grad_set.allocate (N_nlj , phi_table);

  reduced_r_set.allocate (N_nlj , phi_table);

  reduced_r_rms_radius_pn_set.allocate (N_nlj , phi_table);

  reduced_grad_set(CM_KINETIC) = reduced_grad_table*sqrt_two_over_kinetic_factor_M;

  reduced_r_set(RMS_RADIUS_PROTON)  = reduced_r_table*sqrt_factor_rms_radius_prot;
  reduced_r_set(RMS_RADIUS_NEUTRON) = reduced_r_table*sqrt_factor_rms_radius_neut;

  reduced_r_rms_radius_pn_set(RMS_RADIUS_PROTON)  = reduced_r_table*sqrt_factor_rms_radius_pn_prot;
  reduced_r_rms_radius_pn_set(RMS_RADIUS_NEUTRON) = reduced_r_table*sqrt_factor_rms_radius_pn_neut;

  reduced_grad_set(HCM) = reduced_grad_table*sqrt_two_over_kinetic_factor_M;
  
  reduced_r_set(HCM) = reduced_r_table*sqrt_two_over_kinetic_factor_M_over_b_square;

  reduced_grad_set(L_REDUCED_TENSOR) = reduced_grad_table;

  reduced_grad_set(A_DAGGER_CM_HO_REDUCED_TENSOR) = reduced_grad_table*b_times_sqrt_mass_ratio;

  reduced_r_set(L_REDUCED_TENSOR) = reduced_r_table*minus_sqrt2_mass_ratio;

  reduced_r_set(A_DAGGER_CM_HO_REDUCED_TENSOR) = reduced_r_table/b_over_sqrt_mass_ratio;
}









// Calculation of reduced r, gradient and multipole matrix elements with Berggren basis states using the HO expansion method
// --------------------------------------------------------------------------------------------------------------------------
// Reduced r and gradient matrix elements are used in center of mass operators in general, when one calculates matrix elements of ri.rj and pi.pj for example.
//
// Formulas reduced r and gradient matrix elements are, for Berggren in and out states:
// <out || r || in> = \sum_{n_HO_in , n_HO_out} <n_in | n_HO_in> <n_out | n_HO_out> \int u_{n_HO_in}(r) r u_{n_HO_out}(r) dr . sqrt (4Pi/3) <out || Y1 || in>
// <out || grad || in> = \sum_{n_HO_in , n_HO_out} <n_in | n_HO_in> <n_out | n_HO_out> \int u_{n_HO_out}(r) [u_{n_HO_in}'(r) + (l_in(l_in+1) - l_out(l_out+1))/(2r) u_{n_HO_in}(r)] dr . sqrt (4Pi/3) <out || Y1 || in>
// where the integral involves an expansion of the CM operator with HO states.
//
// For multipole operators, one has:
// <b || grad || a> = \int ub_HO(r) [ua_HO'(r) + (la(la+1) - lb(lb+1))/(2r) ua_HO(r)] dr . sqrt (4Pi/3) <b || Y1 || a>
// <b | (r^L / exp (-(r - R0)^2) YL)^2 | a> = \int ua_HO(r) (r^L / exp (-(r - R0)^2))^2 ub_HO(r) dr <lb jb | YL^2 | la ja>
// <b || r^L / exp (-(r - R0)^2) YL || a> = \int ua_HO(r) r^L / exp (-(r - R0)^2) ub_HO(r) dr <lb jb || YL || la ja>
//
// The HO expansion in the interaction class is used up to lmax_for_interaction, which can be smaller than the maximal orbital angular momentum used in the one-body basis.
// They can be different if one considers N hbar omega spaces to generate |NCM-HO LCM intrinsic> states for GSM-CC, 
// for which large orbital angular momenta are needed but no interaction matrix elements for these orbital angular momenta are used.
// All HO overlaps involving states with l > lmax_for_interaction with the HO expansion are then ignored.
//
// One does not use any HO expansion if the in and out states are HO, as here one calculates radial integrals directly.
// Radial integrals used in the HO expansion are calculated in another routine, which is called here.
//
// One does not impose symmetry explicitly to calculate <out || grad || in>, even though derivatives occur and the formula seems not to be numerically symmetric.
// However, on the one hand, symmetry is almost exact as one uses HO states, and, on the other hand, matrix elements in the GSM one-body basis, calculated afterwards, are explicitly symmetrized.

void OBMEs_TBMEs::reduced_r_grad_HO_expansion_calc (
						    const bool is_it_only_basis , 
						    const class interaction_class &inter_data , 
						    const class nucleons_data &particles_data , 
						    class array<TYPE> &reduced_grad_table , 	
						    class array<TYPE> &reduced_r_table)
{
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const unsigned int N_nlj_HO = inter_data.get_N_nlj_HO ();
  
  const unsigned int N_bef_R_GL = particles_data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = particles_data.get_N_aft_R_GL ();

  const double sqrt_four_pi_over_three = 2.04665341589297697695;
    
  const int lmax_for_interaction = inter_data.get_lmax_for_interaction ();

  const class array<int> &nmax_HO_lab_tab = inter_data.get_nmax_HO_lab_tab ();
  
  const class nlj_table<unsigned int> &shells_HO_indices = inter_data.get_shells_HO_indices ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class array<class spherical_state> &shells = particles_data.get_shells ();
  
  const class array<class vector_class<complex<double> > > &HO_overlaps = (is_it_only_basis) ? (particles_data.get_HO_overlaps_basis ()) : (particles_data.get_HO_overlaps ());

  class array<TYPE> reduced_grad_HO_tab(N_nlj_HO , N_nlj_HO);
  
  class array<TYPE> reduced_r_HO_tab(N_nlj_HO , N_nlj_HO);

  HO_wfs::reduced_r_grad_tables_calc (inter_data , reduced_grad_HO_tab , reduced_r_HO_tab);
  
  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
      {
	const class nlj_struct &shell_qn_in = shells_qn(s_in);
	const class nlj_struct &shell_qn_out = shells_qn(s_out);

	const bool is_it_HO_in = shell_qn_in.get_is_it_HO ();
	const bool is_it_HO_out = shell_qn_out.get_is_it_HO ();

	const int l_in = shell_qn_in.get_l ();
	const int l_out = shell_qn_out.get_l ();
	
	const double j_in = shell_qn_in.get_j ();
	const double j_out = shell_qn_out.get_j ();

	complex<double> reduced_r_OBME = 0.0;

	complex<double> reduced_grad_OBME = 0.0;
  
	if (is_it_HO_in && is_it_HO_out)
	  {
	    const class spherical_state &shell_in = shells(s_in);
	    const class spherical_state &shell_out = shells (s_out);

	    const class array<double> &r_bef_R_tab_GL = shell_in.get_r_bef_R_tab_GL ();
	    const class array<double> &w_bef_R_tab_GL = shell_in.get_w_bef_R_tab_GL ();

	    const class array<double> &r_aft_R_tab_GL = shell_in.get_r_aft_R_tab_GL_real ();
	    const class array<double> &w_aft_R_tab_GL = shell_in.get_w_aft_R_tab_GL_real ();

	    const class array<complex<double> > &wf_in_bef_R_tab_GL = shell_in.get_wf_bef_R_tab_GL ();
	    const class array<complex<double> > &wf_in_aft_R_tab_GL = shell_in.get_wf_aft_R_tab_GL_real ();

	    const class array<complex<double> > &dwf_in_bef_R_tab_GL = shell_in.get_dwf_bef_R_tab_GL ();
	    const class array<complex<double> > &dwf_in_aft_R_tab_GL = shell_in.get_dwf_aft_R_tab_GL_real ();

	    const class array<complex<double> > &wf_out_bef_R_tab_GL = shell_out.get_wf_bef_R_tab_GL ();
	    const class array<complex<double> > &wf_out_aft_R_tab_GL = shell_out.get_wf_aft_R_tab_GL_real ();

	    const double l_factor = 0.5*(l_in*(l_in + 1.0) - l_out*(l_out + 1.0));
	    
	    const double angular_part = sqrt_four_pi_over_three*OBME_YL_reduced_in_j (1 , l_in , j_in , l_out , j_out);

	    if (angular_part != 0.0)
	      {
		double radial_integral_grad = 0.0;
		double radial_integral_r    = 0.0;

		for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
		  {
		    const double r = r_bef_R_tab_GL(i);
		    const double w = w_bef_R_tab_GL(i);

		    const double  wf_in_r = real ( wf_in_bef_R_tab_GL(i));
		    const double dwf_in_r = real (dwf_in_bef_R_tab_GL(i));
		    
		    const double wf_out_r = real (wf_out_bef_R_tab_GL(i));

		    radial_integral_grad += w*wf_out_r*(dwf_in_r + l_factor*wf_in_r/r);
		    
		    radial_integral_r += w*wf_out_r*r*wf_in_r;		    
		  }
		
		for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
		  {
		    const double r = r_aft_R_tab_GL(i);
		    const double w = w_aft_R_tab_GL(i);

		    const double  wf_in_r = real ( wf_in_aft_R_tab_GL(i));
		    const double dwf_in_r = real (dwf_in_aft_R_tab_GL(i));
		    
		    const double wf_out_r = real (wf_out_aft_R_tab_GL(i));

		    radial_integral_grad += w*wf_out_r*(dwf_in_r + l_factor*wf_in_r/r);
		    
		    radial_integral_r += w*wf_out_r*r*wf_in_r;
		  }

		reduced_grad_OBME = angular_part*radial_integral_grad;
		reduced_r_OBME    = angular_part*radial_integral_r;
	      }
	  }
	else
	  {
	    if (l_in  > lmax_for_interaction) continue;
	    if (l_out > lmax_for_interaction) continue;

	    const class vector_class<complex<double> > &HO_overlaps_in  = HO_overlaps(s_in);
	    const class vector_class<complex<double> > &HO_overlaps_out = HO_overlaps(s_out);
	    
	    const int nmax_HO_l_in  = nmax_HO_lab_tab(l_in);
	    const int nmax_HO_l_out = nmax_HO_lab_tab(l_out);

	    for (int na = 0 ; na <= nmax_HO_l_in ; na++)
	      for (int nb = 0 ; nb <= nmax_HO_l_out ; nb++)
		{
		  const unsigned int sa = shells_HO_indices(na , l_in , j_in);
		  const unsigned int sb = shells_HO_indices(nb , l_out , j_out);

		  const complex<double> HO_overlaps_product = HO_overlaps_in(na)*HO_overlaps_out(nb);

		  const complex<double> reduced_grad_HO_ME = reduced_grad_HO_tab(sa , sb);

		  const complex<double> reduced_r_HO_ME = reduced_r_HO_tab(sa , sb);
	    
		  reduced_grad_OBME += HO_overlaps_product*reduced_grad_HO_ME;
		  reduced_r_OBME    += HO_overlaps_product*reduced_r_HO_ME;
		}
	  }
	
#ifdef TYPEisDOUBLECOMPLEX
	reduced_grad_table(s_in , s_out) = reduced_grad_OBME;	
	reduced_r_table(s_in , s_out)    = reduced_r_OBME;
#endif
	
#ifdef TYPEisDOUBLE
	reduced_grad_table(s_in , s_out) = real (reduced_grad_OBME);	
	reduced_r_table(s_in , s_out)    = real (reduced_r_OBME);
#endif	
      }
}









void OBMEs_TBMEs::multipole_OBMEs_HO_expansion_alloc_calc (
							   const bool is_it_only_basis , 
							   const class interaction_class &inter_data , 
							   class nucleons_data &particles_data)
{
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const unsigned int N_nlj_HO = inter_data.get_N_nlj_HO ();
  
  const unsigned int N_bef_R_GL = particles_data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = particles_data.get_N_aft_R_GL ();

  const int lmax_for_interaction = inter_data.get_lmax_for_interaction ();
  
  const int lmax = particles_data.get_lmax ();

  const class array<int> &nmax_HO_lab_tab = inter_data.get_nmax_HO_lab_tab ();
  
  const class nlj_table<unsigned int> &shells_HO_indices = inter_data.get_shells_HO_indices ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();
  
  const class array<class spherical_state> &shells = particles_data.get_shells ();
  
  const class array<class vector_class<complex<double> > > &HO_overlaps = (is_it_only_basis) ? (particles_data.get_HO_overlaps_basis ()) : (particles_data.get_HO_overlaps ());
  
  class OBMEs_multipole_square_str OBMEs_multipole_square_HO(lmax_for_interaction , N_nlj_HO);
 
  class OBMEs_multipole_reduced_str OBMEs_multipole_reduced_HO(lmax_for_interaction , N_nlj_HO);

  HO_wfs::multipole_OBMEs_calc (inter_data , OBMEs_multipole_square_HO , OBMEs_multipole_reduced_HO);
  
  class OBMEs_multipole_square_str &OBMEs_multipole_square = particles_data.get_OBMEs_multipole_square_HO_expansion ();
  
  class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced = particles_data.get_OBMEs_multipole_reduced_HO_expansion ();
  
  OBMEs_multipole_square.allocate (lmax , N_nlj , phi_table);
  
  OBMEs_multipole_reduced.allocate (lmax , N_nlj);
    
  OBMEs_multipole_square.zero ();

  OBMEs_multipole_reduced.zero ();
      
  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
      {
	const class nlj_struct &shell_qn_in = shells_qn(s_in);
	const class nlj_struct &shell_qn_out = shells_qn(s_out);

	const bool is_it_HO_in = shell_qn_in.get_is_it_HO ();
	const bool is_it_HO_out = shell_qn_out.get_is_it_HO ();

	const int l_in = shell_qn_in.get_l ();
	const int l_out = shell_qn_out.get_l ();
	    
	const double j_in = shell_qn_in.get_j ();
	const double j_out = shell_qn_out.get_j ();

	const bool same_lj_in_out = same_lj (shell_qn_in , shell_qn_out);
	
	const int Lmin = abs (l_in - l_out);
	
	const int Lmax = l_in + l_out;
		
	for (int L = Lmin ; L <= Lmax ; L++)
	  {
	    if (is_it_HO_in && is_it_HO_out)
	      {
		const class spherical_state &shell_in = shells(s_in);
		const class spherical_state &shell_out = shells (s_out);
		
		const class array<double> &r_bef_R_tab_GL = shell_in.get_r_bef_R_tab_GL ();
		const class array<double> &w_bef_R_tab_GL = shell_in.get_w_bef_R_tab_GL ();

		const class array<double> &r_aft_R_tab_GL = shell_in.get_r_aft_R_tab_GL_real ();
		const class array<double> &w_aft_R_tab_GL = shell_in.get_w_aft_R_tab_GL_real ();

		const class array<complex<double> > &wf_in_bef_R_tab_GL = shell_in.get_wf_bef_R_tab_GL ();
		const class array<complex<double> > &wf_in_aft_R_tab_GL = shell_in.get_wf_aft_R_tab_GL_real ();

		const class array<complex<double> > &wf_out_bef_R_tab_GL = shell_out.get_wf_bef_R_tab_GL ();
		const class array<complex<double> > &wf_out_aft_R_tab_GL = shell_out.get_wf_aft_R_tab_GL_real ();

		double radial_integral_rL = 0.0;
		double radial_integral_r2L = 0.0;

		for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
		  {		    
		    const double r = r_bef_R_tab_GL(i);
		    const double w = w_bef_R_tab_GL(i);

		    const double wf_in_r = real (wf_in_bef_R_tab_GL(i));		    
		    const double wf_out_r = real (wf_out_bef_R_tab_GL(i));
		    		    
		    const double wf_in_wf_out_w = wf_in_r*wf_out_r*w;
		    
		    const double rL = pow (r , L);
		    
		    radial_integral_rL += wf_in_wf_out_w*rL;
	    
		    if (same_lj_in_out) radial_integral_r2L += wf_in_wf_out_w*rL*rL;
		  }

		for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
		  {		    
		    const double r = r_aft_R_tab_GL(i);
		    const double w = w_aft_R_tab_GL(i);

		    const double wf_in_r = real (wf_in_aft_R_tab_GL(i));		    
		    const double wf_out_r = real (wf_out_aft_R_tab_GL(i));
		    		    
		    const double wf_in_wf_out_w = wf_in_r*wf_out_r*w;
		    
		    const double rL = pow (r , L);
		    
		    radial_integral_rL += wf_in_wf_out_w*rL;
	    
		    if (same_lj_in_out) radial_integral_r2L += wf_in_wf_out_w*rL*rL;
		  }

		radial_integral_rL *= M_SQRT2;
	
		if (same_lj_in_out)
		  {	
		    const double OBMEs_multipole_square_coupled_OBME = radial_integral_r2L*OBME_YL_square (L , l_in);
		
		    OBMEs_multipole_square.coupled_OBME_fill (L , s_in , s_out , OBMEs_multipole_square_coupled_OBME);
		  }
	    
		const double OBMEs_multipole_reduced_OBME = radial_integral_rL*OBME_YL_reduced_in_j (L , l_in , j_in , l_out , j_out);
	    
		OBMEs_multipole_reduced.reduced_OBME_fill (L , s_in , s_out , OBMEs_multipole_reduced_OBME);
	      }
	    else
	      {
		if (l_in  > lmax_for_interaction) continue;
		if (l_out > lmax_for_interaction) continue;
	
		const class vector_class<complex<double> > &HO_overlaps_in  = HO_overlaps(s_in);
		const class vector_class<complex<double> > &HO_overlaps_out = HO_overlaps(s_out);
	    
		const int nmax_HO_l_in  = nmax_HO_lab_tab(l_in);
		const int nmax_HO_l_out = nmax_HO_lab_tab(l_out);

		TYPE OBMEs_multipole_square_coupled_OBME = 0.0;
		
		TYPE OBMEs_multipole_reduced_OBME = 0.0;
		
		for (int na = 0 ; na <= nmax_HO_l_in ; na++)
		  for (int nb = 0 ; nb <= nmax_HO_l_out ; nb++)
		    {
		      const unsigned int sa = shells_HO_indices(na , l_in , j_in);
		      const unsigned int sb = shells_HO_indices(nb , l_out , j_out);

		      const complex<double> HO_overlaps_product = HO_overlaps_in(na)*HO_overlaps_out(nb);

#ifdef TYPEisDOUBLECOMPLEX
		      if (same_lj_in_out) OBMEs_multipole_square_coupled_OBME += HO_overlaps_product*OBMEs_multipole_square_HO.coupled_OBME (L , sa , sb);
		
		      OBMEs_multipole_reduced_OBME += HO_overlaps_product*OBMEs_multipole_reduced_HO.reduced_OBME (L , sa , sb);
#endif
		      
#ifdef TYPEisDOUBLE
		      if (same_lj_in_out) OBMEs_multipole_square_coupled_OBME += real (HO_overlaps_product*OBMEs_multipole_square_HO.coupled_OBME (L , sa , sb));
		      
		      OBMEs_multipole_reduced_OBME += real (HO_overlaps_product*OBMEs_multipole_reduced_HO.reduced_OBME (L , sa , sb));
#endif		      
		    }

		
		if (same_lj_in_out) OBMEs_multipole_square.coupled_OBME_fill (L , s_in , s_out , OBMEs_multipole_square_coupled_OBME);
	    	    
		OBMEs_multipole_reduced.reduced_OBME_fill (L , s_in , s_out , OBMEs_multipole_reduced_OBME);
	      }
	  }
      }
}










// Calculation of all one-body matrix elements (OBMEs) and two-body matrix elements (TBMEs)
// ----------------------------------------------------------------------------------------
// Unless one just calculates shell model space dimensions or the proportion of non-zero N-body matrix elements of the Hamiltonian, OBMEs and TBMEs are calculated.
//
// In the HO code, arrays of shells quantum numbers are first initialized and then one calculates OBMEs.
// Single-particle are allocated and stored in the realistic interaction code. It was already done in the effective interaction code.
// TBMEs are calculated afterwards.
//
// If one uses the Berggren basis, one first allocates and stored one-body basis energies. 
// Then, one reads OBMEs from an input file if one uses the option for it (OBMEs_inter_read true).
//
// Otherwise, if one has natural orbitals, their OBMEs are read from file in all cases, even if OBMEs_inter_read is false.
// Indeed, they had to be calculated in the previous run, when natural orbitals were calculated, so that their OBMEs had to be stored in a file.
// After this, the rest of OBMEs are calculated with the routines above.
//
// The time taken to calculate OBMEs and TBMEs can be written at the end of the routine, as it is not negligible.

void OBMEs_TBMEs::OBMEs_alloc_calc (
				    const bool is_there_cout , 
				    const bool is_it_only_basis , 
				    const class input_data_str &input_data , 
				    const class interaction_class &inter_data , 
				    const class nucleons_data &neut_data_like , 
				    class nucleons_data &particles_data)
{
  const bool only_dimensions = input_data.get_only_dimensions ();
  
  const bool non_zero_NBMEs_proportion_only = input_data.get_non_zero_NBMEs_proportion_only ();

  const bool full_calculation = (is_it_only_basis || (!only_dimensions && !non_zero_NBMEs_proportion_only));

  if (full_calculation)
    {
      const enum potential_type basis_potential = input_data.get_basis_potential ();
      
      const enum interaction_type inter = input_data.get_inter ();
  
      const bool is_it_HO_fit_or_SU3 = ((basis_potential == HO_POTENTIAL) && ((inter == FIT) || (inter == SU3_INTERACTION)));
  
      if (is_it_HO_fit_or_SU3)
	{
	  particles_data.shells_quantum_numbers_k_fill_from_h ();
	    
	  OBMEs_TBMEs::HO_wfs::OBMEs_alloc_calc (input_data , inter_data , particles_data);
	}
      else
	{  
	  OBMEs_TBMEs::Berggren::h_basis_alloc_calc (inter_data , is_there_cout , neut_data_like , particles_data);
	  
	  const enum interaction_read_type inter_read = input_data.get_inter_read ();

	  if (inter_read == LAB_BERGGREN_TBMES_READ)
	    {
	      const enum interaction_type inter = input_data.get_inter ();
      
	      const unsigned int N_nlj = particles_data.get_N_nlj ();
		
	      const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();

	      class OBMEs_inter_set_str &OBMEs_inter_set = particles_data.get_OBMEs_inter_set ();
  
	      OBMEs_inter_set.allocate (N_nlj , phi_table);
		
	      OBMEs_TBMEs::Berggren::read_OBMEs_from_file (inter , particles_data , OBMEs_inter_set(inter));
	    }
	  else
	    {
	      const bool are_there_basis_natural_orbitals = particles_data.get_are_there_basis_natural_orbitals ();
	      
	      if (are_there_basis_natural_orbitals)
		{
		  particles_data.OBMEs_inter_set_alloc_read_disk (inter);
		
		  particles_data.OBMEs_CM_set_alloc_read_disk (true);
		  particles_data.OBMEs_CM_set_alloc_read_disk (false);
		}

	      OBMEs_TBMEs::Berggren::OBMEs_inter_alloc_calc (is_it_only_basis , input_data , inter_data , neut_data_like , particles_data);
	    }
	    
	  OBMEs_TBMEs::Berggren::OBMEs_CM_multipole_operators_alloc_calc (is_it_only_basis , input_data , inter_data , neut_data_like , particles_data);
	}
    }
}

void OBMEs_TBMEs::TBMEs_alloc_calc (
				    const bool is_there_cout , 
				    const bool is_it_only_basis , 
				    const class input_data_str &input_data , 
				    const class interaction_class &inter_data , 
				    const class array<class array<class JT_coupled_TBME> > &JT_TBME_tables , 
				    class nucleons_data &particles_data)
{
  const bool only_dimensions = input_data.get_only_dimensions ();
  
  const bool non_zero_NBMEs_proportion_only = input_data.get_non_zero_NBMEs_proportion_only ();
  
  const bool full_calculation = (is_it_only_basis || (!only_dimensions && !non_zero_NBMEs_proportion_only));
  
  if (full_calculation)
    {
      const enum potential_type basis_potential = input_data.get_basis_potential ();
      
      const enum interaction_type inter = input_data.get_inter ();
  
      const bool is_it_HO_fit_or_SU3 = ((basis_potential == HO_POTENTIAL) && ((inter == FIT) || (inter == SU3_INTERACTION)));

      if (is_it_HO_fit_or_SU3)
	OBMEs_TBMEs::standard_HO_SM::TBMEs_alloc_calc (is_there_cout , input_data , JT_TBME_tables , particles_data);
      else
	OBMEs_TBMEs::Berggren::TBMEs_alloc_calc (is_there_cout , is_it_only_basis , input_data , inter_data , particles_data);
    }
}

void OBMEs_TBMEs::OBMEs_TBMEs_alloc_calc (
					  const bool is_there_cout , 
					  const bool is_it_only_basis , 
					  const class input_data_str &input_data , 
					  const class interaction_class &inter_data_basis , 
					  const class interaction_class &inter_data , 
					  const class array<class array<class JT_coupled_TBME> > &JT_TBME_tables , 
					  const class nucleons_data &neut_data_like , 
					  class nucleons_data &particles_data)
{
  OBMEs_alloc_calc (is_there_cout , is_it_only_basis , input_data , inter_data_basis , neut_data_like , particles_data);

  TBMEs_alloc_calc (is_there_cout , is_it_only_basis , input_data , inter_data , JT_TBME_tables , particles_data);
}

void OBMEs_TBMEs::TBMEs_pn_alloc_calc (
				       const bool is_there_cout , 
				       const bool is_it_only_basis , 
				       const class array<class array<class JT_coupled_TBME> > &JT_TBME_tables , 
				       const class interaction_class &inter_data , 
				       const class input_data_str &input_data , 
				       const class nucleons_data &prot_data , 
				       const class nucleons_data &neut_data , 
				       class TBMEs_class &TBMEs_pn)
{
  const enum interaction_type inter = input_data.get_inter ();
  
  const enum potential_type basis_potential = input_data.get_basis_potential ();
      
  const bool is_it_HO_fit_or_SU3 = ((basis_potential == HO_POTENTIAL) && ((inter == FIT) || (inter == SU3_INTERACTION)));

  TBMEs_pn.allocate (is_there_cout , is_it_only_basis , input_data , prot_data , neut_data);
  
  if (is_it_HO_fit_or_SU3)
    coupled_TBMEs::standard_HO_SM::TBMEs_pn_calc (input_data , prot_data , neut_data , true , JT_TBME_tables , TBMEs_pn);
  else
    coupled_TBMEs::Berggren::TBMEs_pn_calc (is_there_cout , is_it_only_basis , inter , input_data , prot_data , neut_data , true , inter_data , TBMEs_pn);
}

void OBMEs_TBMEs::all_OBMEs_TBMEs_alloc_calc (
					      const bool is_there_cout , 
					      const bool is_it_only_basis ,
					      const class array<class array<class JT_coupled_TBME> > &JT_TBME_tables ,
					      const class interaction_class &inter_data_basis ,   
					      const class interaction_class &inter_data ,  
					      const class input_data_str &input_data , 
					      class nucleons_data &prot_data , 
					      class nucleons_data &neut_data , 
					      class TBMEs_class &TBMEs_pn)
{  
  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);
  
  const enum space_type space = (is_it_only_basis) ? (input_data.get_basis_space ()) : (input_data.get_space ());

  const class nucleons_data &neut_data_like = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);

  const bool only_dimensions = input_data.get_only_dimensions ();
  
  const bool non_zero_NBMEs_proportion_only = input_data.get_non_zero_NBMEs_proportion_only ();
      
  const bool full_calculation = (is_it_only_basis || (!only_dimensions && !non_zero_NBMEs_proportion_only));
        
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      cout << endl << "OBMEs and TBMEs " << endl;
      cout <<         "----------------" << endl << endl;
    }  

  if (space != NEUTRONS_ONLY) OBMEs_TBMEs_alloc_calc (is_there_cout , is_it_only_basis , input_data , inter_data_basis , inter_data , JT_TBME_tables , neut_data_like , prot_data);
  if (space != PROTONS_ONLY)  OBMEs_TBMEs_alloc_calc (is_there_cout , is_it_only_basis , input_data , inter_data_basis , inter_data , JT_TBME_tables , neut_data_like , neut_data);

  if ((space == PROTONS_NEUTRONS) && full_calculation) TBMEs_pn_alloc_calc (is_there_cout , is_it_only_basis , JT_TBME_tables , inter_data , input_data , prot_data , neut_data , TBMEs_pn);

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time;
      
      cout << endl << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;
      cout << "OBMEs and TBMEs calculated. time:" << relative_time << " s" << endl;
      cout << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl << endl;
    } 
}


