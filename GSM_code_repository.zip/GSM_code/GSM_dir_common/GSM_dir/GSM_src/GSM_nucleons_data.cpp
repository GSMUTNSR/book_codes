#include "../GSM_include/GSM_include_def_common.h"

using namespace string_routines;
using namespace inputs_misc;

// TYPE is double or complex
// -------------------------

// See nucleons_data.h for definitions of its members

// Constructors of the class nucleons_data
// ---------------------------------------
// This class is used as a bag class, where all data related to either protons, neutrons or two-body systems such as dineutron, diproton and deuteron, are stored.
// Hence, arrays are not allocated at the beginning and they are allocated in the code.

nucleons_data::nucleons_data () :
  is_it_M_scheme (false) , 
  is_Coulomb_Hamiltonian_here (false) ,
  are_there_basis_natural_orbitals (false) , 
  are_there_new_natural_orbitals (false) ,
  particle (NO_PARTICLE) , 
  nmax (0) , 
  lmax (0) , 
  n_scat_max (0) , 
  n_holes_max (0) , 
  n_holes_max_pole_approximation (0) , 
  E_min_hw (0) , 
  E_max_hw (0) , 
  E_max_hw_pole_approximation (0) , 
  A (0) , 
  A_basis (0) , 
  A_core (0) , 
  Z_core (0) , 
  N_core (0) , 
  Z (0) , 
  N (0) , 
  Z_basis (0) , 
  N_basis (0) , 
  hole_states_number (0) , 
  N_nucleons (0) , 
  N_valence_nucleons (0) , 
  N_valence_nucleons_1h (0) , 
  N_valence_nucleons_2h (0) , 
  N_valence_nucleons_basis (0) , 
  Z_charge (0) , 
  Z_charge_basis_potential (0) , 
  nucleus_mass (0) , 
  nucleus_mass_basis (0) , 
  N_nljm (0) , 
  N_nlj (0) , 
  N_nlj_res (0) , 
  N_nljm_res (0) , 
  natural_orbitals_reference_states_number (0) , 
  jmax (0) , 
  m_min (0) , 
  m_max (0) , 
  M_max (0) , 
  M_max_1h (0) , 
  M_max_2h (0) , 
  effective_mass_for_calc (0) ,   
  m_max_minus_half (0) , 
  two_m_max (0) , 
  four_m_max (0) , 
  m_max_minus_m_min (0) , 
  iM_max (0) , 
  iM_max_1h (0) , 
  iM_max_2h (0) , 
  debut_file_name (""),
  R_charge (0) , 
  effective_charge (0) , 
  basis_potential (NO_POTENTIAL) , 
  H_potential (NO_POTENTIAL) , 
  neutron_basis_potential (false) ,
  is_it_OCM_HO_core (false) ,
  N_bef_R_GL (0) , 
  N_aft_R_GL (0) , 
  N_bef_R_uniform (0) , 
  N_aft_R_uniform (0) , 
  R (0) , 
  step_bef_R_uniform (0) ,
  R_real_max (0) , 
  step_momentum_uniform (0) ,
  kmax_momentum (0) ,
  R_Fermi_momentum (0) ,
  BPmin_global (0) , 
  BPmax_global (0) , 
  Jmin_global (0) , 
  Jmax_global (0) , 
  R_cut_function (0) , 
  d_cut_function (0) , 
  dimension_1p1h_space_BP_iM_fixed_max (0) , 
  dimension_2p2h_space_BP_iM_fixed_max (0) , 
  BP_one_configuration (0) , 
  iC_one_configuration (0) , 
  dimension_configuration_total (0) , 
  dimension_configuration_total_1h (0) , 
  dimension_configuration_total_2h (0) , 
  dimension_configuration_max (0) , 
  dimension_configuration_max_1h (0) , 
  dimension_configuration_max_2h (0) , 
  dimension_SD_total (0) , 
  dimension_SD_total_1h (0) , 
  dimension_SD_total_2h (0) , 
  dimension_SD_max (0) , 
  dimension_SD_max_1h (0) , 
  dimension_SD_max_2h (0)
{
  for (unsigned int i = 0 ; i < 5 ; i++) V0_KKNN[i] = rho_KKNN[i] = 0.0;
  for (unsigned int i = 0 ; i < 3 ; i++) Vls_KKNN[i] = rho_ls_KKNN[i] = 0.0;
}




nucleons_data::nucleons_data (const class nucleons_data &X) :
  is_it_M_scheme (false) , 
  is_Coulomb_Hamiltonian_here (false) ,
  are_there_basis_natural_orbitals (false) , 
  are_there_new_natural_orbitals (false) ,
  particle (NO_PARTICLE) , 
  nmax (0) , 
  lmax (0) , 
  n_scat_max (0) , 
  n_holes_max (0) , 
  n_holes_max_pole_approximation (0) , 
  E_min_hw (0) , 
  E_max_hw (0) , 
  E_max_hw_pole_approximation (0) , 
  A (0) , 
  A_basis (0) , 
  A_core (0) , 
  Z_core (0) , 
  N_core (0) , 
  Z (0) , 
  N (0) , 
  Z_basis (0) , 
  N_basis (0) , 
  hole_states_number (0) , 
  N_nucleons (0) , 
  N_valence_nucleons (0) , 
  N_valence_nucleons_1h (0) , 
  N_valence_nucleons_2h (0) , 
  N_valence_nucleons_basis (0) , 
  Z_charge (0) , 
  Z_charge_basis_potential (0) , 
  nucleus_mass (0) , 
  nucleus_mass_basis (0) , 
  N_nljm (0) , 
  N_nlj (0) , 
  N_nlj_res (0) , 
  N_nljm_res (0) , 
  natural_orbitals_reference_states_number (0) , 
  jmax (0) , 
  m_min (0) , 
  m_max (0) , 
  M_max (0) , 
  M_max_1h (0) , 
  M_max_2h (0) , 
  effective_mass_for_calc (0) ,   
  m_max_minus_half (0) , 
  two_m_max (0) , 
  four_m_max (0) , 
  m_max_minus_m_min (0) , 
  iM_max (0) , 
  iM_max_1h (0) , 
  iM_max_2h (0) , 
  debut_file_name (""),
  R_charge (0) , 
  effective_charge (0) , 
  basis_potential (NO_POTENTIAL) , 
  H_potential (NO_POTENTIAL) , 
  neutron_basis_potential (false) ,
  is_it_OCM_HO_core (false) ,
  N_bef_R_GL (0) , 
  N_aft_R_GL (0) , 
  N_bef_R_uniform (0) , 
  N_aft_R_uniform (0) , 
  R (0) , 
  step_bef_R_uniform (0) ,
  R_real_max (0) , 
  step_momentum_uniform (0) ,
  kmax_momentum (0) ,
  R_Fermi_momentum (0) ,
  BPmin_global (0) , 
  BPmax_global (0) , 
  Jmin_global (0) , 
  Jmax_global (0) , 
  R_cut_function (0) , 
  d_cut_function (0) , 
  dimension_1p1h_space_BP_iM_fixed_max (0) , 
  dimension_2p2h_space_BP_iM_fixed_max (0) , 
  BP_one_configuration (0) , 
  iC_one_configuration (0) , 
  dimension_configuration_total (0) , 
  dimension_configuration_total_1h (0) , 
  dimension_configuration_total_2h (0) , 
  dimension_configuration_max (0) , 
  dimension_configuration_max_1h (0) , 
  dimension_configuration_max_2h (0) , 
  dimension_SD_total (0) , 
  dimension_SD_total_1h (0) , 
  dimension_SD_total_2h (0) , 
  dimension_SD_max (0) , 
  dimension_SD_max_1h (0) , 
  dimension_SD_max_2h (0)
{
  allocate_fill (X);
}


nucleons_data::~nucleons_data () {}

void nucleons_data::allocate_fill (const class nucleons_data &X)
{
  if (is_it_filled ()) error_message_print_abort ("nucleons_data cannot be allocated twice in nucleons_data::allocate_fill");

  is_it_M_scheme = X.is_it_M_scheme;
  
  is_Coulomb_Hamiltonian_here = X.is_Coulomb_Hamiltonian_here;
  
  are_there_basis_natural_orbitals = X.are_there_basis_natural_orbitals;
  
  are_there_new_natural_orbitals = X.are_there_new_natural_orbitals;
  
  particle = X.particle;
  
  nmax = X.nmax;
  lmax = X.lmax;
  
  n_scat_max = X.n_scat_max;

  n_holes_max = X.n_holes_max;
  
  n_holes_max_pole_approximation = X.n_holes_max_pole_approximation;
  
  E_min_hw = X.E_min_hw;
  E_max_hw = X.E_max_hw;
  
  E_max_hw_pole_approximation = X.E_max_hw_pole_approximation;
  
  A = X.A;
  
  A_basis = X.A_basis;
  
  A_core = X.A_core;
  Z_core = X.Z_core;
  N_core = X.N_core;
  
  Z = X.Z;
  N = X.N;
  
  Z_basis = X.Z_basis;
  N_basis = X.N_basis;
  
  hole_states_number = X.hole_states_number;

  N_nucleons = X.N_nucleons;
  
  N_valence_nucleons = X.N_valence_nucleons;
  N_valence_nucleons_1h = X.N_valence_nucleons_1h;
  N_valence_nucleons_2h = X.N_valence_nucleons_2h;
  
  N_valence_nucleons_basis = X.N_valence_nucleons_basis;
  
  Z_charge = X.Z_charge;
  
  Z_charge_basis_potential = X.Z_charge_basis_potential;
  
  nucleus_mass = X.nucleus_mass;
  
  nucleus_mass_basis = X.nucleus_mass_basis;
  
  N_nljm = X.N_nljm;
  N_nlj  = X.N_nlj;
  
  N_nlj_res  = X.N_nlj_res;
  N_nljm_res = X.N_nljm_res;
  
  natural_orbitals_reference_states_number = X.natural_orbitals_reference_states_number;

  jmax = X.jmax;

  m_min = X.m_min;
  m_max = X.m_max;
  
  M_max = X.M_max;
  M_max_1h = X.M_max_1h;
  M_max_2h = X.M_max_2h;
  
  effective_mass_for_calc = X.effective_mass_for_calc;
  
  m_max_minus_half = X.m_max_minus_half;
  
  two_m_max = X.two_m_max;
  
  four_m_max = X.four_m_max;
  
  m_max_minus_m_min = X.m_max_minus_m_min;
  
  iM_max    = X.iM_max;  
  iM_max_1h = X.iM_max_1h;
  iM_max_2h = X.iM_max_2h;
  
  debut_file_name = X.debut_file_name;
  
  R_charge = X.R_charge;
  
  effective_charge = X.effective_charge;
    
  basis_potential = X.basis_potential;
  
  H_potential = X.H_potential;
  
  neutron_basis_potential = X.neutron_basis_potential;
  
  is_it_OCM_HO_core = X.is_it_OCM_HO_core;
  
  N_bef_R_GL = X.N_bef_R_GL;
  N_aft_R_GL = X.N_aft_R_GL;
  
  N_bef_R_uniform = X.N_bef_R_uniform;
  N_aft_R_uniform = X.N_aft_R_uniform;
  
  Nk_momentum_uniform = X.Nk_momentum_uniform;
  Nk_momentum_GL  = X.Nk_momentum_GL;
  
  R = X.R;

  step_bef_R_uniform = X.step_bef_R_uniform;
  
  R_real_max = X.R_real_max;
  
  step_momentum_uniform = X.step_momentum_uniform;

  kmax_momentum = X.kmax_momentum;

  R_Fermi_momentum = X.R_Fermi_momentum;
  
  BPmin_global = X.BPmin_global;
  BPmax_global = X.BPmax_global;
  
  Jmin_global = X.Jmin_global;
  Jmax_global = X.Jmax_global;
  
  R_cut_function = X.R_cut_function;
  d_cut_function = X.d_cut_function ;
  
  dimension_1p1h_space_BP_iM_fixed_max = X.dimension_1p1h_space_BP_iM_fixed_max;
  dimension_2p2h_space_BP_iM_fixed_max = X.dimension_2p2h_space_BP_iM_fixed_max;
  
  BP_one_configuration = X.BP_one_configuration;
  iC_one_configuration = X.iC_one_configuration;
  
  dimension_configuration_total    = X.dimension_configuration_total;
  dimension_configuration_total_1h = X.dimension_configuration_total_1h;
  dimension_configuration_total_2h = X.dimension_configuration_total_2h;
  
  dimension_configuration_max    = X.dimension_configuration_max;
  dimension_configuration_max_1h = X.dimension_configuration_max_1h;
  dimension_configuration_max_1h = X.dimension_configuration_max_2h;
  
  dimension_SD_total    = X.dimension_SD_total;
  dimension_SD_total_1h = X.dimension_SD_total_1h;
  dimension_SD_total_2h = X.dimension_SD_total_2h;
  
  dimension_SD_max    = X.dimension_SD_max;
  dimension_SD_max_1h = X.dimension_SD_max_1h;
  dimension_SD_max_2h = X.dimension_SD_max_2h;
     
  for (unsigned int i = 0 ; i < 5 ; i++) 
    {
      V0_KKNN[i] = X.V0_KKNN[i]; 
      rho_KKNN[i] = X.rho_KKNN[i];
    }

  for (unsigned int i = 0 ; i < 3 ; i++) 
    {
      Vls_KKNN[i] = X.Vls_KKNN[i];
      rho_ls_KKNN[i] = X.rho_ls_KKNN[i];
    }
  
  basis_potential_partial_waves.allocate_fill (X.basis_potential_partial_waves);
  
  TRS_nljm_indices.allocate_fill (X.TRS_nljm_indices);
    
  dimensions_configuration_set.allocate_fill    (X.dimensions_configuration_set);
  dimensions_configuration_set_1h.allocate_fill (X.dimensions_configuration_set_1h);
  dimensions_configuration_set_2h.allocate_fill (X.dimensions_configuration_set_2h);
  
  sum_dimensions_configuration_set.allocate_fill    (X.sum_dimensions_configuration_set);
  sum_dimensions_configuration_set_1h.allocate_fill (X.sum_dimensions_configuration_set_1h);
  sum_dimensions_configuration_set_2h.allocate_fill (X.sum_dimensions_configuration_set_2h);
  
  configuration_set.allocate_fill (X.configuration_set);
  
  configuration_set_1h.allocate_fill (X.configuration_set_1h);
  configuration_set_2h.allocate_fill (X.configuration_set_2h);
  
  dimensions_SD_set.allocate_fill (X.dimensions_SD_set);
  
  dimensions_SD_set_1h.allocate_fill (X.dimensions_SD_set_1h);
  dimensions_SD_set_2h.allocate_fill (X.dimensions_SD_set_2h);
  
  sum_dimensions_SD_set.allocate_fill (X.sum_dimensions_SD_set);
  
  sum_dimensions_SD_set_1h.allocate_fill (X.sum_dimensions_SD_set_1h);
  sum_dimensions_SD_set_2h.allocate_fill (X.sum_dimensions_SD_set_2h);

  SD_set.allocate_fill (X.SD_set);
  
  SD_set_1h.allocate_fill (X.SD_set_1h);
  SD_set_2h.allocate_fill (X.SD_set_2h);  

  E_hw_table.allocate_fill (X.E_hw_table);

  OBMEs_CM_set_HO_expansion.allocate_fill (X.OBMEs_CM_set_HO_expansion);

  OBMEs_CM_set_R_cut.allocate_fill (X.OBMEs_CM_set_R_cut);
  
  reduced_grad_HO_expansion_set.allocate_fill (X.reduced_grad_HO_expansion_set);

  reduced_r_HO_expansion_set.allocate_fill (X.reduced_r_HO_expansion_set);
  
  reduced_r_HO_expansion_rms_radius_pn_set.allocate_fill (X.reduced_r_HO_expansion_rms_radius_pn_set);
  
  reduced_grad_R_cut_set.allocate_fill (X.reduced_grad_R_cut_set);

  reduced_r_R_cut_set.allocate_fill (X.reduced_r_R_cut_set);
  
  reduced_r_R_cut_rms_radius_pn_set.allocate_fill (X.reduced_r_R_cut_rms_radius_pn_set);

  OBMEs_multipole_square_HO_expansion.allocate_fill (X.OBMEs_multipole_square_HO_expansion);
  
  OBMEs_multipole_square_R_cut.allocate_fill (X.OBMEs_multipole_square_R_cut);
  
  OBMEs_multipole_reduced_HO_expansion.allocate_fill (X.OBMEs_multipole_reduced_HO_expansion);
  
  OBMEs_multipole_reduced_R_cut.allocate_fill (X.OBMEs_multipole_reduced_R_cut);
      
  OBMEs_inter_set.allocate_fill (X.OBMEs_inter_set);

  nmax_lj_tab.allocate_fill (X.nmax_lj_tab);

  nmin_lj_valence_tab.allocate_fill (X.nmin_lj_valence_tab);

  shells_indices.allocate_fill (X.shells_indices);

  is_it_valence_shell_tab.allocate_fill (X.is_it_valence_shell_tab);

  one_body_indices.allocate_fill (X.one_body_indices);
  
  shells.allocate_fill_object_elements (X.shells);

  shells_plus.allocate_fill_object_elements (X.shells_plus);  
  shells_minus.allocate_fill_object_elements (X.shells_minus);
  
  phi_table.allocate_fill (X.phi_table);

  Ueq_finite_range_tab_uniform.allocate_fill (X. Ueq_finite_range_tab_uniform);

  Ueq_finite_range_plus_tab_uniform.allocate_fill (X.Ueq_finite_range_plus_tab_uniform);
  Ueq_finite_range_minus_tab_uniform.allocate_fill (X.Ueq_finite_range_minus_tab_uniform);
  
  source_tab_uniform.allocate_fill (X.source_tab_uniform);
  
  source_plus_tab_uniform.allocate_fill (X.source_plus_tab_uniform);  
  source_minus_tab_uniform.allocate_fill (X.source_minus_tab_uniform);
  
  OBMEs_HF_SGI_MSGI.allocate_fill (X.OBMEs_HF_SGI_MSGI);

  h_basis.allocate_fill (X.h_basis);

  TBMEs.allocate_fill (X.TBMEs);

  shells_quantum_numbers.allocate_fill (X.shells_quantum_numbers);

  SD_TRS_indices.allocate_fill (X.SD_TRS_indices);

  SD_TRS_indices_1h.allocate_fill (X.SD_TRS_indices_1h);
  SD_TRS_indices_2h.allocate_fill (X.SD_TRS_indices_2h);
  
  SD_TRS_reordering_bin_phases.allocate_fill (X.SD_TRS_reordering_bin_phases);

  SD_TRS_reordering_bin_phases_1h.allocate_fill (X.SD_TRS_reordering_bin_phases_1h);
  SD_TRS_reordering_bin_phases_2h.allocate_fill (X.SD_TRS_reordering_bin_phases_2h);
  
  SD_TRS_bin_phases.allocate_fill (X.SD_TRS_bin_phases);

  SD_TRS_bin_phases_1h.allocate_fill (X.SD_TRS_bin_phases_1h);
  SD_TRS_bin_phases_2h.allocate_fill (X.SD_TRS_bin_phases_2h);

  dimensions_configuration_one_jump_table_in_to_out.allocate_fill (X.dimensions_configuration_one_jump_table_in_to_out);
  dimensions_configuration_one_jump_table_out_to_in.allocate_fill (X.dimensions_configuration_one_jump_table_out_to_in);
  
  configuration_one_jump_table_in_to_out.allocate_fill (X.configuration_one_jump_table_in_to_out);
  configuration_one_jump_table_out_to_in.allocate_fill (X.configuration_one_jump_table_out_to_in);
  
  dimensions_SD_one_jump_table_in_to_out.allocate_fill (X.dimensions_SD_one_jump_table_in_to_out);
  dimensions_SD_one_jump_table_out_to_in.allocate_fill (X.dimensions_SD_one_jump_table_out_to_in);
  
  dimensions_SD_one_jump_table_Jpm_in_to_out.allocate_fill (X.dimensions_SD_one_jump_table_Jpm_in_to_out);
  dimensions_SD_one_jump_table_Jpm_out_to_in.allocate_fill (X.dimensions_SD_one_jump_table_Jpm_out_to_in);
  
  SD_one_jump_table_in_to_out.allocate_fill (X.SD_one_jump_table_in_to_out);
  SD_one_jump_table_out_to_in.allocate_fill (X.SD_one_jump_table_out_to_in);
  
  SD_one_jump_table_Jpm_in_to_out.allocate_fill (X.SD_one_jump_table_Jpm_in_to_out);
  SD_one_jump_table_Jpm_out_to_in.allocate_fill (X.SD_one_jump_table_Jpm_out_to_in);
      
  for (unsigned int occupied_squares_index = 0 ; occupied_squares_index <= 1 ; occupied_squares_index++)
    {
      are_configurations_inter_occupied_in_space_1ph_tables[occupied_squares_index].allocate_fill (X.are_configurations_inter_occupied_in_space_1ph_tables[occupied_squares_index]);
  
      are_configurations_inter_occupied_in_space_2ph_tables[occupied_squares_index].allocate_fill (X.are_configurations_inter_occupied_in_space_2ph_tables[occupied_squares_index]);
  
      dimensions_configuration_1p_tables[occupied_squares_index].allocate_fill (X.dimensions_configuration_1p_tables[occupied_squares_index]);
      dimensions_configuration_1h_tables[occupied_squares_index].allocate_fill (X.dimensions_configuration_1h_tables[occupied_squares_index]);
  
      dimensions_configuration_2p_tables[occupied_squares_index].allocate_fill (X.dimensions_configuration_2p_tables[occupied_squares_index]);
      dimensions_configuration_2h_tables[occupied_squares_index].allocate_fill (X.dimensions_configuration_2h_tables[occupied_squares_index]);
  
      configuration_1p_tables[occupied_squares_index].allocate_fill (X.configuration_1p_tables[occupied_squares_index]);
      configuration_1h_tables[occupied_squares_index].allocate_fill (X.configuration_1h_tables[occupied_squares_index]);
  
      configuration_2p_tables[occupied_squares_index].allocate_fill (X.configuration_2p_tables[occupied_squares_index]);
      configuration_2h_tables[occupied_squares_index].allocate_fill (X.configuration_2h_tables[occupied_squares_index]);

      dimensions_SD_1p_tables[occupied_squares_index].allocate_fill (X.dimensions_SD_1p_tables[occupied_squares_index]);
      dimensions_SD_1h_tables[occupied_squares_index].allocate_fill (X.dimensions_SD_1h_tables[occupied_squares_index]);
  
      dimensions_SD_2p_tables[occupied_squares_index].allocate_fill (X.dimensions_SD_2p_tables[occupied_squares_index]);
      dimensions_SD_2h_tables[occupied_squares_index].allocate_fill (X.dimensions_SD_2h_tables[occupied_squares_index]);
    
      SD_1p_tables[occupied_squares_index].allocate_fill (X.SD_1p_tables[occupied_squares_index]);
      SD_1h_tables[occupied_squares_index].allocate_fill (X.SD_1h_tables[occupied_squares_index]);
  
      SD_2p_tables[occupied_squares_index].allocate_fill (X.SD_2p_tables[occupied_squares_index]);
      SD_2h_tables[occupied_squares_index].allocate_fill (X.SD_2h_tables[occupied_squares_index]);
    }
  
  U_finite_range_HF_HO_basis_HO_expansion_part.allocate_fill_object_elements (X.U_finite_range_HF_HO_basis_HO_expansion_part);

  HO_overlaps_basis.allocate_fill (X.HO_overlaps_basis);
  
  HO_overlaps_basis_Fermi.allocate_fill (X.HO_overlaps_basis_Fermi);
  
  HO_overlaps.allocate_fill_object_elements (X.HO_overlaps);
  
  HO_overlaps_Fermi.allocate_fill_object_elements (X.HO_overlaps_Fermi);
  
  GHF_overlaps.allocate_fill_object_elements (X.GHF_overlaps);

  d_core_potential_tab.allocate_fill   (X.d_core_potential_tab);
  R0_core_potential_tab.allocate_fill  (X.R0_core_potential_tab);
  Vo_core_potential_tab.allocate_fill  (X.Vo_core_potential_tab);
  Vso_core_potential_tab.allocate_fill (X.Vso_core_potential_tab);
  
  d_basis_core_potential_tab.allocate_fill   (X.d_basis_core_potential_tab);
  R0_basis_core_potential_tab.allocate_fill  (X.R0_basis_core_potential_tab);
  Vo_basis_core_potential_tab.allocate_fill  (X.Vo_basis_core_potential_tab);
  Vso_basis_core_potential_tab.allocate_fill (X.Vso_basis_core_potential_tab);
  
  d_basis_tab.allocate_fill   (X.d_basis_tab);
  R0_basis_tab.allocate_fill  (X.R0_basis_tab);
  Vo_basis_tab.allocate_fill  (X.Vo_basis_tab);
  Vso_basis_tab.allocate_fill (X.Vso_basis_tab);
    
  b_partial_waves.allocate_fill (X.b_partial_waves);

  basis_PSI_quantum_numbers_tab.allocate_fill (X.basis_PSI_quantum_numbers_tab);

  BPin_for_one_jump_tab.allocate_fill (X.BPin_for_one_jump_tab);
  
  BPout_for_one_jump_tab.allocate_fill (X.BPout_for_one_jump_tab);
  
  BPin_iMin_for_one_jump_tab.allocate_fill (X.BPin_iMin_for_one_jump_tab);
  
  BPout_iMout_for_one_jump_tab.allocate_fill (X.BPout_iMout_for_one_jump_tab);

  is_inSD_in_space_tab_Jpm.allocate_fill (X.is_inSD_in_space_tab_Jpm);

  for (unsigned int occupied_squares_index = 0 ; occupied_squares_index <= 1 ; occupied_squares_index++)
    iC_in_min_tab[occupied_squares_index].allocate_fill (X.iC_in_min_tab[occupied_squares_index]);
  
  for (unsigned int occupied_squares_index = 0 ; occupied_squares_index <= 1 ; occupied_squares_index++)
    iC_in_max_tab[occupied_squares_index].allocate_fill (X.iC_in_max_tab[occupied_squares_index]);

  iC_out_min_tab.allocate_fill (X.iC_out_min_tab);
  iC_out_max_tab.allocate_fill (X.iC_out_max_tab);
  
  for (unsigned int occupied_squares_index = 0 ; occupied_squares_index <= 1 ; occupied_squares_index++)
    is_configuration_in_in_space_tabs[occupied_squares_index].allocate_fill (X.is_configuration_in_in_space_tabs[occupied_squares_index]);
      
  is_configuration_out_in_space_tab.allocate_fill (X.is_configuration_out_in_space_tab);
  
  for (unsigned int occupied_squares_index = 0 ; occupied_squares_index <= 1 ; occupied_squares_index++)
    is_inSD_in_space_tabs[occupied_squares_index].allocate_fill (X.is_inSD_in_space_tabs[occupied_squares_index]);
  
  is_outSD_in_space_tab.allocate_fill (X.is_outSD_in_space_tab);

  is_it_configuration_inter_to_include_tab.allocate_fill (X.is_it_configuration_inter_to_include_tab);
  
  is_it_SD_inter_to_include_tab.allocate_fill (X.is_it_SD_inter_to_include_tab);	

  initial_to_nljm_ordered_states.allocate_fill (X.initial_to_nljm_ordered_states);
  
  nljm_ordered_to_initial_states.allocate_fill (X.nljm_ordered_to_initial_states);

  dimensions_SD_HO_Berggren_overlaps_table.allocate_fill (X.dimensions_SD_HO_Berggren_overlaps_table);
  
  SD_HO_Berggren_overlaps_table.allocate_fill (X.SD_HO_Berggren_overlaps_table);

  scalar_density_matrices.allocate_fill (X.scalar_density_matrices);
  
  natural_orbitals_matrices.allocate_fill (X.natural_orbitals_matrices);
  
  ESPEs_Hamiltonian_matrices.allocate_fill (X.ESPEs_Hamiltonian_matrices);
  
  ESPEs_Hamiltonian_orbitals_matrices.allocate_fill (X.ESPEs_Hamiltonian_orbitals_matrices);
  
  natural_orbitals_reference_states.allocate_fill (X.natural_orbitals_reference_states);

  SD_quantum_numbers_tab.allocate_fill (X.SD_quantum_numbers_tab);
}




void nucleons_data::deallocate ()
{
  basis_potential_partial_waves.deallocate ();
  
  TRS_nljm_indices.deallocate ();
    
  dimensions_configuration_set.deallocate ();
  dimensions_configuration_set_1h.deallocate ();
  dimensions_configuration_set_2h.deallocate ();
  
  sum_dimensions_configuration_set.deallocate ();
  sum_dimensions_configuration_set_1h.deallocate ();
  sum_dimensions_configuration_set_2h.deallocate ();
  
  configuration_set.deallocate ();
  configuration_set_1h.deallocate ();
  configuration_set_2h.deallocate ();
  
  dimensions_SD_set.deallocate ();
  dimensions_SD_set_1h.deallocate ();
  dimensions_SD_set_2h.deallocate ();
  
  sum_dimensions_SD_set.deallocate ();
  sum_dimensions_SD_set_1h.deallocate ();
  sum_dimensions_SD_set_2h.deallocate ();

  SD_set.deallocate ();
  SD_set_1h.deallocate ();
  SD_set_2h.deallocate ();  

  E_hw_table.deallocate ();

  OBMEs_CM_set_HO_expansion.deallocate ();
  
  OBMEs_CM_set_R_cut.deallocate ();
  
  reduced_grad_HO_expansion_set.deallocate ();
  
  reduced_r_HO_expansion_set.deallocate ();
  
  reduced_r_HO_expansion_rms_radius_pn_set.deallocate ();
  
  reduced_grad_R_cut_set.deallocate ();
  
  reduced_r_R_cut_set.deallocate ();
  
  reduced_r_R_cut_rms_radius_pn_set.deallocate ();

  OBMEs_multipole_square_HO_expansion.deallocate ();
  
  OBMEs_multipole_square_R_cut.deallocate ();
  
  OBMEs_multipole_reduced_HO_expansion.deallocate ();
  
  OBMEs_multipole_reduced_R_cut.deallocate ();
  
  OBMEs_inter_set.deallocate ();

  nmax_lj_tab.deallocate ();
  
  nmin_lj_valence_tab.deallocate ();

  shells_indices.deallocate ();
  
  is_it_valence_shell_tab.deallocate ();

  one_body_indices.deallocate ();
  
  shells.deallocate ();
  
  shells_plus.deallocate ();
  shells_minus.deallocate ();
  
  phi_table.deallocate ();

  Ueq_finite_range_tab_uniform.deallocate ();
  
  Ueq_finite_range_plus_tab_uniform.deallocate ();
  Ueq_finite_range_minus_tab_uniform.deallocate ();
  
  source_tab_uniform.deallocate ();
  
  source_plus_tab_uniform.deallocate ();  
  source_minus_tab_uniform.deallocate ();
  
  OBMEs_HF_SGI_MSGI.deallocate ();

  h_basis.deallocate ();
  
  TBMEs.deallocate ();

  shells_quantum_numbers.deallocate ();

  SD_TRS_indices.deallocate ();
  
  SD_TRS_indices_1h.deallocate ();
  SD_TRS_indices_2h.deallocate ();
  
  SD_TRS_reordering_bin_phases.deallocate ();
  
  SD_TRS_reordering_bin_phases_1h.deallocate ();
  SD_TRS_reordering_bin_phases_2h.deallocate ();
  
  SD_TRS_bin_phases.deallocate ();
  
  SD_TRS_bin_phases_1h.deallocate ();
  SD_TRS_bin_phases_2h.deallocate ();

  dimensions_configuration_one_jump_table_in_to_out.deallocate ();
  dimensions_configuration_one_jump_table_out_to_in.deallocate ();
  
  configuration_one_jump_table_in_to_out.deallocate ();
  configuration_one_jump_table_out_to_in.deallocate ();
  
  dimensions_SD_one_jump_table_in_to_out.deallocate ();
  dimensions_SD_one_jump_table_out_to_in.deallocate ();
  
  dimensions_SD_one_jump_table_Jpm_in_to_out.deallocate ();
  dimensions_SD_one_jump_table_Jpm_out_to_in.deallocate ();
    
  SD_one_jump_table_in_to_out.deallocate ();
  SD_one_jump_table_out_to_in.deallocate ();
  
  SD_one_jump_table_Jpm_in_to_out.deallocate ();
  SD_one_jump_table_Jpm_out_to_in.deallocate ();
        
  for (unsigned int occupied_squares_index = 0 ; occupied_squares_index <= 1 ; occupied_squares_index++)
    {
      are_configurations_inter_occupied_in_space_1ph_tables[occupied_squares_index].deallocate ();
  
      are_configurations_inter_occupied_in_space_2ph_tables[occupied_squares_index].deallocate ();
      
      dimensions_configuration_1p_tables[occupied_squares_index].deallocate ();
      dimensions_configuration_1h_tables[occupied_squares_index].deallocate ();
  
      dimensions_configuration_2p_tables[occupied_squares_index].deallocate ();
      dimensions_configuration_2h_tables[occupied_squares_index].deallocate ();
  
      configuration_1p_tables[occupied_squares_index].deallocate ();
      configuration_1h_tables[occupied_squares_index].deallocate ();
  
      configuration_2p_tables[occupied_squares_index].deallocate ();
      configuration_2h_tables[occupied_squares_index].deallocate ();

      dimensions_SD_1p_tables[occupied_squares_index].deallocate ();
      dimensions_SD_1h_tables[occupied_squares_index].deallocate ();
  
      dimensions_SD_2p_tables[occupied_squares_index].deallocate ();
      dimensions_SD_2h_tables[occupied_squares_index].deallocate ();
  
      SD_1p_tables[occupied_squares_index].deallocate ();
      SD_1h_tables[occupied_squares_index].deallocate ();

      SD_2p_tables[occupied_squares_index].deallocate ();
      SD_2h_tables[occupied_squares_index].deallocate ();
    }
  
  U_finite_range_HF_HO_basis_HO_expansion_part.deallocate ();

  HO_overlaps_basis.deallocate ();
  
  HO_overlaps_basis_Fermi.deallocate ();
  
  HO_overlaps.deallocate ();
  
  HO_overlaps_Fermi.deallocate ();

  GHF_overlaps.deallocate ();
  
  d_core_potential_tab.deallocate ();
  R0_core_potential_tab.deallocate ();
  Vo_core_potential_tab.deallocate ();
  Vso_core_potential_tab.deallocate ();
  
  d_basis_core_potential_tab.deallocate ();
  R0_basis_core_potential_tab.deallocate ();
  Vo_basis_core_potential_tab.deallocate ();
  Vso_basis_core_potential_tab.deallocate ();
  
  d_basis_tab.deallocate ();
  R0_basis_tab.deallocate ();
  Vo_basis_tab.deallocate ();
  Vso_basis_tab.deallocate ();
    
  b_partial_waves.deallocate ();

  basis_PSI_quantum_numbers_tab.deallocate ();

  BPin_for_one_jump_tab.deallocate ();
  
  BPout_for_one_jump_tab.deallocate ();
  
  BPin_iMin_for_one_jump_tab.deallocate ();
  
  BPout_iMout_for_one_jump_tab.deallocate ();
  
  for (unsigned int occupied_squares_index = 0 ; occupied_squares_index <= 1 ; occupied_squares_index++)
    iC_in_min_tab[occupied_squares_index].deallocate ();

  for (unsigned int occupied_squares_index = 0 ; occupied_squares_index <= 1 ; occupied_squares_index++)
    iC_in_max_tab[occupied_squares_index].deallocate ();
  
  iC_out_min_tab.deallocate ();
  iC_out_max_tab.deallocate ();
  
  for (unsigned int occupied_squares_index = 0 ; occupied_squares_index <= 1 ; occupied_squares_index++)
    is_configuration_in_in_space_tabs[occupied_squares_index].deallocate ();

  is_configuration_out_in_space_tab.deallocate ();
  
  is_inSD_in_space_tab_Jpm.deallocate ();
  
  for (unsigned int occupied_squares_index = 0 ; occupied_squares_index <= 1 ; occupied_squares_index++)
    is_inSD_in_space_tabs[occupied_squares_index].deallocate ();
  
  is_outSD_in_space_tab.deallocate ();
  
  is_it_configuration_inter_to_include_tab.deallocate ();
  
  is_it_SD_inter_to_include_tab.deallocate ();	

  initial_to_nljm_ordered_states.deallocate ();
  
  nljm_ordered_to_initial_states.deallocate ();

  dimensions_SD_HO_Berggren_overlaps_table.deallocate ();
  
  SD_HO_Berggren_overlaps_table.deallocate ();

  scalar_density_matrices.deallocate ();
  
  natural_orbitals_matrices.deallocate ();
  
  ESPEs_Hamiltonian_matrices.deallocate ();
  
  ESPEs_Hamiltonian_orbitals_matrices.deallocate ();
  
  natural_orbitals_reference_states.deallocate ();

  SD_quantum_numbers_tab.deallocate ();

  is_it_M_scheme = false;

  is_Coulomb_Hamiltonian_here = false;

  are_there_basis_natural_orbitals = false;
  
  are_there_new_natural_orbitals = false;

  particle = NO_PARTICLE;

  nmax = 0;
  lmax = 0;

  n_scat_max = 0;

  n_holes_max = 0;
  n_holes_max_pole_approximation = 0;
  
  E_min_hw = 0;
  E_max_hw = 0;
  E_max_hw_pole_approximation = 0;

  A = 0;

  A_basis = 0;

  A_core = 0;
  Z_core = 0;
  N_core = 0;

  Z = 0;
  N = 0;

  Z_basis = 0;
  N_basis = 0;

  hole_states_number = 0;

  N_nucleons = 0;

  N_valence_nucleons = 0;

  N_valence_nucleons_1h = 0;
  N_valence_nucleons_2h = 0;

  N_valence_nucleons_basis = 0;

  Z_charge = 0;

  Z_charge_basis_potential = 0;

  nucleus_mass = 0;

  nucleus_mass_basis = 0;

  N_nljm     = 0;
  N_nljm_res = 0;

  N_nlj     = 0;
  N_nlj_res = 0;
  
  natural_orbitals_reference_states_number = 0;

  jmax = 0;

  m_min = 0;
  m_max = 0;

  M_max    = 0;
  M_max_1h = 0;
  M_max_2h = 0;

  effective_mass_for_calc = 0;  

  m_max_minus_half = 0;

  two_m_max = 0;

  four_m_max = 0;

  m_max_minus_m_min = 0;

  iM_max    = 0;
  iM_max_1h = 0;
  iM_max_2h = 0;

  debut_file_name = "";

  R_charge = 0;

  effective_charge = 0;

  basis_potential = NO_POTENTIAL; 
  H_potential     = NO_POTENTIAL; 

  neutron_basis_potential = false;
  
  is_it_OCM_HO_core = false;

  N_bef_R_GL = 0;
  N_aft_R_GL = 0;

  N_bef_R_uniform = 0;
  N_aft_R_uniform = 0;

  Nk_momentum_uniform = 0;
  Nk_momentum_GL  = 0;
  
  R = 0;

  step_bef_R_uniform = 0;
  
  R_real_max = 0;

  step_momentum_uniform = 0;
  
  kmax_momentum = 0;

  R_Fermi_momentum = 0;
  
  BPmin_global = 0;
  BPmax_global = 0;

  Jmin_global = 0;
  Jmax_global = 0;

  R_cut_function = 0;
  d_cut_function = 0;

  dimension_1p1h_space_BP_iM_fixed_max = 0;
  dimension_2p2h_space_BP_iM_fixed_max = 0;

  BP_one_configuration = 0;
  iC_one_configuration = 0;

  dimension_configuration_total    = 0;
  dimension_configuration_total_1h = 0;
  dimension_configuration_total_2h = 0;

  dimension_configuration_max    = 0;
  dimension_configuration_max_1h = 0;
  dimension_configuration_max_2h = 0;

  dimension_SD_total    = 0;
  dimension_SD_total_1h = 0;
  dimension_SD_total_2h = 0;

  dimension_SD_max    = 0;
  dimension_SD_max_1h = 0;
  dimension_SD_max_2h = 0;
  
  for (unsigned int i = 0 ; i < 5 ; i++) 
    {
      V0_KKNN[i] = 0.0;
      rho_KKNN[i] = 0.0;
    }

  for (unsigned int i = 0 ; i < 3 ; i++) 
    {
      Vls_KKNN[i] = 0.0;
      rho_ls_KKNN[i] = 0.0;
    }
}



// Routines deallocating specific arrays of nucleons_data
// ------------------------------------------------------

void nucleons_data::one_jump_tables_in_to_out_deallocate ()
{
  dimensions_configuration_one_jump_table_in_to_out.deallocate ();
  
  configuration_one_jump_table_in_to_out.deallocate ();
  
  dimensions_SD_one_jump_table_in_to_out.deallocate ();

  SD_one_jump_table_in_to_out.deallocate ();
}

void nucleons_data::one_jump_tables_Jpm_in_to_out_deallocate ()
{
  dimensions_SD_one_jump_table_Jpm_in_to_out.deallocate ();
  
  SD_one_jump_table_Jpm_in_to_out.deallocate ();
}

void nucleons_data::one_jump_tables_out_to_in_deallocate ()
{
  dimensions_configuration_one_jump_table_out_to_in.deallocate ();
  
  configuration_one_jump_table_out_to_in.deallocate ();
  
  dimensions_SD_one_jump_table_out_to_in.deallocate ();

  SD_one_jump_table_out_to_in.deallocate ();
}

void nucleons_data::one_jump_tables_Jpm_out_to_in_deallocate ()
{
  dimensions_SD_one_jump_table_Jpm_out_to_in.deallocate ();
  
  SD_one_jump_table_Jpm_out_to_in.deallocate ();
}

void nucleons_data::tables_1ph_deallocate ()
{
  for (unsigned int occupied_squares_index = 0 ; occupied_squares_index <= 1 ; occupied_squares_index++)
    {
      are_configurations_inter_occupied_in_space_1ph_tables[occupied_squares_index].deallocate ();

      dimensions_configuration_1p_tables[occupied_squares_index].deallocate ();
      dimensions_configuration_1h_tables[occupied_squares_index].deallocate ();
      
      configuration_1p_tables[occupied_squares_index].deallocate ();
      configuration_1h_tables[occupied_squares_index].deallocate ();
  
      dimensions_SD_1p_tables[occupied_squares_index].deallocate ();
      dimensions_SD_1h_tables[occupied_squares_index].deallocate ();
      
      SD_1p_tables[occupied_squares_index].deallocate ();
      SD_1h_tables[occupied_squares_index].deallocate ();
    }
}

void nucleons_data::tables_2ph_deallocate ()
{
  for (unsigned int occupied_squares_index = 0 ; occupied_squares_index <= 1 ; occupied_squares_index++)
    {
      are_configurations_inter_occupied_in_space_2ph_tables[occupied_squares_index].deallocate ();

      dimensions_configuration_2p_tables[occupied_squares_index].deallocate ();
      dimensions_configuration_2h_tables[occupied_squares_index].deallocate ();
      
      configuration_2p_tables[occupied_squares_index].deallocate ();
      configuration_2h_tables[occupied_squares_index].deallocate ();
  
      dimensions_SD_2p_tables[occupied_squares_index].deallocate ();
      dimensions_SD_2h_tables[occupied_squares_index].deallocate ();
      
      SD_2p_tables[occupied_squares_index].deallocate ();  
      SD_2h_tables[occupied_squares_index].deallocate ();
    }
}




// Constants of nucleons_data are initialized here from input_data
// ---------------------------------------------------------------
// M-scheme is used everywhere except in two-particle codes, where one uses J-scheme.

void nucleons_data::initialize_constants (
					  const bool is_it_M_scheme_input , 
					  const enum particle_type particle_input , 
					  const class input_data_str &input_data)
{
  if (is_it_filled ()) error_message_print_abort ("constants cannot be initialized twice in nucleons_data::initialize_constants");

  is_it_M_scheme = is_it_M_scheme_input;
  
  particle = particle_input;

  is_Coulomb_Hamiltonian_here = input_data.get_is_Coulomb_Hamiltonian_here ();
  
  basis_potential = input_data.get_basis_potential ();

  H_potential = input_data.get_H_potential ();
  
  neutron_basis_potential = input_data.get_neutron_basis_potential ();
  
  nucleus_mass = input_data.get_nucleus_mass ();
  
  nucleus_mass_basis = input_data.get_nucleus_mass_basis ();
  
  R = input_data.get_R ();

  step_bef_R_uniform = input_data.get_step_bef_R_uniform ();
  
  R_real_max = input_data.get_R_real_max ();
  
  kmax_momentum = input_data.get_kmax_momentum ();

  R_Fermi_momentum = input_data.get_R_Fermi_momentum ();
  
  step_momentum_uniform = input_data.get_step_momentum_uniform ();
    
  N_bef_R_GL = input_data.get_N_bef_R_GL ();
  N_aft_R_GL = input_data.get_N_aft_R_GL ();
  
  N_bef_R_uniform = input_data.get_N_bef_R_uniform ();
  N_aft_R_uniform = input_data.get_N_aft_R_uniform ();

  Nk_momentum_uniform = input_data.get_Nk_momentum_uniform ();
  
  Nk_momentum_GL  = input_data.get_Nk_momentum_GL ();
  
  R_charge = input_data.get_R_charge ();
  
  R_cut_function = input_data.get_R_cut_function ();
  d_cut_function = input_data.get_d_cut_function ();
  
  A = input_data.get_A ();
  
  A_basis = input_data.get_A_basis ();
  
  A_core = input_data.get_A_core ();
  Z_core = input_data.get_Z_core ();
  N_core = input_data.get_N_core ();
  
  Z = input_data.get_Z ();
  N = input_data.get_N ();
  
  Z_basis = input_data.get_Z_basis ();
  N_basis = input_data.get_N_basis ();
  
  natural_orbitals_reference_states_number = input_data.get_natural_orbitals_reference_states_number ();

  if (particle == PROTON)
    {
      are_there_basis_natural_orbitals = input_data.get_are_there_basis_prot_natural_orbitals ();

      are_there_new_natural_orbitals = input_data.get_are_there_new_prot_natural_orbitals ();

      effective_mass_for_calc = input_data.get_prot_mass_for_calc ();
      
      N_valence_nucleons = input_data.get_Zval ();      

      N_valence_nucleons_basis = input_data.get_Zval_basis ();
      
      hole_states_number = input_data.get_prot_hole_states_number ();

      N_nucleons = input_data.get_Z ();
      
      Z_charge = input_data.get_Z_charge ();
      
      Z_charge_basis_potential = input_data.get_Z_charge_basis_potential ();
      
      N_nljm = input_data.get_Np_nljm ();
      
      N_nlj = input_data.get_Np_nlj ();
      
      N_nljm_res = input_data.get_Np_nljm_res ();
      
      N_nlj_res = input_data.get_Np_nlj_res ();
      
      nmax = input_data.get_nmax_p ();
      lmax = input_data.get_lmax_p ();

      jmax = input_data.get_jp_max ();
      
      m_max = input_data.get_mp_max ();      
      m_min = input_data.get_mp_min ();
      
      m_max_minus_half = input_data.get_mp_max_minus_half ();
      
      two_m_max = input_data.get_two_mp_max ();

      four_m_max = input_data.get_four_mp_max ();
      
      m_max_minus_m_min = input_data.get_mp_max_minus_mp_min ();
      
      BPmin_global = input_data.get_BPmin_global_pp ();
      BPmax_global = input_data.get_BPmax_global_pp ();
      
      Jmin_global = input_data.get_Jmin_global_pp ();
      Jmax_global = input_data.get_Jmax_global_pp ();
      
      n_scat_max = input_data.get_n_scat_max_p ();
      
      n_holes_max = input_data.get_n_holes_max_p ();

      n_holes_max_pole_approximation = input_data.get_n_holes_max_p_pole_approximation ();
  
      effective_charge = input_data.get_prot_effective_charge ();
    }

  if (particle == NEUTRON)
    {
      are_there_basis_natural_orbitals = input_data.get_are_there_basis_neut_natural_orbitals ();

      are_there_new_natural_orbitals = input_data.get_are_there_new_neut_natural_orbitals ();
      
      effective_mass_for_calc = input_data.get_neut_mass_for_calc ();
      
      N_valence_nucleons = input_data.get_Nval ();

      N_valence_nucleons_basis = input_data.get_Nval_basis ();
      
      hole_states_number = input_data.get_neut_hole_states_number ();

      N_nucleons = input_data.get_N ();
      
      Z_charge = 0;

      Z_charge_basis_potential = 0;
      
      N_nljm = input_data.get_Nn_nljm ();

      N_nlj = input_data.get_Nn_nlj ();
      
      N_nlj_res = input_data.get_Nn_nlj_res ();

      N_nljm_res = input_data.get_Nn_nljm_res ();
      
      nmax = input_data.get_nmax_n ();
      lmax = input_data.get_lmax_n ();
      
      jmax = input_data.get_jn_max ();

      m_max = input_data.get_mn_max ();
      m_min = input_data.get_mn_min ();
      
      m_max_minus_half = input_data.get_mn_max_minus_half ();
      
      two_m_max = input_data.get_two_mn_max ();

      four_m_max = input_data.get_four_mn_max ();
      
      m_max_minus_m_min = input_data.get_mn_max_minus_mn_min ();
      
      BPmin_global = input_data.get_BPmin_global_nn ();
      BPmax_global = input_data.get_BPmax_global_nn ();
      
      Jmin_global = input_data.get_Jmin_global_nn ();
      Jmax_global = input_data.get_Jmax_global_nn ();
      
      n_scat_max = input_data.get_n_scat_max_n ();
      
      n_holes_max = input_data.get_n_holes_max_n ();
      
      n_holes_max_pole_approximation = input_data.get_n_holes_max_n_pole_approximation ();
      
      effective_charge = input_data.get_neut_effective_charge ();
    }
  
  if (is_it_two_nucleon_ST_cluster_determine (particle))
    {
      if (is_it_M_scheme) error_message_print_abort ("J-scheme only for two-body systems");

      const int prot_mass_for_calc = input_data.get_prot_mass_for_calc ();
      const int neut_mass_for_calc = input_data.get_neut_mass_for_calc ();

      effective_mass_for_calc = two_nucleon_reduced_mass_calc (particle , prot_mass_for_calc , neut_mass_for_calc);
      
      N_valence_nucleons = 2;

      N_valence_nucleons_basis = 2;
      
      hole_states_number = 0;

      N_nucleons = 2;
      
      const int Z = input_data.get_Z ();

      Z_charge = Z - 1;

      Z_charge_basis_potential = Z_charge;
      
      N_nlj = input_data.get_N_nlj_relative ();
      
      N_nlj_res = input_data.get_N_nlj_res_relative ();
      
      nmax = input_data.get_nmax_relative ();
      lmax = input_data.get_lmax_relative ();
      jmax = input_data.get_jmax_relative ();

      const int S = make_int (S_cluster_determine (particle));

      BPmin_global = 0;
      BPmax_global = (lmax == 0) ? (0) : (1);
      
      Jmin_global = abs (lmax - S);
      Jmax_global = lmax + S;
    }
  
  N_valence_nucleons_1h = (N_valence_nucleons >= 1) ? (N_valence_nucleons - 1) : (NO_VALENCE_NUCLEONS);
  N_valence_nucleons_2h = (N_valence_nucleons >= 2) ? (N_valence_nucleons - 2) : (NO_VALENCE_NUCLEONS);
}








// One-body arrays and energy truncation values copied from input_data
// -------------------------------------------------------------------
// Arrays of potential parameters, basis wave function quantum numbers, natural orbital reference states and energy truncation arrays are allocated and filled here.

void nucleons_data::alloc_fill_one_body_data_tables_E_min_max_hw (const class input_data_str &input_data)
{  
  for (unsigned int i = 0 ; i < 5 ; i++) 
    {
      V0_KKNN[i] = input_data.get_V0_KKNN(i);
      
      rho_KKNN[i] = input_data.get_rho_KKNN(i);
    }

  for (unsigned int i = 0 ; i < 3 ; i++) 
    {
      Vls_KKNN[i] = input_data.get_Vls_KKNN(i);
      
      rho_ls_KKNN[i] = input_data.get_rho_ls_KKNN(i);
    }
  
  if (particle == PROTON)
    {
      d_core_potential_tab.allocate_fill   (input_data.get_prot_d_core_potential_tab ());
      R0_core_potential_tab.allocate_fill  (input_data.get_prot_R0_core_potential_tab ());
      Vo_core_potential_tab.allocate_fill  (input_data.get_prot_Vo_core_potential_tab ());
      Vso_core_potential_tab.allocate_fill (input_data.get_prot_Vso_core_potential_tab ());

      d_basis_core_potential_tab.allocate_fill   (input_data.get_prot_d_basis_core_potential_tab ());
      R0_basis_core_potential_tab.allocate_fill  (input_data.get_prot_R0_basis_core_potential_tab ());
      Vo_basis_core_potential_tab.allocate_fill  (input_data.get_prot_Vo_basis_core_potential_tab ());
      Vso_basis_core_potential_tab.allocate_fill (input_data.get_prot_Vso_basis_core_potential_tab ());

      d_basis_tab.allocate_fill   (input_data.get_prot_d_basis_tab ());
      R0_basis_tab.allocate_fill  (input_data.get_prot_R0_basis_tab ());
      Vo_basis_tab.allocate_fill  (input_data.get_prot_Vo_basis_tab ());
      Vso_basis_tab.allocate_fill (input_data.get_prot_Vso_basis_tab ());
  
      if (N_nlj > 0)
	{	  
	  shells_quantum_numbers.allocate_fill (input_data.get_prot_shells_quantum_numbers ());

	  shells_quantum_numbers.quick_sort (0 , N_nlj - 1);
	  
	  b_partial_waves.allocate (0.5 , lmax);
	  
	  b_partial_waves = input_data.get_prot_b_lab_partial_waves ();

	  basis_potential_partial_waves.allocate (0.5 , lmax);

	  basis_potential_partial_waves = input_data.get_prot_basis_potential_partial_waves ();

	  optimized_partial_waves_data_alloc_fill (input_data);
	}
    }

  if (particle == NEUTRON)
    {
      d_core_potential_tab.allocate_fill   (input_data.get_neut_d_core_potential_tab ());
      R0_core_potential_tab.allocate_fill  (input_data.get_neut_R0_core_potential_tab ());
      Vo_core_potential_tab.allocate_fill  (input_data.get_neut_Vo_core_potential_tab ());
      Vso_core_potential_tab.allocate_fill (input_data.get_neut_Vso_core_potential_tab ());

      d_basis_core_potential_tab.allocate_fill   (input_data.get_neut_d_basis_core_potential_tab ());
      R0_basis_core_potential_tab.allocate_fill  (input_data.get_neut_R0_basis_core_potential_tab ());
      Vo_basis_core_potential_tab.allocate_fill  (input_data.get_neut_Vo_basis_core_potential_tab ());
      Vso_basis_core_potential_tab.allocate_fill (input_data.get_neut_Vso_basis_core_potential_tab ());

      d_basis_tab.allocate_fill   (input_data.get_neut_d_basis_tab ());
      R0_basis_tab.allocate_fill  (input_data.get_neut_R0_basis_tab ());
      Vo_basis_tab.allocate_fill  (input_data.get_neut_Vo_basis_tab ());
      Vso_basis_tab.allocate_fill (input_data.get_neut_Vso_basis_tab ());

      if (N_nlj > 0)
	{
	  shells_quantum_numbers.allocate_fill (input_data.get_neut_shells_quantum_numbers ());
	  
	  shells_quantum_numbers.quick_sort (0 , N_nlj - 1);

	  b_partial_waves.allocate (0.5 , lmax);

	  b_partial_waves = input_data.get_neut_b_lab_partial_waves ();
	  
	  basis_potential_partial_waves.allocate (0.5 , lmax);	  

	  basis_potential_partial_waves = input_data.get_neut_basis_potential_partial_waves ();
	  
	  optimized_partial_waves_data_alloc_fill (input_data);
	}
    }

  const double A_dependent_factor_core_potential = A_dependent_factor_core_potential_calc (particle , input_data);
  
  Vo_core_potential_tab *= A_dependent_factor_core_potential;
  
  Vo_basis_core_potential_tab *= A_dependent_factor_core_potential;
      
  if (is_it_two_nucleon_ST_cluster_determine (particle))
    {
      d_basis_tab.allocate_fill   (input_data.get_d_basis_relative_tab ());
      R0_basis_tab.allocate_fill  (input_data.get_R0_basis_relative_tab ());
      Vo_basis_tab.allocate_fill  (input_data.get_Vo_basis_relative_tab ());
      Vso_basis_tab.allocate_fill (input_data.get_Vso_basis_relative_tab ());

      if (N_nlj > 0)
	{
	  const double spin = J_intrinsic_cluster_determine (particle);

	  shells_quantum_numbers.allocate_fill (input_data.get_shells_quantum_numbers_relative ());
	  
	  shells_quantum_numbers.quick_sort (0 , N_nlj - 1);
	  
	  b_partial_waves.allocate (spin , lmax);

	  const double b_lab = input_data.get_b_lab ();

	  const double b_relative = b_lab*M_SQRT2;
  
	  b_partial_waves = b_relative;

	  basis_potential_partial_waves.allocate (spin , lmax);	  

	  basis_potential_partial_waves = basis_potential;
	}
    }

  if (is_it_one_nucleon_determine (particle))
    {
      E_min_hw = E_min_hw_pp_nn (N_valence_nucleons , shells_quantum_numbers);
  
      E_max_hw = input_data.get_E_relative_max_hw () + E_min_hw;
  
      E_max_hw_pole_approximation = input_data.get_E_relative_max_hw_pole_approximation () + E_min_hw;
    }

  if (N_nlj > 0) fill_nljm_nlj_one_body_indices_alloc_calc ();

  debut_file_name = STORAGE_DIR + "Z" + make_string<int> (Z_basis) + "_N" + make_string<int> (N_basis);

  if (natural_orbitals_reference_states_number > 0)
    {     
      const int Aval_basis = Z_basis + N_basis - A_core;
	  
      natural_orbitals_reference_states.allocate (natural_orbitals_reference_states_number);

      const class array<unsigned int> &natural_orbitals_reference_states_BP_tab = input_data.get_natural_orbitals_reference_states_BP_tab ();

      const class array<unsigned int> &natural_orbitals_reference_states_vector_index_tab = input_data.get_natural_orbitals_reference_states_vector_index_tab ();

      const class array<double> &natural_orbitals_reference_states_J_tab = input_data.get_natural_orbitals_reference_states_J_tab ();

      for (unsigned int i = 0 ; i < natural_orbitals_reference_states_number ; i++)
	{
	  const unsigned int BP = natural_orbitals_reference_states_BP_tab(i);

	  const unsigned int vector_index = natural_orbitals_reference_states_vector_index_tab(i);

	  const double J = natural_orbitals_reference_states_J_tab(i);

	  const int two_J = make_int (2.0*J);

	  if (Aval_basis%2 != two_J%2) error_message_print_abort ("J is integer for Aval[basis] even and half-integer for Aval[basis] odd for J.Pi=" + J_Pi_string (BP , J) + " (natural orbital reference states)");

	  class correlated_state_str &natural_orbitals_reference_state = natural_orbitals_reference_states(i);

	  natural_orbitals_reference_state.initialize (Z , N , BP , J , vector_index , NADA , NADA , NADA , NADA , false);
	  
	  debut_file_name += "_" + J_Pi_vector_index_string_for_file_name (BP , J , vector_index);
	}
    }
}





// Arrays of indices, n[min] values, n[max] values and valence character of one-body shells and states are allocated and filled here.
// ----------------------------------------------------------------------------------------------------------------------------------

void nucleons_data::fill_nljm_nlj_one_body_indices_alloc_calc ()
{
  const double spin = S_cluster_determine (particle);

  nmax_lj_tab.allocate (spin , lmax);
  
  nmin_lj_valence_tab.allocate (spin , lmax);

  is_it_valence_shell_tab.allocate (spin , nmax , lmax);

  shells_indices.allocate (spin , nmax , lmax);

  if (is_it_M_scheme)
    {
      phi_table.allocate (N_nljm);
      
      one_body_indices.allocate (nmax , lmax , N_nlj , m_max);

      TRS_nljm_indices.allocate (N_nljm);

      initial_to_nljm_ordered_states.allocate (N_nljm);

      nljm_ordered_to_initial_states.allocate (N_nljm);
    }

  nmax_lj_tab = -1;

  nmin_lj_valence_tab = N_nlj;

  is_it_valence_shell_tab = false;

  shells_indices = OUT_OF_RANGE;

  unsigned int state = 0;
  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(s);
      
      const double j = shell_qn.get_j ();

      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();

      const int e_trunc = shell_qn.get_e_trunc ();

      const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

      const bool core_state = shell_qn.get_core_state ();
      
      const bool frozen_state = shell_qn.get_frozen_state ();

      shells_indices (n , l , j) = s;
      
      is_it_valence_shell_tab (n , l , j) = !frozen_state;

      const int nmax_lj_bef = nmax_lj_tab (l , j);

      nmax_lj_tab (l , j) = max (nmax_lj_bef , n);
      
      if (!core_state && !frozen_state)
	{
	  const int nmin_lj_valence_bef = nmin_lj_valence_tab (l , j);

	  nmin_lj_valence_tab (l , j) = min (nmin_lj_valence_bef , n);
	}

      if (is_it_M_scheme)
	{
	  const int two_j = make_int (2*j);

	  for (int m_index = 0 ; m_index <= two_j ; m_index++)
	    { 
	      const double m = m_index - j;

	      const int im = make_int (m + m_max);

	      phi_table(state).initialize (n , l , j , m , S_matrix_pole , core_state , frozen_state , e_trunc , s , m_max);

	      one_body_indices(n , l , j , m) = one_body_indices (s , im) = state;

	      state++;
	    }
	}
    }

  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	if (nmin_lj_valence_tab(l , j) == make_int (N_nlj)) nmin_lj_valence_tab(l , j) = nmax_lj_tab (l , j) + 1;	
      }

  if (is_it_M_scheme)
    {
      TRS_nljm_indices = OUT_OF_RANGE;
      
      initial_to_nljm_ordered_states = OUT_OF_RANGE;

      nljm_ordered_to_initial_states = OUT_OF_RANGE;

      for (unsigned int s = 0 ; s < N_nljm ; s++)
	{
	  const class nljm_struct &phi = phi_table (s);

	  const int n = phi.get_n ();
	  const int l = phi.get_l ();

	  const double j = phi.get_j ();
	  const double m = phi.get_m ();

	  TRS_nljm_indices(s) = one_body_indices (n , l , j , -m);
	}

      for (unsigned int s = 0 ; s < N_nljm ; s++) initial_to_nljm_ordered_states (s) = s;

      initial_to_nljm_ordered_states_sort (0 , N_nljm - 1 , phi_table , initial_to_nljm_ordered_states);

      for (unsigned int s = 0 ; s < N_nljm ; s++) nljm_ordered_to_initial_states (initial_to_nljm_ordered_states (s)) = s;
    }
}










// Overlaps between HO states (multiplied by a Fermi function or not) and basis states are allocated and calculated here.
// ----------------------------------------------------------------------------------------------------------------------

void nucleons_data::HO_overlaps_alloc_calc (
					    const bool is_it_only_basis ,
					    const class input_data_str &input_data)
{
  const bool is_it_one_nucleon_COSM_case = is_it_one_nucleon_determine (particle);

  const class array<int> &nmax_HO_tab = (is_it_one_nucleon_COSM_case) ? (input_data.get_nmax_HO_lab_tab ()) : (input_data.get_nmax_HO_relative_tab ());
  
  const int nmax_HO = nmax_calc (nmax_HO_tab);

  const int nmax_HO_plus_one = nmax_HO + 1;

  const int lmax_for_interaction_one_nucleon_case = (is_it_only_basis) ? (input_data.get_lmax_for_basis_interaction ()) : (input_data.get_lmax_for_interaction ());

  const int lmax_for_interaction = (is_it_one_nucleon_COSM_case) ? (lmax_for_interaction_one_nucleon_case) : (lmax);

  const int lmax_for_interaction_plus_one = lmax_for_interaction + 1;

  class array<double> r_bef_R_tab_GL (N_bef_R_GL);
  class array<double> w_bef_R_tab_GL (N_bef_R_GL);

  class array<double> r_aft_R_tab_GL (N_aft_R_GL);
  class array<double> w_aft_R_tab_GL (N_aft_R_GL);
  
  class array<double> HO_wfs_bef_R_tab_GL(nmax_HO_plus_one , lmax_for_interaction_plus_one , N_bef_R_GL);
  class array<double> HO_wfs_aft_R_tab_GL(nmax_HO_plus_one , lmax_for_interaction_plus_one , N_aft_R_GL);

  const double b_lab = input_data.get_b_lab ();

  const double b_relative = b_lab*M_SQRT2;

  const double b_inter = (is_it_one_nucleon_COSM_case) ? (b_lab) : (b_relative);

  if (is_it_only_basis)
    {
      HO_overlaps_basis.allocate (N_nlj);
      
      HO_overlaps_basis_Fermi.allocate (N_nlj);
    }
  else
    {
      HO_overlaps.allocate (N_nlj);
      
      HO_overlaps_Fermi.allocate (N_nlj);
    }

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R          , r_bef_R_tab_GL , w_bef_R_tab_GL);  
  Gauss_Legendre::abscissas_weights_tables_calc (R   , R_real_max , r_aft_R_tab_GL , w_aft_R_tab_GL);
  
  HO_wave_functions::HO_3D::u_r_tables_calc (b_inter , r_bef_R_tab_GL , HO_wfs_bef_R_tab_GL);
  HO_wave_functions::HO_3D::u_r_tables_calc (b_inter , r_aft_R_tab_GL , HO_wfs_aft_R_tab_GL);

  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(s);

      const int l = shell_qn.get_l ();

      const int nmax_HO_l = (l <= lmax_for_interaction) ? (nmax_HO_tab(l)) : (0);

      const int nmax_HO_l_plus_one = nmax_HO_l + 1;
      
      class vector_class<complex<double> > &HO_overlaps_shell       = (is_it_only_basis) ? (HO_overlaps_basis(s))       : (HO_overlaps(s));
      class vector_class<complex<double> > &HO_overlaps_Fermi_shell = (is_it_only_basis) ? (HO_overlaps_basis_Fermi(s)) : (HO_overlaps_Fermi(s));
      
      HO_overlaps_shell.allocate (nmax_HO_l_plus_one);
      
      HO_overlaps_Fermi_shell.allocate (nmax_HO_l_plus_one);

      HO_overlaps_shell = 0.0;

      HO_overlaps_Fermi_shell = 0.0;

      if (l > lmax_for_interaction) continue;

      const class spherical_state &shell = shells(s);
      
      const int n = shell_qn.get_n ();
      
      const double j = shell_qn.get_j ();

      const double b_shell = b_partial_waves(l , j);
      
      const bool is_it_HO = shell_qn.get_is_it_HO ();
      
      const class array<complex<double> > &wf_bef_R_tab_GL = shell.get_wf_bef_R_tab_GL ();
      const class array<complex<double> > &wf_aft_R_tab_GL = shell.get_wf_aft_R_tab_GL_real ();
      
      for (int n_HO = 0 ; n_HO <= nmax_HO_l ; n_HO++)
	{
	  if (is_it_HO && (abs (b_shell - b_inter) < precision)) 
	    {
	      HO_overlaps_shell(n_HO) = (n_HO == n) ? (1.0) : (0.0);

	      complex<double> HO_overlaps_Fermi_shell_n_HO = 0.0;

	      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
		HO_overlaps_Fermi_shell_n_HO += w_bef_R_tab_GL(i)*wf_bef_R_tab_GL(i)*HO_wfs_bef_R_tab_GL(n_HO , l , i)*Fermi_like_function (R_cut_function , d_cut_function , r_bef_R_tab_GL(i));

	      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
		HO_overlaps_Fermi_shell_n_HO += w_aft_R_tab_GL(i)*wf_aft_R_tab_GL(i)*HO_wfs_aft_R_tab_GL(n_HO , l , i)*Fermi_like_function (R_cut_function , d_cut_function , r_aft_R_tab_GL(i));

	      HO_overlaps_Fermi_shell(n_HO) = HO_overlaps_Fermi_shell_n_HO;
	    }
	  else
	    {
	      complex<double> HO_overlaps_shell_n_HO = 0.0;

	      complex<double> HO_overlaps_Fermi_shell_n_HO = 0.0;

	      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
		{
		  const double r = r_bef_R_tab_GL(i);

		  const double Fermi_r = Fermi_like_function (R_cut_function , d_cut_function , r);

		  const complex<double> wfs_w_product = w_bef_R_tab_GL(i)*wf_bef_R_tab_GL(i)*HO_wfs_bef_R_tab_GL(n_HO , l , i);
		  
		  HO_overlaps_shell_n_HO += wfs_w_product;
		  
		  HO_overlaps_Fermi_shell_n_HO += wfs_w_product*Fermi_r;
		}

	      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
		{	
		  const double r = r_aft_R_tab_GL(i);

		  const double Fermi_r = Fermi_like_function (R_cut_function , d_cut_function , r);

		  const complex<double> wfs_w_product = w_aft_R_tab_GL(i)*wf_aft_R_tab_GL(i)*HO_wfs_aft_R_tab_GL(n_HO , l , i);
		  
		  HO_overlaps_shell_n_HO += wfs_w_product;
		  
		  HO_overlaps_Fermi_shell_n_HO += wfs_w_product*Fermi_r;
		}

	      HO_overlaps_shell(n_HO) = HO_overlaps_shell_n_HO;

	      HO_overlaps_Fermi_shell(n_HO) = HO_overlaps_Fermi_shell_n_HO;
				
	    }
	}
      //HO_overlaps_Fermi_shell = HO_overlaps_shell;
    }
}














// Overlaps between GHF states and basis states are allocated and filled here.
// ---------------------------------------------------------------------------
// As one-body basis states are GHF states, overlaps are 0 or 1.

void nucleons_data::GHF_overlaps_alloc_fill (const class input_data_str &input_data)
{
  const string debut_file_name_basis_state = debut_file_name + "_basis_state_";

  const string debut_file_name_basis_state_particle = debut_file_name_basis_state + "_" + make_string<enum particle_type> (particle);
    
  GHF_overlaps.allocate (N_nlj);

  if (basis_potential == QBOX_POTENTIAL)
    {
      const class array<int> &nmax_GHF_lab_tab = input_data.get_nmax_GHF_lab_tab ();
  
      for (unsigned int s = 0 ; s < N_nlj ; s++)
	{
	  const class nlj_struct &shell_qn = shells_quantum_numbers(s);
      
	  const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ();
      
	  const int n = shell_qn.get_n ();
	  const int l = shell_qn.get_l ();

	  const double j = shell_qn.get_j ();
	      		
	  const int nmax_GHF_l = nmax_GHF_lab_tab(l);
	  
	  const int nmax_lj = nmax_lj_tab(l , j);

	  if (nmax_GHF_l < nmax_lj)
	    error_message_print_abort ("nmax.GHF[l=" + make_string<int> (l) +"] must be larger than one-body nmax of " + angular_state (l,j) + " for " + make_string<enum particle_type> (particle));
	  
	  const int nmax_GHF_l_plus_one = nmax_GHF_l + 1;
	  
	  class vector_class<complex<double> > &GHF_overlaps_shell = GHF_overlaps(s);
	  
	  GHF_overlaps_shell.allocate (nmax_GHF_l_plus_one);
            
	  if (is_it_natural_orbital)
	    {	
	      const string shell_qn_file_name_part = make_string<int> (n) + angular_state_for_file_name (l , j) + "_Berggren_basis_components.dat";
	      
	      GHF_overlaps_shell.read_disk (debut_file_name_basis_state_particle + shell_qn_file_name_part);
	    }
	  else
	    {
	      GHF_overlaps_shell = 0.0;
	      
	      GHF_overlaps_shell(n) = 1.0;
	    }
	}
    }
  else
    {
      for (unsigned int s = 0 ; s < N_nlj ; s++)
	{
	  const class nlj_struct &shell_qn = shells_quantum_numbers(s);
	      
	  const int n = shell_qn.get_n ();
	  const int l = shell_qn.get_l ();
	      
	  const double j = shell_qn.get_j ();
	      
	  const int nmax_lj = nmax_lj_tab (l , j);
	  
	  const int nmax_lj_plus_one = nmax_lj + 1;
      	
	  class vector_class<complex<double> > &GHF_overlaps_shell = GHF_overlaps(s);
	      
	  GHF_overlaps_shell.allocate (nmax_lj_plus_one);
	      
	  GHF_overlaps_shell = 0.0;
	      
	  GHF_overlaps_shell(n) = 1.0;
	}
    }
}

void nucleons_data::all_HO_GHF_overlaps_alloc_calc (const class input_data_str &input_data)
{
  HO_overlaps_alloc_calc (true  , input_data);
  HO_overlaps_alloc_calc (false , input_data);
  
  GHF_overlaps_alloc_fill (input_data);
}






// OBMEs of different interaction one-body operators (H, nuclear part, kinetic part, Coulomb part) allocated and read from disk files.
// -----------------------------------------------------------------------------------------------------------------------------------

void nucleons_data::OBMEs_inter_set_alloc_read_disk (const enum interaction_type inter)
{
  if ((particle != PROTON) && (particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in nucleons_data::OBMEs_inter_set_alloc_read_disk");

  const string debut_file_name_OBMEs_inter_set = debut_file_name + "_" + make_string<enum particle_type> (particle) + "_coupled_OBMEs_";
  
  if (!OBMEs_inter_set.is_it_filled ())
    {
      if (is_it_M_scheme)
	OBMEs_inter_set.allocate (N_nlj , phi_table);
      else
	OBMEs_inter_set.allocate (N_nlj);
    }

  if (THIS_PROCESS == MASTER_PROCESS)
    {  
      const string file_name_N_nlj = debut_file_name + "_" + make_string<enum particle_type> (particle) + "_N_nlj.dat";
      
      const unsigned int N_nlj_from_file = dimension_read_disk (file_name_N_nlj);

      const string file_name_N_nljm = (is_it_M_scheme) ? (debut_file_name + "_" + make_string<enum particle_type> (particle) + "_N_nljm.dat") : ("");

      const unsigned int N_nljm_from_file = (is_it_M_scheme) ? (dimension_read_disk (file_name_N_nljm)) : (0);

      class array<class nlj_struct> shells_qn_from_file(N_nlj_from_file);

      const string file_name_shells_qn = debut_file_name + "_" + make_string<enum particle_type> (particle) + "_shells_quantum_numbers.dat";

      shells_qn_from_file.read_disk (file_name_shells_qn);

      class array<class nljm_struct> phi_table_from_file(N_nljm_from_file);

      const string file_name_phi_table = (is_it_M_scheme) ? (debut_file_name + "_" + make_string<enum particle_type> (particle) + "_phi_table.dat") : ("");

      if (is_it_M_scheme) phi_table_from_file.read_disk (file_name_phi_table);

      class OBMEs_inter_set_str OBMEs_inter_set_from_file;

      if (is_it_M_scheme)
	OBMEs_inter_set_from_file.allocate (N_nlj_from_file , phi_table_from_file);
      else
	OBMEs_inter_set_from_file.allocate (N_nlj_from_file);
 
      OBMEs_inter_set_from_file.read_disk (inter , debut_file_name_OBMEs_inter_set);

      const class array<TYPE> &OBMEs_H_from_file       = OBMEs_inter_set_from_file (inter);
      const class array<TYPE> &OBMEs_nuclear_from_file = OBMEs_inter_set_from_file (ONE_BODY_NUCLEAR);
      const class array<TYPE> &OBMEs_kinetic_from_file = OBMEs_inter_set_from_file (ONE_BODY_KINETIC);
      const class array<TYPE> &OBMEs_Coulomb_from_file = OBMEs_inter_set_from_file (ONE_BODY_COULOMB);

      class array<TYPE> &OBMEs_H       = OBMEs_inter_set (inter);
      class array<TYPE> &OBMEs_nuclear = OBMEs_inter_set (ONE_BODY_NUCLEAR);
      class array<TYPE> &OBMEs_kinetic = OBMEs_inter_set (ONE_BODY_KINETIC);
      class array<TYPE> &OBMEs_Coulomb = OBMEs_inter_set (ONE_BODY_COULOMB);

      OBMEs_H       = 0.0;
      OBMEs_nuclear = 0.0;
      OBMEs_kinetic = 0.0;
      OBMEs_Coulomb = 0.0;

      for (unsigned int s_from_file = 0 ; s_from_file < N_nlj_from_file ; s_from_file++)
	{
	  const class nlj_struct &shell_from_file = shells_qn_from_file(s_from_file);
	  const int l = shell_from_file.get_l ();

	  if (l <= lmax)
	    {
	      const double j = shell_from_file.get_j ();
	      
	      const int n = shell_from_file.get_n ();
	      
	      const int nmax_lj = nmax_lj_tab(l,j);

	      if ((n <= nmax_lj) && is_it_valence_shell_tab(n , l , j))
		{
		  const unsigned int s = shells_indices(n , l , j);

		  for (unsigned int sp_from_file = 0 ; sp_from_file < N_nlj_from_file ; sp_from_file++)
		    {
		      const class nlj_struct &shell_p_from_file = shells_qn_from_file(sp_from_file);
		      
		      const int lp = shell_p_from_file.get_l ();

		      if (lp <= lmax)
			{
			  const double jp = shell_p_from_file.get_j ();

			  const int np = shell_p_from_file.get_n ();

			  const int np_max_lp_jp = nmax_lj_tab(lp,jp);

			  if ((np <= np_max_lp_jp) && is_it_valence_shell_tab(np , lp , jp))
			    {
			      const unsigned int sp = shells_indices(np , lp , jp);

			      OBMEs_H      (s , sp) = OBMEs_H_from_file      (s_from_file , sp_from_file);
			      OBMEs_nuclear(s , sp) = OBMEs_nuclear_from_file(s_from_file , sp_from_file);
			      OBMEs_kinetic(s , sp) = OBMEs_kinetic_from_file(s_from_file , sp_from_file);
			      OBMEs_Coulomb(s , sp) = OBMEs_Coulomb_from_file(s_from_file , sp_from_file);
			    }}}}}}
    }

#ifdef UseMPI
  
  OBMEs_inter_set.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

#endif
}




// OBMEs of different one-body center-of-mass operators (Hcm, P^2/2M, L^(1), A+[CM-HO], rms radii) allocated and read from disk files.
// -----------------------------------------------------------------------------------------------------------------------------------

void nucleons_data::OBMEs_CM_set_alloc_read_disk (const bool is_it_HO_expansion)
{
  if ((particle != PROTON) && (particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in nucleons_data::OBMEs_CM_set_alloc_read_disk");
		
  const string debut_file_name_OBMEs_CM_set = debut_file_name + "_" + make_string<enum particle_type> (particle) + "_coupled_OBMEs_";

  if (is_it_HO_expansion)
    {
      if (!OBMEs_CM_set_HO_expansion.is_it_filled ())
	{
	  if (is_it_M_scheme)
	    OBMEs_CM_set_HO_expansion.allocate (N_nlj , phi_table);
	  else
	    OBMEs_CM_set_HO_expansion.allocate (N_nlj);
	}
    }
  else
    {
      if (!OBMEs_CM_set_R_cut.is_it_filled ())
	{
	  if (is_it_M_scheme)
	    OBMEs_CM_set_R_cut.allocate (N_nlj , phi_table);
	  else
	    OBMEs_CM_set_R_cut.allocate (N_nlj);
	}
    }

  class OBMEs_CM_set_str &OBMEs_CM_set = (is_it_HO_expansion) ? (OBMEs_CM_set_HO_expansion) : (OBMEs_CM_set_R_cut);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      const string file_name_N_nlj = debut_file_name + "_" + make_string<enum particle_type> (particle) + "_N_nlj.dat";
      
      const unsigned int N_nlj_from_file = dimension_read_disk (file_name_N_nlj);

      const string file_name_N_nljm = (is_it_M_scheme) ? (debut_file_name + "_" + make_string<enum particle_type> (particle) + "_N_nljm.dat") : ("");

      const unsigned int N_nljm_from_file = (is_it_M_scheme) ? (dimension_read_disk (file_name_N_nljm)) : (0);

      class array<class nlj_struct> shells_qn_from_file(N_nlj_from_file);

      const string file_name_shells_qn = debut_file_name + "_" + make_string<enum particle_type> (particle) + "_shells_quantum_numbers.dat";

      shells_qn_from_file.read_disk (file_name_shells_qn);

      class array<class nljm_struct> phi_table_from_file(N_nljm_from_file);

      const string file_name_phi_table = (is_it_M_scheme) ? (debut_file_name + "_" + make_string<enum particle_type> (particle) + "_phi_table.dat") : ("");

      if (is_it_M_scheme) phi_table_from_file.read_disk (file_name_phi_table);

      class OBMEs_CM_set_str OBMEs_CM_set_from_file;

      if (is_it_M_scheme)
	OBMEs_CM_set_from_file.allocate (N_nlj_from_file , phi_table_from_file);
      else
	OBMEs_CM_set_from_file.allocate (N_nlj_from_file);
 
      OBMEs_CM_set_from_file.read_disk (is_it_HO_expansion , debut_file_name_OBMEs_CM_set);
      
      const class array<TYPE> &OBMEs_Hcm_from_file                            = OBMEs_CM_set_from_file(HCM);
      const class array<TYPE> &OBMEs_CM_kinetic_from_file                     = OBMEs_CM_set_from_file(CM_KINETIC);
      const class array<TYPE> &OBMEs_L_reduced_tensor_from_file               = OBMEs_CM_set_from_file(L_REDUCED_TENSOR);
      const class array<TYPE> &OBMEs_A_dagger_CM_HO_reduced_tensor_from_file  = OBMEs_CM_set_from_file(A_DAGGER_CM_HO_REDUCED_TENSOR);
      const class array<TYPE> &OBMEs_rms_radius_proton_from_file              = OBMEs_CM_set_from_file(RMS_RADIUS_PROTON);
      const class array<TYPE> &OBMEs_rms_radius_neutron_from_file             = OBMEs_CM_set_from_file(RMS_RADIUS_NEUTRON);

      class array<TYPE> &OBMEs_Hcm                           = OBMEs_CM_set(HCM);
      class array<TYPE> &OBMEs_CM_kinetic                    = OBMEs_CM_set(CM_KINETIC);
      class array<TYPE> &OBMEs_L_reduced_tensor              = OBMEs_CM_set(L_REDUCED_TENSOR);
      class array<TYPE> &OBMEs_A_dagger_CM_HO_reduced_tensor = OBMEs_CM_set(A_DAGGER_CM_HO_REDUCED_TENSOR);
      class array<TYPE> &OBMEs_rms_radius_proton             = OBMEs_CM_set(RMS_RADIUS_PROTON);
      class array<TYPE> &OBMEs_rms_radius_neutron            = OBMEs_CM_set(RMS_RADIUS_NEUTRON);

      OBMEs_Hcm                           = 0.0;
      OBMEs_CM_kinetic                    = 0.0;
      OBMEs_L_reduced_tensor              = 0.0;
      OBMEs_A_dagger_CM_HO_reduced_tensor = 0.0;
      OBMEs_rms_radius_proton             = 0.0;
      OBMEs_rms_radius_neutron            = 0.0;

      for (unsigned int s_from_file = 0 ; s_from_file < N_nlj_from_file ; s_from_file++)
	{
	  const class nlj_struct &shell_from_file = shells_qn_from_file(s_from_file);

	  const int l = shell_from_file.get_l ();

	  if (l <= lmax)
	    {
	      const double j = shell_from_file.get_j ();
	      
	      const int n = shell_from_file.get_n ();

	      const int nmax_lj = nmax_lj_tab(l,j);

	      if ((n <= nmax_lj) && is_it_valence_shell_tab(n , l , j))
		{
		  const unsigned int s = shells_indices(n , l , j);

		  for (unsigned int sp_from_file = 0 ; sp_from_file < N_nlj_from_file ; sp_from_file++)
		    {
		      const class nlj_struct &shell_p_from_file = shells_qn_from_file(sp_from_file);

		      const int lp = shell_p_from_file.get_l ();

		      if (lp <= lmax)
			{
			  const double jp = shell_p_from_file.get_j ();

			  const int np = shell_p_from_file.get_n ();

			  const int np_max_lp_jp = nmax_lj_tab(lp,jp);

			  if ((np <= np_max_lp_jp) && is_it_valence_shell_tab(np , lp , jp))
			    {
			      const unsigned int sp = shells_indices(np , lp , jp);

			      OBMEs_Hcm                           (s , sp) = OBMEs_Hcm_from_file                          (s_from_file , sp_from_file);
			      OBMEs_CM_kinetic                    (s , sp) = OBMEs_CM_kinetic_from_file                   (s_from_file , sp_from_file);
			      OBMEs_L_reduced_tensor              (s , sp) = OBMEs_L_reduced_tensor_from_file             (s_from_file , sp_from_file);
			      OBMEs_A_dagger_CM_HO_reduced_tensor (s , sp) = OBMEs_A_dagger_CM_HO_reduced_tensor_from_file(s_from_file , sp_from_file);
			      OBMEs_rms_radius_proton             (s , sp) = OBMEs_rms_radius_proton_from_file            (s_from_file , sp_from_file);
			      OBMEs_rms_radius_neutron            (s , sp) = OBMEs_rms_radius_neutron_from_file           (s_from_file , sp_from_file);			      
			    }}}}}}
    }

#ifdef UseMPI
  
  OBMEs_CM_set.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

#endif
}



















// OBMEs of different operators (interaction and center-of-mass) involving natural orbitals stored in files here.
// --------------------------------------------------------------------------------------------------------------

void nucleons_data::natural_orbitals_OBMEs_basis_store (const class interaction_class &inter_data) const
{
  
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in nucleons_data::natural_orbitals_OBMEs_basis_store.");

  if ((particle != PROTON) && (particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in nucleons_data::natural_orbitals_OBMEs_basis_store");

  if (N_nlj == 0) return;

  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  class lj_table<class matrix<TYPE> > new_basis_change_matrices(0.5 , lmax);

  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	const int nmax_lj = nmax_lj_tab(l,j);
    
	if (nmax_lj >= 0)
	  {
	    const class matrix<TYPE> &natural_orbitals_matrix = natural_orbitals_matrices(l , j);
	    
	    new_basis_change_matrices(l , j).allocate_fill (natural_orbitals_matrix);
	  }
      }
  
  new_basis_calc_store (new_basis_change_matrices);

  const string file_name_N_nlj = debut_file_name + "_" + make_string<enum particle_type> (particle) + "_N_nlj.dat";

  dimension_copy_disk (file_name_N_nlj , N_nlj);

  const string file_name_shells_quantum_numbers = debut_file_name + "_" + make_string<enum particle_type> (particle) + "_shells_quantum_numbers.dat";

  shells_quantum_numbers.copy_disk (file_name_shells_quantum_numbers);

  if (is_it_M_scheme)
    {
      const string file_name_N_nljm = debut_file_name + "_" + make_string<enum particle_type> (particle) + "_N_nljm.dat";

      dimension_copy_disk (file_name_N_nljm , N_nljm);
  
      const string file_name_phi_table = debut_file_name + "_" + make_string<enum particle_type> (particle) + "_phi_table.dat";

      phi_table.copy_disk (file_name_phi_table);
    }
      
  OBMEs_inter_CM_sets_new_basis_calc_store (TBME_inter , new_basis_change_matrices);
}










// New one-body basis states expanded with the initial one-body basis states stored on files as vectors
// ----------------------------------------------------------------------------------------------------

void nucleons_data::new_basis_calc_store (const class lj_table<class matrix<TYPE> > &new_basis_change_matrices) const
{
  if ((particle != PROTON) && (particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in nucleons_data::new_basis_calc_store");

  const string debut_file_name_basis_state = debut_file_name + "_basis_state_";

  const string debut_file_name_basis_state_particle = debut_file_name_basis_state + "_" + make_string<enum particle_type> (particle);
  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(s);
      
      const double j = shell_qn.get_j ();

      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();

      const int nmax_lj = nmax_lj_tab(l,j);

      if (nmax_lj >= 0)
	{
	  const bool core_state = shell_qn.get_core_state ();
	  
	  const bool frozen_state = shell_qn.get_frozen_state ();

	  if (!core_state || !frozen_state)
	    {
	      const int nmax_lj_plus_one = nmax_lj + 1;

	      class array<unsigned int> basis_shells_lj_indices(nmax_lj_plus_one);

	      for (int nn = 0 ; nn <= nmax_lj ; nn++)
		{
		  const unsigned int s = shells_indices(nn , l , j);

		  basis_shells_lj_indices(nn) = s;
		}
	      
	      const class matrix<TYPE> &new_basis_change_matrix = new_basis_change_matrices(l,j);
	      
	      const class vector_class<TYPE> &Vn = new_basis_change_matrix.eigenvector (n);
	      
	      const unsigned int basis_shell_index = basis_shells_lj_indices(n);

	      const class spherical_state &basis_shell = shells(basis_shell_index);
	      
	      class spherical_state new_shell(basis_shell);

	      new_shell.wave_calculation_from_vector (false , NADA , Vn , basis_shells_lj_indices , shells);
	  
	      if (THIS_PROCESS == MASTER_PROCESS)
		{
		  new_shell.copy_to_file_no_scaled_wfs (debut_file_name_basis_state);
		  
		  const string shell_qn_file_name_part = make_string<int> (n) + angular_state_for_file_name (l , j) + "_Berggren_basis_components.dat";

		  Vn.copy_disk (debut_file_name_basis_state_particle + shell_qn_file_name_part);
		}
	    }
	}	
    }
}




// OBMEs of different interaction one-body operators (H, nuclear part, kinetic part, Coulomb part) involving the new one-body basis above stored on disk here.
// -----------------------------------------------------------------------------------------------------------------------------------------------------------

void nucleons_data::OBMEs_inter_set_new_basis_calc_store (
							  const enum interaction_type inter ,
							  const class matrix<TYPE> &new_basis_change_matrix_all_lj) const
{
  if ((particle != PROTON) && (particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in nucleons_data::OBMEs_inter_set_new_basis_calc_store");

  const class array<TYPE> &OBMEs_H       = OBMEs_inter_set (inter);
  const class array<TYPE> &OBMEs_nuclear = OBMEs_inter_set (ONE_BODY_NUCLEAR);
  const class array<TYPE> &OBMEs_kinetic = OBMEs_inter_set (ONE_BODY_KINETIC);
  const class array<TYPE> &OBMEs_Coulomb = OBMEs_inter_set (ONE_BODY_COULOMB);

  class OBMEs_inter_set_str OBMEs_inter_set_new_basis;

  if (is_it_M_scheme)
    OBMEs_inter_set_new_basis.allocate (N_nlj , phi_table);
  else
    OBMEs_inter_set_new_basis.allocate (N_nlj);
    
  class array<TYPE> &OBMEs_H_new_basis       = OBMEs_inter_set_new_basis (inter);
  class array<TYPE> &OBMEs_nuclear_new_basis = OBMEs_inter_set_new_basis (ONE_BODY_NUCLEAR);
  class array<TYPE> &OBMEs_kinetic_new_basis = OBMEs_inter_set_new_basis (ONE_BODY_KINETIC);
  class array<TYPE> &OBMEs_Coulomb_new_basis = OBMEs_inter_set_new_basis (ONE_BODY_COULOMB);
  
  similarity_transformation_with_arrays (OBMEs_H       , new_basis_change_matrix_all_lj , OBMEs_H_new_basis);
  similarity_transformation_with_arrays (OBMEs_nuclear , new_basis_change_matrix_all_lj , OBMEs_nuclear_new_basis);
  similarity_transformation_with_arrays (OBMEs_kinetic , new_basis_change_matrix_all_lj , OBMEs_kinetic_new_basis);
  similarity_transformation_with_arrays (OBMEs_Coulomb , new_basis_change_matrix_all_lj , OBMEs_Coulomb_new_basis);
  
  const string debut_file_name_coupled_OBMEs = debut_file_name + "_" + make_string<enum particle_type> (particle) + "_coupled_OBMEs_";

  OBMEs_inter_set_new_basis.copy_disk (inter , debut_file_name_coupled_OBMEs);
}






// OBMEs of different one-body center-of-mass operators (Hcm, P^2/2M, L^(1), A+[CM-HO], rms radii) involving the new one-body basis above stored on disk here.
// -----------------------------------------------------------------------------------------------------------------------------------------------------------

void nucleons_data::OBMEs_CM_set_new_basis_calc_store (
						       const bool is_it_HO_expansion , 
						       const class matrix<TYPE> &new_basis_change_matrix_all_lj) const
{
  if ((particle != PROTON) && (particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in nucleons_data::OBMEs_CM_set_new_basis_calc_store");

  const class OBMEs_CM_set_str &OBMEs_CM_set = (is_it_HO_expansion) ? (OBMEs_CM_set_HO_expansion) : (OBMEs_CM_set_R_cut);

  const class array<TYPE> &OBMEs_Hcm                           = OBMEs_CM_set (HCM);
  const class array<TYPE> &OBMEs_CM_kinetic                    = OBMEs_CM_set (CM_KINETIC);
  const class array<TYPE> &OBMEs_L_reduced_tensor              = OBMEs_CM_set (L_REDUCED_TENSOR);
  const class array<TYPE> &OBMEs_A_dagger_CM_HO_reduced_tensor = OBMEs_CM_set (A_DAGGER_CM_HO_REDUCED_TENSOR);
  const class array<TYPE> &OBMEs_rms_radius_proton             = OBMEs_CM_set (RMS_RADIUS_PROTON);
  const class array<TYPE> &OBMEs_rms_radius_neutron            = OBMEs_CM_set (RMS_RADIUS_NEUTRON);

  class OBMEs_CM_set_str OBMEs_CM_set_new_basis;

  if (is_it_M_scheme)
    OBMEs_CM_set_new_basis.allocate (N_nlj , phi_table);
  else
    OBMEs_CM_set_new_basis.allocate (N_nlj);

  class array<TYPE> &OBMEs_Hcm_new_basis                           = OBMEs_CM_set_new_basis (HCM);
  class array<TYPE> &OBMEs_CM_kinetic_new_basis                    = OBMEs_CM_set_new_basis (CM_KINETIC);
  class array<TYPE> &OBMEs_L_reduced_tensor_new_basis              = OBMEs_CM_set_new_basis (L_REDUCED_TENSOR);
  class array<TYPE> &OBMEs_A_dagger_CM_HO_reduced_tensor_new_basis = OBMEs_CM_set_new_basis (A_DAGGER_CM_HO_REDUCED_TENSOR);
  class array<TYPE> &OBMEs_rms_radius_proton_new_basis             = OBMEs_CM_set_new_basis (RMS_RADIUS_PROTON);
  class array<TYPE> &OBMEs_rms_radius_neutron_new_basis            = OBMEs_CM_set_new_basis (RMS_RADIUS_NEUTRON);

  similarity_transformation_with_arrays (OBMEs_Hcm                           , new_basis_change_matrix_all_lj , OBMEs_Hcm_new_basis);
  similarity_transformation_with_arrays (OBMEs_CM_kinetic                    , new_basis_change_matrix_all_lj , OBMEs_CM_kinetic_new_basis);
  similarity_transformation_with_arrays (OBMEs_L_reduced_tensor              , new_basis_change_matrix_all_lj , OBMEs_L_reduced_tensor_new_basis);
  similarity_transformation_with_arrays (OBMEs_A_dagger_CM_HO_reduced_tensor , new_basis_change_matrix_all_lj , OBMEs_A_dagger_CM_HO_reduced_tensor_new_basis);
  similarity_transformation_with_arrays (OBMEs_rms_radius_proton             , new_basis_change_matrix_all_lj , OBMEs_rms_radius_proton_new_basis);
  similarity_transformation_with_arrays (OBMEs_rms_radius_neutron            , new_basis_change_matrix_all_lj , OBMEs_rms_radius_neutron_new_basis);

  const string debut_file_name_coupled_OBMEs = debut_file_name + "_" + make_string<enum particle_type> (particle) + "_coupled_OBMEs_";

  OBMEs_CM_set_new_basis.copy_disk (is_it_HO_expansion , debut_file_name_coupled_OBMEs);
}







// OBMEs of different interaction one-body operators (H, nuclear part, kinetic part, Coulomb part) and one-body center-of-mass operators (Hcm, P^2/2M, L^(1), A+[CM-HO], rms radii) involving the new one-body basis above stored on disk here.
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


void nucleons_data::OBMEs_inter_CM_sets_new_basis_calc_store (
							      const enum interaction_type inter ,
							      const class lj_table<class matrix<TYPE> > &new_basis_change_matrices) const
{
  if (N_nlj == 0) return;
  
  if ((particle != PROTON) && (particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in nucleons_data::OBMEs_inter_CM_sets_new_basis_calc_store");

  class matrix<TYPE> new_basis_change_matrix_all_lj(N_nlj);

  new_basis_change_matrix_all_lj = 0.0;

  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(s);

      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();

      const double j = shell_qn.get_j ();

      for (unsigned int sp = 0 ; sp < N_nlj ; sp++)
	{
	  const class nlj_struct &shell_p_qn = shells_quantum_numbers(sp);

	  if (same_lj (shell_qn , shell_p_qn))
	    {
	      const class matrix<TYPE> &new_basis_change_matrix_lj = new_basis_change_matrices(l , j);

	      const int np = shell_p_qn.get_n ();

	      new_basis_change_matrix_all_lj(s , sp) = new_basis_change_matrix_lj(n , np);
	    }
	}
    }  
  
  OBMEs_inter_set_new_basis_calc_store (inter , new_basis_change_matrix_all_lj);

  OBMEs_CM_set_new_basis_calc_store (true  , new_basis_change_matrix_all_lj);
  OBMEs_CM_set_new_basis_calc_store (false , new_basis_change_matrix_all_lj);
}






















// Calculations of the largest possible number of proton/neutron Slater determinants of fixed angular momentum projection and parity accessible with [a+ a] or [a+ a+ a a] operators from a given proton/neutron Slater determinant
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

void nucleons_data::dimensions_1p1h_2p2h_space_BP_iM_fixed_max_calc_print (const bool is_there_cout_detailed)
{
  if ((particle != PROTON) && (particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in nucleons_data::dimensions_1p1h_2p2h_space_BP_iM_fixed_max_calc_print");

  const unsigned int N_nlj_positive_parity = N_nlj_fixed_parity_determine (0 , shells_quantum_numbers);
  const unsigned int N_nlj_negative_parity = N_nlj_fixed_parity_determine (1 , shells_quantum_numbers);

  const unsigned int N_nlj_fixed_parity_max = max (N_nlj_positive_parity , N_nlj_negative_parity);
  
  const unsigned int N_valence_pairs_number = (N_valence_nucleons*(N_valence_nucleons - 1))/2;
  
  const unsigned int N_pairs_number_BP_pair_iM_pair_fixed_max = (N_nljm*N_nlj_fixed_parity_max)/2;

  dimension_1p1h_space_BP_iM_fixed_max = N_nlj_fixed_parity_max*N_valence_nucleons;

  dimension_2p2h_space_BP_iM_fixed_max = (N_valence_nucleons >= 2) ? (N_valence_pairs_number*N_pairs_number_BP_pair_iM_pair_fixed_max + 1) : (0);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_it_M_scheme && is_there_cout_detailed)
    {
      cout << endl;
      cout << "Maximal number of 1p-1h excitations from a " << particle << " SD with parity and M fixed for inSD and outSD : " << dimension_1p1h_space_BP_iM_fixed_max << endl;
      cout << "Maximal number of 2p-2h excitations from a " << particle << " SD with parity and M fixed for inSD and outSD : " << dimension_2p2h_space_BP_iM_fixed_max << endl << endl;
    }
}






// Potential one-body arrays, values assoiated to the HO wave functions of the HO expansion of operators and energy truncation values copied from input_data or calculated
// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Arrays of potential parameters are copied from input_data.
// Quantum numbers of HO shells entering the HO expansion of operators, associated indices, as well as the number of HO shells and states are evaluated.
// HO wave functions are calculated as well and stored as one-body basis.
// Energy truncation values are calculated.

void nucleons_data::alloc_fill_one_body_data_tables_E_min_max_hw_HO_expansion (const class input_data_str &input_data)
{  
  for (unsigned int i = 0 ; i < 5 ; i++) 
    {
      V0_KKNN[i] = input_data.get_V0_KKNN(i);
      
      rho_KKNN[i] = input_data.get_rho_KKNN(i);
    }

  for (unsigned int i = 0 ; i < 3 ; i++) 
    {
      Vls_KKNN[i] = input_data.get_Vls_KKNN(i);
      
      rho_ls_KKNN[i] = input_data.get_rho_ls_KKNN(i);
    }

  if ((particle != PROTON) && (particle != NEUTRON)) error_message_print_abort ("Proton or neutron particle only in nucleons_data::alloc_fill_one_body_data_tables_E_min_max_hw_HO_expansion");

  if (particle == PROTON)
    {	
      d_core_potential_tab.allocate_fill   (input_data.get_prot_d_core_potential_tab ());
      R0_core_potential_tab.allocate_fill  (input_data.get_prot_R0_core_potential_tab ());
      Vo_core_potential_tab.allocate_fill  (input_data.get_prot_Vo_core_potential_tab ());
      Vso_core_potential_tab.allocate_fill (input_data.get_prot_Vso_core_potential_tab ());

      d_basis_core_potential_tab.allocate_fill   (input_data.get_prot_d_basis_core_potential_tab ());
      R0_basis_core_potential_tab.allocate_fill  (input_data.get_prot_R0_basis_core_potential_tab ());
      Vo_basis_core_potential_tab.allocate_fill  (input_data.get_prot_Vo_basis_core_potential_tab ());
      Vso_basis_core_potential_tab.allocate_fill (input_data.get_prot_Vso_basis_core_potential_tab ());

      d_basis_tab.allocate_fill   (input_data.get_prot_d_basis_tab ());
      R0_basis_tab.allocate_fill  (input_data.get_prot_R0_basis_tab ());
      Vo_basis_tab.allocate_fill  (input_data.get_prot_Vo_basis_tab ());
      Vso_basis_tab.allocate_fill (input_data.get_prot_Vso_basis_tab ());

      b_partial_waves.allocate (0.5 , lmax);
  
      b_partial_waves = input_data.get_prot_b_lab_partial_waves ();
      
      basis_potential_partial_waves.allocate (0.5 , lmax);
      
      basis_potential_partial_waves = input_data.get_prot_basis_potential_partial_waves ();
    }

  if (particle == NEUTRON)
    {	
      d_core_potential_tab.allocate_fill   (input_data.get_neut_d_core_potential_tab ());
      R0_core_potential_tab.allocate_fill  (input_data.get_neut_R0_core_potential_tab ());
      Vo_core_potential_tab.allocate_fill  (input_data.get_neut_Vo_core_potential_tab ());
      Vso_core_potential_tab.allocate_fill (input_data.get_neut_Vso_core_potential_tab ());

      d_basis_core_potential_tab.allocate_fill   (input_data.get_neut_d_basis_core_potential_tab ());
      R0_basis_core_potential_tab.allocate_fill  (input_data.get_neut_R0_basis_core_potential_tab ());
      Vo_basis_core_potential_tab.allocate_fill  (input_data.get_neut_Vo_basis_core_potential_tab ());
      Vso_basis_core_potential_tab.allocate_fill (input_data.get_neut_Vso_basis_core_potential_tab ());

      d_basis_tab.allocate_fill   (input_data.get_neut_d_basis_tab ());
      R0_basis_tab.allocate_fill  (input_data.get_neut_R0_basis_tab ());
      Vo_basis_tab.allocate_fill  (input_data.get_neut_Vo_basis_tab ());
      Vso_basis_tab.allocate_fill (input_data.get_neut_Vso_basis_tab ());

      b_partial_waves.allocate (0.5 , lmax);
  
      b_partial_waves = input_data.get_neut_b_lab_partial_waves ();
      
      basis_potential_partial_waves.allocate (0.5 , lmax);
      
      basis_potential_partial_waves = input_data.get_neut_basis_potential_partial_waves ();
    }

  const enum interaction_type inter = input_data.get_inter ();
  
  const bool is_it_COSM = is_it_COSM_determine (inter);

  const bool is_it_cluster_CM_HO_basis_calculation = input_data.get_is_it_cluster_CM_HO_basis_calculation ();

  const double mass_modif = (!is_it_COSM) ? (-nucleus_mass_basis) : (nucleus_mass_basis);

  if (is_it_cluster_CM_HO_basis_calculation)
    {
      n_scat_max = (particle == PROTON) ? (input_data.get_n_scat_max_p ()) : (input_data.get_n_scat_max_n ());

      n_holes_max = n_holes_max_pole_approximation = 0;

      const class array<class nlj_struct> &shells_quantum_numbers_input = (particle == PROTON) ? (input_data.get_prot_shells_quantum_numbers ()) : (input_data.get_neut_shells_quantum_numbers ());

      N_nlj_res  = (particle == PROTON) ? (input_data.get_Np_nlj_res ())  : (input_data.get_Nn_nlj_res ());
      N_nljm_res = (particle == PROTON) ? (input_data.get_Np_nljm_res ()) : (input_data.get_Nn_nljm_res ());

      N_nlj  = (particle == PROTON) ? (input_data.get_Np_nlj ())  : (input_data.get_Nn_nlj ());
      N_nljm = (particle == PROTON) ? (input_data.get_Np_nljm ()) : (input_data.get_Nn_nljm ());

      shells_quantum_numbers.allocate_fill (shells_quantum_numbers_input);
    }
  else
    {
      n_scat_max = n_holes_max = n_holes_max_pole_approximation =  0;

      const class array<int> &nmax_HO_lab_tab_input = input_data.get_nmax_HO_lab_tab ();

      class array<int> nmax_HO_lab_tab (lmax + 1);

      nmax_HO_lab_tab = 0;

      for (int l = 0 ; l <= lmax ; l++) nmax_HO_lab_tab(l) = nmax_HO_lab_tab_input(l);

      const unsigned int N_nlj_HO = N_nlj_calc (nmax_HO_lab_tab);

      N_nlj = N_nlj_res = N_nlj_HO;

      shells_quantum_numbers.allocate (N_nlj_HO);

      unsigned int index_nlj = 0;

      for (int l = 0 ; l <= lmax ; l++)
	for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	  {
	    const int n_max_l = nmax_HO_lab_tab (l);

	    for (int n = 0 ; n <= n_max_l ; n++)
	      {
		const int e_trunc = 2*n + l;

		shells_quantum_numbers(index_nlj++).initialize (true , false , false , false , false , true , false , false ,
								e_trunc , n , l , j , NO_SEGMENT , NADA , NADA , NADA , NADA , NADA , NADA , NADA , NADA);
	      }
	  }

      N_nljm = N_nljm_res = N_nljm_calc (lmax , nmax_HO_lab_tab);
    }

  if (N_nlj > 0) shells_quantum_numbers.quick_sort (0 , N_nlj - 1);

  shells.allocate (N_nlj);

  for (unsigned int i = 0 ; i < N_nlj ; i++)
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(i);

      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();

      const double j = shell_qn.get_j ();

      const double b = b_partial_waves(l , j);

      class spherical_state &shell_HO = shells(i);

      shell_HO.allocate (false , true , HO_POTENTIAL , A_basis , Z_charge_basis_potential , mass_modif , NADA ,
			 N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , Nk_momentum_GL , Nk_momentum_uniform ,
			 R , NADA , NADA , R_real_max , kmax_momentum , R_Fermi_momentum , true , particle , n , NADA , l , j , false , NADA , effective_mass_for_calc , 1.0 , 1.0);

      shell_HO.HO_wave_function (b);
    }

  fill_nljm_nlj_one_body_indices_alloc_calc ();

  dimensions_1p1h_2p2h_space_BP_iM_fixed_max_calc_print (false);
  
  E_min_hw = E_min_hw_pp_nn (N_valence_nucleons , shells_quantum_numbers);
  
  E_max_hw = input_data.get_E_relative_max_hw () + E_min_hw;

  E_max_hw_pole_approximation = input_data.get_E_relative_max_hw_pole_approximation () + E_min_hw;
}





// Linear momenta are calculated and stored form their associated energy
// ---------------------------------------------------------------------
// This arises for example with standard HO-SM, where energy is given first.

void nucleons_data::shells_quantum_numbers_k_fill_from_h ()
{
  const double kinetic_factor = kinetic_factor_calc (false , nucleus_mass , effective_mass_for_calc);

  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      class nlj_struct &shell_qn = shells_quantum_numbers(s);

      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();
      
      const double j = shell_qn.get_j ();

      const TYPE e = h_basis (n , l , j);

      const complex<double> k = sqrt_mod (kinetic_factor*e);

      shell_qn.initialize (
			   shell_qn.get_S_matrix_pole () ,
			   shell_qn.get_core_state () ,
			   shell_qn.get_frozen_state () ,
			   shell_qn.get_hole_state () ,
			   shell_qn.get_OCM_valence_state () ,
			   shell_qn.get_is_it_HO () ,
			   shell_qn.get_is_it_for_HF_gs () ,
			   shell_qn.get_is_it_natural_orbital () ,
			   shell_qn.get_e_trunc () ,
			   n , l , j ,
			   shell_qn.get_segment () ,
			   k ,
			   shell_qn.get_w () ,
			   shell_qn.get_C0 () ,
			   shell_qn.get_Cplus () ,
			   shell_qn.get_k_plus () ,
			   shell_qn.get_C0_plus () ,
			   shell_qn.get_k_minus () ,
			   shell_qn.get_C0_minus ());
    }
}





// Constants of nucleons_data are initialized here from the class nucleons_data of another nucleus
// -----------------------------------------------------------------------------------------------

void nucleons_data::initialize_constants_from_other_nucleus (
							     const bool is_core_suppressed , 
							     const int Z_new_nucleus , 
							     const int N_new_nucleus , 
							     const double nucleus_mass_new_nucleus , 
							     const class nucleons_data &data_other_nucleus)
{
  is_it_M_scheme = data_other_nucleus.is_it_M_scheme;
  
  particle = data_other_nucleus.particle;
  
  A_core = (is_core_suppressed) ? (0) : (data_other_nucleus.A_core);
  Z_core = (is_core_suppressed) ? (0) : (data_other_nucleus.Z_core);
  N_core = (is_core_suppressed) ? (0) : (data_other_nucleus.N_core);
  
  Z = Z_new_nucleus;
  N = N_new_nucleus;
  
  A = Z + N;
  
  Z_basis = data_other_nucleus.Z_basis;
  N_basis = data_other_nucleus.N_basis;
  
  A_basis = Z_basis + N_basis;

  hole_states_number = data_other_nucleus.hole_states_number;

  N_nucleons = (particle == PROTON) ? (Z) : (N);

  nucleus_mass = nucleus_mass_new_nucleus;

  effective_mass_for_calc = data_other_nucleus.effective_mass_for_calc;

  R_charge = data_other_nucleus.R_charge;
  
  basis_potential = data_other_nucleus.basis_potential;
  
  H_potential = data_other_nucleus.H_potential;
  
  neutron_basis_potential = data_other_nucleus.neutron_basis_potential;
  
  N_bef_R_GL = data_other_nucleus.N_bef_R_GL;
  N_aft_R_GL = data_other_nucleus.N_aft_R_GL;
  
  N_bef_R_uniform = data_other_nucleus.N_bef_R_uniform;
  N_aft_R_uniform = data_other_nucleus.N_aft_R_uniform;
  
  Nk_momentum_uniform = data_other_nucleus.Nk_momentum_uniform;
  Nk_momentum_GL  = data_other_nucleus.Nk_momentum_GL;
  
  is_it_OCM_HO_core = data_other_nucleus.is_it_OCM_HO_core;
  
  R_cut_function = data_other_nucleus.R_cut_function;
  d_cut_function = data_other_nucleus.d_cut_function;
  
  R = data_other_nucleus.R;

  step_bef_R_uniform = data_other_nucleus.step_bef_R_uniform;
  
  R_real_max = data_other_nucleus.R_real_max;
  
  step_momentum_uniform = data_other_nucleus.step_momentum_uniform;
  
  kmax_momentum = data_other_nucleus.kmax_momentum;

  R_Fermi_momentum = data_other_nucleus.R_Fermi_momentum;
  
  const unsigned int N_nucleons_core = (particle == PROTON) ? (Z_core) : (N_core);
  
  if (N_nucleons + hole_states_number < N_nucleons_core) return;

  if (N_nucleons == 0) return;

  is_Coulomb_Hamiltonian_here = data_other_nucleus.is_Coulomb_Hamiltonian_here;
  
  are_there_basis_natural_orbitals = data_other_nucleus.are_there_basis_natural_orbitals;

  are_there_new_natural_orbitals = data_other_nucleus.are_there_new_natural_orbitals;
  
  natural_orbitals_reference_states_number = data_other_nucleus.natural_orbitals_reference_states_number;
  
  N_valence_nucleons = N_nucleons - N_nucleons_core + hole_states_number;
  
  N_valence_nucleons_1h = (N_valence_nucleons >= 1) ? (N_valence_nucleons - 1) : (NO_VALENCE_NUCLEONS);
  N_valence_nucleons_2h = (N_valence_nucleons >= 2) ? (N_valence_nucleons - 2) : (NO_VALENCE_NUCLEONS);
 
  n_scat_max = min (data_other_nucleus.n_scat_max , make_int (N_valence_nucleons));
  
  n_holes_max = data_other_nucleus.n_holes_max;
  
  n_holes_max_pole_approximation = data_other_nucleus.n_holes_max_pole_approximation;  
  
  if ((particle == PROTON) && is_Coulomb_Hamiltonian_here) Z_charge = (N_valence_nucleons > 0) ? (Z_core + N_valence_nucleons - 1) : (Z_core);
  
  Z_charge_basis_potential = data_other_nucleus.Z_charge_basis_potential;

  N_valence_nucleons_basis = data_other_nucleus.N_valence_nucleons_basis;
  
  N_nljm = data_other_nucleus.N_nljm;
  
  N_nlj = data_other_nucleus.N_nlj;
  
  N_nlj_res = data_other_nucleus.N_nlj_res;

  N_nljm_res = data_other_nucleus.N_nljm_res;

  BPmin_global = data_other_nucleus.BPmin_global;
  BPmax_global = data_other_nucleus.BPmax_global;
  
  Jmin_global = data_other_nucleus.Jmin_global;
  Jmax_global = data_other_nucleus.Jmax_global;
  
  nmax = data_other_nucleus.nmax;
  lmax = data_other_nucleus.lmax;

  jmax = data_other_nucleus.jmax;

  m_min = data_other_nucleus.m_min;
  m_max = data_other_nucleus.m_max;
  
  m_max_minus_half = data_other_nucleus.m_max_minus_half;
  
  two_m_max = data_other_nucleus.two_m_max;

  four_m_max = data_other_nucleus.four_m_max;
  
  m_max_minus_m_min = data_other_nucleus.m_max_minus_m_min;

  effective_charge = data_other_nucleus.effective_charge;
}



// One-body arrays and energy truncation arrays copied from the class nucleons_data of another nucleus
// ----------------------------------------------------------------------------------------------------
// One considers here also wave functions, HF and HO overlaps arrays, but not natural orbital arrays.

void nucleons_data::alloc_copy_one_body_data_tables_E_min_max_hw (const class nucleons_data &data_other_nucleus)
{
  const unsigned int N_nucleons_core = (particle == PROTON) ? (Z_core) : (N_core); 

  if (N_nucleons + hole_states_number < N_nucleons_core) return;
  
  for (unsigned int i = 0 ; i < 5 ; i++)
    {
      V0_KKNN[i] = data_other_nucleus.V0_KKNN[i];

      rho_KKNN[i] = data_other_nucleus.rho_KKNN[i];
    }
  
  for (unsigned int i = 0 ; i < 3 ; i++)
    {
      Vls_KKNN[i] = data_other_nucleus.Vls_KKNN[i];

      rho_ls_KKNN[i] = data_other_nucleus.rho_ls_KKNN[i];
    }
  
  d_core_potential_tab.allocate_fill   (data_other_nucleus.d_core_potential_tab);
  R0_core_potential_tab.allocate_fill  (data_other_nucleus.R0_core_potential_tab);
  Vo_core_potential_tab.allocate_fill  (data_other_nucleus.Vo_core_potential_tab);
  Vso_core_potential_tab.allocate_fill (data_other_nucleus.Vso_core_potential_tab);

  d_basis_core_potential_tab.allocate_fill   (data_other_nucleus.d_basis_core_potential_tab);
  R0_basis_core_potential_tab.allocate_fill  (data_other_nucleus.R0_basis_core_potential_tab);
  Vo_basis_core_potential_tab.allocate_fill  (data_other_nucleus.Vo_basis_core_potential_tab);
  Vso_basis_core_potential_tab.allocate_fill (data_other_nucleus.Vso_basis_core_potential_tab);

  d_basis_tab.allocate_fill   (data_other_nucleus.d_basis_tab);
  R0_basis_tab.allocate_fill  (data_other_nucleus.R0_basis_tab);
  Vo_basis_tab.allocate_fill  (data_other_nucleus.Vo_basis_tab);
  Vso_basis_tab.allocate_fill (data_other_nucleus.Vso_basis_tab);

  OBMEs_CM_set_HO_expansion.allocate_fill (data_other_nucleus.OBMEs_CM_set_HO_expansion);

  OBMEs_CM_set_R_cut.allocate_fill (data_other_nucleus.OBMEs_CM_set_R_cut);
  
  reduced_grad_HO_expansion_set.allocate_fill (data_other_nucleus.reduced_grad_HO_expansion_set);
  
  reduced_r_HO_expansion_set.allocate_fill (data_other_nucleus.reduced_r_HO_expansion_set);

  reduced_r_HO_expansion_rms_radius_pn_set.allocate_fill (data_other_nucleus.reduced_r_HO_expansion_rms_radius_pn_set);
  
  reduced_grad_R_cut_set.allocate_fill (data_other_nucleus.reduced_grad_R_cut_set);
  
  reduced_r_R_cut_set.allocate_fill (data_other_nucleus.reduced_r_R_cut_set);

  reduced_r_R_cut_rms_radius_pn_set.allocate_fill (data_other_nucleus.reduced_r_R_cut_rms_radius_pn_set);

  OBMEs_multipole_square_HO_expansion.allocate_fill (data_other_nucleus.OBMEs_multipole_square_HO_expansion);
  
  OBMEs_multipole_square_R_cut.allocate_fill (data_other_nucleus.OBMEs_multipole_square_R_cut);
  
  OBMEs_multipole_reduced_HO_expansion.allocate_fill (data_other_nucleus.OBMEs_multipole_reduced_HO_expansion);
  
  OBMEs_multipole_reduced_R_cut.allocate_fill (data_other_nucleus.OBMEs_multipole_reduced_R_cut);
  
  OBMEs_inter_set.allocate_fill (data_other_nucleus.OBMEs_inter_set);

  nmax_lj_tab.allocate_fill (data_other_nucleus.nmax_lj_tab);

  nmin_lj_valence_tab.allocate_fill (data_other_nucleus.nmin_lj_valence_tab);
  
  is_it_valence_shell_tab.allocate_fill (data_other_nucleus.is_it_valence_shell_tab);
  
  Ueq_finite_range_tab_uniform.allocate_fill (data_other_nucleus.Ueq_finite_range_tab_uniform);
  
  source_tab_uniform.allocate_fill (data_other_nucleus.source_tab_uniform);
  
  OBMEs_HF_SGI_MSGI.allocate_fill (data_other_nucleus.OBMEs_HF_SGI_MSGI);

  shells_indices.allocate_fill (data_other_nucleus.shells_indices);

  one_body_indices.allocate_fill (data_other_nucleus.one_body_indices);

  if (particle == PROTON)
    {
      Ueq_finite_range_plus_tab_uniform.allocate_fill  (data_other_nucleus.Ueq_finite_range_plus_tab_uniform);
      Ueq_finite_range_minus_tab_uniform.allocate_fill (data_other_nucleus.Ueq_finite_range_minus_tab_uniform);
      
      source_plus_tab_uniform.allocate_fill  (data_other_nucleus.source_plus_tab_uniform);
      source_minus_tab_uniform.allocate_fill (data_other_nucleus.source_minus_tab_uniform);
    }

  b_partial_waves.allocate_fill (data_other_nucleus.b_partial_waves);
  
  basis_potential_partial_waves.allocate_fill (data_other_nucleus.basis_potential_partial_waves);
  
  h_basis.allocate_fill (data_other_nucleus.h_basis);

  TRS_nljm_indices.allocate_fill (data_other_nucleus.TRS_nljm_indices);

  phi_table.allocate_fill (data_other_nucleus.phi_table);
  
  initial_to_nljm_ordered_states.allocate_fill (data_other_nucleus.initial_to_nljm_ordered_states);
  
  nljm_ordered_to_initial_states.allocate_fill (data_other_nucleus.nljm_ordered_to_initial_states);

  shells_quantum_numbers.allocate_fill (data_other_nucleus.shells_quantum_numbers);

  shells.allocate_fill_object_elements (data_other_nucleus.shells);
  
  shells_plus.allocate_fill_object_elements (data_other_nucleus.shells_plus);
  shells_minus.allocate_fill_object_elements (data_other_nucleus.shells_minus);

  U_finite_range_HF_HO_basis_HO_expansion_part.allocate_fill_object_elements (data_other_nucleus.U_finite_range_HF_HO_basis_HO_expansion_part);

  HO_overlaps.allocate_fill_object_elements (data_other_nucleus.HO_overlaps);

  HO_overlaps_Fermi.allocate_fill_object_elements (data_other_nucleus.HO_overlaps_Fermi);
  
  GHF_overlaps.allocate_fill_object_elements (data_other_nucleus.GHF_overlaps);
  
  basis_PSI_quantum_numbers_tab.allocate_fill (data_other_nucleus.basis_PSI_quantum_numbers_tab);

  dimensions_1p1h_2p2h_space_BP_iM_fixed_max_calc_print (false);

  const unsigned int N_valence_nucleons_other_nucleus = data_other_nucleus.N_valence_nucleons;
  
  E_min_hw = E_min_hw_pp_nn (N_valence_nucleons , shells_quantum_numbers);
  
  const int E_min_hw_other_nucleus = E_min_hw_pp_nn (N_valence_nucleons_other_nucleus , shells_quantum_numbers);
  
  const int E_max_hw_other_nucleus = data_other_nucleus.E_max_hw;
  
  E_max_hw = E_max_hw_other_nucleus + E_min_hw - E_min_hw_other_nucleus;
}







// Arrays of quantum numbers of one-body states and many-body states at HF/MSDHF level allocated and filled here from input_data
// -----------------------------------------------------------------------------------------------------------------------------

void nucleons_data::optimized_partial_waves_data_alloc_fill (const class input_data_str &input_data)
{
  if ((particle != PROTON) && (particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in nucleons_data::optimized_partial_waves_data_alloc_fill");

  const int Z_basis = input_data.get_Z_basis ();
  const int N_basis = input_data.get_N_basis ();

  basis_PSI_quantum_numbers_tab.allocate (0.5 , lmax);

  const class lj_table<unsigned int> &prot_basis_BP_tab = input_data.get_prot_basis_BP_tab ();
  const class lj_table<unsigned int> &neut_basis_BP_tab = input_data.get_neut_basis_BP_tab ();

  const class lj_table<unsigned int> &basis_BP_tab = (particle == PROTON) ? (prot_basis_BP_tab) : (neut_basis_BP_tab);

  if (!basis_BP_tab.is_it_filled ()) return;

  const class lj_table<double> &prot_basis_J_tab = input_data.get_prot_basis_J_tab ();
  const class lj_table<double> &neut_basis_J_tab = input_data.get_neut_basis_J_tab ();

  const class lj_table<double> &basis_J_tab = (particle == PROTON) ? (prot_basis_J_tab) : (neut_basis_J_tab);

  if (!basis_J_tab.is_it_filled ()) return;

  for (int l = 0 ; l <= lmax ; l++)
    {
      const double jminus = (l > 0) ? (l - 0.5) : (NADA);

      const double jplus = l + 0.5;

      if (l > 0)
	{
	  const unsigned int BP_l_jminus = basis_BP_tab(l , jminus);

	  const double J_l_jminus = basis_J_tab(l , jminus);

	  if ((BP_l_jminus != 2) && (J_l_jminus > -0.1))
	    basis_PSI_quantum_numbers_tab (l , jminus).initialize (Z_basis , N_basis , BP_l_jminus , J_l_jminus , 0 , NADA , NADA , NADA , NADA , false);
	}

      const unsigned int BP_l_jplus = basis_BP_tab(l , jplus);

      const double J_l_jplus = basis_J_tab(l , jplus);

      if ((BP_l_jplus != 2) && (J_l_jplus > -0.1))
	basis_PSI_quantum_numbers_tab (l , jplus).initialize (Z_basis , N_basis , BP_l_jplus , J_l_jplus , 0 , NADA , NADA , NADA , NADA , false);
    }
}






// Arrays of HF/MSDHF potentials and OBMEs allocated and filled here from a class HF_nucleons_data 
// -----------------------------------------------------------------------------------------------
// One cannot use operator = , one has to use loops , as dimensions of tables in HF_data and particles_data are different.

void nucleons_data::HF_potentials_quantum_numbers_OBMEs_write (
							       const enum interaction_type TBME_inter , 
							       const class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj_small = min (HF_data.get_N_nlj () , N_nlj);
  
  if (N_nlj_small == 0) return;

  if ((particle != PROTON) && (particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in nucleons_data::HF_potentials_quantum_numbers_OBMEs_write");

  const int nmax_small = min (HF_data.get_nmax () , nmax);
  const int lmax_small = min (HF_data.get_lmax () , lmax);
  
  const class nlj_table<complex<double> > &HF_Ueq_finite_range_averaged_tab_uniform = HF_data.get_Ueq_finite_range_averaged_tab_uniform ();

  const class nlj_table<complex<double> > &HF_source_averaged_tab_uniform = HF_data.get_source_averaged_tab_uniform ();

  const class lj_table<class matrix<complex<double> > > &U_finite_range_HF_HO_basis_HO_expansion_part_copy = HF_data.get_U_finite_range_HF_HO_basis_HO_expansion_part ();  

  const class array<class nlj_struct> &HF_shells_quantum_numbers = HF_data.get_shells_quantum_numbers ();
  
  class nlj_table<int> e_trunc_tab(0.5 , nmax_small , lmax_small);

  for (unsigned int s = 0 ; s < N_nlj_small ; s++) 
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(s);

      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();

      const double j = shell_qn.get_j ();

      e_trunc_tab(n , l , j) = shell_qn.get_e_trunc ();
    }
  
  for (unsigned int s_HF = 0 ; s_HF < N_nlj_small ; s_HF++) 
    {
      const class nlj_struct &HF_shell_qn = HF_shells_quantum_numbers(s_HF);
      
      const int n_HF = HF_shell_qn.get_n ();
      const int l_HF = HF_shell_qn.get_l ();

      const double j_HF = HF_shell_qn.get_j ();

      for (unsigned int s = 0 ; s < N_nlj_small ; s++) 
	{
	  class nlj_struct &shell_qn = shells_quantum_numbers(s);

	  const int n = shell_qn.get_n ();
	  const int l = shell_qn.get_l ();

	  const double j = shell_qn.get_j ();

	  if (same_nlj (n_HF , l_HF , j_HF , n , l , j))
	    {
	      const int e_trunc = e_trunc_tab(n , l , j);

	      shell_qn.initialize (
				   HF_shell_qn.get_S_matrix_pole () ,
				   HF_shell_qn.get_core_state () ,
				   HF_shell_qn.get_frozen_state () ,
				   HF_shell_qn.get_hole_state () ,
				   HF_shell_qn.get_OCM_valence_state () ,
				   HF_shell_qn.get_is_it_HO () ,
				   HF_shell_qn.get_is_it_for_HF_gs () ,
				   HF_shell_qn.get_is_it_natural_orbital () ,
				   e_trunc ,
				   HF_shell_qn.get_n () ,
				   HF_shell_qn.get_l () ,
				   HF_shell_qn.get_j () ,
				   HF_shell_qn.get_segment () ,
				   HF_shell_qn.get_k () ,
				   HF_shell_qn.get_w () ,
				   HF_shell_qn.get_C0 () ,
				   HF_shell_qn.get_Cplus () ,
				   HF_shell_qn.get_k_plus () ,
				   HF_shell_qn.get_C0_plus () ,
				   HF_shell_qn.get_k_minus () ,
				   HF_shell_qn.get_C0_minus ());
	    }
	}
    }
  
  for (int n = 0 ; n <= nmax_small ; n++)
    for (int l = 0 ; l <= lmax_small ; l++)
      for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	  {
	    Ueq_finite_range_tab_uniform(n , l , j , i) = HF_Ueq_finite_range_averaged_tab_uniform(n , l , j , i);
	    
	    source_tab_uniform(n , l , j , i) = HF_source_averaged_tab_uniform(n , l , j , i);
	  }

  for (int l = 0 ; l <= lmax_small ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	const class matrix<complex<double> > &U_finite_range_HF_HO_basis_HO_expansion_part_lj_copy = U_finite_range_HF_HO_basis_HO_expansion_part_copy(l , j);
	
	class matrix<complex<double> > &U_finite_range_HF_HO_basis_HO_expansion_part_lj = U_finite_range_HF_HO_basis_HO_expansion_part(l , j);

	U_finite_range_HF_HO_basis_HO_expansion_part_lj = U_finite_range_HF_HO_basis_HO_expansion_part_lj_copy;
      }

  const bool is_it_SGI  = is_it_SGI_determine  (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  if (is_it_SGI || is_it_MSGI)
    {
      const class lj_table<complex<double> > &OBMEs_HF_SGI_MSGI_copy = HF_data.get_OBMEs_HF_SGI_MSGI ();

      for (int l = 0 ; l <= lmax_small ; l++)
	for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	  for (int n = 0 ; n <= nmax_small ; n++)
	    for (int np = 0 ; np <= nmax_small ; np++)
	      OBMEs_HF_SGI_MSGI(l , j , n , np) = OBMEs_HF_SGI_MSGI_copy(l , j , n , np);
    }

  if (particle == PROTON)
    { 
      const class nlj_table<complex<double> > &HF_Ueq_finite_range_plus_averaged_tab_uniform  = HF_data.get_Ueq_finite_range_plus_averaged_tab_uniform ();
      const class nlj_table<complex<double> > &HF_Ueq_finite_range_minus_averaged_tab_uniform = HF_data.get_Ueq_finite_range_minus_averaged_tab_uniform ();
      
      const class nlj_table<complex<double> > &HF_source_plus_averaged_tab_uniform  = HF_data.get_source_plus_averaged_tab_uniform ();
      const class nlj_table<complex<double> > &HF_source_minus_averaged_tab_uniform = HF_data.get_source_minus_averaged_tab_uniform ();

      for (int n = 0 ; n <= nmax_small ; n++)
	for (int l = 0 ; l <= lmax_small ; l++)
	  for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	    for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	      {
		Ueq_finite_range_plus_tab_uniform (n , l , j , i) = HF_Ueq_finite_range_plus_averaged_tab_uniform (n , l , j , i);
		Ueq_finite_range_minus_tab_uniform(n , l , j , i) = HF_Ueq_finite_range_minus_averaged_tab_uniform(n , l , j , i);

		source_plus_tab_uniform (n , l , j , i) = HF_source_plus_averaged_tab_uniform (n , l , j , i);
		source_minus_tab_uniform(n , l , j , i) = HF_source_minus_averaged_tab_uniform(n , l , j , i);
	      }
    }
}





// Constants and arrays calculated in HF_data or found in input_data, inter_data or another class nucleons_data are copied here to constants and arrays after allocation
// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

void nucleons_data::data_MSDHF_one_configuration_one_body_alloc_fill (
								      const class input_data_str &input_data , 
								      const class interaction_class &inter_data ,
								      const class nucleons_data &data ,  
								      const class HF_nucleons_data &HF_data)
{
  if (is_it_filled ()) error_message_print_abort ("nucleons_data cannot be allocated twice in nucleons_data::data_MSDHF_one_configuration_one_body_alloc_fill");

  is_it_M_scheme = data.is_it_M_scheme;
  
  particle = data.particle;
  
  if ((particle != PROTON) && (particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in nucleons_data::data_MSDHF_one_configuration_one_body_alloc_fill");

  n_scat_max = 0;
  
  n_holes_max = data.n_holes_max;
  
  n_holes_max_pole_approximation = data.n_holes_max_pole_approximation;
  
  A = data.A_basis;
  
  A_basis = data.A_basis;
  
  A_core = data.A_core;
  Z_core = data.Z_core;
  
  Z = data.Z;
  N = data.N;
  
  hole_states_number = data.hole_states_number;

  N_nucleons = data.N_nucleons;
  
  N_valence_nucleons = data.N_valence_nucleons_basis;
  
  N_valence_nucleons_1h = (N_valence_nucleons >= 1) ? (N_valence_nucleons - 1) : (NO_VALENCE_NUCLEONS);
  N_valence_nucleons_2h = (N_valence_nucleons >= 2) ? (N_valence_nucleons - 2) : (NO_VALENCE_NUCLEONS);
 
  N_valence_nucleons_basis = data.N_valence_nucleons_basis;
  
  nucleus_mass = data.nucleus_mass;
  nucleus_mass_basis = data.nucleus_mass_basis;
  
  Z_charge_basis_potential = data.Z_charge_basis_potential;
  
  N_nljm = data.N_nljm_res;

  N_nlj = data.N_nlj_res;

  N_nljm_res = data.N_nljm_res;

  N_nlj_res = data.N_nlj_res;

  effective_mass_for_calc = data.effective_mass_for_calc;
  
  R_charge = data.R_charge;
  
  basis_potential = data.basis_potential;
  
  H_potential = data.H_potential;
  
  neutron_basis_potential = data.neutron_basis_potential;
  
  N_bef_R_GL = data.N_bef_R_GL;
  N_aft_R_GL = data.N_aft_R_GL;
  
  N_bef_R_uniform = data.N_bef_R_uniform;
  N_aft_R_uniform = data.N_aft_R_uniform;
  
  Nk_momentum_uniform = data.Nk_momentum_uniform;
  Nk_momentum_GL  = data.Nk_momentum_GL;
  
  R = data.R;

  step_bef_R_uniform = data.step_bef_R_uniform;

  R_real_max = data.R_real_max;

  step_momentum_uniform = data.step_momentum_uniform;
  
  kmax_momentum = data.kmax_momentum; 

  R_Fermi_momentum = data.R_Fermi_momentum; 
  
  BPmin_global = data.BPmin_global;
  BPmax_global = data.BPmax_global;
  
  Jmin_global = data.Jmin_global;
  Jmax_global = data.Jmax_global;
  
  is_it_OCM_HO_core = data.is_it_OCM_HO_core;
  
  R_cut_function = data.R_cut_function;
  d_cut_function = data.d_cut_function;

  const double *const data_V0_KKNN = data.V0_KKNN;

  const double *const data_rho_KKNN = data.rho_KKNN;

  const double *const data_Vls_KKNN = data.Vls_KKNN;

  const double *const data_rho_ls_KKNN = data.rho_ls_KKNN;

  for (unsigned int i = 0 ; i < 5 ; i++)
    {
      V0_KKNN[i] = data_V0_KKNN[i];

      rho_KKNN[i] = data_rho_KKNN[i];
    }

  for (unsigned int i = 0 ; i < 3 ; i++)
    {
      Vls_KKNN[i] = data_Vls_KKNN[i];

      rho_ls_KKNN[i] = data_rho_ls_KKNN[i];
    }
  
  d_core_potential_tab.allocate_fill   (data.d_basis_core_potential_tab);
  R0_core_potential_tab.allocate_fill  (data.R0_basis_core_potential_tab);
  Vo_core_potential_tab.allocate_fill  (data.Vo_basis_core_potential_tab);
  Vso_core_potential_tab.allocate_fill (data.Vso_basis_core_potential_tab);

  d_basis_core_potential_tab.allocate_fill   (data.d_basis_core_potential_tab);
  R0_basis_core_potential_tab.allocate_fill  (data.R0_basis_core_potential_tab);
  Vo_basis_core_potential_tab.allocate_fill  (data.Vo_basis_core_potential_tab);
  Vso_basis_core_potential_tab.allocate_fill (data.Vso_basis_core_potential_tab);

  d_basis_tab.allocate_fill   (data.d_basis_tab);
  R0_basis_tab.allocate_fill  (data.R0_basis_tab);
  Vo_basis_tab.allocate_fill  (data.Vo_basis_tab);
  Vso_basis_tab.allocate_fill (data.Vso_basis_tab);

  b_partial_waves.allocate_fill (data.b_partial_waves);

  basis_PSI_quantum_numbers_tab.allocate_fill (data.basis_PSI_quantum_numbers_tab);

  basis_potential_partial_waves.allocate_fill (data.basis_potential_partial_waves);

  if (N_valence_nucleons == 0) return;
  
  const class array<int> &nmax_HO_lab_tab = inter_data.get_nmax_HO_lab_tab ();

  const class array<class spherical_state> &HF_shells_res = HF_data.get_shells_res ();

  shells.allocate (N_nlj_res);

  nmax = 0;
  lmax = 0;
  jmax = 0;

  m_max = 0;

  for (unsigned int s = 0 ; s < N_nlj_res ; s++)    
    {
      const class spherical_state &HF_shell_res = HF_shells_res(s);

      if (HF_shell_res.is_it_filled ())
	{
	  const int n = HF_shell_res.get_n ();
	  const int l = HF_shell_res.get_l ();

	  const double j = HF_shell_res.get_j ();

	  nmax = max (nmax , n);
	  lmax = max (lmax , l);
	  jmax = max (jmax , j);

	  m_max = max (m_max , j);

	  shells(s).allocate_fill (HF_shell_res);
	}
    }

  m_min = -m_max;

  m_max_minus_half = make_int (m_max - 0.5);
  
  two_m_max = make_int (2.0*m_max);
  
  four_m_max = make_int (4.0*m_max);

  m_max_minus_m_min = make_int (m_max - m_min);

  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  Ueq_finite_range_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);

  source_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);

  if (is_it_SGI_MSGI) OBMEs_HF_SGI_MSGI.allocate (0.5 , lmax , nmax+1 , nmax+1);

  U_finite_range_HF_HO_basis_HO_expansion_part.allocate (0.5 , lmax);

  shells_quantum_numbers.allocate (N_nlj_res);

  const class array<class nlj_struct> &HF_shells_res_qn = HF_data.get_shells_quantum_numbers_res ();

  for (unsigned int s = 0 ; s < N_nlj_res ; s++) shells_quantum_numbers(s) = HF_shells_res_qn(s); 

  const int lmax_for_interaction = inter_data.get_lmax_for_interaction ();

  for (int l = 0 ; l <= lmax ; l++)
    {
      const int nmax_HO_l = (l <= lmax_for_interaction) ? (nmax_HO_lab_tab(l)) : (0);
      
      for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	U_finite_range_HF_HO_basis_HO_expansion_part(l , j).allocate (nmax_HO_l + 1);
    }

  if (particle == PROTON)
    {
      Ueq_finite_range_plus_tab_uniform.allocate  (0.5 , nmax , lmax , N_bef_R_uniform);
      Ueq_finite_range_minus_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);
      
      source_plus_tab_uniform.allocate  (0.5 , nmax , lmax , N_bef_R_uniform);
      source_minus_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);
    }

  dimensions_1p1h_2p2h_space_BP_iM_fixed_max_calc_print (false);

  HF_potentials_quantum_numbers_OBMEs_write (TBME_inter , HF_data);

  fill_nljm_nlj_one_body_indices_alloc_calc ();

  all_HO_GHF_overlaps_alloc_calc (input_data);
  
  E_min_hw = E_min_hw_pp_nn (N_valence_nucleons , shells_quantum_numbers);
    
  E_max_hw = E_max_hw_pole_approximation = E_min_hw + 1;

  effective_charge = data.effective_charge;
}






// Initialization and/or reallocation and reinitialization of given data to fixed values
// -------------------------------------------------------------------------------------

void nucleons_data::set_BP_iC_one_configuration (const unsigned int BP , const unsigned int iC)
{
  BP_one_configuration = BP;
  iC_one_configuration = iC;
}

void nucleons_data::is_it_OCM_HO_core_determine_test ()
{
  is_it_OCM_HO_core = true;

  for (unsigned int s = 0 ; s < N_nlj ; s++) 
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(s);

      const bool core_state = shell_qn.get_core_state ();

      const bool is_it_HO = shell_qn.get_is_it_HO ();

      if (core_state && !is_it_HO) is_it_OCM_HO_core = false;

      if (!is_it_OCM_HO_core && core_state && is_it_HO)
	error_message_print_abort ("All " + make_string<enum particle_type> (particle) + " core states must be HO , or none of them can be.");
    }
}

void nucleons_data::is_it_OCM_HO_core_impose_pp_nn (
						    const class input_data_str &input_data ,
						    const class nucleons_data &other_data)
{
  const enum space_type basis_space = input_data.get_basis_space ();

  if (((basis_space == PROTONS_ONLY) && (particle == NEUTRON)) || ((basis_space == NEUTRONS_ONLY) && (particle == PROTON)))
    is_it_OCM_HO_core = other_data.is_it_OCM_HO_core;
}

void nucleons_data::set_N_nlj_N_nlj_res_shells_quantum_numbers_realloc_fill (
									     const unsigned int N_nlj_res_c ,
									     const unsigned int N_nlj_c ,
									     const class array<class nlj_struct> &shells_quantum_numbers_c)
{
  N_nlj_res = N_nlj_res_c;

  N_nlj = N_nlj_c;

  shells_quantum_numbers.deallocate ();
  
  shells_quantum_numbers.allocate_fill (shells_quantum_numbers_c);
}






// Initialization to fixed or simple values of boolean and indices arrays associated to configurations and/or Slater determinants
// ------------------------------------------------------------------------------------------------------------------------------

void nucleons_data::inSD_in_space_tab_Jpm_init (const bool init_bool)
{
  is_inSD_in_space_tab_Jpm = init_bool;
}

void nucleons_data::configuration_SD_in_in_space_BPin_iMin_tables_init (const bool init_bool)
{
  BPin_for_one_jump_tab = init_bool;
  
  BPin_iMin_for_one_jump_tab = init_bool;

  is_configuration_in_in_space_tabs[0] = init_bool;
  is_configuration_in_in_space_tabs[1] = init_bool;
  
  is_inSD_in_space_tabs[0] = init_bool;
  is_inSD_in_space_tabs[1] = init_bool;
}

void nucleons_data::configuration_SD_in_in_space_iC_min_max_tables_init (
									 const unsigned int occupied_squares_index ,
									 const bool init_bool)
{  
  class array<unsigned int> &iC_in_min_tab_squares = iC_in_min_tab[occupied_squares_index];
  class array<unsigned int> &iC_in_max_tab_squares = iC_in_max_tab[occupied_squares_index];
      
  is_configuration_in_in_space_tabs[occupied_squares_index] = init_bool;
  
  is_inSD_in_space_tabs[occupied_squares_index] = init_bool;

  iC_in_min_tab_squares = dimension_configuration_max;
  
  iC_in_max_tab_squares = 0;
      
  if (init_bool)
    {  
      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
	{
	  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
	    {
	      const unsigned int dimension_C = dimensions_configuration_set(BP , n_scat);

	      if (dimension_C > 0)
		{
		  iC_in_min_tab_squares(BP , n_scat) = 0;
		  
		  iC_in_max_tab_squares(BP , n_scat) = dimension_C - 1;
		}
	    }
	}
    }
}

void nucleons_data::configuration_SD_inter_to_include_tables_init (const bool init_bool)
{
  is_it_configuration_inter_to_include_tab = init_bool;
  
  is_it_SD_inter_to_include_tab = init_bool;
}


void nucleons_data::configuration_SD_out_in_space_BPout_iMout_tables_init (const bool init_bool)
{
  BPout_for_one_jump_tab = init_bool;
  
  BPout_iMout_for_one_jump_tab = init_bool;

  is_configuration_out_in_space_tab = init_bool;
  
  is_outSD_in_space_tab = init_bool;
}

void nucleons_data::configuration_SD_out_in_space_iC_min_max_tables_init (const bool init_bool)
{
  is_configuration_out_in_space_tab = init_bool;
  
  is_outSD_in_space_tab = init_bool;
  
  iC_out_min_tab = dimension_configuration_max;
  
  iC_out_max_tab = 0;
  
  if (init_bool)
    {
      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
	{
	  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
	    {
	      const unsigned int dimension_C = dimensions_configuration_set(BP , n_scat);

	      if (dimension_C > 0)
		{
		  iC_out_min_tab(BP , n_scat) = 0;
		  
		  iC_out_max_tab(BP , n_scat) = dimension_C - 1;
		}
	    }
	}
    }
}













// One checks whether basis and core potentials are the same or not
// ----------------------------------------------------------------

bool are_core_basis_potentials_equal (
				      const int l ,
				      const class nucleons_data &data)
{
  const bool is_it_OCM_HO_core = data.get_is_it_OCM_HO_core ();

  if (is_it_OCM_HO_core) return false;

  const class array<double> &d_tab   = data.get_d_core_potential_tab ();
  const class array<double> &R0_tab  = data.get_R0_core_potential_tab ();
  const class array<double> &Vo_tab  = data.get_Vo_core_potential_tab ();
  const class array<double> &Vso_tab = data.get_Vso_core_potential_tab ();

  const class array<double> &d_basis_tab   = data.get_d_basis_tab ();
  const class array<double> &R0_basis_tab  = data.get_R0_basis_tab ();
  const class array<double> &Vo_basis_tab  = data.get_Vo_basis_tab ();
  const class array<double> &Vso_basis_tab = data.get_Vso_basis_tab ();

  const double d   = d_tab   (l);
  const double R0  = R0_tab  (l);
  const double Vo  = Vo_tab  (l);
  const double Vso = Vso_tab (l);

  const double d_basis   = d_basis_tab   (l);
  const double R0_basis  = R0_basis_tab  (l);
  const double Vo_basis  = Vo_basis_tab  (l);
  const double Vso_basis = Vso_basis_tab (l);

  if (abs (d   -   d_basis) > precision) return false;
  if (abs (R0  -  R0_basis) > precision) return false;
  if (abs (Vo  -  Vo_basis) > precision) return false;
  if (abs (Vso - Vso_basis) > precision) return false;

  return true;
}



// Constants and arrays of proton and/or neutron types allocated and filled here, as well as the HO character or not of core shells with COSM
// ------------------------------------------------------------------------------------------------------------------------------------------

void nucleons_data_initialization (
				   const bool is_it_M_scheme ,
				   const class input_data_str &input_data ,
				   class nucleons_data &prot_data ,
				   class nucleons_data &neut_data)
{
  prot_data.initialize_constants (is_it_M_scheme , PROTON  , input_data);
  neut_data.initialize_constants (is_it_M_scheme , NEUTRON , input_data);
  
  prot_data.alloc_fill_one_body_data_tables_E_min_max_hw (input_data);
  neut_data.alloc_fill_one_body_data_tables_E_min_max_hw (input_data);
  
  is_it_OCM_HO_core_determine (input_data , prot_data , neut_data);
}



// Constants and arrays of two-body systems defined with relative coordinates allocated and filled here
// ----------------------------------------------------------------------------------------------------

void relative_data_initialization (
				   const class input_data_str &input_data ,
				   class nucleons_data &relative_data)
{
  const enum particle_type relative_cluster = input_data.get_relative_cluster ();

  if (!is_it_two_nucleon_ST_cluster_determine (relative_cluster)) error_message_print_abort ("Two-nucleon ST clusters only in relative_data_initialization");

  relative_data.initialize_constants (false , relative_cluster , input_data);
  
  relative_data.alloc_fill_one_body_data_tables_E_min_max_hw (input_data);
}



double used_memory_calc (const class nucleons_data &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.basis_potential_partial_waves) + used_memory_calc (T.TRS_nljm_indices) + used_memory_calc (T.dimensions_configuration_set) + used_memory_calc (T.dimensions_configuration_set_1h) + used_memory_calc (T.dimensions_configuration_set_2h) + used_memory_calc (T.sum_dimensions_configuration_set) + used_memory_calc (T.sum_dimensions_configuration_set_1h) +  used_memory_calc (T.sum_dimensions_configuration_set_2h) + used_memory_calc (T.configuration_set) + used_memory_calc (T.configuration_set_1h) + used_memory_calc (T.configuration_set_2h) + used_memory_calc (T.dimensions_SD_set) + used_memory_calc (T.dimensions_SD_set_1h) + used_memory_calc (T.dimensions_SD_set_2h) + used_memory_calc (T.sum_dimensions_SD_set) + used_memory_calc (T.sum_dimensions_SD_set_1h) + used_memory_calc (T.sum_dimensions_SD_set_2h) + used_memory_calc (T.SD_set) + used_memory_calc (T.SD_set_1h) + used_memory_calc (T.SD_set_2h) + used_memory_calc (T.E_hw_table) + used_memory_calc (T.n_holes_table) + used_memory_calc (T.OBMEs_CM_set_HO_expansion) + used_memory_calc (T.OBMEs_CM_set_R_cut) + used_memory_calc (T.reduced_grad_HO_expansion_set) + used_memory_calc (T.reduced_r_HO_expansion_set) + used_memory_calc (T.reduced_r_HO_expansion_rms_radius_pn_set) + used_memory_calc (T.reduced_grad_R_cut_set) + used_memory_calc (T.reduced_r_R_cut_set) + used_memory_calc (T.reduced_r_R_cut_rms_radius_pn_set) + used_memory_calc (T.OBMEs_multipole_square_HO_expansion) + used_memory_calc (T.OBMEs_multipole_square_R_cut) + used_memory_calc (T.OBMEs_multipole_reduced_HO_expansion) + used_memory_calc (T.OBMEs_multipole_reduced_R_cut) + used_memory_calc (T.OBMEs_inter_set) + used_memory_calc (T.nmax_lj_tab) + used_memory_calc (T.shells_indices) + used_memory_calc (T.is_it_valence_shell_tab) + used_memory_calc (T.one_body_indices) + used_memory_calc (T.shells) + used_memory_calc (T.shells_plus) + used_memory_calc (T.shells_minus) + used_memory_calc (T.phi_table) + used_memory_calc (T.Ueq_finite_range_tab_uniform) + used_memory_calc (T.Ueq_finite_range_plus_tab_uniform) + used_memory_calc (T.Ueq_finite_range_minus_tab_uniform) + used_memory_calc (T.source_tab_uniform) + used_memory_calc (T.source_plus_tab_uniform) + used_memory_calc (T.source_minus_tab_uniform) + used_memory_calc (T.OBMEs_HF_SGI_MSGI) + used_memory_calc (T.h_basis) + used_memory_calc (T.TBMEs) + used_memory_calc (T.shells_quantum_numbers) + used_memory_calc (T.SD_TRS_indices) + used_memory_calc (T.SD_TRS_indices_1h) + used_memory_calc (T.SD_TRS_indices_2h) + used_memory_calc (T.SD_TRS_reordering_bin_phases) + used_memory_calc (T.SD_TRS_reordering_bin_phases_1h) + used_memory_calc (T.SD_TRS_reordering_bin_phases_2h) + used_memory_calc (T.SD_TRS_bin_phases) + used_memory_calc (T.SD_TRS_bin_phases_1h) + used_memory_calc (T.SD_TRS_bin_phases_2h) + used_memory_calc (T.dimensions_configuration_one_jump_table_in_to_out) + used_memory_calc (T.dimensions_configuration_one_jump_table_out_to_in) + used_memory_calc (T.configuration_one_jump_table_in_to_out) + used_memory_calc (T.configuration_one_jump_table_out_to_in) + used_memory_calc (T.dimensions_SD_one_jump_table_in_to_out) + used_memory_calc (T.dimensions_SD_one_jump_table_out_to_in) + used_memory_calc (T.dimensions_SD_one_jump_table_Jpm_in_to_out) + used_memory_calc (T.dimensions_SD_one_jump_table_Jpm_out_to_in) + used_memory_calc (T.SD_one_jump_table_in_to_out) + used_memory_calc (T.SD_one_jump_table_out_to_in) + used_memory_calc (T.SD_one_jump_table_Jpm_in_to_out) + used_memory_calc (T.SD_one_jump_table_Jpm_out_to_in) + used_memory_calc (T.are_configurations_inter_occupied_in_space_1ph_tables[0]) + used_memory_calc (T.are_configurations_inter_occupied_in_space_2ph_tables[0]) + used_memory_calc (T.dimensions_configuration_1p_tables[0]) + used_memory_calc (T.dimensions_configuration_1h_tables[0]) + used_memory_calc (T.dimensions_configuration_2p_tables[0]) + used_memory_calc (T.dimensions_configuration_2h_tables[0]) + used_memory_calc (T.configuration_1p_tables[0]) + used_memory_calc (T.configuration_1h_tables[0]) + used_memory_calc (T.configuration_2p_tables[0]) + used_memory_calc (T.configuration_2h_tables[0]) + used_memory_calc (T.are_configurations_inter_occupied_in_space_1ph_tables[1]) + used_memory_calc (T.are_configurations_inter_occupied_in_space_2ph_tables[1]) + used_memory_calc (T.dimensions_configuration_1p_tables[1]) + used_memory_calc (T.dimensions_configuration_1h_tables[1]) + used_memory_calc (T.dimensions_configuration_2p_tables[1]) + used_memory_calc (T.dimensions_configuration_2h_tables[1]) + used_memory_calc (T.configuration_1p_tables[1]) + used_memory_calc (T.configuration_1h_tables[1]) + used_memory_calc (T.configuration_2p_tables[1]) + used_memory_calc (T.configuration_2h_tables[1]) + used_memory_calc (T.dimensions_SD_1p_tables[0]) + used_memory_calc (T.dimensions_SD_1h_tables[0]) + used_memory_calc (T.dimensions_SD_2p_tables[0]) + used_memory_calc (T.dimensions_SD_2h_tables[0]) + used_memory_calc (T.SD_1p_tables[0]) + used_memory_calc (T.SD_1h_tables[0]) + used_memory_calc (T.SD_2p_tables[0]) + used_memory_calc (T.SD_2h_tables[0])+ used_memory_calc (T.dimensions_SD_1p_tables[1]) + used_memory_calc (T.dimensions_SD_1h_tables[1]) + used_memory_calc (T.dimensions_SD_2p_tables[1]) + used_memory_calc (T.dimensions_SD_2h_tables[1]) + used_memory_calc (T.SD_1p_tables[1]) + used_memory_calc (T.SD_1h_tables[1]) + used_memory_calc (T.SD_2p_tables[1]) + used_memory_calc (T.SD_2h_tables[1]) + used_memory_calc (T.U_finite_range_HF_HO_basis_HO_expansion_part) + used_memory_calc (T.HO_overlaps_basis) + used_memory_calc (T.HO_overlaps_basis_Fermi) + used_memory_calc (T.HO_overlaps) + used_memory_calc (T.HO_overlaps_Fermi) + used_memory_calc (T.GHF_overlaps) + used_memory_calc (T.d_core_potential_tab) + used_memory_calc (T.R0_core_potential_tab) + used_memory_calc (T.Vo_core_potential_tab) + used_memory_calc (T.Vso_core_potential_tab) + used_memory_calc (T.d_basis_core_potential_tab) + used_memory_calc (T.R0_basis_core_potential_tab) + used_memory_calc (T.Vo_basis_core_potential_tab) + used_memory_calc (T.Vso_basis_core_potential_tab) + used_memory_calc (T.d_basis_tab) + used_memory_calc (T.R0_basis_tab) + used_memory_calc (T.Vo_basis_tab) + used_memory_calc (T.Vso_basis_tab) + used_memory_calc (T.b_partial_waves) + used_memory_calc (T.basis_PSI_quantum_numbers_tab) + used_memory_calc (T.BPin_for_one_jump_tab) + used_memory_calc (T.BPout_for_one_jump_tab) + used_memory_calc (T.BPin_iMin_for_one_jump_tab) + used_memory_calc (T.BPout_iMout_for_one_jump_tab) + used_memory_calc (T.iC_in_min_tab[0]) + used_memory_calc (T.iC_in_min_tab[1]) + used_memory_calc (T.iC_in_max_tab[0]) + used_memory_calc (T.iC_in_max_tab[1]) + used_memory_calc (T.iC_out_min_tab) + used_memory_calc (T.iC_out_max_tab) + used_memory_calc (T.is_configuration_in_in_space_tabs[0]) + used_memory_calc (T.is_configuration_in_in_space_tabs[1]) + used_memory_calc (T.is_configuration_out_in_space_tab) + used_memory_calc (T.is_inSD_in_space_tab_Jpm) + used_memory_calc (T.is_inSD_in_space_tabs[0]) + used_memory_calc (T.is_inSD_in_space_tabs[1]) + used_memory_calc (T.is_outSD_in_space_tab) + used_memory_calc (T.is_it_configuration_inter_to_include_tab) + used_memory_calc (T.is_it_SD_inter_to_include_tab) + used_memory_calc (T.initial_to_nljm_ordered_states) + used_memory_calc (T.nljm_ordered_to_initial_states) + used_memory_calc (T.dimensions_SD_HO_Berggren_overlaps_table) + used_memory_calc (T.SD_HO_Berggren_overlaps_table) + used_memory_calc (T.scalar_density_matrices) + used_memory_calc (T.natural_orbitals_matrices) + used_memory_calc (T.ESPEs_Hamiltonian_matrices) + used_memory_calc (T.ESPEs_Hamiltonian_orbitals_matrices) + used_memory_calc (T.natural_orbitals_reference_states) + used_memory_calc (T.SD_quantum_numbers_tab) - (sizeof (T.basis_potential_partial_waves) + sizeof (T.TRS_nljm_indices) + sizeof (T.dimensions_configuration_set) + sizeof (T.dimensions_configuration_set_1h) + sizeof (T.dimensions_configuration_set_2h) + sizeof (T.sum_dimensions_configuration_set) + sizeof (T.sum_dimensions_configuration_set_1h) +  sizeof (T.sum_dimensions_configuration_set_2h) + sizeof (T.configuration_set) + sizeof (T.configuration_set_1h) + sizeof (T.configuration_set_2h) + sizeof (T.dimensions_SD_set) + sizeof (T.dimensions_SD_set_1h) + sizeof (T.dimensions_SD_set_2h) + sizeof (T.sum_dimensions_SD_set) + sizeof (T.sum_dimensions_SD_set_1h) + sizeof (T.sum_dimensions_SD_set_2h) + sizeof (T.SD_set) + sizeof (T.SD_set_1h) + sizeof (T.SD_set_2h) + sizeof (T.E_hw_table) + sizeof (T.n_holes_table) + sizeof (T.OBMEs_CM_set_HO_expansion) + sizeof (T.OBMEs_CM_set_R_cut) + sizeof (T.reduced_grad_HO_expansion_set) + sizeof (T.reduced_r_HO_expansion_set) + sizeof (T.reduced_r_HO_expansion_rms_radius_pn_set) + sizeof (T.reduced_grad_R_cut_set) + sizeof (T.reduced_r_R_cut_set) + sizeof (T.reduced_r_R_cut_rms_radius_pn_set) + sizeof (T.OBMEs_multipole_square_HO_expansion) + sizeof (T.OBMEs_multipole_square_R_cut) + sizeof (T.OBMEs_multipole_reduced_HO_expansion) + sizeof (T.OBMEs_multipole_reduced_R_cut) + sizeof (T.OBMEs_inter_set) + sizeof (T.nmax_lj_tab) + sizeof (T.shells_indices) + sizeof (T.is_it_valence_shell_tab) + sizeof (T.one_body_indices) + sizeof (T.shells) + sizeof (T.shells_plus) + sizeof (T.shells_minus) + sizeof (T.phi_table) + sizeof (T.Ueq_finite_range_tab_uniform) + sizeof (T.Ueq_finite_range_plus_tab_uniform) + sizeof (T.Ueq_finite_range_minus_tab_uniform) + sizeof (T.source_tab_uniform) + sizeof (T.source_plus_tab_uniform) + sizeof (T.source_minus_tab_uniform) + sizeof (T.OBMEs_HF_SGI_MSGI) + sizeof (T.h_basis) + sizeof (T.TBMEs) + sizeof (T.shells_quantum_numbers) + sizeof (T.SD_TRS_indices) + sizeof (T.SD_TRS_indices_1h) + sizeof (T.SD_TRS_indices_2h) + sizeof (T.SD_TRS_reordering_bin_phases) + sizeof (T.SD_TRS_reordering_bin_phases_1h) + sizeof (T.SD_TRS_reordering_bin_phases_2h) + sizeof (T.SD_TRS_bin_phases) + sizeof (T.SD_TRS_bin_phases_1h) + sizeof (T.SD_TRS_bin_phases_2h) + sizeof (T.dimensions_configuration_one_jump_table_in_to_out) + sizeof (T.dimensions_configuration_one_jump_table_out_to_in) + sizeof (T.configuration_one_jump_table_in_to_out) + sizeof (T.configuration_one_jump_table_out_to_in) + sizeof (T.dimensions_SD_one_jump_table_in_to_out) + sizeof (T.dimensions_SD_one_jump_table_out_to_in) + sizeof (T.dimensions_SD_one_jump_table_Jpm_in_to_out) + sizeof (T.dimensions_SD_one_jump_table_Jpm_out_to_in) + sizeof (T.SD_one_jump_table_in_to_out) + sizeof (T.SD_one_jump_table_out_to_in) + sizeof (T.SD_one_jump_table_Jpm_in_to_out) + sizeof (T.SD_one_jump_table_Jpm_out_to_in) + sizeof (T.are_configurations_inter_occupied_in_space_1ph_tables[0]) + sizeof (T.are_configurations_inter_occupied_in_space_2ph_tables[0]) + sizeof (T.dimensions_configuration_1p_tables[0]) + sizeof (T.dimensions_configuration_1h_tables[0]) + sizeof (T.dimensions_configuration_2p_tables[0]) + sizeof (T.dimensions_configuration_2h_tables[0]) + sizeof (T.configuration_1p_tables[0]) + sizeof (T.configuration_1h_tables[0]) + sizeof (T.configuration_2p_tables[0]) + sizeof (T.configuration_2h_tables[0]) + sizeof (T.are_configurations_inter_occupied_in_space_1ph_tables[1]) + sizeof (T.are_configurations_inter_occupied_in_space_2ph_tables[1]) + sizeof (T.dimensions_configuration_1p_tables[1]) + sizeof (T.dimensions_configuration_1h_tables[1]) + sizeof (T.dimensions_configuration_2p_tables[1]) + sizeof (T.dimensions_configuration_2h_tables[1]) + sizeof (T.configuration_1p_tables[1]) + sizeof (T.configuration_1h_tables[1]) + sizeof (T.configuration_2p_tables[1]) + sizeof (T.configuration_2h_tables[1]) + sizeof (T.dimensions_SD_1p_tables[0]) + sizeof (T.dimensions_SD_1h_tables[0]) + sizeof (T.dimensions_SD_2p_tables[0]) + sizeof (T.dimensions_SD_2h_tables[0]) + sizeof (T.SD_1p_tables[0]) + sizeof (T.SD_1h_tables[0]) + sizeof (T.SD_2p_tables[0]) + sizeof (T.SD_2h_tables[0])+ sizeof (T.dimensions_SD_1p_tables[1]) + sizeof (T.dimensions_SD_1h_tables[1]) + sizeof (T.dimensions_SD_2p_tables[1]) + sizeof (T.dimensions_SD_2h_tables[1]) + sizeof (T.SD_1p_tables[1]) + sizeof (T.SD_1h_tables[1]) + sizeof (T.SD_2p_tables[1]) + sizeof (T.SD_2h_tables[1]) + sizeof (T.U_finite_range_HF_HO_basis_HO_expansion_part) + sizeof (T.HO_overlaps_basis) + sizeof (T.HO_overlaps_basis_Fermi) + sizeof (T.HO_overlaps) + sizeof (T.HO_overlaps_Fermi) + sizeof (T.GHF_overlaps) + sizeof (T.d_core_potential_tab) + sizeof (T.R0_core_potential_tab) + sizeof (T.Vo_core_potential_tab) + sizeof (T.Vso_core_potential_tab) + sizeof (T.d_basis_core_potential_tab) + sizeof (T.R0_basis_core_potential_tab) + sizeof (T.Vo_basis_core_potential_tab) + sizeof (T.Vso_basis_core_potential_tab) + sizeof (T.d_basis_tab) + sizeof (T.R0_basis_tab) + sizeof (T.Vo_basis_tab) + sizeof (T.Vso_basis_tab) + sizeof (T.b_partial_waves) + sizeof (T.basis_PSI_quantum_numbers_tab) + sizeof (T.BPin_for_one_jump_tab) + sizeof (T.BPout_for_one_jump_tab) + sizeof (T.BPin_iMin_for_one_jump_tab) + sizeof (T.BPout_iMout_for_one_jump_tab) + sizeof (T.iC_in_min_tab[0]) + sizeof (T.iC_in_min_tab[1]) + sizeof (T.iC_in_max_tab[0]) + sizeof (T.iC_in_max_tab[1]) + sizeof (T.iC_out_min_tab) + sizeof (T.iC_out_max_tab) + sizeof (T.is_configuration_in_in_space_tabs[0]) + sizeof (T.is_configuration_in_in_space_tabs[1]) + sizeof (T.is_configuration_out_in_space_tab) + sizeof (T.is_inSD_in_space_tab_Jpm) + sizeof (T.is_inSD_in_space_tabs[0]) + sizeof (T.is_inSD_in_space_tabs[1]) + sizeof (T.is_outSD_in_space_tab) + sizeof (T.is_it_configuration_inter_to_include_tab) + sizeof (T.is_it_SD_inter_to_include_tab) + sizeof (T.initial_to_nljm_ordered_states) + sizeof (T.nljm_ordered_to_initial_states) + sizeof (T.dimensions_SD_HO_Berggren_overlaps_table) + sizeof (T.SD_HO_Berggren_overlaps_table) + sizeof (T.scalar_density_matrices) + sizeof (T.natural_orbitals_matrices) + sizeof (T.ESPEs_Hamiltonian_matrices) + sizeof (T.ESPEs_Hamiltonian_orbitals_matrices) + sizeof (T.natural_orbitals_reference_states) + sizeof (T.SD_quantum_numbers_tab))/1000000.0;
  
  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;    
}
