#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Array class type to store an array of class SD_one_jump_data_Jpm_out_to_in_str
// -------------------------------------------------------------------------------------
// class SD_one_jump_data_Jpm_out_to_in_str stores information related to the SD inSD obtained after the action of a+_{alpha} a_{beta} on a Slater determinant outSD to generate inSD for the action of J+/J- only.
// Indeed, one needs to go from outSD to inSD with creation/annihilation operators in some matrix-vector operations.
// It contains the shell index for this jump, as the shell is fixed during a jump when J+/J- only is considered,
// the coded difference of M quantum numbers, equal to 0 for J+ and 1 for J-, from which M[in] = M[out] -/+ 1 can be recovered as M[in] is fixed, 
// the index of inSD in a fixed configuration, and the binary phase related to a+_{alpha} a_{beta}.
// M[in] and m[in] can be recovered from shifted M-values as M[out] is fixed.
//			       
// In this array class type, one uniquely stores the existing class SD_one_jump_data_Jpm_out_to_in_str by knowing their number for each SD and summing dimensions.
//
// The method is the following to allocate the array of class SD_one_jump_data_Jpm_out_to_in_str:
// _ one loops over all SDs
// _ one adds the number of class SD_one_jump_data_Jpm_out_to_in_str to the total number of SD_one_jump_data_Jpm_out_to_in_str
// _ one does the same for the array of sums of dimensions
// _ one allocates the array of class SD_one_jump_data_Jpm_out_to_in_str with its calculated dimension
//
// The internal index of the table storing all classes SD_one_jump_data_Jpm_out_to_in_str is a one-dimensional index ,
// calculated from the local index SD_one_jump_index, where SD quantum numbers are fixed, to which a sum of dimensions is added.
// This is done in index_determine.
//
// One can access the table with operator (), where one puts all SD quantum numbers and the local index SD_one_jump_index,
// or with operator [], where one puts directly the internal one-dimensional index of the stored array.

array_of_SD_one_jump_data_Jpm_out_to_in::array_of_SD_one_jump_data_Jpm_out_to_in () {}
  
array_of_SD_one_jump_data_Jpm_out_to_in::array_of_SD_one_jump_data_Jpm_out_to_in (
										  const unsigned long int dimension_SD_total , 
										  const class array_BP_Nscat_iC<unsigned long int> &sum_dimensions_SD_set , 
										  const int n_scat_max , 
										  const class array<unsigned int> &dimensions_configuration_set , 
										  const int iM_max , 
										  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set , 
										  const class array_BP_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_one_jump_table_Jpm)
{
  allocate (dimension_SD_total , sum_dimensions_SD_set , n_scat_max , dimensions_configuration_set ,iM_max , dimensions_SD_set , dimensions_SD_one_jump_table_Jpm);
}

array_of_SD_one_jump_data_Jpm_out_to_in::array_of_SD_one_jump_data_Jpm_out_to_in (const class array_of_SD_one_jump_data_Jpm_out_to_in &X)
{
  allocate_fill (X);
}

void array_of_SD_one_jump_data_Jpm_out_to_in::allocate (
							const unsigned long int dimension_SD_total , 
							const class array_BP_Nscat_iC<unsigned long int> &sum_dimensions_SD_set , 
							const int n_scat_max , 
							const class array<unsigned int> &dimensions_configuration_set , 
							const int iM_max , 
							const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set , 
							const class array_BP_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_one_jump_table_Jpm)
{
  sum_dimensions_tab.allocate (dimension_SD_total , sum_dimensions_SD_set);

  unsigned int dimension_table = 0;

  unsigned int dimension_bef = 0;

  unsigned int sum_dimensions_bef = 0;

  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
      {
	const unsigned int dimension_configuration_set_BP_n_scat = dimensions_configuration_set(BP , n_scat);

	for (unsigned int iC = 0 ; iC < dimension_configuration_set_BP_n_scat ; iC++)
	  for (int iM = 0 ; iM <= iM_max ; iM++) 
	    {
	      const unsigned int dimension_SD_set_BP_n_scat_iC_iM = dimensions_SD_set(BP , n_scat , iC , iM);

	      const unsigned long int dimensions_SD_one_jump_Jpm_debut_index = dimensions_SD_one_jump_table_Jpm.index_determine (BP , n_scat , iC , iM , 0);

	      const unsigned long int sum_dimensions_debut_index = sum_dimensions_tab.index_determine (BP , n_scat , iC , iM , 0);

	      for (unsigned int iSD = 0 ; iSD < dimension_SD_set_BP_n_scat_iC_iM ; iSD++)
		{
		  const unsigned long int dimensions_SD_one_jump_Jpm_index = dimensions_SD_one_jump_Jpm_debut_index + iSD ;

		  const unsigned long int sum_dimensions_index = sum_dimensions_debut_index + iSD;

		  const unsigned int dimension = dimensions_SD_one_jump_table_Jpm[dimensions_SD_one_jump_Jpm_index];

		  unsigned int &sum_dimensions = sum_dimensions_tab[sum_dimensions_index];

		  dimension_table += dimension;

		  sum_dimensions = sum_dimensions_bef + dimension_bef;

		  dimension_bef = dimension;

		  sum_dimensions_bef = sum_dimensions;		
		}
	    }
      }

  table.allocate (dimension_table);
}



void array_of_SD_one_jump_data_Jpm_out_to_in::allocate_fill (const class array_of_SD_one_jump_data_Jpm_out_to_in &X)
{
  sum_dimensions_tab.allocate_fill (X.sum_dimensions_tab);

  table.allocate_fill (X.table);
}



void array_of_SD_one_jump_data_Jpm_out_to_in::deallocate ()
{
  sum_dimensions_tab.deallocate ();

  table.deallocate ();
}

bool array_of_SD_one_jump_data_Jpm_out_to_in::is_it_filled () const
{
  return table.is_it_filled ();
}


unsigned int array_of_SD_one_jump_data_Jpm_out_to_in::index_determine (
								       const unsigned int BP , 
								       const int n_scat , 
								       const unsigned int iC , 
								       const int iM_out , 
								       const unsigned int outSD_index , 
								       const unsigned int SD_one_jump_index) const
{
  const unsigned int index = SD_one_jump_index + sum_dimensions_tab(BP , n_scat , iC , iM_out , outSD_index);

  return index;
}


class SD_one_jump_data_Jpm_out_to_in_str & array_of_SD_one_jump_data_Jpm_out_to_in::operator () (
												 const unsigned int BP , 
												 const int n_scat , 
												 const unsigned int iC , 
												 const int iM_out , 
												 const unsigned int outSD_index , 
												 const unsigned int SD_one_jump_index) const
{
  const unsigned int index = index_determine (BP , n_scat , iC , iM_out , outSD_index , SD_one_jump_index);

  return table(index);
}


class SD_one_jump_data_Jpm_out_to_in_str & array_of_SD_one_jump_data_Jpm_out_to_in::operator [] (const unsigned int index) const
{
  return table(index);
}



// Determination of the first and last element of the array for which the coded difference of M quantum numbers, equal to 0 for J+ and 1 for J-, from which M[in] = M[out] -/+ 1 can be recovered, is fixed
// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// In the class array_of_SD_one_jump_data_out_to_in, elements are given in terms of configuration, SD indices and the index of the jump a+_{alpha} a_{beta} itself (see index_determine).
// The value of coded difference of M quantum numbers is then the same for all groups of elements of the array. 
// One needs to have a fixed value of coded difference of M quantum numbers when dealing with jumps due to M conservation.
// Hence, one needs to know the first and last indices of elements of the array for which coded difference of M quantum numbers is the same,
// as all elements in between possess the same value for coded difference of M quantum numbers.
// This is done with a binary search, as coded difference of M quantum numbers is ordered in the array.

unsigned long int array_of_SD_one_jump_data_Jpm_out_to_in::debut_index_good_iM_in_determine (
											     const int Delta_iM_in , 
											     const unsigned int dimension_SD_one_jump_subtable , 
											     const unsigned long int SD_one_jump_zero_index) const
{
  const class array_of_SD_one_jump_data_Jpm_out_to_in &SD_one_jump_table = *this;

  const unsigned int dimension_SD_one_jump_subtable_minus_one = dimension_SD_one_jump_subtable - 1;

  const unsigned long int last_SD_one_jump_index = SD_one_jump_zero_index + dimension_SD_one_jump_subtable_minus_one;
  
  unsigned long int SD_one_jump_debut_index = SD_one_jump_zero_index;

  unsigned long int SD_one_jump_end_index = last_SD_one_jump_index;

  const class SD_one_jump_data_Jpm_out_to_in_str &SD_one_jump_debut = SD_one_jump_table[SD_one_jump_debut_index];
  
  const int Delta_iM_in_debut = SD_one_jump_debut.get_Delta_iM_in ();
  
  if (Delta_iM_in_debut == Delta_iM_in) return SD_one_jump_debut_index;

  while (SD_one_jump_end_index - SD_one_jump_debut_index > 1)
    {
      const unsigned long int SD_one_jump_middle_index = SD_one_jump_debut_index + (SD_one_jump_end_index - SD_one_jump_debut_index)/2;

      const class SD_one_jump_data_Jpm_out_to_in_str &SD_one_jump_middle = SD_one_jump_table[SD_one_jump_middle_index];
      
      const int Delta_iM_in_middle = SD_one_jump_middle.get_Delta_iM_in ();

      if (Delta_iM_in <= Delta_iM_in_middle)
	SD_one_jump_end_index = SD_one_jump_middle_index;
      else 
	SD_one_jump_debut_index = SD_one_jump_middle_index;
    }

  return SD_one_jump_end_index;
}



unsigned long int array_of_SD_one_jump_data_Jpm_out_to_in::end_index_good_iM_in_determine (
											   const int Delta_iM_in , 
											   const unsigned int dimension_SD_one_jump_subtable , 
											   const unsigned long int SD_one_jump_zero_index) const
{
  const class array_of_SD_one_jump_data_Jpm_out_to_in &SD_one_jump_table = *this;

  const unsigned int dimension_SD_one_jump_subtable_minus_one = dimension_SD_one_jump_subtable - 1;
  
  const unsigned long int last_SD_one_jump_index = SD_one_jump_zero_index + dimension_SD_one_jump_subtable_minus_one;
  
  unsigned long int SD_one_jump_debut_index = SD_one_jump_zero_index;

  unsigned long int SD_one_jump_end_index = last_SD_one_jump_index;

  const class SD_one_jump_data_Jpm_out_to_in_str &SD_one_jump_end = SD_one_jump_table[SD_one_jump_end_index];
  
  const int Delta_iM_in_end = SD_one_jump_end.get_Delta_iM_in ();
  
  if (Delta_iM_in_end == Delta_iM_in) return SD_one_jump_end_index;

  while (SD_one_jump_end_index - SD_one_jump_debut_index > 1)
    {
      const unsigned long int SD_one_jump_middle_index = SD_one_jump_debut_index + (SD_one_jump_end_index - SD_one_jump_debut_index)/2;
      
      const class SD_one_jump_data_Jpm_out_to_in_str &SD_one_jump_middle = SD_one_jump_table[SD_one_jump_middle_index];
      
      const int Delta_iM_in_middle = SD_one_jump_middle.get_Delta_iM_in ();

      if (Delta_iM_in >= Delta_iM_in_middle)
	SD_one_jump_debut_index = SD_one_jump_middle_index;
      else 
	SD_one_jump_end_index = SD_one_jump_middle_index;
    }

  return SD_one_jump_debut_index;
}




double used_memory_calc (const class array_of_SD_one_jump_data_Jpm_out_to_in &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.sum_dimensions_tab) + used_memory_calc (T.table) - (sizeof (T.sum_dimensions_tab) + sizeof (T.table))/1000000.0);
}

