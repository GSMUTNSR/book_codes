#include "../GSM_include/GSM_include_def_common.h"

using namespace string_routines;
using namespace angular_matrix_elements;
using namespace Wigner_signs;
using namespace inputs_misc;

extern called_code_type called_code;

// TYPE is double or complex
// -------------------------

// TBME means two-body matrix element
// ----------------------------------




// This class contains parameters and arrays related to the interaction used in the Hamiltonian. 
// One only uses HO expansion for realistic, Coulomb, Minnesota and FHT interactions.
// Hence, J-coupled HO matrix elements are calculated and stored here using the Brody-Moshinsky transformation, or read from a file if one uses GHF expansion.
// Only simple interactions can be directly handled in coordinate space, such as SDI, SGI and MSDI.
// See GSM_interaction_class.h and files where called functions are defined for information.
// TBME is for two-body matrix element
// TBMEs are all coupled to J. 
// One does not couple in isospin unless explicitly stated.
// A-dependence is used only on nuclear TBMEs.
// A-dependence is not considered in inter_data_calc in the optimization code as A is typically undefined therein.

interaction_class::interaction_class () :
  is_it_only_basis (false) ,
  is_there_cout (false) ,
  is_there_cout_detailed (false) ,
  TBME_inter (NO_INTERACTION) , 
  are_there_pp_TBMEs (false) ,
  are_there_nn_TBMEs (false) ,
  are_there_pn_TBMEs (false) ,
  a (0.0) , 
  b (0.0) ,
  V_SDI (0.0) ,
  R0 (0.0) ,
  mu (0.0) , 
  b_lab (0.0) , 
  b_relative (0.0) ,
  u_Minnesota (0.0) ,
  nu_three_body_like (0.0) ,
  V_three_body_like (0.0) ,
  lmax_for_interaction (0) ,
  lmax_multipole_expansion (0) ,
  BPmin_global_pp (2) ,
  BPmax_global_pp (2) ,
  Jmin_global_pp (0.0) , 
  Jmax_global_pp (0.0) , 
  BPmin_global_nn (2) ,
  BPmax_global_nn (2) ,
  Jmin_global_nn (0.0) , 
  Jmax_global_nn (0.0) , 
  BPmin_global_pn (2) ,
  BPmax_global_pn (2) ,
  Jmin_global_pn (0.0) ,
  Jmax_global_pn (0.0) ,
  BPmin_global (2) ,
  BPmax_global (2) ,
  Jmin_global (0.0) ,
  Jmax_global (0.0)
{
  for (unsigned int i = 0 ; i < 2 ; i++) 
    {
      V0_so_tab[i] = 0.0;

      alpha_so_tab[i] = 0.0;

      W_so_tab[i] = 0.0;
      H_so_tab[i] = 0.0;
    } 

  for (unsigned int i = 0 ; i < 3 ; i++) 
    {
      V0_Minnesota_tab[i] = 0.0;
      rho_Minnesota_tab[i] = 0.0;

      V0_ctr_tab[i] = 0.0; 
      
      alpha_ctr_tab[i] = 0.0;
      
      W_ctr_tab[i] = 0.0;
      B_ctr_tab[i] = 0.0;
      H_ctr_tab[i] = 0.0;
      M_ctr_tab[i] = 0.0;

      V0_t_tab[i] = 0.0;

      alpha_t_tab[i] = 0.0;

      W_t_tab[i] = 0.0;
      H_t_tab[i] = 0.0;
    }
}

interaction_class::interaction_class (
				      const bool is_there_cout_c , 
				      const bool is_it_only_basis_c , 
				      const bool is_it_Coulomb , 
				      const class input_data_str &input_data) :
  is_it_only_basis (false) ,
  is_there_cout (false) ,
  is_there_cout_detailed (false) ,
  TBME_inter (NO_INTERACTION) , 
  inter_read (NO_TBMES_READ) , 
  are_there_pp_TBMEs (false) ,
  are_there_nn_TBMEs (false) ,
  are_there_pn_TBMEs (false) ,
  a (0.0), 
  b (0.0) ,
  V_SDI (0.0) ,
  R0 (0.0) ,
  mu (0.0) , 
  b_lab (0.0) , 
  b_relative (0.0) ,
  u_Minnesota (0.0) ,
  nu_three_body_like (0.0) ,
  V_three_body_like (0.0) ,
  lmax_for_interaction (0) ,
  lmax_multipole_expansion (0) ,
  BPmin_global_pp (2) ,
  BPmax_global_pp (2) ,
  Jmin_global_pp (0.0) , 
  Jmax_global_pp (0.0) , 
  BPmin_global_nn (2) ,
  BPmax_global_nn (2) ,
  Jmin_global_nn (0.0) , 
  Jmax_global_nn (0.0) , 
  BPmin_global_pn (2) ,
  BPmax_global_pn (2) ,
  Jmin_global_pn (0.0) ,
  Jmax_global_pn (0.0) ,
  BPmin_global (2) ,
  BPmax_global (2) ,
  Jmin_global (0.0) ,
  Jmax_global (0.0)
{ 
  for (unsigned int i = 0 ; i < 2 ; i++) 
    {
      V0_so_tab[i] = 0.0;

      alpha_so_tab[i] = 0.0;

      W_so_tab[i] = 0.0;
      H_so_tab[i] = 0.0;
    } 

  for (unsigned int i = 0 ; i < 3 ; i++) 
    {
      V0_Minnesota_tab[i] = 0.0;
      rho_Minnesota_tab[i] = 0.0;

      V0_ctr_tab[i] = 0.0; 
      
      alpha_ctr_tab[i] = 0.0;
      
      W_ctr_tab[i] = 0.0;
      B_ctr_tab[i] = 0.0;
      H_ctr_tab[i] = 0.0;
      M_ctr_tab[i] = 0.0;

      V0_t_tab[i] = 0.0;

      alpha_t_tab[i] = 0.0;

      W_t_tab[i] = 0.0;
      H_t_tab[i] = 0.0;
    }

  allocate (is_there_cout_c , is_it_only_basis_c , is_it_Coulomb , input_data);
}

interaction_class::interaction_class (const class interaction_class &X)
{  
  allocate_fill (X);
}



interaction_class::~interaction_class () {}




// Allocation and initialization of data of the class interaction_class
// --------------------------------------------------------------------
// Parameters are initialized from the values present in input_data. They typically differ according to the value of is_it_only_basis.
//
// If it is true, the class interaction_class is used in the context of HF/MSDHF potentials, so that values related to basis only are copied to interaction_class data.
//
// If it is false, the class interaction_class is used in the context of the calculation of Hamiltonian TBMEs for Hamiltonian diagonalization, 
// so that values related to Hamiltonian are copied to interaction_class data.
//
// HO/GHF shells and wave functions are allocated and calculated. They are used in the HO/GHF expansion of interactions.
// Gauss-Legendre radii and weights before and after the rotation point are allocated and calculated.
//
// The HO/GHF TBMEs of the used interaction, if one uses the HO/GHF expansion of interactions, are allocated. They are calculated in other routines.
// The multipolar expansion array of the SGI interaction is allocated if one uses SGI. It is calculated in another routine.
//
// HO basis only
// -------------
// Matrix elements of a Fermi cut function are also allocated and calculated. 
// They are used in the context of GSM-CC as one uses a Fermi cut function in the HF/MSDHF potentials and a HO representation of the HF/MSDHF potentials is demanded therein.
//
// One separates the infinite-range of the Coulomb potential, given by a one-body Coulomb potential generated by a Gaussian charged sphere, from the Coulomb interaction.
// Indeed, the difference between the Coulomb interaction and the one-body Coulomb potential generated by a Gaussian charged sphere is finite range.
// Thus it can be expanded in a HO basis.
// One then needs to have the one-body Coulomb potential in a HO basis, which is calculated as well.
//
// GHF basis only
// --------------
// GHF basis expansion is used with the Qbox method, where GHF TBMEs are calculated from a realistic interaction.
// GHF expansion is used either for GHF basis, where it is trivial, or for a basis or natural orbitals.

void interaction_class::allocate (				  
				  const bool is_there_cout_c , 
				  const bool is_it_only_basis_c ,
				  const bool is_it_Coulomb , 
				  const class input_data_str &input_data)
{
  if (is_it_filled ()) error_message_print_abort ("interaction_class cannot be allocated twice in interaction_class::allocate (1)");

  const bool print_detailed_information = input_data.get_print_detailed_information ();
    
  is_it_only_basis = is_it_only_basis_c;
  
  is_there_cout = is_there_cout_c;
  
  is_there_cout_detailed = (is_there_cout && print_detailed_information);

  TBME_inter = (!is_it_Coulomb) ? (input_data.get_inter ()) : (COULOMB_INTERACTION);
  
  inter_read = (!is_it_Coulomb) ? (input_data.get_inter_read ()) : (NO_TBMES_READ);
  
  const enum potential_type basis_potential = input_data.get_basis_potential ();

  const bool TBMEs_used = (!is_it_only_basis || (basis_potential == HF) || (basis_potential == MSDHF));
  
  const bool is_it_nuclear_mixed = is_it_nuclear_mixed_determine (TBME_inter);

  are_there_pp_TBMEs = (is_it_only_basis) ? (input_data.get_Zval_basis () >= 2) : (input_data.get_Zval () >= 2);

  are_there_pp_TBMEs = (are_there_pp_TBMEs && TBMEs_used);
  
  R0 = (is_it_only_basis) ? (input_data.get_R0_inter_basis ()) : (input_data.get_R0_inter ());

  const unsigned int N_bef_R_GL = input_data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = input_data.get_N_aft_R_GL ();

  b_lab = (is_it_only_basis) ? (input_data.get_b_lab_basis ()) : (input_data.get_b_lab ());

  b_relative = b_lab*M_SQRT2;
  
  lmax_for_interaction = (is_it_only_basis) ? (input_data.get_lmax_for_basis_interaction ()) : (input_data.get_lmax_for_interaction ());
  
  lmax_multipole_expansion = 2*lmax_for_interaction;

  const bool are_MEs_Berggren_read_not_only_basis = (!is_it_only_basis && (inter_read == LAB_BERGGREN_TBMES_READ));

  const int lmax_for_interaction_plus_one = lmax_for_interaction + 1;

  const class array<int> &nmax_HO_lab_tab_from_input_data = input_data.get_nmax_HO_lab_tab ();
  
  nmax_HO_lab_tab.allocate (lmax_for_interaction_plus_one);
  
  nmax_HO_lab_tab.assign (nmax_HO_lab_tab_from_input_data);
  
  const unsigned int N_nlj_HO = N_nlj_calc (nmax_HO_lab_tab);
  
  const unsigned int N_nlj_inter = (are_MEs_Berggren_read_not_only_basis) ? (N_nlj_calc (input_data.get_nmax_GHF_lab_tab ())) : (N_nlj_HO);
    
  const int lmax_multipole_expansion_plus_one = lmax_multipole_expansion + 1;
  
  const bool is_it_SGI_MSGI         = is_it_SGI_MSGI_determine         (TBME_inter);
  const bool is_it_SGI_MSGI_COSM    = is_it_SGI_MSGI_COSM_determine    (TBME_inter);
  const bool is_it_SGI_MSGI_no_COSM = is_it_SGI_MSGI_no_COSM_determine (TBME_inter);
  
  const bool is_it_FHT = is_it_FHT_determine (TBME_inter);
  const bool is_it_EFT = is_it_EFT_determine (TBME_inter);
	  
  if (are_MEs_Berggren_read_not_only_basis)
    nmax_inter_lab_tab.allocate_fill (input_data.get_nmax_GHF_lab_tab ());
  else
    nmax_inter_lab_tab.allocate_fill (nmax_HO_lab_tab);
  
  const int nmax_HO_lab = nmax_calc (nmax_HO_lab_tab);

  const int nmax_inter_lab = nmax_calc (nmax_inter_lab_tab);

  const int nmax_HO_lab_plus_one = nmax_HO_lab + 1;

  shells_HO_table.allocate (N_nlj_HO);

  shells_HO_indices.allocate (0.5 , nmax_HO_lab , lmax_for_interaction);

  shells_HO_indices = OUT_OF_RANGE;
  	  
  unsigned int index_HO = 0;

  for (int l = 0 ; l <= lmax_for_interaction ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	const int n_max_l = nmax_HO_lab_tab(l);

	for (int n = 0 ; n <= n_max_l ; n++)
	  {
	    shells_HO_table(index_HO).initialize (true , false , false , false , false , true , false , false , NADA , n , l , j , NO_SEGMENT , NADA , NADA , NADA , NADA , NADA , NADA , NADA , NADA);
	    
	    shells_HO_indices(n , l , j) = index_HO++;
	  }
      }
  
  if (index_HO != N_nlj_HO) error_message_print_abort ("Problem with shells_HO_table in interaction_class::allocate (1)");
  
  if (are_MEs_Berggren_read_not_only_basis)
    {
      // GHF states are all considered scattering for interaction basis expansion
      
      shells_inter_table.allocate (N_nlj_inter);
  
      shells_inter_indices.allocate (0.5 , nmax_inter_lab , lmax_for_interaction);

      shells_inter_indices = OUT_OF_RANGE;
  
      unsigned int index_inter = 0;

      for (int l = 0 ; l <= lmax_for_interaction ; l++)
	for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	  {
	    const int n_max_l = nmax_inter_lab_tab(l);

	    for (int n = 0 ; n <= n_max_l ; n++)
	      {
		shells_inter_table(index_inter).initialize (false , false , false , false , false , false , false , false , NADA , n , l , j , NO_SEGMENT , NADA , NADA , NADA , NADA , NADA , NADA , NADA , NADA);
	    
		shells_inter_indices(n , l , j) = index_inter++;
	      }
	  }
      
      if (index_inter != N_nlj_inter) error_message_print_abort ("Problem with shells_inter_table in interaction_class::allocate (1)");
    }
  else
    {
      shells_inter_table.allocate_fill (shells_HO_table);
  
      shells_inter_indices.allocate_fill (shells_HO_indices);
    }
  
  if (TBME_inter == COULOMB_INTERACTION)
    {
      BPmin_global_pp = BPmin_global = input_data.get_BPmin_global_pp ();
      BPmax_global_pp = BPmax_global = input_data.get_BPmax_global_pp ();

      Jmin_global_pp = Jmin_global = input_data.get_Jmin_global_pp ();
      Jmax_global_pp = Jmax_global = input_data.get_Jmax_global_pp ();

      if (are_there_pp_TBMEs) TBMEs_pp_inter_lab.allocate (is_there_cout_detailed , PROTONS_ONLY , input_data , shells_inter_table);

      are_there_nn_TBMEs = false;
      are_there_pn_TBMEs = false;
      
      a = 0.0;
      b = 0.0;
      
      V_SDI = 0.0;
      
      mu = 0.0;
      
      V0_Minnesota_tab[0] = 0.0;
      V0_Minnesota_tab[1] = 0.0;
      V0_Minnesota_tab[2] = 0.0;
      
      rho_Minnesota_tab[0] = 0.0; 
      rho_Minnesota_tab[1] = 0.0;
      rho_Minnesota_tab[2] = 0.0;
      
      u_Minnesota = 0.0;
      
      nu_three_body_like = 0.0;
      
      V_three_body_like = 0.0;
      
      V0_ctr_tab[0] = 0.0; 
      V0_ctr_tab[1] = 0.0; 
      V0_ctr_tab[2] = 0.0;
      
      alpha_ctr_tab[0] = 0.0; 
      alpha_ctr_tab[1] = 0.0; 
      alpha_ctr_tab[2] = 0.0;
      
      W_ctr_tab[0] = 0.0; 
      W_ctr_tab[1] = 0.0; 
      W_ctr_tab[2] = 0.0;
      
      B_ctr_tab[0] = 0.0; 
      B_ctr_tab[1] = 0.0; 
      B_ctr_tab[2] = 0.0;
      
      H_ctr_tab[0] = 0.0; 
      H_ctr_tab[1] = 0.0; 
      H_ctr_tab[2] = 0.0;
      
      M_ctr_tab[0] = 0.0; 
      M_ctr_tab[1] = 0.0; 
      M_ctr_tab[2] = 0.0;
      
      V0_so_tab[0] = 0.0; 
      V0_so_tab[1] = 0.0;
      
      alpha_so_tab[0] = 0.0; 
      alpha_so_tab[1] = 0.0;
      
      W_so_tab[0] = 0.0; 
      W_so_tab[1] = 0.0;
      
      H_so_tab[0] = 0.0; 
      H_so_tab[1] = 0.0;
      
      V0_t_tab[0] = 0.0; 
      V0_t_tab[1] = 0.0; 
      V0_t_tab[2] = 0.0;
      
      alpha_t_tab[0] = 0.0; 
      alpha_t_tab[1] = 0.0; 
      alpha_t_tab[2] = 0.0;
      
      W_t_tab[0] = 0.0; 
      W_t_tab[1] = 0.0; 
      W_t_tab[2] = 0.0;
      
      H_t_tab[0] = 0.0; 
      H_t_tab[1] = 0.0; 
      H_t_tab[2] = 0.0;
    }
  else
    {
      are_there_nn_TBMEs = (is_it_only_basis) ? (input_data.get_Nval_basis () >= 2) : (input_data.get_Nval () >= 2); 
      are_there_pn_TBMEs = (is_it_only_basis) ? (input_data.get_basis_space () == PROTONS_NEUTRONS) : (input_data.get_space () == PROTONS_NEUTRONS);

      are_there_nn_TBMEs = (are_there_nn_TBMEs && TBMEs_used);
      are_there_pn_TBMEs = (are_there_pn_TBMEs && TBMEs_used);
      
      a = (is_it_only_basis) ? (input_data.get_a_basis ()) : (input_data.get_a ()); 
      b = (is_it_only_basis) ? (input_data.get_b_basis ()) : (input_data.get_b ());

      V_SDI = (is_it_only_basis) ? (input_data.get_V_SDI_basis ()) : (input_data.get_V_SDI ()); 

      mu = (is_it_only_basis) ? (input_data.get_mu_basis ()) : (input_data.get_mu ());

      V0_Minnesota_tab[0] = (is_it_only_basis) ? (input_data.get_V0_Minnesota_basis(0)) : (input_data.get_V0_Minnesota(0)); 
      V0_Minnesota_tab[1] = (is_it_only_basis) ? (input_data.get_V0_Minnesota_basis(1)) : (input_data.get_V0_Minnesota(1)); 
      V0_Minnesota_tab[2] = (is_it_only_basis) ? (input_data.get_V0_Minnesota_basis(2)) : (input_data.get_V0_Minnesota(2));

      rho_Minnesota_tab[0] = (is_it_only_basis) ? (input_data.get_rho_Minnesota_basis(0)) : (input_data.get_rho_Minnesota(0)); 
      rho_Minnesota_tab[1] = (is_it_only_basis) ? (input_data.get_rho_Minnesota_basis(1)) : (input_data.get_rho_Minnesota(1)); 
      rho_Minnesota_tab[2] = (is_it_only_basis) ? (input_data.get_rho_Minnesota_basis(2)) : (input_data.get_rho_Minnesota(2));

      u_Minnesota = (is_it_only_basis) ? (input_data.get_u_Minnesota_basis ()) : (input_data.get_u_Minnesota ());

      nu_three_body_like = (is_it_only_basis) ? (input_data.get_nu_three_body_like_basis ()) : (input_data.get_nu_three_body_like ()); 

      V_three_body_like = (is_it_only_basis) ? (input_data.get_V_three_body_like_basis ()) : (input_data.get_V_three_body_like ());

      V0_ctr_tab[0] = (is_it_only_basis) ? (input_data.get_V0_ctr_basis(0)) : (input_data.get_V0_ctr(0)); 
      V0_ctr_tab[1] = (is_it_only_basis) ? (input_data.get_V0_ctr_basis(1)) : (input_data.get_V0_ctr(1)); 
      V0_ctr_tab[2] = (is_it_only_basis) ? (input_data.get_V0_ctr_basis(2)) : (input_data.get_V0_ctr(2));

      alpha_ctr_tab[0] = (is_it_only_basis) ? (input_data.get_alpha_ctr_basis(0)) : (input_data.get_alpha_ctr(0)); 
      alpha_ctr_tab[1] = (is_it_only_basis) ? (input_data.get_alpha_ctr_basis(1)) : (input_data.get_alpha_ctr(1)); 
      alpha_ctr_tab[2] = (is_it_only_basis) ? (input_data.get_alpha_ctr_basis(2)) : (input_data.get_alpha_ctr(2));

      W_ctr_tab[0] = (is_it_only_basis) ? (input_data.get_W_ctr_basis(0)) : (input_data.get_W_ctr(0)); 
      W_ctr_tab[1] = (is_it_only_basis) ? (input_data.get_W_ctr_basis(1)) : (input_data.get_W_ctr(1)); 
      W_ctr_tab[2] = (is_it_only_basis) ? (input_data.get_W_ctr_basis(2)) : (input_data.get_W_ctr(2));

      B_ctr_tab[0] = (is_it_only_basis) ? (input_data.get_B_ctr_basis(0)) : (input_data.get_B_ctr(0)); 
      B_ctr_tab[1] = (is_it_only_basis) ? (input_data.get_B_ctr_basis(1)) : (input_data.get_B_ctr(1)); 
      B_ctr_tab[2] = (is_it_only_basis) ? (input_data.get_B_ctr_basis(2)) : (input_data.get_B_ctr(2));

      H_ctr_tab[0] = (is_it_only_basis) ? (input_data.get_H_ctr_basis(0)) : (input_data.get_H_ctr(0)); 
      H_ctr_tab[1] = (is_it_only_basis) ? (input_data.get_H_ctr_basis(1)) : (input_data.get_H_ctr(1)); 
      H_ctr_tab[2] = (is_it_only_basis) ? (input_data.get_H_ctr_basis(2)) : (input_data.get_H_ctr(2));

      M_ctr_tab[0] = (is_it_only_basis) ? (input_data.get_M_ctr_basis(0)) : (input_data.get_M_ctr(0)); 
      M_ctr_tab[1] = (is_it_only_basis) ? (input_data.get_M_ctr_basis(1)) : (input_data.get_M_ctr(1)); 
      M_ctr_tab[2] = (is_it_only_basis) ? (input_data.get_M_ctr_basis(2)) : (input_data.get_M_ctr(2));

      V0_so_tab[0] = (is_it_only_basis) ? (input_data.get_V0_so_basis(0)) : (input_data.get_V0_so(0)); 
      V0_so_tab[1] = (is_it_only_basis) ? (input_data.get_V0_so_basis(1)) : (input_data.get_V0_so(1));

      alpha_so_tab[0] = (is_it_only_basis) ? (input_data.get_alpha_so_basis(0)) : (input_data.get_alpha_so(0)); 
      alpha_so_tab[1] = (is_it_only_basis) ? (input_data.get_alpha_so_basis(1)) : (input_data.get_alpha_so(1));

      W_so_tab[0] = (is_it_only_basis) ? (input_data.get_W_so_basis(0)) : (input_data.get_W_so(0)); 
      W_so_tab[1] = (is_it_only_basis) ? (input_data.get_W_so_basis(1)) : (input_data.get_W_so(1)); 

      H_so_tab[0] = (is_it_only_basis) ? (input_data.get_H_so_basis(0)) : (input_data.get_H_so(0)); 
      H_so_tab[1] = (is_it_only_basis) ? (input_data.get_H_so_basis(1)) : (input_data.get_H_so(1));

      V0_t_tab[0] = (is_it_only_basis) ? (input_data.get_V0_t_basis(0)) : (input_data.get_V0_t(0)); 
      V0_t_tab[1] = (is_it_only_basis) ? (input_data.get_V0_t_basis(1)) : (input_data.get_V0_t(1)); 
      V0_t_tab[2] = (is_it_only_basis) ? (input_data.get_V0_t_basis(2)) : (input_data.get_V0_t(2));

      alpha_t_tab[0] = (is_it_only_basis) ? (input_data.get_alpha_t_basis(0)) : (input_data.get_alpha_t(0)); 
      alpha_t_tab[1] = (is_it_only_basis) ? (input_data.get_alpha_t_basis(1)) : (input_data.get_alpha_t(1)); 
      alpha_t_tab[2] = (is_it_only_basis) ? (input_data.get_alpha_t_basis(2)) : (input_data.get_alpha_t(2));

      W_t_tab[0] = (is_it_only_basis) ? (input_data.get_W_t_basis(0)) : (input_data.get_W_t(0)); 
      W_t_tab[1] = (is_it_only_basis) ? (input_data.get_W_t_basis(1)) : (input_data.get_W_t(1));    
      W_t_tab[2] = (is_it_only_basis) ? (input_data.get_W_t_basis(2)) : (input_data.get_W_t(2)); 

      H_t_tab[0] = (is_it_only_basis) ? (input_data.get_H_t_basis(0)) : (input_data.get_H_t(0)); 
      H_t_tab[1] = (is_it_only_basis) ? (input_data.get_H_t_basis(1)) : (input_data.get_H_t(1)); 
      H_t_tab[2] = (is_it_only_basis) ? (input_data.get_H_t_basis(2)) : (input_data.get_H_t(2));

      BPmin_global_pp = input_data.get_BPmin_global_pp ();
      BPmax_global_pp = input_data.get_BPmax_global_pp ();

      Jmin_global_pp = input_data.get_Jmin_global_pp ();
      Jmax_global_pp = input_data.get_Jmax_global_pp ();

      BPmin_global_nn = input_data.get_BPmin_global_nn ();
      BPmax_global_nn = input_data.get_BPmax_global_nn ();

      Jmin_global_nn = input_data.get_Jmin_global_nn ();
      Jmax_global_nn = input_data.get_Jmax_global_nn ();

      BPmin_global_pn = input_data.get_BPmin_global_pn ();
      BPmax_global_pn = input_data.get_BPmax_global_pn ();

      Jmin_global_pn = input_data.get_Jmin_global_pn ();
      Jmax_global_pn = input_data.get_Jmax_global_pn ();

      BPmin_global = input_data.BPmin_global_determine (is_it_only_basis);
      BPmax_global = input_data.BPmax_global_determine (is_it_only_basis);

      Jmin_global = input_data.Jmin_global_determine (is_it_only_basis);
      Jmax_global = input_data.Jmax_global_determine (is_it_only_basis);

      if (is_it_only_basis)
	V_Gaussian_consts.allocate_fill (input_data.get_V_Gaussian_consts_basis ());
      else
	V_Gaussian_consts.allocate_fill (input_data.get_V_Gaussian_consts ());
      
      if (is_it_SGI_MSGI && TBMEs_used) Vl_SGI_tab_GL.allocate (lmax_multipole_expansion_plus_one , N_bef_R_GL);
    
      if (is_it_SGI_MSGI_no_COSM && are_there_pp_TBMEs) TBMEs_pp_inter_lab.allocate (is_there_cout_detailed , PROTONS_ONLY , input_data , shells_inter_table);
    }

  const double R = input_data.get_R ();

  const double R_real_max = input_data.get_R_real_max ();

  const double R_cut_function = input_data.get_R_cut_function ();
  const double d_cut_function = input_data.get_d_cut_function ();

  r_bef_R_tab_GL.allocate (N_bef_R_GL);
  w_bef_R_tab_GL.allocate (N_bef_R_GL);

  HO_wfs_bef_R_tab_GL.allocate  (nmax_HO_lab_plus_one , lmax_for_interaction_plus_one , N_bef_R_GL);
  HO_dwfs_bef_R_tab_GL.allocate (nmax_HO_lab_plus_one , lmax_for_interaction_plus_one , N_bef_R_GL);
  
  r_aft_R_tab_GL.allocate (N_aft_R_GL);
  w_aft_R_tab_GL.allocate (N_aft_R_GL);

  HO_wfs_aft_R_tab_GL.allocate  (nmax_HO_lab_plus_one , lmax_for_interaction_plus_one , N_aft_R_GL);
  HO_dwfs_aft_R_tab_GL.allocate (nmax_HO_lab_plus_one , lmax_for_interaction_plus_one , N_aft_R_GL);

  r_bef_R_tab_GL_SGI_MSGI.allocate (N_bef_R_GL);
  w_bef_R_tab_GL_SGI_MSGI.allocate (N_bef_R_GL);

  HO_wfs_bef_R_tab_GL_SGI_MSGI.allocate  (nmax_HO_lab_plus_one , lmax_for_interaction_plus_one , N_bef_R_GL);
  HO_dwfs_bef_R_tab_GL_SGI_MSGI.allocate (nmax_HO_lab_plus_one , lmax_for_interaction_plus_one , N_bef_R_GL);

  HO_radial_tables_calc (R , R_real_max);

  HO_overlaps_Fermi.allocate (N_nlj_HO);
  
  HO_overlaps_Fermi_calc (R_cut_function , d_cut_function);

  if (is_it_nuclear_mixed || is_it_SGI_MSGI_COSM || are_MEs_Berggren_read_not_only_basis)
    {
      if (are_there_pp_TBMEs) TBMEs_pp_inter_lab.allocate (is_there_cout_detailed , PROTONS_ONLY     , input_data , shells_inter_table);
      if (are_there_nn_TBMEs) TBMEs_nn_inter_lab.allocate (is_there_cout_detailed , NEUTRONS_ONLY    , input_data , shells_inter_table);
      if (are_there_pn_TBMEs) TBMEs_pn_inter_lab.allocate (is_there_cout_detailed , is_it_only_basis , input_data , shells_inter_table , shells_inter_table);
    }

  if (TBME_inter == COULOMB_INTERACTION) zero ();

  if (is_it_FHT && TBMEs_used)
    {
      zero ();

      V0_ctr_ot_inter = (is_it_only_basis) ? (input_data.get_V0_ctr_ot_basis ()) : (input_data.get_V0_ctr_ot ());
      V0_ctr_et_inter = (is_it_only_basis) ? (input_data.get_V0_ctr_et_basis ()) : (input_data.get_V0_ctr_et ());
      V0_ctr_os_inter = (is_it_only_basis) ? (input_data.get_V0_ctr_os_basis ()) : (input_data.get_V0_ctr_os ());
      V0_ctr_es_inter = (is_it_only_basis) ? (input_data.get_V0_ctr_es_basis ()) : (input_data.get_V0_ctr_es ());
      V0_so_ot_inter  = (is_it_only_basis) ? (input_data.get_V0_so_ot_basis ())  : (input_data.get_V0_so_ot ());
      V0_so_et_inter  = (is_it_only_basis) ? (input_data.get_V0_so_et_basis ())  : (input_data.get_V0_so_et ());  
      V0_t_ot_inter   = (is_it_only_basis) ? (input_data.get_V0_t_ot_basis ())   : (input_data.get_V0_t_ot ());
      V0_t_et_inter   = (is_it_only_basis) ? (input_data.get_V0_t_et_basis ())   : (input_data.get_V0_t_et ());
    }

  if (is_it_EFT && TBMEs_used)
    {
      zero ();

      VS_const_LO_T0_inter          = (is_it_only_basis) ? (input_data.get_VS_const_LO_T0_basis ())          : (input_data.get_VS_const_LO_T0 ());
      VS_const_LO_T1_inter          = (is_it_only_basis) ? (input_data.get_VS_const_LO_T1_basis ())          : (input_data.get_VS_const_LO_T1 ());
      VT_sigma_product_LO_T0_inter  = (is_it_only_basis) ? (input_data.get_VT_sigma_product_LO_T0_basis ())  : (input_data.get_VT_sigma_product_LO_T0 ());
      VT_sigma_product_LO_T1_inter  = (is_it_only_basis) ? (input_data.get_VT_sigma_product_LO_T1_basis ())  : (input_data.get_VT_sigma_product_LO_T1 ());
      V1_q2_NLO_inter               = (is_it_only_basis) ? (input_data.get_V1_q2_NLO_basis ())               : (input_data.get_V1_q2_NLO ());
      V2_k2_NLO_inter               = (is_it_only_basis) ? (input_data.get_V2_k2_NLO_basis ())               : (input_data.get_V2_k2_NLO ());
      V3_q2_sigma_product_NLO_inter = (is_it_only_basis) ? (input_data.get_V3_q2_sigma_product_NLO_basis ()) : (input_data.get_V3_q2_sigma_product_NLO ());
      V4_k2_sigma_product_NLO_inter = (is_it_only_basis) ? (input_data.get_V4_k2_sigma_product_NLO_basis ()) : (input_data.get_V4_k2_sigma_product_NLO ());
      V5_sigma_q_vector_k_NLO_inter = (is_it_only_basis) ? (input_data.get_V5_sigma_q_vector_k_NLO_basis ()) : (input_data.get_V5_sigma_q_vector_k_NLO ());
      V6_sigma_q_product_NLO_inter  = (is_it_only_basis) ? (input_data.get_V6_sigma_q_product_NLO_basis ())  : (input_data.get_V6_sigma_q_product_NLO ());
      V7_sigma_k_product_NLO_inter  = (is_it_only_basis) ? (input_data.get_V7_sigma_k_product_NLO_basis ())  : (input_data.get_V7_sigma_k_product_NLO ());
    }

  const int lmax_p = input_data.get_lmax_p ();
  
  const int lmax_for_basis_interaction = input_data.get_lmax_for_basis_interaction ();
  
  V_Coulomb_HO_basis.allocate (0.5 , lmax_p);
    
  //--// fill the table for each channel
  for (int l = 0 ; l <= lmax_p ; l++)
    {
      const int nmax_HO_lab_basis_l = (l <= lmax_for_basis_interaction) ? (nmax_HO_lab_tab_from_input_data(l)) : (0);

      const int nmax_HO_lab_basis_l_plus_one = nmax_HO_lab_basis_l + 1;

      for (double j = (l == 0) ? (0.5) : (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	V_Coulomb_HO_basis(l , j).allocate (nmax_HO_lab_basis_l_plus_one);
    }
  
  if (is_it_only_basis) V_Coulomb_HO_basis_calc (input_data);
}




void interaction_class::allocate_fill (const class interaction_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("interaction_class cannot be allocated twice in interaction_class::allocate_fill");

  is_it_only_basis = X.is_it_only_basis;
  
  is_there_cout = X.is_there_cout;
  
  is_there_cout_detailed = X.is_there_cout_detailed;
  
  TBME_inter = X.TBME_inter;
  
  inter_read = X.inter_read;
  
  are_there_pp_TBMEs = X.are_there_pp_TBMEs; 
  are_there_nn_TBMEs = X.are_there_nn_TBMEs; 
  are_there_pn_TBMEs = X.are_there_pn_TBMEs;

  a = X.a; 
  b = X.b; 
  V_SDI = X.V_SDI;

  R0 = X.R0;

  mu = X.mu;

  b_lab = X.b_lab; 
  b_relative = X.b_relative;

  V0_Minnesota_tab[0] = X.V0_Minnesota_tab[0]; 
  V0_Minnesota_tab[1] = X.V0_Minnesota_tab[1]; 
  V0_Minnesota_tab[2] = X.V0_Minnesota_tab[2];

  rho_Minnesota_tab[0] = X.rho_Minnesota_tab[0]; 
  rho_Minnesota_tab[1] = X.rho_Minnesota_tab[1]; 
  rho_Minnesota_tab[2] = X.rho_Minnesota_tab[2];

  u_Minnesota = X.u_Minnesota; 

  nu_three_body_like = X.nu_three_body_like;

  V_three_body_like = X.V_three_body_like;

  V0_ctr_tab[0] = X.V0_ctr_tab[0]; 
  V0_ctr_tab[1] = X.V0_ctr_tab[1]; 
  V0_ctr_tab[2] = X.V0_ctr_tab[2];

  alpha_ctr_tab[0] = X.alpha_ctr_tab[0]; 
  alpha_ctr_tab[1] = X.alpha_ctr_tab[1]; 
  alpha_ctr_tab[2] = X.alpha_ctr_tab[2];

  W_ctr_tab[0] = X.W_ctr_tab[0]; 
  W_ctr_tab[1] = X.W_ctr_tab[1]; 
  W_ctr_tab[2] = X.W_ctr_tab[2];

  B_ctr_tab[0] = X.B_ctr_tab[0]; 
  B_ctr_tab[1] = X.B_ctr_tab[1]; 
  B_ctr_tab[2] = X.B_ctr_tab[2];

  H_ctr_tab[0] = X.H_ctr_tab[0]; 
  H_ctr_tab[1] = X.H_ctr_tab[1]; 
  H_ctr_tab[2] = X.H_ctr_tab[2];

  M_ctr_tab[0] = X.M_ctr_tab[0]; 
  M_ctr_tab[1] = X.M_ctr_tab[1]; 
  M_ctr_tab[2] = X.M_ctr_tab[2];

  V0_so_tab[0] = X.V0_so_tab[0]; 
  V0_so_tab[1] = X.V0_so_tab[1];

  alpha_so_tab[0] = X.alpha_so_tab[0]; 
  alpha_so_tab[1] = X.alpha_so_tab[1];

  W_so_tab[0] = X.W_so_tab[0]; 
  W_so_tab[1] = X.W_so_tab[1];

  H_so_tab[0] = X.H_so_tab[0]; 
  H_so_tab[1] = X.H_so_tab[1];

  V0_t_tab[0] = X.V0_t_tab[0]; 
  V0_t_tab[1] = X.V0_t_tab[1]; 
  V0_t_tab[2] = X.V0_t_tab[2];

  alpha_t_tab[0] = X.alpha_t_tab[0]; 
  alpha_t_tab[1] = X.alpha_t_tab[1]; 
  alpha_t_tab[2] = X.alpha_t_tab[2];

  W_t_tab[0] = X.W_t_tab[0]; 
  W_t_tab[1] = X.W_t_tab[1]; 
  W_t_tab[2] = X.W_t_tab[2];

  H_t_tab[0] = X.H_t_tab[0]; 
  H_t_tab[1] = X.H_t_tab[1]; 
  H_t_tab[2] = X.H_t_tab[2];

  lmax_for_interaction = X.lmax_for_interaction; 
  lmax_multipole_expansion = X.lmax_multipole_expansion;

  BPmin_global_pp = X.BPmin_global_pp; 
  BPmax_global_pp = X.BPmax_global_pp;

  Jmin_global_pp = X.Jmin_global_pp; 
  Jmax_global_pp = X.Jmax_global_pp;

  BPmin_global_nn = X.BPmin_global_nn; 
  BPmax_global_nn = X.BPmax_global_nn;

  Jmin_global_nn = X.Jmin_global_nn; 
  Jmax_global_nn = X.Jmax_global_nn;

  BPmin_global_pn = X.BPmin_global_pn; 
  BPmax_global_pn = X.BPmax_global_pn;

  Jmin_global_pn = X.Jmin_global_pn; 
  Jmax_global_pn = X.Jmax_global_pn; 

  BPmin_global = X.BPmin_global; 
  BPmax_global = X.BPmax_global;

  Jmin_global = X.Jmin_global; 
  Jmax_global = X.Jmax_global;

  V_Gaussian_consts.allocate_fill (X.V_Gaussian_consts);

  nmax_HO_lab_tab.allocate_fill (X.nmax_HO_lab_tab);

  shells_HO_table.allocate_fill (X.shells_HO_table);
  shells_HO_indices.allocate_fill (X.shells_HO_indices);
  
  nmax_inter_lab_tab.allocate_fill (X.nmax_inter_lab_tab);

  shells_inter_table.allocate_fill (X.shells_inter_table);
  shells_inter_indices.allocate_fill (X.shells_inter_indices);

  r_bef_R_tab_GL.allocate_fill (X.r_bef_R_tab_GL);
  w_bef_R_tab_GL.allocate_fill (X.w_bef_R_tab_GL);

  HO_wfs_bef_R_tab_GL.allocate_fill (X.HO_wfs_bef_R_tab_GL);
  HO_dwfs_bef_R_tab_GL.allocate_fill (X.HO_dwfs_bef_R_tab_GL);

  r_aft_R_tab_GL.allocate_fill (X.r_aft_R_tab_GL);
  w_aft_R_tab_GL.allocate_fill (X.w_aft_R_tab_GL);

  HO_wfs_aft_R_tab_GL.allocate_fill (X.HO_wfs_aft_R_tab_GL);
  HO_dwfs_aft_R_tab_GL.allocate_fill (X.HO_dwfs_aft_R_tab_GL);

  r_bef_R_tab_GL_SGI_MSGI.allocate_fill (X.r_bef_R_tab_GL_SGI_MSGI);
  w_bef_R_tab_GL_SGI_MSGI.allocate_fill (X.w_bef_R_tab_GL_SGI_MSGI);
  
  HO_wfs_bef_R_tab_GL_SGI_MSGI.allocate_fill (X.HO_wfs_bef_R_tab_GL_SGI_MSGI);
  HO_dwfs_bef_R_tab_GL_SGI_MSGI.allocate_fill (X.HO_dwfs_bef_R_tab_GL_SGI_MSGI);

  HO_overlaps_Fermi.allocate_fill (X.HO_overlaps_Fermi);
  
  Vl_SGI_tab_GL.allocate_fill (X.Vl_SGI_tab_GL);

  TBMEs_pp_inter_lab.allocate_fill (X.TBMEs_pp_inter_lab);
  TBMEs_nn_inter_lab.allocate_fill (X.TBMEs_nn_inter_lab);
  TBMEs_pn_inter_lab.allocate_fill (X.TBMEs_pn_inter_lab);
  
  V_Coulomb_HO_basis.allocate_fill (X.V_Coulomb_HO_basis);
}






void interaction_class::deallocate ()
{
  V_Gaussian_consts.deallocate ();

  nmax_HO_lab_tab.deallocate ();

  shells_HO_table.deallocate ();
  shells_HO_indices.deallocate ();
  
  nmax_inter_lab_tab.deallocate ();

  shells_inter_table.deallocate ();
  shells_inter_indices.deallocate ();

  r_bef_R_tab_GL.deallocate ();
  w_bef_R_tab_GL.deallocate ();
  
  HO_wfs_bef_R_tab_GL.deallocate ();
  HO_dwfs_bef_R_tab_GL.deallocate ();

  r_aft_R_tab_GL.deallocate ();
  w_aft_R_tab_GL.deallocate ();
  
  HO_wfs_aft_R_tab_GL.deallocate ();
  HO_dwfs_aft_R_tab_GL.deallocate ();

  r_bef_R_tab_GL_SGI_MSGI.deallocate ();
  w_bef_R_tab_GL_SGI_MSGI.deallocate ();
  
  HO_wfs_bef_R_tab_GL_SGI_MSGI.deallocate ();
  HO_dwfs_bef_R_tab_GL_SGI_MSGI.deallocate ();

  HO_overlaps_Fermi.deallocate ();
  
  Vl_SGI_tab_GL.deallocate ();

  TBMEs_pp_inter_lab.deallocate ();
  TBMEs_nn_inter_lab.deallocate ();
  TBMEs_pn_inter_lab.deallocate ();

  is_it_only_basis = false;

  is_there_cout = false;

  is_there_cout_detailed = false;

  TBME_inter = NO_INTERACTION; 

  inter_read = NO_TBMES_READ;
  
  are_there_pp_TBMEs = false;
  are_there_nn_TBMEs = false;
  are_there_pn_TBMEs = false;

  a = 0.0;
  b = 0.0;

  V_SDI = 0.0;

  R0 = 0.0;

  mu = 0.0; 

  b_lab = 0.0; 

  b_relative = 0.0; 

  V0_Minnesota_tab[0] = 0.0;
  V0_Minnesota_tab[1] = 0.0;
  V0_Minnesota_tab[2] = 0.0; 

  rho_Minnesota_tab[0] = 0.0; 
  rho_Minnesota_tab[1] = 0.0;
  rho_Minnesota_tab[2] = 0.0; 

  u_Minnesota = 0.0;

  nu_three_body_like = 0.0;

  V_three_body_like = 0.0; 

  V0_ctr_tab[0] = 0.0; 
  V0_ctr_tab[1] = 0.0; 
  V0_ctr_tab[2] = 0.0; 

  alpha_ctr_tab[0] = 0.0; 
  alpha_ctr_tab[1] = 0.0; 
  alpha_ctr_tab[2] = 0.0; 

  W_ctr_tab[0] = 0.0; 
  W_ctr_tab[1] = 0.0; 
  W_ctr_tab[2] = 0.0; 

  B_ctr_tab[0] = 0.0; 
  B_ctr_tab[1] = 0.0; 
  B_ctr_tab[2] = 0.0; 

  H_ctr_tab[0] = 0.0; 
  H_ctr_tab[1] = 0.0; 
  H_ctr_tab[2] = 0.0; 

  M_ctr_tab[0] = 0.0; 
  M_ctr_tab[1] = 0.0; 
  M_ctr_tab[2] = 0.0; 

  V0_so_tab[0] = 0.0; 
  V0_so_tab[1] = 0.0; 

  alpha_so_tab[0] = 0.0; 
  alpha_so_tab[1] = 0.0; 

  W_so_tab[0] = 0.0; 
  W_so_tab[1] = 0.0; 

  H_so_tab[0] = 0.0; 
  H_so_tab[1] = 0.0; 

  V0_t_tab[0] = 0.0; 
  V0_t_tab[1] = 0.0; 
  V0_t_tab[2] = 0.0; 

  alpha_t_tab[0] = 0.0; 
  alpha_t_tab[1] = 0.0; 
  alpha_t_tab[2] = 0.0; 

  W_t_tab[0] = 0.0; 
  W_t_tab[1] = 0.0; 
  W_t_tab[2] = 0.0; 

  H_t_tab[0] = 0.0; 
  H_t_tab[1] = 0.0; 
  H_t_tab[2] = 0.0; 

  lmax_for_interaction = 0;

  lmax_multipole_expansion = 0;

  BPmin_global_pp = 2;
  BPmax_global_pp = 2;

  Jmin_global_pp = 0.0; 
  Jmax_global_pp = 0.0; 

  BPmin_global_nn = 2;
  BPmax_global_nn = 2;

  Jmin_global_nn = 0.0; 
  Jmax_global_nn = 0.0; 

  BPmin_global_pn = 2;
  BPmax_global_pn = 2;

  Jmin_global_pn = 0.0;
  Jmax_global_pn = 0.0;

  BPmin_global = 2;
  BPmax_global = 2;

  Jmin_global = 0.0;
  Jmax_global = 0.0;
}



bool interaction_class::is_it_filled () const
{
  return (TBME_inter != NO_INTERACTION);
}




// SGI multipolar expansion and interaction TBMEs put to zero
// -----------------------------------------------------------
// The multipolar expansion array of the SGI interaction (for SGI) and the HO TBMEs of the used interaction (HO or GHF expansion) are put to zero here.
// Interaction constants are not put to zero.

void interaction_class::zero ()
{
  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const unsigned int N_nlj_inter = get_N_nlj_inter ();

  if (is_it_SGI) Vl_SGI_tab_GL = 0.0;

  if (is_it_SGI_MSGI)
    {
      for (unsigned int a = 0 ; a < N_nlj_inter ; a++) 
	for (unsigned int b = 0 ; b < N_nlj_inter ; b++)
	  {
	    const class pair_str pair_ab(a , b);
	    
	    const unsigned int bp_ab = pair_ab.bp_determine (shells_inter_table , shells_inter_table);

	    const int Jmin_ab = pair_ab.Jmin_determine (shells_inter_table , shells_inter_table);
	    const int Jmax_ab = pair_ab.Jmax_determine (shells_inter_table , shells_inter_table);

	    const bool pair_ab_ordered = pair_ab.ordered ();

	    for (unsigned int c = 0 ; c < N_nlj_inter ; c++)
	      for (unsigned int d = 0 ; d < N_nlj_inter ; d++)
		{
		  const class pair_str pair_cd(c , d);

		  const unsigned int bp_cd = pair_cd.bp_determine (shells_inter_table , shells_inter_table);

		  if ((bp_ab == bp_cd) && (pair_ab <= pair_cd))
		    {
		      const int Jmin_cd = pair_cd.Jmin_determine (shells_inter_table , shells_inter_table);
		      const int Jmax_cd = pair_cd.Jmax_determine (shells_inter_table , shells_inter_table);
		      
		      const bool pair_cd_ordered = pair_cd.ordered ();

		      const bool are_pairs_ordered = (pair_ab_ordered && pair_cd_ordered);

		      const bool is_pp_here = (are_there_pp_TBMEs && are_pairs_ordered && (bp_ab >= BPmin_global_pp) && (bp_ab <= BPmax_global_pp));

		      const int Jmin_local = max (Jmin_ab , Jmin_cd);
		      const int Jmax_local = min (Jmax_ab , Jmax_cd);
		      
		      const int Jmin_pp = max (Jmin_local , Jmin_global_pp);
		      const int Jmax_pp = min (Jmax_local , Jmax_global_pp);

		      if (is_pp_here)
			{
			  for (int J = Jmin_pp ; J <= Jmax_pp ; J++) TBMEs_pp_inter_lab(J , a , b , c , d) = 0.0;
			}
		    }
		}
	  }
    }
  else
    {
      for (unsigned int a = 0 ; a < N_nlj_inter ; a++)
	for (unsigned int b = 0 ; b < N_nlj_inter ; b++)
	  {
	    const class pair_str pair_ab(a , b);

	    const unsigned int bp_ab = pair_ab.bp_determine (shells_inter_table , shells_inter_table);

	    const int Jmin_ab = pair_ab.Jmin_determine (shells_inter_table , shells_inter_table);
	    const int Jmax_ab = pair_ab.Jmax_determine (shells_inter_table , shells_inter_table);
	    
	    const bool pair_ab_ordered = pair_ab.ordered ();

	    for (unsigned int c = 0 ; c < N_nlj_inter ; c++)
	      for (unsigned int d = 0 ; d < N_nlj_inter ; d++)
		{
		  const class pair_str pair_cd(c , d);
		  
		  const unsigned int bp_cd = pair_cd.bp_determine (shells_inter_table , shells_inter_table);

		  if ((bp_ab == bp_cd) && (pair_ab <= pair_cd))
		    {
		      const int Jmin_cd = pair_cd.Jmin_determine (shells_inter_table , shells_inter_table);
		      const int Jmax_cd = pair_cd.Jmax_determine (shells_inter_table , shells_inter_table);
		      
		      const bool pair_cd_ordered = pair_cd.ordered ();

		      const bool are_pairs_ordered = (pair_ab_ordered && pair_cd_ordered);

		      const bool is_pp_here = (are_there_pp_TBMEs && are_pairs_ordered && (bp_ab >= BPmin_global_pp) && (bp_ab <= BPmax_global_pp));
		      const bool is_nn_here = (are_there_nn_TBMEs && are_pairs_ordered && (bp_ab >= BPmin_global_nn) && (bp_ab <= BPmax_global_nn));

		      const bool is_pn_here = (are_there_pn_TBMEs && (bp_ab >= BPmin_global_pn) && (bp_ab <= BPmax_global_pn));

		      const int Jmin_local = max (Jmin_ab , Jmin_cd);
		      const int Jmax_local = min (Jmax_ab , Jmax_cd);
		      
		      const int Jmin_pp = max (Jmin_local , Jmin_global_pp) , Jmax_pp = min (Jmax_local , Jmax_global_pp);
		      const int Jmin_nn = max (Jmin_local , Jmin_global_nn) , Jmax_nn = min (Jmax_local , Jmax_global_nn);
		      const int Jmin_pn = max (Jmin_local , Jmin_global_pn) , Jmax_pn = min (Jmax_local , Jmax_global_pn);

		      if (is_pp_here)
			{
			  for (int J = Jmin_pp ; J <= Jmax_pp ; J++) TBMEs_pp_inter_lab(J , a , b , c , d) = 0.0;
			}

		      if (is_nn_here)
			{
			  for (int J = Jmin_nn ; J <= Jmax_nn ; J++) TBMEs_nn_inter_lab(J , a , b , c , d) = 0.0;
			}

		      if (is_pn_here)
			{
			  for (int J = Jmin_pn ; J <= Jmax_pn ; J++) TBMEs_pn_inter_lab(J , a , b , c , d) = 0.0;
			}
		    }
		}
	  }
    }
}










// Calculation of the SGI multipolar expansion
// -------------------------------------------
// One has V_SGI(\vec{r},\vec{r'}) = \sum_l (2.l + 1) . I^l . exp (-[(r - r')/mu]^2) exp (-(2/mu^2) . r.r') / (-(2.i/mu^2) r.r') (4Pi/(2l+1)) Fl(-(2.i/mu^2) r.r') (Yl(1) . Yl(2))
// with r' = 2.R0 - r, F being the regular Riccati-Bessel function, R0 and mu the radius and range of the SGI interaction.
//
// (2.l + 1) . I^l . exp (-[(r - r')/mu]^2) exp (-(2/mu^2) . r.r') / (-(2.i/mu^2) r.r') F(l , -(2.i/mu^2) r.r') is then stored in Vl_SGI_tab_GL.
//
// F is calculated directly if |(2.i/mu^2) r.r'| <= 1, and with scaled Hankel functions otherwise, with which the exp (-(2/mu^2) . r.r') cancels out, for stability.
// Indeed, F(l,z) = (H+(l,z) - H-(l,z))/(2i) = (H+_scaled(l,z) . exp (i.z) - H-_scaled(l,z) . exp (-i.z))/(2i), and one can see that exp (i.z) simplifies with exp (-(2/mu^2) . r.r') above.
// The presence of exp (-2.i.z) along with H-(l,z) is not important as |exp (-2.i.z)| -> 0 with |z| -> +oo in our case.
//
// Fl(z)/z is replaced by Fl'(z) for z=0.

void interaction_class::SGI_radial_tables_calc ()
{
  if (!is_it_SGI_determine (TBME_inter)) error_message_print_abort ("SGI interaction only in interaction_class::SGI_radial_tables_calc");

  const unsigned int N_bef_R_GL = r_bef_R_tab_GL_SGI_MSGI.dimension (0);
  
  const double two_R0 = 2*R0;
  
  const int lmax_multipole_expansion_plus_one = lmax_multipole_expansion + 1;

  const complex<double> I(0 , 1);
  
  const complex<double> two_I(0 , 2);
  
  const complex<double> mu_factor = -two_I/(mu*mu);  

  class array<class Coulomb_wave_functions> Riccati_Bessel_tab(lmax_multipole_expansion_plus_one);
  
  for (int l = 0 ; l <= lmax_multipole_expansion ; l++) Riccati_Bessel_tab(l).initialize (true , l , 0);

  class array<complex<double> > l_factor_tab(lmax_multipole_expansion_plus_one);
  
  for (int l = 0 ; l <= lmax_multipole_expansion ; l++) l_factor_tab(l) = (2*l + 1)*pow (I , l);

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double r = r_bef_R_tab_GL_SGI_MSGI(i);

      const double rp = two_R0 - r;

      const double x_over_mu = (r - rp)/mu;

      const double Gaussian = exp (-x_over_mu*x_over_mu);

      const complex<double> z = mu_factor*r*rp;

      const complex<double> scale = exp (-I*z);

      const complex<double> scale_square = scale*scale;

      const complex<double> Gaussian_scale_over_z = (z != 0.0) ? (Gaussian*scale/z) : (NADA);

      const complex<double> Gaussian_over_two_I_z = (z != 0.0) ? (Gaussian/(two_I*z)) : (NADA);

      const double abs_z = abs (z);

      for (int l = 0 ; l <= lmax_multipole_expansion ; l++)
	{
	  class Coulomb_wave_functions &Riccati_Bessel = Riccati_Bessel_tab(l);

	  if (abs_z <= 1.0)
	    {
	      complex<double> F = 0.0;
	      complex<double> dF = 0.0;
	      
	      Riccati_Bessel.F_dF (z , F , dF);

	      Vl_SGI_tab_GL(l , i) = (z == 0) ? (real (l_factor_tab(l)*dF)*Gaussian) : (real (l_factor_tab(l)*F*Gaussian_scale_over_z));
	    }
	  else
	    {
	      complex<double> scaled_Hplus = 0.0;
	      complex<double> scaled_Hminus = 0.0;
	      complex<double> dH = 0.0;
	      
	      Riccati_Bessel.H_dH_scaled ( 1 , z , scaled_Hplus  , dH);
	      Riccati_Bessel.H_dH_scaled (-1 , z , scaled_Hminus , dH);

	      Vl_SGI_tab_GL(l , i) = real (l_factor_tab(l)*(scaled_Hplus - scaled_Hminus*scale_square)*Gaussian_over_two_I_z);
	    }
	}
    }
}





// Calculations of HO wave functions and Gauss-Legendre radial arrays
// ------------------------------------------------------------------
// Gauss-Legendre radii, weights and HO wave functions are calculated on [0:R], [R:R_real_max] and [0:2.R0] arrays
// with R0 the radius of the SGI interaction, R the rotation point and R_real_max the maximal radius considered on the real-axis. All HO states must be negligible therein

void interaction_class::HO_radial_tables_calc (
					       const double R , 
					       const double R_real_max)
{	
  const double two_R0 = 2.0 * R0;

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (R , R_real_max , r_aft_R_tab_GL , w_aft_R_tab_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , two_R0 , r_bef_R_tab_GL_SGI_MSGI , w_bef_R_tab_GL_SGI_MSGI);

  HO_wave_functions::HO_3D::u_du_r_tables_calc (b_lab , r_bef_R_tab_GL , HO_wfs_bef_R_tab_GL , HO_dwfs_bef_R_tab_GL);
  HO_wave_functions::HO_3D::u_du_r_tables_calc (b_lab , r_aft_R_tab_GL , HO_wfs_aft_R_tab_GL , HO_dwfs_aft_R_tab_GL);

  HO_wave_functions::HO_3D::u_du_r_tables_calc (b_lab , r_bef_R_tab_GL_SGI_MSGI , HO_wfs_bef_R_tab_GL_SGI_MSGI , HO_dwfs_bef_R_tab_GL_SGI_MSGI);
}






// Calculation of the Fermi cut function matrix elements between HO functions
// --------------------------------------------------------------------------
// One calculates <n'[HO] l j | F(r) | n[HO] l j> where F(r) is a Fermi function used for stability, as potentials do not necessarily vanish at large distance.
// They are used in the context of GSM-CC as one uses a Fermi cut function in the HF/MSDHF potentials and a HO representation of the HF/MSDHF potentials is demanded therein.

void interaction_class::HO_overlaps_Fermi_calc (
						const double R_cut_function ,
						const double d_cut_function)

{
  const unsigned int N_bef_R_GL = r_bef_R_tab_GL.dimension (0);
  const unsigned int N_aft_R_GL = r_aft_R_tab_GL.dimension (0);

  const unsigned int N_nlj_HO = get_N_nlj_HO ();

  for (unsigned int s = 0 ; s < N_nlj_HO ; s++)
    {
      const class nlj_struct &shell_HO = shells_HO_table(s);
      
      const int n_HO = shell_HO.get_n ();
      
      const int l = shell_HO.get_l ();

      const int nmax_HO_l = (l <= lmax_for_interaction) ? (nmax_HO_lab_tab(l)) : (0);

      const int nmax_HO_l_plus_one = nmax_HO_l + 1;

      class vector_class<complex<double> > &HO_overlaps_Fermi_s  = HO_overlaps_Fermi(s);

      HO_overlaps_Fermi_s.allocate  (nmax_HO_l_plus_one);

      HO_overlaps_Fermi_s  = 0.0;

      for (int np_HO = 0 ; np_HO <= nmax_HO_l ; np_HO++)
	{
	  complex<double> HO_overlap_Fermi  = 0.0;

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	    {
	      const double r = r_bef_R_tab_GL(i);

	      const double Fermi_r = Fermi_like_function (R_cut_function , d_cut_function , r);
	      	      
	      HO_overlap_Fermi += Fermi_r*HO_wfs_bef_R_tab_GL (n_HO , l , i)*HO_wfs_bef_R_tab_GL (np_HO , l , i)*w_bef_R_tab_GL(i);
	    }

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {	
	      const double r = r_aft_R_tab_GL(i);

	      const double Fermi_r = Fermi_like_function (R_cut_function , d_cut_function , r);
	      	      
	      HO_overlap_Fermi += Fermi_r*HO_wfs_aft_R_tab_GL (n_HO , l , i)*HO_wfs_aft_R_tab_GL (np_HO , l , i)*w_aft_R_tab_GL(i);
	    }

	  HO_overlaps_Fermi_s (np_HO) = HO_overlap_Fermi;
	}
    }
}





// Calculation of the HO representation of the one-body Coulomb potential generated by a Gaussian charged sphere
// -------------------------------------------------------------------------------------------------------------
// One separates the infinite-range of the Coulomb potential, given by a one-body Coulomb potential generated by a Gaussian charged sphere, from the Coulomb interaction.
// Indeed, the difference between the Coulomb interaction and the one-body Coulomb potential generated by a Gaussian charged sphere is finite range.
// Thus it can be expanded in a HO basis.
// One then needs to have the one-body Coulomb potential in a HO basis.
// It is initialized to zero, and calculated if does not use the neutron basis potential, if the Coulomb Hamiltonian is considered, and if the used charge is not zero.

void interaction_class::local_potential_HO_basis_calc (
						       const enum potential_type H_potential , 
						       const int Zval_charge_potential , 
						       const double R_charge)
{
  if (Zval_charge_potential == 0) return; 

  const unsigned int N_bef_R_GL = r_bef_R_tab_GL.dimension (0);
  const unsigned int N_aft_R_GL = r_aft_R_tab_GL.dimension (0);

  const unsigned int N_nlj_HO = get_N_nlj_HO ();

  const int lmax_p = V_Coulomb_HO_basis.get_lmax ();

  const class Coulomb_potential_class Coulomb_potential(false , PROTON , Zval_charge_potential , NADA);
  
  class array<double> V_Coulomb_bef_R_tab_GL(N_bef_R_GL);
  class array<double> V_Coulomb_aft_R_tab_GL(N_aft_R_GL);
  
  Coulomb_potential::local_potential_calc (false , H_potential , PROTON , Zval_charge_potential , R_charge , r_bef_R_tab_GL , V_Coulomb_bef_R_tab_GL);

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) V_Coulomb_aft_R_tab_GL(i) = Coulomb_potential.point_potential_calc (r_aft_R_tab_GL(i));
  
  for (int l = 0 ; l <= lmax_p ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	class matrix<complex<double> > &V_Coulomb_HO_basis_lj = V_Coulomb_HO_basis(l , j);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
	for (unsigned int a = 0 ; a < N_nlj_HO ; a++)
	  {
	    const class nlj_struct &sa = shells_HO_table(a);

	    const int na = sa.get_n ();
	    const int la = sa.get_l ();

	    const double ja = sa.get_j ();

	    if (same_lj (l , j , la , ja))
	      {
		for (unsigned int b = 0 ; b <= a ; b++)
		  {
		    const class nlj_struct &sb = shells_HO_table(b);

		    if (same_lj (sa , sb))
		      {
			const int nb = sb.get_n ();

			double radial_integral = 0.0;
			
			for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) radial_integral += HO_wfs_bef_R_tab_GL(na , l , i)*HO_wfs_bef_R_tab_GL(nb , l , i)*w_bef_R_tab_GL(i)*V_Coulomb_bef_R_tab_GL(i);			
			for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) radial_integral += HO_wfs_aft_R_tab_GL(na , l , i)*HO_wfs_aft_R_tab_GL(nb , l , i)*w_aft_R_tab_GL(i)*V_Coulomb_aft_R_tab_GL(i);

			V_Coulomb_HO_basis_lj(na , nb) = V_Coulomb_HO_basis_lj(nb , na) = radial_integral;
		      }
		  }
	      }
	  }
      }
}

void interaction_class::V_Coulomb_HO_basis_calc (const class input_data_str &input_data)
{
  const int lp_max = input_data.get_lmax_p ();
    
  const enum potential_type H_potential = input_data.get_H_potential ();
  
  const double R_charge = input_data.get_R_charge ();
  
  const bool neutron_basis_potential = input_data.get_neutron_basis_potential ();

  const bool is_Coulomb_Hamiltonian_here = input_data.get_is_Coulomb_Hamiltonian_here ();
  
  const int Z_core = input_data.get_Z_core ();
  
  const int Z_charge_basis_potential = input_data.get_Z_charge_basis_potential ();
  
  const int Zval_charge_basis_potential = Z_charge_basis_potential - Z_core;

  //--// fill the table for each channel
  for (int l = 0 ; l <= lp_max ; l++)
    for (double j = (l == 0) ? (0.5) : (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      V_Coulomb_HO_basis(l , j) = 0.0;
  
  if (!neutron_basis_potential && is_Coulomb_Hamiltonian_here && (H_potential != WS) && (Zval_charge_basis_potential > 0))
    local_potential_HO_basis_calc (H_potential , Zval_charge_basis_potential , R_charge);
}







// Read of relative TBMEs from a file
// ----------------------------------
// One reads relative TBMEs from a file, which are given in HO or Bessel function basis.
//
// They are stored as: n[relative] , l[relative]  , n'[relative] , lp[relative] , S , J[relative] , Tz , TBME in HO basis
//
//                     l[relative] , l'[relative] , J[relative] , S , J[relative] , Tz , k.index[relative] , k'.index[relative] , TBME for Bessel function basis
//                     k and k' are retrieved from an array of k values and their indices. They are Gauss-Legendre abscissas, so that one can calculate k-integrals with them.
//
// They are ignored if one just considers proton-proton, neutron-neutron and proton-neutron and Tz != -1,1,0, or if their quantum numbers exceed the maximal value given in the input file.
//
// In the HO file, b[relative] is given as first value to check if it corresponds to the HO length of the class.

void interaction_class::TBMEs_HO_relative_read (
						const int Jn_relative_max , 
						class array<double> &TBMEs_pp_HO_relative , 
						class array<double> &TBMEs_nn_HO_relative , 
						class array<double> &TBMEs_pn_HO_relative) const
{ 
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in interaction_class::TBMEs_HO_relative_read.");

  if (TBME_inter != REALISTIC_INTERACTION) error_message_print_abort ("Realistic interaction only in interaction_class::TBMEs_HO_relative_read");

  const int nmax_HO_lab = nmax_calc (nmax_HO_lab_tab);

  const int n_relative_max = 2*nmax_HO_lab + lmax_for_interaction;

  const int ln_relative_max = Jn_relative_max + 1;

  const string TBMEs_HO_relative_file_name = STORAGE_DIR + "v2body_HO_rel.dat";

  ifstream TBMEs_HO_relative_file(TBMEs_HO_relative_file_name.c_str ());
  
  file_existence_check (TBMEs_HO_relative_file_name , TBMEs_HO_relative_file);

  TBMEs_pp_HO_relative = 0.0;
  TBMEs_nn_HO_relative = 0.0;
  TBMEs_pn_HO_relative = 0.0;

  double b_relative_from_file;

  TBMEs_HO_relative_file >> b_relative_from_file;
  
  if (abs ((b_relative_from_file - b_relative)*M_SQRT2) > precision)
    error_message_print_abort ("b_relative of interaction_class and b_relative from interaction file are different in interaction_class::TBMEs_HO_relative_read.");
  
  // There is a multiplication by sqrt (2) as b_relative is sqrt (2).b_lab, and b_lab often has just a few digits.

  while (!TBMEs_HO_relative_file.eof ())
    {
      int n_relative , np_relative;
      int l_relative , lp_relative;
      
      int S;
      int J_relative;
      int Tz;
      
      double TBME_HO_relative;

      TBMEs_HO_relative_file >> n_relative >> l_relative >> np_relative >> lp_relative >> S >> J_relative >> Tz >> TBME_HO_relative;

      if (TBMEs_HO_relative_file.eof ()) break;

      if ((Tz == -1) && !are_there_pp_TBMEs) continue;
      if ((Tz == 1)  && !are_there_nn_TBMEs) continue;
      if ((Tz == 0)  && !are_there_pn_TBMEs) continue;

      if ((n_relative <= n_relative_max) && (np_relative <= n_relative_max) && (l_relative <= ln_relative_max) && (lp_relative <= ln_relative_max) && (J_relative <= Jn_relative_max))
	{
	  switch (Tz)
	    {
	    case -1: TBMEs_pp_HO_relative(n_relative , l_relative , np_relative , lp_relative , S , J_relative) = TBME_HO_relative; break;
	    case  1: TBMEs_nn_HO_relative(n_relative , l_relative , np_relative , lp_relative , S , J_relative) = TBME_HO_relative; break;
	    case  0: TBMEs_pn_HO_relative(n_relative , l_relative , np_relative , lp_relative , S , J_relative) = TBME_HO_relative; break;
	      
	    default: abort_all ();
	    }
	}
    }
}

void interaction_class::TBMEs_Bessel_read (
					   const int Jn_relative_max , 
					   class array<double> &TBMEs_pp_k_relative , 
					   class array<double> &TBMEs_nn_k_relative , 
					   class array<double> &TBMEs_pn_k_relative) const
{ 
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in interaction_class::TBMEs_Bessel_read.");

  if (TBME_inter != REALISTIC_INTERACTION)
    error_message_print_abort ("Realistic interaction only in interaction_class::TBMEs_Bessel_read");
  
  const int ln_relative_max = Jn_relative_max + 1;

  const string TBMEs_k_relative_file_name = STORAGE_DIR + "v2body_Bessel_rel.dat";

  ifstream TBMEs_k_relative_file(TBMEs_k_relative_file_name.c_str ());
  
  file_existence_check (TBMEs_k_relative_file_name , TBMEs_k_relative_file);

  TBMEs_pp_k_relative = 0.0;
  TBMEs_nn_k_relative = 0.0;
  TBMEs_pn_k_relative = 0.0;

  while (!TBMEs_k_relative_file.eof ())
    {
      unsigned int ik_relative;
      unsigned int ikp_relative;

      int l_relative;
      int lp_relative;

      int S;
      int J_relative;
      int Tz;

      double TBME_k_relative;

      TBMEs_k_relative_file >> l_relative >> lp_relative >> J_relative >> S >> Tz >> ik_relative >> ikp_relative >> TBME_k_relative;

      if (TBMEs_k_relative_file.eof ()) break;

      if ((Tz == -1) && !are_there_pp_TBMEs) continue;
      if ((Tz == 1)  && !are_there_nn_TBMEs) continue;
      if ((Tz == 0)  && !are_there_pn_TBMEs) continue;

      if ((l_relative <= ln_relative_max) && (lp_relative <= ln_relative_max) && (J_relative <= Jn_relative_max))
	{
	  switch (Tz)
	    {
	    case -1: TBMEs_pp_k_relative(ik_relative , l_relative , ikp_relative , lp_relative , S , J_relative) = TBME_k_relative; break;
	    case  1: TBMEs_nn_k_relative(ik_relative , l_relative , ikp_relative , lp_relative , S , J_relative) = TBME_k_relative; break;
	    case  0: TBMEs_pn_k_relative(ik_relative , l_relative , ikp_relative , lp_relative , S , J_relative) = TBME_k_relative; break;
	      
	    default: abort_all ();
	    }
	}
    }
}









// HO relative TBMEs calculated from Bessel function relative TBMEs
// ----------------------------------------------------------------
// One first reads the array of mesh Gauss-Legendre linear momenta and weights.
// The Bessel function relative TBMEs are read afterwards.
// From the analytical values of HO wave functions in k-pscae, one calculates TBMEs in relative HO basis.
//
// The formula is: <n'_rel[HO] l'_rel S J_rel | V | n_rel[HO] l_rel S J_rel> = \int k_rel,k'_rel k_rel^2 k'_rel^2 <k'_rel l'_rel S J_rel | V | k_rel l_rel S J_rel> u_HO(l_rel,k_rel) u_HO(l'_rel,k'_rel) dk_rel dk'_rel
//                                                                           ~ \sum_{k_rel,k'_rel} k'_rel^2 <k'_rel l'_rel S J_rel | V | k_rel l_rel S J_rel> u_HO(l_rel,k_rel) u_HO(l'_rel,k'_rel) w_rel w'_rel
//
// The HO relative k-length is the inverse of the HO relative length in r-space.
//
// One checks for antisymmetry and angular momentum couplings (J_rel = l_rel + S, J_rel = l'_rel + S) of the two-body states and calculates TBMEs only if they are fulfilled.
//
// The master process reads and calculates matrix elements, and distributes them to all other nodes afterwards.

void interaction_class::TBMEs_HO_relative_calc_from_Bessel_read (
								 const int Jn_relative_max , 
								 class array<double> &TBMEs_pp_HO_relative , 
								 class array<double> &TBMEs_nn_HO_relative , 
								 class array<double> &TBMEs_pn_HO_relative) const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in interaction_class::TBMEs_HO_relative_calc_from_Bessel_read.");

  if (TBME_inter != REALISTIC_INTERACTION) error_message_print_abort ("Realistic interaction only in interaction_class::TBMEs_HO_relative_calc_from_Bessel_read");

  const int n_relative_max = TBMEs_pp_HO_relative.dimension (0) - 1;
  
  const int n_relative_max_plus_one = n_relative_max + 1;

  const int Jn_relative_max_plus_one = TBMEs_pp_HO_relative.dimension (5);

  const int ln_relative_max =  TBMEs_pp_HO_relative.dimension (1) - 1;

  const int ln_relative_max_plus_one = ln_relative_max + 1;

  const string mesh_file_name = STORAGE_DIR + "mesh_Bessel_rel.dat";

  const unsigned int Nk = elements_number<double> (mesh_file_name)/2;

  class array<double> TBMEs_pp_k_relative(Nk , ln_relative_max_plus_one , Nk , ln_relative_max_plus_one , 2 , Jn_relative_max_plus_one);
  class array<double> TBMEs_nn_k_relative(Nk , ln_relative_max_plus_one , Nk , ln_relative_max_plus_one , 2 , Jn_relative_max_plus_one);
  class array<double> TBMEs_pn_k_relative(Nk , ln_relative_max_plus_one , Nk , ln_relative_max_plus_one , 2 , Jn_relative_max_plus_one);
  
  class array<double> HO_wfs_momentum(n_relative_max_plus_one , ln_relative_max_plus_one , Nk);

  class array<double> weight_k_table(Nk , Nk);

  class array<double> k_table(Nk);
  class array<double> w_table(Nk);

  ifstream mesh_file(mesh_file_name.c_str ());

  file_existence_check (mesh_file_name , mesh_file);

  for (unsigned int i = 0 ; i < Nk ; i++) mesh_file >> k_table(i) >> w_table(i);

  TBMEs_Bessel_read (Jn_relative_max , TBMEs_pp_k_relative , TBMEs_nn_k_relative , TBMEs_pn_k_relative);

  const double bk_relative = 1.0/b_relative;
  			      
  HO_wave_functions::HO_3D::u_k_tables_calc (bk_relative , k_table , HO_wfs_momentum);
  
  for (unsigned int ik = 0 ; ik < Nk ; ik++)
    for (unsigned int ikp = 0 ; ikp < Nk ; ikp++)
      weight_k_table(ik , ikp) = w_table(ik)*w_table(ikp)*k_table(ik)*k_table(ikp);

  for (int l_relative = 0 ; l_relative <= ln_relative_max ; l_relative++) 
    for (int lp_relative = 0 ; lp_relative <= ln_relative_max ; lp_relative++)
      {
	if ((l_relative + lp_relative)%2 == 0)
	  {
	    for (int S = 0 ; S <= 1 ; S++) 
	      {
		const bool is_it_antisymmetric = ((l_relative + S)%2 == 0);

		const int J_relative_min_l_relative_S  = abs (l_relative  - S);
		const int J_relative_min_lp_relative_S = abs (lp_relative - S);

		const int J_relative_max_l_relative_S  = min (l_relative  + S , Jn_relative_max);
		const int J_relative_max_lp_relative_S = min (lp_relative + S , Jn_relative_max);

		const int J_relative_min = max (J_relative_min_l_relative_S , J_relative_min_lp_relative_S);
		const int J_relative_max = min (J_relative_max_l_relative_S , J_relative_max_lp_relative_S);

		for (int n_relative = 0 ; n_relative <= n_relative_max ; n_relative++) 
		  for (int np_relative = 0 ; np_relative <= n_relative_max ; np_relative++)
		    for (int J_relative = J_relative_min ; J_relative <= J_relative_max ; J_relative++)
		      {
			double TBME_HO_pp = 0.0;
			double TBME_HO_nn = 0.0;
			double TBME_HO_pn = 0.0;

			for (unsigned int ik = 0 ; ik < Nk ; ik++)
			  for (unsigned int ikp = 0 ; ikp < Nk ; ikp++)
			    {
			      const double weight_k_HO_term = HO_wfs_momentum(n_relative , l_relative , ik)*HO_wfs_momentum(np_relative , lp_relative , ikp)*weight_k_table(ik , ikp);
			      
			      if (is_it_antisymmetric)
				{
				  TBME_HO_pp += weight_k_HO_term*TBMEs_pp_k_relative(ik , l_relative , ikp , lp_relative , S , J_relative);
				  TBME_HO_nn += weight_k_HO_term*TBMEs_nn_k_relative(ik , l_relative , ikp , lp_relative , S , J_relative);
				}

			      TBME_HO_pn += weight_k_HO_term*TBMEs_pn_k_relative(ik , l_relative , ikp , lp_relative , S , J_relative);			      
			    }

			TBMEs_pp_HO_relative(n_relative , l_relative , np_relative , lp_relative , S , J_relative) = TBME_HO_pp;
			TBMEs_nn_HO_relative(n_relative , l_relative , np_relative , lp_relative , S , J_relative) = TBME_HO_nn;
			TBMEs_pn_HO_relative(n_relative , l_relative , np_relative , lp_relative , S , J_relative) = TBME_HO_pn;			
		      }
	      }
	  }
      }
}

void interaction_class::TBMEs_real_inter_HO_relative_calc (
							   const int Jn_relative_max , 
							   class array<double> &TBMEs_pp_HO_relative , 
							   class array<double> &TBMEs_nn_HO_relative , 
							   class array<double> &TBMEs_pn_HO_relative) const
{
  if (TBME_inter != REALISTIC_INTERACTION) error_message_print_abort ("Realistic interaction only in interaction_class::TBMEs_real_inter_HO_relative_calc");

  TBMEs_pp_HO_relative = 0.0;
  TBMEs_nn_HO_relative = 0.0;
  TBMEs_pn_HO_relative = 0.0;

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      switch (inter_read)
	{
	case RELATIVE_BESSEL_TBMES_READ: TBMEs_HO_relative_calc_from_Bessel_read (Jn_relative_max , TBMEs_pp_HO_relative , TBMEs_nn_HO_relative , TBMEs_pn_HO_relative); break;

	case RELATIVE_HO_TBMES_READ: TBMEs_HO_relative_read (Jn_relative_max , TBMEs_pp_HO_relative , TBMEs_nn_HO_relative , TBMEs_pn_HO_relative); break;

	default: error_message_print_abort ("inter_read is RELATIVE_BESSEL_TBMES_READ or RELATIVE_HO_TBMES_READ in interaction_class::TBMEs_real_inter_HO_relative_calc.");
	}
    }

#ifdef UseMPI
  
  TBMEs_pp_HO_relative.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
  TBMEs_nn_HO_relative.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
  TBMEs_pn_HO_relative.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
  
#endif
}











// Read of laboratory HO TBMEs from a file
// ---------------------------------------
// One reads laboratory TBMEs <cd | V |ab>_J from a file, which are given in HO basis.
//
// They are stored as: nlj strings for a,b,c,d states (e.g. 0p3/2 0d5/2 1s1/2 0f7/2), total angular momentum J, Tz, TBME in HO basis
// As indices of a,b,c,d states might not be the same in the interaction file and in the interaction class, reordering phases have to be taken into account.
//
// They are ignored if one just considers proton-proton, neutron-neutron and proton-neutron and Tz != -1,1,0, or if their quantum numbers exceed the maximal value given in the input file.
//
// In the HO file, b[laboratory] is given as first value to check if it is the same as the HO length of the class.
//
// There are two routines with HO states, one which reads a file in pp/nn/pn formalism and one in isospin formalism.
// The isospin formalism is for the moment for the EFT interaction only. It is converted to pp/nn/pn formalism therein,
// When one reads pp/nn/pn matrix elements, all pn matrix elements must be present i.e. <ab|V|cd>, <ba|V|cd>, <ab|V|dc>, and <ba|V|dc>. No test is made.

void interaction_class::TBMEs_HO_lab_pp_nn_pn_read_add (const string TBMEs_HO_lab_file_name , const double V_parameter)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in interaction_class::TBMEs_HO_lab_pp_nn_pn_read_add.");

  if (V_parameter == 0.0) return;
  
  if (are_there_pp_TBMEs)
    {
      if (!is_it_mixed_determine (PROTON , TBME_inter)) error_message_print_abort ("HO-defined interaction only in interaction_class::TBMEs_HO_lab_pp_nn_pn_read_add (pp/nn/pn)");
    }
  else
    {
      if (!is_it_nuclear_mixed_determine (TBME_inter)) error_message_print_abort ("HO-defined interaction only in interaction_class::TBMEs_HO_lab_pp_nn_pn_read_add (nn/pn)");
    }

  ifstream TBMEs_HO_lab_file(TBMEs_HO_lab_file_name.c_str ());
  
  file_existence_check (TBMEs_HO_lab_file_name , TBMEs_HO_lab_file);

  double b_lab_from_file;

  TBMEs_HO_lab_file >> b_lab_from_file;

  if (abs (b_lab_from_file - b_lab) > precision)
    error_message_print_abort ("b_lab of interaction_class and b_lab from interaction file are different in interaction_class::TBMEs_HO_lab_pp_nn_pn_read_add.");

  while (!TBMEs_HO_lab_file.eof ())
    {
      string sa;
      string sb;
      string sc;
      string sd;

      int J;
      int Tz;
      
      double TBME_HO_lab;

      TBMEs_HO_lab_file >> sa >> sb >> sc >> sd >> J >> Tz >> TBME_HO_lab;

      TBME_HO_lab *= V_parameter;
      
      if (TBMEs_HO_lab_file.eof ()) break;
	
      if ((Tz == -1) && !are_there_pp_TBMEs) continue;
      if ((Tz == 1)  && !are_there_nn_TBMEs) continue;
      if ((Tz == 0)  && !are_there_pn_TBMEs) continue;

      const int la = determine_l (sa);
      const int lb = determine_l (sb);
      const int lc = determine_l (sc);
      const int ld = determine_l (sd);

      if ((la > lmax_for_interaction) || (lb > lmax_for_interaction) || (lc > lmax_for_interaction) || (ld > lmax_for_interaction)) continue;

      const int na = determine_n (sa);
      const int nb = determine_n (sb);
      const int nc = determine_n (sc);
      const int nd = determine_n (sd);

      if ((na > nmax_HO_lab_tab(la)) || (nb > nmax_HO_lab_tab(lb)) || (nc > nmax_HO_lab_tab(lc)) || (nd > nmax_HO_lab_tab(ld))) continue;

      const double ja = determine_j (sa);
      const double jb = determine_j (sb);
      const double jc = determine_j (sc);
      const double jd = determine_j (sd);

      check_partial_wave_nucleon (la , ja);
      check_partial_wave_nucleon (lb , jb);
      check_partial_wave_nucleon (lc , jc);
      check_partial_wave_nucleon (ld , jd);
 
      const int Jmin_ab = abs (make_int (ja - jb));
      const int Jmin_cd = abs (make_int (jc - jd));
      
      const int Jmax_ab = make_int (ja + jb);
      const int Jmax_cd = make_int (jc + jd);

      const int Jmin_local = max (Jmin_ab , Jmin_cd);
      const int Jmax_local = min (Jmax_ab , Jmax_cd);
      
      const int Jmin = max (Jmin_local , Jmin_global);
      const int Jmax = min (Jmax_local , Jmax_global);

      if ((J < Jmin) || (J > Jmax)) continue;

      const unsigned int a = shells_HO_indices(na , la , ja);
      const unsigned int b = shells_HO_indices(nb , lb , jb);
      const unsigned int c = shells_HO_indices(nc , lc , jc);
      const unsigned int d = shells_HO_indices(nd , ld , jd);

      if (Tz == 0)
	TBMEs_pn_inter_lab(J , a , b , c , d) += TBME_HO_lab;
      else
	{
	  const int phase_in  = (b < a) ? (minus_one_pow (ja + jb - J - 1)) : (1);
	  const int phase_out = (d < c) ? (minus_one_pow (jc + jd - J - 1)) : (1);

	  const int phase = phase_in*phase_out;
	  
	  const unsigned int ab_min = min (a , b);
	  const unsigned int ab_max = max (a , b);
	  const unsigned int cd_min = min (c , d);
	  const unsigned int cd_max = max (c , d);
	  
	  switch (Tz)
	    {
	    case -1: TBMEs_pp_inter_lab(J , ab_min , ab_max , cd_min , cd_max) += phase*TBME_HO_lab; break;
	    case  1: TBMEs_nn_inter_lab(J , ab_min , ab_max , cd_min , cd_max) += phase*TBME_HO_lab; break;
	      
	    default: abort_all ();
	    }	
	}
    }
}


void interaction_class::TBMEs_HO_lab_T0_T1_read_add (const string TBMEs_HO_lab_file_name , const double V_parameter)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in interaction_class::TBMEs_HO_lab_T0_T1_read_add.");

  if (V_parameter == 0.0) return;
  
  if (!is_it_EFT_determine (TBME_inter)) error_message_print_abort ("EFT interaction only in interaction_class::TBMEs_HO_lab_T0_T1_read_add (pp/nn/pn)");

  ifstream TBMEs_HO_lab_file(TBMEs_HO_lab_file_name.c_str ());
  
  file_existence_check (TBMEs_HO_lab_file_name , TBMEs_HO_lab_file);

  double b_lab_from_file;

  TBMEs_HO_lab_file >> b_lab_from_file;

  if (abs (b_lab_from_file - b_lab) > precision) error_message_print_abort ("b_lab of interaction_class and b_lab from interaction file are different in interaction_class::TBMEs_HO_lab_T0_T1_read_add.");

  while (!TBMEs_HO_lab_file.eof ())
    {
      string sa;
      string sb;
      string sc;
      string sd;

      int J;
      int T;
      
      double TBME_HO_lab;

      TBMEs_HO_lab_file >> sa >> sb >> sc >> sd >> J >> T >> TBME_HO_lab;
            
      if (TBMEs_HO_lab_file.eof ()) break;
	      
      TBME_HO_lab *= V_parameter;
      
      const int la = determine_l (sa);
      const int lb = determine_l (sb);
      const int lc = determine_l (sc);
      const int ld = determine_l (sd);

      if ((la > lmax_for_interaction) || (lb > lmax_for_interaction) || (lc > lmax_for_interaction) || (ld > lmax_for_interaction)) continue;

      const int na = determine_n (sa);
      const int nb = determine_n (sb);
      const int nc = determine_n (sc);
      const int nd = determine_n (sd);

      if ((na > nmax_HO_lab_tab(la)) || (nb > nmax_HO_lab_tab(lb)) || (nc > nmax_HO_lab_tab(lc)) || (nd > nmax_HO_lab_tab(ld))) continue;

      const double ja = determine_j (sa);
      const double jb = determine_j (sb);
      const double jc = determine_j (sc);
      const double jd = determine_j (sd);

      check_partial_wave_nucleon (la , ja);
      check_partial_wave_nucleon (lb , jb);
      check_partial_wave_nucleon (lc , jc);
      check_partial_wave_nucleon (ld , jd);
      
      const int Jmin_ab = abs (make_int (ja - jb));
      const int Jmin_cd = abs (make_int (jc - jd));
      
      const int Jmax_ab = make_int (ja + jb);
      const int Jmax_cd = make_int (jc + jd);

      const int Jmin_local = max (Jmin_ab , Jmin_cd);
      const int Jmax_local = min (Jmax_ab , Jmax_cd);
      
      const int Jmin = max (Jmin_local , Jmin_global);
      const int Jmax = min (Jmax_local , Jmax_global);

      if ((J < Jmin) || (J > Jmax)) continue;
      
      const unsigned int a = shells_HO_indices(na , la , ja);
      const unsigned int b = shells_HO_indices(nb , lb , jb);
      const unsigned int c = shells_HO_indices(nc , lc , jc);
      const unsigned int d = shells_HO_indices(nd , ld , jd);

      const int phase_ab_swap = minus_one_pow (ja + jb - J - T);      
      const int phase_cd_swap = minus_one_pow (jc + jd - J - T);
      
      const unsigned int is_J_plus_T_even = ((J + T)%2 == 0);
            
      const bool ab_same_shells = (a == b);
      const bool cd_same_shells = (c == d);
      
      if (ab_same_shells && is_J_plus_T_even) continue;
      if (cd_same_shells && is_J_plus_T_even) continue;
      
      if (T == 1)
	{	  
	  const int phase_in  = (b < a) ? (phase_ab_swap) : (1);
	  const int phase_out = (d < c) ? (phase_cd_swap) : (1);

	  const int phase = phase_in*phase_out;
	  
	  const unsigned int ab_min = min (a , b);
	  const unsigned int ab_max = max (a , b);
	  const unsigned int cd_min = min (c , d);
	  const unsigned int cd_max = max (c , d);
	  
	  if (are_there_pp_TBMEs) TBMEs_pp_inter_lab(J , ab_min , ab_max , cd_min , cd_max) += phase*TBME_HO_lab;
	  if (are_there_nn_TBMEs) TBMEs_nn_inter_lab(J , ab_min , ab_max , cd_min , cd_max) += phase*TBME_HO_lab;
	}
      
      if (are_there_pn_TBMEs)
	{
	  const class pair_str pair_ab(a , b), pair_cd(c , d);
	  const class pair_str pair_ba(b , a), pair_dc(d , c);
	
	  const bool is_ab_equal_to_cd = (pair_ab == pair_cd);
	  const bool is_ba_equal_to_cd = (pair_ba == pair_cd);
      
	  const bool is_ab_equal_to_dc = (pair_ab == pair_dc);
	  const bool is_ba_equal_to_dc = (pair_ba == pair_dc);
	  
	  const double inv_antisymmetry_delta_in  = (ab_same_shells) ? (M_SQRT2) : (1.0);
	  const double inv_antisymmetry_delta_out = (cd_same_shells) ? (M_SQRT2) : (1.0);
					  
	  TBME_HO_lab *= 0.5*inv_antisymmetry_delta_in*inv_antisymmetry_delta_out;
	  
	  TBMEs_pn_inter_lab(J , a , b , c , d) += TBME_HO_lab;

	  if (!ab_same_shells && (!is_ba_equal_to_cd || !is_ab_equal_to_cd))
	    TBMEs_pn_inter_lab(J , b , a , c , d) += phase_ab_swap*TBME_HO_lab;
	  
	  if (!cd_same_shells && (!is_ab_equal_to_cd || !is_ab_equal_to_dc) && (!is_ab_equal_to_cd || !is_ba_equal_to_dc))
	    TBMEs_pn_inter_lab(J , a , b , d , c) += phase_cd_swap*TBME_HO_lab;
	  
	  if (!ab_same_shells && !cd_same_shells && (!is_ba_equal_to_cd || !is_ab_equal_to_dc) && (!is_ba_equal_to_cd || !is_ba_equal_to_dc) && (!is_ab_equal_to_dc || !is_ba_equal_to_dc))
	    TBMEs_pn_inter_lab(J , b , a , d , c) += phase_ab_swap*phase_cd_swap*TBME_HO_lab;
	}
    }
}




void interaction_class::TBMEs_GHF_lab_read_add (class TBMEs_class &TBMEs_GHF_lab)
{
  if (inter_read != LAB_BERGGREN_TBMES_READ) error_message_print_abort ("Laboratory Berggren MEs read only in interaction_class::TBMEs_GHF_lab_read_add");
  
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      TBMEs_GHF_lab.zero ();

      const enum space_type TBME_space = TBMEs_GHF_lab.get_TBME_space ();
          
      const string inter_file_string = STORAGE_DIR + "TBMEs_" + make_string<enum space_type> (TBME_space) + "_" + make_string<enum interaction_type> (TBME_inter);
      
      if (is_there_cout)
	{
	  cout << endl << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;
	  cout << inter_file_string << " are being read from disk" << endl;
	  cout << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl << endl;
	}
  
      ifstream munu_inter(inter_file_string.c_str ());
      
      file_existence_check (inter_file_string , munu_inter);

      int J;
      
      string sa;
      string sb;
      string sc;
      string sd;
      
      TYPE TBME;
	  
      while (!munu_inter.eof ())
	{
	  munu_inter >> J;
	  
	  if (munu_inter.eof ()) break;

	  munu_inter >> sa >> sb >> sc >> sd >> TBME;
	  
	  const int la = determine_l (sa);
	  const int lb = determine_l (sb);
	  const int lc = determine_l (sc);
	  const int ld = determine_l (sd);
	  
	  if (la > lmax_for_interaction) continue;
	  if (lb > lmax_for_interaction) continue;
	  if (lc > lmax_for_interaction) continue;
	  if (ld > lmax_for_interaction) continue;
	  
	  const int nmax_la = nmax_inter_lab_tab(la);
	  const int nmax_lb = nmax_inter_lab_tab(lb);
	  const int nmax_lc = nmax_inter_lab_tab(lc);
	  const int nmax_ld = nmax_inter_lab_tab(ld);
	  
	  const int na = determine_n (sa);
	  const int nb = determine_n (sb);
	  const int nc = determine_n (sc);
	  const int nd = determine_n (sd);
	  
	  if (na > nmax_la) continue;
	  if (nb > nmax_lb) continue;
	  if (nc > nmax_lc) continue;
	  if (nd > nmax_ld) continue;

	  const double ja = determine_j (sa);
	  const double jb = determine_j (sb);
	  const double jc = determine_j (sc);
	  const double jd = determine_j (sd);

	  check_partial_wave_nucleon (la , ja);
	  check_partial_wave_nucleon (lb , jb);
	  check_partial_wave_nucleon (lc , jc);
	  check_partial_wave_nucleon (ld , jd);
      
	  const unsigned int a = shells_inter_indices(na , la , ja);
	  const unsigned int b = shells_inter_indices(nb , lb , jb);
	  
	  const unsigned int c = shells_inter_indices(nc , lc , jc);
	  const unsigned int d = shells_inter_indices(nd , ld , jd);

	  if (a == OUT_OF_RANGE) continue;
	  if (b == OUT_OF_RANGE) continue;
	  if (c == OUT_OF_RANGE) continue;
	  if (d == OUT_OF_RANGE) continue;
	  
	  if (TBME_space == PROTONS_NEUTRONS)
	    TBMEs_GHF_lab(J , a , b , c , d) = TBME;
	  else
	    {
	      if      ((a <= b) && (c <= d)) TBMEs_GHF_lab(J , a , b , c , d) += TBME;
	      else if ((a >  b) && (c <= d)) TBMEs_GHF_lab(J , b , a , c , d) += TBME*minus_one_pow (ja + jb - J - 1);
	      else if ((a <= b) && (c >  d)) TBMEs_GHF_lab(J , a , b , d , c) += TBME*minus_one_pow (jc + jd - J - 1);
	      else if ((a >  b) && (c >  d)) TBMEs_GHF_lab(J , b , a , d , c) += TBME*minus_one_pow (ja + jb + jc + jd);
	    }
	}
    }
  
#ifdef UseMPI
  TBMEs_GHF_lab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}






void interaction_class::TBMEs_HO_lab_EFT_read_add ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in interaction_class::TBMEs_HO_lab_EFT_read_add.");
  
  const bool is_it_EFT = is_it_EFT_determine (TBME_inter);
  
  if (!is_it_EFT) error_message_print_abort ("EFT interaction only in interaction_class::TBMEs_HO_lab_EFT_read_add");
  
  const string TBMEs_HO_lab_file_name_VS_LO_T0                = STORAGE_DIR + "v2body_HO_lab_" + make_string<enum FHT_EFT_parameter_type> (VS_LO_T0)                + ".dat";
  const string TBMEs_HO_lab_file_name_VS_LO_T1                = STORAGE_DIR + "v2body_HO_lab_" + make_string<enum FHT_EFT_parameter_type> (VS_LO_T1)                + ".dat";
  const string TBMEs_HO_lab_file_name_VT_SIGMA_PRODUCT_LO_T0  = STORAGE_DIR + "v2body_HO_lab_" + make_string<enum FHT_EFT_parameter_type> (VT_SIGMA_PRODUCT_LO_T0)  + ".dat";
  const string TBMEs_HO_lab_file_name_VT_SIGMA_PRODUCT_LO_T1  = STORAGE_DIR + "v2body_HO_lab_" + make_string<enum FHT_EFT_parameter_type> (VT_SIGMA_PRODUCT_LO_T1)  + ".dat";
  const string TBMEs_HO_lab_file_name_V1_Q2_NLO               = STORAGE_DIR + "v2body_HO_lab_" + make_string<enum FHT_EFT_parameter_type> (V1_Q2_NLO)               + ".dat";
  const string TBMEs_HO_lab_file_name_V2_K2_NLO               = STORAGE_DIR + "v2body_HO_lab_" + make_string<enum FHT_EFT_parameter_type> (V2_K2_NLO)               + ".dat";
  const string TBMEs_HO_lab_file_name_V3_Q2_SIGMA_PRODUCT_NLO = STORAGE_DIR + "v2body_HO_lab_" + make_string<enum FHT_EFT_parameter_type> (V3_Q2_SIGMA_PRODUCT_NLO) + ".dat";
  const string TBMEs_HO_lab_file_name_V4_K2_SIGMA_PRODUCT_NLO = STORAGE_DIR + "v2body_HO_lab_" + make_string<enum FHT_EFT_parameter_type> (V4_K2_SIGMA_PRODUCT_NLO) + ".dat";
  const string TBMEs_HO_lab_file_name_V5_SIGMA_Q_VECTOR_K_NLO = STORAGE_DIR + "v2body_HO_lab_" + make_string<enum FHT_EFT_parameter_type> (V5_SIGMA_Q_VECTOR_K_NLO) + ".dat";
  const string TBMEs_HO_lab_file_name_V6_SIGMA_Q_PRODUCT_NLO  = STORAGE_DIR + "v2body_HO_lab_" + make_string<enum FHT_EFT_parameter_type> (V6_SIGMA_Q_PRODUCT_NLO)  + ".dat";
  const string TBMEs_HO_lab_file_name_V7_SIGMA_K_PRODUCT_NLO  = STORAGE_DIR + "v2body_HO_lab_" + make_string<enum FHT_EFT_parameter_type> (V7_SIGMA_K_PRODUCT_NLO)  + ".dat";

  TBMEs_HO_lab_T0_T1_read_add (TBMEs_HO_lab_file_name_VS_LO_T0                , VS_const_LO_T0_inter);
  TBMEs_HO_lab_T0_T1_read_add (TBMEs_HO_lab_file_name_VS_LO_T1                , VS_const_LO_T1_inter);
  TBMEs_HO_lab_T0_T1_read_add (TBMEs_HO_lab_file_name_VT_SIGMA_PRODUCT_LO_T0  , VT_sigma_product_LO_T0_inter);
  TBMEs_HO_lab_T0_T1_read_add (TBMEs_HO_lab_file_name_VT_SIGMA_PRODUCT_LO_T1  , VT_sigma_product_LO_T1_inter);
  TBMEs_HO_lab_T0_T1_read_add (TBMEs_HO_lab_file_name_V1_Q2_NLO               , V1_q2_NLO_inter); 
  TBMEs_HO_lab_T0_T1_read_add (TBMEs_HO_lab_file_name_V2_K2_NLO               , V2_k2_NLO_inter);  
  TBMEs_HO_lab_T0_T1_read_add (TBMEs_HO_lab_file_name_V3_Q2_SIGMA_PRODUCT_NLO , V3_q2_sigma_product_NLO_inter);
  TBMEs_HO_lab_T0_T1_read_add (TBMEs_HO_lab_file_name_V4_K2_SIGMA_PRODUCT_NLO , V4_k2_sigma_product_NLO_inter);
  TBMEs_HO_lab_T0_T1_read_add (TBMEs_HO_lab_file_name_V5_SIGMA_Q_VECTOR_K_NLO , V5_sigma_q_vector_k_NLO_inter);
  TBMEs_HO_lab_T0_T1_read_add (TBMEs_HO_lab_file_name_V6_SIGMA_Q_PRODUCT_NLO  , V6_sigma_q_product_NLO_inter);   
  TBMEs_HO_lab_T0_T1_read_add (TBMEs_HO_lab_file_name_V7_SIGMA_K_PRODUCT_NLO  , V7_sigma_k_product_NLO_inter);   
}





// Calculation of the HO relative TBMEs of the Coulomb interaction
// ---------------------------------------------------------------
// HO relative TBMEs of the Coulomb interaction are equal to <n'_rel[HO] l'_rel S J_rel | Cc/r_rel | n_rel[HO] l_rel S J_rel>, with Cc the Coulomb constant.
// A direct integration in r-space is done.

void interaction_class::TBMEs_Coulomb_HO_relative_calc (class array<double> &TBMEs_HO_relative_Coulomb) const
{
  if (!are_there_pp_TBMEs) error_message_print_abort ("Coulomb interaction only with protons in interaction_class::TBMEs_Coulomb_HO_relative_calc");

  if (!is_it_mixed_determine (PROTON , TBME_inter)) error_message_print_abort ("HO-defined interaction only in interaction_class::TBMEs_Coulomb_HO_relative_calc");

  const unsigned int N_bef_R_GL = r_bef_R_tab_GL.dimension (0);
  const unsigned int N_aft_R_GL = r_aft_R_tab_GL.dimension (0);

  const int n_relative_max = TBMEs_HO_relative_Coulomb.dimension (1) - 1;
  
  const int n_relative_max_plus_one = n_relative_max + 1;

  const int lc_relative_max = TBMEs_HO_relative_Coulomb.dimension (0) - 1;

  const int lc_relative_max_plus_one = lc_relative_max + 1;

  TBMEs_HO_relative_Coulomb = 0.0;

  class array<double> HO_relative_bef_R_tab_GL(n_relative_max_plus_one , lc_relative_max_plus_one , N_bef_R_GL);
  class array<double> HO_relative_aft_R_tab_GL(n_relative_max_plus_one , lc_relative_max_plus_one , N_aft_R_GL);

  HO_wave_functions::HO_3D::u_r_tables_calc (b_relative , r_bef_R_tab_GL , HO_relative_bef_R_tab_GL);
  HO_wave_functions::HO_3D::u_r_tables_calc (b_relative , r_aft_R_tab_GL , HO_relative_aft_R_tab_GL);

  for (int l_relative = 0 ; l_relative <= lc_relative_max ; l_relative++)
    for (int n_relative = 0 ; n_relative <= n_relative_max ; n_relative++) 
      for (int np_relative = 0 ; np_relative <= n_relative_max ; np_relative++)
	{ 
	  double Coulomb_radial_integral = 0.0;

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) Coulomb_radial_integral += w_bef_R_tab_GL(i)*HO_relative_bef_R_tab_GL(n_relative , l_relative , i)*HO_relative_bef_R_tab_GL(np_relative , l_relative , i)/r_bef_R_tab_GL(i);
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) Coulomb_radial_integral += w_aft_R_tab_GL(i)*HO_relative_aft_R_tab_GL(n_relative , l_relative , i)*HO_relative_aft_R_tab_GL(np_relative , l_relative , i)/r_aft_R_tab_GL(i);

	  const double Coulomb_TBME = Coulomb_constant*Coulomb_radial_integral;

	  TBMEs_HO_relative_Coulomb(l_relative , n_relative , np_relative) = Coulomb_TBME;
	}
}












// Calculation of the HO relative TBMEs of the Minnesota or FHT interaction
// ------------------------------------------------------------------------
// One calculates HO relative TBMEs of the form <n'_rel[HO] l'_rel S J_rel | V | n_rel[HO] l_rel S J_rel> with:
//
// V = \sum_i fi(r_rel) (Wi + Bi Psigma - Hi Ptau - Mi Psigma Ptau)) (Minnesota)
// V = \sum_i (Wi fi_ctr(r_rel) + Bi Psigma gi_ctr(r_rel) - Hi Ptau hi_ctr(r_rel) - Mi Psigma Ptau pi_ctr(r_rel))) + (Wi fi_so(r_rel) - Hi Ptau hi_so(r_rel)) L.S + (Wi fi_t(r_rel) - Hi Ptau hi_t(r_rel)) S12 (FHT)
//
// where Psigma is spin exchange, Ptau is isospin exchange, Wi,Mi,Bi,Hi are coupling constants, 
// one has  central (ctr), spin-orbit (so) and tensor (t) parts in the FHT interaction, 
// fi, gi, hi , pi (with ctr,so,t suffixes in the FHT interaction) are relative radial form factors,
// L.S is the relative spin-orbit coupling and S12 is the tensor operator in the FHT interaction.
// 
// A direct integration in r-space is done after replacing Psigma, Ptau by (-1)^(S+1) and (-1)^(T+1).
// One pays attention to symmetries not to calculate vanishing terms of the nuclear interaction TBME.

void interaction_class::TBMEs_Minnesota_HO_relative_calc (
							  const int Jn_relative_max , 
							  class array<double> &TBMEs_HO_relative) const
{
  if (!is_it_Minnesota_determine (TBME_inter)) error_message_print_abort ("Minnesota interaction only in interaction_class::TBMEs_Minnesota_HO_relative_calc");

  const double V0_Minnesota_0 = V0_Minnesota_tab[0];
  const double V0_Minnesota_1 = V0_Minnesota_tab[1];
  const double V0_Minnesota_2 = V0_Minnesota_tab[2];
  
  const double rho_Minnesota_0 = rho_Minnesota_tab[0];
  const double rho_Minnesota_1 = rho_Minnesota_tab[1];
  const double rho_Minnesota_2 = rho_Minnesota_tab[2];

  const unsigned int N_bef_R_GL = r_bef_R_tab_GL.dimension (0);
  const unsigned int N_aft_R_GL = r_aft_R_tab_GL.dimension (0);

  const double W0 = 0.5*u_Minnesota  , M0 =  0.5*(2.0 - u_Minnesota) , B0 =  0.0               , H0 = 0.0;
  const double W1 = 0.25*u_Minnesota , M1 = 0.25*(2.0 - u_Minnesota) , B1 =  0.25*u_Minnesota  , H1 =  0.25*(2.0 - u_Minnesota);
  const double W2 = 0.25*u_Minnesota , M2 = 0.25*(2.0 - u_Minnesota) , B2 = -0.25*u_Minnesota  , H2 = -0.25*(2.0 - u_Minnesota);

  const int n_relative_max = TBMEs_HO_relative.dimension (0) - 1;

  const int n_relative_max_plus_one = n_relative_max + 1;

  const int ln_relative_max = TBMEs_HO_relative.dimension (1) - 1;

  const int ln_relative_max_plus_one = ln_relative_max + 1;

  TBMEs_HO_relative = 0.0;

  class array<double> HO_relative_bef_R_tab_GL(n_relative_max_plus_one , ln_relative_max_plus_one , N_bef_R_GL);
  class array<double> HO_relative_aft_R_tab_GL(n_relative_max_plus_one , ln_relative_max_plus_one , N_aft_R_GL);

  HO_wave_functions::HO_3D::u_r_tables_calc (b_relative , r_bef_R_tab_GL , HO_relative_bef_R_tab_GL);
  HO_wave_functions::HO_3D::u_r_tables_calc (b_relative , r_aft_R_tab_GL , HO_relative_aft_R_tab_GL);

  class array<double> V_bef_R_tab_GL(N_bef_R_GL);
  class array<double> V_aft_R_tab_GL(N_aft_R_GL);

  for (int l_relative = 0 ; l_relative <= ln_relative_max ; l_relative++)
    for (int S = 0 ; S <= 1 ; S++)
      {
	const int T = (l_relative + S + 1)%2;

	const int S_phase = minus_one_pow (S + 1);
	const int T_phase = minus_one_pow (T + 1);

	const int ST_phase = S_phase*T_phase;

	const double V0_Minnesota_0_factor = V0_Minnesota_0*(W0 - ST_phase*M0 + S_phase*B0 - T_phase*H0); 
	const double V0_Minnesota_1_factor = V0_Minnesota_1*(W1 - ST_phase*M1 + S_phase*B1 - T_phase*H1); 
	const double V0_Minnesota_2_factor = V0_Minnesota_2*(W2 - ST_phase*M2 + S_phase*B2 - T_phase*H2); 

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	  {
	    const double r = r_bef_R_tab_GL(i);

	    const double r2 = r*r;

	    V_bef_R_tab_GL(i) = V0_Minnesota_0_factor*exp (-rho_Minnesota_0*r2) + V0_Minnesota_1_factor*exp (-rho_Minnesota_1*r2) + V0_Minnesota_2_factor*exp (-rho_Minnesota_2*r2);
	  }

	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	  {
	    const double r = r_aft_R_tab_GL(i);

	    const double r2 = r*r;

	    V_aft_R_tab_GL(i) = V0_Minnesota_0_factor*exp (-rho_Minnesota_0*r2) + V0_Minnesota_1_factor*exp (-rho_Minnesota_1*r2) + V0_Minnesota_2_factor*exp (-rho_Minnesota_2*r2);
	  }

	const int J_relative_min = abs (l_relative - S);

	const int J_relative_max = min (l_relative + S , Jn_relative_max);

	for (int n_relative = 0 ; n_relative <= n_relative_max ; n_relative++) 
	  for (int np_relative = 0 ; np_relative <= n_relative_max ; np_relative++)
	    {
	      double Minnesota_TBME = 0.0;

	      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) Minnesota_TBME += HO_relative_bef_R_tab_GL(n_relative , l_relative , i)*HO_relative_bef_R_tab_GL(np_relative , l_relative , i)*V_bef_R_tab_GL(i)*w_bef_R_tab_GL(i); 
	      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) Minnesota_TBME += HO_relative_aft_R_tab_GL(n_relative , l_relative , i)*HO_relative_aft_R_tab_GL(np_relative , l_relative , i)*V_aft_R_tab_GL(i)*w_aft_R_tab_GL(i); 

	      for (int J_relative = J_relative_min ; J_relative <= J_relative_max ; J_relative++)
		TBMEs_HO_relative(n_relative , l_relative , np_relative , l_relative , S , J_relative) = Minnesota_TBME;
	    }
      }
}

void interaction_class::TBMEs_FHT_HO_relative_calc (
						    const int Jn_relative_max , 
						    class array<double> &TBMEs_HO_relative) const
{
  if (!is_it_FHT_determine (TBME_inter)) error_message_print_abort ("FHT interaction only in interaction_class::TBMEs_FHT_HO_relative_calc");

  const double V0_ctr_0 = V0_ctr_tab[0];
  const double V0_ctr_1 = V0_ctr_tab[1];
  const double V0_ctr_2 = V0_ctr_tab[2];

  const double alpha_ctr_0 = alpha_ctr_tab[0];
  const double alpha_ctr_1 = alpha_ctr_tab[1];
  const double alpha_ctr_2 = alpha_ctr_tab[2];

  const double W_ctr_0 = W_ctr_tab[0];
  const double W_ctr_1 = W_ctr_tab[1];
  const double W_ctr_2 = W_ctr_tab[2];

  const double B_ctr_0 = B_ctr_tab[0];
  const double B_ctr_1 = B_ctr_tab[1];
  const double B_ctr_2 = B_ctr_tab[2];

  const double H_ctr_0 = H_ctr_tab[0];
  const double H_ctr_1 = H_ctr_tab[1];
  const double H_ctr_2 = H_ctr_tab[2];

  const double M_ctr_0 = M_ctr_tab[0];
  const double M_ctr_1 = M_ctr_tab[1];
  const double M_ctr_2 = M_ctr_tab[2];

  const double V0_so_0 = V0_so_tab[0];
  const double V0_so_1 = V0_so_tab[1];

  const double alpha_so_0 = alpha_so_tab[0];
  const double alpha_so_1 = alpha_so_tab[1];

  const double W_so_0 = W_so_tab[0];
  const double W_so_1 = W_so_tab[1];

  const double H_so_0 = H_so_tab[0];
  const double H_so_1 = H_so_tab[1];

  const double V0_t_0 = V0_t_tab[0];
  const double V0_t_1 = V0_t_tab[1];
  const double V0_t_2 = V0_t_tab[2];

  const double alpha_t_0 = alpha_t_tab[0];
  const double alpha_t_1 = alpha_t_tab[1];
  const double alpha_t_2 = alpha_t_tab[2];

  const double W_t_0 = W_t_tab[0];
  const double W_t_1 = W_t_tab[1];
  const double W_t_2 = W_t_tab[2];

  const double H_t_0 = H_t_tab[0];
  const double H_t_1 = H_t_tab[1];
  const double H_t_2 = H_t_tab[2];

  const unsigned int N_bef_R_GL = r_bef_R_tab_GL.dimension (0);
  const unsigned int N_aft_R_GL = r_aft_R_tab_GL.dimension (0);

  const int n_relative_max = TBMEs_HO_relative.dimension (0) - 1;

  const int n_relative_max_plus_one = n_relative_max + 1;

  const int ln_relative_max = TBMEs_HO_relative.dimension (1) - 1;

  const int ln_relative_max_plus_one = ln_relative_max + 1;

  class array<double> HO_relative_bef_R_tab_GL(n_relative_max_plus_one , ln_relative_max_plus_one , N_bef_R_GL);
  class array<double> HO_relative_aft_R_tab_GL(n_relative_max_plus_one , ln_relative_max_plus_one , N_aft_R_GL);
  
  HO_wave_functions::HO_3D::u_r_tables_calc (b_relative , r_bef_R_tab_GL , HO_relative_bef_R_tab_GL);
  HO_wave_functions::HO_3D::u_r_tables_calc (b_relative , r_aft_R_tab_GL , HO_relative_aft_R_tab_GL);

  class array<double> V_bef_R_tab_GL_ctr_0(N_bef_R_GL) , V_aft_R_tab_GL_ctr_0(N_aft_R_GL) , V_bef_R_tab_GL_ctr_1(N_bef_R_GL) , V_aft_R_tab_GL_ctr_1(N_aft_R_GL) , V_bef_R_tab_GL_ctr_2(N_bef_R_GL) , V_aft_R_tab_GL_ctr_2(N_aft_R_GL);
  class array<double> V_bef_R_tab_GL_t_0  (N_bef_R_GL) , V_aft_R_tab_GL_t_0  (N_aft_R_GL) , V_bef_R_tab_GL_t_1  (N_bef_R_GL) , V_aft_R_tab_GL_t_1  (N_aft_R_GL) , V_bef_R_tab_GL_t_2  (N_bef_R_GL) , V_aft_R_tab_GL_t_2  (N_aft_R_GL); 
  class array<double> V_bef_R_tab_GL_so_0 (N_bef_R_GL) , V_aft_R_tab_GL_so_0 (N_aft_R_GL) , V_bef_R_tab_GL_so_1 (N_bef_R_GL) , V_aft_R_tab_GL_so_1 (N_aft_R_GL);

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double r = r_bef_R_tab_GL(i);

      const double r2 = r*r;
      
      V_bef_R_tab_GL_ctr_0(i) = exp (-alpha_ctr_0*r2);
      V_bef_R_tab_GL_ctr_1(i) = exp (-alpha_ctr_1*r2);
      V_bef_R_tab_GL_ctr_2(i) = exp (-alpha_ctr_2*r2);

      V_bef_R_tab_GL_t_0(i) = r2 * exp (-alpha_t_0*r2);
      V_bef_R_tab_GL_t_1(i) = r2 * exp (-alpha_t_1*r2);
      V_bef_R_tab_GL_t_2(i) = r2 * exp (-alpha_t_2*r2);
      
      V_bef_R_tab_GL_so_0(i) = exp (-alpha_so_0*r2);
      V_bef_R_tab_GL_so_1(i) = exp (-alpha_so_1*r2);
    }

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)   
    {
      const double r = r_aft_R_tab_GL(i);

      const double r2 = r*r;
      
      V_aft_R_tab_GL_ctr_0(i) = exp (-alpha_ctr_0*r2);
      V_aft_R_tab_GL_ctr_1(i) = exp (-alpha_ctr_1*r2);
      V_aft_R_tab_GL_ctr_2(i) = exp (-alpha_ctr_2*r2);

      V_aft_R_tab_GL_t_0(i) = r2 * exp (-alpha_t_0*r2);
      V_aft_R_tab_GL_t_1(i) = r2 * exp (-alpha_t_1*r2);
      V_aft_R_tab_GL_t_2(i) = r2 * exp (-alpha_t_2*r2);
      
      V_aft_R_tab_GL_so_0(i) = exp (-alpha_so_0*r2);
      V_aft_R_tab_GL_so_1(i) = exp (-alpha_so_1*r2);
    }

  const double Vc1_over_Vc0 = V0_ctr_1/V0_ctr_0;
  const double Vc2_over_Vc0 = V0_ctr_2/V0_ctr_0;

  const double Vso1_over_Vso0 = V0_so_1/V0_so_0;

  const double Vt1_over_Vt0 = V0_t_1/V0_t_0;
  const double Vt2_over_Vt0 = V0_t_2/V0_t_0;

  const double exchange_ctr_0_ot = W_ctr_0 + B_ctr_0 - H_ctr_0 - M_ctr_0 , exchange_ctr_1_ot = W_ctr_1 + B_ctr_1 - H_ctr_1 - M_ctr_1 , exchange_ctr_2_ot = W_ctr_2 + B_ctr_2 - H_ctr_2 - M_ctr_2;
  const double exchange_ctr_0_et = W_ctr_0 + B_ctr_0 + H_ctr_0 + M_ctr_0 , exchange_ctr_1_et = W_ctr_1 + B_ctr_1 + H_ctr_1 + M_ctr_1 , exchange_ctr_2_et = W_ctr_2 + B_ctr_2 + H_ctr_2 + M_ctr_2;
  const double exchange_ctr_0_os = W_ctr_0 - B_ctr_0 + H_ctr_0 - M_ctr_0 , exchange_ctr_1_os = W_ctr_1 - B_ctr_1 + H_ctr_1 - M_ctr_1 , exchange_ctr_2_os = W_ctr_2 - B_ctr_2 + H_ctr_2 - M_ctr_2;
  const double exchange_ctr_0_es = W_ctr_0 - B_ctr_0 - H_ctr_0 + M_ctr_0 , exchange_ctr_1_es = W_ctr_1 - B_ctr_1 - H_ctr_1 + M_ctr_1 , exchange_ctr_2_es = W_ctr_2 - B_ctr_2 - H_ctr_2 + M_ctr_2;
  
  const double exchange_so_0_ot = W_so_0 - H_so_0 , exchange_so_1_ot = W_so_1 - H_so_1;
  const double exchange_so_0_et = W_so_0 + H_so_0 , exchange_so_1_et = W_so_1 + H_so_1;

  const double exchange_t_0_ot = W_t_0 - H_t_0 , exchange_t_1_ot = W_t_1 - H_t_1 , exchange_t_2_ot = W_t_2 - H_t_2;
  const double exchange_t_0_et = W_t_0 + H_t_0 , exchange_t_1_et = W_t_1 + H_t_1 , exchange_t_2_et = W_t_2 + H_t_2;

  class array<double> f_bef_R_tab_GL_ctr_ot(N_bef_R_GL) , f_bef_R_tab_GL_ctr_et(N_bef_R_GL) , f_bef_R_tab_GL_ctr_os(N_bef_R_GL) , f_bef_R_tab_GL_ctr_es(N_bef_R_GL);
  class array<double> f_aft_R_tab_GL_ctr_ot(N_aft_R_GL) , f_aft_R_tab_GL_ctr_et(N_aft_R_GL) , f_aft_R_tab_GL_ctr_os(N_aft_R_GL) , f_aft_R_tab_GL_ctr_es(N_aft_R_GL);
  
  class array<double> f_bef_R_tab_GL_so_ot(N_bef_R_GL) , f_bef_R_tab_GL_so_et(N_bef_R_GL) , f_bef_R_tab_GL_t_ot(N_bef_R_GL)  , f_bef_R_tab_GL_t_et(N_bef_R_GL); 
  class array<double> f_aft_R_tab_GL_so_ot(N_aft_R_GL) , f_aft_R_tab_GL_so_et(N_aft_R_GL) , f_aft_R_tab_GL_t_ot(N_aft_R_GL)  , f_aft_R_tab_GL_t_et(N_aft_R_GL); 

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {   
      f_bef_R_tab_GL_ctr_ot(i) = V_bef_R_tab_GL_ctr_0(i)*exchange_ctr_0_ot + Vc1_over_Vc0*V_bef_R_tab_GL_ctr_1(i)*exchange_ctr_1_ot + Vc2_over_Vc0*V_bef_R_tab_GL_ctr_2(i)*exchange_ctr_2_ot; 
      f_bef_R_tab_GL_ctr_et(i) = V_bef_R_tab_GL_ctr_0(i)*exchange_ctr_0_et + Vc1_over_Vc0*V_bef_R_tab_GL_ctr_1(i)*exchange_ctr_1_et + Vc2_over_Vc0*V_bef_R_tab_GL_ctr_2(i)*exchange_ctr_2_et; 
      f_bef_R_tab_GL_ctr_os(i) = V_bef_R_tab_GL_ctr_0(i)*exchange_ctr_0_os + Vc1_over_Vc0*V_bef_R_tab_GL_ctr_1(i)*exchange_ctr_1_os + Vc2_over_Vc0*V_bef_R_tab_GL_ctr_2(i)*exchange_ctr_2_os; 
      f_bef_R_tab_GL_ctr_es(i) = V_bef_R_tab_GL_ctr_0(i)*exchange_ctr_0_es + Vc1_over_Vc0*V_bef_R_tab_GL_ctr_1(i)*exchange_ctr_1_es + Vc2_over_Vc0*V_bef_R_tab_GL_ctr_2(i)*exchange_ctr_2_es;
      
      f_bef_R_tab_GL_so_ot(i)  = V_bef_R_tab_GL_so_0(i)* exchange_so_0_ot  + Vso1_over_Vso0*V_bef_R_tab_GL_so_1(i)* exchange_so_1_ot; 
      f_bef_R_tab_GL_so_et(i)  = V_bef_R_tab_GL_so_0(i)* exchange_so_0_et  + Vso1_over_Vso0*V_bef_R_tab_GL_so_1(i)* exchange_so_1_et; 

      f_bef_R_tab_GL_t_ot(i)   = V_bef_R_tab_GL_t_0(i)*  exchange_t_0_ot   + Vt1_over_Vt0*  V_bef_R_tab_GL_t_1(i)*  exchange_t_1_ot   + Vt2_over_Vt0*V_bef_R_tab_GL_t_2(i)*exchange_t_2_ot; 
      f_bef_R_tab_GL_t_et(i)   = V_bef_R_tab_GL_t_0(i)*  exchange_t_0_et   + Vt1_over_Vt0*  V_bef_R_tab_GL_t_1(i)*  exchange_t_1_et   + Vt2_over_Vt0*V_bef_R_tab_GL_t_2(i)*exchange_t_2_et;    
    }

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {   
      f_aft_R_tab_GL_ctr_ot(i) = V_aft_R_tab_GL_ctr_0(i)*exchange_ctr_0_ot + Vc1_over_Vc0*V_aft_R_tab_GL_ctr_1(i)*exchange_ctr_1_ot + Vc2_over_Vc0*V_aft_R_tab_GL_ctr_2(i)*exchange_ctr_2_ot; 
      f_aft_R_tab_GL_ctr_et(i) = V_aft_R_tab_GL_ctr_0(i)*exchange_ctr_0_et + Vc1_over_Vc0*V_aft_R_tab_GL_ctr_1(i)*exchange_ctr_1_et + Vc2_over_Vc0*V_aft_R_tab_GL_ctr_2(i)*exchange_ctr_2_et; 
      f_aft_R_tab_GL_ctr_os(i) = V_aft_R_tab_GL_ctr_0(i)*exchange_ctr_0_os + Vc1_over_Vc0*V_aft_R_tab_GL_ctr_1(i)*exchange_ctr_1_os + Vc2_over_Vc0*V_aft_R_tab_GL_ctr_2(i)*exchange_ctr_2_os; 
      f_aft_R_tab_GL_ctr_es(i) = V_aft_R_tab_GL_ctr_0(i)*exchange_ctr_0_es + Vc1_over_Vc0*V_aft_R_tab_GL_ctr_1(i)*exchange_ctr_1_es + Vc2_over_Vc0*V_aft_R_tab_GL_ctr_2(i)*exchange_ctr_2_es; 

      f_aft_R_tab_GL_so_ot(i)  = V_aft_R_tab_GL_so_0(i)*exchange_so_0_ot + Vso1_over_Vso0*   V_aft_R_tab_GL_so_1(i)*exchange_so_1_ot; 
      f_aft_R_tab_GL_so_et(i)  = V_aft_R_tab_GL_so_0(i)*exchange_so_0_et + Vso1_over_Vso0*   V_aft_R_tab_GL_so_1(i)*exchange_so_1_et; 

      f_aft_R_tab_GL_t_ot(i)   = V_aft_R_tab_GL_t_0(i)* exchange_t_0_ot  + Vt1_over_Vt0*     V_aft_R_tab_GL_t_1(i)*exchange_t_1_ot + Vt2_over_Vt0*V_aft_R_tab_GL_t_2(i)*exchange_t_2_ot; 
      f_aft_R_tab_GL_t_et(i)   = V_aft_R_tab_GL_t_0(i)* exchange_t_0_et  + Vt1_over_Vt0*     V_aft_R_tab_GL_t_1(i)*exchange_t_1_et + Vt2_over_Vt0*V_aft_R_tab_GL_t_2(i)*exchange_t_2_et;    
    }

  for (int l_relative = 0 ; l_relative <= ln_relative_max ; l_relative++)
    for (int lp_relative = 0 ; lp_relative <= ln_relative_max ; lp_relative++)
      {
	if ((l_relative + lp_relative)%2 == 0)
	  {
	    for (int S = 0 ; S <= 1 ; S++)
	      {
		const bool is_it_angular_diagonal = (l_relative == lp_relative);

		const bool Tensor_possible = (S == 1) && (abs (l_relative - lp_relative) <= 2) && ((l_relative + lp_relative) >= 2);

		if (is_it_angular_diagonal || Tensor_possible)
		  {
		    const int T = (l_relative + S + 1)%2;

		    const int J_relative_min_l_relative_S  = abs (l_relative  - S);
		    const int J_relative_min_lp_relative_S = abs (lp_relative - S);

		    const int J_relative_max_l_relative_S  = min (l_relative  + S , Jn_relative_max);
		    const int J_relative_max_lp_relative_S = min (lp_relative + S , Jn_relative_max);

		    const int J_relative_min = max (J_relative_min_l_relative_S , J_relative_min_lp_relative_S);
		    const int J_relative_max = min (J_relative_max_l_relative_S , J_relative_max_lp_relative_S);

		    const bool is_it_ot = ((S == 1) && (T == 1));
		    const bool is_it_et = ((S == 1) && (T == 0));
		    const bool is_it_os = ((S == 0) && (T == 0));
		    const bool is_it_es = ((S == 0) && (T == 1));

		    const double V0_ctr_factor_ot = (is_it_angular_diagonal && is_it_ot) ? (V0_ctr_ot_inter) : (0.0) , V0_ctr_factor_et = (is_it_angular_diagonal && is_it_et) ? (V0_ctr_et_inter) : (0.0);
		    const double V0_ctr_factor_os = (is_it_angular_diagonal && is_it_os) ? (V0_ctr_os_inter) : (0.0) , V0_ctr_factor_es = (is_it_angular_diagonal && is_it_es) ? (V0_ctr_es_inter) : (0.0);

		    for (int J_relative = J_relative_min ; J_relative <= J_relative_max ; J_relative++)
		      {
			const double L_dot_S = 0.5*(J_relative*(J_relative + 1) - l_relative*(l_relative + 1) - S*(S + 1));

			const double V0_so_factor_ot = (is_it_angular_diagonal && is_it_ot) ? (V0_so_ot_inter*L_dot_S) : (0.0);
			const double V0_so_factor_et = (is_it_angular_diagonal && is_it_et) ? (V0_so_et_inter*L_dot_S) : (0.0);

			const int phase_factor = minus_one_pow (J_relative + 1);
			
			const double numeric_factor = 2.0*sqrt (30.0);

			const double hat_factor = hat (l_relative)*hat (lp_relative);

			const double three_j_factor = Wigner_3j(l_relative , 2 , lp_relative , 0 , 0 , 0);

			const double six_j_factor = Wigner_6j(l_relative , S , J_relative , S , lp_relative , 2);

			const double S12 = phase_factor*numeric_factor*hat_factor*three_j_factor*six_j_factor;

			const double V0_t_factor_ot = (Tensor_possible && is_it_ot) ? (V0_t_ot_inter*S12) : (0.0);
			const double V0_t_factor_et = (Tensor_possible && is_it_et) ? (V0_t_et_inter*S12) : (0.0);

			for (int n_relative = 0 ; n_relative <= n_relative_max ; n_relative++)
			  for (int np_relative = 0 ; np_relative <= n_relative_max ; np_relative++)
			    {
			      double Central_TBME_ot_bef_R_tab_GL = 0.0 , Spin_Orbit_TBME_ot_bef_R_tab_GL = 0.0 , Tensor_TBME_ot_bef_R_tab_GL = 0.0;
			      double Central_TBME_et_bef_R_tab_GL = 0.0 , Spin_Orbit_TBME_et_bef_R_tab_GL = 0.0 , Tensor_TBME_et_bef_R_tab_GL = 0.0;
			      
			      double Central_TBME_os_bef_R_tab_GL = 0.0;
			      double Central_TBME_es_bef_R_tab_GL = 0.0;

			      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
				{
				  const double HO_wfs_weight = HO_relative_bef_R_tab_GL(n_relative , l_relative , i)*HO_relative_bef_R_tab_GL(np_relative , lp_relative , i)*w_bef_R_tab_GL(i);

				  if (is_it_angular_diagonal && is_it_ot)  Central_TBME_ot_bef_R_tab_GL    += HO_wfs_weight*f_bef_R_tab_GL_ctr_ot(i) , Spin_Orbit_TBME_ot_bef_R_tab_GL += HO_wfs_weight*f_bef_R_tab_GL_so_ot(i);
				  if (is_it_angular_diagonal && is_it_et)  Central_TBME_et_bef_R_tab_GL    += HO_wfs_weight*f_bef_R_tab_GL_ctr_et(i) , Spin_Orbit_TBME_et_bef_R_tab_GL += HO_wfs_weight*f_bef_R_tab_GL_so_et(i); 

				  if (is_it_angular_diagonal && is_it_os)  Central_TBME_os_bef_R_tab_GL    += HO_wfs_weight*f_bef_R_tab_GL_ctr_os(i);
				  if (is_it_angular_diagonal && is_it_es)  Central_TBME_es_bef_R_tab_GL    += HO_wfs_weight*f_bef_R_tab_GL_ctr_es(i);
				  
				  if (Tensor_possible && is_it_ot) Tensor_TBME_ot_bef_R_tab_GL     += HO_wfs_weight*f_bef_R_tab_GL_t_ot(i);
				  if (Tensor_possible && is_it_et) Tensor_TBME_et_bef_R_tab_GL     += HO_wfs_weight*f_bef_R_tab_GL_t_et(i);
				}

			      double Central_TBME_ot_aft_R_tab_GL = 0.0 , Spin_Orbit_TBME_ot_aft_R_tab_GL = 0.0 , Tensor_TBME_ot_aft_R_tab_GL = 0.0;
			      double Central_TBME_et_aft_R_tab_GL = 0.0 , Spin_Orbit_TBME_et_aft_R_tab_GL = 0.0 , Tensor_TBME_et_aft_R_tab_GL = 0.0;
			      
			      double Central_TBME_os_aft_R_tab_GL = 0.0 , Central_TBME_es_aft_R_tab_GL = 0.0;

			      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
				{
				  const double HO_wfs_weight = HO_relative_aft_R_tab_GL(n_relative , l_relative , i)*HO_relative_aft_R_tab_GL(np_relative , lp_relative , i)*w_aft_R_tab_GL(i);

				  if (is_it_angular_diagonal && is_it_ot)  Central_TBME_ot_aft_R_tab_GL += HO_wfs_weight*f_aft_R_tab_GL_ctr_ot(i) , Spin_Orbit_TBME_ot_aft_R_tab_GL += HO_wfs_weight*f_aft_R_tab_GL_so_ot(i);
				  if (is_it_angular_diagonal && is_it_et)  Central_TBME_et_aft_R_tab_GL += HO_wfs_weight*f_aft_R_tab_GL_ctr_et(i) , Spin_Orbit_TBME_et_aft_R_tab_GL += HO_wfs_weight*f_aft_R_tab_GL_so_et(i); 

				  if (is_it_angular_diagonal && is_it_os)  Central_TBME_os_aft_R_tab_GL += HO_wfs_weight*f_aft_R_tab_GL_ctr_os(i);
				  if (is_it_angular_diagonal && is_it_es)  Central_TBME_es_aft_R_tab_GL += HO_wfs_weight*f_aft_R_tab_GL_ctr_es(i);
				  
				  if (Tensor_possible && is_it_ot) Tensor_TBME_ot_aft_R_tab_GL += HO_wfs_weight*f_aft_R_tab_GL_t_ot(i);
				  if (Tensor_possible && is_it_et) Tensor_TBME_et_aft_R_tab_GL += HO_wfs_weight*f_aft_R_tab_GL_t_et(i);
				}

			      const double Central_TBME_ot = (Central_TBME_ot_bef_R_tab_GL + Central_TBME_ot_aft_R_tab_GL)*V0_ctr_factor_ot;
			      const double Central_TBME_et = (Central_TBME_et_bef_R_tab_GL + Central_TBME_et_aft_R_tab_GL)*V0_ctr_factor_et;
			      const double Central_TBME_os = (Central_TBME_os_bef_R_tab_GL + Central_TBME_os_aft_R_tab_GL)*V0_ctr_factor_os;
			      const double Central_TBME_es = (Central_TBME_es_bef_R_tab_GL + Central_TBME_es_aft_R_tab_GL)*V0_ctr_factor_es;

			      const double Spin_Orbit_TBME_ot = (Spin_Orbit_TBME_ot_bef_R_tab_GL + Spin_Orbit_TBME_ot_aft_R_tab_GL)*V0_so_factor_ot;
			      const double Spin_Orbit_TBME_et = (Spin_Orbit_TBME_et_bef_R_tab_GL + Spin_Orbit_TBME_et_aft_R_tab_GL)*V0_so_factor_et;

			      const double Tensor_TBME_ot = (Tensor_TBME_ot_bef_R_tab_GL + Tensor_TBME_ot_aft_R_tab_GL)*V0_t_factor_ot;
			      const double Tensor_TBME_et = (Tensor_TBME_et_bef_R_tab_GL + Tensor_TBME_et_aft_R_tab_GL)*V0_t_factor_et;

			      const double TBME_total = Central_TBME_ot + Spin_Orbit_TBME_ot + Tensor_TBME_ot + Central_TBME_et + Spin_Orbit_TBME_et + Tensor_TBME_et + Central_TBME_es + Central_TBME_os;

			      TBMEs_HO_relative(n_relative , l_relative , np_relative , lp_relative , S , J_relative) = TBME_total;
			    }
		      }
		  }
	      }
	  }
      }
}








// Calculation of pp/nn/pn laboratory HO TBMEs for fixed (a,b) and (c,d) shells and J from relative HO TBMEs using the Brody-Moshinsky transformation
// --------------------------------------------------------------------------------------------------------------------------------------------------
// Coulomb, Minnesota, FHT and realistic interactions are first given in relative coordinates from an input file.
// They are transformed to laboratory coordinates using the Brody-Moshinsky transformation.
// Moshinsky coefficients are calculated in these routines.
// One pays attention to symmetries not to calculate vanishing terms of the nuclear interaction TBME.
//
// The formula is:
// <cd | V |ab>_J = \sum <na la nb lb | n  l  N L >_lambda  6j(S,lambda ,l ,L,J_rel,J) \hat{J_rel}.\hat{lambda} .(-1)^(L + l  + S + J) . 9j(la,1/2,ja,lb,1/2,jb,lambda ,S,J) \hat{ja}.hat{jb}.\hat{S}.\hat{lambda}
//                       <nc lc nd ld | n' l' N L >_lambda' 6j(S,lambda',l',L,J_rel,J) \hat{J_rel}.\hat{lambda'}.(-1)^(L + l' + S + J) . 9j(lc,1/2,jc,ld,1/2,jd,lambda',S,J) \hat{jc}.hat{jd}.\hat{S}.\hat{lambda'}
//                       <n' l' S J_rel | V | n l S J_rel>
//
// where n,l,n',l' are relative quantum numbers and N,L are center of mass quantum numbers. 
// la,lb and l,L are coupled to lambda. lc,ld and l',L are coupled to lambda'. 
// ja,jb , jc,jd , lambda and S, lambda' and S, are coupled to J. 
// l and S, l' and S, are coupled to J_rel.
// One sums over n,l,n',l',lambda,lambda',N,L,S,J_rel.
// \hat{j} is sqrt(2j+1).
//
// If one has protons only or neutrons only, one has to have (-1)^(l_rel + S) even and multiply the TBME by 2/[sqrt (1 + delta_ab) . sqrt (1 + delta_cd)].
// If one has proton-neutron two-body states coupled to T=0,1 , one has to have (-1)^(l_rel + S + T) odd and one has to multiply <cd | V |ab>_JT by 2.
//
// One has l=l' in the Coulomb routine and T=1 is imposed.
//
// One first calculates the T=0,1 parts for proton-neutron TBMEs for the case where interaction is charge-independent (good_T).
// One also has l=l' in the  Minnesota interaction.
// As one can have J-Pi-T dependence of the interaction in the Minnesota or FHT interactions, one multiplies <cd | V |ab>_JT by J-Pi-T dependent coupling constants as well.
// The additional 2 factor at the end is for isospin is for the different definitions of norm_ab_cd (see below).
//
// One does not separate in isospin in realistic interactions as the interaction is charge-dependent in general.
// 
// The Coulomb TBME in laboratory coordinates is returned and the pp/nn/pn TBMEs in laboratory coordinates are calculated in the realistic and charge-independent (good_T) routines.

double interaction_class::TBME_abcd_Coulomb_lab_calc (
						      const int Jc_relative_max , 
						      const int J , 
						      const unsigned int a , 
						      const unsigned int b , 
						      const unsigned int c , 
						      const unsigned int d , 
						      const class array<class Moshinsky_table> &Moshinsky_tables , 
						      const class array<double> &three_js_recoupling_table , 
						      const class array<double> &four_js_recoupling_table , 
						      const class array<double> &TBMEs_pp_HO_relative_Coulomb) const
{
  const class nlj_struct &sa = shells_HO_table(a);
  const class nlj_struct &sb = shells_HO_table(b);
  const class nlj_struct &sc = shells_HO_table(c);
  const class nlj_struct &sd = shells_HO_table(d);

  const int na = sa.get_n () , nb = sb.get_n () , nc = sc.get_n () , nd = sd.get_n ();
  const int la = sa.get_l () , lb = sb.get_l () , lc = sc.get_l () , ld = sd.get_l ();
  
  const unsigned int bp = binary_parity_from_orbital_angular_momentum (la + lb);
  
  const double ja = sa.get_j ();
  const double jb = sb.get_j ();
  const double jc = sc.get_j ();
  const double jd = sd.get_j ();

  const double norm_ab = (a == b) ? (M_SQRT1_2) : (1.0);
  const double norm_cd = (c == d) ? (M_SQRT1_2) : (1.0);

  const double norm_ab_cd = 2.0*norm_ab*norm_cd;

  const int Jmax_global_pp_plus_one = Jmax_global_pp + 1;
  
  const int lc_relative_max = Jc_relative_max + 1;

  const int E_HO_total_ab = 2*na + la + 2*nb + lb;
  const int E_HO_total_cd = 2*nc + lc + 2*nd + ld;

  const int ija = (ja > la) ? (1) : (0);
  const int ijb = (jb > lb) ? (1) : (0);
  const int ijc = (jc > lc) ? (1) : (0);
  const int ijd = (jd > ld) ? (1) : (0);

  const int lambda_min_ab = abs (la - lb);
  const int lambda_max_ab = min (la + lb , Jmax_global_pp_plus_one);

  const int lambda_p_min_cd = abs (lc - ld);
  const int lambda_p_max_cd = min (lc + ld , Jmax_global_pp_plus_one);

  double TBME = 0.0;

  for (int S = 0 ; S <= 1 ; S++)
    {
      const int lambda_min_JS = abs (J - S);
      const int lambda_max_JS = J + S;

      const int lambda_p_min_JS = lambda_min_JS;
      const int lambda_p_max_JS = lambda_max_JS;

      const int lambda_min = max (lambda_min_JS , lambda_min_ab);
      const int lambda_max = min (lambda_max_JS , lambda_max_ab);

      const int lambda_p_min = max (lambda_p_min_JS , lambda_p_min_cd);
      const int lambda_p_max = min (lambda_p_max_JS , lambda_p_max_cd);    

      for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
	{
	  const class Moshinsky_table &Moshinsky_table_ab = Moshinsky_tables(na , la , nb , lb , lambda);
	  
	  const double four_js_recoupling_ab = four_js_recoupling_table(la , ija , lb , ijb , lambda , S , J);

	  for (int lambda_p = lambda_p_min ; lambda_p <= lambda_p_max ; lambda_p++)
	    {
	      const class Moshinsky_table &Moshinsky_table_cd = Moshinsky_tables(nc , lc , nd , ld , lambda_p);

	      const double four_js_recoupling_cd = four_js_recoupling_table(lc , ijc , ld , ijd , lambda_p , S , J);

	      const double four_js_recoupling_product = four_js_recoupling_ab*four_js_recoupling_cd;

	      double TBME_part = 0.0;

	      for (int l_relative = 0 ; l_relative <= lc_relative_max ; l_relative++)
		{
		  const bool is_it_antisymmetric = ((l_relative + S)%2 == 0);

		  if (is_it_antisymmetric)
		    {
		      const int Lmin = abs (lambda - l_relative);
		      const int Lmax = lambda + l_relative;
		      
		      const int J_relative_min_l_relative_S = abs (l_relative - S);
		      const int J_relative_max_l_relative_S = min (l_relative + S , Jc_relative_max);

		      for (int L = Lmin ; L <= Lmax ; L++)
			{
			  if (binary_parity_from_orbital_angular_momentum (l_relative + L) == bp)
			    {
			      const int J_relative_min_LJ = abs (L - J);
			      const int J_relative_max_LJ = min (L + J , Jc_relative_max);
			      
			      const int J_relative_min = max (J_relative_min_l_relative_S , J_relative_min_LJ);
			      const int J_relative_max = min (J_relative_max_l_relative_S , J_relative_max_LJ);

			      for (int J_relative = J_relative_min ; J_relative <= J_relative_max ; J_relative++)
				{
				  const double three_js_recoupling   = three_js_recoupling_table(l_relative , L , lambda   , S , J_relative , J);
				  const double three_js_recoupling_p = three_js_recoupling_table(l_relative , L , lambda_p , S , J_relative , J);

				  const double three_js_recoupling_product = three_js_recoupling*three_js_recoupling_p;
				  
				  const int n_relative_min = max ((E_HO_total_ab - E_HO_total_cd)/2 , 0);
				  
				  const int n_relative_max = (E_HO_total_ab - l_relative - L)/2;

				  double TBME_subpart = 0.0;

				  for (int n_relative = n_relative_min ; n_relative <= n_relative_max ; n_relative++)
				    {
				      const int N = (E_HO_total_ab - (2*n_relative + l_relative) - L)/2;

				      const int np_relative = (E_HO_total_cd - (2*N + L) - l_relative)/2;

				      const double Moshinsky_ab = Moshinsky_table_ab(n_relative  , l_relative , N , L);
				      const double Moshinsky_cd = Moshinsky_table_cd(np_relative , l_relative , N , L);
				      
				      const double Moshinsky_coefficients_product = Moshinsky_ab*Moshinsky_cd;

				      TBME_subpart += Moshinsky_coefficients_product*TBMEs_pp_HO_relative_Coulomb(l_relative , n_relative , np_relative);
				    }

				  TBME_subpart *= three_js_recoupling_product;
				  
				  TBME_part += TBME_subpart;
				}
			    }
			}
		    }
		}

	      TBME_part *= four_js_recoupling_product;
	      
	      TBME += TBME_part;	
	    }
	}
    }

  TBME *= norm_ab_cd;

  return TBME;
}

void interaction_class::TBMEs_abcd_real_inter_nuclear_lab_calc (
								const int Jn_relative_max , 
								const int J , 
								const unsigned int a , 
								const unsigned int b , 
								const unsigned int c , 
								const unsigned int d , 
								const class array<class Moshinsky_table> &Moshinsky_tables , 
								const class array<double> &three_js_recoupling_table , 
								const class array<double> &four_js_recoupling_table , 
								const class array<double> &TBMEs_pp_HO_relative , 
								const class array<double> &TBMEs_nn_HO_relative , 
								const class array<double> &TBMEs_pn_HO_relative , 
								double &TBME_pp , 
								double &TBME_nn , 
								double &TBME_pn) const
{
  if (TBME_inter != REALISTIC_INTERACTION) error_message_print_abort ("Realistic interaction only in interaction_class::TBMEs_abcd_real_inter_nuclear_lab_calc");

  const class nlj_struct &sa = shells_HO_table(a);
  const class nlj_struct &sb = shells_HO_table(b);
  const class nlj_struct &sc = shells_HO_table(c);
  const class nlj_struct &sd = shells_HO_table(d);

  const int na = sa.get_n () , nb = sb.get_n () , nc = sc.get_n () , nd = sd.get_n ();
  const int la = sa.get_l () , lb = sb.get_l () , lc = sc.get_l () , ld = sd.get_l ();
  
  const unsigned int bp_ab = binary_parity_from_orbital_angular_momentum (la + lb);
  
  const double ja = sa.get_j ();
  const double jb = sb.get_j ();
  const double jc = sc.get_j ();
  const double jd = sd.get_j ();
  
  const int ija = (ja > la) ? (1) : (0);
  const int ijb = (jb > lb) ? (1) : (0);
  const int ijc = (jc > lc) ? (1) : (0);
  const int ijd = (jd > ld) ? (1) : (0);
  
  const double norm_ab = (a == b) ? (M_SQRT1_2) : (1.0);
  const double norm_cd = (c == d) ? (M_SQRT1_2) : (1.0);

  const double norm_ab_cd = 2.0*norm_ab*norm_cd;
  
  const int Jmax_global_plus_one = Jmax_global + 1;
  
  const int ln_relative_max = Jn_relative_max + 1;

  const int E_HO_total_ab = 2*na + la + 2*nb + lb;
  const int E_HO_total_cd = 2*nc + lc + 2*nd + ld;
  
  const int lambda_min_ab = abs (la - lb);
  const int lambda_max_ab = min (la + lb , Jmax_global_plus_one);

  const int lambda_p_min_cd = abs (lc - ld);
  const int lambda_p_max_cd = min (lc + ld , Jmax_global_plus_one);

  const bool are_pairs_ordered = ((a <= b) && (c <= d));
  
  const bool is_pp_here = (are_there_pp_TBMEs && are_pairs_ordered && (bp_ab >= BPmin_global_pp) && (bp_ab <= BPmax_global_pp) && (J >= Jmin_global_pp) && (J <= Jmax_global_pp));
  const bool is_nn_here = (are_there_nn_TBMEs && are_pairs_ordered && (bp_ab >= BPmin_global_nn) && (bp_ab <= BPmax_global_nn) && (J >= Jmin_global_nn) && (J <= Jmax_global_nn));
  
  const bool is_pn_here = (are_there_pn_TBMEs && (bp_ab >= BPmin_global_pn) && (bp_ab <= BPmax_global_pn) && (J >= Jmin_global_pn) && (J <= Jmax_global_pn));

  TBME_pp = TBME_nn = TBME_pn = 0.0;

  for (int S = 0 ; S <= 1 ; S++)
    {
      const int lambda_min_JS = abs (J - S);
      const int lambda_max_JS = J + S;

      const int lambda_p_min_JS = lambda_min_JS;
      const int lambda_p_max_JS = lambda_max_JS;

      const int lambda_min = max (lambda_min_JS , lambda_min_ab);
      const int lambda_max = min (lambda_max_JS , lambda_max_ab);

      const int lambda_p_min = max (lambda_p_min_JS , lambda_p_min_cd);
      const int lambda_p_max = min (lambda_p_max_JS , lambda_p_max_cd);    

      for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
	{
	  const class Moshinsky_table &Moshinsky_table_ab = Moshinsky_tables(na , la , nb , lb , lambda);
	  
	  const double four_js_recoupling_ab = four_js_recoupling_table(la , ija , lb , ijb , lambda , S , J);

	  for (int lambda_p = lambda_p_min ; lambda_p <= lambda_p_max ; lambda_p++)
	    {
	      const class Moshinsky_table &Moshinsky_table_cd = Moshinsky_tables(nc , lc , nd , ld , lambda_p);
	      
	      const double four_js_recoupling_cd = four_js_recoupling_table(lc , ijc , ld , ijd , lambda_p , S , J);

	      const double four_js_recoupling_product = four_js_recoupling_ab*four_js_recoupling_cd;

	      double TBME_pp_part = 0.0;
	      double TBME_nn_part = 0.0;
	      double TBME_pn_part = 0.0;

	      for (int l_relative = 0 ; l_relative <= ln_relative_max ; l_relative++)
		{
		  const bool is_it_pp_nn_antisymmetric = ((l_relative + S)%2 == 0);
		  
		  const bool is_pp_non_zero = (is_pp_here && is_it_pp_nn_antisymmetric);
		  const bool is_nn_non_zero = (is_nn_here && is_it_pp_nn_antisymmetric);
		  
		  const int Lmin = abs (lambda - l_relative);
		  const int Lmax = lambda + l_relative;
		  
		  const int J_relative_min_l_relative_S = abs (l_relative - S);
		  const int J_relative_max_l_relative_S = min (l_relative + S , Jn_relative_max);

		  for (int L = Lmin ; L <= Lmax ; L++)
		    {
		      if (binary_parity_from_orbital_angular_momentum (l_relative + L) == bp_ab)
			{
			  const int lp_relative_min = abs (lambda_p - L);
			  const int lp_relative_max = min (lambda_p + L , ln_relative_max);

			  const int J_relative_min_LJ = abs (L - J);
			  const int J_relative_max_LJ = min (L + J , Jn_relative_max);

			  for (int lp_relative = lp_relative_min ; lp_relative <= lp_relative_max ; lp_relative++)
			    {
			      if (binary_parity_from_orbital_angular_momentum (lp_relative + L) == bp_ab)
				{
				  const int J_relative_min_lp_relative_S = abs (lp_relative - S);
				  const int J_relative_max_lp_relative_S = min (lp_relative + S , Jn_relative_max);
				  
				  const int J_relative_min_S = max (J_relative_min_l_relative_S , J_relative_min_lp_relative_S);
				  const int J_relative_max_S = min (J_relative_max_l_relative_S , J_relative_max_lp_relative_S);
				  
				  const int J_relative_min = max (J_relative_min_S , J_relative_min_LJ);
				  const int J_relative_max = min (J_relative_max_S , J_relative_max_LJ);

				  for (int J_relative = J_relative_min ; J_relative <= J_relative_max ; J_relative++)
				    {
				      const double three_js_recoupling   = three_js_recoupling_table(l_relative  , L , lambda   , S , J_relative , J);
				      const double three_js_recoupling_p = three_js_recoupling_table(lp_relative , L , lambda_p , S , J_relative , J);

				      const double three_js_recoupling_product = three_js_recoupling*three_js_recoupling_p;
				  				      
				      const int n_relative_min = max ((E_HO_total_ab - E_HO_total_cd + lp_relative - l_relative)/2 , 0);
				      
				      const int n_relative_max = (E_HO_total_ab - l_relative - L)/2;

				      double TBME_pp_subpart = 0.0;
				      double TBME_nn_subpart = 0.0;
				      double TBME_pn_subpart = 0.0;

				      for (int n_relative = n_relative_min ; n_relative <= n_relative_max ; n_relative++)
					{
					  const int N = (E_HO_total_ab - (2*n_relative + l_relative) - L)/2;
					  
					  const int np_relative = (E_HO_total_cd - (2*N + L) - lp_relative)/2;

					  const double Moshinsky_ab = Moshinsky_table_ab(n_relative  , l_relative  , N , L);
					  const double Moshinsky_cd = Moshinsky_table_cd(np_relative , lp_relative , N , L);
					  
					  const double Moshinsky_coefficients_product = Moshinsky_ab*Moshinsky_cd;

					  if (is_pp_non_zero) TBME_pp_subpart += Moshinsky_coefficients_product*TBMEs_pp_HO_relative(n_relative , l_relative , np_relative , lp_relative , S , J_relative);
					  if (is_nn_non_zero) TBME_nn_subpart += Moshinsky_coefficients_product*TBMEs_nn_HO_relative(n_relative , l_relative , np_relative , lp_relative , S , J_relative);
					  if (is_pn_here)     TBME_pn_subpart += Moshinsky_coefficients_product*TBMEs_pn_HO_relative(n_relative , l_relative , np_relative , lp_relative , S , J_relative);
					} 

				      if (is_pp_here)
					{
					  TBME_pp_subpart *= three_js_recoupling_product;

					  TBME_pp_part += TBME_pp_subpart;
					}

				      if (is_nn_here) 
					{
					  TBME_nn_subpart *= three_js_recoupling_product;

					  TBME_nn_part += TBME_nn_subpart;
					}

				      if (is_pn_here) 
					{
					  TBME_pn_subpart *= three_js_recoupling_product;

					  TBME_pn_part += TBME_pn_subpart;
					}
				    }
				}
			    }
			}
		    }
		}

	      if (is_pp_here) 
		{
		  TBME_pp_part *= four_js_recoupling_product;

		  TBME_pp += TBME_pp_part;
		}

	      if (is_nn_here) 
		{
		  TBME_nn_part *= four_js_recoupling_product;

		  TBME_nn += TBME_nn_part;
		}

	      if (is_pn_here) 
		{
		  TBME_pn_part *= four_js_recoupling_product;

		  TBME_pn += TBME_pn_part;
		}
	    }
	}
    }

  if (is_pp_here) TBME_pp *= norm_ab_cd;
  if (is_nn_here) TBME_nn *= norm_ab_cd;
}

void interaction_class::TBMEs_abcd_good_T_nuclear_lab_calc (
							    const int Jn_relative_max , 
							    const int J , 
							    const unsigned int a , 
							    const unsigned int b , 
							    const unsigned int c , 
							    const unsigned int d , 
							    const class array<class Moshinsky_table> &Moshinsky_tables , 
							    const class array<double> &three_js_recoupling_table , 
							    const class array<double> &four_js_recoupling_table , 
							    const class array<double> &TBMEs_HO_relative , 
							    double &TBME_T1_pp_nn , 
							    double &TBME_T0_pn , 
							    double &TBME_T1_pn) const
{
  if (TBME_inter == REALISTIC_INTERACTION) error_message_print_abort ("No realistic interaction in interaction_class::TBMEs_abcd_good_T_nuclear_lab_calc");

  const class nlj_struct &sa = shells_HO_table(a);
  const class nlj_struct &sb = shells_HO_table(b);
  const class nlj_struct &sc = shells_HO_table(c);
  const class nlj_struct &sd = shells_HO_table(d);

  const int na = sa.get_n () , nb = sb.get_n () , nc = sc.get_n () , nd = sd.get_n ();
  const int la = sa.get_l () , lb = sb.get_l () , lc = sc.get_l () , ld = sd.get_l ();
  
  const unsigned int bp_ab = binary_parity_from_orbital_angular_momentum (la + lb);
  
  const double ja = sa.get_j ();
  const double jb = sb.get_j ();
  const double jc = sc.get_j ();
  const double jd = sd.get_j ();

  const double norm_ab = (a == b) ? (M_SQRT1_2) : (1.0);
  const double norm_cd = (c == d) ? (M_SQRT1_2) : (1.0);

  const double norm_ab_cd = norm_ab*norm_cd;
  
  const int Jmax_global_plus_one = Jmax_global + 1;
  
  const int ln_relative_max = Jn_relative_max + 1;

  const int E_HO_total_ab = 2*na + la + 2*nb + lb;
  const int E_HO_total_cd = 2*nc + lc + 2*nd + ld;
  
  const int ija = (ja > la) ? (1) : (0);
  const int ijb = (jb > lb) ? (1) : (0);
  const int ijc = (jc > lc) ? (1) : (0);
  const int ijd = (jd > ld) ? (1) : (0);
  
  const int lambda_min_ab = abs (la - lb);
  const int lambda_max_ab = min (la + lb , Jmax_global_plus_one);

  const int lambda_p_min_cd = abs (lc - ld);
  const int lambda_p_max_cd = min (lc + ld , Jmax_global_plus_one);

  const bool is_pn_here = (are_there_pn_TBMEs && (bp_ab >= BPmin_global_pn) && (bp_ab <= BPmax_global_pn) && (J >= Jmin_global_pn) && (J <= Jmax_global_pn));
  
  const bool is_it_FHT = is_it_FHT_determine (TBME_inter);
  
  const double V_Gaussian_const_T0 = V_Gaussian_consts(bp_ab , J , 0);
  const double V_Gaussian_const_T1 = V_Gaussian_consts(bp_ab , J , 1);

  TBME_T0_pn = 0.0;
  TBME_T1_pn = 0.0;			 

  for (int S = 0 ; S <= 1 ; S++)
    {
      const int lambda_min_JS = abs (J - S);
      const int lambda_max_JS = J + S;

      const int lambda_p_min_JS = lambda_min_JS;
      const int lambda_p_max_JS = lambda_max_JS;

      const int lambda_min = max (lambda_min_JS , lambda_min_ab);
      const int lambda_max = min (lambda_max_JS , lambda_max_ab);

      const int lambda_p_min = max (lambda_p_min_JS , lambda_p_min_cd);
      const int lambda_p_max = min (lambda_p_max_JS , lambda_p_max_cd);    

      for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
	{
	  const class Moshinsky_table &Moshinsky_table_ab = Moshinsky_tables(na , la , nb , lb , lambda);
	  
	  const double four_js_recoupling_ab = four_js_recoupling_table(la , ija , lb , ijb , lambda , S , J);

	  for (int lambda_p = lambda_p_min ; lambda_p <= lambda_p_max ; lambda_p++)
	    {
	      const class Moshinsky_table &Moshinsky_table_cd = Moshinsky_tables(nc , lc , nd , ld , lambda_p);
	      
	      const double four_js_recoupling_cd = four_js_recoupling_table(lc , ijc , ld , ijd , lambda_p , S , J);
	      
	      const double four_js_recoupling_product = four_js_recoupling_ab*four_js_recoupling_cd;

	      double TBME_T0_part = 0.0;
	      double TBME_T1_part = 0.0;

	      for (int l_relative = 0 ; l_relative <= ln_relative_max ; l_relative++)
		{
		  const int Lmin = abs (lambda - l_relative);
		  const int Lmax = lambda + l_relative;
		  
		  const int T = (l_relative + S + 1)%2;
		  
		  const int J_relative_min_l_relative_S = abs (l_relative - S);
		  const int J_relative_max_l_relative_S = min (l_relative + S , Jn_relative_max);
		  
		  const bool is_T_equal_one = (T == 1);

		  if (is_T_equal_one || is_pn_here)
		    {
		      const bool is_T_equal_zero = (T == 0);

		      for (int L = Lmin ; L <= Lmax ; L++)
			{
			  if (binary_parity_from_orbital_angular_momentum (l_relative + L) == bp_ab)
			    {
			      const int lp_relative_min = abs (lambda_p - L);
			      const int lp_relative_max = min (lambda_p + L , ln_relative_max);
			      
			      const int J_relative_min_LJ = abs (L - J);
			      const int J_relative_max_LJ = min (L + J , Jn_relative_max);

			      for (int lp_relative = lp_relative_min ; lp_relative <= lp_relative_max ; lp_relative++)
				{
				  if ((binary_parity_from_orbital_angular_momentum (lp_relative + L) == bp_ab) && (is_it_FHT || (lp_relative == l_relative)))
				    {
				      const int J_relative_min_lp_relative_S = abs (lp_relative - S);
				      const int J_relative_max_lp_relative_S = min (lp_relative + S , Jn_relative_max);
				      
				      const int J_relative_min_S = max (J_relative_min_l_relative_S , J_relative_min_lp_relative_S);
				      const int J_relative_max_S = min (J_relative_max_l_relative_S , J_relative_max_lp_relative_S);
				      
				      const int J_relative_min = max (J_relative_min_S , J_relative_min_LJ);
				      const int J_relative_max = min (J_relative_max_S , J_relative_max_LJ);

				      for (int J_relative = J_relative_min ; J_relative <= J_relative_max ; J_relative++)
					{
					  const double three_js_recoupling   = three_js_recoupling_table(l_relative  , L , lambda   , S , J_relative , J);
					  const double three_js_recoupling_p = three_js_recoupling_table(lp_relative , L , lambda_p , S , J_relative , J);
					  
					  const double three_js_recoupling_product = three_js_recoupling*three_js_recoupling_p;
					  
					  const int n_relative_min = max ((E_HO_total_ab - E_HO_total_cd + lp_relative - l_relative)/2 , 0);

					  const int n_relative_max = (E_HO_total_ab - l_relative - L)/2;

					  double TBME_T_subpart = 0.0;

					  for (int n_relative = n_relative_min ; n_relative <= n_relative_max ; n_relative++)
					    {
					      const int N = (E_HO_total_ab - (2*n_relative + l_relative) - L)/2;
					      
					      const int np_relative = (E_HO_total_cd - (2*N + L) - lp_relative)/2;

					      const double Moshinsky_ab = Moshinsky_table_ab(n_relative  , l_relative  , N , L);
					      const double Moshinsky_cd = Moshinsky_table_cd(np_relative , lp_relative , N , L);
					      
					      const double Moshinsky_coefficients_product = Moshinsky_ab*Moshinsky_cd;

					      TBME_T_subpart += Moshinsky_coefficients_product*TBMEs_HO_relative(n_relative , l_relative , np_relative , lp_relative , S , J_relative); 
					    }

					  TBME_T_subpart *= three_js_recoupling_product;

					  if (is_T_equal_zero) TBME_T0_part += TBME_T_subpart;
					  if (is_T_equal_one)  TBME_T1_part += TBME_T_subpart;
					}
				    }
				}
			    }
			}
		    }
		}

	      if (is_pn_here) 
		{
		  TBME_T0_part *= four_js_recoupling_product;

		  TBME_T0_pn += TBME_T0_part;
		}

	      TBME_T1_part *= four_js_recoupling_product;
	      
	      TBME_T1_pn += TBME_T1_part;
	    }
	}
    }
  
  TBME_T0_pn *= 2.0*V_Gaussian_const_T0;
  TBME_T1_pn *= 2.0*V_Gaussian_const_T1;

  TBME_T1_pp_nn = norm_ab_cd*TBME_T1_pn;
}











// Calculation of all pp/nn/pn laboratory HO TBMEs from relative HO TBMEs using the Brody-Moshinsky transformation
// ---------------------------------------------------------------------------------------------------------------
// One uses the standard Brody-Moshinsky transformation show above to calculate all possible pp/nn/pn TBMEs <cd | V |ab>_J from relative HO TBMEs.
//
// The formula is:
// <cd | V |ab>_J = \sum <na la nb lb | n  l  N L >_lambda  6j(S,lambda ,l ,L,J_rel,J) \hat{J_rel}.\hat{lambda} .(-1)^(L + l  + S + J) . 9j(la,1/2,ja,lb,1/2,jb,lambda ,S,J) \hat{ja}.hat{jb}.\hat{S}.\hat{lambda}
//                       <nc lc nd ld | n' l' N L >_lambda' 6j(S,lambda',l',L,J_rel,J) \hat{J_rel}.\hat{lambda'}.(-1)^(L + l' + S + J) . 9j(lc,1/2,jc,ld,1/2,jd,lambda',S,J) \hat{jc}.hat{jd}.\hat{S}.\hat{lambda'}
//                       <n' l' S J_rel | V | n l S J_rel>
//
// where n,l,n',l' are relative quantum numbers and N,L are center of mass quantum numbers. 
// la,lb and l,L are coupled to lambda. lc,ld and l',L are coupled to lambda'. 
// ja,jb , jc,jd , lambda and S, lambda' and S, are coupled to J. 
// l and S, l' and S, are coupled to J_rel.
// One sums over n,l,n',l',lambda,lambda',N,L,S,J_rel.
// \hat{j} is sqrt(2j+1).
//
// One uses symmetry so that <cd | V |ab>_J is calculated and stored, but not <ab | V |cd>_J if pairs are different.
//
// If the interaction is charge-independent, one calculates proton-neutron TBMEs for T=0,1 and ordered pairs, i.e. a <= b and c <= d. 
// The other TBMEs with a <-> b and/or c <-> d are obtained from the latter and reordering phases.
// Indeed, |ab>_JT = (-1)^(ja + jb - J - T) |ba>_JT in isospin formalism, so that:
// <ab | V |cd>_J = (<ab | V |cd>_J=0 + <ab | V |cd>_J=1)/2
// <ba | V |dc>_J = (-1)^(ja + jb + jc + jd) <ab | V |cd>_J
// <ba | V |cd>_J = (-1)^(ja + jb - J) (<ba | V |cd>_J=0 - <ba | V |cd>_J=1)/2
// <ab | V |dc>_J = (-1)^(ja + jb + jc + jd) <ba | V |cd>_J
//
// If the interaction is charge-dependent, one can use a similar method, as long as T does not enter formulas:
// <ba | V |dc>_J = (-1)^(ja + jb + jc + jd) <ab | V |cd>_J
// <ab | V |dc>_J = (-1)^(ja + jb + jc + jd) <ba | V |cd>_J, where <ba | V |cd>_J had to be recalculated
//
// MPI and OpenMP parallelization are implemented here as well. 
// A node calculates a part of all HO TBMEs. They are distributed to all other nodes afterwards.
//
// All different nuclear interactions are considered afterwards.
// One can also add the Coulomb interaction to an already existing interaction.
// The kinetic part is not considered here, and is added only in TBMEs_HO_lab_add_kinetic_part.
//
// TBMEs calculated in TBMEs_HO_lab_no_added_kinetic_part are added to the previous ones, so that use zero () before using this routine if you calculate TBMEs from the beginning,

void interaction_class::TBMEs_HO_lab_no_added_kinetic_part_from_relative_TBMEs (
										const bool is_there_nuclear , 
										const bool is_there_Coulomb , 
										const int Jn_relative_max , 
										const int Jc_relative_max , 
										const class array<double> &TBMEs_pp_HO_relative_Coulomb , 
										const class array<double> &TBMEs_pp_HO_relative_nuclear , 
										const class array<double> &TBMEs_nn_HO_relative , 
										const class array<double> &TBMEs_pn_HO_relative)
{
  const unsigned int N_nlj_HO = get_N_nlj_HO ();

  const int lambda_max = Jmax_global + 1;

  const int nmax_HO_lab = nmax_calc (nmax_HO_lab_tab);

  const int Ln_max = Jn_relative_max + Jmax_global;
  const int Lc_max = Jc_relative_max + Jmax_global;

  const int ln_relative_max = Jn_relative_max + 1;
  const int lc_relative_max = Jc_relative_max + 1;

  const int l_relative_max = max (ln_relative_max , lc_relative_max);

  const int l_relative_max_plus_one = l_relative_max + 1;
  
  const int Lmax = max (Ln_max , Lc_max);

  const int Lmax_plus_one = Lmax + 1;

  const int J_relative_max = max (Jn_relative_max , Jc_relative_max);
  
  const int J_relative_max_plus_one = J_relative_max + 1;

  const int nmax_HO_lab_plus_one = nmax_HO_lab + 1;

  const int lmax_for_interaction_plus_one = lmax_for_interaction + 1;

  const int Jmax_global_plus_one = Jmax_global + 1;

  const int lambda_max_plus_one = lambda_max + 1;
  
  class array<class Moshinsky_table> Moshinsky_tables(nmax_HO_lab_plus_one , lmax_for_interaction_plus_one , nmax_HO_lab_plus_one , lmax_for_interaction_plus_one , lambda_max_plus_one);
  
  class array<double> three_js_recoupling_table(l_relative_max_plus_one , Lmax_plus_one , lambda_max_plus_one , 2 , J_relative_max_plus_one , Jmax_global_plus_one);

  class array<double> four_js_recoupling_table(lmax_for_interaction_plus_one , 2 , lmax_for_interaction_plus_one , 2 , lambda_max_plus_one , 2 , Jmax_global_plus_one);

  three_js_recoupling_table = 0.0;
  
  four_js_recoupling_table = 0.0;

  Moshinsky_recoupling_relative_lab_tables_alloc_calc (is_there_cout , 1.0 , Jmin_global , Jmax_global , nmax_HO_lab_tab , Moshinsky_tables , three_js_recoupling_table , four_js_recoupling_table);

  const unsigned int first_index_pp = (are_there_pp_TBMEs) ? (TBMEs_pp_inter_lab.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS)) : (NADA);
  const unsigned int first_index_nn = (are_there_nn_TBMEs) ? (TBMEs_nn_inter_lab.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS)) : (NADA);
  const unsigned int first_index_pn = (are_there_pn_TBMEs) ? (TBMEs_pn_inter_lab.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS)) : (NADA);
  
  const unsigned int last_index_pp  = (are_there_pp_TBMEs) ? (TBMEs_pp_inter_lab.last_index_determine_for_MPI  (NUMBER_OF_PROCESSES , THIS_PROCESS)) : (NADA);
  const unsigned int last_index_nn  = (are_there_nn_TBMEs) ? (TBMEs_nn_inter_lab.last_index_determine_for_MPI  (NUMBER_OF_PROCESSES , THIS_PROCESS)) : (NADA);
  const unsigned int last_index_pn  = (are_there_pn_TBMEs) ? (TBMEs_pn_inter_lab.last_index_determine_for_MPI  (NUMBER_OF_PROCESSES , THIS_PROCESS)) : (NADA);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int a = 0 ; a < N_nlj_HO ; a++)
    for (unsigned int b = 0 ; b < N_nlj_HO ; b++)
      { 
	const class pair_str pair_ab(a , b);

	const unsigned int bp_ab = pair_ab.bp_determine (shells_HO_table , shells_HO_table);
	
	const int Jmin_ab = pair_ab.Jmin_determine (shells_HO_table , shells_HO_table);
	const int Jmax_ab = pair_ab.Jmax_determine (shells_HO_table , shells_HO_table);

	const bool pair_ab_ordered = pair_ab.ordered ();

	const bool same_shells_ab = (a == b);

	const class nlj_struct &sa = shells_HO_table(a);
	const class nlj_struct &sb = shells_HO_table(b);

	const double ja = sa.get_j ();
	const double jb = sb.get_j ();

	if ((bp_ab >= BPmin_global) && (bp_ab <= BPmax_global) && pair_ab_ordered)
	  {
	    for (unsigned int c = 0 ; c < N_nlj_HO ; c++)
	      for (unsigned int d = 0 ; d < N_nlj_HO ; d++)
		{
		  const class pair_str pair_cd(c , d);
		  
		  const unsigned int bp_cd = pair_cd.bp_determine (shells_HO_table , shells_HO_table);

		  if ((bp_ab == bp_cd) && (pair_ab <= pair_cd) && pair_cd.ordered ())
		    {
		      const class nlj_struct &sc = shells_HO_table(c);
		      const class nlj_struct &sd = shells_HO_table(d);

		      const double jc = sc.get_j ();
		      const double jd = sd.get_j ();

		      const int Jmin_cd = pair_cd.Jmin_determine (shells_HO_table , shells_HO_table);
		      const int Jmax_cd = pair_cd.Jmax_determine (shells_HO_table , shells_HO_table);

		      const int Jmin_local = max (Jmin_ab , Jmin_cd);
		      const int Jmax_local = min (Jmax_ab , Jmax_cd);

		      const int Jmin = max (Jmin_local , Jmin_global);
		      const int Jmax = min (Jmax_local , Jmax_global);

		      const int phase_abcd = minus_one_pow (ja + jb + jc + jd);

		      const bool same_shells_cd = (c == d);

		      const bool different_pairs = (pair_ab != pair_cd);

		      const bool different_shells_ab_or_cd  = (!same_shells_ab || !same_shells_cd);
		      const bool different_shells_ab_and_cd = (!same_shells_ab && !same_shells_cd);

		      for (int J = Jmin ; J <= Jmax ; J++)
			{			
			  const bool is_pp_here_bp_J = (are_there_pp_TBMEs && (bp_ab >= BPmin_global_pp) && (bp_ab <= BPmax_global_pp) && (J >= Jmin_global_pp) && (J <= Jmax_global_pp));
			  const bool is_nn_here_bp_J = (are_there_nn_TBMEs && (bp_ab >= BPmin_global_nn) && (bp_ab <= BPmax_global_nn) && (J >= Jmin_global_nn) && (J <= Jmax_global_nn));
			  const bool is_pn_here_bp_J = (are_there_pn_TBMEs && (bp_ab >= BPmin_global_pn) && (bp_ab <= BPmax_global_pn) && (J >= Jmin_global_pn) && (J <= Jmax_global_pn));
			
			  const bool is_pn_abcd_here_bp_J =  is_pn_here_bp_J;
			  const bool is_pn_bacd_here_bp_J = (is_pn_here_bp_J && different_shells_ab_and_cd); 
			  const bool is_pn_abdc_here_bp_J = (is_pn_here_bp_J && different_shells_ab_and_cd && different_pairs); 
			  const bool is_pn_badc_here_bp_J = (is_pn_here_bp_J && different_shells_ab_or_cd); 

			  const unsigned int index_pp = (is_pp_here_bp_J) ? (TBMEs_pp_inter_lab.index_determine (J , a , b , c , d)) : (NADA);
			  const unsigned int index_nn = (is_nn_here_bp_J) ? (TBMEs_nn_inter_lab.index_determine (J , a , b , c , d)) : (NADA);
			
			  const unsigned int index_pn_abcd = (is_pn_abcd_here_bp_J) ? (TBMEs_pn_inter_lab.index_determine (J , a , b , c , d)) : (NADA);
			  const unsigned int index_pn_bacd = (is_pn_bacd_here_bp_J) ? (TBMEs_pn_inter_lab.index_determine (J , b , a , c , d)) : (NADA);
			  const unsigned int index_pn_abdc = (is_pn_abdc_here_bp_J) ? (TBMEs_pn_inter_lab.index_determine (J , a , b , d , c)) : (NADA);
			  const unsigned int index_pn_badc = (is_pn_badc_here_bp_J) ? (TBMEs_pn_inter_lab.index_determine (J , b , a , d , c)) : (NADA);

			  const bool is_pp_here = (is_pp_here_bp_J) ? ((index_pp >= first_index_pp) && (index_pp <= last_index_pp)) : (false);
			  const bool is_nn_here = (is_nn_here_bp_J) ? ((index_nn >= first_index_nn) && (index_nn <= last_index_nn)) : (false);
			
			  const bool is_pn_abcd_here = (is_pn_abcd_here_bp_J) ? ((index_pn_abcd >= first_index_pn) && (index_pn_abcd <= last_index_pn)) : (false);
			  const bool is_pn_bacd_here = (is_pn_bacd_here_bp_J) ? ((index_pn_bacd >= first_index_pn) && (index_pn_bacd <= last_index_pn)) : (false);
			  const bool is_pn_abdc_here = (is_pn_abdc_here_bp_J) ? ((index_pn_abdc >= first_index_pn) && (index_pn_abdc <= last_index_pn)) : (false);
			  const bool is_pn_badc_here = (is_pn_badc_here_bp_J) ? ((index_pn_badc >= first_index_pn) && (index_pn_badc <= last_index_pn)) : (false);

			  if (is_pp_here || is_nn_here || is_pn_abcd_here || is_pn_bacd_here || is_pn_abdc_here || is_pn_badc_here)
			    {
			      double TBME_pp_nuclear = 0.0;

			      double TBME_nn = 0.0;
			      double TBME_pn = 0.0;

			      double dummy_TBME = 0.0;

			      if (is_there_nuclear)
				{
				  if (TBME_inter == REALISTIC_INTERACTION)
				    {
				      TBMEs_abcd_real_inter_nuclear_lab_calc (Jn_relative_max , J , a , b , c , d , Moshinsky_tables , three_js_recoupling_table , four_js_recoupling_table , 
									      TBMEs_pp_HO_relative_nuclear , TBMEs_nn_HO_relative , TBMEs_pn_HO_relative , TBME_pp_nuclear , TBME_nn , TBME_pn);

				      if (is_nn_here) TBMEs_nn_inter_lab(J , a , b , c , d) += TBME_nn;

				      if (is_pn_abcd_here) TBMEs_pn_inter_lab(J , a , b , c , d) += TBME_pn;
				      if (is_pn_badc_here) TBMEs_pn_inter_lab(J , b , a , d , c) += phase_abcd*TBME_pn;

				      if (is_pn_bacd_here || is_pn_abdc_here)
					{
					  TBMEs_abcd_real_inter_nuclear_lab_calc (Jn_relative_max , J , b , a , c , d , Moshinsky_tables , three_js_recoupling_table , four_js_recoupling_table , 
										  TBMEs_pp_HO_relative_nuclear , TBMEs_nn_HO_relative , TBMEs_pn_HO_relative , dummy_TBME , dummy_TBME , TBME_pn);

					  if (is_pn_bacd_here) TBMEs_pn_inter_lab(J , b , a , c , d) += TBME_pn;
					  if (is_pn_abdc_here) TBMEs_pn_inter_lab(J , a , b , d , c) += phase_abcd*TBME_pn;
					}
				    }
				  else
				    {
				      double TBME_T1_pp_nn = 0.0;

				      double TBME_T0_pn = 0.0;
				      double TBME_T1_pn = 0.0;

				      TBMEs_abcd_good_T_nuclear_lab_calc (Jn_relative_max , J , a , b , c , d , Moshinsky_tables , three_js_recoupling_table , four_js_recoupling_table , 
									  TBMEs_pn_HO_relative , TBME_T1_pp_nn , TBME_T0_pn , TBME_T1_pn);

				      TBME_pp_nuclear = TBME_nn = TBME_T1_pp_nn;
				      
				      if (is_nn_here) TBMEs_nn_inter_lab(J , a , b , c , d) += TBME_nn;

				      if (is_pn_abcd_here || is_pn_badc_here)
					{
					  TBME_pn = 0.5*(TBME_T0_pn + TBME_T1_pn);

					  if (is_pn_abcd_here) TBMEs_pn_inter_lab(J , a , b , c , d) += TBME_pn;
					  if (is_pn_badc_here) TBMEs_pn_inter_lab(J , b , a , d , c) += phase_abcd*TBME_pn;
					}

				      if (is_pn_bacd_here || is_pn_abdc_here)
					{
					  TBME_pn = minus_one_pow (ja + jb - J)*0.5*(TBME_T0_pn - TBME_T1_pn);

					  if (is_pn_bacd_here) TBMEs_pn_inter_lab(J , b , a , c , d) += TBME_pn;
					  if (is_pn_abdc_here) TBMEs_pn_inter_lab(J , a , b , d , c) += phase_abcd*TBME_pn;
					}
				    }
				}

			      if (is_pp_here)
				{
				  const double TBME_pp_Coulomb = (is_there_Coulomb)
				    ? (TBME_abcd_Coulomb_lab_calc (Jc_relative_max , J , a , b , c , d , Moshinsky_tables , three_js_recoupling_table , four_js_recoupling_table , TBMEs_pp_HO_relative_Coulomb))
				    : (0.0);

				  TBMEs_pp_inter_lab(J , a , b , c , d) += TBME_pp_nuclear + TBME_pp_Coulomb;
				}
			    }
			}
		    }
		}
	  } 
      }
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized && are_there_pp_TBMEs) TBMEs_pp_inter_lab.MPI_Allgatherv (NUMBER_OF_PROCESSES , MPI_COMM_WORLD);
  if (is_it_MPI_parallelized && are_there_nn_TBMEs) TBMEs_nn_inter_lab.MPI_Allgatherv (NUMBER_OF_PROCESSES , MPI_COMM_WORLD);
  if (is_it_MPI_parallelized && are_there_pn_TBMEs) TBMEs_pn_inter_lab.MPI_Allgatherv (NUMBER_OF_PROCESSES , MPI_COMM_WORLD);

#endif
}

void interaction_class::TBMEs_HO_Coulomb_lab_add (const int Jc_relative_max)
{
  if (!are_there_pp_TBMEs) return;

  const int nmax_HO_lab = nmax_calc (nmax_HO_lab_tab);

  const int n_relative_max = 2*nmax_HO_lab + lmax_for_interaction;

  const int n_relative_max_plus_one = n_relative_max + 1;

  const int lc_relative_max = Jc_relative_max + 1;

  const int lc_relative_max_plus_one = lc_relative_max + 1;

  class array<double> TBMEs_pp_HO_relative_Coulomb(lc_relative_max_plus_one , n_relative_max_plus_one , n_relative_max_plus_one);

  class array<double> dummy;

  TBMEs_Coulomb_HO_relative_calc (TBMEs_pp_HO_relative_Coulomb);
  
  TBMEs_HO_lab_no_added_kinetic_part_from_relative_TBMEs (false , true , 0 , Jc_relative_max , TBMEs_pp_HO_relative_Coulomb , dummy , dummy , dummy);
}

void interaction_class::TBMEs_HO_lab_no_added_kinetic_part (
							    const bool is_there_Coulomb , 
							    const int Jn_relative_max , 
							    const int Jc_relative_max ,
							    const double TBME_A_dependent_factor)
{
  const double reference_time = (is_there_cout && (THIS_PROCESS == MASTER_PROCESS)) ? (absolute_time_determine ()) : (NADA);

  const int nmax_HO_lab = nmax_calc (nmax_HO_lab_tab);

  const int n_relative_max = 2*nmax_HO_lab + lmax_for_interaction;

  const int n_relative_max_plus_one = n_relative_max + 1;
  
  const int Jn_relative_max_plus_one = Jn_relative_max + 1;

  const int ln_relative_max = Jn_relative_max_plus_one;

  const int lc_relative_max = Jc_relative_max + 1;

  const int ln_relative_max_plus_one = ln_relative_max + 1;
  const int lc_relative_max_plus_one = lc_relative_max + 1;

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const bool is_it_FHT = is_it_FHT_determine (TBME_inter);
  const bool is_it_EFT = is_it_EFT_determine (TBME_inter);
  
  const bool is_it_Minnesota = is_it_Minnesota_determine (TBME_inter);

  if (is_there_Coulomb && is_it_SGI_MSGI) TBMEs_HO_Coulomb_lab_add (Jc_relative_max);
  
  if (inter_read == LAB_HO_TBMES_READ)
    {
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  if (is_it_EFT)
	    TBMEs_HO_lab_EFT_read_add ();
	  else
	    {
	      const string TBMEs_HO_lab_file_name = STORAGE_DIR + "v2body_HO_lab.dat";

	      TBMEs_HO_lab_pp_nn_pn_read_add (TBMEs_HO_lab_file_name , 1.0);
	    }
	}
      
#ifdef UseMPI
      
      if (are_there_pp_TBMEs) TBMEs_pp_inter_lab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
      if (are_there_nn_TBMEs) TBMEs_nn_inter_lab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
      if (are_there_pn_TBMEs) TBMEs_pn_inter_lab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

#endif
    
      if (are_there_pp_TBMEs) TBMEs_pp_inter_lab.corrective_factor_multiplication (TBME_A_dependent_factor);
      if (are_there_nn_TBMEs) TBMEs_nn_inter_lab.corrective_factor_multiplication (TBME_A_dependent_factor);
      if (are_there_pn_TBMEs) TBMEs_pn_inter_lab.corrective_factor_multiplication (TBME_A_dependent_factor);
  
      if (is_there_Coulomb && are_there_pp_TBMEs) TBMEs_HO_Coulomb_lab_add (Jc_relative_max);
    }
  else if (TBME_inter == REALISTIC_INTERACTION)
    { 
      class array<double> TBMEs_pp_HO_relative_Coulomb(lc_relative_max_plus_one , n_relative_max_plus_one , n_relative_max_plus_one);
      
      class array<double> TBMEs_pp_HO_relative(n_relative_max_plus_one , ln_relative_max_plus_one , n_relative_max_plus_one , ln_relative_max_plus_one , 2 , Jn_relative_max_plus_one);
      class array<double> TBMEs_nn_HO_relative(n_relative_max_plus_one , ln_relative_max_plus_one , n_relative_max_plus_one , ln_relative_max_plus_one , 2 , Jn_relative_max_plus_one);
      class array<double> TBMEs_pn_HO_relative(n_relative_max_plus_one , ln_relative_max_plus_one , n_relative_max_plus_one , ln_relative_max_plus_one , 2 , Jn_relative_max_plus_one);
      
      TBMEs_real_inter_HO_relative_calc (Jn_relative_max , TBMEs_pp_HO_relative , TBMEs_nn_HO_relative , TBMEs_pn_HO_relative);
      
      if (are_there_pp_TBMEs) TBMEs_pp_HO_relative *= TBME_A_dependent_factor;
      if (are_there_nn_TBMEs) TBMEs_nn_HO_relative *= TBME_A_dependent_factor;
      if (are_there_pn_TBMEs) TBMEs_pn_HO_relative *= TBME_A_dependent_factor;
      
      if (is_there_Coulomb && are_there_pp_TBMEs) TBMEs_Coulomb_HO_relative_calc (TBMEs_pp_HO_relative_Coulomb);

      TBMEs_HO_lab_no_added_kinetic_part_from_relative_TBMEs (true , is_there_Coulomb , Jn_relative_max , Jc_relative_max ,
							      TBMEs_pp_HO_relative_Coulomb , TBMEs_pp_HO_relative , TBMEs_nn_HO_relative , TBMEs_pn_HO_relative);
    }
  else if (is_it_FHT || is_it_Minnesota)
    {
      class array<double> TBMEs_pp_HO_relative_Coulomb(lc_relative_max_plus_one , n_relative_max_plus_one , n_relative_max_plus_one);
      
      class array<double> TBMEs_HO_relative(n_relative_max_plus_one , ln_relative_max_plus_one , n_relative_max_plus_one , ln_relative_max_plus_one , 2 , Jn_relative_max_plus_one);

      if (is_it_Minnesota) TBMEs_Minnesota_HO_relative_calc (Jn_relative_max , TBMEs_HO_relative);
      
      if (is_it_FHT) TBMEs_FHT_HO_relative_calc (Jn_relative_max , TBMEs_HO_relative);
	    
      if (is_there_Coulomb && are_there_pp_TBMEs) TBMEs_Coulomb_HO_relative_calc (TBMEs_pp_HO_relative_Coulomb);

      TBMEs_HO_lab_no_added_kinetic_part_from_relative_TBMEs (true , is_there_Coulomb , Jn_relative_max , Jc_relative_max ,
							      TBMEs_pp_HO_relative_Coulomb , TBMEs_HO_relative , TBMEs_HO_relative , TBMEs_HO_relative);
    }
  else
    error_message_print_abort ("No interaction available in interaction_class::TBMEs_HO_lab_no_added_kinetic_part.");

  if (is_there_cout && (THIS_PROCESS == MASTER_PROCESS))
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time; 

      cout << endl << "Coupled HO TBMEs calculated. time:" << relative_time << " s" << endl << endl;
    }
}















// Three-body like interaction in the Minnesota interaction
// --------------------------------------------------------
// In the Minnesota interaction, a two-body interaction mimicking the three-body interaction is sometimes added. 
// It is a simple Gaussian separable term V(r1,r2) = V3 . exp (-nu r1^2) . exp (-nu r2^2).
// The radial integrals \int u_a_HO(r) u_b_HO(r) exp (-nu r^2) dr are all calculated first, and all TBMEs are calculated afterwards. 
// There is nothing else to consider besides antisymmetry as the interaction is separable.

void interaction_class::radial_three_body_like_HO_calc (class array<double> &radial_three_body_like) const
{
  const unsigned int N_nlj_HO = get_N_nlj_HO ();

  const unsigned int N_bef_R_GL = r_bef_R_tab_GL.dimension (0);
  const unsigned int N_aft_R_GL = r_aft_R_tab_GL.dimension (0);

  radial_three_body_like = 0.0;
    
  for (unsigned int a = 0 ; a < N_nlj_HO ; a++)
    for (unsigned int b = 0 ; b < N_nlj_HO ; b++)
      {	
	const class nlj_struct &sa = shells_HO_table(a);
	const class nlj_struct &sb = shells_HO_table(b);

	if (same_lj (sa , sb))
	  {
	    const int na = sa.get_n () , nb = sb.get_n ();
	    const int la = sa.get_l () , lb = sb.get_l ();
	    
	    double radial_integral = 0.0;

	    for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) radial_integral += w_bef_R_tab_GL(i)*HO_wfs_bef_R_tab_GL(nb , lb , i)*HO_wfs_bef_R_tab_GL(na , la , i)*exp (-nu_three_body_like*r_bef_R_tab_GL(i)*r_bef_R_tab_GL(i));
	    for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) radial_integral += w_aft_R_tab_GL(i)*HO_wfs_aft_R_tab_GL(nb , lb , i)*HO_wfs_aft_R_tab_GL(na , la , i)*exp (-nu_three_body_like*r_aft_R_tab_GL(i)*r_aft_R_tab_GL(i));

	    radial_three_body_like(a , b) = radial_integral;
	  }
      }
}

void interaction_class::TBMEs_HO_three_body_like_add ()
{
  const unsigned int N_nlj_HO = get_N_nlj_HO ();

  class array<double> radial_three_body_like (N_nlj_HO , N_nlj_HO);
  
  radial_three_body_like_HO_calc (radial_three_body_like);

  for (unsigned int a = 0 ; a < N_nlj_HO ; a++)
    for (unsigned int b = 0 ; b < N_nlj_HO ; b++)
      {
	const class pair_str pair_ab(a , b);

	const unsigned int bp_ab = pair_ab.bp_determine (shells_HO_table , shells_HO_table);
	
	const int Jmin_ab = pair_ab.Jmin_determine (shells_HO_table , shells_HO_table);
	const int Jmax_ab = pair_ab.Jmax_determine (shells_HO_table , shells_HO_table);
	
	const bool pair_ab_ordered = pair_ab.ordered ();

	const double norm_ab = (a == b) ? (M_SQRT1_2) : (1.0);

	const class nlj_struct &sa = shells_HO_table(a);
	const class nlj_struct &sb = shells_HO_table(b);
	
	const double ja = sa.get_j ();
	const double jb = sb.get_j ();
			  
	for (unsigned int c = 0 ; c < N_nlj_HO ; c++)
	  for (unsigned int d = 0 ; d < N_nlj_HO ; d++)
	    {
	      const class pair_str pair_cd(c , d);

	      const unsigned int bp_cd = pair_cd.bp_determine (shells_HO_table , shells_HO_table);

	      if ((bp_ab >= BPmin_global) && (bp_ab <= BPmax_global) && (bp_ab == bp_cd) && (pair_ab <= pair_cd))
		{
		  const bool pair_cd_ordered = pair_cd.ordered ();

		  const bool are_pairs_ordered = (pair_ab_ordered && pair_cd_ordered);
		  
		  const int Jmin_cd = pair_cd.Jmin_determine (shells_HO_table , shells_HO_table);
		  const int Jmax_cd = pair_cd.Jmax_determine (shells_HO_table , shells_HO_table);
		  
		  const int Jmin_local = max (Jmin_ab , Jmin_cd);
		  const int Jmax_local = min (Jmax_ab , Jmax_cd);

		  const int Jmin = max (Jmin_local , Jmin_global);
		  const int Jmax = min (Jmax_local , Jmax_global);

		  for (int J = Jmin ; J <= Jmax ; J++)
		    {
		      const bool is_pp_here = (are_there_pp_TBMEs && are_pairs_ordered && (bp_ab >= BPmin_global_pp) && (bp_ab <= BPmax_global_pp) && (J >= Jmin_global_pp) && (J <= Jmax_global_pp));
		      const bool is_nn_here = (are_there_nn_TBMEs && are_pairs_ordered && (bp_ab >= BPmin_global_nn) && (bp_ab <= BPmax_global_nn) && (J >= Jmin_global_nn) && (J <= Jmax_global_nn));
		      
		      const bool is_pn_here = (are_there_pn_TBMEs && (bp_ab >= BPmin_global_pn) && (bp_ab <= BPmax_global_pn) && (J >= Jmin_global_pn) && (J <= Jmax_global_pn));

		      const int phase = minus_one_pow (ja + jb - J);
	
		      if (is_pp_here || is_nn_here)
			{
			  const double TBME_direct   = V_three_body_like*radial_three_body_like(a , c)*radial_three_body_like(b , d);
			  const double TBME_exchange = V_three_body_like*radial_three_body_like(a , d)*radial_three_body_like(b , c);
			  
			  const double norm_cd = (c == d) ? (M_SQRT1_2) : (1.0);

			  const double TBME = (TBME_direct - phase*TBME_exchange)*norm_ab*norm_cd;

			  if (is_pp_here) TBMEs_pp_inter_lab(J , a , b , c , d) += TBME;
			  if (is_nn_here) TBMEs_nn_inter_lab(J , a , b , c , d) += TBME;
			}

		      if (is_pn_here)
			{
			  const double TBME = V_three_body_like*radial_three_body_like(a , c)*radial_three_body_like(b , d);
			  
			  TBMEs_pn_inter_lab(J , a , b , c , d) += TBME;
			}
		    }
		}
	    }
      }
}









// Kinetic part of the two-body interaction with realistic interactions or COSM
// ----------------------------------------------------------------------------
// Besides the nuclear and Coulomb interactions, a two-body kinetic or recoil part enter the two-body part of the Hamiltonian.
//
// It is added to HO TBMEs and is considered here:
//
// Realistic interactions: H = H[one-body kinetic + nuclear + Coulomb] - hbar^2/M      \sum_(i<j) pi.pj, as H = T + V and T = \sum_i (pi - (m/M).P)^2 /(2m), with P = \sum_i pi
// COSM:                   H = H[one-body kinetic + nuclear + Coulomb] + hbar^2/M_core \sum_(i<j) pi.pj, as H = T + U_core + V and T = \sum_i pi^2/(2 mu) - (\sum_(i<j) pi.pj)/M_core, with 1/mu = 1/m + 1/M_core
//
// M and M_core are stored in nucleus_mass, so that only a sign changes from realistic interactions to COSM.
// Hence, one multiplies reduced gradient matrix elements by sqrt(hbar^2/M) or sqrt(hbar^2/M_core) and one just has to take care of the sign afterwards.
// The two-body kinetic TBME is calculated from reduced gradient matrix elements in TBME_CM_operator::P2_over_M, as it is just a simple application of the Wigner-Eckart theorem.
// 
// The formula for reduced gradient matrix elements is:
// <b | p | a> = \int ub_HO(r) [ua_HO'(r) + (la(la+1) - lb(lb+1))/(2r) ua_HO(r)] dr. sqrt (4Pi/3) <b || Y1 || a>

void interaction_class::reduced_grad_set_HO_calc (
						  const double nucleus_mass , 
						  class array<double> &reduced_grad_P2) const 
{
  const unsigned int N_nlj_HO = get_N_nlj_HO ();

  const unsigned int N_bef_R_GL = r_bef_R_tab_GL.dimension (0);
  const unsigned int N_aft_R_GL = r_aft_R_tab_GL.dimension (0);

  const double sqrt_four_pi_over_three = 2.04665341589297697695;
  
  const double sqrt_two_over_kinetic_factor_M = sqrt (2.0/two_amu_over_hbar_square/nucleus_mass);
  
  reduced_grad_P2 = 0.0;
  
  for (unsigned int a = 0 ; a < N_nlj_HO ; a++)
    for (unsigned int b = 0 ; b < N_nlj_HO ; b++)
      {	
	const class nlj_struct &sa = shells_HO_table(a);
	const class nlj_struct &sb = shells_HO_table(b);

	const int na = sa.get_n ();
	const int nb = sb.get_n ();

	const int la = sa.get_l ();
	const int lb = sb.get_l ();

	const double ja = sa.get_j ();
	const double jb = sb.get_j ();

	const double l_factor = 0.5*(la*(la + 1.0) - lb*(lb + 1.0));
	
	const double angular_part = sqrt_four_pi_over_three*OBME_YL_reduced_in_j (1 , la , ja , lb , jb);

	if (angular_part != 0.0)
	  {
	    double radial_integral_grad = 0.0;

	    for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) radial_integral_grad += w_bef_R_tab_GL(i)*HO_wfs_bef_R_tab_GL(nb , lb , i)*(HO_dwfs_bef_R_tab_GL(na , la , i) + l_factor*HO_wfs_bef_R_tab_GL(na , la , i)/r_bef_R_tab_GL(i));
	    for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) radial_integral_grad += w_aft_R_tab_GL(i)*HO_wfs_aft_R_tab_GL(nb , lb , i)*(HO_dwfs_aft_R_tab_GL(na , la , i) + l_factor*HO_wfs_aft_R_tab_GL(na , la , i)/r_aft_R_tab_GL(i));

	    reduced_grad_P2(a , b) = radial_integral_grad*angular_part;
	  }
      }

  reduced_grad_P2 *= sqrt_two_over_kinetic_factor_M;
}

void interaction_class::TBMEs_HO_lab_add_kinetic_part (
						       const bool is_it_COSM ,
						       const double nucleus_mass)
{
  const unsigned int N_nlj_HO = get_N_nlj_HO ();

  class array<double> reduced_grad_P2(N_nlj_HO , N_nlj_HO);
  
  reduced_grad_set_HO_calc (nucleus_mass , reduced_grad_P2);
  
  for (unsigned int a = 0 ; a < N_nlj_HO ; a++)
    for (unsigned int b = 0 ; b < N_nlj_HO ; b++)
      {
	const class pair_str pair_ab(a , b);
	
	const unsigned int bp_ab = pair_ab.bp_determine (shells_HO_table , shells_HO_table);
	
	const int Jmin_ab = pair_ab.Jmin_determine (shells_HO_table , shells_HO_table);
	const int Jmax_ab = pair_ab.Jmax_determine (shells_HO_table , shells_HO_table);
	
	const bool pair_ab_ordered = pair_ab.ordered ();

	for (unsigned int c = 0 ; c < N_nlj_HO ; c++)
	  for (unsigned int d = 0 ; d < N_nlj_HO ; d++)
	    {
	      const class pair_str pair_cd(c , d);

	      const unsigned int bp_cd = pair_cd.bp_determine (shells_HO_table , shells_HO_table);

	      if ((bp_ab >= BPmin_global) && (bp_ab <= BPmax_global) && (bp_ab == bp_cd) && (pair_ab <= pair_cd))
		{
		  const bool pair_cd_ordered = pair_cd.ordered ();

		  const bool are_pairs_ordered = (pair_ab_ordered && pair_cd_ordered);
		  
		  const int Jmin_cd = pair_cd.Jmin_determine (shells_HO_table , shells_HO_table);
		  const int Jmax_cd = pair_cd.Jmax_determine (shells_HO_table , shells_HO_table);
		  
		  const int Jmin_local = max (Jmin_ab , Jmin_cd);
		  const int Jmax_local = min (Jmax_ab , Jmax_cd);

		  const int Jmin = max (Jmin_local , Jmin_global);
		  const int Jmax = min (Jmax_local , Jmax_global);

		  for (int J = Jmin ; J <= Jmax ; J++)
		    {
		      const bool is_pp_here = (are_there_pp_TBMEs && are_pairs_ordered && (bp_ab >= BPmin_global_pp) && (bp_ab <= BPmax_global_pp) && (J >= Jmin_global_pp) && (J <= Jmax_global_pp));
		      const bool is_nn_here = (are_there_nn_TBMEs && are_pairs_ordered && (bp_ab >= BPmin_global_nn) && (bp_ab <= BPmax_global_nn) && (J >= Jmin_global_nn) && (J <= Jmax_global_nn));
		      
		      const bool is_pn_here = (are_there_pn_TBMEs && (bp_ab >= BPmin_global_pn) && (bp_ab <= BPmax_global_pn) && (J >= Jmin_global_pn) && (J <= Jmax_global_pn));

		      const bool is_pp_nn_here = (is_pp_here || is_nn_here);

		      if (is_pp_nn_here)
			{
			  if (is_it_COSM)
			    {
			      if (is_pp_here) TBMEs_pp_inter_lab(J , a , b , c , d) += TBME_CM_operator::P2_over_2M::TBME_J_pp_nn_antisymmetrized (J , a , b , c , d , shells_HO_table , reduced_grad_P2);
			      if (is_nn_here) TBMEs_nn_inter_lab(J , a , b , c , d) += TBME_CM_operator::P2_over_2M::TBME_J_pp_nn_antisymmetrized (J , a , b , c , d , shells_HO_table , reduced_grad_P2);			      
			    } 
			  else
			    {
			      if (is_pp_here) TBMEs_pp_inter_lab(J , a , b , c , d) -= TBME_CM_operator::P2_over_2M::TBME_J_pp_nn_antisymmetrized (J , a , b , c , d , shells_HO_table , reduced_grad_P2);
			      if (is_nn_here) TBMEs_nn_inter_lab(J , a , b , c , d) -= TBME_CM_operator::P2_over_2M::TBME_J_pp_nn_antisymmetrized (J , a , b , c , d , shells_HO_table , reduced_grad_P2);
			    }
			}

		      if (is_pn_here)
			{
			  if (is_it_COSM)
			    TBMEs_pn_inter_lab(J , a , b , c , d) += TBME_CM_operator::P2_over_2M::TBME_J_pn (J , a , b , c , d , shells_HO_table , shells_HO_table , reduced_grad_P2 , reduced_grad_P2);
			  else
			    TBMEs_pn_inter_lab(J , a , b , c , d) -= TBME_CM_operator::P2_over_2M::TBME_J_pn (J , a , b , c , d , shells_HO_table , shells_HO_table , reduced_grad_P2 , reduced_grad_P2);
			}
		    }
		}
	    }
      }
}








void interaction_class::TBMEs_HO_lab_remove_kinetic_part (
							  const bool is_it_COSM ,
							  const double nucleus_mass)
{
  const unsigned int N_nlj_HO = get_N_nlj_HO ();

  class array<double> reduced_grad_P2(N_nlj_HO , N_nlj_HO);
  
  reduced_grad_set_HO_calc (nucleus_mass , reduced_grad_P2);
  
  for (unsigned int a = 0 ; a < N_nlj_HO ; a++)
    for (unsigned int b = 0 ; b < N_nlj_HO ; b++)
      {
	const class pair_str pair_ab(a , b);
	
	const unsigned int bp_ab = pair_ab.bp_determine (shells_HO_table , shells_HO_table);
	
	const int Jmin_ab = pair_ab.Jmin_determine (shells_HO_table , shells_HO_table);
	const int Jmax_ab = pair_ab.Jmax_determine (shells_HO_table , shells_HO_table);
	
	const bool pair_ab_ordered = pair_ab.ordered ();

	for (unsigned int c = 0 ; c < N_nlj_HO ; c++)
	  for (unsigned int d = 0 ; d < N_nlj_HO ; d++)
	    {
	      const class pair_str pair_cd(c , d);

	      const unsigned int bp_cd = pair_cd.bp_determine (shells_HO_table , shells_HO_table);

	      if ((bp_ab >= BPmin_global) && (bp_ab <= BPmax_global) && (bp_ab == bp_cd) && (pair_ab <= pair_cd))
		{
		  const bool pair_cd_ordered = pair_cd.ordered ();

		  const bool are_pairs_ordered = (pair_ab_ordered && pair_cd_ordered);
		  
		  const int Jmin_cd = pair_cd.Jmin_determine (shells_HO_table , shells_HO_table);
		  const int Jmax_cd = pair_cd.Jmax_determine (shells_HO_table , shells_HO_table);
		  
		  const int Jmin_local = max (Jmin_ab , Jmin_cd);
		  const int Jmax_local = min (Jmax_ab , Jmax_cd);

		  const int Jmin = max (Jmin_local , Jmin_global);
		  const int Jmax = min (Jmax_local , Jmax_global);

		  for (int J = Jmin ; J <= Jmax ; J++)
		    {
		      const bool is_pp_here = (are_there_pp_TBMEs && are_pairs_ordered && (bp_ab >= BPmin_global_pp) && (bp_ab <= BPmax_global_pp) && (J >= Jmin_global_pp) && (J <= Jmax_global_pp));
		      const bool is_nn_here = (are_there_nn_TBMEs && are_pairs_ordered && (bp_ab >= BPmin_global_nn) && (bp_ab <= BPmax_global_nn) && (J >= Jmin_global_nn) && (J <= Jmax_global_nn));
		      
		      const bool is_pn_here = (are_there_pn_TBMEs && (bp_ab >= BPmin_global_pn) && (bp_ab <= BPmax_global_pn) && (J >= Jmin_global_pn) && (J <= Jmax_global_pn));

		      const bool is_pp_nn_here = (is_pp_here || is_nn_here);

		      if (is_pp_nn_here)
			{
			  if (is_it_COSM)
			    {
			      if (is_pp_here) TBMEs_pp_inter_lab(J , a , b , c , d) -= TBME_CM_operator::P2_over_2M::TBME_J_pp_nn_antisymmetrized (J , a , b , c , d , shells_HO_table , reduced_grad_P2);
			      if (is_nn_here) TBMEs_nn_inter_lab(J , a , b , c , d) -= TBME_CM_operator::P2_over_2M::TBME_J_pp_nn_antisymmetrized (J , a , b , c , d , shells_HO_table , reduced_grad_P2);
			    } 
			  else
			    {
			      if (is_pp_here) TBMEs_pp_inter_lab(J , a , b , c , d) += TBME_CM_operator::P2_over_2M::TBME_J_pp_nn_antisymmetrized (J , a , b , c , d , shells_HO_table , reduced_grad_P2);
			      if (is_nn_here) TBMEs_nn_inter_lab(J , a , b , c , d) += TBME_CM_operator::P2_over_2M::TBME_J_pp_nn_antisymmetrized (J , a , b , c , d , shells_HO_table , reduced_grad_P2);
			    }
			}

		      if (is_pn_here)
			{
			  if (is_it_COSM)
			    TBMEs_pn_inter_lab(J , a , b , c , d) -= TBME_CM_operator::P2_over_2M::TBME_J_pn (J , a , b , c , d , shells_HO_table , shells_HO_table , reduced_grad_P2 , reduced_grad_P2);
			  else
			    TBMEs_pn_inter_lab(J , a , b , c , d) -= TBME_CM_operator::P2_over_2M::TBME_J_pn (J , a , b , c , d , shells_HO_table , shells_HO_table , reduced_grad_P2 , reduced_grad_P2);
			}
		    }
		}
	    }
      }
}










// Copy to disk of HO TBMEs
// ------------------------
// The HO TBMEs can be copied to disk.
// As GHF TBMEs are calculated in another code and always read from file, it is meaningless to use it here and only real TBMEs are considered here.
// Copy is formatted here and one writes, for example: "0p3/2 1s1/2 0f7/2 0d5/2  1  1   0.123456" , for J=1, Tz=1 and TBME=0.123456.
// The HO length b_lab is written first.

void interaction_class::copy_disk (const string file_name) const
{
  if (inter_read == LAB_BERGGREN_TBMES_READ) error_message_print_abort ("TBMEs in HO basis only in interaction_class::copy_disk");
  
  const unsigned int N_nlj_HO = get_N_nlj_HO ();

  ofstream out_file(file_name.c_str ());
  
  out_file.precision (15);

  out_file << b_lab << endl;

  for (unsigned int a = 0 ; a < N_nlj_HO ; a++)
    {
      const class nlj_struct &sa = shells_HO_table(a);

      for (unsigned int b = 0 ; b < N_nlj_HO ; b++)
	{
	  const class nlj_struct &sb = shells_HO_table(b);
	  
	  const class pair_str pair_ab(a , b);

	  const unsigned int bp_ab = pair_ab.bp_determine (shells_HO_table , shells_HO_table);

	  const int Jmin_ab = pair_ab.Jmin_determine (shells_HO_table , shells_HO_table);
	  const int Jmax_ab = pair_ab.Jmax_determine (shells_HO_table , shells_HO_table);

	  const bool pair_ab_ordered = pair_ab.ordered ();

	  for (unsigned int c = 0 ; c < N_nlj_HO ; c++)
	    {
	      const class nlj_struct &sc = shells_HO_table(c);

	      for (unsigned int d = 0 ; d < N_nlj_HO ; d++)
		{
		  const class nlj_struct &sd = shells_HO_table(d);

		  const class pair_str pair_cd(c , d);
		  
		  const unsigned int bp_cd = pair_cd.bp_determine (shells_HO_table , shells_HO_table);

		  if ((bp_ab >= BPmin_global) && (bp_ab <= BPmax_global) && (bp_ab == bp_cd) && (pair_ab <= pair_cd))
		    {
		      const bool pair_cd_ordered = pair_cd.ordered ();

		      const bool are_pairs_ordered = (pair_ab_ordered && pair_cd_ordered);
		      
		      const int Jmin_cd = pair_cd.Jmin_determine (shells_HO_table , shells_HO_table);
		      const int Jmax_cd = pair_cd.Jmax_determine (shells_HO_table , shells_HO_table);
		      
		      const int Jmin_local = max (Jmin_ab , Jmin_cd);
		      const int Jmax_local = min (Jmax_ab , Jmax_cd);

		      const int Jmin = max (Jmin_local , Jmin_global);
		      const int Jmax = min (Jmax_local , Jmax_global);

		      for (int J = Jmin ; J <= Jmax ; J++)
			{
			  const bool is_pp_here = (are_there_pp_TBMEs && are_pairs_ordered && (bp_ab >= BPmin_global_pp) && (bp_ab <= BPmax_global_pp) && (J >= Jmin_global_pp) && (J <= Jmax_global_pp));
			  const bool is_nn_here = (are_there_nn_TBMEs && are_pairs_ordered && (bp_ab >= BPmin_global_nn) && (bp_ab <= BPmax_global_nn) && (J >= Jmin_global_nn) && (J <= Jmax_global_nn));
			  
			  const bool is_pn_here = (are_there_pn_TBMEs && (bp_ab >= BPmin_global_pn) && (bp_ab <= BPmax_global_pn) && (J >= Jmin_global_pn) && (J <= Jmax_global_pn));

			  if (is_pp_here) out_file << sa << " " << sb << " " << sc << " " << sd << " " << J << " " << -1 << " " << real_dc (TBMEs_pp_inter_lab(J , a , b , c , d)) << endl;
			  if (is_nn_here) out_file << sa << " " << sb << " " << sc << " " << sd << " " << J << " " <<  1 << " " << real_dc (TBMEs_nn_inter_lab(J , a , b , c , d)) << endl;
			  if (is_pn_here) out_file << sa << " " << sb << " " << sc << " " << sd << " " << J << " " <<  0 << " " << real_dc (TBMEs_pn_inter_lab(J , a , b , c , d)) << endl;
			}
		    }
		}
	    }
	}
    }
}











// Calculation of the coupling constant for SGI/MSGI interactions
// --------------------------------------------------------------
// Coupling constants of SGI/MSGI interactions depend on J-Pi-T of two-particle states.
// As TBMEs are coupled to J and not T, and as coupling constants depend on T, isospin decoupling is done here for pn as well.
// The array of coupling constants is V_Gaussian_consts, function of bp (binary parity, see observables_basic_functions.cpp for definition), J and T.
//
// V_Gaussian_consts(bp , J , 1) is returned for pp/nn
//
// If one considers the direct   part of pn TBME (isospin formalism), (V_Gaussian_consts(bp , J , 1) + V_Gaussian_consts(bp , J , 0))/2 is returned
// If one considers the exchange part of pn TBME (isospin formalism), (V_Gaussian_consts(bp , J , 1) - V_Gaussian_consts(bp , J , 0))/2 is returned

double interaction_class::Gaussian_coupling_constant (
						      const unsigned int bp , 
						      const int J , 
						      const bool is_it_pn_direct , 
						      const bool is_it_pn_exchange) const
{
  if (!is_it_SGI_determine (TBME_inter) && !is_it_SGI_MSGI_determine (TBME_inter))
    error_message_print_abort ("SGI or MSGI interaction only in interaction_class::Gaussian_coupling_constant: " + make_string<enum interaction_type> (TBME_inter));

  if (is_it_pn_direct)
    return 0.5*(V_Gaussian_consts(bp , J , 1) + V_Gaussian_consts(bp , J , 0));
  else if (is_it_pn_exchange)
    return 0.5*(V_Gaussian_consts(bp , J , 1) - V_Gaussian_consts(bp , J , 0));
  else
    return V_Gaussian_consts(bp , J , 1);
}












// Addition of weighted interactions, Coulomb and kinetic parts to the current interaction
// ---------------------------------------------------------------------------------------
// In the GSM optimization code, one writes the full interaction as V = \sum_i a_i V_i, where a_i are the parameters to fit and V_i are pre-calculated unit interactions, of central, spin-orbit, tensor type.
// Hence, one recalculates the refitted interaction from the parameters a_i and unit interactions V_i, which is much faster than to recalculate the interaction matrix elements from the beginning.
//
// One unit interaction multiplied by a parameter is added one at a time to the already existing interaction.
// The Coulomb interaction is added afterwards with a parameter equal to one.
// The kinetic part is added at the end.
//
// One also calculates the gradient dV/dx similarly. Indeed, as x = a_i for a given index i and V depends linearly on a_j, one has dV/dx = V_i. 
// It is then sufficient to replace a_j by delta_ij and use the same routine as before to obtain dV/dx.
// Unit interactions are obviously calculated with the same method.

void interaction_class::add_weighted_TBMEs (
					    const double V_parameter ,
					    const class interaction_class &unit_interaction)
{
  if (V_parameter == 0.0) return;
  
  const unsigned int N_nlj_inter = get_N_nlj_inter ();

  const class TBMEs_class &TBMEs_pp_inter_lab_unit_interaction = unit_interaction.TBMEs_pp_inter_lab;
  const class TBMEs_class &TBMEs_nn_inter_lab_unit_interaction = unit_interaction.TBMEs_nn_inter_lab;
  const class TBMEs_class &TBMEs_pn_inter_lab_unit_interaction = unit_interaction.TBMEs_pn_inter_lab;

  const bool are_there_pp_TBMEs_unit_interaction = unit_interaction.are_there_pp_TBMEs , are_there_pp_TBMEs_for_add = (are_there_pp_TBMEs && are_there_pp_TBMEs_unit_interaction);
  const bool are_there_nn_TBMEs_unit_interaction = unit_interaction.are_there_nn_TBMEs , are_there_nn_TBMEs_for_add = (are_there_nn_TBMEs && are_there_nn_TBMEs_unit_interaction);
  const bool are_there_pn_TBMEs_unit_interaction = unit_interaction.are_there_pn_TBMEs , are_there_pn_TBMEs_for_add = (are_there_pn_TBMEs && are_there_pn_TBMEs_unit_interaction);

  for (unsigned int a = 0 ; a < N_nlj_inter ; a++)
    for (unsigned int b = 0 ; b < N_nlj_inter ; b++)
      {
	const class pair_str pair_ab(a , b);

	const unsigned int bp_ab = pair_ab.bp_determine (shells_inter_table , shells_inter_table);
	
	const int Jmin_ab = pair_ab.Jmin_determine (shells_inter_table , shells_inter_table);
	const int Jmax_ab = pair_ab.Jmax_determine (shells_inter_table , shells_inter_table);

	const bool pair_ab_ordered = pair_ab.ordered ();

	for (unsigned int c = 0 ; c < N_nlj_inter ; c++)
	  for (unsigned int d = 0 ; d < N_nlj_inter ; d++)
	    {
	      const class pair_str pair_cd(c , d);
	      
	      const unsigned int bp_cd = pair_cd.bp_determine (shells_inter_table , shells_inter_table);

	      if ((bp_ab >= BPmin_global) && (bp_ab <= BPmax_global) && (bp_ab == bp_cd) && (pair_ab <= pair_cd))
		{
		  const bool pair_cd_ordered = pair_cd.ordered ();

		  const bool are_pairs_ordered = (pair_ab_ordered && pair_cd_ordered);
		  
		  const int Jmin_cd = pair_cd.Jmin_determine (shells_inter_table , shells_inter_table);
		  const int Jmax_cd = pair_cd.Jmax_determine (shells_inter_table , shells_inter_table);
		  
		  const int Jmin_local = max (Jmin_ab , Jmin_cd);
		  const int Jmax_local = min (Jmax_ab , Jmax_cd);

		  const int Jmin = max (Jmin_local , Jmin_global);
		  const int Jmax = min (Jmax_local , Jmax_global);

		  for (int J = Jmin ; J <= Jmax ; J++)
		    {
		      const bool is_pp_here = (are_there_pp_TBMEs_for_add && are_pairs_ordered && (bp_ab >= BPmin_global_pp) && (bp_ab <= BPmax_global_pp) && (J >= Jmin_global_pp) && (J <= Jmax_global_pp));
		      const bool is_nn_here = (are_there_nn_TBMEs_for_add && are_pairs_ordered && (bp_ab >= BPmin_global_nn) && (bp_ab <= BPmax_global_nn) && (J >= Jmin_global_nn) && (J <= Jmax_global_nn));

		      const bool is_pn_here = (are_there_pn_TBMEs_for_add && (bp_ab >= BPmin_global_pn) && (bp_ab <= BPmax_global_pn) && (J >= Jmin_global_pn) && (J <= Jmax_global_pn));

		      if (is_pp_here) TBMEs_pp_inter_lab(J , a , b , c , d) += V_parameter*TBMEs_pp_inter_lab_unit_interaction(J , a , b , c , d);
		      if (is_nn_here) TBMEs_nn_inter_lab(J , a , b , c , d) += V_parameter*TBMEs_nn_inter_lab_unit_interaction(J , a , b , c , d);
		      if (is_pn_here) TBMEs_pn_inter_lab(J , a , b , c , d) += V_parameter*TBMEs_pn_inter_lab_unit_interaction(J , a , b , c , d);
		    }
		}
	    }
      }
}

void interaction_class::calculate_from_units_Coulomb_kinetic (
							      const double frozen_core_mass , 
							      const class vector_class<double> &FHT_EFT_parameters , 
							      const double TBME_A_dependent_factor , 
							      const class array<class interaction_class> &inter_data_units , 
							      const class interaction_class &inter_data_Coulomb)
{
  const bool is_it_FHT = is_it_FHT_determine (TBME_inter);
  const bool is_it_EFT = is_it_EFT_determine (TBME_inter);
  
  if (!is_it_FHT && !is_it_EFT) error_message_print_abort ("FHT or EFT interaction only in interaction_class::calculate_from_units_Coulomb_kinetic");

  const unsigned int dimension_inter_data_units = inter_data_units.dimension (0);

  class array<double> Vp(dimension_inter_data_units);

  Vp = 0.0;
  
  if (is_it_FHT)
    {
      const unsigned int V0_ctr_ot_index = FHT_EFT_parameter_index_determine (V0_CTR_OT_S1_T1 , NADA , NADA);
      const unsigned int V0_ctr_et_index = FHT_EFT_parameter_index_determine (V0_CTR_ET_S1_T0 , NADA , NADA);
      const unsigned int V0_ctr_os_index = FHT_EFT_parameter_index_determine (V0_CTR_OS_S0_T0 , NADA , NADA);
      const unsigned int V0_ctr_es_index = FHT_EFT_parameter_index_determine (V0_CTR_ES_S0_T1 , NADA , NADA);
      const unsigned int V0_so_ot_index  = FHT_EFT_parameter_index_determine (V0_SO_OT_S1_T1  , NADA , NADA);
      const unsigned int V0_so_et_index  = FHT_EFT_parameter_index_determine (V0_SO_ET_S1_T0  , NADA , NADA);
      const unsigned int V0_t_ot_index   = FHT_EFT_parameter_index_determine (V0_T_OT_S1_T1   , NADA , NADA);
      const unsigned int V0_t_et_index   = FHT_EFT_parameter_index_determine (V0_T_ET_S1_T0   , NADA , NADA);
  
      const double V0_ctr_ot = FHT_EFT_parameters(V0_ctr_ot_index);
      const double V0_ctr_et = FHT_EFT_parameters(V0_ctr_et_index);
      const double V0_ctr_os = FHT_EFT_parameters(V0_ctr_os_index);
      const double V0_ctr_es = FHT_EFT_parameters(V0_ctr_es_index);
      const double V0_so_ot  = FHT_EFT_parameters(V0_so_ot_index);
      const double V0_so_et  = FHT_EFT_parameters(V0_so_et_index);
      const double V0_t_ot   = FHT_EFT_parameters(V0_t_ot_index);
      const double V0_t_et   = FHT_EFT_parameters(V0_t_et_index);
  
      V0_ctr_ot_inter = V0_ctr_ot;
      V0_ctr_et_inter = V0_ctr_et;
      V0_ctr_os_inter = V0_ctr_os;
      V0_ctr_es_inter = V0_ctr_es;
      V0_so_ot_inter  = V0_so_ot;
      V0_so_et_inter  = V0_so_et;
      V0_t_ot_inter   = V0_t_ot;
      V0_t_et_inter   = V0_t_et;
      
      Vp(V0_ctr_ot_index) = V0_ctr_ot_inter;
      Vp(V0_ctr_et_index) = V0_ctr_et_inter;
      Vp(V0_ctr_os_index) = V0_ctr_os_inter;
      Vp(V0_ctr_es_index) = V0_ctr_es_inter;
      Vp(V0_so_ot_index)  = V0_so_ot_inter;
      Vp(V0_so_et_index)  = V0_so_et_inter;
      Vp(V0_t_ot_index)   = V0_t_ot_inter;
      Vp(V0_t_et_index)   = V0_t_et_inter;
    }

  if (is_it_EFT)
    {
      const unsigned int VS_const_LO_T0_index          = FHT_EFT_parameter_index_determine (VS_LO_T0                   , NADA , NADA);
      const unsigned int VS_const_LO_T1_index          = FHT_EFT_parameter_index_determine (VS_LO_T1                   , NADA , NADA);
      const unsigned int VT_sigma_product_LO_T0_index  = FHT_EFT_parameter_index_determine (VT_SIGMA_PRODUCT_LO_T0     , NADA , NADA);
      const unsigned int VT_sigma_product_LO_T1_index  = FHT_EFT_parameter_index_determine (VT_SIGMA_PRODUCT_LO_T1     , NADA , NADA);
      const unsigned int V1_q2_NLO_index               = FHT_EFT_parameter_index_determine (V1_Q2_NLO                  , NADA , NADA);
      const unsigned int V2_k2_NLO_index               = FHT_EFT_parameter_index_determine (V2_K2_NLO                  , NADA , NADA);  
      const unsigned int V3_q2_sigma_product_NLO_index = FHT_EFT_parameter_index_determine (V3_Q2_SIGMA_PRODUCT_NLO    , NADA , NADA);
      const unsigned int V4_k2_sigma_product_NLO_index = FHT_EFT_parameter_index_determine (V4_K2_SIGMA_PRODUCT_NLO    , NADA , NADA);
      const unsigned int V5_sigma_q_vector_k_NLO_index = FHT_EFT_parameter_index_determine (V5_SIGMA_Q_VECTOR_K_NLO    , NADA , NADA);  
      const unsigned int V6_sigma_q_product_NLO_index  = FHT_EFT_parameter_index_determine (V6_SIGMA_Q_PRODUCT_NLO     , NADA , NADA);
      const unsigned int V7_sigma_k_product_NLO_index  = FHT_EFT_parameter_index_determine (V7_SIGMA_K_PRODUCT_NLO     , NADA , NADA);

      const double VS_const_LO_T0          = FHT_EFT_parameters(VS_const_LO_T0_index);
      const double VS_const_LO_T1          = FHT_EFT_parameters(VS_const_LO_T1_index);
      const double VT_sigma_product_LO_T0  = FHT_EFT_parameters(VT_sigma_product_LO_T0_index);    
      const double VT_sigma_product_LO_T1  = FHT_EFT_parameters(VT_sigma_product_LO_T1_index);      
      const double V1_q2_NLO               = FHT_EFT_parameters(V1_q2_NLO_index);
      const double V2_k2_NLO               = FHT_EFT_parameters(V2_k2_NLO_index);
      const double V3_q2_sigma_product_NLO = FHT_EFT_parameters(V3_q2_sigma_product_NLO_index);
      const double V4_k2_sigma_product_NLO = FHT_EFT_parameters(V4_k2_sigma_product_NLO_index);
      const double V5_sigma_q_vector_k_NLO = FHT_EFT_parameters(V5_sigma_q_vector_k_NLO_index);  
      const double V6_sigma_q_product_NLO  = FHT_EFT_parameters(V6_sigma_q_product_NLO_index);
      const double V7_sigma_k_product_NLO  = FHT_EFT_parameters(V7_sigma_k_product_NLO_index);

      VS_const_LO_T0_inter          = VS_const_LO_T0;
      VS_const_LO_T1_inter          = VS_const_LO_T1;
      VT_sigma_product_LO_T0_inter  = VT_sigma_product_LO_T0;
      VT_sigma_product_LO_T1_inter  = VT_sigma_product_LO_T1;
      V1_q2_NLO_inter               = V1_q2_NLO;
      V2_k2_NLO_inter               = V2_k2_NLO;
      V3_q2_sigma_product_NLO_inter = V3_q2_sigma_product_NLO;
      V4_k2_sigma_product_NLO_inter = V4_k2_sigma_product_NLO;
      V5_sigma_q_vector_k_NLO_inter = V5_sigma_q_vector_k_NLO;
      V6_sigma_q_product_NLO_inter  = V6_sigma_q_product_NLO;
      V7_sigma_k_product_NLO_inter  = V7_sigma_k_product_NLO;

      Vp(VS_const_LO_T0_index)          = VS_const_LO_T0_inter;
      Vp(VS_const_LO_T1_index)          = VS_const_LO_T1_inter;
      Vp(VT_sigma_product_LO_T0_index)  = VT_sigma_product_LO_T0_inter;
      Vp(VT_sigma_product_LO_T1_index)  = VT_sigma_product_LO_T1_inter;
      Vp(V1_q2_NLO_index)               = V1_q2_NLO_inter;
      Vp(V2_k2_NLO_index)               = V2_k2_NLO_inter;
      Vp(V3_q2_sigma_product_NLO_index) = V3_q2_sigma_product_NLO_inter;
      Vp(V4_k2_sigma_product_NLO_index) = V4_k2_sigma_product_NLO_inter;
      Vp(V5_sigma_q_vector_k_NLO_index) = V5_sigma_q_vector_k_NLO_inter;
      Vp(V6_sigma_q_product_NLO_index)  = V6_sigma_q_product_NLO_inter;
      Vp(V7_sigma_k_product_NLO_index)  = V7_sigma_k_product_NLO_inter;
    }

  Vp *= TBME_A_dependent_factor;
  
  zero ();

  for (unsigned int s = 0 ; s < dimension_inter_data_units ; s++)
    {
      const class interaction_class &inter_data_unit = inter_data_units(s);

      const double Vp_s = Vp(s);

      if (inter_data_unit.is_it_filled ()) add_weighted_TBMEs (Vp_s , inter_data_unit); 
    }

  add_weighted_TBMEs (1.0 , inter_data_Coulomb); 

  TBMEs_HO_lab_add_kinetic_part (true , frozen_core_mass);
}

void interaction_class::calculate_grad_from_units (
						   const class array<class interaction_class> &inter_data_units ,
						   const double TBME_A_dependent_factor , 
						   const enum FHT_EFT_parameter_type FHT_EFT_parameter)
{
  
  
  const bool is_it_FHT = is_it_FHT_determine (TBME_inter);
  const bool is_it_EFT = is_it_EFT_determine (TBME_inter);
  
  if (!is_it_FHT && !is_it_EFT) error_message_print_abort ("FHT or EFT interaction only in interaction_class::calculate_grad_from_units");

  const unsigned int dimension_inter_data_units = inter_data_units.dimension (0);
  
  class array<double> Vp(dimension_inter_data_units);

  Vp = 0.0;
  
  zero ();

  if (is_it_FHT)
    {
      const unsigned int V0_ctr_ot_index = FHT_EFT_parameter_index_determine (V0_CTR_OT_S1_T1 , NADA , NADA);
      const unsigned int V0_ctr_et_index = FHT_EFT_parameter_index_determine (V0_CTR_ET_S1_T0 , NADA , NADA);
      const unsigned int V0_ctr_os_index = FHT_EFT_parameter_index_determine (V0_CTR_OS_S0_T0 , NADA , NADA);
      const unsigned int V0_ctr_es_index = FHT_EFT_parameter_index_determine (V0_CTR_ES_S0_T1 , NADA , NADA);
      const unsigned int V0_so_ot_index  = FHT_EFT_parameter_index_determine (V0_SO_OT_S1_T1  , NADA , NADA);
      const unsigned int V0_so_et_index  = FHT_EFT_parameter_index_determine (V0_SO_ET_S1_T0  , NADA , NADA);
      const unsigned int V0_t_ot_index   = FHT_EFT_parameter_index_determine (V0_T_OT_S1_T1   , NADA , NADA);
      const unsigned int V0_t_et_index   = FHT_EFT_parameter_index_determine (V0_T_ET_S1_T0   , NADA , NADA);
  
      V0_ctr_ot_inter = (FHT_EFT_parameter == V0_CTR_OT_S1_T1) ? (TBME_A_dependent_factor) : (0.0);
      V0_ctr_et_inter = (FHT_EFT_parameter == V0_CTR_ET_S1_T0) ? (TBME_A_dependent_factor) : (0.0); 
      V0_ctr_os_inter = (FHT_EFT_parameter == V0_CTR_OS_S0_T0) ? (TBME_A_dependent_factor) : (0.0);
      V0_ctr_es_inter = (FHT_EFT_parameter == V0_CTR_ES_S0_T1) ? (TBME_A_dependent_factor) : (0.0);
      V0_so_ot_inter  = (FHT_EFT_parameter == V0_SO_OT_S1_T1)  ? (TBME_A_dependent_factor) : (0.0);
      V0_so_et_inter  = (FHT_EFT_parameter == V0_SO_ET_S1_T0)  ? (TBME_A_dependent_factor) : (0.0); 
      V0_t_ot_inter   = (FHT_EFT_parameter == V0_T_OT_S1_T1)   ? (TBME_A_dependent_factor) : (0.0);
      V0_t_et_inter   = (FHT_EFT_parameter == V0_T_ET_S1_T0)   ? (TBME_A_dependent_factor) : (0.0);

      Vp(V0_ctr_ot_index) = V0_ctr_ot_inter;
      Vp(V0_ctr_et_index) = V0_ctr_et_inter;
      Vp(V0_ctr_os_index) = V0_ctr_os_inter;
      Vp(V0_ctr_es_index) = V0_ctr_es_inter;
      Vp(V0_so_ot_index)  = V0_so_ot_inter;
      Vp(V0_so_et_index)  = V0_so_et_inter;
      Vp(V0_t_ot_index)   = V0_t_ot_inter;
      Vp(V0_t_et_index)   = V0_t_et_inter;
    }
  
  if (is_it_EFT)
    {
      const unsigned int VS_const_LO_T0_index          = FHT_EFT_parameter_index_determine (VS_LO_T0                   , NADA , NADA);
      const unsigned int VS_const_LO_T1_index          = FHT_EFT_parameter_index_determine (VS_LO_T1                   , NADA , NADA);
      const unsigned int VT_sigma_product_LO_T0_index  = FHT_EFT_parameter_index_determine (VT_SIGMA_PRODUCT_LO_T0     , NADA , NADA);
      const unsigned int VT_sigma_product_LO_T1_index  = FHT_EFT_parameter_index_determine (VT_SIGMA_PRODUCT_LO_T1     , NADA , NADA);
      const unsigned int V1_q2_NLO_index               = FHT_EFT_parameter_index_determine (V1_Q2_NLO                  , NADA , NADA);
      const unsigned int V2_k2_NLO_index               = FHT_EFT_parameter_index_determine (V2_K2_NLO                  , NADA , NADA);  
      const unsigned int V3_q2_sigma_product_NLO_index = FHT_EFT_parameter_index_determine (V3_Q2_SIGMA_PRODUCT_NLO    , NADA , NADA);
      const unsigned int V4_k2_sigma_product_NLO_index = FHT_EFT_parameter_index_determine (V4_K2_SIGMA_PRODUCT_NLO    , NADA , NADA);
      const unsigned int V5_sigma_q_vector_k_NLO_index = FHT_EFT_parameter_index_determine (V5_SIGMA_Q_VECTOR_K_NLO    , NADA , NADA);  
      const unsigned int V6_sigma_q_product_NLO_index  = FHT_EFT_parameter_index_determine (V6_SIGMA_Q_PRODUCT_NLO     , NADA , NADA);
      const unsigned int V7_sigma_k_product_NLO_index  = FHT_EFT_parameter_index_determine (V7_SIGMA_K_PRODUCT_NLO     , NADA , NADA);
  
      VS_const_LO_T0_inter          = (FHT_EFT_parameter == VS_LO_T0)                ? (TBME_A_dependent_factor) : (0.0);
      VS_const_LO_T1_inter          = (FHT_EFT_parameter == VS_LO_T1)                ? (TBME_A_dependent_factor) : (0.0);
      VT_sigma_product_LO_T0_inter  = (FHT_EFT_parameter == VT_SIGMA_PRODUCT_LO_T0)  ? (TBME_A_dependent_factor) : (0.0);
      VT_sigma_product_LO_T1_inter  = (FHT_EFT_parameter == VT_SIGMA_PRODUCT_LO_T1)  ? (TBME_A_dependent_factor) : (0.0);
      V1_q2_NLO_inter               = (FHT_EFT_parameter == V1_Q2_NLO)               ? (TBME_A_dependent_factor) : (0.0);
      V2_k2_NLO_inter               = (FHT_EFT_parameter == V2_K2_NLO)               ? (TBME_A_dependent_factor) : (0.0);
      V3_q2_sigma_product_NLO_inter = (FHT_EFT_parameter == V3_Q2_SIGMA_PRODUCT_NLO) ? (TBME_A_dependent_factor) : (0.0);
      V4_k2_sigma_product_NLO_inter = (FHT_EFT_parameter == V4_K2_SIGMA_PRODUCT_NLO) ? (TBME_A_dependent_factor) : (0.0);
      V5_sigma_q_vector_k_NLO_inter = (FHT_EFT_parameter == V5_SIGMA_Q_VECTOR_K_NLO) ? (TBME_A_dependent_factor) : (0.0);
      V6_sigma_q_product_NLO_inter  = (FHT_EFT_parameter == V6_SIGMA_Q_PRODUCT_NLO)  ? (TBME_A_dependent_factor) : (0.0);
      V7_sigma_k_product_NLO_inter  = (FHT_EFT_parameter == V7_SIGMA_K_PRODUCT_NLO)  ? (TBME_A_dependent_factor) : (0.0);
      
      Vp(VS_const_LO_T0_index)          = VS_const_LO_T0_inter;
      Vp(VS_const_LO_T1_index)          = VS_const_LO_T1_inter;
      Vp(VT_sigma_product_LO_T0_index)  = VT_sigma_product_LO_T0_inter;
      Vp(VT_sigma_product_LO_T1_index)  = VT_sigma_product_LO_T1_inter;
      Vp(V1_q2_NLO_index)               = V1_q2_NLO_inter;
      Vp(V2_k2_NLO_index)               = V2_k2_NLO_inter;
      Vp(V3_q2_sigma_product_NLO_index) = V3_q2_sigma_product_NLO_inter;
      Vp(V4_k2_sigma_product_NLO_index) = V4_k2_sigma_product_NLO_inter;
      Vp(V5_sigma_q_vector_k_NLO_index) = V5_sigma_q_vector_k_NLO_inter;
      Vp(V6_sigma_q_product_NLO_index)  = V6_sigma_q_product_NLO_inter;
      Vp(V7_sigma_k_product_NLO_index)  = V7_sigma_k_product_NLO_inter;
    }
    
  for (unsigned int s = 0 ; s < dimension_inter_data_units ; s++)
    {
      const class interaction_class &inter_data_unit = inter_data_units(s);
      
      const double Vp_s = Vp(s);

      if (inter_data_unit.is_it_filled ()) add_weighted_TBMEs (Vp_s , inter_data_unit); 
    }
}

void interaction_class::calculate_unit (
					const int Jn_relative_max , 
					const enum FHT_EFT_parameter_type FHT_EFT_parameter)
{
  const bool is_it_FHT = is_it_FHT_determine (TBME_inter);
  const bool is_it_EFT = is_it_EFT_determine (TBME_inter);
  
  if (!is_it_FHT && !is_it_EFT) error_message_print_abort ("FHT or EFT interaction only in interaction_class::calculate_unit");

  zero ();
  
  if (is_it_FHT)
    {
      V0_ctr_ot_inter = (FHT_EFT_parameter == V0_CTR_OT_S1_T1) ? (1.0) : (0.0);
      V0_ctr_et_inter = (FHT_EFT_parameter == V0_CTR_ET_S1_T0) ? (1.0) : (0.0); 
      V0_ctr_os_inter = (FHT_EFT_parameter == V0_CTR_OS_S0_T0) ? (1.0) : (0.0);
      V0_ctr_es_inter = (FHT_EFT_parameter == V0_CTR_ES_S0_T1) ? (1.0) : (0.0);
      V0_so_ot_inter  = (FHT_EFT_parameter == V0_SO_OT_S1_T1)  ? (1.0) : (0.0);
      V0_so_et_inter  = (FHT_EFT_parameter == V0_SO_ET_S1_T0)  ? (1.0) : (0.0); 
      V0_t_ot_inter   = (FHT_EFT_parameter == V0_T_OT_S1_T1)   ? (1.0) : (0.0);
      V0_t_et_inter   = (FHT_EFT_parameter == V0_T_ET_S1_T0)   ? (1.0) : (0.0);
    }
 
  if (is_it_EFT)
    {
      VS_const_LO_T0_inter          = (FHT_EFT_parameter == VS_LO_T0)                ? (1.0) : (0.0);
      VS_const_LO_T1_inter          = (FHT_EFT_parameter == VS_LO_T1)                ? (1.0) : (0.0);
      VT_sigma_product_LO_T0_inter  = (FHT_EFT_parameter == VT_SIGMA_PRODUCT_LO_T0)  ? (1.0) : (0.0);
      VT_sigma_product_LO_T1_inter  = (FHT_EFT_parameter == VT_SIGMA_PRODUCT_LO_T1)  ? (1.0) : (0.0);
      V1_q2_NLO_inter               = (FHT_EFT_parameter == V1_Q2_NLO)               ? (1.0) : (0.0);
      V2_k2_NLO_inter               = (FHT_EFT_parameter == V2_K2_NLO)               ? (1.0) : (0.0);
      V3_q2_sigma_product_NLO_inter = (FHT_EFT_parameter == V3_Q2_SIGMA_PRODUCT_NLO) ? (1.0) : (0.0);
      V4_k2_sigma_product_NLO_inter = (FHT_EFT_parameter == V4_K2_SIGMA_PRODUCT_NLO) ? (1.0) : (0.0);
      V5_sigma_q_vector_k_NLO_inter = (FHT_EFT_parameter == V5_SIGMA_Q_VECTOR_K_NLO) ? (1.0) : (0.0);
      V6_sigma_q_product_NLO_inter  = (FHT_EFT_parameter == V6_SIGMA_Q_PRODUCT_NLO)  ? (1.0) : (0.0);
      V7_sigma_k_product_NLO_inter  = (FHT_EFT_parameter == V7_SIGMA_K_PRODUCT_NLO)  ? (1.0) : (0.0);
    }
  
  TBMEs_HO_lab_no_added_kinetic_part (false , Jn_relative_max , 0 , 1.0);
}












// Calculation of all interaction matrix elements and multipolar expansions
// ------------------------------------------------------------------------
// Previous routines are called according to the case unless one read TBMEs from a file using Berggren or GHF basis.
// A-dependence is applied to all nuclear TBMEs if there is one unless one uses the optimization code.


void interaction_class::inter_data_calc (const class input_data_str &input_data)
{
  const bool only_dimensions = input_data.get_only_dimensions ();

  const bool non_zero_NBMEs_proportion_only = input_data.get_non_zero_NBMEs_proportion_only ();

  if (only_dimensions || non_zero_NBMEs_proportion_only) return;

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      if (is_it_only_basis)
	{
	  cout << endl << "Basis interaction" << endl;
	  cout <<         "-----------------" << endl << endl;
	}
      else
	{
	  cout << endl << "Interaction" << endl;
	  cout <<         "-----------" << endl << endl;
	}
    }

  zero ();
  
  const double TBME_A_dependent_factor = (called_code != OPTIMIZATION_CODE) ? (TBME_A_dependent_factor_calc (input_data)) : (1.0);
  
  V_SDI *= TBME_A_dependent_factor;

  V_Gaussian_consts *= TBME_A_dependent_factor;
	  
  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);
  
  if (inter_read == LAB_BERGGREN_TBMES_READ)
    {
      if (are_there_pp_TBMEs) TBMEs_GHF_lab_read_add (TBMEs_pp_inter_lab);
      if (are_there_nn_TBMEs) TBMEs_GHF_lab_read_add (TBMEs_nn_inter_lab);
      if (are_there_pn_TBMEs) TBMEs_GHF_lab_read_add (TBMEs_pn_inter_lab);
    }
  else
    {
      const bool neutron_basis_potential = input_data.get_neutron_basis_potential ();
  
      const bool is_Coulomb_to_be_added = input_data.get_is_Coulomb_to_be_added ();

      const int Jc_relative_max = (is_it_only_basis) ? (input_data.get_Jc_relative_max_basis ()) : (input_data.get_Jc_relative_max ());
  
      if ((TBME_inter == COULOMB_INTERACTION) && !neutron_basis_potential && is_Coulomb_to_be_added)
	TBMEs_HO_Coulomb_lab_add (Jc_relative_max);
      else
	{
	  const enum potential_type basis_potential = input_data.get_basis_potential ();

	  const int Jn_relative_max = (is_it_only_basis) ? (input_data.get_Jn_relative_max_basis ()) : (input_data.get_Jn_relative_max ());

	  const bool is_there_Coulomb = (is_it_only_basis) ? (!neutron_basis_potential && is_Coulomb_to_be_added) : (is_Coulomb_to_be_added);
  
	  const double nucleus_mass = (is_it_only_basis) ? (input_data.get_nucleus_mass_basis ()) : (input_data.get_nucleus_mass ());
  
	  const bool is_it_SDI = is_it_SDI_determine (TBME_inter);
	  
	  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

	  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);
	  
	  const bool is_it_SDI_SGI_MSGI = (is_it_SDI || is_it_SGI_MSGI);

	  const bool is_it_Minnesota = is_it_Minnesota_determine (TBME_inter);
  
	  const bool is_it_nuclear_mixed = is_it_nuclear_mixed_determine (TBME_inter);

	  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);

	  const bool is_Coulomb_to_be_added = input_data.get_is_Coulomb_to_be_added ();
  
	  const bool is_there_calc_only_basis = (is_it_only_basis && ((basis_potential == HF) || (basis_potential == MSDHF)));
  
	  if (is_there_calc_only_basis || !is_it_only_basis)
	    {	      
	      if (is_it_SGI)                                    SGI_radial_tables_calc ();

	      if (is_it_SDI_SGI_MSGI && is_Coulomb_to_be_added) TBMEs_HO_Coulomb_lab_add (Jc_relative_max);
	      	      
	      if (is_it_nuclear_mixed)                          TBMEs_HO_lab_no_added_kinetic_part (is_there_Coulomb , Jn_relative_max , Jc_relative_max , TBME_A_dependent_factor);

	      if (is_it_Minnesota)                              TBMEs_HO_three_body_like_add ();

	      if (is_it_COSM && !is_it_SDI_SGI_MSGI)            TBMEs_HO_lab_add_kinetic_part (true , nucleus_mass);

	      if (!is_it_COSM)                                  TBMEs_HO_lab_add_kinetic_part (false , nucleus_mass);
	    }
	}
    }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time;
 
      cout << endl << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;
      
      if (is_it_only_basis)
	cout << "Basis interaction calculated. time:" << relative_time << " s" << endl;
      else
	cout << "Interaction calculated. time:" << relative_time << " s" << endl;
      
      cout << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl << endl;
    }
}


double used_memory_calc (const class interaction_class &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.nmax_HO_lab_tab) + used_memory_calc (T.shells_HO_table) + used_memory_calc (T.shells_HO_indices) + used_memory_calc (T.nmax_inter_lab_tab) + used_memory_calc (T.shells_inter_table) + used_memory_calc (T.shells_inter_indices) + used_memory_calc (T.TBMEs_pp_inter_lab) + used_memory_calc (T.TBMEs_nn_inter_lab) + used_memory_calc (T.TBMEs_pn_inter_lab) + used_memory_calc (T.Vl_SGI_tab_GL) + used_memory_calc (T.V_Gaussian_consts) + used_memory_calc (T.r_bef_R_tab_GL) + used_memory_calc (T.w_bef_R_tab_GL) + used_memory_calc (T.r_aft_R_tab_GL) + used_memory_calc (T.w_aft_R_tab_GL) + used_memory_calc (T.HO_wfs_bef_R_tab_GL) + used_memory_calc (T.HO_dwfs_bef_R_tab_GL) + used_memory_calc (T.HO_wfs_aft_R_tab_GL) + used_memory_calc (T.HO_dwfs_aft_R_tab_GL) + used_memory_calc (T.r_bef_R_tab_GL_SGI_MSGI) + used_memory_calc (T.w_bef_R_tab_GL_SGI_MSGI) + used_memory_calc (T.HO_wfs_bef_R_tab_GL_SGI_MSGI) + used_memory_calc (T.HO_dwfs_bef_R_tab_GL_SGI_MSGI) + used_memory_calc (T.HO_overlaps_Fermi) + used_memory_calc (T.V_Coulomb_HO_basis) - (sizeof (T.nmax_HO_lab_tab) + sizeof (T.shells_HO_table) + sizeof (T.shells_HO_indices) + sizeof (T.nmax_inter_lab_tab) + sizeof (T.shells_inter_table) + sizeof (T.shells_inter_indices) + sizeof (T.TBMEs_pp_inter_lab) + sizeof (T.TBMEs_nn_inter_lab) + sizeof (T.TBMEs_pn_inter_lab) + sizeof (T.Vl_SGI_tab_GL) + sizeof (T.V_Gaussian_consts) + sizeof (T.r_bef_R_tab_GL) + sizeof (T.w_bef_R_tab_GL) + sizeof (T.r_aft_R_tab_GL) + sizeof (T.w_aft_R_tab_GL) + sizeof (T.HO_wfs_bef_R_tab_GL) + sizeof (T.HO_dwfs_bef_R_tab_GL) + sizeof (T.HO_wfs_aft_R_tab_GL) + sizeof (T.HO_dwfs_aft_R_tab_GL) + sizeof (T.r_bef_R_tab_GL_SGI_MSGI) + sizeof (T.w_bef_R_tab_GL_SGI_MSGI) + sizeof (T.HO_wfs_bef_R_tab_GL_SGI_MSGI) + sizeof (T.HO_dwfs_bef_R_tab_GL_SGI_MSGI) + sizeof (T.HO_overlaps_Fermi) + sizeof (T.V_Coulomb_HO_basis))/1000000.0;

  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;
}

