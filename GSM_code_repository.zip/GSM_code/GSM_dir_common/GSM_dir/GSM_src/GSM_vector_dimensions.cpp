#include "../GSM_include/GSM_include_def_common.h"

using namespace string_routines;
using namespace inputs_misc;
using namespace GSM_vector_dimensions;


// TYPE is double or complex
// -------------------------

// TBME means two-body matrix element
// ----------------------------------

// Routines named ...one_configuration... are for MSDHF calculations, where one does shell model calculations on only one configuration to optimize
// ------------------------------------------------------------------------------------------------------------------------------------------------



// Definition of total angular momentum projection indices
// -------------------------------------------------------
//
// General case
// ------------
// iM is the index associated to the total angular momentum projection M of the current GSM vector, 
// and is equal to M + M[max], with M[max] the maximal M quantum number of all basis vectors,
// which is Zval.mp[max] (PROTONS_ONLY), Nval.mn[max] (NEUTRONS_ONLY), or Zval.mp[max] + Nval.mn[max] (PROTONS_NEUTRONS).
// Hence, the maximal possible value for iM is iM_max = 2.M[max].
//
// proton-neutron case
// -------------------
// For the previous case, one has iMp_max = 2.Mp[max] and iMn_max = 2.Mn[max].
//
// One writes iMp for the index associated to the total angular momentum projection Mp of the proton  part of the current GSM vector, equal to Mp + Mp[max], with Mp[max] = Zval.mp[max] .
// One writes iMn for the index associated to the total angular momentum projection Mn of the neutron part of the current GSM vector, equal to Mn + Mn[max], with Mn[max] = Nval.mn[max] .
//
// One writes iMp_min_M, iMp_max_M, the minimal and maximal indices of Mp so that M = Mp + Mn, and hence iM = iMp + iMn, where iMp_min_M <= iMp <= iMp_max_M in a GSM vector.
// One writes iMn_min_M, iMp_max_M, the minimal and maximal indices of Mn so that M = Mp + Mn, and hence iM = iMp + iMn, where iMn_min_M <= iMn <= iMn_max_M in a GSM vector.
//
// Indeed, as Mp + Mn = M, the minimal and maximal values of Mp and Mn depend on M, are not only +/- |Mp[max]| and +/- |Mn[max]|.
//
// For example:
// if one considers 2 protons in 0f7/2 and 2 neutrons in 1p3/2 and M=0, Mp_min(M) = -2 and Mp[max](M) = 2 as one must have Mp = -Mn, and |Mn| <= 2, while |Mp| <= 6 in the proton part.
// if one considers 2 protons in 1p3/2 and 2 neutrons in 0f7/2 and M=0, Mn_min(M) = -2 and Mn[max](M) = 2 as one must have Mn = -Mp, and |Mp| <= 2, while |Mn| <= 6 in the neutron part.
//
// One clearly has: Mp <= M - Mn[min] = M + Mn[max], and Mp >= M - Mn[max]. Symmetrically,  Mn <= M + Mp[max] and Mn >= M - Mp[max].
// As the indices of Mp, Mn, M are  iMp = Mp + Mp[max], iMn = Mn + Mn[max] and iM = M+M[max] = M + Mp[max] + Mn[max],
// one obtains iMp <= iM, iMp >= iM - iMn_max, and  iMn <= iM, iMn >= iM - iMp_max.
// Evidently, one also has iMp >= 0, iMp <= iMp_max and iMn >= 0, iMp <= iMn_max.
// Thus: iMp_min_M = max (0 , iM - iMn_max) , iMp_max_M = min (iMp_max , iM), iMn_min_M = max (0 , iM - iMp_max) , iMn_max_M = min (iMn_max , iM).
//
//
//
//
// Slater determinant indices in the general case
// ----------------------------------------------
//
// sum_GSM_vector_dimensions is a class of type sum_GSM_vector_dimensions_class (see below).
//
// proton or neutron case
// ----------------------
// The basis Slater determinant index read: I(SD) = sum_GSM_vector_dimensions(n_scat , iC) + SD_index.
// Indeed, sum_GSM_vector_dimensions(n_scat , iC) is the sum of all SD dimensions of configuration indices smaller or equal to that in sum_GSM_vector_dimensions, where parity and M are fixed.
// As one cannot have truncations when configuration is fixed, the dimension of Slater determinants |SD> with these quantum numbers is dimension_SD = dimensions_SD_set(BP , n_scat , iC , iM).
//
// proton-neutron case
// -------------------
// The basis Slater determinant index read: I(SD) = sum_GSM_vector_dimensions(BPp , n_scat_p , n_scat_n , iCp , iCn , iMp) + dimension_SDn.SDp_index + SDn_index, where |SD> = |SDp> |SDn>.
// Indeed, sum_GSM_vector_dimensions(BPp , n_scat_p , n_scat_n , iCp , iCn , iMp) is the sum of all SD dimensions of configuration and Mp indices smaller or equal to that in sum_GSM_vector_dimensions,
// so that this shift provides with the first index of the space of Slater determinants |SD> bearing these quantum numbers.
// As one cannot have truncations when configuration and M indices are fixed, the dimension of Slater determinants |SD> with these quantum numbers is dimension_SDp.dimension_SDn,
// where dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp) and dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn).
// BPn and iMn are not given as inputs in sum_GSM_vector_dimensions as they are provided by BP = binary_parity_product (BPp , BPn) and iMp + iMn = iM.
//
// Slater determinant indices
// --------------------------
// One considers here proton or neutron Slater determinants.
// SD_index is an index for which all SD quantum numbers are fixed (see GSM_array_BP_Nscat_iC_iM_SD.hpp): SD = SD_set(BP , n_scat , iC , iM , SD_index).
// One also uses total Slater determinant indices in the code, where all quantum numbers are included.
// They are equal to total_SD_index = SD_set.index_determine (BP , n_scat , iC , iM , SD_index), i.e. it is the full Slater determinant index in the SD_set:
// One has: SD = SD_set(BP , n_scat , iC , iM , SD_index) = SD_set[total_SD_index].
//
//
//
//
// Slater determinant indices when only one configuration is occupied in basis space for MSDHF calculations
// --------------------------------------------------------------------------------------------------------
//
// sum_GSM_vector_dimensions is a class of type sum_GSM_vector_dimensions_one_configuration_class (see below).
//
// proton or neutron case
// ----------------------
// The basis Slater determinant index simply reads: I(SD) = SD_index, with SD = SD_set(BP , n_scat , iC , iM , SD_index).
// Indeed, configuration, parity and M are fixed, so one considers only the Slater determinants stated above.
// The dimension of Slater determinants |SD> with these quantum numbers is dimension_SD = dimensions_SD_set(BP , n_scat , iC , iM).
//
// proton-neutron case
// -------------------
// The basis Slater determinant index read: I(SD) = sum_GSM_vector_dimensions(iMp) + dimension_SDn.SDp_index + SDn_index, where |SD> = |SDp> |SDn>.
// Indeed, sum_GSM_vector_dimensions(iMp) is the sum of all SD dimensions of Mp indices smaller or equal to that in sum_GSM_vector_dimensions, as configuration is fixed,
// so that this shift provides with the first index of the space of Slater determinants |SD> bearing this quantum number.
// The dimension of Slater determinants |SD> with these quantum numbers is dimension_SDp.dimension_SDn,
// where dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp) and dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn),
// the BPp , n_scat_p , iCp , BPn , n_scat_n , iCn quantum numbers being fixed by the optimizes MSDHF configuration.
// iMn is not given as input in sum_GSM_vector_dimensions as it is provided by iMp + iMn = iM.














// Calculation of the optimal many-body angular momentum projection M to use for GSM vectors
// -----------------------------------------------------------------------------------------
// One considers here a single GSM eigenvector.
// If one demands M=J for all vectors, J is returned.
//
// Odd nuclei
// ----------
// One considers the M value leading to the smallest dimension.
// It M is always M=J.
//
// Even nuclei
// -----------
// One considers the M value leading to the smallest dimension.
//
// M can be M=0 as one uses time reversal symmetry therein, for which about half of vector components only are calculated. 
// It is not exactly half as a few Slater determinants are equal to their symmetric by time reversal symmetry.
//
// One has then to determine if one must choose M=0 or M=J.
// One considers that GSM matrices are full for this calculation.
// Let us show that it does not significantly change the situation here.
// One assumes that the number of non-zero matrix elements is about the same for all M quantum numbers, which is a good approximation when M is small, which is the case in practice.
// Hence, the number of operations for Hamiltonian times vector in the M=0 case is about (d(M=0)^alpha)/2 and is d(M=J)^alpha in the M=J case, 
// with d(M) the GSM space dimension and d(M)^alpha the number of non-zero matrix elements.
// One has 3/2 <= alpha <= 2 from typical sparse matrix to full matrix.
// Hence: (d(M=0)^alpha)/2 < d(M=J)^alpha <=> (1/2)^(1/alpha) d(M=0) < d(M=J).
// As 0.63 <= (1/2)^(1/alpha) <= 0.71, considering that matrices are full (alpha = 2) only leads to a 10% change in (1/2)^(1/alpha), which is negligible compared to other approximations made here.
//
// Hence, one takes M=0 if sqrt(1/2) . d(M=0) < d(M=J) and M=J otherwise.
//
// Comments are for testing, as one can always have M=1/2 for odd nuclei, M=0 for even nuclei, and M=J in all cases.

double GSM_vector_dimensions::optimal_M_calc (
					      const class input_data_str &input_data ,
					      const class nucleons_data &prot_data , 
					      const class nucleons_data &neut_data , 
					      const unsigned int BP , 
					      const double J)
{
  const bool M_equal_J_imposed_in_GSM_vectors = input_data.get_M_equal_J_imposed_in_GSM_vectors ();

  if (M_equal_J_imposed_in_GSM_vectors) return J;
  
  const bool is_it_cluster_CM_HO_basis_calculation = input_data.get_is_it_cluster_CM_HO_basis_calculation ();

  const enum space_type space = input_data.get_space ();
  
  const bool truncation_hw = input_data.get_truncation_hw (); 
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const int n_scat_max_p = (!is_it_cluster_CM_HO_basis_calculation) ? (prot_data.get_n_scat_max ()) : (0);
  const int n_scat_max_n = (!is_it_cluster_CM_HO_basis_calculation) ? (neut_data.get_n_scat_max ()) : (0);
  
  const int n_scat_max = (!is_it_cluster_CM_HO_basis_calculation) ? (input_data.get_n_scat_max ()) : (0);
	
  const int Ep_max_hw = prot_data.get_E_max_hw ();
  const int En_max_hw = neut_data.get_E_max_hw ();
  
  const int n_holes_max_p = prot_data.get_n_holes_max ();
  const int n_holes_max_n = neut_data.get_n_holes_max ();
  
  const int E_max_hw = input_data.get_E_max_hw ();
  
  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int two_J = make_int (2.0*J);

  const unsigned long int total_space_dimension_max_M_is_zero = (two_J%2 == 0)
    ? (total_space_dimension_M_calc (space , truncation_hw , truncation_ph ,
				     n_holes_max_p , n_scat_max_p , Ep_max_hw ,
				     n_holes_max_n , n_scat_max_n , En_max_hw ,
				     n_holes_max   , n_scat_max   , E_max_hw  , prot_data , neut_data , BP , 0.0))
    : (NADA);

  const unsigned long int total_space_dimension_max_M_is_J = total_space_dimension_M_calc (space , truncation_hw , truncation_ph ,
											   n_holes_max_p , n_scat_max_p , Ep_max_hw ,
											   n_holes_max_n , n_scat_max_n , En_max_hw ,
											   n_holes_max   , n_scat_max   , E_max_hw  , prot_data , neut_data , BP , J);

  //const double M = J; // For testing only.
  //const double M = (two_J%2 == 0) ? (0.0) : (0.5); // For testing only.
  const double M = ((two_J%2 == 0) && (make_uns_int (M_SQRT1_2*total_space_dimension_max_M_is_zero) < total_space_dimension_max_M_is_J)) ? (0.0) : (J);

  return M;
}

double GSM_vector_dimensions::optimal_M_calc_one_configuration (
								const enum space_type space , 
								const class nucleons_data &prot_data , 
								const class nucleons_data &neut_data , 
								const double J)
{
  const int two_J = make_int (2.0*J);

  const unsigned long int total_space_dimension_max_M_is_zero = (two_J%2 == 0) ? (total_space_dimension_M_calc_one_configuration (space , prot_data , neut_data , 0.0)) : (NADA);
  
  const unsigned long int total_space_dimension_max_M_is_J = total_space_dimension_M_calc_one_configuration (space , prot_data , neut_data , J);

  //const double M = J; // For testing only.
  //const double M = (two_J%2 == 0) ? (0.0) : (0.5); // For testing only.
  const double M = ((two_J%2 == 0) && (make_uns_int (M_SQRT1_2*total_space_dimension_max_M_is_zero) < total_space_dimension_max_M_is_J)) ? (0.0) : (J);

  return M;
}





// Calculation of the optimal many-body angular momentum projection M to use for all GSM vectors
// ---------------------------------------------------------------------------------------------
// If one demands M=J for all vectors, M=J only is considered .
//
// Otherwise, One considers here all the GSM eigenvectors to calculate.
// The best M to use for one GSM eigenvector is the M value calculated in optimal_M_calc.
// This value is firstly stored in the array of optimal M values for all eigensets (i.e. sets of eigenvectors with same parity and J quantum numbers).
// However, if one stores Hamiltonian matrix elements, it would be inefficient to recalculate many times the Hamiltonian for different M values, as it is much slower than Hamiltonian matrix.vector multiplications.
// Consequently, if one stores Hamiltonian matrix elements, one takes the smallest M value for all GSM eigenvectors of fixed parity, which can be used for all J >= M.
// Indeed, it is much faster not to recalculate Hamiltonians for different M values, even if Hamiltonian matrix.vector multiplications are slightly slower than with the optimal M of this GSM eigenvector.

void GSM_vector_dimensions::M_table_calc (
					  const class input_data_str &input_data ,
					  const class nucleons_data &prot_data , 
					  const class nucleons_data &neut_data , 
					  const class array<unsigned int> &BP_eigenset_tab , 
					  const class array<double> &J_eigenset_tab , 
					  class array<double> &M_table)
{
  const enum space_type space = input_data.get_space ();
  
  const enum storage_type Hamiltonian_storage = input_data.get_Hamiltonian_storage ();
					    
  const unsigned int eigenset_number = M_table.dimension (0);

  const double M_max = M_max_calc (space , prot_data , neut_data);

  for (unsigned int eigenset_index = 0 ; eigenset_index < eigenset_number ; eigenset_index++)
    {
      const unsigned int BP = BP_eigenset_tab(eigenset_index);

      const double J = J_eigenset_tab(eigenset_index);
      
      M_table(eigenset_index) = optimal_M_calc (input_data , prot_data , neut_data , BP , J);
    }

  const bool M_equal_J_imposed_in_GSM_vectors = input_data.get_M_equal_J_imposed_in_GSM_vectors ();

  if (M_equal_J_imposed_in_GSM_vectors) return;
 
  if (is_it_full_or_partial_storage_determine (Hamiltonian_storage))
    {
      double M_min_BP_0 = M_max;
      double M_min_BP_1 = M_max;

      for (unsigned int eigenset_index = 0 ; eigenset_index < eigenset_number ; eigenset_index++) 
	{
	  const unsigned int BP = BP_eigenset_tab(eigenset_index);
	  
	  const double M = M_table(eigenset_index);

	  if (BP == 0) M_min_BP_0 = min (M , M_min_BP_0);
	  if (BP == 1) M_min_BP_1 = min (M , M_min_BP_1);
	}

      for (unsigned int eigenset_index = 0 ; eigenset_index < eigenset_number ; eigenset_index++) 
	{
	  const unsigned int BP = BP_eigenset_tab(eigenset_index);

	  if (BP == 0) M_table(eigenset_index) = M_min_BP_0;
	  if (BP == 1) M_table(eigenset_index) = M_min_BP_1;
	}
    }
}








// Check if a configuration belongs to the model space
// ---------------------------------------------------
// One checks if a configuration belongs to the model space with valence protons or neutrons only (is_basis_state_in_space_pp_nn)
// or with both protons and neutrons (is_basis_state_in_space_pn).
// 
// Energy truncation
// -----------------
// truncation_hw (hbar omega) must be true or there is no truncation.
// Otherwise, the energy truncation of the proton/neutron Slater determinant E_hw (is_basis_state_in_space_pp_nn) 
// or the sum of the energy truncation of the proton and neutron Slater determinants Ep_hw + En_hw (is_basis_state_in_space_pn)
// must be smaller than the maximal energy truncation E_max_hw.
//
// Particle-hole truncation
// ------------------------
// Particle-hole means particle-hole excitation from core unfrozen states to valence states or pole states to scattering states.
// truncation_ph (particle-hole) must be true or there is no truncation.
//
// Otherwise:
//
// The number of holes of the proton/neutron Slater determinant n_holes (is_basis_state_in_space_pp_nn) 
// or the sum of the numbers of holes of the proton and neutron Slater determinants n_holes_p + n_holes_n (is_basis_state_in_space_pn)
// must be smaller than the maximal number of holes n_holes_max.
//
// The number of particles in the continuum of the proton/neutron Slater determinant n_scat (is_basis_state_in_space_pp_nn) 
// or the sum of the numbers of particles in the continuum of the proton and neutron Slater determinants n_scat_p + n_scat_n (is_basis_state_in_space_pn)
// must be smaller than the maximal number of particles in the continuum n_scat_max.

bool GSM_vector_dimensions::is_basis_state_in_space_pp_nn (
							   const bool truncation_hw , 
							   const bool truncation_ph , 
							   const int n_holes , 
							   const int n_scat , 
							   const int E_hw , 
							   const int n_holes_max , 
							   const int n_scat_max , 
							   const int E_max_hw)
{
  if (truncation_hw && (E_hw > E_max_hw)) return false;

  if (truncation_ph && (n_holes > n_holes_max)) return false;

  if (truncation_ph && (n_scat > n_scat_max)) return false;

  return true;
}

bool GSM_vector_dimensions::is_basis_state_in_space_pn (
							const bool truncation_hw , 
							const bool truncation_ph , 
							const int n_holes_p , 
							const int n_scat_p , 
							const int Ep_hw , 
							const int n_holes_n , 
							const int n_scat_n , 
							const int En_hw , 
							const int n_holes_max , 
							const int n_scat_max , 
							const int E_max_hw)
{
  if (truncation_hw && (Ep_hw + En_hw > E_max_hw)) return false;
  
  if (truncation_ph && (n_holes_p + n_holes_n > n_holes_max)) return false;
  
  if (truncation_ph && (n_scat_p + n_scat_n > n_scat_max)) return false;

  return true;
}










// Calculation of the GSM space dimension for fixed parity and M quantum numbers for one configuration (MSDHF calculations, where one does shell model calculations on only one configuration to optimize)
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// The total space dimension for fixed parity and M quantum numbers is calculated for the optimized configuration.
// One first checks if |M| <= M_max of the total space and |M| <= M_max_C of the considered configuration, as otherwise the dimension is zero, which is returned.
//
// One considers in the following that it is not the case.
//
// Valence protons only or neutrons only
// -------------------------------------
// The dimension is the number of protons or neutrons Slater determinants of the configuration.
// The zero in T(BP_one_configuration , 0 , iC_one_configuration) afterwards, with T an array, is the number of particles of the continuum, as the considered configuration has to belong to the pole space.
//
// Valence protons and neutrons
// ----------------------------
// The dimension is \sum_Mp dimension_SDp(Mp). dimension_SDn(Mn), where M = Mp + Mn,
//     dimension_SDp(Mp) is the number of proton  Slater determinants of total angular momentum projection Mp,
// and dimension_SDn(Mn) is the number of neutron Slater determinants of total angular momentum projection Mn.
//
// The variables of the proton-neutron case ending with "_p" or "_n", or with "BP,C,M" replaced by "BPp,BPn,Cp,Cn,Mp,Mn", are the same as those of the protons only or neutrons only case, for protons or neutrons then.

unsigned int GSM_vector_dimensions::total_space_dimension_M_calc_pp_nn_one_configuration (
											  const class nucleons_data &particles_data , 
											  const double M)
{
  const double M_max = particles_data.get_M_max ();
  
  const int iM_max = particles_data.get_iM_max ();
  
  const int iM = make_int (M + M_max);

  const int two_iM = 2*iM;

  const int iM_abs_M = (two_iM >= iM_max) ? (iM) : (iM_max - iM);
  
  if (iM_abs_M > iM_max) return 0;

  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  const class array_of_configuration &configuration_set = particles_data.get_configuration_set ();

  const unsigned int BP_one_configuration = particles_data.get_BP_one_configuration ();
  const unsigned int iC_one_configuration = particles_data.get_iC_one_configuration ();  

  const class configuration &C_one_configuration = configuration_set(BP_one_configuration , 0 , iC_one_configuration);

  const double two_M_max_C = C_one_configuration.two_M_max_determine (shells_qn);

  const int two_M_max = iM_max;

  const int iM_max_C = (two_M_max_C + two_M_max)/2;
  
  if (iM_abs_M > iM_max_C) return 0;
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = particles_data.get_dimensions_SD_set ();

  return dimensions_SD_set(BP_one_configuration , 0 , iC_one_configuration , iM);
}

unsigned int GSM_vector_dimensions::total_space_dimension_M_calc_pn_one_configuration (
										       const class nucleons_data &prot_data , 
										       const class nucleons_data &neut_data , 
										       const double M)
{
  const double Mp_max = prot_data.get_M_max ();
  const double Mn_max = neut_data.get_M_max ();
  
  const int iMp_max = prot_data.get_iM_max ();
  const int iMn_max = neut_data.get_iM_max ();
  
  const double M_max = Mp_max + Mn_max;

  const int iM_max = iMp_max + iMn_max;
  
  const int iM = make_int (M + M_max);

  const int two_iM = 2*iM;

  const int iM_abs_M = (two_iM >= iM_max) ? (iM) : (iM_max - iM);
  
  if (iM_abs_M > iM_max) return 0;

  const unsigned int BPp_one_configuration = prot_data.get_BP_one_configuration ();
  const unsigned int BPn_one_configuration = neut_data.get_BP_one_configuration ();
  
  const unsigned int iCp_one_configuration = prot_data.get_iC_one_configuration ();
  const unsigned int iCn_one_configuration = neut_data.get_iC_one_configuration ();

  const class array_of_configuration &configuration_set_p = prot_data.get_configuration_set ();
  const class array_of_configuration &configuration_set_n = neut_data.get_configuration_set ();

  const class array<class nlj_struct> &shells_qn_p = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_data.get_shells_quantum_numbers ();

  const class configuration &Cp_one_configuration = configuration_set_p(BPp_one_configuration , 0 , iCp_one_configuration);
  const class configuration &Cn_one_configuration = configuration_set_n(BPn_one_configuration , 0 , iCn_one_configuration);
  
  const int two_M_max_Cp = Cp_one_configuration.two_M_max_determine (shells_qn_p);
  const int two_M_max_Cn = Cn_one_configuration.two_M_max_determine (shells_qn_n);

  const int two_Mp_max = iMp_max;
  const int two_Mn_max = iMn_max;
  
  const int iMp_max_Cp = (two_M_max_Cp + two_Mp_max)/2;
  const int iMn_max_Cn = (two_M_max_Cn + two_Mn_max)/2;

  const int iMp_min_M = max (0 , iM - iMn_max);
  
  const int iMp_max_M = min (iMp_max , iM);

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  unsigned long int total_space_dimension_M = 0;
  
  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
    {
      const int iMn = iM - iMp;
      
      const int two_iMp = 2*iMp;
      const int two_iMn = 2*iMn;
      
      const int iMp_abs_Mp = (two_iMp >= iMp_max) ? (iMp) : (iMp_max - iMp);
      const int iMn_abs_Mn = (two_iMn >= iMn_max) ? (iMn) : (iMn_max - iMn);
      
      if (iMp_abs_Mp > iMp_max_Cp) continue;
      if (iMn_abs_Mn > iMn_max_Cn) continue;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp_one_configuration , 0 , iCp_one_configuration , iMp);
      const unsigned int dimension_SDn = dimensions_SDn_set(BPn_one_configuration , 0 , iCn_one_configuration , iMn);
      
      total_space_dimension_M += dimension_SDp*dimension_SDn;
    }

  return total_space_dimension_M;
}

unsigned int GSM_vector_dimensions::total_space_dimension_M_calc_one_configuration (
										    const enum space_type space , 
										    const class nucleons_data &prot_data , 
										    const class nucleons_data &neut_data , 
										    const double M)
{
  switch (space)
    {
    case PROTONS_NEUTRONS: return total_space_dimension_M_calc_pn_one_configuration (prot_data , neut_data , M);
      
    case PROTONS_ONLY:  return total_space_dimension_M_calc_pp_nn_one_configuration (prot_data , M);      
    case NEUTRONS_ONLY: return total_space_dimension_M_calc_pp_nn_one_configuration (neut_data , M);

    default: abort_all ();
    }

  return NADA;
}





















// Calculation of the GSM space dimension for fixed parity and M quantum numbers
// -----------------------------------------------------------------------------
// The total space dimension for fixed parity and M quantum numbers is calculated.
// One first checks if |M| <= M_max of the total space, as otherwise the dimension is zero, which is returned.
//
// One considers in the following that it is not the case.
//
// Valence protons only or neutrons only
// -------------------------------------
// The dimension is \sum_C dimension_SD_C(M), where dimension_SD_C(M) is the number of proton or neutron Slater determinants of total angular momentum projection M of the configuration C,
//
// Valence protons and neutrons
// ----------------------------
// The dimension is \sum_(Cp,Cn,Mp) dimension_SDp_Cp(Mp). dimension_SDn_Cn(Mn), where M = Mp + Mn,
//     dimension_SDp_Cp(Mp) is the number of proton  Slater determinants of total angular momentum projection Mp of the configuration Cp
// and dimension_SDn_cn(Mn) is the number of neutron Slater determinants of total angular momentum projection Mn of the configuration Cn.
//
// In order to fulfull truncations, one first checks if Cp has its energy truncation and number of particles in the continuum smaller than their maximal values (if truncated).
// After this, one checks if the (Cp,Cn) total configuration has its energy truncation and number of particles (protons and neutrons) in the continuum smaller than their maximal values (if truncated).
//
// The variables of the proton-neutron case ending with "_p" or "_n", or with "BP,C,M" replaced by "BPp,BPn,Cp,Cn,Mp,Mn", are the same as those of the protons only or neutrons only case, for protons or neutrons then.

unsigned long int GSM_vector_dimensions::total_space_dimension_M_calc_pp_nn (
									     const bool truncation_hw , 
									     const bool truncation_ph ,  
									     const int n_holes_max , 
									     const int n_scat_max ,
									     const int E_max_hw , 
									     const class nucleons_data &particles_data , 
									     const unsigned int BP , 
									     const double M)
{
  const double M_max = particles_data.get_M_max ();
  
  const int iM_max = particles_data.get_iM_max ();
  
  const int iM = make_int (M + M_max);

  const int two_iM = 2*iM;

  const int iM_abs_M = (two_iM >= iM_max) ? (iM) : (iM_max - iM);
  
  if (iM_abs_M > iM_max) return 0;
  
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = particles_data.get_dimensions_SD_set ();
  
  const class array<unsigned int> &dimensions_configuration_set = particles_data.get_dimensions_configuration_set ();

  const class array_BP_Nscat_iC<int> &n_holes_table = particles_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &E_hw_table = particles_data.get_E_hw_table ();

  unsigned long int total_space_dimension_M = 0;

  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int dimension_C = dimensions_configuration_set(BP , n_scat);
      
      for (unsigned int iC = 0 ; iC < dimension_C ; iC++)
	{
	  const int n_holes = n_holes_table(BP , n_scat , iC);
	  
	  const int E_hw = E_hw_table(BP , n_scat , iC);

	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
	  
	  total_space_dimension_M += dimensions_SD_set(BP , n_scat , iC , iM);
	}
    }

  return total_space_dimension_M;
}

unsigned long int GSM_vector_dimensions::total_space_dimension_M_calc_pn (
									  const bool truncation_hw , 
									  const bool truncation_ph ,
									  const int n_holes_max_p , 
									  const int n_scat_max_p , 
									  const int n_scat_max_n , 
									  const int Ep_max_hw ,
									  const int n_holes_max ,  
									  const int n_scat_max , 
									  const int E_max_hw , 
									  const class nucleons_data &prot_data , 
									  const class nucleons_data &neut_data , 
									  const unsigned int BP , 
									  const double M)
{
  const double Mp_max = prot_data.get_M_max ();
  const double Mn_max = neut_data.get_M_max ();
  
  const int iMp_max = prot_data.get_iM_max ();
  const int iMn_max = neut_data.get_iM_max ();
  
  const double M_max = Mp_max + Mn_max;
  
  const int iM_max = iMp_max + iMn_max;
  
  const int iM = make_int (M + M_max);

  const int two_iM = 2*iM;

  const int iM_abs_M = (two_iM >= iM_max) ? (iM) : (iM_max - iM);
  
  if (iM_abs_M > iM_max) return 0;

  const int iMp_min_M = max (0 , iM - iMn_max);

  const int iMp_max_M = min (iMp_max , iM);

  const class array<unsigned int> &dimensions_configuration_set_p = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_set_n = neut_data.get_dimensions_configuration_set ();

  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  unsigned long int total_space_dimension_M = 0;

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP);
      
      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int dimension_Cp = dimensions_configuration_set_p(BPp , n_scat_p);

	  for (unsigned int iCp = 0 ; iCp < dimension_Cp ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);
	      
	      const int Ep = Ep_hw_table(BPp , n_scat_p , iCp);
	      
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

	      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
		{
		  const unsigned int dimension_Cn = dimensions_configuration_set_n(BPn , n_scat_n);
		  
		  for (unsigned int iCn = 0 ; iCn < dimension_Cn ; iCn++)
		    {
		      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
		      
		      const int En = En_hw_table(BPn , n_scat_n , iCn);
		      
		      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep , n_holes_n , n_scat_n , En , n_holes_max , n_scat_max , E_max_hw))
			{
			  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
			    {
			      const int iMn = iM - iMp;

			      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);
			      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);
      
			      total_space_dimension_M += dimension_SDp*dimension_SDn;
			    }}}}}}}

  return total_space_dimension_M;
}

unsigned long int GSM_vector_dimensions::total_space_dimension_M_calc (
								       const enum space_type space , 
								       const bool truncation_hw , 
								       const bool truncation_ph ,
								       const int n_holes_max_p ,  
								       const int n_scat_max_p , 
								       const int Ep_max_hw , 
								       const int n_holes_max_n , 
								       const int n_scat_max_n , 
								       const int En_max_hw , 
								       const int n_holes_max , 
								       const int n_scat_max , 
								       const int E_max_hw , 
								       const class nucleons_data &prot_data , 
								       const class nucleons_data &neut_data , 
								       const unsigned int BP , 
								       const double M)
{
  switch (space)
    {
    case PROTONS_ONLY:     return total_space_dimension_M_calc_pp_nn (truncation_hw , truncation_ph , n_holes_max_p , n_scat_max_p , Ep_max_hw , prot_data , BP , M);
    case NEUTRONS_ONLY:    return total_space_dimension_M_calc_pp_nn (truncation_hw , truncation_ph , n_holes_max_n , n_scat_max_n , En_max_hw , neut_data , BP , M);

    case PROTONS_NEUTRONS: return total_space_dimension_M_calc_pn (truncation_hw , truncation_ph , n_holes_max_p , n_scat_max_p , n_scat_max_n , Ep_max_hw , n_holes_max , n_scat_max , E_max_hw , prot_data , neut_data , BP , M);

    default: abort_all ();
    }

  return NADA;
}







// Calculation of the maximal total angular projection of the GSM space 
// --------------------------------------------------------------------
// It is M_max = Zval.mp_max (PROTONS_ONLY), M_max = Nval.mn_max (NEUTRONS_ONLY), M_max = Zval.mp_max + Nval.mn_max (PROTONS_NEUTRONS)

double GSM_vector_dimensions::M_max_calc (
					  const enum space_type space , 
					  const class nucleons_data &prot_data , 
					  const class nucleons_data &neut_data)
{
  switch (space)
    {
    case PROTONS_ONLY:     return prot_data.get_M_max ();
    case NEUTRONS_ONLY:    return neut_data.get_M_max ();

    case PROTONS_NEUTRONS: return (prot_data.get_M_max () + neut_data.get_M_max ());

    default: abort_all ();
    }

  return NADA;
}






// Calculation of the maximal total angular projection of the GSM space for which the GSM dimension is not zero 
// ------------------------------------------------------------------------------------------------------------
// As one poses M_max = Zval.mp_max (PROTONS_ONLY), M_max = Nval.mn_max (NEUTRONS_ONLY), M_max = Zval.mp_max + Nval.mn_max (PROTONS_NEUTRONS), 
// where the Pauli principle is not taken into account,
// the maximal total angular projection of the GSM space for which the GSM dimension is not zero is smaller than the latter in general.
// It is calculated here by looping on M = M_max , M_max-1, M_max-2, ... and by calculating the space dimension for that M until it is not equal to zero

double GSM_vector_dimensions::M_max_dimension_non_zero_calc (
							     const unsigned int BP , 
							     const enum space_type space , 
							     const bool truncation_hw , 
							     const bool truncation_ph ,
							     const int n_holes_max_p ,  
							     const int n_scat_max_p , 
							     const int Ep_max_hw , 
							     const int n_holes_max_n , 
							     const int n_scat_max_n , 
							     const int En_max_hw , 
							     const int n_holes_max , 
							     const int n_scat_max , 
							     const int E_max_hw , 
							     const class nucleons_data &prot_data , 
							     const class nucleons_data &neut_data)
{
  const double M_max = M_max_calc (space , prot_data , neut_data);

  const int two_M_max = make_int (2.0*M_max);

  const bool is_M_integer = (two_M_max%2 == 0);

  const unsigned int M_index_max = (is_M_integer) ? (make_uns_int (M_max)) : (make_uns_int (M_max - 0.5));

  for (unsigned int M_index = M_index_max ; M_index <= M_index_max ; M_index--)
    {
      const double M = (is_M_integer) ? (M_index) : (M_index + 0.5);

      const unsigned long int total_space_dimension_M = total_space_dimension_M_calc (space , truncation_hw , truncation_ph ,
										      n_holes_max_p , n_scat_max_p , Ep_max_hw ,
										      n_holes_max_n , n_scat_max_n , En_max_hw ,
										      n_holes_max   , n_scat_max   , E_max_hw  , prot_data , neut_data , BP , M);

      if (total_space_dimension_M > 0) return M;
    }

  return NADA;
}

double GSM_vector_dimensions::M_max_dimension_non_zero_calc_one_configuration (
									       const enum space_type space , 
									       const class nucleons_data &prot_data , 
									       const class nucleons_data &neut_data)
{
  const double M_max = M_max_calc (space , prot_data , neut_data);

  const int two_M_max = make_int (2.0*M_max);

  const bool is_M_integer = (two_M_max%2 == 0);

  const unsigned int M_index_max = (is_M_integer) ? (make_uns_int (M_max)) : (make_uns_int (M_max - 0.5));

  for (unsigned int M_index = M_index_max ; M_index <= M_index_max ; M_index--)
    {
      const double M = (is_M_integer) ? (M_index) : (M_index + 0.5);

      const unsigned long int total_space_dimension_M = total_space_dimension_M_calc_one_configuration (space , prot_data , neut_data , M);

      if (total_space_dimension_M > 0) return M;
    }

  return NADA;
}







// Print of GSM model space dimensions in J-scheme and M-scheme for all J and positive M values
// --------------------------------------------------------------------------------------------
// The diagonalized GSM spaces are in M-scheme, and one always uses M >= 0, as dimensions are identical for M and -M.
// The physical dimension is that of J-scheme, as GSM eigenvectors have a fixed J.
// J-scheme dimensions are straightforward to calculate from M-scheme dimensions:
// J-scheme-dimension(J) = M-scheme-dimension(M) - M-scheme-dimension(M+1) with M=J (M-scheme-dimension(M.max+1) = 0 by convention)
// This comes from the fact that an M-scheme space with angular projection M contains all eigenvectors with J >= M.
// Dimensions at pole approximation level and in truncated spaces with 0,..., [maximal allowed number of particles in the continuum] are printed, even if some of these truncations are not used..
// Pole approximation is enforced by demanding zero particles in the continuum for configurations and by using the truncation energies proper to pole approximation.
// GSM model space dimensions are printed the following way:    
// 0+: dimension(J)=100 dimension(M)=1000, where one has J-Pi=0+ for the first dimension and M-Pi=0+ for the second dimension.
// See total_space_dimension_M_calc for the calculation of M-scheme dimensions.

void GSM_vector_dimensions::J_total_space_dimensions_calc_print (
								 const bool is_there_cout , 
								 const bool is_it_pole_approximation , 
								 const class input_data_str &input_data , 
								 const class nucleons_data &prot_data , 
								 const class nucleons_data &neut_data , 
								 class array<unsigned long int> &total_space_dimensions_good_J)
{
  const enum space_type space = input_data.get_space ();

  const bool truncation_hw = input_data.get_truncation_hw ();
  
  const double M_max = M_max_calc (space , prot_data , neut_data);

  const int two_M_max = make_int (2.0*M_max);

  const bool is_M_integer = (two_M_max%2 == 0);
  
  const int n_holes_max = (is_it_pole_approximation) ? (input_data.get_n_holes_max_pole_approximation ()) : (input_data.get_n_holes_max ());
  
  const int n_scat_max = (is_it_pole_approximation) ? (0) : (input_data.get_n_scat_max ());
    
  const unsigned int J_index_max = (is_M_integer) ? (make_uns_int (M_max)) : (make_uns_int (M_max - 0.5));
  
  const int n_holes_max_p = (is_it_pole_approximation) ? (prot_data.get_n_holes_max_pole_approximation ()) : (prot_data.get_n_holes_max ());
  const int n_holes_max_n = (is_it_pole_approximation) ? (neut_data.get_n_holes_max_pole_approximation ()) : (neut_data.get_n_holes_max ());
  
  const int n_scat_max_p = (is_it_pole_approximation) ? (0) : (prot_data.get_n_scat_max ());
  const int n_scat_max_n = (is_it_pole_approximation) ? (0) : (neut_data.get_n_scat_max ());
  
  const int E_max_hw = (is_it_pole_approximation) ? (input_data.get_E_max_hw_pole_approximation ()) : (input_data.get_E_max_hw ());

  const int Ep_max_hw = (is_it_pole_approximation) ? (prot_data.get_E_max_hw_pole_approximation ()) : (prot_data.get_E_max_hw ());
  const int En_max_hw = (is_it_pole_approximation) ? (neut_data.get_E_max_hw_pole_approximation ()) : (neut_data.get_E_max_hw ());
  
  const int n_scat_max_plus_one = n_scat_max + 1;

  const int J_index_max_plus_one = J_index_max + 1;

  class array<unsigned long int> total_space_dimensions_all_M(2 , n_scat_max_plus_one ,  J_index_max_plus_one);
  
  for (int n_scat_max_sub = 0 ; n_scat_max_sub <= n_scat_max ; n_scat_max_sub++)
    {
      const bool truncation_ph = (is_it_pole_approximation || (n_scat_max_sub < n_scat_max)) ? (true) : (input_data.get_truncation_ph ());

      const int n_scat_max_p_sub = min (n_scat_max_sub , n_scat_max_p);
      const int n_scat_max_n_sub = min (n_scat_max_sub , n_scat_max_n);

      for (unsigned int M_index = 0 ; M_index <= J_index_max ; M_index++)
	{
	  const double M = (is_M_integer) ? (M_index) : (M_index + 0.5);

	  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
	    total_space_dimensions_all_M(BP , n_scat_max_sub , M_index) = total_space_dimension_M_calc (space , truncation_hw , truncation_ph ,
													n_holes_max_p , n_scat_max_p_sub , Ep_max_hw ,
													n_holes_max_n , n_scat_max_n_sub , En_max_hw ,
													n_holes_max   , n_scat_max_sub   , E_max_hw  , prot_data , neut_data , BP , M);
	}

      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
	{
	  for (unsigned int J_index = 0 ; J_index < J_index_max ; J_index++)
	    {
	      const unsigned int M_index = J_index;

	      const unsigned long int total_space_dimension_J = total_space_dimensions_all_M(BP , n_scat_max_sub , M_index) - total_space_dimensions_all_M(BP , n_scat_max_sub , M_index + 1);

	      total_space_dimensions_good_J(BP , n_scat_max_sub , J_index) = total_space_dimension_J;
	    }

	  const unsigned int M_index_max = J_index_max;
	  
	  total_space_dimensions_good_J(BP , n_scat_max_sub , J_index_max) = total_space_dimensions_all_M(BP , n_scat_max_sub , M_index_max);
	}
    }

  if (is_there_cout && (THIS_PROCESS == MASTER_PROCESS))
    {
      if (is_it_pole_approximation)
	{
	  cout << endl << "Pole approximation dimensions for starting point" << endl;
	  cout <<         "------------------------------------------------" << endl << endl;
	  
	  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
	    {
	      for (unsigned int J_index = 0 ; J_index <= J_index_max ; J_index++)
		{
		  const unsigned int M_index = J_index;

		  const double J = (is_M_integer) ? (J_index) : (J_index + 0.5);
		
		  if (total_space_dimensions_good_J(BP , 0 , J_index) > 0)
		    cout << J_Pi_string (BP , J) << ":"
			 << " dimension(J)=" << total_space_dimensions_good_J(BP , 0 , J_index)
			 << " dimension(M)=" << total_space_dimensions_all_M (BP , 0 , M_index) << endl;
		}

	      cout << endl;
	    }
	}
      else
	{
	  cout << endl << "Full space dimensions" << endl;
	  cout <<         "---------------------" << endl << endl;

	  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
	    {
	      for (unsigned int J_index = 0 ; J_index <= J_index_max ; J_index++)
		{
		  const unsigned int M_index = J_index;

		  const double J = (is_M_integer) ? (J_index) : (J_index + 0.5);
		
		  if (total_space_dimensions_good_J(BP , n_scat_max , J_index) > 0)
		    cout << J_Pi_string (BP , J) << ":"
			 << " dimension(J)=" << total_space_dimensions_good_J(BP , n_scat_max , J_index)
			 << " dimension(M)=" << total_space_dimensions_all_M (BP , n_scat_max , M_index) << endl;
		}
	      cout << endl;
	    }
	}
      
      cout << endl << endl;
    }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && !is_it_pole_approximation && is_there_cout)
    {
      cout << endl
	   << "----------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;
      
      cout << "Space dimensions calculated" << endl;
      
      cout << "----------------------------------------------------------------------------------------------------------------------------------------------------------------"
	   << endl << endl;
    }
}

void GSM_vector_dimensions::all_J_total_space_dimensions_calc_print (
								     const bool is_there_cout , 
								     const class input_data_str &input_data , 
								     const class nucleons_data &prot_data , 
								     const class nucleons_data &neut_data , 
								     class array<unsigned long int> &dimensions_good_J_pole_approximation ,
								     class array<unsigned long int> &dimensions_good_J)
{
  const bool is_it_cluster_CM_HO_basis_calculation = input_data.get_is_it_cluster_CM_HO_basis_calculation ();
  
  const bool copy_J_OBMEs_TBMEs = input_data.get_copy_J_OBMEs_TBMEs ();
  
  if (!copy_J_OBMEs_TBMEs) 
    {
      J_total_space_dimensions_calc_print (is_there_cout , true , input_data , prot_data , neut_data , dimensions_good_J_pole_approximation);
      
      if (!is_it_cluster_CM_HO_basis_calculation) J_total_space_dimensions_calc_print (is_there_cout , false , input_data , prot_data , neut_data , dimensions_good_J);
    }
}

unsigned int GSM_vector_dimensions::BP_J_dimension_calc_print_one_configuration (
										 const enum space_type space , 
										 const class nucleons_data &prot_data , 
										 const class nucleons_data &neut_data , 
										 const unsigned int BP , 
										 const double J)
{
  const bool is_M_integer = (make_int (2.0*J)%2 == 0) ? (true) : (false);

  const double M_max = M_max_calc (space , prot_data , neut_data);

  const unsigned int J_index_max = (is_M_integer) ? (make_uns_int (M_max)) : (make_uns_int (M_max - 0.5));

  const unsigned int BP_one_configuration = BP_one_configuration_determine (space , prot_data , neut_data);

  if (BP != BP_one_configuration) 
    {
      if (THIS_PROCESS == MASTER_PROCESS) cout << "Demanded J Pi:" << J_Pi_string (BP , J) << " Determined J Pi:" << J_Pi_string (BP_one_configuration , J) << endl;

      error_message_print_abort ("BP and BP_one_configuration_determine must be equal in BP_J_dimension_calc_print_one_configuration");
    }

  class array<unsigned int> total_space_dimensions_all_M(J_index_max + 1);

  class array<unsigned int> total_space_dimensions_good_J(J_index_max + 1);

  for (unsigned int M_index = 0 ; M_index <= J_index_max ; M_index++)
    {
      const double M = (is_M_integer) ? (M_index) : (M_index + 0.5);

      total_space_dimensions_all_M(M_index) = total_space_dimension_M_calc_one_configuration (space , prot_data , neut_data , M);
    }

  for (unsigned int J_index = 0 ; J_index <= J_index_max ; J_index++)
    {
      const unsigned int M_index = J_index;

      total_space_dimensions_good_J(J_index) = (J_index < J_index_max)
	? (total_space_dimensions_all_M(M_index) - total_space_dimensions_all_M(M_index + 1))
	: (total_space_dimensions_all_M(M_index));
    }

  const unsigned int J_index = (abs (J - rint (J)) < precision) ? (make_int (J)) : (make_int (J - 0.5));
  
  const unsigned long int total_space_dimension_good_J = total_space_dimensions_good_J(J_index);

  return total_space_dimension_good_J;
}

unsigned int GSM_vector_dimensions::J_index_max_calc (
						      const enum space_type space , 
						      const class nucleons_data &prot_data , 
						      const class nucleons_data &neut_data)
{
  const double M_max = M_max_calc (space , prot_data , neut_data);

  const int two_M_max = make_int (2.0*M_max);

  const bool is_M_integer = (two_M_max%2 == 0);

  const unsigned int J_index_max = (is_M_integer) ? (make_uns_int (M_max)) : (make_uns_int (M_max - 0.5));

  return J_index_max;
}





// Calculation of the number of total angular momenta present in the current GSM model space
// -----------------------------------------------------------------------------------------
// One considers only the J-spaces of positive dimension with J >= M.

unsigned int GSM_vector_dimensions::J_number_calc (
						   const enum space_type space ,
						   const class nucleons_data &prot_data , 
						   const class nucleons_data &neut_data , 
						   const unsigned int BP ,
						   const unsigned int n_scat_max ,
						   const double M , 
						   const class array<unsigned long int> &total_space_dimensions_good_J)
{
  const double M_max = M_max_calc (space , prot_data , neut_data);

  const int two_M_max = make_int (2.0*M_max);

  const bool is_M_integer = (two_M_max%2 == 0);
  
  const unsigned int J_index_min = (is_M_integer) ? (make_uns_int (M))     : (make_uns_int (M     - 0.5));  
  const unsigned int J_index_max = (is_M_integer) ? (make_uns_int (M_max)) : (make_uns_int (M_max - 0.5));
  
  unsigned int J_number = 0;
  
  for (unsigned int J_index = J_index_min ; J_index <= J_index_max ; J_index++)
    {
      const unsigned long int total_space_dimension_J = total_space_dimensions_good_J(BP , n_scat_max , J_index);      
      
      if (total_space_dimension_J > 0) J_number++;
    }

  return J_number;
}





// Calculation of maximal number of total angular momenta present in the current GSM model space for all parities and M quantum numbers
// ------------------------------------------------------------------------------------------------------------------------------------

unsigned int GSM_vector_dimensions::J_number_max_calc (
						       const enum space_type space ,
						       const class nucleons_data &prot_data , 
						       const class nucleons_data &neut_data , 
						       const unsigned int n_scat_max ,
						       const class array<unsigned long int> &total_space_dimensions_good_J)
{
  
  const double M_max = M_max_calc (space , prot_data , neut_data);

  const int two_M_max = make_int (2.0*M_max);
    
  unsigned int J_number_max = 0;
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int iM = 0 ; iM <= two_M_max ; iM++)
      {
	const double M = iM - M_max;

	const int two_M = make_int (2.0*M);

	if (two_M >= 0)
	  {
	    const unsigned int J_number = J_number_calc (space , prot_data , neut_data , BP , n_scat_max , M , total_space_dimensions_good_J);
	    
	    J_number_max = max (J_number , J_number_max);
	  }
      }
  
  return J_number_max;
}















// Classes storing the GSM sums of dimensions of fixed proton, neutron, or proton-neutron configurations and fixed Mp,Mn, or Mp and Mn angular momentum projections
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------
// The GSM space dimension is a sum of sub GSM space dimensions in every configuration,
// i.e. the number of Slater determinants of each configuration of fixed parity and M quantum numbers, which are different in general.
// Hence, to determine the index of the Slater determinant of a GSM eigenvector, one first takes the sum of GSM dimensions of all previous configurations, 
// to which one adds the sub-index of the considered Slater determinant associated to its own configuration only (protons or neutrons only),
// or to its own configuration and proton parity and Mp quantum numbers (proton-neutron case).
//
// For example, in the proton-neutron case, if one has three configurations, of same parities, of 3, 5 and 16 Slater determinants each, 
// and one considers the 8th proton Slater determinant of the 3rd configuration, for which Mp = 0, 
// while the 1st proton Slater determinant of the 3rd configuration has Mp = -2, the 2nd to 5th proton Slater determinant of the 3rd configuration have Mp = -1, 
// and all other after them up to the current considered Slater determinants have Mp = 0,
// the sum of dimensions of the 3rd configuration is 3+5 = 8, to which one adds 1+4, for the Slater determinants of the same configuration but different Mp's.
// The total sum of dimensions is then 13 for the considered Slater determinant. 
//
// The sum of GSM dimensions for all previous configurations is stored here.
// A class was necessary for it, and not just an array, as one has to limit the truncation parameters to consider, otherwise one would store too many zeroes.
// For example, if one has a maximal number of particles of continuum equal to 3, with at most 2 protons or 2 neutrons on the continuum (configurations of the form 2p-1n or 1p-2n in the continuum), 
// it is useless to store the dimensions of all configurations with 3 protons or 3 neutrons in the continuum, which are typically much more numerous than those of the considered model space.
//
// As a consequence, sums of dimensions are stored as arrays of arrays so that the GSM sum of dimensions associated to a configuration:
// tables(n_scat_p)(iCp) for protons only
// tables(n_scat_n)(iCn) for neutrons only
// tables(BPp , n_scat_p , n_scat_n)(iCp , iCn , iMp) for protons-neutrons
// where n_scat_p/n_scat_n are the number of particles in the continuum of the proton/neutron parts,
// iCp, iCn are the configuration indices of the proton/neutron parts, where parity and number of particles in the continuum are fixed,
// BPp, iMp are the binary parity (see observables_basic_functions.cpp for definition) and total angular momentum projection index of the proton part (protons-neutrons only) .
// Bpn and iMn are fixed by Pi_p.Pi_n = Pi and Mp + Mn = M.
//
// In the proton-neutron case, dimensions are calculated differently if one has a number of valence protons Zval larger or smaller than the number of valence neutrons Nval.
// If Nval is larger, one first loops over neutron configurations, and then one loops over proton configurations to generate proton-neutron configurations.
// Indeed, if Nval >> Zval, the most expensive part of the Hamiltonian comes from the matrix elements <SDn'' SDp | H | SDn SDp>, where |SDn''> differ from |SDn> by two states.
// To calculate them, one loops over |SDn>, generates |SDn''> from |SDn> with |SDn''> = a+(alpha') a+(beta') a(beta) a(alpha)|SDn>, 
// and then one has <SDn'' SDp | H | SDn SDp> = phase . <alpha' beta' | Vnn | alpha beta>, with phase = +/-1.
// As <SDn'' SDp | H | SDn SDp> is independent of |SDp>, it is more efficient to generate phase . <alpha' beta' | Vnn | alpha beta> just once and then store it for all |SDp>'s.
// If one loops firstly over the neutron space and secondly over the proton space, one can see that one calculates phase . <alpha' beta' | Vnn | alpha beta> only once,
// whereas it would be recalculated for every encountered |SDn> if one looped over |SDp> instead.
// Moreover, the consideration of the proton-neutron part of the Hamiltonian does not matter here.
// Indeed, the most expensive proton-neutron part is <SDn' SDp' | H | SDn SDp> = phase . <alpha' beta' | Vpn | alpha beta>, with phase = +/-1 and |SDn'> = a+(beta') a(beta)|SDn> and |SDp'> = a+(alpha') a(alpha)|SDp>.
// It is the most expensive part in the Hamiltonian only if Nval ~ Zval, for which it is clear that looping over proton or neutron configuration first does not change much.
// The situation is symmetric for a larger Zval.
//
// The "_c" suffix in constructors/allocate routines means that the variable is used to be copied in member variables. 
// It is not mentioned afterwards.
//
// The memory used by the class can be calculated, and is the memory used the array of arrays tables. It is given in Mb.
//
// For the "one_configuration" case used in MSDHF, there are no truncations in the calculation as one considers only one configuration.
// Hence, only the proton-neutron case is not trivial, and the class is never used with only protons or neutrons.
// To calculate a given sum of dimensions, one considers only the number of proton Slater determinants of fixed Mp quantum number of the MSDHF configuration to optimize:
// table(iMp) is the number of proton Slater determinants of Mp' quantum number smaller than Mp.
// The calculation of GSM vector indices is then the same as before but starting from Slater determinants with Mp = -2.
// The zero in T(BP_one_configuration , 0 , iC_one_configuration) afterwards, with T an array,
// is the number of particles of the continuum, as the considered configuration has to belong to the pole space.

sum_GSM_vector_dimensions_class::sum_GSM_vector_dimensions_class ()
  : space (NO_SPACE) , 
    n_scat_max_p (0) , 
    n_scat_max_n (0)
{}

sum_GSM_vector_dimensions_class::sum_GSM_vector_dimensions_class (
								  const enum space_type space_c , 
								  const bool truncation_hw , 
								  const bool truncation_ph , 
								  const int n_holes_max_p ,  
								  const int n_scat_max_p_c ,
								  const int Ep_max_hw , 
								  const int n_holes_max_n , 
								  const int n_scat_max_n_c , 
								  const int En_max_hw , 
								  const int n_holes_max ,
								  const int n_scat_max ,
								  const int E_max_hw , 
								  const class nucleons_data &prot_data , 
								  const class nucleons_data &neut_data , 
								  const unsigned int BP , 
								  const int iM , 
								  const int iMp_min_M , 
								  const int iMp_max_M , 
								  const int iMn_min_M , 
								  const int iMn_max_M)
{
  allocate (space_c , truncation_hw , truncation_ph ,
	    n_holes_max_p , n_scat_max_p_c , Ep_max_hw ,
	    n_holes_max_n , n_scat_max_n_c , En_max_hw ,
	    n_holes_max   , n_scat_max     , E_max_hw  , prot_data , neut_data , BP , iM , iMp_min_M , iMp_max_M , iMn_min_M , iMn_max_M);
}

sum_GSM_vector_dimensions_class::sum_GSM_vector_dimensions_class (const class sum_GSM_vector_dimensions_class &X)
{
  allocate_fill (X);
}

void sum_GSM_vector_dimensions_class::allocate (
						const enum space_type space_c , 
						const bool truncation_hw , 
						const bool truncation_ph , 
						const int n_holes_max_p ,  
						const int n_scat_max_p_c , 
						const int Ep_max_hw , 
						const int n_holes_max_n , 
						const int n_scat_max_n_c , 
						const int En_max_hw , 
						const int n_holes_max ,
						const int n_scat_max ,
						const int E_max_hw , 
						const class nucleons_data &prot_data , 
						const class nucleons_data &neut_data , 
						const unsigned int BP , 
						const int iM , 
						const int iMp_min_M , 
						const int iMp_max_M , 
						const int iMn_min_M , 
						const int iMn_max_M)

{
  space = space_c;

  n_scat_max_p = n_scat_max_p_c;
  n_scat_max_n = n_scat_max_n_c;
  
  const int n_scat_max_p_plus_one = n_scat_max_p + 1;
  const int n_scat_max_n_plus_one = n_scat_max_n + 1;

  switch (space)
    {
    case PROTONS_ONLY: 
      {
	tables_pp_nn.allocate (n_scat_max_p_plus_one);

	const class array<unsigned int> &dimensions_configuration_set_p = prot_data.get_dimensions_configuration_set ();

	for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	  {
	    const unsigned int dimension_configuration_n_scat_p = dimensions_configuration_set_p(BP , n_scat_p);

	    tables_pp_nn(n_scat_p).allocate (dimension_configuration_n_scat_p);
	  }

	calc_pp_nn (prot_data , truncation_hw , truncation_ph , n_holes_max_p , n_scat_max_p , Ep_max_hw , BP , iM);
      } break;

    case NEUTRONS_ONLY:
      {
	tables_pp_nn.allocate (n_scat_max_n_plus_one);

	const class array<unsigned int> &dimensions_configuration_set_n = neut_data.get_dimensions_configuration_set ();

	for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	  {
	    const unsigned int dimension_configuration_n_scat_n = dimensions_configuration_set_n(BP , n_scat_n);

	    tables_pp_nn(n_scat_n).allocate (dimension_configuration_n_scat_n);
	  }
	  
	calc_pp_nn (neut_data , truncation_hw , truncation_ph , n_holes_max_n , n_scat_max_n , En_max_hw , BP , iM);
      } break;

    case PROTONS_NEUTRONS:
      { 
	const int iMp_max_M_plus_one = iMp_max_M + 1;

	const class array<unsigned int> &dimensions_configuration_set_p = prot_data.get_dimensions_configuration_set ();
	const class array<unsigned int> &dimensions_configuration_set_n = neut_data.get_dimensions_configuration_set ();

	tables_pn_0.allocate (n_scat_max_p_plus_one , n_scat_max_n_plus_one);
	tables_pn_1.allocate (n_scat_max_p_plus_one , n_scat_max_n_plus_one);

	for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
	  {
	    class array<class array<unsigned long int> > &tables_pn = (BPp == 0) ? (tables_pn_0) : (tables_pn_1);
	      
	    const unsigned int BPn = binary_parity_product (BP , BPp);

	    for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	      {
		const unsigned int dimension_configuration_n_scat_p = dimensions_configuration_set_p(BPp , n_scat_p);

		for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
		  {
		    const unsigned int dimension_configuration_n_scat_n = dimensions_configuration_set_n(BPn , n_scat_n);
		    
		    if (!truncation_ph || (n_scat_p + n_scat_n <= n_scat_max))
		      tables_pn(n_scat_p , n_scat_n).allocate (dimension_configuration_n_scat_p , dimension_configuration_n_scat_n , iMp_max_M_plus_one);
		  }
	      }
	  }

	const int Zval = prot_data.get_N_valence_nucleons ();
	const int Nval = neut_data.get_N_valence_nucleons ();
  
	if (Nval >= Zval)
	  calc_pn_N_valence_larger (truncation_hw , truncation_ph , n_holes_max , n_scat_max , E_max_hw , prot_data , neut_data , BP , iM , iMp_min_M , iMp_max_M);
	else
	  calc_pn_Z_valence_larger (truncation_hw , truncation_ph , n_holes_max , n_scat_max , E_max_hw , prot_data , neut_data , BP , iM , iMn_min_M , iMn_max_M);
	
      } break;

    default: abort_all ();
    }
}

void sum_GSM_vector_dimensions_class::allocate_fill (const class sum_GSM_vector_dimensions_class &X)
{
  space = X.space;

  n_scat_max_p = X.n_scat_max_p;
  n_scat_max_n = X.n_scat_max_n;

  const int n_scat_max_p_plus_one = n_scat_max_p + 1;
  const int n_scat_max_n_plus_one = n_scat_max_n + 1;

  switch (space)
    {
    case PROTONS_ONLY: 
      {
	tables_pp_nn.allocate (n_scat_max_p_plus_one);

	for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++) tables_pp_nn(n_scat_p).allocate_fill (X.tables_pp_nn(n_scat_p));

      } break;

    case NEUTRONS_ONLY:
      {
	tables_pp_nn.allocate (n_scat_max_n_plus_one);

	for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++) tables_pp_nn(n_scat_n).allocate_fill (X.tables_pp_nn(n_scat_n));

      } break;

    case PROTONS_NEUTRONS:
      { 
	tables_pn_0.allocate (n_scat_max_p_plus_one , n_scat_max_n_plus_one);
	tables_pn_1.allocate (n_scat_max_p_plus_one , n_scat_max_n_plus_one);

	for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	  for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	    {
	      tables_pn_0(n_scat_p , n_scat_n).allocate_fill (X.tables_pn_0(n_scat_p , n_scat_n));
	      tables_pn_1(n_scat_p , n_scat_n).allocate_fill (X.tables_pn_1(n_scat_p , n_scat_n));
	    }

      } break;

    default: abort_all ();
    }
}

void sum_GSM_vector_dimensions_class::deallocate ()
{
  tables_pp_nn.deallocate ();
  tables_pn_0.deallocate ();
  tables_pn_1.deallocate ();
}

void sum_GSM_vector_dimensions_class::calc_pp_nn (
						  const class nucleons_data &particles_data , 
						  const bool truncation_hw , 
						  const bool truncation_ph , 
						  const int n_holes_max , 
						  const int n_scat_max , 
						  const int E_max_hw , 
						  const unsigned int BP , 
						  const int iM)
{
  const class array<unsigned int> &dimensions_configuration_set = particles_data.get_dimensions_configuration_set ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set = particles_data.get_dimensions_SD_set ();

  const class array_BP_Nscat_iC<int> &n_holes_table = particles_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &E_hw_table = particles_data.get_E_hw_table ();

  unsigned long int sum_GSM_vector_dimensions_bef = 0;

  unsigned int dimension_bef = 0;

  class sum_GSM_vector_dimensions_class &sum_GSM_vector_dimensions_GSM = *this;

  for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
    {
      const unsigned int dimension_C = dimensions_configuration_set(BP , n_scat);
      	  
      for (unsigned int iC = 0 ; iC < dimension_C ; iC++)
	{
	  const int n_holes = n_holes_table(BP , n_scat , iC);
	  
	  const int E_hw = E_hw_table(BP , n_scat , iC);
      
	  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	  const unsigned int dimension = dimensions_SD_set(BP , n_scat , iC , iM);

	  unsigned long int &sum_GSM_vector_dimensions_n_scat_iC = sum_GSM_vector_dimensions_GSM(n_scat , iC);

	  sum_GSM_vector_dimensions_n_scat_iC = sum_GSM_vector_dimensions_bef + dimension_bef;
	      
	  dimension_bef = dimension;

	  sum_GSM_vector_dimensions_bef = sum_GSM_vector_dimensions_n_scat_iC;
	}
    }
}

void sum_GSM_vector_dimensions_class::calc_pn_N_valence_larger (
								const bool truncation_hw , 
								const bool truncation_ph , 
								const int n_holes_max , 
								const int n_scat_max , 
								const int E_max_hw , 
								const class nucleons_data &prot_data , 
								const class nucleons_data &neut_data , 
								const unsigned int BP , 
								const int iM , 
								const int iMp_min_M , 
								const int iMp_max_M)
{
  const class array<unsigned int> &dimensions_configuration_set_p = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_set_n = neut_data.get_dimensions_configuration_set ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const int n_holes_max_n = neut_data.get_n_holes_max ();
  
  const int En_max_hw = neut_data.get_E_max_hw ();

  unsigned long int sum_GSM_vector_dimensions_bef = 0;
  
  unsigned int dimension_bef = 0;

  class sum_GSM_vector_dimensions_class &sum_GSM_vector_dimensions_GSM = *this;
  
  for (unsigned int BPn = 0 ; BPn <= 1 ; BPn++)
    {
      const unsigned int BPp = binary_parity_product (BPn , BP);

      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	{
	  const unsigned int dimension_Cn = dimensions_configuration_set_n(BPn , n_scat_n);
	  
	  for (unsigned int iCn = 0 ; iCn < dimension_Cn ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);

	      const int En_hw = En_hw_table(BPn , n_scat_n , iCn);
	      
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

	      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
		{
		  const unsigned int dimension_Cp = dimensions_configuration_set_p(BPp , n_scat_p);	  		  		  
	  	  
		  for (unsigned int iCp = 0 ; iCp < dimension_Cp ; iCp++)
		    {
		      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);
		      
		      const int Ep_hw = Ep_hw_table(BPp , n_scat_p , iCp);
	      
		      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw))
			{
			  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
			    {
			      const int iMn = iM - iMp;
			      
			      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);
			      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);
			      
			      const unsigned int dimension = dimension_SDp*dimension_SDn;

			      unsigned long int &sum_GSM_vector_dimensions_BP_n_scat_iC_iM_pn = sum_GSM_vector_dimensions_GSM(BPp , n_scat_p , n_scat_n , iCp , iCn , iMp);

			      sum_GSM_vector_dimensions_BP_n_scat_iC_iM_pn = sum_GSM_vector_dimensions_bef + dimension_bef;

			      dimension_bef = dimension;

			      sum_GSM_vector_dimensions_bef = sum_GSM_vector_dimensions_BP_n_scat_iC_iM_pn;
			    }}}}}}}
  
}

void sum_GSM_vector_dimensions_class::calc_pn_Z_valence_larger (
								const bool truncation_hw , 
								const bool truncation_ph ,
								const int n_holes_max ,  
								const int n_scat_max , 
								const int E_max_hw , 
								const class nucleons_data &prot_data , 
								const class nucleons_data &neut_data , 
								const unsigned int BP , 
								const int iM , 
								const int iMn_min_M , 
								const int iMn_max_M)
{
  const class array<unsigned int> &dimensions_configuration_set_p = prot_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_set_n = neut_data.get_dimensions_configuration_set ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  const class array_BP_Nscat_iC<int> &n_holes_p_table = prot_data.get_n_holes_table ();
  const class array_BP_Nscat_iC<int> &n_holes_n_table = neut_data.get_n_holes_table ();
  
  const class array_BP_Nscat_iC<int> &Ep_hw_table = prot_data.get_E_hw_table ();
  const class array_BP_Nscat_iC<int> &En_hw_table = neut_data.get_E_hw_table ();
  
  const int n_holes_max_p = prot_data.get_n_holes_max ();
  
  const int Ep_max_hw = prot_data.get_E_max_hw ();

  unsigned int sum_GSM_vector_dimensions_bef = 0;

  unsigned int dimension_bef = 0;

  class sum_GSM_vector_dimensions_class &sum_GSM_vector_dimensions_GSM = *this;

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    {
      const unsigned int BPn = binary_parity_product (BPp , BP);

      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int dimension_Cp = dimensions_configuration_set_p(BPp , n_scat_p);	  		  		  
	  	  
	  for (unsigned int iCp = 0 ; iCp < dimension_Cp ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , n_scat_p , iCp);
	      
	      const int Ep_hw = Ep_hw_table(BPp , n_scat_p , iCp);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
		  
	      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
		{
		  const unsigned int dimension_Cn = dimensions_configuration_set_n(BPn , n_scat_n);
		  		  
		  for (unsigned int iCn = 0 ; iCn < dimension_Cn ; iCn++)
		    {
		      const int n_holes_n = n_holes_n_table(BPn , n_scat_n , iCn);
	      
		      const int En_hw = En_hw_table(BPn , n_scat_n , iCn);
	      
		      if (is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw))
			{
			  for (int iMn = iMn_min_M ; iMn <= iMn_max_M ; iMn++)
			    {
			      const int iMp = iM - iMn;
		  
			      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , n_scat_p , iCp , iMp);
			      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , n_scat_n , iCn , iMn);
			      
			      const unsigned int dimension = dimension_SDp*dimension_SDn;

			      unsigned long int &sum_GSM_vector_dimensions_BP_n_scat_iC_iM_pn = sum_GSM_vector_dimensions_GSM(BPp , n_scat_p , n_scat_n , iCp , iCn , iMp);

			      sum_GSM_vector_dimensions_BP_n_scat_iC_iM_pn = sum_GSM_vector_dimensions_bef + dimension_bef;

			      dimension_bef = dimension;

			      sum_GSM_vector_dimensions_bef = sum_GSM_vector_dimensions_BP_n_scat_iC_iM_pn;
			    }}}}}}}
}

double used_memory_calc (const class sum_GSM_vector_dimensions_class &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.tables_pp_nn) + used_memory_calc (T.tables_pn_0) + used_memory_calc (T.tables_pn_1) - (sizeof (T.tables_pp_nn) + sizeof (T.tables_pn_0) + sizeof (T.tables_pn_1))/1000000.0);
}











sum_GSM_vector_dimensions_one_configuration_class::sum_GSM_vector_dimensions_one_configuration_class () {}

sum_GSM_vector_dimensions_one_configuration_class::sum_GSM_vector_dimensions_one_configuration_class (
												      const enum space_type space , 
												      const class nucleons_data &prot_data , 
												      const class nucleons_data &neut_data , 
												      const int iM ,
												      const int iMp_min_M ,
												      const int iMp_max_M)
{
  allocate (space , prot_data , neut_data , iM , iMp_min_M , iMp_max_M);
}

sum_GSM_vector_dimensions_one_configuration_class::sum_GSM_vector_dimensions_one_configuration_class (const class sum_GSM_vector_dimensions_one_configuration_class &X)
{
  allocate_fill (X);
}

void sum_GSM_vector_dimensions_one_configuration_class::allocate (
								  const enum space_type space , 
								  const class nucleons_data &prot_data , 
								  const class nucleons_data &neut_data , 
								  const int iM ,
								  const int iMp_min_M ,
								  const int iMp_max_M)
{ 
  if (space != PROTONS_NEUTRONS) return;

  const int iMp_max_M_plus_one = iMp_max_M + 1;

  table.allocate (iMp_max_M_plus_one); 

  calc_pn (prot_data , neut_data , iM , iMp_min_M , iMp_max_M);
}

void sum_GSM_vector_dimensions_one_configuration_class::allocate_fill (const class sum_GSM_vector_dimensions_one_configuration_class &X)
{
  table.allocate_fill (X.table);
}

void sum_GSM_vector_dimensions_one_configuration_class::deallocate ()
{
  table.deallocate ();
}

void sum_GSM_vector_dimensions_one_configuration_class::calc_pn (
								 const class nucleons_data &prot_data , 
								 const class nucleons_data &neut_data , 
								 const int iM , 
								 const int iMp_min_M , 
								 const int iMp_max_M)
{
  const unsigned int BPp_one_configuration = prot_data.get_BP_one_configuration ();
  const unsigned int BPn_one_configuration = neut_data.get_BP_one_configuration ();
  
  const unsigned int iCp_one_configuration = prot_data.get_iC_one_configuration ();
  const unsigned int iCn_one_configuration = neut_data.get_iC_one_configuration ();

  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();

  unsigned int sum_GSM_vector_dimensions_bef = 0;
  
  unsigned int dimension_bef = 0;

  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
    {
      const int iMn = iM - iMp;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp_one_configuration , 0 , iCp_one_configuration , iMp);
      const unsigned int dimension_SDn = dimensions_SDn_set(BPn_one_configuration , 0 , iCn_one_configuration , iMn);
    
      const unsigned int dimension = dimension_SDp*dimension_SDn;

      unsigned int &sum_GSM_vector_dimensions_pn = table(iMp);

      sum_GSM_vector_dimensions_pn = sum_GSM_vector_dimensions_bef + dimension_bef;

      dimension_bef = dimension;

      sum_GSM_vector_dimensions_bef = sum_GSM_vector_dimensions_pn;
    }
}

double used_memory_calc (const class sum_GSM_vector_dimensions_one_configuration_class &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.table) - sizeof (T.table)/1000000.0);
}


