#include "../GSM_include/GSM_include_def_common.h"

using namespace inputs_misc;
using namespace string_routines;


// TYPE is double or complex
// -------------------------






// Calculation of one one-body matrix element of the nuclear part of a core potential of a HO core state
// -----------------------------------------------------------------------------------------------------
// One calculates the one-body matrix element <wf_core | U_nuclear | wf_core>. It is used to determine the average energy of the HO core state for a given core potential.
// As the HO core state is localized, it can be done by direct integration on the real axis.
// One considers the integral on [0:R] only, with R the rotation point, as core states have a small principal quantum number and nuclear potentials are finite-ranged so that the integrand is negligible in R.
// The nuclear potential can be WS (with Coulomb uniformly charged sphere potential), WS_ANALYTIC (with Coulomb Gaussian charged sphere potential) or KKNN.
// WS potentials can be real or complex. Core states are always HO states with complex WS potentials.

complex<double> HF_wave_function::OBME_nuclear_potential_HO_core_state_calc (
									     const class HF_nucleons_data &HF_data , 
									     const potential_type nuclear_potential , 
									     const class spherical_state &shell_HO_core)
{
  const unsigned int N_bef_R_GL = shell_HO_core.get_N_bef_R_GL ();
  
  const int l = shell_HO_core.get_l ();

  const double j = shell_HO_core.get_j ();

  const class array<double> &r_bef_R_tab_GL = shell_HO_core.get_r_bef_R_tab_GL ();
  const class array<double> &w_bef_R_tab_GL = shell_HO_core.get_w_bef_R_tab_GL ();

  const class array<complex<double> > &wf_HO_core_bef_R_tab_GL = shell_HO_core.get_wf_bef_R_tab_GL ();

  const class array<double> &d_tab        = HF_data.get_d_tab ();
  const class array<double> &R0_tab       = HF_data.get_R0_tab ();
  const class array<double> &Vo_tab       = HF_data.get_Vo_tab ();
  const class array<double> &Vso_tab      = HF_data.get_Vso_tab ();
  const class array<double> &Im_Vo_tab    = HF_data.get_Im_Vo_tab ();
  const class array<double> &Im_Vso_tab   = HF_data.get_Im_Vso_tab ();
  const class array<double> &Im_Vsurf_tab = HF_data.get_Im_Vsurf_tab ();

  const class array<double> &V0_KKNN_tab     = HF_data.get_V0_KKNN_tab ();  
  const class array<double> &rho_KKNN_tab    = HF_data.get_rho_KKNN_tab ();
  const class array<double> &Vls_KKNN_tab    = HF_data.get_Vls_KKNN_tab ();
  const class array<double> &rho_ls_KKNN_tab = HF_data.get_rho_ls_KKNN_tab ();
  
  const double V0_KKNN[5] = {
    V0_KKNN_tab(0 , 0) ,
    V0_KKNN_tab(0 , 1) ,
    V0_KKNN_tab(0 , 2) ,
    V0_KKNN_tab(0 , 3) ,
    V0_KKNN_tab(0 , 4)};
  
  const double rho_KKNN[5] = {
    rho_KKNN_tab(0 , 0) ,
    rho_KKNN_tab(0 , 1) ,
    rho_KKNN_tab(0 , 2) ,
    rho_KKNN_tab(0 , 3) ,
    rho_KKNN_tab(0 , 4)};

  const double Vls_KKNN[3] = {
    Vls_KKNN_tab(0 , 0) ,
    Vls_KKNN_tab(0 , 1) ,
    Vls_KKNN_tab(0 , 2)};
  
  const double rho_ls_KKNN[3] = {
    rho_ls_KKNN_tab(0 , 0) ,
    rho_ls_KKNN_tab(0 , 1) ,
    rho_ls_KKNN_tab(0 , 2)};

  complex<double> OBME_potential = 0.0;

  switch (nuclear_potential)
    {
    case WS:
      {
	const double d   = d_tab  (0 , l);
	const double R0  = R0_tab (0 , l);
	const double Vo  = Vo_tab (0 , l);
	const double Vso = Vso_tab(0 , l);
	
	const class WS_class WS_potential(false , d , R0 , Vo , Vso , NEUTRON , NADA , NADA , l , j);

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	  {
	    const double r = r_bef_R_tab_GL(i);
	    const double w = w_bef_R_tab_GL(i);

	    const double WS_potential_r = WS_potential(r);

	    const double wf_HO_core_r = real (wf_HO_core_bef_R_tab_GL(i));

	    OBME_potential += wf_HO_core_r*WS_potential_r*wf_HO_core_r*w;
	  }
      } break;

    case WS_ANALYTIC:
      {
	const double d   = d_tab  (0 , l);
	const double R0  = R0_tab (0 , l);
	const double Vo  = Vo_tab (0 , l);
	const double Vso = Vso_tab(0 , l);

	const class WS_analytic_class WS_potential(false , d , R0 , Vo , Vso , NEUTRON , NADA , NADA , l , j);

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	  {
	    const double r = r_bef_R_tab_GL(i);
	    const double w = w_bef_R_tab_GL(i);

	    const double WS_potential_r = WS_potential(r);

	    const double wf_HO_core_r = real (wf_HO_core_bef_R_tab_GL(i));

	    OBME_potential += wf_HO_core_r*WS_potential_r*wf_HO_core_r*w;
	  }
      } break;

    case KKNN:
      {
	const class KKNN_class KKNN_potential(false , V0_KKNN , rho_KKNN , Vls_KKNN , rho_ls_KKNN , NEUTRON , NADA , NADA , l , j);

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	  {
	    const double r = r_bef_R_tab_GL(i);
	    const double w = w_bef_R_tab_GL(i);

	    const double KKNN_potential_r = KKNN_potential(r);

	    const double wf_HO_core_r = real (wf_HO_core_bef_R_tab_GL(i));

	    OBME_potential += wf_HO_core_r*KKNN_potential_r*wf_HO_core_r*w;
	  }

      } break;

    case COMPLEX_WS:
      {
	const double d        = d_tab       (0 , l);
	const double R0       = R0_tab      (0 , l);
	const double Vo       = Vo_tab      (0 , l);
	const double Vso      = Vso_tab     (0 , l);
	const double Im_Vo    = Im_Vo_tab   (0 , l);
	const double Im_Vso   = Im_Vso_tab  (0 , l);
	const double Im_Vsurf = Im_Vsurf_tab(0 , l);
	
	const complex<double> Vo_complex(Vo , Im_Vo);

	const complex<double> Vso_complex(Vso , Im_Vso);

	const class WS_complex_class WS_complex_potential(false , d , R0 , Vo_complex , Vso_complex , Im_Vsurf , NEUTRON , NADA , NADA , l , j);

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	  {
	    const double r = r_bef_R_tab_GL(i);
	    const double w = w_bef_R_tab_GL(i);

	    const complex<double> WS_complex_potential_r = WS_complex_potential(r);

	    const double wf_HO_core_r = real (wf_HO_core_bef_R_tab_GL(i));

	    OBME_potential += wf_HO_core_r*WS_complex_potential_r*wf_HO_core_r*w;
	  }
      } break;

    case COMPLEX_WS_ANALYTIC:
      {
	const double d        = d_tab       (0 , l);
	const double R0       = R0_tab      (0 , l);
	const double Vo       = Vo_tab      (0 , l);
	const double Vso      = Vso_tab     (0 , l);
	const double Im_Vo    = Im_Vo_tab   (0 , l);
	const double Im_Vso   = Im_Vso_tab  (0 , l);
	const double Im_Vsurf = Im_Vsurf_tab(0 , l);
	
	const complex<double> Vo_complex(Vo , Im_Vo);

	const complex<double> Vso_complex(Vso , Im_Vso);

	const class WS_analytic_complex_class WS_complex_potential(false , d , R0 , Vo_complex , Vso_complex , Im_Vsurf , NEUTRON , NADA , NADA , l , j);

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	  {
	    const double r = r_bef_R_tab_GL(i);
	    const double w = w_bef_R_tab_GL(i);

	    const complex<double> WS_complex_potential_r = WS_complex_potential(r);

	    const double wf_HO_core_r = real (wf_HO_core_bef_R_tab_GL(i));

	    OBME_potential += wf_HO_core_r*WS_complex_potential_r*wf_HO_core_r*w;
	  }
      } break;
      
    default: abort_all ();
    }
  
  return OBME_potential;
}













// Calculation of the Coulomb potential matrix element of the core for a core HO state
// -----------------------------------------------------------------------------------
// The matrix element of one-body Coulomb potential Vc generated by Gaussian charged sphere defined with charge Z_core is calculated by direct integration.

double HF_wave_function::OBME_H_Coulomb_potential_HO_core_state_calc (
								      const int Z_core , 
								      const class HF_nucleons_data &HF_data , 
								      const class spherical_state &shell_HO_core)
{
  const enum particle_type particle = HF_data.get_particle ();

  if (particle == NEUTRON) return 0.0;

  const unsigned int N_bef_R_GL = shell_HO_core.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = shell_HO_core.get_N_aft_R_GL ();

  const double R_charge = HF_data.get_R_charge ();

  const class array<double> &r_bef_R_tab_GL = shell_HO_core.get_r_bef_R_tab_GL ();
  const class array<double> &w_bef_R_tab_GL = shell_HO_core.get_w_bef_R_tab_GL ();
  
  const class array<double> &r_aft_R_tab_GL = shell_HO_core.get_r_aft_R_tab_GL_real ();
  const class array<double> &w_aft_R_tab_GL = shell_HO_core.get_w_aft_R_tab_GL_real ();

  const class array<complex<double> > &wf_HO_core_bef_R_tab_GL = shell_HO_core.get_wf_bef_R_tab_GL ();
  const class array<complex<double> > &wf_HO_core_aft_R_tab_GL = shell_HO_core.get_wf_aft_R_tab_GL_real ();

  const class Coulomb_potential_class Coulomb_potential(false , particle , Z_core , R_charge);

  double OBME_Coulomb_potential = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
    {
      const double r = r_bef_R_tab_GL(i);
      const double w = w_bef_R_tab_GL(i);

      const double Vc_r = Coulomb_potential.analytic_potential_calc (r);

      const double wf_HO_core_r = real (wf_HO_core_bef_R_tab_GL(i));

      OBME_Coulomb_potential += wf_HO_core_r*Vc_r*wf_HO_core_r*w;
    }

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
    {
      const double r = r_aft_R_tab_GL(i);
      const double w = w_aft_R_tab_GL(i);

      const double Vc_r = Coulomb_potential.point_potential_calc (r);

      const double wf_HO_core_r = real (wf_HO_core_aft_R_tab_GL(i));

      OBME_Coulomb_potential += wf_HO_core_r*Vc_r*wf_HO_core_r*w;
    }

  return OBME_Coulomb_potential;
}











// Calculation of the average energy of a HO core state of the core potential Hamiltonian
// --------------------------------------------------------------------------------------
// The average energy of a HO core state of the core potential Hamiltonian is <wf_core | p^2/2m + U_nuclear + U_Coulomb | wf_core>.
// The kinetic part is analytical as wf_core is a HO state and the nuclear and Coulomb parts are calculated numerically.

complex<double> HF_wave_function::E_HO_core_state_calc (
							const int Z_core , 
							const class HF_nucleons_data &HF_data , 
							const class spherical_state &shell_HO_core)
{
  const int n = shell_HO_core.get_n ();
  const int l = shell_HO_core.get_l ();

  const double j = shell_HO_core.get_j ();
  
  const class lj_table<double> &b_lab_partial_waves = HF_data.get_b_lab_partial_waves ();
    
  const double b_lab = b_lab_partial_waves(l , j);

  const enum potential_type H_potential = HF_data.get_H_potential ();
  
  const double nucleon_mass_for_calc = HF_data.get_nucleon_mass_for_calc ();

  const double nucleus_mass_basis = HF_data.get_nucleus_mass_basis ();

  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , nucleus_mass_basis , nucleon_mass_for_calc , b_lab);

  const double OBME_kinetic = HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n , n , hbar_omega);

  const complex<double> OBME_nuclear_potential = OBME_nuclear_potential_HO_core_state_calc (HF_data , H_potential , shell_HO_core);

  const double OBME_Coulomb_potential = OBME_H_Coulomb_potential_HO_core_state_calc (Z_core , HF_data , shell_HO_core); 

  const complex<double> OBME = OBME_kinetic + OBME_nuclear_potential + OBME_Coulomb_potential;

  return OBME;
}












// Reallocation and calculation of the radial wave functions of the core states
// ----------------------------------------------------------------------------
// The radial wave functions of the core states are calculated here, as well their average energy with respect to the core Hamiltonian (see above).
// They are calculated analytically if they are HO states or numerically if they are WS or KKNN eigenstates.
// Information about these states can be printed on screen.

void HF_wave_function::OCM_core_states_realloc_calc (
						     const bool is_there_cout , 
						     const bool is_it_res , 
						     const bool is_it_OCM_HO_core , 
						     const int Z_core , 
						     const class interaction_class &inter_data_basis , 
						     class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj = (is_it_res) ? (HF_data.get_N_nlj_res ()) : (HF_data.get_N_nlj ());
  
  if (N_nlj == 0) return;

  const enum potential_type H_potential = HF_data.get_H_potential ();

  const enum particle_type particle = HF_data.get_particle ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const int A_basis = HF_data.get_A_basis ();

  const unsigned int N_bef_R_GL = HF_data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = HF_data.get_N_aft_R_GL ();

  const unsigned int N_bef_R_uniform = HF_data.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = HF_data.get_N_aft_R_uniform ();

  const double R = HF_data.get_R ();

  const double R_real_max = HF_data.get_R_real_max ();

  const double R_charge = HF_data.get_R_charge ();

  const double nucleon_mass_for_calc = HF_data.get_nucleon_mass_for_calc ();

  const double nucleus_mass_basis = HF_data.get_nucleus_mass_basis ();

  const class array<double> &d_tab        = HF_data.get_d_tab ();
  const class array<double> &R0_tab       = HF_data.get_R0_tab ();
  const class array<double> &Vo_tab       = HF_data.get_Vo_tab ();
  const class array<double> &Vso_tab      = HF_data.get_Vso_tab ();
  const class array<double> &Im_Vo_tab    = HF_data.get_Im_Vo_tab ();
  const class array<double> &Im_Vso_tab   = HF_data.get_Im_Vso_tab ();
  const class array<double> &Im_Vsurf_tab = HF_data.get_Im_Vsurf_tab ();

  const double R0_inter = inter_data_basis.get_R0 ();

  const class array<double> &V0_KKNN_tab     = HF_data.get_V0_KKNN_tab     ();  
  const class array<double> &rho_KKNN_tab    = HF_data.get_rho_KKNN_tab    ();
  const class array<double> &Vls_KKNN_tab    = HF_data.get_Vls_KKNN_tab    ();
  const class array<double> &rho_ls_KKNN_tab = HF_data.get_rho_ls_KKNN_tab ();
  
  const double V0_KKNN[5] = {
    V0_KKNN_tab(0 , 0) ,
    V0_KKNN_tab(0 , 1) ,
    V0_KKNN_tab(0 , 2) ,
    V0_KKNN_tab(0 , 3) ,
    V0_KKNN_tab(0 , 4)};
  
  const double rho_KKNN[5] = {
    rho_KKNN_tab(0 , 0) ,
    rho_KKNN_tab(0 , 1) ,
    rho_KKNN_tab(0 , 2) ,
    rho_KKNN_tab(0 , 3) ,
    rho_KKNN_tab(0 , 4)};

  const double Vls_KKNN[3] = {
    Vls_KKNN_tab(0 , 0) ,
    Vls_KKNN_tab(0 , 1) ,
    Vls_KKNN_tab(0 , 2)};
  
  const double rho_ls_KKNN[3] = {
    rho_ls_KKNN_tab(0 , 0) ,
    rho_ls_KKNN_tab(0 , 1) ,
    rho_ls_KKNN_tab(0 , 2)};

  const class lj_table<double> &b_lab_partial_waves = HF_data.get_b_lab_partial_waves ();

  class array<class nlj_struct> &shells_qn = (is_it_res) ? (HF_data.get_shells_quantum_numbers_res ()) : (HF_data.get_shells_quantum_numbers ());
  
  class array<class spherical_state> &shells = (is_it_res) ? (HF_data.get_shells_res ()) : (HF_data.get_shells ());

  bool is_there_core_state = false;

  for (unsigned int s = 0 ; (s < N_nlj) && (!is_there_core_state) ; s++)
    {
      const class nlj_struct &shell_qn = shells_qn(s);
      
      const bool core_state = shell_qn.get_core_state ();

      if (core_state) is_there_core_state = true;
    }

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout && is_there_core_state &&  is_it_res) cout << particle << " core states (resonant part)" << endl;
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout && is_there_core_state && !is_it_res) cout << particle << " core states" << endl;

  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_qn(s);
      
      const bool core_state = shell_qn.get_core_state ();

      if (core_state)
	{
	  const int n = shell_qn.get_n ();
	  const int l = shell_qn.get_l ();

	  const double j = shell_qn.get_j ();

	  const double d        = d_tab       (0 , l);
	  const double R0       = R0_tab      (0 , l);
	  const double Vo       = Vo_tab      (0 , l);
	  const double Vso      = Vso_tab     (0 , l);
	  const double Im_Vo    = Im_Vo_tab   (0 , l);
	  const double Im_Vso   = Im_Vso_tab  (0 , l);
	  const double Im_Vsurf = Im_Vsurf_tab(0 , l);
	  
	  const complex<double> Vo_complex(Vo , Im_Vo);

	  const complex<double> Vso_complex(Vso , Im_Vso);

	  const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);
	  
	  class spherical_state &shell_OCM_core = shells(s);

	  shell_OCM_core.deallocate ();

	  shell_OCM_core.allocate (false , true , H_potential , A_basis , Z_core , nucleus_mass_basis , NADA , N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , 0 , 0 ,
				   R , NADA , R0_matching_point , R_real_max , 0.0 , 0.0 , true , particle , n , NADA , l , j , true , 0.0 , nucleon_mass_for_calc , 1.0 , 1.0);

	  class potentials_effective_mass T;

	  T.initialize_constants (
				  shell_OCM_core.get_potential () ,
				  shell_OCM_core.get_kinetic_factor () ,
				  shell_OCM_core.get_jr () ,
				  shell_OCM_core.get_l () ,
				  shell_OCM_core.get_ZY_charge () ,
				  shell_OCM_core.get_j () ,
				  shell_OCM_core.get_k () ,
				  shell_OCM_core.get_eta () ,
				  NADA);

	  class WS_class &WS_potential = T.get_WS_potential ();
	  
	  class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();

	  class WS_complex_class &WS_complex_potential = T.get_WS_complex_potential ();
	  
	  class WS_analytic_complex_class &WS_complex_analytic_potential = T.get_WS_complex_analytic_potential ();

	  class KKNN_class &KKNN_potential = T.get_KKNN_potential ();

	  WS_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_core , R_charge , l , j);

	  WS_analytic_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_core , R_charge , l , j);

	  WS_complex_potential.initialize (false , d , R0 , Vo_complex , Vso_complex , Im_Vsurf , particle , Z_core , R_charge , l , j);

	  WS_complex_analytic_potential.initialize (false , d , R0 , Vo_complex , Vso_complex , Im_Vsurf , particle , Z_core , R_charge , l , j);

	  KKNN_potential.initialize (false , V0_KKNN , rho_KKNN , Vls_KKNN , rho_ls_KKNN , particle , Z_core , R_charge , l , j);

	  if (is_it_OCM_HO_core)
	    {
	      const double b_lab = b_lab_partial_waves(l , j);
	      
	      shell_OCM_core.HO_wave_function (b_lab);
	      
	      const complex<double> E = E_HO_core_state_calc (Z_core , HF_data , shell_OCM_core);

	      if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
		{
		  if (abs (imag (E)) < precision) 
		    cout << shell_OCM_core << " " << particle << " E:" << real (E) << " MeV " << endl;
		  else
		    cout << shell_OCM_core << " " << particle << " E:" << real (E) << " MeV  G:" << -2000.0*imag (E) << " keV " << endl;
		}
	    }
	  else
	    {
	      shell_OCM_core.k_search (T , true , is_there_cout);
	      
	      shell_OCM_core.wave_calculation (is_there_cout , T , false);
	    }
	}
    }

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout && is_there_core_state) cout << endl;
}







// Orthogonalization of a given shell with respect to one-body core shells
// -----------------------------------------------------------------------
// One orthogonalizes a valence shell with respect to one-body core shells with the modified Gram-Schmidt method.
// It is normalized afterwards, taking care of the Gaussian weight if it is a scattering state.

void HF_wave_function::OCM_orthogonalization (
					      const class array<class nlj_struct> &shells_qn_res , 
					      const class array<class spherical_state> &shells_res , 
					      const complex<double> &w , 
					      class spherical_state &shell)
{  
  const unsigned int N_nlj_res = shells_qn_res.dimension (0);
  
  const bool S_matrix_pole = shell.get_S_matrix_pole ();

  bool is_it_orthogonalized = false;

  for (unsigned int t = 0 ; t < N_nlj_res ; t++)
    {
      const class nlj_struct &shell_OCM_possibly_core_qn = shells_qn_res(t);

      const bool core_state = shell_OCM_possibly_core_qn.get_core_state ();

      if (core_state)
	{
	  const class spherical_state &OCM_core_shell = shells_res(t);

	  if (same_lj_particle (OCM_core_shell , shell))
	    {
	      shell.OCM_core_shell_orthogonalize (OCM_core_shell);

	      is_it_orthogonalized = true;
	    }
	}
    }

  if (is_it_orthogonalized)
    {
      shell.normalization (1.0/shell.Gamow_norm ());
      
      if (!S_matrix_pole) shell.normalization (sqrt (w));
    }
}




// Sort of calculated HF pole states with respect to their energy
// --------------------------------------------------------------
// Occupied and unoccupied states at HF level are determined from their energy, as only the states of lowest energies are occupied.
// However, core states are always occupied whatever their energy, and one can demand shells never to be occupied whatever their energy.
// The latter feature prevents the HF potential to oscillate between two values if partially occupied shells are too close in energy.
// 
// The energy used to sort HF pole states is then:
//
// Scattering state: E_very_large, with E_large a very large number (here 1E300) as scattering states can never be occupied at HF level.
//
// Core frozen state: -E_very_large.|Re[k2]| (it is assumed to be negative as it is in the core) if one has a core frozen state, hence always occupied.
// Thus, core frozen states can neither mix with valence states nor core states but not frozen and keep their original place in the many-body state.
//
// Core state not frozen: -E_large.|Re[k2]| (it is assumed to be negative as it is in the core) if one has a core state but not frozen,
// hence always occupied, with E_large a very large number but much smaller than E_very_large.
// Thus, core frozen states can neither mix with valence states nor core frozen states and keep their original place in the many-body state.
//
// State demanded never to be occupied at HF level: E_large. Thus, states demanded never to be occupied at HF level cannot mix with valence states.
//
// Other states: these are valence states which can be occupied or not at HF level.
// One takes Re[k^2] as energy value, as the hbar^2/2m constant is not important therein and one sorts with respect to the real part of energy.
//
// Energies, and hence states, are then sorted with a quick sort routine.

double HF_wave_function::Re_k2_for_energy_sort (const class nlj_struct &shell_qn)
{	
  const double very_large_energy = INFINITE;

  const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

  if (!S_matrix_pole) return (very_large_energy);
  
  const complex<double> k = shell_qn.get_k ();
  
  const complex<double> k2 = k*k;

  const double Re_k2 = real (k2);
  
  const bool core_state = shell_qn.get_core_state ();
  
  const bool frozen_state = shell_qn.get_frozen_state ();

  if (core_state && frozen_state) return (-very_large_energy*abs (Re_k2));
  
  const double large_energy = SQRT_INFINITE;

  const bool is_it_for_HF_gs = shell_qn.get_is_it_for_HF_gs ();
  
  if (!is_it_for_HF_gs) return (large_energy);
    
  if (core_state && !frozen_state) return (-large_energy*abs (Re_k2));

  return Re_k2;
}

void HF_wave_function::energy_sort (
				    const int low , 
				    const int high , 
				    class array<class spherical_state> &shells , 
				    class array<class nlj_struct> &shells_qn)
{ 
  const int pivot_index = low + (high - low)/2;
  
  const double pivot_k2 = Re_k2_for_energy_sort (shells_qn(pivot_index));

  int i_sort = low;
  int j_sort = high;

  do
    {
      double k2_i_sort = Re_k2_for_energy_sort (shells_qn(i_sort));
      
      while ((k2_i_sort < pivot_k2) && (abs (k2_i_sort - pivot_k2) > precision))
	{
	  i_sort++;
	  
	  k2_i_sort = Re_k2_for_energy_sort (shells_qn(i_sort));
	}

      double k2_j_sort = Re_k2_for_energy_sort (shells_qn(j_sort));
      
      while ((k2_j_sort > pivot_k2) && (abs (k2_j_sort - pivot_k2) > precision))
	{
	  j_sort--;
	  
	  k2_j_sort = Re_k2_for_energy_sort (shells_qn(j_sort));
	}

      if (i_sort <= j_sort)
	{
	  swap (shells(i_sort) , shells(j_sort));
	  
	  swap (shells_qn(i_sort) , shells_qn(j_sort));
	  
	  i_sort++ , j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) energy_sort (low , j_sort , shells , shells_qn);

  if (i_sort < high) energy_sort (i_sort , high , shells , shells_qn); 
}








// Modification of the truncation energy of bound and resonant states to state their occupied or unoccupied character at HF level
// ------------------------------------------------------------------------------------------------------------------------------
// This routine is useful when using MSDHF only, even though it is called in all cases.
// Bound and resonant states are separated in two groups at HF level: those occupied in the HF ground state and those unoccupied in the HF ground state. 
// The former are assigned a truncation energy of 0 and the latter a truncation energy of 1.
// Core frozen states are not considered as occupied for truncation purposes, as they do not enter Slater determinants in the shell model part of MSDHF.
// This way, if one optimizes the MSDHF potential, not with respect to the ground state but with respect to an excited state, 
// as is the case if one optimizes the 1s1/2 state in 17O for example, truncations can be easily performed to include the latter 1p-1h configuration in the shell model part of MSDHF with 0d5/2 -> 1s1/2.

void HF_wave_function::e_trunc_modify (
				       const unsigned int N_valence_nucleons_basis , 
				       class array<class nlj_struct> &shells_qn)
{
  const unsigned int N_nlj = shells_qn.dimension (0);
  
  class configuration C_GS(N_valence_nucleons_basis);
  
  C_GS.ground_state (0 , shells_qn);

  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      class nlj_struct &shell_qn = shells_qn(s);

      const enum particle_type particle = shell_qn.get_particle ();

      const int strangeness = particle_strangeness_determine (particle);

      if (strangeness != 0) continue;
      
      const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

      if (S_matrix_pole)
	{
	  const int e_trunc = (C_GS.is_shell_occupied (s)) ? (0) : (1);

	  shell_qn.initialize (S_matrix_pole ,
			       shell_qn.get_core_state () ,
			       shell_qn.get_frozen_state () ,
			       shell_qn.get_hole_state () ,
			       shell_qn.get_OCM_valence_state () ,
			       shell_qn.get_is_it_HO () ,
			       shell_qn.get_is_it_for_HF_gs () ,
			       shell_qn.get_is_it_natural_orbital () ,
			       shell_qn.get_particle () ,
			       e_trunc ,
			       shell_qn.get_n () ,
			       shell_qn.get_l () ,
			       shell_qn.get_j () ,
			       shell_qn.get_segment () ,
			       shell_qn.get_k () ,
			       shell_qn.get_w () ,
			       shell_qn.get_C0 () ,
			       shell_qn.get_Cplus () ,
			       shell_qn.get_k_plus () ,
			       shell_qn.get_C0_plus () ,
			       shell_qn.get_k_minus () ,
			       shell_qn.get_C0_minus ());
	}
    }
}










// Determination of occupied pairs at MSDHF level (two-particle code only)
// -----------------------------------------------------------------------
// This routine is useful when using MSDHF only, even though it is called in all cases.
//
// One optimizes the partial wave (l,j) for a proton or neutron, so that that nucleon must occupy an (l,j) shell so that it can be optimized with MSDHF.
//
// If one has a proton-neutron pair and one optimizes the proton partial wave (l,j), 
// one puts the neutron in the lowest possible shell which is not core frozen and proton in the lowest possible (l,j) shell which is not core frozen
//
// If one has a proton-neutron pair and one optimizes the neutron partial wave (l,j), 
// one puts the proton in the lowest possible shell which is not core frozen and neutron in the lowest possible (l,j) shell which is not core frozen
//
// If one has a proton-proton or neutron-neutron pairs and one optimizes the partial wave (l,j),
// one puts the left nucleon of the pair in the lowest possible shell which is not core frozen and the right nucleon of the pair in the lowest possible (l,j) shell which is not core frozen.
//
// Such pairs are determined here and stored.

void HF_wave_function::occupied_pairs_determine (
						 const enum space_type basis_space , 
						 const class HF_nucleons_data &HF_data_other_particle_type , 
						 class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj_res = HF_data.get_N_nlj_res ();

  const unsigned int N_valence_nucleons_basis = HF_data.get_N_valence_nucleons_basis ();

  if ((N_nlj_res == 0) || (N_valence_nucleons_basis == 0)) return;

  const int lmax = HF_data.get_lmax ();

  const class array<class nlj_struct> &shells_qn_res = HF_data.get_shells_quantum_numbers_res ();

  const class array<class nlj_struct> &shells_qn_res_neighbor_particle = (basis_space == PROT_NEUT_Y) ? (HF_data_other_particle_type.get_shells_quantum_numbers_res ()) : (shells_qn_res);

  class lj_table<class pair_str> &occupied_pairs = HF_data.get_occupied_pairs ();

  const bool is_it_OCM_basis = HF_data.get_is_it_OCM_basis ();

  if (is_it_OCM_basis) return;

  unsigned int s_neighbor = 0;

  bool is_s_neighbor_frozen_state = true;

  while (is_s_neighbor_frozen_state)
    {
      const class nlj_struct &s_neighbor_shell_qn_res = shells_qn_res_neighbor_particle(s_neighbor);

      const bool frozen_s_neighbor = s_neighbor_shell_qn_res.get_frozen_state ();

      if (frozen_s_neighbor) s_neighbor++;

      is_s_neighbor_frozen_state = frozen_s_neighbor;
    } 

  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	bool is_lj_occupied = false;

	for (unsigned int s = 0 ; (s < N_nlj_res) && (!is_lj_occupied) ; s++)
	  {
	    const class nlj_struct &shell_qn_res = shells_qn_res(s);

	    const enum particle_type particle = shell_qn_res.get_particle ();

	    const int strangeness = particle_strangeness_determine (particle);

	    if (strangeness != 0) continue;
      
	    const bool frozen_state = shell_qn_res.get_frozen_state ();

	    if (frozen_state) continue;

	    const int ls = shell_qn_res.get_l ();

	    const double js = shell_qn_res.get_j ();

	    if (same_lj_particle (particle , l , j , particle , ls , js))
	      { 
		is_lj_occupied = true;

		if (basis_space == PROT_NEUT_Y)
		  occupied_pairs(l , j) = (particle == PROTON) ? (pair_str (PROTON , s , NEUTRON , s_neighbor)) : (pair_str (NEUTRON , s_neighbor , PROTON , s));
		else
		  occupied_pairs(l , j) = pair_str (particle , s_neighbor , particle , s);
	      }
	  }
      } 
}






// Determination of the configurations to optimize at MSDHF level (general case, excluding two-particle codes)
// -----------------------------------------------------------------------------------------------------------
// This routine is used with MSDHF only.
//
// One builds here the configurations which will be optimized at MSDHF level to optimize the MSDHF potential for a (l,j) partial wave.
//
// For this, one considers the ground state configuration. If an (l,j) shell is occupied therein, it can be used to optimize the MSDHF potential for that (l,j) partial wave.
// If no (l,j) shell is occupied therein, one generates 1p-1h excitations from the last occupied shell of the ground state configuration to higher (l,j) shells unoccupied at ground state level.
// Then, one can optimize the MSDHF potential for that (l,j) partial wave from this 1p-1h configuration, as an (l,j) shell is occupied therein.
//
// The principal quantum number of the highest shell in the (l,j) partial wave occupied in the ground state configuration or 1p-1h configurations is also determined and stored.
// It is nessary to perform 1p-1h excitations from the last occupied shell of the ground state configuration to that latter shell in the MSDHF procedure.

void HF_wave_function::occupied_poles_configurations_to_diagonalize_determine (class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj_res = HF_data.get_N_nlj_res ();

  const unsigned int N_valence_nucleons_basis = HF_data.get_N_valence_nucleons_basis ();

  if ((N_nlj_res == 0) || (N_valence_nucleons_basis == 0)) return;
  
  const unsigned int N_valence_nucleons_basis_minus_one = N_valence_nucleons_basis - 1;

  const int lmax = HF_data.get_lmax ();
  
  const class array<class nlj_struct> &shells_qn_res = HF_data.get_shells_quantum_numbers_res ();

  const class lj_table<bool> &is_partial_wave_optimized_HF_MSDHF_tab = HF_data.get_is_partial_wave_optimized_HF_MSDHF_tab ();

  class lj_table<int> &highest_occupied_n_tab = HF_data.get_highest_occupied_n_tab ();

  highest_occupied_n_tab = -1;

  const bool is_it_OCM_basis = HF_data.get_is_it_OCM_basis ();

  if (is_it_OCM_basis) return;

  class lj_table<class configuration> &configurations_to_diagonalize = HF_data.get_configurations_to_diagonalize ();

  class configuration C_GS(N_valence_nucleons_basis);

  C_GS.ground_state (0 , shells_qn_res);
 
  const unsigned int C_GS_last_occupied_shell = C_GS[N_valence_nucleons_basis_minus_one];
	    
  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	class configuration &C_lj = configurations_to_diagonalize(l , j);

	bool is_lj_GS_occupied = false;

	for (unsigned int s = 0 ; s < N_nlj_res ; s++)
	  {
	    const class nlj_struct &shell_qn_res = shells_qn_res(s);

	    const enum particle_type particle = shell_qn_res.get_particle ();

	    const int strangeness = particle_strangeness_determine (particle);

	    if (strangeness != 0) continue;
      
	    const bool frozen_state = shell_qn_res.get_frozen_state ();
	    	
	    if (!frozen_state)
	      {
		const int ns = shell_qn_res.get_n ();
		const int ls = shell_qn_res.get_l ();
		
		const double js = shell_qn_res.get_j ();
		
		if (same_lj_particle (particle , l , j , particle , ls , js))
		  {
		    if (C_GS.is_shell_occupied (s))
		      {
			C_lj = C_GS;
			
			is_lj_GS_occupied = true;

			highest_occupied_n_tab(l , j) = max (ns , highest_occupied_n_tab(l , j));
		      }
		  }
	      }
	  }

	if (!is_lj_GS_occupied && is_partial_wave_optimized_HF_MSDHF_tab(l , j))
	  {
	    for (unsigned int s = 0 ; s < N_nlj_res ; s++)
	      {
		const class nlj_struct &shell_qn_res = shells_qn_res(s);
		
		const enum particle_type particle = shell_qn_res.get_particle ();

		const int strangeness = particle_strangeness_determine (particle);

		if (strangeness != 0) continue;
      
		const bool frozen_state = shell_qn_res.get_frozen_state ();

		if (!frozen_state)
		  {
		    const int ns = shell_qn_res.get_n ();
		    const int ls = shell_qn_res.get_l ();

		    const double js = shell_qn_res.get_j ();

		    if (same_lj_particle (particle , l , j , particle , ls , js))
		      {
			C_GS.excitation_1p_1h (s , C_GS_last_occupied_shell , C_lj);

			highest_occupied_n_tab(l , j) = max (ns , highest_occupied_n_tab(l , j));
		      }
		  }
	      }
	  }
      }
}













// Number of occupied shells in the HF ground state
// ------------------------------------------------
// This routine is useful the HF potential only, even though it is called in all cases.
//
// One calculates the number of valence nucleons occupied in all shells at HF level. This is used to calculate coefficients of uniform filling approximation or single-particle/hole spherical HF potentials.
// The total number of occupied shells is also calculated and stored.

void HF_wave_function::shells_occupied_number_calc (class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj = HF_data.get_N_nlj ();
  
  if (N_nlj == 0) return;

  const unsigned int N_valence_nucleons_basis = HF_data.get_N_valence_nucleons_basis ();
  
  const class array<class nlj_struct> &shells_qn_res = HF_data.get_shells_quantum_numbers_res ();

  class nlj_table<unsigned int> &N_valence_nucleons_in_shell_tab = HF_data.get_N_valence_nucleons_in_shell_tab ();
  
  N_valence_nucleons_in_shell_tab = 0;

  unsigned int Nshells_occ = 0;

  unsigned int particles_number = 0;

  for (unsigned int s = 0 ; (s < N_nlj) && (particles_number < N_valence_nucleons_basis) ; s++)
    {
      Nshells_occ++;

      const class nlj_struct &shell_qn_res = shells_qn_res(s);
      
      const enum particle_type particle = shell_qn_res.get_particle ();
		
      const int strangeness = particle_strangeness_determine (particle);
		
      if (strangeness != 0) continue;
		
      const bool frozen_state = shell_qn_res.get_frozen_state ();

      if (frozen_state) continue;

      const int n = shell_qn_res.get_n ();
      const int l = shell_qn_res.get_l ();

      const double j = shell_qn_res.get_j ();

      const unsigned int m_number = shell_qn_res.m_number_determine ();

      for (unsigned int m_index = 0 ; (m_index < m_number) && (particles_number < N_valence_nucleons_basis) ; m_index++)
	{
	  particles_number++;

	  N_valence_nucleons_in_shell_tab(n , l , j)++;
	}
    }

  HF_data.set_Nshells_occ (Nshells_occ);
}











// Test if the same state has been calculated sevral times and rejection of the repeated states
// --------------------------------------------------------------------------------------------
// If one tries to calculate a nlj state, and that it is well unbound, the code can returned the energy of a bound or loosely resonant state for which n' < n.
// Then, one checks here if such a situation occurred, and each spherical_state structure in this situation is put to the rejected case.

void HF_wave_function::state_rejection_test (
					     const class array<class nlj_struct> &shells_qn , 
					     const unsigned int s_ref , 
					     class array<spherical_state> &shells)
{
  const unsigned int N_nlj = shells_qn.dimension (0);

  const class spherical_state &shell_ref = shells(s_ref);

  const int n_ref = shell_ref.get_n ();
  const int l_ref = shell_ref.get_l ();

  const double j_ref = shell_ref.get_j ();

  const complex<double> k_ref = shell_ref.get_k ();

  bool rejected = false;

  for (unsigned int s = 0 ; (s < N_nlj) && (!rejected) ; s++)
    {
      const class nlj_struct &shell_qn = shells_qn(s);
      
      const enum particle_type particle = shell_qn.get_particle ();
      
      const int strangeness = particle_strangeness_determine (particle);
      
      if (strangeness != 0) continue;
		
      const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();

      const double j = shell_qn.get_j ();

      class spherical_state &shell = shells(s);

      const bool is_shell_filled = shell.is_it_filled ();

      if (is_shell_filled && S_matrix_pole && same_lj_particle (particle , l , j , particle , l_ref , j_ref) && (n < n_ref))
	{
	  const complex<double> k = shell.get_k ();

	  if (inf_norm (1.0 - k/k_ref) < 1E-3)
	    {
	      cout << "Rejected." << endl;
	      
	      rejected = true;

	      shell.reject ();
	    }
	}
    }
}









// Orthogonalization of all shells with respect to one-body core shells
// ---------------------------------------------------------------------
// One orthogonalizes all valence shells with respect to one-body core shells with the modified Gram-Schmidt method.
// They are also normalized afterwards, taking care of their Gaussian weight if they are scattering states.

void HF_wave_function::all_shells_orthogonalize (
						 const bool is_it_res ,
						 class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj = (is_it_res) ? (HF_data.get_N_nlj_res ()) : (HF_data.get_N_nlj ());
  
  if (N_nlj == 0) return;

  class array<class nlj_struct> &shells_qn_res = HF_data.get_shells_quantum_numbers_res ();

  class array<class spherical_state> &shells_res = HF_data.get_shells_res ();

  class array<class nlj_struct> &shells_qn = (is_it_res) ? (HF_data.get_shells_quantum_numbers_res ()) : (HF_data.get_shells_quantum_numbers ());

  class array<class spherical_state> &shells = (is_it_res) ? (HF_data.get_shells_res ()) : (HF_data.get_shells ());

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      class spherical_state &shell = shells(s);

      if (shell.is_it_filled ())
	{
	  const class nlj_struct &shell_qn = shells_qn(s);
	  
	  const bool core_state = shell_qn.get_core_state ();

	  if (!core_state) 
	    {
	      const complex<double> &w = shell_qn.get_w ();

	      OCM_orthogonalization (shells_qn_res , shells_res , w , shell);
	    }
	}
    }
}

void HF_wave_function::all_shells_pm_orthogonalize (
						    const int pm , 
						    class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj = HF_data.get_N_nlj ();
  
  if (N_nlj == 0) return;

  const class array<class nlj_struct> &shells_qn_res = HF_data.get_shells_quantum_numbers_res ();
  
  const class array<class spherical_state> &shells_res = HF_data.get_shells_res ();

  const class array<class nlj_struct> &shells_qn = HF_data.get_shells_quantum_numbers ();

  class array<class spherical_state> &shells_pm = (pm == 1) ? (HF_data.get_shells_plus ()) : (HF_data.get_shells_minus ());

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      class spherical_state &shell_pm = shells_pm(s);

      if (shell_pm.is_it_filled ())
	{
	  const class nlj_struct &shell_qn = shells_qn(s);

	  const bool core_state = shell_qn.get_core_state ();

	  const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ();

	  if (!core_state && !is_it_natural_orbital) 
	    {
	      const complex<double> &w = shell_qn.get_w ();

	      OCM_orthogonalization (shells_qn_res , shells_res , w , shell_pm);
	    }
	}
    }
}









// Calculation of the starting values of HF/MSDHF/OCM wave functions and equivalent potentials and sources using a WS or KKNN potential for the initial potential
// --------------------------------------------------------------------------------------------------------------------------------------------------------------
// The self-consistent procedure must start with a starting point for wave functions, equivalent potentials and sources.
// One chooses the same type of potential as that used in the Hamiltonian for the initial potential, except that it can have other parameters.
// All initial wave functions, equivalent potentials and sources are calculated from it, with equivalent potentials equal to the initial potential and sources put to zero as the initial potential is local.
// If the OCM potential is used, one calculates all bound, resonant and scattering states as they will be used as a complete basis to diagonalize the php Hamiltonian (see GSM_HF_potentials_common_OCM_part_common.cpp).
// Otherwise, the initial potential Hamiltonian is diagonalized with HO basis as it is a starting point for the HF/MSDHF potential, so that one does not precise wave functions and scattering states can be neglected as this level.
// Wave functions are then sorted using the methods described above to prepare for the HF procedure

void HF_wave_function::all_shells_alloc_calc_inter_init (
							 const bool is_there_cout , 
							 const bool is_it_res , 
							 const class interaction_class &inter_data_basis , 
							 class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj_res = HF_data.get_N_nlj_res ();
  
  const unsigned int N_nlj = (is_it_res) ? (N_nlj_res) : (HF_data.get_N_nlj ());

  if (N_nlj == 0) return;

  const class lj_table<double> &b_lab_partial_waves = HF_data.get_b_lab_partial_waves ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);

  const enum particle_type particle = HF_data.get_particle ();

  const enum potential_type H_potential = (is_it_realistic_interaction (TBME_inter)) ? (WS_ANALYTIC) : (HF_data.get_H_potential ());

  const int A_basis = HF_data.get_A_basis ();

  const int Z_charge_basis_potential = HF_data.get_Z_charge_basis_potential ();
  
  const int N_valence_nucleons_basis = HF_data.get_N_valence_nucleons_basis ();
  
  const unsigned int N_bef_R_GL = HF_data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = HF_data.get_N_aft_R_GL ();
  
  const unsigned int N_bef_R_uniform = HF_data.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = HF_data.get_N_aft_R_uniform ();
  
  const double R = HF_data.get_R ();
  
  const double R_real_max = HF_data.get_R_real_max ();

  const double R_charge = HF_data.get_R_charge ();
  
  const double step_bef_R_uniform = HF_data.get_step_bef_R_uniform ();

  const double nucleon_mass_for_calc = HF_data.get_nucleon_mass_for_calc ();
  
  const double b_HO_for_diag = pow (static_cast<double> (A_basis) , 0.1666666666666667);
  
  const bool is_it_OCM_basis = HF_data.get_is_it_OCM_basis ();

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const double nucleus_mass_basis = HF_data.get_nucleus_mass_basis ();

  const double mass_modif = (!is_it_COSM) ? (-nucleus_mass_basis) : (nucleus_mass_basis);

  const class array<double> &V0_KKNN_tab     = HF_data.get_V0_KKNN_tab ();  
  const class array<double> &rho_KKNN_tab    = HF_data.get_rho_KKNN_tab ();
  const class array<double> &Vls_KKNN_tab    = HF_data.get_Vls_KKNN_tab ();
  const class array<double> &rho_ls_KKNN_tab = HF_data.get_rho_ls_KKNN_tab ();
  
  const double V0_KKNN[5] = {
    V0_KKNN_tab(0 , 0) ,
    V0_KKNN_tab(0 , 1) ,
    V0_KKNN_tab(0 , 2) ,
    V0_KKNN_tab(0 , 3) ,
    V0_KKNN_tab(0 , 4)};
  
  const double rho_KKNN[5] = {
    rho_KKNN_tab(0 , 0) ,
    rho_KKNN_tab(0 , 1) ,
    rho_KKNN_tab(0 , 2) ,
    rho_KKNN_tab(0 , 3) ,
    rho_KKNN_tab(0 , 4)};

  const double Vls_KKNN[3] = {
    Vls_KKNN_tab(0 , 0) ,
    Vls_KKNN_tab(0 , 1) ,
    Vls_KKNN_tab(0 , 2)};
  
  const double rho_ls_KKNN[3] = {
    rho_ls_KKNN_tab(0 , 0) ,
    rho_ls_KKNN_tab(0 , 1) ,
    rho_ls_KKNN_tab(0 , 2)};

  const class array<double> &d_basis_tab        = HF_data.get_d_basis_tab ();
  const class array<double> &R0_basis_tab       = HF_data.get_R0_basis_tab ();
  const class array<double> &Vo_basis_tab       = HF_data.get_Vo_basis_tab ();
  const class array<double> &Vso_basis_tab      = HF_data.get_Vso_basis_tab ();
  const class array<double> &Im_Vo_basis_tab    = HF_data.get_Im_Vo_basis_tab ();
  const class array<double> &Im_Vso_basis_tab   = HF_data.get_Im_Vso_basis_tab ();
  const class array<double> &Im_Vsurf_basis_tab = HF_data.get_Im_Vsurf_basis_tab ();

  if (is_there_cout && (THIS_PROCESS == MASTER_PROCESS) && is_it_res)  cout << endl << "Pole one-" << particle << " shells starting point to generate HF/MSDHF potentials" << endl; 
  if (is_there_cout && (THIS_PROCESS == MASTER_PROCESS) && !is_it_res) cout << endl << "One-"      << particle << " HF/MSDHF shells" << endl; 

  class array<class nlj_struct> &shells_qn = (is_it_res) ? (HF_data.get_shells_quantum_numbers_res ()) : (HF_data.get_shells_quantum_numbers ());
  
  class array<class spherical_state> &shells = (is_it_res) ? (HF_data.get_shells_res ()) : (HF_data.get_shells ());

  class nlj_table<complex<double> > &Ueq_finite_range_averaged_tab_uniform = (is_it_res) ? (HF_data.get_Ueq_finite_range_res_averaged_tab_uniform ()) : (HF_data.get_Ueq_finite_range_averaged_tab_uniform ());  
  class nlj_table<complex<double> > &Ueq_finite_range_averaged_tab_GL      = (is_it_res) ? (HF_data.get_Ueq_finite_range_res_averaged_tab_GL      ()) : (HF_data.get_Ueq_finite_range_averaged_tab_GL      ());

  class nlj_table<complex<double> > &source_averaged_tab_uniform = (is_it_res) ? (HF_data.get_source_res_averaged_tab_uniform ()) : (HF_data.get_source_averaged_tab_uniform ());
  class nlj_table<complex<double> > &source_averaged_tab_GL      = (is_it_res) ? (HF_data.get_source_res_averaged_tab_GL      ()) : (HF_data.get_source_averaged_tab_GL      ());

  class nlj_table<complex<double> > &Ueq_finite_range_tab_uniform = (is_it_res) ? (HF_data.get_Ueq_finite_range_res_tab_uniform ()) : (HF_data.get_Ueq_finite_range_tab_uniform ());
  class nlj_table<complex<double> > &Ueq_finite_range_tab_GL      = (is_it_res) ? (HF_data.get_Ueq_finite_range_res_tab_GL      ()) : (HF_data.get_Ueq_finite_range_tab_GL      ());
  
  class nlj_table<complex<double> > &source_tab_uniform = (is_it_res) ? (HF_data.get_source_res_tab_uniform ()) : (HF_data.get_source_tab_uniform ());  
  class nlj_table<complex<double> > &source_tab_GL      = (is_it_res) ? (HF_data.get_source_res_tab_GL      ()) : (HF_data.get_source_tab_GL      ());

  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);

  source_averaged_tab_uniform = 0.0;

  source_averaged_tab_GL = 0.0;
  
  source_tab_uniform = 0.0;

  source_tab_GL = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {	
      class nlj_struct &shell_qn = shells_qn(s);
      
      const enum particle_type particle = shell_qn.get_particle ();

      const int strangeness = particle_strangeness_determine (particle);

      if (strangeness != 0) continue;
				   
      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();
      
      const double j = shell_qn.get_j ();
      
      const complex<double> C0 = shell_qn.get_C0 ();

      const complex<double> Cplus = shell_qn.get_Cplus ();

      const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

      const bool is_it_HO = shell_qn.get_is_it_HO ();
      
      const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ();

      const double d        = d_basis_tab       (0 , l);
      const double R0       = R0_basis_tab      (0 , l);
      const double Vo       = Vo_basis_tab      (0 , l);
      const double Vso      = Vso_basis_tab     (0 , l);
      const double Im_Vo    = Im_Vo_basis_tab   (0 , l);
      const double Im_Vso   = Im_Vso_basis_tab  (0 , l);
      const double Im_Vsurf = Im_Vsurf_basis_tab(0 , l);
      
      const complex<double> Vo_complex(Vo , Im_Vo);

      const complex<double> Vso_complex(Vso , Im_Vso);

      const double R0_inter = inter_data_basis.get_R0 ();
      
      const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);
      
      if (S_matrix_pole)
	{	  
	  class spherical_state &shell = shells(s);

	  shell.allocate (false , true , H_potential , A_basis , Z_charge_basis_potential , mass_modif , NADA , N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , 0 , 0 ,
			  R , NADA , R0_matching_point , R_real_max , 0.0 , 0.0 , S_matrix_pole , particle , n , NADA , l , j , true , 0.0 , nucleon_mass_for_calc , C0 , Cplus);
	  
	  class potentials_effective_mass T;

	  class WS_class &WS_potential = T.get_WS_potential ();
	  
	  class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();

	  class WS_complex_class &WS_complex_potential = T.get_WS_complex_potential ();
	  
	  class WS_analytic_complex_class &WS_complex_analytic_potential = T.get_WS_complex_analytic_potential ();

	  class KKNN_class &KKNN_potential = T.get_KKNN_potential ();

	  T.initialize_constants (
				  shell.get_potential () ,
				  shell.get_kinetic_factor () ,
				  shell.get_jr () ,
				  shell.get_l () ,
				  shell.get_ZY_charge () ,
				  shell.get_j () ,
				  shell.get_k () ,
				  shell.get_eta () ,
				  NADA);

	  WS_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge_basis_potential , R_charge , l , j);

	  WS_analytic_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge_basis_potential , R_charge , l , j);
	  
	  WS_complex_potential.initialize (false , d , R0 , Vo_complex , Vso_complex , Im_Vsurf , particle , Z_charge_basis_potential , R_charge , l , j);

	  WS_complex_analytic_potential.initialize (false , d , R0 , Vo_complex , Vso_complex , Im_Vsurf , particle , Z_charge_basis_potential , R_charge , l , j);

	  KKNN_potential.initialize (false , V0_KKNN , rho_KKNN , Vls_KKNN , rho_ls_KKNN , particle , Z_charge_basis_potential , R_charge , l , j);
      
	  if (is_it_OCM_basis)
	    {
	      shell.k_search (T , true , is_there_cout);
	      
	      shell.wave_calculation (is_there_cout , T , true);	     

	      state_rejection_test (shells_qn , s , shells);
	    }
	  else
	    shell.wave_calculation_HO_diag (T , b_HO_for_diag);
	  
#ifdef UseOpenMP
#pragma omp critical
#endif 
	  if (is_there_cout && !is_it_OCM_basis && (THIS_PROCESS == MASTER_PROCESS))
	    {
	      if (abs (imag (shell.get_E ())) < precision)
		cout << shell << " " << particle << " E:" << real (shell.get_E ()) << " MeV " << endl;
	      else
		cout << shell << " " << particle << " E:" << real (shell.get_E ()) << " MeV  G:" << -2000.0*imag (shell.get_E ()) << " keV " << endl;
	    }

	  shell_qn.initialize (S_matrix_pole ,
			       shell_qn.get_core_state () ,
			       shell_qn.get_frozen_state () ,
			       shell_qn.get_hole_state () ,
			       shell_qn.get_OCM_valence_state () ,
			       shell_qn.get_is_it_HO () ,
			       shell_qn.get_is_it_for_HF_gs () ,
			       shell_qn.get_is_it_natural_orbital () ,
			       shell_qn.get_particle () ,
			       shell_qn.get_e_trunc () ,
			       shell_qn.get_n () ,
			       shell_qn.get_l () ,
			       shell_qn.get_j () ,
			       shell_qn.get_segment () ,
			       shell.get_k () ,
			       shell_qn.get_w () ,
			       shell_qn.get_C0 () ,
			       shell_qn.get_Cplus () ,
			       shell_qn.get_k_plus () ,
			       shell_qn.get_C0_plus () ,
			       shell_qn.get_k_minus () ,
			       shell_qn.get_C0_minus ());
	}
      else
	{
	  if (is_it_OCM_basis && !S_matrix_pole)
	    {
	      const complex<double> k = shell_qn.get_k ();
	      const complex<double> w = shell_qn.get_w ();

	      class spherical_state &shell = shells(s);

	      shell.allocate (false , false , H_potential , A_basis , Z_charge_basis_potential , mass_modif , NADA , N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , 0 , 0 ,
			      R , NADA , R0_matching_point , R_real_max , 0.0 , 0.0 , S_matrix_pole , particle , n , NADA , l , j , true , k , nucleon_mass_for_calc , C0 , Cplus);

	      if (is_it_HO)
		{
		  const double b_lab = b_lab_partial_waves(l , j);
		  
		  shell.HO_wave_function (b_lab);
		}
	      else if (!is_it_natural_orbital)
		{
		  class potentials_effective_mass T;

		  class WS_class &WS_potential = T.get_WS_potential ();

		  class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();

		  class WS_complex_class &WS_complex_potential = T.get_WS_complex_potential ();

		  class WS_analytic_complex_class &WS_complex_analytic_potential = T.get_WS_complex_analytic_potential ();

		  class KKNN_class &KKNN_potential = T.get_KKNN_potential ();

		  T.initialize_constants (
					  shell.get_potential () ,
					  shell.get_kinetic_factor () ,
					  shell.get_jr () ,
					  shell.get_l () ,
					  shell.get_ZY_charge () ,
					  shell.get_j () ,
					  shell.get_k () ,
					  shell.get_eta () ,
					  NADA);

		  WS_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge_basis_potential , R_charge , l , j);

		  WS_analytic_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge_basis_potential , R_charge , l , j);

		  KKNN_potential.initialize (false , V0_KKNN , rho_KKNN , Vls_KKNN , rho_ls_KKNN , particle , Z_charge_basis_potential , R_charge , l , j);

		  WS_complex_potential.initialize (false , d , R0 , Vo_complex , Vso_complex , Im_Vsurf , particle , Z_charge_basis_potential , R_charge , l , j);

		  WS_complex_analytic_potential.initialize (false , d , R0 , Vo_complex , Vso_complex , Im_Vsurf , particle , Z_charge_basis_potential , R_charge , l , j);

		  shell.wave_calculation (is_there_cout , T , false);

		  shell.normalization (sqrt (w));	      
		}
	    }
	}
    }

  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_qn(s);
      
      const enum particle_type particle = shell_qn.get_particle ();

      const int strangeness = particle_strangeness_determine (particle);

      if (strangeness != 0) continue;
      
      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();

      const double j = shell_qn.get_j ();

      const double d        = d_basis_tab     (0 , l);
      const double R0       = R0_basis_tab    (0 , l);
      const double Vo       = Vo_basis_tab    (0 , l);
      const double Vso      = Vso_basis_tab   (0 , l);
      const double Im_Vo    = Im_Vo_basis_tab (0 , l);
      const double Im_Vso   = Im_Vso_basis_tab(0 , l);
      const double Im_Vsurf = Im_Vso_basis_tab(0 , l);
      
      const complex<double> Vo_complex(Vo , Im_Vo);

      const complex<double> Vso_complex(Vso , Im_Vso);

      const unsigned int zero_index_uniform = Ueq_finite_range_tab_uniform.index_determine (n , l , j , 0);
      
      const unsigned int zero_index_GL = Ueq_finite_range_tab_GL.index_determine  (n , l , j , 0);
	  
      const class WS_complex_class WS_nuclear(false , d , R0 , Vo_complex , Vso_complex , Im_Vsurf , particle , Z_charge_basis_potential , R_charge , l , j);
	  
      const class KKNN_class KKNN_nuclear_potential(false , V0_KKNN , rho_KKNN , Vls_KKNN , rho_ls_KKNN , NEUTRON , Z_charge_basis_potential , R_charge , l , j);

      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	{
	  const double r = i*step_bef_R_uniform;
	      
	  const unsigned int index_uniform = zero_index_uniform + i;
	  
	  Ueq_finite_range_tab_uniform[index_uniform] = Ueq_finite_range_averaged_tab_uniform[index_uniform] = (H_potential == KKNN) ? (KKNN_nuclear_potential(r)) : (WS_nuclear(r));
	}
	   
      const bool is_there_infinite = !finite (Ueq_finite_range_tab_uniform(n , l , j , 0));
 
      const complex<double> slope = (Ueq_finite_range_tab_uniform(n , l , j , 2) - Ueq_finite_range_tab_uniform(n , l , j , 1))/step_bef_R_uniform;

      const complex<double> shift = Ueq_finite_range_tab_uniform(n , l , j , 1);

      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  const double r = r_bef_R_tab_GL(i);
	  
	  const unsigned int index_GL = zero_index_GL + i;
	  
	  Ueq_finite_range_tab_GL[index_GL] = Ueq_finite_range_averaged_tab_GL[index_GL] = (H_potential == KKNN) ? (KKNN_nuclear_potential(r)) : (WS_nuclear(r));
	      
	  if (is_there_infinite && (r < step_bef_R_uniform)) Ueq_finite_range_tab_GL[index_GL] = Ueq_finite_range_averaged_tab_GL[index_GL] = slope*(r - step_bef_R_uniform) + shift;  
	}
      
      if (is_there_infinite) Ueq_finite_range_tab_uniform(n , l , j , 0) = Ueq_finite_range_averaged_tab_uniform(n , l , j , 0) = 2.0*Ueq_finite_range_tab_uniform(n , l , j , 1) - Ueq_finite_range_tab_uniform(n , l , j , 2); 
    }
  

  if (is_it_res)
    {
      energy_sort (0 , N_nlj - 1 , shells , shells_qn);
      
      e_trunc_modify (N_valence_nucleons_basis , shells_qn); 
    }	
  else
    energy_sort (0 , N_nlj_res - 1 , shells , shells_qn);

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << endl;
}









// Diagonalization of the php Hamiltonian (see GSM_HF_potentials_common_OCM_part_common.cpp) with the Berggren basis generated by the initial potential for the OCM procedure
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// The representation of the php Hamiltonian is calculated with the Berggren basis generated by the initial basis WS or KKNN potential.
// Indeed, the latter is complete so that it can be used to diagonalize the php Hamiltonian.
// It thus provides with the best starting point of the OCM potential in the self-consistent procedure.
//
// One has: <wf_out | php | wf_in> = <wf_out | h - hq - qh + qhq | wf_in> = e_in delta(in,out) - (e_in + e_out) <wf_out | q | wf_in> + <wf_out | qhq | wf_in>
//          where <wf_out | q | wf_in> = \sum_{wf_core} <wf_out | wf_core> <wf_core | wf_in> and <wf_out | qhq | wf_in> = \sum_{wf_core,wfp_core} <wf_out | wfp_core> <wfp_core | h | wf_core> <wf_core | wf_in>
//          and where <wfp_core | h | wf_core> is calculated in the OBME_OCM_s_core_state_h_OCM_sp_core_state_calc routine.
//
// It is diagonalized here. 
//
// However, the part besides h, equal to - hq - qh + qhq, must be small enough so that the diagonalized states with a given principal quantum number n is close to the basis state of same principal quantum number,
// otherwise it is not a good starting point for it.
//
// This is checked by finding the most important component in a diagonalized state of principal quantum number n with the overlap method,
// and the associated basis state must have the principal quantum number n as the diagonalized state itself. Otherwise, the code stops as otherwise one cannot calculate the OCM potential afterwards.
//
// Shells are then deallocated, reallocated and recalculated from the diagonalized states.

void HF_wave_function::all_shells_alloc_calc_from_php_matrices_diagonalization (
										const bool is_there_cout ,
										const class interaction_class &inter_data_basis , 
										const class baryons_data &particles_data ,
										class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj_res = HF_data.get_N_nlj_res ();
  const unsigned int N_nlj     = HF_data.get_N_nlj ();
  
  if (N_nlj == 0) return;
  
  const int lmax = HF_data.get_lmax ();
  const int nmax = HF_data.get_nmax ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const enum particle_type particle = HF_data.get_particle ();

  const unsigned int N_bef_R_GL = HF_data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = HF_data.get_N_aft_R_GL ();
  
  const unsigned int N_bef_R_uniform = HF_data.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = HF_data.get_N_aft_R_uniform ();
  
  const int A_basis = HF_data.get_A_basis ();

  const int Z_charge_basis_potential = HF_data.get_Z_charge_basis_potential ();

  const double R = HF_data.get_R ();

  const double R_real_max = HF_data.get_R_real_max ();

  const double nucleus_mass_basis = HF_data.get_nucleus_mass_basis ();

  const double nucleon_mass_for_calc = HF_data.get_nucleon_mass_for_calc ();
  
  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const class array<double> &R0_tab = HF_data.get_R0_tab ();

  const bool is_it_OCM_HO_core = particles_data.get_is_it_OCM_HO_core ();

  const int Z_core = particles_data.get_Z_core ();

  const unsigned int particle_index = charge_baryon_index_determine (particle);
  
  const class array<class nlj_table<unsigned int> > &shells_indices_tab = particles_data.get_shells_indices_tab ();

  const class nlj_table<unsigned int> &shells_indices = shells_indices_tab(particle_index);

  const class lj_table<class matrix<complex<double> > > &php_matrices = HF_data.get_php_matrices ();

  class array<class nlj_struct> &shells_qn_res = HF_data.get_shells_quantum_numbers_res ();

  class array<class spherical_state> &shells_res = HF_data.get_shells_res ();

  class array<class nlj_struct> &shells_qn = HF_data.get_shells_quantum_numbers ();

  class array<class spherical_state> &shells = HF_data.get_shells ();

  class nlj_table<class spherical_state> shells_nlj(0.5 , nmax , lmax);

  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	const string particle_lj_str = make_string<enum particle_type> (particle) + " " + angular_state (l , j);
		      
	const double R0 = R0_tab(0 , l);

	const double R0_inter = inter_data_basis.get_R0 ();
	
	const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);

	const class matrix<complex<double> > &php_matrix = php_matrices(l,j);
	
	const int nmax_lj = php_matrix.get_dimension () - 1;

	const int nmax_lj_plus_one = nmax_lj + 1;

	bool is_partial_wave_considered = true;

	class array<unsigned int> basis_shells_lj_indices(nmax_lj_plus_one);
	
	for (int n = 0 ; n <= nmax_lj ; n++)
	  {
	    const unsigned int s = shells_indices(n , l , j);

	    const class nlj_struct &shell_qn = shells_qn(s);

	    const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ();

	    if (is_it_natural_orbital)
	      is_partial_wave_considered = false;
	    else
	      basis_shells_lj_indices(n) = s;
	  }

	if (is_partial_wave_considered)
	  {
	    class array<int> n_check_tab(nmax_lj_plus_one);

	    class matrix<complex<double> > wfs_matrix = php_matrix;

	    class array<complex<double> > E_tab(nmax_lj_plus_one);

	    total_diagonalization::symmetric::all_eigenpairs (wfs_matrix , E_tab);

	    for (int nn = 0 ; nn <= nmax_lj ; nn++)
	      {
		const class vector_class<complex<double> > &Vnn = wfs_matrix.eigenvector (nn);

		const int n = Vnn.closest_value_index_determine (1.0);

		n_check_tab(nn) = n;
	      }

	    for (int n = 0 ; n <= nmax_lj ; n++)
	      for (int nn = 0 ; nn <= nmax_lj ; nn++)
		{
		  if ((n != nn) && (n_check_tab(n) == n_check_tab(nn)))
		    error_message_print_abort ("Same eigenfunctions of different n's for partial wave " + particle_lj_str + " in HF_wave_function::all_shells_alloc_calc_from_php_matrices_diagonalization");
		}

	    for (int nn = 0 ; nn <= nmax_lj ; nn++)
	      {
		const class vector_class<complex<double> > &Vnn = wfs_matrix.eigenvector (nn);
		
		const int n = Vnn.closest_value_index_determine (1.0);

		const complex<double> E = E_tab(nn);

		const unsigned int s = shells_indices(n , l , j);

		const class nlj_struct &shell_qn = shells_qn(s);

		const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

		n_check_tab(nn) = n;

		class spherical_state &shell_nlj = shells_nlj(n , l , j);

		shell_nlj.allocate (false , false , HF , A_basis , Z_charge_basis_potential , nucleus_mass_basis , NADA , N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , 0 , 0 ,
				    R , NADA , R0_matching_point , R_real_max , 0.0 , 0.0 , S_matrix_pole , particle , n , NADA , l , j , false , NADA , nucleon_mass_for_calc , 1.0 , 1.0);

		shell_nlj.wave_calculation_from_vector (true , E , Vnn , basis_shells_lj_indices , shells);
	      }

	    for (int n = 0 ; n <= nmax_lj ; n++)
	      for (int nn = 0 ; nn <= nmax_lj ; nn++)
		{
		  if ((n != nn) && (n_check_tab(n) == n_check_tab(nn)))
		    error_message_print_abort ("Same eigenwave functions for different principal quantum numbers for partial wave " + particle_lj_str + " in HF_wave_function::all_shells_alloc_calc_from_php_matrices_diagonalization");
		}
	  }
      }

  waves_deallocate (HF_data);

  OCM_core_states_realloc_calc (is_there_cout , true  , is_it_OCM_HO_core , Z_core , inter_data_basis , HF_data);
  OCM_core_states_realloc_calc (is_there_cout , false , is_it_OCM_HO_core , Z_core , inter_data_basis , HF_data);

  for (unsigned int s = 0 ; s < N_nlj_res ; s++)
    {
      const class nlj_struct &shell_qn_res = shells_qn_res(s);
      
      const enum particle_type particle = shell_qn_res.get_particle ();

      const int strangeness = particle_strangeness_determine (particle);

      if (strangeness != 0) continue;
      
      const bool core_state = shell_qn_res.get_core_state ();

      const bool is_it_natural_orbital = shell_qn_res.get_is_it_natural_orbital ();

      if (!core_state && !is_it_natural_orbital)
	{
	  const int n = shell_qn_res.get_n ();
	  const int l = shell_qn_res.get_l ();

	  const double j = shell_qn_res.get_j ();

	  const class spherical_state &shell_nlj = shells_nlj(n , l , j);

	  shells_res(s).allocate_fill (shell_nlj);
	}
    }

  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_qn(s);
      
      const enum particle_type particle = shell_qn.get_particle ();

      const int strangeness = particle_strangeness_determine (particle);

      if (strangeness != 0) continue;
      
      const bool core_state = shell_qn.get_core_state ();

      const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ();

      if (!core_state && !is_it_natural_orbital)
	{
	  const int n = shell_qn.get_n ();
	  const int l = shell_qn.get_l ();

	  const double j = shell_qn.get_j ();

	  const class spherical_state &shell_nlj = shells_nlj(n , l , j);

	  shells(s).allocate_fill (shell_nlj);
	}
    }
  
  shells_nlj.deallocate_object_elements ();
}













// Equivalent potentials as splines
// --------------------------------
// One has the equivalent potential without the infinite range Coulomb part Ueq_finite_range_tab_uniform(n , l , j , i[radial]) and the source term source_tab_uniform(n , l , j , i[radial]).
//
// The non-local potential U(r,r') applied a wave function is written Ueq(r).u(r) + S(r), where Ueq(r) is the equivalent potential and S(r) the source.
//
// Ueq(r) = [1 - F(r)] \int U(r,r') u(r') dr' / u(r) and S(r) = F(r) \int U(r,r') u(r') dr', with F(r) a regularizing factor preventing from Ueq(r) to diverge if u(r) = 0, which is numerically non-zero only close to the zeroes of u(r).
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
//                  Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
//                  The ratio |u(r)|^2/|u'(r)|^2 prevents F(r) to be non zero when r -> +oo.
//                  Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// The equivalent potential and source are then deallocated, reallocated, calculated and stored as splines in the class potentials_effective_mass.

void HF_wave_function::trivially_equivalent_potential_splines_realloc_calc (
									    const bool is_it_real , 
									    const double R , 
									    const int Z_charge_basis_potential , 
									    const enum particle_type particle , 
									    const class nlj_table<complex<double> > &Ueq_finite_range_tab_averaged , 
									    const class nlj_table<complex<double> > &source_tab_averaged , 
									    const class array<double> &V_Coulomb_tab_uniform , 
									    const int n , 
									    const int l , 
									    const double j , 
									    class potentials_effective_mass &T)
{
  const unsigned int N_bef_R_uniform = V_Coulomb_tab_uniform.dimension (0);
  
  const double step_bef_R_uniform = R/static_cast<double> (N_bef_R_uniform - 1);

  const unsigned int zero_index_uniform = Ueq_finite_range_tab_averaged.index_determine (n , l , j , 0);

  class array<double> r_bef_R_tab_uniform(N_bef_R_uniform);
  
  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;

  class array<complex<double> > potential_tab(N_bef_R_uniform);
  
  class array<complex<double> > source_tab(N_bef_R_uniform);

  switch (particle)
    {
    case PROTON: for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) potential_tab(i) = Ueq_finite_range_tab_averaged[zero_index_uniform + i] + V_Coulomb_tab_uniform(i); break;

    case NEUTRON: for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) potential_tab(i) = Ueq_finite_range_tab_averaged[zero_index_uniform + i]; break;

    default: abort_all ();
    }

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) source_tab(i) = source_tab_averaged[zero_index_uniform + i];

  if (is_it_real) 
    {
      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	{
	  potential_tab(i) = real (potential_tab(i));

	  source_tab(i) = real (source_tab(i));
	}
    }
  
  const class Coulomb_potential_class Coulomb_potential(false , particle , Z_charge_basis_potential , NADA);
  
  const double dV_R = Coulomb_potential.point_potential_derivative_calc (R);

  class splines_class<complex<double> > &trivially_equivalent_potential = T.get_trivially_equivalent_potential ();

  class splines_class<complex<double> > &source = T.get_source ();

  trivially_equivalent_potential.deallocate ();
  
  source.deallocate ();

  trivially_equivalent_potential.allocate_calc (r_bef_R_tab_uniform , potential_tab , 0.0 , dV_R);
  
  source.allocate_calc (r_bef_R_tab_uniform , source_tab , 0.0 , 0.0);
}






// Calculation of the radial wave functions of a fixed HF/MSDHF/OCM state
// ----------------------------------------------------------------------
// The HF/MSDHF/OCM potential for a fixed iteration has been calculated in other routines, and one calculates the radial wave functions of one eigenstate. 
// HO scattering-like states are calculated directly. 
//
// For other states, the HF/MSDHF/OCM potential is either diagonalized in a HO basis, or the radial wave functions of one eigenstate are calculated by direct integration.
// In the latter case, its linear momentum is calculated first for the case of bound and resonant states and its radial wave functions afterwards.
// For HF/MSDHF, if one is close to convergence, i.e. if the HF test is smaller than 10^(-3), and the eigenstate was not a broad resonant state (one chooses -Im (k) < 0.05 . Re (k)),
// one uses the previous linear momentum as starting point for the new one as calculations are then faster. One always uses the previous linear momentum as starting point for the new one for l=0 in HF/MSDHF..
// But one never uses the previous linear momentum as starting point with the OCM potential. 
// Indeed, no HO basis diagonalization iterations are done therein before direct integration starts, so that dealing with the OCM potential is always more difficult during the first iterations. 
// Hence, it is preferred never to use the previous linear momentum as starting point with the OCM potential for stability.
//
// If the linear momentum of the eigenstate is small (one takes k < 0.1, which is about less than 300 keV), or if a bound state is complex due to numerical inaccuracy (appearance of complex equivalent potentials),
// One replaces all equivalent potentials and sources by their real parts, and the integration constants C0 and C+ by 1, i.e. C0 and C+ are reinitialized.
// It has been checked to be numerically stable and precise even for unbound states, as their imaginary is very small, so that the imaginary parts of equivalent potentials and sources can be neglected.
// If one had obtained a complex bound state, one can no longer use its previous linear momentum as starting point for the new one, so that the last shell is rejected and the new shell recalculated from the beginning.

void HF_wave_function::shell_calc (
				   const bool is_there_cout , 
				   const bool is_it_res , 
				   const bool HO_diag , 
				   const double b_lab , 
				   const class array<double> &V_Coulomb_tab_uniform , 
				   const unsigned int shell_index , 
				   class HF_nucleons_data &HF_data , 
				   class potentials_effective_mass &T , 
				   class array<class nlj_struct> &shells_qn , 
				   class array<class spherical_state> &shells)
{
  class nlj_struct &shell_qn = shells_qn(shell_index);
  
  class spherical_state &shell = shells(shell_index);

  const enum particle_type particle = HF_data.get_particle ();

  const enum potential_type H_potential = HF_data.get_H_potential ();

  const unsigned int N_bef_R_uniform = HF_data.get_N_bef_R_uniform ();

  const unsigned int N_bef_R_GL = HF_data.get_N_bef_R_GL ();

  const int A_basis = HF_data.get_A_basis ();

  const int Z_charge_basis_potential = HF_data.get_Z_charge_basis_potential ();
  
  const double R = HF_data.get_R ();

  class nlj_table<complex<double> > &Ueq_finite_range_averaged_tab_uniform = (is_it_res) ? (HF_data.get_Ueq_finite_range_res_averaged_tab_uniform ()) : (HF_data.get_Ueq_finite_range_averaged_tab_uniform ());  
  class nlj_table<complex<double> > &Ueq_finite_range_averaged_tab_GL      = (is_it_res) ? (HF_data.get_Ueq_finite_range_res_averaged_tab_GL      ()) : (HF_data.get_Ueq_finite_range_averaged_tab_GL      ());
  
  class nlj_table<complex<double> > &source_averaged_tab_uniform = (is_it_res) ? (HF_data.get_source_res_averaged_tab_uniform ()) : (HF_data.get_source_averaged_tab_uniform ());
  class nlj_table<complex<double> > &source_averaged_tab_GL      = (is_it_res) ? (HF_data.get_source_res_averaged_tab_GL      ()) : (HF_data.get_source_averaged_tab_GL      ());

  class nlj_table<complex<double> > &Ueq_finite_range_tab_uniform = (is_it_res) ? (HF_data.get_Ueq_finite_range_res_tab_uniform ()) : (HF_data.get_Ueq_finite_range_tab_uniform ());
  class nlj_table<complex<double> > &Ueq_finite_range_tab_GL      = (is_it_res) ? (HF_data.get_Ueq_finite_range_res_tab_GL      ()) : (HF_data.get_Ueq_finite_range_tab_GL      ());
  
  class nlj_table<complex<double> > &source_tab_uniform = (is_it_res) ? (HF_data.get_source_res_tab_uniform ()) : (HF_data.get_source_tab_uniform ());
  class nlj_table<complex<double> > &source_tab_GL      = (is_it_res) ? (HF_data.get_source_res_tab_GL      ()) : (HF_data.get_source_tab_GL      ());

  const int n = shell_qn.get_n ();
  const int l = shell_qn.get_l ();

  const double j = shell_qn.get_j ();

  const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();
  
  const bool is_it_HO = shell_qn.get_is_it_HO ();

  const complex<double> w = shell_qn.get_w ();

  if (!S_matrix_pole && is_it_HO) shell.HO_wave_function (b_lab);

  if (S_matrix_pole && !HO_diag)
    {      
      shell.k_search (T , true , is_there_cout); 

      const complex<double> k = shell.get_k ();

      const bool is_k_small = (inf_norm (k) < 0.1);
      
      const bool is_k_bound_not_real = ((abs (real (k)) > precision) && (imag (k) > 1E-3));
      
      if (!is_it_complex_WS_potential_determine (H_potential) && (is_k_small || is_k_bound_not_real))
	{  
	  trivially_equivalent_potential_splines_realloc_calc (true , R , Z_charge_basis_potential , particle , Ueq_finite_range_averaged_tab_uniform , source_averaged_tab_uniform , V_Coulomb_tab_uniform , n , l , j , T);

	  if (abs (imag (shell.get_C0    ())) > precision) shell.set_C0    (1.0);
	  if (abs (imag (shell.get_Cplus ())) > precision) shell.set_Cplus (1.0);

	  if (is_k_bound_not_real) shell.reject ();
	  
	  shell.k_search (T , true , is_there_cout);

	  const unsigned int zero_index_uniform = Ueq_finite_range_tab_uniform.index_determine (n , l , j , 0);
	  
	  const unsigned int zero_index_GL = Ueq_finite_range_tab_GL.index_determine  (n , l , j , 0);

	  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	    {
	      const unsigned int index_uniform = zero_index_uniform + i;

	      Ueq_finite_range_tab_uniform[index_uniform] = real (Ueq_finite_range_tab_uniform[index_uniform]);

	      source_tab_uniform[index_uniform] = real (source_tab_uniform[index_uniform]);
	      
	      Ueq_finite_range_averaged_tab_uniform[index_uniform] = real (Ueq_finite_range_averaged_tab_uniform[index_uniform]);

	      source_averaged_tab_uniform[index_uniform] = real (source_averaged_tab_uniform[index_uniform]);
	    }

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	    {
	      const unsigned int index_GL = zero_index_GL + i;

	      Ueq_finite_range_tab_GL[index_GL] = real (Ueq_finite_range_tab_GL[index_GL]);

	      source_tab_GL[index_GL] = real (source_tab_GL[index_GL]);
	      
	      Ueq_finite_range_averaged_tab_GL[index_GL] = real (Ueq_finite_range_averaged_tab_GL[index_GL]);

	      source_averaged_tab_GL[index_GL] = real (source_averaged_tab_GL[index_GL]);
	    }
	}
    }

  if (S_matrix_pole)
    { 
      if (HO_diag)
	{
	  const double b_HO_for_diag = pow (static_cast<double> (A_basis) , 0.1666666666666667);
	  
	  shell.wave_calculation_HO_diag (T , b_HO_for_diag);
	}
      else
	{
	  shell.wave_calculation (is_there_cout , T , true);
	  
	  state_rejection_test (shells_qn , shell_index , shells);
	}
      
      if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout && HO_diag)
	{
	  const complex<double> E = shell.get_E ();

#ifdef UseOpenMP
#pragma omp critical 
#endif
	  cout << shell << " " << particle << " E:" << real (E) << " MeV " << endl;
	}
    }
  else if (!is_it_HO)
    {
      shell.wave_calculation (is_there_cout , T , false);

      shell.normalization (sqrt (w));
    }
}









// Calculation of the radial wave functions of all HF/MSDHF/OCM states of proton or neutron character
// --------------------------------------------------------------------------------------------------
// The HF/MSDHF/OCM potential for a fixed iteration has been calculated in other routines, and one calculates the radial wave functions of one eigenstate. 
// HO scattering-like states are calculated directly. 
//
// If the HF/MSDHF potential is diagonalized in a HO basis, one only calculates bound or resonant (then approximated by states) states with it.
// It is sufficient to obtain a very good starting point of the HF/MSDHF potential for direct integration.
//
// A state demanded to be a natural orbital is never calculated. This can happen only for scattering-like states, so that it does not impact the calculations of HF/MSDHF potentials.
//
// The number of nucleons one can put in all calculated bound and resonant states is calculated. 
// If it is smaller than the total number of nucleons of the basis nucleus of optimized with HF/MSDHF, the code stops.
//
// All MPI processes calculate poles and MPI processes calculate only a part of scattering states each.

void HF_wave_function::all_shells_alloc_calc (
					      const class interaction_class &inter_data_basis , 
					      const bool is_there_cout , 
					      const bool is_it_res , 
					      const bool HO_diag , 
					      const double test , 
					      const class array<double> &V_Coulomb_tab_uniform , 
					      class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj_res = HF_data.get_N_nlj_res ();

  const unsigned int N_nlj = (is_it_res) ? (N_nlj_res) : (HF_data.get_N_nlj ());

  if (N_nlj == 0) return;

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
  
  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);

  const enum particle_type particle = HF_data.get_particle ();
  
  const unsigned int N_bef_R_GL = HF_data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = HF_data.get_N_aft_R_GL ();
  
  const unsigned int N_bef_R_uniform = HF_data.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = HF_data.get_N_aft_R_uniform ();

  const unsigned int N_valence_nucleons_basis = HF_data.get_N_valence_nucleons_basis ();

  const int A_basis = HF_data.get_A_basis ();
  
  const int Z_charge_basis_potential = HF_data.get_Z_charge_basis_potential ();
  
  const double R = HF_data.get_R ();

  const double R_real_max = HF_data.get_R_real_max ();

  const double nucleus_mass_basis = HF_data.get_nucleus_mass_basis ();

  const double nucleon_mass_for_calc = HF_data.get_nucleon_mass_for_calc ();

  const double mass_modif = (!is_it_COSM) ? (-nucleus_mass_basis) : (nucleus_mass_basis);
  
  const class lj_table<double> &b_lab_partial_waves = HF_data.get_b_lab_partial_waves ();

  const bool is_it_OCM_basis = HF_data.get_is_it_OCM_basis ();

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const class array<double> &R0_tab = HF_data.get_R0_tab ();

  const class nlj_table<complex<double> > &Ueq_finite_range_averaged_tab_uniform = (is_it_res) ? (HF_data.get_Ueq_finite_range_res_averaged_tab_uniform ()) : (HF_data.get_Ueq_finite_range_averaged_tab_uniform ());

  const class nlj_table<complex<double> > &source_averaged_tab_uniform = (is_it_res) ? (HF_data.get_source_res_averaged_tab_uniform ()) : (HF_data.get_source_averaged_tab_uniform ());

  if (!is_it_OCM_basis && is_there_cout && (THIS_PROCESS == MASTER_PROCESS) &&  is_it_res) cout << endl << "Pole one-" << particle << " shells to generate HF/MSDHF potentials" << endl; 
  if (!is_it_OCM_basis && is_there_cout && (THIS_PROCESS == MASTER_PROCESS) && !is_it_res) cout << endl << "One-"      << particle << " HF/MSDHF shells" << endl; 

  class array<class nlj_struct> &shells_qn = (is_it_res) ? (HF_data.get_shells_quantum_numbers_res ()) : (HF_data.get_shells_quantum_numbers ());
  
  class array<class spherical_state> &shells = (is_it_res) ? (HF_data.get_shells_res ()) : (HF_data.get_shells ());

  const unsigned int first_state = basic_first_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_state = basic_last_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  unsigned int available_nucleon_states = 0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) reduction(+:available_nucleon_states)
#endif
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      class nlj_struct &shell_qn = shells_qn(s);
      
      const enum particle_type particle = shell_qn.get_particle ();

      const int strangeness = particle_strangeness_determine (particle);

      if (strangeness != 0) continue;
      
      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();
      
      const double j = shell_qn.get_j ();

      const double R0 = R0_tab(0 , l);
      
      const double R0_inter = inter_data_basis.get_R0 ();

      const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);
	  
      const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

      const bool hole_state = shell_qn.get_hole_state ();

      if (hole_state && is_it_res) available_nucleon_states += shell_qn.m_number_determine ();

      const bool core_state = shell_qn.get_core_state ();

      if (core_state) continue;

      const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ();

      const bool is_shell_meaningful = (S_matrix_pole || !HO_diag);

      class spherical_state &shell = shells(s);
      	      
      if (is_shell_meaningful)
	{
	  const complex<double> k = shell_qn.get_k ();

	  const complex<double> C0 = shell_qn.get_C0 ();

	  const complex<double> Cplus = shell_qn.get_Cplus ();
	  
	  const bool is_k_narrow = (-imag (k) < 0.05*real (k));

	  const bool automatic_starting_point = !(((l == 0) || ((test > 1E-3) && is_k_narrow)) && !is_it_OCM_basis);
	  
	  if (!shell.is_it_filled ())
	    shell.allocate (false , true , HF , A_basis , Z_charge_basis_potential , mass_modif , NADA , N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , 0 , 0 ,
			    R , NADA , R0_matching_point , R_real_max , 0.0 , 0.0 , S_matrix_pole , particle , n , NADA , l , j , automatic_starting_point , k , nucleon_mass_for_calc , C0 , Cplus);

	  if (S_matrix_pole || ((s >= first_state) && (s <= last_state)))
	    {
	      class potentials_effective_mass T;

	      T.initialize_constants (
				      shell.get_potential () ,
				      shell.get_kinetic_factor () ,
				      shell.get_jr () ,
				      shell.get_l () ,
				      shell.get_ZY_charge () ,
				      shell.get_j () ,
				      shell.get_k () ,
				      shell.get_eta () ,
				      NADA);

	      trivially_equivalent_potential_splines_realloc_calc (false , R , Z_charge_basis_potential , particle , Ueq_finite_range_averaged_tab_uniform , source_averaged_tab_uniform , V_Coulomb_tab_uniform , n , l , j , T);
	      
	      if (!is_it_natural_orbital)
		{
		  const double b_lab = b_lab_partial_waves(l , j);

		  shell_calc (is_there_cout , false , HO_diag , b_lab , V_Coulomb_tab_uniform , s , HF_data , T , shells_qn , shells);
		}
	            
	      const complex<double> C0 = shell.get_C0 ();

	      const complex<double> Cplus = shell.get_Cplus ();
      
	      if (!shell.get_is_k_OK ()) shell.reject ();

	      const complex<double> k = (S_matrix_pole) ? (shell.get_k ()) : (shell_qn.get_k ());

	      if ((!is_it_OCM_basis) && shell.get_is_k_OK () && is_it_res) available_nucleon_states += shell_qn.m_number_determine ();

	      shell_qn.initialize (
				   shell_qn.get_S_matrix_pole () ,
				   shell_qn.get_core_state () ,
				   shell_qn.get_frozen_state () ,
				   shell_qn.get_hole_state () ,
				   shell_qn.get_OCM_valence_state () ,
				   shell_qn.get_is_it_HO () ,
				   shell_qn.get_is_it_for_HF_gs () ,
				   shell_qn.get_is_it_natural_orbital () ,
				   shell_qn.get_particle () ,
				   shell_qn.get_e_trunc () ,
				   shell_qn.get_n () ,
				   shell_qn.get_l () ,
				   shell_qn.get_j () ,
				   shell_qn.get_segment () ,
				   k ,
				   shell_qn.get_w () ,
				   C0 ,
				   Cplus ,
				   shell_qn.get_k_plus () ,
				   shell_qn.get_C0_plus () ,
				   shell_qn.get_k_minus () ,
				   shell_qn.get_C0_minus ());
	      
	    }
	}
      else
	shell.deallocate ();
    }
  
  if (!is_it_OCM_basis && is_it_res)
    {
      if (available_nucleon_states < N_valence_nucleons_basis) 
	error_message_print_abort ("available states : " + make_string<unsigned int> (available_nucleon_states) + " " + make_string<enum particle_type> (particle) + "s : " + make_string<unsigned int> (N_valence_nucleons_basis));

      energy_sort (0 , N_nlj - 1 , shells , shells_qn);
      
      e_trunc_modify (N_valence_nucleons_basis , shells_qn);
    }
  else
    energy_sort (0 , N_nlj_res - 1 , shells , shells_qn);
}

void HF_wave_function::all_shells_pm_alloc_calc (
						 const int pm ,
						 const class interaction_class &inter_data_basis , 
						 const class array<double> &V_Coulomb_tab_uniform , 
						 class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj = HF_data.get_N_nlj ();
  
  if (N_nlj == 0) return;
  
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);

  const unsigned int N_bef_R_GL = HF_data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = HF_data.get_N_aft_R_GL ();

  const unsigned int N_bef_R_uniform = HF_data.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = HF_data.get_N_aft_R_uniform ();

  const int A_basis = HF_data.get_A_basis ();
  
  const int Z_charge_basis_potential = HF_data.get_Z_charge_basis_potential ();

  const double R = HF_data.get_R ();

  const double R_real_max = HF_data.get_R_real_max ();

  const double nucleus_mass_basis = HF_data.get_nucleus_mass_basis ();

  const double nucleon_mass_for_calc = HF_data.get_nucleon_mass_for_calc ();

  const double mass_modif = (!is_it_COSM) ? (-nucleus_mass_basis) : (nucleus_mass_basis);

  const bool is_it_OCM_basis = HF_data.get_is_it_OCM_basis ();

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const class array<double> &R0_tab = HF_data.get_R0_tab ();

  const class nlj_table<complex<double> > &Ueq_finite_range_pm_averaged_tab_uniform = (pm == 1) ? (HF_data.get_Ueq_finite_range_plus_averaged_tab_uniform ()) : (HF_data.get_Ueq_finite_range_minus_averaged_tab_uniform ());
  
  const class nlj_table<complex<double> > &source_pm_averaged_tab_uniform = (pm == 1) ? (HF_data.get_source_plus_averaged_tab_uniform ()) : (HF_data.get_source_minus_averaged_tab_uniform ());

  class array<class nlj_struct> &shells_qn = HF_data.get_shells_quantum_numbers ();

  class array<class spherical_state> &shells_pm = (pm == 1) ? (HF_data.get_shells_plus ()) : (HF_data.get_shells_minus ());

  const unsigned int first_state = basic_first_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_state = basic_last_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      class nlj_struct &shell_qn = shells_qn(s);
      
      const enum particle_type particle = shell_qn.get_particle ();

      const int strangeness = particle_strangeness_determine (particle);

      if (strangeness != 0) continue;
      
      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();

      const double j = shell_qn.get_j ();

      const double R0 = R0_tab(0 , l);

      const double R0_inter = inter_data_basis.get_R0 ();

      const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);

      const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

      const bool is_it_HO = shell_qn.get_is_it_HO ();

      const bool OCM_valence_state = shell_qn.get_OCM_valence_state ();

      const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ();
      
      const complex<double> k_pm  = (pm == 1) ? (shell_qn.get_k_plus ())  : (shell_qn.get_k_minus ());
      const complex<double> C0_pm = (pm == 1) ? (shell_qn.get_C0_plus ()) : (shell_qn.get_C0_minus ());

      const bool is_shell_in_space_pm = !S_matrix_pole && !is_it_HO && (OCM_valence_state || !is_it_OCM_basis);

      class spherical_state &shell_pm = shells_pm(s);

      if (is_shell_in_space_pm)
	{	  
	  if (!shell_pm.is_it_filled ())
	    shell_pm.allocate (false , true , HF , A_basis , Z_charge_basis_potential , mass_modif , NADA , N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , 0 , 0 ,
			       R , NADA , R0_matching_point , R_real_max , 0.0 , 0.0 , S_matrix_pole , particle , n , NADA , l , j , false , k_pm , nucleon_mass_for_calc , C0_pm , NADA);  

	  if ((s >= first_state) && (s <= last_state))
	    {
	      const complex<double> w = shell_qn.get_w ();

	      const complex<double> sqrt_w = sqrt (w);

	      class potentials_effective_mass T;

	      T.initialize_constants (
				      shell_pm.get_potential () ,
				      shell_pm.get_kinetic_factor () ,
				      shell_pm.get_jr () ,
				      shell_pm.get_l () ,
				      shell_pm.get_ZY_charge () ,
				      shell_pm.get_j () ,
				      shell_pm.get_k () ,
				      shell_pm.get_eta () ,
				      NADA);

	      if (!is_it_natural_orbital)
		{
		  trivially_equivalent_potential_splines_realloc_calc (false , R , Z_charge_basis_potential , particle , Ueq_finite_range_pm_averaged_tab_uniform , source_pm_averaged_tab_uniform , V_Coulomb_tab_uniform , n , l , j , T);

		  shell_pm.wave_calculation (false , T , false);
		  
		  shell_pm.normalization (sqrt_w);
		}

	      const complex<double> C0_plus  = (pm == 1) ? (shell_pm.get_C0 ())       : (shell_qn.get_C0_plus ());
	      const complex<double> C0_minus = (pm == 1) ? (shell_qn.get_C0_minus ()) : (shell_pm.get_C0 ());
	      
	      shell_qn.initialize (shell_qn.get_S_matrix_pole () ,
				   shell_qn.get_core_state () ,
				   shell_qn.get_frozen_state () ,
				   shell_qn.get_hole_state () ,
				   shell_qn.get_OCM_valence_state () ,
				   shell_qn.get_is_it_HO () ,
				   shell_qn.get_is_it_for_HF_gs () ,
				   shell_qn.get_is_it_natural_orbital () ,
				   shell_qn.get_particle () ,
				   shell_qn.get_e_trunc () ,
				   shell_qn.get_n () ,
				   shell_qn.get_l () ,
				   shell_qn.get_j () ,
				   shell_qn.get_segment () ,
				   shell_qn.get_k () ,
				   shell_qn.get_w () ,
				   shell_qn.get_C0 () ,
				   shell_qn.get_Cplus () ,
				   shell_qn.get_k_plus () ,
				   C0_plus , 
				   shell_qn.get_k_minus () ,
				   C0_minus);
	    }
	}
      else
	shell_pm.deallocate ();
    }
}



// Deallocation of the structures containing one-body radial functions
// -------------------------------------------------------------------
// When one changes potential type or method to calculate one-body states,
// such as php potential diagonalization in all_shells_alloc_calc_from_php_matrices_diagonalization or HF/MSDHF/OCM diagonalization/direct integration at first iteration,
// one has to deallocate either bound/resonant wave functions, as they define the HF/MSDHF potentials, or all wave functions, as they will be reallocated afterwards.
// It is not done at every iteration, as then the method to calculate one-body states does not change.

void HF_wave_function::res_waves_deallocate (class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj = HF_data.get_N_nlj ();

  if (N_nlj == 0) return;

  class array<class spherical_state> &shells_res = HF_data.get_shells_res ();

  shells_res.deallocate_object_elements ();

  class array<class spherical_state> &shells = HF_data.get_shells ();

  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      class spherical_state &shell = shells(s);

      if (shell.get_S_matrix_pole ()) shell.deallocate ();
    }
}

void HF_wave_function::waves_deallocate (class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj = HF_data.get_N_nlj ();

  if (N_nlj == 0) return;

  class array<class spherical_state> &shells_res   = HF_data.get_shells_res ();
  class array<class spherical_state> &shells       = HF_data.get_shells ();
  class array<class spherical_state> &shells_plus  = HF_data.get_shells_plus ();
  class array<class spherical_state> &shells_minus = HF_data.get_shells_minus ();

  shells_res.deallocate_object_elements ();
  
  shells.deallocate_object_elements ();

  shells_plus.deallocate_object_elements ();

  shells_minus.deallocate_object_elements ();
}





// Calculation of the radial wave functions of all HF/MSDHF/OCM states
// -------------------------------------------------------------------
// Routines calculating core and valence HF/MSDHF/OCM radial wave functions are called here.
// The HF/MSDHF/OCM potential for a fixed iteration has been calculated in other routines, and one calculates radial wave functions.
// Hence, this routine is not used to initialize wave functions, equivalent potentials and sources. This is done in all_shells_alloc_calc_inter_init.
// Bound/resonant wave functions are always deallocated as they can build the HF/MSDHF potential, and their order can change as their energies varies at each iteration.
// Hence, it is the easiest to deallocate and reallocate them at each iteration. It is not expensive as they are in very small number.
// On the contrary, it would be expensive to deallocate and reallocate scattering states as well. As their energy is fixed, it is not necessary to deallocate and reallocate them anyway.
// If one uses COSM, core states are reallocated and recalculated as they had just been reallocated. Its numerical cost is negligible as one just has a few core states.
// Scattering states are reallocated only at first HF/MSDHF/OCM iteration, where it us necessary.
// Then, one calculates all bound, resonant and scattering states.
// Proton scattering states for which k +/- w/(4 Pi), pm is +/-1 for Coulomb complex scaling (see H_CM_OBMEs.cpp) are calculated if one does not use HO diagonalization of HF/MSDHF/OCM potentials.
// They are orthogonalized with respect to core states if COSM is used.

void HF_wave_function::wave_functions_calc (
					    const bool is_there_cout , 
					    const class interaction_class &inter_data_basis , 
					    const class baryons_data &prot_data , 
					    const class baryons_data &neut_data , 
					    const unsigned int iteration , 
					    const bool HO_diag ,
					    const double test ,
					    const class array<double> &V_Coulomb_tab_uniform , 
					    class HF_nucleons_data &prot_HF_data , 
					    class HF_nucleons_data &neut_HF_data)
{
  const bool good_isospin_basis_potential = prot_data.get_good_isospin_basis_potential ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
  
  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);

  const bool is_it_OCM_HO_core = prot_data.get_is_it_OCM_HO_core ();

  const int Zval_basis = prot_data.get_N_valence_nucleons_basis ();
  const int Nval_basis = neut_data.get_N_valence_nucleons_basis ();
  
  const int Z_core = prot_data.get_Z_core ();

  res_waves_deallocate (prot_HF_data);
  res_waves_deallocate (neut_HF_data);

  if (iteration == 1)
    {
      waves_deallocate (prot_HF_data);
      waves_deallocate (neut_HF_data);
    }
  
  if (is_it_COSM && (Zval_basis > 0)) OCM_core_states_realloc_calc (is_there_cout , true , is_it_OCM_HO_core , Z_core , inter_data_basis , prot_HF_data);
  if (is_it_COSM && (Nval_basis > 0)) OCM_core_states_realloc_calc (is_there_cout , true , is_it_OCM_HO_core , Z_core , inter_data_basis , neut_HF_data);

  if (is_it_COSM && (Zval_basis > 0)) OCM_core_states_realloc_calc (is_there_cout , false , is_it_OCM_HO_core , Z_core , inter_data_basis , prot_HF_data);
  if (is_it_COSM && (Nval_basis > 0)) OCM_core_states_realloc_calc (is_there_cout , false , is_it_OCM_HO_core , Z_core , inter_data_basis , neut_HF_data);

  all_shells_alloc_calc (inter_data_basis , is_there_cout , true , HO_diag , test , V_Coulomb_tab_uniform , prot_HF_data);
  all_shells_alloc_calc (inter_data_basis , is_there_cout , true , HO_diag , test , V_Coulomb_tab_uniform , neut_HF_data);
  
  all_shells_alloc_calc (inter_data_basis , is_there_cout , false , HO_diag , test , V_Coulomb_tab_uniform , prot_HF_data);
  all_shells_alloc_calc (inter_data_basis , is_there_cout , false , HO_diag , test , V_Coulomb_tab_uniform , neut_HF_data);
  
  if (is_it_COSM && (Zval_basis > 0)) HF_potentials_common::OCM_part_common::shells_OCM_core_states_overlaps_calc (prot_HF_data);
  if (is_it_COSM && (Nval_basis > 0)) HF_potentials_common::OCM_part_common::shells_OCM_core_states_overlaps_calc (neut_HF_data);

  shells_occupied_number_calc (prot_HF_data);
  shells_occupied_number_calc (neut_HF_data);
  
  if (!HO_diag)
    {
      class HF_nucleons_data &HF_data = (!good_isospin_basis_potential) ? (prot_HF_data) : (neut_HF_data);

      all_shells_pm_alloc_calc ( 1 , inter_data_basis , V_Coulomb_tab_uniform , HF_data);
      all_shells_pm_alloc_calc (-1 , inter_data_basis , V_Coulomb_tab_uniform , HF_data);

      all_shells_pm_orthogonalize ( 1 , HF_data);
      all_shells_pm_orthogonalize (-1 , HF_data);
    }

  if (is_it_COSM)
    {
      all_shells_orthogonalize (true  , prot_HF_data);
      all_shells_orthogonalize (false , prot_HF_data);

      all_shells_orthogonalize (true  , neut_HF_data);
      all_shells_orthogonalize (false , neut_HF_data);
    }
}









// Calculation of the convergence test of the HF/MSDHF and OCM self-consistent procedures
// --------------------------------------------------------------------------------------
// The convergence test is the difference of the linear momenta of calculated pole states with those of the previous iteration with HF/MSDHF.
// It is the maximal overlap with core states with OCM (see HF_wave_function::test_calc_k_update).
// The convergence test is calculated and the previous linear momenta of calculated pole states replaces by the new ones with HF/MSDHF.
// One distributes the largest test value to all nodes with MPI to avoid race conditions, as the code would behave differently from one node to the other.
// Information about the convergence test for the current iteration can be printed on screen.
  
double HF_wave_function::test_HF_MSDHF_k_update_part_calc (class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj_res = HF_data.get_N_nlj_res ();

  double test_HF_MSDHF_k_part = 0.0;

  if (N_nlj_res > 0)
    {
      const class array<class spherical_state> &shells_res = HF_data.get_shells_res ();

      class nlj_table<complex<double> > &k_bef_tab = HF_data.get_k_bef_tab ();

      for (unsigned int s = 0 ; s < N_nlj_res ; s++)
	{
	  const class spherical_state &shell_res = shells_res(s);

	  if (shell_res.is_it_filled ())
	    {
	      const int n = shell_res.get_n ();
	      const int l = shell_res.get_l ();

	      const double j = shell_res.get_j ();

	      const complex<double> k = shell_res.get_k ();

	      test_HF_MSDHF_k_part = max (test_HF_MSDHF_k_part , inf_norm (k_bef_tab(n , l , j) - k));

	      k_bef_tab(n , l , j) = k;
	    }
	}
    }

  return test_HF_MSDHF_k_part;
}

double HF_wave_function::test_OCM_part_calc (const class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj_res = HF_data.get_N_nlj_res ();
  const unsigned int N_nlj     = HF_data.get_N_nlj ();

  double test_OCM = 0.0;

  if (N_nlj > 0)
    {      
      const class lj_table<complex<double> > &shells_OCM_core_states_overlaps = HF_data.get_shells_OCM_core_states_overlaps ();
      
      const class array<class nlj_struct> &shells_qn_res = HF_data.get_shells_quantum_numbers_res ();
      const class array<class nlj_struct> &shells_qn     = HF_data.get_shells_quantum_numbers ();

      const unsigned int first_state = basic_first_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_state = basic_last_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

      for (unsigned int s = 0 ; s < N_nlj ; s++)
	{
	  class nlj_struct &shell_qn = shells_qn(s);

	  const enum particle_type particle = shell_qn.get_particle ();

	  const int strangeness = particle_strangeness_determine (particle);
      
	  if (strangeness != 0) continue;
      
	  const int n = shell_qn.get_n ();
	  const int l = shell_qn.get_l ();

	  const double j = shell_qn.get_j ();

	  const bool OCM_valence_state_s = shell_qn.get_OCM_valence_state ();
	  
	  if (OCM_valence_state_s)
	    {
	      const bool S_matrix_pole_s = shell_qn.get_S_matrix_pole ();

	      if (S_matrix_pole_s || ((s >= first_state) && (s <= last_state)))
		{
		  for (unsigned int t = 0 ; t < N_nlj_res ; t++)
		    {
		      const class nlj_struct &shell_OCM_possibly_core_qn = shells_qn_res(t);
		      
		      const bool core_state_t = shell_OCM_possibly_core_qn.get_core_state ();

		      if (core_state_t && same_lj_particle (shell_qn , shell_OCM_possibly_core_qn))
			{
			  const int n_core = shell_OCM_possibly_core_qn.get_n ();

			  const complex<double> overlap_OCM_core_shell = shells_OCM_core_states_overlaps(l , j , n , n_core);

			  const double inf_norm_overlap_OCM_core_shell = inf_norm (overlap_OCM_core_shell);

			  test_OCM = max (test_OCM , inf_norm_overlap_OCM_core_shell);
			}
		    }
		}
	    }
	}
    }

  return test_OCM;
}

double HF_wave_function::test_HF_MSDHF_k_update_calc (
						      class HF_nucleons_data &prot_HF_data , 
						      class HF_nucleons_data &neut_HF_data)
{
  const double test_HF_MSDHF_p_local = test_HF_MSDHF_k_update_part_calc (prot_HF_data);
  const double test_HF_MSDHF_n_local = test_HF_MSDHF_k_update_part_calc (neut_HF_data);
  
  const double test_HF_MSDHF_local = test_HF_MSDHF_p_local + test_HF_MSDHF_n_local;

  const double test_HF_MSDHF = max_Allreduce<double> (is_it_MPI_parallelized , test_HF_MSDHF_local);

  return test_HF_MSDHF;
}

double HF_wave_function::test_OCM_calc (
					const class HF_nucleons_data &prot_HF_data , 
					const class HF_nucleons_data &neut_HF_data)
{
  const double test_OCM_p_local = test_OCM_part_calc (prot_HF_data);
  const double test_OCM_n_local = test_OCM_part_calc (neut_HF_data);
  
  const double test_OCM_local = test_OCM_p_local + test_OCM_n_local;

  const double test_OCM = max_Allreduce<double> (is_it_MPI_parallelized , test_OCM_local);

  return test_OCM;
}

double HF_wave_function::test_calc_k_update (
					     const bool is_there_cout ,
					     const bool print_detailed_information ,
					     const bool is_it_HO ,
					     const unsigned int iteration ,
					     class HF_nucleons_data &prot_HF_data , 
					     class HF_nucleons_data &neut_HF_data)
{
  const bool is_it_OCM_basis = prot_HF_data.get_is_it_OCM_basis ();

  const double test = (is_it_OCM_basis) ? (test_OCM_calc (prot_HF_data , neut_HF_data)) : (test_HF_MSDHF_k_update_calc (prot_HF_data , neut_HF_data));

  const string HO_Berggren_str = (is_it_HO) ? ("(HO)") : ("(Berggren)");
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      if (!print_detailed_information && (iteration == 1)) cout << endl;
      
      if (print_detailed_information)
	cout << endl << endl << "Iteration:" << iteration << " test:" << test << " " << HO_Berggren_str << endl << endl;
      else
	cout << "Iteration:" << iteration << " test:" << test << " " << HO_Berggren_str << endl;
    }
  
  return test;
}








#ifdef UseMPI

// MPI distribution of one-body radial wave functions
// --------------------------------------------------
// One distributes calculated proton or neutron radial wave functions to all nodes.
// Indeed, only a part of all scattering states are calculated in one node, which have to be distributed to all other nodes afterwards.

void HF_wave_function::shells_MPI_transfer (
					    class HF_nucleons_data &HF_data ,
					    const MPI_Comm MPI_C)
{
  const unsigned int N_nlj = HF_data.get_N_nlj ();
  
  class array<class spherical_state> &shells = HF_data.get_shells ();
  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      class spherical_state &shell = shells(s);
      
      if (shell.is_it_filled ())
	{
	  const unsigned int sending_process = basic_active_process_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , s);
	  
	  shell.MPI_Bcast (sending_process , MPI_C);
	}
    }  
}

#endif



