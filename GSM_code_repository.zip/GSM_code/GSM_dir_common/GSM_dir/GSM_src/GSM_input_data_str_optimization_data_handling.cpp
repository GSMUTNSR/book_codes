#include "../GSM_include/GSM_include_def_common.h"


using namespace inputs_misc;
using namespace string_routines;


// TYPE is double or complex
// -------------------------

// See input_data_str.h for information about its data. Routines here are for the GSM optimization code only. They are rather straightforward so that no details are provided, only general explanations.
// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------



// WS and FHT/EFT parameters of input arrays are copied to input_data_str here when using the GSM optimization code.

void input_data_str::set_FHT_EFT_parameters (
					     const bool is_it_only_basis , 
					     const class array<class input_data_str> &input_data_tab ,
					     const class vector_class<double> &FHT_EFT_parameters)
{
  set_FHT_EFT_interaction_parameters (FHT_EFT_parameters);

  set_FHT_EFT_WS_parameters (is_it_only_basis , input_data_tab , FHT_EFT_parameters);
}









// One calculates here the number of parameters to fit in the GSM optimization code.
// If a two-body parameter or a WS core potential parameter independent of partial waves must be fitted, one is added.
// If a WS core potential parameter is dependent of partial wave, lmax+1 is added (lmax_p for proton, lmax_n for neutrons), as this parameter can be taken from an array of lmax+1 terms, one for each orbital angular momentum.

unsigned int input_data_str::N_parameters_to_fit_calc () const
{
  unsigned int N_parameters_to_fit = 0;

  if (is_dp_fitted)
    {
      if (same_dp_all_lj)
	N_parameters_to_fit++;
      else
	N_parameters_to_fit += lmax_p+1;
    }

  if (is_R0_p_fitted)
    {
      if (same_R0_p_all_lj)
	N_parameters_to_fit++;
      else
	N_parameters_to_fit += lmax_p+1;
    }

  if (is_Vo_p_fitted)
    {
      if (same_Vo_p_all_lj)
	N_parameters_to_fit++;
      else
	N_parameters_to_fit += lmax_p+1;
    }

  if (is_Vso_p_fitted)
    {
      if (same_Vso_p_all_lj)
	N_parameters_to_fit++;
      else
	N_parameters_to_fit += lmax_p;
    }

  if (is_R_charge_fitted)
    N_parameters_to_fit++;

  if (is_dn_fitted)
    {
      if (same_dn_all_lj)
	N_parameters_to_fit++;
      else
	N_parameters_to_fit += lmax_n+1;
    }

  if (is_R0_n_fitted)
    {
      if (same_R0_n_all_lj)
	N_parameters_to_fit++;
      else
	N_parameters_to_fit += lmax_n+1;
    }

  if (is_Vo_n_fitted)
    {
      if (same_Vo_n_all_lj)
	N_parameters_to_fit++;
      else
	N_parameters_to_fit += lmax_n+1;
    }

  if (is_Vso_n_fitted)
    {
      if (same_Vso_n_all_lj)
	N_parameters_to_fit++;
      else
	N_parameters_to_fit += lmax_n;
    }

  if (is_it_FHT_determine (inter))
    {
      if (is_V0_ctr_ot_S1_T1_fitted) N_parameters_to_fit++;
      if (is_V0_ctr_et_S1_T0_fitted) N_parameters_to_fit++;
      if (is_V0_ctr_os_S0_T0_fitted) N_parameters_to_fit++;
      if (is_V0_ctr_es_S0_T1_fitted) N_parameters_to_fit++;
      if (is_V0_so_ot_S1_T1_fitted)  N_parameters_to_fit++;
      if (is_V0_so_et_S1_T0_fitted)  N_parameters_to_fit++;
      if (is_V0_t_ot_S1_T1_fitted)   N_parameters_to_fit++;
      if (is_V0_t_et_S1_T0_fitted)   N_parameters_to_fit++;
    }
  
  if (is_it_EFT_determine (inter))
    {
      if (is_VS_const_LO_T0_fitted)          N_parameters_to_fit++;
      if (is_VS_const_LO_T1_fitted)          N_parameters_to_fit++;
      if (is_VT_sigma_product_LO_T0_fitted)          N_parameters_to_fit++;
      if (is_VT_sigma_product_LO_T1_fitted)          N_parameters_to_fit++;
      if (is_V1_q2_NLO_fitted)               N_parameters_to_fit++;
      if (is_V2_k2_NLO_fitted)               N_parameters_to_fit++;
      if (is_V3_q2_sigma_product_NLO_fitted) N_parameters_to_fit++;
      if (is_V4_k2_sigma_product_NLO_fitted) N_parameters_to_fit++;
      if (is_V5_sigma_q_vector_k_NLO_fitted) N_parameters_to_fit++;
      if (is_V6_sigma_q_product_NLO_fitted)  N_parameters_to_fit++;
      if (is_V7_sigma_k_product_NLO_fitted)  N_parameters_to_fit++;
    }
  
  return N_parameters_to_fit;
}










// In arrays FHT_EFT_parameters_from_fit_index, l_from_fit_index, is_there_l_dependence_from_fit_index, 
// one puts the name of the FHT/EFT parameter if it is fitted, its orbital angular momentum in case it depends on partial wave and if it depends or not on orbital angular momentum, hence on partial wave.
// Fit indices are defined by increasing an index unit by unit everytime a given FHT/EFT parameter is fitted by looping on all of them.

void input_data_str::fit_indices_tables_calc (
					      class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
					      class array<bool> &is_there_l_dependence_from_fit_index , 
					      class array<int> &l_from_fit_index) const
{
  unsigned int fit_index = 0;

  is_there_l_dependence_from_fit_index = false;

  l_from_fit_index = 0;

  if (is_dp_fitted)
    {
      if (same_dp_all_lj)
	FHT_EFT_parameters_from_fit_index(fit_index++) = CORE_D_PROTON;
      else
	{
	  for (int l = 0 ; l <= lmax_p ; l++)
	    {
	      FHT_EFT_parameters_from_fit_index(fit_index) = CORE_D_PROTON;
	      
	      l_from_fit_index(fit_index) = l;

	      is_there_l_dependence_from_fit_index(fit_index) = true;

	      fit_index++;
	    }
	}
    }

  if (is_R0_p_fitted)
    {
      if (same_R0_p_all_lj)
	FHT_EFT_parameters_from_fit_index(fit_index++) = CORE_R0_PROTON;
      else
	{
	  for (int l = 0 ; l <= lmax_p ; l++)
	    {
	      FHT_EFT_parameters_from_fit_index(fit_index) = CORE_R0_PROTON;

	      l_from_fit_index(fit_index) = l;

	      is_there_l_dependence_from_fit_index(fit_index) = true;

	      fit_index++;
	    }
	}
    }

  if (is_Vo_p_fitted)
    {
      if (same_Vo_p_all_lj)
	FHT_EFT_parameters_from_fit_index(fit_index++) = CORE_VO_PROTON;
      else
	{
	  for (int l = 0 ; l <= lmax_p ; l++)
	    {
	      FHT_EFT_parameters_from_fit_index(fit_index) = CORE_VO_PROTON;

	      l_from_fit_index(fit_index) = l;

	      is_there_l_dependence_from_fit_index(fit_index) = true;

	      fit_index++;
	    }
	}
    }

  if (is_Vso_p_fitted)
    {
      if (same_Vso_p_all_lj)
	FHT_EFT_parameters_from_fit_index(fit_index++) = CORE_VSO_PROTON;
      else
	{
	  for (int l = 1 ; l <= lmax_p ; l++)
	    {
	      FHT_EFT_parameters_from_fit_index(fit_index) = CORE_VSO_PROTON;

	      l_from_fit_index(fit_index) = l;

	      is_there_l_dependence_from_fit_index(fit_index) = true;

	      fit_index++;
	    }
	}
    }

  if (is_R_charge_fitted)
    FHT_EFT_parameters_from_fit_index(fit_index++) = CORE_R_CHARGE_PROTON;

  if (is_dn_fitted)
    {
      if (same_dn_all_lj)
	FHT_EFT_parameters_from_fit_index(fit_index++) = CORE_D_NEUTRON;
      else
	{
	  for (int l = 0 ; l <= lmax_n ; l++)
	    {
	      FHT_EFT_parameters_from_fit_index(fit_index) = CORE_D_NEUTRON;

	      l_from_fit_index(fit_index) = l;

	      is_there_l_dependence_from_fit_index(fit_index) = true;

	      fit_index++;
	    }
	}
    }

  if (is_R0_n_fitted)
    {
      if (same_R0_n_all_lj)
	FHT_EFT_parameters_from_fit_index(fit_index++) = CORE_R0_NEUTRON;
      else
	{
	  for (int l = 0 ; l <= lmax_n ; l++)
	    {
	      FHT_EFT_parameters_from_fit_index(fit_index) = CORE_R0_NEUTRON;

	      l_from_fit_index(fit_index) = l;

	      is_there_l_dependence_from_fit_index(fit_index) = true;

	      fit_index++;
	    }
	}
    }

  if (is_Vo_n_fitted)
    {
      if (same_Vo_n_all_lj)
	FHT_EFT_parameters_from_fit_index(fit_index++) = CORE_VO_NEUTRON;
      else
	{
	  for (int l = 0 ; l <= lmax_n ; l++)
	    {
	      FHT_EFT_parameters_from_fit_index(fit_index) = CORE_VO_NEUTRON;

	      l_from_fit_index(fit_index) = l;

	      is_there_l_dependence_from_fit_index(fit_index) = true;

	      fit_index++;
	    }
	}
    }

  if (is_Vso_n_fitted)
    {
      if (same_Vso_n_all_lj)
	FHT_EFT_parameters_from_fit_index(fit_index++) = CORE_VSO_NEUTRON;
      else
	{
	  for (int l = 1 ; l <= lmax_n ; l++)
	    {
	      FHT_EFT_parameters_from_fit_index(fit_index) = CORE_VSO_NEUTRON;

	      l_from_fit_index(fit_index) = l;

	      is_there_l_dependence_from_fit_index(fit_index) = true;

	      fit_index++;
	    }
	}
    }

  
  if (is_it_FHT_determine (inter))
    {
      if (is_V0_ctr_ot_S1_T1_fitted) FHT_EFT_parameters_from_fit_index(fit_index++) = V0_CTR_OT_S1_T1;
      if (is_V0_ctr_et_S1_T0_fitted) FHT_EFT_parameters_from_fit_index(fit_index++) = V0_CTR_ET_S1_T0;
      if (is_V0_ctr_os_S0_T0_fitted) FHT_EFT_parameters_from_fit_index(fit_index++) = V0_CTR_OS_S0_T0;
      if (is_V0_ctr_es_S0_T1_fitted) FHT_EFT_parameters_from_fit_index(fit_index++) = V0_CTR_ES_S0_T1;      
      if (is_V0_so_ot_S1_T1_fitted)  FHT_EFT_parameters_from_fit_index(fit_index++) = V0_SO_OT_S1_T1;
      if (is_V0_so_et_S1_T0_fitted)  FHT_EFT_parameters_from_fit_index(fit_index++) = V0_SO_ET_S1_T0;      
      if (is_V0_t_ot_S1_T1_fitted)   FHT_EFT_parameters_from_fit_index(fit_index++) = V0_T_OT_S1_T1;
      if (is_V0_t_et_S1_T0_fitted)   FHT_EFT_parameters_from_fit_index(fit_index++) = V0_T_ET_S1_T0;
    }
  
  if (is_it_EFT_determine (inter))
    {
      if (is_VS_const_LO_T0_fitted)          FHT_EFT_parameters_from_fit_index(fit_index++) = VS_LO_T0;
      if (is_VS_const_LO_T1_fitted)          FHT_EFT_parameters_from_fit_index(fit_index++) = VS_LO_T1;
      if (is_VT_sigma_product_LO_T0_fitted)  FHT_EFT_parameters_from_fit_index(fit_index++) = VT_SIGMA_PRODUCT_LO_T0;
      if (is_VT_sigma_product_LO_T1_fitted)  FHT_EFT_parameters_from_fit_index(fit_index++) = VT_SIGMA_PRODUCT_LO_T1;
      if (is_V1_q2_NLO_fitted)               FHT_EFT_parameters_from_fit_index(fit_index++) = V1_Q2_NLO;
      if (is_V2_k2_NLO_fitted)               FHT_EFT_parameters_from_fit_index(fit_index++) = V2_K2_NLO;
      if (is_V3_q2_sigma_product_NLO_fitted) FHT_EFT_parameters_from_fit_index(fit_index++) = V3_Q2_SIGMA_PRODUCT_NLO;
      if (is_V4_k2_sigma_product_NLO_fitted) FHT_EFT_parameters_from_fit_index(fit_index++) = V4_K2_SIGMA_PRODUCT_NLO;
      if (is_V5_sigma_q_vector_k_NLO_fitted) FHT_EFT_parameters_from_fit_index(fit_index++) = V5_SIGMA_Q_VECTOR_K_NLO;
      if (is_V6_sigma_q_product_NLO_fitted)  FHT_EFT_parameters_from_fit_index(fit_index++) = V6_SIGMA_Q_PRODUCT_NLO;
      if (is_V7_sigma_k_product_NLO_fitted)  FHT_EFT_parameters_from_fit_index(fit_index++) = V7_SIGMA_K_PRODUCT_NLO;
    }
}













// If one demands WS core potential parameters to be independent of partial waves, it has to be the case as well for its input parameters in the input file, as they are given for all partial waves.
// It is checked here, and the code stops if it is not the case.

void input_data_str::same_partial_wave_values_check () const
{
  if (is_dp_fitted)
    {
      if (same_dp_all_lj)
	{
	  const double dp_check = prot_d_core_potential_tab(0);
	  
	  for (int l = 1 ; l <= lmax_p ; l++)
	    {
	      if (abs (prot_d_core_potential_tab(l) - dp_check) > precision)
		error_message_print_abort ("Proton diffusenesses (d) are not the same for all partial waves");
	    }
	}
    }
  
  if (is_R0_p_fitted)
    {
      if (same_R0_p_all_lj)
	{
	  const double R0_p_check = prot_R0_core_potential_tab(0);
	  
	  for (int l = 1 ; l <= lmax_p ; l++)
	    {
	      if (abs (prot_R0_core_potential_tab(l) - R0_p_check) > precision)
		error_message_print_abort ("Proton radii (R0) are not the same for all partial waves");
	    }
	}
    }

  if (is_Vo_p_fitted)
    {
      if (same_Vo_p_all_lj)
	{
	  const double Vo_p_check = prot_Vo_core_potential_tab(0);
	  
	  for (int l = 1 ; l <= lmax_p ; l++)
	    {
	      if (abs (prot_Vo_core_potential_tab(l) - Vo_p_check) > precision)
		error_message_print_abort ("Proton central potential strengths (Vo) are not the same for all partial waves");
	    }
	}
    }

  if (is_Vso_p_fitted && (lmax_p >= 1))
    {
      if (same_Vso_p_all_lj)
	{
	  const double Vso_p_check = prot_Vso_core_potential_tab(1);
	  
	  for (int l = 1 ; l <= lmax_p ; l++)
	    {
	      if (abs (prot_Vso_core_potential_tab(l) - Vso_p_check) > precision)
		error_message_print_abort ("Proton spin-orbit potential strengths (Vso) are not the same for all partial waves");
	    }
	}
    }

  if (is_dn_fitted)
    {
      if (same_dn_all_lj)
	{
	  const double dn_check = neut_d_core_potential_tab(0);
	  
	  for (int l = 1 ; l <= lmax_n ; l++)
	    {
	      if (abs (neut_d_core_potential_tab(l) - dn_check) > precision)
		error_message_print_abort ("Neutron diffusenesses (d) are not the same for all partial waves");
	    }
	}
    }
  
  if (is_R0_n_fitted)
    {
      if (same_R0_n_all_lj)
	{
	  const double R0_n_check = neut_R0_core_potential_tab(0);
	  
	  for (int l = 1 ; l <= lmax_n ; l++)
	    {
	      if (abs (neut_R0_core_potential_tab(l) - R0_n_check) > precision)
		error_message_print_abort ("Neutron radii (R0) are not the same for all partial waves");
	    }
	}
    }

  if (is_Vo_n_fitted)
    {
      if (same_Vo_n_all_lj)
	{
	  const double Vo_n_check = neut_Vo_core_potential_tab(0);
	  
	  for (int l = 1 ; l <= lmax_n ; l++)
	    {
	      if (abs (neut_Vo_core_potential_tab(l) - Vo_n_check) > precision)
		error_message_print_abort ("Neutron central potential strengths (Vo) are not the same for all partial waves");
	    }
	}
    }

  if (is_Vso_n_fitted && (lmax_n >= 1))
    {
      if (same_Vso_n_all_lj)
	{
	  const double Vso_n_check = neut_Vso_core_potential_tab(1);
	  
	  for (int l = 1 ; l <= lmax_n ; l++)
	    {
	      if (abs (neut_Vso_core_potential_tab(l) - Vso_n_check) > precision)
		error_message_print_abort ("Neutron spin-orbit potential strengths (Vso) are not the same for all partial waves");
	    }
	}
    }
}



