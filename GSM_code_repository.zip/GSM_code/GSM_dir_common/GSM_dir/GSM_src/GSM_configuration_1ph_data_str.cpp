#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Class configuration_1ph_data_str
// --------------------------------
// class configuration_1ph_data_str stores information related to the obtained configuration after the action of a+_{alpha} (1p) or a_{alpha} (1h) on a Slater determinant.
// It contains its number of particles in the continuum, its index with fixed parity, and the index of the shell of the state alpha borne by a+_{alpha} or a_{alpha}.

configuration_1ph_data_str::configuration_1ph_data_str ()
  : n_scat (0) , 
    iC (0) , 
    shell_index (0) 
{}

configuration_1ph_data_str::configuration_1ph_data_str (
							const unsigned int n_scat_c , 
							const unsigned int iC_c , 
							const unsigned int shell_index_c)
{
  initialize (n_scat_c , iC_c , shell_index_c);
}

void configuration_1ph_data_str::initialize (
					     const unsigned int n_scat_c , 
					     const unsigned int iC_c , 
					     const unsigned int shell_index_c)
{
  n_scat = n_scat_c;
  
  iC = iC_c;

  shell_index = shell_index_c;  
}

void configuration_1ph_data_str::initialize (const class configuration_1ph_data_str &X)
{
  n_scat = X.n_scat; 

  iC = X.iC;

  shell_index = X.shell_index;
}
   
void configuration_1ph_data_str::allocate_fill (const class configuration_1ph_data_str &X)
{
  initialize (X);
}

double used_memory_calc (const class configuration_1ph_data_str &T)
{
  return sizeof (T)/1000000.0;
}
