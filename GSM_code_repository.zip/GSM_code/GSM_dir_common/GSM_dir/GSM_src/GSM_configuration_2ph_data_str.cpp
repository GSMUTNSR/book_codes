#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Array class type to store an array of class configuration_2ph_data_str
// ----------------------------------------------------------------------
// class configuration_2ph_data_str stores information related to the obtained configuration after the action of a+_{alpha} a+_{beta} (2p) or a_{alpha} a_{beta} (2h) on a Slater determinant.
// It contains its number of particles in the continuum, its index with fixed parity, and the indices of the shells borne by a+_{alpha} a+_{beta} or a_{alpha} a_{beta}. One must have alpha <= beta.

configuration_2ph_data_str::configuration_2ph_data_str ()
  : n_scat (0) , 
    iC (0) , 
    shell_left_index (0) ,
    shell_right_index (0) 
{}

configuration_2ph_data_str::configuration_2ph_data_str (
							const unsigned int n_scat_c ,
							const unsigned int iC_c , 
							const unsigned int shell_left_index_c ,
							const unsigned int shell_right_index_c)
{
  initialize (n_scat_c , iC_c , shell_left_index_c , shell_right_index_c);
}

void configuration_2ph_data_str::initialize (
					     const unsigned int n_scat_c , 
					     const unsigned int iC_c , 
					     const unsigned int shell_left_index_c , 
					     const unsigned int shell_right_index_c)
{
  n_scat = n_scat_c;
  
  iC = iC_c;

  shell_left_index = shell_left_index_c;  

  shell_right_index = shell_right_index_c;  
}

void configuration_2ph_data_str::initialize (const class configuration_2ph_data_str &X)
{
  n_scat = X.n_scat; 

  iC = X.iC;

  shell_left_index = X.shell_left_index;

  shell_right_index = X.shell_right_index;
}
   
void configuration_2ph_data_str::allocate_fill (const class configuration_2ph_data_str &X)
{
  initialize (X);
}



double used_memory_calc (const class configuration_2ph_data_str &T)
{
  return sizeof (T)/1000000.0;
}
