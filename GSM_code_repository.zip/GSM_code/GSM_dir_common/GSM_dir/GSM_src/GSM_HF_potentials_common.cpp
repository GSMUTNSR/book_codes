#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------


// Reallocation and initialisation of the HO expansion of the finite-range part of the HF/MSDHF or OCM potential given in HO basis
// -------------------------------------------------------------------------------------------------------------------------------
// The finite-range part of the HF/MSDHF or OCM potential given in HO basis is deallocated, reallocated and initialized here.

void HF_potentials_common::U_finite_range_HF_HO_basis_HO_expansion_part_realloc_init (
										      const class array<int> &nmax_HO_lab_tab , 
										      class baryons_data &data)
{
  
  const int lmax = data.get_lmax ();
  
  const int lmax_for_basis_interaction = nmax_HO_lab_tab.dimension (0) - 1;
  
  class lj_table<class matrix<complex<double> > > &U_finite_range_HF_HO_basis_HO_expansion_part = data.get_U_finite_range_HF_HO_basis_HO_expansion_part ();

  U_finite_range_HF_HO_basis_HO_expansion_part.deallocate ();

  U_finite_range_HF_HO_basis_HO_expansion_part.allocate (0.5 , lmax);

  for (int l = 0 ; l <= lmax ; l++)
    for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	const int nmax_HO_l = (l <= lmax_for_basis_interaction) ? (nmax_HO_lab_tab(l)) : (0);
	
	class matrix<complex<double> > &U_finite_range_HF_HO_basis_HO_expansion_part_lj = U_finite_range_HF_HO_basis_HO_expansion_part(l , j);

	U_finite_range_HF_HO_basis_HO_expansion_part_lj.allocate (nmax_HO_l + 1);

	U_finite_range_HF_HO_basis_HO_expansion_part_lj = 0.0; 
      }
}













// Reallocation and initialisation of the equivalent potentials and sources, as well as one-body matrix elements, including those with k +/- w/(4 Pi) with protons for Coulomb complex scaling (see H_CM_OBMEs.cpp) (pm is +/-)
// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Equivalent potentials, sources and HF potential one-body matrix elements for the SGI and MSGI interactions for all states are deallocated, reallocated and initialized here.
//
// The non-local potential U(r,r') applied a wave function is written Ueq(r).u(r) + S(r), where Ueq(r) is the equivalent potential and S(r) the source.
//
// Ueq(r) = [1 - F(r)] \int U(r,r') u(r') dr' / u(r) and S(r) = F(r) \int U(r,r') u(r') dr', with F(r) a regularizing factor preventing from Ueq(r) to diverge if u(r) = 0, which is numerically non-zero only close to the zeroes of u(r).
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
//                  Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
//                  The ratio |u(r)|^2/|u'(r)|^2 prevents F(r) to be non zero when r -> +oo.
//                  Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).

void HF_potentials_common::Ueq_source_OBMEs_HF_SGI_MSGI_pm_realloc_init (
									 const enum interaction_type inter , 
									 class baryons_data &data)
{
  const enum particle_type particle = data.get_nucleonic_particle ();
  
  const int nmax = data.get_nmax ();
  const int lmax = data.get_lmax ();

  const int nmax_plus_one = nmax + 1;

  const unsigned int N_bef_R_uniform = data.get_N_bef_R_uniform ();
  
  class nlj_table<complex<double> > &Ueq_finite_range_tab_uniform = data.get_Ueq_finite_range_tab_uniform ();

  class nlj_table<complex<double> > &source_tab_uniform = data.get_source_tab_uniform ();
  
  Ueq_finite_range_tab_uniform.deallocate ();

  Ueq_finite_range_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);

  source_tab_uniform.deallocate ();

  source_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);

  Ueq_finite_range_tab_uniform = 0.0;

  source_tab_uniform = 0.0;

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (inter);

  if (is_it_SGI_MSGI) 
    { 
      class lj_table<complex<double> > &OBMEs_HF_SGI_MSGI = data.get_OBMEs_HF_SGI_MSGI ();

      OBMEs_HF_SGI_MSGI.allocate (0.5 , lmax , nmax_plus_one , nmax_plus_one);

      OBMEs_HF_SGI_MSGI = 0.0;
    }

  if (particle == PROTON)
    {
      class nlj_table<complex<double> > &Ueq_finite_range_plus_tab_uniform  = data.get_Ueq_finite_range_plus_tab_uniform ();
      class nlj_table<complex<double> > &Ueq_finite_range_minus_tab_uniform = data.get_Ueq_finite_range_minus_tab_uniform ();

      class nlj_table<complex<double> > &source_plus_tab_uniform  = data.get_source_plus_tab_uniform ();
      class nlj_table<complex<double> > &source_minus_tab_uniform = data.get_source_minus_tab_uniform ();
      
      Ueq_finite_range_plus_tab_uniform.allocate  (0.5 , nmax , lmax , N_bef_R_uniform);
      Ueq_finite_range_minus_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);
      
      source_plus_tab_uniform.allocate  (0.5 , nmax , lmax , N_bef_R_uniform);
      source_minus_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);

      Ueq_finite_range_plus_tab_uniform  = 0.0;
      Ueq_finite_range_minus_tab_uniform = 0.0;
      
      source_plus_tab_uniform  = 0.0;
      source_minus_tab_uniform = 0.0;
    }
}





// Removal of the boolean is_it_HO in one-body wave functions for the HF procedure
// -------------------------------------------------------------------------------
// Bound wave functions can be used as HO in the GSM model space. However, they have to be included as HF states in the HF procedure as they can be occupied and enter the HF potential.
// Consequently, their HO character is temporarily removed here (false in shell_qn.initialize), to be restored after the calculation of the HF procedure.

void HF_potentials_common::is_it_HO_removal (class baryons_data &data)
{
  const unsigned int N_nlj = data.get_N_nlj_baryon ();

  const class lj_table<class correlated_state_str> &basis_PSI_quantum_numbers_tab = data.get_basis_PSI_quantum_numbers_tab ();
  
  class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  for (unsigned int i = 0 ; i < N_nlj ; i++) 
    {
      class nlj_struct &shell_qn = shells_qn(i);

      const enum particle_type particle = shell_qn.get_particle ();

      const int strangeness = particle_strangeness_determine (particle);
      
      if (strangeness != 0) continue;
	  
      const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();
      
      const int l = shell_qn.get_l ();

      const double j = shell_qn.get_j ();

      const class correlated_state_str &basis_PSI_qn = basis_PSI_quantum_numbers_tab(l , j);

      if (S_matrix_pole && basis_PSI_qn.get_is_it_filled ())
	{
	  shell_qn.initialize (
			       S_matrix_pole ,
			       shell_qn.get_core_state () ,
			       shell_qn.get_frozen_state () ,
			       shell_qn.get_hole_state () ,
			       shell_qn.get_OCM_valence_state () ,
			       false ,
			       shell_qn.get_is_it_for_HF_gs () ,
			       shell_qn.get_is_it_natural_orbital () ,
			       shell_qn.get_particle () ,
			       shell_qn.get_e_trunc () ,
			       shell_qn.get_n () ,
			       l ,
			       j ,
			       shell_qn.get_segment () ,
			       shell_qn.get_k () ,
			       shell_qn.get_w () ,
			       shell_qn.get_C0 () ,
			       shell_qn.get_Cplus () ,
			       shell_qn.get_k_plus () ,
			       shell_qn.get_C0_plus () ,
			       shell_qn.get_k_minus () ,
			       shell_qn.get_C0_minus ());
	}
    }
}











// Restoration of the boolean is_it_HO and of truncation energy in one-body wave functions for the HF procedure
// ------------------------------------------------------------------------------------------------------------
// Bound wave functions can be used as HO in the GSM model space. However, they have to be included as HF states in the HF procedure as they can be occupied and enter the HF potential.
// Consequently, their HO character is restored here (old_shell_qn.get_is_it_HO () in shell_qn.initialize).
// As the truncation energy of one-body wave functions had also been modified to allow for specific configurations to be optimized in the HF procedure, it is also restored here (old_shell_qn.get_e_trunc () in shell_qn.initialize).

void HF_potentials_common::init_restore (
					 const class array<class nlj_struct> &old_shells_qn , 
					 class array<class nlj_struct> &shells_qn)
{
  const unsigned int N_nlj = shells_qn.dimension (0);

  for (unsigned int i = 0 ; i < N_nlj ; i++)
    {
      class nlj_struct &shell_qn = shells_qn(i);

      const enum particle_type particle = shell_qn.get_particle ();

      const int strangeness = particle_strangeness_determine (particle);
      
      if (strangeness != 0) continue;
      
      for (unsigned int ii = 0 ; ii < N_nlj ; ii++)
	{
	  const class nlj_struct &old_shell_qn = old_shells_qn(ii);

	  const enum particle_type particle_old = old_shell_qn.get_particle ();

	  const int strangeness_old = particle_strangeness_determine (particle_old);
      
	  if (strangeness_old != 0) continue;
      
	  if (same_nlj_particle (shell_qn , old_shell_qn)) 
	    {
	      shell_qn.initialize (
				   shell_qn.get_S_matrix_pole () ,
				   shell_qn.get_core_state () ,
				   shell_qn.get_frozen_state () ,
				   shell_qn.get_hole_state () ,
				   shell_qn.get_OCM_valence_state () ,
				   old_shell_qn.get_is_it_HO () ,
				   shell_qn.get_is_it_for_HF_gs () ,
				   shell_qn.get_is_it_natural_orbital () ,
				   shell_qn.get_particle () ,
				   old_shell_qn.get_e_trunc () ,
				   shell_qn.get_n () ,
				   shell_qn.get_l () ,
				   shell_qn.get_j () ,
				   shell_qn.get_segment () ,
				   shell_qn.get_k () ,
				   shell_qn.get_w () ,
				   shell_qn.get_C0 () ,
				   shell_qn.get_Cplus () ,
				   shell_qn.get_k_plus () ,
				   shell_qn.get_C0_plus () ,
				   shell_qn.get_k_minus () ,
				   shell_qn.get_C0_minus ());
	    }
	}
    } 
}
















// Reallocation and initialisation of the HO expansion of the finite-range part of the HF/MSDHF or OCM potential given in HO basis
// -------------------------------------------------------------------------------------------------------------------------------
// The finite-range part of the HF/MSDHF or OCM potential given in HO basis is initialized using a WS potential as a starting point for the HF potential.

void HF_potentials_common::Ueq_finite_range_no_core_init_calc (
							       const class interaction_class &inter_data_basis , 
							       class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj = HF_data.get_N_nlj ();

  if (N_nlj == 0) return;

  const int lmax_for_basis_interaction = inter_data_basis.get_lmax_for_interaction();
  
  const enum particle_type particle = HF_data.get_particle ();

  const int Z_charge_basis_potential = HF_data.get_Z_charge_basis_potential ();

  const int lmax = HF_data.get_lmax ();

  const unsigned int N_bef_R_GL = HF_data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = HF_data.get_N_aft_R_GL ();

  const double R_charge = HF_data.get_R_charge ();

  const class array<double> &d_tab        = HF_data.get_d_tab ();
  const class array<double> &R0_tab       = HF_data.get_R0_tab ();
  const class array<double> &Vo_tab       = HF_data.get_Vo_tab ();
  const class array<double> &Vso_tab      = HF_data.get_Vso_tab ();
  const class array<double> &Im_Vo_tab    = HF_data.get_Im_Vo_tab ();
  const class array<double> &Im_Vso_tab   = HF_data.get_Im_Vso_tab ();
  const class array<double> &Im_Vsurf_tab = HF_data.get_Im_Vsurf_tab ();

  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  const class array<double> &r_bef_R_tab_GL = inter_data_basis.get_r_bef_R_tab_GL ();
  const class array<double> &w_bef_R_tab_GL = inter_data_basis.get_w_bef_R_tab_GL ();

  const class array<double> &r_aft_R_tab_GL = inter_data_basis.get_r_aft_R_tab_GL ();
  const class array<double> &w_aft_R_tab_GL = inter_data_basis.get_w_aft_R_tab_GL ();
  
  const class array<double> &HO_wfs_bef_R_tab_GL = inter_data_basis.get_HO_wfs_bef_R_tab_GL ();
  const class array<double> &HO_wfs_aft_R_tab_GL = inter_data_basis.get_HO_wfs_aft_R_tab_GL ();

  class lj_table<class matrix<complex<double> > > &U_finite_range_HF_HO_basis_HO_expansion_part = HF_data.get_U_finite_range_HF_HO_basis_HO_expansion_part ();

  for (int l = 0 ; l <= lmax ; l++)
    {
      const int nmax_HO = (l <= lmax_for_basis_interaction) ? (nmax_HO_lab_tab(l)) : (0);
      
      const double d        = d_tab       (0 , l);
      const double R0       = R0_tab      (0 , l);
      const double Vo       = Vo_tab      (0 , l);
      const double Vso      = Vso_tab     (0 , l);
      const double Im_Vo    = Im_Vo_tab   (0 , l);
      const double Im_Vso   = Im_Vso_tab  (0 , l);
      const double Im_Vsurf = Im_Vsurf_tab(0 , l);

      const complex<double> Vo_complex(Vo , Im_Vo);

      const complex<double> Vso_complex(Vso , Im_Vso);

      const double R0_init = R0 + 2;

      for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	{
	  const class WS_analytic_complex_class WS_complex_analytic_potential(false , d , R0_init , Vo_complex , Vso_complex , Im_Vsurf , particle , Z_charge_basis_potential , R_charge , l , j);

	  class array<complex<double> > WS_potential_tab_bef_R(N_bef_R_GL);
	  class array<complex<double> > WS_potential_tab_aft_R(N_aft_R_GL);
	  
	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) WS_potential_tab_bef_R(i) = WS_complex_analytic_potential(r_bef_R_tab_GL(i));	  
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) WS_potential_tab_aft_R(i) = WS_complex_analytic_potential(r_aft_R_tab_GL(i));

	  class matrix<complex<double> > &U_finite_range_HF_HO_basis_HO_expansion_part_lj = U_finite_range_HF_HO_basis_HO_expansion_part(l , j);

	  for (int na = 0 ; na <= nmax_HO ; na++)
	    for (int nb = 0 ; nb <= na ; nb++)
	      {
		complex<double> radial_integral_bef_R = 0.0;
		complex<double> radial_integral_aft_R = 0.0;

		for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) radial_integral_bef_R += w_bef_R_tab_GL(i)*HO_wfs_bef_R_tab_GL(nb , l , i)*HO_wfs_bef_R_tab_GL(na , l , i)*WS_potential_tab_bef_R(i);
		for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) radial_integral_aft_R += w_aft_R_tab_GL(i)*HO_wfs_aft_R_tab_GL(nb , l , i)*HO_wfs_aft_R_tab_GL(na , l , i)*WS_potential_tab_aft_R(i);

		U_finite_range_HF_HO_basis_HO_expansion_part_lj(na , nb) = U_finite_range_HF_HO_basis_HO_expansion_part_lj(nb , na) = radial_integral_bef_R + radial_integral_aft_R;
	      }
	}
    }
}









// Initialisation of the HF/MSDHF or OCM equivalent potentials with a WS or KKNN potential, including states for which k +/- w/(4 Pi) with protons for Coulomb complex scaling (see H_CM_OBMEs.cpp) (pm is +/-)
// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// The HF/MSDHF or OCM equivalent potentials are initialized using a WS or KKNN potential as a starting point for the HF potential.
// All sources and additional HF potentials to add to the initial potentials, as for the SGI and MSGI interactions, are put to zero.
// After calculating potentials for r > 0, they are calculated in r = 0 using the approximate formula f(0) = (4 f(1) - f(2))/3, which comes from a quadratic formula using f'(0) = 0.
//
// The non-local potential U(r,r') applied a wave function is written Ueq(r).u(r) + S(r), where Ueq(r) is the equivalent potential and S(r) the source.
//
// Ueq(r) = [1 - F(r)] \int U(r,r') u(r') dr' / u(r) and S(r) = F(r) \int U(r,r') u(r') dr', with F(r) a regularizing factor preventing from Ueq(r) to diverge if u(r) = 0, which is numerically non-zero only close to the zeroes of u(r).
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
//                  Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
//                  The ratio |u(r)|^2/|u'(r)|^2 prevents F(r) to be non zero when r -> +oo.
//                  Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// The routine with "pm (i.e. +/- 1)" added in its name means that one considers the equivalent potentials of the states for which k +/- w/(4 Pi) with protons for Coulomb complex scaling (see H_CM_OBMEs.cpp).

void HF_potentials_common::one_body_nuclear_hamiltonian_part_calc_init (
									const bool is_it_SGI_MSGI , 
									class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj = HF_data.get_N_nlj ();
  
  if (N_nlj == 0) return;

  const unsigned int N_bef_R_uniform = HF_data.get_N_bef_R_uniform ();
  
  const unsigned int N_bef_R_GL = HF_data.get_N_bef_R_GL ();
  
  const class lj_table<bool> &is_partial_wave_optimized_HF_MSDHF_tab = HF_data.get_is_partial_wave_optimized_HF_MSDHF_tab ();
 
  const int nmax = HF_data.get_nmax ();
  const int lmax = HF_data.get_lmax ();

  class lj_table<class matrix<complex<double> > > &U_finite_range_HF_HO_basis_HO_expansion_part = HF_data.get_U_finite_range_HF_HO_basis_HO_expansion_part ();

  for (int l = 0 ; l <= lmax ; l++)
    for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	class matrix<complex<double> > &U_finite_range_HF_HO_basis_HO_expansion_part_lj = U_finite_range_HF_HO_basis_HO_expansion_part(l , j);

	U_finite_range_HF_HO_basis_HO_expansion_part_lj = 0.0;
      }

  if (is_it_SGI_MSGI)
    {
      class lj_table<complex<double> > &OBMEs_HF_SGI_MSGI = HF_data.get_OBMEs_HF_SGI_MSGI ();

      OBMEs_HF_SGI_MSGI = 0.0;
    }

  const bool is_it_OCM_basis = HF_data.get_is_it_OCM_basis ();
  
  const enum potential_type H_potential = HF_data.get_H_potential ();

  const class array<double> &d_tab_HF        = HF_data.get_d_tab ();
  const class array<double> &R0_tab_HF       = HF_data.get_R0_tab ();
  const class array<double> &Vo_tab_HF       = HF_data.get_Vo_tab ();
  const class array<double> &Vso_tab_HF      = HF_data.get_Vso_tab ();
  const class array<double> &Im_Vo_tab_HF    = HF_data.get_Im_Vo_tab ();
  const class array<double> &Im_Vso_tab_HF   = HF_data.get_Im_Vso_tab ();
  const class array<double> &Im_Vsurf_tab_HF = HF_data.get_Im_Vsurf_tab ();

  const class array<double> &d_basis_tab_HF        = HF_data.get_d_basis_tab ();
  const class array<double> &R0_basis_tab_HF       = HF_data.get_R0_basis_tab ();
  const class array<double> &Vo_basis_tab_HF       = HF_data.get_Vo_basis_tab ();
  const class array<double> &Vso_basis_tab_HF      = HF_data.get_Vso_basis_tab ();
  const class array<double> &Im_Vo_basis_tab_HF    = HF_data.get_Im_Vo_basis_tab ();
  const class array<double> &Im_Vso_basis_tab_HF   = HF_data.get_Im_Vso_basis_tab ();
  const class array<double> &Im_Vsurf_basis_tab_HF = HF_data.get_Im_Vsurf_basis_tab ();

  const class array<double> &V0_KKNN_tab     = HF_data.get_V0_KKNN_tab ();  
  const class array<double> &rho_KKNN_tab    = HF_data.get_rho_KKNN_tab ();
  const class array<double> &Vls_KKNN_tab    = HF_data.get_Vls_KKNN_tab ();
  const class array<double> &rho_ls_KKNN_tab = HF_data.get_rho_ls_KKNN_tab ();
  
  const double V0_KKNN[5] = {
    V0_KKNN_tab(0 , 0) ,
    V0_KKNN_tab(0 , 1) ,
    V0_KKNN_tab(0 , 2) ,
    V0_KKNN_tab(0 , 3) ,
    V0_KKNN_tab(0 , 4)};
  
  const double rho_KKNN[5] = {
    rho_KKNN_tab(0 , 0) ,
    rho_KKNN_tab(0 , 1) ,
    rho_KKNN_tab(0 , 2) ,
    rho_KKNN_tab(0 , 3) ,
    rho_KKNN_tab(0 , 4)};

  const double Vls_KKNN[3] = {
    Vls_KKNN_tab(0 , 0) ,
    Vls_KKNN_tab(0 , 1) ,
    Vls_KKNN_tab(0 , 2)};
  
  const double rho_ls_KKNN[3] = {
    rho_ls_KKNN_tab(0 , 0) ,
    rho_ls_KKNN_tab(0 , 1) ,
    rho_ls_KKNN_tab(0 , 2)};

  class nlj_table<complex<double> > &Ueq_finite_range_tab_uniform = HF_data.get_Ueq_finite_range_tab_uniform ();
  class nlj_table<complex<double> > &Ueq_finite_range_tab_GL      = HF_data.get_Ueq_finite_range_tab_GL ();
  
  class nlj_table<complex<double> > &source_tab_uniform = HF_data.get_source_tab_uniform ();
  class nlj_table<complex<double> > &source_tab_GL      = HF_data.get_source_tab_GL ();

  const double R = HF_data.get_R ();
  
  const double step_bef_R_uniform = HF_data.get_step_bef_R_uniform ();
  
  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);

  class array<complex<double> > potential_bef_R_tab_uniform(N_bef_R_uniform);
  class array<complex<double> > potential_bef_R_tab_GL     (N_bef_R_GL);
	  
  for (int l = 0 ; l <= lmax ; l++)
    {
      const double d_HF        = d_tab_HF       (0 , l) , d_basis_HF        = d_basis_tab_HF       (0 , l);
      const double R0_HF       = R0_tab_HF      (0 , l) , R0_basis_HF       = R0_basis_tab_HF      (0 , l);
      const double Vo_HF       = Vo_tab_HF      (0 , l) , Vo_basis_HF       = Vo_basis_tab_HF      (0 , l);
      const double Vso_HF      = Vso_tab_HF     (0 , l) , Vso_basis_HF      = Vso_basis_tab_HF     (0 , l);
      const double Im_Vo_HF    = Im_Vo_tab_HF   (0 , l) , Im_Vo_basis_HF    = Im_Vo_basis_tab_HF   (0 , l);
      const double Im_Vso_HF   = Im_Vso_tab_HF  (0 , l) , Im_Vso_basis_HF   = Im_Vso_basis_tab_HF  (0 , l);
      const double Im_Vsurf_HF = Im_Vsurf_tab_HF(0 , l) , Im_Vsurf_basis_HF = Im_Vsurf_basis_tab_HF(0 , l);
      
      for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	{
	  const bool is_lj_partial_wave_HF_MSDHF_optimized = (!is_it_OCM_basis && is_partial_wave_optimized_HF_MSDHF_tab(l , j));
	  
	  const double d        = (is_lj_partial_wave_HF_MSDHF_optimized) ? (d_HF)        : (d_basis_HF);
	  const double R0       = (is_lj_partial_wave_HF_MSDHF_optimized) ? (R0_HF)       : (R0_basis_HF);
	  const double Vo       = (is_lj_partial_wave_HF_MSDHF_optimized) ? (Vo_HF)       : (Vo_basis_HF);
	  const double Vso      = (is_lj_partial_wave_HF_MSDHF_optimized) ? (Vso_HF)      : (Vso_basis_HF);
	  const double Im_Vo    = (is_lj_partial_wave_HF_MSDHF_optimized) ? (Im_Vo_HF)    : (Im_Vo_basis_HF);
	  const double Im_Vso   = (is_lj_partial_wave_HF_MSDHF_optimized) ? (Im_Vso_HF)   : (Im_Vso_basis_HF);
	  const double Im_Vsurf = (is_lj_partial_wave_HF_MSDHF_optimized) ? (Im_Vsurf_HF) : (Im_Vsurf_basis_HF);

	  const complex<double> Vo_complex(Vo , Im_Vo);

	  const complex<double> Vso_complex(Vso , Im_Vso);

	  const class WS_complex_class WS_nuclear_potential(false , d , R0 , Vo_complex , Vso_complex , Im_Vsurf , NEUTRON , NADA , NADA , l , j);
	  
	  const class KKNN_class KKNN_nuclear_potential(false , V0_KKNN , rho_KKNN , Vls_KKNN , rho_ls_KKNN , NEUTRON , NADA , NADA , l , j);

	  for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
	    {
	      const double r = i*step_bef_R_uniform;

	      potential_bef_R_tab_uniform(i) = (H_potential == KKNN) ? (KKNN_nuclear_potential(r)) : (WS_nuclear_potential(r));
	    }

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	    {
	      const double r = r_bef_R_tab_GL(i);

	      potential_bef_R_tab_GL(i) = (H_potential == KKNN) ? (KKNN_nuclear_potential(r)) : (WS_nuclear_potential(r));
	    }
	  
	  source_tab_uniform = 0.0;
	  source_tab_GL      = 0.0;

	  for (int n = 0 ; n <= nmax ; n++)
	    {
	      const unsigned int zero_index_uniform = Ueq_finite_range_tab_uniform.index_determine (n , l , j , 0);
	      const unsigned int zero_index_GL      = Ueq_finite_range_tab_GL.index_determine      (n , l , j , 0);

	      for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++) Ueq_finite_range_tab_uniform[zero_index_uniform + i] = potential_bef_R_tab_uniform(i);
	      for (unsigned int i = 0 ; i < N_bef_R_GL      ; i++) Ueq_finite_range_tab_GL[zero_index_GL + i]           = potential_bef_R_tab_GL(i);
	    }
	}
    }
  
  class nlj_table<complex<double> > &Ueq_finite_range_res_tab_uniform = HF_data.get_Ueq_finite_range_res_tab_uniform ();
  class nlj_table<complex<double> > &Ueq_finite_range_res_tab_GL      = HF_data.get_Ueq_finite_range_res_tab_GL ();
  
  class nlj_table<complex<double> > &source_res_tab_uniform = HF_data.get_source_res_tab_uniform ();
  class nlj_table<complex<double> > &source_res_tab_GL      = HF_data.get_source_res_tab_GL ();

  Ueq_finite_range_res_tab_uniform = Ueq_finite_range_tab_uniform;
  Ueq_finite_range_res_tab_GL      = Ueq_finite_range_tab_GL;
  
  source_res_tab_uniform = source_tab_uniform;
  source_res_tab_GL      = source_tab_GL;

  if (is_it_SGI_MSGI)
    {
      class nlj_table<complex<double> > &Ueq_SGI_MSGI_tab_GL     = HF_data.get_Ueq_SGI_MSGI_tab_GL ();
      class nlj_table<complex<double> > &Ueq_SGI_MSGI_res_tab_GL = HF_data.get_Ueq_SGI_MSGI_res_tab_GL ();
      
      class nlj_table<complex<double> > &source_SGI_MSGI_tab_GL     = HF_data.get_source_SGI_MSGI_tab_GL ();
      class nlj_table<complex<double> > &source_SGI_MSGI_res_tab_GL = HF_data.get_source_SGI_MSGI_res_tab_GL ();

      Ueq_SGI_MSGI_tab_GL     = 0.0;
      Ueq_SGI_MSGI_res_tab_GL = 0.0;
      
      source_SGI_MSGI_tab_GL     = 0.0;
      source_SGI_MSGI_res_tab_GL = 0.0;
    }
}

void HF_potentials_common::one_body_nuclear_hamiltonian_part_shells_pm_calc_init (
										  const int pm , 
										  const bool is_it_SGI_MSGI , 
										  class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj = HF_data.get_N_nlj ();
  
  if (N_nlj == 0) return;

  const unsigned int N_bef_R_uniform = HF_data.get_N_bef_R_uniform ();
  const unsigned int N_bef_R_GL  = HF_data.get_N_bef_R_GL ();
  
  const int nmax = HF_data.get_nmax ();
  const int lmax = HF_data.get_lmax ();
  
  const enum potential_type H_potential = HF_data.get_H_potential();

  const bool is_it_OCM_basis = HF_data.get_is_it_OCM_basis();

  const class array<double> &d_tab_HF        = HF_data.get_d_tab ();
  const class array<double> &R0_tab_HF       = HF_data.get_R0_tab ();
  const class array<double> &Vo_tab_HF       = HF_data.get_Vo_tab ();
  const class array<double> &Vso_tab_HF      = HF_data.get_Vso_tab ();
  const class array<double> &Im_Vo_tab_HF    = HF_data.get_Im_Vo_tab ();
  const class array<double> &Im_Vso_tab_HF   = HF_data.get_Im_Vso_tab ();
  const class array<double> &Im_Vsurf_tab_HF = HF_data.get_Im_Vsurf_tab ();

  const class array<double> &d_basis_tab_HF        = HF_data.get_d_basis_tab ();
  const class array<double> &R0_basis_tab_HF       = HF_data.get_R0_basis_tab ();
  const class array<double> &Vo_basis_tab_HF       = HF_data.get_Vo_basis_tab ();
  const class array<double> &Vso_basis_tab_HF      = HF_data.get_Vso_basis_tab ();
  const class array<double> &Im_Vo_basis_tab_HF    = HF_data.get_Im_Vo_basis_tab ();
  const class array<double> &Im_Vso_basis_tab_HF   = HF_data.get_Im_Vso_basis_tab ();
  const class array<double> &Im_Vsurf_basis_tab_HF = HF_data.get_Im_Vsurf_basis_tab ();

  const class array<double> &d_tab        = (is_it_OCM_basis) ? (d_basis_tab_HF)        : (d_tab_HF);
  const class array<double> &R0_tab       = (is_it_OCM_basis) ? (R0_basis_tab_HF)       : (R0_tab_HF);
  const class array<double> &Vo_tab       = (is_it_OCM_basis) ? (Vo_basis_tab_HF)       : (Vo_tab_HF);
  const class array<double> &Vso_tab      = (is_it_OCM_basis) ? (Vso_basis_tab_HF)      : (Vso_tab_HF);
  const class array<double> &Im_Vo_tab    = (is_it_OCM_basis) ? (Im_Vo_basis_tab_HF)    : (Im_Vo_tab_HF);
  const class array<double> &Im_Vso_tab   = (is_it_OCM_basis) ? (Im_Vso_basis_tab_HF)   : (Im_Vso_tab_HF);
  const class array<double> &Im_Vsurf_tab = (is_it_OCM_basis) ? (Im_Vsurf_basis_tab_HF) : (Im_Vsurf_tab_HF);

  const class array<double> &V0_KKNN_tab     = HF_data.get_V0_KKNN_tab ();  
  const class array<double> &rho_KKNN_tab    = HF_data.get_rho_KKNN_tab ();
  const class array<double> &Vls_KKNN_tab    = HF_data.get_Vls_KKNN_tab ();
  const class array<double> &rho_ls_KKNN_tab = HF_data.get_rho_ls_KKNN_tab ();
  
  const double V0_KKNN[5] = {
    V0_KKNN_tab(0 , 0) ,
    V0_KKNN_tab(0 , 1) ,
    V0_KKNN_tab(0 , 2) ,
    V0_KKNN_tab(0 , 3) ,
    V0_KKNN_tab(0 , 4)};
  
  const double rho_KKNN[5] = {
    rho_KKNN_tab(0 , 0) ,
    rho_KKNN_tab(0 , 1) ,
    rho_KKNN_tab(0 , 2) ,
    rho_KKNN_tab(0 , 3) ,
    rho_KKNN_tab(0 , 4)};

  const double Vls_KKNN[3] = {
    Vls_KKNN_tab(0 , 0) ,
    Vls_KKNN_tab(0 , 1) ,
    Vls_KKNN_tab(0 , 2)};
  
  const double rho_ls_KKNN[3] = {
    rho_ls_KKNN_tab(0 , 0) ,
    rho_ls_KKNN_tab(0 , 1) ,
    rho_ls_KKNN_tab(0 , 2)};
  
  class nlj_table<complex<double> > &Ueq_finite_range_pm_tab_uniform = (pm == 1) ? (HF_data.get_Ueq_finite_range_plus_tab_uniform ()) : (HF_data.get_Ueq_finite_range_minus_tab_uniform ());  
  class nlj_table<complex<double> > &Ueq_finite_range_pm_tab_GL      = (pm == 1) ? (HF_data.get_Ueq_finite_range_plus_tab_GL      ()) : (HF_data.get_Ueq_finite_range_minus_tab_GL      ());
  
  class nlj_table<complex<double> > &source_pm_tab_uniform = (pm == 1) ? (HF_data.get_source_plus_tab_uniform ()) : (HF_data.get_source_minus_tab_uniform ());
  class nlj_table<complex<double> > &source_pm_tab_GL      = (pm == 1) ? (HF_data.get_source_plus_tab_GL      ()) : (HF_data.get_source_minus_tab_GL      ());

  const double R = HF_data.get_R ();

  const double step_bef_R_uniform = HF_data.get_step_bef_R_uniform ();

  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);

  source_pm_tab_uniform = 0.0;
  source_pm_tab_GL  = 0.0;

  for (int l = 0 ; l <= lmax ; l++)
    {
      const double d        = d_tab       (0 , l);
      const double R0       = R0_tab      (0 , l);
      const double Vo       = Vo_tab      (0 , l);
      const double Vso      = Vso_tab     (0 , l);
      const double Im_Vo    = Im_Vo_tab   (0 , l);
      const double Im_Vso   = Im_Vso_tab  (0 , l);
      const double Im_Vsurf = Im_Vsurf_tab(0 , l);

      const complex<double> Vo_complex(Vo , Im_Vo);
	  
      const complex<double> Vso_complex(Vso , Im_Vso);

      for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	{
	  const class WS_complex_class WS_nuclear_potential(false , d , R0 , Vo_complex , Vso_complex , Im_Vsurf , NEUTRON , NADA , NADA , l , j);
	  
	  const class KKNN_class KKNN_nuclear_potential(false , V0_KKNN , rho_KKNN , Vls_KKNN , rho_ls_KKNN , NEUTRON , NADA , NADA , l , j);

	  for (int n = 0 ; n <= nmax ; n++)
	    {	
	      const unsigned int zero_index_uniform = Ueq_finite_range_pm_tab_uniform.index_determine (n , l , j , 0);
	      
	      const unsigned int zero_index_GL  = Ueq_finite_range_pm_tab_GL.index_determine  (n , l , j , 0);

	      for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++) 
		{
		  const double r = i*step_bef_R_uniform;

		  Ueq_finite_range_pm_tab_uniform[zero_index_uniform + i] = (H_potential == KKNN) ? (KKNN_nuclear_potential(r)) : (WS_nuclear_potential(r));
		}

	      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
		{
		  const double r = r_bef_R_tab_GL(i);

		  Ueq_finite_range_pm_tab_GL[zero_index_GL + i] = (H_potential == KKNN) ? (KKNN_nuclear_potential(r)) : (WS_nuclear_potential(r));
		}
	    }
	}
    }
  
  if (is_it_SGI_MSGI)
    {
      class nlj_table<complex<double> > &Ueq_SGI_MSGI_pm_tab_GL = (pm == 1) ? (HF_data.get_Ueq_SGI_MSGI_plus_tab_GL ()) : (HF_data.get_Ueq_SGI_MSGI_minus_tab_GL ());
      
      class nlj_table<complex<double> > &source_SGI_MSGI_pm_tab_GL = (pm == 1) ? (HF_data.get_source_SGI_MSGI_plus_tab_GL ()) : (HF_data.get_source_SGI_MSGI_minus_tab_GL ());
      
      Ueq_SGI_MSGI_pm_tab_GL = 0.0;
      
      source_SGI_MSGI_pm_tab_GL = 0.0;
    }
}



void HF_potentials_common::potentials_in_zero_calc (
						    const bool HO_diag ,
						    class HF_nucleons_data &HF_data)
{ 
  const unsigned int N_nlj = HF_data.get_N_nlj ();
  
  if (N_nlj == 0) return;

  const unsigned int N_nlj_res = HF_data.get_N_nlj_res ();
  
  const class array<class nlj_struct> &shells_qn = HF_data.get_shells_quantum_numbers ();
  
  const class array<class nlj_struct> &shells_qn_res = HF_data.get_shells_quantum_numbers_res ();
  
  class nlj_table<complex<double> > &Ueq_finite_range_tab_uniform = HF_data.get_Ueq_finite_range_tab_uniform ();
  
  class nlj_table<complex<double> > &Ueq_finite_range_res_tab_uniform = HF_data.get_Ueq_finite_range_res_tab_uniform ();
  
  class nlj_table<complex<double> > &source_tab_uniform = HF_data.get_source_tab_uniform ();
  
  class nlj_table<complex<double> > &source_res_tab_uniform = HF_data.get_source_res_tab_uniform ();

  for (unsigned int state = 0 ; state < N_nlj_res ; state++)
    {
      const class nlj_struct &shell_qn_res = shells_qn_res(state);
      
      const enum particle_type particle = shell_qn_res.get_particle ();

      const int strangeness = particle_strangeness_determine (particle);
      
      if (strangeness != 0) continue;
      
      const int n = shell_qn_res.get_n ();
      const int l = shell_qn_res.get_l ();
      
      const double j = shell_qn_res.get_j ();

      Ueq_finite_range_res_tab_uniform(n , l , j , 0) = (4.0*Ueq_finite_range_res_tab_uniform(n , l , j , 1) - Ueq_finite_range_res_tab_uniform(n , l , j , 2))/3.0;
      
      source_res_tab_uniform(n , l , j , 0) = 0.0;
    }
  
  const unsigned int first_state = basic_first_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_state = basic_last_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  for (unsigned int state = 0 ; state < N_nlj ; state++)
    {
      const class nlj_struct &shell_qn = shells_qn(state);
      
      const enum particle_type particle = shell_qn.get_particle ();

      const int strangeness = particle_strangeness_determine (particle);
      
      if (strangeness != 0) continue;
      
      const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

      if (S_matrix_pole || ((state >= first_state) && (state <= last_state)))
	{
	  const bool is_it_HO = shell_qn.get_is_it_HO ();
	  
	  const bool no_HO = (!is_it_HO) && (!HO_diag);

	  if (S_matrix_pole || no_HO)
	    {
	      const int n = shell_qn.get_n ();
	      const int l = shell_qn.get_l ();

	      const double j = shell_qn.get_j ();

	      Ueq_finite_range_tab_uniform(n , l , j , 0) = (4.0*Ueq_finite_range_tab_uniform(n , l , j , 1) - Ueq_finite_range_tab_uniform(n , l , j , 2))/3.0;
	      
	      source_tab_uniform(n , l , j , 0) = 0.0;
	    }
	}
    }
}










void HF_potentials_common::potentials_in_zero_shells_pm_calc (
							      const int pm ,
							      class HF_nucleons_data &HF_data)
{ 
  const unsigned int N_nlj = HF_data.get_N_nlj (); 

  if (N_nlj == 0) return;

  const class array<class nlj_struct> &shells_qn = HF_data.get_shells_quantum_numbers ();

  class nlj_table<complex<double> > &Ueq_finite_range_pm_tab_uniform = (pm == 1) ? (HF_data.get_Ueq_finite_range_plus_tab_uniform ()) : (HF_data.get_Ueq_finite_range_minus_tab_uniform ());
  
  class nlj_table<complex<double> > &source_pm_tab_uniform = (pm == 1) ? (HF_data.get_source_plus_tab_uniform ()) : (HF_data.get_source_minus_tab_uniform ());

  const unsigned int first_state = basic_first_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  const unsigned int last_state = basic_last_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int state = 0 ; state < N_nlj ; state++)
    {
      const class nlj_struct &shell_qn = shells_qn(state);
      
      const enum particle_type particle = shell_qn.get_particle ();

      const int strangeness = particle_strangeness_determine (particle);
      
      if (strangeness != 0) continue;
      
      const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

      if (S_matrix_pole || ((state >= first_state) && (state <= last_state)))
	{
	  const bool is_it_HO = shell_qn.get_is_it_HO ();

	  if (!is_it_HO)
	    {
	      const int n = shell_qn.get_n ();
	      const int l = shell_qn.get_l ();

	      const double j = shell_qn.get_j ();

	      Ueq_finite_range_pm_tab_uniform(n , l , j , 0) = (4.0*Ueq_finite_range_pm_tab_uniform(n , l , j , 1) - Ueq_finite_range_pm_tab_uniform(n , l , j , 2))/3.0;
	      
	      source_pm_tab_uniform(n , l , j , 0) = 0.0;
	    }
	}
    }
}









// Calculation of averaged equivalent potentials using linear mixing
// -----------------------------------------------------------------
// The non-local potential U(r,r') applied a wave function is written Ueq(r).u(r) + S(r), where Ueq(r) is the trivially equivalent potential and S(r) the source.
//
// Ueq(r) = [1 - F(r)] \int U(r,r') u(r') dr' / u(r) and S(r) = F(r) \int U(r,r') u(r') dr', with F(r) a regularizing factor preventing from Ueq(r) to diverge if u(r) = 0, which is numerically non-zero only close to the zeroes of u(r).
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
//                  Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
//                  The ratio |u(r)|^2/|u'(r)|^2 prevents F(r) to be non zero when r -> +oo.
//                  Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// The HF procedure provides with V(r,r'), and hence Ueq(r) and S(r) as a functional of occupied states. However, using a naive HF formula makes the self-consistent procedure diverge.
// A standard method to avoid this problem is to use linear mixing.
// The new potentials and source Ueq(r) and S(r) are replaced by Ueq(r) = alpha.Ueq(new)(r) + (1 - alpha).Ueq(old)(r) and S(r) = alpha.S(new)(r) + (1 - alpha).S(old)(r), 
// where Ueq(new) and S(new come from a direct use of the HF formula and alpha < 1. As one uses HF with spherical symmetry, alpha can be fairly large, 1/2 with HF/MSDHF, and even 1 (no linear mixing) with OCM only.
// This averaging procedure is done here.
// As all bound and resonant states are calculated, the averaging procedure is done for all potentials and sources.
// Otherwise, it is done only for the equivalent potentials and sources of the states effectively calculated by the node.
// OpenMP parallelization is done here.

void HF_potentials_common::trivially_equivalent_potentials_averaged_calc (
									  const bool HO_diag , 
									  const double new_potential_fraction , 
									  class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj = HF_data.get_N_nlj ();
  
  if (N_nlj == 0) return;

  const double one_minus_new_potential_fraction = 1.0 - new_potential_fraction;

  const class array<class nlj_struct> &shells_qn = HF_data.get_shells_quantum_numbers ();
  const class array<class spherical_state > &shells = HF_data.get_shells ();

  const class nlj_table<complex<double> > &Ueq_finite_range_res_tab_uniform = HF_data.get_Ueq_finite_range_res_tab_uniform ();
  const class nlj_table<complex<double> > &Ueq_finite_range_res_tab_GL      = HF_data.get_Ueq_finite_range_res_tab_GL ();
  
  const class nlj_table<complex<double> > &source_res_tab_uniform = HF_data.get_source_res_tab_uniform ();
  const class nlj_table<complex<double> > &source_res_tab_GL      = HF_data.get_source_res_tab_GL ();

  class nlj_table<complex<double> > &Ueq_finite_range_res_averaged_tab_uniform = HF_data.get_Ueq_finite_range_res_averaged_tab_uniform ();  
  class nlj_table<complex<double> > &Ueq_finite_range_res_averaged_tab_GL      = HF_data.get_Ueq_finite_range_res_averaged_tab_GL ();
  
  class nlj_table<complex<double> > &source_res_averaged_tab_uniform = HF_data.get_source_res_averaged_tab_uniform ();
  class nlj_table<complex<double> > &source_res_averaged_tab_GL      = HF_data.get_source_res_averaged_tab_GL ();
  
  Ueq_finite_range_res_averaged_tab_uniform *= one_minus_new_potential_fraction;
  Ueq_finite_range_res_averaged_tab_uniform += complex<double> (new_potential_fraction)*Ueq_finite_range_res_tab_uniform;

  source_res_averaged_tab_uniform *= one_minus_new_potential_fraction;
  source_res_averaged_tab_uniform += complex<double> (new_potential_fraction)*source_res_tab_uniform;

  Ueq_finite_range_res_averaged_tab_GL *= one_minus_new_potential_fraction;
  Ueq_finite_range_res_averaged_tab_GL += complex<double> (new_potential_fraction)*Ueq_finite_range_res_tab_GL;

  source_res_averaged_tab_GL *= one_minus_new_potential_fraction;
  source_res_averaged_tab_GL += complex<double> (new_potential_fraction)*source_res_tab_GL;

  const unsigned int first_state = basic_first_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  const unsigned int last_state = basic_last_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int state = 0 ; state < N_nlj ; state++)
    {
      const class spherical_state &shell = shells(state);

      if (shell.is_it_filled ())
	{
	  const class nlj_struct &shell_qn = shells_qn(state);

	  const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

	  if (S_matrix_pole || ((state >= first_state) && (state <= last_state)))
	    {
	      const class nlj_table<complex<double> > &Ueq_finite_range_tab_uniform       = HF_data.get_Ueq_finite_range_tab_uniform ();
	      const class nlj_table<complex<double> > &Ueq_finite_range_tab_GL            = HF_data.get_Ueq_finite_range_tab_GL ();
	      const class nlj_table<complex<double> > &Ueq_finite_range_plus_tab_uniform  = HF_data.get_Ueq_finite_range_plus_tab_uniform ();
	      const class nlj_table<complex<double> > &Ueq_finite_range_plus_tab_GL       = HF_data.get_Ueq_finite_range_plus_tab_GL ();
	      const class nlj_table<complex<double> > &Ueq_finite_range_minus_tab_uniform = HF_data.get_Ueq_finite_range_minus_tab_uniform ();
	      const class nlj_table<complex<double> > &Ueq_finite_range_minus_tab_GL      = HF_data.get_Ueq_finite_range_minus_tab_GL ();
	      
	      const class nlj_table<complex<double> > &source_tab_uniform       = HF_data.get_source_tab_uniform ();
	      const class nlj_table<complex<double> > &source_tab_GL            = HF_data.get_source_tab_GL ();
	      const class nlj_table<complex<double> > &source_plus_tab_uniform  = HF_data.get_source_plus_tab_uniform ();
	      const class nlj_table<complex<double> > &source_plus_tab_GL       = HF_data.get_source_plus_tab_GL ();
	      const class nlj_table<complex<double> > &source_minus_tab_uniform = HF_data.get_source_minus_tab_uniform ();
	      const class nlj_table<complex<double> > &source_minus_tab_GL      = HF_data.get_source_minus_tab_GL ();

	      class nlj_table<complex<double> > &Ueq_finite_range_averaged_tab_uniform       = HF_data.get_Ueq_finite_range_averaged_tab_uniform ();
	      class nlj_table<complex<double> > &Ueq_finite_range_averaged_tab_GL            = HF_data.get_Ueq_finite_range_averaged_tab_GL ();
	      class nlj_table<complex<double> > &Ueq_finite_range_plus_averaged_tab_uniform  = HF_data.get_Ueq_finite_range_plus_averaged_tab_uniform ();
	      class nlj_table<complex<double> > &Ueq_finite_range_plus_averaged_tab_GL       = HF_data.get_Ueq_finite_range_plus_averaged_tab_GL ();
	      class nlj_table<complex<double> > &Ueq_finite_range_minus_averaged_tab_uniform = HF_data.get_Ueq_finite_range_minus_averaged_tab_uniform ();
	      class nlj_table<complex<double> > &Ueq_finite_range_minus_averaged_tab_GL      = HF_data.get_Ueq_finite_range_minus_averaged_tab_GL ();
	      
	      class nlj_table<complex<double> > &source_averaged_tab_uniform       = HF_data.get_source_averaged_tab_uniform ();
	      class nlj_table<complex<double> > &source_averaged_tab_GL            = HF_data.get_source_averaged_tab_GL ();
	      class nlj_table<complex<double> > &source_plus_averaged_tab_uniform  = HF_data.get_source_plus_averaged_tab_uniform ();
	      class nlj_table<complex<double> > &source_plus_averaged_tab_GL       = HF_data.get_source_plus_averaged_tab_GL ();
	      class nlj_table<complex<double> > &source_minus_averaged_tab_uniform = HF_data.get_source_minus_averaged_tab_uniform ();
	      class nlj_table<complex<double> > &source_minus_averaged_tab_GL      = HF_data.get_source_minus_averaged_tab_GL ();	      
	      
	      const bool is_it_HO = shell_qn.get_is_it_HO ();
	      
	      const bool no_HO = (!is_it_HO) && (!HO_diag);

	      if (S_matrix_pole || no_HO)
		{
		  const int n = shell.get_n ();
		  const int l = shell.get_l ();
		  
		  const unsigned int N_bef_R_uniform = shell.get_N_bef_R_uniform ();
		  const unsigned int N_bef_R_GL  = shell.get_N_bef_R_GL ();
		  
		  const double j = shell.get_j ();

		  const unsigned int zero_index_uniform = Ueq_finite_range_tab_uniform.index_determine (n , l , j , 0);
		  const unsigned int zero_index_GL  = Ueq_finite_range_tab_GL.index_determine  (n , l , j , 0);

		  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) 
		    {
		      const unsigned int index_uniform = zero_index_uniform + i;

		      Ueq_finite_range_averaged_tab_uniform[index_uniform]       = new_potential_fraction*Ueq_finite_range_tab_uniform[index_uniform]       + one_minus_new_potential_fraction*Ueq_finite_range_averaged_tab_uniform[index_uniform];
		      Ueq_finite_range_plus_averaged_tab_uniform[index_uniform]  = new_potential_fraction*Ueq_finite_range_plus_tab_uniform[index_uniform]  + one_minus_new_potential_fraction*Ueq_finite_range_plus_averaged_tab_uniform[index_uniform];
		      Ueq_finite_range_minus_averaged_tab_uniform[index_uniform] = new_potential_fraction*Ueq_finite_range_minus_tab_uniform[index_uniform] + one_minus_new_potential_fraction*Ueq_finite_range_minus_averaged_tab_uniform[index_uniform];
		      
		      source_averaged_tab_uniform[index_uniform]       = new_potential_fraction*source_tab_uniform[index_uniform]       + one_minus_new_potential_fraction*source_averaged_tab_uniform[index_uniform];
		      source_plus_averaged_tab_uniform[index_uniform]  = new_potential_fraction*source_plus_tab_uniform[index_uniform]  + one_minus_new_potential_fraction*source_plus_averaged_tab_uniform[index_uniform];	
		      source_minus_averaged_tab_uniform[index_uniform] = new_potential_fraction*source_minus_tab_uniform[index_uniform] + one_minus_new_potential_fraction*source_minus_averaged_tab_uniform[index_uniform];
		    }

		  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
		    {
		      const unsigned int index_GL = zero_index_GL + i;

		      Ueq_finite_range_averaged_tab_GL[index_GL]       = new_potential_fraction*Ueq_finite_range_tab_GL[index_GL]       + one_minus_new_potential_fraction*Ueq_finite_range_averaged_tab_GL[index_GL];
		      Ueq_finite_range_plus_averaged_tab_GL[index_GL]  = new_potential_fraction*Ueq_finite_range_plus_tab_GL[index_GL]  + one_minus_new_potential_fraction*Ueq_finite_range_plus_averaged_tab_GL[index_GL];
		      Ueq_finite_range_minus_averaged_tab_GL[index_GL] = new_potential_fraction*Ueq_finite_range_minus_tab_GL[index_GL] + one_minus_new_potential_fraction*Ueq_finite_range_minus_averaged_tab_GL[index_GL];
		      
		      source_averaged_tab_GL[index_GL]       = new_potential_fraction*source_tab_GL[index_GL]       + one_minus_new_potential_fraction*source_averaged_tab_GL[index_GL];
		      source_plus_averaged_tab_GL[index_GL]  = new_potential_fraction*source_plus_tab_GL[index_GL]  + one_minus_new_potential_fraction*source_plus_averaged_tab_GL[index_GL];	
		      source_minus_averaged_tab_GL[index_GL] = new_potential_fraction*source_minus_tab_GL[index_GL] + one_minus_new_potential_fraction*source_minus_averaged_tab_GL[index_GL];		      
		    }		  
		}
	    }
	}
    }
}









#ifdef UseMPI

// MPI distribution of equivalent potentials and sources to all nodes
// ------------------------------------------------------------------
// Averaged equivalent potentials and sources calculated on the uniform grid are put to zero on the other processes except the one dedicated to their calculation.
// Then , as Ueq(n , j , l , i) is non zero for one process only and Ueq(n , j , l , i) = 0 for other processes , 
// final Ueq(n , j , l , i) = initial Ueq(n , j , l , i) + 0 + 0 + ... + 0 = initial Ueq(n , j , l , i) using summed Allreduce routines (same for sources).
// The C0 and C+ constants are calculated shells are also transferred, as they are needed afterwards to integrate the non-homogeneous Schrodinger equation equivalent equation (it has a source term).
// Equivalent potentials and sources calculated on the Gauss-Legendre grid and non averaged equivalent potentials and sources do not have to be distributed, 
// as one uses only averaged equivalent potentials and sources afterwards with direct integration, with which one uses the uniform grid only.

void HF_potentials_common::potentials_MPI_transfer (
						    const enum space_type basis_space , 
						    class HF_nucleons_data &HF_data)
{  
  const enum particle_type particle = HF_data.get_particle ();
  
  if ((particle == PROTON)  && (basis_space == NEUT_Y_ONLY)) return;
  if ((particle == NEUTRON) && (basis_space == PROT_Y_ONLY)) return;

  const unsigned int N_nlj = HF_data.get_N_nlj ();

  if (N_nlj == 0) return;

  const unsigned int N_bef_R_uniform = HF_data.get_N_bef_R_uniform ();
  
  const unsigned int first_state = basic_first_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_state = basic_last_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const int nmax = HF_data.get_nmax ();
  const int lmax = HF_data.get_lmax ();
  
  const class array<class nlj_struct> &shells_qn = HF_data.get_shells_quantum_numbers ();

  class array<class spherical_state > &shells = HF_data.get_shells ();

  class nlj_table<complex<double> > &Ueq_finite_range_tab_uniform_averaged       = HF_data.get_Ueq_finite_range_averaged_tab_uniform ();
  class nlj_table<complex<double> > &Ueq_finite_range_plus_tab_uniform_averaged  = HF_data.get_Ueq_finite_range_plus_averaged_tab_uniform ();
  class nlj_table<complex<double> > &Ueq_finite_range_minus_tab_uniform_averaged = HF_data.get_Ueq_finite_range_minus_averaged_tab_uniform ();
  
  class nlj_table<complex<double> > &source_tab_uniform_averaged       = HF_data.get_source_averaged_tab_uniform ();  
  class nlj_table<complex<double> > &source_plus_tab_uniform_averaged  = HF_data.get_source_plus_averaged_tab_uniform ();
  class nlj_table<complex<double> > &source_minus_tab_uniform_averaged = HF_data.get_source_minus_averaged_tab_uniform ();

  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      class spherical_state &shell = shells(s);

      if (shell.is_it_filled ())
	{
	  if ((s < first_state) || (s > last_state))
	    {	      
	      const int n = shell.get_n ();
	      const int l = shell.get_l ();

	      const double j = shell.get_j ();
	      
	      const unsigned int zero_index_uniform = Ueq_finite_range_tab_uniform_averaged.index_determine (n , l , j , 0);

	      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) 
		{	
		  const unsigned int index_uniform = zero_index_uniform + i;

		  Ueq_finite_range_tab_uniform_averaged[index_uniform]       = source_tab_uniform_averaged[index_uniform]       = 0.0;
		  Ueq_finite_range_plus_tab_uniform_averaged[index_uniform]  = source_plus_tab_uniform_averaged[index_uniform]  = 0.0;
		  Ueq_finite_range_minus_tab_uniform_averaged[index_uniform] = source_minus_tab_uniform_averaged[index_uniform] = 0.0;
		}
	    }

	  const unsigned int sending_process = basic_active_process_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , s);
	  
	  complex<double> C0_Cplus[2] = {shell.get_C0 () , shell.get_Cplus ()};
	  
	  MPI_helper::Bcast<complex<double> > (2 , C0_Cplus , sending_process , MPI_COMM_WORLD);
	    
	  if (THIS_PROCESS != sending_process) shell.set_C0 (C0_Cplus[0]) , shell.set_Cplus (C0_Cplus[1]);
	}
    }
  
  if (THIS_PROCESS != MASTER_PROCESS)
    {	
      for (int n = 0 ; n <= nmax ; n++)
	for (int l = 0 ; l <= lmax ; l++)
	  for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	    {
	      const class nlj_struct shell_nlj (false , false , false , false , false , false , false , false , particle , NADA , n , l , j , NO_SEGMENT , NADA , NADA , NADA , NADA , NADA , NADA , NADA , NADA);

	      bool is_there_potential_to_put_to_zero = true;

	      for (unsigned int s = 0 ; is_there_potential_to_put_to_zero && (s < N_nlj) ; s++)
		{
		  class spherical_state &shell = shells(s);

		  if (shell.is_it_filled ())
		    {
		      const class nlj_struct &shell_qn = shells_qn(s);

		      if (same_nlj_particle (shell_nlj , shell_qn)) is_there_potential_to_put_to_zero = false;
		    }
		}

	      if (is_there_potential_to_put_to_zero)
		{
		  const unsigned int zero_index_uniform = Ueq_finite_range_tab_uniform_averaged.index_determine (n , l , j , 0);

		  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) 
		    {
		      const unsigned int index_uniform = zero_index_uniform + i;

		      Ueq_finite_range_tab_uniform_averaged      [index_uniform] = source_tab_uniform_averaged      [index_uniform] = 0.0;
		      Ueq_finite_range_plus_tab_uniform_averaged [index_uniform] = source_plus_tab_uniform_averaged [index_uniform] = 0.0;
		      Ueq_finite_range_minus_tab_uniform_averaged[index_uniform] = source_minus_tab_uniform_averaged[index_uniform] = 0.0;
		    }
		}
	    }
    }
  
  Ueq_finite_range_tab_uniform_averaged.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
  Ueq_finite_range_plus_tab_uniform_averaged.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);

  Ueq_finite_range_minus_tab_uniform_averaged.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
  source_tab_uniform_averaged.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);

  source_plus_tab_uniform_averaged.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);

  source_minus_tab_uniform_averaged.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
}

#endif







// Check if one has to proceed with the HF procedure
// -------------------------------------------------
// The HF procedure must not be done if one has only HO states, natural orbitals, or OCM valence states (i.e. to orthogonalize to the occupied core states) using the basis potential of the core, 
// and of course basis potential is not HF/MSDHF as a start.
// True is returned unless all shells verify previous conditions.

bool HF_potentials_common::is_there_HF_calc_determine (
						       const bool is_it_OCM_basis , 
						       const class baryons_data &prot_data , 
						       const class baryons_data &neut_data)
{
  const enum potential_type basis_potential = prot_data.get_basis_potential ();

  if (basis_potential == HO_POTENTIAL) return false;
  
  const unsigned int Np_nlj = prot_data.get_N_nlj_baryon ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj_baryon ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_data.get_shells_quantum_numbers ();

  for (unsigned int ip = 0 ; ip < Np_nlj ; ip++) 
    {
      const class nlj_struct &shell_p_qn = shells_qn_p(ip);

      const enum particle_type particle = shell_p_qn.get_particle ();

      const int strangeness = particle_strangeness_determine (particle);

      if (strangeness != 0) continue;
	  
      const int lp = shell_p_qn.get_l ();
      
      const bool is_it_HO = shell_p_qn.get_is_it_HO ();

      const bool OCM_valence_state = shell_p_qn.get_OCM_valence_state ();
      
      const bool are_core_basis_potentials_equal_p = are_core_basis_potentials_equal (lp , prot_data);
      
      const bool is_it_natural_orbital = shell_p_qn.get_is_it_natural_orbital ();

      if (!is_it_HO && is_it_OCM_basis && !is_it_natural_orbital && OCM_valence_state && !are_core_basis_potentials_equal_p) return true;
    }

  for (unsigned int in = 0 ; in < Nn_nlj ; in++)
    {
      const class nlj_struct &shell_n_qn = shells_qn_n(in);
      
      const enum particle_type particle = shell_n_qn.get_particle ();

      const int strangeness = particle_strangeness_determine (particle);

      if (strangeness != 0) continue;
      
      const int ln = shell_n_qn.get_l ();

      const bool is_it_HO = shell_n_qn.get_is_it_HO ();

      const bool OCM_valence_state = shell_n_qn.get_OCM_valence_state ();
      
      const bool are_core_basis_potentials_equal_n = are_core_basis_potentials_equal (ln , neut_data);

      const bool is_it_natural_orbital = shell_n_qn.get_is_it_natural_orbital ();

      if (!is_it_HO && is_it_OCM_basis && !is_it_natural_orbital && OCM_valence_state && !are_core_basis_potentials_equal_n) return true;
    }

  const bool is_there_HF_basis = ((basis_potential == HF) || (basis_potential == MSDHF));

  return is_there_HF_basis;
}













// Calculation of all HF/MSDHF/OCM potentials during one iteration
// ---------------------------------------------------------------
// One calculates all HF/MSDHF/OCM potentials from the HF/MSDHF/OCM wave functions calculated before during one iteration. 
// Shells for which k +/- w/(4 Pi) with protons for Coulomb complex scaling (see H_CM_OBMEs.cpp) (pm is +/-) are not calculated 
// if one diagonalizes the HF potential matrix with a HO basis, as they are defined for scattering states only.
// HO overlaps between the HF/MSDHF/OCM wave functions calculated before and HO states are calculated here as well, as they are used in HF/MSDHF/OCM potentials formulas.

void HF_potentials_common::potentials_calc (
					    const bool HO_diag , 
					    const double new_potential_fraction , 
					    const bool good_isospin_basis_potential , 
					    const class CG_str &CGs , 
					    const class interaction_class &inter_data_basis , 
					    const class array<double> &Gaussian_table_GL , 
					    const class multipolar_expansion_str &multipolar_expansion ,
					    class HF_nucleons_data &prot_HF_data , 
					    class HF_nucleons_data &neut_HF_data)
{
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
  
  const bool is_it_SGI      = is_it_SGI_determine      (TBME_inter);
  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);
  
  const bool is_it_OCM_basis = prot_HF_data.get_is_it_OCM_basis ();

  const unsigned int N_bef_R_GL = prot_HF_data.get_N_bef_R_GL ();

  const unsigned int Np_nlj_res = prot_HF_data.get_N_nlj_res ();
  const unsigned int Nn_nlj_res = neut_HF_data.get_N_nlj_res ();

  class SGI_radial_tabs_str prot_radial_tabs(inter_data_basis , Np_nlj_res , N_bef_R_GL);
  class SGI_radial_tabs_str neut_radial_tabs(inter_data_basis , Nn_nlj_res , N_bef_R_GL);

  if (is_it_SGI && !is_it_OCM_basis) 
    {
      SGI_MSGI_part_common::SGI_part_common::radial_dir_exc_tabs_calc (prot_HF_data , inter_data_basis , prot_radial_tabs);
      SGI_MSGI_part_common::SGI_part_common::radial_dir_exc_tabs_calc (neut_HF_data , inter_data_basis , neut_radial_tabs);
    }

  if (!is_it_OCM_basis)
    {
      HO_expansion_part_common::HO_overlaps_calc (inter_data_basis , true , prot_HF_data);
      HO_expansion_part_common::HO_overlaps_calc (inter_data_basis , true , neut_HF_data);

      HO_expansion_part_common::HO_overlaps_calc (inter_data_basis , false , prot_HF_data);
      HO_expansion_part_common::HO_overlaps_calc (inter_data_basis , false , neut_HF_data);
    }

  one_body_nuclear_hamiltonian_part_calc_init (is_it_SGI_MSGI , prot_HF_data);
  one_body_nuclear_hamiltonian_part_calc_init (is_it_SGI_MSGI , neut_HF_data);

  if (is_it_SGI_MSGI && !is_it_OCM_basis)
    {
      SGI_MSGI_part_common::prot_trivially_equivalent_potentials_calc (HO_diag , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , neut_radial_tabs , neut_HF_data , prot_HF_data);
      SGI_MSGI_part_common::neut_trivially_equivalent_potentials_calc (HO_diag , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , neut_radial_tabs , prot_HF_data , neut_HF_data);
    }

  if (!is_it_OCM_basis)
    {	
      HO_expansion_part_common::prot_potentials_HO_basis_calc (CGs , inter_data_basis , neut_HF_data , prot_HF_data);
      HO_expansion_part_common::neut_potentials_HO_basis_calc (CGs , inter_data_basis , prot_HF_data , neut_HF_data);

      HO_expansion_part_common::trivially_equivalent_potentials_calc (HO_diag , inter_data_basis , prot_HF_data);
      HO_expansion_part_common::trivially_equivalent_potentials_calc (HO_diag , inter_data_basis , neut_HF_data);
    }

  if (is_it_COSM) 
    {
      OCM_part_common::trivially_equivalent_potentials_calc (HO_diag , prot_HF_data);
      OCM_part_common::trivially_equivalent_potentials_calc (HO_diag , neut_HF_data);
    }	

  potentials_in_zero_calc (HO_diag , prot_HF_data);
  potentials_in_zero_calc (HO_diag , neut_HF_data);

  trivially_equivalent_potentials_averaged_calc (HO_diag , new_potential_fraction , prot_HF_data);
  trivially_equivalent_potentials_averaged_calc (HO_diag , new_potential_fraction , neut_HF_data);

  if (!HO_diag)
    {
      class HF_nucleons_data &HF_data = (!good_isospin_basis_potential) ? (prot_HF_data) : (neut_HF_data);

      if (!is_it_OCM_basis)
	{
	  HO_expansion_part_common::HO_overlaps_pm_calc ( 1 , inter_data_basis , HF_data);
	  HO_expansion_part_common::HO_overlaps_pm_calc (-1 , inter_data_basis , HF_data);
	}

      one_body_nuclear_hamiltonian_part_shells_pm_calc_init ( 1 , is_it_SGI_MSGI , HF_data);
      one_body_nuclear_hamiltonian_part_shells_pm_calc_init (-1 , is_it_SGI_MSGI , HF_data);

      if (!good_isospin_basis_potential)
	{
	  if (is_it_SGI_MSGI && !is_it_OCM_basis)
	    {
	      SGI_MSGI_part_common::prot_trivially_equivalent_potentials_shells_pm_calc ( 1 , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , neut_radial_tabs , neut_HF_data , prot_HF_data);
	      SGI_MSGI_part_common::prot_trivially_equivalent_potentials_shells_pm_calc (-1 , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , neut_radial_tabs , neut_HF_data , prot_HF_data);
	    }

	  if (!is_it_OCM_basis)
	    {
	      HO_expansion_part_common::trivially_equivalent_potentials_shells_pm_calc ( 1 , inter_data_basis , HF_data);
	      HO_expansion_part_common::trivially_equivalent_potentials_shells_pm_calc (-1 , inter_data_basis , HF_data);
	    }

	  if (is_it_COSM) 
	    {
	      OCM_part_common::trivially_equivalent_potentials_shells_pm_calc ( 1 , HF_data);
	      OCM_part_common::trivially_equivalent_potentials_shells_pm_calc (-1 , HF_data);
	    }
	}
      else
	{
	  if (is_it_SGI_MSGI && !is_it_OCM_basis)
	    {
	      SGI_MSGI_part_common::neut_trivially_equivalent_potentials_shells_pm_calc ( 1 , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , neut_radial_tabs , prot_HF_data , neut_HF_data);
	      SGI_MSGI_part_common::neut_trivially_equivalent_potentials_shells_pm_calc (-1 , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , neut_radial_tabs , prot_HF_data , neut_HF_data);
	    }

	  if (!is_it_OCM_basis) 
	    {
	      HO_expansion_part_common::trivially_equivalent_potentials_shells_pm_calc ( 1 , inter_data_basis , HF_data);
	      HO_expansion_part_common::trivially_equivalent_potentials_shells_pm_calc (-1 , inter_data_basis , HF_data);
	    }

	  if (is_it_COSM) 
	    {
	      OCM_part_common::trivially_equivalent_potentials_shells_pm_calc ( 1 , HF_data);
	      OCM_part_common::trivially_equivalent_potentials_shells_pm_calc (-1 , HF_data);
	    }
	}

      potentials_in_zero_shells_pm_calc ( 1 , HF_data);
      potentials_in_zero_shells_pm_calc (-1 , HF_data);
    }
}
