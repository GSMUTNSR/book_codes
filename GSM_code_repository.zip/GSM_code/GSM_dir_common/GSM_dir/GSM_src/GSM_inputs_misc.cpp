#include "../GSM_include/GSM_include_def_common.h"

using namespace string_routines;
using namespace angular_matrix_elements;
using namespace correlated_state_routines;
using namespace GSM_vector_dimensions;

extern enum called_code_type called_code;

// TYPE is double or complex
// -------------------------

// TBME means two-body matrix element
// ----------------------------------



// Check if all occupied core states are HO states or not when one uses COSM or not
// --------------------------------------------------------------------------------
// One checks if all occupied core states are HO states or not when one uses COSM or not. 
// Indeed, all proton and neutron core states must be HO, or none of them can be.

void inputs_misc::is_it_OCM_HO_core_determine (
					       const class input_data_str &input_data , 
					       class nucleons_data &prot_data , 
					       class nucleons_data &neut_data)
{
  prot_data.is_it_OCM_HO_core_determine_test ();
  neut_data.is_it_OCM_HO_core_determine_test ();

  prot_data.is_it_OCM_HO_core_impose_pp_nn (input_data , neut_data);
  neut_data.is_it_OCM_HO_core_impose_pp_nn (input_data , prot_data);
}








// Minimal and maximal values of different quantum numbers for all fitted nuclei (GSM optimization only)
// -----------------------------------------------------------------------------------------------------
// In the GSM optimization code, one needs the maximal values of proton and neutron valence nucleons (Zval_max_all/Nval_max_all) and orbital angular momenta (lmax_p_all/lmax_n_all), 
// minimal and maximal values of binary parities (BPmin/max_global_pp/nn/pn_all) (see observables_basic_functions.cpp for definition) and total angular momenta (Jmin/max_global_pp/nn/pn_all) for all fitted nuclei. 
// They are calculated here.

int inputs_misc::Zval_max_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  int Zval_max_all = 0;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      Zval_max_all = max (Zval_max_all , input_data.get_Zval ());
    }

  return Zval_max_all;
}

int inputs_misc::Nval_max_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  int Nval_max_all = 0;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      Nval_max_all = max (Nval_max_all , input_data.get_Nval ());
    }

  return Nval_max_all;
}

int inputs_misc::lmax_p_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  int lmax_p_all = 0;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      lmax_p_all = max (lmax_p_all , input_data.get_lmax_p ());
    }

  return lmax_p_all;
}

int inputs_misc::lmax_n_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  int lmax_n_all = 0;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      lmax_n_all = max (lmax_n_all , input_data.get_lmax_n ());
    }

  return lmax_n_all;
}

unsigned int inputs_misc::BPmin_global_pp_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  unsigned int BPmin_global_pp_all = 1;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      BPmin_global_pp_all = min (BPmin_global_pp_all , input_data.get_BPmin_global_pp ());
    }

  return BPmin_global_pp_all;
}

unsigned int inputs_misc::BPmax_global_pp_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  unsigned int BPmax_global_pp_all = 0;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      BPmax_global_pp_all = max (BPmax_global_pp_all , input_data.get_BPmax_global_pp ());
    }

  return BPmax_global_pp_all;
}

unsigned int inputs_misc::BPmin_global_nn_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  unsigned int BPmin_global_nn_all = 1;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      BPmin_global_nn_all = min (BPmin_global_nn_all , input_data.get_BPmin_global_nn ());
    }

  return BPmin_global_nn_all;
}

unsigned int inputs_misc::BPmax_global_nn_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  unsigned int BPmax_global_nn_all = 0;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      BPmax_global_nn_all = max (BPmax_global_nn_all , input_data.get_BPmax_global_nn ());
    }

  return BPmax_global_nn_all;
}

unsigned int inputs_misc::BPmin_global_pn_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  unsigned int BPmin_global_pn_all = 1;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      BPmin_global_pn_all = min (BPmin_global_pn_all , input_data.get_BPmin_global_pn ());
    }

  return BPmin_global_pn_all;
}

unsigned int inputs_misc::BPmax_global_pn_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  unsigned int BPmax_global_pn_all = 0;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      BPmax_global_pn_all = max (BPmax_global_pn_all , input_data.get_BPmax_global_pn ());
    }

  return BPmax_global_pn_all;
}

int inputs_misc::Jmin_global_pp_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  int Jmin_global_pp_all = 1000000;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      Jmin_global_pp_all = min (Jmin_global_pp_all , input_data.get_Jmin_global_pp ());
    }

  return Jmin_global_pp_all;
}

int inputs_misc::Jmax_global_pp_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  int Jmax_global_pp_all = 0;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      Jmax_global_pp_all = max (Jmax_global_pp_all , input_data.get_Jmax_global_pp ());
    }

  return Jmax_global_pp_all;
}

int inputs_misc::Jmin_global_nn_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  int Jmin_global_nn_all = 1000000;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      Jmin_global_nn_all = min (Jmin_global_nn_all , input_data.get_Jmin_global_nn ());
    }

  return Jmin_global_nn_all;
}

int inputs_misc::Jmax_global_nn_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  int Jmax_global_nn_all = 0;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      Jmax_global_nn_all = max (Jmax_global_nn_all , input_data.get_Jmax_global_nn ());
    }

  return Jmax_global_nn_all;
}

int inputs_misc::Jmin_global_pn_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  int Jmin_global_pn_all = 1000000;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      Jmin_global_pn_all = min (Jmin_global_pn_all , input_data.get_Jmin_global_pn ());
    }

  return Jmin_global_pn_all;
}

int inputs_misc::Jmax_global_pn_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  int Jmax_global_pn_all = 0;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);

      Jmax_global_pn_all = max (Jmax_global_pn_all , input_data.get_Jmax_global_pn ());
    }

  return Jmax_global_pn_all;
}

int inputs_misc::Jmin_global_pp_opp_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  int Jmin_global_pp_opp_all = 1000000;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      Jmin_global_pp_opp_all = min (Jmin_global_pp_opp_all , input_data.get_Jmin_global_pp_opp ());
    }

  return Jmin_global_pp_opp_all;
}

int inputs_misc::Jmax_global_pp_opp_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  int Jmax_global_pp_opp_all = 0;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      Jmax_global_pp_opp_all = max (Jmax_global_pp_opp_all , input_data.get_Jmax_global_pp_opp ());
    }

  return Jmax_global_pp_opp_all;
}

int inputs_misc::Jmin_global_nn_opp_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  int Jmin_global_nn_opp_all = 1000000;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      Jmin_global_nn_opp_all = min (Jmin_global_nn_opp_all , input_data.get_Jmin_global_nn_opp ());
    }

  return Jmin_global_nn_opp_all;
}

int inputs_misc::Jmax_global_nn_opp_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  int Jmax_global_nn_opp_all = 0;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      Jmax_global_nn_opp_all = max (Jmax_global_nn_opp_all , input_data.get_Jmax_global_nn_opp ());
    }

  return Jmax_global_nn_opp_all;
}

int inputs_misc::Jmin_global_pn_opp_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  int Jmin_global_pn_opp_all = 1000000;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);
      
      Jmin_global_pn_opp_all = min (Jmin_global_pn_opp_all , input_data.get_Jmin_global_pn_opp ());
    }

  return Jmin_global_pn_opp_all;
}

int inputs_misc::Jmax_global_pn_opp_all_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_fit = input_data_tab.dimension (0);

  int Jmax_global_pn_opp_all = 0;

  for (unsigned int s = 0 ; s < N_nuclei_to_fit ; s++) 
    {
      const class input_data_str &input_data = input_data_tab(s);

      Jmax_global_pn_opp_all = max (Jmax_global_pn_opp_all , input_data.get_Jmax_global_pn_opp ());
    }

  return Jmax_global_pn_opp_all;
}







// Determination if a state is an OCM valence state, i.e. if it has to be orthogonal to core states when using COSM
// ----------------------------------------------------------------------------------------------------------------
// There is nothing to do if one is not in COSM, or if one considers a core state.
// One provides with the (l,j) quantum number of the state, and one loop over all shells to check if there is one or several core states of (l,j) quantum numbers.

bool inputs_misc::OCM_valence_state_determine (
					       const class array<class nlj_struct> &shells_qn , 
					       const bool is_it_COSM , 
					       const bool core_state , 
					       const bool is_it_HO , 
					       const bool is_it_natural_orbital , 
					       const int l , 
					       const double j)
{	
  if (core_state || !is_it_COSM || is_it_HO || is_it_natural_orbital)
    return false;
  else
    {
      const unsigned int N_nlj = shells_qn.dimension (0);

      for (unsigned int s = 0 ; s < N_nlj ; s++)
	{
	  const class nlj_struct &shell_qn_s = shells_qn(s);
	  
	  const bool core_state_s = shell_qn_s.get_core_state ();
	  
	  const int ls = shell_qn_s.get_l ();
	  
	  const double js = shell_qn_s.get_j ();

	  if (core_state_s && same_lj (l , j , ls , js)) return true;
	}

      return false;
    }
}










// Routines here concern input file read. Only general statements will be given here as information is given in the input file and in input_data_str.h
// ---------------------------------------------------------------------------------------------------------------------------------------------------



// Valence nucleons are read for the basis case, i.e. they are used only in the context of basis potential calculation, such as HF, and for Hamiltonian
// ----------------------------------------------------------------------------------------------------------------------------------------------------

void inputs_misc::valence_particle_number_read (
						const bool is_it_basis_only , 
						const enum space_type space , 
						const enum potential_type H_potential , 
						int &Zval , 
						int &Nval)
{
  const string proton_string  = (is_it_basis_only) ? ("proton(s)[basis]") : ("proton(s)");
  const string neutron_string = (is_it_basis_only) ? ("neutron(s)[basis]") : ("neutron(s)");

  if (space != NEUTRONS_ONLY)
    {
      cin >> Zval;

      word_check_print<int> (proton_string , Zval);
    }

  if (space != PROTONS_ONLY)
    {
      cin >> Nval;

      word_check_print<int> (neutron_string , Nval);
    }

  if ((Zval >= 2) && (H_potential == WS)) error_message_print_abort ("No WS potential in hamiltonian with Coulomb interaction when Z >= 2.");
}





// Parameters of the SDI interaction are read here
// -----------------------------------------------

void inputs_misc::SDI_data_read (
				 double &a , 
				 double &b , 
				 double &R0 , 
				 double &V_SDI)
{
  cin >> V_SDI;
  word_check_print<double> ("MeV.fm^3(interaction)" , V_SDI); 

  cin >> R0;
  word_check_print<double> ("fm(R0)" , R0);

  if (R0 <= 0) error_message_print_abort ("R0[SDI] must be positive");
	
  cin >> a;
  word_check_print<double> ("(a)" , a);

  cin >> b;
  word_check_print<double> ("(b)" , b);
}








// J-Pi dependent strengths of the SGI/MSGI/Minnesota/FHT/EFT interaction are read here
// ------------------------------------------------------------------------------------

void inputs_misc::V_Gaussian_consts_read (
					  const enum space_type space ,
					  const int Jmin , 
					  const int Jmax , 
					  const int Jmin_opp , 
					  const int Jmax_opp , 
					  class array<double> &V_Gaussian_consts)
{
  string J_Pi;
	    
  word_check ("J-Pi");
  
  if (space == PROTONS_NEUTRONS) word_check ("V[J,Pi,T=0]");

  word_check ("V[J,Pi,T=1]");

  if (space == PROTONS_NEUTRONS) 
    cout << "J-Pi    V[J,Pi,T=0]    V[J,Pi,T=1]" << endl;
  else
    cout << "J-Pi   V[J,Pi,T=1]" << endl;
  
  for (int J = Jmin_opp ; J <= Jmax_opp ; J++)
    {
      cin >> J_Pi;

      const unsigned int BP_check = determine_Binary_Parity (J_Pi);

      const double J_check = determine_J (J_Pi);

      if ((BP_check != 1) || (J_check != J)) error_message_print_abort ("J-Pi is not correct while reading J,Pi,T parameters (Pi = -1) : read J-Pi=" + J_Pi + ", correct J-Pi=" + J_Pi_string (1 , J));

      if (space == PROTONS_NEUTRONS)
	{
	  cin >> V_Gaussian_consts(1 , J , 0) >> V_Gaussian_consts(1 , J , 1);      

	  cout << J_Pi << "   " << V_Gaussian_consts(1 , J , 0) << "   " << V_Gaussian_consts(1 , J , 1) << endl;
	}
      else
	{
	  cin >> V_Gaussian_consts(1 , J , 1);
      	
	  cout << J_Pi << "   " << V_Gaussian_consts(1 , J , 1) << endl;
	}
    }

  for (int J = Jmin ; J <= Jmax ; J++)
    {
      cin >> J_Pi;

      const unsigned int BP_check = determine_Binary_Parity (J_Pi);

      const double J_check = determine_J (J_Pi);

      if ((BP_check != 0) || (J_check != J)) error_message_print_abort ("J-Pi is not correct while reading J,Pi,T parameters (Pi = 1) : read J-Pi=" + J_Pi + ", correct J-Pi=" + J_Pi_string (0 , J));

      if (space == PROTONS_NEUTRONS)
	{
	  cin >> V_Gaussian_consts(0 , J , 0) >> V_Gaussian_consts(0 , J , 1);
      	
	  cout << J_Pi << "   " << V_Gaussian_consts(0 , J , 0) << "   " << V_Gaussian_consts(0 , J , 1) << endl;
	}
      else
	{

	  cin >> V_Gaussian_consts(0 , J , 1);
      	
	  cout << J_Pi << "   " << V_Gaussian_consts(0 , J , 1) << endl;
	}
    }
}





















// Parameters of the SGI/MSGI interaction radius and range are read here
// ---------------------------------------------------------------------

void inputs_misc::SGI_MSGI_data_read (
				      const enum space_type space ,
				      const int Jmin , 
				      const int Jmax , 
				      const int Jmin_opp , 
				      const int Jmax_opp , 
				      double &R0 , 
				      double &mu , 
				      class array<double> &V_Gaussian_consts)
{ 
  cin >> R0;
  
  if (R0 <= 0) error_message_print_abort ("R0[SGI/MSGI] must be positive");
  
  word_check_print<double> ("fm(R0)" , R0);

  cin >> mu;

  if (mu <= 0) error_message_print_abort ("mu[SGI/MSGI] must be positive");
  
  word_check_print<double> ("fm(mu)" , mu);

  V_Gaussian_consts_read (space , Jmin , Jmax , Jmin_opp , Jmax_opp , V_Gaussian_consts);

  cout << endl;
}








// Parameters of the Minnesota interaction are read here
// -----------------------------------------------------

void inputs_misc::Minnesota_data_read (
				       const enum space_type space ,
				       double V0_Minnesota[] , 
				       double rho_Minnesota[] , 
				       double &u_Minnesota , 
				       double &nu_three_body_like , 
				       double &V_three_body_like , 
				       const int Jmin , 
				       const int Jmax , 
				       const int Jmin_opp , 
				       const int Jmax_opp , 
				       class array<double> &V_Gaussian_consts)
{
  word_check ("V0-Minnesota(MeV)");
  word_check ("rho-Minnesota(fm)");

  for (unsigned int i = 0 ; i < 3 ; i++) cin >> V0_Minnesota[i];

  for (unsigned int i = 0 ; i < 3 ; i++) cin >> rho_Minnesota[i];

  for (unsigned int i = 0 ; i < 3 ; i++) cout << V0_Minnesota[i] << " ";

  cout << endl;
  
  for (unsigned int i = 0 ; i < 3 ; i++) cout << rho_Minnesota[i] << " ";

  cout << endl;
  
  word_check ("u-Minnesota");
  word_check ("nu-3.body(fm^{-2})");
  word_check ("V-3.body(MeV)");

  cin >> u_Minnesota >> nu_three_body_like >> V_three_body_like;
  
  cout << "u-Minnesota   nu-3.body(fm^{-2})   V-3.body(MeV)" << endl;

  cout << "   " << u_Minnesota << "   " << nu_three_body_like << "   " << V_three_body_like << endl << endl;

  const bool is_there_J_Pi_T_dependence = bool_determination_no_print ("J.Parity.T.dependence");

  if (is_there_J_Pi_T_dependence) V_Gaussian_consts_read (space , Jmin , Jmax , Jmin_opp , Jmax_opp , V_Gaussian_consts);

  cout << endl;
}








// Parameters of the FHT interaction are read here
// -----------------------------------------------

void inputs_misc::FHT_read (
			    const enum space_type space ,
			    double &V0_ctr_ot , 
			    double &V0_ctr_et , 
			    double &V0_ctr_os , 
			    double &V0_ctr_es , 
			    double &V0_so_ot , 
			    double &V0_so_et , 
			    double &V0_t_ot , 
			    double &V0_t_et , 
			    const int Jmin , 
			    const int Jmax ,  
			    const int Jmin_opp , 
			    const int Jmax_opp , 
			    class array<double> &V_Gaussian_consts)
{
  V0_ctr_ot = V0_ctr_et = V0_ctr_os = V0_ctr_es = V0_so_ot = V0_so_et = V0_t_ot = V0_t_et = 0.0;

  cin >> V0_ctr_ot;
  
  word_check_print<double> ("(V0.central.odd.triplet(S=1,T=1))" , V0_ctr_ot);

  if (space == PROTONS_NEUTRONS)
    {
      cin >> V0_ctr_et;

      word_check_print<double> ("(V0.central.even.triplet(S=1,T=0))" , V0_ctr_et);
  
      cin >> V0_ctr_os;

      word_check_print<double> ("(V0.central.odd.singlet(S=0,T=0))" , V0_ctr_os);
    }
  
  cin >> V0_ctr_es;
  
  word_check_print<double> ("(V0.central.even.singlet(S=0,T=1))" , V0_ctr_es);

  cin >> V0_so_ot;

  word_check_print<double> ("(V0.spin.orbit.odd.triplet(S=1,T=1))" , V0_so_ot);

  if (space == PROTONS_NEUTRONS)
    {
      cin >> V0_so_et;

      word_check_print<double> ("(V0.spin.orbit.even.triplet(S=1,T=0))" , V0_so_et);
    }
  
  cin >> V0_t_ot;

  word_check_print<double> ("(V0.tensor.odd.triplet(S=1,T=1))" , V0_t_ot);

  if (space == PROTONS_NEUTRONS)
    {
      cin >> V0_t_et;

      word_check_print<double> ("(V0.tensor.even.triplet(S=1,T=0))" , V0_t_et);
    }
  
  const bool is_there_J_Pi_T_dependence = bool_determination_no_print ("J.Parity.T.dependence");

  if (is_there_J_Pi_T_dependence) V_Gaussian_consts_read (space , Jmin , Jmax , Jmin_opp , Jmax_opp , V_Gaussian_consts);

  cout << endl;
}

void inputs_misc::EFT_read (
			    const enum space_type space ,
			    double &VS_const_LO_T0 ,
			    double &VS_const_LO_T1 ,
			    double &VT_sigma_product_LO_T0 ,
			    double &VT_sigma_product_LO_T1 ,
			    double &V1_q2_NLO ,
			    double &V2_k2_NLO ,
			    double &V3_q2_sigma_product_NLO ,
			    double &V4_k2_sigma_product_NLO ,
			    double &V5_sigma_q_vector_k_NLO , 
			    double &V6_sigma_q_product_NLO ,
			    double &V7_sigma_k_product_NLO)
{
  if (space == PROTONS_NEUTRONS)
    {
      cin >> VS_const_LO_T0;

      word_check_print<double> ("(VS.LO(T=0))" , VS_const_LO_T0);
    }
  
  cin >> VS_const_LO_T1;

  word_check_print<double> ("(VS.LO(T=1))" , VS_const_LO_T1);

  if (space == PROTONS_NEUTRONS)
    {
      cin >> VT_sigma_product_LO_T0;

      word_check_print<double> ("(VT.sigma.product.LO(T=0))" , VT_sigma_product_LO_T0);
    }
  
  cin >> VT_sigma_product_LO_T1;

  word_check_print<double> ("(VT.sigma.product.LO(T=1))" , VT_sigma_product_LO_T1);
  
  cin >> V1_q2_NLO;

  word_check_print<double> ("(V1.q.square.NLO)" , V1_q2_NLO);
  
  cin >> V2_k2_NLO;

  word_check_print<double> ("(V2.k.square.NLO)" , V2_k2_NLO);
  
  cin >> V3_q2_sigma_product_NLO;

  word_check_print<double> ("(V3.q.square.sigma.product.NLO)" , V3_q2_sigma_product_NLO);
  
  cin >> V4_k2_sigma_product_NLO;

  word_check_print<double> ("(V4.k.square.sigma.product.NLO)" , V4_k2_sigma_product_NLO);
  
  cin >> V5_sigma_q_vector_k_NLO;

  word_check_print<double> ("(V5.sigma.q.vector.k.NLO)" , V5_sigma_q_vector_k_NLO);
  
  cin >> V6_sigma_q_product_NLO;

  word_check_print<double> ("(V6.sigma.q.product.NLO)" , V6_sigma_q_product_NLO);
  
  cin >> V7_sigma_k_product_NLO;

  word_check_print<double> ("(V7.sigma.k.product.NLO)" , V7_sigma_k_product_NLO);

  cout << endl;
}








// Parameters of the KKNN potential are read here
// ----------------------------------------------

void inputs_misc::KKNN_potential_data_read (
					    double V0_KKNN[] , 
					    double rho_KKNN[] , 
					    double Vls_KKNN[] , 
					    double rho_ls_KKNN[])
{ 
  word_check ("V0(MeV)");
  word_check ("rho(fm)");

  cout << "V0(MeV)   rho(fm)" << endl;
  
  unsigned int ip1_check;
  
  for (unsigned int i = 0 ; i < 5 ; i++)
    {
      cin >> ip1_check >> V0_KKNN[i] >> rho_KKNN[i];
      
      if (ip1_check != i+1) error_message_print_abort ("index is not correct while reading KKN potential parameters: read index=" + make_string<int> (ip1_check) + ", correct index=" + make_string<int> (i+1));
      
      cout << ip1_check << "   " << V0_KKNN[i] << "   " << rho_KKNN[i] << endl;
    }

  cout << endl;

  word_check ("Vls(MeV)");
  word_check ("rho-ls(fm)");
 
  cout << "Vls(MeV)   rho-ls(fm)" << endl;
  
  for (unsigned int i = 0 ; i < 3 ; i++)
    {
      cin >> ip1_check >> Vls_KKNN[i] >> rho_ls_KKNN[i];
      
      if (ip1_check != i + 1) error_message_print_abort ("index is not correct while reading KKNN potential parameters: read index=" + make_string<int> (ip1_check) + ", correct index=" + make_string<int> (i+1));
      
      cout << ip1_check << "   " << Vls_KKNN[i] << "   " << rho_ls_KKNN[i] << endl;
    }

  cout << endl;
}








// Parameters of the WS potential of protons or neutrons are read here
// -------------------------------------------------------------------

void inputs_misc::WS_nucleus_data_read (
					const int lmax , 
					class array<double> &d_tab , 
					class array<double> &R0_tab , 
					class array<double> &Vo_tab , 
					class array<double> &Vso_tab)
{
  word_check ("l");
  word_check ("d(fm)");
  word_check ("R0(fm)");
  word_check ("Vo(MeV)");
  word_check ("Vso(MeV)");
 
  cout << "l   d(fm)   R0(fm)   Vo(MeV)   Vso(MeV)" << endl;

  int l_check;
  
  for (int l = 0 ; l <= lmax ; l++)
    {
      cin >> l_check >> d_tab(l) >> R0_tab(l) >> Vo_tab(l) >> Vso_tab(l); 

      if (R0_tab[l] <= 0) error_message_print_abort ("R0[WS] for l " + make_string<int> (l) + " must be positive");
      
      if (l_check != l) error_message_print_abort ("l is not correct while reading WS parameters: read l=" + make_string<int> (l_check) + ", correct l=" + make_string<int> (l));

      if ((l == 0) && (Vso_tab(l) != 0.0)) error_message_print_abort ("Vso is zero by convention for s1/2 partial waves");
      
      cout << l << "   " << d_tab(l) << "   " << R0_tab(l) << "   " << Vo_tab(l) << "   " << Vso_tab(l) << endl; 
    }

  cout << endl;
}









// Parameters of the WS potential of protons and neutrons are read here
// --------------------------------------------------------------------

void inputs_misc::WS_nucleus_data_prot_neut_read (
						  const enum space_type space , 
						  const int lmax_p , 
						  const int lmax_n , 
						  class array<double> &prot_d_tab , 
						  class array<double> &prot_R0_tab , 
						  class array<double> &prot_Vo_tab , 
						  class array<double> &prot_Vso_tab , 
						  class array<double> &neut_d_tab , 
						  class array<double> &neut_R0_tab , 
						  class array<double> &neut_Vo_tab , 
						  class array<double> &neut_Vso_tab)
{
  cout << endl;
  
  if (space == PROTONS_NEUTRONS)
    {
      word_check ("proton");
      
      cout << "proton" << endl << endl;
    }
  
  if (space != NEUTRONS_ONLY) WS_nucleus_data_read (lmax_p , prot_d_tab , prot_R0_tab , prot_Vo_tab , prot_Vso_tab);

  if (space == PROTONS_NEUTRONS)
    {
      word_check ("neutron");
      
      cout << "neutron" << endl << endl;
    }
  
  if (space != PROTONS_ONLY) WS_nucleus_data_read (lmax_n , neut_d_tab , neut_R0_tab , neut_Vo_tab , neut_Vso_tab);
}








// Maximal numbers of holes are read for proton and neutrons
// ---------------------------------------------------------

void inputs_misc::all_n_holes_max_read (
					const bool is_it_pole_approximation , 
					const enum space_type space , 
					int &n_holes_max , 
					int &n_holes_max_p , 
					int &n_holes_max_n)
{
  const string pole_approximation_string = (is_it_pole_approximation) ? (".pole.approximation") : ("");
  
  switch (space)
    {
    case PROTONS_ONLY: 
      {
	cin >> n_holes_max_p;
      
	word_check_print<int> ("(proton.hole.states" + pole_approximation_string  + ".max)" , n_holes_max_p);

	n_holes_max = n_holes_max_p;
      } break;

    case NEUTRONS_ONLY: 
      {
	cin >> n_holes_max_n;

	word_check_print<int> ("(neutron.hole.states" + pole_approximation_string  + ".max)" , n_holes_max_n);

	n_holes_max = n_holes_max_n;
      } break;

    case PROTONS_NEUTRONS:
      {
	cin >> n_holes_max_p;

	word_check_print<int> ("(proton.hole.states" + pole_approximation_string  + ".max)" , n_holes_max_p);

	cin >> n_holes_max_n;

	word_check_print<int> ("(neutron.hole.states" + pole_approximation_string  + ".max)" , n_holes_max_n);

	cin >> n_holes_max;

	word_check_print<int> ("(total.hole.states" + pole_approximation_string  + ".max)" , n_holes_max);
      } break;

    default: abort_all ();
    }
  
  if (n_holes_max_p < 0) error_message_print_abort ("proton.hole.states must be positive or zero");
  if (n_holes_max_n < 0) error_message_print_abort ("neutron.hole.states must be positive or zero");

  if (n_holes_max < 0) error_message_print_abort ("total.hole.states must be positive or zero");
}




// Maximal numbers of particles in the continuum are read for proton and neutrons
// ------------------------------------------------------------------------------

void inputs_misc::all_n_scat_read (
				   const enum space_type space , 
				   int &n_scat_max , 
				   int &n_scat_max_p , 
				   int &n_scat_max_n)
{
  switch (space)
    {
    case PROTONS_ONLY: 
      {
	cin >> n_scat_max_p;

	word_check_print<int> ("(proton.scattering.states.max)" , n_scat_max_p);

	n_scat_max = n_scat_max_p;
      } break;

    case NEUTRONS_ONLY: 
      {
	cin >> n_scat_max_n;

	word_check_print<int> ("(neutron.scattering.states.max)" , n_scat_max_n);

	n_scat_max = n_scat_max_n;
      } break;

    case PROTONS_NEUTRONS:
      {
	cin >> n_scat_max_p;

	word_check_print<int> ("(proton.scattering.states.max)" , n_scat_max_p);

	cin >> n_scat_max_n;

	word_check_print<int> ("(neutron.scattering.states.max)" , n_scat_max_n);

	cin >> n_scat_max;

	word_check_print<int> ("(total.scattering.states.max)" , n_scat_max);
      } break;

    default: abort_all ();
    }
  
  if (n_scat_max_p < 0) error_message_print_abort ("proton.scattering.states must be positive or zero");
  if (n_scat_max_n < 0) error_message_print_abort ("neutron.scattering.states must be positive or zero");

  if (n_scat_max < 0) error_message_print_abort ("total.scattering.states must be positive or zero");
}












// Parity and total angular momentum are read from the input file for a given composite channel in GSM-CC
// ------------------------------------------------------------------------------------------------------
// An outgoing channel (is_it_out_states is true) can be pole or scattering, so that it has a vector index only in the first case, as it is a bound or resonant state of the spectrum only in this case.
// An incoming channel (is_it_out_states is false) cannot be bound or resonant.

void inputs_misc::CC_composite_data_read (
					  class array<unsigned int> &CC_BP_A_composite_tab , 
					  class array<unsigned int> &CC_vector_index_A_composite_tab , 
					  class array<double> &CC_J_A_composite_tab , 
					  const bool is_it_out_states , 
					  const bool is_it_GSM_pole_state)
{
  const unsigned int N_JPi_A = CC_BP_A_composite_tab.dimension (0);

  for (unsigned int iJPi_A = 0 ; iJPi_A < N_JPi_A ; iJPi_A++)
    {
      string composite;

      cin >> composite;

      cout << composite;

      CC_J_A_composite_tab(iJPi_A) = determine_J (composite);

      CC_BP_A_composite_tab(iJPi_A) = determine_Binary_Parity (composite);
      
      if (is_it_out_states)
	{
	  CC_vector_index_A_composite_tab(iJPi_A) = 0;

	  if (is_it_GSM_pole_state) 
	    {
	      cin >> CC_vector_index_A_composite_tab(iJPi_A);

	      cout << " " << CC_vector_index_A_composite_tab(iJPi_A); 
	    }

	  cout << endl;
	}
      else
	cout << endl;
    }
}










// Data in files starting with eigenvector_E_averaged_n_scat
//----------------------------------------------------------
// The file starting with eigenvector_E_averaged_n_scat for a given many body-state contains its energy and average number of particles in the continuum
// They are read here.
//
// T means target, as one uses these routines in GSM-CC.
// E_tilde is a standard notation for complex energy.

complex<double> inputs_misc::CC_get_energy_from_file (const class correlated_state_str &T_qn)
{
  const string file_name = file_name_eigenvector_string (true , "eigenvector_E_averaged_n_scat" , T_qn);

  ifstream input_file(file_name.c_str() , ios::in);

  file_existence_check (file_name , input_file);

  complex<double> ET_tilde;

  input_file >> ET_tilde;

  input_file.close ();

  return ET_tilde;
}

complex<double> inputs_misc::CC_get_average_n_scat_from_file (const class correlated_state_str &T_qn)
{
  const string file_name = file_name_eigenvector_string (true , "eigenvector_E_averaged_n_scat" , T_qn);

  ifstream input_file(file_name.c_str() , ios::in);

  file_existence_check (file_name , input_file);

  complex<double> ET_tilde;

  complex<double> average_n_scat_number;

  input_file >> ET_tilde >> average_n_scat_number;

  input_file.close ();

  return average_n_scat_number;
}




























// Calculation of the maximal numbers of particles in the continuum from input file values and model space
// -------------------------------------------------------------------------------------------------------
// The maximal number of particles in the continuum might be different from that given in the input file.
// For example, it cannot be larger than the number of valence nucleons and is the number of valence nucleons if one has no such truncation.
// It is calculated here with valence protons/neutrons only (n_scat_max_pp_nn_calc) and with protons and valence neutrons (n_scat_max_pn_calc).

unsigned int inputs_misc::n_scat_max_pp_nn_calc (
						 const bool truncation_ph ,
						 const int n_scat_max_init ,  
						 const class nucleons_data &particles_data)
{
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();
  
  if (!truncation_ph)
    {
      const unsigned int N_nljm_res = particles_data.get_N_nljm_res ();

      const unsigned int N_nljm = particles_data.get_N_nljm ();
      
      const unsigned int N_nljm_scat = N_nljm - N_nljm_res;

      const int n_scat_max = min (N_valence_nucleons , make_int (N_nljm_scat));
      
      return n_scat_max;
    }
  else
    {
      const int n_scat_max = min (N_valence_nucleons , n_scat_max_init);
  
      return n_scat_max;
    }
}

unsigned int inputs_misc::n_scat_max_pn_calc (
					      const bool truncation_ph ,
					      const int n_scat_max_init ,  
					      const class nucleons_data &prot_data , 
					      const class nucleons_data &neut_data)
{
  if (!truncation_ph)
    {
      const int n_scat_max_p = n_scat_max_pp_nn_calc (truncation_ph , NADA , prot_data);
      const int n_scat_max_n = n_scat_max_pp_nn_calc (truncation_ph , NADA , neut_data);

      const int n_scat_max = n_scat_max_p + n_scat_max_n;

      return n_scat_max;
    }
  else
    {
      const int Zval = prot_data.get_N_valence_nucleons ();
      const int Nval = neut_data.get_N_valence_nucleons ();

      const int Aval = Zval + Nval;

      const int n_scat_max = min (Aval , n_scat_max_init);

      return n_scat_max;
    }
}

unsigned int inputs_misc::n_scat_max_modification (
						   const enum space_type space , 
						   const bool truncation_ph , 
						   const class nucleons_data &prot_data , 
						   const class nucleons_data &neut_data , 
						   const int n_scat_max_init)
{
  switch (space)
    {
    case PROTONS_ONLY: return n_scat_max_pp_nn_calc (truncation_ph , n_scat_max_init , prot_data);

    case NEUTRONS_ONLY: return n_scat_max_pp_nn_calc (truncation_ph , n_scat_max_init , neut_data);

    case PROTONS_NEUTRONS: return n_scat_max_pn_calc (truncation_ph , n_scat_max_init , prot_data , neut_data);

    default: abort_all ();
    }

  return NADA;
}


unsigned int inputs_misc::BP_one_configuration_determine (
							  const enum space_type space , 
							  const class nucleons_data &prot_data , 
							  const class nucleons_data &neut_data)
{
  switch (space)
    {
    case PROTONS_ONLY: return prot_data.get_BP_one_configuration ();

    case NEUTRONS_ONLY: return neut_data.get_BP_one_configuration ();

    case PROTONS_NEUTRONS: return binary_parity_product (prot_data.get_BP_one_configuration () , neut_data.get_BP_one_configuration ());
      
    default: return NADA;
    }
}





// Calculation of the minimal truncation energy of model space configurations
// --------------------------------------------------------------------------
// In order to impose energy truncations, one has to know the minimal truncation energy of model space configurations for both proton and neutron spaces.
// It is that of the ground state configuration in the proton and neutron space. It is put to zero if one has neither valence protons or neutrons or shells.
// It is calculated here.

int inputs_misc::E_min_hw_pp_nn (
				 const int N_valence_nucleons ,
				 const class array<class nlj_struct> &shells_qn)
				 
{
  if (N_valence_nucleons == 0) return 0;

  const unsigned int N_nlj = shells_qn.dimension (0);

  if (N_nlj == 0) return 0;
  
  class configuration GS(N_valence_nucleons);
  
  GS.ground_state (0 , shells_qn);

  return GS.E_hw_determine (shells_qn);
}










// Calculation of the number of HO or GHF  states from the knowledge of maximal principal quantum numbers for all partial waves
// ----------------------------------------------------------------------------------------------------------------------------
// One has (nmax_l + 1).(2j + 1) states in an (l,j) partial wave if the maximal principal quantum number in the partial wave of orbital quantum number l is nmax_l.
// These numbers are summed here and returned.

unsigned int inputs_misc::N_nljm_calc (
				       const int lmax ,
				       const class array<int> &nmax_lab_tab)
{
  unsigned int N_nljm = 0;

  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	const int n_max_l = nmax_lab_tab(l);

	const int j_number = make_int (2.0*j + 1.0);

	N_nljm += (n_max_l + 1)*j_number;
      }

  return N_nljm;
}






// Calculation and storage of the <out | j+ | in> and <out | j- | in> matrix elements
// ----------------------------------------------------------------------------------
// One uses the <out | j+ | in> and <out | j- | in> matrix elements when one applies the many-body operators J+ or J-, in the context of J^2 application for example.
// <n l j m+1 | j+ | n l j m> = sqrt (j(j+1) - m(m+1)) and  <n l j m-1 | j+ | n l j m> = sqrt (j(j+1) - m(m-1)). All other matrix elements are equal to zero.
// They are calculated here for protons or neutrons

void inputs_misc::Jminus_OBMEs_calc (
				     const class array<class nljm_struct> &phi_table , 
				     class array<double> &Jminus_tab)
{
  const unsigned int N_nljm = Jminus_tab.dimension (0);

  Jminus_tab = 0.0;

  for (unsigned int state_in = 0 ; state_in < N_nljm ; state_in++)
    for (unsigned int state_out = 0 ; state_out < N_nljm ; state_out++)
      {
	const class nljm_struct &phi_in  = phi_table(state_in);
	const class nljm_struct &phi_out = phi_table(state_out);

	if (same_nlj (phi_in , phi_out))
	  {
	    const double j = phi_in.get_j ();
	    const double m = phi_in.get_m ();

	    const double m_out = phi_out.get_m ();

	    if (rint (m - 1 - m_out) == 0.0) Jminus_tab(state_in , state_out) = sqrt (rint (j*(j + 1) - m*(m - 1)));
	  }
      }
}

void inputs_misc::Jplus_OBMEs_calc (
				    const class array<class nljm_struct> &phi_table , 
				    class array<double> &Jplus_tab)
{
  const unsigned int N_nljm = Jplus_tab.dimension (0);

  Jplus_tab = 0.0;

  for (unsigned int state_in = 0 ; state_in < N_nljm ; state_in++)
    for (unsigned int state_out = 0 ; state_out < N_nljm ; state_out++)
      {
	const class nljm_struct &phi_in  = phi_table(state_in);
	const class nljm_struct &phi_out = phi_table(state_out);

	if (same_nlj (phi_in , phi_out))
	  {
	    const double j = phi_in.get_j ();
	    const double m = phi_in.get_m ();

	    const double m_out = phi_out.get_m ();

	    if (rint (m + 1 - m_out) == 0.0) Jplus_tab(state_in , state_out) = sqrt (rint (j*(j + 1) - m*(m + 1)));
	  }
      }
}

void inputs_misc::Jpm_OBMEs_calc (
				  const int pm , 
				  const class array<class nljm_struct> &phi_table , 
				  class array<double> &Jpm_tab)
{
  switch (pm)
    {      
    case 1:
      {
	Jplus_OBMEs_calc (phi_table , Jpm_tab);
	
      } break;

    case -1:
      {
	Jminus_OBMEs_calc (phi_table , Jpm_tab);
	
      } break;

    default: abort_all ();
    }
}




// Reordering of one-body states from initial to nljm reordering
// -------------------------------------------------------------
// When one calculates the overlap between two Slater determinants whose bases have different radial wave functions,
// they are reordered so that one-body states are arranged in groups of fixed (l,j,m) quantum numbers, in which only the principal quantum number n varies.
// This is the nljm reordering, and related indices are called nljm indices. 
// Quick sort is used here.

void inputs_misc::initial_to_nljm_ordered_states_sort (
						       const int low , 
						       const int high , 
						       const class array<class nljm_struct> &phi_table , 
						       class array<unsigned int> &initial_to_nljm_ordered_states)
{
  const int pivot_index = low + (high - low)/2;
  
  const class nljm_struct phi_pivot = phi_table(initial_to_nljm_ordered_states(pivot_index));

  int i_sort = low , j_sort = high;


  do
    {
      while (phi_table(initial_to_nljm_ordered_states(i_sort)) < phi_pivot) i_sort++;

      while (phi_table(initial_to_nljm_ordered_states(j_sort)) > phi_pivot) j_sort--;

      if (i_sort <= j_sort)
	{
	  swap (initial_to_nljm_ordered_states(i_sort) , initial_to_nljm_ordered_states(j_sort));
	  
	  i_sort++ , j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) initial_to_nljm_ordered_states_sort (low , j_sort , phi_table , initial_to_nljm_ordered_states);
  
  if (i_sort < high) initial_to_nljm_ordered_states_sort (i_sort , high , phi_table , initial_to_nljm_ordered_states); 
}






// Calculation of the indices of GSM eigenvectors of fixed parity and total angular momentum
// -----------------------------------------------------------------------------------------
// When parity and total angular momentum are fixed, different GSM eigenvectors are assigned an index to differentiate them. 
// They start from zero and are increased one by one for each parity and total angular momentum.
//
// One can ask for eigenvectors of arbitrary indices, i.e. the third, fourth, and first excited states, of indices 3,4,1.
// One calculates all eigenvectors at pole approximation level.
// Indeed, one can select among all calculated eigenvectors those of considered indices, 3,4,1 in the example.
// Moreover, all calculated eigenvectors are used to invert H_app in the Jacobi-Davidson method (see GSM_Davidson.cpp).
//
// One only stores on disk the latter eigenvectors at pole approximation level, which will be used as starting points for Lanczos/Jacobi-Davidson methods in full space.
// Hence, in order to store the proper eigenvectors, one uses eigenvector indices 3,4,1,0,2,5,6,7,8,......,
// as one loops only on the number of calculated eigenvectors for disk storage, here 3, so that the eigenvectors of indices 3,4,1 will be stored on disk at pole approximation level.
// The array is obtained by successive swaps on an initial array 0,1,2,3,4,5,6,7,8,...... so that 0,1,2 becomes 3,4,1 with the following sequences:
// 0,1,2,3,4,5,6,7,8,...... -> 3,1,2,0,4,5,6,7,8,...... (0 <-> 3)
// 3,1,2,0,4,5,6,7,8,...... -> 3,4,2,0,1,5,6,7,8,...... (1 <-> 4)
// 3,4,2,0,1,5,6,7,8,...... -> 3,4,1,0,2,5,6,7,8,...... (2 <-> 1)

void inputs_misc::eigensets_vectors_indices_calc (
						  const bool is_it_pole_approximation , 
						  const class nucleons_data &prot_data , 
						  const class nucleons_data &neut_data , 
						  const class array<unsigned long int> &dimensions_good_J , 
						  const class input_data_str &input_data , 
						  class array<unsigned int> &eigenset_vectors_indices)
{	
  const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();
  
  const class array<unsigned int> &BP_eigenset_tab = input_data.get_BP_eigenset_tab ();

  const class array<double> &J_eigenset_tab = input_data.get_J_eigenset_tab ();

  const class array<class correlated_state_str> &PSI_qn_from_file_tab = input_data.get_PSI_qn_from_file_tab ();
  
  const enum space_type space = input_data.get_space ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  
  const bool truncation_ph = (is_it_pole_approximation) ? (true) : (input_data.get_truncation_ph ());
  
  const int n_scat_max_p = (is_it_pole_approximation) ? (0) : (prot_data.get_n_scat_max ());
  const int n_scat_max_n = (is_it_pole_approximation) ? (0) : (neut_data.get_n_scat_max ());
  
  const int n_holes_max_p = (is_it_pole_approximation) ? (prot_data.get_n_holes_max_pole_approximation ()) : (prot_data.get_n_holes_max ());
  const int n_holes_max_n = (is_it_pole_approximation) ? (neut_data.get_n_holes_max_pole_approximation ()) : (neut_data.get_n_holes_max ());
  
  const int Ep_max_hw = (is_it_pole_approximation) ? (prot_data.get_E_max_hw_pole_approximation ()) : (prot_data.get_E_max_hw ());
  const int En_max_hw = (is_it_pole_approximation) ? (neut_data.get_E_max_hw_pole_approximation ()) : (neut_data.get_E_max_hw ());
  
  const int n_holes_max = (is_it_pole_approximation) ? (input_data.get_n_holes_max_pole_approximation   ()) : (input_data.get_n_holes_max ());
  
  const int n_scat_max = (is_it_pole_approximation) ? (0) : (input_data.get_n_scat_max ());
  
  const int E_max_hw = (is_it_pole_approximation) ? (input_data.get_E_max_hw_pole_approximation  ()) : (input_data.get_E_max_hw ());

  const bool J_projected = input_data.get_J_projected ();
  
  const bool all_states_calculated = input_data.get_all_states_calculated ();
  
  const bool all_current_states_considered = (is_it_pole_approximation) ? (true) : (all_states_calculated);
  
  const bool are_pole_states_necessary = (is_it_pole_approximation && !all_states_calculated);

  const unsigned int eigensets_number = input_data.get_eigensets_number ();

  for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
    {      
      const unsigned int BP = BP_eigenset_tab(eigenset_index);
      
      const double J = J_eigenset_tab(eigenset_index);

      const double M = J;

      const int two_J = make_int (2.0*J);

      const int J_index = (two_J%2 == 0) ? (make_int (J)) : (make_int (J - 0.5));

      const unsigned int dimension_good_J_or_M = (J_projected) ? (dimensions_good_J(BP , n_scat_max , J_index)) : (total_space_dimension_M_calc (space , truncation_hw , truncation_ph ,
																		 n_holes_max_p , n_scat_max_p , Ep_max_hw ,
																		 n_holes_max_n , n_scat_max_n , En_max_hw ,
																		 n_holes_max   , n_scat_max   , E_max_hw  , prot_data , neut_data , BP , M));
      if (dimension_good_J_or_M == 0)
	{
	  if (are_pole_states_necessary) error_message_print_abort ("Pole approximation dimension is zero for J-Pi = " + J_Pi_string (BP , J));
	  
	  if (!is_it_pole_approximation) error_message_print_abort ("Full space dimension is zero for J-Pi = " + J_Pi_string (BP , J));
	}

      const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

      const unsigned int vectors_to_find_number = (all_current_states_considered) ? (dimension_good_J_or_M) : (eigenset_vectors_number);

      if (all_current_states_considered)
	{
	  for (unsigned int i = 0 ; i < dimension_good_J_or_M ; i++) eigenset_vectors_indices(eigenset_index , i) = i;
	  
	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {
	      const class correlated_state_str &PSI_qn = PSI_qn_from_file_tab(eigenset_index , i);
	  
	      if ((PSI_qn.get_BP () != BP) || (rint (PSI_qn.get_J () - J) != 0.0))
		error_message_print_abort ("Problem with PSI_qn_from_file_tab in inputs_misc::eigensets_vectors_indices_calc");
	      
	      const unsigned int new_eigenvector_index = PSI_qn.get_vector_index ();

	      const unsigned int old_eigenvector_index = eigenset_vectors_indices(eigenset_index , i);		
	      
	      if (new_eigenvector_index != old_eigenvector_index)
		{	      
		  bool swap_done = false;

		  unsigned int ii = 0;
	      
		  while (!swap_done)
		    {
		      if (eigenset_vectors_indices(eigenset_index , ii) == new_eigenvector_index)
			{		      
			  eigenset_vectors_indices(eigenset_index , i) = new_eigenvector_index;
		      
			  eigenset_vectors_indices(eigenset_index , ii) = old_eigenvector_index;

			  swap_done = true;
			}
		  	      
		      if (!swap_done && (++ii == dimension_good_J_or_M)) error_message_print_abort ("Eigenvector indices too large in inputs_misc::eigensets_vectors_indices_calc");
		    }
		}	  
	    }
	}
      else
	{
	  for (unsigned int i = 0 ; i < vectors_to_find_number ; i++)
	    {
	      const class correlated_state_str &PSI_qn = PSI_qn_from_file_tab(eigenset_index , i);
	  
	      if ((PSI_qn.get_BP () != BP) || (rint (PSI_qn.get_J () - J) != 0.0))
		error_message_print_abort ("Problem with PSI_qn_from_file_tab in inputs_misc::eigensets_vectors_indices_calc");
	      	      
	      eigenset_vectors_indices(eigenset_index , i) = PSI_qn.get_vector_index ();
	    }
	}      
    }
}




// Calls of routines related to the dimension of 1p-1h and 2p-2h subspaces per Slater determinant and print on screen of the optimal hbar omega of protons and neutrons
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates here the number of Slater determinants with parity and M fixed obtained by 1p-1h and 2p-2h excitations from a given Slater determinant.
// This is necessary to apply many-body operators.
// The optimal hbar omega of protons and neutrons is also printed if one uses the Hamiltonian diagonalization code with Berggren basis.
// All maximal numbers of protons and neutrons in the continuum are modified as well.
// The code stops if one uses the Jacobi-Davidson without scattering states, as pole approximation, dealt with the Lanczos method, corresponds to a calculation in full space.
// The optimal hbar omega of the Berggren basis protons and neutrons is also calculated and printed here.

void inputs_misc::space_truncation_data_best_hbar_omega_calc (
							      const bool is_there_cout , 
							      class input_data_str &input_data , 
							      class nucleons_data &prot_data , 
							      class nucleons_data &neut_data)
{
  const enum space_type space = input_data.get_space ();

  const enum interaction_type TBME_inter = input_data.get_inter ();

  const bool only_dimensions = input_data.get_only_dimensions ();
  
  const bool non_zero_NBMEs_proportion_only = input_data.get_non_zero_NBMEs_proportion_only ();
  
  const bool is_it_Lanczos = input_data.get_is_it_Lanczos (); 

  const bool is_it_M_scheme = prot_data.get_is_it_M_scheme ();

  const bool print_detailed_information = input_data.get_print_detailed_information ();

  const bool is_there_cout_detailed = (is_there_cout && print_detailed_information);
  
  if (is_it_M_scheme)
    {
      if (space != NEUTRONS_ONLY) prot_data.dimensions_1p1h_2p2h_space_BP_iM_fixed_max_calc_print (is_there_cout_detailed);
      if (space != PROTONS_ONLY)  neut_data.dimensions_1p1h_2p2h_space_BP_iM_fixed_max_calc_print (is_there_cout_detailed);
    }

  if ((called_code == GSM_CODE) && is_there_cout_detailed && (THIS_PROCESS == MASTER_PROCESS))
    {
      const double b_lab = input_data.get_b_lab ();
      
      cout << endl << "hw:" << 2.0/(two_amu_over_hbar_square*b_lab*b_lab) << " MeV. 3/4 hw:" << 1.5/(two_amu_over_hbar_square*b_lab*b_lab) << " MeV" << endl;

      if (space != NEUTRONS_ONLY) Berggren_basis::best_hbar_omega_b_lab_print (TBME_inter , prot_data);
      if (space != PROTONS_ONLY)  Berggren_basis::best_hbar_omega_b_lab_print (TBME_inter , neut_data);
    }

  const bool truncation_ph = input_data.get_truncation_ph ();

  input_data.all_n_scat_max_modification (space , truncation_ph , prot_data , neut_data);

  const int n_scat_max = input_data.get_n_scat_max ();

  if (!only_dimensions && !non_zero_NBMEs_proportion_only && (called_code != CC_CODE) && (called_code != RDM_CODE) && !is_it_Lanczos && (n_scat_max == 0))
    error_message_print_abort ("The Jacobi-Davidson method cannot be used without scattering or scattering-like one-body states.");

  prot_data.set_n_scat_max (input_data.get_n_scat_max_p ());
  neut_data.set_n_scat_max (input_data.get_n_scat_max_n ());

  if (is_there_cout_detailed && (THIS_PROCESS == MASTER_PROCESS)) cout << endl; //For clarity on screen.
}











// Calculation of the numbers of (l,ml) and (l,j,m) angular states and associated indices. Routines are straightforward and are not detailed
// -----------------------------------------------------------------------------------------------------------------------------------------
// The lmax_ljm and m_max_ljm used below are not necessarily the same as the lmax and the m_max defined in nucleons_data.
// qn means quantum numbers.

unsigned int inputs_misc::lm_number_calc (const int lmax_lm)
{
  unsigned int lm_number = 0;

  for (int l = 0 ; l <= lmax_lm ; l++) lm_number += 2*l + 1;

  return lm_number;
}

void inputs_misc::lm_quantum_numbers_indices_fill (class array<class lm_struct> &lm_qn_table , class lm_table<unsigned int> &lm_indices)
{
  const int lmax_lm = lm_indices.get_lmax (); 

  unsigned int lm_index = 0;

  lm_indices = OUT_OF_RANGE;

  for (int l = 0 ; l <= lmax_lm ; l++)
    for (int ml = -l ; ml <= l ; ml++)
      {
	lm_qn_table(lm_index) = lm_struct (l , ml);
	
	lm_indices(l , ml) = lm_index++;
      }
}

unsigned int inputs_misc::ljm_number_calc (const int lmax_ljm)
{
  unsigned int ljm_number = 0;

  for (int l = 0 ; l <= lmax_ljm ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      ljm_number += make_uns_int (2*j + 1);

  return ljm_number;
}

void inputs_misc::ljm_quantum_numbers_indices_fill (class array<class ljm_struct> &ljm_qn_table , class ljm_table<unsigned int> &ljm_indices)
{
  const int lmax_ljm = ljm_indices.get_lmax (); 

  const double m_max_ljm = lmax_ljm + 0.5;

  ljm_indices = OUT_OF_RANGE;

  unsigned int ljm_index = 0;

  for (int l = 0 ; l <= lmax_ljm ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      for (double m = -j ;  make_int (m - j) <= 0 ; m++)
	{
	  ljm_qn_table(ljm_index) = ljm_struct (l , j , m , m_max_ljm);
	  
	  ljm_indices(l , j , m) = ljm_index++;
	}
}










// Calculation and storage of Clebsch-Gordan coefficients of the form <l ml s ms | j m>
// ------------------------------------------------------------------------------------
// When decoupling orbital angular momentum and spin, one uses Clebsch-Gordan coefficients of the form <l ml s ms | j m>.
// They are calculated and stored here in an array function of lm_index (see above), i_ms (0 for ms = -s, increases by one unit up to ms = s) and ljm_index (see above).

void inputs_misc::CGs_lj_coupling_calc (
					const class array<class lm_struct> &lm_qn_table , 
					const class ljm_table<unsigned int> &ljm_indices , 
					class array<double> &CGs)
{
  const double s = ljm_indices.get_s ();

  const int s_number = make_int (2*s + 1);

  const unsigned int lm_number = lm_qn_table.dimension (0);

  CGs = 0.0;

  for (unsigned int lm_index = 0 ; lm_index < lm_number ; lm_index++)
    {
      const class lm_struct &lm = lm_qn_table(lm_index);

      const int l = lm.get_l ();

      const int ml = lm.get_ml ();

      for (int i_ms = 0 ; i_ms < s_number ; i_ms++)
	{
	  const double ms = i_ms - s;

	  const double m = ml + ms;

	  const double abs_m = abs (m);

	  const double jmin = max (abs (l - s) , abs_m);

	  const double jmax = l + s;
	  
	  const unsigned int j_number = make_int (jmax - jmin) + 1;

	  for (unsigned int j_index = 0 ; j_index < j_number ; j_index++)
	    {
	      const double j = jmin + j_index;
	      
	      const unsigned int ljm_index = ljm_indices(l , j , m);

	      CGs(lm_index , i_ms , ljm_index) = Clebsch_Gordan (l , ml , s , ms , j , m);
	    }
	}
    }
}













// Read of the number of |n l j m> states and |n l j m> states from a file associated to a GSM eigenvector stored on file
// ----------------------------------------------------------------------------------------------------------------------
// Information about the one-body basis |n l j m> states associated to a GSM eigenvector stored on file is stored on file as well, so that one-body indices do not have to be identical.
//
// The numbers of |n l j m> states are stored in file of the form [GSM eigenvector file name]_N_nljm.dat, [GSM eigenvector file name]_Np_nljm.dat, [GSM eigenvector file name]_Nn_nljm.dat 
// for protons/neutrons (only one type of valence particles), protons and neutrons (valence protons and neutrons used). These files are formatted as they contain only one integer.
//
// The |n l j m> states are stored in file of the form [GSM eigenvector file name]_phi_table.dat, [GSM eigenvector file name]_phi_p_table.dat, [GSM eigenvector file name]_phi_n_table.dat 
// for protons/neutrons (only one type of valence particles), protons and neutrons (valence protons and neutrons used). These files are not formatted.
//
// mu is proton or neutron.
//
// When MPI is used with the GSM eigenvector distributed over all nodes (full_common_vectors_used_in_file false in hybrid 1D/2D, 2D partitioning), data are read in parallel.
//
// When MPI is used with the GSM eigenvector entirely stored on all nodes (full_common_vectors_used_in_file true), the master process reads the file and casts data to all other processes.
//
// If one has no valence protons/neutrons and that the number of proton/neutron |n l j m> states is demanded, the current number of proton/neutron |n l j m> states is returned.

unsigned int inputs_misc::Np_nljm_from_file_determine (
						       const string &file_name ,
						       const int Zval ,
						       const int Nval ,
						       const unsigned int Np_nljm)
{
  if (Zval == 0)
    return Np_nljm;
  else if ((Zval != 0) && (Nval == 0))
    {
      const string file_name_N_nljm = file_name + "_N_nljm.dat";

      return dimension_read_disk (file_name_N_nljm);
    }
  else
    {
      const string file_name_Np_nljm = file_name + "_Np_nljm.dat";

      return dimension_read_disk (file_name_Np_nljm);
    }
}

unsigned int inputs_misc::Np_nljm_from_file_determine (
						       const bool full_common_vectors_used_in_file , 
						       const string &file_name ,
						       const int Zval ,
						       const int Nval ,
						       const unsigned int Np_nljm)
{
  if (full_common_vectors_used_in_file)
    {
      unsigned int Np_nljm_from_file = 0;

      if (THIS_PROCESS == MASTER_PROCESS) Np_nljm_from_file = Np_nljm_from_file_determine (file_name , Zval , Nval , Np_nljm);

#ifdef UseMPI      

      MPI_helper::Bcast<unsigned int> (Np_nljm_from_file , MASTER_PROCESS , MPI_COMM_WORLD);

#endif

      return Np_nljm_from_file;
    }
  else
    return Np_nljm_from_file_determine (file_name , Zval , Nval , Np_nljm);
}

unsigned int inputs_misc::Nn_nljm_from_file_determine (
						       const string &file_name ,
						       const int Zval ,
						       const int Nval ,
						       const unsigned int Nn_nljm)
{
  if (Nval == 0)
    return Nn_nljm;
  else if ((Zval == 0) && (Nval != 0))
    {
      const string file_name_N_nljm = file_name + "_N_nljm.dat";

      return dimension_read_disk (file_name_N_nljm);
    }
  else
    {
      const string file_name_Nn_nljm = file_name + "_Nn_nljm.dat";

      return dimension_read_disk (file_name_Nn_nljm);
    }
}

unsigned int inputs_misc::Nn_nljm_from_file_determine (
						       const bool full_common_vectors_used_in_file , 
						       const string &file_name ,
						       const int Zval ,
						       const int Nval ,
						       const unsigned int Nn_nljm)
{
  if (full_common_vectors_used_in_file)
    {
      unsigned int Nn_nljm_from_file = 0;

      if (THIS_PROCESS == MASTER_PROCESS) Nn_nljm_from_file = Nn_nljm_from_file_determine (file_name , Zval , Nval , Nn_nljm);

#ifdef UseMPI
      
      MPI_helper::Bcast<unsigned int> (Nn_nljm_from_file , MASTER_PROCESS , MPI_COMM_WORLD);

#endif

      return Nn_nljm_from_file;
    }
  else
    return Nn_nljm_from_file_determine (file_name , Zval , Nval , Nn_nljm);
}

unsigned int inputs_misc::N_nljm_from_file_determine (
						      const string &file_name ,
						      const int Nval_mu ,
						      const unsigned int N_nljm_mu)
{
  if (Nval_mu == 0)
    return N_nljm_mu;
  else
    {
      const string file_name_N_nljm_mu = file_name + "_N_nljm.dat";

      return dimension_read_disk (file_name_N_nljm_mu);
    }
}

unsigned int inputs_misc::N_nljm_from_file_determine (
						      const bool full_common_vectors_used_in_file , 
						      const string &file_name ,
						      const int Nval_mu ,
						      const unsigned int N_nljm_mu)
{
  if (full_common_vectors_used_in_file)
    {	  
      unsigned int N_nljm_from_file = 0;

      if (THIS_PROCESS == MASTER_PROCESS) N_nljm_from_file = N_nljm_from_file_determine (file_name , Nval_mu , N_nljm_mu);

#ifdef UseMPI
      
      MPI_helper::Bcast<unsigned int> (N_nljm_from_file , MASTER_PROCESS , MPI_COMM_WORLD);
      
#endif

      return N_nljm_from_file;
    }
  else
    return N_nljm_from_file_determine (file_name , Nval_mu , N_nljm_mu);
}

void inputs_misc::phi_p_table_from_file_determine (
						   const string &file_name ,
						   const int Zval ,
						   const int Nval ,
						   const class array<class nljm_struct> &phi_p_table ,
						   class array<class nljm_struct> &phi_p_table_from_file)
{
  if (Zval == 0)
    phi_p_table_from_file = phi_p_table;
  else if ((Zval != 0) && (Nval == 0))
    {
      const string file_name_phi_table = file_name + "_phi_table.dat";

      phi_p_table_from_file.read_disk (file_name_phi_table);
    }
  else
    {
      const string file_name_phi_p_table = file_name + "_phi_p_table.dat";

      phi_p_table_from_file.read_disk (file_name_phi_p_table);
    }
}

void inputs_misc::phi_n_table_from_file_determine (
						   const string &file_name ,
						   const int Zval ,
						   const int Nval ,
						   const class array<class nljm_struct> &phi_n_table ,
						   class array<class nljm_struct> &phi_n_table_from_file)
{
  if (Nval == 0)
    phi_n_table_from_file = phi_n_table;
  else if ((Zval == 0) && (Nval != 0))
    {
      const string file_name_phi_table = file_name + "_phi_table.dat";

      phi_n_table_from_file.read_disk (file_name_phi_table);
    }
  else
    {
      const string file_name_phi_n_table = file_name + "_phi_n_table.dat";

      phi_n_table_from_file.read_disk (file_name_phi_n_table);
    }
}

void inputs_misc::phi_table_from_file_determine (
						 const string &file_name ,
						 const int Nval_mu ,
						 const class array<class nljm_struct> &phi_mu_table ,
						 class array<class nljm_struct> &phi_mu_table_from_file)
{
  if (Nval_mu == 0)
    phi_mu_table_from_file = phi_mu_table;
  else
    {
      const string file_name_phi_mu_table = file_name + "_phi_table.dat";

      phi_mu_table_from_file.read_disk (file_name_phi_mu_table);
    }
}





// Calculation of the number of proton or neutron shells with fixed parity
// -----------------------------------------------------------------------
// When one calculates the number of Slater determinants with parity and M fixed obtained by 1p-1h and 2p-2h excitations from a given Slater determinant,
// one has to know the number of proton or neutron shells with fixed parity. 
// It is calculated and returned here.

unsigned int inputs_misc::N_nlj_fixed_parity_determine (
							const unsigned int bp ,
							const class array<class nlj_struct> &shells_qn)
{
  const unsigned int N_nlj = shells_qn.dimension (0);

  unsigned int N_nlj_fixed_parity = 0;

  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn_s = shells_qn(s);

      const int ls = shell_qn_s.get_l ();

      const unsigned int bp_s = binary_parity_from_orbital_angular_momentum (ls);

      if (bp_s == bp) N_nlj_fixed_parity++;
    }

  return N_nlj_fixed_parity;
}





// Determination of the dimension of the part of an array dealt with by a process when elements are distributed with MPI
// ---------------------------------------------------------------------------------------------------------------------
// One uses the same routine with both parallel and sequential compilations.

unsigned int inputs_misc::process_dimension_determine (
						       const unsigned long int total_dimension ,
						       const unsigned int processes_number ,
						       const unsigned int process)
{ 
#ifdef UseMPI

  const unsigned int process_dimension = basic_process_dimension_determine_for_MPI (total_dimension , processes_number , process);

#else

  if ((processes_number != 1) || (process != MASTER_PROCESS)) error_message_print_abort ("Only the master process can be used in inputs_misc::process_dimension_determine in a sequential run");

  const unsigned int process_dimension = total_dimension;

#endif

  return process_dimension;
}




// Maximal numbers of particles in the continuum for proton and neutrons are copied to a other structure 
// -----------------------------------------------------------------------------------------------------
// CC_Berggren means that the CC_Berggren structures only use the Berggren basis for one-body states in GSM-CC.

void inputs_misc::set_all_n_holes_max_n_scat_max_CC_Berggren_classes (
								      const class input_data_str &input_data ,
								      class input_data_str &input_data_CC_Berggren , 
								      class nucleons_data &prot_data_CC_Berggren ,
								      class nucleons_data &neut_data_CC_Berggren)
{
  const int n_holes_max_p_pole_approximation = input_data.get_n_holes_max_p_pole_approximation ();  
  const int n_holes_max_n_pole_approximation = input_data.get_n_holes_max_n_pole_approximation ();
  
  const int n_holes_max_p = input_data.get_n_holes_max_p ();  
  const int n_holes_max_n = input_data.get_n_holes_max_n ();
  
  const int n_scat_max_p = input_data.get_n_scat_max_p ();  
  const int n_scat_max_n = input_data.get_n_scat_max_n ();
  
  input_data_CC_Berggren.set_all_n_holes_max_n_scat_max_E_max (input_data);
  
  prot_data_CC_Berggren.set_n_holes_max_pole_approximation (n_holes_max_p_pole_approximation);
  neut_data_CC_Berggren.set_n_holes_max_pole_approximation (n_holes_max_n_pole_approximation);
  
  prot_data_CC_Berggren.set_n_holes_max (n_holes_max_p);
  neut_data_CC_Berggren.set_n_holes_max (n_holes_max_n);

  prot_data_CC_Berggren.set_n_scat_max (n_scat_max_p);
  neut_data_CC_Berggren.set_n_scat_max (n_scat_max_n);
}








// Determination of the maximal number of vectors per J-Pi quantum numbers
// -----------------------------------------------------------------------
// This value is used as dimension in arrays of the form T(eigensets_number , vectors_to_find_number_max).
//
// If one does not calculate all states, one is only considering the bound or resonant many-body states, so that one uses the dimensions issued from pole approximation.
// If one calculates all states, one uses the dimensions issued from full space.

unsigned int inputs_misc::vectors_to_find_number_max_determine (
								const class input_data_str &input_data ,
								const class array<unsigned long int> &total_space_dimensions_good_J_pole_approximation ,
								const class array<unsigned long int> &total_space_dimensions_good_J)
{
  const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

  const bool all_states_calculated = input_data.get_all_states_calculated ();

  const unsigned long int eigenset_vectors_number_max = eigenset_vectors_number_tab.max ();

  const unsigned long int total_space_dimensions_good_J_pole_approximation_max = total_space_dimensions_good_J_pole_approximation.max ();

  const unsigned long int total_space_dimensions_good_J_max = total_space_dimensions_good_J.max ();

  const unsigned long int total_space_dimensions_good_J_max_for_calculation = (all_states_calculated) ? (total_space_dimensions_good_J_max) : (total_space_dimensions_good_J_pole_approximation_max);

  const unsigned int vectors_to_find_number_max = max (eigenset_vectors_number_max , total_space_dimensions_good_J_max_for_calculation);

  return vectors_to_find_number_max;
}








// Calculation of HO/GHF overlaps between HO/GHF states and Berggren basis states for both protons and neutrons
// ------------------------------------------------------------------------------------------------------------

void inputs_misc::all_HO_GHF_overlaps_prot_neut_alloc_calc (
							    const class input_data_str &input_data ,
							    class nucleons_data &prot_data ,
							    class nucleons_data &neut_data)
{
  const enum space_type space = input_data.get_space ();
    
  if (space != NEUTRONS_ONLY) prot_data.all_HO_GHF_overlaps_alloc_calc (input_data); 
  if (space != PROTONS_ONLY)  neut_data.all_HO_GHF_overlaps_alloc_calc (input_data); 
}

void inputs_misc::HO_GHF_overlaps_prot_neut_alloc_calc (
							const bool is_it_only_basis , 
							const class input_data_str &input_data ,
							class nucleons_data &prot_data ,
							class nucleons_data &neut_data)
{
  const enum space_type space = input_data.get_space ();
    
  if (space != NEUTRONS_ONLY) prot_data.HO_overlaps_alloc_calc (is_it_only_basis , input_data) , prot_data.GHF_overlaps_alloc_fill (input_data);
  if (space != PROTONS_ONLY)  neut_data.HO_overlaps_alloc_calc (is_it_only_basis , input_data) , neut_data.GHF_overlaps_alloc_fill (input_data);
}
















// The following routines read data from disk to store them in class nucleons_data or copy data from class nucleons_data to disk. See GSM_input_data.h and GSM_nucleons_data.h for information
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// When one uses MPI, data is copied to disk by the master process only.
// When one uses MPI, data is read from disk by the master process only and distributed to all nodes afterwards. 
//
// Arrays which can be copied as formatted on disk in other routinesbut are only copied as unformatted here have "unformatted" in their names.

void inputs_misc::radial_wfs_HF_data_HO_overlaps_basis_copy_disk (
								  const class input_data_str &input_data ,
								  const class nucleons_data &particles_data)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in inputs_misc::radial_wfs_HF_data_HO_overlaps_basis_copy_disk");
    
  const enum interaction_type inter = input_data.get_inter ();
  
  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (inter);

  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const int lmax = particles_data.get_lmax ();

  const enum particle_type particle = particles_data.get_particle ();
      
  const class array<class spherical_state> &shells = particles_data.get_shells ();
  const class array<class spherical_state> &shells_plus = particles_data.get_shells_plus ();
  const class array<class spherical_state> &shells_minus = particles_data.get_shells_minus ();

  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  const class lj_table<class matrix<complex<double> > > &U_finite_range_HF_HO_basis_HO_expansion_part = particles_data.get_U_finite_range_HF_HO_basis_HO_expansion_part ();
 
  const class lj_table<complex<double> > &OBMEs_HF_SGI_MSGI = particles_data.get_OBMEs_HF_SGI_MSGI ();

  const class array<class vector_class<complex<double> > > &HO_overlaps_basis       = particles_data.get_HO_overlaps_basis ();  
  const class array<class vector_class<complex<double> > > &HO_overlaps_basis_Fermi = particles_data.get_HO_overlaps_basis_Fermi ();
  
  if (is_it_SGI_MSGI) OBMEs_HF_SGI_MSGI.copy_disk (STORAGE_DIR + "OBMEs_HF_SGI_MSGI_" + make_string<enum particle_type> (particle));
  
  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	const class matrix<complex<double> > &U_finite_range_HF_HO_basis_HO_expansion_part_lj = U_finite_range_HF_HO_basis_HO_expansion_part(l , j);
	
	U_finite_range_HF_HO_basis_HO_expansion_part_lj.copy_disk (STORAGE_DIR + "U_finite_range_HF_HO_basis_HO_expansion_" + make_string<enum particle_type> (particle) + "_" + angular_state_for_file_name (l , j));
      }
  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_qn(s);
      
      const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

      const bool is_it_HO = shell_qn.get_is_it_HO ();
      
      const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ();

      const bool are_shells_plus_minus_calculated = (!S_matrix_pole && !is_it_HO && !is_it_natural_orbital && (particle == PROTON));
  
      const class spherical_state &shell = shells(s);
      const class spherical_state &shell_plus = shells_plus(s);
      const class spherical_state &shell_minus = shells_minus(s);
      
      shell.copy_to_file (STORAGE_DIR + "wf_");
	  
      if (are_shells_plus_minus_calculated)
	{
	  shell_plus.copy_to_file  (STORAGE_DIR + "wf_plus_");
	  shell_minus.copy_to_file (STORAGE_DIR + "wf_minus_");
	}
    }

  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class vector_class<complex<double> > &HO_overlaps_basis_shell       = HO_overlaps_basis(s);
      const class vector_class<complex<double> > &HO_overlaps_basis_Fermi_shell = HO_overlaps_basis_Fermi(s);
      
      HO_overlaps_basis_shell.copy_disk       (STORAGE_DIR + "HO_overlaps_basis_"       + make_string<int> (s) + "_" + make_string<enum particle_type> (particle));
      HO_overlaps_basis_Fermi_shell.copy_disk (STORAGE_DIR + "HO_overlaps_basis_Fermi_" + make_string<int> (s) + "_" + make_string<enum particle_type> (particle));
    }
}

void inputs_misc::radial_wfs_HF_data_HO_overlaps_basis_prot_neut_copy_disk (
									    const class input_data_str &input_data ,
									    const class nucleons_data &prot_data ,
									    const class nucleons_data &neut_data)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in inputs_misc::radial_wfs_HF_data_HO_overlaps_basis_prot_neut_copy_disk");
  
  const enum space_type space = input_data.get_space ();
    
  if (space != NEUTRONS_ONLY) radial_wfs_HF_data_HO_overlaps_basis_copy_disk (input_data , prot_data);    
  if (space != PROTONS_ONLY)  radial_wfs_HF_data_HO_overlaps_basis_copy_disk (input_data , neut_data);
}

void inputs_misc::radial_wfs_HF_data_HO_overlaps_basis_alloc_read_disk (
									const class input_data_str &input_data ,
									const class nucleons_data &neut_data ,
									class nucleons_data &particles_data)
{
  const class array<int> &nmax_HO_lab_tab = input_data.get_nmax_HO_lab_tab ();
    
  const int lmax = particles_data.get_lmax ();
  
  const int nmax = particles_data.get_nmax ();
  
  const int lmax_for_basis_interaction = input_data.get_lmax_for_basis_interaction ();

  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const enum space_type basis_space = input_data.get_basis_space ();
   
  const enum potential_type H_potential = particles_data.get_H_potential ();

  const enum interaction_type inter = input_data.get_inter ();
      
  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (inter);

  const double R0_inter = input_data.get_R0_inter_basis ();
      
  const int A_basis = particles_data.get_A_basis ();

  const int Z_core = particles_data.get_Z_core ();

  const int Z_charge_basis_potential_init = particles_data.get_Z_charge_basis_potential ();
  
  const bool neutron_basis_potential = particles_data.get_neutron_basis_potential ();

  const class nucleons_data &data_for_potential = (neutron_basis_potential && (basis_space != PROTONS_ONLY)) ? (neut_data) : (particles_data);
      
  const double nu_mass = data_for_potential.get_effective_mass_for_calc ();

  const double nucleus_mass_basis = particles_data.get_nucleus_mass_basis ();

  const bool is_it_COSM = is_it_COSM_determine (inter);

  const double mass_modif = (!is_it_COSM) ? (-nucleus_mass_basis) : (nucleus_mass_basis);
      
  const unsigned int N_bef_R_GL = particles_data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = particles_data.get_N_aft_R_GL ();
  
  const unsigned int N_bef_R_uniform = particles_data.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = particles_data.get_N_aft_R_uniform ();
  
  const unsigned int Nk_momentum_GL  = particles_data.get_Nk_momentum_GL ();
  
  const unsigned int Nk_momentum_uniform = particles_data.get_Nk_momentum_uniform ();
  
  const double R = particles_data.get_R ();

  const double R_real_max = particles_data.get_R_real_max ();
  
  const double kmax_momentum = particles_data.get_kmax_momentum ();

  const double R_Fermi_momentum = particles_data.get_R_Fermi_momentum ();

  const enum particle_type particle = particles_data.get_particle ();
      
  const class lj_table<enum potential_type> &basis_potential_partial_waves = particles_data.get_basis_potential_partial_waves ();

  const class array<double> &R0_core_potential_tab = particles_data.get_R0_core_potential_tab ();
  
  const class array<double> &R0_basis_tab = particles_data.get_R0_basis_tab ();
  
  class lj_table<class matrix<complex<double> > > &U_finite_range_HF_HO_basis_HO_expansion_part = particles_data.get_U_finite_range_HF_HO_basis_HO_expansion_part ();
  
  class lj_table<complex<double> > &OBMEs_HF_SGI_MSGI = particles_data.get_OBMEs_HF_SGI_MSGI ();
  
  class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  class array<class spherical_state> &shells       = particles_data.get_shells ();
  class array<class spherical_state> &shells_plus  = particles_data.get_shells_plus ();
  class array<class spherical_state> &shells_minus = particles_data.get_shells_minus ();  

  class array<class vector_class<complex<double> > > &HO_overlaps_basis       = particles_data.get_HO_overlaps_basis ();
  class array<class vector_class<complex<double> > > &HO_overlaps_basis_Fermi = particles_data.get_HO_overlaps_basis_Fermi ();

  if (is_it_SGI_MSGI)
    {
      const int nmax_plus_one = nmax + 1;
      
      OBMEs_HF_SGI_MSGI.allocate (0.5 , lmax , nmax_plus_one , nmax_plus_one);
      
      if (THIS_PROCESS == MASTER_PROCESS) OBMEs_HF_SGI_MSGI.read_disk (STORAGE_DIR + "OBMEs_HF_SGI_MSGI_" + make_string<enum particle_type> (particle));
      
#ifdef UseMPI

      OBMEs_HF_SGI_MSGI.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

#endif
    }
  
  U_finite_range_HF_HO_basis_HO_expansion_part.allocate (0.5 , lmax);
  
  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	class matrix<complex<double> > &U_finite_range_HF_HO_basis_HO_expansion_part_lj = U_finite_range_HF_HO_basis_HO_expansion_part(l , j);

	const int nmax_HO_l = (l <= lmax_for_basis_interaction) ? (nmax_HO_lab_tab(l)) : (0);
	
	U_finite_range_HF_HO_basis_HO_expansion_part_lj.allocate (nmax_HO_l + 1);
	
	if (THIS_PROCESS == MASTER_PROCESS)
	  U_finite_range_HF_HO_basis_HO_expansion_part_lj.read_disk (STORAGE_DIR + "U_finite_range_HF_HO_basis_HO_expansion_" + make_string<enum particle_type> (particle) + "_" + angular_state_for_file_name (l , j));
	
#ifdef UseMPI
	U_finite_range_HF_HO_basis_HO_expansion_part_lj.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);	  
#endif
      }
  
  shells.allocate (N_nlj);
  shells_plus.allocate (N_nlj);
  shells_minus.allocate (N_nlj);
  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      class nlj_struct &shell_qn = shells_qn(s);      
  
      const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

      const bool is_it_HO = shell_qn.get_is_it_HO ();

      const bool core_state = shell_qn.get_core_state ();

      const bool frozen_state = shell_qn.get_frozen_state ();

      const bool hole_state = shell_qn.get_hole_state ();

      const bool is_it_for_HF_gs = shell_qn.get_is_it_for_HF_gs ();

      const bool OCM_valence_state = shell_qn.get_OCM_valence_state ();

      const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ();

      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();

      const int e_trunc = shell_qn.get_e_trunc ();

      const double j = shell_qn.get_j ();
      
      const double R0 = (core_state) ? (R0_core_potential_tab(l)) : (R0_basis_tab(l));
      
      const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);
      
      const enum segment_type segment = shell_qn.get_segment ();

      const complex<double> k       = shell_qn.get_k ();
      const complex<double> k_plus  = shell_qn.get_k_plus ();
      const complex<double> k_minus = shell_qn.get_k_minus ();
  
      const int Z_charge_basis_potential = (core_state && (particle == PROTON)) ? (Z_core) : (Z_charge_basis_potential_init);

      const enum potential_type basis_potential_if_it_exists = (is_it_natural_orbital) ? (NO_POTENTIAL) : (basis_potential_partial_waves(l , j));
      
      const enum potential_type basis_potential_init_no_HO = (core_state) ? (H_potential) : (basis_potential_if_it_exists);

      const enum potential_type basis_potential_init = (is_it_HO) ? (HO_POTENTIAL) : (basis_potential_init_no_HO);

      const bool are_core_basis_potentials_equal_wf = are_core_basis_potentials_equal (l , particles_data);

      const enum potential_type basis_potential = (OCM_valence_state && !are_core_basis_potentials_equal_wf && !is_it_HO) ? (HF) : (basis_potential_init);

      const bool is_basis_potential_local = ((basis_potential != HF) && (basis_potential != MSDHF));

      const bool is_there_starting_point = S_matrix_pole && !is_it_natural_orbital && (core_state || is_basis_potential_local);

      const bool are_there_scaled_wfs = !is_it_natural_orbital;
      
      const bool are_shells_plus_minus_calculated = (!S_matrix_pole && !is_it_HO && !is_it_natural_orbital && (particle == PROTON));
      
      const complex<double> w = shell_qn.get_w ();
      
      const complex<double> C0       = (!is_basis_potential_local) ? (shell_qn.get_C0 ())      : (1.0);
      const complex<double> C0_plus  = (!is_basis_potential_local) ? (shell_qn.get_C0_plus ()) : (1.0);
      const complex<double> C0_minus = (!is_basis_potential_local) ? (shell_qn.get_C0_minus ()) : (1.0);
      
      const complex<double> Cplus = (!is_basis_potential_local) ? (shell_qn.get_Cplus ()) : (1.0);
  
      class spherical_state &shell       = shells(s);
      class spherical_state &shell_plus  = shells_plus(s);
      class spherical_state &shell_minus = shells_minus(s);

      shell.allocate (false , are_there_scaled_wfs , basis_potential , A_basis , Z_charge_basis_potential , mass_modif , NADA ,
		      N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , Nk_momentum_GL , Nk_momentum_uniform ,
		      R , NADA , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , S_matrix_pole , particle , n , NADA , l , j , is_there_starting_point , k , nu_mass , C0 , Cplus);

      if (are_shells_plus_minus_calculated)
	{
	  shell_plus.allocate (false , are_there_scaled_wfs , basis_potential , A_basis , Z_charge_basis_potential , mass_modif , NADA ,
			       N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , Nk_momentum_GL , Nk_momentum_uniform ,
			       R , NADA , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , S_matrix_pole , particle , n , NADA , l , j , false , k_plus , nu_mass , C0_plus , NADA); 
	    
	  shell_minus.allocate (false , are_there_scaled_wfs , basis_potential , A_basis , Z_charge_basis_potential , mass_modif , NADA ,
				N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , Nk_momentum_GL , Nk_momentum_uniform ,
				R , NADA , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , S_matrix_pole , particle , n , NADA , l , j , false , k_minus , nu_mass , C0_minus , NADA); 
	}
      
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  shell.get_from_file (STORAGE_DIR + "wf_");
      
	  if (are_shells_plus_minus_calculated)
	    {
	      shell_plus.get_from_file  (STORAGE_DIR + "wf_plus_");
	      shell_minus.get_from_file (STORAGE_DIR + "wf_minus_");
	    }
	}
      
#ifdef UseMPI

      shell.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

      if (are_shells_plus_minus_calculated)
	{
	  shell_plus.MPI_Bcast  (MASTER_PROCESS , MPI_COMM_WORLD);
	  shell_minus.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
	}
	  
#endif
      
      const complex<double> new_C0 = shell.get_C0 ();

      const complex<double> new_Cplus = shell.get_Cplus ();

      const complex<double> new_k = shell.get_k ();

      shell_qn.initialize (S_matrix_pole , core_state , frozen_state , hole_state , OCM_valence_state , is_it_HO , is_it_for_HF_gs , is_it_natural_orbital ,
			   e_trunc , n , l , j , segment , new_k , w , new_C0 , new_Cplus , k_plus , C0_plus , k_minus , C0_minus);
    }
  
  HO_overlaps_basis.allocate (N_nlj);
  HO_overlaps_basis_Fermi.allocate (N_nlj);
  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_qn(s);
      
      const int l = shell_qn.get_l ();
      
      const int nmax_HO_l = (l <= lmax_for_basis_interaction) ? (nmax_HO_lab_tab(l)) : (0);
      
      const int nmax_HO_l_plus_one = nmax_HO_l + 1;
  
      class vector_class<complex<double> > &HO_overlaps_basis_shell       = HO_overlaps_basis(s);
      class vector_class<complex<double> > &HO_overlaps_basis_Fermi_shell = HO_overlaps_basis_Fermi(s);

      HO_overlaps_basis_shell.allocate (nmax_HO_l_plus_one);
      HO_overlaps_basis_Fermi_shell.allocate (nmax_HO_l_plus_one);
	
      HO_overlaps_basis_shell.read_disk       (STORAGE_DIR + "HO_overlaps_basis_"       + make_string<int> (s) + "_" + make_string<enum particle_type> (particle));
      HO_overlaps_basis_Fermi_shell.read_disk (STORAGE_DIR + "HO_overlaps_basis_Fermi_" + make_string<int> (s) + "_" + make_string<enum particle_type> (particle));
    }
}

void inputs_misc::radial_wfs_HF_data_HO_overlaps_basis_prot_neut_alloc_read_disk (
										  const class input_data_str &input_data ,
										  class nucleons_data &prot_data ,
										  class nucleons_data &neut_data)
{
  const enum space_type basis_space = input_data.get_basis_space ();
  
  const enum space_type space = input_data.get_space ();

  const class nucleons_data &neut_data_like = (basis_space == PROTONS_ONLY) ? (prot_data) : (neut_data);

  if (space != NEUTRONS_ONLY) radial_wfs_HF_data_HO_overlaps_basis_alloc_read_disk (input_data , neut_data_like , prot_data);    
  if (space != PROTONS_ONLY)  radial_wfs_HF_data_HO_overlaps_basis_alloc_read_disk (input_data , neut_data_like , neut_data);
}

void inputs_misc::coupled_one_body_tab_copy_disk (
						  const string debut_file_name , 
						  const enum interaction_type Op_inter , 
						  const class nucleons_data &particles_data ,
						  const class array<TYPE> &coupled_one_body_tab)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in inputs_misc::coupled_one_body_tab_copy_disk (1)");

  const enum particle_type particle = particles_data.get_particle ();

  const string coupled_one_body_tab_file_name = STORAGE_DIR + debut_file_name + make_string<enum particle_type> (particle) + "_" + make_string<enum interaction_type> (Op_inter) + ".dat";

  coupled_one_body_tab.copy_disk (coupled_one_body_tab_file_name);
}

void inputs_misc::coupled_one_body_tab_copy_disk (
						  const string debut_file_name , 
						  const enum operator_type Op_inter , 
						  const class nucleons_data &particles_data ,
						  const class array<TYPE> &coupled_one_body_tab)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in inputs_misc::coupled_one_body_tab_copy_disk (2)");

  const enum particle_type particle = particles_data.get_particle ();

  const string coupled_one_body_tab_file_name = STORAGE_DIR + debut_file_name + make_string<enum particle_type> (particle) + "_" + make_string<enum operator_type> (Op_inter) + ".dat";

  coupled_one_body_tab.copy_disk (coupled_one_body_tab_file_name);
}

void inputs_misc::OBMEs_inter_HO_GHF_overlaps_copy_disk (
							 const class input_data_str &input_data , 
							 const class nucleons_data &particles_data)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in inputs_misc::OBMEs_inter_HO_GHF_overlaps_copy_disk");

  const enum interaction_type TBME_inter = input_data.get_inter ();
  
  const enum particle_type particle = particles_data.get_particle ();

  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const class OBMEs_inter_set_str &OBMEs_inter_set = particles_data.get_OBMEs_inter_set ();

  const class array<class vector_class<complex<double> > > &HO_overlaps       = particles_data.get_HO_overlaps ();
  const class array<class vector_class<complex<double> > > &HO_overlaps_Fermi = particles_data.get_HO_overlaps_Fermi ();
  
  const class array<class vector_class<complex<double> > > &GHF_overlaps = particles_data.get_GHF_overlaps ();
  
  coupled_one_body_tab_copy_disk ("OBMEs_unformatted_" , TBME_inter , particles_data , OBMEs_inter_set(TBME_inter));

  coupled_one_body_tab_copy_disk ("OBMEs_unformatted_" , ONE_BODY_NUCLEAR , particles_data , OBMEs_inter_set(ONE_BODY_NUCLEAR));
  coupled_one_body_tab_copy_disk ("OBMEs_unformatted_" , ONE_BODY_KINETIC , particles_data , OBMEs_inter_set(ONE_BODY_KINETIC));
  coupled_one_body_tab_copy_disk ("OBMEs_unformatted_" , ONE_BODY_COULOMB , particles_data , OBMEs_inter_set(ONE_BODY_COULOMB));
  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class vector_class<complex<double> > &HO_overlaps_shell       = HO_overlaps(s);
      const class vector_class<complex<double> > &HO_overlaps_Fermi_shell = HO_overlaps_Fermi(s);
      
      const class vector_class<complex<double> > &GHF_overlaps_shell = GHF_overlaps(s);
      
      HO_overlaps_shell.copy_disk       (STORAGE_DIR + "HO_overlaps_"       + make_string<int> (s) + "_" + make_string<enum particle_type> (particle));      
      HO_overlaps_Fermi_shell.copy_disk (STORAGE_DIR + "HO_overlaps_Fermi_" + make_string<int> (s) + "_" + make_string<enum particle_type> (particle));
      
      GHF_overlaps_shell.copy_disk (STORAGE_DIR + "GHF_overlaps_" + make_string<int> (s) + "_" + make_string<enum particle_type> (particle));
    }
}

void inputs_misc::all_OBMEs_inter_HO_GHF_overlaps_copy_disk (
							     const class input_data_str &input_data ,
							     const class nucleons_data &prot_data , 
							     const class nucleons_data &neut_data)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in inputs_misc::all_OBMEs_inter_HO_GHF_overlaps_copy_disk");
  
  const enum space_type space = input_data.get_space ();
  
  if (space != NEUTRONS_ONLY) OBMEs_inter_HO_GHF_overlaps_copy_disk (input_data , prot_data);
  if (space != PROTONS_ONLY)  OBMEs_inter_HO_GHF_overlaps_copy_disk (input_data , neut_data); 
}

void inputs_misc::reduced_grad_set_copy_disk (const class nucleons_data &particles_data)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in inputs_misc::reduced_grad_set_copy_disk");
  
  const class OBMEs_CM_set_str &reduced_grad_HO_expansion_set = particles_data.get_reduced_grad_HO_expansion_set ();

  coupled_one_body_tab_copy_disk ("reduced_grad_tab_HO_expansion_unformatted_" , CM_KINETIC                    , particles_data , reduced_grad_HO_expansion_set(CM_KINETIC));
  coupled_one_body_tab_copy_disk ("reduced_grad_tab_HO_expansion_unformatted_" , HCM                           , particles_data , reduced_grad_HO_expansion_set(HCM));
  coupled_one_body_tab_copy_disk ("reduced_grad_tab_HO_expansion_unformatted_" , L_REDUCED_TENSOR              , particles_data , reduced_grad_HO_expansion_set(L_REDUCED_TENSOR));
  coupled_one_body_tab_copy_disk ("reduced_grad_tab_HO_expansion_unformatted_" , A_DAGGER_CM_HO_REDUCED_TENSOR , particles_data , reduced_grad_HO_expansion_set(A_DAGGER_CM_HO_REDUCED_TENSOR));
      
  const class OBMEs_CM_set_str &reduced_grad_R_cut_set = particles_data.get_reduced_grad_R_cut_set ();
      
  coupled_one_body_tab_copy_disk ("reduced_grad_tab_R_cut_unformatted_" , CM_KINETIC                    , particles_data , reduced_grad_R_cut_set(CM_KINETIC));
  coupled_one_body_tab_copy_disk ("reduced_grad_tab_R_cut_unformatted_" , HCM                           , particles_data , reduced_grad_R_cut_set(HCM));
  coupled_one_body_tab_copy_disk ("reduced_grad_tab_R_cut_unformatted_" , L_REDUCED_TENSOR              , particles_data , reduced_grad_R_cut_set(L_REDUCED_TENSOR));
  coupled_one_body_tab_copy_disk ("reduced_grad_tab_R_cut_unformatted_" , A_DAGGER_CM_HO_REDUCED_TENSOR , particles_data , reduced_grad_R_cut_set(A_DAGGER_CM_HO_REDUCED_TENSOR));
}

void inputs_misc::reduced_r_set_copy_disk (const class nucleons_data &particles_data)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in inputs_misc::reduced_r_set_copy_disk");

  const class OBMEs_CM_set_str &reduced_r_HO_expansion_set = particles_data.get_reduced_r_HO_expansion_set ();

  coupled_one_body_tab_copy_disk ("reduced_r_tab_HO_expansion_unformatted_" , HCM                           , particles_data , reduced_r_HO_expansion_set(HCM));
  coupled_one_body_tab_copy_disk ("reduced_r_tab_HO_expansion_unformatted_" , RMS_RADIUS_PROTON             , particles_data , reduced_r_HO_expansion_set(RMS_RADIUS_PROTON));
  coupled_one_body_tab_copy_disk ("reduced_r_tab_HO_expansion_unformatted_" , RMS_RADIUS_NEUTRON            , particles_data , reduced_r_HO_expansion_set(RMS_RADIUS_NEUTRON));
  coupled_one_body_tab_copy_disk ("reduced_r_tab_HO_expansion_unformatted_" , L_REDUCED_TENSOR              , particles_data , reduced_r_HO_expansion_set(L_REDUCED_TENSOR));
  coupled_one_body_tab_copy_disk ("reduced_r_tab_HO_expansion_unformatted_" , A_DAGGER_CM_HO_REDUCED_TENSOR , particles_data , reduced_r_HO_expansion_set(A_DAGGER_CM_HO_REDUCED_TENSOR));
      
  const class OBMEs_CM_set_str &reduced_r_R_cut_set = particles_data.get_reduced_r_R_cut_set ();
      
  coupled_one_body_tab_copy_disk ("reduced_r_tab_R_cut_unformatted_" , HCM                           , particles_data , reduced_r_R_cut_set(HCM));
  coupled_one_body_tab_copy_disk ("reduced_r_tab_R_cut_unformatted_" , RMS_RADIUS_PROTON             , particles_data , reduced_r_R_cut_set(RMS_RADIUS_PROTON));
  coupled_one_body_tab_copy_disk ("reduced_r_tab_R_cut_unformatted_" , RMS_RADIUS_NEUTRON            , particles_data , reduced_r_R_cut_set(RMS_RADIUS_NEUTRON));
  coupled_one_body_tab_copy_disk ("reduced_r_tab_R_cut_unformatted_" , L_REDUCED_TENSOR              , particles_data , reduced_r_R_cut_set(L_REDUCED_TENSOR));
  coupled_one_body_tab_copy_disk ("reduced_r_tab_R_cut_unformatted_" , A_DAGGER_CM_HO_REDUCED_TENSOR , particles_data , reduced_r_R_cut_set(A_DAGGER_CM_HO_REDUCED_TENSOR));
}

void inputs_misc::reduced_r_rms_radius_pn_set_copy_disk (const class nucleons_data &particles_data)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in inputs_misc::reduced_r_rms_radius_pn_set_copy_disk");

  const class OBMEs_CM_set_str &reduced_r_HO_expansion_rms_radius_pn_set = particles_data.get_reduced_r_HO_expansion_rms_radius_pn_set ();

  coupled_one_body_tab_copy_disk ("reduced_r_rms_radius_pn_tab_HO_expansion_unformatted_" , HCM                           , particles_data , reduced_r_HO_expansion_rms_radius_pn_set(HCM));
  coupled_one_body_tab_copy_disk ("reduced_r_rms_radius_pn_tab_HO_expansion_unformatted_" , RMS_RADIUS_PROTON             , particles_data , reduced_r_HO_expansion_rms_radius_pn_set(RMS_RADIUS_PROTON));
  coupled_one_body_tab_copy_disk ("reduced_r_rms_radius_pn_tab_HO_expansion_unformatted_" , RMS_RADIUS_NEUTRON            , particles_data , reduced_r_HO_expansion_rms_radius_pn_set(RMS_RADIUS_NEUTRON));
  coupled_one_body_tab_copy_disk ("reduced_r_rms_radius_pn_tab_HO_expansion_unformatted_" , L_REDUCED_TENSOR              , particles_data , reduced_r_HO_expansion_rms_radius_pn_set(L_REDUCED_TENSOR));
  coupled_one_body_tab_copy_disk ("reduced_r_rms_radius_pn_tab_HO_expansion_unformatted_" , A_DAGGER_CM_HO_REDUCED_TENSOR , particles_data , reduced_r_HO_expansion_rms_radius_pn_set(A_DAGGER_CM_HO_REDUCED_TENSOR));
      
  const class OBMEs_CM_set_str &reduced_r_R_cut_rms_radius_pn_set = particles_data.get_reduced_r_R_cut_rms_radius_pn_set ();
      
  coupled_one_body_tab_copy_disk ("reduced_r_rms_radius_pn_tab_R_cut_unformatted_" , HCM                           , particles_data , reduced_r_R_cut_rms_radius_pn_set(HCM));
  coupled_one_body_tab_copy_disk ("reduced_r_rms_radius_pn_tab_R_cut_unformatted_" , RMS_RADIUS_PROTON             , particles_data , reduced_r_R_cut_rms_radius_pn_set(RMS_RADIUS_PROTON));
  coupled_one_body_tab_copy_disk ("reduced_r_rms_radius_pn_tab_R_cut_unformatted_" , RMS_RADIUS_NEUTRON            , particles_data , reduced_r_R_cut_rms_radius_pn_set(RMS_RADIUS_NEUTRON));
  coupled_one_body_tab_copy_disk ("reduced_r_rms_radius_pn_tab_R_cut_unformatted_" , L_REDUCED_TENSOR              , particles_data , reduced_r_R_cut_rms_radius_pn_set(L_REDUCED_TENSOR));
  coupled_one_body_tab_copy_disk ("reduced_r_rms_radius_pn_tab_R_cut_unformatted_" , A_DAGGER_CM_HO_REDUCED_TENSOR , particles_data , reduced_r_R_cut_rms_radius_pn_set(A_DAGGER_CM_HO_REDUCED_TENSOR));
}

void inputs_misc::OBMEs_CM_set_copy_disk (const class nucleons_data &particles_data)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in inputs_misc::OBMEs_CM_set_copy_disk");

  const class OBMEs_CM_set_str &OBMEs_CM_set_HO_expansion = particles_data.get_OBMEs_CM_set_HO_expansion ();

  coupled_one_body_tab_copy_disk ("OBMEs_HO_expansion_unformatted_" , CM_KINETIC                    , particles_data , OBMEs_CM_set_HO_expansion(CM_KINETIC));
  coupled_one_body_tab_copy_disk ("OBMEs_HO_expansion_unformatted_" , HCM                           , particles_data , OBMEs_CM_set_HO_expansion(HCM));
  coupled_one_body_tab_copy_disk ("OBMEs_HO_expansion_unformatted_" , RMS_RADIUS_PROTON             , particles_data , OBMEs_CM_set_HO_expansion(RMS_RADIUS_PROTON));
  coupled_one_body_tab_copy_disk ("OBMEs_HO_expansion_unformatted_" , RMS_RADIUS_NEUTRON            , particles_data , OBMEs_CM_set_HO_expansion(RMS_RADIUS_NEUTRON));
  coupled_one_body_tab_copy_disk ("OBMEs_HO_expansion_unformatted_" , L_REDUCED_TENSOR              , particles_data , OBMEs_CM_set_HO_expansion(L_REDUCED_TENSOR));
  coupled_one_body_tab_copy_disk ("OBMEs_HO_expansion_unformatted_" , A_DAGGER_CM_HO_REDUCED_TENSOR , particles_data , OBMEs_CM_set_HO_expansion(A_DAGGER_CM_HO_REDUCED_TENSOR));
      
  const class OBMEs_CM_set_str &OBMEs_CM_set_R_cut = particles_data.get_OBMEs_CM_set_R_cut ();
      
  coupled_one_body_tab_copy_disk ("OBMEs_R_cut_unformatted_" , CM_KINETIC                    , particles_data , OBMEs_CM_set_R_cut(CM_KINETIC));
  coupled_one_body_tab_copy_disk ("OBMEs_R_cut_unformatted_" , HCM                           , particles_data , OBMEs_CM_set_R_cut(HCM));
  coupled_one_body_tab_copy_disk ("OBMEs_R_cut_unformatted_" , RMS_RADIUS_PROTON             , particles_data , OBMEs_CM_set_R_cut(RMS_RADIUS_PROTON));
  coupled_one_body_tab_copy_disk ("OBMEs_R_cut_unformatted_" , RMS_RADIUS_NEUTRON            , particles_data , OBMEs_CM_set_R_cut(RMS_RADIUS_NEUTRON));
  coupled_one_body_tab_copy_disk ("OBMEs_R_cut_unformatted_" , L_REDUCED_TENSOR              , particles_data , OBMEs_CM_set_R_cut(L_REDUCED_TENSOR));
  coupled_one_body_tab_copy_disk ("OBMEs_R_cut_unformatted_" , A_DAGGER_CM_HO_REDUCED_TENSOR , particles_data , OBMEs_CM_set_R_cut(A_DAGGER_CM_HO_REDUCED_TENSOR));
}

void inputs_misc::all_OBMEs_CM_reduced_r_grad_sets_copy_disk (
							      const enum space_type space ,
							      const class nucleons_data &prot_data , 
							      const class nucleons_data &neut_data)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in inputs_misc::all_OBMEs_CM_reduced_r_grad_sets_copy_disk");

  if (space != NEUTRONS_ONLY)
    {
      reduced_grad_set_copy_disk (prot_data);

      reduced_r_set_copy_disk (prot_data);

      reduced_r_rms_radius_pn_set_copy_disk (prot_data);
      
      OBMEs_CM_set_copy_disk (prot_data);
    }
  
  if (space != PROTONS_ONLY)
    {
      reduced_grad_set_copy_disk (neut_data);

      reduced_r_set_copy_disk (neut_data);

      reduced_r_rms_radius_pn_set_copy_disk (neut_data);
      
      OBMEs_CM_set_copy_disk (neut_data);
    }
}

void inputs_misc::TBMEs_pp_nn_pn_copy_disk (
					    const class input_data_str &input_data , 
					    const class nucleons_data &prot_data ,
					    const class nucleons_data &neut_data ,
					    const class TBMEs_class &TBMEs_pn)
{  
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in inputs_misc::TBMEs_pp_nn_pn_copy_disk");

  const enum interaction_type TBME_inter = input_data.get_inter ();
    
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  if (Zval >= 2)
    {
      const class TBMEs_class &TBMEs_pp = prot_data.get_TBMEs ();

      const string TBME_pp_file_name = STORAGE_DIR + "TBMEs_unformatted_" + make_string<enum space_type> (PROTONS_ONLY) + "_" + make_string<enum interaction_type> (TBME_inter) + ".dat";
 
      TBMEs_pp.copy_disk (TBME_pp_file_name);
    }
  
  if (Nval >= 2)
    {
      const class TBMEs_class &TBMEs_nn = neut_data.get_TBMEs ();
      
      const string TBME_nn_file_name = STORAGE_DIR + "TBMEs_unformatted_" + make_string<enum space_type> (NEUTRONS_ONLY) + "_" + make_string<enum interaction_type> (TBME_inter) + ".dat";
      
      TBMEs_nn.copy_disk (TBME_nn_file_name);
    }
  
  if ((Zval >= 1) && (Nval >= 1))
    {  
      const string TBME_pn_file_name = STORAGE_DIR + "TBMEs_unformatted_" + make_string<enum space_type> (PROTONS_NEUTRONS) + "_" + make_string<enum interaction_type> (TBME_inter) + ".dat";
      
      TBMEs_pn.copy_disk (TBME_pn_file_name);
    }
}

void inputs_misc::coupled_one_body_tab_read_disk (
						  const string debut_file_name , 
						  const enum interaction_type Op_inter , 
						  const class nucleons_data &particles_data ,
						  class array<TYPE> &coupled_one_body_tab)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      const enum particle_type particle = particles_data.get_particle ();

      const string coupled_one_body_tab_file_name = STORAGE_DIR + debut_file_name + make_string<enum particle_type> (particle) + "_" + make_string<enum interaction_type> (Op_inter) + ".dat";

      coupled_one_body_tab.read_disk (coupled_one_body_tab_file_name);
    }

#ifdef UseMPI
  
  coupled_one_body_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

#endif
}

void inputs_misc::coupled_one_body_tab_read_disk (
						  const string debut_file_name , 
						  const enum operator_type Op_inter , 
						  const class nucleons_data &particles_data ,
						  class array<TYPE> &coupled_one_body_tab)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      const enum particle_type particle = particles_data.get_particle ();

      const string coupled_one_body_tab_file_name = STORAGE_DIR + debut_file_name + make_string<enum particle_type> (particle) + "_" + make_string<enum operator_type> (Op_inter) + ".dat";

      coupled_one_body_tab.read_disk (coupled_one_body_tab_file_name);
    }

#ifdef UseMPI

  coupled_one_body_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

#endif
}

void inputs_misc::OBMEs_inter_HO_GHF_overlaps_alloc_read_disk (
							       const class input_data_str &input_data , 
							       class nucleons_data &particles_data)
{
  const enum interaction_type TBME_inter = input_data.get_inter ();
  
  const enum particle_type particle = particles_data.get_particle ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();
  
  const int lmax_for_interaction = input_data.get_lmax_for_interaction ();
  
  const class array<int> &nmax_HO_lab_tab = input_data.get_nmax_HO_lab_tab ();
  
  const class array<int> &nmax_GHF_lab_tab = input_data.get_nmax_GHF_lab_tab ();
  
  class OBMEs_inter_set_str &OBMEs_inter_set = particles_data.get_OBMEs_inter_set ();
  
  class array<class vector_class<complex<double> > > &HO_overlaps       = particles_data.get_HO_overlaps ();
  class array<class vector_class<complex<double> > > &HO_overlaps_Fermi = particles_data.get_HO_overlaps_Fermi ();
  
  class array<class vector_class<complex<double> > > &GHF_overlaps       = particles_data.get_GHF_overlaps ();

  OBMEs_inter_set.allocate (N_nlj , phi_table);

  coupled_one_body_tab_read_disk ("OBMEs_unformatted_" , TBME_inter , particles_data , OBMEs_inter_set(TBME_inter));

  coupled_one_body_tab_read_disk ("OBMEs_unformatted_" , ONE_BODY_NUCLEAR , particles_data , OBMEs_inter_set(ONE_BODY_NUCLEAR));
  coupled_one_body_tab_read_disk ("OBMEs_unformatted_" , ONE_BODY_KINETIC , particles_data , OBMEs_inter_set(ONE_BODY_KINETIC));
  coupled_one_body_tab_read_disk ("OBMEs_unformatted_" , ONE_BODY_COULOMB , particles_data , OBMEs_inter_set(ONE_BODY_COULOMB));

  HO_overlaps.allocate (N_nlj);
  HO_overlaps_Fermi.allocate (N_nlj);
  
  GHF_overlaps.allocate (N_nlj);

  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_qn(s);
      
      const int l = shell_qn.get_l ();
      
      const int nmax_HO_l = (l <= lmax_for_interaction) ? (nmax_HO_lab_tab(l)) : (0);
      
      const int nmax_HO_l_plus_one = nmax_HO_l + 1;
      
      const int nmax_GHF_l = (l <= lmax_for_interaction) ? (nmax_GHF_lab_tab(l)) : (0);
      
      const int nmax_GHF_l_plus_one = nmax_GHF_l + 1;
  
      class vector_class<complex<double> > &HO_overlaps_shell       = HO_overlaps(s);
      class vector_class<complex<double> > &HO_overlaps_Fermi_shell = HO_overlaps_Fermi(s);
      
      class vector_class<complex<double> > &GHF_overlaps_shell = GHF_overlaps(s);

      HO_overlaps_shell.allocate (nmax_HO_l_plus_one);
      HO_overlaps_Fermi_shell.allocate (nmax_HO_l_plus_one);
      
      GHF_overlaps_shell.allocate (nmax_GHF_l_plus_one);
	
      HO_overlaps_shell.read_disk       (STORAGE_DIR + "HO_overlaps_"       + make_string<int> (s) + "_" + make_string<enum particle_type> (particle));      
      HO_overlaps_Fermi_shell.read_disk (STORAGE_DIR + "HO_overlaps_Fermi_" + make_string<int> (s) + "_" + make_string<enum particle_type> (particle));
      
      GHF_overlaps_shell.read_disk (STORAGE_DIR + "GHF_overlaps_" + make_string<int> (s) + "_" + make_string<enum particle_type> (particle)); 
    }
}
							   
void inputs_misc::all_OBMEs_inter_HO_GHF_overlaps_alloc_read_disk (
								   const class input_data_str &input_data ,
								   class nucleons_data &prot_data , 
								   class nucleons_data &neut_data)
{
  const enum space_type space = input_data.get_space ();
  
  if (space != NEUTRONS_ONLY) OBMEs_inter_HO_GHF_overlaps_alloc_read_disk (input_data , prot_data);
  if (space != PROTONS_ONLY)  OBMEs_inter_HO_GHF_overlaps_alloc_read_disk (input_data , neut_data); 
}

void inputs_misc::reduced_grad_set_alloc_read_disk (class nucleons_data &particles_data)
{
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();
 
  class OBMEs_CM_set_str &reduced_grad_HO_expansion_set = particles_data.get_reduced_grad_HO_expansion_set ();
  
  reduced_grad_HO_expansion_set.allocate (N_nlj , phi_table);

  coupled_one_body_tab_read_disk ("reduced_grad_tab_HO_expansion_unformatted_" , CM_KINETIC                    , particles_data , reduced_grad_HO_expansion_set(CM_KINETIC));
  coupled_one_body_tab_read_disk ("reduced_grad_tab_HO_expansion_unformatted_" , HCM                           , particles_data , reduced_grad_HO_expansion_set(HCM));
  coupled_one_body_tab_read_disk ("reduced_grad_tab_HO_expansion_unformatted_" , L_REDUCED_TENSOR              , particles_data , reduced_grad_HO_expansion_set(L_REDUCED_TENSOR));
  coupled_one_body_tab_read_disk ("reduced_grad_tab_HO_expansion_unformatted_" , A_DAGGER_CM_HO_REDUCED_TENSOR , particles_data , reduced_grad_HO_expansion_set(A_DAGGER_CM_HO_REDUCED_TENSOR));
      
  class OBMEs_CM_set_str &reduced_grad_R_cut_set = particles_data.get_reduced_grad_R_cut_set ();
      
  reduced_grad_R_cut_set.allocate (N_nlj , phi_table);
      
  coupled_one_body_tab_read_disk ("reduced_grad_tab_R_cut_unformatted_" , CM_KINETIC                    , particles_data , reduced_grad_R_cut_set(CM_KINETIC));
  coupled_one_body_tab_read_disk ("reduced_grad_tab_R_cut_unformatted_" , HCM                           , particles_data , reduced_grad_R_cut_set(HCM));
  coupled_one_body_tab_read_disk ("reduced_grad_tab_R_cut_unformatted_" , L_REDUCED_TENSOR              , particles_data , reduced_grad_R_cut_set(L_REDUCED_TENSOR));
  coupled_one_body_tab_read_disk ("reduced_grad_tab_R_cut_unformatted_" , A_DAGGER_CM_HO_REDUCED_TENSOR , particles_data , reduced_grad_R_cut_set(A_DAGGER_CM_HO_REDUCED_TENSOR));
}

void inputs_misc::reduced_r_set_alloc_read_disk (class nucleons_data &particles_data)
{
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();
 
  class OBMEs_CM_set_str &reduced_r_HO_expansion_set = particles_data.get_reduced_r_HO_expansion_set ();

  reduced_r_HO_expansion_set.allocate (N_nlj , phi_table);
      
  coupled_one_body_tab_read_disk ("reduced_r_tab_HO_expansion_unformatted_" , HCM                           , particles_data , reduced_r_HO_expansion_set(HCM));
  coupled_one_body_tab_read_disk ("reduced_r_tab_HO_expansion_unformatted_" , RMS_RADIUS_PROTON             , particles_data , reduced_r_HO_expansion_set(RMS_RADIUS_PROTON));
  coupled_one_body_tab_read_disk ("reduced_r_tab_HO_expansion_unformatted_" , RMS_RADIUS_NEUTRON            , particles_data , reduced_r_HO_expansion_set(RMS_RADIUS_NEUTRON));
  coupled_one_body_tab_read_disk ("reduced_r_tab_HO_expansion_unformatted_" , L_REDUCED_TENSOR              , particles_data , reduced_r_HO_expansion_set(L_REDUCED_TENSOR));
  coupled_one_body_tab_read_disk ("reduced_r_tab_HO_expansion_unformatted_" , A_DAGGER_CM_HO_REDUCED_TENSOR , particles_data , reduced_r_HO_expansion_set(A_DAGGER_CM_HO_REDUCED_TENSOR));
      
  class OBMEs_CM_set_str &reduced_r_R_cut_set = particles_data.get_reduced_r_R_cut_set ();
      
  reduced_r_R_cut_set.allocate (N_nlj , phi_table);
      
  coupled_one_body_tab_read_disk ("reduced_r_tab_R_cut_unformatted_" , HCM                           , particles_data , reduced_r_R_cut_set(HCM));
  coupled_one_body_tab_read_disk ("reduced_r_tab_R_cut_unformatted_" , RMS_RADIUS_PROTON             , particles_data , reduced_r_R_cut_set(RMS_RADIUS_PROTON));
  coupled_one_body_tab_read_disk ("reduced_r_tab_R_cut_unformatted_" , RMS_RADIUS_NEUTRON            , particles_data , reduced_r_R_cut_set(RMS_RADIUS_NEUTRON));
  coupled_one_body_tab_read_disk ("reduced_r_tab_R_cut_unformatted_" , L_REDUCED_TENSOR              , particles_data , reduced_r_R_cut_set(L_REDUCED_TENSOR));
  coupled_one_body_tab_read_disk ("reduced_r_tab_R_cut_unformatted_" , A_DAGGER_CM_HO_REDUCED_TENSOR , particles_data , reduced_r_R_cut_set(A_DAGGER_CM_HO_REDUCED_TENSOR));
}

void inputs_misc::reduced_r_rms_radius_pn_set_alloc_read_disk (class nucleons_data &particles_data)
{
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();

  class OBMEs_CM_set_str &reduced_r_HO_expansion_rms_radius_pn_set = particles_data.get_reduced_r_HO_expansion_rms_radius_pn_set ();

  reduced_r_HO_expansion_rms_radius_pn_set.allocate (N_nlj , phi_table);
      
  coupled_one_body_tab_read_disk ("reduced_r_rms_radius_pn_tab_HO_expansion_unformatted_" , HCM                           , particles_data , reduced_r_HO_expansion_rms_radius_pn_set(HCM));
  coupled_one_body_tab_read_disk ("reduced_r_rms_radius_pn_tab_HO_expansion_unformatted_" , RMS_RADIUS_PROTON             , particles_data , reduced_r_HO_expansion_rms_radius_pn_set(RMS_RADIUS_PROTON));
  coupled_one_body_tab_read_disk ("reduced_r_rms_radius_pn_tab_HO_expansion_unformatted_" , RMS_RADIUS_NEUTRON            , particles_data , reduced_r_HO_expansion_rms_radius_pn_set(RMS_RADIUS_NEUTRON));
  coupled_one_body_tab_read_disk ("reduced_r_rms_radius_pn_tab_HO_expansion_unformatted_" , L_REDUCED_TENSOR              , particles_data , reduced_r_HO_expansion_rms_radius_pn_set(L_REDUCED_TENSOR));
  coupled_one_body_tab_read_disk ("reduced_r_rms_radius_pn_tab_HO_expansion_unformatted_" , A_DAGGER_CM_HO_REDUCED_TENSOR , particles_data , reduced_r_HO_expansion_rms_radius_pn_set(A_DAGGER_CM_HO_REDUCED_TENSOR));
      
  class OBMEs_CM_set_str &reduced_r_R_cut_rms_radius_pn_set = particles_data.get_reduced_r_R_cut_rms_radius_pn_set ();
      
  reduced_r_R_cut_rms_radius_pn_set.allocate (N_nlj , phi_table);
      
  coupled_one_body_tab_read_disk ("reduced_r_rms_radius_pn_tab_R_cut_unformatted_" , HCM                           , particles_data , reduced_r_R_cut_rms_radius_pn_set(HCM));
  coupled_one_body_tab_read_disk ("reduced_r_rms_radius_pn_tab_R_cut_unformatted_" , RMS_RADIUS_PROTON             , particles_data , reduced_r_R_cut_rms_radius_pn_set(RMS_RADIUS_PROTON));
  coupled_one_body_tab_read_disk ("reduced_r_rms_radius_pn_tab_R_cut_unformatted_" , RMS_RADIUS_NEUTRON            , particles_data , reduced_r_R_cut_rms_radius_pn_set(RMS_RADIUS_NEUTRON));
  coupled_one_body_tab_read_disk ("reduced_r_rms_radius_pn_tab_R_cut_unformatted_" , L_REDUCED_TENSOR              , particles_data , reduced_r_R_cut_rms_radius_pn_set(L_REDUCED_TENSOR));
  coupled_one_body_tab_read_disk ("reduced_r_rms_radius_pn_tab_R_cut_unformatted_" , A_DAGGER_CM_HO_REDUCED_TENSOR , particles_data , reduced_r_R_cut_rms_radius_pn_set(A_DAGGER_CM_HO_REDUCED_TENSOR));
}

void inputs_misc::OBMEs_CM_set_alloc_read_disk (class nucleons_data &particles_data)
{
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const class array<class nljm_struct> &phi_table = particles_data.get_phi_table ();
  
  class OBMEs_CM_set_str &OBMEs_CM_set_HO_expansion = particles_data.get_OBMEs_CM_set_HO_expansion ();
  OBMEs_CM_set_HO_expansion.allocate (N_nlj , phi_table);

  coupled_one_body_tab_read_disk ("OBMEs_HO_expansion_unformatted_" , CM_KINETIC                    , particles_data , OBMEs_CM_set_HO_expansion(CM_KINETIC));
  coupled_one_body_tab_read_disk ("OBMEs_HO_expansion_unformatted_" , HCM                           , particles_data , OBMEs_CM_set_HO_expansion(HCM));
  coupled_one_body_tab_read_disk ("OBMEs_HO_expansion_unformatted_" , RMS_RADIUS_PROTON             , particles_data , OBMEs_CM_set_HO_expansion(RMS_RADIUS_PROTON));
  coupled_one_body_tab_read_disk ("OBMEs_HO_expansion_unformatted_" , RMS_RADIUS_NEUTRON            , particles_data , OBMEs_CM_set_HO_expansion(RMS_RADIUS_NEUTRON));
  coupled_one_body_tab_read_disk ("OBMEs_HO_expansion_unformatted_" , L_REDUCED_TENSOR              , particles_data , OBMEs_CM_set_HO_expansion(L_REDUCED_TENSOR));
  coupled_one_body_tab_read_disk ("OBMEs_HO_expansion_unformatted_" , A_DAGGER_CM_HO_REDUCED_TENSOR , particles_data , OBMEs_CM_set_HO_expansion(A_DAGGER_CM_HO_REDUCED_TENSOR));
      
  class OBMEs_CM_set_str &OBMEs_CM_set_R_cut = particles_data.get_OBMEs_CM_set_R_cut ();
  OBMEs_CM_set_R_cut.allocate (N_nlj , phi_table);
      
  coupled_one_body_tab_read_disk ("OBMEs_R_cut_unformatted_" , CM_KINETIC                    , particles_data , OBMEs_CM_set_R_cut(CM_KINETIC));
  coupled_one_body_tab_read_disk ("OBMEs_R_cut_unformatted_" , HCM                           , particles_data , OBMEs_CM_set_R_cut(HCM));
  coupled_one_body_tab_read_disk ("OBMEs_R_cut_unformatted_" , RMS_RADIUS_PROTON             , particles_data , OBMEs_CM_set_R_cut(RMS_RADIUS_PROTON));
  coupled_one_body_tab_read_disk ("OBMEs_R_cut_unformatted_" , RMS_RADIUS_NEUTRON            , particles_data , OBMEs_CM_set_R_cut(RMS_RADIUS_NEUTRON));
  coupled_one_body_tab_read_disk ("OBMEs_R_cut_unformatted_" , L_REDUCED_TENSOR              , particles_data , OBMEs_CM_set_R_cut(L_REDUCED_TENSOR));
  coupled_one_body_tab_read_disk ("OBMEs_R_cut_unformatted_" , A_DAGGER_CM_HO_REDUCED_TENSOR , particles_data , OBMEs_CM_set_R_cut(A_DAGGER_CM_HO_REDUCED_TENSOR));
}

void inputs_misc::all_OBMEs_CM_reduced_r_grad_sets_alloc_read_disk (const enum space_type space ,
								    class nucleons_data &prot_data , 
								    class nucleons_data &neut_data)
{
  if (space != NEUTRONS_ONLY)
    {
      reduced_grad_set_alloc_read_disk (prot_data);

      reduced_r_set_alloc_read_disk (prot_data);

      reduced_r_rms_radius_pn_set_alloc_read_disk (prot_data);
      
      OBMEs_CM_set_alloc_read_disk (prot_data);
    }
  
  if (space != PROTONS_ONLY)
    {
      reduced_grad_set_alloc_read_disk (neut_data);

      reduced_r_set_alloc_read_disk (neut_data);

      reduced_r_rms_radius_pn_set_alloc_read_disk (neut_data);
      
      OBMEs_CM_set_alloc_read_disk (neut_data);
    }
}

void inputs_misc::TBMEs_pp_nn_pn_alloc_read_disk (
						  const bool is_there_cout ,
						  const bool is_it_only_basis ,   
						  const class input_data_str &input_data , 
						  class nucleons_data &prot_data ,
						  class nucleons_data &neut_data ,
						  class TBMEs_class &TBMEs_pn)
{
  const enum interaction_type TBME_inter = input_data.get_inter ();
    
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  if (Zval >= 2)
    {
      const string TBME_pp_file_name = STORAGE_DIR + "TBMEs_unformatted_" + make_string<enum space_type> (PROTONS_ONLY) + "_" + make_string<enum interaction_type> (TBME_inter) + ".dat";
      
      class TBMEs_class &TBMEs_pp = prot_data.get_TBMEs ();

      TBMEs_pp.allocate (is_there_cout , is_it_only_basis , input_data , prot_data);
      
      TBMEs_pp.read_disk (TBME_pp_file_name);
    }
  
  if (Nval >= 2)
    {      
      const string TBME_nn_file_name = STORAGE_DIR + "TBMEs_unformatted_" + make_string<enum space_type> (NEUTRONS_ONLY) + "_" + make_string<enum interaction_type> (TBME_inter) + ".dat";
      
      class TBMEs_class &TBMEs_nn = neut_data.get_TBMEs ();

      TBMEs_nn.allocate (is_there_cout , is_it_only_basis , input_data , neut_data);
      
      TBMEs_nn.read_disk (TBME_nn_file_name);
    }
  
  if ((Zval >= 1) && (Nval >= 1))
    {  
      const string TBME_pn_file_name = STORAGE_DIR + "TBMEs_unformatted_" + make_string<enum space_type> (PROTONS_NEUTRONS) + "_" + make_string<enum interaction_type> (TBME_inter) + ".dat";
      
      TBMEs_pn.allocate (is_there_cout , is_it_only_basis , input_data , prot_data , neut_data);
      
      TBMEs_pn.read_disk (TBME_pn_file_name);
    }
}















// Natural orbitals and effective single particle energies (ESPE)
// --------------------------------------------------------------
// Scalar density matrices are diagonalized here to obtain natural orbitals given as vectors on the used one-body basis.
// Information about their occupancy and numerical precision is printed on screen.
//
// ESPE Hamiltonians are also diagonalized and ESPEs are printed if it is demanded.
//
// ESPE_natural_orbital is the average of the ESPE Hamiltonian of a natural orbital, as in standard shell model. 
// It is typically close to the ESPE arising from the ESPE Hamiltonian for well bound states, and completely different for loosely bound and resonant states.

void inputs_misc::natural_orbitals_occupancies_ESPEs_alloc_calc_print (
								       const bool is_there_cout ,
								       const bool are_there_ESPEs , 
								       class nucleons_data &particles_data)
{
  const enum particle_type particle = particles_data.get_particle ();
  
  const int lmax = particles_data.get_lmax ();

  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  const class nlj_table<unsigned int> &shells_indices = particles_data.get_shells_indices ();
  
  const class lj_table<int> &nmin_lj_valence_tab = particles_data.get_nmin_lj_valence_tab ();

  const class lj_table<class matrix<TYPE> > &scalar_density_matrices = particles_data.get_scalar_density_matrices ();
  
  const class lj_table<class matrix<TYPE> > &ESPEs_Hamiltonian_matrices = particles_data.get_ESPEs_Hamiltonian_matrices ();

  class lj_table<class matrix<TYPE> > &natural_orbitals_matrices = particles_data.get_natural_orbitals_matrices ();
  
  class lj_table<class matrix<TYPE> > &ESPEs_Hamiltonian_orbitals_matrices = particles_data.get_ESPEs_Hamiltonian_orbitals_matrices ();

  natural_orbitals_matrices.allocate (0.5 , lmax);

  if (are_there_ESPEs) ESPEs_Hamiltonian_orbitals_matrices.allocate (0.5 , lmax);
 
  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	const class matrix<TYPE> &scalar_density_matrix = scalar_density_matrices(l , j);

	if (scalar_density_matrix.is_it_filled ())
	  {
	    const int nmin_lj_valence = nmin_lj_valence_tab (l , j);

	    const int nmax_lj = scalar_density_matrix.get_dimension () - 1;

	    class matrix<TYPE> &natural_orbitals_matrix = natural_orbitals_matrices(l , j);

	    natural_orbitals_matrix.allocate_fill (scalar_density_matrix);
	    
	    class array<TYPE> occupancies(nmax_lj + 1);

	    total_diagonalization::symmetric::all_eigenpairs_Householder (natural_orbitals_matrix , occupancies);

	    total_diagonalization::eigenpairs_abs_sort (0 , nmax_lj , natural_orbitals_matrix , occupancies);
	    
	    natural_orbitals_matrix.reverse_vectors_order ();
	    
	    occupancies.reverse_order ();

	    for (int n = 0 ; n < nmin_lj_valence ; n++) occupancies(n) = 0.0;
	    
	    if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
	      {
		class matrix<TYPE> Id(nmax_lj + 1);

		Id.identity ();

		const class matrix<TYPE> natural_orbital_eigenvectors_precision_matrix = transpose (natural_orbitals_matrix)*natural_orbitals_matrix - Id;

		double natural_orbital_eigenvectors_precision = natural_orbital_eigenvectors_precision_matrix.infinite_norm ();

		for (int n = nmin_lj_valence ; n <= nmax_lj ; n++)
		  {
		    const class vector_class<TYPE> &natural_orbital_eigenvector = natural_orbitals_matrix.eigenvector (n);
		    
		    const TYPE &occupancy = occupancies(n);

		    const class vector_class<TYPE> residue = scalar_density_matrix*natural_orbital_eigenvector - occupancy*natural_orbital_eigenvector;
		    
		    natural_orbital_eigenvectors_precision = max (natural_orbital_eigenvectors_precision , residue.infinite_norm ());
		  }

		cout << endl << particle << " " << angular_state (l , j) << " natural orbitals eigenvectors precision:" << natural_orbital_eigenvectors_precision << endl << endl;

		for (int n = 0 ; n <= nmax_lj ; n++)
		  {
		    const TYPE occupancy_nlj = occupancies(n);

		    cout << particle << " " << n << angular_state (l , j) << " occupancy: " << occupancy_nlj << endl;
		  }
	      }
	  }
	
	if (are_there_ESPEs)
	  {
	    const class matrix<TYPE> &ESPEs_Hamiltonian_matrix = ESPEs_Hamiltonian_matrices(l , j);
	    
	    if (ESPEs_Hamiltonian_matrix.is_it_filled ())
	      {
		if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << endl;
	
		const int nmin_lj_valence = nmin_lj_valence_tab (l , j);

		const int nmax_lj = scalar_density_matrix.get_dimension () - 1;
	    
		const class matrix<TYPE> &natural_orbitals_matrix = natural_orbitals_matrices(l , j);
	    
		class matrix<TYPE> &ESPEs_Hamiltonian_orbitals_matrix = ESPEs_Hamiltonian_orbitals_matrices(l , j);
	    
		ESPEs_Hamiltonian_orbitals_matrix.allocate_fill (ESPEs_Hamiltonian_matrix);
	    
		class array<TYPE> ESPEs(nmax_lj + 1);
	    
		total_diagonalization::symmetric::all_eigenpairs (ESPEs_Hamiltonian_orbitals_matrix , ESPEs);
	    
		if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
		  {
		    for (int n = 0 ; n <= nmax_lj ; n++)
		      {		    
			const TYPE &ESPE = ESPEs(n);

			const double E_ESPE = real_dc (ESPE);

			const double Gamma_ESPE = -2000.0*imag_dc (ESPE);
		    
			const class vector_class<TYPE> &natural_orbital_eigenvector = natural_orbitals_matrix.eigenvector (n);

			const class vector_class<TYPE> &ESPE_eigenvector = ESPEs_Hamiltonian_orbitals_matrix.eigenvector (n);
			
			const int n_maximal_overlap = ESPE_eigenvector.closest_value_index_determine (1.0);
		    
			if (n_maximal_overlap >= nmin_lj_valence)
			  {
			    const unsigned int s_maximal_overlap = shells_indices(n_maximal_overlap , l , j);
		    
			    const class nlj_struct &shell_qn_maximal_overlap = shells_qn(s_maximal_overlap);

			    const bool S_matrix_pole_maximal_overlap = shell_qn_maximal_overlap.get_S_matrix_pole ();

			    if (S_matrix_pole_maximal_overlap)
			      {
				const TYPE ESPE_natural_orbital = natural_orbital_eigenvector*(ESPEs_Hamiltonian_matrix*natural_orbital_eigenvector);

				const double E_ESPE_natural_orbital = real_dc (ESPE_natural_orbital);

				const double Gamma_ESPE_natural_orbital = -2000.0*imag_dc (ESPE_natural_orbital);
			
				const double inf_norm_overlap = inf_norm (ESPE_eigenvector(n_maximal_overlap));
		    
				cout << particle << " " << n_maximal_overlap << angular_state (l , j) << " |overlap|oo: " << inf_norm_overlap << endl;			

				if (inf_norm (E_ESPE) < 5000) cout << "ESPE.Hamiltonian      E:" << E_ESPE  << " MeV G:" << Gamma_ESPE << " keV" << endl;

				if (inf_norm (E_ESPE_natural_orbital) < 5000) cout << "ESPE.natural.orbital  E:" << E_ESPE_natural_orbital  << " MeV G:" << Gamma_ESPE_natural_orbital << " keV" << endl << endl;
			      }
			  }
		      }
		  }
	      }
	  }
      }
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) cout << endl << endl;
}
















// Slater determinants and GSM vector components from file, booleans checking if Slater determinant belongs to the new space and reordering phases calculated
// -----------------------------------------------------------------------------------------------------------------------------------------------------------
// 
// Slater determinants, which are stored as an array of integers here (SD_tab(i_SD,i) is the index of the state occupied by the i-th nucleon in the i_SD-th SD), 
// and their components in a GSM eigenvector (PSI_component_tab(i_SD) is the component of the i-th SD), are read from a file and stored in arrays.
// A GSM component of 1 is considered if Slater determinants reduce to vaccum, i.e. if their number of valence nucleons is zero.
 
void inputs_misc::Slater_determinants_PSI_components_read_from_file (
								     const string &eigenvector_file_name , 
								     class array<unsigned int> &SD_tab , 
								     class array<TYPE> &PSI_component_tab)
{
  const int N_valence_nucleons = SD_tab.dimension (1);

  if (N_valence_nucleons == 0)
    {
      PSI_component_tab(0) = 1.0;
      
      return;
    }
  
  PSI_component_tab.read_disk (eigenvector_file_name);
  
  const string eigenvector_SD_table_file_name = eigenvector_file_name + "_SD_basis.dat";
  
  SD_tab.read_disk (eigenvector_SD_table_file_name);
}

void inputs_misc::Slater_determinants_PSI_components_read_from_file (
								     const string &eigenvector_file_name , 
								     class array<unsigned int> &SDp_tab , 
								     class array<unsigned int> &SDn_tab , 
								     class array<TYPE> &PSI_component_tab)
{
  const int Zval = SDp_tab.dimension (1);
  const int Nval = SDn_tab.dimension (1);
  
  if ((Zval == 0) && (Nval == 0))
    {
      PSI_component_tab(0) = 1.0;

      return;
    }

  if (Zval == 0) 
    Slater_determinants_PSI_components_read_from_file (eigenvector_file_name , SDn_tab , PSI_component_tab);
  else if (Nval == 0)
    Slater_determinants_PSI_components_read_from_file (eigenvector_file_name , SDp_tab , PSI_component_tab);
  else
    {
      PSI_component_tab.read_disk (eigenvector_file_name);

      const string eigenvector_SDp_table_file_name = eigenvector_file_name + "_SDp_basis.dat";
      const string eigenvector_SDn_table_file_name = eigenvector_file_name + "_SDn_basis.dat";

      SDp_tab.read_disk (eigenvector_SDp_table_file_name);
      SDn_tab.read_disk (eigenvector_SDn_table_file_name);
    }
}






// Slater determinants and GSM vector components from file, booleans checking if Slater determinant belongs to the new space and reordering phases calculated from a GSM vector stored on disk
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// 
// Slater determinants, which are stored as an array of integers here (SD_tab(i_SD,i) is the index of the state occupied by the i-th nucleon in the i_SD-th SD), 
// and their components in a GSM eigenvector (PSI_component_tab(i_SD) is the component of the i-th SD), are read from a file and stored in arrays.
// A GSM component of 1 is considered if Slater determinants reduce to vaccum, i.e. if their number of valence nucleons is zero.
//
// Booleans checking if the Slater determinant belongs to the new space are also stored, case which can occur if truncations in the current and file model spaces are different.
// As the indices of one-body states might be different, reordering binary phases (see observables_basic_functions.cpp for definition) are calculated as well and stored.
// mu is proton or neutron.
//
// If a GSM vector is fully stored on a node, the master process reads files containing one-body states, Slater determinants and GSM vector components,  and distributes them to all nodes.
// If a GSM vector is separated on all nodes, all processes read their own files containing one-body states, part of Slater determinants and part of GSM vector components.
//
// IN means that one considers the target, i.e. the in state.
//
// one_nucleon in routines means that routines are used in GSM-CC or for spectroscopic factors/overlap functions with one-nucleon projectiles.
//
// cluster in routines means that routines are used in GSM-CC or for spectroscopic factors/overlap functions with cluster projectiles. Cluster wave functions are small and are always fully stored on one node.
// If these routines are used for spectroscopic factors/overlap functions and not GSM-CC, many-body cluster states do not consist of basis cluster center of mass (CM) states, but are simply GSM eigenstates.

void inputs_misc::files_IN_tables_read_pp_nn_one_nucleon (
							  const bool full_common_vectors_used_in_file , 
							  const class correlated_state_str &PSI_IN_qn ,
							  const double M_IN ,
							  const class nucleons_data &data ,
							  class array<unsigned int> &inSD_tab ,
							  class array<TYPE> &PSI_IN_component_tab ,
							  class array<bool> &is_inSD_in_new_space_tab ,
							  class array<unsigned char> &reordering_bin_phases)
{
  const enum particle_type particle = data.get_particle ();
  
  const int Z_core = data.get_Z_core (); 
  const int N_core = data.get_N_core ();

  const int hole_states_number = data.get_hole_states_number ();

  const int N_core_mu = (particle == PROTON) ? (Z_core) : (N_core);
  
  const int N_IN_mu = (particle == PROTON) ? (PSI_IN_qn.get_Z ()) : (PSI_IN_qn.get_N ());

  const int Nval_IN_mu = N_IN_mu - N_core_mu + hole_states_number;
  
  const unsigned int N_nljm_mu = data.get_N_nljm ();
  
  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();
  
  const class lj_table<int> &nmax_lj_tab_mu = data.get_nmax_lj_tab ();
  
  const class nlj_table<bool> &is_it_valence_shell_tab_mu = data.get_is_it_valence_shell_tab ();
  
  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();
  
  const string file_name_IN = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector" , PSI_IN_qn , M_IN);

  const unsigned int N_nljm_mu_IN_from_file = N_nljm_from_file_determine (full_common_vectors_used_in_file , file_name_IN , Nval_IN_mu , N_nljm_mu);
   
  class array<class nljm_struct> phi_mu_table_IN_from_file(N_nljm_mu_IN_from_file);
      
  if (full_common_vectors_used_in_file)
    {
      if (THIS_PROCESS == MASTER_PROCESS) 
	{
	  phi_table_from_file_determine (file_name_IN , Nval_IN_mu , phi_mu_table , phi_mu_table_IN_from_file);

	  Slater_determinants_PSI_components_read_from_file (file_name_IN , inSD_tab , PSI_IN_component_tab);
	}
  
#ifdef UseMPI
      
      MPI_Datatype MPI_nljm_struct = MPI_Datatype_nljm_struct_create ();
      
      MPI_helper::Type_commit (MPI_nljm_struct);
  
      phi_mu_table_IN_from_file.MPI_Bcast (MASTER_PROCESS , MPI_nljm_struct , MPI_COMM_WORLD);

      MPI_helper::Type_free (MPI_nljm_struct);

      inSD_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
     
      PSI_IN_component_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
      
#endif
      
    }
  else
    {
      phi_table_from_file_determine (file_name_IN , Nval_IN_mu , phi_mu_table , phi_mu_table_IN_from_file);

      Slater_determinants_PSI_components_read_from_file (file_name_IN , inSD_tab , PSI_IN_component_tab);
    }
 
  SDs_is_it_in_new_space_reindexation_phases_determine (nmax_lj_tab_mu , is_it_valence_shell_tab_mu , phi_mu_table_IN_from_file , one_body_indices_mu , inSD_tab , is_inSD_in_new_space_tab , reordering_bin_phases);
}

void inputs_misc::files_IN_tables_read_pn_one_nucleon (
						       const bool full_common_vectors_used_in_file , 
						       const int Zval_IN , 
						       const int Nval_IN , 
						       const class correlated_state_str &PSI_IN_qn ,
						       const double M_IN , 
						       const class nucleons_data &prot_data ,
						       const class nucleons_data &neut_data ,
						       class array<unsigned int> &inSDp_tab ,
						       class array<unsigned int> &inSDn_tab ,
						       class array<TYPE> &PSI_IN_component_tab ,
						       class array<bool> &is_inSDp_in_new_space_tab ,
						       class array<bool> &is_inSDn_in_new_space_tab ,
						       class array<unsigned char> &reordering_bin_phases_p ,
						       class array<unsigned char> &reordering_bin_phases_n)
{
  const unsigned int Np_nljm = prot_data.get_N_nljm ();
  const unsigned int Nn_nljm = neut_data.get_N_nljm ();
  
  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();
  
  const class one_body_indices_str &one_body_indices_p = prot_data.get_one_body_indices ();
  const class one_body_indices_str &one_body_indices_n = neut_data.get_one_body_indices ();
  
  const class lj_table<int> &nmax_lj_tab_p = prot_data.get_nmax_lj_tab ();
  const class lj_table<int> &nmax_lj_tab_n = neut_data.get_nmax_lj_tab ();
  
  const class nlj_table<bool> &is_it_valence_shell_tab_p = prot_data.get_is_it_valence_shell_tab ();
  const class nlj_table<bool> &is_it_valence_shell_tab_n = neut_data.get_is_it_valence_shell_tab ();

  const string file_name_IN = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector" , PSI_IN_qn , M_IN);

  const unsigned int Np_nljm_IN_from_file = Np_nljm_from_file_determine (full_common_vectors_used_in_file , file_name_IN , Zval_IN , Nval_IN , Np_nljm);
  const unsigned int Nn_nljm_IN_from_file = Nn_nljm_from_file_determine (full_common_vectors_used_in_file , file_name_IN , Zval_IN , Nval_IN , Nn_nljm);

  class array<class nljm_struct> phi_p_table_IN_from_file(Np_nljm_IN_from_file);
  class array<class nljm_struct> phi_n_table_IN_from_file(Nn_nljm_IN_from_file);
  
  if (full_common_vectors_used_in_file)
    {  
      if (THIS_PROCESS == MASTER_PROCESS) 
	{
	  phi_p_table_from_file_determine (file_name_IN , Zval_IN , Nval_IN , phi_p_table , phi_p_table_IN_from_file);
	  phi_n_table_from_file_determine (file_name_IN , Zval_IN , Nval_IN , phi_n_table , phi_n_table_IN_from_file);
  
	  Slater_determinants_PSI_components_read_from_file (file_name_IN , inSDp_tab , inSDn_tab , PSI_IN_component_tab);	  
	}

#ifdef UseMPI
      
      MPI_Datatype MPI_nljm_struct = MPI_Datatype_nljm_struct_create ();

      MPI_helper::Type_commit (MPI_nljm_struct);

      phi_p_table_IN_from_file.MPI_Bcast (MASTER_PROCESS , MPI_nljm_struct , MPI_COMM_WORLD);
      phi_n_table_IN_from_file.MPI_Bcast (MASTER_PROCESS , MPI_nljm_struct , MPI_COMM_WORLD); 

      MPI_helper::Type_free (MPI_nljm_struct);
      
      inSDp_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
      inSDn_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

      PSI_IN_component_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

#endif
      
    }
  else
    {
      phi_p_table_from_file_determine (file_name_IN , Zval_IN , Nval_IN , phi_p_table , phi_p_table_IN_from_file);
      phi_n_table_from_file_determine (file_name_IN , Zval_IN , Nval_IN , phi_n_table , phi_n_table_IN_from_file);
  
      Slater_determinants_PSI_components_read_from_file (file_name_IN , inSDp_tab , inSDn_tab , PSI_IN_component_tab);
    }

  SDs_is_it_in_new_space_reindexation_phases_determine (nmax_lj_tab_p , is_it_valence_shell_tab_p , phi_p_table_IN_from_file , one_body_indices_p , inSDp_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p);
  SDs_is_it_in_new_space_reindexation_phases_determine (nmax_lj_tab_n , is_it_valence_shell_tab_n , phi_n_table_IN_from_file , one_body_indices_n , inSDn_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n);	
}

void inputs_misc::files_IN_tables_read_pp_nn_cluster (
						      const bool full_common_vectors_used_in_file ,
						      const bool is_it_CM_relative_cluster , 
						      const enum particle_type cluster , 
						      const int NCM_HO , 
						      const int LCM , 
						      const class correlated_state_str &PSI_cluster_qn ,
						      const double M_cluster ,  
						      const class correlated_state_str &PSI_IN_qn ,
						      const double M_IN ,
						      const class nucleons_data &data ,
						      class array<unsigned int> &SD_IN_tab ,
						      class array<unsigned int> &SD_cluster_tab ,
						      class array<TYPE> &PSI_IN_component_tab ,
						      class array<TYPE> &PSI_cluster_component_tab ,
						      class array<bool> &is_SD_IN_in_new_space_tab ,
						      class array<bool> &is_SD_cluster_in_new_space_tab ,
						      class array<unsigned char> &reordering_bin_phases_IN ,
						      class array<unsigned char> &reordering_bin_phases_cluster)
{
  const enum particle_type particle = data.get_particle ();
  
  const int Z_core = data.get_Z_core (); 
  const int N_core = data.get_N_core ();
  
  const int Z_cluster = PSI_cluster_qn.get_Z ();
  const int N_cluster = PSI_cluster_qn.get_N ();
  
  const int N_core_mu = (particle == PROTON) ? (Z_core) : (N_core);

  const int N_IN_mu = (particle == PROTON) ? (PSI_IN_qn.get_Z ()) : (PSI_IN_qn.get_N ());

  const int hole_states_number = data.get_hole_states_number ();

  const int Nval_IN_mu = N_IN_mu - N_core_mu + hole_states_number;

  const int N_cluster_mu = (particle == PROTON) ? (Z_cluster) : (N_cluster);

  const unsigned int N_nljm_mu = data.get_N_nljm ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();  

  const class lj_table<int> &nmax_lj_tab_mu = data.get_nmax_lj_tab ();

  const class nlj_table<bool> &is_it_valence_shell_tab_mu = data.get_is_it_valence_shell_tab ();
  
  const double J_cluster = PSI_cluster_qn.get_J ();

  const string file_name_IN = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector" , PSI_IN_qn , M_IN); 
 
  const string file_name_cluster = (is_it_CM_relative_cluster)
    ? (file_name_intrinsic_CM_cluster_string ("Berggren_basis_state" , cluster , NCM_HO , LCM , J_cluster , M_cluster))
    : (file_name_eigenvector_string (true , "eigenvector" , PSI_cluster_qn , M_cluster));

  const unsigned int N_nljm_mu_IN_from_file = N_nljm_from_file_determine (full_common_vectors_used_in_file , file_name_IN , Nval_IN_mu , N_nljm_mu);

  const unsigned int N_nljm_mu_cluster_from_file = N_nljm_from_file_determine (true , file_name_cluster , N_cluster_mu , N_nljm_mu);
  
  class array<class nljm_struct> phi_mu_table_cluster_from_file(N_nljm_mu_cluster_from_file);
  
  if (THIS_PROCESS == MASTER_PROCESS) 
    {
      phi_table_from_file_determine (file_name_cluster , N_cluster_mu , phi_mu_table , phi_mu_table_cluster_from_file);
      
      Slater_determinants_PSI_components_read_from_file (file_name_cluster , SD_cluster_tab , PSI_cluster_component_tab);
    }

#ifdef UseMPI
  
  MPI_Datatype MPI_nljm_struct = MPI_Datatype_nljm_struct_create ();

  MPI_helper::Type_commit (MPI_nljm_struct);

  phi_mu_table_cluster_from_file.MPI_Bcast (MASTER_PROCESS , MPI_nljm_struct , MPI_COMM_WORLD);

  MPI_helper::Type_free (MPI_nljm_struct);

  SD_cluster_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

  PSI_cluster_component_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

#endif
      
  class array<class nljm_struct> phi_mu_table_IN_from_file(N_nljm_mu_IN_from_file);
      
  if (full_common_vectors_used_in_file)
    { 
      if (THIS_PROCESS == MASTER_PROCESS) 
	{
	  phi_table_from_file_determine (file_name_IN , Nval_IN_mu , phi_mu_table , phi_mu_table_IN_from_file);

	  Slater_determinants_PSI_components_read_from_file (file_name_IN , SD_IN_tab , PSI_IN_component_tab);
	}

#ifdef UseMPI

      MPI_Datatype MPI_nljm_struct = MPI_Datatype_nljm_struct_create ();

      MPI_helper::Type_commit (MPI_nljm_struct);
  
      phi_mu_table_IN_from_file.MPI_Bcast (MASTER_PROCESS , MPI_nljm_struct , MPI_COMM_WORLD);
  
      MPI_helper::Type_free (MPI_nljm_struct);

      SD_IN_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

      PSI_IN_component_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
      
#endif
    }
  else
    {
      phi_table_from_file_determine (file_name_IN , Nval_IN_mu , phi_mu_table , phi_mu_table_IN_from_file);

      Slater_determinants_PSI_components_read_from_file (file_name_IN , SD_IN_tab , PSI_IN_component_tab);
    }  
  
  SDs_is_it_in_new_space_reindexation_phases_determine (nmax_lj_tab_mu , is_it_valence_shell_tab_mu , phi_mu_table_IN_from_file , one_body_indices_mu , SD_IN_tab , is_SD_IN_in_new_space_tab , reordering_bin_phases_IN);
	  
  SDs_is_it_in_new_space_reindexation_phases_determine (nmax_lj_tab_mu , is_it_valence_shell_tab_mu , phi_mu_table_cluster_from_file , one_body_indices_mu ,
							SD_cluster_tab , is_SD_cluster_in_new_space_tab , reordering_bin_phases_cluster);
}

void inputs_misc::files_IN_tables_read_pn_cluster (
						   const bool full_common_vectors_used_in_file , 
						   const bool is_it_CM_relative_cluster , 
						   const enum particle_type cluster , 
						   const int NCM_HO , 
						   const int LCM , 
						   const class correlated_state_str &PSI_cluster_qn ,
						   const double M_cluster ,  
						   const class correlated_state_str &PSI_IN_qn ,
						   const double M_IN ,
						   const class nucleons_data &prot_data ,
						   const class nucleons_data &neut_data ,
						   class array<unsigned int> &SDp_IN_tab ,
						   class array<unsigned int> &SDn_IN_tab ,
						   class array<unsigned int> &SDp_cluster_tab ,
						   class array<unsigned int> &SDn_cluster_tab ,
						   class array<TYPE> &PSI_IN_component_tab ,
						   class array<TYPE> &PSI_cluster_component_tab ,
						   class array<bool> &is_SDp_IN_in_new_space_tab ,
						   class array<bool> &is_SDn_IN_in_new_space_tab ,
						   class array<bool> &is_SDp_cluster_in_new_space_tab ,
						   class array<bool> &is_SDn_cluster_in_new_space_tab ,
						   class array<unsigned char> &reordering_bin_phases_p_IN ,
						   class array<unsigned char> &reordering_bin_phases_n_IN ,
						   class array<unsigned char> &reordering_bin_phases_p_cluster ,
						   class array<unsigned char> &reordering_bin_phases_n_cluster) 
{
  const int Z_core = prot_data.get_Z_core (); 
  const int N_core = prot_data.get_N_core ();

  const int Z_cluster = PSI_cluster_qn.get_Z ();
  const int N_cluster = PSI_cluster_qn.get_N ();
  
  const int Z_IN = PSI_IN_qn.get_Z ();
  const int N_IN = PSI_IN_qn.get_N ();

  const int prot_hole_states_number = prot_data.get_hole_states_number ();
  const int neut_hole_states_number = neut_data.get_hole_states_number ();
  
  const int Zval_IN = Z_IN - Z_core + prot_hole_states_number;  
  const int Nval_IN = N_IN - N_core + neut_hole_states_number;
  
  const unsigned int Np_nljm = prot_data.get_N_nljm ();
  const unsigned int Nn_nljm = neut_data.get_N_nljm ();
  
  const class array<class nljm_struct> &phi_p_table = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_data.get_phi_table ();
  
  const class one_body_indices_str &one_body_indices_p = prot_data.get_one_body_indices ();
  const class one_body_indices_str &one_body_indices_n = neut_data.get_one_body_indices ();
  
  const class lj_table<int> &nmax_lj_tab_p = prot_data.get_nmax_lj_tab ();
  const class lj_table<int> &nmax_lj_tab_n = neut_data.get_nmax_lj_tab ();
  
  const class nlj_table<bool> &is_it_valence_shell_tab_p = prot_data.get_is_it_valence_shell_tab ();
  const class nlj_table<bool> &is_it_valence_shell_tab_n = neut_data.get_is_it_valence_shell_tab ();
    
  const double J_cluster = PSI_cluster_qn.get_J ();
  
  const string file_name_IN = file_name_eigenvector_string (full_common_vectors_used_in_file , "eigenvector" , PSI_IN_qn , M_IN);
      
  const string file_name_cluster = (is_it_CM_relative_cluster)
    ? (file_name_intrinsic_CM_cluster_string ("Berggren_basis_state" , cluster , NCM_HO , LCM , J_cluster , M_cluster))
    : (file_name_eigenvector_string (true , "eigenvector" , PSI_cluster_qn , M_cluster));
  
  const unsigned int Np_nljm_IN_from_file = Np_nljm_from_file_determine (full_common_vectors_used_in_file , file_name_IN , Zval_IN , Nval_IN , Np_nljm);
  const unsigned int Nn_nljm_IN_from_file = Nn_nljm_from_file_determine (full_common_vectors_used_in_file , file_name_IN , Zval_IN , Nval_IN , Nn_nljm);

  const unsigned int Np_nljm_cluster_from_file = Np_nljm_from_file_determine (true , file_name_cluster , Z_cluster , N_cluster , Np_nljm);
  const unsigned int Nn_nljm_cluster_from_file = Nn_nljm_from_file_determine (true , file_name_cluster , Z_cluster , N_cluster , Nn_nljm);
      
  class array<class nljm_struct> phi_p_table_cluster_from_file(Np_nljm_cluster_from_file);
  class array<class nljm_struct> phi_n_table_cluster_from_file(Nn_nljm_cluster_from_file);
      	          
  if (THIS_PROCESS == MASTER_PROCESS) 
    {
      phi_p_table_from_file_determine (file_name_cluster , Z_cluster , N_cluster , phi_p_table , phi_p_table_cluster_from_file);
      phi_n_table_from_file_determine (file_name_cluster , Z_cluster , N_cluster , phi_n_table , phi_n_table_cluster_from_file);

      Slater_determinants_PSI_components_read_from_file (file_name_cluster , SDp_cluster_tab , SDn_cluster_tab , PSI_cluster_component_tab);
    }
  
#ifdef UseMPI

  MPI_Datatype MPI_nljm_struct = MPI_Datatype_nljm_struct_create ();
  
  MPI_helper::Type_commit (MPI_nljm_struct);

  phi_p_table_cluster_from_file.MPI_Bcast (MASTER_PROCESS , MPI_nljm_struct , MPI_COMM_WORLD);
  phi_n_table_cluster_from_file.MPI_Bcast (MASTER_PROCESS , MPI_nljm_struct , MPI_COMM_WORLD); 

  MPI_helper::Type_free (MPI_nljm_struct);
      
  SDp_cluster_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

  SDn_cluster_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

  PSI_cluster_component_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

#endif
  
  class array<class nljm_struct> phi_p_table_IN_from_file(Np_nljm_IN_from_file);
  class array<class nljm_struct> phi_n_table_IN_from_file(Nn_nljm_IN_from_file);
   
  if (full_common_vectors_used_in_file)
    {
      if (THIS_PROCESS == MASTER_PROCESS) 
	{
	  phi_p_table_from_file_determine (file_name_IN , Zval_IN , Nval_IN , phi_p_table , phi_p_table_IN_from_file);
	  phi_n_table_from_file_determine (file_name_IN , Zval_IN , Nval_IN , phi_n_table , phi_n_table_IN_from_file);

	  Slater_determinants_PSI_components_read_from_file (file_name_IN , SDp_IN_tab , SDn_IN_tab , PSI_IN_component_tab);
	}

#ifdef UseMPI

      MPI_Datatype MPI_nljm_struct = MPI_Datatype_nljm_struct_create ();
      
      MPI_helper::Type_commit (MPI_nljm_struct);
  
      phi_p_table_IN_from_file.MPI_Bcast (MASTER_PROCESS , MPI_nljm_struct , MPI_COMM_WORLD);
      phi_n_table_IN_from_file.MPI_Bcast (MASTER_PROCESS , MPI_nljm_struct , MPI_COMM_WORLD);
  
      MPI_helper::Type_free (MPI_nljm_struct);
      
      SDp_IN_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
      SDn_IN_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

      PSI_IN_component_tab.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

#endif
    }
  else
    {
      phi_p_table_from_file_determine (file_name_IN , Zval_IN , Nval_IN , phi_p_table , phi_p_table_IN_from_file);
      phi_n_table_from_file_determine (file_name_IN , Zval_IN , Nval_IN , phi_n_table , phi_n_table_IN_from_file);

      Slater_determinants_PSI_components_read_from_file (file_name_IN , SDp_IN_tab , SDn_IN_tab , PSI_IN_component_tab);
    }
  
  SDs_is_it_in_new_space_reindexation_phases_determine (nmax_lj_tab_p , is_it_valence_shell_tab_p , phi_p_table_IN_from_file , one_body_indices_p , SDp_IN_tab , is_SDp_IN_in_new_space_tab , reordering_bin_phases_p_IN);
  SDs_is_it_in_new_space_reindexation_phases_determine (nmax_lj_tab_n , is_it_valence_shell_tab_n , phi_n_table_IN_from_file , one_body_indices_n , SDn_IN_tab , is_SDn_IN_in_new_space_tab , reordering_bin_phases_n_IN);
	  
  SDs_is_it_in_new_space_reindexation_phases_determine (nmax_lj_tab_p , is_it_valence_shell_tab_p , phi_p_table_cluster_from_file , one_body_indices_p ,
							SDp_cluster_tab , is_SDp_cluster_in_new_space_tab , reordering_bin_phases_p_cluster);
	  
  SDs_is_it_in_new_space_reindexation_phases_determine (nmax_lj_tab_n , is_it_valence_shell_tab_n , phi_n_table_cluster_from_file , one_body_indices_n ,
							SDn_cluster_tab , is_SDn_cluster_in_new_space_tab , reordering_bin_phases_n_cluster);
}








// Routines reducing booleans with MPI routines
// --------------------------------------------
// The "and", "or" reduction on a process or on all processes of a boolean x is done here.
// One uses the same routine with both parallel and sequential compilation.
// Nothing is done in the sequential code case except checking that input data are correct.
//
// is_it_MPI_parallelized_local can be set to false to remove MPI distribution even if the MPI parallel code is used.

bool inputs_misc::and_Reduce (
			      const bool is_it_MPI_parallelized_local ,
			      const unsigned int Recv_process ,
			      const unsigned int process ,
			      const bool x)
{
  bool x_min = x;

#ifdef UseMPI
    
  if (is_it_MPI_parallelized_local) MPI_helper::Reduce<bool > (x_min , MPI_LAND , Recv_process , process , MPI_COMM_WORLD);
    
#else
    
  if (is_it_MPI_parallelized_local && (Recv_process != MASTER_PROCESS) && (process != MASTER_PROCESS))
    error_message_print_abort ("is_it_MPI_parallelized_local has to be false in a sequential calculation in and_Reduce and processes have to be MASTER_PROCESS");
    
#endif

  return x_min;
}

bool inputs_misc::or_Reduce (
			     const bool is_it_MPI_parallelized_local ,
			     const unsigned int Recv_process ,
			     const unsigned int process ,
			     const bool x)
{
  bool x_min = x;

#ifdef UseMPI
    
  if (is_it_MPI_parallelized_local) MPI_helper::Reduce<bool > (x_min , MPI_LOR , Recv_process , process , MPI_COMM_WORLD);
    
#else
    
  if (is_it_MPI_parallelized_local && (Recv_process != MASTER_PROCESS) && (process != MASTER_PROCESS))
    error_message_print_abort ("is_it_MPI_parallelized_local has to be false in a sequential calculation in or_Reduce and processes have to be MASTER_PROCESS");
    
#endif

  return x_min;
}

bool inputs_misc::and_Allreduce (
				 const bool is_it_MPI_parallelized_local ,
				 const bool x)
{
  bool x_min = x;

#ifdef UseMPI
    
  if (is_it_MPI_parallelized_local) MPI_helper::Allreduce<bool > (x_min , MPI_LAND , MPI_COMM_WORLD);
    
#else
    
  if (is_it_MPI_parallelized_local) error_message_print_abort ("is_it_MPI_parallelized_local has to be false in a sequential calculation in and_Allreduce");
    
#endif

  return x_min;
}

bool inputs_misc::or_Allreduce (
				const bool is_it_MPI_parallelized_local ,
				const bool x)
{
  bool x_min = x;

#ifdef UseMPI
    
  if (is_it_MPI_parallelized_local) MPI_helper::Allreduce<bool > (x_min , MPI_LOR , MPI_COMM_WORLD);
    
#else
    
  if (is_it_MPI_parallelized_local) error_message_print_abort ("is_it_MPI_parallelized_local has to be false in a sequential calculation in or_Allreduce");
    
#endif

  return x_min;
}





double inputs_misc::A_dependent_factor_core_potential_calc (const enum particle_type particle , const class input_data_str &input_data)
{
  const double A_dependence_alpha_core_potential = input_data.get_A_dependence_alpha_core_potential ();
  
  if (A_dependence_alpha_core_potential != 0.0)
    {  
      const int Z = input_data.get_Z ();
      const int A = input_data.get_A ();

      const double A_dependent_factor_core_potential = ::A_dependent_factor_core_potential_calc (particle , Z , A , A_dependence_alpha_core_potential);
    
      return A_dependent_factor_core_potential;
    }
  else
    return 1.0;
}	  






double inputs_misc::TBME_A_dependent_factor_calc (const class input_data_str &input_data)
{
  const double A_dependence_exponent = input_data.get_A_dependence_exponent ();
  
  if (A_dependence_exponent != 0.0)
    {  
      const int A_core = input_data.get_A_core ();
      
      const int A = input_data.get_A ();

      const double TBME_A_dependent_factor = ::TBME_A_dependent_factor_calc (A_core , A , A_dependence_exponent);
    
      return TBME_A_dependent_factor;
    }
  else
    return 1.0;
}	  



void inputs_misc::Ylm_table_coupled_to_l_calc (
					       const class array<class lm_struct> &lm_qn_table ,
					       class array<double> &Ylm_table_coupled_to_l)
{
  const unsigned int lm_number = lm_qn_table.dimension (0);

  const int two_lmax = Ylm_table_coupled_to_l.dimension (0) - 1;
  
  const int two_lmax_plus_one = two_lmax + 1;
  
  const int lmax = two_lmax/2;

  const int lmax_plus_one = lmax + 1;

  class array<double> Yl_reduced_table(two_lmax_plus_one , lmax_plus_one , lmax_plus_one);

  Yl_reduced_table = 0.0;

  for (int la = 0 ; la <= lmax ; la++)
    for (int lb = 0 ; lb <= lmax ; lb++)
      {
	const int lmin_ab = abs (la - lb) , lmax_ab = la + lb;

	for (int l = lmin_ab ; l <= lmax_ab ; l++)
	  {
	    if ((la + l + lb)%2 == 0) Yl_reduced_table(l , la , lb) = OBME_YL_reduced_in_l (l , la , lb);
	  }
      }

  Ylm_table_coupled_to_l = 0.0;

  for (unsigned int lm_sa = 0 ; lm_sa < lm_number ; lm_sa++)
    {
      const class lm_struct &lm_a = lm_qn_table(lm_sa);

      const int la = lm_a.get_l ();
      
      const int ml_a = lm_a.get_ml ();

      for (unsigned int lm_sb = 0 ; lm_sb < lm_number ; lm_sb++)
	{
	  const class lm_struct &lm_b = lm_qn_table(lm_sb);

	  const int lb = lm_b.get_l ();
	  
	  const int ml_b = lm_b.get_ml ();

	  const int lmin_ab = abs (la - lb);
	  
	  const int lmax_ab = la + lb;

	  for (int l = lmin_ab ; l <= lmax_ab ; l++)
	    {
	      if ((la + l + lb)%2 == 0)
		{
		  const int ml = ml_b - ml_a;

		  if (abs (ml) <= l)
		    {
		      const double Yl_reduced_ME = Yl_reduced_table(l , la , lb);

		      Ylm_table_coupled_to_l(l , lm_sa , lm_sb) = ME_dereduced (Yl_reduced_ME , l , ml , la , ml_a , lb , ml_b);
		    }
		}
	    }
	}
    }
}




void inputs_misc::Ylm_table_coupled_to_j_calc (
					       const class array<class ljm_struct> &ljm_qn_table ,
					       class array<double> &Ylm_table_coupled_to_j)
{
  const unsigned int ljm_number = ljm_qn_table.dimension (0);

  const int two_lmax = Ylm_table_coupled_to_j.dimension (0) - 1;

  const int two_lmax_plus_one = two_lmax + 1;

  const int lmax = two_lmax/2;

  const int lmax_plus_one = lmax + 1;

  class array<double> Yl_reduced_table(two_lmax_plus_one , lmax_plus_one , 2 , lmax_plus_one , 2);
  
  Yl_reduced_table = 0.0;

  for (int la = 0 ; la <= lmax ; la++)
    for (double ja = (la == 0) ? (0.5) : (la - 0.5) ; rint (ja - la - 0.5) <= 0.0 ; ja++)
      {
	const unsigned int ja_index = (la < ja) ? (0) : (1);

	for (int lb = 0 ; lb <= lmax ; lb++)
	  for (double jb = (lb == 0) ? (0.5) : (lb - 0.5) ; rint (jb - lb - 0.5) <= 0.0 ; jb++)
	    {
	      const unsigned int jb_index = (lb < jb) ? (0) : (1);

	      const int lmin_ab = abs (la - lb);

	      const int lmax_ab = la + lb;

	      for (int l = lmin_ab ; l <= lmax_ab ; l++)
		{
		  if ((la + l + lb)%2 == 0) Yl_reduced_table(l , la , ja_index , lb , jb_index) = OBME_YL_reduced_in_j (l , la , ja , lb , jb);
		}
	    }
      }

  Ylm_table_coupled_to_j = 0.0;

  for (unsigned int ljm_sa = 0 ; ljm_sa < ljm_number ; ljm_sa++)
    {
      const class ljm_struct &ljm_a = ljm_qn_table(ljm_sa);
      
      const int la = ljm_a.get_l ();

      const double ja = ljm_a.get_j  ();
      const double ma = ljm_a.get_m ();

      const unsigned int ja_index = (la < ja) ? (0) : (1);

      for (unsigned int ljm_sb = 0 ; ljm_sb < ljm_number ; ljm_sb++)
	{
	  const class ljm_struct &ljm_b = ljm_qn_table(ljm_sb);

	  const int lb = ljm_b.get_l ();

	  const double jb = ljm_b.get_j ();
	  const double mb = ljm_b.get_m ();

	  const unsigned int jb_index = (lb < jb) ? (0) : (1);

	  const int lmin_ab = abs (la - lb);

	  const int lmax_ab = la + lb;

	  for (int l = lmin_ab ; l <= lmax_ab ; l++)
	    {
	      if ((la + l + lb)%2 == 0)
		{
		  const int ml = make_int (mb - ma);

		  if (abs (ml) <= l)
		    {
		      const double Yl_reduced_ME = Yl_reduced_table(l , la , ja_index , lb , jb_index);

		      Ylm_table_coupled_to_j(l , ljm_sa , ljm_sb) = ME_dereduced (Yl_reduced_ME , l , ml , ja , ma , jb , mb);
		    }}}}}
}











// Storage of correlation densities and integrated correlation densities in a file
// -------------------------------------------------------------------------------
// The correlation density can be pp, nn, pn, or total.

void inputs_misc::correlation_density_files_store (
						   const bool is_it_radial ,
						   const string PSI_qn_string ,
						   const string pn_string ,
						   const class array<double> &rk_tab ,
						   const class array<double> &theta_tab ,
						   const class array<TYPE> &angular_densities_tab ,
						   const class array<TYPE> &density_tab)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in inputs_misc::correlation_density_files_store");
  
  const unsigned int N_RKmax = rk_tab.dimension (0);
  
  const unsigned int theta_number = theta_tab.dimension (0);
  
  const string density_string = (is_it_radial) ? ("radial_correlation_density_" + pn_string + "_" + PSI_qn_string + ".dat") : ("momentum_correlation_density_" + pn_string + "_" + PSI_qn_string + ".dat");

  const string angular_densities_string = (is_it_radial) ? ("radial_integrated_correlation_density_" + pn_string + "_" + PSI_qn_string + ".dat") : ("momentum_integrated_correlation_density_" + pn_string + "_" + PSI_qn_string + ".dat");

  ofstream density_file (density_string.c_str() , ios::out);

  density_file.precision (15);

  for (unsigned int i = 0 ; i < N_RKmax ; i++)
    {
      const double rk = rk_tab(i);
	      
      const double rk2 = rk*rk;
	      
      for (unsigned int it = 0 ; it < theta_number ; it++)
	{
	  const double theta12_radians = theta_tab(it);

	  const double theta12_degrees = theta12_radians*180.0/M_PI;

	  const TYPE density_rk_theta12 = density_tab(i , it);
	  const TYPE density_rk_theta12_rk2 = rk2*density_rk_theta12;
	  
#ifdef TYPEisDOUBLECOMPLEX 
	      
	  density_file << rk << " " << theta12_radians  << " " << theta12_degrees << " "
		       << real (density_rk_theta12)     << " " << imag (density_rk_theta12) << " "
		       << real (density_rk_theta12_rk2) << " " << imag (density_rk_theta12_rk2) << endl;
	      
#endif
	      
#ifdef TYPEisDOUBLE
	      
	  density_file << rk << " " << theta12_radians << " " << theta12_degrees << " "
		       << density_rk_theta12 << " "  << density_rk_theta12_rk2 << endl;

#endif
	  
	}
    }

  density_file.close ();

  ofstream angular_densities_file (angular_densities_string.c_str() , ios::out);
      
  angular_densities_file.precision (15);
      
  for (unsigned int it = 0 ; it < theta_number ; it++)
    {
      const double theta12_radians = theta_tab(it);

      const double theta12_degrees = theta12_radians*180.0/M_PI;

      const TYPE angular_density_theta12_S0 = angular_densities_tab(0 , it);
      const TYPE angular_density_theta12_S1 = angular_densities_tab(1 , it);

      const TYPE angular_density_theta12 = angular_density_theta12_S0 + angular_density_theta12_S1;
	 
#ifdef TYPEisDOUBLECOMPLEX 
	      
      angular_densities_file << theta12_radians << " " << theta12_degrees << " "
			     << real (angular_density_theta12_S0) << " " << imag (angular_density_theta12_S0) << " "
			     << real (angular_density_theta12_S1) << " " << imag (angular_density_theta12_S1) << " "
			     << real (angular_density_theta12)    << " " << imag (angular_density_theta12) << endl;
	  	      
#endif
	      
#ifdef TYPEisDOUBLE
	      
      angular_densities_file << theta12_radians << " " << theta12_degrees << " "
			     << angular_density_theta12_S0 << " "  << angular_density_theta12_S1 << " " << angular_density_theta12 << endl;
	      
#endif
	 
    }

  angular_densities_file.close ();
}
						   



// True if one has scattering states, false if not
// -----------------------------------------------

bool inputs_misc::is_there_scat_determine (const class nucleons_data &particles_data)
{  
  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {  
      const class nlj_struct &shell_qn = shells_qn(s);
      
      const bool S_matrix_pole_s = shell_qn.get_S_matrix_pole ();
      
      if (!S_matrix_pole_s) return true;
    }

  return false;
}
